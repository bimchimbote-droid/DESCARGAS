using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

static class InsumosEdicionCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object o) => JsonSerializer.Serialize(o);
    private static void Rechaza(Action accion)
    { try { accion(); } catch (InvalidOperationException) { return; } throw new Exception("Se aceptó una modificación inválida del insumo."); }
    private static MYGPresupuestoDocumento Crear()
    {
        var p = new MYGPresupuestoDocumento { Nombre = "INSUMOS", Item = "01" };
        var a = MYGEstructuraPresupuestos.InsertarNodo(p, false); a.Descripcion = "PARTIDA A";
        var b = MYGEstructuraPresupuestos.InsertarNodo(p, false); b.Descripcion = "PARTIDA B";
        a = p.Items.Single(x => x.Id == a.Id); b = p.Items.Single(x => x.Id == b.Id);
        p.Costos.Insumos.Add(new() { Codigo = "M01", Descripcion = "ARENA", Unidad = "m3", Precio = 20 });
        p.Costos.Insumos.Add(new() { Codigo = "M02", Descripcion = "PIEDRA", Unidad = "m3", Precio = 30 });
        a.Costos.Analisis.Add(new() { InsumoId = p.Costos.Insumos[0].Id, Cantidad = 2.5m, NumeroRecursos = 3, DesperdicioPorcentaje = 7 });
        b.Costos.Analisis.Add(new() { InsumoId = p.Costos.Insumos[0].Id, Cantidad = 1 });
        MYGProyectoStorage.ValidarPresupuesto(p); return p;
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var p = Crear(); var a = p.Items[0]; var original = a.Costos.Analisis.Single(); var b = p.Items[1];
        string id = original.Id, firmaB = Firma(b); var costos = a.Costos; var items = p.Items; int historial = 0;
        var copia = MYGProyectoStorage.Copia(p);
        var r = MYGInsumosEdicion.Aplicar(p, a.Id, id, new() { InsumoId = p.Costos.Insumos[1].Id }, antes: () => historial++);
        Exige(r.Id == id && r.Cantidad == 2.5m && r.NumeroRecursos == 3 && r.DesperdicioPorcentaje == 7 && r.Modo == MYGModoCantidad.Directa,
            "Reemplazar perdió identidad, cantidad, cuadrilla, desperdicio o modo.");
        Exige(Firma(b) == firmaB && ReferenceEquals(costos, a.Costos) && ReferenceEquals(items, p.Items) && historial == 1 &&
            copia.Items[0].Costos.Analisis.Single().InsumoId == copia.Costos.Insumos[0].Id && MYGMotorPresupuestos.Analizar(p, a).PrecioUnitario == 80.25m,
            "El reemplazo alteró otro ACU, referencias o instantáneas, o no recalculó.");
        pasa("Reemplazo local conserva identidad y coeficientes, recalcula el ACU y mantiene las demás partidas e instantáneas");

        var cambio = MYGProyectoStorage.Copia(p.Costos.Insumos[0]); cambio.Precio = 45; cambio.Descripcion = "ARENA EDITADA";
        MYGInsumosEdicion.EditarInsumo(p, cambio);
        Exige(MYGMotorPresupuestos.Analizar(p, b).PrecioUnitario == 45 && MYGMotorPresupuestos.Analizar(p, a).PrecioUnitario == 80.25m,
            "La edición compartida no actualizó sus apariciones o modificó un reemplazo local.");
        var invalido = MYGProyectoStorage.Copia(cambio); invalido.Grupo = MYGGrupoRecurso.Equipo;
        string firma = Firma(p); Rechaza(() => MYGInsumosEdicion.EditarInsumo(p, invalido, () => historial++));
        Exige(Firma(p) == firma && historial == 1, "Una edición compartida inválida mutó datos o añadió historial.");
        pasa("Edición compartida sólo afecta las referencias del presupuesto activo y rechaza cambiar el tipo de un insumo utilizado");

        var nuevo = new MYGInsumo { Codigo = "M03", Descripcion = "CEMENTO", Precio = 40 };
        var agregado = MYGInsumosEdicion.Aplicar(p, a.Id, null, new() { NuevoInsumo = nuevo }, id);
        Exige(a.Costos.Analisis[0].Id == agregado.Id && a.Costos.Analisis[1].Id == id && p.Costos.Insumos.Count == 3,
            "Agregar sobre la selección no insertó antes dentro del mismo grupo.");
        var ultimo = MYGInsumosEdicion.Aplicar(p, a.Id, null, new() { InsumoId = nuevo.Id });
        Exige(a.Costos.Analisis.Last().Id == ultimo.Id, "Agregar al final no respetó el orden.");
        firma = Firma(p); var otraCopia = MYGProyectoStorage.Copia(p.Costos.Insumos[0]); otraCopia.Descripcion = "CANCELADA";
        Exige(Firma(p) == firma, "Editar una copia antes de aceptar mutó el presupuesto.");
        Rechaza(() => MYGInsumosEdicion.Aplicar(p, a.Id, null, new() { NuevoInsumo = nuevo }));
        Exige(Firma(p) == firma, "Rechazar ID duplicado dejó un insumo huérfano.");
        pasa("Inserción sobre selección y al final respeta el orden; copias canceladas e identificadores duplicados no modifican el presupuesto");

        var lote = Crear(); var la = lote.Items[0]; var lb = lote.Items[1];
        var analisisLote = la.Costos.Analisis; var originalLote = analisisLote.Single();
        var itemsLote = lote.Items; var costosLote = la.Costos; var insumosLote = lote.Costos.Insumos;
        var materialExistente = insumosLote[1]; string firmaOtraPartida = Firma(lb), firmaAntesLote = Firma(lote);
        var obrero = new MYGInsumo { Descripcion = "OPERARIO", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 12 };
        var equipoLote = new MYGInsumo { Descripcion = "VIBRADOR", Unidad = "hm", Grupo = MYGGrupoRecurso.Equipo, Precio = 8 };
        var cementoLote = new MYGInsumo { Descripcion = "CEMENTO EN LOTE", Unidad = "bol", Grupo = MYGGrupoRecurso.Materiales, Precio = 30 };
        var subcontrato = new MYGInsumo { Descripcion = "SERVICIO", Unidad = "und", Grupo = MYGGrupoRecurso.Subcontratos, Precio = 15 };
        int historialLote = 0;
        var agregadosLote = MYGInsumosEdicion.AplicarVarios(lote, la.Id, new MYGSeleccionInsumo[] {
            new() { NuevoInsumo = obrero }, new() { InsumoId = materialExistente.Id }, new() { NuevoInsumo = equipoLote },
            new() { NuevoInsumo = cementoLote }, new() { NuevoInsumo = subcontrato }
        }, originalLote.Id, () => { Exige(Firma(lote) == firmaAntesLote, "El lote creó historial después de publicar cambios."); historialLote++; });
        Exige(agregadosLote.Select(x => x.Grupo).SequenceEqual(new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales,
            MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Subcontratos }) &&
            agregadosLote[0].Modo == MYGModoCantidad.Rendimiento && agregadosLote[2].Modo == MYGModoCantidad.Rendimiento &&
            agregadosLote[1].Modo == MYGModoCantidad.Directa,
            "La inserción múltiple no conservó el tipo y modo propios de cada insumo.");
        Exige(analisisLote.Select(x => x.Id).SequenceEqual(new[] { agregadosLote[1].Id, agregadosLote[3].Id,
            originalLote.Id, agregadosLote[0].Id, agregadosLote[2].Id, agregadosLote[4].Id }),
            "El lote invirtió el orden seleccionado o insertó recursos antes de una línea de otro grupo.");
        Exige(historialLote == 1 && ReferenceEquals(itemsLote, lote.Items) && ReferenceEquals(costosLote, la.Costos) &&
            ReferenceEquals(analisisLote, la.Costos.Analisis) && ReferenceEquals(insumosLote, lote.Costos.Insumos) &&
            ReferenceEquals(originalLote, analisisLote[2]) && ReferenceEquals(materialExistente, insumosLote[1]) &&
            Firma(lb) == firmaOtraPartida && insumosLote.Count == 6 && agregadosLote.All(x => analisisLote.Contains(x)),
            "El lote reemplazó referencias existentes, alteró otro ACU, duplicó insumos o añadió más de una entrada de historial.");
        pasa("Inserción múltiple conserva grupos y modos, orden estable antes de la selección y referencias existentes con un único historial");

        firmaAntesLote = Firma(lote); int historialInvalido = 0;
        var sinPublicar = new MYGInsumo { Descripcion = "NO PUBLICAR", Precio = 1 };
        var deshabilitado = new MYGInsumo { Descripcion = "DESHABILITADO EN LOTE", Habilitado = false };
        Rechaza(() => MYGInsumosEdicion.AplicarVarios(lote, la.Id, new MYGSeleccionInsumo[] {
            new() { NuevoInsumo = sinPublicar }, new() { NuevoInsumo = deshabilitado }
        }, antes: () => historialInvalido++));
        Rechaza(() => MYGInsumosEdicion.AplicarVarios(lote, la.Id, new MYGSeleccionInsumo[] {
            new() { NuevoInsumo = sinPublicar }, new() { NuevoInsumo = sinPublicar }
        }, antes: () => historialInvalido++));
        Exige(Firma(lote) == firmaAntesLote && historialInvalido == 0 && !lote.Costos.Insumos.Any(x => x.Id == sinPublicar.Id),
            "Un lote inválido publicó líneas, dejó un insumo huérfano o creó historial.");
        Exige(MYGInsumosEdicion.AplicarVarios(lote, la.Id, Array.Empty<MYGSeleccionInsumo>(), antes: () => historialInvalido++).Count == 0 &&
            Firma(lote) == firmaAntesLote && historialInvalido == 0, "Un lote vacío modificó datos o creó historial.");
        pasa("Un insumo deshabilitado o duplicado rechaza todo el lote sin historial ni huérfanos; un lote vacío no modifica datos");

        var compartido = MYGProyectoStorage.Copia(p.Costos.Insumos[1]); compartido.Precio = 10; compartido.Marca = "MARCA";
        MYGInsumosEdicion.Aplicar(p, a.Id, id, new() { NuevoInsumo = compartido, EditarCompartido = true });
        Exige(p.Costos.Insumos.Single(x => x.Id == compartido.Id).Marca == "MARCA" && MYGMotorPresupuestos.Analizar(p, a).Recursos.Single(x => x.Recurso.Id == id).Total == 26.75m,
            "La pestaña editar y reemplazar no publicó el insumo compartido.");
        pasa("Editar y reemplazar publica los datos compartidos y recalcula sin duplicar el insumo");

        var ciclo = Crear(); var ca = ciclo.Items[0]; var cb = ciclo.Items[1];
        MYGInsumosEdicion.Aplicar(ciclo, ca.Id, null, new() { SubpartidaIdLocal = cb.IdLocalMYG });
        firma = Firma(ciclo); int antesCiclo = 0;
        Rechaza(() => MYGInsumosEdicion.Aplicar(ciclo, cb.Id, null, new() { SubpartidaIdLocal = ca.IdLocalMYG }, antes: () => antesCiclo++));
        Rechaza(() => MYGInsumosEdicion.Aplicar(ciclo, ca.Id, ca.Costos.Analisis[0].Id, new() { SubpartidaIdLocal = ca.IdLocalMYG }));
        Exige(Firma(ciclo) == firma && antesCiclo == 0, "Los ciclos cambiaron parcialmente el ACU o historial.");
        pasa("Insumos compuestos permiten referencias válidas y rechazan ciclos directos e indirectos atómicamente");

        var compuestosLote = Crear(); var cla = compuestosLote.Items[0]; var clb = compuestosLote.Items[1]; int historialCompuestos = 0;
        var compuestos = MYGInsumosEdicion.AplicarVarios(compuestosLote, cla.Id, new MYGSeleccionInsumo[] {
            new() { InsumoId = compuestosLote.Costos.Insumos[1].Id }, new() { SubpartidaIdLocal = clb.IdLocalMYG }
        }, antes: () => historialCompuestos++);
        Exige(compuestos.Count == 2 && compuestos[1].Grupo == MYGGrupoRecurso.Subpartidas &&
            compuestos[1].SubpartidaIdLocal == clb.IdLocalMYG && historialCompuestos == 1,
            "Un lote de insumo simple y compuesto no publicó la referencia válida con un solo historial.");
        firma = Firma(compuestosLote); var previoAlCiclo = new MYGInsumo { Descripcion = "ANTES DEL CICLO", Precio = 3 };
        Rechaza(() => MYGInsumosEdicion.AplicarVarios(compuestosLote, clb.Id, new MYGSeleccionInsumo[] {
            new() { NuevoInsumo = previoAlCiclo }, new() { SubpartidaIdLocal = cla.IdLocalMYG }
        }, antes: () => historialCompuestos++));
        Rechaza(() => MYGInsumosEdicion.AplicarVarios(compuestosLote, cla.Id, new MYGSeleccionInsumo[] {
            new() { NuevoInsumo = previoAlCiclo }, new() { SubpartidaIdLocal = cla.IdLocalMYG }
        }, antes: () => historialCompuestos++));
        Exige(Firma(compuestosLote) == firma && historialCompuestos == 1 &&
            !compuestosLote.Costos.Insumos.Any(x => x.Id == previoAlCiclo.Id),
            "Un ciclo directo o indirecto publicó parcialmente el lote de compuestos.");
        pasa("Lotes mixtos admiten subpartidas válidas y rechazan ciclos directos e indirectos sin publicar recursos ni insumos previos");

        var modos = Crear(); var ma = modos.Items[0];
        var hm = new MYGInsumo { Descripcion = "MEZCLADORA", Unidad = "hm", Grupo = MYGGrupoRecurso.Equipo, Precio = 8 };
        var porcentaje = new MYGInsumo { Descripcion = "HERRAMIENTAS", Unidad = "%mo", Grupo = MYGGrupoRecurso.Equipo, Precio = 0 };
        modos.Costos.Insumos.Add(hm); modos.Costos.Insumos.Add(porcentaje);
        var rendimiento = MYGInsumosEdicion.Aplicar(modos, ma.Id, null, new() { InsumoId = hm.Id });
        rendimiento.NumeroRecursos = 2; rendimiento.Cantidad = 99; ma.Costos.RendimientoDiario = 4; rendimiento.DesperdicioPorcentaje = 5;
        firma = Firma(modos);
        Rechaza(() => MYGInsumosEdicion.Aplicar(modos, ma.Id, rendimiento.Id, new() { InsumoId = porcentaje.Id }));
        Exige(Firma(modos) == firma, "Se convirtió horas en porcentaje de mano de obra.");
        var tasa = MYGInsumosEdicion.Aplicar(modos, ma.Id, null, new() { InsumoId = porcentaje.Id }); tasa.Cantidad = 3;
        firma = Firma(modos); Rechaza(() => MYGInsumosEdicion.Aplicar(modos, ma.Id, tasa.Id, new() { InsumoId = hm.Id }));
        Rechaza(() => MYGInsumosEdicion.Aplicar(modos, ma.Id, tasa.Id, new() { SubpartidaIdLocal = modos.Items[1].IdLocalMYG }));
        Exige(Firma(modos) == firma, "Se reinterpretó un porcentaje como horas o subpartida.");
        var unidadInvalida = MYGProyectoStorage.Copia(hm); unidadInvalida.Unidad = "%mo";
        Rechaza(() => MYGInsumosEdicion.EditarInsumo(modos, unidadInvalida));
        Rechaza(() => MYGInsumosEdicion.Aplicar(modos, ma.Id, rendimiento.Id, new() { NuevoInsumo = unidadInvalida, EditarCompartido = true }));
        Exige(Firma(modos) == firma, "La edición compartida reinterpretó modos de otras apariciones.");
        var consumo = MYGInsumosEdicion.Aplicar(modos, ma.Id, rendimiento.Id, new() { InsumoId = modos.Costos.Insumos[1].Id });
        Exige(consumo.Modo == MYGModoCantidad.Directa && consumo.Cantidad == 4 && consumo.NumeroRecursos == 2 && consumo.DesperdicioPorcentaje == 5,
            "Pasar rendimiento a consumo perdió el coeficiente efectivo o desperdicio.");
        pasa("Reemplazo conserva coeficiente de rendimiento a consumo y rechaza convertir horas/consumos a porcentajes, también en edición compartida");

        var valido = new MYGInsumo { Codigo = "M-META", Descripcion = "META", Precio = 15, CodigoAlterno = "A-001", UsarCodigoAlterno = true,
            GrupoGenerico = "ÁRIDOS", Proveedor = "PROVEEDOR", DescripcionBase = "BASE", PrecioBase = 10, FechaBase = new(2026, 1, 1),
            UnidadBase = "kg", Marca = "MARCA", Especificaciones = "ESPECIFICACIÓN\nSEGUNDA LÍNEA", ImagenRuta = "C:\\Imagenes\\arena.png",
            IGVPorcentaje = 18, FechaCompra = new(2026, 9, 10), FichaTecnicaRuta = "C:\\Fichas\\arena.pdf", Habilitado = true };
        MYGInsumosEdicion.ValidarInsumo(valido); var metadata = Crear(); metadata.Costos.Insumos.Add(valido);
        string ruta = Path.Combine(carpeta, "Metadatos insumo.sqlite");
        var proyecto = new MYGProyectoDocumento { Nombre = "METADATOS", Datos = new() { UsarUbicacion = false }, Presupuestos = new() { metadata } };
        MYGProyectoStorage.Guardar(ruta, proyecto);
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, proyecto.Id).Presupuestos.Single().Costos.Insumos.Single(x => x.Id == valido.Id);
        Exige(Firma(reabierto) == Firma(valido), "SQLite no conservó todos los metadatos opcionales del insumo.");
        var entrada = MYGCatalogos.GuardarInsumo(ruta, valido);
        var delCatalogo = MYGCatalogos.LeerInsumo(ruta, entrada.Id, entrada.Revision);
        Exige(delCatalogo.CodigoAlterno == "A-001" && delCatalogo.Especificaciones == valido.Especificaciones && delCatalogo.FechaCompra == valido.FechaCompra && delCatalogo.IGVPorcentaje == 18 && delCatalogo.FichaTecnicaRuta == valido.FichaTecnicaRuta,
            "El catálogo perdió metadatos del insumo.");
        var antiguo = JsonSerializer.Deserialize<MYGInsumo>("{\"Id\":\"VIEJO\",\"Descripcion\":\"ANTIGUO\",\"Unidad\":\"und\",\"Precio\":1}");
        Exige(antiguo.Habilitado && antiguo.CodigoAlterno == "" && antiguo.IGVPorcentaje == 0, "Un JSON antiguo no conservó valores predeterminados retrocompatibles.");
        pasa("Metadatos, código alterno, referencias a imagen/ficha y fechas persisten en SQLite y catálogo, con compatibilidad de JSON anteriores");

        var invalidos = Crear(); var ia = invalidos.Items[0];
        foreach (var v in new[] { new MYGInsumo { Descripcion = "", Precio = 1 }, new MYGInsumo { Descripcion = "NEGATIVO", Precio = -1 },
            new MYGInsumo { Descripcion = "IGV", IGVPorcentaje = 101 }, new MYGInsumo { Descripcion = "BASE", PrecioBase = -1 },
            new MYGInsumo { Descripcion = "DESHABILITADO", Habilitado = false }, new MYGInsumo { Descripcion = "DESBORDE", Precio = decimal.MaxValue } })
        {
            firma = Firma(invalidos); Rechaza(() => MYGInsumosEdicion.Aplicar(invalidos, ia.Id, null, new() { NuevoInsumo = v }));
            Exige(Firma(invalidos) == firma, "Un insumo inválido dejó una línea o insumo huérfano.");
        }
        pasa("Datos incompletos, precios/IGV inválidos, recursos deshabilitados y desbordamientos se rechazan sin modificaciones parciales");
        VerificarEdicionEnACU(carpeta, pasa);
    }

    private static void VerificarEdicionEnACU(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("EDICIÓN DE ÍNDICE EN ACU");
        documento.Datos = new() { UsarUbicacion = false };
        var presupuesto = documento.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        var otra = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        partida = presupuesto.Items.Single(x => x.Id == partida.Id);
        otra = presupuesto.Items.Single(x => x.Id == otra.Id);
        var insumo = new MYGInsumo { Descripcion = "CEMENTO", Unidad = "Bls", Precio = 28 };
        presupuesto.Costos.Insumos.Add(insumo);
        var recurso = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, null, new() { InsumoId = insumo.Id });
        recurso.Cantidad = 2.5m; recurso.NumeroRecursos = 3; recurso.DesperdicioPorcentaje = 7;
        MYGInsumosEdicion.Aplicar(presupuesto, otra.Id, null, new() { InsumoId = insumo.Id });
        decimal precio = MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario;
        string ruta = Path.Combine(carpeta, "Índice editado desde ACU.sqlite");
        foreach (string indice in new[] { MYGCatalogoIndicesUnificados.Listar().Single(x => x.Codigo == "21").ToString(), "" })
        {
            var cambio = MYGProyectoStorage.Copia(presupuesto.Costos.Insumos.Single());
            cambio.GrupoGenerico = indice;
            int historial = 0;
            var aplicado = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, recurso.Id,
                new() { NuevoInsumo = cambio, EditarCompartido = true }, antes: () => historial++);
            Exige(historial == 1 && presupuesto.Costos.Insumos.Count == 1 &&
                presupuesto.Costos.Insumos.Single().GrupoGenerico == indice &&
                aplicado.Id == recurso.Id && aplicado.InsumoId == insumo.Id && aplicado.Cantidad == 2.5m &&
                aplicado.NumeroRecursos == 3 && aplicado.DesperdicioPorcentaje == 7 &&
                otra.Costos.Analisis.Single().InsumoId == insumo.Id &&
                MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario == precio,
                "Editar el índice desde el ACU perdió la clasificación, duplicó el insumo o alteró los coeficientes/importes.");
            MYGProyectoStorage.Guardar(ruta, documento);
            var reabierto = MYGBaseDatos.LeerProyecto(ruta, documento.Id).Presupuestos.Single();
            Exige(reabierto.Costos.Insumos.Single().GrupoGenerico == indice &&
                reabierto.Items.SelectMany(x => x.Costos.Analisis).All(x => x.InsumoId == insumo.Id),
                "Guardar y reabrir SQLite perdió el índice editado o la asociación de sus apariciones en el ACU.");
        }
        pasa("Editar y reemplazar conserva o borra explícitamente el índice compartido al reabrir SQLite, sin cambiar cantidades ni importes");
    }
}
