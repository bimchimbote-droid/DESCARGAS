using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class DisenoProfesionalCheck
{
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", EntryPoint = "FindWindowExW", CharSet = CharSet.Unicode)]
    private static extern IntPtr BuscarHijo(IntPtr padre, IntPtr anterior, string clase, string titulo);
    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr ventana, out RectanguloNativo rectangulo);
    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr ventana);
    [DllImport("user32.dll")]
    private static extern bool RedrawWindow(IntPtr ventana, IntPtr rectangulo, IntPtr region, uint opciones);
    [DllImport("user32.dll")]
    private static extern IntPtr GetDC(IntPtr ventana);
    [DllImport("user32.dll")]
    private static extern int ReleaseDC(IntPtr ventana, IntPtr dc);
    [DllImport("gdi32.dll")]
    private static extern bool GdiFlush();
    [DllImport("gdi32.dll", EntryPoint = "BitBlt")]
    private static extern bool CopiarPixeles(IntPtr destino, int x, int y, int ancho, int alto,
        IntPtr origen, int origenX, int origenY, uint operacion);

    [StructLayout(LayoutKind.Sequential)]
    private struct RectanguloNativo
    {
        internal int Izquierda, Arriba, Derecha, Abajo;
        internal readonly Rectangle Rectangulo => Rectangle.FromLTRB(Izquierda, Arriba, Derecha, Abajo);
    }

    private sealed class PestanasPrueba : TabControl
    {
        internal bool Navegar(Keys tecla)
        {
            var mensaje = Message.Create(Handle, 0x0100, new IntPtr((int)(tecla & Keys.KeyCode)), IntPtr.Zero);
            return ProcessCmdKey(ref mensaje, tecla);
        }
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        Point cursorOriginal = Cursor.Position;
        try
        {
            foreach (TabAlignment alineacion in new[] { TabAlignment.Top, TabAlignment.Bottom })
            {
                using var formulario = new Form { ClientSize = new Size(700, 450) };
                using var pestanas = new PestanasPrueba { Dock = DockStyle.Fill, Alignment = alineacion };
                using var primera = new TabPage("Presupuesto");
                using var segunda = new TabPage("Especificaciones");
                using var texto = new TextBox { Text = "PARTIDA12145", Dock = DockStyle.Top };
                using var documento = new RichTextBox { Dock = DockStyle.Fill,
                    Rtf = @"{\rtf1\ansi{\colortbl;\red22\green90\blue52;}\b TITULO\b0\par\cf1 Texto de autor conservado.}" };
                primera.Controls.Add(texto); segunda.Controls.Add(documento);
                pestanas.TabPages.AddRange(new[] { primera, segunda });
                formulario.Controls.Add(pestanas); formulario.Show();
                MYG2027_TemaComercial.Aplicar(formulario);
                string rtf = documento.Rtf;
                int cambios = 0;
                pestanas.SelectedIndexChanged += (_, _) => cambios++;
                for (int modo = 0; modo < 2; modo++)
                {
                    int seleccion = pestanas.SelectedIndex;
                    MYGTemaPestanas.Preparar(pestanas);
                    MYGTemaPestanas.Preparar(pestanas);
                    Application.DoEvents();
                    exige(pestanas.SelectedIndex == seleccion && texto.Text == "PARTIDA12145" && documento.Rtf == rtf,
                        "Reaplicar el diseño debe conservar selección, nombre y formato de autor.");
                    pestanas.SelectedIndex = 0;
                    int antes = cambios;
                    pestanas.Focus();
                    exige(pestanas.Navegar(Keys.Control | Keys.Tab) && pestanas.SelectedIndex == 1 && cambios == antes + 1,
                        "Las pestañas modernas deben conservar Ctrl+Tab y emitir un solo cambio de selección.");
                    Application.DoEvents();
                    exige(documento.Visible && documento.Rtf == rtf,
                        "La transición debe mostrar el documento inmediatamente sin transformar su RTF.");
                    exige(pestanas.Navegar(Keys.Control | Keys.Shift | Keys.Tab) && pestanas.SelectedIndex == 0,
                        "Ctrl+Shift+Tab debe conservar la navegación inversa.");
                    texto.Focus(); texto.Select(3, 4);
                    MYG2027_TemaComercial.Alternar(false);
                    Application.DoEvents();
                    exige(texto.Text == "PARTIDA12145" && texto.SelectionStart == 3 && texto.SelectionLength == 4 &&
                        documento.Rtf == rtf,
                        "Cambiar de tema debe preservar el texto, la selección de edición y los colores de autor.");
                }
                // Cerrar durante una transición ejercita la liberación de su timer y ventana nativa.
                pestanas.SelectedIndex = 1;
                formulario.Close();
                Application.DoEvents();
            }
            if (OperatingSystem.IsWindows() && !SystemInformation.HighContrast)
                foreach (bool oscuro in new[] { false, true })
                {
                    if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                    foreach (TabAlignment alineacion in new[] { TabAlignment.Top, TabAlignment.Bottom })
                        VerificarRepintado(alineacion, oscuro, exige);
                }
        }
        finally
        {
            Cursor.Position = cursorOriginal;
            if (MYG2027_TemaComercial.Oscuro != original) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarRepintado(TabAlignment alineacion, bool oscuro, Action<bool, string> exige)
    {
        Rectangle pantalla = Screen.PrimaryScreen.WorkingArea;
        using var formulario = new Form
        {
            Text = "Prueba de repintado de pestañas",
            StartPosition = FormStartPosition.Manual,
            Location = new Point(pantalla.Left + 12, pantalla.Top + 12),
            ClientSize = new Size(Math.Min(680, pantalla.Width - 40), Math.Min(280, pantalla.Height - 80))
        };
        using var pestanas = new PestanasPrueba { Dock = DockStyle.Fill, Alignment = alineacion };
        using var foco = new Button { Text = "Foco de prueba", Dock = DockStyle.Bottom, Height = 28 };
        using var primera = new TabPage("Presupuesto");
        using var segunda = new TabPage("Especificaciones");
        using var texto = new TextBox { Text = "PARTIDA12145", Dock = DockStyle.Top, HideSelection = false };
        using var documento = new RichTextBox { Dock = DockStyle.Fill,
            Rtf = @"{\rtf1\ansi\b TITULO\b0\par Texto de autor conservado.}" };
        using var imagenes = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        using var icono = SystemIcons.Information.ToBitmap();
        imagenes.Images.Add(icono);
        primera.Controls.Add(texto); segunda.Controls.Add(documento);
        primera.ImageIndex = segunda.ImageIndex = 0;
        pestanas.ImageList = imagenes;
        pestanas.TabPages.AddRange(new[] { primera, segunda });
        formulario.Controls.Add(pestanas); formulario.Controls.Add(foco);
        formulario.Show(); formulario.Activate();
        MYG2027_TemaComercial.Aplicar(formulario);
        texto.Select(3, 4); foco.Focus();
        Cursor.Position = foco.PointToScreen(new Point(8, 8));
        // Aplicar detiene la transición del indicador: las dos imágenes deben
        // representar exactamente el mismo estado, sin depender de un timer.
        MYGTemaPestanas.Aplicar(pestanas); Procesar(220);
        string rtf = documento.Rtf;
        int seleccion = pestanas.SelectedIndex, cambios = 0;
        pestanas.SelectedIndexChanged += (_, _) => cambios++;
        string contexto = $"pestañas {alineacion}, tema {(oscuro ? "oscuro" : "claro")}";

        for (int vuelta = 0; vuelta < 2; vuelta++)
            for (int i = 0; i < pestanas.TabCount; i++)
            {
                Rectangle rectangulo = pestanas.GetTabRect(i);
                Point centro = new(rectangulo.Left + rectangulo.Width / 2, rectangulo.Top + rectangulo.Height / 2);
                MoverRaton(pestanas, centro);
                VerificarBorradoSinDestello(pestanas, exige, contexto + $", hover {i}, vuelta {vuelta}");
                VerificarCuadro(pestanas, exige, contexto + $", hover {i}, vuelta {vuelta}");
                // El daño parcial reproduce el repintado nativo al cambiar
                // hot tracking. No debe necesitar otra invalidación para limpiar.
                pestanas.Invalidate(new Rectangle(rectangulo.Left, rectangulo.Top,
                    Math.Max(1, rectangulo.Width / 2), rectangulo.Height));
                pestanas.Update(); Procesar();
                VerificarCuadro(pestanas, exige, contexto + $", repintado parcial {i}");
            }
        SalirRaton(pestanas, foco);
        VerificarBorradoSinDestello(pestanas, exige, contexto + ", salida del cursor");
        VerificarCuadro(pestanas, exige, contexto + ", salida del cursor");
        VerificarPinturaSinPasadaNativa(pestanas, exige, contexto);
        VerificarImpresion(pestanas, exige, contexto);
        exige(pestanas.SelectedIndex == seleccion && cambios == 0 && texto.Text == "PARTIDA12145" &&
            texto.SelectionStart == 3 && texto.SelectionLength == 4 && documento.Rtf == rtf,
            "Hover, repintado parcial y WM_PRINTCLIENT deben conservar selección, edición y RTF: " + contexto + ".");

        // Muchas etiquetas fuerzan el hijo nativo de desplazamiento. El acabado
        // de la barra debe respetar sus botones y el hit testing de las pestañas.
        for (int i = 0; i < 9; i++) pestanas.TabPages.Add(new TabPage("Metrado detallado " + (i + 1)) { ImageIndex = 0 });
        MYGTemaPestanas.Aplicar(pestanas); Procesar(220);
        IntPtr desplazamiento = BuscarHijo(pestanas.Handle, IntPtr.Zero, "msctls_updown32", null);
        exige(desplazamiento != IntPtr.Zero && IsWindowVisible(desplazamiento) &&
            GetWindowRect(desplazamiento, out _),
            "El desbordamiento debe mantener visible el control nativo de desplazamiento: " + contexto + ".");
        GetWindowRect(desplazamiento, out RectanguloNativo botones);
        int antes = pestanas.GetTabRect(0).Left;
        Point derecha = new(Math.Max(1, botones.Rectangulo.Width * 3 / 4), Math.Max(1, botones.Rectangulo.Height / 2));
        Cursor.Position = new Point(botones.Izquierda + derecha.X, botones.Arriba + derecha.Y);
        Enviar(desplazamiento, 0x0201, new IntPtr(1), Coordenadas(derecha));
        Enviar(desplazamiento, 0x0202, IntPtr.Zero, Coordenadas(derecha));
        Procesar(); SalirRaton(pestanas, foco);
        exige(pestanas.GetTabRect(0).Left < antes && pestanas.SelectedIndex == seleccion && cambios == 0,
            "La flecha debe desplazar las etiquetas sin cambiar la partida seleccionada: " + contexto + ".");
        VerificarCuadro(pestanas, exige, contexto + ", desbordamiento desplazado");
        VerificarIndicadorDesplazado(pestanas, desplazamiento, exige, contexto);
        GetWindowRect(desplazamiento, out botones);
        using (var antesBotones = Capturar(botones.Rectangulo))
        {
            pestanas.Refresh(); Procesar();
            using var despuesBotones = Capturar(botones.Rectangulo);
            exige(Pixeles(antesBotones).SequenceEqual(Pixeles(despuesBotones)),
                "Repintar la barra no debe borrar ni alterar los botones de desplazamiento: " + contexto + ".");
        }
        exige(texto.Text == "PARTIDA12145" && texto.SelectionStart == 3 && texto.SelectionLength == 4 && documento.Rtf == rtf,
            "El desplazamiento de pestañas debe conservar el texto, la selección y el formato de autor: " + contexto + ".");
        formulario.Close(); Procesar();
    }

    private static Rectangle Franja(TabControl pestanas)
    {
        Rectangle cliente = pestanas.ClientRectangle;
        Rectangle pagina = pestanas.SelectedTab?.Bounds ?? pestanas.DisplayRectangle;
        return pestanas.Alignment == TabAlignment.Bottom
            ? Rectangle.FromLTRB(cliente.Left, pagina.Bottom, cliente.Right, cliente.Bottom)
            : Rectangle.FromLTRB(cliente.Left, cliente.Top, cliente.Right, pagina.Top);
    }

    private static void VerificarBorradoSinDestello(TabControl pestanas, Action<bool, string> exige, string contexto)
    {
        Rectangle franja = Franja(pestanas);
        IntPtr dc = GetDC(pestanas.Handle);
        if (dc == IntPtr.Zero) throw new InvalidOperationException("No se pudo obtener el DC de las pestañas.");
        try
        {
            using var antes = CapturarDc(dc, franja);
            IntPtr resultado = Enviar(pestanas.Handle, 0x0014, dc, IntPtr.Zero); // WM_ERASEBKGND.
            GdiFlush();
            // Leer el mismo DC inmediatamente, sin DoEvents, Update ni una
            // reconstrucción de la barra que oculte el borrado transitorio.
            using var despues = CapturarDc(dc, franja);
            exige(resultado != IntPtr.Zero && Pixeles(antes).SequenceEqual(Pixeles(despues)),
                "WM_ERASEBKGND debe conservar la barra ya pintada sin un destello de fondo: " + contexto + ".");
        }
        finally { ReleaseDC(pestanas.Handle, dc); }
    }

    private static void VerificarPinturaSinPasadaNativa(TabControl pestanas, Action<bool, string> exige, string contexto)
    {
        int pasadasNativas = 0;
        bool repintado;
        DrawItemEventHandler observar = (_, _) => pasadasNativas++;
        pestanas.DrawItem += observar;
        try
        {
            const uint Invalidar = 0x0001, Borrar = 0x0004, Ahora = 0x0100;
            repintado = RedrawWindow(pestanas.Handle, IntPtr.Zero, IntPtr.Zero, Invalidar | Borrar | Ahora);
        }
        finally { pestanas.DrawItem -= observar; }
        exige(repintado && pasadasNativas == 0,
            "WM_PAINT debe presentar el cuadro compuesto sin dibujar primero las cabeceras nativas: " + contexto + ".");
    }

    private static Bitmap CapturarDc(IntPtr origen, Rectangle region)
    {
        var imagen = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppRgb);
        try
        {
            using var grafico = Graphics.FromImage(imagen);
            IntPtr destino = grafico.GetHdc();
            try
            {
                if (!CopiarPixeles(destino, 0, 0, region.Width, region.Height,
                    origen, region.Left, region.Top, 0x00CC0020)) // SRCCOPY.
                    throw new InvalidOperationException("No se pudo capturar el DC de las pestañas.");
                GdiFlush();
            }
            finally { grafico.ReleaseHdc(destino); }
            return imagen;
        }
        catch { imagen.Dispose(); throw; }
    }

    private static void VerificarIndicadorDesplazado(TabControl pestanas, IntPtr desplazamiento,
        Action<bool, string> exige, string contexto)
    {
        Rectangle franja = Franja(pestanas), activa = pestanas.GetTabRect(pestanas.SelectedIndex);
        Rectangle botones = GetWindowRect(desplazamiento, out var r) ? r.Rectangulo : Rectangle.Empty;
        using var imagen = Capturar(pestanas.RectangleToScreen(franja));
        int acento = MYG2027_TemaComercial.Azul.ToArgb();
        for (int y = 0; y < imagen.Height; y++)
            for (int x = 0; x < imagen.Width; x++)
            {
                Point punto = new(x + franja.Left, y + franja.Top);
                if (botones.Contains(pestanas.PointToScreen(punto))) continue;
                if (imagen.GetPixel(x, y).ToArgb() != acento) continue;
                exige(activa.Contains(punto),
                    "Desplazar las etiquetas no debe dejar el indicador bajo otra pestaña: " + contexto + ".");
            }
    }

    private static void VerificarCuadro(TabControl pestanas, Action<bool, string> exige, string contexto)
    {
        Rectangle franja = Franja(pestanas);
        exige(franja.Width > 100 && franja.Height > 10,
            "La prueba debe capturar una barra visible con etiquetas: " + contexto + ".");
        Rectangle region = pestanas.RectangleToScreen(franja);
        using var antes = Capturar(region);
        // Una reconstrucción total borra los residuos que una pintura parcial
        // defectuosa conserva alrededor de las cabeceras y de su indicador.
        const uint Invalidar = 0x0001, Borrar = 0x0004, Ahora = 0x0100, Marco = 0x0400;
        RedrawWindow(pestanas.Handle, IntPtr.Zero, IntPtr.Zero, Invalidar | Borrar | Ahora | Marco);
        Procesar();
        using var despues = Capturar(region);
        exige(Pixeles(antes).SequenceEqual(Pixeles(despues)),
            "La barra debe quedar limpia al mover el cursor sin necesitar otro repintado: " + contexto + ".");
        Color fondo = MYG2027_TemaComercial.Fondo;
        int bordes = 0;
        IntPtr desplazamiento = BuscarHijo(pestanas.Handle, IntPtr.Zero, "msctls_updown32", null);
        Rectangle botones = desplazamiento != IntPtr.Zero && IsWindowVisible(desplazamiento) &&
            GetWindowRect(desplazamiento, out var limitesBotones) ? limitesBotones.Rectangulo : Rectangle.Empty;
        for (int i = 0; i < pestanas.TabCount; i++)
        {
            Rectangle tab = pestanas.GetTabRect(i);
            Point borde = new(tab.Left + 1, tab.Top + 1);
            if (!franja.Contains(borde) || tab.Width < 10 || botones.Contains(pestanas.PointToScreen(borde))) continue;
            // La esquina exterior no pertenece a la tarjeta redondeada:
            // un borde blanco aquí revela que quedó dibujado el marco nativo.
            exige(antes.GetPixel(borde.X - franja.Left, borde.Y - franja.Top).ToArgb() == fondo.ToArgb(),
                "El acabado no debe conservar contornos nativos alrededor de las etiquetas: " + contexto + ".");
            bordes++;
        }
        exige(bordes > 0, "La comprobación debe incluir al menos una cabecera visible: " + contexto + ".");
    }

    private static void VerificarImpresion(TabControl pestanas, Action<bool, string> exige, string contexto)
    {
        Rectangle franja = Franja(pestanas);
        using var pantalla = Capturar(pestanas.RectangleToScreen(franja));
        using var impresion = new Bitmap(pestanas.ClientSize.Width, pestanas.ClientSize.Height, PixelFormat.Format32bppRgb);
        using (var grafico = Graphics.FromImage(impresion))
        {
            grafico.Clear(Color.Magenta);
            IntPtr hdc = grafico.GetHdc();
            try { Enviar(pestanas.Handle, 0x0318, hdc, new IntPtr(0x0004)); } // WM_PRINTCLIENT, PRF_CLIENT.
            finally { grafico.ReleaseHdc(hdc); }
        }
        int acento = MYG2027_TemaComercial.Azul.ToArgb(), barra = 0, muestras = 0, iguales = 0;
        int[] planos = { MYG2027_TemaComercial.Fondo.ToArgb(), MYG2027_TemaComercial.Superficie.ToArgb(),
            MYG2027_TemaComercial.SuperficieAlterna.ToArgb(), acento };
        for (int y = 0; y < franja.Height; y++)
            for (int x = 0; x < franja.Width; x++)
            {
                int colorPantalla = pantalla.GetPixel(x, y).ToArgb();
                int colorImpresion = impresion.GetPixel(x + franja.Left, y + franja.Top).ToArgb();
                if (colorImpresion == acento) barra++;
                // No comparar antialiasing de texto entre un DC de pantalla y
                // otro de impresión: sí las superficies y el indicador sólido.
                if (!planos.Contains(colorPantalla)) continue;
                muestras++;
                if (colorPantalla == colorImpresion) iguales++;
            }
        exige(barra > 10 && muestras > franja.Width && iguales >= muestras * .99,
            "WM_PRINTCLIENT debe reproducir el fondo moderno y el indicador visible: " + contexto + ".");
    }

    private static void MoverRaton(Control control, Point punto)
    {
        Cursor.Position = control.PointToScreen(punto);
        Enviar(control.Handle, 0x0200, IntPtr.Zero, Coordenadas(punto));
        Procesar();
    }

    private static void SalirRaton(Control control, Control foco)
    {
        Cursor.Position = foco.PointToScreen(new Point(8, 8));
        Enviar(control.Handle, 0x02A3, IntPtr.Zero, IntPtr.Zero); // WM_MOUSELEAVE.
        Procesar();
    }

    private static IntPtr Coordenadas(Point punto) => new(unchecked((punto.Y << 16) | (punto.X & 0xffff)));

    private static void Procesar(int milisegundos = 30)
    {
        var reloj = Stopwatch.StartNew();
        do { Application.DoEvents(); Thread.Sleep(5); } while (reloj.ElapsedMilliseconds < milisegundos);
        GdiFlush();
    }

    private static Bitmap Capturar(Rectangle region)
    {
        if (region.Width <= 0 || region.Height <= 0)
            throw new InvalidOperationException("La captura exige una región visible en pantalla.");
        var imagen = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppRgb);
        using var grafico = Graphics.FromImage(imagen);
        grafico.CopyFromScreen(region.Location, Point.Empty, imagen.Size);
        return imagen;
    }

    private static byte[] Pixeles(Bitmap imagen)
    {
        var bloqueo = imagen.LockBits(new Rectangle(Point.Empty, imagen.Size), ImageLockMode.ReadOnly, PixelFormat.Format32bppRgb);
        try
        {
            var pixeles = new byte[checked(imagen.Width * imagen.Height * 4)];
            for (int y = 0; y < imagen.Height; y++)
                Marshal.Copy(IntPtr.Add(bloqueo.Scan0, y * bloqueo.Stride), pixeles, y * imagen.Width * 4, imagen.Width * 4);
            for (int i = 3; i < pixeles.Length; i += 4) pixeles[i] = 0;
            return pixeles;
        }
        finally { imagen.UnlockBits(bloqueo); }
    }

    internal static double Contraste(Color a, Color b)
    {
        static double Canal(byte valor)
        {
            double v = valor / 255d;
            return v <= .04045 ? v / 12.92 : Math.Pow((v + .055) / 1.055, 2.4);
        }
        static double Luz(Color c) => .2126 * Canal(c.R) + .7152 * Canal(c.G) + .0722 * Canal(c.B);
        double x = Luz(a), y = Luz(b);
        return (Math.Max(x, y) + .05) / (Math.Min(x, y) + .05);
    }
}
