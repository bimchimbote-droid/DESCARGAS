using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Cliente real contra un transporte HTTP controlado; fixtures SQLite de dos obras.</summary>
internal static class CentralClienteCheck
{
    private static readonly Guid Usuario = Guid.Parse("29ef66eb-997d-4c8d-a10b-f6436f75c04b");
    private static readonly Guid Base = Guid.Parse("281baf5d-2302-4b7e-bff3-6f70e166fd5f");
    private static readonly Guid Vista = Guid.Parse("f2f9c294-9281-4943-a840-b71fd0780cf4");
    private static readonly Guid Legado = Guid.Parse("091476d3-41cd-445b-99e7-c416729ad4af");
    private const string Privado = "OTRA-OBRA-PRIVADA-285D68C2";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-central-cliente-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "origen.sqlite");
            var autorizada = MYGProyectoStorage.Nuevo("Obra autorizada central", "Presupuesto central");
            var privada = MYGProyectoStorage.Nuevo(Privado, "Presupuesto privado");
            MYGProyectoStorage.Guardar(ruta, autorizada); MYGProyectoStorage.Guardar(ruta, privada);
            string hash = Hash(ruta);
            var contenido = PaqueteNube.CrearContenido(autorizada, ruta, "obra");
            Exige(!contenido.GetRawText().Contains(Privado, StringComparison.Ordinal), "fixture debe contener solo la obra autorizada.");
            await MigracionYListado(contenido, autorizada.Id);
            await NuevaBaseDirecta(contenido, autorizada.Id);
            await AbrirFrioGuardarRevocar(contenido, autorizada.Id);
            await GuardarYAdministrarEnFrio(contenido, autorizada.Id);
            await RenovacionExacta(contenido, autorizada.Id);
            await RespuestasInvalidas(contenido, autorizada.Id);
            await ServidorAnterior(contenido, autorizada.Id);
            await CatalogosInvalidos(contenido, autorizada.Id);
            await CatalogosGlobalesAdicionales(contenido, autorizada.Id);
            Exige(Hash(ruta) == hash && MYGBaseDatos.ListarProyectos(ruta).Count == 2,
                "el cliente de migración no debe modificar el archivo de origen.");
            Console.WriteLine($"OK Base central cliente: {comprobaciones} comprobaciones de migración por RPC, listado, reapertura fría, sesiones, aislamiento, permisos y ausencia de servicio externo/Storage; HTTP simulado y SQLite real.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static async Task MigracionYListado(JsonElement contenido, string documento)
    {
        using var transporte = new Transporte(contenido, documento);
        using var cliente = await Conectar(transporte);
        Exige(cliente.ServicioBasesUrl is null && await cliente.AdmiteCentralAsync(),
            "Supabase central no debe necesitar ServicioBasesUrl.");
        Guid migracion = Guid.NewGuid();
        var estado = await cliente.IniciarMigracionCentralAsync(Base, 7, migracion,
            new[] { new DocumentoMigracionCentral(documento, "Obra autorizada central") });
        Exige(estado == new EstadoMigracionCentral(migracion, Base, 7, "preparando"), "iniciar debe confirmar sus mismas identidades y revisión.");
        await cliente.PrepararDocumentoCentralAsync(migracion, documento, contenido);
        await cliente.PrepararCatalogoCentralAsync(migracion, CatalogoFixture());
        Exige(transporte.Preparaciones == 1 && transporte.ManifestSoloIdentidades,
            "inicio debe enviar metadatos; preparar debe enviar una sola obra.");
        var central = await cliente.ActivarMigracionCentralAsync(migracion);
        Exige(central.Id == Base && central.EsCentralNativa && !central.EsObraMismaBase && central.Alcance == "base",
            "activar debe devolver la misma base, no una nueva publicación.");
        var catalogo = await cliente.ObtenerCatalogoCentralAsync(Base);
        Exige(catalogo.GetProperty("tablas")[0].GetProperty("Filas")[0][0].GetProperty("Valor").GetString() == "UNIDAD-NO-USADA",
            "el catálogo completo debe conservar filas que todavía no usa ninguna obra.");
        var lista = await cliente.ListarProyectosAsync();
        Exige(lista.Count == 3 && lista.Count(p => p.Id == Base) == 1 && lista.Single(p => p.Id == Vista).EsCentralNativa
            && !lista.Single(p => p.Id == Legado).EsCentralNativa,
            "el listado combinado debe conservar los legados y una sola cabecera de la base central.");
        var obras = await cliente.ListarObrasCentralAsync(Base);
        Exige(obras.Count == 1 && obras[0].BaseId == Base && obras[0].DocumentoId == documento,
            "listar obras debe conservar identidades de base/documento sin el archivo completo.");
        Exige(await cliente.EsObraMismaBaseAsync(Vista), "el sincronizador debe reconocer vistas centrales sin URL externa.");
        var permisos = new MYGPermisosModulos { Acu = true, Especificaciones = false, MetradosExcel = false, MetradosRevit = false };
        await cliente.CompartirConUsuarioMygAsync(Vista, "colaborador", "editor", permisos);
        await cliente.CambiarPermisosMiembroAsync(Vista, Usuario.ToString("D"), permisos);
        Exige(transporte.Permisos.Count == 2 && transporte.Permisos.All(p => p.EnumerateObject().Count() == 4
            && p.GetProperty("acu").GetBoolean() && !p.GetProperty("metrados_revit").GetBoolean()),
            "la gestión debe enviar los cuatro permisos explícitos incluido Revit deshabilitado.");
        var creada = await cliente.CrearObraCentralAsync(Base, documento, "Obra autorizada central", contenido);
        Exige(creada.EsCentralNativa && PaqueteNube.LeerDocumento(creada.Contenido).Id == documento,
            "crear obra debe devolver su contenido y vincularlo a la base central.");
        SinOtroServicio(transporte);
    }

    private static async Task AbrirFrioGuardarRevocar(JsonElement contenido, string documento)
    {
        using var transporte = new Transporte(contenido, documento);
        using var cliente = await Conectar(transporte);
        var abierto = await cliente.AbrirProyectoAsync(Vista);
        Exige(transporte.AperturasLegadas == 1 && abierto.EsCentralNativa && abierto.BaseId == Base,
            "una copia recién abierta debe descubrir MGN01 y resolver su ruta central.");
        Exige(!abierto.Contenido.GetRawText().Contains(Privado, StringComparison.Ordinal), "abrir no debe incluir otra obra.");
        var revision = await cliente.ConsultarRevisionProyectoAsync(Vista);
        Exige(revision.Revision == 1 && revision.EsCentralNativa, "la revisión debe proceder de la obra, no del SQLite original.");
        var operacion = Guid.NewGuid();
        var respuesta = await cliente.GuardarProyectoAsync(Vista, operacion, 1, contenido);
        Exige(respuesta.Estado == "aplicada" && respuesta.OperacionId == operacion && respuesta.Revision == 2,
            "guardar debe confirmar UUID y revisión de la obra.");
        int llamadas = transporte.Rutas.Count;
        await Rechaza(() => cliente.GuardarProyectoAsync(Vista, Guid.NewGuid(), 2,
            CambiarDocumento(contenido, "OTRO-DOCUMENTO")));
        Exige(transporte.Rutas.Count == llamadas, "no debe transmitir un documento distinto en la misma vista.");
        transporte.Revocado = true;
        var error = await Rechaza(() => cliente.AbrirProyectoAsync(Vista));
        Exige(error.AccesoDenegado && transporte.AperturasLegadas == 1,
            "revocar debe rechazar en central sin recurrir a Storage ni al protocolo legado.");
        SinOtroServicio(transporte);
    }

    private static async Task NuevaBaseDirecta(JsonElement contenido, string documento)
    {
        using var transporte = new Transporte(contenido, documento);
        using var cliente = await Conectar(transporte);
        Guid migracion = Guid.NewGuid();
        var estado = await cliente.CrearBaseCentralAsync(Base, "Base nueva comercial", migracion,
            new[] { new DocumentoMigracionCentral(documento, "Obra autorizada central") });
        Exige(estado == new EstadoMigracionCentral(migracion, Base, 1, "preparando"),
            "una base nueva debe comenzar en PostgreSQL con identidad durable y revisión uno.");
        await cliente.PrepararDocumentoCentralAsync(migracion, documento, contenido);
        await cliente.PrepararCatalogoCentralAsync(migracion, CatalogoFixture());
        var activada = await cliente.ActivarMigracionCentralAsync(migracion);
        Exige(activada.Id == Base && activada.Revision == 1 && activada.EsCentralNativa,
            "la publicación nueva debe activar su misma identidad central sin archivo previo.");
        SinOtroServicio(transporte);
    }

    private static async Task RenovacionExacta(JsonElement contenido, string documento)
    {
        using var transporte = new Transporte(contenido, documento) { PrimerGuardar401 = true };
        using var cliente = await Conectar(transporte);
        await cliente.ResolverCentralAsync(Vista);
        Guid operacion = Guid.NewGuid();
        var respuesta = await cliente.GuardarProyectoAsync(Vista, operacion, 1, contenido);
        Exige(respuesta.OperacionId == operacion && transporte.Refrescos == 1 && transporte.CuerposGuardados.Count == 2
            && transporte.CuerposGuardados[0].SequenceEqual(transporte.CuerposGuardados[1]),
            "renovar la sesión debe reenviar exactamente el cuerpo congelado y UUID original.");
        SinOtroServicio(transporte);
    }

    private static async Task GuardarYAdministrarEnFrio(JsonElement contenido, string documento)
    {
        using (var transporte = new Transporte(contenido, documento))
        using (var cliente = await Conectar(transporte))
        {
            var guardado = await cliente.GuardarProyectoAsync(Vista, Guid.NewGuid(), 1, contenido);
            Exige(guardado.Estado == "aplicada" && transporte.CuerposGuardados.Count == 1,
                "guardar desde una sesión nueva debe resolver MGN01 y usar la misma obra central.");
            SinOtroServicio(transporte);
        }
        using (var transporte = new Transporte(contenido, documento))
        using (var cliente = await Conectar(transporte))
        {
            await cliente.CompartirConUsuarioMygAsync(Vista, "colaborador", "editor", new MYGPermisosModulos
                { Acu = false, Especificaciones = true, MetradosExcel = false, MetradosRevit = false });
            Exige(transporte.Permisos.Count == 1 && transporte.Permisos[0].EnumerateObject().Count() == 4,
                "la administración en frío debe resolver la obra y enviar su máscara completa sin URL externa.");
            SinOtroServicio(transporte);
        }
    }

    private static async Task RespuestasInvalidas(JsonElement contenido, string documento)
    {
        foreach (string fallo in new[] { "marcador-falso", "sin-vista", "con-sqlite", "documento-ajeno" })
        {
            using var transporte = new Transporte(contenido, documento) { RespuestaInvalida = fallo };
            using var cliente = await Conectar(transporte);
            await Rechaza(() => cliente.ResolverCentralAsync(Vista));
            Exige(transporte.AperturasLegadas == 0, "una respuesta central inválida no debe consultar otro almacenamiento.");
        }
    }

    private static async Task ServidorAnterior(JsonElement contenido, string documento)
    {
        using var transporte = new Transporte(contenido, documento) { FaltaMigracion = true };
        using var cliente = await Conectar(transporte);
        Exige(!await cliente.AdmiteCentralAsync() && await cliente.ResolverCentralAsync(Legado) is null,
            "un servidor anterior debe indicar capacidad ausente y conservar legados.");
        var error = await Rechaza(() => cliente.IniciarMigracionCentralAsync(Base, 7, Guid.NewGuid(),
            new[] { new DocumentoMigracionCentral(documento, "Obra autorizada central") }));
        Exige(error.Codigo == "MYG_CENTRAL_NO_INSTALADA" && transporte.Preparaciones == 0,
            "sin migración SQL debe explicar la actualización sin subir datos ni pedir otro servicio.");
        transporte.FaltaMigracion = false;
        Exige(await cliente.AdmiteCentralAsync(), "instalar la migración debe poder detectarse sin reiniciar MYG.");
    }

    private static async Task CatalogosInvalidos(JsonElement contenido, string documento)
    {
        foreach (string error in new[] { "documentos", "tabla-privada", "version", "recurso-externo", "fila-invalida" })
        {
            using var transporte = new Transporte(contenido, documento) { CatalogoError = error };
            using var cliente = await Conectar(transporte);
            await Rechaza(() => cliente.ObtenerCatalogoCentralAsync(Base));
            SinOtroServicio(transporte);
        }
        using (var transporte = new Transporte(contenido, documento) { Revocado = true })
        using (var cliente = await Conectar(transporte))
        {
            var error = await Rechaza(() => cliente.ObtenerCatalogoCentralAsync(Base));
            Exige(error.AccesoDenegado, "el catálogo global debe exigir permiso del propietario actual.");
            SinOtroServicio(transporte);
        }
        using (var transporte = new Transporte(contenido, documento))
        using (var cliente = await Conectar(transporte))
        {
            int antes = transporte.Rutas.Count;
            var privado = System.Text.Json.Nodes.JsonNode.Parse(CatalogoFixture().GetRawText())!;
            privado["tablas"]![0]!["Nombre"] = "myg_info";
            await Rechaza(() => cliente.PrepararCatalogoCentralAsync(Guid.NewGuid(), JsonSerializer.SerializeToElement(privado)));
            Exige(transporte.Rutas.Count == antes, "un catálogo con tablas privadas debe rechazarse antes de enviar datos.");
        }
    }

    private static JsonElement CatalogoFixture() => JsonSerializer.SerializeToElement(new
    {
        formato = "MYG_CATALOGO_BASE", version = 1,
        tablas = new[] { new { Nombre = "catalogo_unidad", Columnas = new[] { "codigo" },
            Filas = new[] { new[] { new { Tipo = "texto", Valor = "UNIDAD-NO-USADA" } } } } },
        recursos = Array.Empty<object>()
    });

    private static async Task CatalogosGlobalesAdicionales(JsonElement contenido, string documento)
    {
        string[] adicionales = ["unidad_map", "unidad_tipocosto", "unidad_tipocostonew", "horario", "horario_ex", "feriado", "excepcion",
            "plantilla_partida", "titulo_plantilla", "costo_unitarioplantilla", "precio_producto", "subclase_costo"];
        foreach (string tabla in adicionales)
        {
            using var transporte = new Transporte(contenido, documento);
            using var cliente = await Conectar(transporte);
            Guid migracion = Guid.NewGuid();
            await cliente.CrearBaseCentralAsync(Base, "Base nueva comercial", migracion,
                new[] { new DocumentoMigracionCentral(documento, "Obra autorizada central") });
            var catalogo = System.Text.Json.Nodes.JsonNode.Parse(CatalogoFixture().GetRawText())!;
            catalogo["tablas"]![0]!["Nombre"] = tabla;
            await cliente.PrepararCatalogoCentralAsync(migracion, JsonSerializer.SerializeToElement(catalogo));
            var recuperado = await cliente.ObtenerCatalogoCentralAsync(Base);
            Exige(recuperado.GetProperty("tablas")[0].GetProperty("Nombre").GetString() == tabla,
                "el catálogo privado debe admitir la tabla global reconocida " + tabla + ".");
            SinOtroServicio(transporte);
        }
    }

    private static JsonElement CambiarDocumento(JsonElement contenido, string id)
    {
        var objeto = System.Text.Json.Nodes.JsonNode.Parse(contenido.GetRawText())!.AsObject();
        objeto["documento"]!["Id"] = id;
        return JsonSerializer.SerializeToElement(objeto);
    }

    private static async Task<ClienteSupabase> Conectar(Transporte transporte)
    {
        var cliente = new ClienteSupabase("https://central-qa.supabase.co", "sb_publishable_central_qa", transporte);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        return cliente;
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error) { comprobaciones++; return error; }
        throw new InvalidOperationException("Base central cliente: faltó el rechazo esperado.");
    }

    private static void SinOtroServicio(Transporte t) => Exige(t.Rutas.All(r => r.Host == "central-qa.supabase.co"
        && !r.AbsolutePath.Contains("/storage/", StringComparison.Ordinal)
        && !r.AbsolutePath.Contains("sqlite", StringComparison.Ordinal) && r.AbsolutePath != "/health")
        && !t.Rutas.Any(r => r.AbsolutePath.Contains("myg_nube_crear", StringComparison.Ordinal)),
        "no debe contactar otro servicio, subir Storage, crear publicaciones ni transferir el SQLite completo.");

    private static void Exige(bool condicion, string detalle)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException("Base central cliente: " + detalle); }
    private static string Hash(string ruta)
    { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }

    private sealed class Transporte(JsonElement contenido, string documento) : HttpMessageHandler
    {
        internal bool FaltaMigracion, Revocado, PrimerGuardar401, ManifestSoloIdentidades;
        internal string RespuestaInvalida = "";
        internal string CatalogoError = "";
        internal int AperturasLegadas, Preparaciones, Refrescos;
        internal List<Uri> Rutas { get; } = new();
        internal List<JsonElement> Permisos { get; } = new();
        internal List<byte[]> CuerposGuardados { get; } = new();
        private Guid migracion;
        private long revisionBase = 7;
        private JsonElement? catalogo;
        private long revision = 1;
        private string token = "central_acceso_sintetico";

        private Dictionary<string, object?> Metadata(bool esBase = false, bool conContenido = false)
        {
            var meta = new Dictionary<string, object?>
            {
                ["id"] = esBase ? Base : Vista, ["codigo"] = "MYG-CENTRAL-QA", ["nombre"] = "Obra autorizada central",
                ["rol"] = "propietario", ["revision"] = esBase ? revisionBase : revision, ["alcance"] = esBase ? "base" : "obra",
                ["central_nativa"] = RespuestaInvalida == "marcador-falso" ? false : true,
                ["permisos_modulos"] = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true }
            };
            if (!esBase)
            {
                if (RespuestaInvalida != "sin-vista") meta["vista_base"] = true;
                meta["base_id"] = Base; meta["documento_id"] = RespuestaInvalida == "documento-ajeno" ? " " : documento;
            }
            if (RespuestaInvalida == "con-sqlite") meta["archivo_sqlite"] = new { ruta = "privado.sqlite" };
            if (conContenido) meta["contenido"] = contenido;
            return meta;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            var uri = request.RequestUri!; Rutas.Add(uri);
            if (uri.Host != "central-qa.supabase.co") throw new InvalidOperationException("Cliente central contactó otro servicio.");
            if (uri.AbsolutePath == "/auth/v1/token")
            {
                if (uri.Query == "?grant_type=refresh_token") { Refrescos++; token += "_renovado"; }
                return Json(new { access_token = token, refresh_token = "refresco_central_sintetico", expires_in = 3600, user = new { id = Usuario } });
            }
            Exige(request.Headers.Authorization?.Parameter == token && request.Headers.Contains("apikey"),
                "cada RPC debe usar la sesión de su propia cuenta.");
            string funcion = uri.AbsolutePath.Split('/').Last();
            byte[] bytes = await request.Content!.ReadAsByteArrayAsync(ct);
            using var json = JsonDocument.Parse(bytes); var p = json.RootElement;
            if (FaltaMigracion && funcion.StartsWith("myg_central_", StringComparison.Ordinal))
                return Json(new { code = "PGRST202", message = "función ausente QA" }, HttpStatusCode.NotFound);
            if (funcion == "myg_central_capacidades") return Json(new { version = 1 });
            if (funcion == "myg_central_iniciar")
            {
                migracion = p.GetProperty("p_migracion").GetGuid();
                var docs = p.GetProperty("p_documentos");
                ManifestSoloIdentidades = docs.GetArrayLength() == 1 && docs[0].EnumerateObject().Count() == 2
                    && docs[0].GetProperty("documento_id").GetString() == documento;
                return Json(new { estado = "preparando", migracion_id = migracion, base_id = Base, revision = 7 });
            }
            if (funcion == "myg_central_crear_base")
            {
                migracion = p.GetProperty("p_migracion").GetGuid(); revisionBase = 1;
                Exige(p.GetProperty("p_nombre").GetString() == "Base nueva comercial"
                    && p.GetProperty("p_documentos").GetArrayLength() == 1,
                    "crear base debe transportar nombre e identidades, sin SQLite.");
                return Json(new { estado = "preparando", migracion_id = migracion, base_id = Base, revision = 1 });
            }
            if (funcion == "myg_central_preparar")
            {
                Preparaciones++;
                Exige(p.GetProperty("p_migracion").GetGuid() == migracion
                    && PaqueteNube.LeerDocumento(p.GetProperty("p_contenido")).Id == documento
                    && !p.GetProperty("p_contenido").GetRawText().Contains(Privado, StringComparison.Ordinal),
                    "preparar documento debe transportar exactamente la obra prevista.");
                return Json(new { estado = "preparado", documento_id = documento });
            }
            if (funcion == "myg_central_preparar_catalogo")
            {
                Exige(p.GetProperty("p_migracion").GetGuid() == migracion,
                    "el catálogo debe prepararse en la misma migración durable.");
                catalogo = p.GetProperty("p_contenido").Clone();
                return Json(new { estado = "preparado" });
            }
            if (funcion == "myg_central_catalogo")
            {
                if (Revocado) return Json(new { code = "42501", message = "Solo propietario QA" }, HttpStatusCode.Forbidden);
                var nodo = System.Text.Json.Nodes.JsonNode.Parse((catalogo ?? CatalogoFixture()).GetRawText())!;
                if (CatalogoError == "documentos") nodo["documentos"] = new System.Text.Json.Nodes.JsonArray();
                if (CatalogoError == "tabla-privada") nodo["tablas"]![0]!["Nombre"] = "myg_info";
                if (CatalogoError == "version") nodo["version"] = 2;
                if (CatalogoError == "fila-invalida") nodo["tablas"]![0]!["Filas"]![0] = new System.Text.Json.Nodes.JsonArray();
                if (CatalogoError == "recurso-externo") nodo["recursos"] = JsonSerializer.SerializeToNode(new[]
                    { new { Referencia = "MYG_RECURSO_QA", Nombre = "archivo", Sha256 = new string('a', 64), Base64 = "", Almacen = "ajeno/ruta" } });
                return Json(nodo);
            }
            if (funcion == "myg_central_activar") return Json(Metadata(esBase: true));
            if (funcion == "myg_nube_listar") return Json(new object[] { Metadata(esBase: true), Metadata(), new
                { id = Legado, codigo = "MYG-LEGADO", nombre = "Anterior", rol = "editor", revision = 2, alcance = "obra" } });
            if (funcion == "myg_central_obras") return Json(new[] { Metadata() });
            if (funcion == "myg_central_crear_obra") return Json(Metadata(conContenido: true));
            if (funcion == "myg_nube_abrir")
            {
                AperturasLegadas++;
                return Json(new { code = "MGN01", message = "MYG_CENTRAL_NATIVA" }, HttpStatusCode.BadRequest);
            }
            if (funcion is "myg_nube_guardar" or "myg_nube_compartir_usuario")
                return Json(new { code = "MGN01", message = "MYG_CENTRAL_NATIVA" }, HttpStatusCode.BadRequest);
            if (funcion == "myg_central_resolver") return Json(Metadata());
            if (funcion == "myg_central_abrir") return Revocado
                ? Json(new { code = "42501", message = "Acceso retirado QA" }, HttpStatusCode.Forbidden)
                : Json(Metadata(conContenido: true));
            if (funcion == "myg_central_guardar")
            {
                CuerposGuardados.Add(bytes);
                if (PrimerGuardar401 && CuerposGuardados.Count == 1)
                    return Json(new { message = "sesión vencida QA" }, HttpStatusCode.Unauthorized);
                Exige(p.GetProperty("p_id").GetGuid() == Vista && p.GetProperty("p_revision").GetInt64() == 1,
                    "guardar debe conservar la identidad y revisión por obra.");
                revision = 2;
                return Json(new { estado = "aplicada", revision, operacion_id = p.GetProperty("p_operacion").GetGuid(), contenido = p.GetProperty("p_contenido") });
            }
            if (funcion is "myg_base_compartir_usuario" or "myg_base_permisos")
            {
                Permisos.Add(p.GetProperty("p_permisos_modulos").Clone());
                return Json(new { estado = "actualizada" });
            }
            throw new InvalidOperationException("Base central cliente: RPC inesperada " + funcion);
        }

        private static HttpResponseMessage Json(object? valor, HttpStatusCode status = HttpStatusCode.OK) => new(status)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
