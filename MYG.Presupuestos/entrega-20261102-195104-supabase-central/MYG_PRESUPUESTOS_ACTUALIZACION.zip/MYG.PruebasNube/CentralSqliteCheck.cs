using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class CentralSqliteCheck
{
    private static readonly Guid Usuario = Guid.Parse("b77a1a3b-a953-4c4e-a6f1-a2238631541b");
    private static readonly Guid Base = Guid.Parse("37a33eba-c1e4-4814-aa44-b972fc94a48d");
    private const string Servidor = "https://central-sqlite-qa.supabase.co";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-central-sqlite-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta); comprobaciones = 0;
        try
        {
            string ruta = Path.Combine(carpeta, "dos-obras.sqlite");
            var norte = MYGProyectoStorage.Nuevo("Norte central", "Presupuesto norte");
            var sur = MYGProyectoStorage.Nuevo("Sur privado central", "Presupuesto sur");
            MYGProyectoStorage.Guardar(ruta, norte); MYGProyectoStorage.Guardar(ruta, sur);
            string hashInicial = Hash(ruta);
            var contenidoNorte = BaseCentralNube.CrearContenidoEstricto(ruta, norte.Id);
            var contenidoSur = BaseCentralNube.CrearContenidoEstricto(ruta, sur.Id);
            var catalogo = BaseCentralNube.CrearCatalogoEstricto(ruta);
            Exige(!contenidoNorte.GetRawText().Contains(sur.Nombre, StringComparison.Ordinal), "una proyección no lleva la otra obra");
            Exige(PaqueteNube.LeerDocumento(contenidoNorte).Id == norte.Id && Hash(ruta) == hashInicial, "preparar no escribe la base original");
            Exige(!BaseCentralNube.EsBase(ruta), "una base anterior no se confunde con central");
            var obras = new[] { Obra(norte, contenidoNorte), Obra(sur, contenidoSur) };
            using var transporte = new Transporte(obras, catalogo);
            using var cliente = new ClienteSupabase(Servidor, "sb_publishable_central_sqlite_qa", transporte);
            await cliente.IniciarSesionAsync("qa@central.example", "clave_sintetica");

            // Una edición producida mientras la migración viajaba se conserva
            // como pendiente contra la revisión que realmente se confirmó.
            norte.Nombre = "Norte editada después de preparar"; MYGProyectoStorage.Guardar(ruta, norte);
            BaseCentralNube.ActivarLocal(cliente, ruta, Base, obras);
            Exige(BaseCentralNube.LeerBase(ruta) == new VinculoBaseCentral(Base, Servidor, Usuario.ToString("D")), "el vínculo central conserva cuenta y base");
            var vinculo = MYGColaboracionLocal.Leer(ruta, norte.Id)!;
            Exige(vinculo.Pendiente is not null && MYGBaseDatos.LeerProyecto(ruta, norte.Id).Nombre == norte.Nombre,
                "activar conserva y encola el borrador posterior a la preparación");
            Exige(MYGColaboracionLocal.Leer(ruta, sur.Id)!.Pendiente is null, "la obra no editada queda confirmada sin pendientes artificiales");
            Guid pendiente = vinculo.Pendiente!.Id;
            BaseCentralNube.ActivarLocal(cliente, ruta, Base, obras);
            Exige(MYGColaboracionLocal.Leer(ruta, norte.Id)!.Pendiente!.Id == pendiente, "repetir activación no sustituye UUID ni cuerpo pendiente");
            string hashActivado = Hash(ruta);
            Rechaza(() => BaseCentralNube.ActivarLocal(cliente, ruta, Guid.NewGuid(), obras), "rechazar otra base");
            Exige(Hash(ruta) == hashActivado, "un rechazo no cambia los datos locales");
            Rechaza(() => BaseCentralNube.ActivarLocal(cliente, ruta, Base, obras.Take(1).ToArray()), "rechazar activación parcial");
            Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 2, "una activación parcial no elimina la otra obra");

            string nueva = Path.Combine(carpeta, "descarga-central.sqlite");
            await BaseCentralNube.CrearCopiaAsync(cliente, Base, nueva);
            Exige(BaseCentralNube.EsBase(nueva) && MYGBaseDatos.ListarProyectos(nueva).Count == 2, "crear copia local obtiene las obras de la misma base central");
            Exige(MYGColaboracionLocal.Leer(nueva, norte.Id)!.ProyectoId == obras[0].Id
                && MYGColaboracionLocal.Leer(nueva, sur.Id)!.ProyectoId == obras[1].Id, "cada obra conserva su propia revisión y cola");
            Exige(MYGColaboracionLocal.Leer(nueva, norte.Id)!.Pendiente is null
                && MYGColaboracionLocal.Leer(nueva, sur.Id)!.Pendiente is null, "la descarga no inventa ediciones locales");
            string hashNueva = Hash(nueva);
            await RechazaAsync(() => BaseCentralNube.CrearCopiaAsync(cliente, Base, nueva), "no sobrescribir descarga existente");
            Exige(Hash(nueva) == hashNueva, "la descarga existente conserva sus bytes");
            Exige(transporte.Rutas.All(x => x.StartsWith("/auth/", StringComparison.Ordinal)
                || x.StartsWith("/rest/v1/rpc/myg_central_", StringComparison.Ordinal)), "abrir central no solicita Storage ni otro servicio");

            string extension = Path.Combine(carpeta, "extension.sqlite");
            MYGProyectoStorage.Guardar(extension, MYGProyectoStorage.Copia(sur));
            Sql(extension, "CREATE TABLE mi_extension_privada(id INTEGER PRIMARY KEY, contenido TEXT); INSERT INTO mi_extension_privada VALUES(1,'NO OMITIR');");
            string hashExtension = Hash(extension);
            Rechaza(() => BaseCentralNube.CrearContenidoEstricto(extension, sur.Id), "rechazar extensión con datos");
            Exige(Hash(extension) == hashExtension, "rechazar extensión no cambia la base");
            Sql(extension, "DROP TABLE mi_extension_privada; ALTER TABLE myg_proyecto ADD COLUMN campo_extension TEXT;");
            Rechaza(() => BaseCentralNube.CrearContenidoEstricto(extension, sur.Id), "rechazar columna desconocida sin omisión silenciosa");
            await RecuperacionNoAdoptaRevisionAjena(carpeta, obras, catalogo);
            Console.WriteLine($"OK Base central SQLite: {comprobaciones} comprobaciones de proyección, activación recuperable, cola por obra, descarga multobra y extensiones; SQLite real y HTTP simulado.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static async Task RecuperacionNoAdoptaRevisionAjena(string carpeta, IReadOnlyList<ProyectoNube> congeladas, JsonElement catalogo)
    {
        string ruta = Path.Combine(carpeta, "recuperar-activacion.sqlite");
        foreach (var obra in congeladas) MYGProyectoStorage.Guardar(ruta, PaqueteNube.LeerDocumento(obra.Contenido));
        var local = MYGBaseDatos.LeerProyecto(ruta, congeladas[0].DocumentoId!);
        local.Nombre = "Borrador local posterior al envío"; MYGProyectoStorage.Guardar(ruta, local);
        var remoto = PaqueteNube.LeerDocumento(congeladas[0].Contenido); remoto.Nombre = "Edición remota posterior al ACK";
        var actuales = new[]
        {
            congeladas[0] with { Revision = 2, Contenido = PaqueteNube.ActualizarDocumento(congeladas[0].Contenido, remoto) },
            congeladas[1]
        };
        using var transporte = new Transporte(actuales, catalogo);
        using var cliente = new ClienteSupabase(Servidor, "sb_publishable_central_sqlite_qa", transporte);
        await cliente.IniciarSesionAsync("qa@central.example", "clave_sintetica");
        string hashSinIntento = Hash(ruta);
        await RechazaAsync(() => BaseCentralNube.RecuperarActivacionAsync(cliente, ruta, Base), "no adoptar borradores sin su base congelada");
        Exige(Hash(ruta) == hashSinIntento && !BaseCentralNube.EsBase(ruta), "sin manifiesto no se altera la copia ni se marca como confirmada");
        string intento = ruta + ".central"; Directory.CreateDirectory(intento);
        var documentos = new List<object>();
        for (int i = 0; i < congeladas.Count; i++)
        {
            string nombre = "obra-" + i + ".json"; string archivo = Path.Combine(intento, nombre);
            File.WriteAllText(archivo, congeladas[i].Contenido.GetRawText());
            documentos.Add(new { DocumentoId = congeladas[i].DocumentoId, Nombre = congeladas[i].Nombre, Archivo = nombre, Sha256 = Hash(archivo) });
        }
        string rutaCatalogo = Path.Combine(intento, "catalogo.json"); File.WriteAllText(rutaCatalogo, catalogo.GetRawText());
        File.WriteAllText(Path.Combine(intento, "intento.json"), JsonSerializer.Serialize(new
        {
            Migracion = Guid.NewGuid(), BaseId = Base, Servidor, Usuario = Usuario.ToString("D"), Revision = 7,
            HashOrigen = new string('A', 64), Documentos = documentos,
            Catalogo = new { Archivo = "catalogo.json", Sha256 = Hash(rutaCatalogo) }
        }));
        await BaseCentralNube.RecuperarActivacionAsync(cliente, ruta, Base);
        var vinculo = MYGColaboracionLocal.Leer(ruta, local.Id)!;
        Exige(vinculo.Revision == 1 && vinculo.Pendiente?.RevisionBase == 1,
            "un borrador de la migración conserva revisión base 1 aunque otro usuario ya confirmó la 2");
        Exige(MYGColaboracionLocal.ImportarDocumento(vinculo.JsonConfirmado).Nombre == congeladas[0].Nombre,
            "la versión confirmada local procede del paquete congelado, no de la edición ajena posterior");
        Exige(MYGBaseDatos.LeerProyecto(ruta, local.Id).Nombre == local.Nombre,
            "recuperar el ACK conserva el borrador posterior sin sobrescribirlo con la edición remota");
    }

    private static ProyectoNube Obra(MYGProyectoDocumento doc, JsonElement contenido) => new(Guid.NewGuid(), "MYG-CENTRAL-QA", doc.Nombre,
        "propietario", 1, "obra", contenido)
    {
        BaseId = Base, DocumentoId = doc.Id, EsCentralNativa = true,
        PermisosModulos = new() { Acu = true, Especificaciones = true, MetradosExcel = true, MetradosRevit = true, MetradosRevitDisponible = true }
    };

    private sealed class Transporte(IReadOnlyList<ProyectoNube> obras, JsonElement catalogo) : HttpMessageHandler
    {
        internal List<string> Rutas { get; } = new();
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage q, CancellationToken ct)
        {
            string ruta = q.RequestUri!.AbsolutePath; Rutas.Add(ruta);
            if (ruta == "/auth/v1/token") return Respuesta(new { access_token = "acceso_central_sintetico", refresh_token = "refresco_qa", expires_in = 3600, user = new { id = Usuario } });
            if (ruta == "/rest/v1/rpc/myg_central_capacidades") return Respuesta(new { version = 1 });
            if (ruta == "/rest/v1/rpc/myg_central_resolver") return Respuesta(new
            { id = Base, codigo = "MYG-BASE-CENTRAL", nombre = "Base central QA", rol = "propietario", revision = 1, alcance = "base", central_nativa = true,
                permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true } });
            if (ruta == "/rest/v1/rpc/myg_central_obras") return Respuesta(obras.Select(x => Descriptor(x, false)).ToArray());
            if (ruta == "/rest/v1/rpc/myg_central_catalogo") return Respuesta(catalogo);
            if (ruta == "/rest/v1/rpc/myg_central_abrir")
            {
                using var cuerpo = JsonDocument.Parse(await q.Content!.ReadAsStringAsync(ct));
                return Respuesta(Descriptor(obras.Single(x => x.Id == cuerpo.RootElement.GetProperty("p_id").GetGuid()), true));
            }
            throw new InvalidOperationException("Ruta inesperada: " + ruta);
        }
        private static object Descriptor(ProyectoNube x, bool contenido)
        {
            var d = new Dictionary<string, object?>
            {
                ["id"] = x.Id, ["codigo"] = x.Codigo, ["nombre"] = x.Nombre, ["rol"] = x.Rol, ["revision"] = x.Revision, ["alcance"] = x.Alcance,
                ["vista_base"] = true, ["base_id"] = x.BaseId, ["documento_id"] = x.DocumentoId, ["central_nativa"] = true,
                ["permisos_modulos"] = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true }
            };
            if (contenido) d["contenido"] = x.Contenido;
            return d;
        }
        private static HttpResponseMessage Respuesta(object x) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(x), Encoding.UTF8, "application/json") };
    }

    private static void Sql(string ruta, string sql)
    { using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()); c.Open(); using var q = c.CreateCommand(); q.CommandText = sql; q.ExecuteNonQuery(); }
    private static string Hash(string ruta) { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }
    private static void Exige(bool condicion, string texto) { comprobaciones++; if (!condicion) throw new InvalidOperationException("Base central SQLite: " + texto); }
    private static void Rechaza(Action accion, string texto) { try { accion(); } catch (Exception e) when (e is InvalidDataException or InvalidOperationException or IOException) { comprobaciones++; return; } throw new InvalidOperationException("Base central SQLite: no rechazó " + texto); }
    private static async Task RechazaAsync(Func<Task> accion, string texto) { try { await accion(); } catch (Exception e) when (e is InvalidDataException or InvalidOperationException or IOException) { comprobaciones++; return; } throw new InvalidOperationException("Base central SQLite: no rechazó " + texto); }
}
