using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Cliente y SQLite reales contra los RPC de PostgreSQL reales. Solo
/// Auth y transporte HTTP se sustituyen por un puente local a psql.</summary>
internal static class CentralIntegracionCheck
{
    private static readonly Guid Propietario = Guid.Parse("eee10000-0000-0000-0000-000000000001");
    private static readonly Guid Colaborador = Guid.Parse("eee10000-0000-0000-0000-000000000002");
    private static readonly Guid Base = Guid.Parse("eee10000-0000-0000-0000-000000000003");
    private const string Servidor = "https://integracion-central-qa.supabase.co";
    private const string Privado = "OTRA-OBRA-NO-ENTREGAR-EEE1";
    private const string CatalogoPrivado = "CATALOGO-PRIVADO-NO-ENTREGAR-EEE1";
    private static int comprobaciones;

    internal static async Task RunAsync(string contenedor)
    {
        if (!Regex.IsMatch(contenedor, "^[a-zA-Z0-9][a-zA-Z0-9_.-]{5,127}$"))
            throw new ArgumentException("Indique el contenedor PostgreSQL desechable creado por Probar-CentralIntegracion.sh.");
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-central-integracion-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        var sql = new PostgreSqlLocal(contenedor);
        using var redPropietario = new Puente(sql, Propietario);
        using var redColaborador = new Puente(sql, Colaborador);
        try
        {
            string ruta = Path.Combine(carpeta, "base-dos-obras.sqlite");
            var norte = MYGProyectoStorage.Nuevo("Obra autorizada integración", "Presupuesto norte");
            var sur = MYGProyectoStorage.Nuevo(Privado, "Presupuesto sur privado");
            MYGProyectoStorage.Guardar(ruta, norte); MYGProyectoStorage.Guardar(ruta, sur);
            Sqlite(ruta, "INSERT INTO catalogo_unidad(id,simbolo,descripcion) VALUES('QA-ORFANA','qa-or','" + CatalogoPrivado + "')");
            string instantanea = Path.Combine(carpeta, "publicada.sqlite");
            CopiaSqliteNube.CrearSnapshot(ruta, instantanea);
            string hash = Hash(instantanea).ToLowerInvariant(); long bytes = new FileInfo(instantanea).Length;
            string objeto = $"{Propietario:D}/{Base:N}/{hash}.sqlite";
            await sql.Ejecutar($"INSERT INTO myg_nube_privado.identidades_verificadas VALUES({Literal(Propietario.ToString("D"))}::uuid,'qa_integracion_dueno',true),({Literal(Colaborador.ToString("D"))}::uuid,'qa_integracion_colaborador',true); "
                + $"SET ROLE authenticated; SET request.jwt.claim.sub='{Propietario:D}'; "
                + $"INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('myg-nube-sqlite',{Literal(objeto)},jsonb_build_object('size',{bytes})); "
                + $"SELECT public.myg_nube_sqlite_crear('{Base:D}','Base integración real','base',{Literal(norte.Id)},{Literal(objeto)},'{hash}',{bytes});");
            using var propietario = await Conectar(redPropietario);
            using var colaborador = await Conectar(redColaborador);
            var remoto = await propietario.AbrirSqliteAsync(Base);
            Exige(remoto.Archivo.Sha256 == hash && remoto.Proyecto.Id == Base, "SQLite remoto inicial debe conservar hash e identidad.");
            CopiaSqliteNube.Vincular(ruta, remoto, propietario);
            // Asigna un permiso antes de migrar para demostrar que no se crean
            // nuevas identidades ni se pierden los accesos ya concedidos.
            var vistaPrevia = await redPropietario.Rpc("myg_base_registrar", new { p_base = Base, p_documento = norte.Id, p_nombre = norte.Nombre });
            Guid vistaId = vistaPrevia.GetProperty("id").GetGuid();
            await redPropietario.Rpc("myg_base_compartir_usuario", new
            {
                p_id = vistaId, p_usuario_myg = "qa_integracion_colaborador", p_rol = "editor",
                p_permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true }
            });
            string contadores = await sql.Ejecutar("SELECT jsonb_build_array((SELECT count(*) FROM public.myg_nube_proyectos),(SELECT count(*) FROM storage.objects),(SELECT count(*) FROM myg_nube_privado.sqlite_revisiones))::text;");
            int solicitudesAntesPreparar = redPropietario.Rutas.Count;
            string hashAntesPreparar = Hash(ruta);
            try
            {
                await BaseCentralNube.PrepararMigracionAsync(propietario, ruta,
                    remoto with { Archivo = remoto.Archivo with { Sha256 = new string('0', 64) } });
                throw new Exception("La integración aceptó una preparación cuyo hash no coincide con la nube.");
            }
            catch (InvalidOperationException)
            {
                Exige(redPropietario.Rutas.Count == solicitudesAntesPreparar,
                    "un hash de origen incorrecto debe rechazarse antes de enviar cualquier RPC.");
                Exige(Hash(ruta) == hashAntesPreparar && !BaseCentralNube.EsBase(ruta),
                    "una preparación rechazada debe conservar el origen y su vínculo anterior.");
                Exige(!File.Exists(Path.Combine(ruta + ".central", "intento.json")),
                    "un rechazo previo al manifiesto no debe dejar un intento listo para enviar datos incorrectos.");
            }
            redPropietario.PerderPrimerAckActivacion = true;
            try
            {
                await BaseCentralNube.PrepararMigracionAsync(propietario, ruta, remoto);
                throw new InvalidOperationException("La integración no simuló la pérdida de ACK de activación.");
            }
            catch (NubeException error) when (error.EsErrorDeConexion)
            {
                Exige(!BaseCentralNube.EsBase(ruta) && File.Exists(CopiaSqliteNube.RutaEstado(ruta))
                    && (await propietario.ResolverCentralAsync(Base))?.EsCentralNativa == true,
                    "un ACK perdido debe conservar el vínculo previo mientras la activación SQL ya está confirmada.");
            }
            var obras = await BaseCentralNube.RecuperarActivacionAsync(propietario, ruta, Base);
            Exige(Directory.EnumerateDirectories(ruta + ".central", "preparacion-interrumpida-*").Any(),
                "reanudar con el hash correcto debe archivar la preparación no enviada y continuar sin intervención manual.");
            Exige(obras.Count == 2 && obras.Single(o => o.DocumentoId == norte.Id).Id == vistaId
                && BaseCentralNube.LeerBase(ruta)?.BaseId == Base, "migración real debe activar dos obras conservando UUID base/vista y vínculo local.");
            Exige(!CopiaSqliteNube.EsBase(ruta) && CopiaSqliteNube.LeerVinculo(ruta, norte.Id) is null,
                "una base activada no debe seguir enviando el binario antiguo.");
            Exige(obras.All(o => MYGColaboracionLocal.Leer(ruta, o.DocumentoId!)!.Pendiente is null),
                "migrar no debe inventar cambios ni colas en las obras confirmadas.");
            var catalogo = await propietario.ObtenerCatalogoCentralAsync(Base);
            Exige(catalogo.GetRawText().Contains(CatalogoPrivado, StringComparison.Ordinal),
                "la migración debe conservar el catálogo sin referencias en el ámbito privado de su propietario.");
            await Denegado(() => colaborador.ObtenerCatalogoCentralAsync(Base),
                "un permiso sobre una obra no concede el catálogo privado completo de la base.");
            string recuperada = Path.Combine(carpeta, "propietario-recuperada.sqlite");
            await BaseCentralNube.CrearCopiaAsync(propietario, Base, recuperada);
            Exige(Sqlite(recuperada, "SELECT descripcion FROM catalogo_unidad WHERE id='QA-ORFANA'") == CatalogoPrivado,
                "la reconstrucción del propietario debe conservar también las unidades sin uso.");
            var privada = obras.Single(o => o.DocumentoId == sur.Id);
            var surAnterior = await propietario.AbrirObraCentralAsync(privada.Id);
            string firmaSur = PaqueteNube.FirmaDatosCompartidos(surAnterior.Contenido);

            var abierto = await colaborador.AbrirProyectoAsync(vistaId);
            Exige(abierto.EsCentralNativa && !abierto.Contenido.GetRawText().Contains(Privado, StringComparison.Ordinal)
                && !abierto.Contenido.GetRawText().Contains(CatalogoPrivado, StringComparison.Ordinal),
                "apertura fría debe resolver protocolo central sin entregar la otra obra.");
            var lista = await colaborador.ListarProyectosAsync();
            Exige(lista.Count == 1 && lista[0].Id == vistaId && lista[0].BaseId == Base,
                "el listado SQL real del colaborador debe contener únicamente su obra.");
            await Denegado(() => colaborador.AbrirProyectoAsync(privada.Id), "conocer otro UUID no concede acceso.");
            string trabajo = Path.Combine(carpeta, "colaborador.sqlite");
            PaqueteNube.Descargar(abierto.Contenido, trabajo);
            var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(trabajo, norte.Id);
            MYGColaboracionLocal.Vincular(trabajo, documento, new MYGVinculoNube
            {
                ProyectoId = vistaId, Servidor = Servidor, UsuarioId = Colaborador.ToString("D"),
                Rol = abierto.Rol, Revision = abierto.Revision, PermisosModulos = abierto.PermisosModulos!.Copiar(),
                JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento),
                JsonPaqueteConfirmado = abierto.Contenido.GetRawText()
            });
            documento.Nombre = "Edición colaborativa real confirmada";
            MYGProyectoStorage.Guardar(trabajo, documento);
            var sincronizado = await SincronizadorProyectoNube.EjecutarAsync(colaborador, trabajo, documento);
            Exige(sincronizado.Vinculo.Revision == 2 && sincronizado.Vinculo.Pendiente is null,
                "Sincronizador debe confirmar revisión dos y retirar su cola durable.");
            var releido = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(trabajo, norte.Id);
            var segundaLectura = await SincronizadorProyectoNube.EjecutarAsync(colaborador, trabajo, releido, soloLeer: true);
            Exige(segundaLectura.Vinculo.Pendiente is null && segundaLectura.Documento.Nombre == documento.Nombre,
                "reabrir la copia confirmada no debe generar una edición fantasma.");
            var propietarioActual = await propietario.AbrirObraCentralAsync(vistaId);
            var surActual = await propietario.AbrirObraCentralAsync(privada.Id);
            Exige(PaqueteNube.LeerDocumento(propietarioActual.Contenido).Nombre == documento.Nombre
                && surActual.Revision == 1 && PaqueteNube.FirmaDatosCompartidos(surActual.Contenido) == firmaSur,
                "propietario debe ver la edición en la misma obra y la otra debe permanecer intacta.");

            using (var guardado = JsonDocument.Parse(redColaborador.UltimoGuardado!))
            {
                var p = guardado.RootElement;
                var repetido = await colaborador.GuardarProyectoAsync(vistaId, p.GetProperty("p_operacion").GetGuid(),
                    p.GetProperty("p_revision").GetInt64(), p.GetProperty("p_contenido"));
                Exige(repetido.Revision == 2 && repetido.Estado == "aplicada", "reintentar ACK real no debe duplicar la revisión.");
            }
            await propietario.CambiarPermisosMiembroAsync(vistaId, Colaborador.ToString("D"), new()
            { Acu = true, Especificaciones = true, MetradosExcel = true, MetradosRevit = false, MetradosRevitDisponible = true });
            var revit = PaqueteNube.LeerDocumento(propietarioActual.Contenido);
            revit.Presupuestos[0].CantidadFiltros = 2;
            await Denegado(() => colaborador.GuardarProyectoAsync(vistaId, Guid.NewGuid(), 2,
                PaqueteNube.ActualizarDocumento(propietarioActual.Contenido, revit)),
                "SQL real debe impedir modificar Metrados Revit cuando el permiso está retirado.");
            Exige((await propietario.AbrirObraCentralAsync(vistaId)).Revision == 2,
                "rechazar una edición BIM no debe avanzar la revisión.");
            await propietario.CambiarRolAsync(vistaId, Colaborador.ToString("D"), null);
            await Denegado(() => colaborador.AbrirProyectoAsync(vistaId), "revocación real debe impedir la reapertura, aun con cache cliente.");
            Exige((await colaborador.ListarProyectosAsync()).Count == 0, "después de revocar no debe aparecer ninguna obra en su cuenta.");
            Exige(contadores == await sql.Ejecutar("SELECT jsonb_build_array((SELECT count(*) FROM public.myg_nube_proyectos),(SELECT count(*) FROM storage.objects),(SELECT count(*) FROM myg_nube_privado.sqlite_revisiones))::text;"),
                "migrar, compartir y editar no deben publicar proyectos, objetos ni revisiones SQLite adicionales.");
            await PublicarBaseNuevaYEliminar(propietario, redPropietario, sql, carpeta, contadores);
            await ReanudarMigracionTrasNuevaRevision(propietario, redPropietario, sql, carpeta);
            Exige(redPropietario.Rutas.Concat(redColaborador.Rutas).All(u => u.Host == new Uri(Servidor).Host
                && (u.AbsolutePath.StartsWith("/auth/", StringComparison.Ordinal) || u.AbsolutePath.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal))),
                "ninguna etapa debe enviar archivos a Storage ni contactar el servicio externo.");
            Console.WriteLine($"OK Base central integración real: {comprobaciones} comprobaciones; PostgreSQL 17 + ClienteSupabase + migración SQLite de dos obras + Sincronizador. Solo Auth/HTTP simulados, RPC/ACL/CAS/colas reales.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static async Task ReanudarMigracionTrasNuevaRevision(ClienteSupabase propietario, Puente red,
        PostgreSqlLocal sql, string carpeta)
    {
        Guid baseId = Guid.Parse("eee10000-0000-0000-0000-000000000004");
        string ruta = Path.Combine(carpeta, "base-cas-reinicio.sqlite");
        var primera = MYGProyectoStorage.Nuevo("CAS obra antes de preparar", "Presupuesto CAS A");
        var segunda = MYGProyectoStorage.Nuevo("CAS otra obra conservada", "Presupuesto CAS B");
        MYGProyectoStorage.Guardar(ruta, primera); MYGProyectoStorage.Guardar(ruta, segunda);
        string copiaUno = Path.Combine(carpeta, "cas-publicada-1.sqlite");
        CopiaSqliteNube.CrearSnapshot(ruta, copiaUno);
        string hashUno = Hash(copiaUno).ToLowerInvariant(); long bytesUno = new FileInfo(copiaUno).Length;
        string objetoUno = $"{Propietario:D}/{baseId:N}/{hashUno}.sqlite";
        await sql.Ejecutar($"SET ROLE authenticated; SET request.jwt.claim.sub='{Propietario:D}'; "
            + $"INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('myg-nube-sqlite',{Literal(objetoUno)},jsonb_build_object('size',{bytesUno})); "
            + $"SELECT public.myg_nube_sqlite_crear('{baseId:D}','Base CAS reanudable','base',{Literal(primera.Id)},{Literal(objetoUno)},'{hashUno}',{bytesUno});");
        var revisionUno = await propietario.AbrirSqliteAsync(baseId);
        CopiaSqliteNube.Vincular(ruta, revisionUno, propietario);
        red.PerderPrimerAckPreparacion = true;
        try
        {
            await BaseCentralNube.PrepararMigracionAsync(propietario, ruta, revisionUno);
            throw new Exception("La integración no perdió el ACK durante la preparación parcial.");
        }
        catch (NubeException error) when (error.EsErrorDeConexion)
        {
            Exige(!BaseCentralNube.EsBase(ruta) && await propietario.ResolverCentralAsync(baseId) is null,
                "una preparación parcial no debe activar la base ni retirar la fuente SQLite anterior.");
        }
        string intento = Path.Combine(ruta + ".central", "intento.json");
        byte[] manifiestoAnterior = File.ReadAllBytes(intento);
        using var anterior = JsonDocument.Parse(manifiestoAnterior);
        Guid migracionAnterior = anterior.RootElement.GetProperty("Migracion").GetGuid();
        Exige(await sql.Ejecutar($"SELECT count(*) FROM myg_nube_privado.central_preparados WHERE migracion_id='{migracionAnterior:D}';") == "1",
            "el fixture debe conservar una obra preparada antes de que la fuente avance.");

        // Modela otro escritor autorizado que confirma el SQLite mientras esta
        // preparación estaba interrumpida. Después se abre su revisión nueva
        // con el mismo vinculador real usado por una descarga limpia.
        primera.Nombre = "CAS obra actualizada en revisión SQLite dos";
        MYGProyectoStorage.Guardar(ruta, primera);
        string copiaDos = Path.Combine(carpeta, "cas-publicada-2.sqlite");
        CopiaSqliteNube.CrearSnapshot(ruta, copiaDos);
        string hashDos = Hash(copiaDos).ToLowerInvariant(); long bytesDos = new FileInfo(copiaDos).Length;
        string objetoDos = $"{Propietario:D}/{baseId:N}/{hashDos}.sqlite";
        await sql.Ejecutar($"SET ROLE authenticated; SET request.jwt.claim.sub='{Propietario:D}'; "
            + $"INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('myg-nube-sqlite',{Literal(objetoDos)},jsonb_build_object('size',{bytesDos})); "
            + $"SELECT public.myg_nube_sqlite_guardar('{baseId:D}','{Guid.NewGuid():D}',1,{Literal(objetoDos)},'{hashDos}',{bytesDos});");
        var revisionDos = await propietario.AbrirSqliteAsync(baseId);
        Exige(revisionDos.Proyecto.Revision == 2 && revisionDos.Archivo.Sha256 == hashDos,
            "la revisión nueva debe estar realmente confirmada por la ruta SQLite anterior.");
        File.Move(CopiaSqliteNube.RutaEstado(ruta), CopiaSqliteNube.RutaEstado(ruta) + ".revision-uno-respaldada");
        CopiaSqliteNube.Vincular(ruta, revisionDos, propietario);
        var activadas = await BaseCentralNube.PrepararMigracionAsync(propietario, ruta, revisionDos);
        using var actual = JsonDocument.Parse(File.ReadAllBytes(intento));
        Guid migracionActual = actual.RootElement.GetProperty("Migracion").GetGuid();
        Exige(migracionActual != migracionAnterior && actual.RootElement.GetProperty("Revision").GetInt64() == 2,
            "reanudar una fuente más nueva debe cancelar el intento anterior y preparar un UUID nuevo para su revisión.");
        var archivosArchivados = Directory.EnumerateDirectories(ruta + ".central", "intento-cancelado-*").ToArray();
        Exige(archivosArchivados.Length == 1
            && File.ReadAllBytes(Path.Combine(archivosArchivados[0], "intento.json")).SequenceEqual(manifiestoAnterior)
            && File.Exists(Path.Combine(archivosArchivados[0], "origen.sqlite"))
            && Directory.EnumerateFiles(archivosArchivados[0], "obra-*.json").Count() == 2,
            "el intento sustituido debe conservar su manifiesto, instantánea y paquetes locales completos.");
        Exige(await sql.Ejecutar($"SELECT (cancelada_en IS NOT NULL AND catalogo IS NULL)::text FROM myg_nube_privado.central_migraciones WHERE id='{migracionAnterior:D}';") == "true"
            && await sql.Ejecutar($"SELECT count(*) FROM myg_nube_privado.central_preparados WHERE migracion_id='{migracionAnterior:D}';") == "0",
            "el servidor debe retirar staging anterior solo después de autorizar su cancelación.");
        Exige(activadas.Count == 2 && MYGBaseDatos.LeerProyecto(ruta, primera.Id).Nombre == primera.Nombre
            && MYGBaseDatos.LeerProyecto(ruta, segunda.Id).Nombre == segunda.Nombre
            && activadas.All(o => MYGColaboracionLocal.Leer(ruta, o.DocumentoId!)!.Pendiente is null),
            "la activación final debe conservar los datos de la revisión dos y ambas obras sin pendientes artificiales.");
        string manifiestoActivo = Hash(intento);
        try
        {
            await propietario.CancelarMigracionCentralAsync(migracionActual);
            throw new Exception("La integración permitió cancelar una migración ya activa.");
        }
        catch (NubeException error) when (error.Codigo == "22023")
        {
            Exige(Hash(intento) == manifiestoActivo && BaseCentralNube.EsBase(ruta),
                "rechazar cancelar una migración activa debe conservar el manifiesto de recuperación y su vínculo.");
        }
    }

    private static async Task PublicarBaseNuevaYEliminar(ClienteSupabase propietario, Puente red, PostgreSqlLocal sql,
        string carpeta, string contadores)
    {
        string origen = Path.Combine(carpeta, "base-nueva-local.sqlite");
        var primera = MYGProyectoStorage.Nuevo("Nueva central A", "Presupuesto A");
        var segunda = MYGProyectoStorage.Nuevo("Nueva central B", "Presupuesto B");
        MYGProyectoStorage.Guardar(origen, primera); MYGProyectoStorage.Guardar(origen, segunda);
        string hash = Hash(origen);
        red.PerderPrimerAckActivacion = true;
        Guid baseConfirmada;
        try
        {
            await BaseCentralNube.PublicarAsync(propietario, origen, "Base nativa desde instalación comercial");
            throw new InvalidOperationException("La integración no perdió el ACK de la publicación nueva.");
        }
        catch (NubeException error) when (error.EsErrorDeConexion)
        {
            baseConfirmada = (await propietario.ListarProyectosAsync()).Single(p => p.EsCentralNativa
                && p.Alcance == "base" && p.Nombre == "Base nativa desde instalación comercial").Id;
        }
        var publicada = await BaseCentralNube.PublicarAsync(propietario, origen, "Base nativa desde instalación comercial");
        Exige(publicada.Id == baseConfirmada, "un ACK perdido al publicar debe recuperar la misma base y sus identidades congeladas.");
        Exige(publicada.EsCentralNativa && publicada.Alcance == "base" && Hash(origen) == hash,
            "publicar una base nueva debe dejar intacto el origen local y crear la cabecera central.");
        var repetida = await BaseCentralNube.PublicarAsync(propietario, origen, "Base nativa desde instalación comercial");
        Exige(repetida.Id == publicada.Id && (await propietario.ListarObrasCentralAsync(publicada.Id)).Count == 2,
            "reintentar publicación debe confirmar la misma base con sus dos obras, sin duplicarlas.");
        string terceraRuta = Path.Combine(carpeta, "obra-nueva-local.sqlite");
        var tercera = MYGProyectoStorage.Nuevo("Obra añadida a la base central", "Presupuesto C");
        MYGProyectoStorage.Guardar(terceraRuta, tercera);
        var creada = await propietario.CrearObraCentralAsync(publicada.Id, tercera.Id, tercera.Nombre,
            BaseCentralNube.CrearContenidoEstricto(terceraRuta, tercera.Id));
        Exige(creada.BaseId == publicada.Id && creada.DocumentoId == tercera.Id && creada.Revision == 1,
            "una obra nueva se debe agregar a la misma base central con identidad estable.");
        string copia = Path.Combine(carpeta, "base-central-recuperada.sqlite");
        await BaseCentralNube.CrearCopiaAsync(propietario, publicada.Id, copia);
        Exige(BaseCentralNube.LeerBase(copia)?.BaseId == publicada.Id && MYGBaseDatos.ListarProyectos(copia).Count == 3
            && MYGBaseDatos.ListarProyectos(copia).All(d => MYGColaboracionLocal.Leer(copia, d.Id)!.Pendiente is null),
            "abrir una base central nueva debe materializar sus tres obras sin inventar operaciones.");
        await RegistrarNuevaObraConAckPerdido(propietario, red, publicada.Id, copia);
        var eliminada = await propietario.EliminarBaseAsync(publicada.Id);
        Exige(eliminada.BaseId == publicada.Id && eliminada.ObjetosEliminados == 0
            && await propietario.ResolverCentralAsync(publicada.Id) is null
            && Hash(origen) == hash && File.Exists(copia),
            "borrado central real debe retirar la nube sin borrar las copias locales ni buscar objetos inexistentes.");
        Exige(contadores == await sql.Ejecutar("SELECT jsonb_build_array((SELECT count(*) FROM public.myg_nube_proyectos),(SELECT count(*) FROM storage.objects),(SELECT count(*) FROM myg_nube_privado.sqlite_revisiones))::text;"),
            "publicar y eliminar una base nativa debe restaurar los contadores sin huérfanos Storage/SQLite.");
    }

    private static async Task RegistrarNuevaObraConAckPerdido(ClienteSupabase propietario, Puente red,
        Guid baseId, string ruta)
    {
        var nueva = MYGProyectoStorage.Nuevo("Nueva obra con creación interrumpida", "Presupuesto nuevo con ACK perdido");
        MYGProyectoStorage.Guardar(ruta, nueva);
        int creacionesAntes = red.Rutas.Count(u => u.AbsolutePath == "/rest/v1/rpc/myg_central_crear_obra");
        red.PerderPrimerAckCreacion = true;
        try
        {
            await BaseCentralNube.RegistrarObraAsync(propietario, ruta, baseId, nueva.Id);
            throw new Exception("La integración no perdió la confirmación al crear la obra.");
        }
        catch (NubeException error) when (error.EsErrorDeConexion)
        {
            Exige(MYGColaboracionLocal.Leer(ruta, nueva.Id) is null
                && (await propietario.ListarObrasCentralAsync(baseId)).Count(o => o.DocumentoId == nueva.Id) == 1,
                "un ACK perdido debe dejar la obra creada una sola vez en Supabase y el vínculo local pendiente de recuperar.");
        }
        string paquete = Directory.EnumerateFiles(ruta + ".central-obras", "*.json").Single();
        string hashPaquete = Hash(paquete);
        nueva.Nombre = "Borrador local conservado después del ACK perdido";
        MYGProyectoStorage.Guardar(ruta, nueva);
        var recuperada = await BaseCentralNube.RegistrarObraAsync(propietario, ruta, baseId, nueva.Id);
        var vinculo = MYGColaboracionLocal.Leer(ruta, nueva.Id)!;
        Exige(vinculo.ProyectoId == recuperada.Id && vinculo.Revision == 1
            && vinculo.Pendiente is not null && vinculo.Pendiente.RevisionBase == 1
            && MYGBaseDatos.LeerProyecto(ruta, nueva.Id).Nombre == nueva.Nombre
            && MYGColaboracionLocal.ImportarDocumento(vinculo.JsonConfirmado).Nombre == "Nueva obra con creación interrumpida",
            "recuperar la creación debe vincular su contenido congelado en revisión uno y conservar la edición posterior como pendiente.");
        Exige(Hash(paquete) == hashPaquete
            && red.Rutas.Count(u => u.AbsolutePath == "/rest/v1/rpc/myg_central_crear_obra") == creacionesAntes + 1
            && (await propietario.ListarObrasCentralAsync(baseId)).Count(o => o.DocumentoId == nueva.Id) == 1,
            "reintentar debe reutilizar los bytes iniciales y descubrir la obra existente sin repetir su creación.");
        var local = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, nueva.Id);
        var sincronizada = await SincronizadorProyectoNube.EjecutarAsync(propietario, ruta, local);
        Exige(sincronizada.Vinculo.Revision == 2 && sincronizada.Vinculo.Pendiente is null
            && PaqueteNube.LeerDocumento((await propietario.AbrirObraCentralAsync(recuperada.Id)).Contenido).Nombre == nueva.Nombre,
            "la edición posterior recuperada debe sincronizarse sobre la misma obra en revisión dos sin perder el borrador.");
        var releida = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, nueva.Id);
        var estable = await SincronizadorProyectoNube.EjecutarAsync(propietario, ruta, releida, soloLeer: true);
        Exige(estable.Vinculo.Pendiente is null
            && (await propietario.ListarObrasCentralAsync(baseId)).Count == 4,
            "la reapertura debe quedar estable, sin cambios fantasma ni otra obra duplicada.");
    }

    private static async Task<ClienteSupabase> Conectar(Puente puente)
    {
        var cliente = new ClienteSupabase(Servidor, "sb_publishable_integracion_central_sintetica", puente);
        await cliente.IniciarSesionAsync("qa@example.invalid", "clave_qa_sintetica");
        return cliente;
    }

    private static void Exige(bool condicion, string detalle)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException("Integración central real: " + detalle); }

    private static async Task Denegado(Func<Task> accion, string detalle)
    {
        try { await accion(); }
        catch (NubeException error) when (error.AccesoDenegado) { comprobaciones++; return; }
        throw new InvalidOperationException("Integración central real: faltó rechazo 403: " + detalle);
    }

    private static string Hash(string ruta) { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }
    private static string? Sqlite(string ruta, string sentencia)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = sentencia;
        return q.ExecuteScalar()?.ToString();
    }
    private static string Literal(string texto) => "convert_from(decode('" + Convert.ToBase64String(Encoding.UTF8.GetBytes(texto)) + "','base64'),'UTF8')";

    private sealed class Puente(PostgreSqlLocal sql, Guid actor) : HttpMessageHandler
    {
        internal List<Uri> Rutas { get; } = new();
        internal byte[]? UltimoGuardado;
        internal bool PerderPrimerAckActivacion;
        internal bool PerderPrimerAckPreparacion;
        internal bool PerderPrimerAckCreacion;
        private string Token => "acceso_qa_" + actor.ToString("N");

        internal async Task<JsonElement> Rpc(string funcion, object parametros)
        {
            using var q = new HttpRequestMessage(HttpMethod.Post, Servidor + "/rest/v1/rpc/" + funcion)
            { Content = new StringContent(JsonSerializer.Serialize(parametros), Encoding.UTF8, "application/json") };
            q.Headers.Authorization = new("Bearer", Token); q.Headers.Add("apikey", "sb_publishable_integracion_central_sintetica");
            using var respuesta = await SendAsync(q, CancellationToken.None);
            string contenido = await respuesta.Content.ReadAsStringAsync();
            if (!respuesta.IsSuccessStatusCode) throw new InvalidOperationException("RPC fixture: " + contenido);
            using var j = JsonDocument.Parse(contenido); return j.RootElement.Clone();
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage q, CancellationToken ct)
        {
            var uri = q.RequestUri!; Rutas.Add(uri);
            if (uri.Host != new Uri(Servidor).Host) throw new InvalidOperationException("La integración intentó usar un destino externo.");
            if (uri.AbsolutePath == "/auth/v1/token") return Respuesta(JsonSerializer.Serialize(new
            { access_token = Token, refresh_token = "refresco_qa_" + actor.ToString("N"), expires_in = 3600, user = new { id = actor } }));
            if (q.Headers.Authorization?.Parameter != Token || !q.Headers.Contains("apikey"))
                throw new InvalidOperationException("La solicitud no conserva la cuenta sintética de esta sesión.");
            if (!uri.AbsolutePath.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal))
                throw new InvalidOperationException("No se admite Storage ni otro servicio en la integración central.");
            string funcion = uri.AbsolutePath.Split('/').Last();
            if (!Regex.IsMatch(funcion, "^myg_(central|nube|base)_[a-z0-9_]+$")) throw new InvalidOperationException("RPC fuera del fixture.");
            byte[] cuerpo = await q.Content!.ReadAsByteArrayAsync(ct);
            if (funcion == "myg_central_guardar") UltimoGuardado = cuerpo;
            using var documento = JsonDocument.Parse(cuerpo, new JsonDocumentOptions { MaxDepth = 128 });
            var argumentos = documento.RootElement.EnumerateObject().Select(p =>
            {
                if (!Regex.IsMatch(p.Name, "^p_[a-z0-9_]+$")) throw new InvalidOperationException("Parámetro RPC no válido.");
                string tipo = p.Name is "p_id" or "p_base" or "p_operacion" or "p_migracion" or "p_usuario" ? "uuid"
                    : p.Name is "p_revision" ? "bigint"
                    : p.Value.ValueKind is JsonValueKind.Array or JsonValueKind.Object ? "jsonb" : "text";
                string valor = p.Value.ValueKind == JsonValueKind.Null ? "NULL"
                    : Literal(p.Value.ValueKind == JsonValueKind.String ? p.Value.GetString()! : p.Value.GetRawText());
                return p.Name + "=>" + valor + "::" + tipo;
            });
            try
            {
                string resultado = await sql.Ejecutar($"SET ROLE authenticated; SET request.jwt.claim.sub='{actor:D}'; SELECT coalesce(to_jsonb(public.{funcion}({string.Join(',', argumentos)})),'null'::jsonb)::text;", ct);
                if (funcion == "myg_central_activar" && PerderPrimerAckActivacion)
                {
                    PerderPrimerAckActivacion = false;
                    return Respuesta("{\"code\":\"503\",\"message\":\"ACK de activación perdido por prueba\"}", HttpStatusCode.ServiceUnavailable);
                }
                if (funcion == "myg_central_preparar" && PerderPrimerAckPreparacion)
                {
                    PerderPrimerAckPreparacion = false;
                    return Respuesta("{\"code\":\"503\",\"message\":\"ACK de preparación perdido por prueba\"}", HttpStatusCode.ServiceUnavailable);
                }
                if (funcion == "myg_central_crear_obra" && PerderPrimerAckCreacion)
                {
                    PerderPrimerAckCreacion = false;
                    return Respuesta("{\"code\":\"503\",\"message\":\"ACK de creación perdido por prueba\"}", HttpStatusCode.ServiceUnavailable);
                }
                return Respuesta(resultado);
            }
            catch (ErrorPostgreSql e)
            {
                var estado = e.Codigo == "42501" ? HttpStatusCode.Forbidden : HttpStatusCode.BadRequest;
                return Respuesta(JsonSerializer.Serialize(new { code = e.Codigo, message = e.Detalle }), estado);
            }
        }

        private static HttpResponseMessage Respuesta(string texto, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        { Content = new StringContent(texto, Encoding.UTF8, "application/json") };
    }

    private sealed class ErrorPostgreSql(string codigo, string detalle) : Exception(detalle)
    { internal string Codigo => codigo; internal string Detalle => Message; }

    private sealed class PostgreSqlLocal(string contenedor)
    {
        internal async Task<string> Ejecutar(string sentencia, CancellationToken ct = default)
        {
            var inicio = new ProcessStartInfo("docker")
            { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
            foreach (var n in new[] { "DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH" }) inicio.Environment.Remove(n);
            foreach (var a in new[] { "--host=unix:///var/run/docker.sock", "exec", "-i", "-u", "postgres", contenedor,
                "psql", "-X", "-qAt", "-d", "postgres", "-v", "ON_ERROR_STOP=1", "-v", "VERBOSITY=verbose" }) inicio.ArgumentList.Add(a);
            using var proceso = Process.Start(inicio) ?? throw new IOException("No se inició psql en PostgreSQL desechable.");
            var salida = proceso.StandardOutput.ReadToEndAsync(ct); var errores = proceso.StandardError.ReadToEndAsync(ct);
            await proceso.StandardInput.WriteAsync(sentencia.AsMemory(), ct); proceso.StandardInput.Close();
            await proceso.WaitForExitAsync(ct);
            string resultado = (await salida).Trim(), error = await errores;
            if (proceso.ExitCode != 0)
            {
                var fallo = Regex.Match(error, @"ERROR:\s+([A-Z0-9]{5}):\s*([^\r\n]*)");
                if (fallo.Success) throw new ErrorPostgreSql(fallo.Groups[1].Value, fallo.Groups[2].Value);
                throw new IOException("No se ejecutó el fixture PostgreSQL: " + error[..Math.Min(error.Length, 1000)]);
            }
            return resultado;
        }
    }
}
