using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Regresión independiente de catálogos que no pertenecen a ninguna
/// obra y de sus adjuntos/configuración, usando SQLite real y transporte local.</summary>
internal static class CentralCoberturaCheck
{
    private static readonly Guid Usuario = Guid.Parse("5cc148cf-bc76-457e-9070-bf96fd036d22");
    private static readonly Guid Base = Guid.Parse("e746359b-416c-45cc-bfac-3ac4fd6fd1c7");
    private const string Servidor = "https://central-cobertura-qa.supabase.co";
    private const string Privado = "QA-CATALOGO-PRIVADO-NO-USADO-7AB2";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Central-Cobertura-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string origen = Path.Combine(carpeta, "origen.sqlite");
            var norte = MYGProyectoStorage.Nuevo("Norte cobertura", "Presupuesto norte");
            var sur = MYGProyectoStorage.Nuevo("Sur cobertura", "Presupuesto sur");
            var usado = new MYGInsumo
            { Codigo = "QA-USADO-OBRA", Descripcion = "Insumo de la obra en revisión uno", Unidad = "kg", Precio = 12.34m };
            norte.Presupuestos[0].Costos.Insumos.Add(usado);
            string partidaObraId = MYGProyectoStorage.NuevoId();
            norte.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            {
                Id = partidaObraId, IdLocalMYG = partidaObraId, Descripcion = "Partida con recurso nativo", Unidad = "und",
                Costos = new MYGDatosPartida
                {
                    Cantidad = 1, RendimientoDiario = 1,
                    Analisis = new() { new MYGRecursoACU { InsumoId = usado.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 } }
                }
            });
            MYGProyectoStorage.Guardar(origen, norte); MYGProyectoStorage.Guardar(origen, sur);
            string imagen = Path.Combine(carpeta, "imagen-catalogo.bin");
            byte[] bytesImagen = Encoding.UTF8.GetBytes("imagen sintetica de catalogo no usado");
            File.WriteAllBytes(imagen, bytesImagen);
            var insumo = MYGCatalogos.GuardarInsumo(origen, new MYGInsumo
            {
                Codigo = Privado, Descripcion = "Insumo que no participa en las obras", Unidad = "und",
                Grupo = MYGGrupoRecurso.Materiales, Precio = 123.45m, ImagenRuta = imagen
            });
            var modelo = MYGProyectoStorage.Nuevo("Plantilla temporal", "Plantilla").Presupuestos[0];
            string partidaId = MYGProyectoStorage.NuevoId();
            var partida = new ItemPresupuestoDelphin
            {
                Id = partidaId, IdLocalMYG = partidaId, Descripcion = "Partida reusable no utilizada",
                Unidad = "und", Costos = new MYGDatosPartida { PrecioDirecto = 45.67m, Cantidad = 1 }
            };
            modelo.Items.Add(partida);
            var entrada = MYGCatalogos.GuardarPartida(origen, modelo, partida,
                "QA-PARTIDA-NO-USADA", partida.Descripcion, partida.Unidad);
            var unidad = MYGCatalogoUnidades.Guardar(origen, new MYGUnidadCatalogo
            {
                Simbolo = "QA_COBERTURA", Descripcion = "Unidad sin uso con filtros propios", Tipo = "H",
                EsCostoUnitario = false, EsGastoGeneral = true, TiposCosto = new() { MYGGrupoRecurso.Equipo }
            });
            Sql(origen, "CREATE TABLE IF NOT EXISTS myg_indice_unificado(codigo TEXT PRIMARY KEY COLLATE NOCASE,descripcion TEXT NOT NULL,periodo_base TEXT NOT NULL,resolucion TEXT NOT NULL,orden INTEGER NOT NULL); INSERT INTO myg_indice_unificado VALUES('QA-UNUSED','Índice no usado','2026','QA',901)");

            JsonElement catalogo = BaseCentralNube.CrearCatalogoEstricto(origen);
            Exige(catalogo.GetProperty("formato").GetString() == "MYG_CATALOGO_BASE", "el catálogo tiene un formato propio");
            Exige(!catalogo.TryGetProperty("documento", out _) && !catalogo.TryGetProperty("documentos", out _),
                "el catálogo privado no transporta documentos de las obras");
            Exige(Contiene(catalogo, "catalogo_insumo", insumo.Id), "incluye el insumo sin referencias en presupuestos");
            Exige(Contiene(catalogo, "catalogo_partida", entrada.Id), "incluye la partida reusable sin referencias");
            Exige(Contiene(catalogo, "catalogo_unidad", unidad.Id), "incluye la unidad personalizada sin uso");
            Exige(Contiene(catalogo, "myg_indice_unificado", "QA-UNUSED"), "incluye los índices globales sin uso");
            var recursos = catalogo.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>()!;
            Exige(recursos.Count == 1 && Convert.FromBase64String(recursos[0].Base64).AsSpan().SequenceEqual(bytesImagen),
                "conserva el adjunto del catálogo no utilizado");

            var obras = new[] { norte, sur }.Select((d, i) => new ProyectoNube(
                Guid.Parse(i == 0 ? "2fe052cc-f7e7-44a5-a7b5-727de17a0a91" : "3fe052cc-f7e7-44a5-a7b5-727de17a0a91"),
                "VISTA-QA-" + i, d.Nombre, "propietario", 1, "obra", BaseCentralNube.CrearContenidoEstricto(origen, d.Id))
            { BaseId = Base, DocumentoId = d.Id, EsCentralNativa = true }).ToArray();
            foreach (var obra in obras)
                Exige(!obra.Contenido.GetRawText().Contains(Privado, StringComparison.Ordinal),
                    "el paquete de obra no entrega el catálogo ajeno no utilizado");
            ValidarCobertura(origen, obras.Select(x => x.Contenido).ToArray(), catalogo);
            Exige(true, "las filas de origen están cubiertas por obras, catálogo y valores iniciales de Core");
            using var transporte = new Transporte(obras, catalogo);
            using var cliente = new ClienteSupabase(Servidor, "sb_publishable_cobertura_sintetica", transporte);
            await cliente.IniciarSesionAsync("qa-cobertura@example.test", "clave_sintetica");
            string destino = Path.Combine(carpeta, "descarga.sqlite");
            await BaseCentralNube.CrearCopiaAsync(cliente, Base, destino);
            Exige(MYGBaseDatos.ListarProyectos(destino).Count == 2, "la base reconstruida conserva ambas obras");
            var recibido = MYGCatalogos.Listar(destino, partidas: false).Single(x => x.Id == insumo.Id);
            Exige(recibido.Codigo == Privado && recibido.Precio == 123.45m, "el catálogo mantiene datos y precio exacto del insumo");
            Exige(MYGCatalogos.Listar(destino, partidas: true).Single(x => x.Id == entrada.Id).Precio == entrada.Precio,
                "el catálogo mantiene la partida reusable");
            var unidadRecibida = MYGCatalogoUnidades.Listar(destino).Single(x => x.Id == unidad.Id);
            Exige(unidadRecibida.Simbolo == unidad.Simbolo && unidadRecibida.Descripcion == unidad.Descripcion,
                "la unidad recuperada mantiene su identidad y descripción");
            Exige(unidadRecibida.Tipo == unidad.Tipo && unidadRecibida.EsCostoUnitario == unidad.EsCostoUnitario
                && unidadRecibida.EsGastoGeneral == unidad.EsGastoGeneral && unidadRecibida.TiposCosto.SequenceEqual(unidad.TiposCosto),
                "la unidad mantiene tipo, alcance y filtros por grupo de recurso");
            var insumoRecibido = MYGCatalogos.LeerInsumo(destino, insumo.Id);
            Exige(File.Exists(insumoRecibido.ImagenRuta) && File.ReadAllBytes(insumoRecibido.ImagenRuta).AsSpan().SequenceEqual(bytesImagen),
                "el adjunto existe después de mover la base del temporal a su destino");
            Exige(Contiene(BaseCentralNube.CrearCatalogoEstricto(destino), "myg_indice_unificado", "QA-UNUSED"),
                "el índice global sigue en el catálogo tras reconstruir la base");
            Exige(transporte.Rutas.All(x => x.StartsWith("/auth/", StringComparison.Ordinal) || x.StartsWith("/rest/", StringComparison.Ordinal)),
                "la reconstrucción no necesita un servicio externo ni descargas del archivo completo");
            // El catálogo inicial es inmutable, pero los recursos de un presupuesto
            // evolucionan con su obra. Abrir otra caché debe usar esa revisión nueva.
            usado.Precio = 98.76m; usado.Descripcion = "Insumo de la obra actualizado en revisión dos";
            MYGProyectoStorage.Guardar(origen, norte);
            obras = obras.Select(o => o.DocumentoId == norte.Id ? o with
            { Revision = 2, Contenido = BaseCentralNube.CrearContenidoEstricto(origen, norte.Id) } : o).ToArray();
            using var transporteActualizado = new Transporte(obras, catalogo);
            using var clienteActualizado = new ClienteSupabase(Servidor, "sb_publishable_cobertura_sintetica", transporteActualizado);
            await clienteActualizado.IniciarSesionAsync("qa-cobertura@example.test", "clave_sintetica");
            string destinoActualizado = Path.Combine(carpeta, "descarga-revision-dos.sqlite");
            await BaseCentralNube.CrearCopiaAsync(clienteActualizado, Base, destinoActualizado);
            var norteActualizado = MYGBaseDatos.LeerProyecto(destinoActualizado, norte.Id);
            var recursoActualizado = norteActualizado.Presupuestos[0].Costos.Insumos.Single(i => i.Id == usado.Id);
            Exige(recursoActualizado.Precio == 98.76m && recursoActualizado.Descripcion == usado.Descripcion,
                "una descarga nueva usa precio y descripción de la revisión dos de la obra");
            Exige(MYGCatalogos.Listar(destinoActualizado, false).Any(i => i.Id == insumo.Id),
                "actualizar el recurso de una obra conserva el catálogo privado no utilizado");
            Exige(MYGBaseDatos.LeerProyecto(destinoActualizado, sur.Id).Nombre == sur.Nombre,
                "la descarga con una obra actualizada conserva la otra obra");
            Sql(origen, "INSERT INTO persona(id_persona,nombre_persona) VALUES(987654321,'Persona sintética fuera del modelo colaborativo')");
            bool rechazado = false;
            try { ValidarCobertura(origen, obras.Select(x => x.Contenido).ToArray(), catalogo); }
            catch (InvalidDataException error) when (error.Message.Contains("persona", StringComparison.Ordinal)) { rechazado = true; }
            Exige(rechazado, "una fila conocida sin destino central impide convertir la base y señala su tabla");
            Exige(Valor(origen, "SELECT count(*) FROM persona WHERE id_persona=987654321") == 1,
                "el rechazo conserva las filas no cubiertas en el archivo de origen");
            Console.WriteLine($"OK Cobertura central: {comprobaciones} comprobaciones de catálogos no utilizados, unidades, filtros, índices, adjuntos y privacidad de obra.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static void ValidarCobertura(string ruta, IReadOnlyList<JsonElement> obras, JsonElement catalogo)
    {
        var tipo = typeof(BaseCentralNube).Assembly.GetType("MYG.Colaboracion.CoberturaCentralNube", throwOnError: true)!;
        var metodo = tipo.GetMethod("Validar", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)!;
        try { metodo.Invoke(null, new object[] { ruta, obras, catalogo }); }
        catch (System.Reflection.TargetInvocationException error) when (error.InnerException is not null)
        { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error.InnerException).Throw(); }
    }

    private static bool Contiene(JsonElement catalogo, string nombre, string valor)
    {
        var tablas = catalogo.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>()!;
        return tablas.Any(t => t.Nombre == nombre && t.Filas.Any(f => f.Any(c => c.Valor == valor)));
    }

    private sealed class Transporte(ProyectoNube[] obras, JsonElement catalogo) : HttpMessageHandler
    {
        internal List<string> Rutas { get; } = new();
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri!.AbsolutePath; Rutas.Add(ruta);
            if (ruta == "/auth/v1/token") return Respuesta(new
            { access_token = "acceso_qa_cobertura", refresh_token = "refresco_qa_cobertura", expires_in = 3600, user = new { id = Usuario } });
            if (ruta == "/rest/v1/rpc/myg_central_resolver") return Respuesta(new
            {
                id = Base, codigo = "MYG-BASE-COBERTURA", nombre = "Base cobertura", rol = "propietario",
                revision = 1, alcance = "base", central_nativa = true,
                permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true }
            });
            if (ruta == "/rest/v1/rpc/myg_central_obras") return Respuesta(obras.Select(x => Descriptor(x, false)));
            if (ruta == "/rest/v1/rpc/myg_central_catalogo") return Respuesta(catalogo);
            if (ruta == "/rest/v1/rpc/myg_central_abrir")
            {
                using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(ct));
                Guid id = cuerpo.RootElement.GetProperty("p_id").GetGuid();
                return Respuesta(Descriptor(obras.Single(x => x.Id == id), true));
            }
            throw new InvalidOperationException("Ruta no prevista en cobertura: " + ruta);
        }
        private static object Descriptor(ProyectoNube obra, bool contenido)
        {
            var salida = new Dictionary<string, object?>
            {
                ["id"] = obra.Id, ["codigo"] = obra.Codigo, ["nombre"] = obra.Nombre, ["rol"] = obra.Rol,
                ["revision"] = obra.Revision, ["alcance"] = obra.Alcance, ["base_id"] = obra.BaseId,
                ["documento_id"] = obra.DocumentoId, ["vista_base"] = true, ["central_nativa"] = true,
                ["permisos_modulos"] = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true }
            };
            if (contenido) salida["contenido"] = obra.Contenido;
            return salida;
        }
        private static HttpResponseMessage Respuesta(object datos) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(datos), Encoding.UTF8, "application/json") };
    }

    private static void Sql(string ruta, string sql)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = sql; q.ExecuteNonQuery();
    }
    private static long Valor(string ruta, string sql)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = sql; return Convert.ToInt64(q.ExecuteScalar());
    }
    private static void Exige(bool cumple, string mensaje)
    { comprobaciones++; if (!cumple) throw new InvalidOperationException("Cobertura central: " + mensaje); }
}
