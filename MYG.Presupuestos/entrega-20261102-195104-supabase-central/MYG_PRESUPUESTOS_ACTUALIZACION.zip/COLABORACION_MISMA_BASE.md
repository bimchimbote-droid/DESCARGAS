# Colaboración MYG: guía vigente

La solución actual utiliza directamente Supabase como base central, con permisos y revisión por obra. No requiere instalar el servicio .NET de la entrega anterior ni configurar ServicioBasesUrl.

Siga [COLABORACION_SUPABASE_CENTRAL.md](COLABORACION_SUPABASE_CENTRAL.md): contiene los archivos, la activación SQL, el instalador comercial, las pruebas y los límites de esta actualización.

Los archivos y colaboraciones anteriores se conservan. Los pasos antiguos de alojamiento, dominio y servidor adicional dejan de ser necesarios para esta modalidad.
