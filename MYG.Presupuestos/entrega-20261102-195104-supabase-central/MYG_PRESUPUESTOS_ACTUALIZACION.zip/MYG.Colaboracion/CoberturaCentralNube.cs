using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>Comprueba que la transformación central no descarte filas conocidas
/// del SQLite de origen. Las tablas privadas quedan fuera del paquete portable.</summary>
internal static class CoberturaCentralNube
{
    // Estas tablas se reconstruyen al guardar los documentos MYG. id_table es
    // el contador de identidades nativas generado por Core, no contenido de obra.
    private static readonly HashSet<string> Derivadas = new(StringComparer.OrdinalIgnoreCase)
    {
        "myg_proyecto", "myg_presupuesto", "partida_presupuesto", "insumo_presupuesto",
        "recurso_presupuesto", "id_table"
    };
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };

    internal static void Validar(string ruta, IReadOnlyList<JsonElement> obras, JsonElement catalogo)
    {
        if (obras.Count == 0) throw new InvalidDataException("La base central necesita al menos una obra.");
        string patron = Path.Combine(Path.GetTempPath(), "myg-central-cobertura-" + Guid.NewGuid().ToString("N") + ".sqlite");
        try
        {
            MYGBaseDatos.CrearBaseVacia(patron);
            PrepararCatalogosDerivados(ruta, patron, catalogo);
            var principal = PaqueteNube.LeerDocumento(obras[0]);
            var fuente = FormatoPaqueteNube.Expandir(PaqueteNube.CrearContenido(principal, ruta, "base"));
            var vacia = FormatoPaqueteNube.Expandir(PaqueteNube.CrearContenido(principal, patron, "base"));
            var representadas = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
            foreach (var obra in obras) Registrar(representadas, FormatoPaqueteNube.Expandir(obra));
            Registrar(representadas, catalogo);
            var iniciales = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
            Registrar(iniciales, vacia);
            var omitidas = new List<string>();
            foreach (var tabla in LeerTablas(fuente))
            {
                if (Derivadas.Contains(tabla.Nombre) || tabla.Filas.Count == 0) continue;
                representadas.TryGetValue(tabla.Nombre, out var incluidas);
                iniciales.TryGetValue(tabla.Nombre, out var predeterminadas);
                if (tabla.Filas.Any(fila =>
                {
                    string firma = Firmar(tabla, fila);
                    return incluidas?.Contains(firma) != true && predeterminadas?.Contains(firma) != true;
                })) omitidas.Add(tabla.Nombre);
            }
            if (omitidas.Count > 0)
                throw new InvalidDataException("La base contiene datos adicionales que todavía no se pueden conservar íntegramente en la colaboración central: "
                    + string.Join(", ", omitidas.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
                    + ". No se activó la conversión; conserve el archivo original.");
        }
        finally { SqliteConnection.ClearAllPools(); if (File.Exists(patron)) File.Delete(patron); }
    }

    private static void PrepararCatalogosDerivados(string origen, string patron, JsonElement catalogo)
    {
        // Core reconstruye los análisis nativos de los catálogos a partir de
        // sus plantillas. Compararlos con esa reconstrucción evita tanto perder
        // filas huérfanas como rechazar una plantilla válida por sus índices.
        var tablas = LeerTablas(catalogo);
        HashSet<string> Identidades(string nombre)
        {
            var tabla = tablas.SingleOrDefault(t => t.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase));
            if (tabla is null) return new(StringComparer.OrdinalIgnoreCase);
            int columna = tabla.Columnas.FindIndex(c => c.Equals("id", StringComparison.OrdinalIgnoreCase));
            return columna < 0 ? new(StringComparer.OrdinalIgnoreCase)
                : tabla.Filas.Select(f => f[columna].Valor ?? "").ToHashSet(StringComparer.OrdinalIgnoreCase);
        }
        var insumos = Identidades("catalogo_insumo");
        foreach (var entrada in MYGCatalogos.Listar(origen, partidas: false).Where(e => insumos.Contains(e.Id)))
            MYGCatalogos.GuardarInsumo(patron, MYGCatalogos.LeerInsumo(origen, entrada.Id), entrada.Id);
        var partidas = Identidades("catalogo_partida");
        foreach (var entrada in MYGCatalogos.Listar(origen, partidas: true).Where(e => partidas.Contains(e.Id)))
        {
            var plantilla = MYGCatalogos.LeerPartida(origen, entrada.Id);
            var presupuesto = new MYGPresupuestoDocumento
            {
                Nombre = "Comprobación de catálogo", Items = plantilla.Partidas,
                Costos = new MYGCostosPresupuesto
                {
                    Insumos = plantilla.Insumos, DecimalesPrecio = plantilla.DecimalesPrecio,
                    DecimalesCantidad = plantilla.DecimalesCantidad
                }
            };
            var raiz = presupuesto.Items.Single(i => i.IdLocalMYG == plantilla.RaizLocalId);
            MYGCatalogos.GuardarPartida(patron, presupuesto, raiz, entrada.Codigo, entrada.Descripcion,
                entrada.Unidad, entrada.Id, grupo: plantilla.Grupo);
        }
    }

    private static List<PaqueteNube.Tabla> LeerTablas(JsonElement paquete) => paquete.TryGetProperty("tablas", out var tablas)
        ? tablas.Deserialize<List<PaqueteNube.Tabla>>(Json) ?? new() : new();

    private static void Registrar(Dictionary<string, HashSet<string>> destino, JsonElement paquete)
    {
        foreach (var tabla in LeerTablas(paquete))
        {
            if (!destino.TryGetValue(tabla.Nombre, out var filas)) destino[tabla.Nombre] = filas = new(StringComparer.Ordinal);
            foreach (var fila in tabla.Filas) filas.Add(Firmar(tabla, fila));
        }
    }

    private static string Firmar(PaqueteNube.Tabla tabla, List<PaqueteNube.Celda> fila)
    {
        if (fila.Count != tabla.Columnas.Count) throw new InvalidDataException("Una fila de la base no tiene un esquema consistente.");
        var campos = new SortedDictionary<string, object?>(StringComparer.Ordinal);
        for (int i = 0; i < fila.Count; i++)
        {
            string nombre = tabla.Columnas[i];
            if (nombre.Equals("modificado_utc", StringComparison.OrdinalIgnoreCase)) continue;
            var celda = fila[i];
            object? valor = celda.Valor;
            if (celda.Tipo == "texto" && !string.IsNullOrWhiteSpace(celda.Valor)
                && (celda.Valor.TrimStart().StartsWith('{') || celda.Valor.TrimStart().StartsWith('[')))
            {
                try { valor = Canonizar(JsonNode.Parse(celda.Valor, documentOptions: new JsonDocumentOptions { MaxDepth = 128 })); }
                catch (JsonException) { }
            }
            // La cultura nunca afecta números, nombres ni precios del SQLite.
            campos[nombre.ToLowerInvariant()] = new object?[] { celda.Tipo, valor };
        }
        return JsonSerializer.Serialize(campos, Json);
    }

    private static object? Canonizar(JsonNode? nodo)
    {
        if (nodo is JsonObject objeto)
        {
            var salida = new SortedDictionary<string, object?>(StringComparer.Ordinal);
            foreach (var campo in objeto)
            {
                if (campo.Key.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("ModificadoUtc", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("PresupuestoActivoId", StringComparison.OrdinalIgnoreCase)) continue;
                salida[campo.Key] = Canonizar(campo.Value);
            }
            return salida;
        }
        if (nodo is JsonArray lista) return lista.Select(Canonizar).ToArray();
        if (nodo is null) return null;
        return nodo.Deserialize<JsonElement>(Json);
    }
}
