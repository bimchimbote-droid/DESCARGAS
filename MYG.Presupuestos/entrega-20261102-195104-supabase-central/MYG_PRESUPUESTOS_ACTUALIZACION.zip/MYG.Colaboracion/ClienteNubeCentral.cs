#nullable enable
using System.Collections.Concurrent;
using System.Text.Json;

namespace MYG.Colaboracion;

/// <summary>Identidades de documentos de una migración; no contiene datos de las obras.</summary>
public sealed record DocumentoMigracionCentral(string DocumentoId, string Nombre);
public sealed record EstadoMigracionCentral(Guid MigracionId, Guid BaseId, long Revision, string Estado);

public sealed partial class ClienteSupabase
{
    private bool capacidadCentral;
    private readonly ConcurrentDictionary<Guid, ProyectoNube> proyectosCentrales = new();

    /// <summary>La capacidad se negocia en Supabase. No necesita otra dirección ni credenciales administrativas.</summary>
    public async Task<bool> AdmiteCentralAsync(CancellationToken ct = default)
    {
        if (capacidadCentral) return true;
        try
        {
            bool admite = await EjecutarRpcNubeAsync("myg_central_capacidades", new { }, raiz =>
            {
                if (raiz.ValueKind != JsonValueKind.Object
                    || !raiz.TryGetProperty("version", out var v) || v.ValueKind != JsonValueKind.Number
                    || !v.TryGetInt32(out int version) || version != 1) throw RespuestaNubeInvalida();
                return true;
            }, ct);
            capacidadCentral = admite;
            return admite;
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883") { return false; }
    }

    private async Task ExigirCentralAsync(CancellationToken ct)
    {
        if (!await AdmiteCentralAsync(ct))
            throw new NubeException("Actualice Supabase ejecutando completa 20261106_base_central.sql. La base local se conserva; no necesita configurar un servicio adicional.", codigo: "MYG_CENTRAL_NO_INSTALADA");
    }

    /// <summary>Retira únicamente la preparación no activada. El servidor nunca
    /// cancela una base central que ya está operativa.</summary>
    public async Task CancelarMigracionCentralAsync(Guid migracion, CancellationToken ct = default)
    {
        ValidarIdNube(migracion);
        string usuario = await IdentidadArchivosAsync(ct);
        await EjecutarRpcNubeAsync("myg_central_cancelar", new { p_migracion = migracion }, raiz =>
        {
            if (TextoNube(raiz, "estado", 16) != "cancelada") throw RespuestaNubeInvalida();
            return true;
        }, ct, identidadEsperada: usuario);
    }

    /// <summary>Resolver devuelve solo metadatos autorizados; nunca el archivo de la base completa.</summary>
    public async Task<ProyectoNube?> ResolverCentralAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        try
        {
            return await EjecutarRpcNubeAsync("myg_central_resolver", new { p_id = id }, raiz =>
            {
                if (raiz.ValueKind == JsonValueKind.Null) return null;
                return LeerCentral(raiz, contenido: false, esperado: id);
            }, ct);
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883") { return null; }
    }

    public async Task<EstadoMigracionCentral> IniciarMigracionCentralAsync(Guid baseId, long revision,
        Guid migracion, IReadOnlyList<DocumentoMigracionCentral> documentos, CancellationToken ct = default)
    {
        ValidarIdNube(baseId); ValidarIdNube(migracion);
        if (revision < 1 || revision == long.MaxValue || documentos is null || documentos.Count is < 1 or > 10000)
            throw new NubeException("La migración necesita la revisión confirmada y las identidades de sus obras.");
        var ids = new HashSet<string>(StringComparer.Ordinal);
        var manifest = documentos.Select(d =>
        {
            ValidarDocumentoCentral(d.DocumentoId);
            if (!ids.Add(d.DocumentoId)) throw new NubeException("La migración contiene documentos repetidos.");
            return new { documento_id = d.DocumentoId, nombre = ValidarNombreNube(d.Nombre) };
        }).ToArray();
        await ExigirCentralAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_central_iniciar", new
        {
            p_base = baseId, p_revision = revision, p_migracion = migracion, p_documentos = manifest
        }, raiz =>
        {
            string estado = TextoNube(raiz, "estado", 16);
            if (estado is not ("preparando" or "activa") || GuidNube(raiz, "migracion_id") != migracion
                || GuidNube(raiz, "base_id") != baseId) throw RespuestaNubeInvalida();
            long recibida = RevisionNube(raiz);
            if (recibida != revision) throw RespuestaNubeInvalida();
            return new EstadoMigracionCentral(migracion, baseId, recibida, estado);
        }, ct, identidadEsperada: usuario);
    }

    /// <summary>Prepara una base nueva directamente en PostgreSQL, sin publicar antes un SQLite en Storage.</summary>
    public async Task<EstadoMigracionCentral> CrearBaseCentralAsync(Guid baseId, string nombre,
        Guid migracion, IReadOnlyList<DocumentoMigracionCentral> documentos, CancellationToken ct = default)
    {
        ValidarIdNube(baseId); ValidarIdNube(migracion); nombre = ValidarNombreNube(nombre);
        if (documentos is null || documentos.Count is < 1 or > 10000)
            throw new NubeException("La base necesita las identidades de sus obras.");
        var ids = new HashSet<string>(StringComparer.Ordinal);
        var manifest = documentos.Select(d =>
        {
            ValidarDocumentoCentral(d.DocumentoId);
            if (!ids.Add(d.DocumentoId)) throw new NubeException("La base contiene documentos repetidos.");
            return new { documento_id = d.DocumentoId, nombre = ValidarNombreNube(d.Nombre) };
        }).ToArray();
        await ExigirCentralAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_central_crear_base", new
        {
            p_base = baseId, p_nombre = nombre, p_migracion = migracion, p_documentos = manifest
        }, raiz =>
        {
            string estado = TextoNube(raiz, "estado", 16);
            if (estado is not ("preparando" or "activa") || GuidNube(raiz, "migracion_id") != migracion
                || GuidNube(raiz, "base_id") != baseId || RevisionNube(raiz) != 1) throw RespuestaNubeInvalida();
            return new EstadoMigracionCentral(migracion, baseId, 1, estado);
        }, ct, identidadEsperada: usuario);
    }

    public async Task PrepararDocumentoCentralAsync(Guid migracion, string documentoId,
        JsonElement contenido, CancellationToken ct = default)
    {
        ValidarIdNube(migracion); ValidarDocumentoCentral(documentoId);
        JsonElement copia = ValidarContenidoNube(contenido, ct);
        ValidarContenidoObraMismaBase(copia, documentoId);
        await ExigirCentralAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        JsonElement autocontenido = await PrepararContenidoComprimidoAsync(copia, ct);
        await EjecutarRpcNubeAsync("myg_central_preparar", new
        {
            p_migracion = migracion, p_documento = documentoId, p_contenido = autocontenido
        }, raiz =>
        {
            if (TextoNube(raiz, "estado", 16) != "preparado"
                || TextoNube(raiz, "documento_id", 200) != documentoId) throw RespuestaNubeInvalida();
            return true;
        }, ct, identidadEsperada: usuario);
    }

    public async Task<ProyectoNube> ActivarMigracionCentralAsync(Guid migracion, CancellationToken ct = default)
    {
        ValidarIdNube(migracion);
        await ExigirCentralAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_central_activar", new { p_migracion = migracion }, raiz =>
        {
            var central = LeerCentral(raiz, contenido: false);
            if (central.Alcance != "base" || central.Rol != "propietario") throw RespuestaNubeInvalida();
            return central;
        }, ct, identidadEsperada: usuario);
    }

    /// <summary>Conserva una sola vez los catálogos completos de la base, incluidos los todavía no usados.</summary>
    public async Task PrepararCatalogoCentralAsync(Guid migracion, JsonElement contenido,
        CancellationToken ct = default)
    {
        ValidarIdNube(migracion);
        var copia = ValidarContenidoNube(contenido, ct);
        ValidarCatalogoCentral(copia);
        await ExigirCentralAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        await EjecutarRpcNubeAsync("myg_central_preparar_catalogo", new
        {
            p_migracion = migracion, p_contenido = copia
        }, raiz =>
        {
            if (TextoNube(raiz, "estado", 16) != "preparado") throw RespuestaNubeInvalida();
            return true;
        }, ct, identidadEsperada: usuario);
    }

    /// <summary>El servidor entrega los catálogos completos únicamente al propietario de la base.</summary>
    public async Task<JsonElement> ObtenerCatalogoCentralAsync(Guid baseId, CancellationToken ct = default)
    {
        ValidarIdNube(baseId);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_central_catalogo", new { p_base = baseId }, raiz =>
        {
            ValidarCatalogoCentral(raiz);
            return ValidarContenidoNube(raiz, ct);
        }, ct, identidadEsperada: usuario);
    }

    public async Task<IReadOnlyList<ProyectoNube>> ListarObrasCentralAsync(Guid baseId, CancellationToken ct = default)
    {
        ValidarIdNube(baseId);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_central_obras", new { p_base = baseId }, raiz =>
        {
            ValidarArrayNube(raiz);
            var ids = new HashSet<Guid>(); var documentos = new HashSet<string>(StringComparer.Ordinal);
            var resultado = new List<ProyectoNube>();
            foreach (var elemento in raiz.EnumerateArray())
            {
                var obra = LeerCentral(elemento, contenido: false);
                if (!obra.EsObraMismaBase || obra.BaseId != baseId || !ids.Add(obra.Id)
                    || !documentos.Add(obra.DocumentoId!)) throw RespuestaNubeInvalida();
                resultado.Add(obra);
            }
            return (IReadOnlyList<ProyectoNube>)resultado.AsReadOnly();
        }, ct, identidadEsperada: usuario);
    }

    public async Task<ProyectoNube> CrearObraCentralAsync(Guid baseId, string documentoId, string nombre,
        JsonElement contenido, CancellationToken ct = default)
    {
        ValidarIdNube(baseId); ValidarDocumentoCentral(documentoId); nombre = ValidarNombreNube(nombre);
        JsonElement copia = ValidarContenidoNube(contenido, ct);
        ValidarContenidoObraMismaBase(copia, documentoId);
        await ExigirCentralAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        JsonElement autocontenido = await PrepararContenidoComprimidoAsync(copia, ct);
        return await EjecutarRpcNubeAsync("myg_central_crear_obra", new
        {
            p_base = baseId, p_documento = documentoId, p_nombre = nombre, p_contenido = autocontenido
        }, raiz =>
        {
            var obra = LeerCentral(raiz, contenido: true);
            if (obra.BaseId != baseId || obra.DocumentoId != documentoId || obra.Rol != "propietario")
                throw RespuestaNubeInvalida();
            return obra;
        }, ct, identidadEsperada: usuario);
    }

    public async Task<ProyectoNube> AbrirObraCentralAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_central_abrir", new { p_id = id },
            raiz => LeerCentral(raiz, contenido: true, esperado: id), ct, identidadEsperada: usuario);
    }

    private async Task<RespuestaGuardarNube> GuardarObraCentralAsync(Guid id, Guid operacion, long revision,
        JsonElement contenido, CancellationToken ct)
    {
        var obra = proyectosCentrales.TryGetValue(id, out var conocida) ? conocida
            : await ResolverCentralAsync(id, ct) ?? throw RespuestaNubeInvalida();
        if (!obra.EsObraMismaBase) throw new NubeException("Sincronice cada obra de la base central por separado.");
        ValidarContenidoObraMismaBase(contenido, obra.DocumentoId!);
        string usuario = await IdentidadArchivosAsync(ct);
        JsonElement autocontenido = await PrepararContenidoComprimidoAsync(contenido, ct);
        return await EjecutarRpcNubeAsync("myg_central_guardar", new
        {
            p_id = id, p_operacion = operacion, p_revision = revision, p_contenido = autocontenido
        }, raiz =>
        {
            string estado = TextoNube(raiz, "estado", 32);
            long recibida = RevisionNube(raiz);
            if (estado is not ("aplicada" or "conflicto") || GuidNube(raiz, "operacion_id") != operacion
                || recibida < revision || (estado == "aplicada" && recibida != revision + 1)) throw RespuestaNubeInvalida();
            JsonElement confirmado = ContenidoNube(raiz);
            ValidarContenidoObraMismaBase(confirmado, obra.DocumentoId!);
            return new RespuestaGuardarNube(estado, recibida, confirmado, operacion);
        }, ct, identidadEsperada: usuario);
    }

    private ProyectoNube LeerCentral(JsonElement raiz, bool contenido, Guid? esperado = null)
    {
        var proyecto = LeerProyectoNube(raiz, contenido, esperado);
        if (!proyecto.EsCentralNativa || (contenido && !proyecto.EsObraMismaBase)) throw RespuestaNubeInvalida();
        if (contenido) ValidarContenidoObraMismaBase(proyecto.Contenido, proyecto.DocumentoId!);
        RegistrarCentral(proyecto);
        return proyecto;
    }

    private void RegistrarCentral(ProyectoNube proyecto)
    {
        if (!proyecto.EsCentralNativa) return;
        capacidadCentral = true;
        proyectosCentrales[proyecto.Id] = proyecto with { Contenido = default };
        if (proyecto.EsObraMismaBase) vistasMismaBase[proyecto.Id] = proyecto with { Contenido = default };
    }

    private static void ValidarDocumentoCentral(string documentoId)
    {
        if (!TextoEntradaValido(documentoId, 200) || documentoId != documentoId.Trim())
            throw new NubeException("La obra necesita una identidad de documento válida.");
    }

    private static readonly HashSet<string> TablasCatalogoCentral = new(StringComparer.Ordinal)
    {
        "catalogo_unidad", "catalogo_insumo", "catalogo_partida", "catalogo_partida_nodo", "catalogo_partida_insumo", "catalogo_partida_recurso",
        "myg_indice_unificado", "unidad", "tipo_costo", "categoria", "producto", "lista_precio", "infraestructura", "propietario", "portafolio",
        "departamento", "provincia", "distrito", "localidad", "pais_info", "moneda", "clase", "subclase", "marca", "indice", "indice_precio",
        "region_precio", "responsable", "calendario",
        "unidad_map", "unidad_tipocosto", "unidad_tipocostonew", "horario", "horario_ex", "feriado", "excepcion",
        "plantilla_partida", "titulo_plantilla", "costo_unitarioplantilla", "precio_producto", "subclase_costo"
    };

    private static void ValidarCatalogoCentral(JsonElement contenido)
    {
        if (!ObjetoConCamposCatalogo(contenido, ["formato", "version", "tablas", "recursos"])
            || contenido.GetProperty("formato").ValueKind != JsonValueKind.String
            || contenido.GetProperty("formato").GetString() != "MYG_CATALOGO_BASE"
            || contenido.GetProperty("version").ValueKind != JsonValueKind.Number
            || !contenido.GetProperty("version").TryGetInt32(out int version) || version != 1
            || contenido.GetProperty("tablas").ValueKind != JsonValueKind.Array
            || contenido.GetProperty("recursos").ValueKind != JsonValueKind.Array) throw RespuestaNubeInvalida();
        var nombres = new HashSet<string>(StringComparer.Ordinal);
        foreach (var tabla in contenido.GetProperty("tablas").EnumerateArray())
        {
            if (!ObjetoConCamposCatalogo(tabla, ["Nombre", "Columnas", "Filas"])
                || tabla.GetProperty("Nombre").ValueKind != JsonValueKind.String
                || !TablasCatalogoCentral.Contains(tabla.GetProperty("Nombre").GetString()!)
                || !nombres.Add(tabla.GetProperty("Nombre").GetString()!)
                || tabla.GetProperty("Columnas").ValueKind != JsonValueKind.Array
                || tabla.GetProperty("Columnas").GetArrayLength() is < 1 or > 2000
                || tabla.GetProperty("Filas").ValueKind != JsonValueKind.Array) throw RespuestaNubeInvalida();
            var columnas = new HashSet<string>(StringComparer.Ordinal);
            foreach (var columna in tabla.GetProperty("Columnas").EnumerateArray())
                if (columna.ValueKind != JsonValueKind.String || !TextoEntradaValido(columna.GetString()!, 200)
                    || !columnas.Add(columna.GetString()!)) throw RespuestaNubeInvalida();
            foreach (var fila in tabla.GetProperty("Filas").EnumerateArray())
            {
                if (fila.ValueKind != JsonValueKind.Array || fila.GetArrayLength() != columnas.Count) throw RespuestaNubeInvalida();
                foreach (var celda in fila.EnumerateArray())
                    if (!ObjetoConCamposCatalogo(celda, ["Tipo", "Valor"])
                        || celda.GetProperty("Tipo").ValueKind != JsonValueKind.String
                        || celda.GetProperty("Tipo").GetString() is not ("nulo" or "entero" or "real" or "texto" or "blob")
                        || celda.GetProperty("Valor").ValueKind is not (JsonValueKind.String or JsonValueKind.Null))
                        throw RespuestaNubeInvalida();
            }
        }
        var referencias = new HashSet<string>(StringComparer.Ordinal);
        foreach (var recurso in contenido.GetProperty("recursos").EnumerateArray())
        {
            if (!ObjetoConCamposCatalogo(recurso, ["Referencia", "Nombre", "Sha256", "Base64", "Almacen"])
                || recurso.GetProperty("Referencia").ValueKind != JsonValueKind.String
                || !TextoEntradaValido(recurso.GetProperty("Referencia").GetString()!, 2000)
                || !referencias.Add(recurso.GetProperty("Referencia").GetString()!)
                || recurso.GetProperty("Nombre").ValueKind != JsonValueKind.String
                || recurso.GetProperty("Sha256").ValueKind != JsonValueKind.String
                || recurso.GetProperty("Sha256").GetString() is not { Length: 64 } hash || !hash.All(char.IsAsciiHexDigit)
                || recurso.GetProperty("Base64").ValueKind != JsonValueKind.String
                || recurso.GetProperty("Almacen").ValueKind is not (JsonValueKind.Null or JsonValueKind.String)
                || recurso.GetProperty("Almacen").ValueKind == JsonValueKind.String
                    && recurso.GetProperty("Almacen").GetString() != "") throw RespuestaNubeInvalida();
        }
    }

    private static bool ObjetoConCamposCatalogo(JsonElement objeto, string[] campos)
    {
        if (objeto.ValueKind != JsonValueKind.Object) return false;
        var nombres = new HashSet<string>(StringComparer.Ordinal);
        foreach (var propiedad in objeto.EnumerateObject())
            if (!campos.Contains(propiedad.Name, StringComparer.Ordinal) || !nombres.Add(propiedad.Name)) return false;
        return nombres.Count == campos.Length;
    }
}
