using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MYG.Colaboracion;

/// <summary>Destino de la nube y clave pública. No contiene identidad ni sesiones de usuario.</summary>
public sealed record ConfiguracionServicioNube(string Nombre, string Url, string ClavePublicable)
{
    /// <summary>Servicio HTTPS que proyecta obras de la misma base. Nunca contiene credenciales.</summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? ServicioBasesUrl { get; init; }
    private const int MaximoBytes = 64 * 1024;

    /// <summary>Conserva la conexión local. Los perfiles anteriores pueden heredar
    /// solo el servicio distribuido para el mismo Supabase, sin reescribir archivos.</summary>
    public static ConfiguracionServicioNube? Cargar(string rutaLocal, string rutaDistribuida)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(rutaLocal);
        ArgumentException.ThrowIfNullOrWhiteSpace(rutaDistribuida);
        var local = LeerSiExiste(rutaLocal);
        if (local is null) return LeerSiExiste(rutaDistribuida);
        // Null (o campo ausente) permite la actualización automática. Una cadena
        // local, incluso vacía, es una elección explícita y se conserva.
        if (local.ServicioBasesUrl is not null || string.Equals(Path.GetFullPath(rutaLocal),
            Path.GetFullPath(rutaDistribuida), OperatingSystem.IsWindows()
                ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)) return local;
        ConfiguracionServicioNube? distribuida;
        try { distribuida = LeerSiExiste(rutaDistribuida); }
        catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or NubeException)
        {
            // La distribución opcional nunca invalida un perfil local correcto.
            return local;
        }
        if (string.IsNullOrWhiteSpace(distribuida?.ServicioBasesUrl)) return local;
        var origenLocal = new Uri(local.Url).GetLeftPart(UriPartial.Authority);
        var origenDistribuido = new Uri(distribuida.Url).GetLeftPart(UriPartial.Authority);
        return string.Equals(origenLocal, origenDistribuido, StringComparison.OrdinalIgnoreCase)
            ? local with { ServicioBasesUrl = distribuida.ServicioBasesUrl } : local;
    }

    private static ConfiguracionServicioNube? LeerSiExiste(string ruta)
    {
        FileStream archivo;
        try { archivo = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.Read); }
        catch (FileNotFoundException) { return null; }
        catch (DirectoryNotFoundException) { return null; }

        using (archivo)
        {
            if (archivo.Length > MaximoBytes)
                throw new InvalidDataException("La configuración de Nube MYG excede el tamaño permitido.");
            using var contenido = new MemoryStream();
            byte[] bloque = new byte[4096];
            int cantidad;
            while ((cantidad = archivo.Read(bloque)) != 0)
            {
                if (contenido.Length + cantidad > MaximoBytes)
                    throw new InvalidDataException("La configuración de Nube MYG excede el tamaño permitido.");
                contenido.Write(bloque, 0, cantidad);
            }
            contenido.Position = 0;
            // Mantener los archivos UTF-8/UTF-16 con BOM que admitía
            // File.ReadAllText, conservando el límite sobre sus bytes originales.
            using var lector = new StreamReader(contenido, new UTF8Encoding(false, true),
                detectEncodingFromByteOrderMarks: true);
            string texto;
            try { texto = lector.ReadToEnd(); }
            catch (DecoderFallbackException ex)
            { throw new InvalidDataException("La configuración de Nube MYG contiene texto inválido.", ex); }
            var configuracion = JsonSerializer.Deserialize<ConfiguracionServicioNube>(texto)
                ?? throw new InvalidDataException("La configuración de Nube MYG está vacía.");
            Validar(configuracion);
            return configuracion;
        }
    }

    public static void Validar(ConfiguracionServicioNube configuracion)
    {
        ArgumentNullException.ThrowIfNull(configuracion);
        if (string.IsNullOrWhiteSpace(configuracion.Nombre) || configuracion.Nombre.Length > 100)
            throw new InvalidDataException("Introduzca un nombre de conexión de hasta 100 caracteres.");
        // Construir el cliente sólo valida el destino HTTPS y una clave pública/anon;
        // no envía solicitudes ni permite credenciales secretas o service_role.
        using var cliente = new ClienteSupabase(configuracion.Url, configuracion.ClavePublicable);
        cliente.ServicioBasesUrl = configuracion.ServicioBasesUrl;
    }

    public static void Guardar(string ruta, ConfiguracionServicioNube configuracion)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(ruta);
        Validar(configuracion);
        byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(configuracion,
            new JsonSerializerOptions { WriteIndented = true });
        if (bytes.Length > MaximoBytes)
            throw new InvalidDataException("La configuración de Nube MYG excede el tamaño permitido.");

        string destino = Path.GetFullPath(ruta);
        Directory.CreateDirectory(Path.GetDirectoryName(destino)!);
        string temporal = destino + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var archivo = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write,
                FileShare.None, 4096, FileOptions.WriteThrough))
            {
                archivo.Write(bytes);
                archivo.Flush(flushToDisk: true);
            }
            File.Move(temporal, destino, overwrite: true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }
}
