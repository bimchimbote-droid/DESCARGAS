using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG_2027;

namespace MYG.Colaboracion;

public static partial class BaseCentralNube
{
    /// <summary>La creación de una obra conserva su primer contenido antes del
    /// HTTP. Un ACK perdido no adopta como confirmadas ediciones posteriores.</summary>
    public static async Task<ProyectoNube> RegistrarObraAsync(ClienteSupabase cliente, string ruta,
        Guid baseId, string documentoId, CancellationToken ct = default)
    {
        var identidad = LeerBase(ruta) ?? throw new InvalidOperationException("Abra la base central antes de agregar una obra.");
        ValidarIdentidad(cliente, identidad);
        if (identidad.BaseId != baseId) throw new InvalidOperationException("La obra pertenece a otra base.");
        string carpeta = Path.GetFullPath(ruta) + ".central-obras";
        Directory.CreateDirectory(carpeta);
        string clave = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(documentoId)));
        using var bloqueo = new FileStream(Path.Combine(carpeta, clave + ".lock"), FileMode.OpenOrCreate,
            FileAccess.ReadWrite, FileShare.None);
        var obras = await cliente.ListarObrasCentralAsync(baseId, ct);
        var obra = obras.SingleOrDefault(o => o.DocumentoId == documentoId);
        var vinculo = MYGColaboracionLocal.Leer(ruta, documentoId);
        if (obra is not null && vinculo is not null)
        {
            if (vinculo.ProyectoId != obra.Id) throw new InvalidOperationException("La obra local tiene otro vínculo.");
            SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
            return obra;
        }
        string intento = Path.Combine(carpeta, clave + ".json");
        if (!File.Exists(intento))
        {
            if (obra is not null)
                throw new InvalidOperationException("La obra ya existe en la nube, pero esta copia no conserva su creación confirmada. Conserve sus cambios locales y abra la obra desde Nube MYG.");
            var contenido = CrearContenidoEstricto(ruta, documentoId);
            string temporal = intento + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var archivo = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    var bytes = JsonSerializer.SerializeToUtf8Bytes(contenido, Json);
                    archivo.Write(bytes); archivo.Flush(flushToDisk: true);
                }
                File.Move(temporal, intento);
            }
            finally { if (File.Exists(temporal)) File.Delete(temporal); }
        }
        using var congelado = JsonDocument.Parse(File.ReadAllBytes(intento), new JsonDocumentOptions { MaxDepth = 128 });
        var documento = PaqueteNube.LeerDocumento(congelado.RootElement);
        if (documento.Id != documentoId) throw new InvalidDataException("La preparación corresponde a otra obra.");
        // El listado permite recuperar un commit cuya respuesta no llegó sin
        // reenviar una creación con el borrador más reciente del usuario.
        obra ??= await cliente.CrearObraCentralAsync(baseId, documentoId, documento.Nombre,
            congelado.RootElement, ct);
        VincularObraLocal(cliente, ruta, obra with { Revision = 1, Contenido = congelado.RootElement.Clone() });
        return obra;
    }
}
