-- SOLO PostgreSQL desechable. Nunca ejecutar este fixture en Supabase real.
\set ON_ERROR_STOP on
\ir colaboracion_misma_base.sql
reset role;
\ir ../migraciones/20261106_base_central.sql
\ir ../migraciones/20261106_base_central.sql
select qa.exige(not has_table_privilege('authenticated','myg_nube_privado.central_documentos','select')
    and not has_table_privilege('service_role','myg_nube_privado.central_preparados','insert')
    and not has_function_privilege('anon','public.myg_central_listar()','execute')
    and not has_function_privilege('authenticated','myg_nube_privado.central_meta(uuid,uuid)','execute')
    and not has_function_privilege('authenticated','myg_nube_privado.central_legacy_myg_nube_abrir(uuid)','execute'),
    'Central: tablas privadas, auxiliares y rutas anteriores no son API alternativa');
create table qa.central_payload(nombre text primary key,contenido jsonb not null);
insert into qa.central_payload select nombre,contenido from qa.paquetes
    where nombre in ('baseline','nombre','acu_precio','especificacion','cantidad');
insert into qa.central_payload select 'segunda',replace(contenido::text,'QA-DOCUMENTO','QA-DOCUMENTO-B')::jsonb
    from qa.paquetes where nombre='baseline';
grant select on qa.central_payload to authenticated,service_role;
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000001/d9500000000000000000000000000001/'||repeat('a',64)||'.sqlite','{"size":4096}');
select public.myg_nube_sqlite_crear('d9500000-0000-0000-0000-000000000001','Base central QA','base','QA-DOCUMENTO',
    '00000000-0000-0000-0000-000000000001/d9500000000000000000000000000001/'||repeat('a',64)||'.sqlite',repeat('a',64),4096);
create temporary table central_vistas as select
    public.myg_base_registrar('d9500000-0000-0000-0000-000000000001','QA-DOCUMENTO','Obra A') a,
    public.myg_base_registrar('d9500000-0000-0000-0000-000000000001','QA-DOCUMENTO-B','Obra B') b;
select public.myg_base_compartir_usuario((a->>'id')::uuid,'ajeno','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}') from central_vistas;
select public.myg_base_compartir_usuario((a->>'id')::uuid,'lector','lector',
    '{"acu":false,"especificaciones":false,"metrados_excel":false,"metrados_revit":false}') from central_vistas;
reset role;
grant select on central_vistas to authenticated,service_role;
create table qa.central_antes as select
    (select count(*) from public.myg_nube_proyectos) proyectos,
    (select count(*) from storage.objects) objetos,
    (select count(*) from myg_nube_privado.sqlite_revisiones) revisiones;
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_central_iniciar('d9500000-0000-0000-0000-000000000001',1,
    'c9500000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"Obra A"}]')$$,
    '42501','Central: colaborador de obra no puede iniciar migración de la base');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_central_capacidades()->>'version'='1','Central: capacidad independiente sin servicio adicional');
select qa.rechaza($$select public.myg_central_iniciar('d9500000-0000-0000-0000-000000000001',1,
    'c9500000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"A"},{"documento_id":"QA-DOCUMENTO","nombre":"B"}]')$$,
    '22023','Central: manifiesto duplicado rechazado antes de modificar datos');
select qa.exige(public.myg_central_iniciar('d9500000-0000-0000-0000-000000000001',1,
    'c9500000-0000-0000-0000-000000000001',
    '[{"documento_id":"QA-DOCUMENTO","nombre":"Obra A"},{"documento_id":"QA-DOCUMENTO-B","nombre":"Obra B"}]')->>'estado'='preparando',
    'Central: iniciar solo prepara, conserva operativa la fuente anterior');
select qa.exige(public.myg_central_iniciar('d9500000-0000-0000-0000-000000000001',1,
    'c9500000-0000-0000-0000-000000000001',
    '[{"documento_id":"QA-DOCUMENTO-B","nombre":"Obra B"},{"documento_id":"QA-DOCUMENTO","nombre":"Obra A"}]')->>'estado'='preparando',
    'Central: reintentar manifiesto ordenado conserva el UUID de migración');
select qa.rechaza($$select public.myg_central_iniciar('d9500000-0000-0000-0000-000000000001',1,
    'c9500000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"Otro"}]')$$,
    '22023','Central: UUID de migración no acepta otro manifiesto');
select qa.rechaza($$select public.myg_central_activar('c9500000-0000-0000-0000-000000000001')$$,
    '22023','Central: no activa un manifiesto sin sus documentos completos');
select qa.rechaza($$select public.myg_central_preparar('c9500000-0000-0000-0000-000000000001','QA-DOCUMENTO-B',contenido)
    from qa.central_payload where nombre='baseline'$$,'22023','Central: cada paquete debe corresponder exactamente a su obra');
select public.myg_central_preparar('c9500000-0000-0000-0000-000000000001','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='baseline';
select qa.rechaza($$select public.myg_central_preparar('c9500000-0000-0000-0000-000000000001','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='nombre'$$,'22023','Central: reenvío parcial no cambia los bytes preparados');
select qa.rechaza($$select public.myg_central_activar('c9500000-0000-0000-0000-000000000001')$$,
    '22023','Central: un corte entre obras no activa una base incompleta');
select qa.exige(public.myg_nube_sqlite_consultar('d9500000-0000-0000-0000-000000000001')->>'revision'='1',
    'Central: durante preparación el SQLite original sigue accesible');
select public.myg_central_preparar('c9500000-0000-0000-0000-000000000001','QA-DOCUMENTO-B',contenido)
    from qa.central_payload where nombre='segunda';
select qa.rechaza($$select public.myg_central_activar('c9500000-0000-0000-0000-000000000001')$$,
    '22023','Central: catálogo propietario también debe prepararse antes de activar');
select qa.rechaza($$select public.myg_central_preparar_catalogo('c9500000-0000-0000-0000-000000000001',
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[{"Nombre":"usuario","Columnas":[],"Filas":[]}],"recursos":[]}')$$,
    '22023','Central: catálogo no acepta tablas privadas ni documentos ajenos');
select public.myg_central_preparar_catalogo('c9500000-0000-0000-0000-000000000001',
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[{"Nombre":"catalogo_unidad","Columnas":["id","nombre"],
    "Filas":[[{"Tipo":"entero","Valor":"9999"},{"Tipo":"texto","Valor":"Unidad sin referencias"}]]}],"recursos":[]}');
select qa.exige(public.myg_central_activar('c9500000-0000-0000-0000-000000000001')->>'central_nativa'='true',
    'Central: activación atómica mantiene el UUID de base');
select qa.exige(public.myg_central_activar('c9500000-0000-0000-0000-000000000001')->>'id'='d9500000-0000-0000-0000-000000000001',
    'Central: ACK perdido al activar no duplica documentos');
select qa.exige(public.myg_central_iniciar('d9500000-0000-0000-0000-000000000001',1,
    'c9500000-0000-0000-0000-000000000001',
    '[{"documento_id":"QA-DOCUMENTO","nombre":"Obra A"},{"documento_id":"QA-DOCUMENTO-B","nombre":"Obra B"}]')->>'estado'='activa',
    'Central: recuperar intento después de activar informa estado confirmado');
select qa.exige(jsonb_array_length(public.myg_central_obras('d9500000-0000-0000-0000-000000000001'))=2
    and public.myg_central_abrir((a->>'id')::uuid)->>'id'=a->>'id'
    and public.myg_base_resolver((a->>'id')::uuid)->>'central_nativa'='true',
    'Central: conserva UUID de vistas existentes y metadatos de ambas obras') from central_vistas;
select qa.exige((select count(*)=1 from jsonb_array_elements(public.myg_nube_listar())
    where value->>'id'='d9500000-0000-0000-0000-000000000001' and value->>'central_nativa'='true'),
    'Central: listado compatible sustituye la entrada antigua sin duplicarla');
select qa.rechaza($$select public.myg_nube_sqlite_abrir('d9500000-0000-0000-0000-000000000001')$$,'MGN01',
    'Central: cliente binario antiguo recibe aviso de actualización');
select qa.rechaza($$select public.myg_nube_abrir((a->>'id')::uuid) from central_vistas$$,'MGN01',
    'Central: cliente frío puede resolver la ruta nativa explícitamente');
select qa.rechaza($$select public.myg_nube_miembros((a->>'id')::uuid) from central_vistas$$,'MGN01',
    'Central: gestión fría de ACL también indica ruta nativa');
select qa.rechaza($$select public.myg_central_preparar('c9500000-0000-0000-0000-000000000001','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='nombre'$$,'22023','Central: paquete diferente tras activar tampoco suplanta el intento');
reset role;
select qa.exige((select count(*) from public.myg_nube_proyectos)=(select proyectos from qa.central_antes)
    and (select count(*) from storage.objects)=(select objetos from qa.central_antes)
    and (select count(*) from myg_nube_privado.sqlite_revisiones)=(select revisiones from qa.central_antes)
    and not exists(select 1 from myg_nube_privado.central_preparados where migracion_id='c9500000-0000-0000-0000-000000000001'),
    'Central: activación no publica archivos ni proyectos y retira staging duplicado');
select qa.rechaza($$update public.myg_nube_proyectos set actualizado_en=clock_timestamp()
    where id='d9500000-0000-0000-0000-000000000001'$$,'MGN01','Central: escritura antigua no modifica la fuente congelada');
select qa.rechaza($$delete from public.myg_nube_proyectos where id='d9500000-0000-0000-0000-000000000001'$$,
    'MGN01','Central: borrado binario antiguo no deja documentos huérfanos');
select qa.rechaza($$insert into myg_nube_privado.bim_documentos(proyecto_id,documento_id,revision,contenido)
    values('d9500000-0000-0000-0000-000000000001','QA-DOCUMENTO',1,'{"presupuestos":[]}')$$,
    'MGN01','Central: cliente BIM antiguo no abre otra fuente paralela');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige(public.myg_central_resolver('d9500000-0000-0000-0000-000000000001') is null
    and jsonb_array_length(public.myg_central_obras('d9500000-0000-0000-0000-000000000001'))=1,
    'Central: colaborador no recibe la base ni el listado de obras ajenas');
select qa.rechaza($$select public.myg_central_catalogo('d9500000-0000-0000-0000-000000000001')$$,'42501',
    'Central: catálogo completo no se entrega al colaborador de una obra');
select qa.exige(public.myg_central_abrir((a->>'id')::uuid)#>>'{contenido,documento,Id}'='QA-DOCUMENTO',
    'Central: respuesta de apertura contiene únicamente la obra autorizada') from central_vistas;
select qa.rechaza($$select public.myg_central_abrir((b->>'id')::uuid) from central_vistas$$,'42501',
    'Central: conocer el UUID de otra obra no permite leerla');
select qa.rechaza($$select public.myg_central_crear_obra('d9500000-0000-0000-0000-000000000001','QA-DOCUMENTO-B','B',contenido)
    from qa.central_payload where nombre='segunda'$$,'42501','Central: colaborador no crea obras en base ajena');
select qa.exige((select public.myg_central_guardar((a->>'id')::uuid,'c9510000-0000-0000-0000-000000000001',1,contenido)->>'revision'='2'
    from central_vistas,qa.central_payload where nombre='nombre'),'Central: edición actualiza la misma obra');
select qa.exige((select public.myg_central_guardar((a->>'id')::uuid,'c9510000-0000-0000-0000-000000000001',1,contenido)->>'revision'='2'
    from central_vistas,qa.central_payload where nombre='nombre'),'Central: ACK perdido no duplica revisión');
select qa.rechaza($$select public.myg_central_guardar((a->>'id')::uuid,'c9510000-0000-0000-0000-000000000001',1,contenido)
    from central_vistas,qa.central_payload where nombre='baseline'$$,'22023','Central: UUID de edición rechaza cuerpo diferente');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_central_abrir((b->>'id')::uuid)->>'revision'='1'
    and public.myg_central_abrir((b->>'id')::uuid)->'contenido'=(select contenido from qa.central_payload where nombre='segunda'),
    'Central: editar obra A conserva contenido y revisión de obra B') from central_vistas;
select qa.exige(public.myg_central_catalogo('d9500000-0000-0000-0000-000000000001')#>>'{tablas,0,Filas,0,1,Valor}'='Unidad sin referencias',
    'Central: conserva catálogo propietario aunque ninguna obra lo referencie');
select qa.exige((select public.myg_central_guardar((a->>'id')::uuid,'c9510000-0000-0000-0000-000000000002',1,contenido)->>'estado'='conflicto'
    from central_vistas,qa.central_payload where nombre='acu_precio'),'Central: CAS conserva cambios ajenos ante revisión atrasada');
select public.myg_base_permisos((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    '{"acu":false,"especificaciones":false,"metrados_excel":false,"metrados_revit":false}') from central_vistas;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_central_guardar((a->>'id')::uuid,'c9510000-0000-0000-0000-000000000003',2,contenido)
    from central_vistas,qa.central_payload where nombre='acu_precio'$$,'42501','Central: módulo ACU restringido se verifica en servidor');
select qa.rechaza($$select public.myg_central_guardar((a->>'id')::uuid,'c9510000-0000-0000-0000-000000000004',2,
    jsonb_set(jsonb_set(contenido,'{documento,Presupuestos,0,Items,0,Plantilla}','"Revit restringido"'),
        '{documentos,0,Presupuestos,0,Items,0,Plantilla}','"Revit restringido"'))
    from central_vistas,qa.central_payload where nombre='nombre'$$,'42501','Central: Revit restringido tampoco se modifica por RPC directo');
select qa.rechaza($$select public.myg_central_guardar((a->>'id')::uuid,'c9510000-0000-0000-0000-000000000001',1,contenido)
    from central_vistas,qa.central_payload where nombre='nombre'$$,'42501','Central: replay no evade permisos revocados después del ACK');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.rechaza($$select public.myg_central_guardar((a->>'id')::uuid,gen_random_uuid(),2,contenido)
    from central_vistas,qa.central_payload where nombre='nombre'$$,'42501','Central: lector no guarda aunque presente contenido válido');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_base_rol((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',null) from central_vistas;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_central_abrir((a->>'id')::uuid) from central_vistas$$,'42501',
    'Central: revocar membresía corta lecturas posteriores');
reset role;
create table qa.central_reinstalacion as select
    (select jsonb_agg(to_jsonb(d) order by vista_id) from myg_nube_privado.central_documentos d) documentos,
    (select jsonb_agg(to_jsonb(m) order by vista_id,usuario_id) from myg_nube_privado.base_vista_miembros m) miembros;
\ir ../migraciones/20261106_base_central.sql
select qa.exige((select documentos=(select jsonb_agg(to_jsonb(d) order by vista_id) from myg_nube_privado.central_documentos d)
    and miembros=(select jsonb_agg(to_jsonb(m) order by vista_id,usuario_id) from myg_nube_privado.base_vista_miembros m)
    from qa.central_reinstalacion),'Central: reinstalar preserva exactamente datos, revisiones y permisos');
select qa.exige((select count(*) from storage.objects)=(select objetos from qa.central_antes)
    and (select count(*) from myg_nube_privado.sqlite_revisiones)=(select revisiones from qa.central_antes),
    'Central: colaborar y editar no crean nuevas copias SQLite en Storage');

-- Creación nueva: desde el primer envío los datos se guardan por obra; no se
-- exige subir un SQLite inicial ni configurar un segundo servidor.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_central_crear_base('d9600000-0000-0000-0000-000000000001','Nueva base directa',
    'c9600000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"Obra nueva"}]')->>'revision'='1',
    'Central: crea base nueva sin publicar previamente un archivo');
select qa.exige(not exists(select 1 from jsonb_array_elements(public.myg_nube_listar())
    where value->>'id'='d9600000-0000-0000-0000-000000000001'),
    'Central: el listado no anuncia una base nueva incompleta');
select qa.exige(public.myg_central_crear_base('d9600000-0000-0000-0000-000000000001','Nueva base directa',
    'c9600000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"Obra nueva"}]')->>'estado'='preparando',
    'Central: reintento de creación conserva identidad y manifiesto');
select qa.rechaza($$select public.myg_central_crear_base('d9600000-0000-0000-0000-000000000001','Otro nombre',
    'c9600000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"Obra nueva"}]')$$,
    '22023','Central: creación no reutiliza base ID con otro cuerpo');
select public.myg_central_preparar('c9600000-0000-0000-0000-000000000001','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='baseline';
select public.myg_central_preparar_catalogo('c9600000-0000-0000-0000-000000000001',
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[],"recursos":[]}');
select qa.exige(public.myg_central_activar('c9600000-0000-0000-0000-000000000001')->>'central_nativa'='true',
    'Central: base creada directamente se activa con su obra íntegra');
select qa.exige((public.myg_central_crear_obra('d9600000-0000-0000-0000-000000000001',
    'QA-DOCUMENTO-B','Segunda nueva',(select contenido from qa.central_payload where nombre='segunda'))->>'revision')='1',
    'Central: propietario agrega una obra posterior sin volver a publicar la base');
select qa.exige(jsonb_array_length(public.myg_central_obras('d9600000-0000-0000-0000-000000000001'))=2,
    'Central: nueva obra pertenece a la misma base existente');
reset role;
select qa.exige(not exists(select 1 from myg_nube_privado.sqlite_revisiones where proyecto_id='d9600000-0000-0000-0000-000000000001')
    and not exists(select 1 from storage.objects where name like '%/d9600000000000000000000000000001/%'),
    'Central: crear y ampliar base nativa no crea binarios de nube');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_nube_base_eliminacion_iniciar('d9600000-0000-0000-0000-000000000001',
    'e9600000-0000-0000-0000-000000000001')$$,'42501','Central: otro usuario no inicia borrado');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_base_eliminacion_iniciar('d9600000-0000-0000-0000-000000000001',
    'e9600000-0000-0000-0000-000000000001')->>'estado'='pendiente',
    'Central: borrado usa manifiesto autorizado y congela la base');
select qa.exige(public.myg_central_resolver('d9600000-0000-0000-0000-000000000001')->>'eliminacion_pendiente'='true',
    'Central: propietario puede recuperar el borrado pendiente');
select qa.exige(public.myg_nube_base_eliminacion_iniciar('d9600000-0000-0000-0000-000000000001',
    'e9600000-0000-0000-0000-000000000002')->>'operacion_id'='e9600000-0000-0000-0000-000000000001',
    'Central: reabrir borrado con UUID nuevo recupera el job anterior');
select qa.exige(public.myg_nube_base_eliminacion_finalizar('e9600000-0000-0000-0000-000000000001')->>'estado'='eliminada',
    'Central: sin objetos Storage finaliza borrado transaccional');
select qa.exige(public.myg_nube_base_eliminacion_finalizar('e9600000-0000-0000-0000-000000000001')->>'estado'='eliminada',
    'Central: ACK perdido del borrado conserva el tombstone');
select qa.rechaza($$select public.myg_central_crear_base('d9600000-0000-0000-0000-000000000001','No resucitar',
    'c9600000-0000-0000-0000-000000000002','[{"documento_id":"QA-DOCUMENTO","nombre":"A"}]')$$,
    '22023','Central: no resucita un UUID borrado');
reset role;
select qa.exige(not exists(select 1 from myg_nube_privado.central_documentos where base_id='d9600000-0000-0000-0000-000000000001')
    and not exists(select 1 from public.myg_nube_proyectos where id='d9600000-0000-0000-0000-000000000001'),
    'Central: borrado retira datos centrales y metadatos sin huérfanos');

-- La fuente puede seguir recibiendo escrituras mientras se prepara la migración.
-- La activación compara su revisión: jamás sustituye silenciosamente esos datos.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
insert into storage.objects(bucket_id,name,metadata) values
    ('myg-nube-sqlite','00000000-0000-0000-0000-000000000001/d9700000000000000000000000000001/'||repeat('a',64)||'.sqlite','{"size":4096}'),
    ('myg-nube-sqlite','00000000-0000-0000-0000-000000000001/d9700000000000000000000000000001/'||repeat('b',64)||'.sqlite','{"size":8192}');
select public.myg_nube_sqlite_crear('d9700000-0000-0000-0000-000000000001','Cambio durante migración','base','QA-DOCUMENTO',
    '00000000-0000-0000-0000-000000000001/d9700000000000000000000000000001/'||repeat('a',64)||'.sqlite',repeat('a',64),4096);
select public.myg_central_iniciar('d9700000-0000-0000-0000-000000000001',1,'c9700000-0000-0000-0000-000000000001',
    '[{"documento_id":"QA-DOCUMENTO","nombre":"A"}]');
select public.myg_central_preparar('c9700000-0000-0000-0000-000000000001','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='baseline';
select public.myg_central_preparar_catalogo('c9700000-0000-0000-0000-000000000001',
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[],"recursos":[]}');
select public.myg_nube_sqlite_guardar('d9700000-0000-0000-0000-000000000001','c9710000-0000-0000-0000-000000000001',1,
    '00000000-0000-0000-0000-000000000001/d9700000000000000000000000000001/'||repeat('b',64)||'.sqlite',repeat('b',64),8192);
select qa.rechaza($$select public.myg_central_activar('c9700000-0000-0000-0000-000000000001')$$,'22023',
    'Central: CAS impide activar si la fuente cambió después de iniciar');
select qa.exige(public.myg_nube_sqlite_consultar('d9700000-0000-0000-0000-000000000001')->>'revision'='2'
    and public.myg_central_resolver('d9700000-0000-0000-0000-000000000001') is null,
    'Central: fallo CAS conserva el archivo y la revisión más reciente');
reset role;
insert into myg_nube_privado.bim_documentos(proyecto_id,documento_id,revision,contenido)
    select 'd9700000-0000-0000-0000-000000000001','QA-DOCUMENTO',1,contenido from qa.bim_payload where nombre='uno';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$select public.myg_central_iniciar('d9700000-0000-0000-0000-000000000001',2,
    'c9700000-0000-0000-0000-000000000002','[{"documento_id":"QA-DOCUMENTO","nombre":"A"}]')$$,
    '55000','Central: BIM separado pendiente impide iniciar una migración que lo descartaría');
reset role;
update myg_nube_privado.bim_documentos set contenido='{"presupuestos":[]}',revision=2
    where proyecto_id='d9700000-0000-0000-0000-000000000001';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_central_iniciar('d9700000-0000-0000-0000-000000000001',2,'c9700000-0000-0000-0000-000000000002',
    '[{"documento_id":"QA-DOCUMENTO","nombre":"A"}]');
select public.myg_central_preparar('c9700000-0000-0000-0000-000000000002','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='baseline';
select public.myg_central_preparar_catalogo('c9700000-0000-0000-0000-000000000002',
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[],"recursos":[]}');
reset role;
update myg_nube_privado.bim_documentos set contenido=(select contenido from qa.bim_payload where nombre='uno'),revision=3
    where proyecto_id='d9700000-0000-0000-0000-000000000001';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$select public.myg_central_activar('c9700000-0000-0000-0000-000000000002')$$,
    '55000','Central: BIM concurrente también impide activar sin su integración');
reset role;

-- Retirar un intento fallido libera sus paquetes y permite empezar con otra
-- revisión/UUID, sin tocar la base operativa ni una migración ya activada.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_central_cancelar('c9700000-0000-0000-0000-000000000001')$$,'42501',
    'Central: otro usuario no puede cancelar el intento del propietario');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$select public.myg_central_cancelar('c9500000-0000-0000-0000-000000000001')$$,'22023',
    'Central: cancelar nunca retira datos de una base ya activada');
select qa.exige(public.myg_central_cancelar('c9700000-0000-0000-0000-000000000001')->>'estado'='cancelada'
    and public.myg_central_cancelar('c9700000-0000-0000-0000-000000000001')->>'estado'='cancelada',
    'Central: cancelar un intento fallido es idempotente');
select qa.rechaza($$select public.myg_central_preparar('c9700000-0000-0000-0000-000000000001','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='baseline'$$,'22023','Central: paquetes antiguos no resucitan un intento cancelado');
select qa.exige(public.myg_central_cancelar('c9700000-0000-0000-0000-000000000002')->>'estado'='cancelada',
    'Central: segundo intento fallido también puede retirarse');
reset role;
select qa.exige(not exists(select 1 from myg_nube_privado.central_preparados
        where migracion_id in ('c9700000-0000-0000-0000-000000000001','c9700000-0000-0000-0000-000000000002'))
    and not exists(select 1 from myg_nube_privado.central_migraciones where base_id='d9700000-0000-0000-0000-000000000001'
        and (catalogo is not null or catalogo_sha is not null or huellas<>'{}'::jsonb))
    and exists(select 1 from myg_nube_privado.central_documentos where base_id='d9500000-0000-0000-0000-000000000001'),
    'Central: cancelar libera staging y conserva obras ya activadas');
update myg_nube_privado.bim_documentos set contenido='{"presupuestos":[]}',revision=4
    where proyecto_id='d9700000-0000-0000-0000-000000000001';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_central_iniciar('d9700000-0000-0000-0000-000000000001',2,
    'c9700000-0000-0000-0000-000000000003','[{"documento_id":"QA-DOCUMENTO","nombre":"A"}]')->>'estado'='preparando',
    'Central: después de cancelar se puede preparar la revisión actual con otro UUID');
select qa.rechaza($$select public.myg_central_iniciar('d9700000-0000-0000-0000-000000000001',1,
    'c9700000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"A"}]')$$,
    '22023','Central: UUID cancelado no inicia otra migración');
select qa.exige(public.myg_nube_sqlite_consultar('d9700000-0000-0000-0000-000000000001')->>'revision'='2',
    'Central: cancelar y reintentar conserva la fuente SQLite actual');
reset role;
