-- Colaboración nativa en Supabase. La base conserva su UUID y sus permisos por
-- obra; PostgreSQL pasa a ser la fuente colaborativa. El SQLite previo queda
-- como respaldo privado, no se crea ningún archivo ni dato por colaborador.
-- Ejecutar COMPLETO después de 20261105_colaboracion_misma_base.sql.
begin;

do $preflight$
begin
    if to_regclass('myg_nube_privado.base_vistas') is null
       or to_regprocedure('myg_nube_privado.base_vista_meta(uuid,uuid,bigint)') is null
       or to_regprocedure('myg_nube_privado.validar_contenido(jsonb)') is null
       or to_regprocedure('myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb)') is null then
        raise exception 'Aplique primero 20261105_colaboracion_misma_base.sql y sus requisitos.';
    end if;
    if not exists(select 1 from pg_trigger where tgrelid='public.myg_nube_miembros'::regclass
        and tgname='myg_base_privada_miembro' and not tgisinternal and tgenabled in ('O','A')) then
        raise exception 'Habilite primero la protección de base privada de 20261101_bases_obras.sql.';
    end if;
end $preflight$;

-- No hay FK nuevas a tablas antiguas: su borrado oficial valida estrictamente
-- las dependencias. Las guardas al final impiden borrar una base activada.
-- Las referencias entre tablas centrales sí se comprueban mediante FK.
create table if not exists myg_nube_privado.central_migraciones (
    id uuid primary key, base_id uuid not null, propietario uuid not null,
    revision_origen bigint not null check(revision_origen>=1),
    documentos jsonb not null, huellas jsonb not null default '{}'::jsonb,
    catalogo jsonb, catalogo_sha text,
    es_nueva boolean not null default false,
    creada_en timestamptz not null default clock_timestamp(),
    activada_en timestamptz, cancelada_en timestamptz
);
create table if not exists myg_nube_privado.central_preparados (
    migracion_id uuid not null references myg_nube_privado.central_migraciones(id) on delete cascade,
    documento_id text not null, contenido jsonb not null,
    primary key(migracion_id,documento_id)
);
create table if not exists myg_nube_privado.central_bases (
    base_id uuid primary key,
    migracion_id uuid not null unique references myg_nube_privado.central_migraciones(id),
    catalogo jsonb not null,
    activada_en timestamptz not null default clock_timestamp()
);
create table if not exists myg_nube_privado.central_documentos (
    vista_id uuid primary key,
    base_id uuid not null references myg_nube_privado.central_bases(base_id),
    documento_id text not null,
    revision bigint not null check(revision>=1), contenido jsonb not null,
    actualizado_en timestamptz not null default clock_timestamp(),
    unique(base_id,documento_id)
);
create table if not exists myg_nube_privado.central_operaciones (
    usuario_id uuid not null, operacion_id uuid not null,
    vista_id uuid not null references myg_nube_privado.central_documentos(vista_id),
    revision_base bigint not null, solicitud_sha text not null,
    permisos_requeridos jsonb not null,
    estado text not null check(estado in ('aplicada','conflicto')),
    revision bigint not null, contenido_conflicto jsonb,
    creada_en timestamptz not null default clock_timestamp(),
    primary key(usuario_id,operacion_id)
);
create table if not exists myg_nube_privado.central_eliminaciones (
    operacion_id uuid primary key, base_id uuid not null unique, propietario uuid not null
);
alter table myg_nube_privado.central_migraciones enable row level security;
alter table myg_nube_privado.central_preparados enable row level security;
alter table myg_nube_privado.central_bases enable row level security;
alter table myg_nube_privado.central_documentos enable row level security;
alter table myg_nube_privado.central_operaciones enable row level security;
alter table myg_nube_privado.central_eliminaciones enable row level security;
revoke all on myg_nube_privado.central_migraciones,myg_nube_privado.central_preparados,
    myg_nube_privado.central_bases,myg_nube_privado.central_documentos,
    myg_nube_privado.central_operaciones,myg_nube_privado.central_eliminaciones from public,anon,authenticated,service_role;

create or replace function myg_nube_privado.central_validar_recurso(p_recurso jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
begin
    if jsonb_typeof(p_recurso) is distinct from 'object'
       or p_recurso-array['Referencia','Nombre','Sha256','Base64','Almacen']<>'{}'::jsonb
       or jsonb_typeof(p_recurso->'Referencia') is distinct from 'string' or length(p_recurso->>'Referencia')<1
       or jsonb_typeof(p_recurso->'Nombre') is distinct from 'string'
       or jsonb_typeof(p_recurso->'Sha256') is distinct from 'string' or p_recurso->>'Sha256' !~ '^[0-9a-fA-F]{64}$'
       or jsonb_typeof(p_recurso->'Base64') is distinct from 'string'
       or coalesce(p_recurso->>'Almacen','')<>'' then
        raise exception using errcode='22023',message='MYG_CENTRAL_RECURSO_NO_AUTOCONTENIDO';
    end if;
    if encode(sha256(decode(p_recurso->>'Base64','base64')),'hex')<>lower(p_recurso->>'Sha256') then
        raise exception using errcode='22023',message='MYG_CENTRAL_RECURSO_INTEGRIDAD';
    end if;
end $fn$;

create or replace function myg_nube_privado.central_validar(p_documento text,p_contenido jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
declare j jsonb; recurso jsonb; tabla jsonb; fila jsonb; indice integer; indice_json integer;
begin
    if p_documento is null or length(p_documento) not between 1 and 200
       or p_documento<>btrim(p_documento) or p_documento ~ '[[:cntrl:]]' then
        raise exception using errcode='22023',message='MYG_DOCUMENTO_INVALIDO';
    end if;
    perform myg_nube_privado.validar_contenido(p_contenido);
    j:=myg_nube_privado.expandir_paquete(p_contenido);
    if j->>'formato' is distinct from 'MYG_COLABORACION'
       or j->>'alcance' is distinct from 'obra'
       or jsonb_typeof(j->'documento') is distinct from 'object'
       or j->'documento'->>'Id' is distinct from p_documento
       or jsonb_typeof(j->'documentos') is distinct from 'array'
       or jsonb_array_length(j->'documentos')<>1
       or j->'documentos'->0 is distinct from j->'documento'
       or jsonb_typeof(j->'documento'->'Nombre') is distinct from 'string'
       or length(btrim(j->'documento'->>'Nombre')) not between 1 and 2000
       or j->'documento'->>'Nombre' ~ '[[:cntrl:]]'
       or jsonb_typeof(j->'recursos') is distinct from 'array'
       or j ?| array['archivo_sqlite','url','ruta','contenido_comprimido'] then
        raise exception using errcode='22023',message='MYG_CENTRAL_PAQUETE_DE_OTRA_OBRA';
    end if;
    for recurso in select value from jsonb_array_elements(j->'recursos') loop
        perform myg_nube_privado.central_validar_recurso(recurso);
    end loop;
    for tabla in select value from jsonb_array_elements(j->'tablas') loop
        if lower(tabla->>'Nombre') in ('myg_proyecto','myg_presupuesto') then
            select (ord-1)::integer into indice from jsonb_array_elements_text(tabla->'Columnas') with ordinality c(nombre,ord)
                where lower(nombre)=case lower(tabla->>'Nombre') when 'myg_proyecto' then 'id' else 'proyecto_id' end;
            if indice is null then raise exception using errcode='22023',message='MYG_CENTRAL_TABLA_SIN_IDENTIDAD'; end if;
            for fila in select value from jsonb_array_elements(tabla->'Filas') loop
                if fila->indice->>'Valor' is distinct from p_documento then
                    raise exception using errcode='22023',message='MYG_CENTRAL_TABLA_DE_OTRA_OBRA';
                end if;
            end loop;
            if lower(tabla->>'Nombre')='myg_proyecto' then
                select (ord-1)::integer into indice_json from jsonb_array_elements_text(tabla->'Columnas') with ordinality c(nombre,ord)
                    where lower(nombre)='json_documento';
                if indice_json is null then raise exception using errcode='22023',message='MYG_CENTRAL_TABLA_SIN_IDENTIDAD'; end if;
                for fila in select value from jsonb_array_elements(tabla->'Filas') loop
                    if ((fila->indice_json->>'Valor')::jsonb)->>'Id' is distinct from p_documento then
                        raise exception using errcode='22023',message='MYG_CENTRAL_TABLA_DE_OTRA_OBRA';
                    end if;
                end loop;
            end if;
        end if;
    end loop;
end $fn$;

create or replace function myg_nube_privado.central_validar_catalogo(p_contenido jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
declare t jsonb; recurso jsonb; fila jsonb; celda jsonb;
begin
    if jsonb_typeof(p_contenido) is distinct from 'object'
       or p_contenido-array['formato','version','tablas','recursos']<>'{}'::jsonb
       or p_contenido->>'formato' is distinct from 'MYG_CATALOGO_BASE'
       or p_contenido->'version' is distinct from '1'::jsonb
       or jsonb_typeof(p_contenido->'tablas') is distinct from 'array'
       or jsonb_typeof(p_contenido->'recursos') is distinct from 'array'
       or octet_length(p_contenido::text)>314572800 then
        raise exception using errcode='22023',message='MYG_CATALOGO_INVALIDO';
    end if;
    for t in select value from jsonb_array_elements(p_contenido->'tablas') loop
        if t->>'Nombre' is null or t->>'Nombre'<>all(array[
            'catalogo_unidad','catalogo_insumo','catalogo_partida','catalogo_partida_nodo','catalogo_partida_insumo','catalogo_partida_recurso',
            'myg_indice_unificado','unidad','tipo_costo','categoria','producto','lista_precio','infraestructura','propietario',
            'portafolio','departamento','provincia','distrito','localidad','pais_info','moneda','clase','subclase','marca',
            'indice','indice_precio','region_precio','responsable','calendario',
            'unidad_map','unidad_tipocosto','unidad_tipocostonew','horario','horario_ex','feriado','excepcion',
            'plantilla_partida','titulo_plantilla','costo_unitarioplantilla','precio_producto','subclase_costo'])
           or jsonb_typeof(t->'Columnas') is distinct from 'array' or jsonb_typeof(t->'Filas') is distinct from 'array'
           or t-array['Nombre','Columnas','Filas']<>'{}'::jsonb then
            raise exception using errcode='22023',message='MYG_CATALOGO_TABLA_NO_ADMITIDA';
        end if;
        if exists(select 1 from jsonb_array_elements(t->'Columnas') where jsonb_typeof(value)<>'string' or length(value#>>'{}') not between 1 and 200)
           or (select count(distinct value) from jsonb_array_elements(t->'Columnas'))<>jsonb_array_length(t->'Columnas') then
            raise exception using errcode='22023',message='MYG_CATALOGO_COLUMNAS_INVALIDAS';
        end if;
        for fila in select value from jsonb_array_elements(t->'Filas') loop
            if jsonb_typeof(fila)<>'array' or jsonb_array_length(fila)<>jsonb_array_length(t->'Columnas') then
                raise exception using errcode='22023',message='MYG_CATALOGO_FILA_INVALIDA';
            end if;
            for celda in select value from jsonb_array_elements(fila) loop
                if jsonb_typeof(celda)<>'object' or celda-array['Tipo','Valor']<>'{}'::jsonb
                   or celda->>'Tipo' is null or celda->>'Tipo' not in ('nulo','texto','entero','real','blob')
                   or (celda->>'Tipo'<>'nulo' and jsonb_typeof(celda->'Valor') is distinct from 'string') then
                    raise exception using errcode='22023',message='MYG_CATALOGO_CELDA_INVALIDA';
                end if;
            end loop;
        end loop;
    end loop;
    if (select count(distinct value->>'Nombre') from jsonb_array_elements(p_contenido->'tablas'))<>jsonb_array_length(p_contenido->'tablas') then
        raise exception using errcode='22023',message='MYG_CATALOGO_TABLA_DUPLICADA';
    end if;
    for recurso in select value from jsonb_array_elements(p_contenido->'recursos') loop
        perform myg_nube_privado.central_validar_recurso(recurso);
    end loop;
end $fn$;

create or replace function public.myg_central_preparar_catalogo(p_migracion uuid,p_contenido jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='120s' as $fn$
declare u uuid:=myg_nube_privado.identidad(); m myg_nube_privado.central_migraciones%rowtype; huella text;
begin
    select * into m from myg_nube_privado.central_migraciones where id=p_migracion for update;
    if m.propietario is distinct from u or not exists(select 1 from public.myg_nube_proyectos where id=m.base_id and propietario=u) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    if m.cancelada_en is not null then raise exception using errcode='22023',message='MYG_MIGRACION_CANCELADA'; end if;
    perform myg_nube_privado.eliminacion_exigir_activo(m.base_id);
    perform myg_nube_privado.central_validar_catalogo(p_contenido);
    huella:=encode(sha256(convert_to(p_contenido::text,'UTF8')),'hex');
    if m.catalogo_sha is not null and m.catalogo_sha<>huella then
        raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
    end if;
    if m.activada_en is null then
        update myg_nube_privado.central_migraciones set catalogo=p_contenido,catalogo_sha=huella where id=m.id;
    end if;
    return '{"estado":"preparado"}'::jsonb;
end $fn$;

create or replace function public.myg_central_catalogo(p_base uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); j jsonb;
begin
    select b.catalogo into j from myg_nube_privado.central_bases b
        join public.myg_nube_proyectos p on p.id=b.base_id where b.base_id=p_base and p.propietario=u;
    if j is null then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    perform myg_nube_privado.eliminacion_exigir_activo(p_base);
    return j;
end $fn$;

create or replace function myg_nube_privado.central_exigir_bim_integrado(p_base uuid)
returns void language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if exists(select 1 from myg_nube_privado.bim_documentos where proyecto_id=p_base
        and contenido is distinct from '{"presupuestos":[]}'::jsonb) then
        raise exception using errcode='55000',message='MYG_BIM_PENDIENTE_DE_INTEGRAR';
    end if;
end $fn$;

create or replace function myg_nube_privado.central_exigir_base_privada(p_base uuid)
returns void language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if not exists(select 1 from pg_trigger where tgrelid='public.myg_nube_miembros'::regclass
        and tgname='myg_base_privada_miembro' and not tgisinternal and tgenabled in ('O','A'))
       or exists(select 1 from public.myg_nube_miembros m join public.myg_nube_proyectos p on p.id=m.proyecto_id
            where p.id=p_base and (m.usuario_id<>p.propietario or m.rol<>'propietario')) then
        raise exception using errcode='55000',message='MYG_BASE_REQUIERE_PROTECCION_PRIVADA';
    end if;
end $fn$;

-- Reusar exactamente las identidades y ACL ya asignadas a las vistas. Una vez
-- activada, la revisión pertenece a la obra, no al antiguo archivo completo.
create or replace function myg_nube_privado.base_vista_meta(p_id uuid,p_actor uuid,p_revision bigint default null)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare r text:=myg_nube_privado.base_vista_rol(p_id,p_actor); j jsonb;
begin
    if r is null then return null; end if;
    select jsonb_build_object('id',v.id,'codigo','VISTA-'||replace(v.id::text,'-',''),
        'nombre',v.nombre,'rol',r,'revision',coalesce(p_revision,d.revision,p.revision),'alcance','obra',
        'base_id',v.base_id,'documento_id',v.documento_id,'vista_base',true,
        'actualizado_en',coalesce(d.actualizado_en,p.actualizado_en),
        'permisos_modulos',case when r='propietario' then
            '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}'::jsonb
            else m.permisos_modulos end)
        ||case when d.vista_id is not null then jsonb_build_object('central_nativa',true,
            'tamano_bytes',octet_length(d.contenido::text),'tamano_formato','json') else '{}'::jsonb end into j
    from myg_nube_privado.base_vistas v join public.myg_nube_proyectos p on p.id=v.base_id
    left join myg_nube_privado.base_vista_miembros m on m.vista_id=v.id and m.usuario_id=p_actor
    left join myg_nube_privado.central_documentos d on d.vista_id=v.id
    where v.id=p_id;
    return j;
end $fn$;

create or replace function myg_nube_privado.central_meta(p_id uuid,p_actor uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare j jsonb;
begin
    if not exists(select 1 from myg_nube_privado.identidades_verificadas where auth_usuario_id=p_actor and activo) then return null; end if;
    select jsonb_build_object('id',p.id,'codigo',p.codigo,'nombre',p.nombre,
        'rol','propietario','revision',p.revision,'alcance','base','central_nativa',true,
        'eliminacion_pendiente',exists(select 1 from myg_nube_privado.eliminacion_proyectos ep
            join myg_nube_privado.eliminacion_jobs ej using(operacion_id) where ep.proyecto_id=p.id and ej.estado='pendiente'),
        'actualizado_en',coalesce((select max(actualizado_en) from myg_nube_privado.central_documentos where base_id=p.id),p.actualizado_en),
        'permisos_modulos','{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}'::jsonb)
    into j from public.myg_nube_proyectos p join myg_nube_privado.central_bases b on b.base_id=p.id
    where p.id=p_id and p.propietario=p_actor and p.alcance='base';
    if j is not null then return j; end if;
    if exists(select 1 from myg_nube_privado.central_documentos where vista_id=p_id) then
        return myg_nube_privado.base_vista_meta(p_id,p_actor);
    end if;
    return null;
end $fn$;

-- Las bases nuevas se preparan directamente como filas PostgreSQL, sin subir
-- primero un archivo SQLite. El marcador de preparación permanece privado para
-- el propietario y el listado no lo anuncia hasta la activación completa.
create or replace function public.myg_central_crear_base(p_base uuid,p_nombre text,p_migracion uuid,p_documentos jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); p public.myg_nube_proyectos%rowtype; j jsonb;
begin
    if p_base is null or p_base='00000000-0000-0000-0000-000000000000'::uuid
       or p_nombre is null or length(btrim(p_nombre)) not between 1 and 2000 or p_nombre ~ '[[:cntrl:]]' then
        raise exception using errcode='22023',message='MYG_BASE_INVALIDA';
    end if;
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-crear:'||p_base::text,0)) then
        raise exception using errcode='55006',message='MYG_PUBLICACION_EN_CURSO';
    end if;
    select * into p from public.myg_nube_proyectos where id=p_base for update;
    if found then
        if p.propietario<>u then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
        if p.nombre<>btrim(p_nombre) or not exists(select 1 from myg_nube_privado.central_migraciones
            where id=p_migracion and base_id=p_base and propietario=u and es_nueva) then
            raise exception using errcode='22023',message='MYG_ID_REUTILIZADO_CON_OTRA_CREACION';
        end if;
        return public.myg_central_iniciar(p_base,1,p_migracion,p_documentos);
    end if;
    if exists(select 1 from myg_nube_privado.eliminacion_jobs where base_id=p_base) then
        raise exception using errcode='22023',message='MYG_ID_ELIMINADO_NO_REUTILIZABLE';
    end if;
    insert into public.myg_nube_proyectos(id,codigo,nombre,propietario,contenido,alcance,es_comprimido)
        values(p_base,'MYG-'||upper(replace(p_base::text,'-','')),btrim(p_nombre),u,
            '{"formato":"MYG_CENTRAL_PREPARACION","version":1}', 'base',false);
    insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values(p_base,u,'propietario');
    insert into myg_nube_privado.sqlite_proyectos(proyecto_id,documento_id)
        values(p_base,p_documentos->0->>'documento_id');
    j:=public.myg_central_iniciar(p_base,1,p_migracion,p_documentos);
    update myg_nube_privado.central_migraciones set es_nueva=true where id=p_migracion;
    return j;
end $fn$;

create or replace function public.myg_central_capacidades()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    perform myg_nube_privado.identidad();
    return '{"version":1,"revision_por_obra":true,"max_contenido_mib":300}'::jsonb;
end $fn$;

create or replace function public.myg_central_resolver(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin return myg_nube_privado.central_meta(p_id,myg_nube_privado.identidad()); end $fn$;

create or replace function public.myg_central_listar()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); j jsonb;
begin
    select coalesce(jsonb_agg(m order by m->>'nombre',m->>'id'),'[]'::jsonb) into j from (
        select myg_nube_privado.central_meta(base_id,u) m from myg_nube_privado.central_bases
        union all select myg_nube_privado.central_meta(vista_id,u) from myg_nube_privado.central_documentos
    ) s where m is not null;
    return j;
end $fn$;

create or replace function public.myg_central_obras(p_base uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); j jsonb;
begin
    if myg_nube_privado.central_meta(p_base,u) is null and not exists(
        select 1 from myg_nube_privado.central_documentos where base_id=p_base
            and myg_nube_privado.base_vista_rol(vista_id,u) is not null) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    select coalesce(jsonb_agg(m order by m->>'nombre',m->>'id'),'[]'::jsonb) into j
    from (select myg_nube_privado.central_meta(vista_id,u) m
        from myg_nube_privado.central_documentos where base_id=p_base) s where m is not null;
    return j;
end $fn$;

create or replace function public.myg_central_abrir(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); j jsonb; contenido jsonb;
begin
    j:=myg_nube_privado.central_meta(p_id,u);
    if j is null then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    select d.contenido into contenido from myg_nube_privado.central_documentos d where vista_id=p_id;
    if contenido is null then return j; end if;
    return j||jsonb_build_object('contenido',contenido);
end $fn$;

create or replace function public.myg_central_iniciar(p_base uuid,p_revision bigint,p_migracion uuid,p_documentos jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); p public.myg_nube_proyectos%rowtype;
    previa myg_nube_privado.central_migraciones%rowtype; d jsonb; manifest jsonb;
begin
    if p_migracion is null or p_migracion='00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision<1 or jsonb_typeof(p_documentos) is distinct from 'array'
       or jsonb_array_length(p_documentos) not between 1 and 100000 then
        raise exception using errcode='22023',message='MYG_MIGRACION_INVALIDA';
    end if;
    select * into p from public.myg_nube_proyectos where id=p_base for update;
    if p.propietario is distinct from u or p.alcance<>'base' or not exists(
        select 1 from myg_nube_privado.sqlite_proyectos where proyecto_id=p_base) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    perform myg_nube_privado.eliminacion_exigir_activo(p_base);
    perform myg_nube_privado.central_exigir_base_privada(p_base);
    for d in select value from jsonb_array_elements(p_documentos) loop
        if jsonb_typeof(d) is distinct from 'object' or d-array['documento_id','nombre']<>'{}'::jsonb
           or jsonb_typeof(d->'documento_id') is distinct from 'string'
           or length(d->>'documento_id') not between 1 and 200 or d->>'documento_id'<>btrim(d->>'documento_id')
           or d->>'documento_id' ~ '[[:cntrl:]]' or jsonb_typeof(d->'nombre') is distinct from 'string'
           or length(btrim(d->>'nombre')) not between 1 and 2000 or d->>'nombre' ~ '[[:cntrl:]]' then
            raise exception using errcode='22023',message='MYG_MANIFIESTO_INVALIDO';
        end if;
    end loop;
    if (select count(distinct value->>'documento_id') from jsonb_array_elements(p_documentos))<>jsonb_array_length(p_documentos) then
        raise exception using errcode='22023',message='MYG_MANIFIESTO_DUPLICADO';
    end if;
    select jsonb_agg(value order by value->>'documento_id') into manifest from jsonb_array_elements(p_documentos);
    select * into previa from myg_nube_privado.central_migraciones where id=p_migracion;
    if found then
        if previa.base_id<>p_base or previa.propietario<>u or previa.revision_origen<>p_revision or previa.documentos<>manifest then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        if previa.cancelada_en is not null then raise exception using errcode='22023',message='MYG_MIGRACION_CANCELADA'; end if;
        return jsonb_build_object('estado',case when previa.activada_en is null then 'preparando' else 'activa' end,
            'migracion_id',p_migracion,'base_id',p_base,'revision',p_revision);
    end if;
    if exists(select 1 from myg_nube_privado.central_bases where base_id=p_base) then
        raise exception using errcode='22023',message='MYG_BASE_YA_CENTRAL';
    end if;
    if p.revision<>p_revision then raise exception using errcode='22023',message='MYG_BASE_CAMBIO_DURANTE_MIGRACION'; end if;
    perform myg_nube_privado.central_exigir_bim_integrado(p_base);
    insert into myg_nube_privado.central_migraciones(id,base_id,propietario,revision_origen,documentos)
        values(p_migracion,p_base,u,p_revision,manifest);
    return jsonb_build_object('estado','preparando','migracion_id',p_migracion,'base_id',p_base,'revision',p_revision);
end $fn$;

create or replace function public.myg_central_preparar(p_migracion uuid,p_documento text,p_contenido jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='120s' as $fn$
declare u uuid:=myg_nube_privado.identidad(); m myg_nube_privado.central_migraciones%rowtype; previo jsonb; huella text;
begin
    select * into m from myg_nube_privado.central_migraciones where id=p_migracion for update;
    if m.propietario is distinct from u or not exists(select 1 from public.myg_nube_proyectos
        where id=m.base_id and propietario=u) then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    if m.cancelada_en is not null then raise exception using errcode='22023',message='MYG_MIGRACION_CANCELADA'; end if;
    perform myg_nube_privado.eliminacion_exigir_activo(m.base_id);
    if not exists(select 1 from jsonb_array_elements(m.documentos) where value->>'documento_id'=p_documento) then
        raise exception using errcode='22023',message='MYG_DOCUMENTO_FUERA_DE_MANIFIESTO';
    end if;
    perform myg_nube_privado.central_validar(p_documento,p_contenido);
    huella:=encode(sha256(convert_to(p_contenido::text,'UTF8')),'hex');
    if m.activada_en is not null then
        -- Tras un ACK perdido la migración ya pudo terminar. Nunca sobreescribir
        -- una edición posterior con el paquete importado originalmente.
        if m.huellas->>p_documento is distinct from huella then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        return jsonb_build_object('estado','preparado','documento_id',p_documento);
    end if;
    select contenido into previo from myg_nube_privado.central_preparados where migracion_id=p_migracion and documento_id=p_documento;
    if previo is not null and previo<>p_contenido then raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO'; end if;
    insert into myg_nube_privado.central_preparados(migracion_id,documento_id,contenido)
        values(p_migracion,p_documento,p_contenido) on conflict do nothing;
    update myg_nube_privado.central_migraciones set huellas=huellas||jsonb_build_object(p_documento,huella) where id=p_migracion;
    return jsonb_build_object('estado','preparado','documento_id',p_documento);
end $fn$;

create or replace function public.myg_central_activar(p_migracion uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='120s' as $fn$
declare u uuid:=myg_nube_privado.identidad(); m myg_nube_privado.central_migraciones%rowtype;
    p public.myg_nube_proyectos%rowtype; d jsonb; v uuid;
begin
    select * into m from myg_nube_privado.central_migraciones where id=p_migracion for update;
    if m.propietario is distinct from u then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    if m.cancelada_en is not null then raise exception using errcode='22023',message='MYG_MIGRACION_CANCELADA'; end if;
    select * into p from public.myg_nube_proyectos where id=m.base_id for update;
    if p.propietario is distinct from u then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    perform myg_nube_privado.eliminacion_exigir_activo(m.base_id);
    if m.activada_en is not null then return myg_nube_privado.central_meta(m.base_id,u); end if;
    perform myg_nube_privado.central_exigir_base_privada(m.base_id);
    if exists(select 1 from myg_nube_privado.central_bases where base_id=m.base_id) then
        raise exception using errcode='22023',message='MYG_BASE_YA_CENTRAL';
    end if;
    if p.revision<>m.revision_origen then raise exception using errcode='22023',message='MYG_BASE_CAMBIO_DURANTE_MIGRACION'; end if;
    perform myg_nube_privado.central_exigir_bim_integrado(m.base_id);
    if m.catalogo is null or (select count(*) from myg_nube_privado.central_preparados where migracion_id=p_migracion)<>jsonb_array_length(m.documentos)
       or exists(select 1 from myg_nube_privado.base_vistas vista where vista.base_id=m.base_id
           and not exists(select 1 from jsonb_array_elements(m.documentos) manifiesto_doc(value)
               where manifiesto_doc.value->>'documento_id'=vista.documento_id)) then
        raise exception using errcode='22023',message='MYG_MIGRACION_INCOMPLETA';
    end if;
    insert into myg_nube_privado.central_bases(base_id,migracion_id,catalogo) values(m.base_id,m.id,m.catalogo);
    for d in select value from jsonb_array_elements(m.documentos) loop
        select (public.myg_base_registrar(m.base_id,d->>'documento_id',d->>'nombre')->>'id')::uuid into v;
        insert into myg_nube_privado.central_documentos(vista_id,base_id,documento_id,revision,contenido)
            select v,m.base_id,p_documento.documento_id,1,p_documento.contenido
            from myg_nube_privado.central_preparados p_documento
            where p_documento.migracion_id=m.id and p_documento.documento_id=d->>'documento_id';
    end loop;
    update myg_nube_privado.central_migraciones set activada_en=clock_timestamp(),catalogo=null where id=m.id;
    delete from myg_nube_privado.central_preparados where migracion_id=m.id;
    return myg_nube_privado.central_meta(m.base_id,u);
end $fn$;

-- Solo retira datos preparados de un intento NO activado. Conserva un tombstone
-- pequeño para que un reenvío antiguo no pueda resucitar el mismo UUID.
create or replace function public.myg_central_cancelar(p_migracion uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); m myg_nube_privado.central_migraciones%rowtype;
begin
    if p_migracion is null or p_migracion='00000000-0000-0000-0000-000000000000'::uuid then
        raise exception using errcode='22023',message='MYG_MIGRACION_INVALIDA';
    end if;
    select * into m from myg_nube_privado.central_migraciones where id=p_migracion for update;
    if not found then return '{"estado":"cancelada"}'::jsonb; end if;
    if m.propietario<>u then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    if m.activada_en is not null then raise exception using errcode='22023',message='MYG_MIGRACION_YA_ACTIVA'; end if;
    delete from myg_nube_privado.central_preparados where migracion_id=p_migracion;
    update myg_nube_privado.central_migraciones set cancelada_en=coalesce(cancelada_en,clock_timestamp()),
        catalogo=null,catalogo_sha=null,huellas='{}'::jsonb where id=p_migracion;
    return '{"estado":"cancelada"}'::jsonb;
end $fn$;

create or replace function public.myg_central_crear_obra(p_base uuid,p_documento text,p_nombre text,p_contenido jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='120s' as $fn$
declare u uuid:=myg_nube_privado.identidad(); p public.myg_nube_proyectos%rowtype; v uuid; previo jsonb;
begin
    select * into p from public.myg_nube_proyectos where id=p_base for update;
    if p.propietario is distinct from u or not exists(select 1 from myg_nube_privado.central_bases where base_id=p_base) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    perform myg_nube_privado.central_validar(p_documento,p_contenido);
    select contenido,vista_id into previo,v from myg_nube_privado.central_documentos where base_id=p_base and documento_id=p_documento;
    if previo is not null then
        if previo<>p_contenido then raise exception using errcode='22023',message='MYG_DOCUMENTO_YA_EXISTE'; end if;
        return public.myg_central_abrir(v);
    end if;
    select (public.myg_base_registrar(p_base,p_documento,p_nombre)->>'id')::uuid into v;
    insert into myg_nube_privado.central_documentos(vista_id,base_id,documento_id,revision,contenido)
        values(v,p_base,p_documento,1,p_contenido);
    return public.myg_central_abrir(v);
end $fn$;

create or replace function public.myg_central_guardar(p_id uuid,p_operacion uuid,p_revision bigint,p_contenido jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='120s' as $fn$
declare u uuid:=myg_nube_privado.identidad(); d myg_nube_privado.central_documentos%rowtype;
    anterior myg_nube_privado.central_operaciones%rowtype; meta jsonb; b uuid; huella text;
    estado text; rev bigint; respuesta jsonb;
begin
    if p_operacion is null or p_operacion='00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision<1 or p_revision=9223372036854775807 then
        raise exception using errcode='22023',message='MYG_OPERACION_INVALIDA';
    end if;
    select base_id into b from myg_nube_privado.central_documentos where vista_id=p_id;
    -- SHARE permite guardados simultáneos en obras diferentes. La gestión ACL
    -- existente usa UPDATE sobre esta fila y queda serializada con el guardado.
    perform 1 from public.myg_nube_proyectos where id=b for share;
    begin
        select * into d from myg_nube_privado.central_documentos where vista_id=p_id for update nowait;
    exception when lock_not_available then raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO'; end;
    meta:=myg_nube_privado.central_meta(p_id,u);
    if d.vista_id is null or meta is null or meta->>'rol' not in ('propietario','administrador','editor')
       or not myg_nube_privado.base_permisos_validos(meta->'permisos_modulos') then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    perform myg_nube_privado.central_validar(d.documento_id,p_contenido);
    huella:=encode(sha256(convert_to(jsonb_build_object('id',p_id,'revision',p_revision,'contenido',p_contenido)::text,'UTF8')),'hex');
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-op:'||u::text||':'||p_operacion::text,0)) then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end if;
    select * into anterior from myg_nube_privado.central_operaciones where usuario_id=u and operacion_id=p_operacion;
    if found then
        if anterior.vista_id<>p_id or anterior.revision_base<>p_revision or anterior.solicitud_sha<>huella then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        if not (meta->'permisos_modulos' @> (select coalesce(jsonb_object_agg(key,value),'{}'::jsonb)
            from jsonb_each(anterior.permisos_requeridos) where value='true'::jsonb)) then
            raise exception using errcode='42501',message='MYG_PERMISO_REVOCADO';
        end if;
        return jsonb_build_object('estado',anterior.estado,'revision',anterior.revision,'operacion_id',p_operacion,
            'contenido',case when anterior.estado='aplicada' then p_contenido else anterior.contenido_conflicto end);
    end if;
    if exists(select 1 from public.myg_nube_operaciones where usuario_id=u and operacion_id=p_operacion)
       or exists(select 1 from myg_nube_privado.sqlite_operaciones where usuario_id=u and operacion_id=p_operacion)
       or exists(select 1 from myg_nube_privado.bim_operaciones where usuario_id=u and operacion_id=p_operacion) then
        raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
    end if;
    rev:=d.revision;
    if d.revision<>p_revision then estado:='conflicto';
    else
        perform myg_nube_privado.exigir_modulos(d.contenido,p_contenido,meta->'permisos_modulos');
        estado:='aplicada'; rev:=d.revision+1;
        update myg_nube_privado.central_documentos set revision=rev,contenido=p_contenido,actualizado_en=clock_timestamp() where vista_id=p_id;
        update myg_nube_privado.base_vistas set nombre=btrim(myg_nube_privado.expandir_paquete(p_contenido)->'documento'->>'Nombre') where id=p_id;
    end if;
    insert into myg_nube_privado.central_operaciones(usuario_id,operacion_id,vista_id,revision_base,solicitud_sha,
        permisos_requeridos,estado,revision,contenido_conflicto)
    values(u,p_operacion,p_id,p_revision,huella,meta->'permisos_modulos',estado,rev,case when estado='conflicto' then d.contenido end);
    -- Reservar el UUID en el espacio global sin duplicar el contenido aplicado.
    insert into public.myg_nube_operaciones(usuario_id,operacion_id,proyecto_id,solicitud,respuesta)
        values(u,p_operacion,b,jsonb_build_object('formato','MYG_CENTRAL','vista',p_id,'sha256',huella),
            jsonb_build_object('estado',estado,'revision',rev,'operacion_id',p_operacion));
    return jsonb_build_object('estado',estado,'revision',rev,'operacion_id',p_operacion,
        'contenido',case when estado='aplicada' then p_contenido else d.contenido end);
end $fn$;

-- Conservar funciones anteriores literalmente para las bases no migradas. Las
-- envolturas solo cambian el enrutamiento de UUID centrales autorizados.
do $copiar$
declare nombre text; firma text; destino text; d text;
begin
    foreach firma in array array['myg_nube_listar()','myg_nube_abrir(uuid)',
        'myg_nube_guardar(uuid,uuid,bigint,jsonb)','myg_nube_revision(uuid)',
        'myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)',
        'myg_nube_sqlite_consultar(uuid)','myg_nube_sqlite_abrir(uuid,bigint)',
        'myg_nube_miembros(uuid)','myg_nube_solicitudes(uuid)',
        'myg_nube_rol(uuid,uuid,text)','myg_nube_compartir_usuario(uuid,text,text,jsonb)',
        'myg_nube_permisos(uuid,uuid,jsonb)',
        'myg_nube_base_eliminacion_iniciar(uuid,uuid)','myg_nube_base_eliminacion_finalizar(uuid)',
        'myg_base_contexto_servidor(uuid,uuid,bigint)'] loop
        nombre:=split_part(firma,'(',1); destino:='central_legacy_'||nombre;
        if to_regprocedure('myg_nube_privado.'||replace(firma,nombre,destino)) is null then
            d:=pg_get_functiondef(to_regprocedure('public.'||firma));
            if d is null then
                if nombre='myg_nube_solicitudes' then continue; end if;
                raise exception 'Falta la función oficial %.',firma;
            end if;
            d:=replace(d,'FUNCTION public.'||nombre||'(','FUNCTION myg_nube_privado.'||destino||'(');
            execute d;
        end if;
        execute 'revoke all on function myg_nube_privado.'||replace(firma,nombre,destino)||' from public,anon,authenticated,service_role';
    end loop;
end $copiar$;

create or replace function public.myg_nube_listar()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare j jsonb; centrales jsonb;
begin
    centrales:=public.myg_central_listar();
    select coalesce(jsonb_agg(value),'[]'::jsonb) into j from jsonb_array_elements(myg_nube_privado.central_legacy_myg_nube_listar())
    where not exists(select 1 from myg_nube_privado.central_bases where base_id=(value->>'id')::uuid);
    select coalesce(jsonb_agg(value),'[]'::jsonb) into j from jsonb_array_elements(j)
    where not exists(select 1 from myg_nube_privado.central_migraciones
        where base_id=(value->>'id')::uuid and es_nueva and activada_en is null);
    return j||centrales;
end $fn$;

create or replace function myg_nube_privado.central_exigir_ruta(p_id uuid)
returns void language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if myg_nube_privado.central_meta(p_id,myg_nube_privado.identidad()) is not null then
        raise exception using errcode='MGN01',message='MYG_BASE_CENTRAL_REQUIERE_CLIENTE';
    end if;
end $fn$;
create or replace function public.myg_nube_abrir(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_abrir(p_id); end $fn$;
create or replace function public.myg_nube_guardar(p_id uuid,p_operacion uuid,p_revision bigint,p_contenido jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='120s' as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_guardar(p_id,p_operacion,p_revision,p_contenido); end $fn$;
create or replace function public.myg_nube_revision(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_revision(p_id); end $fn$;
create or replace function public.myg_nube_guardar_cambios(p_id uuid,p_operacion uuid,p_revision bigint,p_cambios jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='120s' as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_guardar_cambios(p_id,p_operacion,p_revision,p_cambios); end $fn$;
create or replace function public.myg_nube_sqlite_consultar(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_sqlite_consultar(p_id); end $fn$;
create or replace function public.myg_nube_sqlite_abrir(p_id uuid,p_revision bigint default null)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_sqlite_abrir(p_id,p_revision); end $fn$;
create or replace function public.myg_nube_miembros(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_miembros(p_id); end $fn$;
do $solicitudes$
begin
    if to_regprocedure('myg_nube_privado.central_legacy_myg_nube_solicitudes(uuid)') is not null then
        execute $wrapper$create or replace function public.myg_nube_solicitudes(p_id uuid)
            returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
            begin perform myg_nube_privado.central_exigir_ruta(p_id);
            return myg_nube_privado.central_legacy_myg_nube_solicitudes(p_id); end $fn$;$wrapper$;
    end if;
end $solicitudes$;
create or replace function public.myg_nube_rol(p_id uuid,p_usuario uuid,p_rol text)
returns boolean language plpgsql security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_rol(p_id,p_usuario,p_rol); end $fn$;
create or replace function public.myg_nube_compartir_usuario(p_id uuid,p_usuario_myg text,p_rol text,p_permisos_modulos jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_compartir_usuario(p_id,p_usuario_myg,p_rol,p_permisos_modulos); end $fn$;
create or replace function public.myg_nube_permisos(p_id uuid,p_usuario uuid,p_permisos_modulos jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
begin perform myg_nube_privado.central_exigir_ruta(p_id); return myg_nube_privado.central_legacy_myg_nube_permisos(p_id,p_usuario,p_permisos_modulos); end $fn$;
create or replace function public.myg_base_contexto_servidor(p_id uuid,p_actor uuid,p_revision bigint default null)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if myg_nube_privado.central_meta(p_id,p_actor) is not null then
        raise exception using errcode='MGN01',message='MYG_BASE_CENTRAL_REQUIERE_CLIENTE';
    end if;
    return myg_nube_privado.central_legacy_myg_base_contexto_servidor(p_id,p_actor,p_revision);
end $fn$;

-- El borrado conserva el protocolo existente: primero manifiesto autorizado,
-- luego API Storage, y finalmente eliminación transaccional de metadatos.
-- El marcador privado permite únicamente ese recorrido, nunca un GUC editable.
create or replace function public.myg_nube_base_eliminacion_iniciar(p_base uuid,p_operacion uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); dueno uuid;
begin
    if exists(select 1 from myg_nube_privado.central_bases where base_id=p_base)
       or exists(select 1 from myg_nube_privado.central_migraciones where base_id=p_base and es_nueva) then
        select propietario into dueno from public.myg_nube_proyectos where id=p_base for update;
        if dueno is distinct from u then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
        if p_operacion is null or p_operacion='00000000-0000-0000-0000-000000000000'::uuid then
            raise exception using errcode='22023',message='MYG_OPERACION_INVALIDA';
        end if;
        insert into myg_nube_privado.central_eliminaciones(operacion_id,base_id,propietario)
            values(p_operacion,p_base,u) on conflict do nothing;
        -- El cliente existente puede volver a iniciar con un UUID nuevo al
        -- recuperar un borrado. El protocolo devuelve el job anterior de la
        -- MISMA base y propietario; no exige conocer su UUID perdido.
        if not exists(select 1 from myg_nube_privado.central_eliminaciones where base_id=p_base and propietario=u) then
            raise exception using errcode='22023',message='MYG_ELIMINACION_EN_CURSO';
        end if;
    end if;
    return myg_nube_privado.central_legacy_myg_nube_base_eliminacion_iniciar(p_base,p_operacion);
end $fn$;
create or replace function public.myg_nube_base_eliminacion_finalizar(p_operacion uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog set lock_timeout='5s' as $fn$
declare u uuid:=myg_nube_privado.identidad(); b uuid; j jsonb;
begin
    select base_id into b from myg_nube_privado.central_eliminaciones where operacion_id=p_operacion and propietario=u;
    -- El finalizador anterior verifica propietario, esquema y desaparición real
    -- de todos los objetos antes de borrar. Si falla, también se revierte todo
    -- lo realizado por esta envoltura.
    j:=myg_nube_privado.central_legacy_myg_nube_base_eliminacion_finalizar(p_operacion);
    if b is not null then
        delete from myg_nube_privado.central_operaciones where vista_id in
            (select vista_id from myg_nube_privado.central_documentos where base_id=b);
        delete from myg_nube_privado.central_documentos where base_id=b;
        delete from myg_nube_privado.central_bases where base_id=b;
        delete from myg_nube_privado.central_migraciones where base_id=b;
    end if;
    return j;
end $fn$;

create or replace function myg_nube_privado.central_proteger_legacy()
returns trigger language plpgsql security definer set search_path=pg_catalog as $fn$
declare b uuid;
begin
    if tg_table_name='myg_nube_proyectos' then b:=old.id;
    elsif tg_op='DELETE' then b:=old.proyecto_id;
    else b:=new.proyecto_id; end if;
    if exists(select 1 from myg_nube_privado.central_bases where base_id=b)
       or exists(select 1 from myg_nube_privado.central_migraciones where base_id=b and es_nueva) then
        if (tg_op='DELETE' or tg_table_name='eliminacion_proyectos') and exists(
            select 1 from myg_nube_privado.central_eliminaciones c
            join myg_nube_privado.eliminacion_jobs j on j.operacion_id=c.operacion_id
            where c.base_id=b and c.propietario=auth.uid() and j.propietario=c.propietario and j.estado='pendiente') then
            if tg_op='DELETE' then return old; end if;
            return new;
        end if;
        raise exception using errcode='MGN01',message='MYG_BASE_CENTRAL_REQUIERE_CLIENTE';
    end if;
    if tg_op='DELETE' then return old; end if;
    return new;
end $fn$;
drop trigger if exists myg_central_proteger on public.myg_nube_proyectos;
create trigger myg_central_proteger before update or delete on public.myg_nube_proyectos
    for each row execute function myg_nube_privado.central_proteger_legacy();
drop trigger if exists myg_central_proteger on myg_nube_privado.bim_documentos;
create trigger myg_central_proteger before insert or update or delete on myg_nube_privado.bim_documentos
    for each row execute function myg_nube_privado.central_proteger_legacy();
drop trigger if exists myg_central_proteger on myg_nube_privado.eliminacion_proyectos;
create trigger myg_central_proteger before insert on myg_nube_privado.eliminacion_proyectos
    for each row execute function myg_nube_privado.central_proteger_legacy();

create or replace function myg_nube_privado.central_vista_completa()
returns trigger language plpgsql security definer set search_path=pg_catalog as $fn$
begin
    if exists(select 1 from myg_nube_privado.central_bases where base_id=new.base_id)
       and not exists(select 1 from myg_nube_privado.central_documentos where vista_id=new.id
           and base_id=new.base_id and documento_id=new.documento_id) then
        raise exception using errcode='22023',message='MYG_CENTRAL_OBRA_SIN_DATOS';
    end if;
    return new;
end $fn$;
drop trigger if exists myg_central_vista_completa on myg_nube_privado.base_vistas;
create constraint trigger myg_central_vista_completa after insert or update on myg_nube_privado.base_vistas
    deferrable initially deferred for each row execute function myg_nube_privado.central_vista_completa();

-- Impedir subidas binarias nuevas para la base activada, incluso desde un
-- cliente anterior. El respaldo existente sigue siendo privado y descargable.
create or replace function myg_nube_privado.central_storage_permitido(p_ruta text)
returns boolean language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if p_ruta ~ '^[0-9a-f-]{36}/[0-9a-f]{32}/' then
        return not exists(select 1 from myg_nube_privado.central_bases where base_id=split_part(p_ruta,'/',2)::uuid)
            and not exists(select 1 from myg_nube_privado.central_migraciones where base_id=split_part(p_ruta,'/',2)::uuid and es_nueva);
    end if;
    return true;
end $fn$;
drop policy if exists myg_central_bloquear_binario on storage.objects;
create policy myg_central_bloquear_binario on storage.objects as restrictive for insert to public
    with check(bucket_id<>'myg-nube-sqlite' or myg_nube_privado.central_storage_permitido(name));

revoke all on function myg_nube_privado.central_validar(text,jsonb),myg_nube_privado.central_validar_recurso(jsonb),
    myg_nube_privado.central_exigir_bim_integrado(uuid),
    myg_nube_privado.central_validar_catalogo(jsonb),
    myg_nube_privado.central_exigir_base_privada(uuid),
    myg_nube_privado.central_meta(uuid,uuid),myg_nube_privado.central_exigir_ruta(uuid),
    myg_nube_privado.central_vista_completa(),
    myg_nube_privado.central_proteger_legacy(),myg_nube_privado.central_storage_permitido(text)
    from public,anon,authenticated,service_role;
grant execute on function myg_nube_privado.central_storage_permitido(text) to anon,authenticated;
revoke all on function public.myg_central_capacidades(),public.myg_central_listar(),public.myg_central_resolver(uuid),
    public.myg_central_obras(uuid),public.myg_central_abrir(uuid),
    public.myg_central_crear_base(uuid,text,uuid,jsonb),
    public.myg_central_preparar_catalogo(uuid,jsonb),public.myg_central_catalogo(uuid),
    public.myg_central_cancelar(uuid),
    public.myg_central_iniciar(uuid,bigint,uuid,jsonb),public.myg_central_preparar(uuid,text,jsonb),
    public.myg_central_activar(uuid),public.myg_central_crear_obra(uuid,text,text,jsonb),
    public.myg_central_guardar(uuid,uuid,bigint,jsonb) from public,anon;
grant execute on function public.myg_central_capacidades(),public.myg_central_listar(),public.myg_central_resolver(uuid),
    public.myg_central_obras(uuid),public.myg_central_abrir(uuid),
    public.myg_central_crear_base(uuid,text,uuid,jsonb),
    public.myg_central_preparar_catalogo(uuid,jsonb),public.myg_central_catalogo(uuid),
    public.myg_central_cancelar(uuid),
    public.myg_central_iniciar(uuid,bigint,uuid,jsonb),public.myg_central_preparar(uuid,text,jsonb),
    public.myg_central_activar(uuid),public.myg_central_crear_obra(uuid,text,text,jsonb),
    public.myg_central_guardar(uuid,uuid,bigint,jsonb) to authenticated,service_role;
notify pgrst,'reload schema';
commit;
