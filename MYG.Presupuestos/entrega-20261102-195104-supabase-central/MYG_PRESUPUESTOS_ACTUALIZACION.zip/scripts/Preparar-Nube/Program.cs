using System.Text.Json;
using System.Text;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using MYG.Colaboracion;

bool soloValidar = args.Length == 2 && args[0] == "--validar";
bool validarEnsamblado = args.Length == 2 && args[0] == "--validar-ensamblado";
if (args.Length is not (2 or 3) || (args.Length == 3 && args[2] != "--requerir-servicio"))
{
    Console.Error.WriteLine("Uso: Preparar-Nube <configuración guardada> <conexión pública de distribución> [--requerir-servicio], --validar <conexión pública>, o --validar-ensamblado <programa.dll>");
    return 2;
}

try
{
    if (validarEnsamblado)
    {
        ValidarEnsamblado(args[1]);
        Console.WriteLine("Conexión pública del programa validada sin ejecutar su código.");
        return 0;
    }
    // Se exige una fuente explícita: no hay lectura de otras cuentas ni red.
    string origen = Path.GetFullPath(soloValidar ? args[1] : args[0]);
    if (!File.Exists(origen)) throw new FileNotFoundException();
    var conexion = ConfiguracionServicioNube.Cargar(origen, origen)
        ?? throw new InvalidDataException();
    if (soloValidar)
    {
        // El recurso comercial debe contener exclusivamente los campos públicos.
        // No basta ignorar un secreto desconocido y luego incrustar el archivo original.
        ValidarRecursoPublico(File.ReadAllText(origen));
        Console.WriteLine("Conexión pública integrada validada.");
        return 0;
    }
    if (args.Length == 3 && string.IsNullOrWhiteSpace(conexion.ServicioBasesUrl))
    {
        Console.Error.WriteLine("Falta ServicioBasesUrl. Configure la dirección HTTPS real del servicio central antes de publicar colaboración por Internet. No se modificó la distribución existente.");
        return 1;
    }
    // Exportar solo la conexión pública y el servicio opcional del modelo. No copiar
    // el JSON original, que podría contener otros campos o datos de sesión.
    ConfiguracionServicioNube.Guardar(args[1], conexion);
    Console.WriteLine("Conexión pública de Nube MYG preparada para la distribución.");
    return 0;
}
catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or NubeException or ArgumentException or BadImageFormatException or InvalidOperationException)
{
    // No imprimir el JSON, la clave recibida ni excepciones de parseo.
    Console.Error.WriteLine("No se pudo preparar Nube MYG. Revise el archivo de configuración indicado y use únicamente una clave publicable o anon.");
    return 1;
}

static void ValidarRecursoPublico(string texto)
{
    using var documento = JsonDocument.Parse(texto);
    var permitidos = new HashSet<string>(StringComparer.Ordinal)
        { "Nombre", "Url", "ClavePublicable", "ServicioBasesUrl" };
    var encontrados = new HashSet<string>(StringComparer.Ordinal);
    if (documento.RootElement.ValueKind != JsonValueKind.Object
        || documento.RootElement.EnumerateObject().Any(p => !permitidos.Contains(p.Name) || !encontrados.Add(p.Name)))
        throw new InvalidDataException();
    var conexion = JsonSerializer.Deserialize<ConfiguracionServicioNube>(texto) ?? throw new InvalidDataException();
    ConfiguracionServicioNube.Validar(conexion);
}

static void ValidarEnsamblado(string ruta)
{
    // Leer el PE y sus recursos como datos. No cargar el ensamblado ni resolver
    // WinForms/dependencias, ni ejecutar inicializadores del programa publicado.
    using var archivo = File.OpenRead(Path.GetFullPath(ruta));
    using var pe = new PEReader(archivo);
    if (!pe.HasMetadata) throw new InvalidDataException();
    var metadata = pe.GetMetadataReader();
    var recursos = pe.PEHeaders.CorHeader?.ResourcesDirectory ?? throw new InvalidDataException();
    bool encontrada = false;
    foreach (var id in metadata.ManifestResources)
    {
        var recurso = metadata.GetManifestResource(id);
        if (metadata.GetString(recurso.Name) != "MYG_2027.Nube.Publica.json") continue;
        if (encontrada || !recurso.Implementation.IsNil || recurso.Offset > int.MaxValue
            || recursos.Size < 4 || recurso.Offset > recursos.Size - 4)
            throw new InvalidDataException();
        var lector = pe.GetSectionData(recursos.RelativeVirtualAddress).GetReader();
        lector.Offset = checked((int)recurso.Offset);
        int longitud = lector.ReadInt32();
        if (longitud < 1 || longitud > 64 * 1024 || longitud > lector.RemainingBytes
            || longitud > recursos.Size - (int)recurso.Offset - 4)
            throw new InvalidDataException();
        using var contenido = new MemoryStream(lector.ReadBytes(longitud));
        using var texto = new StreamReader(contenido, new UTF8Encoding(false, true), detectEncodingFromByteOrderMarks: true);
        ValidarRecursoPublico(texto.ReadToEnd());
        encontrada = true;
    }
    if (!encontrada) throw new InvalidDataException();
}
