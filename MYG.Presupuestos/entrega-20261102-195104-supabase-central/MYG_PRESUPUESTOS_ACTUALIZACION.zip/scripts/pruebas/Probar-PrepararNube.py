from pathlib import Path
import argparse,json,os,shutil,subprocess,tempfile
root=Path(__file__).resolve().parents[2]
dll=root/'scripts/Preparar-Nube/bin/Release/net10.0/Preparar-Nube.dll'
parser=argparse.ArgumentParser(description='Prueba la preparación pública de Nube MYG con archivos sintéticos y sin red.')
parser.add_argument('--no-build',action='store_true')
args=parser.parse_args()
exe=shutil.which('dotnet')
if not exe:
 candidate=Path(os.environ.get('DOTNET_ROOT',''))/('dotnet.exe' if os.name=='nt' else 'dotnet')
 if candidate.is_file():exe=str(candidate.resolve())
if not exe:raise RuntimeError('Instale .NET SDK 10 y añada dotnet al PATH.')
if not args.no_build:
 subprocess.run([exe,'build',str(root/'scripts/Preparar-Nube/Preparar-Nube.csproj'),'-c','Release','-m:1','-nr:false'],check=True)
if not dll.is_file():raise RuntimeError('Compile primero scripts/Preparar-Nube/Preparar-Nube.csproj en Release.')
checks=0
with tempfile.TemporaryDirectory(prefix='myg-nube-cli-') as folder:
 base=Path(folder)
 source=base/'config.json'; target=base/'publicacion'/'nube-myg.json'
 def run(args):
  p=subprocess.run([exe,str(dll),*map(str,args)],capture_output=True,text=True)
  assert 'SENTINELA_NO_DISTRIBUIR' not in p.stdout+p.stderr
  return p
 official={'Nombre':'Nube MYG Áncash','Url':'https://oficial.supabase.co','ClavePublicable':'sb_publishable_prueba_sintetica'}
 source.write_text(json.dumps({**official,'Acceso':'SENTINELA_NO_DISTRIBUIR','Refresco':'SENTINELA_NO_DISTRIBUIR'}))
 original=source.read_bytes()
 p=run([source,target]); assert p.returncode==0,p.stderr
 assert json.loads(target.read_bytes())==official
 assert source.read_bytes()==original
 checks+=3
 for encoding in ['utf-8-sig','utf-16']:
  source.write_bytes(json.dumps(official,ensure_ascii=False).encode(encoding))
  p=run([source,target]); assert p.returncode==0,p.stderr
  assert json.loads(target.read_bytes())==official
  checks+=2
 before=target.read_bytes()
 for invalid in [
  {**official,'ClavePublicable':'sb_secret_SENTINELA_NO_DISTRIBUIR'},
  {**official,'Url':'http://oficial.supabase.co'},
  {**official,'Url':'https://externo.example'},
  {**official,'Nombre':''}]:
  source.write_text(json.dumps(invalid))
  p=run([source,target]); assert p.returncode==1
  assert target.read_bytes()==before
  checks+=2
 source.write_text('{')
 p=run([source,target]); assert p.returncode==1 and target.read_bytes()==before
 checks+=1
 source.write_bytes(b'{"Nombre":"'+bytes([255])+b'"}')
 p=run([source,target]); assert p.returncode==1 and target.read_bytes()==before
 checks+=1
 p=run([base/'no-existe.json',target]); assert p.returncode==1 and target.read_bytes()==before
 checks+=1
 p=run([]); assert p.returncode==2
 checks+=1
 target.write_text(json.dumps({**official,'Acceso':'SENTINELA_NO_DISTRIBUIR'}))
 p=run([target,target]); assert p.returncode==0 and json.loads(target.read_bytes())==official
 checks+=1
 assert not list(base.rglob('*.tmp'))
 checks+=1
 central={**official,'ServicioBasesUrl':'https://central-myg.example'}
 source.write_text(json.dumps({**central,'Acceso':'SENTINELA_NO_DISTRIBUIR','Refresco':'SENTINELA_NO_DISTRIBUIR','ServiceRole':'SENTINELA_NO_DISTRIBUIR'}))
 original=source.read_bytes()
 p=run([source,target]); assert p.returncode==0,p.stderr
 assert json.loads(target.read_bytes())==central
 assert source.read_bytes()==original
 checks+=3
 before=target.read_bytes()
 for invalid_url in ['http://central-myg.example','https://usuario:clave@central-myg.example','https://central-myg.example?token=SENTINELA_NO_DISTRIBUIR']:
  source.write_text(json.dumps({**central,'ServicioBasesUrl':invalid_url}))
  p=run([source,target]); assert p.returncode==1
  assert target.read_bytes()==before
  checks+=2
 for service_url in [None,'','  ']:
  source.write_text(json.dumps({**official,'ServicioBasesUrl':service_url}))
  p=run([source,target,'--requerir-servicio']); assert p.returncode==1
  assert target.read_bytes()==before
  checks+=2
 source.write_text(json.dumps(central))
 p=run([source,target,'--requerir-servicio']); assert p.returncode==0,p.stderr
 assert json.loads(target.read_bytes())==central
 checks+=2
 p=run([source,target,'--opcion-invalida']); assert p.returncode==2
 checks+=1
 for public_config in [official,central]:
  source.write_text(json.dumps(public_config))
  original=source.read_bytes();before=target.read_bytes()
  p=run(['--validar',source]); assert p.returncode==0,p.stderr
  assert source.read_bytes()==original and target.read_bytes()==before
  checks+=2
 for embedded_invalid in [
  json.dumps({**official,'Sesion':'SENTINELA_NO_DISTRIBUIR'}),
  json.dumps({**official,'ClavePublicable':'sb_secret_SENTINELA_NO_DISTRIBUIR'}),
  json.dumps({**official,'Url':'http://oficial.supabase.co'}),
  json.dumps(official)[:-1]+',"Nombre":"duplicado"}',
  '{']:
  source.write_text(embedded_invalid)
  original=source.read_bytes();before=target.read_bytes()
  p=run(['--validar',source]); assert p.returncode==1
  assert source.read_bytes()==original and target.read_bytes()==before
  checks+=2
 p=run(['--validar',base/'no-existe.json']); assert p.returncode==1
 checks+=1
 # Ensamblados PE reales y desechables: el validador no carga ni ejecuta su código.
 fixture=base/'ensamblado';fixture.mkdir()
 project=fixture/'Recurso.csproj';payload=fixture/'publica.json'
 project.write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup>
 <TargetFramework>net10.0</TargetFramework><OutputType>Library</OutputType>
 <EnableDefaultCompileItems>false</EnableDefaultCompileItems>
 </PropertyGroup><ItemGroup><Compile Include="Fixture.cs" />
 <EmbeddedResource Include="publica.json" LogicalName="MYG_2027.Nube.Publica.json" WithCulture="false" Condition="'$(OmitirRecurso)' != 'true'" />
 </ItemGroup></Project>''')
 (fixture/'Fixture.cs').write_text('''using System;
using System.Runtime.CompilerServices;
public static class FixtureRecurso {
 [ModuleInitializer] public static void Inicializar() => throw new InvalidOperationException("SENTINELA_NO_DISTRIBUIR");
}''')
 for name,contents,omit,expected in [
  ('valida',official,False,0),('sin-recurso',official,True,1),
  ('campo-ajeno',{**official,'Sesion':'SENTINELA_NO_DISTRIBUIR'},False,1),
  ('clave-secreta',{**official,'ClavePublicable':'sb_secret_SENTINELA_NO_DISTRIBUIR'},False,1)]:
  payload.write_text(json.dumps(contents))
  output=fixture/name
  build=subprocess.run([exe,'build',str(project),'-c','Release','-o',str(output),'-m:1','-nr:false','-p:OmitirRecurso='+str(omit).lower()],capture_output=True,text=True)
  assert build.returncode==0,build.stdout+build.stderr
  assembly=output/'Recurso.dll';original=assembly.read_bytes()
  p=run(['--validar-ensamblado',assembly]);assert p.returncode==expected,p.stdout+p.stderr
  assert assembly.read_bytes()==original
  checks+=2
 corrupt=fixture/'corrupta.dll';corrupt.write_bytes(b'PE_SINTETICO_TRUNCADO')
 original=corrupt.read_bytes()
 p=run(['--validar-ensamblado',corrupt]);assert p.returncode==1
 assert corrupt.read_bytes()==original
 checks+=2
 assert not list(base.rglob('*.tmp'))
 checks+=1
 print(f'OK Preparar-Nube: {checks} comprobaciones de exportación pública, recurso integrado, privacidad, errores y actualización en el mismo archivo; sin red.')
