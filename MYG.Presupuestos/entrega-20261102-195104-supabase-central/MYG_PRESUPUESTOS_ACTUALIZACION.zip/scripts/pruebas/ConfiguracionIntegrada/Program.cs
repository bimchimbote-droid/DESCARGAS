using System.Text;
using System.Text.Json;
using System.Reflection;
using MYG.Colaboracion;
using MYG_2027;

string carpeta = Path.Combine(Path.GetTempPath(), "myg-conexion-integrada-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(carpeta);
int comprobaciones = 0;
void Exigir(bool condicion, string mensaje)
{
    if (!condicion) throw new InvalidOperationException(mensaje);
    comprobaciones++;
}
void Rechazar(Action accion, string mensaje)
{
    bool fallo = false;
    try { accion(); }
    catch (Exception ex) when (ex is IOException or InvalidDataException or JsonException or NubeException or DecoderFallbackException) { fallo = true; }
    Exigir(fallo, mensaje);
}
try
{
    string local = Path.Combine(carpeta, "perfil", "config.json");
    string anterior = Path.Combine(carpeta, "nube-myg.json");
    var publica = new ConfiguracionServicioNube("Nube integrada de prueba", "https://integrada.supabase.co", "sb_publishable_prueba_sintetica");
    byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(publica);
    Stream? Abrir() => typeof(NubeConfiguracion).Assembly.GetManifestResourceStream(NubeConfiguracion.RecursoIntegrado);

    if (args.Length == 2 && args[0] == "--verificar-ensamblado")
    {
        var compilada = Assembly.LoadFile(Path.GetFullPath(args[1]));
        using var integrada = compilada.GetManifestResourceStream(NubeConfiguracion.RecursoIntegrado);
        Exigir(integrada is not null, "El ensamblado publicado no incluye su conexión pública.");
        var recuperada = JsonSerializer.Deserialize<ConfiguracionServicioNube>(integrada!);
        Exigir(recuperada == publica, "El ensamblado no contiene la conexión sintética esperada.");
    }

    var limpia = NubeConfiguracion.Cargar(local, anterior, Abrir);
    Exigir(limpia?.Url == publica.Url && limpia.ClavePublicable == publica.ClavePublicable, "La instalación limpia no carga el recurso real.");
    Exigir(!File.Exists(local) && !File.Exists(anterior), "La instalación limpia creó configuración manual.");
    Exigir(Directory.GetFiles(carpeta, "*", SearchOption.AllDirectories).Length == 0, "La carga integrada escribió archivos.");
    using (var cliente = limpia!.CrearCliente())
        Exigir(cliente.UrlServidor == publica.Url && cliente.ServicioBasesUrl is null, "La conexión central requiere otro servicio.");

    ConfiguracionServicioNube.Guardar(anterior, publica with { Nombre = "Distribución anterior", Url = "https://anterior.supabase.co" });
    byte[] bytesAnteriores = File.ReadAllBytes(anterior);
    var actualizada = NubeConfiguracion.Cargar(local, anterior, Abrir);
    Exigir(actualizada?.Url == publica.Url, "Un archivo distribuido antiguo ocultó el recurso actualizado.");
    Exigir(File.ReadAllBytes(anterior).SequenceEqual(bytesAnteriores), "Se modificó la distribución anterior.");

    var propia = publica with { Nombre = "Perfil elegido", Url = "https://privada.supabase.co", ServicioBasesUrl = "https://servicio.example" };
    ConfiguracionServicioNube.Guardar(local, propia);
    byte[] originalLocal = File.ReadAllBytes(local);
    bool abierto = false;
    var conservada = NubeConfiguracion.Cargar(local, anterior, () => { abierto = true; throw new InvalidOperationException(); });
    Exigir(conservada?.Nombre == propia.Nombre && conservada.Url == propia.Url && conservada.ServicioBasesUrl == propia.ServicioBasesUrl, "Se sustituyó el perfil existente.");
    Exigir(!abierto && File.ReadAllBytes(local).SequenceEqual(originalLocal), "Se cambió la conexión o se abrió otro destino.");
    ConfiguracionServicioNube.Guardar(local, publica);
    ConfiguracionServicioNube.Guardar(anterior, publica with { ServicioBasesUrl = "https://legado.example" });
    var herencia = NubeConfiguracion.Cargar(local, anterior, Abrir);
    Exigir(herencia?.ServicioBasesUrl == "https://legado.example", "Se perdió la herencia del servicio de una distribución anterior.");
    ConfiguracionServicioNube.Guardar(anterior, publica with { Nombre = "Distribución anterior", Url = "https://anterior.supabase.co" });
    File.WriteAllText(local, "{");
    Rechazar(() => NubeConfiguracion.Cargar(local, anterior, Abrir), "Un perfil corrupto cambió silenciosamente de nube.");
    Exigir(File.ReadAllText(local) == "{", "Se sobreescribió el perfil corrupto.");
    File.Delete(local);

    var legado = NubeConfiguracion.Cargar(local, anterior, () => null);
    Exigir(legado?.Url == "https://anterior.supabase.co", "Se perdió compatibilidad con distribución sin recurso.");
    File.Delete(anterior);
    Exigir(NubeConfiguracion.Cargar(local, anterior, () => null) is null, "Una compilación de desarrollo inventó una conexión.");

    foreach (byte[] valido in new[] { bytes, Encoding.UTF8.GetPreamble().Concat(bytes).ToArray(), Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes(JsonSerializer.Serialize(publica))).ToArray() })
    {
        var cargada = NubeConfiguracion.Cargar(local, anterior, () => new MemoryStream(valido));
        Exigir(cargada?.Url == publica.Url, "El recurso con codificación admitida no se cargó.");
    }
    foreach (byte[] invalido in new[]
    {
        Encoding.UTF8.GetBytes("{"), new byte[65537],
        Encoding.UTF8.GetBytes(JsonSerializer.Serialize(publica with { ClavePublicable = "sb_secret_sintetica_prohibida" })),
        Encoding.UTF8.GetBytes(JsonSerializer.Serialize(publica with { Url = "http://integrada.supabase.co" }))
    })
        Rechazar(() => NubeConfiguracion.Cargar(local, anterior, () => new MemoryStream(invalido)), "Se aceptó un recurso dañado o secreto.");
    Exigir(!File.Exists(local) && !File.Exists(anterior), "Una validación fallida escribió configuración.");
    Console.WriteLine($"OK Configuración integrada: {comprobaciones} comprobaciones de instalación limpia, actualización y aislamiento; sin red.");
}
finally { Directory.Delete(carpeta, true); }
