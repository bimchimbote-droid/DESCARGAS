#!/usr/bin/env bash
# PostgreSQL local desechable, sin cuentas ni datos de producción.
set -euo pipefail
repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
test_workspace=$(mktemp -d -t myg-base-central-XXXXXXXX)
test_container=""
test_lock_pid=""
cleanup() {
    result=$?
    trap - EXIT
    if [[ -n "$test_lock_pid" ]]; then kill "$test_lock_pid" 2>/dev/null || true; wait "$test_lock_pid" 2>/dev/null || true; fi
    if [[ -n "$test_container" ]]; then docker rm -f "$test_container" >/dev/null 2>&1 || true; fi
    rm -rf -- "$test_workspace"
    exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_HOST=unix:///var/run/docker.sock
docker info --format '{{.ServerVersion}}'
postgres_test_image='postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
if ! docker image inspect "$postgres_test_image" >/dev/null 2>&1; then docker pull "$postgres_test_image"; fi
dotnet run --project "$repo_root/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" \
    -c Release -p:UseSharedCompilation=false -- "$test_workspace/paquetes"
test_container=$(docker run --detach --rm --network none --memory=2g --cpus=2 \
    --tmpfs /var/lib/postgresql/data:rw,size=1g \
    -e POSTGRES_HOST_AUTH_METHOD=trust "$postgres_test_image")
for attempt in {1..60}; do
    if docker exec "$test_container" pg_isready -U postgres >/dev/null 2>&1; then break; fi
    if [[ "$attempt" == 60 ]]; then docker logs "$test_container"; exit 1; fi
    sleep 1
done
docker exec -u root "$test_container" mkdir -p /pruebas
docker cp "$repo_root/supabase" "$test_container:/pruebas/supabase"
docker cp "$test_workspace/paquetes" "$test_container:/pruebas/paquetes"
docker exec -u root "$test_container" chmod -R a+rX /pruebas
docker exec -u postgres "$test_container" psql -X -d postgres \
    -v MYG_PRUEBAS_DESECHABLES=1 -v ON_ERROR_STOP=1 -f /pruebas/supabase/pruebas/base_central.sql

# Dos conexiones reales. Una obra bloqueada no debe detener el guardado de otra
# obra de la misma base; tampoco se debe esperar indefinidamente por la primera.
docker exec -e PGAPPNAME=myg-central-qa-doc-lock -u postgres "$test_container" \
    psql -X -v ON_ERROR_STOP=1 -d postgres -c "BEGIN;
    SELECT vista_id FROM myg_nube_privado.central_documentos
      WHERE base_id='d9500000-0000-0000-0000-000000000001' AND documento_id='QA-DOCUMENTO' FOR UPDATE;
    SELECT pg_sleep(6); ROLLBACK;" > "$test_workspace/bloqueo.log" 2>&1 &
test_lock_pid=$!
for attempt in {1..60}; do
    blocked=$(docker exec -u postgres "$test_container" psql -X -At -d postgres -c \
        "SELECT EXISTS(SELECT 1 FROM pg_stat_activity WHERE application_name='myg-central-qa-doc-lock' AND wait_event='PgSleep');")
    if [[ "$blocked" == t ]]; then break; fi
    if [[ "$attempt" == 60 ]]; then cat "$test_workspace/bloqueo.log"; exit 1; fi
    sleep 0.1
done
docker exec -u postgres "$test_container" psql -X -v ON_ERROR_STOP=1 -d postgres -c "
CREATE TEMPORARY TABLE qa_central_ids AS SELECT vista_id,documento_id FROM myg_nube_privado.central_documentos
    WHERE base_id='d9500000-0000-0000-0000-000000000001';
GRANT SELECT ON qa_central_ids TO authenticated;
SET ROLE authenticated; SET request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
SET statement_timeout='2s';
SELECT qa.rechaza(\$\$SELECT public.myg_central_guardar(vista_id,'c95f0000-0000-0000-0000-000000000001',2,contenido)
    FROM qa_central_ids,qa.central_payload WHERE documento_id='QA-DOCUMENTO' AND nombre='nombre'\$\$,'55006',
    'Central: segunda conexión rechaza pronto la misma obra ocupada');
SELECT qa.exige((SELECT public.myg_central_guardar(vista_id,'c95f0000-0000-0000-0000-000000000002',1,contenido)->>'revision'='2'
    FROM qa_central_ids,qa.central_payload WHERE documento_id='QA-DOCUMENTO-B' AND nombre='segunda'),
    'Central: obra distinta guarda durante el bloqueo de la primera');"
wait "$test_lock_pid"
test_lock_pid=""
