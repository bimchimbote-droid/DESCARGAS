param(
    [string]$RevitInstallDir = 'C:\Program Files\Autodesk\Revit 2027',
    [string]$ConfiguracionNube = '',
    [switch]$ColaboracionPorInternet
)
$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot
if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Instale el SDK de .NET 10.' }
if ([string]::IsNullOrWhiteSpace($ConfiguracionNube)) {
    $ConfiguracionNube = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MYG\Nube\config.json'
}
if (!(Test-Path -LiteralPath $ConfiguracionNube -PathType Leaf)) {
    throw 'No se encontró la configuración de distribución de Nube MYG. Indique -ConfiguracionNube con el archivo config.json que utilizará el instalador.'
}
foreach ($api in @('RevitAPI.dll', 'RevitAPIUI.dll')) {
    if (!(Test-Path (Join-Path $RevitInstallDir $api))) { throw "No se encontró $api en $RevitInstallDir." }
}
$escritorio = Join-Path $raiz 'dist\MYG'
$conector = Join-Path $raiz 'dist\Conector'
# El operador prepara una única conexión pública. Cada instalación recibe el
# recurso integrado; no se distribuye un archivo que el cliente deba configurar.
# ColaboracionPorInternet se conserva por compatibilidad con comandos anteriores:
# Supabase central no requiere ServicioBasesUrl ni un servidor SQLite externo.
$preparacionNube = Join-Path ([System.IO.Path]::GetTempPath()) ('myg-nube-publica-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $preparacionNube | Out-Null
try {
    $recursoNube = Join-Path $preparacionNube 'conexion.publica.json'
    & dotnet run --project (Join-Path $PSScriptRoot 'Preparar-Nube\Preparar-Nube.csproj') -c Release -- $ConfiguracionNube $recursoNube
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar la conexión pública de Nube MYG. No distribuya esta publicación.' }
    & dotnet publish (Join-Path $raiz 'MYG.Desktop\MYG.Desktop.csproj') -c Release -r win-x64 --self-contained true `
        '-p:PublishSingleFile=false' '-p:UseRevitReferencePackages=false' '-p:MygExigirNubeIntegrada=true' `
        "-p:MygNubeConfiguracionPublica=$recursoNube" -o $escritorio
    if ($LASTEXITCODE -ne 0) { throw 'Falló la publicación de MYG.Desktop.' }
    $conexionAnterior = Join-Path $escritorio 'nube-myg.json'
    if (Test-Path -LiteralPath $conexionAnterior -PathType Leaf) { Remove-Item -LiteralPath $conexionAnterior -Force }
}
finally { Remove-Item -LiteralPath $preparacionNube -Recurse -Force }
& dotnet build (Join-Path $raiz 'MYG.Revit2027\MYG.Revit2027.csproj') -c Release `
    "-p:RevitInstallDir=$RevitInstallDir" '-p:UseRevitReferencePackages=false' -o $conector
if ($LASTEXITCODE -ne 0) { throw 'Falló la compilación del conector.' }
$scripts = Join-Path $raiz 'dist\scripts'
New-Item -ItemType Directory -Force -Path $scripts | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'Instalar-Conector.ps1') $scripts -Force
Copy-Item (Join-Path $PSScriptRoot 'Desinstalar-Conector.ps1') $scripts -Force
Copy-Item (Join-Path $raiz 'LEEME.md') (Join-Path $raiz 'dist\LEEME.md') -Force
Write-Host "Publicación terminada: $escritorio"
Write-Host 'La conexión pública está integrada en el programa; cada usuario solo instala e ingresa con su propia cuenta MYG.'
Write-Host 'Distribuya la carpeta dist completa. MYG.Presupuestos.exe requiere los demás archivos de su carpeta.'
