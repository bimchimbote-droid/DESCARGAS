#nullable enable
using MYG.Colaboracion;
using System.IO;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private async Task PublicarBaseCentralAsync(ClienteSupabase cliente, NubeForm ventana)
    {
        var almacen = PublicacionesSqliteDe(cliente);
        var pendiente = await Task.Run(almacen.Consultar);
        if (pendiente is not null && pendiente.Alcance != "base")
            throw new InvalidOperationException("Hay una publicación anterior de obra pendiente. Revísela en Publicaciones pendientes; su copia local se conserva.");
        var ct = ventana.ComenzarPublicacion();
        bool confirmado = false;
        try
        {
            if (pendiente is null)
            {
                var activo = pestanasProyectos.SelectedTab?.Tag as EditorForm;
                using var dialogo = new NubePublicarForm(null, activo?.RutaProyecto ?? rutaBase, central: true);
                if (dialogo.ShowDialog(ventana) != System.Windows.Forms.DialogResult.OK) return;
                string? fuente = dialogo.RutaSQLite;
                if (dialogo.CrearVacia)
                {
                    var nueva = dialogo.Documento ?? throw new InvalidOperationException("No se preparó la base nueva.");
                    fuente = Path.Combine(CarpetaNube, "bases-nuevas", Guid.NewGuid().ToString("N"), "base.sqlite");
                    string rutaNueva = fuente;
                    await Task.Run(() => MYGProyectoStorage.Guardar(rutaNueva, nueva), ct);
                }
                string ruta = fuente ?? throw new InvalidOperationException("Seleccione la base que desea publicar.");
                string documentoId = dialogo.DocumentoPrincipalId ?? throw new InvalidOperationException("La base no contiene obras.");
                await PrepararPublicacionBaseAsync(ruta);
                // La cola existente congela una copia LOCAL y permite reintentar
                // tras cerrar MYG. Su archivo nunca se envía a Storage.
                pendiente = await Task.Run(() => almacen.Crear(dialogo.Nombre, "base",
                    ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documentoId), ruta, ct), ct);
            }
            ComprobarClienteActual(cliente);
            var envio = await Task.Run(() => almacen.Leer(pendiente), ct);
            // Adopta el ACK de un intento de publicación SQLite de versiones
            // anteriores antes de iniciar una nueva base con los mismos datos.
            var anterior = await cliente.ConsultarSqliteAsync(envio.Id, ct);
            ProyectoNube central;
            if (anterior is not null)
                central = anterior.Proyecto;
            else
            {
                var progreso = new Progress<string>(ventana.InformarProgresoPublicacion);
                central = await Task.Run(() => BaseCentralNube.PublicarAsync(cliente,
                    envio.RutaSQLite, envio.Nombre, ct, progreso), ct);
            }
            confirmado = true; ventana.PublicacionConfirmada();
            await Task.Run(() => almacen.Confirmar(envio));
            ComprobarClienteActual(cliente);
            await ventana.MostrarPublicacionConfirmadaAsync(central);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested && !confirmado)
        {
            ventana.InformarResultadoPublicacion("Se conservó la preparación local. Reintente desde Publicaciones pendientes para continuar la misma base.");
        }
        finally { ventana.TerminarPublicacion(); }
    }

    private async Task AbrirBaseCentralAsync(ClienteSupabase cliente, ProyectoNube central)
    {
        if (!central.EsCentralNativa || central.Alcance != "base" || central.Rol != "propietario")
            throw new InvalidOperationException("La base central completa solo está disponible para su propietario.");
        string carpeta = CarpetaDeProyectoNube(cliente, central.Id);
        string anterior = Path.Combine(carpeta, "trabajo.sqlite");
        // Una copia antigua de otro equipo puede conservar borradores. Se deja
        // intacta; la caché central tiene una ruta estable distinta en ese caso.
        string ruta = BaseCentralNube.EsBase(anterior) ? anterior : Path.Combine(carpeta, "central.sqlite");
        bool hayEditores = EditoresAbiertos.Any(e => MismaRuta(e.RutaProyecto, ruta));
        await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Abriendo las obras de su base central…", async progreso =>
        {
            return await Task.Run(async () =>
            {
                Directory.CreateDirectory(carpeta);
                if (!File.Exists(ruta))
                {
                    await BaseCentralNube.CrearCopiaAsync(cliente, central.Id, ruta, progreso: progreso);
                    return true;
                }
                ValidarBaseCentralLocal(cliente, ruta, central.Id);
                // Los editores abiertos conservan sus borradores. Sus barras
                // sincronizan cada obra y resuelven los conflictos por separado.
                if (hayEditores) return true;
                foreach (var obra in await cliente.ListarObrasCentralAsync(central.Id))
                {
                    var vinculo = MYGColaboracionLocal.Leer(ruta, obra.DocumentoId!);
                    if (vinculo is null)
                        BaseCentralNube.VincularObraLocal(cliente, ruta, await cliente.AbrirObraCentralAsync(obra.Id));
                    else
                    {
                        var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, obra.DocumentoId!);
                        await SincronizadorProyectoNube.EjecutarAsync(cliente, ruta, documento, soloLeer: true, progreso: progreso);
                    }
                }
                return true;
            });
        });
        ComprobarClienteActual(cliente);
        var lectura = await Task.Run(() => LeerListaProyectos(ruta));
        ComprobarClienteActual(cliente);
        rutaBase = ruta; datos = lectura.Proyectos;
        RegistrarListaProyectos(rutaBase, lectura.Revision);
        obrasBaseNube = Array.Empty<ObraBaseNube>(); rutaIndiceBaseNube = null;
        MostrarProyectos(); SeleccionarPagina(paginaInicio); ventanaNube?.Hide();
    }

    private async Task DescargarBaseCentralAsync(ClienteSupabase cliente, ProyectoNube central)
    {
        using var dialogo = new System.Windows.Forms.SaveFileDialog
        {
            Title = "Exportar base central", Filter = "Base SQLite (*.sqlite)|*.sqlite",
            FileName = "MYG_BASE.sqlite", AddExtension = true, OverwritePrompt = false
        };
        if (dialogo.ShowDialog(ventanaNube ?? (System.Windows.Forms.IWin32Window)this)
            != System.Windows.Forms.DialogResult.OK) return;
        string destino = dialogo.FileName;
        if (File.Exists(destino)) throw new IOException("Elija un nombre nuevo para conservar el archivo existente.");
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-exportar-central-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        string temporal = Path.Combine(carpeta, "base.sqlite");
        try
        {
            await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Exportando las obras confirmadas…", async progreso =>
            {
                await BaseCentralNube.CrearCopiaAsync(cliente, central.Id, temporal, progreso: progreso);
                using (var c = new Microsoft.Data.Sqlite.SqliteConnection(new Microsoft.Data.Sqlite.SqliteConnectionStringBuilder
                { DataSource = temporal, Mode = Microsoft.Data.Sqlite.SqliteOpenMode.ReadWrite, Pooling = false }.ToString()))
                {
                    c.Open();
                    using var q = c.CreateCommand();
                    q.CommandText = "DROP TABLE IF EXISTS myg_colaboracion_local; DROP TABLE IF EXISTS myg_base_central_local; VACUUM";
                    q.ExecuteNonQuery();
                }
                // Copiar a un nombre nuevo evita cualquier reemplazo de archivos
                // de trabajo. Los adjuntos se materializan junto a la exportación.
                var obras = MYGBaseDatos.ListarProyectos(temporal);
                var principal = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(temporal, obras[0].Id);
                var contenido = PaqueteNube.CrearContenido(principal, temporal, "base");
                PaqueteNube.Descargar(contenido, destino);
                return true;
            });
            ComprobarClienteActual(cliente);
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static void ValidarBaseCentralLocal(ClienteSupabase cliente, string ruta, Guid baseId)
    {
        var vinculo = BaseCentralNube.LeerBase(ruta)
            ?? throw new InvalidOperationException("La copia existente no tiene un vínculo central válido. Consérvela antes de recuperar otra copia.");
        if (vinculo.BaseId != baseId || vinculo.Usuario != cliente.UsuarioId
            || !string.Equals(vinculo.Servidor, cliente.UrlServidor, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Abra esta base con la misma cuenta MYG y conexión que la descargaron.");
    }

    private async Task<ProyectoNube> PrepararObraCentralAsync(ClienteSupabase cliente, string ruta,
        Guid baseId, string documentoId)
    {
        ValidarBaseCentralLocal(cliente, ruta, baseId);
        await PrepararPublicacionBaseAsync(ruta);
        var obra = await Task.Run(() => BaseCentralNube.RegistrarObraAsync(cliente, ruta, baseId, documentoId));
        ComprobarClienteActual(cliente);
        foreach (var editor in EditoresAbiertos.Where(e => MismaRuta(e.RutaProyecto, ruta)))
            await editor.ActualizarEdicionBaseNubeAsync(false);
        return obra;
    }

    private async Task<ProyectoNube> MigrarYPrepararObraCentralAsync(ClienteSupabase cliente, string ruta,
        Guid baseId, string documentoId)
    {
        if (!await cliente.AdmiteCentralAsync())
            throw new NubeException("Falta aplicar 20261106_base_central.sql en Supabase. Esta actualización habilita la colaboración por obra sin configurar otro servidor.");
        var existente = await cliente.ResolverCentralAsync(baseId);
        if (existente is null)
        {
            await PrepararPublicacionBaseAsync(ruta);
            var documento = await Task.Run(() => ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documentoId));
            var resultado = await MYGCargaAnimada.EjecutarConProgresoAsync(this,
                "Sincronizando la base antes de activar la colaboración…",
                progreso => Task.Run(() => CopiaSqliteNube.EjecutarAsync(cliente, ruta, documento, progreso: progreso)));
            if (resultado.Vinculo.Pendiente is not null || resultado.Vinculo.RevisionRemotaConflicto > 0)
                throw new InvalidOperationException("Resuelva los cambios pendientes o el conflicto de esta base antes de activar la colaboración. Sus cambios se conservan.");
            foreach (var editor in EditoresAbiertos.Where(e => MismaRuta(e.RutaProyecto, ruta)))
                await editor.ActualizarEdicionBaseNubeAsync(true);
            var remoto = await cliente.AbrirSqliteAsync(baseId);
            await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Preparando las obras en Supabase…",
                progreso => Task.Run(() => BaseCentralNube.PrepararMigracionAsync(cliente, ruta, remoto, progreso: progreso)));
        }
        else
        {
            // Recupera un cierre después del commit sin repetir la importación
            // ni declarar confirmados los borradores posteriores a ella.
            await PrepararPublicacionBaseAsync(ruta);
            await Task.Run(() => BaseCentralNube.RecuperarActivacionAsync(cliente, ruta, baseId));
        }
        ComprobarClienteActual(cliente);
        foreach (var editor in EditoresAbiertos.Where(e => MismaRuta(e.RutaProyecto, ruta)))
            await editor.ActualizarEdicionBaseNubeAsync(false);
        return await PrepararObraCentralAsync(cliente, ruta, baseId, documentoId);
    }
}
