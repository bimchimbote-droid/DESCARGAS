#nullable enable
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    // Compatibilidad de lectura con índices privados anteriores. Las bases nuevas
    // usan trabajo.sqlite y un único vínculo/cola para todas sus obras.
    private sealed record IndiceBaseNube(Guid BaseId, string Servidor, string Usuario);
    private IReadOnlyList<ObraBaseNube> obrasBaseNube = Array.Empty<ObraBaseNube>();
    private string? rutaIndiceBaseNube;
    private static string RutaIndice(string ruta) => ruta + ".base-nube.json";
    private static bool EsIndiceBaseNube(string? ruta) => !string.IsNullOrWhiteSpace(ruta) && File.Exists(RutaIndice(ruta));
    private static void RegistrarDuracionApertura(string etapa, System.Diagnostics.Stopwatch reloj) =>
        System.Diagnostics.Trace.WriteLine($"MYG apertura · {etapa}: {reloj.Elapsed.TotalMilliseconds:F0} ms");

    private ArchivoPublicacionBasePendiente PublicacionesBaseDe(ClienteSupabase cliente) => new(
        Path.Combine(CarpetaNube, "publicaciones-bases"), cliente.UrlServidor, cliente.UsuarioId!);

    private async Task<bool> GestionarPublicacionBasePendienteAsync(ClienteSupabase cliente)
    {
        var almacen = PublicacionesBaseDe(cliente);
        var pendiente = await Task.Run(almacen.Consultar);
        ComprobarClienteActual(cliente);
        if (pendiente is null) return false;
        var opcion = WinForms.MessageBox.Show(ventanaNube,
            "Hay una importación del formato anterior: " + pendiente.Nombre + ".\n\n"
            + "Ahora se publica únicamente la base SQLite, sin crear obras separadas. "
            + "¿Retirar el intento anterior conservando todas sus copias para preparar una publicación de base única? "
            + "Las publicaciones ya existentes en nube no se eliminan.",
            "Publicación anterior", WinForms.MessageBoxButtons.OKCancel, WinForms.MessageBoxIcon.Information);
        ComprobarClienteActual(cliente);
        if (opcion != WinForms.DialogResult.OK) return true;
        await Task.Run(() => almacen.Retirar(pendiente));
        return false;
    }

    private async Task<string> PrepararArchivoBaseNubeAsync(ClienteSupabase cliente, ProyectoSqliteNube remoto)
    {
        if (remoto.Proyecto.Alcance != "base" || remoto.Proyecto.Rol != "propietario")
            throw new InvalidOperationException("La base completa solo puede abrirla su propietario.");
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Proyecto.Id);
        string ruta = Path.Combine(carpeta, "trabajo.sqlite");
        bool hayEditores = EditoresAbiertos.Any(e => MismaRuta(e.RutaProyecto, ruta));
        await Task.Run(async () =>
        {
            var reloj = System.Diagnostics.Stopwatch.StartNew();
            Directory.CreateDirectory(carpeta);
            if (!File.Exists(ruta))
            {
                string temporal = Path.Combine(carpeta, "descarga-" + Guid.NewGuid().ToString("N") + ".sqlite");
                try
                {
                    await cliente.DescargarSqliteAsync(remoto, temporal);
                    ComprobarClienteActual(cliente);
                    File.Move(temporal, ruta);
                }
                finally { if (File.Exists(temporal)) File.Delete(temporal); }
                RegistrarDuracionApertura("descarga SQLite", reloj);
            }
            else RegistrarDuracionApertura("reutilización de copia local", reloj);
            reloj.Restart();
            var vinculo = CopiaSqliteNube.LeerVinculo(ruta, remoto.DocumentoId);
            if (vinculo is null)
            {
                // Un cierre después de descargar puede dejar un archivo sin vínculo.
                // Solo se adopta si sus bytes siguen siendo los confirmados por nube.
                using (var archivo = File.OpenRead(ruta))
                    if (!string.Equals(Convert.ToHexString(SHA256.HashData(archivo)), remoto.Archivo.Sha256,
                        StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("La copia existente no tiene vínculo y conserva otros bytes. Guárdela antes de recuperar otra copia; no se sobrescribirá.");
                CopiaSqliteNube.Vincular(ruta, remoto, cliente);
            }
            else
            {
                SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
                if (vinculo.ProyectoId != remoto.Proyecto.Id)
                    throw new InvalidOperationException("La copia pertenece a otra base remota.");
                if (!CopiaSqliteNube.EsBase(ruta)) CopiaSqliteNube.Vincular(ruta, remoto, cliente);
                // Con editores abiertos se conserva su trabajo. Recargar desde una
                // obra coordina los borradores de todas las pestañas del archivo.
                if (!hayEditores && remoto.Proyecto.Revision > vinculo.Revision)
                {
                    var doc = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, remoto.DocumentoId);
                    await CopiaSqliteNube.EjecutarAsync(cliente, ruta, doc, soloLeer: true);
                }
            }
            RegistrarDuracionApertura("validación y vínculo SQLite", reloj);
        });
        ComprobarClienteActual(cliente);
        return ruta;
    }

    private async Task AbrirBaseNubeAsync(ClienteSupabase cliente, ProyectoSqliteNube remoto)
    {
        var lectura = await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Abriendo la base SQLite y su lista de obras…", async progreso =>
        {
            progreso.Report("Preparando el archivo SQLite de trabajo…");
            string ruta = await PrepararArchivoBaseNubeAsync(cliente, remoto);
            progreso.Report("Leyendo la lista de obras de la base…");
            var reloj = System.Diagnostics.Stopwatch.StartNew();
            var lista = await Task.Run(() => LeerListaProyectos(ruta));
            RegistrarDuracionApertura("consulta de lista de obras", reloj);
            return (Ruta: ruta, Lista: lista);
        });
        ComprobarClienteActual(cliente);
        rutaBase = lectura.Ruta; datos = lectura.Lista.Proyectos;
        RegistrarListaProyectos(rutaBase, lectura.Lista.Revision);
        obrasBaseNube = Array.Empty<ObraBaseNube>(); rutaIndiceBaseNube = null;
        var interfaz = System.Diagnostics.Stopwatch.StartNew();
        MostrarProyectos(); SeleccionarPagina(paginaInicio);
        RegistrarDuracionApertura("presentación de la lista", interfaz);
        ventanaNube?.Hide();
    }

    private async Task PrepararIndiceBaseNubeAsync(string ruta)
    {
        if (!EsIndiceBaseNube(ruta))
        {
            obrasBaseNube = Array.Empty<ObraBaseNube>(); rutaIndiceBaseNube = null;
            return;
        }
        var indice = JsonSerializer.Deserialize<IndiceBaseNube>(await File.ReadAllTextAsync(RutaIndice(ruta)))
            ?? throw new InvalidDataException("No se pudo leer el vínculo de la base. Se conserva su copia.");
        if (clienteNube?.SesionIniciada != true) await MostrarNubeAsync();
        var cliente = RequerirNube();
        if (indice.Usuario != cliente.UsuarioId || !string.Equals(indice.Servidor.TrimEnd('/'),
            cliente.UrlServidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Abra la base con la misma cuenta y servidor que la descargaron.");
        var remoto = await cliente.AbrirSqliteAsync(indice.BaseId);
        ComprobarClienteActual(cliente);
        rutaIndiceBaseNube = await PrepararArchivoBaseNubeAsync(cliente, remoto);
        obrasBaseNube = Array.Empty<ObraBaseNube>();
        ventanaNube?.Hide();
    }

    private async Task<EditorForm> AbrirObraBaseNubeAsync(string ruta, string documentoId)
    {
        await PrepararIndiceBaseNubeAsync(ruta);
        string trabajo = rutaIndiceBaseNube ?? throw new InvalidOperationException("No se pudo preparar la base SQLite de trabajo.");
        return await CargarYAbrirProyectoAsync(trabajo, documentoId);
    }

    private void ExigirBaseLocalEditable()
    {
        if (EsIndiceBaseNube(rutaBase))
            throw new InvalidOperationException("Este archivo es un índice privado anterior. Abra la base desde Nube MYG para trabajar con su copia SQLite actual; se conserva el índice privado.");
    }


    private void MenuObraNube(object? sender, WinForms.DataGridViewCellEventArgs e)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        if (e.RowIndex < 0 || e.ColumnIndex < 0 || proyectos.Columns[e.ColumnIndex].Name != "NUBE_OBRA") return;
        proyectos.CurrentCell = proyectos.Rows[e.RowIndex].Cells[0];
        var obra = proyectos.Rows[e.RowIndex].Tag as MYGProyectoResumen;
        if (obra is null) return;
        string ruta = rutaBase;
        var menu = new WinForms.ContextMenuStrip { Name = "menuObraNube" };
        var abrirObra = menu.Items.Add("Abrir obra");
        abrirObra.Click += (_, _) => EjecutarDesdeMenuObraNube(async () => { await CargarYAbrirProyectoAsync(ruta, obra.Id); });
        var vinculo = VinculoColaboracionObra(ruta, obra.Id);
        if (vinculo is not null)
        {
            var agregar = menu.Items.Add("Agregar colaborador…");
            agregar.Name = "agregarColaboradorObra";
            agregar.Enabled = sesion.Autorizado && vinculo.Rol is "propietario" or "administrador";
            agregar.Click += (_, _) => EjecutarDesdeMenuObraNube(() => ColaboracionObraBaseAsync(ruta, obra.Id, agregar: true));
            var configurar = menu.Items.Add("Configurar colaboradores…");
            configurar.Name = "configurarColaboradoresObra";
            configurar.Enabled = sesion.Autorizado;
            configurar.Click += (_, _) => EjecutarDesdeMenuObraNube(() => ColaboracionObraBaseAsync(ruta, obra.Id, agregar: false));
        }
        else
        {
            var publicar = menu.Items.Add("Publicar base completa…");
            publicar.Click += (_, _) => EjecutarDesdeMenuObraNube(async () =>
            {
                await MostrarNubeAsync();
                await PublicarProyectoSqliteNube();
            });
        }
        MostrarMenuObraNube(menu);
    }

    private static MYGVinculoNube? VinculoColaboracionObra(string ruta, string documentoId)
    {
        var obra = CopiaSqliteNube.LeerVinculo(ruta, documentoId) ?? MYGColaboracionLocal.Leer(ruta, documentoId);
        if (obra is not null) return obra;
        var central = BaseCentralNube.LeerBase(ruta);
        return central is null ? null : new MYGVinculoNube
        {
            ProyectoId = central.BaseId, Servidor = central.Servidor, UsuarioId = central.Usuario,
            Rol = "propietario", Revision = 1
        };
    }

    private void EjecutarDesdeMenuObraNube(Func<Task> accion)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        // Completar el clic antes de abrir cargas o diálogos que procesan mensajes.
        BeginInvoke(new Action(async () =>
        {
            if (IsDisposed || Disposing) return;
            await IntentarAsync(accion);
        }));
    }

    private void MostrarMenuObraNube(WinForms.ContextMenuStrip menu)
    {
        componentesMenusInicio.Add(menu);
        menu.Closed += (_, _) =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated || menu.IsDisposed) return;
            // Closed todavía pertenece al cierre interno de WinForms. Liberar
            // después desde Inicio, que también conserva los menús abiertos.
            BeginInvoke(new Action(() =>
            {
                if (!menu.IsDisposed && !menu.Disposing) menu.Dispose();
            }));
        };
        menu.Show(proyectos, proyectos.PointToClient(WinForms.Cursor.Position));
    }

}
