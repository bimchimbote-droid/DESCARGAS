#nullable enable
using System;
using System.IO;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

namespace MYG_2027;

/// <summary>La configuración contiene solo el destino y una clave pública; nunca una sesión.</summary>
public sealed record ConfiguracionNube(string Nombre, string Url, string ClavePublicable)
{
    public string? ServicioBasesUrl { get; init; }
    public ClienteSupabase CrearCliente() => new(Url, ClavePublicable) { ServicioBasesUrl = ServicioBasesUrl };
}

public static class NubeConfiguracion
{
    internal const string RecursoIntegrado = "MYG_2027.Nube.Publica.json";
    public static string Ruta => Path.Combine(Environment.GetFolderPath(
        Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "config.json");
    public static string RutaDistribuida => Path.Combine(AppContext.BaseDirectory, "nube-myg.json");

    public static ConfiguracionNube? Cargar()
    {
        return Cargar(Ruta, RutaDistribuida, () => typeof(NubeConfiguracion).Assembly
            .GetManifestResourceStream(RecursoIntegrado));
    }

    /// <summary>Una actualización conserva la conexión local existente. Una instalación
    /// limpia utiliza la conexión pública integrada en el ejecutable.</summary>
    internal static ConfiguracionNube? Cargar(string rutaLocal, string rutaDistribuida, Func<Stream?> abrirIntegrada)
    {
        var configuracion = ConfiguracionServicioNube.Cargar(rutaLocal, rutaLocal);
        if (configuracion is not null && configuracion.ServicioBasesUrl is null)
        {
            // Mantener la actualización automática del servicio legado distribuido.
            // Si alguien cambia el perfil entre lecturas, conservar la primera
            // identidad validada en lugar de adoptar otra nube durante la carga.
            var actualizada = ConfiguracionServicioNube.Cargar(rutaLocal, rutaDistribuida);
            if (actualizada is not null && actualizada.Nombre == configuracion.Nombre
                && actualizada.Url == configuracion.Url && actualizada.ClavePublicable == configuracion.ClavePublicable)
                configuracion = actualizada;
        }
        if (configuracion is null)
        {
            using var recurso = abrirIntegrada();
            if (recurso is not null)
            {
                // El recurso también se valida al compilar. Validarlo aquí conserva
                // el mismo límite y rechaza una instalación dañada sin cambiar de nube.
                using var contenido = new MemoryStream();
                var bloque = new byte[4096];
                int leidos;
                while ((leidos = recurso.Read(bloque)) != 0)
                {
                    if (contenido.Length + leidos > 64 * 1024)
                        throw new InvalidDataException("La conexión integrada de Nube MYG excede el tamaño permitido.");
                    contenido.Write(bloque, 0, leidos);
                }
                contenido.Position = 0;
                using var lector = new StreamReader(contenido, new UTF8Encoding(false, true), detectEncodingFromByteOrderMarks: true);
                configuracion = JsonSerializer.Deserialize<ConfiguracionServicioNube>(lector.ReadToEnd())
                    ?? throw new InvalidDataException("La instalación no contiene una conexión válida de Nube MYG.");
                ConfiguracionServicioNube.Validar(configuracion);
            }
            else configuracion = ConfiguracionServicioNube.Cargar(rutaLocal, rutaDistribuida);
        }
        return configuracion is null ? null : new ConfiguracionNube(
            configuracion.Nombre, configuracion.Url, configuracion.ClavePublicable)
            { ServicioBasesUrl = configuracion.ServicioBasesUrl };
    }

    public static void Guardar(ConfiguracionNube configuracion)
    {
        ArgumentNullException.ThrowIfNull(configuracion);
        ConfiguracionServicioNube.Guardar(Ruta, new ConfiguracionServicioNube(
            configuracion.Nombre, configuracion.Url, configuracion.ClavePublicable)
            { ServicioBasesUrl = configuracion.ServicioBasesUrl });
    }

}
