using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Colaboracion;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private Func<ClienteSupabase> obtenerClienteNube;
    private Action mostrarColaboracionNube;
    private Func<EditorForm, Task> prepararSincronizacionBase;
    private Func<EditorForm, bool, Task> actualizarEditoresBase;
    private MYGVinculoNube vinculoNube;
    private FlowLayoutPanel barraNube;
    private TableLayoutPanel contenedorNube;
    private Label estadoNube;
    private Button sincronizarNube, recargarNube, resolverNube;
    private System.Windows.Forms.Timer relojPermisosNube;
    private bool permisoNubeAnterior, conservandoEdicionNube, bimBloqueadoNube, actualizandoNube;
    private bool obraAusenteEnBaseNube;

    internal Guid? NubeProyectoId => vinculoNube?.ProyectoId;
    internal string NubeServidor => vinculoNube?.Servidor;
    internal string NubeUsuario => vinculoNube?.UsuarioId;

    private bool IdentidadNubeDisponible
    {
        get
        {
            if (vinculoNube == null) return true;
            ClienteSupabase actual = obtenerClienteNube?.Invoke();
            return actual?.SesionIniciada == true && actual.UsuarioId == vinculoNube.UsuarioId
                && string.Equals(actual.UrlServidor.TrimEnd('/'), vinculoNube.Servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase);
        }
    }

    private bool PuedeModificarProyecto => !obraAusenteEnBaseNube && (conservandoEdicionNube || sesion.Autorizado &&
        (vinculoNube == null || IdentidadNubeDisponible && SincronizadorProyectoNube.PuedeEditar(vinculoNube.Rol)
            && vinculoNube.EstadoConexion != "acceso retirado"));

    private bool PuedeEditarMetradosRevit => PuedeModificarProyecto &&
        (vinculoNube == null || vinculoNube.PermisosModulos?.MetradosRevit == true);

    private bool PuedeActualizarResultadosBim => PuedeEditarMetradosRevit &&
        (vinculoNube == null || vinculoNube.PermisosModulos is { Acu: true, Especificaciones: true, MetradosExcel: true });

    private void ExigirPermisoMetradosRevit()
    {
        ExigirPermisoEdicionProyecto();
        if (!PuedeEditarMetradosRevit)
            throw new InvalidOperationException("Metrados Revit está en solo lectura. Solicite este permiso al administrador de la obra.");
    }

    private void ExigirPermisosModulosEstructura(bool acu = true, bool especificaciones = true, bool metrados = true)
    {
        ExigirPermisoEdicionProyecto();
        var permisos = vinculoNube?.PermisosModulos;
        if (acu && permisos?.Acu == false || especificaciones && permisos?.Especificaciones == false
            || metrados && permisos?.MetradosExcel == false || permisos?.MetradosRevit == false)
            throw new InvalidOperationException("Esta acción puede cambiar módulos configurados en solo lectura. Solicite permiso al administrador.");
    }

    private void ExigirPermisoEdicionProyecto()
    {
        if (!PuedeModificarProyecto)
            throw new InvalidOperationException(vinculoNube == null
                ? "Inicie una sesión autorizada para modificar el proyecto."
                : "Esta copia está en solo lectura. Compruebe la sesión de nube y el permiso del proyecto. Puede consultar y guardar una copia local.");
    }

    internal void ConfigurarNube(Func<ClienteSupabase> obtenerCliente, Action mostrarColaboracion,
        Func<EditorForm, Task> prepararBase = null, Func<EditorForm, bool, Task> actualizarBase = null)
    {
        obtenerClienteNube = obtenerCliente;
        mostrarColaboracionNube = mostrarColaboracion;
        prepararSincronizacionBase = prepararBase;
        actualizarEditoresBase = actualizarBase;
        RecargarVinculoNube();
        if (vinculoNube == null && contenedorNube == null) return;
        if (contenedorNube == null)
        {
            barraNube = new FlowLayoutPanel
            {
                Name = "barra_proyecto_nube", Dock = DockStyle.Fill, AutoScroll = true,
                WrapContents = false, Padding = new(8, 5, 6, 3), Margin = new(0),
                BackColor = MYG2027_TemaComercial.AzulSuave
            };
            estadoNube = new Label { Name = "estado_proyecto_nube", Width = 330, Height = 32,
                TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true, Margin = new(0, 0, 8, 0) };
            barraNube.Controls.Add(estadoNube);
            Button Boton(string texto, string nombre, Func<Task> accion)
            {
                var boton = MYGProyectoUI.Boton(texto); boton.Name = nombre;
                boton.AutoSize = true; boton.Height = 32; boton.Margin = new(0, 0, 6, 0);
                boton.Click += async (_, _) =>
                {
                    try { await accion(); }
                    catch (Exception ex) { estado.Text = ex.Message; MYGProyectoUI.Error(this, ex); }
                };
                barraNube.Controls.Add(boton); return boton;
            }
            sincronizarNube = Boton("Sincronizar", "sincronizar_proyecto_nube", () => ActualizarNubeAsync(false));
            recargarNube = Boton("Recargar", "recargar_proyecto_nube", () => ActualizarNubeAsync(true));
            Boton("Colaboración", "colaboracion_proyecto_nube", () =>
            { mostrarColaboracionNube?.Invoke(); return Task.CompletedTask; });
            resolverNube = Boton("Resolver conflicto", "resolver_conflicto_nube", ResolverConflictoNubeAsync);
            Boton("Guardar copia local", "copia_local_proyecto_nube", () =>
            { GuardarCopiaLocalNube(); return Task.CompletedTask; });
            ayudas.SetToolTip(recargarNube, "Consulta la revisión y los permisos del servidor. Si hay cambios locales, se conservan como conflicto.");
            contenedorNube = new TableLayoutPanel { Name = "contenedor_proyecto_nube", Dock = DockStyle.Fill,
                ColumnCount = 1, RowCount = 2, Margin = new(0), Padding = new(0) };
            contenedorNube.ColumnStyles.Add(new(SizeType.Percent, 100));
            contenedorNube.RowStyles.Add(new(SizeType.Absolute, 48));
            contenedorNube.RowStyles.Add(new(SizeType.Percent, 100));
            Controls.Remove(exteriorPresupuestoCronograma);
            contenedorNube.Controls.Add(barraNube, 0, 0);
            contenedorNube.Controls.Add(exteriorPresupuestoCronograma, 0, 1);
            Controls.Add(contenedorNube);
            panelPresupuesto.ConfigurarPermisoNube(() => PuedeModificarProyecto, () => vinculoNube?.PermisosModulos);
            relojPermisosNube = new System.Windows.Forms.Timer { Interval = 1000 };
            relojPermisosNube.Tick += (_, _) => ActualizarEstadoNube();
            relojPermisosNube.Start();
            Disposed += (_, _) => relojPermisosNube.Dispose();
        }
        ActualizarEstadoNube(); EstadoSesion();
    }

    private void RecargarVinculoNube()
    {
        if (obraAusenteEnBaseNube) return; // Conservar el vínculo y la copia visible para recuperación.
        vinculoNube = !string.IsNullOrWhiteSpace(archivo) && File.Exists(archivo)
            ? LeerVinculoTrabajoNube(archivo, documento.Id) : null;
    }

    private static MYGVinculoNube LeerVinculoTrabajoNube(string ruta, string id) =>
        CopiaSqliteNube.LeerVinculo(ruta, id) ?? MYGColaboracionLocal.Leer(ruta, id);

    private void ActualizarEstadoNube()
    {
        if (IsDisposed || barraNube == null) return;
        bool permisoAnterior = permisoNubeAnterior;
        ConservarEdicionAntesDeBloquearNube();
        bool permiso = PuedeModificarProyecto;
        bool cambioPermiso = permiso != permisoAnterior;
        permisoNubeAnterior = permiso;
        barraNube.Visible = vinculoNube != null;
        contenedorNube.RowStyles[0].Height = vinculoNube == null ? 0 : (float)Math.Ceiling(48F * DeviceDpi / 96F);
        if (vinculoNube != null)
        {
            string estadoActual = !string.IsNullOrWhiteSpace(vinculoNube.EstadoConexion)
                ? vinculoNube.EstadoConexion : vinculoNube.Estado;
            if (obraAusenteEnBaseNube) estadoActual = "obra ausente de la revisión recibida · guarde una copia local";
            else if (!string.IsNullOrWhiteSpace(vinculoNube.JsonRemotoConflicto)) estadoActual = "conflicto";
            else if (estadoActual != "acceso retirado" && !IdentidadNubeDisponible) estadoActual = "solo lectura · falta sesión de nube";
            else if (estadoActual != "acceso retirado" && !sesion.Autorizado) estadoActual = "solo lectura · falta sesión MYG";
            else if (estadoActual != "acceso retirado" && !SincronizadorProyectoNube.PuedeEditar(vinculoNube.Rol)) estadoActual = "solo lectura";
            if (vinculoNube.Pendiente != null && !estadoActual.Contains("pendiente", StringComparison.OrdinalIgnoreCase))
                estadoActual += " · pendiente";
            estadoNube.Text = "NUBE · " + estadoActual + " · r" + vinculoNube.Revision + " · " + vinculoNube.Rol;
            ayudas.SetToolTip(estadoNube, estadoNube.Text + "\n" + vinculoNube.Servidor);
            sincronizarNube.Enabled = !obraAusenteEnBaseNube && !ocupado && IdentidadNubeDisponible && vinculoNube.EstadoConexion != "acceso retirado"
                && string.IsNullOrWhiteSpace(vinculoNube.JsonRemotoConflicto);
            recargarNube.Enabled = !obraAusenteEnBaseNube && !ocupado && IdentidadNubeDisponible;
            resolverNube.Enabled = !obraAusenteEnBaseNube && !ocupado && !string.IsNullOrWhiteSpace(vinculoNube.JsonRemotoConflicto);
        }
        panelPresupuesto?.ActualizarPermisoNube();
        if (cambioPermiso) EstadoSesion();
    }

    private void ConservarEdicionAntesDeBloquearNube()
    {
        if (obraAusenteEnBaseNube || vinculoNube == null || !permisoNubeAnterior || PuedeModificarProyecto || ocupado || conservandoEdicionNube) return;
        // Se confirma una edición ya iniciada antes de pasar a solo lectura.
        conservandoEdicionNube = true;
        try { Sincronizar(); Guardar(false); }
        catch (Exception ex) { estado.Text = "No se pudo conservar la edición pendiente: " + ex.Message; }
        finally { conservandoEdicionNube = false; permisoNubeAnterior = false; }
    }

    private void AplicarPermisosBimNube()
    {
        if (vinculoNube == null || PuedeModificarProyecto)
        {
            if (!bimBloqueadoNube) { AplicarPermisosModeladoresBim(); return; }
            foreach (Control grupo in acciones.Controls)
                foreach (Button boton in grupo.Controls.OfType<Button>()) boton.Enabled = !ocupado && sesion.Autorizado;
            foreach (Control grupo in pie.Controls)
                foreach (Button boton in grupo.Controls.OfType<Button>()) boton.Enabled = !ocupado;
            bimBloqueadoNube = false; ActualizarDisponibilidad(); AplicarPermisosModeladoresBim(); return;
        }
        bimBloqueadoNube = true;
        foreach (Control grupo in acciones.Controls)
            foreach (Button boton in grupo.Controls.OfType<Button>())
                boton.Enabled = !ocupado && boton.Text is "Expandir todo" or "Contraer todo" or "Columnas" or "Exportar presupuesto";
        foreach (Control grupo in pie.Controls)
        {
            foreach (Button boton in grupo.Controls.OfType<Button>())
                boton.Enabled = !ocupado && boton.Text is "Guardar" or "Abrir proyecto" or "Federar metrados";
        }
        AplicarPermisosModeladoresBim();
    }

    private bool HerramientaEditorDisponible(Button boton)
    {
        if (vinculoNube == null || PuedeModificarProyecto)
            return HerramientaProyectoDisponible(boton.Tag is not false, ocupado, sesion.Autorizado);
        if (ocupado) return false;
        return boton.Tag is false || boton.Name is "imprimir_proyecto_button" or "exportar_proyecto_button"
            or "resumen_costos_button" or "especificaciones_button"
            or "cronograma_imprimir_button" or "cronograma_exportar_button";
    }

    internal MYGProyectoDocumento DocumentoParaPublicar()
    {
        if (ocupado) throw new InvalidOperationException("Espere a que termine la operación actual.");
        Sincronizar();
        if (!Guardar(false)) throw new OperationCanceledException("Se canceló el guardado del proyecto.");
        return MYGProyectoStorage.Copia(documento);
    }

    internal async Task<MYGProyectoDocumento> DocumentoParaPublicarSqliteAsync()
    {
        if (ocupado || actualizandoNube) throw new InvalidOperationException("Espere a que termine la operación actual.");
        actualizandoNube = true;
        try
        {
            return await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Preparando la obra para publicar…", async progreso =>
            {
                panelCronograma?.GuardarTiempoTrabajoPendiente(); Sincronizar();
                ocupado = true; EstadoSesion();
                progreso.Report("Preparando la copia de la obra…");
                return await Task.Run(() => MYGProyectoStorage.Copia(documento));
            });
        }
        finally { ocupado = false; actualizandoNube = false; EstadoSesion(); }
    }

    internal async Task ActualizarNubeAsync(bool soloLeer)
    {
        ExigirObraPresenteEnBase();
        if (ocupado || actualizandoNube) return;
        actualizandoNube = true;
        try
        {
            await MYGCargaAnimada.EjecutarConProgresoAsync(this,
                soloLeer ? "Preparando recarga de nube…" : "Preparando sincronización de nube…", async progreso =>
            {
                bool guardadoLocalConfirmado = false;
                bool otrasObrasActualizadas = false;
                try
                {
                    progreso.Report("Confirmando la edición del proyecto…");
                    // Los controles se confirman en UI; la copia, SQLite y la red
                    // trabajan fuera de ella mientras el diálogo sigue animado.
                    panelCronograma?.GuardarTiempoTrabajoPendiente();
                    Sincronizar();
                    if (prepararSincronizacionBase != null)
                    {
                        progreso.Report("Conservando las ediciones de las otras obras de la base…");
                        await prepararSincronizacionBase(this);
                    }
                    // Confirmar el borrador con sus permisos habituales antes de
                    // bloquear la edición; el diálogo ya impide nuevas entradas.
                    ocupado = true;
                    UseWaitCursor = true; EstadoSesion(); ActualizarEstadoNube();
                    string ruta = archivo;
                    MYGProyectoDocumento origen = documento;
                    string firmaAnterior = firmaGuardada;
                    ClienteSupabase actual = obtenerClienteNube?.Invoke()
                        ?? throw new NubeException("Inicie sesión de nube para actualizar este proyecto.", necesitaIniciarSesion: true);
                    var guardado = await Task.Run(async () =>
                    {
                        progreso.Report("Comprobando el vínculo y la sesión de nube…");
                        var nativo = CopiaSqliteNube.LeerVinculo(ruta, origen.Id);
                        var vinculo = !string.IsNullOrWhiteSpace(ruta) && File.Exists(ruta)
                            ? nativo ?? MYGColaboracionLocal.Leer(ruta, origen.Id) : null;
                        if (vinculo == null) throw new InvalidOperationException("El proyecto no está vinculado a la nube.");
                        SincronizadorProyectoNube.ValidarIdentidad(actual, vinculo);
                        if (nativo == null && !soloLeer
                            && (await actual.ResolverCentralAsync(vinculo.ProyectoId))?.EsCentralNativa != true)
                            throw new InvalidOperationException("Este proyecto usa el formato anterior. Guarde una copia local y publíquela desde Crear / publicar para usar SQLite sin comprimir. Recargar sigue disponible; no se enviará otro paquete JSON o GZip.");
                        if (!MYGBaseDatos.EsRutaSQLite(ruta))
                            throw new InvalidOperationException("Guarde el proyecto en un archivo con extensión .sqlite.");
                        progreso.Report("Guardando la copia de trabajo local…");
                        string firmaActual = MYGProyectoStorage.Firma(origen);
                        bool escribir = nativo == null || firmaActual != firmaAnterior;
                        var copia = escribir ? MYGProyectoStorage.Copia(origen) : origen;
                        if (escribir)
                        {
                            MYGProyectoStorage.Guardar(ruta, copia);
                            if (nativo != null) CopiaSqliteNube.MarcarCambio(ruta, copia.Id);
                        }
                        string firma = escribir ? MYGProyectoStorage.Firma(copia) : firmaActual;
                        if (escribir) MYGIndiceLocal.Registrar(copia, ruta);
                        return (Documento: copia, Firma: firma, Vinculo: LeerVinculoTrabajoNube(ruta, copia.Id), Nativo: nativo != null, Escrito: escribir);
                    });
                    // Mantener los controles ligados al documento actual hasta
                    // poder aplicar el resultado y refrescarlos juntos. Si falla
                    // la red, ninguna fila queda ligada a una copia descartada.
                    firmaGuardada = guardado.Firma; vinculoNube = guardado.Vinculo;
                    guardadoLocalConfirmado = true;
                    if (guardado.Escrito) ProyectoGuardado?.Invoke(ruta);
                    MYGProyectoDocumento anterior = guardado.Documento;
                    bool consultar = soloLeer || vinculoNube.EstadoConexion == "acceso retirado";
                    var actualizado = await Task.Run(async () =>
                    {
                        var resultado = guardado.Nativo
                            ? await CopiaSqliteNube.EjecutarAsync(actual, ruta, anterior, consultar, progreso: progreso)
                            : await SincronizadorProyectoNube.EjecutarAsync(actual, ruta, anterior, consultar, progreso: progreso);
                        progreso.Report("Preparando el proyecto actualizado para mostrarlo…");
                        return (Resultado: resultado, Firma: ReferenceEquals(resultado.Documento, anterior)
                            ? guardado.Firma : MYGProyectoStorage.Firma(resultado.Documento));
                    });
                    documento = actualizado.Resultado.Documento; vinculoNube = actualizado.Resultado.Vinculo;
                    if (!ReferenceEquals(anterior, documento)) { undo.Clear(); redo.Clear(); }
                    firmaGuardada = actualizado.Firma;
                    progreso.Report("Actualizando la pantalla del proyecto…");
                    if (!ReferenceEquals(origen, documento)) Refrescar();
                    // Una obra vecina puede desaparecer de la revisión remota o
                    // rechazar su recarga. El editor que ya recibió el resultado
                    // debe quedar ligado al documento y la firma nuevos incluso
                    // cuando esa notificación posterior propaga un error.
                    ActualizarIndicadorArchivo(false);
                    if (actualizarEditoresBase != null)
                        await actualizarEditoresBase(this, !ReferenceEquals(anterior, documento));
                    otrasObrasActualizadas = true;
                    estado.Text = "Nube: " + vinculoNube.Estado + ".";
                    return true;
                }
                finally
                {
                    // Incluye los permisos y pendientes conservados si falló la red.
                    string ruta = archivo, id = documento.Id;
                    vinculoNube = await Task.Run(() => !string.IsNullOrWhiteSpace(ruta) && File.Exists(ruta)
                        ? LeerVinculoTrabajoNube(ruta, id) : null);
                    // Registrar una revocación mientras sigue bloqueada la
                    // operación: la edición ya se conservó antes de la consulta.
                    ActualizarEstadoNube();
                    if (guardadoLocalConfirmado) ActualizarIndicadorArchivo(false);
                    else ActualizarIndicadorArchivo();
                    if (guardadoLocalConfirmado && !otrasObrasActualizadas && actualizarEditoresBase != null)
                        await actualizarEditoresBase(this, false);
                }
            });
        }
        finally
        {
            ocupado = false; actualizandoNube = false; UseWaitCursor = false;
            ActualizarEstadoNube(); EstadoSesion();
        }
    }

    private bool GuardarCopiaLocalNube()
    {
        Sincronizar();
        bool nativo = CopiaSqliteNube.LeerVinculo(archivo, documento.Id) != null;
        using var elegir = new SaveFileDialog
        {
            Title = "Guardar copia local independiente", Filter = nativo ? "Base SQLite (*.sqlite)|*.sqlite" : "Base SQLite (*.sqlite)|*.sqlite|Paquete ZIP (*.zip)|*.zip",
            DefaultExt = "sqlite", AddExtension = true,
            FileName = Path.GetFileNameWithoutExtension(archivo) + "_COPIA_LOCAL.sqlite"
        };
        if (elegir.ShowDialog(this) != DialogResult.OK) return false;
        if (File.Exists(elegir.FileName)) throw new IOException("Elija un archivo nuevo para guardar la copia local independiente.");
        if (string.Equals(Path.GetFullPath(elegir.FileName), Path.GetFullPath(archivo), StringComparison.OrdinalIgnoreCase))
            throw new IOException("La copia local necesita un archivo distinto de la copia de nube.");
        if (nativo)
        {
            MYGCargaAnimada.EjecutarConProgreso(this, "Guardando una copia SQLite independiente…", async progreso =>
            {
                var copia = MYGProyectoStorage.Copia(documento);
                await Task.Run(() =>
                {
                    CopiaSqliteNube.CrearSnapshot(archivo, elegir.FileName);
                    MYGProyectoStorage.Guardar(elegir.FileName, copia);
                    ArchivoPublicacionSqlitePendiente.NormalizarCopiaPortable(elegir.FileName, archivo);
                });
                return true;
            });
            estado.Text = "Copia SQLite independiente guardada.";
            return true;
        }
        string alcance = "obra";
        if (!string.IsNullOrWhiteSpace(vinculoNube?.JsonPaqueteConfirmado))
        {
            using var confirmado = JsonDocument.Parse(vinculoNube.JsonPaqueteConfirmado, new JsonDocumentOptions { MaxDepth = 128 });
            if (confirmado.RootElement.TryGetProperty("alcance", out var a) && a.GetString() == "base") alcance = "base";
        }
        JsonElement paquete = PaqueteNube.CrearContenido(MYGProyectoStorage.Copia(documento), archivo, alcance);
        PaqueteNube.Descargar(paquete, elegir.FileName, elegir.FilterIndex == 2);
        estado.Text = "Copia local independiente guardada: " + Path.GetFileName(elegir.FileName);
        return true;
    }

    private async Task ResolverConflictoNubeAsync()
    {
        if (ocupado || actualizandoNube) return;
        Sincronizar(); RecargarVinculoNube();
        if (string.IsNullOrWhiteSpace(vinculoNube?.JsonRemotoConflicto)) return;
        using var elegir = new Form();
        MYGProyectoUI.Preparar(elegir, "Resolver conflicto de nube", 670, 260);
        var detalle = new Label { Dock = DockStyle.Fill, Padding = new(18), Text =
            "La nube tiene la revisión " + vinculoNube.RevisionRemotaConflicto + " y esta copia conserva sus cambios locales.\n\n"
            + "Mantener local crea una operación nueva sobre la revisión remota; podrá enviarla al sincronizar. "
            + "Usar remoto reemplaza el documento local y descarta el borrador pendiente." };
        var local = MYGProyectoUI.Boton("Mantener local", 1); local.AutoSize = true;
        var remoto = MYGProyectoUI.Boton("Usar remoto"); remoto.AutoSize = true;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        bool conflictoBim = CopiaSqliteNube.TieneConflictoBim(archivo, documento.Id);
        local.Enabled = PuedeModificarProyecto && !conflictoBim;
        if (conflictoBim) detalle.Text = "Otra persona confirmó cambios BIM sobre esta revisión. Guarde una copia local si desea consultar su borrador. Usar remoto conserva un respaldo del archivo actual y permite recargar los filtros confirmados; reaplique después los cambios que quiera conservar.";
        local.Click += (_, _) => elegir.DialogResult = DialogResult.Yes;
        remoto.Click += (_, _) => elegir.DialogResult = DialogResult.No;
        var opciones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48,
            FlowDirection = FlowDirection.RightToLeft, Padding = new(8), WrapContents = false };
        opciones.Controls.AddRange(new Control[] { cancelar, remoto, local });
        elegir.Controls.Add(detalle); elegir.Controls.Add(opciones);
        DialogResult opcion = elegir.ShowDialog(this);
        if (CopiaSqliteNube.LeerVinculo(archivo, documento.Id) != null)
        {
            if (opcion is not (DialogResult.Yes or DialogResult.No)) return;
            if (opcion == DialogResult.No && MessageBox.Show(this,
                "¿Usar la base remota completa, incluidas todas sus obras? Se conservará una copia de respaldo local con las ediciones guardadas.",
                "Resolver conflicto", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Preparando la resolución de la base SQLite…", async progreso =>
            {
                await GuardarEdicionBaseNubeAsync();
                if (prepararSincronizacionBase != null) await prepararSincronizacionBase(this);
                ocupado = true; actualizandoNube = true;
                try
                {
                    if (opcion == DialogResult.Yes)
                    {
                        ExigirPermisoEdicionProyecto();
                        await Task.Run(() => CopiaSqliteNube.ResolverMantenerLocal(archivo, documento.Id));
                    }
                    else
                    {
                        var cliente = obtenerClienteNube?.Invoke() ?? throw new InvalidOperationException("Inicie sesión de nube.");
                        var resultado = await Task.Run(() => CopiaSqliteNube.ResolverUsarRemotoAsync(cliente, archivo, documento, progreso: progreso));
                        documento = resultado.Documento; vinculoNube = resultado.Vinculo;
                        undo.Clear(); redo.Clear();
                    }
                    firmaGuardada = await Task.Run(() => MYGProyectoStorage.Firma(documento));
                    RecargarVinculoNube(); Refrescar(); ActualizarIndicadorArchivo(false);
                    if (actualizarEditoresBase != null) await actualizarEditoresBase(this, opcion == DialogResult.No);
                    return true;
                }
                finally
                {
                    ocupado = false; actualizandoNube = false;
                    ActualizarEstadoNube(); EstadoSesion();
                }
            });
            if (conflictoBim && opcion == DialogResult.No) await ActualizarNubeAsync(true);
            return;
        }
        if (opcion == DialogResult.Yes)
        {
            ExigirPermisoEdicionProyecto();
            MYGColaboracionLocal.ResolverConflictoMantenerLocal(archivo, documento, vinculoNube);
            estado.Text = "Se conserva el documento local con una operación nueva pendiente de sincronizar.";
        }
        else if (opcion == DialogResult.No)
        {
            if (MessageBox.Show(this, "¿Descartar el borrador local pendiente y usar la revisión remota? Puede guardar una copia local antes de continuar.",
                "Resolver conflicto", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            if (string.IsNullOrWhiteSpace(vinculoNube.JsonPaqueteConflicto))
                documento = MYGColaboracionLocal.ResolverConflictoUsarRemoto(archivo, vinculoNube);
            else
            {
                using var paquete = JsonDocument.Parse(vinculoNube.JsonPaqueteConflicto, new JsonDocumentOptions { MaxDepth = 128 });
                if (paquete.RootElement.TryGetProperty("alcance", out var alcance) && alcance.GetString() == "base")
                {
                    var resultado = SincronizadorProyectoNube.IncorporarBaseConfirmada(archivo, documento, vinculoNube,
                        vinculoNube.RevisionRemotaConflicto, paquete.RootElement);
                    documento = resultado.Documento; vinculoNube = resultado.Vinculo;
                }
                else documento = MYGColaboracionLocal.ResolverConflictoUsarRemoto(archivo, vinculoNube,
                    (conexion, transaccion) => PaqueteNube.AplicarDependencias(paquete.RootElement, conexion, transaccion));
            }
            undo.Clear(); redo.Clear(); estado.Text = "La copia usa la revisión remota confirmada.";
        }
        else return;
        firmaGuardada = MYGProyectoStorage.Firma(documento);
        RecargarVinculoNube(); Refrescar(); ActualizarEstadoNube(); EstadoSesion();
    }
}
