#nullable enable
using System;
using System.Collections.Generic;
using System.IO;
using MYG.Colaboracion;
using System.Threading.Tasks;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace MYG_2027;

/// <summary>Publica un archivo SQLite completo, con todas sus obras, sin crear paquetes por obra.</summary>
public sealed class NubePublicarForm : WinForms.Form
{
    private readonly MYGProyectoDocumento? actual;
    private readonly string? rutaActual;
    private readonly bool central;
    private readonly WinForms.ComboBox modo = new() { Name = "modoPublicacionNube", Dock = WinForms.DockStyle.Fill,
        DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly SugerenciaNombrePublicacionNube sugerenciaNombre = new();
    private readonly WinForms.Label etiquetaNombre = new() { Text = "Nombre de la base en la nube", AutoSize = true };
    private readonly WinForms.TextBox nombre = new() { Name = "nombrePublicacionNube", Dock = WinForms.DockStyle.Fill,
        ReadOnly = false, ShortcutsEnabled = true,
        MaxLength = ClienteSupabase.MaxNombreProyectoNube, PlaceholderText = "Nombre de la base en la nube" };
    private readonly WinForms.TextBox ruta = new() { Name = "archivoPublicacionNube", Dock = WinForms.DockStyle.Fill,
        ReadOnly = true, PlaceholderText = "Seleccione una base .sqlite" };
    private readonly WinForms.ListBox proyectos = new() { Name = "obrasIncluidasPublicacionNube", Dock = WinForms.DockStyle.Fill,
        IntegralHeight = false, HorizontalScrollbar = true, SelectionMode = WinForms.SelectionMode.None };
    private readonly WinForms.Label explicacion = new() { Name = "alcancePublicacionNube", Dock = WinForms.DockStyle.Fill };
    private readonly WinForms.CheckBox confirmarBase = new() { Name = "confirmarBaseCompletaNube", Dock = WinForms.DockStyle.Fill,
        Text = "Confirmo publicar una sola base SQLite completa, con todas sus obras y presupuestos.", AutoSize = false };
    private readonly WinForms.Button elegir, publicar;
    private bool ocupado;
    private string? rutaCargada;
    private string? rutaResumenes;
    private List<MYGProyectoResumen> resumenes = new();

    public MYGProyectoDocumento? Documento { get; private set; }
    public string? RutaSQLite { get; private set; }
    public string? DocumentoPrincipalId { get; private set; }
    public string Alcance => "base";
    public string Nombre { get; private set; } = "";
    public bool CrearVacia { get; private set; }

    public NubePublicarForm(MYGProyectoDocumento? actual, string? rutaActual, bool central = false)
    {
        this.actual = actual;
        this.rutaActual = rutaActual;
        this.central = central;
        Name = "publicarProyectoNubeDialogo";
        MYGProyectoUI.Preparar(this, "Publicar base SQLite", 800, 710);
        if (central)
        {
            Text = "Publicar base en Nube MYG";
            confirmarBase.Text = "Confirmo publicar todas las obras y sus presupuestos en una misma base central.";
        }
        MinimumSize = new(740, 680);
        MaximizeBox = false; MinimizeBox = false;
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, Padding = new(24),
            ColumnCount = 2, RowCount = 11 };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 145));
        foreach (int alto in new[] { 35, 40, 26, 38, 26, 40, 26, 90, 72, 48, 54 })
            raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, alto));
        var titulo = new WinForms.Label { Text = "Publicar una base en la nube", Dock = WinForms.DockStyle.Fill,
            Font = new("Segoe UI", 15, Drawing.FontStyle.Bold) };
        raiz.Controls.Add(titulo, 0, 0); raiz.SetColumnSpan(titulo, 2);
        modo.Items.AddRange(new object[] { "Base abierta: publicar todas sus obras", "Crear base vacía",
            "Elegir base SQLite: publicar todas sus obras" });
        raiz.Controls.Add(modo, 0, 1); raiz.SetColumnSpan(modo, 2);
        raiz.Controls.Add(etiquetaNombre, 0, 2);
        nombre.Text = sugerenciaNombre.Actualizar("", true, rutaActual, null);
        raiz.Controls.Add(nombre, 0, 3); raiz.SetColumnSpan(nombre, 2);
        raiz.Controls.Add(new WinForms.Label { Text = "Base de datos de origen", AutoSize = true }, 0, 4);
        raiz.Controls.Add(ruta, 0, 5);
        elegir = MYGProyectoUI.Boton("Elegir .sqlite"); elegir.Name = "elegirArchivoPublicacionNube";
        elegir.Click += async (_, _) => await ElegirArchivoAsync();
        raiz.Controls.Add(elegir, 1, 5);
        raiz.Controls.Add(new WinForms.Label { Text = "Obras incluidas (todas)", AutoSize = true }, 0, 6);
        raiz.Controls.Add(proyectos, 0, 7); raiz.SetColumnSpan(proyectos, 2);
        raiz.Controls.Add(explicacion, 0, 8); raiz.SetColumnSpan(explicacion, 2);
        raiz.Controls.Add(confirmarBase, 0, 9); raiz.SetColumnSpan(confirmarBase, 2);
        var pie = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill,
            FlowDirection = WinForms.FlowDirection.RightToLeft, WrapContents = false };
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        publicar = MYGProyectoUI.Boton("Continuar", 1); publicar.Name = "continuarPublicacionNube";
        publicar.Click += async (_, _) => await AceptarAsync();
        pie.Controls.Add(cancelar); pie.Controls.Add(publicar);
        raiz.Controls.Add(pie, 0, 10); raiz.SetColumnSpan(pie, 2);
        Controls.Add(raiz); AcceptButton = publicar; CancelButton = cancelar;
        modo.SelectedIndexChanged += async (_, _) =>
        {
            confirmarBase.Checked = false;
            ActualizarModo();
            if (Visible && !ocupado) await EjecutarAsync(CargarListaFuenteAsync);
        };
        Shown += async (_, _) => { if (!ocupado) await EjecutarAsync(CargarListaFuenteAsync); };
        FormClosing += (_, e) => { if (ocupado) e.Cancel = true; };
        modo.SelectedIndex = !string.IsNullOrWhiteSpace(rutaActual)
            && File.Exists(rutaActual) ? 0 : 1;
        ActualizarModo();
    }

    private void ActualizarModo()
    {
        elegir.Enabled = !ocupado && modo.SelectedIndex == 2;
        confirmarBase.Enabled = !ocupado;
        proyectos.Enabled = !ocupado;
        if (modo.SelectedIndex == 0)
        {
            ruta.Text = rutaActual ?? "";
            explicacion.Text = "Publicará una sola base SQLite, sin comprimir, con todas sus obras, presupuestos y catálogos. Al abrirla verá las obras del mismo archivo y sus cambios se sincronizarán en esa base. El original se conserva.";
        }
        else if (modo.SelectedIndex == 1)
        {
            ruta.Clear();
            explicacion.Text = "Creará una base SQLite con una obra y un presupuesto inicial. Se publicará como una sola base; podrá abrirla y trabajar con las herramientas habituales de MYG.";
        }
        else
        {
            ruta.Text = rutaCargada ?? "";
            explicacion.Text = "Publicará el archivo SQLite completo como una sola entrada de nube, sin crear copias independientes de las obras ni convertirlo a un paquete JSON. Al abrirlo verá todas sus obras. El original se conserva.";
        }
        if (central)
            explicacion.Text = modo.SelectedIndex == 1
                ? "Creará una base central con una obra y un presupuesto inicial. Podrá agregar más obras y elegir quién colabora en cada una."
                : "Publicará sus obras y catálogos en la misma base central. Usted verá todas sus obras; cada colaborador verá únicamente las que autorice. El archivo de origen se conserva.";
        if (modo.SelectedIndex == 1) proyectos.DataSource = new[] { "Obra inicial · 1 presupuesto" };
        else if (!string.Equals(RutaFuente(), rutaResumenes, StringComparison.OrdinalIgnoreCase))
            proyectos.DataSource = Array.Empty<string>();
        ActualizarNombreSugerido();
    }

    private string? RutaFuente() => modo.SelectedIndex == 0 ? rutaActual
        : modo.SelectedIndex == 2 ? rutaCargada : null;

    private void ActualizarNombreSugerido()
    {
        string propuesta = sugerenciaNombre.Actualizar(nombre.Text, true, RutaFuente(), null);
        if (propuesta == nombre.Text) return;
        nombre.Text = propuesta;
        nombre.SelectAll();
    }

    private async Task ElegirArchivoAsync()
    {
        if (ocupado) return;
        using var archivo = new WinForms.OpenFileDialog
        {
            Title = "Elegir una base MYG o Delphin para publicar",
            Filter = "Base de datos SQLite (*.sqlite)|*.sqlite", CheckFileExists = true, Multiselect = false
        };
        if (archivo.ShowDialog(this) != WinForms.DialogResult.OK) return;
        await EjecutarAsync(async () =>
        {
            rutaCargada = Path.GetFullPath(archivo.FileName); ruta.Text = rutaCargada;
            await CargarListaFuenteAsync();
            ActualizarNombreSugerido();
            confirmarBase.Checked = false;
        });
    }

    private async Task CargarListaFuenteAsync()
    {
        string? fuente = RutaFuente();
        if (fuente is null) return;
        if (!File.Exists(fuente)) throw new FileNotFoundException("Elija una base SQLite existente.", fuente);
        var lista = await Task.Run(() => MYGBaseDatos.ListarProyectos(fuente));
        if (IsDisposed || Disposing) return;
        if (lista.Count == 0) throw new InvalidOperationException(
            "La base no contiene obras. Cree una base vacía o elija una base que contenga al menos una obra.");
        resumenes = lista; rutaResumenes = fuente;
        proyectos.DataSource = lista.Select(p => p.Nombre + " · " + p.CantidadPresupuestos
            + (p.CantidadPresupuestos == 1 ? " presupuesto" : " presupuestos")).ToArray();
    }

    private async Task AceptarAsync()
    {
        if (ocupado) return;
        await EjecutarAsync(async () =>
        {
            string texto = nombre.Text.Trim();
            if (texto.Length == 0 || texto.Length > ClienteSupabase.MaxNombreProyectoNube || texto.Any(char.IsControl))
                throw new InvalidOperationException($"Introduzca un nombre de base de hasta {ClienteSupabase.MaxNombreProyectoNube} caracteres.");
            if (!confirmarBase.Checked)
                throw new InvalidOperationException("Confirme que desea publicar la base SQLite completa con todas sus obras.");
            if (modo.SelectedIndex == 1)
            {
                Documento = MYGProyectoStorage.Nuevo(texto); RutaSQLite = null;
                DocumentoPrincipalId = Documento.Id;
            }
            else
            {
                if (modo.SelectedIndex is not (0 or 2) || string.IsNullOrWhiteSpace(RutaFuente()))
                    throw new InvalidOperationException("Abra o elija una base SQLite.");
                await CargarListaFuenteAsync();
                Documento = null; RutaSQLite = Path.GetFullPath(RutaFuente()!);
                DocumentoPrincipalId = resumenes.FirstOrDefault(p => p.Id == actual?.Id)?.Id ?? resumenes[0].Id;
            }
            Nombre = texto;
            CrearVacia = modo.SelectedIndex == 1;
            // Se cierra después de liberar el estado ocupado para permitir FormClosing.
        });
        if (Nombre.Length > 0 && DocumentoPrincipalId is not null)
            DialogResult = WinForms.DialogResult.OK;
    }

    private async Task EjecutarAsync(Func<Task> accion)
    {
        ocupado = true; modo.Enabled = nombre.Enabled = publicar.Enabled = false; ActualizarModo();
        try { await accion(); }
        catch (Exception ex) { Documento = null; DocumentoPrincipalId = null; RutaSQLite = null; Nombre = ""; MYGProyectoUI.Error(this, ex); }
        finally
        {
            ocupado = false; modo.Enabled = nombre.Enabled = publicar.Enabled = true; ActualizarModo();
        }
    }
}
