using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Iconos de la cinta de impresión, dibujados al tamaño real del monitor.</summary>
internal static class MYGVistaPreliminarCintaIconos
{
    internal static Bitmap Dibujar(string id, int tamano, bool seleccionado = false)
    {
        id = (id ?? "").ToLowerInvariant();
        if (id is "volver" or "xls_volver")
            return MYGExcelCintaIconos.Dibujar("xls_volver", tamano, seleccionado);
        if (id == "impresion_rapida")
            return MYGEspecificacionesCinta.DibujarIcono("imprimir", tamano, seleccionado);
        if (id is not ("escala" or "buscar" or "binoculares" or "primera" or "anterior" or "siguiente" or "ultima"
            or "puntero" or "mano" or "varias_paginas" or "filigrana" or "email" or "pdf" or "imprimir"
            or "zoom" or "ampliacion" or "pagina_completa" or "retrato" or "apaisado"))
            return MYGEspecificacionesCinta.DibujarIcono(id, tamano, seleccionado);

        int lado = Math.Max(8, tamano);
        var imagen = new Bitmap(lado, lado, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(imagen);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        g.ScaleTransform(lado / 24f, lado / 24f);

        bool contraste = SystemInformation.HighContrast;
        bool oscuro = MYG2027_TemaComercial.Oscuro;
        Color tinta = contraste ? seleccionado ? SystemColors.HighlightText : SystemColors.ControlText
            : oscuro ? MYG2027_TemaComercial.Texto : Color.FromArgb(86, 120, 163);
        Color gris = contraste ? tinta : oscuro ? MYG2027_TemaComercial.Secundario : Color.FromArgb(136, 145, 157);
        Color fondo = contraste ? seleccionado ? SystemColors.Highlight : SystemColors.Control
            : MYG2027_TemaComercial.Superficie;
        Color rosa = contraste ? tinta : oscuro ? Color.FromArgb(255, 146, 165) : Color.FromArgb(210, 76, 111);
        Color verde = contraste ? tinta : oscuro ? Color.FromArgb(129, 213, 154) : Color.FromArgb(88, 164, 75);
        using var linea = new Pen(tinta, 1.25f) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round };
        using var bordeGris = new Pen(gris, 1.1f) { LineJoin = LineJoin.Round };
        using var papel = new SolidBrush(fondo);
        using var azul = new SolidBrush(tinta);
        using var grisRelleno = new SolidBrush(gris);
        using var rosaRelleno = new SolidBrush(rosa);
        using var verdeRelleno = new SolidBrush(verde);

        void Hoja(float x, float y, float ancho, float alto, bool rayas = false)
        {
            g.FillRectangle(papel, x, y, ancho, alto);
            g.DrawRectangle(bordeGris, x, y, ancho, alto);
            if (rayas)
                for (float fila = y + 4; fila < y + alto - 2; fila += 3)
                    g.DrawLine(bordeGris, x + 3, fila, x + ancho - 3, fila);
        }
        void Triangulo(bool derecha, float x, float y, float ancho = 10, float alto = 14)
        {
            g.FillPolygon(grisRelleno, derecha
                ? new[] { new PointF(x, y), new PointF(x + ancho, y + alto / 2), new PointF(x, y + alto) }
                : new[] { new PointF(x + ancho, y), new PointF(x, y + alto / 2), new PointF(x + ancho, y + alto) });
        }
        void Pdf(float x, float y, float ancho, float alto)
        {
            Hoja(x + 3, y, ancho - 3, alto);
            using var detalle = new Pen(rosa, 1);
            g.DrawLine(detalle, x + 5, y + 2, x + ancho - 2, y + 2);
            g.FillRectangle(rosaRelleno, x, y + 4, ancho, 7);
            using var fuente = new Font("Arial", 5.8f, FontStyle.Bold, GraphicsUnit.Pixel);
            using var texto = new SolidBrush(contraste ? fondo : Color.White);
            using var formato = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            g.DrawString("PDF", fuente, texto, new RectangleF(x, y + 4, ancho, 7), formato);
        }

        switch (id)
        {
            case "retrato":
                Hoja(5, 1, 14, 22, true);
                break;
            case "apaisado":
                Hoja(1, 5, 22, 14, true);
                break;
            case "imprimir":
                using (var original = MYGEspecificacionesCinta.DibujarIcono("imprimir", lado, seleccionado))
                    g.DrawImage(original, new RectangleF(0, 0, 24, 24));
                g.FillEllipse(verdeRelleno, 14, 0, 10, 10);
                using (var marca = new Pen(contraste ? fondo : Color.White, 1.4f) { LineJoin = LineJoin.Round })
                    g.DrawLines(marca, new[] { new PointF(16, 5), new PointF(18, 7), new PointF(22, 3) });
                break;
            case "escala":
                Hoja(2, 1, 19, 22);
                using (var guias = new Pen(gris, .8f))
                {
                    g.DrawLine(guias, 7, 2, 7, 22);
                    g.DrawLine(guias, 3, 7, 20, 7);
                }
                using (var flecha = new Pen(tinta, 2) { LineJoin = LineJoin.Round })
                {
                    g.DrawLines(flecha, new[] { new PointF(11, 10), new PointF(18, 17), new PointF(11, 17) });
                    g.DrawLine(flecha, 18, 17, 18, 10);
                }
                break;
            case "buscar":
            case "binoculares":
                using (var cuerpo = new LinearGradientBrush(new RectangleF(3, 3, 18, 17), fondo, gris, 90f))
                {
                    g.FillRectangle(cuerpo, 5, 3, 5, 10); g.FillRectangle(cuerpo, 14, 3, 5, 10);
                    g.FillRectangle(cuerpo, 3, 10, 8, 9); g.FillRectangle(cuerpo, 13, 10, 8, 9);
                }
                g.DrawRectangle(bordeGris, 5, 3, 5, 10); g.DrawRectangle(bordeGris, 14, 3, 5, 10);
                g.DrawLine(linea, 10, 9, 14, 9);
                using (var lente = new SolidBrush(contraste ? fondo : Color.FromArgb(211, 231, 247)))
                {
                    g.FillEllipse(lente, 3, 11, 8, 9); g.FillEllipse(lente, 13, 11, 8, 9);
                }
                g.DrawEllipse(linea, 3, 11, 8, 9); g.DrawEllipse(linea, 13, 11, 8, 9);
                break;
            case "primera":
            case "anterior":
            case "siguiente":
            case "ultima":
                bool derecha = id is "siguiente" or "ultima";
                Triangulo(derecha, derecha ? 5 : 9, 5);
                if (id is "primera" or "ultima")
                    using (var barra = new Pen(gris, 2))
                        g.DrawLine(barra, derecha ? 19 : 5, 5, derecha ? 19 : 5, 19);
                break;
            case "puntero":
                var puntos = new[] { new PointF(5, 2), new PointF(5, 19), new PointF(9, 15),
                    new PointF(13, 22), new PointF(17, 20), new PointF(13, 13), new PointF(20, 13) };
                using (var rellenoPuntero = new SolidBrush(contraste ? tinta : oscuro ? Color.White : Color.FromArgb(33, 39, 47)))
                    g.FillPolygon(rellenoPuntero, puntos);
                using (var contorno = new Pen(contraste ? fondo : oscuro ? Color.FromArgb(33, 39, 47) : Color.White, .9f))
                    g.DrawPolygon(contorno, puntos);
                break;
            case "mano":
                using (var mano = new GraphicsPath())
                {
                    mano.AddLines(new[] { new PointF(6, 13), new PointF(5, 7), new PointF(6, 5), new PointF(8, 6),
                        new PointF(9, 12), new PointF(9, 3), new PointF(10, 2), new PointF(12, 3), new PointF(12, 11),
                        new PointF(13, 4), new PointF(15, 4), new PointF(15, 12), new PointF(17, 6),
                        new PointF(19, 7), new PointF(18, 16), new PointF(15, 22), new PointF(9, 22),
                        new PointF(5, 18), new PointF(2, 12), new PointF(3, 10), new PointF(5, 11) });
                    mano.CloseFigure(); g.FillPath(papel, mano); g.DrawPath(bordeGris, mano);
                }
                break;
            case "varias_paginas":
                Hoja(2, 2, 8, 8); Hoja(13, 2, 8, 8); Hoja(2, 13, 8, 8); Hoja(13, 13, 8, 8);
                using (var destacada = new SolidBrush(contraste ? tinta : Color.FromArgb(224, 229, 236)))
                    g.FillRectangle(destacada, 3, 3, 6, 6);
                break;
            case "filigrana":
                Hoja(5, 1, 15, 22);
                var guardado = g.Save();
                g.SetClip(new RectangleF(7, 3, 11, 18));
                using (var diagonal = new Pen(gris, 1))
                    for (int desplazamiento = -16; desplazamiento < 25; desplazamiento += 4)
                        g.DrawLine(diagonal, 7, 3 + desplazamiento, 18, 14 + desplazamiento);
                g.Restore(guardado);
                break;
            case "email":
                Pdf(2, 1, 17, 20);
                g.FillRectangle(papel, 8, 13, 15, 9); g.DrawRectangle(linea, 8, 13, 15, 9);
                g.DrawLines(linea, new[] { new PointF(8, 13), new PointF(15.5f, 18), new PointF(23, 13) });
                break;
            case "pdf":
                Pdf(2, 1, 20, 22);
                break;
            case "zoom":
            case "ampliacion":
                using (var lente = new SolidBrush(contraste ? fondo : Color.FromArgb(226, 237, 248)))
                    g.FillEllipse(lente, 2, 2, 14, 14);
                g.DrawEllipse(linea, 2, 2, 14, 14);
                using (var mango = new Pen(tinta, 3) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawLine(mango, 14, 14, 22, 22);
                break;
            case "pagina_completa":
                Hoja(6, 2, 12, 20);
                g.DrawLine(linea, 2, 5, 2, 19); g.DrawLine(linea, 22, 5, 22, 19);
                g.DrawLines(linea, new[] { new PointF(0, 7), new PointF(2, 4), new PointF(4, 7) });
                g.DrawLines(linea, new[] { new PointF(20, 17), new PointF(22, 20), new PointF(24, 17) });
                break;
        }
        return imagen;
    }
}
