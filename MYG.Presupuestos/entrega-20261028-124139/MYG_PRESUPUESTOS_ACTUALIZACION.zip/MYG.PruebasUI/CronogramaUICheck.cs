using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class CronogramaUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        CronogramaMenusUICheck.Ejecutar(exige);
        VerificarIconosModo(exige);
        VerificarPanel(exige);
        VerificarNavegacionSinLicencia(exige);
        VerificarLimitesProyecto(exige);
        VerificarAlertasPeriodo(exige);
        VerificarVinculosContextuales(exige);
    }

    private static void VerificarVinculosContextuales(Action<bool, string> exige)
    {
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 11, 2), FechaEstado = new DateTime(2026, 11, 2) };
        for (int i = 0; i < 100; i++)
            plan.Tareas.Add(new MYGTareaCronograma { Id = "GANTT-RED-" + i, Nombre = "Frente " + i, DuracionDias = 2 });
        var primera = plan.Tareas[0]; var independiente = plan.Tareas[1];
        var elegida = plan.Tareas[50]; var ajena = plan.Tareas[51]; var ultima = plan.Tareas[99];
        elegida.Predecesoras.Add(new() { PredecesoraId = primera.Id, Tipo = MYGTipoVinculo.FC });
        ultima.Predecesoras.Add(new() { PredecesoraId = elegida.Id, Tipo = MYGTipoVinculo.CC, DesfaseDias = 2 });
        ajena.Predecesoras.Add(new() { PredecesoraId = independiente.Id, Tipo = MYGTipoVinculo.FF });
        var resultado = MYGMotorCronograma.Calcular(plan);
        string huella = Huella(plan);
        using var gantt = new MYGCronogramaGanttControl();
        using var ventana = new Form { ClientSize = new Size(850, 280) };
        ventana.Controls.Add(gantt); ventana.Controls.Add(gantt.Cabecera); ventana.Show();
        gantt.Cargar(resultado.Filas, plan.Calendario, plan.FechaEstado);
        exige(gantt.ModoVinculos == MYGModoVinculosGantt.Seleccionadas &&
            !gantt.EnumerarVinculosParaDibujar(48, 55).Any() &&
            gantt.TextoModoVinculos.Contains("seleccionadas") && gantt.AccessibleDescription.Contains("seleccionadas"),
            "El Gantt debe iniciar con el filtro explícito de vínculos de seleccionadas y evitar mostrar la red completa cuando no hay selección.");
        gantt.Seleccionar(new[] { elegida.Id });
        var contextuales = gantt.EnumerarVinculosParaDibujar(48, 55).ToArray();
        exige(contextuales.Length == 2 && contextuales.Any(v =>
                v.Vinculo.PredecesoraId == primera.Id && resultado.Filas[v.Destino].Tarea.Id == elegida.Id) &&
            contextuales.Any(v => v.Vinculo.PredecesoraId == elegida.Id && resultado.Filas[v.Destino].Tarea.Id == ultima.Id),
            "Seleccionar una actividad debe mostrar su predecesora situada fuera de pantalla y su sucesora fuera de pantalla, sin las dependencias de otros frentes.");
        exige(gantt.EnumerarVinculosParaDibujar(90, 100).Single().Vinculo.PredecesoraId == elegida.Id,
            "Al desplazarse hasta una sucesora visible debe conservarse la conexión con la tarea seleccionada aunque su barra haya salido de pantalla.");
        gantt.Seleccionar(new[] { primera.Id, elegida.Id, ultima.Id });
        exige(gantt.EnumerarVinculosParaDibujar(48, 55).Count() == 2,
            "Seleccionar ambos extremos no debe duplicar las conexiones compartidas.");
        gantt.Seleccionar(new[] { elegida.Id });
        gantt.ConfigurarPresentacion(new MYGOpcionesVistaCronograma { ColorDependenciasCriticasArgb = Color.Magenta.ToArgb() }, null);
        gantt.DefinirCriticas(resultado.Filas.Select(f => f.Tarea.Id).ToHashSet()); gantt.MostrarCritica = true;
        gantt.PixelesPorDia = 24; gantt.MostrarFila(48);
        using (var imagen = Capturar())
            exige(PixelesVinculos(imagen) > 10,
                "La pintura real debe incluir los vínculos entrantes y salientes de la selección y recortar sus tramos que quedan fuera del cuerpo visible.");

        var menu = gantt.ContextMenuStrip;
        var todas = menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == "cronograma_gantt_vinculos_todos");
        var ocultar = menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == "cronograma_gantt_vinculos_ocultar");
        var seleccionadas = menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == "cronograma_gantt_vinculos_seleccionadas");
        todas.PerformClick();
        exige(gantt.ModoVinculos == MYGModoVinculosGantt.Todos && todas.Checked && !ocultar.Checked && !seleccionadas.Checked &&
            gantt.TextoModoVinculos.Contains("todos") && gantt.EnumerarVinculosParaDibujar(48, 55).Count() == 3,
            "La opción real Todos debe restaurar los vínculos de otros frentes y reflejar el modo activo sin escribir en el cronograma.");
        ocultar.PerformClick();
        using (var imagen = Capturar())
            exige(gantt.ModoVinculos == MYGModoVinculosGantt.Ocultar && ocultar.Checked && !todas.Checked &&
                gantt.TextoModoVinculos.Contains("ocultos") && !gantt.EnumerarVinculosParaDibujar(0, 100).Any() && PixelesVinculos(imagen) == 0,
                "Ocultar debe retirar realmente las líneas del dibujo y mantener explícita la opción elegida.");
        seleccionadas.PerformClick();
        gantt.Cargar(resultado.Filas.Reverse().ToArray(), plan.Calendario, plan.FechaEstado);
        var reordenadas = gantt.EnumerarVinculosParaDibujar(0, 100).ToArray();
        exige(reordenadas.Length == 2 && reordenadas.Any(v => v.Vinculo.PredecesoraId == elegida.Id && v.Destino == 0) &&
            seleccionadas.Checked && gantt.ModoVinculos == MYGModoVinculosGantt.Seleccionadas,
            "Recargar filas reordenadas debe reconstruir el índice visual por identidades y conservar el modo de presentación.");
        gantt.Cargar(Array.Empty<MYGResultadoTarea>(), plan.Calendario, plan.FechaEstado);
        exige(!gantt.EnumerarVinculosParaDibujar(0, 100).Any() && Huella(plan) == huella &&
            ultima.Predecesoras.Single().DesfaseDias == 2 && ajena.Predecesoras.Single().Tipo == MYGTipoVinculo.FF,
            "Vaciar o filtrar la vista debe retirar índices obsoletos sin eliminar ni cambiar predecesoras, desfases, fechas o calendario del modelo.");
        ventana.Close();

        Bitmap Capturar()
        {
            Application.DoEvents(); gantt.Invalidate(); gantt.Update();
            var imagen = new Bitmap(gantt.ClientSize.Width, gantt.ClientSize.Height);
            gantt.DrawToBitmap(imagen, new Rectangle(Point.Empty, imagen.Size)); return imagen;
        }
        static int PixelesVinculos(Bitmap imagen)
        {
            int cantidad = 0;
            for (int y = 0; y < imagen.Height; y++)
                for (int x = 0; x < imagen.Width; x++)
                {
                    Color color = imagen.GetPixel(x, y);
                    if (color.R > 210 && color.G < 70 && color.B > 210) cantidad++;
                }
            return cantidad;
        }
    }

    private static void VerificarIconosModo(Action<bool, string> exige)
    {
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        int textoOriginal = MYGTamanoTextoUI.Porcentaje;
        var proyecto = Proyecto();
        string presupuestoOriginal = MYGProyectoStorage.Firma(proyecto);
        var plan = Plan();
        plan.Tareas.RemoveRange(3, plan.Tareas.Count - 3);
        string resumenId = plan.Tareas[0].Id, autoId = plan.Tareas[1].Id, manualId = plan.Tareas[2].Id;
        plan.Tareas[2].Modo = MYGModoTarea.Manual;
        plan.Tareas[2].InicioManual = plan.FechaInicio;
        int aplicaciones = 0;
        bool autorizado = true;
        try
        {
            MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
            using var manual = MYGIconosModoTarea.Crear(MYGModoTarea.Manual);
            using var automatico = MYGIconosModoTarea.Crear(MYGModoTarea.Automatica);
            exige(manual.Size == new Size(32, 32) && automatico.Size == manual.Size && !Iguales(manual, automatico),
                "Manual y automática deben tener iconos diferentes, de igual tamaño y propios de cada modo.");
            exige(Cantidad(manual, c => c.A < 20) > 30 && Cantidad(automatico, c => c.A < 20) > 30,
                "Los iconos de programación deben conservar fondo transparente para ambas paletas.");
            exige(Cantidad(manual, c => c.A > 128 && c.G > c.R + 25 && c.B > c.R + 25 && Math.Abs(c.G - c.B) < 55) > 8,
                "El modo manual debe conservar la chincheta turquesa y no mostrar el antiguo icono de documento.");
            exige(Cantidad(automatico, c => c.A > 128 && c.B > c.G + 12 && c.B > c.R + 30) > 8,
                "El modo automático debe mostrar la barra azul con flecha, no una hoja genérica.");

            using var panel = new MYGPanelCronograma(() => plan, nuevo => { plan = nuevo; aplicaciones++; },
                () => autorizado, () => { }, () => { }, () => { }, () => proyecto);
            using var formulario = new Form { ClientSize = new Size(1300, 600) };
            var cinta = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 76, AutoScroll = true, WrapContents = false };
            cinta.Controls.AddRange(panel.BotonesCinta.Cast<Control>().ToArray());
            formulario.Controls.Add(panel); formulario.Controls.Add(cinta);
            formulario.Show(); panel.Refrescar(); Application.DoEvents();
            var tabla = Control<DataGridView>(panel, "cronograma_tareas");
            var columna = tabla.Columns["MODO"] as DataGridViewComboBoxColumn;
            exige(columna?.CellTemplate is MYGCeldaModoCronograma &&
                columna.Items.Cast<string>().SequenceEqual(new[] { "Automática", "Manual" }),
                "Modo debe conservar sus dos valores editables y utilizar la celda que dibuja solo el icono.");
            var botonManual = panel.BotonesCinta.Single(b => b.Name == "cronograma_programar_manual");
            var botonAuto = panel.BotonesCinta.Single(b => b.Name == "cronograma_programar_automatico");
            using (var imagenManual = new Bitmap(botonManual.Image))
            using (var imagenAuto = new Bitmap(botonAuto.Image))
                exige(Iguales(imagenManual, manual) && Iguales(imagenAuto, automatico),
                    "Los botones superiores deben usar exactamente los mismos dibujos de manual y automática que la columna Modo.");
            var imagenManualOriginal = botonManual.Image;
            var imagenAutoOriginal = botonAuto.Image;

            foreach (int porcentaje in new[] { 85, 100, 115, 85, 100 })
                foreach (bool oscuro in new[] { false, true, false })
                {
                    string huella = Huella(plan);
                    int antes = aplicaciones;
                    MYGTamanoTextoUI.Cambiar(porcentaje, guardarPreferencia: false);
                    if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                    panel.AplicarTema(); Application.DoEvents();
                    foreach (string id in new[] { autoId, manualId })
                    {
                        var celda = Celda(id);
                        string valor = id == autoId ? "Automática" : "Manual";
                        exige(Convert.ToString(celda.Value) == valor && celda.AccessibilityObject.Value == valor &&
                            celda.ToolTipText.Contains(valor, StringComparison.OrdinalIgnoreCase),
                            "La celda debe conservar su modo textual para lectores de pantalla y ayuda aunque visualmente muestre solo el icono.");
                        using var normal = new Font("Segoe UI", 9);
                        using var grande = new Font("Segoe UI", 24);
                        using var imagenNormal = PintarCelda(celda, normal);
                        using var imagenGrande = PintarCelda(celda, grande);
                        exige(Iguales(imagenNormal, imagenGrande),
                            "Cambiar la fuente del estilo no debe dibujar las palabras Automática o Manual en la columna de iconos.");
                    }
                    exige(ReferenceEquals(botonManual.Image, imagenManualOriginal) && ReferenceEquals(botonAuto.Image, imagenAutoOriginal)
                        && Huella(plan) == huella && aplicaciones == antes,
                        "Alternar paleta y tamaño debe conservar iconos, valores y planificación sin crear historial.");
                }

            int antesEditar = aplicaciones;
            string antesCancelar = Huella(plan);
            var editor = AbrirEditor(autoId);
            foreach (bool oscuro in new[] { true, false })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                Application.DoEvents();
                exige(tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.EditingControl, editor)
                    && editor.DrawMode == DrawMode.OwnerDrawFixed && aplicaciones == antesEditar && Huella(plan) == antesCancelar,
                    "Cambiar de tema durante la selección de modo debe conservar el editor de iconos y la edición sin confirmar.");
            }
            editor.SelectedItem = "Manual";
            exige(aplicaciones == antesEditar && Huella(plan) == antesCancelar,
                "Elegir otro icono en el editor no debe modificar el plan antes de confirmar la celda.");
            tabla.CancelEdit(); panel.Refrescar(); Application.DoEvents();
            exige(aplicaciones == antesEditar && Huella(plan) == antesCancelar,
                "Cancelar la selección de un modo debe conservar la programación y no registrar un cambio.");

            CambiarDesdeEditor(autoId, "Manual", MYGModoTarea.Manual);
            CambiarDesdeEditor(autoId, "Automática", MYGModoTarea.Automatica);
            foreach (var paso in new[] { (botonManual, MYGModoTarea.Manual), (botonAuto, MYGModoTarea.Automatica) })
            {
                Seleccionar(autoId);
                int antes = aplicaciones;
                paso.Item1.PerformClick(); Application.DoEvents();
                exige(aplicaciones == antes + 1 && plan.Tareas.Single(t => t.Id == autoId).Modo == paso.Item2,
                    "Los nuevos iconos de la barra deben conservar una sola operación de cambio de modo.");
            }
            tabla.CurrentCell = Celda(resumenId);
            exige(!tabla.BeginEdit(false), "Los iconos de Modo no deben permitir editar un resumen calculado.");
            autorizado = false; panel.Refrescar(); Application.DoEvents();
            string antesLectura = Huella(plan);
            int aplicacionesLectura = aplicaciones;
            tabla.CurrentCell = Celda(autoId);
            exige(!tabla.BeginEdit(false) && !botonManual.Enabled && !botonAuto.Enabled,
                "La columna con iconos y ambos botones deben conservar los permisos de solo lectura.");
            exige(Huella(plan) == antesLectura && aplicaciones == aplicacionesLectura &&
                MYGProyectoStorage.Firma(proyecto) == presupuestoOriginal,
                "Mostrar o proteger los modos de programación no debe modificar el presupuesto de origen.");
            formulario.Close();

            DataGridViewCell Celda(string id) => tabla.Rows.Cast<DataGridViewRow>()
                .Single(r => ((MYGResultadoTarea)r.Tag).Tarea.Id == id).Cells["MODO"];
            void Seleccionar(string id)
            {
                tabla.ClearSelection(); tabla.CurrentCell = Celda(id); Celda(id).OwningRow.Selected = true;
                tabla.Focus(); Application.DoEvents();
            }
            MYGEditorModoCronograma AbrirEditor(string id)
            {
                Seleccionar(id);
                exige(tabla.BeginEdit(false) && tabla.EditingControl is MYGEditorModoCronograma,
                    "La columna Modo debe abrir su editor real con los iconos de programación.");
                var actual = (MYGEditorModoCronograma)tabla.EditingControl;
                exige(actual.DrawMode == DrawMode.OwnerDrawFixed && actual.DropDownStyle == ComboBoxStyle.DropDownList,
                    "El selector debe dibujar sus iconos y limitar la elección a los dos modos válidos.");
                actual.DroppedDown = true; Application.DoEvents();
                exige(actual.DropDownWidth > actual.Width,
                    "La lista debe reservar espacio para el icono y el nombre completo aunque la columna sea compacta.");
                actual.DroppedDown = false;
                return actual;
            }
            void CambiarDesdeEditor(string id, string valor, MYGModoTarea esperado)
            {
                int antes = aplicaciones;
                var actual = AbrirEditor(id);
                actual.SelectedItem = valor;
                tabla.NotifyCurrentCellDirty(true);
                exige(tabla.EndEdit(), "La selección válida del icono debe confirmar la celda de programación.");
                panel.FinalizarEdicion(); Application.DoEvents();
                exige(aplicaciones == antes + 1 && plan.Tareas.Single(t => t.Id == id).Modo == esperado &&
                    Convert.ToString(Celda(id).Value) == valor,
                    "Confirmar manual o automática desde el selector debe aplicar una sola copia y refrescar su icono.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
            MYGTamanoTextoUI.Cambiar(textoOriginal, guardarPreferencia: false);
        }

        static int Cantidad(Bitmap imagen, Func<Color, bool> cumple) => Enumerable.Range(0, imagen.Height)
            .Sum(y => Enumerable.Range(0, imagen.Width).Count(x => cumple(imagen.GetPixel(x, y))));
        static bool Iguales(Bitmap a, Bitmap b) => a.Size == b.Size && Enumerable.Range(0, a.Height)
            .All(y => Enumerable.Range(0, a.Width).All(x => a.GetPixel(x, y).ToArgb() == b.GetPixel(x, y).ToArgb()));
        static Bitmap PintarCelda(DataGridViewCell celda, Font fuente)
        {
            var rectangulo = new Rectangle(0, 0, celda.OwningColumn.Width, celda.OwningRow.Height);
            var imagen = new Bitmap(rectangulo.Width, rectangulo.Height);
            try
            {
                using var grafico = Graphics.FromImage(imagen);
                var estilo = celda.InheritedStyle.Clone(); estilo.Font = fuente;
                typeof(MYGCeldaModoCronograma).GetMethod("Paint", Privados).Invoke(celda, new object[]
                {
                    grafico, rectangulo, rectangulo, celda.RowIndex, DataGridViewElementStates.Visible,
                    celda.Value, celda.FormattedValue, "", estilo, celda.DataGridView.AdvancedCellBorderStyle,
                    DataGridViewPaintParts.All
                });
                return imagen;
            }
            catch { imagen.Dispose(); throw; }
        }
    }

    private static void VerificarLimitesProyecto(Action<bool, string> exige)
    {
        if (!OperatingSystem.IsWindows()) return;
        var proyecto = Proyecto();
        DateTime inicioProyecto = new(2026, 10, 27), finProyecto = new(2027, 3, 26);
        proyecto.Datos = new MYGDatosProyecto();
        proyecto.Datos.FechaInicio = inicioProyecto;
        proyecto.Datos.FechaFin = finProyecto;
        var plan = new MYGCronograma
        {
            FechaInicio = new DateTime(2026, 9, 7), FechaEstado = new DateTime(2026, 12, 15)
        };
        plan.Tareas.Add(new MYGTareaCronograma
        {
            Nombre = "Actividad anterior al plazo", Modo = MYGModoTarea.Manual,
            InicioManual = new DateTime(2026, 9, 7), DuracionDias = 3
        });
        plan.Tareas.Add(new MYGTareaCronograma
        {
            Nombre = "Actividad posterior al plazo", Modo = MYGModoTarea.Manual,
            InicioManual = new DateTime(2027, 6, 7), DuracionDias = 3
        });
        string planInicial = Huella(plan), proyectoInicial = JsonSerializer.Serialize(proyecto);
        int cambios = 0;
        using var panel = new MYGPanelCronograma(() => plan, _ => cambios++, () => false,
            () => cambios++, () => cambios++, () => cambios++, () => proyecto);
        using var ventana = new Form { ClientSize = new Size(1600, 760) };
        ventana.Controls.Add(panel);
        ventana.Show();
        panel.Refrescar();
        Application.DoEvents();
        var gantt = Control<MYGCronogramaGanttControl>(panel, "cronograma_gantt");
        var estado = Control<Label>(panel, "cronograma_estado");
        exige(estado.Text.Contains("26/03/2027", StringComparison.Ordinal) &&
            estado.Text.Contains("límites rojos", StringComparison.Ordinal) &&
            estado.Text.Contains("Estado: 15/12/2026", StringComparison.Ordinal),
            "El panel debe distinguir el plazo del proyecto de la fecha de estado en su leyenda.");
        exige(FechaPrivada("origen") <= new DateTime(2026, 9, 7) &&
            FechaPrivada("limite") > new DateTime(2027, 6, 9),
            "Los límites del proyecto no deben recortar las actividades anteriores o posteriores al plazo declarado.");

        foreach (float zoom in new[] { 2f, 8f })
        {
            gantt.PixelesPorDia = zoom;
            VerificarMarcador(inicioProyecto, false, "inicio del proyecto con zoom " + zoom);
            VerificarMarcador(finProyecto, true, "fin inclusivo del proyecto con zoom " + zoom);
        }
        exige(Huella(plan) == planInicial && JsonSerializer.Serialize(proyecto) == proyectoInicial && cambios == 0,
            "Refrescar, desplazar y ampliar los límites debe conservar tareas, metadatos, fecha de estado e historial.");

        DateTime nuevoFin = new(2027, 4, 9);
        proyecto.Datos.FechaFin = nuevoFin;
        string proyectoConNuevoFin = JsonSerializer.Serialize(proyecto);
        panel.Refrescar();
        VerificarMarcador(nuevoFin, true, "fin actualizado tras aceptar los datos del proyecto");
        gantt.IrFecha(finProyecto.AddDays(-8));
        Procesar();
        using (var imagen = Capturar(gantt))
            exige(PixelesRojos(imagen, Coordenada(finProyecto, true), 100, imagen.Height - 15) == 0,
                "Cambiar el fin debe retirar la línea anterior; no debe quedar un límite en 26/03/2027.");
        exige(Huella(plan) == planInicial && JsonSerializer.Serialize(proyecto) == proyectoConNuevoFin && cambios == 0,
            "La actualización visual del fin no debe desplazar tareas ni sustituir la fecha de estado.");

        proyecto.Datos.FechaFin = null;
        panel.Refrescar();
        gantt.IrFecha(nuevoFin.AddDays(-8));
        Procesar();
        using (var imagen = Capturar(gantt))
            exige(PixelesRojos(imagen, Coordenada(nuevoFin, true), 100, imagen.Height - 15) == 0,
                "Quitar la fecha final debe retirar su marcador y conservar únicamente los límites que aún existen.");
        VerificarMarcador(inicioProyecto, false, "inicio cuando la fecha final está vacía");
        proyecto.Datos = null;
        panel.Refrescar();
        gantt.IrFecha(inicioProyecto.AddDays(-8));
        Procesar();
        using (var imagen = Capturar(gantt))
            exige(PixelesRojos(imagen, Coordenada(inicioProyecto, false), 100, imagen.Height - 15) == 0,
                "Un proyecto sin datos generales no debe conservar líneas antiguas ni inventar límites del cronograma.");

        gantt.Cargar(Array.Empty<MYGResultadoTarea>(), plan.Calendario, plan.FechaEstado, inicioProyecto, finProyecto);
        exige(FechaPrivada("origen") < inicioProyecto && FechaPrivada("limite") > finProyecto,
            "Sin actividades, la escala debe seguir incluyendo todo el plazo del proyecto y ambos marcadores.");
        VerificarMarcador(finProyecto, true, "fin del proyecto sin tareas");
        exige(Huella(plan) == planInicial && cambios == 0,
            "La presentación de límites opcionales no debe escribir en el plan ni invocar acciones de edición.");
        ventana.Close();

        DateTime FechaPrivada(string nombre) => (DateTime)typeof(MYGCronogramaGanttControl)
            .GetField(nombre, Privados).GetValue(gantt);
        float Coordenada(DateTime fecha, bool fin) => (float)(fecha.Date - FechaPrivada("origen")).TotalDays *
            gantt.PixelesPorDia + gantt.AutoScrollPosition.X + (fin ? gantt.PixelesPorDia : 0);
        void Procesar()
        {
            Application.DoEvents(); gantt.Invalidate(); gantt.Update();
            gantt.Cabecera.Invalidate(); gantt.Cabecera.Update();
        }
        void VerificarMarcador(DateTime fecha, bool fin, string caso)
        {
            gantt.IrFecha(fecha.AddDays(-8));
            Procesar();
            float x = Coordenada(fecha, fin);
            exige(x > 3 && x < gantt.ClientSize.Width - 3,
                "La comprobación necesita el marcador dentro del área visible: " + caso + ".");
            using var cuerpo = Capturar(gantt);
            using var cabecera = Capturar(gantt.Cabecera);
            exige(PixelesRojos(cuerpo, x, 100, cuerpo.Height - 15) > 15 &&
                PixelesRojos(cabecera, x, cabecera.Height - 8, cabecera.Height - 2) > 0,
                "La línea roja del cuerpo y su marca en la escala deben coincidir con la fecha, el zoom y el scroll: " + caso + ".");
        }
        static Bitmap Capturar(Control control)
        {
            var imagen = new Bitmap(control.ClientSize.Width, control.ClientSize.Height);
            control.DrawToBitmap(imagen, new Rectangle(Point.Empty, imagen.Size));
            return imagen;
        }
        static int PixelesRojos(Bitmap imagen, float posicion, int desde, int hasta)
        {
            int cantidad = 0, centro = (int)Math.Round(posicion);
            Color rojo = Color.FromArgb(210, 55, 58);
            for (int x = Math.Max(0, centro - 2); x <= Math.Min(imagen.Width - 1, centro + 2); x++)
                for (int y = Math.Max(0, desde); y < Math.Min(imagen.Height, hasta); y++)
                {
                    Color actual = imagen.GetPixel(x, y);
                    if (Math.Abs(actual.R - rojo.R) <= 35 && Math.Abs(actual.G - rojo.G) <= 35 && Math.Abs(actual.B - rojo.B) <= 35)
                        cantidad++;
                }
            return cantidad;
        }
    }

    private static void VerificarAlertasPeriodo(Action<bool, string> exige)
    {
        var inicio = new DateTime(2026, 1, 12); var fin = new DateTime(2026, 1, 23);
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 1), FechaEstado = new DateTime(2026, 1, 19) };
        var antes = Agregar("Antes", inicio.AddDays(-7), 2);
        var despues = Agregar("Después al 100%", fin.AddDays(3), 2); despues.Avance = 100;
        var dentro = Agregar("Crítica dentro", inicio.AddDays(1), 2);
        dentro.InicioBase = inicio.AddDays(-10); dentro.FinBase = fin.AddDays(10);
        var igualInicio = Agregar("Inicio inclusivo", inicio, 1);
        var igualFin = Agregar("Fin inclusivo", fin, 1);
        var resumen = Agregar("Resumen fuera", inicio, 1); resumen.EsResumen = true;
        var hijo = Agregar("Hijo fuera", fin.AddDays(3), 2); hijo.PadreId = resumen.Id;
        var hito = Agregar("Hito fuera", fin.AddDays(4), 0);
        var partes = Agregar("Partes fuera", fin.AddDays(3), 4);
        partes.Partes.Add(new MYGParteTarea { DesfaseInicioDias = 0, DuracionDias = 2 });
        partes.Partes.Add(new MYGParteTarea { DesfaseInicioDias = 4, DuracionDias = 2 });
        var resultado = MYGMotorCronograma.Calcular(plan);
        string huella = Huella(plan);
        using var gantt = new MYGCronogramaGanttControl();
        using var ventana = new Form { ClientSize = new Size(1000, 440) };
        ventana.Controls.Add(gantt); ventana.Controls.Add(gantt.Cabecera); ventana.Show();
        gantt.Cargar(resultado.Filas, plan.Calendario, plan.FechaEstado, inicio, fin);
        gantt.PixelesPorDia = 15; gantt.IrFecha(new DateTime(2026, 1, 1));
        gantt.DefinirCriticas(resultado.Filas.Select(f => f.Tarea.Id).ToHashSet());
        var filas = resultado.Filas.ToDictionary(f => f.Tarea.Id);
        string[] fuera = { antes.Id, despues.Id, resumen.Id, hijo.Id, hito.Id, partes.Id };
        exige(fuera.All(id => gantt.FueraDelPeriodo(filas[id])) &&
            new[] { dentro.Id, igualInicio.Id, igualFin.Id }.All(id => !gantt.FueraDelPeriodo(filas[id])),
            "El aviso debe detectar inicio anterior o fin posterior, incluidos resúmenes e hitos, manteniendo válidos ambos límites inclusivos.");
        typeof(MYGResultadoTarea).GetProperty("Fin").SetValue(filas[igualFin.Id], fin.AddHours(23));
        exige(!gantt.FueraDelPeriodo(filas[igualFin.Id]),
            "La hora del mismo día final no debe generar una alerta de fuera del periodo.");
        var naranja = Color.FromArgb(217, 119, 6);
        foreach (bool critica in new[] { false, true })
        {
            gantt.MostrarCritica = critica;
            using var imagen = Capturar();
            exige(fuera.All(id => ColorEnBarra(imagen, id, naranja) > 3),
                "Las barras fuera del plazo deben usar naranja aunque cambie la ruta crítica, incluidos resumen, hito, partes y avance completo.");
            exige(ColorEnBarra(imagen, dentro.Id, critica ? Color.Firebrick : Color.FromArgb(64, 149, 128)) > 3,
                "Una tarea dentro del periodo debe conservar el color de ruta crítica o manual según la vista.");
            RectangleF actual = Barras()[dentro.Id];
            exige(Cerca(imagen.GetPixel((int)(actual.Left + actual.Width / 2), (int)(actual.Bottom + 3)), Color.FromArgb(145, 145, 145)),
                "Una línea base fuera del plazo debe conservar su gris; la alerta corresponde a las fechas actuales de la actividad.");
            RectangleF completa = Barras()[despues.Id];
            Color centro = imagen.GetPixel((int)(completa.Left + completa.Width / 2), (int)(completa.Top + completa.Height / 2));
            exige(Cerca(centro, naranja), "El avance al 100% no debe tapar la alerta con el color habitual de progreso.");
        }
        gantt.ConfigurarPresentacion(new MYGOpcionesVistaCronograma { ColorCriticaArgb = naranja.ToArgb() }, null);
        using (var imagen = Capturar())
            exige(gantt.ColorAlertaPeriodo.ToArgb() != naranja.ToArgb() &&
                ColorEnBarra(imagen, despues.Id, Color.FromArgb(128, 85, 210)) > 3 &&
                ColorEnBarra(imagen, dentro.Id, naranja) > 3,
                "Si la ruta crítica se personaliza en naranja, la alerta debe usar violeta y seguir siendo distinguible.");
        gantt.Cargar(resultado.Filas, plan.Calendario, plan.FechaEstado, inicio, null);
        exige(gantt.FueraDelPeriodo(filas[antes.Id]) && !gantt.FueraDelPeriodo(filas[despues.Id]),
            "Con sólo inicio debe alertarse exclusivamente el desbordamiento anterior.");
        gantt.Cargar(resultado.Filas, plan.Calendario, plan.FechaEstado, null, fin);
        exige(!gantt.FueraDelPeriodo(filas[antes.Id]) && gantt.FueraDelPeriodo(filas[despues.Id]),
            "Con sólo fin debe alertarse exclusivamente el desbordamiento posterior.");
        gantt.Cargar(resultado.Filas, plan.Calendario, plan.FechaEstado);
        exige(resultado.Filas.All(f => !gantt.FueraDelPeriodo(f)) && Huella(plan) == huella,
            "Sin límites no debe inventarse un periodo ni alterar las fechas, avance, línea base o tareas de origen.");
        ventana.Close();

        MYGTareaCronograma Agregar(string nombre, DateTime fecha, int duracion)
        {
            var tarea = new MYGTareaCronograma { Nombre = nombre, Modo = MYGModoTarea.Manual, InicioManual = fecha, DuracionDias = duracion };
            plan.Tareas.Add(tarea); return tarea;
        }
        Dictionary<string, RectangleF> Barras() => (Dictionary<string, RectangleF>)typeof(MYGCronogramaGanttControl)
            .GetField("barras", Privados).GetValue(gantt);
        Bitmap Capturar()
        {
            Application.DoEvents(); gantt.Invalidate(); gantt.Update();
            var imagen = new Bitmap(gantt.ClientSize.Width, gantt.ClientSize.Height);
            gantt.DrawToBitmap(imagen, new Rectangle(Point.Empty, imagen.Size)); return imagen;
        }
        int ColorEnBarra(Bitmap imagen, string id, Color esperado)
        {
            Rectangle area = Rectangle.Intersect(Rectangle.Ceiling(Barras()[id]), new Rectangle(Point.Empty, imagen.Size));
            int cantidad = 0;
            for (int y = area.Top; y < area.Bottom; y++)
                for (int x = area.Left; x < area.Right; x++) if (Cerca(imagen.GetPixel(x, y), esperado)) cantidad++;
            return cantidad;
        }
        static bool Cerca(Color actual, Color esperado) => Math.Abs(actual.R - esperado.R) < 35 &&
            Math.Abs(actual.G - esperado.G) < 35 && Math.Abs(actual.B - esperado.B) < 35;
    }

    private static void VerificarPanel(Action<bool, string> exige)
    {
        var proyecto = Proyecto();
        string firmaPresupuesto = MYGProyectoStorage.Firma(proyecto);
        var plan = Plan();
        var inicial = plan;
        string huellaInicial = Huella(inicial);
        string primeraId = plan.Tareas[1].Id, segundaId = plan.Tareas[2].Id, terceraId = plan.Tareas[3].Id;
        bool puedeEditar = true, copiasIndependientes = true;
        int aplicaciones = 0, guardados = 0, deshechos = 0, rehechos = 0;
        var undo = new Stack<MYGCronograma>();
        var redo = new Stack<MYGCronograma>();
        var instantaneas = new List<(MYGCronograma Plan, string Huella)>();
        MYGPanelCronograma panel = null;
        panel = new MYGPanelCronograma(() => plan, nuevo =>
        {
            copiasIndependientes &= !ReferenceEquals(nuevo, plan) && nuevo.Tareas.All(t =>
                !plan.Tareas.Any(anterior => ReferenceEquals(t, anterior)));
            undo.Push(MYGProyectoStorage.Copia(plan));
            redo.Clear();
            plan = nuevo;
            aplicaciones++;
        }, () => puedeEditar, () => guardados++, () =>
        {
            deshechos++;
            if (undo.Count == 0) return;
            redo.Push(MYGProyectoStorage.Copia(plan));
            plan = undo.Pop();
            panel.Refrescar();
        }, () =>
        {
            rehechos++;
            if (redo.Count == 0) return;
            undo.Push(MYGProyectoStorage.Copia(plan));
            plan = redo.Pop();
            panel.Refrescar();
        }, () => proyecto);
        using (panel)
        using (var formulario = new Form { ClientSize = new Size(1600, 860) })
        {
            var cinta = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 76, WrapContents = false, AutoScroll = true };
            cinta.Controls.AddRange(panel.BotonesCinta.Cast<Control>().ToArray());
            panel.Dock = DockStyle.Fill;
            formulario.Controls.Add(panel);
            formulario.Controls.Add(cinta);
            formulario.Show();
            panel.Refrescar();
            Application.DoEvents();
            var tabla = Control<DataGridView>(panel, "cronograma_tareas");
            var gantt = Control<ScrollableControl>(panel, "cronograma_gantt");
            string[] columnas = { "ID", "MODO", "NOMBRE", "DIASCAL", "DURACION", "INICIO", "FIN", "PREDECESORAS", "AVANCE" };
            exige(panel.Name == "cronograma_panel" && columnas.All(tabla.Columns.Contains) &&
                tabla.Rows.Count == plan.Tareas.Count && tabla.Rows.Cast<DataGridViewRow>().All(f => f.Tag is MYGResultadoTarea),
                "El cronograma debe mostrar su tabla real de tareas y el Gantt con las nueve columnas solicitadas.");
            var resumen = tabla.Rows.Cast<DataGridViewRow>().Single(f => ((MYGResultadoTarea)f.Tag).Tarea.EsResumen);
            exige(resumen.ReadOnly && resumen.InheritedStyle.Font?.Bold == true &&
                tabla.Columns["DIASCAL"].ReadOnly && !tabla.Columns["INICIO"].ReadOnly && !tabla.Columns["FIN"].ReadOnly,
                "Los resúmenes y días calendario deben protegerse, conservando Inicio y Fin editables para las tareas.");
            exige(gantt.Visible && gantt.ClientSize.Width > 100 && gantt.ClientSize.Height > 100 &&
                !string.IsNullOrWhiteSpace(gantt.AccessibleName),
                "El Gantt debe ocupar un área utilizable y tener un nombre accesible.");
            var cabeceraGantt = ((MYGCronogramaGanttControl)gantt).Cabecera;
            exige(cabeceraGantt.Visible && ReferenceEquals(cabeceraGantt.Parent, gantt.Parent) &&
                !gantt.Contains(cabeceraGantt) && cabeceraGantt.Height == tabla.ColumnHeadersHeight &&
                cabeceraGantt.Bottom == gantt.Top,
                "La escala de meses y días debe ocupar una cabecera hermana fija encima del cuerpo desplazable.");

            Cambio(() => Editar(primeraId, "DURACION", "5"), "Editar duración debe aplicar una sola copia validada.");
            exige(Tarea(primeraId).DuracionDias == 5 && Fila(primeraId).Fin == new DateTime(2026, 1, 9),
                "La duración editada debe recalcular el fin inclusivo en días laborables.");
            int numeroPrimera = Fila(primeraId).Numero;
            Cambio(() => Editar(segundaId, "PREDECESORAS", numeroPrimera + "FC-1"),
                "Editar predecesoras debe aplicar una sola transacción y admitir desfases negativos.");
            exige(Tarea(segundaId).Predecesoras.Count == 1 &&
                Tarea(segundaId).Predecesoras[0].PredecesoraId == primeraId &&
                Tarea(segundaId).Predecesoras[0].DesfaseDias == -1 && Fila(segundaId).Inicio == Fila(primeraId).Fin,
                "La tabla debe resolver el número de fila a una identidad estable y programar FC-1 correctamente.");
            Cambio(() => Editar(segundaId, "AVANCE", "45"), "Editar avance debe registrar exactamente una modificación.");
            exige(Tarea(segundaId).Avance == 45m, "El porcentaje escrito en la tabla debe conservarse en el plan.");

            Rechazar(primeraId, "DURACION", "-1", "Una duración negativa debe rechazarse sin aplicar cambios.");
            Rechazar(segundaId, "AVANCE", "101", "Un avance superior a cien debe rechazarse sin aplicar cambios.");
            Rechazar(primeraId, "PREDECESORAS", Fila(segundaId).Numero + "FC",
                "Una dependencia que cierra un ciclo debe rechazarse de forma atómica.");

            Seleccionar(segundaId);
            Cambio(() => Boton("cronograma_programar_manual").PerformClick(),
                "Pasar una tarea a manual debe registrar una sola copia.");
            DateTime inicioManual = Tarea(segundaId).InicioManual.Value;
            exige(Tarea(segundaId).Modo == MYGModoTarea.Manual && Fila(segundaId).Inicio == inicioManual,
                "El modo manual debe fijar el inicio calculado de la tarea seleccionada.");
            Cambio(() => Editar(primeraId, "DURACION", "6"), "Cambiar una predecesora debe seguir siendo una operación atómica.");
            exige(Fila(segundaId).Inicio == inicioManual,
                "Una tarea manual debe conservar su fecha aunque se prolongue su predecesora.");
            Seleccionar(segundaId);
            Cambio(() => Boton("cronograma_programar_automatico").PerformClick(),
                "Volver a automática debe aplicar una única modificación.");
            exige(Tarea(segundaId).Modo == MYGModoTarea.Automatica && Fila(segundaId).Inicio == Fila(primeraId).Fin,
                "Recuperar el modo automático debe volver a respetar las predecesoras.");

            int antesMismoFin = aplicaciones;
            string antesMismoFinHuella = Huella(plan);
            Editar(terceraId, "FIN", "06/01/2026");
            exige(aplicaciones == antesMismoFin && Huella(plan) == antesMismoFinHuella &&
                Tarea(terceraId).Modo == MYGModoTarea.Automatica && Tarea(terceraId).InicioManual == null,
                "Confirmar el mismo fin debe conservar el modo automático sin crear cambios ni historial.");
            Cambio(() => Editar(terceraId, "FIN", "12/01/2026"),
                "Editar el fin debe aplicar una sola copia validada del cronograma.");
            exige(Tarea(terceraId).Modo == MYGModoTarea.Manual &&
                Tarea(terceraId).InicioManual == new DateTime(2026, 1, 5) && Tarea(terceraId).DuracionDias == 6 &&
                Fila(terceraId).Inicio == new DateTime(2026, 1, 5) && Fila(terceraId).Fin == new DateTime(2026, 1, 12),
                "Cambiar Fin debe fijar el inicio actual y contar sólo los seis días laborables inclusivos, omitiendo el fin de semana.");
            Rechazar(terceraId, "FIN", "04/01/2026", "Un fin anterior al inicio debe rechazarse sin aplicar cambios.");
            Rechazar(terceraId, "FIN", "10/01/2026", "Un fin inhábil debe rechazarse sin desplazar la fecha ni modificar la tarea.");

            Seleccionar(segundaId);
            int tareasAntesHito = plan.Tareas.Count;
            Cambio(() => AceptarTarea(() => Boton("cronograma_insertar_hito").PerformClick(), "Entrega comprobada", exige),
                "Insertar un hito desde la herramienta real debe aplicar una sola copia.");
            var hito = plan.Tareas.Single(t => t.Nombre == "Entrega comprobada");
            exige(plan.Tareas.Count == tareasAntesHito + 1 && hito.DuracionDias == 0 &&
                Fila(hito.Id).Inicio == Fila(hito.Id).Fin,
                "La herramienta Insertar hito debe crear una tarea de duración cero con una fecha única.");
            Cambio(() => Editar(hito.Id, "INICIO", "10/01/2026"),
                "Editar Inicio debe fijar la fecha manual de un hito mediante una sola modificación.");
            exige(Tarea(hito.Id).Modo == MYGModoTarea.Manual && Tarea(hito.Id).DuracionDias == 0 &&
                Fila(hito.Id).Inicio == new DateTime(2026, 1, 10) && Fila(hito.Id).Fin == new DateTime(2026, 1, 10),
                "Un hito manual debe conservar exactamente su fecha aunque sea sábado.");
            int antesMismoFinHito = aplicaciones;
            string antesMismoFinHitoHuella = Huella(plan);
            Editar(hito.Id, "FIN", "10/01/2026");
            exige(aplicaciones == antesMismoFinHito && Huella(plan) == antesMismoFinHitoHuella,
                "Confirmar la fecha existente de un hito en día inhábil debe aceptarse sin crear una duración ni un cambio.");

            Cambio(() => Menu("cronograma_linea_base", "cronograma_establecer_base"),
                "Establecer línea base debe guardar una sola instantánea del cronograma.");
            exige(plan.Tareas.All(t => t.InicioBase.HasValue && t.FinBase.HasValue && t.DuracionBase.HasValue) &&
                plan.Tareas.All(t => t.InicioBase == Fila(t.Id).Inicio && t.FinBase == Fila(t.Id).Fin),
                "La línea base debe conservar inicio, fin y duración de todas las tareas y resúmenes.");
            string antesVista = Huella(plan);
            int aplicacionesVista = aplicaciones;
            VerificarRutaCritica();
            VerificarTiempoTrabajo(panel, Boton("cronograma_tiempo_trabajo"), tabla, gantt, exige);
            Boton("cronograma_linea_tiempo").PerformClick();
            Menu("cronograma_linea_base", "cronograma_ver_base");
            Application.DoEvents();
            exige(Huella(plan) == antesVista && aplicaciones == aplicacionesVista,
                "Alternar ruta crítica, tiempo de trabajo, línea de tiempo y visibilidad de línea base debe conservar datos e historial.");
            Cambio(() => Menu("cronograma_linea_base", "cronograma_quitar_base"),
                "Quitar línea base debe aplicar una única modificación.");
            exige(plan.Tareas.All(t => t.InicioBase == null && t.FinBase == null && t.DuracionBase == null),
                "Quitar línea base debe retirar sus tres valores sin alterar la planificación vigente.");

            string antesDeshacer = Huella(plan);
            Cambio(() => Editar(primeraId, "DURACION", "7"), "La edición previa al historial debe guardarse una sola vez.");
            string antesRehacer = Huella(plan);
            int aplicacionesHistorial = aplicaciones;
            Menu("cronograma_otros", "cronograma_deshacer");
            exige(deshechos == 1 && Huella(plan) == antesDeshacer && aplicaciones == aplicacionesHistorial,
                "Deshacer debe invocar su callback y recuperar la planificación anterior sin una edición adicional.");
            Menu("cronograma_otros", "cronograma_rehacer");
            exige(rehechos == 1 && Huella(plan) == antesRehacer && aplicaciones == aplicacionesHistorial,
                "Rehacer debe invocar su callback y restaurar exactamente la planificación editada.");
            Menu("cronograma_otros", "cronograma_guardar");
            exige(guardados == 1 && Huella(plan) == antesRehacer && aplicaciones == aplicacionesHistorial,
                "Guardar desde el cronograma debe ejecutar su callback una sola vez sin modificar el plan.");

            // La selección se comprueba en la posición visual de una fila después
            // de desplazar la tabla, para detectar desfases entre ambas mitades.
            tabla.FirstDisplayedScrollingRowIndex = 20;
            Application.DoEvents();
            var primeraVisible = tabla.GetRowDisplayRectangle(tabla.FirstDisplayedScrollingRowIndex, false);
            exige(gantt.PointToScreen(Point.Empty).Y == tabla.PointToScreen(new Point(0, primeraVisible.Top)).Y,
                "La primera fila debe comenzar en Y=0 del cuerpo del Gantt y alinearse con la tabla bajo ambas cabeceras.");
            string seleccionAntesCabecera = ((MYGResultadoTarea)tabla.CurrentRow.Tag).Tarea.Id;
            Invocar(cabeceraGantt, "OnMouseDown", new MouseEventArgs(MouseButtons.Left, 1, 20, 10, 0));
            Invocar(cabeceraGantt, "OnMouseUp", new MouseEventArgs(MouseButtons.Left, 1, 50, 10, 0));
            exige(((MYGResultadoTarea)tabla.CurrentRow.Tag).Tarea.Id == seleccionAntesCabecera &&
                aplicaciones == aplicacionesHistorial,
                "Pulsar o arrastrar la cabecera fija no debe seleccionar ni reprogramar una tarea.");
            int indice = tabla.FirstDisplayedScrollingRowIndex + 2;
            var filaVisual = tabla.Rows[indice];
            var area = tabla.GetRowDisplayRectangle(indice, false);
            var punto = gantt.PointToClient(tabla.PointToScreen(new Point(4, area.Top + area.Height / 2)));
            exige(area.Height > 0 && punto.Y > 0 && punto.Y < gantt.ClientSize.Height,
                "La fila utilizada para comprobar la sincronización debe estar visible en ambas mitades.");
            var raton = new MouseEventArgs(MouseButtons.Left, 1, Math.Max(2, gantt.ClientSize.Width - 8), punto.Y, 0);
            Invocar(gantt, "OnMouseDown", raton);
            Invocar(gantt, "OnMouseUp", raton);
            Application.DoEvents();
            exige(tabla.CurrentRow?.Tag is MYGResultadoTarea seleccionada &&
                seleccionada.Tarea.Id == ((MYGResultadoTarea)filaVisual.Tag).Tarea.Id &&
                aplicaciones == aplicacionesHistorial,
                "Pulsar una fila del Gantt después de desplazar debe seleccionar la misma tarea de la tabla sin editarla.");
            int altoFila = tabla.Rows[0].Height;
            gantt.AutoScrollPosition = new Point(-gantt.AutoScrollPosition.X, 10 * altoFila);
            int primeraGantt = Math.Max(0, -gantt.AutoScrollPosition.Y / altoFila);
            Invocar(gantt, "OnScroll", new ScrollEventArgs(ScrollEventType.ThumbPosition,
                tabla.FirstDisplayedScrollingRowIndex * altoFila, primeraGantt * altoFila, ScrollOrientation.VerticalScroll));
            Application.DoEvents();
            exige(tabla.FirstDisplayedScrollingRowIndex == primeraGantt && aplicaciones == aplicacionesHistorial,
                "Desplazar verticalmente el Gantt también debe llevar la tabla a la misma primera fila, sin crear historial.");

            var buscar = Control<TextBox>(panel, "cronograma_buscar");
            buscar.Text = "Trabajo 12";
            Application.DoEvents();
            exige(tabla.Rows.Count == 2 && tabla.Rows.Cast<DataGridViewRow>().Any(f =>
                    ((MYGResultadoTarea)f.Tag).Tarea.Nombre == "Trabajo 12") && aplicaciones == aplicacionesHistorial,
                "Buscar una tarea debe conservar su resumen y limitar las filas visibles sin modificar la planificación.");
            buscar.Clear();
            Application.DoEvents();
            exige(tabla.Rows.Count == plan.Tareas.Count,
                "Quitar la búsqueda debe recuperar todas las tareas y el hito recién creado.");

            puedeEditar = false;
            panel.Refrescar();
            Application.DoEvents();
            string antesSoloLectura = Huella(plan);
            Seleccionar(segundaId);
            exige((tabla.ReadOnly || tabla.Rows.Cast<DataGridViewRow>().All(f => f.ReadOnly)) &&
                !Boton("cronograma_insertar_hito").Enabled,
                "Sin permiso de edición, la tabla y la creación de hitos deben quedar protegidas.");
            exige(Boton("cronograma_tiempo_trabajo").Enabled,
                "Tiempo de trabajo debe permitir consultar el calendario en el panel inferior aunque no exista permiso de edición.");
            VerificarTiempoTrabajo(panel, Boton("cronograma_tiempo_trabajo"), tabla, gantt, exige);
            try { Invocar(panel, "CambiarModo", MYGModoTarea.Manual); }
            catch (TargetInvocationException ex) when (ex.InnerException is InvalidOperationException) { }
            panel.Refrescar();
            Application.DoEvents();
            exige(Huella(plan) == antesSoloLectura && aplicaciones == aplicacionesHistorial,
                "Los comandos de edición también deben comprobar el permiso antes de aplicar una copia.");
            exige(copiasIndependientes && Huella(inicial) == huellaInicial &&
                instantaneas.All(i => Huella(i.Plan) == i.Huella) &&
                MYGProyectoStorage.Firma(proyecto) == firmaPresupuesto && proyecto.Cronograma == null,
                "Editar el cronograma debe conservar sus instantáneas anteriores y todo el presupuesto de origen.");
            formulario.Close();

            MYGTareaCronograma Tarea(string id) => plan.Tareas.Single(t => t.Id == id);
            MYGResultadoTarea Fila(string id) => MYGMotorCronograma.Calcular(plan).Filas.Single(f => f.Tarea.Id == id);
            DataGridViewRow FilaTabla(string id) => tabla.Rows.Cast<DataGridViewRow>()
                .Single(f => ((MYGResultadoTarea)f.Tag).Tarea.Id == id);
            Button Boton(string nombre) => panel.BotonesCinta.Single(b => b.Name == nombre);
            void Seleccionar(string id)
            {
                tabla.ClearSelection();
                var fila = FilaTabla(id);
                tabla.CurrentCell = fila.Cells["NOMBRE"];
                fila.Selected = true;
                Application.DoEvents();
            }
            void Editar(string id, string columna, string texto)
            {
                Seleccionar(id);
                tabla.CurrentCell = FilaTabla(id).Cells[columna];
                tabla.Focus();
                exige(tabla.BeginEdit(false) && tabla.EditingControl is TextBox,
                    "La celda del cronograma debe permitir su edición real mediante teclado.");
                ((TextBox)tabla.EditingControl).Text = texto;
                exige(tabla.EndEdit(), "La edición válida debe confirmarse sin bloquear la tabla.");
                panel.FinalizarEdicion();
            }
            void Cambio(Action accion, string mensaje)
            {
                int antes = aplicaciones;
                string huella = Huella(plan);
                instantaneas.Add((plan, huella));
                accion();
                Application.DoEvents();
                exige(aplicaciones == antes + 1 && Huella(plan) != huella, mensaje);
            }
            void Rechazar(string id, string columna, string texto, string mensaje)
            {
                Seleccionar(id);
                var celda = FilaTabla(id).Cells[columna];
                tabla.CurrentCell = celda;
                string huella = Huella(plan);
                int antes = aplicaciones;
                tabla.Focus();
                exige(tabla.BeginEdit(false) && tabla.EditingControl is TextBox,
                    "La prueba de rechazo debe utilizar el editor real de la celda.");
                ((TextBox)tabla.EditingControl).Text = texto;
                bool rechazado = false;
                try { panel.FinalizarEdicion(); }
                catch (InvalidOperationException) { rechazado = true; }
                exige(rechazado && tabla.IsCurrentCellInEditMode && !string.IsNullOrEmpty(celda.OwningRow.ErrorText) &&
                    Huella(plan) == huella && aplicaciones == antes, mensaje);
                tabla.CancelEdit();
                panel.Refrescar();
            }
            void Menu(string boton, string opcion)
            {
                var herramienta = Boton(boton);
                herramienta.PerformClick();
                Application.DoEvents();
                var menu = herramienta.ContextMenuStrip;
                exige(menu != null, "Las herramientas desplegables deben exponer su menú contextual real.");
                var item = menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == opcion);
                exige(item.Enabled, "La acción solicitada del cronograma debe estar habilitada.");
                item.PerformClick();
                menu.Close();
                Application.DoEvents();
            }
            void VerificarRutaCritica()
            {
                string huella = Huella(plan);
                int antes = aplicaciones;
                string seleccion = ActualId();
                var visual = (MYGCronogramaGanttControl)gantt;
                var menu = Boton("cronograma_ruta_critica").ContextMenuStrip;
                var simple = menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == "cronograma_critica_simple");
                var multiple = menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == "cronograma_critica_multiple");
                panel.SeleccionarRutaCritica(MYGModoRutaCritica.Ninguna);
                Estado(false, false, "Quitar el resaltado debe desmarcar ambos modos de ruta crítica.");
                Menu("cronograma_ruta_critica", "cronograma_critica_simple");
                Estado(true, false, "Simple debe activar sólo su opción y mostrar el resaltado de tareas críticas.");
                Menu("cronograma_ruta_critica", "cronograma_critica_simple");
                Estado(false, false, "Volver a elegir Simple debe ocultar el resaltado sin cambiar la programación.");
                Menu("cronograma_ruta_critica", "cronograma_critica_multiple");
                Estado(false, true, "Múltiple debe activar sólo su opción y conservar visible el Gantt.");
                Menu("cronograma_ruta_critica", "cronograma_critica_multiple");
                Estado(false, false, "Volver a elegir Múltiple debe ocultar el resaltado sin cambiar la programación.");
                panel.SeleccionarRutaCritica(MYGModoRutaCritica.Simple);
                panel.SeleccionarRutaCritica(MYGModoRutaCritica.Simple);
                Estado(true, false, "Seleccionar un modo explícitamente debe ser estable; sólo repetir su clic lo desactiva.");
                exige(Huella(plan) == huella && aplicaciones == antes && ActualId() == seleccion,
                    "Cambiar el modo de ruta crítica debe conservar el plan, la tarea seleccionada y el historial.");

                string ActualId() => (tabla.CurrentRow?.Tag as MYGResultadoTarea)?.Tarea.Id;
                void Estado(bool esSimple, bool esMultiple, string mensaje)
                {
                    Application.DoEvents();
                    exige(simple.Checked == esSimple && multiple.Checked == esMultiple &&
                        visual.MostrarCritica == (esSimple || esMultiple), mensaje);
                }
            }
        }
    }

    private static void VerificarNavegacionSinLicencia(Action<bool, string> exige)
    {
        var proyecto = Proyecto();
        string firma = MYGProyectoStorage.Firma(proyecto);
        using var sesion = new SesionDesktop();
        using var editor = new EditorForm(proyecto, null, sesion, firma);
        editor.WindowState = FormWindowState.Normal;
        editor.ClientSize = new Size(1600, 900);
        editor.Show();
        Application.DoEvents();
        var presupuesto = Control<Button>(editor, "vista_presupuesto_button");
        var cronograma = Control<Button>(editor, "vista_cronograma_button");
        var cintaPresupuesto = Control<FlowLayoutPanel>(editor, "herramientas_proyecto");
        var cintaCronograma = Control<FlowLayoutPanel>(editor, "herramientas_cronograma");
        var cabecera = Control<TableLayoutPanel>(editor, "cabecera_vistas_proyecto");
        exige(ReferenceEquals(cintaPresupuesto.Parent, cintaCronograma.Parent) &&
            ReferenceEquals(cintaPresupuesto.Parent.Parent, cabecera) &&
            cabecera.Parent is TableLayoutPanel exterior && ReferenceEquals(exterior.GetControlFromPosition(0, 0), cabecera),
            "Las dos cintas deben compartir la única cabecera de la fila superior sin volver a insertar una cinta encima de R/CPM.");
        var historial = (Stack<MYGProyectoDocumento>)typeof(EditorForm).GetField("undo", Privados).GetValue(editor);
        int cambios = historial.Count;
        exige(presupuesto.Visible && cronograma.Visible && presupuesto.Enabled && cronograma.Enabled &&
            presupuesto.Parent == cronograma.Parent &&
            (presupuesto.Parent is not FlowLayoutPanel modos || !modos.AutoScroll),
            "R y CPM deben permanecer juntos y utilizables fuera de la cinta desplazable, también sin licencia.");
        cronograma.PerformClick();
        Application.DoEvents();
        var panel = Control<MYGPanelCronograma>(editor, "cronograma_panel");
        exige(panel.Visible && presupuesto.Visible && cronograma.Visible,
            "CPM debe mostrar el panel real y conservar visibles ambos accesos de navegación.");
        VerificarCinta();
        VerificarTiempoTrabajo(panel, Control<Button>(editor, "cronograma_tiempo_trabajo"),
            Control<DataGridView>(panel, "cronograma_tareas"), Control<ScrollableControl>(panel, "cronograma_gantt"), exige);
        presupuesto.PerformClick();
        Application.DoEvents();
        exige(!panel.Visible && Descendientes(editor).OfType<MYGPanelPresupuesto>().Any(p => p.Visible),
            "R debe recuperar la vista de presupuesto al volver desde el cronograma.");
        cronograma.PerformClick();
        presupuesto.PerformClick();
        Application.DoEvents();
        exige(!sesion.Autorizado && sesion.Credencial == null && proyecto.Cronograma == null &&
            MYGProyectoStorage.Firma(proyecto) == firma && historial.Count == cambios,
            "Alternar R y CPM sin licencia no debe consultar credenciales, persistir el plan temporal ni modificar firma o historial.");
        editor.Close();

        void VerificarCinta()
        {
            string[] nombres = {
                "cronograma_inicio_button", "cronograma_guardar_button", "cronograma_imprimir_button",
                "cronograma_info_proyecto_button", "cronograma_exportar_button", "cronograma_tiempo_trabajo",
                "cronograma_informacion", "cronograma_insertar_hito", "cronograma_ruta_critica",
                "cronograma_diagrama_red", "cronograma_asistente_ia", "cronograma_linea_base", "cronograma_linea_tiempo",
                "cronograma_programar_automatico", "cronograma_programar_manual", "cronograma_adquisiciones",
                "cronograma_valorizado", "cronograma_responsables", "cronograma_otros"
            };
            var botones = cintaCronograma.Controls.OfType<Button>().ToArray();
            var referencia = cintaPresupuesto.Controls.OfType<Button>().First();
            exige(botones.Select(b => b.Name).SequenceEqual(nombres) &&
                botones.All(b => b is MYG2027_BotonComercial && b.Height == referencia.Height && b.Image != null &&
                    b.TextImageRelation == TextImageRelation.ImageAboveText &&
                    b.ImageAlign == ContentAlignment.TopCenter && b.TextAlign == ContentAlignment.BottomCenter),
                "La franja CPM debe conservar sus 19 comandos en orden y usar el mismo botón, altura y alineación que Presupuesto.");
            var imagenes = botones.Select(b => b.Image).ToArray();
            var textos = botones.Select(b => b.Text).ToArray();
            var menus = botones.Where(b => b.ContextMenuStrip != null).ToArray();
            exige(menus.Select(b => b.Name).SequenceEqual(new[]
                { "cronograma_imprimir_button", "cronograma_exportar_button", "cronograma_ruta_critica", "cronograma_linea_base", "cronograma_otros" }),
                "CPM debe exponer Imprimir, Exportar, Ruta crítica, Línea base y Otros como cinco desplegables sin añadir botones a la franja.");
            VerificarMenu(menus[0], CronogramaMenusUICheck.NombresImpresion, verificarPermisos: false);
            VerificarMenu(menus[1], CronogramaMenusUICheck.NombresExportacion);
            VerificarMenu(menus[2], new[] { "cronograma_critica_simple", "cronograma_critica_multiple" });
            VerificarMenu(menus[3], new[] { "cronograma_establecer_base", "cronograma_quitar_base", "cronograma_ver_base" });
            VerificarMenu(menus[4], new[] {
                "cronograma_nueva_tarea", "cronograma_eliminar", "cronograma_vincular", "cronograma_desvincular",
                "cronograma_sincronizar", "cronograma_fechas_proyecto", "cronograma_zoom_mas", "cronograma_zoom_menos", "cronograma_zoom_ajustar",
                "cronograma_expandir", "cronograma_contraer", "cronograma_calendario_valorizado",
                "cronograma_calendario_adquisiciones", "cronograma_guardar", "cronograma_deshacer", "cronograma_rehacer"
            });
            int original = MYGTamanoTextoUI.Porcentaje;
            Size tamanoOriginal = editor.ClientSize;
            int alturaCabecera = cabecera.Height;
            Point posicionOriginal = cintaCronograma.AutoScrollPosition;
            try
            {
                foreach (int porcentaje in new[] { 85, 100, 115 })
                {
                    MYGTamanoTextoUI.Cambiar(porcentaje, guardarPreferencia: false);
                    Application.DoEvents();
                    foreach (var boton in botones)
                    {
                        using var grafico = boton.CreateGraphics();
                        float escala = boton.DeviceDpi / 96F;
                        int ancho = boton.ClientSize.Width - 2 * Math.Max(3, (int)Math.Round(4F * escala));
                        int alto = boton.ClientSize.Height - 2 * Math.Max(2, (int)Math.Round(2F * escala));
                        Size texto = TextRenderer.MeasureText(grafico, boton.Text, boton.Font,
                            new Size(Math.Max(1, ancho), int.MaxValue), TextFormatFlags.WordBreak | TextFormatFlags.NoPadding);
                        int linea = TextRenderer.MeasureText(grafico, "Ag", boton.Font, Size.Empty,
                            TextFormatFlags.SingleLine | TextFormatFlags.NoPadding).Height;
                        exige(ancho > 0 && texto.Width <= ancho && texto.Height <= linea * 2 &&
                            texto.Height + (int)Math.Round(19F * escala) <= alto,
                            $"{boton.AccessibleName} debe caber completo en dos líneas y dejar sitio separado para un icono legible al {porcentaje} %.");
                    }
                    editor.ClientSize = new Size(1000, tamanoOriginal.Height);
                    Application.DoEvents();
                    exige(cintaCronograma.AutoScroll && !cintaCronograma.WrapContents && cintaCronograma.HorizontalScroll.Visible &&
                        cabecera.Height == alturaCabecera,
                        "Una ventana estrecha debe desplazar la franja horizontalmente sin añadir filas ni aumentar su altura.");
                    foreach (var extremo in new[] { botones[0], botones[^1] })
                    {
                        cintaCronograma.ScrollControlIntoView(extremo);
                        Application.DoEvents();
                        exige(cintaCronograma.ClientRectangle.Contains(extremo.Bounds),
                            $"El desplazamiento debe permitir mostrar completo el comando {extremo.AccessibleName}.");
                    }
                    var areaCinta = cintaCronograma.RectangleToScreen(cintaCronograma.ClientRectangle);
                    var areaCabecera = cabecera.RectangleToScreen(cabecera.ClientRectangle);
                    exige(new[] { presupuesto, cronograma }.All(b => b.Visible && b.Enabled &&
                        areaCabecera.Contains(b.RectangleToScreen(b.ClientRectangle)) &&
                        !areaCinta.IntersectsWith(b.RectangleToScreen(b.ClientRectangle))),
                        "R y CPM deben seguir visibles y accesibles fuera del desplazamiento, también con texto grande y ventana estrecha.");
                    editor.ClientSize = tamanoOriginal;
                    Application.DoEvents();
                }
                exige(botones.Select(b => b.Text).SequenceEqual(textos) &&
                    botones.Select(b => b.Image).SequenceEqual(imagenes) &&
                    MYGProyectoStorage.Firma(proyecto) == firma && historial.Count == cambios,
                    "Adaptar la franja debe conservar etiquetas, iconos, documento e historial.");
            }
            finally
            {
                MYGTamanoTextoUI.Cambiar(original, guardarPreferencia: false);
                editor.ClientSize = tamanoOriginal;
                cintaCronograma.AutoScrollPosition = new Point(-posicionOriginal.X, -posicionOriginal.Y);
                Application.DoEvents();
            }

            void VerificarMenu(Button boton, string[] opciones, bool verificarPermisos = true)
            {
                cintaCronograma.ScrollControlIntoView(boton);
                exige(boton.Enabled,
                    $"Consultar el desplegable {boton.AccessibleName} debe estar permitido sin licencia y no abrir un diálogo de autenticación.");
                boton.PerformClick();
                Application.DoEvents();
                var menu = boton.ContextMenuStrip;
                exige(menu.Visible && menu.Items.OfType<ToolStripMenuItem>().Select(i => i.Name).SequenceEqual(opciones) &&
                    (!verificarPermisos || menu.Items.OfType<ToolStripMenuItem>().All(i => i.Enabled == (i.Tag is not true))),
                    $"El desplegable {boton.AccessibleName} debe abrir sus mismas opciones y mantener los permisos de edición sin licencia.");
                menu.Close();
                Application.DoEvents();
            }
        }
    }

    private static void VerificarTiempoTrabajo(MYGPanelCronograma panel, Button boton, DataGridView tabla,
        ScrollableControl gantt, Action<bool, string> exige)
    {
        string seleccion = (tabla.CurrentRow?.Tag as MYGResultadoTarea)?.Tarea.Id;
        string columna = tabla.CurrentCell?.OwningColumn.Name;
        var seleccionadas = tabla.SelectedRows.Cast<DataGridViewRow>()
            .Select(r => ((MYGResultadoTarea)r.Tag).Tarea.Id).OrderBy(id => id).ToArray();
        var ventanas = Application.OpenForms.Cast<Form>().ToArray();
        int altoGantt = gantt.ClientSize.Height;
        exige(boton.Enabled && boton.Tag is not true,
            "Tiempo de trabajo debe ser una consulta disponible sin permiso de edición.");
        boton.PerformClick();
        Application.DoEvents();
        var tiempo = Descendientes(panel).Single(c => c.Name == "cronograma_tiempo_trabajo" && c is not Button);
        Rectangle areaGantt = gantt.RectangleToScreen(gantt.ClientRectangle);
        Rectangle areaTrabajo = tiempo.RectangleToScreen(tiempo.ClientRectangle);
        exige(tiempo.Visible && tiempo.Dock == DockStyle.Bottom && tiempo.Parent != null &&
            areaGantt.Bottom <= areaTrabajo.Top && areaTrabajo.Height > 0 &&
            gantt.Visible && gantt.ClientSize.Width > 100 && gantt.ClientSize.Height > 100,
            "Tiempo de trabajo debe ocupar un panel inferior sin tapar ni sustituir el Gantt que permanece visible encima.");
        exige(Application.OpenForms.Cast<Form>().SequenceEqual(ventanas),
            "Tiempo de trabajo debe abrirse dentro del cronograma, sin crear otra ventana ni solicitar credenciales.");
        exige((tabla.CurrentRow?.Tag as MYGResultadoTarea)?.Tarea.Id == seleccion &&
            tabla.CurrentCell?.OwningColumn.Name == columna,
            "Abrir Tiempo de trabajo debe mantener la tarea y la celda seleccionadas para continuar consultando el Gantt.");
        boton.PerformClick();
        Application.DoEvents();
        exige(!tiempo.Visible && gantt.Visible && gantt.ClientSize.Height >= altoGantt - 2 &&
            (tabla.CurrentRow?.Tag as MYGResultadoTarea)?.Tarea.Id == seleccion &&
            tabla.CurrentCell?.OwningColumn.Name == columna &&
            tabla.SelectedRows.Cast<DataGridViewRow>().Select(r => ((MYGResultadoTarea)r.Tag).Tarea.Id)
                .OrderBy(id => id).SequenceEqual(seleccionadas),
            "Cerrar el panel inferior debe recuperar el espacio y conservar la tarea, la celda y la selección del Gantt.");
    }

    private static void AceptarTarea(Action abrir, string nombre, Action<bool, string> exige)
    {
        bool atendido = false;
        Exception fallo = null;
        using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
        temporizador.Tick += (_, _) =>
        {
            var dialogo = Application.OpenForms.Cast<Form>().SingleOrDefault(f => f.Name == "cronograma_tarea_dialogo");
            if (dialogo == null) return;
            temporizador.Stop();
            try
            {
                Control<TextBox>(dialogo, "cronograma_tarea_nombre").Text = nombre;
                Control<NumericUpDown>(dialogo, "cronograma_tarea_duracion").Value = 0;
                Control<Button>(dialogo, "cronograma_tarea_aceptar").PerformClick();
                atendido = dialogo.DialogResult == DialogResult.OK;
                if (!atendido) dialogo.Close();
            }
            catch (Exception ex) { fallo = ex; dialogo.Close(); }
        };
        temporizador.Start();
        abrir();
        temporizador.Stop();
        if (fallo != null) throw new InvalidOperationException("No se pudo completar el diálogo real de tarea.", fallo);
        exige(atendido, "Insertar hito debe abrir y aceptar el diálogo de información de la tarea.");
    }

    private static MYGProyectoDocumento Proyecto()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Cronograma sin alterar presupuesto", "ESTRUCTURAS");
        string id = MYGProyectoStorage.NuevoId();
        proyecto.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Item = "01.01", Posicion = 1,
            TipoPropuesta = "PARTIDA", Descripcion = "Concreto de origen", Unidad = "m³", Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida { Cantidad = 8m, FuenteMetrado = MYGFuenteMetrado.Cantidad, PrecioDirecto = 150m }
        });
        MYGProyectoStorage.Validar(proyecto);
        return proyecto;
    }

    private static MYGCronograma Plan()
    {
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 8) };
        var resumen = new MYGTareaCronograma { Nombre = "Etapa de prueba", EsResumen = true };
        plan.Tareas.Add(resumen);
        for (int i = 1; i <= 40; i++)
            plan.Tareas.Add(new MYGTareaCronograma
            {
                PadreId = resumen.Id, Codigo = "T" + i.ToString("00"), Nombre = "Trabajo " + i,
                DuracionDias = i == 2 ? 3 : 2
            });
        return plan;
    }

    private static string Huella(MYGCronograma plan) => JsonSerializer.Serialize(plan);
    private static object Invocar(object objeto, string nombre, params object[] argumentos) =>
        objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);
    private static T Control<T>(Control padre, string nombre) where T : Control =>
        Descendientes(padre).OfType<T>().Single(c => c.Name == nombre);
    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
