using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class RedConstructivaCronogramaIACheck
{
    private static readonly DateTime Inicio = new(2026, 10, 5);
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Red constructiva IA: " + detalle); }
    private static string Instantanea(MYGCronograma plan) => JsonSerializer.Serialize(plan);
    private static MYGCronograma Plan() => new() { FechaInicio = Inicio, FechaEstado = Inicio };
    private static MYGTareaCronograma Tarea(string id) => new()
    { Id = id, Nombre = "Trabajo " + id, Codigo = id, Modo = MYGModoTarea.Automatica, DuracionDias = 2 };
    private static void Vincular(MYGTareaCronograma destino, string origen, MYGTipoVinculo tipo = MYGTipoVinculo.FC, int desfase = 0) =>
        destino.Predecesoras.Add(new MYGDependenciaCronograma { PredecesoraId = origen, Tipo = tipo, DesfaseDias = desfase });
    private static MYGCronograma Triangulo()
    {
        var plan = Plan();
        plan.Tareas.AddRange(new[] { Tarea("A"), Tarea("B"), Tarea("C") });
        Vincular(plan.Tareas[1], "A"); Vincular(plan.Tareas[2], "A"); Vincular(plan.Tareas[2], "B");
        return plan;
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        FrentesGrandes(pasa);
        ConvergenciaYRedundancia(pasa);
        RelacionesMixtasYProtegidas(pasa);
        LimitesDeRevision(pasa);
    }

    private static void FrentesGrandes(Action<string> pasa)
    {
        var plan = Plan();
        for (int frente = 0; frente < 3; frente++)
        {
            string grupo = "F" + frente;
            plan.Tareas.Add(new MYGTareaCronograma { Id = grupo, Nombre = "Frente " + frente, EsResumen = true });
            for (int n = 0; n < 200; n++)
            {
                var tarea = Tarea(grupo + "-" + n);
                tarea.PadreId = grupo;
                if (n > 0) Vincular(tarea, grupo + "-" + (n - 1));
                plan.Tareas.Add(tarea);
            }
        }
        foreach (var tarea in plan.Tareas.Where(t => t.PadreId == "F1").Take(6).Select((t, n) => (Tarea: t, Numero: n)))
            Vincular(tarea.Tarea, "F0-0", MYGTipoVinculo.CC, tarea.Numero % 2 == 0 ? 218 : 398);
        plan.Calendario.Feriados.Add(Inicio.AddDays(2));
        plan.Calendario.Excepciones.Add(new MYGExcepcionCalendario
        { Inicio = Inicio.AddDays(5), Fin = Inicio.AddDays(5), Laborable = true });
        string antes = Instantanea(plan);
        var avisos = MYGRedConstructivaCronogramaIA.Revisar(plan, 300);
        Exige(plan.Tareas.Count == 603 && avisos.Count(a => a.Contains("[DESFASE_LARGO]")) == 6 &&
            avisos.Any(a => a.Contains("CC+218")) && avisos.Any(a => a.Contains("CC+398")) &&
            avisos.Any(a => a.Contains("[ANCLA_REPETIDA]") && a.Contains("F0-0") && a.Contains("6 vínculos")),
            "una obra de 600 tareas en tres frentes debe señalar los seis anclajes remotos de 218/398 jornadas.");
        Exige(!avisos.Any(a => a.Contains("REVISION_PARCIAL")) && Instantanea(plan) == antes,
            "la revisión normal debe conservar tareas, vínculos, fechas, feriados y excepciones de los tres frentes.");
        var umbral = Plan(); umbral.Tareas.AddRange(new[] { Tarea("A"), Tarea("B"), Tarea("C") });
        Vincular(umbral.Tareas[1], "A", MYGTipoVinculo.CC, 11);
        Vincular(umbral.Tareas[2], "A", MYGTipoVinculo.CC, 12);
        var umbralAvisos = MYGRedConstructivaCronogramaIA.Revisar(umbral, 101);
        Exige(umbralAvisos.Count(a => a.Contains("DESFASE_LARGO")) == 1 && umbralAvisos[0].Contains("CC+12") &&
            MYGRedConstructivaCronogramaIA.UmbralDesfaseLargo(1) == 10 &&
            MYGRedConstructivaCronogramaIA.UmbralDesfaseLargo(int.MaxValue) == 214748365,
            "el umbral relativo debe redondearse hacia arriba y mantener diez jornadas como mínimo sin desbordarse.");
        pasa("Red constructiva IA: revisa 603 tareas en frentes paralelos, detecta CC+218/398 y anclas repetidas sin modificar calendario ni fechas");
    }

    private static void ConvergenciaYRedundancia(Action<string> pasa)
    {
        var plan = Triangulo();
        plan.Tareas.AddRange(new[] { Tarea("D"), Tarea("E") });
        Vincular(plan.Tareas[2], "D", MYGTipoVinculo.CC);
        Vincular(plan.Tareas[2], "E", MYGTipoVinculo.FF);
        string antes = Instantanea(plan);
        var avisos = MYGRedConstructivaCronogramaIA.Revisar(plan, 100);
        Exige(avisos.Count(a => a.Contains("[REDUNDANCIA_FC]")) == 1 &&
            avisos.Single(a => a.Contains("[REDUNDANCIA_FC]")).Contains("Trabajo B") &&
            avisos.Single(a => a.Contains("[CONVERGENCIA]")).Contains("4 predecesoras") &&
            avisos.Single(a => a.Contains("[CONVERGENCIA]")).Contains("cierre válido"),
            "debe identificar el triángulo FC0 y revisar una convergencia sin declarar inválido el cierre de varios frentes.");
        Exige(plan.Tareas[2].Predecesoras.Count == 4 && Instantanea(plan) == antes,
            "un aviso no debe borrar la relación directa ni los vínculos CC/FF del cierre.");
        pasa("Red constructiva IA: diagnostica redundancia FC0 y convergencia de varios frentes como avisos, conservando todas las predecesoras");
    }

    private static void RelacionesMixtasYProtegidas(Action<string> pasa)
    {
        foreach (var tipo in new[] { MYGTipoVinculo.CC, MYGTipoVinculo.FF, MYGTipoVinculo.CF })
        {
            var plan = Triangulo(); plan.Tareas[1].Predecesoras[0].Tipo = tipo;
            string antes = Instantanea(plan);
            Exige(!MYGRedConstructivaCronogramaIA.Revisar(plan, 100).Any(a => a.Contains("REDUNDANCIA_FC")) && Instantanea(plan) == antes,
                "un camino " + tipo + "/FC no permite deducir redundancia FC0 ni modificar relaciones.");
        }
        foreach (int desfase in new[] { -218, -1, 1, 218 })
        {
            var plan = Triangulo(); plan.Tareas[1].Predecesoras[0].DesfaseDias = desfase;
            string antes = Instantanea(plan);
            var avisos = MYGRedConstructivaCronogramaIA.Revisar(plan, 100);
            Exige(!avisos.Any(a => a.Contains("REDUNDANCIA_FC")) && Instantanea(plan) == antes,
                "la revisión conservadora no debe tratar una ruta FC con desfase como un triángulo FC0.");
            if (desfase == -218) Exige(avisos.Any(a => a.Contains("FC-218")), "los adelantos largos también requieren revisión sin perder su signo.");
        }
        foreach (int posicion in new[] { 0, 1, 2 })
        foreach (string proteccion in new[] { "manual", "importada", "partes", "restricción" })
        {
            var plan = Triangulo(); var tarea = plan.Tareas[posicion];
            if (proteccion == "manual") { tarea.Modo = MYGModoTarea.Manual; tarea.InicioManual = Inicio; }
            if (proteccion == "importada") tarea.FechasImportadasDelphin = new MYGFechasImportadasDelphin
            { Inicio = Inicio, Fin = Inicio.AddDays(1), DuracionDias = 2 };
            if (proteccion == "partes") tarea.Partes.Add(new MYGParteTarea { DuracionDias = 2, Cantidad = 1, Porcentaje = 100 });
            if (proteccion == "restricción") { tarea.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; tarea.FechaRestriccion = Inicio; }
            string antes = Instantanea(plan);
            Exige(!MYGRedConstructivaCronogramaIA.Revisar(plan, 100).Any(a => a.Contains("REDUNDANCIA_FC")) && Instantanea(plan) == antes,
                "no debe inferir redundancia si un extremo o la tarea intermedia tiene planificación " + proteccion + ".");
        }
        pasa("Red constructiva IA: conserva tipos mixtos, desfases positivos/negativos y tareas manuales, importadas, divididas o restringidas sin falsas redundancias");
    }

    private static void LimitesDeRevision(Action<string> pasa)
    {
        var muchosAvisos = Plan(); muchosAvisos.Tareas.Add(Tarea("A"));
        for (int n = 0; n < 45; n++)
        {
            var tarea = Tarea("L" + n); Vincular(tarea, "A", MYGTipoVinculo.CC, 218); muchosAvisos.Tareas.Add(tarea);
        }
        var avisos = MYGRedConstructivaCronogramaIA.Revisar(muchosAvisos, 100);
        Exige(avisos.Count == 31 && avisos[^1].Contains("LIMITE_DIAGNOSTICO") &&
            avisos[0].Contains("ANCLA_REPETIDA") &&
            !avisos.Any(a => a.Contains("REVISION_PARCIAL")),
            "debe conservar el diagnóstico general de anclajes repetidos entre treinta detalles y un aviso, sin afirmar que una revisión completa fue parcial.");
        var densa = Plan();
        for (int n = 0; n < 330; n++)
        {
            var tarea = Tarea("D" + n);
            for (int a = 0; a < n; a++) Vincular(tarea, "D" + a);
            densa.Tareas.Add(tarea);
        }
        string antes = Instantanea(densa);
        avisos = MYGRedConstructivaCronogramaIA.Revisar(densa, 300);
        Exige(avisos.Count <= 31 && avisos.Any(a => a.Contains("REVISION_PARCIAL")) &&
            avisos.Any(a => a.Contains("LIMITE_DIAGNOSTICO")) && Instantanea(densa) == antes,
            "una red densa debe acotar arcos/comparaciones, declarar la revisión parcial y conservar todos los datos.");
        pasa("Red constructiva IA: acota detalles y trabajo sobre redes densas y declara revisiones parciales sin alterar el cronograma");
    }
}
