using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

/// <summary>Revisión orientativa de la red propuesta. No programa tareas ni modifica vínculos.</summary>
public static class MYGRedConstructivaCronogramaIA
{
    public const int PredecesorasHabituales = 3;
    private const int MaximoDetalles = 30;
    private const int MaximoTareas = 20000;
    private const int MaximoArcos = 50000;
    private const int MaximoComparaciones = 200000;

    public static int UmbralDesfaseLargo(int jornadasDisponibles) =>
        Math.Max(10, (int)decimal.Ceiling(jornadasDisponibles / 10m));

    public static List<string> Revisar(MYGCronograma plan, int jornadasDisponibles)
    {
        ArgumentNullException.ThrowIfNull(plan);
        ArgumentNullException.ThrowIfNull(plan.Tareas);
        var avisos = new List<string>();
        bool detallesLimitados = false;
        bool revisionParcial = plan.Tareas.Count > MaximoTareas;
        void Avisar(string mensaje, bool prioritario = false)
        {
            if (prioritario)
            {
                avisos.Insert(0, mensaje);
                if (avisos.Count > MaximoDetalles) { avisos.RemoveAt(MaximoDetalles); detallesLimitados = true; }
            }
            else if (avisos.Count < MaximoDetalles) avisos.Add(mensaje);
            else detallesLimitados = true;
        }

        // El asistente ya valida identidades, ciclos y referencias antes de revisar la calidad.
        // También se acotan datos y trabajo aquí para que una red densa no bloquee la revisión.
        var tareas = new Dictionary<string, MYGTareaCronograma>(StringComparer.Ordinal);
        foreach (var tarea in plan.Tareas.Take(MaximoTareas))
            if (tarea != null && !string.IsNullOrEmpty(tarea.Id)) tareas.TryAdd(tarea.Id, tarea);
        var aptas = tareas.Values.Where(AptaParaRedundancia).Select(t => t.Id)
            .ToHashSet(StringComparer.Ordinal);
        var fc = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);
        var anclas = new Dictionary<string, (int Cantidad, int Minimo, int Maximo)>(StringComparer.Ordinal);
        int umbral = UmbralDesfaseLargo(jornadasDisponibles);
        int arcos = 0;
        bool limiteArcos = false;
        string Nombre(string id) => tareas.TryGetValue(id, out var tarea) ? Etiqueta(tarea) : Acortar(id);

        foreach (var tarea in tareas.Values)
        {
            if (tarea.EsResumen || tarea.Predecesoras == null) continue;
            if (tarea.Predecesoras.Count > PredecesorasHabituales)
                Avisar("[CONVERGENCIA] «" + Etiqueta(tarea) + "» tiene " + tarea.Predecesoras.Count +
                    " predecesoras. Puede ser un cierre válido de varios frentes; compruebe que sean liberaciones inmediatas y no antecesoras ya representadas.");
            foreach (var dependencia in tarea.Predecesoras)
            {
                if (arcos >= MaximoArcos)
                {
                    limiteArcos = true;
                    revisionParcial = true;
                    break;
                }
                arcos++;
                if (dependencia == null || string.IsNullOrEmpty(dependencia.PredecesoraId)) continue;
                if (Math.Abs((long)dependencia.DesfaseDias) > umbral)
                {
                    string desfase = dependencia.DesfaseDias >= 0 ? "+" + dependencia.DesfaseDias : dependencia.DesfaseDias.ToString();
                    Avisar("[DESFASE_LARGO] «" + Etiqueta(tarea) + "» depende de «" + Nombre(dependencia.PredecesoraId) +
                        "» mediante " + dependencia.Tipo + desfase + " jornadas (umbral de revisión: " + umbral +
                        "). Justifique la espera técnica y la liberación real del frente; no use el desfase como una fecha absoluta.");
                    if (dependencia.Tipo is MYGTipoVinculo.CC or MYGTipoVinculo.FF)
                    {
                        var anterior = anclas.GetValueOrDefault(dependencia.PredecesoraId);
                        anclas[dependencia.PredecesoraId] = (anterior.Cantidad + 1,
                            anterior.Cantidad == 0 ? dependencia.DesfaseDias : Math.Min(anterior.Minimo, dependencia.DesfaseDias),
                            anterior.Cantidad == 0 ? dependencia.DesfaseDias : Math.Max(anterior.Maximo, dependencia.DesfaseDias));
                    }
                }
                if (dependencia.Tipo == MYGTipoVinculo.FC && dependencia.DesfaseDias == 0 &&
                    aptas.Contains(tarea.Id) && aptas.Contains(dependencia.PredecesoraId))
                {
                    if (!fc.TryGetValue(tarea.Id, out var anteriores))
                        fc[tarea.Id] = anteriores = new HashSet<string>(StringComparer.Ordinal);
                    anteriores.Add(dependencia.PredecesoraId);
                }
            }
            if (limiteArcos) break;
        }
        foreach (var ancla in anclas.Where(a => a.Value.Cantidad >= 6))
            Avisar("[ANCLA_REPETIDA] «" + Nombre(ancla.Key) + "» origina " + ancla.Value.Cantidad +
                " vínculos CC/FF con desfases largos (" + ancla.Value.Minimo + " a " + ancla.Value.Maximo +
                " jornadas). Revise liberaciones por frente en lugar de anclar muchas tareas a un origen remoto.", prioritario: true);

        // Solo triángulos FC0 entre tareas automáticas ordinarias. No se deduce redundancia
        // de una mera ruta CC/FF/CF ni de fechas que casualmente coincidan hoy.
        // Los arcos se conservan: este diagnóstico tampoco promete equivalencia de oficios.
        int comparaciones = 0;
        bool limiteComparaciones = false;
        var redundantes = new HashSet<(string Origen, string Destino)>();
        foreach (var destino in fc)
        {
            foreach (string intermedia in destino.Value)
            {
                if (!fc.TryGetValue(intermedia, out var anteriores)) continue;
                foreach (string origen in anteriores)
                {
                    if (comparaciones >= MaximoComparaciones)
                    {
                        limiteComparaciones = true;
                        revisionParcial = true;
                        break;
                    }
                    comparaciones++;
                    if (destino.Value.Contains(origen) && redundantes.Add((origen, destino.Key)))
                        Avisar("[REDUNDANCIA_FC] «" + Nombre(origen) + "» → «" + Nombre(destino.Key) +
                            "» también está representada por «" + Nombre(origen) + "» → «" + Nombre(intermedia) +
                            "» → «" + Nombre(destino.Key) + "» mediante FC sin desfase. Revise la relación directa; no se ha eliminado ningún vínculo.");
                }
                if (limiteComparaciones) break;
            }
            if (limiteComparaciones) break;
        }
        if (revisionParcial || detallesLimitados)
        {
            string limite = revisionParcial
                ? "[REVISION_PARCIAL] Revisión acotada a " + MaximoTareas + " tareas, " + MaximoArcos +
                    " vínculos y " + MaximoComparaciones + " comparaciones; no se afirma haber revisado toda la red."
                : "";
            if (detallesLimitados)
                limite += (limite.Length == 0 ? "" : " ") + "[LIMITE_DIAGNOSTICO] Se muestran como máximo " +
                    MaximoDetalles + " detalles. Revise también los demás frentes.";
            avisos.Add(limite);
        }
        return avisos;
    }

    private static bool AptaParaRedundancia(MYGTareaCronograma tarea) =>
        !tarea.EsResumen && tarea.Modo == MYGModoTarea.Automatica && tarea.FechasImportadasDelphin == null &&
        tarea.Partes?.Count is null or 0 && tarea.TipoRestriccion == MYGTipoRestriccion.LoAntesPosible;

    private static string Etiqueta(MYGTareaCronograma tarea) =>
        Acortar((string.IsNullOrWhiteSpace(tarea.Codigo) ? "" : tarea.Codigo + " ") + tarea.Nombre);

    private static string Acortar(string texto) => texto == null ? "(sin identidad)" :
        texto.Length <= 100 ? texto : texto[..97] + "…";
}
