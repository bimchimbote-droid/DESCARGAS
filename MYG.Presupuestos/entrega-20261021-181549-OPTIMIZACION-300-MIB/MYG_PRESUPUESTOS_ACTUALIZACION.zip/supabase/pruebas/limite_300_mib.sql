-- SOLO PostgreSQL desechable, después del fixture usuarios_myg_roles.sql.
-- Nunca ejecutar este archivo en el Supabase de un usuario.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren una base desechable.'; end $$;
\endif

reset role;
create table qa.antes_limite_300 as select
    (select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb) from public.myg_nube_proyectos p) proyectos,
    (select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from public.myg_nube_historial h) historial,
    (select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb) from public.myg_nube_miembros m) miembros,
    (select coalesce(jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id),'[]'::jsonb) from public.myg_nube_operaciones o) operaciones,
    (select coalesce(jsonb_agg(to_jsonb(i) order by auth_usuario_id),'[]'::jsonb) from myg_nube_privado.identidades_verificadas i) identidades,
    (select rolconfig from pg_roles where rolname='authenticated') rolconfig,
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'definer',p.prosecdef) order by p.oid)
      from pg_proc p where p.oid in (
        'myg_nube_privado.validar_contenido(jsonb)'::regprocedure,
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure)) atributos,
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'acl',p.proacl) order by p.oid)
      from pg_proc p where p.oid in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure)) acl_rpc,
    (select coalesce(jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,
        'acl',p.proacl,'config',p.proconfig,'definer',p.prosecdef) order by p.oid),'[]'::jsonb)
      from pg_proc p where p.oid in (
        to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)'),
        to_regprocedure('public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)'))) atributos_ampliados,
    null::jsonb historial_incremental,
    (select count(*) from qa.resultados) resultados_antes;

do $$ begin
    if to_regclass('myg_nube_privado.historial_cambios') is not null then
        execute 'update qa.antes_limite_300 set historial_incremental=(select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),''[]''::jsonb) from myg_nube_privado.historial_cambios h)';
    end if;
end $$;

\ir ../migraciones/20261025_limite_300_mib.sql

select qa.exige((select proyectos=(select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb) from public.myg_nube_proyectos p)
    from qa.antes_limite_300),'300 MiB: conserva proyectos y revisiones');
select qa.exige((select historial=(select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from public.myg_nube_historial h)
    from qa.antes_limite_300),'300 MiB: conserva historial anterior');
select qa.exige((select miembros=(select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb) from public.myg_nube_miembros m)
    from qa.antes_limite_300),'300 MiB: conserva miembros, roles y máscaras');
select qa.exige((select operaciones=(select coalesce(jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id),'[]'::jsonb) from public.myg_nube_operaciones o)
    from qa.antes_limite_300),'300 MiB: conserva operaciones, solicitudes y respuestas');
select qa.exige((select identidades=(select coalesce(jsonb_agg(to_jsonb(i) order by auth_usuario_id),'[]'::jsonb) from myg_nube_privado.identidades_verificadas i)
    from qa.antes_limite_300),'300 MiB: conserva vinculaciones MYG');
select qa.exige((select rolconfig is not distinct from (select rolconfig from pg_roles where rolname='authenticated')
    from qa.antes_limite_300),'300 MiB: conserva configuración del rol');
select qa.exige((select atributos=(select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'definer',p.prosecdef) order by p.oid)
      from pg_proc p where p.oid in (
        'myg_nube_privado.validar_contenido(jsonb)'::regprocedure,
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure))
    from qa.antes_limite_300),'300 MiB: conserva OID, propietario y SECURITY de funciones originales');
select qa.exige((select acl_rpc=(select jsonb_agg(jsonb_build_object('oid',p.oid,'acl',p.proacl) order by p.oid)
      from pg_proc p where p.oid in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure))
    from qa.antes_limite_300),'300 MiB: conserva ACL de RPC originales');
select qa.exige((select atributos_ampliados=(select coalesce(jsonb_agg(jsonb_build_object(
        'oid',p.oid,'owner',p.proowner,'acl',p.proacl,'config',p.proconfig,'definer',p.prosecdef) order by p.oid),'[]'::jsonb)
      from pg_proc p where p.oid in (select (f->>'oid')::oid from jsonb_array_elements(a.atributos_ampliados) f))
    from qa.antes_limite_300 a),'300 MiB: parche conserva OID, propietario, ACL y configuración de funciones existentes');
select qa.exige((select historial_incremental is null or historial_incremental=(
    select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from myg_nube_privado.historial_cambios h)
    from qa.antes_limite_300),'300 MiB: conserva diferencias incrementales');

create table qa.primera_limite_300 as select
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,
        'config',p.proconfig,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
      from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace)) funciones;
\ir ../migraciones/20261025_limite_300_mib.sql
select qa.exige((select funciones=(select jsonb_agg(jsonb_build_object('oid',p.oid,
        'owner',p.proowner,'acl',p.proacl,'config',p.proconfig,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
      from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace))
    from qa.primera_limite_300),'300 MiB: repetir conserva definiciones, OID, propietarios, ACL y configuración');
select qa.exige((select strpos(prosrc,'MYG_CONTENIDO_INVALIDO_MAX_300_MIB')>0
    and strpos(prosrc,'314572800')>0 and strpos(prosrc,'MYG_CONTENIDO_INVALIDO_MAX_127_MIB')=0
    from pg_proc where oid='myg_nube_privado.validar_contenido_v1(jsonb)'::regprocedure),
    '300 MiB: validador original contiene el nuevo límite');
select qa.exige((select strpos(regexp_replace(prosrc,'[[:space:]]','','g'),
    'octet_length(p_cambios::text)>314572800')>0 from pg_proc
    where oid='public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)'::regprocedure),
    '300 MiB: guardado incremental contiene el mismo límite');

with auxiliares as (
    select to_regprocedure(firma) oid from unnest(array[
        'myg_nube_privado.validar_contenido_v1(jsonb)',
        'myg_nube_privado.exigir_modulos_v1(jsonb,jsonb,jsonb)',
        'myg_nube_privado.expandir_celda(jsonb,jsonb,jsonb,text,text,boolean)',
        'myg_nube_privado.expandir_paquete(jsonb,boolean)',
        'myg_nube_privado.expandir_paquete(jsonb)',
        'myg_nube_privado.validar_contenido(jsonb)',
        'myg_nube_privado.tablas_solo_metadatos(jsonb,jsonb)',
        'myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb)',
        'myg_nube_privado.cambiar_coleccion(jsonb,jsonb,text)',
        'myg_nube_privado.aplicar_rutas(jsonb,jsonb)',
        'myg_nube_privado.aplicar_cambios(jsonb,jsonb)',
        'myg_nube_privado.reconstruir_revision(uuid,bigint)']) firma
)
select qa.exige((select count(oid)=12 from auxiliares) and not exists(
    select 1 from auxiliares f join pg_proc p on p.oid=f.oid
    cross join lateral aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
    where a.privilege_type='EXECUTE'
      and a.grantee in (0,'anon'::regrole,'authenticated'::regrole,'service_role'::regrole)),
    '300 MiB: auxiliares y respaldos permanecen privados');
select qa.exige(not has_table_privilege('authenticated','public.myg_nube_proyectos','UPDATE')
    and not has_table_privilege('authenticated','public.myg_nube_miembros','UPDATE')
    and not has_table_privilege('authenticated','myg_nube_privado.historial_cambios','INSERT'),
    '300 MiB: no habilita escritura directa en tablas');

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_capacidades()=
    '{"paquete_compacto":2,"cambios":1,"historial_intervalo":20,"max_contenido_mib":300}'::jsonb,
    '300 MiB: capacidades autentican y anuncian el límite');
reset request.jwt.claim.sub;
select qa.rechaza($$select public.myg_nube_capacidades()$$,'42501',
    '300 MiB: no acepta sesión sin identidad');
reset role;
set role anon;
select qa.rechaza($$select public.myg_nube_capacidades()$$,'42501',
    '300 MiB: anon no ejecuta capacidades');
select qa.rechaza($$select public.myg_nube_guardar_cambios(gen_random_uuid(),gen_random_uuid(),1,'{}')$$,'42501',
    '300 MiB: anon no ejecuta guardado incremental');
reset role;
select qa.rechaza($$select myg_nube_privado.validar_contenido(null)$$,'22023','300 MiB: conserva rechazo de NULL SQL');
select qa.rechaza($$select myg_nube_privado.validar_contenido('null'::jsonb)$$,'22023','300 MiB: conserva rechazo de null JSON');
select qa.rechaza($$select myg_nube_privado.validar_contenido('[]'::jsonb)$$,'22023','300 MiB: conserva rechazo de array JSON');

\if :{?MYG_PRUEBAS_BORDES300}
-- No se almacenan paquetes grandes: cada sentencia libera sus datos temporales.
-- Una comilla ocupa un byte en JSONB binario y dos en su representación textual.
-- Así se ejercita el límite textual de300MiB sin infringir el máximo binario
-- de268435455 bytes por contenedor JSONB que PostgreSQL impone por separado.
do $$ declare v jsonb; v_relleno integer; begin
    v:='{"formato":"MYG_COLABORACION","version":2,"alcance":"obra",
        "documento":{"Id":"LIMITE300-COMPACTO","Nombre":"Obra sintética"},
        "documentos":[],"recursos":[],"textos":[""],
        "tablas":[{"Nombre":"caso_codec","Columnas":["texto"],"Filas":[[["s",0]]]}]}'::jsonb;
    v_relleno:=200*1024*1024-octet_length(v::text);
    v:=jsonb_set(v,'{textos,0}',to_jsonb(repeat('"',v_relleno/2)
        ||case when v_relleno%2=1 then 'x' else '' end));
    perform qa.exige(octet_length(v::text)=200*1024*1024,'300 MiB: fixture compacto real mide200MiB textuales');
    perform myg_nube_privado.validar_contenido(v);
    perform qa.exige(true,'300 MiB: acepta paquete compacto v2 de200MiB, mayor que127MiB');
end $$;
do $$ declare v jsonb; begin
    v:=jsonb_build_object('x',repeat('"',(314572800-10)/2)||'x');
    perform qa.exige(octet_length(v::text)=314572800,'300 MiB: fixture alcanza el borde exacto');
    perform myg_nube_privado.validar_contenido(v);
    perform qa.exige(true,'300 MiB: acepta exactamente300MiB de JSONB textual');
end $$;
select qa.rechaza($$select myg_nube_privado.validar_contenido(
    jsonb_build_object('x',repeat('"',(314572800-8)/2)))$$,
    '22023','300 MiB: rechaza300MiB más un byte');
select qa.rechaza($$select jsonb_build_object('x',repeat('x',300*1024*1024))$$,
    '54000','300 MiB: identifica el límite binario independiente de PostgreSQL');
\endif

select format('PRUEBAS LIMITE300 COMPLETADAS: %s',count(*)-(select resultados_antes from qa.antes_limite_300))
    from qa.resultados;
