# Nube MYG: optimización adicional y límite de aplicación de 300 MiB

Esta entrega complementa las actualizaciones de fuentes anteriores. Conserva el
formato compacto v2, la edición colaborativa, los permisos por módulo, los
conflictos por revisión y los reintentos duraderos. No elimina datos de la base
para reducir su tamaño.

## Qué se optimiza

- JSON UTF-8 con menos escapes: las comillas de JSON guardado dentro de texto se
  escriben como `\"` en lugar de `\u0022`, y los caracteres Unicode usan su
  representación UTF-8. Se conservan comillas, barras, controles y valores exactos.
  Estos datos viajan como `application/json`; no se insertan como código HTML.
- Diccionario de textos repetidos por ahorro real, incluidos códigos y UUID. Cada
  entrada se incorpora solo si ahorra bytes después de contar todas las
  referencias, el índice final y la entrada del propio diccionario. El orden es
  estable y no se duplican textos que ya son referencias a documentos conocidos.
- El ahorro se conserva en el paquete, los adjuntos preparados, el cuerpo HTTP,
  las diferencias incrementales y la cola local de colaboración. No se cambia el
  formato general con que se guardan los documentos de la aplicación.
- El máximo de contenido de la aplicación pasa de 127 a **300 MiB** (314572800
  bytes). La lectura de respuestas permite 320 MiB para incluir metadatos. La
  profundidad JSON sigue limitada a 128 y la expansión compacta a 512 MiB.
- El cliente consulta el máximo anunciado por el servidor antes de enviar más
  de 127 MiB. Un servidor anterior muestra la actualización necesaria. Un error
  de límite interno JSONB tiene un mensaje distinto y no cierra la sesión.

El ahorro por escapes reduce el archivo JSON local y la transferencia. PostgreSQL
ya interpreta los escapes al almacenar JSONB: ese ahorro no se puede presentar
como la misma reducción del espacio físico de la nube. El diccionario cambia
además la representación almacenada; el resultado físico depende de los datos,
la compresión de PostgreSQL, los índices y el historial.

En el mismo conjunto sintético de 400 partidas y 4800 insumos de la entrega
anterior, el paquete pasó de 39810772 a 32623993 bytes (**18,05 % adicional**).
La expansión conservó el contenido semántico y la firma de datos compartidos.
En PostgreSQL 17, el texto JSONB normalizado pasó de 34736067 a 34157215 bytes;
el valor almacenado con TOAST pasó de 2873298 a 2881757 bytes (un aumento del
0,3 %). Esta medición demuestra por qué el ahorro del archivo JSON no equivale
al ahorro físico en la nube. No se ha medido el SQLite privado del usuario.

## Aplicar esta entrega

Base del código: `bimchimbote-droid/MYG.Presupuestos`, rama `main`, commit
`4ba66afdfba50b572fc077b272d86692e6fc8df6`. Este complemento presupone que ya se
aplicó la entrega anterior de 26 archivos de formato compacto e incremental.
Reemplazar archivos completos puede perder modificaciones locales o posteriores:
revise sus diferencias y respalde o confirme sus cambios primero.

1. Cierre MYG, conserve una copia de su SQLite y extraiga el ZIP fuera del
   repositorio. Copie solamente sus archivos a la raíz del repositorio local
   conservando las rutas relativas. Mantenga `.git`, los archivos no incluidos y
   la configuración de conexión existente.
2. En una consulta nueva del SQL Editor de **su proyecto Supabase**, ejecute TODO
   `supabase/migraciones/20261025_limite_300_mib.sql` como administrador. Es el único
   SQL que necesita ejecutar para esta entrega: incluye los requisitos anteriores
   si faltan, usa una sola transacción y admite repetición. No ejecuta operaciones
   sobre obras, identidades, miembros, historial ni intentos existentes.
3. La consulta debe devolver `resultado = ACTUALIZACION_300_MIB_COMPLETA`,
   `max_contenido_mib = 300`, `paquete_compacto = true` y
   `sincronizacion_incremental = true`. El aviso de recarga de esquema está
   incluido. No vuelva a ejecutar los instaladores 21, 22, 23 o 24 por separado
   después de instalar el 25: corresponden al límite anterior.
4. Restaure y compile la solución con .NET 10 y actualice la aplicación compilada
   con sus DLL dependientes. Esta entrega contiene fuentes, SQL y pruebas; no
   contiene ejecutables ni el runtime. Actualice también a los colaboradores que
   deban abrir proyectos superiores al límite de su versión anterior.
5. Reinicie MYG. Puede reintentar el pendiente existente con el máximo nuevo:
   conserva su UUID y contenido. Para beneficiarse también del nuevo diccionario
   y del tamaño JSON guardado, revise antes **Mis proyectos**; si el intento no
   fue publicado, use **Publicaciones pendientes → Retirar y conservar copia** y
   cree una publicación nueva desde el SQLite. No edite ni borre manualmente el
   archivo del pendiente ni transforme una operación que ya pudo llegar al servidor.

El instalador no modifica su Supabase desde este entorno: la ejecución del paso 2
corresponde al administrador del proyecto. Use sus mecanismos habituales de
respaldo antes de cambiar funciones.

## Qué significa el máximo de 300 MiB

Es el máximo de validación de MYG, no una cuota nueva de Supabase ni una garantía
para cualquier archivo de ese tamaño. El cliente cuenta los bytes JSON preparados;
el servidor valida el texto normalizado por PostgreSQL, que puede añadir espacios.

PostgreSQL tiene además un máximo interno de aproximadamente 256 MiB para los
datos y metadatos binarios de un contenedor JSONB. Su representación binaria puede
ser mayor o menor que el JSON textual. Por eso un JSON de 300 MiB con muchos
escapes puede caber y otro con 300 MiB de texto ASCII puede fallar antes de llamar
al validador. Ese límite está compilado en PostgreSQL y no se elimina cambiando
un número en el SQL. La aplicación identifica el código `54000` sin perder la
sesión ni el intento.

Si una base supera ese límite interno, se puede publicar una obra de la base
mediante el alcance existente. Admitir bases arbitrariamente grandes completas
requiere un almacenamiento por partes y permisos/historial sobre esas partes;
esta entrega conserva el protocolo actual. También siguen vigentes los recursos,
plazos, cuota y restricciones del servicio Supabase utilizado.

Referencias del límite interno (PostgreSQL 17):
- https://github.com/postgres/postgres/blob/REL_17_STABLE/src/include/utils/jsonb.h
- https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/utils/adt/jsonb_util.c

## Restaurar, compilar y validar

Visual Studio 2026, C#, SDK .NET 10.0.100 o compatible con `global.json`, SQLite y
Revit 2027 para el conector. Desde la raíz del repositorio:

```bash
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
```

La referencia de Revit por paquete permite compilar fuera de Revit; con Revit 2027
instalado puede utilizar las API locales según `LEEME.md`.

Para probar el SQL en PostgreSQL 17 desechable con Docker y el SDK .NET disponible:

```bash
bash scripts/pruebas/Probar-Limite300Nube.sh
```

Nunca ejecute los fixtures de `supabase/pruebas` en su Supabase real. El ejecutor
crea sus propias bases y contenedor sin puertos publicados y los elimina al
terminar. Prueba cinco estados anteriores, repetición, conservación de datos y
permisos, rechazo de tamaños, límite JSONB y reversión completa ante un error.

Resultados ejecutados del SQL: **119 comprobaciones nuevas aprobadas**, además de
134 del fixture inicial. Incluyen contenido de 200 MiB, exactamente 300 MiB de
texto JSONB, rechazo de 300 MiB más un byte y el error interno `54000` esperado.
Estas pruebas de bordes no garantizan aceptar todas las representaciones de 300
MiB: precisamente distinguen los dos límites.

La solución completa compiló con cero errores y advertencias. Pasaron las 584
comprobaciones principales de datos y los 35 grupos de nube (982 comprobaciones
principales del contrato HTTP, además de las suites especializadas).

Para repetir la integración con HTTP real en contenedores desechables:

```bash
python3 scripts/pruebas/Probar-Nube300HTTP.py
```

Esta prueba requiere Python 3, Docker y .NET. Pasaron 21 peticiones reales con
PostgreSQL 17 y PostgREST 16.5: publicación y lectura de un paquete de 134400190
bytes, superior a 127 MiB, permisos, conflicto, revocación y reintento idéntico.
El renombrado de esa publicación envió 222 bytes y recibió una confirmación de
93 bytes. Tardó unos 24 segundos en la prueba local: el envío pequeño evita
transferir la base, aunque el servidor todavía debe procesar el JSONB completo.

Para comparar dos paquetes JSON propios en PostgreSQL desechable sin red:

```bash
python3 scripts/pruebas/Medir-TamanoJSONB.py antes.json despues.json
```

Informa bytes JSON, texto normalizado y `pg_column_size` del valor almacenado,
sin imprimir contenido. La medición excluye índices, historial y otras filas.

La validación visual en Windows/Revit y la medición con su SQLite privado deben
completarse en su equipo. No se ha leído ni modificado su base real.

## Guardar el código en GitHub

Después de copiar, compilar y validar, abra **Visual Studio → Cambios de Git**.
Revise las rutas de esta entrega y confirme la rama `main`. Haga Commit y Push,
y compruebe el commit en `bimchimbote-droid/MYG.Presupuestos`. Incorpore los cambios
remotos y resuelva diferencias antes de publicar si hubiera avances posteriores;
no utilice Push forzado. La publicación del ZIP en el repositorio independiente
`bimchimbote-droid/DESCARGAS` no hace Commit ni Push del código por usted.
