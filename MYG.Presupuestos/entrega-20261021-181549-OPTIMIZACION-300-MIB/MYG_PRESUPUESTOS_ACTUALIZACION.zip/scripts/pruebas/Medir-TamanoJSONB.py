#!/usr/bin/env python3
"""Compara dos JSON en PostgreSQL 17 desechable; informa bytes, nunca contenido.

Uso: python3 scripts/pruebas/Medir-TamanoJSONB.py antes.json despues.json
Requiere Docker. El contenedor no tiene red ni puertos y se elimina al terminar.
"""
import csv
import io
import json
import pathlib
import subprocess
import sys
import time

IMAGE = "postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939"


def run(*args):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT).strip()


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    inputs = [pathlib.Path(value).resolve(strict=True) for value in sys.argv[1:]]
    exists = subprocess.run(["docker", "image", "inspect", IMAGE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if exists.returncode:
        subprocess.run(["docker", "pull", IMAGE], check=True)
    container = run("docker", "run", "--detach", "--rm", "--network", "none", "--memory=3g", "--cpus=2",
                    "--tmpfs", "/var/lib/postgresql/data:rw,size=1g", "-e", "POSTGRES_HOST_AUTH_METHOD=trust", IMAGE)
    try:
        for attempt in range(60):
            ready = subprocess.run(["docker", "exec", container, "pg_isready", "-U", "postgres"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if ready.returncode == 0:
                break
            if attempt == 59:
                raise RuntimeError("PostgreSQL no inició.")
            time.sleep(1)
        run("docker", "exec", "-u", "root", container, "mkdir", "-p", "/medicion")
        for index, path in enumerate(inputs):
            run("docker", "cp", str(path), container + ":/medicion/" + str(index) + ".json")
        run("docker", "exec", "-u", "root", container, "chmod", "-R", "a+rX", "/medicion")
        sql = """
CREATE TEMP TABLE medicion(etiqueta text, bytes_json bigint, contenido jsonb);
INSERT INTO medicion VALUES
('antes',octet_length(pg_read_file('/medicion/0.json')),pg_read_file('/medicion/0.json')::jsonb),
('despues',octet_length(pg_read_file('/medicion/1.json')),pg_read_file('/medicion/1.json')::jsonb);
SELECT etiqueta, bytes_json, octet_length(contenido::text) AS bytes_jsonb_texto,
       pg_column_size(contenido) AS bytes_jsonb_almacenado
FROM medicion ORDER BY etiqueta;
"""
        output = run("docker", "exec", "-u", "postgres", container, "psql", "-X", "-q", "--csv",
                     "-v", "ON_ERROR_STOP=1", "-c", sql)
        rows = [{key: (value if key == "etiqueta" else int(value)) for key, value in row.items()}
                for row in csv.DictReader(io.StringIO(output))]
        print(json.dumps({"postgresql": 17, "mediciones": rows,
                          "nota": "pg_column_size de valores almacenados con TOAST; excluye índices, historial, otras filas y cuota del servicio."},
                         ensure_ascii=False, indent=2))
    finally:
        subprocess.run(["docker", "rm", "-f", container], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == "__main__":
    main()
