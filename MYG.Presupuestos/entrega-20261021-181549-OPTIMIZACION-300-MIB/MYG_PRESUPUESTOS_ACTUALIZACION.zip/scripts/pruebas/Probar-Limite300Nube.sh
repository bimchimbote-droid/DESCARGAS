#!/usr/bin/env bash
# Solo PostgreSQL desechable. No conecta a Supabase ni lee bases del usuario.
set -euo pipefail
repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
test_workspace=$(mktemp -d -t myg-limite300-nube-XXXXXXXX)
test_container=""
cleanup() {
    result=$?
    trap - EXIT
    if [[ -n "$test_container" ]]; then docker rm -f "$test_container" >/dev/null 2>&1 || true; fi
    rm -rf -- "$test_workspace"
    exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
command -v docker >/dev/null
command -v dotnet >/dev/null
docker version --format '{{.Server.Version}}'
postgres_test_image='postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
if ! docker image inspect "$postgres_test_image" >/dev/null 2>&1; then docker pull "$postgres_test_image"; fi
dotnet run --project "$repo_root/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" -c Release -- "$test_workspace/paquetes"
test_container=$(docker run --detach --rm --network none --memory=4g --cpus=2 \
    --tmpfs /var/lib/postgresql/data:rw,size=2g \
    -e POSTGRES_HOST_AUTH_METHOD=trust "$postgres_test_image")
for attempt in {1..60}; do
    if docker exec "$test_container" pg_isready -U postgres >/dev/null 2>&1; then break; fi
    if [[ "$attempt" == 60 ]]; then docker logs "$test_container"; exit 1; fi
    sleep 1
done
docker exec -u root "$test_container" mkdir -p /pruebas
docker cp "$repo_root/supabase" "$test_container:/pruebas/supabase"
docker cp "$test_workspace/paquetes" "$test_container:/pruebas/paquetes"
docker exec -u root "$test_container" chmod -R a+rX /pruebas
psql_test() {
    docker exec -u postgres "$test_container" psql -X -d "$1" \
        -v MYG_PRUEBAS_DESECHABLES=1 -v ON_ERROR_STOP=1 "${@:2}"
}
psql_test postgres -f /pruebas/supabase/pruebas/usuarios_myg_roles.sql

# Base32MiB, requisito127, compacto, incremental, y yaactualizada300MiB.
for nivel in 0 1 2 3 4; do
    test_database="myg_limite300_$nivel"
    docker exec -u postgres "$test_container" createdb -U postgres -T postgres "$test_database"
    if (( nivel >= 1 )); then
        psql_test "$test_database" -f /pruebas/supabase/migraciones/20261021_contenido_grande.sql
    fi
    if (( nivel >= 2 )); then
        psql_test "$test_database" -f /pruebas/supabase/migraciones/20261022_paquete_compacto.sql
    fi
    if (( nivel >= 3 )); then
        psql_test "$test_database" -f /pruebas/supabase/migraciones/20261023_sincronizacion_incremental.sql
    fi
    if (( nivel == 4 )); then
        psql_test "$test_database" -f /pruebas/supabase/migraciones/20261025_limite_300_mib.sql
        psql_test "$test_database" -v MYG_PRUEBAS_BORDES300=1 -f /pruebas/supabase/pruebas/limite_300_mib.sql
    else
        psql_test "$test_database" -f /pruebas/supabase/pruebas/limite_300_mib.sql
    fi
    printf 'CASO LIMITE300 APROBADO: nivel previo %s\n' "$nivel"
done

# Un retorno incompatible falla avanzado el bootstrap (al instalar capacidades),
# después de actualizar tamaño y crear auxiliares. Todo debe revertirse.
docker exec -u postgres "$test_container" createdb -U postgres -T postgres myg_limite300_fallo
psql_test myg_limite300_fallo -c \
    "CREATE FUNCTION public.myg_nube_capacidades() RETURNS text LANGUAGE sql AS 'SELECT ''incompatible''::text';"
if psql_test myg_limite300_fallo -f /pruebas/supabase/migraciones/20261025_limite_300_mib.sql \
    > "$test_workspace/rechazo-esperado.log" 2>&1; then
    cat "$test_workspace/rechazo-esperado.log"
    printf 'FALLO: se aceptó una instalación con una función de retorno incompatible.\n' >&2
    exit 1
fi
case "$(cat "$test_workspace/rechazo-esperado.log")" in
    *'cannot change return type of existing function'*) ;;
    *) cat "$test_workspace/rechazo-esperado.log"; exit 1 ;;
esac
psql_test myg_limite300_fallo -c "
SELECT qa.exige((SELECT prorettype='text'::regtype FROM pg_proc
    WHERE oid='public.myg_nube_capacidades()'::regprocedure)
    AND public.myg_nube_capacidades()='incompatible',
    '300 MiB: rechazo conserva la función previa sin capacidades parciales');
SELECT qa.exige(to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)') IS NULL,
    '300 MiB: rechazo revierte la copia del validador');
SELECT qa.exige((SELECT strpos(prosrc,'MYG_CONTENIDO_INVALIDO_MAX_32_MIB')>0
    FROM pg_proc WHERE oid='myg_nube_privado.validar_contenido(jsonb)'::regprocedure),
    '300 MiB: rechazo revierte los límites y conserva el validador inicial');"
printf 'LIMITE300 COMPLETADO: cinco estados, bordes reales y rollback aprobados.\n'
