#!/usr/bin/env python3
"""Prueba HTTP real con datos sintéticos y contenedores desechables.

Requiere Python 3, Docker y el SDK .NET del repositorio. No conecta a Supabase,
no lee bases del usuario y no publica puertos. Ejecutar desde cualquier carpeta.
"""

import base64
import copy
import hashlib
import hmac
import json
import pathlib
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid


REPO = pathlib.Path(__file__).resolve().parents[2]
POSTGRES = "postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939"
POSTGREST = "postgrest/postgrest:v16.5@sha256:1347d7552b88f17832912c06afbf7c43209af6eeeb60834b04aae12c9bd9d5cc"
SECRET = b"myg_synthetic_http_300_test_secret_not_a_real_credential"
OWNER = "00000000-0000-0000-0000-000000000001"
EDITOR = "00000000-0000-0000-0000-000000000003"
SMALL_PROJECT = "94000000-0000-0000-0000-000000000001"
LARGE_PROJECT = "94000000-0000-0000-0000-000000000002"


def run(*args, log=None):
    result = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if log is not None:
        log.write(result.stdout)
        log.flush()
    if result.returncode:
        # No volcar cuerpos HTTP ni paquetes en errores.
        raise RuntimeError(f"Falló {args[0]} ({result.returncode}): {result.stdout[-1500:]}")
    return result.stdout.strip()


def token(user):
    def b64(value):
        return base64.urlsafe_b64encode(value).rstrip(b"=")

    header = b64(b'{"alg":"HS256","typ":"JWT"}')
    claims = b64(json.dumps({"role": "authenticated", "sub": user, "exp": int(time.time()) + 3600}).encode())
    body = header + b"." + claims
    return (body + b"." + b64(hmac.new(SECRET, body, hashlib.sha256).digest())).decode()


def patch(path, value):
    return {"version": 2, "operaciones": [{"ruta": path, "valor": value}]}


def main():
    suffix = uuid.uuid4().hex[:12]
    network, database, api = ("myg-http300-" + suffix + name for name in ("-red", "-pg", "-api"))
    created_network = False
    containers = []
    requests = 0
    measurements = []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    try:
        with tempfile.TemporaryDirectory(prefix="myg-http300-") as temporary:
            temporary = pathlib.Path(temporary)
            with (temporary / "preparacion.log").open("w") as log:
                for image in (POSTGRES, POSTGREST):
                    exists = subprocess.run(["docker", "image", "inspect", image], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    if exists.returncode:
                        run("docker", "pull", image, log=log)
                packages = temporary / "paquetes"
                run("dotnet", "run", "--project", str(REPO / "supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj"),
                    "-c", "Release", "--", str(packages), log=log)
                run("docker", "network", "create", "--internal", network, log=log)
                created_network = True
                run("docker", "run", "--detach", "--rm", "--name", database,
                    "--network", network, "--memory=6g", "--cpus=2",
                    "--tmpfs", "/var/lib/postgresql/data:rw,size=2g",
                    "-e", "POSTGRES_HOST_AUTH_METHOD=trust", POSTGRES, log=log)
                containers.append(database)
                for attempt in range(60):
                    ready = subprocess.run(["docker", "exec", database, "pg_isready", "-U", "postgres"],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    if ready.returncode == 0:
                        break
                    if attempt == 59:
                        raise RuntimeError("PostgreSQL desechable no inició.")
                    time.sleep(1)
                run("docker", "exec", "-u", "root", database, "mkdir", "-p", "/pruebas", log=log)
                run("docker", "cp", str(REPO / "supabase"), database + ":/pruebas/supabase", log=log)
                run("docker", "cp", str(packages), database + ":/pruebas/paquetes", log=log)
                run("docker", "exec", "-u", "root", database, "chmod", "-R", "a+rX", "/pruebas", log=log)

                def sql(*args):
                    return run("docker", "exec", "-u", "postgres", database, "psql", "-X",
                               "-v", "ON_ERROR_STOP=1", "-v", "MYG_PRUEBAS_DESECHABLES=1", *args, log=log)

                sql("-f", "/pruebas/supabase/pruebas/usuarios_myg_roles.sql")
                sql("-f", "/pruebas/supabase/migraciones/20261025_limite_300_mib.sql")
                # Adaptación exclusiva del fixture: PostgREST16 transmite claims JSON.
                sql("-c", """
                    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
                      SELECT coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub',
                        nullif(current_setting('request.jwt.claim.sub',true),''))::uuid;
                    $$;
                    CREATE ROLE myg_http_login LOGIN NOINHERIT;
                    GRANT anon,authenticated TO myg_http_login;
                    """)
                run("docker", "run", "--detach", "--rm", "--name", api, "--network", network,
                    "--memory=2g", "--cpus=2",
                    "-e", f"PGRST_DB_URI=postgres://myg_http_login@{database}:5432/postgres",
                    "-e", "PGRST_DB_SCHEMAS=public", "-e", "PGRST_DB_ANON_ROLE=anon",
                    "-e", "PGRST_JWT_SECRET=" + SECRET.decode(), POSTGREST, log=log)
                containers.append(api)
                address = run("docker", "inspect", api, "--format", "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}")
                url = f"http://{address}:3000/"
                for attempt in range(60):
                    try:
                        with opener.open(url, timeout=2) as response:
                            if response.status == 200:
                                break
                    except (urllib.error.URLError, TimeoutError):
                        pass
                    if attempt == 59:
                        raise RuntimeError("PostgREST desechable no inició.")
                    time.sleep(1)

                def rpc(name, body, user=OWNER, expected=200):
                    nonlocal requests
                    data = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode()
                    headers = {"Content-Type": "application/json"}
                    if user:
                        headers["Authorization"] = "Bearer " + token(user)
                    started = time.monotonic()
                    request = urllib.request.Request(url + "rpc/" + name, data=data, headers=headers, method="POST")
                    try:
                        with opener.open(request, timeout=180) as response:
                            status, content = response.status, response.read()
                    except urllib.error.HTTPError as error:
                        status, content = error.code, error.read()
                    if status != expected:
                        # El cuerpo podría ser grande; solo mostrar código, nunca el contenido.
                        try:
                            code = json.loads(content).get("code", "sin código")
                        except (ValueError, AttributeError):
                            code = "respuesta no JSON"
                        raise AssertionError(f"{name}: HTTP {status}, esperado {expected}, código {code}")
                    requests += 1
                    elapsed = round(time.monotonic() - started, 3)
                    measurements.append({"rpc": name, "status": status, "request_bytes": len(data),
                                         "response_bytes": len(content), "seconds": elapsed})
                    print(f"OK HTTP {status} {name}: {len(data)} -> {len(content)} bytes; {elapsed}s", flush=True)
                    return json.loads(content), len(data), len(content)

                capabilities, _, _ = rpc("myg_nube_capacidades", {})
                assert capabilities == {"paquete_compacto": 2, "cambios": 1, "historial_intervalo": 20, "max_contenido_mib": 300}
                rpc("myg_nube_capacidades", {}, user=None, expected=401)
                baseline = json.loads((packages / "compacto_cliente.json").read_text())
                created, _, _ = rpc("myg_nube_crear", {"p_id": SMALL_PROJECT, "p_nombre": "HTTP compacto sintético",
                                                       "p_contenido": baseline, "p_alcance": "base"})
                assert created["revision"] == 1 and created["contenido"] == baseline
                revision, _, _ = rpc("myg_nube_revision", {"p_id": SMALL_PROJECT})
                assert revision["revision"] == 1 and "contenido" not in revision
                rename = patch(["documento", "Nombre"], "RENOMBRADA HTTP QA")
                operation = "95000000-0000-0000-0000-000000000001"
                request = {"p_id": SMALL_PROJECT, "p_operacion": operation, "p_revision": 1, "p_cambios": rename}
                ack, _, _ = rpc("myg_nube_guardar_cambios", request)
                assert ack == {"estado": "aplicada", "revision": 2, "operacion_id": operation}
                replay, _, _ = rpc("myg_nube_guardar_cambios", request)
                assert replay == ack
                opened, _, _ = rpc("myg_nube_abrir", {"p_id": SMALL_PROJECT})
                assert opened["revision"] == 2 and opened["contenido"]["documento"]["Nombre"] == "RENOMBRADA HTTP QA"
                rpc("myg_nube_compartir_usuario", {"p_id": SMALL_PROJECT, "p_usuario_myg": "editor", "p_rol": "editor",
                                                  "p_permisos_modulos": {"acu": False, "especificaciones": True, "metrados_excel": False}})
                blocked, _, _ = rpc("myg_nube_guardar_cambios", {"p_id": SMALL_PROJECT,
                    "p_operacion": "95000000-0000-0000-0000-000000000002", "p_revision": 2,
                    "p_cambios": patch(["documento", "Presupuestos", "0", "Items", "0", "Costos", "PrecioDirecto"], 999)},
                    user=EDITOR, expected=403)
                assert blocked["code"] == "42501"
                spec_request = {"p_id": SMALL_PROJECT, "p_operacion": "95000000-0000-0000-0000-000000000003", "p_revision": 2,
                    "p_cambios": patch(["documento", "Presupuestos", "0", "Items", "0", "Costos", "EspecificacionTexto"], "Especificación permitida HTTP")}
                ack2, _, _ = rpc("myg_nube_guardar_cambios", spec_request, user=EDITOR)
                assert ack2["estado"] == "aplicada" and ack2["revision"] == 3
                repeated, _, _ = rpc("myg_nube_guardar_cambios", spec_request, user=EDITOR)
                assert repeated == ack2
                conflict, _, _ = rpc("myg_nube_guardar_cambios", {"p_id": SMALL_PROJECT,
                    "p_operacion": "95000000-0000-0000-0000-000000000004", "p_revision": 1, "p_cambios": rename})
                assert conflict["estado"] == "conflicto" and conflict["revision"] == 3
                rpc("myg_nube_rol", {"p_id": SMALL_PROJECT, "p_usuario": EDITOR, "p_rol": None})
                rpc("myg_nube_revision", {"p_id": SMALL_PROJECT}, user=EDITOR, expected=403)

                # El cuerpo completo supera127MiB: prueba POST, JSONB, respuesta y lectura reales.
                large = copy.deepcopy(baseline)
                payload = "x" * (128 * 1024 * 1024)
                large["documento"]["CampoGrandePrueba"] = payload
                package_bytes = len(json.dumps(large, ensure_ascii=False, separators=(",", ":")).encode())
                assert 127 * 1024 * 1024 < package_bytes < 300 * 1024 * 1024
                created, upload_bytes, create_response = rpc("myg_nube_crear", {"p_id": LARGE_PROJECT,
                    "p_nombre": "HTTP base sintética mayor de127MiB", "p_contenido": large, "p_alcance": "base"})
                assert created["revision"] == 1 and created["contenido"] == large
                del created
                metadata, _, metadata_bytes = rpc("myg_nube_revision", {"p_id": LARGE_PROJECT})
                assert metadata["revision"] == 1 and "contenido" not in metadata and metadata_bytes < 1024
                opened, _, open_response = rpc("myg_nube_abrir", {"p_id": LARGE_PROJECT})
                assert opened["revision"] == 1 and opened["contenido"] == large
                del opened
                big_operation = "95000000-0000-0000-0000-000000000005"
                big_request = {"p_id": LARGE_PROJECT, "p_operacion": big_operation, "p_revision": 1,
                    "p_cambios": patch(["documento", "Nombre"], "BASE GRANDE RENOMBRADA")}
                ack_large, delta_bytes, ack_bytes = rpc("myg_nube_guardar_cambios", big_request)
                assert ack_large == {"estado": "aplicada", "revision": 2, "operacion_id": big_operation}
                assert delta_bytes < 512 and ack_bytes < 512
                replay_large, _, _ = rpc("myg_nube_guardar_cambios", big_request)
                assert replay_large == ack_large
                metadata, _, _ = rpc("myg_nube_revision", {"p_id": LARGE_PROJECT})
                assert metadata["revision"] == 2 and "contenido" not in metadata
                opened, _, final_response = rpc("myg_nube_abrir", {"p_id": LARGE_PROJECT})
                large["documento"]["Nombre"] = "BASE GRANDE RENOMBRADA"
                assert opened["revision"] == 2 and opened["contenido"] == large
                print(json.dumps({"status": "passed", "checks_http": requests, "postgres": "17", "postgrest": "16.5",
                    "large_package_bytes": package_bytes, "large_request_bytes": upload_bytes,
                    "large_create_response_bytes": create_response, "large_open_response_bytes": open_response,
                    "large_final_response_bytes": final_response, "large_rename_request_bytes": delta_bytes,
                    "large_rename_ack_bytes": ack_bytes, "large_revision_response_bytes": metadata_bytes,
                    "requests": measurements}, indent=2), flush=True)
    finally:
        for name in reversed(containers):
            subprocess.run(["docker", "rm", "-f", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if created_network:
            subprocess.run(["docker", "network", "rm", network], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == "__main__":
    main()
