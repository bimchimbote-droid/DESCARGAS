#nullable enable
using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace MYG.Colaboracion;

/// <summary>Cliente del piloto DEMO. Las credenciales y sesiones permanecen solo en memoria.</summary>
public sealed partial class ClienteSupabase : IDisposable
{
    private const string ProyectoId = "MYG-DEMO-COLABORACION";
    private const string PresupuestoId = "MYG-DEMO-PRESUPUESTO";
    private const string PartidaId = "MYG-DEMO-PARTIDA";
    private const int MaxRespuestaBytes = 256 * 1024;
    private readonly HttpClient _http;
    private readonly string _clave;
    private readonly TimeProvider _reloj;
    private readonly SemaphoreSlim _exclusion = new(1, 1);
    private readonly object _estadoSesion = new();
    private readonly CancellationTokenSource _vida = new();
    private readonly CancellationToken _vidaToken;
    private Sesion? _sesion;
    private int _dispuesto;

    private sealed record Sesion(string Acceso, string Refresco, string Usuario,
        DateTimeOffset Expira, DateTimeOffset RefrescarDesde, string? UsuarioMyg = null);

    public ClienteSupabase(string url, string clavePublicable,
        HttpMessageHandler? handler = null, TimeProvider? reloj = null)
    {
        Uri destino = ValidarUrl(url);
        ValidarClave(clavePublicable);
        _clave = clavePublicable;
        _reloj = reloj ?? TimeProvider.System;
        _vidaToken = _vida.Token;
        handler ??= new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false };
        _http = new HttpClient(handler, disposeHandler: true)
        {
            BaseAddress = destino,
            Timeout = Timeout.InfiniteTimeSpan
        };
    }

    public bool SesionIniciada => Volatile.Read(ref _dispuesto) == 0 && Volatile.Read(ref _sesion) is not null;
    public string? UsuarioId => Volatile.Read(ref _dispuesto) == 0 ? Volatile.Read(ref _sesion)?.Usuario : null;
    public string? UsuarioMygSesion => Volatile.Read(ref _dispuesto) == 0 ? Volatile.Read(ref _sesion)?.UsuarioMyg : null;

    public async Task IniciarSesionAsync(string correo, string contrasena, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(correo) || string.IsNullOrEmpty(contrasena))
            throw new NubeException("Introduzca el correo y la contraseña de la cuenta de prueba.");
        await EjecutarAsync(async token =>
        {
            LimpiarSesion();
            var cuerpo = JsonSerializer.SerializeToUtf8Bytes(new { email = correo.Trim(), password = contrasena });
            using var respuesta = await EnviarAsync(HttpMethod.Post,
                "auth/v1/token?grant_type=password", cuerpo, acceso: null, token);
            if (!respuesta.IsSuccessStatusCode)
            {
                await LanzarErrorAsync(respuesta, autenticacion: true, token);
            }
            PublicarSesion(await LeerSesionAsync(respuesta, token));
            return true;
        }, ct);
    }

    public Task<PartidaNube> LeerPartidaAsync(CancellationToken ct = default) =>
        EjecutarAsync(async token =>
        {
            const string ruta = "rest/v1/myg_partidas?select=descripcion,unidad,cantidad,revision_nube"
                + "&proyecto_id=eq." + ProyectoId
                + "&presupuesto_id=eq." + PresupuestoId
                + "&id=eq." + PartidaId + "&eliminado=eq.false";
            using var respuesta = await EnviarConSesionAsync(HttpMethod.Get, ruta, null, token);
            using var json = await LeerJsonAsync(respuesta, token);
            JsonElement raiz = json.RootElement;
            if (raiz.ValueKind != JsonValueKind.Array)
                throw RespuestaInvalida();
            if (raiz.GetArrayLength() == 0)
                throw new NubeException("La cuenta no puede ver la partida DEMO. Compruebe el proyecto de prueba y sus miembros.");
            if (raiz.GetArrayLength() != 1)
                throw RespuestaInvalida();
            JsonElement partida = raiz[0];
            string descripcion = LeerTexto(partida, "descripcion");
            string unidad = LeerTexto(partida, "unidad");
            decimal cantidad = LeerCantidad(partida, "cantidad");
            long revision = LeerRevision(partida, "revision_nube");
            return new PartidaNube(descripcion, unidad, cantidad, revision);
        }, ct);

    public Task<ResultadoCantidad> GuardarCantidadAsync(OperacionCantidad op, CancellationToken ct = default)
    {
        if (op is null || op.Id == Guid.Empty || op.RevisionBase < 1)
            throw new NubeException("La operación pendiente necesita un identificador y una revisión válidos.");
        if (!CantidadValida(op.Cantidad))
            throw new NubeException("Introduzca una cantidad entre 0 y 1000000000000, con un máximo de dos decimales.");
        return EjecutarAsync(async token =>
        {
            // Estos mismos bytes y el mismo UUID se conservan también al renovar la sesión.
            byte[] cuerpo = JsonSerializer.SerializeToUtf8Bytes(new
            {
                p_proyecto_id = ProyectoId,
                p_presupuesto_id = PresupuestoId,
                p_partida_id = PartidaId,
                p_revision_base = op.RevisionBase,
                p_cantidad = op.Cantidad,
                p_operacion_id = op.Id
            });
            using var respuesta = await EnviarConSesionAsync(HttpMethod.Post,
                "rest/v1/rpc/myg_cambiar_cantidad", cuerpo, token);
            using var json = await LeerJsonAsync(respuesta, token);
            JsonElement raiz = json.RootElement;
            if (raiz.ValueKind != JsonValueKind.Object)
                throw RespuestaInvalida();
            ValidarIdentificadorSiExiste(raiz, "proyecto_id", ProyectoId);
            ValidarIdentificadorSiExiste(raiz, "presupuesto_id", PresupuestoId);
            ValidarIdentificadorSiExiste(raiz, "partida_id", PartidaId);
            if (raiz.TryGetProperty("operacion_id", out var operacion)
                && (operacion.ValueKind != JsonValueKind.String
                    || !Guid.TryParse(operacion.GetString(), out Guid id) || id != op.Id))
                throw RespuestaInvalida();
            string estado = LeerTexto(raiz, "estado");
            if (estado == "aplicada")
                return new ResultadoCantidad(false, LeerCantidad(raiz, "cantidad"), LeerRevision(raiz, "revision_nube"));
            if (estado == "conflicto")
                return new ResultadoCantidad(true, LeerCantidad(raiz, "cantidad_actual"), LeerRevision(raiz, "revision_actual"));
            throw RespuestaInvalida();
        }, ct);
    }

    public async Task CerrarSesionAsync(CancellationToken ct = default)
    {
        try
        {
            await EjecutarAsync(async token =>
            {
                Sesion? sesion = Volatile.Read(ref _sesion);
                try
                {
                    if (sesion is not null)
                    {
                        using var respuesta = await EnviarAsync(HttpMethod.Post,
                            "auth/v1/logout?scope=local", null, sesion.Acceso, token);
                        // Una sesión ya rechazada tampoco debe impedir el cierre local.
                        if (!respuesta.IsSuccessStatusCode
                            && respuesta.StatusCode != HttpStatusCode.Unauthorized
                            && respuesta.StatusCode != HttpStatusCode.Forbidden)
                            await LanzarErrorAsync(respuesta, autenticacion: false, token);
                    }
                    return true;
                }
                finally { LimpiarSesion(); }
            }, ct);
        }
        finally { LimpiarSesion(); }
    }

    private async Task<T> EjecutarAsync<T>(Func<CancellationToken, Task<T>> accion, CancellationToken ct,
        TimeSpan? plazo = null)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _dispuesto) != 0, this);
        // Incluye la lectura del cuerpo; HttpClient con ResponseHeadersRead no la limita.
        using var limite = new CancellationTokenSource(plazo ?? TimeSpan.FromSeconds(40), _reloj);
        using var unidos = CancellationTokenSource.CreateLinkedTokenSource(ct, _vidaToken, limite.Token);
        bool adquirido = false;
        try
        {
            await _exclusion.WaitAsync(unidos.Token);
            adquirido = true;
            ObjectDisposedException.ThrowIf(Volatile.Read(ref _dispuesto) != 0, this);
            return await accion(unidos.Token);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested && !_vidaToken.IsCancellationRequested)
        {
            throw new NubeException("La conexión tardó demasiado. Puede reintentar la misma operación pendiente.", esErrorDeConexion: true);
        }
        catch (HttpRequestException)
        {
            throw new NubeException("No se pudo confirmar la comunicación con Supabase. Revise Internet y reintente la misma operación pendiente.", esErrorDeConexion: true);
        }
        catch (IOException)
        {
            throw new NubeException("La conexión se interrumpió. Reintente la misma operación pendiente.", esErrorDeConexion: true);
        }
        finally
        {
            if (adquirido) _exclusion.Release();
        }
    }

    private async Task<HttpResponseMessage> EnviarConSesionAsync(HttpMethod metodo, string ruta,
        byte[]? cuerpo, CancellationToken ct, bool nube = false, string tipoContenido = "application/json")
    {
        Sesion sesion = await AsegurarSesionAsync(forzarRefresco: false, ct, nube);
        HttpResponseMessage respuesta = await EnviarAsync(metodo, ruta, cuerpo, sesion.Acceso, ct, tipoContenido);
        if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
        {
            respuesta.Dispose();
            sesion = await AsegurarSesionAsync(forzarRefresco: true, ct, nube);
            respuesta = await EnviarAsync(metodo, ruta, cuerpo, sesion.Acceso, ct, tipoContenido);
        }
        if (respuesta.IsSuccessStatusCode) return respuesta;
        try
        {
            if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
            {
                LimpiarSesion();
                throw new NubeException("La sesión ya no es válida. Inicie sesión de nuevo para continuar.", necesitaIniciarSesion: true);
            }
            await LanzarErrorAsync(respuesta, autenticacion: false, ct, nube);
            throw nube ? RespuestaNubeInvalida() : RespuestaInvalida();
        }
        finally { respuesta.Dispose(); }
    }

    private async Task<Sesion> AsegurarSesionAsync(bool forzarRefresco, CancellationToken ct, bool nube = false)
    {
        Sesion? anterior = Volatile.Read(ref _sesion);
        if (anterior is null)
            throw new NubeException(nube ? "Inicie sesión para consultar o modificar los proyectos en la nube."
                : "Inicie sesión para consultar o modificar la partida DEMO.", necesitaIniciarSesion: true);
        if (!forzarRefresco && _reloj.GetUtcNow() < anterior.RefrescarDesde)
            return anterior;
        byte[] cuerpo = JsonSerializer.SerializeToUtf8Bytes(new { refresh_token = anterior.Refresco });
        using var respuesta = await EnviarAsync(HttpMethod.Post,
            "auth/v1/token?grant_type=refresh_token", cuerpo, acceso: null, ct);
        if (!respuesta.IsSuccessStatusCode)
            await LanzarErrorAsync(respuesta, autenticacion: true, ct);
        Sesion nueva = await LeerSesionAsync(respuesta, ct);
        if (nueva.Usuario != anterior.Usuario)
        {
            LimpiarSesion();
            throw new NubeException("Cambió la identidad de la sesión. Inicie sesión de nuevo.", necesitaIniciarSesion: true);
        }
        nueva = nueva with { UsuarioMyg = anterior.UsuarioMyg };
        PublicarSesion(nueva);
        return nueva;
    }

    private async Task<HttpResponseMessage> EnviarAsync(HttpMethod metodo, string ruta,
        byte[]? cuerpo, string? acceso, CancellationToken ct, string tipoContenido = "application/json")
    {
        using var solicitud = new HttpRequestMessage(metodo, ruta);
        solicitud.Headers.Add("apikey", _clave);
        solicitud.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        if (acceso is not null)
            solicitud.Headers.Authorization = new AuthenticationHeaderValue("Bearer", acceso);
        if (cuerpo is not null)
        {
            solicitud.Content = new ByteArrayContent(cuerpo);
            solicitud.Content.Headers.ContentType = new MediaTypeHeaderValue(tipoContenido);
            if (tipoContenido == "application/json") solicitud.Content.Headers.ContentType.CharSet = "utf-8";
        }
        return await _http.SendAsync(solicitud, HttpCompletionOption.ResponseHeadersRead, ct);
    }

    private async Task<Sesion> LeerSesionAsync(HttpResponseMessage respuesta, CancellationToken ct,
        string? usuarioMygEsperado = null)
    {
        try
        {
            using var json = await LeerJsonAsync(respuesta, ct);
            JsonElement raiz = json.RootElement;
            string acceso = LeerTexto(raiz, "access_token");
            string refresco = LeerTexto(raiz, "refresh_token");
            if (usuarioMygEsperado is not null
                && LeerTexto(raiz, "usuario_myg") != usuarioMygEsperado)
                throw RespuestaInvalida();
            if (!TokenValido(acceso) || !TokenValido(refresco)
                || !raiz.TryGetProperty("user", out var usuario)
                || !Guid.TryParse(LeerTexto(usuario, "id"), out Guid id) || id == Guid.Empty)
                throw RespuestaInvalida();
            DateTimeOffset ahora = _reloj.GetUtcNow();
            DateTimeOffset expira;
            if (raiz.TryGetProperty("expires_in", out var duracion)
                && duracion.ValueKind == JsonValueKind.Number && duracion.TryGetInt64(out long segundos)
                && segundos > 0 && segundos <= 31_536_000)
                expira = ahora.AddSeconds(segundos);
            else if (raiz.TryGetProperty("expires_at", out var instante)
                && instante.ValueKind == JsonValueKind.Number && instante.TryGetInt64(out long unix))
                expira = DateTimeOffset.FromUnixTimeSeconds(unix);
            else throw RespuestaInvalida();
            if (expira <= ahora) throw RespuestaInvalida();
            double margen = Math.Min(60, (expira - ahora).TotalSeconds / 10);
            return new Sesion(acceso, refresco, id.ToString("D"), expira, expira.AddSeconds(-margen), usuarioMygEsperado);
        }
        catch (NubeException)
        {
            LimpiarSesion();
            throw new NubeException("La respuesta de autenticación no es válida. Inicie sesión de nuevo.", necesitaIniciarSesion: true);
        }
        catch (ArgumentOutOfRangeException)
        {
            LimpiarSesion();
            throw new NubeException("La respuesta de autenticación no es válida. Inicie sesión de nuevo.", necesitaIniciarSesion: true);
        }
    }

    private async Task LanzarErrorAsync(HttpResponseMessage respuesta, bool autenticacion, CancellationToken ct,
        bool nube = false)
    {
        int estado = (int)respuesta.StatusCode;
        // PostgREST devuelve algunos errores SQL conocidos (por ejemplo 54000)
        // con HTTP 500. La nube debe leer su código antes del fallback transitorio;
        // autenticación y DEMO conservan su tratamiento anterior.
        if (nube && !autenticacion)
        {
            await LanzarErrorNubeAsync(respuesta, ct);
            return;
        }
        if (estado >= 500 || estado == 408 || estado == 429)
            throw new NubeException("Supabase no pudo confirmar la solicitud. Espere un momento y reintente la misma operación pendiente.", esErrorDeConexion: true);
        if (autenticacion)
        {
            bool ingresoMyg = Volatile.Read(ref _sesion)?.UsuarioMyg is not null;
            LimpiarSesion();
            throw new NubeException(ingresoMyg
                ? "La sesión de nube ya no es válida. Abra Nube MYG y reintente la conexión con su usuario MYG."
                : "No se pudo validar la sesión. Compruebe el correo y la contraseña e inicie sesión de nuevo.", necesitaIniciarSesion: true);
        }
        // Solo se reconocen códigos conocidos; nunca se presenta el cuerpo del servidor.
        string? codigo = null;
        try
        {
            using var json = await LeerJsonAsync(respuesta, ct);
            if (json.RootElement.ValueKind == JsonValueKind.Object
                && json.RootElement.TryGetProperty("code", out var valor)
                && valor.ValueKind == JsonValueKind.String)
                codigo = valor.GetString();
        }
        catch (NubeException) { }
        if (codigo == "40001")
            throw new NubeException("Otro cambio coincidió con la solicitud. Reintente la misma operación pendiente.", esErrorDeConexion: true);
        if (codigo == "42501" || respuesta.StatusCode == HttpStatusCode.Forbidden)
            throw new NubeException("La cuenta no tiene permiso para esta operación. Compruebe sus miembros y rol en el proyecto DEMO.");
        if (codigo == "22023")
            throw new NubeException("La función rechazó los datos. Compruebe la cantidad, la revisión y que usa la partida del proyecto DEMO.");
        if (codigo is "PGRST202" or "42883")
            throw new NubeException("No está disponible la función de edición DEMO. Compruebe el paso 4 en Supabase.");
        if (codigo == "42P01")
            throw new NubeException("No están disponibles las tablas DEMO. Compruebe la instalación en Supabase.");
        throw new NubeException($"Supabase rechazó la solicitud (HTTP {estado}). Compruebe la configuración del piloto DEMO.");
    }

    private static async Task<JsonDocument> LeerJsonAsync(HttpResponseMessage respuesta, CancellationToken ct,
        int maxBytes = MaxRespuestaBytes, int maxDepth = 32, bool nube = false)
    {
        if (respuesta.Content.Headers.ContentLength is long longitud && longitud > maxBytes)
            throw nube ? RespuestaNubeInvalida() : RespuestaInvalida();
        using Stream flujo = await respuesta.Content.ReadAsStreamAsync(ct);
        using var buffer = new MemoryStream();
        byte[] bloque = new byte[8192];
        while (true)
        {
            int leidos = await flujo.ReadAsync(bloque.AsMemory(), ct);
            if (leidos == 0) break;
            if (buffer.Length + leidos > maxBytes) throw nube ? RespuestaNubeInvalida() : RespuestaInvalida();
            buffer.Write(bloque, 0, leidos);
        }
        try
        {
            return JsonDocument.Parse(buffer.GetBuffer().AsMemory(0, checked((int)buffer.Length)),
                new JsonDocumentOptions { MaxDepth = maxDepth });
        }
        catch (JsonException) { throw nube ? RespuestaNubeInvalida() : RespuestaInvalida(); }
    }

    private static string LeerTexto(JsonElement objeto, string nombre)
    {
        if (objeto.ValueKind != JsonValueKind.Object || !objeto.TryGetProperty(nombre, out var valor)
            || valor.ValueKind != JsonValueKind.String || valor.GetString() is not string texto)
            throw RespuestaInvalida();
        return texto;
    }

    private static decimal LeerCantidad(JsonElement objeto, string nombre)
    {
        if (objeto.ValueKind != JsonValueKind.Object || !objeto.TryGetProperty(nombre, out var valor)
            || valor.ValueKind != JsonValueKind.Number || !valor.TryGetDecimal(out decimal cantidad)
            || !CantidadValida(cantidad))
            throw RespuestaInvalida();
        return cantidad;
    }

    private static long LeerRevision(JsonElement objeto, string nombre)
    {
        if (objeto.ValueKind != JsonValueKind.Object || !objeto.TryGetProperty(nombre, out var valor)
            || valor.ValueKind != JsonValueKind.Number || !valor.TryGetInt64(out long revision) || revision < 1)
            throw RespuestaInvalida();
        return revision;
    }

    private static void ValidarIdentificadorSiExiste(JsonElement objeto, string nombre, string esperado)
    {
        if (objeto.TryGetProperty(nombre, out var valor)
            && (valor.ValueKind != JsonValueKind.String || valor.GetString() != esperado))
            throw RespuestaInvalida();
    }

    private static bool CantidadValida(decimal cantidad) =>
        cantidad >= 0 && cantidad <= 1_000_000_000_000m && decimal.Round(cantidad, 2) == cantidad;

    private static bool TokenValido(string token) =>
        token.Length is > 0 and <= 32768 && !token.Any(char.IsWhiteSpace) && !token.Any(char.IsControl);

    private static NubeException RespuestaInvalida() => new(
        "La respuesta de Supabase no tiene el formato esperado. Conserve la operación pendiente y compruebe los pasos del piloto.",
        esErrorDeConexion: true);

    private static Uri ValidarUrl(string url)
    {
        if (string.IsNullOrWhiteSpace(url) || !Uri.TryCreate(url, UriKind.Absolute, out var uri)
            || uri.Scheme != Uri.UriSchemeHttps || !uri.IsDefaultPort
            || !string.IsNullOrEmpty(uri.UserInfo) || !string.IsNullOrEmpty(uri.Query)
            || !string.IsNullOrEmpty(uri.Fragment) || uri.AbsolutePath != "/"
            || !uri.Host.EndsWith(".supabase.co", StringComparison.OrdinalIgnoreCase)
            || uri.Host.Length <= ".supabase.co".Length
            || uri.HostNameType != UriHostNameType.Dns
            || uri.Host.Any(c => !(char.IsAsciiLetterOrDigit(c) || c is '.' or '-')))
            throw new NubeException("Use la URL HTTPS del proyecto Supabase, sin rutas, parámetros ni credenciales.");
        return new Uri(uri.GetLeftPart(UriPartial.Authority) + "/");
    }

    private static void ValidarClave(string clave)
    {
        const string mensaje = "Use únicamente la clave publicable del proyecto o su clave anon anterior. No utilice claves secretas.";
        if (string.IsNullOrEmpty(clave) || clave.Length > 32768
            || clave.Any(char.IsWhiteSpace) || clave.Any(char.IsControl)
            || clave.StartsWith("sb_secret_", StringComparison.Ordinal))
            throw new NubeException(mensaje);
        if (clave.StartsWith("sb_publishable_", StringComparison.Ordinal)
            && clave.Length > "sb_publishable_".Length
            && clave.All(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_'))
            return;
        string[] partes = clave.Split('.');
        if (partes.Length != 3 || partes.Any(p => p.Length == 0
            || !p.All(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_')))
            throw new NubeException(mensaje);
        try
        {
            string payload = partes[1].Replace('-', '+').Replace('_', '/');
            payload = payload.PadRight((payload.Length + 3) / 4 * 4, '=');
            using var json = JsonDocument.Parse(Convert.FromBase64String(payload));
            if (json.RootElement.ValueKind == JsonValueKind.Object
                && json.RootElement.TryGetProperty("role", out var rol)
                && rol.ValueKind == JsonValueKind.String && rol.GetString() == "anon")
                return;
        }
        catch (FormatException) { }
        catch (JsonException) { }
        throw new NubeException(mensaje);
    }

    private void PublicarSesion(Sesion sesion)
    {
        lock (_estadoSesion)
        {
            ObjectDisposedException.ThrowIf(Volatile.Read(ref _dispuesto) != 0, this);
            Volatile.Write(ref _sesion, sesion);
        }
    }

    private void LimpiarSesion()
    {
        lock (_estadoSesion) Volatile.Write(ref _sesion, null);
    }

    public void Dispose()
    {
        if (Interlocked.Exchange(ref _dispuesto, 1) != 0) return;
        LimpiarSesion();
        _vida.Cancel();
        _http.Dispose();
        _vida.Dispose();
        // El semáforo queda vivo para que una solicitud cancelada pueda liberarlo.
    }
}
