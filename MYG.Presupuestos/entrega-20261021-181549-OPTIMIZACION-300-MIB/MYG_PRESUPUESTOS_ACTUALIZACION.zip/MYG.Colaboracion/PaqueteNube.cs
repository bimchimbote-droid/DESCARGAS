using System.Globalization;
using System.IO.Compression;
using System.Text.Encodings.Web;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>Contenido portable JSONB. Nunca transporta una copia binaria indiscriminada de la hoja.</summary>
public static class PaqueteNube
{
    // Se transporta como application/json, nunca como código insertado en HTML.
    // Conserva los caracteres originales sin multiplicar comillas y Unicode.
    private static readonly JsonSerializerOptions Json = new()
    {
        PropertyNameCaseInsensitive = true, MaxDepth = 128,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };
    // Los accesos de Delphin y la configuración de esta máquina no forman parte de una colaboración.
    private static readonly HashSet<string> Privadas = new(StringComparer.OrdinalIgnoreCase)
    {
        "usuario", "usuario_map", "perfil", "perfil_map", "roles_sucursal", "SESION_CAJA", "parametro",
        "log_objs_changes", "messages_app", "myg_info", "myg_delphin_fila", "myg_colaboracion_local"
    };
    private static readonly HashSet<string> NativasObra = new(StringComparer.OrdinalIgnoreCase)
    {
        "proyecto", "presupuesto", "titulo", "titulo_bim", "costo_unitario", "analisis_costo",
        "subtotal_costounitario", "subtotal_analisiscosto", "composicion_costounitario", "composicion_analisiscosto",
        "metrado", "metrado_bim", "programacion_costo", "programacion_metrado", "dependencia", "dependencianew",
        "dependencia_costo", "dependencia_metrado", "dependencia_tarea", "linea_base", "planoteca",
        "valorizacion_programada", "metrado_ejecutado", "metrado_valorizado", "resumen_costounitario",
        "costo_partida", "costo_desagregado", "calendario", "responsable_obra", "presupuesto_val",
        "unidad", "tipo_costo", "categoria", "producto", "lista_precio", "infraestructura", "propietario",
        "portafolio", "departamento", "provincia", "distrito", "localidad", "pais_info", "moneda",
        "clase", "subclase", "marca", "indice", "indice_precio", "region_precio", "responsable"
    };
    private static readonly HashSet<string> AnclasObra = new(StringComparer.OrdinalIgnoreCase)
    { "id_proyecto", "id_presupuesto", "id_titulo", "id_costounitario", "id_analisiscosto", "id_subtotal", "id_metrado", "id_programacion" };
    private static readonly HashSet<string> Dependencias = new(StringComparer.OrdinalIgnoreCase)
    {
        "catalogo_unidad", "catalogo_insumo", "catalogo_partida", "catalogo_partida_nodo", "catalogo_partida_insumo", "catalogo_partida_recurso",
        "myg_indice_unificado", "unidad", "tipo_costo", "categoria", "producto", "lista_precio", "infraestructura", "propietario",
        "portafolio", "departamento", "provincia", "distrito", "localidad", "pais_info", "moneda", "clase", "subclase", "marca",
        "indice", "indice_precio", "region_precio", "responsable", "calendario"
    };

    public sealed class Celda
    {
        public string Tipo { get; set; } = "nulo";
        public string? Valor { get; set; }
    }
    public sealed class Tabla
    {
        public string Nombre { get; set; } = "";
        public List<string> Columnas { get; set; } = new();
        public List<List<Celda>> Filas { get; set; } = new();
    }
    public sealed class Recurso
    {
        public string Referencia { get; set; } = "";
        public string Nombre { get; set; } = "";
        public string Sha256 { get; set; } = "";
        public string Base64 { get; set; } = "";
        public string? Almacen { get; set; }
    }
    private sealed record Columna(string Nombre, string Tipo, int Clave);

    public static JsonElement CrearContenido(MYGProyectoDocumento documento, string rutaSQLite, string alcance = "obra", bool compacto = false)
    {
        if (alcance != "obra" && alcance != "base") throw new ArgumentException("El alcance debe ser obra o base.", nameof(alcance));
        var principal = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(principal);
        if (!File.Exists(rutaSQLite)) throw new FileNotFoundException("Guarde la hoja antes de compartirla.", rutaSQLite);
        string temporal = CrearTemporal();
        try
        {
            string patron = Path.Combine(temporal, "esquema.sqlite");
            MYGBaseDatos.CrearBaseVacia(patron);
            using var confiable = Abrir(patron, false);
            PrepararEsquemaPortable(confiable);
            var esquema = Esquema(confiable);
            string instantanea = Path.Combine(temporal, "instantanea.sqlite");
            using (var fuenteOriginal = Abrir(rutaSQLite, true))
            using (var salida = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = instantanea, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false }.ToString()))
            {
                salida.Open(); fuenteOriginal.BackupDatabase(salida);
            }
            var documentos = alcance == "base"
                ? MYGBaseDatos.ListarProyectos(instantanea).Select(x => x.Id == principal.Id ? principal : MYGBaseDatos.LeerProyecto(instantanea, x.Id)).ToList()
                : new List<MYGProyectoDocumento> { principal };
            foreach (var d in documentos) RedirigirFuente(d, instantanea, Path.GetFullPath(rutaSQLite));
            if (!documentos.Any(x => x.Id == principal.Id)) documentos.Add(principal);
            var avisos = new List<string>();
            List<Tabla> tablas;
            using (var fuente = Abrir(instantanea, true))
            {
                var tablasFuente = Esquema(fuente);
                tablas = tablasFuente.Keys.Where(x => esquema.ContainsKey(x) && Permitida(x))
                    .Select(x => LeerTabla(fuente, x, tablasFuente[x].Where(c => esquema[x].Any(y => y.Nombre == c.Nombre)).Select(c => c.Nombre).ToList())).ToList();
                var desconocidas = tablasFuente.Keys.Where(x => !esquema.ContainsKey(x) && !x.StartsWith("sqlite_", StringComparison.OrdinalIgnoreCase)).ToList();
                if (desconocidas.Count > 0) avisos.Add("Tablas de extensiones no incluidas: " + string.Join(", ", desconocidas));
                if (alcance == "obra")
                {
                    string semilla = Path.Combine(temporal, "obra.sqlite");
                    MYGBaseDatos.CrearBaseVacia(semilla);
                    using (var catalogos = Abrir(semilla, false))
                    {
                        PrepararEsquemaPortable(catalogos);
                        Restaurar(catalogos, tablas.Where(x => Dependencias.Contains(x.Nombre)).ToList(), true);
                    }
                    MYGProyectoStorage.Guardar(semilla, MYGProyectoStorage.Copia(principal));
                    using var propia = Abrir(semilla, true);
                    tablas = FiltrarObra(tablas, propia, esquema, principal);
                    avisos.Add("La obra incluye solo dependencias nativas reconocidas. Las tablas administrativas o de extensiones sin relación comprobable permanecen en la hoja original.");
                }
            }
            // Un catálogo externo se consulta por sus dependencias explícitas, nunca se adjunta su hoja completa.
            if (alcance == "obra") AgregarCatalogosExternos(tablas, documentos, rutaSQLite, esquema, avisos);
            var recursos = new List<Recurso>();
            foreach (var d in documentos) CapturarRecursos(JsonSerializer.SerializeToNode(d, Json), Path.GetDirectoryName(Path.GetFullPath(rutaSQLite))!, recursos, avisos);
            foreach (var tabla in tablas) RecorrerJsonTabla(tabla, nodo => CapturarRecursos(nodo, Path.GetDirectoryName(Path.GetFullPath(rutaSQLite))!, recursos, avisos));
            if (compacto) return FormatoPaqueteNube.CrearCompacto(principal, documentos, tablas, recursos, avisos, alcance);
            return JsonSerializer.SerializeToElement(new
            {
                formato = "MYG_COLABORACION", version = 1, alcance, documento = principal, documentos,
                tablas, recursos, avisos,
                exclusiones = FormatoPaqueteNube.Exclusiones
            }, Json);
        }
        finally { Directory.Delete(temporal, true); }
    }

    /// <summary>Conserva adjuntos y datos nativos al modificar el documento principal de una colaboración.</summary>
    public static JsonElement ActualizarDocumento(JsonElement contenido, MYGProyectoDocumento documento)
    {
        bool compacto = FormatoPaqueteNube.EsCompacto(contenido);
        contenido = FormatoPaqueteNube.Expandir(contenido);
        MYGProyectoStorage.Validar(documento);
        var objeto = JsonNode.Parse(contenido.GetRawText())?.AsObject() ?? new JsonObject();
        objeto["documento"] = JsonSerializer.SerializeToNode(documento, Json);
        if (objeto["documentos"] is JsonArray documentos)
        {
            for (int i = 0; i < documentos.Count; i++)
                if (documentos[i]?["Id"]?.GetValue<string>() == documento.Id) { documentos[i] = JsonSerializer.SerializeToNode(documento, Json); break; }
        }
        var recursos = objeto["recursos"]?.Deserialize<List<Recurso>>(Json) ?? new();
        var avisos = objeto["avisos"]?.Deserialize<List<string>>(Json) ?? new();
        CapturarRecursos(JsonSerializer.SerializeToNode(documento, Json), null, recursos, avisos);
        objeto["recursos"] = JsonSerializer.SerializeToNode(recursos, Json);
        objeto["avisos"] = JsonSerializer.SerializeToNode(avisos.Distinct().ToList(), Json);
        var actualizado = JsonSerializer.SerializeToElement(objeto, Json);
        return compacto ? FormatoPaqueteNube.Compactar(actualizado) : actualizado;
    }

    /// <summary>Firma del contenido compartido, independiente de rutas locales, orden SQL y transporte de adjuntos.</summary>
    public static string FirmaDatosCompartidos(JsonElement contenido)
    {
        contenido = FormatoPaqueteNube.Expandir(contenido);
        LeerDocumento(contenido);
        var recursos = contenido.TryGetProperty("recursos", out var r) ? r.Deserialize<List<Recurso>>(Json) ?? new() : new List<Recurso>();
        var hashes = recursos.Where(x => !string.IsNullOrWhiteSpace(x.Referencia)).GroupBy(x => x.Referencia, StringComparer.Ordinal)
            .ToDictionary(x => x.Key, x => x.Last().Sha256.ToUpperInvariant(), StringComparer.Ordinal);
        var documentos = contenido.TryGetProperty("documentos", out var ds) ? JsonNode.Parse(ds.GetRawText())?.AsArray() ?? new() : new JsonArray();
        var principal = JsonNode.Parse(contenido.GetProperty("documento").GetRawText());
        string? idPrincipal = principal?["Id"]?.GetValue<string>();
        for (int i = documentos.Count - 1; i >= 0; i--) if (documentos[i]?["Id"]?.GetValue<string>() == idPrincipal) documentos.RemoveAt(i);
        documentos.Add(principal);
        var documentosCanonicos = documentos.Select(x => Canonizar(x, hashes)?.ToJsonString(Json) ?? "null").OrderBy(x => x, StringComparer.Ordinal).ToArray();
        var tablas = contenido.TryGetProperty("tablas", out var ts) ? ts.Deserialize<List<Tabla>>(Json) ?? new() : new List<Tabla>();
        var tablasCanonicas = new List<string>();
        foreach (var tabla in tablas.Where(x => x.Filas.Count > 0).OrderBy(x => x.Nombre, StringComparer.Ordinal))
        {
            var filas = new List<string>();
            foreach (var fila in tabla.Filas)
            {
                var objeto = new JsonObject();
                foreach (int i in Enumerable.Range(0, tabla.Columnas.Count).OrderBy(i => tabla.Columnas[i], StringComparer.Ordinal))
                {
                    string columna = tabla.Columnas[i];
                    if (columna.Equals("modificado_utc", StringComparison.OrdinalIgnoreCase)) continue;
                    var celda = fila[i];
                    JsonNode? valor = JsonValue.Create(celda.Valor);
                    if (columna.StartsWith("json_", StringComparison.OrdinalIgnoreCase) && celda.Tipo == "texto" && celda.Valor != null)
                    {
                        try { valor = Canonizar(JsonNode.Parse(celda.Valor, documentOptions: new JsonDocumentOptions { MaxDepth = 128 }), hashes); }
                        catch (JsonException) { }
                    }
                    objeto[columna] = new JsonArray(JsonValue.Create(celda.Tipo), valor);
                }
                filas.Add(objeto.ToJsonString(Json));
            }
            tablasCanonicas.Add(tabla.Nombre + "\n" + string.Join("\n", filas.OrderBy(x => x, StringComparer.Ordinal)));
        }
        string canonico = JsonSerializer.Serialize(new { documentos = documentosCanonicos, tablas = tablasCanonicas,
            recursos = recursos.Select(x => x.Sha256.ToUpperInvariant()).Distinct(StringComparer.Ordinal).OrderBy(x => x, StringComparer.Ordinal).ToArray() }, Json);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonico)));
    }

    private static JsonNode? Canonizar(JsonNode? nodo, Dictionary<string, string> hashes)
    {
        if (nodo is JsonObject objeto)
        {
            var salida = new JsonObject();
            foreach (var campo in objeto.OrderBy(x => x.Key, StringComparer.Ordinal))
            {
                if (campo.Key.Equals("ModificadoUtc", StringComparison.OrdinalIgnoreCase) || campo.Key.Equals("PresupuestoActivoId", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase) || campo.Key.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase)) continue;
                if (EsRutaRecurso(campo.Key))
                {
                    string? referencia = campo.Value is JsonValue valor && valor.TryGetValue<string>(out string? ruta) ? ruta : null;
                    salida[campo.Key] = referencia != null && hashes.TryGetValue(referencia, out string? hash) ? hash : "";
                }
                else salida[campo.Key] = Canonizar(campo.Value, hashes);
            }
            return salida;
        }
        if (nodo is JsonArray lista) return new JsonArray(lista.Select(x => Canonizar(x, hashes)).ToArray());
        return nodo?.DeepClone();
    }

    public static MYGProyectoDocumento LeerDocumento(JsonElement contenido)
    {
        contenido = FormatoPaqueteNube.Expandir(contenido);
        ValidarEnvoltura(contenido);
        if (!contenido.TryGetProperty("documento", out var d)) throw new InvalidDataException("La colaboración no contiene un documento MYG.");
        var documento = d.Deserialize<MYGProyectoDocumento>(Json) ?? throw new InvalidDataException("Documento MYG vacío.");
        MYGProyectoStorage.Validar(documento);
        return documento;
    }

    private static void ValidarEnvoltura(JsonElement contenido)
    {
        if (contenido.ValueKind != JsonValueKind.Object
            || (contenido.TryGetProperty("formato", out var f) && (f.ValueKind != JsonValueKind.String || f.GetString() != "MYG_COLABORACION"))
            || (contenido.TryGetProperty("version", out var v) && (v.ValueKind != JsonValueKind.Number || !v.TryGetInt32(out int version) || version != 1))
            || (contenido.TryGetProperty("alcance", out var a) && (a.ValueKind != JsonValueKind.String || (a.GetString() != "obra" && a.GetString() != "base"))))
            throw new InvalidDataException("Formato, versión o alcance de colaboración no compatible.");
    }

    /// <summary>Resuelve adjuntos junto a la hoja local, sin escribir la base ni reemplazar archivos existentes.</summary>
    public static MYGProyectoDocumento MaterializarDocumento(JsonElement contenido, string rutaSQLite)
    {
        contenido = FormatoPaqueteNube.Expandir(contenido);
        var nodo = JsonSerializer.SerializeToNode(LeerDocumento(contenido), Json)!;
        string completa = Path.GetFullPath(rutaSQLite);
        // Solo se materializan archivos referidos por este documento, aunque el paquete sea de una base completa.
        var referencias = new HashSet<string>(StringComparer.Ordinal);
        ReferenciasRecursos(nodo, referencias);
        var reemplazos = MaterializarRecursos(contenido, completa, referencias);
        ReemplazarRecursos(nodo, reemplazos, true);
        NormalizarFuentesRemotas(nodo, contenido, completa);
        var documento = nodo.Deserialize<MYGProyectoDocumento>(Json)!;
        MYGProyectoStorage.Validar(documento);
        return documento;
    }

    private static Dictionary<string, string> MaterializarRecursos(JsonElement contenido, string rutaSQLite, HashSet<string> referencias)
    {
        var recursos = contenido.TryGetProperty("recursos", out var r) ? r.Deserialize<List<Recurso>>(Json) ?? new() : new List<Recurso>();
        string completa = Path.GetFullPath(rutaSQLite);
        string carpeta = Path.Combine(Path.GetDirectoryName(completa)!, Path.GetFileNameWithoutExtension(completa) + ".recursos");
        var reemplazos = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var recurso in recursos.Where(x => referencias.Contains(x.Referencia)))
        {
            byte[] bytes;
            try { bytes = Convert.FromBase64String(recurso.Base64); }
            catch (FormatException ex) { throw new InvalidDataException("Un adjunto de la colaboración no es válido.", ex); }
            string hash = Convert.ToHexString(SHA256.HashData(bytes));
            if (!hash.Equals(recurso.Sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("La integridad de un adjunto no coincide.");
            string ruta = Path.Combine(carpeta, hash + ExtensionSegura(recurso.Nombre));
            Directory.CreateDirectory(carpeta);
            if (File.Exists(ruta))
            {
                if (!SHA256.HashData(File.ReadAllBytes(ruta)).AsSpan().SequenceEqual(SHA256.HashData(bytes)))
                    throw new IOException("Ya existe un adjunto diferente en el destino.");
            }
            else using (var archivo = new FileStream(ruta, FileMode.CreateNew, FileAccess.Write, FileShare.None)) archivo.Write(bytes);
            reemplazos[recurso.Referencia] = ruta;
        }
        return reemplazos;
    }

    /// <summary>Importa dependencias dentro de la transacción del guardado local; nunca altera otras obras ni confirma la transacción.</summary>
    public static void AplicarDependencias(JsonElement contenido, SqliteConnection conexion, SqliteTransaction transaccion)
    {
        contenido = FormatoPaqueteNube.Expandir(contenido);
        if (!ReferenceEquals(transaccion.Connection, conexion)) throw new ArgumentException("La transacción pertenece a otra conexión.");
        ValidarEnvoltura(contenido);
        if (!contenido.TryGetProperty("tablas", out var datos)) return;
        var tablas = datos.Deserialize<List<Tabla>>(Json) ?? new();
        var referencias = new HashSet<string>(StringComparer.Ordinal);
        foreach (var tabla in tablas.Where(x => Dependencias.Contains(x.Nombre))) RecorrerJsonTabla(tabla, nodo => ReferenciasRecursos(nodo, referencias));
        var reemplazos = MaterializarRecursos(contenido, conexion.DataSource, referencias);
        var normalizarFuentes = CrearNormalizadorFuentes(contenido, Path.GetFullPath(conexion.DataSource));
        foreach (var tabla in tablas.Where(x => Dependencias.Contains(x.Nombre)))
            RecorrerJsonTabla(tabla, nodo => { ReemplazarRecursos(nodo, reemplazos, true); normalizarFuentes(nodo); }, true);
        string temporal = CrearTemporal();
        try
        {
            string patron = Path.Combine(temporal, "esquema.sqlite");
            MYGBaseDatos.CrearBaseVacia(patron);
            using var confiable = Abrir(patron, false); PrepararEsquemaPortable(confiable);
            var esquema = Esquema(confiable);
            PrepararEsquemaPortable(conexion, transaccion);
            var disponibles = Esquema(conexion, transaccion);
            var idsCompartidos = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { LeerDocumento(contenido).Id };
            if (contenido.TryGetProperty("alcance", out var alcance) && alcance.GetString() == "base" && contenido.TryGetProperty("documentos", out var documentos))
                foreach (var documento in documentos.Deserialize<List<MYGProyectoDocumento>>(Json) ?? new()) idsCompartidos.Add(documento.Id);
            bool hayObrasAjenas = false;
            using (var proyectos = conexion.CreateCommand())
            {
                proyectos.Transaction = transaccion; proyectos.CommandText = "SELECT id FROM myg_proyecto";
                using var lector = proyectos.ExecuteReader();
                while (lector.Read()) if (!idsCompartidos.Contains(lector.GetString(0))) hayObrasAjenas = true;
            }
            var vistos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var tabla in tablas.Where(x => Dependencias.Contains(x.Nombre)))
            {
                if (!vistos.Add(tabla.Nombre) || !esquema.TryGetValue(tabla.Nombre, out var columnas)
                    || !disponibles.TryGetValue(tabla.Nombre, out var locales) || tabla.Columnas.Count == 0
                    || tabla.Columnas.Distinct(StringComparer.OrdinalIgnoreCase).Count() != tabla.Columnas.Count
                    || tabla.Columnas.Any(x => !columnas.Any(y => y.Nombre == x) || !locales.Any(y => y.Nombre == x))
                    || tabla.Filas.Any(x => x.Count != tabla.Columnas.Count)) throw new InvalidDataException("Dependencia de colaboración no compatible con el esquema local.");
                using var cmd = conexion.CreateCommand(); cmd.Transaction = transaccion;
                var claves = columnas.Where(x => x.Clave > 0).Select(x => x.Nombre).ToHashSet(StringComparer.OrdinalIgnoreCase);
                var actualizables = tabla.Columnas.Where(x => !claves.Contains(x)).ToList();
                // UPSERT conserva las filas referidas por otros datos, sin los DELETE implícitos de REPLACE.
                cmd.CommandText = "INSERT INTO " + Identificador(tabla.Nombre) + "(" + string.Join(",", tabla.Columnas.Select(Identificador))
                    + ") VALUES(" + string.Join(",", tabla.Columnas.Select((_, i) => "$p" + i)) + ") ON CONFLICT("
                    + string.Join(",", columnas.Where(x => x.Clave > 0).OrderBy(x => x.Clave).Select(x => Identificador(x.Nombre))) + ") DO "
                    + (actualizables.Count == 0 ? "NOTHING" : "UPDATE SET " + string.Join(",", actualizables.Select(x => Identificador(x) + "=excluded." + Identificador(x))));
                for (int i = 0; i < tabla.Columnas.Count; i++) cmd.Parameters.Add(new SqliteParameter("$p" + i, DBNull.Value));
                foreach (var fila in tabla.Filas)
                {
                    if (hayObrasAjenas && FilaExistenteDiferente(conexion, transaccion, tabla, fila, claves))
                        throw new InvalidOperationException("El catálogo local contiene otra obra y una dependencia tiene datos distintos. Descargue la colaboración en una hoja independiente para conservar ambas versiones.");
                    for (int i = 0; i < fila.Count; i++) cmd.Parameters[i].Value = Valor(fila[i]);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        finally { Directory.Delete(temporal, true); }
    }

    private static bool FilaExistenteDiferente(SqliteConnection conexion, SqliteTransaction transaccion, Tabla tabla, List<Celda> fila, HashSet<string> claves)
    {
        var indices = Enumerable.Range(0, tabla.Columnas.Count).Where(i => claves.Contains(tabla.Columnas[i])).ToList();
        if (indices.Count != claves.Count) throw new InvalidDataException("La dependencia no contiene su identidad completa.");
        using var cmd = conexion.CreateCommand(); cmd.Transaction = transaccion;
        cmd.CommandText = "SELECT " + string.Join(",", tabla.Columnas.Select(Identificador)) + " FROM " + Identificador(tabla.Nombre)
            + " WHERE " + string.Join(" AND ", indices.Select(i => Identificador(tabla.Columnas[i]) + " IS $p" + i));
        foreach (int i in indices) cmd.Parameters.AddWithValue("$p" + i, Valor(fila[i]));
        using var lector = cmd.ExecuteReader();
        if (!lector.Read()) return false;
        for (int i = 0; i < fila.Count; i++)
        {
            if (tabla.Columnas[i].Equals("modificado_utc", StringComparison.OrdinalIgnoreCase)) continue;
            object existente = lector.GetValue(i), entrante = Valor(fila[i]);
            if (existente is byte[] a && entrante is byte[] b ? !a.AsSpan().SequenceEqual(b) : !Equals(existente, entrante)) return true;
        }
        return false;
    }

    public static void Descargar(JsonElement contenido, string destinoSQLite, bool zip = false)
    {
        if (zip) { ExportarZip(contenido, destinoSQLite); return; }
        DescargarInterno(contenido, destinoSQLite, false);
    }

    public static void ExportarZip(JsonElement contenido, string destinoZip)
    {
        string destino = Path.GetFullPath(destinoZip);
        if (File.Exists(destino)) throw new IOException("El archivo de destino ya existe. Elija un nombre nuevo.");
        string temporal = CrearTemporal();
        string zipTemporal = Path.Combine(temporal, "descarga.zip");
        try
        {
            string carpeta = Path.Combine(temporal, "contenido");
            Directory.CreateDirectory(carpeta);
            DescargarInterno(contenido, Path.Combine(carpeta, "proyecto.sqlite"), true);
            File.WriteAllText(Path.Combine(carpeta, "contenido.json"), contenido.GetRawText(), new UTF8Encoding(false));
            ZipFile.CreateFromDirectory(carpeta, zipTemporal, CompressionLevel.Optimal, false);
            Directory.CreateDirectory(Path.GetDirectoryName(destino)!);
            File.Move(zipTemporal, destino);
        }
        finally { Directory.Delete(temporal, true); }
    }

    private static void DescargarInterno(JsonElement contenido, string destinoSQLite, bool rutasRelativas)
    {
        contenido = FormatoPaqueteNube.Expandir(contenido);
        var principal = LeerDocumento(contenido);
        string destino = Path.GetFullPath(destinoSQLite);
        if (!MYGBaseDatos.EsRutaSQLite(destino)) throw new ArgumentException("El destino debe tener extensión .sqlite.", nameof(destinoSQLite));
        if (File.Exists(destino)) throw new IOException("El archivo de destino ya existe. Elija un nombre nuevo.");
        string temporal = CrearTemporal();
        try
        {
            string baseTemporal = Path.Combine(temporal, "descarga.sqlite");
            MYGBaseDatos.CrearBaseVacia(baseTemporal);
            var tablas = contenido.TryGetProperty("tablas", out var t) ? t.Deserialize<List<Tabla>>(Json) ?? new() : new List<Tabla>();
            bool esBase = contenido.TryGetProperty("alcance", out var a) && a.GetString() == "base";
            var documentos = esBase && contenido.TryGetProperty("documentos", out var docs)
                ? docs.Deserialize<List<MYGProyectoDocumento>>(Json) ?? new() : new List<MYGProyectoDocumento>();
            documentos.RemoveAll(x => x.Id == principal.Id); documentos.Add(principal);
            var recursos = contenido.TryGetProperty("recursos", out var r) ? r.Deserialize<List<Recurso>>(Json) ?? new() : new List<Recurso>();
            string nombreRecursos = Path.GetFileNameWithoutExtension(destino) + ".recursos";
            string carpetaFinal = Path.Combine(Path.GetDirectoryName(destino)!, nombreRecursos);
            var reemplazos = new Dictionary<string, string>(StringComparer.Ordinal);
            var archivos = new Dictionary<string, byte[]>(StringComparer.Ordinal);
            foreach (var recurso in recursos)
            {
                byte[] bytes;
                try { bytes = Convert.FromBase64String(recurso.Base64); }
                catch (FormatException ex) { throw new InvalidDataException("Un adjunto de la colaboración no es válido.", ex); }
                string hash = Convert.ToHexString(SHA256.HashData(bytes));
                if (!hash.Equals(recurso.Sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("La integridad de un adjunto no coincide.");
                string nombre = hash + ExtensionSegura(recurso.Nombre);
                archivos[nombre] = bytes;
                reemplazos[recurso.Referencia] = rutasRelativas ? nombreRecursos + "/" + nombre : Path.Combine(carpetaFinal, nombre);
            }
            var normalizarFuentes = CrearNormalizadorFuentes(contenido, destino);
            foreach (var tabla in tablas) RecorrerJsonTabla(tabla, nodo => { ReemplazarRecursos(nodo, reemplazos, true); normalizarFuentes(nodo); }, true);
            // La restauración solo conoce tablas y columnas del esquema instalado localmente.
            using (var c = Abrir(baseTemporal, false)) { PrepararEsquemaPortable(c); Restaurar(c, tablas, esBase); }
            foreach (var documento in documentos)
            {
                MYGProyectoStorage.Validar(documento);
                var nodo = JsonSerializer.SerializeToNode(documento, Json)!;
                ReemplazarRecursos(nodo, reemplazos, true);
                normalizarFuentes(nodo);
                var rebasado = nodo.Deserialize<MYGProyectoDocumento>(Json)!;
                documento.Presupuestos = rebasado.Presupuestos;
                documento.FuenteCatalogo = rebasado.FuenteCatalogo;
                // Se recalculan los datos MYG y nativos del documento editado sobre la instantánea nativa conservada.
                MYGProyectoStorage.Guardar(baseTemporal, documento);
            }
            Directory.CreateDirectory(Path.GetDirectoryName(destino)!);
            foreach (var archivo in archivos)
            {
                Directory.CreateDirectory(carpetaFinal);
                string ruta = Path.Combine(carpetaFinal, archivo.Key);
                if (File.Exists(ruta))
                {
                    if (!SHA256.HashData(File.ReadAllBytes(ruta)).AsSpan().SequenceEqual(SHA256.HashData(archivo.Value)))
                        throw new IOException("Ya existe un adjunto diferente en el destino.");
                }
                else using (var salida = new FileStream(ruta, FileMode.CreateNew, FileAccess.Write, FileShare.None)) salida.Write(archivo.Value);
            }
            File.Move(baseTemporal, destino);
        }
        finally { Directory.Delete(temporal, true); }
    }

    private static bool Permitida(string tabla) => !Privadas.Contains(tabla) && !tabla.StartsWith("sqlite_", StringComparison.OrdinalIgnoreCase)
        && !tabla.Contains("licencia", StringComparison.OrdinalIgnoreCase) && !tabla.Contains("password", StringComparison.OrdinalIgnoreCase)
        && !tabla.Contains("token", StringComparison.OrdinalIgnoreCase) && !tabla.Contains("credential", StringComparison.OrdinalIgnoreCase);
    private static string CrearTemporal()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-paquete-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta); return carpeta;
    }
    private static string Identificador(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";
    private static void PrepararEsquemaPortable(SqliteConnection c, SqliteTransaction? transaccion = null)
    {
        // Tabla opcional definida por Core; el DDL procede del cliente, nunca de la colaboración.
        using var cmd = c.CreateCommand(); cmd.Transaction = transaccion;
        cmd.CommandText = "CREATE TABLE IF NOT EXISTS myg_indice_unificado(codigo TEXT PRIMARY KEY COLLATE NOCASE,descripcion TEXT NOT NULL,periodo_base TEXT NOT NULL,resolucion TEXT NOT NULL,orden INTEGER NOT NULL)";
        cmd.ExecuteNonQuery();
    }
    private static SqliteConnection Abrir(string ruta, bool lectura)
    {
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta,
            Mode = lectura ? SqliteOpenMode.ReadOnly : SqliteOpenMode.ReadWrite, Pooling = false, ForeignKeys = false }.ToString());
        c.Open(); return c;
    }
    private static Dictionary<string, List<Columna>> Esquema(SqliteConnection c, SqliteTransaction? transaccion = null)
    {
        var nombres = new List<string>();
        using (var cmd = c.CreateCommand())
        {
            cmd.Transaction = transaccion;
            cmd.CommandText = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name";
            using var r = cmd.ExecuteReader(); while (r.Read()) nombres.Add(r.GetString(0));
        }
        var resultado = new Dictionary<string, List<Columna>>(StringComparer.OrdinalIgnoreCase);
        foreach (string tabla in nombres)
        {
            using var cmd = c.CreateCommand(); cmd.Transaction = transaccion; cmd.CommandText = "PRAGMA table_info(" + Identificador(tabla) + ")";
            using var r = cmd.ExecuteReader(); var columnas = new List<Columna>();
            while (r.Read()) columnas.Add(new Columna(r.GetString(1), r.GetString(2), r.GetInt32(5)));
            resultado[tabla] = columnas;
        }
        return resultado;
    }
    private static void RedirigirFuente(MYGProyectoDocumento d, string desde, string hasta)
    {
        if (d.FuenteCatalogo?.RutaSQLite == desde) d.FuenteCatalogo.RutaSQLite = hasta;
        foreach (var p in d.Presupuestos)
        {
            if (p.Conexion?.RutaSQLite == desde) p.Conexion.RutaSQLite = hasta;
            foreach (var i in p.Costos.Insumos) if (i.CatalogoMYGRuta == desde) i.CatalogoMYGRuta = hasta;
            foreach (var i in p.Items)
            {
                if (i.FuenteCatalogoRuta == desde) i.FuenteCatalogoRuta = hasta;
                if (i.Costos.CatalogoMYGRuta == desde) i.Costos.CatalogoMYGRuta = hasta;
            }
        }
    }
    private static Tabla LeerTabla(SqliteConnection c, string nombre, List<string> columnas)
    {
        var tabla = new Tabla { Nombre = nombre, Columnas = columnas };
        if (columnas.Count == 0) return tabla;
        using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT " + string.Join(",", columnas.Select(Identificador)) + " FROM " + Identificador(nombre);
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            var fila = new List<Celda>();
            for (int i = 0; i < r.FieldCount; i++) fila.Add(r.GetValue(i) switch
            {
                DBNull => new Celda(),
                byte[] b => new Celda { Tipo = "blob", Valor = Convert.ToBase64String(b) },
                long n => new Celda { Tipo = "entero", Valor = n.ToString(CultureInfo.InvariantCulture) },
                double n => new Celda { Tipo = "real", Valor = n.ToString("R", CultureInfo.InvariantCulture) },
                string s => new Celda { Tipo = "texto", Valor = s },
                _ => throw new InvalidDataException("Tipo SQLite no compatible en " + nombre)
            });
            tabla.Filas.Add(fila);
        }
        return tabla;
    }
    private static object Valor(Celda celda) => celda.Tipo switch
    {
        "nulo" => DBNull.Value,
        "texto" => celda.Valor ?? "",
        "entero" => long.Parse(celda.Valor!, CultureInfo.InvariantCulture),
        "real" => double.TryParse(celda.Valor, NumberStyles.Float, CultureInfo.InvariantCulture, out double n) && double.IsFinite(n)
            ? n : throw new InvalidDataException("Número SQLite no válido."),
        "blob" => Convert.FromBase64String(celda.Valor!),
        _ => throw new InvalidDataException("Tipo de celda SQLite desconocido.")
    };
    private static void Restaurar(SqliteConnection c, List<Tabla> tablas, bool reemplazar)
    {
        var esquema = Esquema(c);
        var vistos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var tabla in tablas)
        {
            if (!Permitida(tabla.Nombre) || !esquema.TryGetValue(tabla.Nombre, out var columnas) || !vistos.Add(tabla.Nombre)
                || tabla.Columnas.Count == 0 || tabla.Columnas.Distinct(StringComparer.OrdinalIgnoreCase).Count() != tabla.Columnas.Count
                || tabla.Columnas.Any(x => !columnas.Any(y => y.Nombre == x)) || tabla.Filas.Any(x => x.Count != tabla.Columnas.Count))
                throw new InvalidDataException("Tabla o columnas no autorizadas en la colaboración.");
        }
        using var transaccion = c.BeginTransaction();
        foreach (var tabla in tablas)
        {
            if (reemplazar) { using var borrar = c.CreateCommand(); borrar.Transaction = transaccion; borrar.CommandText = "DELETE FROM " + Identificador(tabla.Nombre); borrar.ExecuteNonQuery(); }
            using var cmd = c.CreateCommand(); cmd.Transaction = transaccion;
            cmd.CommandText = "INSERT OR REPLACE INTO " + Identificador(tabla.Nombre) + "(" + string.Join(",", tabla.Columnas.Select(Identificador)) + ") VALUES(" + string.Join(",", tabla.Columnas.Select((_, i) => "$p" + i)) + ")";
            for (int i = 0; i < tabla.Columnas.Count; i++) cmd.Parameters.Add(new SqliteParameter("$p" + i, DBNull.Value));
            foreach (var fila in tabla.Filas)
            {
                for (int i = 0; i < fila.Count; i++) cmd.Parameters[i].Value = Valor(fila[i]);
                cmd.ExecuteNonQuery();
            }
        }
        transaccion.Commit();
    }

    private static List<Tabla> FiltrarObra(List<Tabla> origen, SqliteConnection propia,
        Dictionary<string, List<Columna>> esquema, MYGProyectoDocumento documento)
    {
        var ids = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
        void Registrar(string columna, string? valor)
        {
            if (string.IsNullOrWhiteSpace(valor) || !columna.StartsWith("id_", StringComparison.OrdinalIgnoreCase)) return;
            if (!ids.TryGetValue(columna, out var conjunto)) ids[columna] = conjunto = new(StringComparer.OrdinalIgnoreCase);
            conjunto.Add(valor);
        }
        void RegistrarFila(Tabla tabla, List<Celda> fila)
        {
            for (int i = 0; i < tabla.Columnas.Count; i++) Registrar(tabla.Columnas[i], fila[i].Valor);
            // Los auxiliares son análisis nativos, aunque la composición use otro nombre de columna.
            int auxiliar = tabla.Columnas.FindIndex(x => x.Equals("id_costoauxiliar", StringComparison.OrdinalIgnoreCase));
            if (auxiliar >= 0) Registrar("id_analisiscosto", fila[auxiliar].Valor);
        }
        foreach (string nombre in NativasObra.Where(x => esquema.ContainsKey(x) && !Dependencias.Contains(x)))
        {
            var semilla = LeerTabla(propia, nombre, esquema[nombre].Select(x => x.Nombre).ToList());
            foreach (var fila in semilla.Filas) RegistrarFila(semilla, fila);
        }
        // Una referencia al catálogo MYG es informativa; se comparte únicamente la entrada utilizada.
        var referencias = ReferenciasCatalogo(documento);
        var elegidas = origen.Where(x => NativasObra.Contains(x.Nombre) || x.Nombre.StartsWith("catalogo_", StringComparison.OrdinalIgnoreCase))
            .Select(x => new Tabla { Nombre = x.Nombre, Columnas = x.Columnas }).ToList();
        var tomadas = elegidas.ToDictionary(x => x.Nombre, _ => new HashSet<int>(), StringComparer.OrdinalIgnoreCase);
        bool Coincide(string columna, string? valor) => valor != null && ids.TryGetValue(columna, out var valores) && valores.Contains(valor);
        bool Elegible(Tabla tabla, List<Celda> fila)
        {
            if (tabla.Nombre.StartsWith("catalogo_", StringComparison.OrdinalIgnoreCase))
            {
                int id = tabla.Columnas.FindIndex(x => x is "id" or "catalogo_id");
                return id >= 0 && fila[id].Valor != null && referencias.Contains(fila[id].Valor!);
            }
            // Si existe una relación explícita con una obra/presupuesto, tiene prioridad sobre IDs compartidos.
            foreach (string raiz in new[] { "id_proyecto", "id_presupuesto", "id_titulo", "id_costounitario" })
            {
                int i = tabla.Columnas.FindIndex(x => x.Equals(raiz, StringComparison.OrdinalIgnoreCase));
                if (i >= 0 && !string.IsNullOrWhiteSpace(fila[i].Valor)) return Coincide(raiz, fila[i].Valor);
            }
            for (int i = 0; i < tabla.Columnas.Count; i++)
                if (AnclasObra.Contains(tabla.Columnas[i]) && Coincide(tabla.Columnas[i], fila[i].Valor)) return true;
            return esquema[tabla.Nombre].Where(x => x.Clave > 0).Any(clave =>
            {
                int i = tabla.Columnas.IndexOf(clave.Nombre);
                return i >= 0 && Coincide(clave.Nombre, fila[i].Valor);
            });
        }
        // Cierre de dependencias: presupuesto → títulos → partidas → análisis → insumos y unidades.
        bool cambios;
        do
        {
            cambios = false;
            foreach (var destino in elegidas)
            {
                var fuente = origen.First(x => x.Nombre == destino.Nombre);
                for (int i = 0; i < fuente.Filas.Count; i++)
                {
                    if (tomadas[fuente.Nombre].Contains(i) || !Elegible(fuente, fuente.Filas[i])) continue;
                    tomadas[fuente.Nombre].Add(i); destino.Filas.Add(fuente.Filas[i]);
                    RegistrarFila(fuente, fuente.Filas[i]); cambios = true;
                }
            }
        } while (cambios);
        return elegidas.Where(x => x.Filas.Count > 0).ToList();
    }

    private static HashSet<string> ReferenciasCatalogo(MYGProyectoDocumento documento)
    {
        var referencias = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in documento.Presupuestos)
        {
            foreach (var i in p.Costos.Insumos) if (!string.IsNullOrWhiteSpace(i.CatalogoMYGId)) referencias.Add(i.CatalogoMYGId);
            foreach (var i in p.Items) if (!string.IsNullOrWhiteSpace(i.Costos.CatalogoMYGId)) referencias.Add(i.Costos.CatalogoMYGId);
        }
        return referencias;
    }

    private static void AgregarCatalogosExternos(List<Tabla> tablas, List<MYGProyectoDocumento> documentos, string rutaSQLite,
        Dictionary<string, List<Columna>> esquema, List<string> avisos)
    {
        var rutas = documentos.SelectMany(d => d.Presupuestos).SelectMany(p =>
            p.Costos.Insumos.Select(i => i.CatalogoMYGRuta).Concat(p.Items.Select(i => i.Costos.CatalogoMYGRuta)))
            .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase);
        var referencias = documentos.SelectMany(ReferenciasCatalogo).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (string ruta in rutas)
        {
            string completa;
            try { completa = Path.GetFullPath(ruta, Path.GetDirectoryName(Path.GetFullPath(rutaSQLite))!); }
            catch (ArgumentException) { avisos.Add("Una ruta de catálogo no es válida."); continue; }
            if (completa.Equals(Path.GetFullPath(rutaSQLite), StringComparison.OrdinalIgnoreCase)) continue;
            if (!File.Exists(completa)) { avisos.Add("No se encontró un catálogo externo referenciado; el presupuesto conserva sus datos propios."); continue; }
            using var c = Abrir(completa, true);
            var disponibles = Esquema(c);
            foreach (var nombre in disponibles.Keys.Where(x => x.StartsWith("catalogo_", StringComparison.OrdinalIgnoreCase) && esquema.ContainsKey(x)))
            {
                var tabla = LeerTabla(c, nombre, disponibles[nombre].Where(x => esquema[nombre].Any(y => y.Nombre == x.Nombre)).Select(x => x.Nombre).ToList());
                int id = tabla.Columnas.FindIndex(x => x is "id" or "catalogo_id");
                if (id < 0) continue;
                tabla.Filas.RemoveAll(f => f[id].Valor == null || !referencias.Contains(f[id].Valor!));
                if (tabla.Filas.Count == 0) continue;
                var existente = tablas.FirstOrDefault(x => x.Nombre == nombre);
                if (existente == null) tablas.Add(tabla);
                else if (existente.Columnas.SequenceEqual(tabla.Columnas))
                {
                    var filas = existente.Filas.Select(f => JsonSerializer.Serialize(f, Json)).ToHashSet(StringComparer.Ordinal);
                    existente.Filas.AddRange(tabla.Filas.Where(f => filas.Add(JsonSerializer.Serialize(f, Json))));
                }
                else avisos.Add("Un catálogo externo tiene columnas de una versión distinta y se omitió.");
            }
        }
    }

    private static bool EsRutaRecurso(string propiedad) => propiedad.Equals("ImagenRuta", StringComparison.OrdinalIgnoreCase)
        || propiedad.Equals("FichaTecnicaRuta", StringComparison.OrdinalIgnoreCase);
    private static void RecorrerJsonTabla(Tabla tabla, Action<JsonNode?> visitar, bool actualizar = false)
    {
        for (int i = 0; i < tabla.Columnas.Count; i++)
        {
            if (!tabla.Columnas[i].StartsWith("json_", StringComparison.OrdinalIgnoreCase)) continue;
            foreach (var fila in tabla.Filas)
            {
                if (fila[i].Tipo != "texto" || string.IsNullOrWhiteSpace(fila[i].Valor)) continue;
                JsonNode? nodo;
                try { nodo = JsonNode.Parse(fila[i].Valor!, documentOptions: new JsonDocumentOptions { MaxDepth = 128 }); }
                catch (JsonException) { continue; }
                visitar(nodo);
                if (actualizar && nodo != null) fila[i].Valor = nodo.ToJsonString(Json);
            }
        }
    }
    private static void ReferenciasRecursos(JsonNode? nodo, HashSet<string> referencias)
    {
        if (nodo is JsonObject objeto)
            foreach (var campo in objeto)
            {
                if (EsRutaRecurso(campo.Key) && campo.Value is JsonValue valor && valor.TryGetValue<string>(out string? ruta) && !string.IsNullOrWhiteSpace(ruta)) referencias.Add(ruta);
                else ReferenciasRecursos(campo.Value, referencias);
            }
        else if (nodo is JsonArray lista) foreach (var hijo in lista) ReferenciasRecursos(hijo, referencias);
    }
    private static void CapturarRecursos(JsonNode? nodo, string? carpeta, List<Recurso> recursos, List<string> avisos)
    {
        if (nodo is JsonObject objeto)
        {
            foreach (var campo in objeto)
            {
                if (!EsRutaRecurso(campo.Key) || campo.Value is not JsonValue valor || !valor.TryGetValue<string>(out string? referencia)
                    || string.IsNullOrWhiteSpace(referencia)) { CapturarRecursos(campo.Value, carpeta, recursos, avisos); continue; }
                string ruta;
                try
                {
                    if (!Path.IsPathRooted(referencia) && carpeta == null) continue;
                    ruta = carpeta == null ? Path.GetFullPath(referencia) : Path.GetFullPath(referencia, carpeta);
                }
                catch (ArgumentException) { avisos.Add("Una ruta de adjunto no es válida."); continue; }
                if (!File.Exists(ruta))
                {
                    if (!recursos.Any(x => x.Referencia == referencia)) avisos.Add("Adjunto no disponible: " + Path.GetFileName(referencia));
                    continue;
                }
                byte[] bytes = File.ReadAllBytes(ruta);
                var recurso = new Recurso { Referencia = referencia, Nombre = Path.GetFileName(ruta),
                    Sha256 = Convert.ToHexString(SHA256.HashData(bytes)), Base64 = Convert.ToBase64String(bytes) };
                var anterior = recursos.LastOrDefault(x => x.Referencia == referencia);
                if (anterior?.Sha256.Equals(recurso.Sha256, StringComparison.OrdinalIgnoreCase) == true) recurso.Almacen = anterior.Almacen;
                recursos.RemoveAll(x => x.Referencia == referencia); recursos.Add(recurso);
            }
        }
        else if (nodo is JsonArray lista) foreach (var hijo in lista) CapturarRecursos(hijo, carpeta, recursos, avisos);
    }
    private static void ReemplazarRecursos(JsonNode? nodo, Dictionary<string, string> reemplazos, bool eliminarAusentes = false)
    {
        if (nodo is JsonObject objeto)
        {
            foreach (var campo in objeto.ToList())
            {
                if (EsRutaRecurso(campo.Key) && campo.Value is JsonValue valor && valor.TryGetValue<string>(out string? ruta))
                {
                    if (ruta != null && reemplazos.TryGetValue(ruta, out string? nueva)) objeto[campo.Key] = nueva;
                    else if (eliminarAusentes) objeto[campo.Key] = "";
                }
                else ReemplazarRecursos(campo.Value, reemplazos, eliminarAusentes);
            }
        }
        else if (nodo is JsonArray lista) foreach (var hijo in lista) ReemplazarRecursos(hijo, reemplazos, eliminarAusentes);
    }
    private static void NormalizarFuentesRemotas(JsonNode? nodo, JsonElement contenido, string rutaLocal)
        => CrearNormalizadorFuentes(contenido, rutaLocal)(nodo);
    private static Action<JsonNode?> CrearNormalizadorFuentes(JsonElement contenido, string rutaLocal)
    {
        var idsCatalogo = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var idsProyectos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var idsPresupuestos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (contenido.TryGetProperty("tablas", out var datos))
            foreach (var tabla in datos.Deserialize<List<Tabla>>(Json) ?? new())
            {
                string columna = tabla.Nombre is "catalogo_insumo" or "catalogo_partida" ? "id"
                    : tabla.Nombre == "proyecto" ? "id_proyecto" : tabla.Nombre == "presupuesto" ? "id_presupuesto" : "";
                int indice = tabla.Columnas.IndexOf(columna);
                if (indice < 0) continue;
                var destino = columna == "id" ? idsCatalogo : columna == "id_proyecto" ? idsProyectos : idsPresupuestos;
                foreach (var fila in tabla.Filas) if (fila.Count > indice && fila[indice].Valor is string id) destino.Add(id);
            }
        string? Texto(JsonObject objeto, string campo) => objeto[campo] is JsonValue v && v.TryGetValue<string>(out string? texto) ? texto : null;
        void Visitar(JsonNode? actual)
        {
            if (actual is JsonObject objeto)
            {
                foreach (var campo in objeto.ToList()) Visitar(campo.Value);
                foreach (var campo in objeto.ToList())
                    if (campo.Key.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase)
                        || campo.Key.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase)
                        || campo.Key.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase)) objeto[campo.Key] = null;
                if (objeto.ContainsKey("CatalogoMYGRuta"))
                {
                    bool incluido = Texto(objeto, "CatalogoMYGId") is string id && idsCatalogo.Contains(id);
                    objeto["CatalogoMYGRuta"] = incluido ? rutaLocal : null;
                    if (!incluido) objeto["CatalogoMYGId"] = null;
                }
                if (objeto.ContainsKey("FuenteCatalogoRuta")) objeto["FuenteCatalogoRuta"] = null;
                if (objeto["FuenteCatalogo"] is JsonObject fuente)
                {
                    if (idsProyectos.Count > 0) fuente["RutaSQLite"] = rutaLocal;
                    else objeto["FuenteCatalogo"] = null;
                }
                if (objeto["Conexion"] is JsonObject conexion)
                {
                    if (Texto(conexion, "ProyectoId") is string p && idsProyectos.Contains(p)
                        && Texto(conexion, "PresupuestoId") is string b && idsPresupuestos.Contains(b)) conexion["RutaSQLite"] = rutaLocal;
                    else objeto["Conexion"] = null;
                }
            }
            else if (actual is JsonArray lista) foreach (var hijo in lista) Visitar(hijo);
        }
        return Visitar;
    }
    private static string ExtensionSegura(string nombre)
    {
        string extension = Path.GetExtension(nombre).ToLowerInvariant();
        return extension.Length is > 1 and <= 12 && extension.Skip(1).All(char.IsAsciiLetterOrDigit) ? extension : ".bin";
    }
}
