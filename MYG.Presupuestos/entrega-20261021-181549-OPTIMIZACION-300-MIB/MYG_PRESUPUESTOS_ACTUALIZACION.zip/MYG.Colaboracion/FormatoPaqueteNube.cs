using System.Buffers;
using System.Globalization;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>
/// Codificación portable sin pérdida de tipos SQLite. La versión 2 se conserva
/// compacta en disco y en el servidor; la expansión es sólo para interpretar el
/// contrato anterior, nunca para sustituir los bytes de una operación enviada.
/// </summary>
public static class FormatoPaqueteNube
{
    public const long MaxBytesExpandidos = 512L * 1024 * 1024;
    internal const string Exclusiones = "Accesos, usuarios, perfiles, configuración, licencias y credenciales locales. No se ejecuta SQL recibido.";
    // Estos bytes son JSON de datos, nunca contenido insertado directamente en HTML.
    // Las comillas, controles y barras invertidas siguen escapándose; Unicode no necesita \uXXXX.
    private static readonly JsonSerializerOptions Json = new()
        { PropertyNameCaseInsensitive = true, MaxDepth = 128, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
    private static readonly HashSet<string> Claves = new(StringComparer.Ordinal)
    {
        "formato", "version", "alcance", "documento", "documentos", "tablas",
        "recursos", "avisos", "exclusiones", "textos"
    };
    private static readonly HashSet<string> ClavesTabla = new(StringComparer.Ordinal)
        { "Nombre", "Columnas", "Filas" };
    private static readonly HashSet<string> ClavesCelda = new(StringComparer.Ordinal)
        { "Tipo", "Valor" };

    public static bool EsCompacto(JsonElement contenido) => contenido.ValueKind == JsonValueKind.Object
        && contenido.TryGetProperty("formato", out var formato)
        && formato.ValueKind == JsonValueKind.String && formato.GetString() == "MYG_COLABORACION"
        && contenido.TryGetProperty("version", out var version)
        && version.ValueKind == JsonValueKind.Number && version.TryGetInt32(out int numero) && numero == 2;

    /// <summary>
    /// Crea la publicación compacta directamente desde los objetos leídos de SQLite.
    /// Evita materializar primero todas las celdas y copias de documentos como JSON v1.
    /// </summary>
    public static JsonElement CrearCompacto(MYGProyectoDocumento principal,
        IReadOnlyList<MYGProyectoDocumento> documentos, IReadOnlyList<PaqueteNube.Tabla> tablas,
        IReadOnlyList<PaqueteNube.Recurso> recursos, IReadOnlyList<string> avisos, string alcance)
    {
        ArgumentNullException.ThrowIfNull(principal); ArgumentNullException.ThrowIfNull(documentos);
        ArgumentNullException.ThrowIfNull(tablas); ArgumentNullException.ThrowIfNull(recursos);
        ArgumentNullException.ThrowIfNull(avisos);
        if (alcance is not ("obra" or "base")) throw Invalido("El alcance debe ser obra o base.");
        JsonElement principalJson = JsonSerializer.SerializeToElement(principal, Json);
        string principalId = IdentidadDocumento(principalJson);
        var porId = new Dictionary<string, JsonElement>(StringComparer.Ordinal)
            { [principalId] = principalJson };
        var identidades = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var secundarios = new List<JsonElement>();
        foreach (var documento in documentos)
        {
            if (documento is null || string.IsNullOrWhiteSpace(documento.Id)) throw Invalido("El documento necesita una identidad canónica.");
            if (!identidades.Add(documento.Id)) throw Invalido("Identidades de documentos repetidas.");
            if (documento.Id.Equals(principalId, StringComparison.OrdinalIgnoreCase))
            {
                if (!ReferenceEquals(documento, principal)
                    && !JsonElement.DeepEquals(JsonSerializer.SerializeToElement(documento, Json), principalJson))
                    throw Invalido("La copia del documento principal tiene datos distintos.");
                continue;
            }
            var jsonDocumento = JsonSerializer.SerializeToElement(documento, Json);
            IdentidadDocumento(jsonDocumento);
            porId.Add(documento.Id, jsonDocumento); secundarios.Add(jsonDocumento);
        }
        var repeticiones = new Dictionary<string, int>(StringComparer.Ordinal);
        var referenciasDocumentos = new Dictionary<string, string?>(StringComparer.Ordinal);
        var nombresTablas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var tabla in tablas)
        {
            if (string.IsNullOrWhiteSpace(tabla.Nombre) || !nombresTablas.Add(tabla.Nombre))
                throw Invalido("Tablas inválidas o repetidas.");
            var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string columna in tabla.Columnas)
                if (string.IsNullOrWhiteSpace(columna) || !columnas.Add(columna)) throw Invalido("Columnas inválidas o repetidas.");
            foreach (var fila in tabla.Filas)
            {
                if (fila.Count != tabla.Columnas.Count) throw Invalido("Una fila no coincide con sus columnas.");
                for (int i = 0; i < fila.Count; i++)
                {
                    var celda = fila[i];
                    ValidarValor(celda.Tipo, celda.Valor);
                    ContarTexto(repeticiones, celda.Tipo, celda.Valor, tabla.Nombre, tabla.Columnas[i], porId, referenciasDocumentos);
                }
            }
        }
        string[] textos = ElegirTextos(repeticiones);
        var indices = textos.Select((texto, indice) => (texto, indice))
            .ToDictionary(x => x.texto, x => x.indice, StringComparer.Ordinal);
        return Escribir(writer =>
        {
            writer.WriteStartObject(); writer.WriteString("formato", "MYG_COLABORACION");
            writer.WriteNumber("version", 2); writer.WriteString("alcance", alcance);
            writer.WritePropertyName("documento"); principalJson.WriteTo(writer);
            writer.WritePropertyName("documentos"); writer.WriteStartArray();
            foreach (var documento in secundarios) documento.WriteTo(writer);
            writer.WriteEndArray(); writer.WritePropertyName("tablas"); writer.WriteStartArray();
            foreach (var tabla in tablas)
            {
                writer.WriteStartObject(); writer.WriteString("Nombre", tabla.Nombre);
                writer.WritePropertyName("Columnas"); JsonSerializer.Serialize(writer, tabla.Columnas, Json);
                writer.WritePropertyName("Filas"); writer.WriteStartArray();
                foreach (var fila in tabla.Filas)
                {
                    writer.WriteStartArray();
                    for (int i = 0; i < fila.Count; i++)
                        EscribirCeldaCompacta(writer, fila[i].Tipo, fila[i].Valor, tabla.Nombre, tabla.Columnas[i], porId, indices, referenciasDocumentos);
                    writer.WriteEndArray();
                }
                writer.WriteEndArray(); writer.WriteEndObject();
            }
            writer.WriteEndArray();
            writer.WritePropertyName("recursos"); JsonSerializer.Serialize(writer, recursos, Json);
            writer.WritePropertyName("avisos"); JsonSerializer.Serialize(writer, avisos, Json);
            writer.WriteString("exclusiones", Exclusiones);
            writer.WritePropertyName("textos"); JsonSerializer.Serialize(writer, textos, Json);
            writer.WriteEndObject();
        });
    }

    /// <summary>Codifica paquetes completos v1; deja intactos los documentos legados sin envoltura.</summary>
    public static JsonElement Compactar(JsonElement contenido)
    {
        if (EsCompacto(contenido))
        {
            ValidarCompacto(contenido);
            // Un intento compacto existente conserva representación y referencias;
            // las mejoras de escritura se aplican al crear una publicación nueva.
            return contenido.Clone();
        }
        if (contenido.ValueKind != JsonValueKind.Object
            || !contenido.TryGetProperty("formato", out var formato)
            || formato.ValueKind != JsonValueKind.String || formato.GetString() != "MYG_COLABORACION")
            return contenido.Clone();
        ValidarClaves(contenido, Claves, "paquete");
        if (!contenido.TryGetProperty("version", out var version) || version.ValueKind != JsonValueKind.Number
            || !version.TryGetInt32(out int numero) || numero != 1)
            throw Invalido("Versión de paquete no compatible.");
        ValidarCabecera(contenido);
        if (contenido.TryGetProperty("textos", out _)) throw Invalido("Un paquete anterior no puede declarar referencias compactas.");

        string principal = IdentidadDocumento(contenido.GetProperty("documento"));
        var documentos = new List<JsonElement>();
        var identidades = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        bool encontrado = false;
        foreach (var documento in contenido.GetProperty("documentos").EnumerateArray())
        {
            string id = IdentidadDocumento(documento);
            if (!identidades.Add(id)) throw Invalido("Identidades de documentos repetidas.");
            if (id.Equals(principal, StringComparison.OrdinalIgnoreCase))
            {
                if (!JsonElement.DeepEquals(documento, contenido.GetProperty("documento")))
                    throw Invalido("La copia del documento principal tiene datos distintos.");
                encontrado = true;
            }
            else documentos.Add(documento);
        }
        // Una envoltura v1 incompleta no debe convertirse silenciosamente en otra solicitud.
        if (!encontrado) throw Invalido("Falta la copia del documento principal en la versión anterior.");

        var porId = documentos.Append(contenido.GetProperty("documento"))
            .ToDictionary(x => IdentidadDocumento(x), x => x, StringComparer.Ordinal);
        var repeticiones = new Dictionary<string, int>(StringComparer.Ordinal);
        var referenciasDocumentos = new Dictionary<string, string?>(StringComparer.Ordinal);
        foreach (var tabla in contenido.GetProperty("tablas").EnumerateArray())
        {
            ValidarTabla(tabla);
            foreach (var fila in tabla.GetProperty("Filas").EnumerateArray())
                for (int i = 0; i < fila.GetArrayLength(); i++)
                {
                    var (tipo, valor) = LeerCeldaAnterior(fila[i]);
                    ContarTexto(repeticiones, tipo, valor, tabla.GetProperty("Nombre").GetString()!,
                        tabla.GetProperty("Columnas")[i].GetString()!, porId, referenciasDocumentos);
                }
        }
        var textos = ElegirTextos(repeticiones);
        var indices = textos.Select((texto, indice) => (texto, indice))
            .ToDictionary(x => x.texto, x => x.indice, StringComparer.Ordinal);

        return Escribir(writer =>
        {
            writer.WriteStartObject();
            foreach (var propiedad in contenido.EnumerateObject())
            {
                writer.WritePropertyName(propiedad.Name);
                switch (propiedad.Name)
                {
                    case "version": writer.WriteNumberValue(2); break;
                    case "documentos":
                        writer.WriteStartArray();
                        foreach (var documento in documentos) documento.WriteTo(writer);
                        writer.WriteEndArray();
                        break;
                    case "tablas":
                        EscribirTablas(writer, propiedad.Value, (celda, tabla, columna) =>
                        {
                            var (tipo, valor) = LeerCeldaAnterior(celda);
                            EscribirCeldaCompacta(writer, tipo, valor, tabla, columna, porId, indices, referenciasDocumentos);
                        });
                        break;
                    default: propiedad.Value.WriteTo(writer); break;
                }
            }
            writer.WritePropertyName("textos");
            writer.WriteStartArray();
            foreach (string texto in textos) writer.WriteStringValue(texto);
            writer.WriteEndArray(); writer.WriteEndObject();
        });
    }

    /// <summary>Entrega la representación v1 a los lectores existentes; los paquetes v1 no se reescriben.</summary>
    public static JsonElement Expandir(JsonElement contenido)
    {
        if (!EsCompacto(contenido)) return contenido.Clone();
        string[] textos = ValidarCompacto(contenido);
        var documentos = contenido.GetProperty("documentos").EnumerateArray().Append(contenido.GetProperty("documento"))
            .ToDictionary(x => IdentidadDocumento(x), x => x, StringComparer.Ordinal);
        return Escribir(writer =>
        {
            writer.WriteStartObject();
            foreach (var propiedad in contenido.EnumerateObject())
            {
                if (propiedad.Name == "textos") continue;
                writer.WritePropertyName(propiedad.Name);
                switch (propiedad.Name)
                {
                    case "version": writer.WriteNumberValue(1); break;
                    case "documentos":
                        writer.WriteStartArray();
                        foreach (var documento in propiedad.Value.EnumerateArray()) documento.WriteTo(writer);
                        contenido.GetProperty("documento").WriteTo(writer);
                        writer.WriteEndArray();
                        break;
                    case "tablas":
                        EscribirTablas(writer, propiedad.Value, (celda, tabla, columna) =>
                        {
                            var (tipo, valor) = LeerCeldaCompacta(celda, textos, documentos, tabla, columna);
                            writer.WriteStartObject(); writer.WriteString("Tipo", tipo);
                            writer.WritePropertyName("Valor");
                            if (valor is null) writer.WriteNullValue(); else writer.WriteStringValue(valor);
                            writer.WriteEndObject();
                        });
                        break;
                    default: propiedad.Value.WriteTo(writer); break;
                }
            }
            writer.WriteEndObject();
        });
    }

    private static string[] ValidarCompacto(JsonElement contenido)
    {
        ValidarClaves(contenido, Claves, "paquete");
        ValidarCabecera(contenido);
        string principal = IdentidadDocumento(contenido.GetProperty("documento"));
        var identidades = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { principal };
        foreach (var documento in contenido.GetProperty("documentos").EnumerateArray())
            if (!identidades.Add(IdentidadDocumento(documento))) throw Invalido("Identidades de documentos repetidas.");
        if (!contenido.TryGetProperty("textos", out var diccionario) || diccionario.ValueKind != JsonValueKind.Array)
            throw Invalido("Falta el diccionario de textos compactos.");
        var textos = new List<string>();
        var unicos = new HashSet<string>(StringComparer.Ordinal);
        foreach (var texto in diccionario.EnumerateArray())
        {
            if (texto.ValueKind != JsonValueKind.String || !unicos.Add(texto.GetString()!))
                throw Invalido("El diccionario contiene textos inválidos o repetidos.");
            textos.Add(texto.GetString()!);
        }
        var conjunto = textos.ToArray();
        var documentosPorId = contenido.GetProperty("documentos").EnumerateArray().Append(contenido.GetProperty("documento"))
            .ToDictionary(x => IdentidadDocumento(x), x => x, StringComparer.Ordinal);
        long bytesEstimados = 0;
        var tablas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var tabla in contenido.GetProperty("tablas").EnumerateArray())
        {
            ValidarTabla(tabla);
            if (!tablas.Add(tabla.GetProperty("Nombre").GetString()!)) throw Invalido("Tablas repetidas.");
            foreach (var fila in tabla.GetProperty("Filas").EnumerateArray())
                for (int i = 0; i < fila.GetArrayLength(); i++)
                {
                    var (_, valor) = LeerCeldaCompacta(fila[i], conjunto, documentosPorId, tabla.GetProperty("Nombre").GetString()!, tabla.GetProperty("Columnas")[i].GetString()!);
                    // Las referencias no pueden convertir un paquete pequeño en una expansión ilimitada.
                    bytesEstimados += valor is null ? 28 : 32L + Encoding.UTF8.GetByteCount(valor);
                    if (bytesEstimados > MaxBytesExpandidos) throw Invalido("La expansión supera el máximo de 512 MiB.");
                }
        }
        return conjunto;
    }

    private static void ValidarCabecera(JsonElement contenido)
    {
        if (!contenido.TryGetProperty("formato", out var formato) || formato.ValueKind != JsonValueKind.String
            || formato.GetString() != "MYG_COLABORACION"
            || !contenido.TryGetProperty("alcance", out var alcance) || alcance.ValueKind != JsonValueKind.String
            || alcance.GetString() is not ("obra" or "base")
            || !contenido.TryGetProperty("documento", out var documento) || documento.ValueKind != JsonValueKind.Object
            || !contenido.TryGetProperty("documentos", out var documentos) || documentos.ValueKind != JsonValueKind.Array
            || !contenido.TryGetProperty("tablas", out var tablas) || tablas.ValueKind != JsonValueKind.Array
            || !contenido.TryGetProperty("recursos", out var recursos) || recursos.ValueKind != JsonValueKind.Array)
            throw Invalido("Envoltura de colaboración no válida.");
    }

    private static string IdentidadDocumento(JsonElement documento)
    {
        if (documento.ValueKind != JsonValueKind.Object || !documento.TryGetProperty("Id", out var id)
            || id.ValueKind != JsonValueKind.String || string.IsNullOrWhiteSpace(id.GetString()))
            throw Invalido("El documento necesita una identidad canónica.");
        var propiedades = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var propiedad in documento.EnumerateObject())
            if (!propiedades.Add(propiedad.Name)) throw Invalido("Propiedades ambiguas en el documento.");
        return id.GetString()!;
    }

    private static void ValidarTabla(JsonElement tabla)
    {
        ValidarClaves(tabla, ClavesTabla, "tabla");
        if (!tabla.TryGetProperty("Nombre", out var nombre) || nombre.ValueKind != JsonValueKind.String || string.IsNullOrWhiteSpace(nombre.GetString())
            || !tabla.TryGetProperty("Columnas", out var columnas) || columnas.ValueKind != JsonValueKind.Array
            || !tabla.TryGetProperty("Filas", out var filas) || filas.ValueKind != JsonValueKind.Array)
            throw Invalido("Tabla portable no válida.");
        var nombres = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var columna in columnas.EnumerateArray())
            if (columna.ValueKind != JsonValueKind.String || string.IsNullOrWhiteSpace(columna.GetString()) || !nombres.Add(columna.GetString()!))
                throw Invalido("Columnas inválidas o repetidas.");
        foreach (var fila in filas.EnumerateArray())
            if (fila.ValueKind != JsonValueKind.Array || fila.GetArrayLength() != columnas.GetArrayLength())
                throw Invalido("Una fila no coincide con sus columnas.");
    }

    private static (string Tipo, string? Valor) LeerCeldaAnterior(JsonElement celda)
    {
        ValidarClaves(celda, ClavesCelda, "celda");
        if (!celda.TryGetProperty("Tipo", out var tipo) || tipo.ValueKind != JsonValueKind.String
            || !celda.TryGetProperty("Valor", out var valor)) throw Invalido("Celda anterior no válida.");
        string nombre = tipo.GetString()!;
        if (nombre == "nulo" && valor.ValueKind == JsonValueKind.Null) return (nombre, null);
        if (valor.ValueKind != JsonValueKind.String)
            throw Invalido("Tipo o valor de celda anterior no válido.");
        ValidarValor(nombre, valor.GetString());
        return (nombre, valor.GetString());
    }

    private static void ValidarValor(string tipo, string? valor)
    {
        if (tipo == "nulo" && valor is null) return;
        if (tipo is not ("texto" or "entero" or "real" or "blob") || valor is null)
            throw Invalido("Tipo o valor de celda no válido.");
        ValidarNumero(tipo, valor);
    }

    private static void ContarTexto(Dictionary<string, int> repeticiones, string tipo, string? valor,
        string tabla, string columna, Dictionary<string, JsonElement> documentos, Dictionary<string, string?> referenciasDocumentos)
    {
        if (tipo != "texto" || ReferenciaDocumento(valor!, tabla, columna, documentos, referenciasDocumentos) != null) return;
        repeticiones[valor!] = repeticiones.TryGetValue(valor!, out int cantidad) ? cantidad + 1 : 1;
    }

    private static string[] ElegirTextos(Dictionary<string, int> repeticiones)
    {
        var textos = new List<string>();
        // Se conserva la primera aparición, también para códigos y UUID cortos.
        // Cada entrada debe ahorrar bytes incluyendo su literal, su coma y TODAS
        // sus referencias con el índice definitivo; no se eligen por longitud UTF-16.
        foreach (var (texto, cantidad) in repeticiones)
        {
            if (cantidad < 2) continue;
            long literal = JsonEncodedText.Encode(texto, JavaScriptEncoder.UnsafeRelaxedJsonEscaping).EncodedUtf8Bytes.Length + 2L;
            int referencia = 6 + textos.Count.ToString(CultureInfo.InvariantCulture).Length; // ["s",índice]
            long entrada = literal + (textos.Count == 0 ? 0 : 1);
            if ((long)cantidad * (literal - referencia) > entrada) textos.Add(texto);
        }
        return textos.ToArray();
    }

    private static string? ReferenciaDocumento(string texto, string tabla, string columna,
        Dictionary<string, JsonElement> documentos, Dictionary<string, string?> referenciasDocumentos)
    {
        if (tabla != "myg_proyecto" || columna != "json_documento") return null;
        // Solo se analiza la columna autorizada, una vez por texto distinto. La
        // escritura reutiliza el resultado sin analizar otra vez documentos grandes.
        if (!referenciasDocumentos.TryGetValue(texto, out string? referencia))
        {
            referencia = DocumentoReferido(texto, documentos);
            referenciasDocumentos.Add(texto, referencia);
        }
        return referencia;
    }

    private static void EscribirCeldaCompacta(Utf8JsonWriter writer, string tipo, string? valor,
        string tabla, string columna, Dictionary<string, JsonElement> documentos, Dictionary<string, int> textos,
        Dictionary<string, string?> referenciasDocumentos)
    {
        string? referencia = tipo == "texto"
            ? ReferenciaDocumento(valor!, tabla, columna, documentos, referenciasDocumentos) : null;
        if (referencia != null)
        {
            writer.WriteStartArray(); writer.WriteStringValue("d"); writer.WriteStringValue(referencia); writer.WriteEndArray();
        }
        else if (tipo == "nulo") writer.WriteNullValue();
        else if (tipo == "texto" && !textos.ContainsKey(valor!)) writer.WriteStringValue(valor);
        else
        {
            writer.WriteStartArray();
            if (tipo == "texto")
            {
                writer.WriteStringValue("s"); writer.WriteNumberValue(textos[valor!]);
            }
            else
            {
                writer.WriteStringValue(tipo switch { "entero" => "i", "real" => "r", "blob" => "b", _ => throw Invalido("Tipo desconocido.") });
                writer.WriteStringValue(valor);
            }
            writer.WriteEndArray();
        }
    }

    private static (string Tipo, string? Valor) LeerCeldaCompacta(JsonElement celda, string[] textos,
        Dictionary<string, JsonElement> documentos, string tabla, string columna)
    {
        if (celda.ValueKind == JsonValueKind.Null) return ("nulo", null);
        if (celda.ValueKind == JsonValueKind.String) return ("texto", celda.GetString());
        if (celda.ValueKind != JsonValueKind.Array || celda.GetArrayLength() != 2 || celda[0].ValueKind != JsonValueKind.String)
            throw Invalido("Celda compacta no válida.");
        string etiqueta = celda[0].GetString()!;
        if (etiqueta == "d")
        {
            if (tabla != "myg_proyecto" || columna != "json_documento" || celda[1].ValueKind != JsonValueKind.String
                || !documentos.TryGetValue(celda[1].GetString()!, out var documento))
                throw Invalido("Referencia de documento inexistente o fuera de su columna autorizada.");
            return ("texto", documento.GetRawText());
        }
        if (etiqueta == "s")
        {
            if (celda[1].ValueKind != JsonValueKind.Number || !celda[1].TryGetInt32(out int indice) || indice < 0 || indice >= textos.Length)
                throw Invalido("Referencia de texto inexistente.");
            return ("texto", textos[indice]);
        }
        string tipo = etiqueta switch { "i" => "entero", "r" => "real", "b" => "blob", _ => throw Invalido("Etiqueta de celda desconocida.") };
        if (celda[1].ValueKind != JsonValueKind.String) throw Invalido("Valor compacto no válido.");
        string valor = celda[1].GetString()!;
        ValidarNumero(tipo, valor);
        return (tipo, valor);
    }

    private static void ValidarNumero(string tipo, string valor)
    {
        if (tipo == "entero" && !long.TryParse(valor, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out _))
            throw Invalido("Entero SQLite fuera de rango.");
        if (tipo == "blob" && !Base64Valido(valor)) throw Invalido("Binario Base64 no válido.");
        if (tipo == "real" && (!double.TryParse(valor, NumberStyles.Float, CultureInfo.InvariantCulture, out double numero) || !double.IsFinite(numero)))
            throw Invalido("Número SQLite no finito.");
    }

    private static string? DocumentoReferido(string texto, Dictionary<string, JsonElement> documentos)
    {
        try
        {
            using var candidato = JsonDocument.Parse(texto, new JsonDocumentOptions { MaxDepth = 128 });
            if (candidato.RootElement.ValueKind != JsonValueKind.Object
                || !candidato.RootElement.TryGetProperty("Id", out var id) || id.ValueKind != JsonValueKind.String
                || !documentos.TryGetValue(id.GetString()!, out var documento)) return null;
            return JsonElement.DeepEquals(candidato.RootElement, documento) ? id.GetString() : null;
        }
        catch (JsonException) { return null; }
    }

    private static bool Base64Valido(string texto)
    {
        long caracteres = 0; int relleno = 0;
        foreach (char c in texto)
        {
            if (c is ' ' or '\t' or '\r' or '\n') continue;
            caracteres++;
            if (c == '=') { if (++relleno > 2) return false; }
            else if (relleno != 0 || !(c is >= 'A' and <= 'Z' or >= 'a' and <= 'z' or >= '0' and <= '9' or '+' or '/')) return false;
        }
        return caracteres % 4 == 0;
    }

    private static void ValidarClaves(JsonElement objeto, HashSet<string> permitidas, string nombre)
    {
        if (objeto.ValueKind != JsonValueKind.Object) throw Invalido("Se esperaba un objeto de " + nombre + ".");
        var vistas = new HashSet<string>(StringComparer.Ordinal);
        foreach (var propiedad in objeto.EnumerateObject())
            if (!permitidas.Contains(propiedad.Name) || !vistas.Add(propiedad.Name))
                throw Invalido("Propiedad no compatible o repetida en " + nombre + ".");
    }

    private static void EscribirTablas(Utf8JsonWriter writer, JsonElement tablas, Action<JsonElement, string, string> escribirCelda)
    {
        writer.WriteStartArray();
        foreach (var tabla in tablas.EnumerateArray())
        {
            writer.WriteStartObject();
            foreach (var propiedad in tabla.EnumerateObject())
            {
                writer.WritePropertyName(propiedad.Name);
                if (propiedad.Name != "Filas") { propiedad.Value.WriteTo(writer); continue; }
                writer.WriteStartArray();
                foreach (var fila in propiedad.Value.EnumerateArray())
                {
                    writer.WriteStartArray();
                    for (int i = 0; i < fila.GetArrayLength(); i++)
                        escribirCelda(fila[i], tabla.GetProperty("Nombre").GetString()!, tabla.GetProperty("Columnas")[i].GetString()!);
                    writer.WriteEndArray();
                }
                writer.WriteEndArray();
            }
            writer.WriteEndObject();
        }
        writer.WriteEndArray();
    }

    private static JsonElement Escribir(Action<Utf8JsonWriter> escribir)
    {
        var buffer = new BufferLimitado();
        using (var writer = new Utf8JsonWriter(buffer, new JsonWriterOptions
            { MaxDepth = 128, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping })) escribir(writer);
        using var documento = JsonDocument.Parse(buffer.WrittenMemory, new JsonDocumentOptions { MaxDepth = 128 });
        return documento.RootElement.Clone();
    }

    private sealed class BufferLimitado : IBufferWriter<byte>
    {
        private readonly ArrayBufferWriter<byte> buffer = new();
        public ReadOnlyMemory<byte> WrittenMemory => buffer.WrittenMemory;
        public void Advance(int count)
        {
            Comprobar(count); buffer.Advance(count);
        }
        public Memory<byte> GetMemory(int sizeHint = 0)
        {
            Comprobar(Math.Max(sizeHint, 1));
            var memoria = buffer.GetMemory(sizeHint);
            return memoria[..(int)Math.Min(memoria.Length, MaxBytesExpandidos - buffer.WrittenCount)];
        }
        public Span<byte> GetSpan(int sizeHint = 0) => GetMemory(sizeHint).Span;
        private void Comprobar(int adicional)
        {
            if (adicional < 0 || buffer.WrittenCount + (long)adicional > MaxBytesExpandidos)
                throw Invalido("La expansión supera el máximo de 512 MiB.");
        }
    }

    private static InvalidDataException Invalido(string mensaje) => new("Paquete compacto: " + mensaje);
}
