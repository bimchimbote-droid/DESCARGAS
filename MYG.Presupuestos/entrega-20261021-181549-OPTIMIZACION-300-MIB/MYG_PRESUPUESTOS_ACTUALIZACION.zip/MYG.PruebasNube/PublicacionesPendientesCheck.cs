using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

internal static class PublicacionesPendientesCheck
{
    private const string Servidor = "https://pruebas.supabase.co";
    private const string Usuario = "11111111-1111-4111-8111-111111111111";
    private static readonly Guid IdA = Guid.Parse("22222222-2222-4222-8222-222222222222");
    private static readonly Guid IdB = Guid.Parse("33333333-3333-4333-8333-333333333333");
    private static int comprobaciones;

    public static Task RunAsync()
    {
        comprobaciones = 0;
        string raiz = Path.Combine(Path.GetTempPath(), "myg-publicaciones-pendientes-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(raiz);
        try
        {
            CompatibilidadYRetiro(Path.Combine(raiz, "compatibilidad"));
            SerializacionReducida(Path.Combine(raiz, "serializacion"));
            Aislamiento(Path.Combine(raiz, "aislamiento"));
            CambiosConcurrentes(Path.Combine(raiz, "cambios"));
            CorruptosYGrandes(Path.Combine(raiz, "grandes"));
            Validaciones(Path.Combine(raiz, "validaciones"));
            Console.WriteLine($"OK Publicaciones pendientes: {comprobaciones} comprobaciones de recuperación, retiro reversible, aislamiento y tamaño; sin red.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(raiz, recursive: true); }
    }

    private static ArchivoPublicacionPendienteNube Archivo(string carpeta, string servidor = Servidor, string usuario = Usuario) =>
        new(carpeta, servidor, usuario);

    private static JsonElement Contenido(string json = "{\"obra\":\"sintética\"}")
    {
        using var documento = JsonDocument.Parse(json, new JsonDocumentOptions { MaxDepth = 128 });
        return documento.RootElement.Clone();
    }

    private static PublicacionPendienteNube Publicacion(Guid? id = null) => new(id ?? IdA, "Obra sintética Áncash", "base", Contenido());

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Publicaciones pendientes: " + detalle);
    }

    private static void Rechaza<T>(Action accion, string detalle) where T : Exception
    {
        comprobaciones++;
        try { accion(); }
        catch (T) { return; }
        throw new InvalidOperationException("Publicaciones pendientes: " + detalle);
    }

    private static void CompatibilidadYRetiro(string carpeta)
    {
        var archivo = Archivo(carpeta);
        Exige(archivo.Consultar() is null && !Directory.Exists(carpeta), "consultar una cuenta sin intentos creó archivos o mostró un pendiente.");
        string ambitoAnterior = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Servidor + "\n" + Usuario)));
        Exige(archivo.RutaActiva == Path.Combine(Path.GetFullPath(carpeta), ambitoAnterior + ".json"),
            "cambió la ruta de los pendientes guardados por versiones anteriores.");
        Directory.CreateDirectory(carpeta);
        // Contrato anterior, con formato y campos adicionales que un retiro debe conservar.
        string anterior = "{\n  \"Id\":\"" + IdA + "\",\"Nombre\":\"Obra Áncash\",\"Alcance\":\"base\","
            + "\"ExtensionFutura\":{\"Id\":\"no-confundir-con-identidad\",\"dato\":\"conservar\"},\"Contenido\":{\"cantidad\":1.1234567890123456789}}\n";
        File.WriteAllText(archivo.RutaActiva, anterior, new UTF8Encoding(false));
        byte[] bytes = File.ReadAllBytes(archivo.RutaActiva);
        var resumen = archivo.Consultar()!;
        Exige(resumen.DatosLegibles && resumen.Id == IdA && resumen.Nombre == "Obra Áncash" && resumen.Alcance == "base",
            "no se recuperaron los metadatos de un pendiente anterior.");
        Exige(resumen.BytesArchivo == bytes.LongLength && resumen.FechaUtc.Kind == DateTimeKind.Utc,
            "el resumen no muestra los bytes reales guardados o su fecha UTC.");
        var recuperada = archivo.Leer(resumen);
        Exige(recuperada.Id == IdA && recuperada.Contenido.GetProperty("cantidad").GetDecimal() == 1.1234567890123456789m,
            "leer un pendiente anterior cambió su identidad o la precisión del contenido.");
        Rechaza<IOException>(() => archivo.Guardar(Publicacion(IdB)), "guardar sobrescribió un intento no confirmado.");
        Exige(File.ReadAllBytes(archivo.RutaActiva).SequenceEqual(bytes), "rechazar una sobrescritura cambió el intento original.");
        string respaldo = archivo.Retirar(resumen);
        Exige(!File.Exists(archivo.RutaActiva) && archivo.Consultar() is null && File.ReadAllBytes(respaldo).SequenceEqual(bytes),
            "retirar no conservó exactamente el archivo anterior y sus campos desconocidos.");
        Exige(Path.GetDirectoryName(respaldo) == Path.Combine(Path.GetFullPath(carpeta), "retiradas", ambitoAnterior),
            "el retiro no quedó dentro del archivo del ámbito correcto.");
        archivo.Guardar(Publicacion(IdB));
        var nueva = archivo.Consultar()!;
        Exige(nueva.Id == IdB && archivo.Leer(nueva).Id == IdB, "retirar el intento anterior no permitió crear uno nuevo.");
        string segundo = archivo.Retirar(nueva);
        Exige(segundo != respaldo && File.Exists(segundo) && File.ReadAllBytes(respaldo).SequenceEqual(bytes),
            "un segundo retiro sustituyó un respaldo anterior.");
        Exige(!Directory.EnumerateFiles(carpeta, "*.tmp").Any(), "guardar dejó temporales de preparación.");
    }

    private static void SerializacionReducida(string carpeta)
    {
        // JSON nativo guardado como texto: las comillas no deben ocupar seis bytes.
        string texto = string.Concat(Enumerable.Repeat("{\"nombre\":\"Áncash 漢字 <dato>&\",\"ruta\":\"C:\\\\obra\"}\n", 600));
        var publicacion = Publicacion() with
        {
            Contenido = JsonSerializer.SerializeToElement(new { json_nativo = texto, control = "\u0001\t\r\n" })
        };
        long anterior = JsonSerializer.SerializeToUtf8Bytes(publicacion).LongLength;
        var archivo = Archivo(carpeta);
        archivo.Guardar(publicacion);
        var resumen = archivo.Consultar()!;
        Exige(resumen.BytesArchivo < anterior * 0.75,
            "el archivo pendiente volvió a inflar las comillas y los caracteres Unicode del contenido.");
        var leida = archivo.Leer(resumen);
        Exige(JsonElement.DeepEquals(publicacion.Contenido, leida.Contenido)
            && leida.Contenido.GetProperty("json_nativo").GetString() == texto,
            "el ahorro cambió comillas, rutas, controles, Unicode o datos que parecen HTML.");
        byte[] antes = File.ReadAllBytes(archivo.RutaActiva);
        string retirada = archivo.Retirar(resumen);
        Exige(File.ReadAllBytes(retirada).SequenceEqual(antes),
            "retirar una publicación optimizada cambió sus bytes o su identificador.");
    }

    private static void Aislamiento(string carpeta)
    {
        var propia = Archivo(carpeta);
        var otraCuenta = Archivo(carpeta, usuario: "44444444-4444-4444-8444-444444444444");
        var otroServidor = Archivo(carpeta, servidor: "https://otro.supabase.co");
        otraCuenta.Guardar(Publicacion(IdB));
        otroServidor.Guardar(Publicacion(IdB));
        Exige(propia.Consultar() is null, "la cuenta actual mostró intentos de otra cuenta o servidor.");
        propia.Guardar(Publicacion());
        var actual = propia.Consultar()!;
        var ajena = otraCuenta.Consultar()!;
        Rechaza<InvalidOperationException>(() => propia.Leer(ajena), "se aceptó leer un resumen de otra cuenta.");
        Rechaza<InvalidOperationException>(() => propia.Retirar(ajena), "se retiró un intento mediante un resumen de otra cuenta.");
        Rechaza<InvalidOperationException>(() => propia.Confirmar(ajena), "se confirmó un intento de otra cuenta.");
        var manipulada = actual with { Ambito = "../../otra-cuenta" };
        Rechaza<InvalidOperationException>(() => propia.Retirar(manipulada), "se aceptó una ruta introducida en el ámbito del resumen.");
        propia.Confirmar(actual);
        Exige(propia.Consultar() is null && otraCuenta.Leer(ajena).Id == IdB && otroServidor.Consultar()?.Id == IdB,
            "confirmar el intento actual afectó archivos de otras cuentas o servidores.");
    }

    private static void CambiosConcurrentes(string carpeta)
    {
        var archivo = Archivo(carpeta);
        archivo.Guardar(Publicacion());
        var anterior = archivo.Consultar()!;
        // Mismo UUID y contenido con un byte adicional: cambia la versión por tamaño.
        File.AppendAllText(archivo.RutaActiva, " ");
        Rechaza<InvalidOperationException>(() => archivo.Leer(anterior), "leer aceptó un archivo que cambió desde la selección.");
        Rechaza<InvalidOperationException>(() => archivo.Retirar(anterior), "retirar aceptó un archivo que cambió desde la selección.");
        Rechaza<InvalidOperationException>(() => archivo.Confirmar(anterior), "confirmar eliminó una versión distinta de la confirmada.");
        var actual = archivo.Consultar()!;
        File.SetLastWriteTimeUtc(archivo.RutaActiva, actual.FechaUtc.AddSeconds(2));
        Rechaza<InvalidOperationException>(() => archivo.Confirmar(actual), "se ignoró el cambio de fecha con tamaño e identidad iguales.");
        actual = archivo.Consultar()!;
        string texto = File.ReadAllText(archivo.RutaActiva).Replace(IdA.ToString(), IdB.ToString(), StringComparison.Ordinal);
        File.WriteAllText(archivo.RutaActiva, texto, new UTF8Encoding(false));
        File.SetLastWriteTimeUtc(archivo.RutaActiva, actual.FechaUtc);
        Rechaza<InvalidOperationException>(() => archivo.Confirmar(actual), "se ignoró el cambio de identidad con tamaño y fecha iguales.");
        var reemplazada = archivo.Consultar()!;
        Exige(reemplazada.Id == IdB, "el resumen no reflejó el intento reemplazado.");
        archivo.Confirmar(reemplazada);
        Exige(!File.Exists(archivo.RutaActiva), "confirmar la versión esperada no retiró su archivo activo.");
    }

    private static void CorruptosYGrandes(string carpeta)
    {
        var archivo = Archivo(carpeta);
        Directory.CreateDirectory(carpeta);
        byte[] corrupto = Encoding.UTF8.GetBytes("NO ES JSON\n");
        File.WriteAllBytes(archivo.RutaActiva, corrupto);
        var resumen = archivo.Consultar()!;
        Exige(!resumen.DatosLegibles, "el resumen presentó un archivo corrupto como legible.");
        Rechaza<InvalidDataException>(() => archivo.Leer(resumen), "leer aceptó un archivo corrupto.");
        string respaldo = archivo.Retirar(resumen);
        Exige(File.ReadAllBytes(respaldo).SequenceEqual(corrupto) && archivo.Consultar() is null,
            "no se pudo retirar y conservar un intento corrupto.");

        byte[] utf8Invalido = Encoding.UTF8.GetBytes("{\"Id\":\"" + IdA + "\",\"Nombre\":\"")
            .Concat(new byte[] { 255 }).Concat(Encoding.UTF8.GetBytes("\",\"Alcance\":\"base\",\"Contenido\":{}}")).ToArray();
        File.WriteAllBytes(archivo.RutaActiva, utf8Invalido);
        resumen = archivo.Consultar()!;
        Exige(!resumen.DatosLegibles, "una cabecera con UTF-8 inválido impidió consultar y retirar el intento.");
        respaldo = archivo.Retirar(resumen);
        Exige(File.ReadAllBytes(respaldo).SequenceEqual(utf8Invalido), "retirar una cabecera UTF-8 inválida cambió sus bytes originales.");

        var grande = Publicacion() with { Contenido = Contenido("{\"texto\":\"" + new string('x', 256 * 1024) + "\"}") };
        archivo.Guardar(grande);
        resumen = archivo.Consultar()!;
        Exige(resumen.DatosLegibles && resumen.Id == IdA && resumen.BytesArchivo > 64 * 1024,
            "consultar un archivo mayor que el prefijo perdió su cabecera o su tamaño.");
        Exige(archivo.Leer(resumen).Contenido.GetProperty("texto").GetString()?.Length == 256 * 1024,
            "la lectura de metadatos truncó el contenido completo al reintentar.");
        archivo.Retirar(resumen);

        // El prefijo es legible, pero el contenido posterior no: consultar no debe cargar/validar todo el paquete.
        string cabecera = "{\"Id\":\"" + IdA + "\",\"Nombre\":\"Cabecera legible\",\"Alcance\":\"obra\",\"Contenido\":{";
        File.WriteAllText(archivo.RutaActiva, cabecera + new string('x', 512 * 1024), new UTF8Encoding(false));
        resumen = archivo.Consultar()!;
        Exige(resumen.DatosLegibles && resumen.Nombre == "Cabecera legible" && resumen.BytesArchivo > 64 * 1024,
            "consultar intentó validar el contenido que sigue al prefijo de metadatos.");
        Rechaza<InvalidDataException>(() => archivo.Leer(resumen), "leer no detectó un contenido truncado tras la cabecera legible.");
        archivo.Retirar(resumen);

        string duplicada = "{\"Id\":\"" + IdA + "\",\"Nombre\":\"Identidad duplicada\",\"Alcance\":\"base\",\"Contenido\":{},\"Id\":\"" + IdB + "\"}";
        File.WriteAllText(archivo.RutaActiva, duplicada, new UTF8Encoding(false));
        resumen = archivo.Consultar()!;
        Rechaza<InvalidDataException>(() => archivo.Leer(resumen), "la lectura cambió el UUID seleccionado mediante una propiedad duplicada.");
        archivo.Retirar(resumen);

        var profundo = Publicacion() with { Contenido = Contenido("{\"nodo\":" + new string('[', 90) + "0" + new string(']', 90) + "}") };
        archivo.Guardar(profundo);
        Exige(archivo.Leer(archivo.Consultar()).Contenido.GetProperty("nodo").ValueKind == JsonValueKind.Array,
            "la recuperación heredó el límite JSON predeterminado de 64 niveles.");
    }

    private static void Validaciones(string carpeta)
    {
        var archivo = Archivo(carpeta);
        foreach (var invalida in new[]
        {
            Publicacion(Guid.Empty), Publicacion() with { Nombre = " " },
            Publicacion() with { Nombre = "Texto\nno válido" }, Publicacion() with { Alcance = "ajeno" },
            Publicacion() with { Contenido = Contenido("[]") }
        })
            Rechaza<InvalidDataException>(() => archivo.Guardar(invalida), "se guardó una publicación con metadatos o contenido inválidos.");
        Exige(!File.Exists(archivo.RutaActiva), "una publicación inválida dejó un archivo activo.");
    }
}
