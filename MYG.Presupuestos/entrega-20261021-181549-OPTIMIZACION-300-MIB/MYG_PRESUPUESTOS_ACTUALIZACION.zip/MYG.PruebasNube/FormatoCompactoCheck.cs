using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class FormatoCompactoCheck
{
    public static Task RunAsync()
    {
        int comprobaciones = 0;
        void Exige(bool condicion, string mensaje)
        {
            comprobaciones++;
            if (!condicion) throw new InvalidOperationException("Formato compacto: " + mensaje);
        }
        void Rechaza(JsonNode contenido, string mensaje)
        {
            bool rechazo = false;
            try { FormatoPaqueteNube.Expandir(JsonSerializer.SerializeToElement(contenido)); }
            catch (InvalidDataException) { rechazo = true; }
            Exige(rechazo, mensaje);
        }

        CeldasExactas(Exige, Rechaza);
        EscapesCompactos(Exige);
        DiccionarioPorCosto(Exige);
        ReferenciasDocumento(Exige, Rechaza);
        LimitarExpansion(Rechaza);
        MedirPaqueteRepresentativo(Exige);
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-compacto-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            BaseSQLite(carpeta, Exige);
            MetadatosPendientes(carpeta, Exige);
            Console.WriteLine($"OK Formato compacto: {comprobaciones} comprobaciones de tipos, rechazo de formatos ambiguos, tamaño, SQLite y adjuntos.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static void EscapesCompactos(Action<bool, string> exige)
    {
        // Es JSON de datos: las etiquetas HTML, comillas, controles y Unicode
        // se restituyen como texto; no se insertan en un documento HTML.
        const string texto = "{\"Descripción\":\"á漢字😀 <script>dato</script> & + ' \\\"\",\"control\":\"\u0001\r\n\t\\\"}";
        var original = Paquete(new[] { new PaqueteNube.Tabla
        {
            Nombre = "json_y_unicode", Columnas = new() { "dato" },
            Filas = new() { new() { Celda("texto", texto) } }
        } });
        var compacto = FormatoPaqueteNube.Compactar(original);
        string bytes = compacto.GetRawText();
        exige(compacto.GetProperty("tablas")[0].GetProperty("Filas")[0][0].GetString() == texto,
            "la escritura UTF-8 cambió los caracteres del texto JSON anidado.");
        exige(bytes.Contains("á漢字", StringComparison.Ordinal)
            && bytes.Contains("\\\"Descripción\\\"", StringComparison.Ordinal)
            && !bytes.Contains("\\u0022", StringComparison.Ordinal),
            "se inflaron Unicode o las comillas de un JSON guardado como texto.");
        exige(bytes.Contains("\\u0001", StringComparison.Ordinal) && bytes.Contains("\\r\\n\\t", StringComparison.Ordinal)
            && !bytes.Contains('\u0001'), "la escritura compacta dejó controles sin escapar.");
        exige(bytes.Contains("<script>dato</script> & + '", StringComparison.Ordinal),
            "la codificación de datos cambió los caracteres de un texto parecido a HTML.");
        exige(JsonElement.DeepEquals(original.GetProperty("tablas"), FormatoPaqueteNube.Expandir(compacto).GetProperty("tablas")),
            "expandir UTF-8 perdió valores exactos de JSON, Unicode o controles.");
        byte[] anterior = JsonSerializer.SerializeToUtf8Bytes(compacto);
        exige(Encoding.UTF8.GetByteCount(bytes) < anterior.Length,
            "evitar escapes innecesarios no redujo la representación JSON.");
        // Las publicaciones compactas ya guardadas siguen siendo inmutables:
        // no se reescriben al leerlas, aunque utilicen los escapes anteriores.
        using var existente = JsonDocument.Parse(anterior);
        exige(FormatoPaqueteNube.Compactar(existente.RootElement).GetRawText() == existente.RootElement.GetRawText(),
            "la mejora reescribió los bytes de un paquete compacto existente.");
        exige(PaqueteNube.FirmaDatosCompartidos(original) == PaqueteNube.FirmaDatosCompartidos(compacto),
            "reducir escapes cambió la firma de datos compartidos.");
    }

    private static void DiccionarioPorCosto(Action<bool, string> exige)
    {
        const string empate = "123456789012"; // Dos usos al índice0 no ahorran bytes.
        const string limiteIndice = "12345678"; // Cuatro usos sí ahorrarían al índice0, pero no al10.
        const string uuid = "4d147a53-fcf5-477c-95c0-7b8a5474a286";
        const string unicode = "漢字漢字";
        var valores = new List<string> { empate, empate };
        var esperados = Enumerable.Range(0, 10).Select(i => "CODIGO-REPETIDO-" + i).ToList();
        foreach (string codigo in esperados) valores.AddRange(new[] { codigo, codigo, codigo });
        valores.AddRange(Enumerable.Repeat(limiteIndice, 4));
        valores.AddRange(Enumerable.Repeat(uuid, 3)); esperados.Add(uuid);
        valores.AddRange(Enumerable.Repeat(unicode, 4)); esperados.Add(unicode);
        valores.AddRange(Enumerable.Repeat("kg", 100));
        valores.Add("Texto único que no debe añadirse al diccionario aunque sea largo " + new string('x', 160));
        var original = Paquete(new[] { new PaqueteNube.Tabla
        {
            Nombre = "costos_diccionario", Columnas = new() { "dato" },
            Filas = valores.Select(x => new List<PaqueteNube.Celda> { Celda("texto", x) }).ToList()
        } });
        var compacto = FormatoPaqueteNube.Compactar(original);
        var textos = compacto.GetProperty("textos").EnumerateArray().Select(x => x.GetString()!).ToArray();
        exige(textos.SequenceEqual(esperados),
            "el diccionario no respetó el ahorro real, los índices de dos dígitos o la primera aparición.");
        exige(!textos.Contains(empate) && !textos.Contains(limiteIndice) && !textos.Contains("kg"),
            "se añadieron textos cuya referencia o entrada cuesta más que su escritura directa.");
        exige(textos.Contains(uuid) && textos.Contains(unicode),
            "el diccionario omitió códigos cortos o Unicode repetido que sí ahorran bytes.");
        exige(JsonElement.DeepEquals(original.GetProperty("tablas"), FormatoPaqueteNube.Expandir(compacto).GetProperty("tablas")),
            "el diccionario basado en bytes perdió valores o tipos de las celdas.");
        var sinReferencias = JsonNode.Parse(compacto.GetRawText())!;
        foreach (var fila in sinReferencias["tablas"]![0]!["Filas"]!.AsArray())
        {
            if (fila![0] is JsonArray referencia)
                fila[0] = JsonValue.Create(textos[referencia[1]!.GetValue<int>()]);
        }
        sinReferencias["textos"] = new JsonArray();
        var opciones = new JsonSerializerOptions { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
        int bytesSinReferencias = JsonSerializer.SerializeToUtf8Bytes(sinReferencias, opciones).Length;
        exige(Encoding.UTF8.GetByteCount(compacto.GetRawText()) < bytesSinReferencias,
            "el diccionario aumentó el paquete frente a escribir todos los textos directamente.");
        exige(FormatoPaqueteNube.Compactar(original).GetRawText() == compacto.GetRawText()
            && FormatoPaqueteNube.Compactar(compacto).GetRawText() == compacto.GetRawText(),
            "el diccionario no fue determinista o cambió al leer un paquete compacto existente.");
    }

    private static void CeldasExactas(Action<bool, string> exige, Action<JsonNode, string> rechaza)
    {
        var legado = JsonSerializer.SerializeToElement(new { version = 2, presupuestos = new[] { "legado" } });
        exige(!FormatoPaqueteNube.EsCompacto(legado)
            && FormatoPaqueteNube.Expandir(legado).GetRawText() == legado.GetRawText()
            && FormatoPaqueteNube.Compactar(legado).GetRawText() == legado.GetRawText(),
            "un documento legado con version=2 se confundió con una publicación compacta.");
        string repetido = new string('á', 140) + "\"\\\n";
        var celdas = new[]
        {
            Celda("nulo", null), Celda("texto", ""), Celda("texto", "á漢字\"\\\n"),
            Celda("entero", long.MinValue.ToString(CultureInfo.InvariantCulture)),
            Celda("entero", long.MaxValue.ToString(CultureInfo.InvariantCulture)),
            Celda("real", "-0"), Celda("real", "1.7976931348623157E+308"),
            Celda("real", "4.9406564584124654E-324"), Celda("blob", "AAEC/w=="),
            Celda("texto", "12.12345678901234567890123456"),
            Celda("texto", repetido), Celda("texto", repetido)
        };
        JsonElement original = Paquete(new[] { new PaqueteNube.Tabla
        {
            Nombre = "valores_sinteticos", Columnas = Enumerable.Range(0, celdas.Length).Select(i => "c" + i).ToList(),
            Filas = new() { celdas.ToList() }
        } });
        string bytesOriginales = original.GetRawText();
        JsonElement compacto = FormatoPaqueteNube.Compactar(original);
        JsonElement expandido = FormatoPaqueteNube.Expandir(compacto);
        exige(FormatoPaqueteNube.EsCompacto(compacto) && compacto.GetProperty("version").GetInt32() == 2,
            "la publicación no identifica el formato v2.");
        exige(!FormatoPaqueteNube.EsCompacto(original) && FormatoPaqueteNube.Expandir(original).GetRawText() == bytesOriginales,
            "leer el formato anterior transformó su contenido.");
        exige(JsonNode.DeepEquals(JsonNode.Parse(original.GetProperty("tablas").GetRawText()),
            JsonNode.Parse(expandido.GetProperty("tablas").GetRawText())),
            "el viaje compacto alteró NULL, texto, Int64, reales, binarios o decimales guardados como texto.");
        exige(compacto.GetProperty("textos").EnumerateArray().Any(x => x.GetString() == repetido),
            "no se compartió una cadena larga repetida conservando sus caracteres exactos.");
        exige(compacto.GetProperty("documentos").GetArrayLength() == 0
            && expandido.GetProperty("documentos").GetArrayLength() == 1,
            "el documento principal no se guardó una sola vez o no se restituyó para los lectores anteriores.");
        exige(JsonNode.DeepEquals(JsonNode.Parse(compacto.GetRawText()),
            JsonNode.Parse(FormatoPaqueteNube.Compactar(compacto).GetRawText())),
            "compactar de nuevo cambió el paquete o sus referencias.");

        JsonNode ConCelda(JsonNode? valor)
        {
            var copia = JsonNode.Parse(compacto.GetRawText())!;
            copia["tablas"]![0]!["Filas"]![0]![0] = valor;
            return copia;
        }
        rechaza(ConCelda(JsonValue.Create(42)), "una celda numérica sin etiqueta se aceptó como tipo SQLite conocido.");
        rechaza(ConCelda(new JsonArray("desconocido", "1")), "se aceptó una etiqueta desconocida.");
        rechaza(ConCelda(new JsonArray("i", JsonValue.Create(1))), "se aceptó un entero sin su representación exacta como cadena.");
        rechaza(ConCelda(new JsonArray("i", "9223372036854775808")), "se aceptó un entero fuera de Int64.");
        rechaza(ConCelda(new JsonArray("r", "NaN")), "se aceptó un real no finito.");
        rechaza(ConCelda(new JsonArray("b", "!!")), "se aceptó un binario Base64 inválido.");
        rechaza(ConCelda(new JsonArray("s", JsonValue.Create(-1))), "se aceptó una referencia negativa.");
        rechaza(ConCelda(new JsonArray("s", JsonValue.Create(compacto.GetProperty("textos").GetArrayLength()))),
            "se aceptó una referencia fuera del diccionario.");
        rechaza(ConCelda(new JsonArray("s", JsonValue.Create(0.5))), "se aceptó un índice fraccional.");
        rechaza(ConCelda(new JsonArray("i", "1", "extra")), "se aceptó una celda con campos ocultos adicionales.");
        var truncado = JsonNode.Parse(compacto.GetRawText())!;
        truncado["tablas"]![0]!["Filas"]![0]!.AsArray().RemoveAt(0);
        rechaza(truncado, "se aceptó una fila con menos celdas que columnas.");
        var columnasDuplicadas = JsonNode.Parse(compacto.GetRawText())!;
        columnasDuplicadas["tablas"]![0]!["Columnas"]![1] = "C0";
        rechaza(columnasDuplicadas, "se aceptaron columnas duplicadas con distinto casing.");
        var documentoDuplicado = JsonNode.Parse(compacto.GetRawText())!;
        documentoDuplicado["documentos"]!.AsArray().Add(documentoDuplicado["documento"]!.DeepClone());
        rechaza(documentoDuplicado, "se aceptó otra representación del principal en documentos secundarios.");
        var alias = JsonNode.Parse(compacto.GetRawText())!;
        alias["Tablas"] = alias["tablas"]!.DeepClone();
        rechaza(alias, "se aceptó un alias de tablas que podría ocultar cambios al control de permisos.");
        var extraTabla = JsonNode.Parse(compacto.GetRawText())!;
        extraTabla["tablas"]![0]!["oculto"] = "dato";
        rechaza(extraTabla, "se aceptaron propiedades ocultas en una tabla compacta.");
    }

    private static void MedirPaqueteRepresentativo(Action<bool, string> exige)
    {
        // Comparación determinista de un catálogo disperso: mezcla valores únicos,
        // códigos, textos de especificaciones repetidos y celdas nulas habituales.
        string especificacion = "Especificación sintética: " + new string('x', 256);
        var tabla = new PaqueteNube.Tabla
        {
            Nombre = "catalogo_sintetico",
            Columnas = new() { "id", "codigo", "descripcion", "unidad", "precio", "especificacion", "anexo", "observacion" }
        };
        for (int i = 0; i < 2500; i++) tabla.Filas.Add(new()
        {
            Celda("entero", i.ToString(CultureInfo.InvariantCulture)), Celda("texto", "INS-" + i.ToString("D5")),
            Celda("texto", "Insumo sintético " + i), Celda("texto", i % 2 == 0 ? "kg" : "m3"),
            Celda("real", (i / 7d).ToString("R", CultureInfo.InvariantCulture)), Celda("texto", especificacion),
            Celda("nulo", null), Celda("nulo", null)
        });
        JsonElement original = Paquete(new[] { tabla });
        JsonElement compacto = FormatoPaqueteNube.Compactar(original);
        long antes = Encoding.UTF8.GetByteCount(original.GetRawText());
        long despues = Encoding.UTF8.GetByteCount(compacto.GetRawText());
        exige(despues < antes * 0.65, "el catálogo representativo no redujo al menos el 35% de sus bytes.");
        exige(JsonNode.DeepEquals(JsonNode.Parse(original.GetProperty("tablas").GetRawText()),
            JsonNode.Parse(FormatoPaqueteNube.Expandir(compacto).GetProperty("tablas").GetRawText())),
            "la reducción del catálogo se consiguió perdiendo contenido.");
        Console.WriteLine($"OK Tamaño sintético compacto: {antes:N0} → {despues:N0} bytes ({100d * (1d - (double)despues / antes):N1}% menos); 2.500 filas, no corresponde a una base privada.");
    }

    private static void ReferenciasDocumento(Action<bool, string> exige, Action<JsonNode, string> rechaza)
    {
        var original = JsonNode.Parse(Paquete(Array.Empty<PaqueteNube.Tabla>()).GetRawText())!;
        string documentoJson = original["documento"]!.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
        string id = original["documento"]!["Id"]!.GetValue<string>();
        original["tablas"] = JsonSerializer.SerializeToNode(new[] { new PaqueteNube.Tabla
        {
            Nombre = "myg_proyecto", Columnas = new() { "id", "json_documento" },
            Filas = new()
            {
                new() { Celda("texto", id), Celda("texto", documentoJson) },
                new() { Celda("texto", id), Celda("texto", documentoJson) }
            }
        } });
        var compacto = FormatoPaqueteNube.Compactar(JsonSerializer.SerializeToElement(original));
        var referencia = compacto.GetProperty("tablas")[0].GetProperty("Filas")[0][1];
        exige(referencia.ValueKind == JsonValueKind.Array && referencia[0].GetString() == "d" && referencia[1].GetString() == id,
            "una copia equivalente del documento MYG siguió duplicada dentro de la tabla.");
        exige(!compacto.GetProperty("textos").EnumerateArray().Any(x => x.GetString() == documentoJson),
            "un documento ya referenciado se volvió a guardar sin uso dentro del diccionario.");
        JsonElement expandido = FormatoPaqueteNube.Expandir(compacto);
        string restaurado = expandido.GetProperty("tablas")[0].GetProperty("Filas")[0][1].GetProperty("Valor").GetString()!;
        exige(JsonNode.DeepEquals(JsonNode.Parse(documentoJson), JsonNode.Parse(restaurado)),
            "la referencia al documento perdió campos al reconstruir json_documento.");
        exige(PaqueteNube.FirmaDatosCompartidos(JsonSerializer.SerializeToElement(original)) == PaqueteNube.FirmaDatosCompartidos(expandido),
            "reemplazar la copia de json_documento cambió la firma semántica compartida.");

        var desconocida = JsonNode.Parse(compacto.GetRawText())!;
        desconocida["tablas"]![0]!["Filas"]![0]![1] = new JsonArray("d", "ID-INEXISTENTE");
        rechaza(desconocida, "se aceptó una referencia a un documento inexistente.");
        var columnaAjena = JsonNode.Parse(compacto.GetRawText())!;
        columnaAjena["tablas"]![0]!["Filas"]![0]![0] = new JsonArray("d", id);
        rechaza(columnaAjena, "se aceptó una referencia de documento fuera de json_documento.");
        var tablaAjena = JsonNode.Parse(compacto.GetRawText())!;
        tablaAjena["tablas"]![0]!["Nombre"] = "otra_tabla";
        rechaza(tablaAjena, "se aceptó una referencia de documento fuera de myg_proyecto.");

        // Sólo se elimina una copia demostrablemente equivalente: no descartar
        // el JSON que contenga metadatos adicionales aunque comparta el mismo ID.
        var documentoExtendido = original["documento"]!.DeepClone();
        documentoExtendido["ExtensionNativaConDatos"] = "dato único";
        original["tablas"]![0]!["Filas"]![0]![1]!["Valor"] = documentoExtendido.ToJsonString();
        JsonElement distinto = FormatoPaqueteNube.Compactar(JsonSerializer.SerializeToElement(original));
        var celda = distinto.GetProperty("tablas")[0].GetProperty("Filas")[0][1];
        exige(celda.ValueKind != JsonValueKind.Array || celda[0].GetString() != "d",
            "se descartó un JSON no equivalente por coincidir su ID con un documento.");
        string vuelta = FormatoPaqueteNube.Expandir(distinto).GetProperty("tablas")[0].GetProperty("Filas")[0][1].GetProperty("Valor").GetString()!;
        exige(JsonNode.Parse(vuelta)!["ExtensionNativaConDatos"]!.GetValue<string>() == "dato único",
            "la compactación eliminó metadatos únicos de una copia no equivalente.");
    }

    private static void LimitarExpansion(Action<JsonNode, string> rechaza)
    {
        // Una sola cadena de 1 MiB no debe permitir materializar cientos de MiB
        // sin límite mediante referencias baratas en un paquete pequeño.
        var contenido = JsonNode.Parse(FormatoPaqueteNube.Compactar(Paquete(Array.Empty<PaqueteNube.Tabla>())).GetRawText())!;
        contenido["textos"] = new JsonArray(new string('x', 1024 * 1024));
        var filas = new JsonArray();
        for (int i = 0; i < 600; i++) filas.Add(new JsonArray { new JsonArray("s", JsonValue.Create(0)) });
        contenido["tablas"] = new JsonArray(new JsonObject
        {
            ["Nombre"] = "valores_sinteticos", ["Columnas"] = new JsonArray("contenido"), ["Filas"] = filas
        });
        rechaza(contenido, "las referencias permitieron superar el límite de expansión de 512 MiB.");
    }

    private static void BaseSQLite(string carpeta, Action<bool, string> exige)
    {
        var principal = MYGProyectoStorage.Nuevo("Principal compacto");
        var secundaria = MYGProyectoStorage.Nuevo("Secundaria compacta");
        principal.Presupuestos[0].Items.Add(Partida("COMPACTOA", "Partida principal"));
        secundaria.Presupuestos[0].Items.Add(Partida("COMPACTOB", "Partida secundaria"));
        const decimal precio = 12.12345678901234567890123456m;
        string adjunto = Path.Combine(carpeta, "adjunto.txt");
        byte[] bytesAdjunto = Encoding.UTF8.GetBytes("Archivo sintético íntegro: á漢字\n");
        File.WriteAllBytes(adjunto, bytesAdjunto);
        principal.Presupuestos[0].Costos.Insumos.Add(new MYGInsumo
        {
            Descripcion = "Insumo de precisión", ImagenRuta = adjunto, Precio = precio
        });
        string origen = Path.Combine(carpeta, "origen.sqlite");
        MYGProyectoStorage.Guardar(origen, principal);
        MYGProyectoStorage.Guardar(origen, secundaria);
        using (var conexion = Abrir(origen))
        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText = """
                UPDATE costo_unitario SET archivo_pdf=X'000102FF',Notas1='Metadato nativo único' WHERE id_costounitario='COMPACTOA';
                CREATE TABLE extension_no_publicable(password TEXT);
                INSERT INTO extension_no_publicable VALUES('SECRETO-QUE-NO-SE-PUBLICA');
                """;
            comando.ExecuteNonQuery();
        }
        byte[] huella = SHA256.HashData(File.ReadAllBytes(origen));
        foreach (string alcance in new[] { "obra", "base" })
        {
            JsonElement original = PaqueteNube.CrearContenido(principal, origen, alcance);
            JsonElement compacto = FormatoPaqueteNube.Compactar(original);
            JsonElement expandido = FormatoPaqueteNube.Expandir(compacto);
            JsonElement directo = PaqueteNube.CrearContenido(principal, origen, alcance, compacto: true);
            exige(FormatoPaqueteNube.EsCompacto(directo) && directo.GetProperty("documentos").GetArrayLength() == (alcance == "base" ? 1 : 0),
                "el creador directo volvió a producir JSON expandido o duplicó la obra principal.");
            exige(PaqueteNube.FirmaDatosCompartidos(FormatoPaqueteNube.Expandir(directo)) == PaqueteNube.FirmaDatosCompartidos(expandido),
                "crear v2 directamente cambió datos respecto de compactar el paquete anterior.");
            exige(Encoding.UTF8.GetByteCount(directo.GetRawText()) < Encoding.UTF8.GetByteCount(original.GetRawText()),
                "crear v2 directamente no redujo el paquete SQLite representativo.");
            exige(PaqueteNube.FirmaDatosCompartidos(original) == PaqueteNube.FirmaDatosCompartidos(expandido),
                "la firma compartida cambió al compactar " + alcance + ".");
            exige(!compacto.GetRawText().Contains("SECRETO-QUE-NO-SE-PUBLICA", StringComparison.Ordinal),
                "el paquete compacto incorporó datos excluidos de la publicación.");
            string destino = Path.Combine(carpeta, alcance + ".sqlite");
            PaqueteNube.Descargar(directo, destino);
            var descargado = MYGBaseDatos.LeerProyecto(destino, principal.Id);
            exige(MYGBaseDatos.ListarProyectos(destino).Count == (alcance == "base" ? 2 : 1),
                "la reconstrucción modificó el alcance compartido.");
            exige(descargado.Presupuestos[0].Costos.Insumos[0].Precio == precio,
                "el precio decimal perdió precisión al reconstruir SQLite.");
            exige(File.ReadAllBytes(descargado.Presupuestos[0].Costos.Insumos[0].ImagenRuta).SequenceEqual(bytesAdjunto),
                "el adjunto no conservó sus bytes tras compactar y descargar.");
            using var conexion = Abrir(destino);
            using var comando = conexion.CreateCommand();
            comando.CommandText = "SELECT archivo_pdf FROM costo_unitario WHERE id_costounitario='COMPACTOA'";
            exige(comando.ExecuteScalar() is byte[] blob && blob.SequenceEqual(new byte[] { 0, 1, 2, 255 }),
                "un binario nativo perdió sus bytes.");
            comando.CommandText = "SELECT Notas1 FROM costo_unitario WHERE id_costounitario='COMPACTOA'";
            exige((string?)comando.ExecuteScalar() == "Metadato nativo único", "se eliminó un metadato nativo.");
            comando.CommandText = "PRAGMA integrity_check";
            exige((string?)comando.ExecuteScalar() == "ok", "la base reconstruida no pasó integrity_check.");
        }
        exige(SHA256.HashData(File.ReadAllBytes(origen)).SequenceEqual(huella),
            "publicar, compactar o descargar modificó la base original.");
    }

    private static void MetadatosPendientes(string carpeta, Action<bool, string> exige)
    {
        var archivo = new ArchivoPublicacionPendienteNube(Path.Combine(carpeta, "publicaciones"),
            "https://compacto.example.test", "33333333-3333-4333-8333-333333333333");
        var contenido = FormatoPaqueteNube.Compactar(Paquete(Array.Empty<PaqueteNube.Tabla>()));
        const long bytesSQLite = 61535L * 1024;
        var pendiente = new PublicacionPendienteNube(Guid.NewGuid(), "Base compacta", "obra", contenido)
        {
            BytesSQLiteOriginal = bytesSQLite
        };
        archivo.Guardar(pendiente);
        var resumen = archivo.Consultar()!;
        exige(resumen.BytesSQLiteOriginal == bytesSQLite && archivo.Leer(resumen).BytesSQLiteOriginal == bytesSQLite,
            "el tamaño del SQLite original no se conservó al consultar y recuperar el pendiente.");
        byte[] guardado = File.ReadAllBytes(archivo.RutaActiva);
        exige(resumen.BytesArchivo == guardado.Length, "el tamaño del paquete local no corresponde a sus bytes reales.");
        string retirado = archivo.Retirar(resumen);
        exige(File.ReadAllBytes(retirado).SequenceEqual(guardado) && archivo.Consultar() is null,
            "retirar el pendiente cambió sus bytes, UUID o estado recuperable.");
        // Los intentos de versiones anteriores no contienen el campo nuevo.
        File.WriteAllText(archivo.RutaActiva, JsonSerializer.Serialize(new
        {
            pendiente.Id, pendiente.Nombre, pendiente.Alcance, pendiente.Contenido
        }), new UTF8Encoding(false));
        var legado = archivo.Consultar()!;
        exige(legado.BytesSQLiteOriginal is null && archivo.Leer(legado).BytesSQLiteOriginal is null,
            "un pendiente anterior sin metadatos dejó de ser legible o inventó el tamaño original.");
    }

    private static PaqueteNube.Celda Celda(string tipo, string? valor) => new() { Tipo = tipo, Valor = valor };

    private static JsonElement Paquete(IEnumerable<PaqueteNube.Tabla> tablas)
    {
        var documento = MYGProyectoStorage.Nuevo("Documento de formato");
        return JsonSerializer.SerializeToElement(new
        {
            formato = "MYG_COLABORACION", version = 1, alcance = "obra", documento,
            documentos = new[] { documento }, tablas, recursos = Array.Empty<PaqueteNube.Recurso>(), avisos = Array.Empty<string>()
        });
    }

    private static ItemPresupuestoDelphin Partida(string id, string descripcion) => new()
    {
        Id = id, IdLocalMYG = id, Descripcion = descripcion, Unidad = "m", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA"
    };

    private static SqliteConnection Abrir(string ruta)
    {
        var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        conexion.Open();
        return conexion;
    }
}
