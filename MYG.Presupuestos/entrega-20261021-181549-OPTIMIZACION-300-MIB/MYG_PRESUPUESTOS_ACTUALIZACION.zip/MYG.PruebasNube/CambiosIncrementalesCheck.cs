using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class CambiosIncrementalesCheck
{
    private const string Servidor = "https://incremental.supabase.co";
    private static readonly Guid ProyectoId = Guid.Parse("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa");
    private static readonly Guid UsuarioId = Guid.Parse("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        DiferenciasYReconstruccion();
        SerializacionReducida();
        EntradasInvalidas();
        await RpcYReintento();
        Console.WriteLine($"OK Sincronización incremental: {comprobaciones} comprobaciones de tamaño, reconstrucción, rutas y HTTP simulado.");
    }

    private static void Exige(bool condicion, string mensaje)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Cambios incrementales: " + mensaje);
    }

    private static JsonElement Elemento(JsonNode nodo) => JsonSerializer.SerializeToElement(nodo,
        new JsonSerializerOptions { MaxDepth = 128 });

    private static JsonObject Paquete()
    {
        var documento = MYGProyectoStorage.Nuevo("Obra incremental");
        documento.Id = "DOCUMENTO-A";
        return new JsonObject
        {
            ["formato"] = "MYG_COLABORACION", ["version"] = 2, ["alcance"] = "obra",
            ["documento"] = JsonSerializer.SerializeToNode(documento), ["documentos"] = new JsonArray(),
            ["tablas"] = new JsonArray(new JsonObject
            {
                ["Nombre"] = "tabla_a", ["Columnas"] = new JsonArray("id", "valor"),
                ["Filas"] = new JsonArray(new JsonArray(new JsonArray("i", "1"), "dato"))
            }),
            ["recursos"] = new JsonArray(), ["textos"] = new JsonArray(), ["avisos"] = new JsonArray(),
            ["exclusiones"] = "Accesos y credenciales locales"
        };
    }

    private static void DiferenciasYReconstruccion()
    {
        var anterior = Paquete(); var nuevo = anterior.DeepClone().AsObject();
        // El nombre de una obra grande no debe provocar el envío del documento entero.
        anterior["documento"]!["DescripcionLargaPrueba"] = new string('x', 2 * 1024 * 1024);
        nuevo = anterior.DeepClone().AsObject(); nuevo["documento"]!["Nombre"] = "Renombrada";
        var cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(nuevo));
        Exige(cambios.GetProperty("version").GetInt32() == 2, "No eligió rutas para una edición puntual.");
        Exige(Encoding.UTF8.GetByteCount(cambios.GetRawText()) < 512, "Renombrar reenvió el documento grande.");
        Exige(JsonNode.DeepEquals(JsonNode.Parse(CambiosPaqueteNube.Aplicar(Elemento(anterior), cambios).GetRawText()), nuevo),
            "La reconstrucción del nombre cambió otro dato.");
        nuevo["tablas"]![0]!["Filas"]![0]![1] = "dato modificado";
        cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(nuevo));
        Exige(cambios.GetProperty("version").GetInt32() == 2
            && !cambios.GetRawText().Contains("DescripcionLargaPrueba", StringComparison.Ordinal),
            "Una celda reenvió datos no modificados.");
        Exige(JsonNode.DeepEquals(JsonNode.Parse(CambiosPaqueteNube.Aplicar(Elemento(anterior), cambios).GetRawText()), nuevo),
            "La ruta de celda cambió su tabla o sus tipos.");
        anterior = Paquete(); nuevo = anterior.DeepClone().AsObject();
        anterior["documento"]!["PrecisionPrueba"] = 9007199254740993.123456789012m;
        nuevo["documento"]!["PrecisionPrueba"] = 9007199254740993.123456789013m;
        cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(nuevo));
        Exige(CambiosPaqueteNube.Aplicar(Elemento(anterior), cambios).GetProperty("documento")
            .GetProperty("PrecisionPrueba").GetDecimal() == 9007199254740993.123456789013m,
            "La comparación de cambios perdió decimales que double no distingue.");

        // Altas, bajas y cambios de orden de los tres tipos de colección.
        anterior = Paquete(); nuevo = anterior.DeepClone().AsObject();
        nuevo["documentos"]!.AsArray().Add(new JsonObject { ["Id"] = "DOCUMENTO-B", ["Nombre"] = "Otra" });
        nuevo["tablas"]!.AsArray().Clear();
        nuevo["tablas"]!.AsArray().Add(new JsonObject { ["Nombre"] = "tabla_b", ["Columnas"] = new JsonArray("valor"), ["Filas"] = new JsonArray() });
        nuevo["recursos"]!.AsArray().Add(new JsonObject { ["Referencia"] = "archivo-a", ["Sha256"] = "ABC", ["Base64"] = "" });
        cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(nuevo));
        Exige(JsonNode.DeepEquals(JsonNode.Parse(CambiosPaqueteNube.Aplicar(Elemento(anterior), cambios).GetRawText()), nuevo),
            "Altas y bajas perdieron documentos, tablas o recursos.");
        var regreso = CambiosPaqueteNube.Crear(Elemento(nuevo), Elemento(anterior));
        Exige(JsonNode.DeepEquals(JsonNode.Parse(CambiosPaqueteNube.Aplicar(Elemento(nuevo), regreso).GetRawText()), anterior),
            "La eliminación de recursos y documentos no conserva el resto.");
        cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(anterior));
        Exige(JsonNode.DeepEquals(JsonNode.Parse(CambiosPaqueteNube.Aplicar(Elemento(anterior), cambios).GetRawText()), anterior),
            "Un cambio vacío alteró el paquete.");

        // Muchos cambios pequeños usan el formato por componentes como alternativa acotada.
        anterior = Paquete(); nuevo = anterior.DeepClone().AsObject();
        var filasAntes = anterior["tablas"]![0]!["Filas"]!.AsArray(); filasAntes.Clear();
        var filasDespues = nuevo["tablas"]![0]!["Filas"]!.AsArray(); filasDespues.Clear();
        for (int i = 0; i < 4200; i++)
        {
            filasAntes.Add(new JsonArray(new JsonArray("i", i.ToString()), "a"));
            filasDespues.Add(new JsonArray(new JsonArray("i", i.ToString()), "b"));
        }
        cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(nuevo));
        Exige(cambios.GetProperty("version").GetInt32() == 1, "No acotó la cantidad de rutas.");
        Exige(JsonNode.DeepEquals(JsonNode.Parse(CambiosPaqueteNube.Aplicar(Elemento(anterior), cambios).GetRawText()), nuevo),
            "La alternativa por tablas cambió las filas.");
    }

    private static void SerializacionReducida()
    {
        var anterior = Paquete(); var nuevo = anterior.DeepClone().AsObject();
        string texto = string.Concat(Enumerable.Repeat("{\"obra\":\"Áncash 漢字 <dato>&\",\"n\":12.3456789}\n", 400));
        nuevo["tablas"]![0]!["Filas"]![0]![1] = texto;
        var cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(nuevo));
        int inflado = JsonSerializer.SerializeToUtf8Bytes(cambios).Length;
        Exige(Encoding.UTF8.GetByteCount(cambios.GetRawText()) < inflado * 0.75,
            "la diferencia incremental volvió a escapar innecesariamente el JSON nativo.");
        var aplicado = CambiosPaqueteNube.Aplicar(Elemento(anterior), cambios);
        Exige(aplicado.GetProperty("tablas")[0].GetProperty("Filas")[0][1].GetString() == texto
            && JsonElement.DeepEquals(aplicado, Elemento(nuevo)),
            "reducir los escapes de un delta alteró su reconstrucción o la precisión del contenido.");
    }

    private static void EntradasInvalidas()
    {
        JsonElement anterior = Elemento(Paquete());
        string[] invalidos =
        {
            "{\"version\":3,\"campos\":{}}",
            "{\"version\":1,\"campos\":{\"oculto\":1}}",
            "{\"version\":1,\"campos\":{},\"tablas\":{\"poner\":[],\"quitar\":[],\"orden\":[]}}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[],\"valor\":1}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"oculto\"],\"valor\":1}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"tablas\",\"00\"],\"valor\":1}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"tablas\",\"-1\"],\"valor\":1}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"tablas\",\"99\"],\"valor\":1}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"tablas\",\"0\"],\"quitar\":true}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"documento\",\"NoExiste\",\"x\"],\"valor\":1}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"documento\",\"Nombre\"],\"quitar\":false}]}",
            "{\"version\":2,\"operaciones\":[{\"ruta\":[\"version\"],\"valor\":1}]}"
        };
        foreach (string invalido in invalidos)
        {
            using var json = JsonDocument.Parse(invalido);
            bool rechazado = false;
            try { CambiosPaqueteNube.Aplicar(anterior, json.RootElement); }
            catch (InvalidDataException) { rechazado = true; }
            Exige(rechazado, "Aceptó cambios malformados: " + invalido);
        }
        var duplicado = Paquete(); duplicado["tablas"]!.AsArray().Add(duplicado["tablas"]![0]!.DeepClone());
        bool repetido = false;
        try { CambiosPaqueteNube.Crear(anterior, Elemento(duplicado)); }
        catch (InvalidDataException) { repetido = true; }
        Exige(repetido, "Una colección repetida no debe producir un patch ambiguo.");
    }

    private static async Task RpcYReintento()
    {
        using var transporte = new Transporte();
        using var cliente = new ClienteSupabase(Servidor, "sb_publishable_incremental_pruebas", transporte);
        transporte.Paso(_ => Task.FromResult(Sesion()));
        await cliente.IniciarSesionMygAsync(new TicketNubeMYG("cabecera.cuerpo.firma", "editor", Servidor,
            DateTimeOffset.UtcNow.AddMinutes(1)));
        transporte.Paso(r =>
        {
            Exige(r.RequestUri?.AbsolutePath == "/rest/v1/rpc/myg_nube_revision", "No consultó metadatos livianos.");
            return Task.FromResult(Json(new { id = ProyectoId, codigo = "MYG-DELTA", nombre = "Obra", rol = "editor", revision = 3,
                alcance = "obra", permisos_modulos = new { acu = false, especificaciones = true, metrados_excel = false } }));
        });
        var metadatos = await cliente.ConsultarRevisionProyectoAsync(ProyectoId);
        Exige(metadatos.Revision == 3 && metadatos.Contenido.ValueKind == JsonValueKind.Undefined
            && metadatos.PermisosModulos is { Acu: false, Especificaciones: true }, "Los metadatos perdieron permisos o descargaron contenido.");

        var anterior = Paquete(); var final = anterior.DeepClone().AsObject(); final["documento"]!["Nombre"] = "Cambio congelado";
        var cambios = CambiosPaqueteNube.Crear(Elemento(anterior), Elemento(final));
        Guid operacion = Guid.NewGuid(); string? cuerpo = null;
        transporte.Paso(async r =>
        {
            Exige(r.RequestUri?.AbsolutePath == "/rest/v1/rpc/myg_nube_guardar_cambios", "Usó el RPC de snapshots completos.");
            cuerpo = await r.Content!.ReadAsStringAsync();
            using var solicitud = JsonDocument.Parse(cuerpo);
            Exige(!solicitud.RootElement.TryGetProperty("p_contenido", out _) && solicitud.RootElement.GetProperty("p_operacion").GetGuid() == operacion,
                "El envío duplicó el snapshot o cambió el UUID.");
            return Json(new { error = "sesion caducada" }, HttpStatusCode.Unauthorized);
        });
        transporte.Paso(_ => Task.FromResult(Sesion("acceso_renovado")));
        transporte.Paso(async r =>
        {
            Exige(await r.Content!.ReadAsStringAsync() == cuerpo, "Renovar la sesión alteró la diferencia congelada.");
            return Json(new { estado = "aplicada", revision = 4, operacion_id = operacion });
        });
        var respuesta = await cliente.GuardarCambiosCongeladosAsync(ProyectoId, operacion, 3, cambios, Elemento(final));
        Exige(respuesta.Revision == 4 && respuesta.Estado == "aplicada" && respuesta.OperacionId == operacion
            && JsonNode.DeepEquals(JsonNode.Parse(respuesta.Contenido.GetRawText()), final), "El ACK compacto no recuperó el contenido congelado.");
        transporte.Paso(_ => Task.FromResult(Json(new { estado = "conflicto", revision = 7, operacion_id = operacion, contenido = Elemento(anterior) })));
        respuesta = await cliente.GuardarCambiosCongeladosAsync(ProyectoId, operacion, 3, cambios, Elemento(final));
        Exige(respuesta.Estado == "conflicto" && respuesta.Revision == 7
            && JsonNode.DeepEquals(JsonNode.Parse(respuesta.Contenido.GetRawText()), anterior), "El conflicto usó nuestro borrador en lugar del snapshot remoto.");
        transporte.Paso(_ => Task.FromResult(Json(new { estado = "aplicada", revision = 99, operacion_id = operacion })));
        bool rechazada = false;
        try { await cliente.GuardarCambiosCongeladosAsync(ProyectoId, operacion, 3, cambios, Elemento(final)); }
        catch (NubeException) { rechazada = true; }
        Exige(rechazada, "El cliente aceptó una revisión de ACK incompatible.");
        Exige(transporte.Pendientes == 0, "No se ejecutaron todas las solicitudes HTTP previstas.");
    }

    private static HttpResponseMessage Sesion(string acceso = "acceso_pruebas") => Json(new
    {
        access_token = acceso, refresh_token = "refresco_pruebas", expires_in = 3600,
        user = new { id = UsuarioId }, usuario_myg = "editor"
    });

    private static HttpResponseMessage Json(object dato, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    { Content = new StringContent(JsonSerializer.Serialize(dato), Encoding.UTF8, "application/json") };

    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<Func<HttpRequestMessage, Task<HttpResponseMessage>>> pasos = new();
        public int Pendientes => pasos.Count;
        public void Paso(Func<HttpRequestMessage, Task<HttpResponseMessage>> paso) => pasos.Enqueue(paso);
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) =>
            pasos.Count > 0 ? pasos.Dequeue()(request) : throw new InvalidOperationException("Solicitud incremental no prevista.");
    }
}
