using System.Net;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using MYG_2027;

internal static class CapacidadesNubeCheck
{
    private const string Servidor = "https://capacidades.supabase.co";
    private const string Clave = "sb_publishable_pruebas_capacidades";
    private static readonly Guid Usuario = Guid.Parse("11111111-1111-4111-8111-111111111111");
    private static readonly Guid Proyecto = Guid.Parse("22222222-2222-4222-8222-222222222222");
    private static int comprobaciones;

    public static async Task RunAsync()
    {
        comprobaciones = 0;
        await CapacidadAusenteConservaPendiente();
        await RespuestasInvalidas();
        await CacheYAutenticacion();
        await ContenidoLegadoNoConsultaCapacidades();
        Console.WriteLine($"OK Capacidades de nube: {comprobaciones} comprobaciones de actualización, caché, sesión y compatibilidad; HTTP simulado.");
    }

    private static void Exige(bool condicion, string mensaje)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Capacidades: " + mensaje);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error) { comprobaciones++; return error; }
        throw new InvalidOperationException("Capacidades: faltó el rechazo esperado.");
    }

    private static HttpResponseMessage Json(object objeto, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    {
        Content = new StringContent(JsonSerializer.Serialize(objeto), Encoding.UTF8, "application/json")
    };

    private static async Task<(ClienteSupabase Cliente, Transporte Transporte)> Conectar()
    {
        var transporte = new Transporte();
        transporte.Paso((r, _) =>
        {
            Exige(r.RequestUri?.PathAndQuery == "/auth/v1/token?grant_type=password", "se usó otra ruta de autenticación.");
            return Task.FromResult(Json(new
            {
                access_token = "sesion_capacidades", refresh_token = "refresco_capacidades", expires_in = 3600,
                user = new { id = Usuario }
            }));
        });
        var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        await cliente.IniciarSesionAsync("cuenta@example.test", "clave_sintetica_solo_memoria");
        return (cliente, transporte);
    }

    private static async Task RevisarRpc(HttpRequestMessage solicitud)
    {
        Exige(solicitud.Method == HttpMethod.Post && solicitud.RequestUri?.AbsolutePath == "/rest/v1/rpc/myg_nube_capacidades",
            "la consulta no usó la RPC de capacidades.");
        Exige(solicitud.Headers.Authorization?.Parameter == "sesion_capacidades"
            && solicitud.Headers.GetValues("apikey").Single() == Clave,
            "la consulta no conservó la sesión de la cuenta y la clave pública.");
        using var parametros = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync());
        Exige(parametros.RootElement.ValueKind == JsonValueKind.Object && !parametros.RootElement.EnumerateObject().Any(),
            "se enviaron datos de una base o credenciales en una consulta de capacidades.");
    }

    private static async Task CapacidadAusenteConservaPendiente()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-capacidades-" + Guid.NewGuid().ToString("N"));
        try
        {
            foreach (string codigo in new[] { "PGRST202", "42883" })
            {
                var (cliente, transporte) = await Conectar();
                using (cliente)
                {
                    var almacen = new ArchivoPublicacionPendienteNube(Path.Combine(carpeta, codigo), Servidor, Usuario.ToString("D"));
                    var pendiente = new PublicacionPendienteNube(Guid.NewGuid(), "Publicación conservada", "obra", Compacto());
                    almacen.Guardar(pendiente);
                    byte[] original = File.ReadAllBytes(almacen.RutaActiva);
                    transporte.Paso(async (r, _) =>
                    {
                        await RevisarRpc(r);
                        return Json(new { code = codigo, message = "detalle_remoto_no_mostrar" }, HttpStatusCode.NotFound);
                    });
                    var error = await Rechaza(() => cliente.CrearProyectoAsync(pendiente.Id, pendiente.Nombre, pendiente.Contenido, pendiente.Alcance));
                    Exige(error.Codigo == codigo && error.Message.Contains("Actualice Supabase", StringComparison.Ordinal)
                        && error.Message.Contains("pendiente", StringComparison.Ordinal)
                        && !error.Message.Contains("detalle_remoto_no_mostrar", StringComparison.Ordinal),
                        "la ausencia de migración no explicó el requisito sin filtrar contenido remoto.");
                    Exige(File.ReadAllBytes(almacen.RutaActiva).SequenceEqual(original) && almacen.Leer().Id == pendiente.Id,
                        "el rechazo de capacidades cambió o retiró el intento pendiente.");
                    // Un fallo no se cachea: después de aplicar la migración puede reanudarse.
                    transporte.Paso(async (r, _) => { await RevisarRpc(r); return Json(new { paquete_compacto = 2, cambios = 1 }); });
                    var actualizado = await cliente.ObtenerCapacidadesNubeAsync();
                    Exige(actualizado == new CapacidadesNube(2, 1), "un error previo impidió detectar la actualización del servidor.");
                    transporte.Completo();
                }
            }
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, true); }
    }

    private static async Task RespuestasInvalidas()
    {
        foreach (string respuesta in new[]
        {
            "null", "[]", "{}", "{\"paquete_compacto\":\"2\"}", "{\"paquete_compacto\":true}",
            "{\"paquete_compacto\":0}", "{\"paquete_compacto\":2.5}", "{\"paquete_compacto\":2147483648}",
            "{\"paquete_compacto\":2,\"cambios\":\"1\"}", "{\"paquete_compacto\":2,\"cambios\":false}",
            "{\"paquete_compacto\":2,\"cambios\":-1}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":\"300\"}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":true}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":null}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":0}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":-1}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":300.5}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":301}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":2147483648}",
            "{\"paquete_compacto\":2,\"max_contenido_mib\":127,\"max_contenido_mib\":300}"
        })
        {
            var (cliente, transporte) = await Conectar();
            using (cliente)
            {
                transporte.Paso((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(respuesta, Encoding.UTF8, "application/json")
                }));
                await Rechaza(() => cliente.ObtenerCapacidadesNubeAsync());
                transporte.Completo();
            }
        }
        var (anterior, t) = await Conectar();
        using (anterior)
        {
            t.Paso((_, _) => Task.FromResult(Json(new { paquete_compacto = 1 })));
            var capacidades = await anterior.ObtenerCapacidadesNubeAsync();
            Exige(capacidades.Cambios == 0 && capacidades.MaxContenidoMiB == 127,
                "un servidor anterior recibió capacidades o límites inventados.");
            var error = await Rechaza(() => anterior.ExigirPaqueteCompactoAsync());
            Exige(error.Message.Contains("pendiente", StringComparison.Ordinal), "un formato incompatible no dejó clara la conservación del intento.");
            t.Completo();
        }
    }

    private static async Task CacheYAutenticacion()
    {
        using (var sinSesion = new ClienteSupabase(Servidor, Clave, new Transporte()))
        {
            var error = await Rechaza(() => sinSesion.ObtenerCapacidadesNubeAsync());
            Exige(error.NecesitaIniciarSesion, "se consultaron capacidades sin identidad autenticada.");
        }
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso(async (r, _) => { await RevisarRpc(r); return Json(new { paquete_compacto = 2, cambios = 1, max_contenido_mib = 300 }); });
            var primera = await cliente.ObtenerCapacidadesNubeAsync();
            var segunda = await cliente.ObtenerCapacidadesNubeAsync();
            await cliente.ExigirPaqueteCompactoAsync();
            Exige(primera == new CapacidadesNube(2, 1, 300) && segunda == primera,
                "la capacidad compatible cambió entre consultas cacheadas.");
            using var cancelacion = new CancellationTokenSource();
            cancelacion.Cancel();
            bool cancelado = false;
            try { await cliente.ObtenerCapacidadesNubeAsync(cancelacion.Token); }
            catch (OperationCanceledException) { cancelado = true; }
            Exige(cancelado, "una respuesta cacheada ignoró la cancelación explícita.");
            transporte.Paso((r, _) =>
            {
                Exige(r.RequestUri?.PathAndQuery == "/auth/v1/logout?scope=local", "el cierre de sesión usó otra ruta.");
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.NoContent));
            });
            await cliente.CerrarSesionAsync();
            var error = await Rechaza(() => cliente.ObtenerCapacidadesNubeAsync());
            Exige(error.NecesitaIniciarSesion && !cliente.SesionIniciada,
                "la caché evitó comprobar la sesión después de cerrarla.");
            transporte.Completo();
        }
    }

    private static async Task ContenidoLegadoNoConsultaCapacidades()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            // version=2 en un documento arbitrario no identifica un paquete MYG compacto.
            JsonElement contenido = JsonSerializer.SerializeToElement(new { version = 2, texto = "documento anterior" });
            transporte.Paso(async (r, _) =>
            {
                Exige(r.RequestUri?.AbsolutePath == "/rest/v1/rpc/myg_nube_crear",
                    "se exigieron capacidades compactas para un objeto anterior arbitrario.");
                using var json = JsonDocument.Parse(await r.Content!.ReadAsStringAsync());
                Exige(JsonElement.DeepEquals(json.RootElement.GetProperty("p_contenido"), contenido),
                    "se transformó un contenido anterior por tener una propiedad version=2.");
                return Json(new { id = Proyecto, codigo = "MYG-LEGADO", nombre = "Anterior", rol = "propietario", revision = 1, alcance = "obra", contenido });
            });
            var proyecto = await cliente.CrearProyectoAsync(Proyecto, "Anterior", contenido, "obra");
            Exige(JsonElement.DeepEquals(proyecto.Contenido, contenido), "la lectura del documento anterior cambió su contenido.");
            transporte.Completo();
        }
    }

    private static JsonElement Compacto()
    {
        var documento = MYGProyectoStorage.Nuevo("Publicación de capacidades");
        return FormatoPaqueteNube.Compactar(JsonSerializer.SerializeToElement(new
        {
            formato = "MYG_COLABORACION", version = 1, alcance = "obra", documento, documentos = new[] { documento },
            tablas = Array.Empty<PaqueteNube.Tabla>(), recursos = Array.Empty<PaqueteNube.Recurso>(), avisos = Array.Empty<string>()
        }));
    }

    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>>> pasos = new();
        internal void Paso(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> respuesta) => pasos.Enqueue(respuesta);
        internal void Completo() => Exige(pasos.Count == 0, "quedaron solicitudes esperadas sin ejecutar.");
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if (pasos.Count == 0) throw new InvalidOperationException("Capacidades: hubo una solicitud HTTP adicional inesperada.");
            return pasos.Dequeue()(request, cancellationToken);
        }
    }
}
