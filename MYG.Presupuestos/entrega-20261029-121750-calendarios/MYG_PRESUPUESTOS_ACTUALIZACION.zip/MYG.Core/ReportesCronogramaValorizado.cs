using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

public static partial class MYGReportesCronograma
{
    private sealed record FilaValorizada(string Codigo, string Descripcion, string Unidad,
        decimal? Cantidad, decimal? Precio, decimal Parcial, decimal[] Meses, bool Titulo);

    /// <summary>Calendario mensual continuo de las partidas vinculadas al plan.
    /// El presupuesto opcional se filtra después de calcular todas las tareas,
    /// conservando las fechas de las dependencias entre presupuestos.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> CrearValorizado(
        MYGProyectoDocumento documento, MYGCronograma plan, string presupuestoId = null)
    {
        var partidas = PrepararPartidas(documento, plan, out _, presupuestoId);
        string titulo = "CRONOGRAMA VALORIZADO DEL " + (presupuestoId == null ? "PROYECTO" : "PRESUPUESTO");
        if (partidas.Count == 0)
            return new[] { SinDatos(documento, plan, titulo, "Sin partidas de presupuesto vinculadas al cronograma.") };
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        var reportes = new List<MYGHojaReporteProyecto>();
        int numero = 0;
        foreach (var moneda in partidas.GroupBy(p => Moneda(p.Presupuesto), StringComparer.OrdinalIgnoreCase))
        {
            var entradas = moneda.Select(p => (Partida: p, Meses: Repartir(p, calendario))).ToArray();
            var periodos = Periodos(entradas.Min(p => p.Partida.Fila.Inicio), entradas.Max(p => p.Partida.Fila.Fin), false);
            if (periodos.Length > 194)
                throw new InvalidDataException("El cronograma valorizado admite hasta 194 meses por moneda. Reduzca el alcance de la programación para exportarlo.");
            var presupuestos = entradas.Select(e => e.Partida.Presupuesto).DistinctBy(p => p.Id)
                .OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.OrdinalIgnoreCase).ToArray();
            var filas = new List<FilaValorizada>();
            var calculos = new List<MYGCalculoPresupuesto>();
            var directos = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in presupuestos)
            {
                var propias = entradas.Where(e => e.Partida.Presupuesto.Id == p.Id).ToArray();
                var porId = p.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
                var montos = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
                var vinculadas = propias.ToDictionary(e => e.Partida.Partida.Id, StringComparer.OrdinalIgnoreCase);
                foreach (var entrada in propias)
                {
                    var i = entrada.Partida.Partida;
                    var mensual = periodos.Select(m => entrada.Meses.GetValueOrDefault(m.Inicio)).ToArray();
                    montos.Add(i.Id, mensual);
                    string padre = i.ParentId;
                    var vistos = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { i.Id };
                    while (padre != null && porId.TryGetValue(padre, out var ancestro))
                    {
                        if (!vistos.Add(padre)) throw new InvalidDataException("La estructura del presupuesto contiene un ciclo.");
                        if (!montos.TryGetValue(padre, out var suma)) montos.Add(padre, suma = new decimal[periodos.Length]);
                        for (int n = 0; n < mensual.Length; n++) suma[n] += mensual[n];
                        padre = ancestro.ParentId;
                    }
                }
                var meses = periodos.Select(m => propias.Sum(e => e.Meses.GetValueOrDefault(m.Inicio))).ToArray();
                decimal directo = meses.Sum();
                directos.Add(p.Id, meses);
                // Los análisis se calcularon en la copia completa. Este snapshot
                // sólo entrega al motor del pie el costo directo ya calculado;
                // no corta referencias de subanálisis ni grava de nuevo insumos.
                var alcance = new MYGPresupuestoDocumento
                {
                    Id = p.Id, Item = p.Item, Nombre = p.Nombre, Posicion = p.Posicion,
                    Costos = MYGProyectoStorage.Copia(p.Costos),
                    Items = new() { new() { Id = "programado", IdLocalMYG = "programado", TipoPropuesta = "PARTIDA",
                        Costos = new() { Cantidad = 1, PrecioDirecto = directo } } }
                };
                // El parcial nativo puede conservar más decimales que la
                // presentación del precio unitario. Evitar redondearlo otra vez
                // sin alterar la precisión propia de los conceptos del pie.
                MYGMotorPresupuestos.CapturarPrecioDelphin(alcance, alcance.Items[0], directo, directo);
                calculos.Add(MYGMotorPresupuestos.CrearCalculo(alcance));
                filas.Add(new(p.Item ?? "", p.Nombre ?? "", "", null, null, directo, meses, true));
                foreach (var i in MYGOrdenPresupuestos.FilasOrdenadas(p))
                {
                    if (!montos.TryGetValue(i.Id, out var mensual)) continue;
                    bool esTitulo = MYGProyectoStorage.EsTitulo(i);
                    if (!esTitulo && !vinculadas.ContainsKey(i.Id)) continue;
                    var calculo = propias[0].Partida.Calculo;
                    filas.Add(new(i.Item ?? "", i.Descripcion ?? "", esTitulo ? "" : i.Unidad ?? "",
                        esTitulo ? null : calculo.Cantidad(i), esTitulo ? null : calculo.Analizar(i).PrecioUnitario,
                        mensual.Sum(), mensual, esTitulo));
                }
            }
            var pie = MYGPiePresupuesto.Filas(calculos);
            decimal total = MYGPiePresupuesto.Resumen(calculos).Total;
            var pieMensual = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
            var totalesMes = new decimal[periodos.Length];
            // Los fijos de un pie Delphin compartido se aplican una sola vez.
            var gruposPie = MYGPiePresupuesto.EsPieUnicoDelphin(calculos.Select(c => c.Presupuesto))
                ? new[] { calculos.ToArray() } : calculos.Select(c => new[] { c }).ToArray();
            foreach (var grupo in gruposPie)
            {
                var pesos = Enumerable.Range(0, periodos.Length).Select(n => grupo.Sum(c => directos[c.Presupuesto.Id][n])).ToArray();
                int decimales = grupo.Max(c => Math.Max(c.Presupuesto.Costos.DecimalesPrecio,
                    c.Presupuesto.Costos.PieDelphin?.Decimales ?? 0));
                var estado = pesos.ToArray();
                decimal acumuladoPie = pesos.Sum();
                var conceptos = MYGPiePresupuesto.Filas(grupo);
                var mesesGrupo = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
                bool nativo = grupo.All(c => MYGPiePresupuesto.EsPieDelphin(c.Presupuesto));
                var configuracionNativa = nativo ? grupo.OrderBy(c => c.Presupuesto.Posicion).First().Presupuesto.Costos.PieDelphin : null;
                for (int indice = 0; indice < conceptos.Count; indice++)
                {
                    var concepto = conceptos[indice];
                    decimal[] reparto;
                    if (concepto.Id == MYGPiePresupuesto.IdCostoDirecto) reparto = pesos.ToArray();
                    else
                    {
                        bool acumulada = concepto.Id == MYGPiePresupuesto.IdTotal ||
                            (configuracionNativa != null ? configuracionNativa.Filas[indice - 1].Tipo == "F" :
                                grupo[0].Presupuesto.Costos.PiePersonalizado == null && concepto.Id == "parcial");
                        // Una fila F muestra el acumulado: no vuelve a sumar sus
                        // componentes. Repartir sólo su diferencia conserva tanto
                        // el total nativo como la conciliación de cada mes.
                        decimal incremento = acumulada ? concepto.Importe - acumuladoPie : concepto.Importe;
                        var cambio = RepartirImporteValorizado(incremento, pesos, decimales);
                        for (int n = 0; n < estado.Length; n++) estado[n] += cambio[n];
                        acumuladoPie += incremento;
                        reparto = acumulada ? estado.ToArray() : cambio;
                    }
                    mesesGrupo[concepto.Id] = reparto;
                    if (!pieMensual.TryGetValue(concepto.Id, out var meses)) pieMensual.Add(concepto.Id, meses = new decimal[periodos.Length]);
                    for (int n = 0; n < meses.Length; n++) meses[n] += reparto[n];
                }
                var resumenGrupo = MYGPiePresupuesto.Resumen(grupo);
                // El motor agrega el Parcial de todo el alcance aunque algunos
                // pies personalizados/nativos no tengan una fila con ese ID.
                if (pie.Any(f => f.Id == "parcial") && !mesesGrupo.ContainsKey("parcial"))
                {
                    decimal[] subtotal;
                    if (grupo[0].Presupuesto.Costos.PiePersonalizado != null) subtotal = estado.ToArray();
                    else
                    {
                        var filaSubtotal = configuracionNativa?.Filas.LastOrDefault(f =>
                            f.Clave.Equals("user_sub_total", StringComparison.OrdinalIgnoreCase) ||
                            f.Clave.Equals("parcial_presupuesto", StringComparison.OrdinalIgnoreCase));
                        subtotal = filaSubtotal != null && mesesGrupo.TryGetValue("delphin:" + filaSubtotal.Clave, out var nativos)
                            ? nativos : RepartirImporteValorizado(resumenGrupo.Subtotal, pesos, decimales);
                    }
                    if (!pieMensual.TryGetValue("parcial", out var parciales)) pieMensual.Add("parcial", parciales = new decimal[periodos.Length]);
                    for (int n = 0; n < subtotal.Length; n++) parciales[n] += subtotal[n];
                }
                decimal totalGrupo = resumenGrupo.Total;
                var ajusteFinal = RepartirImporteValorizado(totalGrupo - acumuladoPie, pesos, decimales);
                for (int n = 0; n < estado.Length; n++) totalesMes[n] += estado[n] + ajusteFinal[n];
            }
            // El modelo de hoja admite 200.000 celdas. Sólo la última
            // continuación contiene el pie y el total global, sin duplicarlos.
            int maxFilas = Math.Min(10000, 200000 / (6 + periodos.Length));
            int porHoja = Math.Min(FilasPorHoja, maxFilas - pie.Count - 20);
            if (porHoja < 1) throw new InvalidDataException("El pie del presupuesto supera las filas disponibles para exportar.");
            var partes = filas.Chunk(porHoja).ToArray();
            for (int parte = 0; parte < partes.Length; parte++)
            {
                var h = Hoja("Valorizado " + ++numero, new[] { 90, 330, 44, 78, 78, 100 }, periodos.Length, 105);
                CabeceraValorizado(h, documento, presupuestoId, titulo, moneda.Key, periodos);
                int fila = 10;
                foreach (var dato in partes[parte])
                {
                    Texto(h, fila, 1, dato.Codigo, dato.Titulo);
                    Texto(h, fila, 2, dato.Descripcion, dato.Titulo);
                    Texto(h, fila, 3, dato.Unidad, alineacion: "Centro");
                    if (dato.Cantidad.HasValue) Numero(h, fila, 4, dato.Cantidad.Value, "#,##0.####");
                    if (dato.Precio.HasValue) Numero(h, fila, 5, dato.Precio.Value);
                    Numero(h, fila, 6, dato.Parcial, negrita: dato.Titulo);
                    for (int n = 0; n < periodos.Length; n++)
                        if (dato.Meses[n] != 0) Numero(h, fila, 7 + n, dato.Meses[n], negrita: dato.Titulo);
                        else Texto(h, fila, 7 + n, "");
                    for (int c = 1; c <= h.Columnas; c++)
                    {
                        var celda = Celda(h, fila, c); celda.ColorTexto = "000000";
                        if (dato.Titulo) { celda.Subrayado = true; celda.ColorFondo = "F4F5F7"; }
                    }
                    h.AltosFilas[fila++] = 26;
                }
                fila++;
                if (parte == partes.Length - 1)
                {
                    foreach (var concepto in pie.Where(f => f.Id != MYGPiePresupuesto.IdTotal))
                    {
                        string nombre = concepto.Nombre + (concepto.Porcentaje.HasValue
                            ? " (" + concepto.Porcentaje.Value.ToString("0.00", Espanol) + "%)" : "");
                        FilaPieValorizado(h, fila++, nombre, concepto.Importe,
                            pieMensual.GetValueOrDefault(concepto.Id) ?? new decimal[periodos.Length],
                            concepto.Id is MYGPiePresupuesto.IdCostoDirecto or "parcial");
                    }
                    fila++;
                    string nombreTotal = pie.LastOrDefault(f => f.Id == MYGPiePresupuesto.IdTotal)?.Nombre;
                    string alcanceTotal = presupuestoId == null ? "PROYECTO" : "PRESUPUESTO";
                    string rotuloTotal = string.IsNullOrWhiteSpace(nombreTotal) || nombreTotal.Equals("Total", StringComparison.OrdinalIgnoreCase)
                        ? "TOTAL " + alcanceTotal : nombreTotal + " · " + alcanceTotal;
                    FilaPieValorizado(h, fila, rotuloTotal + " · " + moneda.Key, total, totalesMes, true);
                    h.CeldaTotal = "F" + fila++;
                    fila++;
                    decimal acumulado = 0;
                    Texto(h, fila, 2, "Porcentaje de avance por Mes");
                    Texto(h, fila + 1, 2, "Porcentaje de avance acumulado");
                    h.RangosCombinados.Add("B" + fila + ":F" + fila);
                    h.RangosCombinados.Add("B" + (fila + 1) + ":F" + (fila + 1));
                    for (int n = 0; n < periodos.Length; n++)
                    {
                        acumulado += totalesMes[n];
                        Numero(h, fila, 7 + n, total == 0 ? 0 : totalesMes[n] / total, "0.00%");
                        Numero(h, fila + 1, 7 + n, total == 0 ? 0 : acumulado / total, "0.00%");
                    }
                    fila += 3;
                    Pie(h, fila, "Alcance: partidas vinculadas al cronograma; los títulos suman sólo esas partidas. " +
                        "El pie conserva la configuración activa aplicada al costo directo programado, incluidos importes fijos una sola vez según su alcance. " +
                        "Distribución mensual proporcional a los costos directos, respetando partes, pausas y redondeos; no es avance físico ejecutado. " +
                        "Los porcentajes usan el total programado con pie de esta moneda. Puede diferir del total contractual si hay partidas sin programar.");
                }
                else
                {
                    Texto(h, fila, 2, "Continúa en la siguiente hoja; pie y totales globales en la última.");
                    Numero(h, fila, 6, 0); h.CeldaTotal = "F" + fila;
                }
                Terminar(h, fila);
                reportes.Add(new(titulo + " · " + moneda.Key, h, Datos(documento, plan), cabeceraEnHoja: true));
            }
        }
        return AplicarPresentacion(reportes, plan);
    }

    private static decimal[] RepartirImporteValorizado(decimal importe, decimal[] pesos, int decimales)
    {
        var resultado = new decimal[pesos.Length];
        decimal total = pesos.Sum();
        if (total == 0) { resultado[0] = importe; return resultado; }
        decimal acumulado = 0, asignado = 0;
        int ultimo = Array.FindLastIndex(pesos, p => p != 0);
        for (int n = 0; n < pesos.Length; n++)
        {
            acumulado += pesos[n];
            decimal objetivo = n >= ultimo ? importe : decimal.Round(importe * acumulado / total, decimales, MidpointRounding.AwayFromZero);
            resultado[n] = objetivo - asignado; asignado = objetivo;
        }
        return resultado;
    }

    private static void FilaPieValorizado(MYGHojaMetrado h, int fila, string nombre, decimal importe, decimal[] meses, bool fuerte)
    {
        for (int c = 2; c <= h.Columnas; c++)
            Texto(h, fila, c, "", fuerte).ColorFondo = fuerte ? "ECEEF1" : "FFFFFF";
        Texto(h, fila, 2, nombre, fuerte).ColorFondo = fuerte ? "ECEEF1" : "FFFFFF";
        h.RangosCombinados.Add("B" + fila + ":E" + fila);
        Numero(h, fila, 6, importe, negrita: fuerte);
        for (int n = 0; n < meses.Length; n++) Numero(h, fila, 7 + n, meses[n], negrita: fuerte);
        if (fuerte) for (int c = 2; c <= h.Columnas; c++) Celda(h, fila, c).ColorFondo = "ECEEF1";
        h.AltosFilas[fila] = 24;
    }

    private static void CabeceraValorizado(MYGHojaMetrado h, MYGProyectoDocumento documento, string presupuestoId,
        string titulo, string moneda, Periodo[] periodos)
    {
        h.AltosFilas.Clear(); h.FilasInmovilizadas = 9; h.ColumnasInmovilizadas = 6;
        string ultima = MYGHojaCalculo.Columna(h.Columnas);
        Texto(h, 1, 1, titulo, true, "Centro").TamanoFuente = 12;
        h.RangosCombinados.Add("A1:" + ultima + "1"); h.AltosFilas[1] = 30;
        h.AltosFilas[2] = 12;
        string ubicacion = "DPTO: " + (documento.Datos?.Departamento ?? "") + "  PROV: " +
            (documento.Datos?.Provincia ?? "") + "  DIST: " + (documento.Datos?.Distrito ?? "");
        var datos = new[] { ("PROYECTO", documento.Nombre ?? ""), ("PROPIETARIO", documento.Datos?.Propietario ?? ""),
            ("UBICACIÓN", ubicacion), ("FECHA DE PROY.", documento.Datos?.FechaElaboracion?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "No registrado"),
            ("PRESUPUESTO", presupuestoId == null ? "Todos los presupuestos · " + moneda :
                documento.Presupuestos.Single(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)).ToString() + " · " + moneda) };
        for (int n = 0; n < datos.Length; n++)
        {
            int fila = n + 3;
            Texto(h, fila, 1, datos[n].Item1 + ":").Bordes = false;
            Texto(h, fila, 2, datos[n].Item2).Bordes = false;
            h.RangosCombinados.Add("B" + fila + ":" + ultima + fila);
            h.AltosFilas[fila] = n == 0 ? 38 : 24;
        }
        Celda(h, 1, 1).Bordes = false; h.AltosFilas[8] = 12; h.AltosFilas[9] = 54;
        string[] titulos = { "Item", "Descripción", "Unid.", "Cantidad", "Precio", "Parcial" };
        for (int c = 1; c <= h.Columnas; c++)
            Texto(h, 9, c, c <= 6 ? titulos[c - 1] : "Mes " + (c - 6) + "\nDel " + Fecha(periodos[c - 7].Inicio) + "\nAl " + Fecha(periodos[c - 7].Fin),
                true, "Centro").ColorFondo = "ECEEF1";
    }
}
