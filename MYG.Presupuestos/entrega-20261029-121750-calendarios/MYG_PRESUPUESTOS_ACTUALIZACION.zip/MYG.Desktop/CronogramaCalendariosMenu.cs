using System;
using System.Windows.Forms;

namespace MYG_2027;

internal enum MYGAlcanceCalendarioFinanciero { Presupuesto, Proyecto }

internal static class MYGMenuCalendariosCronograma
{
    internal static ContextMenuStrip Crear(bool adquisiciones, Action<MYGAlcanceCalendarioFinanciero> ejecutar,
        Func<string> obtenerNombrePresupuesto)
    {
        ArgumentNullException.ThrowIfNull(ejecutar);
        ArgumentNullException.ThrowIfNull(obtenerNombrePresupuesto);
        string tipo = adquisiciones ? "adquisiciones" : "valorizado";
        var menu = new ContextMenuStrip { Name = "cronograma_menu_" + tipo };
        var presupuesto = new ToolStripMenuItem("Calendario del presupuesto")
        {
            Name = "cronograma_" + tipo + "_presupuesto", Tag = MYGAlcanceCalendarioFinanciero.Presupuesto,
            AccessibleName = "Calendario del presupuesto activo",
            ToolTipText = "Abre el calendario del presupuesto activo para revisar, imprimir o exportar."
        };
        var proyecto = new ToolStripMenuItem("Calendario del proyecto")
        {
            Name = "cronograma_" + tipo + "_proyecto", Tag = MYGAlcanceCalendarioFinanciero.Proyecto,
            AccessibleName = "Calendario de todos los presupuestos del proyecto",
            ToolTipText = "Abre el calendario de todos los presupuestos del proyecto para revisar, imprimir o exportar."
        };
        presupuesto.Click += (_, _) => ejecutar(MYGAlcanceCalendarioFinanciero.Presupuesto);
        proyecto.Click += (_, _) => ejecutar(MYGAlcanceCalendarioFinanciero.Proyecto);
        menu.Items.AddRange(new ToolStripItem[] { presupuesto, proyecto });
        void Actualizar()
        {
            string nombre = obtenerNombrePresupuesto();
            presupuesto.Enabled = !string.IsNullOrWhiteSpace(nombre);
            presupuesto.Text = presupuesto.Enabled ? "Calendario del presupuesto: " + nombre : "Calendario del presupuesto (sin selección)";
        }
        Actualizar();
        menu.Opening += (_, _) => Actualizar();
        return menu;
    }
}
