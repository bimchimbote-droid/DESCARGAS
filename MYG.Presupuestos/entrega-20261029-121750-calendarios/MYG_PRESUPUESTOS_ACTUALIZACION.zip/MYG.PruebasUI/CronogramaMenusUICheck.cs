using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class CronogramaMenusUICheck
{
    internal static readonly string[] NombresImpresion =
    {
        "imprimir_presupuesto_seleccionado", "imprimir_todos_presupuestos", "imprimir_hoja_resumen",
        "imprimir_analisis_costos_unitarios", "imprimir_consolidado_costos_unitarios", "imprimir_metrados",
        "exportar_metrados_excel", "imprimir_metrados_aceros", "exportar_metrados_aceros_excel",
        "exportar_metrados_por_plantilla_excel", "imprimir_programacion_gantt"
    };

    internal static readonly string[] NombresExportacion =
    {
        "cronograma_exportar_nativo", "cronograma_exportar_project_tareas", "cronograma_exportar_project_recursos",
        "cronograma_exportar_xml_tareas", "cronograma_exportar_xml_recursos", "cronograma_exportar_pdf",
        "cronograma_exportar_xlsx", "cronograma_exportar_texto", "cronograma_exportar_mht", "cronograma_exportar_csv"
    };

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarExportacion(exige);
        VerificarImpresion(exige);
        VerificarCalendarios(exige);
        VerificarAlcancesCalendarios(exige);
    }

    private static void VerificarCalendarios(Action<bool, string> exige)
    {
        foreach (bool adquisiciones in new[] { true, false })
        {
            string nombre = "ESTRUCTURAS";
            var ejecuciones = new List<MYGAlcanceCalendarioFinanciero>();
            using var menu = MYGMenuCalendariosCronograma.Crear(adquisiciones, ejecuciones.Add, () => nombre);
            var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
            string tipo = adquisiciones ? "adquisiciones" : "valorizado";
            exige(opciones.Select(o => o.Name).SequenceEqual(new[]
                { "cronograma_" + tipo + "_presupuesto", "cronograma_" + tipo + "_proyecto" }) &&
                opciones.All(o => o.Enabled) && opciones[0].Text.Contains(nombre) && ejecuciones.Count == 0,
                "Cada calendario debe ofrecer presupuesto activo y proyecto, identificando el presupuesto sin exportar ni abrir una vista al construir el menú.");
            foreach (var opcion in opciones) opcion.PerformClick();
            exige(ejecuciones.SequenceEqual(new[] { MYGAlcanceCalendarioFinanciero.Presupuesto, MYGAlcanceCalendarioFinanciero.Proyecto }),
                "Los dos alcances del calendario deben ejecutar una sola vez su callback correspondiente, en orden y sin intercambiar presupuesto y proyecto.");
            void Abrir() => typeof(ContextMenuStrip).GetMethod("OnOpening", BindingFlags.Instance | BindingFlags.NonPublic)!
                .Invoke(menu, new object[] { new CancelEventArgs() });
            nombre = "ARQUITECTURA"; Abrir();
            exige(opciones[0].Enabled && opciones[0].Text.Contains(nombre) && !opciones[0].Text.Contains("ESTRUCTURAS"),
                "Volver a abrir el menú debe reflejar el presupuesto activo actual y no conservar la selección anterior.");
            nombre = null; Abrir();
            opciones[0].PerformClick();
            exige(!opciones[0].Enabled && opciones[1].Enabled && ejecuciones.Count == 2,
                "Sin un presupuesto activo, sólo su calendario debe quedar deshabilitado y no debe ejecutar el callback; el calendario del proyecto permanece disponible.");
        }
    }

    private static void VerificarAlcancesCalendarios(Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Proyecto de calendarios", "Presupuesto A");
        var primero = documento.Presupuestos.Single();
        var segundo = new MYGPresupuestoDocumento { Nombre = "Presupuesto B", Item = "02" };
        documento.Presupuestos.Add(segundo);
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 5) };
        foreach (var presupuesto in documento.Presupuestos)
        {
            string sufijo = ReferenceEquals(presupuesto, primero) ? "A" : "B";
            var recurso = new MYGInsumo { Codigo = "MAT-" + sufijo, Descripcion = "Recurso alcance " + sufijo, Unidad = "und", Precio = 10 };
            presupuesto.Costos.Insumos.Add(recurso);
            string id = MYGProyectoStorage.NuevoId();
            var partida = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = "01", Posicion = 1,
                TipoPropuesta = "PARTIDA", Descripcion = "Partida alcance " + sufijo, Unidad = "und" };
            partida.Costos.Cantidad = 2;
            partida.Costos.Analisis.Add(new() { InsumoId = recurso.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 1 });
            presupuesto.Items.Add(partida);
            plan.Tareas.Add(new() { Nombre = partida.Descripcion, Codigo = partida.Item, PresupuestoId = presupuesto.Id,
                PartidaId = partida.Id, DuracionDias = 2 });
        }
        MYGProyectoStorage.Validar(documento);
        string antes = JsonSerializer.Serialize(documento), planAntes = JsonSerializer.Serialize(plan);
        int cambios = 0;
        using var panel = new MYGPanelCronograma(() => plan, _ => cambios++, () => false,
            () => cambios++, () => cambios++, () => cambios++, () => documento);
        foreach (string tipo in new[] { "adquisiciones", "valorizado" })
        {
            var boton = panel.BotonesCinta.Single(b => b.Name == "cronograma_" + tipo);
            exige(boton.Text.Contains('▾') && boton.ContextMenuStrip?.Items.OfType<ToolStripMenuItem>().Count() == 2,
                "Los dos botones reales de la cinta deben mostrar indicador de desplegable y tener asociados los alcances presupuesto y proyecto.");
        }
        foreach (bool adquisiciones in new[] { true, false })
        {
            string prefijo = adquisiciones ? "Recurso alcance " : "Partida alcance ";
            bool Contiene(IReadOnlyList<MYGHojaReporteProyecto> reportes, string texto) => reportes.Any(r =>
                r.Hoja.Celdas.Keys.Any(c => new MYGHojaCalculo(r.Hoja).Mostrar(c).Contains(texto, StringComparison.Ordinal)));
            var presupuesto = panel.PrepararCalendarioFinanciero(adquisiciones, MYGAlcanceCalendarioFinanciero.Presupuesto);
            var proyecto = panel.PrepararCalendarioFinanciero(adquisiciones, MYGAlcanceCalendarioFinanciero.Proyecto);
            exige(Contiene(presupuesto, prefijo + "A") && !Contiene(presupuesto, prefijo + "B") &&
                Contiene(proyecto, prefijo + "A") && Contiene(proyecto, prefijo + "B"),
                "Preparar el calendario del presupuesto debe incluir sólo el activo; el del proyecto debe reunir todos sus presupuestos, también en lectura.");
            documento.PresupuestoActivoId = segundo.Id;
            var cambiado = panel.PrepararCalendarioFinanciero(adquisiciones, MYGAlcanceCalendarioFinanciero.Presupuesto);
            exige(Contiene(cambiado, prefijo + "B") && !Contiene(cambiado, prefijo + "A"),
                "La preparación debe resolver el presupuesto activo al ejecutar la opción y no al construir el panel.");
            documento.PresupuestoActivoId = primero.Id;
        }
        exige(cambios == 0 && JsonSerializer.Serialize(documento) == antes && JsonSerializer.Serialize(plan) == planAntes,
            "Preparar calendarios para exportación no debe guardar, registrar historial ni modificar el proyecto, sus partidas o el cronograma.");
        documento.PresupuestoActivoId = "PRESUPUESTO_INEXISTENTE";
        bool rechazado = false;
        try { panel.PrepararCalendarioFinanciero(false, MYGAlcanceCalendarioFinanciero.Presupuesto); }
        catch (InvalidOperationException) { rechazado = true; }
        exige(rechazado && cambios == 0, "Un presupuesto activo inexistente debe rechazarse sin exportar silenciosamente el proyecto completo ni modificar datos.");
    }

    private static void VerificarExportacion(Action<bool, string> exige)
    {
        var ejecuciones = new List<MYGDestinoExportacionCronograma>();
        using var menu = MYGMenuExportacionCronograma.Crear(ejecuciones.Add);
        var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
        var destinos = new[]
        {
            MYGDestinoExportacionCronograma.Nativo,
            MYGDestinoExportacionCronograma.ProjectTareas, MYGDestinoExportacionCronograma.ProjectRecursos,
            MYGDestinoExportacionCronograma.XmlTareas, MYGDestinoExportacionCronograma.XmlRecursos,
            MYGDestinoExportacionCronograma.Pdf, MYGDestinoExportacionCronograma.Xlsx,
            MYGDestinoExportacionCronograma.Texto, MYGDestinoExportacionCronograma.Mht,
            MYGDestinoExportacionCronograma.Csv
        };
        exige(opciones.Select(o => o.Name).SequenceEqual(NombresExportacion) && opciones.All(o => o.Enabled),
            "Exportar cronograma debe ofrecer sus diez destinos en el orden solicitado, separando Project y XML, tareas y recursos.");
        exige(ejecuciones.Count == 0,
            "Construir el desplegable de Exportar no debe generar archivos ni iniciar aplicaciones externas.");
        foreach (var opcion in opciones) opcion.PerformClick();
        exige(ejecuciones.SequenceEqual(destinos),
            "Cada destino de Exportar debe invocar una sola vez su callback exacto, sin intercambiar tareas, recursos, MPP ni XML.");

        foreach (var alcance in new[] { "tareas", "recursos" })
        {
            var mpp = opciones.Single(o => o.Name == "cronograma_exportar_project_" + alcance);
            var xml = opciones.Single(o => o.Name == "cronograma_exportar_xml_" + alcance);
            string Descripcion(ToolStripMenuItem item) => item.Text + " " + item.ToolTipText + " " + item.AccessibleDescription;
            exige(Descripcion(mpp).Contains(".mpp", StringComparison.OrdinalIgnoreCase) &&
                Descripcion(xml).Contains("XML", StringComparison.OrdinalIgnoreCase) && mpp.Text != xml.Text,
                "Los destinos Project y XML deben explicar formatos distintos; un archivo XML no debe presentarse como un MPP nativo.");
        }
    }

    private static void VerificarImpresion(Action<bool, string> exige)
    {
        var ejecuciones = new List<string>();
        using var menu = EditorForm.CrearMenuImprimirProyecto(
            tipo => ejecuciones.Add("imprimir:" + tipo),
            plantilla => ejecuciones.Add("excel:" + (plantilla ?? "todas")),
            () => ejecuciones.Add("excel:por_plantilla"), true, true, true, true, true,
            () => ejecuciones.Add("gantt"));
        var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
        exige(opciones.Select(o => o.Name).SequenceEqual(NombresImpresion) && opciones.All(o => o.Enabled),
            "Imprimir desde CPM debe conservar los diez reportes de presupuesto y añadir Programación Gantt como último destino.");
        exige(opciones[^1].Text.Contains("Gantt", StringComparison.OrdinalIgnoreCase) && ejecuciones.Count == 0,
            "Abrir el menú de impresión debe identificar Programación Gantt sin imprimir ni abrir todavía una vista previa.");
        foreach (var opcion in opciones) opcion.PerformClick();
        exige(ejecuciones.SequenceEqual(new[]
        {
            "imprimir:" + MYGTipoReporteProyecto.PresupuestoSeleccionado,
            "imprimir:" + MYGTipoReporteProyecto.TodosPresupuestos,
            "imprimir:" + MYGTipoReporteProyecto.HojaResumen,
            "imprimir:" + MYGTipoReporteProyecto.AnalisisCostosUnitarios,
            "imprimir:" + MYGTipoReporteProyecto.ConsolidadoCostosUnitarios,
            "imprimir:" + MYGTipoReporteProyecto.Metrados,
            "excel:todas", "imprimir:" + MYGTipoReporteProyecto.MetradosAceros,
            "excel:" + MYGPlantillasMetrado.Aceros, "excel:por_plantilla", "gantt"
        }), "Los destinos heredados de presupuesto y Programación Gantt deben conservar su enrutado y ejecutarse una sola vez por clic.");
    }
}
