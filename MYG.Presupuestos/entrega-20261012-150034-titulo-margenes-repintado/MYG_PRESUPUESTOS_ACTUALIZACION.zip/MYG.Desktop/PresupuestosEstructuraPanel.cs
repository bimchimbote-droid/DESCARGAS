using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Func<MYGProyectoDocumento> obtenerProyectoEstructura;
    private Action<string> activarPresupuestoEstructura;
    private Action<object> mostrarMenuEstructura;
    private Action<object, string, string> editarEstructura;
    private Func<IEnumerable<MYGUnidadCatalogo>> obtenerUnidadesEstructura;
    private readonly Dictionary<DataGridViewRow, MYGPresupuestoDocumento> propietariosEstructura = new();
    private readonly Dictionary<DataGridViewRow, int> nivelesEstructura = new();
    private readonly HashSet<string> expandiblesEstructura = new(StringComparer.OrdinalIgnoreCase);
    private readonly System.Windows.Forms.Timer animacionEstructura = new() { Interval = 16 };
    private readonly Stopwatch tiempoEstructura = new();
    private string nodoAnimadoEstructura;
    private float anguloInicialEstructura, anguloFinalEstructura;
    private object nodoEstructura, nodoEnEdicion;
    private string columnaEstructuraEnEdicion, valorEstructuraAntes;
    private bool seleccionVaciaEstructura, seleccionandoEstructura, validandoEstructura;
    private MYGSelectorUnidadPartida selectorUnidadEstructura;
    private bool huboEdicionEstructura, aplicandoSeleccionEstructura;
    private MYGRefrescoDiferido refrescoDiferidoEstructura;
    internal object SeleccionEstructura => estructura.SelectedRows.Cast<DataGridViewRow>().FirstOrDefault()?.Tag;

    internal void InicializarEstructura(Func<MYGProyectoDocumento> proyecto, Action<string> activarPresupuesto,
        Action<object> menu, Action<object, string, string> editar, Func<IEnumerable<MYGUnidadCatalogo>> unidades)
    {
        obtenerProyectoEstructura = proyecto; activarPresupuestoEstructura = activarPresupuesto;
        mostrarMenuEstructura = menu; editarEstructura = editar; obtenerUnidadesEstructura = unidades;
    }

    private IEnumerable<MYGPresupuestoDocumento> PresupuestosEstructura =>
        obtenerProyectoEstructura?.Invoke()?.Presupuestos ?? (P == null ? Enumerable.Empty<MYGPresupuestoDocumento>() : new[] { P });

    private static string IdNodoEstructura(object nodo) => nodo switch
    {
        MYGPresupuestoDocumento p => "P:" + p.Id,
        ItemPresupuestoDelphin i => "I:" + i.Id,
        _ => null
    };
    private static string CodigoEstructura(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
        string.IsNullOrWhiteSpace(p.Item) ? i.Item : string.IsNullOrWhiteSpace(i.Item) ? p.Item : p.Item + "." + i.Item;
    private MYGPresupuestoDocumento PropietarioEstructura(object nodo) => nodo is MYGPresupuestoDocumento p
        ? PresupuestosEstructura.FirstOrDefault(x => x.Id == p.Id) :
        nodo is ItemPresupuestoDelphin i ? PresupuestosEstructura.FirstOrDefault(x => x.Items.Any(h => ReferenceEquals(h, i)))
            ?? PresupuestosEstructura.FirstOrDefault(x => x.Id == P?.Id && x.Items.Any(h => h.Id == i.Id))
            ?? PresupuestosEstructura.FirstOrDefault(x => x.Items.Any(h => h.Id == i.Id)) : null;
    private object NodoEstructuraVigente(object nodo) => nodo is ItemPresupuestoDelphin i
        ? PropietarioEstructura(i)?.Items.FirstOrDefault(x => x.Id == i.Id)
        : nodo is MYGPresupuestoDocumento p ? PropietarioEstructura(p) : null;

    private void PrepararEstructura()
    {
        refrescoDiferidoEstructura = new MYGRefrescoDiferido(
            accion => BeginInvoke(accion),
            () => !IsDisposed && !Disposing && IsHandleCreated && !cargando && !validandoEstructura &&
                !finalizandoEdicion && !estructura.IsCurrentCellInEditMode && selectorUnidadEstructura?.Visible != true,
            tipo => Intentar(() =>
            {
                if ((tipo & MYGTipoRefresco.Estructura) != 0) Refrescar();
                else ActualizarCalculos();
            }));
        HandleCreated += (s, e) => SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
        PrepararArrastreEstructura();
        estructura.ReadOnly = false; estructura.EditMode = DataGridViewEditMode.EditProgrammatically;
        estructura.Columns["CANT"].DefaultCellStyle.Format = "N2";
        estructura.DefaultCellStyle.Padding = new(4, 4, 4, 4);
        estructura.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        foreach (string c in new[] { "ITEM", "CANT", "UND", "PU", "TOTAL" }) estructura.Columns[c].DefaultCellStyle.WrapMode = DataGridViewTriState.False;
        estructura.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
        estructura.RowTemplate.MinimumHeight = 29;
        estructura.CellPainting += DibujarJerarquia;
        estructura.CellPainting += DibujarUnidadEstructura;
        animacionEstructura.Tick += (s, e) => { estructura.InvalidateColumn(estructura.Columns["ITEM"].Index); if (tiempoEstructura.ElapsedMilliseconds >= 140) { animacionEstructura.Stop(); nodoAnimadoEstructura = null; } };
        Disposed += (s, e) => { refrescoDiferidoEstructura.Cancelar(); CerrarSelectorUnidadEstructura(); animacionEstructura.Stop(); animacionEstructura.Dispose(); };
        estructura.Scroll += (s, e) => CerrarSelectorUnidadEstructura();
        estructura.SizeChanged += (s, e) => CerrarSelectorUnidadEstructura();
        estructura.ColumnWidthChanged += (s, e) => CerrarSelectorUnidadEstructura();
        estructura.DataError += (s, e) => { e.ThrowException = false; if (e.RowIndex >= 0) estructura.Rows[e.RowIndex].ErrorText = "Seleccione una unidad de la lista."; };
        estructura.Columns["ITEM"].ReadOnly = estructura.Columns["DESC"].ReadOnly = false;
        estructura.SelectionChanged += (s, e) =>
        {
            if (cargando || seleccionandoEstructura || validandoEstructura) return;
            Intentar(() =>
            {
                seleccionandoEstructura = true;
                try { FinalizarEdicion(); }
                finally { seleccionandoEstructura = false; }
                AplicarSeleccionEstructura();
            });
        };
        estructura.MouseDown += (s, e) =>
        {
            if (e.Button is not (MouseButtons.Left or MouseButtons.Right)) return;
            var posicion = estructura.HitTest(e.X, e.Y);
            if (e.Button == MouseButtons.Left && posicion.RowIndex >= 0) return;
            Intentar(() =>
            {
                FinalizarEdicion();
                seleccionandoEstructura = true;
                try
                {
                    estructura.ClearSelection();
                    if (posicion.RowIndex >= 0)
                    {
                        var fila = estructura.Rows[posicion.RowIndex];
                        estructura.CurrentCell = fila.Cells[posicion.ColumnIndex >= 0 ? posicion.ColumnIndex : estructura.Columns["DESC"].Index];
                        fila.Selected = true;
                    }
                    else estructura.CurrentCell = null;
                }
                finally { seleccionandoEstructura = false; }
                AplicarSeleccionEstructura();
                if (e.Button == MouseButtons.Right) mostrarMenuEstructura?.Invoke(SeleccionEstructura);
            });
        };
        estructura.CellMouseClick += (s, e) =>
        {
            if (e.Button != MouseButtons.Left || e.RowIndex < 0 || e.ColumnIndex < 0) return;
            var nodo = estructura.Rows[e.RowIndex].Tag;
            if (estructura.Columns[e.ColumnIndex].Name == "ITEM" && PuedeExpandir(nodo) &&
                e.X >= SangriaEstructura(estructura.Rows[e.RowIndex]) && e.X < SangriaEstructura(estructura.Rows[e.RowIndex]) + (int)(20 * DeviceDpi / 96F))
                Intentar(() => AlternarNodo(nodo));
            else if (estructura.Columns[e.ColumnIndex].Name == "UND" && !estructura.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly)
                Intentar(() => MostrarSelectorUnidadEstructura(estructura.Rows[e.RowIndex]));
            else if (estructura.Columns[e.ColumnIndex].Name == "CANT" && !estructura.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly)
                Intentar(() => { FinalizarEdicion(); estructura.CurrentCell = estructura.Rows[e.RowIndex].Cells[e.ColumnIndex]; estructura.BeginEdit(true); });
        };
        estructura.CellDoubleClick += (s, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || estructura.Columns[e.ColumnIndex].Name is not ("DESC" or "ITEM" or "CANT" or "UND") || estructura.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly) return;
            if (estructura.Columns[e.ColumnIndex].Name == "ITEM" && PuedeExpandir(estructura.Rows[e.RowIndex].Tag))
            {
                int x = estructura.PointToClient(Cursor.Position).X - estructura.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false).Left;
                if (x < SangriaEstructura(estructura.Rows[e.RowIndex]) + (int)(20 * DeviceDpi / 96F)) return;
            }
            if (estructura.Columns[e.ColumnIndex].Name == "UND")
                Intentar(() => MostrarSelectorUnidadEstructura(estructura.Rows[e.RowIndex]));
            else Intentar(() => { FinalizarEdicion(); estructura.CurrentCell = estructura.Rows[e.RowIndex].Cells[e.ColumnIndex]; estructura.BeginEdit(true); });
        };
        estructura.KeyDown += (s, e) =>
        {
            if (estructura.IsCurrentCellInEditMode || estructura.CurrentRow == null) return;
            if (estructura.CurrentCell?.OwningColumn.Name == "UND" && !estructura.CurrentCell.ReadOnly &&
                (e.KeyCode is Keys.F2 or Keys.F4 or Keys.Enter or Keys.Space || e.Alt && e.KeyCode == Keys.Down))
            {
                Intentar(() => MostrarSelectorUnidadEstructura(estructura.CurrentRow));
                e.Handled = e.SuppressKeyPress = true;
            }
            else if (e.KeyCode is Keys.Left or Keys.Right && PuedeExpandir(estructura.CurrentRow.Tag))
            {
                var nodo = estructura.CurrentRow.Tag; bool cerrado = contraidos.Contains(IdNodoEstructura(nodo));
                if (e.KeyCode == Keys.Right && cerrado || e.KeyCode == Keys.Left && !cerrado) Intentar(() => AlternarNodo(nodo));
                e.Handled = true; e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == Keys.F2)
            {
                Intentar(() => { if (estructura.CurrentCell?.ReadOnly != false) estructura.CurrentCell = estructura.CurrentRow.Cells["DESC"]; estructura.BeginEdit(true); });
                e.Handled = true;
            }
        };
        estructura.CellBeginEdit += (s, e) =>
        {
            if (cargando || editarEstructura == null) { e.Cancel = true; return; }
            // La unidad se elige en el desplegable de dos columnas; nunca se escribe en una celda de texto.
            if (estructura.Columns[e.ColumnIndex].Name == "UND") { e.Cancel = true; return; }
            var fila = estructura.Rows[e.RowIndex]; nodoEnEdicion = NodoEstructuraVigente(fila.Tag);
            if (nodoEnEdicion == null) { e.Cancel = true; return; }
            fila.Tag = nodoEnEdicion;
            propietariosEstructura[fila] = PropietarioEstructura(nodoEnEdicion);
            huboEdicionEstructura = false;
            columnaEstructuraEnEdicion = estructura.Columns[e.ColumnIndex].Name;
            valorEstructuraAntes = columnaEstructuraEnEdicion switch
            {
                "CANT" when nodoEnEdicion is ItemPresupuestoDelphin item => MYGMotorPresupuestos.Cantidad(propietariosEstructura[fila], item).ToString("0.################", CultureInfo.InvariantCulture),
                "UND" => (nodoEnEdicion as ItemPresupuestoDelphin)?.Unidad,
                "ITEM" => nodoEnEdicion is MYGPresupuestoDocumento p ? p.Item : (nodoEnEdicion as ItemPresupuestoDelphin)?.Item,
                _ => nodoEnEdicion is MYGPresupuestoDocumento presupuesto ? presupuesto.Nombre : (nodoEnEdicion as ItemPresupuestoDelphin)?.Descripcion
            };
            fila.Cells[e.ColumnIndex].Value = valorEstructuraAntes;
        };
        estructura.CellValidating += (s, e) =>
        {
            if (cargando || nodoEnEdicion == null || estructura.Columns[e.ColumnIndex].Name != columnaEstructuraEnEdicion) return;
            try
            {
                AplicarValorEstructuraEnEdicion(e.FormattedValue);
                estructura.Rows[e.RowIndex].ErrorText = "";
            }
            catch (Exception ex) { e.Cancel = true; estructura.Rows[e.RowIndex].ErrorText = ex.Message; }
        };
        estructura.CellEndEdit += (s, e) =>
        {
            estructura.Rows[e.RowIndex].ErrorText = "";
            string columna = columnaEstructuraEnEdicion;
            bool cambiado = huboEdicionEstructura;
            nodoEnEdicion = null; columnaEstructuraEnEdicion = valorEstructuraAntes = null;
            huboEdicionEstructura = false;
            if (cambiado && (columna is "ITEM" or "DESC"))
                ActualizarIdentificacionDetalle();
            if (columna == "CANT" && estructura.Rows[e.RowIndex].Tag is ItemPresupuestoDelphin partida &&
                propietariosEstructura.TryGetValue(estructura.Rows[e.RowIndex], out var propietario))
                Intentar(() => PonerValor(estructura.Rows[e.RowIndex].Cells["CANT"], MYGMotorPresupuestos.Cantidad(propietario, partida)));
            // Cantidad no altera el árbol: conservar las filas y el desplazamiento.
            // Escape o una celda sin cambios tampoco reconstruyen la estructura.
            SolicitarRefrescoEstructura(cambiado && (columna is "ITEM" or "DESC")
                ? MYGTipoRefresco.Estructura : cambiado ? MYGTipoRefresco.Calculos : MYGTipoRefresco.Ninguno);
            // CellEndEdit puede ocurrir antes de que DataGridView retire el
            // control de edición. Reintentar al terminar ese mensaje.
            if (!IsDisposed && IsHandleCreated)
                BeginInvoke(new Action(() => refrescoDiferidoEstructura.Reintentar()));
        };
    }

    private void ConfirmarValorEstructuraEnEdicion()
    {
        if (!estructura.IsCurrentCellInEditMode || nodoEnEdicion == null || estructura.CurrentCell == null) return;
        // EndEdit confirma la celda, pero no garantiza CellValidating cuando
        // se llama desde un comando. Aplicar el texto antes de retirar el editor
        // evita mostrar el nombre nuevo en la fila y conservar el viejo en el modelo.
        try
        {
            AplicarValorEstructuraEnEdicion(estructura.CurrentCell.EditedFormattedValue);
            estructura.CurrentRow.ErrorText = "";
        }
        catch (Exception ex)
        {
            estructura.CurrentRow.ErrorText = ex.Message;
            throw;
        }
    }

    private void AplicarValorEstructuraEnEdicion(object valor)
    {
        string texto = Convert.ToString(valor)?.Trim() ?? "";
        bool cambiaFuente = columnaEstructuraEnEdicion == "CANT" && nodoEnEdicion is ItemPresupuestoDelphin partida &&
            partida.Costos.FuenteMetrado != MYGFuenteMetrado.Cantidad;
        if (texto == (valorEstructuraAntes ?? "") && !cambiaFuente) return;
        validandoEstructura = true;
        try
        {
            editarEstructura(nodoEnEdicion, columnaEstructuraEnEdicion, texto);
            huboEdicionEstructura = true;
            valorEstructuraAntes = texto;
        }
        finally { validandoEstructura = false; }
    }

    private void SolicitarRefrescoEstructura(MYGTipoRefresco tipo)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        refrescoDiferidoEstructura?.Solicitar(tipo);
    }

    private Control BarraEstructura()
    {
        return Barra(Boton("Expandir todo", () => { FinalizarEdicion(); contraidos.Clear(); Refrescar(); }),
            Boton("Contraer todo", () => {
                FinalizarEdicion(); foreach (var p in PresupuestosEstructura)
                { contraidos.Add(IdNodoEstructura(p)); foreach (var i in p.Items.Where(MYGProyectoStorage.EsTitulo)) contraidos.Add(IdNodoEstructura(i)); }
                Refrescar();
            }));
    }
    private bool PuedeExpandir(object nodo) => IdNodoEstructura(nodo) is string id && expandiblesEstructura.Contains(id);
    private int SangriaEstructura(DataGridViewRow fila) => (int)((nivelesEstructura.GetValueOrDefault(fila) * 13 + 3) * DeviceDpi / 96F);
    private void AlternarNodo(object nodo)
    {
        FinalizarEdicion(); string id = IdNodoEstructura(nodo); bool estabaCerrado = contraidos.Contains(id);
        if (!contraidos.Add(id)) contraidos.Remove(id); Refrescar();
        if (SystemInformation.IsMenuAnimationEnabled && !SystemInformation.HighContrast)
        { nodoAnimadoEstructura = id; anguloInicialEstructura = estabaCerrado ? 0 : 90; anguloFinalEstructura = estabaCerrado ? 90 : 0; tiempoEstructura.Restart(); animacionEstructura.Start(); }
    }
    private void DibujarJerarquia(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex != estructura.Columns["ITEM"].Index) return;
        e.Paint(e.ClipBounds, DataGridViewPaintParts.All); e.Handled = true;
        var fila = estructura.Rows[e.RowIndex];
        float escala = DeviceDpi / 96F, y = e.CellBounds.Top + e.CellBounds.Height / 2F;
        if (!PuedeExpandir(fila.Tag)) return;
        float centro = e.CellBounds.Left + SangriaEstructura(fila) + 8 * escala, r = 4 * escala;
        var anterior = e.Graphics.SmoothingMode; e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        float angulo = contraidos.Contains(IdNodoEstructura(fila.Tag)) && buscar.Text.Trim().Length == 0 ? 0 : 90;
        if (nodoAnimadoEstructura == IdNodoEstructura(fila.Tag) && buscar.Text.Trim().Length == 0)
        { double p = Math.Min(1, tiempoEstructura.Elapsed.TotalMilliseconds / 140); angulo = anguloInicialEstructura + (anguloFinalEstructura - anguloInicialEstructura) * (float)(p * p * (3 - 2 * p)); }
        var estado = e.Graphics.Save(); e.Graphics.TranslateTransform(centro, y); e.Graphics.RotateTransform(angulo);
        using var color = new SolidBrush(MYG2027_TemaComercial.Secundario);
        e.Graphics.FillPolygon(color, new[] { new PointF(-r / 2, -r), new PointF(-r / 2, r), new PointF(r, 0) });
        e.Graphics.Restore(estado); e.Graphics.SmoothingMode = anterior;
    }

    private void DibujarUnidadEstructura(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex != estructura.Columns["UND"].Index) return;
        var celda = estructura.Rows[e.RowIndex].Cells[e.ColumnIndex];
        if (celda.ReadOnly || estructura.Rows[e.RowIndex].Tag is not ItemPresupuestoDelphin) return;
        e.Paint(e.ClipBounds, DataGridViewPaintParts.All); e.Handled = true;
        int ancho = (int)Math.Round(18 * DeviceDpi / 96F);
        var boton = new Rectangle(e.CellBounds.Right - ancho - 1, e.CellBounds.Top + 1, ancho, Math.Max(1, e.CellBounds.Height - 2));
        var estado = e.Graphics.Save(); e.Graphics.SetClip(Rectangle.Intersect(e.ClipBounds, e.CellBounds));
        using var fondo = new SolidBrush(MYG2027_TemaComercial.AzulSuave);
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        using var flecha = new SolidBrush(MYG2027_TemaComercial.Texto);
        e.Graphics.FillRectangle(fondo, boton);
        e.Graphics.DrawRectangle(borde, boton.X, boton.Y, Math.Max(0, boton.Width - 1), Math.Max(0, boton.Height - 1));
        float centroX = boton.Left + boton.Width / 2F, centroY = boton.Top + boton.Height / 2F;
        float radio = Math.Max(2, 3 * DeviceDpi / 96F);
        e.Graphics.FillPolygon(flecha, new[] { new PointF(centroX - radio, centroY - radio / 2), new PointF(centroX + radio, centroY - radio / 2), new PointF(centroX, centroY + radio / 2) });
        e.Graphics.Restore(estado);
    }

    internal void CerrarSelectorUnidadEstructura()
    {
        var selector = selectorUnidadEstructura;
        if (selector == null) return;
        if (selector.IsDisposed) { selectorUnidadEstructura = null; return; }
        selector.Close(); selector.Dispose();
    }

    private void MostrarSelectorUnidadEstructura(DataGridViewRow fila)
    {
        if (cargando || editarEstructura == null || fila == null || fila.DataGridView != estructura ||
            fila.Cells["UND"].ReadOnly || fila.Tag is not ItemPresupuestoDelphin item) return;
        string presupuestoId = propietariosEstructura.GetValueOrDefault(fila)?.Id;
        FinalizarEdicion();
        // FinalizarEdicion puede actualizar el árbol: recuperar siempre la fila por su identidad.
        fila = estructura.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is ItemPresupuestoDelphin i && i.Id == item.Id && propietariosEstructura.GetValueOrDefault(r)?.Id == presupuestoId);
        if (fila == null || fila.Cells["UND"].ReadOnly) return;
        item = (ItemPresupuestoDelphin)fila.Tag;
        estructura.CurrentCell = fila.Cells["UND"];
        var unidades = (obtenerUnidadesEstructura?.Invoke() ?? Enumerable.Empty<MYGUnidadCatalogo>())
            .Concat(PresupuestosEstructura.SelectMany(p => p.Items).Where(i => !string.IsNullOrWhiteSpace(i.Unidad))
                .Select(i => new MYGUnidadCatalogo { Simbolo = i.Unidad, Descripcion = i.Unidad }));
        var selector = new MYGSelectorUnidadPartida(unidades, item.Unidad, estructura.Font, DeviceDpi / 96F, simbolo =>
            Intentar(() =>
            {
                try
                {
                    if (!string.Equals(item.Unidad, simbolo, StringComparison.Ordinal))
                    { validandoEstructura = true; editarEstructura(item, "UND", simbolo); }
                }
                finally
                {
                    validandoEstructura = false;
                    var actualizada = estructura.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is ItemPresupuestoDelphin i && i.Id == item.Id && propietariosEstructura.GetValueOrDefault(r)?.Id == presupuestoId);
                    if (actualizada != null)
                    {
                        PonerValor(actualizada.Cells["UND"], item.Unidad);
                        estructura.CurrentCell = actualizada.Cells["UND"];
                    }
                    CargarDetalle();
                    estructura.Focus();
                }
            }));
        selectorUnidadEstructura = selector;
        selector.Closed += (s, e) =>
        {
            if (!ReferenceEquals(selectorUnidadEstructura, selector)) return;
            selectorUnidadEstructura = null;
            refrescoDiferidoEstructura.Reintentar();
        };
        var celda = estructura.GetCellDisplayRectangle(estructura.Columns["UND"].Index, fila.Index, true);
        selector.Abrir(estructura, new Rectangle(estructura.PointToScreen(celda.Location), celda.Size));
    }

    private void AplicarSeleccionEstructura(bool forzar = false)
    {
        if (aplicandoSeleccionEstructura) return;
        var elegido = NodoEstructuraVigente(SeleccionEstructura);
        var filaSeleccionada = estructura.SelectedRows.Cast<DataGridViewRow>().FirstOrDefault();
        var propietario = filaSeleccionada != null && propietariosEstructura.TryGetValue(filaSeleccionada, out var filaPresupuesto)
            ? PropietarioEstructura(filaPresupuesto) : PropietarioEstructura(elegido);
        if (!forzar && ReferenceEquals(nodoEstructura, elegido) && ReferenceEquals(actual, elegido as ItemPresupuestoDelphin) &&
            (propietario == null || propietario.Id == P?.Id))
        { ActualizarHerramientas(); return; }
        aplicandoSeleccionEstructura = true;
        try
        {
            nodoEstructura = elegido; seleccionVaciaEstructura = nodoEstructura == null;
            activarPresupuestoEstructura?.Invoke(propietario?.Id);
            actual = nodoEstructura as ItemPresupuestoDelphin;
            if (actual != null) seleccionar(actual.Id);
            if (forzar || insumos.Tag != P)
            { CargarInsumosEstructura(); insumos.Tag = P; }
            CargarDetalle(); ActualizarHerramientas();
        }
        finally { aplicandoSeleccionEstructura = false; }
    }

    private void CargarInsumosEstructura()
    {
        insumos.Rows.Clear();
        if (P == null) return;
        foreach (var i in P.Costos.Insumos.OrderBy(x => x.Grupo).ThenBy(x => x.Codigo))
            insumos.Rows[insumos.Rows.Add(MYGMotorPresupuestos.Grupo(i.Grupo), i.Codigo, i.Descripcion, i.Unidad, i.Precio)].Tag = i;
    }

    internal void SeleccionarEstructura(object nodo, bool editarNombre = false)
    {
        FinalizarEdicion(); nodoEstructura = nodo; seleccionVaciaEstructura = nodo == null;
        actual = nodo as ItemPresupuestoDelphin;
        var propietario = PropietarioEstructura(nodo);
        if (propietario != null)
        {
            activarPresupuestoEstructura?.Invoke(propietario.Id); contraidos.Remove(IdNodoEstructura(propietario));
            if (nodo is ItemPresupuestoDelphin i)
            {
                var visitados = new HashSet<string>(); string padre = i.ParentId;
                while (!string.IsNullOrWhiteSpace(padre) && visitados.Add(padre))
                {
                    contraidos.Remove("I:" + padre); padre = propietario.Items.FirstOrDefault(x => x.Id == padre)?.ParentId;
                }
            }
        }
        cargando = true; buscar.Clear(); cargando = false;
        Refrescar(); vistas.SelectedIndex = 0; estructura.Focus();
        if (editarNombre && estructura.CurrentRow != null)
        {
            estructura.CurrentCell = estructura.CurrentRow.Cells["DESC"];
            estructura.BeginEdit(true);
        }
    }

    private void RefrescarEstructura()
    {
        if (IsDisposed || validandoEstructura) return;
        CerrarSelectorUnidadEstructura();
        var presupuestos = PresupuestosEstructura.OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        if (actual != null && (nodoEstructura is not ItemPresupuestoDelphin anterior || anterior.Id != actual.Id)) nodoEstructura = actual;
        if (!seleccionVaciaEstructura && P != null && PropietarioEstructura(nodoEstructura)?.Id != P.Id) nodoEstructura = P;
        string seleccionado = IdNodoEstructura(nodoEstructura ?? (seleccionVaciaEstructura ? null : P));
        string primeroVisible = estructura.FirstDisplayedScrollingRowIndex >= 0 ? IdNodoEstructura(estructura.Rows[estructura.FirstDisplayedScrollingRowIndex].Tag) : null;
        string columnaActiva = estructura.CurrentCell?.OwningColumn.Name;
        int desplazamientoHorizontal = estructura.HorizontalScrollingOffset;
        bool cargandoAntes = cargando;
        var ajusteFilas = estructura.AutoSizeRowsMode;
        cargando = true; estructura.SuspendLayout();
        estructura.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        try
        {
            estructura.Rows.Clear(); propietariosEstructura.Clear(); nivelesEstructura.Clear(); expandiblesEstructura.Clear(); string filtro = buscar.Text.Trim();
            foreach (var presupuesto in presupuestos)
            {
                var porId = presupuesto.Items.ToDictionary(i => i.Id);
                var hijos = presupuesto.Items.ToLookup(i => i.ParentId ?? "");
                foreach (var grupo in hijos.Where(g => g.Key.Length > 0)) expandiblesEstructura.Add("I:" + grupo.Key);
                bool presupuestoCoincide = (presupuesto.Item + " " + presupuesto.Nombre).Contains(filtro, StringComparison.OrdinalIgnoreCase);
                var visibles = new HashSet<string>();
                if (filtro.Length > 0 && !presupuestoCoincide)
                    foreach (var i in presupuesto.Items.Where(x => (CodigoEstructura(presupuesto, x) + " " + x.Descripcion + " " + x.Unidad).Contains(filtro, StringComparison.OrdinalIgnoreCase)))
                    {
                        visibles.Add(i.Id); string padre = i.ParentId; var visitados = new HashSet<string>();
                        while (!string.IsNullOrWhiteSpace(padre) && visitados.Add(padre)) { visibles.Add(padre); padre = porId.GetValueOrDefault(padre)?.ParentId; }
                    }
                if (filtro.Length > 0 && !presupuestoCoincide && visibles.Count == 0) continue;
                string raizId = IdNodoEstructura(presupuesto);
                if (presupuesto.Items.Count > 0) expandiblesEstructura.Add(raizId);
                var raiz = estructura.Rows[estructura.Rows.Add(null, presupuesto.Item, presupuesto.Nombre, null, null, null, null)];
                raiz.Tag = presupuesto; propietariosEstructura[raiz] = presupuesto;
                nivelesEstructura[raiz] = 0; raiz.Cells["ITEM"].Style.Padding = new(SangriaEstructura(raiz) + (int)(20 * DeviceDpi / 96F), 4, 3, 4);
                raiz.Cells["CANT"].ReadOnly = raiz.Cells["UND"].ReadOnly = true;
                raiz.DefaultCellStyle.Font = negrita; raiz.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.ColorTitulo(0);
                if (contraidos.Contains(raizId) && filtro.Length == 0) continue;
                var visitadosItems = new HashSet<string>();
                void Agregar(string padre, int nivel)
                {
                    foreach (var i in hijos[padre ?? ""].OrderBy(x => x.Posicion).ThenBy(x => x.Item))
                    {
                        if (!visitadosItems.Add(i.Id) || filtro.Length > 0 && !presupuestoCoincide && !visibles.Contains(i.Id)) continue;
                        bool titulo = MYGProyectoStorage.EsTitulo(i);
                        string id = IdNodoEstructura(i);
                        var fila = estructura.Rows[estructura.Rows.Add(null, CodigoEstructura(presupuesto, i), i.Descripcion, null, null, null, null)];
                        fila.Tag = i; propietariosEstructura[fila] = presupuesto; nivelesEstructura[fila] = nivel;
                        fila.Cells["ITEM"].Style.Padding = new(SangriaEstructura(fila) + (int)(20 * DeviceDpi / 96F), 4, 3, 4);
                        fila.Cells["DESC"].Style.Padding = new((int)((nivel * 6 + 4) * DeviceDpi / 96F), 4, 4, 4);
                        if (titulo) { fila.DefaultCellStyle.Font = negrita; fila.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.ColorTitulo(nivel); }
                        bool oficial = !string.IsNullOrWhiteSpace(i.IdInternoDelphin);
                        fila.Cells["DESC"].ReadOnly = fila.Cells["ITEM"].ReadOnly = oficial;
                        fila.Cells["CANT"].ReadOnly = titulo; fila.Cells["UND"].ReadOnly = titulo || oficial;
                        if (!titulo) fila.Cells["UND"].Value = i.Unidad;
                        if (!titulo && !oficial) fila.Cells["UND"].Style.Padding = new(4, 4, (int)Math.Round(21 * DeviceDpi / 96F), 4);
                        fila.Cells["CANT"].ToolTipText = titulo ? "" : "Origen actual: " + i.Costos.FuenteMetrado + ". Al editar se usará cantidad directa; los metrados BIM, manuales y de Excel se conservan. Máximo dos decimales.";
                        fila.Cells["UND"].ToolTipText = titulo ? "" : oficial ? "Unidad oficial de Delphin." : "Seleccione la unidad de medida de la partida (F4 o Alt + flecha abajo).";
                        if (filtro.Length > 0 || !contraidos.Contains(id)) Agregar(i.Id, nivel + 1);
                    }
                }
                Agregar(null, 1);
            }
            estructura.ClearSelection(); estructura.CurrentCell = null;
            var elegida = estructura.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => IdNodoEstructura(r.Tag) == seleccionado && propietariosEstructura.GetValueOrDefault(r)?.Id == P?.Id);
            if (elegida == null && !seleccionVaciaEstructura) elegida = estructura.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is MYGPresupuestoDocumento p && p.Id == P?.Id);
            if (elegida == null && !seleccionVaciaEstructura) elegida = estructura.Rows.Cast<DataGridViewRow>().FirstOrDefault();
            if (elegida != null)
            {
                estructura.CurrentCell = elegida.Cells[columnaActiva != null && estructura.Columns.Contains(columnaActiva) && estructura.Columns[columnaActiva].Visible ? columnaActiva : "DESC"];
                elegida.Selected = true;
            }
            var visible = estructura.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => IdNodoEstructura(r.Tag) == primeroVisible);
            if (visible != null) estructura.FirstDisplayedScrollingRowIndex = visible.Index;
            if (estructura.Rows.Count > 0)
                estructura.Columns["ITEM"].Width = Math.Max(105, Math.Min(300, estructura.Rows.Cast<DataGridViewRow>().Max(r =>
                    TextRenderer.MeasureText(Convert.ToString(r.Cells["ITEM"].Value), r.DefaultCellStyle.Font ?? estructura.Font).Width + r.Cells["ITEM"].Style.Padding.Horizontal + 8)));
        }
        finally
        {
            estructura.AutoSizeRowsMode = ajusteFilas;
            var visible = estructura.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => IdNodoEstructura(r.Tag) == primeroVisible);
            if (visible != null) estructura.FirstDisplayedScrollingRowIndex = visible.Index;
            estructura.HorizontalScrollingOffset = desplazamientoHorizontal;
            estructura.ResumeLayout(); cargando = cargandoAntes;
        }
        AplicarSeleccionEstructura(forzar: true);
    }

    private void AplicarTemaEstructura()
    {
        foreach (DataGridViewRow fila in estructura.Rows)
            fila.DefaultCellStyle.ForeColor = fila.Tag is MYGPresupuestoDocumento
                ? MYG2027_TemaComercial.ColorTitulo(0)
                : fila.Tag is ItemPresupuestoDelphin item && MYGProyectoStorage.EsTitulo(item)
                    ? MYG2027_TemaComercial.ColorTitulo(nivelesEstructura.GetValueOrDefault(fila))
                    : MYG2027_TemaComercial.Texto;
    }
}


