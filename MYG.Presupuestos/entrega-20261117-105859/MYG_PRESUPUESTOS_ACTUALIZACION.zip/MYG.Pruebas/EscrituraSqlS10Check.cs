using System.Globalization;
using MYG_2027;

internal static class EscrituraSqlS10Check
{
    internal static void Ejecutar(Action<string> pasa)
    {
        PerfilYObligatorias();
        pasa("SQL S10 usa columnas reales y su nulabilidad, identidad y valores predeterminados, sin inventar datos obligatorios");
        TextoEInyeccion();
        pasa("SQL S10 escapa texto y variables tipadas, exige identificadores del perfil y valida Windows1252 y UTF16 sin sustitución ni truncado");
        NumerosYFechas();
        pasa("SQL S10 conserva precisión y escala, rechaza conversiones numéricas con pérdida y emite fechas y GUID compatibles con SQL Server2005");
    }

    private static void PerfilYObligatorias()
    {
        var unidad = MYGSqlS10.Tabla("Unidad");
        Exige(unidad.NombreSql == "[dbo].[Unidad]" && !unidad.Columna("CodUnidad").PermiteNull
            && unidad.Columna("Descripcion").PermiteNull && unidad.Columna("CodUnidad").Longitud == 3,
            "El perfil debe respetar status&1 como NOT NULL y conservar la longitud nativa de códigos.");
        Exige(MYGSqlS10.Tabla("Presupuesto").Columna("Fecha").PermiteNull,
            "Las columnas status0 deben admitir NULL; no deben llenarse con fechas o ceros arbitrarios.");
        string insert = MYGSqlS10.Insertar("Unidad", new Dictionary<string, object> { ["CodUnidad"] = "001" });
        Exige(insert == "INSERT INTO [dbo].[Unidad] ([CodUnidad]) VALUES (N'001');",
            "Omitir columnas opcionales/predeterminadas debe producir un INSERT mínimo sobre tablas nativas.");
        Rechaza(() => MYGSqlS10.Insertar("Unidad", new Dictionary<string, object> { ["Descripcion"] = "Metros" }), "CodUnidad");
        Rechaza(() => MYGSqlS10.Insertar("Unidad", new Dictionary<string, object> { ["CodUnidad"] = null }), "NULL");
        Exige(MYGSqlS10.Literal("Unidad", "Descripcion", null) == "NULL", "Una columna nullable debe admitir NULL explícito.");
        var insumo = MYGSqlS10.Tabla("Insumo");
        Exige(insumo.Columna("OID").Identidad, "OID debe reconocerse como identidad nativa.");
        Rechaza(() => MYGSqlS10.Insertar("Insumo", new Dictionary<string, object>
        { ["CodInsumo"] = "MAT00001", ["Nivel"] = 1, ["Descripcion"] = "Material", ["OID"] = 2 }), "generada");
        var partida = MYGSqlS10.Tabla("Partida");
        Exige(partida.Columna("CodPresupuesto").TienePredeterminado && !partida.Columna("CodPresupuesto").PermiteNull,
            "El perfil debe distinguir el valor predeterminado de la nulabilidad sin copiar el ID privado de su restricción.");
        string conDefecto = MYGSqlS10.Insertar("Partida", new Dictionary<string, object>
        { ["CodPartida"] = "P00001", ["Nivel"] = 1, ["Descripcion"] = "Partida" });
        Exige(!conDefecto.Contains("[CodPresupuesto]", StringComparison.Ordinal),
            "Un valor predeterminado conocido sólo por su existencia debe omitirse, no inventarse ni sustituirse por NULL.");
    }

    private static void TextoEInyeccion()
    {
        string dato = "O'Brien'); DELETE FROM Usuario;--\nNiño áéíóú µ²";
        string literal = MYGSqlS10.Literal("Unidad", "Descripcion", dato);
        Exige(literal == "N'" + dato.Replace("'", "''") + "'", "Las comillas de datos deben duplicarse incluso con saltos de línea.");
        string insert = MYGSqlS10.Insertar("Unidad", new Dictionary<string, object>
        { ["Descripcion"] = dato, ["CodUnidad"] = "001" });
        Exige(ContarSentencias(insert) == 1, "Un valor con SQL aparente debe seguir dentro de un único INSERT.");
        Exige(MYGSqlS10.Literal("Unidad", "Descripcion", new string('ñ', 50)).Length > 50,
            "Windows1252 debe medir bytes del destino, no los dos bytes UTF8 de cada letra española.");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", new string('a', 51)), "truncar");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", "Obra 😀"));
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", "Obra\0oculta"), "nulo");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", "e\u0301"));
        Exige(MYGSqlS10.Literal("Insumo", "RR", "😀") == "N'😀'",
            "NVARCHAR debe contar unidades UTF16 válidas; un par sustituto completo ocupa cuatro bytes.");
        Rechaza(() => MYGSqlS10.Literal("Insumo", "RR", "😀X"), "truncar");
        Rechaza(() => MYGSqlS10.Literal("Insumo", "RR", "\ud800"));
        Rechaza(() => MYGSqlS10.Tabla("Unidad]; DELETE FROM Usuario;--"));
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion]", "texto"));
        Rechaza(() => MYGSqlS10.Insertar("Unidad", new Dictionary<string, object>
        { ["CodUnidad"] = "001", ["codunidad"] = "002" }), "duplicada");

        var variable = new MYGVariableSqlS10("@Unidad0001");
        Exige(MYGSqlS10.Literal("Unidad", "CodUnidad", variable) == "@Unidad0001"
            && MYGSqlS10.Literal("Unidad", "CodUnidad", "@U") == "N'@U'",
            "Sólo una referencia tipada del generador puede convertirse en variable; el texto del usuario sigue siendo un literal.");
        Rechaza(() => new MYGVariableSqlS10("@U; DROP TABLE Unidad"));
        Rechaza(() => new MYGVariableSqlS10("@@VERSION"));
        Rechaza(() => new MYGVariableSqlS10("U"));
    }

    private static void NumerosYFechas()
    {
        var anterior = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = new CultureInfo("es-PE");
            Exige(MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", -1234.125m) == "-1234.125",
                "Un decimal debe conservar el punto invariante y no tener separadores de miles.");
            Exige(MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", 1.23000000000000m) == "1.23",
                "Eliminar ceros finales es exacto; no debe rechazarse un valor equivalente con escala interna mayor.");
            Rechaza(() => MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", .00000000000001m), "redondear");
            Rechaza(() => MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", 10000000000000000m), "supera");
            Rechaza(() => MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", 1.2d), "exacto");
            Exige(MYGSqlS10.Literal("Presupuesto", "Nivel", short.MaxValue) == "32767", "Un smallint límite debe conservarse.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Nivel", 32768), "entero");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Nivel", 1.5m), "entero");
            Exige(MYGSqlS10.Literal("Unidad", "TieneNota", true) == "1", "El bit debe emitirse como valor numérico SQL.");
            Rechaza(() => MYGSqlS10.Literal("Unidad", "TieneNota", 2));
            Exige(MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .5m) == "CONVERT(real,N'0.5')",
                "Un decimal binario exacto puede representarse en real sin pérdida.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .1m), "exacta");
            Exige(MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .1f).StartsWith("CONVERT(real,"),
                "Un float ya elegido explícitamente puede conservarse como aproximado nativo.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", double.NaN));
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", double.PositiveInfinity));
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .1d), "precisión");

            Exige(MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(2024, 2, 29)) == "CONVERT(datetime,N'20240229',112)",
                "La fecha debe usar formato112 independiente del idioma del servidor SQL2005.");
            Exige(MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(2024, 2, 29, 14, 3, 0, 123)) ==
                "CONVERT(datetime,N'2024-02-29T14:03:00.123',126)", "Una fecha con hora debe usar formato126 canónico.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(1600, 1, 1)));
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(2024, 1, 1).AddTicks(1)), "precisión");
            Guid id = Guid.Parse("ee2d90b7-232f-471e-b9ce-ceb9629b8cd4");
            Exige(MYGSqlS10.Literal("Partida", "NroPartida", id) == "CONVERT(uniqueidentifier,N'ee2d90b7-232f-471e-b9ce-ceb9629b8cd4')",
                "Los GUID deben emitirse con tipoSQL sin concatenar contenido arbitrario.");
            Rechaza(() => MYGSqlS10.Literal("Partida", "NroPartida", "x'); DROP TABLE Partida;--"));
        }
        finally { CultureInfo.CurrentCulture = anterior; }
    }

    private static int ContarSentencias(string sql)
    {
        bool cadena = false; int cantidad = 0;
        for (int i = 0; i < sql.Length; i++)
            if (sql[i] == '\'')
            {
                if (cadena && i + 1 < sql.Length && sql[i + 1] == '\'') i++;
                else cadena = !cadena;
            }
            else if (sql[i] == ';' && !cadena) cantidad++;
        Exige(!cadena, "Las cadenas SQL deben terminar dentro de sus propios límites.");
        return cantidad;
    }

    private static void Rechaza(Action accion, string detalle = null)
    {
        try { accion(); }
        catch (InvalidDataException ex)
        {
            Exige(detalle == null || ex.Message.Contains(detalle, StringComparison.OrdinalIgnoreCase),
                "El error debe explicar el dato incompatible: " + detalle + ". Error real: " + ex.Message);
            return;
        }
        throw new Exception("El emisor SQL debió rechazar un dato incompatible.");
    }

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
}
