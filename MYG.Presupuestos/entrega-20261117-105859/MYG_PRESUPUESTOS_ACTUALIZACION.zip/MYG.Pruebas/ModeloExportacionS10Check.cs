using System.Collections;
using System.Text.Json;
using MYG_2027;

internal static class ModeloExportacionS10Check
{
    internal static void Ejecutar(Action<string> pasa)
    {
        FuentesMetradoYAlcance();
        pasa("Modelo S10 resuelve cantidad directa, metrado manual, BIM y Excel vinculado sin cambiar el proyecto y respeta el alcance");
        AnalisisYSubpartidas();
        pasa("Modelo S10 conserva coeficientes efectivos, IGV, desperdicio, porcentajes de mano de obra y subanálisis, con catálogo sólo usado");
        PrecisionImportada();
        pasa("Modelo S10 informa diferencias importadas entre análisis, precio y parcial sin ocultar redondeos");
        ErroresYJerarquia();
        pasa("Modelo S10 rechaza fórmulas, ciclos, jerarquías o alcances inválidos con contexto y sin modificar el documento");
    }

    private static void FuentesMetradoYAlcance()
    {
        var d = MYGProyectoStorage.Nuevo("Prueba de destino S10", "ESTRUCTURAS");
        var p = d.Presupuestos.Single();
        var titulo = Nodo(p, "01", "Título", titulo: true);
        var directa = Nodo(p, "01.01", "Metrado directo", titulo.Id); directa.Costos.Cantidad = 2.34567m;
        directa.ParentId = titulo.Id.ToLowerInvariant();
        var manual = Nodo(p, "01.02", "Metrado manual", titulo.Id);
        manual.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        manual.Costos.Metrados.Add(new() { Elementos = 2, CantidadPorElemento = 3, Largo = 4 });
        manual.Costos.Metrados.Add(new() { Elementos = 1, CantidadPorElemento = 2, Descuento = true });
        var bim = Nodo(p, "01.03", "Metrado BIM", titulo.Id); bim.Costos.FuenteMetrado = MYGFuenteMetrado.BIM;
        bim.Costos.MetradosBIM.Add(new() { ActivoId = "ACTIVO-1", Unidad = "und", Cantidad = 7 });
        bim.Costos.MetradosBIM.Add(new() { ActivoId = "ACTIVO-2", Unidad = "und", Cantidad = 99, ExcluirDelTotal = true });
        var excel = Nodo(p, "01.04", "Metrado vinculado", titulo.Id); excel.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        var origen = new MYGPresupuestoDocumento { Nombre = "ORIGEN", Item = "02", Posicion = 2 };
        d.Presupuestos.Add(origen);
        var partidaOrigen = Nodo(origen, "01", "Celda origen");
        partidaOrigen.Costos.Hoja.Poner("G16", "12.5");
        MYGReferenciasMetrado.Vincular(d.Presupuestos);
        excel.Costos.Hoja.Poner("G16", "=" + MYGReferenciasMetrado.CrearReferencia(excel.Costos.Hoja, origen, partidaOrigen, "G16") + "*2");
        string antes = JsonSerializer.Serialize(d);
        var modelo = MYGPreparacionExportacionS10.Crear(d, p.Id);
        var exportado = modelo.Presupuestos.Single();
        Exige(exportado.Id == p.Id && exportado.Nodos.Select(n => n.Id).SequenceEqual(new[]
            { titulo.Id, directa.Id, manual.Id, bim.Id, excel.Id }), "Debe conservar el árbol en preorden y omitir presupuestos ajenos al alcance.");
        Exige(exportado.Nodos.Where(n => !n.EsTitulo).Select(n => n.Cantidad).SequenceEqual(new[] { 2.3457m, 22m, 7m, 25m }),
            "El metrado debe ser el resultado redondeado del origen real, incluyendo referencias a presupuestos fuera de la selección.");
        Exige(exportado.Nodos.Skip(1).All(n => n.PadreId == titulo.Id) && exportado.Nodos[0].EsTitulo,
            "La jerarquía y el tipo de nodo deben mantenerse independientes de sus códigos visibles.");
        Exige(JsonSerializer.Serialize(d) == antes, "Preparar S10 no debe reparar, renumerar ni recalcular dentro del proyecto abierto.");
        Exige(MYGPreparacionExportacionS10.Crear(d).Presupuestos.Count == 2, "El alcance de proyecto debe incluir todos los presupuestos.");
        bool bloqueado = false;
        try { ((IList)exportado.Nodos).Clear(); } catch (NotSupportedException) { bloqueado = true; }
        Exige(bloqueado, "Las colecciones entregadas al adaptador deben ser de sólo lectura.");
        directa.Costos.Cantidad = 100;
        Exige(exportado.Nodos.Single(n => n.Id == directa.Id).Cantidad == 2.3457m,
            "Editar el proyecto después no debe cambiar la instantánea preparada para exportar.");
    }

    private static void AnalisisYSubpartidas()
    {
        var d = MYGProyectoStorage.Nuevo("Prueba de análisis S10"); var p = d.Presupuestos.Single();
        p.Costos.ConfiguracionCostoDirecto = new() { Nombre = "Costo directo", IncluirIgvMateriales = true };
        var mo = Insumo(p, "MO", MYGGrupoRecurso.ManoObra, "hh", 10);
        var material = Insumo(p, "MAT", MYGGrupoRecurso.Materiales, "und", 5); material.IGVPorcentaje = 18;
        var herramienta = Insumo(p, "HERR", MYGGrupoRecurso.Equipo, "%mo", 1);
        Insumo(p, "NO-USADO", MYGGrupoRecurso.Materiales, "und", -999);
        var raiz = Nodo(p, "01", "Partida compuesta"); raiz.Costos.Cantidad = 2; raiz.Costos.RendimientoDiario = 8;
        var sub = Nodo(p, "02", "Subpartida auxiliar"); sub.Costos.Cantidad = 0; sub.IdLocalMYG = "IDENTIDAD-LOCAL-SUB";
        sub.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 2 });
        raiz.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = mo.Id,
            Modo = MYGModoCantidad.Rendimiento, NumeroRecursos = 2, DesperdicioPorcentaje = 10 });
        raiz.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 3 });
        raiz.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Equipo, InsumoId = herramienta.Id,
            Cantidad = 3, Modo = MYGModoCantidad.PorcentajeManoObra });
        raiz.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = .5m });
        string antes = JsonSerializer.Serialize(d);
        var presupuesto = MYGPreparacionExportacionS10.Crear(d).Presupuestos.Single();
        var nodo = presupuesto.Nodos.Single(n => n.Id == raiz.Id);
        Exige(nodo.Analisis.Select(l => l.Cantidad).SequenceEqual(new[] { 2.2m, 3m, 3m, .5m })
            && nodo.Analisis.Select(l => l.Parcial).SequenceEqual(new[] { 22m, 17.70m, .66m, 5.90m })
            && nodo.PrecioUnitario == 46.26m && nodo.Parcial == 92.52m,
            "El modelo debe trasladar los coeficientes e importes efectivos, incluyendo rendimiento, desperdicio, IGV y base de porcentaje.");
        Exige(nodo.Analisis.Last().SubpartidaId == sub.Id && nodo.Analisis.Last().InsumoId == null
            && nodo.Analisis.Last().Precio == 11.80m,
            "La identidad local del subanálisis debe resolverse a un nodo exportado y conservar su precio calculado.");
        Exige(presupuesto.Insumos.Count == 3 && presupuesto.Insumos.Single(i => i.Id == material.Id).PrecioEfectivo == 5.9m
            && presupuesto.Insumos.All(i => i.Codigo != "NO-USADO") && presupuesto.Resumen.CostoDirecto == 92.52m,
            "La lista de insumos debe omitir catálogos no usados y mantener el precio efectivo y el costo directo.");
        Exige(JsonSerializer.Serialize(d) == antes, "El análisis para S10 no debe modificar las líneas ni firmas del presupuesto.");
        sub.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = raiz.IdLocalMYG });
        var error = Rechaza(() => MYGPreparacionExportacionS10.Crear(d));
        Exige(error.Message.Contains(p.Nombre) && error.Message.Contains("Partida compuesta") && error.Message.Contains("circular"),
            "Los ciclos de subanálisis deben rechazarse con el presupuesto y la partida que los contiene.");
    }

    private static void PrecisionImportada()
    {
        var d = MYGProyectoStorage.Nuevo("Redondeo nativo"); var p = d.Presupuestos.Single();
        var m = Insumo(p, "M", MYGGrupoRecurso.Materiales, "und", 5);
        var i = Nodo(p, "01", "Precio importado"); i.Costos.Cantidad = 2;
        i.Costos.Analisis.Add(new() { InsumoId = m.Id, Cantidad = 3, ParcialImportadoDelphin = 15m });
        i.Costos.PrecioImportadoDelphin = 15.01m; i.Costos.ParcialImportadoDelphin = 30.03m;
        i.Costos.CantidadImportadaDelphin = 2;
        i.Costos.FirmaAnalisisImportadoDelphin = MYGMotorPresupuestos.FirmaAnalisis(p, i);
        string antes = JsonSerializer.Serialize(d);
        var modelo = MYGPreparacionExportacionS10.Crear(d);
        var n = modelo.Presupuestos.Single().Nodos.Single();
        Exige(n.PrecioUnitario == 15.01m && n.Parcial == 30.03m && n.DiferenciaPrecioAnalisis == .01m
            && n.DiferenciaParcial == .01m && modelo.Advertencias.Count == 1,
            "Los precios y parciales nativos deben conservarse con diferencias explícitas para el adaptador, sin cuadrarlos silenciosamente.");
        Exige(JsonSerializer.Serialize(d) == antes, "La exportación debe conservar las firmas y los importes importados del documento.");
    }

    private static void ErroresYJerarquia()
    {
        var d = MYGProyectoStorage.Nuevo("Errores de metrado", "OBRA"); var p = d.Presupuestos.Single();
        var i = Nodo(p, "01", "Metrado inválido"); i.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        i.Costos.Hoja.Poner("G16", "=1/0");
        string antes = JsonSerializer.Serialize(d);
        var error = Rechaza(() => MYGPreparacionExportacionS10.Crear(d));
        Exige(error.Message.Contains("OBRA") && error.Message.Contains("Metrado inválido") && error.Message.Contains("Excel"),
            "Un error de fórmula debe indicar presupuesto, partida y fuente del metrado.");
        Exige(JsonSerializer.Serialize(d) == antes, "Rechazar un metrado inválido no debe cambiar el proyecto.");
        Rechaza(() => MYGPreparacionExportacionS10.Crear(d, "presupuesto-inexistente"));
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad; i.Costos.Hoja.Poner("G16", "0");
        i.ParentId = "padre-inexistente";
        Exige(Rechaza(() => MYGPreparacionExportacionS10.Crear(d)).Message.Contains("padre"),
            "El adaptador no debe aplanar silenciosamente un nodo cuyo padre falta.");
    }

    private static MYGInsumo Insumo(MYGPresupuestoDocumento p, string codigo, MYGGrupoRecurso grupo, string unidad, decimal precio)
    {
        var i = new MYGInsumo { Codigo = codigo, Descripcion = codigo, Grupo = grupo, Unidad = unidad, Precio = precio };
        p.Costos.Insumos.Add(i); return i;
    }

    private static ItemPresupuestoDelphin Nodo(MYGPresupuestoDocumento p, string codigo, string nombre,
        string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        var i = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Item = codigo, Descripcion = nombre,
            ParentId = padre, Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA",
            Posicion = p.Items.Count + 1, Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida { PrecioDirecto = 1 }
        };
        p.Items.Add(i); return i;
    }

    private static InvalidDataException Rechaza(Action accion)
    {
        try { accion(); } catch (InvalidDataException error) { return error; }
        throw new Exception("La preparación S10 debió rechazar los datos inválidos.");
    }

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
}
