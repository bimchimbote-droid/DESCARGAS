using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private Task ExportarS10Async()
    {
        if (P == null) throw new InvalidOperationException("Seleccione un presupuesto para exportar a S10.");
        using var dialogo = new MYGExportarS10Form(documento, P.Id, archivo);
        if (dialogo.ShowDialog(this) == DialogResult.OK && dialogo.RutaExportada != null)
            estado.Text = "Script SQL para S10 exportado: " + dialogo.RutaExportada;
        return Task.CompletedTask;
    }
}
