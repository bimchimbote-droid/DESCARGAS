using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGExportarS10Form : Form
{
    private readonly MYGProyectoDocumento proyecto;
    private readonly string origenSQLite;
    private readonly Func<string, MYGProyectoDocumento, MYGOpcionesExportacionS10, Action<string>, MYGResultadoExportacionS10> exportador;
    private readonly MYGUbicacionS10[] ubicaciones;
    private readonly ComboBox alcance = new() { Name = "s10_exportar_alcance", DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox nombre = new() { Name = "s10_exportar_nombre", MaxLength = 250 };
    private readonly DateTimePicker fecha;
    private readonly TextBox buscarUbicacion = new()
    {
        Name = "s10_exportar_buscar_ubicacion", PlaceholderText = "Escriba un nombre o código para filtrar…"
    };
    private readonly ComboBox ubicacion = new()
    {
        Name = "s10_exportar_ubicacion", DropDownStyle = ComboBoxStyle.DropDownList,
        DropDownWidth = 630, IntegralHeight = false, MaxDropDownItems = 14
    };
    private readonly TextBox usuario = new() { Name = "s10_exportar_usuario", MaxLength = 7 };
    private readonly Label resultado = new()
    {
        Name = "s10_exportar_resultado", Dock = DockStyle.Fill, AutoEllipsis = true,
        AccessibleName = "Resultado de la exportación a S10"
    };
    private readonly TextBox destino = new()
    {
        Name = "s10_exportar_destino", Dock = DockStyle.Fill, ReadOnly = true,
        AccessibleName = "Archivo SQL generado", PlaceholderText = "El archivo .sql se elige al pulsar Exportar."
    };
    private readonly TextBox avisos = new()
    {
        Name = "s10_exportar_avisos", Dock = DockStyle.Fill, Multiline = true,
        ReadOnly = true, ScrollBars = ScrollBars.Vertical, Visible = false,
        AccessibleName = "Avisos de la exportación a S10"
    };
    private readonly Button exportar = new()
    {
        Name = "s10_exportar_exportar", Text = "Exportar…", AutoSize = true, MinimumSize = new Size(110, 32)
    };
    private readonly Button cerrar = new()
    {
        Name = "s10_exportar_cerrar", Text = "Cerrar", AutoSize = true, MinimumSize = new Size(100, 32)
    };
    private string nombrePredeterminado;
    private bool exportando;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal string RutaExportada { get; private set; }

    internal MYGExportarS10Form(MYGProyectoDocumento proyecto, string presupuestoId = null, string origenSQLite = null,
        Func<string, MYGProyectoDocumento, MYGOpcionesExportacionS10, Action<string>, MYGResultadoExportacionS10> exportador = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        // Capturar en el hilo del editor antes de iniciar cualquier tarea de escritura.
        this.proyecto = MYGProyectoStorage.Copia(proyecto);
        this.origenSQLite = origenSQLite;
        this.exportador = exportador ?? MYGExportacionS10Sql.Guardar;
        ubicaciones = MYGExportacionS10Sql.Ubicaciones.ToArray();
        fecha = MYGCronogramaDialogoUI.Fecha("s10_exportar_fecha", this.proyecto.Datos?.FechaElaboracion ?? DateTime.Today);
        fecha.MinDate = new DateTime(1753, 1, 1);
        fecha.MaxDate = new DateTime(9998, 12, 31);
        MYGCronogramaDialogoUI.Preparar(this, "s10_exportar_dialogo", "Exportar a S10 Presupuestos 2005", new Size(820, 650), redimensionable: true);
        MinimumSize = new Size(700, 640);
        MaximizeBox = false;

        var contenido = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 6,
            Padding = new Padding(18, 14, 18, 10)
        };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        foreach (int alto in new[] { 66, 302, 46, 34 }) contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, alto));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        contenido.Controls.Add(new Label
        {
            Name = "s10_exportar_instrucciones", Dock = DockStyle.Fill,
            Text = "Genera SQL para importar en una copia de la base de S10 mediante SQL Server; el respaldo .S2K se crea después desde S10.",
            AccessibleName = "Cómo importar el archivo en S10"
        }, 0, 0);

        var campos = MYGCronogramaDialogoUI.Tabla();
        campos.Dock = DockStyle.Fill;
        campos.Padding = new Padding(0);
        campos.AutoSize = false;
        campos.ColumnStyles[0].Width = 168;
        MYGCronogramaDialogoUI.Campo(campos, "Presupuestos", alcance);
        MYGCronogramaDialogoUI.Campo(campos, "Nombre en S10", nombre);
        MYGCronogramaDialogoUI.Campo(campos, "Fecha de costos", fecha);
        MYGCronogramaDialogoUI.Campo(campos, "Buscar ubicación", buscarUbicacion);
        MYGCronogramaDialogoUI.Campo(campos, "Ubicación de S10", ubicacion);
        MYGCronogramaDialogoUI.Campo(campos, "Código de usuario S10", usuario);
        var ayudaUsuario = new Label
        {
            Name = "s10_exportar_ayuda_usuario", Dock = DockStyle.Fill,
            Text = "Opcional, hasta 7 caracteres. Vacío: se usa el usuario SQL al importar."
        };
        MYGCronogramaDialogoUI.Campo(campos, "", ayudaUsuario, 42);
        contenido.Controls.Add(campos, 0, 1);
        resultado.Text = "Seleccione la ubicación de S10 y revise los datos antes de exportar.";
        contenido.Controls.Add(resultado, 0, 2);
        contenido.Controls.Add(destino, 0, 3);
        contenido.Controls.Add(avisos, 0, 4);
        var botones = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false, Margin = new Padding(0), Padding = new Padding(0, 8, 0, 0)
        };
        botones.Controls.Add(cerrar);
        botones.Controls.Add(exportar);
        contenido.Controls.Add(botones, 0, 5);
        Controls.Add(contenido);

        var activo = this.proyecto.Presupuestos.FirstOrDefault(p => p.Id == (presupuestoId ?? this.proyecto.PresupuestoActivoId));
        if (activo != null) alcance.Items.Add(new Alcance("Presupuesto activo: " + activo.Nombre, activo.Id));
        alcance.Items.Add(new Alcance("Todos los presupuestos del proyecto", null));
        alcance.SelectedIndexChanged += (_, _) => ActualizarNombre();
        alcance.SelectedIndex = 0;
        FiltrarUbicaciones();
        PreseleccionarUbicacion();
        buscarUbicacion.TextChanged += (_, _) => FiltrarUbicaciones();
        exportar.Click += async (_, _) => await ExportarAsync();
        cerrar.Click += (_, _) => Close();
        AcceptButton = exportar;
        CancelButton = cerrar;
        FormClosing += (_, e) =>
        {
            if (exportando) e.Cancel = true;
            else if (RutaExportada != null) DialogResult = DialogResult.OK;
        };
        MYGCronogramaDialogoUI.Tema(this);
    }

    private sealed record Alcance(string Nombre, string PresupuestoId)
    {
        public override string ToString() => Nombre;
    }

    private void ActualizarNombre()
    {
        if (alcance.SelectedItem is not Alcance seleccion) return;
        string nuevo = seleccion.PresupuestoId == null ? proyecto.Nombre
            : proyecto.Presupuestos.First(p => p.Id == seleccion.PresupuestoId).Nombre;
        nuevo = string.IsNullOrWhiteSpace(nuevo) ? "Presupuesto MYG" : nuevo.Trim();
        if (nuevo.Length > nombre.MaxLength) nuevo = nuevo[..nombre.MaxLength];
        if (string.IsNullOrWhiteSpace(nombre.Text) || nombre.Text == nombrePredeterminado) nombre.Text = nuevo;
        nombrePredeterminado = nuevo;
    }

    private void FiltrarUbicaciones()
    {
        string codigo = (ubicacion.SelectedItem as MYGUbicacionS10)?.Codigo;
        string filtro = buscarUbicacion.Text.Trim();
        var coincidencias = ubicaciones.Where(u => filtro.Length == 0 || CultureInfo.InvariantCulture.CompareInfo.IndexOf(
            u.ToString(), filtro, CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0).ToArray();
        ubicacion.BeginUpdate();
        try
        {
            ubicacion.Items.Clear();
            ubicacion.Items.AddRange(coincidencias);
            ubicacion.SelectedIndex = Array.FindIndex(coincidencias, u => u.Codigo == codigo);
        }
        finally { ubicacion.EndUpdate(); }
    }

    private void PreseleccionarUbicacion()
    {
        foreach (string texto in new[] { proyecto.Datos?.Distrito, proyecto.Datos?.Provincia })
        {
            if (string.IsNullOrWhiteSpace(texto)) continue;
            var coincidencias = ubicaciones.Where(u => CultureInfo.InvariantCulture.CompareInfo.Compare(
                u.Nombre?.Trim(), texto.Trim(), CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) == 0).ToArray();
            if (coincidencias.Length != 1) continue;
            ubicacion.SelectedItem = coincidencias[0];
            return;
        }
    }

    private async Task ExportarAsync()
    {
        if (exportando) return;
        try
        {
            if (alcance.SelectedItem is not Alcance seleccion)
                throw new InvalidOperationException("Seleccione los presupuestos que desea exportar.");
            if (string.IsNullOrWhiteSpace(nombre.Text))
            {
                nombre.Focus();
                throw new InvalidOperationException("Indique el nombre del presupuesto de destino en S10.");
            }
            if (ubicacion.SelectedItem is not MYGUbicacionS10 lugar)
            {
                ubicacion.Focus();
                throw new InvalidOperationException("Seleccione una ubicación del catálogo de S10.");
            }
            var opciones = new MYGOpcionesExportacionS10
            {
                PresupuestoId = seleccion.PresupuestoId, Nombre = nombre.Text.Trim(),
                FechaCosto = fecha.Value.Date, CodigoLugar = lugar.Codigo,
                CodigoUsuario = string.IsNullOrWhiteSpace(usuario.Text) ? null : usuario.Text.Trim()
            };
            using var dialogo = new SaveFileDialog
            {
                Title = "Exportar a S10 Presupuestos 2005 · Script SQL", AddExtension = true, DefaultExt = "sql",
                Filter = "Script SQL para S10 Presupuestos 2005 (*.sql)|*.sql", OverwritePrompt = true,
                CheckPathExists = true, RestoreDirectory = true, FileName = NombreArchivo(opciones.Nombre)
            };
            if (dialogo.ShowDialog(this) != DialogResult.OK) return;
            MYGExportacionCronogramaWindows.ValidarDestino(dialogo.FileName, "sql", origenSQLite);
            string ruta = Path.GetFullPath(dialogo.FileName);
            resultado.ForeColor = MYG2027_TemaComercial.Texto;
            resultado.Text = "";
            avisos.Visible = false;
            CambiarOcupado(true);
            var resumen = await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Preparando la exportación a S10…",
                informar => Task.Run(() => exportador(ruta, proyecto, opciones, informar.Report)));
            RutaExportada = ruta;
            destino.Text = ruta;
            resultado.Text = $"Script SQL creado: {resumen.Presupuestos:N0} presupuesto(s), {resumen.Partidas:N0} partida(s) y {resumen.Insumos:N0} insumo(s).";
            avisos.Text = string.Join(Environment.NewLine, resumen.Advertencias);
            avisos.Visible = resumen.Advertencias.Count > 0;
        }
        catch (Exception ex)
        {
            resultado.ForeColor = Color.Firebrick;
            resultado.Text = ex.Message;
        }
        finally { CambiarOcupado(false); }
    }

    private void CambiarOcupado(bool ocupado)
    {
        exportando = ocupado;
        alcance.Enabled = nombre.Enabled = fecha.Enabled = buscarUbicacion.Enabled = ubicacion.Enabled =
            usuario.Enabled = exportar.Enabled = cerrar.Enabled = !ocupado;
        ControlBox = !ocupado;
        UseWaitCursor = ocupado;
    }

    private static string NombreArchivo(string texto)
    {
        char[] invalidos = Path.GetInvalidFileNameChars();
        string limpio = new string((texto ?? "").Select(c => invalidos.Contains(c) ? '_' : c).ToArray()).Trim().TrimEnd('.');
        if (limpio.Length == 0) limpio = "Presupuesto S10";
        if (limpio.Length > 120) limpio = limpio[..120];
        return limpio + ".sql";
    }
}
