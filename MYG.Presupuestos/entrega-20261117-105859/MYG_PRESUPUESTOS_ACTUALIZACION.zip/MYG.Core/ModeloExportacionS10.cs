using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;

namespace MYG_2027;

/// <summary>Datos calculados para el adaptador S10. No representa un archivo
/// S2K ni presupone nombres de tablas de una versión del motor de destino.</summary>
public sealed record MYGModeloExportacionS10(string Nombre,
    IReadOnlyList<MYGPresupuestoExportacionS10> Presupuestos, IReadOnlyList<string> Advertencias);

public sealed record MYGPresupuestoExportacionS10(string Id, string Codigo, string Nombre, string Moneda,
    int DecimalesPrecio, int DecimalesCantidad, IReadOnlyList<MYGNodoExportacionS10> Nodos,
    IReadOnlyList<MYGInsumoExportacionS10> Insumos, MYGResumenExportacionS10 Resumen,
    IReadOnlyList<MYGFilaPieExportacionS10> Pie);

/// <summary>Los identificadores sólo relacionan esta instantánea; el adaptador
/// asigna las claves del destino. El metrado es el resultado, sin vínculos BIM/Excel.</summary>
public sealed record MYGNodoExportacionS10(string Id, string PadreId, string Codigo, string Descripcion,
    string Unidad, bool EsTitulo, int Posicion, decimal Cantidad, decimal PrecioUnitario, decimal Parcial,
    decimal RendimientoDiario, decimal JornadaHoras, IReadOnlyList<MYGLineaAcuExportacionS10> Analisis,
    decimal DiferenciaPrecioAnalisis, decimal DiferenciaParcial)
{
    public bool PrecioDirectoSinAnalisis => !EsTitulo && Analisis.Count == 0;
}

/// <summary>Cantidad, Precio y Parcial son los valores efectivos del motor MYG,
/// incluidos desperdicio, porcentajes e IGV. Los datos de cuadrilla permiten
/// al adaptador decidir cómo representarlos sin recalcular otra regla.</summary>
public sealed record MYGLineaAcuExportacionS10(int Posicion, MYGGrupoRecurso Grupo, string InsumoId,
    string SubpartidaId, string Codigo, string Descripcion, string Unidad, decimal Cantidad,
    decimal Precio, decimal Parcial, decimal NumeroRecursos, decimal DesperdicioPorcentaje,
    MYGModoCantidad Modo, bool CalcularCantidadPorUnidad);

public sealed record MYGInsumoExportacionS10(string Id, string Codigo, string Descripcion, string Unidad,
    MYGGrupoRecurso Grupo, decimal PrecioCatalogo, decimal PrecioEfectivo);

public sealed record MYGResumenExportacionS10(decimal CostoDirecto, decimal GastosGenerales, decimal Utilidad,
    decimal Subtotal, decimal Impuesto, decimal OtrosImpuestos, decimal Total);

public sealed record MYGFilaPieExportacionS10(string Nombre, decimal? Porcentaje, decimal Importe,
    MYGConceptoPie? Concepto);

public static class MYGPreparacionExportacionS10
{
    /// <summary>Un Id selecciona un presupuesto; null selecciona todo el
    /// proyecto. Trabaja sobre una copia, incluso al resolver referencias y
    /// normalizar datos heredados. Nunca cambia el proyecto abierto.</summary>
    public static MYGModeloExportacionS10 Crear(MYGProyectoDocumento proyecto, string presupuestoId = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        if (presupuestoId != null && string.IsNullOrWhiteSpace(presupuestoId))
            throw new ArgumentException("Seleccione un presupuesto válido.", nameof(presupuestoId));
        if (proyecto.Presupuestos == null || proyecto.Presupuestos.Count == 0)
            throw new InvalidDataException("El proyecto no contiene presupuestos para exportar a S10.");
        if (proyecto.Presupuestos.Any(p => p == null))
            throw new InvalidDataException("El proyecto contiene un presupuesto vacío.");

        var copia = MYGProyectoStorage.Copia(proyecto);
        MYGReferenciasMetrado.Vincular(copia.Presupuestos);
        var seleccion = copia.Presupuestos.Where(p => presupuestoId == null || string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase))
            .OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.Ordinal).ToArray();
        if (seleccion.Length == 0)
            throw new InvalidDataException("El presupuesto seleccionado no pertenece al proyecto.");
        if (seleccion.Any(p => string.IsNullOrWhiteSpace(p.Id) || string.IsNullOrWhiteSpace(p.Nombre)) ||
            seleccion.Select(p => p.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() != seleccion.Length)
            throw new InvalidDataException("La selección contiene presupuestos incompletos o duplicados.");

        var advertencias = new List<string>();
        var presupuestos = seleccion.Select(p => Preparar(p, advertencias)).ToArray();
        return new(copia.Nombre ?? "", Lectura(presupuestos), Lectura(advertencias));
    }

    private static MYGPresupuestoExportacionS10 Preparar(MYGPresupuestoDocumento presupuesto, List<string> advertencias)
    {
        // Un catálogo puede contener otros recursos; no son parte de la
        // exportación ni deben impedirla por datos que el análisis no utiliza.
        var referencias = (presupuesto.Items ?? new()).Where(i => i?.Costos?.Analisis != null)
            .SelectMany(i => i.Costos.Analisis).Where(r => r != null && r.Grupo != MYGGrupoRecurso.Subpartidas)
            .Select(r => r.InsumoId).ToHashSet(StringComparer.Ordinal);
        if (presupuesto.Costos?.Insumos != null)
            presupuesto.Costos.Insumos = presupuesto.Costos.Insumos.Where(i => i != null && referencias.Contains(i.Id)).ToList();
        try { MYGProyectoStorage.ValidarPresupuesto(presupuesto); }
        catch (Exception ex) when (ex is InvalidDataException or InvalidOperationException or ArgumentException or ArithmeticException)
        {
            // El validador global también comprueba fórmulas y subanálisis.
            // Localizar una partida fallida da al usuario su origen concreto.
            var comprobacion = MYGMotorPresupuestos.CrearCalculo(presupuesto);
            foreach (var i in presupuesto.Items.Where(i => i != null && !MYGProyectoStorage.EsTitulo(i)))
                try { comprobacion.Cantidad(i); comprobacion.Analizar(i); }
                catch (Exception causa) when (causa is InvalidDataException or InvalidOperationException or ArgumentException or ArithmeticException)
                { throw ErrorPartida(presupuesto, i, causa); }
            throw new InvalidDataException("Presupuesto «" + presupuesto.Nombre + "»: " + ex.Message, ex);
        }

        // El validador acepta las identidades sin distinguir mayúsculas.
        // Usar su escritura canónica evita dejar fuera un hijo válido al
        // construir el árbol y al calcular los subtotales de sus títulos.
        var identidades = presupuesto.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
        foreach (var i in presupuesto.Items)
            if (i.ParentId != null) i.ParentId = identidades[i.ParentId].Id;
        var calculo = MYGMotorPresupuestos.CrearCalculo(presupuesto);
        var nodos = new List<MYGNodoExportacionS10>();
        var usados = new HashSet<string>(StringComparer.Ordinal);
        var hijos = presupuesto.Items.ToLookup(i => i.ParentId ?? "", StringComparer.Ordinal);
        void Agregar(string padre)
        {
            foreach (var i in hijos[padre ?? ""].OrderBy(i => i.Posicion).ThenBy(i => i.Item, StringComparer.Ordinal))
            {
                try
                {
                    bool titulo = MYGProyectoStorage.EsTitulo(i);
                    var acu = titulo ? new MYGResultadoACU() : calculo.Analizar(i);
                    decimal cantidad = titulo ? 0 : calculo.Cantidad(i), parcial = calculo.TotalPartida(i);
                    var lineas = acu.Recursos.Select((valor, indice) =>
                    {
                        var r = valor.Recurso;
                        string subpartida = r.Grupo == MYGGrupoRecurso.Subpartidas
                            ? calculo.Subpartida(r.SubpartidaIdLocal)?.Id : null;
                        string insumo = r.Grupo == MYGGrupoRecurso.Subpartidas ? null : r.InsumoId;
                        if (insumo != null) usados.Add(insumo);
                        return new MYGLineaAcuExportacionS10(indice + 1, r.Grupo, insumo, subpartida,
                            valor.Codigo ?? "", valor.Descripcion ?? "", valor.Unidad ?? "", valor.Cantidad,
                            valor.Precio, valor.Total, r.NumeroRecursos, r.DesperdicioPorcentaje, r.Modo, r.CalcularCantidadPorUnidad);
                    }).ToArray();
                    decimal diferenciaAcu = lineas.Length == 0 ? 0 : acu.PrecioUnitario - lineas.Sum(l => l.Parcial);
                    decimal diferenciaParcial = titulo ? 0 : parcial - MYGMotorPresupuestos.Dinero(presupuesto, cantidad * acu.PrecioUnitario);
                    if (diferenciaAcu != 0 || diferenciaParcial != 0)
                        advertencias.Add("Presupuesto «" + presupuesto.Nombre + "», partida «" + i.Item + " · " + i.Descripcion +
                            "»: conserva diferencias de redondeo importadas (ACU " + diferenciaAcu + ", parcial " + diferenciaParcial + ").");
                    nodos.Add(new(i.Id, i.ParentId, i.Item ?? "", i.Descripcion ?? "", i.Unidad ?? "", titulo,
                        i.Posicion, cantidad, acu.PrecioUnitario, parcial, i.Costos.RendimientoDiario, i.Costos.JornadaHoras,
                        Lectura(lineas), diferenciaAcu, diferenciaParcial));
                    if (titulo) Agregar(i.Id);
                }
                catch (Exception ex) when (ex is InvalidDataException or InvalidOperationException or ArgumentException or ArithmeticException)
                { throw ErrorPartida(presupuesto, i, ex); }
            }
        }
        Agregar(null);
        if (nodos.Count != presupuesto.Items.Count)
            throw new InvalidDataException("La jerarquía del presupuesto «" + presupuesto.Nombre + "» contiene nodos no alcanzables.");
        var insumos = presupuesto.Costos.Insumos.Where(i => usados.Contains(i.Id)).Select(i =>
            new MYGInsumoExportacionS10(i.Id, i.Codigo ?? "", i.Descripcion, i.Unidad, i.Grupo, i.Precio,
                i.Precio * (presupuesto.Costos.ConfiguracionCostoDirecto?.IncluirIgv(i.Grupo) == true ? 1m + i.IGVPorcentaje / 100m : 1m)));
        var resumen = calculo.Resumen();
        var pie = MYGPiePresupuesto.Filas(new[] { calculo }).Select(f => new MYGFilaPieExportacionS10(f.Nombre,
            f.Porcentaje, f.Importe, f.Concepto));
        return new(presupuesto.Id, presupuesto.Item ?? "", presupuesto.Nombre, presupuesto.Costos.Moneda,
            presupuesto.Costos.DecimalesPrecio, presupuesto.Costos.DecimalesCantidad, Lectura(nodos), Lectura(insumos),
            new(resumen.CostoDirecto, resumen.GastosGenerales, resumen.Utilidad, resumen.Subtotal,
                resumen.Impuesto, resumen.OtrosImpuestos, resumen.Total), Lectura(pie));
    }

    private static InvalidDataException ErrorPartida(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i, Exception causa) =>
        new("Presupuesto «" + p.Nombre + "», partida «" + i.Item + " · " + i.Descripcion +
            "», metrado " + i.Costos?.FuenteMetrado + ": " + causa.Message, causa);

    private static ReadOnlyCollection<T> Lectura<T>(IEnumerable<T> valores) => Array.AsReadOnly(valores.ToArray());
}
