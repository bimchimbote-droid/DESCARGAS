using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlTypes;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace MYG_2027;

internal sealed record MYGColumnaSqlS10(string Nombre, string Tipo, int Longitud, int Precision, int Escala,
    bool PermiteNull, bool Identidad, bool Calculada, bool TienePredeterminado)
{
    internal string NombreSql => MYGSqlS10.Identificador(Nombre);
}

/// <summary>Referencia a una variable declarada por el generador del lote.
/// Sus tipos y valores los valida ese generador; nunca se interpreta texto del
/// usuario como una expresión o como una referencia a variable.</summary>
internal sealed record MYGVariableSqlS10
{
    internal string Nombre { get; }
    internal MYGVariableSqlS10(string nombre)
    {
        if (nombre == null || nombre.Length > 128 || !Regex.IsMatch(nombre, @"^@[A-Za-z_][A-Za-z0-9_]*$", RegexOptions.CultureInvariant))
            throw new InvalidDataException("Nombre de variable SQL inválido.");
        Nombre = nombre;
    }
}

internal sealed class MYGTablaSqlS10
{
    internal string Nombre { get; }
    internal string NombreSql => "[dbo]." + MYGSqlS10.Identificador(Nombre);
    internal IReadOnlyList<MYGColumnaSqlS10> Columnas { get; }
    private readonly IReadOnlyDictionary<string, MYGColumnaSqlS10> porNombre;
    internal MYGTablaSqlS10(string nombre, IEnumerable<MYGColumnaSqlS10> columnas)
    {
        MYGSqlS10.Identificador(nombre);
        Nombre = nombre;
        var lista = columnas.ToArray();
        foreach (var columna in lista) MYGSqlS10.Identificador(columna.Nombre);
        Columnas = Array.AsReadOnly(lista);
        porNombre = new ReadOnlyDictionary<string, MYGColumnaSqlS10>(lista.ToDictionary(c => c.Nombre, StringComparer.OrdinalIgnoreCase));
    }
    internal MYGColumnaSqlS10 Columna(string nombre) => nombre != null && porNombre.TryGetValue(nombre, out var c)
        ? c : throw new InvalidDataException("Columna S10 desconocida: " + Nombre + "." + nombre + ".");
}

/// <summary>Emisión de datos SQL Server 2005 según el perfil de columnas
/// extraído de una base S10. No interpreta cadenas de datos como SQL.</summary>
internal static class MYGSqlS10
{
    private static readonly CultureInfo Invariante = CultureInfo.InvariantCulture;
    private static readonly Regex NombreValido = new(@"^[A-Za-z_][A-Za-z0-9_]*$", RegexOptions.CultureInvariant);
    private static readonly Encoding Texto1252 = Crear1252();
    private static readonly Encoding UnicodeEstricto = new UnicodeEncoding(false, false, true);
    private static readonly Lazy<IReadOnlyDictionary<string, MYGTablaSqlS10>> esquema = new(Cargar);

    internal static IReadOnlyDictionary<string, MYGTablaSqlS10> Perfil => esquema.Value;
    internal static MYGTablaSqlS10 Tabla(string nombre) => nombre != null && Perfil.TryGetValue(nombre, out var tabla)
        ? tabla : throw new InvalidDataException("Tabla ajena al perfil S10: " + nombre + ".");

    internal static string Identificador(string nombre)
    {
        if (nombre == null || !NombreValido.IsMatch(nombre))
            throw new InvalidDataException("Identificador SQL inválido.");
        return "[" + nombre + "]";
    }

    internal static string Insertar(string tabla, IReadOnlyDictionary<string, object> valores)
    {
        ArgumentNullException.ThrowIfNull(valores);
        var perfil = Tabla(tabla);
        var entradas = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        foreach (var par in valores)
        {
            var columna = perfil.Columna(par.Key);
            if (columna.Identidad || columna.Calculada)
                throw new InvalidDataException("Debe omitir la columna generada por S10: " + perfil.Nombre + "." + columna.Nombre + ".");
            if (!entradas.TryAdd(columna.Nombre, par.Value))
                throw new InvalidDataException("Columna S10 duplicada: " + perfil.Nombre + "." + columna.Nombre + ".");
        }
        foreach (var columna in perfil.Columnas)
            if (!columna.PermiteNull && !columna.TienePredeterminado && !columna.Identidad && !columna.Calculada
                && !entradas.ContainsKey(columna.Nombre))
                throw new InvalidDataException("Falta la columna obligatoria S10: " + perfil.Nombre + "." + columna.Nombre + ".");
        if (entradas.Count == 0) return "INSERT INTO " + perfil.NombreSql + " DEFAULT VALUES;";
        var seleccion = perfil.Columnas.Where(c => entradas.ContainsKey(c.Nombre)).ToArray();
        return "INSERT INTO " + perfil.NombreSql + " (" + string.Join(",", seleccion.Select(c => c.NombreSql)) + ") VALUES ("
            + string.Join(",", seleccion.Select(c => LiteralValidado(perfil, c, entradas[c.Nombre]))) + ");";
    }

    internal static string Literal(string tabla, string columna, object valor)
    {
        var perfil = Tabla(tabla);
        return LiteralValidado(perfil, perfil.Columna(columna), valor);
    }

    private static string LiteralValidado(MYGTablaSqlS10 tabla, MYGColumnaSqlS10 columna, object valor)
    {
        try
        {
            if (valor is MYGVariableSqlS10 variable) return variable.Nombre;
            if (valor == null || valor is DBNull)
            {
                if (!columna.PermiteNull) throw new InvalidDataException("La columna no admite NULL.");
                return "NULL";
            }
            return columna.Tipo switch
            {
                "varchar" or "char" or "nvarchar" or "nchar" or "text" or "ntext" => Texto(columna, valor),
                "numeric" or "decimal" => Numero(columna, valor),
                "tinyint" => Entero(valor, byte.MinValue, byte.MaxValue),
                "smallint" => Entero(valor, short.MinValue, short.MaxValue),
                "int" => Entero(valor, int.MinValue, int.MaxValue),
                "bigint" => Entero(valor, long.MinValue, long.MaxValue),
                "bit" => valor is bool booleano ? booleano ? "1" : "0" : Entero(valor, 0, 1),
                "float" or "real" => Flotante(columna, valor),
                "datetime" => Fecha(valor),
                "uniqueidentifier" => Identidad(valor),
                "binary" or "varbinary" or "image" => Binario(columna, valor),
                _ => throw new InvalidDataException("Tipo SQL no admitido: " + columna.Tipo + ".")
            };
        }
        catch (Exception ex) when (ex is InvalidDataException or EncoderFallbackException or SqlTypeException or ArgumentException or ArithmeticException)
        { throw new InvalidDataException("S10 " + tabla.Nombre + "." + columna.Nombre + ": " + ex.Message, ex); }
    }

    private static string Texto(MYGColumnaSqlS10 columna, object valor)
    {
        string texto = valor switch { string s => s, char c => c.ToString(), _ => throw new InvalidDataException("Se esperaba texto.") };
        if (texto.Contains('\0')) throw new InvalidDataException("El texto contiene un carácter nulo.");
        bool unicode = columna.Tipo is "nvarchar" or "nchar" or "ntext";
        int bytes = (unicode ? UnicodeEstricto : Texto1252).GetByteCount(texto);
        if (columna.Tipo is not ("text" or "ntext") && columna.Longitud >= 0 && bytes > columna.Longitud)
            throw new InvalidDataException("El texto ocupa " + bytes + " bytes y la columna admite " + columna.Longitud + ". No se truncará.");
        return "N'" + texto.Replace("'", "''", StringComparison.Ordinal) + "'";
    }

    private static decimal DecimalExacto(object valor) => valor switch
    {
        decimal n => n, byte n => n, sbyte n => n, short n => n, ushort n => n,
        int n => n, uint n => n, long n => n, ulong n => n,
        _ => throw new InvalidDataException("Se esperaba un número decimal o entero exacto.")
    };

    private static string Numero(MYGColumnaSqlS10 columna, object valor)
    {
        decimal numero = DecimalExacto(valor);
        if (columna.Precision < 1 || columna.Precision > 38 || columna.Escala < 0 || columna.Escala > columna.Precision)
            throw new InvalidDataException("Precisión o escala inválida en el perfil S10.");
        int[] bits = decimal.GetBits(numero);
        var magnitud = new BigInteger((uint)bits[0]) + (new BigInteger((uint)bits[1]) << 32) + (new BigInteger((uint)bits[2]) << 64);
        int escala = (bits[3] >> 16) & 255;
        if (escala > columna.Escala)
        {
            var divisor = BigInteger.Pow(10, escala - columna.Escala);
            if (magnitud % divisor != 0) throw new InvalidDataException("El valor exige más de " + columna.Escala + " decimales. No se redondeará.");
            magnitud /= divisor;
        }
        else magnitud *= BigInteger.Pow(10, columna.Escala - escala);
        if (magnitud >= BigInteger.Pow(10, columna.Precision))
            throw new InvalidDataException("El valor supera numeric(" + columna.Precision + "," + columna.Escala + ").");
        return numero.ToString("0.############################", Invariante);
    }

    private static string Entero(object valor, decimal minimo, decimal maximo)
    {
        decimal numero = DecimalExacto(valor);
        if (numero != decimal.Truncate(numero) || numero < minimo || numero > maximo)
            throw new InvalidDataException("El valor no cabe exactamente en el tipo entero de destino.");
        return numero.ToString("0", Invariante);
    }

    private static string Flotante(MYGColumnaSqlS10 columna, object valor)
    {
        bool simple = columna.Tipo == "real" || columna.Precision is > 0 and <= 24;
        double numero;
        if (valor is double doble) numero = doble;
        else if (valor is float real) numero = real;
        else
        {
            decimal exacto = DecimalExacto(valor);
            numero = simple ? (double)(float)exacto : (double)exacto;
            if (!IgualBinario(exacto, numero))
                throw new InvalidDataException("El decimal no tiene representación binaria exacta en " + columna.Tipo + ".");
        }
        if (!double.IsFinite(numero)) throw new InvalidDataException("SQL Server no admite NaN ni infinito.");
        if (simple && (!float.IsFinite((float)numero) || (double)(float)numero != numero))
            throw new InvalidDataException("El valor perdería precisión en real.");
        string texto = simple ? ((float)numero).ToString("R", Invariante) : numero.ToString("R", Invariante);
        return "CONVERT(" + (simple ? "real" : "float") + ",N'" + texto + "')";
    }

    private static bool IgualBinario(decimal numero, double aproximado)
    {
        if (!double.IsFinite(aproximado)) return false;
        long binario = BitConverter.DoubleToInt64Bits(aproximado);
        int exponente = (int)((binario >> 52) & 2047);
        var mantisa = new BigInteger((ulong)binario & 0x000fffffffffffffUL);
        if (exponente != 0) mantisa += BigInteger.One << 52;
        int potencia = exponente == 0 ? -1074 : exponente - 1075;
        int[] bits = decimal.GetBits(numero);
        var decimalMantisa = new BigInteger((uint)bits[0]) + (new BigInteger((uint)bits[1]) << 32) + (new BigInteger((uint)bits[2]) << 64);
        int escala = (bits[3] >> 16) & 255;
        if ((bits[3] < 0) != (binario < 0) && decimalMantisa != 0) return false;
        var decimalDenominador = BigInteger.Pow(10, escala);
        return potencia >= 0 ? decimalMantisa == (mantisa << potencia) * decimalDenominador
            : (decimalMantisa << -potencia) == mantisa * decimalDenominador;
    }

    private static string Fecha(object valor)
    {
        if (valor is not DateTime fecha) throw new InvalidDataException("Se esperaba DateTime, sin conversión de zona horaria.");
        if (new SqlDateTime(fecha).Value != fecha)
            throw new InvalidDataException("La fecha perdería precisión al convertirse a datetime de SQL Server.");
        return fecha.TimeOfDay == TimeSpan.Zero ? "CONVERT(datetime,N'" + fecha.ToString("yyyyMMdd", Invariante) + "',112)"
            : "CONVERT(datetime,N'" + fecha.ToString("yyyy-MM-dd'T'HH:mm:ss.fff", Invariante) + "',126)";
    }

    private static string Identidad(object valor)
    {
        Guid id;
        if (valor is Guid guid) id = guid;
        else if (valor is not string texto || !Guid.TryParseExact(texto, "D", out id))
            throw new InvalidDataException("Se esperaba un GUID válido.");
        return "CONVERT(uniqueidentifier,N'" + id.ToString("D") + "')";
    }

    private static string Binario(MYGColumnaSqlS10 columna, object valor)
    {
        if (valor is not byte[] bytes) throw new InvalidDataException("Se esperaba un arreglo de bytes.");
        if (columna.Tipo != "image" && columna.Longitud >= 0 && bytes.Length > columna.Longitud)
            throw new InvalidDataException("El binario supera la longitud de la columna.");
        return "0x" + Convert.ToHexString(bytes);
    }

    private static Encoding Crear1252()
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        return Encoding.GetEncoding(1252, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback);
    }

    private static IReadOnlyDictionary<string, MYGTablaSqlS10> Cargar()
    {
        var ensamblado = typeof(MYGSqlS10).Assembly;
        string recurso = ensamblado.GetManifestResourceNames().SingleOrDefault(n => n.EndsWith("S10Costos2005.Esquema.json", StringComparison.Ordinal));
        if (recurso == null) throw new InvalidOperationException("Falta el perfil de esquema de S10 Costos 2005.");
        using var stream = ensamblado.GetManifestResourceStream(recurso);
        using var json = JsonDocument.Parse(stream);
        var tablas = new Dictionary<string, MYGTablaSqlS10>(StringComparer.OrdinalIgnoreCase);
        foreach (var tabla in json.RootElement.EnumerateArray())
        {
            var columnas = tabla.GetProperty("columns").EnumerateArray().Select(c => new MYGColumnaSqlS10(
                c.GetProperty("name").GetString(), c.GetProperty("type").GetString(), c.GetProperty("length").GetInt32(),
                c.GetProperty("precision").GetInt32(), c.GetProperty("scale").GetInt32(), c.GetProperty("nullable").GetBoolean(),
                c.GetProperty("identity").GetBoolean(), c.GetProperty("computed").GetBoolean(), c.GetProperty("hasDefault").GetBoolean()));
            var perfil = new MYGTablaSqlS10(tabla.GetProperty("name").GetString(), columnas);
            tablas.Add(perfil.Nombre, perfil);
        }
        return new ReadOnlyDictionary<string, MYGTablaSqlS10>(tablas);
    }
}
