using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

// Las cuatro vistas y sus transiciones se dibujan con controles administrados;
// no dependen de capturar ni repintar la ventana nativa SysMonthCal32.
internal sealed class MYGCalendarioFechaPopup : ToolStripDropDown
{
    private readonly DateTimePicker fecha;
    private readonly ContenidoCalendario contenido;
    private readonly TableLayoutPanel tabla, tablaDias, tablaPeriodos;
    private readonly Panel cuerpo;
    private readonly BotonCalendario mes;
    private readonly Label[] semanas = new Label[7];
    private readonly BotonCalendario anterior, siguiente, hoy;
    private readonly BotonCalendario[] dias = new BotonCalendario[42];
    private readonly BotonCalendario[] periodos = new BotonCalendario[12];
    private readonly TransicionCalendario transicion;
    private readonly ToolStripControlHost alojamiento;
    private Font fuentePropia;
    private CultureInfo cultura;
    private DateTime activa, mostrada, minimo, maximo;
    private MYGVistaCalendarioFecha vista;
    private bool confirmada;

    internal event Action<DateTime> FechaElegida;

    internal MYGCalendarioFechaPopup(DateTimePicker fecha)
    {
        this.fecha = fecha ?? throw new ArgumentNullException(nameof(fecha));
        Name = "calendarioFechaPopup";
        AccessibleName = "Seleccionar fecha";
        AutoSize = false; AutoClose = true; DropShadowEnabled = true;
        Margin = System.Windows.Forms.Padding.Empty;
        contenido = new ContenidoCalendario(this)
        {
            Name = "calendarioFechaContenido", AutoScaleMode = AutoScaleMode.None,
            Margin = System.Windows.Forms.Padding.Empty, TabStop = true
        };
        tabla = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 7, RowCount = 3,
            Margin = System.Windows.Forms.Padding.Empty
        };
        for (int i = 0; i < 7; i++) tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 7));
        tabla.RowStyles.Add(new RowStyle(SizeType.Absolute));
        tabla.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        tabla.RowStyles.Add(new RowStyle(SizeType.Absolute));
        anterior = Boton("calendarioFechaAnterior", "‹", "Período anterior");
        siguiente = Boton("calendarioFechaSiguiente", "›", "Período siguiente");
        mes = Boton("calendarioFechaMes", "", "Mostrar meses");
        tabla.Controls.Add(anterior, 0, 0); tabla.Controls.Add(mes, 1, 0); tabla.SetColumnSpan(mes, 5);
        tabla.Controls.Add(siguiente, 6, 0);
        anterior.Click += (_, _) => MoverPagina(-1);
        siguiente.Click += (_, _) => MoverPagina(1);
        mes.Click += (_, _) => SubirVista();
        cuerpo = new Panel { Dock = DockStyle.Fill, Margin = System.Windows.Forms.Padding.Empty };
        tabla.Controls.Add(cuerpo, 0, 1); tabla.SetColumnSpan(cuerpo, 7);
        tablaDias = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 7, RowCount = 7,
            Margin = System.Windows.Forms.Padding.Empty
        };
        for (int i = 0; i < 7; i++) tablaDias.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 7));
        tablaDias.RowStyles.Add(new RowStyle(SizeType.Absolute));
        for (int i = 0; i < 6; i++) tablaDias.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / 6));
        for (int i = 0; i < semanas.Length; i++)
        {
            semanas[i] = new Label
            {
                Name = "calendarioFechaSemana" + i, Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter, Margin = System.Windows.Forms.Padding.Empty
            };
            tablaDias.Controls.Add(semanas[i], i, 0);
        }
        for (int i = 0; i < dias.Length; i++)
        {
            var boton = dias[i] = Boton("calendarioFechaDia" + i, "", "Fecha");
            boton.Click += (_, _) => { if (boton.Tag is DateTime dia) Elegir(dia); };
            tablaDias.Controls.Add(boton, i % 7, 1 + i / 7);
        }
        tablaPeriodos = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 3,
            Margin = System.Windows.Forms.Padding.Empty, Visible = false
        };
        for (int i = 0; i < 4; i++) tablaPeriodos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        for (int i = 0; i < 3; i++) tablaPeriodos.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / 3));
        for (int i = 0; i < periodos.Length; i++)
        {
            var boton = periodos[i] = Boton("calendarioFechaPeriodo" + i, "", "Período");
            boton.Click += (_, _) => { if (boton.Tag is MYGPeriodoFecha periodo) ElegirPeriodo(periodo); };
            tablaPeriodos.Controls.Add(boton, i % 4, i / 4);
        }
        transicion = new TransicionCalendario
        {
            Name = "calendarioFechaTransicion", Dock = DockStyle.Fill,
            Visible = false, Enabled = false, TabStop = false
        };
        cuerpo.Controls.Add(tablaDias); cuerpo.Controls.Add(tablaPeriodos); cuerpo.Controls.Add(transicion);
        hoy = Boton("calendarioFechaHoy", "", "Hoy");
        hoy.Click += (_, _) => Elegir(DateTime.Today);
        tabla.Controls.Add(hoy, 0, 2); tabla.SetColumnSpan(hoy, 7);
        contenido.Controls.Add(tabla);
        alojamiento = new ToolStripControlHost(contenido)
        {
            AutoSize = false, Margin = System.Windows.Forms.Padding.Empty,
            Padding = System.Windows.Forms.Padding.Empty
        };
        Items.Add(alojamiento);
        MYG2027_TemaComercial.CambioTema += CambiarTema;
    }

    private BotonCalendario Boton(string nombre, string texto, string accesible)
    {
        var boton = new BotonCalendario
        {
            Name = nombre, Text = texto, AccessibleName = accesible,
            Dock = DockStyle.Fill, Margin = System.Windows.Forms.Padding.Empty,
            FlatStyle = FlatStyle.Flat, UseVisualStyleBackColor = false, TabStop = false
        };
        boton.KeyDown += (_, e) =>
        {
            if (ProcesarTecla(e.KeyData)) e.Handled = e.SuppressKeyPress = true;
        };
        return boton;
    }

    internal void Abrir()
    {
        if (IsDisposed || fecha.IsDisposed || fecha.Disposing || !fecha.IsHandleCreated || !fecha.Enabled) return;
        cultura = CultureInfo.CurrentCulture;
        minimo = fecha.MinDate.Date; maximo = fecha.MaxDate.Date;
        activa = MYGCalendarioFechaModelo.Limitar(fecha.Value, minimo, maximo);
        mostrada = MYGCalendarioFechaModelo.InicioMes(activa);
        transicion.Detener();
        vista = MYGVistaCalendarioFecha.Dias;
        confirmada = false;
        RightToLeft = contenido.RightToLeft = fecha.RightToLeft;
        // El desplegable se reutiliza y puede permanecer oculto mientras el
        // propietario sustituye y libera CalendarFont. Conservar una copia
        // propia evita usar después una fuente ajena ya liberada.
        var anteriorFuente = fuentePropia;
        fuentePropia = (Font)fecha.CalendarFont.Clone();
        Font = contenido.Font = tabla.Font = alojamiento.Font = fuentePropia;
        AsignarFuente(tabla, fuentePropia);
        anteriorFuente?.Dispose();
        ActualizarDias();
        var ancla = fecha.RectangleToScreen(fecha.ClientRectangle);
        var area = Screen.FromControl(fecha).WorkingArea;
        Medir(area);
        int x = Math.Clamp(ancla.Left, area.Left, Math.Max(area.Left, area.Right - Width));
        int y = ancla.Bottom;
        if (y + Height > area.Bottom) y = ancla.Top - Height;
        y = Math.Clamp(y, area.Top, Math.Max(area.Top, area.Bottom - Height));
        Show(fecha, fecha.PointToClient(new Point(x, y)));
        EnfocarDia();
    }

    private static void AsignarFuente(Control control, Font fuente)
    {
        control.Font = fuente;
        foreach (Control hijo in control.Controls) AsignarFuente(hijo, fuente);
    }

    protected override void OnOpened(EventArgs e)
    {
        base.OnOpened(e);
        // La aplicación tematiza los menús al mostrarlos. Reponer después los
        // colores de selección propios, además del dibujo independiente de los días.
        AplicarColores();
        EnfocarDia();
    }

    private void Medir(Rectangle area)
    {
        int P(int valor) => Math.Max(1, (int)Math.Ceiling(valor * fecha.DeviceDpi / 96D));
        using var dibujo = fecha.CreateGraphics();
        int altoTexto = (int)Math.Ceiling(Font.GetHeight(dibujo));
        int MedirTexto(string texto) => TextRenderer.MeasureText(dibujo, texto, Font,
            Size.Empty, TextFormatFlags.NoPadding | TextFormatFlags.SingleLine).Width;
        int margen = P(6), marco = P(1);
        int altoDia = Math.Max(P(26), altoTexto + P(10));
        int altoCabecera = Math.Max(P(30), altoTexto + P(12));
        int altoSemana = altoTexto + P(6);
        int anchoDia = Math.Max(P(32), semanas.Max(dia => MedirTexto(dia.Text)) + P(10));
        int ancho = Math.Max(anchoDia * 7 + margen * 2 + marco * 2,
            Math.Max(MedirTexto(mes.Text) + altoCabecera * 2 + margen * 4, MedirTexto(hoy.Text) + margen * 4));
        // No cambiar el tamaño del desplegable al pasar de días a décadas.
        int anchoPeriodo = Math.Max(MedirTexto("9990–9999"), Enumerable.Range(1, 12)
            .Max(numero => MedirTexto(cultura.DateTimeFormat.GetAbbreviatedMonthName(numero)))) + P(12);
        ancho = Math.Max(ancho, anchoPeriodo * 4 + margen * 2 + marco * 2);
        int alto = altoCabecera * 2 + altoSemana + altoDia * 6 + margen * 2 + marco * 2;
        Padding = new Padding(marco);
        tabla.Padding = new Padding(margen);
        tabla.RowStyles[0].Height = tabla.RowStyles[2].Height = altoCabecera;
        tablaDias.RowStyles[0].Height = altoSemana;
        Size = new Size(Math.Min(ancho, area.Width), Math.Min(alto, area.Height));
        alojamiento.Size = contenido.Size = new Size(Math.Max(1, Width - marco * 2), Math.Max(1, Height - marco * 2));
    }

    private void ActualizarDias()
    {
        var inicioVista = MYGCalendarioFechaModelo.InicioVista(activa, vista);
        mes.Text = vista switch
        {
            MYGVistaCalendarioFecha.Dias => mostrada.ToString("MMMM yyyy", cultura),
            MYGVistaCalendarioFecha.Meses => activa.Year.ToString(cultura),
            MYGVistaCalendarioFecha.Anos => RangoAnos(activa.Year / 10 * 10, 10),
            _ => RangoAnos(activa.Year / 100 * 100, 100)
        };
        mes.AccessibleName = mes.Text;
        mes.AccessibleDescription = vista switch
        {
            MYGVistaCalendarioFecha.Dias => "Mostrar los meses del año.",
            MYGVistaCalendarioFecha.Meses => "Mostrar los años de la década.",
            MYGVistaCalendarioFecha.Anos => "Mostrar las décadas del siglo.",
            _ => "Vista de décadas. Elija una para acercar."
        };
        mes.Enabled = vista != MYGVistaCalendarioFecha.Decadas;
        tablaDias.Visible = vista == MYGVistaCalendarioFecha.Dias;
        tablaPeriodos.Visible = vista != MYGVistaCalendarioFecha.Dias;
        int primero = (int)cultura.DateTimeFormat.FirstDayOfWeek;
        for (int i = 0; i < semanas.Length; i++)
        {
            var diaSemana = (DayOfWeek)((primero + i) % 7);
            semanas[i].Text = cultura.DateTimeFormat.GetAbbreviatedDayName(diaSemana);
            semanas[i].AccessibleName = cultura.DateTimeFormat.GetDayName(diaSemana);
        }
        DateTime?[] celdas = MYGCalendarioFechaModelo.Dias(mostrada, cultura.DateTimeFormat.FirstDayOfWeek);
        for (int i = 0; i < dias.Length; i++)
        {
            var boton = dias[i];
            boton.Tag = celdas[i];
            boton.Text = celdas[i]?.Day.ToString(cultura) ?? "";
            boton.Enabled = celdas[i] is DateTime dia && MYGCalendarioFechaModelo.Permitida(dia, minimo, maximo);
            boton.Activo = celdas[i] == activa;
            boton.OtroMes = celdas[i] is DateTime fechaDia && fechaDia.Month != mostrada.Month;
            boton.EsHoy = celdas[i] == DateTime.Today;
            boton.TabStop = boton.Activo && boton.Enabled;
            boton.AccessibleName = celdas[i]?.ToString("D", cultura) ?? "Fuera del calendario";
            boton.AccessibleDescription = boton.Activo ? "Fecha activa. Intro para elegir."
                : boton.Enabled ? "Elegir esta fecha." : "Fecha no disponible.";
        }
        if (vista != MYGVistaCalendarioFecha.Dias)
        {
            var celdasPeriodo = MYGCalendarioFechaModelo.Periodos(activa, vista);
            for (int i = 0; i < periodos.Length; i++)
            {
                var boton = periodos[i];
                boton.Tag = celdasPeriodo[i];
                boton.Text = celdasPeriodo[i] is not MYGPeriodoFecha periodo ? "" : vista switch
                {
                    MYGVistaCalendarioFecha.Meses => cultura.DateTimeFormat.GetAbbreviatedMonthName(periodo.Inicio.Month),
                    MYGVistaCalendarioFecha.Anos => periodo.Inicio.Year.ToString(cultura),
                    _ => RangoAnos(periodo.Inicio.Year, periodo.Fin.Year - periodo.Inicio.Year + 1)
                };
                boton.Enabled = celdasPeriodo[i] is MYGPeriodoFecha p && MYGCalendarioFechaModelo.PeriodoPermitido(p, minimo, maximo);
                boton.Activo = celdasPeriodo[i] is MYGPeriodoFecha a && activa >= a.Inicio && activa <= a.Fin;
                boton.OtroMes = celdasPeriodo[i]?.EsAdyacente ?? false;
                boton.EsHoy = celdasPeriodo[i] is MYGPeriodoFecha h && DateTime.Today >= h.Inicio && DateTime.Today <= h.Fin;
                boton.TabStop = boton.Activo && boton.Enabled;
                boton.AccessibleName = celdasPeriodo[i] is not MYGPeriodoFecha nombre ? "Fuera del calendario"
                    : vista == MYGVistaCalendarioFecha.Meses ? nombre.Inicio.ToString("MMMM yyyy", cultura) : boton.Text;
                boton.AccessibleDescription = boton.Enabled ? "Mostrar este período sin confirmar la fecha." : "Período no disponible.";
            }
        }
        anterior.Enabled = inicioVista > MYGCalendarioFechaModelo.InicioVista(minimo, vista);
        siguiente.Enabled = inicioVista < MYGCalendarioFechaModelo.InicioVista(maximo, vista);
        string unidad = vista switch
        {
            MYGVistaCalendarioFecha.Dias => "Mes", MYGVistaCalendarioFecha.Meses => "Año",
            MYGVistaCalendarioFecha.Anos => "Década", _ => "Siglo"
        };
        anterior.AccessibleName = unidad + " anterior"; siguiente.AccessibleName = unidad + " siguiente";
        hoy.Text = "Hoy: " + DateTime.Today.ToString("D", cultura);
        hoy.AccessibleName = hoy.Text;
        hoy.Enabled = MYGCalendarioFechaModelo.Permitida(DateTime.Today, minimo, maximo);
        AplicarColores();
    }

    private string RangoAnos(int inicio, int cantidad) => Math.Max(1, inicio).ToString(cultura)
        + "–" + Math.Min(9999, inicio + cantidad - 1).ToString(cultura);

    private void AplicarColores()
    {
        BackColor = MYG2027_TemaComercial.Borde;
        ForeColor = contenido.ForeColor = tabla.ForeColor = MYG2027_TemaComercial.Texto;
        contenido.BackColor = tabla.BackColor = cuerpo.BackColor = tablaDias.BackColor = tablaPeriodos.BackColor
            = mes.BackColor = transicion.BackColor = MYG2027_TemaComercial.Superficie;
        mes.ForeColor = MYG2027_TemaComercial.Texto;
        foreach (var semana in semanas)
        {
            semana.BackColor = MYG2027_TemaComercial.Superficie;
            semana.ForeColor = MYG2027_TemaComercial.Secundario;
        }
        foreach (var boton in dias.Concat(periodos).Concat(new[] { anterior, siguiente, hoy, mes }))
        {
            boton.BackColor = boton.Activo ? MYG2027_TemaComercial.Azul : MYG2027_TemaComercial.Superficie;
            boton.ForeColor = boton.Activo ? MYG2027_TemaComercial.TextoSobreAzul
                : boton.OtroMes || !boton.Enabled ? MYG2027_TemaComercial.Secundario : MYG2027_TemaComercial.Texto;
            boton.FlatAppearance.BorderSize = 0;
            boton.Invalidate();
        }
    }

    private void MoverPagina(int cantidad)
    {
        DateTime nueva = MYGCalendarioFechaModelo.MoverPagina(activa, cantidad, vista, minimo, maximo);
        if (nueva == activa) return;
        Cambiar(() => activa = nueva, cantidad < 0 ? TipoTransicion.Anterior : TipoTransicion.Siguiente);
    }

    private void MoverCeldas(int cantidad)
    {
        DateTime nueva = MYGCalendarioFechaModelo.MoverCelda(activa, cantidad, vista, minimo, maximo);
        if (MYGCalendarioFechaModelo.InicioVista(nueva, vista) != MYGCalendarioFechaModelo.InicioVista(activa, vista))
            Cambiar(() => activa = nueva, cantidad < 0 ? TipoTransicion.Anterior : TipoTransicion.Siguiente);
        else
        {
            transicion.Detener(); activa = nueva;
            ActualizarDias(); EnfocarDia();
        }
    }

    private void SubirVista()
    {
        if (vista != MYGVistaCalendarioFecha.Decadas) Cambiar(() => vista++, TipoTransicion.Ampliar);
    }

    private void ElegirPeriodo(MYGPeriodoFecha periodo)
    {
        if (!MYGCalendarioFechaModelo.PeriodoPermitido(periodo, minimo, maximo)) return;
        Cambiar(() =>
        {
            activa = MYGCalendarioFechaModelo.ElegirPeriodo(activa, periodo, vista, minimo, maximo);
            vista--;
        }, TipoTransicion.Reducir);
    }

    private void ConfirmarVista()
    {
        if (vista == MYGVistaCalendarioFecha.Dias) Elegir(activa);
        else ElegirPeriodo(MYGCalendarioFechaModelo.Periodos(activa, vista)
            .First(p => p.HasValue && activa >= p.Value.Inicio && activa <= p.Value.Fin).Value);
    }

    private void Cambiar(Action cambio, TipoTransicion tipo)
    {
        transicion.Detener();
        Bitmap antes = null, despues = null;
        try
        {
            bool animar = Visible && SystemInformation.IsMenuAnimationEnabled
                && System.Windows.SystemParameters.ClientAreaAnimation && !SystemInformation.HighContrast;
            if (animar) antes = CapturarVista();
            cambio(); mostrada = MYGCalendarioFechaModelo.InicioMes(activa);
            ActualizarDias(); cuerpo.PerformLayout(); EnfocarDia();
            if (antes != null)
            {
                despues = CapturarVista();
                if (despues != null)
                {
                    if (RightToLeft == RightToLeft.Yes)
                        tipo = tipo == TipoTransicion.Anterior ? TipoTransicion.Siguiente
                            : tipo == TipoTransicion.Siguiente ? TipoTransicion.Anterior : tipo;
                    transicion.Iniciar(antes, despues, tipo);
                    antes = despues = null; // La transición posee y libera ambas imágenes.
                }
            }
        }
        finally { antes?.Dispose(); despues?.Dispose(); }
    }

    private Bitmap CapturarVista()
    {
        var control = vista == MYGVistaCalendarioFecha.Dias ? tablaDias : tablaPeriodos;
        if (control.Width <= 0 || control.Height <= 0) return null;
        control.PerformLayout();
        var imagen = new Bitmap(control.Width, control.Height);
        try { control.DrawToBitmap(imagen, new Rectangle(Point.Empty, imagen.Size)); return imagen; }
        catch { imagen.Dispose(); throw; }
    }

    private void EnfocarDia()
    {
        if (!Visible) return;
        (vista == MYGVistaCalendarioFecha.Dias ? dias : periodos)
            .FirstOrDefault(dia => dia.Enabled && dia.Activo)?.Focus();
    }

    private void Elegir(DateTime dia)
    {
        if (confirmada || !MYGCalendarioFechaModelo.Permitida(dia, minimo, maximo)) return;
        confirmada = true;
        var elegir = FechaElegida;
        Close(ToolStripDropDownCloseReason.ItemClicked);
        elegir?.Invoke(dia.Date);
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) =>
        ProcesarTecla(keyData) || base.ProcessCmdKey(ref msg, keyData);

    private bool ProcesarTecla(Keys teclas)
    {
        Keys tecla = teclas & Keys.KeyCode;
        if (tecla is Keys.Escape or Keys.F4 || tecla == Keys.Down && teclas.HasFlag(Keys.Alt))
        {
            Close(ToolStripDropDownCloseReason.Keyboard); return true;
        }
        if (tecla == Keys.Tab)
        {
            bool avanzar = !teclas.HasFlag(Keys.Shift);
            Close(ToolStripDropDownCloseReason.Keyboard);
            if (!fecha.IsDisposed && fecha.IsHandleCreated)
                fecha.BeginInvoke(new Action(() =>
                {
                    if (!fecha.IsDisposed && fecha.IsHandleCreated)
                        fecha.FindForm()?.SelectNextControl(fecha, avanzar, true, true, true);
                }));
            return true;
        }
        if (teclas.HasFlag(Keys.Alt)) return false;
        if (teclas.HasFlag(Keys.Control) && tecla == Keys.Up) { SubirVista(); return true; }
        if (teclas.HasFlag(Keys.Control) && tecla == Keys.Down)
        {
            if (vista != MYGVistaCalendarioFecha.Dias) ConfirmarVista();
            return true;
        }
        switch (tecla)
        {
            case Keys.Left: MoverCeldas(RightToLeft == RightToLeft.Yes ? 1 : -1); break;
            case Keys.Right: MoverCeldas(RightToLeft == RightToLeft.Yes ? -1 : 1); break;
            case Keys.Up: MoverCeldas(vista == MYGVistaCalendarioFecha.Dias ? -7 : -4); break;
            case Keys.Down: MoverCeldas(vista == MYGVistaCalendarioFecha.Dias ? 7 : 4); break;
            case Keys.PageUp: MoverPagina(vista == MYGVistaCalendarioFecha.Dias && teclas.HasFlag(Keys.Control) ? -12 : -1); break;
            case Keys.PageDown: MoverPagina(vista == MYGVistaCalendarioFecha.Dias && teclas.HasFlag(Keys.Control) ? 12 : 1); break;
            case Keys.Home:
                IrAlExtremo(false); break;
            case Keys.End:
                IrAlExtremo(true); break;
            case Keys.Enter:
            case Keys.Space: ConfirmarVista(); break;
            default: return false;
        }
        return true;
    }

    private void IrAlExtremo(bool ultimo)
    {
        if (vista == MYGVistaCalendarioFecha.Dias)
        {
            int dia = (7 + (int)activa.DayOfWeek - (int)cultura.DateTimeFormat.FirstDayOfWeek) % 7;
            MoverCeldas(ultimo ? 6 - dia : -dia);
            return;
        }
        var opciones = MYGCalendarioFechaModelo.Periodos(activa, vista)
            .Where(p => p.HasValue && !p.Value.EsAdyacente && MYGCalendarioFechaModelo.PeriodoPermitido(p.Value, minimo, maximo));
        if (!opciones.Any()) return;
        transicion.Detener();
        activa = MYGCalendarioFechaModelo.ElegirPeriodo(activa, (ultimo ? opciones.Last() : opciones.First()).Value, vista, minimo, maximo);
        mostrada = MYGCalendarioFechaModelo.InicioMes(activa);
        ActualizarDias(); EnfocarDia();
    }

    private void CambiarTema(object sender, EventArgs e)
    {
        if (!IsDisposed) { transicion.Detener(); AplicarColores(); }
    }

    protected override void OnClosed(ToolStripDropDownClosedEventArgs e)
    {
        transicion.Detener();
        base.OnClosed(e);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) MYG2027_TemaComercial.CambioTema -= CambiarTema;
        try { base.Dispose(disposing); }
        finally
        {
            if (disposing) { fuentePropia?.Dispose(); fuentePropia = null; }
        }
    }

    private sealed class ContenidoCalendario : UserControl
    {
        private readonly MYGCalendarioFechaPopup propietario;
        internal ContenidoCalendario(MYGCalendarioFechaPopup propietario) => this.propietario = propietario;
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData) =>
            propietario.ProcesarTecla(keyData) || base.ProcessCmdKey(ref msg, keyData);
    }

    private sealed class BotonCalendario : Button
    {
        internal bool Activo, OtroMes, EsHoy;
        private bool sobre, pulsado;
        protected override void OnMouseEnter(EventArgs e) { sobre = true; base.OnMouseEnter(e); Invalidate(); }
        protected override void OnMouseLeave(EventArgs e) { sobre = pulsado = false; base.OnMouseLeave(e); Invalidate(); }
        protected override void OnMouseDown(MouseEventArgs e) { pulsado = e.Button == MouseButtons.Left; base.OnMouseDown(e); Invalidate(); }
        protected override void OnMouseUp(MouseEventArgs e) { pulsado = false; base.OnMouseUp(e); Invalidate(); }
        protected override void OnPaint(PaintEventArgs e)
        {
            // La selección usa siempre la paleta actual, aunque el adaptador
            // genérico de botones haya actualizado BackColor o FlatAppearance.
            Color fondo = Activo ? MYG2027_TemaComercial.Azul : MYG2027_TemaComercial.Superficie;
            if (!Activo && Enabled && sobre)
            {
                Color azul = MYG2027_TemaComercial.Azul;
                int peso = pulsado ? 3 : 1;
                fondo = Color.FromArgb((fondo.R * (5 - peso) + azul.R * peso) / 5,
                    (fondo.G * (5 - peso) + azul.G * peso) / 5, (fondo.B * (5 - peso) + azul.B * peso) / 5);
            }
            Color texto = Activo ? MYG2027_TemaComercial.TextoSobreAzul
                : OtroMes || !Enabled ? MYG2027_TemaComercial.Secundario : MYG2027_TemaComercial.Texto;
            using (var pincel = new SolidBrush(fondo)) e.Graphics.FillRectangle(pincel, ClientRectangle);
            TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle, texto, fondo,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
                TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
            if (EsHoy && Width > 1 && Height > 1)
            {
                using var borde = new Pen(Activo ? MYG2027_TemaComercial.TextoSobreAzul : MYG2027_TemaComercial.Azul);
                e.Graphics.DrawRectangle(borde, 1, 1, Math.Max(0, Width - 3), Math.Max(0, Height - 3));
            }
            if (Focused && ShowFocusCues)
                ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -3, -3), texto, fondo);
        }
    }

    private enum TipoTransicion { Anterior, Siguiente, Ampliar, Reducir }

    private sealed class TransicionCalendario : Control
    {
        private readonly System.Windows.Forms.Timer reloj = new() { Interval = 15 };
        private readonly Stopwatch tiempo = new();
        private Bitmap antes, despues;
        private TipoTransicion tipo;

        internal TransicionCalendario()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            reloj.Tick += Avanzar;
        }

        internal void Iniciar(Bitmap anterior, Bitmap siguiente, TipoTransicion movimiento)
        {
            Detener(); antes = anterior; despues = siguiente; tipo = movimiento;
            tiempo.Restart(); Visible = true; BringToFront(); reloj.Start(); Invalidate();
        }

        internal void Detener()
        {
            reloj.Stop(); tiempo.Reset(); Visible = false;
            antes?.Dispose(); despues?.Dispose(); antes = despues = null;
        }

        private void Avanzar(object sender, EventArgs e)
        {
            if (tiempo.ElapsedMilliseconds >= 160) Detener();
            else Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            if (antes == null || despues == null) return;
            float progreso = Math.Clamp(tiempo.ElapsedMilliseconds / 160F, 0, 1);
            float suave = 1 - MathF.Pow(1 - progreso, 3);
            var area = ClientRectangle;
            if (tipo is TipoTransicion.Anterior or TipoTransicion.Siguiente)
            {
                int sentido = tipo == TipoTransicion.Siguiente ? 1 : -1;
                var salida = area; salida.X = (int)(-sentido * Width * suave);
                var entrada = area; entrada.X = (int)(sentido * Width * (1 - suave));
                e.Graphics.DrawImage(antes, salida); e.Graphics.DrawImage(despues, entrada);
            }
            else
            {
                float sentido = tipo == TipoTransicion.Ampliar ? -1 : 1;
                Dibujar(antes, 1 + sentido * .25F * suave, 1 - suave);
                Dibujar(despues, 1 - sentido * .25F * (1 - suave), suave);
            }

            void Dibujar(Bitmap imagen, float escala, float opacidad)
            {
                int ancho = (int)(Width * escala), alto = (int)(Height * escala);
                using var atributos = new ImageAttributes();
                atributos.SetColorMatrix(new ColorMatrix { Matrix33 = opacidad });
                e.Graphics.DrawImage(imagen, new Rectangle((Width - ancho) / 2, (Height - alto) / 2, ancho, alto),
                    0, 0, imagen.Width, imagen.Height, GraphicsUnit.Pixel, atributos);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { Detener(); reloj.Tick -= Avanzar; reloj.Dispose(); }
            base.Dispose(disposing);
        }
    }
}
