using System;

namespace MYG_2027;

internal enum MYGVistaCalendarioFecha { Dias, Meses, Anos, Decadas }

internal readonly record struct MYGPeriodoFecha(DateTime Inicio, DateTime Fin, bool EsAdyacente);

// Geometría y navegación por fechas gregorianas, independiente de WinForms.
// Los resultados contienen sólo la fecha (00:00) y conservan el Kind de entrada.
internal static class MYGCalendarioFechaModelo
{
    internal static DateTime InicioMes(DateTime fecha) => fecha.Date.AddDays(1 - fecha.Day);

    internal static DateTime InicioVista(DateTime fecha, MYGVistaCalendarioFecha vista) => vista switch
    {
        MYGVistaCalendarioFecha.Dias => InicioMes(fecha),
        MYGVistaCalendarioFecha.Meses => new DateTime(fecha.Year, 1, 1, 0, 0, 0, fecha.Kind),
        MYGVistaCalendarioFecha.Anos => new DateTime(Math.Max(1, fecha.Year / 10 * 10), 1, 1, 0, 0, 0, fecha.Kind),
        MYGVistaCalendarioFecha.Decadas => new DateTime(Math.Max(1, fecha.Year / 100 * 100), 1, 1, 0, 0, 0, fecha.Kind),
        _ => throw new ArgumentOutOfRangeException(nameof(vista))
    };

    // Las vistas superiores usan doce celdas: doce meses o diez períodos
    // centrales y los dos vecinos. No se inventan años cero o posteriores a 9999.
    internal static MYGPeriodoFecha?[] Periodos(DateTime fecha, MYGVistaCalendarioFecha vista)
    {
        if (vista is not (MYGVistaCalendarioFecha.Meses or MYGVistaCalendarioFecha.Anos or MYGVistaCalendarioFecha.Decadas))
            throw new ArgumentOutOfRangeException(nameof(vista));
        var periodos = new MYGPeriodoFecha?[12];
        for (int i = 0; i < periodos.Length; i++)
        {
            int primerAno, ultimoAno, primerMes, ultimoMes;
            if (vista == MYGVistaCalendarioFecha.Meses)
            {
                primerAno = ultimoAno = fecha.Year;
                primerMes = ultimoMes = i + 1;
            }
            else
            {
                int anos = vista == MYGVistaCalendarioFecha.Anos ? 1 : 10;
                int inicio = vista == MYGVistaCalendarioFecha.Anos ? fecha.Year / 10 * 10 : fecha.Year / 100 * 100;
                primerAno = inicio + (i - 1) * anos;
                ultimoAno = primerAno + anos - 1;
                if (ultimoAno < 1 || primerAno > 9999) continue;
                primerAno = Math.Max(1, primerAno); ultimoAno = Math.Min(9999, ultimoAno);
                primerMes = 1; ultimoMes = 12;
            }
            periodos[i] = new MYGPeriodoFecha(
                new DateTime(primerAno, primerMes, 1, 0, 0, 0, fecha.Kind),
                new DateTime(ultimoAno, ultimoMes, DateTime.DaysInMonth(ultimoAno, ultimoMes), 0, 0, 0, fecha.Kind),
                vista != MYGVistaCalendarioFecha.Meses && (i == 0 || i == 11));
        }
        return periodos;
    }

    internal static bool PeriodoPermitido(MYGPeriodoFecha periodo, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        ValidarRango(periodo.Inicio, periodo.Fin);
        return periodo.Inicio.Date <= maximo.Date && periodo.Fin.Date >= minimo.Date;
    }

    internal static DateTime MoverPagina(DateTime dia, int paginas, MYGVistaCalendarioFecha vista,
        DateTime minimo, DateTime maximo)
    {
        int meses = vista switch
        {
            MYGVistaCalendarioFecha.Dias => 1,
            MYGVistaCalendarioFecha.Meses => 12,
            MYGVistaCalendarioFecha.Anos => 120,
            MYGVistaCalendarioFecha.Decadas => 1200,
            _ => throw new ArgumentOutOfRangeException(nameof(vista))
        };
        return MoverMeses(dia, (long)paginas * meses, minimo, maximo);
    }

    internal static DateTime MoverCelda(DateTime dia, int celdas, MYGVistaCalendarioFecha vista,
        DateTime minimo, DateTime maximo) => vista switch
    {
        MYGVistaCalendarioFecha.Dias => MoverDias(dia, celdas, minimo, maximo),
        MYGVistaCalendarioFecha.Meses => MoverMeses(dia, celdas, minimo, maximo),
        MYGVistaCalendarioFecha.Anos => MoverMeses(dia, (long)celdas * 12, minimo, maximo),
        MYGVistaCalendarioFecha.Decadas => MoverMeses(dia, (long)celdas * 120, minimo, maximo),
        _ => throw new ArgumentOutOfRangeException(nameof(vista))
    };

    internal static DateTime ElegirPeriodo(DateTime activa, MYGPeriodoFecha periodo, MYGVistaCalendarioFecha vista,
        DateTime minimo, DateTime maximo)
    {
        if (vista is not (MYGVistaCalendarioFecha.Meses or MYGVistaCalendarioFecha.Anos or MYGVistaCalendarioFecha.Decadas))
            throw new ArgumentOutOfRangeException(nameof(vista));
        if (!PeriodoPermitido(periodo, minimo, maximo))
            throw new ArgumentOutOfRangeException(nameof(periodo), "El período no contiene fechas permitidas.");
        int ano = vista == MYGVistaCalendarioFecha.Decadas
            ? Math.Clamp(periodo.Inicio.Year / 10 * 10 + activa.Year % 10, periodo.Inicio.Year, periodo.Fin.Year)
            : periodo.Inicio.Year;
        int mes = vista == MYGVistaCalendarioFecha.Meses ? periodo.Inicio.Month : activa.Month;
        var elegida = new DateTime(ano, mes, Math.Min(activa.Day, DateTime.DaysInMonth(ano, mes)),
            0, 0, 0, activa.Kind);
        DateTime desde = periodo.Inicio.Date > minimo.Date ? periodo.Inicio.Date : minimo.Date;
        DateTime hasta = periodo.Fin.Date < maximo.Date ? periodo.Fin.Date : maximo.Date;
        return Limitar(elegida, desde, hasta);
    }

    // Seis semanas completas. En los extremos de DateTime hay casillas sin
    // fecha representable; se dejan vacías en vez de desbordar o repetir días.
    internal static DateTime?[] Dias(DateTime mes, DayOfWeek primerDia)
    {
        if ((uint)primerDia > 6) throw new ArgumentOutOfRangeException(nameof(primerDia));
        DateTime inicio = InicioMes(mes);
        int anteriores = ((int)inicio.DayOfWeek - (int)primerDia + 7) % 7;
        var dias = new DateTime?[42];
        for (int i = 0; i < dias.Length; i++)
        {
            long ticks = inicio.Ticks + (i - anteriores) * TimeSpan.TicksPerDay;
            if (ticks >= DateTime.MinValue.Ticks && ticks <= DateTime.MaxValue.Date.Ticks)
                dias[i] = new DateTime(ticks, mes.Kind);
        }
        return dias;
    }

    internal static bool Permitida(DateTime dia, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        return dia.Date >= minimo.Date && dia.Date <= maximo.Date;
    }

    internal static DateTime Limitar(DateTime dia, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        DateTime fecha = dia.Date;
        if (fecha < minimo.Date) fecha = minimo.Date;
        if (fecha > maximo.Date) fecha = maximo.Date;
        return DateTime.SpecifyKind(fecha, dia.Kind);
    }

    // Saturar el índice mensual evita AddMonths fuera de 1..9999 y conserva
    // el día de mes cuando existe; por ejemplo 31/01 pasa a 28 o 29/02.
    internal static DateTime MoverMes(DateTime dia, int meses, DateTime minimo, DateTime maximo) =>
        MoverMeses(dia, meses, minimo, maximo);

    private static DateTime MoverMeses(DateTime dia, long meses, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        long indice = Math.Clamp((dia.Year - 1L) * 12 + dia.Month - 1 + meses, 0, 9999L * 12 - 1);
        int ano = (int)(indice / 12) + 1, mes = (int)(indice % 12) + 1;
        var fecha = new DateTime(ano, mes, Math.Min(dia.Day, DateTime.DaysInMonth(ano, mes)),
            0, 0, 0, dia.Kind);
        return Limitar(fecha, minimo, maximo);
    }

    internal static DateTime MoverDias(DateTime dia, int dias, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        // Calcular en días, no en ticks: incluso int.Min/MaxValue caben en long.
        long destino = Math.Clamp(dia.Date.Ticks / TimeSpan.TicksPerDay + dias,
            minimo.Date.Ticks / TimeSpan.TicksPerDay, maximo.Date.Ticks / TimeSpan.TicksPerDay);
        return new DateTime(destino * TimeSpan.TicksPerDay, dia.Kind);
    }

    private static void ValidarRango(DateTime minimo, DateTime maximo)
    {
        if (minimo.Date > maximo.Date)
            throw new ArgumentException("La fecha mínima no puede ser posterior a la máxima.", nameof(minimo));
    }
}
