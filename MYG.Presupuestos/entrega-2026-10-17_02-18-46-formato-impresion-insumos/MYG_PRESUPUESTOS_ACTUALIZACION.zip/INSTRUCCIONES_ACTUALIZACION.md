# Actualización: formato de impresión de la lista de insumos

## A. Resumen de la implementación

El botón de impresión señalado en la lista de insumos y su menú contextual abren un informe con el formato de la referencia:
- Papel A4 vertical, márgenes definidos y fuente Arial Narrow de 9 puntos.
- Título centrado LISTA DE INSUMOS DEL PRESUPUESTO o LISTA DE INSUMOS DEL PROYECTO.
- Cabecera con proyecto, presupuesto, propietario, ubicación y fecha del proyecto. Si se imprime un título, también se identifica la selección. El alcance de proyecto no atribuye toda la lista a un único presupuesto.
- Columnas Código, Descripción, Unid., Cantidad, Costo y Total. La cantidad tiene cuatro decimales; costo y total, dos. Proveedor no aparece en este formato impreso.
- Encabezados grises, grupos en negrita con sus subtotales y TOTAL: sombreado en las dos columnas derechas. Se conserva la regla doble superior.
- Las columnas caben juntas en A4. En listas largas se repiten cabecera y columnas, se mantienen los grupos con su primer insumo y el total con la fila anterior.
- La impresión respeta los filtros. Contraer un grupo en pantalla no elimina su detalle del informe.
- Copiar y el botón Excel conservan su formato anterior. La vista previa puede exportar su informe formateado con las herramientas existentes.
- Abrir, configurar y cerrar la vista previa no modifica ni guarda el proyecto.

## Base y compatibilidad

Repositorio del código: bimchimbote-droid/MYG.Presupuestos.
Rama base Git: main, commit 48765e07163a63217f87048fb4a6a1a76b5b504d.
Esta entrega incremental se aplica sobre la actualización anterior de insumos reales y eliminación de pestañas inferiores publicada en el repositorio independiente bimchimbote-droid/DESCARGAS, commit 6bae2dfb9ea45af0c64dff6bead38196070b150b:
MYG.Presupuestos/entrega-2026-10-16_16-59-25-insumos-pestanas/MYG_PRESUPUESTOS_ACTUALIZACION.zip

Conserva también las entregas anteriores de costo directo/fuente y listas contextuales. No sustituya estos archivos directamente sobre una copia antigua de main sin aplicar primero las actualizaciones previas correspondientes.

## B. Archivos de esta entrega

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | INSTRUCCIONES_ACTUALIZACION.md | REEMPLAZAR | Instrucciones de instalación y validación. |
| 2 | MYG.Core/ReportesInsumosContextoMYG.cs | CREAR | Genera el informe de insumos con el formato solicitado. |
| 3 | MYG.Core/ReportesProyectoMYG.cs | REEMPLAZAR | Reconoce la lista de insumos y su cabecera. |
| 4 | MYG.Core/ConfiguracionVistaReporte.cs | REEMPLAZAR | Conserva el formato al copiar y configurar la vista previa. |
| 5 | MYG.Desktop/PresupuestosInsumosContexto.cs | REEMPLAZAR | Conecta el botón y menú de impresión al nuevo informe. |
| 6 | MYG.Desktop/ReportesImpresion.cs | REEMPLAZAR | Dibuja las reglas, el total y pagina los grupos. |
| 7 | MYG.Pruebas/ReporteInsumosContextoCheck.cs | CREAR | Comprueba formato, alcances, literales, totales y exportación. |
| 8 | MYG.Pruebas/Program.cs | REEMPLAZAR | Ejecuta las nuevas comprobaciones funcionales. |
| 9 | MYG.PruebasUI/InsumosContextoUICheck.cs | REEMPLAZAR | Comprueba botón, menú, filtros y aislamiento de la vista previa. |
| 10 | MYG.PruebasUI/ReportesImpresionCheck.cs | REEMPLAZAR | Comprueba varias páginas y las seis columnas juntas. |

Los archivos se entregan completos. No hay eliminaciones ni parches que aplicar. El ZIP contiene sólo estos diez archivos; excluye bases de datos, credenciales, dependencias, ejecutables y metadatos Git.

## C. Descarga

MYG_PRESUPUESTOS_ACTUALIZACION.zip se publica en una ruta nueva de bimchimbote-droid/DESCARGAS, sin sobrescribir entregas anteriores.
La respuesta de entrega proporciona el enlace público HTTPS fijado al commit de publicación y el resultado de la descarga comparada por bytes y SHA-256, además de la comprobación de integridad ZIP.

## D. Instalación manual

1. Cierre MYG. En Visual Studio > Cambios de Git confirme o respalde los cambios locales.
2. Compruebe que tiene aplicada la entrega anterior indicada en Base y compatibilidad.
3. Descargue el ZIP y extráigalo fuera del proyecto.
4. Copie el contenido a la raíz del proyecto, conservando sus rutas. Carpeta de ejemplo: D:\ADDIN\repos\MYG.Presupuestos_GITHUB.
5. Cree los dos archivos nuevos y reemplace únicamente los ocho existentes indicados en la tabla. Si contienen cambios posteriores, compare y fusione antes de sustituirlos.
6. Abra MYG.Presupuestos.sln, restaure dependencias, compile Release y ejecute las comprobaciones siguientes.

## E. Configuraciones adicionales

Tecnologías: C#, .NET 10 y SQLite. SDK utilizado: .NET 10.0.100.
No hay paquetes nuevos, migraciones, credenciales ni cambios de solución/proyectos. Los proyectos SDK incluyen automáticamente las clases nuevas.
Use Arial Narrow instalada en Windows para reproducir la tipografía; la vista previa mantiene sus controles existentes para cambiar fuente, papel, márgenes y orientación.

## F. Compilación y validación

Desde la raíz del proyecto:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

En Windows, ejecute además:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

Resultados de esta entrega:
- Compilación completa Release: 0 errores y 0 advertencias.
- Suite funcional: 409 comprobaciones aprobadas. Incluyen formato del informe, precisión, códigos con ceros iniciales, descripciones literales, filtros, alcances, grupos, ajustes negativos, copia de vista previa, recorrido XLSX y conservación de los datos.
- Las pruebas UI se compilaron. No se ejecutaron en Linux porque necesitan Windows Desktop. Incluyen el botón y menú reales, presupuestos/títulos/proyecto, filtros pendientes, grupos contraídos, configuración sin mutación y paginación de 120 insumos.
- Named Pipes de Windows fue omitida por el runner. Las muestras privadas opcionales MYG_QA_LEGACY_JSON y MYG_QA_DELPHIN_SQLITE no se ejecutaron.
- No se ejecutaron Revit, licencias reales ni una impresora física. UseRevitReferencePackages permite compilar el conector sin tener Revit instalado.

Comprobaciones manuales en Windows:
1. Seleccione un presupuesto con insumos y pulse el botón de impresora de la lista. Compruebe título, cabecera real, seis columnas, fuente y total.
2. Compare con la referencia: unidad separada, cantidad de cuatro decimales, encabezado gris, grupos en negrita y recuadro TOTAL: a la derecha.
3. Imprima a Microsoft Print to PDF. Con una lista extensa, revise que continúan todos los insumos y se repiten las cabeceras.
4. Pruebe selección de título, pestaña proyecto, un filtro escrito sin confirmar y un grupo contraído. Deben respetarse alcance/filtros, sin perder insumos por contracción.
5. Cambie papel/fuente/márgenes en la vista y ciérrela. El proyecto, sus importes e historial deben permanecer intactos. Compruebe que copiar/Excel conservan su formato.

## G. Publicación del código en GitHub

Sólo el ZIP se publica en el repositorio independiente DESCARGAS. No se hace Commit ni Push al repositorio del código ni se modifica su rama main.
Después de aplicar y validar en Windows:
1. Abra Visual Studio > Cambios de Git y confirme la rama de trabajo.
2. Revise las diferencias y seleccione los archivos de esta entrega.
3. Haga Commit y después Push.
4. Verifique el commit en bimchimbote-droid/MYG.Presupuestos, en la rama correcta.

## H. Advertencias y pendientes

- La comparación visual final, la impresión a PDF/impresora y las pruebas UI quedan pendientes de ejecución en Windows.
- Reemplazar archivos completos puede perder cambios locales o posteriores: respalde y compare.
- El ZIP requiere la entrega anterior indicada y no contiene el proyecto completo.
- No se cambian ni eliminan bases de datos. Publicar el ZIP no aplica los cambios automáticamente en su PC.

