#nullable enable
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private ClienteSupabase? clienteNube;
    private NubeForm? ventanaNube;
    private bool clienteNubePreparado;
    private ConfiguracionNube? configuracionNube;
    private string? errorConfiguracionNube;
    private string? usuarioNube;
    private long generacionNube;
    private readonly System.Threading.SemaphoreSlim ingresoNube = new(1, 1);
    private static string CarpetaNube => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "trabajo");

    // Conservar el callback Action de los editores; IntentarAsync controla los
    // errores y las aperturas repetidas antes del primer await.
    private void MostrarNube() => _ = IntentarAsync(MostrarNubeAsync);

    private async Task MostrarNubeAsync()
    {
        RequerirSesion();
        if (!clienteNubePreparado)
        {
            try
            {
                configuracionNube = NubeConfiguracion.Cargar();
                errorConfiguracionNube = null;
            }
            catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or NubeException)
            {
                // Conservar el archivo y el destino previo: no sustituirlo por
                // otra conexión si está dañado. Su recuperación corresponde a soporte.
                configuracionNube = null;
                errorConfiguracionNube = "No se pudo leer la conexión guardada de Nube MYG. Solicite a soporte que revise la instalación. No se cambió el servidor de sus obras.";
            }
            clienteNubePreparado = true;
        }
        ActualizarSesionNube();
        bool nuevaVentana = ventanaNube is null || ventanaNube.IsDisposed;
        if (nuevaVentana)
        {
            ventanaNube = new NubeForm(sesion, clienteNube);
            ventanaNube.AbrirSolicitado += AbrirProyectoNube;
            ventanaNube.PublicarSolicitado += PublicarProyectoNube;
            ventanaNube.DescargarSolicitado += DescargarProyectoNube;
            ventanaNube.ConectarMygSolicitado += ConectarNubeConMygAsync;
        }
        var ventana = ventanaNube!;
        if (ventana.OperacionEnCurso)
        {
            ventana.Activate();
            return;
        }
        ventana.InformarErrorConfiguracion(errorConfiguracionNube);
        ventana.Hide();
        var clienteApertura = clienteNube;
        try
        {
            await MYGCargaAnimada.EjecutarAsync(this, "Conectando…", ventana.ConectarYRefrescarAsync);
            if (IsDisposed || Disposing || ventana.IsDisposed || ventana.Disposing) return;
            ComprobarClienteActual(clienteApertura!);
            ventana.Show(this); ventana.Activate();
        }
        catch
        {
            // El error se presenta sobre Inicio, una vez cerrada la carga.
            // No dejar una ventana nueva suscrita a la sesión tras fallar.
            if (nuevaVentana)
            {
                ventana.Dispose();
                if (ReferenceEquals(ventanaNube, ventana)) ventanaNube = null;
            }
            throw;
        }
    }

    private string? UsuarioMygActual => sesion.Autorizado
        ? sesion.Credencial?.Usuario?.Trim().ToLowerInvariant() : null;

    private void ActualizarSesionNube()
    {
        if (!clienteNubePreparado) return;
        string? usuario = UsuarioMygActual;
        if (usuario == usuarioNube && (clienteNube is not null || configuracionNube is null || usuario is null)) return;
        generacionNube++;
        var anterior = clienteNube;
        clienteNube = usuario is not null ? configuracionNube?.CrearCliente() : null;
        usuarioNube = usuario;
        // Cancelar y eliminar solo la sesión local anterior; nunca cerrar otras computadoras.
        anterior?.Dispose();
        ventanaNube?.ActualizarCliente(clienteNube);
    }

    private async Task ConectarNubeConMygAsync()
    {
        await ingresoNube.WaitAsync();
        try
        {
            if (IsDisposed || Disposing) return;
            RequerirSesion(); ActualizarSesionNube();
            var cliente = clienteNube ?? throw new InvalidOperationException("No se encontró la conexión de Nube MYG. Solicite a soporte que revise la instalación.");
            string usuario = UsuarioMygActual ?? throw new InvalidOperationException("Inicie sesión en MYG.");
            if (cliente.SesionIniciada && cliente.UsuarioMygSesion == usuario) return;
            long generacion = generacionNube;
            var resultado = await sesion.ObtenerTicketNubeAsync(cliente.UrlServidor);
            if (!resultado.Ok || resultado.Ticket is null) throw new InvalidOperationException(resultado.Mensaje);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            await cliente.IniciarSesionMygAsync(resultado.Ticket);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
            {
                cliente.Dispose();
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            }
            ventanaNube?.ActualizarCliente(cliente);
        }
        finally { ingresoNube.Release(); }
    }

    private void ComprobarClienteActual(ClienteSupabase cliente)
    {
        RequerirSesion();
        if (!ReferenceEquals(clienteNube, cliente) || !cliente.SesionIniciada || cliente.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Cambió la sesión MYG durante la operación. Vuelva a abrir Nube MYG.");
    }

    private ClienteSupabase RequerirNube()
    {
        RequerirSesion();
        if (clienteNube?.SesionIniciada != true || clienteNube.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Abra Nube MYG para conectar con su usuario MYG actual.");
        return clienteNube;
    }

    private static string CarpetaDeProyectoNube(ClienteSupabase cliente, Guid proyecto)
    {
        string servidor = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(cliente.UrlServidor)))[..24];
        if (!Guid.TryParse(cliente.UsuarioId, out var usuario)) throw new InvalidOperationException("La identidad de nube no es válida.");
        return Path.Combine(CarpetaNube, servidor, usuario.ToString("N"), proyecto.ToString("N"));
    }

    private async Task AbrirProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        Guid proyectoId = seleccionado.Id;
        string servidor = cliente.UrlServidor, usuario = cliente.UsuarioId!;
        var remoto = await Task.Run(() => cliente.AbrirProyectoAsync(proyectoId));
        ComprobarClienteActual(cliente);
        JsonElement contenido = remoto.Contenido;
        var contenidoCargado = await Task.Run(() => cliente.CargarArchivosAsync(contenido));
        ComprobarClienteActual(cliente);
        remoto = remoto with { Contenido = contenidoCargado };
        var existente = EditoresAbiertos.FirstOrDefault(e => e.NubeProyectoId == remoto.Id
            && string.Equals(e.NubeServidor?.TrimEnd('/'), servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase)
            && e.NubeUsuario == usuario);
        if (existente is not null)
        {
            await existente.ActualizarNubeAsync(true);
            ComprobarClienteActual(cliente);
            SeleccionarEditor(existente); ventanaNube?.Hide(); return;
        }
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Id);
        string ruta = Path.Combine(carpeta, "trabajo.sqlite");
        var original = await Task.Run(() => PaqueteNube.LeerDocumento(contenidoCargado));
        ComprobarClienteActual(cliente);
        MYGProyectoDocumento documento;
        if (File.Exists(ruta))
        {
            var recuperado = await Task.Run(() =>
            {
                var local = MYGBaseDatos.LeerProyecto(ruta, original.Id);
                var vinculoLocal = MYGColaboracionLocal.Leer(ruta, local.Id)
                    ?? throw new InvalidOperationException("La copia existente no tiene un vínculo válido. Consérvela antes de recuperar otra copia.");
                return (Documento: local, Vinculo: vinculoLocal);
            });
            ComprobarClienteActual(cliente);
            documento = recuperado.Documento;
            var vinculo = recuperado.Vinculo;
            SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
            if (vinculo.ProyectoId != remoto.Id) throw new InvalidOperationException("La copia corresponde a otro proyecto remoto.");
            SincronizadorProyectoNube.ActualizarPermisos(vinculo, remoto);
            await Task.Run(() => MYGColaboracionLocal.Guardar(ruta, documento, vinculo));
            ComprobarClienteActual(cliente);
        }
        else
        {
            string preparacion = Path.Combine(carpeta, "preparando-" + Guid.NewGuid().ToString("N") + ".sqlite");
            documento = await Task.Run(() =>
            {
                Directory.CreateDirectory(carpeta);
                PaqueteNube.Descargar(contenidoCargado, preparacion);
                var local = MYGBaseDatos.LeerProyecto(preparacion, original.Id);
                MYGColaboracionLocal.Vincular(preparacion, local, new MYGVinculoNube
                {
                    ProyectoId = remoto.Id, Servidor = servidor, UsuarioId = usuario,
                    Revision = remoto.Revision, Rol = remoto.Rol, PermisosModulos = remoto.PermisosModulos?.Copiar(),
                    JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(local),
                    JsonPaqueteConfirmado = contenidoCargado.GetRawText()
                });
                return local;
            });
            ComprobarClienteActual(cliente);
            File.Move(preparacion, ruta);
        }
        ComprobarClienteActual(cliente);
        var editor = AbrirEditor(documento, ruta);
        editor.ConfigurarNube(() => clienteNube, MostrarNube);
        ventanaNube?.Hide();
        // La copia recuperada conserva borradores: actualizar explícitamente desde su barra.
    }

    private async Task PublicarProyectoNube()
    {
        var cliente = RequerirNube();
        var activo = pestanasProyectos.SelectedTab?.Tag as EditorForm;
        MYGProyectoDocumento? documentoActual = activo?.DocumentoParaPublicar();
        string pendientes = Path.Combine(CarpetaNube, "publicaciones");
        Directory.CreateDirectory(pendientes);
        string ambito = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(cliente.UrlServidor + "\n" + cliente.UsuarioId)));
        string solicitud = Path.Combine(pendientes, ambito + ".json");
        PublicacionPendiente publicacion;
        if (File.Exists(solicitud))
        {
            var opcion = WinForms.MessageBox.Show(ventanaNube, "Hay una publicación sin confirmar. Reintentar conserva su identidad y evita duplicados.",
                "Recuperar publicación", WinForms.MessageBoxButtons.OKCancel);
            if (opcion != WinForms.DialogResult.OK) return;
            ComprobarClienteActual(cliente);
            publicacion = await Task.Run(() => JsonSerializer.Deserialize<PublicacionPendiente>(File.ReadAllText(solicitud))
                ?? throw new InvalidDataException("La solicitud pendiente está dañada. Consérvela para recuperarla."));
            ComprobarClienteActual(cliente);
        }
        else
        {
            using var dialogo = new NubePublicarForm(documentoActual, activo?.RutaProyecto);
            if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
            ComprobarClienteActual(cliente);
            var documento = dialogo.Documento ?? throw new InvalidOperationException("Seleccione un proyecto.");
            string nombre = dialogo.Nombre, alcance = dialogo.Alcance;
            string? origen = dialogo.RutaSQLite;
            string? temporal = string.IsNullOrWhiteSpace(origen)
                ? Path.Combine(pendientes, Guid.NewGuid().ToString("N") + ".sqlite") : null;
            try
            {
                // Preparar una base grande y su JSON no debe bloquear WinForms.
                var contenido = await Task.Run(() =>
                {
                    if (temporal is not null) MYGProyectoStorage.Guardar(temporal, documento);
                    return PaqueteNube.CrearContenido(documento, temporal ?? origen!, alcance);
                });
                ComprobarClienteActual(cliente);
                if (contenido.TryGetProperty("avisos", out var avisos) && avisos.ValueKind == JsonValueKind.Array)
                {
                    string detalle = string.Join(Environment.NewLine, avisos.EnumerateArray().Select(a => a.GetString()));
                    if (!string.IsNullOrWhiteSpace(detalle) && WinForms.MessageBox.Show(ventanaNube,
                        "Revise el alcance antes de publicar:" + Environment.NewLine + Environment.NewLine + detalle,
                        "Publicar en Nube MYG", WinForms.MessageBoxButtons.OKCancel, WinForms.MessageBoxIcon.Information)
                        != WinForms.DialogResult.OK) return;
                }
                ComprobarClienteActual(cliente);
                publicacion = new(Guid.NewGuid(), nombre, alcance, contenido);
                await Task.Run(() =>
                {
                    string archivoTemporal = solicitud + ".tmp";
                    File.WriteAllText(archivoTemporal, JsonSerializer.Serialize(publicacion));
                    File.Move(archivoTemporal, solicitud);
                });
                ComprobarClienteActual(cliente);
            }
            finally { if (temporal is not null && File.Exists(temporal)) File.Delete(temporal); }
        }
        ComprobarClienteActual(cliente);
        var contenidoRed = await Task.Run(() => cliente.PrepararArchivosAsync(publicacion.Contenido, publicacion.Id));
        ComprobarClienteActual(cliente);
        var remoto = await Task.Run(() => cliente.CrearProyectoAsync(publicacion.Id, publicacion.Nombre, contenidoRed, publicacion.Alcance));
        ComprobarClienteActual(cliente);
        File.Delete(solicitud);
        await AbrirProyectoNube(remoto);
    }

    private async Task DescargarProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        using var dialogo = new WinForms.SaveFileDialog
        {
            Title = "Descargar copia independiente confirmada", Filter = "Paquete con recursos (*.zip)|*.zip|Base SQLite (*.sqlite)|*.sqlite",
            FileName = "MYG_NUBE.zip", AddExtension = true, OverwritePrompt = true
        };
        if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
        string destino = dialogo.FileName;
        bool zip = string.Equals(Path.GetExtension(destino), ".zip", StringComparison.OrdinalIgnoreCase);
        Guid proyectoId = seleccionado.Id;
        if (File.Exists(destino)) throw new InvalidOperationException("Elija un nombre nuevo para conservar el archivo existente.");
        ComprobarClienteActual(cliente);
        var remoto = await Task.Run(() => cliente.AbrirProyectoAsync(proyectoId));
        ComprobarClienteActual(cliente);
        JsonElement contenido = remoto.Contenido;
        var contenidoCargado = await Task.Run(() => cliente.CargarArchivosAsync(contenido));
        ComprobarClienteActual(cliente);
        await Task.Run(() => PaqueteNube.Descargar(contenidoCargado, destino, zip));
        ComprobarClienteActual(cliente);
        WinForms.MessageBox.Show(ventanaNube, "Copia independiente descargada desde la revisión " + remoto.Revision + ".",
            "Nube MYG", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information);
    }

    private sealed record PublicacionPendiente(Guid Id, string Nombre, string Alcance, JsonElement Contenido);
}
