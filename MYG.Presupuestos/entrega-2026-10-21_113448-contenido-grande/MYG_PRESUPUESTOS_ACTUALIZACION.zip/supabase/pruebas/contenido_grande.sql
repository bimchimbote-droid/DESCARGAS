-- SOLO PostgreSQL desechable, después de usuarios_myg_roles.sql. Nunca Supabase.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Use scripts/pruebas/Probar-ContenidoGrande.sh; requiere una base desechable.'; end $$;
\endif

-- Un límite de rol previo debe sobrevivir a las dos aplicaciones de la migración.
alter role authenticated set statement_timeout='8s';
create table qa.antes_contenido_grande as select
    (select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p) proyectos,
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h) historial,
    (select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m) miembros,
    (select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from public.myg_nube_operaciones o) operaciones,
    (select jsonb_agg(to_jsonb(i) order by auth_usuario_id) from myg_nube_privado.identidades_verificadas i) identidades,
    (select rolconfig from pg_roles where rolname='authenticated') rolconfig,
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definer',p.prosecdef) order by p.oid)
        from pg_proc p where p.oid in (
            'myg_nube_privado.validar_contenido(jsonb)'::regprocedure,
            'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
            'public.myg_nube_abrir(uuid)'::regprocedure,
            'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure)) atributos,
    (select proconfig from pg_proc where oid='myg_nube_privado.validar_contenido(jsonb)'::regprocedure) configuracion_helper;

\ir ../migraciones/20261021_contenido_grande.sql
\ir ../migraciones/20261021_contenido_grande.sql

select qa.exige((select proyectos=(select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p)
    and historial=(select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h)
    and miembros=(select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m)
    and operaciones=(select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from public.myg_nube_operaciones o)
    and identidades=(select jsonb_agg(to_jsonb(i) order by auth_usuario_id) from myg_nube_privado.identidades_verificadas i)
    from qa.antes_contenido_grande),'Contenido grande: migración repetida conserva obras, historial, miembros, operaciones e identidades');
select qa.exige((select atributos=(select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definer',p.prosecdef) order by p.oid)
    from pg_proc p where p.oid in ('myg_nube_privado.validar_contenido(jsonb)'::regprocedure,
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure))
    and configuracion_helper=(select proconfig from pg_proc where oid='myg_nube_privado.validar_contenido(jsonb)'::regprocedure)
    from qa.antes_contenido_grande),'Contenido grande: conserva propietario, ACL, SECURITY y search_path originales');
select qa.exige((select rolconfig=(select rolconfig from pg_roles where rolname='authenticated')
    from qa.antes_contenido_grande),'Contenido grande: no cambia el timeout de rol authenticated');
select qa.exige((select count(*)=3 from pg_proc p where p.oid in (
    'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,'public.myg_nube_abrir(uuid)'::regprocedure,
    'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure) and 'statement_timeout=120s'=any(p.proconfig)),
    'Contenido grande: plazos de 120 segundos solo en crear, abrir y guardar');

-- Borde exacto del validador: {"x": ""} ocupa nueve bytes en JSONB textual.
select myg_nube_privado.validar_contenido(jsonb_build_object('x',repeat('x',133169152-9)));
select qa.exige(true,'Contenido grande: acepta exactamente 127 MiB de JSONB textual');
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_build_object('x',repeat('x',133169152-8)))$$,
    '22023','Contenido grande: rechaza 127 MiB mas un byte');
select qa.rechaza($$select myg_nube_privado.validar_contenido(null)$$,'22023','Contenido grande: rechaza NULL SQL');
select qa.rechaza($$select myg_nube_privado.validar_contenido('null'::jsonb)$$,'22023','Contenido grande: rechaza null JSON');
select qa.rechaza($$select myg_nube_privado.validar_contenido('[]'::jsonb)$$,'22023','Contenido grande: rechaza array JSON');
select qa.rechaza($$select myg_nube_privado.validar_contenido('5'::jsonb)$$,'22023','Contenido grande: rechaza escalar JSON');

-- Un paquete real generado por MYG, con metadatos sintéticos para superar
-- holgadamente los antiguos 32 MiB. No son archivos ni datos de un usuario.
create table qa.paquetes_grandes(nombre text primary key,contenido jsonb not null);
insert into qa.paquetes_grandes select nombre,contenido||jsonb_build_object('nota_tamano_prueba',repeat('x',50*1024*1024))
    from qa.paquetes where nombre in ('baseline','nombre','cantidad','acu_precio');
grant select on qa.paquetes_grandes to authenticated;
select qa.exige((select min(octet_length(contenido::text))>50*1024*1024
    and max(octet_length(contenido::text))<133169152 from qa.paquetes_grandes),
    'Contenido grande: fixture MYG supera 50 MiB y cabe en el nuevo limite');

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_crear('40000000-0000-0000-0000-000000000001','Obra grande QA',
    (select contenido from qa.paquetes_grandes where nombre='baseline'),'base')->>'revision'='1',
    'Contenido grande: crear paquete mayor de 50 MiB');
select qa.exige(public.myg_nube_abrir('40000000-0000-0000-0000-000000000001')->'contenido'=
    (select contenido from qa.paquetes_grandes where nombre='baseline'),
    'Contenido grande: abrir conserva contenido JSONB completo');
select qa.exige(public.myg_nube_compartir_usuario('40000000-0000-0000-0000-000000000001','editor','editor',
    '{"acu":false,"especificaciones":true,"metrados_excel":true}')='{"estado":"actualizada"}'::jsonb,
    'Contenido grande: propietario conserva administracion de roles y mascaras');
select qa.exige(public.myg_nube_compartir_usuario('40000000-0000-0000-0000-000000000001','lector','lector',
    '{"acu":true,"especificaciones":true,"metrados_excel":true}')='{"estado":"actualizada"}'::jsonb,
    'Contenido grande: agrega lector sin ampliar permisos');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.rechaza($$select public.myg_nube_guardar('40000000-0000-0000-0000-000000000001',
    '50000000-0000-0000-0000-000000000001',1,(select contenido from qa.paquetes_grandes where nombre='nombre'))$$,
    '42501','Contenido grande: lector no puede guardar aunque el paquete sea grande');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_guardar('40000000-0000-0000-0000-000000000001',
    '50000000-0000-0000-0000-000000000002',1,(select contenido from qa.paquetes_grandes where nombre='acu_precio'))$$,
    '42501','Contenido grande: modulo ACU bloqueado conserva validacion del servidor');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_guardar('40000000-0000-0000-0000-000000000001',
    '50000000-0000-0000-0000-000000000003',1,(select contenido from qa.paquetes_grandes where nombre='nombre'))->>'revision'='2',
    'Contenido grande: guardar confirma revision dos');
select qa.exige(public.myg_nube_guardar('40000000-0000-0000-0000-000000000001',
    '50000000-0000-0000-0000-000000000003',1,(select contenido from qa.paquetes_grandes where nombre='nombre'))->>'revision'='2',
    'Contenido grande: replay UUID no aplica otra revision');
select qa.rechaza($$select public.myg_nube_guardar('40000000-0000-0000-0000-000000000001',
    '50000000-0000-0000-0000-000000000003',1,(select contenido from qa.paquetes_grandes where nombre='cantidad'))$$,
    '22023','Contenido grande: UUID reutilizado con otros bytes se rechaza');
select qa.exige(public.myg_nube_guardar('40000000-0000-0000-0000-000000000001',
    '50000000-0000-0000-0000-000000000004',1,(select contenido from qa.paquetes_grandes where nombre='cantidad'))->>'estado'='conflicto',
    'Contenido grande: revision obsoleta produce conflicto sin sobrescribir');
select qa.exige(public.myg_nube_abrir('40000000-0000-0000-0000-000000000001')->'contenido'=
    (select contenido from qa.paquetes_grandes where nombre='nombre'),
    'Contenido grande: conserva contenido confirmado despues de replay y conflicto');
reset role;
select qa.exige((select revision=2 from public.myg_nube_proyectos where id='40000000-0000-0000-0000-000000000001')
    and (select count(*)=2 from public.myg_nube_historial where proyecto_id='40000000-0000-0000-0000-000000000001')
    and (select count(*)=2 from public.myg_nube_operaciones where proyecto_id='40000000-0000-0000-0000-000000000001'),
    'Contenido grande: rechazos, replay y conflicto no duplican historial ni operaciones');
select qa.exige(not has_table_privilege('authenticated','public.myg_nube_proyectos','UPDATE')
    and not has_table_privilege('authenticated','public.myg_nube_miembros','UPDATE'),
    'Contenido grande: mantiene bloqueo de DML directo');

select format('PRUEBAS CONTENIDO GRANDE COMPLETADAS: %s',count(*)) from qa.resultados where descripcion like 'Contenido grande:%';
