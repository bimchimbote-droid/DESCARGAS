-- Paquetes Nube MYG de hasta 127 MiB (133169152 bytes de JSONB textual).
-- Ejecutar completo en SQL Editor como administrador, después de la migración
-- 20261020_usuarios_myg_roles.sql. Es repetible y no modifica tablas ni datos.
-- El cliente actualizado reserva otro MiB para la respuesta RPC (128 MiB).
begin;

do $contenido_grande$
declare
    v_helper record;
    v_despues record;
    v_rpc record;
    v_definicion text;
    v_cuerpo text;
begin
    select p.*, l.lanname into v_helper
    from pg_catalog.pg_proc p join pg_catalog.pg_language l on l.oid=p.prolang
    where p.oid=pg_catalog.to_regprocedure('myg_nube_privado.validar_contenido(jsonb)');
    if not found or v_helper.prokind<>'f' or v_helper.prorettype<>'void'::regtype
       or v_helper.lanname<>'plpgsql' or v_helper.provolatile<>'i'
       or v_helper.proargnames is distinct from array['p_contenido']::text[] then
        raise exception 'Migración cancelada: validar_contenido(jsonb) no tiene la firma compatible esperada.';
    end if;
    -- Reconocer el límite anterior o esta misma actualización. Nunca sustituir
    -- silenciosamente un validador con otro contrato. Se conserva TODO el resto
    -- del cuerpo, sus atributos, search_path, propietario y ACL originales.
    v_cuerpo:=pg_catalog.regexp_replace(v_helper.prosrc,'[[:space:]]','','g');
    if pg_catalog.strpos(v_cuerpo,'p_contenidoisnull')=0
       or pg_catalog.strpos(v_cuerpo,'jsonb_typeof(p_contenido)<>''object''')=0
       or (select count(*) from pg_catalog.regexp_matches(v_cuerpo,
           'octet_length\(p_contenido::text\)>(33554432|133169152)([^0-9]|$)','g'))<>1
       or (pg_catalog.strpos(v_helper.prosrc,'MYG_CONTENIDO_INVALIDO_MAX_32_MIB')=0
           and pg_catalog.strpos(v_helper.prosrc,'MYG_CONTENIDO_INVALIDO_MAX_127_MIB')=0) then
        raise exception 'Migración cancelada: el validador actual no contiene el contrato de objeto JSON y límite 32/127 MiB esperado.';
    end if;
    for v_rpc in select * from (values
        ('public.myg_nube_crear(uuid,text,jsonb,text)'),
        ('public.myg_nube_abrir(uuid)'),
        ('public.myg_nube_guardar(uuid,uuid,bigint,jsonb)')
    ) r(firma) loop
        if not exists(select 1 from pg_catalog.pg_proc p
            where p.oid=pg_catalog.to_regprocedure(v_rpc.firma)
                and p.prokind='f' and p.prosecdef and p.prorettype='jsonb'::regtype) then
            raise exception 'Migración cancelada: falta el RPC SECURITY DEFINER compatible %.',v_rpc.firma;
        end if;
    end loop;

    v_definicion:=pg_catalog.pg_get_functiondef(v_helper.oid);
    v_definicion:=pg_catalog.regexp_replace(v_definicion,
        'octet_length[[:space:]]*\([[:space:]]*p_contenido[[:space:]]*::[[:space:]]*text[[:space:]]*\)[[:space:]]*>[[:space:]]*(33554432|133169152)([^0-9]|$)',
        'octet_length(p_contenido::text) > 133169152\2','g');
    v_definicion:=pg_catalog.replace(v_definicion,
        'MYG_CONTENIDO_INVALIDO_MAX_32_MIB','MYG_CONTENIDO_INVALIDO_MAX_127_MIB');
    execute v_definicion;

    select p.* into v_despues from pg_catalog.pg_proc p where p.oid=v_helper.oid;
    if v_despues.proowner is distinct from v_helper.proowner
       or v_despues.proacl is distinct from v_helper.proacl
       or v_despues.proconfig is distinct from v_helper.proconfig
       or v_despues.prosecdef is distinct from v_helper.prosecdef then
        raise exception 'Migración cancelada: cambiaron atributos protegidos del validador.';
    end if;
end;
$contenido_grande$;

-- Plazos por función para REST/Supabase. No se altera ningún rol, base, política,
-- permiso ni cuerpo de los RPC; se mantienen sus revisiones y UUID idempotentes.
alter function public.myg_nube_crear(uuid,text,jsonb,text) set statement_timeout to '120s';
alter function public.myg_nube_abrir(uuid) set statement_timeout to '120s';
alter function public.myg_nube_guardar(uuid,uuid,bigint,jsonb) set statement_timeout to '120s';

notify pgrst, 'reload schema';
commit;
