using System.Net;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

internal static class PlazosNubeCheck
{
    private static readonly Guid ProyectoId = Guid.Parse("11111111-1111-4111-8111-111111111111");
    private static readonly Guid OperacionId = Guid.Parse("22222222-2222-4222-8222-222222222222");
    private static readonly Guid UsuarioId = Guid.Parse("33333333-3333-4333-8333-333333333333");
    private static readonly JsonElement Contenido = JsonSerializer.SerializeToElement(new { datos = new string('x', 1024 * 1024) });
    private static int comprobaciones;

    public static async Task RunAsync()
    {
        comprobaciones = 0;
        foreach (string funcion in new[] { "crear", "abrir", "guardar" })
        {
            await PlazoDeProyecto(funcion);
            await ProyectoLentoExitoso(funcion);
        }
        await CancelacionExterna();
        await ListadoConPlazoCorto();
        await IngresoConPlazoCorto();
        Console.WriteLine($"OK Plazos de nube: {comprobaciones} comprobaciones; reloj simulado, sin esperas reales ni red.");
    }

    private static void Exige(bool condicion, string mensaje)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Plazos de nube: " + mensaje);
    }

    private static ClienteSupabase Cliente(Transporte transporte, Reloj reloj) =>
        new("https://pruebas.supabase.co", "sb_publishable_pruebas_sin_red", transporte, reloj);

    private static async Task Ingresar(ClienteSupabase cliente)
    {
        await cliente.IniciarSesionAsync("pruebas@myg.example", "contrasena_sintetica");
        Exige(cliente.SesionIniciada && cliente.UsuarioId == UsuarioId.ToString("D"), "no se preparó la sesión sintética.");
    }

    private static async Task Operar(ClienteSupabase cliente, string funcion, CancellationToken ct = default)
    {
        switch (funcion)
        {
            case "crear":
                Exige((await cliente.CrearProyectoAsync(ProyectoId, "Base sintética", Contenido, "base", ct)).Id == ProyectoId,
                    "crear no conservó la identidad confirmada.");
                break;
            case "abrir":
                Exige((await cliente.AbrirProyectoAsync(ProyectoId, ct)).Contenido.GetProperty("datos").GetString()?.Length == 1024 * 1024,
                    "abrir no completó la lectura del contenido grande.");
                break;
            case "guardar":
                Exige((await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 1, Contenido, ct)).OperacionId == OperacionId,
                    "guardar no conservó la operación confirmada.");
                break;
            default: throw new ArgumentOutOfRangeException(nameof(funcion));
        }
    }

    private static async Task PlazoDeProyecto(string funcion)
    {
        var reloj = new Reloj();
        var transporte = new Transporte();
        using var cliente = Cliente(transporte, reloj);
        await Ingresar(cliente);
        var pendiente = transporte.Programar("/rest/v1/rpc/myg_nube_" + funcion);
        Task tarea = Operar(cliente, funcion);
        CancellationToken token = await pendiente.Iniciada.Task.WaitAsync(TimeSpan.FromSeconds(5));
        if (funcion != "abrir") Exige(pendiente.Bytes > 1024 * 1024, funcion + " no envió el contenido grande sintético.");
        reloj.Avanzar(TimeSpan.FromSeconds(41));
        Exige(!token.IsCancellationRequested && !tarea.IsCompleted, funcion + " conserva el límite antiguo de 40 segundos.");
        reloj.Avanzar(TimeSpan.FromSeconds(108));
        Exige(!token.IsCancellationRequested && !tarea.IsCompleted, funcion + " venció antes de los 150 segundos.");
        reloj.Avanzar(TimeSpan.FromSeconds(1));
        Exige(token.IsCancellationRequested, funcion + " no canceló el transporte a los 150 segundos.");
        await EsperarErrorDeConexion(tarea);
        Exige(cliente.SesionIniciada && cliente.UsuarioId == UsuarioId.ToString("D"), funcion + " borró la sesión al agotar el plazo.");
        Exige((await cliente.ListarProyectosAsync()).Count == 0, "el timeout dejó bloqueada la siguiente solicitud.");
    }

    private static async Task ProyectoLentoExitoso(string funcion)
    {
        var reloj = new Reloj();
        var transporte = new Transporte();
        using var cliente = Cliente(transporte, reloj);
        await Ingresar(cliente);
        var pendiente = transporte.Programar("/rest/v1/rpc/myg_nube_" + funcion);
        Task tarea = Operar(cliente, funcion);
        CancellationToken token = await pendiente.Iniciada.Task.WaitAsync(TimeSpan.FromSeconds(5));
        reloj.Avanzar(TimeSpan.FromSeconds(41));
        Exige(!token.IsCancellationRequested, funcion + " no permite completar una respuesta posterior a 40 segundos.");
        pendiente.Completar(RespuestaProyecto(funcion));
        await tarea.WaitAsync(TimeSpan.FromSeconds(5));
        Exige(cliente.SesionIniciada, "una respuesta lenta correcta perdió la sesión.");
    }

    private static async Task CancelacionExterna()
    {
        var reloj = new Reloj();
        var transporte = new Transporte();
        using var cliente = Cliente(transporte, reloj);
        await Ingresar(cliente);
        using var cancelacion = new CancellationTokenSource();
        var pendiente = transporte.Programar("/rest/v1/rpc/myg_nube_guardar");
        Task tarea = Operar(cliente, "guardar", cancelacion.Token);
        CancellationToken token = await pendiente.Iniciada.Task.WaitAsync(TimeSpan.FromSeconds(5));
        reloj.Avanzar(TimeSpan.FromSeconds(41));
        cancelacion.Cancel();
        bool cancelada = false;
        try { await tarea.WaitAsync(TimeSpan.FromSeconds(5)); }
        catch (OperationCanceledException) { cancelada = true; }
        Exige(cancelada && token.IsCancellationRequested, "la cancelación externa se convirtió en un timeout de conexión.");
        Exige(cliente.SesionIniciada && (await cliente.ListarProyectosAsync()).Count == 0,
            "la cancelación externa borró la sesión o dejó la exclusión ocupada.");
    }

    private static async Task ListadoConPlazoCorto()
    {
        var reloj = new Reloj();
        var transporte = new Transporte();
        using var cliente = Cliente(transporte, reloj);
        await Ingresar(cliente);
        var pendiente = transporte.Programar("/rest/v1/rpc/myg_nube_listar");
        Task tarea = cliente.ListarProyectosAsync();
        CancellationToken token = await pendiente.Iniciada.Task.WaitAsync(TimeSpan.FromSeconds(5));
        reloj.Avanzar(TimeSpan.FromSeconds(39));
        Exige(!token.IsCancellationRequested, "el listado venció antes de 40 segundos.");
        reloj.Avanzar(TimeSpan.FromSeconds(1));
        Exige(token.IsCancellationRequested, "el listado recibió indebidamente el plazo largo de proyectos.");
        await EsperarErrorDeConexion(tarea);
        Exige(cliente.SesionIniciada && (await cliente.ListarProyectosAsync()).Count == 0,
            "el plazo corto del listado borró la sesión o impidió reintentar.");
    }

    private static async Task IngresoConPlazoCorto()
    {
        var reloj = new Reloj();
        var transporte = new Transporte();
        using var cliente = Cliente(transporte, reloj);
        var pendiente = transporte.Programar("/auth/v1/token");
        Task tarea = cliente.IniciarSesionAsync("pruebas@myg.example", "contrasena_sintetica");
        CancellationToken token = await pendiente.Iniciada.Task.WaitAsync(TimeSpan.FromSeconds(5));
        reloj.Avanzar(TimeSpan.FromSeconds(39));
        Exige(!token.IsCancellationRequested, "el ingreso venció antes de 40 segundos.");
        reloj.Avanzar(TimeSpan.FromSeconds(1));
        Exige(token.IsCancellationRequested, "el ingreso recibió indebidamente el plazo largo de proyectos.");
        await EsperarErrorDeConexion(tarea);
        Exige(!cliente.SesionIniciada, "el ingreso agotado publicó una sesión inexistente.");
        await Ingresar(cliente);
    }

    private static async Task EsperarErrorDeConexion(Task tarea)
    {
        NubeException? error = null;
        try { await tarea.WaitAsync(TimeSpan.FromSeconds(5)); }
        catch (NubeException ex) { error = ex; }
        Exige(error is { EsErrorDeConexion: true, NecesitaIniciarSesion: false },
            "el plazo agotado no se comunicó como un error de conexión recuperable.");
    }

    private static HttpResponseMessage Json(object valor) => new(HttpStatusCode.OK)
    { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };

    private static HttpResponseMessage RespuestaProyecto(string funcion) => funcion == "guardar"
        ? Json(new { estado = "aplicada", revision = 2, contenido = Contenido, operacion_id = OperacionId })
        : Json(new { id = ProyectoId, codigo = "MYG-PLAZOS", nombre = "Base sintética", rol = "propietario",
            revision = 1, alcance = "base", contenido = Contenido });

    private sealed class Pendiente
    {
        public readonly TaskCompletionSource<CancellationToken> Iniciada = new(TaskCreationOptions.RunContinuationsAsynchronously);
        private readonly TaskCompletionSource<HttpResponseMessage> respuesta = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public int Bytes { get; private set; }
        public async Task<HttpResponseMessage> Enviar(HttpRequestMessage solicitud, CancellationToken ct)
        {
            Bytes = solicitud.Content is null ? 0 : (await solicitud.Content.ReadAsByteArrayAsync(ct)).Length;
            Iniciada.SetResult(ct);
            return await respuesta.Task.WaitAsync(ct);
        }
        public void Completar(HttpResponseMessage valor) => respuesta.SetResult(valor);
    }

    private sealed class Transporte : HttpMessageHandler
    {
        private string? ruta;
        private Pendiente? pendiente;
        public Pendiente Programar(string destino)
        {
            ruta = destino;
            return pendiente = new Pendiente();
        }
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string destino = solicitud.RequestUri!.AbsolutePath;
            if (pendiente is not null && destino == ruta)
            {
                var actual = pendiente; pendiente = null;
                return actual.Enviar(solicitud, ct);
            }
            if (destino == "/auth/v1/token") return Task.FromResult(Json(new
            { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600, user = new { id = UsuarioId } }));
            if (destino == "/rest/v1/rpc/myg_nube_listar") return Task.FromResult(Json(Array.Empty<object>()));
            throw new InvalidOperationException("Ruta inesperada en prueba de plazos: " + destino);
        }
    }

    private sealed class Reloj : TimeProvider
    {
        private readonly object sincronizacion = new();
        private readonly List<Temporizador> temporizadores = new();
        private TimeSpan transcurrido;
        public override DateTimeOffset GetUtcNow() => new DateTimeOffset(2026, 10, 21, 0, 0, 0, TimeSpan.Zero) + transcurrido;
        public override long TimestampFrequency => TimeSpan.TicksPerSecond;
        public override long GetTimestamp() => transcurrido.Ticks;
        public override ITimer CreateTimer(TimerCallback callback, object? state, TimeSpan dueTime, TimeSpan period)
        {
            var temporizador = new Temporizador(this, callback, state);
            lock (sincronizacion) temporizadores.Add(temporizador);
            temporizador.Change(dueTime, period);
            return temporizador;
        }
        public void Avanzar(TimeSpan cantidad)
        {
            if (cantidad < TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(cantidad));
            List<Temporizador> vencidos;
            lock (sincronizacion)
            {
                transcurrido += cantidad;
                vencidos = temporizadores.Where(t => !t.Eliminado && t.Proximo <= transcurrido).ToList();
                foreach (var t in vencidos)
                    t.Proximo = t.Periodo > TimeSpan.Zero ? transcurrido + t.Periodo : TimeSpan.MaxValue;
            }
            foreach (var t in vencidos) t.Disparar();
        }
        private sealed class Temporizador : ITimer
        {
            private readonly Reloj reloj;
            private readonly TimerCallback callback;
            private readonly object? estado;
            internal bool Eliminado;
            internal TimeSpan Proximo = TimeSpan.MaxValue;
            internal TimeSpan Periodo;
            internal Temporizador(Reloj reloj, TimerCallback callback, object? estado)
            { this.reloj = reloj; this.callback = callback; this.estado = estado; }
            public bool Change(TimeSpan dueTime, TimeSpan period)
            {
                lock (reloj.sincronizacion)
                {
                    if (Eliminado) return false;
                    Proximo = dueTime == Timeout.InfiniteTimeSpan ? TimeSpan.MaxValue : reloj.transcurrido + dueTime;
                    Periodo = period;
                    return true;
                }
            }
            internal void Disparar() { if (!Eliminado) callback(estado); }
            public void Dispose() { lock (reloj.sincronizacion) Eliminado = true; }
            public ValueTask DisposeAsync() { Dispose(); return ValueTask.CompletedTask; }
        }
    }
}
