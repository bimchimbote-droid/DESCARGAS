using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class InformacionTareaCheck
{
    private static readonly DateTime Lunes = new(2026, 10, 5);
    private static readonly XNamespace Project = "http://schemas.microsoft.com/project";
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Información de tarea: " + mensaje); }
    private static MYGCronograma Plan() => new() { FechaInicio = Lunes, FechaEstado = Lunes };
    private static MYGTareaCronograma Tarea(MYGCronograma plan, string id, int dias = 2)
    {
        var tarea = new MYGTareaCronograma { Id = id, Nombre = id, DuracionDias = dias };
        plan.Tareas.Add(tarea); return tarea;
    }
    private static MYGResultadoTarea Fila(MYGResultadoCronograma calculado, string id) =>
        calculado.Filas.Single(f => f.Tarea.Id == id);
    private static void Fechas(MYGResultadoCronograma calculado, string id, DateTime inicio, DateTime fin)
    {
        var fila = Fila(calculado, id);
        Exige(fila.Inicio == inicio && fila.Fin == fin,
            $"{id} debe ir del {inicio:dd/MM/yyyy} al {fin:dd/MM/yyyy}; devolvió {fila.Inicio:dd/MM/yyyy}–{fila.Fin:dd/MM/yyyy}.");
    }
    private static void RechazaSinCambiar(object entrada, Action accion, string motivo)
    {
        string antes = Firma(entrada);
        bool rechazada = false;
        try { accion(); }
        catch (InvalidDataException) { rechazada = true; }
        catch (ArgumentException) { rechazada = true; }
        catch (InvalidOperationException) { rechazada = true; }
        Exige(rechazada && Firma(entrada) == antes, motivo + " debe rechazarse sin cambiar la entrada.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Restricciones(pasa);
        ConflictosYCalendario(pasa);
        Reprogramacion(pasa);
        Division(pasa);
        Validacion(pasa);
        CopiaSincronizacionPersistencia(carpeta, pasa);
        Exportacion(carpeta, pasa);
        ReportesYPresentacion(carpeta, pasa);
        Papeles(carpeta, pasa);
        RestriccionNativaDelphin(pasa);
    }

    private static void Restricciones(Action<string> pasa)
    {
        var tipos = Enum.GetValues<MYGTipoRestriccion>();
        Exige(tipos.Length == 8 && tipos.Select(t => (int)t).SequenceEqual(Enumerable.Range(0, 8)) &&
            MYGInformacionTarea.NombresRestricciones.Length == 8 &&
            MYGInformacionTarea.NombresRestricciones.All(n => !string.IsNullOrWhiteSpace(n)) &&
            MYGInformacionTarea.NombresRestricciones.Distinct().Count() == 8,
            "las ocho restricciones deben mantener su identidad y nombres distintos para la selección.");
        var casos = new[]
        {
            (MYGTipoRestriccion.LoAntesPosible, Lunes, Lunes.AddDays(1)),
            (MYGTipoRestriccion.LoMasTardePosible, Lunes.AddDays(3), Lunes.AddDays(4)),
            (MYGTipoRestriccion.NoComenzarAntesDe, Lunes.AddDays(3), Lunes.AddDays(4)),
            (MYGTipoRestriccion.NoComenzarDespuesDe, Lunes, Lunes.AddDays(1)),
            (MYGTipoRestriccion.NoFinalizarAntesDe, Lunes.AddDays(2), Lunes.AddDays(3)),
            (MYGTipoRestriccion.NoFinalizarDespuesDe, Lunes, Lunes.AddDays(1)),
            (MYGTipoRestriccion.DebeComenzarEl, Lunes.AddDays(3), Lunes.AddDays(4)),
            (MYGTipoRestriccion.DebeFinalizarEl, Lunes.AddDays(2), Lunes.AddDays(3))
        };
        foreach (var (tipo, inicio, fin) in casos)
        {
            var plan = Plan(); Tarea(plan, "HORIZONTE", 5);
            var tarea = Tarea(plan, "RESTRINGIDA"); tarea.TipoRestriccion = tipo;
            if ((int)tipo >= 2) tarea.FechaRestriccion = Lunes.AddDays(3);
            string antes = Firma(plan);
            var resultado = MYGMotorCronograma.Calcular(plan);
            Fechas(resultado, tarea.Id, inicio, fin);
            Exige(Firma(plan) == antes && Fila(resultado, tarea.Id).Advertencias.Count == 0,
                "calcular una restricción compatible modificó el plan o generó un conflicto: " + tipo);
        }
        var cadena = Plan(); Tarea(cadena, "HORIZONTE", 5);
        var tarde = Tarea(cadena, "TARDE"); tarde.TipoRestriccion = MYGTipoRestriccion.LoMasTardePosible;
        var sucesora = Tarea(cadena, "SUCESORA", 1);
        sucesora.Predecesoras.Add(new() { PredecesoraId = tarde.Id });
        var final = MYGMotorCronograma.Calcular(cadena);
        Fechas(final, tarde.Id, Lunes.AddDays(2), Lunes.AddDays(3));
        Fechas(final, sucesora.Id, Lunes.AddDays(4), Lunes.AddDays(4));
        Exige(final.Fin == Lunes.AddDays(4), "lo más tarde posible extendió innecesariamente el horizonte de la obra.");

        var limiteCadena = Plan(); Tarea(limiteCadena, "HORIZONTE", 10);
        var antecedente = Tarea(limiteCadena, "TARDE CON LÍMITE"); antecedente.TipoRestriccion = MYGTipoRestriccion.LoMasTardePosible;
        var entrega = Tarea(limiteCadena, "ENTREGA LIMITADA", 1);
        entrega.Predecesoras.Add(new() { PredecesoraId = antecedente.Id });
        entrega.TipoRestriccion = MYGTipoRestriccion.NoFinalizarDespuesDe; entrega.FechaRestriccion = Lunes.AddDays(3);
        var conLimite = MYGMotorCronograma.Calcular(limiteCadena);
        Fechas(conLimite, antecedente.Id, Lunes.AddDays(1), Lunes.AddDays(2));
        Fechas(conLimite, entrega.Id, Lunes.AddDays(3), Lunes.AddDays(3));
        Exige(conLimite.Advertencias.Count == 0,
            "lo más tarde posible debe adelantarse lo necesario para cumplir el límite viable de su sucesora.");
        pasa("Las ocho restricciones programan fechas distintas y coherentes; lo más tarde posible respeta sucesoras y el horizonte sin mutar el plan");
    }

    private static void ConflictosYCalendario(Action<string> pasa)
    {
        foreach (var tipo in new[] { MYGTipoRestriccion.NoComenzarDespuesDe, MYGTipoRestriccion.NoFinalizarDespuesDe })
        {
            var plan = Plan(); Tarea(plan, "PREVIA", 5);
            var limitada = Tarea(plan, "LIMITADA"); limitada.TipoRestriccion = tipo;
            limitada.FechaRestriccion = Lunes.AddDays(2);
            limitada.Predecesoras.Add(new() { PredecesoraId = "PREVIA" });
            var resultado = MYGMotorCronograma.Calcular(plan);
            Fechas(resultado, limitada.Id, Lunes.AddDays(7), Lunes.AddDays(8));
            Exige(Fila(resultado, limitada.Id).Advertencias.Count > 0 && resultado.Advertencias.Count > 0,
                "un límite imposible debe respetar la predecesora y avisar el conflicto: " + tipo);
        }
        foreach (var tipo in new[] { MYGTipoRestriccion.DebeComenzarEl, MYGTipoRestriccion.DebeFinalizarEl })
        {
            var plan = Plan(); Tarea(plan, "PREVIA", 5);
            var fija = Tarea(plan, "FIJA"); fija.TipoRestriccion = tipo; fija.FechaRestriccion = Lunes.AddDays(2);
            fija.Predecesoras.Add(new() { PredecesoraId = "PREVIA" });
            var resultado = MYGMotorCronograma.Calcular(plan);
            Exige((tipo == MYGTipoRestriccion.DebeComenzarEl ? Fila(resultado, fija.Id).Inicio : Fila(resultado, fija.Id).Fin) == Lunes.AddDays(2) &&
                Fila(resultado, fija.Id).Advertencias.Count > 0,
                "una fecha obligatoria debe conservarse y advertir la dependencia incompatible: " + tipo);
        }
        var calendario = Plan(); calendario.Calendario.Feriados.Add(Lunes.AddDays(7));
        var despues = Tarea(calendario, "DESDE SÁBADO");
        despues.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; despues.FechaRestriccion = Lunes.AddDays(5);
        Fechas(MYGMotorCronograma.Calcular(calendario), despues.Id, Lunes.AddDays(8), Lunes.AddDays(9));
        var hasta = Tarea(calendario, "HASTA SÁBADO"); hasta.TipoRestriccion = MYGTipoRestriccion.DebeFinalizarEl;
        hasta.FechaRestriccion = Lunes.AddDays(4);
        Fechas(MYGMotorCronograma.Calcular(calendario), hasta.Id, Lunes.AddDays(3), Lunes.AddDays(4));

        foreach (var tipo in new[] { MYGTipoRestriccion.DebeComenzarEl, MYGTipoRestriccion.DebeFinalizarEl })
        {
            var plan = Plan(); var fija = Tarea(plan, "FECHA FIJA INHÁBIL");
            fija.TipoRestriccion = tipo; fija.FechaRestriccion = Lunes.AddDays(5);
            string antes = Firma(plan); var resultado = MYGMotorCronograma.Calcular(plan);
            var fila = Fila(resultado, fija.Id);
            Exige((tipo == MYGTipoRestriccion.DebeComenzarEl ? fila.Inicio : fila.Fin) == Lunes.AddDays(5) &&
                fila.Advertencias.Any(a => a.Contains("no laborable", StringComparison.OrdinalIgnoreCase)) && Firma(plan) == antes,
                "una fecha exacta del sábado debe conservarse y explicar el conflicto de calendario.");
        }
        var horizonteSabado = Plan(); var fijaSabado = Tarea(horizonteSabado, "FIN CONTRACTUAL");
        fijaSabado.TipoRestriccion = MYGTipoRestriccion.DebeFinalizarEl; fijaSabado.FechaRestriccion = Lunes.AddDays(5);
        Tarea(horizonteSabado, "TARDE ANTES DEL SÁBADO", 1).TipoRestriccion = MYGTipoRestriccion.LoMasTardePosible;
        Fechas(MYGMotorCronograma.Calcular(horizonteSabado), "TARDE ANTES DEL SÁBADO", Lunes.AddDays(4), Lunes.AddDays(4));
        foreach (var tipo in new[] { MYGTipoRestriccion.NoComenzarDespuesDe, MYGTipoRestriccion.NoFinalizarDespuesDe })
        {
            var plan = Plan(); var anterior = Tarea(plan, "LÍMITE ANTES DE LA OBRA");
            anterior.TipoRestriccion = tipo; anterior.FechaRestriccion = Lunes.AddDays(-3);
            var resultado = MYGMotorCronograma.Calcular(plan);
            Fechas(resultado, anterior.Id, Lunes, Lunes.AddDays(1));
            Exige(Fila(resultado, anterior.Id).Advertencias.Count > 0,
                "un límite anterior a la obra debe advertirse sin adelantar el comienzo del proyecto.");
        }
        var manual = Plan(); var manualRestringida = Tarea(manual, "MANUAL RESTRINGIDA");
        manualRestringida.Modo = MYGModoTarea.Manual; manualRestringida.InicioManual = Lunes.AddDays(1);
        manualRestringida.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; manualRestringida.FechaRestriccion = Lunes.AddDays(3);
        var calculoManual = MYGMotorCronograma.Calcular(manual);
        Fechas(calculoManual, manualRestringida.Id, Lunes.AddDays(1), Lunes.AddDays(2));
        Exige(Fila(calculoManual, manualRestringida.Id).Advertencias.Count > 0,
            "una restricción incumplida debe advertirse conservando la fecha manual.");
        pasa("Restricciones incompatibles emiten advertencias útiles, conservan las fechas obligatorias y aplican fines de semana y feriados");
    }

    private static void Reprogramacion(Action<string> pasa)
    {
        var tarea = new MYGTareaCronograma { DuracionDias = 10, NumeroCuadrillas = 1.5m, CuadrillasIniciales = 1.5m };
        MYGInformacionTarea.Reprogramar(tarea, 5);
        Exige(tarea.Reprogramada && tarea.DuracionInicialDias == 10 && tarea.CuadrillasIniciales == 1.5m &&
            tarea.DuracionDias == 5 && tarea.NumeroCuadrillas == 3,
            "reducir a la mitad el plazo debe duplicar las cuadrillas y conservar la programación inicial.");
        MYGInformacionTarea.Reprogramar(tarea, 4);
        Exige(tarea.DuracionInicialDias == 10 && tarea.CuadrillasIniciales == 1.5m &&
            tarea.DuracionDias == 4 && tarea.NumeroCuadrillas == 3.75m,
            "una segunda reprogramación debe usar las diez jornadas originales y admitir cuadrillas fraccionarias.");
        MYGInformacionTarea.Dividir(tarea, 2, 1, 25);
        MYGInformacionTarea.Reprogramar(tarea, 8);
        Exige(tarea.Partes.Count == 0 && tarea.NumeroCuadrillas == 1.875m && tarea.DuracionInicialDias == 10,
            "cambiar la duración debe eliminar una división obsoleta sin reemplazar la duración inicial.");
        var hito = new MYGTareaCronograma { DuracionDias = 0, NumeroCuadrillas = 2, CuadrillasIniciales = 2 };
        MYGInformacionTarea.Reprogramar(hito, 0);
        Exige(hito.DuracionDias == 0 && hito.NumeroCuadrillas == 2, "reprogramar un hito debe evitar dividir entre cero.");
        pasa("Reprogramación conserva duración y cuadrillas iniciales, recalcula cuadrillas sin acumulación de redondeos y limpia divisiones obsoletas");
    }

    private static void Division(Action<string> pasa)
    {
        var plan = Plan(); var partida = Tarea(plan, "DIVIDIDA", 5);
        MYGInformacionTarea.Dividir(partida, 3, 2, 10);
        Exige(partida.DuracionDias == 5 && partida.Partes.Count == 3 &&
            partida.Partes.Sum(p => p.DuracionDias) == 5 && partida.Partes.Sum(p => p.Cantidad) == 10 &&
            partida.Partes.Sum(p => p.Porcentaje) == 100 && partida.Partes[0].DesfaseInicioDias == 0 &&
            partida.Partes.Zip(partida.Partes.Skip(1), (a, b) =>
                b.DesfaseInicioDias == a.DesfaseInicioDias + a.DuracionDias + 2).All(v => v),
            "dividir debe conservar trabajo, cantidad y 100 %, y separar cada parte por dos jornadas.");
        var sucesora = Tarea(plan, "DESPUÉS", 1); sucesora.Predecesoras.Add(new() { PredecesoraId = partida.Id });
        var paralela = Tarea(plan, "PARALELA", 2);
        string antes = Firma(plan); var resultado = MYGMotorCronograma.Calcular(plan);
        Fechas(resultado, partida.Id, Lunes, Lunes.AddDays(10));
        Fechas(resultado, sucesora.Id, Lunes.AddDays(11), Lunes.AddDays(11));
        Exige(Fila(resultado, partida.Id).DuracionDias == 5 && Fila(resultado, partida.Id).DiasCalendario == 11 &&
            Fila(resultado, paralela.Id).HolguraDias == 8 && Fila(resultado, partida.Id).HolguraDias == 0 && Firma(plan) == antes,
            "las pausas deben extender el fin y las precedencias/holguras sin aumentar la duración activa ni cambiar el plan.");
        var cien = new MYGTareaCronograma { DuracionDias = 7 };
        MYGInformacionTarea.Dividir(cien, 7, 0, .01m);
        Exige(cien.Partes.All(p => p.DuracionDias == 1 && p.Cantidad >= 0 && p.Porcentaje >= 0) &&
            cien.Partes.Sum(p => p.Cantidad) == .01m && cien.Partes.Sum(p => p.Porcentaje) == 100,
            "la distribución debe reconciliar cantidades pequeñas y porcentajes periódicos exactamente.");
        pasa("División conserva trabajo, metrado y 100 % exactos; sus pausas modifican fin, sucesoras y holguras sin alterar el origen");
    }

    private static void Validacion(Action<string> pasa)
    {
        var tarea = new MYGTareaCronograma { DuracionDias = 5 };
        foreach (int nueva in new[] { -1, 36501 })
            RechazaSinCambiar(tarea, () => MYGInformacionTarea.Reprogramar(tarea, nueva), "una duración reprogramada fuera de rango");
        foreach (var caso in new[] { (0, 1, 1m), (6, 1, 1m), (2, -1, 1m), (2, 1, -1m) })
            RechazaSinCambiar(tarea, () => MYGInformacionTarea.Dividir(tarea, caso.Item1, caso.Item2, caso.Item3), "una división inválida");
        var hito = new MYGTareaCronograma { DuracionDias = 0 };
        RechazaSinCambiar(hito, () => MYGInformacionTarea.Dividir(hito, 2, 0, 1), "dividir un hito");
        foreach (var tipo in Enum.GetValues<MYGTipoRestriccion>().Where(t => (int)t >= 2))
        {
            var plan = Plan(); Tarea(plan, "SIN FECHA").TipoRestriccion = tipo;
            RechazaSinCambiar(plan, () => MYGMotorCronograma.Validar(plan), "una restricción fechada sin fecha");
        }
        var invalido = Plan(); var hoja = Tarea(invalido, "INVÁLIDA"); hoja.TipoRestriccion = (MYGTipoRestriccion)99;
        RechazaSinCambiar(invalido, () => MYGMotorCronograma.Validar(invalido), "una restricción desconocida");
        hoja.TipoRestriccion = MYGTipoRestriccion.LoAntesPosible; hoja.NumeroCuadrillas = 0;
        RechazaSinCambiar(invalido, () => MYGMotorCronograma.Validar(invalido), "cero cuadrillas");
        hoja.NumeroCuadrillas = 1; MYGInformacionTarea.Dividir(hoja, 2, 0, 1);
        hoja.Partes[1].DesfaseInicioDias = 0;
        RechazaSinCambiar(invalido, () => MYGMotorCronograma.Validar(invalido), "partes solapadas");
        pasa("Validaciones rechazan restricciones sin fecha, cuadrillas inválidas, duraciones imposibles y divisiones inconsistentes de forma atómica");
    }

    private static void CopiaSincronizacionPersistencia(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Información de tarea persistente");
        var presupuesto = documento.Presupuestos[0];
        var partida = new ItemPresupuestoDelphin { Id = "PARTIDA", IdLocalMYG = "PARTIDA", Item = "01",
            Descripcion = "Partida de origen", Unidad = "m3", TipoPropuesta = "PARTIDA" };
        partida.Costos.Cantidad = 17.5m; partida.Costos.PrecioDirecto = 3; presupuesto.Items.Add(partida);
        documento.Datos = new MYGDatosProyecto { FechaInicio = Lunes };
        var plan = documento.Cronograma = MYGMotorCronograma.CrearDesdePresupuestos(documento);
        var tarea = plan.Tareas.Single(t => !t.EsResumen); tarea.DuracionDias = 10;
        tarea.CuadrillasIniciales = tarea.NumeroCuadrillas = 2;
        MYGInformacionTarea.Reprogramar(tarea, 5); MYGInformacionTarea.Dividir(tarea, 3, 1, 17.5m);
        tarea.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; tarea.FechaRestriccion = Lunes.AddDays(2);
        tarea.Notas = "Notas con ñ"; tarea.Responsables.Add("ING. PÉREZ");
        plan.OpcionesVista["Presentacion"] = "{\"Barras\":\"continuas\"}";
        string firma = Firma(plan); var copia = MYGProyectoStorage.Copia(plan);
        Exige(Firma(copia) == firma && !ReferenceEquals(copia.Tareas.Single(t => t.Id == tarea.Id).Partes, tarea.Partes),
            "la copia del historial debe conservar información de tarea con listas independientes.");
        copia.Tareas.Single(t => t.Id == tarea.Id).Partes[0].Cantidad = 999;
        copia.OpcionesVista["Presentacion"] = "otra";
        Exige(Firma(plan) == firma, "editar o cancelar una copia cambió las partes o presentación originales.");
        string tareaAntes = Firma(tarea), presupuestoAntes = Firma(presupuesto);
        MYGMotorCronograma.SincronizarPresupuestos(documento, plan);
        Exige(Firma(plan.Tareas.Single(t => t.Id == tarea.Id)) == tareaAntes && Firma(presupuesto) == presupuestoAntes &&
            plan.OpcionesVista["Presentacion"] == "{\"Barras\":\"continuas\"}",
            "sincronizar debe preservar restricciones, cuadrillas, partes y preferencias sin modificar los metrados.");
        var otra = MYGMotorCronograma.AgregarTarea(plan, null, "Control posterior");
        MYGMotorCronograma.Vincular(plan, new[] { tarea.Id, otra.Id });
        Exige(Firma(plan.Tareas.Single(t => t.Id == tarea.Id)) == tareaAntes &&
            plan.OpcionesVista["Presentacion"] == "{\"Barras\":\"continuas\"}",
            "vincular debe conservar la información y presentación previamente guardadas.");
        firma = Firma(plan);
        foreach (string extension in new[] { ".myg.json", ".sqlite" })
        {
            string ruta = Path.Combine(carpeta, "Información de tarea" + extension);
            MYGProyectoStorage.Guardar(ruta, documento); var leido = MYGProyectoStorage.Leer(ruta);
            Exige(Firma(leido.Cronograma) == firma && Firma(leido.Presupuestos) == Firma(documento.Presupuestos),
                "guardar y reabrir " + extension + " debe conservar restricciones, cuadrillas, partes, presentación y presupuesto.");
        }
        pasa("Copias, sincronización, vínculos y reapertura JSON/SQLite conservan información de tarea y presentación con historial independiente");
    }

    private static void Exportacion(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Restricciones Project"); var plan = Plan();
        int[] tiposProject = { 0, 1, 4, 5, 6, 7, 2, 3 };
        foreach (var tipo in Enum.GetValues<MYGTipoRestriccion>())
        {
            var tarea = Tarea(plan, "TIPO " + (int)tipo); tarea.TipoRestriccion = tipo;
            if ((int)tipo >= 2) tarea.FechaRestriccion = Lunes.AddDays(3);
        }
        string antes = Firma(plan); var modelo = MYGExportacionCronograma.PrepararProject(documento, plan, false);
        string ruta = Path.Combine(carpeta, "Restricciones Project.xml");
        MYGExportacionCronograma.Guardar(ruta, documento, plan, MYGFormatoExportacionCronograma.XmlTareas);
        var xml = XDocument.Load(ruta);
        foreach (var tarea in plan.Tareas)
        {
            int indice = (int)tarea.TipoRestriccion;
            var exportada = modelo.Tareas.Single(t => t.IdMYG == tarea.Id);
            var nodo = xml.Root.Element(Project + "Tasks").Elements(Project + "Task")
                .Single(t => (string)t.Element(Project + "Name") == tarea.Nombre);
            Exige(exportada.TipoRestriccion == tarea.TipoRestriccion && exportada.TipoRestriccionProject == tiposProject[indice] &&
                (int)nodo.Element(Project + "ConstraintType") == tiposProject[indice],
                "el modelo y XML deben usar la identidad nativa de Project para " + tarea.TipoRestriccion);
            if (indice >= 2)
            {
                int hora = indice is 4 or 5 or 7 ? 17 : 8;
                var fecha = Lunes.AddDays(3).AddHours(hora);
                Exige(exportada.FechaRestriccion == fecha && (DateTime)nodo.Element(Project + "ConstraintDate") == fecha,
                    "Project debe conservar la fecha y hora de comienzo/fin correspondiente a " + tarea.TipoRestriccion);
            }
        }
        Exige(Firma(plan) == antes, "exportar restricciones modificó el cronograma original.");
        pasa("Modelo y XML Project conservan las ocho restricciones con su código nativo y la hora de inicio o fin correcta sin mutar el origen");

        var dividido = Plan(); var partida = Tarea(dividido, "PARTES", 5);
        MYGInformacionTarea.Dividir(partida, 3, 2, 10);
        var modeloPartes = MYGExportacionCronograma.PrepararProject(documento, dividido, false);
        var tareaPartes = modeloPartes.Tareas.Single();
        var tramos = modeloPartes.TramosPorTarea[tareaPartes.Uid];
        Exige(tareaPartes.DuracionMinutos == 5 * 8 * 60 && tareaPartes.Fin == Lunes.AddDays(10).AddHours(17) &&
            tramos.Count == 3 && tramos[0].Inicio == Lunes.AddHours(8) && tramos[0].Fin == Lunes.AddDays(1).AddHours(17) &&
            tramos[1].Inicio == Lunes.AddDays(4).AddHours(8) && tramos[1].Fin == Lunes.AddDays(7).AddHours(17) &&
            tramos[2].Inicio == Lunes.AddDays(10).AddHours(8) && tramos[2].Fin == Lunes.AddDays(10).AddHours(17) &&
            tramos.Sum(t => t.Cantidad ?? 0) == 10 && tramos.Sum(t => t.Porcentaje ?? 0) == 100,
            "Project debe exportar sólo cinco jornadas activas, las pausas y extremos reales, con cantidad y porcentaje por tramo.");
        string rutaPartes = Path.Combine(carpeta, "Partes Project.xml");
        MYGExportacionCronograma.Guardar(rutaPartes, documento, dividido, MYGFormatoExportacionCronograma.XmlTareas);
        var nodoPartes = XDocument.Load(rutaPartes).Root.Element(Project + "Tasks").Elements(Project + "Task").Single();
        string notas = (string)nodoPartes.Element(Project + "Notes");
        Exige(notas.Contains("Partes de tarea MYG:", StringComparison.Ordinal) &&
            notas.Contains("XML de Project no representa estas pausas", StringComparison.Ordinal) &&
            notas.Contains("2026-10-15", StringComparison.Ordinal),
            "XML debe describir todas las partes y explicar su limitación al conservar pausas para que puedan revisarse.");
        pasa("Project conserva duración activa, calendario, pausas y distribución de cantidad y porcentaje de las partes");
    }

    private static void ReportesYPresentacion(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Reportes por partes"); var presupuesto = documento.Presupuestos[0];
        var recurso = new MYGInsumo { Id = "MATERIAL", Codigo = "01", Descripcion = "Material por partes", Unidad = "m3",
            Grupo = MYGGrupoRecurso.Materiales, Precio = 10 };
        presupuesto.Costos.Insumos.Add(recurso);
        var partida = new ItemPresupuestoDelphin { Id = "PARTIDA", IdLocalMYG = "PARTIDA", Item = "01",
            Descripcion = "Partida enero marzo", TipoPropuesta = "PARTIDA", Unidad = "m3" };
        partida.Costos.Cantidad = 10;
        partida.Costos.Analisis.Add(new() { InsumoId = recurso.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 });
        presupuesto.Items.Add(partida);
        var enero = new DateTime(2026, 1, 5);
        var plan = new MYGCronograma { FechaInicio = enero, FechaEstado = enero };
        plan.Tareas.Add(new() { Id = "PARTIDA", Nombre = partida.Descripcion, DuracionDias = 10, Avance = 50,
            PresupuestoId = presupuesto.Id, PartidaId = partida.Id, Partes = new()
            {
                new() { DesfaseInicioDias = 0, DuracionDias = 5, Cantidad = 2.5m, Porcentaje = 25 },
                new() { DesfaseInicioDias = 40, DuracionDias = 5, Cantidad = 7.5m, Porcentaje = 75 }
            } });
        string antes = Firma(plan), presupuestoAntes = Firma(documento.Presupuestos);
        var gantt = MYGReportesCronograma.Crear(documento, plan);
        var barras = gantt.SelectMany(r => r.Hoja.Celdas.Where(c =>
            MYGHojaCalculo.Coordenadas(c.Key).Fila == 3 && MYGHojaCalculo.Coordenadas(c.Key).Columna >= 13))
            .Where(c => !string.IsNullOrWhiteSpace(c.Value.Contenido)).ToArray();
        Exige(barras.Length == 2 && barras.Count(c => c.Value.Contenido.Contains('▓')) == 1 &&
            barras.Count(c => c.Value.Contenido.Contains('░')) == 1 && gantt[0].Hoja.Celdas["N3"].Contenido == "",
            "el Gantt debe dibujar las semanas de trabajo y avance, dejando vacías las semanas de pausa entre enero y marzo.");
        var valorizado = MYGReportesCronograma.CrearValorizado(documento, plan).Single().Hoja;
        var valor = new MYGHojaCalculo(valorizado);
        int filaValorizada = valorizado.Celdas.Where(c => c.Value.Contenido == partida.Descripcion)
            .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();
        Exige(valor.Numero("F" + filaValorizada) == 200 && valor.Numero("G" + filaValorizada) == 50 && valor.Numero("H" + filaValorizada) == 0 && valor.Numero("I" + filaValorizada) == 150 &&
            valor.Numero(valorizado.CeldaTotal) == 200,
            "el valorizado debe repartir S/200 al 25/75 en enero/marzo sin cargos en febrero y conservar el total.");
        var adquisiciones = MYGReportesCronograma.CrearAdquisiciones(documento, plan).Single().Hoja;
        var compra = new MYGHojaCalculo(adquisiciones);
        int filaCompra = adquisiciones.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == 3 && c.Value.Contenido == recurso.Descripcion)
            .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();
        Exige(compra.Numero("F" + filaCompra) == 20 && compra.Numero("H" + filaCompra) == 200 && compra.Numero("I" + filaCompra) == 5 &&
            compra.Numero("J" + filaCompra) == 0 && compra.Numero("K" + filaCompra) == 15 && compra.Numero(adquisiciones.CeldaTotal) == 200,
            "adquisiciones debe programar 5 y 15 unidades al comienzo de las partes y conservar 20 unidades/S200 sin compras durante la pausa.");
        Exige(Firma(plan) == antes && Firma(documento.Presupuestos) == presupuestoAntes,
            "crear reportes con pausas modificó la planificación o el ACU.");
        plan.OpcionesVista["Presentacion"] = JsonSerializer.Serialize(new
        {
            ImprimirLeyenda = false, Horizontal = false, Papel = "B5", ColorCriticaArgb = unchecked((int)0xFF123456),
            ColorAvanceArgb = unchecked((int)0xFF654321), OcultarAvance = false,
            InicioImpresion = enero, FinImpresion = enero.AddDays(20), ImprimirInformacionPagina = true,
            TipoInformacionPagina = "Número del total", TituloPagina = "CONTROL DE OBRA"
        });
        antes = Firma(plan);
        var conOpciones = MYGReportesCronograma.Crear(documento, plan).Single().Hoja;
        Exige(conOpciones.TamanoPapel == "B5" && conOpciones.OrientacionPagina == "Vertical" && conOpciones.Columnas == 15 &&
            conOpciones.Celdas["M3"].ColorTexto == "654321" &&
            !conOpciones.Celdas.Values.Any(c => c.Contenido.Contains("Leyenda:", StringComparison.Ordinal)) &&
            conOpciones.Celdas.Values.Any(c => c.Contenido.Contains("CONTROL DE OBRA", StringComparison.Ordinal) && c.Contenido.Contains("1 de 1", StringComparison.Ordinal)) &&
            Firma(plan) == antes && Firma(documento.Presupuestos) == presupuestoAntes,
            "la presentación debe aplicar rango, B5 vertical, color de avance, leyenda y pie de página sin alterar el proyecto.");
        plan.OpcionesVista["Presentacion"] = plan.OpcionesVista["Presentacion"].Replace("\"OcultarAvance\":false", "\"OcultarAvance\":true", StringComparison.Ordinal);
        var sinAvance = MYGReportesCronograma.Crear(documento, plan).Single().Hoja;
        Exige(sinAvance.Celdas["M3"].ColorTexto == "123456" && !sinAvance.Celdas["M3"].Contenido.Contains('▓'),
            "ocultar avance debe mantener la barra planificada con el color crítico configurado.");
        pasa("Gantt, valorizado y adquisiciones respetan las pausas y porcentajes; presentación aplica rango, colores, papel, leyenda y pie sin mutar datos");
    }

    private static void Papeles(string carpeta, Action<string> pasa)
    {
        var nombres = new[] { "A4", "A3", "A2", "A5", "A6", "B4", "B5", "Carta", "Oficio" };
        Exige(MYGPapelReporte.Nombres.SequenceEqual(nombres) && MYGPapelReporte.DimensionesMm("A2") == (420m, 594m) &&
            MYGPapelReporte.DimensionesMm("B5") == (176m, 250m) && !MYGPapelReporte.EsValido("PAPEL INVENTADO"),
            "el catálogo debe ofrecer los nueve papeles reales y sus dimensiones físicas.");
        var hojas = new List<MYGHojaMetrado>();
        foreach (string papel in nombres)
        {
            var hoja = new MYGHojaMetrado { Nombre = papel, Filas = 2, Columnas = 2, CeldaTotal = "B2", AreaImpresion = "A1:B2" };
            hoja.Poner("A1", papel); hoja.Poner("B2", "17"); string original = Firma(hoja);
            var vista = new MYGConfiguracionVistaReporte(new[] { new MYGHojaReporteProyecto(papel, hoja) });
            vista.ConfigurarPagina(papel, "Vertical", .2m, .2m, .2m, .2m);
            Exige(Firma(hoja) == original && vista.Reportes.Single().Hoja.TamanoPapel == papel,
                "configurar " + papel + " debe aplicarse a una copia independiente del informe.");
            hojas.Add(vista.Reportes.Single().Hoja);
        }
        string ruta = Path.Combine(carpeta, "Papeles de información de tarea.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        foreach (string papel in nombres)
        {
            var leida = MYGExcelPresupuestos.Importar(ruta, papel, "A1");
            Exige(leida.TamanoPapel == papel && leida.OrientacionPagina == "Vertical" && new MYGHojaCalculo(leida).Numero("B2") == 17,
                "guardar y abrir XLSX debe conservar papel " + papel + ", orientación y datos.");
        }
        pasa("Los nueve tamaños de papel se configuran en copias y se conservan al guardar/reabrir XLSX");
    }

    private static void RestriccionNativaDelphin(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Restricción Delphin sin correspondencia documentada");
        documento.Datos = new() { FechaInicio = Lunes };
        var presupuesto = documento.Presupuestos[0];
        var partida = new ItemPresupuestoDelphin { Id = "CU-A", IdLocalMYG = "CU-A", IdInternoDelphin = "CU-A",
            Descripcion = "Restricción nativa", Unidad = "und", TipoPropuesta = "PARTIDA", Item = "01" };
        partida.Costos.Cantidad = 1; presupuesto.Items.Add(partida);
        string antes = Firma(documento);
        SQLiteDependencyBootstrapper.Initialize();
        using var conexion = new SqliteConnection("Data Source=:memory:"); conexion.Open();
        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,task_mode INTEGER,
                    fecha_inicio TEXT,fecha_fin TEXT,tipo_restriccion INTEGER,fecha_restriccion TEXT);
                INSERT INTO costo_unitario VALUES('CU-A',2,1,'2026-10-08','2026-10-09',6,'2026-10-05');
                """;
            comando.ExecuteNonQuery();
        }
        var plan = DelphinCronogramaMYG.Leer(conexion, documento);
        var tarea = plan.Tareas.Single(t => !t.EsResumen);
        var calculado = MYGMotorCronograma.Calcular(plan);
        Fechas(calculado, tarea.Id, Lunes.AddDays(3), Lunes.AddDays(4));
        Exige(tarea.TipoRestriccion == MYGTipoRestriccion.LoAntesPosible && tarea.FechaRestriccion == null &&
            plan.AdvertenciasImportacion.Any(a => a.Contains("restricción nativa", StringComparison.OrdinalIgnoreCase)) &&
            tarea.FechasImportadasDelphin != null && Firma(documento) == antes,
            "importar una restricción Delphin sin código documentado debe conservar las fechas, advertir su alcance y evitar traducirla por coincidencia numérica.");
        pasa("Las restricciones nativas Delphin sin correspondencia documentada conservan sus fechas y generan un aviso sin modificar el documento");
    }
}
