using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Xml.Linq;
using System.Linq;
using System.Text.Json;
using MYG_2027;

static class ReportesCronogramaCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object o) => JsonSerializer.Serialize(o);
    private static string Ver(MYGHojaMetrado h, string direccion) => new MYGHojaCalculo(h).Mostrar(direccion);
    private static int Buscar(MYGHojaMetrado h, int columna, string contenido) => h.Celdas.Keys
        .Where(d => MYGHojaCalculo.Coordenadas(d).Columna == columna && Ver(h, d).Contains(contenido, StringComparison.Ordinal))
        .Select(d => MYGHojaCalculo.Coordenadas(d).Fila).Single();
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new Exception("El calendario financiero aceptó una partida ajena o duplicada.");
    }
    private static MYGCronograma Plan() => new()
    {
        FechaInicio = new DateTime(2026, 1, 30), FechaEstado = new DateTime(2026, 2, 3),
        Calendario = new() { Feriados = new() { new DateTime(2026, 2, 2) } }
    };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("OBRA GANTT QA");
        documento.Datos = new() { Propietario = "PROPIETARIO QA", Departamento = "ÁNCASH", Provincia = "SANTA", Distrito = "CHIMBOTE" };
        var plan = Plan();
        plan.Tareas.Add(new() { Id = "RESUMEN", Nombre = "RESUMEN QA", EsResumen = true });
        plan.Tareas.Add(new() { Id = "A", PadreId = "RESUMEN", Codigo = "0001", Nombre = "=TAREA \"LITERAL\", QA", DuracionDias = 3, Avance = 50, Notas = "@NOTA SEGURA" });
        plan.Tareas.Add(new() { Id = "B", PadreId = "RESUMEN", Codigo = "0002", Nombre = "HITO QA", DuracionDias = 0,
            Predecesoras = new() { new() { PredecesoraId = "A" } } });
        MYGMotorCronograma.EstablecerLineaBase(plan);
        plan.Tareas.Single(t => t.Id == "A").DuracionDias = 5;
        string antes = Firma(documento), planAntes = Firma(plan);
        var informes = MYGReportesCronograma.Crear(documento, plan);
        var reporte = informes.Single(); var h = reporte.Hoja; var motor = new MYGHojaCalculo(h);
        int a = Buscar(h, 3, "=TAREA"), b = Buscar(h, 3, "HITO QA"), resumen = Buscar(h, 3, "RESUMEN QA");
        Exige(h.TamanoPapel == "A3" && h.OrientacionPagina == "Horizontal" && h.RepetirTitulos && h.FilasInmovilizadas == 2 &&
            h.Columnas >= 13 && h.Columnas <= 20 && h.AnchosColumnas.Values.Sum() < 1500 &&
            Ver(h, "C" + a).Contains("0001 =TAREA \"LITERAL\", QA", StringComparison.Ordinal) &&
            motor.Numero("I" + a) == 50 && motor.Numero("E" + a) == 5 &&
            Ver(h, "K" + a) == "30/01/2026" && Ver(h, "L" + a) == "04/02/2026" &&
            Ver(h, "H" + b) == "2FC" && h.Celdas["C" + resumen].Negrita &&
            h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == b).Any(c => c.Value.Contenido.Contains('◆')) &&
            h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == a).Any(c => c.Value.Contenido.Contains('▓')) &&
            h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == a).Any(c => c.Value.Contenido.Contains('―')) &&
            reporte.DatosProyecto.Any(d => d.Key == "Proyecto" && d.Value == documento.Nombre) &&
            reporte.DatosProyecto.Any(d => d.Key == "Fecha de estado" && d.Value == "03/02/2026") &&
            Firma(documento) == antes && Firma(plan) == planAntes,
            "El informe Gantt perdió escala, jerarquía, hitos, avance, vínculos, línea base o aislamiento de los datos.");
        foreach (var informe in informes) MYGHojaCalculo.Validar(informe.Hoja);
        pasa("Gantt imprimible A3 conserva jerarquía, hitos, avance, predecesoras, línea base y cabecera sin modificar presupuesto ni planificación");

        string csvRuta = Path.Combine(carpeta, "Cronograma seguro.csv");
        MYGReportesCronograma.GuardarCsv(csvRuta, plan);
        var csv = LeerCsv(File.ReadAllText(csvRuta));
        var filaA = csv.Single(f => f.Count > 1 && f[1] == "A");
        var filaB = csv.Single(f => f.Count > 1 && f[1] == "B");
        Exige(csv.Count == plan.Tareas.Count + 1 && csv.All(f => f.Count == 22) &&
            filaA[3] == "0001" && filaA[4] == "'=TAREA \"LITERAL\", QA" && filaA[19] == "'@NOTA SEGURA" &&
            filaA[9] == "2026-01-30" && filaA[10] == "2026-02-06" && filaA[12] == "50" &&
            filaB[8] == "0" && filaB[11] == "2FC" && !Directory.GetFiles(carpeta, "Cronograma seguro.csv.*.tmp").Any(),
            "CSV no preservó filas, ISO, literales, comillas, vínculos o prevención de fórmulas, o dejó temporales.");
        string excelRuta = Path.Combine(carpeta, "Cronograma Gantt.xlsx");
        MYGReportesCronograma.GuardarExcel(excelRuta, documento, plan);
        var excelHojas = MYGExcelPresupuestos.Hojas(excelRuta);
        var excel = MYGExcelPresupuestos.Importar(excelRuta, excelHojas.Single(), "A1");
        Exige(excel.TamanoPapel == "A3" && excel.OrientacionPagina == "Horizontal" &&
            excel.Celdas.Keys.Any(k => Ver(excel, k) == documento.Nombre) &&
            excel.Celdas.Keys.Any(k => Ver(excel, k).Contains("0001 =TAREA \"LITERAL\", QA", StringComparison.Ordinal)) &&
            excel.Celdas.Keys.Any(k => Ver(excel, k).Contains('◆')) && Firma(documento) == antes && Firma(plan) == planAntes,
            "XLSX perdió formato A3, cabecera, descripción literal, hitos o aislamiento del informe.");
        pasa("Exportación CSV segura y XLSX abierto conservan datos, literales, fechas y representación Gantt sin depender de Office");

        var largo = Plan();
        largo.Tareas.Add(new() { Id = "LARGA", Nombre = "ACTIVIDAD DE VARIOS AÑOS", DuracionDias = 400 });
        var tramos = MYGReportesCronograma.Crear(documento, largo);
        Exige(tramos.Count >= 3 && tramos.All(t => t.Hoja.Columnas <= 20 && t.Hoja.AnchosColumnas.Values.Sum() < 1500) &&
            tramos.All(t => t.Hoja.Celdas.Keys.Any(k => Ver(t.Hoja, k).Contains("ACTIVIDAD DE VARIOS AÑOS", StringComparison.Ordinal))) &&
            tramos.All(t => t.DatosProyecto.Any(d => d.Key == "Escala" && d.Value.StartsWith("Mensual", StringComparison.Ordinal))),
            "Un cronograma largo comprimió toda la escala o perdió tareas al dividir meses.");
        var vacio = MYGReportesCronograma.Crear(documento, Plan()).Single();
        Exige(vacio.Hoja.Celdas.Keys.Any(k => Ver(vacio.Hoja, k) == "Sin tareas programadas."), "El informe vacío inventó tareas.");
        pasa("Gantt extenso divide meses en tramos legibles y conserva la tabla completa; cronograma vacío produce informe explícito");

        ComprobarFinanzas(carpeta, pasa);
        ComprobarFormatoYPie(carpeta, pasa);
        ValorizadoDimensionesCheck.Ejecutar(carpeta, pasa);
        ValorizadoContinuoCheck.Ejecutar(carpeta, pasa);
        CalendariosColoresCheck.Ejecutar(carpeta, pasa);
        PresupuestoCronogramaSeleccionCheck.Ejecutar(pasa);
    }

    private static void ComprobarFinanzas(string carpeta, Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("OBRA FINANCIERA QA");
        var p = d.Presupuestos.Single();
        ItemPresupuestoDelphin Nodo(string id, decimal cantidad, string padre = null, bool titulo = false)
        {
            var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, ParentId = padre,
                Descripcion = id, Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA" };
            i.Costos.Cantidad = cantidad; p.Items.Add(i); return i;
        }
        var titulo = Nodo("TITULO", 0, titulo: true);
        var directa = Nodo("PRECIO DIRECTO", 2, titulo.Id); directa.Costos.PrecioDirecto = 50;
        var acu = Nodo("ACU REAL", 2, titulo.Id);
        var sub = Nodo("SUBANÁLISIS", 0);
        var otro = Nodo("OTRO PROVEEDOR", 1);
        var mat = new MYGInsumo { Codigo = "0007", Descripcion = "ARENA QA", Unidad = "m3", Precio = 4, Proveedor = "PROVEEDOR A" };
        var matB = new MYGInsumo { Codigo = "0007", Descripcion = "ARENA QA", Unidad = "m3", Precio = 4, Proveedor = "PROVEEDOR B" };
        p.Costos.Insumos.Add(mat); p.Costos.Insumos.Add(matB);
        acu.Costos.Analisis.Add(new() { InsumoId = mat.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 1 });
        sub.Costos.Analisis.Add(new() { InsumoId = mat.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 });
        acu.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = .5m });
        otro.Costos.Analisis.Add(new() { InsumoId = matB.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 3 });
        MYGProyectoStorage.ValidarPresupuesto(p);
        var plan = Plan();
        plan.Tareas.Add(new() { Id = "RESUMEN", Nombre = "RESUMEN", EsResumen = true, PresupuestoId = p.Id, PartidaId = titulo.Id });
        plan.Tareas.Add(new() { Id = "DIRECTA", Nombre = directa.Descripcion, Codigo = "01", PadreId = "RESUMEN",
            PresupuestoId = p.Id, PartidaId = directa.Id, DuracionDias = 3 });
        plan.Tareas.Add(new() { Id = "ACU", Nombre = acu.Descripcion, Codigo = "02", PadreId = "RESUMEN", PresupuestoId = p.Id, PartidaId = acu.Id,
            Modo = MYGModoTarea.Manual, InicioManual = new DateTime(2026, 2, 5), DuracionDias = 0 });
        plan.Tareas.Add(new() { Id = "OTRO", Nombre = otro.Descripcion, Codigo = "03", PresupuestoId = p.Id, PartidaId = otro.Id,
            Modo = MYGModoTarea.Manual, InicioManual = new DateTime(2026, 2, 6), DuracionDias = 1 });
        plan.Tareas.Add(new() { Id = "PERSONALIZADA", Nombre = "PERSONALIZADA SIN COSTO", DuracionDias = 1 });
        string antes = Firma(d), planAntes = Firma(plan);
        var valorizado = MYGReportesCronograma.CrearValorizado(d, plan).Single();
        var h = valorizado.Hoja; var m = new MYGHojaCalculo(h);
        int filaDirecta = Buscar(h, 2, "PRECIO DIRECTO"), filaAcu = Buscar(h, 2, "ACU REAL");
        Exige(m.Numero("F" + filaDirecta) == 100 && m.Numero("G" + filaDirecta) == 33.33m && m.Numero("H" + filaDirecta) == 66.67m &&
            m.Numero("F" + filaAcu) == 16 && m.Numero("G" + filaAcu) == 0 && m.Numero("H" + filaAcu) == 16 &&
            m.Numero(h.CeldaTotal) == 128 && m.Numero(h.CeldaTotal) == MYGMotorPresupuestos.Resumen(p).CostoDirecto &&
            !h.Celdas.Keys.Any(k => Ver(h, k) == "PERSONALIZADA SIN COSTO") && Firma(d) == antes && Firma(plan) == planAntes,
            "El valorizado no concilió los costos reales, feriados, redondeos o hitos, o duplicó resúmenes/personalizadas.");
        var adquisiciones = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single();
        var ah = adquisiciones.Hoja; var am = new MYGHojaCalculo(ah);
        int proveedorA = Buscar(ah, 5, "PROVEEDOR A"), proveedorB = Buscar(ah, 5, "PROVEEDOR B");
        Exige(am.Numero("F" + proveedorA) == 4 && am.Numero("H" + proveedorA) == 16 && am.Numero("I" + proveedorA) == 4 &&
            am.Numero("F" + proveedorB) == 3 && am.Numero("H" + proveedorB) == 12 && am.Numero(ah.CeldaTotal) == 28 &&
            ah.Celdas.Keys.Count(k => MYGHojaCalculo.Coordenadas(k).Columna == 2 && Ver(ah, k) == "0007") == 2 &&
            !ah.Celdas.Keys.Any(k => Ver(ah, k).Contains("(precio directo)", StringComparison.Ordinal)) &&
            Firma(d) == antes && Firma(plan) == planAntes,
            "Adquisiciones alteró cantidades/subanálisis, mezcló proveedores o inventó subcontratos para precios directos.");
        string ruta = Path.Combine(carpeta, "Calendarios reales.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, new[] { valorizado, adquisiciones });
        Exige(MYGExcelPresupuestos.Hojas(ruta).Length == 2, "Los calendarios no se exportaron como hojas independientes.");
        var planLargo = MYGProyectoStorage.Copia(plan);
        planLargo.Tareas.Single(t => t.Id == "DIRECTA").DuracionDias = 400;
        planLargo.Tareas.Single(t => t.Id == "OTRO").InicioManual = new DateTime(2027, 6, 1);
        var valorizadosLargos = MYGReportesCronograma.CrearValorizado(d, planLargo);
        var comprasLargas = MYGReportesCronograma.CrearAdquisiciones(d, planLargo);
        Exige(valorizadosLargos.Count == 1 && valorizadosLargos[0].Hoja.Columnas > 14 && valorizadosLargos.Sum(r => new MYGHojaCalculo(r.Hoja).Numero(r.Hoja.CeldaTotal)) == 128 &&
            comprasLargas.Count >= 3 && comprasLargas.Sum(r => new MYGHojaCalculo(r.Hoja).Numero(r.Hoja.CeldaTotal)) == 28,
            "Los tramos de calendario repitieron importes globales en vez de conciliar el costo sólo de los meses de cada hoja.");
        pasa("Calendarios reales concilian costo directo por días laborables/feriados y recursos al inicio, sin duplicar resúmenes, subanálisis ni proveedores");

        var usd = new MYGPresupuestoDocumento { Nombre = "DÓLARES", Item = "02" }; usd.Costos.Moneda = "USD";
        var usdPartida = new ItemPresupuestoDelphin { Id = "USD", IdLocalMYG = "USD", Item = "01", Descripcion = "PARTIDA USD", Unidad = "und", TipoPropuesta = "PARTIDA" };
        usdPartida.Costos.Cantidad = 1; usdPartida.Costos.PrecioDirecto = 7; usd.Items.Add(usdPartida); d.Presupuestos.Add(usd);
        plan.Tareas.Add(new() { Id = "USD", Nombre = "PARTIDA USD", PresupuestoId = usd.Id, PartidaId = usdPartida.Id });
        var separados = MYGReportesCronograma.CrearValorizado(d, plan);
        Exige(separados.Count == 2 && separados.Select(r => new MYGHojaCalculo(r.Hoja).Numero(r.Hoja.CeldaTotal)).OrderBy(n => n).SequenceEqual(new[] { 7m, 128m }),
            "El calendario sumó importes de monedas diferentes.");
        var duplicado = MYGProyectoStorage.Copia(plan);
        duplicado.Tareas.Add(new() { Id = "DUPLICADA", Nombre = "DUPLICADA", PresupuestoId = p.Id, PartidaId = directa.Id });
        Rechaza(() => MYGReportesCronograma.CrearValorizado(d, duplicado));
        Rechaza(() => MYGReportesCronograma.CrearAdquisiciones(d, duplicado));
        var ajeno = MYGProyectoStorage.Copia(plan); ajeno.Tareas.Single(t => t.Id == "DIRECTA").PartidaId = "YA NO EXISTE";
        Rechaza(() => MYGReportesCronograma.CrearValorizado(d, ajeno));
        var sinRecursos = MYGReportesCronograma.CrearAdquisiciones(d, Plan()).Single().Hoja;
        Exige(sinRecursos.Celdas.Keys.Any(k => Ver(sinRecursos, k).StartsWith("Sin recursos", StringComparison.Ordinal)),
            "Adquisiciones vacío inventó requerimientos.");
        pasa("Calendarios separan monedas y rechazan vínculos duplicados/rotos; planes sin partidas muestran su alcance vacío");
    }

    private static void ComprobarFormatoYPie(string carpeta, Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("PROYECTO CALENDARIO");
        d.Datos = new() { Propietario = "PROPIETARIO", Departamento = "ÁNCASH", Provincia = "SANTA", Distrito = "CHIMBOTE",
            FechaElaboracion = new DateTime(2026, 1, 1) };
        var a = d.Presupuestos.Single(); a.Nombre = "PRESUPUESTO A"; a.Item = "01";
        var b = new MYGPresupuestoDocumento { Id = "B", Nombre = "PRESUPUESTO B", Item = "02", Posicion = 2 };
        d.Presupuestos.Add(b);
        ItemPresupuestoDelphin Partida(MYGPresupuestoDocumento p, string nombre, decimal importe)
        {
            var i = MYGEstructuraPresupuestos.InsertarNodo(p, false);
            i.Descripcion = nombre; i.Unidad = "m2"; i.Costos.Cantidad = 1; i.Costos.PrecioDirecto = importe; return i;
        }
        var iA = Partida(a, "ACTIVIDAD A", 100); var iB = Partida(b, "ACTIVIDAD B", 100);
        Partida(a, "PARTIDA NO PROGRAMADA", 1000);
        a.Costos.GastosGeneralesPorcentaje = 10; b.Costos.GastosGeneralesPorcentaje = 50;
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5) };
        plan.Tareas.Add(new() { Id = "A", Nombre = iA.Descripcion, PresupuestoId = a.Id, PartidaId = iA.Id, DuracionDias = 1 });
        plan.Tareas.Add(new() { Id = "B", Nombre = iB.Descripcion, PresupuestoId = b.Id, PartidaId = iB.Id,
            Modo = MYGModoTarea.Manual, InicioManual = new DateTime(2026, 2, 2), DuracionDias = 1 });
        string antes = Firma(d), planAntes = Firma(plan);
        var reporte = MYGReportesCronograma.CrearValorizado(d, plan).Single();
        var h = reporte.Hoja; var motor = new MYGHojaCalculo(h);
        int gg = Buscar(h, 2, "Gastos generales"), total = MYGHojaCalculo.Coordenadas(h.CeldaTotal).Fila;
        int avance = Buscar(h, 2, "Porcentaje de avance por Mes"), acumulado = Buscar(h, 2, "Porcentaje de avance acumulado");
        Exige(reporte.CabeceraEnHoja && h.FilasInmovilizadas == 9 && h.ColumnasInmovilizadas == 6 &&
            Ver(h, "A1") == "CRONOGRAMA VALORIZADO DEL PROYECTO" && Ver(h, "A9") == "Item" && Ver(h, "B9") == "Descripción" &&
            Ver(h, "D9") == "Cantidad" && Ver(h, "E9") == "Precio" && Ver(h, "F9") == "Parcial" &&
            Ver(h, "G9") == "Mes 1\nDel 01/01/2026\nAl 31/01/2026" && Ver(h, "H9").Contains("Mes 2\nDel 01/02/2026\nAl 28/02/2026"),
            "El valorizado perdió cabecera, columnas presupuestales o los rangos fechados de cada mes.");
        Exige(motor.Numero("F" + gg) == 60 && motor.Numero("G" + gg) == 10 && motor.Numero("H" + gg) == 50 &&
            !Ver(h, "B" + gg).Contains('%') && motor.Numero(h.CeldaTotal) == 260 &&
            motor.Numero("G" + total) == 110 && motor.Numero("H" + total) == 150 &&
            motor.Numero("G" + avance) == 110m / 260m && motor.Numero("H" + acumulado) == 1 &&
            h.Celdas["G" + avance].FormatoNumero == "0.00%" &&
            !h.Celdas.Keys.Any(k => Ver(h, k) == "PARTIDA NO PROGRAMADA") && Firma(d) == antes && Firma(plan) == planAntes,
            "El pie mensual mezcló tasas/meses, incluyó partidas no programadas, cambió documentos o usó porcentajes con denominador distinto del total.");
        var seleccionado = MYGReportesCronograma.CrearValorizado(d, plan, b.Id).Single().Hoja;
        Exige(Ver(seleccionado, "A1") == "CRONOGRAMA VALORIZADO DEL PRESUPUESTO" &&
            new MYGHojaCalculo(seleccionado).Numero(seleccionado.CeldaTotal) == 150 &&
            !seleccionado.Celdas.Keys.Any(k => Ver(seleccionado, k) == "ACTIVIDAD A"), "El alcance de presupuesto incluyó otros presupuestos.");
        Rechaza(() => MYGReportesCronograma.CrearValorizado(d, plan, "NO EXISTE"));
        string ruta = Path.Combine(carpeta, "Valorizado formato.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, new[] { reporte });
        var leido = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta).Single(), h.CeldaTotal);
        Exige(Ver(leido, "A1") == Ver(h, "A1") && Ver(leido, "G9") == Ver(h, "G9") &&
            new MYGHojaCalculo(leido).Numero("H" + acumulado) == 1 && leido.Celdas["H" + acumulado].FormatoNumero == "0.00%",
            "XLSX cambió el formato continuo, duplicó la cabecera o perdió porcentajes numéricos.");
        using (var zip = ZipFile.OpenRead(ruta))
        using (var stream = zip.GetEntry("xl/workbook.xml").Open())
        {
            var xml = XDocument.Load(stream); XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            Exige(xml.Descendants(ns + "definedName").Any(n => (string)n.Attribute("name") == "_xlnm.Print_Titles" && n.Value.EndsWith("$1:$9", StringComparison.Ordinal)),
                "La exportación XLSX no repite la cabecera y los encabezados mensuales completos al imprimir.");
        }
        pasa("Valorizado conserva columnas de presupuesto, fechas por mes, pie con tasas por presupuesto y avance mensual/acumulado también al reabrir XLSX");

        b.Costos.PiePersonalizado = new() { new() { Id = "fijo-b", Nombre = "FIJO B", Modo = MYGModoFilaResumen.ValorManual, ValorManual = 10 } };
        var mixto = MYGReportesCronograma.CrearValorizado(d, plan).Single().Hoja; var mm = new MYGHojaCalculo(mixto);
        int subtotalMixto = Buscar(mixto, 2, "Parcial");
        Exige(mm.Numero("F" + subtotalMixto) == 220 && mm.Numero("G" + subtotalMixto) == 110 && mm.Numero("H" + subtotalMixto) == 110,
            "El parcial global perdió el subtotal de un pie personalizado que no expone una fila Parcial.");
        b.Costos.PiePersonalizado = null;
        a.Costos.PiePersonalizado = new() { new() { Id = "fijo", Nombre = "Costo fijo", Modo = MYGModoFilaResumen.ValorManual, ValorManual = 40 },
            new() { Id = "formula", Nombre = "Adicional calculado", Modo = MYGModoFilaResumen.Formula, Formula = "CD * 0.1" } };
        a.Costos.MostrarTotalPiePersonalizado = false;
        var personalizado = MYGReportesCronograma.CrearValorizado(d, plan, a.Id).Single().Hoja;
        int fijo = Buscar(personalizado, 2, "Costo fijo");
        Exige(new MYGHojaCalculo(personalizado).Numero("F" + fijo) == 40 &&
            new MYGHojaCalculo(personalizado).Numero(personalizado.CeldaTotal) == 150 &&
            !personalizado.Celdas.Keys.Any(k => Ver(personalizado, k).Contains("Gastos generales", StringComparison.Ordinal)),
            "El valorizado ignoró el pie personalizado, duplicó un valor manual o activó porcentajes históricos.");
        var pieNativo = new MYGConfiguracionPieDelphin { ProyectoId = "PR", UnicoPorProyecto = true, Filas = new()
        {
            new() { Clave = "user_fijo", Tipo = "V", Nombre = "EXPEDIENTE", Valor = 40, Posicion = 1 },
            new() { Clave = "user_total", Tipo = "F", Nombre = "TOTAL NATIVO", Formula = "[costo_directo]+[user_fijo]", Posicion = 2 }
        } };
        a.Costos.PiePersonalizado = null;
        a.Costos.PieDelphin = MYGProyectoStorage.Copia(pieNativo); b.Costos.PieDelphin = MYGProyectoStorage.Copia(pieNativo);
        var nativo = MYGReportesCronograma.CrearValorizado(d, plan).Single().Hoja;
        int expediente = Buscar(nativo, 2, "EXPEDIENTE");
        Exige(new MYGHojaCalculo(nativo).Numero("F" + expediente) == 40 &&
            new MYGHojaCalculo(nativo).Numero(nativo.CeldaTotal) == 240 &&
            Ver(nativo, "B" + MYGHojaCalculo.Coordenadas(nativo.CeldaTotal).Fila).Contains("TOTAL NATIVO", StringComparison.Ordinal) &&
            new MYGHojaCalculo(nativo).Numero("G" + expediente) == 20 && new MYGHojaCalculo(nativo).Numero("H" + expediente) == 20,
            "El pie único Delphin duplicó fijos o sumó filas F como gastos adicionales.");
        var redondeo = MYGProyectoStorage.Nuevo("REDONDEOS");
        var rp = redondeo.Presupuestos.Single(); var ri = Partida(rp, "PARTIDA CENTAVOS", 100);
        rp.Costos.PiePersonalizado = new() { new() { Id = "centavo-a", Nombre = "RECARGO A", Modo = MYGModoFilaResumen.ValorManual, ValorManual = .01m },
            new() { Id = "centavo-b", Nombre = "RECARGO B", Modo = MYGModoFilaResumen.ValorManual, ValorManual = .01m } };
        var pr = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 30) };
        pr.Tareas.Add(new() { Nombre = ri.Descripcion, PresupuestoId = rp.Id, PartidaId = ri.Id, DuracionDias = 2 });
        var hr = MYGReportesCronograma.CrearValorizado(redondeo, pr).Single().Hoja; var mr = new MYGHojaCalculo(hr);
        int cd = Buscar(hr, 2, "Costo directo"), ra = Buscar(hr, 2, "RECARGO A"), rb = Buscar(hr, 2, "RECARGO B");
        int tr = MYGHojaCalculo.Coordenadas(hr.CeldaTotal).Fila;
        Exige(mr.Numero("G" + tr) == 50.02m && mr.Numero("H" + tr) == 50m && mr.Numero(hr.CeldaTotal) == 100.02m &&
            new[] { "G", "H" }.All(c => mr.Numero(c + tr) == mr.Numero(c + cd) + mr.Numero(c + ra) + mr.Numero(c + rb)),
            "Los totales mensuales no concilian con los conceptos del pie al repartir centavos.");
        rp.Costos.PiePersonalizado = null; rp.Costos.GastosGeneralesPorcentaje = .01m; rp.Costos.UtilidadPorcentaje = .01m;
        var hd = MYGReportesCronograma.CrearValorizado(redondeo, pr).Single().Hoja; var md = new MYGHojaCalculo(hd);
        int parcial = Buscar(hd, 2, "Parcial"), dg = Buscar(hd, 2, "Gastos generales"), du = Buscar(hd, 2, "Utilidad");
        int dc = Buscar(hd, 2, "Costo directo"), dt = MYGHojaCalculo.Coordenadas(hd.CeldaTotal).Fila;
        Exige(new[] { "G", "H" }.All(c => md.Numero(c + parcial) == md.Numero(c + dc) + md.Numero(c + dg) + md.Numero(c + du) &&
            md.Numero(c + parcial) == md.Numero(c + dt)), "El parcial estándar o el total volvieron a redondear y perdieron centavos mensuales.");
        rp.Costos.PiePersonalizado = null; rp.Costos.GastosGeneralesPorcentaje = rp.Costos.UtilidadPorcentaje = 0;
        rp.Costos.DecimalesPrecio = 0;
        MYGMotorPresupuestos.CapturarPrecioDelphin(rp, ri, 100.49m, 100.49m);
        var hp = MYGReportesCronograma.CrearValorizado(redondeo, pr).Single().Hoja; var mp = new MYGHojaCalculo(hp);
        int filaImportada = Buscar(hp, 2, "PARTIDA CENTAVOS");
        Exige(mp.Numero("F" + filaImportada) == 100.49m && mp.Numero(hp.CeldaTotal) == 100.49m,
            "El snapshot del pie volvió a redondear el parcial Delphin a la precisión de presentación del precio.");
        var sinCompras = MYGReportesCronograma.CrearAdquisiciones(d, plan, a.Id).Single();
        Exige(sinCompras.Titulo == "CALENDARIO DE ADQUISICIONES DEL PRESUPUESTO" &&
            sinCompras.DatosProyecto.Any(dato => dato.Key == "Presupuesto" && dato.Value.Contains(a.Nombre)),
            "El calendario de adquisiciones sin recursos perdió el alcance del presupuesto seleccionado.");
        pasa("Valorizado respeta pies personalizados con fórmulas/manuales y pie único Delphin sin duplicar importes fijos ni subtotales");
    }

    // Lector independiente RFC 4180 para comprobar comillas, separadores y
    // registros del CSV generado sin depender del exportador bajo prueba.
    private static List<List<string>> LeerCsv(string texto)
    {
        var filas = new List<List<string>>(); var fila = new List<string>(); var valor = new System.Text.StringBuilder(); bool comillas = false;
        for (int n = 0; n < texto.Length; n++)
        {
            char c = texto[n];
            if (c == '"')
            {
                if (comillas && n + 1 < texto.Length && texto[n + 1] == '"') { valor.Append('"'); n++; }
                else comillas = !comillas;
            }
            else if (c == ',' && !comillas) { fila.Add(valor.ToString()); valor.Clear(); }
            else if (c == '\n' && !comillas) { fila.Add(valor.ToString()); valor.Clear(); filas.Add(fila); fila = new(); }
            else if (c != '\r' || comillas) valor.Append(c);
        }
        Exige(!comillas && valor.Length == 0 && fila.Count == 0, "CSV incompleto o con comillas no cerradas.");
        return filas;
    }
}
