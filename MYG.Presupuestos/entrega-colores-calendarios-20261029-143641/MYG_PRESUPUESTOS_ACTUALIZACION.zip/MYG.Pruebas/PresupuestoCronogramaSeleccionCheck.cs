using System;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class PresupuestoCronogramaSeleccionCheck
{
    private static void Exige(bool valor, string mensaje)
    { if (!valor) throw new Exception(mensaje); }

    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidOperationException) { return; }
        throw new Exception("La selección de calendario aceptó un vínculo roto o ambiguo.");
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Selección de calendarios", "ESTRUCTURAS");
        var estructuras = documento.Presupuestos.Single();
        var arquitectura = new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02" };
        documento.Presupuestos.Add(arquitectura);
        documento.PresupuestoActivoId = estructuras.Id;
        var plan = new MYGCronograma();
        plan.Tareas.AddRange(new[]
        {
            new MYGTareaCronograma { Id = "E", PresupuestoId = estructuras.Id, EsResumen = true, Nombre = estructuras.Nombre },
            new MYGTareaCronograma { Id = "A", PresupuestoId = arquitectura.Id, EsResumen = true, Nombre = arquitectura.Nombre },
            new MYGTareaCronograma { Id = "CAP", PadreId = "A", EsResumen = true, Nombre = "Capítulo arquitectura" },
            new MYGTareaCronograma { Id = "ACT", PadreId = "CAP", Nombre = "Actividad dentro de arquitectura" },
            new MYGTareaCronograma { Id = "LIBRE", Nombre = "Personalizada sin vínculo" }
        });
        string antes = JsonSerializer.Serialize(documento), planAntes = JsonSerializer.Serialize(plan);
        Exige(MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "A") == arquitectura &&
            MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "CAP") == arquitectura &&
            MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "ACT") == arquitectura &&
            MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "E") == estructuras,
            "Seleccionar un presupuesto, capítulo o actividad debe resolver su presupuesto y no el activo en otra vista.");
        Exige(MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan) == estructuras &&
            MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "LIBRE") == estructuras &&
            JsonSerializer.Serialize(documento) == antes && JsonSerializer.Serialize(plan) == planAntes,
            "La selección personalizada sin vínculo debe usar el activo sin cambiar datos ni selección guardada.");
        pasa("Calendarios resuelven presupuesto, capítulo y actividad actuales aunque el presupuesto activo sea otro, sin modificar documentos");

        plan.Tareas.Add(new() { Id = "RESUMEN", EsResumen = true, Nombre = "Resumen personalizado" });
        plan.Tareas.Single(t => t.Id == "A").PadreId = "RESUMEN";
        Exige(MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "RESUMEN") == arquitectura,
            "Un resumen con un único presupuesto descendiente debe resolver ese alcance.");
        plan.Tareas.Single(t => t.Id == "E").PadreId = "RESUMEN";
        Rechaza(() => MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "RESUMEN"));
        plan.Tareas.Add(new() { Id = "ROTA", PresupuestoId = "INEXISTENTE", Nombre = "Vínculo roto" });
        Rechaza(() => MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "ROTA"));
        Rechaza(() => MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "TAREA_INEXISTENTE"));
        plan.Tareas.Single(t => t.Id == "LIBRE").PadreId = "PADRE_INEXISTENTE";
        Rechaza(() => MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "LIBRE"));
        plan.Tareas.Single(t => t.Id == "LIBRE").PadreId = "LIBRE";
        Rechaza(() => MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan, "LIBRE"));
        documento.PresupuestoActivoId = null;
        Exige(MYGPresupuestoCronogramaSeleccion.Resolver(documento, plan) == null,
            "Sin selección ni presupuesto activo no debe inventarse otro alcance.");
        pasa("Calendarios infieren un único presupuesto de resúmenes personalizados y rechazan selecciones ambiguas, inexistentes y ciclos sin usar otro presupuesto");
    }
}
