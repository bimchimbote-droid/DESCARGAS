using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using MYG_2027;

internal static class CalendariosColoresCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static string ColorNivel(int nivel) => new[] { "117744", "224488", "AA3355" }[Math.Min(nivel, 2)];
    private static int Fila(MYGHojaMetrado h, int columna, string texto) => h.Celdas
        .Where(e => MYGHojaCalculo.Coordenadas(e.Key).Columna == columna && e.Value.Contenido == texto)
        .Select(e => MYGHojaCalculo.Coordenadas(e.Key).Fila).Single();

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("COLORES DE CALENDARIOS QA");
        var a = documento.Presupuestos.Single(); a.Nombre = "PRESUPUESTO A QA"; a.Item = "01";
        var b = new MYGPresupuestoDocumento { Id = "PRESUPUESTO-B", Item = "02", Nombre = "PRESUPUESTO B QA", Posicion = 1 };
        documento.Presupuestos.Add(b);
        ItemPresupuestoDelphin Nodo(MYGPresupuestoDocumento p, string id, string nombre, string codigo, string padre = null, bool titulo = false)
        {
            var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = codigo, ParentId = padre,
                Descripcion = nombre, Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA" };
            i.Costos.Cantidad = titulo ? 0 : 2; p.Items.Add(i); return i;
        }
        // Los códigos no expresan la profundidad. Los colores siguen ParentId.
        var capitulo = Nodo(a, "CAP", "CAPITULO QA", "99", titulo: true);
        var subcapitulo = Nodo(a, "SUBCAP", "SUBCAPITULO QA", "01", capitulo.Id, titulo: true);
        var partidaA = Nodo(a, "PA", "ACTIVIDAD A QA", "777", subcapitulo.Id);
        var partidaB = Nodo(b, "PB", "ACTIVIDAD B QA", "001"); partidaB.Costos.Cantidad = 1;
        var material = new MYGInsumo { Codigo = "MAT-A", Descripcion = "MATERIAL A QA", Unidad = "und", Precio = 3,
            Proveedor = "PROVEEDOR A QA", Grupo = MYGGrupoRecurso.Materiales };
        var equipo = new MYGInsumo { Codigo = "EQ-A", Descripcion = "EQUIPO A QA", Unidad = "hm", Precio = 4,
            Proveedor = "PROVEEDOR EQ QA", Grupo = MYGGrupoRecurso.Equipo };
        var materialB = new MYGInsumo { Codigo = "MAT-B", Descripcion = "MATERIAL B QA", Unidad = "und", Precio = 10,
            Proveedor = "PROVEEDOR B QA", Grupo = MYGGrupoRecurso.Materiales };
        a.Costos.Insumos.Add(material); a.Costos.Insumos.Add(equipo); b.Costos.Insumos.Add(materialB);
        partidaA.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 1 });
        partidaA.Costos.Analisis.Add(new() { InsumoId = equipo.Id, Grupo = MYGGrupoRecurso.Equipo, Cantidad = 2 });
        partidaB.Costos.Analisis.Add(new() { InsumoId = materialB.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 1 });
        MYGProyectoStorage.ValidarPresupuesto(a); MYGProyectoStorage.ValidarPresupuesto(b);
        var plan = new MYGCronograma { FechaInicio = new DateTime(2028, 1, 3), FechaEstado = new DateTime(2028, 1, 3) };
        plan.Tareas.Add(new() { Id = "TA", Nombre = partidaA.Descripcion, PresupuestoId = a.Id, PartidaId = partidaA.Id, DuracionDias = 1 });
        plan.Tareas.Add(new() { Id = "TB", Nombre = partidaB.Descripcion, PresupuestoId = b.Id, PartidaId = partidaB.Id, DuracionDias = 1 });
        string antes = Firma(documento), programacion = Firma(plan);

        var valorizado = MYGReportesCronograma.CrearValorizado(documento, plan, a.Id).Single();
        var h = valorizado.Hoja;
        int filaPresupuesto = Fila(h, 2, a.Nombre), filaCapitulo = Fila(h, 2, capitulo.Descripcion),
            filaSubcapitulo = Fila(h, 2, subcapitulo.Descripcion), filaPartida = Fila(h, 2, partidaA.Descripcion);
        Exige(valorizado.NivelesTitulos.Count == 3 && valorizado.NivelesTitulos[filaPresupuesto] == 0 &&
            valorizado.NivelesTitulos[filaCapitulo] == 1 && valorizado.NivelesTitulos[filaSubcapitulo] == 2 &&
            !valorizado.NivelesTitulos.ContainsKey(filaPartida) &&
            !h.Celdas.Values.Any(c => c.Contenido == partidaB.Descripcion) && new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 22,
            "El valorizado no conserva la jerarquía real de títulos o mezcló presupuestos/importes al colorear.");
        pasa("Valorizado identifica presupuesto y títulos por jerarquía real para sus colores, sin colorear partidas ni mezclar otro presupuesto");

        var adquisiciones = MYGReportesCronograma.CrearAdquisiciones(documento, plan, a.Id).Single();
        var compras = adquisiciones.Hoja;
        int filaMaterial = Fila(compras, 3, material.Descripcion), filaEquipo = Fila(compras, 3, equipo.Descripcion);
        var motor = new MYGHojaCalculo(compras);
        Exige(adquisiciones.NivelesTitulos.Count == 2 && adquisiciones.NivelesTitulos.Values.All(n => n == 0) &&
            !adquisiciones.NivelesTitulos.ContainsKey(filaMaterial) && !adquisiciones.NivelesTitulos.ContainsKey(filaEquipo) &&
            motor.Numero("F" + filaMaterial) == 2 && motor.Numero("H" + filaMaterial) == 6 &&
            motor.Numero("F" + filaEquipo) == 4 && motor.Numero("H" + filaEquipo) == 16 && motor.Numero(compras.CeldaTotal) == 22 &&
            !compras.Celdas.Values.Any(c => c.Contenido == materialB.Descripcion) &&
            adquisiciones.NivelesTitulos.Keys.All(f => compras.RangosCombinados.Contains("A" + f + ":H" + f)),
            "Los títulos de adquisiciones alteraron cantidades/costos, colorearon recursos o mezclaron otro presupuesto.");
        var comprasProyecto = MYGReportesCronograma.CrearAdquisiciones(documento, plan).Single();
        Exige(new MYGHojaCalculo(comprasProyecto.Hoja).Numero(comprasProyecto.Hoja.CeldaTotal) == 32 &&
            comprasProyecto.Hoja.Celdas.Values.Any(c => c.Contenido == materialB.Descripcion),
            "El alcance del proyecto perdió recursos de otro presupuesto al agregar títulos coloreables.");
        pasa("Adquisiciones habilita colores en títulos de grupos y conserva cantidades, costos y recursos del presupuesto seleccionado o de todo el proyecto");

        ComprobarExportaciones(carpeta, "Valorizado", valorizado, 2, pasa);
        ComprobarExportaciones(carpeta, "Adquisiciones", adquisiciones, 1, pasa);
        Exige(Firma(documento) == antes && Firma(plan) == programacion,
            "Colorear o exportar calendarios modificó el documento editable o la programación.");
    }

    private static void ComprobarExportaciones(string carpeta, string nombre, MYGHojaReporteProyecto original, int columnaTitulo, Action<string> pasa)
    {
        string origen = Firma(original.Hoja);
        var vista = new MYGConfiguracionVistaReporte(new[] { original });
        var titulos = original.NivelesTitulos.Select(n => (Fila: n.Key, Nivel: n.Value,
            Texto: original.Hoja.Celdas[MYGHojaCalculo.Columna(columnaTitulo) + n.Key].Contenido)).ToArray();
        var inicial = vista.CapturarSolicitud();
        vista.ColorearTitulos(true, ColorNivel);
        var coloreada = vista.CapturarSolicitud();
        var actual = vista.Reportes.Single();
        foreach (var celda in original.Hoja.Celdas)
        {
            int fila = MYGHojaCalculo.Coordenadas(celda.Key).Fila;
            string esperado = original.NivelesTitulos.TryGetValue(fila, out int nivel) ? ColorNivel(nivel) : celda.Value.ColorTexto;
            Exige(actual.Hoja.Celdas[celda.Key].ColorTexto == esperado &&
                actual.Hoja.Celdas[celda.Key].Contenido == celda.Value.Contenido,
                nombre + ": el cambio de color afectó datos o filas que no son títulos.");
        }
        vista.ColorearTitulos(false);
        Exige(Firma(vista.Reportes.Single().Hoja) == origen &&
            coloreada.CrearReportes().Single().Hoja.Celdas[MYGHojaCalculo.Columna(columnaTitulo) + titulos[0].Fila].ColorTexto == ColorNivel(titulos[0].Nivel),
            nombre + ": desactivar colores perdió el original o alteró la captura independiente.");
        vista.ColorearTitulos(true, _ => "ABCDEF"); vista.Restaurar();
        Exige(!vista.TitulosConColor && Firma(vista.Reportes.Single().Hoja) == origen,
            nombre + ": restaurar no recuperó colores originales.");

        var rutas = new Dictionary<MYGFormatoExportacionReporte, string>();
        foreach (var formato in Enum.GetValues<MYGFormatoExportacionReporte>())
        {
            string ruta = Path.Combine(carpeta, nombre + " colores." + formato.ToString().ToLowerInvariant());
            MYGReportesExportacion.Guardar(ruta, formato, coloreada.CrearReportes());
            rutas.Add(formato, ruta);
        }
        string rutaXlsx = rutas[MYGFormatoExportacionReporte.Xlsx];
        var leida = MYGExcelPresupuestos.Importar(rutaXlsx, MYGExcelPresupuestos.Hojas(rutaXlsx).Single(), "A1");
        foreach (var titulo in titulos)
        {
            var celda = leida.Celdas.Values.Single(c => c.Contenido == titulo.Texto && c.Negrita);
            Exige(celda.ColorTexto == ColorNivel(titulo.Nivel), nombre + ": XLSX perdió el color del título " + titulo.Texto);
        }
        var html = XDocument.Load(rutas[MYGFormatoExportacionReporte.Html]);
        ComprobarHtml(html);
        string mht = File.ReadAllText(rutas[MYGFormatoExportacionReporte.Mht]);
        const string cabecera = "Content-Location: informe.html\r\n\r\n";
        int desde = mht.IndexOf(cabecera, StringComparison.Ordinal) + cabecera.Length;
        int hasta = mht.IndexOf("\r\n------MYG_", desde, StringComparison.Ordinal);
        Exige(desde >= cabecera.Length && hasta > desde, nombre + ": MHT no contiene el cuerpo HTML completo.");
        ComprobarHtml(XDocument.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(mht[desde..hasta]))));
        string rtf = File.ReadAllText(rutas[MYGFormatoExportacionReporte.Rtf]);
        var coloresRtf = Regex.Matches(rtf, @"\\red(\d+)\\green(\d+)\\blue(\d+);").Select(m =>
            int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture).ToString("X2") +
            int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture).ToString("X2") +
            int.Parse(m.Groups[3].Value, CultureInfo.InvariantCulture).ToString("X2")).ToArray();
        foreach (var titulo in titulos)
        {
            int indice = Array.IndexOf(coloresRtf, ColorNivel(titulo.Nivel)) + 1;
            bool encontrado = false;
            // Un nombre de presupuesto o grupo también puede aparecer en la
            // cabecera o en un recurso; comprobar su párrafo coloreado real.
            for (int texto = rtf.IndexOf(titulo.Texto, StringComparison.Ordinal); texto >= 0;
                texto = rtf.IndexOf(titulo.Texto, texto + titulo.Texto.Length, StringComparison.Ordinal))
            {
                int parrafo = rtf.LastIndexOf(@"\pard\intbl", texto, StringComparison.Ordinal);
                if (indice > 0 && parrafo >= 0 && Regex.IsMatch(rtf[parrafo..texto], @"\\cf" + indice + @"(?!\d)"))
                { encontrado = true; break; }
            }
            Exige(encontrado,
                nombre + ": RTF no aplica el índice de color al título " + titulo.Texto);
        }
        foreach (var formato in new[] { MYGFormatoExportacionReporte.Csv, MYGFormatoExportacionReporte.Texto })
        {
            string rutaSinColor = Path.Combine(carpeta, nombre + " sin colores." + formato.ToString().ToLowerInvariant());
            MYGReportesExportacion.Guardar(rutaSinColor, formato, inicial.CrearReportes());
            Exige(File.ReadAllBytes(rutaSinColor).SequenceEqual(File.ReadAllBytes(rutas[formato])),
                nombre + ": colorear títulos cambió el contenido de un formato de texto sin estilos.");
        }
        Exige(Firma(original.Hoja) == origen && new MYGHojaCalculo(actual.Hoja).Numero(actual.Hoja.CeldaTotal) ==
            new MYGHojaCalculo(original.Hoja).Numero(original.Hoja.CeldaTotal),
            nombre + ": exportar colores alteró el origen o el total.");
        pasa(nombre + " conserva colores de títulos en XLSX, HTML, MHT y RTF; capturas, desactivar/restaurar y CSV/TXT mantienen datos e importes");

        void ComprobarHtml(XDocument xml)
        {
            foreach (var titulo in titulos)
                Exige(xml.Descendants("td").Any(e => e.Value == titulo.Texto &&
                    ((string)e.Attribute("style") ?? "").Contains("font-weight:bold", StringComparison.Ordinal) &&
                    ((string)e.Attribute("style") ?? "").Contains("color:#" + ColorNivel(titulo.Nivel), StringComparison.Ordinal)),
                    nombre + ": HTML/MHT perdió el color aplicado al título " + titulo.Texto);
        }
    }
}
