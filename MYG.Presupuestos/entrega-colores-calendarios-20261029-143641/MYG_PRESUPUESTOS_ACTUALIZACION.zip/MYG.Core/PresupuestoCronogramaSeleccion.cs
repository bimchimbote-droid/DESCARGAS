using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

/// <summary>Resuelve el alcance del calendario desde la tarea actual sin cambiar
/// el presupuesto activo ni los vínculos de la programación.</summary>
public static class MYGPresupuestoCronogramaSeleccion
{
    public static MYGPresupuestoDocumento Resolver(MYGProyectoDocumento documento, MYGCronograma plan, string tareaId = null)
    {
        if (documento == null) return null;
        var presupuestos = new Dictionary<string, MYGPresupuestoDocumento>(StringComparer.OrdinalIgnoreCase);
        foreach (var presupuesto in documento.Presupuestos)
            if (presupuesto == null || string.IsNullOrWhiteSpace(presupuesto.Id) || !presupuestos.TryAdd(presupuesto.Id, presupuesto))
                throw new InvalidOperationException("El proyecto contiene presupuestos incompletos o repetidos.");

        MYGPresupuestoDocumento Vinculado(MYGTareaCronograma tarea)
        {
            if (string.IsNullOrWhiteSpace(tarea.PresupuestoId)) return null;
            if (!presupuestos.TryGetValue(tarea.PresupuestoId, out var presupuesto))
                throw new InvalidOperationException("La tarea seleccionada pertenece a un presupuesto que ya no existe. Revise sus vínculos antes de exportar.");
            return presupuesto;
        }

        if (!string.IsNullOrWhiteSpace(tareaId))
        {
            var tareas = new Dictionary<string, MYGTareaCronograma>(StringComparer.Ordinal);
            foreach (var tarea in plan?.Tareas ?? Enumerable.Empty<MYGTareaCronograma>())
                if (tarea == null || string.IsNullOrWhiteSpace(tarea.Id) || !tareas.TryAdd(tarea.Id, tarea))
                    throw new InvalidOperationException("El cronograma contiene tareas incompletas o repetidas.");
            if (!tareas.TryGetValue(tareaId, out var seleccionada))
                throw new InvalidOperationException("La tarea seleccionada ya no existe. Vuelva a seleccionarla en el cronograma.");
            var visitados = new HashSet<string>(StringComparer.Ordinal);
            var actual = seleccionada;
            while (actual != null)
            {
                if (!visitados.Add(actual.Id))
                    throw new InvalidOperationException("La jerarquía de la tarea seleccionada contiene un ciclo.");
                var presupuesto = Vinculado(actual);
                if (presupuesto != null) return presupuesto;
                if (string.IsNullOrWhiteSpace(actual.PadreId)) break;
                if (!tareas.TryGetValue(actual.PadreId, out actual))
                    throw new InvalidOperationException("El capítulo padre de la tarea seleccionada ya no existe. Revise la jerarquía antes de exportar.");
            }

            // Un resumen personalizado puede reunir tareas vinculadas aunque
            // él mismo no tenga origen. Sólo un alcance inequívoco es válido.
            var hijos = tareas.Values.Where(t => !string.IsNullOrWhiteSpace(t.PadreId))
                .ToLookup(t => t.PadreId, StringComparer.Ordinal);
            var pendientes = new Stack<MYGTareaCronograma>(hijos[seleccionada.Id]);
            visitados.Clear(); visitados.Add(seleccionada.Id);
            MYGPresupuestoDocumento descendiente = null;
            while (pendientes.TryPop(out var tarea))
            {
                if (!visitados.Add(tarea.Id))
                    throw new InvalidOperationException("La jerarquía de la tarea seleccionada contiene un ciclo.");
                var presupuesto = Vinculado(tarea);
                if (presupuesto != null)
                {
                    if (descendiente != null && descendiente.Id != presupuesto.Id)
                        throw new InvalidOperationException("La selección reúne varios presupuestos. Seleccione un presupuesto o una tarea de su interior para exportar su calendario.");
                    descendiente = presupuesto;
                }
                foreach (var hijo in hijos[tarea.Id]) pendientes.Push(hijo);
            }
            if (descendiente != null) return descendiente;
        }

        return documento.PresupuestoActivoId != null && presupuestos.TryGetValue(documento.PresupuestoActivoId, out var activo)
            ? activo : null;
    }
}
