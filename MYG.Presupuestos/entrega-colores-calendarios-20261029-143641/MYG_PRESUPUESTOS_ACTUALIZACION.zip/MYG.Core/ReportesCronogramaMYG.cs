using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace MYG_2027;

/// <summary>Instantáneas imprimibles y archivos abiertos de la planificación. No
/// cambia el presupuesto, las fechas de las tareas ni los costos del proyecto.</summary>
public static partial class MYGReportesCronograma
{
    private static readonly CultureInfo Espanol = CultureInfo.GetCultureInfo("es-PE");
    private const int PeriodosPorHoja = 8;
    private const int FilasPorHoja = 1000;
    private sealed record Periodo(DateTime Inicio, DateTime Fin, string Rotulo);
    private sealed record PartidaProgramada(MYGResultadoTarea Fila, MYGPresupuestoDocumento Presupuesto,
        ItemPresupuestoDelphin Partida, MYGCalculoPresupuesto Calculo);

    /// <summary>Gantt en A3 horizontal. Hasta ocho semanas o meses por hoja,
    /// conservando la tabla de tareas en cada tramo, también al exportar a Excel.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> Crear(MYGProyectoDocumento documento, MYGCronograma plan,
        MYGModoRutaCritica modoCritica = MYGModoRutaCritica.Simple)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var resultado = MYGMotorCronograma.Calcular(plan);
        var criticas = MYGRutasCriticasCronograma.Calcular(plan, resultado, modoCritica);
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        var opciones = LeerPresentacion(plan);
        var valoresBarra = new Dictionary<string, (decimal Cantidad, decimal Valorizado, string Unidad, string Moneda)>();
        if (new[] { "TextoIzquierda", "TextoCentro", "TextoDerecha" }.Any(k =>
            OpcionTexto(opciones, k) is "@Metrado" or "@Valorizado"))
            foreach (var partida in PrepararPartidas(documento, plan, out _))
                valoresBarra[partida.Fila.Tarea.Id] = (partida.Calculo.Cantidad(partida.Partida),
                    partida.Calculo.TotalPartida(partida.Partida), partida.Partida.Unidad ?? "", Moneda(partida.Presupuesto));
        DateTime inicio = resultado.Inicio, fin = resultado.Fin;
        foreach (var f in resultado.Filas)
        {
            if (f.Tarea.InicioBase.HasValue && f.Tarea.InicioBase.Value.Date < inicio) inicio = f.Tarea.InicioBase.Value.Date;
            if (f.Tarea.FinBase.HasValue && f.Tarea.FinBase.Value.Date > fin) fin = f.Tarea.FinBase.Value.Date;
        }
        var desdeImpresion = OpcionFecha(opciones, "InicioImpresion");
        var hastaImpresion = OpcionFecha(opciones, "FinImpresion");
        if (desdeImpresion.HasValue) inicio = desdeImpresion.Value;
        if (hastaImpresion.HasValue) fin = hastaImpresion.Value;
        if (fin < inicio) throw new InvalidDataException("La fecha final de impresión no puede ser anterior a la inicial.");
        bool semanal = (fin - inicio).TotalDays <= 112;
        var periodos = Periodos(inicio, fin, semanal);
        var reportes = new List<MYGHojaReporteProyecto>();
        var tramosFilas = PartirFilas(resultado.Filas);
        int numero = 0;
        foreach (var tramo in periodos.Chunk(PeriodosPorHoja))
        foreach (var filas in tramosFilas)
        {
            numero++;
            var h = Hoja("Gantt " + numero, new[] { 30, 44, 210, 40, 44, 68, 68, 82, 48, 42, 68, 68 }, tramo.Length, 62);
            string[] titulos = { "ID", "Modo", "Descripción", "Días cal.", "Duración", "Inicio", "Fin", "Predecesoras", "% avance", "Holgura", "Inicio base", "Fin base" };
            Encabezados(h, titulos, tramo, "DIAGRAMA GANTT · " + (semanal ? "SEMANAS" : "MESES"));
            int fila = 3;
            foreach (var f in filas)
            {
                var t = f.Tarea;
                bool esCritica = criticas.Contains(t.Id);
                bool resumen = t.EsResumen;
                Numero(h, fila, 1, f.Numero, "0", resumen);
                Texto(h, fila, 2, resumen ? "Resumen" : t.Modo == MYGModoTarea.Manual ? "Manual" : "Auto", resumen, "Centro");
                Texto(h, fila, 3, new string(' ', Math.Min(f.Nivel, 20) * 2) + t.Codigo + " " + t.Nombre +
                    (!resumen && f.DuracionDias == 0 ? " [hito]" : ""), resumen);
                Numero(h, fila, 4, f.DiasCalendario, "0", resumen);
                Numero(h, fila, 5, f.DuracionDias, "0\" d\"", resumen);
                Texto(h, fila, 6, Fecha(f.Inicio), resumen, "Centro");
                Texto(h, fila, 7, Fecha(f.Fin), resumen, "Centro");
                var dependencias = Texto(h, fila, 8, MYGMotorCronograma.FormatoPredecesoras(t, resultado.Filas));
                if (esCritica && t.Predecesoras.Any(d => criticas.Contains(d.PredecesoraId)))
                    dependencias.ColorTexto = OpcionColor(opciones, "ColorDependenciasCriticasArgb", dependencias.ColorTexto);
                Numero(h, fila, 9, t.Avance, "0.##\"%\"", resumen);
                Numero(h, fila, 10, f.HolguraDias, "0\" d\"", resumen);
                Texto(h, fila, 11, t.InicioBase.HasValue ? Fecha(t.InicioBase.Value) : "", resumen, "Centro");
                Texto(h, fila, 12, t.FinBase.HasValue ? Fecha(t.FinBase.Value) : "", resumen, "Centro");
                // El trazo inferior representa la línea base; el porcentaje
                // queda explícito en la tabla y el relleno oscuro marca el avance.
                int duracion = Math.Max(1, f.DuracionDias);
                decimal completados = duracion * t.Avance / 100m;
                var bloques = TramosPonderados(f, calendario);
                if (t.Partes.Count == 0 && MYGMotorCronograma.ConservaFechasDelphin(t) && t.FechasImportadasDelphin.Tramos.Count > 0)
                    bloques = t.FechasImportadasDelphin.Tramos.Select(s => (s.Inicio, s.Fin, 0m)).ToList();
                var columnasActivas = Enumerable.Range(0, tramo.Length).Where(p => bloques.Any(s =>
                    Solapan(s.Inicio, s.Fin, Mayor(tramo[p].Inicio, inicio), Menor(tramo[p].Fin, fin)))).ToArray();
                string izquierda = TextoPersonalizado(OpcionTexto(opciones, "TextoIzquierda"), f, valoresBarra);
                string centro = TextoPersonalizado(OpcionTexto(opciones, "TextoCentro"), f, valoresBarra);
                string derecha = TextoPersonalizado(OpcionTexto(opciones, "TextoDerecha"), f, valoresBarra);
                for (int p = 0; p < tramo.Length; p++)
                {
                    var periodo = tramo[p];
                    DateTime desde = Mayor(periodo.Inicio, inicio), hasta = Menor(periodo.Fin, fin);
                    bool activa = bloques.Any(s => Solapan(s.Inicio, s.Fin, desde, hasta));
                    bool baseActiva = t.InicioBase.HasValue && t.FinBase.HasValue &&
                        Solapan(t.InicioBase.Value, t.FinBase.Value, desde, hasta);
                    var c = Texto(h, fila, 13 + p, "", resumen, "Centro");
                    c.Fuente = "Arial";
                    if (activa)
                    {
                        if (resumen) { c.Contenido = "━"; c.ColorFondo = "DCE3EA"; c.ColorTexto = "243746"; }
                        else if (f.DuracionDias == 0) { c.Contenido = "◆"; c.ColorTexto = esCritica ? OpcionColor(opciones, "ColorCriticaArgb", "B72E36") : "2463A5"; }
                        else
                        {
                            int anteriores = desde == DateTime.MinValue.Date ? 0 : bloques.Sum(s =>
                                calendario.Contar(s.Inicio, Menor(s.Fin, desde.AddDays(-1))));
                            int enPeriodo = bloques.Sum(s => calendario.Contar(Mayor(s.Inicio, desde), Menor(s.Fin, hasta)));
                            bool avanzado = !OpcionBool(opciones, "OcultarAvance", false) &&
                                (completados > anteriores && enPeriodo > 0 || t.Avance == 100);
                            c.Contenido = avanzado ? "▓▓" : OpcionTexto(opciones, "AparienciaBarra") == "Contorno" ? "▱▱" : "░░";
                            c.ColorFondo = !avanzado && OpcionTexto(opciones, "AparienciaBarra") == "Contorno" ? "FFFFFF" :
                                esCritica ? "F6DADD" : "D7E8FA";
                            c.ColorTexto = avanzado ? OpcionColor(opciones, "ColorAvanceArgb", esCritica ? "A92532" : "1D5795") :
                                esCritica ? OpcionColor(opciones, "ColorCriticaArgb", "A92532") : "1D5795";
                        }
                    }
                    if (activa && columnasActivas.Length > 0)
                    {
                        var textos = new List<string>();
                        if (p == columnasActivas[0] && izquierda.Length > 0) textos.Add(izquierda);
                        if (p == columnasActivas[columnasActivas.Length / 2] && centro.Length > 0) textos.Add(centro);
                        if (p == columnasActivas[^1] && derecha.Length > 0) textos.Add(derecha);
                        if (textos.Count > 0) c.Contenido += "\n" + string.Join(" · ", textos);
                    }
                    if (baseActiva) c.Contenido += "\n―";
                    if (desde <= plan.FechaEstado.Date && hasta >= plan.FechaEstado.Date)
                    { c.Subrayado = true; if (!activa) c.ColorFondo = "FFF0E2"; }
                    c.Bordes = true;
                }
                h.AltosFilas[fila] = izquierda.Length > 0 || centro.Length > 0 || derecha.Length > 0 ? 45 : f.Tarea.InicioBase.HasValue ? 32 : 25;
                if (resumen)
                    for (int col = 1; col <= 12; col++) Celda(h, fila, col).ColorFondo = "EAF0F6";
                fila++;
            }
            if (filas.Length == 0) { Texto(h, fila, 3, "Sin tareas programadas."); fila++; }
            if (OpcionBool(opciones, "ImprimirLeyenda", true))
                Pie(h, fila, "Leyenda: ░ plan · ▓ avance · ◆ hito · ━ resumen · ― línea base · color crítico: ruta crítica. " +
                    "La columna naranja contiene la fecha de estado. Duraciones y holguras: días laborables completos.");
            else fila--;
            Terminar(h, fila);
            reportes.Add(new("CRONOGRAMA · GANTT DE SEGUIMIENTO", h,
                Datos(documento, plan, "Escala", (semanal ? "Semanal" : "Mensual") + " · " + Fecha(tramo[0].Inicio) + " al " + Fecha(tramo[^1].Fin))));
        }
        return AplicarPresentacion(reportes, plan);
    }

    /// <summary>Una fila por tarea, fechas ISO, sin fórmulas ejecutables al abrir
    /// el CSV en una hoja de cálculo. Sustituye el destino de manera atómica.</summary>
    public static void GuardarCsv(string ruta, MYGCronograma plan)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("Indique el archivo CSV de destino.", nameof(ruta));
        var r = MYGMotorCronograma.Calcular(plan);
        var s = new StringBuilder();
        void Fila(params string[] campos) => s.AppendJoin(',', campos.Select(CampoCsv)).Append("\r\n");
        Fila("ID", "ID estable", "ID padre", "Código", "Descripción", "Resumen", "Modo", "Días calendario", "Duración laborable", "Inicio", "Fin",
            "Predecesoras", "Avance %", "Holgura laborable", "Crítica", "Inicio base", "Fin base", "Duración base", "Responsables", "Notas", "Presupuesto ID", "Partida ID");
        foreach (var f in r.Filas)
        {
            var t = f.Tarea;
            Fila(Num(f.Numero), t.Id, t.PadreId, t.Codigo, t.Nombre, t.EsResumen ? "Sí" : "No",
                t.Modo == MYGModoTarea.Manual ? "Manual" : "Automática", Num(f.DiasCalendario), Num(f.DuracionDias),
                Iso(f.Inicio), Iso(f.Fin), MYGMotorCronograma.FormatoPredecesoras(t, r.Filas), Num(t.Avance),
                Num(f.HolguraDias), f.EsCritica ? "Sí" : "No", t.InicioBase.HasValue ? Iso(t.InicioBase.Value) : "",
                t.FinBase.HasValue ? Iso(t.FinBase.Value) : "", t.DuracionBase.HasValue ? Num(t.DuracionBase.Value) : "",
                string.Join("; ", t.Responsables ?? new()), t.Notas, t.PresupuestoId, t.PartidaId);
        }
        string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { File.WriteAllText(temporal, s.ToString(), new UTF8Encoding(true)); File.Move(temporal, ruta, true); }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    public static void GuardarExcel(string ruta, MYGProyectoDocumento documento, MYGCronograma plan,
        MYGModoRutaCritica modoCritica = MYGModoRutaCritica.Simple) =>
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, Crear(documento, plan, modoCritica));

    /// <summary>Consolida recursos reales por condiciones económicas iguales y
    /// programa toda la cantidad al inicio de la tarea. Los subanálisis se
    /// expanden mediante el mismo motor que calcula el presupuesto.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> CrearAdquisiciones(MYGProyectoDocumento documento, MYGCronograma plan, string presupuestoId = null)
    {
        var partidas = PrepararPartidas(documento, plan, out _, presupuestoId);
        string titulo = "CALENDARIO DE ADQUISICIONES DEL " + (presupuestoId == null ? "PROYECTO" : "PRESUPUESTO");
        IReadOnlyList<KeyValuePair<string, string>> Metadatos(string etiqueta = null, string valor = null)
        {
            var datos = Datos(documento, plan, etiqueta, valor).ToList();
            datos.Add(new("Presupuesto", presupuestoId == null ? "Todos los presupuestos" :
                documento.Presupuestos.Single(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)).ToString()));
            return datos.AsReadOnly();
        }
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        var recursos = new Dictionary<ClaveRecurso, RecursoProgramado>();
        foreach (var p in partidas)
        {
            var catalogo = p.Presupuesto.Costos.Insumos.ToDictionary(i => i.Id, StringComparer.Ordinal);
            foreach (var i in p.Calculo.Consolidar(p.Partida))
            {
                // Sólo un recurso del catálogo identifica algo adquirible.
                // DIRECTO, PORCENTAJE y REDONDEO sintéticos no se convierten en
                // subcontratos ni en compras ficticias.
                if (!catalogo.TryGetValue(i.Clave, out var fuente)) continue;
                var clave = new ClaveRecurso(Moneda(p.Presupuesto), i.Grupo, i.Codigo ?? "", i.Descripcion ?? "",
                    string.IsNullOrWhiteSpace(fuente.Proveedor) ? "SIN CLASIFICAR" : fuente.Proveedor.Trim(), i.Unidad ?? "", i.Precio);
                if (!recursos.TryGetValue(clave, out var recurso)) recursos.Add(clave, recurso = new());
                foreach (var tramo in TramosPonderados(p.Fila, calendario))
                {
                    var mes = Mes(tramo.Inicio);
                    recurso.Cantidades[mes] = recurso.Cantidades.GetValueOrDefault(mes) + i.Cantidad * tramo.Peso;
                    recurso.Costos[mes] = recurso.Costos.GetValueOrDefault(mes) + i.Total * tramo.Peso;
                }
            }
        }
        if (recursos.Count == 0)
        {
            var vacio = SinDatos(documento, plan, titulo, "Sin recursos reales requeridos por las partidas programadas.");
            return new[] { new MYGHojaReporteProyecto(titulo, vacio.Hoja, Metadatos()) };
        }
        var reportes = new List<MYGHojaReporteProyecto>();
        int numero = 0;
        foreach (var moneda in recursos.GroupBy(r => r.Key.Moneda, StringComparer.OrdinalIgnoreCase))
        {
            var ordenados = moneda.OrderBy(r => r.Key.Grupo).ThenBy(r => r.Key.Codigo, StringComparer.OrdinalIgnoreCase)
                .ThenBy(r => r.Key.Descripcion, StringComparer.OrdinalIgnoreCase).ThenBy(r => r.Key.Proveedor, StringComparer.OrdinalIgnoreCase).ToArray();
            var fechas = ordenados.SelectMany(r => r.Value.Cantidades.Keys).ToArray();
            var periodos = Periodos(fechas.Min(), fechas.Max(), false);
            foreach (var tramo in periodos.Chunk(PeriodosPorHoja))
            foreach (var filas in ordenados.Chunk(FilasPorHoja))
            {
                var h = Hoja("Adquisiciones " + ++numero, new[] { 74, 72, 220, 42, 140, 84, 74, 94 }, tramo.Length, 66);
                Encabezados(h, new[] { "Grupo", "Código", "Recurso", "Unid.", "Proveedor", "Cant. tramo", "Precio " + moneda.Key, "Costo tramo " + moneda.Key }, tramo, "CANTIDADES REQUERIDAS AL INICIO DE LAS TAREAS");
                var nivelesTitulos = new Dictionary<int, int>();
                MYGGrupoRecurso? grupoAnterior = null;
                int fila = 3;
                foreach (var r in filas)
                {
                    if (grupoAnterior != r.Key.Grupo)
                    {
                        // Título de grupo independiente de las filas de recursos:
                        // permite colorearlo sin cambiar cantidades ni totales.
                        nivelesTitulos.Add(fila, 0);
                        for (int c = 1; c <= h.Columnas; c++)
                            Texto(h, fila, c, c == 1 ? MYGMotorPresupuestos.Grupo(r.Key.Grupo) : "", true).ColorFondo = "EAF0F6";
                        h.RangosCombinados.Add("A" + fila + ":H" + fila);
                        h.AltosFilas[fila++] = 25;
                        grupoAnterior = r.Key.Grupo;
                    }
                    Texto(h, fila, 1, MYGMotorPresupuestos.Grupo(r.Key.Grupo)); Texto(h, fila, 2, r.Key.Codigo);
                    Texto(h, fila, 3, r.Key.Descripcion); Texto(h, fila, 4, r.Key.Unidad, alineacion: "Centro");
                    Texto(h, fila, 5, r.Key.Proveedor); Numero(h, fila, 6, tramo.Sum(m => r.Value.Cantidades.GetValueOrDefault(m.Inicio)), "#,##0.0000");
                    Numero(h, fila, 7, r.Key.Precio, "#,##0.0000"); Numero(h, fila, 8, tramo.Sum(m => r.Value.Costos.GetValueOrDefault(m.Inicio)));
                    for (int n = 0; n < tramo.Length; n++) Numero(h, fila, 9 + n, r.Value.Cantidades.GetValueOrDefault(tramo[n].Inicio), "#,##0.0000");
                    h.AltosFilas[fila++] = 30;
                }
                Texto(h, fila, 5, "TOTAL RECURSOS · " + moneda.Key, true);
                Numero(h, fila, 8, filas.Sum(r => tramo.Sum(m => r.Value.Costos.GetValueOrDefault(m.Inicio))), negrita: true); h.CeldaTotal = "H" + fila;
                Pie(h, ++fila, "Supuesto: se requiere cada fracción del recurso al inicio de su parte; las tareas sin partes requieren el 100% al inicio, sin plazos de proveedor ni inventario. " +
                    "Las columnas mensuales muestran cantidades en la unidad de cada recurso; no se suman unidades distintas. " +
                    "Incluye recursos reales del ACU y subanálisis; excluye precios directos sin recursos, porcentajes y ajustes. " +
                    "Totales sólo de las filas y meses de esta hoja. No duplica resúmenes. Cada moneda se presenta por separado.");
                Terminar(h, fila);
                reportes.Add(new(titulo + " · " + moneda.Key, h,
                    Metadatos("Tramo mensual", Fecha(tramo[0].Inicio) + " al " + Fecha(tramo[^1].Fin)), nivelesTitulos: nivelesTitulos));
            }
        }
        return AplicarPresentacion(reportes, plan);
    }

    private sealed record ClaveRecurso(string Moneda, MYGGrupoRecurso Grupo, string Codigo, string Descripcion,
        string Proveedor, string Unidad, decimal Precio);
    private sealed class RecursoProgramado
    {
        internal Dictionary<DateTime, decimal> Cantidades = new();
        internal Dictionary<DateTime, decimal> Costos = new();
    }

    private static List<PartidaProgramada> PrepararPartidas(MYGProyectoDocumento documento, MYGCronograma plan,
        out MYGResultadoCronograma resultado, string presupuestoId = null)
    {
        ArgumentNullException.ThrowIfNull(documento);
        resultado = MYGMotorCronograma.Calcular(plan);
        if (presupuestoId != null && !documento.Presupuestos.Any(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("El presupuesto seleccionado ya no existe en el proyecto.");
        var copia = MYGProyectoStorage.Copia(documento);
        var presupuestos = copia.Presupuestos.ToDictionary(p => p.Id, StringComparer.OrdinalIgnoreCase);
        var calculos = new Dictionary<string, MYGCalculoPresupuesto>(StringComparer.OrdinalIgnoreCase);
        var vistas = new HashSet<(string Presupuesto, string Partida)>();
        var partidas = new List<PartidaProgramada>();
        foreach (var f in resultado.Filas.Where(f => !f.Tarea.EsResumen))
        {
            var t = f.Tarea;
            if (presupuestoId != null && !string.Equals(t.PresupuestoId, presupuestoId, StringComparison.OrdinalIgnoreCase)) continue;
            if (string.IsNullOrWhiteSpace(t.PartidaId)) continue;
            if (string.IsNullOrWhiteSpace(t.PresupuestoId) || !presupuestos.TryGetValue(t.PresupuestoId, out var p))
                throw new InvalidDataException("La tarea «" + t.Nombre + "» refiere a un presupuesto que ya no existe. Sincronice el cronograma.");
            var i = p.Items.FirstOrDefault(i => string.Equals(i.Id, t.PartidaId, StringComparison.OrdinalIgnoreCase));
            if (i == null || MYGProyectoStorage.EsTitulo(i))
                throw new InvalidDataException("La tarea «" + t.Nombre + "» no refiere a una partida vigente. Sincronice el cronograma.");
            if (!vistas.Add((p.Id.ToUpperInvariant(), i.Id.ToUpperInvariant())))
                throw new InvalidDataException("La partida «" + i.Descripcion + "» está vinculada a más de una tarea. Mantenga un solo vínculo para no duplicar sus costos y recursos.");
            if (!calculos.TryGetValue(p.Id, out var calculo))
            {
                MYGProyectoStorage.ValidarPresupuesto(p);
                calculos.Add(p.Id, calculo = MYGMotorPresupuestos.CrearCalculo(p));
            }
            partidas.Add(new(f, p, i, calculo));
        }
        return partidas;
    }

    private static Dictionary<DateTime, decimal> Repartir(PartidaProgramada p, MYGCalendarioEntero calendario)
    {
        decimal total = p.Calculo.TotalPartida(p.Partida);
        if (p.Fila.Tarea.Partes.Count > 0 ||
            MYGMotorCronograma.ConservaFechasDelphin(p.Fila.Tarea) && p.Fila.Tarea.FechasImportadasDelphin.Tramos.Count > 0)
        {
            // Un tramo representa su fracción del metrado, no todos los días
            // entre el primer trabajo y una movilización al final de la obra.
            var pesos = new SortedDictionary<DateTime, decimal>();
            foreach (var tramo in TramosPonderados(p.Fila, calendario))
            {
                var mesesTramo = Periodos(tramo.Inicio, tramo.Fin, false).Select(m =>
                    (Mes: m.Inicio, Dias: calendario.Contar(Mayor(tramo.Inicio, m.Inicio), Menor(tramo.Fin, m.Fin))))
                    .Where(m => m.Dias > 0).ToList();
                int diasTramo = mesesTramo.Sum(m => m.Dias);
                if (diasTramo == 0) pesos[Mes(tramo.Inicio)] = pesos.GetValueOrDefault(Mes(tramo.Inicio)) + tramo.Peso;
                else foreach (var mes in mesesTramo) pesos[mes.Mes] = pesos.GetValueOrDefault(mes.Mes) + tramo.Peso * mes.Dias / diasTramo;
            }
            var importado = new Dictionary<DateTime, decimal>(); decimal peso = 0, asignadoTramos = 0; int numero = 0;
            foreach (var mes in pesos)
            {
                peso += mes.Value;
                decimal acumulado = ++numero == pesos.Count ? total : MYGMotorPresupuestos.Dinero(p.Presupuesto, total * peso);
                importado[mes.Key] = acumulado - asignadoTramos; asignadoTramos = acumulado;
            }
            return importado;
        }
        var meses = new SortedDictionary<DateTime, int>();
        if (p.Fila.DuracionDias > 0)
            foreach (var mes in Periodos(p.Fila.Inicio, p.Fila.Fin, false))
            {
                int diasMes = calendario.Contar(Mayor(p.Fila.Inicio, mes.Inicio), Menor(p.Fila.Fin, mes.Fin));
                if (diasMes > 0) meses.Add(mes.Inicio, diasMes);
            }
        if (meses.Count == 0) return new() { [Mes(p.Fila.Inicio)] = total };
        int dias = meses.Values.Sum(), n = 0, acumulados = 0;
        decimal asignado = 0;
        var resultado = new Dictionary<DateTime, decimal>();
        foreach (var mes in meses)
        {
            acumulados += mes.Value;
            // Redondear acumulados evita que muchos meses pequeños produzcan
            // un residuo final negativo por sumar redondeos independientes.
            decimal objetivo = ++n == meses.Count ? total : MYGMotorPresupuestos.Dinero(p.Presupuesto, total * acumulados / dias);
            resultado.Add(mes.Key, objetivo - asignado); asignado = objetivo;
        }
        return resultado;
    }

    private static List<(DateTime Inicio, DateTime Fin, decimal Peso)> TramosPonderados(MYGResultadoTarea fila,
        MYGCalendarioEntero calendario)
    {
        var tarea = fila.Tarea;
        if (tarea.Partes.Count > 0)
        {
            long ordinal = calendario.Primero(fila.Inicio);
            return tarea.Partes.Select(p => (calendario.Fecha(ordinal + p.DesfaseInicioDias),
                calendario.Fecha(ordinal + p.DesfaseInicioDias + p.DuracionDias - 1), p.Porcentaje / 100m)).ToList();
        }
        var tramos = MYGMotorCronograma.ConservaFechasDelphin(tarea) ? tarea.FechasImportadasDelphin.Tramos : new();
        decimal total = tramos.Sum(t => Math.Max(0, t.Porcentaje));
        bool porcentajes = total > 0;
        if (!porcentajes) total = tramos.Sum(t => Math.Max(0, t.Cantidad));
        if (total <= 0) return new() { (fila.Inicio, fila.Fin, 1) };
        var resultado = new List<(DateTime, DateTime, decimal)>(); decimal asignado = 0;
        for (int n = 0; n < tramos.Count; n++)
        {
            var tramo = tramos[n];
            decimal peso = n == tramos.Count - 1 ? 1 - asignado : Math.Max(0, porcentajes ? tramo.Porcentaje : tramo.Cantidad) / total;
            resultado.Add((tramo.Inicio, tramo.Fin, peso)); asignado += peso;
        }
        return resultado;
    }

    private static string TextoPersonalizado(string token, MYGResultadoTarea fila,
        IReadOnlyDictionary<string, (decimal Cantidad, decimal Valorizado, string Unidad, string Moneda)> valores)
    {
        if (token == "@Inicio") return Fecha(fila.Inicio);
        if (token == "@Fin") return Fecha(fila.Fin);
        if (token is "@Duración" or "@Duracion") return fila.DuracionDias + " d";
        if (token is "@Descripción" or "@Descripcion") return fila.Tarea.Nombre ?? "";
        // No se inventan cantidades ni monedas para resúmenes o tareas libres.
        if (fila.Tarea.EsResumen || !valores.TryGetValue(fila.Tarea.Id, out var dato)) return "";
        return token switch
        {
            "@Metrado" => dato.Cantidad.ToString("#,##0.####", Espanol) + " " + dato.Unidad,
            "@Valorizado" => dato.Moneda + " " + dato.Valorizado.ToString("#,##0.00", Espanol),
            _ => ""
        };
    }

    // El contrato se guarda como JSON en OpcionesVista para evitar acoplar el
    // motor de informes a controles de Windows Forms. Opciones antiguas o JSON
    // desconocido conservan los valores de impresión predeterminados.
    private static JsonElement LeerPresentacion(MYGCronograma plan)
    {
        if (plan.OpcionesVista == null || !plan.OpcionesVista.TryGetValue("Presentacion", out var json) ||
            string.IsNullOrWhiteSpace(json)) return default;
        try
        {
            using var documento = JsonDocument.Parse(json);
            return documento.RootElement.ValueKind == JsonValueKind.Object ? documento.RootElement.Clone() : default;
        }
        catch (JsonException) { return default; }
    }
    private static string OpcionTexto(JsonElement opciones, string nombre) =>
        opciones.ValueKind == JsonValueKind.Object && opciones.TryGetProperty(nombre, out var valor) &&
        valor.ValueKind == JsonValueKind.String ? valor.GetString() ?? "" : "";
    private static bool OpcionBool(JsonElement opciones, string nombre, bool defecto) =>
        opciones.ValueKind == JsonValueKind.Object && opciones.TryGetProperty(nombre, out var valor) &&
        valor.ValueKind is JsonValueKind.True or JsonValueKind.False ? valor.GetBoolean() : defecto;
    private static string OpcionColor(JsonElement opciones, string nombre, string defecto) =>
        opciones.ValueKind == JsonValueKind.Object && opciones.TryGetProperty(nombre, out var valor) &&
        valor.ValueKind == JsonValueKind.Number && valor.TryGetInt32(out int argb) ?
            (argb & 0x00FFFFFF).ToString("X6", CultureInfo.InvariantCulture) : defecto;
    private static DateTime? OpcionFecha(JsonElement opciones, string nombre) =>
        opciones.ValueKind == JsonValueKind.Object && opciones.TryGetProperty(nombre, out var valor) &&
        valor.ValueKind == JsonValueKind.String && valor.TryGetDateTime(out var fecha) ? fecha.Date : null;

    private static IReadOnlyList<MYGHojaReporteProyecto> AplicarPresentacion(List<MYGHojaReporteProyecto> reportes,
        MYGCronograma plan)
    {
        var opciones = LeerPresentacion(plan);
        if (opciones.ValueKind != JsonValueKind.Object) return reportes.AsReadOnly();
        string papel = OpcionTexto(opciones, "Papel");
        DateTime ahora = DateTime.Now;
        for (int i = 0; i < reportes.Count; i++)
        {
            var hoja = reportes[i].Hoja;
            if (papel is "A2" or "A3" or "A4" or "A5" or "A6" or "B4" or "B5" or "Carta" or "Oficio") hoja.TamanoPapel = papel;
            hoja.OrientacionPagina = OpcionBool(opciones, "Horizontal", true) ? "Horizontal" : "Vertical";
            if (OpcionBool(opciones, "ImprimirInformacionPagina", false))
            {
                string tipo = OpcionTexto(opciones, "TipoInformacionPagina");
                string informacion = tipo switch
                {
                    "Fecha y Hora" or "Fecha y hora" => ahora.ToString("dd/MM/yyyy HH:mm", Espanol),
                    "Número" or "Numero" => (i + 1).ToString(Espanol),
                    "Número del total" or "Numero del Total" or "Número del Total" => (i + 1) + " de " + reportes.Count,
                    "Total" => reportes.Count.ToString(Espanol),
                    "Usuario" => Environment.UserName,
                    _ => ""
                };
                string texto = string.Join(" · ", new[] { OpcionTexto(opciones, "TituloPagina"), informacion }.Where(t => !string.IsNullOrWhiteSpace(t)));
                if (texto.Length > 0) Pie(hoja, ++hoja.Filas, texto);
            }
            Terminar(hoja, hoja.Filas);
        }
        return reportes.AsReadOnly();
    }

    private static MYGHojaReporteProyecto SinDatos(MYGProyectoDocumento d, MYGCronograma p, string titulo, string mensaje)
    {
        var h = Hoja(titulo, new[] { 400, 400 }, 0, 0);
        Texto(h, 1, 1, mensaje); h.RangosCombinados.Add("A1:B1"); h.AltosFilas[1] = 40; Terminar(h, 2);
        return AplicarPresentacion(new() { new(titulo, h, Datos(d, p)) }, p)[0];
    }

    private static MYGResultadoTarea[][] PartirFilas(IReadOnlyList<MYGResultadoTarea> filas) =>
        filas.Count == 0 ? new[] { Array.Empty<MYGResultadoTarea>() } : filas.Chunk(FilasPorHoja).ToArray();
    private static MYGHojaMetrado Hoja(string nombre, int[] anchos, int periodos, int anchoPeriodo)
    {
        var h = new MYGHojaMetrado
        {
            Nombre = nombre, Filas = 2, Columnas = anchos.Length + periodos, CeldaTotal = "A1",
            TamanoPapel = "A3", OrientacionPagina = "Horizontal", FormatoNumeroPredeterminado = "#,##0.00",
            LineasDivision = false, Encabezados = false, ImprimirLineasDivision = false, ImprimirEncabezados = false,
            RepetirTitulos = true, FilasInmovilizadas = 2, ColumnasInmovilizadas = Math.Min(3, anchos.Length),
            MargenIzquierdo = .35m, MargenDerecho = .35m, MargenSuperior = .35m, MargenInferior = .35m,
            AltosFilas = new() { [1] = 27, [2] = 30 }
        };
        for (int c = 1; c <= h.Columnas; c++) h.AnchosColumnas[c] = c <= anchos.Length ? anchos[c - 1] : anchoPeriodo;
        return h;
    }

    private static void Encabezados(MYGHojaMetrado h, string[] titulos, Periodo[] periodos, string banda)
    {
        for (int c = 1; c <= h.Columnas; c++)
        {
            Texto(h, 1, c, "", true, "Centro").ColorFondo = "DCE6F1";
            Texto(h, 2, c, "", true, "Centro").ColorFondo = "EAF0F6";
        }
        Texto(h, 1, 1, "PLANIFICACIÓN DEL PROYECTO", true).ColorFondo = "DCE6F1";
        h.RangosCombinados.Add("A1:" + MYGHojaCalculo.Columna(titulos.Length) + "1");
        for (int c = 0; c < titulos.Length; c++) Texto(h, 2, c + 1, titulos[c], true, c == 2 ? "Izquierda" : "Centro").ColorFondo = "EAF0F6";
        if (periodos.Length == 0) return;
        int inicial = titulos.Length + 1;
        Texto(h, 1, inicial, banda, true, "Centro").ColorFondo = "DCE6F1";
        if (periodos.Length > 1) h.RangosCombinados.Add(MYGHojaCalculo.Columna(inicial) + "1:" + MYGHojaCalculo.Columna(h.Columnas) + "1");
        for (int p = 0; p < periodos.Length; p++) Texto(h, 2, inicial + p, periodos[p].Rotulo, true, "Centro").ColorFondo = "EAF0F6";
    }

    private static MYGCeldaHoja Texto(MYGHojaMetrado h, int fila, int columna, string valor, bool negrita = false, string alineacion = "Izquierda")
    {
        // Las cadenas numéricas, códigos y textos que empiezan por '=' conservan
        // su identidad literal tanto en el motor como en el archivo XLSX.
        valor ??= "";
        string contenido = MYGHojaCalculo.IntentarNumero(valor, out _) || valor.StartsWith('=')
            ? "=\"" + valor.Replace("\"", "\"\"") + "\"" : valor;
        var celda = new MYGCeldaHoja
        {
            Contenido = contenido, Negrita = negrita, Fuente = "Arial Narrow", TamanoFuente = 9,
            FormatoNumero = "@", ColorTexto = "172D45", ColorFondo = "FFFFFF", Bordes = true,
            AlineacionPersonalizada = true, AlineacionHorizontal = alineacion, AjustarTexto = true
        };
        h.Celdas[MYGHojaCalculo.Columna(columna) + fila] = celda;
        return celda;
    }
    private static void Numero(MYGHojaMetrado h, int fila, int columna, decimal valor, string formato = "#,##0.00", bool negrita = false)
    {
        var c = Texto(h, fila, columna, "", negrita, "Derecha"); c.Contenido = Num(valor); c.FormatoNumero = formato;
    }
    private static MYGCeldaHoja Celda(MYGHojaMetrado h, int fila, int columna) =>
        h.Celdas.TryGetValue(MYGHojaCalculo.Columna(columna) + fila, out var c) ? c : Texto(h, fila, columna, "");
    private static void Pie(MYGHojaMetrado h, int fila, string texto)
    {
        var c = Texto(h, fila, 1, texto); c.TamanoFuente = 8; c.ColorTexto = "52667A"; c.Bordes = false;
        h.RangosCombinados.Add("A" + fila + ":" + MYGHojaCalculo.Columna(h.Columnas) + fila); h.AltosFilas[fila] = 48;
    }
    private static void Terminar(MYGHojaMetrado h, int fila)
    {
        h.Filas = Math.Max(2, fila); h.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(h.Columnas) + h.Filas;
        MYGHojaCalculo.Validar(h);
    }
    private static IReadOnlyList<KeyValuePair<string, string>> Datos(MYGProyectoDocumento documento, MYGCronograma plan,
        string etiqueta = null, string valor = null)
    {
        string ubicacion = string.Join(" / ", new[] { documento.Datos?.Departamento, documento.Datos?.Provincia, documento.Datos?.Distrito }
            .Where(s => !string.IsNullOrWhiteSpace(s)));
        var datos = new List<KeyValuePair<string, string>>
        {
            new("Proyecto", documento.Nombre ?? ""), new("Propietario", documento.Datos?.Propietario ?? "No registrado"),
            new("Ubicación", ubicacion), new("Fecha de estado", Fecha(plan.FechaEstado)),
            new("Calendario", string.Join(", ", plan.Calendario.DiasLaborables.OrderBy(d => ((int)d + 6) % 7)
                .Select(d => Espanol.DateTimeFormat.GetAbbreviatedDayName(d))) + " · " + Num(plan.Calendario.HorasPorDia) + " h/día"),
            new("Línea base", plan.Tareas.Any(t => t.InicioBase.HasValue) ? "Fechas base en tabla y trazo inferior en Gantt" : "Sin establecer")
        };
        if (etiqueta != null) datos.Add(new(etiqueta, valor ?? ""));
        return datos.AsReadOnly();
    }

    private static Periodo[] Periodos(DateTime inicio, DateTime fin, bool semanal)
    {
        inicio = inicio.Date; fin = fin.Date;
        if (fin < inicio) fin = inicio;
        var lista = new List<Periodo>();
        DateTime actual;
        if (semanal)
        {
            int retroceso = ((int)inicio.DayOfWeek + 6) % 7;
            actual = inicio.Ticks >= TimeSpan.TicksPerDay * retroceso ? inicio.AddDays(-retroceso) : DateTime.MinValue.Date;
        }
        else actual = Mes(inicio);
        while (actual <= fin)
        {
            DateTime termino = semanal ? SumarDias(actual, 6) : new DateTime(actual.Year, actual.Month, DateTime.DaysInMonth(actual.Year, actual.Month));
            lista.Add(new(actual, termino, semanal ? actual.ToString("dd MMM", Espanol) + "\n" + actual.Year : actual.ToString("MMM yyyy", Espanol)));
            if (termino >= fin || termino == DateTime.MaxValue.Date) break;
            actual = termino.AddDays(1);
        }
        return lista.ToArray();
    }
    private static bool Solapan(DateTime a, DateTime b, DateTime c, DateTime d) => a.Date <= d.Date && b.Date >= c.Date;
    private static DateTime Menor(DateTime a, DateTime b) => a < b ? a : b;
    private static DateTime Mayor(DateTime a, DateTime b) => a > b ? a : b;
    private static DateTime Mes(DateTime d) => new(d.Year, d.Month, 1);
    private static DateTime SumarDias(DateTime d, int dias) => (DateTime.MaxValue.Date - d).Days < dias ? DateTime.MaxValue.Date : d.AddDays(dias);
    private static string Moneda(MYGPresupuestoDocumento p) => (p.Costos.Moneda ?? "S/").Trim().ToUpperInvariant();
    private static string Fecha(DateTime fecha) => fecha.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
    private static string Iso(DateTime fecha) => fecha.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    private static string Num(decimal numero) => numero.ToString(CultureInfo.InvariantCulture);
    private static string CampoCsv(string valor)
    {
        valor ??= "";
        string significativo = valor.TrimStart(' ', '\t', '\r', '\n', '\uFEFF');
        if (significativo.Length > 0 && "=+-@".Contains(significativo[0])) valor = "'" + valor;
        return "\"" + valor.Replace("\"", "\"\"") + "\"";
    }
}
