using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MYG_2027;

public sealed class MYGOpcionesRespaldoS10
{
    public string Servidor { get; set; } = "localhost";
    public string RutaPlantilla { get; set; }
}

internal sealed record MYGSolicitudSqlCmdS10(string Servidor, string BaseDatos, string Sql, TimeSpan TiempoMaximo);
internal sealed record MYGRespuestaSqlCmdS10(int CodigoSalida, string Salida, string Errores);
internal interface IMYGSqlCmdS10Runner
{
    MYGRespuestaSqlCmdS10 Ejecutar(MYGSolicitudSqlCmdS10 solicitud);
}

/// <summary>Respaldo nativo creado por una instancia local SQL Server 2005.
/// La plantilla debe proceder del usuario y estar vacía de presupuestos.
/// No ejecuta S10 ni su procesador F9.</summary>
public static class MYGExportacionS10S2K
{
    private sealed record Archivo(string Logico, string Tipo, string Ruta);
    private static readonly TimeSpan Consulta = TimeSpan.FromMinutes(2);
    private static readonly TimeSpan Operacion = TimeSpan.FromMinutes(15);
    private static readonly Encoding UnicodeEstricto = new UnicodeEncoding(false, false, true);

    public static MYGResultadoExportacionS10 Guardar(string ruta, MYGProyectoDocumento proyecto,
        MYGOpcionesExportacionS10 opciones, MYGOpcionesRespaldoS10 respaldo, Action<string> progreso = null)
        => Guardar(ruta, proyecto, opciones, respaldo, progreso, new SqlCmdLocal());

    internal static MYGResultadoExportacionS10 Guardar(string ruta, MYGProyectoDocumento proyecto,
        MYGOpcionesExportacionS10 opciones, MYGOpcionesRespaldoS10 respaldo, Action<string> progreso,
        IMYGSqlCmdS10Runner runner)
    {
        ArgumentNullException.ThrowIfNull(respaldo); ArgumentNullException.ThrowIfNull(runner);
        string destino = RutaArchivo(ruta, ".s2k");
        string plantilla = RutaArchivo(respaldo.RutaPlantilla, ".s2k", ".bak");
        if (MismaRuta(destino, plantilla)) throw new InvalidDataException("El destino S2K no puede ser la plantilla original.");
        if (!Directory.Exists(Path.GetDirectoryName(destino))) throw new DirectoryNotFoundException("La carpeta de destino no existe.");
        ComprobarFirma(plantilla);
        string servidor = ServidorLocal(respaldo.Servidor);
        var documento = MYGExportacionS10Sql.CrearDocumento(proyecto, opciones, progreso);
        var avisos = documento.Resultado.Advertencias.ToList();
        string token = Guid.NewGuid().ToString("N");
        string baseTemporal = "MYG_S2K_" + token;
        string copiaPlantilla = null, archivoRespaldo = null, temporalDestino = null;
        var archivos = new List<Archivo>();
        bool restauracionIntentada = false, timeoutSql = false, copiaCreada = false,
            respaldoIntentado = false, destinoTemporalCreado = false;
        Exception fallo = null;
        string fase = "METADATOS";

        MYGRespuestaSqlCmdS10 Ejecutar(string etapa, string baseDatos, string sql, TimeSpan tiempo)
        {
            fase = etapa;
            var respuesta = runner.Ejecutar(new(servidor, baseDatos, "-- MYG_S2K:" + etapa + "\nSET NOCOUNT ON;\n" + sql, tiempo));
            if (respuesta == null || respuesta.CodigoSalida != 0)
                throw new InvalidDataException("SQLCMD no completó " + etapa + ". " + Diagnostico(respuesta));
            return respuesta;
        }

        try
        {
            progreso?.Invoke("Comprobando SQL Server 2005 local y sus carpetas…");
            var meta = Ejecutar("METADATOS", "master", SqlMetadatos(), Consulta);
            string version = Marcador(meta.Salida, "MYG_VERSION");
            if (!Version.TryParse(version, out var motor) || motor.Major != 9)
                throw new InvalidDataException("La exportación S2K requiere SQL Server 2005 (versión 9). Motor detectado: " + version + ".");
            string maquina = LeerHex(Marcador(meta.Salida, "MYG_MACHINE"));
            string fisica = LeerHex(Marcador(meta.Salida, "MYG_PHYSICAL"));
            string equipo = string.IsNullOrWhiteSpace(fisica) ? maquina : fisica;
            if (!string.Equals(equipo, Environment.MachineName, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("La instancia resuelta no está en este equipo. No se admiten alias hacia servidores remotos.");
            string backupDir = CarpetaLocal(LeerHex(Marcador(meta.Salida, "MYG_BACKUP")));
            string dataDir = CarpetaLocal(LeerHex(Marcador(meta.Salida, "MYG_DATA")));
            string logDir = CarpetaLocal(LeerHex(Marcador(meta.Salida, "MYG_LOG")));
            copiaPlantilla = Path.Combine(backupDir, "myg_s2k_" + token + "_plantilla.s2k");
            archivoRespaldo = Path.Combine(backupDir, "myg_s2k_" + token + "_resultado.s2k");
            if (File.Exists(copiaPlantilla) || File.Exists(archivoRespaldo))
                throw new IOException("Ya existe un archivo de trabajo con el identificador de esta exportación.");
            progreso?.Invoke("Copiando la plantilla vacía a la carpeta local de respaldos…");
            CopiarNuevo(plantilla, copiaPlantilla);
            copiaCreada = true;
            var header = Ejecutar("HEADER", "master", SqlHeader(copiaPlantilla), Consulta);
            string[] datos = Marcador(header.Salida, "MYG_HEADER").Split('|');
            if (datos.Length != 4 || datos[0] != "1" || datos[1] != "1" || datos[3] != "0"
                || !int.TryParse(datos[2], NumberStyles.None, CultureInfo.InvariantCulture, out int formato) || formato < 515)
                throw new InvalidDataException("La plantilla debe contener un único respaldo completo de base de datos, posición 1, sin snapshot.");
            var listado = Ejecutar("FILELIST", "master", SqlFilelist(copiaPlantilla), Consulta);
            var logicos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string registro in Marcadores(listado.Salida, "MYG_FILE"))
            {
                string[] campos = registro.Split('|');
                if (campos.Length != 2 || campos[1] is not ("D" or "L"))
                    throw new InvalidDataException("La plantilla contiene un tipo de archivo no admitido para SQL Server 2005.");
                string logico = LeerHex(campos[0]); TextoSeguro(logico, "nombre lógico");
                if (string.IsNullOrWhiteSpace(logico) || logico.Length > 128 || !logicos.Add(logico))
                    throw new InvalidDataException("La plantilla contiene nombres lógicos vacíos, duplicados o demasiado largos.");
                int indice = archivos.Count;
                string extension = campos[1] == "L" ? ".ldf" : indice == 0 ? ".mdf" : ".ndf";
                string fisico = Path.Combine(campos[1] == "L" ? logDir : dataDir,
                    "myg_s2k_" + token + "_" + indice.ToString(CultureInfo.InvariantCulture) + extension);
                if (File.Exists(fisico)) throw new IOException("Ya existe un archivo físico de la base temporal.");
                archivos.Add(new(logico, campos[1], fisico));
            }
            if (archivos.Count is < 2 or > 256 || !archivos.Any(a => a.Tipo == "D") || !archivos.Any(a => a.Tipo == "L"))
                throw new InvalidDataException("No se obtuvo una lista completa de archivos de datos y registro de la plantilla.");
            progreso?.Invoke("Restaurando una base temporal independiente…");
            restauracionIntentada = true;
            Ejecutar("RESTORE", "master", SqlRestaurar(baseTemporal, copiaPlantilla, archivos), Operacion);
            progreso?.Invoke("Comprobando que la plantilla no contiene presupuestos…");
            var vacia = Ejecutar("PLANTILLA", baseTemporal, Propiedad(baseTemporal, archivos, false) + SqlPlantillaVacia(), Consulta);
            if (Marcador(vacia.Salida, "MYG_EMPTY") != "1") throw new InvalidDataException("No se confirmó una plantilla S10 vacía.");
            progreso?.Invoke("Importando el proyecto en la base temporal…");
            Ejecutar("IMPORTAR", baseTemporal, Propiedad(baseTemporal, archivos, false) + Encapsular(documento.Contenido), Operacion);
            progreso?.Invoke("Creando el respaldo nativo S2K con checksum…");
            if (File.Exists(archivoRespaldo)) throw new IOException("El archivo temporal de respaldo ya existe; no se sobrescribirá.");
            respaldoIntentado = true;
            Ejecutar("BACKUP", "master", Propiedad(baseTemporal, archivos, false)
                + "BACKUP DATABASE " + Identificador(baseTemporal) + " TO DISK=" + Literal(archivoRespaldo) + " WITH COPY_ONLY,CHECKSUM,INIT;\n", Operacion);
            progreso?.Invoke("Verificando el respaldo antes de guardar el destino…");
            Ejecutar("VERIFY", "master", "RESTORE VERIFYONLY FROM DISK=" + Literal(archivoRespaldo) + " WITH CHECKSUM;\n", Operacion);
            ComprobarFirma(archivoRespaldo);
            temporalDestino = Path.Combine(Path.GetDirectoryName(destino), ".myg_s2k_" + token + ".tmp");
            CopiarNuevo(archivoRespaldo, temporalDestino);
            destinoTemporalCreado = true;
            ComprobarFirma(temporalDestino);
            File.Move(temporalDestino, destino, overwrite: true);
            temporalDestino = null;
        }
        catch (Exception ex)
        {
            fallo = ex;
            timeoutSql = ex is TimeoutException;
        }
        finally
        {
            bool puedeBorrarDatos = false;
            if (restauracionIntentada && !timeoutSql)
            {
                try
                {
                    Ejecutar("CLEANUP", "master", Propiedad(baseTemporal, archivos, true), Consulta);
                    puedeBorrarDatos = true;
                }
                catch (Exception ex)
                {
                    avisos.Add("No se pudo retirar la base temporal " + baseTemporal + ": " + ex.Message
                        + ". Revise esa base y sus archivos propios: " + string.Join(", ", archivos.Select(a => a.Ruta)) + ".");
                }
            }
            else if (restauracionIntentada)
                avisos.Add("Se agotó el tiempo de " + fase + ". No se eliminó la base temporal " + baseTemporal
                    + " porque la operación puede seguir en SQL Server. Revise el proceso y estos archivos antes de retirarlos: "
                    + string.Join(", ", archivos.Select(a => a.Ruta)) + ".");
            if (puedeBorrarDatos)
                foreach (var a in archivos) BorrarPropio(a.Ruta, avisos);
            if (!timeoutSql)
            {
                if (copiaCreada) BorrarPropio(copiaPlantilla, avisos);
                if (respaldoIntentado) BorrarPropio(archivoRespaldo, avisos);
            }
            else if (copiaCreada || respaldoIntentado)
                avisos.Add("Archivos de trabajo conservados tras el timeout: " + copiaPlantilla + ", " + archivoRespaldo + ".");
            if (destinoTemporalCreado) BorrarPropio(temporalDestino, avisos);
        }
        if (fallo != null)
        {
            string limpieza = string.Join(Environment.NewLine, avisos.Skip(documento.Resultado.Advertencias.Count));
            throw new InvalidDataException("No se completó la exportación S2K. " + fallo.Message
                + (limpieza.Length == 0 ? "" : Environment.NewLine + limpieza), fallo);
        }
        avisos.Add("El S2K es un respaldo SQL Server 2005 verificado con checksum. Abra la copia restaurada en S10 y ejecute Procesar (F9) antes de abrir el ACU; el respaldo no valida el cálculo final de S10.");
        return documento.Resultado with { Advertencias = Array.AsReadOnly(avisos.Distinct().ToArray()) };
    }

    private static string RutaArchivo(string ruta, params string[] extensiones)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new InvalidDataException("Seleccione la ruta del archivo S2K y de su plantilla vacía.");
        TextoSeguro(ruta, "ruta");
        string completa = Path.GetFullPath(ruta);
        if (!extensiones.Contains(Path.GetExtension(completa), StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException("La extensión del archivo no está admitida: " + string.Join(", ", extensiones) + ".");
        return completa;
    }

    private static string ServidorLocal(string servidor)
    {
        servidor = string.IsNullOrWhiteSpace(servidor) ? "localhost" : servidor.Trim();
        string[] partes = servidor.Split('\\');
        string[] locales = { ".", "localhost", "(local)", Environment.MachineName };
        if (partes.Length > 2 || !locales.Contains(partes[0], StringComparer.OrdinalIgnoreCase)
            || partes.Length == 2 && !Regex.IsMatch(partes[1], @"^[A-Za-z0-9_]{1,16}$", RegexOptions.CultureInvariant))
            throw new InvalidDataException("Indique una instancia SQL Server 2005 de este equipo: localhost, (local), . o el nombre del equipo, opcionalmente seguido de \\instancia.");
        return servidor;
    }

    private static string CarpetaLocal(string ruta)
    {
        TextoSeguro(ruta, "carpeta SQL Server");
        if (string.IsNullOrWhiteSpace(ruta) || !Path.IsPathFullyQualified(ruta) || ruta.StartsWith(@"\\", StringComparison.Ordinal)
            || !Directory.Exists(ruta))
            throw new InvalidDataException("SQL Server debe indicar carpetas locales existentes, accesibles por la aplicación y por su servicio.");
        return Path.GetFullPath(ruta);
    }

    private static void TextoSeguro(string texto, string campo)
    {
        if (texto == null || texto.Any(char.IsControl)) throw new InvalidDataException("El " + campo + " contiene caracteres de control no admitidos.");
    }

    private static bool MismaRuta(string a, string b) => string.Equals(Path.GetFullPath(a), Path.GetFullPath(b),
        OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
    private static string Literal(string valor) { TextoSeguro(valor, "dato SQL"); return "N'" + valor.Replace("'", "''", StringComparison.Ordinal) + "'"; }
    private static string Identificador(string valor) => "[" + valor.Replace("]", "]]", StringComparison.Ordinal) + "]";

    private static void CopiarNuevo(string origen, string destino)
    {
        using var entrada = new FileStream(origen, FileMode.Open, FileAccess.Read, FileShare.Read);
        // Sólo tras CreateNew somos propietarios del archivo; una colisión no
        // autoriza a borrar el archivo que otra operación creó previamente.
        bool creado = false;
        try
        {
            using var salida = new FileStream(destino, FileMode.CreateNew, FileAccess.Write, FileShare.None);
            creado = true;
            entrada.CopyTo(salida); salida.Flush(flushToDisk: true);
        }
        catch
        {
            if (creado) { try { File.Delete(destino); } catch (IOException) { } catch (UnauthorizedAccessException) { } }
            throw;
        }
    }

    private static void ComprobarFirma(string ruta)
    {
        using var f = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.Read);
        Span<byte> firma = stackalloc byte[4];
        if (f.Length < 512 || f.Read(firma) != 4 || !firma.SequenceEqual("TAPE"u8))
            throw new InvalidDataException("El archivo no contiene la cabecera TAPE de un respaldo nativo SQL Server.");
    }

    private static void BorrarPropio(string ruta, List<string> avisos)
    {
        if (ruta == null) return;
        try { if (File.Exists(ruta)) File.Delete(ruta); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        { avisos.Add("No se pudo retirar el archivo temporal " + ruta + ": " + ex.Message); }
    }

    private static IEnumerable<string> Marcadores(string salida, string nombre)
        => (salida ?? "").Split('\n').Select(l => l.Trim()).Where(l => l.StartsWith(nombre + "=", StringComparison.Ordinal)).Select(l => l[(nombre.Length + 1)..]);
    private static string Marcador(string salida, string nombre)
    {
        string[] valores = Marcadores(salida, nombre).ToArray();
        if (valores.Length != 1) throw new InvalidDataException("SQLCMD no devolvió un único marcador válido " + nombre + ".");
        return valores[0];
    }
    private static string LeerHex(string texto)
    {
        if (texto == null || !Regex.IsMatch(texto, @"^0x(?:[0-9A-Fa-f]{4})*$", RegexOptions.CultureInvariant) || texto.Length > 16002)
            throw new InvalidDataException("Metadato SQL no válido: se esperaba UTF16 hexadecimal.");
        try { return UnicodeEstricto.GetString(Convert.FromHexString(texto[2..])); }
        catch (ArgumentException ex) { throw new InvalidDataException("Metadato SQL Unicode no válido.", ex); }
    }
    private static string Diagnostico(MYGRespuestaSqlCmdS10 respuesta)
    {
        if (respuesta == null) return "No se recibió respuesta.";
        string detalle = ((respuesta.Errores ?? "") + "\n" + (respuesta.Salida ?? "")).Trim();
        return detalle.Length <= 4000 ? detalle : detalle[..4000] + "…";
    }

    private static string Encapsular(string sql)
    {
        // SQLCMD interpreta directivas antes de TSQL. El proyecto viaja como
        // hex UTF16, de modo que sus saltos, :r, !! o $(variables) son datos.
        var b = new StringBuilder("DECLARE @myg_importacion nvarchar(max); SET @myg_importacion=N'';\n");
        byte[] bytes = UnicodeEstricto.GetBytes(sql);
        for (int i = 0; i < bytes.Length; i += 8000)
            b.Append("SET @myg_importacion=@myg_importacion+CONVERT(nvarchar(max),0x")
                .Append(Convert.ToHexString(bytes.AsSpan(i, Math.Min(8000, bytes.Length - i)))).AppendLine(");");
        b.AppendLine("EXEC sys.sp_executesql @myg_importacion;");
        return b.ToString();
    }

    private static string SqlMetadatos()
    {
        string carpetas = """
        DECLARE @backup nvarchar(4000),@data nvarchar(4000),@log nvarchar(4000);
        EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory',@backup OUTPUT;
        SELECT @data=physical_name FROM master.sys.master_files WHERE database_id=1 AND file_id=1;
        SELECT @log=physical_name FROM master.sys.master_files WHERE database_id=1 AND file_id=2;
        SET @data=LEFT(@data,LEN(@data)-CHARINDEX(N'\',REVERSE(@data))+1);
        SET @log=LEFT(@log,LEN(@log)-CHARINDEX(N'\',REVERSE(@log))+1);
        SELECT 'MYG_MACHINE='+master.dbo.fn_varbintohexstr(CONVERT(varbinary(8000),CONVERT(nvarchar(4000),SERVERPROPERTY('MachineName'))));
        SELECT 'MYG_PHYSICAL='+master.dbo.fn_varbintohexstr(CONVERT(varbinary(8000),ISNULL(CONVERT(nvarchar(4000),SERVERPROPERTY('ComputerNamePhysicalNetBIOS')),N'')));
        SELECT 'MYG_BACKUP='+master.dbo.fn_varbintohexstr(CONVERT(varbinary(8000),@backup));
        SELECT 'MYG_DATA='+master.dbo.fn_varbintohexstr(CONVERT(varbinary(8000),@data));
        SELECT 'MYG_LOG='+master.dbo.fn_varbintohexstr(CONVERT(varbinary(8000),@log));
        """;
        // No resolver vistas sys.* de SQL 2005 en motores anteriores antes de
        // poder devolver una versión y explicar la incompatibilidad.
        return "SELECT 'MYG_VERSION='+CONVERT(varchar(100),SERVERPROPERTY('ProductVersion'));\n"
            + "IF CONVERT(varchar(100),SERVERPROPERTY('ProductVersion')) NOT LIKE '9.%' RETURN;\n"
            + "EXEC(N'" + carpetas.Replace("'", "''", StringComparison.Ordinal) + "');\n";
    }

    private static string SqlHeader(string ruta) => """
        CREATE TABLE #h(BackupName nvarchar(128),BackupDescription nvarchar(255),BackupType smallint,ExpirationDate datetime,Compressed bit,Position smallint,DeviceType tinyint,UserName nvarchar(128),ServerName nvarchar(128),DatabaseName nvarchar(128),DatabaseVersion int,DatabaseCreationDate datetime,BackupSize numeric(20,0),FirstLSN numeric(25,0),LastLSN numeric(25,0),CheckpointLSN numeric(25,0),DatabaseBackupLSN numeric(25,0),BackupStartDate datetime,BackupFinishDate datetime,SortOrder smallint,CodePage smallint,UnicodeLocaleId int,UnicodeComparisonStyle int,CompatibilityLevel tinyint,SoftwareVendorId int,SoftwareVersionMajor int,SoftwareVersionMinor int,SoftwareVersionBuild int,MachineName nvarchar(128),Flags int,BindingID uniqueidentifier,RecoveryForkID uniqueidentifier,Collation nvarchar(128),FamilyGUID uniqueidentifier,HasBulkLoggedData bit,IsSnapshot bit,IsReadOnly bit,IsSingleUser bit,HasBackupChecksums bit,IsDamaged bit,BeginsLogChain bit,HasIncompleteMetaData bit,IsForceOffline bit,IsCopyOnly bit,FirstRecoveryForkID uniqueidentifier,ForkPointLSN numeric(25,0),RecoveryModel nvarchar(60),DifferentialBaseLSN numeric(25,0),DifferentialBaseGUID uniqueidentifier,BackupTypeDescription nvarchar(60),BackupSetGUID uniqueidentifier);
        """ + "\nINSERT #h EXEC(N'RESTORE HEADERONLY FROM DISK=" + Literal(ruta).Replace("'", "''", StringComparison.Ordinal) + "');\n" + """
        IF (SELECT COUNT(*) FROM #h)<>1 OR EXISTS(SELECT 1 FROM #h WHERE Position<>1 OR BackupType<>1 OR ISNULL(IsSnapshot,0)<>0 OR ISNULL(IsDamaged,0)<>0 OR ISNULL(HasIncompleteMetaData,0)<>0 OR BackupFinishDate IS NULL)
        BEGIN RAISERROR(N'La plantilla debe ser un único respaldo completo, posición 1, finalizado y sin snapshot ni daños declarados.',16,1); RETURN; END;
        """ + "\nRESTORE VERIFYONLY FROM DISK=" + Literal(ruta) + " WITH FILE=1;\n"
        + "SELECT 'MYG_HEADER='+CONVERT(varchar(10),Position)+'|'+CONVERT(varchar(10),BackupType)+'|'+CONVERT(varchar(10),DatabaseVersion)+'|'+CONVERT(varchar(10),ISNULL(IsSnapshot,0)) FROM #h;\n";

    private static string SqlFilelist(string ruta) => """
        CREATE TABLE #f(LogicalName nvarchar(128),PhysicalName nvarchar(260),Type char(1),FileGroupName nvarchar(128),Size numeric(20,0),MaxSize numeric(20,0),FileId bigint,CreateLSN numeric(25,0),DropLSN numeric(25,0),UniqueId uniqueidentifier,ReadOnlyLSN numeric(25,0),ReadWriteLSN numeric(25,0),BackupSizeInBytes bigint,SourceBlockSize int,FileGroupID int,LogGroupGUID uniqueidentifier,DifferentialBaseLSN numeric(25,0),DifferentialBaseGUID uniqueidentifier,IsReadOnly bit,IsPresent bit);
        """ + "\nINSERT #f EXEC(N'RESTORE FILELISTONLY FROM DISK=" + Literal(ruta).Replace("'", "''", StringComparison.Ordinal) + " WITH FILE=1');\n"
        + "IF NOT EXISTS(SELECT 1 FROM #f) OR EXISTS(SELECT 1 FROM #f WHERE ISNULL(IsPresent,0)<>1 OR Type NOT IN('D','L')) BEGIN RAISERROR(N'La plantilla no contiene una lista completa de archivos de datos y registro.',16,1); RETURN; END;\n"
        + "SELECT 'MYG_FILE='+master.dbo.fn_varbintohexstr(CONVERT(varbinary(8000),LogicalName))+'|'+Type FROM #f ORDER BY FileId;\n";

    private static string SqlRestaurar(string nombre, string ruta, IReadOnlyList<Archivo> archivos)
        => "IF DB_ID(" + Literal(nombre) + ") IS NOT NULL BEGIN RAISERROR(N'La base temporal ya existe. No se reemplazará.',16,1); RETURN; END;\n"
        + "IF EXISTS(SELECT 1 FROM master.sys.master_files WHERE physical_name IN(" + RutasSql(archivos) + ")) BEGIN RAISERROR(N'Los archivos temporales ya están vinculados a otra base.',16,1); RETURN; END;\n"
        + "RESTORE DATABASE " + Identificador(nombre) + " FROM DISK=" + Literal(ruta) + " WITH FILE=1,"
        + string.Join(",", archivos.Select(a => "MOVE " + Literal(a.Logico) + " TO " + Literal(a.Ruta))) + ",RECOVERY;\n";

    private static string RutasSql(IReadOnlyList<Archivo> archivos) => string.Join(",", archivos.Select(a => Literal(a.Ruta)));
    private static string Propiedad(string nombre, IReadOnlyList<Archivo> archivos, bool retirar)
    {
        string id = Literal(nombre), rutas = RutasSql(archivos), tabla = Identificador(nombre);
        string comprobacion = "IF EXISTS(SELECT 1 FROM master.sys.master_files WHERE database_id=DB_ID(" + id + ") AND physical_name NOT IN(" + rutas + ")) OR (SELECT COUNT(*) FROM master.sys.master_files WHERE database_id=DB_ID(" + id + "))<>" + archivos.Count
            + " BEGIN RAISERROR(N'No se confirmó la propiedad de todos los archivos de la base temporal. No se modificará ni eliminará.',16,1); RETURN; END;\n";
        if (!retirar) return "IF DB_ID(" + id + ") IS NULL BEGIN RAISERROR(N'La base temporal no existe.',16,1); RETURN; END;\n" + comprobacion;
        return "IF DB_ID(" + id + ") IS NOT NULL BEGIN\n" + comprobacion
            + "ALTER DATABASE " + tabla + " SET SINGLE_USER WITH ROLLBACK IMMEDIATE;\nDROP DATABASE " + tabla + ";\nEND;\n"
            + "IF EXISTS(SELECT 1 FROM master.sys.master_files WHERE physical_name IN(" + rutas + ")) BEGIN RAISERROR(N'Los archivos siguen vinculados a SQL Server. No se eliminarán.',16,1); RETURN; END;\n";
    }

    private static string SqlPlantillaVacia() => """
        IF OBJECT_ID(N'dbo.Presupuesto',N'U') IS NULL BEGIN RAISERROR(N'La plantilla no contiene una base S10.',16,1); RETURN; END;
        IF NOT EXISTS(SELECT 1 FROM dbo.Presupuesto WHERE CodPresupuesto=N'9999999') OR EXISTS(SELECT 1 FROM dbo.Presupuesto WHERE CodPresupuesto IS NULL OR CodPresupuesto<>N'9999999')
        BEGIN RAISERROR(N'La plantilla contiene presupuestos o carece del registro de sistema. Debe suministrar una plantilla S10 vacía; no se eliminará su contenido.',16,1); RETURN; END;
        DECLARE @tablas TABLE(id int PRIMARY KEY);
        INSERT @tablas SELECT DISTINCT t.object_id FROM sys.tables t JOIN sys.columns c ON c.object_id=t.object_id WHERE t.is_ms_shipped=0 AND c.name IN(N'CodPresupuesto',N'CodPresupuestoPartida',N'CodPresupuestoR');
        WHILE EXISTS(SELECT 1 FROM sys.foreign_keys f JOIN @tablas p ON p.id=f.referenced_object_id WHERE NOT EXISTS(SELECT 1 FROM @tablas x WHERE x.id=f.parent_object_id))
        INSERT @tablas SELECT DISTINCT f.parent_object_id FROM sys.foreign_keys f JOIN @tablas p ON p.id=f.referenced_object_id WHERE NOT EXISTS(SELECT 1 FROM @tablas x WHERE x.id=f.parent_object_id);
        DECLARE @id int,@esquema sysname,@tabla sysname,@nombre nvarchar(520),@condicion nvarchar(max),@consulta nvarchar(max);
        DECLARE vacio CURSOR LOCAL FAST_FORWARD FOR SELECT t.object_id,s.name,t.name FROM @tablas x JOIN sys.tables t ON t.object_id=x.id JOIN sys.schemas s ON s.schema_id=t.schema_id;
        OPEN vacio; FETCH NEXT FROM vacio INTO @id,@esquema,@tabla;
        WHILE @@FETCH_STATUS=0 BEGIN
          SET @nombre=QUOTENAME(@esquema)+N'.'+QUOTENAME(@tabla);
          IF NOT(@esquema=N'dbo' AND @tabla=N'Presupuesto') BEGIN
            SET @condicion=N'';
            IF @esquema=N'dbo' AND @tabla IN(N'Partida',N'PartidaDetalle',N'PartidaRendimiento')
              SELECT @condicion=@condicion+CASE WHEN LEN(@condicion)>0 THEN N' OR ' ELSE N'' END+N'('+QUOTENAME(c.name)+N' IS NULL OR '+QUOTENAME(c.name)+N'<>N''9999999'')' FROM sys.columns c WHERE c.object_id=@id AND c.name IN(N'CodPresupuesto',N'CodPresupuestoPartida',N'CodPresupuestoR');
            SET @consulta=N'IF EXISTS(SELECT 1 FROM '+@nombre+CASE WHEN LEN(@condicion)>0 THEN N' WHERE '+@condicion ELSE N'' END+N') RAISERROR(N''La plantilla contiene datos presupuestarios en %s. No se borrarán; seleccione una plantilla vacía.'',16,1,@n);';
            EXEC sys.sp_executesql @consulta,N'@n nvarchar(520)',@n=@nombre;
          END;
          FETCH NEXT FROM vacio INTO @id,@esquema,@tabla;
        END;
        CLOSE vacio; DEALLOCATE vacio;
        SELECT 'MYG_EMPTY=1';
        """;

    private sealed class SqlCmdLocal : IMYGSqlCmdS10Runner
    {
        public MYGRespuestaSqlCmdS10 Ejecutar(MYGSolicitudSqlCmdS10 solicitud)
        {
            if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("La exportación S2K nativa requiere Windows, SQLCMD y SQL Server 2005 local.");
            string archivo = Path.Combine(Path.GetTempPath(), "myg_s2k_sql_" + Guid.NewGuid().ToString("N") + ".sql");
            try
            {
                File.WriteAllText(archivo, solicitud.Sql, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
                var inicio = new ProcessStartInfo("sqlcmd")
                {
                    UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
                };
                foreach (string argumento in new[] { "-S", solicitud.Servidor, "-d", solicitud.BaseDatos, "-E", "-b", "-r1", "-h-1", "-w65535", "-y0", "-f65001", "-X1", "-x", "-i", archivo }) inicio.ArgumentList.Add(argumento);
                inicio.Environment.Remove("SQLCMDINI"); inicio.Environment.Remove("SQLCMDPASSWORD");
                using var proceso = new Process { StartInfo = inicio };
                try { proceso.Start(); }
                catch (Win32Exception ex) { throw new InvalidDataException("No se pudo iniciar SQLCMD. Instale las herramientas cliente compatibles y compruebe que sqlcmd está en PATH.", ex); }
                var salida = proceso.StandardOutput.ReadToEndAsync(); var errores = proceso.StandardError.ReadToEndAsync();
                if (!proceso.WaitForExit(checked((int)solicitud.TiempoMaximo.TotalMilliseconds)))
                {
                    Exception errorAlDetener = null;
                    try { proceso.Kill(entireProcessTree: true); }
                    catch (Exception ex) when (ex is InvalidOperationException or Win32Exception or NotSupportedException or AggregateException)
                    { errorAlDetener = ex; }
                    // El timeout conserva su tipo incluso si no se pudo cerrar
                    // SQLCMD: el coordinador no debe iniciar DROP ni borrar los
                    // archivos de una operación que puede seguir en el servidor.
                    throw new TimeoutException("SQLCMD superó el tiempo máximo. La operación puede seguir ejecutándose en SQL Server.", errorAlDetener);
                }
                return new(proceso.ExitCode, salida.GetAwaiter().GetResult(), errores.GetAwaiter().GetResult());
            }
            finally { try { File.Delete(archivo); } catch (IOException) { } catch (UnauthorizedAccessException) { } }
        }
    }
}
