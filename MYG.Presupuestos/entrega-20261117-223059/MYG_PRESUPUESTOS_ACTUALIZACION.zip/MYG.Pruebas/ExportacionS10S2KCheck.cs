#nullable enable
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using MYG_2027;

// Pruebas de orquestacion y archivos con SQLCMD simulado. No crean ni
// verifican un backup SQL Server real; eso requiere la instalacion Windows.
internal static class ExportacionS10S2KCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        ExitoArchivoYOrden();
        pasa("S2K ejecuta restauracion aislada, validacion, importacion, BACKUP y VERIFY antes de publicar el archivo; conserva MYG y la plantilla");
        PlantillaConObras();
        pasa("S2K rechaza una plantilla con presupuestos antes de importar y conserva el destino anterior");
        FallosNoPublican();
        pasa("S2K preserva el archivo anterior ante fallos de restauracion, importacion, backup o verificacion y limita la limpieza a su base temporal");
        LimpiezaFallidaInforma();
        pasa("S2K informa una limpieza fallida sin ocultar que el respaldo ya fue verificado y entregado");
        ServidorYMotor();
        pasa("S2K rechaza servidores remotos o manipulados, versiones SQL incompatibles y metadatos incompletos antes de restaurar");
        MetadatosRespaldoInvalidos();
        pasa("S2K rechaza cabeceras y listas de archivos incompatibles o ambiguas sin importar datos");
        NombresYComandos();
        pasa("S2K conserva apostrofes en rutas y nombres, encapsula la importacion y no convierte datos en comandos SQLCMD ni DROP ajenos");
        DestinoYFirma();
        pasa("S2K protege la plantilla y el destino, exige extension de respaldo y rechaza una salida que contiene SQL en vez de un backup");
    }

    internal static IReadOnlyList<string> DocumentosSqlRepresentativos()
    {
        using var e = new Entorno();
        var f = new SqlFalso(e);
        Ejecutar(e, f);
        return f.Solicitudes.Select(s => s.Sql).ToArray();
    }

    private static void ExitoArchivoYOrden()
    {
        using var e = new Entorno();
        var f = new SqlFalso(e);
        string original = JsonSerializer.Serialize(e.Proyecto);
        byte[] plantilla = File.ReadAllBytes(e.Plantilla);
        var progreso = new List<string>();
        var resultado = Ejecutar(e, f, progreso.Add);
        Exige(File.ReadAllBytes(e.Destino).SequenceEqual(f.BytesBackup), "La entrega debe copiar los bytes del respaldo que produjo el runner, no SQL renombrado.");
        Exige(File.ReadAllBytes(e.Destino).AsSpan(0, 4).SequenceEqual(Encoding.ASCII.GetBytes("TAPE")), "La salida simulada debe conservar su cabecera de backup.");
        Exige(resultado.Partidas == 1 && resultado.Presupuestos == 1 && resultado.Insumos == 1 && progreso.Count > 0,
            "El resultado debe corresponder a la importacion real preparada por MYG e informar avance.");
        var fases = f.Solicitudes.Select(Fase).ToArray();
        foreach (var (antes, despues) in new[] { ("HEADER", "RESTORE"), ("FILELIST", "RESTORE"), ("RESTORE", "PLANTILLA"), ("PLANTILLA", "IMPORTAR"), ("IMPORTAR", "BACKUP"), ("BACKUP", "VERIFY"), ("VERIFY", "CLEANUP") })
            Exige(Array.IndexOf(fases, antes) >= 0 && Array.IndexOf(fases, despues) > Array.IndexOf(fases, antes), "Orden de fases incorrecto: " + antes + " / " + despues);
        Exige(f.Solicitudes.All(s => s.TiempoMaximo > TimeSpan.Zero), "Cada proceso debe tener un plazo acotado.");
        Exige(JsonSerializer.Serialize(e.Proyecto) == original && File.ReadAllBytes(e.Plantilla).SequenceEqual(plantilla),
            "Exportar no debe modificar el documento MYG ni su plantilla.");
        var importar = f.Solicitudes.Single(s => Fase(s) == "IMPORTAR");
        Exige(importar.BaseDatos == f.BaseRestaurada || Regex.IsMatch(Codigo(importar.Sql), @"\bUSE\s+\[" + Regex.Escape(f.BaseRestaurada!) + @"\]", RegexOptions.IgnoreCase),
            "La importacion debe ejecutarse sobre la base temporal, nunca sobre la original.");
        ComprobarLimpiezaPropia(f);
    }

    private static void PlantillaConObras()
    {
        using var e = new Entorno();
        var f = new SqlFalso(e) { PlantillaVacia = false };
        byte[] anterior = File.ReadAllBytes(e.Destino);
        Rechaza(() => Ejecutar(e, f));
        Exige(!f.Solicitudes.Any(s => Fase(s) is "IMPORTAR" or "BACKUP" or "VERIFY"),
            "Una plantilla con obras debe detener el flujo antes de mezclarla con la exportacion.");
        Exige(File.ReadAllBytes(e.Destino).SequenceEqual(anterior), "Rechazar la plantilla debe conservar la entrega anterior.");
        ComprobarLimpiezaPropia(f);
    }

    private static void FallosNoPublican()
    {
        foreach (string fase in new[] { "RESTORE", "IMPORTAR", "BACKUP", "VERIFY" })
        {
            using var e = new Entorno();
            var f = new SqlFalso(e) { FallarEn = fase };
            byte[] anterior = File.ReadAllBytes(e.Destino), plantilla = File.ReadAllBytes(e.Plantilla);
            Rechaza(() => Ejecutar(e, f));
            Exige(File.ReadAllBytes(e.Destino).SequenceEqual(anterior) && File.ReadAllBytes(e.Plantilla).SequenceEqual(plantilla),
                "Un fallo en " + fase + " no debe sobrescribir el destino ni la plantilla.");
            Exige(!f.Solicitudes.Any(s => Fase(s) == "VERIFY") || fase == "VERIFY", "No debe verificar tras un fallo anterior.");
            ComprobarLimpiezaPropia(f);
        }
    }

    private static void LimpiezaFallidaInforma()
    {
        using var e = new Entorno();
        var f = new SqlFalso(e) { FallarEn = "CLEANUP" };
        var r = Ejecutar(e, f);
        Exige(File.ReadAllBytes(e.Destino).SequenceEqual(f.BytesBackup), "La limpieza posterior no debe sustituir una entrega ya verificada por una version incompleta.");
        Exige(r.Advertencias.Any(a => a.Contains(f.BaseRestaurada!, StringComparison.Ordinal)
            || a.Contains("limpi", StringComparison.OrdinalIgnoreCase) || a.Contains("eliminar", StringComparison.OrdinalIgnoreCase)),
            "Un fallo de limpieza debe quedar visible para el usuario, sin anunciar que todo fue eliminado.");
        ComprobarLimpiezaPropia(f);
    }

    private static void ServidorYMotor()
    {
        foreach (string servidor in new[] { "equipo-remoto", "localhost;DROP DATABASE otra", "localhost\r\n:!! whoami" })
        {
            using var e = new Entorno();
            e.Respaldo.Servidor = servidor;
            var f = new SqlFalso(e);
            Rechaza(() => Ejecutar(e, f));
            Exige(f.Solicitudes.Count == 0, "Un servidor ajeno o manipulado debe rechazarse antes de invocar SQLCMD.");
        }
        using (var e = new Entorno())
        {
            var f = new SqlFalso(e) { Version = "8.0.2039" };
            Rechaza(() => Ejecutar(e, f));
            Exige(!f.Solicitudes.Any(s => Fase(s) == "RESTORE"), "Un motor anterior al soportado debe rechazarse aunque las demas rutas sean validas.");
        }
        using (var e = new Entorno())
        {
            var f = new SqlFalso(e) { Host = "SERVIDOR_AJENO_SINTETICO" };
            Rechaza(() => Ejecutar(e, f));
            Exige(!f.Solicitudes.Any(s => Fase(s) == "RESTORE") && Directory.GetFiles(e.BackupDir).Length == 0,
                "Un alias local que llega a otra maquina debe rechazarse antes de copiar archivos o restaurar.");
        }
        foreach (string metadata in new[] { "MYG_VERSION=no-es-version\n", "MYG_VERSION=9.0.5000\nMYG_BACKUP=0xGG\n" })
        {
            using var e = new Entorno();
            var f = new SqlFalso(e) { Metadata = metadata };
            Rechaza(() => Ejecutar(e, f));
            Exige(!f.Solicitudes.Any(s => Fase(s) == "RESTORE"), "La version o las rutas invalidas deben impedir la restauracion.");
        }
    }

    private static void MetadatosRespaldoInvalidos()
    {
        foreach (var dato in new[]
        {
            (Cabecera: "MYG_HEADER=1|5|515|0", Lista: (string?)null),
            (Cabecera: "MYG_HEADER=1|1|515|1", Lista: (string?)null),
            (Cabecera: "MYG_HEADER=no-valida", Lista: (string?)null),
            (Cabecera: (string?)null, Lista: "MYG_FILE=0xGG|D"),
            (Cabecera: (string?)null, Lista: "MYG_FILE=" + Hex("Data") + "|X"),
            (Cabecera: (string?)null, Lista: "MYG_FILE=" + Hex("Duplicado") + "|D\nMYG_FILE=" + Hex("Duplicado") + "|L"),
            (Cabecera: (string?)null, Lista: "MYG_FILE=" + Hex("Data\r\n:!! whoami") + "|D\nMYG_FILE=" + Hex("Log") + "|L")
        })
        {
            using var e = new Entorno();
            var f = new SqlFalso(e) { Cabecera = dato.Cabecera, ListaArchivos = dato.Lista };
            Rechaza(() => Ejecutar(e, f));
            Exige(!f.Solicitudes.Any(s => Fase(s) == "IMPORTAR"), "Los metadatos incompatibles no deben llegar al importador.");
            Exige(!f.Solicitudes.Any(s => Fase(s) == "RESTORE"), "Una lista de archivos no confiable no debe usarse para restaurar.");
        }
    }

    private static void NombresYComandos()
    {
        using var e = new Entorno("O'Brien ];--");
        e.Opciones.Nombre = "Nombre O'Brien\r\n:!! whoami\r\nDROP DATABASE [AJENA];--";
        var f = new SqlFalso(e);
        Ejecutar(e, f);
        string importar = f.Solicitudes.Single(s => Fase(s) == "IMPORTAR").Sql;
        Exige(!Regex.IsMatch(importar, @"(?m)^\s*:!!") && !importar.Contains("whoami", StringComparison.Ordinal),
            "Los saltos de linea de datos no deben exponerse al preprocesador de SQLCMD.");
        Exige(f.Solicitudes.All(s => !Regex.IsMatch(Codigo(s.Sql), @"\bDROP\s+DATABASE\s+\[AJENA\]", RegexOptions.IgnoreCase)),
            "Las comillas y cierres de identificador aportados como datos no deben ejecutar sentencias ajenas.");
        ComprobarLimpiezaPropia(f);
        Exige(File.Exists(e.Plantilla) && File.ReadAllBytes(e.Destino).SequenceEqual(f.BytesBackup),
            "Una ruta con apostrofe debe seguir siendo un dato y entregar el archivo correcto.");
    }

    private static void DestinoYFirma()
    {
        using (var e = new Entorno())
        {
            var f = new SqlFalso(e);
            string ruta = e.Destino;
            e.Destino = e.Plantilla;
            Rechaza(() => Ejecutar(e, f));
            Exige(f.Solicitudes.Count == 0, "La plantilla no puede ser tambien el destino.");
            e.Destino = Path.ChangeExtension(ruta, ".sql");
            Rechaza(() => Ejecutar(e, f));
            Exige(f.Solicitudes.Count == 0, "No debe publicarse SQL con una extension de respaldo equivocada.");
        }
        using (var e = new Entorno())
        {
            var f = new SqlFalso(e) { SalidaNoNativa = true };
            byte[] anterior = File.ReadAllBytes(e.Destino);
            Rechaza(() => Ejecutar(e, f));
            Exige(File.ReadAllBytes(e.Destino).SequenceEqual(anterior), "Una salida sin cabecera de backup debe conservar el destino previo.");
            ComprobarLimpiezaPropia(f);
        }
    }

    private static MYGResultadoExportacionS10 Ejecutar(Entorno e, SqlFalso f, Action<string>? progreso = null) =>
        MYGExportacionS10S2K.Guardar(e.Destino, e.Proyecto, e.Opciones, e.Respaldo, progreso, f);

    private static void ComprobarLimpiezaPropia(SqlFalso f)
    {
        Exige(f.BaseRestaurada != null && Regex.IsMatch(f.BaseRestaurada, @"^MYG_S2K_[a-fA-F0-9]{32}$"), "La restauracion debe usar un nombre temporal con GUID, nunca el nombre de una base original.");
        var limpiezas = f.Solicitudes.Where(s => Fase(s) == "CLEANUP").ToArray();
        Exige(limpiezas.Length == 1, "Cada restauracion intentada debe tener una sola limpieza, tambien cuando falla parcialmente.");
        foreach (var s in f.Solicitudes)
        {
            string codigo = Codigo(s.Sql);
            foreach (Match m in Regex.Matches(codigo, @"\bDROP\s+DATABASE\s+\[(?<db>[^\]]+)\]", RegexOptions.IgnoreCase))
                Exige(Fase(s) == "CLEANUP" && m.Groups["db"].Value == f.BaseRestaurada, "La limpieza no debe eliminar ninguna base ajena a esta exportacion.");
        }
        Exige(limpiezas[0].Sql.Contains("sys.master_files", StringComparison.OrdinalIgnoreCase), "La limpieza debe comprobar la propiedad mediante las rutas de sus archivos temporales.");
        Exige(!Regex.IsMatch(Codigo(f.Solicitudes.Single(s => Fase(s) == "RESTORE").Sql), @"\bWITH\s+REPLACE\b|,\s*REPLACE\s*(?:[,;]|$)", RegexOptions.IgnoreCase), "Restaurar una plantilla no debe reemplazar una base existente.");
    }

    private static string Fase(MYGSolicitudSqlCmdS10 s) => Regex.Match(s.Sql, @"^\s*--\s*MYG_S2K:(?<f>[A-Z]+)").Groups["f"].Value;
    private static string Hex(string texto) => "0x" + Convert.ToHexString(Encoding.Unicode.GetBytes(texto));
    private static string Codigo(string sql) => Regex.Replace(Regex.Replace(sql, @"N?'(?:''|[^'])*'", " ", RegexOptions.IgnoreCase), @"--[^\r\n]*|/\*[\s\S]*?\*/", " ");
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (Exception ex) when (ex is InvalidDataException or IOException or InvalidOperationException or ArgumentException) { return; }
        throw new Exception("La exportacion S2K debio rechazar el caso incompatible.");
    }
    private static void Exige(bool condicion, string detalle) { if (!condicion) throw new Exception(detalle); }

    private sealed class Entorno : IDisposable
    {
        internal readonly string Carpeta, Plantilla;
        internal string Destino;
        internal readonly string BackupDir, DataDir, LogDir;
        internal readonly MYGProyectoDocumento Proyecto;
        internal readonly MYGOpcionesExportacionS10 Opciones;
        internal readonly MYGOpcionesRespaldoS10 Respaldo;
        internal Entorno(string sufijo = "")
        {
            Carpeta = Path.Combine(Path.GetTempPath(), "MYG-S2K-Pruebas-" + Guid.NewGuid().ToString("N") + sufijo);
            Directory.CreateDirectory(Carpeta);
            BackupDir = Path.Combine(Carpeta, "Backup"); DataDir = Path.Combine(Carpeta, "Data"); LogDir = Path.Combine(Carpeta, "Log");
            foreach (string d in new[] { BackupDir, DataDir, LogDir }) Directory.CreateDirectory(d);
            Plantilla = Path.Combine(Carpeta, "Plantilla.S2K"); Destino = Path.Combine(Carpeta, "Entrega.S2K");
            File.WriteAllBytes(Plantilla, Encoding.ASCII.GetBytes("TAPE" + new string('P', 1024)));
            File.WriteAllBytes(Destino, Encoding.ASCII.GetBytes("respaldo anterior del usuario"));
            Proyecto = MYGProyectoStorage.Nuevo("Presupuesto de prueba S2K");
            string id = MYGProyectoStorage.NuevoId();
            Proyecto.Presupuestos.Single().Items.Add(new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, IdPropuesta = id, Item = "01", Descripcion = "Partida de prueba",
                Unidad = "und", TipoPropuesta = "PARTIDA", Posicion = 1, Origen = "MODELO", Estado = "PROPUESTA",
                Costos = new MYGDatosPartida { Cantidad = 2m, PrecioDirecto = 3.5m }
            });
            Opciones = new MYGOpcionesExportacionS10 { Nombre = "Entrega de prueba", CodigoLugar = MYGExportacionS10Sql.Ubicaciones.First().Codigo, FechaCosto = new DateTime(2026, 11, 18) };
            Respaldo = new MYGOpcionesRespaldoS10 { Servidor = "localhost", RutaPlantilla = Plantilla };
        }
        public void Dispose() { if (Directory.Exists(Carpeta)) Directory.Delete(Carpeta, true); }
    }

    private sealed class SqlFalso : IMYGSqlCmdS10Runner
    {
        private readonly Entorno entorno;
        internal readonly List<MYGSolicitudSqlCmdS10> Solicitudes = new();
        internal readonly byte[] BytesBackup = Encoding.ASCII.GetBytes("TAPE" + new string('B', 1024));
        internal bool PlantillaVacia = true, SalidaNoNativa;
        internal string? FallarEn, Metadata, Cabecera, ListaArchivos, BaseRestaurada;
        internal string Version = "9.0.5000", Host = Environment.MachineName;
        internal SqlFalso(Entorno entorno) { this.entorno = entorno; }
        public MYGRespuestaSqlCmdS10 Ejecutar(MYGSolicitudSqlCmdS10 solicitud)
        {
            Solicitudes.Add(solicitud);
            string fase = Fase(solicitud);
            if (fase == "RESTORE")
            {
                BaseRestaurada = Regex.Match(solicitud.Sql, @"RESTORE\s+DATABASE\s+\[(?<db>[^\]]+)\]", RegexOptions.IgnoreCase).Groups["db"].Value;
                Exige(BaseRestaurada.Length > 0, "El runner debe recibir una restauracion explicita y auditable de su base temporal.");
            }
            if (fase == FallarEn) return new(1, "", "Fallo sintetico en " + fase);
            string salida = fase switch
            {
                "METADATOS" => Metadata ?? "MYG_VERSION=" + Version + "\nMYG_MACHINE=" + Hex(Host) + "\nMYG_PHYSICAL=" + Hex(Host)
                    + "\nMYG_BACKUP=" + Hex(entorno.BackupDir) + "\nMYG_DATA=" + Hex(entorno.DataDir) + "\nMYG_LOG=" + Hex(entorno.LogDir),
                "HEADER" => Cabecera ?? "MYG_HEADER=1|1|515|0",
                "FILELIST" => ListaArchivos ?? "MYG_FILE=" + Hex("S10_Data") + "|D\nMYG_FILE=" + Hex("S10_Log") + "|L",
                "PLANTILLA" => "MYG_EMPTY=" + (PlantillaVacia ? "1" : "0"),
                _ => ""
            };
            if (fase == "BACKUP")
            {
                var m = Regex.Match(solicitud.Sql, @"TO\s+DISK\s*=\s*N?'(?<ruta>(?:''|[^'])*)'", RegexOptions.IgnoreCase);
                Exige(m.Success, "El BACKUP debe identificar su archivo de disco generado.");
                string archivo = m.Groups["ruta"].Value.Replace("''", "'", StringComparison.Ordinal);
                Directory.CreateDirectory(Path.GetDirectoryName(archivo)!);
                File.WriteAllBytes(archivo, SalidaNoNativa ? Encoding.ASCII.GetBytes("INSERT INTO tabla;" + new string('x', 1024)) : BytesBackup);
            }
            return new(0, salida, "");
        }
    }
}
