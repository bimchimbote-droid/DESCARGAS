SET NOCOUNT ON;
DECLARE @id int,@db int,@r int,@dir nvarchar(4000),@base nvarchar(32),@prefix nvarchar(4000),@file nvarchar(260);
SELECT @db=DB_ID(N'S10_MYG_PRUEBA'),@base=N'MYG_S10_Error0_';
BEGIN TRY
IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 RAISERROR(N'Use the verified SQL sysadmin session.',16,1);
IF @db IS NULL RAISERROR(N'Database S10_MYG_PRUEBA was not found.',16,1);
EXEC @r=master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory',@dir OUTPUT;
IF @r<>0 OR NULLIF(@dir,N'') IS NULL RAISERROR(N'Cannot resolve the SQL backup directory.',16,1);
SET @prefix=@dir+CASE WHEN RIGHT(@dir,1) IN(N'\',N'/') THEN N'' ELSE N'\' END;
SELECT TOP 1 @id=id,@file=path FROM sys.traces WHERE is_default=0 AND LEFT(path,LEN(@prefix+@base))=@prefix+@base AND RIGHT(path,4)=N'.trc' ORDER BY path DESC;
IF @id IS NOT NULL BEGIN
IF EXISTS(SELECT 1 FROM sys.traces WHERE id=@id AND is_default=0 AND path=@file AND status=1) BEGIN
EXEC @r=sys.sp_trace_setstatus @id,0;
IF @r<>0 BEGIN SELECT @r AS TraceStopReturnCode; RAISERROR(N'Own trace could not be stopped.',16,1); END;
END;
IF EXISTS(SELECT 1 FROM sys.traces WHERE id=@id AND is_default=0 AND path=@file) BEGIN
EXEC @r=sys.sp_trace_setstatus @id,2;
IF @r<>0 BEGIN SELECT @r AS TraceCloseReturnCode; RAISERROR(N'Own trace could not be closed.',16,1); END;
END;
END;
IF @file IS NULL BEGIN
DECLARE @files TABLE(subdirectory nvarchar(512),depth int,[file] bit);
INSERT INTO @files EXEC master.dbo.xp_dirtree @dir,1,1;
SELECT TOP 1 @file=@prefix+subdirectory FROM @files WHERE [file]=1 AND depth=1 AND LEFT(subdirectory,LEN(@base))=@base AND LEN(subdirectory)=LEN(@base)+51 AND SUBSTRING(subdirectory,LEN(@base)+15,1)=N'_' AND RIGHT(subdirectory,4)=N'.trc' ORDER BY subdirectory DESC;
END;
IF @file IS NULL RAISERROR(N'No matching MYG error trace was found in the existing backup directory.',16,1);
SELECT @file AS ReadOnlyTraceFile,@id AS ClosedOwnTraceID;
SELECT TOP 100 StartTime,SPID,EventClass,Error,Severity,CONVERT(nvarchar(2000),TextData) AS ErrorMessage FROM sys.fn_trace_gettable(@file,1) WHERE DatabaseID=@db AND EventClass IN(33,162) ORDER BY StartTime DESC,SPID,EventClass;
END TRY
BEGIN CATCH
DECLARE @message nvarchar(4000); SET @message=ERROR_MESSAGE();
BEGIN TRY
IF EXISTS(SELECT 1 FROM sys.traces WHERE id=@id AND is_default=0 AND path=@file AND LEFT(path,LEN(@prefix+@base))=@prefix+@base) BEGIN
IF EXISTS(SELECT 1 FROM sys.traces WHERE id=@id AND status=1) EXEC sys.sp_trace_setstatus @id,0;
EXEC sys.sp_trace_setstatus @id,2;
END;
END TRY
BEGIN CATCH
PRINT N'Own trace cleanup failed: '+ERROR_MESSAGE();
END CATCH;
RAISERROR(N'%s',16,1,@message);
END CATCH;
