﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Menu', 'Reporte', 'Capturar', 'Cerrar')]
    [string]$Accion = 'Menu',
    [string]$CodigoPresupuesto = ''
)

# Herramienta de desarrollo: usa los permisos Windows ya existentes.
# Los informes se guardan localmente, fuera del proyecto y de la entrega ZIP.
$ErrorActionPreference = 'Stop'
$runDir = $null
$resultCode = 0
$oldConsoleEncoding = [Console]::OutputEncoding
$oldOutputEncoding = $OutputEncoding

try {
    if ($env:OS -ne 'Windows_NT') {
        throw 'Esta herramienta requiere Windows y el SQLCMD de la instalacion S10.'
    }
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Cierra esta ventana y ejecuta Diagnosticar-S10.cmd con clic derecho: Ejecutar como administrador.'
    }
    $sqlcmd = Get-Command sqlcmd.exe -CommandType Application -ErrorAction SilentlyContinue
    if ($null -eq $sqlcmd) {
        throw 'No se encontro sqlcmd.exe. Usa el equipo donde ya comprobaste la conexion a S10.'
    }

    if ($Accion -eq 'Menu') {
        Write-Host 'Diagnostico S10: servidor localhost, copia S10_MYG_PRUEBA.'
        Write-Host '1. Informe de la importacion (solo lectura).'
        Write-Host '2. Capturar Error 0: reproducir F9 una vez y cerrar la captura.'
        Write-Host '3. Cerrar y leer una captura MYG pendiente.'
        Write-Host '0. Salir.'
        switch (Read-Host 'Elige una opcion') {
            '1' { $Accion = 'Reporte' }
            '2' { $Accion = 'Capturar' }
            '3' { $Accion = 'Cerrar' }
            '0' { exit 0 }
            default { throw 'Opcion no reconocida.' }
        }
    }
    if ($Accion -eq 'Reporte' -or $Accion -eq 'Capturar') {
        if ([string]::IsNullOrWhiteSpace($CodigoPresupuesto)) {
            $CodigoPresupuesto = Read-Host 'Codigo del presupuesto importado: siete digitos, como aparece en el titulo de S10'
        }
        if ($CodigoPresupuesto -notmatch '^[0-9]{7}$') {
            throw 'El codigo debe tener exactamente siete digitos. Conserva sus ceros iniciales.'
        }
    }

    $taskDir = Join-Path ([IO.Path]::GetTempPath()) 'MYG-S10-Diagnostico'
    $runName = (Get-Date -Format 'yyyyMMdd-HHmmss') + '_' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
    $runDir = Join-Path $taskDir $runName
    [IO.Directory]::CreateDirectory($runDir) | Out-Null
    [Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
    $OutputEncoding = [Console]::OutputEncoding

    function Invoke-S10DiagnosticSql {
        param(
            [Parameter(Mandatory = $true)][string]$FileName,
            [Parameter(Mandatory = $true)][string]$LogName,
            [ValidateSet('master', 'S10_MYG_PRUEBA')][string]$Database
        )
        $source = Join-Path $PSScriptRoot $FileName
        $content = Get-Content -LiteralPath $source -Raw -Encoding UTF8
        if ($content.Contains('__MYG_BUDGET__')) {
            if ($CodigoPresupuesto -notmatch '^[0-9]{7}$') {
                throw 'Falta un codigo de presupuesto valido para el informe.'
            }
            $content = $content.Replace('__MYG_BUDGET__', $CodigoPresupuesto)
        }
        $inputPath = Join-Path $runDir $FileName
        $logPath = Join-Path $runDir $LogName
        [IO.File]::WriteAllText($inputPath, $content, (New-Object Text.UTF8Encoding($true)))
        $previousPreference = $ErrorActionPreference
        try {
            # PowerShell 5 puede convertir stderr nativo en ErrorRecord.
            # Capturarlo y preservar el codigo real de SQLCMD antes de fallar.
            $ErrorActionPreference = 'Continue'
            $records = @(& $sqlcmd.Source -S localhost -E -d $Database -b -f 65001 -W -w 240 -s '|' -i $inputPath 2>&1)
            $nativeCode = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $previousPreference
        }
        $lines = @($records | ForEach-Object { $_.ToString() })
        [IO.File]::WriteAllLines($logPath, [string[]]$lines, (New-Object Text.UTF8Encoding($true)))
        $lines | ForEach-Object { Write-Host $_ }
        if ($null -eq $nativeCode -or $nativeCode -ne 0) {
            throw "SQLCMD no completo el diagnostico (codigo $nativeCode). Mensaje original guardado en $logPath"
        }
        return $logPath
    }

    switch ($Accion) {
        'Reporte' {
            $null = Invoke-S10DiagnosticSql -FileName 'revisar-importacion.sql' -LogName 'informe.txt' -Database 'S10_MYG_PRUEBA'
        }
        'Capturar' {
            $null = Invoke-S10DiagnosticSql -FileName 'revisar-importacion.sql' -LogName 'informe-antes.txt' -Database 'S10_MYG_PRUEBA'
            $traceStarted = $false
            try {
                $null = Invoke-S10DiagnosticSql -FileName 'iniciar-traza.sql' -LogName 'inicio-captura.txt' -Database 'master'
                $traceStarted = $true
                Write-Host ''
                Write-Host 'En S10 selecciona el presupuesto de S10_MYG_PRUEBA y ejecuta F9 una sola vez.'
                Write-Host 'Repite la misma respuesta que produjo Error 0. Conserva la fecha y los precios.'
                $null = Read-Host 'Cuando termine o aparezca el error, vuelve aqui y pulsa Enter (la captura dura como maximo 10 minutos)'
            }
            finally {
                if ($traceStarted) {
                    $null = Invoke-S10DiagnosticSql -FileName 'cerrar-traza.sql' -LogName 'errores-sql.txt' -Database 'master'
                }
            }
            $null = Invoke-S10DiagnosticSql -FileName 'revisar-importacion.sql' -LogName 'informe-despues.txt' -Database 'S10_MYG_PRUEBA'
        }
        'Cerrar' {
            $null = Invoke-S10DiagnosticSql -FileName 'cerrar-traza.sql' -LogName 'errores-sql.txt' -Database 'master'
        }
    }
}
catch {
    $resultCode = 1
    Write-Host ('DIAGNOSTICO NO COMPLETADO: ' + $_.Exception.Message) -ForegroundColor Red
}
finally {
    [Console]::OutputEncoding = $oldConsoleEncoding
    $OutputEncoding = $oldOutputEncoding
    if ($null -ne $runDir -and (Test-Path -LiteralPath $runDir)) {
        Write-Host ('Informes locales: ' + $runDir)
        try { Start-Process explorer.exe -ArgumentList ('"' + $runDir + '"') | Out-Null }
        catch { Write-Host 'Puedes abrir la carpeta anterior manualmente.' }
    }
}
exit $resultCode
