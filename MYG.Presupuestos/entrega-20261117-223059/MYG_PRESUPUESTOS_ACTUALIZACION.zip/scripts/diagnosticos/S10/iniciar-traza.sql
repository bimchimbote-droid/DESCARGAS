SET NOCOUNT ON;
DECLARE @id int,@db int,@r int,@e int,@c int,@on bit,@max bigint,@until datetime,@dir nvarchar(4000),@prefix nvarchar(4000),@path nvarchar(245);
SELECT @db=DB_ID(N'S10_MYG_PRUEBA'),@on=1,@max=5,@until=DATEADD(minute,10,GETDATE());
BEGIN TRY
IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 RAISERROR(N'Use the verified SQL sysadmin session.',16,1);
IF @db IS NULL RAISERROR(N'Database S10_MYG_PRUEBA was not found.',16,1);
IF (SELECT COUNT(*) FROM sys.trace_events WHERE trace_event_id IN(33,162))<>2 RAISERROR(N'Required trace events are unavailable.',16,1);
IF (SELECT COUNT(*) FROM sys.trace_event_bindings b JOIN sys.trace_columns c ON c.trace_column_id=b.trace_column_id WHERE b.trace_event_id IN(33,162) AND c.name IN(N'DatabaseID',N'TextData'))<>4 RAISERROR(N'Trace cannot capture both events with DatabaseID and TextData.',16,1);
IF NOT EXISTS(SELECT 1 FROM sys.trace_columns WHERE trace_column_id=3 AND name=N'DatabaseID' AND is_filterable=1) RAISERROR(N'Database trace filtering is unavailable.',16,1);
EXEC @r=master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory',@dir OUTPUT;
IF @r<>0 OR NULLIF(@dir,N'') IS NULL RAISERROR(N'Cannot resolve the existing SQL backup directory.',16,1);
SET @prefix=@dir+CASE WHEN RIGHT(@dir,1) IN(N'\',N'/') THEN N'' ELSE N'\' END+N'MYG_S10_Error0_';
IF EXISTS(SELECT 1 FROM sys.traces WHERE is_default=0 AND LEFT(path,LEN(@prefix))=@prefix) RAISERROR(N'Stop and read the existing MYG trace before starting another capture.',16,1);
IF LEN(@prefix)+47>245 RAISERROR(N'Trace path is too long.',16,1);
SET @path=@prefix+CONVERT(nvarchar(8),GETDATE(),112)+REPLACE(CONVERT(nvarchar(8),GETDATE(),108),N':',N'')+N'_'+REPLACE(CONVERT(nvarchar(36),NEWID()),N'-',N'');
EXEC @r=sys.sp_trace_create @id OUTPUT,0,@path,@max,@until;
IF @r<>0 BEGIN SELECT @r AS TraceReturnCode; RAISERROR(N'sp_trace_create failed.',16,1); END;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT b.trace_event_id,b.trace_column_id FROM sys.trace_event_bindings b JOIN sys.trace_columns tc ON tc.trace_column_id=b.trace_column_id WHERE b.trace_event_id IN(33,162) AND tc.name IN(N'TextData',N'DatabaseID',N'SPID',N'StartTime',N'Error',N'Severity',N'EventClass');
OPEN c;
FETCH NEXT FROM c INTO @e,@c;
WHILE @@FETCH_STATUS=0 BEGIN
EXEC @r=sys.sp_trace_setevent @id,@e,@c,@on;
IF @r<>0 BEGIN SELECT @r AS TraceReturnCode; RAISERROR(N'sp_trace_setevent failed.',16,1); END;
FETCH NEXT FROM c INTO @e,@c;
END;
CLOSE c; DEALLOCATE c;
EXEC @r=sys.sp_trace_setfilter @id,3,0,0,@db;
IF @r<>0 BEGIN SELECT @r AS TraceReturnCode; RAISERROR(N'sp_trace_setfilter failed.',16,1); END;
EXEC @r=sys.sp_trace_setstatus @id,1;
IF @r<>0 BEGIN SELECT @r AS TraceReturnCode; RAISERROR(N'sp_trace_setstatus failed.',16,1); END;
SELECT @id AS TraceID,@path+N'.trc' AS TraceFile,@until AS AutoStop,CONVERT(nvarchar(128),SERVERPROPERTY(N'Edition')) AS Edition;
PRINT N'Only SQL errors for S10_MYG_PRUEBA; 5 MB maximum; automatic stop in 10 minutes. Reproduce F9 once, then stop/read this trace.';
END TRY
BEGIN CATCH
DECLARE @message nvarchar(4000); SET @message=ERROR_MESSAGE();
IF CURSOR_STATUS('local','c')>=0 CLOSE c;
IF CURSOR_STATUS('local','c')>-3 DEALLOCATE c;
BEGIN TRY
IF EXISTS(SELECT 1 FROM sys.traces WHERE id=@id AND is_default=0 AND LEFT(path,LEN(@prefix))=@prefix) BEGIN EXEC sys.sp_trace_setstatus @id,0; EXEC sys.sp_trace_setstatus @id,2; END;
END TRY
BEGIN CATCH
PRINT N'Trace cleanup failed: '+ERROR_MESSAGE();
END CATCH;
RAISERROR(N'%s',16,1,@message);
END CATCH;
