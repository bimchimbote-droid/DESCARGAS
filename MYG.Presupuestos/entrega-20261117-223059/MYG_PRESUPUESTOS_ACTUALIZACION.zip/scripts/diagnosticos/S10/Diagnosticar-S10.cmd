@echo off
setlocal DisableDelayedExpansion
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Diagnosticar-S10.ps1"
set "MYG_DIAG_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %MYG_DIAG_EXIT%
