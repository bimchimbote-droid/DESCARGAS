# Exportar a S10 Presupuestos 2005

En el editor, abra **Exportar → Exportar a S10 Presupuestos 2005…**. Seleccione el
presupuesto, su ubicación real y la fecha de costos. El código de usuario S10 es
opcional: si queda vacío, se identifica al usuario a partir de la sesión SQL que
ejecuta la importación.

## Respaldo nativo S2K

El formato predeterminado es **Respaldo S10 (*.S2K)**. MYG genera un respaldo
binario de SQL Server desde una base temporal e incluye los presupuestos
seleccionados del proyecto. Mantiene también los catálogos y usuarios de la
plantilla S10. El archivo SQL intermedio se ejecuta automáticamente: no hace
falta abrir Management Studio ni pegar consultas.

Esta primera implementación usa **SQL Server 2005 local y SQLCMD**, ya instalados
en el equipo, con autenticación de Windows y permisos SQL de administrador. En
**SQL Server local**, escriba `localhost` o el nombre de su instancia local.
Los servidores remotos y otras versiones del motor se rechazan con un mensaje;
un respaldo de un motor reciente no garantiza que pueda abrirse en S10 antiguo.
Si su acceso SQL administrativo depende de ejecutar Windows con privilegios
elevados, abra MYG con **Ejecutar como administrador**.

En **Plantilla S10 vacía**, elija un `.S2K` o `.bak` válido de una base creada
por S10, con sus tablas, procedimientos y catálogos, **sin presupuestos**. Una
base SQL recién creada sin la estructura de S10 no sirve. Una base con
presupuestos se rechaza; MYG no la limpia ni borra sus proyectos. La muestra
`BASE ISOLINA.S2K` permitió identificar el formato, pero no se distribuye con
MYG ni se presupone que esté vacía.

La plantilla se prepara una vez desde la administración de bases de S10:
cree una base S10 nueva y vacía y genere su respaldo nativo. Conserve ese
archivo y selecciónelo al exportar. También puede instalarlo junto al
ejecutable con el nombre `S10PlantillaVacia.S2K`; MYG lo preselecciona si existe.
La plantilla es un archivo de datos de su instalación y no se compila como C#.

1. Abra **Exportar → Exportar a S10 Presupuestos 2005…** y mantenga el formato
   **Respaldo S10 (*.S2K)**.
2. Seleccione el alcance, nombre, fecha y ubicación de los presupuestos.
3. Indique la instancia SQL local y elija la plantilla vacía.
4. Pulse **Exportar…** y elija la carpeta y nombre del `.S2K`.
5. Restaure el archivo con la administración de bases de S10. Ejecute
   **Hoja del Presupuesto → Procesar (F9)** antes de abrir un ACU y compare sus
   importes con MYG.

El servicio SQL y MYG necesitan acceso a la carpeta de trabajo de respaldos
de la instancia. MYG crea allí archivos con nombres únicos; la carpeta final
elegida para guardar el S2K sólo necesita ser accesible para MYG. El original
de la plantilla se conserva. La restauración se dirige a una base y archivos
temporales propios, sin reemplazar `S10`, `S10_MYG_PRUEBA` ni otras bases.
La comprobación de importación y la verificación del respaldo deben terminar
antes de publicar el destino. Un fallo conserva el archivo final anterior.

La verificación SQL comprueba el respaldo y los datos insertados; no ejecuta
el cliente S10 ni su cálculo F9. El `Error 0` observado en esa instalación
sigue pendiente de diagnóstico. No se considera resuelto por generar un S2K.

## Script SQL

El formato **Script SQL (*.sql)** conserva la exportación manual para ejecutar
el archivo completo en SQL Server sobre **una copia de la base S10**. Crea
registros nuevos dentro de una transacción y comprueba el esquema de destino.
Abra y procese el presupuesto importado en S10 y compare sus importes antes de
utilizarlo.

**Ejecute Hoja del Presupuesto → Procesar (F9) antes de abrir cualquier ACU del
presupuesto recién importado.** En la prueba de integración, la hoja mostraba
los importes importados, pero abrir un ACU sin ese procesamiento mostraba los
recursos a cero y cambiaba su precio unitario. F9 generó el análisis y recuperó
sus precios. Por eso el resultado SQL distingue datos guardados de cálculo
pendiente en S10; el mensaje de importación no valida el proceso nativo.

Antes del `COMMIT`, el lote comprueba cada precio de insumo del presupuesto
nuevo y su precio general con la clave exacta de ubicación, año, mes y moneda.
Un registro ausente, `NULL` o distinto provoca la reversión. Un precio realmente
cero se conserva como cero: no se sustituye por un precio de otro período.

## Usuario de la importación

El nombre de acceso a S10 (por ejemplo, `sa`) y su código interno no son el mismo
dato. No escriba una contraseña en el campo **Código de usuario S10**.

- Con una sesión SQL que ya tiene el rol de servidor `sysadmin` y entra a la base
  como `dbo`, se reconoce al administrador reservado `0000000`, si esa fila
  existe, tiene `Administrador=1` y su `uid` coincide con la sesión. Este registro
  puede tener `Activo=0`; el exportador no lo activa ni cambia sus permisos.
- Para otras sesiones, se busca un usuario activo vinculado por SID o por el
  identificador de usuario de la base. Se excluyen el reservado y los códigos
  cortos de grupos. Si hay más de un candidato se pide un código explícito.
- Un código explícito normal debe identificar un usuario activo de siete
  caracteres. El código reservado `0000000` exige siempre las comprobaciones
  administrativas anteriores, incluso si figura activo. Un código inválido no
  provoca una sustitución por otro usuario.

Para el acceso administrativo descrito, puede dejar **Código de usuario S10**
vacío y generar de nuevo el SQL con esta versión. Se conserva la asignación del
presupuesto nuevo mediante `PresupuestoUsuario`; no se modifican usuarios,
contraseñas, roles ni permisos existentes. Las validaciones y restricciones de
la base siguen vigentes y un error revierte la importación.

## Ejecutar en SQL Server 2005

Las versiones recientes de SSMS pueden no conectarse a SQL Server 2005. Si la
instalación ya dispone de `sqlcmd`, puede ejecutar el archivo contra una copia
preparada de su base S10. Por ejemplo, desde la carpeta que contiene el SQL:

```bat
sqlcmd -S localhost -E -d S10_MYG_PRUEBA -b -f 65001 -i "presupuesto.sql"
```

`S10_MYG_PRUEBA` debe ser una copia válida de S10, con sus tablas y catálogos, no
una base vacía. `-E` usa la cuenta de Windows de esa consola; ejecutarla como
administrador sólo aprovecha los permisos que ya tenga asignados en SQL Server.
El archivo generado es UTF-8; `-f 65001` conserva sus caracteres. Compruebe el
resultado antes de repetir la importación, para no duplicar presupuestos.

## Diagnóstico del proceso S10

Los scripts de `scripts/diagnosticos/S10` son herramientas opcionales para el
desarrollador en el equipo de prueba. No son una dependencia del ejecutable MYG
ni deben instalarse en las PC de los clientes para ejecutar MYG.

1. Extraiga la carpeta completa de la entrega, conservando juntos sus archivos.
2. Haga clic derecho en `Diagnosticar-S10.cmd` y elija **Ejecutar como
   administrador**. Utiliza el SQLCMD ya instalado y autenticación de Windows;
   no solicita ni guarda contraseñas.
3. Elija **1** para un informe de solo lectura, o **2** para registrar un
   «Error 0». Introduzca el código de siete dígitos del presupuesto que figura
   en la barra de título de S10, conservando sus ceros iniciales.
4. La opción **2** guarda un informe anterior e inicia una captura limitada a
   errores del motor SQL en `S10_MYG_PRUEBA`. Vuelva a S10, reproduzca F9 una sola
   vez y, al terminar o aparecer el aviso, vuelva a la consola y pulse Enter.
   El script cierra su captura y guarda los errores y el informe posterior.
5. Se abre la carpeta de resultados. Para revisar el problema, conserve
   `errores-sql.txt`, `informe-antes.txt` e `informe-despues.txt`. Estos archivos
   pueden contener nombres e importes del presupuesto; revíselos antes de
   compartirlos. No se publican automáticamente ni se incluyen en el ZIP.

La herramienta trabaja únicamente con `localhost` y la copia
`S10_MYG_PRUEBA`. No crea usuarios, altera permisos, modifica precios ni cambia
la instalación de S10. La captura usa únicamente eventos de error, un máximo
de 5 MB y parada automática a los diez minutos. No captura todas las consultas
ni los inicios de sesión. Si se interrumpe la consola, la opción **3** permite
cerrar y leer una captura MYG pendiente; no afecta otras trazas del servidor.

El informe incluye los ajustes de precisión, estado del proceso, precios cero
y `NULL`, datos de los análisis, fórmulas del pie y las mayores diferencias
entre importes base y recalculados. Los valores cero de los contadores no se
presentan como prueba de que el proceso terminó bien.

La disponibilidad real de SQL Trace en la instalación se comprueba al ejecutar
el inicio. Un fallo se muestra con su mensaje original, sin sustituirlo por
«Error 0» ni ampliar la captura a otras bases. Un archivo sin errores SQL
registrados tampoco certifica el funcionamiento del cliente S10.

## Precisión numérica

Los cálculos de MYG pueden producir más decimales que las columnas de S10. El
mensaje «PresupuestoInsumo.Precio1: El valor exige más de 9 decimales» se refiere a
un precio calculado, no a los datos que se escriben en el formulario.

Al exportar se redondea cada número a la escala de su columna, según el perfil
S10 incluido en el proyecto. Las mitades se redondean alejándose de cero.

| Destino | Decimales admitidos |
|---|---:|
| Precios de insumos (`PresupuestoInsumo`, `PrecioGeneral`) | 9 |
| Metrados (`SubpresupuestoDetalle`) | 9 |
| Precios de partidas y cantidades del análisis | 13 |
| Cuadrilla | 9 |
| Rendimiento de mano de obra y equipo | 4 |
| Jornada | 2 |

Por ejemplo, un precio `1.23456789155` se exporta como `1.234567892` en una columna
de nueve decimales. La cuadrilla se calcula con el consumo, rendimiento y jornada
que realmente recibirá S10, y después se ajusta a sus nueve decimales.

Cada cambio se informa en los avisos de la exportación. El SQL conserva además
un comentario JSON de una sola línea con el prefijo `MYG_PRECISION_NUMERICA`:
incluye contexto, tabla, columna, valor original, valor exportado, precisión y
escala. Los valores numéricos usan punto decimal independientemente del idioma
del equipo. Los ceros finales que no cambian el valor no generan avisos.

El proyecto, las opciones y la base SQLite de MYG conservan sus valores
originales. Los importes pueden variar al reprocesar los análisis en S10 por su
precisión de almacenamiento. Revise los avisos y compare precios, parciales y
totales en la copia. El pie conserva los importes calculados de MYG: si modifica
metrados o precios en S10, revise sus fórmulas antes de reprocesar.

Con parciales importados de más de trece decimales, la suma de los parciales
redondeados puede diferir del resumen original. El exportador informa ambas
cifras y valida el SQL contra la suma que realmente inserta; no recalcula ni
reescribe silenciosamente el resumen y el pie originales.

Se siguen rechazando los valores que exceden la parte entera admitida, incluido
un desbordamiento causado por el redondeo. Si el rendimiento o la jornada quedan
en cero a la precisión de S10, se indica la partida afectada y se detiene la
exportación para evitar un análisis inválido. Otros valores que se redondeen a
cero se señalan expresamente. Un fallo de validación conserva el archivo SQL
anterior sin escribir una exportación parcial.

## Descripciones

Se mantienen las correcciones anteriores: equivalentes compatibles con
Windows-1252 para símbolos conocidos, compactación de espacios y abreviación de
descripciones que excedan su columna. Los textos completos ajustados por
longitud quedan en comentarios `MYG_DESCRIPCION_COMPLETA`. Los códigos, unidades
y fórmulas siguen validados estrictamente; no se sustituyen por texto inventado.

## Validación del código

Requiere el SDK .NET 10 de `global.json`. Desde la raíz del repositorio:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --exportacion-s10
```

La opción de referencias Revit permite comprobar la compilación sin instalar
Revit. Las pruebas de exportación usan datos sintéticos y no ejecutan SQL Server
ni S10. La interfaz y la importación real deben comprobarse en Windows.
