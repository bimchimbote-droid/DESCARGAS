using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesContextoCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarFormatosPegado(exige);
        VerificarOrtografia(exige);
        VerificarHitTestFuenteGrande(exige);
        VerificarAnotaciones(exige);
        VerificarEditor(exige);
    }

    private static void VerificarHitTestFuenteGrande(Action<bool, string> exige)
    {
        using var documento = new RichTextBox { Font = new Font("Arial", 11), Text = "hormigonx", Dock = DockStyle.Fill };
        using var formulario = new Form { ClientSize = new Size(600, 200) };
        using var grande = new Font("Arial", 36, FontStyle.Bold);
        formulario.Controls.Add(documento); formulario.Show();
        documento.SelectAll(); documento.SelectionFont = grande;
        Application.DoEvents();
        Point inicio = documento.GetPositionFromCharIndex(0), fin = documento.GetPositionFromCharIndex(1);
        Point interior = new((inicio.X + fin.X) / 2, inicio.Y + grande.Height / 2);
        exige(MYGEspecificacionesOrtografia.ContieneCaracter(documento, 0, interior),
            "El clic derecho debe reconocer la mitad inferior de un carácter cuya fuente es mayor que la fuente base.");
        exige(!MYGEspecificacionesOrtografia.ContieneCaracter(documento, 0, new Point(interior.X, 180)),
            "El margen vacío debajo de una palabra no debe reconocerse como un carácter ortográfico.");
    }

    private static void VerificarFormatosPegado(Action<bool, string> exige)
    {
        using var fuente = new RichTextBox { Font = new Font("Arial", 11), Text = "Hormigón armado" };
        fuente.Select(0, 8);
        fuente.SelectionFont = new Font("Arial", 14, FontStyle.Bold);
        fuente.SelectionColor = Color.DarkGreen;
        fuente.Select(9, 6);
        fuente.SelectionFont = new Font("Courier New", 10, FontStyle.Italic);
        var datos = new DataObject();
        datos.SetData(DataFormats.Rtf, false, fuente.Rtf);
        datos.SetData(DataFormats.Html, false, "<p><b>Hormigón</b> <i>armado</i></p>");
        datos.SetData(DataFormats.UnicodeText, false, fuente.Text);
        var copia = MYGEspecificacionesPegado.Capturar(datos);
        exige(Enum.GetValues<MYGFormatoPegado>().All(copia.Disponible),
            "El pegado debe reconocer RTF, HTML y texto del mismo IDataObject.");
        datos.SetData(DataFormats.UnicodeText, false, "Cambiado después de abrir el diálogo");
        exige(copia.Texto == "Hormigón armado", "El diálogo debe conservar la copia del portapapeles tomada al abrirse.");

        using var destino = new RichTextBox { Font = new Font("Arial", 11) };
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(copia, MYGFormatoPegado.Automatico));
        destino.Select(0, 8);
        exige(destino.Text == fuente.Text && destino.SelectionFont?.Bold == true &&
            Math.Abs(destino.SelectionFont.Size - 14) < .01 && destino.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "Pegar automáticamente debe elegir RTF y conservar tamaño, negrita y color del primer fragmento.");
        destino.Select(9, 6);
        exige(destino.SelectionFont?.Italic == true && destino.SelectionFont.Name == "Courier New",
            "El RTF pegado debe conservar el formato distinto del segundo fragmento.");
        destino.Clear(); destino.Font = new Font("Arial", 11);
        destino.SelectAll(); destino.SelectionFont = destino.Font; destino.SelectionColor = Color.Black;
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(copia, MYGFormatoPegado.Texto));
        destino.SelectAll();
        exige(destino.Text == fuente.Text && destino.SelectionFont is Font plano && !plano.Bold && !plano.Italic &&
            Math.Abs(plano.Size - 11) < .01 && destino.SelectionColor.ToArgb() == Color.Black.ToArgb(),
            "Texto sin formato debe pegar los mismos caracteres sin importar las fuentes ni los colores del RTF.");

        var html = new DataObject();
        html.SetData(DataFormats.Html, false, "<b>Seguro</b><script>oculto()</script><img src='https://example.com/img' alt=' visible'>");
        var copiaHtml = MYGEspecificacionesPegado.Capturar(html);
        exige(copiaHtml.Disponible(MYGFormatoPegado.Html) && !copiaHtml.Disponible(MYGFormatoPegado.Rtf),
            "Un portapapeles HTML no debe anunciar disponibilidad de RTF.");
        destino.Clear();
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(copiaHtml, MYGFormatoPegado.Automatico));
        destino.Select(0, 6);
        exige(destino.Text == "Seguro visible" && destino.SelectionFont?.Bold == true &&
            !destino.Rtf.Contains("https", StringComparison.OrdinalIgnoreCase) && !destino.Text.Contains("oculto"),
            "El pegado HTML automático debe conservar formato visible y excluir scripts y recursos remotos.");

        var streams = new DataObject();
        var alineado = new MYGEspecificacionesPortapapeles(null,
            "<p style='text-align:center'>Centro</p><p style='text-align:right'>Derecha</p><p>Izquierda</p>", null);
        destino.Clear();
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(alineado, MYGFormatoPegado.Html));
        destino.Select(0, 6);
        exige(destino.SelectionAlignment == HorizontalAlignment.Center, "El HTML debe conservar la alineación centrada del primer párrafo.");
        destino.Select(destino.Text.IndexOf("Derecha", StringComparison.Ordinal), 7);
        exige(destino.SelectionAlignment == HorizontalAlignment.Right, "El HTML debe conservar la alineación derecha sin extenderla al siguiente párrafo.");
        destino.Select(destino.Text.IndexOf("Izquierda", StringComparison.Ordinal), 9);
        exige(destino.SelectionAlignment == HorizontalAlignment.Left, "Un párrafo HTML sin alineación debe conservar la alineación izquierda.");
        streams.SetData(DataFormats.Rtf, false, new MemoryStream(Encoding.Latin1.GetBytes(fuente.Rtf + '\0')));
        streams.SetData(DataFormats.UnicodeText, false, new MemoryStream(Encoding.Unicode.GetBytes("área\0")));
        var copiaStream = MYGEspecificacionesPegado.Capturar(streams);
        exige(copiaStream.Rtf == fuente.Rtf && copiaStream.Texto == "área",
            "Capturar el portapapeles debe decodificar streams RTF/texto Unicode y quitar el terminador nulo.");

        var texto = new DataObject(); texto.SetData(DataFormats.UnicodeText, false, "Sólo texto");
        using var dialogo = new MYGEspecificacionesPegadoForm(MYGEspecificacionesPegado.Capturar(texto));
        exige(dialogo.Formatos.Items.Cast<string>().SequenceEqual(new[] { "Pegar", "Texto con Formato (RTF)", "Formato HTML", "Texto sin formato" }),
            "Pegado Especial debe mostrar las cuatro opciones de la captura en su orden.");
        dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Rtf;
        exige(!((Button)dialogo.AcceptButton).Enabled, "Aceptar debe estar deshabilitado si falta el formato RTF elegido.");
        dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Html;
        exige(!((Button)dialogo.AcceptButton).Enabled, "Aceptar debe estar deshabilitado si falta el formato HTML elegido.");
        dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Texto;
        exige(((Button)dialogo.AcceptButton).Enabled, "Texto sin formato debe estar disponible cuando el portapapeles contiene texto.");
        var vacio = MYGEspecificacionesPegado.Capturar(null);
        exige(!Enum.GetValues<MYGFormatoPegado>().Any(vacio.Disponible) &&
            MYGEspecificacionesPegado.Preparar(vacio, MYGFormatoPegado.Automatico) == null,
            "Un portapapeles vacío no debe producir contenido ni anunciar formatos disponibles.");
    }

    private static void VerificarOrtografia(Action<bool, string> exige)
    {
        using var documento = new RichTextBox { Font = new Font("Arial", 14), Text = "Correcto hormigonx y hormigonx final", Dock = DockStyle.Fill };
        using var formulario = new Form { ClientSize = new Size(700, 250) };
        formulario.Controls.Add(documento); formulario.Show(); Application.DoEvents();
        documento.Select(9, 9); documento.SelectionFont = new Font("Arial", 14, FontStyle.Bold);
        documento.SelectionColor = Color.DarkGreen;
        documento.Select(documento.Text.IndexOf("final", StringComparison.Ordinal), 5);
        documento.SelectionFont = new Font("Courier New", 12, FontStyle.Italic);
        documento.ClearUndo(); documento.Select(2, 3);
        int cambiosTexto = 0, altasDiccionario = 0;
        documento.TextChanged += (_, _) => cambiosTexto++;
        using var corrector = new MYGEspecificacionesOrtografia(documento, BuscarErrores,
            _ => new[] { "hormigón", "hormigón", "hormigon" }, _ => altasDiccionario++);
        corrector.ComprobarAhora();
        exige(corrector.RevisionCompleta && corrector.Errores.Count == 2 && corrector.ObtenerError(9)?.Palabra == "hormigonx" &&
            corrector.ObtenerError(18) == null && corrector.ObtenerError(-1) == null,
            "La revisión debe localizar cada aparición y respetar los límites de las palabras.");
        exige(corrector.Sugerencias(corrector.Errores[0]).SequenceEqual(new[] { "hormigón", "hormigon" }),
            "Las sugerencias ortográficas deben conservar su orden sin duplicarlas.");

        string rtf = documento.Rtf; int inicio = documento.SelectionStart, longitud = documento.SelectionLength;
        bool deshacer = documento.CanUndo; using var imagen = new Bitmap(documento.Width, documento.Height);
        using (var dibujo = Graphics.FromImage(imagen))
        {
            dibujo.Clear(Color.White); corrector.Pintar(dibujo, documento.ClientRectangle);
        }
        bool hayRojo = false;
        for (int y = 0; y < imagen.Height && !hayRojo; y++)
            for (int x = 0; x < imagen.Width && !hayRojo; x++)
            {
                Color color = imagen.GetPixel(x, y);
                hayRojo = color.R > 150 && color.G < 100 && color.B < 110;
            }
        exige(hayRojo, "Los errores deben dibujarse con un subrayado rojo visible.");
        exige(documento.Rtf == rtf && documento.SelectionStart == inicio && documento.SelectionLength == longitud &&
            documento.CanUndo == deshacer && cambiosTexto == 0,
            "Pintar la ortografía no debe cambiar RTF, selección, Deshacer ni emitir un cambio del texto.");

        corrector.Ignorar(corrector.Errores[0]);
        exige(corrector.Errores.Count == 1 && corrector.Errores[0].Inicio == 21 && documento.Rtf == rtf && cambiosTexto == 0,
            "Ignorar debe retirar sólo la aparición elegida sin modificar el documento.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        exige(corrector.Errores.Count == 2, "Cargar otra partida debe volver a revisar las apariciones ignoradas.");
        corrector.IgnorarTodo(corrector.Errores[0]);
        exige(corrector.Errores.Count == 0 && documento.Rtf == rtf && cambiosTexto == 0,
            "Ignorar todo debe retirar ambas marcas sin tocar RTF ni emitir cambios.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        corrector.AgregarAlDiccionario(corrector.Errores[0]);
        exige(altasDiccionario == 1 && corrector.Errores.Count == 0 && documento.Rtf == rtf && cambiosTexto == 0,
            "Agregar al diccionario debe usar el proveedor una vez y retirar las marcas sin editar la especificación.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        var anterior = corrector.Errores[0]; corrector.Corregir(anterior, "hormigón");
        exige(documento.Text == "Correcto hormigón y hormigonx final" && cambiosTexto == 1,
            "Corregir debe reemplazar sólo la aparición elegida del error.");
        documento.Select(9, 8);
        exige(documento.SelectionFont?.Bold == true && documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "Una sugerencia debe conservar la negrita y el color de la palabra corregida.");
        documento.Select(documento.Text.IndexOf("final", StringComparison.Ordinal), 5);
        exige(documento.SelectionFont?.Italic == true && documento.SelectionFont.Name == "Courier New",
            "Corregir una palabra no debe homogeneizar el formato del resto de la especificación.");
        rtf = documento.Rtf; corrector.Corregir(anterior, "reemplazo obsoleto");
        exige(documento.Rtf == rtf && cambiosTexto == 1, "Una sugerencia obsoleta no debe reemplazar texto que ya cambió.");
        corrector.ComprobarAhora(); documento.ReadOnly = true;
        corrector.Corregir(corrector.Errores[0], "hormigón");
        exige(documento.Rtf == rtf && cambiosTexto == 1, "El corrector debe respetar los documentos de sólo lectura.");
        formulario.Close();
    }

    private static void VerificarEditor(Action<bool, string> exige)
    {
        // Las pruebas usan un proveedor determinista: no dependen de los
        // diccionarios personales ni de los idiomas instalados en Windows.
        int antes = 0, cambios = 0;
        using var documento = new RichTextBox { Font = new Font("Arial", 11), DetectUrls = false };
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "Partida de prueba", () => "und", () => "01", comprobarOrtografia: BuscarErrores,
            sugerirOrtografia: _ => new[] { "hormigón" });
        using var formulario = new Form { ClientSize = new Size(950, 740) };
        formulario.Controls.Add(editor); formulario.Show(); Application.DoEvents();
        editor.Cargar("contexto-A", "", "Correcto hormigonx y hormigonx");
        documento.Focus(); Application.DoEvents();
        var corrector = (MYGEspecificacionesOrtografia)typeof(MYGEspecificacionesEditor)
            .GetField("ortografia", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        corrector.ComprobarAhora();
        var menu = documento.ContextMenuStrip;
        var papel = Controles(editor).Single(x => x.Name == "espec_papel");
        exige(menu != null && ReferenceEquals(papel.ContextMenuStrip, menu),
            "La hoja y el texto deben compartir el menú contextual de la especificación.");
        var originales = new[] { "Cortar", "Copiar", "Pegar", "Aumentar Sangría", "Disminuir Sangría", "Fuente", "Párrafo", "Lista Enumerada", "Marcador...", "Hipervínculo...", "Nuevo comentario" };
        documento.Select(0, 0); AbrirMenu(documento, new Point(2, 2));
        exige(menu.Items.OfType<ToolStripMenuItem>().Select(x => x.Text).SequenceEqual(originales),
            "El clic derecho en texto correcto debe ofrecer todas las herramientas de la segunda captura.");
        exige(!Opcion(menu, "Cortar").Enabled && !Opcion(menu, "Copiar").Enabled,
            "Cortar y Copiar deben estar deshabilitados si no hay texto seleccionado.");
        menu.Close();
        documento.Select(0, 8); AbrirMenu(documento, documento.GetPositionFromCharIndex(1));
        exige(documento.SelectionStart == 0 && documento.SelectionLength == 8 &&
            Opcion(menu, "Cortar").Enabled && Opcion(menu, "Copiar").Enabled,
            "El clic derecho dentro de una selección debe conservarla y habilitar Cortar/Copiar.");
        menu.Close(); documento.ReadOnly = true;
        AbrirMenu(documento, documento.GetPositionFromCharIndex(1));
        exige(!Opcion(menu, "Cortar").Enabled && Opcion(menu, "Copiar").Enabled &&
            menu.Items.OfType<ToolStripMenuItem>().Where(x => x.Text != "Copiar").All(x => !x.Enabled),
            "El menú de sólo lectura debe permitir copiar y bloquear comandos que editan el documento.");
        menu.Close(); documento.ReadOnly = false;

        documento.Select(9, 9); documento.SelectionFont = new Font("Arial", 13, FontStyle.Bold);
        documento.SelectionColor = Color.DarkGreen;
        documento.Select(9, 0);
        int antesInicial = antes, cambiosInicial = cambios; string rtf = editor.DocumentoRtf;
        AbrirMenu(documento, documento.GetPositionFromCharIndex(10));
        var opcionesOrtografia = menu.Items.OfType<ToolStripMenuItem>().Select(x => x.Text).ToArray();
        exige(opcionesOrtografia.Take(5).SequenceEqual(new[] { "hormigón", "Ignorar", "Ignorar todo", "Agregar al Diccionario", "Comprobar ortografía" }) &&
            opcionesOrtografia.Skip(5).SequenceEqual(originales),
            "El clic derecho sobre un error debe anteponer sugerencias y las opciones ortográficas de la tercera captura.");
        Opcion(menu, "Ignorar").PerformClick(); menu.Close();
        exige(corrector.Errores.Count == 1 && editor.DocumentoRtf == rtf && antes == antesInicial && cambios == cambiosInicial,
            "Ignorar desde el menú no debe guardar la partida ni agregar historial.");
        AbrirMenu(papel, new Point(3, 3));
        exige(menu.Items.OfType<ToolStripMenuItem>().Select(x => x.Text).SequenceEqual(originales),
            "El clic derecho en el margen de la hoja no debe mostrar sugerencias del cursor anterior.");
        menu.Close();
        AbrirMenu(documento, documento.GetPositionFromCharIndex(22));
        Opcion(menu, "Ignorar todo").PerformClick(); menu.Close();
        exige(corrector.Errores.Count == 0 && editor.DocumentoRtf == rtf && antes == antesInicial && cambios == cambiosInicial,
            "Ignorar todo desde el menú debe retirar las marcas sin generar una modificación del presupuesto.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        AbrirMenu(documento, documento.GetPositionFromCharIndex(10));
        Opcion(menu, "hormigón").PerformClick(); menu.Close();
        exige(documento.Text == "Correcto hormigón y hormigonx" && antes == antesInicial + 1 && cambios == cambiosInicial + 1,
            "Aceptar una sugerencia contextual debe corregir una palabra y registrar una sola modificación.");
        documento.Select(9, 8);
        exige(documento.SelectionFont?.Bold == true && documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "La corrección contextual debe conservar el formato de la palabra reemplazada.");
        VerificarCancelacionPegado(editor, documento, () => (antes, cambios), exige);
        VerificarAnotacionesPartida(editor, documento, () => (antes, cambios), exige);
        formulario.Close();
    }

    private static void VerificarAnotaciones(Action<bool, string> exige)
    {
        using var documento = new RichTextBox { Text = "Concreto armado conforme al plano" };
        int operaciones = 0;
        using var anotaciones = new MYGEspecificacionesAnotaciones(documento, null, accion => { operaciones++; accion(); });
        documento.Select(9, 6); string rtfSinAnotaciones = documento.Rtf;
        anotaciones.AgregarMarcador("Armadura_01"); anotaciones.AgregarComentario("Verificar diámetro y posición de las barras.");
        exige(operaciones == 2 && documento.Rtf == rtfSinAnotaciones && anotaciones.Elementos.Count == 2,
            "Marcadores y comentarios deben guardar metadatos sin insertar texto ni homogeneizar el formato del documento.");
        var marcador = anotaciones.Elementos.Single(x => x.Tipo == "marcador");
        var comentario = anotaciones.Elementos.Single(x => x.Tipo == "comentario");
        exige(marcador.Inicio == 9 && marcador.Longitud == 6 && comentario.Ancla == "armado",
            "Las anotaciones deben conservar la selección que identifica el texto comentado.");
        string guardado = anotaciones.Guardar(documento.Rtf);
        using var copia = new RichTextBox { Rtf = guardado };
        using var recuperadas = new MYGEspecificacionesAnotaciones(copia, null, accion => accion());
        recuperadas.Leer(guardado);
        exige(copia.Text == documento.Text && recuperadas.Elementos.Count == 2 &&
            recuperadas.Elementos.Single(x => x.Tipo == "comentario").Texto == comentario.Texto &&
            recuperadas.Elementos.Single(x => x.Tipo == "marcador").Id == marcador.Id &&
            recuperadas.Elementos.All(x => x.Inicio == 9 && x.Longitud == 6),
            "El RTF guardado debe recuperar textos Unicode, identificadores y rangos de comentarios/marcadores.");
        string guardadoOtraVez = anotaciones.Guardar(guardado);
        exige(guardadoOtraVez == guardado,
            "Guardar anotaciones dos veces no debe duplicar sus metadatos en el RTF.");

        documento.ClearUndo(); documento.Select(0, 0); documento.SelectedText = "Inicio: ";
        exige(anotaciones.Elementos.All(x => x.Inicio == 17 && x.Longitud == 6),
            "Insertar texto antes de una anotación debe desplazar su rango sin cambiar su longitud.");
        documento.Undo();
        exige(anotaciones.Elementos.All(x => x.Inicio == 9 && x.Longitud == 6),
            "Deshacer el prefijo debe recuperar las posiciones originales de las anotaciones.");
        documento.ClearUndo(); documento.SelectAll(); documento.SelectedText = "";
        exige(anotaciones.Elementos.All(x => x.Inicio == 0 && x.Longitud == 0),
            "Borrar el texto comentado debe colapsar sus rangos sin perder los comentarios.");
        documento.Undo();
        exige(documento.Text == "Concreto armado conforme al plano" &&
            anotaciones.Elementos.All(x => x.Inicio == 9 && x.Longitud == 6),
            "Deshacer el borrado debe recuperar también la selección completa de los comentarios/marcadores.");
        documento.Redo();
        exige(documento.TextLength == 0 && anotaciones.Elementos.All(x => x.Inicio == 0 && x.Longitud == 0),
            "Rehacer el borrado debe volver a colapsar los rangos de las anotaciones.");
        anotaciones.Eliminar(comentario); documento.Undo();
        exige(anotaciones.Elementos.All(x => x.Tipo != "comentario"),
            "Deshacer texto no debe resucitar un comentario que se eliminó explícitamente.");

        documento.Select(9, 6); int antes = operaciones;
        anotaciones.InsertarHipervinculo("Armadura", "https://example.com/planos?tipo=armado");
        exige(operaciones == antes + 1 && documento.Text == "Concreto Armadura conforme al plano" &&
            documento.Rtf.Contains("HYPERLINK", StringComparison.Ordinal) &&
            anotaciones.Elementos.Single(x => x.Tipo == "hipervinculo").Direccion == "https://example.com/planos?tipo=armado",
            "Insertar un hipervínculo debe crear un campo RTF y conservar el texto alrededor del enlace.");
        var vinculo = anotaciones.Elementos.Single(x => x.Tipo == "hipervinculo");
        documento.ClearUndo(); anotaciones.Guardar(documento.Rtf);
        anotaciones.InsertarHipervinculo("Armadura", "https://example.com/planos?tipo=revisado", vinculo.Inicio, vinculo.Longitud, vinculo);
        anotaciones.Guardar(documento.Rtf);
        exige(documento.Text == "Concreto Armadura conforme al plano" && documento.CanUndo &&
            vinculo.Direccion == "https://example.com/planos?tipo=revisado",
            "Editar únicamente el destino debe guardar un campo nuevo sin cambiar la etiqueta del hipervínculo.");
        documento.Undo(); anotaciones.Guardar(documento.Rtf);
        exige(vinculo.Direccion == "https://example.com/planos?tipo=armado" &&
            documento.Rtf.Contains("tipo=armado", StringComparison.Ordinal),
            "Deshacer un destino con etiqueta idéntica debe sincronizar el campo RTF y la dirección de sus metadatos.");
        documento.Redo(); anotaciones.Guardar(documento.Rtf);
        exige(vinculo.Direccion == "https://example.com/planos?tipo=revisado" &&
            documento.Rtf.Contains("tipo=revisado", StringComparison.Ordinal),
            "Rehacer el cambio de destino debe recuperar también la dirección persistida del hipervínculo.");
        antes = operaciones; string anterior = documento.Rtf; bool rechazo = false;
        try { anotaciones.InsertarHipervinculo("Archivo", "javascript:alert(1)"); }
        catch (ArgumentException) { rechazo = true; }
        exige(rechazo && operaciones == antes && documento.Rtf == anterior,
            "Un destino de hipervínculo no admitido debe rechazarse antes de modificar el documento o el historial.");

        documento.Select(0, 8); anotaciones.AgregarComentario("Control adicional");
        using var exportacion = new RichTextBox { Rtf = documento.Rtf };
        anterior = documento.Rtf;
        anotaciones.AñadirComentariosParaExportacion(exportacion);
        exige(exportacion.Text.Contains("COMENTARIOS DE LA ESPECIFICACIÓN") && exportacion.Text.Contains("Control adicional") &&
            documento.Rtf == anterior,
            "Exportar los comentarios debe agregarlos a la copia de salida y conservar el documento editable.");

        using var largo = new RichTextBox { Text = "Antes " + new string('x', 2300) + " después" };
        using var anotacionesLargas = new MYGEspecificacionesAnotaciones(largo, null, accion => accion());
        largo.Select(6, 2300); anotacionesLargas.AgregarComentario("Selección extensa");
        string rtfLargo = anotacionesLargas.Guardar(largo.Rtf); anotacionesLargas.Leer(rtfLargo);
        exige(anotacionesLargas.Elementos.Single().Longitud == 2300 && anotacionesLargas.Elementos.Single().Ancla.Length == 2000,
            "Recuperar comentarios extensos debe conservar su rango completo aunque el texto de referencia esté limitado.");
    }

    private static void VerificarAnotacionesPartida(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int antes, int cambios)> estado, Action<bool, string> exige)
    {
        var anotaciones = (MYGEspecificacionesAnotaciones)typeof(MYGEspecificacionesEditor)
            .GetField("anotaciones", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        documento.Focus(); documento.Select(0, 8); Application.DoEvents();
        var inicial = estado();
        anotaciones.AgregarMarcador("Descripcion"); anotaciones.AgregarComentario("Comentario persistente de la partida A");
        var despues = estado(); string rtf = editor.DocumentoRtf, texto = documento.Text;
        exige(despues.antes == inicial.antes + 2 && despues.cambios == inicial.cambios + 2,
            "Agregar marcador y comentario a la partida debe registrar una modificación por cada comando.");
        editor.Cargar("contexto-B", "", "Otra especificación");
        exige(anotaciones.Elementos.Count == 0 && estado() == despues,
            "Cambiar de partida debe limpiar sus anotaciones sin generar historial ni guardar la especificación abandonada.");
        editor.Cargar("contexto-A", rtf, texto);
        exige(anotaciones.Elementos.Count == 2 && anotaciones.Elementos.Single(x => x.Tipo == "comentario").Texto ==
            "Comentario persistente de la partida A" && editor.DocumentoRtf == rtf && estado() == despues,
            "Volver a una partida debe recuperar sus comentarios y marcadores del RTF sin volver a guardarlos.");
        documento.Select(2, 3); bool deshacer = documento.CanUndo;
        editor.Cargar("contexto-A", rtf, texto);
        exige(documento.SelectionStart == 2 && documento.SelectionLength == 3 && documento.CanUndo == deshacer &&
            anotaciones.Elementos.Count == 2 && estado() == despues,
            "Refrescar la misma partida debe conservar la selección, el historial y las anotaciones.");
    }

    private static void VerificarCancelacionPegado(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int antes, int cambios)> estado, Action<bool, string> exige)
    {
        IDataObject previo = Clipboard.GetDataObject();
        try
        {
            Clipboard.SetText("Contenido que no debe insertarse");
            documento.Select(2, 4); documento.Focus(); Application.DoEvents();
            var inicial = estado(); string rtf = editor.DocumentoRtf;
            bool deshacer = documento.CanUndo; int inicio = documento.SelectionStart, longitud = documento.SelectionLength;
            bool mostrado = false; Exception fallo = null;
            var plazo = Stopwatch.StartNew();
            using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
            temporizador.Tick += (_, _) =>
            {
                if (plazo.Elapsed > TimeSpan.FromSeconds(10))
                {
                    Console.Error.WriteLine("Pegado Especial quedó bloqueado en un diálogo inesperado.");
                    Environment.Exit(1);
                }
                var dialogo = Application.OpenForms.OfType<MYGEspecificacionesPegadoForm>().FirstOrDefault();
                if (dialogo == null || mostrado) return;
                mostrado = true;
                try
                {
                    dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Texto;
                    ((Button)dialogo.CancelButton).PerformClick();
                }
                catch (Exception ex) { fallo = ex; dialogo.Close(); }
            };
            var especial = Controles(editor).OfType<ToolStrip>().SelectMany(x => x.Items.OfType<ToolStripButton>())
                .Single(x => x.Text == "Pegado especial");
            temporizador.Start(); especial.PerformClick(); temporizador.Stop(); Application.DoEvents();
            exige(mostrado && fallo == null, fallo?.Message ?? "El botón Pegado especial debe abrir el selector modal de formatos.");
            exige(editor.DocumentoRtf == rtf && documento.SelectionStart == inicio && documento.SelectionLength == longitud &&
                documento.CanUndo == deshacer && estado() == inicial,
                "Cancelar Pegado Especial debe conservar texto, formato, selección, Deshacer y callbacks del presupuesto.");
        }
        finally
        {
            if (previo != null) Clipboard.SetDataObject(previo, true);
            else Clipboard.Clear();
        }
    }

    private static IReadOnlyList<MYGErrorOrtografico> BuscarErrores(string texto)
    {
        var errores = new List<MYGErrorOrtografico>();
        for (int desde = 0; desde < texto.Length;)
        {
            int inicio = texto.IndexOf("hormigonx", desde, StringComparison.Ordinal);
            if (inicio < 0) break;
            errores.Add(new(inicio, 9, "hormigonx")); desde = inicio + 9;
        }
        return errores;
    }

    private static ToolStripMenuItem Opcion(ContextMenuStrip menu, string texto) =>
        menu.Items.OfType<ToolStripMenuItem>().Single(x => x.Text == texto);

    private static void AbrirMenu(Control destino, Point punto)
    {
        // Invocar el evento del control conserva el camino de posicionamiento
        // real, y Show ejecuta Opening sin depender de mover el mouse del usuario.
        typeof(Control).GetMethod("OnMouseDown", BindingFlags.Instance | BindingFlags.NonPublic)
            .Invoke(destino, new object[] { new MouseEventArgs(MouseButtons.Right, 1, punto.X, punto.Y, 0) });
        destino.ContextMenuStrip.Show(destino, punto); Application.DoEvents();
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
