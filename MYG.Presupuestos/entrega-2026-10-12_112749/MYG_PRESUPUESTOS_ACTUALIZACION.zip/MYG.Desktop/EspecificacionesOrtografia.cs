using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed record MYGErrorOrtografico(int Inicio, int Longitud, string Palabra, string Reemplazo = null)
{
    internal int Fin => Inicio + Longitud;
}

// El corrector de Windows trabaja sobre una copia de Text. Las marcas se pintan
// en pantalla: nunca son formato RichEdit ni entran en el RTF o en Deshacer.
internal sealed class MYGEspecificacionesOrtografia : IDisposable
{
    private readonly RichTextBox documento;
    private readonly System.Windows.Forms.Timer espera = new() { Interval = 650 };
    private readonly Func<string, IReadOnlyList<MYGErrorOrtografico>> comprobarAlternativo;
    private readonly Func<string, IReadOnlyList<string>> sugerirAlternativo;
    private readonly Action<string> agregarAlternativo;
    private readonly HashSet<string> ignoradas = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<MYGErrorOrtografico> ignoradasUnaVez = new();
    private readonly List<MYGErrorOrtografico> pendientes = new();
    private IReadOnlyList<MYGErrorOrtografico> errores = Array.Empty<MYGErrorOrtografico>();
    private ISpellChecker corrector;
    private string textoActual, textoComprobando;
    private int siguiente;
    private bool comprobado, eliminado;

    internal bool Disponible => corrector != null || comprobarAlternativo != null;
    internal bool RevisionCompleta => comprobado;
    internal string Idioma { get; private set; }
    internal string Estado { get; private set; }
    internal IReadOnlyList<MYGErrorOrtografico> Errores => errores;
    internal event EventHandler ErroresCambiados;

    internal MYGEspecificacionesOrtografia(RichTextBox documento,
        Func<string, IReadOnlyList<MYGErrorOrtografico>> comprobar = null,
        Func<string, IReadOnlyList<string>> sugerir = null, Action<string> agregar = null)
    {
        this.documento = documento ?? throw new ArgumentNullException(nameof(documento));
        comprobarAlternativo = comprobar; sugerirAlternativo = sugerir; agregarAlternativo = agregar;
        textoActual = documento.Text;
        if (comprobar == null) CrearCorrector();
        else { Idioma = "es-PE"; Estado = "Ortografía: español (es-PE)."; }
        espera.Tick += ComprobarBloque;
        documento.TextChanged += TextoCambiado;
        documento.HandleCreated += HandleCreado;
        documento.HandleDestroyed += HandleDestruido;
        if (Disponible) espera.Start();
    }

    // Se llama al cargar otra partida; las exclusiones de una sola aparición no
    // pueden heredarse por coincidencia de sus posiciones en otro documento.
    internal void ReiniciarDocumento()
    {
        if (eliminado || documento.IsDisposed) return;
        ignoradasUnaVez.Clear(); ignoradas.Clear();
        errores = Array.Empty<MYGErrorOrtografico>(); textoActual = documento.Text;
        Programar(); Notificar();
    }

    internal void ComprobarAhora()
    {
        if (eliminado || documento.IsDisposed || !Disponible) return;
        if (comprobado && textoActual == documento.Text) return;
        espera.Stop();
        IniciarComprobacion();
        try
        {
            while (siguiente < textoComprobando.Length) LeerBloque();
            TerminarComprobacion();
        }
        catch (COMException) { FalloComprobacion(); }
    }

    internal MYGErrorOrtografico ObtenerError(int indice)
    {
        if (eliminado || documento.IsDisposed || indice < 0 || indice >= documento.TextLength) return null;
        // Los resultados están ordenados por posición, incluso cuando el
        // proveedor devuelve más de una clase de corrección para una palabra.
        int izquierda = 0, derecha = errores.Count - 1;
        while (izquierda <= derecha)
        {
            int centro = izquierda + (derecha - izquierda) / 2;
            var error = errores[centro];
            if (indice < error.Inicio) derecha = centro - 1;
            else if (indice >= error.Fin) izquierda = centro + 1;
            else return error;
        }
        return null;
    }

    internal static bool ContieneCaracter(RichTextBox documento, int indice, Point punto)
    {
        if (indice < 0 || indice >= documento.TextLength) return false;
        using var geometria = new GeometriaTexto(documento);
        return geometria.Contiene(indice, punto);
    }

    internal IReadOnlyList<string> Sugerencias(MYGErrorOrtografico error)
    {
        var sugerencias = new List<string>();
        if (!Vigente(error) || !Disponible) return sugerencias;
        if (!string.IsNullOrEmpty(error.Reemplazo)) sugerencias.Add(error.Reemplazo);
        if (comprobarAlternativo != null)
        {
            foreach (string sugerencia in sugerirAlternativo?.Invoke(error.Palabra) ?? Array.Empty<string>())
                if (!string.IsNullOrWhiteSpace(sugerencia) && !sugerencias.Contains(sugerencia) && sugerencias.Count < 8)
                    sugerencias.Add(sugerencia);
            return sugerencias;
        }
        IEnumString enumerador = null;
        try
        {
            corrector.Suggest(error.Palabra, out enumerador);
            string[] siguiente = new string[1];
            while (sugerencias.Count < 8 && enumerador.Next(1, siguiente, IntPtr.Zero) == 0)
                if (!string.IsNullOrWhiteSpace(siguiente[0]) && !sugerencias.Contains(siguiente[0]))
                    sugerencias.Add(siguiente[0]);
        }
        catch (COMException) { Estado = "Windows no pudo obtener sugerencias para esta palabra."; }
        finally { Liberar(enumerador); }
        return sugerencias;
    }

    internal void Ignorar(MYGErrorOrtografico error)
    {
        if (!Vigente(error)) return;
        ignoradasUnaVez.Add(error);
        QuitarMarcas(x => x.Inicio == error.Inicio && x.Longitud == error.Longitud);
    }

    internal void IgnorarTodo(MYGErrorOrtografico error)
    {
        if (!Vigente(error)) return;
        ignoradas.Add(error.Palabra);
        QuitarMarcas(x => string.Equals(x.Palabra, error.Palabra, StringComparison.OrdinalIgnoreCase));
    }

    internal void AgregarAlDiccionario(MYGErrorOrtografico error)
    {
        if (!Vigente(error) || !Disponible) return;
        // Add persiste en el diccionario personal de Windows del idioma activo.
        // Una excepción se deja al llamador para mostrarla, sin fingir el éxito.
        if (comprobarAlternativo != null) agregarAlternativo?.Invoke(error.Palabra);
        else corrector.Add(error.Palabra);
        ignoradas.Add(error.Palabra);
        QuitarMarcas(x => string.Equals(x.Palabra, error.Palabra, StringComparison.OrdinalIgnoreCase));
    }

    internal void Corregir(MYGErrorOrtografico error, string reemplazo)
    {
        if (!Vigente(error) || documento.ReadOnly || reemplazo == null) return;
        documento.Select(error.Inicio, error.Longitud);
        documento.SelectedText = reemplazo;
    }

    // Sólo MYGEspecificacionesVistaOscura invoca este callback tras WM_PAINT.
    // No se invoca para WM_PRINTCLIENT, impresión ni imágenes de exportación.
    internal void Pintar(Graphics grafico, Rectangle visible)
    {
        if (eliminado || documento.IsDisposed || errores.Count == 0 || documento.TextLength == 0 || visible.IsEmpty) return;
        int primeraLinea = documento.GetLineFromCharIndex(documento.GetCharIndexFromPosition(visible.Location));
        int ultimaLinea = documento.GetLineFromCharIndex(documento.GetCharIndexFromPosition(new Point(visible.Right - 1, visible.Bottom - 1))) + 1;
        int primero = Math.Max(0, documento.GetFirstCharIndexFromLine(primeraLinea));
        int ultimo = documento.GetFirstCharIndexFromLine(ultimaLinea + 1);
        if (ultimo < 0) ultimo = documento.TextLength;
        var estado = grafico.Save();
        try
        {
            grafico.SetClip(visible, System.Drawing.Drawing2D.CombineMode.Intersect);
            using var lapiz = new Pen(Color.FromArgb(220, 35, 45), Math.Max(1, documento.DeviceDpi / 96f));
            using var geometria = new GeometriaTexto(documento);
            foreach (var error in errores)
            {
                if (error.Fin <= primero) continue;
                if (error.Inicio >= ultimo) break;
                int desde = Math.Max(error.Inicio, primero), hasta = Math.Min(error.Fin, ultimo);
                while (desde < hasta)
                {
                    int linea = documento.GetLineFromCharIndex(desde);
                    int finLinea = documento.GetFirstCharIndexFromLine(linea + 1);
                    int fin = Math.Min(hasta, finLinea < 0 ? documento.TextLength : finLinea);
                    if (fin <= desde) break;
                    if (geometria.Obtener(desde, fin, out Point inicio, out Point final))
                    {
                        float x1 = Math.Max(visible.Left, Math.Min(inicio.X, final.X));
                        float x2 = Math.Min(visible.Right, Math.Max(inicio.X, final.X));
                        float y = inicio.Y + Math.Max(2, documento.DeviceDpi / 48f);
                        float paso = Math.Max(2, documento.DeviceDpi / 48f);
                        bool subir = true;
                        for (float x = x1; x < x2; x += paso)
                        {
                            float finX = Math.Min(x + paso, x2);
                            grafico.DrawLine(lapiz, x, y + (subir ? paso / 2 : 0), finX, y + (subir ? 0 : paso / 2));
                            subir = !subir;
                        }
                    }
                    desde = fin;
                }
            }
        }
        finally { grafico.Restore(estado); }
    }

    private bool Vigente(MYGErrorOrtografico error) => !eliminado && !documento.IsDisposed && error != null && error.Inicio >= 0 &&
        error.Longitud > 0 && error.Fin <= documento.TextLength &&
        string.CompareOrdinal(documento.Text, error.Inicio, error.Palabra, 0, error.Longitud) == 0;

    private void QuitarMarcas(Func<MYGErrorOrtografico, bool> quitar)
    {
        errores = errores.Where(x => !quitar(x)).ToArray();
        pendientes.RemoveAll(x => quitar(x));
        Notificar();
    }

    private void TextoCambiado(object sender, EventArgs e)
    {
        string nuevo = documento.Text;
        int prefijo = 0, sufijo = 0;
        while (prefijo < textoActual.Length && prefijo < nuevo.Length && textoActual[prefijo] == nuevo[prefijo]) prefijo++;
        while (sufijo < textoActual.Length - prefijo && sufijo < nuevo.Length - prefijo &&
            textoActual[textoActual.Length - 1 - sufijo] == nuevo[nuevo.Length - 1 - sufijo]) sufijo++;
        int finAnterior = textoActual.Length - sufijo, delta = nuevo.Length - textoActual.Length;
        // Ignorar una vez acompaña a su aparición al insertar texto antes de ella.
        for (int i = ignoradasUnaVez.Count - 1; i >= 0; i--)
        {
            var error = ignoradasUnaVez[i];
            if (error.Fin <= prefijo) continue;
            if (error.Inicio >= finAnterior) ignoradasUnaVez[i] = error with { Inicio = error.Inicio + delta };
            else ignoradasUnaVez.RemoveAt(i);
        }
        textoActual = nuevo;
        errores = Array.Empty<MYGErrorOrtografico>();
        Programar(); Notificar();
    }

    private void Programar()
    {
        comprobado = false; textoComprobando = null; pendientes.Clear(); siguiente = 0;
        espera.Stop(); espera.Interval = 650;
        if (Disponible && !eliminado) espera.Start();
    }

    private void IniciarComprobacion()
    {
        textoActual = textoComprobando = documento.Text;
        siguiente = 0; pendientes.Clear();
    }

    private void ComprobarBloque(object sender, EventArgs e)
    {
        if (eliminado || documento.IsDisposed || !documento.IsHandleCreated) { espera.Stop(); return; }
        try
        {
            if (textoComprobando == null) IniciarComprobacion();
            if (siguiente < textoComprobando.Length) LeerBloque();
            if (siguiente >= textoComprobando.Length) TerminarComprobacion();
            else espera.Interval = 25; // Ceder a entrada, desplazamiento y pintura entre bloques.
        }
        catch (COMException) { FalloComprobacion(); }
    }

    private void LeerBloque()
    {
        int inicio = siguiente, fin = Math.Min(inicio + 8192, textoComprobando.Length);
        // Cortar en espacio para que el proveedor nunca compruebe media palabra.
        while (fin < textoComprobando.Length && !char.IsWhiteSpace(textoComprobando[fin])) fin++;
        string bloque = textoComprobando.Substring(inicio, fin - inicio);
        if (comprobarAlternativo != null)
        {
            foreach (var local in comprobarAlternativo(bloque) ?? Array.Empty<MYGErrorOrtografico>())
            {
                if (local.Inicio < 0 || local.Longitud <= 0 || local.Fin > bloque.Length) continue;
                var error = local with { Inicio = inicio + local.Inicio };
                if (!ignoradas.Contains(error.Palabra) && !ignoradasUnaVez.Any(x => x.Inicio == error.Inicio && x.Longitud == error.Longitud && x.Palabra == error.Palabra))
                    pendientes.Add(error);
            }
            siguiente = fin; return;
        }
        IEnumSpellingError enumerador = null;
        try
        {
            corrector.Check(bloque, out enumerador);
            while (true)
            {
                int resultado = enumerador.Next(out var nativo);
                if (resultado < 0) Marshal.ThrowExceptionForHR(resultado);
                if (resultado != 0 || nativo == null) { Liberar(nativo); break; }
                try
                {
                    nativo.GetStartIndex(out uint posicion); nativo.GetLength(out uint longitud);
                    nativo.GetCorrectiveAction(out int accion);
                    if (accion == 0 || longitud == 0 || (ulong)posicion + longitud > (ulong)bloque.Length) continue;
                    string palabra = bloque.Substring((int)posicion, (int)longitud);
                    var error = new MYGErrorOrtografico(inicio + (int)posicion, (int)longitud, palabra);
                    if (ignoradas.Contains(palabra) || ignoradasUnaVez.Any(x => x.Inicio == error.Inicio && x.Longitud == error.Longitud && x.Palabra == palabra)) continue;
                    if (accion == 2) { nativo.GetReplacement(out string reemplazo); error = error with { Reemplazo = reemplazo }; }
                    else if (accion == 3) error = error with { Reemplazo = "" };
                    pendientes.Add(error);
                }
                finally { Liberar(nativo); }
            }
        }
        finally { Liberar(enumerador); }
        siguiente = fin;
    }

    private void TerminarComprobacion()
    {
        espera.Stop(); comprobado = true;
        errores = pendientes.OrderBy(x => x.Inicio).Distinct().ToArray();
        textoComprobando = null; pendientes.Clear();
        Estado = $"Ortografía: español ({Idioma}).";
        Notificar();
    }

    private void FalloComprobacion()
    {
        espera.Stop(); comprobado = false; textoComprobando = null; pendientes.Clear();
        Estado = "Windows no pudo completar la revisión ortográfica. Intenta comprobar de nuevo.";
        errores = Array.Empty<MYGErrorOrtografico>(); Notificar();
    }

    private void Notificar()
    {
        if (!documento.IsDisposed) documento.Invalidate();
        ErroresCambiados?.Invoke(this, EventArgs.Empty);
    }

    private void HandleCreado(object sender, EventArgs e) => Programar();
    private void HandleDestruido(object sender, EventArgs e) => espera.Stop();

    private void CrearCorrector()
    {
        Estado = "Para revisar la ortografía, instala el paquete de idioma español en Configuración de Windows > Hora e idioma > Idioma y región.";
        if (!OperatingSystem.IsWindows()) return;
        ISpellCheckerFactory fabrica = null;
        IEnumString idiomas = null;
        try
        {
            fabrica = (ISpellCheckerFactory)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("7AB36653-1796-484B-BDFA-E74F1DB7C1DC"), true));
            var candidatos = new List<string> { "es-PE", "es-ES", "es-MX", "es-US" };
            fabrica.GetSupportedLanguages(out idiomas);
            string[] nombre = new string[1];
            while (idiomas.Next(1, nombre, IntPtr.Zero) == 0)
                if (nombre[0].StartsWith("es", StringComparison.OrdinalIgnoreCase) && !candidatos.Contains(nombre[0])) candidatos.Add(nombre[0]);
            foreach (string candidato in candidatos)
            {
                fabrica.IsSupported(candidato, out int soportado);
                if (soportado == 0) continue;
                try { fabrica.CreateSpellChecker(candidato, out corrector); }
                catch (COMException) { Liberar(corrector); corrector = null; continue; }
                if (corrector != null) { Idioma = candidato; Estado = $"Ortografía: español ({Idioma})."; break; }
            }
        }
        catch (COMException) { Liberar(corrector); corrector = null; }
        finally { Liberar(idiomas); Liberar(fabrica); }
    }

    private static void Liberar(object objeto)
    {
        if (objeto != null && Marshal.IsComObject(objeto)) Marshal.ReleaseComObject(objeto);
    }

    public void Dispose()
    {
        if (eliminado) return;
        eliminado = true; espera.Stop(); espera.Dispose();
        documento.TextChanged -= TextoCambiado;
        documento.HandleCreated -= HandleCreado;
        documento.HandleDestroyed -= HandleDestruido;
        Liberar(corrector); corrector = null;
        errores = Array.Empty<MYGErrorOrtografico>(); pendientes.Clear(); ignoradasUnaVez.Clear(); ignoradas.Clear();
    }

    [ComImport, Guid("8E018A9D-2415-4677-BF08-794EA61F94BB"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface ISpellCheckerFactory
    {
        void GetSupportedLanguages(out IEnumString idiomas);
        void IsSupported([MarshalAs(UnmanagedType.LPWStr)] string idioma, out int soportado);
        void CreateSpellChecker([MarshalAs(UnmanagedType.LPWStr)] string idioma, out ISpellChecker corrector);
    }

    [ComImport, Guid("B6FD0B71-E2BC-4653-8D05-F197E412770B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface ISpellChecker
    {
        void GetLanguageTag([MarshalAs(UnmanagedType.LPWStr)] out string idioma);
        void Check([MarshalAs(UnmanagedType.LPWStr)] string texto, out IEnumSpellingError errores);
        void Suggest([MarshalAs(UnmanagedType.LPWStr)] string palabra, out IEnumString sugerencias);
        void Add([MarshalAs(UnmanagedType.LPWStr)] string palabra);
    }

    [ComImport, Guid("803E3BD4-2828-4410-8290-418D1D73C762"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IEnumSpellingError
    {
        [PreserveSig] int Next(out ISpellingError error);
    }

    [ComImport, Guid("B7C82D61-FBE8-4B47-9B27-6C0D2E0DE0A3"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface ISpellingError
    {
        void GetStartIndex(out uint inicio);
        void GetLength(out uint longitud);
        void GetCorrectiveAction(out int accion);
        void GetReplacement([MarshalAs(UnmanagedType.LPWStr)] out string reemplazo);
    }

    // TOM devuelve la línea de base y los límites de cada carácter con su fuente
    // y zoom reales, sin seleccionar texto ni consultar SelectionFont. Se usan
    // sus interfaces binarias estables; no se necesita Word o una biblioteca COM.
    private sealed class GeometriaTexto : IDisposable
    {
        private readonly RichTextBox documento;
        private IntPtr objeto;
        private CrearRango crear;
        [DllImport("user32.dll", EntryPoint = "SendMessageW")]
        private static extern IntPtr SendMessage(IntPtr hwnd, int mensaje, IntPtr wp, out IntPtr lp);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate int CrearRango(IntPtr documento, int inicio, int fin, out IntPtr rango);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate int LeerPunto(IntPtr rango, int flags, out int x, out int y);

        internal GeometriaTexto(RichTextBox documento)
        {
            this.documento = documento;
            IntPtr ole = IntPtr.Zero;
            try
            {
                SendMessage(documento.Handle, 0x043C, IntPtr.Zero, out ole); // EM_GETOLEINTERFACE.
                if (ole == IntPtr.Zero) return;
                var id = new Guid("8CC497C0-A1DF-11CE-8098-00AA0047BE5D");
                if (Marshal.QueryInterface(ole, ref id, out objeto) < 0) return;
                // IUnknown (3), IDispatch (4), 17 métodos anteriores a Range.
                crear = Metodo<CrearRango>(objeto, 24);
            }
            finally { if (ole != IntPtr.Zero) Marshal.Release(ole); }
        }

        internal bool Obtener(int inicio, int fin, out Point izquierda, out Point derecha)
        {
            izquierda = derecha = Point.Empty;
            if (objeto != IntPtr.Zero && crear != null &&
                Punto(inicio, false, out izquierda) && Punto(fin - 1, true, out derecha)) return true;
            // RichEdit antiguo sin TOM: conservar un subrayado visible basado
            // en las posiciones nativas, sin tocar formato ni selección.
            izquierda = documento.GetPositionFromCharIndex(inicio);
            derecha = documento.GetPositionFromCharIndex(fin);
            int alto = (int)Math.Ceiling(documento.Font.Height * documento.ZoomFactor);
            if (derecha.Y != izquierda.Y)
            {
                var ultimo = documento.GetPositionFromCharIndex(fin - 1);
                derecha = new Point(ultimo.X + Math.Max(2, alto / 2), izquierda.Y);
            }
            izquierda.Y += (int)(alto * .78); derecha.Y = izquierda.Y;
            return derecha.X != izquierda.X;
        }

        internal bool Contiene(int indice, Point punto)
        {
            if (objeto != IntPtr.Zero && crear != null &&
                Punto(indice, false, out Point superior, 0) && Punto(indice, true, out Point inferior, 8))
            {
                return punto.X >= Math.Min(superior.X, inferior.X) - 2 &&
                    punto.X <= Math.Max(superior.X, inferior.X) + 2 &&
                    punto.Y >= Math.Min(superior.Y, inferior.Y) - 2 &&
                    punto.Y <= Math.Max(superior.Y, inferior.Y) + 2;
            }
            // RichEdit antiguo: usar el alto de la línea si hay una siguiente.
            Point inicio = documento.GetPositionFromCharIndex(indice);
            Point fin = documento.GetPositionFromCharIndex(indice + 1);
            int siguiente = documento.GetFirstCharIndexFromLine(documento.GetLineFromCharIndex(indice) + 1);
            int alto = siguiente >= 0 ? documento.GetPositionFromCharIndex(siguiente).Y - inicio.Y
                : (int)Math.Ceiling(documento.Font.Height * documento.ZoomFactor);
            int derecha = fin.Y == inicio.Y ? fin.X : inicio.X + Math.Max(2, alto / 2);
            return punto.X >= inicio.X - 2 && punto.X <= derecha + 2 && punto.Y >= inicio.Y - 2 && punto.Y <= inicio.Y + alto + 2;
        }

        private bool Punto(int posicion, bool derecha, out Point punto, int alineacionVertical = 24)
        {
            punto = Point.Empty; IntPtr rango = IntPtr.Zero;
            try
            {
                if (crear(objeto, posicion, posicion + 1, out rango) != 0 || rango == IntPtr.Zero) return false;
                // IUnknown + IDispatch + 47 métodos anteriores a GetPoint.
                var leer = Metodo<LeerPunto>(rango, 54);
                // tomStart | tomClientCoord | tomAllowOffClient | TA_BASELINE | TA_RIGHT opcional.
                int flags = 32 | 256 | 512 | alineacionVertical | (derecha ? 2 : 0);
                if (leer(rango, flags, out int x, out int y) != 0) return false;
                punto = new Point(x, y); return true;
            }
            finally { if (rango != IntPtr.Zero) Marshal.Release(rango); }
        }

        private static T Metodo<T>(IntPtr instancia, int indice) where T : Delegate =>
            Marshal.GetDelegateForFunctionPointer<T>(Marshal.ReadIntPtr(Marshal.ReadIntPtr(instancia), indice * IntPtr.Size));

        public void Dispose()
        {
            if (objeto != IntPtr.Zero) { Marshal.Release(objeto); objeto = IntPtr.Zero; }
        }
    }
}
