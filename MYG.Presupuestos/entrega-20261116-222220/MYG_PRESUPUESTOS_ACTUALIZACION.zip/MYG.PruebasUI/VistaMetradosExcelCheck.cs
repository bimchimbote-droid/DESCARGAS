using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using System.Xml.Linq;
using MYG_2027;

internal static class VistaMetradosExcelCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarLibroVisibleYExportado(exige);
        VerificarCabeceraExterna(exige);
        VerificarColumnasEstrechas(exige);
        VerificarPapelBlancoEnTemas(exige);
        VerificarLibroGrande(exige);
        VerificarLimiteXls(exige);
    }

    private static void VerificarLibroVisibleYExportado(Action<bool, string> exige)
    {
        var reporte = CrearReporte();
        string original = JsonSerializer.Serialize(reporte.Hoja);
        using var formulario = new MYGVistaMetradosExcelForm("Proyecto de metrados", reporte)
        {
            WindowState = FormWindowState.Normal, ClientSize = new Size(1280, 800)
        };
        formulario.Show();
        Application.DoEvents();
        var controles = Controles(formulario).Where(c => c.Name.StartsWith("vista_metrados_excel", StringComparison.Ordinal)).ToDictionary(c => c.Name);
        var grilla = (DataGridView)controles["vista_metrados_excel_hoja"];
        var cinta = (TabControl)controles["vista_metrados_excel_cinta"];
        var direccion = (TextBox)controles["vista_metrados_excel_direccion"];
        var formula = (TextBox)controles["vista_metrados_excel_formula"];
        var pestanas = (TabControl)controles["vista_metrados_excel_pestanas"];
        var acciones = Controles(cinta).OfType<ToolStrip>().SelectMany(b => b.Items.Cast<ToolStripItem>())
            .Where(i => !string.IsNullOrEmpty(i.Name)).ToDictionary(i => i.Name);
        exige(grilla.ReadOnly && grilla.VirtualMode && grilla.SelectionMode == DataGridViewSelectionMode.CellSelect &&
            grilla.Columns[0].HeaderText == "A" && grilla.Columns[7].HeaderText == "H" && grilla.RowHeadersVisible &&
            grilla.Rows.Count >= reporte.Hoja.Filas && pestanas.TabPages.Count == 1 && pestanas.TabPages[0].Text == "Metrados",
            "La vista de metrados debe ofrecer una sola hoja tipo Excel, letras, números de fila y consulta sin edición.");
        exige(cinta.TabPages.Cast<TabPage>().Select(p => p.Text).SequenceEqual(new[] { "Archivo", "Inicio", "Vista" }) &&
            acciones.Values.All(i => i.Enabled && i.Image is { Width: >= 24, Height: >= 24 }) &&
            acciones.ContainsKey("vista_metrados_excel_guardar") && acciones.ContainsKey("vista_metrados_excel_imprimir") &&
            acciones.ContainsKey("vista_metrados_excel_copiar") && acciones.ContainsKey("vista_metrados_excel_volver"),
            "La cinta debe tener comandos utilizables de guardar, impresión, copia y regreso, con iconos y sin acciones de edición inactivas.");
        var barra = controles["vista_metrados_excel_barra_formula"];
        exige(cinta.Bottom <= barra.Top && barra.Bottom <= grilla.Top && grilla.Bottom <= pestanas.Top,
            "La cinta, fórmula, hoja y pestaña inferior deben permanecer visibles sin superposiciones.");
        exige(formulario.ReporteVisible.CabeceraEnHoja && formulario.HojaVisible.Filas == reporte.Hoja.Filas &&
            formulario.HojaVisible.RangosCombinados.SequenceEqual(reporte.Hoja.RangosCombinados) && !grilla.Rows[10].Visible,
            "La vista debe conservar cabecera única, combinaciones y filas ocultas del libro consolidado.");
        exige(Convert.ToString(grilla[21, 29].Value) == "" && Convert.ToString(grilla[8, 0].Value) == "" &&
            Convert.ToString(grilla[0, 12].Value) == "",
            "El margen de celdas fuera de los datos exportados debe verse vacío, sin errores de referencias.");

        formulario.SeleccionarRango("G9");
        Application.DoEvents();
        exige(direccion.Text == "G9" && formula.ReadOnly && formula.Text == "=B9*C9" &&
            Convert.ToString(grilla[6, 8].Value) == 6m.ToString("0.00", CultureInfo.CurrentCulture),
            "Seleccionar una fórmula debe mostrar su dirección, contenido original y resultado numérico en la cuadrícula.");
        formulario.SeleccionarRango("A9:C9");
        exige(direccion.Text == "A9:C9" && formulario.TextoSeleccion() == "Columna C-01\t" +
            2m.ToString("0.0000", CultureInfo.CurrentCulture) + "\t" + 3m.ToString("0.0000", CultureInfo.CurrentCulture),
            "La copia debe conservar las columnas seleccionadas y sus valores tal como aparecen en la vista.");
        formulario.SeleccionarRango("A10");
        exige(formulario.TextoSeleccion() == "\"Texto con\ttabulador\"",
            "La copia de textos con tabuladores debe proteger el contenido de una sola celda al pegar en Excel.");
        formulario.SeleccionarRango("C7");
        exige(formula.Text == "01.01.01 CONCRETO EN COLUMNAS",
            "La barra de fórmulas debe leer el ancla cuando se selecciona el interior de una celda combinada.");
        formulario.SeleccionarRango("G9");
        cinta.SelectedIndex = 2;
        acciones["vista_metrados_excel_formulas"].PerformClick();
        exige(Convert.ToString(grilla[6, 8].Value) == "=B9*C9",
            "Mostrar fórmulas debe permitir revisar las expresiones conservadas en el metrado consolidado.");
        acciones["vista_metrados_excel_formulas"].PerformClick();
        int anchoOriginal = grilla.Columns[0].Width;
        formulario.CambiarZoom(150);
        exige(formulario.HojaVisible.Zoom == 150 && reporte.Hoja.Zoom == 100 && grilla.Columns[0].Width > anchoOriginal,
            "Cambiar el zoom debe ampliar la copia visible sin modificar la hoja del proyecto.");
        acciones["vista_metrados_excel_zoom_100"].PerformClick();
        exige(grilla.Columns[0].Width == anchoOriginal && direccion.Text == "G9",
            "Restablecer el zoom debe conservar la celda activa y recuperar las dimensiones originales.");

        // Probar el dibujo después de aplicar el tema global detecta la pérdida
        // de rellenos de autor y las líneas internas de las celdas combinadas.
        MYG2027_TemaComercial.Aplicar(formulario);
        grilla.FirstDisplayedScrollingRowIndex = 0;
        grilla.FirstDisplayedScrollingColumnIndex = 0;
        Application.DoEvents();
        using (var imagen = new Bitmap(grilla.Width, grilla.Height))
        {
            grilla.DrawToBitmap(imagen, grilla.ClientRectangle);
            Rectangle celda = grilla.GetCellDisplayRectangle(0, 6, false);
            exige(imagen.GetPixel(celda.Right - 1, celda.Bottom - 3).ToArgb() == Color.FromArgb(231, 237, 242).ToArgb(),
                "El nombre combinado de la partida debe conservar su fondo sin divisiones verticales internas al dibujar la hoja.");
        }

        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-VistaMetradosExcel-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "Metrados.xlsx");
            formulario.GuardarEn(ruta);
            var nombres = MYGExcelPresupuestos.Hojas(ruta);
            var leida = MYGExcelPresupuestos.Importar(ruta, nombres.Single(), formulario.HojaVisible.CeldaTotal);
            exige(nombres.SequenceEqual(new[] { "Metrados" }) && formulario.ArchivoGuardado == ruta &&
                leida.Celdas["A1"].Contenido == "METRADOS" && leida.Celdas["B2"].Contenido == "PROYECTO DE PRUEBA" &&
                leida.Celdas["A5"].Contenido == "01 · PRESUPUESTO ESTRUCTURAS" &&
                leida.Celdas["A6"].Contenido == "01.01 · ESTRUCTURAS" &&
                leida.Celdas["A7"].Contenido == "01.01.01 CONCRETO EN COLUMNAS" &&
                leida.Celdas["G9"].Contenido == "=B9*C9" && leida.RangosCombinados.Contains("A7:H7"),
                "Guardar debe producir una sola hoja con la misma cabecera, presupuesto, títulos, partida y fórmulas que se revisaron en pantalla.");
            exige(leida.Celdas["A7"].ColorFondo == "E7EDF2" && leida.Celdas["G9"].FormatoNumero == "0.00" && formulario.Visible,
                "El libro debe conservar los formatos y la ventana debe seguir abierta después de guardarlo.");
        }
        finally { Directory.Delete(carpeta, true); }
        exige(JsonSerializer.Serialize(reporte.Hoja) == original,
            "Abrir, seleccionar, copiar, ampliar y exportar la vista de metrados no debe modificar la hoja original.");
    }

    private static void VerificarCabeceraExterna(Action<bool, string> exige)
    {
        var hoja = new MYGHojaMetrado { Nombre = "Detalle", Filas = 3, Columnas = 3, CeldaTotal = "C3", AreaImpresion = "A1:C3" };
        hoja.Poner("A1", "Descripción"); hoja.Poner("B1", "Cantidad"); hoja.Poner("A2", "Partida conservada"); hoja.Poner("C3", "2");
        hoja.Celdas["A2"].Fuente = "Calibri";
        hoja.Celdas["A2"].TamanoFuente = 11;
        var reporte = new MYGHojaReporteProyecto("METRADOS", hoja,
            new[] { new KeyValuePair<string, string>("PROYECTO", "CABECERA EXTERNA") });
        string original = JsonSerializer.Serialize(hoja);
        using var formulario = new MYGVistaMetradosExcelForm("Cabecera de informe", reporte);
        var grilla = Controles(formulario).OfType<DataGridView>().Single();
        exige(formulario.HojaVisible.Celdas.Values.Any(c => c.Contenido == "CABECERA EXTERNA") &&
            formulario.HojaVisible.Celdas.Values.Any(c => c.Contenido == "Partida conservada") &&
            formulario.HojaVisible.Celdas.Values.Count(c => c.Contenido == "METRADOS") == 1 &&
            formulario.ReporteVisible.CabeceraEnHoja && JsonSerializer.Serialize(hoja) == original,
            "La vista debe materializar los datos de arriba cuando el informe aún los tiene fuera de las celdas, sin duplicar cabeceras ni tocar el origen.");
        exige(formulario.HojaVisible.Celdas.Values.All(c => c.Fuente == "Arial Narrow") &&
            formulario.HojaVisible.Celdas.Values.Any(c => c.Contenido == "Partida conservada" && c.TamanoFuente == 11) &&
            hoja.Celdas["A2"].Fuente == "Calibri",
            "La vista y el libro guardado deben usar Arial Narrow también en hojas antiguas, conservando tamaños y fuente del proyecto original.");
        exige(grilla.Columns[0].Width == (int)Math.Round(288 * formulario.DeviceDpi / 96d) &&
            grilla.Columns[1].Width == (int)Math.Round(68 * formulario.DeviceDpi / 96d) &&
            grilla.Columns[7].Width == (int)Math.Round(110 * formulario.DeviceDpi / 96d),
            "Las columnas sin ancho explícito deben usar los mismos valores predeterminados que el libro exportado.");
    }

    private static void VerificarColumnasEstrechas(Action<bool, string> exige)
    {
        var hoja = new MYGHojaMetrado { Nombre = "Metrados", Filas = 3, Columnas = 50, CeldaTotal = "AX3", AreaImpresion = "A1:AX3" };
        for (int c = 1; c <= 50; c++) hoja.AnchosColumnas[c] = 8;
        hoja.RangosCombinados.Add("A1:AX1"); hoja.Poner("A1", "METRADOS");
        var reporte = new MYGHojaReporteProyecto("METRADOS", hoja, cabeceraEnHoja: true);
        using var formulario = new MYGVistaMetradosExcelForm("Anchos de las plantillas", reporte);
        var grilla = Controles(formulario).OfType<DataGridView>().Single();
        exige(grilla.Columns[0].Width == Math.Max(2, (int)Math.Round(8 * formulario.DeviceDpi / 96d)),
            "La vista debe conservar la rejilla estrecha del consolidado para no deformar los anchos de las plantillas de metrados.");
        formulario.CambiarZoom(25);
        exige(grilla.Columns[0].Width == Math.Max(2, (int)Math.Round(2 * formulario.DeviceDpi / 96d)),
            "El zoom reducido también debe respetar las proporciones de las columnas pequeñas.");
    }

    private static void VerificarPapelBlancoEnTemas(Action<bool, string> exige)
    {
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        var reporte = CrearReporte();
        string original = JsonSerializer.Serialize(reporte.Hoja);
        using var formulario = new MYGVistaMetradosExcelForm("Papel del consolidado", reporte)
        { WindowState = FormWindowState.Normal, ClientSize = new Size(1280, 800) };
        try
        {
            formulario.Show();
            var grilla = Controles(formulario).OfType<DataGridView>().Single();
            foreach (bool oscuro in new[] { false, true, false })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                MYG2027_TemaComercial.Aplicar(formulario);
                Application.DoEvents();
                exige(grilla.DefaultCellStyle.BackColor.ToArgb() == Color.White.ToArgb() && grilla.DefaultCellStyle.ForeColor.ToArgb() == Color.Black.ToArgb() &&
                    grilla.AlternatingRowsDefaultCellStyle.BackColor.ToArgb() == Color.White.ToArgb() &&
                    grilla.ColumnHeadersDefaultCellStyle.BackColor == MYG2027_TemaComercial.CabeceraTabla,
                    "El consolidado debe conservar las celdas blancas y sus cabeceras del tema al alternar la paleta.");
                using var imagen = new Bitmap(grilla.Width, grilla.Height);
                grilla.DrawToBitmap(imagen, grilla.ClientRectangle);
                var celda = grilla.GetCellDisplayRectangle(2, 3, false);
                exige(imagen.GetPixel(celda.Left + celda.Width / 2, celda.Top + celda.Height / 2).ToArgb() == Color.White.ToArgb() &&
                    formulario.HojaVisible.Celdas["A7"].ColorFondo == "E7EDF2" && JsonSerializer.Serialize(reporte.Hoja) == original,
                    "Dibujar el consolidado oscuro debe mostrar papel blanco sin sustituir rellenos de autor ni modificar el informe original.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static MYGHojaReporteProyecto CrearReporte()
    {
        var h = new MYGHojaMetrado
        {
            Nombre = "Metrados", Filas = 12, Columnas = 8, CeldaTotal = "G12", AreaImpresion = "A1:H12",
            FilasInmovilizadas = 0, LineasDivision = true, FilasOcultas = new() { 11 },
            AnchosColumnas = new() { [1] = 220, [2] = 72, [3] = 72, [4] = 72, [5] = 72, [6] = 72, [7] = 90, [8] = 90 }
        };
        h.Poner("A1", "METRADOS", true); h.Poner("A2", "PROYECTO:"); h.Poner("B2", "PROYECTO DE PRUEBA");
        h.Poner("A5", "01 · PRESUPUESTO ESTRUCTURAS", true); h.Poner("A6", "01.01 · ESTRUCTURAS", true);
        h.Poner("A7", "01.01.01 CONCRETO EN COLUMNAS", true);
        h.Poner("A8", "Descripción", true); h.Poner("B8", "Cantidad", true); h.Poner("C8", "Largo", true); h.Poner("G8", "Parcial", true);
        h.Poner("A9", "Columna C-01"); h.Poner("B9", "2"); h.Poner("C9", "3"); h.Poner("G9", "=B9*C9");
        h.Celdas["G9"].FormatoNumero = "0.00";
        h.Poner("A10", "Texto con\ttabulador"); h.Poner("A11", "FILA OCULTA"); h.Poner("A12", "TOTAL", true); h.Poner("G12", "=SUM(G9:G10)", true);
        h.Celdas["A7"].ColorFondo = "E7EDF2";
        h.Celdas["A1"].TamanoFuente = 14;
        h.Celdas["A1"].AlineacionHorizontal = "Centro"; h.Celdas["A1"].AlineacionPersonalizada = true;
        h.RangosCombinados.AddRange(new[] { "A1:H1", "B2:H2", "A5:H5", "A6:H6", "A7:H7" });
        h.AltosFilas[1] = 30;
        return new MYGHojaReporteProyecto("METRADOS", h,
            new[] { new KeyValuePair<string, string>("PROYECTO", "PROYECTO DE PRUEBA") }, cabeceraEnHoja: true);
    }

    private static void VerificarLibroGrande(Action<bool, string> exige)
    {
        var hoja = new MYGHojaMetrado
        {
            Nombre = "Metrados", Filas = 12001, Columnas = 20, CeldaTotal = "T12001",
            AreaImpresion = "A1:T12001", FilasInmovilizadas = 0
        };
        hoja.Poner("A1", "METRADOS DEL PROYECTO", true);
        hoja.RangosCombinados.AddRange(new[] { "A1:T1", "A2:A10000" });
        hoja.Poner("B12000", "60"); hoja.Poner("T12001", "=B12000");
        hoja.AltosFilas[1] = 30;
        hoja.AltosFilas[12001] = 31;
        string original = JsonSerializer.Serialize(hoja);
        var reporte = new MYGHojaReporteProyecto("METRADOS", hoja, cabeceraEnHoja: true);
        using var formulario = new MYGVistaMetradosExcelForm("Proyecto completo", reporte)
        { WindowState = FormWindowState.Normal, ClientSize = new Size(1280, 800) };
        formulario.Show(); Application.DoEvents();
        var grilla = Controles(formulario).OfType<DataGridView>().Single();
        exige(grilla.VirtualMode && grilla.RowCount == 12001 && grilla.Rows.SharedRow(5000).Index == -1 &&
            formulario.HojaVisible.Filas == 12001 && !ReferenceEquals(formulario.HojaVisible, hoja),
            "La vista debe admitir el consolidado mayor que los límites del editor conservando filas compartidas y una copia aislada.");
        // Construir la ventana ya aplica las dimensiones. El mismo recorrido
        // actualiza las alturas al cambiar el zoom o el DPI: debe incluir tanto
        // la fila cero como la última, sin materializar todas las intermedias.
        void VerificarAlturas(int zoom)
        {
            int Alto(int baseEnPixeles) => Math.Max(12,
                (int)Math.Round(baseEnPixeles * zoom / 100d * formulario.DeviceDpi / 96d));
            // Medir solo estas tres filas permite materializarlas; la fila
            // 5000 queda como centinela del resto de filas compartidas.
            exige(grilla.Rows[0].Height == Alto(30) &&
                grilla.Rows[6000].Height == Alto(20) &&
                grilla.Rows[12000].Height == Alto(31),
                $"La vista debe aplicar a {zoom} % las alturas de la primera, intermedia y última fila al abrir o cambiar sus dimensiones.");
            exige(grilla.Rows.SharedRow(5000).Index == -1 && reporte.Hoja.Zoom == 100 &&
                reporte.Hoja.AltosFilas[1] == 30 && reporte.Hoja.AltosFilas[12001] == 31,
                "Actualizar alturas debe conservar las filas virtuales compartidas y las dimensiones originales del reporte.");
        }
        VerificarAlturas(100);
        foreach (int zoom in new[] { 150, 25, 100 })
        {
            formulario.CambiarZoom(zoom);
            Application.DoEvents();
            VerificarAlturas(zoom);
        }
        // Desplazar y repintar una zona distante no debe materializar sus filas
        // ni volver a evaluar/formatear las mismas celdas en cada fotograma.
        grilla.FirstDisplayedScrollingRowIndex = 4000;
        Application.DoEvents();
        using (var imagen = new Bitmap(grilla.Width, grilla.Height))
        {
            grilla.DrawToBitmap(imagen, grilla.ClientRectangle);
            int calculos = formulario.CalculosValores;
            grilla.DrawToBitmap(imagen, grilla.ClientRectangle);
            exige(formulario.CalculosValores == calculos && formulario.ValoresEnCache is > 0 and <= 8192 &&
                formulario.EstilosEnCache is > 0 and <= 1024,
                "Repintar durante el scroll debe reutilizar los valores mostrados y estilos con cachés acotadas.");
        }
        exige(grilla.Rows.SharedRow(4005).Index == -1 && grilla.Rows.SharedRow(5000).Index == -1,
            "Dibujar y consultar la selección de celdas no debe descompartir las filas virtuales que recorrió el scroll.");
        formulario.SeleccionarRango("T12001");
        exige(formulario.TextoSeleccion() == 60m.ToString("0.0000", CultureInfo.CurrentCulture),
            "La última fórmula del consolidado grande debe poder revisarse sin recortar sus filas.");
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-VistaMetradosGrande-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "Proyecto completo.xlsx");
            formulario.GuardarEn(ruta);
            using var zip = ZipFile.OpenRead(ruta);
            using var entrada = zip.GetEntry("xl/worksheets/sheet1.xml").Open();
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            var xml = XDocument.Load(entrada);
            var ultima = xml.Descendants(s + "c").Single(c => (string)c.Attribute("r") == "T12001");
            exige(ultima.Element(s + "f")?.Value == "B12000" &&
                xml.Descendants(s + "mergeCell").Any(c => (string)c.Attribute("ref") == "A2:A10000") &&
                formulario.ArchivoGuardado == ruta && JsonSerializer.Serialize(hoja) == original,
                "Guardar desde la vista grande debe conservar la última fórmula, combinaciones y origen sin aplicar límites de edición.");
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static void VerificarLimiteXls(Action<bool, string> exige)
    {
        var hoja = new MYGHojaMetrado { Nombre = "Metrados", Filas = 65537, Columnas = 2, CeldaTotal = "B65537" };
        hoja.Poner("A1", "METRADOS"); hoja.Poner("B65537", "60");
        using var formulario = new MYGVistaMetradosExcelForm("Límite XLS",
            new MYGHojaReporteProyecto("METRADOS", hoja, cabeceraEnHoja: true));
        string ruta = Path.Combine(Path.GetTempPath(), "MYG-LimiteXls-" + Guid.NewGuid().ToString("N") + ".xls");
        bool rechazo = false;
        try { formulario.GuardarEn(ruta); }
        catch (InvalidOperationException error) { rechazo = error.Message.Contains("65 536", StringComparison.Ordinal); }
        exige(rechazo && !File.Exists(ruta) && formulario.ArchivoGuardado == null,
            "El XLS heredado debe rechazar más de 65.536 filas antes de intentar usar Excel o crear un archivo parcial.");
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        yield return padre;
        foreach (Control hijo in padre.Controls)
            foreach (var control in Controles(hijo)) yield return control;
    }
}
