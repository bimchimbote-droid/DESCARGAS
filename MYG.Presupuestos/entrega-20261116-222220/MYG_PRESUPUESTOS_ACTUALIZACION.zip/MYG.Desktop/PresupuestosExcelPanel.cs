using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Label avisoMetradoDelphin;
    private void PrepararHoja()
    {
        var p = paginaExcel = Pagina("Metrado Xls"); p.Name = "metrado_pagina";
        hoja.Name = "metrado_hoja";
        MYG2027_TemaComercial.ConservarColoresDocumento(hoja, papelBlanco: true);
        hoja.ReadOnly = false; hoja.SelectionMode = DataGridViewSelectionMode.CellSelect; hoja.MultiSelect = true;
        hoja.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
        hoja.RowHeadersVisible = true; hoja.RowHeadersWidth = 24; hoja.ColumnHeadersHeight = 20;
        hoja.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        hoja.RowTemplate.Height = 18; hoja.AlternatingRowsDefaultCellStyle = new();
        hoja.CellBeginEdit += (_, e) =>
        {
            if (cargando || !HayPartida || !EdicionMetradosExcelNubePermitida || EligiendoReferenciaPartidaHoja) { e.Cancel = true; return; }
            string dir = DireccionAnclaHoja(e.RowIndex, e.ColumnIndex);
            contenidoAntes = new MYGHojaCalculo(actual.Costos.Hoja).Contenido(dir);
            hoja.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = contenidoAntes;
        };
        hoja.CellValidating += (_, e) =>
        {
            if (cargando || !HayPartida || BloqueandoEdicionReferenciaPartidaHoja || !hoja.IsCurrentCellInEditMode) return;
            try { ValidarEntradaReferenciaPartidaHoja(DireccionAnclaHoja(e.RowIndex, e.ColumnIndex), MYGEdicionHoja.CompletarCierreFormula(Convert.ToString(e.FormattedValue) ?? "")); hoja.Rows[e.RowIndex].ErrorText = ""; }
            catch (Exception ex) { e.Cancel = true; hoja.Rows[e.RowIndex].ErrorText = ex.Message; }
        };
        hoja.CellParsing += (_, e) =>
        {
            if (cargando || !HayPartida || !EdicionMetradosExcelNubePermitida || BloqueandoEdicionReferenciaPartidaHoja) return;
            string texto = Convert.ToString(e.Value) ?? "", completo = MYGEdicionHoja.CompletarCierreFormula(texto);
            if (completo != texto) { e.Value = completo; e.ParsingApplied = true; }
        };
        hoja.CellEndEdit += (_, e) =>
        {
            if (cargando || !HayPartida || !EdicionMetradosExcelNubePermitida || BloqueandoEdicionReferenciaPartidaHoja) return;
            string dir = DireccionAnclaHoja(e.RowIndex, e.ColumnIndex), texto = Convert.ToString(hoja.Rows[e.RowIndex].Cells[e.ColumnIndex].Value) ?? "";
            if (texto != contenidoAntes) { ExigirPermisoMetradosExcel(); antes(); PonerCelda(dir, texto); Cambiado(); }
            RecalcularHoja();
            hoja.Invalidate();
        };
        hoja.CellPainting += PintarCeldaHoja;
        hoja.ColumnHeaderMouseClick += (_, e) =>
        {
            if (e.Button == MouseButtons.Left) Intentar(() => SeleccionarEncabezadoHoja(-1, e.ColumnIndex,
                (ModifierKeys & Keys.Control) != 0, (ModifierKeys & Keys.Shift) != 0));
        };
        hoja.RowHeaderMouseClick += (_, e) =>
        {
            if (e.Button == MouseButtons.Left) Intentar(() => SeleccionarEncabezadoHoja(e.RowIndex, -1,
                (ModifierKeys & Keys.Control) != 0, (ModifierKeys & Keys.Shift) != 0));
        };
        hoja.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || !HayPartida) return;
            string texto = new MYGHojaCalculo(actual.Costos.Hoja).Contenido(DireccionAnclaHoja(e.RowIndex, e.ColumnIndex));
            if (Uri.TryCreate(texto, UriKind.Absolute, out var url) && url.Scheme == "https")
            {
                if (MessageBox.Show(this, "Abrir el enlace en el navegador?\n" + url, "Hipervínculo", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url.AbsoluteUri) { UseShellExecute = true });
                return;
            }
            hoja.CurrentCell = hoja[e.ColumnIndex, e.RowIndex];
            hoja.BeginEdit(true);
        };
        var menuHoja = new ContextMenuStrip();
        foreach (var par in new[] { ("Cortar", "cortar"), ("Copiar", "copiar"), ("Pegar", "pegar"), ("Rellenar abajo", "rellenar_abajo"), ("Borrar contenido", "limpiar"), ("Insertar filas", "insertar_filas"), ("Eliminar filas", "eliminar_filas"), ("Insertar columnas", "insertar_columnas"), ("Eliminar columnas", "eliminar_columnas") })
            menuHoja.Items.Add(new ToolStripMenuItem(par.Item1, null, (_, _) => Intentar(() => EjecutarComandoHoja(par.Item2))) { Tag = par.Item2 });
        menuHoja.Opening += (_, _) => { foreach (ToolStripItem item in menuHoja.Items) item.Enabled = EdicionMetradosExcelNubePermitida || item.Tag as string == "copiar"; };
        hoja.ContextMenuStrip = menuHoja;
        Disposed += (_, _) => menuHoja.Dispose();
        hoja.Scroll += (_, _) => hoja.Invalidate();
        hoja.SelectionChanged += (_, _) => { if (!cargando) { ConfirmarFormulaHoja(); ActualizarFormula(); } };
        hoja.CurrentCellChanged += (_, _) => { if (!cargando) { ConfirmarFormulaHoja(); ActualizarFormula(); } };
        hoja.EditingControlShowing += (_, e) =>
        {
            var actualCelda = hoja.CurrentCell;
            if (actualCelda != null && ConfiguracionEdicionCombinadaHoja(actualCelda.RowIndex, actualCelda.ColumnIndex) is { } combinada)
                e.CellStyle = combinada.Estilo;
            else if (e.Control is MYGEditorTextoFormulaHoja editorFormula) editorFormula.AplicarTema();
            else { e.Control.BackColor = MYG2027_TemaComercial.Superficie; e.Control.ForeColor = MYG2027_TemaComercial.Texto; }
        };
        hoja.DpiChangedAfterParent += (_, _) => { if (HayPartida) { AplicarEncabezadosHoja(); hoja.Invalidate(); } };
        hoja.KeyDown += (_, e) =>
        {
            if (hoja.IsCurrentCellInEditMode) return;
            string comando = e.Control && e.KeyCode == Keys.V ? "pegar" : e.Control && e.KeyCode == Keys.C ? "copiar" : e.Control && e.KeyCode == Keys.X ? "cortar" : e.KeyCode == Keys.Delete ? "limpiar" : null;
            if (comando != null) { e.SuppressKeyPress = true; Intentar(() => EjecutarComandoHoja(comando)); }
        };
        p.Controls.Add(hoja);
        p.Controls.Add(PrepararPestanasHoja());
        p.Controls.Add(PrepararBarraFormulaHoja());
        p.Controls.Add(PrepararBarraReferenciasPartidasHoja());
        p.Controls.Add(PrepararCintaHoja());
        avisoMetradoDelphin = new Label
        {
            Name = "metrado_delphin_aviso", Dock = DockStyle.Top, AutoSize = false, Height = 52,
            Padding = new Padding(8), Visible = false, TextAlign = ContentAlignment.MiddleLeft
        };
        p.Controls.Add(avisoMetradoDelphin);
        cabeceraExcel = new MYGMetradoCabecera(() => P?.Nombre ?? "", () => PartidaActual is { } i ? CodigoEstructura(P, i) : "", () => PartidaActual?.Descripcion ?? "",
            () => HayPartida ? MYGPlantillasMetrado.Identificar(actual.Costos.Hoja) : "",
            id => Intentar(() => ElegirPlantillaMetrado(id)), () => HayPartida && !cargando && EdicionMetradosExcelNubePermitida,
            () => MYGActualizacionMetradoHoja.Evaluar(P, PartidaActual),
            () => Intentar(ActualizarMetradoPresupuesto));
        p.Controls.Add(cabeceraExcel);
        PrepararReferenciasHoja();
        PrepararAutocompletadoHoja();
        PrepararElegirReferenciasHoja();
        PrepararZoomRuedaHoja();
        PrepararCursoresHoja();
        Disposed += (_, _) => { foreach (var f in fuentesHoja.Values) f.Dispose(); };
    }
    private void PonerCelda(string dir, string texto)
    {
        ExigirPermisoMetradosExcel();
        if (texto.Length > 32767) throw new InvalidOperationException("La celda supera los 32.767 caracteres.");
        actual = PartidaActual;
        RequerirPartida();
        MYGReferenciasMetrado.Vincular(PresupuestosEstructura);
        var h = actual.Costos.Hoja; dir = MYGHojaCalculo.Normalizar(dir);
        var coordenadas = MYGHojaCalculo.Coordenadas(dir);
        dir = DireccionAnclaHoja(coordenadas.Fila - 1, coordenadas.Columna - 1);
        ValidarEntradaReferenciaPartidaHoja(dir, texto);
        if (BorradorReferenciasPartidasHoja(dir) is { } referenciasPendientes)
            MYGReferenciasMetrado.AplicarReferenciasPendientes(h, referenciasPendientes, texto);
        var c = MYGEdicionHoja.Celda(h, dir);
        c.Contenido = texto;
        DescartarReferenciasPartidasPendientesHoja();
    }
    private void ConfirmarCambioHoja(MYGHojaMetrado nueva)
    {
        ExigirPermisoMetradosExcel();
        actual = PartidaActual;
        RequerirPartida();
        actual.Costos.Hoja = nueva;
        MYGReferenciasMetrado.Vincular(PresupuestosEstructura);
        MYGReferenciasMetrado.SincronizarOrigen(nueva);
    }
    private void CargarHoja()
    {
        MYGReferenciasMetrado.Vincular(PresupuestosEstructura);
        TerminarEleccionReferenciasHoja();
        CancelarArrastreHoja();
        CerrarAutocompletadoHoja();
        LimpiarReferenciasHoja();
        bool previo = cargando; cargando = true;
        try
        {
            bool mismaPartida = Equals(hoja.Tag, actual?.Id);
            var posicion = !mismaPartida || hoja.CurrentCell == null ? (Fila: 3, Columna: 0)
                : (Fila: hoja.CurrentCell.RowIndex, Columna: hoja.CurrentCell.ColumnIndex);
            var seleccion = mismaPartida ? hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex)).ToArray()
                : Array.Empty<(int RowIndex, int ColumnIndex)>();
            int scroll = mismaPartida ? hoja.FirstDisplayedScrollingRowIndex : -1;
            if (!mismaPartida) filtroTextoHoja = "";
            hoja.Tag = actual?.Id;
            hoja.Rows.Clear(); hoja.Columns.Clear();
            avisoMetradoDelphin.Text = HayPartida ? actual.Costos.MetradoDelphin?.Advertencia ?? "" : "";
            avisoMetradoDelphin.Visible = avisoMetradoDelphin.Text.Length > 0;
            if (!HayPartida) return;
            if (actual.Costos.MetradoDelphin?.Compatible == false)
            {
                // No mostrar una plantilla inicial como si fuera el archivo
                // nativo que no se pudo interpretar.
                celdaTotal.Text = formula.Text = direccion.Text = "";
                hoja.ReadOnly = formula.ReadOnly = celdaTotal.ReadOnly = true;
                cabeceraExcel?.Actualizar();
                return;
            }
            var h = actual.Costos.Hoja;
            MYGHojaCalculo.Validar(EdicionMetradosExcelNubePermitida ? h : MYGProyectoStorage.Copia(h));
            celdaTotal.Text = h.CeldaTotal;
            // Las reparaciones de hojas heredadas son cambios persistentes.
            // Consultar un módulo bloqueado debe conservar el documento exacto.
            // El libro Delphin conserva sus combinaciones y estilos nativos.
            // Consultarlo no debe aplicar reparaciones de plantillas MYG.
            if (EdicionMetradosExcelNubePermitida && actual.Costos.MetradoDelphin == null)
            {
                MYGEdicionHoja.RepararCabeceraMetrado(h);
                MYGEdicionHoja.RepararRellenoCabeceraMetrado(h);
                MYGEdicionHoja.RepararFormatoTotalMetrado(h);
            }
            anclaEncabezadoColumnaHoja = anclaEncabezadoFilaHoja = -1;
            for (int c = 1; c <= h.Columnas; c++)
            {
                string letra = MYGHojaCalculo.Columna(c);
                hoja.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = letra, HeaderText = letra, Width = AnchoColumnaHoja(h, c), ReadOnly = false,
                    SortMode = DataGridViewColumnSortMode.NotSortable,
                    CellTemplate = new MYGCeldaMetradoCombinada { ConfigurarEdicion = ConfiguracionEdicionCombinadaHoja }
                });
            }
            hoja.Rows.Add(h.Filas);
            foreach (DataGridViewRow r in hoja.Rows) r.HeaderCell.Value = (r.Index + 1).ToString();
            RecalcularHoja();
            AplicarVistaHoja();
            var fila = hoja.Rows[Math.Min(posicion.Fila, h.Filas - 1)];
            if (!fila.Visible) fila = hoja.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Visible && r.Index >= 2)
                ?? hoja.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Visible);
            hoja.ClearSelection();
            if (fila != null)
            {
                hoja.CurrentCell = fila.Cells[Math.Min(posicion.Columna, h.Columnas - 1)];
                foreach (var celda in seleccion)
                    if (celda.RowIndex < h.Filas && celda.ColumnIndex < h.Columnas && hoja.Rows[celda.RowIndex].Visible)
                        hoja[celda.ColumnIndex, celda.RowIndex].Selected = true;
                hoja.CurrentCell.Selected = true;
            }
            if (scroll >= h.FilasInmovilizadas && scroll < h.Filas && hoja.Rows[scroll].Visible) hoja.FirstDisplayedScrollingRowIndex = scroll;
        }
        finally { cargando = previo; }
        ActualizarSeleccionCursorHoja();
        ActualizarFormula();
        cabeceraExcel?.Actualizar();
    }
    private void RecalcularHoja()
    {
        if (!HayPartida) return; bool previo = cargando; cargando = true;
        try
        {
            var h = actual.Costos.Hoja; var motor = new MYGHojaCalculo(h);
            bool aceros = MYGPlantillasMetrado.Identificar(h) == MYGPlantillasMetrado.Aceros;
            foreach (DataGridViewRow r in hoja.Rows)
                foreach (DataGridViewCell c in r.Cells)
                {
                    string dir = MYGHojaCalculo.Columna(c.ColumnIndex + 1) + (r.Index + 1);
                    c.Value = mostrarFormulasHoja ? motor.Contenido(dir) : motor.Mostrar(dir); c.ToolTipText = motor.Contenido(dir);
                    if (h.Celdas.TryGetValue(dir, out var entrada) && entrada.TipoValidacion == "Lista")
                        c.ToolTipText += "\nValores permitidos: " + string.Join(", ", entrada.ListaValores);
                    if (aceros && h.Celdas.TryGetValue(MYGHojaCalculo.Columna(c.ColumnIndex + 1) + "2", out var titulo) &&
                        titulo.Contenido == "% Desperdicio")
                        c.ToolTipText += "\nDesperdicio en porcentaje: escriba 5 para añadir 5 %.";
                    AplicarFormatoCeldaHoja(c, h.Celdas.GetValueOrDefault(dir));
                    AplicarTemaCeldaHoja(c, dir, h.CeldaTotal);
                }
        }
        finally { cargando = previo; }
        ActualizarSeleccionCursorHoja();
        ActualizarFormula();
        cabeceraExcel?.Actualizar();
    }
    private void AplicarTemaHoja()
    {
        hoja.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
        hoja.DefaultCellStyle.BackColor = Color.White;
        hoja.DefaultCellStyle.ForeColor = Color.Black;
        hoja.AlternatingRowsDefaultCellStyle.BackColor = Color.White;
        if (HayPartida)
        {
            hoja.CellBorderStyle = actual.Costos.Hoja.LineasDivision ? DataGridViewCellBorderStyle.Single : DataGridViewCellBorderStyle.None;
            hoja.GridColor = ColorRejillaHoja;
            AplicarEncabezadosHoja();
        }
        string total = HayPartida ? actual.Costos.Hoja.CeldaTotal : null;
        foreach (DataGridViewRow fila in hoja.Rows)
            foreach (DataGridViewCell celda in fila.Cells)
                AplicarTemaCeldaHoja(celda, MYGHojaCalculo.Columna(celda.ColumnIndex + 1) + (fila.Index + 1), total);
    }
    private void AplicarTemaCeldaHoja(DataGridViewCell celda, string direccionCelda, string celdaTotal)
    {
        // La hoja conserva el papel blanco incluso con la interfaz oscura.
        // Los colores explícitos del documento se aplican después, sin tocar
        // la hoja nativa ni convertir el tema en formato persistente.
        celda.Style.BackColor = Color.White;
        celda.Style.ForeColor = Color.Black;
        if (HayPartida) AplicarColoresCeldaHoja(celda, actual.Costos.Hoja.Celdas.GetValueOrDefault(direccionCelda));
    }
    private void ActualizarFormula()
    {
        if (cargando || restaurandoReferenciaPartidaHoja || !HayPartida || hoja.CurrentCell == null) return;
        string dir = DireccionAnclaHoja(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex);
        direccionFormulaHoja = dir;
        actualizandoFormulaHoja = true;
        try
        {
            direccion.Text = hoja.SelectedCells.Count == 1 ? dir : MYGHojaCalculo.ReferenciaSeleccion(hoja.SelectedCells.Cast<DataGridViewCell>()
                .Select(c => DireccionCelda(c.RowIndex, c.ColumnIndex)), dir);
            formula.Text = new MYGHojaCalculo(actual.Costos.Hoja).Contenido(dir); formulaPendienteHoja = false;
        }
        finally { actualizandoFormulaHoja = false; }
        var estiloCinta = MYGEdicionHoja.CopiarCelda(actual.Costos.Hoja.Celdas.GetValueOrDefault(dir)
            ?? new MYGCeldaHoja { FormatoNumero = actual.Costos.Hoja.FormatoNumeroPredeterminado });
        estiloCinta.AlineacionHorizontal = MYGEdicionHoja.AlineacionCelda(actual.Costos.Hoja.Celdas.GetValueOrDefault(dir), dir);
        SincronizarCintaHoja(actual.Costos.Hoja, estiloCinta);
    }
    private void AplicarFormula()
    {
        ExigirPermisoMetradosExcel();
        if (EligiendoReferenciaPartidaHoja) throw new InvalidOperationException("Seleccione la celda de origen o cancele la selección antes de confirmar.");
        TerminarEleccionReferenciasHoja();
        RequerirPartida(); if (hoja.CurrentCell == null) return;
        string dir = direccionFormulaHoja ?? DireccionAnclaHoja(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex);
        string texto = MYGEdicionHoja.CompletarCierreFormula(formula.Text);
        ValidarEntradaReferenciaPartidaHoja(dir, texto);
        if (new MYGHojaCalculo(actual.Costos.Hoja).Contenido(dir) != texto) { ExigirPermisoMetradosExcel(); antes(); PonerCelda(dir, texto); Cambiado(); }
        else DescartarReferenciasPartidasPendientesHoja();
        formulaPendienteHoja = false;
        LimpiarReferenciasHoja(); RecalcularHoja();
        refrescoDiferidoEstructura?.Reintentar();
    }
    private void CopiarHoja()
    {
        RequerirPartida(); if (hoja.SelectedCells.Count == 0) return;
        var celdas = hoja.SelectedCells.Cast<DataGridViewCell>().ToArray(); int f1 = celdas.Min(x => x.RowIndex), f2 = celdas.Max(x => x.RowIndex), c1 = celdas.Min(x => x.ColumnIndex), c2 = celdas.Max(x => x.ColumnIndex);
        var motor = new MYGHojaCalculo(actual.Costos.Hoja);
        if (celdas.Length == 1)
        {
            string contenido = motor.Contenido(DireccionAnclaHoja(f1, c1));
            if (contenido.Length == 0) Clipboard.Clear(); else Clipboard.SetText(contenido);
            return;
        }
        Clipboard.SetText(string.Join("\r\n", Enumerable.Range(f1, f2 - f1 + 1).Select(f => string.Join("\t", Enumerable.Range(c1, c2 - c1 + 1).Select(c => motor.Contenido(MYGHojaCalculo.Columna(c + 1) + (f + 1)))))));
    }
    private void PegarHoja()
    {
        ExigirPermisoMetradosExcel();
        RequerirPartida(); if (hoja.CurrentCell == null || !Clipboard.ContainsText()) return;
        string[] filas = Clipboard.GetText().Replace("\r\n", "\n").Replace('\r', '\n').TrimEnd('\n').Split('\n');
        var datos = filas.Select(x => x.Split('\t')).ToArray(); int f0 = hoja.CurrentCell.RowIndex, c0 = hoja.CurrentCell.ColumnIndex;
        if (datos.Length == 1 && datos[0].Length == 1)
        {
            var ancla = MYGHojaCalculo.Coordenadas(DireccionAnclaHoja(f0, c0));
            f0 = ancla.Fila - 1; c0 = ancla.Columna - 1;
        }
        var h = actual.Costos.Hoja;
        if (f0 + datos.Length > h.Filas || c0 + datos.Max(x => x.Length) > h.Columnas) throw new InvalidOperationException("El contenido pegado excede la hoja; añada filas o seleccione otra celda.");
        if (datos.Any(x => x.Any(c => c.Length > 32767))) throw new InvalidOperationException("Una celda pegada es demasiado larga.");
        var copia = MYGProyectoStorage.Copia(h);
        for (int f = 0; f < datos.Length; f++) for (int c = 0; c < datos[f].Length; c++)
        {
            string dir = DireccionCelda(f0 + f, c0 + c);
            if (EsInteriorCombinado(dir)) throw new InvalidOperationException("No se puede pegar en el interior de una combinación. Separe las celdas primero.");
            MYGEdicionHoja.Celda(copia, dir).Contenido = datos[f][c];
        }
        for (int f = 0; f < datos.Length; f++) for (int c = 0; c < datos[f].Length; c++) MYGEdicionHoja.ValidarEntrada(copia, DireccionCelda(f0 + f, c0 + c), datos[f][c]);
        MYGHojaCalculo.Validar(copia);
        ExigirPermisoMetradosExcel(); antes(); ConfirmarCambioHoja(copia); RecalcularHoja(); Cambiado();
    }
    private void RellenarHoja()
    {
        ExigirPermisoMetradosExcel();
        RequerirPartida(); var seleccion = hoja.SelectedCells.Cast<DataGridViewCell>().ToList(); if (seleccion.Count == 0) return;
        int primera = seleccion.Min(x => x.RowIndex); var motor = new MYGHojaCalculo(actual.Costos.Hoja);
        var copia = MYGProyectoStorage.Copia(actual.Costos.Hoja);
        foreach (var c in seleccion.Where(x => x.RowIndex > primera))
        {
            string dir = DireccionCelda(c.RowIndex, c.ColumnIndex);
            if (EsInteriorCombinado(dir)) throw new InvalidOperationException("No se puede rellenar el interior de una combinación.");
            var origen = actual.Costos.Hoja.Celdas.GetValueOrDefault(DireccionCelda(primera, c.ColumnIndex));
            var celda = MYGEdicionHoja.CopiarCelda(origen);
            celda.Contenido = MYGEdicionHoja.TrasladarFormula(motor.Contenido(DireccionCelda(primera, c.ColumnIndex)), c.RowIndex - primera, 0);
            copia.Celdas[dir] = celda;
        }
        MYGHojaCalculo.Validar(copia);
        foreach (var c in seleccion.Where(x => x.RowIndex > primera))
        { string dir = DireccionCelda(c.RowIndex, c.ColumnIndex); MYGEdicionHoja.ValidarEntrada(copia, dir, copia.Celdas[dir].Contenido); }
        ExigirPermisoMetradosExcel(); antes(); ConfirmarCambioHoja(copia); RecalcularHoja(); Cambiado();
    }
    private void FormatoHoja(bool bold)
    {
        ExigirPermisoMetradosExcel();
        RequerirPartida(); ExigirPermisoMetradosExcel(); antes(); foreach (DataGridViewCell c in hoja.SelectedCells)
        {
            string dir = MYGHojaCalculo.Columna(c.ColumnIndex + 1) + (c.RowIndex + 1); var h = actual.Costos.Hoja;
            if (!h.Celdas.TryGetValue(dir, out var estilo)) h.Celdas[dir] = estilo = new();
            if (bold) estilo.Negrita = !estilo.Negrita; else estilo.Cursiva = !estilo.Cursiva;
        }
        RecalcularHoja(); despues();
    }
    private void ImportarHoja()
    {
        ExigirPermisoMetradosExcel();
        RequerirPartida(); FinalizarEdicion(); using var d = new OpenFileDialog { Filter = "Libro Excel (*.xlsx)|*.xlsx" };
        if (d.ShowDialog(this) != DialogResult.OK) return; var nombres = MYGExcelPresupuestos.Hojas(d.FileName);
        using var f = new MYGElegirCostoForm("Hoja que contiene el metrado", nombres.Cast<object>().ToArray()); if (f.ShowDialog(this) != DialogResult.OK) return;
        using var total = new MYGCamposProyectoForm("Total del metrado en Excel", new[] { "Dirección de la celda total" }, new[] { celdaTotal.Text });
        if (total.ShowDialog(this) != DialogResult.OK) return;
        var nueva = MYGExcelPresupuestos.Importar(d.FileName, (string)f.Elegido, total.Valores[0]);
        var n = new MYGHojaCalculo(nueva).Numero(nueva.CeldaTotal); if (n < 0) throw new InvalidOperationException("El metrado de la hoja es negativo.");
        ExigirPermisoMetradosExcel(); antes(); ConfirmarCambioHoja(nueva); CargarHoja(); Cambiado();
    }
    private void ExportarHoja()
    {
        RequerirPartida(); FinalizarEdicion();
        var reporte = MYGReportesProyecto.CrearMetrado(ProyectoParaExportacionExcel(), P.Id, actual.Id);
        using var vista = new MYGVistaMetradosExcelForm(P.Nombre, reporte);
        vista.ShowDialog(this);
    }
    internal void ExportarPresupuesto()
    {
        if (P == null) return;
        FinalizarEdicion();
        var hojas = CrearLibroPresupuestoParaExportar();
        using var dialogo = new SaveFileDialog { Filter = "Libro de presupuesto (*.xlsx)|*.xlsx",
            DefaultExt = "xlsx", AddExtension = true, FileName = "Presupuesto.xlsx" };
        if (dialogo.ShowDialog(this) == DialogResult.OK) MYGExcelPresupuestos.Guardar(dialogo.FileName, hojas);
    }
    internal void ExportarMetradosCompletos()
    {
        FinalizarEdicion();
        var proyecto = ProyectoParaExportacionExcel();
        EditorForm.AbrirVistaMetradosParaExportar(FindForm(), "Metrados del proyecto", proyecto,
            todosPresupuestos: true);
    }
    internal void Resumen()
    {
        if (P == null) return; FinalizarEdicion(); using var f = new MYGResumenCostosForm(P);
        if (f.ShowDialog(this) == DialogResult.OK) { antes(); P.Costos.Moneda = f.Moneda; P.Costos.GastosGeneralesPorcentaje = f.Gastos; P.Costos.UtilidadPorcentaje = f.Utilidad; P.Costos.ImpuestoPorcentaje = f.Impuesto; P.Costos.OtrosImpuestosPorcentaje = f.Otros; Cambiado(); }
    }
    internal void ImprimirPresupuesto()
    {
        if (P == null) return; FinalizarEdicion(); MYGMotorPresupuestos.Validar(P); var resumen = MYGMotorPresupuestos.Resumen(P);
        string texto = string.Join("\n", MYGOrdenPresupuestos.FilasOrdenadas(P).Select(i => i.Item + "  " + i.Descripcion +
            (MYGProyectoStorage.EsTitulo(i) ? "" : "\n    " + MYGFormatoPresupuesto.Cantidad(MYGMotorPresupuestos.Cantidad(P, i)) + " " + i.Unidad + " × " + MYGFormatoPresupuesto.Dinero(MYGMotorPresupuestos.Analizar(P, i).PrecioUnitario)) +
            "   " + P.Costos.Moneda + " " + MYGFormatoPresupuesto.Dinero(MYGMotorPresupuestos.TotalPartida(P, i)))) +
            "\n\n" + string.Join("\n", MYGPiePresupuesto.Filas(new[] { P }).Select(f => f.Nombre + ": " + MYGFormatoPresupuesto.Dinero(f.Importe))) +
            (P.Costos.PiePersonalizado?.Count > 0 ? "\nTOTAL: " + P.Costos.Moneda + " " + MYGFormatoPresupuesto.Dinero(resumen.Total) : "");
        ImprimirTexto(P.Nombre, texto);
    }
    private void ImprimirTexto(string titulo, string contenido)
    {
        using var documento = new PrintDocument { DocumentName = titulo }; using var fuenteTexto = new Font("Arial", 10);
        string restante = titulo + "\n\n" + contenido;
        documento.PrintPage += (s, e) =>
        {
            e.Graphics.MeasureString(restante, fuenteTexto, e.MarginBounds.Size, StringFormat.GenericTypographic, out int caracteres, out _);
            if (caracteres <= 0) throw new InvalidOperationException("El área de impresión es demasiado pequeña.");
            e.Graphics.DrawString(restante[..caracteres], fuenteTexto, Brushes.Black, e.MarginBounds, StringFormat.GenericTypographic);
            restante = restante[caracteres..]; e.HasMorePages = restante.Length > 0;
        };
        using var d = new PrintDialog { Document = documento, UseEXDialog = true };
        if (d.ShowDialog(this) == DialogResult.OK) documento.Print();
    }
}

internal sealed class MYGResumenCostosForm : Form
{
    internal string Moneda { get; private set; }
    internal decimal Gastos { get; private set; }
    internal decimal Utilidad { get; private set; }
    internal decimal Impuesto { get; private set; }
    internal decimal Otros { get; private set; }
    internal MYGResumenCostosForm(MYGPresupuestoDocumento p)
    {
        Text = "MYG | Resumen de costos"; StartPosition = FormStartPosition.CenterParent; ClientSize = new(620, 480); Font = new("Segoe UI", 10);
        var tabla = new TableLayoutPanel { Dock = DockStyle.Top, Height = 200, ColumnCount = 2, RowCount = 5, Padding = new(12) };
        tabla.ColumnStyles.Add(new(SizeType.Percent, 60)); tabla.ColumnStyles.Add(new(SizeType.Percent, 40));
        var moneda = new TextBox { Text = p.Costos.Moneda, Dock = DockStyle.Fill };
        NumericUpDown Porcentaje(decimal v) => new() { Value = Math.Min(v, 10000), Maximum = 10000, DecimalPlaces = 4, Dock = DockStyle.Fill };
        var gastos = Porcentaje(p.Costos.GastosGeneralesPorcentaje); var utilidad = Porcentaje(p.Costos.UtilidadPorcentaje); var impuesto = Porcentaje(p.Costos.ImpuestoPorcentaje);
        var otros = Porcentaje(p.Costos.OtrosImpuestosPorcentaje);
        bool predeterminado = p.Costos.PiePersonalizado == null;
        gastos.Enabled = utilidad.Enabled = impuesto.Enabled = otros.Enabled = predeterminado;
        string[] nombres = { "Moneda", "Gastos generales (% costo directo)", "Utilidad (% costo directo)", "I.G.V. (% subtotal)", "Otros impuestos (% subtotal)" }; Control[] controles = { moneda, gastos, utilidad, impuesto, otros };
        for (int n = 0; n < 5; n++) { tabla.RowStyles.Add(new(SizeType.Percent, 20)); tabla.Controls.Add(new Label { Text = nombres[n], AutoSize = true }, 0, n); tabla.Controls.Add(controles[n], 1, n); }
        var importes = new Label { Dock = DockStyle.Fill, Padding = new(18), Font = new("Segoe UI", 11) };
        void Calcular()
        {
            var copia = MYGProyectoStorage.Copia(p); copia.Costos.GastosGeneralesPorcentaje = gastos.Value; copia.Costos.UtilidadPorcentaje = utilidad.Value; copia.Costos.ImpuestoPorcentaje = impuesto.Value; copia.Costos.OtrosImpuestosPorcentaje = otros.Value;
            // El resumen y sus filas pertenecen a la misma actualización.
            // Otra edición crea una sesión nueva para no reutilizar importes anteriores.
            var calculo = MYGMotorPresupuestos.CrearCalculo(copia);
            var r = calculo.Resumen();
            importes.Text = string.Join("\n", MYGPiePresupuesto.Filas(new[] { calculo }).Select(f => f.Nombre + ": " + MYGFormatoPresupuesto.Dinero(f.Importe))) +
                "\n\nTOTAL: " + moneda.Text + " " + MYGFormatoPresupuesto.Dinero(r.Total) +
                (predeterminado ? "" : "\nEdite los conceptos desde el menú del panel Resumen.");
        }
        gastos.ValueChanged += (s, e) => Calcular(); utilidad.ValueChanged += (s, e) => Calcular(); impuesto.ValueChanged += (s, e) => Calcular(); otros.ValueChanged += (s, e) => Calcular(); moneda.TextChanged += (s, e) => Calcular();
        var aceptar = new Button { Text = "Aplicar", Dock = DockStyle.Bottom, Height = 36 };
        aceptar.Click += (s, e) => { if (string.IsNullOrWhiteSpace(moneda.Text)) return; Moneda = moneda.Text.Trim(); Gastos = predeterminado ? gastos.Value : p.Costos.GastosGeneralesPorcentaje; Utilidad = predeterminado ? utilidad.Value : p.Costos.UtilidadPorcentaje; Impuesto = predeterminado ? impuesto.Value : p.Costos.ImpuestoPorcentaje; Otros = predeterminado ? otros.Value : p.Costos.OtrosImpuestosPorcentaje; DialogResult = DialogResult.OK; };
        Controls.Add(importes); Controls.Add(tabla); Controls.Add(aceptar); Calcular();
    }
}
