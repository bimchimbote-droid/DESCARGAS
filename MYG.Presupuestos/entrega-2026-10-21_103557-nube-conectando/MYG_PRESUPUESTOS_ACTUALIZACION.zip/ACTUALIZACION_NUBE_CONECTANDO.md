# Nube MYG: ventana temporal de conexión — 21/10/2026

Al pulsar **Nube MYG**, aparece la misma ventana animada utilizada al cargar
proyectos, con el mensaje **Conectando…**. El explorador de Nube MYG permanece
oculto hasta finalizar el ingreso con su cuenta MYG y la consulta de proyectos.
Entonces se cierra la animación y se muestra el explorador conectado.

La animación refleja la operación real, sin porcentajes ni esperas simuladas.
Una cuenta sin proyectos también puede conectar correctamente y abrir la lista
vacía. Si falla la conexión o el listado, se cierra la carga y se muestra el
error sobre Inicio; puede volver a pulsar Nube MYG para reintentar.

Se mantienen los accesos desde Inicio y Colaboración en los proyectos. Se
controlan las aperturas simultáneas y se comprueba de nuevo la cuenta antes
de mostrar la ventana. Se elimina la conexión desde Shown para no repetirla.
No cambian los permisos, la conexión automática ni la configuración interna.

## Archivos de la entrega

Las rutas parten de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.

| N.º | Ruta exacta | Acción | Qué hacer |
|---|---|---|---|
| 1 | `MYG.Desktop/InicioNube.cs` | REEMPLAZAR | Copiar el archivo completo. Espera la conexión y el listado dentro de la animación y abre el explorador al finalizar. |
| 2 | `MYG.Desktop/NubeForm.cs` | REEMPLAZAR | Copiar el archivo completo. Permite preparar la ventana oculta y propaga los errores de apertura. |
| 3 | `ACTUALIZACION_NUBE_CONECTANDO.md` | CREAR | Copiar junto a la solución; contiene instrucciones y resultados. No se ejecuta. |

El ZIP es una actualización incremental de la entrega anterior sin formulario
de conexión. Incluye sólo estos tres archivos; conserva las correcciones
anteriores. No hay archivos que eliminar, SQL ni cambios en Supabase real.

## Instalación

1. Cierre MYG y respalde o confirme sus modificaciones locales.
2. Descargue y extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip`.
3. Copie su contenido en `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`,
   combinando las carpetas. Reemplace los dos archivos C# y copie este documento.
4. Abra `MYG.Presupuestos.sln` en Visual Studio, restaure NuGet y compile en
   **Release**. Ejecute la compilación nueva, no un ejecutable anterior.
5. Para distribuirlo a otros usuarios, genere un instalador nuevo con su
   procedimiento habitual (`scripts/Generar-Instalador.ps1`), usando el número
   correspondiente a su siguiente versión.

No necesita escribir otra vez los datos de conexión. Conserve `config.json`
y `nube-myg.json`. No ejecute migraciones ni modifique obras o vinculaciones
para aplicar este cambio. No se añaden dependencias.

## Compilación y validación

Base de código: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`5eff104c9b208c40857bdbecf42298605e9e1d93`; preparación local en `work`,
conservando las entregas previas y sus cambios pendientes. C#, .NET SDK
10.0.100, WinForms/WPF y SQLite. Proyecto funcional afectado: MYG.Desktop.

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build
```

Resultados ejecutados en Linux:

- Solución completa: **0 errores y 0 advertencias**.
- Suite de nube: **27 grupos principales y 787 comprobaciones de contrato
  HTTP**, además de sus comprobaciones de integración indicadas en la salida.
  Incluye ingreso único MYG (169), permisos por módulo (191), configuración
  distribuida (65), sincronización (145), archivos (61), paquetes (25) y
  confirmación JSONB (29). Todas aprobadas, con HTTP simulado y sin red.
- `git diff --check`: aprobado. Revisión de flujo: sin segunda conexión al
  mostrar la ventana y con errores propagados hasta Inicio.

Estas pruebas comprueban los contratos existentes; no ejecutan la animación
ni sustituyen la comprobación visual. Los proyectos de interfaz y Revit se
compilaron, pero no se ejecutaron en Linux. Tampoco se generó un instalador.

## Comprobación manual en Windows

1. Inicie sesión en MYG y pulse Nube MYG: debe aparecer **Conectando…** en
   la ventana temporal; el explorador debe aparecer después, conectado.
2. Compruebe la lista de proyectos y abra una obra. Vuelva a Colaboración y
   compruebe la misma secuencia al reabrir el explorador.
3. Cierre el explorador y ábralo otra vez. Compruebe que un doble clic no
   crea ventanas de carga ni exploradores duplicados.
4. Con una cuenta de prueba sin obras, compruebe que conecta y muestra la
   lista vacía sin tratarla como error.
5. Sin Internet, compruebe que desaparece la carga y aparece el aviso de
   error. Restablezca Internet y vuelva a abrir Nube MYG.
6. Si la sesión deja de estar autorizada durante la carga, no debe aparecer
   el explorador con proyectos de otra cuenta.

## GitHub y continuidad

En Visual Studio, abra Cambios de Git, revise los archivos y su rama `main`,
haga Commit y Push y compruebe la publicación en GitHub. Esta entrega sólo
publica el ZIP en una ruta nueva de `bimchimbote-droid/DESCARGAS`; no hace
Push del código ni sobrescribe otras entregas.

Compare sus personalizaciones antes de reemplazar archivos completos.
Un ejecutable o instalador anterior conserva su comportamiento anterior.

Implementación, compilación, suite sin red y revisión completadas. La revisión
visual de Windows queda pendiente en el equipo del usuario. Registros de esta
sesión: `/workspace/.cloud-setup/nube-carga-build.log` y
`/workspace/.cloud-setup/nube-carga-tests.log`. La preparación y la verificación
de descarga se guardan en `loading-delivery.json` y
`loading-delivery-publication.json` en esa misma carpeta.
