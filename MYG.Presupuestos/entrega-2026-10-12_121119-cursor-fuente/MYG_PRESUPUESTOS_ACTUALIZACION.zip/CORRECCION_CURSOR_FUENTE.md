# Cursor estable y fuente predeterminada de especificaciones

Aplicar sobre las entregas anteriores, incluida la corrección de textos del menú
publicada en `bimchimbote-droid/DESCARGAS`, commit
`bf0637d4a20a832dadece308bf4faec85859e3fd`.
La base del repositorio de código es `main`, commit
`081ee6172c9274aa37608bf1bbac2980e206fc70`.

## Comportamiento corregido

- El clic derecho abre el menú y conserva la posición del cursor y la selección.
  Cortar, pegar y los comandos de formato actúan sobre esa posición o selección.
  Elegir una sugerencia ortográfica corrige la palabra sobre la que se hizo clic.
- Apps y Mayús+F10 abren el menú junto al cursor existente.
- Las especificaciones nuevas y el texto sin formato usan **Arial Narrow, 11 puntos**,
  también en los párrafos vacíos y después de insertar el título. El tamaño real de
  RichEdit se establece en 220 twips para evitar el redondeo a 11,5 puntos al escalar.
- Se conserva el formato explícito del texto RTF. Los párrafos vacíos heredados con
  Arial regular de 11 a 11,5 puntos se adaptan al nuevo valor predeterminado al cargar.
  El formato elegido después por el usuario sigue siendo editable mediante la cinta.

## Instalación manual

| Ruta exacta | Acción | Función |
|---|---|---|
| MYG.Desktop/EspecificacionesContexto.cs | REEMPLAZAR | Conserva cursor y selección al preparar el menú. |
| MYG.Desktop/EspecificacionesContextoNativo.cs | CREAR | Intercepta clic derecho y apertura por teclado. |
| MYG.Desktop/EspecificacionesEditor.cs | REEMPLAZAR | Fuente inicial y párrafos vacíos. |
| MYG.Desktop/EspecificacionesFormato.cs | REEMPLAZAR | Fuente nativa exacta y párrafo final. |
| MYG.Desktop/EspecificacionesRichTextBox.cs | CREAR | Conserva los puntos de fuente al escalar DPI. |
| MYG.Desktop/PresupuestosPanel.cs | REEMPLAZAR | Utiliza el control actualizado. |
| MYG.Desktop/EspecificacionesExportacionForm.cs | REEMPLAZAR | Utiliza el control actualizado en exportación. |
| MYG.Desktop/EspecificacionesOrtografia.cs | REEMPLAZAR | Corrige la advertencia de interoperabilidad .NET 10. |
| MYG.PruebasUI/EspecificacionesContextoCheck.cs | REEMPLAZAR | Regresiones de cursor, fuente y DPI. |
| CORRECCION_CURSOR_FUENTE.md | CREAR | Instrucciones de esta entrega. |

1. Respalde o confirme sus modificaciones locales en Visual Studio.
2. Cierre MYG, extraiga el ZIP y copie sus archivos sobre la raíz del checkout,
   conservando las rutas relativas. Los archivos existentes se entregan completos:
   compare antes de reemplazar si tiene cambios locales posteriores.
3. Restaure y compile con .NET 10:

   ```powershell
   dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
   dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
   dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
   ```

   La ejecución del último comando requiere Windows y el runtime Windows Desktop.
4. Revise **Cambios de Git**, haga Commit y Push a su rama elegida y verifique el
   resultado en GitHub. Publicar este ZIP en DESCARGAS no publica cambios del código.

## Comprobación manual en Windows

1. Sitúe el cursor debajo de DESCRIPCIÓN. Haga clic derecho en otra línea y en el
   espacio blanco; cierre el menú y escriba. El texto debe aparecer en el punto inicial.
2. Seleccione un fragmento y haga clic derecho lejos de él. Cortar/copiar deben usar
   la selección original. Pruebe pegar donde estaba el cursor.
3. Haga clic derecho en una palabra con error mientras el cursor está en otra línea.
   Acepte una sugerencia: debe corregirse únicamente la palabra señalada.
4. Cree una especificación vacía y compruebe Arial Narrow 11 en la cinta; inserte el
   título y haga clic debajo de DESCRIPCIÓN. Escriba y compruebe el tamaño.
5. Alterne el tema, amplíe la hoja y pruebe diferentes escalas de pantalla de Windows.
   La fuente predeterminada debe seguir indicando 11 puntos.

Arial Narrow debe estar instalada en Windows. Cuando no está disponible, se utiliza
Arial 11 como alternativa; el editor muestra la fuente realmente utilizada.

## Validación y requisitos

Esta entrega utiliza C#/.NET 10.0.100. La compilación incluye los proyectos Desktop,
Core, pruebas y el conector Revit mediante sus paquetes de referencia documentados.
El ejecutor Linux mantiene 206 comprobaciones aprobadas; Named Pipes de Windows
se omite explícitamente.

Las regresiones de interfaz envían mensajes nativos de clic derecho y comprueban
cursor, selección, formato, desplazamiento, historial y acciones del menú. También
comprueban los valores iniciales de fuente, líneas vacías y conservación de RTF.
Las pruebas UI se compilan en Linux; su ejecución y verificación visual requieren
Windows. Revit no se ejecuta en esta validación.

No se añaden paquetes NuGet ni migraciones de bases de datos. El ZIP es incremental
y requiere los demás archivos de las entregas anteriores.
