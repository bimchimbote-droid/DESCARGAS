using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinPrimerGuardadoCheck
{
    private static object Sql(string ruta, string sql, params object[] valores)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = sql;
        for (int n = 0; n < valores.Length; n++) cmd.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        return cmd.ExecuteScalar();
    }

    private static string Firma(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Metrado primer guardado puro.sqlite");
        var d = MYGProyectoStorage.Nuevo("PRIMER GUARDADO SINTÉTICO");
        d.Id = "PRFIRSTMET";
        var p = d.Presupuestos.Single(); p.Id = "PPFIRSTMET"; d.PresupuestoActivoId = p.Id;
        p.Items.Add(new ItemPresupuestoDelphin
        {
            Id = "CUFIRSTMET", IdInternoDelphin = "CUFIRSTMET", IdLocalMYG = "DELPHIN-LOCAL-CUFIRSTMET",
            Origen = "DELPHIN", Estado = "OFICIAL", TipoPropuesta = "PARTIDA", Unidad = "m",
            Descripcion = "FRENTE SINTÉTICO", Item = "01", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 60, PrecioDirecto = 0.2m }
        });
        MYGProyectoStorage.Guardar(ruta, d);
        var hoja = MYGHojaMetrado.Crear();
        hoja.Poner("A3", "Frente original"); hoja.Poner("B3", "1"); hoja.Poner("C3", "60");
        string libro = Path.Combine(carpeta, "metrado-primer-guardado.xlsx");
        MYGExcelPresupuestos.Guardar(libro, new[] { hoja });
        Sql(ruta, "UPDATE costo_unitario SET archivo_metrado=$p0,campo_metrado='G16' WHERE id_costounitario='CUFIRSTMET'; DROP TABLE myg_info;", File.ReadAllBytes(libro));
        var pendiente = MYGBaseDatos.LeerProyecto(ruta, d.Id);
        pendiente.Presupuestos.Single().Items.Single().Costos.Hoja.Celdas["A3"].Contenido = "Edición local pendiente";
        hoja.Celdas["A3"].Contenido = "Edición nativa concurrente";
        MYGExcelPresupuestos.Guardar(libro, new[] { hoja });
        Sql(ruta, "UPDATE costo_unitario SET archivo_metrado=$p0 WHERE id_costounitario='CUFIRSTMET'", File.ReadAllBytes(libro));
        string anterior = Firma(ruta); bool rechazado = false;
        try { MYGProyectoStorage.Guardar(ruta, pendiente); }
        catch (InvalidOperationException) { rechazado = true; }
        long extensiones = Convert.ToInt64(Sql(ruta, "SELECT count(*) FROM sqlite_master WHERE type='table' AND name='myg_info'"));
        if (!rechazado || anterior != Firma(ruta) || extensiones != 0)
            throw new Exception("El primer guardado conflictivo creó extensiones MYG o cambió la base Delphin antes de rechazar la revisión obsoleta.");
        pasa("Un conflicto del primer guardado se rechaza en solo lectura sin crear extensiones ni modificar la base Delphin pura");
    }
}
