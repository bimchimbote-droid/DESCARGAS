using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace MYG_2027;

// Intercambio del libro OOXML que Delphin conserva en archivo_metrado.
// No atribuye ese formato a cualquier BLOB ni convierte un XLS binario a XLSX.
internal static class DelphinLibroMetrado
{
    private const int Limite = 64 * 1024 * 1024;
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static readonly XNamespace R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static readonly XNamespace Rel = "http://schemas.openxmlformats.org/package/2006/relationships";
    private static readonly Regex Celda = new(@"^\$?[A-Za-z]{1,3}\$?[1-9][0-9]{0,6}$", RegexOptions.CultureInvariant);
    private static readonly Regex Suma = new(@"^\s*(?:SUM|SUMA|SUBTOTAL)\s*\(", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private sealed record Hoja(string Nombre, string Parte, int Indice);
    private sealed record Total(Hoja Hoja, string Direccion);

    internal static MYGHojaMetrado Leer(byte[] contenido, string campoTotal)
    {
        using var flujo = new MemoryStream(contenido ?? Array.Empty<byte>(), false);
        using var libro = Abrir(flujo);
        var documento = Xml(libro, "xl/workbook.xml");
        var hojas = Hojas(libro, documento);
        var total = ResolverTotal(libro, documento, hojas, campoTotal);
        return Importar(contenido, total.Hoja.Nombre, total.Direccion);
    }

    internal static byte[] Guardar(byte[] original, MYGHojaMetrado hoja)
    {
        ArgumentNullException.ThrowIfNull(hoja);
        MYGHojaCalculo.Validar(hoja);
        if (original == null || original.Length == 0)
            return Temporal(ruta => { MYGExcelPresupuestos.Guardar(ruta, new[] { hoja }); return File.ReadAllBytes(ruta); });

        using var fuente = new MemoryStream(original, false);
        using var libro = Abrir(fuente);
        var documento = Xml(libro, "xl/workbook.xml");
        var hojas = Hojas(libro, documento);
        var seleccionadas = hojas.Where(h => h.Nombre == hoja.Nombre).ToArray();
        if (seleccionadas.Length != 1)
            throw new InvalidDataException("No se puede cambiar el nombre o sustituir la hoja del libro de metrado Delphin.");
        var seleccionada = seleccionadas[0];
        var inicial = Importar(original, seleccionada.Nombre, hoja.CeldaTotal);
        ComprobarEdicion(inicial, hoja);
        var comparacion = MYGProyectoStorage.Copia(hoja); comparacion.Zoom = inicial.Zoom;
        if (Igual(inicial, comparacion)) return original.ToArray();
        if (libro.Entries.Any(e => e.FullName.StartsWith("_xmlsignatures/", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("El libro de metrado tiene una firma digital. No se puede modificar conservando esa firma.");

        // Se preservan las partes no editadas y todos los atributos, objetos,
        // relaciones, nombres y extensiones del documento original. El escritor
        // general se usa únicamente para crear un libro que antes no existía.
        var cambios = new Dictionary<string, XDocument>(StringComparer.Ordinal);
        var xmlHoja = Xml(libro, seleccionada.Parte);
        var datos = xmlHoja.Root?.Element(S + "sheetData")
            ?? throw new InvalidDataException("El libro de metrado no contiene datos de hoja OOXML.");
        var celdas = datos.Descendants(S + "c").ToDictionary(c => MYGHojaCalculo.Normalizar((string)c.Attribute("r")), StringComparer.OrdinalIgnoreCase);
        bool cambioFormula = false;
        foreach (var entrada in hoja.Celdas)
        {
            string direccion = MYGHojaCalculo.Normalizar(entrada.Key);
            string contenido = entrada.Value.Contenido ?? "";
            string anterior = inicial.Celdas.TryGetValue(direccion, out var antes) ? antes.Contenido ?? "" : "";
            if (contenido == anterior) continue;
            cambioFormula |= contenido.StartsWith('=') || anterior.StartsWith('=');
            if (!celdas.TryGetValue(direccion, out var celda))
            {
                var coordenadas = MYGHojaCalculo.Coordenadas(direccion);
                var fila = datos.Elements(S + "row").FirstOrDefault(f => (int?)f.Attribute("r") == coordenadas.Fila);
                if (fila == null)
                {
                    fila = new XElement(S + "row", new XAttribute("r", coordenadas.Fila));
                    InsertarOrdenado(datos, fila, coordenadas.Fila, x => (int?)x.Attribute("r") ?? 0);
                }
                celda = new XElement(S + "c", new XAttribute("r", direccion));
                InsertarOrdenado(fila, celda, coordenadas.Columna,
                    x => MYGHojaCalculo.Coordenadas((string)x.Attribute("r")).Columna);
                celdas.Add(direccion, celda);
            }
            EscribirContenido(celda, contenido);
        }
        if (cambioFormula && libro.GetEntry("xl/calcChain.xml") != null)
            throw new InvalidDataException("Este libro tiene una cadena de cálculo que no se puede actualizar fielmente. Conserve el original y edite sus fórmulas en Delphin o Excel.");

        var calculo = new MYGHojaCalculo(hoja);
        foreach (var celda in datos.Descendants(S + "c").Where(c => c.Element(S + "f") != null))
            ActualizarCache(celda, calculo, MYGHojaCalculo.Normalizar((string)celda.Attribute("r")));
        cambios.Add(seleccionada.Parte, xmlHoja);

        // Otras hojas pueden depender de la editada: se conservan sus fórmulas
        // y formato, pero nunca se entrega un resultado en caché ya obsoleto.
        foreach (var otra in hojas.Where(h => h.Parte != seleccionada.Parte))
        {
            var xml = Xml(libro, otra.Parte);
            var formulas = xml.Descendants(S + "c").Where(c => c.Element(S + "f") != null).ToArray();
            if (formulas.Length == 0) continue;
            foreach (var c in formulas) { c.Elements(S + "v").Remove(); c.Attribute("t")?.Remove(); }
            cambios.Add(otra.Parte, xml);
        }
        var configuracion = documento.Root?.Element(S + "calcPr");
        if (configuracion == null) { configuracion = new XElement(S + "calcPr"); documento.Root!.Add(configuracion); }
        configuracion.SetAttributeValue("calcMode", "auto");
        configuracion.SetAttributeValue("fullCalcOnLoad", "1");
        configuracion.SetAttributeValue("forceFullCalc", "1");
        cambios.Add("xl/workbook.xml", documento);

        using var salida = new MemoryStream();
        using (var destino = new ZipArchive(salida, ZipArchiveMode.Create, true))
            foreach (var parte in libro.Entries)
            {
                var nueva = destino.CreateEntry(parte.FullName, CompressionLevel.Optimal);
                nueva.LastWriteTime = parte.LastWriteTime;
                nueva.ExternalAttributes = parte.ExternalAttributes;
                using var escribir = nueva.Open();
                if (cambios.TryGetValue(parte.FullName, out var reemplazo)) reemplazo.Save(escribir, SaveOptions.DisableFormatting);
                else { using var leer = parte.Open(); leer.CopyTo(escribir); }
            }
        return salida.ToArray();
    }

    private static ZipArchive Abrir(MemoryStream flujo)
    {
        if (flujo.Length < 4 || flujo.Length > Limite || flujo.GetBufferSeguro(0) != (byte)'P' || flujo.GetBufferSeguro(1) != (byte)'K')
            throw new InvalidDataException("El archivo de metrado Delphin no es un libro XLSX/OOXML admitido. Se conserva su contenido original.");
        ZipArchive libro;
        try { libro = new ZipArchive(flujo, ZipArchiveMode.Read, true); }
        catch (InvalidDataException ex) { throw new InvalidDataException("El libro de metrado Delphin tiene un ZIP no válido.", ex); }
        try
        {
            if (libro.Entries.Count > 4096 || libro.Entries.Sum(e => e.Length) > Limite ||
                libro.Entries.GroupBy(e => e.FullName, StringComparer.Ordinal).Any(g => g.Count() != 1) ||
                libro.GetEntry("xl/workbook.xml") == null || libro.GetEntry("[Content_Types].xml") == null)
                throw new InvalidDataException("El archivo de metrado no es un libro OOXML válido o excede sus límites de lectura.");
            XNamespace tipos = "http://schemas.openxmlformats.org/package/2006/content-types";
            var tiposLibro = Xml(libro, "[Content_Types].xml");
            var especificos = tiposLibro.Descendants(tipos + "Override").Where(t => (string)t.Attribute("PartName") == "/xl/workbook.xml").ToArray();
            var aplicables = especificos.Length != 0 ? especificos : tiposLibro.Descendants(tipos + "Default").Where(t =>
                string.Equals((string)t.Attribute("Extension"), "xml", StringComparison.OrdinalIgnoreCase)).ToArray();
            if (aplicables.Length != 1 || (string)aplicables[0].Attribute("ContentType") !=
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")
                throw new InvalidDataException("Solo se admite el libro XLSX estándar; no se transforma un libro binario, una plantilla o un libro con macros.");
            return libro;
        }
        catch { libro.Dispose(); throw; }
    }

    private static byte GetBufferSeguro(this MemoryStream flujo, int posicion)
    {
        long anterior = flujo.Position; flujo.Position = posicion; int valor = flujo.ReadByte(); flujo.Position = anterior; return (byte)valor;
    }

    private static XDocument Xml(ZipArchive libro, string parte)
    {
        var entrada = libro.GetEntry(parte) ?? throw new InvalidDataException("Falta la parte del libro de metrado: " + parte);
        if (entrada.Length > 32 * 1024 * 1024) throw new InvalidDataException("Parte del libro de metrado demasiado grande.");
        using var flujo = entrada.Open();
        using var lector = XmlReader.Create(flujo, new XmlReaderSettings
        { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 32 * 1024 * 1024 });
        try { return XDocument.Load(lector, LoadOptions.PreserveWhitespace); }
        catch (XmlException ex) { throw new InvalidDataException("La parte XML del libro de metrado no es válida: " + parte, ex); }
    }

    private static Hoja[] Hojas(ZipArchive libro, XDocument documento)
    {
        var relaciones = Xml(libro, "xl/_rels/workbook.xml.rels");
        var resultado = documento.Descendants(S + "sheet").Select((h, indice) =>
        {
            string id = (string)h.Attribute(R + "id");
            var coincidencias = relaciones.Descendants(Rel + "Relationship").Where(r => (string)r.Attribute("Id") == id).ToArray();
            if (string.IsNullOrEmpty(id) || coincidencias.Length != 1 || (string)coincidencias[0].Attribute("TargetMode") == "External")
                throw new InvalidDataException("La hoja del metrado contiene una relación no admitida.");
            var relacion = coincidencias[0];
            string parte = (string)relacion.Attribute("Target") ?? "";
            parte = parte.StartsWith('/') ? parte.TrimStart('/') : "xl/" + parte;
            if (!parte.StartsWith("xl/", StringComparison.Ordinal) || parte.Contains("..") || parte.Contains('\\'))
                throw new InvalidDataException("La ruta de la hoja de metrado no es válida.");
            return new Hoja((string)h.Attribute("name") ?? "", parte, indice);
        }).ToArray();
        if (resultado.Length == 0 || resultado.Any(h => string.IsNullOrWhiteSpace(h.Nombre)) ||
            resultado.GroupBy(h => h.Nombre, StringComparer.OrdinalIgnoreCase).Any(g => g.Count() != 1) ||
            resultado.GroupBy(h => h.Parte, StringComparer.Ordinal).Any(g => g.Count() != 1))
            throw new InvalidDataException("El libro de metrado contiene identidades de hoja ausentes o duplicadas.");
        return resultado;
    }

    private static Total ResolverTotal(ZipArchive libro, XDocument documento, Hoja[] hojas, string campo)
    {
        campo = (campo ?? "").Trim();
        if (campo.StartsWith('=')) campo = campo[1..].Trim();
        if (campo.Length != 0)
        {
            if (IntentarReferencia(campo, hojas, null, out var referencia)) return referencia;
            var nombres = documento.Descendants(S + "definedName").Where(n =>
                string.Equals((string)n.Attribute("name"), campo, StringComparison.OrdinalIgnoreCase)).ToArray();
            return TotalDefinido(nombres, hojas) ?? throw new InvalidDataException(
                "El campo de total del metrado Delphin no identifica una celda ni un nombre definido unívoco: " + campo);
        }
        // Delphin publica este nombre en su libro nativo; los nombres de
        // columnas (unidades, largo, etc.) se conservan en el OOXML original.
        var definidos = documento.Descendants(S + "definedName").Where(n =>
            string.Equals((string)n.Attribute("name"), "total_metrado", StringComparison.OrdinalIgnoreCase)).ToArray();
        if (definidos.Length != 0)
            return TotalDefinido(definidos, hojas) ?? throw new InvalidDataException("El nombre total_metrado de Delphin no identifica una celda unívoca.");
        definidos = documento.Descendants(S + "definedName").Where(n =>
            string.Equals((string)n.Attribute("name"), "Total", StringComparison.OrdinalIgnoreCase)).ToArray();
        if (definidos.Length != 0)
            return TotalDefinido(definidos, hojas) ?? throw new InvalidDataException("El nombre Total del metrado no identifica una celda unívoca.");

        string[] compartidas = libro.GetEntry("xl/sharedStrings.xml") == null ? Array.Empty<string>() :
            Xml(libro, "xl/sharedStrings.xml").Descendants(S + "si").Select(x => string.Concat(x.Descendants(S + "t").Select(t => t.Value))).ToArray();
        var candidatos = new List<Total>();
        foreach (var h in hojas)
        {
            var celdas = Xml(libro, h.Parte).Descendants(S + "sheetData").Descendants(S + "c").ToArray();
            foreach (var etiqueta in celdas.Where(c => Texto(c, compartidas).Trim().TrimEnd(':').Trim().Equals("Total", StringComparison.OrdinalIgnoreCase)))
            {
                var posicion = MYGHojaCalculo.Coordenadas((string)etiqueta.Attribute("r"));
                foreach (var celda in celdas.Where(c => c.Element(S + "f") is XElement f && Suma.IsMatch(f.Value)))
                {
                    var lugar = MYGHojaCalculo.Coordenadas((string)celda.Attribute("r"));
                    if (lugar.Fila == posicion.Fila && lugar.Columna > posicion.Columna)
                        candidatos.Add(new Total(h, MYGHojaCalculo.Normalizar((string)celda.Attribute("r"))));
                }
            }
        }
        var unicos = candidatos.Distinct().ToArray();
        if (unicos.Length != 1) throw new InvalidDataException("No se pudo identificar un total unívoco en el libro de metrado Delphin. Configure una celda o un nombre definido de total.");
        return unicos[0];
    }

    private static Total TotalDefinido(XElement[] nombres, Hoja[] hojas)
    {
        var encontrados = new List<Total>();
        foreach (var nombre in nombres)
        {
            Hoja local = null;
            if (int.TryParse((string)nombre.Attribute("localSheetId"), out int indice)) local = hojas.SingleOrDefault(h => h.Indice == indice);
            if (!IntentarReferencia(nombre.Value.Trim().TrimStart('='), hojas, local, out var total)) return null;
            encontrados.Add(total);
        }
        var unicos = encontrados.Distinct().ToArray();
        return unicos.Length == 1 ? unicos[0] : null;
    }

    private static bool IntentarReferencia(string valor, Hoja[] hojas, Hoja local, out Total total)
    {
        total = null;
        int separador = valor.LastIndexOf('!');
        string direccion = separador < 0 ? valor : valor[(separador + 1)..];
        if (!Celda.IsMatch(direccion)) return false;
        Hoja hoja;
        if (separador >= 0)
        {
            string nombre = valor[..separador];
            if (nombre.StartsWith('\'') && nombre.EndsWith('\'')) nombre = nombre[1..^1].Replace("''", "'");
            hoja = hojas.SingleOrDefault(h => h.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase));
        }
        else hoja = local ?? (hojas.Length == 1 ? hojas[0] : null);
        if (hoja == null) return false;
        var coordenadas = MYGHojaCalculo.Coordenadas(direccion);
        if (coordenadas.Fila > 10000 || coordenadas.Columna > 200) return false;
        total = new Total(hoja, MYGHojaCalculo.Normalizar(direccion));
        return true;
    }

    private static string Texto(XElement celda, string[] compartidas)
    {
        string tipo = (string)celda.Attribute("t");
        if (tipo == "inlineStr") return string.Concat(celda.Descendants(S + "t").Select(t => t.Value));
        string valor = celda.Element(S + "v")?.Value ?? "";
        if (tipo == "s") return int.TryParse(valor, out int indice) && indice >= 0 && indice < compartidas.Length ? compartidas[indice] : "";
        return tipo == "str" ? valor : "";
    }

    private static MYGHojaMetrado Importar(byte[] contenido, string nombre, string total) => Temporal(ruta =>
    {
        File.WriteAllBytes(ruta, contenido);
        try { return MYGExcelPresupuestos.Importar(ruta, nombre, total); }
        catch (Exception ex) when (ex is XmlException or ArgumentException or InvalidOperationException or IndexOutOfRangeException or FormatException)
        { throw new InvalidDataException("El contenido OOXML del metrado no se puede interpretar fielmente.", ex); }
    });

    private static T Temporal<T>(Func<string, T> accion)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-delphin-metrado-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try { return accion(Path.Combine(carpeta, "metrado.xlsx")); }
        finally { Directory.Delete(carpeta, true); }
    }

    private static bool Igual<T>(T a, T b) => JsonElement.DeepEquals(JsonSerializer.SerializeToElement(a), JsonSerializer.SerializeToElement(b));

    private static void ComprobarEdicion(MYGHojaMetrado inicial, MYGHojaMetrado actual)
    {
        var a = MYGProyectoStorage.Copia(inicial); var b = MYGProyectoStorage.Copia(actual);
        // El zoom es una preferencia de presentación de MYG; no necesita
        // reescribir la vista del libro nativo al editar un valor.
        b.Zoom = a.Zoom;
        a.Celdas.Clear(); b.Celdas.Clear();
        if (!Igual(a, b)) throw new InvalidDataException("El guardado nativo conserva la estructura y el formato del libro Delphin. No se puede guardar este cambio estructural o de configuración sin perder información.");
        foreach (var direccion in inicial.Celdas.Keys.Union(actual.Celdas.Keys, StringComparer.OrdinalIgnoreCase))
        {
            if (!actual.Celdas.TryGetValue(direccion, out var celda))
                throw new InvalidDataException("No se puede retirar una celda nativa con formato; borre solamente su contenido para conservar el libro Delphin.");
            var antes = inicial.Celdas.TryGetValue(direccion, out var existente) ? MYGProyectoStorage.Copia(existente) :
                new MYGCeldaHoja { FormatoNumero = inicial.FormatoNumeroPredeterminado,
                    AlineacionHorizontal = MYGHojaCalculo.Coordenadas(direccion).Columna == 1 ? "Izquierda" : "Centro" };
            var despues = MYGProyectoStorage.Copia(celda); antes.Contenido = despues.Contenido = "";
            if (!Igual(antes, despues)) throw new InvalidDataException("El guardado nativo conserva los estilos originales de Delphin. Este cambio de formato de celda requiere un editor compatible con el libro original.");
        }
    }

    private static void InsertarOrdenado(XElement padre, XElement nuevo, int posicion, Func<XElement, int> clave)
    {
        var siguiente = padre.Elements().FirstOrDefault(x => clave(x) > posicion);
        if (siguiente == null) padre.Add(nuevo); else siguiente.AddBeforeSelf(nuevo);
    }

    private static void EscribirContenido(XElement celda, string contenido)
    {
        // Un identificador textual como "001" sigue siendo texto al editarse;
        // su apariencia numérica no autoriza convertirlo a un número Excel.
        bool textoOriginal = celda.Element(S + "f") == null && (string)celda.Attribute("t") is "s" or "str" or "inlineStr";
        celda.Elements(S + "f").Remove(); celda.Elements(S + "v").Remove(); celda.Elements(S + "is").Remove();
        celda.Attribute("t")?.Remove();
        if (contenido.StartsWith('=')) celda.AddFirst(new XElement(S + "f", contenido[1..]));
        else if (!textoOriginal && MYGHojaCalculo.IntentarNumero(contenido, out var numero)) celda.AddFirst(new XElement(S + "v", numero.ToString(CultureInfo.InvariantCulture)));
        else if (contenido.Length != 0)
        {
            try { XmlConvert.VerifyXmlChars(contenido); }
            catch (XmlException ex) { throw new InvalidDataException("La celda contiene caracteres que OOXML no puede conservar.", ex); }
            celda.SetAttributeValue("t", "inlineStr");
            celda.AddFirst(new XElement(S + "is", new XElement(S + "t", new XAttribute(XNamespace.Xml + "space", "preserve"), contenido)));
        }
    }

    private static void ActualizarCache(XElement celda, MYGHojaCalculo calculo, string direccion)
    {
        celda.Elements(S + "v").Remove(); celda.Attribute("t")?.Remove();
        try
        {
            var resultado = calculo.Resultado(direccion).SinError();
            if (resultado.EsTexto) { celda.SetAttributeValue("t", "str"); celda.Element(S + "f")!.AddAfterSelf(new XElement(S + "v", resultado.Texto)); }
            else if (resultado.EsLogico) { celda.SetAttributeValue("t", "b"); celda.Element(S + "f")!.AddAfterSelf(new XElement(S + "v", resultado.Logico ? "1" : "0")); }
            else celda.Element(S + "f")!.AddAfterSelf(new XElement(S + "v", resultado.Numero().ToString(CultureInfo.InvariantCulture)));
        }
        catch (Exception ex) when (ex is FormatException or InvalidDataException or DivideByZeroException or OverflowException)
        { /* Una fórmula no soportada se conserva sin un valor en caché engañoso. */ }
    }
}
