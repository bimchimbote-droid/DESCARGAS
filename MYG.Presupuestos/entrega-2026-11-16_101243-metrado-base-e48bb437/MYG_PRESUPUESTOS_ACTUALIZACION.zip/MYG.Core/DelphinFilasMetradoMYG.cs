using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

// Delphin conserva el libro y un índice de sus filas en metrado. El mapeo
// procede de los nombres definidos del propio libro, no de columnas supuestas.
internal static class DelphinFilasMetradoMYG
{
    private static readonly string[] Campos = { "descripcion_metrado", "unidades", "cantidadxunidad", "largo", "ancho", "alto", "parcial_metrado", "observaciones" };
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    internal static string Firma(SqliteConnection c, SqliteTransaction t, string partidaId)
    {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        void Agregar(string texto)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(texto ?? "");
            hash.AppendData(BitConverter.GetBytes(bytes.Length)); hash.AppendData(bytes);
        }
        var columnas = Columnas(c, t);
        if (columnas.Contains("id_costounitario") && columnas.Contains("id_metrado"))
        {
            using var cmd = MYGBaseDatos.Comando(c, t, "SELECT * FROM metrado WHERE id_costounitario=$p0 ORDER BY id_metrado COLLATE BINARY", partidaId);
            using var r = cmd.ExecuteReader();
            for (int n = 0; n < r.FieldCount; n++) Agregar(r.GetName(n));
            while (r.Read())
                for (int n = 0; n < r.FieldCount; n++)
                {
                    if (r.IsDBNull(n)) { Agregar("NULL"); continue; }
                    object valor = r.GetValue(n);
                    Agregar(valor.GetType().FullName);
                    Agregar(valor is byte[] blob ? Convert.ToHexString(SHA256.HashData(blob)) : Convert.ToString(valor, CultureInfo.InvariantCulture));
                }
        }
        return Convert.ToHexString(hash.GetHashAndReset());
    }

    internal static void Sincronizar(SqliteConnection c, SqliteTransaction t,
        string presupuestoId, string partidaId, byte[] original, MYGHojaMetrado hoja)
    {
        var columnas = Columnas(c, t);
        if (!columnas.Contains("id_costounitario")) return;
        if (!columnas.Contains("id_metrado")) throw NoRepresentable();
        var filas = new List<Fila>();
        using (var cmd = MYGBaseDatos.Comando(c, t,
            "SELECT id_metrado," + (columnas.Contains("posicion") ? "posicion" : "NULL") + "," +
            (columnas.Contains("editor_metrado") ? "editor_metrado" : "NULL") +
            " FROM metrado WHERE id_costounitario=$p0 ORDER BY id_metrado", partidaId))
        using (var r = cmd.ExecuteReader()) while (r.Read())
            filas.Add(new Fila(r.GetString(0), r.IsDBNull(1) ? null : Convert.ToInt32(r.GetValue(1), CultureInfo.InvariantCulture),
                r.IsDBNull(2) ? null : Convert.ToString(r.GetValue(2), CultureInfo.InvariantCulture)));

        var mapa = LeerMapa(original, hoja.Nombre, hoja.CeldaTotal);
        // Un XLSX genérico sin filas nativas sigue siendo un libro válido; no
        // se inventan índices ni códigos de editor para poblar la tabla.
        if (mapa == null && filas.Count == 0) return;
        if (mapa == null || Campos.Any(campo => !columnas.Contains(campo))) throw NoRepresentable();
        string editor;
        using (var cmd = MYGBaseDatos.Comando(c, t,
            "SELECT editor_metrado FROM costo_unitario WHERE id_costounitario=$p0 AND id_presupuesto=$p1", partidaId, presupuestoId))
            editor = cmd.ExecuteScalar() as string;
        if (string.IsNullOrWhiteSpace(editor)) throw NoRepresentable();
        var propias = filas.Where(f => string.Equals(f.Editor, editor, StringComparison.Ordinal)).ToList();
        if (propias.Count == 0 && filas.Count > 0) throw NoRepresentable();
        if (propias.Any(f => !f.Posicion.HasValue || f.Posicion < 0 || f.Posicion.Value + mapa.Primera >= mapa.Total) ||
            propias.Select(f => f.Posicion).Distinct().Count() != propias.Count) throw NoRepresentable();

        var anterior = DelphinLibroMetrado.Leer(original, hoja.CeldaTotal);
        var calculoAntes = new MYGHojaCalculo(anterior);
        var calculoNuevo = new MYGHojaCalculo(hoja);
        var porFila = propias.ToDictionary(f => f.Posicion.Value + mapa.Primera);
        var cambios = new List<(Fila Fila, Dictionary<string, object> Valores)>();
        for (int numero = mapa.Primera; numero < mapa.Total; numero++)
        {
            if (mapa.Imagen.HasValue)
            {
                string imagen = MYGHojaCalculo.Columna(mapa.Imagen.Value) + numero.ToString(CultureInfo.InvariantCulture);
                if (Contenido(anterior, imagen) != Contenido(hoja, imagen)) throw NoRepresentable();
            }
            string Direccion(string campo) => MYGHojaCalculo.Columna(mapa.Columnas[campo]) + numero.ToString(CultureInfo.InvariantCulture);
            bool CambioCampo(string campo)
            {
                string direccion = Direccion(campo), antes = Contenido(anterior, direccion), despues = Contenido(hoja, direccion);
                return antes != despues || despues.StartsWith('=') &&
                    calculoAntes.Resultado(direccion).Texto != calculoNuevo.Resultado(direccion).Texto;
            }
            bool cambianEntradas = Campos.Where(campo => campo != "parcial_metrado")
                .Any(CambioCampo);
            bool cambiaParcial = CambioCampo("parcial_metrado");
            if (!porFila.TryGetValue(numero, out var fila))
            {
                if (cambianEntradas || cambiaParcial) throw NoRepresentable();
                continue;
            }
            if (!cambianEntradas && !cambiaParcial) continue;
            // No asignar identidades nuevas ni convertir una eliminación de
            // fila en un registro vacío con metadatos ajenos conservados.
            if (Campos.Where(campo => campo != "parcial_metrado")
                .All(campo => string.IsNullOrWhiteSpace(Contenido(hoja, Direccion(campo))))) throw NoRepresentable();
            var valores = new Dictionary<string, object>();
            foreach (string campo in Campos.Where(campo => campo != "parcial_metrado"))
            {
                string direccion = Direccion(campo);
                if (!CambioCampo(campo)) continue;
                valores[campo] = campo is "descripcion_metrado" or "observaciones"
                    ? Texto(hoja, calculoNuevo, direccion) : Numero(hoja, calculoNuevo, direccion, campo is "largo" or "ancho" or "alto" ? 1m : 0m);
            }
            // Una fórmula puede conservar el mismo texto y producir otro
            // resultado al cambiar sus operandos o una referencia anterior.
            decimal parcialNuevo = Numero(hoja, calculoNuevo, Direccion("parcial_metrado"), 0m);
            decimal parcialAnterior = Numero(anterior, calculoAntes, Direccion("parcial_metrado"), 0m);
            if (cambiaParcial || parcialNuevo != parcialAnterior) valores["parcial_metrado"] = parcialNuevo;
            if (valores.Count > 0) cambios.Add((fila, valores));
        }
        // Preparar y validar todas las filas antes del primer UPDATE. La
        // transacción exterior sigue protegiendo el libro y su documento MYG.
        foreach (var cambio in cambios)
        {
            var campos = cambio.Valores.Keys.ToArray();
            object[] parametros = new object[] { cambio.Fila.Id, partidaId, editor }
                .Concat(campos.Select(campo => cambio.Valores[campo])).ToArray();
            MYGBaseDatos.Ejecutar(c, t, "UPDATE metrado SET " + string.Join(",", campos.Select((campo, indice) => campo + "=$p" + (indice + 3))) +
                " WHERE id_metrado=$p0 AND id_costounitario=$p1 AND editor_metrado=$p2", parametros);
        }
    }

    private static string Contenido(MYGHojaMetrado hoja, string direccion) =>
        hoja.Celdas.TryGetValue(direccion, out var celda) ? celda.Contenido ?? "" : "";

    private static string Texto(MYGHojaMetrado hoja, MYGHojaCalculo calculo, string direccion)
    {
        string contenido = Contenido(hoja, direccion);
        string valor = contenido.StartsWith('=') ? calculo.Resultado(direccion).Texto : contenido;
        if (valor.Length > 255) throw NoRepresentable();
        return valor;
    }

    private static decimal Numero(MYGHojaMetrado hoja, MYGHojaCalculo calculo, string direccion, decimal vacio)
    {
        if (string.IsNullOrWhiteSpace(Contenido(hoja, direccion))) return vacio;
        var valor = calculo.Resultado(direccion);
        if (!valor.EsNumero) throw NoRepresentable();
        return valor.Numero();
    }

    private static Mapa LeerMapa(byte[] original, string nombre, string celdaTotal)
    {
        using var z = new ZipArchive(new MemoryStream(original, false), ZipArchiveMode.Read);
        var parte = z.GetEntry("xl/workbook.xml");
        if (parte == null || parte.Length > 2 * 1024 * 1024) throw NoRepresentable();
        using var entrada = parte.Open();
        using var lector = XmlReader.Create(entrada, new XmlReaderSettings
        { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 2 * 1024 * 1024 });
        var libro = XDocument.Load(lector);
        var nombres = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var n in libro.Descendants(S + "definedName"))
        {
            string clave = (string)n.Attribute("name");
            if (clave == null || !(Campos.Contains(clave) || clave is "init_row" or "total_metrado" or "imagen")) continue;
            int separador = n.Value.LastIndexOf('!');
            if (separador < 0) throw NoRepresentable();
            string hoja = n.Value[..separador].Trim();
            if (hoja.StartsWith('\'') && hoja.EndsWith('\'')) hoja = hoja[1..^1].Replace("''", "'");
            if (!string.Equals(hoja, nombre, StringComparison.Ordinal)) continue;
            if (!nombres.TryAdd(clave, n.Value[(separador + 1)..].Replace("$", ""))) throw NoRepresentable();
        }
        if (!nombres.Keys.Any(Campos.Contains)) return null;
        if (Campos.Any(campo => !nombres.ContainsKey(campo)) || !nombres.TryGetValue("init_row", out string inicio) ||
            !nombres.TryGetValue("total_metrado", out string total)) throw NoRepresentable();
        var fila = Regex.Match(inicio, @"^([1-9][0-9]*):\1$");
        if (!fila.Success || !int.TryParse(fila.Groups[1].Value, out int primera)) throw NoRepresentable();
        var posicionTotal = MYGHojaCalculo.Coordenadas(total);
        if (MYGHojaCalculo.Normalizar(total) != MYGHojaCalculo.Normalizar(celdaTotal) || primera >= posicionTotal.Fila || posicionTotal.Fila > 10000) throw NoRepresentable();
        var columnas = new Dictionary<string, int>();
        foreach (string campo in Campos)
        {
            var columna = Regex.Match(nombres[campo], @"^([A-Z]{1,3}):\1$");
            if (!columna.Success) throw NoRepresentable();
            columnas[campo] = MYGHojaCalculo.Coordenadas(columna.Groups[1].Value + "1").Columna;
        }
        if (columnas.Values.Distinct().Count() != columnas.Count || columnas.Values.Any(v => v > 200)) throw NoRepresentable();
        int? imagen = null;
        if (nombres.TryGetValue("imagen", out string imagenDefinida))
        {
            var columna = Regex.Match(imagenDefinida, @"^([A-Z]{1,3}):\1$");
            if (!columna.Success) throw NoRepresentable();
            imagen = MYGHojaCalculo.Coordenadas(columna.Groups[1].Value + "1").Columna;
            if (imagen > 200 || columnas.Values.Contains(imagen.Value)) throw NoRepresentable();
        }
        return new Mapa(columnas, primera, posicionTotal.Fila, imagen);
    }

    private static HashSet<string> Columnas(SqliteConnection c, SqliteTransaction t)
    {
        var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using var cmd = MYGBaseDatos.Comando(c, t, "SELECT name FROM pragma_table_info('metrado')");
        using var r = cmd.ExecuteReader(); while (r.Read()) columnas.Add(r.GetString(0));
        return columnas;
    }

    private sealed record Fila(string Id, int? Posicion, string Editor);
    private sealed record Mapa(Dictionary<string, int> Columnas, int Primera, int Total, int? Imagen);
    private static InvalidDataException NoRepresentable() => new("La hoja de metrado cambió de una forma que no permite actualizar sus filas nativas de Delphin con identidad segura. Se conservó el archivo original. Edite las filas existentes sin agregar, eliminar o reordenar filas, o realice ese cambio en Delphin.");
}
