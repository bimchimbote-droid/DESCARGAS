using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace MYG_2027;

public sealed class MYGPlantillaMetrado
{
    public string Id { get; }
    public string Nombre { get; }
    internal MYGPlantillaMetrado(string id, string nombre) { Id = id; Nombre = nombre; }
}

/// <summary>Plantillas integradas disponibles incluso en una base SQLite vacía.</summary>
public static class MYGPlantillasMetrado
{
    public const string Estandar = "estandar";
    public const string Aceros = "aceros";
    public static IReadOnlyList<MYGPlantillaMetrado> Disponibles { get; } = Array.AsReadOnly(new[]
    {
        new MYGPlantillaMetrado(Estandar, "PLANTILLA ESTÁNDAR"),
        new MYGPlantillaMetrado(Aceros, "PLANTILLA DE FIERROS Y ACEROS")
    });

    private static readonly string[] Diametros =
    ["4mm", "4.5mm", "5mm", "5.5mm", "6mm", "1/4″", "6.5mm", "7mm", "7.5mm", "8mm", "8.5mm",
        "3/8″", "12mm", "1/2″", "5/8″", "3/4″", "7/8″", "1″", "1 1/8″", "1 1/4″", "1 3/8″"];
    private static readonly decimal[] PesosPorMetro =
    [0.099m, 0.125m, 0.154m, 0.187m, 0.220m, 0.250m, 0.260m, 0.302m, 0.347m, 0.400m, 0.445m,
        0.580m, 0.890m, 1.020m, 1.600m, 2.260m, 3.040m, 4.000m, 5.060m, 6.400m, 7.910m];
    private static string AliasPulgadas(string diametro) => !diametro.EndsWith('″') ? "" :
        diametro == "1″" ? "1 pulg" : diametro.TrimEnd('″');

    /// <summary>Devuelve una hoja independiente; seleccionar una plantilla nunca comparte celdas entre partidas.</summary>
    public static MYGHojaMetrado Crear(string id) => id switch
    {
        Estandar => MYGHojaMetrado.Crear(),
        Aceros => CrearAceros(),
        _ => throw new ArgumentException("La plantilla de metrado no existe.", nameof(id))
    };

    /// <summary>Identifica sin modificar la hoja ni escribir en la base de datos.</summary>
    public static string Identificar(MYGHojaMetrado hoja)
    {
        if (hoja == null) return "";
        if (hoja.IdPlantilla is Estandar or Aceros) return hoja.IdPlantilla;
        if (!string.IsNullOrEmpty(hoja.IdPlantilla)) return "";
        bool Etiqueta(string direccion, string texto) => hoja.Celdas != null && hoja.Celdas.TryGetValue(direccion, out var celda) &&
            string.Equals(celda?.Contenido?.Trim(), texto, StringComparison.OrdinalIgnoreCase);
        string[] titulos = ["Descripción", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Parcial", "Plano / Referencia"];
        return hoja.Columnas >= 8 && hoja.Filas >= 2 && Etiqueta("A1", "Datos") && Etiqueta("D1", "Dimensiones") &&
            Etiqueta("G1", "Total") && titulos.Select((texto, indice) => Etiqueta(MYGHojaCalculo.Columna(indice + 1) + "2", texto)).All(x => x)
                ? Estandar : "";
    }

    private static MYGHojaMetrado CrearAceros()
    {
        var hoja = new MYGHojaMetrado
        {
            IdPlantilla = Aceros, Columnas = 34, CeldaTotal = "AD16", OrientacionPagina = "Horizontal", AreaImpresion = "A1:AD16",
            AnchosColumnas = new() { [1] = 288, [2] = 68, [3] = 72, [4] = 65, [5] = 84, [6] = 70, [7] = 70, [8] = 92, [30] = 115 },
            AltosFilas = new() { [1] = 20, [2] = 38 }
        };
        for (int columna = 9; columna <= 29; columna++) hoja.AnchosColumnas[columna] = 72;
        for (int fila = 3; fila <= 16; fila++) hoja.AltosFilas[fila] = 20;
        hoja.RangosCombinados.AddRange(["A1:D1", "E1:H1", "I1:AC1", "A14:H14", "A15:H15", "A16:H16", "AD14:AD15"]);
        hoja.Poner("A1", "Datos", true);
        hoja.Poner("E1", "Longitud Parcial", true);
        hoja.Poner("I1", "Longitud x Ø", true);
        hoja.Poner("AD1", "Referencia", true);
        string[] titulos = ["Descripción", "Elem. simil.", "Cant. x Elem.", "Ø", "Long. x Pieza (m)", "Gancho", "Empalme", "% Desperdicio"];
        for (int indice = 0; indice < titulos.Length; indice++) hoja.Poner(MYGHojaCalculo.Columna(indice + 1) + "2", titulos[indice], true);
        hoja.Poner("AD2", "Id - Plano", true);
        hoja.Poner("A14", "Longitud total x Ø", true);
        hoja.Poner("A15", "Peso (kg/m)", true);
        hoja.Poner("A16", "Peso Total (kg)", true);
        hoja.Poner("AD14", "Peso Total (kg)", true);
        hoja.Poner("AD16", "=SUM(I16:AC16)", true);

        // Son fórmulas normales del mismo motor Excel: las referencias relativas
        // y absolutas se ajustan con copiar, rellenar e insertar filas/columnas.
        for (int indice = 0; indice < Diametros.Length; indice++)
        {
            string columna = MYGHojaCalculo.Columna(indice + 9);
            hoja.Poner(columna + "2", Diametros[indice], true);
            string alias = AliasPulgadas(Diametros[indice]);
            for (int fila = 3; fila <= 13; fila++)
            {
                string coincidencia = alias.Length == 0 ? $"$D{fila}={columna}$2" : $"OR($D{fila}={columna}$2,$D{fila}=\"{alias}\")";
                hoja.Poner(columna + fila, $"=IF({coincidencia},$B{fila}*$C{fila}*SUM($E{fila}:$G{fila})*(1+$H{fila}/100),0)");
            }
            hoja.Poner(columna + "14", $"=SUM({columna}3:{columna}13)", true);
            hoja.Poner(columna + "15", PesosPorMetro[indice].ToString("0.000", CultureInfo.InvariantCulture));
            hoja.Poner(columna + "16", $"={columna}14*{columna}15", true);
            hoja.Celdas[columna + "15"].TipoValidacion = "Numero";
            hoja.Celdas[columna + "15"].Minimo = 0;
            hoja.Celdas[columna + "15"].FormatoNumero = "0.000";
        }
        for (int fila = 3; fila <= 13; fila++)
        {
            var diametro = MYGEdicionHoja.Celda(hoja, "D" + fila);
            diametro.TipoValidacion = "Lista";
            // Las fracciones se pueden escribir con el teclado habitual (3/8).
            // El diámetro de una pulgada usa "1 pulg" para evitar ambigüedad numérica.
            diametro.ListaValores = Diametros.Concat(Diametros.Select(AliasPulgadas).Where(x => x.Length != 0)).ToList();
            diametro.FormatoNumero = "General";
            foreach (string columna in new[] { "B", "C", "E", "F", "G", "H" })
            {
                var entrada = MYGEdicionHoja.Celda(hoja, columna + fila);
                entrada.TipoValidacion = "Numero";
                entrada.Minimo = 0;
                entrada.FormatoNumero = "0.##";
            }
        }
        foreach (string direccion in MYGEdicionHoja.Direcciones(hoja, "A1:AD16"))
        {
            var celda = MYGEdicionHoja.Celda(hoja, direccion);
            int fila = MYGHojaCalculo.Coordenadas(direccion).Fila;
            celda.Bordes = true;
            celda.AlineacionPersonalizada = true;
            celda.FormatoNumero = fila <= 2 ? "General" : celda.FormatoNumero;
            if (fila <= 2)
            {
                celda.ColorFondo = "EFF9FC";
                celda.AjustarTexto = true;
                celda.AlineacionHorizontal = direccion == "A2" ? "Izquierda" : "Centro";
            }
            else if (celda.Contenido.StartsWith('=')) celda.FormatoNumero = "0.###;-0.###;-";
        }
        foreach (string direccion in new[] { "A14", "A15", "A16" }) hoja.Celdas[direccion].AlineacionHorizontal = "Derecha";
        for (int fila = 3; fila <= 13; fila++) hoja.Celdas["AD" + fila].AlineacionHorizontal = "Izquierda";
        MYGHojaCalculo.Validar(hoja);
        return hoja;
    }
}
