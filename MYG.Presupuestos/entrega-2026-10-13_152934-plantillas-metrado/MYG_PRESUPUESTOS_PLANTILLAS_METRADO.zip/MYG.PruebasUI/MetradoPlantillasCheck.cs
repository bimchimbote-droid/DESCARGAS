using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoPlantillasCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Plantillas", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        ItemPresupuestoDelphin Partida(string nombre) => new()
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = nombre,
            Unidad = "kg", TipoPropuesta = "PARTIDA", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 12m, FuenteMetrado = MYGFuenteMetrado.Cantidad }
        };
        var primera = Partida("ACERO"); var segunda = Partida("OTRA PARTIDA");
        primera.Costos.Hoja.Poner("A3", "Dato original");
        primera.Costos.Hoja.Celdas["A3"].ColorFondo = "C6EFCE";
        segunda.Costos.Hoja.Poner("A3", "Hoja vecina intacta");
        presupuesto.Items.AddRange([primera, segunda]);
        int anteriores = 0, cambios = 0, guardados = 0, avisos = 0;
        var historial = new Stack<MYGDatosPartida>();
        MYGPanelPresupuesto panel = null;
        using var control = panel = new MYGPanelPresupuesto(() => presupuesto,
            () => { anteriores++; historial.Push(MYGProyectoStorage.Copia(primera.Costos)); },
            () => cambios++, _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++,
            () => { primera.Costos = historial.Pop(); panel.Refrescar(); panel.SeleccionarEstructura(primera); });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1800, 1000) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(primera);
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        ((TabControl)pagina.Parent).SelectedTab = pagina;
        Application.DoEvents();
        var hoja = Campo<DataGridView>(panel, "hoja");
        var cabecera = Campo<MYGMetradoCabecera>(panel, "cabeceraExcel");
        var menu = Campo<ContextMenuStrip>(cabecera, "menu");
        cabecera.ActualizarPlantillas();
        exige(menu.Items.Count == 2 && menu.Items.Cast<ToolStripMenuItem>().All(m => m.Enabled) &&
            ((ToolStripMenuItem)menu.Items[0]).Checked && !((ToolStripMenuItem)menu.Items[1]).Checked &&
            menu.Items[0].Text == "PLANTILLA ESTÁNDAR" && menu.Items[1].Text == "PLANTILLA DE FIERROS Y ACEROS",
            "El botón XLS debe mostrar sólo las dos plantillas integradas y marcar la plantilla actual.");
        exige(cabecera.Controls.Find("metrado_plantilla_xls", true).Single().AccessibleName == "Seleccionar plantilla de metrado",
            "El botón de la cabecera debe identificar selección de plantilla, sin acciones de exportación.");
        string original = Estado(primera.Costos), vecina = Estado(segunda.Costos);
        panel.ConfirmarCambioPlantillaMetrado = _ => { avisos++; return false; };
        menu.Items[1].PerformClick(); Application.DoEvents();
        exige(Estado(primera.Costos) == original && Estado(segunda.Costos) == vecina &&
            anteriores == 0 && cambios == 0 && guardados == 0 && avisos == 1,
            "Cancelar la advertencia debe conservar hojas, formatos, costos y el historial.");
        menu.Items[0].PerformClick();
        exige(avisos == 1 && Estado(primera.Costos) == original && anteriores == 0,
            "Elegir la plantilla ya marcada debe conservar la hoja editada sin reiniciarla ni mostrar advertencias.");

        panel.ConfirmarCambioPlantillaMetrado = _ => { avisos++; return true; };
        menu.Items[1].PerformClick(); Application.DoEvents();
        exige(primera.Costos.Hoja.IdPlantilla == MYGPlantillasMetrado.Aceros && hoja.ColumnCount == 34 &&
            primera.Costos.Hoja.CeldaTotal == "AD16" && new MYGHojaCalculo(primera.Costos.Hoja).Numero("AD16") == 0 &&
            Estado(segunda.Costos) == vecina && primera.Costos.Cantidad == 12m &&
            primera.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
            anteriores == 1 && cambios == 1 && guardados == 0 &&
            ((ToolStripMenuItem)menu.Items[1]).Checked && !((ToolStripMenuItem)menu.Items[0]).Checked,
            "Aceptar debe aplicar aceros sólo a la partida actual, conservar los otros datos y registrar un único cambio.");
        typeof(MYGPanelPresupuesto).GetField("filtroTextoHoja", Privados).SetValue(panel, "sin coincidencias");
        Invocar(panel, "FiltrarHoja");
        exige(!hoja.Rows[2].Visible && hoja.Rows[13].Visible && hoja.Rows[14].Visible && hoja.Rows[15].Visible,
            "El filtro de aceros debe conservar las tres filas de resumen y ocultar sólo los detalles que no coincidan.");
        typeof(MYGPanelPresupuesto).GetField("filtroTextoHoja", Privados).SetValue(panel, "");
        Invocar(panel, "FiltrarHoja");
        var acero = primera.Costos.Hoja;
        MYGEdicionHoja.Celda(acero, "B3").Contenido = "2";
        MYGEdicionHoja.Celda(acero, "C3").Contenido = "3";
        MYGEdicionHoja.Celda(acero, "D3").Contenido = "3/8";
        MYGEdicionHoja.Celda(acero, "E3").Contenido = "4";
        Invocar(panel, "CargarHoja");
        hoja.CurrentCell = hoja[29, 15]; // La selección de AD no existe en la plantilla estándar.
        string aceroEditado = Estado(primera.Costos);
        menu.Items[0].PerformClick(); Application.DoEvents();
        exige(primera.Costos.Hoja.IdPlantilla == MYGPlantillasMetrado.Estandar && hoja.ColumnCount == 12 &&
            hoja.CurrentCell.ColumnIndex < 12 && anteriores == 2 && cambios == 2 && Estado(segunda.Costos) == vecina,
            "Volver a estándar debe reconstruir la selección sin índices de la plantilla ancha ni afectar la otra partida.");
        Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
        exige(Estado(primera.Costos) == aceroEditado && Estado(segunda.Costos) == vecina &&
            primera.Costos.Hoja.IdPlantilla == MYGPlantillasMetrado.Aceros && hoja.ColumnCount == 34,
            "Deshacer debe recuperar íntegros los datos, las fórmulas y los formatos de la plantilla anterior.");
        var reemplazo = MYGProyectoStorage.Copia(primera);
        int avisosPrevios = avisos;
        panel.ConfirmarCambioPlantillaMetrado = _ =>
        {
            avisos++;
            presupuesto.Items[presupuesto.Items.IndexOf(primera)] = reemplazo;
            return true;
        };
        panel.ElegirPlantillaMetrado(MYGPlantillasMetrado.Estandar);
        exige(avisos == avisosPrevios + 1 && Estado(primera.Costos) == aceroEditado &&
            Estado(reemplazo.Costos) == aceroEditado && anteriores == 2 && cambios == 2,
            "Una partida sustituida durante la advertencia no debe recibir cambios mediante una referencia obsoleta.");
        presupuesto.Items[presupuesto.Items.IndexOf(reemplazo)] = primera;

        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                using var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla de fierros y aceros");
                var aceptar = aviso.Controls.Find("plantilla_confirmacion_aceptar", true).Single();
                var cancelar = aviso.Controls.Find("plantilla_confirmacion_cancelar", true).Single();
                exige(!aceptar.Enabled && aviso.AcceptButton == cancelar && aviso.CancelButton == cancelar,
                    "La advertencia debe permitir leer antes de aceptar y usar Cancelar por defecto en ambos temas.");
                aviso.ActualizarEspera(3);
                exige(aceptar.Enabled && cancelar.Text == "Cancelar (7)",
                    "Aceptar debe habilitarse tras tres segundos y el contador debe indicar la cancelación pendiente.");
                aviso.ActualizarEspera(10);
                exige(aviso.DialogResult == DialogResult.Cancel,
                    "El vencimiento de la advertencia debe cancelar siempre, sin aceptar el cambio.");
            }
        }
        finally { if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false); }
        foreach (Keys tecla in new[] { Keys.Enter, Keys.Escape })
        {
            using var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla estándar");
            aviso.ActualizarEspera(3);
            Invocar(aviso, "ProcessDialogKey", tecla);
            exige(aviso.DialogResult == DialogResult.Cancel,
                "Enter y Escape deben cancelar aunque el botón Aceptar ya esté habilitado.");
        }
        using (var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla estándar"))
        {
            aviso.Show(formulario); Application.DoEvents();
            aviso.ActualizarEspera(3);
            ((Button)aviso.Controls.Find("plantilla_confirmacion_aceptar", true).Single()).PerformClick();
            exige(aviso.DialogResult == DialogResult.OK, "La advertencia debe aceptar sólo mediante el botón habilitado.");
        }
        using (var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla estándar"))
        {
            aviso.Show(formulario); Application.DoEvents(); aviso.Close();
            exige(aviso.DialogResult == DialogResult.Cancel, "Cerrar la advertencia con la X debe cancelar el cambio.");
        }
        using (var cabeceraVacia = new MYGMetradoCabecera(() => "", () => "", () => "", () => "", _ => { }, () => false))
        {
            var opciones = Campo<ContextMenuStrip>(cabeceraVacia, "menu");
            exige(opciones.Items.Count == 2 && opciones.Items.Cast<ToolStripMenuItem>().All(m => !m.Enabled),
                "Una base sin partidas debe mostrar ambas plantillas sin permitir un cambio hasta seleccionar una partida.");
        }
        formulario.Close();
    }

    private static string Estado(object valor) => JsonSerializer.Serialize(valor);
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
