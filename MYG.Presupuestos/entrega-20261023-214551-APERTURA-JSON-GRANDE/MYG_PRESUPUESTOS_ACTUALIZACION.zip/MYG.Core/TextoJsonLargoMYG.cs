#nullable enable
using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MYG_2027;

/// <summary>
/// Conserva el formato de cadena JSON, escribiendo los cuerpos grandes por
/// segmentos para evitar el límite de un único valor UTF-16 del escritor.
/// No cambia el texto, las opciones de escape ni el formato persistido.
/// </summary>
public sealed class MYGTextoJsonLargoConverter : JsonConverter<string>
{
    private const int CaracteresPorSegmento = 64 * 1024;

    public override string? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.Null) return null;
        if (reader.TokenType != JsonTokenType.String)
            throw new JsonException("El cuerpo guardado de colaboración debe ser una cadena JSON.");
        return reader.GetString();
    }

    public override void Write(Utf8JsonWriter writer, string value, JsonSerializerOptions options)
    {
        if (value is null) { writer.WriteNullValue(); return; }
        if (value.Length <= CaracteresPorSegmento) { writer.WriteStringValue(value); return; }
        int posicion = 0;
        while (posicion < value.Length)
        {
            int cantidad = Math.Min(CaracteresPorSegmento, value.Length - posicion);
            // Mantener cada par UTF-16 unido, también en el borde de un segmento.
            if (posicion + cantidad < value.Length
                && char.IsHighSurrogate(value[posicion + cantidad - 1])
                && char.IsLowSurrogate(value[posicion + cantidad])) cantidad--;
            writer.WriteStringValueSegment(value.AsSpan(posicion, cantidad),
                isFinalSegment: posicion + cantidad == value.Length);
            posicion += cantidad;
        }
    }
}
