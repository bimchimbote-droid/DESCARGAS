using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class AperturaPaqueteGrandeCheck
{
    // Longitud exacta del error observado al abrir la publicación del usuario.
    private const int CaracteresCasoReal = 209786487;
    private static readonly Guid ProyectoId = Guid.Parse("8630a941-3cf1-40ed-9616-c9b463ef48c7");
    private static readonly Guid UsuarioId = Guid.Parse("3da5bf6a-d71c-4b0d-8958-0d547c4293f9");
    private static int _comprobaciones;

    internal static Task RunAsync()
    {
        _comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-apertura-grande-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            ParidadDelFormato();
            Console.WriteLine("OK Cadenas JSON: mismos bytes, Unicode, escapes, bordes y siete campos duraderos.");
            AperturaGrande(carpeta);
            Console.WriteLine("OK Apertura de 209786487 caracteres: reproducción anterior, descarga SQLite, vínculo y reapertura íntegros.");
            ColaYConflictos(carpeta);
            Console.WriteLine("OK Cola: recuperación, UUID y cuerpos inmutables, ACK y conflictos conservados.");
            RollbackEscritorYPermisos(carpeta);
            Console.WriteLine($"OK Apertura grande: {_comprobaciones} comprobaciones locales; rollback, escritor obsoleto y permisos conservados. Sin red.");
            return Task.CompletedTask;
        }
        finally
        {
            Directory.Delete(carpeta, true);
        }
    }

    private static void Exigir(bool condicion, string detalle)
    {
        _comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Apertura grande: " + detalle);
    }

    private static void ParidadDelFormato()
    {
        string[] textos =
        [
            "", "Español, 漢字, 😀, \\\"\r\n\t\0 <>&",
            new string('a', 65535) + "😀\\\"\nfin",
            new string('a', 65536) + "😀\\\"\nfin",
            new string('a', 131071) + "😀fin",
            new string('a', 65535) + '\uD800' + "x\uDC00",
            new string('a', 1048575) + "😀fin"
        ];
        foreach (JavaScriptEncoder encoder in new[] { JavaScriptEncoder.Default, JavaScriptEncoder.UnsafeRelaxedJsonEscaping })
        foreach (bool indentado in new[] { false, true })
        {
            var opciones = new JsonSerializerOptions { Encoder = encoder, WriteIndented = indentado };
            foreach (string texto in textos)
            {
                string anterior = JsonSerializer.Serialize(new TextoAnterior { Texto = texto }, opciones);
                string actual = JsonSerializer.Serialize(new TextoSegmentado { Texto = texto }, opciones);
                Exigir(actual == anterior, "El escritor segmentado cambió bytes o escapes de un estado anterior.");
                // El lector de .NET normaliza los UTF-16 incompletos igual que el escritor anterior.
                string? esperado = JsonSerializer.Deserialize<TextoAnterior>(anterior, opciones)!.Texto;
                Exigir(JsonSerializer.Deserialize<TextoSegmentado>(actual, opciones)!.Texto == esperado,
                    "El lector segmentado alteró el valor serializado.");
            }
            Exigir(JsonSerializer.Serialize(new TextoSegmentado { Texto = null }, opciones)
                == JsonSerializer.Serialize(new TextoAnterior { Texto = null }, opciones), "Cambió el formato null anterior.");
        }

        bool rechazoTipo = false;
        try { JsonSerializer.Deserialize<TextoSegmentado>("{\"Texto\":123}"); }
        catch (JsonException) { rechazoTipo = true; }
        Exigir(rechazoTipo, "Un estado con un cuerpo de tipo distinto de cadena fue aceptado.");

        string cuerpo = new string('b', 65535) + "😀\"\\\n" + new string('c', 65536);
        var vinculo = new MYGVinculoNube
        {
            JsonConfirmado = cuerpo, JsonPaqueteConfirmado = cuerpo,
            JsonRemotoConflicto = cuerpo, JsonPaqueteConflicto = cuerpo, JsonBorrador = cuerpo,
            Pendiente = new MYGOperacionNube { JsonContenido = cuerpo, JsonCambios = cuerpo }
        };
        var copia = JsonSerializer.Deserialize<MYGVinculoNube>(JsonSerializer.Serialize(vinculo))!;
        Exigir(new[] { copia.JsonConfirmado, copia.JsonPaqueteConfirmado, copia.JsonRemotoConflicto,
            copia.JsonPaqueteConflicto, copia.JsonBorrador, copia.Pendiente.JsonContenido, copia.Pendiente.JsonCambios }
            .All(x => x == cuerpo), "Algún cuerpo del vínculo o pendiente cambió al persistirse.");
    }

    private static void AperturaGrande(string carpeta)
    {
        var documento = MYGProyectoStorage.Nuevo("Apertura grande de regresión");
        var paquete = CrearPaqueteGrande(documento);
        Exigir(paquete.Json.Length == CaracteresCasoReal, "El caso no reproduce la longitud exacta del error.");
        bool falloAnterior = false;
        try { JsonSerializer.Serialize(new { JsonPaqueteConfirmado = paquete.Json }); }
        catch (ArgumentException ex)
        {
            falloAnterior = ex.Message.Contains(CaracteresCasoReal.ToString(CultureInfo.InvariantCulture), StringComparison.Ordinal)
                && ex.Message.Contains("too large", StringComparison.OrdinalIgnoreCase);
        }
        Exigir(falloAnterior, "El escritor anterior no reprodujo el error de longitud observado.");

        string sha = HashTexto(paquete.Json);
        string ruta = Path.Combine(carpeta, "apertura-200mib.sqlite");
        Descargar(paquete.Json, ruta);
        var local = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        Exigir(local.Id == documento.Id && local.Nombre == documento.Nombre,
            "La materialización cambió la identidad o el documento del paquete.");
        Exigir(Convert.ToInt64(Consultar(ruta, "SELECT COUNT(*) FROM catalogo_unidad WHERE id LIKE 'NUBE%'")) == paquete.Filas,
            "La materialización perdió filas nativas del paquete grande.");
        Exigir(Convert.ToInt64(Consultar(ruta, "SELECT SUM(length(descripcion)) FROM catalogo_unidad WHERE id LIKE 'NUBE%'"))
            == paquete.CaracteresNativos, "La materialización truncó las celdas nativas del paquete.");
        Exigir((string?)Consultar(ruta, "PRAGMA integrity_check") == "ok", "La descarga produjo una SQLite dañada.");

        var vinculo = Vinculo(local, paquete.Json);
        MYGColaboracionLocal.Vincular(ruta, local, vinculo);
        Exigir(vinculo.ProyectoId == ProyectoId && vinculo.Revision == 7 && vinculo.Pendiente is null,
            "Vincular el paquete cambió UUID, revisión o generó una edición falsa.");
        Exigir((string?)Consultar(ruta, "SELECT json_type(json_vinculo,'$.JsonPaqueteConfirmado') FROM myg_colaboracion_local") == "text",
            "Cambió el formato persistido: el paquete debe seguir siendo una cadena JSON.");
        ReabrirYGuardar(ruta, local.Id, sha);
        VerificarSnapshot(ruta, local.Id, sha);
    }

    private static void Descargar(string json, string ruta)
    {
        using var contenido = JsonDocument.Parse(json, new JsonDocumentOptions { MaxDepth = 128 });
        PaqueteNube.Descargar(contenido.RootElement, ruta);
    }

    private static void ReabrirYGuardar(string ruta, string id, string sha)
    {
        var documento = MYGBaseDatos.LeerProyecto(ruta, id);
        var vinculo = MYGColaboracionLocal.Leer(ruta, id);
        Exigir(HashTexto(vinculo.JsonPaqueteConfirmado) == sha, "Reabrir cambió bytes del paquete confirmado.");
        Exigir(vinculo.ProyectoId == ProyectoId && vinculo.UsuarioId == UsuarioId.ToString("D") && vinculo.Revision == 7,
            "Reabrir cambió identidad, cuenta o revisión del proyecto.");
        Exigir(vinculo.PermisosModulos is { Acu: true, Especificaciones: false, MetradosExcel: true },
            "Reabrir amplió o perdió los permisos de módulos.");
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        Exigir(vinculo.Pendiente is null && vinculo.Estado == "Sincronizado", "Guardar el proyecto abierto produjo un pendiente falso.");
    }

    private static void VerificarSnapshot(string ruta, string id, string sha)
    {
        var vinculo = MYGColaboracionLocal.Leer(ruta, id);
        Exigir(vinculo.JsonPaqueteConfirmado.Length == CaracteresCasoReal && HashTexto(vinculo.JsonPaqueteConfirmado) == sha,
            "Guardar y volver a abrir truncó o modificó el paquete grande.");
    }

    private static void ColaYConflictos(string carpeta)
    {
        string ruta = Path.Combine(carpeta, "cola.sqlite");
        var documento = MYGProyectoStorage.Nuevo("Base confirmada");
        var vinculo = Vinculo(documento, PaquetePequeno(documento));
        MYGColaboracionLocal.Vincular(ruta, documento, vinculo);
        documento.Nombre = "Primer cambio local";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        string cuerpo = PaquetePequeno(documento);
        string cambios = "{\"texto\":\"" + new string('z', 65537) + "\"}";
        MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, cuerpo, cambios);
        Guid operacion = vinculo.Pendiente!.Id;

        documento = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        vinculo = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exigir(vinculo.Pendiente.Id == operacion && vinculo.Pendiente.Enviada && vinculo.Pendiente.RevisionBase == 7
            && vinculo.Pendiente.JsonContenido == cuerpo && vinculo.Pendiente.JsonCambios == cambios,
            "Recuperar el pendiente alteró UUID, revisión, contenido o protocolo.");
        documento.Nombre = "Borrador posterior al envío";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, cuerpo, cambios);
        Exigir(vinculo.Pendiente.Id == operacion && vinculo.Pendiente.JsonContenido == cuerpo && vinculo.Pendiente.JsonCambios == cambios,
            "El reintento o borrador posterior modificó el cuerpo congelado.");
        Rechaza<InvalidOperationException>(() => MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, cuerpo + " ", cambios),
            "Se permitió cambiar bytes de una operación enviada.");
        Rechaza<InvalidOperationException>(() => MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, cuerpo, cambios + " "),
            "Se permitió cambiar el protocolo congelado de un reintento.");
        Exigir(MYGColaboracionLocal.Leer(ruta, documento.Id).Pendiente.Id == operacion,
            "Un reintento rechazado alteró la operación duradera.");
        MYGColaboracionLocal.Confirmar(ruta, documento, vinculo, operacion, 8);
        Exigir(vinculo.Revision == 8 && vinculo.Pendiente is not null && vinculo.Pendiente.Id != operacion
            && vinculo.Pendiente.RevisionBase == 8 && MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == documento.Nombre,
            "El ACK borró el borrador posterior o no preparó su siguiente operación.");

        Guid pendienteLocal = vinculo.Pendiente!.Id;
        var remoto = MYGProyectoStorage.Copia(documento);
        remoto.Nombre = "Documento remoto en conflicto";
        string paqueteRemoto = PaquetePequeno(remoto);
        vinculo.JsonPaqueteConflicto = paqueteRemoto;
        MYGColaboracionLocal.RegistrarConflicto(ruta, documento, vinculo, 9, MYGColaboracionLocal.ExportarDocumento(remoto));
        vinculo = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exigir(vinculo.Revision == 8 && vinculo.RevisionRemotaConflicto == 9 && vinculo.Pendiente.Id == pendienteLocal
            && vinculo.JsonPaqueteConflicto == paqueteRemoto, "Registrar y recuperar el conflicto perdió el pendiente o paquete remoto.");
        MYGColaboracionLocal.ResolverConflictoMantenerLocal(ruta, documento, vinculo);
        Exigir(vinculo.Revision == 9 && vinculo.JsonPaqueteConfirmado == paqueteRemoto && vinculo.Pendiente is not null
            && vinculo.Pendiente.Id != pendienteLocal && vinculo.Pendiente.RevisionBase == 9 && vinculo.JsonPaqueteConflicto is null,
            "Mantener la edición local no adoptó la base remota ni renovó la operación.");
        remoto.Nombre = "Nueva versión remota adoptada";
        paqueteRemoto = PaquetePequeno(remoto);
        vinculo.JsonPaqueteConflicto = paqueteRemoto;
        MYGColaboracionLocal.RegistrarConflicto(ruta, documento, vinculo, 10, MYGColaboracionLocal.ExportarDocumento(remoto));
        var adoptado = MYGColaboracionLocal.ResolverConflictoUsarRemoto(ruta, vinculo);
        Exigir(adoptado.Nombre == remoto.Nombre && vinculo.Revision == 10 && vinculo.Pendiente is null
            && vinculo.JsonPaqueteConfirmado == paqueteRemoto && MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == remoto.Nombre,
            "Adoptar la versión remota no conservó documento, paquete y revisión juntos.");
    }

    private static void RollbackEscritorYPermisos(string carpeta)
    {
        string ruta = Path.Combine(carpeta, "atomicidad.sqlite");
        var documento = MYGProyectoStorage.Nuevo("Documento previo al fallo");
        var vinculo = Vinculo(documento, PaquetePequeno(documento));
        MYGColaboracionLocal.Vincular(ruta, documento, vinculo);
        var obsoleto = MYGColaboracionLocal.Leer(ruta, documento.Id);
        string borradorAnterior = vinculo.JsonBorrador;
        string snapshotAnterior = vinculo.JsonPaqueteConfirmado;
        Ejecutar(ruta, "CREATE TRIGGER prueba_rechazar_vinculo BEFORE UPDATE ON myg_colaboracion_local BEGIN SELECT RAISE(ABORT,'fallo transaccional inyectado'); END");
        documento.Nombre = "Cambio después del fallo";
        Rechaza<SqliteException>(() => MYGColaboracionLocal.Guardar(ruta, documento, vinculo), "El fallo transaccional no se produjo.");
        Exigir(vinculo.Pendiente is null && vinculo.JsonBorrador == borradorAnterior && vinculo.JsonPaqueteConfirmado == snapshotAnterior,
            "El rollback filtró mutaciones del clon al vínculo en memoria.");
        Exigir(MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == "Documento previo al fallo"
            && MYGColaboracionLocal.Leer(ruta, documento.Id).Pendiente is null,
            "El fallo del vínculo dejó una confirmación parcial del documento o pendiente.");
        Ejecutar(ruta, "DROP TRIGGER prueba_rechazar_vinculo");
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        Guid operacion = vinculo.Pendiente!.Id;
        var otroDocumento = MYGProyectoStorage.Copia(documento);
        otroDocumento.Nombre = "Escritura de ventana antigua";
        Rechaza<InvalidOperationException>(() => MYGColaboracionLocal.Guardar(ruta, otroDocumento, obsoleto),
            "Se permitió sobrescribir el vínculo con una lectura obsoleta.");
        Exigir(MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == documento.Nombre
            && MYGColaboracionLocal.Leer(ruta, documento.Id).Pendiente.Id == operacion,
            "El escritor obsoleto alteró el documento o UUID duraderos.");
        vinculo.Rol = "lector";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        otroDocumento.Nombre = "Edición no autorizada";
        Rechaza<InvalidOperationException>(() => MYGColaboracionLocal.Guardar(ruta, otroDocumento, vinculo),
            "La corrección permitió editar con rol lector.");
        var durable = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exigir(durable.Rol == "lector" && durable.Pendiente.Id == operacion && durable.JsonPaqueteConfirmado == snapshotAnterior
            && durable.PermisosModulos is { Acu: true, Especificaciones: false, MetradosExcel: true },
            "El cambio de permisos perdió el pendiente, snapshot o máscara de módulos.");
    }

    private static MYGVinculoNube Vinculo(MYGProyectoDocumento documento, string paquete) => new()
    {
        ProyectoId = ProyectoId, UsuarioId = UsuarioId.ToString("D"), Servidor = "https://apertura-pruebas.supabase.co",
        Rol = "propietario", Revision = 7, JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento),
        JsonPaqueteConfirmado = paquete,
        PermisosModulos = new() { Acu = true, Especificaciones = false, MetradosExcel = true }
    };

    private static string PaquetePequeno(MYGProyectoDocumento documento) => JsonSerializer.Serialize(new
    {
        formato = "MYG_COLABORACION", version = 1, alcance = "obra", documento,
        documentos = new[] { documento }, tablas = Array.Empty<object>(), recursos = Array.Empty<object>(),
        avisos = new[] { new string('a', 65537) }, exclusiones = "Prueba local"
    }, new JsonSerializerOptions { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping });

    private static (string Json, long Filas, long CaracteresNativos) CrearPaqueteGrande(MYGProyectoDocumento documento)
    {
        const int longitudCelda = 16384;
        string doc = MYGColaboracionLocal.ExportarDocumento(documento);
        string prefijo = "{\"formato\":\"MYG_COLABORACION\",\"version\":1,\"alcance\":\"base\",\"documento\":" + doc
            + ",\"documentos\":[" + doc + "],\"tablas\":[{\"Nombre\":\"catalogo_unidad\",\"Columnas\":[\"id\",\"simbolo\",\"descripcion\"],\"Filas\":[";
        const string filaInicio = "[{\"Tipo\":\"texto\",\"Valor\":\"NUBE";
        const string filaMedio = "\"},{\"Tipo\":\"texto\",\"Valor\":\"m\"},{\"Tipo\":\"texto\",\"Valor\":\"";
        const string filaFin = "\"}]";
        const string sufijo = "]}],\"recursos\":[],\"avisos\":[],\"exclusiones\":\"Prueba local\"}";
        int fijoFila = filaInicio.Length + 8 + filaMedio.Length + filaFin.Length;
        int presupuesto = CaracteresCasoReal - prefijo.Length - sufijo.Length;
        int completas = (presupuesto - fijoFila) / (fijoFila + longitudCelda + 1);
        int ultimaCelda = presupuesto - completas * (fijoFila + longitudCelda + 1) - fijoFila;
        var estado = (prefijo, completas, ultimaCelda);
        string json = string.Create(CaracteresCasoReal, estado, (destino, datos) =>
        {
            int posicion = 0;
            Escribir(destino, ref posicion, datos.prefijo);
            for (int fila = 0; fila <= datos.completas; fila++)
            {
                if (fila > 0) destino[posicion++] = ',';
                Escribir(destino, ref posicion, filaInicio);
                fila.TryFormat(destino.Slice(posicion, 8), out int escritos, "D8", CultureInfo.InvariantCulture);
                posicion += escritos;
                Escribir(destino, ref posicion, filaMedio);
                int caracteres = fila == datos.completas ? datos.ultimaCelda : longitudCelda;
                destino.Slice(posicion, caracteres).Fill('x'); posicion += caracteres;
                Escribir(destino, ref posicion, filaFin);
            }
            Escribir(destino, ref posicion, sufijo);
            if (posicion != destino.Length) throw new InvalidOperationException("La fixture grande no tiene su longitud esperada.");
        });
        return (json, completas + 1L, completas * (long)longitudCelda + ultimaCelda);
    }

    private static void Escribir(Span<char> destino, ref int posicion, ReadOnlySpan<char> valor)
    {
        valor.CopyTo(destino[posicion..]); posicion += valor.Length;
    }

    private static string HashTexto(string texto)
    {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var encoder = Encoding.UTF8.GetEncoder();
        byte[] buffer = new byte[Encoding.UTF8.GetMaxByteCount(65536)];
        for (int posicion = 0; posicion < texto.Length;)
        {
            int cantidad = Math.Min(65536, texto.Length - posicion);
            bool ultimo = posicion + cantidad == texto.Length;
            int escritos = encoder.GetBytes(texto.AsSpan(posicion, cantidad), buffer, ultimo);
            hash.AppendData(buffer.AsSpan(0, escritos)); posicion += cantidad;
        }
        return Convert.ToHexString(hash.GetHashAndReset());
    }

    private static void Rechaza<T>(Action accion, string detalle) where T : Exception
    {
        bool rechazo = false;
        try { accion(); }
        catch (T) { rechazo = true; }
        Exigir(rechazo, detalle);
    }

    private static SqliteConnection Abrir(string ruta)
    {
        var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false }.ToString());
        conexion.Open(); return conexion;
    }

    private static object? Consultar(string ruta, string sql)
    {
        using var conexion = Abrir(ruta);
        using var cmd = conexion.CreateCommand(); cmd.CommandText = sql;
        return cmd.ExecuteScalar();
    }

    private static void Ejecutar(string ruta, string sql)
    {
        using var conexion = Abrir(ruta);
        using var cmd = conexion.CreateCommand(); cmd.CommandText = sql; cmd.ExecuteNonQuery();
    }

    private sealed class TextoAnterior
    {
        public string? Texto { get; set; }
    }

    private sealed class TextoSegmentado
    {
        [JsonConverter(typeof(MYGTextoJsonLargoConverter))]
        public string? Texto { get; set; }
    }
}
