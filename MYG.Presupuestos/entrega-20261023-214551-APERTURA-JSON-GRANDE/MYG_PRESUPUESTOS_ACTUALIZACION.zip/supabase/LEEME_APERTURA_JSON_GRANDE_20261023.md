# Corrección de apertura de proyectos grandes

## A. Resumen de la implementación

El mensaje `The JSON value of length 209786487 is too large and not supported.` se reprodujo en el cliente .NET sin conectar con Supabase. Al abrir el proyecto publicado, la aplicación descomprime el contenido y guarda su estado de recuperación local; escribir sus aproximadamente 200 MiB como una sola cadena JSON supera el límite de entrada del escritor. Cambiar de plan no corrige este defecto.

La corrección escribe los textos por segmentos manteniendo el mismo formato y contenido. Evita también una serialización adicional al copiar el estado transaccional, conserva permisos y operación pendiente, y elimina solo su preparación temporal recién creada si falla la primera apertura. No cambia la compresión ni las funciones instaladas en Supabase.

Esta entrega es incremental sobre la publicación comprimida anterior, ya aplicada para poder publicar. No contiene el repositorio completo, ejecutables ni bases de datos. Los archivos de código se entregan completos.

## B. Archivos y acciones

Rutas relativas a la carpeta que contiene `MYG.Presupuestos.sln`:

| Ruta exacta | Acción | Descripción |
|---|---|---|
| `MYG.Core/TextoJsonLargoMYG.cs` | CREAR | Escritor de cadenas grandes por segmentos, con el formato anterior. |
| `MYG.Core/ColaboracionLocalMYG.cs` | REEMPLAZAR | Aplica el escritor a siete campos duraderos y conserva una copia transaccional independiente. |
| `MYG.Colaboracion/ClienteNubeProyectos.cs` | REEMPLAZAR | Conserva la integración comprimida y aplica el escritor a los textos de RPC. |
| `MYG.Desktop/InicioNube.cs` | REEMPLAZAR | Conserva la publicación comprimida y limpia su preparación temporal fallida. |
| `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Añade el selector de regresión de apertura grande. |
| `MYG.PruebasNube/AperturaPaqueteGrandeCheck.cs` | CREAR | Reproduce el límite y comprueba apertura, integridad, cola, conflictos y permisos. |
| `supabase/CONTINUIDAD_PUBLICACION_COMPRIMIDA.md` | REEMPLAZAR | Estado vigente, decisiones, resultados y siguiente paso, preservando el historial. |
| `supabase/diagnosticos/RESULTADOS_APERTURA_JSON_GRANDE_20261023.json` | CREAR | Resumen verificable de las pruebas locales. No se ejecuta en SQL Editor. |
| `supabase/LEEME_APERTURA_JSON_GRANDE_20261023.md` | CREAR | Esta guía; documento de consulta. |

No hay archivos que eliminar. Los proyectos SDK incluyen automáticamente los dos archivos C# nuevos.

## C. Descarga

ZIP `MYG_PRESUPUESTOS_ACTUALIZACION.zip`, en una carpeta nueva de `bimchimbote-droid/DESCARGAS`. El enlace exacto, commit, tamaño y SHA-256 se comunican al completar su publicación y descarga anónima de comprobación; el registro local queda en `.cloud-setup/myg/apertura-json-grande/entrega/publication.json`. No se sustituyen entregas anteriores.

## D. Instalación

1. Cierra MYG.Presupuestos y Revit si tienen cargada esta aplicación. Conserva una copia de tu carpeta de código y de tus copias locales habituales.
2. Extrae el ZIP. Copia sus carpetas `MYG.Core`, `MYG.Colaboracion`, `MYG.Desktop`, `MYG.PruebasNube` y `supabase` **dentro de la raíz de tu solución**. Acepta reemplazar los archivos indicados. No copies carpetas sobre `%LOCALAPPDATA%` ni sobre las bases de Delphin.
3. En Visual Studio abre `MYG.Presupuestos.sln`, selecciona **Release** y **Compilar → Recompilar solución**. Comprueba que incluye `TextoJsonLargoMYG.cs` y que no hay errores. Copiar fuentes no actualiza un ejecutable que ya estaba instalado.
4. Para comprobar Desktop, ejecuta el resultado recién compilado `MYG.Desktop\bin\Release\net10.0-windows\MYG.Presupuestos.exe`. Si usas el complemento Revit, aplica tu procedimiento habitual de instalación del resultado recompilado, incluyendo las DLL Core y Colaboracion; no mezcles versiones de DLL.
5. Entra en **Nube MYG → Mis proyectos**, selecciona **la obra que ya se publicó** y pulsa **Abrir proyecto**. No hace falta publicar otra vez ni retirar su pendiente.
6. Comprueba la obra y una muestra de sus catálogos/adjuntos. Cierra y vuelve a abrir. Si haces un cambio autorizado, comprueba su guardado y revisión. Conserva tus copias mientras completas esa comprobación real.

## E. Configuración adicional

Se mantiene .NET10, ya utilizado por el proyecto, y las referencias existentes. No se añaden paquetes NuGet ni configuración de acceso. **No ejecutes ningún archivo de esta entrega en Supabase SQL Editor.** SQL28 ya permitió publicar y esta entrega no incluye otra migración. No se cambia el plan de Supabase.

## F. Compilación y validación

- Solución completa Release: cero errores y cero advertencias, con referencias Revit para compilación en este entorno Linux.
- Regresión nueva: **91 comprobaciones**, incluido el rechazo anterior con 209786487 caracteres y el flujo real `PaqueteNube.Descargar → Vincular → Leer → Guardar → reapertura`, filas nativas, SQLite `integrity_check` y SHA idéntico.
- Paridad con el formato anterior, Unicode, escapes, bordes de segmento y los siete campos; recuperación, UUID/cuerpos congelados, ACK con borrador posterior, conflictos local/remoto, permisos, rollback y escritor obsoleto.
- Suite Core: **584 comprobaciones**. Suite nube: **39 grupos y 982 comprobaciones principales**, con sus suites internas de compresión (13 grupos/839) y filas ocupadas55006 (2 casos/116). Los contadores internos no son un total adicional del contrato principal.
- Se repitieron estas regresiones porque cambió la persistencia Core y el escritor común de RPC. No se repitieron benchmarks de servidor ni instalaciones SQL ya validadas.

Comandos opcionales desde la raíz, con .NET10 instalado:

```powershell
dotnet run --project .\MYG.PruebasNube\MYG.PruebasNube.csproj -c Release -- --apertura-paquete-grande
dotnet run --project .\MYG.Pruebas\MYG.Pruebas.csproj -c Release
dotnet run --project .\MYG.PruebasNube\MYG.PruebasNube.csproj -c Release
```

La prueba grande crea un paquete sintético y archivos temporales; no conecta con Supabase ni usa tus datos. Su proceso completo alcanzó aproximadamente 5,8 GiB residentes, incluyendo fixture y verificaciones; no es una medida del mínimo de memoria de la aplicación ni de Supabase. No necesitas repetirla para instalar la corrección.

## G. Publicación del código en GitHub

Se publica únicamente el ZIP en DESCARGAS. No se hace Commit ni Push automático a `MYG.Presupuestos`. Después de aplicar y probar, abre **Cambios de Git** en Visual Studio, verifica el repositorio y tu rama de trabajo, revisa los archivos, haz Commit y luego Push; comprueba el commit en GitHub. Conserva y revisa los demás cambios previos, sin descartarlos para aplicar esta entrega.

## H. Limitaciones y siguiente paso

La prueba usa .NET/SQLite reales y HTTP simulado. No se ejecutó la interfaz Windows/Revit ni se abrió aquí el proyecto privado del usuario. Queda comprobar esa apertura con el ejecutable actualizado y el Storage real. El proyecto de nube y su contenido no se modificaron desde este entorno.

Esta corrección resuelve el rechazo local reproducido. Los HTTP502/520 anteriores, los errores de archivado WAL y las dos recuperaciones tras cierres no limpios siguen sin causa demostrada; no se atribuyen a memoria, al plan Free ni entre sí. Si reaparecen después de actualizar, el nuevo diagnóstico debe distinguir su fase de este mensaje local. No repetir preguntas ya respondidas ni reinstalar parches por el error de cadena JSON.
