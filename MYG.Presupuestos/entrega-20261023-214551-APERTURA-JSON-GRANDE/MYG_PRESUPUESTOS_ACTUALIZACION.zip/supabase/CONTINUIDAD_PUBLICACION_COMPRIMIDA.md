# Continuidad: publicación comprimida

Actualización: 23/10/2026, zona America/Lima. El usuario ya confirmó publicación comprimida visible en Mis proyectos. La corrección siguiente de apertura local está implementada y validada; falta aplicarla en su equipo. Supabase real no se administra desde este entorno.

## Estado vigente: error local al abrir 209786487 caracteres

Esta sección prevalece sobre los siguientes pasos históricos de las entregas anteriores. No reinstalar SQL28 ni volver a publicar la obra por esta incidencia.

El usuario ya ve su proyecto publicado, pero Abrir muestra `The JSON value of length 209786487 is too large and not supported.` Se reprodujo exactamente ese rechazo con el escritor JSON predeterminado de .NET, sin Supabase. Al abrir, `MYGColaboracionLocal.Vincular` conserva `JsonPaqueteConfirmado` como una cadena dentro del estado local; su clon por serialización y la escritura posterior pasaban el texto entero a `Utf8JsonWriter.WriteStringValue`. El Gzip reduce el transporte, pero al materializar vuelve a existir el JSON completo. Este error concreto corresponde al cliente; no demuestra una limitación del plan Free ni agotamiento de memoria del servidor.

Corrección: `MYG.Core/TextoJsonLargoMYG.cs` escribe la misma cadena por segmentos de 64 Ki caracteres mediante la API .NET10 `WriteStringValueSegment`, conservando escapes y pares UTF-16. Se aplica a los siete textos grandes de vínculo/operación. El clon transaccional copia los textos inmutables por referencia y separa permisos/operación mutables. No cambia esquema SQLite, forma del JSON, UUID, revisión ni control de concurrencia. `ClienteNubeProyectos.cs` usa el mismo converter para los textos anterior/nuevo del editor restringido. `InicioNube.cs` limpia exclusivamente su archivo temporal nuevo si falla la primera apertura, sin tocar la copia de trabajo existente.

Pruebas nuevas: selector `--apertura-paquete-grande` en `MYG.PruebasNube/Program.cs`, implementación en `AperturaPaqueteGrandeCheck.cs`. **91 comprobaciones aprobadas**: reproducción exacta del rechazo anterior; paquete sintético válido de 209786487 caracteres con filas nativas pequeñas; materialización SQLite, Vincular, Leer, Guardar y reapertura con SHA idéntico, integridad SQLite e identidad/revisión/permisos; paridad de bytes Unicode/escapes/UTF-16 incompleto/bordes, siete campos, compatibilidad anterior, pendiente congelado, recuperación/ACK, ambas resoluciones de conflicto, rollback, escritor obsoleto y rol lector. El proceso de prueba completo tuvo un máximo residente de 6116956 KiB; incluye fixture y verificaciones y no mide el mínimo de RAM de la aplicación ni el servidor.

Regresión adicional necesaria por cambiar la persistencia Core y las opciones comunes RPC: **584 comprobaciones Core aprobadas**, **39 grupos/982 comprobaciones principales de nube aprobadas**, incluyendo sub-suite comprimida 13 grupos/839 y cliente55006 2 casos/116. No sumar contadores internos como si fueran el total principal. Solución completa Release .NET10: **0 errores/0 advertencias**. La primera compilación de la prueba tuvo una advertencia nullable, corregida antes de la compilación final; no cambió su lógica. Revisión independiente de converter/copia/compatibilidad sin defectos demostrables.

Evidencia: `/workspace/.cloud-setup/myg/apertura-json-grande/{prueba-200mib.log,prueba-200mib.json,pruebas-core.log,pruebas-nube.log,build-solucion.log}`. Resumen transportable: `supabase/diagnosticos/RESULTADOS_APERTURA_JSON_GRANDE_20261023.json`. No se repitieron los benchmarks PostgreSQL/PostgREST, las matrices de permisos SQL ni las pruebas de instalación ya aprobadas. No se usó ni publicó el proyecto privado.

Siguiente paso concreto: finalizar/publicar únicamente el ZIP incremental descrito en `supabase/LEEME_APERTURA_JSON_GRANDE_20261023.md`; registro de entrega en `/workspace/.cloud-setup/myg/apertura-json-grande/entrega/{manifest.json,publication.json}`. Si `download_verified=true`, utilizar ese enlace y no regenerar la entrega ni repetir estas suites. El usuario debe reemplazar/crear sus nueve archivos, recompilar y ejecutar la aplicación actualizada, seleccionar la obra ya publicada y abrirla. No retirar el pendiente, borrar copias locales ni crear una publicación distinta. Comprobar después apertura y guardado reales en Windows/Revit y Storage gestionado: aquí se probaron .NET/SQLite reales y HTTP simulado, no su GUI ni su obra privada. Los HTTP502/520, WAL y cierres no limpios históricos siguen sin causa demostrada y son una investigación distinta.

## Decisiones resueltas

- La prueba aportada por el usuario indica 209.835.827 bytes JSON → 29.868.974 bytes Gzip (200,1 → 28,5 MiB), con SHA-256 de ida y vuelta idéntico. No se dispone aquí de su proyecto privado para repetirla.
- Bucket privado nuevo `myg-nube-paquetes`; Gzip dividido en partes inmutables de hasta 8 MiB. PostgreSQL conserva un manifiesto pequeño. No enviar Gzip directamente a una RPC JSON.
- Creación y guardado con los tres módulos habilitados usan manifiestos pequeños. Un editor con módulos restringidos envía además los textos anterior/nuevo: el servidor verifica sus hashes y conserva `validar_contenido` y `exigir_modulos`. Esta ruta conserva un coste JSONB significativo; no se relajan permisos para ocultarlo.
- Modo de almacenamiento inmutable por proyecto. Los proyectos JSON existentes continúan en JSON. Las RPC antiguas rechazan proyectos comprimidos con `MGC01`.
- La cola durable y el pendiente local conservan JSON, UUID y revisión. Reintentar no requiere retirar ni recrear la publicación. El transporte no modifica el SQLite original.
- La idempotencia identifica el JSON por SHA-256/longitud; no exige que dos versiones del compresor generen el mismo Gzip. Se conserva siempre el primer snapshot confirmado.
- Los adjuntos se hidratan mediante acceso autorizado y SHA, y quedan dentro del Gzip con `Almacen` vacío. La nueva ruta no depende de vincular referencias ocultas al bucket anterior; no se inventó ni reemplazó el validador productivo ausente del repositorio.
- Las entradas directas de creación/guardado de más de 127 MiB negocian capacidades antes de construir una RPC grande. La apertura desde sesión nueva descubre el formato mediante el rechazo seguro `MGC01`; los clientes anteriores permanecen compatibles con sus proyectos JSON.
- Límite lógico 300 MiB; comprimido 320 MiB; máximo 40 partes. Apertura verifica rutas, tamaño, hashes de cada parte, Gzip y JSON antes de materializar.
- El parche 27 ya está instalado y confirmado por el usuario. No volver a ejecutar 26 encima de 27. Los HTTP 502/520 y las interrupciones reales siguen sin causa demostrada; esta implementación evita el gran JSONB en la ruta de publicación y no demuestra su causa histórica.

## Avance recuperado

Código nuevo existente: `MYG.Colaboracion/PaqueteComprimidoNube.cs`, `ClienteNubeComprimida.cs`, `MYG.PruebasNube/PublicacionComprimidaCheck.cs`; migración y regresión SQL `20261028_publicacion_comprimida.sql`, `publicacion_comprimida.sql`; runner `scripts/pruebas/Probar-PublicacionComprimidaHTTP.py`.

Intercepciones ya escritas en cliente de publicación/apertura/guardado/cambios/capacidades/diagnóstico, `MYG.Desktop/InicioNube.cs` y selector de pruebas. Se conservan los demás cambios previos de `git status`; no restaurarlos ni borrarlos.

## Validaciones de esta implementación

- `build-solucion-final.log`: solución completa Release .NET 10.0.100, incluidos Desktop/Revit y pruebas; cero errores y advertencias.
- `pruebas-nube-final.log`: 39 grupos principales, 982 comprobaciones del contrato principal y las suites de integración detalladas en el log. La suite comprimida final aprobó 13 grupos/839 comprobaciones; no sumar los contadores internos como si fueran el contador principal.
- `http/validacion4/results.json`: 904 comprobaciones, 23 SQL, 514 RPC; 120 combinaciones (15 mutaciones × ocho máscaras). Carga sintética 209.835.827 bytes → 158.953.409 Gzip, 19 partes, roundtrip exacto. RPC crear 4.899 bytes, ACK 273; abrir 47 bytes, manifiesto 5.197. Esta tasa sintética no corresponde al reporte privado 200,1 → 28,5 MiB.
- `http/adicionales5/results.json`: 119 comprobaciones adicionales, 45 RPC; no se repitieron ni la carga grande ni la matriz. NOWAIT real crear 3,4 ms/guardar 1,7 ms, código 55006. Textos SHA falsos, manifiesto ajeno, revocación, preservación de trigger/COMMENT y cuerpos CRLF comprobados. Los 23 checks SQL se revalidaron al cambiar el instalador; siguen siendo 23 casos.
- PostgreSQL y PostgREST reales, con 512 MiB independientes; sin OOM registrado en PostgreSQL y sin terminación/reinicio observado en PostgREST durante la prueba. Storage de blobs emulado; tabla de metadatos y RLS reales. No equivale a probar la infraestructura Nano gestionada.
- Fallos iniciales de preparación/instrumentación conservados: permisos de copia del fixture, MD5 inicial del instalador y lectura cgroup distroless. No se trataron como defectos ni como pruebas aprobadas del servicio real.
- Defectos corregidos: manejo de Duplicate Storage 400/409 sin doble lectura de stream, revocación del uploader, replay tras cambiar máscaras, ACK inicial/historial, retorno autocontenido de la API genérica y negociación previa al guardado grande desde sesión nueva.
- De 31 archivos de entregas anteriores, 27 mantienen su SHA; cuatro fuentes se ampliaron intencionalmente para la integración. Los demás cambios del usuario no se restauraron ni eliminaron.

Resultados y logs se guardan fuera del repositorio en `/workspace/.cloud-setup/myg/implementacion-compresion/`. El estado inicial de los archivos está en `estado-inicial-integracion.json`. Los ensayos antiguos siguen en `investigacion-nano`; no repetir sus benchmarks de JSON grande.

## Próximo paso concreto

Las instrucciones y la tabla exacta de los 21 archivos están en `supabase/LEEME_PUBLICACION_COMPRIMIDA.md`. El resumen transportable está en `supabase/diagnosticos/RESULTADOS_PUBLICACION_COMPRIMIDA.json`.

La publicación del ZIP se registra después de crearlo en `/workspace/.cloud-setup/myg/implementacion-compresion/entrega/manifest.json` y `publication.json`. Si este último confirma `download_verified: true`, no volver a publicar ni repetir las suites: comunicar el enlace y proceder a la comprobación manual. Si falta, completar solamente publicación/descarga/verificación de esa entrega. No publicar código en `MYG.Presupuestos` automáticamente.

El siguiente paso funcional corresponde a Supabase real: ejecutar **solo 28**, compilar la aplicación actualizada y reintentar el pendiente existente sin retirarlo ni cambiar su UUID. Comprobar apertura, copia descargada, guardado y colaboración. Windows/Revit visual y Storage real siguen pendientes del usuario. Los HTTP 502/520, cierres no limpios y WAL históricos no tienen causa demostrada; si persisten, correlacionar fase/RPC/HTTP/referencia/hora con los logs y métricas del nuevo intento, sin repetir las preguntas anteriores ni atribuir OOM sin evidencia.

## Incidencia posterior a la entrega: instalación sin confirmar

El usuario mostró `Failed to run sql query: Connection terminated due to connection timeout` en SQL Editor al instalar 28. No confirma ejecución, COMMIT ni rollback. El mensaje de éxito del instalador precede al COMMIT; una pérdida de respuesta exige comprobar el estado desde otra consulta. No hay evidencia nueva de OOM, bloqueo específico ni causalidad con los HTTP anteriores.

Una segunda captura muestra el aviso antiguo «El paquete guardado ocupa 200.1 MiB y supera 127 MiB». Los 200,1 MiB del JSON pendiente local se conservan por diseño; no prueban el tamaño transferido. El texto antiguo puede corresponder al ejecutable previo o a la rama con capacidad comprimida deshabilitada/no detectada. No se ha identificado cuál de esos casos ocurre en el equipo del usuario.

Siguiente comprobación pendiente: ejecutar la consulta pequeña y de solo lectura `supabase/diagnosticos/20261028_estado_instalacion_comprimida.sql` en una pestaña nueva. No volver a instalar ni reenviar el paquete grande antes de conocer esos resultados. Si vuelve a fallar la conexión del editor, investigar esa ruta de conexión; si los componentes aparecen, comprobar a continuación la capacidad efectiva y el ejecutable actualizado. No borrar el pendiente ni cambiar su identificador.

No se modificó el instalador ni el cliente por estas capturas, ni se repitieron compilaciones o benchmarks. El ZIP original publicado conserva sus bytes y su verificación de entrega; este diagnóstico y esta nota se añadieron después.

Resultado posterior confirmado por captura del usuario: `rpc_crear=false`, `rpc_abrir=false`, `rpc_guardar=false`, `capacidad_compresion=false`, `bucket_privado=false`. La consulta nueva sí obtuvo conexión. Los cinco componentes consultados no son visibles como confirmados en ese instante; esto no identifica el motivo del timeout anterior ni excluye por sí solo una ejecución todavía abierta.

Siguiente paso: cerrar MYG para evitar publicaciones simultáneas y ejecutar una sola vez el archivo completo de la migración 28 en una consulta nueva, sin seleccionar únicamente sus líneas finales. El instalador existente ya fue probado como repetible; no se cambia código ni se repiten benchmarks por este resultado. Después de que termine, verificar desde otra consulta que los cinco indicadores sean `true`, y abrir la aplicación recién compilada para renovar su caché de capacidades. Si vuelve a perder la conexión, no encadenar más instalaciones: recuperar estado de sesiones/bloqueos y el error/hora del intento nuevo antes de continuar. No repetir 26/27 ni borrar el pendiente.

## Nuevo resultado: incompatibilidad concreta del trigger de adjuntos

El siguiente intento del usuario devolvió `ERROR: P0001: Trigger de adjuntos desconocido. No se modificó su función. CONTEXT: PL/pgSQL function inline_code_block line 9 at RAISE`. Ahora hay un rechazo SQL explícito del bloque `$adjuntos$`, distinto del timeout anterior. La instalación completa en su transacción se aborta; no retirar la protección para forzarla.

La guarda comprueba cuatro aspectos: OID de `myg_nube_privado.validar_paquete_archivos()`, `tgtype=23` (BEFORE ROW INSERT/UPDATE), cero argumentos y ninguna lista UPDATE OF. Ese mensaje no identifica cuál difiere. Un WHEN personalizado produce otro mensaje posterior, todavía no demostrado. No asumir AFTER, UPDATE OF ni función distinta sin leer el catálogo productivo.

Próximo paso concreto: ejecutar `supabase/diagnosticos/20261028_trigger_adjuntos_solo_lectura.sql` y recuperar su única fila. Muestra identidad de función, coincidencia, tipo, cantidad de argumentos, columnas y flags; omite el cuerpo de función y valores de argumentos. Con ese resultado se adapta y verifica solo la variante real, conservando eventos/columnas/función/ACL/estado/comentario y permisos existentes. El instalador 28 no se ha modificado todavía y no se repitieron las suites aprobadas.

## Estado actual: variante UPDATE OF identificada y corregida

La nueva captura del usuario confirmó `funcion_coincide=true`, `tipo=23`, `numero_argumentos=0`, `columnas_update='6 7'`, `tiene_condicion=false`, `habilitado='O'`. El único rechazo de la guarda anterior corresponde a la lista UPDATE OF; no es necesario solicitar de nuevo metadatos ni el cuerpo de la función productiva.

Se corrigió únicamente el bloque adaptador de `supabase/migraciones/20261028_publicacion_comprimida.sql`: acepta la lista UPDATE OF y la conserva mediante la definición existente; añade una comprobación posterior de eventos/columnas/función/argumentos/estado/comentario. Las demás secciones SQL (RPC, permisos, Storage, CAS, recuperación) mantienen exactamente sus bytes de la entrega original. SHA-256 del instalador corregido: `c65551b548300cdcb19b7b7a3662236c5da7de10554428828e7347faad5540df`.

El selector nuevo `--solo-trigger` de `scripts/pruebas/Probar-PublicacionComprimidaHTTP.py` aprobó **27 comprobaciones** en PostgreSQL17, creando la variante 6/7 antes de la primera instalación. Comprobó instalación y repetición, función/OID/cuerpo/ACL/estado/comentario intactos, disparo de INSERT/UPDATE filtrados, omisión de columnas ajenas, creación/guardado comprimidos y rechazo sin mutaciones de otra función/tipo/argumentos/WHEN. Su cuerpo de función es un contador sintético; no se probó el validador productivo ausente.

Evidencia nueva: `/workspace/.cloud-setup/myg/implementacion-compresion/update-of-trigger/{results.json,fuentes-validadas.json}` y `/workspace/.cloud-setup/myg/implementacion-compresion/correccion-update-of/revision-cambio.json`. Resumen entregable: `supabase/diagnosticos/RESULTADOS_CORRECCION_TRIGGER_20261028.json`. Los 15 archivos C# siguen coincidiendo con los SHA de la entrega original. No se repitieron compilaciones, matrices de permisos ni benchmarks grandes. No quedan contenedores activos.

Entrega correctiva de cinco archivos descrita en `supabase/LEEME_CORRECCION_TRIGGER_20261028.md`. La publicación/descarga se registra después de crear el ZIP en `/workspace/.cloud-setup/myg/implementacion-compresion/correccion-update-of/entrega/{manifest.json,publication.json}`. Si `download_verified=true`, no volver a publicar ni repetir pruebas: usar ese enlace. El ZIP original de 21 archivos permanece disponible pero su SQL28 debe sustituirse por el corregido.

Siguiente paso concreto del usuario: ejecutar completo **solo el SQL28 corregido**, comprobar los cinco indicadores desde otra consulta y abrir la aplicación actualizada anterior para renovar capacidades. Reintentar el mismo pendiente sin borrarlo ni cambiar su UUID. Instalación real y envío de la obra privada siguen pendientes; esta corrección identifica el rechazo UPDATE OF, no la causa de los HTTP502/520 ni el timeout anterior.

## Resultado posterior: definición de snapshot distinta

El usuario ejecutó el instalador corregido y obtuvo `P0001: La función myg_nube_privado.snapshot(uuid,uuid) contiene una personalización desconocida; se conserva intacta. CONTEXT: PL/pgSQL function inline_code_block line 32 at RAISE`. La guarda UPDATE OF fue superada, pero la transacción de instalación vuelve a abortar en `$funciones_existentes$`; no considerar 28 instalado ni volver a usar la versión antigua del trigger.

Esa guarda compara el cuerpo literal tras normalizar CRLF y recortar los extremos. La diferencia podría ser de formato o de lógica: la causa exacta todavía requiere el cuerpo real. Se revisaron los archivos adjuntos existentes: el diagnóstico de producción contiene metadatos de otras RPC, pero no incluye el cuerpo de snapshot ni las cinco definiciones necesarias. No hay acceso directo al servidor para recuperarlas.

Siguiente paso pendiente: usuario ejecuta `supabase/diagnosticos/20261028_funciones_instalador_solo_lectura.sql` y exporta sus cinco filas como JSON completo. Incluye snapshot, capacidades, guardar, guardar_cambios y reconstruir_revision, con lenguaje/seguridad/huella/definición SQL; no consulta filas de obras. Revisar juntas esas definiciones antes de otro parche para conservar la lógica productiva y evitar descubrir incompatibilidades una por una. No quitar las guardas ni sustituir funciones desconocidas o renombrarlas a ciegas.

No se cambiaron de nuevo ni el instalador ni el cliente; no se repitieron pruebas aprobadas. Las nuevas adiciones tras el último ZIP son únicamente este diagnóstico y esta nota. El ZIP correctivo UPDATE OF sigue verificado en su registro de entrega y resuelve exclusivamente esa primera incompatibilidad.

## Definiciones reales recibidas: coincidencia y fallo de finales Windows

El usuario aportó las cinco definiciones en `/workspace/attachments/db92d954-ee8d-4b34-b0c2-1a9e976b9004/Texto pegado.txt`. No volver a pedírselas. Se verificaron los cuerpos completos: todos coinciden exactamente con los esperados al normalizar CRLF a LF. Huellas: snapshot `076e39a2fbe2fce5f71b1e26b6128429`, capacidades `42cfd13eb2449ca9b91643d1c45194c2`, guardar `2be817bb7ff166f548aaa414eac11e1a`, guardar_cambios `f93720e1f5579ff52d8997175cc14a05`, reconstruir_revision `86ee11c5f2710618a474f09ab5f50923`. No hay personalización lógica observada.

Se identificó un defecto del instalador: normalizaba `v_fuente`, pero no `v_esperada` y `v_parcheada`, cuyos literales multilínea heredan los finales CRLF del propio archivo SQL pegado desde Windows. Se corrigió esa comparación normalizando ambos literales antes de comparar; la sustitución posterior sigue conservando los finales originales y los atributos completos de las funciones. Se conservan los plazos reales (guardar120s, guardar_cambios60s) y la corrección UPDATE OF.

SHA-256 del nuevo instalador: `83c44f108e99f8e36d201bca97730b5e83a68bdaaf292ab64744c178c466411e`. Solo cambió el bloque de comparación de funciones; el resto del SQL coincide con la entrega correctiva anterior. Los 15 archivos C# siguen sin cambios. Auditoría y revisión en `/workspace/.cloud-setup/myg/implementacion-compresion/instalador-saltos/{auditoria-definiciones.json,revision-cambio.json}`; no publicar el adjunto completo del usuario.

Verificación terminada: selector focal `--solo-instalador-saltos` del runner, con las definiciones aportadas como entrada local opcional. **122 comprobaciones aprobadas en PostgreSQL17**: reprodujo exactamente el rechazo anterior CRLF y su rollback, mientras el control LF aceptó las mismas funciones. El corregido pasó archivo LF/CRLF × cuerpos LF/CRLF, instalación nueva y repetición, preservación de OID/propietario/ACL/seguridad/configuración (60/120s), cuerpo salvo guarda/capacidad previstas, finales originales y UPDATE OF6/7. Cinco modificaciones reales de lógica siguieron rechazándose sin mutaciones. No se repitieron compilaciones, matriz de120 permisos ni benchmarks200MiB. No quedan contenedores activos.

Evidencia final: `/workspace/.cloud-setup/myg/implementacion-compresion/instalador-saltos/{results.json,fuentes-validadas.json}`. El primer intento tuvo un KeyError de instrumentación por la representación sin esquema public de regprocedure, no un fallo del producto; se conserva en `preparacion1`. SHA del runner validado: `5688d24a53538b3023c4000d27c6f330c3a7c6d0ad90b096d9255fbaef07e7d1`. Resumen entregable: `supabase/diagnosticos/RESULTADOS_CORRECCION_SALTOS_SQL_20261028.json`; no incluye el adjunto SQL completo del usuario.

La entrega de cinco archivos está descrita en `supabase/LEEME_CORRECCION_SALTOS_SQL_20261028.md`. Su registro se guarda después de crear el ZIP en `/workspace/.cloud-setup/myg/implementacion-compresion/instalador-saltos/entrega/{manifest.json,publication.json}`. Si `download_verified=true`, usar ese enlace sin volver a publicar ni repetir las pruebas. Este SQL28 ya incorpora UPDATE OF; sustituye las versiones anteriores.

Siguiente paso del usuario: ejecutar una vez el archivo completo SQL28 de la entrega más reciente y comprobar desde otra consulta los cinco indicadores en true. Abrir la aplicación actualizada de la primera entrega para renovar capacidades y reintentar el mismo pendiente. La instalación real, apertura y envío privado siguen pendientes de esa comprobación; el falso rechazo por formato está reproducido/corregido, sin atribuir el timeout ni los HTTP502/520 históricos a esta causa.
