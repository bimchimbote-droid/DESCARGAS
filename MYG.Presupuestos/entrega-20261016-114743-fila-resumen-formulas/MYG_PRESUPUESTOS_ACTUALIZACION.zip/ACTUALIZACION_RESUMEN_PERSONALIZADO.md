# Resumen por presupuesto o proyecto y pie personalizado

Entrega preparada sobre `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`, commit base `e2c5b771f127f5773d499325c7799a7a08653e85`.

Esta entrega es acumulativa: incluye la actualización anterior del resumen y la nueva ventana **Fila de resumen**. Se puede aplicar directamente sobre el commit base o sobre la entrega anterior, comparando antes los cambios locales propios.

## Ventana Fila de resumen

**Agregar fila bajo la selección** abre una ventana con **Tipo** (Campo personalizado, Gastos Generales o Utilidad), **Etiqueta**, **Identificador** y cuatro opciones:

1. **Gasto con sustento (% del costo directo):** aplica el porcentaje indicado al costo directo.
2. **Otros Gastos con o sin sustento (% de fórmula):** aplica el porcentaje al resultado de la fórmula.
3. **Valor ingresado manualmente:** utiliza el importe indicado, también cuando es negativo.
4. **Fórmula:** utiliza directamente el resultado de la expresión como importe.

El botón **Editar fórmulas…** aparece exclusivamente en las opciones 2 y 4. Al seleccionar las opciones 1 o 3 queda oculto. Cambiar de opción conserva los datos escritos; **Cerrar** descarta los cambios del diálogo.

El editor de fórmulas permite `+`, `-`, `*`, `/` y paréntesis, con prefijo `=` opcional y números decimales con punto o coma. Variables: `CD` (costo directo), `ACUMULADO` (costo directo más conceptos anteriores) y el identificador de cualquier fila anterior. Ejemplos: `CD + GG`, `ACUMULADO * 0.18`, `(CD + GG) / 2`. Los identificadores empiezan por letra o guion bajo y continúan con letras, números o guiones bajos; no pueden repetirse ni usar los nombres reservados `CD`, `COSTODIRECTO` o `ACUMULADO`.

No se admiten referencias a filas posteriores ni funciones Excel en este editor. Se rechazan expresiones inválidas, divisiones entre cero y desbordamientos sin modificar el proyecto. En alcance por proyecto se valida el cálculo para cada presupuesto antes de aplicar cambios. El porcentaje se edita en el diálogo o en la columna `%`; para importes manuales y fórmulas directas se usa **Editar fila**.

## Uso

- El botón **Resumen** permite elegir **Pie resumen por presupuesto** o **Pie resumen único por proyecto**.
- Cambiar de vista no cambia porcentajes ni conceptos. Por presupuesto se edita sólo el presupuesto activo; por proyecto la edición se aplica a todos los presupuestos del proyecto.
- Si hay porcentajes distintos aparece **Varios**. Escribir una tasa en el alcance del proyecto aplica esa tasa a todos, conservando las de los otros conceptos.
- **Limpiar resumen** elimina los conceptos activos del alcance elegido y deja sólo **Costo directo**. Su total pasa a ser el costo directo; no borra partidas, insumos ni metrados.
- Las tasas del resumen predeterminado quedan guardadas, pero no se aplican mientras el pie esté limpio o personalizado. **Mostrar Resumen predeterminado** recupera esas tasas.
- El clic derecho del resumen predeterminado incluye editar, eliminar, subir, bajar, copiar, pegar, limpiar y fuente, con iconos. Las filas calculadas están protegidas; eliminar y mover se habilitan para los conceptos personalizados.
- Después de limpiar, el clic derecho ofrece **Agregar fila bajo la selección** y **Mostrar Resumen predeterminado**. Cada concepto nuevo se configura en **Fila de resumen**. Su importe se suma al total. El orden importa para `ACUMULADO` y las referencias a otras filas.
- Se puede editar, eliminar y ordenar los conceptos personalizados. Seleccionar Costo directo e insertar agrega al inicio; seleccionar Total agrega al final. Con conceptos personalizados se muestra también el total calculado.
- **Copiar resumen / Pegar resumen** copia conceptos y tasas, sin copiar moneda, partidas ni insumos. Pegar actúa sobre el alcance seleccionado. Cuando el proyecto tiene pies o tasas distintos, copie desde un presupuesto concreto para elegir cuál usar.
- Los pies con estructuras distintas se pueden consultar juntos, pero sus filas se editan por presupuesto. Limpiar o pegar un resumen común permite uniformarlos. Los informes conservan los totales de cada presupuesto y su redondeo.
- **Fuente** cambia la presentación del panel durante la sesión; no modifica los importes ni se guarda en el proyecto.

## Archivos de esta entrega

| Archivo | Acción | Función |
|---|---|---|
| MYG.Core/PresupuestosModelos.cs | REEMPLAZAR | Modelo de conceptos personalizados. |
| MYG.Core/PiePresupuestoMYG.cs | REEMPLAZAR | Limpiar, restaurar, validar y agregar pies por alcance. |
| MYG.Core/FormulaFilaResumenMYG.cs | CREAR | Analizador de fórmulas aritméticas del resumen. |
| MYG.Core/CalculoPresupuestoMYG.cs | REEMPLAZAR | Cálculo de los conceptos activos. |
| MYG.Core/MotorPresupuestos.cs | REEMPLAZAR | Validación, plantillas y compatibilidad de firmas. |
| MYG.Core/ReportesProyectoMYG.cs | REEMPLAZAR | Informes con pie personalizado y total coherente. |
| MYG.Desktop/PresupuestosPiePanel.cs | REEMPLAZAR | Selector, edición y visualización del resumen. |
| MYG.Desktop/PresupuestosExcelPanel.cs | REEMPLAZAR | Consulta e impresión coherentes con el pie personalizado. |
| MYG.Desktop/PresupuestosResumenMenu.cs | CREAR | Menús, portapapeles y operaciones con historial. |
| MYG.Desktop/EditarFilaResumenForm.cs | CREAR | Ventana de tipo, etiqueta, identificador y cuatro modos. |
| MYG.Desktop/EditarFormulaResumenForm.cs | CREAR | Editor de expresiones y variables disponibles. |
| MYG.Desktop/ResumenPieIconos.cs | CREAR | Iconos del resumen y sus acciones. |
| MYG.Pruebas/Program.cs | REEMPLAZAR | Registra las pruebas funcionales nuevas. |
| MYG.Pruebas/PiePersonalizadoCheck.cs | CREAR | Pruebas de cálculo, alcance, persistencia e informes. |
| MYG.Pruebas/FilaResumenFormulaCheck.cs | CREAR | Pruebas de modos, fórmulas y compatibilidad. |
| MYG.PruebasUI/Program.cs | REEMPLAZAR | Registra las pruebas de interfaz nuevas. |
| MYG.PruebasUI/ResumenPersonalizadoUICheck.cs | CREAR | Pruebas de menús, edición, selección y alcance. |
| MYG.PruebasUI/FilaResumenDialogoCheck.cs | CREAR | Pruebas de opciones y visibilidad condicional del botón. |
| ACTUALIZACION_RESUMEN_PERSONALIZADO.md | CREAR | Estas instrucciones. |

## Instalación manual

1. Cierre MYG. Respalde el proyecto, sus bases y sus cambios locales, o haga un commit desde **Cambios de Git** en Visual Studio.
2. Verifique que su código corresponde al commit base indicado. Si contiene cambios posteriores o locales en alguno de estos archivos, compare y combine las diferencias antes de reemplazarlos.
3. Descargue el ZIP de esta entrega y extráigalo en una carpeta temporal.
4. Copie los archivos a la raíz de su copia local del repositorio (por ejemplo `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, si esa es su ubicación), conservando las subcarpetas. Sustituya sólo los archivos marcados REEMPLAZAR y agregue los marcados CREAR; si ya aplicó la entrega anterior, reemplace también sus archivos CREAR que ahora existan. No hay eliminaciones ni parches que aplicar.
5. Los proyectos SDK incluyen los nuevos `.cs` automáticamente: no cambie `.csproj`, la solución ni las dependencias.
6. Restaure, compile y ejecute las comprobaciones indicadas abajo.

## Compilación y validación

Tecnologías: C#, SDK .NET **10.0.100**, WinForms/WPF, Microsoft.Data.Sqlite **10.0.0**, SQLitePCLRaw.lib.e_sqlite3 **2.1.12** y referencias Revit **2027.0.0**. No se agregaron paquetes, servicios, variables ni migraciones SQL.

Desde la raíz del repositorio, estos comandos usan las referencias de Revit previstas para compilar sin una instalación local de Autodesk:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

En Windows, ejecute además las pruebas de interfaz:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

En la máquina Linux de preparación: compilación completa aprobada y **392 comprobaciones funcionales aprobadas**. Se validaron limpieza individual/global, recuperación de tasas, los cuatro modos, fórmulas y referencias, redondeo, validación atómica, JSON/SQLite e informes. Las pruebas UI se compilaron, pero **no se ejecutaron**. La prueba de Named Pipes de Windows se omite explícitamente en Linux. Las muestras externas opcionales de obras y Delphin no forman parte de esta entrega.

Comprobación manual pendiente en Windows: abra un proyecto de prueba con dos presupuestos y tasas diferentes; cambie ambos alcances; edite una tasa en cada uno; limpie y restaure; agregue y ordene conceptos; pruebe los tres tipos y las cuatro opciones del diálogo, y confirme que Editar fórmulas sólo aparece en las opciones 2 y 4. Pruebe copiar/pegar, fuente, deshacer/rehacer; guarde y reabra el proyecto y revise sus informes. Confirme la presentación con su escala de pantalla y tema.

## GitHub y límites

Esta entrega se publica únicamente como ZIP en el repositorio independiente `bimchimbote-droid/DESCARGAS`. No se hace commit, push ni fusión en el repositorio del código.

Después de aplicar y validar: abra **Cambios de Git** en Visual Studio, revise los archivos, confirme que la rama elegida es `main` (o su rama de trabajo), haga Commit y luego Push cuando corresponda. Verifique el commit y los archivos en la misma rama de GitHub.

La personalización se conserva en los formatos JSON/SQLite **MYG**, incluyendo sus metadatos. Delphin externo y una importación que elimine los metadatos `myg_*` no pueden reconstruir los conceptos personalizados; Delphin puede recalcular las tasas predeterminadas retenidas. Valide esa interoperabilidad por separado y conserve el archivo MYG original. No se validaron la ejecución visual en Windows, una licencia real, el instalador ni una sesión real de Revit.

Aplique todos los archivos de esta entrega antes de editar proyectos con los modos nuevos. Las versiones anteriores de MYG no conocen los valores manuales ni las expresiones del pie y no deben utilizarse para recalcular o guardar esos proyectos.
