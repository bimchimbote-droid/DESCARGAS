using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class FilaResumenDialogoCheck
{
    private static readonly string[] NombresModos =
    {
        "gastoConSustento", "otrosGastosFormula", "valorManualResumen", "formulaResumen"
    };

    private static readonly MYGModoFilaResumen[] Modos =
    {
        MYGModoFilaResumen.GastoConSustento, MYGModoFilaResumen.OtrosGastos,
        MYGModoFilaResumen.ValorManual, MYGModoFilaResumen.Formula
    };

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarOpcionesYVisibilidad(exige);
        VerificarValidacionYCancelacion(exige);
        VerificarRestauracionYGuardado(exige);
        VerificarEdicionEnResumen(exige);
    }

    private static void VerificarOpcionesYVisibilidad(Action<bool, string> exige)
    {
        using var dialogo = new MYGEditarFilaResumenForm(new MYGFilaPiePersonalizada
            { Nombre = "", Identificador = "" }, nueva: true);
        dialogo.Show();
        Application.DoEvents();
        var tipo = Control<ComboBox>(dialogo, "tipoFilaResumen");
        var editar = Control<Button>(dialogo, "editarFormulasResumen");
        exige(Control<TextBox>(dialogo, "etiquetaFilaResumen").Text == "" &&
                Control<TextBox>(dialogo, "identificadorFilaResumen").Text == "" &&
                !Control<Button>(dialogo, "aceptarFilaResumen").Enabled,
            "Una fila nueva debe abrirse con etiqueta e identificador vacíos y Aceptar deshabilitado.");
        exige(dialogo.Text == "Fila de resumen" && tipo.DropDownStyle == ComboBoxStyle.DropDownList &&
                tipo.Items.Cast<object>().Select(tipo.GetItemText).SequenceEqual(
                    new[] { "Campo personalizado", "Gastos Generales", "Utilidad" }),
            "Agregar una fila debe mostrar Fila de resumen con los tres tipos de las capturas.");
        exige(NombresModos.Select(n => Control<RadioButton>(dialogo, n).Text).SequenceEqual(new[]
            {
                "Gasto con sustento (% del costo directo)", "Otros Gastos con o sin sustento (% de fórmula)",
                "Valor ingresado manualmente", "Fórmula"
            }), "El diálogo debe ofrecer las cuatro formas de calcular una fila de resumen.");

        foreach (int indiceTipo in new[] { 0, 1, 2 })
        {
            tipo.SelectedIndex = indiceTipo;
            foreach (int indiceModo in new[] { 0, 1, 2, 3, 1, 0, 3, 2 })
            {
                Control<RadioButton>(dialogo, NombresModos[indiceModo]).Checked = true;
                Application.DoEvents();
                exige(editar.Visible == (indiceModo == 1 || indiceModo == 3),
                    $"Editar fórmulas sólo debe estar visible en los dos modos de fórmula (tipo {indiceTipo}, modo {indiceModo}).");
                exige(NombresModos.Count(n => Control<RadioButton>(dialogo, n).Checked) == 1,
                    "Cambiar la forma de cálculo debe mantener un único modo seleccionado.");
            }
        }
        dialogo.Close();
    }

    private static void VerificarValidacionYCancelacion(Action<bool, string> exige)
    {
        var original = new MYGFilaPiePersonalizada
        {
            Nombre = "Seguridad", Identificador = "SEGURIDAD", Porcentaje = 7.25m,
            Tipo = MYGTipoFilaResumen.CampoPersonalizado, Modo = MYGModoFilaResumen.GastoConSustento
        };
        using var dialogo = new MYGEditarFilaResumenForm(original, nueva: true);
        dialogo.Show();
        Application.DoEvents();
        var etiqueta = Control<TextBox>(dialogo, "etiquetaFilaResumen");
        var identificador = Control<TextBox>(dialogo, "identificadorFilaResumen");
        var aceptar = Control<Button>(dialogo, "aceptarFilaResumen");
        etiqueta.Text = "Seguridad adicional";
        identificador.Text = "SEG_ADICIONAL";
        exige(aceptar.Enabled, "Una etiqueta e identificador válidos deben permitir aceptar un gasto sobre costo directo.");
        etiqueta.Clear();
        exige(!aceptar.Enabled, "Aceptar debe deshabilitarse si falta la etiqueta de la fila.");
        etiqueta.Text = "Seguridad adicional";
        identificador.Clear();
        exige(!aceptar.Enabled, "Aceptar debe deshabilitarse si falta el identificador de la fila.");
        identificador.Text = "SEG_ADICIONAL";
        foreach (string modo in new[] { "otrosGastosFormula", "formulaResumen" })
        {
            Control<RadioButton>(dialogo, modo).Checked = true;
            exige(!aceptar.Enabled, "Un modo de fórmula sin expresión debe impedir aceptar la fila.");
        }
        Control<RadioButton>(dialogo, "valorManualResumen").Checked = true;
        Control<NumericUpDown>(dialogo, "importeManualResumen").Value = 42m;
        exige(aceptar.Enabled, "El valor manual debe poder aceptarse sin definir una fórmula.");
        Control<ComboBox>(dialogo, "tipoFilaResumen").SelectedIndex = 2;
        Control<Button>(dialogo, "cerrarFilaResumen").PerformClick();
        exige(dialogo.DialogResult == DialogResult.Cancel && dialogo.Valor == null &&
                original.Nombre == "Seguridad" && original.Identificador == "SEGURIDAD" &&
                original.Porcentaje == 7.25m && original.ValorManual == 0m && original.Formula == null &&
                original.Tipo == MYGTipoFilaResumen.CampoPersonalizado && original.Modo == MYGModoFilaResumen.GastoConSustento,
            "Cerrar el diálogo debe descartar sus cambios sin modificar el concepto original.");
    }

    private static void VerificarRestauracionYGuardado(Action<bool, string> exige)
    {
        foreach (int indice in Enumerable.Range(0, Modos.Length))
        {
            var original = new MYGFilaPiePersonalizada
            {
                Nombre = "Cargo de control", Identificador = "CONTROL", Porcentaje = 12.5m,
                Tipo = MYGTipoFilaResumen.Utilidad, Modo = Modos[indice], Formula = "100", ValorManual = 42m
            };
            using var dialogo = new MYGEditarFilaResumenForm(original);
            dialogo.Show();
            Application.DoEvents();
            exige(Control<ComboBox>(dialogo, "tipoFilaResumen").SelectedIndex == 2 &&
                    Control<TextBox>(dialogo, "etiquetaFilaResumen").Text == original.Nombre &&
                    Control<TextBox>(dialogo, "identificadorFilaResumen").Text == original.Identificador &&
                    Control<RadioButton>(dialogo, NombresModos[indice]).Checked &&
                    Control<NumericUpDown>(dialogo, "porcentajeFilaResumen").Value == 12.5m &&
                    Control<NumericUpDown>(dialogo, "importeManualResumen").Value == 42m,
                "Editar una fila debe recuperar su tipo, etiqueta, identificador, modo y valores numéricos.");
            var aceptar = Control<Button>(dialogo, "aceptarFilaResumen");
            exige(aceptar.Enabled, "Una fila guardada y válida debe poder aceptarse sin volver a editar su fórmula.");
            aceptar.PerformClick();
            var guardada = dialogo.Valor;
            exige(dialogo.DialogResult == DialogResult.OK && guardada != null && !ReferenceEquals(guardada, original) &&
                    guardada.Id == original.Id && guardada.Nombre == original.Nombre &&
                    guardada.Identificador == original.Identificador && guardada.Tipo == original.Tipo &&
                    guardada.Modo == original.Modo && guardada.Formula == original.Formula &&
                    guardada.ValorManual == original.ValorManual && guardada.Porcentaje == original.Porcentaje,
                "Aceptar debe devolver una copia completa del concepto, conservando su fórmula y datos de edición.");
        }

        using var heredada = new MYGEditarFilaResumenForm(new MYGFilaPiePersonalizada
            { Nombre = "Acumulado anterior", Base = MYGBaseFilaPie.Acumulado, Porcentaje = 5m });
        heredada.Show();
        Application.DoEvents();
        exige(Control<RadioButton>(heredada, "otrosGastosFormula").Checked &&
                Control<Button>(heredada, "editarFormulasResumen").Visible,
            "Una fila anterior sobre acumulado debe abrirse en el modo porcentual de fórmula.");
        heredada.Close();
    }

    private static T Control<T>(Form dialogo, string nombre) where T : Control =>
        (T)dialogo.Controls.Find(nombre, true).Single();

    private static void VerificarEdicionEnResumen(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Edición de los cuatro modos del resumen");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        partida.Costos.Cantidad = 1m;
        partida.Costos.PrecioDirecto = 100m;
        var conceptos = Modos.Select((modo, indice) => new MYGFilaPiePersonalizada
        {
            Nombre = "Concepto " + indice, Identificador = "FILA_" + indice,
            Modo = modo, Porcentaje = 5m, ValorManual = 42m, Formula = "CD"
        }).ToList();
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { presupuesto }, conceptos);
        int antes = 0, despues = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antes++, () => despues++,
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarCatalogos(() => "", () => true, () => { });
        using var formulario = new Form { ClientSize = new Size(1500, 900) };
        formulario.Controls.Add(panel);
        formulario.Show();
        panel.Refrescar();
        Application.DoEvents();
        const BindingFlags privados = BindingFlags.Instance | BindingFlags.NonPublic;
        var tabla = (DataGridView)typeof(MYGPanelPresupuesto).GetField("tablaPie", privados).GetValue(panel);
        string firma = MYGProyectoStorage.Firma(proyecto);
        for (int indice = 0; indice < conceptos.Count; indice++)
        {
            var fila = tabla.Rows.Cast<DataGridViewRow>().Single(f => f.HeaderCell.Tag as string == conceptos[indice].Id);
            bool porcentual = indice < 2;
            exige(fila.Cells["PORC"].ReadOnly == !porcentual &&
                    string.IsNullOrEmpty(Convert.ToString(fila.Cells["PORC"].Value)) == !porcentual,
                "Sólo los dos modos porcentuales deben ofrecer un porcentaje editable en la tabla del resumen.");
            tabla.CurrentCell = fila.Cells["CONCEPTO"];
            typeof(MYGPanelPresupuesto).GetMethod("ActualizarMenuResumen", privados).Invoke(panel, null);
            exige(tabla.ContextMenuStrip.Items["editarFilaResumen"].Enabled,
                "Editar fila debe seguir disponible para porcentajes, valores manuales y fórmulas.");
            if (!porcentual)
            {
                tabla.CurrentCell = fila.Cells["PORC"];
                exige(!tabla.BeginEdit(true), "El porcentaje vacío de una fila manual o fórmula no debe entrar en edición.");
                tabla.CurrentCell = fila.Cells["CONCEPTO"];
                panel.FinalizarEdicion();
            }
        }
        exige(MYGProyectoStorage.Firma(proyecto) == firma && antes == 0 && despues == 0,
            "Consultar y recorrer los cuatro modos del resumen debe conservar sus valores sin registrar cambios.");
        formulario.Close();
    }
}
