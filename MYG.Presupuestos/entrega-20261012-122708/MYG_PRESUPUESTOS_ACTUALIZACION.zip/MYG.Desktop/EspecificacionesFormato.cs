using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Aplica formato nativo de RichEdit sin reemplazar el RTF ni las fuentes de una selección mixta.</summary>
internal static class MYGEspecificacionesFormato
{
    private const int EmGetCharFormat = 0x043A, EmSetCharFormat = 0x0444;
    private const int EmGetParaFormat = 0x043D, EmSetParaFormat = 0x0447;
    private const uint ScfSelection = 1;
    private const uint CfmEstilos = 0x0000000F, CfmPosicion = 0x00030000;
    private const uint CfmCharset = 0x08000000, CfmOffset = 0x10000000;
    private const uint CfmFace = 0x20000000, CfmColor = 0x40000000, CfmSize = 0x80000000;
    private const uint CfmBackColor = 0x04000000;
    private const uint PfeStartIndent = 0x00000001, PfeRightIndent = 0x00000002, PfeOffset = 0x00000004;
    private const uint PfeAlignment = 0x00000008, PfeTabs = 0x00000010, PfeNumbering = 0x00000020;
    private const uint PfeSpaceBefore = 0x00000040, PfeSpaceAfter = 0x00000080, PfeLineSpacing = 0x00000100;
    private const uint PfeNumberingStyle = 0x00002000, PfeNumberingTab = 0x00004000, PfeNumberingStart = 0x00008000;
    private const uint PfeOffsetIndent = 0x80000000;

    // SCF_DEFAULT cambia la fuente de las nuevas inserciones, sin reformatear
    // los fragmentos que ya tienen una fuente explícita en el RTF.
    internal static void EstablecerFuentePredeterminada(RichTextBox editor, string nombre, float tamano)
    {
        ArgumentNullException.ThrowIfNull(editor);
        CharFormat formato = NuevoCaracter();
        formato.dwMask = CfmFace | CfmSize;
        formato.szFaceName = nombre;
        formato.yHeight = (int)Math.Round(tamano * 20);
        SendMessageCaracter(editor.Handle, EmSetCharFormat, 0, ref formato);
    }

    internal static void PrepararInsercionNormal(RichTextBox editor, string nombre, float tamano)
    {
        CharFormat formato = NuevoCaracter();
        formato.dwMask = CfmEstilos | 0x00800000 | CfmPosicion | CfmOffset | CfmFace | CfmSize | CfmColor | CfmBackColor;
        formato.dwEffects = CfmColor | CfmBackColor;
        formato.bUnderlineType = 1;
        formato.szFaceName = nombre;
        formato.yHeight = (int)Math.Round(tamano * 20);
        // Sólo caracteres: no tocar sangrías/alineación del párrafo vecino
        // cuando se inserta el título en medio de contenido existente.
        AplicarCaracter(editor, ref formato);
    }

    internal static void AlternarEstilo(RichTextBox editor, FontStyle estilo)
    {
        uint mascara = (uint)estilo & CfmEstilos;
        if (mascara == 0) return;
        CharFormat actual = ObtenerCaracter(editor);
        bool quitar = (actual.dwMask & mascara) == mascara && (actual.dwEffects & mascara) == mascara;
        CharFormat nuevo = NuevoCaracter();
        nuevo.dwMask = mascara;
        nuevo.dwEffects = quitar ? 0 : mascara;
        if ((mascara & 4) != 0) { nuevo.dwMask |= 0x00800000; nuevo.bUnderlineType = 1; }
        AplicarCaracter(editor, ref nuevo);
    }

    /// <summary>Devuelve null cuando el estilo varía dentro de la selección.</summary>
    internal static bool? TieneEstilo(RichTextBox editor, FontStyle estilo)
    {
        uint mascara = (uint)estilo & CfmEstilos;
        if (mascara == 0) return false;
        CharFormat actual = ObtenerCaracter(editor);
        return (actual.dwMask & mascara) != mascara ? null : (actual.dwEffects & mascara) == mascara;
    }

    internal static void SubrayadoDoble(RichTextBox editor)
    {
        CharFormat nuevo = NuevoCaracter();
        nuevo.dwMask = 0x00800004; // CFM_UNDERLINETYPE | CFM_UNDERLINE.
        nuevo.dwEffects = 0x00000004;
        nuevo.bUnderlineType = 3; // CFU_UNDERLINEDOUBLE.
        AplicarCaracter(editor, ref nuevo);
    }

    internal static void EstablecerFuente(RichTextBox editor, string nombre, float? tamano)
    {
        CharFormat nuevo = NuevoCaracter();
        if (!string.IsNullOrWhiteSpace(nombre))
        {
            nombre = nombre.Trim();
            if (nombre.Length > 31) throw new ArgumentOutOfRangeException(nameof(nombre), "El nombre de fuente admite hasta 31 caracteres.");
            nuevo.dwMask |= CfmFace;
            nuevo.szFaceName = nombre;
        }
        if (tamano.HasValue)
        {
            float puntos = tamano.Value;
            if (!float.IsFinite(puntos) || puntos < 1 || puntos > 1638)
                throw new ArgumentOutOfRangeException(nameof(tamano), "El tamaño debe estar entre 1 y 1638 puntos.");
            nuevo.dwMask |= CfmSize;
            nuevo.yHeight = (int)Math.Round(puntos * 20);
        }
        if (nuevo.dwMask != 0) AplicarCaracter(editor, ref nuevo);
    }

    /// <param name="alineacion">1: izquierda; 2: derecha; 3: centro; 4: justificada.</param>
    internal static void Alinear(RichTextBox editor, int alineacion)
    {
        if (alineacion is < 1 or > 4) throw new ArgumentOutOfRangeException(nameof(alineacion));
        ParaFormat nuevo = NuevoParrafo();
        nuevo.dwMask = PfeAlignment;
        nuevo.wAlignment = (ushort)alineacion;
        AplicarParrafo(editor, ref nuevo);
    }

    /// <summary>Devuelve 0 si los párrafos seleccionados tienen alineaciones diferentes.</summary>
    internal static int ObtenerAlineacion(RichTextBox editor)
    {
        ParaFormat actual = ObtenerParrafo(editor);
        return (actual.dwMask & PfeAlignment) != 0 ? actual.wAlignment : 0;
    }

    /// <summary>Alterna listas nativas; los números quedan guardados como numeración en el RTF.</summary>
    internal static void Lista(RichTextBox editor, bool numerada)
    {
        ParaFormat actual = ObtenerParrafo(editor);
        ushort tipo = numerada ? (ushort)2 : (ushort)1;
        bool quitar = (actual.dwMask & PfeNumbering) != 0 && actual.wNumbering == tipo;
        ParaFormat nuevo = NuevoParrafo();
        nuevo.dwMask = PfeNumbering;
        nuevo.wNumbering = quitar ? (ushort)0 : tipo;
        if (!quitar)
        {
            nuevo.dwMask |= PfeNumberingStart | PfeNumberingStyle | PfeNumberingTab;
            nuevo.wNumberingStart = 1;
            nuevo.wNumberingStyle = numerada ? (ushort)0x0200 : (ushort)0;
            nuevo.wNumberingTab = 360;
        }
        AplicarParrafo(editor, ref nuevo);
    }

    /// <summary>Cambia la sangría de cada párrafo de forma relativa; un punto equivale a 20 twips.</summary>
    internal static void Sangria(RichTextBox editor, int deltaTwips)
    {
        if (deltaTwips == 0) return;
        ParaFormat nuevo = NuevoParrafo();
        nuevo.dwMask = PfeOffsetIndent;
        nuevo.dxStartIndent = deltaTwips;
        AplicarParrafo(editor, ref nuevo);
    }

    internal static void Interlineado(RichTextBox editor, float factor)
    {
        if (!float.IsFinite(factor) || factor < 0.5f || factor > 10)
            throw new ArgumentOutOfRangeException(nameof(factor), "El interlineado debe estar entre 0,5 y 10 líneas.");
        ParaFormat nuevo = NuevoParrafo();
        nuevo.dwMask = PfeLineSpacing;
        nuevo.bLineSpacingRule = 5;
        nuevo.dyLineSpacing = (int)Math.Round(factor * 20);
        AplicarParrafo(editor, ref nuevo);
    }

    internal static float? ObtenerInterlineado(RichTextBox editor)
    {
        ParaFormat actual = ObtenerParrafo(editor);
        if ((actual.dwMask & PfeLineSpacing) == 0) return null;
        return actual.bLineSpacingRule switch
        {
            0 => 1f,
            1 => 1.5f,
            2 => 2f,
            5 => actual.dyLineSpacing / 20f,
            _ => null
        };
    }

    /// <param name="posicion">0: normal; 1: superíndice; -1: subíndice.</param>
    internal static void PosicionCaracter(RichTextBox editor, int posicion)
    {
        if (posicion is < -1 or > 1) throw new ArgumentOutOfRangeException(nameof(posicion));
        CharFormat nuevo = NuevoCaracter();
        nuevo.dwMask = CfmPosicion | CfmOffset;
        nuevo.dwEffects = posicion == 1 ? 0x00020000u : posicion == -1 ? 0x00010000u : 0;
        AplicarCaracter(editor, ref nuevo);
    }

    internal static int? ObtenerPosicionCaracter(RichTextBox editor)
    {
        CharFormat actual = ObtenerCaracter(editor);
        if ((actual.dwMask & CfmPosicion) != CfmPosicion) return null;
        if ((actual.dwEffects & 0x00020000) != 0) return 1;
        return (actual.dwEffects & 0x00010000) != 0 ? -1 : 0;
    }

    internal static void LimpiarFormato(RichTextBox editor)
    {
        ArgumentNullException.ThrowIfNull(editor);
        CharFormat caracter = NuevoCaracter();
        caracter.dwMask = CfmEstilos | 0x00800000 | CfmPosicion | CfmOffset | CfmFace | CfmSize | CfmCharset | CfmColor | CfmBackColor;
        caracter.bUnderlineType = 1;
        caracter.dwEffects = CfmColor | CfmBackColor; // Colores automáticos de RichEdit.
        caracter.szFaceName = editor.Font.Name;
        caracter.yHeight = (int)Math.Round(editor.Font.SizeInPoints * 20);
        caracter.bCharSet = editor.Font.GdiCharSet;
        AplicarCaracter(editor, ref caracter);

        ParaFormat parrafo = NuevoParrafo();
        parrafo.dwMask = PfeAlignment | PfeStartIndent | PfeRightIndent | PfeOffset | PfeTabs | PfeNumbering |
            PfeSpaceBefore | PfeSpaceAfter | PfeLineSpacing;
        parrafo.wAlignment = 1;
        parrafo.bLineSpacingRule = 5;
        parrafo.dyLineSpacing = 20;
        AplicarParrafo(editor, ref parrafo);
    }

    private static CharFormat NuevoCaracter() => new() { cbSize = (uint)Marshal.SizeOf<CharFormat>(), szFaceName = string.Empty };
    private static ParaFormat NuevoParrafo() => new() { cbSize = (uint)Marshal.SizeOf<ParaFormat>(), rgxTabs = new int[32] };

    private static CharFormat ObtenerCaracter(RichTextBox editor)
    {
        ArgumentNullException.ThrowIfNull(editor);
        CharFormat formato = NuevoCaracter();
        SendMessageCaracter(editor.Handle, EmGetCharFormat, (nint)ScfSelection, ref formato);
        return formato;
    }

    private static ParaFormat ObtenerParrafo(RichTextBox editor)
    {
        ArgumentNullException.ThrowIfNull(editor);
        ParaFormat formato = NuevoParrafo();
        SendMessageParrafo(editor.Handle, EmGetParaFormat, 0, ref formato);
        return formato;
    }

    private static void AplicarCaracter(RichTextBox editor, ref CharFormat formato)
    {
        ArgumentNullException.ThrowIfNull(editor);
        SendMessageCaracter(editor.Handle, EmSetCharFormat, (nint)ScfSelection, ref formato);
    }

    private static void AplicarParrafo(RichTextBox editor, ref ParaFormat formato)
    {
        ArgumentNullException.ThrowIfNull(editor);
        SendMessageParrafo(editor.Handle, EmSetParaFormat, 0, ref formato);
    }

    // CHARFORMAT2W y PARAFORMAT2 no contienen punteros. Su tamaño es el mismo en x86 y x64.
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct CharFormat
    {
        public uint cbSize, dwMask, dwEffects;
        public int yHeight, yOffset, crTextColor;
        public byte bCharSet, bPitchAndFamily;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szFaceName;
        public ushort wWeight;
        public short sSpacing;
        public int crBackColor, lcid;
        public uint dwReserved;
        public short sStyle;
        public ushort wKerning;
        public byte bUnderlineType, bAnimation, bRevAuthor, bReserved1;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ParaFormat
    {
        public uint cbSize, dwMask;
        public ushort wNumbering, wEffects;
        public int dxStartIndent, dxRightIndent, dxOffset;
        public ushort wAlignment;
        public short cTabCount;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)] public int[] rgxTabs;
        public int dySpaceBefore, dySpaceAfter, dyLineSpacing;
        public short sStyle;
        public byte bLineSpacingRule, bOutlineLevel;
        public ushort wShadingWeight, wShadingStyle, wNumberingStart, wNumberingStyle;
        public ushort wNumberingTab, wBorderSpace, wBorderWidth, wBorders;
    }

    [DllImport("user32.dll", EntryPoint = "SendMessageW", CharSet = CharSet.Unicode)]
    private static extern nint SendMessageCaracter(nint ventana, int mensaje, nint parametro, ref CharFormat formato);

    [DllImport("user32.dll", EntryPoint = "SendMessageW", CharSet = CharSet.Unicode)]
    private static extern nint SendMessageParrafo(nint ventana, int mensaje, nint parametro, ref ParaFormat formato);
}
