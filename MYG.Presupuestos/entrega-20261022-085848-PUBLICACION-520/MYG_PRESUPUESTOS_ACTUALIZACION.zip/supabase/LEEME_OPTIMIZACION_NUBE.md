# Nube MYG: investigación del HTTP 520 y publicación con confirmación pequeña

Entrega del 22/10/2026 para `bimchimbote-droid/MYG.Presupuestos`, rama `main`,
base `4ba66afdfba50b572fc077b272d86692e6fc8df6`. Complementa las entregas de
fuentes compacto/incremental (26 archivos) y optimización/300 MiB (20 archivos).
No es el repositorio completo ni una distribución de ejecutables.

## Resultado y alcance

El pendiente comunicado ocupa 200,1 MiB y procede de un SQLite de 60,1 MiB.
**No supera el máximo lógico de 300 MiB**. JSON y SQLite tienen estructuras
distintas; elevar el máximo no garantiza que PostgreSQL tenga memoria para
recibir, convertir, validar y guardar el paquete.

Los registros comunicados muestran ingreso, listado y capacidades con HTTP 200,
pero creación con HTTP 520, interrupción/recuperación de PostgreSQL y un aviso de
incidencia de Supabase. HTTP 520 no determina por sí mismo la causa del corte.
Faltan las líneas anteriores a la recuperación y el texto exacto de la incidencia
para atribuir el fallo real a recursos, infraestructura u otra causa.

En una reproducción aislada, un paquete sintético de 200 MiB agotó PostgreSQL
limitado a 512 MiB y a 1 GiB antes de entrar al RPC. **Las correcciones de esta
entrega no garantizan publicar esos 200 MiB en una instancia pequeña**. Véase
`INFORME_PUBLICACION_200_MIB.md` para evidencia, resultados y límites.

## Cambios implementados

- El pendiente se valida sin conservar toda su expansión v1 ni otro DOM. Se
  cuentan los bytes UTF-8 reales y se conservan profundidad y máximo expandido.
  El buffer temporal depende del mayor token; no es memoria constante para un
  único texto gigantesco.
- La preparación evita copiar el paquete completo cuando no contiene adjuntos.
  Conserva identidad, renovación, comprobación de recursos y contenido exacto.
- `myg_nube_crear_confirmacion` devuelve solo metadatos. Conserva validación,
  propietario, miembros, historial, transacción e idempotencia del RPC anterior,
  que sigue disponible.
- Antes de reenviar, `myg_nube_estado_publicacion` consulta si el mismo UUID sigue
  procesándose. Un UUID existente aún exige verificar el cuerpo original; el
  estado por sí solo nunca confirma ni elimina un pendiente. El bloqueo SQL
  impide ejecutar dos creaciones simultáneas una vez analizados sus argumentos;
  no evita el coste previo de recibir y convertir un POST grande.
- Publicar ya no abre y descarga automáticamente toda la base. Tras confirmar,
  seleccione **Abrir proyecto** cuando quiera trabajar en ella.
- La interfaz muestra fase, tiempo y cancelación. Cancelar conserva el intento;
  no asegura detener un trabajo que ya llegó a PostgreSQL. La cancelación de
  preparación es cooperativa entre fases. Una confirmación válida ya recibida
  completa el cierre local aunque coincida con una pulsación de cancelar.
- Los errores muestran HTTP y códigos permitidos, distinguen recursos, plazos,
  conexión y sesión, y no muestran HTML, tokens ni cuerpos remotos arbitrarios.
  No se repite automáticamente el canje de un ticket MYG de un solo uso.
- Un paquete guardado mayor de 127 MiB muestra un aviso con **Cancelar** como
  opción predeterminada. 127 MiB es un umbral preventivo, no el máximo nuevo.
  Puede continuar si su instancia tiene capacidad verificada. El tamaño del
  envío puede bajar al preparar adjuntos externos.

Se mantienen colaboración, permisos por módulo, conflictos por revisión,
paquetes compactos, adjuntos, diferencias incrementales y reintentos duraderos.
No se elimina información de la base ni se cambian credenciales.

## Instalación manual

1. Cierre MYG y respalde o confirme sus cambios locales en Visual Studio.
   Reemplazar archivos completos puede perder modificaciones locales o
   posteriores: revise las diferencias antes de copiar.
2. Extraiga el ZIP fuera del repositorio. Copie sus archivos a
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, conservando las rutas relativas.
   Mantenga `.git`, la configuración existente y todos los archivos no incluidos.
3. En **su proyecto Supabase**, abra una consulta nueva del SQL Editor como
   administrador y ejecute TODO
   `supabase/migraciones/20261026_publicacion_ligera.sql`. Es el único instalador
   necesario para esta entrega: incluye los requisitos anteriores en una sola
   transacción y admite repetición sobre instalaciones compatibles. Requiere que
   el esquema base de Nube MYG ya exista. Use su respaldo habitual antes de DDL.
4. Debe devolver `resultado = PUBLICACION_LIGERA_INSTALADA`,
   `max_contenido_mib = 300` y `publicacion_ligera = true`. La recarga de esquema
   está incluida. Si devuelve un error, conserve el mensaje completo; no continúe
   interpretando una ejecución fallida como una migración aplicada.
5. No vuelva a ejecutar los instaladores 21 a 25 después del 26: algunos
   redefinen capacidades anteriores. No ejecute los SQL de `supabase/pruebas`
   sobre su servicio: usan datos y roles de prueba desechables.
6. Restaure y compile con .NET 10. Actualice la aplicación compilada y sus DLL
   dependientes juntas. El ZIP contiene fuentes, documentación, SQL y pruebas;
   no contiene ejecutables ni runtime. No basta copiar solo un EXE antiguo.
7. Reinicie MYG y revise **Mis proyectos**. Si falta la confirmación, conserve
   el pendiente y su UUID; no cree otro por cada error. Reintentar verifica el
   mismo contenido. Si informa que sigue procesándose, espere y revise los
   registros antes de repetir.
8. Después de confirmar, compruebe el proyecto y ábralo explícitamente. Pruebe
   primero una obra pequeña y la colaboración entre dos cuentas con los permisos
   habituales. Para la base completa grande, verifique antes salud y recursos.

No se ha ejecutado esta migración ni modificado su Supabase real desde Codex.
Actualizar a todos los colaboradores evita mezclar límites y contratos antiguos.
Los proyectos SDK incluyen automáticamente los nuevos archivos `.cs`; no se
requieren paquetes NuGet ni claves nuevas.

## Compilación y pruebas

En la raíz del repositorio, con SDK .NET 10.0.100 y las dependencias del proyecto:

```powershell
dotnet restore MYG.Presupuestos.sln
dotnet build MYG.Presupuestos.sln -c Release --no-restore
dotnet run --project MYG.Pruebas -c Release --no-build
dotnet run --project MYG.PruebasNube -c Release --no-build
```

Los proyectos afectados son `MYG.Colaboracion`, `MYG.Desktop` y
`MYG.PruebasNube`. `MYG.Core` se comprueba mediante sus 584 pruebas existentes.
La solución Windows/Revit se compila desde Linux con el SDK configurado; la
interfaz Windows y Revit no pueden ejecutarse aquí.
En este entorno sin Revit instalado se usó
`dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true`,
con sus referencias Revit 2027 restauradas con la misma propiedad. Sin Revit
instalado ni esa alternativa, la comprobación del proyecto Revit detiene el build.

Pruebas SQL y HTTP reproducibles, en Linux con Bash, Python 3, Docker y .NET,
exclusivamente sobre contenedores desechables:

```bash
bash scripts/pruebas/Probar-PublicacionLigeraNube.sh
python3 scripts/pruebas/Probar-PublicacionLigeraHTTP.py
```

Se verificaron compilación sin errores ni advertencias, 584 pruebas de datos,
37 grupos de nube, 152 comprobaciones SQL nuevas (más 134 del fixture inicial)
y 15 solicitudes HTTP reales. La prueba HTTP positiva usa unos 8 MiB y PostgreSQL
limitado a 512 MiB; su respuesta de creación fue de 286 bytes, sin OOM. No se
extrapola ese resultado al paquete privado de 200,1 MiB.

## Diagnóstico del servidor real

`supabase/diagnosticos/20261026_publicacion_solo_lectura.sql` es opcional y de
solo lectura. Comprueba firmas, permisos, plazos, definiciones de publicación y
estadísticas generales; no consulta filas privadas, claves ni consultas activas.
No instala nada ni certifica la RAM física de Supabase.

Para cerrar la causa del intento de las 08:26:09 del 22/10/2026, obtenga las líneas
de Logs → Postgres próximas y anteriores a la recuperación, conservando la zona
horaria: `terminated by signal`, `out of memory`, `PANIC`, `FATAL`, `shutdown`,
`reinitializing`, `recovery`. Añada el texto y periodo del aviso de incidencia.
Omita claves, tokens y cuerpos completos de las consultas. Un mensaje posterior
de recuperación sin la causa inicial no basta para diagnosticar OOM.

## Límites que permanecen

- Contenido lógico: 300 MiB (314572800 bytes); respuestas: 320 MiB;
  profundidad JSON: 128; expansión compacta: 512 MiB.
- PostgreSQL tiene además límites propios de JSONB, memoria, disco, tiempo y
  concurrencia. El límite interno de un contenedor JSONB con datos y metadatos
  ronda 256 MiB en la versión comprobada; no equivale directamente a bytes del
  texto JSON ni garantiza admitir cualquier contenido de 300 MiB.
- El envío inicial sigue siendo un POST monolítico. La apertura también debe
  leer y reconstruir la base. Una respuesta de creación pequeña no elimina
  esos costes. No se cambia el plan ni el límite de infraestructura de Supabase.
- Las mejoras anteriores de escapes y diccionario conservan exactitud de datos.
  En el benchmark anterior redujeron 18,05 % los bytes de transferencia; el TOAST
  físico aumentó aproximadamente 0,3 %. No confunda ahorro del JSON con ahorro
  físico en PostgreSQL, que incluye índices, historial y compresión.
- Mientras se determina la capacidad, puede publicar **una sola obra** mediante
  el alcance existente. Para una base completa grande hace falta capacidad
  verificada o un diseño por partes que conserve validación y permisos por módulo.
  Ese rediseño no forma parte de esta corrección.

Publicar este ZIP en `bimchimbote-droid/DESCARGAS` no aplica los cambios al código
ni hace Push en `bimchimbote-droid/MYG.Presupuestos`. Después de instalar y probar,
revise **Cambios de Git** en Visual Studio, confirme `main`, haga Commit, Push y
compruebe el commit en GitHub. No incluya bases, claves, `bin` ni `obj`.
