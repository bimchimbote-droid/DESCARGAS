#nullable enable
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private ClienteSupabase? clienteNube;
    private NubeForm? ventanaNube;
    private bool clienteNubePreparado;
    private ConfiguracionNube? configuracionNube;
    private string? errorConfiguracionNube;
    private string? usuarioNube;
    private long generacionNube;
    private readonly System.Threading.SemaphoreSlim ingresoNube = new(1, 1);
    private static string CarpetaNube => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "trabajo");

    // Conservar el callback Action de los editores; IntentarAsync controla los
    // errores y las aperturas repetidas antes del primer await.
    private void MostrarNube() => _ = IntentarAsync(MostrarNubeAsync);

    private async Task MostrarNubeAsync()
    {
        RequerirSesion();
        if (!clienteNubePreparado)
        {
            try
            {
                configuracionNube = NubeConfiguracion.Cargar();
                errorConfiguracionNube = null;
            }
            catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or NubeException)
            {
                // Conservar el archivo y el destino previo: no sustituirlo por
                // otra conexión si está dañado. Su recuperación corresponde a soporte.
                configuracionNube = null;
                errorConfiguracionNube = "No se pudo leer la conexión guardada de Nube MYG. Solicite a soporte que revise la instalación. No se cambió el servidor de sus obras.";
            }
            clienteNubePreparado = true;
        }
        ActualizarSesionNube();
        bool nuevaVentana = ventanaNube is null || ventanaNube.IsDisposed;
        if (nuevaVentana)
        {
            ventanaNube = new NubeForm(sesion, clienteNube);
            ventanaNube.AbrirSolicitado += AbrirProyectoNube;
            ventanaNube.PublicarSolicitado += PublicarProyectoNube;
            ventanaNube.PendientesSolicitado += GestionarPublicacionesPendientesNube;
            ventanaNube.DescargarSolicitado += DescargarProyectoNube;
            ventanaNube.ConectarMygSolicitado += ConectarNubeConMygAsync;
        }
        var ventana = ventanaNube!;
        if (ventana.OperacionEnCurso)
        {
            ventana.Activate();
            return;
        }
        ventana.InformarErrorConfiguracion(errorConfiguracionNube);
        ventana.Hide();
        var clienteApertura = clienteNube;
        try
        {
            await MYGCargaAnimada.EjecutarAsync(this, "Conectando…", ventana.ConectarYRefrescarAsync);
            if (IsDisposed || Disposing || ventana.IsDisposed || ventana.Disposing) return;
            ComprobarClienteActual(clienteApertura!);
            ventana.Show(this); ventana.Activate();
        }
        catch
        {
            // El error se presenta sobre Inicio, una vez cerrada la carga.
            // No dejar una ventana nueva suscrita a la sesión tras fallar.
            if (nuevaVentana)
            {
                ventana.Dispose();
                if (ReferenceEquals(ventanaNube, ventana)) ventanaNube = null;
            }
            throw;
        }
    }

    private string? UsuarioMygActual => sesion.Autorizado
        ? sesion.Credencial?.Usuario?.Trim().ToLowerInvariant() : null;

    private void ActualizarSesionNube()
    {
        if (!clienteNubePreparado) return;
        string? usuario = UsuarioMygActual;
        if (usuario == usuarioNube && (clienteNube is not null || configuracionNube is null || usuario is null)) return;
        generacionNube++;
        var anterior = clienteNube;
        clienteNube = usuario is not null ? configuracionNube?.CrearCliente() : null;
        usuarioNube = usuario;
        // Cancelar y eliminar solo la sesión local anterior; nunca cerrar otras computadoras.
        anterior?.Dispose();
        ventanaNube?.ActualizarCliente(clienteNube);
    }

    private async Task ConectarNubeConMygAsync()
    {
        await ingresoNube.WaitAsync();
        try
        {
            if (IsDisposed || Disposing) return;
            RequerirSesion(); ActualizarSesionNube();
            var cliente = clienteNube ?? throw new InvalidOperationException("No se encontró la conexión de Nube MYG. Solicite a soporte que revise la instalación.");
            string usuario = UsuarioMygActual ?? throw new InvalidOperationException("Inicie sesión en MYG.");
            if (cliente.SesionIniciada && cliente.UsuarioMygSesion == usuario) return;
            long generacion = generacionNube;
            var resultado = await sesion.ObtenerTicketNubeAsync(cliente.UrlServidor);
            if (!resultado.Ok || resultado.Ticket is null) throw new InvalidOperationException(resultado.Mensaje);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            await cliente.IniciarSesionMygAsync(resultado.Ticket);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
            {
                cliente.Dispose();
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            }
            ventanaNube?.ActualizarCliente(cliente);
        }
        finally { ingresoNube.Release(); }
    }

    private void ComprobarClienteActual(ClienteSupabase cliente)
    {
        RequerirSesion();
        if (!ReferenceEquals(clienteNube, cliente) || !cliente.SesionIniciada || cliente.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Cambió la sesión MYG durante la operación. Vuelva a abrir Nube MYG.");
    }

    private ClienteSupabase RequerirNube()
    {
        RequerirSesion();
        if (clienteNube?.SesionIniciada != true || clienteNube.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Abra Nube MYG para conectar con su usuario MYG actual.");
        return clienteNube;
    }

    private static string CarpetaDeProyectoNube(ClienteSupabase cliente, Guid proyecto)
    {
        string servidor = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(cliente.UrlServidor)))[..24];
        if (!Guid.TryParse(cliente.UsuarioId, out var usuario)) throw new InvalidOperationException("La identidad de nube no es válida.");
        return Path.Combine(CarpetaNube, servidor, usuario.ToString("N"), proyecto.ToString("N"));
    }

    private async Task AbrirProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        Guid proyectoId = seleccionado.Id;
        string servidor = cliente.UrlServidor, usuario = cliente.UsuarioId!;
        var remoto = await Task.Run(() => cliente.AbrirProyectoAsync(proyectoId));
        ComprobarClienteActual(cliente);
        JsonElement contenido = remoto.Contenido;
        var contenidoCargado = await Task.Run(() => cliente.CargarArchivosAsync(contenido));
        ComprobarClienteActual(cliente);
        remoto = remoto with { Contenido = contenidoCargado };
        var existente = EditoresAbiertos.FirstOrDefault(e => e.NubeProyectoId == remoto.Id
            && string.Equals(e.NubeServidor?.TrimEnd('/'), servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase)
            && e.NubeUsuario == usuario);
        if (existente is not null)
        {
            await existente.ActualizarNubeAsync(true);
            ComprobarClienteActual(cliente);
            SeleccionarEditor(existente); ventanaNube?.Hide(); return;
        }
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Id);
        string ruta = Path.Combine(carpeta, "trabajo.sqlite");
        var original = await Task.Run(() => PaqueteNube.LeerDocumento(contenidoCargado));
        ComprobarClienteActual(cliente);
        MYGProyectoDocumento documento;
        if (File.Exists(ruta))
        {
            var recuperado = await Task.Run(() =>
            {
                var local = MYGBaseDatos.LeerProyecto(ruta, original.Id);
                var vinculoLocal = MYGColaboracionLocal.Leer(ruta, local.Id)
                    ?? throw new InvalidOperationException("La copia existente no tiene un vínculo válido. Consérvela antes de recuperar otra copia.");
                return (Documento: local, Vinculo: vinculoLocal);
            });
            ComprobarClienteActual(cliente);
            documento = recuperado.Documento;
            var vinculo = recuperado.Vinculo;
            SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
            if (vinculo.ProyectoId != remoto.Id) throw new InvalidOperationException("La copia corresponde a otro proyecto remoto.");
            SincronizadorProyectoNube.ActualizarPermisos(vinculo, remoto);
            await Task.Run(() => MYGColaboracionLocal.Guardar(ruta, documento, vinculo));
            ComprobarClienteActual(cliente);
        }
        else
        {
            string preparacion = Path.Combine(carpeta, "preparando-" + Guid.NewGuid().ToString("N") + ".sqlite");
            documento = await Task.Run(() =>
            {
                Directory.CreateDirectory(carpeta);
                PaqueteNube.Descargar(contenidoCargado, preparacion);
                var local = MYGBaseDatos.LeerProyecto(preparacion, original.Id);
                MYGColaboracionLocal.Vincular(preparacion, local, new MYGVinculoNube
                {
                    ProyectoId = remoto.Id, Servidor = servidor, UsuarioId = usuario,
                    Revision = remoto.Revision, Rol = remoto.Rol, PermisosModulos = remoto.PermisosModulos?.Copiar(),
                    JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(local),
                    JsonPaqueteConfirmado = contenidoCargado.GetRawText()
                });
                return local;
            });
            ComprobarClienteActual(cliente);
            File.Move(preparacion, ruta);
        }
        ComprobarClienteActual(cliente);
        var editor = AbrirEditor(documento, ruta);
        editor.ConfigurarNube(() => clienteNube, MostrarNube);
        ventanaNube?.Hide();
        // La copia recuperada conserva borradores: actualizar explícitamente desde su barra.
    }

    private ArchivoPublicacionPendienteNube PublicacionesDe(ClienteSupabase cliente) => new(
        Path.Combine(CarpetaNube, "publicaciones"), cliente.UrlServidor, cliente.UsuarioId!);

    private async Task GestionarPublicacionesPendientesNube()
    {
        var cliente = RequerirNube();
        using var dialogo = new PublicacionesPendientesForm(PublicacionesDe(cliente), () => ComprobarClienteActual(cliente));
        var opcion = dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this);
        ComprobarClienteActual(cliente);
        if (opcion == WinForms.DialogResult.Retry && dialogo.ParaReintentar is { } pendiente)
            await PublicarProyectoNube(pendiente);
        else if (opcion == WinForms.DialogResult.OK)
            await PublicarProyectoNube();
    }

    private Task PublicarProyectoNube() => PublicarProyectoNube(null);

    private async Task PublicarProyectoNube(ResumenPublicacionPendienteNube? elegida)
    {
        var cliente = RequerirNube();
        string pendientes = Path.Combine(CarpetaNube, "publicaciones");
        Directory.CreateDirectory(pendientes);
        var almacen = PublicacionesDe(cliente);
        var resumen = await Task.Run(almacen.Consultar);
        ComprobarClienteActual(cliente);
        if (resumen is not null && elegida is null)
        {
            await GestionarPublicacionesPendientesNube();
            return;
        }
        var ventana = ventanaNube ?? throw new InvalidOperationException("Abra Nube MYG para publicar.");
        var cancelacion = ventana.ComenzarPublicacion();
        bool envioIniciado = false, confirmado = false;
        try
        {
            ventana.InformarProgresoPublicacion("Comprobando el servidor de publicación");
            await cliente.ExigirPublicacionLigeraAsync(cancelacion);
            ComprobarClienteActual(cliente);
            cancelacion.ThrowIfCancellationRequested();
            PublicacionPendienteNube publicacion;
            if (elegida is not null)
            {
                ventana.InformarProgresoPublicacion("Leyendo el paquete pendiente");
                publicacion = await Task.Run(() => almacen.Leer(elegida), cancelacion);
                cancelacion.ThrowIfCancellationRequested();
                ComprobarClienteActual(cliente);
                resumen = elegida;
            }
            else
            {
                var activo = pestanasProyectos.SelectedTab?.Tag as EditorForm;
                MYGProyectoDocumento? documentoActual = activo?.DocumentoParaPublicar();
                using var dialogo = new NubePublicarForm(documentoActual, activo?.RutaProyecto);
                if (dialogo.ShowDialog(ventana) != WinForms.DialogResult.OK) return;
                ComprobarClienteActual(cliente);
                cancelacion.ThrowIfCancellationRequested();
                var documento = dialogo.Documento ?? throw new InvalidOperationException("Seleccione un proyecto.");
                string nombre = dialogo.Nombre, alcance = dialogo.Alcance;
                string? origen = dialogo.RutaSQLite;
                string? temporal = string.IsNullOrWhiteSpace(origen)
                    ? Path.Combine(pendientes, Guid.NewGuid().ToString("N") + ".sqlite") : null;
                try
                {
                    ventana.InformarProgresoPublicacion("Preparando SQLite y el paquete compacto");
                    var contenido = await Task.Run(() =>
                    {
                        cancelacion.ThrowIfCancellationRequested();
                        if (temporal is not null) MYGProyectoStorage.Guardar(temporal, documento);
                        cancelacion.ThrowIfCancellationRequested();
                        return PaqueteNube.CrearContenido(documento, temporal ?? origen!, alcance, compacto: true);
                    }, cancelacion);
                    // Las operaciones de SQLite/JSON ya iniciadas terminan su fase;
                    // cancelar impide guardar o enviar después de esa preparación.
                    cancelacion.ThrowIfCancellationRequested();
                    ComprobarClienteActual(cliente);
                    if (contenido.TryGetProperty("avisos", out var avisos) && avisos.ValueKind == JsonValueKind.Array)
                    {
                        string detalle = string.Join(Environment.NewLine, avisos.EnumerateArray().Select(a => a.GetString()));
                        if (!string.IsNullOrWhiteSpace(detalle) && WinForms.MessageBox.Show(ventana,
                            "Revise el alcance antes de publicar:" + Environment.NewLine + Environment.NewLine + detalle,
                            "Publicar en Nube MYG", WinForms.MessageBoxButtons.OKCancel, WinForms.MessageBoxIcon.Information)
                            != WinForms.DialogResult.OK) return;
                    }
                    ComprobarClienteActual(cliente);
                    cancelacion.ThrowIfCancellationRequested();
                    publicacion = new(Guid.NewGuid(), nombre, alcance, contenido)
                    { BytesSQLiteOriginal = new FileInfo(temporal ?? origen!).Length };
                    ventana.InformarProgresoPublicacion("Guardando el intento para poder reanudarlo");
                    await Task.Run(() => almacen.Guardar(publicacion), cancelacion);
                    cancelacion.ThrowIfCancellationRequested();
                    ComprobarClienteActual(cliente);
                    resumen = await Task.Run(almacen.Consultar, cancelacion)
                        ?? throw new InvalidDataException("No se encontró la publicación recién guardada. Revise Publicaciones pendientes.");
                    if (resumen.Id != publicacion.Id)
                        throw new InvalidOperationException("La publicación pendiente cambió desde otra ventana. Revise Publicaciones pendientes antes de continuar.");
                    ComprobarClienteActual(cliente);
                }
                finally { if (temporal is not null && File.Exists(temporal)) File.Delete(temporal); }
            }
            cancelacion.ThrowIfCancellationRequested();
            ComprobarClienteActual(cliente);
            if (resumen!.BytesArchivo > 127L * 1024 * 1024
                && !ConfirmarPublicacionGrande(ventana, resumen))
            {
                ventana.InformarResultadoPublicacion("No se inició otro envío. El intento sigue guardado con el mismo "
                    + "identificador en Publicaciones pendientes.");
                return;
            }
            cancelacion.ThrowIfCancellationRequested();
            ComprobarClienteActual(cliente);
            ventana.InformarProgresoPublicacion("Preparando los adjuntos de la publicación");
            var contenidoRed = await Task.Run(() => cliente.PrepararArchivosAsync(
                publicacion.Contenido, publicacion.Id, cancelacion), cancelacion);
            cancelacion.ThrowIfCancellationRequested();
            ComprobarClienteActual(cliente);
            ventana.InformarProgresoPublicacion("Comprobando y enviando el paquete; esperando confirmación");
            envioIniciado = true;
            var remoto = await Task.Run(() => cliente.CrearProyectoConfirmacionAsync(publicacion.Id,
                publicacion.Nombre, contenidoRed, publicacion.Alcance, cancelacion), cancelacion);
            confirmado = true;
            ventana.PublicacionConfirmada();
            ComprobarClienteActual(cliente);
            // El ACK ya confirma la identidad del proyecto y la creación original.
            // No cancelar este cierre por una pulsación que coincidiera con el ACK.
            try { await Task.Run(() => almacen.Confirmar(resumen!)); }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidOperationException)
            {
                throw new InvalidOperationException("El proyecto ya está confirmado en la nube, pero no se pudo cerrar su intento local. "
                    + "Revise Mis proyectos y Publicaciones pendientes antes de crear otro.", ex);
            }
            ComprobarClienteActual(cliente);
            ventana.InformarProgresoPublicacion("Actualizando el listado de proyectos publicados");
            try { await ventana.MostrarPublicacionConfirmadaAsync(remoto); }
            catch (Exception ex) when (ex is NubeException or IOException or InvalidOperationException)
            {
                throw new InvalidOperationException("La publicación quedó confirmada y se cerró su pendiente local, "
                    + "pero no se pudo actualizar el listado. Pulse Actualizar antes de crear otra publicación.", ex);
            }
            // Abrir es una acción separada: no descargar otros 200 MiB automáticamente.
        }
        catch (OperationCanceledException) when (cancelacion.IsCancellationRequested && !confirmado)
        {
            ventana.InformarResultadoPublicacion(envioIniciado
                ? "Se canceló la espera. Si el envío llegó al servidor, puede seguir procesándose. "
                    + "El intento conserva su identificador: revise Mis proyectos y reintente desde Publicaciones pendientes."
                : "La preparación se canceló. Si llegó a guardarse un intento, permanece en Publicaciones pendientes; "
                    + "la base SQLite de origen se conserva.");
        }
        finally { ventana.TerminarPublicacion(); }
    }

    private static bool ConfirmarPublicacionGrande(NubeForm ventana, ResumenPublicacionPendienteNube resumen)
    {
        using var aviso = new WinForms.Form
        {
            Name = "confirmarPublicacionGrandeNube", MaximizeBox = false, MinimizeBox = false,
            StartPosition = WinForms.FormStartPosition.CenterParent,
            FormBorderStyle = WinForms.FormBorderStyle.FixedDialog
        };
        MYGProyectoUI.Preparar(aviso, "Publicación grande", 650, 385);
        var raiz = new WinForms.TableLayoutPanel
        {
            Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new(24)
        };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 50));
        raiz.Controls.Add(new WinForms.Label
        {
            Dock = WinForms.DockStyle.Fill,
            Text = $"El paquete guardado ocupa {resumen.BytesArchivo / 1048576d:N1} MiB y supera 127 MiB. "
                + "El tamaño del envío puede bajar al preparar los adjuntos." + Environment.NewLine + Environment.NewLine
                + "El máximo de MYG es 300 MiB, pero no garantiza memoria ni tiempo suficientes en el servidor. "
                + "Una instancia con pocos recursos puede interrumpir la solicitud." + Environment.NewLine + Environment.NewLine
                + "Puede cancelar y publicar una sola obra de la base, o revisar los recursos y el estado de Supabase. "
                + "Si continúa, se usará el mismo identificador del intento guardado."
        }, 0, 0);
        var botones = new WinForms.FlowLayoutPanel
        {
            Dock = WinForms.DockStyle.Fill, FlowDirection = WinForms.FlowDirection.RightToLeft,
            WrapContents = false
        };
        var cancelar = MYGProyectoUI.Boton("Cancelar");
        cancelar.Name = "cancelarPublicacionGrande";
        cancelar.DialogResult = WinForms.DialogResult.Cancel;
        var continuar = MYGProyectoUI.Boton("Continuar", 1);
        continuar.Name = "continuarPublicacionGrande";
        continuar.DialogResult = WinForms.DialogResult.OK;
        botones.Controls.Add(cancelar); botones.Controls.Add(continuar);
        raiz.Controls.Add(botones, 0, 1); aviso.Controls.Add(raiz);
        // Enter y Escape conservan el pendiente; continuar requiere elegirlo.
        aviso.AcceptButton = cancelar; aviso.CancelButton = cancelar;
        aviso.Shown += (_, _) => cancelar.Select();
        return aviso.ShowDialog(ventana) == WinForms.DialogResult.OK;
    }

    private async Task DescargarProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        using var dialogo = new WinForms.SaveFileDialog
        {
            Title = "Descargar copia independiente confirmada", Filter = "Paquete con recursos (*.zip)|*.zip|Base SQLite (*.sqlite)|*.sqlite",
            FileName = "MYG_NUBE.zip", AddExtension = true, OverwritePrompt = true
        };
        if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
        string destino = dialogo.FileName;
        bool zip = string.Equals(Path.GetExtension(destino), ".zip", StringComparison.OrdinalIgnoreCase);
        Guid proyectoId = seleccionado.Id;
        if (File.Exists(destino)) throw new InvalidOperationException("Elija un nombre nuevo para conservar el archivo existente.");
        ComprobarClienteActual(cliente);
        var remoto = await Task.Run(() => cliente.AbrirProyectoAsync(proyectoId));
        ComprobarClienteActual(cliente);
        JsonElement contenido = remoto.Contenido;
        var contenidoCargado = await Task.Run(() => cliente.CargarArchivosAsync(contenido));
        ComprobarClienteActual(cliente);
        await Task.Run(() => PaqueteNube.Descargar(contenidoCargado, destino, zip));
        ComprobarClienteActual(cliente);
        WinForms.MessageBox.Show(ventanaNube, "Copia independiente descargada desde la revisión " + remoto.Revision + ".",
            "Nube MYG", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information);
    }

}
