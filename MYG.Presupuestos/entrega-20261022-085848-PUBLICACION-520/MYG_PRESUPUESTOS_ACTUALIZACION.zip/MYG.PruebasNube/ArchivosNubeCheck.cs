using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

internal static class ArchivosNubeCheck
{
    private static readonly Guid Usuario = Guid.Parse("11111111-2222-4333-8444-555555555555");
    private static readonly Guid OtroUsuario = Guid.Parse("99999999-2222-4333-8444-555555555555");
    private static readonly Guid Lote = Guid.Parse("aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee");
    private static readonly byte[] Archivo = Encoding.UTF8.GetBytes("Adjunto MYG con caracteres áé y contenido portable.");
    private static readonly string Hash = Convert.ToHexString(SHA256.HashData(Archivo)).ToLowerInvariant();
    private static readonly string Ruta = Usuario.ToString("D") + "/" + Lote.ToString("N") + "/" + Hash;
    private const string Endpoint = "/storage/v1/object/myg-nube-archivos/";
    private static int comprobaciones;

    public static async Task RunAsync()
    {
        comprobaciones = 0;
        await SubidaYDescarga();
        await ReferenciasExistentesYLegado();
        await ReintentoInmutable();
        await Renovacion();
        await IdentidadCambiada();
        await EntradasInvalidas();
        await DescargasInvalidas();
        await SinSesionYRevocacion();
        await SinAdjuntos();
        await RenovacionSinAdjuntos();
        Console.WriteLine($"OK Archivos privados: 10 casos y {comprobaciones} comprobaciones; HTTP simulado, sin red.");
    }

    private static JsonElement Paquete(string? almacen = null, string? base64 = null, string? hash = null) =>
        JsonSerializer.SerializeToElement(new
        {
            formato = "MYG_COLABORACION", version = 1, documento = new { Nombre = "Obra original" },
            recursos = new[] { new { Referencia = "C:/obra/plano.pdf", Nombre = "plano.pdf",
                Sha256 = hash ?? Hash.ToUpperInvariant(), Base64 = base64 ?? Convert.ToBase64String(Archivo), Almacen = almacen } }
        });

    private static JsonElement Recurso(JsonElement contenido) => contenido.GetProperty("recursos")[0];
    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Archivos: " + detalle);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException ex) { comprobaciones++; return ex; }
        throw new InvalidOperationException("Archivos: se esperaba rechazo de NubeException.");
    }

    private static HttpResponseMessage Json(object contenido, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    { Content = new StringContent(JsonSerializer.Serialize(contenido), Encoding.UTF8, "application/json") };

    private static HttpResponseMessage Autenticacion(string token = "sesion_archivos", Guid? usuario = null) => Json(new
    {
        access_token = token, refresh_token = "refresco_archivos", expires_in = 3600,
        user = new { id = usuario ?? Usuario }
    });

    private static HttpResponseMessage Binario(byte[]? bytes = null) => new(HttpStatusCode.OK)
    { Content = new ByteArrayContent(bytes ?? Archivo) };

    private static async Task<(ClienteSupabase Cliente, Transporte Transporte)> Conectar(TimeProvider? reloj = null)
    {
        var transporte = new Transporte();
        transporte.Paso((peticion, _) =>
        {
            Exige(peticion.RequestUri?.PathAndQuery == "/auth/v1/token?grant_type=password", "ruta de autenticación incorrecta.");
            return Task.FromResult(Autenticacion());
        });
        var cliente = new ClienteSupabase("https://archivos.supabase.co", "sb_publishable_pruebas_archivos", transporte, reloj);
        await cliente.IniciarSesionAsync("cuenta@example.test", "contraseña_solo_memoria");
        return (cliente, transporte);
    }

    private static async Task SubidaYDescarga()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso(async (peticion, ct) =>
            {
                Exige(peticion.Method == HttpMethod.Post && peticion.RequestUri?.AbsolutePath == Endpoint + Ruta,
                    "la subida no usó una ruta canónica de usuario/lote/huella.");
                Exige(peticion.Headers.Authorization?.Parameter == "sesion_archivos", "la subida no usó la sesión de la cuenta.");
                Exige(peticion.Headers.Contains("apikey") && !peticion.Headers.Contains("x-upsert"), "se perdió la clave pública o se permitió reemplazar objetos.");
                Exige(peticion.Content?.Headers.ContentType?.MediaType == "application/octet-stream"
                    && peticion.Content.Headers.ContentType.CharSet is null, "el binario recibió codificación de texto.");
                Exige((await peticion.Content!.ReadAsByteArrayAsync(ct)).SequenceEqual(Archivo), "la subida cambió los bytes del adjunto.");
                return Json(new { Key = Ruta });
            });
            JsonElement original = Paquete();
            JsonElement preparado = await cliente.PrepararArchivosAsync(original, Lote);
            Exige(Recurso(preparado).GetProperty("Base64").GetString() == "" && Recurso(preparado).GetProperty("Almacen").GetString() == Ruta,
                "el paquete remoto conserva bytes o perdió la referencia privada.");
            Exige(Recurso(original).GetProperty("Base64").GetString() == Convert.ToBase64String(Archivo)
                && Recurso(original).GetProperty("Almacen").ValueKind == JsonValueKind.Null, "se alteró el paquete original.");
            Exige(preparado.GetProperty("documento").GetProperty("Nombre").GetString() == "Obra original", "se perdió contenido ajeno a los adjuntos.");
            transporte.Paso((peticion, _) =>
            {
                Exige(peticion.Method == HttpMethod.Get && peticion.RequestUri?.AbsolutePath == Endpoint + Ruta
                    && peticion.Headers.Authorization?.Parameter == "sesion_archivos", "la descarga privada no usó la sesión y ruta previstas.");
                return Task.FromResult(Binario());
            });
            JsonElement cargado = await cliente.CargarArchivosAsync(preparado);
            Exige(Recurso(cargado).GetProperty("Base64").GetString() == Convert.ToBase64String(Archivo), "no se materializaron los bytes verificados.");
            Exige(Recurso(preparado).GetProperty("Base64").GetString() == "", "la descarga mutó el paquete remoto original.");
            transporte.Completo();
        }
    }

    private static async Task ReferenciasExistentesYLegado()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            string otroOrigen = Ruta.Replace(Usuario.ToString("D"), OtroUsuario.ToString("D"), StringComparison.Ordinal);
            var remoto = Paquete(otroOrigen, "");
            var preparado = await cliente.PrepararArchivosAsync(remoto, Lote);
            Exige(Recurso(preparado).GetProperty("Almacen").GetString() == otroOrigen, "se cambió una referencia existente de un colaborador.");
            var hidratado = Paquete(otroOrigen);
            preparado = await cliente.PrepararArchivosAsync(hidratado, Lote);
            Exige(Recurso(preparado).GetProperty("Base64").GetString() == "", "se volvieron a subir bytes de un objeto inmutable ya verificado.");
            var cacheado = await cliente.CargarArchivosAsync(hidratado);
            Exige(JsonElement.DeepEquals(cacheado, hidratado), "el adjunto ya hidratado y verificado se alteró en la caché local.");
            await Rechaza(async () => await cliente.CargarArchivosAsync(Paquete(otroOrigen, Convert.ToBase64String(new byte[] { 1, 2, 3 }))));
            var legado = Paquete();
            var cargado = await cliente.CargarArchivosAsync(legado);
            Exige(JsonElement.DeepEquals(cargado, legado), "se alteró un paquete local anterior válido.");
            transporte.Paso((peticion, _) =>
            {
                Exige(peticion.RequestUri?.AbsolutePath == Endpoint + otroOrigen, "se restringió la descarga al autor local en vez de la membresía del servidor.");
                return Task.FromResult(Binario());
            });
            await cliente.CargarArchivosAsync(remoto);
            transporte.Completo();
        }
    }

    private static async Task ReintentoInmutable()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso((_, _) => Task.FromResult(Json(new { error = "Duplicate" }, HttpStatusCode.Conflict)));
            transporte.Paso((peticion, _) =>
            {
                Exige(peticion.Method == HttpMethod.Get && peticion.RequestUri?.AbsolutePath == Endpoint + Ruta, "un reintento intentó sobrescribir el objeto existente.");
                return Task.FromResult(Binario());
            });
            var preparado = await cliente.PrepararArchivosAsync(Paquete(), Lote);
            Exige(Recurso(preparado).GetProperty("Almacen").GetString() == Ruta, "el reintento cambió la ruta inmutable.");
            transporte.Paso((_, _) => Task.FromResult(Json(new { error = "Duplicate" }, HttpStatusCode.Conflict)));
            transporte.Paso((_, _) => Task.FromResult(Binario(new byte[] { 1, 2, 3 })));
            await Rechaza(async () => await cliente.PrepararArchivosAsync(Paquete(), Lote));
            transporte.Completo();
        }
    }

    private static async Task Renovacion()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            byte[]? intento = null;
            transporte.Paso(async (peticion, ct) =>
            {
                intento = await peticion.Content!.ReadAsByteArrayAsync(ct);
                Exige(peticion.Headers.Authorization?.Parameter == "sesion_archivos", "el primer intento usó una sesión diferente.");
                return Json(new { code = "PGRST301" }, HttpStatusCode.Unauthorized);
            });
            transporte.Paso((peticion, _) =>
            {
                Exige(peticion.RequestUri?.Query == "?grant_type=refresh_token" && peticion.Headers.Authorization is null,
                    "la renovación filtró una sesión o usó la ruta equivocada.");
                return Task.FromResult(Autenticacion("sesion_renovada"));
            });
            transporte.Paso(async (peticion, ct) =>
            {
                Exige(peticion.Headers.Authorization?.Parameter == "sesion_renovada" && peticion.RequestUri?.AbsolutePath == Endpoint + Ruta,
                    "la renovación cambió el destino o no usó el acceso renovado.");
                byte[] repetido = await peticion.Content!.ReadAsByteArrayAsync(ct);
                Exige(intento!.SequenceEqual(repetido), "la renovación cambió los bytes de la subida pendiente.");
                Exige(peticion.Content.Headers.ContentType?.MediaType == "application/octet-stream"
                    && peticion.Content.Headers.ContentType.CharSet is null, "el reintento perdió el tipo binario.");
                return Json(new { Key = Ruta });
            });
            await cliente.PrepararArchivosAsync(Paquete(), Lote);
            transporte.Completo();
        }
    }

    private static async Task IdentidadCambiada()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso((_, _) => Task.FromResult(Json(new { code = "PGRST301" }, HttpStatusCode.Unauthorized)));
            transporte.Paso((_, _) => Task.FromResult(Autenticacion("sesion_ajena", OtroUsuario)));
            var error = await Rechaza(async () => await cliente.PrepararArchivosAsync(Paquete(), Lote));
            Exige(error.NecesitaIniciarSesion && !cliente.SesionIniciada, "se reenviaron archivos bajo otra identidad.");
            transporte.Completo();
        }
    }

    private static async Task EntradasInvalidas()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            await Rechaza(async () => await cliente.PrepararArchivosAsync(Paquete(), Guid.Empty));
            await Rechaza(async () => await cliente.PrepararArchivosAsync(Paquete(hash: new string('0', 64)), Lote));
            await Rechaza(async () => await cliente.PrepararArchivosAsync(Paquete(base64: "no-es-base64"), Lote));
            string[] rutasInvalidas = { "https://ajeno.example/archivo", "../archivo", Ruta + "/otro", Ruta.Replace("/", "%2F"),
                Ruta.Replace(Lote.ToString("N"), "..", StringComparison.Ordinal), Ruta[..^64] + new string('0', 64) };
            foreach (string ruta in rutasInvalidas)
                await Rechaza(async () => await cliente.CargarArchivosAsync(Paquete(ruta, "")));
            string excesivo = new('A', ((20 * 1024 * 1024 + 2) / 3) * 4 + 4);
            await Rechaza(async () => await cliente.PrepararArchivosAsync(Paquete(base64: excesivo), Lote));
            using var invalido = JsonDocument.Parse("{\"recursos\":{}}");
            await Rechaza(async () => await cliente.PrepararArchivosAsync(invalido.RootElement, Lote));
            foreach (string json in new[]
            {
                "{\"recursos\":null}", "{\"recursos\":1}",
                "{\"recursos\":[],\"recursos\":[{}]}", "{\"recursos\":[{}],\"recursos\":[]}",
                "{\"recursos\":[" + string.Join(',', Enumerable.Repeat("{}", 4097)) + "]}"
            })
            {
                using var malformado = JsonDocument.Parse(json);
                await Rechaza(async () => await cliente.PrepararArchivosAsync(malformado.RootElement, Lote));
                await Rechaza(async () => await cliente.CargarArchivosAsync(malformado.RootElement));
            }
            transporte.Completo();
        }
    }

    private static async Task DescargasInvalidas()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso((_, _) => Task.FromResult(Binario(new byte[] { 4, 5, 6 })));
            await Rechaza(async () => await cliente.CargarArchivosAsync(Paquete(Ruta, "")));
            transporte.Paso((_, _) =>
            {
                var respuesta = Binario(Array.Empty<byte>());
                respuesta.Content.Headers.ContentLength = 20 * 1024 * 1024 + 1;
                return Task.FromResult(respuesta);
            });
            await Rechaza(async () => await cliente.CargarArchivosAsync(Paquete(Ruta, "")));
            transporte.Paso((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                { Content = new StreamContent(new FlujoExcesivo(20 * 1024 * 1024 + 1)) }));
            await Rechaza(async () => await cliente.CargarArchivosAsync(Paquete(Ruta, "")));
            using var cancelado = new CancellationTokenSource(); cancelado.Cancel();
            try { await cliente.CargarArchivosAsync(Paquete(Ruta, ""), cancelado.Token); throw new InvalidOperationException("No se canceló la descarga."); }
            catch (OperationCanceledException) { comprobaciones++; }
            transporte.Completo();
        }
    }

    private static async Task SinSesionYRevocacion()
    {
        using (var transporte = new Transporte())
        using (var cliente = new ClienteSupabase("https://archivos.supabase.co", "sb_publishable_pruebas_archivos", transporte))
        {
            var error = await Rechaza(async () => await cliente.CargarArchivosAsync(Paquete(Ruta, "")));
            Exige(error.NecesitaIniciarSesion, "la descarga no exigió autenticación.");
            var vacio = JsonSerializer.SerializeToElement(new { recursos = Array.Empty<object>() });
            error = await Rechaza(async () => await cliente.CargarArchivosAsync(vacio));
            Exige(error.NecesitaIniciarSesion, "el camino sin adjuntos omitió la sesión al descargar.");
            error = await Rechaza(async () => await cliente.PrepararArchivosAsync(vacio, Lote));
            Exige(error.NecesitaIniciarSesion, "el camino sin adjuntos omitió la sesión al preparar.");
            transporte.Completo();
        }
        var (conectado, servidor) = await Conectar();
        using (conectado)
        {
            servidor.Paso((_, _) => Task.FromResult(Json(new { code = "42501", message = "detalle privado que no debe mostrarse" }, HttpStatusCode.Forbidden)));
            var error = await Rechaza(async () => await conectado.CargarArchivosAsync(Paquete(Ruta, "")));
            Exige(error.AccesoDenegado && !error.Message.Contains("detalle privado", StringComparison.Ordinal), "la revocación concedió acceso o filtró la respuesta privada.");
            servidor.Completo();
        }
    }

    private static async Task SinAdjuntos()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            // Un paquete ya congelado sin archivos no necesita convertir 4 MiB
            // a UTF-16, reconstruir un JsonNode ni volver a serializarlo.
            var original = JsonSerializer.SerializeToElement(new
            {
                documento = new { Nombre = "sin adjuntos", contenido = new string('x', 4 * 1024 * 1024) },
                recursos = Array.Empty<object>()
            });
            long inicio = GC.GetAllocatedBytesForCurrentThread();
            var preparado = await cliente.PrepararArchivosAsync(original, Lote);
            var cargado = await cliente.CargarArchivosAsync(preparado);
            long asignados = GC.GetAllocatedBytesForCurrentThread() - inicio;
            Exige(asignados < 2 * 1024 * 1024,
                "el camino sin adjuntos creó copias completas del contenido del proyecto.");
            Exige(JsonElement.DeepEquals(original, cargado)
                && cargado.GetProperty("documento").GetProperty("contenido").GetString()?.Length == 4 * 1024 * 1024,
                "omitir el trabajo de adjuntos cambió o truncó el resto del paquete.");
            var legado = JsonSerializer.SerializeToElement(new { documento = new { Nombre = "sin campo recursos" } });
            Exige(JsonElement.DeepEquals(await cliente.PrepararArchivosAsync(legado, Lote), legado)
                && JsonElement.DeepEquals(await cliente.CargarArchivosAsync(legado), legado),
                "el formato legado sin recursos perdió su contenido o su compatibilidad.");

            JsonElement independiente;
            using (var propietario = JsonDocument.Parse("{\"documento\":{\"Nombre\":\"propietario temporal\"},\"recursos\":[]}"))
                independiente = await cliente.CargarArchivosAsync(propietario.RootElement);
            Exige(independiente.GetProperty("documento").GetProperty("Nombre").GetString() == "propietario temporal",
                "el resultado sin adjuntos dependió de la vida del JsonDocument del llamador.");

            using var cancelado = new CancellationTokenSource(); cancelado.Cancel();
            foreach (bool preparar in new[] { true, false })
            {
                try
                {
                    if (preparar) await cliente.PrepararArchivosAsync(original, Lote, cancelado.Token);
                    else await cliente.CargarArchivosAsync(original, cancelado.Token);
                    throw new InvalidOperationException("No se canceló la operación sin adjuntos.");
                }
                catch (OperationCanceledException) { comprobaciones++; }
            }
            Exige(cliente.SesionIniciada && cliente.UsuarioId == Usuario.ToString("D"),
                "cancelar una preparación vacía cerró o cambió la sesión.");
            transporte.Paso((peticion, _) =>
            {
                Exige(peticion.RequestUri?.AbsolutePath == "/rest/v1/rpc/myg_nube_capacidades",
                    "un compacto vacío omitió la comprobación de capacidades.");
                return Task.FromResult(Json(new { paquete_compacto = 2, cambios = 1, max_contenido_mib = 300 }));
            });
            using var compacto = JsonDocument.Parse("{\"formato\":\"MYG_COLABORACION\",\"version\":2,\"recursos\":[]}");
            await cliente.PrepararArchivosAsync(compacto.RootElement, Lote);
            transporte.Completo();
            Console.WriteLine($"OK Adjuntos vacíos: 4 MiB preservados, {asignados:N0} bytes asignados, sin transferencias Storage.");
        }
    }

    private static async Task RenovacionSinAdjuntos()
    {
        var reloj = new Reloj();
        var (cliente, transporte) = await Conectar(reloj);
        using (cliente)
        {
            reloj.Ahora = reloj.Ahora.AddHours(2);
            transporte.Paso((peticion, _) =>
            {
                Exige(peticion.RequestUri?.Query == "?grant_type=refresh_token",
                    "el camino sin adjuntos ignoró la renovación de sesión.");
                return Task.FromResult(Autenticacion("sesion_ajena", OtroUsuario));
            });
            var vacio = JsonSerializer.SerializeToElement(new { recursos = Array.Empty<object>() });
            var error = await Rechaza(async () => await cliente.CargarArchivosAsync(vacio));
            Exige(error.NecesitaIniciarSesion && !cliente.SesionIniciada,
                "la operación vacía aceptó una renovación con otra identidad.");
            transporte.Completo();
        }
    }

    private sealed class Reloj : TimeProvider
    {
        internal DateTimeOffset Ahora { get; set; } = new(2026, 10, 22, 12, 0, 0, TimeSpan.Zero);
        public override DateTimeOffset GetUtcNow() => Ahora;
    }

    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>>> pasos = new();
        internal void Paso(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> respuesta) => pasos.Enqueue(respuesta);
        internal void Completo() => Exige(pasos.Count == 0, "quedaron solicitudes esperadas sin ejecutar.");
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if (pasos.Count == 0) throw new InvalidOperationException("Archivos: transporte recibió una solicitud inesperada.");
            return pasos.Dequeue()(request, cancellationToken);
        }
    }

    private sealed class FlujoExcesivo(long restantes) : Stream
    {
        public override bool CanRead => true;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
        public override int Read(byte[] buffer, int offset, int count)
        {
            int cantidad = (int)Math.Min(restantes, count); restantes -= cantidad;
            buffer.AsSpan(offset, cantidad).Clear(); return cantidad;
        }
        public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            int cantidad = (int)Math.Min(restantes, buffer.Length); restantes -= cantidad;
            buffer.Span[..cantidad].Clear(); return ValueTask.FromResult(cantidad);
        }
        public override void Flush() => throw new NotSupportedException();
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
    }
}
