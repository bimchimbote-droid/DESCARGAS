using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

internal static class DiagnosticoRecursosNubeCheck
{
    private const string Servidor = "https://diagnostico.supabase.co";
    private static readonly Guid Usuario = Guid.Parse("7a3b2c8a-1d5c-4cb7-8e8e-a91edcb2382b");
    private static readonly Guid Proyecto = Guid.Parse("da83ec3c-7633-443e-a261-a782915831ff");
    private static readonly Guid Operacion = Guid.Parse("af448c02-cd0c-4ce6-bd8b-51a8052879de");
    private const string Referencia = "e16529aa-08d8-4c83-8d88-58309d977594";
    private const string Secreto = "token_remoto_que_no_se_puede_mostrar";
    private static int comprobaciones;

    public static async Task RunAsync()
    {
        comprobaciones = 0;
        foreach (var caso in new[]
        {
            (Codigo: "57014", Esperado: "canceló la operación"),
            (Codigo: "53200", Esperado: "memoria suficiente"),
            (Codigo: "53300", Esperado: "máximo de conexiones"),
            (Codigo: "53400", Esperado: "límite de recursos"),
            (Codigo: "57P01", Esperado: "recuperando"),
            (Codigo: "57P02", Esperado: "recuperando"),
            (Codigo: "57P03", Esperado: "recuperando"),
            (Codigo: "PGRST000", Esperado: "conexión con PostgreSQL"),
            (Codigo: "PGRST001", Esperado: "se interrumpió"),
            (Codigo: "PGRST002", Esperado: "conexión con PostgreSQL"),
            (Codigo: "PGRST003", Esperado: "conexión disponible"),
            (Codigo: "55006", Esperado: "publicación en curso")
        })
        {
            using var transporte = new Transporte();
            using var cliente = await Autenticar(transporte);
            transporte.Respuesta = () =>
            {
                var respuesta = Json(new
                {
                    code = caso.Codigo,
                    message = caso.Codigo == "55006" ? "MYG_PUBLICACION_EN_CURSO" : Secreto,
                    details = Secreto, hint = "https://no-publicar.example/" + Secreto,
                    access_token = Secreto
                }, HttpStatusCode.InternalServerError);
                respuesta.Headers.TryAddWithoutValidation("sb-request-id", Referencia.ToUpperInvariant());
                return respuesta;
            };
            var error = await GuardarYRechazar(cliente);
            Exige(error.Codigo == caso.Codigo && error.EsErrorDeConexion && !error.NecesitaIniciarSesion
                && !error.AccesoDenegado && error.Message.Contains(caso.Esperado, StringComparison.Ordinal),
                "No clasificó correctamente el fallo de recursos " + caso.Codigo);
            Exige(error.Message.Contains("HTTP 500", StringComparison.Ordinal)
                && error.Message.Contains(caso.Codigo, StringComparison.Ordinal)
                && error.Message.Contains(Referencia, StringComparison.Ordinal)
                && !error.Message.Contains(Secreto, StringComparison.Ordinal)
                && !error.Message.Contains("https://", StringComparison.Ordinal),
                "El diagnóstico omitió códigos/referencia o mostró contenido remoto.");
            Exige(cliente.SesionIniciada && cliente.UsuarioId == Usuario.ToString("D") && transporte.Peticiones == 2,
                "El fallo de recursos cambió identidad, cerró sesión o reenvió automáticamente la escritura.");
        }
        await RespuestasNoConfiables();
        Console.WriteLine($"OK Diagnóstico de recursos: {comprobaciones} comprobaciones HTTP simulado, privacidad, límites y sesión.");
    }

    private static void Exige(bool condicion, string mensaje)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Diagnóstico de recursos: " + mensaje);
    }

    private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    {
        Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json")
    };

    private static async Task<ClienteSupabase> Autenticar(Transporte transporte)
    {
        var cliente = new ClienteSupabase(Servidor, "sb_publishable_diagnostico_sintetico", transporte);
        transporte.Respuesta = () => Json(new
        {
            access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600,
            user = new { id = Usuario }
        });
        await cliente.IniciarSesionAsync("prueba@example.test", "clave_sintetica");
        return cliente;
    }

    private static async Task<NubeException> GuardarYRechazar(ClienteSupabase cliente)
    {
        using var contenido = JsonDocument.Parse("{\"formato_sintetico\":true}");
        try { await cliente.GuardarProyectoAsync(Proyecto, Operacion, 1, contenido.RootElement); }
        catch (NubeException error) { return error; }
        throw new InvalidOperationException("Se aceptó un error de servidor como confirmación.");
    }

    private static async Task RespuestasNoConfiables()
    {
        using var transporte = new Transporte();
        using var cliente = await Autenticar(transporte);
        foreach (string cuerpo in new[]
        {
            "<html>" + Secreto + "</html>", "{\"code\":", "[]",
            JsonSerializer.Serialize(new { code = Secreto, message = Secreto, access_token = Secreto })
        })
        {
            transporte.Respuesta = () =>
            {
                var respuesta = new HttpResponseMessage(HttpStatusCode.ServiceUnavailable)
                { Content = new StringContent(cuerpo, Encoding.UTF8, "application/json") };
                respuesta.Headers.TryAddWithoutValidation("sb-request-id", "https://" + Secreto + ".example/");
                respuesta.Headers.TryAddWithoutValidation("x-request-id", Secreto);
                respuesta.Headers.TryAddWithoutValidation("sb-error-code", Secreto);
                return respuesta;
            };
            var error = await GuardarYRechazar(cliente);
            Exige(error.Codigo is null && error.EsErrorDeConexion && !error.NecesitaIniciarSesion
                && error.Message.Contains("HTTP 503", StringComparison.Ordinal)
                && !error.Message.Contains(Secreto, StringComparison.Ordinal)
                && !error.Message.Contains("Referencia", StringComparison.Ordinal),
                "Filtró un cuerpo, código arbitrario o cabecera no permitida.");
        }

        transporte.Respuesta = () =>
        {
            var respuesta = new HttpResponseMessage((HttpStatusCode)520)
            {
                Content = new StringContent("<html>Cloudflare: error de origen " + Secreto + "</html>", Encoding.UTF8, "text/html")
            };
            respuesta.Headers.TryAddWithoutValidation("sb-request-id", Referencia);
            respuesta.Headers.TryAddWithoutValidation("cf-ray", Secreto + "-LIM");
            return respuesta;
        };
        var origen = await GuardarYRechazar(cliente);
        Exige(origen.Codigo is null && origen.EsErrorDeConexion && !origen.NecesitaIniciarSesion && !origen.AccesoDenegado
            && origen.Message.Contains("HTTP 520", StringComparison.Ordinal) && origen.Message.Contains(Referencia, StringComparison.Ordinal),
            "El HTTP 520 de la pasarela perdió su estado, referencia o clasificación transitoria.");
        Exige(!origen.Message.Contains(Secreto, StringComparison.Ordinal)
            && !origen.Message.Contains("memoria", StringComparison.OrdinalIgnoreCase)
            && !origen.Message.Contains("300 MiB", StringComparison.Ordinal)
            && !origen.Message.Contains("sesión", StringComparison.OrdinalIgnoreCase)
            && cliente.SesionIniciada && cliente.UsuarioId == Usuario.ToString("D"),
            "Atribuyó el HTTP 520 a memoria, tamaño o autenticación sin evidencia, filtró HTML o alteró la sesión.");

        transporte.Respuesta = () =>
        {
            var respuesta = Json(new { error = Secreto }, HttpStatusCode.TooManyRequests);
            respuesta.Headers.RetryAfter = new RetryConditionHeaderValue(TimeSpan.FromDays(1));
            respuesta.Headers.TryAddWithoutValidation("sb-request-id", new[] { Referencia, Referencia });
            return respuesta;
        };
        var limitado = await GuardarYRechazar(cliente);
        Exige(limitado.EsErrorDeConexion && limitado.Codigo is null && limitado.Message.Contains("300 segundos", StringComparison.Ordinal)
            && limitado.Message.Contains("HTTP 429", StringComparison.Ordinal) && !limitado.Message.Contains("Referencia", StringComparison.Ordinal),
            "Retry-After no quedó acotado o aceptó referencias múltiples.");
        transporte.Respuesta = () => Json(new { code = "55006", message = Secreto }, HttpStatusCode.Conflict);
        var ocupado = await GuardarYRechazar(cliente);
        Exige(ocupado.Codigo == "55006" && ocupado.Message.Contains("recurso necesario", StringComparison.Ordinal)
            && !ocupado.Message.Contains("publicación en curso", StringComparison.Ordinal),
            "Un 55006 genérico se confundió con el marcador de publicación.");
        Exige(cliente.SesionIniciada && cliente.UsuarioId == Usuario.ToString("D"),
            "Una respuesta defectuosa cerró o cambió la sesión del usuario.");
    }

    private sealed class Transporte : HttpMessageHandler
    {
        public Func<HttpResponseMessage>? Respuesta { get; set; }
        public int Peticiones { get; private set; }
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Exige(request.RequestUri?.Host == "diagnostico.supabase.co", "La prueba salió a otro servidor.");
            Peticiones++;
            if (Respuesta is null) throw new InvalidOperationException("Falta respuesta sintética.");
            return Task.FromResult(Respuesta());
        }
    }
}
