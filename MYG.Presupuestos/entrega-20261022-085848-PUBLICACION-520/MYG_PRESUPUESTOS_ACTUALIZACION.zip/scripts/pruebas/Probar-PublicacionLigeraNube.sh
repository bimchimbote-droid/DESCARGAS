#!/usr/bin/env bash
# Solo PostgreSQL desechable. No conecta a Supabase ni utiliza datos del usuario.
set -euo pipefail
repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
test_workspace=$(mktemp -d -t myg-publicacion-ligera-XXXXXXXX)
test_container=""
lock_session_pid=""
cleanup() {
    result=$?
    trap - EXIT
    if [[ -n "$lock_session_pid" ]]; then kill "$lock_session_pid" >/dev/null 2>&1 || true; fi
    if [[ -n "$test_container" ]]; then docker rm -f "$test_container" >/dev/null 2>&1 || true; fi
    rm -rf -- "$test_workspace"
    exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
command -v docker >/dev/null
command -v dotnet >/dev/null
docker version --format '{{.Server.Version}}'
postgres_test_image='postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
if ! docker image inspect "$postgres_test_image" >/dev/null 2>&1; then docker pull "$postgres_test_image"; fi
if [[ "${MYG_PRUEBAS_SIN_COMPILAR:-0}" == 1 ]]; then
    dotnet run --project "$repo_root/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" \
        -c Release --no-build --no-restore -- "$test_workspace/paquetes"
else
    dotnet run --project "$repo_root/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" \
        -c Release -- "$test_workspace/paquetes"
fi
test_container=$(docker run --detach --rm --network none --memory=2g --cpus=2 \
    --tmpfs /var/lib/postgresql/data:rw,size=1g \
    -e POSTGRES_HOST_AUTH_METHOD=trust "$postgres_test_image")
for attempt in {1..60}; do
    if docker exec "$test_container" pg_isready -U postgres >/dev/null 2>&1; then break; fi
    if [[ "$attempt" == 60 ]]; then docker logs "$test_container"; exit 1; fi
    sleep 1
done
docker exec -u root "$test_container" mkdir -p /pruebas
docker cp "$repo_root/supabase" "$test_container:/pruebas/supabase"
docker cp "$test_workspace/paquetes" "$test_container:/pruebas/paquetes"
docker exec -u root "$test_container" chmod -R a+rX /pruebas
psql_test() {
    docker exec -u postgres "$test_container" psql -X -d "$1" \
        -v MYG_PRUEBAS_DESECHABLES=1 -v ON_ERROR_STOP=1 "${@:2}"
}
psql_test postgres -f /pruebas/supabase/pruebas/usuarios_myg_roles.sql

# Cuatro estados: límite32, requisito127, instalación300 y yaactualizada ligera.
for nivel in 0 1 2 3; do
    test_database="myg_publicacion_ligera_$nivel"
    docker exec -u postgres "$test_container" createdb -U postgres -T postgres "$test_database"
    if (( nivel >= 1 )); then
        psql_test "$test_database" -f /pruebas/supabase/migraciones/20261021_contenido_grande.sql
    fi
    if (( nivel >= 2 )); then
        psql_test "$test_database" -f /pruebas/supabase/migraciones/20261025_limite_300_mib.sql
    fi
    if (( nivel == 3 )); then
        psql_test "$test_database" -f /pruebas/supabase/migraciones/20261026_publicacion_ligera.sql
    fi
    psql_test "$test_database" -f /pruebas/supabase/pruebas/publicacion_ligera.sql
    printf 'CASO PUBLICACIÓN LIGERA APROBADO: nivel previo %s\n' "$nivel"
done

# Otra conexión conserva el mismo bloqueo transaccional que un envío pendiente.
# Probarlo con un UUID todavía ausente comprueba tanto la sonda como el rechazo
# temprano de crear_confirmacion, sin esperar ni validar otro paquete grande.
locked_database='myg_publicacion_ligera_3'
locked_uuid='96000000-0000-0000-0000-000000000099'
psql_test "$locked_database" -c "BEGIN;
SELECT pg_advisory_xact_lock(hashtextextended('myg-nube-crear:$locked_uuid',0));
SELECT pg_sleep(10);
COMMIT;" > "$test_workspace/bloqueo.log" 2>&1 &
lock_session_pid=$!
for attempt in {1..60}; do
    busy=$(psql_test "$locked_database" -At -c \
        "SELECT NOT pg_try_advisory_xact_lock(hashtextextended('myg-nube-crear:$locked_uuid',0));")
    if [[ "$busy" == t ]]; then break; fi
    if [[ "$attempt" == 60 ]]; then cat "$test_workspace/bloqueo.log"; exit 1; fi
    sleep 0.1
done
psql_test "$locked_database" -c "
SET ROLE authenticated;
SET request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
SELECT qa.exige(public.myg_nube_estado_publicacion('$locked_uuid')='{\"estado\":\"procesando\"}'::jsonb,
    'Publicación ligera: sonda real detecta otro envío sin recibir su paquete');
DO \$\$ DECLARE v_estado text; v_mensaje text; v_inicio timestamptz:=clock_timestamp(); BEGIN
    BEGIN
        PERFORM public.myg_nube_crear_confirmacion('$locked_uuid','En curso','[]','base');
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_estado=returned_sqlstate,v_mensaje=message_text;
    END;
    PERFORM qa.exige(v_estado='55006' AND v_mensaje='MYG_PUBLICACION_EN_CURSO',
        'Publicación ligera: otro envío rechaza temprano antes de validar el contenido');
    PERFORM qa.exige(clock_timestamp()-v_inicio<interval '2 seconds',
        'Publicación ligera: otro envío no espera detrás del bloqueo de creación');
END \$\$;"
wait "$lock_session_pid"
lock_session_pid=""
psql_test "$locked_database" -c "
SET ROLE authenticated;
SET request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
SELECT qa.exige(public.myg_nube_estado_publicacion('$locked_uuid')='{\"estado\":\"disponible\"}'::jsonb,
    'Publicación ligera: el UUID vuelve a estar disponible al finalizar la otra llamada');
RESET ROLE;
SELECT qa.exige(NOT EXISTS(SELECT 1 FROM public.myg_nube_proyectos WHERE id='$locked_uuid'),
    'Publicación ligera: rechazo por envío en curso no deja un proyecto parcial');"

# Un retorno incompatible falla después de instalar la base y el primer RPC.
# La transacción debe revertir todos los pasos, sin capacidades a medio instalar.
docker exec -u postgres "$test_container" createdb -U postgres -T postgres myg_publicacion_ligera_fallo
psql_test myg_publicacion_ligera_fallo -c \
    "CREATE FUNCTION public.myg_nube_estado_publicacion(uuid) RETURNS text LANGUAGE sql AS 'SELECT ''incompatible''::text';"
if psql_test myg_publicacion_ligera_fallo -f /pruebas/supabase/migraciones/20261026_publicacion_ligera.sql \
    > "$test_workspace/rechazo-esperado.log" 2>&1; then
    cat "$test_workspace/rechazo-esperado.log"
    printf 'FALLO: se aceptó una instalación con un retorno incompatible.\n' >&2
    exit 1
fi
case "$(cat "$test_workspace/rechazo-esperado.log")" in
    *'cannot change return type of existing function'*) ;;
    *) cat "$test_workspace/rechazo-esperado.log"; exit 1 ;;
esac
psql_test myg_publicacion_ligera_fallo -c "
SELECT qa.exige(to_regprocedure('public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)') IS NULL,
    'Publicación ligera: rechazo revierte el primer RPC nuevo');
SELECT qa.exige(to_regprocedure('public.myg_nube_capacidades()') IS NULL
    AND to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)') IS NULL,
    'Publicación ligera: rechazo revierte la instalación base y sus capacidades');
SELECT qa.exige(public.myg_nube_estado_publicacion(gen_random_uuid())='incompatible'
    AND (SELECT strpos(prosrc,'MYG_CONTENIDO_INVALIDO_MAX_32_MIB')>0 FROM pg_proc
        WHERE oid='myg_nube_privado.validar_contenido(jsonb)'::regprocedure),
    'Publicación ligera: rechazo conserva las funciones y límites anteriores');"
printf 'PUBLICACIÓN LIGERA COMPLETADA: cuatro estados, bloqueo entre conexiones y rollback aprobados.\n'
