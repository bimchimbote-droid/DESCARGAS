#!/usr/bin/env python3
"""Prueba HTTP de confirmación pequeña en PostgreSQL desechable de 512 MiB.

Requiere Python 3, Docker y el SDK .NET del proyecto. Usa exclusivamente datos
sintéticos; no conecta a Supabase ni publica puertos. La prueba positiva de
8 MiB no demuestra que una instancia de 512 MiB pueda procesar paquetes de 200 MiB.
"""

import base64
import copy
import hashlib
import hmac
import json
import os
import pathlib
import signal
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid


REPO = pathlib.Path(__file__).resolve().parents[2]
POSTGRES = "postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939"
POSTGREST = "postgrest/postgrest:v16.5@sha256:1347d7552b88f17832912c06afbf7c43209af6eeeb60834b04aae12c9bd9d5cc"
SECRET = b"myg_synthetic_light_publication_http_secret_not_a_real_credential"
OWNER = "00000000-0000-0000-0000-000000000001"
OTHER = "00000000-0000-0000-0000-000000000003"
PROJECT = "97000000-0000-0000-0000-000000000001"
LOCKED_PROJECT = "97000000-0000-0000-0000-000000000099"


def run(*args, log=None):
    result = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if log is not None:
        log.write(result.stdout)
        log.flush()
    if result.returncode:
        raise RuntimeError(f"Falló {args[0]} ({result.returncode}): {result.stdout[-1500:]}")
    return result.stdout.strip()


def token(user):
    def b64(value):
        return base64.urlsafe_b64encode(value).rstrip(b"=")

    header = b64(b'{"alg":"HS256","typ":"JWT"}')
    claims = b64(json.dumps({"role": "authenticated", "sub": user, "exp": int(time.time()) + 3600}).encode())
    body = header + b"." + claims
    return (body + b"." + b64(hmac.new(SECRET, body, hashlib.sha256).digest())).decode()


def main():
    suffix = uuid.uuid4().hex[:12]
    network, database, api = ("myg-light-http-" + suffix + name for name in ("-red", "-pg", "-api"))
    containers = []
    created_network = False
    lock_process = None
    measurements = []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def stop(_signal, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, stop)
    try:
        with tempfile.TemporaryDirectory(prefix="myg-light-http-") as temporary:
            temporary = pathlib.Path(temporary)
            with (temporary / "preparacion.log").open("w") as log:
                for image in (POSTGRES, POSTGREST):
                    exists = subprocess.run(["docker", "image", "inspect", image], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    if exists.returncode:
                        run("docker", "pull", image, log=log)
                packages = temporary / "paquetes"
                fixture_command = ["dotnet", "run", "--project", str(REPO / "supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj"), "-c", "Release"]
                if os.environ.get("MYG_PRUEBAS_SIN_COMPILAR") == "1":
                    fixture_command.extend(["--no-build", "--no-restore"])
                run(*fixture_command, "--", str(packages), log=log)
                run("docker", "network", "create", "--internal", network, log=log)
                created_network = True
                run("docker", "run", "--detach", "--rm", "--name", database, "--network", network,
                    "--memory=512m", "--memory-swap=512m", "--cpus=2",
                    "--tmpfs", "/var/lib/postgresql/data:rw,size=128m",
                    "-e", "POSTGRES_HOST_AUTH_METHOD=trust", POSTGRES,
                    "-c", "shared_buffers=32MB", "-c", "max_connections=20", "-c", "work_mem=1MB", log=log)
                containers.append(database)
                for attempt in range(60):
                    ready = subprocess.run(["docker", "exec", database, "pg_isready", "-U", "postgres"],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    if ready.returncode == 0:
                        break
                    if attempt == 59:
                        raise RuntimeError("PostgreSQL desechable no inició.")
                    time.sleep(1)
                run("docker", "exec", "-u", "root", database, "mkdir", "-p", "/pruebas", log=log)
                run("docker", "cp", str(REPO / "supabase"), database + ":/pruebas/supabase", log=log)
                run("docker", "cp", str(packages), database + ":/pruebas/paquetes", log=log)
                run("docker", "exec", "-u", "root", database, "chmod", "-R", "a+rX", "/pruebas", log=log)

                def sql(*args):
                    return run("docker", "exec", "-u", "postgres", database, "psql", "-X",
                               "-v", "ON_ERROR_STOP=1", "-v", "MYG_PRUEBAS_DESECHABLES=1", *args, log=log)

                sql("-f", "/pruebas/supabase/pruebas/usuarios_myg_roles.sql")
                sql("-f", "/pruebas/supabase/migraciones/20261026_publicacion_ligera.sql")
                snapshot_sql = """
                    SELECT md5(jsonb_build_object(
                      'proyectos',(SELECT jsonb_agg(to_jsonb(p) ORDER BY id) FROM public.myg_nube_proyectos p),
                      'historial',(SELECT jsonb_agg(to_jsonb(h) ORDER BY proyecto_id,revision) FROM public.myg_nube_historial h),
                      'miembros',(SELECT jsonb_agg(to_jsonb(m) ORDER BY proyecto_id,usuario_id) FROM public.myg_nube_miembros m),
                      'operaciones',(SELECT jsonb_agg(to_jsonb(o) ORDER BY usuario_id,operacion_id) FROM public.myg_nube_operaciones o),
                      'funciones',(SELECT jsonb_agg(pg_get_functiondef(p.oid) ORDER BY p.oid) FROM pg_proc p
                        WHERE p.pronamespace IN ('public'::regnamespace,'myg_nube_privado'::regnamespace)))::text);
                    """
                before_diagnostic = sql("-At", "-c", snapshot_sql)
                sql("-f", "/pruebas/supabase/diagnosticos/20261026_publicacion_solo_lectura.sql")
                assert sql("-At", "-c", snapshot_sql) == before_diagnostic, "El diagnóstico modificó datos o funciones."
                # Adaptación exclusiva del fixture desechable a claims JSON de PostgREST.
                sql("-c", """
                    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
                      SELECT coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub',
                        nullif(current_setting('request.jwt.claim.sub',true),''))::uuid;
                    $$;
                    CREATE ROLE myg_light_http_login LOGIN NOINHERIT;
                    GRANT anon,authenticated TO myg_light_http_login;
                    """)
                run("docker", "run", "--detach", "--rm", "--name", api, "--network", network,
                    "--memory=512m", "--memory-swap=512m", "--cpus=2",
                    "-e", f"PGRST_DB_URI=postgres://myg_light_http_login@{database}:5432/postgres",
                    "-e", "PGRST_DB_SCHEMAS=public", "-e", "PGRST_DB_ANON_ROLE=anon",
                    "-e", "PGRST_JWT_SECRET=" + SECRET.decode(), POSTGREST, log=log)
                containers.append(api)
                address = run("docker", "inspect", api, "--format", "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}")
                url = f"http://{address}:3000/"
                for attempt in range(60):
                    try:
                        with opener.open(url, timeout=2) as response:
                            if response.status == 200:
                                break
                    except (urllib.error.URLError, TimeoutError):
                        pass
                    if attempt == 59:
                        raise RuntimeError("PostgREST desechable no inició.")
                    time.sleep(1)

                def rpc(name, body, user=OWNER, expected=200):
                    data = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode()
                    headers = {"Content-Type": "application/json"}
                    if user:
                        headers["Authorization"] = "Bearer " + token(user)
                    started = time.monotonic()
                    request = urllib.request.Request(url + "rpc/" + name, data=data, headers=headers, method="POST")
                    try:
                        with opener.open(request, timeout=60) as response:
                            status, content = response.status, response.read()
                    except urllib.error.HTTPError as error:
                        status, content = error.code, error.read()
                    parsed = json.loads(content)
                    if status != expected:
                        code = parsed.get("code", "sin código") if isinstance(parsed, dict) else "sin código"
                        raise AssertionError(f"{name}: HTTP {status}, esperado {expected}, código {code}")
                    elapsed = round(time.monotonic() - started, 3)
                    measurements.append({"rpc": name, "status": status, "request_bytes": len(data),
                                         "response_bytes": len(content), "seconds": elapsed})
                    print(f"OK HTTP {status} {name}: {len(data)} -> {len(content)} bytes; {elapsed}s", flush=True)
                    return parsed, measurements[-1]

                capabilities, _ = rpc("myg_nube_capacidades", {})
                assert capabilities["publicacion_ligera"] == 1 and capabilities["max_contenido_mib"] == 300
                state, _ = rpc("myg_nube_estado_publicacion", {"p_id": PROJECT})
                assert state == {"estado": "disponible"}
                rpc("myg_nube_estado_publicacion", {"p_id": PROJECT}, user=None, expected=401)
                rpc("myg_nube_crear_confirmacion", {"p_id": PROJECT, "p_nombre": "Anon", "p_contenido": {}, "p_alcance": "base"},
                    user=None, expected=401)

                package = json.loads((packages / "compacto_cliente.json").read_text())
                package["documento"]["CampoGrandePrueba"] = "x" * (8 * 1024 * 1024)
                body = {"p_id": PROJECT, "p_nombre": "Publicación HTTP sintética de8MiB", "p_contenido": package, "p_alcance": "base"}
                package_bytes = len(json.dumps(package, ensure_ascii=False, separators=(",", ":")).encode())
                ack, first = rpc("myg_nube_crear_confirmacion", body)
                assert ack["id"] == PROJECT and ack["revision"] == 1 and ack["rol"] == "propietario"
                assert "contenido" not in ack and first["response_bytes"] < 2048
                state, _ = rpc("myg_nube_estado_publicacion", {"p_id": PROJECT})
                assert state == {"estado": "existente"}
                repeated, repeat = rpc("myg_nube_crear_confirmacion", body)
                assert repeated == ack and repeat["response_bytes"] < 2048
                wrong = copy.copy(body)
                wrong["p_nombre"] = "Nombre distinto para el mismo UUID"
                rejected, _ = rpc("myg_nube_crear_confirmacion", wrong, expected=400)
                assert rejected["code"] == "22023"
                rejected, _ = rpc("myg_nube_crear_confirmacion", body, user=OTHER, expected=403)
                assert rejected["code"] == "42501"
                rejected, _ = rpc("myg_nube_estado_publicacion", {"p_id": PROJECT}, user=OTHER, expected=403)
                assert rejected["code"] == "42501"
                revision, _ = rpc("myg_nube_revision", {"p_id": PROJECT})
                assert revision["revision"] == 1 and "contenido" not in revision
                opened, opened_measure = rpc("myg_nube_abrir", {"p_id": PROJECT})
                assert opened["revision"] == 1 and opened["contenido"] == package
                del opened
                stored = sql("-At", "-c", f"SELECT count(*) FROM public.myg_nube_historial WHERE proyecto_id='{PROJECT}';")
                assert stored == "1", "Un reintento o rechazo cambió el historial."

                # Conexión real independiente: el rechazo55006 debe preceder a validar[].
                lock_sql = ("BEGIN; SELECT pg_advisory_xact_lock(hashtextextended('myg-nube-crear:"
                            + LOCKED_PROJECT + "',0)); SELECT pg_sleep(5); COMMIT;")
                with (temporary / "bloqueo.log").open("w") as lock_log:
                    lock_process = subprocess.Popen(["docker", "exec", "-u", "postgres", database, "psql", "-X",
                        "-v", "ON_ERROR_STOP=1", "-c", lock_sql], text=True, stdout=lock_log, stderr=subprocess.STDOUT)
                    for attempt in range(60):
                        busy = sql("-At", "-c", f"SELECT NOT pg_try_advisory_xact_lock(hashtextextended('myg-nube-crear:{LOCKED_PROJECT}',0));")
                        if busy == "t":
                            break
                        if lock_process.poll() is not None or attempt == 59:
                            raise AssertionError("No se pudo conservar el bloqueo sintético de5s.")
                        time.sleep(0.05)
                    state, processing = rpc("myg_nube_estado_publicacion", {"p_id": LOCKED_PROJECT})
                    assert state == {"estado": "procesando"} and processing["seconds"] < 2
                    rejected, locked = rpc("myg_nube_crear_confirmacion", {"p_id": LOCKED_PROJECT, "p_nombre": "En curso",
                        "p_contenido": [], "p_alcance": "base"}, expected=500)
                    assert rejected["code"] == "55006" and locked["seconds"] < 2
                    assert lock_process.wait(timeout=10) == 0
                    lock_process = None
                state, _ = rpc("myg_nube_estado_publicacion", {"p_id": LOCKED_PROJECT})
                assert state == {"estado": "disponible"}
                absent = sql("-At", "-c", f"SELECT NOT EXISTS(SELECT 1 FROM public.myg_nube_proyectos WHERE id='{LOCKED_PROJECT}');")
                assert absent == "t", "El rechazo por bloqueo dejó un proyecto parcial."
                memory_events = run("docker", "exec", database, "cat", "/sys/fs/cgroup/memory.events")
                events = dict(line.split() for line in memory_events.splitlines())
                assert events.get("oom_kill") == "0", "El servidor desechable registró un proceso terminado por memoria."
                peak = int(run("docker", "exec", database, "cat", "/sys/fs/cgroup/memory.peak"))
                result = {"status": "passed", "checks_http": len(measurements), "postgres": "17", "postgrest": "16.5",
                    "postgres_memory_limit_bytes": 512 * 1024 * 1024, "postgres_memory_peak_bytes": peak,
                    "synthetic_package_bytes": package_bytes, "create_request_bytes": first["request_bytes"],
                    "create_ack_bytes": first["response_bytes"], "replay_ack_bytes": repeat["response_bytes"],
                    "legacy_open_response_bytes": opened_measure["response_bytes"],
                    "locked_create_seconds": locked["seconds"], "postgres_oom_kill": 0,
                    "diagnostic_read_only_verified": True,
                    "scope": "Prueba funcional8MiB; no garantiza publicar200MiB en512MiB de memoria.",
                    "requests": measurements}
                print(json.dumps(result, indent=2), flush=True)
    finally:
        if lock_process is not None and lock_process.poll() is None:
            lock_process.terminate()
            lock_process.wait(timeout=10)
        for name in reversed(containers):
            subprocess.run(["docker", "rm", "-f", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if created_network:
            subprocess.run(["docker", "network", "rm", network], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == "__main__":
    main()
