using System;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    // La confirmación se puede sustituir en las comprobaciones de interfaz;
    // en el uso normal siempre se muestra el diálogo antes de cambiar la hoja.
    internal Func<string, bool> ConfirmarCambioPlantillaMetrado;

    private void ActualizarMetradoPresupuesto()
    {
        RequerirPartida();
        var presupuesto = P;
        var partida = PartidaActual;
        if (partida == null || !ReferenceEquals(actual, partida)) return;
        FinalizarEdicion();
        if (!ReferenceEquals(P, presupuesto) || !ReferenceEquals(actual, partida) ||
            !ReferenceEquals(PartidaActual, partida)) return;
        var estado = MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida);
        if (!estado.PuedeActualizar || !estado.HayDiferencia) { cabeceraExcel.Actualizar(); return; }
        antes();
        MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida);
        bool previo = cargando; cargando = true;
        try { fuente.SelectedItem = MYGFuenteMetrado.Cantidad; }
        finally { cargando = previo; }
        cabeceraExcel.Actualizar();
        Cambiado();
    }

    private static int InicioResumenMetradoHoja(MYGHojaMetrado h) =>
        MYGHojaCalculo.Coordenadas(h.CeldaTotal).Fila -
        (MYGPlantillasMetrado.Identificar(h) == MYGPlantillasMetrado.Aceros ? 3 : 1);

    private static TextFormatFlags FormatoTextoCombinadoMetrado(DataGridViewCell celda)
    {
        var estilo = celda.InheritedStyle;
        var horizontal = estilo.Alignment switch
        {
            DataGridViewContentAlignment.TopLeft or DataGridViewContentAlignment.MiddleLeft or DataGridViewContentAlignment.BottomLeft => TextFormatFlags.Left,
            DataGridViewContentAlignment.TopRight or DataGridViewContentAlignment.MiddleRight or DataGridViewContentAlignment.BottomRight => TextFormatFlags.Right,
            _ => TextFormatFlags.HorizontalCenter
        };
        var vertical = estilo.Alignment switch
        {
            DataGridViewContentAlignment.TopLeft or DataGridViewContentAlignment.TopCenter or DataGridViewContentAlignment.TopRight => TextFormatFlags.Top,
            DataGridViewContentAlignment.BottomLeft or DataGridViewContentAlignment.BottomCenter or DataGridViewContentAlignment.BottomRight => TextFormatFlags.Bottom,
            _ => TextFormatFlags.VerticalCenter
        };
        return horizontal | vertical | TextFormatFlags.EndEllipsis | TextFormatFlags.PreserveGraphicsClipping |
            TextFormatFlags.NoPrefix | (estilo.WrapMode == DataGridViewTriState.True ? TextFormatFlags.WordBreak : TextFormatFlags.SingleLine);
    }

    internal void ElegirPlantillaMetrado(string id)
    {
        RequerirPartida();
        if (!ReferenceEquals(PartidaActual, actual)) return;
        if (cargando || MYGPlantillasMetrado.Identificar(actual.Costos.Hoja) == id) return;
        var nueva = MYGPlantillasMetrado.Crear(id);
        MYGHojaCalculo.Validar(nueva);
        var partidaOrigen = actual;
        var presupuestoOrigen = P;
        var hojaOrigen = actual.Costos.Hoja;
        string nombre = id == MYGPlantillasMetrado.Aceros ? "Plantilla de fierros y aceros" : "Plantilla estándar";
        bool confirmado;
        if (ConfirmarCambioPlantillaMetrado is { } confirmar) confirmado = confirmar(nombre);
        else
        {
            using var aviso = new MYGConfirmarPlantillaMetradoForm(nombre);
            confirmado = aviso.ShowDialog(this) == DialogResult.OK;
        }
        if (!confirmado || !HayPartida || actual != partidaOrigen || P != presupuestoOrigen ||
            !ReferenceEquals(PartidaActual, partidaOrigen) ||
            !ReferenceEquals(actual.Costos.Hoja, hojaOrigen)) return;
        FinalizarEdicion();
        antes();
        actual.Costos.Hoja = nueva;
        // Las plantillas tienen anchos y cantidades de columnas diferentes.
        // La selección y el desplazamiento anteriores no pertenecen a la nueva.
        hoja.Tag = null;
        filtroTextoHoja = "";
        CargarHoja();
        cabeceraExcel.Actualizar();
        Cambiado();
    }
}
