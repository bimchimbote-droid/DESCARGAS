using System.Net;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

internal static class PublicacionLigeraCheck
{
    private const string Servidor = "https://publicacion-ligera.supabase.co";
    private const string Clave = "sb_publishable_publicacion_ligera_pruebas";
    private static readonly Guid Usuario = Guid.Parse("11111111-1111-4111-8111-111111111111");
    private static readonly Guid Proyecto = Guid.Parse("22222222-2222-4222-8222-222222222222");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        await EntradaDescartadaNoConsultaServidor();
        await ServidorAnteriorConservaPendiente();
        await CreacionYExistente();
        await ProcesandoNoReenvia();
        await RenovacionConservaCuerpo();
        await CancelacionAntesDeEnviar();
        await RespuestasInvalidas();
        await RechazoDelServidorConservaPendiente();
        await ErroresDeFaseConservanPendiente();
        await RenovacionFallidaAntesDePublicar();
        Console.WriteLine($"OK Publicación ligera: {comprobaciones} comprobaciones de metadatos, estado previo, sesión, cancelación y reintentos.");
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Publicación ligera: " + detalle);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException ex) { comprobaciones++; return ex; }
        throw new InvalidOperationException("Publicación ligera: faltó el rechazo esperado.");
    }

    private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };

    private static HttpResponseMessage Sesion(string acceso = "acceso_ligero") => Json(new
    { access_token = acceso, refresh_token = "refresco_sintetico", expires_in = 3600, user = new { id = Usuario } });

    private static object Confirmacion(Guid? id = null) => new
    {
        id = id ?? Proyecto, codigo = "MYG-LIGERA", nombre = "Base ligera", rol = "propietario", revision = 1,
        alcance = "base", permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true }
    };

    private static JsonElement Contenido() => JsonSerializer.SerializeToElement(new
    { texto = "Datos completos: Áncash 漢字 \"comillas\" y decimales", numero = 12.12345678901234567890123456m });

    private static async Task<(ClienteSupabase, Transporte)> Conectar(TimeProvider? reloj = null)
    {
        var t = new Transporte();
        t.Paso("/auth/v1/token?grant_type=password", (_, _) => Task.FromResult(Sesion()));
        var c = new ClienteSupabase(Servidor, Clave, t, reloj);
        await c.IniciarSesionAsync("cuenta@example.test", "clave_sintetica");
        return (c, t);
    }

    private static void Capacidad(Transporte t, int? ligera = 1)
    {
        t.Paso("/rest/v1/rpc/myg_nube_capacidades", (_, _) => Task.FromResult(ligera is null
            ? Json(new { paquete_compacto = 2, cambios = 1, max_contenido_mib = 300 })
            : Json(new { paquete_compacto = 2, cambios = 1, max_contenido_mib = 300, publicacion_ligera = ligera.Value })));
    }

    private static void Estado(Transporte t, string estado)
    {
        t.Paso("/rest/v1/rpc/myg_nube_estado_publicacion", async (r, _) =>
        {
            using var body = JsonDocument.Parse(await r.Content!.ReadAsStringAsync());
            Exige(body.RootElement.EnumerateObject().Count() == 1
                && body.RootElement.GetProperty("p_id").GetGuid() == Proyecto,
                "la consulta de estado envió contenido de la base o un identificador diferente.");
            return Json(new { estado });
        });
    }

    private static async Task EntradaDescartadaNoConsultaServidor()
    {
        var (c, t) = await Conectar(); using (c)
        {
            var documento = JsonDocument.Parse("{}");
            JsonElement contenido = documento.RootElement;
            documento.Dispose();
            var error = await Rechaza(() => c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", contenido, "base"));
            Exige(error.Message.Contains("ya no está disponible", StringComparison.Ordinal)
                && c.SesionIniciada && !error.NecesitaIniciarSesion,
                "un documento descartado consultó el servidor, perdió la sesión o filtró una excepción interna.");
            t.Completo();
        }
    }

    private static async Task ServidorAnteriorConservaPendiente()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-ligera-anterior-" + Guid.NewGuid().ToString("N"));
        try
        {
            var (c, t) = await Conectar(); using (c)
            {
                var archivo = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Usuario.ToString("D"));
                var pendiente = new PublicacionPendienteNube(Proyecto, "Base ligera", "base", Contenido());
                archivo.Guardar(pendiente); byte[] antes = File.ReadAllBytes(archivo.RutaActiva);
                Capacidad(t, null);
                var error = await Rechaza(() => c.CrearProyectoConfirmacionAsync(Proyecto, pendiente.Nombre, pendiente.Contenido, "base"));
                Exige(error.Message.Contains("20261026", StringComparison.Ordinal)
                    && error.Message.Contains("pendiente", StringComparison.Ordinal),
                    "el servidor antiguo no recibió la instrucción de actualización y conservación.");
                Exige(File.ReadAllBytes(archivo.RutaActiva).SequenceEqual(antes) && archivo.Leer().Id == Proyecto,
                    "la falta de capacidad alteró el pendiente.");
                // Una migración aplicada después del rechazo debe poder detectarse.
                Capacidad(t); Estado(t, "disponible");
                t.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", (_, _) => Task.FromResult(Json(Confirmacion())));
                var creado = await c.CrearProyectoConfirmacionAsync(Proyecto, pendiente.Nombre, pendiente.Contenido, "base");
                Exige(creado.Contenido.ValueKind == JsonValueKind.Undefined && c.SesionIniciada,
                    "la confirmación inventó un paquete o cerró la sesión.");
                Exige(File.ReadAllBytes(archivo.RutaActiva).SequenceEqual(antes),
                    "el cliente cerró el archivo pendiente antes de que el llamador verificara su cuenta.");
                t.Completo();
            }
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, true); }
    }

    private static async Task CreacionYExistente()
    {
        foreach (string estado in new[] { "disponible", "existente" })
        {
            var (c, t) = await Conectar(); using (c)
            {
                Capacidad(t); Estado(t, estado);
                JsonElement contenido = Contenido();
                t.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", async (r, _) =>
                {
                    using var body = JsonDocument.Parse(await r.Content!.ReadAsStringAsync());
                    Exige(body.RootElement.GetProperty("p_id").GetGuid() == Proyecto
                        && body.RootElement.GetProperty("p_nombre").GetString() == "Base ligera"
                        && body.RootElement.GetProperty("p_alcance").GetString() == "base"
                        && JsonElement.DeepEquals(body.RootElement.GetProperty("p_contenido"), contenido),
                        "la creación o recuperación de un UUID existente cambió el cuerpo original.");
                    return Json(Confirmacion());
                });
                var creado = await c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", contenido, "base");
                Exige(creado.Id == Proyecto && creado.Revision == 1 && creado.Rol == "propietario"
                    && creado.Contenido.ValueKind == JsonValueKind.Undefined && creado.PermisosModulos?.Acu == true,
                    "el ACK perdió identidad, revisión, permisos o incluyó el contenido completo.");
                t.Completo();
            }
        }
    }

    private static async Task ProcesandoNoReenvia()
    {
        var (c, t) = await Conectar(); using (c)
        {
            Capacidad(t); Estado(t, "procesando");
            var error = await Rechaza(() => c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", Contenido(), "base"));
            Exige(error.EsErrorDeConexion && !error.NecesitaIniciarSesion && c.SesionIniciada
                && error.Message.Contains("No se volvió a enviar", StringComparison.Ordinal)
                && error.Message.Contains("pendiente", StringComparison.Ordinal),
                "una publicación aún en ejecución reenviaría el paquete o cambiaría la identidad.");
            t.Completo();
        }
    }

    private static async Task RenovacionConservaCuerpo()
    {
        var (c, t) = await Conectar(); using (c)
        {
            Capacidad(t); Estado(t, "existente"); byte[]? cuerpo = null;
            t.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", async (r, _) =>
            { cuerpo = await r.Content!.ReadAsByteArrayAsync(); return Json(new { error = "caducada" }, HttpStatusCode.Unauthorized); });
            t.Paso("/auth/v1/token?grant_type=refresh_token", (_, _) => Task.FromResult(Sesion("acceso_renovado")));
            t.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", async (r, _) =>
            {
                byte[] reenviado = await r.Content!.ReadAsByteArrayAsync();
                Exige(cuerpo!.SequenceEqual(reenviado)
                    && r.Headers.Authorization?.Parameter == "acceso_renovado",
                    "renovar la sesión cambió los bytes, UUID o identidad del reenvío.");
                return Json(Confirmacion());
            });
            await c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", Contenido(), "base");
            t.Completo();
        }
    }

    private static async Task CancelacionAntesDeEnviar()
    {
        var (c, t) = await Conectar(); using (c)
        using (var cancelar = new CancellationTokenSource())
        {
            Capacidad(t);
            t.Paso("/rest/v1/rpc/myg_nube_estado_publicacion", (_, _) =>
            { cancelar.Cancel(); return Task.FromResult(Json(new { estado = "disponible" })); });
            bool cancelado = false;
            try { await c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", Contenido(), "base", cancelar.Token); }
            catch (OperationCanceledException) { cancelado = true; }
            Exige(cancelado && c.SesionIniciada && c.UsuarioId == Usuario.ToString("D"),
                "la cancelación antes del envío perdió identidad o fue ignorada.");
            t.Completo();
        }
    }

    private static async Task RespuestasInvalidas()
    {
        foreach (string codigo in new[] { "PGRST202", "42883" })
        {
            var (c, t) = await Conectar(); using (c)
            {
                t.Paso("/rest/v1/rpc/myg_nube_capacidades", (_, _) =>
                    Task.FromResult(Json(new { code = codigo, message = "detalle_remoto_secreto" }, HttpStatusCode.NotFound)));
                var error = await Rechaza(() => c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", Contenido(), "base"));
                Exige(error.Codigo == codigo && error.Message.Contains("20261026", StringComparison.Ordinal)
                    && !error.Message.Contains("secreto", StringComparison.Ordinal),
                    "el requisito de publicación ligera pidió una migración anterior o reveló contenido remoto.");
                t.Completo();
            }
        }
        foreach (string valor in new[] { "\"1\"", "true", "null", "-1", "2", "0.5" })
        {
            var (c, t) = await Conectar(); using (c)
            {
                t.Paso("/rest/v1/rpc/myg_nube_capacidades", (_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                { Content = new StringContent("{\"paquete_compacto\":2,\"publicacion_ligera\":" + valor + "}", Encoding.UTF8, "application/json") }));
                await Rechaza(() => c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", Contenido(), "base"));
                t.Completo();
            }
        }
        foreach (string estado in new[] { "confirmado", "", "desconocido" })
        {
            var (c, t) = await Conectar(); using (c)
            {
                Capacidad(t); Estado(t, estado);
                await Rechaza(() => c.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", Contenido(), "base"));
                t.Completo();
            }
        }
        var (cliente, transporte) = await Conectar(); using (cliente)
        {
            Capacidad(transporte); Estado(transporte, "disponible");
            transporte.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", (_, _) => Task.FromResult(Json(new
            {
                id = Proyecto, codigo = "MYG-NO", nombre = "Base ligera", rol = "propietario", revision = 1,
                alcance = "base", contenido = Contenido()
            })));
            await Rechaza(() => cliente.CrearProyectoConfirmacionAsync(Proyecto, "Base ligera", Contenido(), "base"));
            transporte.Completo();
        }
    }

    private static async Task RechazoDelServidorConservaPendiente()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-ligera-rechazo-" + Guid.NewGuid().ToString("N"));
        try
        {
            var (c, t) = await Conectar(); using (c)
            {
                var archivo = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Usuario.ToString("D"));
                var pendiente = new PublicacionPendienteNube(Proyecto, "Base ligera", "base", Contenido());
                archivo.Guardar(pendiente); byte[] antes = File.ReadAllBytes(archivo.RutaActiva);
                Capacidad(t); Estado(t, "existente");
                transporteRechazo(t);
                var error = await Rechaza(() => c.CrearProyectoConfirmacionAsync(Proyecto, pendiente.Nombre, pendiente.Contenido, "base"));
                Exige(error.Codigo == "22023" && c.SesionIniciada,
                    "un UUID existente con contenido distinto se confirmó o perdió su rechazo.");
                Exige(File.ReadAllBytes(archivo.RutaActiva).SequenceEqual(antes) && archivo.Leer().Id == Proyecto,
                    "el rechazo de contenido distinto alteró o cerró el pendiente original.");
                t.Completo();
            }
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, true); }

        static void transporteRechazo(Transporte t) => t.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", (_, _) =>
            Task.FromResult(Json(new { code = "22023", message = "MYG_ID_REUTILIZADO_CON_OTRA_CREACION" }, HttpStatusCode.BadRequest)));
    }

    private static async Task ErroresDeFaseConservanPendiente()
    {
        const string secreto = "contenido_privado_no_mostrar";
        const string referencia = "5bed582e-e473-4c87-aed8-aebea749865b";
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-ligera-fases-" + Guid.NewGuid().ToString("N"));
        try
        {
            foreach (string funcion in new[]
            {
                "myg_nube_capacidades", "myg_nube_estado_publicacion",
                "myg_nube_crear_confirmacion", "myg_nube_listar"
            })
            {
                var (cliente, transporte) = await Conectar();
                using (cliente)
                {
                    var almacen = new ArchivoPublicacionPendienteNube(Path.Combine(carpeta, funcion), Servidor, Usuario.ToString("D"));
                    var contenido = JsonSerializer.SerializeToElement(new { texto = secreto });
                    var pendiente = new PublicacionPendienteNube(Proyecto, secreto, "base", contenido);
                    almacen.Guardar(pendiente);
                    byte[] original = File.ReadAllBytes(almacen.RutaActiva);
                    bool listado = funcion == "myg_nube_listar";
                    if (!listado && funcion != "myg_nube_capacidades") Capacidad(transporte);
                    if (funcion == "myg_nube_crear_confirmacion") Estado(transporte, "existente");
                    transporte.Paso("/rest/v1/rpc/" + funcion, async (solicitud, token) =>
                    {
                        using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync());
                        if (funcion == "myg_nube_crear_confirmacion")
                            Exige(cuerpo.RootElement.GetProperty("p_id").GetGuid() == Proyecto
                                && cuerpo.RootElement.GetProperty("p_nombre").GetString() == secreto
                                && JsonElement.DeepEquals(cuerpo.RootElement.GetProperty("p_contenido"), contenido),
                                "el reintento de creación omitió o alteró el contenido que debe verificar el servidor.");
                        else
                            Exige(!cuerpo.RootElement.TryGetProperty("p_contenido", out _),
                                "una consulta de diagnóstico transmitió el paquete de publicación.");
                        var respuesta = new HttpResponseMessage((HttpStatusCode)520)
                        { Content = new StringContent("<html>" + secreto + "</html>", Encoding.UTF8, "text/html") };
                        respuesta.Headers.TryAddWithoutValidation("sb-request-id", referencia);
                        return respuesta;
                    });
                    var error = await Rechaza(async () =>
                    {
                        if (listado) await cliente.ListarProyectosAsync();
                        else await cliente.CrearProyectoConfirmacionAsync(Proyecto, pendiente.Nombre, pendiente.Contenido, "base");
                    });
                    string fase = funcion switch
                    {
                        "myg_nube_capacidades" => "comprobación de funciones del servidor",
                        "myg_nube_estado_publicacion" => "consulta del estado de la publicación",
                        "myg_nube_crear_confirmacion" => "publicación y confirmación",
                        _ => "actualización del listado de proyectos"
                    };
                    Exige(error.Message.Contains("Fase de la operación: " + fase, StringComparison.Ordinal)
                        && error.Message.Contains("RPC prevista " + funcion, StringComparison.Ordinal)
                        && error.Message.Contains("HTTP 520", StringComparison.Ordinal)
                        && error.Message.Contains(referencia, StringComparison.Ordinal),
                        "el fallo no identifica su fase y RPC ni conserva el estado y la referencia seguros.");
                    bool consultaPrevia = funcion is "myg_nube_capacidades" or "myg_nube_estado_publicacion";
                    Exige(error.Message.Contains("Esta consulta no transmite el paquete", StringComparison.Ordinal) == consultaPrevia
                        && error.Message.Contains("resultado de la publicación es incierto", StringComparison.Ordinal)
                            == (funcion == "myg_nube_crear_confirmacion"),
                        "el diagnóstico confundió un fallo de consulta con el resultado de un envío de publicación.");
                    Exige(error.EsErrorDeConexion && !error.NecesitaIniciarSesion && !error.AccesoDenegado
                        && !error.VinculoNoVerificado && error.Codigo is null,
                        "el contexto cambió las propiedades del error transitorio.");
                    Exige(File.ReadAllBytes(almacen.RutaActiva).SequenceEqual(original) && almacen.Leer().Id == Proyecto,
                        "el fallo de una fase cambió o retiró el intento pendiente.");
                    int esperadas = funcion == "myg_nube_crear_confirmacion" ? 4
                        : funcion == "myg_nube_estado_publicacion" ? 3 : 2;
                    Exige(transporte.Peticiones == esperadas && cliente.SesionIniciada && cliente.UsuarioId == Usuario.ToString("D"),
                        "el diagnóstico reenvió una operación o cambió la identidad de la cuenta.");
                    foreach (string privado in new[] { secreto, Servidor, Clave, "acceso_ligero", "refresco_sintetico", "https://", "memoria", "300 MiB" })
                        Exige(!error.Message.Contains(privado, StringComparison.OrdinalIgnoreCase),
                            "el contexto mostró datos privados o atribuyó al HTTP 520 una causa no demostrada.");
                    transporte.Completo();
                }
            }
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, true); }
    }

    private static async Task RenovacionFallidaAntesDePublicar()
    {
        const string secreto = "renovacion_privada_no_mostrar";
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-ligera-renovacion-fallida-" + Guid.NewGuid().ToString("N"));
        var reloj = new Reloj();
        try
        {
            var (cliente, transporte) = await Conectar(reloj);
            using (cliente)
            {
                var almacen = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Usuario.ToString("D"));
                var pendiente = new PublicacionPendienteNube(Proyecto, secreto, "base", Contenido());
                almacen.Guardar(pendiente);
                byte[] original = File.ReadAllBytes(almacen.RutaActiva);
                Capacidad(transporte);
                transporte.Paso("/rest/v1/rpc/myg_nube_estado_publicacion", async (solicitud, token) =>
                {
                    using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(token));
                    Exige(cuerpo.RootElement.GetProperty("p_id").GetGuid() == Proyecto
                        && !cuerpo.RootElement.TryGetProperty("p_contenido", out _),
                        "el sondeo previo no conservó el UUID o transmitió el paquete.");
                    reloj.Ahora = reloj.Ahora.AddHours(2);
                    return Json(new { estado = "disponible" });
                });
                transporte.Paso("/auth/v1/token?grant_type=refresh_token", async (solicitud, token) =>
                {
                    using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(token));
                    Exige(cuerpo.RootElement.GetProperty("refresh_token").GetString() == "refresco_sintetico"
                        && !cuerpo.RootElement.TryGetProperty("p_contenido", out _),
                        "la renovación perdió su credencial o recibió contenido de publicación.");
                    return Json(new { message = secreto, access_token = secreto }, HttpStatusCode.ServiceUnavailable);
                });
                var error = await Rechaza(() => cliente.CrearProyectoConfirmacionAsync(Proyecto,
                    pendiente.Nombre, pendiente.Contenido, pendiente.Alcance));
                Exige(error.Message.Contains("Fase de la operación: publicación y confirmación", StringComparison.Ordinal)
                    && error.Message.Contains("RPC prevista myg_nube_crear_confirmacion", StringComparison.Ordinal),
                    "la renovación fallida atribuyó la respuesta a una RPC que no se envió.");
                Exige(error.Message.Contains("puede no haberse enviado", StringComparison.Ordinal)
                    && error.Message.Contains("resultado de la publicación es incierto", StringComparison.Ordinal)
                    && !error.Message.Contains("No se envió el paquete", StringComparison.Ordinal),
                    "el diagnóstico aseguró un envío o una confirmación que no se produjo.");
                Exige(error.EsErrorDeConexion && !error.NecesitaIniciarSesion && !error.AccesoDenegado
                    && !error.VinculoNoVerificado && error.Codigo is null && cliente.SesionIniciada
                    && cliente.UsuarioId == Usuario.ToString("D"),
                    "la renovación transitoriamente fallida cambió la sesión o las propiedades del error.");
                Exige(transporte.Peticiones == 4, "la creación se envió después del fallo de renovación.");
                Exige(File.ReadAllBytes(almacen.RutaActiva).SequenceEqual(original) && almacen.Leer().Id == Proyecto,
                    "la renovación fallida cambió o retiró el pendiente.");
                foreach (string privado in new[] { secreto, Servidor, Clave, "acceso_ligero", "refresco_sintetico", "https://" })
                    Exige(!error.Message.Contains(privado, StringComparison.OrdinalIgnoreCase),
                        "el diagnóstico de renovación mostró credenciales, contenido o destinos privados.");
                transporte.Completo();
            }
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, true); }
    }

    private sealed class Reloj : TimeProvider
    {
        internal DateTimeOffset Ahora { get; set; } = new(2026, 10, 22, 12, 0, 0, TimeSpan.Zero);
        public override DateTimeOffset GetUtcNow() => Ahora;
    }

    private sealed class Transporte : HttpMessageHandler
    {
        internal int Peticiones { get; private set; }
        private readonly Queue<(string Ruta, Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> Ejecutar)> pasos = new();
        internal void Paso(string ruta, Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> ejecutar) => pasos.Enqueue((ruta, ejecutar));
        internal void Completo() => Exige(pasos.Count == 0, "faltaron solicitudes esperadas.");
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Peticiones++;
            Exige(pasos.Count > 0, "se envió una solicitud adicional o el contenido completo por una ruta antigua.");
            var paso = pasos.Dequeue();
            Exige(request.Method == HttpMethod.Post && request.RequestUri?.PathAndQuery == paso.Ruta,
                "se llamó a una ruta distinta de la publicación ligera esperada.");
            return paso.Ejecutar(request, cancellationToken);
        }
    }
}
