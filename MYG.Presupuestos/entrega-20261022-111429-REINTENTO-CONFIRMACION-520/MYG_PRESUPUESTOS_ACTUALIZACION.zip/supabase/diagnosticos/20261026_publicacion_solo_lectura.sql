-- DIAGNÓSTICO DE SOLO LECTURA para SQL Editor de su proyecto Supabase.
-- No lee contenido de obras, usuarios, claves ni consultas activas.
-- Devuelve configuración, tamaños y definiciones de funciones de publicación.
-- No reconstruye paquetes ni ejecuta una publicación.
begin read only;
set local statement_timeout = '10s';
set local lock_timeout = '1s';

select current_timestamp as instante_utc,
       current_setting('server_version') as version_postgresql,
       pg_postmaster_start_time() as inicio_postmaster,
       pg_is_in_recovery() as en_recuperacion;
-- inicio_postmaster no detecta todos los reinicios de procesos individuales.
-- shared_buffers/work_mem no equivalen a la RAM real asignada por el proveedor.
select name, setting, unit from pg_settings
where name in ('max_connections','shared_buffers','work_mem','statement_timeout','lock_timeout')
order by name;

select p.oid::regprocedure::text as funcion, p.prosecdef as security_definer,
       p.provolatile as volatilidad, p.proconfig as configuracion,
       pg_get_userbyid(p.proowner) as propietario,
       has_function_privilege('authenticated',p.oid,'EXECUTE') as authenticated_ejecuta,
       has_function_privilege('anon',p.oid,'EXECUTE') as anon_ejecuta
from pg_proc p
where p.oid in (
    to_regprocedure('public.myg_nube_crear(uuid,text,jsonb,text)'),
    to_regprocedure('public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'),
    to_regprocedure('public.myg_nube_estado_publicacion(uuid)'),
    to_regprocedure('myg_nube_privado.validar_contenido(jsonb)'),
    to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)'))
order by funcion;

select p.oid::regprocedure::text as funcion, pg_get_functiondef(p.oid) as definicion
from pg_proc p
where p.oid in (
    to_regprocedure('public.myg_nube_crear(uuid,text,jsonb,text)'),
    to_regprocedure('myg_nube_privado.validar_contenido(jsonb)'),
    to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)'))
order by funcion;

select n.nspname as esquema, c.relname as tabla,
       pg_total_relation_size(c.oid) as bytes_totales_con_indices_y_toast
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where c.relkind='r' and n.nspname='public'
  and c.relname in ('myg_nube_proyectos','myg_nube_historial','myg_nube_operaciones','myg_nube_miembros')
order by tabla;
select datname, numbackends, deadlocks, temp_bytes, stats_reset
from pg_stat_database where datname=current_database();
commit;
