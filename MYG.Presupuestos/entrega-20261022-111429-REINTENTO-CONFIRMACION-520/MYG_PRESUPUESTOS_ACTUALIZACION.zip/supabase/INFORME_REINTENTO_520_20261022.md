# Revisión del reintento de publicación — 22/10/2026

Repositorio: `bimchimbote-droid/MYG.Presupuestos`. Base comprobada contra `main`
remoto: `901cbaeac6894eb59f2a3dbf0d5777af49958118`. No se ha publicado código en
ese repositorio ni se ha modificado el Supabase del usuario.

## Qué muestran las capturas

1. El aviso aparece al leer una publicación pendiente de **200,1 MiB**. El
   umbral de 127 MiB solicita confirmación; no es el máximo del protocolo. Los
   200,1 MiB están por debajo de 300 MiB. El tamaño del archivo local tampoco
   equivale necesariamente al contenido HTTP ni al consumo de RAM del servidor.
2. **Continuar** autoriza preparar adjuntos y reintentar esa publicación con su
   mismo UUID. No amplía la memoria, los tiempos ni los límites de Supabase.
3. El mensaje HTTP 520 indica que no hubo una confirmación válida del origen.
   No demuestra memoria agotada, credenciales incorrectas ni publicación fallida
   definitivamente. Hay que conservar el pendiente y comprobar su estado.
4. El botón **Reintentar conexión** autentica y obtiene el listado; no publica.
   La primera captura pertenece al reintento del pendiente. La segunda conserva
   el estado «Conectado con su usuario MYG» mientras falla otra operación.

La publicación ligera evita devolver y descargar toda la base al crearla, pero
**la petición sigue enviando el paquete completo**. Incluso si el UUID existe,
el servidor debe comparar su creación original antes de confirmar el pendiente.
Eliminar esa comprobación produciría confirmaciones erróneas con otro contenido.

## Registros del fallo anterior

| Hora mostrada del 22/10/2026 | Hecho observado |
|---|---|
| 08:20:51 | Última actividad conocida antes de la recuperación de las 08:24. |
| 08:24:24 | PostgreSQL arranca, recupera WAL y vuelve a aceptar conexiones. |
| 08:24:53 | Una conexión de cliente termina con `Connection reset by peer`. |
| 08:26:09 | La operación anterior comunicada en `/rpc/myg_nube_crear` devuelve HTTP 520. |
| 08:27:43 | Nuevo arranque, recuperación y disponibilidad de PostgreSQL. |

Las horas UTC escritas dentro de esos registros antiguos son compatibles con
UTC−5 para las horas mostradas. Eso no confirma la configuración del visor
API del nuevo intento y no autoriza correlacionar ambos incidentes sin más datos.
Los dos arranques con recuperación confirman interrupciones bruscas, pero las
líneas compartidas no contienen la causa inicial ni un evento explícito de OOM,
señal 9, PANIC o apagado administrativo. `Connection reset by peer` tampoco
identifica esa causa. El mensaje `unexpected pageaddr` aparece durante el redo;
por sí solo, seguido de recuperación terminada y disponibilidad, no prueba
corrupción de las bases del usuario.

El aviso «We are investigating a technical issue · Follow the status page for
updates» es evidencia comunicada de una incidencia en investigación. No se ha
verificado independientemente su alcance ni su relación causal con cada intento.

## Registros nuevos comunicados durante esta revisión

El usuario encontró estas operaciones en API Gateway del 22/10/2026:

| Hora mostrada, zona aún sin confirmar | RPC | HTTP |
|---|---|---:|
| 10:25:40 | `myg_nube_crear_confirmacion` | 520 |
| 10:32:41 | `myg_nube_crear_confirmacion` | 520 |
| 10:38:09 | `myg_nube_abrir` | 200 |

Estos fallos están en el RPC nuevo de confirmación pequeña; **son distintos del
fallo anterior en `myg_nube_crear`**. No se ha confirmado la correspondencia de
ninguno con la referencia UUID de la captura, la zona horaria del visor ni el
tamaño de instancia. No se puede atribuirles automáticamente la causa de una
interrupción antigua ni correlacionarlos con sus horas UTC sin esos datos.

El HTTP 200 de apertura demuestra que esa petición obtuvo una respuesta correcta
más tarde. No identifica qué proyecto abrió, no confirma el UUID del pendiente
y no demuestra que cualquiera de las dos publicaciones inciertas se completara.
La ruta nueva reduce la respuesta, pero conserva el POST con `p_contenido` JSONB;
eso explica por qué la mejora no elimina por sí sola el riesgo del cuerpo grande,
sin demostrar que ese riesgo sea la causa de estos dos errores concretos.

Para cerrar el diagnóstico actual hay que correlacionar la referencia del error,
el UUID de la operación, hora/zona y métricas o eventos del servidor del mismo
intervalo, además del tamaño de instancia. No hace falta volver a aportar las
mismas líneas antiguas de recuperación. Nunca comparta claves, tokens, bases
privadas ni consultas completas que contengan datos.

## Defectos encontrados y correcciones de esta entrega

- `main` incluía 19 archivos idénticos de los 24 del ZIP anterior, un LEEME
  anterior y **cuatro archivos ausentes**: migración 26, pruebas SQL, diagnóstico
  de solo lectura e informe de publicación grande. Se recuperaron esos cuatro
  archivos completos del ZIP público anterior y se actualizó el LEEME.
- El origen recuperado es la entrega
  `MYG.Presupuestos/entrega-20261022-085848-PUBLICACION-520/` en `DESCARGAS`, commit
  `d7abb99351202438c6250d952f45cdded3eba0ca`. SHA-256 de su ZIP:
  `e9cc019b165f3714e950ac5463415a996cefc8a08031ced2cd2d74e53caf7d87`.
- Algunos mensajes del cliente recomendaban reinstalar el SQL 25, que puede
  restablecer capacidades anteriores. Ahora indican el instalador **26 completo**,
  que incluye los requisitos previos, el máximo de 300 MiB y publicación ligera.
- Los errores RPC ahora muestran una fase de operación y una RPC prevista de una
  lista local. Una renovación de sesión puede fallar antes del envío: la RPC
  prevista no se presenta como la ruta HTTP que falló. Un error en capacidades
  o en la consulta previa indica que esa
  consulta no transmitió el paquete. Un error de conexión en la creación conserva
  el resultado incierto; no afirma que la escritura no se produjo.
- Se conservan códigos HTTP/SQL, referencia permitida, estado de sesión, permisos,
  vínculo MYG, UUID y contenido del pendiente. No se reenvía automáticamente por
  HTTP 520 y no se confirma una creación únicamente por aparecer en el listado.
- Las pruebas nuevas simulan HTTP 520 en capacidades, consulta de estado, creación
  y listado; verifican privacidad, identidad, número de peticiones y conservación
  byte por byte del pendiente. No envían datos a Supabase real.

La recuperación del SQL en el repositorio **no demuestra que falte en el servidor**.
La captura puede corresponder a una instalación que ya lo ejecutó. Esta entrega
mejora integridad de la entrega y diagnóstico; no cambia el protocolo monolítico
ni garantiza que una instancia pequeña publique la base privada de 200 MiB.

## Validación SQL y HTTP de esta revisión

- PostgreSQL 17 y PostgREST 16.5 en contenedores desechables, imágenes fijadas por
  digest y datos exclusivamente sintéticos.
- 152 comprobaciones SQL de publicación ligera y 134 del fixture base aprobadas:
  cuatro estados previos, repetición, permisos, concurrencia y rollback.
- 15 solicitudes HTTP reales aprobadas: paquete de 8.571.070 bytes y confirmación
  de 286 bytes; reintento sin duplicación y rechazos de permisos/estado esperados.
- PostgreSQL limitado a 512 MiB: pico medido de 305.397.760 bytes, `oom_kill = 0`.
  Se comprobó que el diagnóstico SQL no cambia datos ni funciones mediante
  comparación del estado anterior y posterior. Se eliminaron contenedores y red.

La reproducción de OOM con 200 MiB descrita en
`INFORME_PUBLICACION_200_MIB.md` pertenece a la entrega anterior; no se repitió
en esta revisión. La prueba actual de unos 8 MiB no certifica capacidad para
200 MiB ni identifica la causa del servidor del usuario.

## Validación .NET de esta revisión

- SDK .NET 10.0.100; solución completa Release compilada con las referencias
  Revit soportadas por el repositorio: cero errores y cero advertencias.
- Núcleo: 584 comprobaciones completadas; se verificó que `resultado_qa.json`
  perteneciera a esta ejecución y coincidiera con los mensajes `OK`.
- Nube: 37 grupos principales y 982 comprobaciones de contrato HTTP principales.
  El grupo de publicación ligera informa además su contador propio de 290
  comprobaciones, 110 más que en la base. No se suman estos contadores como si
  describieran la misma unidad de prueba.
- Se probó también una renovación de sesión fallida después del sondeo, antes
  del envío de creación: no se transmitió la creación ni se cambió el pendiente.
- Windows Forms, Revit real, credenciales productivas y SQLite privado no se
  ejecutaron. El estado de salud de Supabase del usuario no se simuló como éxito.

Comandos desde la raíz del repositorio:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
```

Los dos runners de SQL/HTTP documentados en el LEEME usan únicamente Docker
local desechable. Sus pruebas se aprobaron después de recuperar los SQL; no
se enviaron peticiones ni migraciones al proyecto Supabase del usuario.

## Aplicación y comprobación manual

1. Cierre MYG y respalde o confirme sus cambios locales. Extraiga el ZIP fuera
   del checkout y copie solo sus archivos con las rutas originales. Revise las
   diferencias antes de reemplazar archivos completos. Conserve `.git`, su
   configuración de conexión, bases privadas y archivos no incluidos.
2. Restaure y compile con .NET 10; actualice el programa y sus DLL conjuntamente.
   El ZIP entrega fuentes, SQL, documentación y pruebas, no ejecutables.
3. El diagnóstico `diagnosticos/20261026_publicacion_solo_lectura.sql` se puede
   ejecutar en SQL Editor para revisar funciones, permisos, inicio del servidor
   y estadísticas sin publicar ni modificar una obra.
4. **Solo si falta el contrato de publicación ligera**, aplique completo
   `migraciones/20261026_publicacion_ligera.sql` como administrador. Debe devolver
   `PUBLICACION_LIGERA_INSTALADA`, 300 MiB y publicación ligera habilitada.
   No reinstale los SQL 21 a 25 después. No ejecute los archivos de pruebas en
   Supabase real. Si el contrato ya está instalado, reejecutarlo no explica ni
   resuelve por sí solo un HTTP 520.
5. Inicie MYG y pulse **Reintentar conexión**; compruebe el listado. Revise
   **Mis proyectos** y conserve el mismo pendiente cuando el resultado sea
   incierto. Pruebe primero una obra pequeña. Para la base completa, verifique
   primero salud y capacidad del servidor; evite repetir el envío grande sin
   un cambio de estado o un diagnóstico nuevo.
6. Si falla, conserve el nuevo mensaje de fase/RPC, HTTP, referencia y hora con
   zona horaria para correlacionarlo con Logs → API y Postgres. Si consulta estado
   indica que sigue procesándose, no cree otro UUID para eludir la espera.

La interfaz y Revit requieren comprobación en Windows. La licencia real y el
SQLite privado no se probaron. No se cambian credenciales ni se requiere un
servicio nuevo para este diagnóstico.

Después de revisar y probar los cambios en Visual Studio: abra **Cambios de Git**,
confirme que trabaja en `main`, revise el diff, haga **Commit**, luego **Push** y
verifique la rama en GitHub. La publicación del ZIP en `DESCARGAS` es independiente
de ese Push; no aplica automáticamente los cambios a su repositorio de código.
