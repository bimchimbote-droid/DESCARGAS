-- SOLO PostgreSQL desechable, después del fixture usuarios_myg_roles.sql.
-- Nunca ejecutar este archivo en el Supabase real de un usuario.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren una base desechable.'; end $$;
\endif

reset role;
create table qa.antes_publicacion_ligera as select
    (select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb) from public.myg_nube_proyectos p) proyectos,
    (select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from public.myg_nube_historial h) historial,
    (select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb) from public.myg_nube_miembros m) miembros,
    (select coalesce(jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id),'[]'::jsonb) from public.myg_nube_operaciones o) operaciones,
    (select coalesce(jsonb_agg(to_jsonb(i) order by auth_usuario_id),'[]'::jsonb) from myg_nube_privado.identidades_verificadas i) identidades,
    (select rolconfig from pg_roles where rolname='authenticated') rolconfig,
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definer',p.prosecdef) order by p.oid)
      from pg_proc p where p.oid in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure)) atributos_rpc,
    (select count(*) from qa.resultados) resultados_antes;

\ir ../migraciones/20261026_publicacion_ligera.sql

select qa.exige((select proyectos=(select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb) from public.myg_nube_proyectos p)
    from qa.antes_publicacion_ligera),'Publicación ligera: conserva proyectos y revisiones existentes');
select qa.exige((select historial=(select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from public.myg_nube_historial h)
    from qa.antes_publicacion_ligera),'Publicación ligera: conserva historial existente');
select qa.exige((select miembros=(select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb) from public.myg_nube_miembros m)
    from qa.antes_publicacion_ligera),'Publicación ligera: conserva miembros y permisos de módulos');
select qa.exige((select operaciones=(select coalesce(jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id),'[]'::jsonb) from public.myg_nube_operaciones o)
    from qa.antes_publicacion_ligera),'Publicación ligera: conserva operaciones y respuestas anteriores');
select qa.exige((select identidades=(select coalesce(jsonb_agg(to_jsonb(i) order by auth_usuario_id),'[]'::jsonb) from myg_nube_privado.identidades_verificadas i)
    from qa.antes_publicacion_ligera),'Publicación ligera: conserva vinculaciones MYG');
select qa.exige((select rolconfig is not distinct from (select rolconfig from pg_roles where rolname='authenticated')
    from qa.antes_publicacion_ligera),'Publicación ligera: conserva configuración del rol');
select qa.exige((select atributos_rpc=(select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definer',p.prosecdef) order by p.oid)
      from pg_proc p where p.oid in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure))
    from qa.antes_publicacion_ligera),'Publicación ligera: conserva OID, propietarios, ACL y SECURITY de RPC existentes');

create table qa.primera_publicacion_ligera as select
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,
        'config',p.proconfig,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
      from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace)) funciones;
\ir ../migraciones/20261026_publicacion_ligera.sql
select qa.exige((select funciones=(select jsonb_agg(jsonb_build_object('oid',p.oid,
        'owner',p.proowner,'acl',p.proacl,'config',p.proconfig,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
      from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace))
    from qa.primera_publicacion_ligera),'Publicación ligera: repetir conserva definiciones, OID, ACL y configuración');
select qa.exige(not has_function_privilege('anon','public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)','execute')
    and not has_function_privilege('anon','public.myg_nube_estado_publicacion(uuid)','execute')
    and has_function_privilege('authenticated','public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)','execute')
    and has_function_privilege('service_role','public.myg_nube_estado_publicacion(uuid)','execute'),
    'Publicación ligera: RPC requieren cuenta autenticada');
select qa.exige(not exists(select 1 from pg_proc p
    cross join lateral aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
    where p.oid in ('public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure,
      'public.myg_nube_estado_publicacion(uuid)'::regprocedure)
    and a.grantee=0 and a.privilege_type='EXECUTE'),
    'Publicación ligera: PUBLIC no ejecuta los nuevos RPC');
select qa.exige(not has_table_privilege('authenticated','public.myg_nube_proyectos','UPDATE')
    and not has_table_privilege('authenticated','public.myg_nube_miembros','INSERT')
    and not has_table_privilege('authenticated','public.myg_nube_historial','DELETE'),
    'Publicación ligera: no habilita escritura directa en tablas');

create table qa.publicacion_ligera_paquete as
    select pg_read_file('/pruebas/paquetes/compacto_cliente.json')::jsonb contenido;
grant select on qa.publicacion_ligera_paquete to authenticated;

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_capacidades()->>'publicacion_ligera'='1'
    and public.myg_nube_capacidades()->>'max_contenido_mib'='300',
    'Publicación ligera: capacidades anuncian confirmación ligera y límite de300MiB');
select qa.exige(public.myg_nube_estado_publicacion('96000000-0000-0000-0000-000000000001')=
    '{"estado":"disponible"}'::jsonb,'Publicación ligera: UUID nuevo está disponible sin enviar su contenido');
do $$ declare v jsonb; begin
    select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000001',
        'OBRA SINTETICA QA',contenido,'base') into v from qa.publicacion_ligera_paquete;
    perform qa.exige(v=public.myg_nube_revision('96000000-0000-0000-0000-000000000001')
        and v->>'id'='96000000-0000-0000-0000-000000000001' and v->>'rol'='propietario'
        and v->>'revision'='1','Publicación ligera: creación confirma identidad, rol y revisión con metadatos');
    perform qa.exige(not v?'contenido' and octet_length(v::text)<2048,
        'Publicación ligera: confirmación no devuelve el paquete ni un snapshot completo');
end $$;
select qa.exige(public.myg_nube_estado_publicacion('96000000-0000-0000-0000-000000000001')=
    '{"estado":"existente"}'::jsonb,'Publicación ligera: estado existente es ligero y no confirma por sí solo el cuerpo');
select qa.exige((select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000001',
    'OBRA SINTETICA QA',contenido,'base')=public.myg_nube_revision('96000000-0000-0000-0000-000000000001')
    from qa.publicacion_ligera_paquete),'Publicación ligera: mismo UUID y mismo cuerpo se confirman otra vez');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000001',
    'Nombre distinto',contenido,'base') from qa.publicacion_ligera_paquete$$,'22023',
    'Publicación ligera: rechaza reutilizar UUID con otro nombre');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000001',
    'OBRA SINTETICA QA',contenido,'obra') from qa.publicacion_ligera_paquete$$,'22023',
    'Publicación ligera: rechaza reutilizar UUID con otro alcance');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000001',
    'OBRA SINTETICA QA',jsonb_set(contenido,'{documento,Nombre}','"CUERPO DISTINTO"'),'base')
    from qa.publicacion_ligera_paquete$$,'22023','Publicación ligera: rechaza UUID con otro contenido inicial');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000002',
    'Inválido','[]','base')$$,'22023','Publicación ligera: creación nueva conserva validación del contenido');
select qa.rechaza($$select public.myg_nube_estado_publicacion(null)$$,'22023',
    'Publicación ligera: rechaza estado con UUID nulo');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('00000000-0000-0000-0000-000000000000',
    'Inválido','{}','base')$$,'22023','Publicación ligera: rechaza creación con UUID vacío');
reset role;
select qa.exige((select count(*)=1 from public.myg_nube_proyectos where id='96000000-0000-0000-0000-000000000001')
    and (select count(*)=1 from public.myg_nube_miembros where proyecto_id='96000000-0000-0000-0000-000000000001')
    and (select count(*)=1 from public.myg_nube_historial where proyecto_id='96000000-0000-0000-0000-000000000001')
    and not exists(select 1 from public.myg_nube_operaciones where proyecto_id='96000000-0000-0000-0000-000000000001'),
    'Publicación ligera: reintento no duplica proyecto, miembro, historial ni operación');
select qa.exige(not exists(select 1 from public.myg_nube_proyectos where id='96000000-0000-0000-0000-000000000002'),
    'Publicación ligera: rechazo de contenido no deja un proyecto parcial');
select qa.exige((select p.contenido=q.contenido from public.myg_nube_proyectos p cross join qa.publicacion_ligera_paquete q
    where p.id='96000000-0000-0000-0000-000000000001'),
    'Publicación ligera: contenido persistido conserva exactamente el paquete recibido');

-- Incluso un colaborador con permiso total no confirma la creación del propietario.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_nube_compartir_usuario('96000000-0000-0000-0000-000000000001','editor','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true}');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_estado_publicacion('96000000-0000-0000-0000-000000000001')$$,
    '42501','Publicación ligera: colaborador no consulta estado de creación ajeno');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000001',
    'OBRA SINTETICA QA',contenido,'base') from qa.publicacion_ligera_paquete$$,'42501',
    'Publicación ligera: colaborador no reutiliza la creación del propietario');
reset request.jwt.claim.sub;
select qa.rechaza($$select public.myg_nube_estado_publicacion(gen_random_uuid())$$,'42501',
    'Publicación ligera: estado exige identidad activa');
select qa.rechaza($$select public.myg_nube_crear_confirmacion(gen_random_uuid(),'Sin sesión','{}','obra')$$,'42501',
    'Publicación ligera: crear exige identidad activa');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000005';
select qa.rechaza($$select public.myg_nube_estado_publicacion(gen_random_uuid())$$,'42501',
    'Publicación ligera: estado rechaza vínculo inactivo');
reset role;
set role anon;
select qa.rechaza($$select public.myg_nube_estado_publicacion(gen_random_uuid())$$,'42501',
    'Publicación ligera: anon no consulta el estado');
select qa.rechaza($$select public.myg_nube_crear_confirmacion(gen_random_uuid(),'Anon','{}','obra')$$,'42501',
    'Publicación ligera: anon no crea mediante confirmación');
reset role;

-- El proyecto puede avanzar después de perderse la confirmación de creación.
-- El reintento verifica el cuerpo inicial y devuelve metadatos de la revisión actual.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_nube_guardar('96000000-0000-0000-0000-000000000001',
    '96000000-0000-0000-0000-000000000010',1,jsonb_set(contenido,'{documento,Presupuestos,0,Nombre}','"EDICIÓN POSTERIOR"'))
    from qa.publicacion_ligera_paquete;
select qa.exige((select public.myg_nube_crear_confirmacion('96000000-0000-0000-0000-000000000001',
    'OBRA SINTETICA QA',contenido,'base')->>'revision'='2' from qa.publicacion_ligera_paquete),
    'Publicación ligera: reintento de creación confirma la revisión actual sin sobrescribirla');
reset role;
select qa.exige((select revision=2 and contenido#>>'{documento,Presupuestos,0,Nombre}'='EDICIÓN POSTERIOR'
    from public.myg_nube_proyectos where id='96000000-0000-0000-0000-000000000001')
    and (select count(*)=2 from public.myg_nube_historial where proyecto_id='96000000-0000-0000-0000-000000000001'),
    'Publicación ligera: el reintento conserva la edición posterior y su historial');

-- El RPC original sigue disponible para versiones anteriores de la aplicación.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige((select public.myg_nube_crear('96000000-0000-0000-0000-000000000003',
    'Cliente anterior',contenido,'base')?'contenido' from qa.publicacion_ligera_paquete),
    'Publicación ligera: conserva el contrato completo del cliente anterior');
reset role;

select format('PRUEBAS PUBLICACIÓN LIGERA COMPLETADAS: %s',count(*)-(select resultados_antes from qa.antes_publicacion_ligera))
    from qa.resultados;
