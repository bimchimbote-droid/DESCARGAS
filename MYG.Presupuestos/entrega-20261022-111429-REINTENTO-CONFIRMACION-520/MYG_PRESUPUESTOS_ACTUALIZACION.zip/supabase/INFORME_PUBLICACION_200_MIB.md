# Investigación de publicación grande e ingreso intermitente — 22/10/2026

## Evidencia del caso comunicado

- SQLite original: 60,1 MiB. Paquete pendiente guardado: 200,1 MiB, unas 3,33 veces
  el SQLite. Son representaciones distintas; el tamaño guardado incluye el
  envoltorio local y puede bajar al preparar adjuntos externos.
- Máximo lógico de MYG: 300 MiB de contenido, 320 MiB de respuesta, profundidad
  128 y expansión compacta de 512 MiB. Los 200,1 MiB no superan el máximo lógico.
- El usuario encontró HTTP 200 en preparar/confirmar ingreso, listar proyectos
  y capacidades; HTTP 520 en `myg_nube_crear` a las 08:26:09 del 22/10/2026,
  junto con interrupción/recuperación de PostgreSQL y un aviso técnico de Supabase.
  La hora corresponde al registro comunicado; la zona del panel debe conservarse
  al correlacionarla con otros registros.
- Un registro `/admin/v1/network-bans/retrieve` con HTTP 200 correspondía al panel
  administrativo, no a la creación del proyecto.

HTTP 520 es una respuesta de pasarela sin una respuesta válida del origen. No es
un rechazo de tamaño, una confirmación de creación ni un código SQL específico.
Un reinicio o corte del backend puede producirlo, pero el código por sí solo no
identifica qué produjo el corte. El fallo posterior de ingreso puede compartir
la indisponibilidad de la base; todavía no prueba una causa independiente.

## Revisión de código y contrato

La petición usa POST JSON con `p_id` UUID no vacío, `p_nombre` recortado de 1 a 200
caracteres, `p_contenido` objeto y `p_alcance` obra/base. Envía la clave publicable
como `apikey` y el token de la sesión como Bearer. El servidor valida identidad
verificada y propietario; un token renovado conserva UUID y bytes de la operación.
Los permisos e identificadores no se sustituyen para eludir el error.

La creación y su historial están en una transacción. El RPC conserva la revisión
inicial para comparar reintentos: encontrar un UUID existente no basta para
confirmar otro contenido. Ante HTTP 520 o una espera cancelada, el cliente no
puede asegurar el resultado remoto y debe conservar la misma publicación pendiente.

El cliente tenía trabajo evitable: reconstruía v1 al validar el pendiente, copiaba
el paquete incluso sin adjuntos y recibía la base completa al crear para volver a
descargarla automáticamente al abrir. Estos son problemas de eficiencia reales;
no demuestran por sí solos la causa del reinicio del servidor real.

SQL ya valida el formato compacto sin reconstruir v1. El coste restante incluye
recibir el POST, convertir sus argumentos a JSONB, recorrer datos y almacenarlos.
El plazo de la operación de red es 150 segundos; la configuración SQL es 120
segundos para creación. Un plazo lógico no limita la memoria de esos pasos.

## Reproducción aislada con recursos limitados

Dataset sintético: exactamente 209715200 bytes (200 MiB), compacto v2 con tablas
nativas del benchmark y filas repetidas. PostgreSQL 17 y PostgREST 16.5 fijados,
contenedores con límites de memoria comprobados, red interna y sin puertos públicos.
No se utilizó el SQLite del usuario ni su cuenta Supabase.

| RAM de PostgreSQL | Creación | Resultado HTTP | Duración |
|---|---|---|---:|
| 512 MiB | RPC anterior | 503 / PGRST001 / OOM | 13,956 s |
| 512 MiB | Prototipo directo con confirmación de metadatos | 503 / PGRST001 / OOM | 5,115 s |
| 1 GiB | RPC anterior | 503 / PGRST001 / OOM | 6,462 s |
| 1 GiB | Prototipo directo con confirmación de metadatos | 503 / PGRST001 / OOM | 4,097 s |

En los cuatro casos el pico alcanzó el límite, el cgroup registró `oom_kill = 1`
y PostgreSQL registró terminación por señal 9 y recuperación. No se insertó el
proyecto sintético; PostgREST seguía vivo. Los contenedores se eliminaron al terminar.

Un control instrumentado registró la entrada de una petición pequeña al RPC, pero
la petición de 200 MiB agotó memoria antes de alcanzar su primera línea PL/pgSQL.
La conversión de argumentos de PostgREST con `json_to_record` ya podía agotar la
memoria. Por eso acelerar el validador, devolver solo metadatos o ampliar un plazo
**no soluciona por sí solo esa carga monolítica con 512 MiB o 1 GiB**.

La validación anterior de transferencias grandes se hizo en un entorno con más
RAM. Demostraba compatibilidad del protocolo, no capacidad de una instancia pequeña.
No debe extrapolarse a cualquier plan Supabase.

## Correcciones comprobadas de esta entrega

- Validación exacta sin conservar un JSON v1 ni un segundo DOM. Conserva el máximo
  de expansión, incluidos caracteres escapados, documentos y cabeceras. Una prueba
  con 200 MiB lógicos de referencias asignó 943576 bytes durante la validación.
  El buffer temporal depende del mayor token; no es memoria constante ante un
  único valor gigantesco.
- Preparación sin copiar todo el paquete cuando no tiene adjuntos. Se mantienen
  los controles de identidad, renovación, formato y recursos duplicados.
- Nuevo RPC de creación con respuesta de metadatos, consulta previa del estado y
  rechazo inmediato de un bloqueo de creación ya adquirido. El RPC antiguo sigue
  disponible. La consulta previa no evita todos los solapamientos durante el
  análisis de argumentos previo a la función.
- Publicación separada de apertura: el usuario abre después desde Mis proyectos.
- Fases, tiempo transcurrido y cancelación cooperativa. Cancelar la espera no
  asegura cancelar un trabajo que ya está ejecutándose en PostgreSQL.
- Diagnóstico seguro de HTTP, SQLSTATE/PostgREST y referencias UUID. No expone
  tokens, cuerpos arbitrarios ni claves. HTTP 520 conserva su clasificación de
  interrupción sin atribuir automáticamente memoria, autenticación o tamaño.
- Aviso para paquetes guardados mayores de 127 MiB, con Cancelar predeterminado.
  Mantiene el máximo lógico de 300 MiB y permite continuar conscientemente en una
  instancia con capacidad suficiente; no descubre ni certifica la RAM del proveedor.

## Validación y límites del resultado

- Solución .NET 10 compilada sin errores ni advertencias.
- 37 grupos de nube aprobados, con pruebas específicas de reintentos, metadatos,
  cancelación, errores 520, confidencialidad y límites.
- 152 comprobaciones SQL nuevas aprobadas, además de las 134 del fixture inicial.
- 15 peticiones HTTP reales del nuevo protocolo aprobadas con PostgreSQL limitado
  a 512 MiB: paquete de 8571070 bytes, confirmación de 286 bytes, lectura explícita,
  reintento sin duplicar, propietario, anónimo y bloqueo concurrente. Pico de
  305569792 bytes, sin OOM. Esa prueba de unos 8 MiB no garantiza publicar 200 MiB.
- El diagnóstico SQL de solo lectura se ejecutó sin alterar datos ni funciones.
- Pendiente: interfaz real Windows/Revit, SQLite privado y causa exacta de la
  interrupción del Supabase del usuario.

## Información necesaria para cerrar la causa del servidor real

Obtener en Logs → Postgres las líneas próximas al intento fallido que expliquen
el inicio de la recuperación, no solo las líneas posteriores de arranque:
`terminated by signal`, `out of memory`, `PANIC`, `FATAL`, `shutdown`,
`reinitializing`, `recovery`. Señal 9 junto a eventos de memoria apoya OOM;
una orden administrativa o un incidente de infraestructura requiere otro tratamiento.
Conservar el texto y periodo del aviso de incidencia técnica del proveedor.

Puede ejecutarse `diagnosticos/20261026_publicacion_solo_lectura.sql` para revisar
firma, propietario, permisos, plazos y definiciones de los RPC de publicación.
No contiene claves ni consulta obras, consultas activas o filas de usuarios.
Sus parámetros de PostgreSQL no certifican la RAM física del servicio.

No se pudo consultar la API pública de estado de Supabase desde este entorno:
el proxy devolvió 403. No se verificó independientemente el alcance ni el cierre
del aviso técnico comunicado por el usuario.

Mientras se determina la capacidad real, publicar una sola obra mediante el
alcance existente reduce la carga. Para mantener una base completa de este tamaño
se necesita capacidad verificada o un diseño de almacenamiento/operaciones por
partes. Comprimirla en bloques opacos sin validar en servidor reduciría las garantías
de permisos por módulo; no se implementó ese cambio incompatible en esta corrección.
