#nullable enable
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using MYG_2027;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    private const int MaxRespuestaNubeBytes = 320 * 1024 * 1024;
    // Reserva espacio para los metadatos del proyecto y el envoltorio de la RPC.
    private const int MaxContenidoNubeBytes = 300 * 1024 * 1024;
    private const int MaxContenidoNubeAnteriorBytes = 127 * 1024 * 1024;
    private const int MaxProfundidadNube = 128;
    // Este JSON se usa exclusivamente en application/json, nunca en HTML.
    private static readonly JsonSerializerOptions OpcionesNube = new()
    { MaxDepth = MaxProfundidadNube, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };

    /// <summary>Identifica el servidor al que pertenece la sesión, sin incluir credenciales.</summary>
    public string UrlServidor => _http.BaseAddress!.GetLeftPart(UriPartial.Authority);

    public Task<IReadOnlyList<ProyectoNube>> ListarProyectosAsync(CancellationToken ct = default) =>
        EjecutarRpcNubeAsync("myg_nube_listar", new { }, raiz =>
        {
            ValidarArrayNube(raiz);
            var proyectos = new List<ProyectoNube>();
            var ids = new HashSet<Guid>();
            foreach (JsonElement elemento in raiz.EnumerateArray())
            {
                ProyectoNube proyecto = LeerProyectoNube(elemento, requiereContenido: false);
                if (!ids.Add(proyecto.Id)) throw RespuestaNubeInvalida();
                proyectos.Add(proyecto);
            }
            return (IReadOnlyList<ProyectoNube>)proyectos.AsReadOnly();
        }, ct);

    public async Task<ProyectoNube> CrearProyectoAsync(Guid id, string nombre, JsonElement contenido,
        string alcance, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        nombre = ValidarNombreNube(nombre);
        ValidarAlcanceNube(alcance);
        JsonElement copia = ValidarContenidoNube(contenido);
        if (FormatoPaqueteNube.EsCompacto(copia)) await ExigirPaqueteCompactoAsync(ct);
        return await EjecutarRpcNubeAsync("myg_nube_crear", new
        {
            p_id = id, p_nombre = nombre, p_contenido = copia, p_alcance = alcance
        }, raiz => LeerProyectoNube(raiz, requiereContenido: true, esperado: id), ct);
    }

    public Task<ProyectoNube> AbrirProyectoAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return EjecutarRpcNubeAsync("myg_nube_abrir", new { p_id = id },
            raiz => LeerProyectoNube(raiz, requiereContenido: true, esperado: id), ct);
    }

    public Task<RespuestaGuardarNube> GuardarProyectoAsync(Guid id, Guid operacion, long revision,
        JsonElement contenido, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        ValidarIdNube(operacion);
        if (revision < 1) throw new NubeException("La operación necesita una revisión de nube válida.");
        JsonElement copia = ValidarContenidoNube(contenido);
        // El UUID y los bytes se crean una sola vez, incluso si hay que renovar la sesión.
        return EjecutarRpcNubeAsync("myg_nube_guardar", new
        {
            p_id = id, p_operacion = operacion, p_revision = revision, p_contenido = copia
        }, raiz =>
        {
            string estado = TextoNube(raiz, "estado", 32);
            if (estado is not ("aplicada" or "conflicto")) throw RespuestaNubeInvalida();
            Guid confirmado = GuidNube(raiz, "operacion_id");
            if (confirmado != operacion) throw RespuestaNubeInvalida();
            return new RespuestaGuardarNube(estado, RevisionNube(raiz), ContenidoNube(raiz), confirmado);
        }, ct);
    }

    public Task SolicitarAccesoAsync(string codigo, CancellationToken ct = default)
    {
        codigo = codigo?.Trim().ToUpperInvariant() ?? "";
        if (!TextoEntradaValido(codigo, 64))
            throw new NubeException("Introduzca un código de proyecto de hasta 64 caracteres.");
        return EjecutarRpcNubeAsync("myg_nube_solicitar", new { p_codigo = codigo }, raiz =>
        {
            if (TextoNube(raiz, "estado", 32) != "recibida") throw RespuestaNubeInvalida();
            return true;
        }, ct);
    }

    public Task<IReadOnlyList<MiembroNube>> ListarMiembrosAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return EjecutarRpcNubeAsync("myg_nube_miembros", new { p_id = id }, raiz =>
        {
            ValidarArrayNube(raiz);
            var miembros = new List<MiembroNube>();
            var usuarios = new HashSet<Guid>();
            foreach (JsonElement elemento in raiz.EnumerateArray())
            {
                Guid usuario = GuidNube(elemento, "usuario_id");
                string rol = RolNube(elemento);
                if (!usuarios.Add(usuario)) throw RespuestaNubeInvalida();
                string? usuarioMyg = null;
                if (elemento.TryGetProperty("usuario_myg", out var nombreMyg) && nombreMyg.ValueKind != JsonValueKind.Null)
                {
                    try
                    {
                        if (nombreMyg.ValueKind != JsonValueKind.String || nombreMyg.GetString() is not string nombre
                            || !UsuarioMygValido(nombre)) throw RespuestaNubeInvalida();
                        usuarioMyg = nombre;
                    }
                    catch (InvalidOperationException) { throw RespuestaNubeInvalida(); }
                }
                miembros.Add(new MiembroNube(usuario.ToString("D"), rol)
                {
                    UsuarioMyg = usuarioMyg,
                    PermisosModulos = LeerPermisosModulosNube(elemento)
                });
            }
            return (IReadOnlyList<MiembroNube>)miembros.AsReadOnly();
        }, ct);
    }

    public Task<IReadOnlyList<SolicitudNube>> ListarSolicitudesAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return EjecutarRpcNubeAsync("myg_nube_solicitudes", new { p_id = id }, raiz =>
        {
            ValidarArrayNube(raiz);
            var solicitudes = new List<SolicitudNube>();
            var usuarios = new HashSet<Guid>();
            foreach (JsonElement elemento in raiz.EnumerateArray())
            {
                Guid usuario = GuidNube(elemento, "usuario_id");
                string estado = TextoNube(elemento, "estado", 32);
                if (estado is not ("pendiente" or "aprobada" or "rechazada") || !usuarios.Add(usuario))
                    throw RespuestaNubeInvalida();
                solicitudes.Add(new SolicitudNube(usuario.ToString("D"), estado));
            }
            return (IReadOnlyList<SolicitudNube>)solicitudes.AsReadOnly();
        }, ct);
    }

    public Task ResolverSolicitudAsync(Guid id, string usuario, string rol, bool aprobar,
        CancellationToken ct = default)
    {
        ValidarIdNube(id);
        usuario = ValidarUsuarioNube(usuario);
        ValidarRolAsignableNube(rol);
        return EjecutarRpcNubeAsync("myg_nube_resolver", new
        {
            p_id = id, p_usuario = usuario, p_rol = rol, p_aprobar = aprobar
        }, ValidarRespuestaAdministracionNube, ct);
    }

    public Task CambiarRolAsync(Guid id, string usuario, string? rol, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        usuario = ValidarUsuarioNube(usuario);
        if (rol is not null) ValidarRolAsignableNube(rol);
        return EjecutarRpcNubeAsync("myg_nube_rol", new { p_id = id, p_usuario = usuario, p_rol = rol },
            ValidarRespuestaAdministracionNube, ct);
    }

    /// <summary>Solicita al servidor otorgar acceso a una identidad MYG verificada, sin conceder permisos locales.</summary>
    public Task CompartirConUsuarioMygAsync(Guid id, string usuarioMyg, string rol,
        MYGPermisosModulos permisos, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        usuarioMyg = usuarioMyg?.Trim().ToLowerInvariant() ?? "";
        if (!UsuarioMygValido(usuarioMyg))
            throw new NubeException("Introduzca un usuario MYG válido de hasta 256 caracteres.");
        ValidarRolAsignableNube(rol);
        if (permisos is null) throw new NubeException("Seleccione los permisos de los módulos del colaborador.");
        return EjecutarRpcPermisosNubeAsync("myg_nube_compartir_usuario", new
        {
            p_id = id, p_usuario_myg = usuarioMyg, p_rol = rol, p_permisos_modulos = permisos.Copiar()
        }, ct);
    }

    public Task CambiarPermisosMiembroAsync(Guid id, string usuario, MYGPermisosModulos permisos,
        CancellationToken ct = default)
    {
        ValidarIdNube(id);
        usuario = ValidarUsuarioNube(usuario);
        if (permisos is null) throw new NubeException("Seleccione los permisos de los módulos del colaborador.");
        return EjecutarRpcPermisosNubeAsync("myg_nube_permisos", new
        {
            p_id = id, p_usuario = usuario, p_permisos_modulos = permisos.Copiar()
        }, ct);
    }

    private async Task<bool> EjecutarRpcPermisosNubeAsync(string funcion, object parametros, CancellationToken ct)
    {
        try
        {
            return await EjecutarRpcNubeAsync(funcion, parametros, ValidarRespuestaPermisosNube, ct);
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883")
        {
            throw new NubeException(
                "El servidor aún no tiene habilitada la gestión por usuario MYG y permisos por módulo. "
                + "Actualice el backend antes de compartir o cambiar permisos. No se concedió ningún acceso.",
                codigo: ex.Codigo);
        }
    }

    private static bool ValidarRespuestaPermisosNube(JsonElement raiz)
    {
        if (TextoNube(raiz, "estado", 32) != "actualizada") throw RespuestaNubeInvalida();
        return true;
    }

    private async Task<T> EjecutarRpcNubeAsync<T>(string funcion, object parametros,
        Func<JsonElement, T> leer, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        byte[] cuerpo;
        try { cuerpo = JsonSerializer.SerializeToUtf8Bytes(parametros, OpcionesNube); }
        catch (JsonException) { throw new NubeException("El contenido del proyecto supera la profundidad admitida de 128 niveles."); }
        ct.ThrowIfCancellationRequested();
        if (cuerpo.Length > MaxContenidoNubeAnteriorBytes)
        {
            int bytesContenido = MedirContenidoSolicitudNube(cuerpo);
            if (bytesContenido > MaxContenidoNubeBytes)
                throw new NubeException($"El contenido preparado para enviar ocupa {bytesContenido / 1048576d:N1} MiB y supera el máximo de 300 MiB. "
                    + "Para crear otra publicación, retire primero el intento desde Publicaciones pendientes.");
            if (bytesContenido > MaxContenidoNubeAnteriorBytes)
            {
                var capacidades = await ObtenerCapacidadesNubeAsync(ct);
                if (bytesContenido > (long)capacidades.MaxContenidoMiB * 1024 * 1024)
                {
                    // Una actualización aplicada después de este rechazo debe poder
                    // detectarse al reintentar, sin cerrar ni cambiar la identidad.
                    capacidadesNube = null;
                    throw new NubeException($"El servidor admite hasta {capacidades.MaxContenidoMiB} MiB. "
                        + "Ejecute completo 20261026_publicacion_ligera.sql en Supabase para habilitar el límite de 300 MiB "
                        + "y reintente la misma publicación pendiente.");
                }
            }
        }
        if (cuerpo.Length > MaxRespuestaNubeBytes)
            throw new NubeException("El contenido del proyecto supera el tamaño admitido para la nube.");
        try
        {
            return await EjecutarAsync(async token =>
            {
                using var respuesta = await EnviarConSesionAsync(HttpMethod.Post,
                    "rest/v1/rpc/" + funcion, cuerpo, token, nube: true);
                using var json = await LeerJsonAsync(respuesta, token,
                    MaxRespuestaNubeBytes, MaxProfundidadNube, nube: true);
                return leer(json.RootElement);
            }, ct, plazo: funcion is "myg_nube_crear" or "myg_nube_crear_confirmacion" or "myg_nube_abrir" or "myg_nube_guardar" or "myg_nube_guardar_cambios"
                ? TimeSpan.FromSeconds(150) : null);
        }
        catch (NubeException error)
        {
            throw ContextualizarErrorRpcNube(error, funcion);
        }
    }

    private static int MedirContenidoSolicitudNube(ReadOnlySpan<byte> cuerpo)
    {
        // El cuerpo ya se serializó y congeló. Medir sobre UTF-8 evita otra
        // copia completa en UTF-16 o un segundo DOM para las bases grandes.
        var lector = new Utf8JsonReader(cuerpo, new JsonReaderOptions { MaxDepth = MaxProfundidadNube });
        if (!lector.Read() || lector.TokenType != JsonTokenType.StartObject) return 0;
        int maximo = 0;
        while (lector.Read() && lector.TokenType != JsonTokenType.EndObject)
        {
            bool contenido = lector.ValueTextEquals("p_contenido"u8) || lector.ValueTextEquals("p_cambios"u8);
            if (!lector.Read()) break;
            long inicio = lector.TokenStartIndex;
            lector.Skip();
            if (contenido) maximo = Math.Max(maximo, checked((int)(lector.BytesConsumed - inicio)));
        }
        return maximo;
    }

    private static ProyectoNube LeerProyectoNube(JsonElement raiz, bool requiereContenido, Guid? esperado = null)
    {
        Guid id = GuidNube(raiz, "id");
        if (esperado is Guid esperadoId && id != esperadoId) throw RespuestaNubeInvalida();
        string codigo = TextoNube(raiz, "codigo", 64);
        string nombre = TextoNube(raiz, "nombre", 200);
        string rol = RolNube(raiz);
        long revision = RevisionNube(raiz);
        string alcance = TextoNube(raiz, "alcance", 16);
        if (alcance is not ("obra" or "base")) throw RespuestaNubeInvalida();
        JsonElement contenido = default;
        if (requiereContenido || raiz.TryGetProperty("contenido", out _)) contenido = ContenidoNube(raiz);
        return new ProyectoNube(id, codigo, nombre, rol, revision, alcance, contenido)
        {
            PermisosModulos = LeerPermisosModulosNube(raiz)
        };
    }

    private static MYGPermisosModulos? LeerPermisosModulosNube(JsonElement raiz)
    {
        // Ausencia identifica al servidor legado. Un objeto incompleto jamás amplía permisos por defecto.
        if (!raiz.TryGetProperty("permisos_modulos", out var valor)) return null;
        if (valor.ValueKind != JsonValueKind.Object) throw RespuestaNubeInvalida();
        var nombres = new HashSet<string>(StringComparer.Ordinal);
        foreach (var propiedad in valor.EnumerateObject())
            if (propiedad.Name is not ("acu" or "especificaciones" or "metrados_excel")
                || !nombres.Add(propiedad.Name)
                || propiedad.Value.ValueKind is not (JsonValueKind.True or JsonValueKind.False))
                throw RespuestaNubeInvalida();
        if (nombres.Count != 3) throw RespuestaNubeInvalida();
        return new MYGPermisosModulos
        {
            Acu = valor.GetProperty("acu").GetBoolean(),
            Especificaciones = valor.GetProperty("especificaciones").GetBoolean(),
            MetradosExcel = valor.GetProperty("metrados_excel").GetBoolean()
        };
    }

    private static string TextoNube(JsonElement raiz, string propiedad, int maximo)
    {
        if (raiz.ValueKind != JsonValueKind.Object || !raiz.TryGetProperty(propiedad, out var valor)
            || valor.ValueKind != JsonValueKind.String || valor.GetString() is not string texto
            || !TextoEntradaValido(texto, maximo)) throw RespuestaNubeInvalida();
        return texto;
    }

    private static Guid GuidNube(JsonElement raiz, string propiedad)
    {
        if (!Guid.TryParse(TextoNube(raiz, propiedad, 36), out Guid id) || id == Guid.Empty)
            throw RespuestaNubeInvalida();
        return id;
    }

    private static string RolNube(JsonElement raiz)
    {
        string rol = TextoNube(raiz, "rol", 32);
        if (rol is not ("propietario" or "administrador" or "editor" or "lector"))
            throw RespuestaNubeInvalida();
        return rol;
    }

    private static long RevisionNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Object || !raiz.TryGetProperty("revision", out var valor)
            || valor.ValueKind != JsonValueKind.Number || !valor.TryGetInt64(out long revision)
            || revision < 1) throw RespuestaNubeInvalida();
        return revision;
    }

    private static JsonElement ContenidoNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Object || !raiz.TryGetProperty("contenido", out var valor)
            || valor.ValueKind != JsonValueKind.Object)
            throw RespuestaNubeInvalida();
        try
        {
            FormatoPaqueteNube.MedirBytesJson(valor, MaxProfundidadNube, MaxContenidoNubeBytes);
            return valor.Clone();
        }
        catch (Exception ex) when (ex is System.IO.InvalidDataException or JsonException or InvalidOperationException or ArgumentException)
        { throw RespuestaNubeInvalida(); }
    }

    private static JsonElement ValidarContenidoNube(JsonElement contenido, CancellationToken ct = default)
    {
        try
        {
            if (contenido.ValueKind != JsonValueKind.Object)
                throw new NubeException("El contenido del proyecto debe ser un objeto JSON.");
            // Contar al escribir sobre un buffer descartable evita crear una
            // cadena UTF-16 y otro DOM. La RPC necesita dos niveles adicionales.
            ct.ThrowIfCancellationRequested();
            FormatoPaqueteNube.MedirBytesJson(contenido, MaxProfundidadNube - 2, MaxContenidoNubeBytes);
            ct.ThrowIfCancellationRequested();
            return contenido.Clone();
        }
        catch (ObjectDisposedException) { throw new NubeException("El contenido del proyecto ya no está disponible."); }
        catch (System.IO.InvalidDataException)
        { throw new NubeException("El contenido preparado para enviar ocupa más del máximo de 300 MiB. "
            + "Para crear otra publicación, retire primero el intento desde Publicaciones pendientes."); }
        catch (ArgumentException)
        { throw new NubeException("El contenido preparado ocupa demasiado espacio o contiene un valor JSON que supera la capacidad del codificador. "
            + "El máximo del paquete es 300 MiB. Conserve una copia al retirar el intento desde Publicaciones pendientes."); }
        catch (Exception ex) when (ex is JsonException or InvalidOperationException)
        { throw new NubeException("El contenido del proyecto supera la profundidad admitida para la nube."); }
    }

    private static void ValidarArrayNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Array || raiz.GetArrayLength() > 10000)
            throw RespuestaNubeInvalida();
    }

    private static bool TextoEntradaValido(string texto, int maximo)
    {
        if (string.IsNullOrWhiteSpace(texto) || texto.Length > maximo) return false;
        foreach (char caracter in texto) if (char.IsControl(caracter)) return false;
        return true;
    }

    private static void ValidarIdNube(Guid id)
    {
        if (id == Guid.Empty) throw new NubeException("El proyecto y la operación necesitan identificadores válidos.");
    }

    private static string ValidarNombreNube(string nombre)
    {
        nombre = nombre?.Trim() ?? "";
        if (!TextoEntradaValido(nombre, 200)) throw new NubeException("Introduzca un nombre de proyecto de hasta 200 caracteres.");
        return nombre;
    }

    private static void ValidarAlcanceNube(string alcance)
    {
        if (alcance is not ("obra" or "base")) throw new NubeException("El alcance del proyecto debe ser obra o base.");
    }

    private static string ValidarUsuarioNube(string usuario)
    {
        if (!Guid.TryParse(usuario, out Guid id) || id == Guid.Empty)
            throw new NubeException("El miembro necesita un identificador de usuario válido.");
        return id.ToString("D");
    }

    private static void ValidarRolAsignableNube(string rol)
    {
        if (rol is not ("administrador" or "editor" or "lector"))
            throw new NubeException("Seleccione un rol de administrador, editor o lector.");
    }

    private static bool ValidarRespuestaAdministracionNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.True) throw RespuestaNubeInvalida();
        return true;
    }

    private static NubeException RespuestaNubeInvalida() => new(
        "La respuesta de la nube no tiene el formato esperado. Conserve la operación pendiente y reinténtela.",
        esErrorDeConexion: true);

    private static async Task LanzarErrorNubeAsync(HttpResponseMessage respuesta, CancellationToken ct)
    {
        NubeException Error(string mensaje, bool esErrorDeConexion = false, bool accesoDenegado = false,
            string? codigo = null, bool vinculoNoVerificado = false) => new(
            mensaje + DiagnosticoHttpNube(respuesta, codigo), esErrorDeConexion: esErrorDeConexion,
            accesoDenegado: accesoDenegado, codigo: codigo, vinculoNoVerificado: vinculoNoVerificado);
        if (respuesta.StatusCode == HttpStatusCode.RequestEntityTooLarge)
            throw Error("El servidor o su pasarela aplican un límite HTTP inferior al tamaño enviado. "
                + "El límite de 300 MiB de MYG no cambia esa configuración. Publique una obra o divida la base; "
                + "se conserva el intento pendiente.");
        if (respuesta.StatusCode is HttpStatusCode.RequestTimeout or HttpStatusCode.GatewayTimeout)
            throw Error("El servidor agotó el tiempo de espera de la transferencia. "
                + "Revise Mis proyectos y reintente la misma operación pendiente para comprobar su confirmación.",
                esErrorDeConexion: true);
        if (respuesta.StatusCode == HttpStatusCode.TooManyRequests)
            throw Error("El servidor limitó la cantidad de solicitudes." + EsperaLimiteNube(respuesta)
                + " Se conserva la operación pendiente y su identificador.", esErrorDeConexion: true);
        string? codigo = null;
        bool vinculoNoVerificado = false;
        bool publicacionEnCurso = false;
        string? limiteContenido = null;
        try
        {
            using var json = await LeerJsonAsync(respuesta, ct, nube: true);
            JsonElement raiz = json.RootElement;
            if (raiz.ValueKind == JsonValueKind.Object)
            {
                if (raiz.TryGetProperty("code", out var valor) && valor.ValueKind == JsonValueKind.String)
                {
                    string? candidato = valor.GetString();
                    if (candidato is "40001" or "42501" or "22023" or "23505" or "54000" or
                        "57014" or "53200" or "53300" or "53400" or "55006" or "57P01" or "57P02" or "57P03" or
                        "PGRST000" or "PGRST001" or "PGRST002" or "PGRST003" or "PGRST202" or "42883" or "42P01")
                        codigo = candidato;
                }
                vinculoNoVerificado = codigo == "42501" && raiz.TryGetProperty("message", out var mensaje)
                    && mensaje.ValueKind == JsonValueKind.String && mensaje.GetString() == "MYG_VINCULO_NO_VERIFICADO";
                publicacionEnCurso = codigo == "55006" && raiz.TryGetProperty("message", out var enCurso)
                    && enCurso.ValueKind == JsonValueKind.String && enCurso.GetString() == "MYG_PUBLICACION_EN_CURSO";
                if (codigo == "22023" && raiz.TryGetProperty("message", out var errorTamano)
                    && errorTamano.ValueKind == JsonValueKind.String
                    && errorTamano.GetString() is "MYG_CONTENIDO_INVALIDO_MAX_32_MIB" or "MYG_CONTENIDO_INVALIDO_MAX_127_MIB" or "MYG_CONTENIDO_INVALIDO_MAX_300_MIB")
                    limiteContenido = errorTamano.GetString();
            }
        }
        catch (NubeException) { }
        if (codigo == "40001")
            throw Error("Otro cambio coincidió con la solicitud. Reintente la misma operación pendiente.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo == "42501" || respuesta.StatusCode == HttpStatusCode.Forbidden)
            throw Error(vinculoNoVerificado
                    ? "La cuenta necesita un vínculo MYG verificado por el administrador del servidor."
                    : "La cuenta ya no tiene permiso para esta operación. Actualice el proyecto y compruebe su rol.",
                accesoDenegado: true, codigo: codigo, vinculoNoVerificado: vinculoNoVerificado);
        if (codigo == "22023")
        {
            if (limiteContenido == "MYG_CONTENIDO_INVALIDO_MAX_32_MIB")
                throw Error("El servidor aún tiene el límite anterior de 32 MiB. Aplique la actualización de Nube MYG en Supabase y reintente la misma publicación pendiente.", codigo: codigo);
            if (limiteContenido == "MYG_CONTENIDO_INVALIDO_MAX_127_MIB")
                throw Error("El servidor aún tiene el límite de 127 MiB. Ejecute completo 20261026_publicacion_ligera.sql en Supabase y reintente la misma publicación pendiente.", codigo: codigo);
            if (limiteContenido == "MYG_CONTENIDO_INVALIDO_MAX_300_MIB")
                throw Error("El contenido del proyecto supera el máximo de 300 MiB del servidor. Publique una obra o divida la base; se conserva el intento pendiente.", codigo: codigo);
            throw Error("La nube rechazó los datos del proyecto, la revisión o la operación.", codigo: codigo);
        }
        if (codigo == "23505")
            throw Error("El identificador de la operación o del proyecto ya está en uso con otros datos.", codigo: codigo);
        if (codigo == "54000")
            throw Error("La base supera un límite interno de PostgreSQL para su representación JSONB. "
                + "El máximo de 300 MiB de la aplicación no elimina ese límite. Publique una obra o divida la base; "
                + "se conserva el intento pendiente.", codigo: codigo);
        if (codigo == "57014")
            throw Error("PostgreSQL canceló la operación, posiblemente al alcanzar su tiempo máximo de ejecución. "
                + "El tamaño permitido de 300 MiB no amplía ese plazo. Se conserva la operación pendiente; "
                + "revise Mis proyectos y el registro del servidor antes de reintentar.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo == "55006")
            throw Error(publicacionEnCurso
                    ? "Ya hay una publicación en curso con este identificador. Espere a que termine y revise Mis proyectos. Se conserva la misma operación pendiente."
                    : "Un recurso necesario sigue ocupado por otra operación. Espere y revise Mis proyectos. Se conserva la misma operación pendiente.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo == "53200")
            throw Error("PostgreSQL no tuvo memoria suficiente para procesar la solicitud. "
                + "Se conserva la operación pendiente. Revise los recursos del servidor antes de volver a enviarla.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo == "53300")
            throw Error("PostgreSQL alcanzó su máximo de conexiones. Se conserva la operación pendiente; "
                + "espere a que se liberen conexiones antes de reintentar.", esErrorDeConexion: true, codigo: codigo);
        if (codigo == "53400")
            throw Error("PostgreSQL alcanzó un límite de recursos configurado en el servidor. "
                + "Se conserva la operación pendiente. Revise ese límite en el registro del servidor.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo is "57P01" or "57P02" or "57P03")
            throw Error("La base de datos se está cerrando, recuperando o todavía no acepta conexiones. "
                + "Espere a que esté disponible. Se conserva la operación pendiente y su identificador.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo == "PGRST003")
            throw Error("Se agotó la espera de una conexión disponible entre la API y PostgreSQL. "
                + "Se conserva la operación pendiente; espere a que se liberen conexiones antes de reintentar.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo == "PGRST001")
            throw Error("La conexión entre la API y PostgreSQL se interrumpió. La base puede estar reiniciándose o temporalmente no disponible. "
                + "Se conserva la operación pendiente. Revise el estado de la base y sus registros antes de reintentar.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo is "PGRST000" or "PGRST002")
            throw Error("La API de Supabase no pudo establecer o preparar su conexión con PostgreSQL. "
                + "Se conserva la operación pendiente. Revise el estado de la base de datos y el registro del servidor.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo is "PGRST202" or "42883" or "42P01")
            throw Error("Las funciones de proyectos en la nube todavía no están instaladas en este servidor.", codigo: codigo);
        int estadoHttp = (int)respuesta.StatusCode;
        if (estadoHttp >= 500 || estadoHttp == 429)
            throw Error("Supabase no pudo confirmar la solicitud. Espere un momento y reintente la misma operación pendiente.",
                esErrorDeConexion: true, codigo: codigo);
        throw Error("La nube rechazó la solicitud. Compruebe la configuración del servidor.",
            codigo: codigo);
    }
}
