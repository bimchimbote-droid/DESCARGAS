using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private void PrepararHoja()
    {
        var p = Pagina("Metrados en Excel"); p.Controls.Add(hoja);
        hoja.ReadOnly = false; hoja.SelectionMode = DataGridViewSelectionMode.CellSelect; hoja.MultiSelect = true; hoja.RowHeadersVisible = true; hoja.RowHeadersWidth = 52;
        hoja.ColumnHeadersHeight = 25;
        hoja.CellBeginEdit += (s, e) =>
        {
            if (cargando || !HayPartida) return; antes();
            string dir = MYGHojaCalculo.Columna(e.ColumnIndex + 1) + (e.RowIndex + 1);
            contenidoAntes = new MYGHojaCalculo(actual.Costos.Hoja).Contenido(dir); hoja.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = contenidoAntes;
        };
        hoja.CellEndEdit += (s, e) =>
        {
            if (cargando || !HayPartida) return;
            string dir = MYGHojaCalculo.Columna(e.ColumnIndex + 1) + (e.RowIndex + 1), texto = Convert.ToString(hoja.Rows[e.RowIndex].Cells[e.ColumnIndex].Value) ?? "";
            PonerCelda(dir, texto); RecalcularHoja(); Cambiado();
        };
        hoja.SelectionChanged += (s, e) => ActualizarFormula();
        formula.KeyDown += (s, e) =>
        { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Intentar(AplicarFormula); } };
        hoja.KeyDown += (s, e) =>
        {
            if (e.Control && e.KeyCode == Keys.V && !hoja.IsCurrentCellInEditMode) { e.SuppressKeyPress = true; Intentar(PegarHoja); }
            if (e.KeyCode == Keys.Delete && !hoja.IsCurrentCellInEditMode && HayPartida)
            { antes(); foreach (DataGridViewCell c in hoja.SelectedCells) PonerCelda(MYGHojaCalculo.Columna(c.ColumnIndex + 1) + (c.RowIndex + 1), ""); RecalcularHoja(); Cambiado(); e.SuppressKeyPress = true; }
        };
        p.Controls.Add(Barra(direccion, Etiqueta("fx"), formula, Boton("Aplicar", AplicarFormula), Etiqueta("Celda total"), celdaTotal,
            Boton("Usar total Excel", () =>
            {
                RequerirPartida(); string dir = MYGHojaCalculo.Normalizar(celdaTotal.Text); var n = new MYGHojaCalculo(actual.Costos.Hoja).Numero(dir);
                if (n < 0) throw new InvalidOperationException("El total de metrado debe ser positivo o cero.");
                antes(); actual.Costos.Hoja.CeldaTotal = dir; fuente.SelectedItem = MYGFuenteMetrado.Excel; detalle.SelectedTab = p; Cambiado();
            })));
        p.Controls.Add(Barra(Boton("Importar XLSX", ImportarHoja), Boton("Exportar XLSX", ExportarHoja), Boton("Copiar celdas", CopiarHoja), Boton("Pegar", PegarHoja),
            Boton("Rellenar abajo", RellenarHoja), Boton("N", () => FormatoHoja(true)), Boton("K", () => FormatoHoja(false)),
            Boton("Añadir filas", () => { RequerirPartida(); if ((long)(actual.Costos.Hoja.Filas + 20) * actual.Costos.Hoja.Columnas > 200000) throw new InvalidOperationException("Se alcanzó el límite de la hoja."); antes(); actual.Costos.Hoja.Filas += 20; CargarHoja(); despues(); })));
    }
    private void PonerCelda(string dir, string texto)
    {
        if (texto.Length > 32767) throw new InvalidOperationException("La celda supera los 32.767 caracteres.");
        var h = actual.Costos.Hoja; dir = MYGHojaCalculo.Normalizar(dir);
        if (!h.Celdas.TryGetValue(dir, out var c)) h.Celdas[dir] = c = new();
        c.Contenido = texto;
    }
    private void CargarHoja()
    {
        bool previo = cargando; cargando = true;
        try
        {
            hoja.Rows.Clear(); hoja.Columns.Clear(); if (!HayPartida) return; var h = actual.Costos.Hoja;
            MYGHojaCalculo.Validar(h); celdaTotal.Text = h.CeldaTotal;
            for (int c = 1; c <= h.Columnas; c++)
            {
                string letra = MYGHojaCalculo.Columna(c);
                hoja.Columns.Add(new DataGridViewTextBoxColumn { Name = letra, HeaderText = letra, Width = c == 1 ? 260 : c == 8 ? 160 : 90, ReadOnly = false, SortMode = DataGridViewColumnSortMode.NotSortable });
            }
            hoja.Rows.Add(h.Filas);
            foreach (DataGridViewRow r in hoja.Rows) r.HeaderCell.Value = (r.Index + 1).ToString();
            if (h.Filas >= 2) { hoja.Rows[0].Frozen = true; hoja.Rows[1].Frozen = true; }
            RecalcularHoja();
        }
        finally { cargando = previo; }
        ActualizarFormula();
    }
    private void RecalcularHoja()
    {
        if (!HayPartida) return; bool previo = cargando; cargando = true;
        try
        {
            var h = actual.Costos.Hoja; var motor = new MYGHojaCalculo(h);
            foreach (DataGridViewRow r in hoja.Rows)
                foreach (DataGridViewCell c in r.Cells)
                {
                    string dir = MYGHojaCalculo.Columna(c.ColumnIndex + 1) + (r.Index + 1);
                    c.Value = motor.Mostrar(dir); c.ToolTipText = motor.Contenido(dir);
                    if (h.Celdas.TryGetValue(dir, out var estilo)) c.Style.Font = estilo.Negrita ? negrita : estilo.Cursiva ? cursiva : hoja.Font;
                    AplicarTemaCeldaHoja(c, dir, h.CeldaTotal);
                }
        }
        finally { cargando = previo; }
        ActualizarFormula();
    }
    private void AplicarTemaHoja()
    {
        string total = HayPartida ? actual.Costos.Hoja.CeldaTotal : null;
        foreach (DataGridViewRow fila in hoja.Rows)
            foreach (DataGridViewCell celda in fila.Cells)
                AplicarTemaCeldaHoja(celda, MYGHojaCalculo.Columna(celda.ColumnIndex + 1) + (fila.Index + 1), total);
    }
    private static void AplicarTemaCeldaHoja(DataGridViewCell celda, string direccionCelda, string celdaTotal)
    {
        celda.Style.BackColor = direccionCelda == celdaTotal ? MYG2027_TemaComercial.ColorFiltro(3)
            : celda.RowIndex < 2 ? MYG2027_TemaComercial.AzulSuave : MYG2027_TemaComercial.Superficie;
        celda.Style.ForeColor = MYG2027_TemaComercial.Texto;
    }
    private void ActualizarFormula()
    {
        if (cargando || !HayPartida || hoja.CurrentCell == null) return;
        string dir = MYGHojaCalculo.Columna(hoja.CurrentCell.ColumnIndex + 1) + (hoja.CurrentCell.RowIndex + 1);
        direccion.Text = dir; formula.Text = new MYGHojaCalculo(actual.Costos.Hoja).Contenido(dir);
    }
    private void AplicarFormula()
    { RequerirPartida(); if (hoja.CurrentCell == null) return; antes(); PonerCelda(direccion.Text, formula.Text); RecalcularHoja(); Cambiado(); }
    private void CopiarHoja()
    {
        RequerirPartida(); if (hoja.SelectedCells.Count == 0) return;
        var celdas = hoja.SelectedCells.Cast<DataGridViewCell>().ToArray(); int f1 = celdas.Min(x => x.RowIndex), f2 = celdas.Max(x => x.RowIndex), c1 = celdas.Min(x => x.ColumnIndex), c2 = celdas.Max(x => x.ColumnIndex);
        var motor = new MYGHojaCalculo(actual.Costos.Hoja);
        Clipboard.SetText(string.Join("\r\n", Enumerable.Range(f1, f2 - f1 + 1).Select(f => string.Join("\t", Enumerable.Range(c1, c2 - c1 + 1).Select(c => motor.Contenido(MYGHojaCalculo.Columna(c + 1) + (f + 1)))))));
    }
    private void PegarHoja()
    {
        RequerirPartida(); if (hoja.CurrentCell == null || !Clipboard.ContainsText()) return;
        string[] filas = Clipboard.GetText().Replace("\r\n", "\n").Replace('\r', '\n').TrimEnd('\n').Split('\n');
        var datos = filas.Select(x => x.Split('\t')).ToArray(); int f0 = hoja.CurrentCell.RowIndex, c0 = hoja.CurrentCell.ColumnIndex;
        var h = actual.Costos.Hoja;
        if (f0 + datos.Length > h.Filas || c0 + datos.Max(x => x.Length) > h.Columnas) throw new InvalidOperationException("El contenido pegado excede la hoja; añada filas o seleccione otra celda.");
        if (datos.Any(x => x.Any(c => c.Length > 32767))) throw new InvalidOperationException("Una celda pegada es demasiado larga.");
        antes(); for (int f = 0; f < datos.Length; f++) for (int c = 0; c < datos[f].Length; c++) PonerCelda(MYGHojaCalculo.Columna(c0 + c + 1) + (f0 + f + 1), datos[f][c]);
        RecalcularHoja(); Cambiado();
    }
    private void RellenarHoja()
    {
        RequerirPartida(); var seleccion = hoja.SelectedCells.Cast<DataGridViewCell>().ToList(); if (seleccion.Count == 0) return;
        antes(); int primera = seleccion.Min(x => x.RowIndex); var motor = new MYGHojaCalculo(actual.Costos.Hoja);
        foreach (var c in seleccion.Where(x => x.RowIndex > primera))
        {
            string texto = motor.Contenido(MYGHojaCalculo.Columna(c.ColumnIndex + 1) + (primera + 1));
            if (texto.StartsWith('=')) texto = Regex.Replace(texto, @"(\$?[A-Za-z]{1,3})(\$?)([1-9][0-9]*)", m =>
                m.Groups[1].Value + m.Groups[2].Value + (m.Groups[2].Value == "$" ? m.Groups[3].Value : (int.Parse(m.Groups[3].Value) + c.RowIndex - primera).ToString()));
            PonerCelda(MYGHojaCalculo.Columna(c.ColumnIndex + 1) + (c.RowIndex + 1), texto);
        }
        RecalcularHoja(); Cambiado();
    }
    private void FormatoHoja(bool bold)
    {
        RequerirPartida(); antes(); foreach (DataGridViewCell c in hoja.SelectedCells)
        {
            string dir = MYGHojaCalculo.Columna(c.ColumnIndex + 1) + (c.RowIndex + 1); var h = actual.Costos.Hoja;
            if (!h.Celdas.TryGetValue(dir, out var estilo)) h.Celdas[dir] = estilo = new();
            if (bold) estilo.Negrita = !estilo.Negrita; else estilo.Cursiva = !estilo.Cursiva;
        }
        RecalcularHoja(); despues();
    }
    private void ImportarHoja()
    {
        RequerirPartida(); using var d = new OpenFileDialog { Filter = "Libro Excel (*.xlsx)|*.xlsx" };
        if (d.ShowDialog(this) != DialogResult.OK) return; var nombres = MYGExcelPresupuestos.Hojas(d.FileName);
        using var f = new MYGElegirCostoForm("Hoja que contiene el metrado", nombres.Cast<object>().ToArray()); if (f.ShowDialog(this) != DialogResult.OK) return;
        using var total = new MYGCamposProyectoForm("Total del metrado en Excel", new[] { "Dirección de la celda total" }, new[] { celdaTotal.Text });
        if (total.ShowDialog(this) != DialogResult.OK) return;
        var nueva = MYGExcelPresupuestos.Importar(d.FileName, (string)f.Elegido, total.Valores[0]);
        var n = new MYGHojaCalculo(nueva).Numero(nueva.CeldaTotal); if (n < 0) throw new InvalidOperationException("El metrado de la hoja es negativo.");
        antes(); actual.Costos.Hoja = nueva; CargarHoja(); Cambiado();
    }
    private void ExportarHoja()
    {
        RequerirPartida(); hoja.EndEdit(); using var d = new SaveFileDialog { Filter = "Libro Excel (*.xlsx)|*.xlsx", FileName = "Metrado_" + actual.Item + ".xlsx" };
        if (d.ShowDialog(this) == DialogResult.OK) MYGExcelPresupuestos.Guardar(d.FileName, new[] { actual.Costos.Hoja });
    }
    internal void ExportarPresupuesto()
    {
        if (P == null) return; FinalizarEdicion(); MYGMotorPresupuestos.Validar(P);
        using var d = new SaveFileDialog { Filter = "Libro de presupuesto (*.xlsx)|*.xlsx", FileName = "Presupuesto.xlsx" }; if (d.ShowDialog(this) != DialogResult.OK) return;
        var resumen = MYGMotorPresupuestos.Resumen(P);
        var hojas = new List<MYGHojaMetrado>
        {
            MYGExcelPresupuestos.Tabla("Presupuesto", new[] { "Ítem", "Descripción", "Unidad", "Cantidad", "Precio unitario", "Total" },
                MYGOrdenPresupuestos.FilasOrdenadas(P).Select(i => new object[] { i.Item, i.Descripcion, i.Unidad, MYGProyectoStorage.EsTitulo(i) ? null : MYGMotorPresupuestos.Cantidad(P, i), MYGProyectoStorage.EsTitulo(i) ? null : MYGMotorPresupuestos.Analizar(P, i).PrecioUnitario, MYGMotorPresupuestos.TotalPartida(P, i) })),
            MYGExcelPresupuestos.Tabla("Resumen", new[] { "Concepto", "Moneda", "Importe" }, new[]
            {
                new object[] { "Costo directo", P.Costos.Moneda, resumen.CostoDirecto }, new object[] { "Gastos generales", P.Costos.Moneda, resumen.GastosGenerales },
                new object[] { "Utilidad", P.Costos.Moneda, resumen.Utilidad }, new object[] { "Subtotal", P.Costos.Moneda, resumen.Subtotal },
                new object[] { "I.G.V.", P.Costos.Moneda, resumen.Impuesto },
                new object[] { "Otros impuestos", P.Costos.Moneda, resumen.OtrosImpuestos }, new object[] { "Total", P.Costos.Moneda, resumen.Total }
            }),
            MYGExcelPresupuestos.Tabla("ACU", new[] { "Ítem", "Partida", "Rend. diario", "Jornada", "Grupo", "Código", "Recurso", "Unidad", "Modo", "Nro. recursos", "Cantidad", "% Desp.", "Precio", "Total por unidad" },
                P.Items.Where(i => !MYGProyectoStorage.EsTitulo(i)).SelectMany(i => MYGMotorPresupuestos.Analizar(P, i).Recursos.Select(r => new object[]
                { i.Item, i.Descripcion, i.Costos.RendimientoDiario, i.Costos.JornadaHoras, MYGMotorPresupuestos.Grupo(r.Recurso.Grupo), r.Codigo, r.Descripcion, r.Unidad, r.Recurso.Modo, r.Recurso.NumeroRecursos, r.Cantidad, r.Recurso.DesperdicioPorcentaje, r.Precio, r.Total }))),
            MYGExcelPresupuestos.Tabla("Insumos", new[] { "Grupo", "Código", "Descripción", "Unidad", "Precio" },
                P.Costos.Insumos.Select(i => new object[] { MYGMotorPresupuestos.Grupo(i.Grupo), i.Codigo, i.Descripcion, i.Unidad, i.Precio })),
            MYGExcelPresupuestos.Tabla("Consolidado", new[] { "Grupo", "Código", "Descripción", "Unidad", "Cantidad", "Precio", "Total" },
                MYGMotorPresupuestos.Consolidar(P).Select(i => new object[] { MYGMotorPresupuestos.Grupo(i.Grupo), i.Codigo, i.Descripcion, i.Unidad, i.Cantidad, i.Precio, i.Total })),
            MYGExcelPresupuestos.Tabla("Metrados manuales", new[] { "Ítem", "Partida", "Descripción", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Descuento", "Parcial", "Referencia", "Imagen" },
                P.Items.SelectMany(i => i.Costos.Metrados.Select(m => new object[] { i.Item, i.Descripcion, m.Descripcion, m.Elementos, m.CantidadPorElemento, m.Largo, m.Ancho, m.Alto, m.Descuento, MYGMotorPresupuestos.Parcial(m), m.Referencia, m.ImagenRuta }))),
            MYGExcelPresupuestos.Tabla("Metrados BIM", new[] { "Ítem", "Partida", "Activo", "Tabla", "Unidad", "Cantidad", "Fecha UTC" },
                P.Items.SelectMany(i => i.Costos.MetradosBIM.Select(m => new object[] { i.Item, i.Descripcion, m.ActivoId, m.Tabla, m.Unidad, m.Cantidad, m.FechaUtc.ToString("O") })))
        };
        foreach (var h in hojas)
        {
            int[] columnas = h.Nombre switch
            {
                "Presupuesto" => new[] { 4, 5, 6 },
                "Resumen" => new[] { 3 },
                "Insumos" => new[] { 5 },
                "Consolidado" => new[] { 6, 7 },
                "ACU" => new[] { 13, 14 },
                _ => Array.Empty<int>()
            };
            foreach (var celda in h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila > 1 && columnas.Contains(MYGHojaCalculo.Coordenadas(c.Key).Columna)))
                celda.Value.FormatoNumero = "#,##0.00";
        }
        foreach (var i in P.Items.Where(x => x.Costos.FuenteMetrado == MYGFuenteMetrado.Excel))
        { var h = MYGProyectoStorage.Copia(i.Costos.Hoja); h.Nombre = "Metrado " + i.Item; hojas.Add(h); }
        MYGExcelPresupuestos.Guardar(d.FileName, hojas);
    }
    internal void Resumen()
    {
        if (P == null) return; FinalizarEdicion(); using var f = new MYGResumenCostosForm(P);
        if (f.ShowDialog(this) == DialogResult.OK) { antes(); P.Costos.Moneda = f.Moneda; P.Costos.GastosGeneralesPorcentaje = f.Gastos; P.Costos.UtilidadPorcentaje = f.Utilidad; P.Costos.ImpuestoPorcentaje = f.Impuesto; P.Costos.OtrosImpuestosPorcentaje = f.Otros; Cambiado(); }
    }
    internal void ImprimirPresupuesto()
    {
        if (P == null) return; FinalizarEdicion(); MYGMotorPresupuestos.Validar(P); var resumen = MYGMotorPresupuestos.Resumen(P);
        string texto = string.Join("\n", MYGOrdenPresupuestos.FilasOrdenadas(P).Select(i => i.Item + "  " + i.Descripcion +
            (MYGProyectoStorage.EsTitulo(i) ? "" : "\n    " + MYGFormatoPresupuesto.Cantidad(MYGMotorPresupuestos.Cantidad(P, i)) + " " + i.Unidad + " × " + MYGFormatoPresupuesto.Dinero(MYGMotorPresupuestos.Analizar(P, i).PrecioUnitario)) +
            "   " + P.Costos.Moneda + " " + MYGFormatoPresupuesto.Dinero(MYGMotorPresupuestos.TotalPartida(P, i)))) +
            FormattableString.Invariant($"\n\nCosto directo: {resumen.CostoDirecto:N2}\nGastos generales: {resumen.GastosGenerales:N2}\nUtilidad: {resumen.Utilidad:N2}\nParcial: {resumen.Subtotal:N2}\nI.G.V.: {resumen.Impuesto:N2}\nOtros impuestos: {resumen.OtrosImpuestos:N2}\nTOTAL: {P.Costos.Moneda} {resumen.Total:N2}");
        ImprimirTexto(P.Nombre, texto);
    }
    private void ImprimirTexto(string titulo, string contenido)
    {
        using var documento = new PrintDocument { DocumentName = titulo }; using var fuenteTexto = new Font("Arial", 10);
        string restante = titulo + "\n\n" + contenido;
        documento.PrintPage += (s, e) =>
        {
            e.Graphics.MeasureString(restante, fuenteTexto, e.MarginBounds.Size, StringFormat.GenericTypographic, out int caracteres, out _);
            if (caracteres <= 0) throw new InvalidOperationException("El área de impresión es demasiado pequeña.");
            e.Graphics.DrawString(restante[..caracteres], fuenteTexto, Brushes.Black, e.MarginBounds, StringFormat.GenericTypographic);
            restante = restante[caracteres..]; e.HasMorePages = restante.Length > 0;
        };
        using var d = new PrintDialog { Document = documento, UseEXDialog = true };
        if (d.ShowDialog(this) == DialogResult.OK) documento.Print();
    }
}

internal sealed class MYGResumenCostosForm : Form
{
    internal string Moneda { get; private set; }
    internal decimal Gastos { get; private set; }
    internal decimal Utilidad { get; private set; }
    internal decimal Impuesto { get; private set; }
    internal decimal Otros { get; private set; }
    internal MYGResumenCostosForm(MYGPresupuestoDocumento p)
    {
        Text = "MYG | Resumen de costos"; StartPosition = FormStartPosition.CenterParent; ClientSize = new(620, 480); Font = new("Segoe UI", 10);
        var tabla = new TableLayoutPanel { Dock = DockStyle.Top, Height = 200, ColumnCount = 2, RowCount = 5, Padding = new(12) };
        tabla.ColumnStyles.Add(new(SizeType.Percent, 60)); tabla.ColumnStyles.Add(new(SizeType.Percent, 40));
        var moneda = new TextBox { Text = p.Costos.Moneda, Dock = DockStyle.Fill };
        NumericUpDown Porcentaje(decimal v) => new() { Value = Math.Min(v, 10000), Maximum = 10000, DecimalPlaces = 4, Dock = DockStyle.Fill };
        var gastos = Porcentaje(p.Costos.GastosGeneralesPorcentaje); var utilidad = Porcentaje(p.Costos.UtilidadPorcentaje); var impuesto = Porcentaje(p.Costos.ImpuestoPorcentaje);
        var otros = Porcentaje(p.Costos.OtrosImpuestosPorcentaje);
        string[] nombres = { "Moneda", "Gastos generales (% costo directo)", "Utilidad (% costo directo)", "I.G.V. (% subtotal)", "Otros impuestos (% subtotal)" }; Control[] controles = { moneda, gastos, utilidad, impuesto, otros };
        for (int n = 0; n < 5; n++) { tabla.RowStyles.Add(new(SizeType.Percent, 20)); tabla.Controls.Add(new Label { Text = nombres[n], AutoSize = true }, 0, n); tabla.Controls.Add(controles[n], 1, n); }
        var importes = new Label { Dock = DockStyle.Fill, Padding = new(18), Font = new("Segoe UI", 11) };
        void Calcular()
        {
            var copia = MYGProyectoStorage.Copia(p); copia.Costos.GastosGeneralesPorcentaje = gastos.Value; copia.Costos.UtilidadPorcentaje = utilidad.Value; copia.Costos.ImpuestoPorcentaje = impuesto.Value; copia.Costos.OtrosImpuestosPorcentaje = otros.Value;
            var r = MYGMotorPresupuestos.Resumen(copia); importes.Text = FormattableString.Invariant($"Costo directo: {r.CostoDirecto:N2}\nGastos generales: {r.GastosGenerales:N2}\nUtilidad: {r.Utilidad:N2}\nSubtotal: {r.Subtotal:N2}\nI.G.V.: {r.Impuesto:N2}\nOtros impuestos: {r.OtrosImpuestos:N2}\n\nTOTAL: {moneda.Text} {r.Total:N2}");
        }
        gastos.ValueChanged += (s, e) => Calcular(); utilidad.ValueChanged += (s, e) => Calcular(); impuesto.ValueChanged += (s, e) => Calcular(); otros.ValueChanged += (s, e) => Calcular(); moneda.TextChanged += (s, e) => Calcular();
        var aceptar = new Button { Text = "Aplicar", Dock = DockStyle.Bottom, Height = 36 };
        aceptar.Click += (s, e) => { if (string.IsNullOrWhiteSpace(moneda.Text)) return; Moneda = moneda.Text.Trim(); Gastos = gastos.Value; Utilidad = utilidad.Value; Impuesto = impuesto.Value; Otros = otros.Value; DialogResult = DialogResult.OK; };
        Controls.Add(importes); Controls.Add(tabla); Controls.Add(aceptar); Calcular();
    }
}
