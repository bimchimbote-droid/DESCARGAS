using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class PresupuestoDetalleCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Proyecto de detalle", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            presupuesto.Item = "01";
            var primera = Partida("01", "CONCRETO EN COLUMNAS", 1);
            var segunda = Partida("02", "ACERO EN COLUMNAS", 2);
            presupuesto.Items.AddRange(new[] { primera, segunda });
            var manual = new MYGLineaMetrado
            {
                Descripcion = "Metrado existente", Elementos = 2m, CantidadPorElemento = 3m,
                Largo = 2m, Referencia = "Plano E-01", ImagenRuta = "referencia-existente.png"
            };
            primera.Costos.Metrados.Add(manual);
            primera.Costos.MetradosBIM.Add(new MYGMetradoBIM
            {
                ActivoId = "activo-01", DocumentoId = "documento-01", Tabla = "Columnas",
                Unidad = "m³", Cantidad = 48.25m, FechaUtc = new DateTime(2026, 10, 12, 12, 0, 0, DateTimeKind.Utc)
            });
            primera.Costos.Hoja.Poner("G16", "37.5");
            primera.Costos.EspecificacionTexto = "Especificación de concreto conservada.";
            int antes = 0, cambios = 0, guardados = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antes++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (nodo, columna, valor) =>
            {
                var vigente = presupuesto.Items.Single(i => i.Id == ((ItemPresupuestoDelphin)nodo).Id);
                if (columna == "ITEM") vigente.Item = valor;
                else if (columna == "DESC") vigente.Descripcion = valor;
            }, () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1500, 850) };
            formulario.Controls.Add(panel);
            formulario.Show();
            panel.Refrescar();
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();

            var detalle = Controles(panel).OfType<TabControl>().Single(t =>
                t.TabPages.Cast<TabPage>().Any(p => p.Text == "Análisis de C.U."));
            string[] orden = { "Análisis de C.U.", "Específ. técnicas", "Metrados en Excel", "Metrados BIM", "Σ Consol. de Partida" };
            exige(detalle.TabPages.Cast<TabPage>().Select(p => p.Text).SequenceEqual(orden),
                "El detalle debe ofrecer ACU, especificaciones, Excel, BIM y consolidado en ese orden, sin la pestaña de metrado manual.");
            var paginaACU = detalle.TabPages[0];
            var paginaEspecificaciones = detalle.TabPages[1];
            var paginaExcel = detalle.TabPages[2];
            var paginaBIM = detalle.TabPages[3];
            var paginaConsolidado = detalle.TabPages[4];
            var acu = Controles(paginaACU).OfType<DataGridView>().Single(t => t.Columns.Contains("NREC"));
            var hoja = Controles(paginaExcel).OfType<DataGridView>().Single();
            var bim = Controles(paginaBIM).OfType<DataGridView>().Single();
            var consolidado = Controles(paginaConsolidado).OfType<DataGridView>().Single();
            var cabeceraACU = Controles(paginaACU).Single(c => c.Name == "acu_cabecera");
            var cabeceraEspecificaciones = Controles(paginaEspecificaciones).Single(c => c.Name == "espec_cabecera");
            var fuente = Controles(panel).OfType<ComboBox>().Single(c =>
                c.Items.Cast<object>().OfType<MYGFuenteMetrado>().SequenceEqual(Enum.GetValues<MYGFuenteMetrado>()));
            exige(Controles(paginaACU).Contains(fuente) && !Controles(panel).OfType<Button>().Any(b => b.Text == "Usar metrado manual"),
                "El origen del metrado debe seguir disponible desde ACU sin conservar los comandos de la pestaña eliminada.");
            exige(cabeceraACU is MYGEspecificacionesCabecera && !Controles(cabeceraACU).OfType<Button>().Any(),
                "La cabecera de ACU debe compartir el diseño de especificaciones y no ofrecer exportación de documentos Word/PDF.");
            VerificarIconos(detalle, exige);
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", primera.Descripcion, exige);

            var sinCambios = (antes, cambios, guardados);
            foreach (var (pagina, contenido) in new[]
            {
                (paginaACU, (Control)acu), (paginaEspecificaciones, cabeceraEspecificaciones),
                (paginaExcel, hoja), (paginaBIM, bim), (paginaConsolidado, consolidado)
            })
            {
                detalle.SelectedTab = pagina;
                Application.DoEvents();
                exige(detalle.SelectedTab == pagina && contenido.Visible,
                    $"Seleccionar {pagina.Text} debe mostrar su propio contenido tras reorganizar las pestañas.");
                VerificarManual();
            }
            exige((antes, cambios, guardados) == sinCambios,
                "Recorrer las nuevas pestañas no debe cambiar los datos, crear historial ni guardar el proyecto.");

            detalle.SelectedTab = paginaExcel;
            Application.DoEvents();
            exige(hoja.Columns.Contains("G") && hoja.Rows.Count >= 16,
                "La pestaña Excel debe cargar la hoja de la partida antes de utilizar su total.");
            Controles(paginaExcel).OfType<Button>().Single(b => b.Text == "Usar total Excel").PerformClick();
            Application.DoEvents();
            exige(detalle.SelectedTab == paginaExcel && hoja.Visible && !consolidado.Visible &&
                primera.Costos.FuenteMetrado == MYGFuenteMetrado.Excel && MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 37.5m,
                "Usar total Excel debe conservar la página Excel y calcular su metrado; no debe saltar al consolidado por un índice antiguo.");
            VerificarManual();
            detalle.SelectedTab = paginaBIM;
            Application.DoEvents();
            Controles(paginaBIM).OfType<Button>().Single(b => b.Text == "Usar cantidad BIM").PerformClick();
            Application.DoEvents();
            exige(detalle.SelectedTab == paginaACU && acu.Visible && primera.Costos.FuenteMetrado == MYGFuenteMetrado.BIM &&
                MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 48.25m,
                "Usar cantidad BIM debe volver al ACU y utilizar la cantidad BIM después de cambiar el orden de pestañas.");
            fuente.SelectedItem = MYGFuenteMetrado.Manual;
            Application.DoEvents();
            exige(primera.Costos.FuenteMetrado == MYGFuenteMetrado.Manual && MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 12m,
                "Los proyectos existentes deben poder seguir usando su metrado manual mediante el selector de origen del ACU.");
            VerificarManual();

            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos();
                detalle.SelectedTab = paginaEspecificaciones;
                Application.DoEvents();
                detalle.SelectedTab = paginaACU;
                Application.DoEvents();
                VerificarEstilo(cabeceraACU, cabeceraEspecificaciones, acu, exige);
                VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", primera.Descripcion, exige);
                VerificarManual();
            }

            sinCambios = (antes, cambios, guardados);
            panel.SeleccionarEstructura(segunda);
            Application.DoEvents();
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.02", segunda.Descripcion, exige);
            panel.SeleccionarEstructura(presupuesto);
            Application.DoEvents();
            exige(Etiqueta(cabeceraACU, "item").Text == "" &&
                Etiqueta(cabeceraACU, "partida").Text != primera.Descripcion && Etiqueta(cabeceraACU, "partida").Text != segunda.Descripcion &&
                Etiqueta(cabeceraACU, "presupuesto").Text == presupuesto.Nombre,
                "Al seleccionar el presupuesto la cabecera de ACU debe vaciar el ítem y descartar el contexto de la partida anterior.");
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();
            exige((antes, cambios, guardados) == sinCambios,
                "Cambiar entre partidas y presupuesto debe actualizar la cabecera sin modificar el modelo ni guardar archivos.");

            var estructura = Controles(panel).OfType<DataGridView>().Single(t => t.Columns.Contains("EXP") && t.Columns.Contains("ITEM"));
            Editar("DESC", "CONCRETO EDITADO");
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", "CONCRETO EDITADO", exige);
            Editar("ITEM", "09");
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.09", "CONCRETO EDITADO", exige);

            // El historial sustituye el modelo y conserva sus Id. La cabecera
            // debe volver a leer la instancia actual en vez del Tag anterior.
            presupuesto = MYGProyectoStorage.Copia(presupuesto);
            proyecto.Presupuestos[0] = presupuesto;
            var vigente = presupuesto.Items.Single(i => i.Id == primera.Id);
            vigente.Descripcion = "CONCRETO RESTAURADO";
            panel.Refrescar();
            Application.DoEvents();
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.09", vigente.Descripcion, exige);
            exige(vigente.Costos.Metrados.Count == 1 && vigente.Costos.Metrados[0].Descripcion == manual.Descripcion &&
                vigente.Costos.Metrados[0].ImagenRuta == manual.ImagenRuta && MYGMotorPresupuestos.Cantidad(presupuesto, vigente) == 12m && guardados == 0,
                "Refrescar y restaurar el modelo debe conservar el metrado manual existente sin guardar el proyecto.");
            formulario.Close();

            void VerificarManual()
            {
                exige(primera.Costos.Metrados.Count == 1 && ReferenceEquals(primera.Costos.Metrados[0], manual) &&
                    manual.Descripcion == "Metrado existente" && manual.Elementos == 2m && manual.CantidadPorElemento == 3m &&
                    manual.Largo == 2m && manual.Ancho == null && manual.Alto == null && !manual.Descuento &&
                    manual.Referencia == "Plano E-01" && manual.ImagenRuta == "referencia-existente.png",
                    "Eliminar la pestaña manual y cambiar de vista o fuente no debe borrar ni modificar las líneas de metrado guardadas.");
            }

            void Editar(string columna, string texto)
            {
                var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is ItemPresupuestoDelphin i && i.Id == primera.Id);
                estructura.CurrentCell = fila.Cells[columna];
                exige(estructura.BeginEdit(true) && estructura.EditingControl is TextBox,
                    $"La prueba de contexto debe editar la celda real {columna} de la estructura.");
                ((TextBox)estructura.EditingControl).Text = texto;
                panel.FinalizarEdicion();
                Application.DoEvents();
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static ItemPresupuestoDelphin Partida(string item, string nombre, int posicion) => new()
    {
        Id = MYGProyectoStorage.NuevoId(), Item = item, Descripcion = nombre, Unidad = "m³",
        TipoPropuesta = "PARTIDA", Posicion = posicion,
        Costos = new MYGDatosPartida { Cantidad = 4m, PrecioDirecto = 10m }
    };

    private static void VerificarContexto(Control cabecera, string presupuesto, string item, string partida, Action<bool, string> exige)
    {
        exige(Etiqueta(cabecera, "titulo").Text == "Análisis de costos unitarios" &&
            Etiqueta(cabecera, "presupuesto").Text == presupuesto && Etiqueta(cabecera, "item").Text == item &&
            Etiqueta(cabecera, "partida").Text == partida,
            "La cabecera de ACU debe mostrar su título, presupuesto, código y descripción de la partida vigente.");
    }

    private static void VerificarEstilo(Control acu, Control especificaciones, DataGridView tabla, Action<bool, string> exige)
    {
        exige(acu.Dock == DockStyle.Top && acu.Visible && acu.Top == 0 && tabla.Top >= acu.Bottom &&
            acu.Height == especificaciones.Height && acu.BackColor.ToArgb() == especificaciones.BackColor.ToArgb() &&
            acu.BackColor.ToArgb() == MYG2027_TemaComercial.Superficie.ToArgb(),
            "El título de ACU debe ocupar una cabecera superior con la altura y el fondo de especificaciones, sin superponerse a la tabla.");
        foreach (string dato in new[] { "titulo", "presupuesto", "item", "partida" })
        {
            var etiquetaACU = Etiqueta(acu, dato);
            var etiquetaEspecificaciones = Etiqueta(especificaciones, dato);
            exige(etiquetaACU.Font.Name == etiquetaEspecificaciones.Font.Name &&
                Math.Abs(etiquetaACU.Font.SizeInPoints - etiquetaEspecificaciones.Font.SizeInPoints) < .01f &&
                etiquetaACU.Font.Style == etiquetaEspecificaciones.Font.Style && etiquetaACU.Location == etiquetaEspecificaciones.Location &&
                etiquetaACU.Height == etiquetaEspecificaciones.Height &&
                etiquetaACU.ForeColor.ToArgb() == etiquetaEspecificaciones.ForeColor.ToArgb() &&
                etiquetaACU.BackColor.ToArgb() == etiquetaEspecificaciones.BackColor.ToArgb(),
                $"La etiqueta {dato} de ACU debe mantener tipografía, posición y colores del diseño de especificaciones en ambos temas.");
        }
        exige(Etiqueta(acu, "titulo").ForeColor.ToArgb() == MYG2027_TemaComercial.Texto.ToArgb() &&
            Etiqueta(acu, "item").ForeColor.ToArgb() == MYG2027_TemaComercial.Secundario.ToArgb(),
            "La cabecera de ACU debe tomar los colores actuales del tema, también después de alternar entre normal y oscuro.");
    }

    private static void VerificarIconos(TabControl detalle, Action<bool, string> exige)
    {
        string[] nombres = { "acu", "especificacion", "excel", "bim", "resumen" };
        exige(detalle.ImageList != null && detalle.ImageList.Images.Count == nombres.Length,
            "Las pestañas de detalle deben conservar un icono por página y retirar el icono del metrado manual.");
        for (int i = 0; i < nombres.Length; i++)
        {
            using var imagen = MYGIconos.Obtener(nombres[i]);
            using var esperados = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
            esperados.Images.Add(imagen);
            int indice = detalle.TabPages[i].ImageIndex;
            exige(indice >= 0 && indice < detalle.ImageList.Images.Count,
                $"La pestaña {detalle.TabPages[i].Text} debe tener un icono válido.");
            using var actual = new Bitmap(detalle.ImageList.Images[indice]);
            using var esperado = new Bitmap(esperados.Images[0]);
            exige(actual.Size == esperado.Size && Enumerable.Range(0, actual.Height).All(y =>
                Enumerable.Range(0, actual.Width).All(x => actual.GetPixel(x, y).ToArgb() == esperado.GetPixel(x, y).ToArgb())),
                $"La pestaña {detalle.TabPages[i].Text} debe mostrar el icono {nombres[i]} tras reorganizar el detalle.");
        }
    }

    private static Label Etiqueta(Control cabecera, string dato) =>
        Controles(cabecera).OfType<Label>().Single(e => e.Name == cabecera.Name + "_" + dato);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
