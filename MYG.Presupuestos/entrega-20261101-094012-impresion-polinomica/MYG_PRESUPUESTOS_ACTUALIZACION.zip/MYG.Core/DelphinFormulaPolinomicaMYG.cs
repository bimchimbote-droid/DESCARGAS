using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

internal static partial class DelphinImportacionMYG
{
    // Se consulta la agrupación nativa sin escribir coeficientes calculados ni
    // modificar las tablas de origen. Las ediciones se guardan como extensión MYG.
    private static void LeerFormulaPolinomica(Lectura lectura, MYGPresupuestoDocumento presupuesto)
    {
        var filas = lectura.Filas("titulo_indice", new[] { "id_titulo", "id_titulopadre", "id_presupuesto",
            "descripcion_titulo", "posicion_titulo", "codigo_clase", "es_indice", "nomenclatura", "coeficiente", "porcentaje", "coeficientedefinido" },
            "id_presupuesto", presupuesto.Id);
        if (filas.Count == 0) return;
        var porId = filas.Where(x => !string.IsNullOrEmpty(x.Texto("id_titulo")))
            .GroupBy(x => x.Texto("id_titulo"), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(x => x.Key, x => x.First(), StringComparer.OrdinalIgnoreCase);
        var hijos = filas.GroupBy(x => x.Texto("id_titulopadre"), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(x => x.Key, x => x.OrderBy(y => y.Entero("posicion_titulo")).ToList(), StringComparer.OrdinalIgnoreCase);
        var raices = filas.Where(x => !porId.ContainsKey(x.Texto("id_titulopadre")))
            .OrderBy(x => x.Entero("posicion_titulo")).ToList();
        string Codigo(Fila fila) => MYGCatalogoIndicesUnificados.CodigoDeClasificacion(fila.Texto("codigo_clase"));
        // Algunas hojas reconstruyen un monomio por IU y dejan filas de la
        // fórmula anterior enlazadas a sus IDs reutilizados. Sólo reconocer
        // esa reconstrucción si TODO el listado la acredita: códigos únicos,
        // 100 % y un hijo del mismo IU que conserva el coeficiente completo.
        // Una raíz con código por sí sola también puede ser un grupo válido.
        bool listadoIndividual = raices.Count > 0 && raices.Select(Codigo).Distinct(StringComparer.OrdinalIgnoreCase).Count() == raices.Count
            && raices.All(raiz => !string.IsNullOrEmpty(Codigo(raiz))
                && raiz.Numero("porcentaje") == 100m && raiz.Numero("coeficiente") > 0m
                && hijos.TryGetValue(raiz.Texto("id_titulo"), out var directos)
                && directos.Any(hijo => Igual(hijo.Texto("es_indice"), "S")
                    && Igual(Codigo(hijo), Codigo(raiz)) && hijo.Numero("porcentaje") == 100m
                    && hijo.Numero("coeficiente") == raiz.Numero("coeficiente")));
        // El listado reconstruido deja a cero todas las celdas definidas sin
        // inicializarlas. No confundir ese caso global con un cero explícito
        // dentro de una configuración que sí contiene valores definidos.
        bool definidosSinInicializar = listadoIndividual && raices.All(raiz =>
            raiz.Valor("coeficientedefinido") != null && raiz.Numero("coeficientedefinido") == 0m);
        var configuracion = new MYGConfiguracionFormulaPolinomica();
        var usados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var raiz in raices)
        {
            var grupo = new MYGGrupoFormulaPolinomica
            {
                Id = raiz.Texto("id_titulo"), Descripcion = raiz.Texto("descripcion_titulo"),
                Nomenclatura = raiz.Texto("nomenclatura"),
                CoeficienteDefinido = definidosSinInicializar || raiz.Valor("coeficientedefinido") == null
                    ? null : raiz.Numero("coeficientedefinido")
            };
            if (listadoIndividual)
            {
                string codigo = Codigo(raiz);
                if (usados.Add(codigo)) grupo.Indices.Add(codigo);
                configuracion.Grupos.Add(grupo);
                continue;
            }
            var pendientes = new Stack<string>(); pendientes.Push(raiz.Texto("id_titulo"));
            var visitados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            while (pendientes.TryPop(out string id))
            {
                if (!visitados.Add(id) || !porId.TryGetValue(id, out var fila)) continue;
                bool tieneHijos = hijos.TryGetValue(id, out var descendientes);
                if (!tieneHijos || Igual(fila.Texto("es_indice"), "S"))
                {
                    string codigo = Codigo(fila);
                    if (!string.IsNullOrEmpty(codigo) && usados.Add(codigo)) grupo.Indices.Add(codigo);
                }
                if (tieneHijos) foreach (var hijo in descendientes.AsEnumerable().Reverse()) pendientes.Push(hijo.Texto("id_titulo"));
            }
            if (grupo.Indices.Count > 0) configuracion.Grupos.Add(grupo);
        }
        if (configuracion.Grupos.Count > 0) presupuesto.FormulaPolinomica = configuracion;
    }
}
