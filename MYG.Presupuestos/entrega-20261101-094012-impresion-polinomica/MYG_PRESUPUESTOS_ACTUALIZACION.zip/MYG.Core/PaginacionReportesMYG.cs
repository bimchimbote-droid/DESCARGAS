using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

/// <summary>Planificación pura compartida por la vista previa y las comprobaciones
/// de impresión. Conserva todos los índices originales de filas y columnas.</summary>
public static class MYGPaginacionReportes
{
    public static IReadOnlyList<int[]> SegmentarColumnas(IReadOnlyList<float> anchos, float anchoDisponible, int columnasRepetidas = 1,
        float escalaMinima = .85f)
    {
        if (anchos == null || anchos.Count == 0 || !Positivo(anchoDisponible) || anchos.Any(a => !Positivo(a))
            || columnasRepetidas < 1 || columnasRepetidas > anchos.Count || !Positivo(escalaMinima) || escalaMinima > 1)
            throw new ArgumentException("Los anchos y el espacio disponible deben ser números positivos y finitos.");
        double capacidad = (double)anchoDisponible / escalaMinima;
        capacidad += Math.Max(1d, capacidad) * .000001d;
        if (anchos.Sum(a => (double)a) <= capacidad) return new[] { Enumerable.Range(0, anchos.Count).ToArray() };
        if (anchos.Count == columnasRepetidas) throw new InvalidOperationException("Las columnas identificadoras no caben con texto legible. Reduzca su ancho o utilice papel más grande.");
        var resultado = new List<int[]>();
        int siguiente = columnasRepetidas;
        while (siguiente < anchos.Count)
        {
            var banda = Enumerable.Range(0, columnasRepetidas).ToList();
            double ancho = anchos.Take(columnasRepetidas).Sum(a => (double)a);
            while (siguiente < anchos.Count && ancho + anchos[siguiente] <= capacidad)
            { ancho += anchos[siguiente]; banda.Add(siguiente++); }
            if (banda.Count == columnasRepetidas)
                throw new InvalidOperationException("La columna identificadora y la columna " + MYGHojaCalculo.Columna(siguiente + 1) +
                    " no caben con texto legible. Reduzca sus anchos o utilice papel más grande.");
            resultado.Add(banda.ToArray());
        }
        return resultado;
    }

    /// <summary>Filas originales de cada página. Altos se indexa por posición en filas, omitiendo las ocultas.</summary>
    public static IReadOnlyList<int[]> PaginarFilas(IReadOnlyList<int> filas, IReadOnlyList<float> altos,
        IReadOnlyList<(int Primera, int Ultima)> combinaciones, float altoDisponible, int filasTitulo,
        float? altoDisponibleSiguientes = null)
    {
        if (filas == null || altos == null || combinaciones == null || filas.Count != altos.Count || !Positivo(altoDisponible) ||
            altos.Any(a => !Positivo(a)) || filasTitulo < 0 || filasTitulo > filas.Count
            || altoDisponibleSiguientes.HasValue && !Positivo(altoDisponibleSiguientes.Value) ||
            filas.Where((f, i) => f < 1 || (i > 0 && f <= filas[i - 1])).Any() ||
            combinaciones.Any(c => c.Primera < 1 || c.Ultima < c.Primera))
            throw new ArgumentException("Las filas, alturas y combinaciones de impresión no son válidas.");
        if (filas.Count == 0) return Array.Empty<int[]>();
        if (altos.Sum() <= altoDisponible) return new[] { filas.ToArray() };

        int ultimaCabecera = filasTitulo == 0 ? 0 : filas[filasTitulo - 1];
        if (combinaciones.Any(c => c.Primera <= ultimaCabecera && c.Ultima > ultimaCabecera))
            throw new InvalidOperationException("Una combinación vertical atraviesa las cabeceras repetidas. Separe esa combinación para imprimir varias páginas.");
        float altoTitulos = altos.Take(filasTitulo).Sum();
        float altoSiguientes = altoDisponibleSiguientes ?? altoDisponible;
        if (altoTitulos >= altoDisponible || altoTitulos >= altoSiguientes)
            throw new InvalidOperationException("Las cabeceras repetidas ocupan toda el área de impresión.");

        // Unir intervalos superpuestos evita separar combinaciones encadenadas.
        var intervalos = new List<(int Primera, int Ultima)>();
        foreach (var intervalo in combinaciones.Where(c => c.Ultima > c.Primera).OrderBy(c => c.Primera))
        {
            if (intervalos.Count > 0 && intervalo.Primera <= intervalos[^1].Ultima)
                intervalos[^1] = (intervalos[^1].Primera, Math.Max(intervalos[^1].Ultima, intervalo.Ultima));
            else intervalos.Add(intervalo);
        }
        var resultado = new List<int[]>();
        var pagina = new List<int>();
        float usado = 0;
        int posicion = 0, intervaloActual = 0;
        while (posicion < filas.Count)
        {
            int fin = posicion;
            while (intervaloActual < intervalos.Count && intervalos[intervaloActual].Ultima < filas[posicion]) intervaloActual++;
            if (intervaloActual < intervalos.Count && intervalos[intervaloActual].Primera <= filas[posicion])
                while (fin + 1 < filas.Count && filas[fin + 1] <= intervalos[intervaloActual].Ultima) fin++;
            float alto = 0;
            for (int i = posicion; i <= fin; i++) alto += altos[i];
            float capacidad = resultado.Count == 0 ? altoDisponible : altoSiguientes;
            if (usado + alto > capacidad)
            {
                if (pagina.Count <= filasTitulo)
                    throw new InvalidOperationException("La fila " + filas[posicion] + " y su bloque combinado exceden el alto imprimible con las cabeceras.");
                resultado.Add(pagina.ToArray());
                pagina = filas.Take(filasTitulo).ToList();
                usado = altoTitulos;
                capacidad = altoSiguientes;
            }
            if (usado + alto > capacidad)
                throw new InvalidOperationException("La fila " + filas[posicion] + " y su bloque combinado exceden el alto imprimible con las cabeceras.");
            for (int i = posicion; i <= fin; i++) pagina.Add(filas[i]);
            usado += alto;
            posicion = fin + 1;
        }
        if (pagina.Count > 0) resultado.Add(pagina.ToArray());
        return resultado;
    }

    private static bool Positivo(float valor) => float.IsFinite(valor) && valor > 0;
}
