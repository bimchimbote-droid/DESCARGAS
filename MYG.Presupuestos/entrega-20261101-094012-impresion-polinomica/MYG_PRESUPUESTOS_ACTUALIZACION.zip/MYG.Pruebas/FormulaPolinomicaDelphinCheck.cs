using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class FormulaPolinomicaDelphinCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        ListadoReconstruido(carpeta, pasa);
        GrupoLegitimoConCodigo(carpeta, pasa);
        PatronIncompleto(carpeta, pasa);
        DefinidosExplicitos(carpeta, pasa);
        ExtensionExplicita(carpeta, pasa);
    }

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Fórmula nativa Delphin: " + mensaje); }

    private const string Individuales = """
        ('RAIZ-MO',NULL,'MO individual',1,'J','47','N',0.6,100,0),
        ('HIJO-MO','RAIZ-MO','MO individual',1,'','47','S',0.6,100,0),
        ('RAIZ-MAT',NULL,'Material individual',2,'M','21','N',0.4,100,0),
        ('HIJO-MAT','RAIZ-MAT','Material individual',1,'','21','S',0.4,100,0)
        """;

    private static string CrearBase(string carpeta, string nombre, string filas)
    {
        string ruta = Path.Combine(carpeta, nombre + ".sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString());
        conexion.Open(); using var cmd = conexion.CreateCommand();
        cmd.CommandText = """
            INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,tipo_gasto,decimales_costo)
            VALUES('PR-FORM-REG','US0000000001','IN0000000007','No','Regresión fórmula nativa','PR',2);
            INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto)
            VALUES('PS-FORM-REG','PR-FORM-REG','Presupuesto sintético',1,'01');
            INSERT INTO unidad(id_unidad,abreviatura_unidad) VALUES('U-FORM-REG','und');
            INSERT INTO costo_unitario(id_costounitario,id_presupuesto,id_unidad,descripcion_costo,cantidad,costo_unitario,parcial_costo)
            VALUES('CU-FORM-REG','PS-FORM-REG','U-FORM-REG','Partida sintética',1,100,100);
            """;
        cmd.CommandText += """
            INSERT INTO titulo_indice(id_titulo,id_titulopadre,descripcion_titulo,posicion_titulo,nomenclatura,
                codigo_clase,es_indice,coeficiente,porcentaje,coeficientedefinido)
            VALUES
            """ + filas + "; UPDATE titulo_indice SET id_presupuesto='PS-FORM-REG';";
        cmd.ExecuteNonQuery();
        return ruta;
    }

    private static MYGConfiguracionFormulaPolinomica Leer(string ruta) =>
        MYGBaseDatos.LeerProyecto(ruta).Presupuestos.Single().FormulaPolinomica;

    private static void ListadoReconstruido(string carpeta, Action<string> pasa)
    {
        string ruta = CrearBase(carpeta, "Formula listado reconstruido", Individuales + """
            ,('ANTIGUO-MAT','RAIZ-MO','Material de una fórmula anterior',2,'','21','S',0.15,100,0),
            ('ANTIGUO-HERR','HIJO-MAT','Herramienta de una fórmula anterior',1,'','37','S',0.02,100,0)
            """);
        string antes = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
        var grupos = Leer(ruta).Grupos;
        Exige(grupos.Count == 2 && grupos[0].Id == "RAIZ-MO" && grupos[1].Id == "RAIZ-MAT"
            && grupos[0].Indices.SequenceEqual(new[] { "47" }) && grupos[1].Indices.SequenceEqual(new[] { "21" }),
            "un listado individual completo absorbió índices viejos colgados de sus IDs reutilizados.");
        Exige(grupos.All(x => x.CoeficienteDefinido == null),
            "todos los ceros nativos sin inicializar se interpretaron como coeficientes definidos explícitos.");
        Exige(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta))) == antes,
            "leer el listado reconstruido modificó la base de origen.");
        pasa("Importación polinómica reconoce un listado individual completo y descarta sus restos históricos sin escribir la base");
    }

    private static void GrupoLegitimoConCodigo(string carpeta, Action<string> pasa)
    {
        string ruta = CrearBase(carpeta, "Formula grupo legitimo con codigo", """
            ('RAIZ-MO',NULL,'MO y herramientas',1,'J','47','N',0.8,100,0.8),
            ('HIJO-MO','RAIZ-MO','Mano de obra',1,'','47','S',0.6,75,0.6),
            ('HIJO-HERR','RAIZ-MO','Herramienta',2,'','37','S',0.2,25,0.2),
            ('RAIZ-MAT',NULL,'Material individual',2,'M','21','N',0.2,100,0.2),
            ('HIJO-MAT','RAIZ-MAT','Material',1,'','21','S',0.2,100,0.2)
            """);
        var grupos = Leer(ruta).Grupos;
        Exige(grupos.Count == 2 && grupos[0].Indices.SequenceEqual(new[] { "47", "37" })
            && grupos[0].CoeficienteDefinido == 0.8m && grupos[1].Indices.SequenceEqual(new[] { "21" })
            && grupos[1].CoeficienteDefinido == 0.2m,
            "la presencia de un código en la raíz destruyó una agrupación legítima con porcentajes que suman 100.");
        pasa("Importación polinómica conserva grupos legítimos con código raíz, porcentajes parciales y coeficientes explícitos");
    }

    private static void PatronIncompleto(string carpeta, Action<string> pasa)
    {
        string ruta = CrearBase(carpeta, "Formula patron individual incompleto", Individuales + """
            ,('HIJO-HERR','RAIZ-MO','Herramienta agrupada',2,'','37','S',0.02,100,0)
            """);
        using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString()))
        {
            conexion.Open(); using var cmd = conexion.CreateCommand();
            cmd.CommandText = "UPDATE titulo_indice SET porcentaje=90 WHERE id_titulo='HIJO-MAT';";
            cmd.ExecuteNonQuery();
        }
        var grupos = Leer(ruta).Grupos;
        Exige(grupos[0].Indices.SequenceEqual(new[] { "47", "37" })
            && grupos.All(x => x.CoeficienteDefinido == 0m),
            "se aplicó la simplificación o la eliminación de ceros sin que todas las raíces cumplieran el patrón.");
        pasa("Importación polinómica exige el patrón completo antes de interpretar un listado nativo como índices individuales");
    }

    private static void DefinidosExplicitos(string carpeta, Action<string> pasa)
    {
        string ruta = CrearBase(carpeta, "Formula definidos explicitos", Individuales);
        using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString()))
        {
            conexion.Open(); using var cmd = conexion.CreateCommand();
            cmd.CommandText = "UPDATE titulo_indice SET coeficientedefinido=1 WHERE id_titulo='RAIZ-MO';";
            cmd.ExecuteNonQuery();
        }
        var grupos = Leer(ruta).Grupos;
        Exige(grupos[0].CoeficienteDefinido == 1m && grupos[1].CoeficienteDefinido == 0m,
            "se descartó un cero explícito en una colección que sí contiene valores definidos.");
        pasa("Importación polinómica conserva los coeficientes explícitos y sus ceros cuando la colección está inicializada");
    }

    private static void ExtensionExplicita(string carpeta, Action<string> pasa)
    {
        string ruta = CrearBase(carpeta, "Formula extension explicita", Individuales);
        var documento = MYGBaseDatos.LeerProyecto(ruta);
        documento.Presupuestos.Single().FormulaPolinomica = new() { Grupos = new()
        {
            new() { Id = "GRUPO-USUARIO", Descripcion = "Agrupación propia", Nomenclatura = "JM",
                Indices = new() { "47", "21" }, CoeficienteDefinido = 1m }
        } };
        string esperado = JsonSerializer.Serialize(documento.Presupuestos.Single().FormulaPolinomica);
        MYGProyectoStorage.Guardar(ruta, documento);
        Exige(JsonSerializer.Serialize(Leer(ruta)) == esperado,
            "la lectura nativa reemplazó una agrupación explícita conservada en las extensiones MYG.");
        pasa("Las extensiones MYG preservan agrupaciones y coeficientes del usuario sobre un listado nativo reconstruido");
    }
}
