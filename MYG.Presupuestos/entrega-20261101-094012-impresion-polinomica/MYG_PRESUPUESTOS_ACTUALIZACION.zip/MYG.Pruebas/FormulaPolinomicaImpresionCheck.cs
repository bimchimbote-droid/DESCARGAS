using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class FormulaPolinomicaImpresionCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Impresión polinómica: " + detalle); }

    internal static void Ejecutar(Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Proyecto de impresión", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        presupuesto.Item = "1";
        proyecto.Datos ??= new MYGDatosProyecto();
        proyecto.Datos.Propietario = "Propietario QA";
        proyecto.Datos.Departamento = "Áncash";
        proyecto.Datos.Provincia = "Santa";
        proyecto.Datos.Distrito = "Nuevo Chimbote";
        proyecto.Datos.Localidad = "Localidad QA";
        proyecto.Datos.FechaElaboracion = new DateTime(2026, 10, 5);
        ItemPresupuestoDelphin Item(string id, string item, string nombre, string padre, int posicion, bool titulo) => new()
        {
            Id = id, IdLocalMYG = id, Item = item, Descripcion = nombre, ParentId = padre,
            Posicion = posicion, TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Unidad = titulo ? "" : "m³"
        };
        var t1 = Item("T1", "1", "Primer título", null, 1, true);
        var t2 = Item("T2", "2", "Segundo título", null, 2, true);
        var p1 = Item("P1", "1.1", "Primera partida", "T1", 1, false);
        var p2 = Item("P2", "2.1", "Segunda partida", "T2", 1, false);
        presupuesto.Items = new() { p2, t2, p1, t1 };
        MYGFilaFormulaPolinomica Fila(ItemPresupuestoDelphin item, bool titulo, decimal total, string indice) => new()
        {
            Id = item.Id, ParentId = item.ParentId, Item = item.Item, Descripcion = item.Descripcion,
            EsTitulo = titulo, Unidad = item.Unidad, Metrado = titulo ? 0 : 2, Precio = titulo ? 0 : total / 2,
            Total = total, Importes = new Dictionary<string, decimal> { [indice] = total }
        };
        var matriz = new MYGMatrizFormulaPolinomica
        {
            Total = 180, GastosGenerales = 20, Utilidad = 18,
            Filas = new() { Fila(p2, false, 80, "47"), Fila(t2, true, 80, "47"),
                Fila(p1, false, 100, "21"), Fila(t1, true, 100, "21") },
            Indices = new() { new() { Codigo = "21", Descripcion = "Cemento", Total = 100 },
                new() { Codigo = "47", Descripcion = "Mano de obra", Total = 80 } }
        };
        var configuracion = MYGFormulaPolinomica.CrearConfiguracion(matriz);
        foreach (var grupo in configuracion.Grupos)
        {
            string codigo = grupo.Indices.Single();
            grupo.Nomenclatura = codigo switch { "21" => "CE", "47" => "MO", _ => "IPC" };
            if (codigo == "21") grupo.CoeficienteDefinido = .5m;
        }
        var resultado = MYGFormulaPolinomica.CalcularAgrupacion(matriz, configuracion);
        resultado.Advertencias.Add("AVISO_NO_IMPRIMIR");
        string antes = JsonSerializer.Serialize(proyecto), matrizAntes = JsonSerializer.Serialize(matriz),
            resultadoAntes = JsonSerializer.Serialize(resultado);
        var detallado = MYGFormulaPolinomicaReportes.CrearImpresionDetallada(proyecto, presupuesto, matriz);
        var formula = MYGFormulaPolinomicaReportes.CrearImpresionFormula(proyecto, presupuesto, resultado);
        var cd = new MYGHojaCalculo(detallado.Hoja);
        var cf = new MYGHojaCalculo(formula.Hoja);
        Exige(detallado.EsFormulaPolinomica && formula.EsFormulaPolinomica
            && detallado.ColumnasRepetidas == 6 && formula.ColumnasRepetidas == 1
            && !detallado.RepetirDatosProyecto && !formula.RepetirDatosProyecto
            && !detallado.AjustarAUnaPaginaDeAncho && formula.AjustarAUnaPaginaDeAncho
            && detallado.Hoja.TamanoPapel == "A4" && detallado.Hoja.OrientacionPagina == "Horizontal"
            && formula.Hoja.TamanoPapel == "A4" && formula.Hoja.OrientacionPagina == "Vertical"
            && detallado.Hoja.MargenIzquierdo == .7m && formula.Hoja.MargenSuperior == .7m,
            "se perdieron el formato A4, la orientación, los márgenes o los bloques de columnas y datos repetidos.");
        Exige(detallado.Titulo == "CALCULO DE COEFICIENTES DE INCIDENCIA" && formula.Titulo == "FORMULA POLINOMICA"
            && detallado.DatosProyecto.Single(d => d.Key == "Presupuesto").Value == "ESTRUCTURAS"
            && formula.CabeceraImpresion.Single(d => d.Key == "FECHA DE PROY.").Value == "5/10/2026"
            && formula.CabeceraImpresion.Single(d => d.Key == "UBICACIÓN").Value.Contains("Localidad QA"),
            "la cabecera omitió los datos del proyecto o agregó el código al nombre del presupuesto.");
        pasa("Plantillas impresas polinómicas usan A4, cabecera del proyecto, orientación propia y repetición de seis columnas del detalle");

        Exige(detallado.Hoja.Columnas == 8 && Enumerable.Range(1, 6).Select(c => cd.Mostrar(MYGHojaCalculo.Columna(c) + "1"))
            .SequenceEqual(new[] { "Item", "Descripción", "Unid.", "Cantidad", "Precio", "Parcial" })
            && cd.Mostrar("A2") == "01" && cd.Mostrar("B2") == "ESTRUCTURAS" && cd.Resultado("F2").Numero() == 218,
            "el detalle no separó Item/Descripción o la raíz no muestra la base CD + GG + utilidad.");
        Exige(new[] { "B3", "B4", "B5", "B6" }.Select(cd.Mostrar)
            .SequenceEqual(new[] { "Primer título", "Primera partida", "Segundo título", "Segunda partida" })
            && cd.Mostrar("A4") == "01.01.01" && cd.Resultado("F4").Numero() == 100
            && cd.Resultado("D4").Numero() == 2 && cd.Resultado("E4").Numero() == 50,
            "el detalle siguió el orden accidental de la lista o cambió códigos, cantidades o parciales de las partidas.");
        Exige(new[] { "G2", "H2", "G3", "H3", "G5", "H5", "H4", "G6" }.All(d => cd.Mostrar(d) == "")
            && cd.Resultado("G4").Numero() == 100 && cd.Resultado("H6").Numero() == 80
            && detallado.NivelesTitulos[2] == 0 && detallado.NivelesTitulos[3] == 1,
            "el detalle imprimió importes IU en los títulos, ceros espurios o perdió la jerarquía real.");
        pasa("Detalle impreso conserva orden jerárquico, raíz con base de fórmula, importes de partidas y celdas vacías en títulos y ceros");

        Exige(formula.Hoja.Columnas == 4 && Enumerable.Range(1, 4).Select(c => cf.Mostrar(MYGHojaCalculo.Columna(c) + "1"))
            .SequenceEqual(new[] { "Descripción", "Nomenclatura", "Coef. Def.", "Porcentaje (%)" })
            && cf.Mostrar("A2").StartsWith("21  ", StringComparison.Ordinal) && formula.Hoja.Celdas["A2"].Negrita
            && cf.Mostrar("A3").StartsWith("    21  ", StringComparison.Ordinal)
            && cf.Resultado("C2").Numero() == .5m && cf.Resultado("C3").Numero() == .459m
            && cf.Resultado("D2").Numero() == 100 && cf.Resultado("D3").Numero() == 100,
            "la fórmula no conserva cuatro columnas, el IU del monomio individual o el coeficiente hijo sobre la base sin impuestos.");
        Exige(formula.Hoja.Celdas.Keys.All(d => !cf.Mostrar(d).Contains("AVISO_NO_IMPRIMIR", StringComparison.Ordinal)
                && !cf.Mostrar(d).Contains("BASE DE COEFICIENTES", StringComparison.Ordinal))
            && formula.TerminosFormula.Select(t => t.Nomenclatura).SequenceEqual(new[] { "CE", "IPC", "MO" })
            && formula.TerminosFormula[0].Coeficiente == .5m && detallado.TerminosFormula.Count == 0,
            "la impresión arrastró auditoría del Excel o perdió los términos de la expresión K1 en su orden original.");
        var exportada = MYGReportesExcel.CrearHojas(new[] { formula }).Single();
        var calculoExportada = new MYGHojaCalculo(exportada);
        Exige(exportada.Celdas.Keys.Any(d => calculoExportada.Mostrar(d).Contains("K1 = 0.500 × (CEr/CEo)", StringComparison.Ordinal))
            && exportada.Celdas.Keys.Any(d => calculoExportada.Mostrar(d) == "Proyecto de impresión")
            && formula.Hoja.Filas < exportada.Filas,
            "exportar desde la vista común perdió K1, sus razones o los datos de obra, o materializó la cabecera sobre el original.");
        pasa("Fórmula impresa conserva cuatro columnas, coeficientes definidos de monomios e hijos y términos K1 sin auditoría del Excel");

        Exige(detallado.Hoja.Celdas.Values.All(c => c.ColorTexto == "000000" && c.Fuente == "Arial Narrow" && c.TamanoFuente == 9 && c.Bordes)
            && formula.Hoja.Celdas.Values.All(c => c.ColorTexto == "000000" && c.Fuente == "Arial Narrow" && c.TamanoFuente == 9 && c.Bordes)
            && detallado.Hoja.Celdas["G1"].ColorFondo == "E9E9EE" && formula.Hoja.Celdas["A1"].ColorFondo == "E9E9EE"
            && JsonSerializer.Serialize(proyecto) == antes && JsonSerializer.Serialize(matriz) == matrizAntes
            && JsonSerializer.Serialize(resultado) == resultadoAntes,
            "las plantillas imprimen el tema del editor o modifican el documento, la matriz o los monomios.");
        proyecto.Nombre = "Proyecto editado después";
        resultado.Monomios[0].Nomenclatura = "CAMBIADA";
        Exige(formula.DatosProyecto.Single(d => d.Key == "Proyecto").Value == "Proyecto de impresión"
            && formula.TerminosFormula[0].Nomenclatura == "CE",
            "la cabecera o la expresión impresa mantienen vínculos con el documento editable.");
        pasa("Las plantillas polinómicas congelan datos, términos y estilo negro Arial Narrow sin mutar las fuentes");
    }
}
