-- Publicación GZip en Storage privado; PostgreSQL conserva manifiestos pequeños.
-- Ejecutar completo DESPUÉS de los parches 26 y 27. No convierte obras existentes.
-- Los editores con módulos restringidos conservan la comprobación JSONB previa:
-- esa ruta mantiene su coste anterior y no promete resolver cargas grandes en Nano.
begin;

do $preflight$
declare v record;
begin
    if getdatabaseencoding()<>'UTF8' then raise exception 'Esta instalación requiere una base UTF8.'; end if;
    if not exists(select 1 from pg_proc where oid=to_regprocedure(
        'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)')
        and md5(prosrc) in ('0e4fc248646351ac672e015931e721e9','172b23f1cb9f9652caece14e4bb359b7')) then
        raise exception 'Instale primero los parches oficiales 26 y 27. No se modificó la instalación.';
    end if;
    for v in select * from (values
        ('storage.buckets','id','text'),('storage.buckets','name','text'),
        ('storage.buckets','public','boolean'),('storage.buckets','file_size_limit','bigint'),
        ('storage.objects','bucket_id','text'),('storage.objects','name','text'),
        ('storage.objects','metadata','jsonb'),
        ('public.myg_nube_proyectos','contenido','jsonb'),
        ('public.myg_nube_miembros','permisos_modulos','jsonb')
    ) r(relacion,columna,tipo) loop
        if not exists(select 1 from pg_attribute where attrelid=to_regclass(v.relacion)
            and attname=v.columna and atttypid=to_regtype(v.tipo) and attnum>0 and not attisdropped) then
            raise exception 'Falta %.% de tipo %. Se conserva la instalación.',v.relacion,v.columna,v.tipo;
        end if;
    end loop;
    if not exists(select 1 from pg_class where oid='storage.objects'::regclass and relrowsecurity) then
        raise exception 'storage.objects debe tener RLS habilitado.';
    end if;
end $preflight$;

alter table public.myg_nube_proyectos add column if not exists es_comprimido boolean not null default false;
do $columna$
begin
    if not exists(select 1 from pg_attribute where attrelid='public.myg_nube_proyectos'::regclass
        and attname='es_comprimido' and atttypid='boolean'::regtype and attnotnull
        and exists(select 1 from pg_attrdef d where d.adrelid=attrelid and d.adnum=attnum
            and pg_get_expr(d.adbin,d.adrelid)='false')) then
        raise exception 'es_comprimido existente tiene una definición incompatible.';
    end if;
    if exists(select 1 from storage.buckets where id='myg-nube-paquetes'
        and (name is distinct from 'myg-nube-paquetes' or public is distinct from false
             or file_size_limit is distinct from 8388608::bigint)) then
        raise exception 'El bucket myg-nube-paquetes existente tiene configuración distinta; no se reemplazó.';
    end if;
end $columna$;
insert into storage.buckets(id,name,public,file_size_limit)
values('myg-nube-paquetes','myg-nube-paquetes',false,8388608) on conflict(id) do nothing;

-- Retener todas las referencias mantiene recuperables las revisiones históricas.
-- No hay GC ni borrado automático de subidas; un intento fallido conserva sus partes.
create table if not exists myg_nube_privado.paquetes_objetos (
    proyecto_id uuid not null references public.myg_nube_proyectos(id),
    ruta text not null, sha256 text not null, bytes bigint not null,
    referenciado_en timestamptz not null default clock_timestamp(),
    primary key(proyecto_id,ruta),
    check(sha256 ~ '^[0-9a-f]{64}$'), check(bytes between 1 and 8388608)
);
create index if not exists myg_nube_paquetes_objetos_ruta on myg_nube_privado.paquetes_objetos(ruta);
revoke all on myg_nube_privado.paquetes_objetos from public,anon,authenticated,service_role;
alter table myg_nube_privado.paquetes_objetos enable row level security;

create or replace function myg_nube_privado.paquete_objeto_acceso(p_ruta text,p_escritura boolean)
returns boolean language plpgsql stable security definer
set search_path=pg_catalog,myg_nube_privado as $fn$
declare v_usuario uuid:=auth.uid(); v_proyecto uuid; v_propia boolean;
begin
    if v_usuario is null or not exists(select 1 from myg_nube_privado.identidades_verificadas
        where auth_usuario_id=v_usuario and activo) then return false; end if;
    if p_ruta !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{32}/[0-9a-f]{64}$' then
        return false;
    end if;
    v_proyecto:=split_part(p_ruta,'/',2)::uuid;
    v_propia:=split_part(p_ruta,'/',1)=v_usuario::text;
    if p_escritura then
        return v_propia and (not exists(select 1 from public.myg_nube_proyectos where id=v_proyecto)
            or exists(select 1 from public.myg_nube_miembros where proyecto_id=v_proyecto
                and usuario_id=v_usuario and rol in ('propietario','administrador','editor')));
    end if;
    if exists(select 1 from myg_nube_privado.paquetes_objetos where ruta=p_ruta) then
        return exists(select 1 from myg_nube_privado.paquetes_objetos o
            join public.myg_nube_miembros m on m.proyecto_id=o.proyecto_id
            where o.ruta=p_ruta and m.usuario_id=v_usuario);
    end if;
    -- Solo las subidas propias aún no confirmadas usan el prefijo como permiso.
    -- Una parte ya referenciada exige membresía, incluso para su antiguo uploader.
    return v_propia and (not exists(select 1 from public.myg_nube_proyectos where id=v_proyecto)
        or exists(select 1 from public.myg_nube_miembros where proyecto_id=v_proyecto
            and usuario_id=v_usuario and rol in ('propietario','administrador','editor')));
end $fn$;
revoke all on function myg_nube_privado.paquete_objeto_acceso(text,boolean) from public,anon,authenticated,service_role;
-- Las políticas se ejecutan con los permisos del llamador; el helper solo devuelve
-- acceso a una ruta, nunca datos ni la identidad de otros usuarios.
grant usage on schema myg_nube_privado to authenticated,anon;
grant execute on function myg_nube_privado.paquete_objeto_acceso(text,boolean) to authenticated,anon;

-- RESTRICTIVE impide que políticas permisivas antiguas de otros buckets abran
-- este bucket. El rol service_role sigue siendo un administrador de confianza.
drop policy if exists myg_paquetes_lectura on storage.objects;
create policy myg_paquetes_lectura on storage.objects for select to authenticated
using(bucket_id='myg-nube-paquetes' and myg_nube_privado.paquete_objeto_acceso(name,false));
drop policy if exists myg_paquetes_subida on storage.objects;
create policy myg_paquetes_subida on storage.objects for insert to authenticated
with check(bucket_id='myg-nube-paquetes' and myg_nube_privado.paquete_objeto_acceso(name,true));
drop policy if exists myg_paquetes_limitar_lectura on storage.objects;
create policy myg_paquetes_limitar_lectura on storage.objects as restrictive for select to public
using(bucket_id<>'myg-nube-paquetes' or myg_nube_privado.paquete_objeto_acceso(name,false));
drop policy if exists myg_paquetes_limitar_subida on storage.objects;
create policy myg_paquetes_limitar_subida on storage.objects as restrictive for insert to public
with check(bucket_id<>'myg-nube-paquetes' or myg_nube_privado.paquete_objeto_acceso(name,true));
drop policy if exists myg_paquetes_inmutables_update on storage.objects;
create policy myg_paquetes_inmutables_update on storage.objects as restrictive for update to public
using(bucket_id<>'myg-nube-paquetes') with check(bucket_id<>'myg-nube-paquetes');
drop policy if exists myg_paquetes_inmutables_delete on storage.objects;
create policy myg_paquetes_inmutables_delete on storage.objects as restrictive for delete to public
using(bucket_id<>'myg-nube-paquetes');

create or replace function myg_nube_privado.validar_manifiesto_gzip(p_id uuid,p_manifest jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
declare v_parte jsonb; v_total bigint:=0; v_cantidad integer; v_indice integer:=0; v_actor text;
begin
    if p_id is null or p_id='00000000-0000-0000-0000-000000000000'::uuid
       or jsonb_typeof(p_manifest) is distinct from 'object'
       or octet_length(p_manifest::text)>65536
       or p_manifest->>'formato' is distinct from 'MYG_ARCHIVO_GZIP'
       or p_manifest->'version' is distinct from '1'::jsonb
       or p_manifest-array['formato','version','sha256_json','bytes_json','sha256_gzip','bytes_gzip','partes']<>'{}'::jsonb
       or jsonb_typeof(p_manifest->'sha256_json') is distinct from 'string'
       or not (p_manifest->>'sha256_json' ~ '^[0-9a-f]{64}$')
       or jsonb_typeof(p_manifest->'sha256_gzip') is distinct from 'string'
       or not (p_manifest->>'sha256_gzip' ~ '^[0-9a-f]{64}$')
       or jsonb_typeof(p_manifest->'bytes_json') is distinct from 'number'
       or not (p_manifest->>'bytes_json' ~ '^[1-9][0-9]{0,8}$')
       or jsonb_typeof(p_manifest->'bytes_gzip') is distinct from 'number'
       or not (p_manifest->>'bytes_gzip' ~ '^[1-9][0-9]{0,8}$')
       or jsonb_typeof(p_manifest->'partes') is distinct from 'array' then
        raise exception using errcode='22023',message='MYG_MANIFIESTO_GZIP_INVALIDO';
    end if;
    if (p_manifest->>'bytes_json')::bigint>314572800
       or (p_manifest->>'bytes_gzip')::bigint>335544320 then
        raise exception using errcode='22023',message='MYG_ARCHIVO_GZIP_SUPERA_LIMITE';
    end if;
    v_cantidad:=jsonb_array_length(p_manifest->'partes');
    if v_cantidad not between 1 and 40 then
        raise exception using errcode='22023',message='MYG_PARTES_GZIP_INVALIDAS';
    end if;
    for v_parte in select value from jsonb_array_elements(p_manifest->'partes') loop
        v_indice:=v_indice+1;
        if jsonb_typeof(v_parte) is distinct from 'object'
           or v_parte-array['ruta','sha256','bytes']<>'{}'::jsonb
           or jsonb_typeof(v_parte->'ruta') is distinct from 'string'
           or jsonb_typeof(v_parte->'sha256') is distinct from 'string'
           or not (v_parte->>'sha256' ~ '^[0-9a-f]{64}$')
           or not (v_parte->>'ruta' ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{32}/[0-9a-f]{64}$')
           or split_part(v_parte->>'ruta','/',2) is distinct from replace(p_id::text,'-','')
           or split_part(v_parte->>'ruta','/',3) is distinct from v_parte->>'sha256'
           or jsonb_typeof(v_parte->'bytes') is distinct from 'number'
           or not (v_parte->>'bytes' ~ '^[1-9][0-9]{0,6}$') then
            raise exception using errcode='22023',message='MYG_PARTE_GZIP_INVALIDA';
        end if;
        if (v_parte->>'bytes')::bigint>8388608 then
            raise exception using errcode='22023',message='MYG_PARTE_GZIP_SUPERA_8_MIB';
        end if;
        if v_indice<v_cantidad and (v_parte->>'bytes')::bigint<>8388608 then
            raise exception using errcode='22023',message='MYG_PARTE_GZIP_INTERMEDIA_INCOMPLETA';
        end if;
        if v_actor is null then v_actor:=split_part(v_parte->>'ruta','/',1);
        elsif v_actor<>split_part(v_parte->>'ruta','/',1) then
            raise exception using errcode='22023',message='MYG_PARTES_GZIP_ACTORES_DISTINTOS';
        end if;
        v_total:=v_total+(v_parte->>'bytes')::bigint;
    end loop;
    if v_total<>(p_manifest->>'bytes_gzip')::bigint then
        raise exception using errcode='22023',message='MYG_LONGITUD_GZIP_NO_COINCIDE';
    end if;
end $fn$;

create or replace function myg_nube_privado.registrar_partes_gzip(p_id uuid,p_manifest jsonb,p_usuario uuid)
returns void language plpgsql security definer set search_path=pg_catalog,myg_nube_privado as $fn$
declare v_parte jsonb; v_tamano text;
begin
    perform myg_nube_privado.validar_manifiesto_gzip(p_id,p_manifest);
    for v_parte in select value from jsonb_array_elements(p_manifest->'partes') loop
        if split_part(v_parte->>'ruta','/',1)<>p_usuario::text
           and not exists(select 1 from myg_nube_privado.paquetes_objetos
               where proyecto_id=p_id and ruta=v_parte->>'ruta'
               and sha256=v_parte->>'sha256' and bytes=(v_parte->>'bytes')::bigint) then
            raise exception using errcode='42501',message='MYG_PARTE_GZIP_AJENA';
        end if;
        select metadata->>'size' into v_tamano from storage.objects
            where bucket_id='myg-nube-paquetes' and name=v_parte->>'ruta';
        if v_tamano is null or v_tamano !~ '^[0-9]{1,10}$'
           or v_tamano::bigint<>(v_parte->>'bytes')::bigint then
            raise exception using errcode='22023',message='MYG_PARTE_GZIP_NO_DISPONIBLE';
        end if;
        insert into myg_nube_privado.paquetes_objetos(proyecto_id,ruta,sha256,bytes)
        values(p_id,v_parte->>'ruta',v_parte->>'sha256',(v_parte->>'bytes')::bigint)
        on conflict(proyecto_id,ruta) do nothing;
        if not exists(select 1 from myg_nube_privado.paquetes_objetos where proyecto_id=p_id
            and ruta=v_parte->>'ruta' and sha256=v_parte->>'sha256' and bytes=(v_parte->>'bytes')::bigint) then
            raise exception using errcode='22023',message='MYG_PARTE_GZIP_IDENTIDAD_DISTINTA';
        end if;
    end loop;
end $fn$;

-- La marca es inmutable: clientes viejos nunca transforman un manifiesto en JSON
-- ni confunden un manifiesto con una obra vacía.
create or replace function myg_nube_privado.proteger_formato_proyecto()
returns trigger language plpgsql security definer set search_path=pg_catalog,myg_nube_privado as $fn$
begin
    if tg_op='UPDATE' and new.es_comprimido is distinct from old.es_comprimido then
        raise exception using errcode='22023',message='MYG_ALMACENAMIENTO_INMUTABLE';
    end if;
    if new.es_comprimido then
        if tg_op='UPDATE' and new.contenido is distinct from old.contenido
           and current_setting('myg.guardando_comprimido',true) is distinct from '1' then
            raise exception using errcode='MGC01',message='MYG_PAQUETE_COMPRIMIDO_REQUIERE_CLIENTE';
        end if;
        perform myg_nube_privado.validar_manifiesto_gzip(new.id,new.contenido);
    elsif new.contenido->>'formato'='MYG_ARCHIVO_GZIP' then
        raise exception using errcode='22023',message='MYG_MANIFIESTO_REQUIERE_RPC_COMPRIMIDO';
    end if;
    return new;
end $fn$;
drop trigger if exists myg_nube_proteger_formato on public.myg_nube_proyectos;
create trigger myg_nube_proteger_formato before insert or update on public.myg_nube_proyectos
for each row execute function myg_nube_privado.proteger_formato_proyecto();

-- Conservar el validador productivo de adjuntos, incluido su cuerpo y ACL.
-- Solo se añade una condición al trigger conocido; variantes desconocidas abortan.
-- UPDATE OF es válido: pg_get_triggerdef conserva su lista exacta de columnas.
do $adjuntos$
declare v record; v_def text; v_nueva text; v_comentario text;
begin
    for v in select t.*,pg_get_triggerdef(t.oid) definicion
        from pg_trigger t where t.tgrelid='public.myg_nube_proyectos'::regclass
          and not t.tgisinternal and t.tgname='myg_nube_validar_adjuntos' loop
        if v.tgfoid is distinct from to_regprocedure('myg_nube_privado.validar_paquete_archivos()')
           or v.tgtype::integer<>23 or v.tgnargs<>0 then
            raise exception 'Trigger de adjuntos desconocido. No se modificó su función.';
        end if;
        if v.tgqual is not null then
            if position('WHEN ((NOT new.es_comprimido))' in v.definicion)=0 then
                raise exception 'El trigger de adjuntos tiene una condición personalizada; se conserva intacto.';
            end if;
            continue;
        end if;
        v_def:=v.definicion;
        v_comentario:=obj_description(v.oid,'pg_trigger');
        v_nueva:=regexp_replace(v_def,' EXECUTE (FUNCTION|PROCEDURE) ',
            ' WHEN (NOT new.es_comprimido) EXECUTE \1 ');
        if v_nueva=v_def then raise exception 'No se pudo conservar el trigger de adjuntos.'; end if;
        execute 'drop trigger myg_nube_validar_adjuntos on public.myg_nube_proyectos';
        execute v_nueva;
        if v_comentario is not null then
            execute format('comment on trigger myg_nube_validar_adjuntos on public.myg_nube_proyectos is %L',v_comentario);
        end if;
        if v.tgenabled='D' then alter table public.myg_nube_proyectos disable trigger myg_nube_validar_adjuntos;
        elsif v.tgenabled='R' then alter table public.myg_nube_proyectos enable replica trigger myg_nube_validar_adjuntos;
        elsif v.tgenabled='A' then alter table public.myg_nube_proyectos enable always trigger myg_nube_validar_adjuntos;
        end if;
        if not exists(select 1 from pg_trigger n where n.tgrelid=v.tgrelid and n.tgname=v.tgname
            and n.tgfoid=v.tgfoid and n.tgtype=v.tgtype and n.tgattr=v.tgattr
            and n.tgnargs=v.tgnargs and n.tgargs=v.tgargs and n.tgenabled=v.tgenabled
            and obj_description(n.oid,'pg_trigger') is not distinct from v_comentario) then
            raise exception 'No se conservaron los eventos, columnas o atributos del trigger de adjuntos.';
        end if;
    end loop;
end $adjuntos$;

create or replace function myg_nube_privado.exigir_paquete_json(p_id uuid)
returns boolean language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if exists(select 1 from public.myg_nube_proyectos p join public.myg_nube_miembros m
        on m.proyecto_id=p.id and m.usuario_id=auth.uid() where p.id=p_id and p.es_comprimido) then
        raise exception using errcode='MGC01',message='MYG_PAQUETE_COMPRIMIDO_REQUIERE_CLIENTE';
    end if;
    return true;
end $fn$;

-- Modificar únicamente los cuerpos oficiales, conservando OID, propietario, ACL
-- y configuración de las funciones existentes. Una personalización aborta todo.
do $funciones_existentes$
declare v_firma text; v_oid oid; v_fuente text; v_def text; v_esperada text; v_parcheada text; v_atributos jsonb;
begin
    foreach v_firma in array array['myg_nube_privado.snapshot(uuid,uuid)','public.myg_nube_capacidades()'] loop
        v_oid:=to_regprocedure(v_firma);
        select replace(prosrc,E'\r\n',E'\n'),pg_get_functiondef(oid),to_jsonb(p)-'prosrc'
            into v_fuente,v_def,v_atributos from pg_proc p where oid=v_oid;
        if v_firma='myg_nube_privado.snapshot(uuid,uuid)' then
            v_esperada:=$snapshot$
    select jsonb_build_object('id', p.id, 'codigo', p.codigo, 'nombre', p.nombre,
        'rol', m.rol, 'revision', p.revision, 'alcance', p.alcance,
        'contenido', p.contenido, 'permisos_modulos', m.permisos_modulos)
    from public.myg_nube_proyectos p
    join public.myg_nube_miembros m
      on m.proyecto_id = p.id and m.usuario_id = p_usuario
    where p.id = p_id;
$snapshot$;
            v_parcheada:=replace(v_esperada,'where p.id = p_id;',
                'where p.id = p_id and myg_nube_privado.exigir_paquete_json(p.id);');
        else
            v_esperada:=$capacidades$
begin
    perform myg_nube_privado.identidad();
    return jsonb_build_object('paquete_compacto',2,'cambios',1,'historial_intervalo',20,
        'max_contenido_mib',300,'publicacion_ligera',1);
end $capacidades$;
            v_parcheada:=replace(v_esperada,'''publicacion_ligera'',1)',
                '''publicacion_ligera'',1,''publicacion_comprimida'',1)');
        end if;
        if btrim(v_fuente)=btrim(v_parcheada) then continue; end if;
        if btrim(v_fuente) is distinct from btrim(v_esperada) then
            raise exception 'La función % contiene una personalización desconocida; se conserva intacta.',v_firma;
        end if;
        if position(E'\r\n' in v_def)>0 then
            v_esperada:=replace(v_esperada,E'\n',E'\r\n');
            v_parcheada:=replace(v_parcheada,E'\n',E'\r\n');
        end if;
        execute replace(v_def,btrim(v_esperada),btrim(v_parcheada));
        if not exists(select 1 from pg_proc p where oid=v_oid and to_jsonb(p)-'prosrc'=v_atributos
            and btrim(replace(prosrc,E'\r\n',E'\n'))=btrim(replace(v_parcheada,E'\r\n',E'\n'))) then
            raise exception 'No se conservaron los atributos de %.',v_firma;
        end if;
    end loop;
end $funciones_existentes$;

do $guardas_json$
declare v record; v_oid oid; v_fuente text; v_def text; v_atributos jsonb; v_nueva text;
begin
    for v in select * from (values
        ('public.myg_nube_guardar(uuid,uuid,bigint,jsonb)','2be817bb7ff166f548aaa414eac11e1a','3be33feec4e840f7fb6d7cc6242fe669'),
        ('public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)','f93720e1f5579ff52d8997175cc14a05','58e96b238b95def2366cc08e63b6f26c'),
        ('myg_nube_privado.reconstruir_revision(uuid,bigint)','86ee11c5f2710618a474f09ab5f50923','a15b7b57b5aa62d734e65d392a7c4263')
    ) r(firma,original,parcheada) loop
        v_oid:=to_regprocedure(v.firma);
        select replace(prosrc,E'\r\n',E'\n'),pg_get_functiondef(oid),to_jsonb(p)-'prosrc'
            into v_fuente,v_def,v_atributos from pg_proc p where oid=v_oid;
        if md5(v_fuente)=v.parcheada then continue; end if;
        if md5(v_fuente) is distinct from v.original then
            raise exception 'La función % tiene una personalización desconocida; se conserva intacta.',v.firma;
        end if;
        v_nueva:=regexp_replace(v_fuente,E'begin\n',
            E'begin\n    perform myg_nube_privado.exigir_paquete_json(p_id);\n');
        if md5(v_nueva)<>v.parcheada then raise exception 'Guarda JSON desconocida: %.',v.firma; end if;
        if position(E'\r\n' in v_def)>0 then
            execute replace(v_def,replace(v_fuente,E'\n',E'\r\n'),replace(v_nueva,E'\n',E'\r\n'));
        else execute replace(v_def,v_fuente,v_nueva);
        end if;
        if not exists(select 1 from pg_proc p where oid=v_oid and to_jsonb(p)-'prosrc'=v_atributos
            and md5(replace(prosrc,E'\r\n',E'\n'))=v.parcheada) then
            raise exception 'No se conservaron los atributos de %.',v.firma;
        end if;
    end loop;
end $guardas_json$;

create or replace function public.myg_nube_paquete_tipo(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog,myg_nube_privado as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_resultado jsonb;
begin
    select jsonb_build_object('almacenamiento',case when p.es_comprimido then 'gzip' else 'json' end)
    into v_resultado from public.myg_nube_proyectos p join public.myg_nube_miembros m
    on m.proyecto_id=p.id and m.usuario_id=v_usuario where p.id=p_id;
    if v_resultado is null then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    return v_resultado;
end $fn$;

create or replace function public.myg_nube_abrir_comprimido(p_id uuid,p_revision bigint default null)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog,myg_nube_privado as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_proyecto public.myg_nube_proyectos%rowtype;
    v_meta jsonb; v_contenido jsonb; v_revision bigint;
begin
    v_meta:=public.myg_nube_revision(p_id);
    select * into v_proyecto from public.myg_nube_proyectos where id=p_id;
    if not v_proyecto.es_comprimido then
        raise exception using errcode='22023',message='MYG_PROYECTO_NO_COMPRIMIDO';
    end if;
    v_revision:=coalesce(p_revision,v_proyecto.revision);
    if v_revision<1 or v_revision>v_proyecto.revision then
        raise exception using errcode='22023',message='MYG_REVISION_NO_RECUPERABLE';
    end if;
    select contenido into v_contenido from public.myg_nube_historial where proyecto_id=p_id and revision=v_revision;
    if not found then raise exception using errcode='22023',message='MYG_REVISION_NO_RECUPERABLE'; end if;
    return v_meta||jsonb_build_object('revision',v_revision,'contenido',v_contenido);
end $fn$;

create or replace function public.myg_nube_crear_comprimido(p_id uuid,p_nombre text,p_manifest jsonb,p_alcance text)
returns jsonb language plpgsql security definer set search_path=pg_catalog,myg_nube_privado
set statement_timeout='120s' as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_proyecto public.myg_nube_proyectos%rowtype;
begin
    if p_id is null or p_id='00000000-0000-0000-0000-000000000000'::uuid
       or p_nombre is null or length(btrim(p_nombre)) not between 1 and 200
       or p_alcance is null or p_alcance not in ('obra','base') then
        raise exception using errcode='22023',message='MYG_CREACION_INVALIDA';
    end if;
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-crear:'||p_id::text,0)) then
        raise exception using errcode='55006',message='MYG_PUBLICACION_EN_CURSO';
    end if;
    select * into v_proyecto from public.myg_nube_proyectos where id=p_id;
    if found and v_proyecto.propietario<>v_usuario then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    begin
        select * into v_proyecto from public.myg_nube_proyectos where id=p_id for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;
    if found then
        if v_proyecto.propietario<>v_usuario then
            raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
        end if;
        if not v_proyecto.es_comprimido
           or v_proyecto.nombre<>btrim(p_nombre) or v_proyecto.alcance<>p_alcance
           or not exists(select 1 from public.myg_nube_historial where proyecto_id=p_id and revision=1
               and contenido->>'sha256_json'=p_manifest->>'sha256_json'
               and contenido->>'bytes_json'=p_manifest->>'bytes_json') then
            raise exception using errcode='22023',message='MYG_ID_REUTILIZADO_CON_OTRA_CREACION';
        end if;
        -- Esta confirmación se refiere a la creación inicial, aunque la obra ya
        -- tenga ediciones posteriores. El listado obtiene la revisión vigente.
        return public.myg_nube_revision(p_id)||jsonb_build_object('revision',1);
    end if;
    perform myg_nube_privado.validar_manifiesto_gzip(p_id,p_manifest);
    insert into public.myg_nube_proyectos(id,codigo,nombre,propietario,contenido,alcance,es_comprimido)
        values(p_id,'MYG-'||upper(replace(p_id::text,'-','')),btrim(p_nombre),v_usuario,p_manifest,p_alcance,true);
    perform myg_nube_privado.registrar_partes_gzip(p_id,p_manifest,v_usuario);
    insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values(p_id,v_usuario,'propietario');
    insert into public.myg_nube_historial(proyecto_id,revision,usuario_id,contenido) values(p_id,1,v_usuario,p_manifest);
    return public.myg_nube_revision(p_id);
end $fn$;

create or replace function public.myg_nube_guardar_comprimido(
    p_id uuid,p_operacion uuid,p_revision bigint,p_manifest jsonb,p_anterior text default null,p_nuevo text default null)
returns jsonb language plpgsql security definer set search_path=pg_catalog,myg_nube_privado
set statement_timeout='120s' as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_proyecto public.myg_nube_proyectos%rowtype;
    v_rol text; v_permisos jsonb; v_previa public.myg_nube_operaciones%rowtype;
    v_solicitud jsonb; v_respuesta jsonb; v_anterior jsonb; v_nuevo jsonb; v_config text;
begin
    if p_operacion is null or p_operacion='00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision<1 or p_revision=9223372036854775807 then
        raise exception using errcode='22023',message='MYG_OPERACION_INVALIDA';
    end if;
    if octet_length(p_anterior)>314572800 or octet_length(p_nuevo)>314572800 then
        raise exception using errcode='22023',message='MYG_TEXTO_PARA_PERMISOS_SUPERA_300_MIB';
    end if;
    select rol,permisos_modulos into v_rol,v_permisos from public.myg_nube_miembros
        where proyecto_id=p_id and usuario_id=v_usuario;
    if v_rol is null or v_rol not in ('propietario','administrador','editor') then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    begin
        select * into v_proyecto from public.myg_nube_proyectos where id=p_id for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;
    -- Releer el permiso después de adquirir la misma fila que usan los cambios de rol.
    select rol,permisos_modulos into v_rol,v_permisos from public.myg_nube_miembros
        where proyecto_id=p_id and usuario_id=v_usuario;
    if v_proyecto.id is null or v_rol is null or v_rol not in ('propietario','administrador','editor') then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    if not v_proyecto.es_comprimido then
        raise exception using errcode='22023',message='MYG_PROYECTO_NO_COMPRIMIDO';
    end if;
    perform myg_nube_privado.validar_manifiesto_gzip(p_id,p_manifest);
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-op:'||v_usuario::text||':'||p_operacion::text,0)) then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end if;
    -- La identidad durable es el JSON lógico, no su compresión ni los textos de
    -- validación: estos pueden aparecer/desaparecer si cambian los permisos
    -- después de perderse el ACK. Un replay autorizado nunca vuelve a escribir.
    v_solicitud:=jsonb_build_object('tipo','gzip','revision',p_revision,
        'sha256_json',p_manifest->>'sha256_json','bytes_json',p_manifest->'bytes_json');
    select * into v_previa from public.myg_nube_operaciones where usuario_id=v_usuario and operacion_id=p_operacion;
    if found then
        if v_previa.proyecto_id<>p_id or v_previa.solicitud<>v_solicitud then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        return v_previa.respuesta;
    end if;
    if v_proyecto.revision<>p_revision then
        v_respuesta:=jsonb_build_object('estado','conflicto','revision',v_proyecto.revision,
            'operacion_id',p_operacion,'contenido',v_proyecto.contenido);
    else
        if not myg_nube_privado.permisos_modulos_validos(v_permisos) then
            raise exception using errcode='42501',message='MYG_PERMISOS_MODULOS_INVALIDOS';
        end if;
        if v_permisos<>'{"acu":true,"especificaciones":true,"metrados_excel":true}'::jsonb then
            if p_anterior is null or p_nuevo is null
               or encode(sha256(convert_to(p_anterior,'UTF8')),'hex') is distinct from v_proyecto.contenido->>'sha256_json'
               or octet_length(p_anterior)::text is distinct from v_proyecto.contenido->>'bytes_json'
               or encode(sha256(convert_to(p_nuevo,'UTF8')),'hex') is distinct from p_manifest->>'sha256_json'
               or octet_length(p_nuevo)::text is distinct from p_manifest->>'bytes_json' then
                raise exception using errcode='22023',message='MYG_TEXTO_PARA_PERMISOS_NO_COINCIDE';
            end if;
            -- CAST deliberadamente posterior a autorización, CAS y verificación SHA.
            v_anterior:=p_anterior::jsonb; v_nuevo:=p_nuevo::jsonb;
            perform myg_nube_privado.validar_contenido(v_anterior);
            perform myg_nube_privado.validar_contenido(v_nuevo);
            if v_anterior->>'alcance' is distinct from v_proyecto.alcance
               or v_nuevo->>'alcance' is distinct from v_proyecto.alcance then
                raise exception using errcode='22023',message='MYG_ALCANCE_INVALIDO';
            end if;
            perform myg_nube_privado.exigir_modulos(v_anterior,v_nuevo,v_permisos);
        end if;
        perform myg_nube_privado.registrar_partes_gzip(p_id,p_manifest,v_usuario);
        v_config:=current_setting('myg.guardando_comprimido',true);
        perform set_config('myg.guardando_comprimido','1',true);
        update public.myg_nube_proyectos set contenido=p_manifest,revision=revision+1,
            actualizado_en=clock_timestamp() where id=p_id returning * into v_proyecto;
        perform set_config('myg.guardando_comprimido',coalesce(v_config,''),true);
        insert into public.myg_nube_historial(proyecto_id,revision,usuario_id,operacion_id,contenido)
            values(p_id,v_proyecto.revision,v_usuario,p_operacion,p_manifest);
        v_respuesta:=jsonb_build_object('estado','aplicada','revision',v_proyecto.revision,'operacion_id',p_operacion);
    end if;
    insert into public.myg_nube_operaciones(usuario_id,operacion_id,proyecto_id,solicitud,respuesta)
        values(v_usuario,p_operacion,p_id,v_solicitud,v_respuesta);
    return v_respuesta;
end $fn$;

revoke all on function myg_nube_privado.validar_manifiesto_gzip(uuid,jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.registrar_partes_gzip(uuid,jsonb,uuid) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.proteger_formato_proyecto() from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.exigir_paquete_json(uuid) from public,anon,authenticated,service_role;
revoke all on function public.myg_nube_paquete_tipo(uuid) from public,anon;
revoke all on function public.myg_nube_abrir_comprimido(uuid,bigint) from public,anon;
revoke all on function public.myg_nube_crear_comprimido(uuid,text,jsonb,text) from public,anon;
revoke all on function public.myg_nube_guardar_comprimido(uuid,uuid,bigint,jsonb,text,text) from public,anon;
grant execute on function public.myg_nube_paquete_tipo(uuid) to authenticated,service_role;
grant execute on function public.myg_nube_abrir_comprimido(uuid,bigint) to authenticated,service_role;
grant execute on function public.myg_nube_crear_comprimido(uuid,text,jsonb,text) to authenticated,service_role;
grant execute on function public.myg_nube_guardar_comprimido(uuid,uuid,bigint,jsonb,text,text) to authenticated,service_role;

notify pgrst,'reload schema';
select 'PUBLICACION_COMPRIMIDA_INSTALADA' resultado,8388608 bytes_maximos_por_parte,
    314572800 bytes_json_maximos,true bucket_privado,true partes_inmutables;
commit;
