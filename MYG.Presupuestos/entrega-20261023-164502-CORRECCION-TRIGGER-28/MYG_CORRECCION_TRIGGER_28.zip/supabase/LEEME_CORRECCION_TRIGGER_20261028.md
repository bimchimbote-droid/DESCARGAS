# Corrección del instalador 28 para triggers UPDATE OF

Entrega de 23/10/2026 (America/Lima). El número 20261028 identifica la migración que ya recibió, no una nueva actualización del cliente.

## A. Problema y cambio

La consulta del servidor mostró: función `myg_nube_privado.validar_paquete_archivos()` coincidente, tipo 23 (BEFORE INSERT/UPDATE por fila), cero argumentos, columnas `6 7`, sin condición WHEN y habilitado normal `O`.

El instalador anterior exigía una lista vacía de columnas. Por eso rechazaba su trigger `UPDATE OF` y abortaba la instalación con `Trigger de adjuntos desconocido`. La corrección acepta esa variante de la misma función y conserva la lista original mediante `pg_get_triggerdef`; comprueba después que eventos, columnas, función, argumentos, estado y comentario se mantengan. No reemplaza el cuerpo de la función de adjuntos ni cambia las RPC, la compresión, el cliente o los permisos de los proyectos.

## B. Qué hacer con cada archivo

Copie los archivos en la carpeta donde está `MYG.Presupuestos.sln`, conservando las rutas. El único archivo que se ejecuta en Supabase es el instalador 28.

| Ruta exacta | Acción requerida | Descripción |
|---|---|---|
| `supabase/migraciones/20261028_publicacion_comprimida.sql` | Reemplazar y ejecutar completo en SQL Editor | Instalador corregido compatible con UPDATE OF. |
| `scripts/pruebas/Probar-PublicacionComprimidaHTTP.py` | Reemplazar; ejecución opcional de desarrollo | Añade `--solo-trigger`; no necesita Python para instalar o usar MYG. |
| `supabase/diagnosticos/RESULTADOS_CORRECCION_TRIGGER_20261028.json` | Crear; solo consultar | Resultado de las pruebas nuevas y SHA-256 del instalador corregido. |
| `supabase/CONTINUIDAD_PUBLICACION_COMPRIMIDA.md` | Reemplazar; conservar | Estado, diagnóstico confirmado y siguiente paso para retomar. |
| `supabase/LEEME_CORRECCION_TRIGGER_20261028.md` | Crear; leer | Estas instrucciones. |

Los 15 archivos C# de la entrega anterior se conservan sin cambios. Se reutiliza la aplicación comprimida ya entregada y sus verificaciones aprobadas.

## C. Descarga

El mensaje final incluye el ZIP correctivo, publicado en una ruta nueva de `bimchimbote-droid/DESCARGAS`. La descarga pública, tamaño, SHA-256, integridad ZIP y contenido se verifican después de publicarlo. No se sobrescribe el ZIP anterior.

## D. Instalación manual

1. Cierre MYG.Presupuestos y copie los archivos del ZIP correctivo sobre sus rutas.
2. En Supabase → SQL Editor, abra una consulta nueva y copie **todo el archivo corregido** `supabase/migraciones/20261028_publicacion_comprimida.sql`, desde `begin;` hasta `commit;`. Pulse Run una vez. No vuelva a usar el SQL del ZIP anterior. No ejecute 26 ni 27.
3. El resultado esperado es `PUBLICACION_COMPRIMIDA_INSTALADA`. Después de que termine, ejecute en otra consulta la comprobación de instalación que ya utilizó: `rpc_crear`, `rpc_abrir`, `rpc_guardar`, `capacidad_compresion` y `bucket_privado` deben dar `true`. Esa lectura posterior comprueba que los componentes son visibles tras la transacción.
4. Abra la aplicación actualizada del primer ZIP, cerrando cualquier instancia anterior para renovar la caché de capacidades. Si todavía no la compiló, desde la carpeta de la solución:

   ```powershell
   dotnet run --project .\MYG.Desktop\MYG.Desktop.csproj -c Release
   ```

5. Abra Publicaciones pendientes y reintente el intento existente. Conserve el identificador y el JSON local. La ventana debe informar que preparará una copia comprimida y después mostrar su tamaño real. Una vez confirmado, compruebe apertura y descarga de copia.

## E. Configuración adicional

No requiere cambiar la instancia, hacer público un bucket, borrar o deshabilitar el trigger, modificar su función ni instalar Python. El instalador conserva la configuración existente y crea los componentes de publicación comprimida de la migración 28.

## F. Validaciones de esta corrección

Se ejecutó únicamente el selector nuevo `--solo-trigger` en PostgreSQL 17 desechable: **27 comprobaciones aprobadas**, con la estructura `tgtype=23`, `tgnargs=0`, `tgattr='6 7'` y `tgenabled='O'` antes de la primera instalación. El cuerpo de la función usado en laboratorio es un contador sintético: no se afirma haber ejecutado la función productiva ausente del repositorio.

Las verificaciones comprueban instalación inicial, repetición, conservación de UPDATE OF y de la función/ACL/estado/comentario; disparo de inserciones y actualizaciones filtradas de proyectos JSON; ausencia de disparo para columnas ajenas y proyectos comprimidos; y rechazo de variantes incompatibles. El JSON adjunto contiene el resultado real y los contadores. No se repiten los benchmarks de 200 MiB, la matriz de 120 permisos ni las compilaciones del cliente porque esta corrección no los modifica.

## G. Commit y Push

Después de aplicar y revisar esta corrección, añada las cinco rutas de la tabla a su commit, junto con los cambios anteriores que desee conservar, y haga Push mediante su flujo habitual. Esta entrega publica solamente el ZIP en el repositorio de descargas; no realiza Push automático al repositorio del software.

## H. Estado y límites

La causa de este rechazo del instalador está identificada: la lista UPDATE OF. Su instalación real y el posterior envío comprimido se comprueban siguiendo los pasos anteriores. Esto no demuestra la causa del timeout previo, de los HTTP 502/520 históricos ni de los eventos WAL.

El pendiente local de 200,1 MiB se conserva por diseño; Gzip se utiliza para transporte y almacenamiento remoto. Los editores con módulos restringidos mantienen su validación adicional en PostgreSQL. Los límites restantes y las pruebas anteriores están en `supabase/LEEME_PUBLICACION_COMPRIMIDA.md` y en el archivo de continuidad.
