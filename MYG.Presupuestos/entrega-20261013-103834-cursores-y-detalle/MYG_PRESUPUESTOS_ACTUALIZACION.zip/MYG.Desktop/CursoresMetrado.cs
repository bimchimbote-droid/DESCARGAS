using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace MYG_2027;

// Los cursores pertenecen a cada hoja y se liberan al cerrar su panel. El .cur
// se construye en memoria, sin archivos externos ni handles GDI prestados.
internal sealed class MYGCursoresMetrado : NativeWindow, IDisposable
{
    private readonly DataGridView hoja;
    private readonly Func<Point, Cursor> elegir;
    private readonly Func<int, Point, bool> raton;
    private Cursor seleccion, relleno, columna, fila, dimensionNativa;
    internal Cursor Seleccion => seleccion;
    internal Cursor Relleno => relleno;
    internal Cursor Columna => columna;
    internal Cursor Fila => fila;

    internal MYGCursoresMetrado(DataGridView hoja, Func<Point, Cursor> elegir, Func<int, Point, bool> raton)
    {
        this.hoja = hoja; this.elegir = elegir; this.raton = raton;
        CrearCursores();
        hoja.HandleCreated += CrearHandle;
        hoja.HandleDestroyed += DestruirHandle;
        hoja.DpiChangedAfterParent += CambiarDpi;
        hoja.MouseLeave += Salir;
        if (hoja.IsHandleCreated) AssignHandle(hoja.Handle);
    }

    private void CrearHandle(object sender, EventArgs e) => AssignHandle(hoja.Handle);
    private void DestruirHandle(object sender, EventArgs e) { dimensionNativa = null; ReleaseHandle(); }
    private void Salir(object sender, EventArgs e) { if (!hoja.Capture) hoja.Cursor = Cursors.Default; }
    private void CambiarDpi(object sender, EventArgs e)
    {
        hoja.Cursor = Cursors.Default;
        LiberarCursores(); CrearCursores();
    }

    private void CrearCursores()
    {
        int tamano = Math.Clamp((int)Math.Ceiling(32 * hoja.DeviceDpi / 96d), 32, 128);
        seleccion = Crear(tamano, 16, 16, g =>
        {
            using var exterior = new GraphicsPath();
            exterior.AddPolygon(Cruz(16, 16, 11, 3));
            g.FillPath(Brushes.Black, exterior);
            using var interior = new GraphicsPath();
            interior.AddPolygon(Cruz(16, 16, 10, 2));
            g.FillPath(Brushes.White, interior);
        });
        relleno = Crear(tamano, 16, 16, g =>
        {
            using var contorno = new Pen(Color.White, 2) { LineJoin = LineJoin.Miter };
            var puntos = Cruz(16, 16, 7, 1);
            g.DrawPolygon(contorno, puntos); g.FillPolygon(Brushes.Black, puntos);
        });
        columna = Crear(tamano, 16, 26, g => DibujarFlecha(g, false));
        fila = Crear(tamano, 26, 16, g => DibujarFlecha(g, true));
    }

    private static PointF[] Cruz(float x, float y, float brazo, float grosor) =>
    [new(x - grosor, y - brazo), new(x + grosor, y - brazo), new(x + grosor, y - grosor),
     new(x + brazo, y - grosor), new(x + brazo, y + grosor), new(x + grosor, y + grosor),
     new(x + grosor, y + brazo), new(x - grosor, y + brazo), new(x - grosor, y + grosor),
     new(x - brazo, y + grosor), new(x - brazo, y - grosor), new(x - grosor, y - grosor)];

    private static void DibujarFlecha(Graphics g, bool horizontal)
    {
        PointF[] puntos = [new(13, 5), new(19, 5), new(19, 17), new(25, 17), new(16, 26), new(7, 17), new(13, 17)];
        if (horizontal) for (int i = 0; i < puntos.Length; i++) puntos[i] = new(puntos[i].Y, puntos[i].X);
        using var borde = new Pen(Color.White, 2) { LineJoin = LineJoin.Miter };
        g.DrawPolygon(borde, puntos); g.FillPolygon(Brushes.Black, puntos);
    }

    private static Cursor Crear(int tamano, int x, int y, Action<Graphics> pintar)
    {
        using var imagen = new Bitmap(tamano, tamano);
        using (var g = Graphics.FromImage(imagen))
        { g.Clear(Color.Transparent); g.ScaleTransform(tamano / 32f, tamano / 32f); pintar(g); }
        int mascaraFila = ((tamano + 31) / 32) * 4;
        int bytesImagen = tamano * tamano * 4, bytesMascara = mascaraFila * tamano;
        using var memoria = new MemoryStream();
        using (var escritor = new BinaryWriter(memoria, System.Text.Encoding.UTF8, true))
        {
            escritor.Write((ushort)0); escritor.Write((ushort)2); escritor.Write((ushort)1);
            escritor.Write((byte)tamano); escritor.Write((byte)tamano); escritor.Write((byte)0); escritor.Write((byte)0);
            escritor.Write((ushort)(x * tamano / 32)); escritor.Write((ushort)(y * tamano / 32));
            escritor.Write(40 + bytesImagen + bytesMascara); escritor.Write(22);
            escritor.Write(40); escritor.Write(tamano); escritor.Write(tamano * 2);
            escritor.Write((ushort)1); escritor.Write((ushort)32); escritor.Write(0); escritor.Write(bytesImagen);
            escritor.Write(0); escritor.Write(0); escritor.Write(0); escritor.Write(0);
            for (int f = tamano - 1; f >= 0; f--) for (int c = 0; c < tamano; c++)
            {
                var color = imagen.GetPixel(c, f);
                escritor.Write(color.B); escritor.Write(color.G); escritor.Write(color.R); escritor.Write(color.A);
            }
            for (int f = tamano - 1; f >= 0; f--)
            {
                var mascara = new byte[mascaraFila];
                for (int c = 0; c < tamano; c++) if (imagen.GetPixel(c, f).A == 0) mascara[c / 8] |= (byte)(128 >> (c % 8));
                escritor.Write(mascara);
            }
        }
        memoria.Position = 0;
        return new Cursor(memoria);
    }

    protected override void WndProc(ref Message mensaje)
    {
        const int Mover = 0x0200, Pulsar = 0x0201, Soltar = 0x0202, EstablecerCursor = 0x0020;
        if (mensaje.Msg is 0x0215 or 0x001f or 0x0008) dimensionNativa = null;
        if (mensaje.Msg == 0x0100 && mensaje.WParam.ToInt32() == (int)Keys.Escape) dimensionNativa = null;
        if (mensaje.Msg == 0x0100 && mensaje.WParam.ToInt32() == (int)Keys.Escape && raton(mensaje.Msg, new((int)Keys.Escape, 0)))
        { mensaje.Result = IntPtr.Zero; return; }
        if (mensaje.Msg is 0x0008 or 0x001f) raton(mensaje.Msg, Point.Empty);
        if (mensaje.Msg == EstablecerCursor && mensaje.WParam == Handle && ((int)mensaje.LParam & 0xffff) == 1)
        {
            Cursor.Current = dimensionNativa ?? elegir(hoja.PointToClient(Cursor.Position));
            mensaje.Result = new IntPtr(1); return;
        }
        if (mensaje.Msg is Mover or Pulsar or Soltar)
        {
            long posicion = mensaje.LParam.ToInt64();
            var punto = new Point((short)(posicion & 0xffff), (short)((posicion >> 16) & 0xffff));
            if (dimensionNativa == null && raton(mensaje.Msg, punto)) { mensaje.Result = IntPtr.Zero; return; }
            if (mensaje.Msg == Pulsar)
            {
                var cursor = elegir(punto);
                if (cursor == Cursors.SizeWE || cursor == Cursors.SizeNS) dimensionNativa = cursor;
            }
            base.WndProc(ref mensaje);
            if (mensaje.Msg == Soltar) dimensionNativa = null;
            hoja.Cursor = dimensionNativa ?? elegir(punto);
            return;
        }
        base.WndProc(ref mensaje);
    }

    private void LiberarCursores()
    { seleccion?.Dispose(); relleno?.Dispose(); columna?.Dispose(); fila?.Dispose(); }

    public void Dispose()
    {
        hoja.HandleCreated -= CrearHandle; hoja.HandleDestroyed -= DestruirHandle;
        hoja.DpiChangedAfterParent -= CambiarDpi; hoja.MouseLeave -= Salir;
        ReleaseHandle();
        if (!hoja.IsDisposed) hoja.Cursor = Cursors.Default;
        LiberarCursores();
    }
}
