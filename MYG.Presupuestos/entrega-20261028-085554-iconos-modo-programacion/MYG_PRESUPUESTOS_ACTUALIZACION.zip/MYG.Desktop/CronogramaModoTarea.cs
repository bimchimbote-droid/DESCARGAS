using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace MYG_2027;

// Una sola geometría para la cinta, las celdas y el selector. Cada bitmap
// pertenece al llamador; las celdas dibujan vectores sin almacenar imágenes.
internal static class MYGIconosModoTarea
{
    internal static Bitmap Crear(MYGModoTarea modo, int lado = 32)
    {
        if (lado <= 0) throw new ArgumentOutOfRangeException(nameof(lado));
        var imagen = new Bitmap(lado, lado, PixelFormat.Format32bppPArgb);
        try
        {
            using var g = Graphics.FromImage(imagen);
            g.Clear(Color.Transparent);
            Dibujar(g, new Rectangle(0, 0, lado, lado), modo);
            return imagen;
        }
        catch { imagen.Dispose(); throw; }
    }

    internal static void Dibujar(Graphics g, Rectangle area, MYGModoTarea modo)
    {
        ArgumentNullException.ThrowIfNull(g);
        if (modo is not (MYGModoTarea.Automatica or MYGModoTarea.Manual))
            throw new ArgumentOutOfRangeException(nameof(modo));
        if (area.Width <= 0 || area.Height <= 0) return;
        var estado = g.Save();
        try
        {
            g.SetClip(area, CombineMode.Intersect);
            g.TranslateTransform(area.X, area.Y);
            g.ScaleTransform(area.Width / 32F, area.Height / 32F);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            if (modo == MYGModoTarea.Manual) DibujarManual(g);
            else DibujarAutomatico(g);
        }
        finally { g.Restore(estado); }
    }

    internal static bool IntentarModo(object valor, out MYGModoTarea modo)
    {
        string texto = Convert.ToString(valor) ?? "";
        modo = MYGModoTarea.Manual;
        if (texto.Equals("Manual", StringComparison.OrdinalIgnoreCase)) return true;
        modo = MYGModoTarea.Automatica;
        return texto.Equals("Automática", StringComparison.OrdinalIgnoreCase)
            || texto.Equals("Automatica", StringComparison.OrdinalIgnoreCase)
            || texto.Equals("Auto", StringComparison.OrdinalIgnoreCase);
    }

    private static void DibujarManual(Graphics g)
    {
        using var aguja = new SolidBrush(Color.FromArgb(35, 123, 137));
        g.FillPolygon(aguja, new PointF[] { new(3, 29), new(8.7F, 18.5F), new(11.5F, 21.3F) });
        using var forma = new GraphicsPath();
        forma.AddPolygon(new PointF[]
        {
            new(12.3F, 12.2F), new(18.4F, 6.4F), new(17, 5), new(20.3F, 2.1F),
            new(29, 10.8F), new(26.1F, 13.9F), new(24.7F, 12.5F), new(18.5F, 18.6F),
            new(18.8F, 22), new(15.8F, 25), new(6.8F, 16), new(9.7F, 13)
        });
        using var relleno = new LinearGradientBrush(new PointF(10, 5), new PointF(25, 25),
            Color.FromArgb(180, 239, 239), Color.FromArgb(79, 184, 194));
        using var borde = new Pen(Color.FromArgb(27, 139, 151), 1.2F) { LineJoin = LineJoin.Round };
        g.FillPath(relleno, forma); g.DrawPath(borde, forma);
        using var brillo = new Pen(Color.FromArgb(224, 255, 255), .9F) { LineJoin = LineJoin.Round };
        g.DrawLines(brillo, new PointF[] { new(14, 14), new(20, 8), new(24, 12) });
    }

    private static void DibujarAutomatico(Graphics g)
    {
        using var relleno = new SolidBrush(Color.FromArgb(133, 206, 250));
        using var borde = new Pen(Color.FromArgb(22, 117, 192), 1.2F);
        g.FillRectangle(relleno, 3, 6, 25, 15); g.DrawRectangle(borde, 3, 6, 25, 15);
        using var brillo = new Pen(Color.FromArgb(221, 245, 255), 1);
        g.DrawLine(brillo, 5, 8, 25, 8);
        // El contorno claro mantiene visible la flecha sobre fondos oscuros.
        using var halo = new Pen(Color.FromArgb(245, 250, 255), 3.6F) { LineJoin = LineJoin.Round, EndCap = LineCap.Round };
        using var flecha = new Pen(Color.FromArgb(48, 65, 77), 1.7F) { LineJoin = LineJoin.Round, EndCap = LineCap.Round };
        var punta = new PointF[] { new(23, 18), new(29, 23), new(23, 28) };
        g.DrawLine(halo, 13, 23, 28, 23); g.DrawLines(halo, punta);
        g.DrawLine(flecha, 13, 23, 28, 23); g.DrawLines(flecha, punta);
    }
}

internal sealed class MYGCeldaModoCronograma : DataGridViewComboBoxCell
{
    public override Type EditType => typeof(MYGEditorModoCronograma);

    protected override void Paint(Graphics graphics, Rectangle clipBounds, Rectangle cellBounds,
        int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue,
        string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle,
        DataGridViewPaintParts paintParts)
    {
        base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue,
            errorText, cellStyle, advancedBorderStyle, paintParts & ~DataGridViewPaintParts.ContentForeground);
        if ((paintParts & DataGridViewPaintParts.ContentForeground) == 0
            || !MYGIconosModoTarea.IntentarModo(value, out var modo)) return;
        int margen = Math.Max(2, (int)Math.Ceiling(3F * (DataGridView?.DeviceDpi ?? 96) / 96F));
        int lado = Math.Min((int)Math.Round(18F * (DataGridView?.DeviceDpi ?? 96) / 96F),
            Math.Min(cellBounds.Width, cellBounds.Height) - margen * 2);
        if (lado <= 0) return;
        var estado = graphics.Save();
        try
        {
            graphics.SetClip(clipBounds, CombineMode.Intersect);
            MYGIconosModoTarea.Dibujar(graphics, new Rectangle(cellBounds.Left + (cellBounds.Width - lado) / 2,
                cellBounds.Top + (cellBounds.Height - lado) / 2, lado, lado), modo);
        }
        finally { graphics.Restore(estado); }
    }
}

internal sealed class MYGEditorModoCronograma : DataGridViewComboBoxEditingControl
{
    public MYGEditorModoCronograma()
    {
        // Se define antes de la tematización para conservar el dibujo propio
        // al alternar normal/oscuro y al reutilizar el editor de la tabla.
        DrawMode = DrawMode.OwnerDrawFixed;
        Dimensionar();
    }

    protected override void OnFontChanged(EventArgs e) { base.OnFontChanged(e); Dimensionar(); }
    protected override void OnDpiChangedAfterParent(EventArgs e) { base.OnDpiChangedAfterParent(e); Dimensionar(); }
    protected override void OnDropDown(EventArgs e)
    {
        base.OnDropDown(e);
        // La celda restablece el ancho al abrir. Medir después conserva los
        // nombres completos aunque la columna muestre únicamente el icono.
        Dimensionar();
    }

    private void Dimensionar()
    {
        ItemHeight = Math.Max(Font.Height + 6, (int)Math.Ceiling(22F * DeviceDpi / 96F));
        DropDownWidth = Math.Max(Width, TextRenderer.MeasureText("Automática", Font).Width
            + (int)Math.Ceiling(38F * DeviceDpi / 96F));
    }

    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        bool seleccion = (e.State & DrawItemState.Selected) != 0;
        Color fondo = seleccion ? MYG2027_TemaComercial.Seleccion : BackColor;
        Color texto = seleccion ? MYG2027_TemaComercial.TextoSeleccion : ForeColor;
        using (var relleno = new SolidBrush(fondo)) e.Graphics.FillRectangle(relleno, e.Bounds);
        int indice = e.Index >= 0 ? e.Index : SelectedIndex;
        if (indice < 0 || indice >= Items.Count || !MYGIconosModoTarea.IntentarModo(Items[indice], out var modo)) return;
        int margen = Math.Max(2, (int)Math.Ceiling(3F * DeviceDpi / 96F));
        int lado = Math.Min((int)Math.Round(18F * DeviceDpi / 96F), e.Bounds.Height - margen * 2);
        bool cerrado = (e.State & DrawItemState.ComboBoxEdit) != 0;
        int x = cerrado ? e.Bounds.Left + (e.Bounds.Width - lado) / 2 : e.Bounds.Left + margen;
        MYGIconosModoTarea.Dibujar(e.Graphics,
            new Rectangle(x, e.Bounds.Top + (e.Bounds.Height - lado) / 2, lado, lado), modo);
        if (!cerrado)
            TextRenderer.DrawText(e.Graphics, GetItemText(Items[indice]), Font,
                new Rectangle(x + lado + margen, e.Bounds.Top, Math.Max(0, e.Bounds.Right - x - lado - margen), e.Bounds.Height),
                texto, fondo, TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix);
        if ((e.State & DrawItemState.Focus) != 0)
            ControlPaint.DrawFocusRectangle(e.Graphics, e.Bounds, texto, fondo);
    }
}
