# Corrección de Metrado Xls: pestañas, filas, selección y fuente

Esta actualización se aplica sobre la entrega de Metrado Xls publicada previamente en DESCARGAS (commit de entrega 1996bffb90757f6b4862cb411814513cce80063d).
Base del repositorio de código: main, 0845f78825ab633e6e0729144817297c25af9130.

## Cambios

- Los nueve nombres de pestañas tienen margen suficiente y se distribuyen en varias filas cuando el panel es estrecho. La altura de la cinta se ajusta sin tapar los comandos.
- Los números de fila se dibujan sin la flecha que los ocultaba. El ancho se calcula según el número de dígitos, el zoom y la escala de pantalla, y se conserva al cambiar de tema.
- El cuadro de dirección muestra una celda (B7), un rango completo (A4:C6) o los tramos reales de una selección discontinua (A4:B4,A6,C8). La barra de fórmulas conserva el contenido de la celda activa. Se puede navegar escribiendo estas direcciones y pulsando Enter.
- Arial Narrow es la fuente predeterminada de las celdas nuevas, la plantilla, el borrado de formato y los estilos sin fuente de XLSX. Se conservan las fuentes guardadas o importadas explícitamente.

Para aplicar Arial Narrow a una hoja anterior con otra fuente guardada, seleccionar sus celdas y elegir Arial Narrow en Inicio. El resto de los formatos se conserva.

## Instalación

1. Cerrar MYG y respaldar o confirmar los cambios locales.
2. Extraer este ZIP sobre la raíz de D:\ADDIN\repos\MYG.Presupuestos_GITHUB, conservando las rutas.
3. Reemplazar los siete archivos C# completos y crear este documento. Mantener todos los demás archivos de la entrega anterior.
4. Si modificaste alguno de los archivos entregados, combinar los cambios antes de reemplazarlo.
5. Compilar y ejecutar las comprobaciones siguientes.

## Compilación y validación

SDK validado: .NET 10.0.100. Sin paquetes adicionales ni migraciones de SQLite.

    dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
    dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
    dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore

En Windows:

    dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release

Se compiló la solución completa sin errores ni advertencias. La suite de datos y cálculo ejecutó 214 comprobaciones aprobadas, incluyendo dirección de selección y fuente predeterminada/XLSX. Named Pipes se omite explícitamente en Linux.
Las pruebas de interfaz se compilaron pero no se ejecutaron en Linux; queda pendiente su ejecución y la revisión visual en Windows. Incluyen pestañas en paneles de 420/800 píxeles, numeración de filas hasta 10000, selección y paletas.
Revisar la cinta y la numeración en las escalas de pantalla que uses, seleccionar una celda y un rango con ratón/teclado, comprobar el contenido de la celda activa y guardar/reabrir una copia de proyecto.

## GitHub

Se publica únicamente el ZIP en una carpeta nueva de DESCARGAS, conservando las entregas anteriores. No se hace commit ni push al repositorio del código.
Después de instalar, revisar Cambios de Git en Visual Studio, hacer Commit y Push manualmente y verificar la rama de trabajo en GitHub.
