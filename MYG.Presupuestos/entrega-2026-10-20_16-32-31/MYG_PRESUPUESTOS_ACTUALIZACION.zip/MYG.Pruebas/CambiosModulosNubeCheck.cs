using System;
using System.Collections.Generic;
using System.Text.Json;
using MYG_2027;

internal static class CambiosModulosNubeCheck
{
    internal static void Run(Action<string> pasa)
    {
        var original = MYGProyectoStorage.Nuevo("CONTROL DE MÓDULOS", "ESTRUCTURAS");
        var presupuesto = original.Presupuestos[0];
        var partida = new ItemPresupuestoDelphin
        {
            Id = "PARTIDA-UNO", IdLocalMYG = "LOCAL-UNO", TipoPropuesta = "PARTIDA",
            Descripcion = "Concreto", Unidad = "m³",
            Costos = new MYGDatosPartida { PrecioDirecto = 150m, EspecificacionTexto = "Especificación original" }
        };
        presupuesto.Items.Add(partida);
        partida.Costos.Hoja.Poner("A3", "Losa"); partida.Costos.Hoja.Poner("B3", "2");
        string huellaOriginal = JsonSerializer.Serialize(original);
        var bloqueados = new MYGPermisosModulos { Acu = false, Especificaciones = false, MetradosExcel = false };

        void Permitido(Action<MYGProyectoDocumento> cambiar)
        {
            var nuevo = MYGProyectoStorage.Copia(original); cambiar(nuevo);
            MYGCambiosModulosNube.ExigirPermitidos(original, nuevo, bloqueados);
        }
        void Bloqueado(Action<MYGProyectoDocumento> cambiar, MYGPermisosModulos permisos = null)
        {
            var nuevo = MYGProyectoStorage.Copia(original); cambiar(nuevo);
            bool rechazo = false;
            try { MYGCambiosModulosNube.ExigirPermitidos(original, nuevo, permisos ?? bloqueados); }
            catch (InvalidOperationException) { rechazo = true; }
            if (!rechazo) throw new Exception("Un cambio en un módulo de solo lectura fue aceptado.");
        }

        Permitido(d => { d.Nombre = "Nombre actualizado"; d.PresupuestoActivoId = "OTRO"; d.ModificadoUtc = DateTime.UtcNow;
            d.Presupuestos[0].Items[0].Descripcion = "Nombre de partida actualizado";
            d.Presupuestos[0].Items[0].Costos.Hoja.Zoom = 175; });
        pasa("Módulos en solo lectura permiten renombrar, navegar y cambiar el zoom sin modificar datos protegidos");

        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.PrecioDirecto++);
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.RendimientoDiario++);
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.JornadaHoras++);
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.Analisis.Add(new MYGRecursoACU { InsumoId = "INSUMO" }));
        Bloqueado(d => d.Presupuestos[0].Items[0].Unidad = "m²");
        Bloqueado(d => d.Presupuestos[0].Costos.Insumos.Add(new MYGInsumo { Descripcion = "Acero", Precio = 15m }));
        Bloqueado(d => d.Presupuestos[0].Costos.DecimalesPrecio++);
        Bloqueado(d => d.Presupuestos[0].Costos.ConfiguracionCostoDirecto = new() { IncluirIgvMateriales = true });
        Bloqueado(d => { d.Datos ??= new MYGDatosProyecto(); d.Datos.PorRendimientoCuadrilla = false; d.Datos.PorAsignacionRecursos = true; });
        pasa("ACU bloqueado protege precio, análisis, rendimiento, jornada, unidades, insumos y configuración de cálculo");

        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.EspecificacionTexto += " cambio");
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.EspecificacionRtf = @"{\rtf1 Texto}");
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.EspecificacionEsBorrador = true);
        pasa("Especificaciones en solo lectura protegen texto, formato RTF y estado de borrador");

        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.Hoja.Poner("B3", "20"));
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.Hoja.Celdas["A3"].Negrita = true);
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.Hoja.CeldaTotal = "B3");
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.Excel);
        Permitido(d => { d.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
            d.Presupuestos[0].Items[0].Costos.Cantidad = 20m; });
        pasa("Excel bloqueado conserva fórmulas, formatos, celda total y origen Excel sin bloquear cantidades de otras fuentes");

        var excelActivo = MYGProyectoStorage.Copia(original);
        excelActivo.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        excelActivo.Presupuestos[0].Items[0].Costos.Cantidad = 2m;
        foreach (bool quitarFuente in new[] { false, true })
        {
            var siguiente = MYGProyectoStorage.Copia(excelActivo);
            if (quitarFuente) siguiente.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
            else siguiente.Presupuestos[0].Items[0].Costos.Cantidad = 200m;
            bool rechazo = false;
            try { MYGCambiosModulosNube.ExigirPermitidos(excelActivo, siguiente, bloqueados); }
            catch (InvalidOperationException) { rechazo = true; }
            if (!rechazo) throw new Exception("El origen o la cantidad Excel activa se modificó en solo lectura.");
        }
        pasa("Excel activo en solo lectura impide cambiar su cantidad o sustituir su fuente por otra");

        Bloqueado(d => d.Presupuestos[0].Items.Clear());
        Bloqueado(d => d.Presupuestos.Clear());
        Bloqueado(d => d.Presupuestos[0].Items[0].Id = "IDENTIDAD-NUEVA");
        Bloqueado(d => { var copia = MYGProyectoStorage.Copia(d.Presupuestos[0].Items[0]); copia.Id = "COPIA";
            d.Presupuestos[0].Items.Add(copia); });
        pasa("Eliminar, cambiar identidad y copiar ramas con datos protegidos no eluden los permisos por módulo");

        Permitido(d => d.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            { Id = "PARTIDA-VACIA", Unidad = "und", Descripcion = "Vacía", TipoPropuesta = "PARTIDA" }));
        Permitido(d => d.Presupuestos.Add(new MYGPresupuestoDocumento { Nombre = "Presupuesto vacío" }));
        var vacio = MYGProyectoStorage.Copia(original);
        vacio.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin { Id = "PARTIDA-VACIA" });
        MYGCambiosModulosNube.ExigirPermitidos(vacio, original, bloqueados);
        pasa("Es posible crear y quitar filas o presupuestos vacíos sin tocar módulos bloqueados");

        var soloAcu = new MYGPermisosModulos { Acu = false };
        var permitido = MYGProyectoStorage.Copia(original);
        permitido.Presupuestos[0].Items[0].Costos.EspecificacionTexto = "Nueva especificación";
        permitido.Presupuestos[0].Items[0].Costos.Hoja.Poner("B3", "12");
        MYGCambiosModulosNube.ExigirPermitidos(original, permitido, soloAcu);
        Bloqueado(d => d.Presupuestos[0].Items[0].Costos.PrecioDirecto++, soloAcu);
        MYGCambiosModulosNube.ExigirPermitidos(original, permitido, null);
        pasa("Cada permiso actúa de forma independiente y el contrato legado conserva el control por rol global");

        var ordenado = MYGProyectoStorage.Copia(original);
        var hoja = ordenado.Presupuestos[0].Items[0].Costos.Hoja;
        var entradas = new List<KeyValuePair<string, MYGCeldaHoja>>(hoja.Celdas); entradas.Reverse();
        hoja.Celdas.Clear(); foreach (var entrada in entradas) hoja.Celdas.Add(entrada.Key, entrada.Value);
        MYGCambiosModulosNube.ExigirPermitidos(original, ordenado, bloqueados);
        Bloqueado(d => d.Presupuestos[0].Items.Add(MYGProyectoStorage.Copia(d.Presupuestos[0].Items[0])));
        if (JsonSerializer.Serialize(original) != huellaOriginal)
            throw new Exception("La comprobación de permisos modificó el documento original.");
        pasa("La comparación ignora el orden JSON de las celdas y rechaza identidades repetidas sin modificar los documentos");
    }
}
