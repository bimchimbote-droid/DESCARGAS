using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGEspecificacionesEditor
{
    private MYGEspecificacionesOrtografia ortografia;
    private MYGEspecificacionesAnotaciones anotaciones;
    private MYGEspecificacionesContextoNativo contextoNativo;
    private readonly ContextMenuStrip menuDocumento = new() { Name = "espec_menu_documento" };
    private int indiceContexto = -1, elementosOrtografia;
    private int dialogosEdicion;
    private ToolStripMenuItem cortarContexto, copiarContexto, pegarContexto;

    private void PrepararEdicionContextual(Func<string, IReadOnlyList<MYGErrorOrtografico>> comprobar,
        Func<string, IReadOnlyList<string>> sugerir, Action<string> agregar)
    {
        ortografia = new MYGEspecificacionesOrtografia(documento, comprobar, sugerir, agregar);
        vistaOscura.PinturaAdicional = ortografia.Pintar;
        anotaciones = new MYGEspecificacionesAnotaciones(documento, this, AplicarFormato);
        cortarContexto = OpcionContexto("Cortar", "cortar", () => AplicarFormato(documento.Cut));
        copiarContexto = OpcionContexto("Copiar", "copiar", documento.Copy);
        pegarContexto = OpcionContexto("Pegar", "pegar", () => AplicarFormato(documento.Paste));
        menuDocumento.Items.Add(new ToolStripSeparator());
        OpcionContexto("Aumentar Sangría", "sangria_mas", () => AplicarFormato(() => MYGEspecificacionesFormato.Sangria(documento, 360)));
        OpcionContexto("Disminuir Sangría", "sangria_menos", () => AplicarFormato(() => MYGEspecificacionesFormato.Sangria(documento, -360)));
        menuDocumento.Items.Add(new ToolStripSeparator());
        OpcionContexto("Fuente", "fuente", () => SinRegistroEntrada(ConfigurarFuenteContextual));
        OpcionContexto("Párrafo", "parrafo", () => SinRegistroEntrada(ConfigurarParrafoContextual));
        OpcionContexto("Lista Enumerada", "numeracion", () => AplicarFormato(() => MYGEspecificacionesFormato.Lista(documento, true)));
        menuDocumento.Items.Add(new ToolStripSeparator());
        OpcionContexto("Marcador...", "marcador", () => SinRegistroEntrada(anotaciones.Marcadores));
        OpcionContexto("Hipervínculo...", "enlace", () => SinRegistroEntrada(anotaciones.Hipervinculo));
        menuDocumento.Items.Add(new ToolStripSeparator());
        OpcionContexto("Nuevo comentario", "comentario", () => SinRegistroEntrada(() => anotaciones.Comentarios()));
        var menuVisible = documento.ContextMenuStrip ?? menuDocumento;
        documento.ContextMenuStrip = menuVisible;
        papel.ContextMenuStrip = menuVisible;
        contextoNativo = new MYGEspecificacionesContextoNativo(documento, menuVisible, PrepararPosicionContexto);
        papel.MouseDown += PrepararPosicionPapel;
        menuDocumento.Opening += AbrirMenuDocumento;
        menuDocumento.Closed += (_, _) => indiceContexto = -1;
    }

    private void SinRegistroEntrada(Action accion)
    {
        dialogosEdicion++;
        try { accion(); }
        finally { dialogosEdicion--; }
    }

    private ToolStripMenuItem OpcionContexto(string texto, string icono, Action accion)
    {
        var opcion = new ToolStripMenuItem(texto) { Name = "espec_contexto_" + icono };
        // Icono usa por defecto el diseño de la cinta (sólo imagen). El menú
        // necesita conservar la etiqueta y distribuirla junto al icono.
        MYGEspecificacionesCinta.Icono(opcion, icono, mostrarTexto: true);
        opcion.TextImageRelation = TextImageRelation.ImageBeforeText;
        opcion.ImageAlign = opcion.TextAlign = ContentAlignment.MiddleLeft;
        opcion.Click += (_, _) => Intentar(accion);
        menuDocumento.Items.Add(opcion);
        return opcion;
    }

    private void PrepararPosicionPapel(object sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Right) indiceContexto = -2;
    }

    private void PrepararPosicionContexto(Point? posicion)
    {
        if (!posicion.HasValue) { indiceContexto = -1; return; }
        int indice = documento.GetCharIndexFromPosition(posicion.Value);
        indiceContexto = indice;
        // RichEdit devuelve un carácter próximo al pulsar en el margen. TOM
        // mide el carácter real, incluso si su fuente es mayor que la de la hoja.
        if (!MYGEspecificacionesOrtografia.ContieneCaracter(documento, indice, posicion.Value)) indiceContexto = -2;
        // El punto identifica la palabra para ortografía; la selección/cursor
        // permanece donde estaba hasta que el usuario ejecuta un comando.
    }

    private void AbrirMenuDocumento(object sender, CancelEventArgs e)
    {
        try { ActualizarMenuDocumento(); }
        finally { AplicarTemaMenuDocumento(); }
    }

    private void AplicarTemaMenuDocumento()
    {
        MYGEspecificacionesCinta.AplicarTema(menuDocumento);
        if (menuDocumento.Renderer is ToolStripProfessionalRenderer renderer)
            menuDocumento.BackColor = renderer.ColorTable.ToolStripDropDownBackground;
        menuDocumento.Invalidate(true);
    }

    private void ActualizarMenuDocumento()
    {
        while (elementosOrtografia > 0)
        {
            var anterior = menuDocumento.Items[0];
            menuDocumento.Items.RemoveAt(0); anterior.Dispose(); elementosOrtografia--;
        }
        bool editable = EdicionNubePermitida && !documento.ReadOnly;
        foreach (ToolStripItem item in menuDocumento.Items) item.Enabled = editable;
        cortarContexto.Enabled = editable && documento.SelectionLength > 0;
        copiarContexto.Enabled = documento.SelectionLength > 0;
        pegarContexto.Enabled = editable && HayContenidoParaPegar();
        var error = ortografia.ObtenerError(indiceContexto == -1 ? documento.SelectionStart : indiceContexto);
        if (!editable || error == null) return;
        void Agregar(string texto, Action accion)
        {
            var opcion = new ToolStripMenuItem(texto) { Name = "espec_contexto_ortografia" };
            opcion.Click += (_, _) => Intentar(accion);
            menuDocumento.Items.Insert(elementosOrtografia++, opcion);
        }
        var sugerencias = ortografia.Sugerencias(error);
        foreach (string sugerencia in sugerencias)
        {
            string reemplazo = sugerencia;
            Agregar(reemplazo, () => AplicarFormato(() => ortografia.Corregir(error, reemplazo)));
        }
        if (sugerencias.Count == 0)
        {
            var ninguna = new ToolStripMenuItem("Sin sugerencias") { Enabled = false };
            menuDocumento.Items.Insert(elementosOrtografia++, ninguna);
        }
        menuDocumento.Items.Insert(elementosOrtografia++, new ToolStripSeparator());
        Agregar("Ignorar", () => ortografia.Ignorar(error));
        Agregar("Ignorar todo", () => ortografia.IgnorarTodo(error));
        Agregar("Agregar al Diccionario", () => ortografia.AgregarAlDiccionario(error));
        menuDocumento.Items.Insert(elementosOrtografia++, new ToolStripSeparator());
        Agregar("Comprobar ortografía", ComprobarOrtografia);
        menuDocumento.Items.Insert(elementosOrtografia++, new ToolStripSeparator());
    }

    private bool HayContenidoParaPegar()
    {
        try
        {
            return Clipboard.ContainsText() || Clipboard.ContainsText(TextDataFormat.Rtf) ||
                Clipboard.ContainsText(TextDataFormat.Html) || Clipboard.ContainsImage();
        }
        catch (System.Runtime.InteropServices.ExternalException) { return false; }
    }

    private void ConfigurarFuenteContextual()
    {
        if (documento.ReadOnly || !EdicionNubePermitida) return;
        using var dialogo = new FontDialog
        {
            Font = documento.SelectionFont ?? documento.Font, Color = documento.SelectionColor,
            ShowColor = true, AllowVerticalFonts = false, MinSize = 1, MaxSize = 500
        };
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            AplicarFormato(() => { documento.SelectionFont = dialogo.Font; documento.SelectionColor = dialogo.Color; });
    }

    private void ConfigurarParrafoContextual()
    {
        if (documento.ReadOnly || !EdicionNubePermitida) return;
        using var dialogo = new Form
        {
            Text = "Párrafo", ClientSize = new(390, 300), FormBorderStyle = FormBorderStyle.FixedDialog,
            StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false
        };
        var alineacion = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Location = new(180, 20), Width = 185 };
        alineacion.Items.AddRange(new object[] { "Conservar", "Izquierda", "Derecha", "Centrada", "Justificada" });
        alineacion.SelectedIndex = MYGEspecificacionesFormato.ObtenerAlineacion(documento);
        var interlineado = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Location = new(180, 58), Width = 185 };
        interlineado.Items.AddRange(new object[] { "Conservar", "Sencillo", "1,15 líneas", "1,5 líneas", "Doble", "3 líneas" });
        interlineado.SelectedIndex = 0;
        dialogo.Controls.AddRange(new Control[] { new Label { Text = "Alineación", Location = new(20, 23) }, alineacion,
            new Label { Text = "Interlineado", Location = new(20, 61) }, interlineado });
        string[] nombres = { "Sangría izquierda (mm)", "Sangría derecha (mm)", "Sangría francesa (mm)" };
        int[] valores = { documento.SelectionIndent, documento.SelectionRightIndent, documento.SelectionHangingIndent };
        var numeros = new NumericUpDown[3];
        for (int i = 0; i < numeros.Length; i++)
        {
            numeros[i] = new NumericUpDown
            {
                Minimum = -100, Maximum = 500, DecimalPlaces = 1,
                Value = Math.Clamp((decimal)valores[i] / DeviceDpi * 25.4m, -100, 500),
                Location = new(180, 102 + i * 40), Width = 185
            };
            dialogo.Controls.AddRange(new Control[] { new Label { Text = nombres[i], Location = new(20, 105 + i * 40), Width = 155 }, numeros[i] });
        }
        BotonesDialogo(dialogo);
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        AplicarFormato(() =>
        {
            if (alineacion.SelectedIndex > 0) MYGEspecificacionesFormato.Alinear(documento, alineacion.SelectedIndex);
            if (interlineado.SelectedIndex > 0) MYGEspecificacionesFormato.Interlineado(documento,
                new[] { 1f, 1.15f, 1.5f, 2f, 3f }[interlineado.SelectedIndex - 1]);
            documento.SelectionIndent = (int)(numeros[0].Value / 25.4m * DeviceDpi);
            documento.SelectionRightIndent = (int)(numeros[1].Value / 25.4m * DeviceDpi);
            documento.SelectionHangingIndent = (int)(numeros[2].Value / 25.4m * DeviceDpi);
        });
    }

    private void ComprobarOrtografia()
    {
        ortografia.ComprobarAhora();
        if (!ortografia.Disponible || !ortografia.RevisionCompleta)
        {
            MessageBox.Show(this, ortografia.Estado, "Comprobar ortografía", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var siguiente = ortografia.Errores.FirstOrDefault(x => x.Inicio >= documento.SelectionStart + documento.SelectionLength)
            ?? ortografia.Errores.FirstOrDefault();
        if (siguiente == null)
        {
            MessageBox.Show(this, "La revisión ha finalizado. No se encontraron errores ortográficos.",
                "Comprobar ortografía", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        documento.Focus(); documento.Select(siguiente.Inicio, siguiente.Longitud); documento.ScrollToCaret();
        indiceContexto = siguiente.Inicio;
        Point posicion = documento.GetPositionFromCharIndex(siguiente.Inicio);
        menuDocumento.Show(documento, new Point(posicion.X, posicion.Y + documento.Font.Height));
    }

    private void LiberarEdicionContextual()
    {
        contextoNativo?.Dispose();
        papel.MouseDown -= PrepararPosicionPapel;
        menuDocumento.Opening -= AbrirMenuDocumento;
        vistaOscura.PinturaAdicional = null;
        ortografia?.Dispose(); anotaciones?.Dispose(); menuDocumento.Dispose();
    }
}
