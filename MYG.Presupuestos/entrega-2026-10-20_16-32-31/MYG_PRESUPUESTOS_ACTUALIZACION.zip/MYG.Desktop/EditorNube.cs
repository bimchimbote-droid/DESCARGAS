using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Colaboracion;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private Func<ClienteSupabase> obtenerClienteNube;
    private Action mostrarColaboracionNube;
    private MYGVinculoNube vinculoNube;
    private FlowLayoutPanel barraNube;
    private TableLayoutPanel contenedorNube;
    private Label estadoNube;
    private Button sincronizarNube, recargarNube, resolverNube;
    private System.Windows.Forms.Timer relojPermisosNube;
    private bool permisoNubeAnterior, conservandoEdicionNube, bimBloqueadoNube;

    internal Guid? NubeProyectoId => vinculoNube?.ProyectoId;
    internal string NubeServidor => vinculoNube?.Servidor;
    internal string NubeUsuario => vinculoNube?.UsuarioId;

    private bool IdentidadNubeDisponible
    {
        get
        {
            if (vinculoNube == null) return true;
            ClienteSupabase actual = obtenerClienteNube?.Invoke();
            return actual?.SesionIniciada == true && actual.UsuarioId == vinculoNube.UsuarioId
                && string.Equals(actual.UrlServidor.TrimEnd('/'), vinculoNube.Servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase);
        }
    }

    private bool PuedeModificarProyecto => conservandoEdicionNube || sesion.Autorizado &&
        (vinculoNube == null || IdentidadNubeDisponible && SincronizadorProyectoNube.PuedeEditar(vinculoNube.Rol)
            && vinculoNube.EstadoConexion != "acceso retirado");

    private void ExigirPermisosModulosEstructura(bool acu = true, bool especificaciones = true, bool metrados = true)
    {
        ExigirPermisoEdicionProyecto();
        var permisos = vinculoNube?.PermisosModulos;
        if (acu && permisos?.Acu == false || especificaciones && permisos?.Especificaciones == false
            || metrados && permisos?.MetradosExcel == false)
            throw new InvalidOperationException("Esta acción puede cambiar módulos configurados en solo lectura. Solicite permiso al administrador.");
    }

    private void ExigirPermisoEdicionProyecto()
    {
        if (!PuedeModificarProyecto)
            throw new InvalidOperationException(vinculoNube == null
                ? "Inicie una sesión autorizada para modificar el proyecto."
                : "Esta copia está en solo lectura. Compruebe la sesión de nube y el permiso del proyecto. Puede consultar y guardar una copia local.");
    }

    internal void ConfigurarNube(Func<ClienteSupabase> obtenerCliente, Action mostrarColaboracion)
    {
        obtenerClienteNube = obtenerCliente;
        mostrarColaboracionNube = mostrarColaboracion;
        RecargarVinculoNube();
        if (vinculoNube == null && contenedorNube == null) return;
        if (contenedorNube == null)
        {
            barraNube = new FlowLayoutPanel
            {
                Name = "barra_proyecto_nube", Dock = DockStyle.Fill, AutoScroll = true,
                WrapContents = false, Padding = new(8, 5, 6, 3), Margin = new(0),
                BackColor = MYG2027_TemaComercial.AzulSuave
            };
            estadoNube = new Label { Name = "estado_proyecto_nube", Width = 330, Height = 32,
                TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true, Margin = new(0, 0, 8, 0) };
            barraNube.Controls.Add(estadoNube);
            Button Boton(string texto, string nombre, Func<Task> accion)
            {
                var boton = MYGProyectoUI.Boton(texto); boton.Name = nombre;
                boton.AutoSize = true; boton.Height = 32; boton.Margin = new(0, 0, 6, 0);
                boton.Click += async (_, _) =>
                {
                    try { await accion(); }
                    catch (Exception ex) { estado.Text = ex.Message; MYGProyectoUI.Error(this, ex); }
                };
                barraNube.Controls.Add(boton); return boton;
            }
            sincronizarNube = Boton("Sincronizar", "sincronizar_proyecto_nube", () => ActualizarNubeAsync(false));
            recargarNube = Boton("Recargar", "recargar_proyecto_nube", () => ActualizarNubeAsync(true));
            Boton("Colaboración", "colaboracion_proyecto_nube", () =>
            { mostrarColaboracionNube?.Invoke(); return Task.CompletedTask; });
            resolverNube = Boton("Resolver conflicto", "resolver_conflicto_nube", () =>
            { ResolverConflictoNube(); return Task.CompletedTask; });
            Boton("Guardar copia local", "copia_local_proyecto_nube", () =>
            { GuardarCopiaLocalNube(); return Task.CompletedTask; });
            ayudas.SetToolTip(recargarNube, "Consulta la revisión y los permisos del servidor. Si hay cambios locales, se conservan como conflicto.");
            contenedorNube = new TableLayoutPanel { Name = "contenedor_proyecto_nube", Dock = DockStyle.Fill,
                ColumnCount = 1, RowCount = 2, Margin = new(0), Padding = new(0) };
            contenedorNube.ColumnStyles.Add(new(SizeType.Percent, 100));
            contenedorNube.RowStyles.Add(new(SizeType.Absolute, 48));
            contenedorNube.RowStyles.Add(new(SizeType.Percent, 100));
            Controls.Remove(exteriorPresupuestoCronograma);
            contenedorNube.Controls.Add(barraNube, 0, 0);
            contenedorNube.Controls.Add(exteriorPresupuestoCronograma, 0, 1);
            Controls.Add(contenedorNube);
            panelPresupuesto.ConfigurarPermisoNube(() => PuedeModificarProyecto, () => vinculoNube?.PermisosModulos);
            relojPermisosNube = new System.Windows.Forms.Timer { Interval = 1000 };
            relojPermisosNube.Tick += (_, _) => ActualizarEstadoNube();
            relojPermisosNube.Start();
            Disposed += (_, _) => relojPermisosNube.Dispose();
        }
        ActualizarEstadoNube(); EstadoSesion();
    }

    private void RecargarVinculoNube()
    {
        vinculoNube = !string.IsNullOrWhiteSpace(archivo) && File.Exists(archivo)
            ? MYGColaboracionLocal.Leer(archivo, documento.Id) : null;
    }

    private void ActualizarEstadoNube()
    {
        if (IsDisposed || barraNube == null) return;
        bool permisoAnterior = permisoNubeAnterior;
        ConservarEdicionAntesDeBloquearNube();
        bool permiso = PuedeModificarProyecto;
        bool cambioPermiso = permiso != permisoAnterior;
        permisoNubeAnterior = permiso;
        barraNube.Visible = vinculoNube != null;
        contenedorNube.RowStyles[0].Height = vinculoNube == null ? 0 : (float)Math.Ceiling(48F * DeviceDpi / 96F);
        if (vinculoNube != null)
        {
            string estadoActual = !string.IsNullOrWhiteSpace(vinculoNube.EstadoConexion)
                ? vinculoNube.EstadoConexion : vinculoNube.Estado;
            if (!string.IsNullOrWhiteSpace(vinculoNube.JsonRemotoConflicto)) estadoActual = "conflicto";
            else if (estadoActual != "acceso retirado" && !IdentidadNubeDisponible) estadoActual = "solo lectura · falta sesión de nube";
            else if (estadoActual != "acceso retirado" && !sesion.Autorizado) estadoActual = "solo lectura · falta sesión MYG";
            else if (estadoActual != "acceso retirado" && !SincronizadorProyectoNube.PuedeEditar(vinculoNube.Rol)) estadoActual = "solo lectura";
            if (vinculoNube.Pendiente != null && !estadoActual.Contains("pendiente", StringComparison.OrdinalIgnoreCase))
                estadoActual += " · pendiente";
            estadoNube.Text = "NUBE · " + estadoActual + " · r" + vinculoNube.Revision + " · " + vinculoNube.Rol;
            ayudas.SetToolTip(estadoNube, estadoNube.Text + "\n" + vinculoNube.Servidor);
            sincronizarNube.Enabled = !ocupado && IdentidadNubeDisponible && vinculoNube.EstadoConexion != "acceso retirado"
                && string.IsNullOrWhiteSpace(vinculoNube.JsonRemotoConflicto);
            recargarNube.Enabled = !ocupado && IdentidadNubeDisponible;
            resolverNube.Enabled = !ocupado && !string.IsNullOrWhiteSpace(vinculoNube.JsonRemotoConflicto);
        }
        panelPresupuesto?.ActualizarPermisoNube();
        if (cambioPermiso) EstadoSesion();
    }

    private void ConservarEdicionAntesDeBloquearNube()
    {
        if (vinculoNube == null || !permisoNubeAnterior || PuedeModificarProyecto || ocupado || conservandoEdicionNube) return;
        // Se confirma una edición ya iniciada antes de pasar a solo lectura.
        conservandoEdicionNube = true;
        try { Sincronizar(); Guardar(false); }
        catch (Exception ex) { estado.Text = "No se pudo conservar la edición pendiente: " + ex.Message; }
        finally { conservandoEdicionNube = false; permisoNubeAnterior = false; }
    }

    private void AplicarPermisosBimNube()
    {
        if (vinculoNube == null || PuedeModificarProyecto)
        {
            if (!bimBloqueadoNube) return;
            foreach (Control grupo in acciones.Controls)
                foreach (Button boton in grupo.Controls.OfType<Button>()) boton.Enabled = !ocupado && sesion.Autorizado;
            foreach (Control grupo in pie.Controls)
                foreach (Button boton in grupo.Controls.OfType<Button>()) boton.Enabled = !ocupado;
            bimBloqueadoNube = false; ActualizarDisponibilidad(); return;
        }
        bimBloqueadoNube = true;
        foreach (Control grupo in acciones.Controls)
            foreach (Button boton in grupo.Controls.OfType<Button>())
                boton.Enabled = !ocupado && boton.Text is "Expandir todo" or "Contraer todo" or "Columnas" or "Exportar presupuesto";
        foreach (Control grupo in pie.Controls)
        {
            foreach (Button boton in grupo.Controls.OfType<Button>())
                boton.Enabled = !ocupado && boton.Text is "Guardar" or "Abrir proyecto" or "Federar metrados";
        }
    }

    private bool HerramientaEditorDisponible(Button boton)
    {
        if (vinculoNube == null || PuedeModificarProyecto)
            return HerramientaProyectoDisponible(boton.Tag is not false, ocupado, sesion.Autorizado);
        if (ocupado) return false;
        return boton.Tag is false || boton.Name is "imprimir_proyecto_button" or "exportar_proyecto_button"
            or "resumen_costos_button" or "especificaciones_button"
            or "cronograma_imprimir_button" or "cronograma_exportar_button";
    }

    internal MYGProyectoDocumento DocumentoParaPublicar()
    {
        if (ocupado) throw new InvalidOperationException("Espere a que termine la operación actual.");
        Sincronizar();
        if (!Guardar(false)) throw new OperationCanceledException("Se canceló el guardado del proyecto.");
        return MYGProyectoStorage.Copia(documento);
    }

    internal async Task ActualizarNubeAsync(bool soloLeer)
    {
        if (ocupado) return;
        RecargarVinculoNube();
        if (vinculoNube == null) throw new InvalidOperationException("El proyecto no está vinculado a la nube.");
        ClienteSupabase actual = obtenerClienteNube?.Invoke()
            ?? throw new NubeException("Inicie sesión de nube para actualizar este proyecto.", necesitaIniciarSesion: true);
        SincronizadorProyectoNube.ValidarIdentidad(actual, vinculoNube);
        if (!Guardar(false)) return;
        RecargarVinculoNube();
        if (vinculoNube.EstadoConexion == "acceso retirado") soloLeer = true;
        ocupado = true; UseWaitCursor = true; EstadoSesion(); ActualizarEstadoNube();
        try
        {
            MYGProyectoDocumento anterior = documento;
            ResultadoSincronizacion resultado = await SincronizadorProyectoNube.EjecutarAsync(actual, archivo, documento, soloLeer);
            documento = resultado.Documento; vinculoNube = resultado.Vinculo;
            if (!ReferenceEquals(anterior, documento)) { undo.Clear(); redo.Clear(); }
            firmaGuardada = MYGProyectoStorage.Firma(documento);
            Refrescar();
        }
        finally
        {
            ocupado = false; UseWaitCursor = false;
            RecargarVinculoNube(); ActualizarEstadoNube(); EstadoSesion(); ActualizarIndicadorArchivo();
        }
    }

    private bool GuardarCopiaLocalNube()
    {
        Sincronizar();
        using var elegir = new SaveFileDialog
        {
            Title = "Guardar copia local independiente", Filter = "Base SQLite (*.sqlite)|*.sqlite|Paquete ZIP (*.zip)|*.zip",
            DefaultExt = "sqlite", AddExtension = true,
            FileName = Path.GetFileNameWithoutExtension(archivo) + "_COPIA_LOCAL.sqlite"
        };
        if (elegir.ShowDialog(this) != DialogResult.OK) return false;
        if (File.Exists(elegir.FileName)) throw new IOException("Elija un archivo nuevo para guardar la copia local independiente.");
        if (string.Equals(Path.GetFullPath(elegir.FileName), Path.GetFullPath(archivo), StringComparison.OrdinalIgnoreCase))
            throw new IOException("La copia local necesita un archivo distinto de la copia de nube.");
        string alcance = "obra";
        if (!string.IsNullOrWhiteSpace(vinculoNube?.JsonPaqueteConfirmado))
        {
            using var confirmado = JsonDocument.Parse(vinculoNube.JsonPaqueteConfirmado, new JsonDocumentOptions { MaxDepth = 128 });
            if (confirmado.RootElement.TryGetProperty("alcance", out var a) && a.GetString() == "base") alcance = "base";
        }
        JsonElement paquete = PaqueteNube.CrearContenido(MYGProyectoStorage.Copia(documento), archivo, alcance);
        PaqueteNube.Descargar(paquete, elegir.FileName, elegir.FilterIndex == 2);
        estado.Text = "Copia local independiente guardada: " + Path.GetFileName(elegir.FileName);
        return true;
    }

    private void ResolverConflictoNube()
    {
        if (ocupado) return;
        Sincronizar(); RecargarVinculoNube();
        if (string.IsNullOrWhiteSpace(vinculoNube?.JsonRemotoConflicto)) return;
        using var elegir = new Form();
        MYGProyectoUI.Preparar(elegir, "Resolver conflicto de nube", 670, 260);
        var detalle = new Label { Dock = DockStyle.Fill, Padding = new(18), Text =
            "La nube tiene la revisión " + vinculoNube.RevisionRemotaConflicto + " y esta copia conserva sus cambios locales.\n\n"
            + "Mantener local crea una operación nueva sobre la revisión remota; podrá enviarla al sincronizar. "
            + "Usar remoto reemplaza el documento local y descarta el borrador pendiente." };
        var local = MYGProyectoUI.Boton("Mantener local", 1); local.AutoSize = true;
        var remoto = MYGProyectoUI.Boton("Usar remoto"); remoto.AutoSize = true;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        local.Enabled = PuedeModificarProyecto;
        local.Click += (_, _) => elegir.DialogResult = DialogResult.Yes;
        remoto.Click += (_, _) => elegir.DialogResult = DialogResult.No;
        var opciones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48,
            FlowDirection = FlowDirection.RightToLeft, Padding = new(8), WrapContents = false };
        opciones.Controls.AddRange(new Control[] { cancelar, remoto, local });
        elegir.Controls.Add(detalle); elegir.Controls.Add(opciones);
        DialogResult opcion = elegir.ShowDialog(this);
        if (opcion == DialogResult.Yes)
        {
            ExigirPermisoEdicionProyecto();
            MYGColaboracionLocal.ResolverConflictoMantenerLocal(archivo, documento, vinculoNube);
            estado.Text = "Se conserva el documento local con una operación nueva pendiente de sincronizar.";
        }
        else if (opcion == DialogResult.No)
        {
            if (MessageBox.Show(this, "¿Descartar el borrador local pendiente y usar la revisión remota? Puede guardar una copia local antes de continuar.",
                "Resolver conflicto", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            if (string.IsNullOrWhiteSpace(vinculoNube.JsonPaqueteConflicto))
                documento = MYGColaboracionLocal.ResolverConflictoUsarRemoto(archivo, vinculoNube);
            else
            {
                using var paquete = JsonDocument.Parse(vinculoNube.JsonPaqueteConflicto, new JsonDocumentOptions { MaxDepth = 128 });
                if (paquete.RootElement.TryGetProperty("alcance", out var alcance) && alcance.GetString() == "base")
                {
                    var resultado = SincronizadorProyectoNube.IncorporarBaseConfirmada(archivo, documento, vinculoNube,
                        vinculoNube.RevisionRemotaConflicto, paquete.RootElement);
                    documento = resultado.Documento; vinculoNube = resultado.Vinculo;
                }
                else documento = MYGColaboracionLocal.ResolverConflictoUsarRemoto(archivo, vinculoNube,
                    (conexion, transaccion) => PaqueteNube.AplicarDependencias(paquete.RootElement, conexion, transaccion));
            }
            undo.Clear(); redo.Clear(); estado.Text = "La copia usa la revisión remota confirmada.";
        }
        else return;
        firmaGuardada = MYGProyectoStorage.Firma(documento);
        RecargarVinculoNube(); Refrescar(); ActualizarEstadoNube(); EstadoSesion();
    }
}
