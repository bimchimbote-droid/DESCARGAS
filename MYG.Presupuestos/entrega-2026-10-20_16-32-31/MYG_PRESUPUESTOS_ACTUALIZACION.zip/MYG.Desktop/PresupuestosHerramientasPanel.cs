using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Func<object, int, bool> puedeMoverFila;
    private Action<object, int> moverFila;
    private Action guardarData;
    private readonly List<Image> iconosHerramientas = new();
    private ToolStripButton subirFila, bajarFila, guardarFila;
    private ToolStripButton alternarDetalle, eliminarFila, copiarFila, pegarFila, recalcularFila;
    private Func<bool> herramientasDisponibles, puedePegarFila;
    private Func<string, object, Task> ejecutarAccionEstructura;
    private int anchoEstructuraConDetalle;
    private ToolStrip herramientasEstructura, herramientasACU;
    private ToolStripButton insertarACU, editarACU, eliminarACU, subirACU, bajarACU, guardarACU;
    private TabPage paginaACU;
    private ContextMenuStrip menuACU;
    private string partidaMenuACU, recursoMenuACU;
    private MYGGrupoRecurso? grupoMenuACU;
    private bool mostrarIndiceUnificado;

    internal void InicializarHerramientas(Func<object, int, bool> puedeMover, Action<object, int> mover, Action guardar)
    { puedeMoverFila = puedeMover; moverFila = mover; guardarData = guardar; ActualizarHerramientas(); }

    internal void InicializarAccionesEstructura(Func<bool> disponible, Func<bool> puedePegar,
        Func<string, object, Task> ejecutar)
    {
        herramientasDisponibles = disponible; puedePegarFila = puedePegar;
        ejecutarAccionEstructura = ejecutar; ActualizarHerramientas();
    }

    internal void ActualizarHerramientas()
    {
        if (IsDisposed) return;
        if (subirFila != null)
        {
            object nodo = SeleccionEstructura;
            bool autorizado = autorizarCatalogos?.Invoke() == true;
            bool disponible = herramientasDisponibles?.Invoke() != false;
            foreach (ToolStripItem item in herramientasEstructura.Items)
                if (item is ToolStripButton) item.Enabled = disponible;
            alternarDetalle.Checked = divisionPresupuesto?.Panel2Collapsed == false;
            string ayudaDetalle = alternarDetalle.Checked ? "Ocultar detalle del presupuesto" : "Mostrar detalle del presupuesto";
            alternarDetalle.Text = alternarDetalle.ToolTipText = alternarDetalle.AccessibleName = ayudaDetalle;
            subirFila.Enabled = disponible && autorizado && puedeMoverFila?.Invoke(nodo, -1) == true;
            bajarFila.Enabled = disponible && autorizado && puedeMoverFila?.Invoke(nodo, 1) == true;
            guardarFila.Enabled = disponible && autorizado && guardarData != null && nodo != null;
            eliminarFila.Enabled = disponible && autorizado && nodo != null && ejecutarAccionEstructura != null;
            copiarFila.Enabled = disponible && nodo != null && ejecutarAccionEstructura != null;
            pegarFila.Enabled = disponible && autorizado && ejecutarAccionEstructura != null && puedePegarFila?.Invoke() == true;
            recalcularFila.Enabled = disponible && ejecutarAccionEstructura != null && PresupuestosEstructura.Any();
        }
        ActualizarHerramientasACU();
    }

    private Control PrepararHerramientasEstructura()
    {
        var barra = herramientasEstructura = new ToolStrip { Name = "barraHerramientasEstructura", AccessibleName = "Herramientas centrales del presupuesto", Dock = DockStyle.Right, AutoSize = false, Width = 36, Padding = new(3, 5, 3, 0),
            GripStyle = ToolStripGripStyle.Hidden, LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow,
            BackColor = AzulClaro, ImageScalingSize = new(22, 22), ShowItemToolTips = true };
        Func<Task> Sincrona(Action accion) => () => { accion(); return Task.CompletedTask; };
        ToolStripButton Agregar(string nombre, string icono, string ayuda, Func<Task> accion)
        {
            var imagen = MYGIconosHerramientasPresupuesto.Obtener(icono); iconosHerramientas.Add(imagen);
            var boton = new ToolStripButton { Name = nombre, Image = imagen, Text = ayuda, ToolTipText = ayuda, AccessibleName = ayuda,
                DisplayStyle = ToolStripItemDisplayStyle.Image, AutoSize = false, Width = 29, Height = 32 };
            boton.Click += async (s, e) =>
            {
                if (herramientasDisponibles?.Invoke() == false) return;
                try { FinalizarEdicion(); await accion(); }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "MYG | Presupuestos", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                finally { if (!IsDisposed) ActualizarHerramientas(); }
            };
            barra.Items.Add(boton); return boton;
        }
        Task Ejecutar(string comando) => ejecutarAccionEstructura?.Invoke(comando, SeleccionEstructura) ?? Task.CompletedTask;
        alternarDetalle = Agregar("alternarDetallePresupuesto", "detalle", "Ocultar detalle del presupuesto", Sincrona(AlternarDetallePresupuesto));
        subirFila = Agregar("subirFilaEstructura", "arriba", "Subir presupuesto, título o partida seleccionada", Sincrona(() => { RequerirPermisoCatalogos(); moverFila?.Invoke(SeleccionEstructura, -1); }));
        bajarFila = Agregar("bajarFilaEstructura", "abajo", "Bajar presupuesto, título o partida seleccionada", Sincrona(() => { RequerirPermisoCatalogos(); moverFila?.Invoke(SeleccionEstructura, 1); }));
        barra.Items.Add(new ToolStripSeparator());
        eliminarFila = Agregar("eliminarFilaEstructura", "eliminar", "Eliminar presupuesto, título o partida (con confirmación)", () => Ejecutar("eliminar"));
        copiarFila = Agregar("copiarFilaEstructura", "copiar", "Copiar presupuesto, título o partida", () => Ejecutar("copiar"));
        pegarFila = Agregar("pegarFilaEstructura", "pegar", "Pegar la copia en el presupuesto seleccionado", () => Ejecutar("pegar"));
        recalcularFila = Agregar("recalcularEstructura", "recalcular", "Recalcular el presupuesto y actualizar sus importes", () => Ejecutar("recalcular"));
        Agregar("fuenteEstructura", "fuente", "Fuente y colores de la vista del presupuesto", Sincrona(ElegirFuenteEstructura));
        Agregar("lupaPresupuesto", "vista", "Abrir la lupa de Windows (Win + Esc para cerrarla)", Sincrona(MYGHerramientasSistemaPresupuesto.AbrirLupa));
        Agregar("calculadoraPresupuesto", "calculadora", "Abrir la calculadora de Windows", Sincrona(MYGHerramientasSistemaPresupuesto.AbrirCalculadora));
        guardarFila = Agregar("grabarCostosMultiplesEstructura", "grabar", "Grabar data de costos múltiples", Sincrona(() => { RequerirPermisoCatalogos(); guardarData?.Invoke(); }));
        Load += (s, e) => { EscalarHerramientas(barra); ActualizarHerramientas(); };
        barra.DpiChangedAfterParent += (s, e) => EscalarHerramientas(barra);
        Disposed += (s, e) => { foreach (var icono in iconosHerramientas) icono.Dispose(); menuACU?.Dispose(); };
        return barra;
    }

    private void AlternarDetallePresupuesto()
    {
        if (divisionPresupuesto == null) return;
        if (!divisionPresupuesto.Panel2Collapsed)
        {
            anchoEstructuraConDetalle = divisionPresupuesto.SplitterDistance;
            divisionPresupuesto.Panel2Collapsed = true;
        }
        else
        {
            divisionPresupuesto.Panel2Collapsed = false;
            int maximo = divisionPresupuesto.ClientSize.Width - divisionPresupuesto.Panel2MinSize - divisionPresupuesto.SplitterWidth;
            if (maximo >= divisionPresupuesto.Panel1MinSize)
                divisionPresupuesto.SplitterDistance = Math.Clamp(anchoEstructuraConDetalle > 0 ? anchoEstructuraConDetalle : divisionPresupuesto.Width / 2,
                    divisionPresupuesto.Panel1MinSize, maximo);
        }
    }

    private Control PrepararHerramientasACU()
    {
        herramientasACU = new ToolStrip { Name = "barraHerramientasACU", AccessibleName = "Herramientas del análisis de costo unitario",
            Dock = DockStyle.Right, AutoSize = false, Width = 36, Padding = new(3, 5, 3, 0),
            GripStyle = ToolStripGripStyle.Hidden, LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow,
            BackColor = AzulClaro, ImageScalingSize = new(22, 22), ShowItemToolTips = true, Visible = false };
        ToolStripButton Agregar(string nombre, string icono, string ayuda, Action accion, bool modifica = true)
        {
            var imagen = MYGIconos.Obtener(icono); iconosHerramientas.Add(imagen);
            var boton = new ToolStripButton { Name = nombre, Image = imagen, Text = ayuda, ToolTipText = ayuda,
                AccessibleName = ayuda, Tag = modifica, DisplayStyle = ToolStripItemDisplayStyle.Image,
                AutoSize = false, Width = 29, Height = 32 };
            boton.Click += (s, e) => Intentar(() => EjecutarHerramientaACU(accion, modifica));
            herramientasACU.Items.Add(boton); return boton;
        }
        Agregar("recalcularACU", "recalcular", "Recalcular el ACU", () => { CargarACU(); ActualizarCalculos(); }, false);
        insertarACU = Agregar("insertarRecursoACU", "insertar_final", "Insertar insumo en el grupo seleccionado",
            () => AgregarRecurso(false, grupoInicial: grupoMenuACU));
        editarACU = Agregar("editarRecursoACU", "editar", "Editar y reemplazar el insumo seleccionado", EditarReemplazarRecurso);
        eliminarACU = Agregar("eliminarRecursoACU", "eliminar", "Eliminar el insumo seleccionado", EliminarRecursoMenuACU);
        subirACU = Agregar("subirRecursoACU", "arriba", "Subir insumo dentro de su grupo", () => MoverSeleccionACU(-1));
        bajarACU = Agregar("bajarRecursoACU", "abajo", "Bajar insumo dentro de su grupo", () => MoverSeleccionACU(1));
        herramientasACU.Items.Add(new ToolStripSeparator());
        guardarACU = Agregar("grabarDataACU", "guardar", "Grabar data del ACU en el catálogo de partidas", GuardarPartidaEnCatalogo);
        Agregar("exportarACU", "excel", "Exportar el ACU a Excel", ExportarACU, false);
        // Cambiar botones visibles modifica el diseño del panel. Esperar a que
        // DataGridView termine de mover la celda y retirar el editor anterior.
        acu.SelectionChanged += (s, e) =>
        {
            if (!cargando) refrescoDiferidoACU.Solicitar(MYGTipoRefresco.Herramientas);
        };
        acu.CurrentCellChanged += (s, e) =>
        {
            if (!cargando) refrescoDiferidoACU.Solicitar(MYGTipoRefresco.Herramientas);
        };
        Load += (s, e) => { EscalarHerramientas(herramientasACU); ActualizarHerramientasACU(); };
        herramientasACU.DpiChangedAfterParent += (s, e) => EscalarHerramientas(herramientasACU);
        return herramientasACU;
    }

    private void ActualizarHerramientasACU()
    {
        if (herramientasACU == null || IsDisposed) return;
        var fila = acu.CurrentRow;
        bool seleccionValida = HayPartida && fila?.Selected == true && fila.Tag is MYGGrupoRecurso or MYGRecursoACU;
        herramientasACU.Visible = seleccionValida && vistaSeleccionada == principal && detalle.SelectedTab == paginaACU;
        var recurso = fila?.Tag as MYGRecursoACU;
        MYGGrupoRecurso? titulo = fila?.Tag is MYGGrupoRecurso grupo ? grupo : null;
        bool autorizado = EdicionACUNubePermitida && autorizarCatalogos?.Invoke() == true;
        foreach (ToolStripItem boton in herramientasACU.Items)
            if (boton is ToolStripButton) boton.Enabled = seleccionValida && (boton.Tag is not true || autorizado);
        editarACU.Visible = eliminarACU.Visible = seleccionValida && recurso != null;
        editarACU.Enabled = eliminarACU.Enabled = autorizado && seleccionValida && recurso != null;
        bool PuedeMover(int sentido) => seleccionValida && (recurso != null
            ? MYGOrdenPresupuestos.PuedeMoverRecurso(P, actual, recurso, sentido)
            : titulo.HasValue && MYGOrdenPresupuestos.PuedeMoverGrupo(P, actual, titulo.Value, sentido));
        bool puedeSubir = PuedeMover(-1), puedeBajar = PuedeMover(1);
        subirACU.Visible = puedeSubir; subirACU.Enabled = autorizado && puedeSubir;
        bajarACU.Visible = puedeBajar; bajarACU.Enabled = autorizado && puedeBajar;
        string ayudaSubir = titulo.HasValue ? "Subir el título con todos sus insumos" : "Subir insumo dentro de su grupo";
        string ayudaBajar = titulo.HasValue ? "Bajar el título con todos sus insumos" : "Bajar insumo dentro de su grupo";
        subirACU.Text = subirACU.ToolTipText = subirACU.AccessibleName = ayudaSubir;
        bajarACU.Text = bajarACU.ToolTipText = bajarACU.AccessibleName = ayudaBajar;
    }

    private void EjecutarHerramientaACU(Action accion, bool modifica)
    {
        RequerirPartida();
        var fila = acu.CurrentRow;
        if (fila?.Selected != true || fila.Tag is not (MYGGrupoRecurso or MYGRecursoACU))
            throw new InvalidOperationException("Seleccione un título o un insumo del ACU.");
        // Finalizar una edición puede reconstruir las filas; conservar sus identidades.
        string partidaId = actual.Id, recursoId = (fila.Tag as MYGRecursoACU)?.Id;
        var grupo = fila.Tag is MYGGrupoRecurso titulo ? titulo : ((MYGRecursoACU)fila.Tag).Grupo;
        try
        {
            if (modifica) { ExigirPermisoACU(); RequerirPermisoCatalogos(); }
            FinalizarEdicion(); RequerirPartida();
            if (actual.Id != partidaId) throw new InvalidOperationException("Seleccione nuevamente la partida para usar las herramientas de su ACU.");
            actual = P.Items.FirstOrDefault(x => x.Id == partidaId)
                ?? throw new InvalidOperationException("La partida seleccionada ya no está en el presupuesto.");
            var seleccionada = acu.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => recursoId != null
                ? r.Tag is MYGRecursoACU recurso && recurso.Id == recursoId
                : r.Tag is MYGGrupoRecurso tituloGrupo && tituloGrupo == grupo);
            if (seleccionada == null) throw new InvalidOperationException("Seleccione nuevamente el título o insumo del ACU.");
            acu.CurrentCell = seleccionada.Cells["DESC"]; seleccionada.Selected = true;
            partidaMenuACU = partidaId; recursoMenuACU = recursoId; grupoMenuACU = grupo;
            if (modifica) { ExigirPermisoACU(); RequerirPermisoCatalogos(); }
            accion();
        }
        finally { ActualizarHerramientas(); }
    }

    private void EscalarHerramientas(ToolStrip barra)
    {
        float escala = DeviceDpi / 96F;
        barra.Width = (int)(36 * escala); barra.Padding = new((int)(3 * escala), (int)(5 * escala), (int)(3 * escala), 0);
        barra.ImageScalingSize = new((int)(22 * escala), (int)(22 * escala));
        foreach (ToolStripItem item in barra.Items)
            if (item is ToolStripButton) item.Size = new((int)(29 * escala), (int)(32 * escala));
    }

    private void AplicarTemaHerramientas()
    {
        foreach (var barra in new[] { herramientasEstructura, herramientasACU })
            if (barra != null) { barra.BackColor = AzulClaro; barra.ForeColor = MYG2027_TemaComercial.Texto; }
    }

    private void PrepararMenuACU()
    {
        menuACU = new ContextMenuStrip { ImageScalingSize = new(20, 20), ShowImageMargin = true };
        acu.ContextMenuStrip = menuACU;
        ToolStripMenuItem Accion(string texto, string icono, Action accion, bool modifica = true, ToolStripItemCollection destino = null)
        {
            var imagen = MYGIconos.Obtener(icono); iconosHerramientas.Add(imagen);
            var item = new ToolStripMenuItem(texto) { Tag = modifica, Image = imagen };
            item.Click += (s, e) =>
            {
                string partidaId = partidaMenuACU, recursoId = recursoMenuACU;
                var grupo = grupoMenuACU;
                if (IsDisposed || !IsHandleCreated) return;
                BeginInvoke(new Action(() => Intentar(() =>
                {
                    FinalizarEdicion(); RequerirPartida();
                    if (actual.Id != partidaId) throw new InvalidOperationException("Seleccione nuevamente la partida para usar su menú de ACU.");
                    recursoMenuACU = recursoId; grupoMenuACU = grupo;
                    if (modifica) { ExigirPermisoACU(); RequerirPermisoCatalogos(); }
                    accion();
                })));
            };
            (destino ?? menuACU.Items).Add(item); return item;
        }
        var insertarSobre = Accion("Insertar insumo arriba", "insertar_sobre", () => InsertarRecursoMenuACU(false));
        var insertarDebajo = Accion("Insertar insumo abajo", "insertar_final", () => InsertarRecursoMenuACU(true));
        var insertar = Accion("Insertar insumo", "insertar_final", () => AgregarRecurso(false, grupoInicial: grupoMenuACU));
        var subpartida = Accion("Insertar subpartida", "acu", AgregarSubpartida);
        var eliminar = Accion("Eliminar", "eliminar", EliminarRecursoMenuACU);
        Accion("Recalcular", "recalcular", () => { CargarACU(); ActualizarCalculos(); }, false);
        var codigo = Accion("Mostrar código estándar", "codigo_estandar", () => SeleccionarIdentificacionACU(false), false);
        var indiceUnificado = Accion("Mostrar índice unificado", "codigo_alterno", () => SeleccionarIdentificacionACU(true), false);
        Accion("Exportar a Excel", "excel", ExportarACU, false);
        var separadorRecurso = new ToolStripSeparator();
        menuACU.Items.Add(separadorRecurso);
        var editar = Accion("Editar y reemplazar insumo…", "editar", EditarReemplazarRecurso);
        var iconoCalculo = MYGIconos.Obtener("recalcular"); iconosHerramientas.Add(iconoCalculo);
        var calculo = new ToolStripMenuItem("Cálculo del recurso") { Name = "calculoRecursoACU", Tag = true, Image = iconoCalculo };
        menuACU.Items.Add(calculo);
        var cantidadDirecta = Accion("Cantidad directa", "recalcular", () => CambiarCalculoRecursoMenuACU(MYGModoCantidad.Directa), destino: calculo.DropDownItems);
        var porRendimiento = Accion("Por rendimiento", "recalcular", () => CambiarCalculoRecursoMenuACU(MYGModoCantidad.Rendimiento), destino: calculo.DropDownItems);
        var porcentajeManoObra = Accion("% de mano de obra", "recalcular", () => CambiarCalculoRecursoMenuACU(MYGModoCantidad.PorcentajeManoObra), destino: calculo.DropDownItems);
        var subir = Accion("Subir recurso", "arriba", () => MoverRecursoMenuACU(-1));
        var bajar = Accion("Bajar recurso", "abajo", () => MoverRecursoMenuACU(1));
        var separadorCatalogos = new ToolStripSeparator();
        menuACU.Items.Add(separadorCatalogos);
        var catalogo = Accion("Catálogo de insumos", "catalogo", InsumoCatalogoAlACU);
        var guardarPartida = Accion("Guardar partida en catálogo", "guardar", GuardarPartidaEnCatalogo);
        acu.MouseDown += (s, e) =>
        {
            if (e.Button != MouseButtons.Right) return;
            Intentar(() =>
            {
                FinalizarEdicion(); var hit = acu.HitTest(e.X, e.Y); acu.ClearSelection();
                if (hit.RowIndex >= 0) { acu.CurrentCell = acu.Rows[hit.RowIndex].Cells["DESC"]; acu.Rows[hit.RowIndex].Selected = true; }
                else acu.CurrentCell = null;
            });
        };
        menuACU.Opening += (s, e) =>
        {
            if (!HayPartida || acu.IsCurrentCellInEditMode || acu.CurrentRow?.Tag is not (MYGGrupoRecurso or MYGRecursoACU)) { e.Cancel = true; return; }
            int ladoIcono = Math.Max(20, (int)Math.Round(20F * DeviceDpi / 96F));
            menuACU.ImageScalingSize = new(ladoIcono, ladoIcono);
            calculo.DropDown.ImageScalingSize = menuACU.ImageScalingSize;
            partidaMenuACU = actual.Id; recursoMenuACU = (acu.CurrentRow?.Tag as MYGRecursoACU)?.Id;
            grupoMenuACU = acu.CurrentRow.Tag is MYGGrupoRecurso grupo ? grupo : (acu.CurrentRow.Tag as MYGRecursoACU)?.Grupo;
            bool esTituloGrupo = acu.CurrentRow.Tag is MYGGrupoRecurso;
            insertar.Visible = esTituloGrupo;
            foreach (var opcion in new ToolStripItem[] { insertarSobre, insertarDebajo, subpartida, eliminar, editar, calculo, subir, bajar,
                catalogo, guardarPartida, separadorRecurso, separadorCatalogos })
                opcion.Visible = !esTituloGrupo;
            bool autorizado = EdicionACUNubePermitida && autorizarCatalogos?.Invoke() == true;
            void Permisos(ToolStripItemCollection opciones)
            {
                foreach (ToolStripItem item in opciones)
                    if (item is ToolStripMenuItem opcion)
                    {
                        opcion.Enabled = item.Tag is not true || autorizado;
                        Permisos(opcion.DropDownItems);
                    }
            }
            Permisos(menuACU.Items);
            var recurso = RecursoMenuACU();
            insertarSobre.Enabled = insertarDebajo.Enabled = autorizado && recurso != null;
            eliminar.Enabled = autorizado && recurso != null;
            editar.Enabled = autorizado && recurso != null;
            bool porUnidad = MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(recurso,
                P.Costos.Insumos.FirstOrDefault(x => x.Id == recurso?.InsumoId)?.Unidad);
            calculo.Enabled = autorizado && recurso != null;
            cantidadDirecta.Enabled = autorizado && recurso != null && !porUnidad;
            porRendimiento.Enabled = autorizado && porUnidad;
            porcentajeManoObra.Enabled = autorizado && recurso?.Grupo == MYGGrupoRecurso.Equipo;
            cantidadDirecta.Checked = recurso?.Modo == MYGModoCantidad.Directa && !(recurso.CalcularCantidadPorUnidad && porUnidad);
            porRendimiento.Checked = recurso?.Modo == MYGModoCantidad.Rendimiento || recurso?.CalcularCantidadPorUnidad == true && porUnidad;
            porcentajeManoObra.Checked = recurso?.Modo == MYGModoCantidad.PorcentajeManoObra;
            subir.Enabled = autorizado && recurso != null && MYGOrdenPresupuestos.PuedeMoverRecurso(P, actual, recurso, -1);
            bajar.Enabled = autorizado && recurso != null && MYGOrdenPresupuestos.PuedeMoverRecurso(P, actual, recurso, 1);
            codigo.Checked = !mostrarIndiceUnificado; indiceUnificado.Checked = mostrarIndiceUnificado;
        };
    }

    private void SeleccionarIdentificacionACU(bool indice)
    {
        mostrarIndiceUnificado = indice;
        ActualizarIdentificacionACU();
    }

    private void ActualizarIdentificacionACU()
    {
        if (acu.Columns.Contains("COD"))
        {
            acu.Columns["COD"].Visible = !mostrarIndiceUnificado;
            acu.Columns["COD"].HeaderText = "Cód. estándar";
        }
        if (acu.Columns.Contains("INDICE")) acu.Columns["INDICE"].Visible = mostrarIndiceUnificado;
    }

    private MYGRecursoACU RecursoMenuACU() => actual?.Costos.Analisis.FirstOrDefault(r => r.Id == recursoMenuACU);
    private void CambiarCalculoRecursoMenuACU(MYGModoCantidad modo)
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); RequerirPartida();
        actual = PartidaActual ?? throw new InvalidOperationException("La partida seleccionada ya no está en el presupuesto.");
        var recurso = RecursoMenuACU() ?? throw new InvalidOperationException("Seleccione un insumo del ACU.");
        string unidad = P.Costos.Insumos.FirstOrDefault(x => x.Id == recurso.InsumoId)?.Unidad;
        bool porUnidad = MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(recurso, unidad);
        if (modo == MYGModoCantidad.Rendimiento && !porUnidad)
            throw new InvalidOperationException("Nro. Rec. se calcula sólo para unidades he, hh y hm.");
        bool activar = modo == MYGModoCantidad.Rendimiento && porUnidad;
        if (recurso.Modo == modo && recurso.CalcularCantidadPorUnidad == activar) return;
        var prueba = MYGProyectoStorage.Copia(P);
        var recursoPrueba = prueba.Items.Single(i => i.Id == actual.Id).Costos.Analisis.Single(r => r.Id == recurso.Id);
        recursoPrueba.Modo = modo; recursoPrueba.CalcularCantidadPorUnidad = activar;
        MYGMotorPresupuestos.Validar(prueba);
        var anterior = recurso.Modo;
        bool reglaAnterior = recurso.CalcularCantidadPorUnidad;
        antes();
        try
        {
            // Cambiar la forma de cálculo conserva las cantidades introducidas.
            recurso.Modo = modo;
            recurso.CalcularCantidadPorUnidad = activar;
            MYGMotorPresupuestos.Validar(P);
        }
        catch
        {
            recurso.Modo = anterior;
            recurso.CalcularCantidadPorUnidad = reglaAnterior;
            CargarACU(); SeleccionarRecursoACU(recurso.Id);
            throw;
        }
        CargarACU(); SeleccionarRecursoACU(recurso.Id); Cambiado();
    }
    private void InsertarRecursoMenuACU(bool debajo)
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion(); RequerirPartida();
        var recurso = RecursoMenuACU();
        if (recurso == null) throw new InvalidOperationException("Seleccione un insumo del ACU.");
        string partidaId = actual.Id;
        var grupo = recurso.Grupo;
        var recursosGrupo = actual.Costos.Analisis.Where(r => r.Grupo == grupo).ToList();
        // Insertar antes del siguiente recurso coloca la nueva fila justo debajo.
        // Sin siguiente recurso, se añade al final del mismo grupo visual.
        string insertarAntesId = debajo
            ? recursosGrupo.Skip(recursosGrupo.IndexOf(recurso) + 1).FirstOrDefault()?.Id
            : recurso.Id;
        // Abrir el selector no registra insumos ajenos a esta inserción.
        string ruta = RutaCatalogos(); var unidades = MYGCatalogoUnidades.Listar(ruta);
        actual = P.Items.First(x => x.Id == partidaId);
        using var f = new MYGSelectorInsumoForm(P, actual, null, unidades, ruta, grupo);
        if (grupo == MYGGrupoRecurso.Subpartidas) f.MostrarCompuesto();
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        var gruposSeleccionados = f.Selecciones.Select(s => !string.IsNullOrWhiteSpace(s.SubpartidaIdLocal)
            ? MYGGrupoRecurso.Subpartidas
            : s.NuevoInsumo?.Grupo ?? P.Costos.Insumos.First(x => x.Id == s.InsumoId).Grupo);
        if (gruposSeleccionados.Any(g => g != grupo))
            throw new InvalidOperationException("Para insertar arriba o abajo seleccione un insumo del grupo " + MYGMotorPresupuestos.Grupo(grupo) + ".");
        var nuevos = AplicarInsumosAlACU(ruta, partidaId, f.Selecciones, insertarAntesId);
        Refrescar(); SeleccionarRecursoACU(nuevos[0].Id); despues();
    }
    private void MoverRecursoMenuACU(int sentido)
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); RequerirPartida();
        var recurso = RecursoMenuACU(); if (recurso == null || !MYGOrdenPresupuestos.PuedeMoverRecurso(P, actual, recurso, sentido)) return;
        var prueba = MYGProyectoStorage.Copia(P); var copia = prueba.Items.Single(i => i.Id == actual.Id);
        MYGOrdenPresupuestos.ReordenarRecursoACU(prueba, copia, copia.Costos.Analisis.Single(r => r.Id == recurso.Id), sentido);
        antes(); MYGOrdenPresupuestos.ReordenarRecursoACU(P, actual, recurso, sentido); CargarACU(); SeleccionarRecursoACU(recurso.Id); Cambiado();
    }
    private void MoverSeleccionACU(int sentido)
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); RequerirPartida();
        if (recursoMenuACU != null) { MoverRecursoMenuACU(sentido); return; }
        if (!grupoMenuACU.HasValue || !MYGOrdenPresupuestos.PuedeMoverGrupo(P, actual, grupoMenuACU.Value, sentido)) return;
        var grupo = grupoMenuACU.Value;
        var prueba = MYGProyectoStorage.Copia(P); var copia = prueba.Items.Single(i => i.Id == actual.Id);
        MYGOrdenPresupuestos.ReordenarGrupoACU(prueba, copia, grupo, sentido);
        antes(); MYGOrdenPresupuestos.ReordenarGrupoACU(P, actual, grupo, sentido); CargarACU(); Cambiado();
    }
    private void EliminarRecursoMenuACU()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); RequerirPartida();
        var recurso = RecursoMenuACU(); if (recurso == null) return;
        antes(); actual.Costos.Analisis.Remove(recurso); CargarACU(); Cambiado();
    }
    private void ExportarACU()
    {
        RequerirPartida(); FinalizarEdicion();
        using var dialogo = new SaveFileDialog { Filter = "Libro Excel (*.xlsx)|*.xlsx", FileName = "ACU_" + actual.Item + ".xlsx" };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        var proyecto = ProyectoParaExportacionExcel();
        var reporte = MYGReportesProyecto.CrearAnalisis(proyecto, P.Id, actual.Id);
        MYGExcelPresupuestos.Guardar(dialogo.FileName, MYGReportesExcel.CrearHojas(new[] { reporte }));
    }
}
