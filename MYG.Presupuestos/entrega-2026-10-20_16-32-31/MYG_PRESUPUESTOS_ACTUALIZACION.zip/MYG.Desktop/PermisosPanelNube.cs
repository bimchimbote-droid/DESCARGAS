using System;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Func<bool> permisoEdicionNube;
    private Func<MYGPermisosModulos> permisosModulosNube;
    internal bool EdicionNubePermitida => permisoEdicionNube?.Invoke() != false;
    internal bool EdicionACUNubePermitida => EdicionNubePermitida && permisosModulosNube?.Invoke()?.Acu != false;
    internal bool EdicionEspecificacionesNubePermitida => EdicionNubePermitida && permisosModulosNube?.Invoke()?.Especificaciones != false;
    internal bool EdicionMetradosExcelNubePermitida => EdicionNubePermitida && permisosModulosNube?.Invoke()?.MetradosExcel != false;

    internal void ConfigurarPermisoNube(Func<bool> permiso, Func<MYGPermisosModulos> permisosModulos = null)
    {
        permisoEdicionNube = permiso;
        permisosModulosNube = permisosModulos;
        if (editorEspecificaciones != null)
            editorEspecificaciones.PermisoEdicionNube = () => EdicionEspecificacionesNubePermitida;
        ActualizarPermisoNube();
    }

    private void ExigirPermisoACU()
    {
        if (!EdicionACUNubePermitida) throw new InvalidOperationException("El análisis de costos unitarios está disponible solo para lectura.");
    }

    private void ExigirPermisoMetradosExcel()
    {
        if (!EdicionMetradosExcelNubePermitida) throw new InvalidOperationException("Los metrados Excel están disponibles solo para lectura.");
    }

    private void ExigirPermisosPartidaCompleta()
    {
        ExigirPermisoACU();
        ExigirPermisoMetradosExcel();
        if (!EdicionEspecificacionesNubePermitida) throw new InvalidOperationException("Las especificaciones técnicas están disponibles solo para lectura.");
    }

    internal void ActualizarPermisoNube()
    {
        if (IsDisposed || Disposing) return;
        bool permite = EdicionNubePermitida;
        bool permiteACU = EdicionACUNubePermitida, permiteExcel = EdicionMetradosExcelNubePermitida;
        bool previo = cargando;
        cargando = true;
        try
        {
            // Cancelar únicamente los editores bloqueados; conservar la navegación y selección.
            if (!permite) { estructura.CancelEdit(); tablaPie.CancelEdit(); }
            if (!permiteACU) acu.CancelEdit();
            if (!permiteExcel)
            {
                hoja.CancelEdit(); formulaPendienteHoja = false;
                CancelarArrastreHoja(); CerrarAutocompletadoHoja();
            }
            estructura.ReadOnly = tablaPie.ReadOnly = !permite;
            acu.ReadOnly = !permiteACU;
            hoja.ReadOnly = formula.ReadOnly = !permiteExcel || EligiendoReferenciaPartidaHoja;
            celdaTotal.ReadOnly = !permiteExcel;
            especificacion.ReadOnly = !EdicionEspecificacionesNubePermitida || !HayPartida;
            fuente.Enabled = permiteExcel && HayPartida;
            rendimiento.Enabled = jornada.Enabled = permiteACU && HayPartida;
            precioDirecto.Enabled = permiteACU && HayPartida && PartidaActual?.Costos.Analisis.Count == 0;
            bool formaDisponible = permiteACU && HayPartida && obtenerProyectoEstructura?.Invoke()?.Datos != null;
            porRendimientoACU.Enabled = porAsignacionACU.Enabled = formaDisponible;
            if (botonReferenciaPartidaHoja != null)
                botonReferenciaPartidaHoja.Enabled = permiteExcel && HayPartida;
            ActualizarHerramientasACU(); ActualizarPermisosComandosHoja();
            editorEspecificaciones?.ActualizarPermisoNube();
        }
        finally { cargando = previo; }
    }
}

internal sealed partial class MYGEspecificacionesEditor
{
    internal Func<bool> PermisoEdicionNube;
    private bool EdicionNubePermitida => PermisoEdicionNube?.Invoke() != false;

    internal void ActualizarPermisoNube()
    {
        if (IsDisposed || Disposing) return;
        bool permite = EdicionNubePermitida && !string.IsNullOrEmpty(identidad);
        if (!permite) CancelarArrastreMargenes();
        documento.ReadOnly = !permite;
        insertarTitulo.Enabled = permite;
        regla.EdicionHabilitada = reglaVertical.EdicionHabilitada = permite && !borrador;
    }
}
