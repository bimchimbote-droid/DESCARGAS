#nullable enable
using System;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Configura edición; la lectura y descarga continúan permitidas.</summary>
internal sealed class PermisosModulosNubeForm : Form
{
    private readonly ComboBox rol = new() { Name = "rolNuevoColaboradorMyg", DropDownStyle = ComboBoxStyle.DropDownList, Width = 210 };
    private readonly CheckBox acu = new() { Name = "permisoEditarAcu", Text = "Editar ACU", AutoSize = true };
    private readonly CheckBox especificaciones = new() { Name = "permisoEditarEspecificaciones", Text = "Editar Especificaciones Técnicas", AutoSize = true };
    private readonly CheckBox metrados = new() { Name = "permisoEditarMetradosExcel", Text = "Editar Metrados Excel", AutoSize = true };

    internal string Rol => rol.SelectedItem as string ?? "lector";
    internal MYGPermisosModulos Permisos => new()
    {
        Acu = Rol != "lector" && acu.Checked,
        Especificaciones = Rol != "lector" && especificaciones.Checked,
        MetradosExcel = Rol != "lector" && metrados.Checked
    };

    internal PermisosModulosNubeForm(string usuario, MYGPermisosModulos? permisos,
        bool permitirRol, string rolActual = "lector")
    {
        Name = "permisosModulosColaboradorMyg";
        MYGProyectoUI.Preparar(this, permitirRol ? "Agregar colaborador MYG" : "Permisos por módulo", 560, 360);
        MinimumSize = new(480, 340);
        var contenido = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 7, Padding = new(18) };
        contenido.ColumnStyles.Add(new(SizeType.Percent, 100));
        foreach (int alto in new[] { 32, 42, 32, 32, 32, 0, 42 })
            contenido.RowStyles.Add(alto == 0 ? new(SizeType.Percent, 100) : new(SizeType.Absolute, alto));
        contenido.Controls.Add(new Label { Text = "Usuario MYG: " + usuario, Dock = DockStyle.Fill, AutoEllipsis = true }, 0, 0);
        rol.Items.AddRange(new object[] { "lector", "editor", "administrador" });
        rol.SelectedItem = rolActual;
        rol.Enabled = permitirRol;
        contenido.Controls.Add(rol, 0, 1);
        acu.Checked = permisos?.Acu ?? true;
        especificaciones.Checked = permisos?.Especificaciones ?? true;
        metrados.Checked = permisos?.MetradosExcel ?? true;
        contenido.Controls.Add(acu, 0, 2);
        contenido.Controls.Add(especificaciones, 0, 3);
        contenido.Controls.Add(metrados, 0, 4);
        contenido.Controls.Add(new Label { Dock = DockStyle.Fill, Text = "Sin marcar: visible y en solo lectura. El rol lector no permite editar ningún módulo. Los cambios se aplican cuando el servidor los confirma." }, 0, 5);
        var botones = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        var aceptar = MYGProyectoUI.Boton("Confirmar"); aceptar.DialogResult = DialogResult.OK;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        botones.Controls.Add(aceptar); botones.Controls.Add(cancelar);
        contenido.Controls.Add(botones, 0, 6); Controls.Add(contenido);
        AcceptButton = aceptar; CancelButton = cancelar;
        void Actualizar() => acu.Enabled = especificaciones.Enabled = metrados.Enabled = Rol != "lector";
        rol.SelectedIndexChanged += (_, _) => Actualizar(); Actualizar();
    }
}
