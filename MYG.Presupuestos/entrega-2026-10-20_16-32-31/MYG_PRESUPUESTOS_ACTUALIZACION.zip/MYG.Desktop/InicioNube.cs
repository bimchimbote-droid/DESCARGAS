#nullable enable
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private ClienteSupabase? clienteNube;
    private NubeForm? ventanaNube;
    private bool clienteNubePreparado;
    private ConfiguracionNube? configuracionNube;
    private string? usuarioNube;
    private long generacionNube;
    private readonly System.Threading.SemaphoreSlim ingresoNube = new(1, 1);
    private static string CarpetaNube => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "trabajo");

    private void MostrarNube()
    {
        RequerirSesion();
        if (!clienteNubePreparado)
        {
            configuracionNube = NubeConfiguracion.Cargar();
            clienteNubePreparado = true;
        }
        ActualizarSesionNube();
        bool nuevaVentana = ventanaNube is null || ventanaNube.IsDisposed;
        if (nuevaVentana)
        {
            ventanaNube = new NubeForm(sesion, clienteNube);
            ventanaNube.ConfiguracionSolicitada += ConfigurarConexionNube;
            ventanaNube.AbrirSolicitado += AbrirProyectoNube;
            ventanaNube.PublicarSolicitado += PublicarProyectoNube;
            ventanaNube.DescargarSolicitado += DescargarProyectoNube;
            ventanaNube.ConectarMygSolicitado += ConectarNubeConMygAsync;
        }
        ventanaNube!.Show(this); ventanaNube.Activate();
        if (!nuevaVentana) _ = ventanaNube.ConectarYRefrescarAsync();
    }

    private void ConfigurarConexionNube()
    {
        if (EditoresAbiertos.Any(e => e.OperacionEnCurso))
            throw new InvalidOperationException("Espere a que terminen las operaciones antes de cambiar la conexión.");
        var configuracion = NubeConfiguracion.Editar(ventanaNube ?? (WinForms.IWin32Window)this);
        if (configuracion is null) return;
        var nuevo = configuracion.CrearCliente();
        configuracionNube = configuracion;
        generacionNube++;
        usuarioNube = UsuarioMygActual;
        var anterior = clienteNube; clienteNube = nuevo; anterior?.Dispose();
        clienteNubePreparado = true;
        ventanaNube?.ActualizarCliente(clienteNube);
        foreach (var editor in EditoresAbiertos) editor.ConfigurarNube(() => clienteNube, MostrarNube);
        if (ventanaNube is not null) _ = ventanaNube.ConectarYRefrescarAsync();
    }

    private string? UsuarioMygActual => sesion.Autorizado
        ? sesion.Credencial?.Usuario?.Trim().ToLowerInvariant() : null;

    private void ActualizarSesionNube()
    {
        if (!clienteNubePreparado) return;
        string? usuario = UsuarioMygActual;
        if (usuario == usuarioNube && (clienteNube is not null || configuracionNube is null || usuario is null)) return;
        generacionNube++;
        var anterior = clienteNube;
        clienteNube = usuario is not null ? configuracionNube?.CrearCliente() : null;
        usuarioNube = usuario;
        // Cancelar y eliminar solo la sesión local anterior; nunca cerrar otras computadoras.
        anterior?.Dispose();
        ventanaNube?.ActualizarCliente(clienteNube);
    }

    private async Task ConectarNubeConMygAsync()
    {
        await ingresoNube.WaitAsync();
        try
        {
            if (IsDisposed || Disposing) return;
            RequerirSesion(); ActualizarSesionNube();
            var cliente = clienteNube ?? throw new InvalidOperationException("Configure primero la URL y la clave publicable de Nube MYG.");
            string usuario = UsuarioMygActual ?? throw new InvalidOperationException("Inicie sesión en MYG.");
            if (cliente.SesionIniciada && cliente.UsuarioMygSesion == usuario) return;
            long generacion = generacionNube;
            var resultado = await sesion.ObtenerTicketNubeAsync(cliente.UrlServidor);
            if (!resultado.Ok || resultado.Ticket is null) throw new InvalidOperationException(resultado.Mensaje);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            await cliente.IniciarSesionMygAsync(resultado.Ticket);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
            {
                cliente.Dispose();
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            }
            ventanaNube?.ActualizarCliente(cliente);
        }
        finally { ingresoNube.Release(); }
    }

    private void ComprobarClienteActual(ClienteSupabase cliente)
    {
        RequerirSesion();
        if (!ReferenceEquals(clienteNube, cliente) || !cliente.SesionIniciada || cliente.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Cambió la sesión MYG durante la operación. Vuelva a abrir Nube MYG.");
    }

    private ClienteSupabase RequerirNube()
    {
        RequerirSesion();
        if (clienteNube?.SesionIniciada != true || clienteNube.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Abra Nube MYG para conectar con su usuario MYG actual.");
        return clienteNube;
    }

    private static string CarpetaDeProyectoNube(ClienteSupabase cliente, Guid proyecto)
    {
        string servidor = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(cliente.UrlServidor)))[..24];
        if (!Guid.TryParse(cliente.UsuarioId, out var usuario)) throw new InvalidOperationException("La identidad de nube no es válida.");
        return Path.Combine(CarpetaNube, servidor, usuario.ToString("N"), proyecto.ToString("N"));
    }

    private async Task AbrirProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        var remoto = await cliente.AbrirProyectoAsync(seleccionado.Id);
        remoto = remoto with { Contenido = await cliente.CargarArchivosAsync(remoto.Contenido) };
        ComprobarClienteActual(cliente);
        var existente = EditoresAbiertos.FirstOrDefault(e => e.NubeProyectoId == remoto.Id
            && string.Equals(e.NubeServidor?.TrimEnd('/'), cliente.UrlServidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase)
            && e.NubeUsuario == cliente.UsuarioId);
        if (existente is not null)
        {
            await existente.ActualizarNubeAsync(true);
            ComprobarClienteActual(cliente);
            SeleccionarEditor(existente); ventanaNube?.Hide(); return;
        }
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Id);
        string ruta = Path.Combine(carpeta, "trabajo.sqlite");
        var original = PaqueteNube.LeerDocumento(remoto.Contenido);
        MYGProyectoDocumento documento;
        if (File.Exists(ruta))
        {
            documento = MYGBaseDatos.LeerProyecto(ruta, original.Id);
            var vinculo = MYGColaboracionLocal.Leer(ruta, documento.Id)
                ?? throw new InvalidOperationException("La copia existente no tiene un vínculo válido. Consérvela antes de recuperar otra copia.");
            SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
            if (vinculo.ProyectoId != remoto.Id) throw new InvalidOperationException("La copia corresponde a otro proyecto remoto.");
            SincronizadorProyectoNube.ActualizarPermisos(vinculo, remoto);
            MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        }
        else
        {
            Directory.CreateDirectory(carpeta);
            string preparacion = Path.Combine(carpeta, "preparando-" + Guid.NewGuid().ToString("N") + ".sqlite");
            PaqueteNube.Descargar(remoto.Contenido, preparacion);
            documento = MYGBaseDatos.LeerProyecto(preparacion, original.Id);
            MYGColaboracionLocal.Vincular(preparacion, documento, new MYGVinculoNube
            {
                ProyectoId = remoto.Id, Servidor = cliente.UrlServidor, UsuarioId = cliente.UsuarioId!,
                Revision = remoto.Revision, Rol = remoto.Rol, PermisosModulos = remoto.PermisosModulos?.Copiar(),
                JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento),
                JsonPaqueteConfirmado = remoto.Contenido.GetRawText()
            });
            File.Move(preparacion, ruta);
        }
        RequerirSesion();
        var editor = AbrirEditor(documento, ruta);
        editor.ConfigurarNube(() => clienteNube, MostrarNube);
        ventanaNube?.Hide();
        // La copia recuperada conserva borradores: actualizar explícitamente desde su barra.
    }

    private async Task PublicarProyectoNube()
    {
        var cliente = RequerirNube();
        var activo = pestanasProyectos.SelectedTab?.Tag as EditorForm;
        MYGProyectoDocumento? documentoActual = activo?.DocumentoParaPublicar();
        string pendientes = Path.Combine(CarpetaNube, "publicaciones");
        Directory.CreateDirectory(pendientes);
        string ambito = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(cliente.UrlServidor + "\n" + cliente.UsuarioId)));
        string solicitud = Path.Combine(pendientes, ambito + ".json");
        PublicacionPendiente publicacion;
        if (File.Exists(solicitud))
        {
            var opcion = WinForms.MessageBox.Show(ventanaNube, "Hay una publicación sin confirmar. Reintentar conserva su identidad y evita duplicados.",
                "Recuperar publicación", WinForms.MessageBoxButtons.OKCancel);
            if (opcion != WinForms.DialogResult.OK) return;
            publicacion = JsonSerializer.Deserialize<PublicacionPendiente>(File.ReadAllText(solicitud))
                ?? throw new InvalidDataException("La solicitud pendiente está dañada. Consérvela para recuperarla.");
        }
        else
        {
            using var dialogo = new NubePublicarForm(documentoActual, activo?.RutaProyecto);
            if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
            var documento = dialogo.Documento ?? throw new InvalidOperationException("Seleccione un proyecto.");
            string? temporal = null;
            try
            {
                string? origen = dialogo.RutaSQLite;
                if (string.IsNullOrWhiteSpace(origen))
                {
                    temporal = Path.Combine(pendientes, Guid.NewGuid().ToString("N") + ".sqlite");
                    MYGProyectoStorage.Guardar(temporal, documento); origen = temporal;
                }
                var contenido = PaqueteNube.CrearContenido(documento, origen, dialogo.Alcance);
                if (contenido.TryGetProperty("avisos", out var avisos) && avisos.ValueKind == JsonValueKind.Array)
                {
                    string detalle = string.Join(Environment.NewLine, avisos.EnumerateArray().Select(a => a.GetString()));
                    if (!string.IsNullOrWhiteSpace(detalle) && WinForms.MessageBox.Show(ventanaNube,
                        "Revise el alcance antes de publicar:" + Environment.NewLine + Environment.NewLine + detalle,
                        "Publicar en Nube MYG", WinForms.MessageBoxButtons.OKCancel, WinForms.MessageBoxIcon.Information)
                        != WinForms.DialogResult.OK) return;
                }
                publicacion = new(Guid.NewGuid(), dialogo.Nombre, dialogo.Alcance, contenido);
                string archivoTemporal = solicitud + ".tmp";
                File.WriteAllText(archivoTemporal, JsonSerializer.Serialize(publicacion));
                File.Move(archivoTemporal, solicitud);
            }
            finally { if (temporal is not null && File.Exists(temporal)) File.Delete(temporal); }
        }
        var contenidoRed = await cliente.PrepararArchivosAsync(publicacion.Contenido, publicacion.Id);
        ComprobarClienteActual(cliente);
        var remoto = await cliente.CrearProyectoAsync(publicacion.Id, publicacion.Nombre, contenidoRed, publicacion.Alcance);
        ComprobarClienteActual(cliente);
        File.Delete(solicitud);
        await AbrirProyectoNube(remoto);
    }

    private async Task DescargarProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        using var dialogo = new WinForms.SaveFileDialog
        {
            Title = "Descargar copia independiente confirmada", Filter = "Paquete con recursos (*.zip)|*.zip|Base SQLite (*.sqlite)|*.sqlite",
            FileName = "MYG_NUBE.zip", AddExtension = true, OverwritePrompt = true
        };
        if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
        if (File.Exists(dialogo.FileName)) throw new InvalidOperationException("Elija un nombre nuevo para conservar el archivo existente.");
        var remoto = await cliente.AbrirProyectoAsync(seleccionado.Id);
        remoto = remoto with { Contenido = await cliente.CargarArchivosAsync(remoto.Contenido) };
        ComprobarClienteActual(cliente);
        PaqueteNube.Descargar(remoto.Contenido, dialogo.FileName,
            string.Equals(Path.GetExtension(dialogo.FileName), ".zip", StringComparison.OrdinalIgnoreCase));
        WinForms.MessageBox.Show(ventanaNube, "Copia independiente descargada desde la revisión " + remoto.Revision + ".",
            "Nube MYG", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information);
    }

    private sealed record PublicacionPendiente(Guid Id, string Nombre, string Alcance, JsonElement Contenido);
}
