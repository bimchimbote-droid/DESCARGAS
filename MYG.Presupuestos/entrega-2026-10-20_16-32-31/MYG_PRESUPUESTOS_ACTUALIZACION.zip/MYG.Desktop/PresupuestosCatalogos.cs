using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Func<string> obtenerRutaCatalogos;
    private Func<string> obtenerRutaLecturaCatalogos;
    private Func<bool> autorizarCatalogos;
    private Action refrescarEditorCatalogos;
    internal void InicializarCatalogos(Func<string> obtenerRuta, Func<bool> autorizado, Action refrescarEditor, Func<string> rutaLectura = null)
    { obtenerRutaCatalogos = obtenerRuta; autorizarCatalogos = autorizado; refrescarEditorCatalogos = refrescarEditor; obtenerRutaLecturaCatalogos = rutaLectura; }
    private string RutaCatalogos() => obtenerRutaCatalogos?.Invoke()
        ?? throw new InvalidOperationException("Guarde el proyecto para usar sus catálogos.");
    private void RequerirPermisoCatalogos()
    { if (autorizarCatalogos?.Invoke() != true) throw new InvalidOperationException("Inicie una sesión autorizada para modificar el presupuesto o el catálogo."); }
    private string PrepararCatalogoInsumos()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        string ruta = RutaCatalogos();
        var presupuesto = P;
        var originales = presupuesto.Costos.Insumos.ToArray();
        var registros = originales.Select(MYGProyectoStorage.Copia).ToArray();
        // Recuperar insumos aceptados anteriormente. Si el registro falla,
        // ni sus referencias locales ni el historial se modifican.
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, registros);
        if (originales.Where((i, n) => i.Codigo != registros[n].Codigo || i.CatalogoMYGId != registros[n].CatalogoMYGId ||
            i.CatalogoMYGRuta != registros[n].CatalogoMYGRuta).Any())
        {
            antes();
            for (int n = 0; n < originales.Length; n++)
            {
                originales[n].Codigo = registros[n].Codigo;
                originales[n].CatalogoMYGId = registros[n].CatalogoMYGId;
                originales[n].CatalogoMYGRuta = registros[n].CatalogoMYGRuta;
            }
            despues();
        }
        return ruta;
    }
    private IReadOnlyList<MYGRecursoACU> AplicarInsumosAlACU(string ruta, string partidaId,
        IReadOnlyList<MYGSeleccionInsumo> selecciones, string insertarAntesId = null)
    {
        ExigirPermisoACU();
        // Validar el ACU completo antes de escribir entradas reutilizables.
        MYGInsumosEdicion.AplicarVarios(MYGProyectoStorage.Copia(P), partidaId, selecciones, insertarAntesId);
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta,
            selecciones.Where(x => x.NuevoInsumo != null && !x.EditarCompartido).Select(x => x.NuevoInsumo));
        return MYGInsumosEdicion.AplicarVarios(P, partidaId, selecciones, insertarAntesId, antes);
    }
    internal void SeleccionarPartidaCatalogo(string id)
    { buscar.Clear(); actual = P?.Items.FirstOrDefault(x => x.Id == id); Refrescar(); }

    internal void GuardarPartidaEnCatalogo()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion(); RequerirPartida(); string idPartida = actual.Id;
        string ruta = RutaCatalogos();
        // El primer guardado puede sustituir el documento por su copia validada.
        var i = P?.Items.FirstOrDefault(x => x.Id == idPartida)
            ?? throw new InvalidOperationException("La partida seleccionada ya no está en el presupuesto.");
        var existente = MYGCatalogos.Referencia(ruta, true, i.Costos.CatalogoMYGId, i.Costos.CatalogoMYGRuta);
        using var f = new MYGGuardarPartidaCatalogoForm(existente?.Codigo ?? MYGCatalogos.SiguienteCodigo(ruta, true), i.Descripcion, i.Unidad,
            existente != null, MYGCatalogoUnidades.Listar(ruta));
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        // Guardar en el catálogo es explícito; el botón Guardar proyecto nunca llama a este método.
        var entrada = MYGCatalogos.GuardarPartida(ruta, P, i, f.Codigo, f.Descripcion, f.Unidad,
            f.ComoNueva ? null : existente?.Id, f.ComoNueva ? 0 : existente?.Revision ?? 0);
        antes(); i.Costos.CatalogoMYGId = entrada.Id; i.Costos.CatalogoMYGRuta = ruta;
        despues(); MessageBox.Show(this, "Partida guardada en el catálogo: " + entrada.Codigo, "MYG", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    internal void GuardarCostosMultiples()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion();
        if (P == null) return;
        string presupuestoId = P.Id;
        object seleccion = SeleccionEstructura;
        string itemId = (seleccion as ItemPresupuestoDelphin)?.Id;
        string ruta = RutaCatalogos();
        // El primer guardado puede reemplazar el documento. Recuperar por identidad.
        var presupuesto = P;
        if (presupuesto == null || presupuesto.Id != presupuestoId)
            throw new InvalidOperationException("El presupuesto seleccionado ha cambiado. Vuelva a seleccionar sus partidas.");
        var partidas = presupuesto.Items.Where(x => !MYGProyectoStorage.EsTitulo(x)).ToArray();
        if (partidas.Length == 0) throw new InvalidOperationException("Este presupuesto no contiene partidas para grabar.");
        var seleccionInicial = partidas.Select(x => x.IdLocalMYG).ToArray();
        if (itemId != null)
        {
            var nodo = presupuesto.Items.FirstOrDefault(x => x.Id == itemId)
                ?? throw new InvalidOperationException("La fila seleccionada ya no está en el presupuesto.");
            var descendientes = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { nodo.Id };
            // Incluye títulos anidados; la visita evita repetir nodos.
            var pendientes = new Queue<string>(); pendientes.Enqueue(nodo.Id);
            while (pendientes.Count > 0)
            {
                string padre = pendientes.Dequeue();
                foreach (var hijo in presupuesto.Items.Where(x => string.Equals(x.ParentId, padre, StringComparison.OrdinalIgnoreCase)))
                    if (descendientes.Add(hijo.Id)) pendientes.Enqueue(hijo.Id);
            }
            seleccionInicial = partidas.Where(x => descendientes.Contains(x.Id)).Select(x => x.IdLocalMYG).ToArray();
        }
        using var f = new MYGGrabarCostosMultiplesForm(partidas, seleccionInicial, MYGCatalogos.ListarGruposCostos(ruta));
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        if (P?.Id != presupuestoId)
            throw new InvalidOperationException("El presupuesto seleccionado ha cambiado. Vuelva a seleccionar sus partidas.");
        var elegidas = f.PartidasSeleccionadas.Select(id => P.Items.Single(x => x.IdLocalMYG == id)).ToArray();
        var entradas = MYGCatalogos.GuardarPartidas(ruta, P, f.PartidasSeleccionadas, f.Grupo);
        // Publicar las referencias sólo después de guardar el lote completo.
        antes();
        for (int n = 0; n < elegidas.Length; n++)
        { elegidas[n].Costos.CatalogoMYGId = entradas[n].Id; elegidas[n].Costos.CatalogoMYGRuta = ruta; }
        despues();
        MessageBox.Show(this, entradas.Count + " costos unitarios guardados en el grupo «" + f.Grupo + "».",
            "MYG", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    internal void ElegirPartidaDelCatalogo()
    {
        ExigirPermisosPartidaCompleta();
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion(); if (P == null) return;
        string ruta = RutaCatalogos();
        using var f = new MYGCatalogoPropioForm(ruta, true, autorizarCatalogos);
        var resultado = f.ShowDialog(this);
        SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
        if (resultado != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        ExigirPermisosPartidaCompleta();
        string padre = MYGProyectoStorage.EsTitulo(actual) ? actual.Id : actual?.ParentId;
        antes(); var raiz = MYGCatalogos.InsertarPartida(P, f.Ruta, f.Seleccionada, padre);
        refrescarEditorCatalogos(); SeleccionarPartidaCatalogo(raiz.Id); despues();
    }
    internal void MostrarCatalogoInsumos() => ElegirInsumoDelCatalogo(false);
    private void InsumoCatalogoAlACU() => ElegirInsumoDelCatalogo(true);
    private void ElegirInsumoDelCatalogo(bool agregarAlACU)
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion(); if (P == null) return;
        if (agregarAlACU) RequerirPartida();
        string partidaId = agregarAlACU ? actual.Id : null;
        string ruta = PrepararCatalogoInsumos();
        using var f = new MYGCatalogoPropioForm(ruta, false, autorizarCatalogos);
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        var seleccionados = f.Seleccionadas.Select(e =>
        {
            var copia = MYGCatalogos.LeerInsumo(f.Ruta, e.Id, e.Revision);
            copia.Id = MYGProyectoStorage.NuevoId(); copia.CatalogoMYGId = e.Id; copia.CatalogoMYGRuta = Path.GetFullPath(f.Ruta);
            return new MYGSeleccionInsumo { NuevoInsumo = copia };
        }).ToArray();
        if (agregarAlACU) AplicarInsumosAlACU(ruta, partidaId, seleccionados);
        else
        {
            var nuevos = seleccionados.Select(x => x.NuevoInsumo).ToArray();
            var prueba = MYGProyectoStorage.Copia(P); prueba.Costos.Insumos.AddRange(nuevos);
            MYGProyectoStorage.ValidarPresupuesto(prueba);
            MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, nuevos);
            antes(); P.Costos.Insumos.AddRange(nuevos);
        }
        Refrescar(); despues(); if (!agregarAlACU) MostrarInsumos();
    }
    internal void GuardarInsumoEnCatalogo()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion();
        if (insumos.CurrentRow?.Tag is not MYGInsumo i) throw new InvalidOperationException("Seleccione un insumo de la Lista de Insumos del presupuesto.");
        string idInsumo = i.Id; string ruta = RutaCatalogos();
        // El primer guardado puede reemplazar el documento por su copia validada.
        i = P.Costos.Insumos.First(x => x.Id == idInsumo);
        var existente = MYGCatalogos.Referencia(ruta, false, i.CatalogoMYGId, i.CatalogoMYGRuta);
        var copia = MYGProyectoStorage.Copia(i);
        if (string.IsNullOrWhiteSpace(copia.Codigo)) copia.Codigo = existente?.Codigo ?? MYGCatalogos.SiguienteCodigo(ruta, false);
        using var f = new MYGInsumoForm(copia, MYGCatalogoUnidades.Listar(ruta));
        if (f.ShowDialog(this) != DialogResult.OK) return;
        if (existente != null && MessageBox.Show(this, "¿Actualizar el insumo «" + existente.Codigo + "» del catálogo con estos datos?",
            "Guardar en catálogo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        var entrada = MYGCatalogos.GuardarInsumo(ruta, f.Valor, existente?.Id, existente?.Revision ?? 0);
        antes(); i.CatalogoMYGId = entrada.Id; i.CatalogoMYGRuta = ruta; despues();
        MessageBox.Show(this, "Insumo guardado en el catálogo: " + entrada.Codigo, "MYG", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // Crear un insumo también lo registra en el catálogo de la base actual.
    // La edición explícita del catálogo conserva su confirmación habitual.
}
