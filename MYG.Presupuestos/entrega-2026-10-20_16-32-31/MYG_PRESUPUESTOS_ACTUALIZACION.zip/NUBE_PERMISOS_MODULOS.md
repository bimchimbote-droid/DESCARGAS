# Colaboración por usuario MYG y módulos en solo lectura

## Estado de esta entrega

Cliente C# preparado sobre `bimchimbote-droid/MYG.Presupuestos`, rama remota
`main`, commit base `67fb617f41203957eb2fb275e7decd4645aa4c1e`.
El checkout de trabajo se llama `work`. No se publicó el código en GitHub.

**La integración de servidor está pendiente.** Este repositorio no contiene el
backend Supabase, las funciones PostgreSQL ni las políticas de autorización.
Esta entrega no activa funciones nuevas en el servidor y no certifica seguridad
por módulo contra clientes modificados. No sustituye una migración del backend.

## Comportamiento del cliente

- El propietario o administrador introduce el usuario MYG del colaborador y
  asigna rol lector, editor o administrador.
- El alta directa sustituye a la solicitud por enlace en la ventana. Se conserva
  la gestión de solicitudes anteriores para no perder pendientes existentes.
- La lista de miembros muestra el nombre MYG cuando el servidor lo devuelve.
- ACU, Especificaciones Técnicas y Metrados Excel tienen permisos de edición
  independientes. Sin edición permanecen visibles, consultables y exportables.
- El lector conserva solo lectura global. Las máscaras no elevan su rol.
- Pegado, borrado, importación, historial y guardado también comprueban módulos
  protegidos. El documento se compara por identidad de presupuesto y partida.
- Los permisos recibidos se guardan en el vínculo SQLite y se revalidan antes de
  sincronizar. La reducción de permisos conserva las operaciones pendientes;
  una operación que altera un módulo bloqueado no se envía.
- Los cambios remotos autorizados pueden recibirse aunque ese módulo sea de
  solo lectura para el colaborador.
- Con servidores anteriores siguen funcionando los roles globales. La ausencia
  de máscaras no se presenta como protección por módulo. Si un vínculo ya tenía
  máscaras, una respuesta que las omita no elimina sus restricciones.

Una copia local independiente puede editarse fuera del proyecto compartido.
Permitir lectura y descarga no impide copiar los datos; el permiso protege la
edición del proyecto compartido. Otros módulos conservan el control por rol global.

## Contrato que debe implementar el backend

Los listados y la apertura deben devolver `permisos_modulos` fuera de
`contenido`, como metadatos de autorización para el usuario autenticado:

```json
{
  "acu": false,
  "especificaciones": true,
  "metrados_excel": false
}
```

Se exigen las tres claves booleanas. Los miembros también pueden devolver
`usuario_myg`, normalizado con las mismas reglas que el inicio de sesión MYG.
Los permisos deben obtenerse de membresías del servidor: no confiar en los
permisos almacenados en documentos ni en la SQLite del cliente.

| RPC nueva | Parámetros JSON | Respuesta satisfactoria |
| --- | --- | --- |
| `myg_nube_compartir_usuario` | `p_id` UUID del proyecto, `p_usuario_myg` normalizado, `p_rol`, `p_permisos_modulos` | `{"estado":"actualizada"}` |
| `myg_nube_permisos` | `p_id`, `p_usuario` UUID del miembro, `p_permisos_modulos` | `{"estado":"actualizada"}` |

Requisitos del servidor antes de habilitarlo:

1. Autorizar al actor como propietario/administrador en cada operación y resolver
   el usuario MYG únicamente contra vínculos verificados. No permitir que un
   cliente asigne un UUID arbitrario a un nombre MYG ni exponga un directorio público.
2. Proteger al propietario y evitar que un colaborador eleve su propio rol o
   restablezca sus permisos. Mantener transacciones y registrar los cambios.
3. Conservar las máscaras al cambiar de rol; devolverlas en
   `myg_nube_listar`, `myg_nube_abrir` y `myg_nube_miembros`, incluso sin cambiar
   la revisión del documento. El propietario debe conservar todos sus permisos.
4. Desactivar nuevas solicitudes en `myg_nube_solicitar` y cualquier escritura
   directa equivalente. Retirar botones no deshabilita clientes anteriores.
   Mantener la consulta/resolución de solicitudes anteriores si se necesitan.
5. En `myg_nube_guardar`, comprobar rol y permisos vigentes dentro de la misma
   transacción que valida revisión y aplica cambios. Comparar el estado confirmado
   con el candidato; conservar el protocolo idempotente de operación/revisión.
6. Validar los datos protegidos en **todo el paquete**: documento principal,
   documentos adicionales del alcance base, tablas SQLite nativas y de catálogo,
   adjuntos y recursos. Las referencias externas no deben eludir la comprobación.
   La comparación C# del documento no cubre tablas ni archivos del servidor.
7. Mantener la lectura/descarga para miembros autorizados; no borrar ni ocultar
   módulos restringidos. Evitar que tablas, Storage o funciones alternativas
   permitan escribir saltándose la RPC. Limitar y auditar las altas por usuario.

Falta el código/SQL actual del backend para preparar una migración compatible y
pruebas reales de RLS, Storage y concurrencia. No se incluyó una migración que invente su
estructura ni se accedió a datos privados.

Para obtener esa información: en tu proyecto Supabase abre **SQL Editor** en
el menú izquierdo, crea una consulta nueva, pega el contenido del archivo
`supabase/InspeccionarColaboracion.sql` y pulsa **Run**. Descarga el resultado
JSON/CSV y adjúntalo en esta conversación para preparar la parte del servidor.
La consulta solo lee estructura y definiciones; no aplica estos permisos ni
consulta las filas de tus obras. No publiques el resultado en DESCARGAS. No se
necesitan tus claves API, contraseña ni datos de usuarios para este paso.
La consulta aún no fue ejecutada en tu Supabase.

## Aplicación manual

1. Respaldar la carpeta local y confirmar o guardar aparte los cambios pendientes.
2. Comprobar que se parte del commit base indicado. Un reemplazo completo puede
   sobrescribir cambios propios posteriores: compararlos antes de copiar.
3. Extraer el ZIP de actualización y copiar sus archivos manteniendo rutas
   relativas sobre la raíz del proyecto; los archivos existentes se reemplazan
   completos y los nuevos se crean. No hay eliminaciones ni parches que aplicar.
4. Instalar SDK .NET 10.0.100, según `global.json`. No se agregaron dependencias
   NuGet ni se modificaron proyectos, solución o versiones.
5. Desde la raíz del proyecto, restaurar y compilar fuera de Revit:

```text
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
```

En Windows con Revit 2027 instalado, la compilación habitual usa las DLL de
Revit y puede omitir `UseRevitReferencePackages=true`.

Prueba específica de interfaz, únicamente en Windows:

```text
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --permisos-modulos
```

Las suites de nube usan HTTP simulado y SQLite real. No demuestran que el
backend desplegado implemente este contrato. En Windows comprobar lectura,
copiado/exportación, edición autorizada, rechazo por módulo, cambio de permisos,
reapertura y sincronización. Probar después con dos cuentas MYG y el backend
actualizado, incluyendo clientes antiguos y peticiones directas.

## Validación de esta entrega

- Linux x64, .NET SDK 10.0.100; compilación Release de la solución completa,
  con referencias Revit 2027: 0 errores y 0 advertencias.
- Suite general: 582 comprobaciones completadas; incluye 9 grupos nuevos de
  cambios por módulo. Named Pipes Windows y muestra privada LLACUSBAMBA omitidos.
- Suite nube: 26 grupos principales; conserva 787 comprobaciones principales,
  añade 179 de contratos/permisos y 145 de sincronización (12 casos), además de
  las integraciones existentes. Transporte HTTP simulado, SQLite real.
- Interfaz y prueba específica `--permisos-modulos`: compiladas; ejecución
  pendiente en Windows. Revit y servicios de producción no ejecutados.
- Consulta de diagnóstico PostgreSQL: sintaxis analizada; ejecución pendiente en
  tu Supabase. No modifica estructura ni aplica autorizaciones.

## GitHub después de aplicar

En Visual Studio abrir **Cambios de Git**, revisar la lista de archivos y el diff,
compilar y ejecutar las pruebas. Seleccionar la rama de trabajo `main`, hacer
Commit con un mensaje descriptivo y después Push cuando se decida publicar el
código. Verificar el commit en GitHub. Publicar un ZIP en `DESCARGAS` no aplica
estos cambios al repositorio del código ni a la instalación de Windows.
