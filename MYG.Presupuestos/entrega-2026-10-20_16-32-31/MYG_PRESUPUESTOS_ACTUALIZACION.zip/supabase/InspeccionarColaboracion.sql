-- DIAGNOSTICO DE SOLO LECTURA. Ejecutar en Supabase > SQL Editor.
-- No modifica tablas, usuarios, permisos ni datos y no consulta filas de obras.
-- Devuelve estructura, politicas y definiciones de las RPC que usa el cliente.
-- Descargar el resultado y adjuntarlo en la conversacion; no publicarlo en GitHub.
BEGIN TRANSACTION READ ONLY;

SELECT jsonb_pretty(jsonb_build_object(
  'tablas_publicas', COALESCE((
    SELECT jsonb_agg(jsonb_build_object(
      'nombre', c.relname,
      'rls', c.relrowsecurity,
      'rls_forzada', c.relforcerowsecurity,
      'columnas', COALESCE((
        SELECT jsonb_agg(jsonb_build_object(
          'nombre', a.attname,
          'tipo', pg_catalog.format_type(a.atttypid, a.atttypmod),
          'no_nulo', a.attnotnull
        ) ORDER BY a.attnum)
        FROM pg_catalog.pg_attribute a
        WHERE a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
      ), '[]'::jsonb),
      'restricciones', COALESCE((
        SELECT jsonb_agg(jsonb_build_object(
          'nombre', x.conname,
          'definicion', pg_catalog.pg_get_constraintdef(x.oid)
        ) ORDER BY x.conname)
        FROM pg_catalog.pg_constraint x WHERE x.conrelid = c.oid
      ), '[]'::jsonb)
    ) ORDER BY c.relname)
    FROM pg_catalog.pg_class c
    JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p')
  ), '[]'::jsonb),
  'politicas', COALESCE((
    SELECT jsonb_agg(jsonb_build_object(
      'tabla', tablename, 'nombre', policyname, 'roles', roles,
      'comando', cmd, 'using', qual, 'with_check', with_check
    ) ORDER BY tablename, policyname)
    FROM pg_catalog.pg_policies WHERE schemaname IN ('public', 'storage')
  ), '[]'::jsonb),
  'funciones_cliente', COALESCE((
    SELECT jsonb_agg(jsonb_build_object(
      'firma', p.oid::regprocedure::text,
      'definicion', pg_catalog.pg_get_functiondef(p.oid)
    ) ORDER BY p.proname, p.oid)
    FROM pg_catalog.pg_proc p
    JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prokind = 'f' AND p.proname IN (
      'myg_nube_listar', 'myg_nube_crear', 'myg_nube_abrir',
      'myg_nube_guardar', 'myg_nube_solicitar', 'myg_nube_miembros',
      'myg_nube_solicitudes', 'myg_nube_resolver', 'myg_nube_rol',
      'myg_nube_compartir_usuario', 'myg_nube_permisos'
    )
  ), '[]'::jsonb),
  'firmas_auxiliares_myg', COALESCE((
    SELECT jsonb_agg(p.oid::regprocedure::text ORDER BY p.proname, p.oid)
    FROM pg_catalog.pg_proc p
    JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname LIKE 'myg\_%' ESCAPE '\'
  ), '[]'::jsonb),
  'permisos_tablas', COALESCE((
    SELECT jsonb_agg(jsonb_build_object(
      'tabla', table_name, 'rol', grantee, 'permiso', privilege_type
    ) ORDER BY table_name, grantee, privilege_type)
    FROM information_schema.table_privileges
    WHERE table_schema = 'public' AND grantee IN ('PUBLIC', 'anon', 'authenticated')
  ), '[]'::jsonb),
  'permisos_rutinas', COALESCE((
    SELECT jsonb_agg(jsonb_build_object(
      'rutina', routine_name, 'firma', specific_name,
      'rol', grantee, 'permiso', privilege_type
    ) ORDER BY routine_name, specific_name, grantee)
    FROM information_schema.routine_privileges
    WHERE routine_schema = 'public' AND routine_name LIKE 'myg\_%' ESCAPE '\'
      AND grantee IN ('PUBLIC', 'anon', 'authenticated')
  ), '[]'::jsonb)
)) AS diagnostico_colaboracion;

COMMIT;
