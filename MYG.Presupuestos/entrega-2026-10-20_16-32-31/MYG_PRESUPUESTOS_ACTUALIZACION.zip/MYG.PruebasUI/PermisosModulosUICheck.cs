using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG_2027;

internal static class PermisosModulosUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Permisos por módulo", "Presupuesto");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), IdLocalMYG = MYGProyectoStorage.NuevoId(),
            TipoPropuesta = "PARTIDA", Descripcion = "Partida de prueba", Unidad = "m3", Posicion = 1
        };
        partida.Costos.EspecificacionTexto = "Contenido visible de la especificación";
        partida.Costos.Hoja.Poner("A3", "Contenido visible de la hoja");
        presupuesto.Items.Add(partida);
        int cambios = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => cambios++, () => { }, _ => { },
            () => System.Threading.Tasks.Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var ventana = new Form { ClientSize = new Size(1300, 850) };
        ventana.Controls.Add(panel); ventana.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        var permisos = new MYGPermisosModulos();
        bool edicionGlobal = true;
        panel.ConfigurarPermisoNube(() => edicionGlobal, () => permisos);
        var acu = Campo<DataGridView>(panel, "acu");
        var hoja = Campo<DataGridView>(panel, "hoja");
        var especificacion = Campo<RichTextBox>(panel, "especificacion");
        var pestanas = Campo<TabControl>(panel, "detalle");
        int paginas = pestanas.TabPages.Count;

        permisos.Acu = false; panel.ActualizarPermisoNube();
        exige(acu.ReadOnly && !hoja.ReadOnly && !especificacion.ReadOnly,
            "Bloquear ACU conserva editables los otros módulos y mantiene visible el análisis.");
        int historial = cambios;
        Rechaza(() => Invocar(panel, "EliminarRecurso"), exige);
        exige(cambios == historial, "La entrada directa de eliminación ACU bloqueada no genera historial.");

        permisos.Especificaciones = false; panel.ActualizarPermisoNube();
        exige(especificacion.ReadOnly && especificacion.Text.Contains("Contenido visible"),
            "Las especificaciones bloqueadas conservan su contenido visible en solo lectura.");

        permisos.MetradosExcel = false; panel.ActualizarPermisoNube();
        exige(hoja.ReadOnly && Campo<TextBoxBase>(panel, "formula").ReadOnly,
            "La hoja y su barra de fórmulas quedan en solo lectura.");
        Rechaza(() => Invocar(panel, "EjecutarComandoHoja", "limpiar"), exige);
        Rechaza(() => Invocar(panel, "ImportarHoja"), exige);
        exige(cambios == historial && partida.Costos.Hoja.Celdas["A3"].Contenido == "Contenido visible de la hoja",
            "Los comandos de hoja bloqueados no alteran datos ni historial.");
        partida.Costos.Hoja.RangoCuerpoPlantilla = null;
        partida.Costos.Hoja.RellenoCabeceraEstandarAplicado = false;
        string legado = MYGProyectoStorage.Firma(proyecto);
        Invocar(panel, "CargarHoja");
        exige(MYGProyectoStorage.Firma(proyecto) == legado,
            "Consultar una hoja heredada bloqueada no aplica reparaciones persistentes ni cambia el documento.");
        exige(pestanas.TabPages.Count == paginas, "Los permisos no ocultan ni eliminan las pestañas de módulos.");

        permisos.Acu = permisos.Especificaciones = permisos.MetradosExcel = true;
        edicionGlobal = false; panel.ActualizarPermisoNube();
        exige(acu.ReadOnly && hoja.ReadOnly && especificacion.ReadOnly,
            "Los permisos de módulo no elevan a un lector global ni una sesión revocada.");
        edicionGlobal = true; panel.ActualizarPermisoNube();
        exige(!acu.ReadOnly && !hoja.ReadOnly && !especificacion.ReadOnly,
            "Restituir los permisos reactiva los editores sin recrear el proyecto.");
        ventana.Close();
    }

    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static void Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); }
    }
    private static void Rechaza(Action accion, Action<bool, string> exige)
    {
        bool rechazo = false;
        try { accion(); } catch (InvalidOperationException) { rechazo = true; }
        exige(rechazo, "La mutación del módulo bloqueado exige permiso incluso al invocarse directamente.");
    }
}
