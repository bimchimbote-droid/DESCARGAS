using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace MYG_2027;

/// <summary>
/// Protege el documento de trabajo al aplicar cambios compuestos (pegado,
/// eliminación, historial y sincronización). No sustituye la autorización del
/// servidor ni examina las tablas SQLite o los archivos del paquete de nube.
/// </summary>
public static class MYGCambiosModulosNube
{
    private static readonly MYGDatosPartida DatosVacios = new();
    private static readonly MYGCostosPresupuesto PresupuestoVacio = new();
    private static readonly JsonSerializerOptions Opciones = new() { MaxDepth = 128 };

    public static void ExigirPermitidos(MYGProyectoDocumento anterior, MYGProyectoDocumento nuevo,
        MYGPermisosModulos permisos)
    {
        ArgumentNullException.ThrowIfNull(anterior);
        ArgumentNullException.ThrowIfNull(nuevo);
        if (permisos == null) return; // Contrato anterior: sigue rigiendo el rol global.
        if (!permisos.Acu && CambiaAcu(anterior, nuevo))
            throw new InvalidOperationException("ACU está en solo lectura. La operación también cambiaría sus análisis o recursos.");
        if (!permisos.Especificaciones && CambiaEspecificaciones(anterior, nuevo))
            throw new InvalidOperationException("Especificaciones técnicas está en solo lectura. La operación cambiaría su contenido.");
        if (!permisos.MetradosExcel && CambiaMetradosExcel(anterior, nuevo))
            throw new InvalidOperationException("Metrados Excel está en solo lectura. La operación cambiaría sus hojas o su origen de cantidad.");
    }

    public static bool CambiaAcu(MYGProyectoDocumento anterior, MYGProyectoDocumento nuevo) =>
        !Igual(FormaAnalisis(anterior), FormaAnalisis(nuevo)) ||
        Cambia(anterior, nuevo, Analisis, incluirRecursos: true);

    public static bool CambiaEspecificaciones(MYGProyectoDocumento anterior, MYGProyectoDocumento nuevo) =>
        Cambia(anterior, nuevo, Especificacion);

    public static bool CambiaMetradosExcel(MYGProyectoDocumento anterior, MYGProyectoDocumento nuevo) =>
        Cambia(anterior, nuevo, MetradoExcel);

    private static object FormaAnalisis(MYGProyectoDocumento documento) => new
    {
        PorRendimientoCuadrilla = documento?.Datos?.PorRendimientoCuadrilla ?? true,
        PorAsignacionRecursos = documento?.Datos?.PorAsignacionRecursos ?? false
    };

    private static object Analisis(ItemPresupuestoDelphin partida)
    {
        MYGDatosPartida datos = partida?.Costos ?? DatosVacios;
        // Una fila nueva vacía no crea un análisis por tener una unidad o un
        // título. Cuando existe un ACU, también se conserva su unidad y enlace.
        bool tieneAnalisis = !Igual(DatosAnalisis(datos), DatosAnalisis(DatosVacios));
        return new
        {
            Datos = DatosAnalisis(datos),
            Unidad = tieneAnalisis ? partida?.Unidad ?? "" : "",
            UnidadPropuesta = tieneAnalisis ? partida?.UnidadPropuesta ?? "" : "",
            IdAnalisisDelphin = partida?.IdAnalisisDelphin ?? "",
            IdCatalogoDelphin = partida?.IdCatalogoDelphin ?? "",
            FuenteCatalogoId = partida?.FuenteCatalogoId ?? "",
            CodigoCatalogoDelphin = partida?.CodigoCatalogoDelphin ?? ""
        };
    }

    private static object DatosAnalisis(MYGDatosPartida datos) => new
    {
        CatalogoMYGId = datos.CatalogoMYGId ?? "",
        datos.PrecioDirecto,
        datos.PrecioImportadoDelphin,
        FirmaAnalisisImportadoDelphin = datos.FirmaAnalisisImportadoDelphin ?? "",
        datos.RendimientoDiario,
        datos.JornadaHoras,
        datos.OrdenGruposACU,
        datos.Analisis
    };

    private static object Recursos(MYGCostosPresupuesto costos)
    {
        costos ??= PresupuestoVacio;
        return new
        {
            costos.Insumos,
            costos.DecimalesPrecio,
            costos.DecimalesCantidad,
            costos.ConfiguracionCostoDirecto
        };
    }

    private static object Especificacion(ItemPresupuestoDelphin partida)
    {
        var datos = partida?.Costos ?? DatosVacios;
        return new
        {
            EspecificacionRtf = datos.EspecificacionRtf ?? "",
            EspecificacionTexto = datos.EspecificacionTexto ?? "",
            datos.EspecificacionEsBorrador
        };
    }

    private static object MetradoExcel(ItemPresupuestoDelphin partida)
    {
        var datos = partida?.Costos ?? DatosVacios;
        var hoja = MYGProyectoStorage.Copia(datos.Hoja);
        // El zoom es navegación. Fórmulas, referencias, formatos, dimensiones
        // y opciones de impresión son contenido y permanecen protegidos.
        if (hoja != null) hoja.Zoom = 100;
        return new
        {
            Hoja = hoja,
            FuenteExcel = datos.FuenteMetrado == MYGFuenteMetrado.Excel,
            CantidadExcel = datos.FuenteMetrado == MYGFuenteMetrado.Excel ? datos.Cantidad : 0m
        };
    }

    private static bool Cambia(MYGProyectoDocumento anterior, MYGProyectoDocumento nuevo,
        Func<ItemPresupuestoDelphin, object> proyectar, bool incluirRecursos = false)
    {
        var antes = Proyectar(anterior, proyectar, incluirRecursos);
        var despues = Proyectar(nuevo, proyectar, incluirRecursos);
        return antes.Count != despues.Count || antes.Any(par =>
            !despues.TryGetValue(par.Key, out var valor) || !JsonElement.DeepEquals(par.Value, valor));
    }

    private static Dictionary<(string Presupuesto, string Partida), JsonElement> Proyectar(
        MYGProyectoDocumento documento, Func<ItemPresupuestoDelphin, object> proyectar, bool incluirRecursos)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var resultado = new Dictionary<(string, string), JsonElement>();
        var presupuestos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        JsonElement vacio = JsonSerializer.SerializeToElement(proyectar(null), Opciones);
        JsonElement recursosVacios = JsonSerializer.SerializeToElement(Recursos(null), Opciones);
        foreach (var presupuesto in documento.Presupuestos ?? throw DocumentoInvalido())
        {
            if (presupuesto == null || string.IsNullOrWhiteSpace(presupuesto.Id) || !presupuestos.Add(presupuesto.Id))
                throw DocumentoInvalido();
            string id = presupuesto.Id.ToUpperInvariant();
            if (incluirRecursos)
            {
                JsonElement recursos = JsonSerializer.SerializeToElement(Recursos(presupuesto.Costos), Opciones);
                if (!JsonElement.DeepEquals(recursos, recursosVacios)) resultado.Add((id, null), recursos);
            }
            var partidas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var partida in presupuesto.Items ?? throw DocumentoInvalido())
            {
                if (partida == null || string.IsNullOrWhiteSpace(partida.Id) || !partidas.Add(partida.Id))
                    throw DocumentoInvalido();
                JsonElement contenido = JsonSerializer.SerializeToElement(proyectar(partida), Opciones);
                if (!JsonElement.DeepEquals(contenido, vacio))
                    resultado.Add((id, partida.Id.ToUpperInvariant()), contenido);
            }
        }
        return resultado;
    }

    private static bool Igual(object a, object b) => JsonElement.DeepEquals(
        JsonSerializer.SerializeToElement(a, Opciones), JsonSerializer.SerializeToElement(b, Opciones));

    private static InvalidOperationException DocumentoInvalido() =>
        new("No se pueden comprobar los permisos: el documento contiene identidades ausentes o repetidas.");
}
