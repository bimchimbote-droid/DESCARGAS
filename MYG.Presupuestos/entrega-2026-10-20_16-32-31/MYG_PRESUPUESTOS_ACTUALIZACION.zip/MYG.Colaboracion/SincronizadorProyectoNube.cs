#nullable enable
using System.IO;
using System.Text.Json;
using MYG_2027;

namespace MYG.Colaboracion;

public sealed record ResultadoSincronizacion(MYGProyectoDocumento Documento, MYGVinculoNube Vinculo);

/// <summary>Sincronización manual; ningún fallo HTTP descarta la cola durable.</summary>
public static class SincronizadorProyectoNube
{
    public static async Task<ResultadoSincronizacion> EjecutarAsync(ClienteSupabase cliente, string ruta,
        MYGProyectoDocumento documento, bool soloLeer = false, CancellationToken ct = default)
    {
        var vinculo = MYGColaboracionLocal.Leer(ruta, documento.Id)
            ?? throw new InvalidOperationException("La copia no está vinculada a un proyecto de nube.");
        ValidarIdentidad(cliente, vinculo);
        bool incorporarDependencias = false;
        try
        {
            // Se revalida el permiso incluso para reenviar una operación ya confirmada.
            ProyectoNube remoto = await cliente.AbrirProyectoAsync(vinculo.ProyectoId, ct);
            remoto = remoto with { Contenido = await cliente.CargarArchivosAsync(remoto.Contenido, ct) };
            ActualizarPermisos(vinculo, remoto);
            vinculo.EstadoConexion = null;
            if (vinculo.Pendiente is null && PuedeEditar(remoto.Rol)
                && string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto)
                && !string.IsNullOrWhiteSpace(vinculo.JsonPaqueteConfirmado))
            {
                using var anterior = JsonDocument.Parse(vinculo.JsonPaqueteConfirmado);
                // Los catálogos y datos nativos también pueden cambiar sin modificar el documento.
                if (anterior.RootElement.TryGetProperty("tablas", out _))
                {
                    var local = PaqueteNube.CrearContenido(documento, ruta, remoto.Alcance);
                    if (PaqueteNube.FirmaDatosCompartidos(local) != PaqueteNube.FirmaDatosCompartidos(anterior.RootElement))
                        MYGColaboracionLocal.PrepararCambioContenido(ruta, documento, vinculo, local.GetRawText());
                }
            }
            if (!soloLeer && vinculo.Pendiente is not null && PuedeEditar(remoto.Rol))
            {
                if (!string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto))
                {
                    MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
                    return new(documento, vinculo);
                }
                var operacion = vinculo.Pendiente;
                using var pendienteComprobado = JsonDocument.Parse(operacion.JsonContenido);
                if (vinculo.PermisosModulos != null && !string.IsNullOrWhiteSpace(vinculo.JsonConfirmado))
                {
                    try
                    {
                        MYGCambiosModulosNube.ExigirPermitidos(
                            MYGColaboracionLocal.ImportarDocumento(vinculo.JsonConfirmado),
                            PaqueteNube.LeerDocumento(pendienteComprobado.RootElement), vinculo.PermisosModulos);
                    }
                    catch (InvalidOperationException ex)
                    {
                        throw new NubeException(ex.Message + " Se conserva la operación pendiente sin publicarla.");
                    }
                }
                if (!operacion.Enviada)
                {
                    using var cuerpo = JsonDocument.Parse(operacion.JsonContenido);
                    var congelado = PaqueteNube.LeerDocumento(cuerpo.RootElement);
                    using var previo = JsonDocument.Parse(vinculo.JsonPaqueteConfirmado ?? operacion.JsonContenido);
                    string alcance = previo.RootElement.TryGetProperty("alcance", out var a) ? a.GetString() ?? "obra" : "obra";
                    var paquete = cuerpo.RootElement.TryGetProperty("tablas", out _)
                        ? cuerpo.RootElement.Clone() : PaqueteNube.CrearContenido(congelado, ruta, alcance);
                    operacion = MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, paquete.GetRawText());
                }
                using var contenido = JsonDocument.Parse(operacion.JsonContenido);
                var contenidoRed = await cliente.PrepararArchivosAsync(contenido.RootElement, operacion.Id, ct);
                var respuesta = await cliente.GuardarProyectoAsync(vinculo.ProyectoId, operacion.Id,
                    operacion.RevisionBase, contenidoRed, ct);
                respuesta = respuesta with { Contenido = await cliente.CargarArchivosAsync(respuesta.Contenido, ct) };
                var confirmado = PaqueteNube.LeerDocumento(respuesta.Contenido);
                ValidarDocumento(documento, confirmado);
                if (respuesta.Estado == "conflicto")
                {
                    vinculo.JsonPaqueteConflicto = respuesta.Contenido.GetRawText();
                    MYGColaboracionLocal.RegistrarConflicto(ruta, documento, vinculo, respuesta.Revision,
                        MYGColaboracionLocal.ExportarDocumento(PaqueteNube.MaterializarDocumento(respuesta.Contenido, ruta)));
                    return new(documento, vinculo);
                }
                vinculo.JsonPaqueteConfirmado = respuesta.Contenido.GetRawText();
                MYGColaboracionLocal.Confirmar(ruta, documento, vinculo, respuesta.OperacionId,
                    respuesta.Revision, MYGColaboracionLocal.ExportarDocumento(confirmado));
                // Un ACK idempotente puede describir una revisión antigua. Leer el estado actual.
                remoto = await cliente.AbrirProyectoAsync(vinculo.ProyectoId, ct);
                remoto = remoto with { Contenido = await cliente.CargarArchivosAsync(remoto.Contenido, ct) };
                ActualizarPermisos(vinculo, remoto);
            }
            if (remoto.Revision < vinculo.Revision)
                throw new NubeException("El servidor devolvió una revisión anterior. Se conserva la copia y sus pendientes.");
            var actual = PaqueteNube.LeerDocumento(remoto.Contenido);
            ValidarDocumento(documento, actual);
            if (remoto.Revision > vinculo.Revision)
            {
                if (vinculo.Pendiente is not null)
                {
                    vinculo.JsonPaqueteConflicto = remoto.Contenido.GetRawText();
                    MYGColaboracionLocal.RegistrarConflicto(ruta, documento, vinculo, remoto.Revision,
                        MYGColaboracionLocal.ExportarDocumento(PaqueteNube.MaterializarDocumento(remoto.Contenido, ruta)));
                    return new(documento, vinculo);
                }
                if (remoto.Alcance == "base")
                    return IncorporarBaseConfirmada(ruta, documento, vinculo, remoto.Revision, remoto.Contenido);
                documento = PaqueteNube.MaterializarDocumento(remoto.Contenido, ruta);
                vinculo.Revision = remoto.Revision;
                vinculo.JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento);
                vinculo.JsonPaqueteConfirmado = remoto.Contenido.GetRawText();
                vinculo.JsonRemotoConflicto = null;
                vinculo.JsonPaqueteConflicto = null;
                incorporarDependencias = true;
            }
            vinculo.Estado = !PuedeEditar(vinculo.Rol) ? "solo lectura" : vinculo.Pendiente is null ? "sincronizado" : "pendiente";
            MYGColaboracionLocal.Guardar(ruta, documento, vinculo, incorporarDependencias
                ? (conexion, transaccion) => PaqueteNube.AplicarDependencias(remoto.Contenido, conexion, transaccion) : null);
            return new(documento, vinculo);
        }
        catch (NubeException ex)
        {
            vinculo.EstadoConexion = ex.AccesoDenegado ? "acceso retirado" : ex.EsErrorDeConexion ? "sin conexión" : null;
            MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
            throw;
        }
    }

    public static void ActualizarPermisos(MYGVinculoNube vinculo, ProyectoNube remoto)
    {
        // No degradar silenciosamente un vínculo con permisos a un servidor legado.
        if (vinculo.PermisosModulos != null && remoto.PermisosModulos == null)
            throw new NubeException("El servidor no devolvió los permisos por módulo. Actualice el backend antes de sincronizar esta copia.");
        vinculo.Rol = remoto.Rol;
        vinculo.PermisosModulos = remoto.PermisosModulos?.Copiar();
    }

    public static bool PuedeEditar(string? rol) => rol is "propietario" or "administrador" or "editor";

    // Una base completa no puede avanzar de revisión aplicando sólo su obra principal.
    // Se prepara toda la nueva hoja y el vínculo antes del reemplazo atómico; el
    // archivo anterior permanece como respaldo, incluidos sus borradores originales.
    public static ResultadoSincronizacion IncorporarBaseConfirmada(string ruta, MYGProyectoDocumento documento,
        MYGVinculoNube vinculo, long revision, JsonElement contenido)
    {
        if (revision <= vinculo.Revision || !contenido.TryGetProperty("alcance", out var alcance)
            || alcance.GetString() != "base")
            throw new InvalidDataException("La base confirmada necesita una revisión posterior y el alcance correcto.");
        ValidarDocumento(documento, PaqueteNube.LeerDocumento(contenido));
        ruta = Path.GetFullPath(ruta);
        if (File.Exists(ruta + "-wal") && new FileInfo(ruta + "-wal").Length > 0)
            throw new IOException("Cierre las otras aplicaciones que usan esta copia antes de incorporar la base completa. Se conservan sus cambios.");
        string estadoInicial = JsonSerializer.Serialize(MYGColaboracionLocal.Leer(ruta, documento.Id));
        string firmaInicial = PaqueteNube.FirmaDatosCompartidos(PaqueteNube.CrearContenido(documento, ruta, "base"));
        string temporal = Path.Combine(Path.GetDirectoryName(ruta)!, "revision-" + Guid.NewGuid().ToString("N") + ".sqlite");
        try
        {
            PaqueteNube.Descargar(contenido, temporal);
            var descargado = MYGBaseDatos.LeerProyecto(temporal, documento.Id);
            var nuevoVinculo = new MYGVinculoNube
            {
                ProyectoId = vinculo.ProyectoId, Servidor = vinculo.Servidor, UsuarioId = vinculo.UsuarioId,
                Rol = vinculo.Rol, PermisosModulos = vinculo.PermisosModulos?.Copiar(), Revision = revision, JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(descargado),
                JsonPaqueteConfirmado = contenido.GetRawText(), EstadoConexion = null
            };
            MYGColaboracionLocal.Vincular(temporal, descargado, nuevoVinculo);
            string firmaActual = PaqueteNube.FirmaDatosCompartidos(PaqueteNube.CrearContenido(documento, ruta, "base"));
            string estadoActual = JsonSerializer.Serialize(MYGColaboracionLocal.Leer(ruta, documento.Id));
            if (firmaActual != firmaInicial || estadoActual != estadoInicial)
                throw new IOException("La copia cambió durante la descarga. No se reemplazó; guarde sus cambios y vuelva a actualizar.");
            string respaldo = ruta + ".antes-r" + revision + "-" + Guid.NewGuid().ToString("N") + ".sqlite";
            File.Replace(temporal, ruta, respaldo);
            return new(descargado, MYGColaboracionLocal.Leer(ruta, descargado.Id));
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    public static void ValidarIdentidad(ClienteSupabase cliente, MYGVinculoNube vinculo)
    {
        if (!cliente.SesionIniciada || cliente.UsuarioId != vinculo.UsuarioId
            || !string.Equals(cliente.UrlServidor.TrimEnd('/'), vinculo.Servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            throw new NubeException("Inicie sesión en el mismo servidor y con la cuenta de esta copia de trabajo.", necesitaIniciarSesion: true);
    }

    private static void ValidarDocumento(MYGProyectoDocumento local, MYGProyectoDocumento remoto)
    {
        if (local.Id != remoto.Id)
            throw new NubeException("La respuesta corresponde a otro documento. Se conserva el trabajo local.");
    }
}
