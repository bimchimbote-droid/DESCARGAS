using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MYG_2027;

// La barra conserva navegación nativa; su indicador se mueve sin animar el contenido.
internal sealed class MYGTemaPestanas : NativeWindow, IDisposable
{
    private static readonly ConditionalWeakTable<TabControl, MYGTemaPestanas> ventanas = new();
    private readonly TabControl pestanas;
    private readonly System.Windows.Forms.Timer reloj = new() { Interval = 16 };
    private readonly Stopwatch tiempo = new();
    private RectangleF indicador, desde, hasta;
    private int sobre = -1;
    private bool preparado, liberado, repintarTrasRaton, pintando;

    [DllImport("user32.dll")]
    private static extern IntPtr GetWindow(IntPtr ventana, uint comando);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsWindowVisible(IntPtr ventana);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetWindowRect(IntPtr ventana, out RectanguloVentana rectangulo);
    [DllImport("user32.dll")]
    private static extern IntPtr BeginPaint(IntPtr ventana, out InformacionPintura pintura);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool EndPaint(IntPtr ventana, ref InformacionPintura pintura);
    [StructLayout(LayoutKind.Sequential)]
    private struct RectanguloVentana { internal int Izquierda, Superior, Derecha, Inferior; }
    [StructLayout(LayoutKind.Sequential)]
    private struct InformacionPintura
    {
        internal IntPtr Hdc;
        internal int Borrar;
        internal RectanguloVentana Area;
        internal int Restaurar, Actualizar;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        internal byte[] Reservado;
    }

    internal static void Aplicar(TabControl pestanas)
    {
        if (pestanas == null || pestanas.IsDisposed) return;
        MYGCursoresUI.Aplicar(pestanas);
        ventanas.GetValue(pestanas, p => new MYGTemaPestanas(p)).Actualizar();
    }
    internal static void Preparar(TabControl pestanas)
    {
        if (pestanas == null || pestanas.IsDisposed) return;
        MYGCursoresUI.Aplicar(pestanas);
        ventanas.GetValue(pestanas, p => new MYGTemaPestanas(p)).Preparar();
    }
    private MYGTemaPestanas(TabControl pestanas)
    {
        this.pestanas = pestanas;
        pestanas.HandleCreated += CrearHandle; pestanas.HandleDestroyed += DestruirHandle;
        pestanas.Disposed += Liberar; pestanas.SelectedIndexChanged += CambiarSeleccion;
        pestanas.MouseMove += MoverRaton; pestanas.MouseLeave += SalirRaton;
        pestanas.VisibleChanged += CambiarGeometria; pestanas.SizeChanged += CambiarGeometria;
        pestanas.DpiChangedAfterParent += CambiarDpi; reloj.Tick += Animar;
        if (pestanas.IsHandleCreated) AssignHandle(pestanas.Handle);
    }
    private void Preparar()
    {
        if (pestanas.Alignment is TabAlignment.Left or TabAlignment.Right) return;
        if (!preparado)
        {
            preparado = true;
            pestanas.DrawMode = TabDrawMode.OwnerDrawFixed;
            pestanas.DrawItem += DibujarPestana;
            AjustarMedidas();
        }
        Actualizar();
    }
    private void AjustarMedidas()
    {
        float escala = pestanas.DeviceDpi / 96f;
        int alto = Math.Max((int)Math.Round(34 * escala), pestanas.Font.Height + (int)Math.Round(12 * escala));
        pestanas.ItemSize = new Size(pestanas.ItemSize.Width, alto);
        int margen = pestanas is MYGPestanasProyectos ? 24 : 12;
        pestanas.Padding = new Point((int)Math.Round(margen * escala), (int)Math.Round(5 * escala));
    }
    private void Actualizar()
    {
        if (liberado) return;
        reloj.Stop(); indicador = IndicadorActual(); InvalidarBarra();
    }
    private RectangleF IndicadorActual()
    {
        if (!preparado || !pestanas.IsHandleCreated || pestanas.SelectedIndex < 0 ||
            pestanas.SelectedIndex >= pestanas.TabCount) return RectangleF.Empty;
        Rectangle r = pestanas.GetTabRect(pestanas.SelectedIndex);
        float escala = pestanas.DeviceDpi / 96f, margen = Math.Min(12 * escala, r.Width / 4f);
        float alto = Math.Max(2, 2 * escala);
        return new RectangleF(r.Left + margen,
            pestanas.Alignment == TabAlignment.Bottom ? r.Top + 1 : r.Bottom - alto - 1,
            Math.Max(1, r.Width - 2 * margen), alto);
    }
    private void CambiarSeleccion(object sender, EventArgs e)
    {
        RectangleF destino = IndicadorActual();
        if (!preparado || !pestanas.Visible || destino.IsEmpty || indicador.IsEmpty ||
            !SystemInformation.IsMenuAnimationEnabled || SystemInformation.HighContrast || SystemInformation.TerminalServerSession)
        { Actualizar(); return; }
        desde = indicador; hasta = destino; tiempo.Restart(); reloj.Start(); InvalidarBarra();
    }
    private void Animar(object sender, EventArgs e)
    {
        if (liberado || !pestanas.Visible || !pestanas.IsHandleCreated ||
            !SystemInformation.IsMenuAnimationEnabled || SystemInformation.HighContrast || SystemInformation.TerminalServerSession)
        { Actualizar(); return; }
        double t = Math.Min(1, tiempo.Elapsed.TotalMilliseconds / 150d);
        float suave = (float)(t * t * (3 - 2 * t));
        indicador = new RectangleF(desde.X + (hasta.X - desde.X) * suave, desde.Y + (hasta.Y - desde.Y) * suave,
            desde.Width + (hasta.Width - desde.Width) * suave, hasta.Height);
        InvalidarBarra();
        if (t >= 1) reloj.Stop();
    }
    private void MoverRaton(object sender, MouseEventArgs e)
    {
        if (!preparado) return;
        int nuevo = -1;
        for (int i = 0; i < pestanas.TabCount; i++)
            if (pestanas.GetTabRect(i).Contains(e.Location)) { nuevo = i; break; }
        if (nuevo == sobre) return;
        sobre = nuevo; repintarTrasRaton = true; InvalidarBarra();
    }
    private void SalirRaton(object sender, EventArgs e)
    { sobre = -1; repintarTrasRaton = true; InvalidarBarra(); }
    private void CambiarGeometria(object sender, EventArgs e) => Actualizar();
    private void CambiarDpi(object sender, EventArgs e) { if (preparado) AjustarMedidas(); Actualizar(); }
    private void CrearHandle(object sender, EventArgs e) { AssignHandle(pestanas.Handle); Actualizar(); }
    private void DestruirHandle(object sender, EventArgs e) { reloj.Stop(); ReleaseHandle(); }
    private void Liberar(object sender, EventArgs e) => Dispose();

    private void DibujarPestana(object sender, DrawItemEventArgs e)
    {
        DibujarPestana(e.Graphics, e.Bounds, e.Index, (e.State & DrawItemState.NoFocusRect) == 0);
    }

    private void DibujarPestana(Graphics grafico, Rectangle limites, int indice, bool mostrarFoco)
    {
        if (indice < 0 || indice >= pestanas.TabCount || limites.Width <= 0 || limites.Height <= 0) return;
        bool seleccionada = indice == pestanas.SelectedIndex, contraste = SystemInformation.HighContrast;
        Color fondo = contraste ? SystemColors.Control : MYG2027_TemaComercial.Fondo;
        Color activo = contraste ? SystemColors.Highlight : MYG2027_TemaComercial.Superficie;
        Color fondoTexto = seleccionada ? activo : !contraste && sobre == indice
            ? MYG2027_TemaComercial.SuperficieAlterna : fondo;
        Color texto = !pestanas.TabPages[indice].Enabled ? MYG2027_TemaComercial.Secundario :
            contraste ? seleccionada ? SystemColors.HighlightText : SystemColors.ControlText
            : seleccionada ? MYG2027_TemaComercial.Texto : MYG2027_TemaComercial.Secundario;
        using (var brocha = new SolidBrush(fondo)) grafico.FillRectangle(brocha, limites);
        var interior = limites; interior.Inflate(-2, -2);
        if (seleccionada || !contraste && sobre == indice)
        {
            grafico.SmoothingMode = SmoothingMode.AntiAlias;
            using var forma = MYG2027_TemaComercial.Contorno(interior, 6f * pestanas.DeviceDpi / 96f);
            using var brocha = new SolidBrush(seleccionada ? activo : MYG2027_TemaComercial.SuperficieAlterna);
            grafico.FillPath(brocha, forma);
        }
        Rectangle etiqueta = interior; etiqueta.Inflate(-8, -3);
        TabPage pagina = pestanas.TabPages[indice];
        if (pestanas is MYGPestanasProyectos proyectos && !proyectos.AreaCerrar(indice).IsEmpty)
            etiqueta.Width = Math.Max(0, proyectos.AreaCerrar(indice).Left - etiqueta.Left - 3);
        if (pestanas.ImageList != null)
        {
            int imagen = !string.IsNullOrEmpty(pagina.ImageKey) ? pestanas.ImageList.Images.IndexOfKey(pagina.ImageKey) : pagina.ImageIndex;
            if (imagen >= 0 && imagen < pestanas.ImageList.Images.Count)
            {
                int tamano = (int)Math.Round(16 * pestanas.DeviceDpi / 96f);
                grafico.DrawImage(pestanas.ImageList.Images[imagen], etiqueta.Left,
                    etiqueta.Top + (etiqueta.Height - tamano) / 2, tamano, tamano);
                etiqueta.X += tamano + 6; etiqueta.Width -= tamano + 6;
            }
        }
        // TextRenderer usa GDI sobre un DC temporal cuando Graphics pertenece
        // al bitmap de la barra. Darle el fondo real evita que el suavizado de
        // las letras mezcle con ese DC en vez de con la superficie ya compuesta.
        // Mantener la calidad de fuente predeterminada respeta el suavizado de Windows.
        TextRenderer.DrawText(grafico, pagina.Text, pestanas.Font, etiqueta, texto, fondoTexto,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis |
            TextFormatFlags.PreserveGraphicsClipping | TextFormatFlags.PreserveGraphicsTranslateTransform);
        if (pestanas is MYGPestanasProyectos proyectosConCierre)
            proyectosConCierre.DibujarCierre(grafico, indice, texto);
        if (seleccionada && pestanas.Focused && mostrarFoco)
        {
            var foco = interior; foco.Inflate(-3, -3);
            ControlPaint.DrawFocusRectangle(grafico, foco, texto, activo);
        }
    }

    private Rectangle FranjaPestanas()
    {
        if (!pestanas.IsHandleCreated || pestanas.TabCount == 0) return Rectangle.Empty;
        Rectangle union = pestanas.GetTabRect(0);
        for (int i = 1; i < pestanas.TabCount; i++) union = Rectangle.Union(union, pestanas.GetTabRect(i));
        int reserva = Math.Max(2, (int)Math.Round(4 * pestanas.DeviceDpi / 96f));
        return pestanas.Alignment == TabAlignment.Bottom
            ? Rectangle.FromLTRB(0, Math.Max(0, union.Top - reserva), pestanas.Width, pestanas.Height)
            : Rectangle.FromLTRB(0, 0, pestanas.Width, Math.Min(pestanas.Height, union.Bottom + reserva));
    }

    private void InvalidarBarra()
    {
        if (liberado || pestanas.IsDisposed || !pestanas.IsHandleCreated) return;
        if (!preparado) { pestanas.Invalidate(); return; }
        Rectangle franja = FranjaPestanas();
        if (!franja.IsEmpty) pestanas.Invalidate(franja);
    }

    private Region SuperficieSinHijos()
    {
        var superficie = new Region(pestanas.ClientRectangle);
        if (pestanas.SelectedTab != null) superficie.Exclude(pestanas.SelectedTab.Bounds);
        // El botón de desplazamiento de las pestañas es un hijo nativo y no
        // aparece en Controls. Su ventana debe conservar dibujo y hit testing.
        for (IntPtr hijo = GetWindow(pestanas.Handle, 5); hijo != IntPtr.Zero; hijo = GetWindow(hijo, 2))
        {
            if (!IsWindowVisible(hijo) || !GetWindowRect(hijo, out var r)) continue;
            Point origen = pestanas.PointToClient(new Point(r.Izquierda, r.Superior));
            superficie.Exclude(new Rectangle(origen.X, origen.Y, r.Derecha - r.Izquierda, r.Inferior - r.Superior));
        }
        return superficie;
    }

    private void DibujarSuperficie(Graphics destino)
    {
        if (pintando || liberado || pestanas.IsDisposed || !pestanas.IsHandleCreated) return;
        pintando = true;
        var estado = destino.Save();
        try
        {
            using var superficie = SuperficieSinHijos();
            using var fondo = new SolidBrush(SystemInformation.HighContrast ? SystemColors.Control : MYG2027_TemaComercial.Fondo);
            destino.SetClip(superficie, CombineMode.Intersect);
            if (!preparado)
            {
                for (int i = 0; i < pestanas.TabCount; i++) superficie.Exclude(pestanas.GetTabRect(i));
                destino.FillRegion(fondo, superficie);
                return;
            }
            Rectangle franja = FranjaPestanas();
            if (franja.Width <= 0 || franja.Height <= 0)
            {
                destino.FillRegion(fondo, superficie);
                return;
            }
            // Componer en un bitmap opaco y copiar mediante GDI+ respeta el
            // recorte de página e hijos. BufferedGraphics.Render usa BitBlt y
            // no conserva ese recorte cuando el destino es un HDC de captura.
            using var cuadro = new Bitmap(franja.Width, franja.Height, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
            using var composicion = Graphics.FromImage(cuadro);
            composicion.TranslateTransform(-franja.X, -franja.Y);
            composicion.SetClip(superficie, CombineMode.Intersect);
            composicion.FillRectangle(fondo, franja);
            RectangleF indicadorVigente = IndicadorActual();
            // El updown nativo cambia GetTabRect sin cambiar SelectedIndex.
            // Actualizar la geometría evita dejar el acento bajo otra etiqueta.
            if (!reloj.Enabled) indicador = indicadorVigente;
            else if (indicadorVigente != hasta) { reloj.Stop(); indicador = indicadorVigente; }
            bool mostrarFoco = (SendMessage(pestanas.Handle, 0x0129, IntPtr.Zero, IntPtr.Zero).ToInt64() & 1) == 0;
            for (int i = 0; i < pestanas.TabCount; i++)
                DibujarPestana(composicion, pestanas.GetTabRect(i), i, mostrarFoco);
            if (!indicador.IsEmpty)
            {
                using var acento = new SolidBrush(MYG2027_TemaComercial.Azul);
                composicion.FillRectangle(acento, indicador);
            }
            // El marco y la barra no se solapan: borrar la franja en el DC
            // visible antes de copiar el bitmap produciría un cuadro vacío.
            using var marco = superficie.Clone();
            marco.Exclude(franja);
            destino.FillRegion(fondo, marco);
            destino.DrawImageUnscaled(cuadro, franja.Location);
        }
        finally { destino.Restore(estado); pintando = false; }
    }

    protected override void WndProc(ref Message mensaje)
    {
        bool pinturaPropia = preparado && !liberado && !pestanas.IsDisposed &&
            pestanas.IsHandleCreated && pestanas.Alignment is TabAlignment.Top or TabAlignment.Bottom;
        if (pinturaPropia && mensaje.Msg == 0x0014) // WM_ERASEBKGND
        {
            // El cuadro opaco ya incluye el fondo. No exponer el borrado
            // nativo entre dos estados de hover o pasos de la animación.
            mensaje.Result = new IntPtr(1);
            return;
        }
        if (pinturaPropia && mensaje.Msg == 0x000F) // WM_PAINT
        {
            // BeginPaint conserva el área dañada y la exclusión de hijos.
            // La ruta nativa pinta antes del tema incluso con OwnerDrawFixed;
            // omitirla aquí permite mostrar únicamente el cuadro terminado.
            IntPtr hdc = BeginPaint(mensaje.HWnd, out var pintura);
            try
            {
                if (hdc != IntPtr.Zero)
                {
                    using var grafico = Graphics.FromHdc(hdc);
                    DibujarSuperficie(grafico);
                }
            }
            finally { EndPaint(mensaje.HWnd, ref pintura); }
            mensaje.Result = IntPtr.Zero;
            return;
        }
        base.WndProc(ref mensaje);
        if (pestanas.IsDisposed || !pestanas.IsHandleCreated || liberado ||
            (!preparado && !MYG2027_TemaComercial.Oscuro)) return;
        if (mensaje.Msg == 0x000F && pestanas.Visible)
        {
            using var grafico = pestanas.CreateGraphics();
            DibujarSuperficie(grafico);
        }
        else if (mensaje.WParam != IntPtr.Zero &&
            (mensaje.Msg == 0x0318 || mensaje.Msg == 0x0317 && (mensaje.LParam.ToInt64() & 4) != 0)) // WM_PRINTCLIENT / WM_PRINT con PRF_CLIENT
        {
            using var grafico = Graphics.FromHdc(mensaje.WParam);
            DibujarSuperficie(grafico);
        }
        else if (repintarTrasRaton && mensaje.Msg is 0x0200 or 0x02A3)
        {
            // Terminar primero el hot tracking nativo. Si se repinta dentro de
            // MouseMove, Windows puede volver a dibujar su borde encima después.
            repintarTrasRaton = false;
            InvalidarBarra(); pestanas.Update();
        }
    }
    public void Dispose()
    {
        if (liberado) return;
        liberado = true; reloj.Stop(); reloj.Dispose();
        pestanas.HandleCreated -= CrearHandle; pestanas.HandleDestroyed -= DestruirHandle;
        pestanas.Disposed -= Liberar; pestanas.SelectedIndexChanged -= CambiarSeleccion;
        pestanas.MouseMove -= MoverRaton; pestanas.MouseLeave -= SalirRaton;
        pestanas.VisibleChanged -= CambiarGeometria; pestanas.SizeChanged -= CambiarGeometria;
        pestanas.DpiChangedAfterParent -= CambiarDpi;
        if (preparado) pestanas.DrawItem -= DibujarPestana;
        ReleaseHandle(); ventanas.Remove(pestanas);
    }
}
