using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class ProyectosAbiertosCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-ProyectosAbiertos-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        var rutaIndice = typeof(MYGIndiceLocal).GetProperty("RutaAlternativaPruebas", BindingFlags.Static | BindingFlags.NonPublic);
        string indiceAnterior = (string)rutaIndice.GetValue(null);
        try
        {
            rutaIndice.SetValue(null, Path.Combine(carpeta, "indice_pruebas.json"));
            MYGIndiceLocal.RecordarBiblioteca(Path.Combine(carpeta, "biblioteca_pruebas.json"));
            string ruta = Path.Combine(carpeta, "obras.sqlite");
            string otraRuta = Path.Combine(carpeta, "copia.sqlite");
            var primera = MYGProyectoStorage.Nuevo("OBRA NORTE", "ESTRUCTURAS");
            primera.Presupuestos.Add(new MYGPresupuestoDocumento { Item = "02", Nombre = "ARQUITECTURA", Posicion = 2 });
            var segunda = MYGProyectoStorage.Nuevo("OBRA SUR", "INSTALACIONES");
            MYGProyectoStorage.Guardar(ruta, primera);
            MYGProyectoStorage.Guardar(ruta, segunda);
            MYGProyectoStorage.Guardar(otraRuta, MYGProyectoStorage.Copia(primera));
            string firmaSegundaGuardada = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id));
            string firmaOtraBase = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(otraRuta, primera.Id));

            // Estos recorridos no inician sesión ni consultan el servicio de licencia.
            // Los documentos se cargan de SQLite para tener un estado inicial limpio.
            using var sesion = new SesionDesktop();
            using var inicio = new InicioForm(sesion);
            inicio.WindowState = FormWindowState.Normal;
            inicio.ClientSize = new Size(1600, 900);
            inicio.Show();
            Application.DoEvents();
            var pestañas = inicio.PestanasProyectos;
            exige(pestañas.TabPages.Count == 1 && pestañas.TabPages[0].Text == "Inicio" &&
                pestañas.Alignment == TabAlignment.Bottom && pestañas.SelectedIndex == 0,
                "La ventana debe comenzar en Inicio y reservar abajo una pestaña permanente para volver a crear y abrir proyectos.");
            exige(((MYGPestanasProyectos)pestañas).AreaCerrar(0).IsEmpty,
                "La pestaña permanente Inicio debe mantenerse sin botón de cierre.");
            int ventanasIniciales = VentanasSuperiores();
            // También comprueba la ruta predeterminada utilizada por los botones de Inicio.
            typeof(InicioForm).GetField("rutaBase", Privados).SetValue(inicio, ruta);
            var editorPrimero = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, primera.Id));
            var editorSegundo = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, segunda.Id), ruta);
            Application.DoEvents();
            var tabPrimera = Pestaña(pestañas, editorPrimero);
            var tabSegunda = Pestaña(pestañas, editorSegundo);
            exige(pestañas.TabPages.Count == 3 && VentanasSuperiores() == ventanasIniciales &&
                !editorPrimero.TopLevel && !editorSegundo.TopLevel &&
                editorPrimero.Parent == tabPrimera && editorSegundo.Parent == tabSegunda &&
                editorPrimero.FormBorderStyle == FormBorderStyle.None && editorPrimero.Dock == DockStyle.Fill,
                "Abrir dos proyectos debe alojarlos en la misma ventana, sin abrir ventanas independientes.");
            exige(tabPrimera.Text.Contains(primera.Nombre, StringComparison.Ordinal) &&
                tabSegunda.Text.Contains(segunda.Nombre, StringComparison.Ordinal) && pestañas.SelectedTab == tabSegunda &&
                editorPrimero.ProyectoId == primera.Id && editorPrimero.RutaProyecto == ruta,
                "Cada pestaña debe identificar su proyecto y la última apertura debe quedar activa.");

            var repetido = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, primera.Id), Path.Combine(carpeta, ".", "obras.sqlite"));
            Application.DoEvents();
            exige(ReferenceEquals(repetido, editorPrimero) && pestañas.TabPages.Count == 3 && pestañas.SelectedTab == tabPrimera,
                "Volver a abrir el mismo proyecto y la misma base, incluso con una ruta equivalente, debe activar su pestaña existente.");
            var editorOtraBase = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(otraRuta, primera.Id), otraRuta);
            Application.DoEvents();
            var tabOtraBase = Pestaña(pestañas, editorOtraBase);
            exige(!ReferenceEquals(editorOtraBase, editorPrimero) && pestañas.TabPages.Count == 4 && pestañas.SelectedTab == tabOtraBase,
                "Un proyecto con el mismo identificador en otra base SQLite debe mantener su propia pestaña y su propio estado.");

            pestañas.SelectedTab = tabPrimera;
            Application.DoEvents();
            var documentoPrimero = Campo<MYGProyectoDocumento>(editorPrimero, "documento");
            var selector = Campo<ComboBox>(editorPrimero, "presupuesto");
            selector.SelectedItem = documentoPrimero.Presupuestos[1];
            Invocar(editorPrimero, "Recordar");
            documentoPrimero.Nombre = "OBRA NORTE REVISADA";
            Invocar(editorPrimero, "Refrescar");
            var buscar = Campo<TextBox>(editorPrimero, "buscarPartida");
            buscar.Text = "búsqueda conservada";
            Application.DoEvents();
            string firmaPrimeraPendiente = MYGProyectoStorage.Firma(documentoPrimero);
            var historialPrimero = Campo<Stack<MYGProyectoDocumento>>(editorPrimero, "undo");
            var historialSegundo = Campo<Stack<MYGProyectoDocumento>>(editorSegundo, "undo");
            exige(tabPrimera.Text.Contains(documentoPrimero.Nombre, StringComparison.Ordinal) &&
                editorPrimero.NombreProyecto == documentoPrimero.Nombre,
                "Renombrar un proyecto y refrescarlo debe actualizar el nombre de su pestaña.");
            exige(ReferenceEquals(inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, primera.Id), ruta), editorPrimero) &&
                ReferenceEquals(Campo<MYGProyectoDocumento>(editorPrimero, "documento"), documentoPrimero) &&
                MYGProyectoStorage.Firma(documentoPrimero) == firmaPrimeraPendiente && historialPrimero.Count == 1,
                "Reabrir un proyecto con cambios pendientes debe activar la instancia existente sin reemplazarla con su versión guardada.");

            var botonInicio = Descendientes(editorPrimero).OfType<Button>().Single(b => b.Name == "ir_inicio_button");
            exige(botonInicio.Enabled && !sesion.Autorizado && sesion.Credencial == null,
                "Ir Inicio debe seguir disponible con la sesión vencida y sin solicitar credenciales.");
            botonInicio.PerformClick();
            Application.DoEvents();
            exige(pestañas.SelectedIndex == 0 && !editorPrimero.IsDisposed && pestañas.TabPages.Count == 4 &&
                MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(editorPrimero, "documento")) == firmaPrimeraPendiente,
                "Ir Inicio debe mostrar la página inicial y conservar abierto el proyecto con sus cambios pendientes.");
            pestañas.SelectedTab = tabSegunda;
            Application.DoEvents();
            var documentoSegundo = Campo<MYGProyectoDocumento>(editorSegundo, "documento");
            Invocar(editorSegundo, "Recordar");
            documentoSegundo.Nombre = "OBRA SUR PENDIENTE";
            Invocar(editorSegundo, "Refrescar");
            pestañas.SelectedTab = tabPrimera;
            Application.DoEvents();
            exige(ReferenceEquals(Campo<MYGProyectoDocumento>(editorPrimero, "documento"), documentoPrimero) &&
                documentoPrimero.PresupuestoActivoId == documentoPrimero.Presupuestos[1].Id &&
                buscar.Text == "búsqueda conservada" && historialPrimero.Count == 1 && historialSegundo.Count == 1 &&
                MYGProyectoStorage.Firma(documentoPrimero) == firmaPrimeraPendiente &&
                Campo<MYGProyectoDocumento>(editorOtraBase, "documento").Nombre == primera.Nombre,
                "Volver de Inicio y cambiar pestañas debe conservar el presupuesto, búsqueda, documento e historial propios de cada proyecto.");
            Invocar(editorPrimero, "Historial", false);
            exige(Campo<MYGProyectoDocumento>(editorPrimero, "documento").Nombre == "OBRA NORTE" &&
                Campo<MYGProyectoDocumento>(editorSegundo, "documento").Nombre == "OBRA SUR PENDIENTE",
                "Deshacer después de volver de Inicio debe actuar únicamente en el proyecto activo.");
            Invocar(editorPrimero, "Historial", true);
            exige(MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(editorPrimero, "documento")) == firmaPrimeraPendiente,
                "Rehacer debe restaurar los cambios que existían antes de ir a Inicio y cambiar pestañas.");
            typeof(EditorForm).GetField("ocupado", Privados).SetValue(editorPrimero, true);
            try
            {
                bool cambioInicio = inicio.ActivarInicio(editorPrimero);
                pestañas.SelectedTab = tabSegunda;
                Application.DoEvents();
                exige(!cambioInicio && pestañas.SelectedTab == tabPrimera &&
                    MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(editorPrimero, "documento")) == firmaPrimeraPendiente,
                    "Una operación en curso debe impedir volver a Inicio o cambiar de proyecto hasta que termine, conservando los cambios.");
            }
            finally { typeof(EditorForm).GetField("ocupado", Privados).SetValue(editorPrimero, false); }

            exige((bool)Invocar(editorPrimero, "Guardar", false), "El primer proyecto debe poder guardar sus cambios desde su pestaña.");
            exige(MYGBaseDatos.LeerProyecto(ruta, primera.Id).Nombre == "OBRA NORTE REVISADA" &&
                MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id)) == firmaSegundaGuardada &&
                MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(otraRuta, primera.Id)) == firmaOtraBase &&
                Campo<MYGProyectoDocumento>(editorSegundo, "documento").Nombre == "OBRA SUR PENDIENTE" && historialSegundo.Count == 1,
                "Guardar una pestaña debe persistir solo ese proyecto, conservando los cambios pendientes de las otras pestañas y de otra base.");
            exige((bool)Invocar(editorSegundo, "Guardar", false), "El segundo proyecto debe poder guardar independientemente.");

            FormClosingEventHandler cancelar = (_, e) => e.Cancel = true;
            editorPrimero.FormClosing += cancelar;
            exige(!inicio.CerrarProyecto(editorPrimero) && !editorPrimero.IsDisposed && pestañas.TabPages.Contains(tabPrimera),
                "Cancelar el cierre de un proyecto debe conservar su pestaña y su editor.");
            pestañas.SelectedTab = tabSegunda;
            Application.DoEvents();
            PulsarCerrar(pestañas, tabPrimera);
            exige(!editorPrimero.IsDisposed && pestañas.TabPages.Contains(tabPrimera) && pestañas.TabPages.Count == 4 &&
                pestañas.SelectedTab == tabSegunda,
                "El botón × de una pestaña inactiva debe respetar la cancelación del cierre y conservar activo el otro proyecto.");
            editorPrimero.FormClosing -= cancelar;

            editorSegundo.FormClosing += cancelar;
            inicio.Close();
            Application.DoEvents();
            exige(!inicio.IsDisposed && !editorPrimero.IsDisposed && !editorSegundo.IsDisposed && !editorOtraBase.IsDisposed &&
                pestañas.TabPages.Count == 4 && pestañas.TabPages.Contains(tabPrimera) && pestañas.TabPages.Contains(tabSegunda),
                "Cancelar el cierre de un proyecto al cerrar la aplicación debe conservar también las pestañas revisadas antes de la cancelación.");
            editorSegundo.FormClosing -= cancelar;
            pestañas.SelectedTab = tabSegunda;
            Application.DoEvents();
            PulsarCerrar(pestañas, tabPrimera);
            exige(editorPrimero.IsDisposed && !pestañas.TabPages.Contains(tabPrimera) &&
                !editorSegundo.IsDisposed && !editorOtraBase.IsDisposed && pestañas.TabPages.Count == 3 &&
                pestañas.SelectedTab == tabSegunda,
                "El botón × debe retirar solo la pestaña inactiva cuyo cierre se confirma y conservar el proyecto seleccionado.");
            exige(inicio.CerrarProyecto(editorSegundo) && inicio.CerrarProyecto(editorOtraBase) && pestañas.TabPages.Count == 1,
                "Cerrar el último proyecto debe conservar la pestaña Inicio.");
            exige(inicio.ActivarInicio() && pestañas.SelectedIndex == 0,
                "Inicio debe seguir accesible después de cerrar todos los proyectos.");
            inicio.Close();
            Application.DoEvents();
            exige(inicio.IsDisposed && !sesion.Autorizado && sesion.Credencial == null,
                "La aplicación debe cerrarse después de confirmar todos los proyectos sin consultar credenciales ni servicios de licencia.");
        }
        finally
        {
            rutaIndice.SetValue(null, indiceAnterior);
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static int VentanasSuperiores() => Application.OpenForms.Cast<Form>().Count(f => f.TopLevel);

    private static TabPage Pestaña(TabControl pestañas, EditorForm editor) =>
        pestañas.TabPages.Cast<TabPage>().Single(p => ReferenceEquals(p.Tag, editor));

    private static void PulsarCerrar(TabControl pestañas, TabPage pagina)
    {
        Rectangle area = ((MYGPestanasProyectos)pestañas).AreaCerrar(pestañas.TabPages.IndexOf(pagina));
        if (area.IsEmpty) throw new InvalidOperationException("La pestaña del proyecto no ofrece el botón × para cerrarlo.");
        int x = area.Left + area.Width / 2, y = area.Top + area.Height / 2;
        var coordenadas = new IntPtr((y << 16) | (x & 0xFFFF));
        SendMessage(pestañas.Handle, 0x0201, new IntPtr(1), coordenadas);
        SendMessage(pestañas.Handle, 0x0202, IntPtr.Zero, coordenadas);
        Application.DoEvents();
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static object Invocar(object objeto, string nombre, params object[] argumentos) =>
        objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
