using System.Text;
using System.Text.Json;
using MYG_2027;

internal static class ConfirmacionJsonbCheck
{
    private static int comprobaciones;

    internal static Task RunAsync()
    {
        comprobaciones = 0;
        OrdenObjetos();
        DecimalesEquivalentes();
        CambioDecimalExacto(9007199254740993.123456789012m, 9007199254740993.123456789013m);
        CambioDecimalExacto(1.0000000000000000000000000000m, 1.0000000000000000000000000001m);
        ArraysConOrden();
        AckAntiguoConBorradorNuevo();
        Console.WriteLine($"OK Confirmación JSONB: 6 casos y {comprobaciones} comprobaciones de igualdad semántica, precisión y cola durable.");
        return Task.CompletedTask;
    }

    private static void Exige(bool condicion, string mensaje)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Confirmación JSONB: " + mensaje);
    }

    private static void OrdenObjetos()
    {
        using var caso = new Escenario(12.3456m);
        string jsonb = NormalizarComoJsonb(caso.Documento);
        var recibido = MYGColaboracionLocal.ImportarDocumento(jsonb);
        Exige(recibido.Cronograma.OpcionesVista.Keys.SequenceEqual(new[] { "a", "zz", "ordenVista" }),
            "La entrada del caso no reproduce el orden de claves de JSONB.");
        Exige(!caso.Documento.Cronograma.OpcionesVista.Keys.SequenceEqual(recibido.Cronograma.OpcionesVista.Keys),
            "La regresión requiere órdenes distintos antes y después del servidor.");
        Exige(caso.Vinculo.Pendiente.Enviada, "La regresión debe recuperar una operación ya enviada.");
        caso.Confirmar(jsonb);
        Exige(caso.Vinculo.Pendiente is null && caso.Vinculo.Revision == 2,
            "El ACK que sólo reordena objetos no confirmó la operación.");
        var durable = MYGColaboracionLocal.Leer(caso.Ruta, caso.Documento.Id);
        Exige(durable.Pendiente is null && durable.Revision == 2, "El ACK aceptado no quedó durable.");
        MYGColaboracionLocal.Guardar(caso.Ruta, caso.Documento, durable);
        Exige(durable.Pendiente is null, "El orden de diccionarios creó una operación fantasma al guardar de nuevo.");
    }

    private static void DecimalesEquivalentes()
    {
        using var caso = new Escenario(1m);
        var recibido = MYGProyectoStorage.Copia(caso.Documento);
        recibido.Presupuestos[0].Items[0].Costos.Cantidad = 1.0000m;
        Exige(MYGColaboracionLocal.ExportarDocumento(recibido).Contains("1.0000", StringComparison.Ordinal),
            "La prueba requiere representación decimal distinta con el mismo valor.");
        caso.Confirmar(NormalizarComoJsonb(recibido));
        Exige(caso.Vinculo.Revision == 2 && caso.Vinculo.Pendiente is null,
            "Escalas decimales equivalentes no deben rechazar el ACK.");
        Exige(MYGBaseDatos.LeerProyecto(caso.Ruta, caso.Documento.Id).Presupuestos[0].Items[0].Costos.Cantidad == 1m,
            "El cambio de representación alteró la cantidad local.");
    }

    private static void CambioDecimalExacto(decimal enviado, decimal diferente)
    {
        using var caso = new Escenario(enviado);
        var alterado = MYGProyectoStorage.Copia(caso.Documento);
        alterado.Presupuestos[0].Items[0].Costos.Cantidad = diferente;
        Exige(enviado != diferente && (double)enviado == (double)diferente,
            "Los valores deben distinguirse como decimal exacto aunque double pierda su diferencia.");
        RechazarSinModificarCola(caso, NormalizarComoJsonb(alterado));
        caso.Confirmar(NormalizarComoJsonb(caso.Documento));
        Exige(caso.Vinculo.Pendiente is null && caso.Vinculo.Revision == 2,
            "El rechazo del número alterado impidió confirmar después el documento correcto.");
    }

    private static void ArraysConOrden()
    {
        using var caso = new Escenario(3m);
        var alterado = MYGProyectoStorage.Copia(caso.Documento);
        alterado.Cronograma.AdvertenciasImportacion.Reverse();
        RechazarSinModificarCola(caso, NormalizarComoJsonb(alterado));
        caso.Confirmar(NormalizarComoJsonb(caso.Documento));
        Exige(caso.Vinculo.Pendiente is null, "El rechazo del array reordenado perdió la operación original.");
    }

    private static void AckAntiguoConBorradorNuevo()
    {
        using var caso = new Escenario(7m);
        Guid primero = caso.Vinculo.Pendiente.Id;
        string cuerpo = caso.Vinculo.Pendiente.JsonContenido;
        string confirmado = NormalizarComoJsonb(caso.Documento);
        caso.Documento.Nombre = "BORRADOR POSTERIOR A LA OPERACIÓN ENVIADA";
        caso.Documento.Cronograma.OpcionesVista["nueva"] = "edición mientras se esperaba ACK";
        MYGColaboracionLocal.Guardar(caso.Ruta, caso.Documento, caso.Vinculo);
        caso.Vinculo = MYGColaboracionLocal.Leer(caso.Ruta, caso.Documento.Id);
        Exige(caso.Vinculo.Pendiente.Id == primero && caso.Vinculo.Pendiente.JsonContenido == cuerpo,
            "Guardar y reabrir alteró los bytes/UUID del envío previo.");
        caso.Confirmar(confirmado);
        var siguiente = caso.Vinculo.Pendiente;
        Exige(siguiente is not null && siguiente.Id != primero && siguiente.RevisionBase == 2,
            "El ACK antiguo no preparó una operación nueva para el borrador más reciente.");
        Exige(MYGBaseDatos.LeerProyecto(caso.Ruta, caso.Documento.Id).Nombre == caso.Documento.Nombre,
            "Confirmar la operación anterior reemplazó el borrador nuevo.");
        var durable = MYGColaboracionLocal.Leer(caso.Ruta, caso.Documento.Id);
        bool rechazo = false;
        try { MYGColaboracionLocal.Confirmar(caso.Ruta, caso.Documento, durable, primero, 2, confirmado); }
        catch (InvalidOperationException) { rechazo = true; }
        Exige(rechazo, "Un ACK repetido de otra operación se aplicó a la nueva cola.");
        var conservado = MYGColaboracionLocal.Leer(caso.Ruta, caso.Documento.Id);
        Exige(conservado.Revision == 2 && conservado.Pendiente.Id == siguiente!.Id
            && conservado.Pendiente.JsonContenido == siguiente.JsonContenido,
            "El ACK repetido borró o cambió la nueva operación pendiente.");
        caso.Vinculo = conservado;
        MYGColaboracionLocal.Confirmar(caso.Ruta, caso.Documento, caso.Vinculo,
            conservado.Pendiente.Id, 3, NormalizarComoJsonb(caso.Documento));
        Exige(caso.Vinculo.Pendiente is null && caso.Vinculo.Revision == 3,
            "El borrador posterior no pudo confirmarse al recuperar el ACK anterior.");
    }

    private static void RechazarSinModificarCola(Escenario caso, string jsonAlterado)
    {
        var antes = MYGColaboracionLocal.Leer(caso.Ruta, caso.Documento.Id);
        string documentoAntes = MYGColaboracionLocal.ExportarDocumento(MYGBaseDatos.LeerProyecto(caso.Ruta, caso.Documento.Id));
        bool rechazo = false;
        try { caso.Confirmar(jsonAlterado); }
        catch (InvalidDataException) { rechazo = true; }
        Exige(rechazo, "Una confirmación con contenido realmente distinto fue aceptada.");
        var despues = MYGColaboracionLocal.Leer(caso.Ruta, caso.Documento.Id);
        Exige(despues.Revision == antes.Revision && despues.Pendiente.Id == antes.Pendiente.Id
            && despues.Pendiente.JsonContenido == antes.Pendiente.JsonContenido && despues.Pendiente.Enviada,
            "Rechazar la confirmación cambió la revisión, el UUID o los bytes de la cola.");
        Exige(MYGColaboracionLocal.ExportarDocumento(MYGBaseDatos.LeerProyecto(caso.Ruta, caso.Documento.Id)) == documentoAntes,
            "La confirmación rechazada modificó el documento local.");
    }

    // Este orden se contrastó con SELECT $1::jsonb::text en PGlite/PostgreSQL:
    // objetos por longitud UTF-8 y clave; arrays en su orden y números sin double.
    // El ejecutor normal no necesita Node.js ni un servicio PostgreSQL para repetirlo.
    private static string NormalizarComoJsonb(MYGProyectoDocumento documento)
    {
        using var json = JsonDocument.Parse(MYGColaboracionLocal.ExportarDocumento(documento), new JsonDocumentOptions { MaxDepth = 128 });
        using var memoria = new MemoryStream();
        using (var writer = new Utf8JsonWriter(memoria)) Escribir(json.RootElement, writer);
        return Encoding.UTF8.GetString(memoria.ToArray());
    }

    private static void Escribir(JsonElement valor, Utf8JsonWriter writer)
    {
        if (valor.ValueKind == JsonValueKind.Object)
        {
            writer.WriteStartObject();
            foreach (var propiedad in valor.EnumerateObject().OrderBy(p => Encoding.UTF8.GetByteCount(p.Name))
                .ThenBy(p => p.Name, StringComparer.Ordinal))
            {
                writer.WritePropertyName(propiedad.Name);
                Escribir(propiedad.Value, writer);
            }
            writer.WriteEndObject();
        }
        else if (valor.ValueKind == JsonValueKind.Array)
        {
            writer.WriteStartArray();
            foreach (var item in valor.EnumerateArray()) Escribir(item, writer);
            writer.WriteEndArray();
        }
        else valor.WriteTo(writer);
    }

    private sealed class Escenario : IDisposable
    {
        private readonly string carpeta = Path.Combine(Path.GetTempPath(), "myg-ack-jsonb-" + Guid.NewGuid().ToString("N"));
        internal string Ruta { get; }
        internal MYGProyectoDocumento Documento { get; }
        internal MYGVinculoNube Vinculo { get; set; }

        internal Escenario(decimal cantidad)
        {
            Directory.CreateDirectory(carpeta);
            Ruta = Path.Combine(carpeta, "trabajo.sqlite");
            Documento = MYGProyectoStorage.Nuevo("ORIGINAL ACK JSONB");
            Documento.Cronograma = new MYGCronograma
            {
                FechaInicio = new DateTime(2026, 10, 20),
                OpcionesVista = new() { ["ordenVista"] = "tardía", ["zz"] = "intermedia", ["a"] = "primera" },
                AdvertenciasImportacion = new() { "PRIMERA ADVERTENCIA", "SEGUNDA ADVERTENCIA" }
            };
            var partida = new ItemPresupuestoDelphin
            {
                Id = MYGProyectoStorage.NuevoId(), IdLocalMYG = MYGProyectoStorage.NuevoId(),
                TipoPropuesta = "PARTIDA", Descripcion = "Cantidad de precisión exacta", Unidad = "und", Posicion = 1
            };
            partida.Costos.Cantidad = cantidad;
            partida.Costos.Hoja.Celdas.Clear();
            partida.Costos.Hoja.Celdas["L9"] = new MYGCeldaHoja { Contenido = "=1+2" };
            partida.Costos.Hoja.Celdas["A1"] = new MYGCeldaHoja { Contenido = "Encabezado" };
            Documento.Presupuestos[0].Items.Add(partida);
            Vinculo = new MYGVinculoNube
            {
                ProyectoId = Guid.NewGuid(), Servidor = "https://regresion.supabase.co", UsuarioId = "usuario-jsonb",
                Rol = "editor", Revision = 1, JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(Documento)
            };
            MYGColaboracionLocal.Vincular(Ruta, Documento, Vinculo);
            Documento.Nombre = "CAMBIO ENVIADO ACK JSONB";
            MYGColaboracionLocal.Guardar(Ruta, Documento, Vinculo);
            MYGColaboracionLocal.PrepararEnvio(Ruta, Documento, Vinculo, Vinculo.Pendiente.JsonContenido);
        }

        internal void Confirmar(string json) => MYGColaboracionLocal.Confirmar(Ruta, Documento, Vinculo,
            Vinculo.Pendiente.Id, 2, json);

        public void Dispose() { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, true); }
    }
}
