# Corrección de confirmaciones de Nube MYG

## A. Resumen

Corrige el mensaje «La confirmación no contiene el documento enviado por esta operación»
cuando PostgreSQL devuelve el mismo contenido con las claves JSON en otro orden.
La confirmación se compara por su contenido JSON, conservando el orden de las listas,
los valores numéricos exactos y los controles de identidad, operación y revisión.
El cuerpo de una operación ya enviada conserva exactamente sus bytes y UUID.

Esta actualización incremental se aplica sobre la entrega de Nube MYG publicada en
`bimchimbote-droid/DESCARGAS`, commit `b8ff209f0c6a4ea89d317d93ad4fe6a84616246d`.
La base del repositorio fuente sigue siendo `main`, commit
`9ea48001e159a0120a86583d18b0dce89df7d787`. No se hizo Commit ni Push del código.

## B. Archivos

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `MYG.Core/ColaboracionLocalMYG.cs` | REEMPLAZAR | Igualdad semántica al validar confirmaciones y documentos de nube. |
| 2 | `MYG.PruebasNube/ConfirmacionJsonbCheck.cs` | CREAR | Regresión de claves reordenadas, decimales, listas y recuperación de pendientes. |
| 3 | `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Ejecuta la regresión nueva junto con las pruebas anteriores. |
| 4 | `LEEME_CORRECCION_CONFIRMACION_NUBE.md` | CREAR | Instalación, recuperación y límites de esta actualización. |

No se eliminan archivos. Los reemplazos contienen los archivos completos.

## C. Descarga

El ZIP se publica solo en una ruta nueva del repositorio público autorizado
`bimchimbote-droid/DESCARGAS`. El enlace fijado al commit, la ruta y el resultado de
la descarga con comparación SHA-256 se proporcionan en la respuesta de entrega.
El paquete incluye únicamente los cuatro archivos de B, sin bases ni credenciales.

## D. Instalación y recuperación

1. Guarde su trabajo local. Si desea conservar una copia independiente desde MYG,
   use **Guardar copia local**. Cierre MYG antes de actualizar el ejecutable.
2. Respalde sus archivos del proyecto y las copias SQLite de trabajo. Conserve los
   vínculos y las operaciones pendientes; no es necesario borrar la caché ni las bases.
3. Descargue y extraiga el ZIP. Copie los cuatro archivos a la raíz de
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, respetando las rutas. Si tiene cambios
   propios posteriores en los archivos a reemplazar, concilie sus diferencias antes.
4. Compile con los comandos de F. Actualice MYG en las dos laptops con el resultado
   de esa compilación; copiar los `.cs` no modifica un ejecutable ya compilado.
5. Abra la misma copia vinculada que conservaba el error, con la cuenta correspondiente,
   y pulse **Sincronizar**. Un envío confirmado en el servidor puede recuperar su
   respuesta mediante el mismo UUID sin duplicar el cambio. El borrador posterior,
   si existe, queda pendiente de una siguiente sincronización.
6. Si aparece un conflicto de revisión real, resuélvalo explícitamente conservando
   una copia de los cambios locales. Reordenar claves JSON ya no provoca ese error.

## E. Configuración adicional

Se mantiene .NET SDK 10.0.100 y las referencias existentes. No hay paquetes nuevos,
migraciones SQL, cambios de cuentas ni cambios de permisos para aplicar este parche.
Las vinculaciones MYG/Supabase y el bucket privado existentes se conservan.

## F. Compilación y validación

Desde la raíz de la solución:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release
```

Los paquetes Revit son referencias para compilación; la ejecución real de Revit
requiere Windows y Revit 2027. En una estación con las DLL locales se puede usar
la configuración de compilación habitual del repositorio.

Validación de esta corrección:

- Solución completa Release: cero errores y cero advertencias.
- Suite general existente: 566 comprobaciones correctas.
- Suite de nube: 787 comprobaciones HTTP, 110 de sincronización, 61 de adjuntos
  y 25 de portabilidad correctas, con HTTP simulado y SQLite real.
- Regresión nueva: 6 casos y 29 comprobaciones correctas. Acepta claves JSON en
  diferente orden y `1` equivalente a `1.0000`; rechaza cambios reales en listas y
  decimales incluso cuando una conversión a `double` perdería su diferencia.
- Se conserva el UUID/cuerpo de una operación enviada al guardar y reabrir SQLite;
  un ACK anterior no reemplaza un borrador posterior ni confirma otra operación.

La normalización de claves se contrastó con PostgreSQL JSONB en PGlite 0.3.14.
La prueba nueva se repite sin Node.js ni conexión a Supabase. No se consultó el
servidor real del usuario ni se ejecutó la UI de Windows en este entorno Linux.
Después de instalar, repita la sincronización entre las dos cuentas en sus laptops.

## G. Publicación del código

Revise la corrección en **Cambios de Git** de Visual Studio, haga Commit y después
Push a `bimchimbote-droid/MYG.Presupuestos`, rama `main`, cuando decida publicarla.
La publicación autorizada de esta entrega solo agrega el ZIP a DESCARGAS.

## H. Alcance pendiente

Este parche mantiene el ingreso MYG y el ingreso de nube actuales. El mensaje de
confirmación reproducido no demuestra que se haya cerrado una sesión. Si después
de aplicar el parche sigue apareciendo una desconexión, anote su mensaje exacto y
el momento para distinguir la validación de licencia de la autenticación de nube.
La unificación del ingreso requiere un intercambio de identidad verificado en el
servidor; no se reemplaza por confiar en el nombre de usuario desde el escritorio.
