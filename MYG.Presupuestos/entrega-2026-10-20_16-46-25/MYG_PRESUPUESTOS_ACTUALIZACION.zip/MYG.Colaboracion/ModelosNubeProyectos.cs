#nullable enable
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>Proyecto visible para la identidad autenticada. El listado no descarga su contenido.</summary>
public sealed record ProyectoNube(
    [property: JsonPropertyName("id")] Guid Id,
    [property: JsonPropertyName("codigo")] string Codigo,
    [property: JsonPropertyName("nombre")] string Nombre,
    [property: JsonPropertyName("rol")] string Rol,
    [property: JsonPropertyName("revision")] long Revision,
    [property: JsonPropertyName("alcance")] string Alcance,
    [property: JsonPropertyName("contenido")] JsonElement Contenido)
{
    [JsonPropertyName("permisos_modulos")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public MYGPermisosModulos? PermisosModulos { get; init; }
}

public sealed record MiembroNube(
    [property: JsonPropertyName("usuario_id")] string UsuarioId,
    [property: JsonPropertyName("rol")] string Rol)
{
    [JsonPropertyName("usuario_myg")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? UsuarioMyg { get; init; }

    [JsonPropertyName("permisos_modulos")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public MYGPermisosModulos? PermisosModulos { get; init; }

    /// <summary>
    /// Usa el nombre de la sesión MYG verificada únicamente para su mismo UUID.
    /// Para los demás miembros, el nombre debe proceder del servidor.
    /// </summary>
    public string? ObtenerUsuarioMyg(string? usuarioIdSesion, string? usuarioMygSesion)
    {
        if (!string.IsNullOrWhiteSpace(usuarioMygSesion)
            && Guid.TryParse(UsuarioId, out Guid miembro) && miembro != Guid.Empty
            && Guid.TryParse(usuarioIdSesion, out Guid sesion) && sesion == miembro)
            return usuarioMygSesion.Trim();
        return string.IsNullOrWhiteSpace(UsuarioMyg) ? null : UsuarioMyg;
    }
}

public sealed record SolicitudNube(
    [property: JsonPropertyName("usuario_id")] string UsuarioId,
    [property: JsonPropertyName("estado")] string Estado);

/// <summary>La revisión y el contenido siempre corresponden al estado confirmado por el servidor.</summary>
public sealed record RespuestaGuardarNube(
    [property: JsonPropertyName("estado")] string Estado,
    [property: JsonPropertyName("revision")] long Revision,
    [property: JsonPropertyName("contenido")] JsonElement Contenido,
    [property: JsonPropertyName("operacion_id")] Guid OperacionId);
