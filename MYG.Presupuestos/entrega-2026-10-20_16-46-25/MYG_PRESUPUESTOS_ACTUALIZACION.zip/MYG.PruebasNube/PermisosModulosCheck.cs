using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class PermisosModulosCheck
{
    private static readonly Guid ProyectoId = Guid.Parse("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa");
    private static readonly Guid UsuarioId = Guid.Parse("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb");
    private const string Servidor = "https://permisos.supabase.co";
    private static int comprobaciones;

    public static async Task RunAsync()
    {
        comprobaciones = 0;
        ModeloYCopia();
        NombresMiembros();
        await LecturaProyectos();
        await LecturaMiembros();
        await PermisosInvalidos();
        await CompartirYActualizar();
        await EntradasInvalidas();
        await RespuestasAdministrativas();
        await RenovacionConservaCuerpo();
        Console.WriteLine($"OK Permisos por módulo: 9 casos y {comprobaciones} comprobaciones; HTTP simulado, sin red.");
    }

    private static void Exige(bool condicion, string mensaje)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Permisos por módulo: " + mensaje);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException ex) { comprobaciones++; return ex; }
        throw new InvalidOperationException("Permisos por módulo: faltó rechazar la operación.");
    }

    private static HttpResponseMessage Json(object dato, HttpStatusCode estado = HttpStatusCode.OK) =>
        Texto(JsonSerializer.Serialize(dato), estado);

    private static HttpResponseMessage Texto(string json, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    { Content = new StringContent(json, Encoding.UTF8, "application/json") };

    private static object Sesion() => new
    {
        access_token = "acceso_prueba", refresh_token = "refresco_prueba", expires_in = 3600,
        user = new { id = UsuarioId }, usuario_myg = "propietario"
    };

    private static async Task<(ClienteSupabase Cliente, Transporte Transporte)> Conectar()
    {
        var transporte = new Transporte();
        var cliente = new ClienteSupabase(Servidor, "sb_publishable_permisos_prueba", transporte);
        transporte.Paso(_ => Json(Sesion()));
        await cliente.IniciarSesionMygAsync(new TicketNubeMYG("cabecera.cuerpo.firma", "propietario",
            Servidor, DateTimeOffset.UtcNow.AddSeconds(60)));
        return (cliente, transporte);
    }

    private static JsonObject Proyecto() => new()
    {
        ["id"] = ProyectoId.ToString("D"), ["codigo"] = "MYG-PERMISOS", ["nombre"] = "Proyecto",
        ["rol"] = "editor", ["revision"] = 3, ["alcance"] = "obra", ["contenido"] = new JsonObject()
    };

    private static MYGPermisosModulos Restricciones() => new()
    { Acu = false, Especificaciones = true, MetradosExcel = false };

    private static void ModeloYCopia()
    {
        var legado = new MYGPermisosModulos();
        Exige(legado.Acu && legado.Especificaciones && legado.MetradosExcel, "Los valores legado cambiaron.");
        var original = Restricciones();
        var copia = original.Copiar(); copia.Acu = true;
        Exige(!original.Acu && copia.Acu, "La copia comparte estado mutable.");
        Exige(!original.Permite("editor", "acu") && original.Permite("editor", "especificaciones")
            && !original.Permite("editor", "metrados_excel"), "No se respetan permisos individuales.");
        Exige(!original.Permite("lector", "especificaciones") && !original.Permite("desconocido", "acu"),
            "Un lector o rol desconocido recibió edición.");
        Exige(!original.Permite("propietario", "acu") && !original.Permite("administrador", "acu")
            && original.Permite("administrador", "especificaciones"), "Un rol escritor ignoró la máscara explícita.");
        using var json = JsonDocument.Parse(JsonSerializer.Serialize(original));
        Exige(json.RootElement.EnumerateObject().Count() == 3 && !json.RootElement.GetProperty("acu").GetBoolean()
            && json.RootElement.GetProperty("especificaciones").GetBoolean()
            && !json.RootElement.GetProperty("metrados_excel").GetBoolean(), "Contrato JSON incorrecto.");
        using var miembroLegado = JsonDocument.Parse(JsonSerializer.Serialize(new MiembroNube(UsuarioId.ToString("D"), "editor")));
        Exige(!miembroLegado.RootElement.TryGetProperty("permisos_modulos", out _)
            && !miembroLegado.RootElement.TryGetProperty("usuario_myg", out _),
            "Serializar un modelo legado produjo permisos nulos incompatibles con el contrato.");
    }

    private static void NombresMiembros()
    {
        string actual = UsuarioId.ToString("D");
        string otro = "cccccccc-cccc-4ccc-8ccc-cccccccccccc";
        var propio = new MiembroNube(actual, "editor");
        var ajeno = new MiembroNube(otro, "propietario");
        Exige(propio.ObtenerUsuarioMyg(actual, "propietario") == "propietario",
            "El mismo UUID no usa su usuario MYG verificado de sesión.");
        Exige(propio.ObtenerUsuarioMyg(actual.ToUpperInvariant(), "área 😃") == "área 😃",
            "La identidad depende de mayúsculas o altera un nombre Unicode.");
        Exige(propio.ObtenerUsuarioMyg("{" + actual + "}", "propietario") == "propietario",
            "Una representación equivalente de UUID no identifica al miembro.");
        Exige(ajeno.ObtenerUsuarioMyg(actual, "propietario") is null,
            "Se asignó el usuario actual a un miembro distinto por su rol.");
        Exige(propio.ObtenerUsuarioMyg(null, "propietario") is null
            && propio.ObtenerUsuarioMyg(actual, null) is null
            && propio.ObtenerUsuarioMyg(actual, "  ") is null,
            "Una sesión sin identidad completa inventó un nombre.");
        var informado = ajeno with { UsuarioMyg = "colaborador" };
        Exige(informado.ObtenerUsuarioMyg(actual, "propietario") == "colaborador"
            && informado.ObtenerUsuarioMyg(null, null) == "colaborador",
            "Se ignoró el nombre del otro miembro recibido del servidor.");
        var contradictorio = propio with { UsuarioMyg = "nombre_anterior" };
        Exige(contradictorio.ObtenerUsuarioMyg(actual, "propietario") == "propietario",
            "Un nombre antiguo del listado sustituyó la identidad verificada de sesión.");
        Exige(contradictorio.ObtenerUsuarioMyg(otro, "otra_cuenta") == "nombre_anterior",
            "La sesión de otro UUID sobrescribió el nombre explícito.");
        var falso = new MiembroNube("no-es-uuid", "editor");
        Exige(falso.ObtenerUsuarioMyg("no-es-uuid", "propietario") is null,
            "Dos identificadores inválidos iguales se trataron como una identidad verificada.");
        var vacio = new MiembroNube(Guid.Empty.ToString("D"), "editor");
        Exige(vacio.ObtenerUsuarioMyg(Guid.Empty.ToString("D"), "propietario") is null,
            "El UUID vacío se trató como una identidad verificada.");
        Exige((propio with { UsuarioMyg = " " }).ObtenerUsuarioMyg(null, null) is null,
            "Un nombre vacío se presentó como usuario MYG conocido.");
        Exige(propio.UsuarioMyg is null && informado.UsuarioMyg == "colaborador",
            "Resolver un nombre modificó los metadatos del miembro.");
    }

    private static async Task LecturaProyectos()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso(_ => Json(new[] { Proyecto() }));
            var lista = await cliente.ListarProyectosAsync();
            Exige(lista[0].PermisosModulos is null, "La ausencia de permisos no identifica al servidor legado.");
            for (int mascara = 0; mascara < 8; mascara++)
            {
                var permisos = new MYGPermisosModulos
                { Acu = (mascara & 1) != 0, Especificaciones = (mascara & 2) != 0, MetradosExcel = (mascara & 4) != 0 };
                var proyecto = Proyecto();
                proyecto["permisos_modulos"] = JsonSerializer.SerializeToNode(permisos);
                transporte.Paso(_ => Json(proyecto));
                var abierto = await cliente.AbrirProyectoAsync(ProyectoId);
                Exige(abierto.PermisosModulos is { } p && p.Acu == permisos.Acu
                    && p.Especificaciones == permisos.Especificaciones && p.MetradosExcel == permisos.MetradosExcel,
                    "Se amplió o perdió un permiso devuelto por el servidor.");
                Exige(abierto.Contenido.ValueKind == JsonValueKind.Object, "Solo lectura ocultó el contenido.");
            }
            transporte.Completo();
        }
    }

    private static async Task LecturaMiembros()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso(_ => Json(new[] { new { usuario_id = UsuarioId, rol = "editor" } }));
            var legado = (await cliente.ListarMiembrosAsync(ProyectoId))[0];
            Exige(legado.UsuarioMyg is null && legado.PermisosModulos is null, "Miembro legado incompatible.");
            transporte.Paso(_ => Json(new[] { new
            { usuario_id = UsuarioId, rol = "editor", usuario_myg = "área 😃", permisos_modulos = Restricciones() } }));
            var miembro = (await cliente.ListarMiembrosAsync(ProyectoId))[0];
            Exige(miembro.UsuarioMyg == "área 😃" && miembro.PermisosModulos is { Acu: false, Especificaciones: true, MetradosExcel: false },
                "Se perdió nombre MYG o permisos del miembro.");
            foreach (string nombre in new[] { " Propietario ", "c\n" })
            {
                transporte.Paso(_ => Json(new[] { new { usuario_id = UsuarioId, rol = "editor", usuario_myg = nombre } }));
                await Rechaza(() => cliente.ListarMiembrosAsync(ProyectoId));
            }
            transporte.Paso(_ => Texto("[{\"usuario_id\":\"" + UsuarioId + "\",\"rol\":\"editor\",\"usuario_myg\":\"c\\ud800\"}]"));
            await Rechaza(() => cliente.ListarMiembrosAsync(ProyectoId));
            transporte.Completo();
        }
    }

    private static async Task PermisosInvalidos()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            foreach (string invalido in new[] { "null", "true", "[]", "{}", "{\"acu\":false}",
                "{\"acu\":false,\"especificaciones\":true,\"metrados_excel\":null}",
                "{\"acu\":\"false\",\"especificaciones\":true,\"metrados_excel\":false}",
                "{\"acu\":0,\"especificaciones\":true,\"metrados_excel\":false}",
                "{\"acu\":false,\"especificaciones\":true,\"metrados_excel\":false,\"otro\":true}",
                "{\"acu\":false,\"acu\":true,\"especificaciones\":true,\"metrados_excel\":false}" })
            {
                string proyecto = Proyecto().ToJsonString();
                string respuesta = proyecto[..^1] + ",\"permisos_modulos\":" + invalido + "}";
                transporte.Paso(_ => Texto(respuesta));
                var error = await Rechaza(() => cliente.AbrirProyectoAsync(ProyectoId));
                Exige(error.EsErrorDeConexion, "Un permiso malformado se admitió como editable.");
                transporte.Paso(_ => Texto("[{\"usuario_id\":\"" + UsuarioId + "\",\"rol\":\"editor\",\"permisos_modulos\":" + invalido + "}]"));
                await Rechaza(() => cliente.ListarMiembrosAsync(ProyectoId));
            }
            transporte.Completo();
        }
    }

    private static async Task RevisarPeticion(HttpRequestMessage solicitud, string funcion, int campos)
    {
        Exige(solicitud.Method == HttpMethod.Post && solicitud.RequestUri?.AbsolutePath == "/rest/v1/rpc/" + funcion,
            "Endpoint o método incorrecto.");
        Exige(solicitud.Headers.Authorization?.Parameter == "acceso_prueba", "No se autenticó la administración.");
        using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync());
        var raiz = cuerpo.RootElement;
        Exige(raiz.EnumerateObject().Count() == campos && raiz.GetProperty("p_id").GetGuid() == ProyectoId,
            "Se enviaron campos o proyecto incorrectos.");
        var permisos = raiz.GetProperty("p_permisos_modulos");
        Exige(permisos.EnumerateObject().Count() == 3 && !permisos.GetProperty("acu").GetBoolean()
            && permisos.GetProperty("especificaciones").GetBoolean()
            && !permisos.GetProperty("metrados_excel").GetBoolean(), "Se cambiaron los permisos solicitados.");
    }

    private static async Task CompartirYActualizar()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            transporte.Paso(async solicitud =>
            {
                await RevisarPeticion(solicitud, "myg_nube_compartir_usuario", 4);
                using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync());
                Exige(cuerpo.RootElement.GetProperty("p_usuario_myg").GetString() == "área 😃"
                    && cuerpo.RootElement.GetProperty("p_rol").GetString() == "editor", "No normalizó al destinatario MYG.");
                return Json(new { estado = "actualizada" });
            });
            await cliente.CompartirConUsuarioMygAsync(ProyectoId, " ÁREA 😃 ", "editor", Restricciones());
            transporte.Paso(async solicitud =>
            {
                await RevisarPeticion(solicitud, "myg_nube_permisos", 3);
                using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync());
                Exige(cuerpo.RootElement.GetProperty("p_usuario").GetGuid() == UsuarioId, "Se cambió el destinatario UUID.");
                return Json(new { estado = "actualizada" });
            });
            await cliente.CambiarPermisosMiembroAsync(ProyectoId, UsuarioId.ToString("D"), Restricciones());
            Exige(cliente.UsuarioId == UsuarioId.ToString("D") && cliente.UsuarioMygSesion == "propietario",
                "Compartir cambió la identidad de la sesión.");
            transporte.Completo();
        }
    }

    private static async Task EntradasInvalidas()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            int peticiones = transporte.Peticiones;
            foreach (string nombre in new[] { "", "  ", "c\nusuario", "c\ud800", new string('a', 257) })
                await Rechaza(() => cliente.CompartirConUsuarioMygAsync(ProyectoId, nombre, "editor", Restricciones()));
            foreach (string rol in new[] { "propietario", "inventado", "Editor" })
                await Rechaza(() => cliente.CompartirConUsuarioMygAsync(ProyectoId, "colaborador", rol, Restricciones()));
            await Rechaza(() => cliente.CompartirConUsuarioMygAsync(Guid.Empty, "colaborador", "editor", Restricciones()));
            await Rechaza(() => cliente.CompartirConUsuarioMygAsync(ProyectoId, "colaborador", "editor", null!));
            await Rechaza(() => cliente.CambiarPermisosMiembroAsync(ProyectoId, "colaborador", Restricciones()));
            await Rechaza(() => cliente.CambiarPermisosMiembroAsync(Guid.Empty, UsuarioId.ToString("D"), Restricciones()));
            await Rechaza(() => cliente.CambiarPermisosMiembroAsync(ProyectoId, UsuarioId.ToString("D"), null!));
            Exige(transporte.Peticiones == peticiones, "Una entrada inválida envió solicitudes.");
            transporte.Completo();
        }
    }

    private static async Task RespuestasAdministrativas()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            foreach (object respuesta in new object[] { true, false, new { }, new { estado = "recibida" }, new { estado = "aplicada" } })
            {
                transporte.Paso(_ => Json(respuesta));
                await Rechaza(() => cliente.CompartirConUsuarioMygAsync(ProyectoId, "colaborador", "editor", Restricciones()));
                transporte.Paso(_ => Json(respuesta));
                await Rechaza(() => cliente.CambiarPermisosMiembroAsync(ProyectoId, UsuarioId.ToString("D"), Restricciones()));
            }
            foreach (string codigo in new[] { "42501", "PGRST202", "42883" })
            {
                transporte.Paso(_ => Json(new { code = codigo, message = "secreto_remoto" },
                    codigo == "42501" ? HttpStatusCode.Forbidden : HttpStatusCode.NotFound));
                var error = await Rechaza(() => cliente.CompartirConUsuarioMygAsync(ProyectoId, "colaborador", "editor", Restricciones()));
                Exige(!error.Message.Contains("secreto_remoto") && cliente.UsuarioMygSesion == "propietario",
                    "Se reveló cuerpo remoto o se cambió identidad tras un rechazo.");
                Exige(error.Codigo == codigo && (codigo != "42501" || error.AccesoDenegado),
                    "Se confundió la falta del backend con una confirmación de permisos.");
                if (codigo is "PGRST202" or "42883")
                {
                    Exige(!error.AccesoDenegado && !error.NecesitaIniciarSesion
                        && error.Message.Contains("gestión por usuario MYG y permisos por módulo")
                        && error.Message.Contains("Actualice el backend"),
                        "El backend faltante no tiene un diagnóstico específico o se presentó como acceso denegado.");
                    transporte.Paso(_ => Json(new { code = codigo, message = "secreto_remoto" }, HttpStatusCode.NotFound));
                    var errorPermisos = await Rechaza(() => cliente.CambiarPermisosMiembroAsync(ProyectoId,
                        UsuarioId.ToString("D"), Restricciones()));
                    Exige(errorPermisos.Codigo == codigo && !errorPermisos.AccesoDenegado
                        && errorPermisos.Message.Contains("Actualice el backend")
                        && !errorPermisos.Message.Contains("secreto_remoto"),
                        "El cambio de permisos no explicó la instalación faltante del backend.");
                }
            }
            transporte.Completo();
        }
    }

    private static async Task RenovacionConservaCuerpo()
    {
        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            string? original = null;
            var permisos = Restricciones();
            transporte.Paso(async solicitud =>
            {
                original = await solicitud.Content!.ReadAsStringAsync();
                permisos.Acu = true;
                return Json(new { }, HttpStatusCode.Unauthorized);
            });
            transporte.Paso(solicitud =>
            {
                Exige(solicitud.RequestUri?.PathAndQuery == "/auth/v1/token?grant_type=refresh_token", "No renovó la sesión.");
                return Json(Sesion());
            });
            transporte.Paso(async solicitud =>
            {
                Exige(await solicitud.Content!.ReadAsStringAsync() == original, "El reintento cambió permisos o usuario.");
                return Json(new { estado = "actualizada" });
            });
            await cliente.CompartirConUsuarioMygAsync(ProyectoId, "colaborador", "editor", permisos);
            transporte.Completo();
        }
    }

    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<Func<HttpRequestMessage, Task<HttpResponseMessage>>> pasos = new();
        public int Peticiones { get; private set; }
        public void Paso(Func<HttpRequestMessage, HttpResponseMessage> accion) => pasos.Enqueue(r => Task.FromResult(accion(r)));
        public void Paso(Func<HttpRequestMessage, Task<HttpResponseMessage>> accion) => pasos.Enqueue(accion);
        public void Completo() => Exige(pasos.Count == 0, "Quedaron solicitudes de prueba sin ejecutar.");
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Peticiones++;
            Exige(pasos.Count > 0, "Se envió una petición inesperada.");
            return pasos.Dequeue()(request);
        }
    }
}
