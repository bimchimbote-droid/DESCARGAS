# Mostrar usuario MYG en la lista de miembros

Actualización incremental sobre la entrega de colaboradores/permisos publicada
en `bimchimbote-droid/DESCARGAS`, commit
`a0d406d6f96eaea07abc7f90ba09c28d05ed2468`.
El código base sigue siendo `main` de MYG.Presupuestos en
`67fb617f41203957eb2fb275e7decd4645aa4c1e`, más esa entrega anterior.

## Comportamiento

- La columna se llama **Usuario MYG**.
- Para la cuenta actual se usa el usuario MYG de su sesión verificada,
  únicamente cuando coincide el UUID del miembro. El nombre no se asigna a
  otras filas por su posición, rol o proyecto.
- Para los demás miembros se muestra `usuario_myg` recibido de Supabase.
- Cuando falta esa información se muestra **Usuario MYG no disponible** y
  se avisa cuántos nombres faltan. El UUID queda interno para gestionar roles;
  puede consultarse pasando el cursor sobre una celda sin nombre.
- El diálogo de permisos utiliza el mismo criterio.
- La respuesta de colaboración se revalida contra la cuenta que inició la
  consulta, como en la entrega anterior.

Esto permite mostrar el nombre de la cuenta actual con el servidor anterior.
**Los nombres reales de los otros miembros requieren que Supabase los
devuelva.** No se inventaron nombres ni se modificaron datos de cuentas.

## Aplicación manual

1. Respaldar o confirmar los cambios locales antes de copiar.
2. Aplicar esta actualización sobre la entrega anterior de 37 archivos.
3. Copiar los tres archivos existentes completos y crear este documento,
   conservando las rutas. Comparar primero cualquier cambio propio posterior.
4. Desde la raíz, compilar y validar:

```text
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
```

Se mantiene .NET SDK 10.0.100 y las dependencias existentes; no hay migraciones,
parches ni eliminaciones en esta actualización. La interfaz se comprueba
manualmente en Windows: abrir Nube MYG, cargar colaboración y verificar que
el miembro de la cuenta actual muestra su usuario MYG, que otros nombres
recibidos se conservan y que las filas sin nombre muestran el aviso.

Validación realizada: solución completa compilada con 0 errores y 0
advertencias; suite de nube aprobada con 26 grupos, incluidos 9 casos de
permisos y 191 comprobaciones en esa suite específica.

Las pruebas de nube usan HTTP simulado y SQLite real. No se ejecutó la interfaz
Windows ni se consultó el Supabase de producción desde este entorno.

## Obtener los nombres de los demás miembros

En el proyecto Supabase, abrir **SQL Editor**, pegar y ejecutar el archivo
`supabase/InspeccionarColaboracion.sql` de la entrega anterior. Exportar el
resultado y adjuntarlo en la conversación. Esa consulta de solo lectura permite
conocer la función `myg_nube_miembros` y la estructura de las vinculaciones para
preparar el cambio de servidor sin adivinar tablas. No consulta filas de obras.

No publicar ese resultado en DESCARGAS. No son necesarias claves API ni
contraseñas para compartir la estructura solicitada.

## Revisión del código

En Visual Studio abrir **Cambios de Git**, revisar el diff, compilar y hacer
Commit/Push a la rama elegida cuando se decida publicar. Esta entrega publica
solo el ZIP en DESCARGAS y conserva el repositorio del código sin Push.
