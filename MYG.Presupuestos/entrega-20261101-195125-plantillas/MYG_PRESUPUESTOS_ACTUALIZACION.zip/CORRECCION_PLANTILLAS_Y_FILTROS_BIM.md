# Corrección de plantillas Revit y llenado rápido de filtros BIM

Aplicar sobre la actualización de modeladores BIM ya entregada (ZIP publicado en DESCARGAS, commit `25d74d6a9f36bb80ce8c652b05584ab3b0b84bce`). La rama remota main se comprobó en `a3130eca22fb423fbe7aae665a02dccdb379522c`. Este ZIP es incremental: sólo contiene los archivos cambiados respecto de aquella entrega, completos y con sus rutas originales.

## Qué corrige
- Se reprodujo el rechazo mostrado al elegir una plantilla: la reconstrucción BIM renumeraba/normalizaba un presupuesto nativo aun cuando sólo cambiaban filtros. Ahora esas ediciones conservan numeración, posiciones, identidades y costos. La validación estructural permanece para las altas.
- Un rechazo de permiso o validación restaura la fila y muestra el motivo sin dejar salir una excepción del evento de edición ni reconstruir la ventana completa.
- Actualizar plantillas siempre consulta los documentos abiertos actuales. Si hay uno, conecta directamente; si hay varios, permite elegir por nombre, ruta e identidad, incluso entre archivos abiertos en una sola instancia de Revit. Cancelar o fallar conserva la conexión anterior.
- El descubrimiento solicita sólo metadatos; las plantillas se cargan del modelo elegido. Las consultas de información tienen un plazo de 10 segundos para no esperar indefinidamente a un Revit ocupado.

## Flujo rápido
1. Pulse **Actualizar plantillas** y, sólo si corresponde, elija el archivo de Revit.
2. Un clic abre el desplegable. Al elegir plantilla, parámetro o regla, se confirma la selección y avanza al siguiente campo.
3. Hay autocompletado; si el parámetro sólo admite una regla se completa automáticamente. También puede escribir valores manualmente y moverse con Tab.
4. El desplegable de Valor consulta Revit sin bloquear la ventana y conserva lo que esté escribiendo. Reutiliza la consulta por instancia, documento, plantilla y parámetro. **Actualizar plantillas** limpia esa caché para volver a consultar datos recientes. Si falla una consulta, puede escribir el valor y volver a intentar.
5. El botón **Editar filtros en lote** también ofrece parámetros/reglas del modelo. Agregar inicia filas vacías; Modificar carga sólo el filtro de la posición elegida; Reemplazar mantiene el conjunto actual. No necesita borrar manualmente los otros siete filtros para modificar uno.
6. La confirmación comprueba sólo la fila editada. El historial se captura cuando realmente cambia un dato, no al abrir cada desplegable; se conservan los permisos del módulo y las operaciones por lote.

## Instalar
1. Cierre MYG y **todas las ventanas de Revit**. Respalde o confirme sus cambios locales. Compare los archivos si su versión cambió después de la entrega anterior; reemplazarlos completos puede perder modificaciones propias posteriores.
2. Extraiga el ZIP en una carpeta temporal y copie los archivos a la raíz del repositorio, conservando las rutas. No sustituya bases SQLite ni sidecars de nube.
3. Restaure y compile con SDK .NET 10 y Visual Studio compatible. En Windows con Revit 2027 instalado:

```powershell
dotnet restore MYG.Presupuestos.sln
dotnet build MYG.Presupuestos.sln -c Release
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Actualizar-Conector.ps1
```

El último comando es obligatorio para consultar varios documentos de una misma instancia: reconstruye e instala el conector y MYG.Core actuales. Si Revit está en otra ubicación, use el parámetro `-RevitInstallDir` del script existente. Abra Revit de nuevo y ejecute la aplicación recompilada. No use una carpeta dist antigua.

## Configuración y compatibilidad
No hay paquetes nuevos, cambios de permisos ni migraciones SQL adicionales. Mantenga la configuración MYG Nube y las bases actuales. Un conector anterior conserva la consulta del modelo activo, pero no expone todos los documentos de la misma instancia; actualícelo para usar la selección completa.

Consultar plantillas/valores de otro documento no lo activa ni modifica. Para crear, revisar o actualizar tablas/activos sigue siendo necesario activar en Revit el documento seleccionado. No se cambia ese control de identidad.

## Validación y límites
La regresión se reprodujo primero con una prueba fallida antes de la corrección. La prueba posterior selecciona una plantilla y completa el filtro campo a campo sobre una partida con numeración nativa y precio, comprobando que no cambien sus otros datos.

Comandos de validación en Linux:

```text
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --modeladores-bim
```

Se añadieron pruebas visuales para restauración de fila, selección automática del único modelo y edición de plantilla/parámetro/regla/valor. Compilan en Linux; su ejecución requiere Windows. No se ha ejecutado la interfaz ni una sesión real de Revit en este entorno. En Windows pruebe uno y dos modelos, incluidos dos en el mismo proceso; cancelar selector; editar/guardar/reabrir filtros; revocar permiso; cambiar de modelo con consultas pendientes y actualizar la caché tras modificar el modelo. La suite general de nube mantiene el fallo preexistente de PublicacionLigeraCheck; no se ha desactivado ni se declara aprobada completa.

## Publicar el código después de aplicar
En Visual Studio use **Cambios de Git**, revise los archivos, ejecute las comprobaciones de Windows, haga Commit y luego Push a su rama main. Esta entrega sólo publica el ZIP en DESCARGAS; no hace Push ni fusiona cambios del repositorio del código.

## Archivos

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `CORRECCION_PLANTILLAS_Y_FILTROS_BIM.md` | CREAR | Instalación, límites y relación completa de archivos |
| 2 | `MYG.Colaboracion/BimNube.cs` | REEMPLAZAR | Conserva numeración y costos al editar plantillas/filtros existentes |
| 3 | `MYG.Core/Protocolo.cs` | REEMPLAZAR | Listado ligero y selección de documentos de Revit |
| 4 | `MYG.Desktop/BimFiltrosMasivosForm.cs` | REEMPLAZAR | Desplegables y carga rápida de la operación en lote |
| 5 | `MYG.Desktop/EditorFiltrosRapidosBim.cs` | CREAR | Edición inmediata, avance y caché aislada de valores |
| 6 | `MYG.Desktop/EditorForm.cs` | REEMPLAZAR | Selección de modelo y confirmación segura de desplegables |
| 7 | `MYG.Desktop/EditorModeladoresBim.cs` | REEMPLAZAR | Validación por fila e historial sólo de cambios reales |
| 8 | `MYG.Pruebas/ModeladoresBimCoreCheck.cs` | REEMPLAZAR | Pruebas del protocolo y compatibilidad de documentos |
| 9 | `MYG.PruebasNube/CopiaSqliteNubeCheck.cs` | REEMPLAZAR | Regresión de edición campo a campo sobre partida nativa |
| 10 | `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Invocación de la regresión de plantilla nativa |
| 11 | `MYG.PruebasUI/ModeladoresBimUICheck.cs` | REEMPLAZAR | Pruebas visuales compiladas de edición segura y modelo único |
| 12 | `MYG.Revit2027/Aplicacion.cs` | REEMPLAZAR | Consulta de documentos/plantillas/valores sin cambiar modelo activo |

## Resultado final

- Solución Release, SDK .NET 10.0.100: **0 errores y 0 advertencias**.
- Suite principal: **807 comprobaciones aprobadas**; incluye compatibilidad del listado de modelos y protocolo anterior. Las muestras externas y Named Pipes Windows se omiten explícitamente en Linux.
- Regresión de plantilla/filtros nativos: **aprobada**, después de reproducirse el fallo original.
- Transporte BIM con SQLite real y HTTP simulado: **aprobado**, incluidos ACK perdido, reintentos, conservación de edición posterior y CAS local.
- Pruebas UI nuevas compiladas; ejecución visual y Revit real pendientes de Windows.
