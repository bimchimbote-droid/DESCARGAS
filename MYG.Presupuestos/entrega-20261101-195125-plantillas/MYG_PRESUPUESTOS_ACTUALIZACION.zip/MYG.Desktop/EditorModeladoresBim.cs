using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using MYG.Colaboracion;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private static bool EsColumnaInternaBim(string nombre) => nombre is
        "CODIGO" or "CODIGO_DELPHIN" or "ID_PROPUESTA" or "ORIGEN" or "ESTADO";

    private string PadreNuevaPartidaBim()
    {
        var seleccion = Seleccionadas.FirstOrDefault();
        return MYGProyectoStorage.EsTitulo(seleccion) ? seleccion.Id : seleccion?.ParentId;
    }

    private void NuevaPartidaBimTexto()
    {
        ExigirPermisoMetradosRevit();
        if (P == null) throw new InvalidOperationException("Seleccione un presupuesto.");
        using var dialogo = new MYGCamposProyectoForm("Nueva partida BIM de texto",
            new[] { "Descripción", "Unidad" }, new[] { "", MYGParametrosUsuario.Leer().UnidadPartida },
            unidades: MYGCatalogoUnidades.Listar(RutaCatalogoPropio()), conservarUnidadInicial: true);
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        string presupuestoId = P.Id, padre = PadreNuevaPartidaBim();
        AplicarCambioModeladoresBim(candidato => MYGPartidasBim.CrearTexto(candidato, presupuestoId,
            dialogo.Valores[0], dialogo.Valores[1], padre, vinculoNube?.PermisosModulos,
            vinculoNube?.Rol ?? "propietario"));
    }

    private void NuevaPartidaBimCatalogo()
    {
        ExigirPermisoMetradosRevit();
        if (P == null) throw new InvalidOperationException("Seleccione un presupuesto.");
        using var dialogo = new BimPartidasForm(RutaCatalogoPropio());
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        string presupuestoId = P.Id, padre = PadreNuevaPartidaBim();
        AplicarCambioModeladoresBim(candidato => MYGPartidasBim.CrearCatalogo(candidato, presupuestoId,
            dialogo.Ruta, dialogo.Seleccionada, padre, vinculoNube?.PermisosModulos,
            vinculoNube?.Rol ?? "propietario"));
    }

    private void EditarFiltrosMasivosBim()
    {
        ExigirPermisoMetradosRevit();
        var seleccion = Seleccionadas.Where(i => !MYGProyectoStorage.EsTitulo(i)).ToList();
        if (P == null || seleccion.Count == 0) throw new InvalidOperationException("Seleccione una o varias partidas con Ctrl o Mayús.");
        using var dialogo = new BimFiltrosMasivosForm(seleccion.Count, seleccion[0], modelo);
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        string presupuestoId = P.Id;
        string[] ids = seleccion.Select(i => i.Id).ToArray();
        AplicarCambioModeladoresBim(candidato => MYGEdicionMasivaFiltrosBim.Aplicar(candidato,
            presupuestoId, ids, dialogo.Operacion, dialogo.Filtros, dialogo.Plantilla,
            dialogo.CambiarPlantilla, vinculoNube?.PermisosModulos, vinculoNube?.Rol ?? "propietario", dialogo.Indice));
        estado.Text = "Configuración aplicada a " + ids.Length + " partida(s). Guarde y sincronice la obra para compartir los cambios.";
    }

    private static void ExigirCambioSoloBim(MYGProyectoDocumento anterior, MYGProyectoDocumento candidato)
    {
        MYGCambiosModulosNube.ExigirPermitidos(anterior, candidato, new MYGPermisosModulos
        { Acu = false, Especificaciones = false, MetradosExcel = false, MetradosRevit = true });
        var reconstruido = BimNube.Aplicar(anterior, BimNube.Cambios(anterior, candidato));
        var esperado = MYGProyectoStorage.Copia(candidato);
        foreach (var partida in reconstruido.Presupuestos.Concat(esperado.Presupuestos).SelectMany(p => p.Items))
        { partida.EstadoRevit = null; partida.MensajeRevit = null; }
        if (MYGProyectoStorage.Firma(reconstruido) != MYGProyectoStorage.Firma(esperado))
            throw new InvalidOperationException("Esta acción también cambiaría datos fuera de las altas y filtros BIM. " +
                "Use el módulo correspondiente. El historial BIM no permite eliminar una partida creada.");
    }

    private void ExigirResultadosBimCompletos()
    {
        ExigirPermisoMetradosRevit();
        if (!PuedeActualizarResultadosBim)
            throw new InvalidOperationException("Esta obra permite compartir altas y filtros BIM con Metrados Revit. " +
                "Actualizar o federar cantidades y activos requiere permisos completos de edición de la obra.");
    }

    private void AplicarCambioModeladoresBim(Action<MYGProyectoDocumento> cambiar)
    {
        ExigirPermisoMetradosRevit();
        var candidato = MYGProyectoStorage.Copia(documento);
        cambiar(candidato);
        ExigirCambioSoloBim(documento, candidato);
        if (vinculoNube?.PermisosModulos != null)
            MYGCambiosModulosNube.ExigirPermitidos(documento, candidato, vinculoNube.PermisosModulos);
        ExigirPermisoMetradosRevit();
        Recordar(); documento = candidato;
        AsegurarColumnas(); Refrescar();
    }

    private void AplicarPermisosModeladoresBim()
    {
        grid.ReadOnly = !PuedeEditarMetradosRevit;
        foreach (Control grupo in acciones.Controls)
            foreach (Button boton in grupo.Controls.OfType<Button>())
            {
                bool consulta = boton.Text is "Expandir todo" or "Contraer todo" or "Columnas" or "Exportar presupuesto" or "Biblioteca";
                boton.Enabled = !ocupado && (consulta || PuedeEditarMetradosRevit);
            }
        foreach (Control grupo in pie.Controls)
            foreach (Button boton in grupo.Controls.OfType<Button>())
                boton.Enabled = !ocupado && (boton.Text is "Guardar" or "Abrir proyecto" ||
                    (boton.Text is "Actualizar activo" or "Federar metrados" ? PuedeActualizarResultadosBim : PuedeEditarMetradosRevit));
        ActualizarDisponibilidad();
    }

    // La tabla puede permanecer abierta mientras cambia la autorización o se
    // edita otro módulo. Sólo confirmar diferencias reales, nunca normalizar
    // una obra consultada ni modificarla antes de comprobar sus permisos.
    private bool SincronizarTablaModeladoresBim(DataGridViewRow unica = null)
    {
        var cambios = new List<(DataGridViewRow Fila, ItemPresupuestoDelphin Original, ItemPresupuestoDelphin Nuevo)>();
        foreach (DataGridViewRow fila in unica == null ? grid.Rows.Cast<DataGridViewRow>() : new[] { unica })
        {
            if (fila.Tag is not ItemPresupuestoDelphin original || MYGProyectoStorage.EsTitulo(original)) continue;
            string Celda(string nombre) => fila.Cells[nombre].Value?.ToString() ?? "";
            bool descripcion = original.CreadaParaBim && (original.Descripcion ?? "") != Celda("PARTIDA");
            bool unidad = original.CreadaParaBim && (original.Unidad ?? "") != Celda("UNIDAD");
            bool plantilla = (original.Plantilla ?? "") != Celda("PLANTILLA");
            var filtros = new List<FiltroPlanificacion>();
            for (int n = 1; n <= P.CantidadFiltros; n++)
                filtros.Add(new() { Parametro = Celda("P" + n), Regla = Celda("R" + n), Valor = Celda("V" + n) });
            var editados = MYGBibliotecaPartidas.FiltrosGuardables(new ItemPresupuestoDelphin { Filtros = filtros });
            var anteriores = MYGBibliotecaPartidas.FiltrosGuardables(original);
            bool iguales = anteriores.Count == editados.Count && anteriores.Zip(editados).All(par =>
                (par.First.Parametro ?? "") == (par.Second.Parametro ?? "") &&
                (par.First.Regla ?? "") == (par.Second.Regla ?? "") && (par.First.Valor ?? "") == (par.Second.Valor ?? ""));
            if (!descripcion && !unidad && !plantilla && iguales) continue;
            var nuevo = MYGProyectoStorage.Copia(original);
            if (descripcion) nuevo.Descripcion = Celda("PARTIDA");
            if (unidad) nuevo.Unidad = Celda("UNIDAD");
            if (plantilla) nuevo.Plantilla = Celda("PLANTILLA");
            if (!iguales)
            {
                nuevo.Filtros = editados;
                var primero = editados.FirstOrDefault();
                nuevo.Parametro = primero?.Parametro; nuevo.Regla = primero?.Regla; nuevo.Valor = primero?.Valor;
                nuevo.IdConfiguracionBibliotecaMYG = null;
            }
            cambios.Add((fila, original, nuevo));
        }
        if (cambios.Count == 0) return false;
        ExigirPermisoMetradosRevit();
        // La tabla sólo escribe estos campos BIM de la fila. Validar la fila
        // evita copiar/serializar todos los ACU de la obra en cada desplegable.
        MYGProyectoDocumento DocumentoFila(ItemPresupuestoDelphin i) => new()
        {
            Id = documento.Id, Nombre = documento.Nombre,
            Presupuestos = new() { new MYGPresupuestoDocumento { Id = P.Id, Nombre = P.Nombre, Items = new() { i } } }
        };
        foreach (var cambio in cambios)
        {
            var antes = DocumentoFila(cambio.Original);
            var despues = DocumentoFila(cambio.Nuevo);
            MYGCambiosModulosNube.ExigirPermitidos(antes, despues, new MYGPermisosModulos
                { Acu = false, Especificaciones = false, MetradosExcel = false, MetradosRevit = true });
            if (vinculoNube?.PermisosModulos != null)
                MYGCambiosModulosNube.ExigirPermitidos(antes, despues, vinculoNube.PermisosModulos);
        }
        ExigirPermisoMetradosRevit();
        Recordar();
        foreach (var cambio in cambios)
        {
            var i = cambio.Original; var nuevo = cambio.Nuevo;
            i.Descripcion = nuevo.Descripcion; i.Unidad = nuevo.Unidad; i.Plantilla = nuevo.Plantilla;
            i.Filtros = nuevo.Filtros; i.Parametro = nuevo.Parametro; i.Regla = nuevo.Regla; i.Valor = nuevo.Valor;
            i.IdConfiguracionBibliotecaMYG = nuevo.IdConfiguracionBibliotecaMYG;
            i.EstadoRevit = null; i.MensajeRevit = null;
            cambio.Fila.Cells["BIBLIOTECA"].Value = biblioteca == null ? "Revisar biblioteca" : MYGBibliotecaPartidas.Estado(biblioteca, i);
        }
        return true;
    }

    private void MenuBibliotecaBim()
    {
        var menu = CrearMenuContextual();
        ItemMenu(menu, "Guardar filtros seleccionados", () => GuardarFiltros(false));
        ItemMenu(menu, "Traer filtros seleccionados", () => TraerFiltros(true));
        ItemMenu(menu, "Elegir biblioteca existente", () =>
        {
            using var dialogo = new OpenFileDialog { Filter = "Biblioteca MYG (*.biblioteca.json;*.json)|*.biblioteca.json;*.json" };
            if (dialogo.ShowDialog(this) != DialogResult.OK) return;
            MYGProyectoStorage.LeerBiblioteca(dialogo.FileName);
            MYGIndiceLocal.RecordarBiblioteca(dialogo.FileName); CargarBiblioteca(); Refrescar();
        });
        ItemMenu(menu, "Ver ubicación", () => MessageBox.Show(this, rutaBiblioteca, "Biblioteca de filtros BIM"));
        foreach (ToolStripMenuItem opcion in menu.Items.OfType<ToolStripMenuItem>())
            if (opcion.Text is "Guardar filtros seleccionados" or "Traer filtros seleccionados")
                opcion.Enabled = PuedeEditarMetradosRevit;
        MostrarMenu(menu);
    }
}
