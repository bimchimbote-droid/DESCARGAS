using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using MYG.Externo;

namespace MYG_2027;

internal sealed class BimFiltrosMasivosForm : Form
{
    private readonly ComboBox operacion = new() { Name = "operacion_filtros_bim", DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
    private readonly CheckBox cambiarPlantilla = new() { Name = "cambiar_plantilla_bim", Text = "Asignar también esta plantilla", AutoSize = true };
    private readonly ComboBox plantilla = new() { Name = "plantilla_masiva_bim", DropDownStyle = ComboBoxStyle.DropDown, Dock = DockStyle.Fill };
    private readonly NumericUpDown indice = new() { Name = "indice_filtro_bim", Minimum = 1, Maximum = 8, Value = 1, Width = 80 };
    private readonly DataGridView tabla = new() { Name = "filtros_masivos_bim", Dock = DockStyle.Fill,
        AllowUserToAddRows = false, AllowUserToDeleteRows = false, RowHeadersVisible = false };
    internal MYGOperacionFiltrosBim Operacion => ((Opcion)operacion.SelectedItem).Operacion;
    internal bool CambiarPlantilla => cambiarPlantilla.Checked;
    internal string Plantilla => plantilla.Text.Trim();
    internal int Indice => (int)indice.Value - 1;
    internal IReadOnlyList<FiltroPlanificacion> Filtros { get; private set; } = Array.Empty<FiltroPlanificacion>();

    internal BimFiltrosMasivosForm(int cantidad, ItemPresupuestoDelphin inicial, DocumentoRevitInfo modelo)
    {
        MYGProyectoUI.Preparar(this, "Editar filtros BIM en lote", 860, 620);
        MinimumSize = new(690, 500);
        var cabecera = new TableLayoutPanel { Dock = DockStyle.Top, Height = 180, ColumnCount = 2, RowCount = 5, Padding = new(12) };
        cabecera.ColumnStyles.Add(new(SizeType.Absolute, 200)); cabecera.ColumnStyles.Add(new(SizeType.Percent, 100));
        foreach (int alto in new[] { 30, 35, 35, 35, 35 }) cabecera.RowStyles.Add(new(SizeType.Absolute, alto));
        var seleccion = new Label { Text = cantidad + " partida(s) seleccionada(s)", AutoSize = true };
        cabecera.Controls.Add(seleccion, 0, 0); cabecera.SetColumnSpan(seleccion, 2);
        cabecera.Controls.Add(new Label { Text = "Operación", AutoSize = true }, 0, 1); cabecera.Controls.Add(operacion, 1, 1);
        operacion.Items.AddRange(new object[]
        {
            new Opcion(MYGOperacionFiltrosBim.Reemplazar, "Reemplazar todos los filtros"),
            new Opcion(MYGOperacionFiltrosBim.Agregar, "Agregar al final"),
            new Opcion(MYGOperacionFiltrosBim.Modificar, "Modificar un filtro por su posición"),
            new Opcion(MYGOperacionFiltrosBim.Eliminar, "Eliminar un filtro por su posición"),
            new Opcion(MYGOperacionFiltrosBim.Limpiar, "Quitar todos los filtros")
        });
        cabecera.Controls.Add(new Label { Text = "Posición del filtro", AutoSize = true }, 0, 2); cabecera.Controls.Add(indice, 1, 2);
        cabecera.Controls.Add(cambiarPlantilla, 0, 3); cabecera.SetColumnSpan(cambiarPlantilla, 2);
        cabecera.Controls.Add(new Label { Text = "Plantilla", AutoSize = true }, 0, 4); cabecera.Controls.Add(plantilla, 1, 4);
        plantilla.Items.AddRange((modelo?.Plantillas ?? new List<string>()).Cast<object>().ToArray());
        plantilla.Text = inicial.Plantilla ?? ""; plantilla.Enabled = false;
        cambiarPlantilla.CheckedChanged += (_, _) => plantilla.Enabled = cambiarPlantilla.Checked;
        tabla.Columns.Add(new DataGridViewComboBoxColumn { Name = "PARAMETRO", HeaderText = "Parámetro", FlatStyle = FlatStyle.Flat });
        tabla.Columns.Add(new DataGridViewComboBoxColumn { Name = "REGLA", HeaderText = "Regla", FlatStyle = FlatStyle.Flat });
        tabla.Columns.Add("VALOR", "Valor");
        foreach (DataGridViewColumn columna in tabla.Columns) columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        var originales = MYGBibliotecaPartidas.FiltrosGuardables(inicial);
        for (int n = 0; n < 8; n++)
        {
            var filtro = n < originales.Count ? originales[n] : new FiltroPlanificacion();
            int fila = tabla.Rows.Add();
            foreach (var par in new[] { (0, filtro.Parametro ?? ""), (1, filtro.Regla ?? "") })
            {
                var c = (DataGridViewComboBoxCell)tabla.Rows[fila].Cells[par.Item1];
                if (!c.Items.Contains(par.Item2)) c.Items.Add(par.Item2);
                c.Value = par.Item2;
            }
            tabla.Rows[fila].Cells[2].Value = filtro.Valor;
        }
        bool actualizando = false;
        void OpcionesFila(DataGridViewRow fila)
        {
            if (actualizando) return;
            actualizando = true;
            try
            {
                void Combo(int columna, IEnumerable<string> opciones)
                {
                    var c = (DataGridViewComboBoxCell)fila.Cells[columna];
                    string valor = c.Value?.ToString() ?? "";
                    var disponibles = new[] { "", valor }.Concat(opciones).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
                    c.Value = null; c.Items.Clear(); c.Items.AddRange(disponibles); c.Value = valor;
                }
                var parametros = modelo != null && modelo.Parametros.TryGetValue(plantilla.Text, out var ps) ? ps : new List<string>();
                Combo(0, parametros);
                string parametro = fila.Cells[0].Value?.ToString() ?? "";
                var reglas = modelo != null && modelo.Reglas.TryGetValue(plantilla.Text, out var porParametro)
                    && porParametro.TryGetValue(parametro, out var rs) ? rs : new List<string>();
                Combo(1, reglas);
                if (reglas.Count == 1 && string.IsNullOrWhiteSpace(fila.Cells[1].Value?.ToString())) fila.Cells[1].Value = reglas[0];
            }
            finally { actualizando = false; }
        }
        void CargarFilas(IEnumerable<FiltroPlanificacion> valores)
        {
            var lista = valores.ToList();
            actualizando = true;
            try
            {
                for (int n = 0; n < tabla.Rows.Count; n++)
                {
                    var f = n < lista.Count ? lista[n] : new FiltroPlanificacion();
                    foreach (var par in new[] { (0, f.Parametro ?? ""), (1, f.Regla ?? "") })
                    {
                        var c = (DataGridViewComboBoxCell)tabla.Rows[n].Cells[par.Item1];
                        if (!c.Items.Contains(par.Item2)) c.Items.Add(par.Item2);
                        c.Value = par.Item2;
                    }
                    tabla.Rows[n].Cells[2].Value = f.Valor;
                }
            }
            finally { actualizando = false; }
            foreach (DataGridViewRow fila in tabla.Rows) OpcionesFila(fila);
        }
        tabla.DataError += (_, e) => e.ThrowException = false;
        tabla.CellValidating += (_, e) =>
        {
            if (tabla.Rows[e.RowIndex].Cells[e.ColumnIndex] is DataGridViewComboBoxCell c)
            { string texto = e.FormattedValue?.ToString() ?? ""; if (!c.Items.Contains(texto)) c.Items.Add(texto); }
        };
        tabla.EditingControlShowing += (_, e) =>
        {
            if (e.Control is ComboBox c)
            { c.DropDownStyle = ComboBoxStyle.DropDown; c.AutoCompleteMode = AutoCompleteMode.SuggestAppend; c.AutoCompleteSource = AutoCompleteSource.ListItems; }
        };
        tabla.CellEndEdit += (_, e) => { if (e.RowIndex >= 0 && e.ColumnIndex == 0) OpcionesFila(tabla.Rows[e.RowIndex]); };
        tabla.CellClick += (_, e) =>
        {
            if (e.RowIndex >= 0 && e.ColumnIndex is 0 or 1 && tabla.BeginEdit(true) && tabla.EditingControl is ComboBox c) c.DroppedDown = true;
        };
        plantilla.TextChanged += (_, _) => { foreach (DataGridViewRow fila in tabla.Rows) OpcionesFila(fila); };
        indice.ValueChanged += (_, _) =>
        {
            if (operacion.SelectedItem is Opcion o && o.Operacion == MYGOperacionFiltrosBim.Modificar)
                CargarFilas(originales.Skip(Indice).Take(1));
        };
        operacion.SelectedIndexChanged += (_, _) =>
        {
            bool entrada = Operacion is not (MYGOperacionFiltrosBim.Eliminar or MYGOperacionFiltrosBim.Limpiar);
            tabla.Enabled = entrada;
            indice.Enabled = Operacion is MYGOperacionFiltrosBim.Modificar or MYGOperacionFiltrosBim.Eliminar;
            CargarFilas(Operacion == MYGOperacionFiltrosBim.Reemplazar ? originales
                : Operacion == MYGOperacionFiltrosBim.Modificar ? originales.Skip(Indice).Take(1) : Array.Empty<FiltroPlanificacion>());
        };
        operacion.SelectedIndex = 0;
        var aplicar = MYGProyectoUI.Boton("Aplicar a la selección", 1); aplicar.Name = "aplicar_filtros_bim"; aplicar.AutoSize = true;
        aplicar.Click += (_, _) =>
        {
            try
            {
                tabla.EndEdit();
                var filtros = tabla.Rows.Cast<DataGridViewRow>().Select(fila => new FiltroPlanificacion
                { Parametro = fila.Cells[0].Value?.ToString()?.Trim(), Regla = fila.Cells[1].Value?.ToString()?.Trim(), Valor = fila.Cells[2].Value?.ToString() })
                    .Where(f => !f.EstaVacio()).ToList();
                if (Operacion is MYGOperacionFiltrosBim.Eliminar or MYGOperacionFiltrosBim.Limpiar) filtros.Clear();
                MYGEdicionMasivaFiltrosBim.ValidarFiltros(filtros);
                if (Operacion == MYGOperacionFiltrosBim.Modificar && filtros.Count != 1)
                    throw new InvalidOperationException("Para modificar una posición, deje exactamente un filtro en la tabla.");
                if (Operacion == MYGOperacionFiltrosBim.Agregar && filtros.Count == 0)
                    throw new InvalidOperationException("Indique los filtros que desea agregar.");
                Filtros = filtros; DialogResult = DialogResult.OK;
            }
            catch (Exception error) { MYGProyectoUI.Error(this, error); }
        };
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, FlowDirection = FlowDirection.RightToLeft, Padding = new(6) };
        pie.Controls.Add(cancelar); pie.Controls.Add(aplicar);
        Controls.Add(tabla); Controls.Add(cabecera); Controls.Add(pie);
        Controls.Add(new Label { Dock = DockStyle.Bottom, Height = 52, Padding = new(10),
            Text = "El cambio se aplica a toda la selección o se rechaza completo. Las filas vacías no agregan filtros. Para modificar una posición, indique un solo filtro." });
        AcceptButton = aplicar; CancelButton = cancelar;
    }
    private sealed record Opcion(MYGOperacionFiltrosBim Operacion, string Texto) { public override string ToString() => Texto; }
}
