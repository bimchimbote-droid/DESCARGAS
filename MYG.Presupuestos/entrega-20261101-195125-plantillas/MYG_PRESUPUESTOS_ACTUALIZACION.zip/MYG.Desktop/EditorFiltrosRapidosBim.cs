using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Externo;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private readonly Dictionary<string, Task<List<string>>> valoresRapidosBim = new();
    private int generacionValoresBim;

    private void InvalidarValoresRevit()
    {
        generacionValoresBim++;
        valoresRapidosBim.Clear();
    }

    private void PrepararEdicionRapidaBim(Control control)
    {
        if (control is not DataGridViewComboBoxEditingControl combo) return;
        combo.DropDownStyle = ComboBoxStyle.DropDown;
        combo.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
        combo.AutoCompleteSource = AutoCompleteSource.ListItems;
        combo.MaxDropDownItems = 20;
        combo.Tag = null;
        combo.SelectionChangeCommitted -= ElegidaOpcionRapidaBim;
        combo.SelectionChangeCommitted += ElegidaOpcionRapidaBim;
        combo.DropDown -= AbrirValoresRapidosBim;
        combo.DropDown += AbrirValoresRapidosBim;
    }

    private void AbrirDesplegableBim(DataGridViewCell celda)
    {
        if (cargando || ocupado || !PuedeEditarMetradosRevit || celda.ReadOnly || !celda.OwningRow.Visible) return;
        grid.CurrentCell = celda;
        if (grid.BeginEdit(true) && grid.EditingControl is DataGridViewComboBoxEditingControl combo)
            combo.DroppedDown = true;
    }

    private void ElegidaOpcionRapidaBim(object sender, EventArgs e)
    {
        var celda = grid.CurrentCell;
        if (celda == null || !IsHandleCreated) return;
        // Confirmar fuera del evento nativo del ComboBox: no sustituir su celda
        // mientras Windows todavía está procesando la selección del desplegable.
        BeginInvoke(new Action(() =>
        {
            if (IsDisposed || grid.IsDisposed || grid.CurrentCell != celda || !PuedeEditarMetradosRevit) return;
            try
            {
                if (!grid.EndEdit() || !string.IsNullOrEmpty(celda.OwningRow.ErrorText)) return;
                string nombre = celda.OwningColumn.Name;
                string siguiente = nombre == "PLANTILLA" ? "P1" : null;
                if (EsFiltro(nombre) && int.TryParse(nombre[1..], out int numero))
                    siguiente = nombre[0] == 'P' ? (string.IsNullOrWhiteSpace(celda.OwningRow.Cells["R" + numero].Value?.ToString()) ? "R" + numero : "V" + numero)
                        : nombre[0] == 'R' ? "V" + numero : "P" + (numero + 1);
                if (siguiente != null && grid.Columns.Contains(siguiente) && grid.Columns[siguiente].Visible)
                    AbrirDesplegableBim(celda.OwningRow.Cells[siguiente]);
            }
            catch (Exception error) { RestaurarFilaBim(celda.OwningRow); estado.Text = error.Message; }
        }));
    }

    private async Task<List<string>> ConsultarValoresRapidosBim(RevitOpcion conexion, string documentoId,
        string plantilla, string parametro)
    {
        string clave = ClaveValoresBim(conexion.Pid, documentoId, plantilla, parametro);
        if (valoresRapidosBim.TryGetValue(clave, out var existente)) return await existente;
        async Task<List<string>> Leer()
        {
            using var limite = new CancellationTokenSource(TimeSpan.FromSeconds(15));
            var respuesta = await cliente.EnviarAsync(conexion.Pid, new SolicitudRevit
            {
                Accion = "VALORES", Credencial = sesion.Credencial,
                DocumentoId = documentoId, Plantilla = plantilla, Parametro = parametro
            }, limite.Token);
            if (!respuesta.Ok) throw new InvalidOperationException(respuesta.Mensaje);
            return (respuesta.Valores ?? new()).Distinct(StringComparer.Ordinal).ToList();
        }
        var tarea = Leer(); valoresRapidosBim[clave] = tarea;
        try { return await tarea; }
        catch { if (valoresRapidosBim.TryGetValue(clave, out var actual) && actual == tarea) valoresRapidosBim.Remove(clave); throw; }
    }

    private string ClaveValoresBim(int pid, string documentoId, string plantilla, string parametro) =>
        System.Text.Json.JsonSerializer.Serialize(new object[] { generacionValoresBim, pid, documentoId, plantilla, parametro });

    private async void AbrirValoresRapidosBim(object sender, EventArgs e)
    {
        if (sender is not DataGridViewComboBoxEditingControl combo || grid.CurrentCell is not DataGridViewCell celda) return;
        string columna = celda.OwningColumn.Name;
        if (!columna.StartsWith("V", StringComparison.Ordinal) || !int.TryParse(columna[1..], out int numero)
            || modelo == null || revit.SelectedItem is not RevitOpcion conexion) return;
        string plantilla = celda.OwningRow.Cells["PLANTILLA"].Value?.ToString();
        string parametro = celda.OwningRow.Cells["P" + numero].Value?.ToString();
        if (string.IsNullOrWhiteSpace(plantilla) || string.IsNullOrWhiteSpace(parametro)) return;
        string id = modelo.Id, clave = ClaveValoresBim(conexion.Pid, id, plantilla, parametro);
        if (Equals(combo.Tag, clave)) return;
        combo.Tag = clave;
        try
        {
            var valores = await ConsultarValoresRapidosBim(conexion, id, plantilla, parametro);
            if (IsDisposed || combo.IsDisposed || grid.CurrentCell != celda || grid.EditingControl != combo
                || modelo?.Id != id || clave != ClaveValoresBim(conexion.Pid, id,
                    celda.OwningRow.Cells["PLANTILLA"].Value?.ToString(), celda.OwningRow.Cells["P" + numero].Value?.ToString())) return;
            string escrito = combo.Text;
            var opciones = new[] { "", escrito }.Concat(valores).Distinct(StringComparer.Ordinal).Cast<object>().ToArray();
            combo.BeginUpdate();
            try { combo.Items.Clear(); combo.Items.AddRange(opciones); combo.Text = escrito; }
            finally { combo.EndUpdate(); }
            if (combo.Focused && !combo.DroppedDown) combo.DroppedDown = true;
        }
        catch (Exception error)
        {
            if (!IsDisposed && !combo.IsDisposed && !grid.IsDisposed && grid.CurrentCell == celda)
            { combo.Tag = null; estado.Text = "No se pudo consultar valores: " + error.Message + " Puede escribir el valor y volver a intentar."; }
        }
    }

    private void RestaurarFilaBim(DataGridViewRow fila)
    {
        if (fila?.Tag is not ItemPresupuestoDelphin i) return;
        bool anterior = cargando; cargando = true;
        try
        {
            fila.Cells["PARTIDA"].Value = i.Descripcion; fila.Cells["UNIDAD"].Value = i.Unidad;
            void Poner(string columna, string valor)
            {
                if (fila.Cells[columna] is DataGridViewComboBoxCell c && !c.Items.Contains(valor ?? "")) c.Items.Add(valor ?? "");
                fila.Cells[columna].Value = valor ?? "";
            }
            Poner("PLANTILLA", i.Plantilla);
            var filtros = MYGBibliotecaPartidas.FiltrosGuardables(i);
            for (int n = 1; n <= (P?.CantidadFiltros ?? 1); n++)
            {
                var f = n <= filtros.Count ? filtros[n - 1] : new FiltroPlanificacion();
                Poner("P" + n, f.Parametro); Poner("R" + n, f.Regla); Poner("V" + n, f.Valor);
            }
        }
        finally { cargando = anterior; }
    }
}
