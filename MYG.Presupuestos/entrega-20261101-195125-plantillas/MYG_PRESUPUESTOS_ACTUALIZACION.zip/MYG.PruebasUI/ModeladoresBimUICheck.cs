using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class ModeladoresBimUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial))!.SetValue(sesion,
            new CredencialMYG { Usuario = "Modelador sintético" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado))!.SetValue(sesion, true);
        var documento = MYGProyectoStorage.Nuevo("Interfaz modeladores BIM");
        var partida = MYGPartidasBim.CrearTexto(documento, documento.PresupuestoActivoId, "Nueva partida", "m2", null, null, "propietario");
        using var editor = new EditorForm(documento, null, sesion);
        var grid = Campo<DataGridView>(editor, "grid");
        string[] internas = { "CODIGO", "CODIGO_DELPHIN", "ID_PROPUESTA", "ORIGEN", "ESTADO" };
        exige(internas.All(c => !grid.Columns[c].Visible) && grid.Columns["ITEM"].Visible
            && grid.Columns["PARTIDA"].Visible && grid.MultiSelect,
            "La vista BIM retira las cinco columnas internas y mantiene selección múltiple.");
        Llamar(editor, "Refrescar");
        exige(internas.All(c => !grid.Columns[c].Visible) && partida.IdPropuesta != null,
            "Refrescar no recupera las columnas ocultas ni elimina la identidad de las partidas.");
        var acciones = Campo<FlowLayoutPanel>(editor, "acciones");
        string[] textos = Controles(acciones).OfType<Button>().Select(b => b.Text).ToArray();
        exige(textos.Contains("+ Partida de texto") && textos.Contains("+ Desde catálogo") && textos.Contains("Editar filtros en lote")
            && !textos.Contains("+ Título") && !textos.Contains("Reconciliar Delphin") && !textos.Contains("− Quitar propuesta"),
            "La ventana ofrece altas y filtros BIM sin comandos que alteren otros módulos o eliminen estructura.");

        using var cliente = new ClienteSupabase("https://bim-ui.supabase.co", "sb_publishable_bim_sintetica", new Acceso());
        cliente.IniciarSesionAsync("bim@myg.example", "clave_sintetica").GetAwaiter().GetResult();
        var permisos = new MYGPermisosModulos { Acu = false, Especificaciones = false, MetradosExcel = false, MetradosRevit = true };
        var vinculo = new MYGVinculoNube { Servidor = cliente.UrlServidor, UsuarioId = cliente.UsuarioId,
            ProyectoId = Guid.NewGuid(), Rol = "editor", PermisosModulos = permisos };
        typeof(EditorForm).GetField("vinculoNube", Privados)!.SetValue(editor, vinculo);
        typeof(EditorForm).GetField("obtenerClienteNube", Privados)!.SetValue(editor, new Func<ClienteSupabase>(() => cliente));
        Llamar(editor, "AplicarPermisosModeladoresBim");
        exige(!grid.ReadOnly && Controles(acciones).OfType<Button>().Single(b => b.Text == "Editar filtros en lote").Enabled,
            "Metrados Revit habilita la edición BIM aunque ACU, especificaciones y Excel estén bloqueados.");
        permisos.MetradosRevit = false;
        Llamar(editor, "AplicarPermisosModeladoresBim");
        exige(grid.ReadOnly && !Controles(acciones).OfType<Button>().Single(b => b.Text == "+ Desde catálogo").Enabled,
            "Retirar sólo Metrados Revit bloquea la tabla y las altas de catálogo.");
        string firma = MYGProyectoStorage.Firma(documento);
        foreach (string metodo in new[] { "NuevaPartidaBimTexto", "NuevaPartidaBimCatalogo", "EditarFiltrosMasivosBim" })
            Rechaza(() => Llamar(editor, metodo), exige);
        Rechaza(() => Llamar(editor, "CambiarFiltros", 1), exige);
        exige(MYGProyectoStorage.Firma(documento) == firma,
            "Las invocaciones directas sin permiso no modifican la obra ni abren diálogos.");

        // El rechazo de una edición por revocación se resuelve en la propia
        // fila: no sale una excepción del evento WinForms ni se altera la obra.
        var filaProtegida = grid.Rows.Cast<DataGridViewRow>().Single(r => r.Tag == partida);
        filaProtegida.Cells["PLANTILLA"].Value = "PLANTILLA NO AUTORIZADA";
        typeof(DataGridView).GetMethod("OnCellEndEdit", Privados)!.Invoke(grid,
            new object[] { new DataGridViewCellEventArgs(grid.Columns["PLANTILLA"].Index, filaProtegida.Index) });
        exige(MYGProyectoStorage.Firma(documento) == firma && !string.IsNullOrWhiteSpace(filaProtegida.ErrorText)
            && (filaProtegida.Cells["PLANTILLA"].Value?.ToString() ?? "") == (partida.Plantilla ?? ""),
            "Una selección rechazada restaura la fila y mantiene la ventana operativa.");

        var nativo = MYGProyectoStorage.Nuevo("Regresión de plantilla nativa");
        var filaNativa = new ItemPresupuestoDelphin { Id = "CU-NATIVA", IdLocalMYG = "LOCAL-NATIVA", IdInternoDelphin = "CU-NATIVA",
            Item = "01.02.03.06.03", Posicion = 234, Descripcion = "Concreto", Unidad = "m3", TipoPropuesta = "PARTIDA",
            Origen = "DELPHIN", Estado = "OFICIAL", Costos = new MYGDatosPartida { PrecioDirecto = 247.35m } };
        nativo.Presupuestos[0].Items.Add(filaNativa);
        using var editorNativo = new EditorForm(nativo, null, sesion);
        decimal precioAntes = filaNativa.Costos.PrecioDirecto;
        var tablaNativa = Campo<DataGridView>(editorNativo, "grid");
        var modelo = new DocumentoRevitInfo { Id = "MODELO-1", Plantillas = new() { "PLANTILLA_COLUMNAS_M3" },
            Parametros = new() { ["PLANTILLA_COLUMNAS_M3"] = new() { "Descripción" } },
            Reglas = new() { ["PLANTILLA_COLUMNAS_M3"] = new() { ["Descripción"] = new() { "comienza por" } } } };
        typeof(EditorForm).GetField("modelo", Privados)!.SetValue(editorNativo, modelo);
        var filaVisual = tablaNativa.Rows.Cast<DataGridViewRow>().Single(r => r.Tag == filaNativa);
        var celdaPlantilla = (DataGridViewComboBoxCell)filaVisual.Cells["PLANTILLA"];
        celdaPlantilla.Items.Add("PLANTILLA_COLUMNAS_M3"); celdaPlantilla.Value = "PLANTILLA_COLUMNAS_M3";
        Llamar(editorNativo, "SincronizarTablaModeladoresBim", filaVisual);
        Llamar(editorNativo, "OpcionesFila", filaVisual, "PLANTILLA");
        exige(filaNativa.Plantilla == "PLANTILLA_COLUMNAS_M3" && filaNativa.Item == "01.02.03.06.03" && filaNativa.Posicion == 234
            && filaNativa.Costos.PrecioDirecto == precioAntes && ((DataGridViewComboBoxCell)filaVisual.Cells["P1"]).Items.Contains("Descripción"),
            "Elegir plantilla conserva numeración y costos nativos y ofrece inmediatamente sus parámetros.");
        filaVisual.Cells["P1"].Value = "Descripción";
        Llamar(editorNativo, "OpcionesFila", filaVisual, "P1");
        filaVisual.Cells["V1"].Value = "Placa";
        Llamar(editorNativo, "SincronizarTablaModeladoresBim", filaVisual);
        exige(filaNativa.Filtros.Single().Parametro == "Descripción" && filaNativa.Filtros[0].Regla == "comienza por"
            && filaNativa.Filtros[0].Valor == "Placa", "El flujo rápido confirma parámetro, única regla y valor sin reconstruir la obra.");
        Type opcionRevit = typeof(EditorForm).GetNestedType("RevitOpcion", BindingFlags.NonPublic)!;
        object unicaConexion = Activator.CreateInstance(opcionRevit, new object[] { 123, "Modelo único", "DOC-1" })!;
        Array conexiones = Array.CreateInstance(opcionRevit, 1); conexiones.SetValue(unicaConexion, 0);
        object seleccionAutomatica = typeof(EditorForm).GetMethod("ElegirConexionRevit", Privados)!.Invoke(editorNativo, new object[] { conexiones })!;
        exige(ReferenceEquals(unicaConexion, seleccionAutomatica), "Un único modelo se elige sin abrir un diálogo.");

        using var configuracion = new PermisosModulosNubeForm("modelador", permisos, true, "editor");
        var check = Controles(configuracion).OfType<CheckBox>().Single(c => c.Name == "permisoEditarMetradosRevit");
        check.Checked = true;
        exige(configuracion.Permisos.MetradosRevit && !configuracion.Permisos.Acu && !configuracion.Permisos.Especificaciones
            && !configuracion.Permisos.MetradosExcel,
            "El administrador puede asignar únicamente el permiso Metrados Revit.");
        using var lote = new BimFiltrosMasivosForm(2000, partida, null);
        exige(Controles(lote).OfType<Label>().Any(l => l.Text == "2000 partida(s) seleccionada(s)")
            && Controles(lote).OfType<DataGridView>().Single().Rows.Count == 8,
            "El diálogo acepta dos mil partidas y limita sólo los filtros de cada tabla.");
        exige(MYGProyectoStorage.Firma(documento) == firma,
            "Consultar y cancelar el diálogo masivo no altera las partidas.");
    }

    private static T Campo<T>(object instancia, string nombre) => (T)instancia.GetType().GetField(nombre, Privados)!.GetValue(instancia)!;
    private static void Llamar(object instancia, string nombre, params object[] argumentos)
    {
        try { instancia.GetType().GetMethod(nombre, Privados)!.Invoke(instancia, argumentos); }
        catch (TargetInvocationException error) when (error.InnerException != null)
        { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error.InnerException).Throw(); }
    }
    private static void Rechaza(Action accion, Action<bool, string> exige)
    {
        bool rechazo = false;
        try { accion(); } catch (InvalidOperationException) { rechazo = true; }
        exige(rechazo, "La operación BIM exige autorización también al invocarla directamente.");
    }
    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (var control in Controles(hijo)) yield return control;
    }
    private sealed class Acceso : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken token)
        {
            if (solicitud.RequestUri!.AbsolutePath != "/auth/v1/token") throw new InvalidOperationException("Sólo autenticación HTTP simulada.");
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            { Content = new StringContent(JsonSerializer.Serialize(new { access_token = "bim_sintetico", refresh_token = "refresco_sintetico",
                expires_in = 3600, user = new { id = "11111111-1111-4111-8111-111111111111" } }), Encoding.UTF8, "application/json") });
        }
    }
}
