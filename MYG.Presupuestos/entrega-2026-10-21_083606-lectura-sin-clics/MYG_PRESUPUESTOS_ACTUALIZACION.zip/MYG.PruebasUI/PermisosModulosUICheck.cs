using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MYG_2027;

internal static class PermisosModulosUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Permisos por módulo", "Presupuesto");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), IdLocalMYG = MYGProyectoStorage.NuevoId(),
            TipoPropuesta = "PARTIDA", Descripcion = "Partida de prueba", Unidad = "m3", Posicion = 1
        };
        partida.Costos.EspecificacionTexto = "Contenido visible de la especificación";
        partida.Costos.Hoja.Poner("A3", "Contenido visible de la hoja");
        for (int i = 0; i < 2; i++)
        {
            var insumo = new MYGInsumo { Codigo = "QA" + i, Descripcion = "Recurso de prueba " + i,
                Unidad = "und", Grupo = MYGGrupoRecurso.Materiales, Precio = 1 };
            presupuesto.Costos.Insumos.Add(insumo);
            partida.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Grupo = insumo.Grupo, Cantidad = 1 });
        }
        presupuesto.Items.Add(partida);
        int cambios = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => cambios++, () => { }, _ => { },
            () => System.Threading.Tasks.Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var ventana = new Form { ClientSize = new Size(1300, 850) };
        ventana.Controls.Add(panel); ventana.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        var permisos = new MYGPermisosModulos();
        bool edicionGlobal = true;
        panel.ConfigurarPermisoNube(() => edicionGlobal, () => permisos);
        var acu = Campo<DataGridView>(panel, "acu");
        var hoja = Campo<DataGridView>(panel, "hoja");
        var especificacion = Campo<RichTextBox>(panel, "especificacion");
        var formula = Campo<TextBoxBase>(panel, "formula");
        var celdaTotal = Campo<TextBox>(panel, "celdaTotal");
        var estructura = Campo<DataGridView>(panel, "estructura");
        var tablaPie = Campo<DataGridView>(panel, "tablaPie");
        var editor = Campo<MYGEspecificacionesEditor>(panel, "editorEspecificaciones");
        var zoom = Campo<NumericUpDown>(editor, "zoom");
        var copiar = Elemento(editor, "Copiar");
        var focoConsulta = Campo<TextBox>(panel, "buscar");
        var pestanas = Campo<TabControl>(panel, "detalle");
        var tabulacionOriginal = new Control[] { acu, hoja, especificacion, formula, celdaTotal, tablaPie, estructura }
            .ToDictionary(control => control, control => control.TabStop);
        int paginas = pestanas.TabPages.Count;
        Color acuEditable = acu.BackgroundColor, hojaEditable = hoja.BackgroundColor;
        Color estructuraEditable = estructura.BackgroundColor, pieEditable = tablaPie.BackgroundColor;
        Color especificacionEditable = especificacion.BackColor, formulaEditable = formula.BackColor;
        Cursor cursorAcu = acu.Cursor, cursorHoja = hoja.Cursor, cursorEspecificacion = especificacion.Cursor;
        Cursor cursorFormula = formula.Cursor, cursorTotal = celdaTotal.Cursor;
        Cursor cursorEstructura = estructura.Cursor, cursorPie = tablaPie.Cursor;
        Cursor cursorZoom = zoom.Cursor, cursorCopiar = copiar.Owner.Cursor;
        var barrasAcu = acu.Controls.OfType<ScrollBar>().Select(barra => (Barra: barra, Habilitada: barra.Enabled)).ToArray();
        var barrasHoja = hoja.Controls.OfType<ScrollBar>().Select(barra => (Barra: barra, Habilitada: barra.Enabled)).ToArray();
        string rtfSinBloqueo = especificacion.Rtf;

        permisos.Acu = false; panel.ActualizarPermisoNube();
        exige(acu.ReadOnly && !hoja.ReadOnly && !especificacion.ReadOnly,
            "Bloquear ACU conserva editables los otros módulos y mantiene visible el análisis.");
        Gris(acu.BackgroundColor, exige, "El fondo de ACU comunica visualmente el bloqueo.");
        exige((SystemInformation.HighContrast || acu.BackgroundColor != acuEditable) && acu.Enabled
            && hoja.BackgroundColor == hojaEditable && especificacion.BackColor == especificacionEditable,
            "Sólo ACU cambia de aspecto y su tabla permanece habilitada para consultar.");
        exige(acu.Cursor == Cursors.No && hoja.Cursor == cursorHoja && especificacion.Cursor == cursorEspecificacion
            && formula.Cursor == cursorFormula && celdaTotal.Cursor == cursorTotal
            && estructura.Cursor == cursorEstructura && tablaPie.Cursor == cursorPie,
            "El puntero de prohibido sólo identifica el contenido de ACU bloqueado.");
        foreach (var barra in barrasAcu)
            exige(barra.Barra.Cursor == Cursors.Default && barra.Barra.Enabled == barra.Habilitada,
                "Las barras de desplazamiento de ACU conservan su habilitación y no heredan el puntero de prohibido.");
        exige(!Campo<NumericUpDown>(panel, "rendimiento").Enabled && !Campo<NumericUpDown>(panel, "jornada").Enabled,
            "Rendimiento y jornada muestran el estado deshabilitado al bloquear ACU.");
        exige(!acu.TabStop && acu.Enabled && hoja.TabStop == tabulacionOriginal[hoja],
            "ACU sale de la tabulación sin deshabilitar el desplazamiento ni afectar a Excel editable.");
        SinInteraccion(acu, pestanas, focoConsulta, () => MYGProyectoStorage.Firma(proyecto), () => cambios, exige, "ACU");
        int historial = cambios;
        Rechaza(() => Invocar(panel, "EliminarRecurso"), exige);
        exige(cambios == historial, "La entrada directa de eliminación ACU bloqueada no genera historial.");

        permisos.Especificaciones = false; panel.ActualizarPermisoNube();
        exige(especificacion.ReadOnly && especificacion.Text.Contains("Contenido visible"),
            "Las especificaciones bloqueadas conservan su contenido visible en solo lectura.");
        Gris(especificacion.BackColor, exige, "El papel de especificaciones aparece gris cuando no se puede editar.");
        exige((SystemInformation.HighContrast || especificacion.BackColor != especificacionEditable) && especificacion.Enabled
            && especificacion.Rtf == rtfSinBloqueo,
            "El bloqueo visual permite seleccionar texto y conserva el RTF sin modificarlo.");
        exige(especificacion.Cursor == Cursors.No && hoja.Cursor == cursorHoja && formula.Cursor == cursorFormula,
            "El documento bloqueado muestra prohibido sin cambiar el puntero de Excel editable.");
        exige(!Campo<ToolStripComboBox>(editor, "fuentes").Enabled && !Campo<ToolStripComboBox>(editor, "tamanos").Enabled
            && !Campo<ToolStripButton>(editor, "negrita").Enabled && !Campo<Button>(editor, "insertarTitulo").Enabled,
            "La cinta de especificaciones deshabilita las herramientas que modifican el documento.");
        especificacion.Select(0, Math.Min(5, especificacion.TextLength));
        exige(especificacion.SelectionLength > 0 && zoom.Enabled && copiar.Enabled
            && zoom.Cursor == cursorZoom && copiar.Owner.Cursor == cursorCopiar,
            "El código puede preparar una selección interna sin deshabilitar los comandos independientes de copiar y zoom.");
        exige(!especificacion.TabStop && especificacion.Enabled,
            "El documento bloqueado sale de la tabulación y conserva el control habilitado para desplazarse.");
        SinInteraccion(especificacion, pestanas, focoConsulta, () => MYGProyectoStorage.Firma(proyecto), () => cambios, exige, "Especificaciones");

        permisos.MetradosExcel = false; panel.ActualizarPermisoNube();
        exige(hoja.ReadOnly && formula.ReadOnly,
            "La hoja y su barra de fórmulas quedan en solo lectura.");
        Gris(hoja.BackgroundColor, exige, "El fondo de la hoja comunica el bloqueo de Metrados Excel.");
        Gris(formula.BackColor, exige, "La barra de fórmulas bloqueada usa un fondo gris.");
        exige((SystemInformation.HighContrast || hoja.BackgroundColor != hojaEditable && formula.BackColor != formulaEditable)
            && hoja.Enabled && formula.Enabled,
            "La hoja y la fórmula cambian de aspecto conservando la consulta y selección.");
        exige(hoja.Cursor == Cursors.No && formula.Cursor == Cursors.No && celdaTotal.Cursor == Cursors.No,
            "Hoja, fórmula y celda total muestran el puntero de prohibido cuando Excel está bloqueado.");
        hoja.Cursor = Cursors.Cross;
        exige(hoja.Cursor == Cursors.No,
            "Un cambio externo de puntero no sustituye prohibido mientras la hoja está bloqueada.");
        foreach (var barra in barrasHoja)
            exige(barra.Barra.Cursor == Cursors.Default && barra.Barra.Enabled == barra.Habilitada,
                "Las barras de desplazamiento de Excel conservan su habilitación y no heredan el puntero de prohibido.");
        var puntoHoja = new Point(hoja.ClientSize.Width / 2, hoja.ClientSize.Height / 2);
        exige(hoja.ClientRectangle.Contains(puntoHoja) && CursorHoja(panel, puntoHoja) == Cursors.No,
            "El selector de puntero de Excel conserva prohibido al desplazarse dentro de la hoja bloqueada.");
        exige(CursorHoja(panel, new Point(-1, -1)) != Cursors.No,
            "El puntero de prohibido de Excel no se extiende fuera de su área cliente.");
        exige(!hoja.TabStop && !formula.TabStop && !celdaTotal.TabStop
            && hoja.Enabled && formula.Enabled && celdaTotal.Enabled,
            "La hoja y sus campos bloqueados salen de la tabulación sin deshabilitar sus controles.");
        if (hoja.Rows.Count > 0 && hoja.Columns.Count > 0)
        {
            hoja.CurrentCell = hoja.Rows[0].Cells[0];
            exige(hoja.CurrentCell == hoja.Rows[0].Cells[0] && hoja.ReadOnly,
                "Preparar una celda desde código conserva el bloqueo de interacción y edición de la hoja.");
        }
        SinInteraccion(hoja, pestanas, focoConsulta, () => MYGProyectoStorage.Firma(proyecto), () => cambios, exige, "Metrados Excel", comprobarRueda: true);
        SinInteraccion(formula, pestanas, focoConsulta, () => MYGProyectoStorage.Firma(proyecto), () => cambios, exige, "Barra de fórmulas");
        SinInteraccion(celdaTotal, pestanas, focoConsulta, () => MYGProyectoStorage.Firma(proyecto), () => cambios, exige, "Celda total");
        Rechaza(() => Invocar(panel, "EjecutarComandoHoja", "limpiar"), exige);
        Rechaza(() => Invocar(panel, "ImportarHoja"), exige);
        exige(cambios == historial && partida.Costos.Hoja.Celdas["A3"].Contenido == "Contenido visible de la hoja",
            "Los comandos de hoja bloqueados no alteran datos ni historial.");
        string antesClicExcel = MYGProyectoStorage.Firma(proyecto);
        permisos.MetradosExcel = true; panel.ActualizarPermisoNube();
        ClicDisponible(hoja, pestanas, focoConsulta, exige, "Restituir Excel permite volver a seleccionar una celda mediante un clic real.");
        exige(hoja.TabStop == tabulacionOriginal[hoja] && formula.TabStop == tabulacionOriginal[formula]
            && celdaTotal.TabStop == tabulacionOriginal[celdaTotal],
            "Restituir únicamente Excel devuelve los valores originales de tabulación de sus controles.");
        exige(MYGProyectoStorage.Firma(proyecto) == antesClicExcel && cambios == historial,
            "Restituir Excel y consultar otra celda no modifica datos ni historial.");
        permisos.MetradosExcel = false; panel.ActualizarPermisoNube();
        partida.Costos.Hoja.RangoCuerpoPlantilla = null;
        partida.Costos.Hoja.RellenoCabeceraEstandarAplicado = false;
        string legado = MYGProyectoStorage.Firma(proyecto);
        Invocar(panel, "CargarHoja");
        exige(MYGProyectoStorage.Firma(proyecto) == legado,
            "Consultar una hoja heredada bloqueada no aplica reparaciones persistentes ni cambia el documento.");
        exige(pestanas.TabPages.Count == paginas, "Los permisos no ocultan ni eliminan las pestañas de módulos.");

        permisos.Acu = true; panel.ActualizarPermisoNube();
        exige(!acu.ReadOnly && acu.BackgroundColor == acuEditable && hoja.ReadOnly && especificacion.ReadOnly,
            "Restituir sólo ACU recupera su edición y colores sin desbloquear los otros módulos.");
        exige(acu.Cursor == cursorAcu && hoja.Cursor == Cursors.No && especificacion.Cursor == Cursors.No
            && formula.Cursor == Cursors.No && celdaTotal.Cursor == Cursors.No,
            "Restituir sólo ACU recupera su puntero y conserva prohibido en los otros módulos bloqueados.");
        Gris(hoja.BackgroundColor, exige, "Restituir ACU conserva gris la hoja bloqueada.");
        Gris(especificacion.BackColor, exige, "Restituir ACU conserva gris la especificación bloqueada.");
        permisos.Acu = false; panel.ActualizarPermisoNube();

        permisos.Acu = permisos.Especificaciones = permisos.MetradosExcel = true;
        edicionGlobal = false; panel.ActualizarPermisoNube();
        exige(acu.ReadOnly && hoja.ReadOnly && especificacion.ReadOnly,
            "Los permisos de módulo no elevan a un lector global ni una sesión revocada.");
        Gris(estructura.BackgroundColor, exige, "La estructura del presupuesto se muestra gris para un lector global.");
        Gris(tablaPie.BackgroundColor, exige, "El pie del presupuesto se muestra gris para un lector global.");
        exige((SystemInformation.HighContrast || estructura.BackgroundColor != estructuraEditable && tablaPie.BackgroundColor != pieEditable)
            && estructura.Enabled && tablaPie.Enabled,
            "El bloqueo global conserva la navegación por estructura y resumen.");
        exige(estructura.Cursor == Cursors.No && tablaPie.Cursor == Cursors.No,
            "Un lector global ve el puntero de prohibido en estructura y resumen.");
        exige(!tablaPie.TabStop && estructura.TabStop == tabulacionOriginal[estructura],
            "El pie bloqueado sale de la tabulación y la estructura conserva la navegación del lector global.");
        SinInteraccion(tablaPie, pestanas, focoConsulta, () => MYGProyectoStorage.Firma(proyecto), () => cambios, exige, "Pie del presupuesto");
        ClicDisponible(estructura, pestanas, focoConsulta, exige,
            "La estructura del lector global conserva la selección mediante clic para navegar por el presupuesto.");
        int paginaAntes = pestanas.SelectedIndex, paginaDestino = (paginaAntes + 1) % pestanas.TabCount;
        Clic(pestanas, Centro(pestanas.GetTabRect(paginaDestino)));
        exige(pestanas.SelectedIndex == paginaDestino,
            "Los clics sobre las pestañas siguen permitiendo consultar otros módulos bloqueados.");
        Clic(pestanas, Centro(pestanas.GetTabRect(paginaAntes)));

        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos(); Application.DoEvents();
            Gris(acu.BackgroundColor, exige, "Cambiar de tema mantiene gris el ACU bloqueado.");
            Gris(hoja.BackgroundColor, exige, "Cambiar de tema mantiene gris la hoja bloqueada.");
            Gris(especificacion.BackColor, exige, "Cambiar de tema mantiene gris el documento bloqueado.");
            exige(acu.ReadOnly && hoja.ReadOnly && especificacion.ReadOnly && especificacion.Rtf == rtfSinBloqueo,
                "Cambiar el tema no reactiva editores ni altera el formato del documento bloqueado.");
            exige(acu.Cursor == Cursors.No && hoja.Cursor == Cursors.No && especificacion.Cursor == Cursors.No
                && formula.Cursor == Cursors.No && celdaTotal.Cursor == Cursors.No
                && estructura.Cursor == Cursors.No && tablaPie.Cursor == Cursors.No,
                "Cambiar el tema conserva prohibido en el contenido bloqueado.");
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos(); panel.ActualizarPermisoNube();
        }
        edicionGlobal = true; panel.ActualizarPermisoNube();
        exige(!acu.ReadOnly && !hoja.ReadOnly && !especificacion.ReadOnly,
            "Restituir los permisos reactiva los editores sin recrear el proyecto.");
        exige(tabulacionOriginal.All(par => par.Key.TabStop == par.Value),
            "Restituir los permisos devuelve la tabulación original de todos los controles de contenido.");
        exige(acu.BackgroundColor == acuEditable && hoja.BackgroundColor == hojaEditable
            && estructura.BackgroundColor == estructuraEditable && tablaPie.BackgroundColor == pieEditable
            && especificacion.BackColor == especificacionEditable && formula.BackColor == formulaEditable,
            "Recuperar permisos restaura los colores editables sin recrear los controles.");
        exige(acu.Cursor == cursorAcu && hoja.Cursor != Cursors.No && especificacion.Cursor == cursorEspecificacion
            && formula.Cursor == cursorFormula && celdaTotal.Cursor == cursorTotal
            && estructura.Cursor == cursorEstructura && tablaPie.Cursor == cursorPie
            && zoom.Cursor == cursorZoom && copiar.Owner.Cursor == cursorCopiar,
            "Recuperar permisos restaura los punteros de edición y conserva los de consulta.");
        exige(CursorHoja(panel, puntoHoja) != Cursors.No,
            "Al recuperar Excel el selector dinámico vuelve a elegir un puntero normal.");
        exige(Campo<ToolStripComboBox>(editor, "fuentes").Enabled && Campo<ToolStripComboBox>(editor, "tamanos").Enabled
            && Campo<ToolStripButton>(editor, "negrita").Enabled && especificacion.Rtf == rtfSinBloqueo
            && cambios == historial,
            "La cinta vuelve a permitir edición y los cambios visuales no modifican contenido ni historial.");
        ventana.Close();
    }

    private static void SinInteraccion(Control control, TabControl pestanas, Control focoConsulta,
        Func<string> estado, Func<int> historial, Action<bool, string> exige, string nombre, bool comprobarRueda = false)
    {
        Mostrar(control, pestanas); focoConsulta.Focus(); Application.DoEvents();
        var tabla = control as DataGridView;
        var texto = control as TextBoxBase;
        if (texto != null) texto.Select(0, Math.Min(2, texto.TextLength));
        Point actual = tabla?.CurrentCellAddress ?? Point.Empty;
        Point[] seleccion = Seleccion(tabla);
        int inicio = texto?.SelectionStart ?? 0, longitud = texto?.SelectionLength ?? 0;
        string contenido = control.Text, rtf = (control as RichTextBox)?.Rtf;
        string estadoAntes = estado(); int historialAntes = historial();
        int eventosRaton = 0, eventosTecla = 0, aperturas = 0, ruedas = 0;
        MouseEventHandler raton = (_, _) => eventosRaton++;
        MouseEventHandler rueda = (_, _) => ruedas++;
        KeyEventHandler tecla = (_, _) => eventosTecla++;
        KeyPressEventHandler caracter = (_, _) => eventosTecla++;
        CancelEventHandler abrir = (_, e) => { aperturas++; e.Cancel = true; };
        var menuOriginal = control.ContextMenuStrip;
        using var menuAuxiliar = menuOriginal == null ? new ContextMenuStrip() : null;
        var menu = menuOriginal ?? menuAuxiliar;
        if (menuAuxiliar != null) { menuAuxiliar.Items.Add("Prueba sin acciones"); control.ContextMenuStrip = menuAuxiliar; }
        menu.Opening += abrir;
        control.MouseDown += raton; control.MouseUp += raton; control.MouseDoubleClick += raton;
        control.KeyDown += tecla; control.KeyPress += caracter; control.MouseWheel += rueda;
        try
        {
            Point punto = tabla is null ? PuntoTexto(texto) : PuntoCelda(tabla);
            Clic(control, punto);
            EnviarMensaje(control.Handle, 0x0203, new IntPtr(1), Coordenadas(punto)); // WM_LBUTTONDBLCLK.
            EnviarMensaje(control.Handle, 0x0202, IntPtr.Zero, Coordenadas(punto));
            EnviarMensaje(control.Handle, 0x0204, new IntPtr(2), Coordenadas(punto)); // WM_RBUTTONDOWN.
            EnviarMensaje(control.Handle, 0x0205, IntPtr.Zero, Coordenadas(punto));
            EnviarMensaje(control.Handle, 0x007B, control.Handle, Coordenadas(control.PointToScreen(punto))); // WM_CONTEXTMENU.
            EnviarMensaje(control.Handle, 0x0100, new IntPtr((int)Keys.Right), IntPtr.Zero);
            EnviarMensaje(control.Handle, 0x0101, new IntPtr((int)Keys.Right), IntPtr.Zero);
            EnviarMensaje(control.Handle, 0x0102, new IntPtr('X'), IntPtr.Zero); // WM_CHAR.
            Application.DoEvents();
            exige((tabla == null || tabla.CurrentCellAddress == actual && seleccion.SequenceEqual(Seleccion(tabla)))
                && (texto == null || texto.SelectionStart == inicio && texto.SelectionLength == longitud),
                nombre + ": clic, doble clic, menú y teclas no cambian la celda ni la selección bloqueada.");
            exige(eventosRaton == 0 && eventosTecla == 0 && aperturas == 0 && !control.Focused
                && (tabla == null || !tabla.IsCurrentCellInEditMode),
                nombre + ": las entradas se detienen antes de los eventos, el foco y el editor nativo.");
            if (comprobarRueda && tabla != null)
            {
                int primeraFila = tabla.FirstDisplayedScrollingRowIndex;
                EnviarMensaje(control.Handle, 0x020A, new IntPtr(unchecked(-120 << 16)),
                    Coordenadas(control.PointToScreen(punto))); // WM_MOUSEWHEEL.
                Application.DoEvents();
                exige((ruedas > 0 || tabla.FirstDisplayedScrollingRowIndex != primeraFila)
                    && tabla.CurrentCellAddress == actual && seleccion.SequenceEqual(Seleccion(tabla)),
                    nombre + ": la rueda sigue llegando al control sin cambiar la selección bloqueada.");
            }
            exige(control.Text == contenido && (rtf == null || ((RichTextBox)control).Rtf == rtf)
                && estado() == estadoAntes && historial() == historialAntes,
                nombre + ": las entradas y la consulta no modifican texto, formato, datos ni historial.");
        }
        finally
        {
            menu.Opening -= abrir;
            control.MouseDown -= raton; control.MouseUp -= raton; control.MouseDoubleClick -= raton;
            control.KeyDown -= tecla; control.KeyPress -= caracter; control.MouseWheel -= rueda;
            if (menuAuxiliar != null) control.ContextMenuStrip = menuOriginal;
        }
    }

    private static void ClicDisponible(DataGridView tabla, TabControl pestanas, Control focoConsulta,
        Action<bool, string> exige, string mensaje)
    {
        Mostrar(tabla, pestanas); focoConsulta.Focus(); tabla.CancelEdit(); Application.DoEvents();
        Point anterior = tabla.CurrentCellAddress;
        Point punto = PuntoCelda(tabla);
        var destino = tabla.HitTest(punto.X, punto.Y);
        exige(destino.Type == DataGridViewHitTestType.Cell && new Point(destino.ColumnIndex, destino.RowIndex) != anterior,
            "La prueba de restitución dispone de otra celda visible para recibir el clic.");
        Clic(tabla, punto); Application.DoEvents();
        exige(tabla.CurrentCellAddress == new Point(destino.ColumnIndex, destino.RowIndex), mensaje);
        tabla.CancelEdit();
    }

    private static Point[] Seleccion(DataGridView tabla) => tabla == null ? Array.Empty<Point>() :
        tabla.SelectedCells.Cast<DataGridViewCell>().Select(celda => new Point(celda.ColumnIndex, celda.RowIndex))
            .OrderBy(punto => punto.Y).ThenBy(punto => punto.X).ToArray();

    private static Point PuntoCelda(DataGridView tabla)
    {
        var filas = tabla.Rows.Cast<DataGridViewRow>().OrderBy(fila => fila.Index == tabla.CurrentCellAddress.Y ? 0 : 1);
        foreach (DataGridViewRow fila in filas)
            if (fila.Visible)
                foreach (DataGridViewCell celda in fila.Cells)
                {
                    if (!celda.Visible || celda == tabla.CurrentCell) continue;
                    var rectangulo = tabla.GetCellDisplayRectangle(celda.ColumnIndex, celda.RowIndex, true);
                    if (rectangulo.Width > 4 && rectangulo.Height > 4 && tabla.ClientRectangle.Contains(Centro(rectangulo)))
                        return Centro(rectangulo);
                }
        return Centro(tabla.ClientRectangle);
    }

    private static Point PuntoTexto(TextBoxBase texto)
    {
        Point punto = texto.GetPositionFromCharIndex(Math.Min(texto.TextLength, Math.Max(1, texto.TextLength / 2)));
        return new Point(Math.Clamp(punto.X + 2, 0, Math.Max(0, texto.ClientSize.Width - 1)),
            Math.Clamp(punto.Y + 2, 0, Math.Max(0, texto.ClientSize.Height - 1)));
    }

    private static void Mostrar(Control control, TabControl pestanas)
    {
        for (Control padre = control.Parent; padre != null; padre = padre.Parent)
            if (padre is TabPage pagina && ReferenceEquals(pagina.Parent, pestanas))
            { pestanas.SelectedTab = pagina; break; }
        Application.DoEvents();
    }

    private static void Clic(Control control, Point punto)
    {
        EnviarMensaje(control.Handle, 0x0201, new IntPtr(1), Coordenadas(punto));
        EnviarMensaje(control.Handle, 0x0202, IntPtr.Zero, Coordenadas(punto));
    }

    private static Point Centro(Rectangle rectangulo) => new(rectangulo.Left + rectangulo.Width / 2, rectangulo.Top + rectangulo.Height / 2);
    private static IntPtr Coordenadas(Point punto) => new(unchecked((punto.Y << 16) | (punto.X & 0xffff)));

    private static void Gris(Color color, Action<bool, string> exige, string mensaje) =>
        exige(color.A == 255 && (SystemInformation.HighContrast ||
            Math.Abs(color.R - color.G) <= 3 && Math.Abs(color.G - color.B) <= 3), mensaje);

    private static ToolStripItem Elemento(Control raiz, string texto) =>
        Controles(raiz).OfType<ToolStrip>().SelectMany(t => t.Items.Cast<ToolStripItem>())
            .First(i => i.Text == texto);

    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (Control control in Controles(hijo)) yield return control;
    }

    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static Cursor CursorHoja(MYGPanelPresupuesto panel, Point punto) =>
        (Cursor)panel.GetType().GetMethod("ElegirCursorHoja", Privados).Invoke(panel, new object[] { punto });
    private static void Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); }
    }
    private static void Rechaza(Action accion, Action<bool, string> exige)
    {
        bool rechazo = false;
        try { accion(); } catch (InvalidOperationException) { rechazo = true; }
        exige(rechazo, "La mutación del módulo bloqueado exige permiso incluso al invocarse directamente.");
    }
}
