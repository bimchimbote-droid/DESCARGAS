using System.Collections.Generic;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGEspecificacionesEditor
{
    private readonly List<ToolStripItem> comandosEdicionNube = new();
    private readonly Dictionary<ToolStripItem, bool> estadosComandosNube = new();

    // La clasificación pertenece al comando, sin depender de su texto visible.
    private T RegistrarComandoEdicionNube<T>(T comando) where T : ToolStripItem
    {
        comandosEdicionNube.Add(comando);
        return comando;
    }

    internal void AplicarAspectoSoloLecturaNube()
    {
        if (IsDisposed || Disposing) return;
        bool bloqueado = !EdicionNubePermitida || string.IsNullOrEmpty(identidad);
        comandosEdicionNube.RemoveAll(comando => comando.IsDisposed);
        foreach (var comando in comandosEdicionNube)
        {
            if (bloqueado)
            {
                if (!estadosComandosNube.ContainsKey(comando))
                    estadosComandosNube.Add(comando, comando.Enabled);
                comando.Enabled = false;
            }
            else if (estadosComandosNube.Remove(comando, out bool habilitado))
                comando.Enabled = habilitado;
        }
        // El modo exportación reemplaza y libera sus grupos de Fichero.
        foreach (var comando in new List<ToolStripItem>(estadosComandosNube.Keys))
            if (comando.IsDisposed) estadosComandosNube.Remove(comando);

        // Sólo se cambia la representación: la tinta RTF y el papel de autor
        // siguen intactos para guardar, imprimir y recuperar la edición.
        vistaOscura.SoloLecturaNube = bloqueado;
        regla.SoloLecturaNube = reglaVertical.SoloLecturaNube = bloqueado;
        foreach (Control superficie in new Control[] { documento, papel, regla, reglaVertical })
            MYGEstadoSoloLecturaNube.AplicarBloqueoInteraccion(superficie, bloqueado);
        papel.BackColor = documento.BackColor;
        lienzo.BackColor = bloqueado ? MYGEstadoSoloLecturaNube.Fondo : MYG2027_TemaComercial.Fondo;
        if (lienzo.Parent != null) lienzo.Parent.BackColor = lienzo.BackColor;
        barraTitulo.BackColor = bloqueado ? MYGEstadoSoloLecturaNube.Fondo : MYG2027_TemaComercial.SuperficieAlterna;
        regla.BackColor = reglaVertical.BackColor = lienzo.BackColor;
        regla.ForeColor = reglaVertical.ForeColor = bloqueado ? MYGEstadoSoloLecturaNube.Texto : MYG2027_TemaComercial.Secundario;
        regla.Invalidate(); reglaVertical.Invalidate(); lienzo.Invalidate(true);
    }
}
