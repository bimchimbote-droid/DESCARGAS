using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace MYG_2027;

// Paleta de pantalla: nunca se escribe en las celdas del modelo ni en el RTF.
internal static class MYGEstadoSoloLecturaNube
{
    private static readonly ConditionalWeakTable<Control, CursorBloqueado> cursores = new();
    internal static Color Fondo => SystemInformation.HighContrast ? SystemColors.Control
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(53, 53, 53) : Color.FromArgb(236, 236, 236);
    internal static Color Texto => SystemInformation.HighContrast ? SystemColors.ControlText
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(185, 185, 185) : Color.FromArgb(100, 100, 100);
    internal static Color Seleccion => SystemInformation.HighContrast ? SystemColors.Highlight
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(76, 76, 76) : Color.FromArgb(211, 211, 211);
    internal static Color TextoSeleccion => SystemInformation.HighContrast ? SystemColors.HighlightText
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(240, 240, 240) : Color.FromArgb(65, 65, 65);
    internal static Color Borde => SystemInformation.HighContrast ? SystemColors.WindowFrame
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(85, 85, 85) : Color.FromArgb(203, 203, 203);

    internal static void Colorear(DataGridViewCellStyle estilo)
    {
        estilo.BackColor = Fondo;
        estilo.ForeColor = Texto;
        estilo.SelectionBackColor = Seleccion;
        estilo.SelectionForeColor = TextoSeleccion;
    }

    internal static void Aplicar(DataGridView tabla, bool bloqueada)
    {
        if (tabla is MYG2027_TablaPresupuesto presupuesto) presupuesto.SoloLecturaNube = bloqueada;
        AplicarCursor(tabla, bloqueada);
        tabla.BackgroundColor = bloqueada ? Fondo : MYG2027_TemaComercial.Superficie;
        tabla.GridColor = bloqueada ? Borde : MYG2027_TemaComercial.Borde;
        if (bloqueada)
        {
            Colorear(tabla.ColumnHeadersDefaultCellStyle);
            Colorear(tabla.RowHeadersDefaultCellStyle);
        }
        else
        {
            var cabecera = tabla.ColumnHeadersDefaultCellStyle;
            cabecera.BackColor = cabecera.SelectionBackColor = MYG2027_TemaComercial.CabeceraTabla;
            cabecera.ForeColor = cabecera.SelectionForeColor = MYG2027_TemaComercial.TextoCabeceraTabla;
            var filas = tabla.RowHeadersDefaultCellStyle;
            filas.BackColor = MYG2027_TemaComercial.AzulSuave;
            filas.ForeColor = MYG2027_TemaComercial.Texto;
            filas.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
            filas.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
        }
        tabla.Invalidate();
    }

    internal static void AplicarCursor(Control control, bool bloqueado)
    {
        if (control == null || control.IsDisposed) return;
        if (!cursores.TryGetValue(control, out var estado))
        {
            if (!bloqueado) return;
            estado = cursores.GetValue(control, c => new CursorBloqueado(c));
        }
        estado.Actualizar(bloqueado);
    }

    internal static void AplicarBloqueoInteraccion(Control control, bool bloqueado)
    {
        if (control == null || control.IsDisposed) return;
        if (!cursores.TryGetValue(control, out var estado))
        {
            if (!bloqueado) return;
            estado = cursores.GetValue(control, c => new CursorBloqueado(c));
        }
        estado.ActualizarInteraccion(bloqueado);
    }

    private sealed class CursorBloqueado : NativeWindow
    {
        private readonly Control control;
        private readonly Dictionary<ScrollBar, (Cursor Cursor, bool Personalizado)> cursoresBarras = new();
        private Cursor cursorNormal;
        private bool bloqueado, interaccionBloqueada, tabStopNormal, moviendoFoco;

        internal CursorBloqueado(Control control)
        {
            this.control = control;
            control.HandleCreated += CrearHandle;
            control.HandleDestroyed += DestruirHandle;
            control.CursorChanged += CambiarCursor;
            control.ControlAdded += AgregarControl;
            control.TabStopChanged += CambiarTabStop;
            control.Disposed += Liberar;
            if (control.IsHandleCreated) AssignHandle(control.Handle);
        }

        internal void ActualizarInteraccion(bool bloquear)
        {
            if (interaccionBloqueada == bloquear) return;
            if (bloquear) tabStopNormal = control.TabStop;
            interaccionBloqueada = bloquear;
            control.TabStop = bloquear ? false : tabStopNormal;
            if (bloquear)
            {
                control.ContextMenuStrip?.Close(ToolStripDropDownCloseReason.CloseCalled);
                if (control.Capture) control.Capture = false;
                SacarFocoDelContenido();
            }
        }

        private void CambiarTabStop(object sender, EventArgs e)
        {
            if (interaccionBloqueada && control.TabStop) control.TabStop = false;
        }

        private void SacarFocoDelContenido()
        {
            if (moviendoFoco || !control.ContainsFocus || control.IsDisposed) return;
            var ventana = control.FindForm();
            if (ventana == null || ventana.Disposing || ventana.IsDisposed) return;
            moviendoFoco = true;
            try
            {
                if (!ventana.SelectNextControl(control, true, true, true, true)) ventana.ActiveControl = null;
            }
            finally { moviendoFoco = false; }
        }

        internal void Actualizar(bool bloquear)
        {
            if (bloquear == bloqueado) return;
            if (bloquear)
            {
                // La hoja crea y libera sus cursores al cambiar el DPI. No
                // retener uno de esos handles; al volver, su selector dinámico
                // elegirá el cursor correspondiente a la posición del ratón.
                cursorNormal = control is DataGridView ? Cursors.Default : control.Cursor;
            }
            bloqueado = bloquear;
            if (bloquear)
                foreach (Control hijo in control.Controls) PrepararBarra(hijo);
            control.Cursor = bloquear ? Cursors.No : cursorNormal;
            if (!bloquear)
            {
                foreach (var par in cursoresBarras)
                    if (!par.Key.IsDisposed)
                    {
                        if (par.Value.Personalizado) par.Key.Cursor = par.Value.Cursor;
                        else par.Key.ResetCursor();
                    }
                cursoresBarras.Clear();
            }
        }

        private void CrearHandle(object sender, EventArgs e) => AssignHandle(control.Handle);
        private void DestruirHandle(object sender, EventArgs e) => ReleaseHandle();
        private void AgregarControl(object sender, ControlEventArgs e)
        {
            if (bloqueado) PrepararBarra(e.Control);
        }

        private void PrepararBarra(Control hijo)
        {
            // Las barras de DataGridView son controles hijos: sin un cursor
            // explícito heredarían No del padre aunque su HWND no se intercepte.
            if (hijo is not ScrollBar barra || barra.IsDisposed) return;
            if (!cursoresBarras.ContainsKey(barra))
                cursoresBarras.Add(barra, (barra.Cursor,
                    TypeDescriptor.GetProperties(barra)[nameof(Control.Cursor)]?.ShouldSerializeValue(barra) == true));
            barra.Cursor = Cursors.Default;
        }
        private void CambiarCursor(object sender, EventArgs e)
        {
            // Los controles de tabla también asignan cursores desde MouseMove,
            // MouseLeave y cambios de DPI. El permiso tiene prioridad mientras
            // dure el bloqueo, sin consumir los mensajes de selección o copia.
            if (bloqueado && control.Cursor != Cursors.No) control.Cursor = Cursors.No;
        }

        protected override void WndProc(ref Message mensaje)
        {
            if (interaccionBloqueada)
            {
                // No se interceptan rueda, barras de scroll ni mensajes internos
                // de carga/selección que necesitan el renderizado y la exportación.
                if (mensaje.Msg is >= 0x0201 and <= 0x0209 or >= 0x020B and <= 0x020D
                    or 0x007B or 0x0300 or 0x0302 or 0x0303 or 0x0304 or 0x0454
                    or >= 0x010D and <= 0x010F
                    || mensaje.Msg == 0x0200 && (mensaje.WParam.ToInt64() & 0x73) != 0)
                {
                    mensaje.Result = IntPtr.Zero;
                    return;
                }
                if (mensaje.Msg is >= 0x0100 and <= 0x0109 &&
                    mensaje.WParam.ToInt64() is not ((int)Keys.Tab or (int)Keys.Escape))
                {
                    mensaje.Result = IntPtr.Zero;
                    return;
                }
                if (mensaje.Msg == 0x0021 && (mensaje.LParam.ToInt64() & 0xffff) == 1)
                {
                    var hijo = control.GetChildAtPoint(control.PointToClient(Cursor.Position), GetChildAtPointSkip.Invisible);
                    if (hijo is not ScrollBar)
                    {
                        mensaje.Result = new IntPtr(2); // MA_ACTIVATEANDEAT: no enfocar el editor.
                        return;
                    }
                }
            }
            // Sólo el contenido cliente de este control. Las barras nativas y
            // los mensajes de otros HWND conservan su comportamiento normal.
            if ((bloqueado || interaccionBloqueada) && mensaje.Msg == 0x0020 && mensaje.WParam == Handle &&
                (mensaje.LParam.ToInt64() & 0xffff) == 1)
            {
                // Al cambiar Cursor, WinForms también envía este mensaje al
                // padre cuando el ratón está sobre uno de sus hijos.
                var hijo = control.GetChildAtPoint(control.PointToClient(Cursor.Position), GetChildAtPointSkip.Invisible);
                Cursor.Current = hijo is ScrollBar ? Cursors.Default : Cursors.No;
                mensaje.Result = new IntPtr(1);
                return;
            }
            base.WndProc(ref mensaje);
            // WM_SETFOCUS se recibe después de que Windows haya asignado el
            // foco. Se redirige después del procesamiento normal del control.
            if (interaccionBloqueada && mensaje.Msg == 0x0007) SacarFocoDelContenido();
        }

        private void Liberar(object sender, EventArgs e)
        {
            control.HandleCreated -= CrearHandle;
            control.HandleDestroyed -= DestruirHandle;
            control.CursorChanged -= CambiarCursor;
            control.ControlAdded -= AgregarControl;
            control.TabStopChanged -= CambiarTabStop;
            control.Disposed -= Liberar;
            ReleaseHandle();
            cursoresBarras.Clear();
            cursores.Remove(control);
        }
    }
}

internal sealed partial class MYGPanelPresupuesto
{
    private void AplicarAspectoPermisosNube()
    {
        MYGEstadoSoloLecturaNube.Aplicar(estructura, !EdicionNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(tablaPie, !EdicionNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(acu, !EdicionACUNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(hoja, !EdicionMetradosExcelNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarBloqueoInteraccion(acu, !EdicionACUNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarBloqueoInteraccion(hoja, !EdicionMetradosExcelNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarBloqueoInteraccion(tablaPie, !EdicionNubePermitida);
        hoja.GridColor = ColorRejillaHoja;

        formula.SoloLecturaNube = !EdicionMetradosExcelNubePermitida;
        MYGEstadoSoloLecturaNube.AplicarCursor(formula, !EdicionMetradosExcelNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarCursor(celdaTotal, !EdicionMetradosExcelNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarCursor(direccion, !EdicionMetradosExcelNubePermitida);
        foreach (Control control in new Control[] { formula, celdaTotal, direccion })
            MYGEstadoSoloLecturaNube.AplicarBloqueoInteraccion(control, !EdicionMetradosExcelNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarCursor(fuente, !EdicionMetradosExcelNubePermitida);
        foreach (Control control in new Control[] { precioDirecto, rendimiento, jornada })
            MYGEstadoSoloLecturaNube.AplicarCursor(control, !EdicionACUNubePermitida);
        formula.AplicarTema();
        ActualizarColoresReferenciasHoja();
        celdaTotal.BackColor = EdicionMetradosExcelNubePermitida ? MYG2027_TemaComercial.Superficie : MYGEstadoSoloLecturaNube.Fondo;
        celdaTotal.ForeColor = EdicionMetradosExcelNubePermitida ? MYG2027_TemaComercial.Texto : MYGEstadoSoloLecturaNube.Texto;
        direccion.BackColor = celdaTotal.BackColor;
        direccion.ForeColor = celdaTotal.ForeColor;
        foreach (var boton in botonesFormulaHoja) boton.Enabled = EdicionMetradosExcelNubePermitida && HayPartida;

        AplicarTemaContextoACU();
        if (!EdicionACUNubePermitida)
        {
            totalPrecioACU.BackColor = MYGEstadoSoloLecturaNube.Fondo;
            totalPrecioACU.ForeColor = MYGEstadoSoloLecturaNube.Texto;
            if (barraRendimientoACU != null)
            {
                barraRendimientoACU.BackColor = MYGEstadoSoloLecturaNube.Fondo;
                foreach (Control grupo in barraRendimientoACU.Controls) grupo.BackColor = MYGEstadoSoloLecturaNube.Fondo;
            }
            foreach (Control control in new Control[] { porRendimientoACU, porAsignacionACU, unidadRendimientoACU })
            { control.BackColor = MYGEstadoSoloLecturaNube.Fondo; control.ForeColor = MYGEstadoSoloLecturaNube.Texto; }
        }
        foreach (var par in new[] { (herramientasEstructura, EdicionNubePermitida), (herramientasACU, EdicionACUNubePermitida) })
            if (par.Item1 != null)
            {
                par.Item1.BackColor = par.Item2 ? AzulClaro : MYGEstadoSoloLecturaNube.Fondo;
                par.Item1.ForeColor = par.Item2 ? MYG2027_TemaComercial.Texto : MYGEstadoSoloLecturaNube.Texto;
            }
    }
}
