# Módulos bloqueados: lectura sin clics

Actualización del 21/10/2026 para MYG Presupuestos. Complementa las entregas
anteriores de módulos grises y puntero de bloqueo, que deben estar aplicadas.

## Resultado

Mientras un módulo esté bloqueado, su contenido no recibe clics, doble clic,
arrastre, menú contextual ni entrada de teclado. No permite seleccionar nuevas
celdas ni texto mediante esas entradas. Los controles salen del recorrido de
Tab y, si tenían el foco al bloquearlos, éste pasa a un control disponible.
El contenido sigue visible y conserva el aspecto gris y el cursor de prohibido.

El bloqueo se aplica independientemente a ACU, Especificaciones y Metrados Excel,
incluidas la fórmula, la dirección y la celda total. Un lector global también
tiene bloqueada la interacción del pie del presupuesto.

Se conserva la navegación entre proyectos/partidas, pestañas y hojas, además de
rueda, barras de desplazamiento y herramientas de consulta disponibles como
zoom, exportación e impresión. Buscar/Ortografía dentro del documento y Buscar
dentro de Excel quedan deshabilitados durante el bloqueo porque seleccionan
contenido o abren menús. La búsqueda general de partidas sigue disponible.

Al restituir el permiso, sólo ese módulo recupera sus clics, teclado, cursor y
tabulación. No se deshabilita toda la ventana ni se alteran datos del proyecto.
Los procesos internos de carga, impresión y exportación pueden seguir utilizando
la selección programática que necesitan para representar el documento.

## Archivos del ZIP

Los archivos REEMPLAZAR contienen su código completo. Las rutas parten de
`D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `MYG.Desktop/EstadoSoloLecturaNube.cs` | REEMPLAZAR | Bloqueo de entradas, foco y tabulación con restauración de permisos. |
| 2 | `MYG.Desktop/PermisosVisualesEspecificaciones.cs` | REEMPLAZAR | Aplica el bloqueo al documento, papel y reglas. |
| 3 | `MYG.Desktop/EspecificacionesEditor.cs` | REEMPLAZAR | Deshabilita Buscar y Ortografía mientras el documento está bloqueado. |
| 4 | `MYG.Desktop/PermisosPanelNube.cs` | REEMPLAZAR | Mantiene la dirección de Excel en lectura y actualiza los permisos. |
| 5 | `MYG.Desktop/PresupuestosExcelEditor.cs` | REEMPLAZAR | Restringe Buscar durante el bloqueo de Excel. |
| 6 | `MYG.Desktop/PresupuestosExcelElegirReferencias.cs` | REEMPLAZAR | Evita que el filtro de referencias capture clics de una hoja bloqueada. |
| 7 | `MYG.PruebasUI/PermisosModulosUICheck.cs` | REEMPLAZAR | Pruebas de clics, teclado, rueda, datos y restauración. |
| 8 | `ACTUALIZACION_LECTURA_SIN_CLICS.md` | CREAR | Estas instrucciones. |

El ZIP incluye únicamente los cambios de esta entrega. Conserve los otros
archivos instalados anteriormente. No hay eliminaciones ni migraciones SQL.

## Instalación manual

1. Cierre MYG. Respalde o confirme sus modificaciones locales.
2. Descargue el ZIP y extráigalo en una carpeta temporal.
3. Copie su contenido dentro de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.
   Combine las carpetas existentes y reemplace sólo los archivos de la tabla.
   El documento `.md` queda junto a `MYG.Presupuestos.sln`.
4. Abra la solución en Visual Studio compatible con .NET 10, restaure NuGet y
   compile en Release. Ejecute el programa recién compilado. Copiar el código
   no actualiza por sí solo un ejecutable o instalador anterior.

No requiere dependencias, referencias ni configuración nuevas. No ejecuta SQL
ni modifica datos reales, obras, usuarios o vinculaciones de Supabase.

## Compilación y validación

C#, .NET SDK 10.0.100, WinForms/WPF. Código base `main` de
`bimchimbote-droid/MYG.Presupuestos`, commit
`5eff104c9b208c40857bdbecf42298605e9e1d93`, más las entregas previas gris y cursor.
Rama local de preparación: `work`.

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore -- --permisos-modulos
```

Validación realizada en Linux: solución y pruebas UI compiladas con 0 errores
y 0 advertencias; `git diff --check` aprobado. Las pruebas UI se compilaron,
pero no se ejecutaron: requieren Windows con escritorio y WinForms.

Las pruebas ampliadas envían mensajes de clic, doble clic, contexto y teclado
al control; comprueban selección, foco, contenido, RTF, firma e historial.
Comprueban también rueda, navegación y recuperación de clics al desbloquear.
No mueven el ratón del usuario ni utilizan su portapapeles.

Comprobación manual en Windows:

1. Bloquee únicamente ACU: intente clicar y seleccionar dentro de su tabla.
   El contenido no debe reaccionar; los otros módulos deben seguir editables.
2. Repita con Especificaciones, incluidas reglas, y con Excel, incluidas su
   fórmula, dirección, total y cabeceras. Pruebe doble clic, arrastre y clic derecho.
3. Intente entrar por Tab o escribir tras revocar el permiso de un editor activo.
   No debe entrar en edición ni cambiar datos o historial.
4. Compruebe rueda, barras, cambio de pestañas y elección de otra partida.
   Pruebe las barras de Especificaciones también al activar una ventana inactiva.
5. Restituya un permiso: sólo ese módulo recupera clics y edición.
6. Cambie de tema y pruebe una cuenta lectora global. La estructura debe seguir
   permitiendo elegir partidas para consultarlas, con sus módulos bloqueados.

## GitHub y precauciones

En Visual Studio, revise Cambios de Git, confirme la rama `main`, cree el Commit
y pulse Push. Verifique los archivos en GitHub. Esta entrega publica únicamente
el ZIP en una ruta nueva del repositorio independiente `DESCARGAS`; no hace
Push del repositorio del código.

Compare y combine cualquier personalización posterior antes de reemplazar un
archivo completo. La comprobación interactiva final en Windows y dentro de
Revit, si utiliza el complemento, queda pendiente de ese entorno.
