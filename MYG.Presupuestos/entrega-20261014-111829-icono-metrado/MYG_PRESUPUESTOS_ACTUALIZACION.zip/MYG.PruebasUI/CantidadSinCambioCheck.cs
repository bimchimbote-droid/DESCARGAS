using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class CantidadSinCambioCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        foreach (MYGFuenteMetrado fuente in Enum.GetValues<MYGFuenteMetrado>())
            Verificar(fuente, 3.35m, ["03.35", "+3.35", "3,35", " 3.35 "], exige);
        Verificar(MYGFuenteMetrado.Excel, 2m, ["2.00", "02", "2,0"], exige);
        // La celda muestra dos decimales, pero entrar y salir debe conservar
        // la precisión del metrado existente, sin redondearlo ni validarlo
        // como si el usuario hubiera escrito una cantidad directa nueva.
        Verificar(MYGFuenteMetrado.Excel, 3.3551m, [], exige);
    }

    private static void Verificar(MYGFuenteMetrado fuenteInicial, decimal cantidadInicial,
        string[] equivalentes, Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Cantidad sin editar " + fuenteInicial, "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        string id = MYGProyectoStorage.NuevoId();
        var partida = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Posicion = 1,
            TipoPropuesta = "PARTIDA", Descripcion = "METRADO EXISTENTE", Unidad = "und",
            Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida
            {
                // Un valor directo distinto evita confundirlo con el total
                // que la celda obtiene de la fuente activa.
                Cantidad = fuenteInicial == MYGFuenteMetrado.Cantidad ? cantidadInicial : 9.87m,
                FuenteMetrado = fuenteInicial, PrecioDirecto = 10m
            }
        };
        partida.Costos.Hoja.Poner("A3", "Metrado que debe conservarse");
        partida.Costos.Hoja.Poner("B3", cantidadInicial.ToString(CultureInfo.InvariantCulture));
        partida.Costos.Metrados.Add(new MYGLineaMetrado
        {
            Descripcion = "Metrado manual conservado", Elementos = cantidadInicial,
            CantidadPorElemento = 1m, Referencia = "Plano conservado"
        });
        partida.Costos.MetradosBIM.Add(new MYGMetradoBIM
        {
            ActivoId = "activo-conservado", DocumentoId = "documento-conservado",
            Tabla = "Tabla conservada", Cantidad = cantidadInicial, Unidad = "und"
        });
        presupuesto.Items.Add(partida);
        MYGProyectoStorage.Validar(proyecto);
        string firmaInicial = MYGProyectoStorage.Firma(proyecto);
        var esperado = MYGProyectoStorage.Copia(proyecto);
        var costos = partida.Costos;
        var hoja = costos.Hoja;
        var manuales = costos.Metrados;
        var bim = costos.MetradosBIM;
        string datosMetrado = JsonSerializer.Serialize(new { hoja, manuales, bim });
        int anteriores = 0, cambios = 0, guardados = 0, ediciones = 0;
        var historial = new List<string>();
        void Recordar()
        {
            historial.Add(MYGProyectoStorage.Firma(proyecto));
            anteriores++;
        }

        using var panel = new MYGPanelPresupuesto(() => presupuesto, Recordar, () => cambios++,
            _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (nodo, columna, texto) =>
        {
            if (columna != "CANT" || nodo is not ItemPresupuestoDelphin editada ||
                !MYGFormatoPresupuesto.IntentarCantidad(texto, out decimal cantidad))
                throw new InvalidOperationException("Escriba una cantidad válida con hasta dos decimales.");
            // Sin filtrar valores idénticos aquí: la regresión debe impedir
            // que el evento de la celda invoque una conversión innecesaria.
            MYGEdicionPartida.CambiarCantidad(presupuesto, editada, cantidad, Recordar);
            ediciones++; cambios++;
        }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1600, 900) };
        formulario.Controls.Add(panel);
        formulario.Show();
        panel.Refrescar(); panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        var tabla = Campo<DataGridView>(panel, "estructura");
        var fila = tabla.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, partida));
        var filas = tabla.Rows.Cast<DataGridViewRow>().ToArray();
        string ayudaExcel = fila.Cells["METRADO_EXCEL"].ToolTipText;
        string ayudaCantidad = fila.Cells["CANT"].ToolTipText;
        bool iconoInicial = fuenteInicial == MYGFuenteMetrado.Excel;
        VerificarSinCambio("al cargar");

        // Recorre el mismo evento de un clic en Cantidad y la validación al
        // seleccionar otra celda, sin tocar el texto del editor.
        var editor = EntrarCantidad();
        exige(editor.Text == cantidadInicial.ToString("0.################", CultureInfo.InvariantCulture),
            "Entrar en Cantidad debe usar el valor completo de la fuente activa, conservando su precisión.");
        tabla.CurrentCell = fila.Cells["DESC"];
        Application.DoEvents();
        exige(!tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.CurrentCell, fila.Cells["DESC"]),
            "Seleccionar otra celda debe cerrar Cantidad sin requerir un cambio de valor.");
        VerificarSinCambio("al hacer clic fuera sin editar");

        EntrarCantidad(); panel.FinalizarEdicion(); Application.DoEvents();
        exige(!tabla.IsCurrentCellInEditMode, "Finalizar la celda intacta debe cerrar el editor de Cantidad.");
        VerificarSinCambio("al confirmar sin editar");
        foreach (string texto in equivalentes)
        {
            EntrarCantidad().Text = texto;
            panel.FinalizarEdicion(); Application.DoEvents();
            VerificarSinCambio("al confirmar el mismo valor como " + texto);
        }

        EntrarCantidad().Text = "7.25";
        InvocarEn(typeof(DataGridView), tabla, "ProcessEscapeKey", Keys.Escape);
        Application.DoEvents();
        exige(!tabla.IsCurrentCellInEditMode, "Escape debe cerrar Cantidad y descartar el borrador.");
        VerificarSinCambio("al cancelar una cantidad distinta con Escape");

        EntrarCantidad().Text = "cantidad inválida";
        // Intentar abandonar la celda recorre CellValidating. Según la
        // versión de WinForms, CurrentCell conserva la selección o lanza
        // InvalidOperationException cuando la validación cancela el cambio.
        try { tabla.CurrentCell = fila.Cells["DESC"]; }
        catch (InvalidOperationException) { }
        exige(tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.CurrentCell, fila.Cells["CANT"]) &&
            !string.IsNullOrEmpty(fila.ErrorText),
            "Una cantidad inválida debe mantener abierta la celda con su error, sin aplicar el borrador.");
        VerificarSinCambio("al rechazar una cantidad inválida", verificarCelda: false);
        bool rechazado = false;
        try { panel.FinalizarEdicion(); }
        catch (InvalidOperationException) { rechazado = true; }
        exige(rechazado, "Finalizar con una cantidad inválida debe impedir la confirmación.");
        VerificarSinCambio("al rechazar la confirmación inválida", verificarCelda: false);
        InvocarEn(typeof(DataGridView), tabla, "ProcessEscapeKey", Keys.Escape);
        Application.DoEvents();
        VerificarSinCambio("al cancelar la cantidad inválida");

        EntrarCantidad().Text = "7.25";
        panel.FinalizarEdicion(); Application.DoEvents();
        var costosEsperados = esperado.Presupuestos.Single().Items.Single().Costos;
        costosEsperados.Cantidad = 7.25m; costosEsperados.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        exige(partida.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad && partida.Costos.Cantidad == 7.25m &&
            Convert.ToDecimal(fila.Cells["CANT"].Value) == 7.25m &&
            MYGProyectoStorage.Firma(proyecto) == MYGProyectoStorage.Firma(esperado) &&
            panel.LimitesIndicadorContenido(fila.Cells["METRADO_EXCEL"]).IsEmpty &&
            string.IsNullOrEmpty(fila.Cells["METRADO_EXCEL"].ToolTipText) &&
            anteriores == 1 && cambios == 1 && ediciones == 1 && historial.SequenceEqual([firmaInicial]) && guardados == 0,
            "Cambiar realmente la cantidad debe usar Cantidad directa, retirar el indicador Excel y registrar una sola edición.");
        VerificarDatosConservados();

        // Una vez convertida, confirmar la misma cantidad directa tampoco
        // debe añadir otra operación al historial.
        EntrarCantidad().Text = "7,25";
        panel.FinalizarEdicion(); Application.DoEvents();
        exige(anteriores == 1 && cambios == 1 && ediciones == 1 && guardados == 0 &&
            MYGProyectoStorage.Firma(proyecto) == MYGProyectoStorage.Firma(esperado),
            "Confirmar la nueva cantidad directa con otro separador debe conservar el único cambio existente.");
        VerificarDatosConservados();
        formulario.Close();

        DataGridViewTextBoxEditingControl EntrarCantidad()
        {
            tabla.CurrentCell = fila.Cells["CANT"];
            tabla.Focus();
            InvocarEn(typeof(DataGridView), tabla, "OnCellMouseClick",
                new DataGridViewCellMouseEventArgs(tabla.Columns["CANT"].Index, fila.Index, 4, 4,
                    new MouseEventArgs(MouseButtons.Left, 1, 4, 4, 0)));
            exige(tabla.IsCurrentCellInEditMode && tabla.EditingControl is DataGridViewTextBoxEditingControl,
                "Un clic sobre Cantidad debe abrir el editor real de la celda.");
            return (DataGridViewTextBoxEditingControl)tabla.EditingControl;
        }

        void VerificarSinCambio(string momento, bool verificarCelda = true)
        {
            exige(MYGProyectoStorage.Firma(proyecto) == firmaInicial && costos.FuenteMetrado == fuenteInicial &&
                MYGMotorPresupuestos.Cantidad(presupuesto, partida) == cantidadInicial &&
                anteriores == 0 && cambios == 0 && ediciones == 0 && historial.Count == 0 && guardados == 0,
                $"La fuente {fuenteInicial} debe conservar cantidad, datos e historial {momento}.");
            exige(!panel.LimitesIndicadorContenido(fila.Cells["METRADO_EXCEL"]).IsEmpty == iconoInicial &&
                fila.Cells["METRADO_EXCEL"].ToolTipText == ayudaExcel && fila.Cells["CANT"].ToolTipText == ayudaCantidad,
                $"El indicador Excel y las ayudas deben conservar su estado {momento}.");
            if (verificarCelda)
                exige(Convert.ToDecimal(fila.Cells["CANT"].Value) == cantidadInicial,
                    $"La celda debe recuperar la cantidad completa del metrado {momento}.");
            VerificarDatosConservados();
        }

        void VerificarDatosConservados() => exige(ReferenceEquals(partida.Costos, costos) &&
            ReferenceEquals(costos.Hoja, hoja) && ReferenceEquals(costos.Metrados, manuales) &&
            ReferenceEquals(costos.MetradosBIM, bim) &&
            JsonSerializer.Serialize(new { hoja, manuales, bim }) == datosMetrado &&
            tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas),
            "Editar o consultar Cantidad debe conservar las hojas, los metrados manuales y BIM y las filas existentes.");
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static object InvocarEn(Type tipo, object objeto, string nombre, params object[] argumentos)
    {
        try { return tipo.GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
