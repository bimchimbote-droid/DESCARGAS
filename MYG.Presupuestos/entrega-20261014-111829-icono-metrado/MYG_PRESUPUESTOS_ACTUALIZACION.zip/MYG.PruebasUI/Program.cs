using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class Program
{
    private static int comprobaciones;

    [STAThread]
    private static int Main()
    {
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try
        {
            MYG2027_TemaComercial.Inicializar();
            CursoresUICheck.Ejecutar(Exige);
            VerificarUnidades();
            VerificarCatalogoUnidadesDelphin();
            VerificarConfirmacionArrastre();
            VerificarTemas();
            DisenoProfesionalCheck.Ejecutar(Exige);
            PresupuestoDetalleCheck.Ejecutar(Exige);
            AlertasPartidasUICheck.Ejecutar(Exige);
            IndicadoresContenidoCheck.Ejecutar(Exige);
            CantidadSinCambioCheck.Ejecutar(Exige);
            ReferenciasPartidasUICheck.Ejecutar(Exige);
            MetradoExcelCheck.Ejecutar(Exige);
            MetradoSeleccionEncabezadosCheck.Ejecutar(Exige);
            MetradoAutocompletadoCheck.Ejecutar(Exige);
            MetradoCierreFormulaCheck.Ejecutar(Exige);
            MetradoPlantillasCheck.Ejecutar(Exige);
            MetradoSeleccionReferenciasCheck.Ejecutar(Exige);
            CursoresMetradoCheck.Ejecutar(Exige);
            EspecificacionesEditorCheck.Ejecutar(Exige);
            EspecificacionesBorradorCheck.Ejecutar(Exige);
            EspecificacionesCursorFuenteCheck.Ejecutar(Exige);
            EspecificacionesTituloMargenesCheck.Ejecutar(Exige);
            EspecificacionesMargenesDibujoCheck.Ejecutar(Exige);
            EspecificacionesContextoCheck.Ejecutar(Exige);
            EspecificacionesOscuroScrollCheck.Ejecutar(Exige);
            EspecificacionesExportacionCheck.Ejecutar(Exige);
            HerramientasEditorCheck.Ejecutar(Exige);
            PreciosInicioCheck.Ejecutar(Exige);
            VerificarCabeceraInicio();
            VerificarSelectorInsumoVacio();
            VerificarTiposDeInsumo();
            IndicesInsumoCheck.Ejecutar(Exige);
            VerificarSeleccionMultipleInsumos();
            VerificarCasillasInsumos();
            VerificarCatalogoAutomaticoDesdeACU();
            VerificarMenuACU();
            VerificarBarraACU();
            VerificarSeleccionCostosMultiples();
            VerificarGruposCatalogoCostos();
            Console.WriteLine($"OK {comprobaciones} comprobaciones de interfaz.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            return 1;
        }
    }

    private static void Exige(bool condicion, string mensaje)
    {
        if (!condicion) throw new InvalidOperationException(mensaje);
        comprobaciones++;
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }

    private static void VerificarUnidades()
    {
        // El orden del catálogo reproduce la captura: Bolsas aparece primero,
        // pero la partida debe conservar su propia unidad.
        var unidades = new[]
        {
            new MYGUnidadCatalogo { Simbolo = "Bls", Descripcion = "Bolsas" },
            new MYGUnidadCatalogo { Simbolo = "m²", Descripcion = "Metro cuadrado" },
            new MYGUnidadCatalogo { Simbolo = "m³", Descripcion = "Metro cúbico" },
            new MYGUnidadCatalogo { Simbolo = "und", Descripcion = "Unidad" }
        };
        foreach (string inicial in new[] { "und", "m²", "m³", "m2", "m3", "jgo" })
        {
            using var dialogo = new MYGGuardarPartidaCatalogoForm("P-000001", "PARTIDA", inicial, false, unidades);
            Exige(dialogo.Unidad == inicial, $"Unidad inicial incorrecta para {inicial}.");
            dialogo.Show();
            Application.DoEvents();
            Exige(dialogo.Unidad == inicial, $"Mostrar el diálogo cambió {inicial} por {dialogo.Unidad}.");
            dialogo.BindingContext = new BindingContext();
            Application.DoEvents();
            Exige(dialogo.Unidad == inicial, "Renovar BindingContext cambió la unidad de la partida.");
            var selector = Controles(dialogo).OfType<ComboBox>().Single();
            selector.SelectedIndex = 0;
            Exige(dialogo.Unidad == "Bls", "No se conserva una unidad elegida explícitamente por el usuario.");
            dialogo.BindingContext = new BindingContext();
            Application.DoEvents();
            Exige(dialogo.Unidad == "Bls", "Renovar BindingContext cambió la unidad elegida por el usuario.");
            dialogo.Close();
        }
        using (var selector = MYGUnidadesUI.Selector(unidades, ""))
            Exige(MYGUnidadesUI.Valor(selector) == "und", "Una partida nueva sin unidad debe comenzar en und.");
        using (var selector = MYGUnidadesUI.Selector(unidades, null))
            Exige(MYGUnidadesUI.Valor(selector) == "und", "Una unidad nula debe comenzar en und.");
        using (var selector = MYGUnidadesUI.Selector(Array.Empty<MYGUnidadCatalogo>(), "jgo"))
            Exige(MYGUnidadesUI.Valor(selector) == "jgo", "Un catálogo vacío perdió la unidad existente.");
        using (var selector = MYGUnidadesUI.Selector(unidades, "jgo", conservarUnidadInicial: false))
            Exige(MYGUnidadesUI.Valor(selector) == "und", "Una entrada nueva eligió una unidad ajena al catálogo.");
    }

    private static void VerificarCatalogoUnidadesDelphin()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-Unidades-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "Hoja nueva con unidades Delphin.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var unidades = MYGCatalogoUnidades.Listar(ruta);
            using var catalogo = new MYGUnidadesForm(ruta, () => true);
            catalogo.Show();
            Application.DoEvents();
            var controles = Controles(catalogo).ToArray();
            var tabla = controles.OfType<DataGridView>().Single(x => x.Columns.Contains("SIMBOLO") && x.Columns.Contains("TIPO"));
            var grupos = controles.OfType<TreeView>().Single();
            var buscar = controles.OfType<TextBox>().Single();
            Exige(grupos.Nodes.Cast<TreeNode>().Select(x => x.Text).SequenceEqual(
                new[] { "Todos", "Costos unitarios", "Gastos Generales", "Por tipo de costo" }),
                "El catálogo no ofrece los grupos de unidades de Delphin.");
            Exige(tabla.Rows.Count == 62 && tabla.Rows.Cast<DataGridViewRow>()
                .Select(x => ((MYGUnidadCatalogo)x.Tag).Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() == 62,
                "La vista Todos perdió unidades o mezcló identidades nativas.");
            foreach (var (tipo, total) in new[]
            {
                ("General", 42), ("Global", 10), ("Porcentaje", 6), ("Hora de trabajo", 3), ("Día de trabajo", 1)
            })
                Exige(tabla.Rows.Cast<DataGridViewRow>().Count(x => (string)x.Cells["TIPO"].Value == tipo) == total,
                    $"La columna Tipo no muestra las {total} unidades {tipo} de Delphin.");

            Seleccionar(grupos.Nodes[1], 56, u => u.EsCostoUnitario);
            Seleccionar(grupos.Nodes[2], 17, u => u.EsGastoGeneral);
            var porCosto = grupos.Nodes[3];
            Exige(porCosto.Nodes.Cast<TreeNode>().Select(x => x.Text).SequenceEqual(
                new[] { "Mano de obra", "Materiales", "Equipo", "Subcontratos", "Subpartidas" }),
                "El catálogo no ofrece los cinco grupos por tipo de costo.");
            foreach (var (nombre, tipo, total) in new[]
            {
                ("Mano de obra", MYGGrupoRecurso.ManoObra, 13), ("Materiales", MYGGrupoRecurso.Materiales, 45),
                ("Equipo", MYGGrupoRecurso.Equipo, 16), ("Subcontratos", MYGGrupoRecurso.Subcontratos, 23),
                ("Subpartidas", MYGGrupoRecurso.Subpartidas, 0)
            })
                Seleccionar(porCosto.Nodes.Cast<TreeNode>().Single(x => x.Text == nombre), total, u => u.TiposCosto.Contains(tipo));
            Seleccionar(grupos.Nodes[0], 62, _ => true);

            buscar.Text = "m²";
            Application.DoEvents();
            Exige(tabla.Rows.Count == 2 && tabla.Rows.Cast<DataGridViewRow>()
                .Select(x => (string)x.Cells["TIPO"].Value).OrderBy(x => x).SequenceEqual(new[] { "General", "Global" }),
                "Buscar m² perdió una de las variantes General/Global del catálogo.");
            buscar.Text = "Porcentaje";
            Application.DoEvents();
            Exige(tabla.Rows.Count == 6 && tabla.Rows.Cast<DataGridViewRow>().All(x => ((MYGUnidadCatalogo)x.Tag).Tipo == "P"),
                "La búsqueda por tipo no encuentra las seis unidades de porcentaje.");
            grupos.SelectedNode = grupos.Nodes[2];
            buscar.Text = "Unidad Mes";
            Application.DoEvents();
            Exige(tabla.Rows.Count == 1 && ((MYGUnidadCatalogo)tabla.Rows[0].Tag).Simbolo == "und- mes",
                "La búsqueda no se combina con el filtro Gastos Generales.");
            buscar.Text = "unidad-que-no-existe";
            Application.DoEvents();
            Exige(tabla.Rows.Count == 0, "Una búsqueda sin coincidencias mantiene filas del catálogo.");
            buscar.Clear();
            Seleccionar(grupos.Nodes[0], 62, _ => true);
            catalogo.Close();

            // El catálogo conserva cada variante; las partidas solo guardan el símbolo.
            // Poner Global primero verifica que el selector elija la descripción General.
            var ordenadas = unidades.OrderBy(u => u.Tipo == "G" ? 0 : 1).ToArray();
            foreach (string inicial in new[] { "m²", "m³", "m2", "m3", "und" })
            {
                using var dialogo = new MYGGuardarPartidaCatalogoForm("P-000001", "PARTIDA", inicial, false, ordenadas);
                dialogo.Show();
                Application.DoEvents();
                var selector = Controles(dialogo).OfType<ComboBox>().Single();
                Exige(selector.Items.Count == 55 && dialogo.Unidad == inicial,
                    "El selector duplicó símbolos de variantes nativas o cambió la unidad inicial.");
                if (inicial != "und")
                    Exige(selector.GetItemText(selector.SelectedItem) ==
                        (MYGProyectoStorage.MismaUnidad(inicial, "m²") ? "m² · Metro Cuadrado" : "m³ · Metro Cúbico"),
                        "El selector no utiliza la descripción General para metros cuadrados/cúbicos.");
                dialogo.BindingContext = new BindingContext();
                Application.DoEvents();
                Exige(dialogo.Unidad == inicial, "El catálogo con variantes cambió la unidad al renovar BindingContext.");
                dialogo.Close();
            }

            void Seleccionar(TreeNode nodo, int total, Func<MYGUnidadCatalogo, bool> incluye)
            {
                grupos.SelectedNode = nodo;
                Application.DoEvents();
                var visibles = tabla.Rows.Cast<DataGridViewRow>().Select(x => (MYGUnidadCatalogo)x.Tag).ToArray();
                Exige(visibles.Length == total && visibles.All(incluye) && visibles.Select(x => x.Id).OrderBy(x => x)
                    .SequenceEqual(unidades.Where(incluye).Select(x => x.Id).OrderBy(x => x)),
                    $"El grupo {nodo.Text} no muestra exactamente sus {total} unidades nativas.");
            }
        }
        finally
        {
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static ItemPresupuestoDelphin Nodo(string nombre, string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, ParentId = padre,
            Descripcion = nombre, TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Unidad = titulo ? "" : "und",
            Posicion = 1, Origen = "MODELO", Estado = "PROPUESTA"
        };
    }

    private static void VerificarConfirmacionArrastre()
    {
        var documento = MYGProyectoStorage.Nuevo("PRUEBA DE ARRASTRE");
        documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
        var presupuesto = documento.Presupuestos.Single();
        var origen = Nodo("TÍTULO ORIGEN", titulo: true);
        var destino = Nodo("TÍTULO DESTINO", titulo: true); destino.Posicion = 2;
        var partida = Nodo("PARTIDA A MOVER", origen.Id);
        var subtitulo = Nodo("SUBTÍTULO", origen.Id, titulo: true); subtitulo.Posicion = 2;
        var descendiente = Nodo("DESCENDIENTE", subtitulo.Id);
        presupuesto.Items.AddRange(new[] { origen, partida, subtitulo, descendiente, destino });
        MYGProyectoStorage.Renumerar(presupuesto);
        int antes = 0, despues = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antes++, () => despues++, _ => { },
            () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => documento, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        panel.InicializarCatalogos(() => "sin-uso.sqlite", () => true, () => { });
        panel.InicializarArrastreEstructura(() => true, () => { }, () => { });

        foreach (var item in new[] { partida, origen })
        {
            int antesInicial = antes, despuesInicial = despues;
            foreach (var accion in new[] { DialogResult.No, DialogResult.Cancel, DialogResult.Yes })
            {
                string firma = MYGProyectoStorage.Firma(documento);
                bool mostrado = false, textoCorrecto = false, cancelacionPredeterminada = false;
                string errorDialogo = null; int ciclos = 0;
                using var temporizador = new System.Windows.Forms.Timer { Interval = 40 };
                temporizador.Tick += (_, _) =>
                {
                    var dialogo = Application.OpenForms.Cast<Form>().FirstOrDefault(x => x.Text.EndsWith(" | Confirmar movimiento", StringComparison.Ordinal));
                    if (dialogo == null)
                    {
                        if (++ciclos < 100) return;
                        temporizador.Stop(); errorDialogo = "No apareció el diálogo de confirmación esperado.";
                        foreach (var abierto in Application.OpenForms.Cast<Form>().ToArray()) abierto.Close();
                        return;
                    }
                    temporizador.Stop(); mostrado = true;
                    var controles = Controles(dialogo).ToArray();
                    string texto = string.Join(" ", controles.Select(x => x.Text));
                    textoCorrecto = texto.Contains("Origen:") && texto.Contains("Destino:") &&
                        texto.Contains("TÍTULO ORIGEN") && texto.Contains("TÍTULO DESTINO") && texto.Contains(item.Descripcion) &&
                        (!MYGProyectoStorage.EsTitulo(item) || texto.Contains("También se moverán todas sus partidas y subtítulos."));
                    cancelacionPredeterminada = dialogo.AcceptButton is Button aceptar && aceptar.DialogResult == DialogResult.No &&
                        dialogo.CancelButton is Button cancelar && cancelar.DialogResult == DialogResult.No;
                    if (accion == DialogResult.Cancel) { dialogo.Close(); return; }
                    var boton = controles.OfType<Button>().FirstOrDefault(x => x.DialogResult == accion);
                    if (boton == null) { errorDialogo = "La confirmación carece del botón " + accion; dialogo.Close(); }
                    else boton.PerformClick();
                };
                temporizador.Start();
                // Aplicar por IDs prueba el mismo punto de confirmación del arrastre
                // sin depender de OLE ni de las coordenadas de una pantalla.
                panel.AplicarArrastreEstructura(presupuesto.Id, item.Id, presupuesto.Id, destino.Id, MYGDestinoArrastre.Dentro);
                temporizador.Stop();
                Exige(errorDialogo == null, errorDialogo);
                Exige(mostrado && textoCorrecto, "El movimiento no mostró el origen, el destino y el alcance completos.");
                Exige(cancelacionPredeterminada, "Enter y Escape deben cancelar el movimiento de forma predeterminada.");
                if (accion == DialogResult.Yes)
                    Exige(item.ParentId == destino.Id && antes == antesInicial + 1 && despues == despuesInicial + 1,
                        "La confirmación explícita no aplicó el movimiento una única vez.");
                else
                    Exige(MYGProyectoStorage.Firma(documento) == firma && antes == antesInicial && despues == despuesInicial,
                        "Rechazar o cerrar la confirmación cambió la jerarquía o el historial.");
            }
        }
        Exige(subtitulo.ParentId == origen.Id && descendiente.ParentId == subtitulo.Id,
            "Mover un título no conservó sus subtítulos y partidas descendientes.");

        // Mover el último título de nuevo al mismo destino no requiere confirmar.
        bool confirmacionInesperada = false;
        using var vigilar = new System.Windows.Forms.Timer { Interval = 40 };
        vigilar.Tick += (_, _) =>
        {
            var dialogo = Application.OpenForms.Cast<Form>().FirstOrDefault(x => x.Text.EndsWith(" | Confirmar movimiento", StringComparison.Ordinal));
            if (dialogo == null) return;
            confirmacionInesperada = true; dialogo.Close();
        };
        vigilar.Start();
        panel.AplicarArrastreEstructura(presupuesto.Id, origen.Id, presupuesto.Id, destino.Id, MYGDestinoArrastre.Dentro);
        vigilar.Stop();
        Exige(antes == 2 && despues == 2 && !confirmacionInesperada,
            "Un movimiento sin cambio agregó historial o abrió una confirmación.");
    }

    private static void VerificarTemas()
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            using var formulario = new Form { Text = "Prueba de temas", Size = new(640, 480) };
            var texto = new TextBox { Text = "Descripción que debe conservarse", Dock = DockStyle.Top };
            var opcion = new CheckBox { Text = "Incluir detalle", Checked = true, Dock = DockStyle.Top };
            var boton = new Button { Text = "Guardar", Dock = DockStyle.Top };
            var especificacion = new RichTextBox { Dock = DockStyle.Bottom, Height = 80,
                Rtf = @"{\rtf1\ansi{\colortbl;\red24\green110\blue60;}\b Especificacion\b0\par\cf1 Texto con color conservado.}" };
            var tabla = new DataGridView { Dock = DockStyle.Fill, AllowUserToAddRows = false };
            tabla.Columns.Add("DESC", "Descripción"); tabla.Rows.Add("Texto guardado");
            formulario.Controls.AddRange(new Control[] { tabla, texto, opcion, boton, especificacion });
            formulario.Show();
            MYG2027_TemaComercial.Aplicar(formulario);
            Application.DoEvents();
            tabla.CurrentCell = tabla.Rows[0].Cells[0];
            Exige(tabla.BeginEdit(true), "No se pudo iniciar la edición para probar el cambio de tema.");
            var celda = tabla.CurrentCell;
            ((TextBox)tabla.EditingControl).Text = "Edición pendiente";
            string rtf = especificacion.Rtf;
            for (int modo = 0; modo <= 2; modo++)
            {
                VerificarPaleta();
                Exige(texto.Text == "Descripción que debe conservarse" && opcion.Checked && boton.Text == "Guardar",
                    "Cambiar el tema alteró el contenido o las opciones del formulario.");
                Exige(tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.CurrentCell, celda) &&
                    tabla.EditingControl is TextBox editando && editando.Text == "Edición pendiente" &&
                    Convert.ToString(celda.Value) == "Texto guardado", "Cambiar el tema perdió o confirmó la edición pendiente.");
                Exige(especificacion.Rtf == rtf, "Cambiar el tema modificó el contenido RTF de las especificaciones.");
                Exige(tabla.BackgroundColor == MYG2027_TemaComercial.Superficie &&
                    texto.BackColor == MYG2027_TemaComercial.Superficie && boton.ForeColor.A == 255,
                    "Los controles abiertos no usan la paleta actual.");
                if (modo < 2)
                {
                    MYG2027_TemaComercial.Alternar(false);
                    Application.DoEvents();
                }
            }
            Exige(MYG2027_TemaComercial.Oscuro == original, "Alternar dos veces no restauró el modo original.");
            formulario.Close();
        }
        finally
        {
            // Las pruebas nunca escriben la preferencia de apariencia del usuario.
            if (MYG2027_TemaComercial.Oscuro != original) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarPaleta()
    {
        var colores = new[]
        {
            MYG2027_TemaComercial.Fondo, MYG2027_TemaComercial.Superficie, MYG2027_TemaComercial.SuperficieAlterna,
            MYG2027_TemaComercial.Texto, MYG2027_TemaComercial.Azul, MYG2027_TemaComercial.Borde,
            MYG2027_TemaComercial.Marino, MYG2027_TemaComercial.MarinoClaro, MYG2027_TemaComercial.AzulSuave,
            MYG2027_TemaComercial.Secundario, MYG2027_TemaComercial.Seleccion, MYG2027_TemaComercial.TextoSobreAzul,
            MYG2027_TemaComercial.TextoCabecera
        }.Concat(Enumerable.Range(0, 8).Select(MYG2027_TemaComercial.ColorTitulo))
            .Concat(Enumerable.Range(1, 8).Select(MYG2027_TemaComercial.ColorFiltro))
            .Concat(Enumerable.Range(1, 8).Select(MYG2027_TemaComercial.ColorCabeceraFiltro));
        Exige(colores.All(x => x.A == 255), "La paleta contiene colores transparentes no admitidos por los controles.");
        if (!SystemInformation.HighContrast)
        {
            Exige(DisenoProfesionalCheck.Contraste(MYG2027_TemaComercial.Texto, MYG2027_TemaComercial.Fondo) >= 4.5 &&
                DisenoProfesionalCheck.Contraste(MYG2027_TemaComercial.Texto, MYG2027_TemaComercial.Superficie) >= 4.5 &&
                DisenoProfesionalCheck.Contraste(MYG2027_TemaComercial.Texto, MYG2027_TemaComercial.Seleccion) >= 4.5 &&
                DisenoProfesionalCheck.Contraste(MYG2027_TemaComercial.TextoCabecera, MYG2027_TemaComercial.Marino) >= 4.5 &&
                DisenoProfesionalCheck.Contraste(MYG2027_TemaComercial.TextoSobreAzul, MYG2027_TemaComercial.Azul) >= 4.5 &&
                DisenoProfesionalCheck.Contraste(MYG2027_TemaComercial.Secundario, MYG2027_TemaComercial.Fondo) >= 4.5,
                "La paleta debe mantener contraste legible para textos, selección y acciones en los dos modos.");
        }
    }

    private static void VerificarCabeceraInicio()
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            // Sin credencial no se intenta validar la licencia ni se hacen
            // peticiones. Los botones de la cabecera deben seguir disponibles.
            using var sesion = new MYG.Externo.SesionDesktop();
            using var inicio = new InicioForm(sesion);
            inicio.Show();
            MYG2027_TemaComercial.Aplicar(inicio);
            Application.DoEvents();
            var barra = Controles(inicio).OfType<TableLayoutPanel>().Single(x => x.Name == "barraCabeceraInicio");
            var titulo = Controles(inicio).OfType<Label>().Single(x => x.Name == "tituloInicio");
            var tema = Controles(inicio).OfType<Button>().Single(x => x.Name == "alternarTema");
            var cuenta = Controles(inicio).OfType<Button>().Single(x => x.Name == "iniciarSesionInicio");
            for (int modo = 0; modo < 2; modo++)
            {
                foreach (int ancho in new[] { 900, 1220 })
                {
                    inicio.WindowState = FormWindowState.Normal;
                    inicio.ClientSize = new(ancho, 640);
                    inicio.PerformLayout();
                    Application.DoEvents();
                    RevisarCabecera("ancho " + ancho);
                }
                inicio.WindowState = FormWindowState.Maximized;
                Application.DoEvents();
                RevisarCabecera("maximizado");
                inicio.WindowState = FormWindowState.Normal;
                Application.DoEvents();
                RevisarCabecera("restaurado");
                MYG2027_TemaComercial.Alternar(false);
                Application.DoEvents();
            }
            Exige(MYG2027_TemaComercial.Oscuro == original, "La prueba de inicio no restauró el tema inicial.");
            Exige(!sesion.Autorizado && sesion.Credencial == null,
                "Comprobar la cabecera no debe iniciar sesión ni requerir credenciales.");
            inicio.Close();

            void RevisarCabecera(string estado)
            {
                Exige(ReferenceEquals(tema.Parent, barra) && ReferenceEquals(cuenta.Parent, barra) &&
                    ReferenceEquals(titulo.Parent, barra), "Los controles de inicio salieron de la cabecera: " + estado);
                Exige(tema.Visible && tema.Enabled && cuenta.Visible && cuenta.Enabled && tema.TabStop,
                    "Cambiar de modo o iniciar sesión dejó de estar disponible: " + estado);
                Exige(tema.Width > 0 && tema.Height > 0 && cuenta.Width > 0 && cuenta.Height > 0 &&
                    barra.ClientRectangle.Contains(tema.Bounds) && barra.ClientRectangle.Contains(cuenta.Bounds),
                    "Los botones de inicio quedaron fuera de la cabecera: " + estado);
                Exige(!tema.Bounds.IntersectsWith(cuenta.Bounds) && !tema.Bounds.IntersectsWith(titulo.Bounds) &&
                    !cuenta.Bounds.IntersectsWith(titulo.Bounds), "Los controles de inicio se superponen: " + estado);
                string siguiente = MYG2027_TemaComercial.Oscuro ? "Modo normal" : "Modo oscuro";
                Exige(tema.Text == siguiente && tema.AccessibleName == siguiente,
                    "El botón de inicio no identifica el modo al que se puede cambiar: " + estado);
                Exige(titulo.ForeColor == MYG2027_TemaComercial.TextoCabecera &&
                    barra.BackColor == MYG2027_TemaComercial.Marino,
                    "El título o la cabecera de inicio no conservan el contraste del tema: " + estado);
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != original) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarSelectorInsumoVacio()
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                var documento = MYGProyectoStorage.Nuevo("PRIMER INSUMO DEL PRESUPUESTO");
                documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
                var presupuesto = documento.Presupuestos.Single();
                var partida = Nodo("PARTIDA SIN INSUMOS");
                presupuesto.Items.Add(partida);
                MYGProyectoStorage.Renumerar(presupuesto);
                MYGProyectoStorage.Validar(documento);
                string firma = MYGProyectoStorage.Firma(documento);

                using (var dialogo = new MYGSelectorInsumoForm(presupuesto, partida, null,
                    Array.Empty<MYGUnidadCatalogo>(), null, MYGGrupoRecurso.Materiales))
                {
                    var pestañas = ComprobarImagenes(dialogo);
                    dialogo.Show();
                    Application.DoEvents();
                    var tabla = Controles(dialogo).OfType<DataGridView>().Single(x => x.Columns.Contains("TIPO"));
                    Exige(tabla.Rows.Count == 0, "El selector de un presupuesto vacío debe comenzar sin insumos.");
                    for (int n = 0; n < pestañas.TabPages.Count; n++)
                    {
                        pestañas.SelectedIndex = n;
                        dialogo.Refresh();
                        Application.DoEvents();
                        Exige(pestañas.TabPages[n].Visible, "Una pestaña del selector vacío no se muestra.");
                    }
                    ((Button)dialogo.CancelButton).PerformClick();
                    Exige(dialogo.DialogResult == DialogResult.Cancel && dialogo.Seleccion == null &&
                        MYGProyectoStorage.Firma(documento) == firma,
                        "Mostrar o cancelar el selector vacío modificó el presupuesto.");
                    dialogo.Close();
                }

                var unidades = new[] { new MYGUnidadCatalogo { Simbolo = "kg", Descripcion = "Kilogramo" } };
                using var crear = new MYGSelectorInsumoForm(presupuesto, partida, null,
                    unidades, null, MYGGrupoRecurso.Materiales);
                var tabs = ComprobarImagenes(crear);
                crear.Show();
                tabs.SelectedIndex = 1;
                Application.DoEvents();
                var campos = Controles(tabs.TabPages[1]).OfType<TableLayoutPanel>().Single(x =>
                    x.Controls.OfType<Label>().Any(l => l.Text == "Código estándar:"));
                Campo<TextBox>("Código estándar:").Text = "MAT-PRIMERO";
                Campo<TextBox>("Descripción:").Text = "PRIMER MATERIAL";
                var tipo = Campo<ComboBox>("Tipo de insumo:");
                Exige(tipo.GetItemText(tipo.SelectedItem) == MYGMotorPresupuestos.Grupo(MYGGrupoRecurso.Materiales),
                    "Crear el primer material cambió el tipo inicial a mano de obra.");
                var unidad = Campo<ComboBox>("Unidad:");
                unidad.SelectedIndex = 0;
                Exige(MYGUnidadesUI.Valor(unidad) == "kg", "No se pudo elegir la unidad del primer insumo.");
                Campo<NumericUpDown>("Precio unitario:").Value = 12.35m;
                ((Button)crear.AcceptButton).PerformClick();
                Exige(crear.DialogResult == DialogResult.OK && crear.Seleccion?.NuevoInsumo != null &&
                    MYGProyectoStorage.Firma(documento) == firma,
                    "Crear el primer insumo no entregó una selección válida o modificó el presupuesto antes de aceptar.");
                int cambios = 0;
                string firmaAntesCambio = null;
                var recurso = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, null, crear.Seleccion,
                    antes: () => { firmaAntesCambio = MYGProyectoStorage.Firma(documento); cambios++; });
                var insumo = presupuesto.Costos.Insumos.Single();
                Exige(cambios == 1 && firmaAntesCambio == firma && partida.Costos.Analisis.Single().Id == recurso.Id &&
                    recurso.InsumoId == insumo.Id && insumo.Codigo == "MAT-PRIMERO" &&
                    insumo.Descripcion == "PRIMER MATERIAL" && insumo.Unidad == "kg" &&
                    insumo.Grupo == MYGGrupoRecurso.Materiales && insumo.Precio == 12.35m,
                    "No se agregó correctamente el primer insumo y su recurso al presupuesto vacío.");
                MYGProyectoStorage.Validar(documento);
                crear.Close();

                T Campo<T>(string etiqueta) where T : Control
                {
                    var rotulo = campos.Controls.OfType<Label>().Single(x => x.Text == etiqueta);
                    var posicion = campos.GetPositionFromControl(rotulo);
                    return (T)campos.GetControlFromPosition(posicion.Column + 1, posicion.Row);
                }
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != original) MYG2027_TemaComercial.Alternar(false);
        }

        static TabControl ComprobarImagenes(MYGSelectorInsumoForm dialogo)
        {
            var tabs = Controles(dialogo).OfType<TabControl>().Single();
            var imagenes = tabs.ImageList;
            Exige(imagenes != null && imagenes.Images.Count == 3,
                "El selector no conserva los tres iconos de sus pestañas.");
            // ImageList difiere la creación nativa: forzarla antes de Show
            // detecta imágenes desechadas aunque el constructor termine bien.
            Exige(imagenes.Handle != IntPtr.Zero, "No se pudo crear la lista nativa de iconos del selector.");
            for (int n = 0; n < 3; n++)
            {
                using var imagen = imagenes.Images[n];
                Exige(imagen.Size == new Size(20, 20) && tabs.TabPages[n].ImageIndex == n,
                    "No se puede recuperar un icono válido de las pestañas del selector.");
            }
            return tabs;
        }
    }

    private static T CampoInsumo<T>(Control formulario, string etiqueta) where T : Control
    {
        var rotulo = Controles(formulario).OfType<Label>().Single(x => x.Text == etiqueta);
        var campos = (TableLayoutPanel)rotulo.Parent;
        var posicion = campos.GetPositionFromControl(rotulo);
        return (T)campos.GetControlFromPosition(posicion.Column + 1, posicion.Row);
    }

    private static void VerificarTiposDeInsumo()
    {
        var grupos = new[] { MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo,
            MYGGrupoRecurso.Subcontratos, MYGGrupoRecurso.ManoObra };
        foreach (var grupo in grupos)
        {
            var documento = MYGProyectoStorage.Nuevo("TIPO INICIAL DEL INSUMO");
            documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
            var presupuesto = documento.Presupuestos.Single();
            var partida = Nodo("PARTIDA DE PRUEBA");
            presupuesto.Items.Add(partida);
            MYGProyectoStorage.Renumerar(presupuesto);
            string firma = MYGProyectoStorage.Firma(documento);

            using (var crear = new MYGSelectorInsumoForm(presupuesto, partida, null,
                Array.Empty<MYGUnidadCatalogo>(), null, grupo))
            {
                var tabs = Controles(crear).OfType<TabControl>().Single();
                tabs.SelectedIndex = 1;
                var tipo = CampoInsumo<ComboBox>(crear, "Tipo de insumo:");
                string texto = MYGMotorPresupuestos.Grupo(grupo);
                Exige(tipo.GetItemText(tipo.SelectedItem) == texto, "El constructor no conserva el tipo " + texto + ".");
                crear.Show();
                Application.DoEvents();
                Exige(tipo.GetItemText(tipo.SelectedItem) == texto, "Mostrar Crear nuevo insumo cambió el tipo " + texto + ".");
                crear.BindingContext = new BindingContext();
                Application.DoEvents();
                Exige(tipo.GetItemText(tipo.SelectedItem) == texto, "Renovar BindingContext cambió el tipo inicial " + texto + ".");
                CampoInsumo<TextBox>(crear, "Descripción:").Text = "NUEVO " + texto;
                ((Button)crear.AcceptButton).PerformClick();
                Exige(crear.DialogResult == DialogResult.OK && crear.Selecciones.Count == 1 &&
                    crear.Seleccion.NuevoInsumo.Grupo == grupo && MYGProyectoStorage.Firma(documento) == firma,
                    "Aceptar el nuevo insumo perdió su tipo o modificó el presupuesto antes de aplicar.");
                var agregado = MYGInsumosEdicion.AplicarVarios(presupuesto, partida.Id, crear.Selecciones).Single();
                Exige(agregado.Grupo == grupo && presupuesto.Costos.Insumos.Single().Grupo == grupo,
                    "El insumo nuevo no quedó en su grupo del ACU.");
                MYGProyectoStorage.Validar(documento);
                crear.Close();
            }

            var original = presupuesto.Costos.Insumos.Single();
            using var editar = new MYGInsumoForm(original, Array.Empty<MYGUnidadCatalogo>());
            var selector = CampoInsumo<ComboBox>(editar, "Tipo de insumo:");
            editar.Show();
            Application.DoEvents();
            editar.BindingContext = new BindingContext();
            Application.DoEvents();
            Exige(selector.GetItemText(selector.SelectedItem) == MYGMotorPresupuestos.Grupo(grupo),
                "Mostrar o renovar el contexto del editor cambió el tipo existente.");
            var elegido = grupos[(Array.IndexOf(grupos, grupo) + 1) % grupos.Length];
            selector.SelectedIndex = Enumerable.Range(0, selector.Items.Count)
                .Single(n => selector.GetItemText(selector.Items[n]) == MYGMotorPresupuestos.Grupo(elegido));
            var eleccion = selector.SelectedItem;
            editar.BindingContext = new BindingContext();
            Application.DoEvents();
            Exige(ReferenceEquals(selector.SelectedItem, eleccion), "Renovar BindingContext perdió el tipo elegido explícitamente.");
            ((Button)editar.AcceptButton).PerformClick();
            Exige(editar.DialogResult == DialogResult.OK && editar.Valor.Grupo == elegido && original.Grupo == grupo,
                "El editor no leyó el tipo elegido o modificó el insumo original antes de aplicar.");
            editar.Close();
        }
    }

    private static void VerificarSeleccionMultipleInsumos()
    {
        var documento = MYGProyectoStorage.Nuevo("SELECCIÓN MÚLTIPLE DE INSUMOS");
        documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
        var presupuesto = documento.Presupuestos.Single();
        var partida = Nodo("PARTIDA DESTINO");
        var sub1 = Nodo("PRIMERA SUBPARTIDA"); sub1.Posicion = 2;
        var sub2 = Nodo("SEGUNDA SUBPARTIDA"); sub2.Posicion = 3;
        presupuesto.Items.AddRange(new[] { partida, sub1, sub2 });
        var insumos = new[]
        {
            new MYGInsumo { Codigo = "MAT-01", Descripcion = "MATERIAL", Grupo = MYGGrupoRecurso.Materiales, Unidad = "kg", Precio = 2m },
            new MYGInsumo { Codigo = "EQ-01", Descripcion = "EQUIPO", Grupo = MYGGrupoRecurso.Equipo, Unidad = "hm", Precio = 5m },
            new MYGInsumo { Codigo = "SC-01", Descripcion = "SUBCONTRATO", Grupo = MYGGrupoRecurso.Subcontratos, Unidad = "und", Precio = 8m }
        };
        presupuesto.Costos.Insumos.AddRange(insumos);
        MYGProyectoStorage.Renumerar(presupuesto);
        MYGProyectoStorage.Validar(documento);
        string firma = MYGProyectoStorage.Firma(documento);

        using (var cancelar = new MYGSelectorInsumoForm(presupuesto, partida, null, Array.Empty<MYGUnidadCatalogo>(), null))
        {
            cancelar.Show();
            Application.DoEvents();
            var tabla = Controles(cancelar).OfType<DataGridView>().Single(x => x.Columns.Contains("TIPO"));
            SeleccionarVarias(tabla, 2, 0);
            ((Button)cancelar.CancelButton).PerformClick();
            Exige(cancelar.DialogResult == DialogResult.Cancel && cancelar.Seleccion == null && cancelar.Selecciones.Count == 0 &&
                MYGProyectoStorage.Firma(documento) == firma, "Cancelar una selección múltiple cambió el presupuesto o entregó un lote.");
            cancelar.Close();
        }

        using (var agregar = new MYGSelectorInsumoForm(presupuesto, partida, null, Array.Empty<MYGUnidadCatalogo>(), null))
        {
            agregar.Show();
            Application.DoEvents();
            var tabla = Controles(agregar).OfType<DataGridView>().Single(x => x.Columns.Contains("TIPO"));
            SeleccionarVarias(tabla, 2, 0);
            ((Button)agregar.AcceptButton).PerformClick();
            Exige(agregar.DialogResult == DialogResult.OK && agregar.Selecciones.Select(x => x.InsumoId)
                .SequenceEqual(new[] { insumos[0].Id, insumos[2].Id }) && ReferenceEquals(agregar.Seleccion, agregar.Selecciones[0]) &&
                MYGProyectoStorage.Firma(documento) == firma,
                "Aceptar no entregó todas las filas en su orden visual o cambió el presupuesto antes de aplicar.");
            int cambios = 0;
            string firmaAntes = null;
            var recursos = MYGInsumosEdicion.AplicarVarios(presupuesto, partida.Id, agregar.Selecciones,
                antes: () => { cambios++; firmaAntes = MYGProyectoStorage.Firma(documento); });
            Exige(cambios == 1 && firmaAntes == firma && recursos.Select(x => x.InsumoId)
                .SequenceEqual(new[] { insumos[0].Id, insumos[2].Id }) && partida.Costos.Analisis.SequenceEqual(recursos) &&
                recursos.Select(x => x.Grupo).SequenceEqual(new[] { MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Subcontratos }) &&
                presupuesto.Costos.Insumos.Count == 3, "Aplicar el lote perdió filas, grupos o creó historial o insumos duplicados.");
            agregar.Close();
        }

        firma = MYGProyectoStorage.Firma(documento);
        using (var compuesto = new MYGSelectorInsumoForm(presupuesto, partida, null, Array.Empty<MYGUnidadCatalogo>(), null))
        {
            compuesto.MostrarCompuesto();
            compuesto.Show();
            Application.DoEvents();
            var tabla = Controles(compuesto).OfType<DataGridView>().Single(x => x.Columns.Contains("ITEM"));
            SeleccionarVarias(tabla, 1, 0);
            ((Button)compuesto.AcceptButton).PerformClick();
            Exige(compuesto.DialogResult == DialogResult.OK && compuesto.Selecciones.Select(x => x.SubpartidaIdLocal)
                .SequenceEqual(new[] { sub1.IdLocalMYG, sub2.IdLocalMYG }) && MYGProyectoStorage.Firma(documento) == firma,
                "Seleccionar varias subpartidas no conservó su orden o modificó el presupuesto antes de aplicar.");
            var recursos = MYGInsumosEdicion.AplicarVarios(presupuesto, partida.Id, compuesto.Selecciones);
            Exige(recursos.Count == 2 && recursos.All(x => x.Grupo == MYGGrupoRecurso.Subpartidas) &&
                recursos.Select(x => x.SubpartidaIdLocal).SequenceEqual(new[] { sub1.IdLocalMYG, sub2.IdLocalMYG }),
                "No se agregaron las dos subpartidas seleccionadas.");
            compuesto.Close();
        }

        var reemplazado = partida.Costos.Analisis.First();
        int cantidad = partida.Costos.Analisis.Count;
        firma = MYGProyectoStorage.Firma(documento);
        using (var reemplazar = new MYGSelectorInsumoForm(presupuesto, partida, reemplazado, Array.Empty<MYGUnidadCatalogo>(), null))
        {
            var tabs = Controles(reemplazar).OfType<TabControl>().Single();
            tabs.SelectedIndex = 0;
            reemplazar.Show();
            Application.DoEvents();
            var tablas = Controles(reemplazar).OfType<DataGridView>().ToArray();
            Exige(tablas.All(x => !x.MultiSelect && !x.Columns.Contains("SEL")),
                "Reemplazar un recurso debe conservar la selección singular sin casillas múltiples.");
            var tabla = tablas.Single(x => x.Columns.Contains("TIPO"));
            tabla.CurrentCell = tabla.Rows[1].Cells["DESC"];
            ((Button)reemplazar.AcceptButton).PerformClick();
            Exige(reemplazar.DialogResult == DialogResult.OK && reemplazar.Selecciones.Count == 1 &&
                reemplazar.Seleccion.InsumoId == insumos[1].Id && MYGProyectoStorage.Firma(documento) == firma,
                "Reemplazar no entregó una única selección o modificó el presupuesto antes de aplicar.");
            var recurso = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, reemplazado.Id, reemplazar.Seleccion);
            Exige(partida.Costos.Analisis.Count == cantidad && recurso.Id == reemplazado.Id && recurso.InsumoId == insumos[1].Id,
                "El reemplazo singular agregó recursos o perdió el identificador de la fila.");
            reemplazar.Close();
        }
        MYGProyectoStorage.Validar(documento);

        static void SeleccionarVarias(DataGridView tabla, int primero, int segundo)
        {
            Exige(tabla.MultiSelect && tabla.SelectionMode == DataGridViewSelectionMode.FullRowSelect,
                "Agregar insumos o subpartidas no permite seleccionar varias filas con Ctrl/Shift.");
            tabla.CurrentCell = tabla.Rows[primero].Cells["DESC"];
            tabla.ClearSelection();
            tabla.Rows[primero].Selected = true;
            tabla.Rows[segundo].Selected = true;
            Exige(tabla.SelectedRows.Count == 2, "No se pueden conservar dos filas seleccionadas a la vez.");
        }
    }

    private static void VerificarCasillasInsumos()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-Casillas-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "Catalogo.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var documento = MYGProyectoStorage.Nuevo("CASILLAS DE INSUMOS");
            documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
            var presupuesto = documento.Presupuestos.Single();
            var partida = Nodo("PARTIDA DESTINO");
            var sub1 = Nodo("PRIMERA SUBPARTIDA"); sub1.Posicion = 2;
            var sub2 = Nodo("SEGUNDA SUBPARTIDA"); sub2.Posicion = 3;
            presupuesto.Items.AddRange(new[] { partida, sub1, sub2 });
            var locales = new[]
            {
                new MYGInsumo { Codigo = "MAT-01", Descripcion = "MATERIAL", Grupo = MYGGrupoRecurso.Materiales, Unidad = "kg", Precio = 2m },
                new MYGInsumo { Codigo = "EQ-01", Descripcion = "EQUIPO", Grupo = MYGGrupoRecurso.Equipo, Unidad = "hm", Precio = 5m },
                new MYGInsumo { Codigo = "SC-01", Descripcion = "SUBCONTRATO", Grupo = MYGGrupoRecurso.Subcontratos, Unidad = "und", Precio = 8m }
            };
            presupuesto.Costos.Insumos.AddRange(locales);
            foreach (var insumo in locales) MYGCatalogos.GuardarInsumo(ruta, insumo);
            MYGProyectoStorage.Renumerar(presupuesto);
            string firma = MYGProyectoStorage.Firma(documento);
            string[] entradasIniciales = MYGCatalogos.Listar(ruta, false).Select(x => x.Id).OrderBy(x => x).ToArray();

            using (var cancelar = NuevoSelector())
            {
                cancelar.Show(); Application.DoEvents();
                var origen = ControlConNombre<ComboBox>(cancelar, "cboOrigenInsumos");
                var tabla = ControlConNombre<DataGridView>(cancelar, "selectorInsumos");
                Exige(origen.GetItemText(origen.SelectedItem) == "Catálogo de insumos" && tabla.Rows.Count == 3 &&
                    tabla.Rows.Cast<DataGridViewRow>().All(x => x.Tag is MYGEntradaCatalogo),
                    "El selector no muestra por defecto las entradas disponibles del catálogo.");
                ComprobarCasillas(tabla);
                Marcar(tabla.Rows[0]); Marcar(tabla.Rows[2]);
                Exige(ControlConNombre<Label>(cancelar, "lblInsumosSeleccionados").Text.Contains("2"),
                    "El contador no incluye las dos casillas marcadas.");
                origen.SelectedIndex = 0; Application.DoEvents();
                Exige(tabla.Rows.Cast<DataGridViewRow>().All(x => !Marcada(x)),
                    "Cambiar de catálogo a presupuesto conserva casillas de una fuente diferente.");
                Marcar(tabla.Rows[1]);
                ControlConNombre<TextBox>(cancelar, "txtFiltroInsumos").Text = "SIN COINCIDENCIAS";
                Application.DoEvents();
                Exige(tabla.Rows.Count == 0 && ControlConNombre<Label>(cancelar, "lblInsumosSeleccionados").Text.Contains("1"),
                    "Ocultar un insumo marcado con el filtro perdió su selección o su contador.");
                ((Button)cancelar.CancelButton).PerformClick();
                Exige(cancelar.DialogResult == DialogResult.Cancel && cancelar.Selecciones.Count == 0 &&
                    MYGProyectoStorage.Firma(documento) == firma && MYGCatalogos.Listar(ruta, false).Select(x => x.Id)
                        .OrderBy(x => x).SequenceEqual(entradasIniciales),
                    "Cancelar las casillas modificó el presupuesto, registró insumos o entregó una selección.");
                cancelar.Close();
            }

            using (var agregar = NuevoSelector())
            {
                agregar.Show(); Application.DoEvents();
                ControlConNombre<ComboBox>(agregar, "cboOrigenInsumos").SelectedIndex = 0;
                var tabla = ControlConNombre<DataGridView>(agregar, "selectorInsumos");
                Marcar(tabla.Rows[0]); Marcar(tabla.Rows[2]);
                tabla.CurrentCell = tabla.Rows[1].Cells["DESC"];
                tabla.ClearSelection(); tabla.Rows[1].Selected = true;
                Exige(tabla.SelectedRows.Count == 1 && Marcada(tabla.Rows[0]) && Marcada(tabla.Rows[2]),
                    "Marcar varios insumos requiere mantener varias filas azules seleccionadas.");
                ((Button)agregar.AcceptButton).PerformClick();
                Exige(agregar.DialogResult == DialogResult.OK && agregar.Selecciones.Select(x => x.InsumoId)
                    .SequenceEqual(new[] { locales[0].Id, locales[2].Id }) && MYGProyectoStorage.Firma(documento) == firma,
                    "Aceptar incluyó una fila azul sin marcar o perdió una casilla marcada.");
                agregar.Close();
            }

            using (var filtrar = NuevoSelector())
            {
                filtrar.Show(); Application.DoEvents();
                ControlConNombre<ComboBox>(filtrar, "cboOrigenInsumos").SelectedIndex = 0;
                var tabla = ControlConNombre<DataGridView>(filtrar, "selectorInsumos");
                var buscar = ControlConNombre<TextBox>(filtrar, "txtFiltroInsumos");
                Marcar(tabla.Rows[0]); buscar.Text = "EQ-01"; Application.DoEvents();
                Exige(tabla.Rows.Count == 1 && !Marcada(tabla.Rows[0]), "Filtrar transfirió una marca a otra fila.");
                ControlConNombre<Button>(filtrar, "btnMarcarInsumosVisibles").PerformClick();
                Exige(Marcada(tabla.Rows[0]) && ControlConNombre<Label>(filtrar, "lblInsumosSeleccionados").Text.Contains("2"),
                    "Marcar visibles perdió el insumo marcado que quedó oculto.");
                buscar.Clear(); Application.DoEvents();
                Exige(Marcada(tabla.Rows[0]) && Marcada(tabla.Rows[1]) && !Marcada(tabla.Rows[2]),
                    "Limpiar el filtro no recupera las casillas de los mismos insumos.");
                ControlConNombre<Button>(filtrar, "btnLimpiarInsumosSeleccion").PerformClick();
                Exige(tabla.Rows.Cast<DataGridViewRow>().All(x => !Marcada(x)), "Limpiar selección mantiene casillas marcadas.");
                Marcar(tabla.Rows[0]); tabla.Rows[0].Cells["SEL"].Value = false; Application.DoEvents();
                Exige(!Marcada(tabla.Rows[0]) && ControlConNombre<Label>(filtrar, "lblInsumosSeleccionados").Text.Contains("0"),
                    "Desmarcar la última casilla no deja el contador en cero.");
                bool rechazoVacio = false;
                try
                {
                    // La misma aceptación, sin su envoltorio MessageBox: evita
                    // bloquear la prueba en la advertencia de selección vacía.
                    typeof(MYGSelectorInsumoForm).GetMethod("Aceptar", System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.NonPublic).Invoke(filtrar, null);
                }
                catch (System.Reflection.TargetInvocationException ex) when (ex.InnerException is InvalidOperationException)
                { rechazoVacio = true; }
                Exige(rechazoVacio && filtrar.DialogResult != DialogResult.OK && filtrar.Selecciones.Count == 0,
                    "Desmarcar la última casilla agrega la fila azul sin autorización.");
                ControlConNombre<Button>(filtrar, "btnLimpiarInsumosSeleccion").PerformClick();
                Marcar(tabla.Rows[0]); buscar.Text = "EQ-01"; Application.DoEvents(); Marcar(tabla.Rows[0]);
                ((Button)filtrar.AcceptButton).PerformClick();
                Exige(filtrar.DialogResult == DialogResult.OK && filtrar.Selecciones.Select(x => x.InsumoId)
                    .SequenceEqual(new[] { locales[0].Id, locales[1].Id }),
                    "Aceptar con filtro omite los insumos marcados ocultos o cambia su orden.");
                filtrar.Close();
            }

            using (var compuesto = NuevoSelector())
            {
                compuesto.MostrarCompuesto(); compuesto.Show(); Application.DoEvents();
                var tabla = ControlConNombre<DataGridView>(compuesto, "selectorSubpartidas");
                ComprobarCasillas(tabla); Marcar(tabla.Rows[0]);
                ControlConNombre<TextBox>(compuesto, "txtFiltroSubpartidas").Text = "SEGUNDA";
                Application.DoEvents(); Marcar(tabla.Rows[0]);
                ((Button)compuesto.AcceptButton).PerformClick();
                Exige(compuesto.DialogResult == DialogResult.OK && compuesto.Selecciones.Select(x => x.SubpartidaIdLocal)
                    .SequenceEqual(new[] { sub1.IdLocalMYG, sub2.IdLocalMYG }),
                    "Las casillas de subpartidas no conservan las filas marcadas ocultas.");
                compuesto.Close();
            }

            using (var catalogo = new MYGCatalogoPropioForm(ruta, false, () => true))
            {
                catalogo.Show(); Application.DoEvents();
                var tabla = Controles(catalogo).OfType<DataGridView>().Single();
                ComprobarCasillas(tabla);
                string[] seleccionadas = new[] { ((MYGEntradaCatalogo)tabla.Rows[0].Tag).Id, ((MYGEntradaCatalogo)tabla.Rows[2].Tag).Id };
                string codigoSinMarcar = ((MYGEntradaCatalogo)tabla.Rows[1].Tag).Codigo;
                Marcar(tabla.Rows[0]); Marcar(tabla.Rows[2]);
                ControlConNombre<TextBox>(catalogo, "txtFiltroCatalogo").Text = codigoSinMarcar; Application.DoEvents();
                Exige(tabla.Rows.Count == 1 && !Marcada(tabla.Rows[0]) &&
                    ControlConNombre<Label>(catalogo, "lblCatalogoSeleccionados").Text.Contains("2"),
                    "El filtro del catálogo perdió las marcas ocultas o marcó otro insumo.");
                tabla.CurrentCell = tabla.Rows[0].Cells["DESC"];
                tabla.ClearSelection(); tabla.Rows[0].Selected = true;
                ((Button)catalogo.AcceptButton).PerformClick();
                Exige(catalogo.DialogResult == DialogResult.OK && catalogo.Seleccionadas.Select(x => x.Id).SequenceEqual(seleccionadas) &&
                    catalogo.Seleccionada.Id == seleccionadas[0], "Usar selección del catálogo no entrega solamente las casillas marcadas.");
                catalogo.Close();
            }
            using (var administrar = new MYGCatalogoPropioForm(ruta, false, () => true, soloAdministrar: true))
            {
                var tabla = Controles(administrar).OfType<DataGridView>().Single();
                Exige(!tabla.MultiSelect && !tabla.Columns.Contains("SEL"), "Administrar catálogo permite una selección múltiple para editar.");
            }
            using (var partidas = new MYGCatalogoPropioForm(ruta, true, () => true))
            {
                var tabla = Controles(partidas).OfType<DataGridView>().Single();
                Exige(!tabla.MultiSelect && !tabla.Columns.Contains("SEL"), "El catálogo de partidas cambió a selección múltiple.");
            }
            Exige(MYGProyectoStorage.Firma(documento) == firma && MYGCatalogos.Listar(ruta, false).Select(x => x.Id)
                .OrderBy(x => x).SequenceEqual(entradasIniciales), "Seleccionar con casillas modifica las fuentes antes de aplicar.");

            MYGSelectorInsumoForm NuevoSelector() => new(presupuesto, partida, null, Array.Empty<MYGUnidadCatalogo>(), ruta);
        }
        finally
        {
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }

        static void ComprobarCasillas(DataGridView tabla)
        {
            Exige(tabla.Visible && !tabla.ReadOnly && tabla.Columns[0] is DataGridViewCheckBoxColumn casilla &&
                casilla.Name == "SEL" && casilla.Visible && !casilla.ReadOnly && casilla.Width >= 35 &&
                tabla.Columns.Cast<DataGridViewColumn>().Where(x => x.Name != "SEL").All(x => x.ReadOnly),
                "Las casillas no son visibles/editables en la primera columna o permiten editar los datos del insumo.");
            Exige(tabla.Rows.Cast<DataGridViewRow>().All(x => !x.Cells["SEL"].ReadOnly), "Una fila bloquea su casilla de selección.");
        }
        static bool Marcada(DataGridViewRow fila) => Equals(fila.Cells["SEL"].Value, true);
        static void Marcar(DataGridViewRow fila)
        {
            // Cambia solo esta casilla; no depende de Ctrl ni de la selección azul.
            fila.DataGridView.CurrentCell = fila.Cells["SEL"];
            fila.Cells["SEL"].Value = true;
            fila.DataGridView.EndEdit(); Application.DoEvents();
            Exige(Marcada(fila), "No se pudo marcar individualmente una casilla.");
        }
    }

    private static T ControlConNombre<T>(Control padre, string nombre) where T : Control =>
        Controles(padre).OfType<T>().Single(x => x.Name == nombre);

    private static void VerificarCatalogoAutomaticoDesdeACU()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-CatalogoAutomatico-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "Catalogo.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var documento = MYGProyectoStorage.Nuevo("REGISTRO AUTOMÁTICO DESDE EL ACU");
            documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
            var presupuesto = documento.Presupuestos.Single();
            var partida = Nodo("PARTIDA DE PRUEBA"); presupuesto.Items.Add(partida);
            var previo = new MYGInsumo { Codigo = "PREV-01", Descripcion = "MATERIAL CREADO ANTERIORMENTE",
                Grupo = MYGGrupoRecurso.Materiales, Unidad = "kg", Precio = 9m };
            presupuesto.Costos.Insumos.Add(previo);
            partida.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = previo.Id, Grupo = previo.Grupo });
            MYGProyectoStorage.Renumerar(presupuesto);
            MYGProyectoStorage.Validar(documento);
            int antes = 0, despues = 0; string firmaAntesCambio = null;
            using var anfitrion = new Form { Text = "Prueba del catálogo automático", ClientSize = new(1400, 800) };
            using var panel = new MYGPanelPresupuesto(() => presupuesto,
                () => { antes++; firmaAntesCambio = MYGProyectoStorage.Firma(documento); }, () => despues++, _ => { },
                () => Task.CompletedTask, _ => { });
            panel.InicializarEstructura(() => documento, _ => { }, _ => { }, (_, _, _) => { },
                () => MYGCatalogoUnidades.Listar(ruta));
            panel.InicializarCatalogos(() => ruta, () => true, () => { });
            anfitrion.Controls.Add(panel); anfitrion.Show();
            panel.SeleccionarPartidaCatalogo(partida.Id); Application.DoEvents();
            var acu = Controles(panel).OfType<DataGridView>().Single(x => x.Columns.Contains("MODO"));

            UsarDialogoPrueba<MYGCatalogoPropioForm>(panel.MostrarCatalogoInsumos, catalogo =>
            {
                var tabla = Controles(catalogo).OfType<DataGridView>().Single();
                Exige(tabla.Rows.Count == 1 && ((MYGEntradaCatalogo)tabla.Rows[0].Tag).Descripcion == previo.Descripcion,
                    "Abrir el catálogo no recupera el insumo local creado anteriormente.");
                ((Button)catalogo.CancelButton).PerformClick();
            });
            var entradaPrevia = MYGCatalogos.Listar(ruta, false).Single();
            Exige(previo.CatalogoMYGId == entradaPrevia.Id && previo.CatalogoMYGRuta == Path.GetFullPath(ruta) &&
                entradaPrevia.Grupo == MYGGrupoRecurso.Materiales.ToString(),
                "La recuperación del insumo anterior perdió su vínculo o lo registró con otro tipo.");
            string firma = MYGProyectoStorage.Firma(documento); int historialAntes = antes, historialDespues = despues;
            UsarDialogoPrueba<MYGCatalogoPropioForm>(panel.MostrarCatalogoInsumos,
                catalogo => ((Button)catalogo.CancelButton).PerformClick());
            Exige(MYGProyectoStorage.Firma(documento) == firma && MYGCatalogos.Listar(ruta, false).Count == 1 &&
                antes == historialAntes && despues == historialDespues,
                "Reabrir el catálogo duplica el insumo anterior o registra otro cambio de historial.");

            foreach (var grupo in new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales,
                MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos })
            {
                firma = MYGProyectoStorage.Firma(documento); historialAntes = antes; historialDespues = despues;
                int cantidadCatalogo = MYGCatalogos.Listar(ruta, false).Count;
                string descripcion = "NUEVO AUTOMÁTICO " + MYGMotorPresupuestos.Grupo(grupo);
                CrearDesdeCabecera(grupo, descripcion, aceptar: true);
                var insumo = presupuesto.Costos.Insumos.Single(x => x.Descripcion == descripcion);
                var entrada = MYGCatalogos.Listar(ruta, false).Single(x => x.Id == insumo.CatalogoMYGId);
                var guardado = MYGCatalogos.LeerInsumo(ruta, entrada.Id, entrada.Revision);
                Exige(MYGCatalogos.Listar(ruta, false).Count == cantidadCatalogo + 1 && insumo.Grupo == grupo &&
                    entrada.Grupo == grupo.ToString() && guardado.Grupo == grupo && entrada.Descripcion == descripcion &&
                    entrada.Codigo == insumo.Codigo && !string.IsNullOrWhiteSpace(insumo.Codigo) &&
                    insumo.CatalogoMYGRuta == Path.GetFullPath(ruta) &&
                    partida.Costos.Analisis.Single(x => x.InsumoId == insumo.Id).Grupo == grupo,
                    "Crear desde " + grupo + " no publica inmediatamente el insumo con su tipo, código y referencia correctos.");
                Exige(antes == historialAntes + 1 && despues == historialDespues + 1 && firmaAntesCambio == firma,
                    "Crear y registrar automáticamente el insumo no representa un único cambio reversible del presupuesto.");
                MYGProyectoStorage.Validar(documento);
            }

            firma = MYGProyectoStorage.Firma(documento); historialAntes = antes; historialDespues = despues;
            string[] ids = MYGCatalogos.Listar(ruta, false).Select(x => x.Id).OrderBy(x => x).ToArray();
            CrearDesdeCabecera(MYGGrupoRecurso.Materiales, "INSUMO CANCELADO", aceptar: false);
            Exige(MYGProyectoStorage.Firma(documento) == firma && antes == historialAntes && despues == historialDespues &&
                MYGCatalogos.Listar(ruta, false).Select(x => x.Id).OrderBy(x => x).SequenceEqual(ids),
                "Cancelar la creación de un insumo escribió datos, creó una entrada de catálogo o agregó historial.");
            UsarDialogoPrueba<MYGCatalogoPropioForm>(panel.MostrarCatalogoInsumos, catalogo =>
            {
                var tabla = Controles(catalogo).OfType<DataGridView>().Single();
                Exige(tabla.Rows.Count == 5 && tabla.Columns[0] is DataGridViewCheckBoxColumn &&
                    tabla.Rows.Cast<DataGridViewRow>().Select(x => ((MYGEntradaCatalogo)x.Tag).Id).OrderBy(x => x).SequenceEqual(ids),
                    "El catálogo abierto desde el panel no muestra todos los insumos creados ni sus casillas.");
                ((Button)catalogo.CancelButton).PerformClick();
            });
            Exige(MYGProyectoStorage.Firma(documento) == firma && antes == historialAntes && despues == historialDespues,
                "Consultar el catálogo después de crear insumos modifica el presupuesto.");
            anfitrion.Close();

            void CrearDesdeCabecera(MYGGrupoRecurso grupo, string descripcion, bool aceptar)
            {
                var cabecera = acu.Rows.Cast<DataGridViewRow>().Single(x => x.Tag is MYGGrupoRecurso g && g == grupo);
                acu.CurrentCell = cabecera.Cells["DESC"];
                int entradasAntes = MYGCatalogos.Listar(ruta, false).Count;
                UsarDialogoPrueba<MYGSelectorInsumoForm>(() =>
                {
                    var menu = acu.ContextMenuStrip; menu.Show(acu, new Point(8, 8)); Application.DoEvents();
                    menu.Items.OfType<ToolStripMenuItem>().Single(x => x.Text == "Insertar insumo").PerformClick();
                    menu.Close();
                }, dialogo =>
                {
                    var origen = ControlConNombre<ComboBox>(dialogo, "cboOrigenInsumos");
                    var tabla = ControlConNombre<DataGridView>(dialogo, "selectorInsumos");
                    Exige(origen.GetItemText(origen.SelectedItem) == "Catálogo de insumos" && tabla.Rows.Count == entradasAntes,
                        "Insertar desde una cabecera no ofrece el catálogo actualizado.");
                    Controles(dialogo).OfType<TabControl>().Single().SelectedIndex = 1; Application.DoEvents();
                    var tipo = CampoInsumo<ComboBox>(dialogo, "Tipo de insumo:");
                    Exige(tipo.GetItemText(tipo.SelectedItem) == MYGMotorPresupuestos.Grupo(grupo),
                        "Crear desde la cabecera cambió automáticamente el tipo de insumo.");
                    CampoInsumo<TextBox>(dialogo, "Código estándar:").Clear();
                    CampoInsumo<TextBox>(dialogo, "Descripción:").Text = descripcion;
                    CampoInsumo<NumericUpDown>(dialogo, "Precio unitario:").Value = 12.35m;
                    Exige(MYGCatalogos.Listar(ruta, false).Count == entradasAntes,
                        "Escribir los campos de un nuevo insumo lo publica antes de aceptarlo.");
                    ((Button)(aceptar ? dialogo.AcceptButton : dialogo.CancelButton)).PerformClick();
                });
            }
        }
        finally
        {
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void UsarDialogoPrueba<T>(Action abrir, Action<T> operar) where T : Form
    {
        bool mostrado = false; string error = null;
        var plazo = System.Diagnostics.Stopwatch.StartNew();
        using var temporizador = new System.Windows.Forms.Timer { Interval = 40 };
        temporizador.Tick += (_, _) =>
        {
            if (plazo.Elapsed > TimeSpan.FromSeconds(10))
            {
                Console.Error.WriteLine("La prueba quedó bloqueada en un diálogo inesperado: " + typeof(T).Name);
                Environment.Exit(1); return;
            }
            if (mostrado) return;
            var dialogo = Application.OpenForms.OfType<T>().FirstOrDefault();
            if (dialogo == null) return;
            mostrado = true;
            try { operar(dialogo); }
            catch (Exception ex) { error = ex.ToString(); dialogo.Close(); }
        };
        temporizador.Start(); abrir(); Application.DoEvents(); temporizador.Stop();
        Exige(mostrado && error == null, error ?? "No se abrió el diálogo real " + typeof(T).Name + ".");
    }

    private static void VerificarBarraACU()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-BarraACU-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "Catalogo.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var documento = MYGProyectoStorage.Nuevo("HERRAMIENTAS EXCLUSIVAS DEL ACU");
            documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
            var presupuesto = documento.Presupuestos.Single();
            var titulo = Nodo("TÍTULO DEL PRESUPUESTO", titulo: true);
            var partida = Nodo("PARTIDA DE LA BARRA ACU", titulo.Id);
            var otraPartida = Nodo("OTRA PARTIDA CON SU ACU", titulo.Id); otraPartida.Posicion = 2;
            var tituloAnidado = Nodo("TÍTULO ANIDADO", titulo.Id, titulo: true); tituloAnidado.Posicion = 3;
            var partidaAnidada = Nodo("PARTIDA DESCENDIENTE", tituloAnidado.Id);
            var partidaFueraTitulo = Nodo("PARTIDA FUERA DEL TÍTULO"); partidaFueraTitulo.Posicion = 2;
            partida.Costos.Cantidad = 2m;
            presupuesto.Items.AddRange(new[] { titulo, partida, otraPartida, tituloAnidado, partidaAnidada, partidaFueraTitulo });
            var materiales = Enumerable.Range(1, 3).Select(n => new MYGInsumo
            {
                Codigo = "MAT-" + n, Descripcion = "MATERIAL " + n, Grupo = MYGGrupoRecurso.Materiales,
                Unidad = "kg", Precio = n * 3.25m
            }).ToArray();
            var equipo = new MYGInsumo { Codigo = "EQ-1", Descripcion = "EQUIPO ÚNICO",
                Grupo = MYGGrupoRecurso.Equipo, Unidad = "hm", Precio = 7.5m };
            presupuesto.Costos.Insumos.AddRange(materiales.Append(equipo));
            MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, presupuesto.Costos.Insumos);
            var recursos = materiales.Select((i, n) => new MYGRecursoACU
            { InsumoId = i.Id, Grupo = i.Grupo, Cantidad = n + 1 }).ToArray();
            var recursoEquipo = new MYGRecursoACU { InsumoId = equipo.Id, Grupo = equipo.Grupo, Cantidad = 2m };
            var equipoOtroACU = new MYGRecursoACU { InsumoId = equipo.Id, Grupo = equipo.Grupo, Cantidad = 1m };
            otraPartida.Costos.Analisis.Add(equipoOtroACU);
            // Intercalar otro grupo en el almacenamiento detecta flechas calculadas
            // sobre el análisis completo en lugar de los vecinos del mismo grupo.
            partida.Costos.Analisis.AddRange(new[] { recursos[0], recursoEquipo, recursos[1], recursos[2] });
            MYGProyectoStorage.Renumerar(presupuesto);
            MYGProyectoStorage.Validar(documento);
            int antes = 0, despues = 0, guardadosMultiples = 0;
            string firmaAntesCambio = null;
            bool autorizado = true;
            using var anfitrion = new Form { Text = "Prueba de herramientas ACU", ClientSize = new(1400, 800) };
            using var panel = new MYGPanelPresupuesto(() => presupuesto,
                () => { antes++; firmaAntesCambio = MYGProyectoStorage.Firma(documento); },
                () => despues++, _ => { }, () => Task.CompletedTask, _ => { });
            panel.InicializarEstructura(() => documento, _ => { }, _ => { }, (_, _, _) => { },
                () => MYGCatalogoUnidades.Listar(ruta));
            panel.InicializarCatalogos(() => ruta, () => autorizado, () => { });
            panel.InicializarHerramientas((_, _) => false, (_, _) => { }, () =>
            { guardadosMultiples++; panel.GuardarCostosMultiples(); });
            anfitrion.Controls.Add(panel); anfitrion.Show();
            panel.SeleccionarPartidaCatalogo(partida.Id); Application.DoEvents();
            var acu = Controles(panel).OfType<DataGridView>().Single(x => x.Columns.Contains("MODO"));
            var barra = ControlConNombre<ToolStrip>(panel, "barraHerramientasACU");
            var paginaACU = (TabPage)barra.Parent;
            var detalle = (TabControl)paginaACU.Parent;
            var vistas = Controles(panel).OfType<TabControl>().Single(x => x.TabPages.Cast<TabPage>()
                .Any(p => p.Text == "Lista de Insumos"));
            var subir = Accion("subirRecursoACU");
            var bajar = Accion("bajarRecursoACU");
            var insertar = Accion("insertarRecursoACU");
            var editar = Accion("editarRecursoACU");
            var eliminar = Accion("eliminarRecursoACU");
            var grabar = Accion("grabarDataACU");
            var recalcular = Accion("recalcularACU");
            var exportar = Accion("exportarACU");
            var centro = Controles(panel).OfType<ToolStrip>().SelectMany(x => x.Items.OfType<ToolStripButton>())
                .Single(x => x.Name == "grabarCostosMultiplesEstructura");
            Exige(paginaACU.Text == "Análisis de C.U." && barra.Dock == DockStyle.Right &&
                barra.Items.OfType<ToolStripButton>().All(x => x.Image != null && !string.IsNullOrWhiteSpace(x.ToolTipText)),
                "La barra del ACU no está en su propia franja o sus acciones no ofrecen iconos y ayuda.");
            Exige(centro.Owner != barra && centro.Text.Contains("costos", StringComparison.OrdinalIgnoreCase) &&
                centro.Text.Contains("múltiples", StringComparison.OrdinalIgnoreCase),
                "El botón central no identifica Grabar data de costos múltiples o pertenece a la barra ACU.");

            ComprobarFlechas(recursos[0], arriba: false, abajo: true);
            ComprobarFlechas(recursos[1], arriba: true, abajo: true);
            ComprobarFlechas(recursos[2], arriba: true, abajo: false);
            ComprobarFlechas(recursoEquipo, arriba: false, abajo: false);
            string firma = MYGProyectoStorage.Firma(documento);
            decimal precio = MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario;
            decimal total = MYGMotorPresupuestos.TotalPartida(presupuesto, partida);
            Seleccionar(recursos[0]);
            bajar.PerformClick(); Application.DoEvents();
            Exige(partida.Costos.Analisis.SequenceEqual(new[] { recursos[1], recursoEquipo, recursos[0], recursos[2] }) &&
                ReferenceEquals(acu.CurrentRow?.Tag, recursos[0]) && antes == 1 && despues == 1 && firmaAntesCambio == firma,
                "La flecha del ACU no mueve solamente al vecino del grupo, pierde la selección o registra historial incorrecto.");
            Exige(MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario == precio &&
                MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == total,
                "Mover desde la barra ACU cambió el precio o el total de la partida.");
            Exige(subir.Visible && bajar.Visible, "Al mover al medio no se muestran ambas flechas inmediatamente.");
            bajar.PerformClick(); Application.DoEvents();
            Exige(ReferenceEquals(acu.CurrentRow?.Tag, recursos[0]) && subir.Visible && !bajar.Visible && !bajar.Enabled &&
                partida.Costos.Analisis.SequenceEqual(new[] { recursos[1], recursoEquipo, recursos[2], recursos[0] }) &&
                antes == 2 && despues == 2,
                "Mover al final del grupo no oculta la flecha inferior ni conserva la fila seleccionada.");
            firma = MYGProyectoStorage.Firma(documento);
            bajar.PerformClick(); Application.DoEvents();
            Exige(MYGProyectoStorage.Firma(documento) == firma && antes == 2 && despues == 2,
                "La flecha inferior sin vecino modifica el ACU o crea historial.");
            subir.PerformClick(); Application.DoEvents();
            Exige(partida.Costos.Analisis.SequenceEqual(new[] { recursos[1], recursoEquipo, recursos[0], recursos[2] }) &&
                ReferenceEquals(acu.CurrentRow?.Tag, recursos[0]) && antes == 3 && despues == 3,
                "La flecha superior no mueve el recurso o pierde su identidad y selección.");

            var gruposIniciales = Enum.GetValues<MYGGrupoRecurso>();
            for (int n = 0; n < gruposIniciales.Length; n++)
            {
                var grupo = gruposIniciales[n];
                SeleccionarTitulo(grupo);
                Exige(barra.Visible && insertar.Visible && insertar.Enabled && grabar.Visible && grabar.Enabled &&
                    !editar.Visible && !eliminar.Visible && subir.Visible == (n > 0) && bajar.Visible == (n + 1 < gruposIniciales.Length) &&
                    subir.Enabled == (n > 0) && bajar.Enabled == (n + 1 < gruposIniciales.Length),
                    "Seleccionar el título " + grupo + " no ofrece insertar/grabar y las flechas de sus grupos vecinos o permite editar/eliminar el título.");
            }
            SeleccionarTitulo(MYGGrupoRecurso.Equipo);
            var recursosAntesTitulo = partida.Costos.Analisis.ToArray();
            var bloquesAntesTitulo = gruposIniciales.ToDictionary(g => g, BloqueVisible);
            decimal precioOtroACU = MYGMotorPresupuestos.Analizar(presupuesto, otraPartida).PrecioUnitario;
            firma = MYGProyectoStorage.Firma(documento);
            bajar.PerformClick(); Application.DoEvents();
            var gruposMovidos = (MYGGrupoRecurso[])gruposIniciales.Clone();
            int posicionEquipo = Array.IndexOf(gruposMovidos, MYGGrupoRecurso.Equipo);
            (gruposMovidos[posicionEquipo], gruposMovidos[posicionEquipo + 1]) =
                (gruposMovidos[posicionEquipo + 1], gruposMovidos[posicionEquipo]);
            Exige(acu.CurrentRow?.Tag is MYGGrupoRecurso seleccionado && seleccionado == MYGGrupoRecurso.Equipo &&
                acu.Rows.Cast<DataGridViewRow>().Where(x => x.Tag is MYGGrupoRecurso).Select(x => (MYGGrupoRecurso)x.Tag)
                    .SequenceEqual(gruposMovidos) && partida.Costos.Analisis.SequenceEqual(recursosAntesTitulo) &&
                gruposIniciales.All(g => BloqueVisible(g).SequenceEqual(bloquesAntesTitulo[g])) &&
                antes == 4 && despues == 4 && firmaAntesCambio == firma,
                "Mover un título no mueve su bloque visual completo, altera los recursos o pierde su selección/historial.");
            Exige(MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario == precio &&
                MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == total &&
                otraPartida.Costos.Analisis.SequenceEqual(new[] { equipoOtroACU }) &&
                MYGMotorPresupuestos.Analizar(presupuesto, otraPartida).PrecioUnitario == precioOtroACU,
                "Mover el título cambia precios, cantidades o el análisis de otra partida.");
            panel.Refrescar(); Application.DoEvents();
            Exige(acu.CurrentRow?.Tag is MYGGrupoRecurso refrescado && refrescado == MYGGrupoRecurso.Equipo &&
                acu.Rows.Cast<DataGridViewRow>().Where(x => x.Tag is MYGGrupoRecurso).Select(x => (MYGGrupoRecurso)x.Tag)
                    .SequenceEqual(gruposMovidos),
                "Refrescar el ACU pierde el orden de títulos o la selección del título movido.");
            panel.SeleccionarPartidaCatalogo(otraPartida.Id); Application.DoEvents();
            Exige(acu.Rows.Cast<DataGridViewRow>().Where(x => x.Tag is MYGGrupoRecurso).Select(x => (MYGGrupoRecurso)x.Tag)
                .SequenceEqual(gruposIniciales), "Mover los títulos de un ACU cambia el orden de títulos de otra partida.");
            panel.SeleccionarPartidaCatalogo(partida.Id); Application.DoEvents();
            SeleccionarTitulo(MYGGrupoRecurso.Equipo);
            Exige(acu.Rows.Cast<DataGridViewRow>().Where(x => x.Tag is MYGGrupoRecurso).Select(x => (MYGGrupoRecurso)x.Tag)
                .SequenceEqual(gruposMovidos), "Volver a la partida pierde su orden personalizado de títulos del ACU.");
            int historialTrasOrden = antes;
            firma = MYGProyectoStorage.Firma(documento);
            UsarDialogoPrueba<MYGSelectorInsumoForm>(insertar.PerformClick, dialogo =>
            {
                Controles(dialogo).OfType<TabControl>().Single().SelectedIndex = 1;
                Application.DoEvents();
                var tipo = CampoInsumo<ComboBox>(dialogo, "Tipo de insumo:");
                Exige(tipo.GetItemText(tipo.SelectedItem) == MYGMotorPresupuestos.Grupo(MYGGrupoRecurso.Equipo),
                    "Insertar desde la barra pierde el tipo del título seleccionado.");
                ((Button)dialogo.CancelButton).PerformClick();
            });
            Exige(MYGProyectoStorage.Firma(documento) == firma && antes == historialTrasOrden && despues == historialTrasOrden,
                "Cancelar Insertar de la barra ACU modificó el documento o historial.");
            // Grabar data de la franja ACU debe abrir el guardado individual real.
            // Cancelar permite verificar su alcance sin una escritura de catálogo.
            foreach (bool desdeTitulo in new[] { true, false })
            {
                if (desdeTitulo) SeleccionarTitulo(MYGGrupoRecurso.Materiales); else Seleccionar(recursos[0]);
                UsarDialogoPrueba<MYGGuardarPartidaCatalogoForm>(grabar.PerformClick, dialogo =>
                {
                    Exige(dialogo.Descripcion == partida.Descripcion && dialogo.Unidad == partida.Unidad,
                        "Grabar data del ACU no usa la descripción y unidad de su partida.");
                    ((Button)dialogo.CancelButton).PerformClick();
                });
                Exige(MYGProyectoStorage.Firma(documento) == firma && antes == historialTrasOrden && despues == historialTrasOrden &&
                    MYGCatalogos.Listar(ruta, true).Count == 0 && guardadosMultiples == 0,
                    "Cancelar Grabar data individual escribe en el catálogo o llama al guardado múltiple del centro.");
            }
            ComprobarGuardadoMultiple(partida, new[] { partida.IdLocalMYG });
            ComprobarGuardadoMultiple(titulo, new[] { partida.IdLocalMYG, otraPartida.IdLocalMYG, partidaAnidada.IdLocalMYG });
            ComprobarGuardadoMultiple(presupuesto, presupuesto.Items.Where(x => !MYGProyectoStorage.EsTitulo(x))
                .Select(x => x.IdLocalMYG).ToArray());
            int guardadosTrasPruebaMultiple = guardadosMultiples;
            Exige(guardadosTrasPruebaMultiple == 3 && MYGProyectoStorage.Firma(documento) == firma &&
                antes == historialTrasOrden && despues == historialTrasOrden && MYGCatalogos.Listar(ruta, true).Count == 0,
                "El botón central no abre el guardado múltiple para las tres selecciones o cancelar escribe en el catálogo.");

            panel.SeleccionarPartidaCatalogo(partida.Id); Application.DoEvents();
            Seleccionar(recursos[0]);
            detalle.SelectedIndex = 1; Application.DoEvents();
            Exige(!barra.Visible, "Las herramientas ACU aparecen en la pestaña de especificaciones.");
            detalle.SelectedTab = paginaACU; Application.DoEvents();
            Exige(barra.Visible, "Regresar al ACU no recupera su barra contextual.");
            vistas.SelectedIndex = 1; Application.DoEvents();
            Exige(!barra.Visible, "La barra ACU aparece en Lista de Insumos.");
            vistas.SelectedIndex = 0; Application.DoEvents();
            Exige(barra.Visible, "Regresar al presupuesto perdió la barra del ACU seleccionado.");
            acu.CurrentCell = null; acu.ClearSelection(); Application.DoEvents();
            Exige(!barra.Visible, "Las herramientas ACU siguen visibles sin una fila seleccionada.");
            panel.SeleccionarPartidaCatalogo(titulo.Id); Application.DoEvents();
            Exige(!barra.Visible, "Seleccionar un título de presupuesto muestra herramientas de una partida anterior.");
            panel.SeleccionarPartidaCatalogo(partida.Id); Application.DoEvents();
            ComprobarFlechas(recursos[0], arriba: true, abajo: true);
            autorizado = false;
            bool bloqueado = false, accionEjecutada = false;
            try
            {
                typeof(MYGPanelPresupuesto).GetMethod("EjecutarHerramientaACU", System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).Invoke(panel, new object[] { new Action(() => accionEjecutada = true), true });
            }
            catch (System.Reflection.TargetInvocationException ex) when (ex.InnerException is InvalidOperationException)
            { bloqueado = true; }
            Exige(bloqueado && !accionEjecutada && MYGProyectoStorage.Firma(documento) == firma &&
                antes == historialTrasOrden && despues == historialTrasOrden,
                "Una autorización retirada después de seleccionar no impide ejecutar la herramienta del ACU.");
            panel.ActualizarHerramientas(); Application.DoEvents();
            Exige(!insertar.Enabled && !editar.Enabled && !eliminar.Enabled && !grabar.Enabled && !subir.Enabled &&
                !bajar.Enabled && !centro.Enabled && recalcular.Enabled && exportar.Enabled,
                "La barra no respeta los permisos de modificación y consulta o deja activo el guardado múltiple.");
            foreach (var comando in new[] { insertar, editar, eliminar, subir, bajar, grabar, centro }) comando.PerformClick();
            Application.DoEvents();
            Exige(MYGProyectoStorage.Firma(documento) == firma && antes == historialTrasOrden &&
                despues == historialTrasOrden && guardadosMultiples == guardadosTrasPruebaMultiple,
                "Una acción deshabilitada de las barras modifica los datos o inicia un guardado.");
            autorizado = true; panel.ActualizarHerramientas(); Application.DoEvents();
            Exige(insertar.Enabled && editar.Enabled && eliminar.Enabled && grabar.Enabled && subir.Enabled && bajar.Enabled && centro.Enabled,
                "Restablecer la autorización no recupera las herramientas de la selección vigente.");
            MYGProyectoStorage.Validar(documento);
            anfitrion.Close();

            ToolStripButton Accion(string nombre) => barra.Items.OfType<ToolStripButton>().Single(x => x.Name == nombre);
            void Seleccionar(MYGRecursoACU recurso)
            {
                var fila = acu.Rows.Cast<DataGridViewRow>().Single(x => ReferenceEquals(x.Tag, recurso));
                acu.CurrentCell = fila.Cells["DESC"]; acu.ClearSelection(); fila.Selected = true; Application.DoEvents();
            }
            void SeleccionarTitulo(MYGGrupoRecurso grupo)
            {
                var fila = acu.Rows.Cast<DataGridViewRow>().Single(x => x.Tag is MYGGrupoRecurso g && g == grupo);
                acu.CurrentCell = fila.Cells["DESC"]; acu.ClearSelection(); fila.Selected = true; Application.DoEvents();
            }
            void ComprobarFlechas(MYGRecursoACU recurso, bool arriba, bool abajo)
            {
                Seleccionar(recurso);
                Exige(barra.Visible && subir.Visible == arriba && bajar.Visible == abajo &&
                    subir.Enabled == arriba && bajar.Enabled == abajo && editar.Visible && eliminar.Visible,
                    "Las flechas no corresponden a los vecinos del grupo del recurso " + recurso.InsumoId + ".");
            }
            MYGRecursoACU[] BloqueVisible(MYGGrupoRecurso grupo)
            {
                var filas = acu.Rows.Cast<DataGridViewRow>().ToArray();
                int cabeceraGrupo = Array.FindIndex(filas, x => x.Tag is MYGGrupoRecurso g && g == grupo);
                return filas.Skip(cabeceraGrupo + 1).TakeWhile(x => x.Tag is not MYGGrupoRecurso)
                    .Select(x => (MYGRecursoACU)x.Tag).ToArray();
            }
            void ComprobarGuardadoMultiple(object seleccion, string[] idsIniciales)
            {
                panel.SeleccionarEstructura(seleccion); Application.DoEvents();
                UsarDialogoPrueba<MYGGrabarCostosMultiplesForm>(centro.PerformClick, dialogo =>
                {
                    var tabla = ControlConNombre<DataGridView>(dialogo, "tablaCostosMultiples");
                    Exige(tabla.Columns["SEL"] is DataGridViewCheckBoxColumn && tabla.Rows.Count == 4 &&
                        tabla.Rows.Cast<DataGridViewRow>().Where(x => x.Cells["SEL"].Value is true)
                            .Select(x => ((ItemPresupuestoDelphin)x.Tag).IdLocalMYG).SequenceEqual(idsIniciales),
                        "Grabar data de costos múltiples no precarga sólo la partida, los descendientes del título o todo el presupuesto seleccionado.");
                    Exige(ControlConNombre<ComboBox>(dialogo, "cmbGrupoCostos").Visible &&
                        ControlConNombre<Button>(dialogo, "btnNuevoGrupoCostos").Text == "+",
                        "El guardado múltiple no ofrece el grupo y su botón para crear uno.");
                    ((Button)dialogo.CancelButton).PerformClick();
                });
                Exige(MYGProyectoStorage.Firma(documento) == firma && antes == historialTrasOrden &&
                    despues == historialTrasOrden && MYGCatalogos.Listar(ruta, true).Count == 0,
                    "Cancelar el lote precargado escribe referencias, historial o entradas de catálogo.");
            }
        }
        finally
        {
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void VerificarSeleccionCostosMultiples()
    {
        var documento = MYGProyectoStorage.Nuevo("SELECCIÓN DE COSTOS MÚLTIPLES");
        documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
        var presupuesto = documento.Presupuestos.Single();
        var partidas = Enumerable.Range(1, 3).Select(n =>
        {
            var partida = Nodo("PARTIDA MÚLTIPLE " + n); partida.Posicion = n; return partida;
        }).ToArray();
        presupuesto.Items.AddRange(partidas);
        MYGProyectoStorage.Renumerar(presupuesto);
        MYGProyectoStorage.Validar(documento);
        string firma = MYGProyectoStorage.Firma(documento);
        using (var dialogo = new MYGGrabarCostosMultiplesForm(partidas, new[] { partidas[1].IdLocalMYG }, new[] { "EDIFICACIÓN", "OBRAS VIALES" }))
        {
            dialogo.Show(); Application.DoEvents();
            var tabla = ControlConNombre<DataGridView>(dialogo, "tablaCostosMultiples");
            var grupo = ControlConNombre<ComboBox>(dialogo, "cmbGrupoCostos");
            Exige(tabla.Columns["SEL"] is DataGridViewCheckBoxColumn casilla && casilla.Visible && !casilla.ReadOnly &&
                !tabla.ReadOnly && tabla.Rows.Count == 3 && tabla.Columns.Cast<DataGridViewColumn>()
                    .Where(x => x.Name != "SEL").All(x => x.ReadOnly),
                "El guardado múltiple no ofrece casillas editables o deja editar los datos de las partidas.");
            Exige(tabla.Rows.Cast<DataGridViewRow>().Where(x => x.Cells["SEL"].Value is true)
                .Select(x => ((ItemPresupuestoDelphin)x.Tag).IdLocalMYG).SequenceEqual(new[] { partidas[1].IdLocalMYG }),
                "El diálogo múltiple ignora las identidades elegidas inicialmente.");
            foreach (DataGridViewRow fila in tabla.Rows) fila.Cells["SEL"].Value = false;
            tabla.EndEdit(); Application.DoEvents();
            Exige(!((Button)dialogo.AcceptButton).Enabled && tabla.Rows.Cast<DataGridViewRow>().All(x => x.Cells["SEL"].Value is not true),
                "Aceptar continúa habilitado sin partidas marcadas.");
            tabla.Rows[0].Cells["SEL"].Value = true;
            tabla.Rows[2].Cells["SEL"].Value = true;
            tabla.CurrentCell = tabla.Rows[1].Cells["DESC"];
            tabla.ClearSelection(); tabla.Rows[1].Selected = true;
            tabla.EndEdit(); Application.DoEvents();
            var crearGrupo = ControlConNombre<Button>(dialogo, "btnNuevoGrupoCostos");
            string nombreInicial = grupo.GetItemText(grupo.SelectedItem); int cantidadGrupos = grupo.Items.Count;
            UsarDialogoPrueba<MYGCamposProyectoForm>(crearGrupo.PerformClick,
                nuevo => ((Button)nuevo.CancelButton).PerformClick());
            Exige(grupo.Items.Count == cantidadGrupos && grupo.GetItemText(grupo.SelectedItem) == nombreInicial,
                "Cancelar crear un grupo cambia los grupos existentes o la elección previa.");
            UsarDialogoPrueba<MYGCamposProyectoForm>(crearGrupo.PerformClick, nuevo =>
            {
                Controles(nuevo).OfType<TextBox>().Single().Text = "ESTRUCTURAS";
                ((Button)nuevo.AcceptButton).PerformClick();
            });
            Exige(grupo.Items.Count == cantidadGrupos + 1 && grupo.GetItemText(grupo.SelectedItem) == "ESTRUCTURAS",
                "El botón + no crea y selecciona el grupo indicado.");
            UsarDialogoPrueba<MYGCamposProyectoForm>(crearGrupo.PerformClick, nuevo =>
            {
                Controles(nuevo).OfType<TextBox>().Single().Text = "estructuras";
                ((Button)nuevo.AcceptButton).PerformClick();
            });
            Exige(grupo.Items.Count == cantidadGrupos + 1 && grupo.GetItemText(grupo.SelectedItem) == "ESTRUCTURAS",
                "Crear un grupo con distinta capitalización duplica el grupo existente.");
            grupo.SelectedIndex = Enumerable.Range(0, grupo.Items.Count).Single(n => grupo.GetItemText(grupo.Items[n]) == "OBRAS VIALES");
            ControlConNombre<TextBox>(dialogo, "txtFiltroCostosMultiples").Text = "PARTIDA MÚLTIPLE 2";
            Application.DoEvents();
            Exige(((Button)dialogo.AcceptButton).Enabled && tabla.Rows.Count == 1 && tabla.Rows[0].Cells["SEL"].Value is not true &&
                ControlConNombre<Label>(dialogo, "lblCostosMultiplesSeleccionados").Text.Contains("2"),
                "Filtrar partidas pierde las dos casillas ocultas o agrega una partida sin marcar.");
            ((Button)dialogo.AcceptButton).PerformClick();
            Exige(dialogo.DialogResult == DialogResult.OK && dialogo.PartidasSeleccionadas.SequenceEqual(
                new[] { partidas[0].IdLocalMYG, partidas[2].IdLocalMYG }) && dialogo.Grupo == "OBRAS VIALES" &&
                MYGProyectoStorage.Firma(documento) == firma,
                "Aceptar la selección múltiple lee la fila azul, pierde las casillas ocultas o modifica el presupuesto antes de aplicar el lote.");
            dialogo.Close();
        }
        using (var cancelar = new MYGGrabarCostosMultiplesForm(partidas, new[] { partidas[0].IdLocalMYG }, Array.Empty<string>()))
        {
            cancelar.Show(); Application.DoEvents();
            var grupos = ControlConNombre<ComboBox>(cancelar, "cmbGrupoCostos");
            Exige(grupos.GetItemText(grupos.SelectedItem) == "GENERAL", "Un catálogo sin grupos no ofrece el grupo inicial GENERAL.");
            ((Button)cancelar.CancelButton).PerformClick();
            Exige(cancelar.DialogResult == DialogResult.Cancel && MYGProyectoStorage.Firma(documento) == firma,
                "Cancelar el guardado múltiple modifica el presupuesto.");
            cancelar.Close();
        }
    }

    private static void VerificarGruposCatalogoCostos()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-GruposCostos-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "Catalogo.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var documento = MYGProyectoStorage.Nuevo("GRUPOS PERSONALIZADOS DE COSTOS UNITARIOS");
            documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
            var presupuesto = documento.Presupuestos.Single();
            var primera = Nodo("PRIMER COSTO UNITARIO");
            var segunda = Nodo("SEGUNDO COSTO UNITARIO"); segunda.Posicion = 2;
            presupuesto.Items.AddRange(new[] { primera, segunda });
            MYGProyectoStorage.Renumerar(presupuesto);
            string firma = MYGProyectoStorage.Firma(documento);
            var entradas = new[]
            {
                MYGCatalogos.GuardarPartida(ruta, presupuesto, primera, "C-01", primera.Descripcion, primera.Unidad,
                    grupo: "ESTRUCTURAS / CONCRETO"),
                MYGCatalogos.GuardarPartida(ruta, presupuesto, segunda, "C-02", segunda.Descripcion, segunda.Unidad,
                    grupo: "INSTALACIONES SANITARIAS")
            };
            using var catalogo = new MYGCatalogoPropioForm(ruta, true, () => true);
            catalogo.Show(); Application.DoEvents();
            var tabla = Controles(catalogo).OfType<DataGridView>().Single();
            var filtro = ControlConNombre<TextBox>(catalogo, "txtFiltroCatalogo");
            Exige(tabla.Columns.Contains("GRUPO") && tabla.Columns["GRUPO"].Visible &&
                tabla.Columns["GRUPO"].HeaderText == "Grupo de costos unitarios" && tabla.Rows.Count == 2 &&
                tabla.Rows.Cast<DataGridViewRow>().Select(x => Convert.ToString(x.Cells["GRUPO"].Value))
                    .SequenceEqual(entradas.Select(x => x.Grupo)),
                "El catálogo de partidas no muestra los grupos personalizados o los convierte en tipos de insumo.");
            filtro.Text = "estructuras / concreto"; Application.DoEvents();
            Exige(tabla.Rows.Count == 1 && ((MYGEntradaCatalogo)tabla.Rows[0].Tag).Id == entradas[0].Id &&
                Convert.ToString(tabla.Rows[0].Cells["GRUPO"].Value) == "ESTRUCTURAS / CONCRETO",
                "Buscar un grupo personalizado no filtra su entrada conservando el nombre completo.");
            filtro.Text = "SANITARIAS"; Application.DoEvents();
            Exige(tabla.Rows.Count == 1 && ((MYGEntradaCatalogo)tabla.Rows[0].Tag).Id == entradas[1].Id,
                "El catálogo no permite buscar por una parte del nombre de grupo.");
            filtro.Text = "Materiales"; Application.DoEvents();
            Exige(tabla.Rows.Count == 0, "El catálogo de partidas confunde un grupo personalizado con un tipo de insumo.");
            ((Button)catalogo.CancelButton).PerformClick();
            Exige(MYGProyectoStorage.Firma(documento) == firma && MYGCatalogos.Listar(ruta, true).Select(x => x.Id)
                .SequenceEqual(entradas.Select(x => x.Id)),
                "Consultar los grupos del catálogo modifica el presupuesto o sus entradas.");
            catalogo.Close();
        }
        finally
        {
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void VerificarMenuACU()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            string ruta = Path.Combine(carpeta, "Catalogos.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var documento = MYGProyectoStorage.Nuevo("PRUEBA DEL MENÚ ACU");
            documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
            var presupuesto = documento.Presupuestos.Single();
            var partida = Nodo("PARTIDA CON MATERIALES");
            partida.Costos.Cantidad = 2m;
            presupuesto.Items.Add(partida);
            string indiceOficial = MYGCatalogoIndicesUnificados.Listar().Single(x => x.Codigo == "21").ToString();
            const string indiceHistorico = "22 · Cemento Portland tipo II";
            var primero = new MYGInsumo { Codigo = "MAT-ESTANDAR-COMPLETO-0001", CodigoAlterno = "ALT-01", UsarCodigoAlterno = true,
                Descripcion = "PRIMER MATERIAL", Grupo = MYGGrupoRecurso.Materiales, Unidad = "kg", Precio = 12.35m,
                GrupoGenerico = indiceOficial };
            var segundo = new MYGInsumo { Codigo = "MAT-0002", CodigoAlterno = "ALT-02", UsarCodigoAlterno = true,
                Descripcion = "SEGUNDO MATERIAL", Grupo = MYGGrupoRecurso.Materiales, Unidad = "kg", Precio = 7.25m,
                GrupoGenerico = indiceHistorico };
            var indicesEsperados = new Dictionary<string, string> { [primero.Id] = "21", [segundo.Id] = "22" };
            presupuesto.Costos.Insumos.AddRange(new[] { primero, segundo });
            MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, new[] { primero, segundo });
            var r1 = new MYGRecursoACU { InsumoId = primero.Id, Grupo = primero.Grupo, Cantidad = 2m };
            var r2 = new MYGRecursoACU { InsumoId = segundo.Id, Grupo = segundo.Grupo, Cantidad = 3m };
            partida.Costos.Analisis.AddRange(new[] { r1, r2 });
            MYGProyectoStorage.Renumerar(presupuesto);
            MYGProyectoStorage.Validar(documento);
            int antes = 0, despues = 0;
            bool autorizado = true;
            string firmaAntesCambio = null;
            using var anfitrion = new Form { Text = "Prueba del menú ACU", ClientSize = new(1400, 800) };
            using var panel = new MYGPanelPresupuesto(() => presupuesto,
                () => { antes++; firmaAntesCambio = MYGProyectoStorage.Firma(documento); },
                () => despues++, _ => { }, () => Task.CompletedTask, _ => { });
            panel.InicializarEstructura(() => documento, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            panel.InicializarCatalogos(() => ruta, () => autorizado, () => { });
            anfitrion.Controls.Add(panel);
            anfitrion.Show();
            panel.SeleccionarPartidaCatalogo(partida.Id);
            Application.DoEvents();
            var acu = Controles(panel).OfType<DataGridView>().Single(x => x.Columns.Contains("MODO"));
            var menu = acu.ContextMenuStrip;
            Exige(menu != null, "El ACU no tiene menú de anticlic.");
            Exige(menu.Items.OfType<ToolStripMenuItem>().All(x => x.Image != null),
                "Las acciones del anticlic deben mostrar sus iconos.");
            var insertar = Opcion("Insertar insumo");
            var insertarSobre = Opcion("Insertar insumo arriba");
            var bajar = Opcion("Bajar recurso");
            var estandar = Opcion("Mostrar código estándar");
            var indiceUnificado = Opcion("Mostrar índice unificado");
            Exige(acu.Columns.Contains("INDICE") && !acu.Columns.Contains("CODALTERNO") &&
                acu.Columns["INDICE"].HeaderText == "Índice unificado" && acu.Columns["INDICE"].ReadOnly,
                "El ACU no ofrece la columna de consulta Índice unificado en lugar del código alterno.");
            VerificarIndices();
            decimal precio = MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario;
            decimal total = MYGMotorPresupuestos.TotalPartida(presupuesto, partida);

            Seleccionar(r1);
            AbrirMenu();
            string[] textosRecurso = { "Insertar insumo arriba", "Insertar insumo abajo", "Insertar subpartida", "Eliminar",
                "Recalcular", "Mostrar código estándar", "Mostrar índice unificado", "Exportar a Excel",
                "Editar y reemplazar insumo…", "Subir recurso", "Bajar recurso", "Catálogo de insumos", "Guardar partida en catálogo" };
            Exige(menu.Items.OfType<ToolStripMenuItem>().Where(x => x.Visible).Select(x => x.Text).SequenceEqual(textosRecurso),
                "El anticlic de un recurso no conserva sus acciones de inserción, edición, orden y catálogo.");
            Exige(insertarSobre.Enabled && bajar.Enabled, "No se puede insertar o bajar el primer material autorizado.");
            menu.Close();
            Seleccionar(r2);
            AbrirMenu();
            Exige(!bajar.Enabled, "Bajar debe deshabilitarse en el último recurso del grupo.");
            menu.Close();
            var grupo = acu.Rows.Cast<DataGridViewRow>().Single(x => x.Tag is MYGGrupoRecurso g && g == MYGGrupoRecurso.Materiales);
            acu.CurrentCell = grupo.Cells["DESC"];
            AbrirMenu();
            Exige(insertar.Enabled && !bajar.Enabled, "Una cabecera de grupo debe permitir insertar, pero no bajar.");
            string[] textosGrupo = { "Insertar insumo", "Recalcular", "Mostrar código estándar", "Mostrar índice unificado", "Exportar a Excel" };
            Exige(menu.Items.OfType<ToolStripMenuItem>().Where(x => x.Visible).Select(x => x.Text).SequenceEqual(textosGrupo),
                "El anticlic de una cabecera no muestra las cinco acciones del grupo, en orden.");
            menu.Close();

            // Recalcular y refrescar reconstruyen las filas: la cabecera elegida
            // debe seguir seleccionada y llegar como tipo inicial al diálogo.
            foreach (var inicial in new[] { MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo,
                MYGGrupoRecurso.Subcontratos, MYGGrupoRecurso.ManoObra })
            {
                var cabecera = acu.Rows.Cast<DataGridViewRow>().Single(x => x.Tag is MYGGrupoRecurso g && g == inicial);
                acu.CurrentCell = cabecera.Cells["DESC"];
                AbrirMenu();
                Opcion("Recalcular").PerformClick();
                menu.Close();
                Application.DoEvents();
                Exige(acu.CurrentRow?.Tag is MYGGrupoRecurso recargado && recargado == inicial,
                    "Recalcular cambió la cabecera seleccionada a otro grupo.");
                panel.Refrescar();
                Application.DoEvents();
                Exige(acu.CurrentRow?.Tag is MYGGrupoRecurso refrescado && refrescado == inicial,
                    "Refrescar cambió la cabecera seleccionada a otro grupo.");
                string firmaGrupo = MYGProyectoStorage.Firma(documento);
                UsarInsertar(insertar, aceptar: false, grupoInicial: inicial);
                Exige(MYGProyectoStorage.Firma(documento) == firmaGrupo && antes == 0 && despues == 0,
                    "Cancelar la inserción desde una cabecera modificó los datos o el historial.");
            }

            Seleccionar(r1);
            string firma = MYGProyectoStorage.Firma(documento);
            AbrirMenu();
            bajar.PerformClick();
            menu.Close();
            Application.DoEvents();
            Exige(antes == 1 && despues == 1 && firmaAntesCambio == firma,
                "Bajar no registró una única operación de historial antes del cambio.");
            Exige(partida.Costos.Analisis.SequenceEqual(new[] { r2, r1 }) &&
                acu.CurrentRow?.Tag is MYGRecursoACU seleccionado && seleccionado.Id == r1.Id,
                "Bajar no conserva las instancias o la selección del recurso movido.");
            Exige(MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario == precio &&
                MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == total,
                "Bajar un recurso cambió el precio o el total de la partida.");
            AbrirMenu();
            Exige(!bajar.Enabled, "Bajar debe quedar deshabilitado después de mover el recurso al final del grupo.");
            menu.Close();

            for (int modo = 0; modo < 2; modo++)
            {
                firma = MYGProyectoStorage.Firma(documento);
                foreach (bool mostrarIndice in new[] { true, false })
                {
                    AbrirMenu();
                    (mostrarIndice ? indiceUnificado : estandar).PerformClick();
                    menu.Close();
                    Application.DoEvents();
                    VerificarVista(mostrarIndice);
                    panel.Refrescar();
                    Application.DoEvents();
                    VerificarVista(mostrarIndice);
                }
                Exige(MYGProyectoStorage.Firma(documento) == firma && antes == 1 && despues == 1 &&
                    primero.Codigo == "MAT-ESTANDAR-COMPLETO-0001" && primero.CodigoAlterno == "ALT-01" &&
                    primero.UsarCodigoAlterno && primero.GrupoGenerico == indiceOficial &&
                    segundo.CodigoAlterno == "ALT-02" && segundo.UsarCodigoAlterno && segundo.GrupoGenerico == indiceHistorico &&
                    MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario == precio &&
                    MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == total,
                    "Consultar el índice unificado alteró códigos, clasificaciones históricas, importes o historial.");
                AbrirMenu();
                indiceUnificado.PerformClick();
                menu.Close();
                MYG2027_TemaComercial.Alternar(false);
                Application.DoEvents();
                VerificarVista(mostrarIndice: true);
                Exige(MYGProyectoStorage.Firma(documento) == firma && antes == 1 && despues == 1,
                    "Cambiar el tema con el índice visible modificó los datos o agregó historial.");
            }

            Seleccionar(r2);
            autorizado = false;
            firma = MYGProyectoStorage.Firma(documento);
            AbrirMenu();
            Exige(!insertarSobre.Enabled && !bajar.Enabled && !Opcion("Eliminar").Enabled &&
                !Opcion("Editar y reemplazar insumo…").Enabled && estandar.Enabled && indiceUnificado.Enabled &&
                Opcion("Recalcular").Enabled && Opcion("Exportar a Excel").Enabled,
                "El anticlic no respeta los permisos de modificación y consulta.");
            menu.Close();
            Exige(MYGProyectoStorage.Firma(documento) == firma && antes == 1 && despues == 1,
                "Abrir el anticlic sin autorización modificó el documento.");
            autorizado = true;

            AbrirMenu();
            Exige(Opcion("Eliminar").Visible && Opcion("Eliminar").Enabled &&
                Opcion("Editar y reemplazar insumo…").Visible && Opcion("Editar y reemplazar insumo…").Enabled,
                "El anticlic no conserva las herramientas de edición del recurso autorizado.");
            menu.Close();

            // Ejercitar el comando real evita probar únicamente su etiqueta.
            Seleccionar(r1);
            firma = MYGProyectoStorage.Firma(documento);
            UsarInsertar(insertarSobre, aceptar: false);
            Exige(MYGProyectoStorage.Firma(documento) == firma && antes == 1 && despues == 1,
                "Cancelar Insertar insumo cambió los datos o agregó historial.");
            UsarInsertar(insertarSobre, aceptar: true);
            var nuevo = partida.Costos.Analisis.Single(x => x.Id != r1.Id && x.Id != r2.Id);
            Exige(partida.Costos.Analisis.SequenceEqual(new[] { r2, nuevo, r1 }) && nuevo.InsumoId == primero.Id &&
                presupuesto.Costos.Insumos.Count == 2 && acu.CurrentRow?.Tag is MYGRecursoACU elegido && elegido.Id == nuevo.Id,
                "Insertar no colocó el insumo antes de la selección o duplicó el insumo existente.");
            Exige(antes == 2 && despues == 2 && firmaAntesCambio == firma,
                "Insertar no registró un único cambio de historial después de aceptar.");

            // Una subpartida no es un insumo y no debe heredar el índice de
            // sus materiales; un insumo sin clasificación también queda vacío.
            var sinIndice = new MYGInsumo { Codigo = "EQ-SIN-INDICE", CodigoAlterno = "ALT-SIN-INDICE", UsarCodigoAlterno = true,
                Descripcion = "EQUIPO SIN ÍNDICE", Grupo = MYGGrupoRecurso.Equipo, Unidad = "und", Precio = 5m };
            presupuesto.Costos.Insumos.Add(sinIndice);
            indicesEsperados[sinIndice.Id] = "";
            var recursoSinIndice = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, null, new() { InsumoId = sinIndice.Id });
            var subpartida = Nodo("SUBPARTIDA CON MATERIAL CLASIFICADO");
            subpartida.Posicion = 2;
            presupuesto.Items.Add(subpartida);
            MYGInsumosEdicion.Aplicar(presupuesto, subpartida.Id, null, new() { InsumoId = primero.Id });
            var recursoSubpartida = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, null,
                new() { SubpartidaIdLocal = subpartida.IdLocalMYG });
            MYGProyectoStorage.Renumerar(presupuesto);
            MYGProyectoStorage.Validar(documento);
            firma = MYGProyectoStorage.Firma(documento);
            panel.Refrescar();
            Application.DoEvents();
            VerificarVista(mostrarIndice: true);
            Exige(ValorIndice(recursoSinIndice) == "" && ValorIndice(recursoSubpartida) == "" &&
                MYGProyectoStorage.Firma(documento) == firma && antes == 2 && despues == 2,
                "Refrescar inventó índices para insumos sin clasificación/subpartidas o modificó el documento.");

            // La vista debe tomar el dato actualizado del presupuesto, incluso
            // cuando varias líneas comparten el insumo que se acaba de editar.
            decimal precioAntesEdicion = MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario;
            decimal totalAntesEdicion = MYGMotorPresupuestos.TotalPartida(presupuesto, partida);
            var reclasificado = MYGProyectoStorage.Copia(presupuesto.Costos.Insumos.Single(x => x.Id == primero.Id));
            reclasificado.GrupoGenerico = MYGCatalogoIndicesUnificados.Listar().Single(x => x.Codigo == "81").ToString();
            MYGInsumosEdicion.EditarInsumo(presupuesto, reclasificado);
            indicesEsperados[primero.Id] = "81";
            firma = MYGProyectoStorage.Firma(documento);
            panel.Refrescar();
            Application.DoEvents();
            VerificarVista(mostrarIndice: true);
            Exige(ValorIndice(r1) == "81" && ValorIndice(nuevo) == "81" &&
                presupuesto.Costos.Insumos.Single(x => x.Id == primero.Id).CodigoAlterno == "ALT-01" &&
                presupuesto.Costos.Insumos.Single(x => x.Id == primero.Id).UsarCodigoAlterno &&
                presupuesto.Costos.Insumos.Single(x => x.Id == segundo.Id).GrupoGenerico == indiceHistorico &&
                MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario == precioAntesEdicion &&
                MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == totalAntesEdicion &&
                MYGProyectoStorage.Firma(documento) == firma && antes == 2 && despues == 2,
                "Refrescar tras editar no mostró el nuevo índice compartido o cambió códigos, importes o historial.");

            // Mostrar sólo el código conserva el cero inicial y los códigos
            // compuestos; una clasificación genérica ajena al índice queda vacía.
            foreach (var (clasificacion, esperado) in new[]
            {
                (" 01 · Aceite y lubricante ", "01"),
                ("01", "01"),
                ("47 · Mano de obra (incluye leyes sociales)", "47"),
                ("47-1 · Mano de obra de alta especialización (incluye leyes sociales)", "47-1"),
                ("ÁRIDOS", "")
            })
            {
                var valor = MYGProyectoStorage.Copia(presupuesto.Costos.Insumos.Single(x => x.Id == sinIndice.Id));
                valor.GrupoGenerico = clasificacion;
                MYGInsumosEdicion.EditarInsumo(presupuesto, valor);
                indicesEsperados[sinIndice.Id] = esperado;
                firma = MYGProyectoStorage.Firma(documento);
                panel.Refrescar();
                Application.DoEvents();
                VerificarVista(mostrarIndice: true);
                Exige(ValorIndice(recursoSinIndice) == esperado &&
                    presupuesto.Costos.Insumos.Single(x => x.Id == sinIndice.Id).GrupoGenerico == clasificacion &&
                    presupuesto.Costos.Insumos.Single(x => x.Id == sinIndice.Id).CodigoAlterno == "ALT-SIN-INDICE" &&
                    presupuesto.Costos.Insumos.Single(x => x.Id == sinIndice.Id).UsarCodigoAlterno &&
                    ValorIndice(recursoSubpartida) == "" && MYGProyectoStorage.Firma(documento) == firma &&
                    MYGMotorPresupuestos.Analizar(presupuesto, partida).PrecioUnitario == precioAntesEdicion &&
                    MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == totalAntesEdicion && antes == 2 && despues == 2,
                    "Mostrar el código del índice perdió ceros/sufijos, mostró la descripción o recodificó los datos guardados.");
            }
            anfitrion.Close();

            ToolStripMenuItem Opcion(string texto) => menu.Items.OfType<ToolStripMenuItem>().Single(x => x.Text == texto);
            string ValorIndice(MYGRecursoACU recurso) => Convert.ToString(acu.Rows.Cast<DataGridViewRow>()
                .Single(x => x.Tag is MYGRecursoACU r && r.Id == recurso.Id).Cells["INDICE"].Value);
            void VerificarIndices()
            {
                foreach (DataGridViewRow fila in acu.Rows)
                {
                    string esperado = fila.Tag is MYGRecursoACU r && r.Grupo != MYGGrupoRecurso.Subpartidas
                        ? indicesEsperados[r.InsumoId] : "";
                    Exige(Convert.ToString(fila.Cells["INDICE"].Value) == esperado,
                        "La columna Índice unificado no muestra sólo el código esperado o inventa un índice.");
                }
            }
            void VerificarVista(bool mostrarIndice)
            {
                Exige(acu.Columns["COD"].Visible == !mostrarIndice && acu.Columns["INDICE"].Visible == mostrarIndice,
                    "La vista no conserva la elección exclusiva entre código estándar e índice unificado.");
                VerificarIndices();
                AbrirMenu();
                Exige(indiceUnificado.Checked == mostrarIndice && estandar.Checked == !mostrarIndice,
                    "El anticlic no marca la vista elegida de código estándar o índice unificado.");
                menu.Close();
            }
            void Seleccionar(MYGRecursoACU recurso)
            {
                var fila = acu.Rows.Cast<DataGridViewRow>().Single(x => x.Tag is MYGRecursoACU r && r.Id == recurso.Id);
                acu.ClearSelection();
                acu.CurrentCell = fila.Cells["DESC"];
                fila.Selected = true;
            }
            void AbrirMenu()
            {
                menu.Show(acu, new Point(8, 8));
                Application.DoEvents();
                Exige(menu.Visible, "El anticlic del ACU no se abre para la partida seleccionada.");
            }
            void UsarInsertar(ToolStripMenuItem comando, bool aceptar, MYGGrupoRecurso? grupoInicial = null)
            {
                bool mostrado = false;
                string error = null;
                var plazo = System.Diagnostics.Stopwatch.StartNew();
                using var temporizador = new System.Windows.Forms.Timer { Interval = 40 };
                temporizador.Tick += (_, _) =>
                {
                    // El plazo sigue activo mientras se pulsa Aceptar: una
                    // advertencia modal inesperada también debe fallar la prueba.
                    if (plazo.Elapsed > TimeSpan.FromSeconds(10))
                    {
                        Console.Error.WriteLine("Insertar insumo quedó bloqueado en un diálogo inesperado.");
                        Environment.Exit(1);
                        return;
                    }
                    if (mostrado) return;
                    var dialogo = Application.OpenForms.OfType<MYGSelectorInsumoForm>().FirstOrDefault();
                    if (dialogo == null) return;
                    mostrado = true;
                    try
                    {
                        if (grupoInicial.HasValue)
                        {
                            Controles(dialogo).OfType<TabControl>().Single().SelectedIndex = 1;
                            Application.DoEvents();
                            var tipo = CampoInsumo<ComboBox>(dialogo, "Tipo de insumo:");
                            Exige(tipo.GetItemText(tipo.SelectedItem) == MYGMotorPresupuestos.Grupo(grupoInicial.Value),
                                "Insertar desde una cabecera no conserva el grupo inicial al mostrar el diálogo.");
                        }
                        if (!aceptar) { ((Button)dialogo.CancelButton).PerformClick(); return; }
                        ControlConNombre<ComboBox>(dialogo, "cboOrigenInsumos").SelectedIndex = 0;
                        var tabla = Controles(dialogo).OfType<DataGridView>().Single(x => x.Columns.Contains("TIPO"));
                        var fila = tabla.Rows.Cast<DataGridViewRow>().Single(x => x.Tag is MYGInsumo i && i.Id == primero.Id);
                        tabla.CurrentCell = fila.Cells["DESC"];
                        tabla.ClearSelection();
                        fila.Selected = true;
                        ((Button)dialogo.AcceptButton).PerformClick();
                    }
                    catch (Exception ex) { error = ex.Message; dialogo.Close(); }
                };
                AbrirMenu();
                temporizador.Start();
                comando.PerformClick();
                menu.Close();
                Application.DoEvents();
                temporizador.Stop();
                Exige(mostrado && error == null, error ?? "Insertar insumo no abrió el selector real.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != original) MYG2027_TemaComercial.Alternar(false);
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }
}
