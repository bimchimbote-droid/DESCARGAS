# Conservar el metrado al confirmar una cantidad sin cambios

Entrar en la celda Cantidad y salir sin cambiar su valor conserva la fuente
del metrado. Si la fuente es Excel, se mantienen el icono y su ayuda. También
se conservan los orígenes BIM y manual, sin añadir cambios al historial.

La confirmación compara primero el texto y después el número. Los formatos
válidos equivalentes, como 3.35 y 3,35, no convierten el origen a cantidad
directa. Una cantidad numéricamente distinta conserva el comportamiento
existente: se convierte a directa y deja de mostrar el icono del vínculo
Excel, conservando la hoja original y los metrados de las otras pestañas.

Una prueba anterior exigía convertir a cantidad directa incluso al confirmar
el mismo número. Esa expectativa se actualiza según la solicitud del usuario,
manteniendo las comprobaciones de desvinculación al introducir otro valor.

## Archivos

| Ruta | Acción |
| --- | --- |
| MYG.Desktop/PresupuestosEstructuraPanel.cs | REEMPLAZAR |
| MYG.PruebasUI/IndicadoresContenidoCheck.cs | REEMPLAZAR |
| MYG.PruebasUI/Program.cs | REEMPLAZAR |
| MYG.PruebasUI/CantidadSinCambioCheck.cs | CREAR |
| CORRECCION_ICONO_METRADO.md | CREAR |

## Aplicación manual

Esta entrega se aplica encima de las actualizaciones anteriores, incluida
la corrección de precios `entrega-20261014-110500-precios-inicio`.
Respalde o confirme los cambios locales, extraiga el ZIP fuera del checkout
y copie los archivos conservando sus rutas relativas. Los archivos existentes
se entregan completos: compare antes de sustituir si tiene cambios posteriores.

Desde la raíz del proyecto:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true --no-restore -m:1 -nr:false
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

La ejecución de la última orden requiere Windows. Cierre el ejecutable
anterior y abra la versión recién compilada. En una partida vinculada a
Excel, seleccione Cantidad y salga sin escribir: el icono debe conservarse.
Repita escribiendo el mismo número con un formato equivalente, cancelando
con Escape y con una cantidad realmente distinta. En ese último caso se
usa cantidad directa, sin borrar el metrado guardado.

No se añaden dependencias, migraciones de base de datos ni herramientas nuevas.
Se mantienen los trece botones y el refresco de precios de las entregas anteriores.
La base remota comprobada sigue siendo main, commit
fc865f24a564dfed3730b7517c31f8567e46892a, más las correcciones anteriores.

## Validación de esta entrega

La solución completa se compiló en Linux x64 con SDK .NET 10.0.100:
cero errores y cero advertencias. Se compilaron las nuevas comprobaciones
de clic y salida, formatos equivalentes, cuatro fuentes de cantidad,
precisión existente, Escape, valor inválido y cambio real.
La ejecución de estas pruebas de interfaz queda pendiente en Windows.

## Publicación

El ZIP se publica únicamente en bimchimbote-droid/DESCARGAS. La publicación
no aplica ni hace Push de estos cambios en MYG.Presupuestos. Después de
validar, revise Cambios de Git en Visual Studio y realice Commit y Push
si desea publicar el código. Las pruebas de interfaz necesitan Windows;
compilarlas en Linux no equivale a ejecutarlas.
