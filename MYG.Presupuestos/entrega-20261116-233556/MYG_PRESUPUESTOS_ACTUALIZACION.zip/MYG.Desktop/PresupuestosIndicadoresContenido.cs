using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Bitmap iconoEspecificacionFila, iconoExcelFila;
    private int EspacioIndicadorContenido => MedidaLecturaEstructura(23);

    private void PrepararIndicadoresContenido()
    {
        iconoEspecificacionFila = MYGIconos.Obtener("especificacion");
        iconoExcelFila = MYGIconos.Obtener("excel");
        // Se agrega al final de la colección para mantener el orden de los
        // valores de Rows.Add; visualmente queda después de cantidad/unidad.
        Columna(estructura, "METRADO_EXCEL", "", 26);
        var columna = estructura.Columns["METRADO_EXCEL"];
        columna.DisplayIndex = estructura.Columns["PU"].DisplayIndex;
        columna.Resizable = DataGridViewTriState.False;
        columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
        DimensionarIndicadorExcel();
        // Al abrir directamente en un monitor con escala alta no se recibe
        // necesariamente DpiChangedAfterParent. Las columnas no son controles
        // y necesitan su ancho en píxeles también durante la carga inicial.
        estructura.HandleCreated += (_, _) => DimensionarIndicadorExcel();
        Load += (_, _) => DimensionarIndicadorExcel();
        estructura.CellPainting += PintarIndicadorContenido;
        estructura.DpiChangedAfterParent += (_, _) =>
        {
            DimensionarIndicadorExcel();
            SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
        };
        Disposed += (_, _) => { iconoEspecificacionFila.Dispose(); iconoExcelFila.Dispose(); };
    }

    private void DimensionarIndicadorExcel()
    {
        int tamano = Math.Max(12, MedidaLecturaEstructura(16));
        int margen = Math.Max(3, MedidaLecturaEstructura(4));
        var columna = estructura.Columns["METRADO_EXCEL"];
        columna.MinimumWidth = tamano + margen * 2;
        columna.Width = Math.Max(columna.MinimumWidth, MedidaLecturaEstructura(26));
    }

    private void ActualizarIndicadoresContenido(DataGridViewRow fila, ItemPresupuestoDelphin partida)
    {
        if (MYGProyectoStorage.EsTitulo(partida)) return;
        var descripcion = CeldaEstructura(fila, "DESC");
        var margen = MargenCeldaEstructura(descripcion);
        // Un espacio para la especificación y otro para el aviso de catálogo.
        descripcion.Style.Padding = new(margen.Left, margen.Top,
            EspacioIndicadorContenido * 2, margen.Bottom);
        CeldaEstructura(fila, "METRADO_EXCEL").ToolTipText = MYGContenidoPartida.TieneMetradoExcelActivo(partida.Costos)
            ? "La cantidad está vinculada al metrado en Excel." : "";
    }

    internal Rectangle LimitesIndicadorContenido(DataGridViewCell celda)
    {
        if (celda?.DataGridView != estructura || celda.RowIndex < 0 || celda.ColumnIndex < 0 ||
            celda.OwningRow.Tag is not ItemPresupuestoDelphin partida || MYGProyectoStorage.EsTitulo(partida))
            return Rectangle.Empty;
        bool presente = celda.OwningColumn.Name switch
        {
            "DESC" => MYGContenidoPartida.TieneEspecificacionGuardada(partida.Costos),
            "METRADO_EXCEL" => MYGContenidoPartida.TieneMetradoExcelActivo(partida.Costos),
            _ => false
        };
        if (!presente) return Rectangle.Empty;
        var limites = estructura.GetCellDisplayRectangle(celda.ColumnIndex, celda.RowIndex, false);
        int tamano = Math.Max(12, MedidaLecturaEstructura(16));
        int margen = Math.Max(3, MedidaLecturaEstructura(4));
        if (limites.Width < tamano + margen * 2 || limites.Height < tamano) return Rectangle.Empty;
        return new(limites.Right - margen - tamano, limites.Top + (limites.Height - tamano) / 2, tamano, tamano);
    }

    private void PintarIndicadorContenido(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
        var celda = estructura[e.ColumnIndex, e.RowIndex];
        var limites = LimitesIndicadorContenido(celda);
        if (limites.IsEmpty) return;
        if (!e.Handled) e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
        var estado = e.Graphics.Save();
        try
        {
            e.Graphics.SetClip(Rectangle.Intersect(e.CellBounds, e.ClipBounds));
            e.Graphics.DrawImage(celda.OwningColumn.Name == "DESC" ? iconoEspecificacionFila : iconoExcelFila, limites);
            e.Handled = true;
        }
        finally { e.Graphics.Restore(estado); }
    }
}
