using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    // Preferencia de esta vista: no se escribe en el proyecto ni en sus reportes.
    private Font fuenteVistaEstructura, fuenteTituloVistaEstructura;
    private Color tintaVistaEstructura, fondoVistaEstructura;
    private bool formatoVistaEstructuraInicializado;
    private bool ajustandoLecturaEstructura, cambiandoDpiEstructura;
    private float factorLecturaEstructura = 1;
    private readonly Dictionary<string, float> anchosLecturaEstructura = new()
    {
        ["CANT"] = 90, ["UND"] = 68, ["PU"] = 100, ["TOTAL"] = 120
    };
    private float EscalaLecturaEstructura => estructura.DeviceDpi / 96f * MYGTamanoTextoUI.Factor;
    private int DpiLecturaEstructura => (int)Math.Round(estructura.DeviceDpi * MYGTamanoTextoUI.Factor);
    private int MedidaLecturaEstructura(float valor) => (int)Math.Round(valor * EscalaLecturaEstructura);

    private void InicializarFormatoVistaEstructura()
    {
        if (formatoVistaEstructuraInicializado) return;
        formatoVistaEstructuraInicializado = true;
        estructura.CellFormatting += FormatearVistaEstructura;
        estructura.EditingControlShowing += FormatearEditorVistaEstructura;
        estructura.HandleCreated += AjustarAlturasFormatoVistaEstructura;
        estructura.DpiChangedBeforeParent += (_, _) => cambiandoDpiEstructura = true;
        estructura.DpiChangedAfterParent += AjustarAlturasFormatoVistaEstructura;
        estructura.ColumnWidthChanged += (_, e) =>
        {
            if (!ajustandoLecturaEstructura && !cambiandoDpiEstructura && anchosLecturaEstructura.ContainsKey(e.Column.Name))
                anchosLecturaEstructura[e.Column.Name] = e.Column.Width / factorLecturaEstructura;
        };
        MYGTamanoTextoUI.CambioTamano += AjustarAlturasFormatoVistaEstructura;
        Disposed += (_, _) =>
        {
            MYGTamanoTextoUI.CambioTamano -= AjustarAlturasFormatoVistaEstructura;
            fuenteVistaEstructura?.Dispose();
            fuenteTituloVistaEstructura?.Dispose();
        };
        AjustarAlturasFormatoVistaEstructura(null, EventArgs.Empty);
    }

    private void ElegirFuenteEstructura()
    {
        var estilo = estructura.DefaultCellStyle;
        using var dialogo = new MYGFuenteResumenForm(
            fuenteVistaEstructura ?? MYGTamanoTextoUI.FuenteOriginal(estilo.Font ?? estructura.Font),
            fuenteVistaEstructura == null ? estilo.ForeColor : tintaVistaEstructura,
            fuenteVistaEstructura == null ? estilo.BackColor : fondoVistaEstructura)
        { Text = "Fuente del presupuesto", Name = "fuentePresupuestoDialogo" };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        AplicarFormatoVistaEstructura(dialogo.FuenteElegida, dialogo.ColorTexto, dialogo.ColorFondo);
    }

    internal void AplicarFormatoVistaEstructura(Font fuente, Color tinta, Color fondo)
    {
        ArgumentNullException.ThrowIfNull(fuente);
        // FuenteOriginal evita guardar otra vez el porcentaje global de lectura.
        var nueva = (Font)MYGTamanoTextoUI.FuenteOriginal(fuente).Clone();
        Font titulo;
        try { titulo = new Font(nueva, nueva.Style | FontStyle.Bold); }
        catch { nueva.Dispose(); throw; }
        var anterior = fuenteVistaEstructura;
        var tituloAnterior = fuenteTituloVistaEstructura;
        fuenteVistaEstructura = nueva;
        fuenteTituloVistaEstructura = titulo;
        tintaVistaEstructura = tinta.IsEmpty ? MYG2027_TemaComercial.Texto : tinta;
        fondoVistaEstructura = fondo.IsEmpty ? MYG2027_TemaComercial.Superficie : fondo;
        AjustarAlturasFormatoVistaEstructura(null, EventArgs.Empty);
        anterior?.Dispose();
        tituloAnterior?.Dispose();
    }

    private Font FuenteFormatoVistaEstructura(DataGridViewRow fila)
    {
        bool titulo = fila.Tag is MYGPresupuestoDocumento ||
            fila.Tag is ItemPresupuestoDelphin item && MYGProyectoStorage.EsTitulo(item);
        // Las fuentes escaladas pertenecen al caché compartido de la interfaz.
        return MYGTamanoTextoUI.Fuente(titulo ? fuenteTituloVistaEstructura : fuenteVistaEstructura);
    }

    private Font FuenteMedicionEstructura(DataGridViewRow fila) => fuenteVistaEstructura == null
        ? MYGTamanoTextoUI.Fuente(fila.DefaultCellStyle.Font ?? estructura.Font)
        : FuenteFormatoVistaEstructura(fila);

    private void FormatearVistaEstructura(object sender, DataGridViewCellFormattingEventArgs e)
    {
        if (fuenteVistaEstructura == null || e.RowIndex < 0) return;
        e.CellStyle.Font = FuenteFormatoVistaEstructura(estructura.Rows[e.RowIndex]);
        AplicarColoresFormatoVistaEstructura(e.CellStyle);
    }

    private void AplicarColoresFormatoVistaEstructura(DataGridViewCellStyle estilo)
    {
        bool contraste = SystemInformation.HighContrast;
        estilo.ForeColor = contraste ? SystemColors.WindowText : tintaVistaEstructura;
        estilo.BackColor = contraste ? SystemColors.Window : fondoVistaEstructura;
        estilo.SelectionBackColor = contraste ? SystemColors.Highlight : MYG2027_TemaComercial.Seleccion;
        estilo.SelectionForeColor = contraste ? SystemColors.HighlightText : MYG2027_TemaComercial.TextoSeleccion;
    }

    private void FormatearEditorVistaEstructura(object sender, DataGridViewEditingControlShowingEventArgs e)
    {
        if (fuenteVistaEstructura == null || estructura.CurrentRow == null) return;
        e.CellStyle.Font = FuenteFormatoVistaEstructura(estructura.CurrentRow);
        AplicarColoresFormatoVistaEstructura(e.CellStyle);
        e.Control.Font = e.CellStyle.Font;
        e.Control.ForeColor = e.CellStyle.ForeColor;
        e.Control.BackColor = e.CellStyle.BackColor;
    }

    private void AjustarAlturasFormatoVistaEstructura(object sender, EventArgs e)
    {
        if (IsDisposed || Disposing || estructura.IsDisposed || ajustandoLecturaEstructura) return;
        bool previo = cargando;
        cargando = true; ajustandoLecturaEstructura = true;
        var ajuste = estructura.AutoSizeRowsMode;
        var primera = estructura.FirstDisplayedScrollingRowIndex >= 0 ? estructura.Rows[estructura.FirstDisplayedScrollingRowIndex] : null;
        int horizontal = estructura.HorizontalScrollingOffset;
        var editor = estructura.EditingControl as TextBoxBase;
        int inicio = editor?.SelectionStart ?? 0, longitud = editor?.SelectionLength ?? 0;
        estructura.SuspendLayout(); estructura.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        try
        {
            factorLecturaEstructura = EscalaLecturaEstructura;
            int margen = MedidaLecturaEstructura(4);
            estructura.DefaultCellStyle.Padding = new Padding(margen);
            var fuenteCabecera = MYGTamanoTextoUI.Fuente(estructura.ColumnHeadersDefaultCellStyle.Font ?? estructura.Font);
            estructura.ColumnHeadersHeight = Math.Max(MedidaLecturaEstructura(30), fuenteCabecera.Height + margen * 2 + 2);
            estructura.RowTemplate.MinimumHeight = Math.Max(MedidaLecturaEstructura(29),
                MYGTamanoTextoUI.Fuente(estructura.Font).Height + margen * 2 + 1);
            estructura.RowTemplate.Height = estructura.RowTemplate.MinimumHeight;
            estructura.Columns["DESC"].MinimumWidth = MedidaLecturaEstructura(170);
            DimensionarIndicadorExcel();
            // También las filas retiradas temporalmente al plegar una rama:
            // reabrirla debe recuperar la escala actual sin reconstruir datos.
            foreach (var fila in filasEstructura) AplicarEspaciadoVistaEstructura(fila);
            foreach (var par in anchosLecturaEstructura)
            {
                var columna = estructura.Columns[par.Key];
                int anchoTitulo = TextRenderer.MeasureText(columna.HeaderText, fuenteCabecera).Width + margen * 2 + 2;
                int anchoContenido = 0;
                foreach (var fila in filasEstructura)
                {
                    var celda = CeldaEstructura(fila, par.Key);
                    string texto = celda.Value is IFormattable valor
                        ? valor.ToString(columna.DefaultCellStyle.Format, CultureInfo.CurrentCulture) : Convert.ToString(celda.Value);
                    if (!string.IsNullOrEmpty(texto)) anchoContenido = Math.Max(anchoContenido,
                        TextRenderer.MeasureText(texto, FuenteMedicionEstructura(fila)).Width + MargenCeldaEstructura(celda).Horizontal + 2);
                }
                columna.Width = Math.Max(Math.Max(anchoTitulo, anchoContenido), MedidaLecturaEstructura(par.Value));
            }
            AjustarAnchoCodigoEstructura();
            if (estructura.Rows.Count > 0)
                estructura.AutoResizeRows(DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders);
        }
        finally
        {
            estructura.AutoSizeRowsMode = ajuste;
            estructura.ResumeLayout();
            if (primera?.DataGridView == estructura) estructura.FirstDisplayedScrollingRowIndex = primera.Index;
            int ancho = estructura.Columns.Cast<DataGridViewColumn>().Where(c => c.Visible).Sum(c => c.Width);
            estructura.HorizontalScrollingOffset = Math.Min(horizontal, Math.Max(0, ancho - estructura.ClientSize.Width + SystemInformation.VerticalScrollBarWidth));
            if (editor != null && !editor.IsDisposed && ReferenceEquals(estructura.EditingControl, editor))
                editor.Select(Math.Min(inicio, editor.TextLength), Math.Min(longitud, Math.Max(0, editor.TextLength - inicio)));
            ajustandoLecturaEstructura = false; cambiandoDpiEstructura = false; cargando = previo;
        }
        estructura.Invalidate();
    }

    private void AplicarEspaciadoVistaEstructura(DataGridViewRow fila)
    {
        int margen = MedidaLecturaEstructura(4), nivel = nivelesEstructura.GetValueOrDefault(fila);
        fila.MinimumHeight = Math.Max(MedidaLecturaEstructura(29), FuenteMedicionEstructura(fila).Height + margen * 2 + 1);
        fila.Height = fila.MinimumHeight;
        CeldaEstructura(fila, "ITEM").Style.Padding = new(SangriaEstructura(fila) + MedidaLecturaEstructura(20), margen, MedidaLecturaEstructura(3), margen);
        bool partida = fila.Tag is ItemPresupuestoDelphin item && !MYGProyectoStorage.EsTitulo(item);
        CeldaEstructura(fila, "DESC").Style.Padding = new(MedidaLecturaEstructura(nivel * 6 + 4), margen,
            partida ? EspacioIndicadorContenido * 2 : margen, margen);
        foreach (string columna in new[] { "PU", "TOTAL" })
            CeldaEstructura(fila, columna).Style.Padding = new(margen, margen, partida ? MedidaLecturaEstructura(21) : margen, margen);
        var unidad = CeldaEstructura(fila, "UND");
        unidad.Style.Padding = new(margen, margen, unidad.ReadOnly ? margen : MedidaLecturaEstructura(21), margen);
    }

    private void AjustarAnchoCodigoEstructura()
    {
        if (filasEstructura.Count == 0) return;
        estructura.Columns["ITEM"].Width = Math.Max(MedidaLecturaEstructura(105), Math.Min(MedidaLecturaEstructura(300),
            filasEstructura.Max(fila => AnchoCodigoEstructura(fila))));
    }

    private int AnchoCodigoEstructura(DataGridViewRow fila) =>
        TextRenderer.MeasureText(Convert.ToString(CeldaEstructura(fila, "ITEM").Value), FuenteMedicionEstructura(fila)).Width
            + CeldaEstructura(fila, "ITEM").Style.Padding.Horizontal + MedidaLecturaEstructura(8);
}
