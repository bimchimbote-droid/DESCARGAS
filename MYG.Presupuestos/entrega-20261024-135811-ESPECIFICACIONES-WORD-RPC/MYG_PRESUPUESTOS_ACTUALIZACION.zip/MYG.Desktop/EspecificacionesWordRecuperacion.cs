using System;
using System.IO;
using System.Runtime.InteropServices;

namespace MYG_2027;

internal static class MYGEspecificacionesWordRecuperacion
{
    // Cada llamada debe crear y liberar su propia sesión de Word. Tras perder
    // RPC no es seguro volver a usar los objetos COM del intento anterior.
    internal static T Ejecutar<T>(Func<T> preparar)
    {
        ArgumentNullException.ThrowIfNull(preparar);
        try { return preparar(); }
        catch (Exception ex) when (EsDesconexion(ex)) { }
        // Este segundo intento queda fuera del catch: su excepción se conserva
        // íntegra y nunca se inicia un tercer intento.
        return preparar();
    }

    internal static bool EsDesconexion(Exception ex)
    {
        bool desconexion = false;
        for (Exception actual = ex; actual != null; actual = actual.InnerException)
        {
            // Un error de recursos, permisos o archivos no se resuelve abriendo
            // otra sesión, aunque contenga una excepción COM como contexto.
            if (actual is OutOfMemoryException or UnauthorizedAccessException or IOException)
                return false;
            if (actual is COMException com && unchecked((uint)com.HResult) is
                0x800706BEu or 0x800706BAu or 0x800706BFu or
                0x80010108u or 0x80010007u or 0x80010012u)
                desconexion = true;
        }
        return desconexion;
    }
}
