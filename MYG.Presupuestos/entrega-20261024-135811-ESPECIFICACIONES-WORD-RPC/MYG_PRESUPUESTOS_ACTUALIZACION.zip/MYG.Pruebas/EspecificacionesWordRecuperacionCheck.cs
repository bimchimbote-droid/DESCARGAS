using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using MYG_2027;

internal static class EspecificacionesWordRecuperacionCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static COMException Error(uint codigo) => new("Fallo Word simulado", unchecked((int)codigo));

    private static void ExigeExcepcionExacta(Exception esperada, Action accion, string detalle)
    {
        try { accion(); }
        catch (Exception recibida)
        {
            Exige(ReferenceEquals(esperada, recibida), detalle + " Se sustituyó la excepción original.");
            return;
        }
        throw new Exception(detalle + " No se propagó el fallo.");
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        int intentos = 0;
        object esperado = new();
        object recibido = MYGEspecificacionesWordRecuperacion.Ejecutar(() =>
        { intentos++; return esperado; });
        Exige(intentos == 1 && ReferenceEquals(recibido, esperado),
            "Una preparación correcta debe devolver su misma entrega sin ejecutar otra sesión.");
        pasa("Word: una entrega correcta conserva su identidad y se prepara una sola vez");

        uint[] codigos = { 0x800706BEu, 0x800706BAu, 0x800706BFu, 0x80010108u, 0x80010007u, 0x80010012u };
        foreach (uint codigo in codigos)
        {
            foreach (bool envolver in new[] { false, true })
            {
                intentos = 0;
                var orden = new List<string>();
                recibido = MYGEspecificacionesWordRecuperacion.Ejecutar(() =>
                {
                    int numero = ++intentos;
                    orden.Add("abrir " + numero);
                    try
                    {
                        if (numero == 1)
                        {
                            Exception error = Error(codigo);
                            if (envolver) error = new InvalidOperationException("Etapa de paginación", new TargetInvocationException(error));
                            throw error;
                        }
                        Exige(orden.Count == 3 && orden[1] == "liberar 1",
                            "La sesión perdida debe liberarse antes de abrir el siguiente intento.");
                        return esperado;
                    }
                    finally { orden.Add("liberar " + numero); }
                });
                Exige(intentos == 2 && ReferenceEquals(recibido, esperado) &&
                    string.Join(",", orden) == "abrir 1,liberar 1,abrir 2,liberar 2",
                    "Una desconexión RPC directa o envuelta debe permitir una nueva sesión completa.");
            }
        }
        pasa("Word: seis códigos de desconexión, directos o envueltos, permiten recuperarse con una segunda sesión independiente");

        intentos = 0;
        Exception segundoError = new InvalidOperationException("Segundo fallo de paginación", Error(0x800706BEu));
        ExigeExcepcionExacta(segundoError, () => MYGEspecificacionesWordRecuperacion.Ejecutar<object>(() =>
        {
            intentos++;
            if (intentos == 1) throw Error(0x80010108u);
            throw segundoError;
        }), "Un segundo fallo debe conservar su excepción y terminar la operación.");
        Exige(intentos == 2, "La recuperación inició un tercer intento.");
        pasa("Word: dos fallos consecutivos terminan tras el segundo intento y conservan la excepción final");

        foreach (uint codigo in new[] { 0x80010001u, 0x8001010Au, 0x80004005u })
        {
            intentos = 0;
            Exception ocupado = new TargetInvocationException(Error(codigo));
            ExigeExcepcionExacta(ocupado, () => MYGEspecificacionesWordRecuperacion.Ejecutar<object>(() =>
            { intentos++; throw ocupado; }), "Una llamada rechazada, Word ocupado u otro fallo COM no debe reiniciar la sesión.");
            Exige(intentos == 1 && !MYGEspecificacionesWordRecuperacion.EsDesconexion(ocupado),
                "Se confundió un error COM distinto con una desconexión.");
        }
        pasa("Word: llamadas rechazadas, servidor ocupado y errores COM desconocidos no reinician la sesión");

        foreach (Exception fallo in new Exception[]
        {
            new InvalidOperationException("Documento inválido"),
            new IOException("No se pudo escribir el archivo", Error(0x800706BEu)),
            new UnauthorizedAccessException("Acceso denegado", Error(0x800706BEu)),
            new OutOfMemoryException("Sin memoria", Error(0x800706BEu)),
            new InvalidOperationException("Operación de archivo", new IOException("Archivo bloqueado", Error(0x800706BEu))),
            new TargetInvocationException(new OutOfMemoryException("Sin memoria", Error(0x800706BEu)))
        })
        {
            intentos = 0;
            ExigeExcepcionExacta(fallo, () => MYGEspecificacionesWordRecuperacion.Ejecutar<object>(() =>
            { intentos++; throw fallo; }), "Los fallos de datos, archivos, permisos o memoria no deben repetirse.");
            Exige(intentos == 1 && !MYGEspecificacionesWordRecuperacion.EsDesconexion(fallo),
                "La recuperación ocultó un error no recuperable tras una desconexión interna.");
        }
        Exige(!MYGEspecificacionesWordRecuperacion.EsDesconexion(null),
            "La ausencia de excepción no representa una desconexión.");
        pasa("Word: errores de datos, permisos, archivos y memoria se propagan intactos sin repetir la operación");
    }
}
