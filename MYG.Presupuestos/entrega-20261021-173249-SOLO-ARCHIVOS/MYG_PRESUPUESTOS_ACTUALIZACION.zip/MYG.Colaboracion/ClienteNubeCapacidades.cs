using System.Text.Json;

namespace MYG.Colaboracion;

public sealed record CapacidadesNube(int PaqueteCompacto, int Cambios);

public sealed partial class ClienteSupabase
{
    private CapacidadesNube? capacidadesNube;

    public async Task<CapacidadesNube> ObtenerCapacidadesNubeAsync(CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        if (!SesionIniciada) throw new NubeException("Inicie sesión para consultar las funciones de nube.", necesitaIniciarSesion: true);
        if (capacidadesNube is not null) return capacidadesNube;
        try
        {
            var resultado = await EjecutarRpcNubeAsync("myg_nube_capacidades", new { }, raiz =>
            {
                if (raiz.ValueKind != JsonValueKind.Object
                    || !raiz.TryGetProperty("paquete_compacto", out var paquete)
                    || paquete.ValueKind != JsonValueKind.Number || !paquete.TryGetInt32(out int version) || version < 1)
                    throw RespuestaNubeInvalida();
                int cambios = 0;
                if (raiz.TryGetProperty("cambios", out var delta)
                    && (delta.ValueKind != JsonValueKind.Number || !delta.TryGetInt32(out cambios) || cambios < 0)) throw RespuestaNubeInvalida();
                return new CapacidadesNube(version, cambios);
            }, ct);
            capacidadesNube = resultado;
            return resultado;
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883")
        {
            throw new NubeException("Actualice Supabase con las migraciones de paquete compacto y sincronización incremental antes de publicar con esta versión. Se conserva el intento pendiente.", codigo: ex.Codigo);
        }
    }

    public async Task ExigirPaqueteCompactoAsync(CancellationToken ct = default)
    {
        if ((await ObtenerCapacidadesNubeAsync(ct)).PaqueteCompacto < 2)
            throw new NubeException("El servidor todavía no admite publicaciones compactas. Aplique la actualización de Supabase; se conserva el intento pendiente.");
    }
}
