using System.Text.Json;
using System.Text.Json.Nodes;
using System.Globalization;
using System.Text;

namespace MYG.Colaboracion;

/// <summary>
/// Diferencias de un paquete por documento, tabla y recurso. La revisión del proyecto
/// sigue siendo la unidad de concurrencia: nunca combina escrituras incompatibles.
/// </summary>
public static class CambiosPaqueteNube
{
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };
    private static readonly Dictionary<string, string> Colecciones = new(StringComparer.Ordinal)
    {
        ["documentos"] = "Id", ["tablas"] = "Nombre", ["recursos"] = "Referencia"
    };
    private static readonly HashSet<string> Campos = new(StringComparer.Ordinal)
    {
        "formato", "version", "alcance", "documento", "textos", "avisos", "exclusiones"
    };

    public static JsonElement Crear(JsonElement anterior, JsonElement nuevo)
    {
        var antes = Objeto(anterior); var despues = Objeto(nuevo);
        ValidarPaquete(antes); ValidarPaquete(despues);
        var campos = new JsonObject();
        foreach (var campo in Campos)
        {
            bool estaba = antes.ContainsKey(campo), esta = despues.ContainsKey(campo);
            if (estaba && !esta) throw new InvalidDataException("El cambio no puede retirar campos del formato de publicación.");
            if (esta && (!estaba || !JsonNode.DeepEquals(antes[campo], despues[campo])))
                campos[campo] = despues[campo]?.DeepClone();
        }
        var cambios = new JsonObject { ["version"] = 1, ["campos"] = campos };
        foreach (var (nombre, identidad) in Colecciones)
        {
            var previos = Indice(antes[nombre] as JsonArray, identidad);
            var actuales = Indice(despues[nombre] as JsonArray, identidad);
            var poner = new JsonArray(); var quitar = new JsonArray(); var orden = new JsonArray();
            foreach (var (id, valor) in actuales)
            {
                orden.Add(id);
                if (!previos.TryGetValue(id, out var previo) || !JsonNode.DeepEquals(previo, valor))
                    poner.Add(valor.DeepClone());
            }
            foreach (string id in previos.Keys) if (!actuales.ContainsKey(id)) quitar.Add(id);
            if (poner.Count > 0 || quitar.Count > 0
                || !previos.Keys.SequenceEqual(actuales.Keys, StringComparer.Ordinal))
                cambios[nombre] = new JsonObject { ["poner"] = poner, ["quitar"] = quitar, ["orden"] = orden };
        }
        JsonElement porColecciones = JsonSerializer.SerializeToElement(cambios, Json);
        var operaciones = new JsonArray();
        if (CompararRutas(antes, despues, new List<string>(), operaciones))
        {
            var rutas = JsonSerializer.SerializeToElement(new JsonObject { ["version"] = 2, ["operaciones"] = operaciones }, Json);
            if (Encoding.UTF8.GetByteCount(rutas.GetRawText()) < Encoding.UTF8.GetByteCount(porColecciones.GetRawText()))
                return rutas;
        }
        return porColecciones;
    }

    public static JsonElement Aplicar(JsonElement anterior, JsonElement cambios)
    {
        var resultado = Objeto(anterior); ValidarPaquete(resultado);
        var delta = Objeto(cambios);
        if (EsVersion(delta["version"], 2)) return AplicarRutas(resultado, delta);
        if (!EsVersion(delta["version"], 1) || delta["campos"] is not JsonObject campos
            || delta.Any(x => x.Key is not ("version" or "campos" or "documentos" or "tablas" or "recursos")))
            throw new InvalidDataException("Formato de cambios de nube no compatible.");
        foreach (var campo in campos)
        {
            if (!Campos.Contains(campo.Key)) throw new InvalidDataException("Campo de publicación no autorizado.");
            resultado[campo.Key] = campo.Value?.DeepClone();
        }
        foreach (var (nombre, identidad) in Colecciones)
        {
            if (!delta.TryGetPropertyValue(nombre, out var nodo)) continue;
            if (nodo is not JsonObject grupo || grupo.Count != 3 || grupo["poner"] is not JsonArray poner
                || grupo["quitar"] is not JsonArray quitar || grupo["orden"] is not JsonArray orden)
                throw new InvalidDataException("Colección de cambios de nube no compatible.");
            var actual = Indice(resultado[nombre] as JsonArray, identidad);
            var bajas = new HashSet<string>(StringComparer.Ordinal);
            foreach (var idNodo in quitar)
            {
                string id = Identidad(idNodo);
                if (!bajas.Add(id) || !actual.Remove(id)) throw new InvalidDataException("La baja no identifica un elemento único existente.");
            }
            var altas = Indice(poner, identidad);
            foreach (var (id, valor) in altas)
            {
                if (bajas.Contains(id)) throw new InvalidDataException("Un elemento no puede reemplazarse y retirarse a la vez.");
                actual[id] = valor;
            }
            var salida = new JsonArray(); var vistos = new HashSet<string>(StringComparer.Ordinal);
            foreach (var idNodo in orden)
            {
                string id = Identidad(idNodo);
                if (!vistos.Add(id) || !actual.TryGetValue(id, out var valor))
                    throw new InvalidDataException("El orden de la colección no identifica elementos únicos.");
                salida.Add(valor.DeepClone());
            }
            if (vistos.Count != actual.Count) throw new InvalidDataException("El cambio omite elementos de la colección.");
            resultado[nombre] = salida;
        }
        ValidarPaquete(resultado);
        return JsonSerializer.SerializeToElement(resultado, Json);
    }

    private static bool CompararRutas(JsonNode? antes, JsonNode? despues, List<string> ruta, JsonArray operaciones)
    {
        if (JsonNode.DeepEquals(antes, despues)) return true;
        if (antes is JsonObject a && despues is JsonObject b)
        {
            foreach (var campo in a)
            {
                ruta.Add(campo.Key);
                if (!b.ContainsKey(campo.Key))
                {
                    if (!AgregarRuta(ruta, null, true, operaciones)) return false;
                }
                else if (!CompararRutas(campo.Value, b[campo.Key], ruta, operaciones)) return false;
                ruta.RemoveAt(ruta.Count - 1);
            }
            foreach (var campo in b.Where(x => !a.ContainsKey(x.Key)))
            {
                ruta.Add(campo.Key);
                if (!AgregarRuta(ruta, campo.Value, false, operaciones)) return false;
                ruta.RemoveAt(ruta.Count - 1);
            }
            return true;
        }
        if (antes is JsonArray listaA && despues is JsonArray listaB && listaA.Count == listaB.Count)
        {
            for (int i = 0; i < listaA.Count; i++)
            {
                ruta.Add(i.ToString(CultureInfo.InvariantCulture));
                if (!CompararRutas(listaA[i], listaB[i], ruta, operaciones)) return false;
                ruta.RemoveAt(ruta.Count - 1);
            }
            return true;
        }
        return AgregarRuta(ruta, despues, false, operaciones);
    }

    private static bool AgregarRuta(List<string> ruta, JsonNode? valor, bool quitar, JsonArray operaciones)
    {
        if (operaciones.Count >= 4096 || ruta.Count is < 1 or > 126) return false;
        var operacion = new JsonObject { ["ruta"] = new JsonArray(ruta.Select(x => (JsonNode?)JsonValue.Create(x)).ToArray()) };
        if (quitar) operacion["quitar"] = true; else operacion["valor"] = valor?.DeepClone();
        operaciones.Add(operacion);
        return true;
    }

    private static JsonElement AplicarRutas(JsonObject resultado, JsonObject delta)
    {
        if (delta.Count != 2 || delta["operaciones"] is not JsonArray operaciones || operaciones.Count > 4096)
            throw new InvalidDataException("Formato de cambios por rutas no compatible.");
        foreach (var nodo in operaciones)
        {
            if (nodo is not JsonObject operacion || operacion.Count != 2 || operacion["ruta"] is not JsonArray ruta
                || ruta.Count is < 1 or > 126)
                throw new InvalidDataException("Ruta de cambio no válida.");
            bool quitar = operacion.ContainsKey("quitar");
            if (quitar ? operacion["quitar"] is not JsonValue baja || !baja.TryGetValue<bool>(out bool esBaja) || !esBaja
                       : !operacion.ContainsKey("valor"))
                throw new InvalidDataException("Operación de cambio no válida.");
            var segmentos = ruta.Select(SegmentoRuta).ToArray();
            if (!Campos.Contains(segmentos[0]) && !Colecciones.ContainsKey(segmentos[0]))
                throw new InvalidDataException("Campo de publicación no autorizado.");
            JsonNode? padre = resultado;
            for (int i = 0; i < segmentos.Length - 1; i++)
            {
                padre = padre switch
                {
                    JsonObject objeto when objeto.TryGetPropertyValue(segmentos[i], out var hijo) => hijo,
                    JsonArray lista => lista[IndiceRuta(segmentos[i], lista.Count)],
                    _ => throw new InvalidDataException("La ruta no identifica un contenedor existente.")
                };
            }
            string ultimo = segmentos[^1];
            if (padre is JsonObject destino)
            {
                if (quitar)
                {
                    if (!destino.Remove(ultimo)) throw new InvalidDataException("La ruta no identifica un campo existente.");
                }
                else destino[ultimo] = operacion["valor"]?.DeepClone();
            }
            else if (padre is JsonArray lista)
            {
                if (quitar) throw new InvalidDataException("El cambio no puede desplazar índices de una lista.");
                lista[IndiceRuta(ultimo, lista.Count)] = operacion["valor"]?.DeepClone();
            }
            else throw new InvalidDataException("La ruta no identifica un contenedor existente.");
        }
        ValidarPaquete(resultado);
        return JsonSerializer.SerializeToElement(resultado, Json);
    }

    private static int IndiceRuta(string segmento, int longitud)
    {
        if (segmento.Length == 0 || (segmento.Length > 1 && segmento[0] == '0')
            || segmento.Any(x => x is < '0' or > '9')
            || !int.TryParse(segmento, NumberStyles.None, CultureInfo.InvariantCulture, out int indice)
            || indice >= longitud)
            throw new InvalidDataException("Índice de cambio fuera de la lista.");
        return indice;
    }

    private static string SegmentoRuta(JsonNode? nodo) => nodo is JsonValue valor
        && valor.TryGetValue<string>(out string? segmento) && segmento is not null ? segmento
        : throw new InvalidDataException("Los segmentos de ruta deben ser texto.");

    private static JsonObject Objeto(JsonElement valor) => JsonNode.Parse(valor.GetRawText(),
        documentOptions: new JsonDocumentOptions { MaxDepth = 128 }) as JsonObject
        ?? throw new InvalidDataException("El paquete de nube debe ser un objeto.");

    private static void ValidarPaquete(JsonObject paquete)
    {
        if (paquete["formato"] is not JsonValue formato || !formato.TryGetValue<string>(out var nombreFormato)
            || nombreFormato != "MYG_COLABORACION" || !EsVersion(paquete["version"], 2)
            || paquete.Any(x => !Campos.Contains(x.Key) && !Colecciones.ContainsKey(x.Key)))
            throw new InvalidDataException("La sincronización incremental requiere un paquete compacto compatible.");
        foreach (var (nombre, identidad) in Colecciones) Indice(paquete[nombre] as JsonArray, identidad);
    }

    private static bool EsVersion(JsonNode? nodo, int esperada) => nodo is JsonValue valor
        && valor.TryGetValue<int>(out int version) && version == esperada;

    private static Dictionary<string, JsonNode> Indice(JsonArray? lista, string propiedad)
    {
        if (lista is null) throw new InvalidDataException("Falta una colección de publicación.");
        var resultado = new Dictionary<string, JsonNode>(StringComparer.Ordinal);
        foreach (var nodo in lista)
        {
            if (nodo is not JsonObject objeto) throw new InvalidDataException("El elemento de publicación debe ser un objeto.");
            string id = Identidad(objeto[propiedad]);
            if (!resultado.TryAdd(id, nodo)) throw new InvalidDataException("La publicación contiene identidades repetidas.");
        }
        return resultado;
    }

    private static string Identidad(JsonNode? nodo)
    {
        if (nodo is not JsonValue valor || !valor.TryGetValue<string>(out string? id) || string.IsNullOrWhiteSpace(id))
            throw new InvalidDataException("La publicación contiene una identidad no válida.");
        return id;
    }
}
