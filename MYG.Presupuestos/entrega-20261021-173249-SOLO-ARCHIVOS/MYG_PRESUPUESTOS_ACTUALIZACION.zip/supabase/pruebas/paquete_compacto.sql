-- SOLO PostgreSQL desechable, después de usuarios_myg_roles.sql y contenido_grande.sql.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren una base desechable.'; end $$;
\endif

create table qa.antes_compacto as select
    (select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p) proyectos,
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h) historial,
    (select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m) miembros,
    (select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from public.myg_nube_operaciones o) operaciones;

\ir ../migraciones/20261022_paquete_compacto.sql
\ir ../migraciones/20261022_paquete_compacto.sql

select qa.exige((select proyectos=(select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p)
    and historial=(select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h)
    and miembros=(select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m)
    and operaciones=(select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from public.myg_nube_operaciones o)
    from qa.antes_compacto),'Compacto: migración repetida no modifica datos existentes');
select qa.exige(not has_function_privilege('anon','public.myg_nube_capacidades()','execute')
    and has_function_privilege('authenticated','public.myg_nube_capacidades()','execute'),
    'Compacto: capacidades solo disponibles para usuarios autenticados');
select qa.exige(not exists(select 1 from pg_proc p cross join lateral aclexplode(p.proacl) a
    where p.pronamespace='myg_nube_privado'::regnamespace and a.privilege_type='EXECUTE'
    and a.grantee in (0,'anon'::regrole,'authenticated'::regrole,'service_role'::regrole)),
    'Compacto: auxiliares y validadores originales permanecen privados');

-- Codificador exclusivo del fixture. La implementación productiva es C#.
create function qa.compactar_celda(p_celda jsonb) returns jsonb language sql immutable as $$
    select case p_celda->>'Tipo'
        when 'nulo' then 'null'::jsonb
        when 'texto' then p_celda->'Valor'
        when 'entero' then jsonb_build_array('i',p_celda->'Valor')
        when 'real' then jsonb_build_array('r',p_celda->'Valor')
        when 'blob' then jsonb_build_array('b',p_celda->'Valor') end;
$$;
create function qa.compactar(p_paquete jsonb) returns jsonb language sql immutable as $$
    select p_paquete||jsonb_build_object('version',2,'textos','[]'::jsonb,
        'documentos',coalesce((select jsonb_agg(value) from jsonb_array_elements(p_paquete->'documentos')
            where value->>'Id'<>p_paquete#>>'{documento,Id}'),'[]'::jsonb),
        'tablas',coalesce((select jsonb_agg(t.value||jsonb_build_object('Filas',
            coalesce((select jsonb_agg((select coalesce(jsonb_agg(qa.compactar_celda(c.value) order by c.ord),'[]'::jsonb)
                from jsonb_array_elements(f.value) with ordinality c(value,ord)) order by f.ord)
            from jsonb_array_elements(t.value->'Filas') with ordinality f(value,ord)),'[]'::jsonb)) order by t.ord)
        from jsonb_array_elements(p_paquete->'tablas') with ordinality t(value,ord)),'[]'::jsonb));
$$;
create table qa.paquetes_compactos as select nombre,qa.compactar(contenido) contenido from qa.paquetes;
grant select on qa.paquetes_compactos to authenticated;

select qa.exige((select myg_nube_privado.expandir_paquete(c.contenido)=v.contenido
    from qa.paquetes_compactos c join qa.paquetes v using(nombre) where nombre='baseline'),
    'Compacto: expansión restaura íntegramente el paquete v1');
select qa.exige((select octet_length(c.contenido::text)<octet_length(v.contenido::text)
    from qa.paquetes_compactos c join qa.paquetes v using(nombre) where nombre='baseline'),
    'Compacto: paquete con datos reales del código reduce tamaño sin comprimir');
select qa.exige(myg_nube_privado.expandir_paquete('{"anterior":"sin cambios"}')='{"anterior":"sin cambios"}'::jsonb,
    'Compacto: objetos anteriores conservan su contrato');
select qa.exige(myg_nube_privado.expandir_paquete('{"version":2,"presupuestos":[]}')='{"version":2,"presupuestos":[]}'::jsonb,
    'Compacto: objetos arbitrarios con version 2 conservan contrato anterior');

-- Comprobar el formato emitido por C#, no solamente un codificador SQL de prueba.
create table qa.paquete_cliente as select
    pg_read_file('/pruebas/paquetes/compacto_cliente.json')::jsonb contenido,
    pg_read_file('/pruebas/paquetes/compacto_cliente_expandido.json')::jsonb esperado;
create function qa.tablas_comparables(p_paquete jsonb) returns jsonb language sql immutable as $$
    select coalesce(jsonb_agg(t.value||jsonb_build_object('Filas',
        coalesce((select jsonb_agg((select jsonb_agg(case
            when t.value->>'Nombre'='myg_proyecto' and t.value->'Columnas'->>(c.ord-1)::integer='json_documento'
                and c.value->>'Tipo'='texto' then jsonb_set(c.value,'{Valor}',(c.value->>'Valor')::jsonb)
            else c.value end order by c.ord)
            from jsonb_array_elements(f.value) with ordinality c(value,ord)) order by f.ord)
        from jsonb_array_elements(t.value->'Filas') with ordinality f(value,ord)),'[]'::jsonb)) order by t.ord),'[]'::jsonb)
    from jsonb_array_elements(p_paquete->'tablas') with ordinality t(value,ord);
$$;
do $cliente$
begin
    perform myg_nube_privado.validar_contenido((select contenido from qa.paquete_cliente));
    perform qa.exige(true,'Compacto: servidor acepta paquete real emitido por codec C#');
end $cliente$;
select qa.exige((select myg_nube_privado.expandir_paquete(contenido)-'tablas'=esperado-'tablas'
    and qa.tablas_comparables(myg_nube_privado.expandir_paquete(contenido))=qa.tablas_comparables(esperado)
    from qa.paquete_cliente),'Compacto: expansión SQL y C# preservan todos los valores de la base completa');
select qa.exige((select octet_length(contenido::text)<octet_length(esperado::text) from qa.paquete_cliente),
    'Compacto: base completa del cliente reduce bytes persistidos sin compresión');
select qa.exige((select bool_and(myg_nube_privado.paquete_modulo(myg_nube_privado.expandir_paquete(p.contenido),m)=
    myg_nube_privado.paquete_modulo(p.esperado,m)) from qa.paquete_cliente p
    cross join unnest(array['acu','especificaciones','metrados_excel']) m),
    'Compacto: C# y servidor coinciden en proyecciones de todos los permisos');

do $navegacion$
declare v jsonb; v_nuevo jsonb;
begin
    select contenido into v from qa.paquete_cliente;
    v_nuevo:=jsonb_set(v,'{documento,Nombre}','"Nombre cambiado sin tocar los datos"');
    perform myg_nube_privado.validar_contenido(v_nuevo);
    perform myg_nube_privado.exigir_modulos(v,v_nuevo,'{"acu":false,"especificaciones":false,"metrados_excel":false}');
    perform qa.exige(true,'Compacto: metadatos con referencia d conservan módulos sin reconstrucción redundante');
end $navegacion$;
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_set((select contenido from qa.paquete_cliente),'{documento,nombre}','"alias"'))$$,
    '22023','Compacto: alias de metadatos no activa la ruta rápida');
select qa.rechaza($$select myg_nube_privado.exigir_modulos(contenido,
    jsonb_set(contenido,'{documento,Presupuestos,0,Items,0,Costos,PrecioDirecto}','999'),
    '{"acu":false,"especificaciones":false,"metrados_excel":false}') from qa.paquete_cliente$$,
    '42501','Compacto: cambiar datos del documento con tablas idénticas no activa ruta de metadatos');
select qa.rechaza($$select myg_nube_privado.exigir_modulos(contenido,
    jsonb_set(contenido,'{documento,Nombre}','"nuevo"'),'{"acu":false}') from qa.paquete_cliente$$,
    '42501','Compacto: metadatos no eluden una máscara de permisos inválida');

create table qa.cliente_renombrado as select pg_read_file('/pruebas/paquetes/compacto_cliente_nombre.json')::jsonb contenido;
select qa.exige((select a.contenido->'tablas'<>b.contenido->'tablas'
    and myg_nube_privado.tablas_solo_metadatos(a.contenido->'tablas',b.contenido->'tablas')
    from qa.paquete_cliente a cross join qa.cliente_renombrado b),
    'Compacto: Guardar real cambia solo nombres y fecha en tablas nativas permitidas');
do $renombrado_real$
begin
    perform myg_nube_privado.validar_contenido((select contenido from qa.cliente_renombrado));
    perform myg_nube_privado.exigir_modulos((select contenido from qa.paquete_cliente),
        (select contenido from qa.cliente_renombrado),'{"acu":false,"especificaciones":false,"metrados_excel":false}');
    perform qa.exige(true,'Compacto: renombrado real SQLite y C# conserva permisos con datos nativos');
end $renombrado_real$;

create table qa.celdas_compactas as select jsonb_set(contenido,'{tablas}',
    '[{"Nombre":"prueba","Columnas":["nulo","texto","entero","real","blob","referencia"],
       "Filas":[[null,"1",["i","9223372036854775807"],["r","1.25"],["b","AAEC"],["s",0]]]}]'::jsonb)
    ||jsonb_build_object('textos',jsonb_build_array('texto compartido')) contenido
    from qa.paquetes_compactos where nombre='baseline';
select qa.exige((select myg_nube_privado.expandir_paquete(contenido)#>'{tablas,0,Filas,0}'=
    '[{"Tipo":"nulo","Valor":null},{"Tipo":"texto","Valor":"1"},{"Tipo":"entero","Valor":"9223372036854775807"},
      {"Tipo":"real","Valor":"1.25"},{"Tipo":"blob","Valor":"AAEC"},{"Tipo":"texto","Valor":"texto compartido"}]'::jsonb
    from qa.celdas_compactas),'Compacto: conserva null, texto, Int64, real, binario y referencias');
select qa.exige((select (myg_nube_privado.expandir_paquete(jsonb_set(contenido,'{tablas}',
    jsonb_build_array(jsonb_build_object('Nombre','myg_proyecto','Columnas',jsonb_build_array('json_documento'),
    'Filas',jsonb_build_array(jsonb_build_array(jsonb_build_array('d',contenido#>>'{documento,Id}')))))))
    #>>'{tablas,0,Filas,0,0,Valor}')::jsonb=contenido->'documento' from qa.celdas_compactas),
    'Compacto: referencia de documento restaura su JSON sin una copia persistida');

do $invalidos$
declare v jsonb; n integer:=0;
begin
    foreach v in array array['0','true','{}','[]','["i"]','["i","1",0]','["i",1]',
        '["i","9223372036854775808"]','["i","1.5"]','["r","NaN"]','["r","Infinity"]',
        '["r","1e9999"]','["b","no-es-base64"]','["s",-1]','["s",1]','["s",0.5]',
        '["s","0"]','["s",999999999999999999999999]','["d","no-existe"]',
        '["d","QA-DOCUMENTO"]','["desconocido","x"]']::jsonb[] loop
        n:=n+1;
        perform qa.rechaza(format('select myg_nube_privado.validar_contenido(jsonb_set((select contenido from qa.celdas_compactas),''{tablas,0,Filas,0,0}'',%L::jsonb))',v),
            '22023','Compacto: rechaza celda o referencia malformada '||n);
    end loop;
end $invalidos$;
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_set((select contenido from qa.celdas_compactas),'{tablas,0,Columnas,1}','"nulo"'))$$,
    '22023','Compacto: rechaza columnas duplicadas');
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_set((select contenido from qa.celdas_compactas),'{tablas,0,Filas,0}','[]'))$$,
    '22023','Compacto: rechaza filas con longitud distinta');
select qa.rechaza($$select myg_nube_privado.validar_contenido((select contenido||'{"Documento":{}}'::jsonb from qa.celdas_compactas))$$,
    '22023','Compacto: rechaza alias de envoltorio');
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_set((select contenido from qa.celdas_compactas),'{documentos}',jsonb_build_array((select contenido->'documento' from qa.celdas_compactas))))$$,
    '22023','Compacto: rechaza documento principal duplicado');
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_set((select contenido from qa.celdas_compactas),'{textos}','[null]'))$$,
    '22023','Compacto: rechaza diccionario con valores no textuales');
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_set((select contenido from qa.celdas_compactas),'{version}','3'))$$,
    '22023','Compacto: rechaza versión no compatible');

-- Un diccionario de 1 MiB referenciado 513 veces se rechaza antes de expandir.
select qa.rechaza($$select myg_nube_privado.validar_contenido(
    jsonb_set((select contenido from qa.celdas_compactas),'{tablas}',jsonb_build_array(jsonb_build_object(
        'Nombre','prueba','Columnas',jsonb_build_array('texto'),'Filas',(select jsonb_agg('[["s",0]]'::jsonb->0) from generate_series(1,513)))))
    ||jsonb_build_object('textos',jsonb_build_array(repeat('x',1024*1024))))$$,
    '22023','Compacto: rechaza expansión superior a 512 MiB antes de materializar');

create table qa.ataque_diccionario as
    select jsonb_set(p.contenido,array['tablas',(t.ord-1)::text,'Filas','0',(c.ord-1)::text],'["s",0]'::jsonb)
        ||jsonb_build_object('textos',jsonb_build_array('Texto modificado solo en tabla')) contenido
    from qa.paquetes_compactos p
    cross join lateral jsonb_array_elements(p.contenido->'tablas') with ordinality t(value,ord)
    cross join lateral jsonb_array_elements(t.value->'Columnas') with ordinality c(value,ord)
    where p.nombre='ataque_tabla_especificacion' and t.value->>'Nombre'='costo_unitario' and c.value#>>'{}'='especificaciones';
grant select on qa.ataque_diccionario to authenticated;

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_capacidades()->>'paquete_compacto'='2',
    'Compacto: servidor anuncia capacidad v2');
select qa.exige(public.myg_nube_crear('60000000-0000-0000-0000-000000000001','Compacto QA',
    (select contenido from qa.paquetes_compactos where nombre='baseline'),'obra')->'contenido'=
    (select contenido from qa.paquetes_compactos where nombre='baseline'),
    'Compacto: crear conserva representación v2 sin expansión persistida');
select qa.exige(public.myg_nube_compartir_usuario('60000000-0000-0000-0000-000000000001','editor','editor',
    '{"acu":false,"especificaciones":false,"metrados_excel":false}')='{"estado":"actualizada"}'::jsonb,
    'Compacto: propietario conserva permisos por módulo');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.exige(public.myg_nube_guardar('60000000-0000-0000-0000-000000000001',
    '61000000-0000-0000-0000-000000000001',1,(select contenido from qa.paquetes_compactos where nombre='nombre'))->>'revision'='2',
    'Compacto: editor cambia nombre con módulos bloqueados');
select qa.exige(public.myg_nube_guardar('60000000-0000-0000-0000-000000000001',
    '61000000-0000-0000-0000-000000000001',1,(select contenido from qa.paquetes_compactos where nombre='nombre'))->>'revision'='2',
    'Compacto: replay conserva revisión y ACK');
select qa.rechaza($$select public.myg_nube_guardar('60000000-0000-0000-0000-000000000001',
    '61000000-0000-0000-0000-000000000001',1,(select contenido from qa.paquetes_compactos where nombre='descripcion'))$$,
    '22023','Compacto: mismo UUID con otro cuerpo no modifica confirmación');
do $modulos$
declare v text;
begin
    foreach v in array array['acu_precio','acu_recurso','acu_insumo','especificacion','hoja_excel',
        'ataque_tabla_acu','ataque_tabla_especificacion','ataque_tabla_excel','ataque_tipo_celda_acu','ataque_mayusculas_acu','ataque_recursos'] loop
        perform qa.rechaza(format('select public.myg_nube_guardar(%L,gen_random_uuid(),2,(select contenido from qa.paquetes_compactos where nombre=%L))',
            '60000000-0000-0000-0000-000000000001',v),'42501','Compacto: guard protege '||v);
    end loop;
end $modulos$;
select qa.rechaza($$select public.myg_nube_guardar('60000000-0000-0000-0000-000000000001',
    gen_random_uuid(),2,(select contenido from qa.ataque_diccionario))$$,
    '42501','Compacto: un diccionario no oculta cambios en módulos bloqueados');
select qa.exige(public.myg_nube_guardar('60000000-0000-0000-0000-000000000001',
    '61000000-0000-0000-0000-000000000002',1,(select contenido from qa.paquetes_compactos where nombre='descripcion'))->>'estado'='conflicto',
    'Compacto: edición concurrente conserva estado de conflicto');
reset role;
select qa.exige((select revision=2 and contenido->'version'='2'::jsonb from public.myg_nube_proyectos
    where id='60000000-0000-0000-0000-000000000001')
    and (select count(*)=2 and bool_and(contenido->'version'='2'::jsonb) from public.myg_nube_historial
    where proyecto_id='60000000-0000-0000-0000-000000000001'),
    'Compacto: rechazos no añaden revisiones e historial conserva formato compacto');
select format('PRUEBAS COMPACTO COMPLETADAS: %s',count(*)) from qa.resultados where descripcion like 'Compacto:%';
