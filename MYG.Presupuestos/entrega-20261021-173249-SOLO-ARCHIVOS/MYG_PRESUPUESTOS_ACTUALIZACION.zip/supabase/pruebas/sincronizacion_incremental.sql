-- SOLO una base desechable, después de paquete_compacto.sql.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren una base desechable.'; end $$;
\endif

create table qa.antes_delta as select
    (select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p) proyectos,
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h) historial;
\ir ../migraciones/20261023_sincronizacion_incremental.sql
\ir ../migraciones/20261023_sincronizacion_incremental.sql
select qa.exige((select proyectos=(select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p)
    and historial=(select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h)
    from qa.antes_delta),'Incremental: repetir migración conserva proyectos e historial');
select qa.exige(not has_function_privilege('anon','public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)','execute')
    and not has_function_privilege('anon','public.myg_nube_revision(uuid)','execute')
    and not has_function_privilege('authenticated','myg_nube_privado.aplicar_cambios(jsonb,jsonb)','execute')
    and not has_table_privilege('authenticated','myg_nube_privado.historial_cambios','SELECT'),
    'Incremental: helpers, historial y RPC no eluden autenticación');

-- Generador de diferencias para fixtures SQL. El cliente tiene sus propias pruebas
-- del generador C#, incluyendo contratos HTTP y reintentos con bytes congelados.
create function qa.crear_cambios(p_antes jsonb,p_despues jsonb) returns jsonb
language plpgsql immutable as $$
declare v_resultado jsonb; v_campos jsonb; v_nombre text; v_id text; v_poner jsonb; v_quitar jsonb; v_orden jsonb;
begin
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into v_campos from jsonb_each(p_despues)
      where key not in ('documentos','tablas','recursos') and value is distinct from p_antes->key;
    v_resultado:=jsonb_build_object('version',1,'campos',v_campos);
    foreach v_nombre in array array['documentos','tablas','recursos'] loop
        if p_antes->v_nombre is not distinct from p_despues->v_nombre then continue; end if;
        v_id:=case v_nombre when 'documentos' then 'Id' when 'tablas' then 'Nombre' else 'Referencia' end;
        select coalesce(jsonb_agg(e.value order by e.ord),'[]'::jsonb) into v_poner
          from jsonb_array_elements(p_despues->v_nombre) with ordinality e(value,ord)
          where not exists(select 1 from jsonb_array_elements(p_antes->v_nombre) a
            where a->>v_id=e.value->>v_id and a=e.value);
        select coalesce(jsonb_agg(e->v_id),'[]'::jsonb) into v_quitar from jsonb_array_elements(p_antes->v_nombre) e
          where not exists(select 1 from jsonb_array_elements(p_despues->v_nombre) d where d->>v_id=e->>v_id);
        select coalesce(jsonb_agg(e.value->v_id order by e.ord),'[]'::jsonb) into v_orden
          from jsonb_array_elements(p_despues->v_nombre) with ordinality e(value,ord);
        v_resultado:=v_resultado||jsonb_build_object(v_nombre,jsonb_build_object('poner',v_poner,'quitar',v_quitar,'orden',v_orden));
    end loop;
    return v_resultado;
end $$;
grant execute on function qa.crear_cambios(jsonb,jsonb) to authenticated;
create table qa.deltas as select a.nombre desde,b.nombre hasta,qa.crear_cambios(a.contenido,b.contenido) cambios
    from qa.paquetes_compactos a cross join qa.paquetes_compactos b
    where a.nombre in ('baseline','nombre','descripcion','especificacion')
      and b.nombre in ('baseline','nombre','descripcion','especificacion','acu_precio');
grant select on qa.deltas to authenticated;
select qa.exige(not exists(select 1 from qa.deltas d
    join qa.paquetes_compactos a on a.nombre=d.desde join qa.paquetes_compactos b on b.nombre=d.hasta
    where myg_nube_privado.aplicar_cambios(a.contenido,d.cambios)<>b.contenido),
    'Incremental: diferencias reconstruyen exactamente todos los fixtures');
select qa.exige((select octet_length(cambios::text)<octet_length(p.contenido::text)
    from qa.deltas d join qa.paquetes_compactos p on p.nombre=d.hasta where desde='baseline' and hasta='nombre'),
    'Incremental: renombrar transmite menos bytes que publicar toda la base');

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_capacidades()->'cambios'='1'::jsonb,
    'Incremental: capacidades anuncian cambios versión uno');
select public.myg_nube_crear('70000000-0000-0000-0000-000000000001','Incremental QA',
    (select contenido from qa.paquetes_compactos where nombre='baseline'),'obra');
select qa.exige(public.myg_nube_revision('70000000-0000-0000-0000-000000000001')->>'revision'='1'
    and not public.myg_nube_revision('70000000-0000-0000-0000-000000000001')?'contenido'
    and public.myg_nube_revision('70000000-0000-0000-0000-000000000001')?'permisos_modulos',
    'Incremental: consultar revisión mantiene permisos sin descargar contenido');
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000001',1,
    (select cambios from qa.deltas where desde='baseline' and hasta='nombre'))=
    '{"estado":"aplicada","revision":2,"operacion_id":"71000000-0000-0000-0000-000000000001"}'::jsonb,
    'Incremental: ACK confirma revisión sin duplicar contenido');
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000001',1,
    (select cambios from qa.deltas where desde='baseline' and hasta='nombre'))->>'revision'='2',
    'Incremental: repetir UUID confirma sin aplicar dos veces');
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000001',1,
    (select cambios from qa.deltas where desde='baseline' and hasta='descripcion'))$$,
    '22023','Incremental: UUID no acepta otro cuerpo');
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000002',2,
    (select cambios from qa.deltas where desde='nombre' and hasta='descripcion'))->>'revision'='3',
    'Incremental: siguiente colaborador aplica desde revisión confirmada');
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000001',1,
    (select cambios from qa.deltas where desde='baseline' and hasta='nombre'))->>'revision'='2',
    'Incremental: ACK antiguo no cambia con revisiones posteriores');
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000003',1,
    (select cambios from qa.deltas where desde='baseline' and hasta='acu_precio'))->>'estado'='conflicto',
    'Incremental: revisión antigua produce conflicto sin sobrescribir');
select public.myg_nube_compartir_usuario('70000000-0000-0000-0000-000000000001','editor','editor',
    '{"acu":false,"especificaciones":true,"metrados_excel":false}');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000004',3,
    (select cambios from qa.deltas where desde='descripcion' and hasta='acu_precio'))$$,
    '42501','Incremental: modificación ACU sigue protegida en servidor');
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000005',3,
    (select cambios from qa.deltas where desde='descripcion' and hasta='especificacion'))->>'revision'='4',
    'Incremental: permite exclusivamente el módulo habilitado');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000003',1,
    (select cambios from qa.deltas where desde='baseline' and hasta='acu_precio'))->>'revision'='3',
    'Incremental: conflicto histórico conserva snapshot y revisión originales');
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',gen_random_uuid(),4,
    '{"version":1,"campos":{"version":1}}')$$,'22023','Incremental: no permite degradar formato');
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',gen_random_uuid(),4,
    '{"version":1,"campos":{"alcance":"base"}}')$$,'22023','Incremental: no amplía alcance compartido');
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',gen_random_uuid(),4,
    '{"version":1,"campos":{"desconocido":true}}')$$,'22023','Incremental: rechaza campos desconocidos');
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',gen_random_uuid(),4,
    '{"version":1,"campos":{},"tablas":{"poner":[],"quitar":[],"orden":[]}}')$$,
    '22023','Incremental: no pierde tablas omitidas de un orden malformado');
select public.myg_nube_rol('70000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',null);
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',
    '71000000-0000-0000-0000-000000000005',3,
    (select cambios from qa.deltas where desde='descripcion' and hasta='especificacion'))$$,
    '42501','Incremental: revocación bloquea incluso reintento confirmado');
select qa.rechaza($$select public.myg_nube_revision('70000000-0000-0000-0000-000000000001')$$,
    '42501','Incremental: revisión no revela metadatos a miembro revocado');
reset role;
select qa.exige((select revision=4 and contenido=(select contenido from qa.paquetes_compactos where nombre='especificacion')
    from public.myg_nube_proyectos where id='70000000-0000-0000-0000-000000000001')
    and (select count(*)=3 from myg_nube_privado.historial_cambios where proyecto_id='70000000-0000-0000-0000-000000000001')
    and (select count(*)=1 from public.myg_nube_historial where proyecto_id='70000000-0000-0000-0000-000000000001'),
    'Incremental: rechazos y reintentos no añaden revisiones ni snapshots completos');
select qa.exige(myg_nube_privado.reconstruir_revision('70000000-0000-0000-0000-000000000001',2)=
    (select contenido from qa.paquetes_compactos where nombre='nombre')
    and myg_nube_privado.reconstruir_revision('70000000-0000-0000-0000-000000000001',4)=
    (select contenido from qa.paquetes_compactos where nombre='especificacion'),
    'Incremental: historial reconstruye revisiones anteriores con deltas');

-- Cruzar un checkpoint y comprobar que la recuperación usa el snapshot más cercano.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
do $checkpoints$
declare v_revision bigint:=4; v_respuesta jsonb;
begin
    while v_revision<22 loop
        v_respuesta:=public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000001',gen_random_uuid(),v_revision,
            jsonb_build_object('version',1,'campos',jsonb_build_object('avisos',jsonb_build_array('Edición '||(v_revision+1)::text))));
        if v_respuesta->>'estado'<>'aplicada' then raise exception 'No se aplicó checkpoint'; end if;
        v_revision:=v_revision+1;
    end loop;
end $checkpoints$;
reset role;
select qa.exige((select count(*)=2 from public.myg_nube_historial where proyecto_id='70000000-0000-0000-0000-000000000001')
    and myg_nube_privado.reconstruir_revision('70000000-0000-0000-0000-000000000001',20)#>>'{avisos,0}'='Edición 20'
    and myg_nube_privado.reconstruir_revision('70000000-0000-0000-0000-000000000001',22)=
      (select contenido from public.myg_nube_proyectos where id='70000000-0000-0000-0000-000000000001'),
    'Incremental: checkpoints periódicos conservan recuperación íntegra');
-- Rutas permiten cambiar una sola celda o un nombre sin reenviar su documento.
create table qa.rutas_delta as select
    jsonb_build_object('version',2,'operaciones',jsonb_build_array(jsonb_build_object(
        'ruta',jsonb_build_array('documento','Nombre'),'valor','Renombrado mínimo'))) cambios,
    jsonb_set(contenido,'{documento,Nombre}','"Renombrado mínimo"') esperado,
    contenido anterior from qa.paquetes_compactos where nombre='baseline';
grant select on qa.rutas_delta to authenticated;
select qa.exige((select myg_nube_privado.aplicar_cambios(anterior,cambios)=esperado
    and octet_length(cambios::text)<512 from qa.rutas_delta),
    'Incremental: edición puntual se transmite en menos de 512 bytes');
select qa.exige((select myg_nube_privado.aplicar_cambios(anterior,
    '{"version":2,"operaciones":[{"ruta":["avisos"],"valor":["nuevo", "otro"]}]}')#>'{avisos}'='["nuevo","otro"]'::jsonb
    from qa.rutas_delta),'Incremental: cambio de longitud reemplaza la lista completa');
do $rutas_invalidas$
declare v jsonb; n integer:=0;
begin
    foreach v in array array[
        '{"version":2,"operaciones":{},"otro":1}',
        '{"version":2,"operaciones":[{"ruta":[],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["oculto"],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["documento",0],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["avisos","-1"],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","Presupuestos","00"],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","Presupuestos","99999999999"],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","Presupuestos","0"],"quitar":true}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","NoExiste","x"],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","Nombre","x"],"valor":1}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","NoExiste"],"quitar":true}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","Nombre"],"quitar":false}]}',
        '{"version":2,"operaciones":[{"ruta":["documento","Nombre"],"quitar":true,"valor":null}]}'
    ]::jsonb[] loop
        n:=n+1;
        perform qa.rechaza(format('select myg_nube_privado.aplicar_cambios((select anterior from qa.rutas_delta),%L::jsonb)',v),
            '22023','Incremental: ruta inválida '||n::text||' se rechaza');
    end loop;
end $rutas_invalidas$;
select qa.rechaza($$select myg_nube_privado.aplicar_cambios((select anterior from qa.rutas_delta),
    jsonb_build_object('version',2,'operaciones',(select jsonb_agg('{"ruta":["avisos"],"valor":[]}'::jsonb)
      from generate_series(1,4097))))$$,'22023','Incremental: límite de 4096 operaciones evita trabajo ilimitado');

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_nube_crear('70000000-0000-0000-0000-000000000002','Rutas QA',
    (select anterior from qa.rutas_delta),'obra');
select public.myg_nube_compartir_usuario('70000000-0000-0000-0000-000000000002','editor','editor',
    '{"acu":false,"especificaciones":true,"metrados_excel":false}');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000002',gen_random_uuid(),1,
    '{"version":2,"operaciones":[{"ruta":["documento","Presupuestos","0","Items","0","Costos","PrecioDirecto"],"valor":999}]}')$$,
    '42501','Incremental: rutas no eluden permisos de ACU');
select qa.exige(public.myg_nube_guardar_cambios('70000000-0000-0000-0000-000000000002',
    '72000000-0000-0000-0000-000000000001',1,(select cambios from qa.rutas_delta))->>'revision'='2',
    'Incremental: RPC aplica ruta mínima con revisión y permisos vigentes');
reset role;
select qa.exige(myg_nube_privado.reconstruir_revision('70000000-0000-0000-0000-000000000002',2)=
    (select esperado from qa.rutas_delta),'Incremental: historial reconstruye también cambios por rutas');
select format('PRUEBAS INCREMENTAL COMPLETADAS: %s',count(*)) from qa.resultados where descripcion like 'Incremental:%';
