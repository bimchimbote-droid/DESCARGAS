using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class SincronizacionIncrementalCheck
{
    private const string Servidor = "https://incremental.supabase.co";
    private const string Clave = "sb_publishable_pruebas_incrementales";
    private static readonly Guid ProyectoId = Guid.Parse("71111111-1111-4111-8111-111111111111");
    private static readonly Guid UsuarioA = Guid.Parse("72222222-2222-4222-8222-222222222222");
    private static readonly Guid UsuarioB = Guid.Parse("73333333-3333-4333-8333-333333333333");
    private static int comprobaciones;

    public static async Task RunAsync()
    {
        comprobaciones = 0;
        await SinCambiosSinDescarga();
        await AckPerdidoYReapertura();
        await DosUsuariosConConflicto();
        await RevocacionSinCambioRevision();
        await CatalogoNativoSinCambioDocumento();
        await ConsultaDeModuloBloqueado();
        Console.WriteLine($"OK Sincronización incremental: 6 casos y {comprobaciones} comprobaciones SQLite + HTTP simulado.");
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Sincronización incremental: " + detalle);
    }

    private static async Task SinCambiosSinDescarga()
    {
        using var prueba = await Escenario.Crear();
        var resultado = await prueba.Sincronizar();
        Exige(resultado.Vinculo.Revision == 1 && resultado.Vinculo.Pendiente is null,
            "una copia limpia creó una operación o cambió de revisión.");
        Exige(prueba.Http.ConsultasRevision >= 1 && prueba.Http.LecturasCompletas == 0,
            "consultar la misma revisión descargó el paquete completo.");
        Exige(prueba.Http.Escrituras.Count == 0, "una sincronización limpia publicó cambios.");
        await prueba.Sincronizar();
        Exige(prueba.Http.ConsultasRevision >= 2 && prueba.Http.LecturasCompletas == 0 && prueba.Http.Escrituras.Count == 0,
            "repetir la sincronización limpia descargó o volvió a publicar la base.");
    }

    private static async Task AckPerdidoYReapertura()
    {
        using var prueba = await Escenario.Crear();
        prueba.Editar("Cambio incremental A");
        Guid operacion = prueba.LeerVinculo().Pendiente.Id;
        prueba.Http.PerderSiguienteAck = true;
        bool fallo = false;
        try { await prueba.Sincronizar(); }
        catch (NubeException ex) { fallo = ex.EsErrorDeConexion; }
        Exige(fallo, "la pérdida del ACK no se comunicó como desconexión.");
        var pendiente = prueba.LeerVinculo().Pendiente;
        Exige(pendiente is { Enviada: true } && pendiente.Id == operacion && !string.IsNullOrWhiteSpace(pendiente.JsonCambios),
            "el envío incremental no congeló su UUID y diferencia antes de perder el ACK.");
        Exige(prueba.Estado.Revision == 2 && prueba.Http.Escrituras.Count == 1,
            "el servidor no confirmó exactamente una operación antes del corte.");
        string diferencia = pendiente!.JsonCambios;
        string contenido = pendiente.JsonContenido;
        byte[] primerEnvio = prueba.Http.Escrituras.Single();
        prueba.Documento = prueba.LeerDocumento();
        prueba.Editar("Borrador posterior B");
        pendiente = prueba.LeerVinculo().Pendiente;
        Exige(pendiente.Id == operacion && pendiente.JsonContenido == contenido && pendiente.JsonCambios == diferencia,
            "reabrir SQLite y editar alteró el cuerpo que espera confirmación.");
        var resultado = await prueba.Sincronizar();
        Exige(prueba.Http.Escrituras.Count == 2 && primerEnvio.SequenceEqual(prueba.Http.Escrituras[1]),
            "reintentar modificó los bytes de la solicitud o su UUID.");
        Exige(resultado.Vinculo.Revision == 2 && resultado.Documento.Nombre == "Borrador posterior B",
            "un ACK antiguo sustituyó el borrador posterior.");
        Exige(resultado.Vinculo.Pendiente != null && resultado.Vinculo.Pendiente.Id != operacion
            && resultado.Vinculo.Pendiente.RevisionBase == 2,
            "el borrador posterior no quedó pendiente con nueva identidad y revisión base.");
        resultado = await prueba.Sincronizar();
        Exige(resultado.Vinculo.Revision == 3 && resultado.Vinculo.Pendiente is null
            && PaqueteNube.LeerDocumento(prueba.Estado.Paquete).Nombre == "Borrador posterior B",
            "la segunda edición incremental no terminó confirmada.");
    }

    private static async Task DosUsuariosConConflicto()
    {
        using var primera = await Escenario.Crear();
        using var segunda = await Escenario.Crear(primera.Estado, UsuarioB);
        primera.Editar("Cambio del primer colaborador");
        segunda.Editar("Trabajo pendiente del segundo colaborador");
        Guid segundoId = segunda.LeerVinculo().Pendiente.Id;
        await primera.Sincronizar();
        var resultado = await segunda.Sincronizar();
        Exige(primera.Estado.Revision == 2 && PaqueteNube.LeerDocumento(primera.Estado.Paquete).Nombre == "Cambio del primer colaborador",
            "un cliente con revisión anterior sobrescribió el cambio del primer usuario.");
        Exige(resultado.Documento.Nombre == "Trabajo pendiente del segundo colaborador"
            && segunda.LeerDocumento().Nombre == resultado.Documento.Nombre,
            "el conflicto borró el trabajo local del segundo usuario.");
        var vinculo = segunda.LeerVinculo();
        Exige(vinculo.Pendiente?.Id == segundoId && vinculo.Revision == 1 && vinculo.RevisionRemotaConflicto == 2
            && !string.IsNullOrWhiteSpace(vinculo.JsonPaqueteConflicto),
            "el conflicto no conservó el UUID pendiente y la revisión remota de forma durable.");
        Exige(primera.Estado.Aplicadas == 1, "el conflicto contó como una segunda operación aplicada.");
    }

    private static async Task RevocacionSinCambioRevision()
    {
        using var prueba = await Escenario.Crear();
        prueba.Http.Rol = "lector";
        var resultado = await prueba.Sincronizar(soloLeer: true);
        Exige(resultado.Vinculo.Revision == 1 && prueba.LeerVinculo().Rol == "lector"
            && prueba.Http.LecturasCompletas == 0,
            "consultar sólo la revisión omitió el cambio de rol o descargó la base sin necesidad.");
        prueba.Http.Rol = "editor";
        await prueba.Sincronizar(soloLeer: true);
        prueba.Documento.Presupuestos[0].Items[0].Costos.EspecificacionTexto = "Cambio antes de revocar el módulo";
        MYGColaboracionLocal.Guardar(prueba.Ruta, prueba.Documento, prueba.LeerVinculo());
        var antes = prueba.LeerVinculo().Pendiente;
        prueba.Http.Permisos = new() { Especificaciones = false };
        bool rechazo = false;
        try { await prueba.Sincronizar(); }
        catch (NubeException) { rechazo = true; }
        var despues = prueba.LeerVinculo();
        Exige(rechazo && prueba.Http.Escrituras.Count == 0 && prueba.Estado.Revision == 1,
            "el cambio de permisos con igual revisión permitió publicar el módulo bloqueado.");
        Exige(despues.PermisosModulos is { Especificaciones: false } && despues.Pendiente?.Id == antes.Id
            && despues.Pendiente.JsonContenido == antes.JsonContenido && !despues.Pendiente.Enviada,
            "el rechazo perdió el pendiente o no persistió el nuevo permiso.");
        prueba.Http.Permisos = new();
        prueba.Http.Revocado = true;
        rechazo = false;
        try { await prueba.Sincronizar(); }
        catch (NubeException ex) { rechazo = ex.AccesoDenegado; }
        Exige(rechazo && prueba.LeerVinculo().EstadoConexion == "acceso retirado"
            && prueba.LeerVinculo().Pendiente.Id == antes.Id && prueba.Http.Escrituras.Count == 0,
            "la consulta de revisión no detectó la retirada de acceso o eliminó el pendiente.");
    }

    private static async Task CatalogoNativoSinCambioDocumento()
    {
        using var prueba = await Escenario.Crear();
        string firma = MYGProyectoStorage.Firma(prueba.Documento);
        prueba.Sql("UPDATE propietario SET nombre_propietario='Catálogo cambiado sin editar el documento' WHERE id_propietario=$id",
            prueba.Documento.Datos.PropietarioId);
        Exige(MYGProyectoStorage.Firma(prueba.LeerDocumento()) == firma && prueba.LeerVinculo().Pendiente is null,
            "la preparación del catálogo alteró el documento o creó un pendiente artificial.");
        var resultado = await prueba.Sincronizar();
        Exige(resultado.Vinculo.Revision == 2 && resultado.Vinculo.Pendiente is null && prueba.Http.Escrituras.Count == 1,
            "no detectó y confirmó la edición exclusiva del catálogo nativo.");
        JsonElement expandido = FormatoPaqueteNube.Expandir(prueba.Estado.Paquete);
        var tabla = expandido.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>()!.Single(x => x.Nombre == "propietario");
        int columna = tabla.Columnas.IndexOf("nombre_propietario");
        Exige(tabla.Filas.Any(f => f[columna].Valor == "Catálogo cambiado sin editar el documento"),
            "el paquete confirmado perdió la modificación nativa.");
        using var envio = JsonDocument.Parse(prueba.Http.Escrituras.Single());
        var cambios = envio.RootElement.GetProperty("p_cambios");
        bool CambioTabla(string nombre)
        {
            if (cambios.GetProperty("version").GetInt32() == 1)
                return cambios.GetProperty("tablas").GetProperty("poner").EnumerateArray()
                    .Any(t => t.GetProperty("Nombre").GetString() == nombre);
            return cambios.GetProperty("operaciones").EnumerateArray().Any(op =>
            {
                var ruta = op.GetProperty("ruta");
                return ruta.GetArrayLength() >= 2 && ruta[0].GetString() == "tablas"
                    && int.TryParse(ruta[1].GetString(), out int indice)
                    && prueba.Estado.Paquete.GetProperty("tablas")[indice].GetProperty("Nombre").GetString() == nombre;
            });
        }
        Exige(!envio.RootElement.TryGetProperty("p_contenido", out _) && CambioTabla("propietario"),
            "la edición del catálogo se envió como una base completa o sin la tabla cambiada.");
        Exige(!CambioTabla("departamento"),
            "la diferencia retransmitió un catálogo geográfico sin cambios.");
        int envios = prueba.Http.Escrituras.Count;
        await prueba.Sincronizar();
        Exige(prueba.Http.Escrituras.Count == envios && prueba.Estado.Revision == 2,
            "repetir una sincronización de catálogo produjo un cambio fantasma.");
    }

    private static async Task ConsultaDeModuloBloqueado()
    {
        using var primera = await Escenario.Crear();
        using var segunda = await Escenario.Crear(primera.Estado, UsuarioB);
        segunda.Http.Permisos = new() { Especificaciones = false };
        await segunda.Sincronizar(soloLeer: true);
        primera.Documento.Presupuestos[0].Items[0].Costos.EspecificacionTexto = "Especificación remota autorizada";
        MYGColaboracionLocal.Guardar(primera.Ruta, primera.Documento, primera.LeerVinculo());
        await primera.Sincronizar();
        var resultado = await segunda.Sincronizar(soloLeer: true);
        Exige(resultado.Vinculo.Revision == 2 && resultado.Vinculo.Pendiente is null
            && resultado.Documento.Presupuestos[0].Items[0].Costos.EspecificacionTexto == "Especificación remota autorizada",
            "un módulo de sólo lectura no recibió su revisión nueva.");
        Exige(segunda.LeerDocumento().Presupuestos[0].Items[0].Costos.EspecificacionTexto == "Especificación remota autorizada"
            && segunda.LeerVinculo().PermisosModulos is { Especificaciones: false },
            "el pull no persistió juntos los datos y los permisos actuales.");
        Exige(segunda.Http.Escrituras.Count == 0 && segunda.Http.LecturasCompletas >= 1,
            "la descarga por revisión nueva publicó contenido como lector.");
    }

    private sealed class Escenario : IDisposable
    {
        private readonly string directorio = Path.Combine(Path.GetTempPath(), "myg-incremental-" + Guid.NewGuid().ToString("N"));
        public string Ruta { get; }
        public MYGProyectoDocumento Documento { get; set; }
        public EstadoServidor Estado { get; }
        public ServidorSimulado Http { get; }
        public ClienteSupabase Cliente { get; }

        private Escenario(EstadoServidor? compartido, Guid usuario)
        {
            Directory.CreateDirectory(directorio);
            Ruta = Path.Combine(directorio, "trabajo.sqlite");
            if (compartido is null)
            {
                Documento = MYGProyectoStorage.Nuevo("Proyecto incremental inicial", "Estructuras");
                Documento.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
                {
                    Id = MYGProyectoStorage.NuevoId(), IdLocalMYG = MYGProyectoStorage.NuevoId(),
                    Descripcion = "Partida compartida", Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
                    Costos = new MYGDatosPartida { EspecificacionTexto = "Especificación inicial" }
                });
                MYGProyectoStorage.Guardar(Ruta, Documento);
                var propietario = MYGCatalogosProyecto.Guardar(Ruta, MYGCatalogoProyecto.Propietarios, "Propietario compartido inicial");
                Documento.Datos = MYGDatosProyecto.Crear();
                Documento.Datos.PropietarioId = propietario.Id;
                Documento.Datos.Propietario = propietario.Nombre;
                MYGProyectoStorage.Guardar(Ruta, Documento);
                Estado = new EstadoServidor(FormatoPaqueteNube.Compactar(PaqueteNube.CrearContenido(Documento, Ruta)));
            }
            else
            {
                Estado = compartido;
                PaqueteNube.Descargar(Estado.Paquete, Ruta);
                Documento = MYGBaseDatos.LeerProyecto(Ruta, PaqueteNube.LeerDocumento(Estado.Paquete).Id);
            }
            Http = new ServidorSimulado(Estado, usuario);
            Cliente = new ClienteSupabase(Servidor, Clave, Http);
            MYGColaboracionLocal.Vincular(Ruta, Documento, new MYGVinculoNube
            {
                ProyectoId = ProyectoId, Servidor = Servidor, UsuarioId = usuario.ToString("D"), Rol = "editor",
                PermisosModulos = new(), Revision = Estado.Revision,
                JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(Documento), JsonPaqueteConfirmado = Estado.Paquete.GetRawText()
            });
        }

        public static async Task<Escenario> Crear(EstadoServidor? estado = null, Guid? usuario = null)
        {
            var prueba = new Escenario(estado, usuario ?? UsuarioA);
            try { await prueba.Cliente.IniciarSesionAsync("prueba@myg.example", "contraseña_sintética"); return prueba; }
            catch { prueba.Dispose(); throw; }
        }

        public void Editar(string nombre)
        {
            Documento.Nombre = nombre;
            MYGColaboracionLocal.Guardar(Ruta, Documento, LeerVinculo());
        }

        public async Task<ResultadoSincronizacion> Sincronizar(bool soloLeer = false)
        {
            var resultado = await SincronizadorProyectoNube.EjecutarAsync(Cliente, Ruta, Documento, soloLeer);
            Documento = resultado.Documento;
            return resultado;
        }

        public MYGVinculoNube LeerVinculo() => MYGColaboracionLocal.Leer(Ruta, Documento.Id);
        public MYGProyectoDocumento LeerDocumento() => MYGBaseDatos.LeerProyecto(Ruta, Documento.Id);

        public void Sql(string sql, string id)
        {
            using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = Ruta, Pooling = false }.ToString());
            conexion.Open(); using var cmd = conexion.CreateCommand(); cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("$id", id); cmd.ExecuteNonQuery();
        }

        public void Dispose()
        {
            Cliente.Dispose(); SqliteConnection.ClearAllPools(); Directory.Delete(directorio, true);
        }
    }

    private sealed class EstadoServidor(JsonElement inicial)
    {
        public JsonElement Paquete { get; set; } = inicial.Clone();
        public long Revision { get; set; } = 1;
        public int Aplicadas { get; set; }
        public Dictionary<(Guid Usuario, Guid Operacion), (byte[] Solicitud, JsonElement Respuesta)> Confirmaciones { get; } = new();
    }

    private sealed class ServidorSimulado(EstadoServidor estado, Guid usuario) : HttpMessageHandler
    {
        public string Rol { get; set; } = "editor";
        public MYGPermisosModulos Permisos { get; set; } = new();
        public bool Revocado { get; set; }
        public bool PerderSiguienteAck { get; set; }
        public int ConsultasRevision { get; private set; }
        public int LecturasCompletas { get; private set; }
        public List<byte[]> Escrituras { get; } = new();

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            Exige(request.Headers.TryGetValues("apikey", out var claves) && claves.Single() == Clave,
                "falta la clave publicable del escenario.");
            string ruta = request.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token")
                return Respuesta(new { access_token = "token_incremental", refresh_token = "refresh_incremental", expires_in = 3600, user = new { id = usuario } });
            Exige(request.Headers.Authorization?.Scheme == "Bearer" && request.Headers.Authorization.Parameter == "token_incremental",
                "no se usó la identidad autenticada.");
            if (ruta == "/rest/v1/rpc/myg_nube_capacidades") return Respuesta(new { paquete_compacto = 2, cambios = 1 });
            if (Revocado) return Respuesta(new { code = "42501", message = "Acceso revocado" }, HttpStatusCode.Forbidden);
            if (ruta is "/rest/v1/rpc/myg_nube_revision" or "/rest/v1/rpc/myg_nube_abrir")
            {
                bool completa = ruta.EndsWith("myg_nube_abrir", StringComparison.Ordinal);
                if (completa) LecturasCompletas++; else ConsultasRevision++;
                var meta = JsonSerializer.SerializeToNode(new
                {
                    id = ProyectoId, codigo = "MYG-INC-001", nombre = "Proyecto incremental", rol = Rol,
                    revision = estado.Revision, alcance = "obra", permisos_modulos = Permisos
                })!.AsObject();
                if (completa) meta["contenido"] = JsonSerializer.SerializeToNode(estado.Paquete);
                return Respuesta(meta);
            }
            Exige(ruta == "/rest/v1/rpc/myg_nube_guardar_cambios", "el escenario incremental usó un endpoint inesperado: " + ruta);
            if (Rol is not ("propietario" or "administrador" or "editor"))
                return Respuesta(new { code = "42501", message = "Sólo lectura" }, HttpStatusCode.Forbidden);
            byte[] cuerpo = await request.Content!.ReadAsByteArrayAsync(ct);
            Escrituras.Add(cuerpo);
            using var solicitud = JsonDocument.Parse(cuerpo);
            Guid id = solicitud.RootElement.GetProperty("p_operacion").GetGuid();
            long revision = solicitud.RootElement.GetProperty("p_revision").GetInt64();
            var clave = (usuario, id);
            if (estado.Confirmaciones.TryGetValue(clave, out var anterior))
            {
                Exige(cuerpo.SequenceEqual(anterior.Solicitud), "se reutilizó UUID con otra solicitud.");
                return Respuesta(anterior.Respuesta);
            }
            JsonElement respuesta;
            if (revision != estado.Revision)
                respuesta = JsonSerializer.SerializeToElement(new
                { estado = "conflicto", revision = estado.Revision, contenido = estado.Paquete, operacion_id = id });
            else
            {
                estado.Paquete = CambiosPaqueteNube.Aplicar(estado.Paquete, solicitud.RootElement.GetProperty("p_cambios"));
                estado.Revision++; estado.Aplicadas++;
                respuesta = JsonSerializer.SerializeToElement(new { estado = "aplicada", revision = estado.Revision, operacion_id = id });
            }
            estado.Confirmaciones.Add(clave, (cuerpo, respuesta));
            if (PerderSiguienteAck)
            {
                PerderSiguienteAck = false;
                throw new HttpRequestException("Respuesta perdida después del commit incremental.");
            }
            return Respuesta(respuesta);
        }

        private static HttpResponseMessage Respuesta(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
