# MYG Presupuestos

Solución C# para Windows x64 y Revit 2027. Versión: MYG_PRESUPUESTOS_1, 6 de octubre de 2026.

La aplicación se ejecuta fuera de Revit. Permite preparar proyectos, partidas y filtros sin abrir un modelo. Para consultar parámetros del modelo y crear o actualizar tablas debe estar abierto Revit 2027 con el conector MYG instalado.

## Guardar el código junto a sus repositorios

Para trabajar desde su carpeta habitual, extraiga la carpeta completa `MYG.Presupuestos` en `D:\ADDIN\repos`. Abra `D:\ADDIN\repos\MYG.Presupuestos\MYG.Presupuestos.sln`. Conserve todas las carpetas de proyectos incluidas para poder editar y compilar cuantas veces necesite.

Las instrucciones detalladas están en [GUARDAR_Y_EDITAR.md](GUARDAR_Y_EDITAR.md). El ejecutable se llama `MYG.Presupuestos.exe`; la solución y los archivos C# constituyen el proyecto editable.

## Qué contiene

| Proyecto | Función |
| --- | --- |
| `MYG.Desktop` | Ejecutable Windows Forms: inicio de sesión, bases SQLite, proyectos, presupuestos, catálogos y filtros BIM. |
| `MYG.Core` | Persistencia SQLite, catálogos, análisis de costos unitarios (ACU), metrados, integración Delphin, biblioteca de filtros, licencia y protocolo. |
| `MYG.Revit2027` | Conector que recibe solicitudes y usa la API de Revit mediante `ExternalEvent`. |
| `MYG.Pruebas` | Comprobaciones de guardado, biblioteca, importación, licencia y protocolo. |
| `scripts` | Publicación, instalación y desinstalación del conector. |

El motor de tablas de Revit, el lector de Delphin y la biblioteca de filtros proceden de la entrega anterior. Los proyectos y sus presupuestos se guardan ahora dentro de una base `*.sqlite`; el soporte de proyectos JSON antiguos permanece en las API de compatibilidad, pero no se ofrece para crear o abrir proyectos en la interfaz.

## Opción A: usar la carpeta compilada

Si descargó el paquete `MYG_Aplicacion_Windows.zip`:

1. Extraiga todo su contenido en una carpeta estable de su PC, por ejemplo `C:\MYG\Presupuestos`.
2. Instale **.NET Desktop Runtime 10 x64** si no está instalado. El runtime incluido internamente en Revit puede no estar disponible para aplicaciones externas. Descarga oficial: <https://dotnet.microsoft.com/download/dotnet/10.0>.
3. Ejecute `MYG\MYG.Presupuestos.exe`. Mantenga junto al ejecutable todos los archivos de esa carpeta.
4. Ingrese su usuario y contraseña MYG. La licencia se verifica con su servicio actual.
5. Para trabajar sobre Revit, cierre Revit e instale el conector como se indica más adelante.

El paquete compilado depende del runtime instalado. El script `Publicar.ps1` del código fuente permite generar una distribución que incluye el runtime del programa de escritorio.

## Opción B: abrir y modificar en Visual Studio

### 1. Requisitos

- Windows x64.
- **Visual Studio 2026, versión 18.0 o posterior**, con la carga **Desarrollo de escritorio con .NET**.
- SDK **.NET 10**. `global.json` permite SDK 10 posteriores al 10.0.100.
- Revit **2027**, para compilar el conector contra las DLL instaladas y usarlo en el modelo.
- Internet para restaurar los paquetes NuGet y validar la licencia.

Microsoft especifica Visual Studio 2026 para desarrollar con .NET 10; Autodesk utiliza .NET 10 en Revit 2027. Fuentes: [Microsoft](https://learn.microsoft.com/dotnet/core/install/windows) y [Autodesk](https://help.autodesk.com/cloudhelp/2027/ENU/Revit-WhatsNew/files/GUID-8D7A4715-EAF8-4BD1-BE78-061F900D0BCE.htm).

### 2. Abrir la solución

1. Extraiga `MYG_Codigo_SQLite.zip` en una carpeta estable.
2. Abra `MYG.Presupuestos.sln` en Visual Studio.
3. Espere a que termine la restauración de NuGet. Si hace falta, clic derecho en la solución → **Restaurar paquetes NuGet**.
4. Clic derecho sobre **MYG.Desktop** → **Establecer como proyecto de inicio**.
5. Seleccione **Release / x64**.
6. Revise la ruta de Revit en `MYG.Revit2027\MYG.Revit2027.csproj`. El valor predeterminado es:

   ```xml
   <RevitInstallDir Condition="'$(RevitInstallDir)' == ''">C:\Program Files\Autodesk\Revit 2027</RevitInstallDir>
   ```

7. Menú **Compilar → Compilar solución**.
8. Presione **F5** para abrir la aplicación e ingresar con la licencia MYG.

Si aún no tiene Revit instalado, puede compilar únicamente `MYG.Desktop` con clic derecho → **Compilar**, o desde terminal:

```powershell
dotnet build .\MYG.Desktop\MYG.Desktop.csproj -c Release
dotnet run --project .\MYG.Desktop\MYG.Desktop.csproj -c Release
```

La interfaz está definida en C#; los archivos principales son `LoginForm.cs`, `InicioForm.cs`, `DatosProyectoForm.cs`, `EditorForm.cs` y `Tema.cs`.

### 3. Instalar el conector en Revit

1. Cierre todas las sesiones de Revit.
2. Compile `MYG.Revit2027` en **Release**, o use el conector del paquete compilado.
3. Abra PowerShell en la carpeta que contiene `scripts` y ejecute:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Instalar-Conector.ps1
   ```

4. El script copia el conector y sus dependencias a:

   ```text
   %APPDATA%\Autodesk\Revit\Addins\2027\MYG_Externo
   ```

   También genera `MYG_Conector_Externo.addin` en la carpeta `2027`. Se instala para su usuario de Windows.

5. Abra Revit 2027. Si Revit solicita autorización para cargar el complemento, revise su nombre y permita cargar **MYG Presupuestos - Conector Revit**.
6. Abra un modelo de proyecto. El conector se inicia en segundo plano; los botones están en la aplicación de escritorio.
7. En el editor MYG, pulse **Buscar Revit**. Elija la sesión correspondiente si hay varios Revit abiertos.

Ejecute MYG y Revit con el mismo usuario de Windows y el mismo nivel de permisos; normalmente ambos sin «Ejecutar como administrador». El canal local exige ese contexto. Documentación: [PipeOptions.CurrentUserOnly](https://learn.microsoft.com/dotnet/api/system.io.pipes.pipeoptions?view=net-10.0).

## Inicio de sesión y licencia MYG

La ventana de inicio de sesión valida el acceso con el servicio MYG del add-in actual.

- **Iniciar sesión** envía `usuario`, `clave` y `pc` al mismo servicio que utiliza su add-in.
- Se reutiliza el mismo cálculo del identificador de PC: `MachineGuid` y SHA-256; también se conserva el mecanismo alternativo del código anterior.
- **Usar ingreso automático MYG** lee el mismo archivo cifrado del add-in:

  ```text
  %LOCALAPPDATA%\MYG_Addin\sesion_automatica.dat
  ```

- El ingreso automático solo funciona si existe una sesión válida y su servicio MYG lo autoriza. Si el servidor lo rechaza, ingrese usuario y contraseña.
- **Guardar ingreso automático en esta PC** guarda únicamente el token que devuelve el servidor, cifrado con DPAPI para el usuario actual. La contraseña no se escribe en la base del proyecto ni en la biblioteca.
- La sesión del escritorio se revisa periódicamente. Si deja de ser válida se bloquea la edición; el proyecto abierto puede guardarse para conservar el trabajo.
- El conector comprueba la licencia antes de atender operaciones y mantiene una autorización temporal de hasta 45 segundos. Una operación ya iniciada en Revit debe finalizar para mantener la coherencia del modelo.
- Revit valida además que el documento activo sea el mismo que se seleccionó desde MYG.

`MYG.Core\ServidorLicencias.cs` contiene la URL existente extraída del código anterior. `LicenciaServicio.cs` implementa el protocolo. No se necesita crear otra hoja de licencias ni cambiar el Apps Script para esta integración.

La contraseña manual permanece en memoria durante la sesión y se transmite al conector por el canal local del mismo usuario de Windows cuando se necesita validar la licencia. Al cerrar la aplicación se descarta la sesión.

## Flujo de trabajo

Una base SQLite reúne varios proyectos y sus catálogos compartidos. Cada proyecto tiene su propia ficha de datos y puede contener varios presupuestos; cada presupuesto pertenece a un proyecto concreto. La ficha del proyecto se crea primero y los presupuestos se agregan después.

### Hoja en blanco

1. Inicie sesión y pulse **Crear archivo .sqlite**, en **Crear hoja en blanco**.
2. Elija un nombre nuevo y una ubicación para la base. Se crea una hoja sin proyectos ni presupuestos, con 12 unidades básicas: `und`, `m`, `m2`, `m3`, `kg`, `t`, `l`, `glb`, `hh`, `hm`, `día` y `mes`.
3. En la ventana principal pulse **Nuevo proyecto**. Complete la ficha **Datos del proyecto** con nombre, propietario, portafolio, tipo de obra, ubicación y los parámetros de duración y ejecución; pulse **Aceptar**. Se crea el proyecto sin presupuestos.
4. Seleccione un proyecto y pulse **Nuevo presupuesto**. Indique código y nombre para entrar al editor. **Abrir proyecto** también solicita el primer presupuesto si el proyecto todavía no tiene ninguno.
5. Cree otros presupuestos desde **Presupuestos → Nuevo presupuesto** y cambie entre ellos con el selector del editor.
6. Cree títulos y partidas con **+ Título** y **+ Partida**. Seleccione el título antes de añadir sus partidas; la unidad de cada partida se elige del catálogo de la base.
7. Prepare sus insumos, ACU, metrados y especificaciones. Puede reutilizar las partidas e insumos de los catálogos compartidos por todos los proyectos de esa base.
8. Configure las plantillas y los filtros BIM. Puede escribirlos sin Revit o consultar las listas del modelo después de conectarlo.
9. Pulse **Guardar**. Proyectos, presupuestos, catálogos y configuraciones BIM quedan dentro del mismo archivo `*.sqlite`, sin un JSON auxiliar de proyecto. Guardar una obra conserva las demás obras de la base.
10. Para volver a todas sus obras use **Proyecto → Volver a mis proyectos**; para retomar otro día use **Abrir archivo .sqlite** y seleccione el proyecto.

Las opciones laterales **Catálogo de partidas**, **Catálogo de insumos** y **Unidades** administran catálogos compartidos por los proyectos de esa base. Al crear o editar una partida o un insumo, elija su unidad de la lista del catálogo. Puede añadir unidades propias; las unidades en uso conservan su símbolo.

Las bases MYG anteriores se pueden abrir; el catálogo de unidades se incorpora al realizar una escritura. **Guardar copia del proyecto como...** guarda el proyecto seleccionado y los catálogos en otro `.sqlite`; no duplica todos los proyectos de la base.

### Datos del proyecto

La misma ficha sirve para crear el proyecto y para editarlo desde **Datos del proyecto** en la ventana principal o desde **Proyecto → Datos del proyecto** en el editor. Sus campos son:

| Grupo | Datos |
| --- | --- |
| Datos del proyecto | Nombre, propietario, portafolio y tipo de obra. |
| Ubicación | **Registrar ubicación** y selectores encadenados de departamento, provincia, distrito y localidad. |
| Duración | Fecha de elaboración, duración en días/semanas/meses, inicio y fin calculado. |
| Calendario y periodos | Calendario **Predeterminado** y periodos **Estándar**, con sus valores conservados al abrir un proyecto existente. |
| Modalidad de ejecución | **Por contrata** o **Administración directa**. |
| Cálculo de costos | **Por rendimiento de cuadrilla** o **Por asignación de recursos**, con una sola opción seleccionada. |
| Autor | **Hecho por**, tomado del usuario MYG al crear la ficha y conservado al editarla. |

El fin se recalcula al cambiar el inicio, la duración o su unidad, contando el primer día: un plazo de un día termina en la fecha de inicio. Las fechas pueden quedar sin registrar. El calendario, los periodos, la modalidad y el método de costos se guardan como parámetros del proyecto; esta ficha no crea un cronograma ni incorpora un motor adicional de planificación por asignación de recursos.

Los botones **+** permiten añadir propietarios, portafolios, tipos de obra, calendarios y opciones de ubicación. La provincia depende del departamento, el distrito de la provincia y la localidad del distrito. Las hojas nuevas incluyen la referencia geográfica pública de departamentos, provincias y distritos; no copian propietarios, usuarios ni localidades privadas de la base de muestra. En una base existente se utilizan sus propios catálogos.

La ventana principal muestra el propietario y el tipo de obra junto al nombre del proyecto. La búsqueda encuentra nombres, propietarios y tipos de obra; el selector de tipo de obra permite limitar la lista. Al guardar, la ficha y los presupuestos se conservan dentro del mismo `.sqlite`, en el documento MYG interno y en las columnas nativas correspondientes, sin un archivo JSON separado. Los metadatos nativos de proyectos existentes se conservan cuando no se modifica su ficha.

### Abrir una base existente

1. Pulse **Abrir archivo .sqlite** en la ventana inicial y seleccione una base MYG o Delphin 2024 reconocida.
2. La ventana principal muestra sus proyectos y la cantidad de presupuestos de cada uno. Seleccione uno y pulse **Abrir proyecto**, o haga doble clic sobre él.
3. Use los catálogos laterales y abra el presupuesto que desea trabajar.
4. Guarde los cambios en la base abierta. Al abrir directamente una base nativa de Delphin, el guardado escribe las tablas nativas correspondientes y añade las tablas complementarias MYG de versión 3 en el mismo SQLite.

La consulta de una base existente no la modifica. La muestra nativa de Delphin 2024 se leyó con sus 3 proyectos y 10 presupuestos; el guardado sin cambios se verificó sobre una copia, conservando los datos de sus 198 tablas originales. El esquema incluido en `MYG.Core\Delphin2024.sql` contiene las definiciones de tablas extraídas de esa muestra, sin datos de obras, usuarios ni credenciales. Estos controles no sustituyen la prueba de abrir y editar el resultado en el programa Delphin 2024 de Windows; esa compatibilidad todavía debe comprobarse allí.

Los ACU nativos importados conservan su árbol de composición cuando no se cambia el análisis. Si una composición compartida no puede modificarse sin afectar el análisis original, cree una copia de la partida según el mensaje del guardado. En el catálogo nativo, cambiar descripción, unidad o especificaciones conserva el árbol; para modificar su composición se guarda una entrada nueva con otro código. Las entradas nativas originales y las entradas en uso están protegidas frente a la eliminación.

### Importar desde otra base Delphin

1. Cree o abra primero una base MYG. En la ventana principal elija **Importar presupuesto Delphin**.
2. Seleccione la base SQLite de Delphin, proyecto y presupuesto.
3. Se crea un proyecto en la base MYG con el presupuesto seleccionado y su estructura. La base de origen Delphin se consulta sin modificarla.
4. Configure filtros, importe data antigua o traiga configuraciones de la biblioteca.
5. Guarde el proyecto MYG para conservar todas las configuraciones de sus presupuestos.

Para incluir otros presupuestos en el mismo archivo MYG, use **Presupuestos → Añadir presupuesto Delphin**. Puede alternar entre ellos mediante la lista de presupuestos. Cada proyecto y presupuesto MYG nuevo utiliza identificadores propios para el ámbito de sus tablas en Revit; las referencias oficiales Delphin se guardan por separado. Los proyectos existentes conservan los identificadores que ya tienen.

El botón **Importar presupuesto Delphin** consulta la base de origen en modo de lectura y guarda el trabajo en la base de destino; para editar una base nativa directamente utilice **Abrir archivo .sqlite**. En el editor, **Conectar Delphin / Reconciliar** permite vincular propuestas con un origen oficial. Revise las correspondencias: las vinculaciones conservan los filtros y la identidad local MYG; los códigos oficiales se toman de Delphin.

Esta integración utiliza SQLite; no contiene un conector a Microsoft SQL Server ni a S10.

### Reutilizar filtros en otros proyectos

1. Seleccione las partidas configuradas y pulse **Guardar filtros**. Puede guardar variantes para distintos usos de una misma partida.
2. Use **Biblioteca → Ver ubicación** para comprobar el archivo que se está utilizando.
3. En otra obra use la misma biblioteca mediante **Biblioteca → Elegir biblioteca existente**.
4. Pulse **Traer filtros** y revise las configuraciones propuestas. La identificación usa el origen de la base y el ID interno del análisis; un código visible repetido no es suficiente.
5. Para partidas libres sin referencia Delphin, elija la configuración manualmente y, si corresponde, recuerde la asociación.

La base `*.sqlite` guarda el trabajo de sus proyectos. La biblioteca heredada `*.biblioteca.json` sigue reuniendo configuraciones reutilizables de filtros y plantillas de presupuesto; es independiente del almacenamiento de proyectos y de los catálogos SQLite. Al cambiar los filtros de una obra, la biblioteca solo se modifica al guardar expresamente en ella.

### Importar el JSON antiguo

1. Abra o prepare las partidas de destino.
2. En la parte inferior izquierda, **Proyecto MYG → Cargar Data**.
3. Seleccione el JSON antiguo que contiene la lista de configuraciones.
4. Revise las coincidencias y complete manualmente las ambiguas.
5. Aplique y guarde el proyecto. Para reutilizar lo importado en otras obras, seleccione esas partidas y pulse **Guardar filtros**.

**Cargar Data** importa configuraciones antiguas; para abrir el trabajo actual utilice **Abrir archivo .sqlite** y después **Abrir proyecto**.

### Crear y actualizar tablas en Revit

1. Abra un modelo en Revit 2027 con sus tablas base de planificación. Se reconocen tablas de planificación cuyo nombre comienza por **PLANTILLA**, según el motor anterior.
2. En MYG pulse **Buscar Revit**; las listas de plantillas, parámetros y reglas se toman de ese modelo.
3. Configure cada partida. Use **+ Filtro / − Filtro** para trabajar con uno a ocho filtros. Un doble clic en una celda **Valor** permite consultar valores del modelo; también puede escribirlos.
4. Pulse **Revisar Revit** y corrija las alertas.
5. Pulse **Crear tablas** para sincronizar las tablas MYG de todo el presupuesto activo. Confirme el alcance que muestra la ventana.
6. Para trabajar sobre unas partidas concretas, selecciónelas y use **Actualizar selección**.
7. Revise el resumen que aparece dentro de Revit y los resultados que devuelve MYG. Una revisión válida no garantiza que toda creación posterior se haya completado.

Crear o actualizar tablas guarda primero el proyecto MYG para conservar sus identificadores y la configuración enviada. Si todavía no tiene un archivo, se solicita su ubicación; cancelar el guardado cancela el envío a Revit.

El motor conserva sus comprobaciones, filtros tipados, transacciones, identificación de tablas MYG y confirmaciones sobre tablas anteriores. Si el modelo activo cambia, la solicitud se rechaza; active el modelo previsto y vuelva a conectar. Si la conexión se interrumpe después de enviar una operación, compruebe Revit antes de repetirla.

## Generar una distribución con runtime incluido

Desde la carpeta de la solución, con Revit 2027 instalado:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Publicar.ps1
```

Si Revit está en otra ubicación:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Publicar.ps1 -RevitInstallDir 'D:\Autodesk\Revit 2027'
```

Se genera `dist`, con `MYG\MYG.Presupuestos.exe`, el conector, scripts e instrucciones. Distribuya esa carpeta completa. La publicación de escritorio incluye .NET; Revit sigue siendo necesario en la PC donde se modificarán tablas.

## Generar un instalador para usuarios

La solución incluye `instalador\MYG.Presupuestos.iss` y `scripts\Generar-Instalador.ps1`. Instale Inno Setup desde <https://jrsoftware.org/isdl.php> y siga [GUIA_INSTALADOR.md](GUIA_INSTALADOR.md).

Desde la carpeta de la solución en Windows:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1
```

Se publican el escritorio con .NET incluido y el conector, y se genera `dist\Instalador\MYG_Presupuestos_Setup_1.0.0.exe`. La configuración del instalador incluye accesos directos y el conector opcional de Revit 2027. El archivo Setup debe compilarse y probarse en Windows; no se incluye aquí un instalador ya compilado.

## Verificación y límites

La actualización de publicaciones compactas y sincronización incremental está
documentada en [Optimización de Nube MYG](supabase/LEEME_OPTIMIZACION_NUBE.md).
Incluye el orden de las migraciones Supabase, la actualización del cliente y la
recuperación del intento anterior que excedía el límite de tamaño.

Las comprobaciones efectuadas están descritas en `VERIFICACION.md`. La compilación y las pruebas de datos/protocolo no sustituyen la prueba en su PC: faltan la ejecución visual en Windows, una sesión real de licencia MYG y la creación de tablas en un modelo real de Revit 2027.

La interfaz cubre fichas de proyectos, varios presupuestos por proyecto, títulos, partidas, catálogos, precios y ACU, metrados manuales/Excel/BIM, especificaciones, resumen de costos, filtros y conexión al motor de tablas. Permite exportar libros **XLSX** e imprimir el presupuesto. El guardado SQLite incluye tablas nativas de Delphin y datos MYG; falta validar el archivo resultante dentro de Delphin 2024 en Windows. La integración con S10 permanece fuera de esta entrega.

Para ejecutar las pruebas incluidas:

```powershell
dotnet run --project .\MYG.Pruebas\MYG.Pruebas.csproj -c Release
```

Las pruebas normales generan archivos sintéticos temporales y usan un índice temporal separado de sus proyectos recientes. Opcionalmente puede comprobar el JSON antiguo usado durante el desarrollo indicando su ruta:

```powershell
$env:MYG_QA_LEGACY_JSON = 'C:\SuCarpeta\EXTERIORES.json'
dotnet run --project .\MYG.Pruebas\MYG.Pruebas.csproj -c Release
Remove-Item Env:\MYG_QA_LEGACY_JSON
```

Esa prueba opcional utiliza la estructura concreta de ese archivo: 220 filas y 94 configuraciones BIM. El JSON de la obra no está incluido en la distribución.

Para desinstalar únicamente el conector externo, cierre Revit y ejecute `scripts\Desinstalar-Conector.ps1`.
