-- SOLO PostgreSQL desechable, con fixture usuarios_myg_roles.sql y migración 26.
-- Nunca ejecutar este archivo sobre una cuenta Supabase real.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren una base desechable.'; end $$;
\endif

reset role;
create role myg_sin_espera_auditor;
grant execute on function public.myg_nube_crear_confirmacion(uuid,text,jsonb,text) to myg_sin_espera_auditor;
alter function public.myg_nube_crear_confirmacion(uuid,text,jsonb,text) set statement_timeout='65s';
alter function public.myg_nube_crear_confirmacion(uuid,text,jsonb,text) set lock_timeout='750ms';
create table qa.antes_sin_espera as select
    (select to_jsonb(p)-'prosrc' from pg_proc p
      where p.oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure) atributos,
    (select jsonb_agg(to_jsonb(p) order by p.oid) from pg_proc p
      where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace)
        and p.oid<>'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure) otras_funciones,
    (select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb) from public.myg_nube_proyectos p) proyectos,
    (select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from public.myg_nube_historial h) historial,
    (select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb) from public.myg_nube_miembros m) miembros,
    (select count(*) from qa.resultados) resultados_antes;

\ir ../migraciones/20261027_publicacion_sin_espera.sql
select qa.exige((select atributos=(select to_jsonb(p)-'prosrc' from pg_proc p
    where p.oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure)
    from qa.antes_sin_espera),'Sin espera: conserva OID, propietario, ACL y todos los atributos excepto el cuerpo');
select qa.exige((select otras_funciones=(select jsonb_agg(to_jsonb(p) order by p.oid) from pg_proc p
    where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace)
      and p.oid<>'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure)
    from qa.antes_sin_espera),'Sin espera: no modifica las otras funciones');
select qa.exige((select proyectos=(select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb)
    from public.myg_nube_proyectos p) and historial=(select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb)
    from public.myg_nube_historial h) and miembros=(select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb)
    from public.myg_nube_miembros m) from qa.antes_sin_espera),'Sin espera: instalación no cambia proyectos, historial ni miembros');
select qa.exige((select proconfig @> array['statement_timeout=65s','lock_timeout=750ms'] from pg_proc
    where oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure),
    'Sin espera: respeta los plazos personalizados ya configurados');
select qa.exige(has_function_privilege('myg_sin_espera_auditor',
    'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)','execute'),
    'Sin espera: conserva un permiso adicional existente');
create table qa.primera_sin_espera as select to_jsonb(p) atributos from pg_proc p
    where p.oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure;
\ir ../migraciones/20261027_publicacion_sin_espera.sql
select qa.exige((select atributos=(select to_jsonb(p) from pg_proc p
    where p.oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure)
    from qa.primera_sin_espera),'Sin espera: repetición conserva cuerpo, OID, ACL y configuración');

create table qa.sin_espera_paquete as
    select pg_read_file('/pruebas/paquetes/compacto_cliente.json')::jsonb contenido;
grant select on qa.sin_espera_paquete to authenticated;
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige((select public.myg_nube_crear_confirmacion('98000000-0000-0000-0000-000000000001',
    'Sin espera',contenido,'base')->>'revision'='1' from qa.sin_espera_paquete),
    'Sin espera: creación nueva conserva contrato y revisión inicial');
select qa.exige((select public.myg_nube_crear_confirmacion('98000000-0000-0000-0000-000000000001',
    'Sin espera',contenido,'base')=public.myg_nube_revision('98000000-0000-0000-0000-000000000001')
    from qa.sin_espera_paquete),'Sin espera: reintento confirma el cuerpo inicial y conserva metadatos');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('98000000-0000-0000-0000-000000000001',
    'Otro nombre',contenido,'base') from qa.sin_espera_paquete$$,'22023',
    'Sin espera: sigue rechazando otro nombre para el mismo UUID');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('98000000-0000-0000-0000-000000000001',
    'Sin espera',contenido,'obra') from qa.sin_espera_paquete$$,'22023',
    'Sin espera: sigue rechazando otro alcance para el mismo UUID');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('98000000-0000-0000-0000-000000000001',
    'Sin espera',jsonb_set(contenido,'{documento,Nombre}','"DISTINTO"'),'base')
    from qa.sin_espera_paquete$$,'22023','Sin espera: sigue comparando el contenido inicial completo');
select qa.rechaza($$select public.myg_nube_crear_confirmacion('98000000-0000-0000-0000-000000000002',
    'Inválido','[]','base')$$,'22023','Sin espera: conserva la validación del paquete');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_crear_confirmacion('98000000-0000-0000-0000-000000000001',
    'Sin espera',contenido,'base') from qa.sin_espera_paquete$$,'42501',
    'Sin espera: identidad ajena sigue rechazada');
reset role;
select qa.exige((select count(*)=1 from public.myg_nube_proyectos where id='98000000-0000-0000-0000-000000000001')
    and (select count(*)=1 from public.myg_nube_historial where proyecto_id='98000000-0000-0000-0000-000000000001')
    and (select count(*)=1 from public.myg_nube_miembros where proyecto_id='98000000-0000-0000-0000-000000000001'),
    'Sin espera: reintentos y rechazos no duplican proyecto, historial ni miembros');
select qa.exige(not exists(select 1 from public.myg_nube_proyectos
    where id='98000000-0000-0000-0000-000000000002'),'Sin espera: validación fallida no deja una creación parcial');
select qa.exige(not has_function_privilege('anon','public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)','execute')
    and not has_table_privilege('authenticated','public.myg_nube_proyectos','UPDATE'),
    'Sin espera: no amplía permisos de ejecución anónima ni escritura directa');
select format('PRUEBAS SIN ESPERA COMPLETADAS: %s',count(*)-(select resultados_antes from qa.antes_sin_espera))
    from qa.resultados;
