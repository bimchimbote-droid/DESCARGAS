# Investigación Nano, JSONB, bloqueos y archivado WAL — 22/10/2026

Proyecto: `bimchimbote-droid/MYG.Presupuestos`, referencia remota `main`, base
`901cbaeac6894eb59f2a3dbf0d5777af49958118`. Se conservaron los trece archivos de la
entrega anterior: sus SHA-256 siguen coincidiendo. No se ha ejecutado ninguna
migración ni publicación contra el Supabase real del usuario.

## Conclusión y límite de la evidencia

La causa exacta del HTTP 502 real **sigue sin confirmarse**. Se han demostrado
tres comportamientos separados en laboratorio:

1. Un POST de aproximadamente 200 MiB puede agotar la memoria de PostgREST o de
   PostgreSQL antes de que comience el cuerpo de la RPC. Se aislaron ambos
   componentes y se conservaron los eventos de terminación, no solo el HTTP.
2. La RPC de confirmación podía esperar por una fila bloqueada aunque la sonda
   devolviera `existente`. Ese defecto de espera se corrige por separado.
3. El archivado WAL fallido puede coexistir con una publicación HTTP 200 y un
   COMMIT correcto. No hay evidencia suficiente para atribuirle el 502 real.

Los resultados sintéticos no certifican la capacidad del servicio ni reproducen
la forma del SQLite privado. Se entregan también los resultados resumidos en
`diagnosticos/RESULTADOS_LAB_NANO_20261022.json`, con hashes de los artefactos
originales de laboratorio.

## Estado recuperado después de la interrupción

Se reutilizaron, sin volver a ejecutarlos:

- Los seis controles HTTP de `entrada-grande-aislado/results.json`, sus logs y
  marcas de entrada a función. El archivo terminó de escribirse y el log contiene
  el mensaje final `RESULTS`; no quedaron contenedores de esos ensayos.
- Los perfiles SQL de 8 MiB, 25 MiB, auxiliares y bloqueos, conservados en
  `small-rpc/summary.json` y sus resultados particulares.
- El ensayo de archivado fallido de `small-rpc/archive-failure-control/`, que sí
  había concluido antes de la interrupción: creación y replay HTTP 200 y COMMIT
  correcto, con fallos de archivado activos.
- Las 286 comprobaciones SQL y las 15 solicitudes HTTP funcionales de la entrega
  anterior. Sus logs no se presentan como ejecuciones nuevas.

El ensayo intermedio `entrada-grande-controlado` falló al intentar ejecutar
`cat` dentro de la imagen mínima de PostgREST, que no contiene ese ejecutable.
Fue un fallo del instrumento de observación, no de MYG ni una prueba de memoria.
Ese resultado se descarta; el ensayo posterior `entrada-grande-aislado` corrigió
la observación y separó los componentes.

Quedaban pendientes la migración de estabilidad por bloqueo de fila, sus pruebas
específicas y el diagnóstico de solo lectura. Las comprobaciones adicionales de
esta entrega se limitan a esos archivos nuevos y su compatibilidad.

## Registros comunicados del servidor real

Configuración confirmada por el usuario: Nano, hasta 512 MB de RAM, CPU compartida,
plan Free; 2 GB asignados y 0,27 GB utilizados según el panel.

| Hora Perú (UTC−5), 22/10/2026 | Registro comunicado |
|---|---|
| 11:24:27 (16:24:27.359 UTC) | POST `myg_nube_crear_confirmacion`, HTTP 502. Sin duración ni SQLSTATE visibles. |
| 11:24:43 | Mensajes de checkpoint, sin explicación del archivado. |
| 11:24:50 | `archive command failed with exit code 1`. |
| 11:25:00 y 11:26:13 | Reintentos de archivado WAL fallidos. |
| 11:28:15 | `Connection reset by peer`. |
| 11:29:43 | `checkpoint complete`. |

No se dispone de un error explicativo del archivador ni de métricas de CPU/RAM
del mismo intervalo. El primer fallo de archivado comunicado es 23 segundos
posterior al 502; eso no prueba que el problema empezara entonces ni que causara
la respuesta HTTP. Tampoco el reset de conexión identifica por sí solo la causa.

Los HTTP 520 anteriores en `myg_nube_crear` y los posteriores en
`myg_nube_crear_confirmacion` son incidentes diferentes. No se les atribuye una
causa común sin correlación temporal, identificador y evidencia del servidor.

## Conversión JSONB y memoria: componentes aislados

Se usaron PostgreSQL 17 y PostgREST 16.5 con imágenes fijadas por digest,
contenedores desechables, un máximo de 1 CPU por componente y datos sintéticos.
La carga grande tenía 209.897.782 bytes HTTP y añadía un campo de texto grande
a un paquete compacto válido. No era la base privada del usuario.

| API | PostgreSQL | Carga añadida | Resultado observado |
|---|---|---:|---|
| 512 MiB | 512 MiB | 1 MiB | HTTP 200, 0,130 s, sin OOM. |
| 512 MiB | 512 MiB | 200 MiB | PostgREST termina con `OOMKilled=true`, salida 137; PostgreSQL no registra OOM y su pico queda cerca de 95 MiB. No entra en la RPC. |
| 2 GiB | 512 MiB | 1 MiB | HTTP 200, 0,140 s, sin OOM. |
| 2 GiB | 512 MiB | 200 MiB | HTTP 503/PGRST001 en 1,774 s; PostgreSQL alcanza 512 MiB, aumenta `oom_kill` en 1, registra señal 9 y recuperación. Sin marca de entrada a la RPC. |
| 2 GiB | 512 MiB | 1 MiB, función mínima | HTTP 200, 0,046 s. |
| 2 GiB | 512 MiB | 200 MiB, función mínima | HTTP 503/PGRST001 en 1,658 s, OOM de PostgreSQL antes de entrar incluso en esta función mínima. |

La función mínima recibe los mismos tipos de argumentos, devuelve solo el tamaño
binario y no valida ni guarda el proyecto. Aísla la ruta de conversión anterior
al cuerpo de MYG. Los controles pequeños comprobaron que las marcas de entrada
se escribían correctamente.

El código oficial de PostgREST 16.5 convierte el cuerpo JSON a columnas tipadas
mediante `json_to_record` antes de llamar a la función. Por ello, devolver un ACK
pequeño y optimizar el cuerpo PL/pgSQL no eliminan ese coste previo.

**No se ha verificado el límite de memoria ni la versión de la API productiva.**
El límite Nano confirmado corresponde a la base, y no autoriza a suponer que
PostgREST productivo también tenga exactamente 512 MiB. El HTTP 503 local tampoco
se identifica automáticamente con los 502/520 de las capas de Supabase.

## Coste dentro de la RPC y sus dependencias

La ruta nueva sigue este orden: identidad, advisory lock, lectura del propietario
con bloqueo, comparación de creación previa o validación, inserción de proyecto,
inserción de miembro, inserción de historial y ACK de metadatos.

- La ruta de creación no ejecuta las comparaciones de permisos por módulo, la
  reconstrucción incremental ni el snapshot completo de respuesta. Esas tareas
  de edición no deben cargarse al análisis de esta publicación.
- El reintento compara el contenido con la revisión inicial; aparecer en el
  listado no basta para confirmar un pendiente. Esa garantía se conserva.
- El validador serializa el JSON completo para medirlo y vuelve a recorrerlo al
  validar el formato compacto. Construye mapas/listas de documentos y comprueba
  tablas, filas, referencias, valores y BLOB. `p_materializar=false` evita la
  expansión final, pero no convierte su coste de memoria en constante.
- La creación guarda contenido en proyecto e historial dentro de una transacción.
  Compresión, TOAST y WAL añaden trabajo; no equivalen necesariamente a dos
  archivos físicos del tamaño del POST.
- Los planes del fixture usan las claves primarias de proyectos e historial.
  No se observó una búsqueda masiva por falta de índice en esos controles.
  El diagnóstico nuevo permite comprobar índices y triggers reales.

Mediciones SQL recuperadas, PostgreSQL limitado a 512 MiB y 1 CPU:

| Dataset sintético | Parse JSONB | RPC original | Replay |
|---|---:|---:|---:|
| Documento con 8 MiB adicionales | 23–30 ms | 456 ms | 16 ms |
| Unas 8 MiB con 8192 filas | 19–20 ms | 287 ms | 14 ms |
| Documento con 25 MiB adicionales | 93 ms | 2026 ms | No medido |

En el perfil de 8 MiB, validar consumió unos 350 ms, insertar proyecto unos 40 ms
e historial unos 36 ms; el ACK consumió menos de 1 ms. En los auxiliares aislados
de 25 MiB, la validación v1 consumió 103,5 ms y la validación compacta 1637,4 ms,
con un pico cercano a 487 MiB.

La RPC original de 25 MiB **pasó**: alcanzó el límite de memoria pero no hubo
`oom_kill`. Un clon instrumentado después de otras pruebas sí falló con OOM.
Esos resultados no son intercambiables; el perfilado y el estado anterior cambian
las asignaciones. No se presenta el fallo del clon como fallo de la RPC original.

## Bloqueo demostrado y corrección acotada

Antes del parche, una conexión mantuvo bloqueada una fila durante cuatro segundos.
La sonda respondió `existente` en 0,095 s, pero la RPC esperó 4,106 s. Se guardaron
19 muestras `wait_event_type=Lock`, `wait_event=transactionid` y PID bloqueador.
El advisory lock protege otra creación del mismo UUID; no cubre esa transacción
de guardado o administración que ya tiene bloqueada la fila.

La migración aditiva `migraciones/20261027_publicacion_sin_espera.sql` modifica
solo esa adquisición de fila: comprueba primero al propietario, usa
`FOR UPDATE NOWAIT`, vuelve a comprobar propietario bajo bloqueo y convierte
la contención en `55006 / MYG_RECURSO_OCUPADO`. El cliente existente reconoce
ese error transitorio y conserva el pendiente; no necesita una actualización C#.

Se conservan firma, propietario, permisos de ejecución, configuración de función,
comparación de creación, validación, contenido, miembros, historial y transacción.
El parche rechaza una función cuyo cuerpo no corresponde exactamente al contrato
esperado, incluidos cambios de formato no reconocidos, en lugar de sobrescribirla.
La repetición de la instalación es admitida.

Este cambio evita esperar por esa fila. **No evita el coste JSONB anterior ni
garantiza publicar 200 MiB en Nano; tampoco acota todos los bloqueos de tabla
causados por mantenimiento DDL.** No se cambia `archive_command`, la durabilidad
ni la configuración global de PostgreSQL.

## Validación nueva de la corrección de bloqueo

Se ejecutó únicamente el runner nuevo y sus requisitos de base desechable,
reutilizando los paquetes sintéticos ya generados. Después se reforzó su control
HTTP con `lock_timeout=0` en el laboratorio: se repitió solo ese runner para probar
que el rechazo rápido procede de NOWAIT y no del timeout personalizado de 750 ms
utilizado antes para verificar la preservación de configuración. No se recompiló
.NET ni se repitieron los benchmarks grandes para esta corrección SQL.

- 16 comprobaciones SQL nuevas y 28 comprobaciones del runner aprobadas.
- Nueve solicitudes HTTP reales con PostgreSQL 17/PostgREST 16.5.
- Con la fila todavía bloqueada, el propietario recibió
  `55006 / MYG_RECURSO_OCUPADO` en 0,0439 s; el usuario ajeno conservó `42501`
  en 0,0126 s. Son respuestas controladas, sin cambios en datos.
- El advisory lock anterior siguió rechazando otra creación en 0,0017 s.
- Después de liberar la fila, el replay devolvió la confirmación correcta;
  los snapshots de proyectos, miembros, operaciones e historial permanecieron
  iguales. Un cuerpo distinto siguió rechazándose con `22023`.
- La repetición conservó OID, propietario, ACL y ajustes personalizados de
  `statement_timeout=65s` y `lock_timeout=750ms` usados en el fixture.
- Una función personalizada desconocida y la falta del requisito 26 se
  rechazaron sin crear ni reemplazar funciones.
- PostgreSQL limitado a 512 MiB no registró OOM en estas verificaciones.

PostgREST presenta `55006` como HTTP 500 en esta versión, pero el cliente MYG
ya interpreta su código SQL como recurso ocupado. Esa respuesta controlada no
se presenta como una caída del servidor ni como reproducción del 502 real.
Los contenedores y la red de prueba se eliminaron al terminar.

Para repetir exclusivamente esta regresión en una máquina de pruebas:

```bash
python3 scripts/pruebas/Probar-PublicacionSinEsperaNube.py
```

El runner admite `--paquetes <directorio>` para reutilizar los fixtures del
generador `supabase/pruebas/PaquetesPrueba`, sin volver a compilarlos. El archivo
SQL de pruebas solo debe utilizarse dentro de su base desechable.

## Archivado WAL y COMMIT: control separado

Se forzó un archivador fallido exclusivamente en un contenedor desechable,
manteniendo `synchronous_commit=on`, PostgreSQL en 512 MiB y la API en 2 GiB.
Con cinco intentos de archivado fallidos y dos segmentos `.ready` pendientes:

- Crear una publicación pequeña devolvió HTTP 200 en 0,135 s.
- El replay devolvió HTTP 200 en 0,034 s, sin duplicar historial.
- Un COMMIT explícito terminó correctamente en 0,094 s.
- El proceso principal conservó su hora de inicio y no hubo OOM.

Este control demuestra que el archivado fallido por sí solo no impide el COMMIT
ordinario. No simula disco lleno, almacenamiento lento, un archivador gestionado
ni saturación prolongada del servicio real.

PostgreSQL reintenta el archivado y conserva segmentos pendientes. Si esa retención
llena el filesystem, puede ocasionar problemas graves y PANIC. Para relacionarlo
con este incidente faltan progreso/cola de archivado, espacio libre real, I/O y
logs del mismo intervalo. El dato del panel de 0,27 GB utilizados no reemplaza
esas mediciones.

## Plazos y manejo de errores

- El cliente no reintenta automáticamente un 502/520. Repite el POST únicamente
  tras una respuesta 401 y renovación de sesión, conservando UUID y bytes.
- Los 150 segundos del cliente comienzan después de serializar el paquete;
  incluyen espera del semáforo, autenticación, POST y lectura del ACK.
- La función declara 120 segundos. PostgREST 16.5 puede extraer esa configuración
  antes de ejecutar la consulta, incluido su procesamiento de argumentos.
- Supabase documenta límites de API que pueden ser inferiores. Una duración
  real cercana al límite y eventos como SQLSTATE 57014 apoyarían esa hipótesis;
  no se dispone todavía de esa duración productiva.
- El reloj del diálogo inicial incluye preparación y espera del usuario, por
  lo que no mide la duración HTTP.

Un 502/520 es una respuesta de pasarela. No prueba por sí solo memoria agotada,
bloqueo, tiempo excedido o fallo del archivador. La apertura posterior con 200
demuestra disponibilidad para esa petición; no confirma el UUID del pendiente.

## Validación del diagnóstico de solo lectura

El diagnóstico nuevo superó 103 verificaciones en PostgreSQL 17 desechable:
cuenta administrativa, rol sin permisos para listar WAL ni ver estadísticas
completas, y base sin objetos MYG. Se comprobaron snapshots idénticos de datos,
funciones, ACL y configuración de roles antes y después. No aparecieron sentinelas
privadas de consultas, configuración ni comando de archivado.

Las consultas de directorios se ejecutan mediante SELECT constante únicamente
en la rama con permiso. Esto evita un error de inicialización de subplanes que
puede ocurrir si una función restringida aparece directamente dentro de CASE.
No se crean funciones auxiliares ni se conceden permisos para diagnosticar.

## Aplicación manual y siguiente evidencia útil

1. Respaldar o confirmar cambios locales. Copiar los archivos nuevos conservando
   sus rutas y sin sustituir los trece archivos de la entrega anterior.
2. Ejecutar en una consulta nueva de SQL Editor el archivo
   `diagnosticos/20261027_wal_bloqueos_solo_lectura.sql`. Es una lectura de
   estadísticas y estructura; no lee contenido de obras ni publica proyectos.
   Copiar el objeto JSON `diagnostico` resultante.
3. Conservar dos resultados de diagnóstico de ejecuciones separadas, con sus
   horas y `stats_reset`, si hace falta observar progreso del archivado. No es
   necesario provocar otro envío grande para obtener estas estadísticas.
4. Para aplicar la estabilidad de bloqueo, ejecutar completo el instalador 27
   después de tener la migración 26 instalada. Si detecta una función modificada
   no reconocida, conservar su error y revisar diferencias; no reinstalar SQL
   anteriores para forzar la instalación.
5. No ejecutar los archivos de pruebas contra Supabase real. El runner nuevo
   prepara sus propios contenedores y datos sintéticos. El SQL de diagnóstico
   solo modifica sus parámetros locales de ejecución y no instala nada.
6. Conservar el mismo pendiente y UUID mientras el resultado sea incierto. Revisar
   el listado y las métricas del intervalo; no crear UUID nuevos por cada error.

El diagnóstico evita consultas completas, credenciales, `archive_command` y
contenidos de proyectos. La lista de WAL se ejecuta únicamente si existen permisos.
Los bytes WAL no son espacio libre, y los contadores de fallos cuentan intentos,
no archivos únicos. El timeout de una sesión de SQL Editor no demuestra el timeout
efectivo de las peticiones de la API.

La causa del archivador gestionado sigue pendiente: si sus logs visibles no
incluyen el motivo, la siguiente evidencia corresponde a métricas/infraestructura
de Supabase, no a cambiar el archivador desde MYG.

## Fuentes oficiales contrastadas

- PostgreSQL 17, archivado continuo y retención:
  <https://www.postgresql.org/docs/17/continuous-archiving.html>.
- PostgreSQL 17, estadísticas de archivado/WAL:
  <https://www.postgresql.org/docs/17/monitoring-stats.html>.
- PostgREST 16.5, conversión previa de argumentos:
  <https://github.com/PostgREST/postgrest/blob/798523c910c09dc56d92ba2c42bcb78e5f59ecb3/src/library/PostgREST/Query/SqlFragment.hs>.
- PostgREST 16.5, preparación de llamadas:
  <https://github.com/PostgREST/postgrest/blob/798523c910c09dc56d92ba2c42bcb78e5f59ecb3/src/library/PostgREST/Query/QueryBuilder.hs>.
- Límites de tiempo documentados por Supabase:
  <https://github.com/supabase/supabase/blob/master/apps/docs/content/guides/database/postgres/timeouts.mdx>.

Las fuentes se consultaron en sus repositorios oficiales. Su documentación no
sustituye la comprobación de versión y configuración del proyecto productivo.
