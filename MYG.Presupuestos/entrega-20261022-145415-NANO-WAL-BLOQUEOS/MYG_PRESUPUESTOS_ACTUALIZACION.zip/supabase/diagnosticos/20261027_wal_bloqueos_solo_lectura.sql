-- DIAGNÓSTICO DE SOLO LECTURA: ejecutar completo en SQL Editor de Supabase.
-- Devuelve una celda JSON llamada diagnostico; conservarla con su hora.
-- No publica, no lee filas de obras, no cambia funciones ni reinicia estadísticas.
-- No devuelve consultas activas, identidades, tokens, archive_command ni destinos.
-- Los directorios WAL solo se consultan si la sesión tiene EXECUTE; sin permiso
-- se informa disponible=false. Sus bytes NO son espacio libre del filesystem.
-- SELECT constante mediante XMLTABLE evita que PostgreSQL prepare una llamada
-- prohibida al directorio incluso cuando la rama CASE no se utiliza.
-- Este informe es una instantánea: no reconstruye el estado de un fallo pasado.
-- Comparar dos ejecuciones independientes y sus stats_reset para medir cambios.
-- failed_count cuenta intentos desde stats_reset, no segmentos únicos fallidos.
-- Tiempos WAL iguales a cero pueden significar track_wal_io_timing desactivado.
-- El timeout de esta sesión administrativa NO prueba el timeout efectivo de API.
-- El inicio del postmaster no detecta todos los reinicios de procesos hijos.
-- No ejecutar pg_switch_wal, borrar WAL ni cambiar archivado/durabilidad para medir.

begin read only;
set local statement_timeout = '8s';
set local lock_timeout = '500ms';

with
instante as (
    select clock_timestamp() as t
),
tablas_objetivo as (
    select c.oid, n.nspname, c.relname
    from pg_catalog.pg_class c
    join pg_catalog.pg_namespace n on n.oid=c.relnamespace
    where n.nspname='public' and c.relkind in ('r','p')
      and c.relname in ('myg_nube_proyectos','myg_nube_historial',
                       'myg_nube_operaciones','myg_nube_miembros')
),
funciones_objetivo(esquema,nombre,argumentos) as (
    values
        ('public','myg_nube_crear','uuid, text, jsonb, text'),
        ('public','myg_nube_crear_confirmacion','uuid, text, jsonb, text'),
        ('public','myg_nube_estado_publicacion','uuid'),
        ('public','myg_nube_capacidades',''),
        ('myg_nube_privado','validar_contenido','jsonb'),
        ('myg_nube_privado','validar_contenido_v1','jsonb'),
        ('myg_nube_privado','expandir_paquete','jsonb, boolean')
),
funciones as (
    select o.esquema, o.nombre, o.argumentos, p.oid,
           p.prosecdef, p.provolatile, p.proconfig, p.prosrc
    from funciones_objetivo o
    left join pg_catalog.pg_namespace n on n.nspname=o.esquema
    left join pg_catalog.pg_proc p on p.pronamespace=n.oid
        and p.proname=o.nombre
        and pg_catalog.oidvectortypes(p.proargtypes)=o.argumentos
),
permisos_directorio as (
    select
        pg_catalog.has_function_privilege(
            current_user,'pg_catalog.pg_ls_waldir()','EXECUTE') as wal,
        pg_catalog.has_function_privilege(
            current_user,'pg_catalog.pg_ls_archive_statusdir()','EXECUTE') as archivo
),
ajustes_rol as (
    select case when s.setrole=0 then '(todos)' else r.rolname end as rol,
           case when s.setdatabase=0 then '(todas)' else '(base actual)' end as alcance_base,
           v.valor
    from pg_catalog.pg_db_role_setting s
    left join pg_catalog.pg_roles r on r.oid=s.setrole
    cross join lateral unnest(s.setconfig) as v(valor)
    where s.setdatabase in (0,(select oid from pg_catalog.pg_database where datname=current_database()))
      and (s.setrole=0 or r.rolname in ('authenticator','authenticated','anon','service_role'))
      and split_part(v.valor,'=',1) in
          ('statement_timeout','lock_timeout','idle_in_transaction_session_timeout')
)
select jsonb_build_object(
    'servidor',jsonb_build_object(
        'observado_utc',to_char(i.t at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
        'observado_lima',to_char(i.t at time zone 'America/Lima','YYYY-MM-DD"T"HH24:MI:SS.US'),
        'zona_lima','America/Lima',
        'zona_sesion',current_setting('TimeZone'),
        'version_postgresql',current_setting('server_version'),
        'inicio_postmaster_utc',to_char(pg_postmaster_start_time() at time zone 'UTC',
            'YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
        'segundos_desde_inicio_postmaster',extract(epoch from i.t-pg_postmaster_start_time()),
        'en_recuperacion',pg_is_in_recovery(),
        'transaccion_solo_lectura',current_setting('transaction_read_only')),
    'archivado',(
        select to_jsonb(a) from (
            select archived_count,last_archived_wal,last_archived_time,
                   failed_count,last_failed_wal,last_failed_time,stats_reset
            from pg_catalog.pg_stat_archiver
        ) a),
    'wal',(
        select to_jsonb(w) from (
            select wal_records,wal_fpi,wal_bytes,wal_buffers_full,
                   wal_write,wal_sync,wal_write_time,wal_sync_time,stats_reset
            from pg_catalog.pg_stat_wal
        ) w),
    'directorio_wal',case when d.wal then (
        select x.datos::jsonb
        from xmltable('/table/row' passing pg_catalog.query_to_xml(
            $wal$select jsonb_build_object('disponible',true,'archivos',count(*),
                'bytes_en_directorio',coalesce(sum(size),0),
                'modificacion_mas_antigua',min(modification),
                'modificacion_mas_reciente',max(modification)) as datos
                from pg_catalog.pg_ls_waldir()$wal$,
            false,false,'') columns datos text path 'datos') x
    ) else jsonb_build_object('disponible',false,'motivo','sin permiso EXECUTE') end,
    'cola_archivado',case when d.archivo then (
        select x.datos::jsonb
        from xmltable('/table/row' passing pg_catalog.query_to_xml(
            $archivo$select jsonb_build_object('disponible',true,
                'pendientes_ready',count(*) filter(where name like '%.ready'),
                'pendiente_mas_antiguo',min(modification) filter(where name like '%.ready'),
                'marcados_done',count(*) filter(where name like '%.done')) as datos
                from pg_catalog.pg_ls_archive_statusdir()$archivo$,
            false,false,'') columns datos text path 'datos') x
    ) else jsonb_build_object('disponible',false,'motivo','sin permiso EXECUTE') end,
    'puede_ver_actividad_completa',(
        select r.rolsuper or pg_catalog.pg_has_role(current_user,'pg_read_all_stats','USAGE')
        from pg_catalog.pg_roles r where r.rolname=current_user),
    'actividad_actual_sin_texto_sql',coalesce((
        select jsonb_agg(jsonb_build_object(
            'pid',a.pid,'estado',a.state,'tipo_espera',a.wait_event_type,
            'evento_espera',a.wait_event,
            'segundos_consulta',extract(epoch from i.t-a.query_start),
            'segundos_transaccion',extract(epoch from i.t-a.xact_start),
            'bloqueadores',pg_catalog.pg_blocking_pids(a.pid))
            order by a.xact_start nulls last,a.query_start)
        from pg_catalog.pg_stat_activity a
        where a.datname=current_database() and a.backend_type='client backend'
          and a.pid<>pg_backend_pid() and a.state is distinct from 'idle'
    ),'[]'::jsonb),
    'ajustes_servidor_sesion',coalesce((
        select jsonb_agg(jsonb_build_object('nombre',name,'valor',setting,'unidad',unit)
            order by name)
        from pg_catalog.pg_settings
        where name in ('archive_mode','archive_timeout','wal_level','wal_segment_size',
            'max_wal_size','min_wal_size','wal_keep_size','checkpoint_timeout',
            'synchronous_commit','track_wal_io_timing','track_io_timing',
            'max_connections','shared_buffers','work_mem','statement_timeout','lock_timeout')
    ),'[]'::jsonb),
    'timeouts_configurados_rol_base',coalesce((
        select jsonb_agg(jsonb_build_object('rol',rol,'alcance_base',alcance_base,'ajuste',valor)
            order by rol,alcance_base,valor)
        from ajustes_rol
    ),'[]'::jsonb),
    'funciones',(
        select jsonb_agg(jsonb_build_object(
            'firma',f.esquema||'.'||f.nombre||'('||f.argumentos||')',
            'existe',f.oid is not null,
            'security_definer',f.prosecdef,'volatilidad',f.provolatile,
            'md5_cuerpo',case when f.oid is not null then md5(f.prosrc) end,
            'md5_definicion',case when f.oid is not null
                then md5(pg_catalog.pg_get_functiondef(f.oid)) end,
            'configuracion_filtrada',coalesce((
                select jsonb_agg(v.valor order by v.valor)
                from unnest(f.proconfig) as v(valor)
                where split_part(v.valor,'=',1) in
                    ('search_path','statement_timeout','lock_timeout','idle_in_transaction_session_timeout')
            ),'[]'::jsonb),
            'authenticated_execute_acl',case when f.oid is not null then
                pg_catalog.has_function_privilege(pg_catalog.to_regrole('authenticated'),f.oid,'EXECUTE') end,
            'anon_execute_acl',case when f.oid is not null then
                pg_catalog.has_function_privilege(pg_catalog.to_regrole('anon'),f.oid,'EXECUTE') end)
            order by f.esquema,f.nombre,f.argumentos)
        from funciones f),
    'indices',coalesce((
        select jsonb_agg(jsonb_build_object(
            'tabla',t.nspname||'.'||t.relname,'indice',c.relname,
            'primario',x.indisprimary,'unico',x.indisunique,'valido',x.indisvalid,
            'columnas',(
                select jsonb_agg(coalesce(a.attname,'(expresion)') order by k.posicion)
                from unnest(x.indkey) with ordinality as k(numero,posicion)
                left join pg_catalog.pg_attribute a on a.attrelid=t.oid and a.attnum=k.numero
            )) order by t.relname,c.relname)
        from tablas_objetivo t
        join pg_catalog.pg_index x on x.indrelid=t.oid
        join pg_catalog.pg_class c on c.oid=x.indexrelid
    ),'[]'::jsonb),
    'triggers_no_internos',coalesce((
        select jsonb_agg(jsonb_build_object(
            'tabla',t.nspname||'.'||t.relname,'trigger',g.tgname,'habilitado',g.tgenabled,
            'funcion',g.tgfoid::regprocedure::text) order by t.relname,g.tgname)
        from tablas_objetivo t join pg_catalog.pg_trigger g on g.tgrelid=t.oid
        where not g.tgisinternal
    ),'[]'::jsonb),
    'tamano_fisico_tablas',coalesce((
        select jsonb_agg(jsonb_build_object('tabla',t.nspname||'.'||t.relname,
            'bytes_con_indices_toast',pg_catalog.pg_total_relation_size(t.oid)) order by t.relname)
        from tablas_objetivo t
    ),'[]'::jsonb),
    'estadisticas_base',(
        select to_jsonb(b) from (
            select numbackends,xact_commit,xact_rollback,temp_files,temp_bytes,
                   deadlocks,blk_read_time,blk_write_time,stats_reset
            from pg_catalog.pg_stat_database where datname=current_database()
        ) b),
    'limites_interpretacion',jsonb_build_array(
        'Instantánea actual: no identifica por sí sola la causa de un HTTP pasado.',
        'No mide la RAM física ni el espacio libre del filesystem del proveedor.',
        'Los timeouts de esta sesión SQL Editor no prueban el timeout efectivo de API.',
        'Sin acceso completo a estadísticas, una actividad vacía no descarta sesiones de otros roles.',
        'failed_count cuenta intentos; comparar horas, stats_reset y progresión de pendientes.',
        'Los tiempos WAL cero necesitan interpretar track_wal_io_timing.',
        'Un WAL retenido también puede deberse a slots u otras políticas.',
        'La existencia o huella de una función no confirma una publicación pendiente.')
) as diagnostico
from instante i cross join permisos_directorio d;

commit;
