-- Estabilidad de reintentos: no esperar por una fila que otra operación modifica.
-- Requiere 20261026_publicacion_ligera.sql. No cambia contenido, permisos ni datos.
-- Conserva OID, propietario, ACL y configuración real de la función instalada.
-- NOWAIT acota la espera de fila, no el parseo JSON previo ni bloqueos de DDL.
begin;

do $instalar_sin_espera$
declare
    v_oid oid:=to_regprocedure('public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)');
    v_fuente text;
    v_definicion text;
    v_atributos jsonb;
    v_antes constant text:=$antes$    select propietario into v_propietario from public.myg_nube_proyectos
      where id=p_id for update;$antes$;
    v_despues constant text:=$despues$    -- MYG_PUBLICACION_SIN_ESPERA_V1: comprobar permisos antes de probar la fila.
    -- La lectura previa no reemplaza la comprobación bajo el bloqueo.
    select propietario into v_propietario from public.myg_nube_proyectos
      where id=p_id;
    if found and v_propietario<>v_usuario then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    begin
        select propietario into v_propietario from public.myg_nube_proyectos
          where id=p_id for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;$despues$;
begin
    if v_oid is null then
        raise exception using errcode='55000',
            message='Instale primero 20261026_publicacion_ligera.sql completo. No se modificó ninguna función.';
    end if;
    select p.prosrc,pg_get_functiondef(p.oid),to_jsonb(p)-'prosrc'
      into v_fuente,v_definicion,v_atributos
      from pg_proc p where p.oid=v_oid;

    -- Huellas del cuerpo oficial 26 y de esta transformación exacta. No son claves.
    -- Rechazar una personalización desconocida evita reemplazar avances ajenos.
    if md5(v_fuente)='0e4fc248646351ac672e015931e721e9' then
        null; -- Ya aplicada: no recrear ni cambiar configuración.
    elsif md5(v_fuente)='d00c2b6242abf449ada0eeb1a081451b'
        and strpos(v_fuente,v_antes)>0 then
        execute replace(v_definicion,v_antes,v_despues);
    else
        raise exception using errcode='55000',
            message='La función de publicación tiene una versión o personalización no reconocida. Se conserva intacta; revise sus diferencias antes de aplicar este cambio.';
    end if;

    if not exists(select 1 from pg_proc p where p.oid=v_oid
        and md5(p.prosrc)='0e4fc248646351ac672e015931e721e9'
        and to_jsonb(p)-'prosrc'=v_atributos) then
        raise exception using errcode='55000',
            message='Verificación de publicación sin espera fallida. Se revierte toda la instalación.';
    end if;
end $instalar_sin_espera$;

notify pgrst,'reload schema';
select 'PUBLICACION_SIN_ESPERA_INSTALADA' as resultado,
       true as rechazo_inmediato_de_fila_ocupada,
       '55006' as codigo_recurso_ocupado;
commit;
