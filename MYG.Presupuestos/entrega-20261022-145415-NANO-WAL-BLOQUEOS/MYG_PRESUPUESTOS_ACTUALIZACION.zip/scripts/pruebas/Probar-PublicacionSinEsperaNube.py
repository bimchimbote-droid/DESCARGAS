#!/usr/bin/env python3
"""Regresión SQL/HTTP de la migración 27, solo en Docker desechable y sin puertos.

--paquetes permite reutilizar fixtures sintéticos ya generados, sin recompilar.
La prueba no conecta a Supabase ni demuestra la capacidad de publicar 200 MiB.
"""
import argparse
import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid

REPO = Path(__file__).resolve().parents[2]
POSTGRES = 'postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
POSTGREST = 'postgrest/postgrest:v16.5@sha256:1347d7552b88f17832912c06afbf7c43209af6eeeb60834b04aae12c9bd9d5cc'
SECRET = b'myg_nowait_synthetic_test_secret_not_a_real_credential'
OWNER = '00000000-0000-0000-0000-000000000001'
OTHER = '00000000-0000-0000-0000-000000000003'
PROJECT = '98000000-0000-0000-0000-000000000001'
LOCKED_NEW = '98000000-0000-0000-0000-000000000099'
MIGRATION = '/pruebas/supabase/migraciones/20261027_publicacion_sin_espera.sql'


def token(user):
    def b64(value):
        return base64.urlsafe_b64encode(value).rstrip(b'=')
    header = b64(b'{"alg":"HS256","typ":"JWT"}')
    claims = b64(json.dumps({'role': 'authenticated', 'sub': user, 'exp': int(time.time()) + 3600}).encode())
    unsigned = header + b'.' + claims
    return (unsigned + b'.' + b64(hmac.new(SECRET, unsigned, hashlib.sha256).digest())).decode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--paquetes', type=Path, help='Fixtures sintéticos existentes del generador PaquetesPrueba')
    parser.add_argument('--resultados', type=Path, help='Directorio de resultados y logs que se conservará')
    args = parser.parse_args()
    suffix = uuid.uuid4().hex[:12]
    output = args.resultados or Path(tempfile.mkdtemp(prefix='myg-sin-espera-resultados-'))
    output.mkdir(parents=True, exist_ok=True)
    network, database, api = [f'myg-sin-espera-{suffix}-{n}' for n in ('red', 'pg', 'api')]
    containers = []
    created_network = False
    lock_process = None
    lock_log = None
    checks, requests = [], []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def stop(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)

    def require(condition, detail):
        if not condition:
            raise AssertionError(detail)
        checks.append(detail)

    with (output / 'preparacion.log').open('w') as log:
        def run(*command, check=True):
            result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(result.stdout)
            log.flush()
            if check and result.returncode:
                raise RuntimeError(f'{command[0]} terminó con {result.returncode}: {result.stdout[-1800:]}')
            return result

        def sql(query, db='postgres'):
            return run('docker', 'exec', '-u', 'postgres', database, 'psql', '-X', '-At',
                       '-d', db, '-v', 'ON_ERROR_STOP=1', '-c', query).stdout.strip()

        def sql_file(path, db='postgres', check=True):
            return run('docker', 'exec', '-u', 'postgres', database, 'psql', '-X',
                       '-d', db, '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose',
                       '-v', 'MYG_PRUEBAS_DESECHABLES=1', '-f', path, check=check)

        def snapshot():
            return sql("""
              SELECT md5(jsonb_build_object(
                'proyectos',(SELECT jsonb_agg(to_jsonb(p) ORDER BY id) FROM public.myg_nube_proyectos p),
                'historial',(SELECT jsonb_agg(to_jsonb(h) ORDER BY proyecto_id,revision) FROM public.myg_nube_historial h),
                'miembros',(SELECT jsonb_agg(to_jsonb(m) ORDER BY proyecto_id,usuario_id) FROM public.myg_nube_miembros m),
                'operaciones',(SELECT jsonb_agg(to_jsonb(o) ORDER BY usuario_id,operacion_id) FROM public.myg_nube_operaciones o))::text);
            """)

        def begin_holder(query, label):
            nonlocal lock_process, lock_log
            lock_log = (output / f'{label}.log').open('w')
            lock_process = subprocess.Popen([
                'docker', 'exec', '-e', 'PGAPPNAME=' + label, '-u', 'postgres', database,
                'psql', '-X', '-At', '-v', 'ON_ERROR_STOP=1', '-c',
                'BEGIN; ' + query + '; SELECT pg_sleep(6); COMMIT;'
            ], text=True, stdout=lock_log, stderr=subprocess.STDOUT)
            for _ in range(80):
                ready = sql("SELECT EXISTS(SELECT 1 FROM pg_stat_activity WHERE application_name='"
                            + label + "' AND wait_event='PgSleep' AND xact_start IS NOT NULL);")
                if ready == 't':
                    return
                if lock_process.poll() is not None:
                    break
                time.sleep(0.05)
            raise AssertionError('La conexión independiente no conservó el bloqueo de prueba')

        def end_holder():
            nonlocal lock_process, lock_log
            require(lock_process.wait(timeout=10) == 0, 'La conexión bloqueadora termina correctamente')
            lock_process = None
            lock_log.close()
            lock_log = None

        try:
            for image in (POSTGRES, POSTGREST):
                if run('docker', 'image', 'inspect', image, check=False).returncode:
                    run('docker', 'pull', image)
            with tempfile.TemporaryDirectory(prefix='myg-sin-espera-') as temporary:
                temporary = Path(temporary)
                packages = args.paquetes
                if packages is None:
                    packages = temporary / 'paquetes'
                    command = ['dotnet', 'run', '--project', str(REPO / 'supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj'), '-c', 'Release']
                    if os.environ.get('MYG_PRUEBAS_SIN_COMPILAR') == '1':
                        command.extend(['--no-build', '--no-restore'])
                    run(*command, '--', str(packages))
                require((packages / 'compacto_cliente.json').is_file(), 'Se dispone del fixture compacto sintético')
                run('docker', 'network', 'create', '--internal', network)
                created_network = True
                run('docker', 'run', '--detach', '--rm', '--name', database, '--network', network,
                    '--memory=512m', '--memory-swap=512m', '--cpus=1',
                    '--tmpfs', '/var/lib/postgresql/data:rw,size=256m',
                    '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', POSTGRES,
                    '-c', 'shared_buffers=32MB', '-c', 'work_mem=1MB', '-c', 'max_connections=20')
                containers.append(database)
                for attempt in range(60):
                    if run('docker', 'exec', database, 'pg_isready', '-U', 'postgres', check=False).returncode == 0:
                        break
                    if attempt == 59:
                        raise RuntimeError('PostgreSQL desechable no inició')
                    time.sleep(0.5)
                run('docker', 'exec', '-u', 'root', database, 'mkdir', '-p', '/pruebas')
                run('docker', 'cp', str(REPO / 'supabase'), database + ':/pruebas/supabase')
                run('docker', 'cp', str(packages), database + ':/pruebas/paquetes')
                run('docker', 'exec', '-u', 'root', database, 'chmod', '-R', 'a+rX', '/pruebas')
                sql_file('/pruebas/supabase/pruebas/usuarios_myg_roles.sql')
                sql_file('/pruebas/supabase/migraciones/20261026_publicacion_ligera.sql')
                sql_file('/pruebas/supabase/pruebas/publicacion_sin_espera.sql')
                sql_checks = int(sql('SELECT count(*)-(SELECT resultados_antes FROM qa.antes_sin_espera) FROM qa.resultados;'))
                require(sql_checks > 0, 'Se ejecutan comprobaciones SQL nuevas, incluida repetición y preservación de metadatos')
                # Después de verificar que la migración preserva los plazos, quitar
                # SOLO en el laboratorio el lock_timeout personalizado de 750 ms.
                # El rechazo rápido debe depender de NOWAIT, no de ese otro límite.
                sql("ALTER FUNCTION public.myg_nube_crear_confirmacion(uuid,text,jsonb,text) SET lock_timeout='0';")
                require(sql("SELECT proconfig @> ARRAY['lock_timeout=0'] FROM pg_proc WHERE oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure;") == 't',
                        'El control HTTP usa lock_timeout=0 para aislar el efecto de NOWAIT')
                sql("""
                  CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
                    SELECT coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub',
                      nullif(current_setting('request.jwt.claim.sub',true),''))::uuid;
                  $$;
                  CREATE ROLE myg_nowait_http_login LOGIN NOINHERIT;
                  GRANT anon,authenticated TO myg_nowait_http_login;
                """)
                run('docker', 'run', '--detach', '--rm', '--name', api, '--network', network,
                    '--memory=512m', '--memory-swap=512m', '--cpus=1',
                    '-e', f'PGRST_DB_URI=postgres://myg_nowait_http_login@{database}:5432/postgres',
                    '-e', 'PGRST_DB_SCHEMAS=public', '-e', 'PGRST_DB_ANON_ROLE=anon',
                    '-e', 'PGRST_JWT_SECRET=' + SECRET.decode(), POSTGREST)
                containers.append(api)
                address = run('docker', 'inspect', api, '--format', '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}').stdout.strip()
                url = f'http://{address}:3000/'
                for attempt in range(60):
                    try:
                        with opener.open(url, timeout=2) as response:
                            if response.status == 200:
                                break
                    except (urllib.error.URLError, TimeoutError):
                        pass
                    if attempt == 59:
                        raise RuntimeError('PostgREST desechable no inició')
                    time.sleep(0.5)

                def rpc(name, body, user=OWNER, expected=200):
                    headers = {'Content-Type': 'application/json'}
                    if user:
                        headers['Authorization'] = 'Bearer ' + token(user)
                    encoded = json.dumps(body, ensure_ascii=False, separators=(',', ':')).encode()
                    started = time.monotonic()
                    request = urllib.request.Request(url + 'rpc/' + name, data=encoded, headers=headers, method='POST')
                    try:
                        with opener.open(request, timeout=15) as response:
                            status, content = response.status, response.read()
                    except urllib.error.HTTPError as error:
                        status, content = error.code, error.read()
                    elapsed = time.monotonic() - started
                    result = json.loads(content)
                    require(status == expected, f'{name} devuelve HTTP {expected}')
                    requests.append({'rpc': name, 'status': status, 'seconds': round(elapsed, 4),
                                     'request_bytes': len(encoded), 'response_bytes': len(content),
                                     'sqlstate': result.get('code') if isinstance(result, dict) else None})
                    return result, elapsed

                package = json.loads((packages / 'compacto_cliente.json').read_text())
                body = {'p_id': PROJECT, 'p_nombre': 'Sin espera', 'p_contenido': package, 'p_alcance': 'base'}
                before = snapshot()
                expected_ack, _ = rpc('myg_nube_revision', {'p_id': PROJECT})
                begin_holder(f"SELECT id FROM public.myg_nube_proyectos WHERE id='{PROJECT}' FOR UPDATE", 'myg-nowait-row-holder')
                probe, probe_seconds = rpc('myg_nube_estado_publicacion', {'p_id': PROJECT})
                require(probe == {'estado': 'existente'} and probe_seconds < 2,
                        'La sonda mantiene su contrato informativo sin esperar la fila')
                busy, row_seconds = rpc('myg_nube_crear_confirmacion', body, expected=500)
                require(busy.get('code') == '55006' and busy.get('message') == 'MYG_RECURSO_OCUPADO' and row_seconds < 2,
                        'El propietario recibe recurso ocupado antes de liberar el bloqueo de fila')
                denied, denied_seconds = rpc('myg_nube_crear_confirmacion', body, user=OTHER, expected=403)
                require(denied.get('code') == '42501' and denied_seconds < 2,
                        'Un usuario ajeno conserva acceso denegado incluso con la fila bloqueada')
                require(snapshot() == before, 'Los rechazos por bloqueo y permisos no modifican datos ni historial')
                end_holder()
                replay, _ = rpc('myg_nube_crear_confirmacion', body)
                require(replay == expected_ack and 'contenido' not in replay,
                        'Después de liberar la fila el mismo UUID confirma metadatos correctos')
                require(snapshot() == before, 'El replay posterior no duplica ni cambia proyectos, miembros, operaciones o historial')
                wrong = dict(body, p_contenido=dict(package, documento=dict(package['documento'], Nombre='DISTINTO')))
                rejected, _ = rpc('myg_nube_crear_confirmacion', wrong, expected=400)
                require(rejected.get('code') == '22023' and snapshot() == before,
                        'La corrección mantiene la comparación completa de la creación inicial')
                anonymous, _ = rpc('myg_nube_crear_confirmacion', body, user=None, expected=401)
                require(anonymous.get('code') == '42501', 'La corrección mantiene el rechazo de ejecución anónima')

                begin_holder("SELECT pg_advisory_xact_lock(hashtextextended('myg-nube-crear:" + LOCKED_NEW + "',0))", 'myg-nowait-advisory-holder')
                processing, _ = rpc('myg_nube_estado_publicacion', {'p_id': LOCKED_NEW})
                require(processing == {'estado': 'procesando'}, 'La sonda sigue detectando otra creación en curso')
                busy, advisory_seconds = rpc('myg_nube_crear_confirmacion',
                    {'p_id': LOCKED_NEW, 'p_nombre': 'En curso', 'p_contenido': [], 'p_alcance': 'base'}, expected=500)
                require(busy.get('code') == '55006' and busy.get('message') == 'MYG_PUBLICACION_EN_CURSO' and advisory_seconds < 2,
                        'El advisory lock anterior sigue rechazando antes de validar contenido')
                end_holder()
                require(snapshot() == before, 'Los rechazos concurrentes no dejan una creación parcial')

                # Rechazar instalación sin requisitos y una función personalizada desconocida.
                run('docker', 'exec', '-u', 'postgres', database, 'createdb', '-T', 'template0', 'myg_sin_espera_sin_base')
                missing = sql_file(MIGRATION, db='myg_sin_espera_sin_base', check=False)
                require(missing.returncode != 0 and '55000' in missing.stdout
                        and sql("SELECT to_regprocedure('public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)') IS NULL;", db='myg_sin_espera_sin_base') == 't',
                        'Sin migración 26 la instalación falla sin crear funciones')
                sql("""
                  DO $$ DECLARE f text; s text; BEGIN
                    SELECT pg_get_functiondef(p.oid),p.prosrc INTO f,s FROM pg_proc p
                    WHERE p.oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure;
                    EXECUTE replace(f,s,s||E'\n-- Personalización sintética que no debe sobrescribirse\n');
                  END $$;
                """)
                custom_before = sql("SELECT md5(to_jsonb(p)::text) FROM pg_proc p WHERE p.oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure;")
                custom = sql_file(MIGRATION, check=False)
                require(custom.returncode != 0 and '55000' in custom.stdout
                        and sql("SELECT md5(to_jsonb(p)::text) FROM pg_proc p WHERE p.oid='public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure;") == custom_before
                        and snapshot() == before,
                        'Una versión personalizada se rechaza sin cambiar función, ACL, configuración o datos')
                memory_lines = run('docker', 'exec', database, 'cat', '/sys/fs/cgroup/memory.events').stdout.splitlines()
                events = dict(line.split() for line in memory_lines)
                require(events.get('oom_kill') == '0', 'Las verificaciones no agotan memoria en el contenedor PostgreSQL de 512 MiB')
                result = {'status': 'passed', 'sql_checks': sql_checks, 'python_checks': len(checks),
                          'http_requests': len(requests), 'row_busy_seconds': round(row_seconds, 4),
                          'other_user_seconds': round(denied_seconds, 4), 'advisory_busy_seconds': round(advisory_seconds, 4),
                          'postgres_limit_bytes': 512 * 1024 * 1024, 'postgres_oom_kill': 0,
                          'requests': requests, 'checks': checks,
                          'scope': 'Regresión funcional de bloqueo de fila; no prueba publicar 200 MiB en Nano ni la causa de HTTP 502/520 reales.'}
                (output / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
                print(json.dumps({k: v for k, v in result.items() if k not in ('requests', 'checks')}, ensure_ascii=False, indent=2))
        finally:
            if lock_process is not None and lock_process.poll() is None:
                lock_process.terminate()
                lock_process.wait(timeout=10)
            if lock_log is not None:
                lock_log.close()
            for name in reversed(containers):
                (output / (name.rsplit('-', 1)[-1] + '.log')).write_text(run('docker', 'logs', name, check=False).stdout)
                run('docker', 'rm', '-f', name, check=False)
            if created_network:
                run('docker', 'network', 'rm', network, check=False)


if __name__ == '__main__':
    main()
