using System;
using System.Diagnostics;
using System.IO;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace MYG.Conector;

[Transaction(TransactionMode.Manual)]
public sealed class AbrirPresupuestos : IExternalCommand
{
    public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
    {
        try
        {
            string configuracion = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "MYG", "TablasAutomaticas", "desktop_path.txt");
            string ruta = File.Exists(configuracion) ? File.ReadAllText(configuracion).Trim() :
                Path.Combine(Path.GetDirectoryName(typeof(AbrirPresupuestos).Assembly.Location), "MYG.Desktop.exe");
            if (!File.Exists(ruta))
            {
                using var d = new System.Windows.Forms.OpenFileDialog
                { Title = "Seleccione el ejecutable de MYG Presupuestos", Filter = "Aplicación MYG (*.exe)|*.exe", CheckFileExists = true };
                if (d.ShowDialog() != System.Windows.Forms.DialogResult.OK) return Result.Cancelled;
                ruta = Path.GetFullPath(d.FileName); Directory.CreateDirectory(Path.GetDirectoryName(configuracion));
                File.WriteAllText(configuracion, ruta);
            }
            Process.Start(new ProcessStartInfo { FileName = ruta, UseShellExecute = true }); return Result.Succeeded;
        }
        catch (Exception ex) { message = ex.Message; return Result.Failed; }
    }
}
