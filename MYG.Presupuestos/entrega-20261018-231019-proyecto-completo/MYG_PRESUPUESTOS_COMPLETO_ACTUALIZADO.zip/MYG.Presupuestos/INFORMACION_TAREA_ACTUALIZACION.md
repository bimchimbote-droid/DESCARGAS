# Proyecto completo actualizado: Información de tarea

Base: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit `19fe32ed03b359b1e87645c1be72e09e1898d565`.
La implementación existente se conserva íntegra. Antes del cierre se guardó el respaldo Git `b00340b37bfcbf3a5e25df2e28eb5fa8563b9347`, en la rama local `backup/informacion-tarea-20261018-2307`, junto con un ZIP completo y un Git bundle verificado.

La rama de entrega es `codex/informacion-tarea-completo-20261018`. La entrega solicitada es **el proyecto completo**, no un parche ni sólo los archivos cambiados. La rama `main` no se sustituye ni se fusiona automáticamente.

## Qué se implementó

En la vista CPM, pulse **Información de tarea**. Se abre un panel bajo el Gantt que sigue la tarea seleccionada y puede ocultarse sin cerrar el proyecto. También puede abrirlo con doble clic. El menú contextual mantiene **Editar campos generales…**.

- **Planificación:** duración y cuadrillas iniciales, reprogramación y cuadrillas resultantes, ocho restricciones de fecha, programación manual/automática, avance, responsables y notas.
- **Dependencias:** selector con búsqueda por nombre/código/fila, jerarquía, vínculos FC/FF/CF/CC, desfases positivos o negativos y eliminación. Se guardan identidades estables, aunque cambie el número de fila.
- **Partes:** división de la duración con intervalos laborables; edición de inicio, duración, cantidad y porcentaje valorizado; fin calculado y totales. Se validan solapes, duración total, cantidades y 100 % exacto.
- **Recursos programados:** insumos reales del ACU de la tarea o sus descendientes, cantidades y valorizado, filtros y escalas día/semana/mes. La opción Recurso x cuadrilla muestra la dotación verificable del ACU multiplicada por las cuadrillas de tarea y su máximo simultáneo; las celdas sin información suficiente quedan vacías con explicación. La vista seleccionada puede imprimirse.
- **Tableros de acción y Curva S:** distribución programada, filtros de recurso/tipo, acumulados, cuadrícula, etiquetas y consulta de puntos.
- **Opciones generales:** colores de ruta crítica y vínculos, apariencia/avance, textos de barra, posición de mensajes, rango de impresión, orientación, leyenda, información de página y papel A2/A3/A4/A5/A6/B4/B5/Carta/Oficio en el motor de reportes.
- **Persistencia:** información de tarea y preferencias de presentación dentro del proyecto MYG/SQLite; no se requiere modificar el esquema de bases existentes. Los cambios se aplican sobre copias y admiten el historial existente.
- **Exportación:** restricciones nativas de Microsoft Project correctamente mapeadas; partes en el modelo y en la exportación directa; reportes Gantt, valorizado y adquisiciones respetan las pausas.

Se decodificaron los 2.597 cuadros del video, se registraron sus transiciones y se inspeccionaron capturas originales y menús breves. Referencias visuales: recursos 1–25 s; planificación, dependencias y partes 25–52 s; BI 52–56 s; Curva S 56–72 s; opciones generales 72–86 s. El análisis corresponde a lo visible; no se transcribió la pista de audio.

## Instalación manual

1. Cierre el software y respalde o confirme sus cambios locales en Visual Studio. Respalde también sus proyectos de trabajo.
2. Descargue `MYG_PRESUPUESTOS_COMPLETO_ACTUALIZADO.zip` y extráigalo en una carpeta nueva. Dentro encontrará `MYG.Presupuestos/MYG.Presupuestos.sln`, todos los proyectos, fuentes y recursos.
3. Abra esa solución en Visual Studio con soporte para .NET 10. Restaure, compile y ejecute las pruebas con los comandos siguientes.
4. Para conservar su copia Git actual, utilice la rama de entrega desde su clon después de respaldar sus cambios, o compare y copie el contenido completo conservando su carpeta `.git`. El ZIP de fuentes no incluye metadatos Git. No sustituya modificaciones locales sin compararlas.
5. En Windows, abra un proyecto de prueba y complete la comprobación manual indicada más abajo antes de trabajar con datos definitivos.

El ZIP contiene el proyecto completo actualizado, incluidos los archivos que no necesitaron cambios. Excluye `.git`, `.vs`, `bin`, `obj`, paquetes restaurables, credenciales y bases privadas. No es una instalación ejecutable: es el código fuente completo listo para abrir y compilar.

## Compilación y comprobación

Se utiliza C#, .NET SDK **10.0.100**, SQLite y la solución existente. Desde la raíz:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

El indicador de referencias permite compilar el conector sin tener Revit instalado. Para ejecutarlo se necesita Windows y Revit 2027; no instala Revit. La compilación normal en una máquina con Revit puede usar sus DLL locales sin ese indicador.

La suite de consola completó **553 comprobaciones aprobadas**. El informe se genera en `MYG.Pruebas/bin/Release/net10.0/resultado_qa.json`. La solución completa se compila en Release. Las pruebas de Named Pipes de Windows y del contenido privado LLACUSBAMBA se omiten en esta máquina Linux; no se cuentan como aprobadas.

Las pruebas de interfaz se añadieron y compilaron, pero deben **ejecutarse en Windows**:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --cronograma
```

Compruebe manualmente: abrir/ocultar panel; seleccionar tareas y resúmenes; cambiar reprogramación, restricciones, dependencias y partes; guardar/cancelar borradores; deshacer/rehacer; cerrar y reabrir SQLite; consultar recursos, BI y curva S; imprimir en el papel elegido y abrir la exportación en Microsoft Project. No se ejecutaron aquí WinForms/WPF, Microsoft Project COM, impresión física ni Revit.

## Límites y compatibilidad

- Las nuevas duraciones y partes utilizan días laborables enteros y fin inclusivo. Los tramos importados fraccionarios conservan sus datos; convertirlos exige una distribución compatible con el calendario.
- Cambiar la duración restablece una división que haya quedado obsoleta y recalcula cuadrillas desde la duración inicial. Vuelva a dividir si necesita pausas.
- Las fechas obligatorias y las tareas manuales conservan su fecha y notifican conflictos; un límite incompatible no elimina dependencias silenciosamente.
- Los códigos de restricciones de Delphin sin correspondencia documentada se notifican y se conservan en el archivo original; no se reinterpretan como restricciones MYG. Si la fuente no informa cuadrillas, se utiliza el valor inicial configurable 1; no se reconstruye un historial nativo.
- La exportación XML Project informa en notas la distribución y su limitación para representar pausas. La exportación directa de Project usa divisiones y necesita verificación real en Windows.
- Los gráficos representan programación, no avance ejecutado. Las cantidades con unidades distintas no se suman como si fueran una sola unidad.
- Para mantener la respuesta de la tabla se muestran hasta 180 períodos. Ajuste el rango o la escala; los totales completos se identifican expresamente.
- La información de número/total del pie se refiere a hojas del informe, no a páginas físicas que pueda producir la impresora.
- Algunas opciones de papel del desplegable original del video son variantes de tamaños; se implementan los formatos indicados arriba.

## Rama GitHub y cambios posteriores

El resultado definitivo se conserva en la rama `codex/informacion-tarea-completo-20261018` de `bimchimbote-droid/MYG.Presupuestos`, conforme a su autorización. El ZIP completo se entrega por separado en `bimchimbote-droid/DESCARGAS`. Ninguna de estas operaciones aplica automáticamente los cambios a su PC.

En su clon Git, después de guardar sus cambios locales, puede obtener la rama con:

```powershell
git fetch origin
git switch --track origin/codex/informacion-tarea-completo-20261018
```

Si ya tiene una rama local con ese nombre, selecciónela en Visual Studio en lugar de crearla otra vez. Abra **Cambios de Git** para revisar sus modificaciones posteriores, crear commits y hacer Push a la rama que elija. Revise una eventual integración con `main` por separado; esta entrega no hace esa fusión.
