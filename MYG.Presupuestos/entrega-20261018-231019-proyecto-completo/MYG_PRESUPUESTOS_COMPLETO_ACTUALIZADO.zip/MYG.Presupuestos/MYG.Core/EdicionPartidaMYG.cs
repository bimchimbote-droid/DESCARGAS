using System;
using System.Globalization;
using System.Linq;

namespace MYG_2027;

// Ediciones de la tabla principal. Las fuentes de metrado conservan sus datos
// aunque el usuario elija una cantidad directa, y las instancias del editor
// no se sustituyen al validar el cambio.
public static class MYGEdicionPartida
{
    public const decimal CantidadMaxima = 1000000000000m;

    public static void CambiarCantidad(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, decimal cantidad) =>
        CambiarCantidad(presupuesto, partida, cantidad, null);

    public static void CambiarCantidad(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, decimal cantidad,
        Action antesDeAplicar)
    {
        if (!CantidadValida(cantidad))
            throw new InvalidOperationException("La cantidad debe estar entre 0 y 1,000,000,000,000.00 y tener como máximo dos decimales.");
        var trabajo = Preparar(presupuesto, partida, out var original, out var copia);
        copia.Costos.Cantidad = cantidad;
        copia.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        ValidarCambio(trabajo);
        antesDeAplicar?.Invoke();
        original.Costos ??= new MYGDatosPartida();
        original.Costos.Cantidad = cantidad;
        original.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
    }

    public static void CambiarUnidad(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, string unidad) =>
        CambiarUnidad(presupuesto, partida, unidad, null);

    public static void CambiarUnidad(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, string unidad,
        Action antesDeAplicar)
    {
        unidad = unidad?.Trim();
        if (string.IsNullOrWhiteSpace(unidad)) throw new InvalidOperationException("Seleccione una unidad de medida.");
        var trabajo = Preparar(presupuesto, partida, out var original, out var copia);
        if (!string.IsNullOrWhiteSpace(original.IdInternoDelphin))
            throw new InvalidOperationException("La unidad oficial se actualiza desde Delphin. Edite únicamente los datos de costo en MYG.");
        if (copia.Costos.MetradosBIM.Count > 0 && !MYGProyectoStorage.MismaUnidad(copia.Unidad, unidad))
            throw new InvalidOperationException("Retire los metrados BIM de la partida antes de cambiar su unidad.");
        copia.Unidad = unidad;
        ValidarCambio(trabajo);
        antesDeAplicar?.Invoke();
        original.Unidad = unidad;
    }

    internal static bool CantidadValida(decimal cantidad) => cantidad >= 0 && cantidad <= CantidadMaxima &&
        decimal.Round(cantidad, 2, MidpointRounding.AwayFromZero) == cantidad;

    private static MYGPresupuestoDocumento Preparar(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida,
        out ItemPresupuestoDelphin original, out ItemPresupuestoDelphin copia)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(partida);
        original = presupuesto.Items?.FirstOrDefault(x => x != null &&
            string.Equals(x.Id, partida.Id, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("La partida ya no pertenece a este presupuesto.");
        var trabajo = MYGProyectoStorage.Copia(presupuesto);
        MYGProyectoStorage.ValidarPresupuesto(trabajo);
        string id = original.Id;
        copia = trabajo.Items.Single(x => string.Equals(x.Id, id, StringComparison.OrdinalIgnoreCase));
        if (MYGProyectoStorage.EsTitulo(copia)) throw new InvalidOperationException("Seleccione una partida, no un título.");
        return trabajo;
    }

    private static void ValidarCambio(MYGPresupuestoDocumento trabajo)
    {
        MYGProyectoStorage.ValidarPresupuesto(trabajo);
        try { MYGMotorPresupuestos.Resumen(trabajo); }
        catch (OverflowException ex)
        { throw new InvalidOperationException("La cantidad o el importe supera el rango de cálculo permitido.", ex); }
    }
}

public static class MYGFormatoPresupuesto
{
    public static string Cantidad(decimal cantidad) => cantidad.ToString("N2", CultureInfo.InvariantCulture);
    public static string Dinero(decimal importe) => importe.ToString("N2", CultureInfo.InvariantCulture);

    public static bool IntentarCantidad(string texto, out decimal cantidad) =>
        IntentarCantidad(texto, CultureInfo.CurrentCulture, out cantidad);

    public static bool IntentarCantidad(string texto, CultureInfo cultura, out decimal cantidad)
    {
        cantidad = 0;
        texto = texto?.Trim() ?? "";
        if (texto.StartsWith('+')) texto = texto[1..];
        if (texto.Length == 0 || texto.Length > 128) return false;
        var formato = (cultura ?? CultureInfo.CurrentCulture).NumberFormat;
        decimal valor;
        bool leido = IntentarFormato(texto, formato.NumberDecimalSeparator, formato.NumberGroupSeparator, out valor) ||
            IntentarFormato(texto, ".", ",", out valor) || IntentarFormato(texto, ",", ".", out valor);
        if (!leido || !MYGEdicionPartida.CantidadValida(valor)) return false;
        cantidad = valor;
        return true;
    }

    private static bool Digitos(string texto) => texto.Length > 0 && texto.All(x => x is >= '0' and <= '9');

    private static bool IntentarFormato(string texto, string separadorDecimal, string separadorMiles, out decimal valor)
    {
        valor = 0;
        if (string.IsNullOrEmpty(separadorDecimal) || separadorDecimal == separadorMiles) return false;
        var partes = texto.Split(separadorDecimal, StringSplitOptions.None);
        if (partes.Length > 2 || partes.Length == 2 && (!Digitos(partes[1]) || partes[1].Length > 2)) return false;
        string entero = partes[0];
        if (!string.IsNullOrEmpty(separadorMiles) && entero.Contains(separadorMiles, StringComparison.Ordinal))
        {
            var grupos = entero.Split(separadorMiles, StringSplitOptions.None);
            // Un solo separador y tres cifras finales ("1,234") puede ser
            // decimal o miles: exigir decimales explícitos evita reinterpretarlo.
            if (partes.Length == 1 && grupos.Length < 3 || grupos[0].Length is < 1 or > 3 ||
                !Digitos(grupos[0]) || grupos.Skip(1).Any(x => x.Length != 3 || !Digitos(x))) return false;
            entero = string.Concat(grupos);
        }
        else if (!Digitos(entero)) return false;
        string normalizado = entero + (partes.Length == 2 ? "." + partes[1] : "");
        return decimal.TryParse(normalizado, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out valor);
    }
}
