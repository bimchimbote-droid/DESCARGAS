using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace MYG_2027;

// Analizador aritmético deliberadamente pequeño: nunca ejecuta código ni funciones externas.
internal sealed class MYGFormulaFilaResumen
{
    private readonly string texto;
    private readonly IReadOnlyDictionary<string, decimal> variables;
    private readonly bool evaluar;
    private int posicion;
    private int profundidad;

    private MYGFormulaFilaResumen(string formula, IReadOnlyDictionary<string, decimal> variables, bool evaluar)
    {
        texto = formula?.Trim();
        if (string.IsNullOrEmpty(texto) || texto.Length > 4096)
            throw new InvalidDataException("Indique una fórmula de hasta 4096 caracteres.");
        if (texto[0] == '=') texto = texto[1..];
        this.variables = variables;
        this.evaluar = evaluar;
    }

    internal static bool EsIdentificador(string valor)
    {
        if (string.IsNullOrEmpty(valor) || valor.Length > 64 || !InicioIdentificador(valor[0])) return false;
        for (int n = 1; n < valor.Length; n++)
            if (!InicioIdentificador(valor[n]) && !char.IsAsciiDigit(valor[n])) return false;
        return true;
    }

    private static bool InicioIdentificador(char caracter) => char.IsAsciiLetter(caracter) || caracter == '_';

    internal static decimal Resolver(string formula, IReadOnlyDictionary<string, decimal> variables, bool evaluar)
    {
        var analizador = new MYGFormulaFilaResumen(formula, variables, evaluar);
        try
        {
            decimal resultado = analizador.Expresion();
            analizador.Espacios();
            if (analizador.posicion != analizador.texto.Length) throw analizador.Error("Símbolo no admitido");
            return resultado;
        }
        catch (OverflowException ex)
        { throw new InvalidDataException("El resultado de la fórmula excede el rango decimal permitido.", ex); }
    }

    private InvalidDataException Error(string mensaje) =>
        new(mensaje + " en la fórmula (posición " + (posicion + 1) + ").");

    private void Espacios()
    { while (posicion < texto.Length && char.IsWhiteSpace(texto[posicion])) posicion++; }

    private bool Tomar(char caracter)
    {
        Espacios();
        if (posicion >= texto.Length || texto[posicion] != caracter) return false;
        posicion++;
        return true;
    }

    private decimal Expresion()
    {
        decimal valor = Producto();
        while (true)
        {
            if (Tomar('+')) { decimal otro = Producto(); if (evaluar) valor += otro; }
            else if (Tomar('-')) { decimal otro = Producto(); if (evaluar) valor -= otro; }
            else return valor;
        }
    }

    private decimal Producto()
    {
        decimal valor = Primario();
        while (true)
        {
            if (Tomar('*')) { decimal otro = Primario(); if (evaluar) valor *= otro; }
            else if (Tomar('/'))
            {
                decimal otro = Primario();
                if (evaluar)
                {
                    if (otro == 0) throw Error("No se puede dividir entre cero");
                    valor /= otro;
                }
            }
            else return valor;
        }
    }

    private decimal Primario()
    {
        if (++profundidad > 64) throw Error("La fórmula contiene demasiados niveles anidados");
        try
        {
            if (Tomar('+')) return Primario();
            if (Tomar('-')) return -Primario();
            if (Tomar('('))
            {
                decimal valor = Expresion();
                if (!Tomar(')')) throw Error("Falta cerrar un paréntesis");
                return valor;
            }
            Espacios();
            if (posicion >= texto.Length) throw Error("Se esperaba un número o identificador");
            int inicio = posicion;
            if (InicioIdentificador(texto[posicion]))
            {
                posicion++;
                while (posicion < texto.Length &&
                    (InicioIdentificador(texto[posicion]) || char.IsAsciiDigit(texto[posicion]))) posicion++;
                string nombre = texto[inicio..posicion];
                if (!variables.TryGetValue(nombre, out decimal valor))
                    throw Error("El identificador '" + nombre + "' no existe o pertenece a una fila posterior");
                return evaluar ? valor : 0;
            }
            while (posicion < texto.Length &&
                (char.IsAsciiDigit(texto[posicion]) || texto[posicion] == '.' || texto[posicion] == ',')) posicion++;
            if (posicion == inicio || !decimal.TryParse(texto[inicio..posicion].Replace(',', '.'),
                NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal numero))
                throw Error("Número no válido");
            return evaluar ? numero : 0;
        }
        finally { profundidad--; }
    }
}
