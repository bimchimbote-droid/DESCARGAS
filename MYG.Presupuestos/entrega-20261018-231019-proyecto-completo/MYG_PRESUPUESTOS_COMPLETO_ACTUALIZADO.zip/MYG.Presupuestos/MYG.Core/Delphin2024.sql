-- Esquema estructural Delphin 2024. Sólo DDL; no contiene proyectos ni credenciales.
CREATE TABLE IF NOT EXISTS CAJA (
  id_movimiento integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  tipo_movimiento VARCHAR(15) NOT NULL, 
  fecha_movimiento TIMESTAMP, 
  id_persona NUMERIC(18, 0), 
  nombre_persona VARCHAR(100), 
  descripcion_movimiento VARCHAR(200), 
  id_modalidadpago VARCHAR(10), 
  numero_referencia VARCHAR(50), 
  id_documento VARCHAR(15), 
  serie_documento VARCHAR(15), 
  numero_documento VARCHAR(15), 
  total_movimiento NUMERIC, 
  moneda VARCHAR(15), 
  total_efectivo NUMERIC, 
  moneda_efectivo VARCHAR(10), 
  tipo_cambio NUMERIC(18, 10), 
  monto_vuelto NUMERIC, 
  id_sucursal VARCHAR(15), 
  id_caja VARCHAR(10), 
  ultimo_movimiento CHAR(1) DEFAULT ('S'), 
  id_concepto VARCHAR(50), 
  estado_movimiento CHAR(1) DEFAULT ('S'), 
  fecha_registro TIMESTAMP, 
  nombre_host VARCHAR(50), 
  nombre_hostanulacion VARCHAR(120), 
  id_usuarioanulacion VARCHAR(15), 
  estado_cargadoabonado CHAR(1) DEFAULT ('N'), 
  debe_soles NUMERIC, 
  haber_soles NUMERIC, 
  saldo_soles NUMERIC, 
  fecha_anulacion TIMESTAMP, 
  monto_interes NUMERIC, 
  dias_interes INTEGER, 
  id_sesion NUMERIC(18, 0), 
  detalle TEXT, 
  id_boletafactura NUMERIC(18, 0), 
  id_cuentadebe NUMERIC(18, 0), 
  id_cuentahaber NUMERIC(18, 0), 
  id_subdebe NUMERIC(18, 0), 
  id_subhaber NUMERIC(18, 0), 
  es_extorno CHAR(1), 
  ruc_persona VARCHAR(20), 
  dni_persona VARCHAR(20), 
  fecha_documento TIMESTAMP, 
  id_usuario VARCHAR(10), 
  id_documentoventa varchar(10), 
  serie_venta varchar(10), 
  numero_venta varchar(10), 
  fecha_modificacion date, 
  id_usuariomodificacion varchar(10), 
  id_cajasesion varchar(12), 
  monto_devuelto decimal(10,2), 
  total_base decimal(10,2), id_proyecto char(12));
CREATE TABLE IF NOT EXISTS DETALLE_DEVOLUCION(
	id_detalledevolucion integer primary key autoincrement,
	id_producto char(12) NULL,
	cantidad numeric(18, 4) NULL,
	observacion varchar(100) NULL,
	id_devolucion numeric(18, 0) NULL,
	requiere_serie varchar(1) NULL,
	serie_completado varchar(1) NULL,
	id_detallesalida numeric(18, 0) NULL,
	id_unidad char(12) NULL,
	cantidad_detalle decimal(18, 4) NULL,
	estado_cargado varchar(1) NULL,
	costo_unitario decimal(10, 2) NULL,
	date_version date NULL
  );
CREATE TABLE IF NOT EXISTS DETALLE_NOTA_COMPRA (
	id_detallenotacompra integer constraint PK_DETALLE_NOTA_COMPRA primary key autoincrement NOT NULL ,
	id_producto varchar (50)  NULL ,
	cantidad numeric(18, 4) NULL ,
	observacion varchar (200)  NULL ,
	id_notacompra numeric(18,0)  NULL ,
	id_unidad varchar (12)  NULL,
	precio_unitario decimal(10,2),
	subtotal decimal(10,2),
	monto_descuento decimal(10,2),
	total_detalle decimal(10,2),
	estado_detalle varchar(1),
	id_detallecomprafact numeric,  
  costo_unitario decimal(10,2), 
  estado_cargado varchar(1), ajuste_precio varchar(1),

	CONSTRAINT FK_DETALLE_NOTA_COMPRA_PRODUCTO foreign key(id_producto)
	references PRODUCTO(id_producto),

	CONSTRAINT FK_DETALLE_NOTA_COMPRA foreign key(id_notacompra)
	references NOTA_COMPRA(id_notacompra),
	
	CONSTRAINT FK_DETALLE_NOTA_UNIDAD foreign key(id_unidad)
	references UNIDAD(id_unidad),
	
	constraint FK_DETALLE_NOTA_DETALLE_NC foreign key(id_detallecomprafact) 
	references detalle_compra_fact(id_detallecomprafact)

);
CREATE TABLE IF NOT EXISTS [DETALLE_PEDIDO] (
  [id_detallepedido] INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  [id_producto] VARCHAR(50), 
  [id_plan] VARCHAR(50), 
  [id_permanencia] VARCHAR(50), 
  [cantidad] NUMERIC(18, 10), 
  [precio_pedido] NUMERIC, 
  [subtotal_pedido] NUMERIC, 
  [porcentaje_descuento] NUMERIC(18, 10), 
  [monto_descuento] NUMERIC, 
  [total_detalle] NUMERIC, 
  [observacion] VARCHAR(200), 
  [id_pedido] NUMERIC(18, 0), 
  [requiere_serie] CHAR(1), 
  [estado_preparado] CHAR(1) DEFAULT ('N'), 
  [incluido] CHAR(1), 
  [orden] NUMERIC(18, 0), 
  [cantidad_activada] NUMERIC(18, 0) DEFAULT 0, 
  [cantidad_facturada] NUMERIC(18, 10) DEFAULT 0, 
  [cantidad_devuelta] NUMERIC(18, 10) DEFAULT 0, 
  [estado_detalle] CHAR(1) DEFAULT ('S'), 
  [es_porcentaje] CHAR(1), 
  [id_estacion] VARCHAR(50), 
  [total_descuento] NUMERIC, 
  [porcentaje_igvdetalle] NUMERIC(18, 10), 
  [monto_igvdetalle] NUMERIC, 
  [valor_ventadetalle] NUMERIC, 
  [cantidad_despachada] NUMERIC(18, 10) DEFAULT 0, 
  [precio_unitario] NUMERIC, 
  [precio_conigv] CHAR(1), 
  [cantidad_recibida] NUMERIC(18, 0) DEFAULT 0, 
  [id_unidad] VARCHAR(10), 
  [valor_salida] NUMERIC DEFAULT 0, 
  [costo_salida] NUMERIC DEFAULT 0, 
  [cantidad_vendida] NUMERIC(18, 0) DEFAULT 0, 
  [id_detalleparent] NUMERIC(18, 0), 
  [fecha_pago_d] TIMESTAMP, 
  [estado_pagado_d] CHAR(1), 
  [monto_pagado_d] NUMERIC, 
  [monto_pagadoefectivo_d] decimal(10,4), 
  [monto_pagadotarjeta_d] decimal(10,4), 
  [plan_anterior] varchar(80), 
  [cargo_fijoanterior] decimal(10,2), 
  [numero_anterior] varchar(30), 
  [cargo_datos] decimal(10,2), descuento_manual varchar(1), lote_completado char(1), requiere_lote char(1));
CREATE TABLE IF NOT EXISTS DEVOLUCION (
  id_devolucion integer PRIMARY KEY AUTOINCREMENT, 
  id_documento VARCHAR(10) NOT NULL, 
  serie_documento VARCHAR(10) NOT NULL, 
  numero_documento VARCHAR(20), 
  fecha_documento TIMESTAMP, 
  observacion VARCHAR(100), 
  id_usuario VARCHAR(10), 
  estado_registro CHAR(1), 
  fecha_registro TIMESTAMP, 
  fecha_anulacion TIMESTAMP, 
  id_usuarioanulacion VARCHAR(10), 
  id_cliente NUMERIC(18, 0), 
  nombre_cliente VARCHAR(100), 
  ruc_cliente VARCHAR(20), 
  dni_cliente VARCHAR(20), 
  direccion_cliente VARCHAR(80), 
  id_responsable NUMERIC(18, 0), 
  id_sucursal VARCHAR(10), 
  id_motivo VARCHAR(10), 
  requiere_facturacion CHAR(1), 
  estado_facturado CHAR(1), 
  id_salida NUMERIC(18, 0), 
  afectar_orden CHAR(1), 
  devolver_vendido varchar(1), 
  fecha_modificacion date, 
  id_usuariomodificacion varchar(10), date_version date, id_documentoidentidad varchar(10));
CREATE TABLE IF NOT EXISTS "ESTACION" ("id_estacion" VARCHAR(10) NOT NULL,
"descripcion_estacion" VARCHAR(50),
"fecha_inicio" TIMESTAMP,
"fecha_fin" TIMESTAMP,
"estado_estacion" CHAR(1) DEFAULT 'S',
"permitir_todo" CHAR(1), color_r int, color_g int, color_b int,
PRIMARY KEY("id_estacion"));
CREATE TABLE IF NOT EXISTS [LETRA_COMPRA] (
  [id_letra] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  [numero_letra] int, 
  [monto_letra] decimal(18,4), 
  [fecha_vencimiento] date, 
  [monto_pagado] decimal(18,4), 
  [estado_pagado] varchar(1), 
  [fecha_giro] date, 
  [lugar_giro] varchar(50), 
  [id_moneda] varchar(10), 
  [nombre_banco] varchar(80), 
  [nombre_oficina] varchar(50), 
  [numero_cuenta] varchar(50), 
  [dc_cuenta] varchar(10), 
  [nombre_aceptante] varchar(80), 
  [direccion_aceptante] varchar(80), 
  [ruc_aceptante] varchar(20), 
  [localidad_aceptante] varchar(80), 
  [telefono_aceptante] varchar(20), 
  [nombre_aval] varchar(80), 
  [direccion_aval] varchar(80), 
  [ruc_aval] varchar(20), 
  [localidad_aval] varchar(80), 
  [telefono_aval] varchar(20), 
  [id_proveedor] numeric, 
  [estado_registro] varchar(1), 
  [fecha_pago] date, 
  [fecha_registro] date, 
  [id_usuario] varchar(12), 
  [fecha_anulacion] date, 
  [id_usuarioanulacion] varchar(12), 
  [fecha_modificacion] date, 
  [id_usuariomodificacion] varchar(12), 
  [id_documento] varchar(10), 
  [serie_documento] varchar(10), 
  [numero_documento] varchar(50), 
  [id_aceptante] numeric, 
  [id_aval] numeric, 
  [observacion] varchar(100), 
  [referencia] varchar(50), 
  [numero_unico] varchar(50), estado_canje varchar(1));
CREATE TABLE IF NOT EXISTS LOTE_SALIDA (
id_lotesalida integer primary key autoincrement,
id_detallesalida NUMERIC(18, 0) NOT NULL,
lote_producto VARCHAR(50),
observacion VARCHAR(100),
duracion_garantia NUMERIC(18, 2),     
id_lotecompra NUMERIC(28, 0),
cantidad_devuelta decimal(10,2),
precio_venta NUMERIC,
estado_lote CHAR(1),
id_lotepedido NUMERIC(28, 0),
cantidad decimal(10,2),
cantidad_liquidada decimal(10,2),
requiere_liquidacion CHAR(1)
);
CREATE TABLE IF NOT EXISTS [PAGO] (
  [id_pago] integer PRIMARY KEY AUTOINCREMENT, 
  [id_documento] VARCHAR(10), 
  [serie_documento] VARCHAR(10), 
  [numero_documento] VARCHAR(20), 
  [fecha_pago] TIMESTAMP, 
  [id_documentopago] VARCHAR(10), 
  [serie_documentopago] VARCHAR(10), 
  [numero_documentopago] VARCHAR(20), 
  [monto_afectar] NUMERIC, 
  [monto_devuelto] NUMERIC, 
  [id_movimiento] NUMERIC(18, 0), 
  [id_compra] NUMERIC(18, 0), 
  [id_venta] NUMERIC(18, 0), 
  [id_nota] NUMERIC(18, 0), 
  [id_moneda] VARCHAR(10), 
  [id_pagoext] NUMERIC(18, 0), 
  [tipo_pago] VARCHAR(10), 
  [id_modalidadpago] VARCHAR(10), 
  [id_planilla] NUMERIC(18, 0), 
  [id_cuentadeuda] numeric, 
  [id_activacion] numeric, 
  [id_pedido] numeric, id_notacompra numeric, id_letracompra numeric, descripcion_pago varchar(50), id_gastounitario char(12), id_requerimiento decimal(18,0));
CREATE TABLE IF NOT EXISTS [PEDIDO] (
  [id_pedido] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  [id_tipovendedor] VARCHAR(50), 
  [id_vendedorreal] NUMERIC(18, 0), 
  [id_cliente] NUMERIC(18, 0), 
  [nombre_cliente] VARCHAR(100), 
  [ruc_cliente] VARCHAR(50), 
  [dni_cliente] VARCHAR(50), 
  [direccion_cliente] VARCHAR(100), 
  [id_responsable] NUMERIC(18, 0), 
  [id_sucursal] VARCHAR(10), 
  [id_documento] VARCHAR(10), 
  [serie_documento] VARCHAR(50) NOT NULL, 
  [numero_documento] NUMERIC(18, 0), 
  [fecha_pedido] TIMESTAMP, 
  [id_formapago] VARCHAR(50), 
  [subtotal] NUMERIC, 
  [monto_descuento] NUMERIC, 
  [valor_venta] NUMERIC, 
  [monto_igv] NUMERIC, 
  [total_pedido] NUMERIC, 
  [moneda] VARCHAR(50), 
  [observacion] VARCHAR(200), 
  [id_motivo] VARCHAR(50), 
  [id_usuario] VARCHAR(10), 
  [id_supervisor] NUMERIC(18, 0), 
  [requiere_aprobacion] CHAR(1), 
  [estado_aprobado] CHAR(1) DEFAULT 'N', 
  [fecha_aprobacion] TIMESTAMP, 
  [requiere_cancelacion] CHAR(1), 
  [estado_cancelado] CHAR(1) DEFAULT 'N', 
  [monto_cancelado] NUMERIC DEFAULT 0, 
  [fecha_cancelacion] TIMESTAMP, 
  [requiere_facturacion] CHAR(1), 
  [estado_facturado] CHAR(1) DEFAULT 'N', 
  [estado_pedido] VARCHAR(50) DEFAULT 'S', 
  [fecha_registro] TIMESTAMP, 
  [id_clientecuenta] NUMERIC(18, 0), 
  [fecha_anulacion] TIMESTAMP, 
  [id_usuarioanulacion] VARCHAR(10), 
  [nombre_hostanulacion] VARCHAR(50), 
  [id_conceptomovimiento] VARCHAR(50), 
  [monto_tarjeta] NUMERIC DEFAULT 0, 
  [tipo_cambio] NUMERIC(18, 6), 
  [estado_cargado] CHAR(1) DEFAULT 'N', 
  [tipo_cambiocontable] NUMERIC, 
  [genera_interes] CHAR(1), 
  [fecha_liquidacion] TIMESTAMP, 
  [tasa_interes] NUMERIC(10, 4), 
  [id_ubicacionorigen] VARCHAR(10), 
  [estado_despachado] CHAR(1), 
  [tipo_planpedido] varchar(10), 
  [fecha_modificacion] date, 
  [id_usuariomodificacion] varchar(10), 
  [id_documentoidentidad] varchar(10), 
  [monto_pagadoefectivo] decimal(10,2), 
  [estado_preparado_p] varchar(1), 
  [requiere_serie_p] varchar(1), 
  [id_tipocliente] varchar(10));
CREATE TABLE IF NOT EXISTS "PERMANENCIA" ("id_permanencia" VARCHAR(10) NOT NULL,
"descripcion_permanencia" VARCHAR(50),
"duracion_meses" NUMERIC(18, 0),
PRIMARY KEY("id_permanencia"));
CREATE TABLE IF NOT EXISTS [PLAN] (
  [id_plan] VARCHAR(50) NOT NULL, 
  [descripcion_plan] VARCHAR(100), 
  [pago_mensual] NUMERIC, 
  [moneda] VARCHAR(10), 
  [estado_vigente] CHAR(1), 
  [requiere_aprobacion] CHAR(1) DEFAULT ('S'), 
  [requiere_permanencia] CHAR(1) DEFAULT ('S'), 
  [orden] NUMERIC(18, 0), 
  [tipo_plan] VARCHAR(50), 
  [descripcion_proveedor] varchar(100), 
  [id_grupoplan] varchar(10), 
  [precio_conigv] varchar(1), 
  [moneda_precio] varchar(10), color_fondo integer, orden_plan integer, 
  CONSTRAINT [sqlite_autoindex_PLAN_1] PRIMARY KEY ([id_plan]));
CREATE TABLE IF NOT EXISTS SERIE_DEVOLUCION(
	id_seriedevolucion integer primary key autoincrement,
	id_detalledevolucion numeric(18, 0) NOT NULL,
	serie_producto varchar(50) NULL,
	id_seriesalida numeric(18, 0) NULL,
	observacion varchar(100) NULL,
	id_seriecompra numeric(18, 0) NULL,
	date_version date NULL
  );
CREATE TABLE IF NOT EXISTS SERIE_PEDIDO (
  id_seriepedido integer PRIMARY KEY AUTOINCREMENT, 
  id_detallepedido NUMERIC(18, 0) NOT NULL, 
  id_producto VARCHAR(50), 
  serie_producto VARCHAR(50), 
  requiere_activacion CHAR(1), 
  estado_activado CHAR(1) DEFAULT ('N'), 
  observacion VARCHAR(100), 
  estado_facturado CHAR(1) DEFAULT ('N'), 
  estado_devuelto CHAR(1) DEFAULT ('N'), 
  estado_serie CHAR(1) DEFAULT ('S'), 
  id_seriepedidoreferencia NUMERIC(18, 0), 
  estado_despachado CHAR(1) DEFAULT ('N'), 
  estado_seriecancelado CHAR(1) DEFAULT ('N'), 
  serie_incluido CHAR(1), 
  garantia NUMERIC(18, 10), 
  periodo_garantia VARCHAR(50), 
  estado_recibido CHAR(1) DEFAULT ('N'), 
  numero_abonadosp VARCHAR(50), 
  estado_vendido CHAR(1) DEFAULT ('N'), 
  estado_baja CHAR(1) DEFAULT ('N'), 
  id_seriecompraref NUMERIC(18, 0), 
  precio_venta NUMERIC, 
  monto_pagado_s NUMERIC, 
  estado_pagado_s CHAR(1), 
  fecha_pago_s TIMESTAMP, 
  fecha_preparacion date, 
  monto_pagadotarjeta_s decimal(10,2), 
  monto_pagadoefectivo_s decimal(10,2), 
  numero_recibo_s varchar(20));
CREATE TABLE IF NOT EXISTS SESION_CAJA (
  id_sesion integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  id_caja VARCHAR(10), 
  id_usuario VARCHAR(10), 
  fecha_sesion TIMESTAMP, 
  saldo_solesant NUMERIC DEFAULT 0, 
  debe_soles NUMERIC DEFAULT 0, 
  haber_soles NUMERIC DEFAULT 0, 
  saldo_soles NUMERIC DEFAULT 0, 
  saldo_dolaresant NUMERIC DEFAULT 0, 
  debe_dolares NUMERIC DEFAULT 0, 
  haber_dolares NUMERIC DEFAULT 0, 
  saldo_dolares NUMERIC DEFAULT 0, 
  ultima_sesion CHAR(1), 
  id_sucursal VARCHAR(10), 
  fecha_cierre TIMESTAMP);
CREATE TABLE IF NOT EXISTS TEMP_DETALLECOMPRA 
(id_detallecompra integer primary key autoincrement,
id_producto VARCHAR(50),
cantidad NUMERIC(18, 10),
precio_compra NUMERIC,
subtotal_compra NUMERIC,
porcentaje_descuento NUMERIC(18, 10),
monto_descuento NUMERIC,
total_detalle NUMERIC,
observacion VARCHAR(200),
id_usuario VARCHAR(4),
lote VARCHAR(50),
id_plan VARCHAR(50),
numero_pedido VARCHAR(50),
requiere_serie CHAR(1),
serie_completado CHAR(1) DEFAULT 'N',
porcentaje_igvdetalle NUMERIC(18, 10),
monto_igvdetalle NUMERIC,
valor_compradetalle NUMERIC,
precio_conigv CHAR(1),
id_unidad VARCHAR(10),
id_detallereferencia NUMERIC(18, 0),
valor_entrada NUMERIC DEFAULT 0,
costo_entrada NUMERIC DEFAULT 0,
es_porcentaje CHAR(1) DEFAULT 'S',
id_comprafact NUMERIC(18, 0),
id_detallecomprafact NUMERIC(18, 0),
estado_check CHAR(1)
, lote_completado char(1), requiere_lote char(1));
CREATE TABLE IF NOT EXISTS TEMP_DETALLE_COMPRA_GASTO(
  id_detallecomprafact integer PRIMARY KEY AUTOINCREMENT, 
  id_producto VARCHAR(50), 
  id_usuario VARCHAR(10), 
  cantidad NUMERIC(18, 4) NOT NULL, 
  precio_unitario NUMERIC NOT NULL, 
  total_detalle NUMERIC NOT NULL, 
  observacion VARCHAR(100), 
  requiere_serie varchar(1), 
  id_unidad varchar(10), 
  precio_compra decimal(10,4), 
  precio_conigv varchar(1), requiere_lote char(1), porcentaje_descuento decimal(10,2), porcentaje_descuento2 decimal(10,2), porcentaje_descuento3 decimal(10,2), id_productopresupuesto char(12), id_persona numeric, id_detalleorden numeric(18,0), id_detallerequerimiento numeric(18,0), tipo_cambio numeric(10,4), id_moneda varchar(10));
CREATE TABLE IF NOT EXISTS TEMP_DETALLE_DEVOLUCION(
	id_detalledevolucion integer primary key autoincrement,
	id_producto char(12) NULL,
	cantidad numeric(18, 4) NULL,
	observacion varchar(100) NULL,
	id_usuario char(12) NULL,
	requiere_serie varchar(1) NULL,
	serie_completado varchar(1) NULL,
	id_detallesalida numeric(18, 0) NULL,
	id_unidad char(12) NULL,
	cantidad_detalle decimal(18, 4) NULL,
	estado_check varchar(1) NULL,
	costo_unitario decimal(10, 2) NULL
 
);
CREATE TABLE IF NOT EXISTS TEMP_DETALLE_NOTA_COMPRA (
  id_detallenotacompra integer constraint PK_TEMP_DETALLE_NOTA_COMPRA PRIMARY KEY AUTOINCREMENT, 
  id_producto varchar (50) CONSTRAINT FK_TEMP_DETALLE_NOTA_COMPRA_PRODUCTO REFERENCES PRODUCTO(id_producto), 
  cantidad numeric(18, 4), 
  observacion varchar (200), 
  id_usuario varchar (12) CONSTRAINT FK_TEMP_DETALLE_NOTA_COMPRA_USUARIO REFERENCES USUARIO(id_usuario), 
  id_unidad varchar (12) CONSTRAINT FK_TEMP_DETALLE_NOTA_COMPRA_UNIDAD REFERENCES UNIDAD(id_unidad), 
  precio_unitario decimal(10,2), 
  subtotal decimal(10,2), 
  monto_descuento decimal(10,2), 
  total_detalle decimal(10,2),  
  id_detallecomprafact numeric, 
  id_comprafact numeric, 
  estado_check varchar(1),  
  costo_unitario decimal(10,2) 
, ajuste_precio varchar(1));
CREATE TABLE IF NOT EXISTS TEMP_LOTECOMPRA (
id_lotecompra integer constraint PK_TEMP_LOTECOMPRA primary key autoincrement,
id_detallecompra NUMERIC(18, 0) NOT NULL,
lote_producto VARCHAR(50),
 cantidad numeric,
observacion VARCHAR(100),
id_lotepedidoreference NUMERIC(28, 0), 
fecha_vencimiento date);
CREATE TABLE IF NOT EXISTS TEMP_LOTE_SALIDA (
id_lotesalida integer primary key autoincrement,
id_detallesalida NUMERIC(18, 0) NOT NULL,
lote_producto VARCHAR(50),
observacion VARCHAR(100),
id_lotecompra NUMERIC(28, 0),
cantidad decimal(10,2)
);
CREATE TABLE IF NOT EXISTS TEMP_LOTE_SALIDA_OF_PEDIDO (
id_lotesalida integer primary key autoincrement,
id_detallesalida NUMERIC(18, 0) NOT NULL,
lote_producto VARCHAR(50),
observacion VARCHAR(100),
id_lotecompra NUMERIC(28, 0),
id_lotepedido NUMERIC(28, 0),
cantidad decimal(10,2),
estado_check varchar(1)
);
CREATE TABLE IF NOT EXISTS TEMP_SERIECOMPRA (
id_seriecompra integer primary key autoincrement,
id_detallecompra NUMERIC(18, 0) NOT NULL,
serie_producto VARCHAR(50),
observacion VARCHAR(100),
garantia NUMERIC(18, 10),
periodo_garantia VARCHAR(50),
id_seriepedidoreference NUMERIC(28, 0)
, fecha_vencimiento date);
CREATE TABLE IF NOT EXISTS TEMP_SERIE_DEVOLUCION(
	id_seriedevolucion integer primary key autoincrement,
	id_detalledevolucion numeric(18, 0) NOT NULL,
	serie_producto varchar(50) NULL,
	id_seriesalida numeric(18, 0) NULL,
	observacion varchar(100) NULL,
	estado_check varchar(1) NULL,
	id_seriecompra numeric(18, 0) NULL
 
);
CREATE TABLE IF NOT EXISTS TEMP_TEMPLOTECOMPRA (
  id_lotecompra integer constraint PK_TEMP_TEMPLOTE_COMPRA PRIMARY KEY AUTOINCREMENT, 
  id_usuario VARCHAR(10) NOT NULL, 
  lote_producto VARCHAR(50),   
  cantidad numeric,
  observacion VARCHAR(100),
  fecha_vencimiento date);
CREATE TABLE IF NOT EXISTS [TEMP_TEMPSERIECOMPRA] (
  [id_seriecompra] integer PRIMARY KEY AUTOINCREMENT, 
  [id_usuario] VARCHAR(10) NOT NULL, 
  [serie_producto] VARCHAR(50), 
  [observacion] VARCHAR(100), 
  [garantia] NUMERIC(18, 10), 
  [periodo_garantia] VARCHAR(50), fecha_vencimiento date);
CREATE TABLE IF NOT EXISTS TEMP_TEMP_LOTE_SALIDA (
id_lotesalida integer primary key autoincrement,
id_usuario VARCHAR(10) NOT NULL,
lote_producto VARCHAR(50),
observacion VARCHAR(100),
id_lotecompra NUMERIC(28, 0),
id_producto varchar(50),
cantidad decimal(10,2)
);
CREATE TABLE IF NOT EXISTS "TIPO_CAMBIO" 
("id_tipocambio" integer primary key autoincrement,
"fecha" TIMESTAMP,
"precio_compra" NUMERIC,
"precio_venta" NUMERIC, precio_mercado decimal(10,2)
);
CREATE TABLE IF NOT EXISTS [TIPO_PLAN] (
  [tipo_plan] VARCHAR(10) NOT NULL, 
  [descripcion_tipo] VARCHAR(80) NOT NULL, 
  [requiere_permanencia] CHAR(1), 
  [estado_vigente] CHAR(1), 
  [orden] INTEGER, requiere_anterior varchar(1), 
  CONSTRAINT [sqlite_autoindex_TIPO_PLAN_1] PRIMARY KEY ([tipo_plan]));
CREATE TABLE IF NOT EXISTS [analisis_costo] (
  [id_analisiscosto] CHAR(12) NOT NULL, 
  [descripcion_costo] VARCHAR(255), 
  [id_unidad] CHAR(12), 
  [costo_unitario] NUMERIC(16, 2) DEFAULT 0.00, 
  [fecha_costo] VARCHAR(10), 
  [especificaciones] TEXT, 
  [especificaciones_texto] CHAR(1), 
  [archivo_especificaciones] BLOB, 
  [nombre_archivoespecificaciones] VARCHAR(200), 
  [productividad] NUMERIC(16, 2) DEFAULT 1.00, 
  [tiempo_productividad] NUMERIC(16, 0), 
  [id_unidadtiempo] CHAR(12), 
  [magnitud_unidadtiempo] NUMERIC(16, 10), 
  [id_infraestructura] CHAR(12), 
  [tiene_composicion] CHAR(1) DEFAULT 'N', 
  [codigo_clase] VARCHAR(10), 
  [codigo_subclase] VARCHAR(10), 
  [codigo_listaprecio] VARCHAR(10), 
  [id_usuariocreate] CHAR(12), tipo_rendimiento char(1), id_categoria varchar(12), es_ic char(1), id_elemento varchar(12), cantidad NUMERIC(16,2), valor_asignacion NUMERIC(16,2), color_fuente int, color_fondo int, nombre_fuente VARCHAR(100), estilo_fuente int, tamano_fuente numeric(6,2), cantidad_metrado NUMERIC(16,2), archivo_pdf  BLOB, cantidad_tarea  NUMERIC(16, 2), editor_costo char(2), 
  CONSTRAINT [sqlite_autoindex_analisis_costo_1] PRIMARY KEY ([id_analisiscosto]));
CREATE TABLE IF NOT EXISTS aplicacion_insumo(
id_aplicacion integer constraint pk_aplicacion_insumo primary key autoincrement,
fecha_aplicacion TIMESTAMP,
cantidad_aplicada decimal(18,4),
costo_unitario decimal(18,4),
subtotal decimal(18,4), 
id_composicion varchar(12), 
id_proyecto varchar(12),
id_detallesalida integer constraint fk_aplicacion_detalle_salida
references detalle_salida(id_detallesalida)
, id_persona numeric(18,0), estado_registro char(1));
CREATE TABLE IF NOT EXISTS asiento_obra(
id_asiento numeric constraint pk_asiento primary key,
numero_asiento integer,
fecha_asiento date,
procedencia char(1),
id_tipo varchar(4),
id_proyecto char(12) not null,
prioridad char(1),
fecha_respuesta date,
observaciones varchar(255),
archivo_asiento blob
, tiene_respuesta char(1), id_usuario char(12));
CREATE TABLE IF NOT EXISTS asiento_respuesta
(
id_registro integer  constraint pk_asiento_respuesta primary key AUTOINCREMENT,
id_respuesta numeric not null,
id_asiento numeric not null
);
CREATE TABLE IF NOT EXISTS calendario(
id_calendario integer primary key autoincrement,
nombre_calendario varchar(50) not null
, id_proyecto char(12));
CREATE TABLE IF NOT EXISTS cargo (
  id_cargo VARCHAR(10) NOT NULL, 
  descripcion_cargo VARCHAR(100), id_tipopersona varchar(10), 
  CONSTRAINT pk_cargo PRIMARY KEY (id_cargo));
CREATE TABLE IF NOT EXISTS categoria (
  id_categoria varchar(12) NOT NULL, 
  descripcion_categoria VARCHAR(50), 
  precios_plan CHAR(1), 
  requiere_serie CHAR(1), 
  nombre_serie VARCHAR(50), 
  requiere_activacion CHAR(1), 
  afecta_kardex CHAR(1), 
  id_concepto VARCHAR(10), 
  permite_incluido CHAR(1), 
  estado_categoria CHAR(1), 
  permite_garantia CHAR(1), 
  longitud_minima INTEGER, 
  longitud_maxima INTEGER, 
  solo_numeros CHAR(1), 
  dias_vencimiento INTEGER, 
  tiene_incluido CHAR(1), 
  requiere_precio varchar(1), 
  orden_categoria int, 
  generar_serie varchar(1), id_conceptoventa varchar(10), id_conceptocompra varchar(10), es_concepto varchar(1), requiere_lote char(1), solo_numeroslote char(1), requiere_vencimiento char(1), date_version TIMESTAMP, alias_categoria VARCHAR(50), 
  CONSTRAINT pk_categoria PRIMARY KEY (id_categoria));
CREATE TABLE IF NOT EXISTS "clase" ("id_clase" CHAR(12) NOT NULL,
"descripcion_clase" VARCHAR(120),
"codigo_clase" VARCHAR(5), nota varchar(15),
PRIMARY KEY("id_clase"));
CREATE TABLE IF NOT EXISTS clase_gl(
	id_clase numeric(18, 0)NOT NULL,
	codigo_clase varchar(10),
	nombre_clase varchar(80) NOT NULL,
 CONSTRAINT PK_CLASE PRIMARY KEY(id_clase)
 );
CREATE TABLE IF NOT EXISTS [composicion_analisiscosto] (
  [id_composicion] CHAR(12) NOT NULL, 
  [descripcion_composicion] VARCHAR(255), 
  [id_subtotal] CHAR(12) NOT NULL, 
  [personal_base] NUMERIC(10, 4), 
  [id_unidad] CHAR(12), 
  [magnitud_unidadcomposicion] NUMERIC(10, 4), 
  [cantidad_composicion] NUMERIC(16, 4), 
  [costo_composicion] NUMERIC(16, 4), 
  [parcial_composicion] NUMERIC(16, 2), 
  [id_costoauxiliar] CHAR(12), 
  [nombre_subcontratista] VARCHAR(120), 
  [numeracion_subtotal] VARCHAR(20), 
  [codigo_clase] VARCHAR(20), 
  [codigo_subclase] VARCHAR(5), 
  [codigo_listaprecio] VARCHAR(5), 
  [id_listaprecio] CHAR(12), 
  [es_composiciondependiente] CHAR(1) DEFAULT 'N', 
  [es_subcomposicion] CHAR(1) DEFAULT 'N', 
  [posicion_composicion] INTEGER, 
  [productividad] NUMERIC(16, 2) DEFAULT 1.00, 
  [tiempo_productividad] NUMERIC(16, 2), 
  [id_unidadtiempo] CHAR(12), 
  [magnitud_unidadtiempo] NUMERIC(16, 10), 
  [fecha_costo] VARCHAR(10), 
  [especificaciones] TEXT, 
  [especificaciones_texto] CHAR(1), 
  [archivo_especificaciones] BLOB, 
  [nombre_archivoespecificaciones] VARCHAR(200), [porcentaje_desperdicio] NUMERIC(16, 4), tipo_rendimiento char(1), id_marca varchar(10), costo_composicion_aigv numeric(18,10), id_aplica_tipocosto varchar(12), include_percent  char(1), disponibilidad_recurso numeric(16,2), valor_asignacion numeric(16,2), cantidad_metrado NUMERIC(16,2), cantidad_tarea  NUMERIC(16, 2), editor_costo char(2), 
  CONSTRAINT [sqlite_autoindex_composicion_analisiscosto_1] PRIMARY KEY ([id_composicion]));
CREATE TABLE IF NOT EXISTS [composicion_costounitario] (
  [id_composicion] CHAR(12) NOT NULL, 
  [descripcion_composicion] VARCHAR(255), 
  [id_subtotal] CHAR(12) NOT NULL, 
  [personal_base] NUMERIC(10, 4), 
  [id_unidad] CHAR(12), 
  [magnitud_unidadcomposicion] NUMERIC(10, 4), 
  [cantidad_composicion] NUMERIC(16, 4), 
  [costo_composicion] NUMERIC(16, 4), 
  [parcial_composicion] NUMERIC(16, 2), 
  [id_costoauxiliar] CHAR(12), 
  [nombre_subcontratista] VARCHAR(120), 
  [numeracion_subtotal] VARCHAR(20), 
  [codigo_clase] VARCHAR(20), 
  [codigo_subclase] VARCHAR(5), 
  [codigo_listaprecio] VARCHAR(5), 
  [id_listaprecio] CHAR(12), 
  [es_composiciondependiente] CHAR(1) DEFAULT 'N', 
  [es_subcomposicion] CHAR(1) DEFAULT 'N', 
  [posicion_composicion] INTEGER, 
  [productividad] NUMERIC(10, 2), 
  [tiempo_productividad] NUMERIC(10, 2), 
  [magnitud_unidadtiempo] NUMERIC(16, 10), 
  [id_unidadtiempo] VARCHAR(12), 
  [fecha_costo] VARCHAR(12), 
  [especificaciones] TEXT, 
  [especificaciones_texto] CHAR(1), 
  [archivo_especificaciones] BLOB, 
  [nombre_archivoespecificaciones] VARCHAR(200), cantidad_ejecutada decimal(18,10), parcial_ejecutado decimal(18,10), cantidad_ordenada decimal(18,10), metrado_ejecutado decimal(18,10), parcial_ordenado decimal(18,10), cantidad_comprada decimal(18,10), parcial_comprado decimal(18,10), [porcentaje_desperdicio] NUMERIC(16, 4), es_presupuestado varchar(1), tipo_rendimiento char(1), id_marca varchar(10), costo_composicion_aigv numeric(18,10), id_aplica_tipocosto varchar(12), include_percent  char(1), disponibilidad_recurso numeric(16,2), valor_asignacion NUMERIC(16,2), cantidad_metrado NUMERIC(16,2), cantidad_tarea  NUMERIC(16, 2), editor_costo char(2), 
  CONSTRAINT [sqlite_autoindex_composicion_costounitario_1] PRIMARY KEY ([id_composicion]));
CREATE TABLE IF NOT EXISTS compra (
  id_compra integer constraint pk_compra PRIMARY KEY AUTOINCREMENT, 
  id_proveedor numeric, 
  id_sucursalorigen VARCHAR(10), 
  id_sucursaldestino VARCHAR(10), 
  id_documento VARCHAR(10), 
  serie_documento VARCHAR(50), 
  numero_documento VARCHAR(50), 
  fecha_compra TIMESTAMP, 
  id_formapago VARCHAR(10), 
  id_motivo VARCHAR(10), 
  moneda VARCHAR(10), 
  tipo_cambio NUMERIC,  
  total_compra NUMERIC, 
  estado_facturado CHAR(1), 
  observacion VARCHAR(200), 
  id_transportista NUMERIC(18, 0), 
  id_usuario CHAR(12), 
  estado_compra VARCHAR(1), 
  fecha_registro TIMESTAMP, 
  fecha_anulacion TIMESTAMP, 
  id_usuarioanulacion CHAR(12), 
  id_comprafact NUMERIC(28, 0), 
  id_salida numeric, 
  fecha_modificacion date, 
  id_usuariomodificacion char(12)
  );
CREATE TABLE IF NOT EXISTS compra_fact (
  id_comprafact integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  id_documento VARCHAR(10), 
  serie_documento VARCHAR(20), 
  numero_documento VARCHAR(20), 
  fecha_documento TIMESTAMP NOT NULL, 
  id_monedabase VARCHAR(10), 
  id_moneda VARCHAR(10), 
  tipo_cambio NUMERIC, 
  total_documento NUMERIC, 
  observacion VARCHAR(100), 
  id_usuario char(12), 
  estado_registro CHAR(1), 
  fecha_registro TIMESTAMP, 
  fecha_anulacion TIMESTAMP, 
  id_usuarioanulacion CHAR(12), 
  id_proveedor NUMERIC(18, 0), 
  id_formapago VARCHAR(10), 
  porcentaje_igv NUMERIC(9, 4), 
  valor_compra NUMERIC, 
  monto_igv NUMERIC, 
  monto_pagado NUMERIC, 
  estado_pagado CHAR(1), 
  estado_entrada CHAR(1), 
  requiere_entrada CHAR(1), 
  fecha_ingreso TIMESTAMP NOT NULL, 
  id_sucursal VARCHAR(10), 
  fecha_modificacion date, 
  id_usuariomodificacion char(12), 
  fecha_pago date, 
  tipo_cambiocontable decimal(10,2)
  , id_concepto varchar(10), es_servicio varchar(1), monto_flete decimal(10,2), moneda_flete varchar(10), monto_canje decimal(10,2), fecha_detraccion date, numero_detraccion varchar(20), monto_detraccion decimal(10,2), mes_contabilidad int, anio_contabilidad int, fecha_vencimiento date, id_cuenta integer, id_proyecto char(12), id_empresa numeric, id_documento_ref VARCHAR(10), serie_documento_ref VARCHAR(20), numero_documento_ref VARCHAR(20), fecha_documento_ref TIMESTAMP, id_moneda_ref VARCHAR(10), id_categoria varchar(12), id_sucursalatender varchar(10), id_orden INTEGER, es_compra_directa char(1), id_responsable NUMERIC(18, 0));
CREATE TABLE IF NOT EXISTS concepto (
  id_concepto VARCHAR(10) NOT NULL, 
  id_cuenta VARCHAR(10) constraint fk_concepto_cuenta references cuenta(id_cuenta), 
  descripcion_concepto VARCHAR(80), 
  estado_concepto CHAR(1), 
  tipo_concepto VARCHAR(10), 
  codigo_cuenta VARCHAR(10), 
  id_cuentagl NUMERIC(18, 0), 
  id_subcuenta NUMERIC(18, 0), 
  info_concepto VARCHAR(120), 
  id_conceptoextorno VARCHAR(10), 
  es_extorno VARCHAR(50), 
  id_extension VARCHAR(50), 
  id_documentos varchar(50), 
  tipo_afectar varchar(1), 
  id_conceptocargo varchar(10), 
  agrega_cuenta varchar(1), 
  imprimir_logo varchar(1), 
  formula varchar(200), 
  permite_suma varchar(1), 
  es_planilla varchar(1), 
  orden int, 
  clave_concepto varchar(30), es_afp char(1), 
  CONSTRAINT pk_concepto PRIMARY KEY (id_concepto));
CREATE TABLE IF NOT EXISTS control_insumo (
id_control numeric constraint PK_CONTROL_INSUMO primary key,
posicion int,
observaciones varchar(200),
cantidad_contratada decimal(10,2),
id_listaprecio char(12),
id_proveedor numeric,
id_proyecto char(12) not null, id_compra numeric, precio_unitario decimal (16,4),
constraint FK_CONTROL_INSUMO_PRODUCTO foreign key (id_listaprecio) references PRODUCTO(id_producto),
constraint FK_CONTROL_INSUMO_PROVEEDOR foreign key (id_proveedor) references PERSONA(id_persona),
constraint FK_CONTROL_INSUMO_PROYECTO foreign key (id_proyecto) references PROYECTO(id_proyecto)
);
CREATE TABLE IF NOT EXISTS costo_desagregado (
  id_costounitario CHAR(12) NOT NULL, 
  descripcion_costo VARCHAR(120), 
  id_unidad CHAR(12), 
  costo_unitario NUMERIC(16, 2) DEFAULT (0.00), 
  id_titulo CHAR(12), 
  numeracion_costo VARCHAR(120), 
  posicion_costo INTEGER, 
  cantidad NUMERIC(16, 2), 
  parcial_costo NUMERIC(16, 2), 
  color_fuente numeric, 
  nombre_fuente varchar(100), 
  estilo_fuente int, 
  tamano_fuente decimal(6,2), id_listaprecio char(12), color_fondo integer, 
  CONSTRAINT pk_costo_desagregado PRIMARY KEY (id_costounitario));
CREATE TABLE IF NOT EXISTS costo_partida
(
id_costopartida CHAR(12) NOT NULL,
descripcion_costo VARCHAR(120),
id_unidad CHAR(12),
id_partida CHAR(12),
numeracion_costo VARCHAR(120),
posicion_costo INTEGER,
id_analisiscosto CHAR(12),
PRIMARY KEY(id_costopartida)
);
CREATE TABLE IF NOT EXISTS "costo_unitario" ("id_costounitario" CHAR(12) NOT NULL,
"descripcion_costo" VARCHAR(255),
"id_unidad" CHAR(12),
"costo_unitario" NUMERIC(16, 2) DEFAULT 0.00,
"fecha_costo" VARCHAR(12),
"especificaciones" TEXT,
"especificaciones_texto" CHAR(1),
"archivo_especificaciones" BLOB,
"nombre_archivoespecificaciones" VARCHAR(200),
"productividad" NUMERIC(16, 2) DEFAULT 1.00,
"tiempo_productividad" NUMERIC(16, 2),
"id_unidadtiempo" CHAR(12),
"magnitud_unidadtiempo" NUMERIC(16, 10),
"id_titulo" CHAR(12),
"numeracion_costo" VARCHAR(120),
"posicion_costo" INTEGER,
"cantidad" NUMERIC(16, 2),
"cantidad_metrado" NUMERIC(16, 2),
"parcial_costo" NUMERIC(16, 2),
"id_analisiscosto" CHAR(12),
"tiene_composicion" CHAR(1) DEFAULT 'N',
"tiempo_requerido" INTEGER,
"tiempo_programado" INTEGER,
"cantidad_programada" NUMERIC(16, 2),
"estado_ajustado" CHAR(1) DEFAULT 'N',
"tiene_metrado" CHAR(1),
"tipo_metrado" CHAR(1),
"factor1_4" NUMERIC(16, 2),
"factor3_8" NUMERIC(16, 2),
"factor1_2" NUMERIC(16, 2),
"factor5_8" NUMERIC(16, 2),
"factor3_4" NUMERIC(16, 2),
"factor1_1" NUMERIC(16, 2),
"total1_4" NUMERIC(16, 2),
"total3_8" NUMERIC(16, 2),
"total1_2" NUMERIC(16, 2),
"total5_8" NUMERIC(16, 2),
"total3_4" NUMERIC(16, 2),
"total1_1" NUMERIC(16, 2),
"id_usuariocreate" CHAR(12), metrado_ejecutado decimal(18,10), factor6mm numeric(16,2), factor8mm numeric(16,2), factor12mm numeric(16,2), factor7_8 numeric(16,2), factor9_8 numeric(16,2), factor10_8 numeric(16,2), factor11_8 numeric(16,2), total6mm numeric(16,2), total8mm numeric(16,2), total12mm numeric(16,2), total7_8 numeric(16,2), total9_8 numeric(16,2), total10_8 numeric(16,2), total11_8 numeric(16,2), factor4mm numeric(16,2), factor4_5mm numeric(16,2), factor5mm numeric(16,2), factor5_5mm numeric(16,2), factor6_5mm numeric(16,2), factor7mm numeric(16,2), factor7_5mm  numeric(16,2), factor8_5mm numeric(16,2), total4mm numeric(16,2), total4_5mm numeric(16,2), total5mm numeric(16,2), total5_5mm numeric(16,2), total6_5mm numeric(16,2), total7mm numeric(16,2), total7_5mm  numeric(16,2), total8_5mm numeric(16,2), tiempo_requeridonew decimal(10,2), tiempo_programadonew decimal(10,2), numeracion_norma varchar(120), color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), tipo_rendimiento char(1), duracion int, fecha_inicio date, fecha_fin date, es_hito char(1), porcentaje_completado decimal(10,2), color_fondo integer, id_presupuesto char(12), id_costopadre char(12), estado_expandido char(1), etiqueta integer, archivo_metrado blob, id_titulobim char(12), parcial_aplicado decimal(18,4), check_cantidad char(1), check_largo char(1), check_ancho char(1), check_alto char(1), check_peso char(1), check_area char(1), check_volumen char(1), id_unidadmetrado char(12), editor_metrado char(1), archivo_pdf BLOB, tipo_restriccion integer, fecha_restriccion date, sync_guid varchar(80), sync_color int, task_mode integer, Notas1 varchar(50), Notas2 varchar(50), Notas3 varchar(50), campo_metrado varchar(50), color_izquierda integer, color_derecha integer, show_timeline char(1) default 'N', show_timeline_num int, show_elaboracion char(1) default 'S', display_formula1 varchar(50), display_formula2 varchar(50), orden_partida integer, valor_asignacion numeric(16,2), tipo_calculo_acu char(1), cantidad_tarea  NUMERIC(16, 2), editor_costo char(2), label_id INT, status_id INT, duracion_new DECIMAL(12,4), color_kanban int,
PRIMARY KEY("id_costounitario"));
CREATE TABLE IF NOT EXISTS "costo_unitariogasto" ("id_costounitario" CHAR(12) NOT NULL,
"descripcion_costo" VARCHAR(120),
"id_unidad" CHAR(12),
"costo_unitario" NUMERIC(16, 2) DEFAULT 0.00,
"fecha_costo" VARCHAR(10),
"especificaciones" TEXT,
"especificaciones_texto" CHAR(1),
"archivo_especificaciones" BLOB,
"nombre_archivoespecificaciones" VARCHAR(200),
"tiempo_requerido" NUMERIC(16, 2),
"id_unidadtiempo" CHAR(12),
"id_titulo" CHAR(12),
"numeracion_costo" VARCHAR(120),
"posicion_costo" INTEGER,
"cantidad" NUMERIC(16, 2),
"parcial_costo" NUMERIC(16, 2),
"tiene_composicion" CHAR(1) DEFAULT 'N',
"cadena_tiempo" TEXT, color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), color_fondo integer, monto_pagado decimal(18,4), estado_pagado char(1), fecha_pago date, id_unidad_real char(12), cantidad_real decimal(16,2), costo_real decimal(16,2), parcial_real decimal(16,2), cantidad_compra decimal(16,2), cantidad_ordenada NUMERIC(16,2), parcial_ordenado NUMERIC(16,2), cantidad_comprada NUMERIC(16,2), parcial_comprado NUMERIC(16,2), parcial_ejecutado NUMERIC(16,2), cantidad_ejecutada NUMERIC(16,2), id_producto CHAR(12),
PRIMARY KEY("id_costounitario"));
CREATE TABLE IF NOT EXISTS "costo_unitarioplantilla" ("id_costounitario" CHAR(12) NOT NULL,
"descripcion_costo" VARCHAR(120),
"id_unidad" CHAR(12),
"costo_unitario" NUMERIC(16, 2) DEFAULT 0.00,
"fecha_costo" VARCHAR(10),
"id_unidadtiempo" CHAR(12),
"id_titulo" CHAR(12),
"numeracion_costo" VARCHAR(120),
"posicion_costo" INTEGER, color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), color_fondo integer, id_costopadre char(12), id_plantilla char(12), estado_expandido char(1), id_clasificador char(12), numeracion_clasificador varchar(120), estado_bloqueado char(1),
PRIMARY KEY("id_costounitario"));
CREATE TABLE IF NOT EXISTS costo_unitariosupervision (
id_costounitario CHAR(12) NOT NULL,
descripcion_costo VARCHAR(120),
id_unidad CHAR(12),
costo_unitario NUMERIC(16, 2),
tiempo_requerido NUMERIC(16, 2),
id_unidadtiempo CHAR(12),
id_titulo CHAR(12),
numeracion_costo VARCHAR(120),
posicion_costo INTEGER,
cantidad NUMERIC(16, 2),
parcial_costo NUMERIC(16, 2),
tiene_composicion CHAR(1),
cadena_tiempo varchar(255), 
color_fuente numeric, 
nombre_fuente varchar(100), 
estilo_fuente int, 
tamano_fuente decimal(6,2), 
color_fondo numeric, id_unidad_real char(12), cantidad_real decimal(16,2), costo_real decimal(16,2), parcial_real decimal(16,2), cantidad_compra decimal(16,2), cantidad_ordenada NUMERIC(16,2), parcial_ordenado NUMERIC(16,2), cantidad_comprada NUMERIC(16,2), parcial_comprado NUMERIC(16,2), parcial_ejecutado NUMERIC(16,2), cantidad_ejecutada NUMERIC(16,2), id_producto CHAR(12),
PRIMARY KEY(id_costounitario)
);
CREATE TABLE IF NOT EXISTS cuenta (
  id_cuenta VARCHAR(10) NOT NULL, 
  descripcion_cuenta VARCHAR(100), 
  estado_cuenta VARCHAR(1), orden integer, 
  CONSTRAINT PK_CUENTA PRIMARY KEY (id_cuenta));
CREATE TABLE IF NOT EXISTS cuenta_caja (
id_caja VARCHAR(10) NOT NULL,
descripcion_caja VARCHAR(50) NOT NULL,
id_tipocaja VARCHAR(10),
id_cuenta NUMERIC(18, 0),
id_subcuenta NUMERIC(18, 0),
id_sucursal VARCHAR(10), id_moneda varchar(10), id_documentofact varchar(10), formato_ticket varchar(1), id_documentovta varchar(10), serie_impresora varchar(50), formato_fact int,
PRIMARY KEY(id_caja));
CREATE TABLE IF NOT EXISTS cuenta_corriente(
	id_movimiento INTEGER primary key AUTOINCREMENT,
	id_persona decimal(18, 0) NULL,
	fecha_movimiento date NULL,
	tipo_movimiento varchar(50) NULL,
	descripcion_movimiento varchar(200) NULL,
	id_cuenta varchar(10) NULL,
	id_concepto varchar(10) NULL,
	id_documento varchar(10) NULL,
	serie_documento varchar(50) NULL,
	numero_documento varchar(50) NULL,
	moneda varchar(50) NULL,
	debe_soles decimal(16,2) NULL,
	haber_soles decimal(16,2) NULL,
	saldo_soles decimal(16,2) NULL,
	debe_dolares decimal(16,2) NULL,
	haber_dolares decimal(16,2) NULL,
	saldo_dolares decimal(16,2) NULL,
	ultimo_movimiento varchar(1) NULL,
	estado_movimiento varchar(1) NULL,
	id_plan varchar(50) NULL,
	numero_abonado varchar(50) NULL,
	estado_pagado varchar(1) NULL,
	estado_documento varchar(1) NULL,
	id_usuario varchar(12) NULL,
	nombre_host varchar(255) NULL,
	orden numeric(18, 0) NULL,
	id_linea varchar(50) NULL,
	desde_planilla varchar(1) NULL,
	id_cuentadeuda numeric(18, 0) NULL,
	id_venta numeric(18, 0) NULL,
	id_nota numeric(18, 0) NULL,
	fecha_registro_mov date NULL,
	id_movimientocaja numeric(18, 0) NULL,
	ingreso_manual varchar(1) NULL,
	monto_procesado decimal(16,2) NULL,
	estado_procesado varchar(1) NULL,
	id_detalleplanilla numeric(18, 0) NULL,
	id_activacionref numeric(18, 0) NULL,
	fecha_anulacion date NULL,
	id_usuarioanulacion varchar(10) NULL,
	fecha_modificacion date NULL,
	id_usuariomodificacion varchar(10) NULL,
	date_version date NULL
 
);
CREATE TABLE IF NOT EXISTS cuenta_gl (
id_cuenta integer primary key autoincrement,
codigo_cuenta VARCHAR(20) NOT NULL,
nombre_cuenta VARCHAR(80) NOT NULL,
id_cuentapadre NUMERIC(18, 0),
id_clase NUMERIC(18, 0), 
orden int
);
CREATE TABLE IF NOT EXISTS cuenta_gl_temp (
id_cuenta integer primary key,
codigo_cuenta VARCHAR(20) NOT NULL,
nombre_cuenta VARCHAR(80) NOT NULL,
id_cuentapadre NUMERIC(18, 0),
id_clase NUMERIC(18, 0), 
orden int
);
CREATE TABLE IF NOT EXISTS cuenta_tipopersona (
id_tipopersona VARCHAR(10) NOT NULL,
id_cuenta VARCHAR(10) NOT NULL,
constraint pk_cuenta_tipopersona PRIMARY KEY(id_tipopersona,id_cuenta)
);
CREATE TABLE IF NOT EXISTS "departamento" ("id_departamento" CHAR(12) NOT NULL,
"nombre_departamento" VARCHAR(120),
PRIMARY KEY("id_departamento"));
CREATE TABLE IF NOT EXISTS dependencia (id_dependencia numeric primary key,id_costounitario varchar(12) ,id_programacionorigen varchar(12) not null,id_programaciondestino varchar(12) not null,tipo int);
CREATE TABLE IF NOT EXISTS dependencia_costo(
id_dependencia char(12) constraint pk_dependenciacosto primary key,
id_costounitario char(12) not null,
id_programaciondestino char(12),
tipo int, id_costounitariodestino char(12), id_proyecto char(12), id_tituloorigen char(12), id_titulodestino char(12));
CREATE TABLE IF NOT EXISTS dependencia_metrado(
id_dependencia char(12) constraint pk_dependenciatarea primary key,
id_metradoorigen char(12) null,
tipo integer, id_metradodestino char(12), 
id_costounitario char(12) not null, 
lag_size integer
);
CREATE TABLE IF NOT EXISTS dependencia_tarea(
id_dependencia char(12) constraint pk_dependenciatarea primary key,
id_costounitarioorigen char(12) null,
id_programaciondestino char(12),
tipo int, id_costounitariodestino char(12), 
id_proyecto char(12) not null, 
id_tituloorigen char(12), 
id_titulodestino char(12)
, lag_size integer, id_presupuestoorigen char(12), id_presupuestodestino char(12));
CREATE TABLE IF NOT EXISTS dependencianew (
id_dependencia char(12) constraint pk_dependencianew primary key,
id_costounitario char(12) ,
id_programacionorigen char(12) not null,
id_programaciondestino char(12) not null,
tipo int);
CREATE TABLE IF NOT EXISTS detalle_compra (
id_detallecompra integer constraint pk_detalle_compra primary key autoincrement NOT NULL,
id_producto  CHAR(12),
cantidad NUMERIC(18, 2),
total_detalle NUMERIC(10,2),
observacion VARCHAR(200),
id_compra NUMERIC(18, 0) constraint fk_detalle_compra_compra references compra(id_compra),
requiere_serie CHAR(1),
serie_completado CHAR(1),
estado_detalle CHAR(1),
id_unidad CHAR(12),
costo_entrada NUMERIC decimal(10,2),
id_detallecomprafact NUMERIC(18, 0), 
estado_cargado varchar(1),
id_detallereferencia numeric
, requiere_lote char(1), lote_completado char(1));
CREATE TABLE IF NOT EXISTS detalle_compra_composicion (
id_registro integer  primary key autoincrement,
id_detallecompra numeric(18,0) NOT NULL,
id_composicion varchar(12) NOT NULL,  
cantidad numeric(18,10), 
estado_registro varchar(1)
, costo_unitario decimal(18,4));
CREATE TABLE IF NOT EXISTS detalle_compra_fact (
id_detallecomprafact integer primary key autoincrement,
id_producto char(12) NOT NULL,
id_comprafact NUMERIC(28, 0) NOT NULL
constraint fk_detalle_compra_compra references compra_fact(id_comprafact),
cantidad NUMERIC(18, 4) NOT NULL,
precio_unitario NUMERIC NOT NULL,
total_detalle NUMERIC NOT NULL,
observacion VARCHAR(100),
estado_detalle CHAR(1),
cantidad_entrada NUMERIC(18, 4),
requiere_serie CHAR(1), 
id_unidad char(12), 
estado_cargado varchar(1), 
cantidad_devuelta decimal(10,2)
, monto_devuelto decimal(10,2), precio_compra decimal(10,4), precio_conigv varchar(1), id_detallerequerimiento numeric, requiere_lote char(1), porcentaje_descuento decimal(10,2), porcentaje_descuento2 decimal(10,2), porcentaje_descuento3 decimal(10,2), id_productopresupuesto char(12), estado_agregado char(1), id_persona  numeric, id_detalleorden numeric(18,0));
CREATE TABLE IF NOT EXISTS detalle_consumo_map
(
id_map integer constraint PK_DETALLE_CONSUMO_MAP primary key AUTOINCREMENT,
id_equipo numeric,
cantidad decimal(10,4),
id_detalle numeric,
observaciones varchar(200), id_cliente NUMERIC(18, 0), ruc_cliente VARCHAR(20), dni_cliente VARCHAR(20), id_transportista NUMERIC(18, 0), id_sucursal VARCHAR(10),
constraint FK_DETALLE_CONSUMO_MAP_CONTROL foreign key (id_detalle) references detalle_insumo(id_detalle),
constraint FK_DETALLE_CONSUMO_MAP_EQUIPO foreign key (id_equipo) references control_insumo(id_control)
);
CREATE TABLE IF NOT EXISTS detalle_gasto
  (
   id_detalle numeric constraint pk_detalle_gasto primary key,
   id_detallecompra numeric constraint fk_detalle_gasto_compra references detalle_compra_fact(id_detallecomprafact),
   id_costounitario char(12) constraint fk_detalle_gasto_gu references costo_unitariogasto(id_costounitario),
   id_unidad char(12),
   cantidad decimal(16,2),
   costo_unitario decimal(16,2)
   );
CREATE TABLE IF NOT EXISTS detalle_gasto_supervision
  (
   id_detalle numeric constraint pk_detalle_gastospv primary key,
   id_detallecompra numeric constraint fk_detalle_gastospv_compra references detalle_compra_fact(id_detallecomprafact),
   id_costounitario char(12) constraint fk_detalle_gastospv_gu references costo_unitariosupervision(id_costounitario),
   id_unidad char(12),
   cantidad decimal(16,2),
   costo_unitario decimal(16,2)
   );
CREATE TABLE IF NOT EXISTS detalle_insumo
(

id_detalle integer constraint PK_DETALLE_INSUMO primary key AUTOINCREMENT,
id_control numeric,
cantidad decimal(10,2),
fecha date, row_page int, id_documento VARCHAR(10), serie_documento VARCHAR(10), numero_documento VARCHAR(20), fecha_registro date, tipo_movimiento int,
constraint FK_DETALLE_INSUMO_CONTROL foreign key (id_control) references CONTROL_INSUMO(id_control)
);
CREATE TABLE IF NOT EXISTS detalle_insumo_map
(
id_map integer constraint PK_DETALLE_INSUMO_MAP primary key AUTOINCREMENT,
id_costounitario char(12) not null,
cantidad decimal(10,4),
id_detalle numeric,
observaciones varchar(200), id_cliente NUMERIC(18, 0), ruc_cliente VARCHAR(20), dni_cliente VARCHAR(20), id_transportista NUMERIC(18, 0), id_sucursal VARCHAR(10), id_proveedor NUMERIC(18, 0),
constraint FK_DETALLE_INSUMO_MAP_CONTROL foreign key (id_detalle) references detalle_insumo(id_detalle),
constraint FK_DETALLE_INSUMO_MAP_COSTO foreign key (id_costounitario) references costo_unitario(id_costounitario)
);
CREATE TABLE IF NOT EXISTS detalle_orden(
	id_detalleorden INTEGER primary key AUTOINCREMENT,
	id_producto char(12) NULL,
	id_orden numeric(18, 0) NOT NULL,
	cantidad decimal(18, 4) NOT NULL,
	precio_unitario decimal(18, 4) NOT NULL,
	total_detalle decimal(18, 4) NOT NULL,
	observacion varchar(100) NULL,
	estado_detalle char(1) NULL,
	cantidad_entrada decimal(18, 4) NULL,
	requiere_serie char(1) NULL,
	id_unidad char(12) NULL,
	estado_cargado varchar(1) NULL,
	cantidad_devuelta decimal(10, 2) NULL,
	monto_devuelto decimal(10, 2) NULL,
	precio_compra decimal(10, 4) NULL,
	precio_conigv varchar(1) NULL,
	id_detallerequerimiento numeric(18, 0) NULL,
	requiere_lote char(1) NULL,
	porcentaje_descuento decimal(10, 2) NULL,
	porcentaje_descuento2 decimal(10, 2) NULL,
	porcentaje_descuento3 decimal(10, 2) NULL,
	id_productopresupuesto char(12) NULL,
	estado_agregado char(1) NULL,
	id_persona numeric(18, 0) NULL
 
);
CREATE TABLE IF NOT EXISTS detalle_planilla (
  id_detalleplanilla integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  id_concepto VARCHAR(10), 
  total_detalle NUMERIC, 
  id_planilla NUMERIC(18, 0) 
  constraint fk_detalle_planilla_planilla references planilla(id_planilla), 
  estado_detalle CHAR(1), 
  formula varchar(200), 
  estado_cargado varchar(1), 
  id_documento varchar(1), 
  numero_documento varchar(20), 
  serie_documento varchar(10), 
  fecha_documento date, 
  tipo_concepto varchar(10), 
  tiene_items varchar(1));
CREATE TABLE IF NOT EXISTS detalle_requerimiento (
id_detallerequerimiento integer constraint pk_detalle_requerimiento primary key autoincrement,
id_producto CHAR(12),
cantidad NUMERIC(18, 2),
precio_unitario NUMERIC(10,2),
total_detalle NUMERIC,
observacion VARCHAR(200),
id_unidad  CHAR(12),
id_unidadcompra  char(12),
id_requerimiento NUMERIC(18, 0) NOT NULL,
cantidad_compra NUMERIC(18, 2),
precio_compra NUMERIC(18,2),
factor_conversion DECIMAL(18, 2),
cantidad_atendida DECIMAL(18, 2),  
descripcion_real varchar(255), 
especificaciones varchar(255),
estado_detalle varchar(1)
, tiene_proyecto varchar(1), id_productopresupuesto char(12), cantidad_ingreso_almacen  numeric(18,2) default 0);
CREATE TABLE IF NOT EXISTS detalle_requerimiento_composicion (
id_registro integer constraint pk_temp_detalle_requerimiento primary key autoincrement,
id_detallerequerimiento numeric(18,0) NOT NULL,
id_composicion varchar(12) NOT NULL,  
cantidad numeric(18,10), 
cantidad_compra numeric(18,10)
, estado_registro varchar(1), costo_unitario decimal(18,4), id_gasto_unitario char(12), id_gasto_supervision char(12));
CREATE TABLE IF NOT EXISTS detalle_salida (
  id_detallesalida integer constraint pk_salida  PRIMARY KEY AUTOINCREMENT, 
  id_producto char(12), 
  cantidad NUMERIC(18, 4), 
  observacion VARCHAR(200), 
  id_salida NUMERIC(18, 0) 
  constraint fk_detalle_salida_salida references salida(id_salida), 
  requiere_serie CHAR(1), 
  serie_completado CHAR(1), 
  id_unidad char(12), 
  cantidad_detalle NUMERIC(18, 4), 
  numero_item NUMERIC(18, 0), 
  costo_unitario NUMERIC, 
  cantidad_devuelta NUMERIC(18, 4), 
  incluido CHAR(1), 
  id_detallepedido NUMERIC(18, 0), 
  cantidad_liquidada NUMERIC(18, 4), 
estado_detalle varchar(1), 
estado_cargado varchar(1), cantidad_aplicada decimal(10,4), id_detallerequerimiento numeric, requiere_lote char(1), lote_completado char(1), id_productopresupuesto char(12));
CREATE TABLE IF NOT EXISTS detalle_salida_map(
id_map integer constraint pk_detalle_salida_map primary key autoincrement,
id_detallesalida numeric(18,0) not null,
id_costounitario char(12) not null,
cantidad numeric(18,4),
observaciones varchar(100)
);
CREATE TABLE IF NOT EXISTS [diccionario] (
  [id_elemento] CHAR(12) NOT NULL, 
  [descripcion_elemento] VARCHAR(120), 
  [codigo_clase] VARCHAR(5), nota varchar(15), 
  CONSTRAINT [sqlite_autoindex_diccionario_1] PRIMARY KEY ([id_elemento]));
CREATE TABLE IF NOT EXISTS "distrito" ("id_distrito" CHAR(12) NOT NULL,
"nombre_distrito" VARCHAR(120),
"id_provincia" CHAR(12) NOT NULL,
PRIMARY KEY("id_distrito"));
CREATE TABLE IF NOT EXISTS documento (
  id_documento VARCHAR(10) NOT NULL, 
  descripcion_documento VARCHAR(50), 
  modulo VARCHAR(50), 
  estado_documento CHAR(1), 
  genera_impuesto CHAR(1), 
  generar_numero CHAR(1),
  codigo_documento varchar(10), 
  omite_serie CHAR(1), 
  long_maxima int, id_documentosecuencia varchar(10), 
  CONSTRAINT pk_documento PRIMARY KEY (id_documento)
);
CREATE TABLE IF NOT EXISTS documento_identidad
(
	id_documento varchar(10) constraint PK_DOCUMENTO_IDENTIDAD primary key,
	descripcion_documento varchar(50),
	codigo_documento varchar(10),
	long_maxima int,
	long_minima int
);
CREATE TABLE IF NOT EXISTS [ejc_pago] ([id_movimiento] NUMERIC(18) NOT NULL,[tipo_movimiento] VARCHAR(15) NOT NULL,[fecha_movimiento] timestamp NOT NULL, [id_cuentabanco] VARCHAR(12), [nombre_persona] VARCHAR(100),[descripcion_movimiento] VARCHAR(200),  [id_modalidadpago] VARCHAR(15),[id_proyecto] VARCHAR(12) NOT NULL,[numero_operacion] VARCHAR(50),[id_documento] VARCHAR(12),  [serie_documento] VARCHAR(12),[numero_documento] numeric,[subtotal_movimiento] DECIMAL(18,10),[monto_redondeo] DECIMAL(18,10),[total_movimiento] DECIMAL(18,10),[moneda] VARCHAR(2),[total_efectivo] DECIMAL(18,10),[moneda_efectivo] VARCHAR(2), [tipo_cambio] NUMERIC(18, 10),[monto_vuelto] DECIMAL(18,10),[moneda_vuelto] VARCHAR(2),[id_concepto] VARCHAR(12), [estado_movimiento] VARCHAR(1),[fecha_registro] TIMESTAMP,[id_usuarioanulacion] VARCHAR(15),[fecha_anulacion] TIMESTAMP,CONSTRAINT [sqlite_autoindex_ejc_pago_1] PRIMARY KEY ([id_movimiento]));
CREATE TABLE IF NOT EXISTS estado_civil
(
	id_estadocivil varchar(10) constraint PK_ESTADO_CIVIL primary key,
	descripcion_estadocivil varchar(20)
);
CREATE TABLE IF NOT EXISTS event_kanban (
    id_event_kanban INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo varchar(75),
    descripcion varchar(255),
    start_date date,
    end_date date,
    all_day char(1),
    event_state INTEGER,
    label_id INTEGER,
    status_id INTEGER,
    archivo_file blob,
    extension_file varchar(8),
    location varchar(75),
    reminder_info varchar(50),
    recurrence_info varchar(50),
    event_type Integer,
    id_costounitario Char(12)
  , show_kanboard char(1), es_terminado CHAR(1), id_kanbanpadre INTEGER, prioridad INTEGER, color_kanban int);
CREATE TABLE IF NOT EXISTS excepcion(
id_excepcion integer primary key autoincrement,
nombre_excepcion varchar(100),
fecha_inicio TIMESTAMP,
fecha_fin TIMESTAMP,
id_calendario integer not null,
tipo_excepcion integer not null
, dia_semana integer, dia_mes integer, numero_semana integer, numero_mes integer, color_fondo integer);
CREATE TABLE IF NOT EXISTS feriado
(
id_feriado numeric constraint PK_FERIADO primary key,
id_proyecto char(12),
fecha_inicio varchar(10),
fecha_fin varchar(10),
es_feriado varchar(1)
);
CREATE TABLE IF NOT EXISTS forma_pago (
id_formapago VARCHAR(10) NOT NULL,
descripcion_formapago VARCHAR(50),
verifica_persona CHAR(1),
agrega_cuenta CHAR(1),
PRIMARY KEY(id_formapago)
);
CREATE TABLE IF NOT EXISTS formato_documento
(
 id_formato integer  constraint PK_FORMATO_DOCUMENTO primary key autoincrement,
 id_documento varchar(10) constraint FK_FORMATO_DOCUMENTO_DOCUMENTO
references DOCUMENTO(id_documento),
 id_sucursal varchar(10) constraint FK_FORMATO_DOCUMENTO_SUCURSAL
references SUCURSAL(id_sucursal) ,
 maximo_items integer, 
 cols_series integer
);
CREATE TABLE IF NOT EXISTS gasto_diario
(
  id_gasto numeric constraint pk_gasto_diario primary key,  
  fecha date,
  cantidad decimal(10,2),  
  id_costounitario char(12) constraint fk_gasto_diario_cu references costo_unitariogasto(id_costounitario)
  );
CREATE TABLE IF NOT EXISTS gasto_diario_supervision
(
  id_gasto numeric constraint pk_gasto_diario_spv primary key,  
  fecha date,
  cantidad decimal(10,2),  
  id_costounitario char(12) constraint fk_gasto_diariospv_cu references costo_unitariosupervision(id_costounitario)
  );
CREATE TABLE IF NOT EXISTS grupo_plan(
id_grupo varchar(10) constraint pk_grupo_plan primary key,
descripcion_grupo varchar(50),
estado_grupo varchar(1)
);
CREATE TABLE IF NOT EXISTS hoja_planilla (
	id_hoja INTEGER PRIMARY KEY AUTOINCREMENT,
	mes_planilla INTEGER,
	anio_planilla INTEGER,
	numero_planilla INTEGER,
	fecha_inicio TIMESTAMP,
	fecha_cierre TIMESTAMP,
	observacion VARCHAR(255),
	estado_hoja CHAR(1),
	id_proyecto CHAR(12)
);
CREATE TABLE IF NOT EXISTS horario(
id_horario integer primary key autoincrement,
dia_semana integer not null,
hora_inicio TIMESTAMP,
hora_fin TIMESTAMP,
id_calendario integer not null,
es_laborable char(1)
);
CREATE TABLE IF NOT EXISTS horario_ex(
id_horario integer primary key autoincrement,
dia_semana integer not null,
hora_inicio TIMESTAMP,
hora_fin TIMESTAMP,
id_excepcion integer not null
);
CREATE TABLE IF NOT EXISTS id_table
(
 id varchar(12) primary key not null
);
CREATE TABLE IF NOT EXISTS "indice" ("id_indice" CHAR(12) NOT NULL,
"id_titulo" CHAR(12),
"coeficiente" NUMERIC(16, 10),
"porcentaje" NUMERIC(16, 2) DEFAULT 0.00,
"codigo_clase" VARCHAR(20), coeficientedefinido NUMERIC(16,10),
PRIMARY KEY("id_indice"));
CREATE TABLE IF NOT EXISTS indice_precio
(      
       id_indice numeric constraint pk_indice_precio primary key,       
       numero_mes int,       
       numero_anio int,              
       codigo_clase varchar(5),
       numero_region int,
       valor_indice decimal(10,2)       
);
CREATE TABLE IF NOT EXISTS "infraestructura" ("id_infraestructura" CHAR(12) NOT NULL,
"nombre_infraestructura" VARCHAR(120),
"codigo_infraestructura" VARCHAR(20),
PRIMARY KEY("id_infraestructura"));
CREATE TABLE IF NOT EXISTS inventario
(
       id_inventario numeric constraint PK_INVENTARIO  primary key,       
       fecha_inicio date,       
       fecha_fin date,       
       es_ultimo varchar(1)
);
CREATE TABLE IF NOT EXISTS kanban_personal_clave    
(
	id_kanban_personal_clave integer primary key,
	id_event_kanban integer,
	id_responsable NUMERIC(18, 0),
	porcentaje_asignado decimal(10,4)
);
CREATE TABLE IF NOT EXISTS kardex (
  id_movimiento integer constraint pk_movimiento PRIMARY KEY AUTOINCREMENT, 
  descripcion_movimiento VARCHAR(100), 
  fecha_movimiento TIMESTAMP, 
  id_documento VARCHAR(10), 
  serie_documento VARCHAR(50), 
  numero_documento VARCHAR(50), 
  id_producto  CHAR(12) NOT NULL, 
  entrada_almacen NUMERIC(18, 2), 
  salida_almacen NUMERIC(18, 2), 
  saldo_almacen NUMERIC(18, 2), 
  id_sucursal VARCHAR(10) NOT NULL, 
  ultimo_movimiento CHAR(1), 
  entrada_valoralmacen NUMERIC, 
  salida_valoralmacen NUMERIC, 
  saldo_valoralmacen NUMERIC, 
  id_unidadkardex VARCHAR(10), 
  cantidad_kardex NUMERIC(18, 2), 
  valor_unitario NUMERIC, 
  id_motivokardex VARCHAR(10), 
  costo_unitario NUMERIC, 
  estado_kardex CHAR(1), 
  id_detallecomprafact NUMERIC(18, 0), 
  costo_salida NUMERIC, 
  id_detallesalida NUMERIC(18, 0), 
  id_detallenotakardex numeric, 
  id_detallecomprakardex numeric, 
  id_detalleventakardex numeric, 
  fecha_registro date, 
  tipo_movimiento varchar(10), 
  orden int, 
  costo_entrada decimal(10,2), 
  id_inventario numeric, 
  id_detallenotacompra numeric, 
  entrada_fisico decimal(10,2), 
  salida_fisico decimal(10,2), 
  saldo_fisico decimal(10,2), 
  id_detalledevolucion numeric, costo_entrada_fisico decimal(10,2), costo_salida_fisico decimal(10,2), costo_saldo_fisico decimal(10,2), monto_entrada_fisico decimal(10,2), monto_salida_fisico decimal(10,2), monto_saldo_fisico decimal(10,2));
CREATE TABLE IF NOT EXISTS linea_base
( 

id_linea integer primary key autoincrement,
nombre_linea varchar(100),
fecha_linea date,
id_proyecto char(12) not null
, color_linea_base integer);
CREATE TABLE IF NOT EXISTS "lista_precio" ("id_listaprecio" CHAR(12) NOT NULL,
"descripcion_listaprecio" VARCHAR(255),
"especificaciones_precio" VARCHAR(255),
"id_unidad" CHAR(12),
"costo_unitariolista" NUMERIC(16, 2),
"fecha_listaprecio" VARCHAR(10),
"id_clase" CHAR(12),
"id_subclase" CHAR(12),
"codigo_clase" VARCHAR(50),
"codigo_subclase" VARCHAR(50),
"codigo_listaprecio" VARCHAR(50),
"codigo_crepco" VARCHAR(50),
"imagen" BLOB,
"ficha_tecnica1" BLOB,
"nombre_fichatecnica1" VARCHAR(200),
"ficha_tecnica2" BLOB,
"nombre_fichatecnica2" VARCHAR(200),
"ficha_tecnica3" BLOB,
"nombre_fichatecnica3" VARCHAR(200),
"id_elemento" VARCHAR(12),
"id_tipocosto" VARCHAR(12),
"id_usuariocreate" CHAR(12),
PRIMARY KEY("id_listaprecio"));
CREATE TABLE IF NOT EXISTS "localidad" ("id_localidad" CHAR(12) NOT NULL,
"nombre_localidad" VARCHAR(120),
"id_distrito" CHAR(12) NOT NULL,
PRIMARY KEY("id_localidad"));
CREATE TABLE IF NOT EXISTS log_objs_changes (
    id_log_change INTEGER PRIMARY KEY,
    instance_machine TEXT,
    obj BLOB,
    last_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    use_instances TEXT
);
CREATE TABLE IF NOT EXISTS marca (
  id_marca VARCHAR(10) NOT NULL, 
  descripcion_marca VARCHAR(50), imagen blob, estado_marca char(1), 
  CONSTRAINT pk_marca PRIMARY KEY (id_marca));
CREATE TABLE IF NOT EXISTS messages_app ( 
    id_mensaje  INTEGER PRIMARY KEY AUTOINCREMENT,
    id_persona_to  numeric(18, 0),            
    id_persona_from  numeric(18, 0),            
    message_text  TEXT,            
    sent_or_updated date,            
    is_edited  CHAR(1),  
    is_deleted CHAR(1),   
    is_liked CHAR(1),  
    is_first_message_of_reply CHAR(1),  
    is_first_message_of_block CHAR(1)  
, is_delivered char(1), is_read char(1));
CREATE TABLE IF NOT EXISTS "metrado" ("id_metrado" CHAR(12) NOT NULL,
"descripcion_metrado" VARCHAR(255),
"id_costounitario" CHAR(12),
"unidades" NUMERIC(16, 2),
"cantidadxunidad" NUMERIC(16, 2),
"largo" NUMERIC(16, 2),
"ancho" NUMERIC(16, 2),
"alto" NUMERIC(16, 2),
"parcial_metrado" NUMERIC(16, 2),
"observaciones" VARCHAR(255),
"imagen" BLOB,
"diametro" VARCHAR(10),
"longitud_pieza" NUMERIC(10, 2),
"parcial1_4" NUMERIC(16, 2),
"parcial3_8" NUMERIC(16, 2),
"parcial1_2" NUMERIC(16, 2),
"parcial5_8" NUMERIC(16, 2),
"parcial3_4" NUMERIC(16, 2),
"parcial1_1" NUMERIC(16, 2), parcial6mm numeric(16,2), parcial8mm numeric(16,2), parcial12mm numeric(16,2), parcial7_8 numeric(16,2), parcial9_8 numeric(16,2), parcial10_8 numeric(16,2), parcial11_8 numeric(16,2), parcial4mm numeric(16,2), parcial4_5mm numeric(16,2), parcial5mm numeric(16,2), parcial5_5mm numeric(16,2), parcial6_5mm numeric(16,2), parcial7mm numeric(16,2), parcial7_5mm  numeric(16,2), parcial8_5mm numeric(16,2), posicion int, cols_image int, longitud_gancho decimal(10,2), longitud_empalme decimal(10,2), porcentaje_desperdicio decimal(10,2), tipo_gancho varchar(1), tipo_empalme varchar(1), tipo_desperdicio varchar(1), tipo_estribo varchar(1), direccion_estribo varchar(1), longitud_distribuir decimal(10,2), cantidad_estribo1 decimal(10,2), cantidad_estribo2 decimal(10,2), cantidad_estribo3 decimal(10,2), cantidad_estribo4 decimal(10,2), espacio_estribo1 decimal(10,2), espacio_estribo2 decimal(10,2), espacio_estribo3 decimal(10,2), espacio_estribo4 decimal(10,2), agregar_nudo varchar(1), color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), color_fondo integer, peso NUMERIC(16, 2), area NUMERIC(16, 2), volumen NUMERIC(16, 2), propiedad_largo varchar(150), propiedad_ancho varchar(150), propiedad_alto varchar(150), propiedad_peso varchar(150), propiedad_area varchar(150), propiedad_volumen varchar(150), bim_guid varchar(128), propiedad_profundidad varchar(150), propiedad_perimetro varchar(150), propiedad_alturanominal varchar(150), propiedad_longnominal varchar(150), propiedad_anchonominal varchar(150), propiedad_areasecciontransv varchar(150), propiedad_areabruta varchar(150), propiedad_areabrutahuella varchar(150), propiedad_arealateralbruta varchar(150), propiedad_arealateralbrutaizq varchar(150), propiedad_arealateralbrutader varchar(150), propiedad_areasuperficiebruta varchar(150), propiedad_areaneta varchar(150), propiedad_areanetahuella varchar(150), propiedad_arealateralneta varchar(150), propiedad_arealateralnetaizq varchar(150), propiedad_arealateralnetader varchar(150), propiedad_areasuperficieneta varchar(150), propiedad_areasuperficieext varchar(150), propiedad_areaproyectada varchar(150), propiedad_volumenbruto varchar(150), propiedad_pesobruto varchar(150), propiedad_canareasupneta varchar(150), propiedad_canvolneto varchar(150), profundidad decimal(16,2), perimetro decimal(16,2), alturanominal decimal(16,2), longnominal decimal(16,2), anchonominal decimal(16,2), areasecciontransv decimal(16,2), areabruta decimal(16,2), areabrutahuella decimal(16,2), arealateralbruta decimal(16,2), arealateralbrutaizq decimal(16,2), arealateralbrutader decimal(16,2), areasuperficiebruta decimal(16,2), areaneta decimal(16,2), areanetahuella decimal(16,2), arealateralneta decimal(16,2), arealateralnetaizq decimal(16,2), arealateralnetader decimal(16,2), areasuperficieneta decimal(16,2), areasuperficieext decimal(16,2), areaproyectada decimal(16,2), volumenbruto decimal(16,2), pesobruto decimal(16,2), canareasupneta decimal(16,2), canvolneto decimal(16,2), duracion int, fecha_inicio date, fecha_fin date, es_hito char(1), porcentaje_completado decimal(10,2), formula1 varchar(255), formula2 varchar(255), editor_metrado char(2), duracion_new DECIMAL(12,4),
PRIMARY KEY("id_metrado"));
CREATE TABLE IF NOT EXISTS metrado_bim (
id_metrado CHAR(12) NOT NULL,
descripcion_metrado VARCHAR(255),
posicion int,
id_titulo CHAR(12),
unidades NUMERIC(16, 2),
cantidadxunidad NUMERIC(16, 2),
largo NUMERIC(16, 2),
ancho NUMERIC(16, 2),
alto NUMERIC(16, 2),
peso NUMERIC(16, 2),
area NUMERIC(16, 2),
volumen NUMERIC(16, 2),
parcial_metrado NUMERIC(16, 2),
observaciones VARCHAR(255),
color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), color_fondo numeric,
propiedad_largo varchar(150),
propiedad_ancho varchar(150),
propiedad_alto varchar(150),
propiedad_peso varchar(150),
propiedad_area varchar(150),
propiedad_volumen varchar(150),
bim_guid varchar(128), id_costounitario char(12),
PRIMARY KEY(id_metrado)
);
CREATE TABLE IF NOT EXISTS metrado_diario
(
  id_metrado numeric constraint pk_metrado_diario primary key,  
  fecha date,
  cantidad decimal(10,2),  
  id_costounitario char(12) constraint fk_metrado_diario_cu references costo_unitario(id_costounitario)
  );
CREATE TABLE IF NOT EXISTS metrado_ejecutado
(
  id_metrado integer constraint pk_metrado_ejecutado primary key autoincrement,  
  numero_periodo integer,  
  cantidad decimal(10,2),  
  id_costounitario char(12) constraint fk_metrado_ejecutado_cu references costo_unitario(id_costounitario)
);
CREATE TABLE IF NOT EXISTS metrado_valorizado
(
  id_metrado numeric constraint pk_metrado_valorizado primary key,  
  numero_mes int,  
  numero_anio int,  
  cantidad decimal(10,2),  
  id_costounitario char(12) constraint fk_metrado_valoriz_cu references costo_unitario(id_costounitario)
, id_valorizacion integer);
CREATE TABLE IF NOT EXISTS modalidad_map
(
	id_modalidadmap integer constraint PK_MODALIDAD_MAP primary key autoincrement,
	id_modalidad varchar(10) not null constraint FK_MODALIDAD_MAP_MODALIDAD
references MODALIDAD_PAGO(id_modalidadpago),
	id_concepto varchar(10) not null constraint FK_MODALIDAD_MAP_CONCEPTO
references CONCEPTO(id_concepto) ,
	permitido varchar(1)
);
CREATE TABLE IF NOT EXISTS modalidad_pago (
id_modalidadpago VARCHAR(10) NOT NULL,
descripcion_modalidadpago VARCHAR(100),
tipo_cuenta VARCHAR(20),
documentos_ingreso VARCHAR(50),
documentos_egreso VARCHAR(50), orden integer,
constraint pk_modalidad_pago PRIMARY KEY(id_modalidadpago)
);
CREATE TABLE IF NOT EXISTS moneda(
id_moneda varchar(10) not null constraint PK_MONEDA primary key,
nombre_moneda varchar(20) not null,
simbolo_moneda varchar(10) not null
);
CREATE TABLE IF NOT EXISTS motivo (
  id_motivo VARCHAR(10) NOT NULL, 
  descripcion_motivo VARCHAR(60), 
  afecta_kardex CHAR(1), 
  solo_empresa CHAR(1), 
  verifica_destino CHAR(1), 
  permitir_proveedor CHAR(1), 
  estado_motivo CHAR(1), 
  requiere_persona CHAR(1), 
  permitir_empresa CHAR(1), 
  codigo_motivo VARCHAR(10), 
  requiere_responsable CHAR(1), 
  requiere_liquidacion CHAR(1), 
  afecta_fisico varchar(1), codigo_sunat varchar(10), tipo_motivo varchar(20), requiere_proyecto varchar(1), 
  CONSTRAINT pk_motivo PRIMARY KEY (id_motivo)
  );
CREATE TABLE IF NOT EXISTS nota_compra (
  id_notacompra integer PRIMARY KEY autoincrement, 
  id_documento varchar(10) NOT NULL CONSTRAINT FK_NOTA_COMPRA_DOCUMENTO REFERENCES DOCUMENTO(id_documento), 
  serie_documento varchar(20) NOT NULL, 
  numero_documento varchar(20), 
  fecha_documento date, 
  observacion varchar(80), 
  id_usuario varchar(12) CONSTRAINT FK_NOTA_COMPRA_USUARIO REFERENCES USUARIO(id_usuario), 
  estado_registro varchar(1), 
  fecha_registro date, 
  fecha_anulacion date, 
  id_usuarioanulacion varchar(12) CONSTRAINT FK_NOTA_COMPRA_USUARIOANULL REFERENCES USUARIO(id_usuario), 
  id_proveedor numeric(18,0) CONSTRAINT FK_NOTA_PROVEEDOR REFERENCES PERSONA(id_persona), 
  nombre_proveedor varchar(255), 
  ruc_proveedor varchar(20), 
  dni_proveedor varchar(20), 
  direccion_proveedor varchar(200), 
  id_sucursal varchar(10) CONSTRAINT FK_NOTA_COMPRA_SUCURSAL REFERENCES SUCURSAL(id_sucursal), 
  subtotal decimal(10,2), 
  monto_descuento decimal(10,2), 
  total_documento decimal(10,2), 
  monto_igv decimal(18,4), 
  valor_venta decimal(18,4), 
  porcentaje_igv decimal(18,4), 
  id_moneda varchar(10), 
  monto_pagado decimal(10,2), 
  estado_pagado varchar(1), 
  afectar_orden varchar(1), 
  fecha_pago date, 
  estado_cargado varchar(1), 
  id_usuariomodificacion varchar(12), 
  fecha_modificacion date, 
  id_comprafact numeric CONSTRAINT FK_NOTA_COMPRA_COMPRA REFERENCES COMPRA_FACT(id_comprafact), 
  afecta_caja varchar(1), 
  id_documentoidentidad varchar(10), 
  ajuste_precio varchar(1), 
  tipo_cambio decimal(10,4), 
  tipo_cambiocontable decimal(10,4), 
  id_monedabase varchar(10), 
  fecha_ingreso date, 
  valor_compra decimal(10,2));
CREATE TABLE IF NOT EXISTS orden_compra(
	id_orden INTEGER primary key AUTOINCREMENT,
	id_documento varchar(10) NULL,
	serie_documento varchar(20) NULL,
	numero_documento varchar(20) NULL,
	fecha_documento datetime NOT NULL,
	id_monedabase varchar(10) NULL,
	id_moneda varchar(10) NULL,
	tipo_cambio decimal(18, 4) NULL,
	total_documento decimal(18, 4) NULL,
	observacion varchar(100) NULL,
	id_usuario char(12) NULL,
	estado_registro char(1) NULL,
	fecha_registro datetime NULL,
	fecha_anulacion datetime NULL,
	id_usuarioanulacion char(12) NULL,
	id_proveedor decimal(18, 0) NULL,
	id_formapago varchar(10) NULL,
	porcentaje_igv decimal(9, 4) NULL,
	valor_compra decimal(18, 4) NULL,
	monto_igv decimal(18, 4) NULL,
	monto_pagado decimal(18, 4) NULL,
	estado_pagado char(1) NULL,
	estado_entrada char(1) NULL,
	requiere_entrada char(1) NULL,
	fecha_ingreso datetime NOT NULL,
	id_sucursal varchar(10) NULL,
	fecha_modificacion datetime NULL,
	id_usuariomodificacion char(12) NULL,
	fecha_pago datetime NULL,
	tipo_cambiocontable decimal(10, 2) NULL,
	id_concepto varchar(10) NULL,
	es_servicio varchar(1) NULL,
	monto_flete decimal(10, 2) NULL,
	moneda_flete varchar(10) NULL,
	monto_canje decimal(10, 2) NULL,
	fecha_detraccion datetime NULL,
	numero_detraccion varchar(20) NULL,
	monto_detraccion decimal(10, 2) NULL,
	mes_contabilidad int NULL,
	anio_contabilidad int NULL,
	fecha_vencimiento datetime NULL,
	id_cuenta numeric(18, 0) NULL,
	id_proyecto char(12) NULL,
	id_empresa numeric(18, 0) NULL,
	id_documento_ref varchar(10) NULL,
	serie_documento_ref varchar(20) NULL,
	numero_documento_ref varchar(20) NULL,
	fecha_documento_ref datetime NULL,
	id_moneda_ref varchar(10) NULL,
	id_categoria varchar(12) NULL
, estado_atendido char(1) default 'N', id_sucursalatender varchar(10), id_responsable NUMERIC(18, 0));
CREATE TABLE IF NOT EXISTS pago_planilla (
  id_pago  integer constraint pk_pago_planilla PRIMARY KEY AUTOINCREMENT, 
  id_documento VARCHAR(10), 
  serie_documento VARCHAR(10), 
  numero_documento VARCHAR(20), 
  fecha_pago TIMESTAMP, 
  id_documentopago VARCHAR(10), 
  serie_documentopago VARCHAR(10), 
  numero_documentopago VARCHAR(20), 
  monto_afectar NUMERIC(10,2), 
  id_moneda VARCHAR(10), 
  tipo_pago VARCHAR(10), 
  id_modalidadpago VARCHAR(10), 
  id_detalleplanilla NUMERIC(18, 0), 
  id_movimiento numeric);
CREATE TABLE IF NOT EXISTS pais_info (id_paisinfo char(12) primary key ,nombre_paisinfo varchar(50),simbolo_moneda varchar(10),nombre_moneda varchar(50),tipo_cambio decimal(16,10), fecha_cambio varchar(20), id_moneda varchar(10));
CREATE TABLE IF NOT EXISTS pais_info_log(id_paisinfo_log integer,id_proyecto char(12),id_paisinfo char(12),tipo_cambio decimal(16,10),old_id_paisinfo char(12),old_tipo_cambio decimal(16,10),fecha_log varchar(20), id_moneda varchar(10));
CREATE TABLE IF NOT EXISTS parametro (
id_parametro VARCHAR(50) NOT NULL,
descripcion_parametro VARCHAR(50),
valor_parametro decimal(10,4),
valor_texto varchar(255), valor_blob blob, 
PRIMARY KEY(id_parametro)
);
CREATE TABLE IF NOT EXISTS "partida" ("id_partida" CHAR(12) NOT NULL,
"descripcion_partida" VARCHAR(255), id_plantilla varchar(12), id_titulopadre varchar(12), posicion_titulo numeric, estado_bloqueado char(1), estado_expandido char(1), numeracion_titulo varchar(120),
PRIMARY KEY("id_partida"));
CREATE TABLE IF NOT EXISTS perfil (
	id_perfil varchar (10)  not null ,
	descripcion_perfil varchar (50)  null ,
	info_perfil varchar (100)  null ,
	requiere_sucursal varchar (1)  null ,
	requiere_caja varchar (1)  null , cambiar_sucursal varchar(1), requiere_mismo_almacen  varchar(1),
	constraint pk_perfil primary key 
	(
		id_perfil
	)  
);
CREATE TABLE IF NOT EXISTS perfil_map (
	id_perfilmap INTEGER not null constraint pk_perfil_map primary key AUTOINCREMENT,
	id_acceso varchar (100)  not null ,
	nombre_acceso varchar (50)  not null ,
	id_perfil varchar (10)  not null ,
	permitido varchar (1)  not null , tipo_atajo int, orden_atajo int,
		constraint fk_perfil_map foreign key 
	(
		id_perfil
	) references perfil (
		id_perfil
	)
);
CREATE TABLE IF NOT EXISTS persona (
  id_persona NUMERIC(18, 0) NOT NULL constraint pk_persona primary key, 
  clase_persona VARCHAR(10), 
  nombre_persona VARCHAR(100), 
  apellidos_persona VARCHAR(50), 
  fecha_nacimiento TIMESTAMP, 
  profesion VARCHAR(60), 
  estado_civil VARCHAR(10), 
  sexo CHAR(1), 
  id_supervisor NUMERIC(18, 0), 
  direccion VARCHAR(100), 
  telefono VARCHAR(20), 
  lugar_trabajo VARCHAR(80), 
  direccion_trabajo VARCHAR(80), 
  telefono_trabajo VARCHAR(20), 
  movil VARCHAR(20), 
  dni VARCHAR(20), 
  ruc VARCHAR(20), 
  email VARCHAR(30), 
  email_alternativo VARCHAR(30), 
  sitio_web VARCHAR(150), 
  id_tipopersona VARCHAR(10) constraint fk_tipo_persona_persona references tipo_persona(id_tipopersona), 
  id_institucion NUMERIC(18, 0), 
  id_cargo VARCHAR(10), 
  descripcion_cargo VARCHAR(60), 
  estado_persona CHAR(1), 
  id_sucursal VARCHAR(10), 
  id_sucursallabora VARCHAR(10), 
  moneda_facturacion VARCHAR(10), 
  fecha_registro TIMESTAMP, 
  id_usuarioregistro CHAR(12), 
  fecha_modificacion TIMESTAMP, 
  id_usuariomodificacion CHAR(12), 
  fecha_anulacion TIMESTAMP, 
  id_usuarioanulacion CHAR(12), 
  id_supervisornegocios NUMERIC(18, 0), 
  en_planilla varchar(1), 
  fecha_planilla date, 
  id_tipopersonacomision varchar(10), 
  id_distrito CHAR(12) constraint fk_persona_distrito references distrito(id_distrito), 
  id_localidad CHAR(12), nombre_comercial varchar(100), tipo_afp varchar(10), imagen blob, version int default(1), cuenta_soles varchar(50), banco_soles varchar(80), moneda_soles varchar(10), cuenta_dolares varchar(50), banco_dolares varchar(80), moneda_dolares varchar(10), date_version TIMESTAMP, telefono_anexo varchar(50), tipo_comision varchar(10), color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), color_fondo numeric, check_mostrar char(1), imagen2 BLOB);
CREATE TABLE IF NOT EXISTS planilla (
  id_planilla integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  id_hoja NUMERIC(18, 0) constraint fk_planilla_hoja references hoja_planilla(id_hoja), 
  id_persona NUMERIC(18, 0), 
  id_documento VARCHAR(10), 
  serie_documento VARCHAR(10), 
  numero_documento VARCHAR(20), 
  fecha_documento TIMESTAMP, 
  observacion VARCHAR(255), 
  estado_registro CHAR(1), 
  fecha_registro TIMESTAMP, 
  id_usuario char(12), 
  fecha_anulacion TIMESTAMP, 
  id_usuarioanulacion char(12), 
  total_ingreso NUMERIC, 
  total_egreso NUMERIC, 
  total_aportacion NUMERIC, 
  monto_neto NUMERIC, 
  monto_pagado NUMERIC, 
  estado_pagado CHAR(1), 
  fecha_pago TIMESTAMP, 
  id_moneda VARCHAR(10), 
  estado_cargado CHAR(1), 
  fecha_cargo TIMESTAMP, 
  fecha_modificacion date, 
  id_usuariomodificacion char(12)
  , porcentaje_fondo decimal(10,4), porcentaje_seguro decimal(10,4), porcentaje_flujo decimal(10,4), porcentaje_mixta decimal(10,4));
CREATE TABLE IF NOT EXISTS planilla_map (
  id_planillamap integer PRIMARY KEY autoincrement, 
  id_persona numeric(18,0) NOT NULL CONSTRAINT FK_PLANILLA_MAP_PERSONA references persona(id_persona), 
  id_concepto varchar(10) NOT NULL CONSTRAINT FK_PLANILLA_MAP_CONCEPTO references concepto(id_concepto), 
  total_detalle decimal(10,2));
CREATE TABLE IF NOT EXISTS planoteca (id_archivo numeric(18,0),titulo_archivo VARCHAR(255),nombre_archivo VARCHAR(31),archivo BLOB,id_proyecto CHAR(12),PRIMARY KEY(id_archivo));
CREATE TABLE IF NOT EXISTS plantilla_clasificador(
  id_plantilla CHAR(12) NOT NULL, 
  nombre_plantilla VARCHAR(255),   
  es_predeterminada varchar(1),  
  anio int,
  CONSTRAINT pk_plantilla_clasificador  PRIMARY KEY (id_plantilla)
  );
CREATE TABLE IF NOT EXISTS "plantilla_gasto" ("id_plantilla" CHAR(12) NOT NULL,
"nombre_plantilla" VARCHAR(255),
"estado_expandido" CHAR(1),
"posicion_plantilla" INTEGER,
"numeracion_plantilla" VARCHAR(120),
"id_unidadduracion" DATE, modalidad_ejecucion char(1),
PRIMARY KEY("id_plantilla"));
CREATE TABLE IF NOT EXISTS plantilla_partida(
  id_plantilla CHAR(12) NOT NULL, 
  nombre_plantilla VARCHAR(255),   
  es_predeterminada varchar(1),
  CONSTRAINT sqlite_autoindex_plantilla_partida 
  PRIMARY KEY (id_plantilla));
CREATE TABLE IF NOT EXISTS portafolio
(
    id_portafolio CHAR(12) NOT NULL,
    nombre_portafolio VARCHAR(120),
    codigo_portafolio VARCHAR(120),
    PRIMARY KEY (id_portafolio)
);
CREATE TABLE IF NOT EXISTS precio_producto (
  id_precio integer PRIMARY KEY AUTOINCREMENT, 
  id_estacion VARCHAR(10) NOT NULL, 
  id_producto VARCHAR(50), 
  id_plan VARCHAR(50), 
  id_permanencia VARCHAR(10), 
  precio_equipo NUMERIC, 
  estado_vigente CHAR(1), 
  id_unidad VARCHAR(50), 
  porcentaje_ganancia decimal(10,2), 
  porcentaje_proteccion decimal(10,2), 
  tipo_cambio decimal(10,2), 
  costo_total decimal(10,2)
);
CREATE TABLE IF NOT EXISTS "presupuesto" ("id_presupuesto" CHAR(12) NOT NULL,
"nombre_presupuesto" VARCHAR(255),
"costo_directo" NUMERIC(20, 6) DEFAULT 0.000000,
"porcentaje_gasto" NUMERIC(16, 10) DEFAULT 0.0000000000,
"monto_gasto" NUMERIC(20, 6) DEFAULT 0.000000,
"porcentaje_utilidad" NUMERIC(16, 2) DEFAULT 0.00,
"monto_utilidad" NUMERIC(16, 2) DEFAULT 0.00,
"porcentaje_igv" NUMERIC(16, 2) DEFAULT 0.00,
"monto_igv" NUMERIC(16, 2) DEFAULT 0.00,
"parcial_presupuesto" NUMERIC(16, 2) DEFAULT 0.00,
"total_presupuesto" NUMERIC(16, 2) DEFAULT 0.00,
"id_proyecto" CHAR(12) NOT NULL,
"estado_expandido" CHAR(1),
"posicion_presupuesto" INTEGER,
"numeracion_presupuesto" VARCHAR(120),
"total_gasto" NUMERIC(16, 2) DEFAULT 0.00,
"duracion" NUMERIC(16, 2),
"id_unidadduracion" CHAR(12),
"fecha_inicio" VARCHAR(12),
"fecha_fin" VARCHAR(12),
"tipo_cambio" NUMERIC(16, 4) DEFAULT 0.0000,
"monto_dolares" NUMERIC(16, 2) DEFAULT 0.00,
"monto_adj" NUMERIC(16, 4) DEFAULT 0.0000,
"Proyecto" VARCHAR(100), monto_impuestootro decimal(16,2), id_responsable varchar(12), costo_directo_val  decimal(10,2), porcentaje_gasto_val  decimal(10,4), porcentaje_gastootro_val  decimal(10,4), porcentaje_utilidad_val  decimal(10,4), porcentaje_igv_val decimal(10,4), porcentaje_impuestootro_val  decimal(10,4), factor_valorizacion decimal(10,5), color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), costo_otro decimal(16,2), monto_gastootro decimal(16,2), porcentaje_impuestootro decimal(16,4), duration int, start_date date, end_date date, es_hito char(1), porcentaje_completado decimal(10,2), color_fondo integer, etiqueta integer, id_unidad_val char(12), porcentaje_supervision decimal(18,10), monto_supervision decimal(18,4), total_supervision decimal(18,4), bim_filename varchar(255), numeracion_norma varchar(50), task_mode integer, decimales_polinomica varchar(10), duracion_new DECIMAL(12,4),
PRIMARY KEY("id_presupuesto"));
CREATE TABLE IF NOT EXISTS presupuesto_val
(
id_presupuesto_val char(12) primary key,
id_presupuesto char(12),
id_responsable numeric,
fecha_valorizacion date,
dias_valorizacion integer,
id_unidad_val char(12)
, parcial_presupuesto decimal(18,4), costo_directo_val  decimal(10,2), porcentaje_gasto_val  decimal(10,4), porcentaje_gastootro_val  decimal(10,4), porcentaje_utilidad_val  decimal(10,4), porcentaje_igv_val decimal(10,4), porcentaje_impuestootro_val  decimal(10,4), factor_valorizacion decimal(10,5), monto_gastootro_val decimal(18,4), otros_costos_directos decimal(18,4), dia_semana numeric, k_manual char(1));
CREATE TABLE IF NOT EXISTS producto (
id_producto CHAR(12) NOT NULL,
descripcion_producto VARCHAR(255),
especificaciones VARCHAR(255),
id_unidad CHAR(12),
costo_unitariolista NUMERIC(16, 2),
fecha_listaprecio VARCHAR(10),
id_clase CHAR(12),
id_subclase CHAR(12),
codigo_clase VARCHAR(50),
codigo_subclase VARCHAR(50),
codigo_producto VARCHAR(50),
imagen BLOB,
ficha_tecnica1 BLOB,
nombre_fichatecnica1 VARCHAR(200),
ficha_tecnica2 BLOB,
nombre_fichatecnica2 VARCHAR(200),
ficha_tecnica3 BLOB,
nombre_fichatecnica3 VARCHAR(200),
id_elemento VARCHAR(12),
id_tipocosto VARCHAR(12),
id_usuariocreate CHAR(12),

codigo_barras varchar(50),
modelo varchar(50),
estado_producto char(1),
id_marca varchar(10),
id_categoria varchar(12),
es_gravado varchar(1), descripcion_proveedor varchar(100), costo_unitario decimal(10,2), costo_flete decimal(10,2), id_monedacosto varchar(10), date_version TIMESTAMP, codigo_electrico varchar(50), id_aplica_tipocosto varchar(12), include_percent  char(1), id_paisinfo char(12),
constraint pk_producto PRIMARY KEY(id_producto)
);
CREATE TABLE IF NOT EXISTS producto_compra (
id_producto CHAR(12) NOT NULL,
descripcion_producto VARCHAR(255),
especificaciones VARCHAR(255),
id_unidad CHAR(12),
id_clase CHAR(12),
id_subclase CHAR(12),
codigo_clase VARCHAR(50),
codigo_subclase VARCHAR(50),
codigo_producto VARCHAR(50),
imagen BLOB,
id_productobase char(12),
id_tipocosto VARCHAR(12),
id_usuariocreate CHAR(12),
codigo_barras varchar(50),
modelo varchar(50),
estado_producto char(1),
id_marca varchar(10),
id_categoria varchar(12),
es_gravado varchar(1), costo_unitario decimal(10,2), id_monedacosto varchar(10), date_version TIMESTAMP, factor_conversion NUMERIC(28,18), 
constraint pk_producto_compra PRIMARY KEY(id_producto)
);
CREATE TABLE IF NOT EXISTS producto_values(id_values int,id_producto char(12),costo_unitario decimal(16,10),id_paisinfo char(12),fecha_log varchar(20));
CREATE TABLE IF NOT EXISTS "programacion_costo" ("id_programacion" CHAR(12) NOT NULL,
"id_costounitario" CHAR(12),
"dia_inicio" INTEGER,
"fecha_inicio" VARCHAR(10),
"duracion" INTEGER,
"fecha_fin" VARCHAR(10),
"dia_fin" INTEGER,
"cantidad" NUMERIC(16, 2),
"porcentaje" NUMERIC(16, 2),
"numero_periodo" INTEGER NOT NULL DEFAULT 0,
"estado_integrado" CHAR(1),
"es_maximo" CHAR(1),
"duracion_total" INTEGER,
"porcentaje_total" NUMERIC(16, 2),
"fecha_iniciototal" VARCHAR(10),
"fecha_fintotal" VARCHAR(10),
"fecha_inicioymd" VARCHAR(10), etiqueta integer, porcentaje_avance decimal(16,2), factor decimal(10,2), estado_ajustado varchar(1), duracion_base decimal(10,4), duracion_opt integer, fecha_inicio_opt varchar(10), fecha_fin_opt varchar(10), duracion_pes integer, fecha_inicio_pes varchar(10), fecha_fin_pes varchar(10), duracion_estimada integer, start_date date, end_date date, start_date_opt date, end_date_opt date, start_date_pes date, end_date_pes date, duracion_new DECIMAL(12,4),
PRIMARY KEY("id_programacion","numero_periodo"));
CREATE TABLE IF NOT EXISTS programacion_metrado
(
  id_programacion integer constraint pk_programacion_metrado primary key autoincrement,  
  fecha_inicio date,
  fecha_fin date,  
  cantidad decimal(10,2),  
  id_metrado char(12) constraint fk_programacion_metrado references metrado_bim(id_metrado)
  
, avance decimal(10,2));
CREATE TABLE IF NOT EXISTS "propietario" ("id_propietario" CHAR(12) NOT NULL,
"nombre_propietario" VARCHAR(120),
PRIMARY KEY("id_propietario"));
CREATE TABLE IF NOT EXISTS "provincia" ("id_provincia" CHAR(12) NOT NULL,
"nombre_provincia" CHAR(40),
"id_departamento" CHAR(12) NOT NULL,
PRIMARY KEY("id_provincia"));
CREATE TABLE IF NOT EXISTS "proyecto" ("id_proyecto" CHAR(12) NOT NULL,
"id_usuario" CHAR(12) NOT NULL,
"id_infraestructura" CHAR(12) NOT NULL,
"id_propietario" CHAR(12),
"id_ubicacion" CHAR(2) NOT NULL,
"nombre_proyecto" VARCHAR(255) NOT NULL,
"id_departamento" CHAR(12),
"id_provincia" CHAR(12),
"id_distrito" CHAR(12),
"id_localidad" CHAR(12),
"total_proyecto" REAL,
"es_plantilla" CHAR(1),
"fecha_proyecto" VARCHAR(10),
"total_gastoproyecto" NUMERIC(16, 2),
"fecha_inicio" VARCHAR(10),
"fecha_fin" VARCHAR(10),
"duracion" INTEGER,
"id_unidadtiempo" CHAR(12),
"trabaja_domingo" CHAR(1),
"tipo_gasto" CHAR(2), tipo_igv varchar(1), tipo_impuesto varchar(1), dias_valorizacion integer, fecha_valorizacion date, mes_base int, anio_base int, numero_region int, trabaja_sabado varchar(1), modalidad_ejecucion char(1), porcentaje_renta numeric(16,2), label_costo_directo varchar(80), label_costo_total varchar(80), label_monto_gasto varchar(80), label_monto_utilidad varchar(80), label_parcial_presupuesto varchar(80), label_monto_igv varchar(80), label_monto_otrosimpuestos varchar(80), archivo_pert blob, archivo_red blob, fin_periodo integer, clear_resumen char(1), label_monto_supervision varchar(100), bim_filename varchar(255), last_num_asiento integer, decimales_cantidad numeric(4,0), plantilla_asiento blob, archivo_fotos blob, path_cuaderno varchar(200), id_calendario integer, decimales_costo numeric, estado_proyecto char(1), Notas1 integer, Notas2 integer, Notas3 integer, acu_mode char(1) default 'N', selected_presupuesto char(12), id_paisinfo char(12), first_id_paisinfo char(12), exclude_igv_tipocosto varchar(15), duracion_new DECIMAL(12,4), id_portafolio char(12),
PRIMARY KEY("id_proyecto"));
CREATE TABLE IF NOT EXISTS region_precio(
numero_region int constraint pk_region_indice primary key,
descripcion_region varchar(200)
);
CREATE TABLE IF NOT EXISTS requerimiento (
  id_requerimiento integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
  id_documento VARCHAR(10), 
  serie_documento VARCHAR(20), 
  numero_documento VARCHAR(20), 
  fecha_documento TIMESTAMP NOT NULL, 
  id_moneda VARCHAR(10),  
  total_documento NUMERIC, 
  observacion VARCHAR(100), 
  id_usuario char(12), 
  estado_registro CHAR(1), 
  fecha_registro TIMESTAMP, 
  fecha_anulacion TIMESTAMP, 
  id_usuarioanulacion CHAR(12), 
  id_proveedor NUMERIC(18, 0), 
  porcentaje_igv NUMERIC(9, 4), 
  valor_compra NUMERIC, 
  monto_igv NUMERIC,  
  estado_atendido CHAR(1), 
  id_sucursal VARCHAR(10), 
  fecha_modificacion date, 
  id_usuariomodificacion char(12), 
  fecha_pago date, 
  id_proyecto char(12)
  , id_sucursalatender varchar(20), tipo_origen varchar(1), monto_pagado decimal(18,4), estado_pagado char(1), tipo_cambio decimal(10,4), id_empresa numeric, id_monedabase varchar(10), id_formapago varchar(10), id_categoria varchar(12), id_usuarioaprueba varchar(12), requiere_aprobacion char(1), id_usuariosolicita varchar(12), fecha_aprobacion date, fecha_solicitud date, estado_aprobado char(1), id_responsable NUMERIC(18, 0));
CREATE TABLE IF NOT EXISTS responsable (id_responsable CHAR(12) NOT NULL,nombre_responsable VARCHAR(120),PRIMARY KEY(id_responsable));
CREATE TABLE IF NOT EXISTS responsable_obra
(
id_responsable integer primary key,
id_proyecto char(12),
id_persona numeric,
tipo char(1),
fecha_inicio date,
fecha_fin date,
estado_vigente char(1)
);
CREATE TABLE IF NOT EXISTS resumen_costounitario (  
	id_resumen_costounitario CHAR(12),
	id_costounitario CHAR(12),
	periodo int,
	porcentaje_costo NUMERIC(10,2)
);
CREATE TABLE IF NOT EXISTS roles_sucursal (
    id_rol INTEGER PRIMARY KEY AUTOINCREMENT,
    id_sucursal VARCHAR(10), 
    id_categoria VARCHAR(12), 
    estado_rol CHAR(1)
);
CREATE TABLE IF NOT EXISTS salida (
  id_salida integer constraint pk_salida PRIMARY KEY AUTOINCREMENT, 
  id_documento VARCHAR(10) NOT NULL, 
  serie_documento VARCHAR(10) NOT NULL, 
  numero_documento VARCHAR(20), 
  fecha_documento TIMESTAMP, 
  observacion VARCHAR(100), 
  id_usuario char(12), 
  estado_registro CHAR(1), 
  fecha_registro TIMESTAMP, 
  fecha_anulacion TIMESTAMP, 
  id_usuarioanulacion char(12), 
  id_cliente NUMERIC(18, 0), 
  nombre_cliente VARCHAR(100), 
  ruc_cliente VARCHAR(20), 
  dni_cliente VARCHAR(20), 
  direccion_cliente VARCHAR(80), 
  id_responsable NUMERIC(18, 0), 
  id_sucursal VARCHAR(10), 
  id_sucursaldestino VARCHAR(10), 
  id_transportista NUMERIC(18, 0), 
  id_motivo VARCHAR(10), 
  requiere_traslado CHAR(1), 
  estado_traslado CHAR(1), 
  fecha_recepcion TIMESTAMP, 
  estado_liquidado CHAR(1), 
  requiere_liquidacion CHAR(1), 
  id_pedido NUMERIC(18, 0), 
  fecha_modificacion date, 
  id_usuariomodificacion char(12), id_proyecto char(12), estado_aplicado varchar(1), id_venta numeric);
CREATE TABLE IF NOT EXISTS [secuencia] (
    [nombre_secuencia] varchar(50) PRIMARY KEY NOT NULL,
    [ultimo_numero] integer NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS secuencia_documento(
  id_secuencia integer constraint pk_secuencia_doc primary key autoincrement, 
  id_documento VARCHAR(10), 
  id_ubicacion VARCHAR(10), 
  serie_actual NUMERIC(18, 0), 
  ultimo_numero NUMERIC(18, 0), 
  id_sucursal VARCHAR(50)
  , id_empresa numeric);
CREATE TABLE IF NOT EXISTS serie_compra (
  id_seriecompra integer constraint pk_serie_compra PRIMARY KEY AUTOINCREMENT, 
  id_detallecompra NUMERIC(18, 0) NOT NULL 
  constraint fk_serie_compra_detalle references detalle_compra(id_detallecompra), 
  serie_producto VARCHAR(50), 
  observacion VARCHAR(100), 
  requiere_activacion CHAR(1), 
  fecha_activacion TIMESTAMP, 
  estado_activado CHAR(1), 
  estado_serie CHAR(1), 
  estado_disponible CHAR(1), 
  garantia NUMERIC(18, 10), 
  periodo_garantia VARCHAR(50), 
  id_seriepedidoreference NUMERIC(28, 0),  
  estado_facturado VARCHAR(10), 
  id_seriecomprafact numeric, 
  id_detallecomprafact numeric, fecha_vencimiento date);
CREATE TABLE IF NOT EXISTS serie_salida (
id_seriesalida integer primary key autoincrement,
id_detallesalida NUMERIC(18, 0) NOT NULL
constraint fk_serie_salida_detalle references detalle_salida(id_detallesalida),
serie_producto VARCHAR(50),
observacion VARCHAR(100),
duracion_garantia NUMERIC(18, 2),
periodo_garantia VARCHAR(10),
id_seriecompra NUMERIC(28, 0),
numero_abonado VARCHAR(20),
estado_activado CHAR(1),
estado_devuelto CHAR(1),
id_detalleventa NUMERIC(18, 0),
precio_venta NUMERIC(18,2),
estado_serie CHAR(1),
id_detallepedido NUMERIC(18, 0),
id_seriepedido NUMERIC(28, 0),
estado_liquidado CHAR(1),
requiere_liquidacion CHAR(1)
);
CREATE TABLE IF NOT EXISTS stock_producto (
  id_stock integer constraint pk_stock_producto PRIMARY KEY AUTOINCREMENT, 
  id_sucursal VARCHAR(10) NOT NULL, 
  id_producto char(12) NOT NULL, 
  saldo_almacen NUMERIC(18, 4), 
  stock_minimo decimal(10,2)
  , saldo_fisico decimal(10,2));
CREATE TABLE IF NOT EXISTS "subclase" ("id_subclase" CHAR(12) NOT NULL,
"nombre_subclase" VARCHAR(120),
"codigo_subclase" VARCHAR(20), id_clase char(12), codigo_clase varchar(50), info_subclase varchar(100),
PRIMARY KEY("id_subclase"));
CREATE TABLE IF NOT EXISTS "subclase_costo" ("id_subclase" CHAR(12) NOT NULL,
"nombre_subclase" VARCHAR(120),
"codigo_subclase" VARCHAR(20),
PRIMARY KEY("id_subclase"));
CREATE TABLE IF NOT EXISTS "subtotal_analisiscosto" ("id_subtotal" CHAR(12) NOT NULL,
"id_analisiscosto" CHAR(12),
"id_tipocosto" VARCHAR(12),
"subtotal" NUMERIC(16, 4),
"numeracion_subtotal" VARCHAR(20),
"id_composicionpadre" VARCHAR(12),
"estado_expandido" CHAR(1),
"factor_cantidad" NUMERIC(16, 4),
PRIMARY KEY("id_subtotal"));
CREATE TABLE IF NOT EXISTS "subtotal_costounitario" ("id_subtotal" CHAR(12) NOT NULL,
"id_costounitario" CHAR(12),
"id_tipocosto" VARCHAR(12),
"subtotal" NUMERIC(16, 4),
"numeracion_subtotal" VARCHAR(20),
"id_composicionpadre" VARCHAR(12),
"estado_expandido" CHAR(1),
"factor_cantidad" NUMERIC(28, 18),
PRIMARY KEY("id_subtotal"));
CREATE TABLE IF NOT EXISTS sucursal (
  id_sucursal VARCHAR(10) NOT NULL, 
  nombre_sucursal VARCHAR(100), 
  id_distrito CHAR(12), 
  direccion_sucursal VARCHAR(100), 
  telefono_sucursal VARCHAR(50), 
  telefono_alternativo VARCHAR(50), 
  es_oficinacentral CHAR(1), 
  es_domiciliofiscal CHAR(1), 
  id_persona NUMERIC(18, 0) not null constraint fk_sucursal_persona references persona(id_persona), 
  id_sucursalcentral VARCHAR(10), 
  estado_sucursal CHAR(1), codigo_sunat varchar(10), id_sucursalstock1 varchar(10), id_sucursalstock2 varchar(10), id_sucursalstock3 varchar(10), id_documentosalida varchar(10), id_documentovta varchar(10), id_documentofact varchar(10), tipo_unidad VARCHAR(20), id_proyecto CHAR(12), id_template int, 
  CONSTRAINT PK_SUCURSAL PRIMARY KEY (id_sucursal));
CREATE TABLE IF NOT EXISTS tarea_linea
(
id_registro integer primary key autoincrement,
id_linea integer,
id_costounitario char(12) not null,
fecha_inicio date,
fecha_fin date,
duracion integer
);
CREATE TABLE IF NOT EXISTS tarea_linea_task(
    id_registro_task INTEGER PRIMARY KEY AUTOINCREMENT,
    id_registro INTEGER,
    fecha_inicio DATE,
    fecha_fin DATE
);
CREATE TABLE IF NOT EXISTS tarea_responsable
(
id_tarearesponsable integer primary key,
id_costounitario char(12),
id_responsable numeric,
porcentaje_asignado decimal(10,4)
);
CREATE TABLE IF NOT EXISTS telefono_persona
(
	id_telefono integer constraint PK_TELEFONO_PERSONA primary key autoincrement,
	id_persona numeric not null,
	numero_telefono varchar(50) not null,
  nombre_contacto varchar(80),  
  nombre_oficina varchar(80),  
  observaciones varchar(80),  
  tipo_telefono varchar(1)
);
CREATE TABLE IF NOT EXISTS temp_detalle_compra_composicion(
id_registro integer  primary key autoincrement,
id_detallecompra numeric(18,0) not null,
id_composicion varchar(12) not null,
cantidad numeric(18,10)
);
CREATE TABLE IF NOT EXISTS temp_detalle_compra_fact
 (
 id_detallecomprafact integer 
 constraint pk_temp_detalle_compra_fact primary key autoincrement,
id_producto VARCHAR(50),
id_usuario VARCHAR(10),
cantidad NUMERIC(18, 4) NOT NULL,
precio_unitario NUMERIC NOT NULL,
total_detalle NUMERIC NOT NULL,
observacion VARCHAR(100)
,requiere_serie varchar(1), 
id_unidad varchar(10)
, precio_compra decimal(10,4), precio_conigv varchar(1), id_detallerequerimiento numeric, requiere_lote char(1), porcentaje_descuento decimal(10,2), porcentaje_descuento2 decimal(10,2), porcentaje_descuento3 decimal(10,2), tipo_cambio decimal(10,4), id_moneda varchar(10), id_productopresupuesto char(12), id_persona numeric, id_detalleorden numeric (18,0));
CREATE TABLE IF NOT EXISTS temp_detalle_orden(
	id_detalleorden INTEGER primary key AUTOINCREMENT,
	id_producto char(12) NULL,
	id_usuario varchar(12) NULL,
	cantidad decimal(18, 4) NOT NULL,
	precio_unitario decimal(18, 4) NOT NULL,
	total_detalle decimal(18, 4) NOT NULL,
	observacion varchar(100) NULL,
	requiere_serie varchar(1) NULL,
	id_unidad char(12) NULL,
	precio_compra decimal(10, 4) NULL,
	precio_conigv varchar(1) NULL,
	id_detallerequerimiento numeric(18, 0) NULL,
	requiere_lote char(1) NULL,
	porcentaje_descuento decimal(10, 2) NULL,
	porcentaje_descuento2 decimal(10, 2) NULL,
	porcentaje_descuento3 decimal(10, 2) NULL,
	tipo_cambio decimal(10, 4) NULL,
	id_moneda varchar(10) NULL,
	id_productopresupuesto char(12) NULL,
	id_persona numeric(18, 0) NULL

);
CREATE TABLE IF NOT EXISTS temp_detalle_requerimiento(
id_detallerequerimiento integer constraint pk_temp_detalle_requerimiento primary key autoincrement, 
id_producto CHAR(12),  
cantidad NUMERIC(18,2),
precio_unitario NUMERIC(18,2),
total_detalle NUMERIC(18,2), 
observacion VARCHAR(200),
id_unidad VARCHAR(12), 
id_unidadcompra varchar(12),
id_usuario char(12) NOT NULL,
id_proyecto char(12), 
cantidad_compra NUMERIC(18, 2),
precio_compra NUMERIC(18, 2),
factor_conversion DECIMAL(18, 2), 
id_documento varchar(12), 
descripcion_real varchar(255), 
especificaciones varchar(255)
, tiene_proyecto varchar(1), id_productopresupuesto char(12), tipo_cambio decimal(10,4), id_moneda varchar(10), cantidad_ingreso_almacen  numeric(18,2) default 0);
CREATE TABLE IF NOT EXISTS temp_detalle_requerimiento_composicion(
id_registro integer constraint pk_temp_detalle_requerimiento primary key autoincrement,
id_detallerequerimiento numeric(18,0) not null,
id_composicion varchar(12) not null,
cantidad numeric(18,10),
cantidad_compra numeric(18,10)
, id_gasto_unitario char(12), id_gasto_supervision char(12));
CREATE TABLE IF NOT EXISTS temp_detalle_salida (
id_detallesalida integer constraint pk_temp_detalle_salida primary key autoincrement,
id_producto CHAR(12),
cantidad NUMERIC(18, 4),
observacion VARCHAR(200),
id_usuario char(12),
requiere_serie CHAR(1),
serie_completado CHAR(1),
id_unidad char(12),
cantidad_detalle NUMERIC(18, 4),
numero_item NUMERIC(18, 0)
, id_detallerequerimiento numeric, requiere_lote char(1), lote_completado char(1), costo_unitario decimal(18,4), id_productopresupuesto char(12));
CREATE TABLE IF NOT EXISTS temp_detalle_salida_composicion(
id_registro integer constraint pk_temp_detalle_salida_composicion primary key autoincrement,
id_detallesalida numeric(18,0) not null,
id_composicion varchar(12) not null,
cantidad numeric(18,4)
);
CREATE TABLE IF NOT EXISTS temp_detalle_salida_map(
id_map integer constraint pk_temp_detalle_salida_map primary key autoincrement,
id_detallesalida numeric(18,0) not null,
id_costounitario char(12) not null,
cantidad numeric(18,4),
observaciones varchar(100)
);
CREATE TABLE IF NOT EXISTS temp_detalletraslado 
(
id_detallecompra integer constraint pk_temp_detalletraslado primary key autoincrement,
id_producto char(12),
cantidad NUMERIC(10, 4),
observacion VARCHAR(200),
requiere_serie CHAR(1),
serie_completado CHAR(1),
costo_entrada NUMERIC(10,4),
id_usuario  char(12),
id_detallesalida numeric
,id_unidad char(12)
, requiere_lote char(1), lote_completado char(1));
CREATE TABLE IF NOT EXISTS temp_serie_salida (
id_seriesalida integer constraint pk_temp_serie_salida primary key autoincrement,
id_detallesalida NUMERIC(18, 0) NOT NULL,
serie_producto VARCHAR(50),
observacion VARCHAR(100),
duracion_garantia NUMERIC(18, 2),
periodo_garantia VARCHAR(10),
id_seriecompra NUMERIC(28, 0)
);
CREATE TABLE IF NOT EXISTS temp_serietraslado (
id_seriecompra integer constraint pk_serie_traslado primary key autoincrement,
id_detallecompra NUMERIC(18, 0) NOT NULL,
serie_producto VARCHAR(50),
observacion VARCHAR(100),
garantia NUMERIC(18, 10),
periodo_garantia VARCHAR(50),
id_seriesalida numeric
, fecha_vencimiento date);
CREATE TABLE IF NOT EXISTS temp_temp_serie_salida (
id_seriesalida integer constraint pk_temp_temp_serie_salida primary key autoincrement,
id_usuario  CHAR(12) NOT NULL,
serie_producto VARCHAR(50),
observacion VARCHAR(100),
duracion_garantia NUMERIC(18, 2),
periodo_garantia VARCHAR(10),
id_seriecompra NUMERIC(28, 0)
, id_producto varchar(12));
CREATE TABLE IF NOT EXISTS tipo_afp (
tipo_afp VARCHAR(10) NOT NULL constraint PK_TIPOAFP PRIMARY KEY,
descripcion_tipo VARCHAR(50),
estado_vigente CHAR(1)

, porcentaje_fondo decimal(10,4), porcentaje_seguro decimal(10,4), porcentaje_flujo decimal(10,4), porcentaje_mixta decimal(10,4));
CREATE TABLE IF NOT EXISTS tipo_asiento(
id_tipo varchar(4) constraint pk_id_tipo primary key,
descripcion_tipo varchar(50),
tipo_emisor varchar(10),
orden integer
);
CREATE TABLE IF NOT EXISTS tipo_caja (
id_tipocaja VARCHAR(10) NOT NULL,
descripcion_tipo VARCHAR(50),
id_modingreso VARCHAR(10),
id_modegreso VARCHAR(10),
es_xcobrar CHAR(1), 
afecta_caja varchar(1),
PRIMARY KEY(id_tipocaja));
CREATE TABLE IF NOT EXISTS tipo_concepto 
(
tipo_concepto VARCHAR(10) NOT NULL,
descripcion_tipo VARCHAR(50),
estado_vigente CHAR(1),
orden INTEGER,
constraint pk_tipo_concepto PRIMARY KEY(tipo_concepto)
);
CREATE TABLE IF NOT EXISTS "tipo_costo" ("id_tipocosto" CHAR(12) NOT NULL,
"descripcion_tipocosto" CHAR(20),
"requiere_productividad" CHAR(1),
"permite_listaprecio" CHAR(1),
"permite_subcontratista" CHAR(1),
"permite_costodependiente" CHAR(1),
"id_tipocostodependiente" CHAR(12),
"id_listapreciodependiente" CHAR(12),
"df_porcentaje_presupuesto" NUMERIC(10, 2), custom_orden int,
PRIMARY KEY("id_tipocosto"));
CREATE TABLE IF NOT EXISTS tipo_persona (
  id_tipopersona VARCHAR(10) NOT NULL, 
  descripcion_tipopersona VARCHAR(50), 
  clase_persona VARCHAR(50), 
  permitir_venta CHAR(1), 
  cuenta_predeterminada VARCHAR(10), 
  es_empleado varchar(1), permite_alias varchar(1), mismo_grupo char(1), date_version TIMESTAMP, categorias varchar(150), es_sistema char(1), 
  CONSTRAINT PK_PERSONA PRIMARY KEY (id_tipopersona));
CREATE TABLE IF NOT EXISTS "titulo" ("id_titulo" CHAR(12) NOT NULL,
"descripcion_titulo" VARCHAR(255),
"id_titulopadre" CHAR(12),
"posicion_titulo" INTEGER,
"nivel_titulo" INTEGER,
"id_presupuesto" CHAR(12),
"estado_expandido" CHAR(1),
"numeracion_titulo" VARCHAR(120),
"costo_titulo" NUMERIC(16, 2) DEFAULT 0.00, id_responsable varchar(12), numeracion_norma varchar(120), color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), duracion int, fecha_inicio date, fecha_fin date, es_hito char(1), porcentaje_completado decimal(10,2), color_fondo integer, duracion_new DECIMAL(12,4),
PRIMARY KEY("id_titulo"));
CREATE TABLE IF NOT EXISTS titulo_bim (
id_titulo CHAR(12) NOT NULL,
descripcion_titulo VARCHAR(255),
id_titulopadre CHAR(12),
posicion_titulo numeric,
id_proyecto CHAR(12),
estado_expandido CHAR(1),
color_fuente numeric, 
nombre_fuente varchar(100), 
estilo_fuente int, 
tamano_fuente decimal(6,2), 
color_fondo numeric,
bim_guid varchar(128), id_unidad char(12), cantidad decimal(18,2), parcial_costo decimal(18,2), es_entidad char(1), check_cantidad char(1), check_largo char(1), check_ancho char(1), check_alto char(1), check_peso char(1), check_area char(1), check_volumen char(1), id_presupuesto char(12), temp_block_recursive varchar(1) default 'N',
PRIMARY KEY(id_titulo)
);
CREATE TABLE IF NOT EXISTS titulo_clasificador(
id_titulo CHAR(12) NOT NULL,
descripcion_titulo VARCHAR(255), 
id_plantilla varchar(12),
 id_titulopadre varchar(12), 
 posicion_titulo numeric, 
 estado_bloqueado char(1), 
 estado_expandido char(1), 
 numeracion_titulo varchar(120), informacion_titulo varchar(255),
constraint pk_titulo_clasificador PRIMARY KEY(id_titulo),
constraint fk_titulo_clasif_plantilla foreign key(id_plantilla) references plantilla_clasificador(id_plantilla)
);
CREATE TABLE IF NOT EXISTS titulo_desagregado (
id_titulo  CHAR(12) NOT NULL,
descripcion_titulo  VARCHAR(255),
id_titulopadre  CHAR(12),
posicion_titulo  INTEGER,
nivel_titulo  INTEGER,
id_presupuesto  CHAR(12),
estado_expandido  CHAR(1),
numeracion_titulo  VARCHAR(120),
costo_titulo  INTEGER DEFAULT NULL,
estado_bloqueado  CHAR(1) DEFAULT 'N', 
color_fuente numeric, 
nombre_fuente varchar(100), 
estilo_fuente int, 
tamano_fuente decimal(6,2), 
id_clasificador char(12), 
numeracion_clasificador varchar(120), id_tipocosto char(12), color_fondo integer,
PRIMARY KEY (id_titulo ASC)
);
CREATE TABLE IF NOT EXISTS titulo_gasto (
id_titulo  CHAR(12) NOT NULL,
descripcion_titulo  VARCHAR(255),
id_titulopadre  CHAR(12),
posicion_titulo  INTEGER,
nivel_titulo  INTEGER,
id_presupuesto  CHAR(12),
estado_expandido  CHAR(1),
numeracion_titulo  VARCHAR(120),
costo_titulo  decimal(16,2),
estado_bloqueado  CHAR(1) DEFAULT 'N',
color_fuente numeric, 
nombre_fuente varchar(100), 
estilo_fuente integer, 
tamano_fuente integer, 
id_clasificador char(12), 
numeracion_clasificador varchar(120), 
color_fondo integer,
PRIMARY KEY (id_titulo ASC)
);
CREATE TABLE IF NOT EXISTS "titulo_indice" ("id_titulo" CHAR(12) NOT NULL,
"descripcion_titulo" VARCHAR(255),
"id_titulopadre" CHAR(12),
"posicion_titulo" INTEGER,
"nivel_titulo" INTEGER,
"id_presupuesto" CHAR(12),
"estado_expandido" CHAR(1),
"coeficiente" NUMERIC(16, 10),
"porcentaje" NUMERIC(16, 2) DEFAULT 0.00,
"nomenclatura" VARCHAR(50), codigo_clase varchar(20), es_indice char(1), custom_control varchar(10), coeficientedefinido NUMERIC(16,10),
PRIMARY KEY("id_titulo"));
CREATE TABLE IF NOT EXISTS titulo_pie (
  id_titulo integer  CONSTRAINT pk_titulo_pie PRIMARY KEY autoincrement, 
  descripcion_titulo VARCHAR(255) not null, 
  posicion_titulo INTEGER, 
  id_presupuesto CHAR(12) not null, 
  tipo_titulo CHAR(1) not null, 
  porcentaje_titulo NUMERIC(16, 10) DEFAULT (0.00),
  costo_titulo NUMERIC(16, 2) DEFAULT (0.00),  
  formula varchar(255),  
  clave varchar(50) not null,  
  seccion_titulo char(1) not null
  , color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), color_fondo numeric);
CREATE TABLE IF NOT EXISTS "titulo_plantilla" ("id_titulo" CHAR(12) NOT NULL,
"descripcion_titulo" VARCHAR(255),
"id_titulopadre" CHAR(12),
"posicion_titulo" INTEGER,
"nivel_titulo" INTEGER,
"id_plantilla" CHAR(12),
"estado_expandido" CHAR(1),
"numeracion_titulo" VARCHAR(120),
"costo_titulo" NUMERIC(16, 2) DEFAULT 0.00,
"estado_bloqueado" CHAR(1) DEFAULT 'N', id_clasificador char(12), numeracion_clasificador varchar(120), color_fuente numeric, nombre_fuente varchar(100), estilo_fuente int, tamano_fuente decimal(6,2), color_fondo integer,
PRIMARY KEY("id_titulo"));
CREATE TABLE IF NOT EXISTS titulo_supervision (
id_titulo  CHAR(12) NOT NULL,
descripcion_titulo  VARCHAR(255),
id_titulopadre  CHAR(12),
posicion_titulo  INT,
id_presupuesto  CHAR(12),
estado_expandido  CHAR(1),
numeracion_titulo  VARCHAR(120),
costo_titulo  decimal(18,4),
estado_bloqueado  CHAR(1), 
color_fuente numeric, nombre_fuente varchar(100), 
estilo_fuente int, tamano_fuente decimal(6,2), id_clasificador char(12), 
numeracion_clasificador varchar(120), color_fondo numeric, clave_pie varchar(50),
PRIMARY KEY (id_titulo)
);
CREATE TABLE IF NOT EXISTS "unidad" ("id_unidad" CHAR(12) NOT NULL,
"descripcion_unidad" VARCHAR(120),
"descripcion_singular" VARCHAR(120),
"orden" INTEGER,
"operador_fecha" VARCHAR(10),
"cantidad_fecha" INTEGER,
"magnitud_unidad" NUMERIC(16, 4),
"id_unidadbase" CHAR(12),
"es_unidadcosto" CHAR(1),
"es_unidadtiempo" CHAR(1),
"en_cronograma" CHAR(1),
"es_unidadgasto" CHAR(1),
"es_dependiente" CHAR(1),
"id_tipocostodependencia" VARCHAR(12),
"informacion_unidad" VARCHAR(100), divisible varchar(1), abreviatura_unidad varchar(30), codigo_sunat varchar(10), es_sistema varchar(1), tipo_unidad VARCHAR(4),
PRIMARY KEY("id_unidad"));
CREATE TABLE IF NOT EXISTS "unidad_map"
(
    id_unidadmap INTEGER PRIMARY KEY AUTOINCREMENT,
    id_unidad CHAR(12) NOT NULL,
    id_producto CHAR(12) NOT NULL,
    permitido VARCHAR(1),
    FOREIGN KEY (id_unidad) REFERENCES UNIDAD(id_unidad)
);
CREATE TABLE IF NOT EXISTS "unidad_tipocosto" ("id_unidad" VARCHAR(12) NOT NULL,
"id_tipocosto" VARCHAR(12) NOT NULL,
PRIMARY KEY("id_unidad","id_tipocosto"));
CREATE TABLE IF NOT EXISTS unidad_tipocostonew (
id_utc integer constraint pk_unidad_tipocosto primary key autoincrement,
id_unidad VARCHAR(12) NOT NULL,
id_tipocosto VARCHAR(12) NOT NULL
);
CREATE TABLE IF NOT EXISTS usuario (
  id_usuario CHAR(12) NOT NULL, 
  nombre_usuario VARCHAR(50),   
  apellidos_usuario varchar(50),  
  login_usuario varchar(20),
  clave_usuario VARCHAR(40), 
  estado_usuario CHAR(1), 
  show_costos  DEFAULT ('S'),  
  id_perfil varchar(10), 
  id_persona numeric(18, 0), 
  es_principal varchar (1), 
  tipo_encripta varchar (3), 
  id_cajaasignada varchar (10), 
  id_sucursalasignada varchar (10), 
  email_usuario varchar (50), 
  editar_descuento varchar(1), 
  editar_fecha varchar(1), 
  CONSTRAINT pk_usuario PRIMARY KEY (id_usuario));
CREATE TABLE IF NOT EXISTS usuario_map
(
       id_usuariomap integer constraint pk_usuario_map primary key autoincrement,
       id_usuario  char(12) not null,       
       id_proyecto char(12) not null,       
       tipo_acceso varchar(1),       
       constraint fk_usuario_map_usuario foreign key (id_usuario) references usuario(id_usuario),       
       constraint fk_usuario_map_proyecto foreign key (id_proyecto) references proyecto(id_proyecto)
);
CREATE TABLE IF NOT EXISTS "valorizacion_programada" (
			id_valorizacion numeric(18,0) NOT NULL,
			numero_mes int,
			numero_anio int,
			id_presupuesto char(12),
			parcial_periodo decimal(10,2),
			parcial_acumulado decimal(10,2),
			fecha_inicio datetime,
			fecha_fin datetime,
			costo_ejecutado decimal(16,2),
			parcial_valorizado decimal(16,2),
			k_real decimal(16,10),
			k_mes decimal(16,10),
			k_proyectado decimal(16,10),
			CONSTRAINT valorizacion_programada_PK_01 PRIMARY KEY (id_valorizacion)
		);
CREATE UNIQUE INDEX IF NOT EXISTS "ESTACION_IX_GRUPO_DESCRIPCION" ON "ESTACION" ("descripcion_estacion");
CREATE INDEX IF NOT EXISTS IXSERIE_PEDIDO_ID_DETALLE ON SERIE_PEDIDO (id_detallepedido);
CREATE INDEX IF NOT EXISTS [ifk_composicion_analisiscosto_id_subtotal] ON [composicion_analisiscosto] ([id_subtotal]);
CREATE INDEX IF NOT EXISTS ifk_composicion_costo_aplicacion ON composicion_costounitario (id_composicion);
CREATE INDEX IF NOT EXISTS [ifk_composicion_costounitario_id_listaprecio] ON [composicion_costounitario] ([id_listaprecio]);
CREATE INDEX IF NOT EXISTS [ifk_composicion_costounitario_id_subtotal] ON [composicion_costounitario] ([id_subtotal]);
CREATE INDEX IF NOT EXISTS "ifk_costo_unitario_id_analisiscosto" ON "costo_unitario" ("id_analisiscosto");
CREATE INDEX IF NOT EXISTS "ifk_costo_unitario_id_titulo" ON "costo_unitario" ("id_titulo");
CREATE INDEX IF NOT EXISTS ifk_costounitario_dependencia ON dependencia (id_costounitario);
CREATE INDEX IF NOT EXISTS ifk_costounitario_dependenciacosto ON dependencianew (id_costounitario);
CREATE INDEX IF NOT EXISTS ifk_costounitario_dependencianew ON dependencianew (id_costounitario);
CREATE INDEX IF NOT EXISTS ifk_metrado_bim_id_titulo ON metrado_bim (id_titulo);
CREATE INDEX IF NOT EXISTS "ifk_metrado_id_costounitario" ON "metrado" ("id_costounitario");
CREATE INDEX IF NOT EXISTS ifk_planoteca_proyecto ON planoteca (id_proyecto);
CREATE INDEX IF NOT EXISTS "ifk_presupuesto_id_proyecto" ON "presupuesto" ("id_proyecto");
CREATE INDEX IF NOT EXISTS "ifk_programacion_costo_id_costounitario" ON "programacion_costo" ("id_costounitario");
CREATE INDEX IF NOT EXISTS "ifk_subtotal_analisiscosto_id_analisiscosto" ON "subtotal_analisiscosto" ("id_analisiscosto");
CREATE INDEX IF NOT EXISTS "ifk_subtotal_costounitario_id_costounitario" ON "subtotal_costounitario" ("id_costounitario");
CREATE INDEX IF NOT EXISTS "ifk_titulo_id_presupuesto" ON "titulo" ("id_presupuesto");