using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace MYG_2027;

/// <summary>Materializa en celdas la misma cabecera que muestra la vista previa.
/// Trabaja sobre instantáneas independientes y conserva fórmulas y formatos del cuerpo.</summary>
public static class MYGReportesExcel
{
    public static IReadOnlyList<MYGHojaMetrado> CrearHojas(IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        // Además de las celdas, esta copia aísla los orígenes de METRADO que no
        // estén visibles entre los informes seleccionados.
        var copias = new MYGConfiguracionVistaReporte(reportes).Reportes;
        for (int i = 0; i < copias.Count; i++)
        {
            if (reportes[i].EsPresupuestoObra || reportes[i].EsAnalisisCostosUnitarios)
                AjustarFilasTexto(copias[i]);
            Materializar(reportes[i], copias[i].Hoja);
        }
        return Array.AsReadOnly(copias.Select(r => r.Hoja).ToArray());
    }

    private static void AjustarFilasTexto(MYGHojaReporteProyecto reporte)
    {
        // El alto se calcula para el ancho del informe, sin trasladar los
        // tamaños de la pantalla. Excel no autoajusta las celdas combinadas.
        var hoja = reporte.Hoja;
        foreach (var minimo in reporte.AltosMinimosFilas) hoja.AltosFilas[minimo.Key] = minimo.Value;
        var combinaciones = new Dictionary<(int Fila, int Columna), (int Primera, int Ultima)>();
        foreach (string rango in hoja.RangosCombinados)
        {
            var region = Extremos(rango);
            if (region.F1 != region.F2) continue;
            for (int c = region.C1; c <= region.C2; c++)
                combinaciones[(region.F1, c)] = (region.C1, region.C2);
        }
        var calculo = new MYGHojaCalculo(hoja);
        foreach (var entrada in hoja.Celdas)
        {
            var celda = entrada.Value;
            if (!celda.AjustarTexto) continue;
            var posicion = MYGHojaCalculo.Coordenadas(entrada.Key);
            int primera = posicion.Columna, ultima = primera;
            if (combinaciones.TryGetValue(posicion, out var region))
            {
                if (primera != region.Primera) continue;
                (primera, ultima) = region;
            }
            string texto = calculo.Mostrar(entrada.Key);
            if (string.IsNullOrEmpty(texto)) continue;
            int minimo = hoja.AltosFilas.GetValueOrDefault(posicion.Fila, 24);
            int caracteres = Math.Max(1, (int)(Math.Max(8, Ancho(hoja, primera, ultima) - 10) / (double)(celda.TamanoFuente * .64m)));
            int lineas = LineasAjustadas(texto, caracteres);
            if (lineas > 1)
                hoja.AltosFilas[posicion.Fila] = Math.Min(1000, Math.Max(minimo,
                    (int)Math.Ceiling(lineas * (double)celda.TamanoFuente * 1.8 + 6)));
        }
    }

    private static int LineasAjustadas(string texto, int caracteres)
    {
        int lineas = 0;
        foreach (string parrafo in texto.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
        {
            int cantidad = 1, ocupados = 0;
            foreach (string palabra in parrafo.Split((char[])null, StringSplitOptions.RemoveEmptyEntries))
            {
                if (ocupados > 0)
                {
                    if (ocupados + 1 + palabra.Length <= caracteres)
                    { ocupados += 1 + palabra.Length; continue; }
                    cantidad++; ocupados = 0;
                }
                cantidad += (palabra.Length - 1) / caracteres;
                ocupados = (palabra.Length - 1) % caracteres + 1;
            }
            lineas += cantidad;
        }
        return lineas;
    }

    private static void Materializar(MYGHojaReporteProyecto reporte, MYGHojaMetrado hoja)
    {
        if (reporte.CabeceraEnHoja) return;
        var datos = reporte.CabeceraImpresion;
        string titulo = reporte.TituloImpresion;
        if (datos.Count == 0 && string.IsNullOrEmpty(titulo)) return;
        var area = Limites(hoja);
        bool tituloDuplicado = datos.Count > 0 && area.F1 == 1 &&
            hoja.Celdas.TryGetValue("A1", out var a1) &&
            (reporte.EsPresupuestoObra || string.Equals(a1.Contenido, reporte.Titulo.Split(" · ")[0], StringComparison.OrdinalIgnoreCase)) &&
            hoja.RangosCombinados.Any(r =>
            {
                var p = Extremos(r);
                return p.F1 == 1 && p.F2 == 1 && p.C1 == area.C1 && p.C2 == area.C2;
            });
        int filas = datos.Count + 3;
        // Insertar filas también ajusta referencias absolutas, total, anclas,
        // combinaciones, cuerpo de plantilla, alturas y filas ocultas.
        MYGEdicionHoja.InsertarFilas(hoja, 1, filas);
        if (tituloDuplicado && !hoja.FilasOcultas.Contains(filas + 1)) hoja.FilasOcultas.Add(filas + 1);
        int primera = area.C1, ultima = area.C2;
        string fuente = hoja.Celdas.Values.FirstOrDefault()?.Fuente ?? MYGCeldaHoja.FuentePredeterminada;
        Poner(hoja, 1, primera, titulo, fuente, true, 11m, "Centro");
        Combinar(hoja, 1, primera, ultima);
        hoja.AltosFilas[1] = Alto(titulo, Ancho(hoja, primera, ultima), 11m, 30);
        hoja.AltosFilas[2] = 12;
        int etiquetaFin = primera;
        // El cuerpo conserva sus anchos originales. Se aprovechan columnas
        // pequeñas contiguas para los rótulos, sin ensanchar la tabla exportada.
        int totalAncho = Ancho(hoja, primera, ultima);
        while (etiquetaFin + 1 < ultima && Ancho(hoja, primera, etiquetaFin + 1) <= Math.Max(96, totalAncho / 4)) etiquetaFin++;
        for (int i = 0; i < datos.Count; i++)
        {
            int fila = i + 3;
            string etiqueta = datos[i].Key.TrimEnd(':') + ":";
            string valor = datos[i].Value;
            if (primera == ultima)
            {
                Poner(hoja, fila, primera, etiqueta + " " + valor, fuente, false, 9m);
                hoja.AltosFilas[fila] = Alto(etiqueta + " " + valor, totalAncho, 9m, 24);
            }
            else
            {
                Poner(hoja, fila, primera, etiqueta, fuente, false, 9m);
                Combinar(hoja, fila, primera, etiquetaFin);
                Poner(hoja, fila, etiquetaFin + 1, valor, fuente, false, 9m);
                Combinar(hoja, fila, etiquetaFin + 1, ultima);
                hoja.AltosFilas[fila] = Math.Max(Alto(etiqueta, Ancho(hoja, primera, etiquetaFin), 9m, 24),
                    Alto(valor, Ancho(hoja, etiquetaFin + 1, ultima), 9m, 24));
            }
        }
        hoja.AltosFilas[filas] = 12;
        hoja.AreaImpresion = MYGHojaCalculo.Columna(primera) + "1:" + MYGHojaCalculo.Columna(ultima) + (area.F2 + filas).ToString(CultureInfo.InvariantCulture);
        MYGHojaCalculo.Validar(hoja);
    }

    private static void Poner(MYGHojaMetrado h, int fila, int columna, string texto,
        string fuente, bool negrita, decimal tamano, string alineacion = "Izquierda")
    {
        // Los metadatos son texto incluso si el nombre de un proyecto empieza
        // por '=' o si un presupuesto tiene un código totalmente numérico.
        string contenido = (texto ?? "").StartsWith('=') || MYGHojaCalculo.IntentarNumero(texto, out _)
            ? "=\"" + (texto ?? "").Replace("\"", "\"\"") + "\"" : texto ?? "";
        h.Celdas[MYGHojaCalculo.Columna(columna) + fila] = new MYGCeldaHoja
        {
            Contenido = contenido, Fuente = fuente, TamanoFuente = tamano, Negrita = negrita,
            ColorTexto = "000000", ColorFondo = "FFFFFF", AjustarTexto = true,
            AlineacionPersonalizada = true, AlineacionHorizontal = alineacion, AlineacionVertical = "Arriba", FormatoNumero = "@"
        };
    }

    private static void Combinar(MYGHojaMetrado h, int fila, int primera, int ultima)
    {
        if (ultima > primera) h.RangosCombinados.Add(MYGHojaCalculo.Columna(primera) + fila + ":" + MYGHojaCalculo.Columna(ultima) + fila);
    }

    private static int Ancho(MYGHojaMetrado h, int primera, int ultima) =>
        Enumerable.Range(primera, ultima - primera + 1).Sum(c => h.AnchosColumnas.GetValueOrDefault(c, c == 1 ? 288 : c == 8 ? 110 : 68));

    private static int Alto(string texto, int ancho, decimal tamano, int minimo)
    {
        // Excel no autoajusta filas con celdas combinadas. Una altura explícita
        // evita que desaparezcan nombres extensos y los saltos de línea.
        int caracteres = Math.Max(1, (int)(Math.Max(8, ancho - 10) / (double)(tamano * .64m)));
        int lineas = (texto ?? "").Replace("\r\n", "\n").Replace('\r', '\n').Split('\n')
            .Sum(l => Math.Max(1, (int)Math.Ceiling(l.Length / (double)caracteres)));
        return Math.Min(1000, Math.Max(minimo, (int)Math.Ceiling(lineas * (double)tamano * 1.6 + 6)));
    }

    private static (int F1, int C1, int F2, int C2) Limites(MYGHojaMetrado h)
    {
        if (!string.IsNullOrWhiteSpace(h.AreaImpresion)) return Extremos(h.AreaImpresion);
        var posiciones = h.Celdas.Keys.Concat(h.RangosCombinados.SelectMany(r => r.Split(':')))
            .Select(MYGHojaCalculo.Coordenadas).ToArray();
        return (1, 1, posiciones.Select(p => p.Fila).DefaultIfEmpty(1).Max(), posiciones.Select(p => p.Columna).DefaultIfEmpty(1).Max());
    }

    private static (int F1, int C1, int F2, int C2) Extremos(string rango)
    {
        var partes = MYGEdicionHoja.NormalizarRango(rango).Split(':');
        var a = MYGHojaCalculo.Coordenadas(partes[0]);
        var b = MYGHojaCalculo.Coordenadas(partes[^1]);
        return (a.Fila, a.Columna, b.Fila, b.Columna);
    }
}
