using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MYG_2027;

public enum MYGAlcanceEspecificaciones { Proyecto, Presupuesto }

// Una sección conserva la estructura completa del presupuesto para resolver
// sus códigos visibles; Partidas omite los títulos y sigue el orden del árbol.
public sealed class MYGSeccionEspecificaciones
{
    public MYGPresupuestoDocumento Presupuesto { get; }
    public IReadOnlyList<ItemPresupuestoDelphin> Partidas { get; }

    internal MYGSeccionEspecificaciones(MYGPresupuestoDocumento presupuesto,
        IReadOnlyList<ItemPresupuestoDelphin> partidas)
    { Presupuesto = presupuesto; Partidas = partidas; }
}

public static class MYGEspecificacionesExportacion
{
    private static readonly StringComparer Comparador = StringComparer.OrdinalIgnoreCase;

    // Sólo trabaja con el proyecto abierto. No consulta el catálogo SQLite ni
    // valida/normaliza los costos y vínculos del documento del usuario.
    public static IReadOnlyList<MYGSeccionEspecificaciones> Seleccionar(MYGProyectoDocumento documento,
        MYGAlcanceEspecificaciones alcance, string presupuestoId = null)
    {
        var seleccionados = Presupuestos(documento, alcance, presupuestoId);
        var secciones = new List<MYGSeccionEspecificaciones>();
        foreach (var original in seleccionados)
        {
            // Copiar sólo los presupuestos incluidos permite exportar uno aunque
            // otro todavía tenga datos de edición incompletos, y aísla sus objetos.
            var copia = MYGProyectoStorage.Copia(original);
            copia.Items ??= new List<ItemPresupuestoDelphin>();
            ValidarJerarquia(copia);
            var partidas = MYGOrdenPresupuestos.FilasOrdenadas(copia)
                .Where(i => !MYGProyectoStorage.EsTitulo(i)).ToArray();
            secciones.Add(new MYGSeccionEspecificaciones(copia, Array.AsReadOnly(partidas)));
        }
        return Array.AsReadOnly(secciones.ToArray());
    }

    // Se comprueban los caracteres de Windows también al ejecutar en Linux.
    public static string NombreArchivo(MYGProyectoDocumento documento,
        MYGAlcanceEspecificaciones alcance, string presupuestoId = null)
    {
        var seleccionados = Presupuestos(documento, alcance, presupuestoId);
        string nombre = alcance == MYGAlcanceEspecificaciones.Proyecto
            ? documento.Nombre : seleccionados[0].Nombre;
        if (string.IsNullOrWhiteSpace(nombre))
            nombre = alcance == MYGAlcanceEspecificaciones.Proyecto ? "Proyecto" : "Presupuesto";
        var seguro = new StringBuilder("Especificaciones - ");
        foreach (char c in nombre)
            seguro.Append(char.IsControl(c) || "<>:\"/\\|?*".Contains(c) ? '_' : c);
        string resultado = seguro.ToString().TrimEnd(' ', '.');
        if (resultado.Length > 156) resultado = resultado[..156].TrimEnd(' ', '.');
        return resultado + ".doc";
    }

    private static List<MYGPresupuestoDocumento> Presupuestos(MYGProyectoDocumento documento,
        MYGAlcanceEspecificaciones alcance, string presupuestoId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (!Enum.IsDefined(alcance))
            throw new ArgumentOutOfRangeException(nameof(alcance), "Seleccione proyecto o presupuesto.");
        var disponibles = documento.Presupuestos ?? new List<MYGPresupuestoDocumento>();
        if (alcance == MYGAlcanceEspecificaciones.Presupuesto)
        {
            if (string.IsNullOrWhiteSpace(presupuestoId))
                throw new InvalidOperationException("Seleccione el presupuesto cuyas especificaciones desea exportar.");
            var coincidencias = disponibles.Where(p => p != null && Comparador.Equals(p.Id, presupuestoId)).ToList();
            if (coincidencias.Count == 0)
                throw new InvalidOperationException("El presupuesto seleccionado no pertenece al proyecto abierto.");
            if (coincidencias.Count != 1)
                throw new InvalidDataException("El identificador del presupuesto está duplicado en el proyecto abierto.");
            return coincidencias;
        }
        var ids = new HashSet<string>(Comparador);
        foreach (var p in disponibles)
            if (p == null || string.IsNullOrWhiteSpace(p.Id) || !ids.Add(p.Id))
                throw new InvalidDataException("El proyecto contiene un presupuesto sin identificador o duplicado.");
        // Mismo criterio que el orden de presupuestos del editor.
        return disponibles.OrderBy(p => p.Posicion).ThenBy(p => p.Item, Comparador).ToList();
    }

    private static bool EsRaiz(string padre) => string.IsNullOrWhiteSpace(padre) || padre == "__ROOT__";

    private static void ValidarJerarquia(MYGPresupuestoDocumento presupuesto)
    {
        var mapa = new Dictionary<string, ItemPresupuestoDelphin>(Comparador);
        foreach (var i in presupuesto.Items)
            if (i == null || string.IsNullOrWhiteSpace(i.Id) || !mapa.TryAdd(i.Id, i))
                throw new InvalidDataException("El presupuesto contiene un ítem sin identificador o duplicado.");
        foreach (var i in presupuesto.Items)
        {
            var visitados = new HashSet<string>(Comparador) { i.Id };
            var actual = i;
            for (int profundidad = 0; !EsRaiz(actual.ParentId); profundidad++)
            {
                if (profundidad >= 64 || !visitados.Add(actual.ParentId))
                    throw new InvalidDataException("La jerarquía del presupuesto es circular o demasiado profunda.");
                if (!mapa.TryGetValue(actual.ParentId, out var padre))
                    throw new InvalidDataException("Falta el título padre de una partida del presupuesto.");
                // Los documentos antiguos pueden reconocer títulos por sus hijos.
                // Esta compatibilidad se aplica únicamente a la copia de exportación.
                if (string.IsNullOrWhiteSpace(padre.TipoPropuesta)) padre.TipoPropuesta = "TITULO";
                if (!MYGProyectoStorage.EsTitulo(padre))
                    throw new InvalidDataException("Una partida no puede contener otros ítems.");
                actual = padre;
            }
        }
    }
}
