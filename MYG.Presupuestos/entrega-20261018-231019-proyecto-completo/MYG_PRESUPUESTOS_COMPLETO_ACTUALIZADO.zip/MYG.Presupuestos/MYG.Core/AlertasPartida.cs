using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Security;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

public enum MYGEstadoRegistroACU { SinVerificar, NoRegistrado, Registrado }
public enum MYGZonaAlertaPartida { Catalogo, Analisis, Cantidad, Total }
public enum MYGSeveridadAlertaPartida { Mensaje, Advertencia, Error, Correcto }
public enum MYGTipoAlertaPartida
{
    SinRegistroACU, RegistroACUSinVerificar, SinAnalisis, CantidadCero, PrecioCero,
    TotalCero, DescripcionVacia, UnidadVacia, ErrorCantidad, ErrorAnalisis, ErrorTotal,
    DatosCostoIncompletos, RecursoSinPrecio, RecursoSinCantidad, RecursoSinUnidad, Completa
}

public sealed class MYGAlertaPartida
{
    internal MYGAlertaPartida(MYGTipoAlertaPartida tipo, MYGZonaAlertaPartida zona,
        MYGSeveridadAlertaPartida severidad, string titulo, string mensaje, string detalle = null)
    { Tipo = tipo; Zona = zona; Severidad = severidad; Titulo = titulo; Mensaje = mensaje; Detalle = detalle ?? ""; }

    public MYGTipoAlertaPartida Tipo { get; }
    public MYGZonaAlertaPartida Zona { get; }
    public MYGSeveridadAlertaPartida Severidad { get; }
    public string Titulo { get; }
    public string Mensaje { get; }
    public string Detalle { get; }
}

public sealed class MYGDiagnosticoPartida
{
    internal MYGDiagnosticoPartida(bool esPartida, bool completa, decimal? cantidad,
        decimal? precio, decimal? total, List<MYGAlertaPartida> alertas)
    {
        EsPartida = esPartida; Completa = completa; Cantidad = cantidad;
        PrecioUnitario = precio; Total = total;
        Alertas = new ReadOnlyCollection<MYGAlertaPartida>(alertas);
    }
    public bool EsPartida { get; }
    // Lista técnica de comprobaciones, no aprobación humana de la partida.
    public bool Completa { get; }
    public decimal? Cantidad { get; }
    public decimal? PrecioUnitario { get; }
    public decimal? Total { get; }
    public IReadOnlyList<MYGAlertaPartida> Alertas { get; }
}

// Instantánea de la base activa: una lectura por actualización, nunca por fila
// ni al pasar el cursor. Su uso no crea bases, migra tablas ni graba vínculos.
public sealed class MYGRegistroACUCatalogo
{
    private readonly HashSet<string> ids;
    private readonly HashSet<string> codigos;
    private readonly bool disponible;
    private MYGRegistroACUCatalogo(string ruta, bool disponible, string detalle,
        IEnumerable<MYGEntradaCatalogo> entradas)
    {
        Ruta = ruta; this.disponible = disponible; Detalle = detalle;
        ids = entradas.Select(e => e.Id).Where(x => !string.IsNullOrWhiteSpace(x)).ToHashSet(StringComparer.OrdinalIgnoreCase);
        codigos = entradas.Select(e => e.Codigo).Where(x => !string.IsNullOrWhiteSpace(x)).ToHashSet(StringComparer.OrdinalIgnoreCase);
    }
    public string Ruta { get; }
    public string Detalle { get; }
    public bool Disponible => disponible;

    public static MYGRegistroACUCatalogo Leer(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta))
            return new("", false, "Guarde o abra una base SQLite para comprobar el catálogo de partidas.", Array.Empty<MYGEntradaCatalogo>());
        try
        {
            string absoluta = Path.GetFullPath(ruta);
            // Listar abre explícitamente en ReadOnly y rechaza archivos ausentes.
            return new(absoluta, true, "", MYGCatalogos.Listar(absoluta, true));
        }
        catch (Exception e) when (e is IOException or InvalidDataException or UnauthorizedAccessException or SecurityException or
            SqliteException or InvalidOperationException or ArgumentException or ArithmeticException or FormatException or System.Text.Json.JsonException)
        {
            return new(ruta, false, "No se pudo leer el catálogo de la base activa: " + e.Message, Array.Empty<MYGEntradaCatalogo>());
        }
    }

    public MYGEstadoRegistroACU Estado(ItemPresupuestoDelphin partida)
    {
        if (!disponible || partida == null || MYGProyectoStorage.EsTitulo(partida)) return MYGEstadoRegistroACU.SinVerificar;
        // Una identidad guardada debe seguir existiendo. Un código de otro
        // registro nunca sustituye una identidad eliminada del catálogo.
        string id = partida.Costos?.CatalogoMYGId;
        if (string.IsNullOrWhiteSpace(id)) id = partida.IdCatalogoDelphin;
        if (string.IsNullOrWhiteSpace(id)) id = partida.IdAnalisisDelphin;
        if (!string.IsNullOrWhiteSpace(id)) return ids.Contains(id) ? MYGEstadoRegistroACU.Registrado : MYGEstadoRegistroACU.NoRegistrado;
        // Sólo se admite el código explícito de catálogo, no el Item de la
        // jerarquía, la descripción ni el código visible del presupuesto.
        return !string.IsNullOrWhiteSpace(partida.CodigoCatalogoDelphin) && codigos.Contains(partida.CodigoCatalogoDelphin)
            ? MYGEstadoRegistroACU.Registrado : MYGEstadoRegistroACU.NoRegistrado;
    }
}

public static class MYGAlertasPartida
{
    // Pureza respecto al documento: usa el cálculo de la actualización, sin
    // llamar a Validar (que normaliza) ni consultar/escribir catálogos.
    public static MYGDiagnosticoPartida Evaluar(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i,
        MYGCalculoPresupuesto calculo = null, MYGEstadoRegistroACU registro = MYGEstadoRegistroACU.SinVerificar,
        string detalleRegistro = null)
    {
        var alertas = new List<MYGAlertaPartida>();
        if (i == null || MYGProyectoStorage.EsTitulo(i)) return new(false, false, null, null, null, alertas);
        void Agregar(MYGTipoAlertaPartida tipo, MYGZonaAlertaPartida zona, MYGSeveridadAlertaPartida severidad,
            string titulo, string mensaje, string detalle = null) => alertas.Add(new(tipo, zona, severidad, titulo, mensaje, detalle));

        if (string.IsNullOrWhiteSpace(i.Descripcion))
            Agregar(MYGTipoAlertaPartida.DescripcionVacia, MYGZonaAlertaPartida.Catalogo, MYGSeveridadAlertaPartida.Advertencia,
                "Alerta", "La partida no tiene descripción");
        if (string.IsNullOrWhiteSpace(i.Unidad))
            Agregar(MYGTipoAlertaPartida.UnidadVacia, MYGZonaAlertaPartida.Cantidad, MYGSeveridadAlertaPartida.Advertencia,
                "Alerta", "La partida no tiene unidad de medida");
        if (registro == MYGEstadoRegistroACU.NoRegistrado)
            Agregar(MYGTipoAlertaPartida.SinRegistroACU, MYGZonaAlertaPartida.Catalogo, MYGSeveridadAlertaPartida.Mensaje,
                "Mensaje", "ACU no registrado en base de datos :\n" + (i.Descripcion ?? ""),
                "El ACU no está registrado en el catálogo de la base SQLite activa.");
        else if (registro != MYGEstadoRegistroACU.Registrado)
            Agregar(MYGTipoAlertaPartida.RegistroACUSinVerificar, MYGZonaAlertaPartida.Catalogo, MYGSeveridadAlertaPartida.Mensaje,
                "Mensaje", "Registro del ACU en la base de datos sin verificar", detalleRegistro);

        if (p == null || i.Costos == null || p.Costos == null)
        {
            Agregar(MYGTipoAlertaPartida.DatosCostoIncompletos, MYGZonaAlertaPartida.Total, MYGSeveridadAlertaPartida.Error,
                "Alerta", "No se puede calcular la partida: faltan los datos de costos");
            return new(true, false, null, null, null, alertas);
        }
        // Un cálculo ajeno no puede producir importes de otro presupuesto.
        if (calculo == null || !ReferenceEquals(calculo.Presupuesto, p)) calculo = MYGMotorPresupuestos.CrearCalculo(p);
        bool tieneAnalisis = i.Costos.Analisis?.Count > 0;
        if (!tieneAnalisis)
            Agregar(MYGTipoAlertaPartida.SinAnalisis, MYGZonaAlertaPartida.Analisis,
                i.Costos.PrecioDirecto > 0 ? MYGSeveridadAlertaPartida.Mensaje : MYGSeveridadAlertaPartida.Advertencia,
                "Mensaje", "El costo unitario no tiene análisis",
                i.Costos.PrecioDirecto > 0 ? "Se usa un precio directo válido. El análisis de costos queda pendiente." : "Agregue recursos al ACU o indique un precio directo.");

        decimal? cantidad = null, precio = null, total = null;
        try
        {
            cantidad = calculo.Cantidad(i);
            if (cantidad == 0)
                Agregar(MYGTipoAlertaPartida.CantidadCero, MYGZonaAlertaPartida.Cantidad, MYGSeveridadAlertaPartida.Advertencia,
                    "Alerta", "La cantidad de la partida es cero", "Revise la cantidad o el metrado seleccionado: " + Fuente(i.Costos.FuenteMetrado) + ".");
        }
        catch (Exception e) when (EsErrorCalculo(e))
        {
            Agregar(MYGTipoAlertaPartida.ErrorCantidad, MYGZonaAlertaPartida.Cantidad, MYGSeveridadAlertaPartida.Error,
                "Alerta", "No se pudo calcular el metrado de la partida", e.Message);
        }
        try
        {
            var analisis = calculo.Analizar(i);
            precio = analisis.PrecioUnitario;
            foreach (var recurso in analisis.Recursos)
            {
                string clase = recurso.Recurso.Grupo == MYGGrupoRecurso.Subpartidas ? "La subpartida" : "El insumo";
                string nombre = (recurso.Codigo ?? "").Trim();
                if (!string.IsNullOrWhiteSpace(recurso.Descripcion)) nombre += (nombre.Length > 0 ? " · " : "") + recurso.Descripcion.Trim();
                if (nombre.Length == 0) nombre = recurso.Recurso.SubpartidaIdLocal ?? recurso.Recurso.InsumoId ?? recurso.Recurso.Id;
                if (recurso.Precio <= 0)
                    Agregar(MYGTipoAlertaPartida.RecursoSinPrecio, MYGZonaAlertaPartida.Analisis, MYGSeveridadAlertaPartida.Advertencia,
                        "Alerta", recurso.Recurso.Modo == MYGModoCantidad.PorcentajeManoObra && recurso.Precio == 0
                            ? "La base de mano de obra del recurso es cero: " + nombre
                            : clase + (recurso.Precio == 0 ? " no tiene precio: " : " tiene precio negativo: ") + nombre);
                if (recurso.Cantidad <= 0)
                    Agregar(MYGTipoAlertaPartida.RecursoSinCantidad, MYGZonaAlertaPartida.Analisis, MYGSeveridadAlertaPartida.Advertencia,
                        "Alerta", clase + (recurso.Cantidad == 0 ? " no tiene cantidad en el ACU: " : " tiene cantidad negativa en el ACU: ") + nombre);
                if (string.IsNullOrWhiteSpace(recurso.Unidad))
                    Agregar(MYGTipoAlertaPartida.RecursoSinUnidad, MYGZonaAlertaPartida.Analisis, MYGSeveridadAlertaPartida.Advertencia,
                        "Alerta", clase + " no tiene unidad de medida: " + nombre);
            }
            if (precio <= 0)
                Agregar(MYGTipoAlertaPartida.PrecioCero, MYGZonaAlertaPartida.Analisis, MYGSeveridadAlertaPartida.Advertencia,
                    "Alerta", precio == 0 ? "El precio unitario de la partida es cero" : "El precio unitario de la partida es negativo",
                    "Revise los precios y las cantidades del análisis de costos.");
        }
        catch (Exception e) when (EsErrorCalculo(e))
        {
            Agregar(MYGTipoAlertaPartida.ErrorAnalisis, MYGZonaAlertaPartida.Analisis, MYGSeveridadAlertaPartida.Error,
                "Alerta", "No se pudo calcular el análisis de costos de la partida", e.Message);
        }
        // Si el cálculo falló no se inventa un cero ni se repite la misma
        // evaluación fallida: la alerta de su origen explica el dato ausente.
        if (cantidad.HasValue && precio.HasValue)
        {
            try
            {
                total = calculo.TotalPartida(i);
                if (total <= 0)
                    Agregar(MYGTipoAlertaPartida.TotalCero, MYGZonaAlertaPartida.Total, MYGSeveridadAlertaPartida.Advertencia,
                        "Alerta", total == 0 ? "El total de la partida es cero" : "El total de la partida es negativo",
                        "Revise la cantidad y el precio unitario; se usa el redondeo del presupuesto.");
            }
            catch (Exception e) when (EsErrorCalculo(e))
            {
                Agregar(MYGTipoAlertaPartida.ErrorTotal, MYGZonaAlertaPartida.Total, MYGSeveridadAlertaPartida.Error,
                    "Alerta", "No se pudo calcular el total de la partida", e.Message);
            }
        }
        bool completa = alertas.Count == 0 && tieneAnalisis && cantidad > 0 && precio > 0 && total > 0;
        if (completa)
            Agregar(MYGTipoAlertaPartida.Completa, MYGZonaAlertaPartida.Total, MYGSeveridadAlertaPartida.Correcto,
                "Mensaje", "Partida completa", "Tiene descripción, unidad, metrado, análisis con precio positivo y ACU registrado en la base activa.");
        return new(true, completa, cantidad, precio, total, alertas);
    }

    private static bool EsErrorCalculo(Exception e) => e is InvalidDataException or InvalidOperationException or
        ArgumentException or ArithmeticException or FormatException or NullReferenceException;
    private static string Fuente(MYGFuenteMetrado fuente) => fuente switch
    { MYGFuenteMetrado.Manual => "metrado manual", MYGFuenteMetrado.BIM => "metrado BIM", MYGFuenteMetrado.Excel => "Metrado XLS", _ => "cantidad manual" };
}
