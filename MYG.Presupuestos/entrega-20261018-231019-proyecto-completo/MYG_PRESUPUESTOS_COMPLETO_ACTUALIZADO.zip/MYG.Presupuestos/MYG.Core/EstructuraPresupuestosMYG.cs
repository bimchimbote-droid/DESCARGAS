using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

// Operaciones de estructura independientes de WinForms. Se valida una copia antes
// de sustituir el contenido, para que un error no deje una edición a medias.
public static class MYGEstructuraPresupuestos
{
    private static readonly StringComparer Comparador = StringComparer.OrdinalIgnoreCase;
    private static bool Igual(string a, string b) => Comparador.Equals(a ?? "", b ?? "");
    private static string Padre(string id) => string.IsNullOrWhiteSpace(id) ? null : id;

    public static MYGPresupuestoDocumento AgregarPresupuesto(MYGProyectoDocumento doc, MYGPresupuestoDocumento antesDe = null)
    {
        ArgumentNullException.ThrowIfNull(doc);
        var trabajo = MYGProyectoStorage.Copia(doc);
        MYGProyectoStorage.Validar(trabajo);
        var orden = trabajo.Presupuestos.OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        int indice = antesDe == null ? orden.Count : orden.FindIndex(x => Igual(x.Id, antesDe.Id));
        if (indice < 0) throw new InvalidOperationException("El presupuesto seleccionado no pertenece al proyecto.");
        var nuevo = new MYGPresupuestoDocumento { Nombre = "PRESUPUESTO" };
        orden.Insert(indice, nuevo); trabajo.Presupuestos = orden;
        RenumerarEnCopia(trabajo); trabajo.PresupuestoActivoId = nuevo.Id;
        MYGProyectoStorage.Validar(trabajo);
        // Los presupuestos existentes conservan sus instancias, usadas por el editor.
        var existentes = doc.Presupuestos.ToDictionary(x => x.Id, Comparador);
        doc.Presupuestos = orden.Select(x =>
        {
            if (!existentes.TryGetValue(x.Id, out var original)) return x;
            original.Item = x.Item; original.Posicion = x.Posicion; return original;
        }).ToList();
        doc.PresupuestoActivoId = nuevo.Id;
        return nuevo;
    }

    public static ItemPresupuestoDelphin InsertarNodo(MYGPresupuestoDocumento p, bool titulo,
        string padreId = null, string antesDeId = null)
    {
        var trabajo = Preparar(p); padreId = Padre(padreId);
        var hermanos = Destino(trabajo, padreId, antesDeId, out int indice);
        var codigos = trabajo.Items.Select(x => x.Item ?? "").ToHashSet(Comparador);
        int siguienteCodigo = 1;
        string id = MYGProyectoStorage.NuevoId();
        var nuevo = new ItemPresupuestoDelphin
        {
            Id = id,
            IdLocalMYG = id,
            IdPropuesta = id,
            ParentId = padreId,
            Descripcion = titulo ? "TÍTULO" : "PARTIDA",
            Unidad = titulo ? "" : "und",
            TipoPropuesta = titulo ? "TITULO" : "PARTIDA",
            Origen = "MODELO",
            Estado = "PROPUESTA",
            Item = CodigoPropuesta(codigos, ref siguienteCodigo)
        };
        hermanos.Insert(indice, nuevo); OrdenarHermanos(hermanos);
        trabajo.Items.Add(nuevo); Terminar(trabajo); Aplicar(p, trabajo);
        return nuevo;
    }

    public static List<ItemPresupuestoDelphin> Rama(MYGPresupuestoDocumento p, ItemPresupuestoDelphin raiz)
    {
        ArgumentNullException.ThrowIfNull(p);
        if (raiz == null || !p.Items.Any(x => Igual(x.Id, raiz.Id)))
            throw new InvalidOperationException("Seleccione un ítem de este presupuesto.");
        var resultado = new List<ItemPresupuestoDelphin>();
        var visitados = new HashSet<string>(Comparador);
        void Visitar(ItemPresupuestoDelphin i, int nivel)
        {
            if (nivel >= 64 || !visitados.Add(i.Id)) throw new InvalidDataException("Jerarquía circular o demasiado profunda.");
            resultado.Add(i);
            foreach (var hijo in p.Items.Where(x => Igual(x.ParentId, i.Id)).OrderBy(x => x.Posicion).ThenBy(x => x.Item))
                Visitar(hijo, nivel + 1);
        }
        Visitar(p.Items.First(x => Igual(x.Id, raiz.Id)), 0);
        return resultado;
    }

    public static void EliminarNodo(MYGPresupuestoDocumento p, ItemPresupuestoDelphin nodo)
    {
        var trabajo = Preparar(p); var rama = Rama(trabajo, nodo);
        if (rama.Any(EsOficial)) throw new InvalidOperationException("Las filas oficiales se mantienen en Delphin. Elimine únicamente propuestas MYG.");
        var ids = rama.Select(x => x.Id).ToHashSet(Comparador);
        var locales = rama.Select(x => x.IdLocalMYG).ToHashSet(Comparador);
        if (trabajo.Items.Any(x => !ids.Contains(x.Id) && x.Costos.Analisis.Any(r => locales.Contains(r.SubpartidaIdLocal ?? ""))))
            throw new InvalidOperationException("La selección está usada como subanálisis. Quite esas referencias del ACU antes de eliminarla.");
        trabajo.Items.RemoveAll(x => ids.Contains(x.Id));
        Terminar(trabajo); Aplicar(p, trabajo);
    }

    public static MYGPresupuestoDocumento CopiarRama(MYGPresupuestoDocumento p, ItemPresupuestoDelphin nodo = null)
    {
        var origen = Preparar(p); var seleccion = nodo == null ? origen.Items.ToList() : Rama(origen, nodo);
        var incluidos = seleccion.Select(x => x.Id).ToHashSet(Comparador);
        // Un ACU puede usar una partida fuera del título copiado. Se incluye su
        // cierre transitivo; copiar sólo el título dejaría referencias rotas.
        for (int n = 0; n < seleccion.Count; n++)
            foreach (var r in seleccion[n].Costos.Analisis.Where(x => x.Grupo == MYGGrupoRecurso.Subpartidas))
            {
                var dependencia = origen.Items.FirstOrDefault(x => Igual(x.IdLocalMYG, r.SubpartidaIdLocal));
                if (dependencia == null) throw new InvalidDataException("El ACU referencia una subpartida inexistente.");
                if (incluidos.Add(dependencia.Id)) seleccion.Add(dependencia);
            }
        var fragmento = new MYGPresupuestoDocumento
        {
            Nombre = nodo?.Descripcion ?? origen.Nombre,
            Item = origen.Item,
            CantidadFiltros = origen.CantidadFiltros,
            Costos = MYGProyectoStorage.Copia(origen.Costos),
            Items = seleccion.Select(MYGProyectoStorage.Copia).ToList()
        };
        foreach (var i in fragmento.Items)
            if (!incluidos.Contains(i.ParentId ?? "")) i.ParentId = null;
        var insumos = fragmento.Items.SelectMany(x => x.Costos.Analisis)
            .Where(x => x.Grupo != MYGGrupoRecurso.Subpartidas).Select(x => x.InsumoId).ToHashSet(Comparador);
        if (nodo != null) fragmento.Costos.Insumos.RemoveAll(x => !insumos.Contains(x.Id));
        fragmento.Costos.FirmaDatosImportadosDelphin = null;
        // La raíz seleccionada precede a las dependencias añadidas al fragmento.
        OrdenarHermanos(fragmento.Items.Where(x => x.ParentId == null).ToList());
        MYGProyectoStorage.ValidarPresupuesto(fragmento);
        return fragmento;
    }

    public static List<ItemPresupuestoDelphin> PegarRama(MYGPresupuestoDocumento destino,
        MYGPresupuestoDocumento fragmento, string padreId = null, string antesDeId = null, bool conMetrados = true)
    {
        var trabajo = Preparar(destino); var origen = Preparar(fragmento); padreId = Padre(padreId);
        var hermanos = Destino(trabajo, padreId, antesDeId, out int indice);
        bool numeracionProtegida = trabajo.Conexion != null || trabajo.Items.Any(EsOficial);
        var codigos = trabajo.Items.Select(x => x.Item ?? "").ToHashSet(Comparador);
        int siguienteCodigo = 1;
        bool mismaPrecision = trabajo.Costos.DecimalesPrecio == origen.Costos.DecimalesPrecio &&
            trabajo.Costos.DecimalesCantidad == origen.Costos.DecimalesCantidad;
        var redondeos = origen.Items.Where(x => mismaPrecision && !MYGProyectoStorage.EsTitulo(x) && MYGMotorPresupuestos.ConservaAnalisisDelphin(origen, x))
            .ToDictionary(x => x.Id, x => (Precio: MYGMotorPresupuestos.Analizar(origen, x).PrecioUnitario,
                Parcial: MYGMotorPresupuestos.TotalPartida(origen, x)), Comparador);
        var nodos = origen.Items.ToDictionary(x => x.Id, x => MYGProyectoStorage.NuevoId(), Comparador);
        var locales = origen.Items.ToDictionary(x => x.IdLocalMYG, x => nodos[x.Id], Comparador);
        var insumos = origen.Costos.Insumos.ToDictionary(x => x.Id, x => MYGProyectoStorage.NuevoId(), Comparador);
        foreach (var original in origen.Costos.Insumos)
        {
            var copia = MYGProyectoStorage.Copia(original); copia.Id = insumos[original.Id];
            trabajo.Costos.Insumos.Add(copia);
        }
        var raices = new List<ItemPresupuestoDelphin>();
        foreach (var original in origen.Items)
        {
            var copia = MYGProyectoStorage.Copia(original);
            copia.Id = nodos[original.Id]; copia.IdLocalMYG = copia.Id; copia.IdPropuesta = copia.Id;
            if (numeracionProtegida) copia.Item = CodigoPropuesta(codigos, ref siguienteCodigo);
            bool raiz = string.IsNullOrWhiteSpace(original.ParentId);
            copia.ParentId = raiz ? padreId : nodos[original.ParentId];
            Desvincular(copia);
            foreach (var r in copia.Costos.Analisis)
            {
                r.Id = MYGProyectoStorage.NuevoId();
                if (r.Grupo == MYGGrupoRecurso.Subpartidas) { r.SubpartidaIdLocal = locales[r.SubpartidaIdLocal]; r.InsumoId = null; }
                else { r.InsumoId = insumos[r.InsumoId]; r.SubpartidaIdLocal = null; }
            }
            copia.Costos.FirmaDatosImportadosDelphin = null;
            copia.Costos.FirmaAnalisisImportadoDelphin = null;
            copia.Costos.PrecioImportadoDelphin = null;
            copia.Costos.ParcialImportadoDelphin = null;
            copia.Costos.CantidadImportadaDelphin = null;
            if (!conMetrados) LimpiarMetrados(copia);
            if (raiz) raices.Add(copia);
            trabajo.Items.Add(copia);
        }
        raices = raices.OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        hermanos.InsertRange(indice, raices); OrdenarHermanos(hermanos);
        trabajo.CantidadFiltros = Math.Max(trabajo.CantidadFiltros, origen.CantidadFiltros);
        trabajo.Costos.FirmaDatosImportadosDelphin = null;
        // Las firmas importadas contienen los IDs anteriores. Se reconstruyen
        // después del remapeo para conservar los redondeos nativos, sin reutilizar
        // una firma ajena ni imponer otra precisión al presupuesto de destino.
        foreach (var r in redondeos)
        {
            var copiado = trabajo.Items.First(x => Igual(x.Id, nodos[r.Key]));
            MYGMotorPresupuestos.CapturarPrecioDelphin(trabajo, copiado, r.Value.Precio, conMetrados ? r.Value.Parcial : 0);
            if (!conMetrados) { copiado.Costos.CantidadImportadaDelphin = null; copiado.Costos.ParcialImportadoDelphin = null; }
        }
        Terminar(trabajo); Aplicar(destino, trabajo);
        return raices;
    }

    public static MYGPresupuestoDocumento ConvertirTitulo(MYGProyectoDocumento doc,
        MYGPresupuestoDocumento p, ItemPresupuestoDelphin titulo)
    {
        ArgumentNullException.ThrowIfNull(doc);
        if (p == null || !doc.Presupuestos.Any(x => Igual(x.Id, p.Id)))
            throw new InvalidOperationException("El presupuesto seleccionado no pertenece al proyecto.");
        var proyecto = MYGProyectoStorage.Copia(doc); MYGProyectoStorage.Validar(proyecto);
        var origen = proyecto.Presupuestos.First(x => Igual(x.Id, p.Id));
        var rama = Rama(origen, titulo); var raiz = rama[0];
        if (!MYGProyectoStorage.EsTitulo(raiz)) throw new InvalidOperationException("Seleccione un título para convertirlo en presupuesto.");
        if (rama.Any(EsOficial)) throw new InvalidOperationException("La selección contiene filas oficiales de Delphin. Copie la rama como propuesta antes de convertirla.");
        var ids = rama.Select(x => x.Id).ToHashSet(Comparador);
        var locales = rama.Select(x => x.IdLocalMYG).ToHashSet(Comparador);
        foreach (var i in origen.Items)
            if (i.Costos.Analisis.Any(r => r.Grupo == MYGGrupoRecurso.Subpartidas && ids.Contains(i.Id) != locales.Contains(r.SubpartidaIdLocal ?? "")))
                throw new InvalidOperationException("El título comparte subanálisis con otras ramas. Quite esas referencias antes de convertirlo.");
        var nuevo = new MYGPresupuestoDocumento
        {
            Nombre = raiz.Descripcion,
            CantidadFiltros = origen.CantidadFiltros,
            Costos = MYGProyectoStorage.Copia(origen.Costos),
            Items = rama.Skip(1).ToList()
        };
        if (raiz.Costos.Responsables?.Count > 0)
            nuevo.Costos.Responsables = MYGProyectoStorage.Copia(raiz.Costos.Responsables);
        foreach (var i in nuevo.Items) if (Igual(i.ParentId, raiz.Id)) i.ParentId = null;
        var necesarios = nuevo.Items.SelectMany(x => x.Costos.Analisis).Where(x => x.Grupo != MYGGrupoRecurso.Subpartidas)
            .Select(x => x.InsumoId).ToHashSet(Comparador);
        nuevo.Costos.Insumos.RemoveAll(x => !necesarios.Contains(x.Id));
        nuevo.Costos.FirmaDatosImportadosDelphin = null;
        origen.Items.RemoveAll(x => ids.Contains(x.Id)); origen.Costos.FirmaDatosImportadosDelphin = null;
        Terminar(origen); Terminar(nuevo);
        var orden = proyecto.Presupuestos.OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        orden.Insert(orden.IndexOf(origen) + 1, nuevo); proyecto.Presupuestos = orden;
        RenumerarEnCopia(proyecto); proyecto.PresupuestoActivoId = nuevo.Id;
        MYGProyectoStorage.Validar(proyecto);
        Aplicar(p, origen);
        var existentes = doc.Presupuestos.ToDictionary(x => x.Id, Comparador);
        doc.Presupuestos = orden.Select(x =>
        {
            if (!existentes.TryGetValue(x.Id, out var original)) return x;
            original.Item = x.Item; original.Posicion = x.Posicion; return original;
        }).ToList();
        doc.PresupuestoActivoId = nuevo.Id;
        return nuevo;
    }

    public static void EliminarMetrados(MYGPresupuestoDocumento p, IEnumerable<ItemPresupuestoDelphin> items)
    {
        ArgumentNullException.ThrowIfNull(items);
        var trabajo = Preparar(p); var ids = new HashSet<string>(Comparador);
        foreach (var i in items) foreach (var miembro in Rama(trabajo, i)) ids.Add(miembro.Id);
        foreach (var i in trabajo.Items.Where(x => ids.Contains(x.Id))) LimpiarMetrados(i);
        trabajo.Costos.FirmaDatosImportadosDelphin = null;
        Terminar(trabajo); Aplicar(p, trabajo);
    }

    public static void RenumerarPresupuestos(MYGProyectoDocumento doc)
    {
        ArgumentNullException.ThrowIfNull(doc);
        var trabajo = MYGProyectoStorage.Copia(doc); MYGProyectoStorage.Validar(trabajo);
        trabajo.Presupuestos = trabajo.Presupuestos.OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        RenumerarEnCopia(trabajo); MYGProyectoStorage.Validar(trabajo);
        var posiciones = trabajo.Presupuestos.ToDictionary(x => x.Id, Comparador);
        foreach (var p in doc.Presupuestos) { p.Item = posiciones[p.Id].Item; p.Posicion = posiciones[p.Id].Posicion; }
        doc.Presupuestos = doc.Presupuestos.OrderBy(x => x.Posicion).ToList();
    }

    public static int ActualizarInsumos(MYGPresupuestoDocumento p, IEnumerable<ItemPresupuestoDelphin> alcance, string rutaCatalogo)
    {
        var trabajo = Preparar(p); var ids = Alcance(trabajo, alcance);
        var usados = trabajo.Items.Where(x => ids.Contains(x.Id)).SelectMany(x => x.Costos.Analisis)
            .Where(x => x.Grupo != MYGGrupoRecurso.Subpartidas).Select(x => x.InsumoId).ToHashSet(Comparador);
        var entradas = MYGCatalogos.Listar(rutaCatalogo, false).ToDictionary(x => x.Id, Comparador);
        int cantidad = 0;
        foreach (var insumo in trabajo.Costos.Insumos.Where(x => usados.Contains(x.Id) && !string.IsNullOrWhiteSpace(x.CatalogoMYGId)))
        {
            if (!entradas.TryGetValue(insumo.CatalogoMYGId, out var entrada))
                throw new InvalidOperationException("El insumo vinculado «" + insumo.Descripcion + "» ya no existe en el catálogo de esta base.");
            var nuevo = MYGCatalogos.LeerInsumo(rutaCatalogo, entrada.Id, entrada.Revision);
            if (!MYGProyectoStorage.MismaUnidad(insumo.Unidad, nuevo.Unidad) || insumo.Grupo != nuevo.Grupo)
                throw new InvalidOperationException("El insumo «" + insumo.Descripcion + "» cambió de unidad o grupo. Cree otro insumo para usar esos datos.");
            insumo.Codigo = nuevo.Codigo; insumo.Descripcion = nuevo.Descripcion; insumo.Precio = nuevo.Precio;
            cantidad++;
        }
        if (cantidad == 0) return 0;
        trabajo.Costos.FirmaDatosImportadosDelphin = null;
        foreach (var i in trabajo.Items.Where(x => x.Costos.Analisis.Any(r => usados.Contains(r.InsumoId ?? ""))))
            i.Costos.FirmaDatosImportadosDelphin = null;
        Terminar(trabajo); Aplicar(p, trabajo); return cantidad;
    }

    public static int ActualizarCostosUnitarios(MYGPresupuestoDocumento p, IEnumerable<ItemPresupuestoDelphin> alcance, string rutaCatalogo)
    {
        var trabajo = Preparar(p); var ids = Alcance(trabajo, alcance);
        var objetivos = trabajo.Items.Where(x => ids.Contains(x.Id) && !MYGProyectoStorage.EsTitulo(x) &&
            !string.IsNullOrWhiteSpace(x.Costos.CatalogoMYGId)).Select(x => x.Id).ToList();
        var entradas = MYGCatalogos.Listar(rutaCatalogo, true).ToDictionary(x => x.Id, Comparador);
        foreach (string id in objetivos)
        {
            var objetivo = trabajo.Items.First(x => Igual(x.Id, id));
            if (!entradas.TryGetValue(objetivo.Costos.CatalogoMYGId, out var entrada))
                throw new InvalidOperationException("La partida vinculada «" + objetivo.Descripcion + "» ya no existe en el catálogo de esta base.");
            if (!MYGProyectoStorage.MismaUnidad(objetivo.Unidad, entrada.Unidad))
                throw new InvalidOperationException("El costo unitario del catálogo cambió de unidad. Mantenga la partida actual o cree otra con la nueva unidad.");
            var numeracionProtegida = trabajo.Conexion == null && trabajo.Items.Any(EsOficial)
                ? trabajo.Items.ToDictionary(x => x.Id, x => (x.Item, x.Posicion), Comparador) : null;
            var temporal = MYGCatalogos.InsertarPartida(trabajo, rutaCatalogo, entrada, objetivo.ParentId);
            if (numeracionProtegida != null) RestaurarNumeracion(trabajo, numeracionProtegida, temporal.Id);
            // InsertarPartida valida y sustituye las listas. Se recupera la instancia
            // vigente y sólo se reemplazan los datos del análisis, nunca el metrado.
            objetivo = trabajo.Items.First(x => Igual(x.Id, id));
            if (!MYGProyectoStorage.MismaUnidad(objetivo.Unidad, temporal.Unidad))
                throw new InvalidOperationException("El análisis del catálogo no utiliza la unidad de la partida.");
            var datos = objetivo.Costos; var nuevos = temporal.Costos;
            datos.Analisis = nuevos.Analisis; datos.PrecioDirecto = nuevos.PrecioDirecto;
            datos.RendimientoDiario = nuevos.RendimientoDiario; datos.JornadaHoras = nuevos.JornadaHoras;
            datos.PrecioImportadoDelphin = null; datos.ParcialImportadoDelphin = null;
            datos.CantidadImportadaDelphin = null; datos.FirmaAnalisisImportadoDelphin = null;
            datos.FirmaDatosImportadosDelphin = null;
            trabajo.Items.Remove(temporal);
        }
        if (objetivos.Count == 0) return 0;
        trabajo.Costos.FirmaDatosImportadosDelphin = null;
        Terminar(trabajo); Aplicar(p, trabajo); return objetivos.Count;
    }

    private static HashSet<string> Alcance(MYGPresupuestoDocumento p, IEnumerable<ItemPresupuestoDelphin> alcance)
    {
        ArgumentNullException.ThrowIfNull(alcance);
        var seleccion = new List<ItemPresupuestoDelphin>(); var ids = new HashSet<string>(Comparador);
        foreach (var i in alcance)
            foreach (var miembro in Rama(p, i)) if (ids.Add(miembro.Id)) seleccion.Add(miembro);
        for (int n = 0; n < seleccion.Count; n++)
            foreach (var r in seleccion[n].Costos.Analisis.Where(x => x.Grupo == MYGGrupoRecurso.Subpartidas))
            {
                var dependencia = p.Items.First(x => Igual(x.IdLocalMYG, r.SubpartidaIdLocal));
                if (ids.Add(dependencia.Id)) seleccion.Add(dependencia);
            }
        return ids;
    }

    private static void RestaurarNumeracion(MYGPresupuestoDocumento p,
        Dictionary<string, (string Item, int Posicion)> numeracion, string raizTemporalId)
    {
        foreach (var i in p.Items)
            if (numeracion.TryGetValue(i.Id, out var original)) { i.Item = original.Item; i.Posicion = original.Posicion; }
        var codigos = numeracion.Values.Select(x => x.Item ?? "").ToHashSet(Comparador);
        int siguiente = 1;
        foreach (var grupo in p.Items.Where(x => !numeracion.ContainsKey(x.Id) && !Igual(x.Id, raizTemporalId))
            .GroupBy(x => x.ParentId ?? "", Comparador))
        {
            int posicion = p.Items.Where(x => numeracion.ContainsKey(x.Id) && Igual(x.ParentId, grupo.Key))
                .Select(x => x.Posicion).DefaultIfEmpty().Max();
            foreach (var i in grupo.OrderBy(x => x.Posicion).ThenBy(x => x.Item))
            {
                i.Item = CodigoPropuesta(codigos, ref siguiente); i.Posicion = ++posicion;
            }
        }
    }

    private static string CodigoPropuesta(HashSet<string> codigos, ref int siguiente)
    {
        string codigo;
        do { codigo = "P-" + (siguiente++).ToString("D3", CultureInfo.InvariantCulture); } while (!codigos.Add(codigo));
        return codigo;
    }

    private static MYGPresupuestoDocumento Preparar(MYGPresupuestoDocumento p)
    {
        ArgumentNullException.ThrowIfNull(p);
        var trabajo = MYGProyectoStorage.Copia(p); MYGProyectoStorage.ValidarPresupuesto(trabajo); return trabajo;
    }
    private static List<ItemPresupuestoDelphin> Destino(MYGPresupuestoDocumento p, string padreId, string antesDeId, out int indice)
    {
        if (padreId != null && !p.Items.Any(x => Igual(x.Id, padreId) && MYGProyectoStorage.EsTitulo(x)))
            throw new InvalidOperationException("Seleccione un título como destino.");
        var hermanos = p.Items.Where(x => Igual(x.ParentId, padreId)).OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        indice = string.IsNullOrWhiteSpace(antesDeId) ? hermanos.Count : hermanos.FindIndex(x => Igual(x.Id, antesDeId));
        if (indice < 0) throw new InvalidOperationException("El ítem de referencia no pertenece al mismo nivel.");
        return hermanos;
    }
    private static void OrdenarHermanos(List<ItemPresupuestoDelphin> hermanos)
    { for (int n = 0; n < hermanos.Count; n++) hermanos[n].Posicion = n + 1; }
    private static void RenumerarEnCopia(MYGProyectoDocumento doc)
    {
        bool Protegido(MYGPresupuestoDocumento p) => p.Conexion != null || p.Items.Any(EsOficial);
        var reservados = doc.Presupuestos.Where(Protegido).Select(x => x.Item ?? "").ToHashSet(Comparador);
        int siguiente = 1;
        for (int n = 0; n < doc.Presupuestos.Count; n++)
        {
            var p = doc.Presupuestos[n]; p.Posicion = n + 1;
            if (Protegido(p)) continue;
            string codigo;
            do { codigo = (siguiente++).ToString("D2", CultureInfo.InvariantCulture); } while (reservados.Contains(codigo));
            p.Item = codigo;
        }
    }
    private static void Terminar(MYGPresupuestoDocumento p)
    {
        MYGProyectoStorage.ValidarPresupuesto(p);
        if (p.Conexion == null && !p.Items.Any(EsOficial)) MYGProyectoStorage.Renumerar(p);
    }
    private static void Aplicar(MYGPresupuestoDocumento destino, MYGPresupuestoDocumento trabajo)
    {
        destino.Items = trabajo.Items; destino.Costos = trabajo.Costos;
        destino.CantidadFiltros = trabajo.CantidadFiltros; destino.IdPresupuestoRevit = trabajo.IdPresupuestoRevit;
    }
    private static bool EsOficial(ItemPresupuestoDelphin i) => !string.IsNullOrWhiteSpace(i.IdInternoDelphin);
    private static void Desvincular(ItemPresupuestoDelphin i)
    {
        i.IdInternoDelphin = null; i.IdAnalisisDelphin = null; i.Origen = "MODELO"; i.Estado = "PROPUESTA";
        i.PartidaOriginal = null; i.UnidadOriginal = null; i.PartidaPropuesta = null; i.UnidadPropuesta = null;
        i.EstadoRevit = null; i.MensajeRevit = null;
    }
    private static void LimpiarMetrados(ItemPresupuestoDelphin i)
    {
        var d = i.Costos; d.Cantidad = 0; d.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        d.Metrados.Clear(); d.MetradosBIM.Clear(); d.Hoja = MYGHojaMetrado.Crear();
        d.CantidadImportadaDelphin = null; d.ParcialImportadoDelphin = null; d.FirmaDatosImportadosDelphin = null;
    }
}
