namespace MYG.Externo;
public static class ServidorLicencias { public const string Url = "https://script.google.com/macros/s/AKfycbzfLUg-1rC3qOSHZk45AN3QODZaPOwNjw9cE6ZeSQ05v54YxTJhF8PDKsIH-i5rf974/exec"; }
