using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MYG.Externo;

public sealed class CredencialMYG
{
    public string Usuario { get; set; }
    public string Clave { get; set; }
    public string Token { get; set; }
    public bool Automatico { get; set; }
    public bool RecordarIngreso { get; set; }
    public string Identidad() => Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(new[]
        { (Usuario ?? "").Trim(), Automatico ? "AUTOMATICO" : "MANUAL", Automatico ? Token : Clave?.Trim() })));
}
public sealed record ResultadoAcceso(bool Ok, string Mensaje, string Token = null);

public sealed class LicenciaServicio
{
    private readonly HttpClient cliente;
    private readonly string pc;
    private readonly string url;
    public LicenciaServicio(HttpClient cliente, string pc, string url = ServidorLicencias.Url)
    { this.cliente = cliente; this.pc = pc; this.url = url; }

    public async Task<ResultadoAcceso> ValidarAsync(CredencialMYG c, CancellationToken cancelacion = default)
    {
        if (c == null || string.IsNullOrWhiteSpace(c.Usuario)) return new(false, "Ingrese el usuario.");
        if (c.Automatico && (c.Token == null || c.Token.Length < 32)) return new(false, "Inicie sesión con usuario y contraseña.");
        if (!c.Automatico && string.IsNullOrWhiteSpace(c.Clave)) return new(false, "Ingrese la contraseña.");
        try
        {
            using var tiempo = CancellationTokenSource.CreateLinkedTokenSource(cancelacion);
            tiempo.CancelAfter(TimeSpan.FromSeconds(15));
            using var solicitud = c.Automatico ? new HttpRequestMessage(HttpMethod.Post, url) :
                new HttpRequestMessage(HttpMethod.Get, url + "?usuario=" + Uri.EscapeDataString(c.Usuario.Trim()) +
                    "&clave=" + Uri.EscapeDataString(c.Clave.Trim()) + "&pc=" + Uri.EscapeDataString(pc));
            if (c.Automatico) solicitud.Content = new FormUrlEncodedContent(new Dictionary<string, string>
                { ["usuario"] = c.Usuario.Trim(), ["token"] = c.Token, ["pc"] = pc });
            solicitud.Headers.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue { NoCache = true };
            using var respuesta = await cliente.SendAsync(solicitud, tiempo.Token).ConfigureAwait(false);
            if (!respuesta.IsSuccessStatusCode) return new(false, "No se pudo consultar la licencia MYG.");
            string texto = (await respuesta.Content.ReadAsStringAsync(tiempo.Token).ConfigureAwait(false)).Trim();
            return Interpretar(texto, c.Automatico);
        }
        catch (OperationCanceledException) { return new(false, "La validación de licencia no respondió. Compruebe su conexión."); }
        catch (HttpRequestException) { return new(false, "No se pudo conectar con el servicio de licencias MYG."); }
    }
    public static ResultadoAcceso Interpretar(string texto, bool automatico)
    {
        if (texto == "OK") return new(true, "Licencia validada.");
        if (!automatico && texto.StartsWith("OK|", StringComparison.Ordinal))
        {
            string token = texto[3..].Trim();
            return token.Length >= 32 ? new(true, "Licencia validada.", token) : new(false, "El servicio devolvió una sesión inválida.");
        }
        return new(false, texto switch {
            "EXPIRADO" => "Licencia expirada.", "BLOQUEADO" => "Licencia bloqueada.",
            "OTRA_PC" => "La licencia está registrada en otra computadora.", "CLAVE_ERROR" => "Contraseña incorrecta.",
            "NO_EXISTE" => "Usuario no registrado.", "TOKEN_INVALIDO" => "Inicie sesión nuevamente.",
            "INGRESO_AUTOMATICO_NO" or "AUTO_NO" or "NO_AUTOMATICO" => "Ingrese su usuario y contraseña.",
            _ => "No se pudo autorizar el acceso. Inicie sesión o consulte al administrador de MYG." });
    }
}
