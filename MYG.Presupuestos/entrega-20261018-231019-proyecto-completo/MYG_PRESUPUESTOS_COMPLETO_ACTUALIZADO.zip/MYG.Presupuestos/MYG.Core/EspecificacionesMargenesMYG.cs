using System;

namespace MYG_2027;

/// <summary>Limita el margen arrastrado conservando el opuesto y el área de texto.</summary>
public static class MYGEspecificacionesMargenes
{
    public static (decimal InicioMm, decimal FinMm) Arrastrar(decimal longitudPaginaMm,
        decimal margenInicioMm, decimal margenFinMm, decimal posicionDesdeInicioMm,
        bool moverInicio, decimal minimoTextoMm = 10m)
    {
        if (longitudPaginaMm <= 0m || minimoTextoMm <= 0m || minimoTextoMm > longitudPaginaMm ||
            margenInicioMm < 0m || margenFinMm < 0m || margenInicioMm >= longitudPaginaMm ||
            margenFinMm >= longitudPaginaMm - margenInicioMm)
            throw new ArgumentException("La página y sus márgenes deben dejar un área de texto positiva.");

        decimal opuesto = moverInicio ? margenFinMm : margenInicioMm;
        // Si una hoja heredada deja menos de 10 mm, no desplazar su margen
        // opuesto: conservar al menos el ancho que ya tenía al comenzar.
        decimal minimo = Math.Min(minimoTextoMm, longitudPaginaMm - margenInicioMm - margenFinMm);
        decimal margen = moverInicio ? posicionDesdeInicioMm : longitudPaginaMm - posicionDesdeInicioMm;
        margen = Math.Clamp(margen, 0m, longitudPaginaMm - opuesto - minimo);
        return moverInicio ? (margen, margenFinMm) : (margenInicioMm, margen);
    }
}
