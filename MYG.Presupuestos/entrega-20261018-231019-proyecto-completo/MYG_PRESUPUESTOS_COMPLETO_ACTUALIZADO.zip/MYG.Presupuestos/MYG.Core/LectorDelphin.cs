using System;using System.Collections.Generic;using System.Data.Common;using System.IO;using System.Reflection;
using System.Linq;using System.Text;using System.Text.Json;using System.Globalization;using System.Text.RegularExpressions;
namespace MYG_2027 {
public static class SQLiteDependencyBootstrapper {
private static readonly object Candado = new(); private static bool listo;
public static Assembly MicrosoftDataSqliteAssembly => typeof(Microsoft.Data.Sqlite.SqliteConnection).Assembly;
public static void Initialize(){lock(Candado){if(listo)return;SQLitePCL.Batteries_V2.Init();listo=true;}}
}
public static class LectorDelphin {
        public static List<ProyectoDelphin>
            LeerProyectosSQLite(
                string sqlitePath)
        {
            var resultado =
                new List<ProyectoDelphin>();

            using (DbConnection connection =
                AbrirConexionSQLite(sqlitePath))
            {
                using (DbCommand command =
                    connection.CreateCommand())
                {
                    command.CommandText = @"
                        SELECT
                            id_proyecto,
                            nombre_proyecto
                        FROM proyecto
                        ORDER BY nombre_proyecto;
                    ";

                    using (DbDataReader reader =
                        command.ExecuteReader())
                    {
                        int idxId =
                            reader.GetOrdinal("id_proyecto");

                        int idxNombre =
                            reader.GetOrdinal("nombre_proyecto");

                        while (reader.Read())
                        {
                            string id =
                                LeerTexto(reader, idxId);

                            string nombre =
                                LeerTexto(reader, idxNombre);

                            if (string.IsNullOrWhiteSpace(nombre))
                            {
                                nombre =
                                    "(Proyecto sin nombre)";
                            }

                            resultado.Add(
                                new ProyectoDelphin()
                                {
                                    Id = id,
                                    Nombre = nombre
                                });
                        }
                    }
                }
            }

            return resultado;
        }

        public static List<PresupuestoDelphin>
            LeerPresupuestosSQLite(
                string sqlitePath,
                string projectId)
        {
            var resultado =
                new List<PresupuestoDelphin>();

            using (DbConnection connection =
                AbrirConexionSQLite(sqlitePath))
            {
                using (DbCommand command =
                    connection.CreateCommand())
                {
                    command.CommandText = @"
                        SELECT
                            id_presupuesto,
                            numeracion_presupuesto,
                            nombre_presupuesto,
                            posicion_presupuesto
                        FROM presupuesto
                        WHERE id_proyecto = @idProyecto
                        ORDER BY
                            posicion_presupuesto,
                            numeracion_presupuesto,
                            nombre_presupuesto;
                    ";

                    AgregarParametro(
                        command,
                        "@idProyecto",
                        projectId);

                    using (DbDataReader reader =
                        command.ExecuteReader())
                    {
                        int idxId =
                            reader.GetOrdinal("id_presupuesto");

                        int idxItem =
                            reader.GetOrdinal("numeracion_presupuesto");

                        int idxNombre =
                            reader.GetOrdinal("nombre_presupuesto");

                        int idxPosicion =
                            reader.GetOrdinal("posicion_presupuesto");

                        while (reader.Read())
                        {
                            resultado.Add(
                                new PresupuestoDelphin()
                                {
                                    Id = LeerTexto(reader, idxId),
                                    Item = LeerTexto(reader, idxItem),
                                    Nombre = LeerTexto(reader, idxNombre),
                                    Posicion = LeerEntero(reader, idxPosicion)
                                });
                        }
                    }
                }
            }

            return resultado;
        }

        // =======================================
        // UNIDAD DE MEDIDA DESDE DELPHIN / SQLITE
        // =======================================
        private class ColumnaSQLiteInfo
        {
            public string Nombre { get; set; }
            public string Tipo { get; set; }
        }

        private static List<ColumnaSQLiteInfo>
            LeerColumnasTabla(
                DbConnection connection,
                string tabla)
        {
            var resultado =
                new List<ColumnaSQLiteInfo>();

            using (
                DbCommand command =
                    connection.CreateCommand())
            {
                command.CommandText =
                    "PRAGMA table_info(" +
                    EscaparIdentificadorSQLite(
                        tabla) +
                    ");";

                using (
                    DbDataReader reader =
                        command.ExecuteReader())
                {
                    int idxNombre =
                        reader.GetOrdinal(
                            "name");

                    int idxTipo =
                        reader.GetOrdinal(
                            "type");

                    while (
                        reader.Read())
                    {
                        resultado.Add(
                            new ColumnaSQLiteInfo()
                            {
                                Nombre =
                                    LeerTexto(
                                        reader,
                                        idxNombre),

                                Tipo =
                                    LeerTexto(
                                        reader,
                                        idxTipo)
                            });
                    }
                }
            }

            return resultado;
        }

        private static bool EsTipoTextoSQLite(
            string tipo)
        {
            string t =
                (tipo ?? "")
                    .Trim()
                    .ToUpperInvariant();

            // SQLite admite afinidad flexible.
            // Consideramos texto si explícitamente declara
            // CHAR / CLOB / TEXT / VARCHAR.
            return
                t.Contains("CHAR") ||
                t.Contains("CLOB") ||
                t.Contains("TEXT") ||
                t.Contains("VARCHAR");
        }

        private static bool PareceColumnaUnidad(
            string nombre)
        {
            if (string.IsNullOrWhiteSpace(
                nombre))
            {
                return false;
            }

            string n =
                nombre
                    .Trim()
                    .ToLowerInvariant();

            return
                n.Contains("unidad") ||
                n.Contains("medida") ||
                n == "um" ||
                n == "u_medida" ||
                n.Contains("abreviatura") ||
                n.Contains("simbolo");
        }

        private static string BuscarColumnaUnidadTexto(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "unidad_costo",
                "unidad",
                "unidad_medida",
                "unidad_medida_costo",
                "abreviatura_unidad",
                "simbolo_unidad",
                "abreviatura",
                "simbolo",
                "um"
            };

            // 1. Coincidencia exacta + tipo texto.
            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase) &&
                            EsTipoTextoSQLite(
                                x.Tipo));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            // 2. Cualquier columna de unidad,
            // siempre que sea de tipo texto.
            ColumnaSQLiteInfo candidata =
                columnas.FirstOrDefault(
                    x =>
                        PareceColumnaUnidad(
                            x.Nombre) &&
                        EsTipoTextoSQLite(
                            x.Tipo) &&
                        !x.Nombre.StartsWith(
                            "id_",
                            StringComparison.OrdinalIgnoreCase));

            return
                candidata?.Nombre;
        }

        private static string BuscarColumnaIdUnidad(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "id_unidad",
                "id_unidadmedida",
                "id_unidad_medida",
                "id_unidad_costo",
                "idunidad",
                "unidad_id",
                "unidadmedida_id"
            };

            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            return
                columnas
                    .FirstOrDefault(
                        x =>
                            PareceColumnaUnidad(
                                x.Nombre) &&
                            (
                                x.Nombre.StartsWith(
                                    "id_",
                                    StringComparison.OrdinalIgnoreCase) ||
                                x.Nombre.EndsWith(
                                    "_id",
                                    StringComparison.OrdinalIgnoreCase)
                            ))
                    ?.Nombre;
        }

        private class RelacionUnidadSQLite
        {
            public string TablaDestino { get; set; }
            public string ColumnaOrigen { get; set; }
            public string ColumnaDestino { get; set; }
        }

        private static RelacionUnidadSQLite
            BuscarRelacionForeignKey(
                DbConnection connection,
                string tablaOrigen,
                string columnaOrigen)
        {
            if (string.IsNullOrWhiteSpace(
                columnaOrigen))
            {
                return null;
            }

            using (
                DbCommand command =
                    connection.CreateCommand())
            {
                command.CommandText =
                    "PRAGMA foreign_key_list(" +
                    EscaparIdentificadorSQLite(
                        tablaOrigen) +
                    ");";

                using (
                    DbDataReader reader =
                        command.ExecuteReader())
                {
                    int idxTabla =
                        reader.GetOrdinal(
                            "table");

                    int idxFrom =
                        reader.GetOrdinal(
                            "from");

                    int idxTo =
                        reader.GetOrdinal(
                            "to");

                    while (
                        reader.Read())
                    {
                        string from =
                            LeerTexto(
                                reader,
                                idxFrom);

                        if (!string.Equals(
                            from,
                            columnaOrigen,
                            StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        return
                            new RelacionUnidadSQLite()
                            {
                                TablaDestino =
                                    LeerTexto(
                                        reader,
                                        idxTabla),

                                ColumnaOrigen =
                                    from,

                                ColumnaDestino =
                                    LeerTexto(
                                        reader,
                                        idxTo)
                            };
                    }
                }
            }

            return null;
        }

        private static string BuscarColumnaDescripcionUnidad(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "simbolo",
                "abreviatura",
                "abreviacion",
                "abreviatura_unidad",
                "unidad",
                "unidad_medida",
                "nombre_unidad",
                "descripcion_unidad",
                "nombre",
                "descripcion"
            };

            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase) &&
                            EsTipoTextoSQLite(
                                x.Tipo));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            return
                columnas
                    .FirstOrDefault(
                        x =>
                            EsTipoTextoSQLite(
                                x.Tipo) &&
                            !x.Nombre.StartsWith(
                                "id_",
                                StringComparison.OrdinalIgnoreCase))
                    ?.Nombre;
        }

        private static List<string>
            LeerNombresTablas(
                DbConnection connection)
        {
            var resultado =
                new List<string>();

            using (
                DbCommand command =
                    connection.CreateCommand())
            {
                command.CommandText =
                    @"SELECT name
                      FROM sqlite_master
                      WHERE type = 'table'
                        AND name NOT LIKE 'sqlite_%'
                      ORDER BY name;";

                using (
                    DbDataReader reader =
                        command.ExecuteReader())
                {
                    int idxNombre =
                        reader.GetOrdinal(
                            "name");

                    while (
                        reader.Read())
                    {
                        string nombre =
                            LeerTexto(
                                reader,
                                idxNombre);

                        if (!string.IsNullOrWhiteSpace(
                            nombre))
                        {
                            resultado.Add(
                                nombre);
                        }
                    }
                }
            }

            return resultado;
        }

        private static bool PareceTablaUnidad(
            string tabla)
        {
            if (string.IsNullOrWhiteSpace(
                tabla))
            {
                return false;
            }

            string t =
                tabla
                    .Trim()
                    .ToLowerInvariant();

            return
                t.Contains("unidad") ||
                t.Contains("medida");
        }

        private static string BuscarColumnaClaveUnidad(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "id_unidad",
                "id_unidadmedida",
                "id_unidad_medida",
                "idunidad",
                "codigo_unidad",
                "codigo",
                "id"
            };

            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            return
                columnas
                    .FirstOrDefault(
                        x =>
                            x.Nombre.StartsWith(
                                "id_",
                                StringComparison.OrdinalIgnoreCase) ||
                            x.Nombre.EndsWith(
                                "_id",
                                StringComparison.OrdinalIgnoreCase))
                    ?.Nombre;
        }

        private static string ResolverUnidadPorTablaHeuristica(
            DbConnection connection,
            string aliasOrigen,
            string tablaOrigen)
        {
            string idUnidad =
                BuscarColumnaIdUnidad(
                    connection,
                    tablaOrigen);

            if (string.IsNullOrWhiteSpace(
                idUnidad))
            {
                return null;
            }

            List<string> tablasUnidad =
                LeerNombresTablas(
                    connection)
                    .Where(
                        PareceTablaUnidad)
                    .OrderBy(x => string.Equals(x, "unidad", StringComparison.OrdinalIgnoreCase) ? 0 : 1)
                    .ToList();

            var expresiones = new List<string>();

            foreach (
                string tablaUnidad
                in tablasUnidad)
            {
                string clave =
                    BuscarColumnaClaveUnidad(
                        connection,
                        tablaUnidad);

                string descripcion =
                    BuscarColumnaDescripcionUnidad(
                        connection,
                        tablaUnidad);

                if (string.IsNullOrWhiteSpace(
                        clave) ||
                    string.IsNullOrWhiteSpace(
                        descripcion))
                {
                    continue;
                }

                expresiones.Add(
                    "(SELECT " +
                    "NULLIF(NULLIF(TRIM(CAST(u." +
                    EscaparIdentificadorSQLite(
                        descripcion) +
                    " AS TEXT)), ''), '0') " +
                    "FROM " +
                    EscaparIdentificadorSQLite(
                        tablaUnidad) +
                    " u " +
                    "WHERE CAST(u." +
                    EscaparIdentificadorSQLite(
                        clave) +
                    " AS TEXT) = CAST(" +
                    aliasOrigen +
                    "." +
                    EscaparIdentificadorSQLite(
                        idUnidad) +
                    " AS TEXT) " +
                    "LIMIT 1)");
            }

            // Una base puede contener catálogos de varias aplicaciones con claves
            // distintas. Usar la primera coincidencia de la fila, no la primera tabla.
            return expresiones.Count == 0 ? null : expresiones.Count == 1
                ? expresiones[0] : "COALESCE(" + string.Join(", ", expresiones) + ")";
        }

        private static string ResolverUnidadDesdeTablaRelacionada(
            DbConnection connection,
            string aliasOrigen,
            string tablaOrigen)
        {
            string idUnidad =
                BuscarColumnaIdUnidad(
                    connection,
                    tablaOrigen);

            if (string.IsNullOrWhiteSpace(
                idUnidad))
            {
                return null;
            }

            RelacionUnidadSQLite relacion =
                BuscarRelacionForeignKey(
                    connection,
                    tablaOrigen,
                    idUnidad);

            if (relacion != null &&
                !string.IsNullOrWhiteSpace(
                    relacion.TablaDestino))
            {
                string descripcion =
                    BuscarColumnaDescripcionUnidad(
                        connection,
                        relacion.TablaDestino);

                string columnaDestino =
                    !string.IsNullOrWhiteSpace(
                        relacion.ColumnaDestino)
                    ? relacion.ColumnaDestino
                    : BuscarColumnaClaveUnidad(
                        connection,
                        relacion.TablaDestino);

                if (!string.IsNullOrWhiteSpace(
                    descripcion) &&
                    !string.IsNullOrWhiteSpace(
                    columnaDestino))
                {
                    return
                        "(SELECT " +
                        "NULLIF(NULLIF(TRIM(CAST(u." +
                        EscaparIdentificadorSQLite(
                            descripcion) +
                        " AS TEXT)), ''), '0') " +
                        "FROM " +
                        EscaparIdentificadorSQLite(
                            relacion.TablaDestino) +
                        " u " +
                        "WHERE CAST(u." +
                        EscaparIdentificadorSQLite(
                            columnaDestino) +
                        " AS TEXT) = CAST(" +
                        aliasOrigen +
                        "." +
                        EscaparIdentificadorSQLite(
                            idUnidad) +
                        " AS TEXT) " +
                        "LIMIT 1)";
                }
            }

            // Muchas bases SQLite no declaran FOREIGN KEY.
            // Intentar relación por nombres/esquema.
            return
                ResolverUnidadPorTablaHeuristica(
                    connection,
                    aliasOrigen,
                    tablaOrigen);
        }

        private static string ResolverExpresionUnidadSql(
            DbConnection connection)
        {
            var expresiones =
                new List<string>();

            // =======================================
            // 1. TEXTO DIRECTO costo_unitario
            // =======================================
            string directaCosto =
                BuscarColumnaUnidadTexto(
                    connection,
                    "costo_unitario");

            if (!string.IsNullOrWhiteSpace(
                directaCosto))
            {
                expresiones.Add(
                    "NULLIF(NULLIF(TRIM(CAST(cu." +
                    EscaparIdentificadorSQLite(
                        directaCosto) +
                    " AS TEXT)), ''), '0')");
            }

            // =======================================
            // 2. TEXTO DIRECTO analisis_costo
            // =======================================
            string directaAnalisis =
                BuscarColumnaUnidadTexto(
                    connection,
                    "analisis_costo");

            if (!string.IsNullOrWhiteSpace(
                directaAnalisis))
            {
                expresiones.Add(
                    "NULLIF(NULLIF(TRIM(CAST(ac." +
                    EscaparIdentificadorSQLite(
                        directaAnalisis) +
                    " AS TEXT)), ''), '0')");
            }

            // =======================================
            // 3. RELACIÓN unidad costo_unitario
            //    con FK o heurística.
            // =======================================
            string relacionadaCosto =
                ResolverUnidadDesdeTablaRelacionada(
                    connection,
                    "cu",
                    "costo_unitario");

            if (!string.IsNullOrWhiteSpace(
                relacionadaCosto))
            {
                expresiones.Add(
                    relacionadaCosto);
            }

            // =======================================
            // 4. RELACIÓN unidad analisis_costo
            // =======================================
            string relacionadaAnalisis =
                ResolverUnidadDesdeTablaRelacionada(
                    connection,
                    "ac",
                    "analisis_costo");

            if (!string.IsNullOrWhiteSpace(
                relacionadaAnalisis))
            {
                expresiones.Add(
                    relacionadaAnalisis);
            }

            // Nada encontrado.
            if (expresiones.Count == 0)
            {
                return
                    "NULL";
            }

            if (expresiones.Count == 1) return expresiones[0];

            // COALESCE toma la primera unidad válida.
            return
                "COALESCE(" +
                string.Join(
                    ", ",
                    expresiones) +
                ")";
        }

        private static string EscaparIdentificadorSQLite(
            string nombre)
        {
            if (string.IsNullOrWhiteSpace(
                nombre))
            {
                return null;
            }

            return
                "\"" +
                nombre.Replace(
                    "\"",
                    "\"\"") +
                "\"";
        }

        public static List<ItemPresupuestoDelphin>
            LeerItemsPresupuestoSQLite(
                string sqlitePath,
                string presupuestoId)
        {
            var resultado =
                new List<ItemPresupuestoDelphin>();

            using (
                DbConnection connection =
                    AbrirConexionSQLite(
                        sqlitePath))
            {
                string expresionUnidad =
                    ResolverExpresionUnidadSql(
                        connection);

                string selectUnidad =
                    ", " +
                    expresionUnidad +
                    " AS unidad_myg";

                using (
                    DbCommand command =
                        connection.CreateCommand())
                {
                    command.CommandText =
                        @"
                        SELECT
                            cu.id_costounitario,
                            cu.id_costopadre,
                            cu.numeracion_costo,
                            cu.descripcion_costo,
                            cu.posicion_costo,

                            cu.id_analisiscosto,

                            ac.codigo_clase,
                            ac.codigo_subclase,
                            ac.codigo_listaprecio
                        " +
                        selectUnidad +
                        @"

                        FROM costo_unitario cu

                        LEFT JOIN analisis_costo ac
                            ON ac.id_analisiscosto =
                               cu.id_analisiscosto

                        WHERE
                            cu.id_presupuesto =
                            @idPresupuesto

                        ORDER BY
                            cu.posicion_costo,
                            cu.numeracion_costo;
                    ";

                    AgregarParametro(
                        command,
                        "@idPresupuesto",
                        presupuestoId);

                    using (
                        DbDataReader reader =
                            command.ExecuteReader())
                    {
                        int idxAnalisis = reader.GetOrdinal("id_analisiscosto");
                        int idxId =
                            reader.GetOrdinal(
                                "id_costounitario");

                        int idxPadre =
                            reader.GetOrdinal(
                                "id_costopadre");

                        int idxItem =
                            reader.GetOrdinal(
                                "numeracion_costo");

                        int idxDescripcion =
                            reader.GetOrdinal(
                                "descripcion_costo");

                        int idxPosicion =
                            reader.GetOrdinal(
                                "posicion_costo");

                        int idxCodigoDelphin =
                            reader.GetOrdinal(
                                "codigo_listaprecio");

                        int idxUnidad =
                            reader.GetOrdinal(
                                "unidad_myg");

                        while (
                            reader.Read())
                        {
                            string id =
                                LeerTexto(
                                    reader,
                                    idxId);

                            if (string.IsNullOrWhiteSpace(
                                id))
                            {
                                continue;
                            }

                            resultado.Add(
                                new ItemPresupuestoDelphin()
                                {
                                    Id = id,
                                    IdInternoDelphin = id,
                                    IdAnalisisDelphin = LeerTexto(reader, idxAnalisis),
                                    Origen = "DELPHIN",
                                    Estado = "OFICIAL",

                                    ParentId =
                                        LeerTexto(
                                            reader,
                                            idxPadre),

                                    Item =
                                        LeerTexto(
                                            reader,
                                            idxItem),

                                    Descripcion =
                                        LeerTexto(
                                            reader,
                                            idxDescripcion),

                                    CodigoDelphin =
                                        LeerTexto(
                                            reader,
                                            idxCodigoDelphin),

                                    Unidad =
                                        NormalizarUnidad(
                                            LeerTexto(
                                                reader,
                                                idxUnidad)),

                                    // Datos BIM:
                                    // se llenan desde interfaz/JSON.
                                    Plantilla =
                                        null,

                                    Parametro =
                                        null,

                                    Regla =
                                        null,

                                    Valor =
                                        null,

                                    Posicion =
                                        LeerEntero(
                                            reader,
                                            idxPosicion)
                                });
                        }
                    }
                }
            }

            return
                resultado;
        }

        private static string NormalizarUnidad(
            string unidad)
        {
            string valor =
                (unidad ?? "")
                    .Trim();

            if (string.IsNullOrWhiteSpace(
                valor))
            {
                return null;
            }

            if (valor == "0" ||
                valor == "0.0" ||
                valor == "0,0")
            {
                return null;
            }

            return valor;
        }

                // Lee los análisis disponibles en la base completa, incluyendo los que
        // no están utilizados en el presupuesto seleccionado. Solo lectura.
        public static List<MYGPartidaCatalogo> LeerCatalogoPartidasSQLite(string sqlitePath)
        {
            using (DbConnection connection = AbrirConexionSQLite(sqlitePath))
            {
                var columnas = LeerColumnasTabla(connection, "analisis_costo");
                if (!columnas.Any(c => string.Equals(c.Nombre, "id_analisiscosto", StringComparison.OrdinalIgnoreCase)))
                    throw new InvalidDataException("Esta base no contiene la tabla de análisis de Delphin esperada (analisis_costo). " +
                        "Conecta una base que incluya el catálogo de partidas.");
                string descripcion = BuscarColumnaCatalogo(columnas, new[]
                { "descripcion_analisiscosto", "descripcion_analisis", "descripcion_analisis_costo", "descripcion_costo",
                    "nombre_analisiscosto", "nombre_analisis", "descripcion", "nombre" }, "descripcion");
                if (descripcion == null) descripcion = BuscarColumnaCatalogo(columnas,
                    new[] { "nombre_costo", "nombre_costounitario" }, "nombre");
                string codigo = BuscarColumnaCatalogo(columnas,
                    new[] { "codigo_listaprecio", "codigo_analisis", "codigo_analisiscosto", "codigo" }, null);
                bool tieneCosto = LeerColumnasTabla(connection, "costo_unitario")
                    .Any(c => string.Equals(c.Nombre, "id_analisiscosto", StringComparison.OrdinalIgnoreCase));
                string descAc = descripcion == null ? "NULL" : "NULLIF(TRIM(CAST(ac." + EscaparIdentificadorSQLite(descripcion) + " AS TEXT)), '')";
                string descCu = tieneCosto ? "NULLIF(TRIM(CAST(cu.descripcion_costo AS TEXT)), '')" : "NULL";
                string codigoSql = codigo == null ? "NULL" : "CAST(ac." + EscaparIdentificadorSQLite(codigo) + " AS TEXT)";
                string unidadSql;
                if (tieneCosto) unidadSql = ResolverExpresionUnidadSql(connection);
                else
                {
                    string texto = BuscarColumnaUnidadTexto(connection, "analisis_costo");
                    string relacionada = ResolverUnidadDesdeTablaRelacionada(connection, "ac", "analisis_costo");
                    var unidades = new List<string>();
                    if (texto != null) unidades.Add("NULLIF(TRIM(CAST(ac." + EscaparIdentificadorSQLite(texto) + " AS TEXT)), '')");
                    if (!string.IsNullOrWhiteSpace(relacionada)) unidades.Add(relacionada);
                    unidadSql = unidades.Count == 0 ? "NULL" : unidades.Count == 1 ? unidades[0] : "COALESCE(" + string.Join(",", unidades) + ")";
                }
                string join = tieneCosto ? @"
                    LEFT JOIN costo_unitario cu ON cu.id_costounitario = (
                        SELECT cu2.id_costounitario FROM costo_unitario cu2
                        WHERE cu2.id_analisiscosto = ac.id_analisiscosto
                        ORDER BY cu2.id_costounitario LIMIT 1)
                    " : "";
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT ac.id_analisiscosto AS id_catalogo, " + codigoSql + " AS codigo, " +
                        "COALESCE(" + descAc + ", " + descCu + ") AS descripcion, " + unidadSql + " AS unidad_myg " +
                        "FROM analisis_costo ac " + join + " ORDER BY codigo, descripcion, ac.id_analisiscosto;";
                    var resultado = new List<MYGPartidaCatalogo>();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string id = LeerTexto(reader, 0); if (string.IsNullOrWhiteSpace(id)) continue;
                            string desc = LeerTexto(reader, 2);
                            if (string.IsNullOrWhiteSpace(desc)) continue; // Una referencia sin descripción no sirve como partida seleccionable.
                            resultado.Add(new MYGPartidaCatalogo { Id = id, Codigo = LeerTexto(reader, 1), Descripcion = desc,
                                Unidad = NormalizarUnidad(LeerTexto(reader, 3)), RutaSQLite = sqlitePath });
                        }
                    }
                    return resultado;
                }
            }
        }

        private static string BuscarColumnaCatalogo(List<ColumnaSQLiteInfo> columnas, string[] preferidas, string prefijo)
        {
            foreach (string nombre in preferidas)
            {
                var c = columnas.FirstOrDefault(x => string.Equals(x.Nombre, nombre, StringComparison.OrdinalIgnoreCase));
                if (c != null) return c.Nombre;
            }
            return prefijo == null ? null : columnas.FirstOrDefault(c =>
                c.Nombre.StartsWith(prefijo, StringComparison.OrdinalIgnoreCase))?.Nombre;
        }

        private static DbConnection AbrirConexionSQLite(
            string sqlitePath)
        {
            SQLiteDependencyBootstrapper.Initialize();

            if (string.IsNullOrWhiteSpace(sqlitePath))
                throw new ArgumentException("La ruta SQLite está vacía.");

            if (!File.Exists(sqlitePath))
                throw new FileNotFoundException("No existe la base SQLite.", sqlitePath);

            Assembly sqliteAssembly =
                SQLiteDependencyBootstrapper.MicrosoftDataSqliteAssembly;

            if (sqliteAssembly == null)
                throw new InvalidOperationException("Microsoft.Data.Sqlite no está cargado.");

            Type connectionType =
                sqliteAssembly.GetType(
                    "Microsoft.Data.Sqlite.SqliteConnection",
                    true);

            var builder = new DbConnectionStringBuilder();
            builder["Data Source"] = Path.GetFullPath(sqlitePath);
            builder["Mode"] = "ReadOnly";
            builder["Pooling"] = false;
            string connectionString = builder.ConnectionString;

            object connectionObject =
                Activator.CreateInstance(
                    connectionType,
                    connectionString);

            DbConnection connection =
                connectionObject as DbConnection;

            if (connection == null)
                throw new InvalidCastException("No se pudo convertir SqliteConnection a DbConnection.");

            connection.Open();

            return connection;
        }

        private static void AgregarParametro(
            DbCommand command,
            string nombre,
            object valor)
        {
            DbParameter parametro =
                command.CreateParameter();

            parametro.ParameterName = nombre;
            parametro.Value = valor ?? DBNull.Value;

            command.Parameters.Add(parametro);
        }

        private static string LeerTexto(
            DbDataReader reader,
            int index)
        {
            if (reader.IsDBNull(index))
                return null;

            return reader.GetValue(index)?.ToString();
        }

        private static int LeerEntero(
            DbDataReader reader,
            int index)
        {
            if (reader.IsDBNull(index))
                return 0;

            object valor = reader.GetValue(index);

            if (valor == null)
                return 0;

            if (int.TryParse(
                valor.ToString(),
                out int resultado))
            {
                return resultado;
            }

            return 0;
        }
}
}
