using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace MYG_2027;

public sealed class MYGDatosProyecto
{
    public string PropietarioId { get; set; }
    public string Propietario { get; set; }
    public string PortafolioId { get; set; }
    public string Portafolio { get; set; }
    public string TipoObraId { get; set; }
    public string TipoObra { get; set; }
    public string DepartamentoId { get; set; }
    public string Departamento { get; set; }
    public string ProvinciaId { get; set; }
    public string Provincia { get; set; }
    public string DistritoId { get; set; }
    public string Distrito { get; set; }
    public string LocalidadId { get; set; }
    public string Localidad { get; set; }
    public bool UsarUbicacion { get; set; }
    public DateTime? FechaElaboracion { get; set; }
    public DateTime? FechaInicio { get; set; }
    public DateTime? FechaFin { get; set; }
    public decimal Duracion { get; set; } = 1;
    public string UnidadDuracion { get; set; } = "MESES";
    public int? CalendarioId { get; set; }
    public string Calendario { get; set; } = "Predeterminado";
    public string Periodos { get; set; } = "Estándar";
    public string ModalidadEjecucion { get; set; } = "C";
    public bool PorRendimientoCuadrilla { get; set; } = true;
    public bool PorAsignacionRecursos { get; set; }
    public string HechoPor { get; set; }
    public string FirmaImportada { get; set; }

    public static MYGDatosProyecto Crear()
    {
        var datos = new MYGDatosProyecto
        {
            FechaElaboracion = DateTime.Today, FechaInicio = DateTime.Today,
            TipoObra = "Edificaciones", Portafolio = "Construcción"
        };
        datos.CalcularFin();
        return datos;
    }

    public void Validar()
    {
        if (Duracion <= 0 || Duracion > 100000)
            throw new InvalidDataException("La duración debe ser mayor que cero y no superar 100 000 unidades.");
        UnidadCanonica(UnidadDuracion);
        if (ModalidadEjecucion != "C" && ModalidadEjecucion != "A")
            throw new InvalidDataException("Seleccione una modalidad de ejecución válida.");
        if (PorRendimientoCuadrilla == PorAsignacionRecursos)
            throw new InvalidDataException("Seleccione una sola forma de análisis: rendimiento de cuadrilla o asignación de recursos.");
        if (FechaInicio.HasValue && FechaFin.HasValue && FechaFin.Value.Date < FechaInicio.Value.Date)
            throw new InvalidDataException("La fecha final no puede ser anterior a la fecha de inicio.");
        if (CalendarioId.HasValue && CalendarioId.Value <= 0)
            throw new InvalidDataException("El calendario seleccionado no es válido.");
        if (UsarUbicacion)
        {
            if (string.IsNullOrWhiteSpace(DepartamentoId))
                throw new InvalidDataException("Seleccione un departamento para usar la ubicación del proyecto.");
            if (!string.IsNullOrWhiteSpace(DistritoId) && string.IsNullOrWhiteSpace(ProvinciaId))
                throw new InvalidDataException("Seleccione la provincia antes del distrito.");
            if (!string.IsNullOrWhiteSpace(LocalidadId) && string.IsNullOrWhiteSpace(DistritoId))
                throw new InvalidDataException("Seleccione el distrito antes de la localidad.");
        }
        foreach (string valor in new[] { Propietario, Portafolio, TipoObra, Departamento, Provincia, Distrito,
            Localidad, Calendario, Periodos, HechoPor })
            if (valor != null && (valor.Length > 2000 || valor.Any(char.IsControl)))
                throw new InvalidDataException("Los datos del proyecto contienen un texto no válido.");
    }

    public DateTime? CalcularFin()
    {
        FechaFin = FechaInicio.HasValue ? CalcularFin(FechaInicio.Value, Duracion, UnidadDuracion) : null;
        return FechaFin;
    }

    public static DateTime CalcularFin(DateTime inicio, decimal duracion, string unidadDuracion)
    {
        if (duracion <= 0 || duracion > 100000)
            throw new InvalidDataException("La duración debe ser mayor que cero y no superar 100 000 unidades.");
        inicio = inicio.Date;
        string unidad = UnidadCanonica(unidadDuracion);
        decimal dias;
        if (unidad == "MESES")
        {
            int meses = (int)decimal.Truncate(duracion);
            int disponibles = (9999 - inicio.Year) * 12 + 12 - inicio.Month;
            if (meses > disponibles) return DateTime.MaxValue.Date;
            DateTime limite = inicio.AddMonths(meses);
            decimal fraccion = duracion - meses;
            if (fraccion == 0) return limite.AddDays(-1);
            int diasMes = limite.Year == 9999 && limite.Month == 12
                ? DateTime.DaysInMonth(limite.Year, limite.Month)
                : (limite.AddMonths(1) - limite).Days;
            dias = decimal.Ceiling(fraccion * diasMes) - 1;
            return AgregarDiasLimitados(limite, dias);
        }
        dias = decimal.Ceiling(duracion * (unidad == "SEMANAS" ? 7 : 1)) - 1;
        return AgregarDiasLimitados(inicio, dias);
    }

    private static DateTime AgregarDiasLimitados(DateTime inicio, decimal dias)
    {
        decimal disponibles = (DateTime.MaxValue.Date - inicio).Days;
        return dias >= disponibles ? DateTime.MaxValue.Date : inicio.AddDays((double)dias);
    }

    internal static string UnidadCanonica(string unidad)
    {
        string valor = (unidad ?? "").Trim().ToUpperInvariant().Replace("Í", "I");
        return valor switch
        {
            "DIA" or "DIAS" => "DIAS", "SEMANA" or "SEMANAS" => "SEMANAS", "MES" or "MESES" => "MESES",
            _ => throw new InvalidDataException("La duración debe expresarse en días, semanas o meses.")
        };
    }

    internal string Firma()
    {
        var copia = MYGProyectoStorage.Copia(this);
        copia.FirmaImportada = null;
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(MYGBaseDatos.Json(copia))));
    }
}
