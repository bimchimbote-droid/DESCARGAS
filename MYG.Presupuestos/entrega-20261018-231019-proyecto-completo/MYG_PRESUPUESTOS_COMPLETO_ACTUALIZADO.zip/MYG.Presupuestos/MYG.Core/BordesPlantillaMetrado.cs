using System;
using System.Linq;

namespace MYG_2027;

/// <summary>Delimita el cuerpo de la plantilla sin vincular su formato a la celda elegida como total.</summary>
public static class MYGBordesPlantillaMetrado
{
    public static bool Contiene(MYGHojaMetrado hoja, int fila, int columna)
    {
        string rango = ObtenerRango(hoja);
        if (string.IsNullOrEmpty(rango)) return false;
        string[] extremos = rango.Split(':');
        var inicio = MYGHojaCalculo.Coordenadas(extremos[0]);
        var fin = MYGHojaCalculo.Coordenadas(extremos[^1]);
        return fila >= inicio.Fila && fila <= fin.Fila && columna >= inicio.Columna && columna <= fin.Columna;
    }

    public static string ObtenerRango(MYGHojaMetrado hoja)
    {
        if (hoja == null) return "";
        if (hoja.RangoCuerpoPlantilla != null) return hoja.RangoCuerpoPlantilla;
        // Una hoja importada no tiene identidad de plantilla. Sus bordes se
        // toman de las celdas, sin dibujar encima una cuadrícula adicional.
        if (hoja.IdPlantilla is not (MYGPlantillasMetrado.Estandar or MYGPlantillasMetrado.Aceros) || hoja.Celdas == null)
            return "";
        var descripcion = Unica(hoja, "Descripción");
        if (!descripcion.HasValue) return "";
        var cabecera = descripcion.Value;
        int primera = cabecera.Fila + 1, ultima, derecha;
        if (hoja.IdPlantilla == MYGPlantillasMetrado.Estandar)
        {
            var resumen = Unica(hoja, "Total:");
            var parcial = Unica(hoja, "Parcial");
            if (!resumen.HasValue || !parcial.HasValue || resumen.Value.Columna != cabecera.Columna ||
                parcial.Value.Fila != cabecera.Fila || parcial.Value.Columna <= cabecera.Columna)
                return "";
            // La leyenda y la suma reales permiten recuperar hojas guardadas
            // tras una eliminación anterior, aunque CeldaTotal sea otra celda.
            string total = MYGHojaCalculo.Columna(parcial.Value.Columna) + resumen.Value.Fila;
            if (!hoja.Celdas.TryGetValue(total, out var celda) ||
                celda?.Contenido?.StartsWith("=SUM(", StringComparison.OrdinalIgnoreCase) != true) return "";
            ultima = resumen.Value.Fila - 1;
            string[] titulos = ["Descripción", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Parcial", "Plano / Referencia"];
            derecha = hoja.Celdas.Where(x => MYGHojaCalculo.Coordenadas(x.Key).Fila == cabecera.Fila &&
                    titulos.Contains(x.Value?.Contenido?.Trim(), StringComparer.OrdinalIgnoreCase))
                .Max(x => MYGHojaCalculo.Coordenadas(x.Key).Columna);
            foreach (string combinado in hoja.RangosCombinados ?? [])
            {
                string[] extremos = combinado.Split(':');
                var a = MYGHojaCalculo.Coordenadas(extremos[0]);
                var b = MYGHojaCalculo.Coordenadas(extremos[^1]);
                if (a.Fila != cabecera.Fila - 1 || b.Fila != a.Fila || a.Columna < cabecera.Columna ||
                    !hoja.Celdas.TryGetValue(extremos[0], out var titulo) ||
                    titulo.Contenido is not ("Datos" or "Dimensiones" or "Total")) continue;
                derecha = Math.Max(derecha, b.Columna);
            }
        }
        else
        {
            var resumen = Unica(hoja, "Longitud total x Ø");
            var referencia = Unica(hoja, "Id - Plano");
            if (!resumen.HasValue || !referencia.HasValue || resumen.Value.Columna != cabecera.Columna ||
                referencia.Value.Fila != cabecera.Fila || referencia.Value.Columna <= cabecera.Columna)
                return "";
            ultima = resumen.Value.Fila - 1;
            derecha = referencia.Value.Columna;
            string izquierda = MYGHojaCalculo.Columna(cabecera.Columna);
            if (!Etiqueta(hoja, izquierda + (ultima + 2), "Peso (kg/m)") ||
                !Etiqueta(hoja, izquierda + (ultima + 3), "Peso Total (kg)")) return "";
        }
        if (ultima < primera || ultima > hoja.Filas || derecha > hoja.Columnas) return "";
        return MYGHojaCalculo.Columna(cabecera.Columna) + primera + ":" + MYGHojaCalculo.Columna(derecha) + ultima;
    }

    private static (int Fila, int Columna)? Unica(MYGHojaMetrado hoja, string texto)
    {
        var encontradas = hoja.Celdas.Where(x => x.Value?.Negrita == true &&
            string.Equals(x.Value.Contenido?.Trim(), texto, StringComparison.OrdinalIgnoreCase)).Take(2).ToArray();
        return encontradas.Length == 1 ? MYGHojaCalculo.Coordenadas(encontradas[0].Key) : null;
    }

    private static bool Etiqueta(MYGHojaMetrado hoja, string direccion, string texto) =>
        hoja.Celdas.TryGetValue(direccion, out var celda) && string.Equals(celda?.Contenido?.Trim(), texto, StringComparison.OrdinalIgnoreCase);
}
