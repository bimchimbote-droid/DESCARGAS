using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGConceptoPie { GastosGenerales, Utilidad, IGV, OtrosImpuestos }

public sealed class MYGFilaResumenPie
{
    public string Id { get; set; }
    public string Nombre { get; set; }
    public decimal? Porcentaje { get; set; }
    public decimal Importe { get; set; }
    public bool Editable { get; set; }
    public MYGConceptoPie? Concepto { get; set; }
}

public sealed class MYGIncidenciaCosto
{
    public string Nombre { get; set; }
    public decimal Importe { get; set; }
    public decimal Porcentaje { get; set; }
}

public static class MYGPiePresupuesto
{
    public const string IdCostoDirecto = "costo-directo";
    public const string IdTotal = "total";
    private static readonly HashSet<string> idsPredeterminados = new(StringComparer.OrdinalIgnoreCase)
    { IdCostoDirecto, "gastos-generales", "utilidad", "parcial", "igv", "otros-impuestos", IdTotal };
    private static readonly HashSet<string> identificadoresReservados = new(StringComparer.OrdinalIgnoreCase)
    { "CD", "COSTODIRECTO", "ACUMULADO" };

    public static bool EsPieDelphin(MYGPresupuestoDocumento p) =>
        p?.Costos.PieDelphin != null && p.Costos.PiePersonalizado == null;

    public static bool EsPieUnicoDelphin(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        MYGPieDelphin.Unico(presupuestos.Select(MYGMotorPresupuestos.CrearCalculo).ToList());

    public static void AplicarPorcentajeDelphin(IEnumerable<MYGPresupuestoDocumento> presupuestos, string idFila, decimal porcentaje)
    {
        ValidarPorcentaje(porcentaje);
        var originales = presupuestos.ToList(); Moneda(originales);
        var copias = originales.Select(MYGProyectoStorage.Copia).ToList();
        foreach (var p in copias)
        {
            var fila = EsPieDelphin(p) ? p.Costos.PieDelphin.Filas.FirstOrDefault(f => MYGPieDelphin.Id(f) == idFila) : null;
            if (fila?.Tipo is not ("C" or "X")) throw new InvalidOperationException("La fila Delphin seleccionada no admite un porcentaje.");
            fila.Porcentaje = porcentaje;
            MYGProyectoStorage.ValidarPresupuesto(p); MYGMotorPresupuestos.Resumen(p);
        }
        for (int n = 0; n < originales.Count; n++) originales[n].Costos.PieDelphin = copias[n].Costos.PieDelphin;
    }

    public static MYGModoFilaResumen ModoEfectivo(MYGFilaPiePersonalizada fila) =>
        fila.Modo ?? (fila.Base == MYGBaseFilaPie.Acumulado ? MYGModoFilaResumen.OtrosGastos : MYGModoFilaResumen.GastoConSustento);

    public static bool EsPorcentual(MYGFilaPiePersonalizada fila) =>
        ModoEfectivo(fila) is MYGModoFilaResumen.GastoConSustento or MYGModoFilaResumen.OtrosGastos;

    public static decimal EvaluarFormula(string formula, decimal costoDirecto, decimal acumulado,
        IReadOnlyDictionary<string, decimal> anteriores = null)
    {
        var variables = Variables(costoDirecto, acumulado);
        if (anteriores != null)
            foreach (var par in anteriores)
            {
                if (!MYGFormulaFilaResumen.EsIdentificador(par.Key) || identificadoresReservados.Contains(par.Key) || !variables.TryAdd(par.Key, par.Value))
                    throw new InvalidDataException("El identificador '" + par.Key + "' es inválido, duplicado o reservado.");
            }
        return MYGFormulaFilaResumen.Resolver(formula, variables, true);
    }

    private static Dictionary<string, decimal> Variables(decimal costoDirecto, decimal acumulado) =>
        new(StringComparer.OrdinalIgnoreCase)
        { ["CD"] = costoDirecto, ["COSTODIRECTO"] = costoDirecto, ["ACUMULADO"] = acumulado };

    private static void ValidarPorcentaje(decimal valor)
    {
        if (valor < 0 || valor > 10000 || decimal.Round(valor, 4) != valor)
            throw new InvalidDataException("El porcentaje debe estar entre 0 y 10000 y tener como máximo cuatro decimales.");
    }

    internal static void ValidarFilas(List<MYGFilaPiePersonalizada> filas)
    {
        if (filas == null) return;
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var variables = Variables(0, 0);
        foreach (var fila in filas)
        {
            if (fila == null || string.IsNullOrWhiteSpace(fila.Id) || !ids.Add(fila.Id) || idsPredeterminados.Contains(fila.Id))
                throw new InvalidDataException("El pie contiene una fila sin identidad, duplicada o reservada.");
            if (string.IsNullOrWhiteSpace(fila.Nombre) || !Enum.IsDefined(fila.Base) || !Enum.IsDefined(fila.Tipo) ||
                (fila.Modo.HasValue && !Enum.IsDefined(fila.Modo.Value)))
                throw new InvalidDataException("Indique el nombre, tipo y modo válidos para cada fila del pie.");
            ValidarPorcentaje(fila.Porcentaje);
            if (fila.Modo is MYGModoFilaResumen.OtrosGastos or MYGModoFilaResumen.Formula)
                MYGFormulaFilaResumen.Resolver(fila.Formula, variables, false);
            if (fila.Identificador != null)
            {
                if (!MYGFormulaFilaResumen.EsIdentificador(fila.Identificador) ||
                    identificadoresReservados.Contains(fila.Identificador) || !variables.TryAdd(fila.Identificador, 0))
                    throw new InvalidDataException("El identificador '" + fila.Identificador + "' es inválido, duplicado o reservado. Use letras, números y guion bajo; comience por una letra o guion bajo.");
            }
        }
    }

    private static List<MYGFilaPiePersonalizada> CopiarFilas(List<MYGFilaPiePersonalizada> filas) =>
        filas?.Select(f => new MYGFilaPiePersonalizada
        { Id = f.Id, Nombre = f.Nombre, Porcentaje = f.Porcentaje, Base = f.Base,
            Tipo = f.Tipo, Identificador = f.Identificador, Modo = f.Modo, Formula = f.Formula, ValorManual = f.ValorManual }).ToList();

    public static string Moneda(IEnumerable<MYGPresupuestoDocumento> presupuestos)
    {
        var monedas = presupuestos.Select(p => p.Costos.Moneda.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (monedas.Count > 1) throw new InvalidOperationException("El proyecto contiene monedas distintas. Seleccione un presupuesto para ver su resumen.");
        return monedas.FirstOrDefault() ?? "S/";
    }

    public static decimal Porcentaje(MYGPresupuestoDocumento p, MYGConceptoPie concepto) => concepto switch
    {
        MYGConceptoPie.GastosGenerales => p.Costos.GastosGeneralesPorcentaje,
        MYGConceptoPie.Utilidad => p.Costos.UtilidadPorcentaje,
        MYGConceptoPie.IGV => p.Costos.ImpuestoPorcentaje,
        MYGConceptoPie.OtrosImpuestos => p.Costos.OtrosImpuestosPorcentaje,
        _ => throw new ArgumentOutOfRangeException(nameof(concepto))
    };

    private static void Asignar(MYGPresupuestoDocumento p, MYGConceptoPie concepto, decimal valor)
    {
        switch (concepto)
        {
            case MYGConceptoPie.GastosGenerales: p.Costos.GastosGeneralesPorcentaje = valor; break;
            case MYGConceptoPie.Utilidad: p.Costos.UtilidadPorcentaje = valor; break;
            case MYGConceptoPie.IGV: p.Costos.ImpuestoPorcentaje = valor; break;
            case MYGConceptoPie.OtrosImpuestos: p.Costos.OtrosImpuestosPorcentaje = valor; break;
            default: throw new ArgumentOutOfRangeException(nameof(concepto));
        }
    }

    // Se comprueban todos los presupuestos antes de modificar el primero.
    public static void AplicarPorcentaje(IEnumerable<MYGPresupuestoDocumento> presupuestos, MYGConceptoPie concepto, decimal valor)
    {
        ValidarPorcentaje(valor);
        var originales = presupuestos.ToList(); Moneda(originales);
        if (originales.Any(p => p.Costos.PiePersonalizado != null || EsPieDelphin(p)))
            throw new InvalidOperationException("Restaure el resumen predeterminado para editar sus porcentajes.");
        foreach (var original in originales)
        {
            var trabajo = MYGProyectoStorage.Copia(original); Asignar(trabajo, concepto, valor);
            MYGProyectoStorage.ValidarPresupuesto(trabajo); MYGMotorPresupuestos.Resumen(trabajo);
        }
        foreach (var p in originales) Asignar(p, concepto, valor);
    }

    // Las cuatro tasas del pie predeterminado se conservan, aunque no se
    // aplican mientras exista PiePersonalizado. Restaurar recupera esas tasas.
    public static void Limpiar(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        EstablecerPersonalizado(presupuestos, new List<MYGFilaPiePersonalizada>());

    public static void RestaurarPredeterminado(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        EstablecerPersonalizado(presupuestos, null);

    public static string NombreCostoDirecto(MYGPresupuestoDocumento presupuesto) =>
        presupuesto.Costos.ConfiguracionCostoDirecto?.Nombre ??
        (EsPieDelphin(presupuesto) ? presupuesto.Costos.PieDelphin.NombreCostoDirecto : "Costo directo");

    public static void ConfigurarCostoDirecto(IEnumerable<MYGPresupuestoDocumento> presupuestos, MYGConfiguracionCostoDirecto configuracion)
    {
        var originales = presupuestos.ToList(); Moneda(originales);
        foreach (var original in originales)
        {
            var trabajo = MYGProyectoStorage.Copia(original);
            trabajo.Costos.ConfiguracionCostoDirecto = MYGProyectoStorage.Copia(configuracion);
            MYGProyectoStorage.ValidarPresupuesto(trabajo); MYGMotorPresupuestos.Resumen(trabajo);
        }
        foreach (var original in originales)
            original.Costos.ConfiguracionCostoDirecto = MYGProyectoStorage.Copia(configuracion);
    }

    public static void EstablecerPersonalizado(IEnumerable<MYGPresupuestoDocumento> presupuestos, List<MYGFilaPiePersonalizada> filas)
    {
        var originales = presupuestos.ToList();
        ValidarPersonalizado(originales, filas);
        foreach (var original in originales)
        { original.Costos.PiePersonalizado = CopiarFilas(filas); original.Costos.PieDelphin = null; }
    }

    // El editor puede validar el pie completo en todos los presupuestos sin guardar cambios.
    public static void ValidarPersonalizado(IEnumerable<MYGPresupuestoDocumento> presupuestos, List<MYGFilaPiePersonalizada> filas)
    {
        ValidarFilas(filas);
        var originales = presupuestos.ToList(); Moneda(originales);
        var plantilla = CopiarFilas(filas);
        foreach (var original in originales)
        {
            var trabajo = MYGProyectoStorage.Copia(original);
            trabajo.Costos.PiePersonalizado = CopiarFilas(plantilla);
            trabajo.Costos.PieDelphin = null;
            MYGProyectoStorage.ValidarPresupuesto(trabajo); MYGMotorPresupuestos.Resumen(trabajo);
        }
    }

    internal static List<MYGFilaResumenPie> CalcularPersonalizado(MYGPresupuestoDocumento p, decimal costoDirecto)
    {
        ValidarFilas(p.Costos.PiePersonalizado);
        var filas = new List<MYGFilaResumenPie>
        { new() { Id = IdCostoDirecto, Nombre = NombreCostoDirecto(p), Importe = costoDirecto } };
        decimal acumulado = costoDirecto;
        var variables = Variables(costoDirecto, acumulado);
        foreach (var fila in p.Costos.PiePersonalizado)
        {
            variables["ACUMULADO"] = acumulado;
            decimal importe;
            try
            {
                decimal bruto = fila.Modo switch
                {
                    MYGModoFilaResumen.GastoConSustento => costoDirecto * fila.Porcentaje / 100m,
                    MYGModoFilaResumen.OtrosGastos => MYGFormulaFilaResumen.Resolver(fila.Formula, variables, true) * fila.Porcentaje / 100m,
                    MYGModoFilaResumen.ValorManual => fila.ValorManual,
                    MYGModoFilaResumen.Formula => MYGFormulaFilaResumen.Resolver(fila.Formula, variables, true),
                    _ => (fila.Base == MYGBaseFilaPie.CostoDirecto ? costoDirecto : acumulado) * fila.Porcentaje / 100m
                };
                importe = MYGMotorPresupuestos.Dinero(p, bruto);
                acumulado += importe;
            }
            catch (OverflowException ex)
            { throw new InvalidDataException("El importe de '" + fila.Nombre + "' excede el rango decimal permitido.", ex); }
            filas.Add(new() { Id = fila.Id, Nombre = fila.Nombre, Porcentaje = EsPorcentual(fila) ? fila.Porcentaje : null,
                Importe = importe, Editable = EsPorcentual(fila) });
            if (fila.Identificador != null) variables.Add(fila.Identificador, importe);
        }
        return filas;
    }

    private static List<MYGFilaResumenPie> FilasPresupuesto(MYGCalculoPresupuesto calculo)
    {
        var p = calculo.Presupuesto; var r = calculo.Resumen();
        if (p.Costos.PiePersonalizado != null)
        {
            var propias = CalcularPersonalizado(p, r.CostoDirecto);
            if (p.Costos.MostrarTotalPiePersonalizado)
                propias.Add(new() { Id = IdTotal, Nombre = "Total", Importe = r.Total });
            return propias;
        }
        if (EsPieDelphin(p))
        {
            var nativas = MYGPieDelphin.Calcular(p.Costos.PieDelphin, r.CostoDirecto).Filas;
            nativas[0].Nombre = NombreCostoDirecto(p);
            return nativas;
        }
        return new()
        {
            new() { Id = IdCostoDirecto, Nombre = NombreCostoDirecto(p), Importe = r.CostoDirecto },
            new() { Id = "gastos-generales", Nombre = "Gastos generales", Porcentaje = p.Costos.GastosGeneralesPorcentaje,
                Importe = r.GastosGenerales, Editable = true, Concepto = MYGConceptoPie.GastosGenerales },
            new() { Id = "utilidad", Nombre = "Utilidad", Porcentaje = p.Costos.UtilidadPorcentaje,
                Importe = r.Utilidad, Editable = true, Concepto = MYGConceptoPie.Utilidad },
            new() { Id = "parcial", Nombre = "Parcial", Importe = r.Subtotal },
            new() { Id = "igv", Nombre = "I.G.V.", Porcentaje = p.Costos.ImpuestoPorcentaje,
                Importe = r.Impuesto, Editable = true, Concepto = MYGConceptoPie.IGV },
            new() { Id = "otros-impuestos", Nombre = "Otros impuestos", Porcentaje = p.Costos.OtrosImpuestosPorcentaje,
                Importe = r.OtrosImpuestos, Editable = true, Concepto = MYGConceptoPie.OtrosImpuestos },
            new() { Id = IdTotal, Nombre = "Total", Importe = r.Total }
        };
    }

    public static List<MYGFilaResumenPie> Filas(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        Filas(presupuestos.Select(MYGMotorPresupuestos.CrearCalculo));

    public static List<MYGFilaResumenPie> Filas(IEnumerable<MYGCalculoPresupuesto> calculos)
    {
        var valores = calculos.ToList(); Moneda(valores.Select(c => c.Presupuesto));
        if (MYGPieDelphin.Unico(valores)) return MYGPieDelphin.CalcularUnico(valores).Filas;
        var resultado = new List<MYGFilaResumenPie>();
        var porId = new Dictionary<string, MYGFilaResumenPie>(StringComparer.OrdinalIgnoreCase);
        var apariciones = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var definiciones = new Dictionary<string, MYGFilaPiePersonalizada>(StringComparer.OrdinalIgnoreCase);
        foreach (var calculo in valores)
        {
            var filas = FilasPresupuesto(calculo);
            var propias = calculo.Presupuesto.Costos.PiePersonalizado?.ToDictionary(f => f.Id, StringComparer.OrdinalIgnoreCase);
            foreach (var fila in filas)
            {
                var definicion = propias?.GetValueOrDefault(fila.Id);
                if (!porId.TryGetValue(fila.Id, out var agregado))
                {
                    agregado = new MYGFilaResumenPie { Id = fila.Id, Nombre = fila.Nombre, Porcentaje = fila.Porcentaje,
                        Editable = fila.Editable, Concepto = fila.Concepto };
                    porId.Add(fila.Id, agregado); resultado.Add(agregado); apariciones.Add(fila.Id, 0);
                    definiciones.Add(fila.Id, definicion);
                }
                apariciones[fila.Id]++;
                agregado.Importe += fila.Importe;
                if (agregado.Porcentaje != fila.Porcentaje) agregado.Porcentaje = null;
                if (agregado.Nombre != fila.Nombre) agregado.Editable = false;
                if (!MismaDefinicion(definiciones[fila.Id], definicion))
                { agregado.Editable = false; agregado.Porcentaje = null; }
            }
        }
        foreach (var fila in resultado)
            if (apariciones[fila.Id] != valores.Count) { fila.Porcentaje = null; fila.Editable = false; }
        // En un alcance mixto, el Total visible incluye también los pies
        // personalizados que no contienen por sí mismos una fila Total.
        if (porId.TryGetValue(IdTotal, out var total))
        {
            total.Importe = valores.Sum(c => c.Resumen().Total);
            resultado.Remove(total); resultado.Add(total);
        }
        if (porId.TryGetValue("parcial", out var parcial)) parcial.Importe = valores.Sum(c => c.Resumen().Subtotal);
        return resultado;
    }

    private static bool MismaDefinicion(MYGFilaPiePersonalizada a, MYGFilaPiePersonalizada b)
    {
        if (a == null || b == null) return a == b;
        return a.Base == b.Base && ModoEfectivo(a) == ModoEfectivo(b) && a.Tipo == b.Tipo &&
            string.Equals(a.Identificador, b.Identificador, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(a.Formula?.Trim(), b.Formula?.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    public static MYGResumenCostos Resumen(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        Resumen(presupuestos.Select(MYGMotorPresupuestos.CrearCalculo));

    public static MYGResumenCostos Resumen(IEnumerable<MYGCalculoPresupuesto> calculos)
    {
        var valores = calculos.ToList(); Moneda(valores.Select(c => c.Presupuesto)); var total = new MYGResumenCostos();
        if (MYGPieDelphin.Unico(valores)) return MYGPieDelphin.CalcularUnico(valores).Resumen;
        foreach (var calculo in valores)
        {
            var r = calculo.Resumen();
            total.CostoDirecto += r.CostoDirecto; total.GastosGenerales += r.GastosGenerales;
            total.Utilidad += r.Utilidad; total.Subtotal += r.Subtotal;
            total.Impuesto += r.Impuesto; total.OtrosImpuestos += r.OtrosImpuestos; total.Total += r.Total;
        }
        return total;
    }

    public static List<MYGIncidenciaCosto> Incidencia(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        Incidencia(presupuestos.Select(MYGMotorPresupuestos.CrearCalculo));

    public static List<MYGIncidenciaCosto> Incidencia(IEnumerable<MYGCalculoPresupuesto> calculos)
    {
        var valores = calculos.ToList(); Moneda(valores.Select(c => c.Presupuesto));
        var importes = new decimal[5];
        bool redondearAlFinal = false;
        foreach (var calculo in valores)
        {
            var p = calculo.Presupuesto;
            var bruto = new decimal[5]; var directo = calculo.Resumen().CostoDirecto;
            foreach (var i in calculo.Consolidar())
            {
                if (i.Clave == "REDONDEO") continue;
                int grupo = i.Clave.StartsWith("DIRECTO:", StringComparison.Ordinal) ? 4 : i.Grupo switch
                { MYGGrupoRecurso.ManoObra => 0, MYGGrupoRecurso.Materiales => 1, MYGGrupoRecurso.Equipo => 2, _ => 3 };
                bruto[grupo] += i.Total;
            }
            // El consolidado puede diferir del parcial nativo por redondeos. Se
            // conserva la proporción del desglose y se concilia al costo directo real.
            decimal suma = bruto.Sum();
            if (suma <= 0) { importes[4] += directo; continue; }
            var partidas = p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i)).ToList();
            if (partidas.Any(i => i.Costos.Analisis.Count > 0) &&
                partidas.All(i => i.Costos.Analisis.Count == 0 || calculo.ConservaRecursosDelphin(i)))
            {
                // Delphin consolida el importe de cada recurso sin redistribuir
                // diferencias contra el costo directo redondeado por partida.
                for (int n = 0; n < importes.Length; n++) importes[n] += bruto[n];
                redondearAlFinal = true;
                continue;
            }
            decimal escala = 1; for (int n = 0; n < p.Costos.DecimalesPrecio; n++) escala *= 10;
            var ideal = bruto.Select(v => v * directo / suma).ToArray();
            var repartido = ideal.Select(v => decimal.Truncate(v * escala) / escala).ToArray();
            var orden = Enumerable.Range(0, bruto.Length).OrderByDescending(n => ideal[n] - repartido[n]).ToArray();
            decimal pendiente = directo - repartido.Sum(); int siguiente = 0;
            while (pendiente > 0)
            { decimal unidad = Math.Min(pendiente, 1m / escala); repartido[orden[siguiente++ % orden.Length]] += unidad; pendiente -= unidad; }
            for (int n = 0; n < importes.Length; n++) importes[n] += repartido[n];
        }
        string[] nombres = { "MANO DE OBRA", "MATERIALES", "EQUIPO", "SUBCONTRATOS", "SIN DESGLOSE" };
        decimal costo = redondearAlFinal ? valores.Sum(c => c.Resumen().CostoDirecto) : importes.Sum();
        int decimales = valores.Select(c => c.Presupuesto.Costos.DecimalesPrecio).DefaultIfEmpty(2).Max();
        return importes.Select((v, n) => new MYGIncidenciaCosto
        { Nombre = nombres[n], Importe = redondearAlFinal ? decimal.Round(v, decimales, MidpointRounding.AwayFromZero) : v,
            Porcentaje = costo == 0 ? 0 : decimal.Round(v * 100m / costo, 4, MidpointRounding.AwayFromZero) })
            .Where((v, n) => n < 4 || v.Importe != 0).ToList();
    }
}
