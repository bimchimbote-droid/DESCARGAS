using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace MYG_2027;

internal static partial class DelphinImportacionMYG
{
    private static void LeerPieDelphin(Lectura lectura, string proyectoId, MYGPresupuestoDocumento presupuesto)
    {
        var filas = lectura.Filas("titulo_pie", new[] { "id_titulo", "descripcion_titulo", "posicion_titulo",
            "tipo_titulo", "porcentaje_titulo", "costo_titulo", "formula", "clave", "seccion_titulo" },
            "id_presupuesto", presupuesto.Id)
            .Where(f => string.IsNullOrEmpty(f.Texto("seccion_titulo")) || Igual(f.Texto("seccion_titulo"), "N"))
            .OrderBy(f => f.Entero("posicion_titulo")).ThenBy(f => f.Entero("id_titulo")).ToList();
        if (filas.Count == 0) return;
        var proyecto = lectura.Filas("proyecto", new[] { "tipo_gasto", "label_costo_directo" }, "id_proyecto", proyectoId).FirstOrDefault();
        presupuesto.Costos.PieDelphin = new()
        {
            ProyectoId = proyectoId,
            UnicoPorProyecto = Igual(proyecto?.Texto("tipo_gasto"), "PR"),
            NombreCostoDirecto = Nombre(proyecto?.Texto("label_costo_directo"), "Costo Directo"),
            // Delphin usa importes monetarios de dos decimales en titulo_pie;
            // decimales_costo=0 del proyecto es una opción de presentación del ACU.
            Decimales = 2,
            Filas = filas.Select(f => new MYGFilaPieDelphin
            {
                IdTitulo = f.Texto("id_titulo"), Nombre = f.Texto("descripcion_titulo"), Clave = f.Texto("clave"),
                Posicion = f.Entero("posicion_titulo"), Tipo = f.Texto("tipo_titulo").ToUpperInvariant(),
                Seccion = Nombre(f.Texto("seccion_titulo"), "N"), Porcentaje = f.Numero("porcentaje_titulo"),
                Valor = f.Numero("costo_titulo"), Formula = f.Texto("formula")
            }).ToList()
        };
        MYGPieDelphin.Validar(presupuesto.Costos.PieDelphin);
    }
}

// El lenguaje nativo se traduce al analizador aritmético de MYG: los corchetes
// sólo identifican variables y nunca ejecutan expresiones SQL ni código externo.
internal static class MYGPieDelphin
{
    internal static string Id(MYGFilaPieDelphin fila) => "delphin:" + fila.Clave;

    private static string Formula(string formula) => Regex.Replace(formula ?? "", @"\[([A-Za-z_][A-Za-z_0-9]*)\]", "$1");

    private static string ClaveImporte(string clave) => clave.ToLowerInvariant() switch
    {
        "porcentaje_gsgs" or "porcentaje_gasto" => "monto_gsgs",
        "porcentaje_utilidad" => "monto_utilidad",
        "porcentaje_igv" => "monto_igv",
        "porcentaje_impuestootro" => "monto_impuestootro",
        "porcentaje_supervision" => "monto_supervision",
        _ => clave
    };

    private static Dictionary<string, decimal> Variables(decimal directo) => new(StringComparer.OrdinalIgnoreCase)
    {
        ["costo_directo"] = directo, ["CD"] = directo, ["COSTODIRECTO"] = directo, ["ACUMULADO"] = directo,
        ["monto_gsgs"] = 0, ["monto_gasto"] = 0, ["monto_utilidad"] = 0,
        ["monto_igv"] = 0, ["monto_impuestootro"] = 0, ["monto_supervision"] = 0
    };

    internal static void Validar(MYGConfiguracionPieDelphin pie)
    {
        if (pie == null) return;
        if (pie.Decimales < 0 || pie.Decimales > 6 || string.IsNullOrWhiteSpace(pie.NombreCostoDirecto) ||
            pie.UnicoPorProyecto && string.IsNullOrWhiteSpace(pie.ProyectoId) || pie.Filas == null || pie.Filas.Count > 1000)
            throw new InvalidDataException("La configuración del pie Delphin no es válida.");
        var claves = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var variables = Variables(0);
        foreach (var fila in pie.Filas)
        {
            if (fila == null || string.IsNullOrWhiteSpace(fila.Nombre) || !MYGFormulaFilaResumen.EsIdentificador(fila.Clave) ||
                !claves.Add(fila.Clave) || fila.Clave.Equals("costo_directo", StringComparison.OrdinalIgnoreCase) ||
                fila.Clave.Equals("CD", StringComparison.OrdinalIgnoreCase) || fila.Clave.Equals("COSTODIRECTO", StringComparison.OrdinalIgnoreCase) ||
                fila.Clave.Equals("ACUMULADO", StringComparison.OrdinalIgnoreCase) ||
                fila.Tipo is not ("C" or "X" or "V" or "F") || fila.Porcentaje < 0 || fila.Porcentaje > 10000)
                throw new InvalidDataException("El pie Delphin contiene una fila, clave, tipo o porcentaje no válido.");
            if (fila.Tipo is "X" or "F")
                MYGFormulaFilaResumen.Resolver(Formula(fila.Formula), variables, false);
            variables[fila.Clave] = 0;
            variables[ClaveImporte(fila.Clave)] = 0;
            if (ClaveImporte(fila.Clave) == "monto_gsgs") variables["monto_gasto"] = 0;
        }
    }

    internal static bool Unico(IReadOnlyList<MYGCalculoPresupuesto> valores) => valores.Count > 0 &&
        valores.All(v => v.Presupuesto.Costos.PiePersonalizado == null && v.Presupuesto.Costos.PieDelphin?.UnicoPorProyecto == true) &&
        valores.Select(v => v.Presupuesto.Costos.PieDelphin.ProyectoId).Distinct(StringComparer.OrdinalIgnoreCase).Count() == 1;

    internal static (List<MYGFilaResumenPie> Filas, MYGResumenCostos Resumen) Calcular(MYGConfiguracionPieDelphin pie, decimal directo)
    {
        Validar(pie);
        decimal Redondear(decimal valor) => decimal.Round(valor, pie.Decimales, MidpointRounding.AwayFromZero);
        var filas = new List<MYGFilaResumenPie>
        { new() { Id = MYGPiePresupuesto.IdCostoDirecto, Nombre = pie.NombreCostoDirecto, Importe = directo } };
        var variables = Variables(directo);
        decimal acumulado = directo;
        decimal? subtotal = null;
        foreach (var fila in pie.Filas)
        {
            decimal importe;
            try
            {
                importe = Redondear(fila.Tipo switch
                {
                    "C" => directo * fila.Porcentaje / 100m,
                    "X" => MYGFormulaFilaResumen.Resolver(Formula(fila.Formula), variables, true) * fila.Porcentaje / 100m,
                    "V" => fila.Valor,
                    _ => MYGFormulaFilaResumen.Resolver(Formula(fila.Formula), variables, true)
                });
                // Una fórmula muestra un subtotal o total ya calculado. Sumarla
                // de nuevo duplicaría el costo directo y todos sus conceptos.
                acumulado = fila.Tipo == "F" ? importe : acumulado + importe;
            }
            catch (Exception ex) when (ex is InvalidDataException or OverflowException)
            { throw new InvalidDataException("No se pudo calcular la fila Delphin '" + fila.Nombre + "': " + ex.Message, ex); }
            variables[fila.Clave] = importe;
            variables[ClaveImporte(fila.Clave)] = importe;
            if (ClaveImporte(fila.Clave) == "monto_gsgs") variables["monto_gasto"] = importe;
            variables["ACUMULADO"] = acumulado;
            if (fila.Clave.Equals("user_sub_total", StringComparison.OrdinalIgnoreCase) || fila.Clave.Equals("parcial_presupuesto", StringComparison.OrdinalIgnoreCase)) subtotal = importe;
            filas.Add(new()
            {
                Id = Id(fila), Nombre = fila.Nombre, Importe = importe,
                Porcentaje = fila.Tipo is "C" or "X" ? fila.Porcentaje : null,
                Editable = fila.Tipo is "C" or "X"
            });
        }
        var resumen = new MYGResumenCostos
        {
            CostoDirecto = directo,
            GastosGenerales = variables["monto_gsgs"], Utilidad = variables["monto_utilidad"],
            Impuesto = variables.GetValueOrDefault("user_igv", variables["monto_igv"]),
            OtrosImpuestos = variables["monto_impuestootro"], Total = acumulado
        };
        resumen.Subtotal = subtotal ?? directo + resumen.GastosGenerales + resumen.Utilidad;
        if (pie.Filas.LastOrDefault()?.Tipo == "F") filas[^1].Id = MYGPiePresupuesto.IdTotal;
        return (filas, resumen);
    }

    internal static (List<MYGFilaResumenPie> Filas, MYGResumenCostos Resumen) CalcularUnico(IReadOnlyList<MYGCalculoPresupuesto> valores)
    {
        var primero = valores.OrderBy(v => v.Presupuesto.Posicion).First();
        var resultado = Calcular(primero.Presupuesto.Costos.PieDelphin, valores.Sum(v => v.Resumen().CostoDirecto));
        resultado.Filas[0].Nombre = MYGPiePresupuesto.NombreCostoDirecto(primero.Presupuesto);
        return resultado;
    }
}
