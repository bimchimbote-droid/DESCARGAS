using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("MYG.Pruebas")]
