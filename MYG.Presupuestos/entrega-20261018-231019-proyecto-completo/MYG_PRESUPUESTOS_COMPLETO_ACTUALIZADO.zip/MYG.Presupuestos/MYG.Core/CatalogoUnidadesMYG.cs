using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

public sealed class MYGUnidadCatalogo
{
    public string Id { get; set; }
    public string Simbolo { get; set; }
    public string Descripcion { get; set; }
    public string Tipo { get; set; } = "N";
    public string TipoDescripcion => Tipo switch
    {
        "G" => "Global", "H" => "Hora de trabajo", "D" => "Día de trabajo", "P" => "Porcentaje", _ => "General"
    };
    public bool EsCostoUnitario { get; set; } = true;
    public bool EsGastoGeneral { get; set; } = true;
    public List<MYGGrupoRecurso> TiposCosto { get; set; } = Enum.GetValues<MYGGrupoRecurso>().ToList();
    public string Codigo { get => Simbolo; set => Simbolo = value; }
    public string SimboloVisible => MYGCatalogoUnidades.SimboloVisible(Simbolo);
    public override string ToString() => SimboloVisible + " · " + Descripcion;
}

public static class MYGCatalogoUnidades
{
    internal const string Esquema = "CREATE TABLE catalogo_unidad(id TEXT PRIMARY KEY COLLATE NOCASE," +
        "simbolo TEXT NOT NULL COLLATE NOCASE,descripcion TEXT NOT NULL);";

    private static readonly (string Simbolo, string Descripcion)[] Basicas =
    {
        ("und", "Unidad"), ("m", "Metro"), ("m²", "Metro cuadrado"), ("m³", "Metro cúbico"),
        ("kg", "Kilogramo"), ("t", "Tonelada"), ("l", "Litro"), ("glb", "Global"),
        ("hh", "Hora hombre"), ("hm", "Hora máquina"), ("día", "Día"), ("mes", "Mes"), ("Bls", "Bolsas")
    };

    // Solo cambia la presentación; las bases existentes conservan sus símbolos e identidades.
    public static string SimboloVisible(string simbolo)
    {
        string valor = simbolo?.Trim() ?? "";
        if (MYGProyectoStorage.MismaUnidad(valor, "m²")) return "m²";
        if (MYGProyectoStorage.MismaUnidad(valor, "m³")) return "m³";
        return valor;
    }

    private static string IdInicial(string simbolo) => "MYG-UNIDAD-" +
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(simbolo.Trim().ToUpperInvariant())))[..16];

    private static List<MYGUnidadCatalogo> UnidadesBasicas() => Basicas.Select(x =>
        new MYGUnidadCatalogo { Id = IdInicial(x.Simbolo), Simbolo = x.Simbolo, Descripcion = x.Descripcion }).ToList();

    private static bool ExisteTabla(SqliteConnection c, SqliteTransaction t)
    {
        using var cmd = MYGBaseDatos.Comando(c, t,
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='catalogo_unidad'");
        return Convert.ToInt64(cmd.ExecuteScalar()) != 0;
    }

    private static List<MYGUnidadCatalogo> Leer(SqliteConnection c, SqliteTransaction t)
    {
        if (!MYGBaseDatos.TieneTabla(c, t, "myg_info")) return DelphinImportacionMYG.ListarUnidades(c, t);
        // Las bases v1 se pueden consultar sin escribir una migración al abrirlas.
        var unidades = MYGBaseDatos.TieneTabla(c, t, "unidad")
            ? DelphinImportacionMYG.ListarUnidades(c, t) : new List<MYGUnidadCatalogo>();
        if (!ExisteTabla(c, t) && unidades.Count == 0) unidades = UnidadesBasicas();
        if (ExisteTabla(c, t))
        {
            using var cmd = MYGBaseDatos.Comando(c, t, "SELECT id,simbolo,descripcion FROM catalogo_unidad");
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                string id = r.GetString(0), simbolo = r.GetString(1), descripcion = r.GetString(2);
                var nativa = unidades.FirstOrDefault(u => string.Equals(u.Id, id, StringComparison.OrdinalIgnoreCase));
                // Las primeras versiones MYG guardaban una identidad propia por símbolo.
                // Se proyecta sobre una sola variante de costo, conservando las demás variantes nativas.
                nativa ??= unidades.Where(u => MYGProyectoStorage.MismaUnidad(u.Simbolo, simbolo))
                    .OrderByDescending(u => u.EsCostoUnitario).ThenBy(u => u.Tipo == "G").ThenBy(u => u.Id, StringComparer.OrdinalIgnoreCase)
                    .FirstOrDefault();
                if (nativa == null) unidades.Add(new MYGUnidadCatalogo { Id = id, Simbolo = simbolo, Descripcion = descripcion });
                else { nativa.Id = id; nativa.Simbolo = simbolo; nativa.Descripcion = descripcion; }
            }
        }
        // También se reconocen unidades que vengan de presupuestos o catálogos
        // anteriores, aunque todavía no tengan una fila propia en el catálogo.
        foreach (string simbolo in SimbolosUsados(c, t))
            if (!unidades.Any(u => MYGProyectoStorage.MismaUnidad(u.Simbolo, simbolo)))
                unidades.Add(new MYGUnidadCatalogo
                { Id = IdInicial(simbolo), Simbolo = simbolo, Descripcion = simbolo });
        return unidades.OrderBy(u => u.Simbolo, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public static List<MYGUnidadCatalogo> Listar(string ruta)
    {
        using var c = MYGBaseDatos.Abrir(ruta, false);
        return Leer(c, null);
    }

    internal static void Inicializar(SqliteConnection c, SqliteTransaction t)
    {
        var actuales = Leer(c, t);
        foreach (var unidad in UnidadesBasicas())
            if (!actuales.Any(u => MYGProyectoStorage.MismaUnidad(u.Simbolo, unidad.Simbolo)))
                MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO catalogo_unidad(id,simbolo,descripcion) VALUES($p0,$p1,$p2)",
                    unidad.Id, unidad.Simbolo, unidad.Descripcion);
        RegistrarUsadas(c, t);
    }

    internal static void InicializarHojaNueva(SqliteConnection c, SqliteTransaction t)
    {
        // Las hojas nuevas usan exclusivamente el catálogo nativo; las trece unidades
        // históricas se mantienen como respaldo para la migración de bases antiguas.
        foreach (var unidad in DelphinImportacionMYG.ListarUnidades(c, t))
            MYGBaseDatos.Ejecutar(c, t, "INSERT INTO catalogo_unidad(id,simbolo,descripcion) VALUES($p0,$p1,$p2)",
                unidad.Id, unidad.Simbolo, unidad.Descripcion);
    }

    internal static void RegistrarUsadas(SqliteConnection c, SqliteTransaction t)
    {
        var unidades = Leer(c, t);
        foreach (var unidad in unidades)
            MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO catalogo_unidad(id,simbolo,descripcion) VALUES($p0,$p1,$p2)",
                unidad.Id, unidad.Simbolo, unidad.Descripcion);
    }

    private static List<string> SimbolosUsados(SqliteConnection c, SqliteTransaction t)
    {
        using var cmd = MYGBaseDatos.Comando(c, t, """
            SELECT unidad FROM partida_presupuesto WHERE tipo<>'TITULO'
            UNION SELECT unidad FROM insumo_presupuesto
            UNION SELECT unidad FROM catalogo_partida
            UNION SELECT unidad FROM catalogo_insumo
            UNION SELECT unidad FROM catalogo_partida_nodo
            UNION SELECT unidad FROM catalogo_partida_insumo
            """);
        using var r = cmd.ExecuteReader(); var simbolos = new List<string>();
        while (r.Read())
            if (!r.IsDBNull(0) && !string.IsNullOrWhiteSpace(r.GetString(0))) simbolos.Add(r.GetString(0).Trim());
        return simbolos;
    }

    public static MYGUnidadCatalogo Guardar(string ruta, MYGUnidadCatalogo unidad)
    {
        if (unidad == null || string.IsNullOrWhiteSpace(unidad.Simbolo) || string.IsNullOrWhiteSpace(unidad.Descripcion))
            throw new InvalidDataException("Indique el símbolo y la descripción de la unidad.");
        string simbolo = unidad.Simbolo.Trim(), descripcion = unidad.Descripcion.Trim();
        if (simbolo.Length > 80 || descripcion.Length > 200 || simbolo.Any(char.IsControl) || descripcion.Any(char.IsControl))
            throw new InvalidDataException("El símbolo o la descripción de la unidad no es válido.");
        string id = string.IsNullOrWhiteSpace(unidad.Id) ? MYGProyectoStorage.NuevoId() : unidad.Id;
        using var c = MYGBaseDatos.Abrir(ruta, true); using var t = c.BeginTransaction();
        RegistrarUsadas(c, t);
        var actuales = Leer(c, t);
        var anterior = actuales.FirstOrDefault(u => string.Equals(u.Id, id, StringComparison.OrdinalIgnoreCase));
        if ((anterior == null || !MYGProyectoStorage.MismaUnidad(anterior.Simbolo, simbolo)) &&
            actuales.Any(u => !string.Equals(u.Id, id, StringComparison.OrdinalIgnoreCase) &&
            MYGProyectoStorage.MismaUnidad(u.Simbolo, simbolo)))
            throw new InvalidDataException("Ya existe una unidad con ese símbolo en el catálogo.");
        if (anterior != null && !string.Equals(anterior.Simbolo, simbolo, StringComparison.Ordinal) &&
            SimbolosUsados(c, t).Any(u => MYGProyectoStorage.MismaUnidad(u, anterior.Simbolo)))
            throw new InvalidOperationException("La unidad está usada en un proyecto o catálogo. Cree otra unidad para cambiar el símbolo.");
        if (anterior != null && !MYGProyectoStorage.MismaUnidad(anterior.Simbolo, simbolo) &&
            !MYGDelphinFormato.EliminarUnidad(c, t, anterior.Id, anterior.Simbolo))
            throw new InvalidOperationException("La unidad está usada o pertenece al catálogo nativo de Delphin. Cree otra unidad para cambiar el símbolo.");
        using (var fila = MYGBaseDatos.Comando(c, t, "SELECT 1 FROM catalogo_unidad WHERE id=$p0", id))
            if (anterior != null && string.Equals(anterior.Simbolo, simbolo, StringComparison.Ordinal) &&
                fila.ExecuteScalar() == null && MYGDelphinFormato.ActualizarDescripcionUnidad(c, t, id, descripcion))
            {
                // Una base MYG anterior puede imponer UNIQUE al símbolo. Las variantes
                // nativas siguen editándose por identidad sin reconstruir esa tabla.
                t.Commit();
                return Listar(ruta).First(u => string.Equals(u.Id, id, StringComparison.OrdinalIgnoreCase));
            }
        MYGBaseDatos.Ejecutar(c, t, "INSERT INTO catalogo_unidad(id,simbolo,descripcion) VALUES($p0,$p1,$p2) " +
            "ON CONFLICT(id) DO UPDATE SET simbolo=excluded.simbolo,descripcion=excluded.descripcion", id, simbolo, descripcion);
        MYGDelphinFormato.SincronizarUnidades(c, t, id);
        t.Commit();
        return Listar(ruta).First(u => string.Equals(u.Id, id, StringComparison.OrdinalIgnoreCase));
    }

    public static void Eliminar(string ruta, string id)
    {
        if (string.IsNullOrWhiteSpace(id)) throw new ArgumentException("Seleccione la unidad que desea eliminar.", nameof(id));
        using var c = MYGBaseDatos.Abrir(ruta, true); using var t = c.BeginTransaction();
        RegistrarUsadas(c, t);
        var unidad = Leer(c, t).FirstOrDefault(u => string.Equals(u.Id, id, StringComparison.OrdinalIgnoreCase));
        if (unidad == null) throw new InvalidOperationException("La unidad ya no existe en el catálogo.");
        if (SimbolosUsados(c, t).Any(u => MYGProyectoStorage.MismaUnidad(u, unidad.Simbolo)))
            throw new InvalidOperationException("La unidad está usada en un proyecto o catálogo y no se puede eliminar.");
        MYGBaseDatos.Ejecutar(c, t, "DELETE FROM catalogo_unidad WHERE id=$p0", id);
        if (!MYGDelphinFormato.EliminarUnidad(c, t, unidad.Id, unidad.Simbolo))
            throw new InvalidOperationException("La unidad pertenece al catálogo nativo de Delphin o está usada en sus datos y no se puede eliminar.");
        t.Commit();
    }

    internal static void Copiar(SqliteConnection origen, SqliteTransaction lectura, SqliteConnection destino, SqliteTransaction escritura,
        bool destinoNuevo)
    {
        // Guardar como conserva las descripciones y las bajas del catálogo de origen,
        // en lugar de volver a incorporar todas las unidades predeterminadas.
        MYGBaseDatos.Ejecutar(destino, escritura, "DELETE FROM catalogo_unidad");
        MYGDelphinFormato.CopiarUnidades(origen, lectura, destino, escritura, destinoNuevo);
        foreach (var unidad in Leer(origen, lectura))
            MYGBaseDatos.Ejecutar(destino, escritura, "INSERT INTO catalogo_unidad(id,simbolo,descripcion) VALUES($p0,$p1,$p2)",
                unidad.Id, unidad.Simbolo, unidad.Descripcion);
    }
}
