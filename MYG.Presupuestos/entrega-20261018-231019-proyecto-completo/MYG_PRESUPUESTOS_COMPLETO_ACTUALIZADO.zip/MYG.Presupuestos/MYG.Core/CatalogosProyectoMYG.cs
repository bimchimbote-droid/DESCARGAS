using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

public enum MYGCatalogoProyecto
{
    Propietarios, Portafolios, TiposObra, Departamentos, Provincias, Distritos, Localidades, Calendarios
}

public sealed class MYGOpcionProyecto
{
    public string Id { get; set; }
    public string Nombre { get; set; }
    public string PadreId { get; set; }
    public override string ToString() => Nombre;
}

// Los datos de proyecto usan los mismos catálogos que Delphin. Consultarlos
// nunca escribe ni migra la hoja; una nueva opción se guarda explícitamente.
public static class MYGCatalogosProyecto
{
    public const string PortafolioConstruccion = "PO0000000001";
    public const string TipoObraEdificaciones = "IN0000000001";
    public const string TipoObraViales = "IN0000000002";
    public const string TipoObraSaneamiento = "IN0000000003";

    public static List<MYGOpcionProyecto> Listar(string ruta, MYGCatalogoProyecto tipo, string padreId = null)
    {
        using var c = MYGBaseDatos.Abrir(ruta, false);
        return Listar(c, null, tipo, padreId);
    }

    internal static List<MYGOpcionProyecto> Listar(SqliteConnection c, SqliteTransaction t,
        MYGCatalogoProyecto tipo, string padreId = null)
    {
        var datos = Describir(tipo);
        bool calendario = tipo == MYGCatalogoProyecto.Calendarios;
        var lectura = calendario ? datos with { Padre = "id_proyecto" } : datos;
        // Una hoja MYG anterior puede carecer aún del esquema nativo. La lectura
        // devuelve un catálogo vacío y deja la migración para una escritura.
        if (!Compatible(c, t, lectura)) return new();
        using var cmd = MYGBaseDatos.Comando(c, t,
            "SELECT \"" + datos.Id + "\",\"" + datos.Nombre + "\"," +
            (lectura.Padre == null ? "NULL" : "\"" + lectura.Padre + "\"") + " FROM \"" + datos.Tabla + "\"");
        using var r = cmd.ExecuteReader();
        var opciones = new List<MYGOpcionProyecto>();
        string filtro = string.IsNullOrWhiteSpace(padreId) ? null : padreId.Trim();
        if (calendario && filtro != null) filtro = MYGDelphinFormato.IdNativo(filtro);
        while (r.Read())
        {
            string id = Convert.ToString(r.GetValue(0), CultureInfo.InvariantCulture);
            string nombre = r.IsDBNull(1) ? "" : Convert.ToString(r.GetValue(1), CultureInfo.InvariantCulture).Trim();
            string padre = r.IsDBNull(2) ? null : Convert.ToString(r.GetValue(2), CultureInfo.InvariantCulture).Trim();
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(nombre)) continue;
            if (calendario)
            {
                // Una obra nueva sólo puede elegir calendarios compartidos.
                // Al editar también se ofrecen los calendarios de esa obra.
                if (!string.IsNullOrWhiteSpace(padre) && !Igual(padre, filtro)) continue;
            }
            else if (datos.Padre != null && filtro != null && !Igual(padre, filtro)) continue;
            opciones.Add(new MYGOpcionProyecto { Id = id, Nombre = nombre, PadreId = padre });
        }
        return opciones.OrderBy(x => x.Nombre, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(x => x.Id, StringComparer.Ordinal).ToList();
    }

    public static MYGOpcionProyecto Guardar(string ruta, MYGCatalogoProyecto tipo, string nombre, string padreId = null)
    {
        var datos = Describir(tipo);
        nombre = (nombre ?? "").Trim();
        padreId = string.IsNullOrWhiteSpace(padreId) ? null : padreId.Trim();
        if (nombre.Length == 0) throw new ArgumentException("Indique el nombre de la opción.", nameof(nombre));
        if (nombre.Length > datos.LongitudNombre || nombre.Any(char.IsControl))
            throw new ArgumentException("El nombre admite hasta " + datos.LongitudNombre + " caracteres y no puede contener caracteres de control.", nameof(nombre));
        if (datos.TipoPadre.HasValue && padreId == null)
            throw new ArgumentException("Seleccione primero " + datos.EtiquetaPadre + ".", nameof(padreId));
        if (datos.Padre == null && padreId != null)
            throw new ArgumentException("Este catálogo no requiere una opción superior.", nameof(padreId));

        // Detectar un duplicado o una selección inválida antes de abrir para
        // escritura evita migraciones innecesarias en una base del usuario.
        using (var lectura = MYGBaseDatos.Abrir(ruta, false))
        {
            ValidarPadre(lectura, null, datos, padreId);
            var existente = Duplicado(lectura, null, tipo, nombre, padreId);
            if (existente != null) return existente;
        }
        using var c = MYGBaseDatos.Abrir(ruta, true);
        using var t = c.BeginTransaction();
        if (!Compatible(c, t, datos)) throw new InvalidDataException("Esta hoja no contiene el catálogo de proyecto esperado.");
        ValidarPadre(c, t, datos, padreId);
        var duplicado = Duplicado(c, t, tipo, nombre, padreId);
        if (duplicado != null) return duplicado;

        string id;
        if (datos.Entero)
        {
            // SQLite conserva su secuencia AUTOINCREMENT, incluso si se eliminó
            // previamente el calendario con el identificador más alto.
            using var cmd = MYGBaseDatos.Comando(c, t,
                "INSERT INTO calendario(nombre_calendario) VALUES($p0) RETURNING id_calendario", nombre);
            id = Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture);
        }
        else
        {
            id = SiguienteId(c, t, datos);
            string columnas = "\"" + datos.Id + "\",\"" + datos.Nombre + "\"";
            string valores = "$p0,$p1";
            if (datos.Padre != null) { columnas += ",\"" + datos.Padre + "\""; valores += ",$p2"; }
            MYGBaseDatos.Ejecutar(c, t, "INSERT INTO \"" + datos.Tabla + "\"(" + columnas + ") VALUES(" + valores + ")",
                id, nombre, padreId);
        }
        var opcion = new MYGOpcionProyecto { Id = id, Nombre = nombre, PadreId = padreId };
        t.Commit();
        return opcion;
    }

    // Sólo se llama al crear el esquema de una hoja nueva o al migrar una hoja
    // propia anterior. No se ejecuta cuando se abre o se adapta una base nativa.
    internal static void Inicializar(SqliteConnection c, SqliteTransaction t)
    {
        MYGBaseDatos.Ejecutar(c, t,
            "INSERT OR IGNORE INTO portafolio(id_portafolio,nombre_portafolio) VALUES($p0,'Construcción')", PortafolioConstruccion);
        foreach (var (id, nombre) in new[] { (TipoObraEdificaciones, "Edificaciones"), (TipoObraViales, "Viales"), (TipoObraSaneamiento, "Saneamiento") })
            MYGBaseDatos.Ejecutar(c, t,
                "INSERT OR IGNORE INTO infraestructura(id_infraestructura,nombre_infraestructura) VALUES($p0,$p1)", id, nombre);
        var ensamblado = typeof(MYGCatalogosProyecto).Assembly;
        string recurso = ensamblado.GetManifestResourceNames().Single(x => x.EndsWith(".GeografiaPeru.sql", StringComparison.Ordinal));
        using var stream = ensamblado.GetManifestResourceStream(recurso);
        using var lector = new StreamReader(stream, Encoding.UTF8);
        MYGBaseDatos.Ejecutar(c, t, lector.ReadToEnd());
    }

    private static MYGOpcionProyecto Duplicado(SqliteConnection c, SqliteTransaction t, MYGCatalogoProyecto tipo,
        string nombre, string padreId) => Listar(c, t, tipo, padreId).FirstOrDefault(x =>
        Igual(x.Nombre, nombre) && Igual(x.PadreId, padreId));

    private static void ValidarPadre(SqliteConnection c, SqliteTransaction t, Descripcion datos, string padreId)
    {
        if (!datos.TipoPadre.HasValue) return;
        if (!Listar(c, t, datos.TipoPadre.Value).Any(x => Igual(x.Id, padreId)))
            throw new ArgumentException("La opción superior no existe en el catálogo de " + datos.EtiquetaPadre + ".", nameof(padreId));
    }

    private static bool Compatible(SqliteConnection c, SqliteTransaction t, Descripcion datos)
    {
        using var cmd = MYGBaseDatos.Comando(c, t, "PRAGMA table_info(\"" + datos.Tabla + "\")");
        using var r = cmd.ExecuteReader();
        var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        while (r.Read()) columnas.Add(r.GetString(1));
        return columnas.Contains(datos.Id) && columnas.Contains(datos.Nombre) &&
            (datos.Padre == null || columnas.Contains(datos.Padre));
    }

    private static string SiguienteId(SqliteConnection c, SqliteTransaction t, Descripcion datos)
    {
        long ultimo = 0;
        var usados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT \"" + datos.Id + "\" FROM \"" + datos.Tabla + "\""))
        using (var r = cmd.ExecuteReader())
            while (r.Read())
            {
                string id = Convert.ToString(r.GetValue(0), CultureInfo.InvariantCulture);
                usados.Add(id);
                if (id.Length == 12 && id.StartsWith(datos.Prefijo, StringComparison.OrdinalIgnoreCase) &&
                    long.TryParse(id.AsSpan(2), NumberStyles.None, CultureInfo.InvariantCulture, out var numero))
                    ultimo = Math.Max(ultimo, numero);
            }
        while (ultimo < 9999999999L)
        {
            string id = datos.Prefijo + (++ultimo).ToString("D10", CultureInfo.InvariantCulture);
            if (!usados.Contains(id)) return id;
        }
        throw new InvalidOperationException("No quedan identificadores de catálogo disponibles.");
    }

    private static bool Igual(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);

    private sealed record Descripcion(string Tabla, string Id, string Nombre, string Prefijo, int LongitudNombre,
        string Padre = null, MYGCatalogoProyecto? TipoPadre = null, string EtiquetaPadre = null, bool Entero = false);

    private static Descripcion Describir(MYGCatalogoProyecto tipo) => tipo switch
    {
        MYGCatalogoProyecto.Propietarios => new("propietario", "id_propietario", "nombre_propietario", "PT", 120),
        MYGCatalogoProyecto.Portafolios => new("portafolio", "id_portafolio", "nombre_portafolio", "PO", 120),
        MYGCatalogoProyecto.TiposObra => new("infraestructura", "id_infraestructura", "nombre_infraestructura", "IN", 120),
        MYGCatalogoProyecto.Departamentos => new("departamento", "id_departamento", "nombre_departamento", "DE", 120),
        MYGCatalogoProyecto.Provincias => new("provincia", "id_provincia", "nombre_provincia", "PV", 40,
            "id_departamento", MYGCatalogoProyecto.Departamentos, "departamentos"),
        MYGCatalogoProyecto.Distritos => new("distrito", "id_distrito", "nombre_distrito", "DI", 120,
            "id_provincia", MYGCatalogoProyecto.Provincias, "provincias"),
        MYGCatalogoProyecto.Localidades => new("localidad", "id_localidad", "nombre_localidad", "LO", 120,
            "id_distrito", MYGCatalogoProyecto.Distritos, "distritos"),
        MYGCatalogoProyecto.Calendarios => new("calendario", "id_calendario", "nombre_calendario", "", 50, Entero: true),
        _ => throw new ArgumentOutOfRangeException(nameof(tipo), "Catálogo de proyecto no válido.")
    };
}
