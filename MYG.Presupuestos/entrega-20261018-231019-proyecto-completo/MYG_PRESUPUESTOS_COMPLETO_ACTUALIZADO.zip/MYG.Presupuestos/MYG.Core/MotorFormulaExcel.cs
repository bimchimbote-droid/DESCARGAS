using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MYG_2027
{
    internal readonly struct MYGValorExcel
    {
        private readonly object valor;
        public MYGValorExcel(decimal numero) { valor = numero; }
        public MYGValorExcel(string texto) { valor = texto ?? ""; }
        public MYGValorExcel(bool logico) { valor = logico; }
        public MYGValorExcel(Exception error) { valor = error; }
        public bool EsVacio => valor == null;
        public bool EsNumero => valor is decimal;
        public bool EsTexto => valor is string;
        public bool EsLogico => valor is bool;
        public bool EsError => valor is Exception;
        public MYGValorExcel SinError() { if (valor is Exception error) throw error; return this; }
        public bool Logico => valor is bool b ? b : Numero() != 0;
        public string Texto => valor switch { null => "", decimal n => n.ToString(CultureInfo.InvariantCulture), bool b => b ? "VERDADERO" : "FALSO", Exception error => throw error, _ => (string)valor };
        public decimal Numero()
        {
            SinError();
            if (valor == null) return 0;
            if (valor is decimal n) return n;
            if (valor is bool b) return b ? 1 : 0;
            if (MYGHojaCalculo.IntentarNumero((string)valor, out n)) return n;
            throw new FormatException("El resultado no es un número.");
        }
    }

    internal sealed class MYGErrorExcel : FormatException
    {
        public string Codigo { get; }
        public MYGErrorExcel(string codigo) : base(codigo) { Codigo = codigo; }
    }

    // Analiza la fórmula antes de evaluar. Las ramas de SI/SI.ERROR son nodos diferidos;
    // los rangos conservan vacíos, texto y dimensiones para aplicar las reglas de Excel.
    internal sealed class MYGMotorFormulaExcel
    {
        private readonly string texto;
        private readonly MYGHojaMetrado hoja;
        private readonly Func<string, MYGValorExcel> resolver;
        private readonly Func<string, string, MYGValorExcel> resolverMetrado;
        private int indice;
        private int profundidad;
        private static readonly Regex Referencia = new(@"^\$?[A-Za-z]{1,3}\$?[1-9][0-9]*$", RegexOptions.Compiled);
        private sealed class Nodo
        {
            public Func<MYGValorExcel> Evaluar { get; }
            public Func<IReadOnlyList<MYGValorExcel>> Rango { get; }
            public bool EsReferencia { get; }
            public int Filas { get; }
            public int Columnas { get; }
            public Nodo(Func<MYGValorExcel> evaluar) { Evaluar = evaluar; Filas = Columnas = 1; }
            public Nodo(Func<IReadOnlyList<MYGValorExcel>> rango, int filas, int columnas)
            {
                Rango = rango; Filas = filas; Columnas = columnas; EsReferencia = true;
                Evaluar = () => filas * columnas == 1 ? rango()[0].SinError() : throw new FormatException("Se esperaba una celda o valor individual.");
            }
            public IReadOnlyList<MYGValorExcel> Valores() => Rango != null ? Rango() : new[] { Evaluar() };
        }
        public MYGMotorFormulaExcel(string formula, MYGHojaMetrado hoja, Func<string, MYGValorExcel> resolver,
            Func<string, string, MYGValorExcel> resolverMetrado = null)
        {
            if (formula.Length > 4096) throw new FormatException("La fórmula es demasiado larga.");
            texto = MYGFuncionesExcel.AExcel(formula); if (texto.StartsWith('=')) texto = texto[1..];
            this.hoja = hoja; this.resolver = resolver; this.resolverMetrado = resolverMetrado;
        }
        public MYGValorExcel Calcular()
        {
            Nodo nodo = Comparar(); Espacios();
            if (indice != texto.Length) throw new FormatException("Fórmula no soportada cerca de: " + texto[indice..]);
            return nodo.Evaluar().SinError();
        }
        private void Espacios() { while (indice < texto.Length && char.IsWhiteSpace(texto[indice])) indice++; }
        private bool Tomar(char c) { Espacios(); if (indice < texto.Length && texto[indice] == c) { indice++; return true; } return false; }
        private static Nodo Numero(decimal valor) => new(() => new MYGValorExcel(valor));
        private Nodo Comparar()
        {
            Nodo nodo = Concatenar();
            while (true)
            {
                Espacios(); string operador = new[] { "<=", ">=", "<>", "=", "<", ">" }.FirstOrDefault(o => texto[indice..].StartsWith(o, StringComparison.Ordinal));
                if (operador == null) return nodo;
                indice += operador.Length; Nodo izquierda = nodo, derecha = Concatenar();
                nodo = new Nodo(() => new MYGValorExcel(Comparacion(izquierda.Evaluar(), derecha.Evaluar(), operador)));
            }
        }
        private Nodo Concatenar()
        {
            Nodo nodo = Sumar();
            while (Tomar('&')) { Nodo izquierda = nodo, derecha = Sumar(); nodo = new Nodo(() => new MYGValorExcel(izquierda.Evaluar().Texto + derecha.Evaluar().Texto)); }
            return nodo;
        }
        private Nodo Sumar()
        {
            Nodo nodo = Multiplicar();
            while (true)
            {
                bool resta; if (Tomar('+')) resta = false; else if (Tomar('-')) resta = true; else return nodo;
                Nodo izquierda = nodo, derecha = Multiplicar();
                nodo = new Nodo(() => new MYGValorExcel(resta ? izquierda.Evaluar().Numero() - derecha.Evaluar().Numero() : izquierda.Evaluar().Numero() + derecha.Evaluar().Numero()));
            }
        }
        private Nodo Multiplicar()
        {
            Nodo nodo = Potencia();
            while (true)
            {
                bool division; if (Tomar('*')) division = false; else if (Tomar('/')) division = true; else return nodo;
                Nodo izquierda = nodo, derecha = Potencia();
                nodo = new Nodo(() => new MYGValorExcel(division ? izquierda.Evaluar().Numero() / derecha.Evaluar().Numero() : izquierda.Evaluar().Numero() * derecha.Evaluar().Numero()));
            }
        }
        private Nodo Potencia()
        {
            Nodo Operando()
            {
                Nodo n = Atomo();
                while (Tomar('%')) { Nodo anterior = n; n = new Nodo(() => new MYGValorExcel(anterior.Evaluar().Numero() / 100m)); }
                return n;
            }
            Nodo nodo = Operando();
            while (Tomar('^')) { Nodo izquierda = nodo, derecha = Operando(); nodo = new Nodo(() => new MYGValorExcel(Elevar(izquierda.Evaluar().Numero(), derecha.Evaluar().Numero()))); }
            return nodo;
        }
        private Nodo Atomo()
        {
            if (++profundidad > 128) throw new FormatException("Fórmula demasiado profunda.");
            try
            {
                if (Tomar('+')) { Nodo n = Atomo(); return new Nodo(() => new MYGValorExcel(n.Evaluar().Numero())); }
                if (Tomar('-')) { Nodo n = Atomo(); return new Nodo(() => new MYGValorExcel(-n.Evaluar().Numero())); }
                if (Tomar('(')) { Nodo n = Comparar(); if (!Tomar(')')) throw new FormatException("Falta un paréntesis."); return n; }
                Espacios(); int inicio = indice;
                if (Tomar('"'))
                {
                    var literal = new StringBuilder(); bool cerrado = false;
                    while (indice < texto.Length)
                    {
                        char c = texto[indice++];
                        if (c != '"') literal.Append(c);
                        else if (indice < texto.Length && texto[indice] == '"') { literal.Append('"'); indice++; }
                        else { cerrado = true; break; }
                    }
                    if (!cerrado) throw new FormatException("Falta la comilla de cierre.");
                    string valor = literal.ToString(); return new Nodo(() => new MYGValorExcel(valor));
                }
                if (indice < texto.Length && texto[indice] == '#')
                {
                    string error = new[] { "#DIV/0!", "#VALUE!", "#REF!", "#NAME?", "#NUM!", "#NULL!", "#N/A", "#N/D" }.FirstOrDefault(e => texto[indice..].StartsWith(e, StringComparison.OrdinalIgnoreCase));
                    if (error == null) throw new FormatException("Error de Excel no válido.");
                    indice += error.Length; return new Nodo(() => throw new MYGErrorExcel(error == "#N/D" ? "#N/A" : error));
                }
                if (indice < texto.Length && (char.IsDigit(texto[indice]) || texto[indice] == '.'))
                {
                    while (indice < texto.Length && (char.IsDigit(texto[indice]) || texto[indice] == '.')) indice++;
                    if (indice < texto.Length && texto[indice] is 'e' or 'E')
                    { indice++; if (indice < texto.Length && texto[indice] is '+' or '-') indice++; while (indice < texto.Length && char.IsDigit(texto[indice])) indice++; }
                    if (!decimal.TryParse(texto[inicio..indice], NumberStyles.Float, CultureInfo.InvariantCulture, out decimal valor)) throw new FormatException("Número no válido en fórmula.");
                    return Numero(valor);
                }
                while (indice < texto.Length && (char.IsLetterOrDigit(texto[indice]) || texto[indice] is '$' or '_' or '.')) indice++;
                string nombre = texto[inicio..indice].ToUpperInvariant();
                if (nombre.Length == 0) throw new FormatException("Se esperaba un número, referencia o función.");
                if (!Tomar('('))
                {
                    if (nombre is "TRUE" or "FALSE") return new Nodo(() => new MYGValorExcel(nombre == "TRUE"));
                    if (!Referencia.IsMatch(nombre)) throw new FormatException("Nombre no definido: " + nombre);
                    string fin = nombre;
                    if (Tomar(':'))
                    {
                        Espacios(); int desde = indice;
                        while (indice < texto.Length && (char.IsLetterOrDigit(texto[indice]) || texto[indice] == '$')) indice++;
                        fin = texto[desde..indice]; if (!Referencia.IsMatch(fin)) throw new FormatException("Rango no válido.");
                    }
                    return CrearRango(nombre, fin);
                }
                var argumentos = new List<Nodo>();
                if (!Tomar(')'))
                {
                    while (true)
                    {
                        Espacios(); argumentos.Add(indice < texto.Length && texto[indice] is ',' or ')' ? Numero(0) : Comparar());
                        if (Tomar(')')) break;
                        if (!Tomar(',')) throw new FormatException("Faltan argumentos o cierre de función.");
                        if (argumentos.Count > 255) throw new FormatException("La función admite hasta 255 argumentos.");
                    }
                }
                return new Nodo(() => Funcion(nombre, argumentos));
            }
            finally { profundidad--; }
        }
        private Nodo CrearRango(string inicio, string fin)
        {
            var a = MYGHojaCalculo.Coordenadas(inicio); var b = MYGHojaCalculo.Coordenadas(fin);
            int f1 = Math.Min(a.Fila, b.Fila), f2 = Math.Max(a.Fila, b.Fila), c1 = Math.Min(a.Columna, b.Columna), c2 = Math.Max(a.Columna, b.Columna);
            return new Nodo(() =>
            {
                if (f2 > hoja.Filas || c2 > hoja.Columnas || (long)(f2 - f1 + 1) * (c2 - c1 + 1) > 200000) throw new MYGErrorExcel("#REF!");
                var valores = new List<MYGValorExcel>();
                for (int f = f1; f <= f2; f++) for (int c = c1; c <= c2; c++)
                    try { valores.Add(resolver(MYGHojaCalculo.Columna(c) + f)); }
                    catch (Exception e) when (EsError(e)) { valores.Add(new MYGValorExcel(e)); }
                return valores;
            }, f2 - f1 + 1, c2 - c1 + 1);
        }
        private static bool EsError(Exception e) => e is FormatException or OverflowException or DivideByZeroException;
        private static void Aridad(string nombre, IReadOnlyList<Nodo> args, int minimo, int maximo)
        { if (args.Count < minimo || args.Count > maximo) throw new FormatException("Número de argumentos incorrecto: " + nombre); }
        private static IReadOnlyList<decimal> Numeros(IReadOnlyList<Nodo> argumentos, bool contar = false)
        {
            var numeros = new List<decimal>();
            foreach (Nodo a in argumentos)
                foreach (MYGValorExcel v in a.Valores())
                {
                    if (v.EsError) { if (!contar || !a.EsReferencia) v.SinError(); continue; }
                    if (v.EsNumero) numeros.Add(v.Numero());
                    else if (!a.EsReferencia && !v.EsVacio)
                    {
                        if (!contar) numeros.Add(v.Numero());
                        else if (v.EsLogico || MYGHojaCalculo.IntentarNumero(v.Texto, out _)) numeros.Add(v.Numero());
                    }
                }
            return numeros;
        }
        private MYGValorExcel Funcion(string nombre, IReadOnlyList<Nodo> args)
        {
            decimal N(int i) => args[i].Evaluar().Numero();
            MYGValorExcel V(decimal n) => new(n);
            switch (nombre)
            {
                case "METRADO":
                    Aridad(nombre, args, 2, 2);
                    var alias = args[0].Evaluar(); var direccion = args[1].Evaluar();
                    if (!alias.EsTexto || !direccion.EsTexto) throw new FormatException("METRADO requiere el nombre de la partida y la celda entre comillas. Use Referenciar otra partida.");
                    return (resolverMetrado ?? throw new MYGErrorReferenciaMetrado("El vínculo necesita el proyecto completo."))(alias.Texto, direccion.Texto);
                case "IF":
                    Aridad(nombre, args, 2, 3);
                    return args[0].Evaluar().Logico ? args[1].Evaluar() : args.Count == 3 ? args[2].Evaluar() : new MYGValorExcel(false);
                case "IFERROR": case "IFNA":
                    Aridad(nombre, args, 2, 2);
                    try { return args[0].Evaluar().SinError(); }
                    catch (Exception e) when (EsError(e) && (nombre == "IFERROR" || e is MYGErrorExcel { Codigo: "#N/A" })) { return args[1].Evaluar(); }
                case "IFS":
                    Aridad(nombre, args, 2, 254); if (args.Count % 2 != 0) throw new FormatException("SI.CONJUNTO requiere pares de condición y valor.");
                    for (int i = 0; i < args.Count; i += 2) if (args[i].Evaluar().Logico) return args[i + 1].Evaluar();
                    throw new MYGErrorExcel("#N/A");
                case "SUM": case "PRODUCT": case "MIN": case "MAX": case "AVERAGE": case "COUNT":
                    Aridad(nombre, args, 1, 255); var numeros = Numeros(args, nombre == "COUNT");
                    return V(nombre switch
                    {
                        "SUM" => numeros.Sum(), "PRODUCT" => numeros.Count == 0 ? 0 : numeros.Aggregate(1m, (a, b) => a * b),
                        "MIN" => numeros.Count == 0 ? 0 : numeros.Min(), "MAX" => numeros.Count == 0 ? 0 : numeros.Max(),
                        "AVERAGE" => numeros.Count == 0 ? throw new DivideByZeroException() : numeros.Average(), _ => numeros.Count
                    });
                case "COUNTA": Aridad(nombre, args, 1, 255); return V(args.Sum(a => a.Valores().Count(v => !v.EsVacio)));
                case "COUNTBLANK":
                    Aridad(nombre, args, 1, 1); if (!args[0].EsReferencia) throw new FormatException("CONTAR.BLANCO requiere una celda o rango.");
                    return V(args[0].Valores().Count(v => v.EsVacio || v.EsTexto && v.Texto.Length == 0));
                case "AND": case "OR":
                    Aridad(nombre, args, 1, 255); var logicos = new List<bool>();
                    foreach (Nodo a in args) foreach (MYGValorExcel v in a.Valores())
                    {
                        v.SinError();
                        if (!a.EsReferencia || v.EsNumero || v.EsLogico) logicos.Add(v.Logico);
                    }
                    if (logicos.Count == 0) throw new FormatException("No hay valores lógicos.");
                    return new MYGValorExcel(nombre == "AND" ? logicos.All(b => b) : logicos.Any(b => b));
                case "NOT": Aridad(nombre, args, 1, 1); return new MYGValorExcel(!args[0].Evaluar().Logico);
                case "TRUE": case "FALSE": Aridad(nombre, args, 0, 0); return new MYGValorExcel(nombre == "TRUE");
                case "NA": Aridad(nombre, args, 0, 0); throw new MYGErrorExcel("#N/A");
                case "SUMIF": case "COUNTIF": case "AVERAGEIF": return ConCriterio(nombre, args);
                case "SUMIFS": case "COUNTIFS": case "AVERAGEIFS": return ConCriterios(nombre, args);
                case "SUMPRODUCT":
                    Aridad(nombre, args, 1, 255); var rangos = args.Select(a => a.Valores()).ToArray();
                    if (args.Any(a => a.Filas != args[0].Filas || a.Columnas != args[0].Columnas)) throw new FormatException("SUMAPRODUCTO requiere rangos del mismo tamaño.");
                    decimal suma = 0;
                    for (int i = 0; i < rangos[0].Count; i++) { decimal producto = 1; foreach (var rango in rangos) { rango[i].SinError(); producto *= rango[i].EsNumero ? rango[i].Numero() : 0; } suma += producto; }
                    return V(suma);
                case "PI": Aridad(nombre, args, 0, 0); return V((decimal)Math.PI);
                case "ROUND": case "ROUNDUP": case "ROUNDDOWN": case "TRUNC":
                    Aridad(nombre, args, nombre == "TRUNC" ? 1 : 2, 2); return V(Redondear(N(0), args.Count == 1 ? 0 : N(1), nombre));
                case "POWER": Aridad(nombre, args, 2, 2); return V(Elevar(N(0), N(1)));
                case "MOD": Aridad(nombre, args, 2, 2); decimal divisor = N(1); if (divisor == 0) throw new DivideByZeroException(); return V(N(0) - divisor * decimal.Floor(N(0) / divisor));
                case "QUOTIENT": Aridad(nombre, args, 2, 2); return V(decimal.Truncate(N(0) / N(1)));
                case "LOG": Aridad(nombre, args, 1, 2); return V(Real(Math.Log((double)N(0), args.Count == 1 ? 10 : (double)N(1))));
                case "ABS": case "INT": case "SIGN": case "SQRT": case "SIN": case "COS": case "TAN": case "SEC": case "SECH":
                case "SINH": case "COSH": case "TANH": case "ASIN": case "ACOS": case "ATAN": case "LN": case "LOG10": case "EXP": case "RADIANS": case "DEGREES": case "SECOND":
                    Aridad(nombre, args, 1, 1); decimal valor = N(0); double d = (double)valor;
                    return V(nombre switch
                    {
                        "ABS" => Math.Abs(valor), "INT" => decimal.Floor(valor), "SIGN" => Math.Sign(valor),
                        "SQRT" => Real(Math.Sqrt(d)), "SIN" => Real(Math.Sin(d)), "COS" => Real(Math.Cos(d)), "TAN" => Real(Math.Tan(d)),
                        "SEC" => Real(1 / Math.Cos(d)), "SECH" => Real(1 / Math.Cosh(d)), "SINH" => Real(Math.Sinh(d)), "COSH" => Real(Math.Cosh(d)),
                        "TANH" => Real(Math.Tanh(d)), "ASIN" => Real(Math.Asin(d)), "ACOS" => Real(Math.Acos(d)), "ATAN" => Real(Math.Atan(d)),
                        "LN" => Real(Math.Log(d)), "LOG10" => Real(Math.Log10(d)), "EXP" => Real(Math.Exp(d)),
                        "RADIANS" => Real(d * Math.PI / 180), "DEGREES" => Real(d * 180 / Math.PI),
                        _ => valor < 0 ? throw new FormatException("La hora no puede ser negativa.") : decimal.Floor(((valor % 1) * 86400m + 0.5m) % 60)
                    });
                default: throw new FormatException("Función no soportada: " + nombre);
            }
        }
        private static decimal Redondear(decimal numero, decimal posiciones, string tipo)
        {
            if (posiciones > 28) return numero;
            if (posiciones < -28) return tipo == "ROUNDUP" && numero != 0 ? throw new OverflowException() : 0;
            int decimales = (int)decimal.Truncate(posiciones);
            if (decimales >= 0 && tipo == "ROUND") return decimal.Round(numero, decimales, MidpointRounding.AwayFromZero);
            if (decimales >= 0 && ((decimal.GetBits(numero)[3] >> 16) & 0x7f) <= decimales) return numero;
            decimal factor = 1; for (int i = 0; i < Math.Abs(decimales); i++) factor *= 10;
            decimal escalado = decimales < 0 ? numero / factor : numero * factor;
            decimal entero = tipo switch { "ROUND" => decimal.Round(escalado, 0, MidpointRounding.AwayFromZero), "ROUNDUP" => Math.Sign(escalado) * decimal.Ceiling(Math.Abs(escalado)), _ => decimal.Truncate(escalado) };
            return decimales < 0 ? entero * factor : entero / factor;
        }
        private static decimal Elevar(decimal numero, decimal exponente)
        {
            if (numero == 0 && exponente < 0) throw new DivideByZeroException();
            if (exponente == decimal.Truncate(exponente) && Math.Abs(exponente) <= 100)
            { decimal r = 1; for (int i = 0; i < Math.Abs(exponente); i++) r *= numero; return exponente < 0 ? 1 / r : r; }
            return Real(Math.Pow((double)numero, (double)exponente));
        }
        private static decimal Real(double numero)
        { if (!double.IsFinite(numero)) throw new FormatException("Resultado numérico fuera del dominio de la función."); return (decimal)numero; }
        private static bool Comparacion(MYGValorExcel a, MYGValorExcel b, string operador)
        {
            int orden;
            if (a.EsVacio) a = b.EsTexto ? new MYGValorExcel("") : b.EsLogico ? new MYGValorExcel(false) : new MYGValorExcel(0m);
            if (b.EsVacio) b = a.EsTexto ? new MYGValorExcel("") : a.EsLogico ? new MYGValorExcel(false) : new MYGValorExcel(0m);
            if (a.EsTexto && b.EsTexto) orden = string.Compare(a.Texto, b.Texto, StringComparison.OrdinalIgnoreCase);
            else if (a.EsLogico && b.EsLogico || a.EsNumero && b.EsNumero) orden = a.Numero().CompareTo(b.Numero());
            else orden = (a.EsLogico ? 2 : a.EsTexto ? 1 : 0).CompareTo(b.EsLogico ? 2 : b.EsTexto ? 1 : 0);
            return operador switch { "=" => orden == 0, "<>" => orden != 0, "<" => orden < 0, ">" => orden > 0, "<=" => orden <= 0, _ => orden >= 0 };
        }
        private static MYGValorExcel ConCriterio(string nombre, IReadOnlyList<Nodo> args)
        {
            Aridad(nombre, args, 2, nombre == "COUNTIF" ? 2 : 3);
            Nodo comparar = args[0], sumar = args.Count == 3 ? args[2] : args[0];
            if (!comparar.EsReferencia || !sumar.EsReferencia) throw new FormatException("La función requiere rangos de celdas.");
            if (comparar.Filas != sumar.Filas || comparar.Columnas != sumar.Columnas) throw new FormatException("Los rangos deben tener el mismo tamaño.");
            var valores = comparar.Valores(); var sumandos = sumar.Valores(); var criterio = Criterio(args[1].Evaluar());
            decimal total = 0; int cantidad = 0;
            for (int i = 0; i < valores.Count; i++)
                if (!valores[i].EsError && criterio(valores[i]))
                {
                    if (nombre == "COUNTIF") cantidad++;
                    else { sumandos[i].SinError(); if (sumandos[i].EsNumero) { total += sumandos[i].Numero(); cantidad++; } }
                }
            return new MYGValorExcel(nombre == "COUNTIF" ? cantidad : nombre == "AVERAGEIF" ? cantidad == 0 ? throw new DivideByZeroException() : total / cantidad : total);
        }
        private static MYGValorExcel ConCriterios(string nombre, IReadOnlyList<Nodo> args)
        {
            bool contar = nombre == "COUNTIFS"; int inicio = contar ? 0 : 1;
            Aridad(nombre, args, contar ? 2 : 3, 255);
            if ((args.Count - inicio) % 2 != 0) throw new FormatException("Se requieren pares de rango y criterio.");
            Nodo patron = args[0]; if (!patron.EsReferencia) throw new FormatException("La función requiere rangos de celdas.");
            var rangos = new List<IReadOnlyList<MYGValorExcel>>(); var criterios = new List<Func<MYGValorExcel, bool>>();
            for (int i = inicio; i < args.Count; i += 2)
            {
                if (!args[i].EsReferencia || args[i].Filas != patron.Filas || args[i].Columnas != patron.Columnas) throw new FormatException("Los rangos deben tener el mismo tamaño.");
                rangos.Add(args[i].Valores()); criterios.Add(Criterio(args[i + 1].Evaluar()));
            }
            var sumandos = patron.Valores(); decimal suma = 0; int cantidad = 0;
            for (int i = 0; i < sumandos.Count; i++)
            {
                bool cumple = true; for (int c = 0; c < criterios.Count; c++) if (rangos[c][i].EsError || !criterios[c](rangos[c][i])) { cumple = false; break; }
                if (cumple && !contar) sumandos[i].SinError();
                if (cumple && (contar || sumandos[i].EsNumero)) { cantidad++; if (!contar) suma += sumandos[i].Numero(); }
            }
            return new MYGValorExcel(contar ? cantidad : nombre == "AVERAGEIFS" ? cantidad == 0 ? throw new DivideByZeroException() : suma / cantidad : suma);
        }
        private static Func<MYGValorExcel, bool> Criterio(MYGValorExcel criterio)
        {
            string texto = criterio.Texto;
            string operador = new[] { "<=", ">=", "<>", "=", "<", ">" }.FirstOrDefault(o => texto.StartsWith(o, StringComparison.Ordinal)) ?? "=";
            string valor = texto.StartsWith(operador, StringComparison.Ordinal) ? texto[operador.Length..] : texto;
            if (MYGHojaCalculo.IntentarNumero(valor, out decimal numero))
                return v => (v.EsNumero || v.EsVacio || v.EsTexto && MYGHojaCalculo.IntentarNumero(v.Texto, out _)) && Comparacion(new MYGValorExcel(v.Numero()), new MYGValorExcel(numero), operador);
            if (valor.Length == 0) return v => operador == "<>" ? !v.EsVacio && v.Texto.Length != 0 : v.EsVacio || v.Texto.Length == 0;
            var patron = new StringBuilder("^"); bool comodin = false;
            for (int i = 0; i < valor.Length; i++)
            {
                char c = valor[i];
                if (c == '~' && i + 1 < valor.Length) patron.Append(Regex.Escape(valor[++i].ToString()));
                else if (c == '*') { patron.Append(".*"); comodin = true; }
                else if (c == '?') { patron.Append('.'); comodin = true; }
                else patron.Append(Regex.Escape(c.ToString()));
            }
            patron.Append('$'); var regex = new Regex(patron.ToString(), RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Singleline | RegexOptions.NonBacktracking);
            if (operador is "=" or "<>")
                return v => operador == "=" ? v.EsTexto && regex.IsMatch(v.Texto) : !(v.EsTexto && regex.IsMatch(v.Texto));
            if (comodin) throw new FormatException("Los comodines requieren un criterio de igualdad.");
            return v => v.EsTexto && Comparacion(v, new MYGValorExcel(valor), operador);
        }
    }
}
