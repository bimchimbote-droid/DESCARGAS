using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public static partial class MYGReportesProyecto
{
    /// <summary>Crea la instantánea de impresión de los insumos ya filtrados.
    /// No depende de filas visibles ni de grupos contraídos del editor.</summary>
    public static MYGHojaReporteProyecto CrearListaInsumos(MYGProyectoDocumento documento,
        MYGPresupuestoDocumento presupuesto, IEnumerable<MYGInsumoContexto> insumos,
        bool proyectoCompleto = false, string tituloSeleccionado = null)
    {
        ArgumentNullException.ThrowIfNull(documento);
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(insumos);
        var seleccionado = documento.Presupuestos?.FirstOrDefault(p => p != null && p.Id == presupuesto.Id)
            ?? throw new ArgumentException("El presupuesto no pertenece al proyecto abierto.", nameof(presupuesto));
        if (seleccionado.Costos == null || string.IsNullOrWhiteSpace(seleccionado.Costos.Moneda))
            throw new InvalidDataException("Indique la moneda del presupuesto para imprimir sus insumos.");
        if (proyectoCompleto && documento.Presupuestos.Where(p => p != null)
            .Select(p => p.Costos?.Moneda?.Trim().ToUpperInvariant()).Distinct().Skip(1).Any())
            throw new InvalidDataException("La lista del proyecto contiene presupuestos con monedas distintas.");
        var filas = insumos.ToArray();
        if (filas.Any(i => i == null || !Enum.IsDefined(i.Grupo) || string.IsNullOrWhiteSpace(i.Descripcion) ||
            string.IsNullOrWhiteSpace(i.Unidad) || i.Precio < 0))
            throw new InvalidDataException("La lista contiene un insumo incompleto o con precio no válido.");
        // La hoja admite hasta 10.000 filas, incluidos encabezado, grupos y total.
        if (filas.Length + filas.Select(i => i.Grupo).Distinct().Count() + 2 > 10000)
            throw new InvalidDataException("La lista de insumos supera las 10.000 filas disponibles para imprimir.");

        var h = new MYGHojaMetrado
        {
            Nombre = "Lista de insumos", Columnas = 6, Filas = 2, CeldaTotal = "F2",
            TamanoPapel = "A4", OrientacionPagina = "Vertical",
            MargenIzquierdo = .7m, MargenDerecho = .7m, MargenSuperior = .75m, MargenInferior = .65m,
            LineasDivision = false, Encabezados = false, ImprimirLineasDivision = false,
            ImprimirEncabezados = false, RepetirTitulos = true, FilasInmovilizadas = 1,
            FormatoNumeroPredeterminado = "#,##0.00",
            AnchosColumnas = new() { [1] = 65, [2] = 315, [3] = 32, [4] = 80, [5] = 78, [6] = 90 },
            AltosFilas = new() { [1] = 26 }
        };

        void Texto(int fila, int columna, string valor, bool negrita = false, string alineacion = "Izquierda")
        {
            // Códigos con ceros iniciales y textos que empiezan por '=' son literales.
            Poner(h, fila, columna, valor ?? "", negrita);
            var celda = h.Celdas[MYGHojaCalculo.Columna(columna) + fila];
            celda.Fuente = "Arial Narrow"; celda.TamanoFuente = 9;
            celda.ColorTexto = "000000"; celda.ColorFondo = "FFFFFF";
            celda.AlineacionHorizontal = alineacion; celda.FormatoNumero = "@";
        }
        void Importe(int fila, int columna, decimal valor, bool negrita = false, bool cantidad = false)
        {
            Poner(h, fila, columna, Num(valor), negrita, cantidad ? "#,##0.0000" : "#,##0.00");
            var celda = h.Celdas[MYGHojaCalculo.Columna(columna) + fila];
            celda.Fuente = "Arial Narrow"; celda.TamanoFuente = 9;
            celda.ColorTexto = "000000"; celda.ColorFondo = "FFFFFF";
            celda.AlineacionHorizontal = "Derecha";
        }

        string[] encabezados = { "Código", "Descripción", "Unid.", "Cantidad", "Costo", "Total" };
        for (int c = 1; c <= encabezados.Length; c++)
        {
            Texto(1, c, encabezados[c - 1], true, c <= 2 ? "Izquierda" : "Centro");
            h.Celdas[MYGHojaCalculo.Columna(c) + "1"].ColorFondo = "ECEEF1";
            h.Celdas[MYGHojaCalculo.Columna(c) + "1"].Bordes = true;
        }
        int f = 2;
        foreach (var grupo in filas.GroupBy(i => i.Grupo).OrderBy(g => g.Key))
        {
            Texto(f, 2, MYGMotorPresupuestos.Grupo(grupo.Key), true);
            h.RangosCombinados.Add("B" + f + ":E" + f);
            Importe(f, 6, grupo.Sum(i => i.Total), true);
            h.AltosFilas[f++] = 24;
            foreach (var insumo in grupo)
            {
                Texto(f, 1, insumo.Codigo);
                Texto(f, 2, insumo.Descripcion);
                Texto(f, 3, insumo.Unidad, alineacion: "Centro");
                Importe(f, 4, insumo.Cantidad, cantidad: true);
                Importe(f, 5, insumo.Precio);
                Importe(f, 6, insumo.Total);
                h.AltosFilas[f++] = 20;
            }
        }
        Texto(f, 5, "TOTAL:", true, "Derecha");
        Importe(f, 6, filas.Sum(i => i.Total), true);
        h.Celdas["E" + f].ColorFondo = h.Celdas["F" + f].ColorFondo = "ECEEF1";
        h.Celdas["E" + f].Bordes = h.Celdas["F" + f].Bordes = true;
        h.AltosFilas[f] = 26;
        Terminar(h, f, 6, f);

        var datos = DatosProyecto(documento, seleccionado, proyectoCompleto).ToList();
        if (!proyectoCompleto && !string.IsNullOrWhiteSpace(tituloSeleccionado))
            datos.Add(new("Título", tituloSeleccionado.Trim()));
        var reporte = new MYGHojaReporteProyecto(proyectoCompleto ? "LISTA DE INSUMOS DEL PROYECTO" : "LISTA DE INSUMOS DEL PRESUPUESTO",
            h, datos, listaInsumos: true);
        if (h.Filas + reporte.CabeceraImpresion.Count + 3 > 10000)
            throw new InvalidDataException("La lista de insumos no deja espacio para la cabecera de exportación.");
        return reporte;
    }
}
