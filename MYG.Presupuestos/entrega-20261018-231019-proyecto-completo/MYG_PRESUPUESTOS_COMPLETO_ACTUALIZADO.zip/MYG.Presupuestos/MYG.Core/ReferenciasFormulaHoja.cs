using System;
using System.Collections.Generic;
using System.Globalization;

namespace MYG_2027
{
    /// <summary>Referencia visible de una fórmula; filas y columnas empiezan en uno.</summary>
    public sealed record MYGReferenciaFormulaHoja(
        int Inicio, int Longitud, string Rango,
        int FilaInicial, int FilaFinal, int ColumnaInicial, int ColumnaFinal, int IndiceColor);

    /// <summary>
    /// Extrae referencias locales para colorearlas durante la edición, sin evaluar la fórmula.
    /// Admite fórmulas incompletas y limita el trabajo al tamaño de una celda de Excel.
    /// </summary>
    public static class MYGReferenciasFormulaHoja
    {
        public const int MaximoReferencias = 512;
        public const int MaximoCaracteresFormula = 32767;
        private const int MaximoFilasExcel = 1048576;
        private const int MaximoColumnasExcel = 16384;

        public static IReadOnlyList<MYGReferenciaFormulaHoja> Extraer(string formula, int filas, int columnas)
        {
            if (string.IsNullOrEmpty(formula) || formula.Length > MaximoCaracteresFormula || filas <= 0 || columnas <= 0)
                return Array.Empty<MYGReferenciaFormulaHoja>();

            int posicion = SaltarEspacios(formula, 0);
            if (posicion == formula.Length || formula[posicion] != '=')
                return Array.Empty<MYGReferenciaFormulaHoja>();

            filas = Math.Min(filas, MaximoFilasExcel);
            columnas = Math.Min(columnas, MaximoColumnasExcel);
            var referencias = new List<MYGReferenciaFormulaHoja>();
            var colores = new Dictionary<string, int>(StringComparer.Ordinal);
            posicion++;
            while (posicion < formula.Length && referencias.Count < MaximoReferencias)
            {
                char caracter = formula[posicion];
                if (caracter == '"')
                {
                    posicion = SaltarTextoEntreComillas(formula, posicion, '"');
                    continue;
                }
                if (caracter == '\'')
                {
                    int fin = SaltarTextoEntreComillas(formula, posicion, '\'');
                    int siguiente = SaltarEspacios(formula, fin);
                    posicion = siguiente < formula.Length && formula[siguiente] == '!'
                        ? SaltarReferenciaCalificada(formula, siguiente + 1) : fin;
                    continue;
                }
                if (caracter == '[')
                {
                    posicion = SaltarCorchetes(formula, posicion);
                    continue;
                }
                if (caracter == '!')
                {
                    posicion = SaltarReferenciaCalificada(formula, posicion + 1);
                    continue;
                }
                if (!EsCaracterIdentificador(caracter)) { posicion++; continue; }

                int inicio = posicion;
                int finPrimero = FinIdentificador(formula, inicio);
                int siguientePrimero = SaltarEspacios(formula, finPrimero);
                if (siguientePrimero < formula.Length && formula[siguientePrimero] == '!')
                {
                    posicion = SaltarReferenciaCalificada(formula, siguientePrimero + 1);
                    continue;
                }
                posicion = finPrimero;
                if (!IntentarCelda(formula, inicio, finPrimero, out int fila1, out int columna1)) continue;
                // LOG10 y otros nombres que coinciden con una dirección son funciones.
                if (siguientePrimero < formula.Length && (formula[siguientePrimero] == '(' || formula[siguientePrimero] == '['))
                    continue;

                int finReferencia = finPrimero, fila2 = fila1, columna2 = columna1;
                if (siguientePrimero < formula.Length && formula[siguientePrimero] == ':')
                {
                    int inicioSegundo = SaltarEspacios(formula, siguientePrimero + 1);
                    if (inicioSegundo < formula.Length && formula[inicioSegundo] == '\'')
                    {
                        int finNombre = SaltarTextoEntreComillas(formula, inicioSegundo, '\'');
                        int calificador = SaltarEspacios(formula, finNombre);
                        if (calificador < formula.Length && formula[calificador] == '!')
                        {
                            posicion = SaltarReferenciaCalificada(formula, calificador + 1);
                            continue;
                        }
                    }
                    int finSegundo = FinIdentificador(formula, inicioSegundo);
                    int siguienteSegundo = SaltarEspacios(formula, finSegundo);
                    if (siguienteSegundo < formula.Length && formula[siguienteSegundo] == '!')
                    {
                        posicion = SaltarReferenciaCalificada(formula, siguienteSegundo + 1);
                        continue;
                    }
                    if (IntentarCelda(formula, inicioSegundo, finSegundo, out int ultimaFila, out int ultimaColumna))
                    {
                        fila2 = ultimaFila;
                        columna2 = ultimaColumna;
                        finReferencia = finSegundo;
                        posicion = finSegundo;
                    }
                }

                int filaInicial = Math.Min(fila1, fila2), filaFinal = Math.Max(fila1, fila2);
                int columnaInicial = Math.Min(columna1, columna2), columnaFinal = Math.Max(columna1, columna2);
                if (filaInicial > filas || columnaInicial > columnas) continue;
                filaFinal = Math.Min(filaFinal, filas);
                columnaFinal = Math.Min(columnaFinal, columnas);
                string primera = Direccion(filaInicial, columnaInicial), ultima = Direccion(filaFinal, columnaFinal);
                string rango = primera == ultima ? primera : primera + ":" + ultima;
                if (!colores.TryGetValue(rango, out int color))
                {
                    color = colores.Count;
                    colores.Add(rango, color);
                }
                referencias.Add(new MYGReferenciaFormulaHoja(inicio, finReferencia - inicio, rango,
                    filaInicial, filaFinal, columnaInicial, columnaFinal, color));
            }
            return referencias.AsReadOnly();
        }

        private static string Direccion(int fila, int columna) =>
            MYGHojaCalculo.Columna(columna) + fila.ToString(CultureInfo.InvariantCulture);

        private static bool EsCaracterIdentificador(char caracter) =>
            char.IsLetterOrDigit(caracter) || caracter == '_' || caracter == '$' || caracter == '.' || caracter == '\\';

        private static int FinIdentificador(string formula, int posicion)
        {
            while (posicion < formula.Length && EsCaracterIdentificador(formula[posicion])) posicion++;
            return posicion;
        }

        private static int SaltarEspacios(string formula, int posicion)
        {
            while (posicion < formula.Length && char.IsWhiteSpace(formula[posicion])) posicion++;
            return posicion;
        }

        private static bool IntentarCelda(string formula, int inicio, int fin, out int fila, out int columna)
        {
            fila = columna = 0;
            int posicion = inicio;
            if (posicion < fin && formula[posicion] == '$') posicion++;
            int inicioLetras = posicion;
            while (posicion < fin)
            {
                char letra = char.ToUpperInvariant(formula[posicion]);
                if (letra < 'A' || letra > 'Z') break;
                if (posicion - inicioLetras == 3) return false;
                columna = columna * 26 + letra - 'A' + 1;
                posicion++;
            }
            if (posicion == inicioLetras || columna > MaximoColumnasExcel) return false;
            if (posicion < fin && formula[posicion] == '$') posicion++;
            int inicioNumero = posicion;
            if (posicion >= fin || formula[posicion] < '1' || formula[posicion] > '9') return false;
            while (posicion < fin && formula[posicion] >= '0' && formula[posicion] <= '9')
            {
                if (posicion - inicioNumero == 7) return false;
                fila = fila * 10 + formula[posicion] - '0';
                posicion++;
            }
            return posicion == fin && fila > 0 && fila <= MaximoFilasExcel;
        }

        private static int SaltarTextoEntreComillas(string formula, int posicion, char comilla)
        {
            posicion++;
            while (posicion < formula.Length)
            {
                if (formula[posicion++] != comilla) continue;
                if (posicion < formula.Length && formula[posicion] == comilla) { posicion++; continue; }
                break;
            }
            return posicion;
        }

        private static int SaltarCorchetes(string formula, int posicion)
        {
            int profundidad = 0;
            while (posicion < formula.Length)
            {
                char caracter = formula[posicion++];
                if (caracter == '[') profundidad++;
                if (caracter == ']' && --profundidad == 0) break;
            }
            return posicion;
        }

        // Una referencia de otra hoja o libro no identifica celdas de esta hoja.
        // Se omite todo el operando calificado, incluidos rangos e intersecciones.
        private static int SaltarReferenciaCalificada(string formula, int posicion)
        {
            while (posicion < formula.Length)
            {
                char caracter = formula[posicion];
                if (caracter == '\'') { posicion = SaltarTextoEntreComillas(formula, posicion, '\''); continue; }
                if (caracter == '[') { posicion = SaltarCorchetes(formula, posicion); continue; }
                if (caracter == '"' || caracter == '+' || caracter == '-' || caracter == '*' || caracter == '/' ||
                    caracter == '^' || caracter == '&' || caracter == '=' || caracter == '<' || caracter == '>' ||
                    caracter == ',' || caracter == ';' || caracter == '(' || caracter == ')') break;
                posicion++;
            }
            return posicion;
        }
    }
}
