using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGTipoRestriccion
{
    LoAntesPosible = 0,
    LoMasTardePosible = 1,
    NoComenzarAntesDe = 2,
    NoComenzarDespuesDe = 3,
    NoFinalizarAntesDe = 4,
    NoFinalizarDespuesDe = 5,
    DebeComenzarEl = 6,
    DebeFinalizarEl = 7
}

/// <summary>Bloque de trabajo. El desfase se cuenta en jornadas laborables desde
/// el inicio de la tarea; los huecos entre bloques no añaden trabajo ni cantidad.</summary>
public sealed class MYGParteTarea
{
    public int DesfaseInicioDias { get; set; }
    public int DuracionDias { get; set; }
    public decimal Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}

/// <summary>Operaciones de Información de tarea independientes de la interfaz.
/// Los cambios se calculan antes de aplicarlos a la tarea recibida.</summary>
public static class MYGInformacionTarea
{
    public static readonly string[] NombresRestricciones =
    {
        "Lo antes posible", "Lo más tarde posible", "No comenzar antes de",
        "No comenzar después de", "No finalizar antes de", "No finalizar después de",
        "Debe comenzar el", "Debe finalizar el"
    };

    public static bool RequiereFecha(MYGTipoRestriccion tipo) =>
        tipo is >= MYGTipoRestriccion.NoComenzarAntesDe and <= MYGTipoRestriccion.DebeFinalizarEl;

    public static int ExtensionDias(MYGTareaCronograma tarea)
    {
        ArgumentNullException.ThrowIfNull(tarea);
        return tarea.Partes?.Count > 0
            ? checked(tarea.Partes[^1].DesfaseInicioDias + tarea.Partes[^1].DuracionDias - 1)
            : Math.Max(0, tarea.DuracionDias - 1);
    }

    public static void Validar(MYGTareaCronograma tarea)
    {
        ArgumentNullException.ThrowIfNull(tarea);
        if (!Enum.IsDefined(tarea.TipoRestriccion) ||
            RequiereFecha(tarea.TipoRestriccion) && (!tarea.FechaRestriccion.HasValue || tarea.FechaRestriccion.Value == default) ||
            tarea.FechaRestriccion.HasValue && tarea.FechaRestriccion.Value == default)
            throw new InvalidDataException("Indique una restricción y una fecha válidas para «" + tarea.Nombre + "».");
        if (tarea.DuracionDias < 0 || tarea.DuracionDias > 36500 ||
            tarea.DuracionInicialDias is < 0 or > 36500 || tarea.CuadrillasIniciales <= 0 || tarea.NumeroCuadrillas <= 0)
            throw new InvalidDataException("La duración debe estar entre 0 y 36.500 días y el número de cuadrillas debe ser mayor que cero.");
        if (tarea.Reprogramada && !tarea.DuracionInicialDias.HasValue)
            throw new InvalidDataException("La tarea reprogramada debe conservar su duración inicial.");
        if (tarea.Partes == null)
            throw new InvalidDataException("La tarea requiere una lista válida de partes.");
        if (tarea.EsResumen && (tarea.Partes.Count > 0 || tarea.TipoRestriccion != MYGTipoRestriccion.LoAntesPosible))
            throw new InvalidDataException("La programación de los resúmenes se obtiene de sus tareas, sin partes ni restricciones propias.");
        if (tarea.Partes.Count == 0) return;
        if (tarea.DuracionDias == 0 || tarea.Partes.Count > tarea.DuracionDias)
            throw new InvalidDataException("Un hito no se divide y cada parte debe contener al menos una jornada de trabajo.");
        long finAnterior = 0, duracion = 0;
        decimal porcentaje = 0;
        for (int i = 0; i < tarea.Partes.Count; i++)
        {
            var parte = tarea.Partes[i];
            if (parte == null || parte.DesfaseInicioDias < 0 || parte.DesfaseInicioDias > 36500 ||
                parte.DuracionDias <= 0 || parte.DuracionDias > 36500 || parte.Cantidad < 0 ||
                parte.Porcentaje < 0 || parte.Porcentaje > 100 ||
                i == 0 && parte.DesfaseInicioDias != 0 || parte.DesfaseInicioDias < finAnterior)
                throw new InvalidDataException("Las partes requieren duración positiva, cantidades y porcentajes válidos, orden cronológico y ningún solape. La primera debe empezar con la tarea.");
            finAnterior = (long)parte.DesfaseInicioDias + parte.DuracionDias;
            if (finAnterior > 36500)
                throw new InvalidDataException("La distribución de las partes supera 36.500 jornadas, incluidos sus intervalos.");
            duracion += parte.DuracionDias;
            porcentaje += parte.Porcentaje;
        }
        if (duracion != tarea.DuracionDias || porcentaje != 100m)
            throw new InvalidDataException("Las partes deben sumar la duración de la tarea y exactamente 100 %.");
    }

    public static void Reprogramar(MYGTareaCronograma tarea, int nuevaDuracion)
    {
        ArgumentNullException.ThrowIfNull(tarea);
        Validar(tarea);
        if (tarea.EsResumen) throw new InvalidDataException("Los resúmenes no se reprograman directamente.");
        if (nuevaDuracion < 0 || nuevaDuracion > 36500)
            throw new ArgumentOutOfRangeException(nameof(nuevaDuracion), "La duración debe estar entre 0 y 36.500 días.");
        int inicial = tarea.DuracionInicialDias ?? tarea.DuracionDias;
        decimal cuadrillas = tarea.DuracionInicialDias.HasValue ? tarea.CuadrillasIniciales : tarea.NumeroCuadrillas;
        decimal nuevasCuadrillas;
        try { nuevasCuadrillas = inicial == 0 || nuevaDuracion == 0 ? cuadrillas : checked(cuadrillas * inicial / nuevaDuracion); }
        catch (OverflowException ex) { throw new InvalidDataException("El número de cuadrillas calculado supera el rango admitido.", ex); }
        if (nuevasCuadrillas <= 0) throw new InvalidDataException("El número de cuadrillas calculado debe ser mayor que cero.");
        if (tarea.DuracionDias != nuevaDuracion)
        {
            tarea.Partes = new();
            tarea.FechasImportadasDelphin = null;
        }
        tarea.DuracionInicialDias = inicial;
        tarea.CuadrillasIniciales = cuadrillas;
        tarea.DuracionDias = nuevaDuracion;
        tarea.NumeroCuadrillas = nuevasCuadrillas;
        tarea.Reprogramada = nuevaDuracion != inicial;
    }

    public static void Dividir(MYGTareaCronograma tarea, int numeroPartes, int intervaloDias, decimal cantidadTotal)
    {
        ArgumentNullException.ThrowIfNull(tarea);
        Validar(tarea);
        if (tarea.EsResumen || tarea.DuracionDias == 0)
            throw new InvalidDataException("Seleccione una tarea con duración positiva para dividirla.");
        if (numeroPartes < 1 || numeroPartes > tarea.DuracionDias)
            throw new ArgumentOutOfRangeException(nameof(numeroPartes), "Cada parte debe contener al menos una jornada de trabajo.");
        if (intervaloDias < 0 || intervaloDias > 36500)
            throw new ArgumentOutOfRangeException(nameof(intervaloDias), "El intervalo debe estar entre 0 y 36.500 días laborables.");
        if (cantidadTotal < 0) throw new ArgumentOutOfRangeException(nameof(cantidadTotal), "La cantidad no puede ser negativa.");
        if ((long)tarea.DuracionDias + (long)(numeroPartes - 1) * intervaloDias > 36500)
            throw new InvalidDataException("La distribución supera 36.500 jornadas, incluidos los intervalos.");
        int duracionBase = tarea.DuracionDias / numeroPartes, sobrantes = tarea.DuracionDias % numeroPartes;
        var partes = new List<MYGParteTarea>(numeroPartes);
        decimal cantidadRestante = cantidadTotal, porcentajeRestante = 100m;
        int desfase = 0;
        for (int i = 0; i < numeroPartes; i++)
        {
            int dias = duracionBase + (i < sobrantes ? 1 : 0);
            decimal porcentaje = i == numeroPartes - 1 ? porcentajeRestante : decimal.Round(100m * dias / tarea.DuracionDias, 6);
            // Dividir antes de multiplicar evita desbordar cantidades decimales grandes.
            decimal cantidad = i == numeroPartes - 1 ? cantidadRestante : decimal.Round(cantidadTotal / tarea.DuracionDias * dias, 6);
            porcentaje = Math.Min(porcentajeRestante, porcentaje);
            cantidad = Math.Min(cantidadRestante, cantidad);
            partes.Add(new() { DesfaseInicioDias = desfase, DuracionDias = dias, Cantidad = cantidad, Porcentaje = porcentaje });
            cantidadRestante -= cantidad;
            porcentajeRestante -= porcentaje;
            desfase += dias + (i < numeroPartes - 1 ? intervaloDias : 0);
        }
        tarea.Partes = partes;
        tarea.FechasImportadasDelphin = null;
    }
}
