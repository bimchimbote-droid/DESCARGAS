using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public sealed class MYGSeleccionInsumo
{
    public string InsumoId { get; set; }
    public MYGInsumo NuevoInsumo { get; set; }
    public string SubpartidaIdLocal { get; set; }
    public bool EditarCompartido { get; set; }
}

// Los diálogos trabajan sobre copias. Validar el presupuesto completo antes de
// publicar el cambio evita ciclos, referencias rotas y ediciones parciales.
public static class MYGInsumosEdicion
{
    public static void ValidarInsumo(MYGInsumo i)
    {
        ArgumentNullException.ThrowIfNull(i);
        if (string.IsNullOrWhiteSpace(i.Id) || string.IsNullOrWhiteSpace(i.Descripcion) || string.IsNullOrWhiteSpace(i.Unidad) ||
            !Enum.IsDefined(i.Grupo) || i.Grupo == MYGGrupoRecurso.Subpartidas)
            throw new InvalidOperationException("Indique descripción, unidad y tipo de insumo válidos.");
        if (i.Precio < 0 || i.PrecioBase < 0 || i.IGVPorcentaje < 0 || i.IGVPorcentaje > 100)
            throw new InvalidOperationException("Los precios deben ser positivos o cero; el IGV debe estar entre 0 y 100%.");
    }

    public static void EditarInsumo(MYGPresupuestoDocumento p, MYGInsumo valor, Action antes = null)
    {
        ArgumentNullException.ThrowIfNull(p); ValidarInsumo(valor);
        var trabajo = MYGProyectoStorage.Copia(p);
        var original = p.Costos.Insumos.SingleOrDefault(x => x.Id == valor.Id)
            ?? throw new InvalidOperationException("El insumo ya no pertenece al presupuesto.");
        ValidarEdicionCompartida(p, original, valor);
        trabajo.Costos.Insumos[trabajo.Costos.Insumos.FindIndex(x => x.Id == valor.Id)] = MYGProyectoStorage.Copia(valor);
        ValidarTrabajo(trabajo); antes?.Invoke();
        p.Costos.Insumos[p.Costos.Insumos.IndexOf(original)] = MYGProyectoStorage.Copia(valor);
    }

    public static MYGRecursoACU Aplicar(MYGPresupuestoDocumento p, string partidaId, string recursoId,
        MYGSeleccionInsumo seleccion, string insertarAntesId = null, Action antes = null)
    {
        ArgumentNullException.ThrowIfNull(p); ArgumentNullException.ThrowIfNull(seleccion);
        var trabajo = MYGProyectoStorage.Copia(p);
        var recurso = AplicarEnTrabajo(trabajo, partidaId, recursoId, seleccion, insertarAntesId, out var agregado, out var editado);
        ValidarTrabajo(trabajo); antes?.Invoke();
        // Publicar sólo el insumo y la línea afectados conserva las referencias
        // de estructura, metrados y restantes ACU que utiliza el editor.
        if (agregado != null) p.Costos.Insumos.Add(agregado);
        if (editado != null) p.Costos.Insumos[p.Costos.Insumos.FindIndex(x => x.Id == editado.Id)] = editado;
        var destino = p.Items.Single(x => x.Id == partidaId).Costos.Analisis;
        if (recursoId == null) destino.Insert(trabajo.Items.Single(x => x.Id == partidaId).Costos.Analisis.FindIndex(x => x.Id == recurso.Id), recurso);
        else destino[destino.FindIndex(x => x.Id == recursoId)] = recurso;
        return recurso;
    }

    public static IReadOnlyList<MYGRecursoACU> AplicarVarios(MYGPresupuestoDocumento p, string partidaId,
        IEnumerable<MYGSeleccionInsumo> selecciones, string insertarAntesId = null, Action antes = null)
    {
        ArgumentNullException.ThrowIfNull(p); ArgumentNullException.ThrowIfNull(selecciones);
        var elegidos = selecciones.ToList();
        if (elegidos.Count == 0) return Array.Empty<MYGRecursoACU>();
        var trabajo = MYGProyectoStorage.Copia(p);
        var recursos = new List<MYGRecursoACU>();
        var insumos = new List<MYGInsumo>();
        foreach (var seleccion in elegidos)
        {
            ArgumentNullException.ThrowIfNull(seleccion);
            var recurso = AplicarEnTrabajo(trabajo, partidaId, null, seleccion, insertarAntesId, out var agregado, out _);
            recursos.Add(recurso);
            if (agregado != null) insumos.Add(agregado);
        }
        // Validar el lote completo antes de crear una sola entrada de historial.
        // Un error tampoco publica los insumos nuevos de las selecciones previas.
        ValidarTrabajo(trabajo); antes?.Invoke();
        p.Costos.Insumos.AddRange(insumos);
        var destino = p.Items.Single(x => x.Id == partidaId).Costos.Analisis;
        var idsNuevos = recursos.Select(x => x.Id).ToHashSet();
        var analisis = trabajo.Items.Single(x => x.Id == partidaId).Costos.Analisis;
        for (int posicion = 0; posicion < analisis.Count; posicion++)
            if (idsNuevos.Contains(analisis[posicion].Id)) destino.Insert(posicion, analisis[posicion]);
        return recursos.AsReadOnly();
    }

    private static MYGRecursoACU AplicarEnTrabajo(MYGPresupuestoDocumento trabajo, string partidaId, string recursoId,
        MYGSeleccionInsumo seleccion, string insertarAntesId, out MYGInsumo agregado, out MYGInsumo editado)
    {
        var partida = trabajo.Items.SingleOrDefault(x => x.Id == partidaId)
            ?? throw new InvalidOperationException("La partida ya no pertenece al presupuesto.");
        if (MYGProyectoStorage.EsTitulo(partida)) throw new InvalidOperationException("Seleccione una partida para editar su ACU.");
        var recurso = recursoId == null ? new MYGRecursoACU() : partida.Costos.Analisis.SingleOrDefault(x => x.Id == recursoId)
            ?? throw new InvalidOperationException("El recurso ya no pertenece al análisis.");
        string unidadAnterior = trabajo.Costos.Insumos.FirstOrDefault(x => x.Id == recurso.InsumoId)?.Unidad;
        bool calculabaCantidad = recurso.Modo == MYGModoCantidad.Rendimiento ||
            recurso.CalcularCantidadPorUnidad && MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(recurso, unidadAnterior);
        decimal cantidadAnterior = recursoId == null ? 0 :
            MYGCalculoCantidadRecursoACU.CantidadBase(partida.Costos, recurso, unidadAnterior);
        string unidadDestino = null;
        int alternativas = (!string.IsNullOrWhiteSpace(seleccion.InsumoId) ? 1 : 0) +
            (seleccion.NuevoInsumo != null ? 1 : 0) + (!string.IsNullOrWhiteSpace(seleccion.SubpartidaIdLocal) ? 1 : 0);
        if (alternativas != 1) throw new InvalidOperationException("Seleccione un insumo o una subpartida.");
        agregado = null; editado = null;
        MYGGrupoRecurso grupo;
        MYGModoCantidad modo;
        if (!string.IsNullOrWhiteSpace(seleccion.SubpartidaIdLocal))
        {
            if (seleccion.EditarCompartido) throw new InvalidOperationException("Una subpartida se edita desde su propio análisis.");
            var sub = trabajo.Items.SingleOrDefault(x => x.IdLocalMYG == seleccion.SubpartidaIdLocal && !MYGProyectoStorage.EsTitulo(x))
                ?? throw new InvalidOperationException("La subpartida seleccionada ya no existe.");
            recurso.InsumoId = null; recurso.SubpartidaIdLocal = sub.IdLocalMYG;
            grupo = MYGGrupoRecurso.Subpartidas; modo = MYGModoCantidad.Directa;
        }
        else
        {
            MYGInsumo insumo;
            if (seleccion.NuevoInsumo != null)
            {
                insumo = MYGProyectoStorage.Copia(seleccion.NuevoInsumo); ValidarInsumo(insumo);
                if (seleccion.EditarCompartido)
                {
                    if (recursoId == null || recurso.Grupo == MYGGrupoRecurso.Subpartidas || recurso.InsumoId != insumo.Id)
                        throw new InvalidOperationException("Seleccione el insumo original para editar todas sus apariciones.");
                    var original = trabajo.Costos.Insumos.Single(x => x.Id == insumo.Id);
                    ValidarEdicionCompartida(trabajo, original, insumo);
                    trabajo.Costos.Insumos[trabajo.Costos.Insumos.IndexOf(original)] = insumo; editado = insumo;
                }
                else
                {
                    if (trabajo.Costos.Insumos.Any(x => x.Id == insumo.Id))
                        throw new InvalidOperationException("El nuevo insumo tiene un identificador ya usado.");
                    trabajo.Costos.Insumos.Add(insumo); agregado = insumo;
                }
            }
            else insumo = trabajo.Costos.Insumos.SingleOrDefault(x => x.Id == seleccion.InsumoId)
                ?? throw new InvalidOperationException("El insumo seleccionado ya no existe.");
            if (!insumo.Habilitado && editado == null) throw new InvalidOperationException("Seleccione un insumo habilitado.");
            grupo = insumo.Grupo;
            unidadDestino = insumo.Unidad;
            modo = ModoInicial(insumo);
            // No convertir horas/unidades en una tasa porcentual ni a la inversa.
            // Estas magnitudes requieren añadir una línea y definir su cantidad.
            if (recursoId != null && editado == null &&
                (recurso.Modo == MYGModoCantidad.PorcentajeManoObra) != (modo == MYGModoCantidad.PorcentajeManoObra))
                throw new InvalidOperationException("No se puede convertir un consumo en porcentaje de mano de obra ni a la inversa. Agregue un recurso y defina su cantidad.");
            if (editado != null || recursoId != null && (recurso.Modo == MYGModoCantidad.Directa && modo != MYGModoCantidad.PorcentajeManoObra ||
                recurso.Modo == MYGModoCantidad.Rendimiento && modo == MYGModoCantidad.Rendimiento ||
                recurso.Modo == MYGModoCantidad.PorcentajeManoObra && modo == MYGModoCantidad.PorcentajeManoObra)) modo = recurso.Modo;
            recurso.InsumoId = insumo.Id; recurso.SubpartidaIdLocal = null;
        }
        if (recursoId != null && recurso.Modo == MYGModoCantidad.PorcentajeManoObra && modo != MYGModoCantidad.PorcentajeManoObra)
            throw new InvalidOperationException("Un porcentaje de mano de obra no se puede convertir en consumo de subpartida. Agregue el nuevo recurso y defina su cantidad.");
        bool calculaDestino = modo == MYGModoCantidad.Rendimiento || recurso.CalcularCantidadPorUnidad &&
            modo != MYGModoCantidad.PorcentajeManoObra && grupo != MYGGrupoRecurso.Subpartidas &&
            MYGCalculoCantidadRecursoACU.EsUnidadPorRecursos(unidadDestino);
        if (recursoId != null && calculabaCantidad && !calculaDestino)
            recurso.Cantidad = cantidadAnterior;
        recurso.Grupo = grupo; recurso.Modo = modo;
        if (recursoId == null)
            recurso.CalcularCantidadPorUnidad = modo == MYGModoCantidad.Rendimiento && MYGCalculoCantidadRecursoACU.EsUnidadPorRecursos(unidadDestino);
        else if (modo == MYGModoCantidad.PorcentajeManoObra || grupo == MYGGrupoRecurso.Subpartidas ||
            !MYGCalculoCantidadRecursoACU.EsUnidadPorRecursos(unidadDestino))
            recurso.CalcularCantidadPorUnidad = false;
        if (recursoId == null)
        {
            int posicion = insertarAntesId == null ? -1 : partida.Costos.Analisis.FindIndex(x => x.Id == insertarAntesId && x.Grupo == grupo);
            if (posicion < 0) partida.Costos.Analisis.Add(recurso); else partida.Costos.Analisis.Insert(posicion, recurso);
        }
        return recurso;
    }

    public static MYGModoCantidad ModoInicial(MYGInsumo i) =>
        i.Grupo == MYGGrupoRecurso.Equipo && string.Equals(i.Unidad, "%mo", StringComparison.OrdinalIgnoreCase) ? MYGModoCantidad.PorcentajeManoObra :
        MYGCalculoCantidadRecursoACU.EsUnidadPorRecursos(i.Unidad) ? MYGModoCantidad.Rendimiento : MYGModoCantidad.Directa;

    private static void ValidarEdicionCompartida(MYGPresupuestoDocumento p, MYGInsumo original, MYGInsumo valor)
    {
        var usos = p.Items.SelectMany(x => x.Costos.Analisis).Where(r => r.InsumoId == valor.Id).ToList();
        if (usos.Count == 0) return;
        if (original.Grupo != valor.Grupo)
            throw new InvalidOperationException("Este insumo está usado en un ACU. Cree uno nuevo para cambiar su tipo.");
        if (ModoInicial(original) != ModoInicial(valor) && usos.Any(x => x.Modo != MYGModoCantidad.Directa || ModoInicial(valor) == MYGModoCantidad.PorcentajeManoObra))
            throw new InvalidOperationException("La nueva unidad requiere otro modo de cálculo. Cree un recurso nuevo para conservar las cantidades de las demás apariciones.");
    }

    private static void ValidarTrabajo(MYGPresupuestoDocumento p)
    {
        try { MYGProyectoStorage.ValidarPresupuesto(p); MYGMotorPresupuestos.Resumen(p); }
        catch (OverflowException ex) { throw new InvalidOperationException("El importe supera el rango de cálculo permitido.", ex); }
        catch (InvalidDataException ex) { throw new InvalidOperationException(ex.Message, ex); }
    }
}
