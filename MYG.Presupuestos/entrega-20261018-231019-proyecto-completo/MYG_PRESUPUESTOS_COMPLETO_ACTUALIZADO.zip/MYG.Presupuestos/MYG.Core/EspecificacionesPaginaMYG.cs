using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace MYG_2027;

public sealed class MYGPaginaEspecificacion
{
    public decimal AnchoMm { get; set; } = 210m;
    public decimal AltoMm { get; set; } = 297m;
    public decimal MargenIzquierdoMm { get; set; } = 25m;
    public decimal MargenDerechoMm { get; set; } = 25m;
    public decimal MargenSuperiorMm { get; set; } = 25m;
    public decimal MargenInferiorMm { get; set; } = 25m;
    public bool Horizontal { get; set; }
    public bool NumerarPaginas { get; set; }
    public string Encabezado { get; set; } = "";
    public string Pie { get; set; } = "";
}

/// <summary>
/// Conserva la configuración de cada especificación en un destino RTF ignorable.
/// El contenido y las tablas del documento no se reescriben al guardar la página.
/// </summary>
public static class MYGEspecificacionesPagina
{
    private const string Destino = @"{\*\mygpagina";
    private const int VersionActual = 1;
    private const int LimiteEncabezadoPie = 2000;
    private const int LimiteMetadatos = 65536;

    private sealed class DatosVersionados
    {
        public int Version { get; set; }
        public MYGPaginaEspecificacion Pagina { get; set; }
    }

    private readonly record struct Grupo(int Inicio, int Fin, int Contenido);

    public static MYGPaginaEspecificacion Leer(string rtf)
    {
        if (!Analizar(rtf, out _, out var grupos) || grupos.Count == 0) return new();
        Grupo grupo = grupos[0];
        int longitud = grupo.Fin - grupo.Contenido - 1;
        if (longitud < 1 || longitud > LimiteMetadatos) return new();
        try
        {
            byte[] json = Convert.FromBase64String(rtf.Substring(grupo.Contenido, longitud));
            var datos = JsonSerializer.Deserialize<DatosVersionados>(json);
            if (datos == null || datos.Version != VersionActual || datos.Pagina == null) return new();
            Validar(datos.Pagina);
            datos.Pagina.Encabezado ??= "";
            datos.Pagina.Pie ??= "";
            return datos.Pagina;
        }
        catch (FormatException) { return new(); }
        catch (JsonException) { return new(); }
        catch (ArgumentException) { return new(); }
    }

    public static string Guardar(string rtf, MYGPaginaEspecificacion pagina)
    {
        Validar(pagina);
        if (!Analizar(rtf, out int finCabecera, out var grupos))
            throw new ArgumentException("La especificación debe ser un documento RTF válido y completo.", nameof(rtf));
        string limpio = Quitar(rtf, grupos);
        string datos = Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(new DatosVersionados
        { Version = VersionActual, Pagina = pagina }));
        return limpio.Insert(finCabecera, Destino + " " + datos + "}");
    }

    public static string QuitarMetadatos(string rtf)
    {
        if (!Analizar(rtf, out _, out var grupos)) return rtf ?? "";
        return Quitar(rtf, grupos);
    }

    public static void Validar(MYGPaginaEspecificacion pagina)
    {
        ArgumentNullException.ThrowIfNull(pagina);
        if (pagina.AnchoMm <= 0m || pagina.AnchoMm > 2000m || pagina.AltoMm <= 0m || pagina.AltoMm > 2000m)
            throw new ArgumentException("El ancho y el alto de la hoja deben ser mayores que cero y no superar 2000 mm.", nameof(pagina));
        if (pagina.MargenIzquierdoMm < 0m || pagina.MargenDerechoMm < 0m ||
            pagina.MargenSuperiorMm < 0m || pagina.MargenInferiorMm < 0m)
            throw new ArgumentException("Los márgenes de la hoja no pueden ser negativos.", nameof(pagina));
        decimal ancho = pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm;
        decimal alto = pagina.Horizontal ? pagina.AnchoMm : pagina.AltoMm;
        // Restar evita desbordamientos ante metadatos externos con valores extremos.
        if (pagina.MargenIzquierdoMm >= ancho || pagina.MargenDerechoMm >= ancho - pagina.MargenIzquierdoMm ||
            pagina.MargenSuperiorMm >= alto || pagina.MargenInferiorMm >= alto - pagina.MargenSuperiorMm)
            throw new ArgumentException("Los márgenes deben dejar un área imprimible con ancho y alto positivos.", nameof(pagina));
        if ((pagina.Encabezado?.Length ?? 0) > LimiteEncabezadoPie || (pagina.Pie?.Length ?? 0) > LimiteEncabezadoPie)
            throw new ArgumentException("El encabezado y el pie no pueden superar 2000 caracteres cada uno.", nameof(pagina));
    }

    private static string Quitar(string rtf, List<Grupo> grupos)
    {
        if (grupos.Count == 0) return rtf;
        var texto = new StringBuilder(rtf.Length);
        int desde = 0;
        foreach (Grupo grupo in grupos)
        {
            if (grupo.Inicio < desde) continue;
            texto.Append(rtf, desde, grupo.Inicio - desde);
            desde = grupo.Fin;
        }
        texto.Append(rtf, desde, rtf.Length - desde);
        return texto.ToString();
    }

    // Recorrer los controles RTF evita confundir llaves escapadas o datos \bin
    // con grupos. Las demás extensiones ignorables se conservan íntegramente.
    private static bool Analizar(string rtf, out int finCabecera, out List<Grupo> grupos)
    {
        finCabecera = 0;
        grupos = new();
        if (string.IsNullOrEmpty(rtf)) return false;
        int inicio = 0;
        while (inicio < rtf.Length && char.IsWhiteSpace(rtf[inicio])) inicio++;
        if (!rtf.AsSpan(inicio).StartsWith(@"{\rtf", StringComparison.Ordinal)) return false;
        int pos = inicio + 5, numero = pos;
        while (pos < rtf.Length && Digito(rtf[pos])) pos++;
        if (pos == numero || rtf.AsSpan(numero, pos - numero).IndexOfAnyExcept('0') < 0 ||
            pos >= rtf.Length || Letra(rtf[pos])) return false;
        finCabecera = pos;
        var abiertos = new Stack<(int Inicio, int Contenido)>();
        pos = inicio;
        while (pos < rtf.Length)
        {
            char actual = rtf[pos];
            if (actual == '{')
            {
                int contenido = -1;
                if (rtf.AsSpan(pos).StartsWith(Destino, StringComparison.Ordinal))
                {
                    int fin = pos + Destino.Length;
                    if (fin < rtf.Length && (char.IsWhiteSpace(rtf[fin]) || rtf[fin] == '}')) contenido = fin;
                }
                abiertos.Push((pos, contenido));
                pos++;
            }
            else if (actual == '}')
            {
                if (abiertos.Count == 0) return false;
                var grupo = abiertos.Pop();
                if (grupo.Contenido >= 0) grupos.Add(new(grupo.Inicio, pos + 1, grupo.Contenido));
                pos++;
                if (abiertos.Count == 0)
                {
                    while (pos < rtf.Length && char.IsWhiteSpace(rtf[pos])) pos++;
                    if (pos != rtf.Length) return false;
                    grupos.Sort((a, b) => a.Inicio.CompareTo(b.Inicio));
                    return true;
                }
            }
            else if (actual == '\\')
            {
                pos++;
                if (pos >= rtf.Length) return false;
                if (!Letra(rtf[pos]))
                {
                    if (rtf[pos] == '\'')
                    {
                        if (pos + 2 >= rtf.Length || !Hexadecimal(rtf[pos + 1]) || !Hexadecimal(rtf[pos + 2])) return false;
                        pos += 3;
                    }
                    else pos++;
                    continue;
                }
                int palabra = pos;
                while (pos < rtf.Length && Letra(rtf[pos])) pos++;
                bool binario = rtf.AsSpan(palabra, pos - palabra).SequenceEqual("bin");
                int argumento = pos;
                if (pos < rtf.Length && rtf[pos] == '-') pos++;
                while (pos < rtf.Length && Digito(rtf[pos])) pos++;
                int finArgumento = pos;
                if (pos < rtf.Length && rtf[pos] == ' ') pos++;
                if (binario)
                {
                    if (!int.TryParse(rtf.AsSpan(argumento, finArgumento - argumento), out int bytes) ||
                        bytes < 0 || bytes > rtf.Length - pos) return false;
                    pos += bytes;
                }
            }
            else pos++;
        }
        return false;
    }

    private static bool Letra(char c) => c is >= 'a' and <= 'z' or >= 'A' and <= 'Z';
    private static bool Digito(char c) => c is >= '0' and <= '9';
    private static bool Hexadecimal(char c) => Digito(c) || c is >= 'a' and <= 'f' or >= 'A' and <= 'F';
}
