using System;
using System.IO;

namespace MYG_2027;

public static class MYGCalculoCantidadRecursoACU
{
    public static bool EsUnidadPorRecursos(string unidad)
    {
        string simbolo = unidad?.Trim();
        return string.Equals(simbolo, "he", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(simbolo, "hh", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(simbolo, "hm", StringComparison.OrdinalIgnoreCase);
    }

    public static bool UsaNumeroRecursos(MYGRecursoACU recurso, string unidad) => recurso != null &&
        recurso.Grupo != MYGGrupoRecurso.Subpartidas && recurso.Modo != MYGModoCantidad.PorcentajeManoObra &&
        EsUnidadPorRecursos(unidad);

    // Coeficiente sin redondeo ni desperdicio; el motor aplica ambos después.
    public static decimal Calcular(MYGDatosPartida datos, decimal numeroRecursos)
    {
        ArgumentNullException.ThrowIfNull(datos);
        if (datos.RendimientoDiario <= 0 || datos.JornadaHoras <= 0)
            throw new InvalidDataException("Rendimiento y jornada deben ser mayores que cero.");
        if (numeroRecursos < 0)
            throw new InvalidDataException("El número de recursos no puede ser negativo.");
        return (datos.RendimientoDiario / datos.JornadaHoras) * numeroRecursos;
    }

    public static decimal CantidadBase(MYGDatosPartida datos, MYGRecursoACU recurso, string unidad)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(recurso);
        if (recurso.CalcularCantidadPorUnidad && UsaNumeroRecursos(recurso, unidad))
            return Calcular(datos, recurso.NumeroRecursos);
        if (recurso.Modo != MYGModoCantidad.Rendimiento) return recurso.Cantidad;
        if (datos.RendimientoDiario <= 0)
            throw new InvalidDataException("El rendimiento debe ser positivo.");
        // Compatibilidad: las líneas guardadas conservan la regla anterior.
        return recurso.NumeroRecursos * datos.JornadaHoras / datos.RendimientoDiario;
    }
}
