using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace MYG_2027;

public enum MYGModoTarea { Automatica, Manual }
public enum MYGTipoVinculo { FC, CC, FF, CF }

public sealed class MYGCronograma
{
    public DateTime FechaInicio { get; set; } = DateTime.Today;
    public DateTime FechaEstado { get; set; } = DateTime.Today;
    public MYGCalendarioTrabajo Calendario { get; set; } = new();
    public List<MYGCalendarioTrabajo> Calendarios { get; set; } = new();
    public List<MYGTareaCronograma> Tareas { get; set; } = new();
    public List<MYGVinculoImportadoDelphin> VinculosImportadosDelphin { get; set; } = new();
    public List<string> AdvertenciasImportacion { get; set; } = new();
    public Dictionary<string, string> OpcionesVista { get; set; } = new();
}

public sealed class MYGTramoImportadoDelphin
{
    public string Id { get; set; }
    public DateTime Inicio { get; set; }
    public DateTime Fin { get; set; }
    public decimal Duracion { get; set; }
    public decimal Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}

public sealed class MYGFechasImportadasDelphin
{
    public DateTime Inicio { get; set; }
    public DateTime Fin { get; set; }
    public int DuracionDias { get; set; }
    public MYGModoTarea? ModoOriginal { get; set; }
    public int VersionLectura { get; set; }
    public string FirmaPredecesoras { get; set; }
    public string FirmaAntecesoras { get; set; }
    public string FirmaCalendario { get; set; }
    public DateTime? InicioProyecto { get; set; }
    public List<MYGTramoImportadoDelphin> Tramos { get; set; } = new();
}

public sealed class MYGVinculoImportadoDelphin
{
    public string Id { get; set; }
    public string OrigenId { get; set; }
    public string DestinoId { get; set; }
    public string ProgramacionDestinoId { get; set; }
    public int Tipo { get; set; }
    public decimal Desfase { get; set; }
}

public sealed class MYGTareaCronograma
{
    public string Id { get; set; } = MYGProyectoStorage.NuevoId();
    public string PadreId { get; set; }
    public string PresupuestoId { get; set; }
    public string PartidaId { get; set; }
    public string Codigo { get; set; }
    public string Nombre { get; set; } = "Nueva tarea";
    public bool EsResumen { get; set; }
    public MYGModoTarea Modo { get; set; } = MYGModoTarea.Automatica;
    public DateTime? InicioManual { get; set; }
    public MYGFechasImportadasDelphin FechasImportadasDelphin { get; set; }
    public int DuracionDias { get; set; } = 1;
    public MYGTipoRestriccion TipoRestriccion { get; set; }
    public DateTime? FechaRestriccion { get; set; }
    public int? DuracionInicialDias { get; set; }
    public decimal CuadrillasIniciales { get; set; } = 1;
    public bool Reprogramada { get; set; }
    public decimal NumeroCuadrillas { get; set; } = 1;
    public List<MYGParteTarea> Partes { get; set; } = new();
    public decimal Avance { get; set; }
    public string Notas { get; set; }
    public List<string> Responsables { get; set; } = new();
    public List<MYGDependenciaCronograma> Predecesoras { get; set; } = new();
    public DateTime? InicioBase { get; set; }
    public DateTime? FinBase { get; set; }
    public int? DuracionBase { get; set; }
}

public sealed class MYGDependenciaCronograma
{
    public string PredecesoraId { get; set; }
    public MYGTipoVinculo Tipo { get; set; } = MYGTipoVinculo.FC;
    public int DesfaseDias { get; set; }
}

public sealed class MYGResultadoTarea
{
    public MYGTareaCronograma Tarea { get; internal set; }
    public DateTime Inicio { get; internal set; }
    public DateTime Fin { get; internal set; }
    public int Numero { get; internal set; }
    public int Nivel { get; internal set; }
    public int DuracionDias { get; internal set; }
    public int DiasCalendario { get; internal set; }
    public int HolguraDias { get; internal set; }
    public bool EsCritica { get; internal set; }
    public decimal Avance { get; internal set; }
    public IReadOnlyList<string> Advertencias { get; internal set; } = Array.Empty<string>();
}

public sealed class MYGResultadoCronograma
{
    public IReadOnlyList<MYGResultadoTarea> Filas { get; internal set; } = Array.Empty<MYGResultadoTarea>();
    public DateTime Inicio { get; internal set; }
    public DateTime Fin { get; internal set; }
    public IReadOnlyList<string> Advertencias { get; internal set; } = Array.Empty<string>();
}

/// <summary>CPM en días laborables enteros. El cálculo y sus resultados son
/// instantáneas: nunca modifican el cronograma ni el presupuesto de origen.</summary>
public static class MYGMotorCronograma
{
    private static InvalidDataException Error(string texto) => new(texto);
    private static bool Vacio(string texto) => string.IsNullOrWhiteSpace(texto);

    // Al abrir una planificación existente sus fechas son una instantánea. Una
    // edición de modo, inicio o duración vuelve a usar el cálculo habitual.
    public static bool ConservaFechasDelphin(MYGTareaCronograma tarea) => tarea?.FechasImportadasDelphin is { } f &&
        tarea.TipoRestriccion == MYGTipoRestriccion.LoAntesPosible && (tarea.Partes?.Count ?? 0) == 0 &&
        tarea.Modo == (f.ModoOriginal ?? MYGModoTarea.Manual) && tarea.InicioManual?.Date == f.Inicio.Date &&
        tarea.DuracionDias == f.DuracionDias && (tarea.Modo == MYGModoTarea.Manual || f.FirmaPredecesoras == null ||
            f.FirmaPredecesoras == FirmaPredecesorasDelphin(tarea));

    internal static string FirmaPredecesorasDelphin(MYGTareaCronograma tarea) => FirmaImportacion(
        tarea.Predecesoras.OrderBy(d => d.PredecesoraId, StringComparer.Ordinal).ThenBy(d => d.Tipo).ThenBy(d => d.DesfaseDias));

    internal static string FirmaCalendarioDelphin(MYGCalendarioTrabajo calendario) => FirmaImportacion(calendario);

    internal static string FirmaAntecesorasDelphin(MYGTareaCronograma tarea,
        IReadOnlyDictionary<string, MYGTareaCronograma> tareas, IReadOnlyDictionary<string, MYGResultadoTarea> resultados) => FirmaImportacion(tarea.Predecesoras
        .OrderBy(d => d.PredecesoraId, StringComparer.Ordinal).Select(d => tareas[d.PredecesoraId]).Select(t => new
        {
            t.Id, t.Modo, t.InicioManual, t.DuracionDias, Inicio = t.FechasImportadasDelphin?.Inicio, Fin = t.FechasImportadasDelphin?.Fin,
            InicioCalculado = resultados[t.Id].Inicio, FinCalculado = resultados[t.Id].Fin
        }));

    private static string FirmaImportacion<T>(T valor) => Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
        System.Text.Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(valor))));

    public static MYGResultadoCronograma Calcular(MYGCronograma plan)
    {
        ArgumentNullException.ThrowIfNull(plan);
        if (plan.Calendarios != null)
        {
            var nombresCalendarios = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var calendarioGuardado in plan.Calendarios)
            {
                if (calendarioGuardado == null || !nombresCalendarios.Add(calendarioGuardado.Nombre?.Trim() ?? ""))
                    throw Error("Los calendarios del proyecto requieren nombres únicos y datos válidos.");
                calendarioGuardado.Validar();
            }
        }
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        if (plan.FechaInicio == default || plan.FechaEstado == default || plan.Tareas == null)
            throw Error("Indique las fechas de inicio y estado y una lista válida de tareas.");
        if (plan.OpcionesVista == null || plan.OpcionesVista.Any(o => Vacio(o.Key) || o.Value == null))
            throw Error("Las preferencias de presentación requieren nombres y valores válidos.");
        var tareas = new Dictionary<string, MYGTareaCronograma>(StringComparer.Ordinal);
        foreach (var t in plan.Tareas)
        {
            if (t == null || Vacio(t.Id) || !tareas.TryAdd(t.Id, t) || Vacio(t.Nombre) ||
                !Enum.IsDefined(t.Modo) || t.DuracionDias < 0 || t.DuracionDias > 36500 || t.Avance < 0 || t.Avance > 100 ||
                t.Responsables == null || t.Responsables.Any(Vacio) || t.Predecesoras == null)
                throw Error("Cada tarea requiere identidad única, nombre, duración de 0 a 36.500 días y avance de 0 a 100 %.");
            MYGInformacionTarea.Validar(t);
            if (!t.EsResumen && t.Modo == MYGModoTarea.Manual && (!t.InicioManual.HasValue || t.InicioManual.Value == default))
                throw Error("Indique la fecha de inicio de la tarea manual «" + t.Nombre + "».");
            if (t.FechasImportadasDelphin is { } importadas && (importadas.Fin.Date < importadas.Inicio.Date || importadas.Tramos == null ||
                importadas.Tramos.Any(s => s == null || s.Fin.Date < s.Inicio.Date || s.Porcentaje < 0)))
                throw Error("Las fechas o tramos importados de la tarea no son válidos: " + t.Nombre);
            bool algunaBase = t.InicioBase.HasValue || t.FinBase.HasValue || t.DuracionBase.HasValue;
            if (algunaBase && (!t.InicioBase.HasValue || !t.FinBase.HasValue || !t.DuracionBase.HasValue ||
                t.DuracionBase.Value < 0 || t.FinBase.Value.Date < t.InicioBase.Value.Date))
                throw Error("La línea base debe contener inicio, fin y duración válidos: " + t.Nombre);
        }
        var hijos = tareas.Values.Where(t => !Vacio(t.PadreId)).GroupBy(t => t.PadreId, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
        foreach (var t in tareas.Values)
            if (!Vacio(t.PadreId) && (!tareas.TryGetValue(t.PadreId, out var padre) || !padre.EsResumen))
                throw Error("La tarea «" + t.Nombre + "» debe pertenecer a un resumen existente.");
        var estados = new Dictionary<string, int>(StringComparer.Ordinal);
        void ValidarPadre(MYGTareaCronograma t)
        {
            if (estados.TryGetValue(t.Id, out int estado))
            { if (estado == 1) throw Error("La jerarquía del cronograma contiene una referencia circular."); return; }
            estados[t.Id] = 1;
            if (!Vacio(t.PadreId)) ValidarPadre(tareas[t.PadreId]);
            estados[t.Id] = 2;
        }
        foreach (var t in tareas.Values) ValidarPadre(t);
        var hojas = tareas.Values.Where(t => !t.EsResumen).ToList();
        var sucesoras = hojas.ToDictionary(t => t.Id, _ => new List<(MYGTareaCronograma Tarea, MYGDependenciaCronograma Vinculo)>(), StringComparer.Ordinal);
        var pendientes = hojas.ToDictionary(t => t.Id, t => t.Predecesoras.Count, StringComparer.Ordinal);
        foreach (var t in tareas.Values)
        {
            if (t.EsResumen && t.Predecesoras.Count != 0) throw Error("Los vínculos se asignan a tareas o hitos, no a resúmenes.");
            var vistas = new HashSet<string>(StringComparer.Ordinal);
            foreach (var d in t.Predecesoras)
            {
                if (d == null || Vacio(d.PredecesoraId) || !Enum.IsDefined(d.Tipo) || !vistas.Add(d.PredecesoraId) ||
                    d.PredecesoraId == t.Id || !tareas.TryGetValue(d.PredecesoraId, out var origen) || origen.EsResumen)
                    throw Error("Predecesora inexistente, repetida, circular o de resumen en «" + t.Nombre + "».");
                sucesoras[origen.Id].Add((t, d));
            }
        }
        var orden = new List<MYGTareaCronograma>();
        var disponibles = new Queue<MYGTareaCronograma>(hojas.Where(t => pendientes[t.Id] == 0));
        while (disponibles.TryDequeue(out var t))
        {
            orden.Add(t);
            foreach (var s in sucesoras[t.Id]) if (--pendientes[s.Tarea.Id] == 0) disponibles.Enqueue(s.Tarea);
        }
        if (orden.Count != hojas.Count) throw Error("Las dependencias del cronograma contienen un ciclo, incluidas las tareas manuales.");

        long inicioProyecto = calendario.Primero(plan.FechaInicio);
        string firmaCalendario = FirmaCalendarioDelphin(plan.Calendario);
        var inicio = new Dictionary<string, long>(StringComparer.Ordinal);
        var resultado = new Dictionary<string, MYGResultadoTarea>(StringComparer.Ordinal);
        bool Exacta(MYGTareaCronograma t) => t.TipoRestriccion is MYGTipoRestriccion.DebeComenzarEl or MYGTipoRestriccion.DebeFinalizarEl;
        bool Fija(MYGTareaCronograma t) => t.Modo == MYGModoTarea.Manual || Exacta(t);
        long ExtensionPlanificada(MYGTareaCronograma t) => MYGInformacionTarea.ExtensionDias(t);
        long? LimiteInferior(MYGTareaCronograma t) => t.TipoRestriccion switch
        {
            MYGTipoRestriccion.NoComenzarAntesDe or MYGTipoRestriccion.DebeComenzarEl => calendario.Primero(t.FechaRestriccion.Value),
            MYGTipoRestriccion.NoFinalizarAntesDe => calendario.Primero(t.FechaRestriccion.Value) - ExtensionPlanificada(t),
            MYGTipoRestriccion.DebeFinalizarEl => calendario.AnteriorOIgual(t.FechaRestriccion.Value) - ExtensionPlanificada(t),
            _ => null
        };
        long? LimiteSuperior(MYGTareaCronograma t) => t.TipoRestriccion switch
        {
            MYGTipoRestriccion.NoComenzarDespuesDe => calendario.AnteriorOIgual(t.FechaRestriccion.Value),
            MYGTipoRestriccion.NoFinalizarDespuesDe or MYGTipoRestriccion.DebeFinalizarEl =>
                calendario.AnteriorOIgual(t.FechaRestriccion.Value) - ExtensionPlanificada(t),
            MYGTipoRestriccion.DebeComenzarEl => calendario.Primero(t.FechaRestriccion.Value),
            _ => null
        };
        bool ConservarImportacion(MYGTareaCronograma t)
        {
            bool conserva = ConservaFechasDelphin(t);
            if (conserva && t.Modo == MYGModoTarea.Automatica)
            {
                conserva = (!t.FechasImportadasDelphin.InicioProyecto.HasValue ||
                    t.FechasImportadasDelphin.InicioProyecto.Value.Date == plan.FechaInicio.Date) &&
                    (t.FechasImportadasDelphin.FirmaCalendario == null ||
                    t.FechasImportadasDelphin.FirmaCalendario == firmaCalendario) &&
                    (t.FechasImportadasDelphin.FirmaAntecesoras == null ||
                    t.FechasImportadasDelphin.FirmaAntecesoras == FirmaAntecesorasDelphin(t, tareas, resultado));
            }
            return conserva;
        }
        long ComienzoMinimo(MYGTareaCronograma t, bool conserva)
        {
            long s = conserva ? calendario.Primero(t.FechasImportadasDelphin.Inicio) :
                t.Modo == MYGModoTarea.Manual ? calendario.Primero(t.InicioManual.Value) : inicioProyecto;
            if (t.Modo == MYGModoTarea.Automatica && !conserva)
            {
                foreach (var d in t.Predecesoras)
                {
                    var anterior = resultado[d.PredecesoraId];
                    long restriccion = d.Tipo switch
                    {
                        MYGTipoVinculo.FC => calendario.Despues(anterior.Fin) + d.DesfaseDias,
                        MYGTipoVinculo.CC => calendario.Primero(anterior.Inicio) + d.DesfaseDias,
                        MYGTipoVinculo.FF => calendario.Primero(anterior.Fin) + d.DesfaseDias - ExtensionPlanificada(t),
                        _ => calendario.Primero(anterior.Inicio) + d.DesfaseDias - ExtensionPlanificada(t)
                    };
                    s = Math.Max(s, restriccion);
                }
                if (LimiteInferior(t) is long inferior) s = Exacta(t) ? inferior : Math.Max(s, inferior);
            }
            return s;
        }
        void Programar(MYGTareaCronograma t, long s, bool conserva)
        {
            var comienzo = conserva ? t.FechasImportadasDelphin.Inicio.Date :
                t.Modo == MYGModoTarea.Manual ? t.InicioManual.Value.Date :
                t.TipoRestriccion == MYGTipoRestriccion.DebeComenzarEl ||
                    t.TipoRestriccion == MYGTipoRestriccion.DebeFinalizarEl && t.DuracionDias == 0
                    ? t.FechaRestriccion.Value.Date : calendario.Fecha(s);
            var fin = conserva ? t.FechasImportadasDelphin.Fin.Date :
                t.Modo == MYGModoTarea.Automatica && t.TipoRestriccion == MYGTipoRestriccion.DebeFinalizarEl
                    ? t.FechaRestriccion.Value.Date :
                t.DuracionDias == 0 ? comienzo : calendario.Fecha(s + ExtensionPlanificada(t));
            inicio[t.Id] = s;
            var tareaResultado = Copiar(t);
            if (!conserva && t.Modo == MYGModoTarea.Automatica) tareaResultado.FechasImportadasDelphin = null;
            resultado[t.Id] = new MYGResultadoTarea { Tarea = tareaResultado, Inicio = comienzo, Fin = fin,
                DuracionDias = t.DuracionDias, DiasCalendario = t.DuracionDias == 0 ? 0 : (fin - comienzo).Days + 1,
                Avance = t.Avance };
        }
        foreach (var t in orden)
        {
            bool conserva = ConservarImportacion(t);
            Programar(t, ComienzoMinimo(t, conserva), conserva);
        }
        // Los huecos de las partes y los tramos importados alargan la tarea,
        // pero no su trabajo. Todos los vínculos y las holguras usan ese rango.
        long Extension(MYGTareaCronograma t) => t.Modo == MYGModoTarea.Automatica && ConservaFechasDelphin(resultado[t.Id].Tarea)
            ? Math.Max(0, calendario.Primero(resultado[t.Id].Fin) - inicio[t.Id]) : ExtensionPlanificada(t);
        Dictionary<string, long> Tardios()
        {
            long horizonte = resultado.Count == 0 ? inicioProyecto : resultado.Values.Max(r =>
                r.Tarea.Modo == MYGModoTarea.Automatica && Exacta(r.Tarea) && !plan.Calendario.EsLaborable(r.Fin)
                    ? calendario.AnteriorOIgual(r.Fin) : calendario.Primero(r.Fin));
            var valores = orden.ToDictionary(t => t.Id,
                t => Fija(t) ? inicio[t.Id] : horizonte - Extension(t), StringComparer.Ordinal);
            foreach (var t in orden)
                if (!Fija(t) && LimiteSuperior(t) is long superior) valores[t.Id] = Math.Min(valores[t.Id], superior);
            foreach (var t in orden.AsEnumerable().Reverse())
            {
                if (Fija(t)) continue;
                foreach (var s in sucesoras[t.Id])
                {
                    long peso = s.Vinculo.Tipo switch
                    {
                        MYGTipoVinculo.FC => Extension(t) + 1L + s.Vinculo.DesfaseDias,
                        MYGTipoVinculo.CC => s.Vinculo.DesfaseDias,
                        MYGTipoVinculo.FF => Extension(t) - Extension(s.Tarea) + s.Vinculo.DesfaseDias,
                        _ => -Extension(s.Tarea) + s.Vinculo.DesfaseDias
                    };
                    long limiteSucesora = valores[s.Tarea.Id];
                    if (Fija(s.Tarea))
                    {
                        var fija = resultado[s.Tarea.Id];
                        limiteSucesora = s.Vinculo.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC
                            ? calendario.AnteriorOIgual(fija.Inicio)
                            : calendario.AnteriorOIgual(fija.Fin) - ExtensionPlanificada(s.Tarea);
                    }
                    valores[t.Id] = Math.Min(valores[t.Id], limiteSucesora - peso);
                }
            }
            return valores;
        }
        var tardio = Tardios();
        if (orden.Any(t => t.Modo == MYGModoTarea.Automatica && t.TipoRestriccion == MYGTipoRestriccion.LoMasTardePosible))
        {
            // Tras situar una tarea ALAP en su comienzo tardío hay que volver
            // a recorrer sus sucesoras. Dejarlas en sus fechas tempranas
            // rompería los vínculos incluso en una red perfectamente viable.
            foreach (var t in orden)
            {
                bool conserva = ConservarImportacion(t);
                long s = ComienzoMinimo(t, conserva);
                if (t.Modo == MYGModoTarea.Automatica && t.TipoRestriccion == MYGTipoRestriccion.LoMasTardePosible)
                    s = Math.Max(s, tardio[t.Id]);
                Programar(t, s, conserva);
            }
            tardio = Tardios();
        }
        foreach (var t in orden)
        {
            var advertencias = new List<string>();
            var fila = resultado[t.Id];
            foreach (var d in t.Predecesoras)
            {
                var anterior = resultado[d.PredecesoraId];
                long requerido = d.Tipo switch
                {
                    MYGTipoVinculo.FC => calendario.Despues(anterior.Fin) + d.DesfaseDias,
                    MYGTipoVinculo.CC => calendario.Primero(anterior.Inicio) + d.DesfaseDias,
                    MYGTipoVinculo.FF => calendario.Primero(anterior.Fin) + d.DesfaseDias,
                    _ => calendario.Primero(anterior.Inicio) + d.DesfaseDias
                };
                bool comienzo = d.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC;
                var actual = comienzo ? fila.Inicio : fila.Fin;
                if (calendario.AnteriorOIgual(actual) < requerido)
                    advertencias.Add("La tarea " + (t.Modo == MYGModoTarea.Manual ? "manual " : "") + "«" + t.Nombre + "» " +
                        (comienzo ? "comienza" : "termina") + " antes de lo requerido por «" + anterior.Tarea.Nombre + "» (" + d.Tipo +
                        (d.DesfaseDias == 0 ? "" : (d.DesfaseDias > 0 ? "+" : "") + d.DesfaseDias.ToString(CultureInfo.InvariantCulture)) + ").");
            }
            if (MYGInformacionTarea.RequiereFecha(t.TipoRestriccion))
            {
                var fecha = t.FechaRestriccion.Value.Date;
                bool incumple = t.TipoRestriccion switch
                {
                    MYGTipoRestriccion.NoComenzarAntesDe => fila.Inicio < fecha,
                    MYGTipoRestriccion.NoComenzarDespuesDe => fila.Inicio > fecha,
                    MYGTipoRestriccion.NoFinalizarAntesDe => fila.Fin < fecha,
                    MYGTipoRestriccion.NoFinalizarDespuesDe => fila.Fin > fecha,
                    MYGTipoRestriccion.DebeComenzarEl => fila.Inicio != fecha,
                    _ => fila.Fin != fecha
                };
                if (incumple)
                    advertencias.Add("La tarea «" + t.Nombre + "» incumple la restricción «" +
                        MYGInformacionTarea.NombresRestricciones[(int)t.TipoRestriccion] + " " + fecha.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) +
                        "». Revise las predecesoras y la programación manual.");
                if (Exacta(t) && !plan.Calendario.EsLaborable(fecha))
                    advertencias.Add("La restricción de la tarea «" + t.Nombre + "» usa una fecha no laborable (" +
                        fecha.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + "). Se conserva la fecha fija y se cuenta el trabajo en jornadas laborables.");
            }
            long holgura = tardio[t.Id] - inicio[t.Id];
            if (holgura < int.MinValue || holgura > int.MaxValue) throw Error("El desfase produce una holgura fuera del rango admitido.");
            if (t.Modo != MYGModoTarea.Manual)
            {
                fila.HolguraDias = (int)holgura;
                fila.EsCritica = holgura <= 0;
                if (holgura < 0)
                    advertencias.Add("La tarea «" + t.Nombre + "» tiene holgura negativa: sus vínculos y restricciones no permiten cumplir las fechas límite actuales.");
            }
            fila.Advertencias = advertencias.AsReadOnly();
        }

        (decimal Peso, decimal Avance) Resumir(MYGTareaCronograma t)
        {
            if (!t.EsResumen) return (Math.Max(1, t.DuracionDias), Math.Max(1, t.DuracionDias) * t.Avance);
            var descendientes = hijos.GetValueOrDefault(t.Id) ?? new();
            decimal peso = 0, avance = 0;
            foreach (var hijo in descendientes)
            { var agregado = Resumir(hijo); peso += agregado.Peso; avance += agregado.Avance; }
            var valores = descendientes.Select(h => resultado[h.Id]).ToArray();
            var comienzo = valores.Length == 0 ? calendario.Fecha(inicioProyecto) : valores.Min(r => r.Inicio);
            var fin = valores.Length == 0 ? comienzo : valores.Max(r => r.Fin);
            int duracion = valores.Length == 0 || valores.All(v => v.DuracionDias == 0) && comienzo == fin ? 0 : calendario.Contar(comienzo, fin);
            var copia = Copiar(t); copia.Avance = peso == 0 ? 0 : avance / peso;
            resultado[t.Id] = new MYGResultadoTarea { Tarea = copia, Inicio = comienzo, Fin = fin,
                DuracionDias = duracion, DiasCalendario = valores.Length == 0 || duracion == 0 && comienzo == fin ? 0 : (fin - comienzo).Days + 1,
                Avance = copia.Avance, HolguraDias = valores.Select(v => v.HolguraDias).DefaultIfEmpty(0).Min(),
                EsCritica = valores.Any(v => v.EsCritica) };
            return (peso, avance);
        }
        var raices = tareas.Values.Where(t => Vacio(t.PadreId)).ToList();
        foreach (var t in raices) Resumir(t);
        var filas = new List<MYGResultadoTarea>();
        void AgregarFila(MYGTareaCronograma t, int nivel)
        {
            var fila = resultado[t.Id]; fila.Numero = filas.Count + 1; fila.Nivel = nivel; filas.Add(fila);
            if (hijos.TryGetValue(t.Id, out var lista)) foreach (var hijo in lista) AgregarFila(hijo, nivel + 1);
        }
        foreach (var t in raices) AgregarFila(t, 0);
        return new MYGResultadoCronograma { Filas = filas.AsReadOnly(),
            Inicio = filas.Count == 0 ? calendario.Fecha(inicioProyecto) : filas.Min(f => f.Inicio),
            Fin = filas.Count == 0 ? calendario.Fecha(inicioProyecto) : filas.Max(f => f.Fin),
            Advertencias = (plan.AdvertenciasImportacion ?? new()).Concat(filas.SelectMany(f => f.Advertencias)).ToList().AsReadOnly() };
    }

    public static void Validar(MYGCronograma plan) => Calcular(plan);

    private static MYGTareaCronograma Copiar(MYGTareaCronograma t) => new()
    {
        Id = t.Id, PadreId = t.PadreId, PresupuestoId = t.PresupuestoId, PartidaId = t.PartidaId,
        Codigo = t.Codigo, Nombre = t.Nombre, EsResumen = t.EsResumen, Modo = t.Modo, InicioManual = t.InicioManual,
        FechasImportadasDelphin = MYGProyectoStorage.Copia(t.FechasImportadasDelphin),
        DuracionDias = t.DuracionDias, Avance = t.Avance, Notas = t.Notas,
        TipoRestriccion = t.TipoRestriccion, FechaRestriccion = t.FechaRestriccion,
        DuracionInicialDias = t.DuracionInicialDias, CuadrillasIniciales = t.CuadrillasIniciales,
        Reprogramada = t.Reprogramada, NumeroCuadrillas = t.NumeroCuadrillas,
        Partes = MYGProyectoStorage.Copia(t.Partes),
        Responsables = t.Responsables?.ToList(), Predecesoras = t.Predecesoras?.Select(d => d == null ? null :
            new MYGDependenciaCronograma { PredecesoraId = d.PredecesoraId, Tipo = d.Tipo, DesfaseDias = d.DesfaseDias }).ToList(),
        InicioBase = t.InicioBase, FinBase = t.FinBase, DuracionBase = t.DuracionBase
    };
    private static MYGCronograma Copiar(MYGCronograma p) => new()
    {
        FechaInicio = p.FechaInicio, FechaEstado = p.FechaEstado,
        Calendario = MYGProyectoStorage.Copia(p.Calendario),
        Calendarios = MYGProyectoStorage.Copia(p.Calendarios),
        VinculosImportadosDelphin = MYGProyectoStorage.Copia(p.VinculosImportadosDelphin),
        AdvertenciasImportacion = p.AdvertenciasImportacion?.ToList(),
        OpcionesVista = p.OpcionesVista == null ? null : new Dictionary<string, string>(p.OpcionesVista),
        Tareas = p.Tareas?.Select(t => t == null ? null : Copiar(t)).ToList()
    };
    private static void Aplicar(MYGCronograma destino, MYGCronograma copia)
    {
        destino.FechaInicio = copia.FechaInicio; destino.FechaEstado = copia.FechaEstado;
        destino.Calendario = copia.Calendario;
        destino.Calendarios = copia.Calendarios;
        destino.VinculosImportadosDelphin = copia.VinculosImportadosDelphin;
        destino.AdvertenciasImportacion = copia.AdvertenciasImportacion;
        destino.OpcionesVista = copia.OpcionesVista;
        var existentes = destino.Tareas.ToDictionary(t => t.Id, StringComparer.Ordinal);
        destino.Tareas = copia.Tareas.Select(t =>
        {
            if (!existentes.TryGetValue(t.Id, out var anterior)) return t;
            anterior.PadreId = t.PadreId; anterior.PresupuestoId = t.PresupuestoId; anterior.PartidaId = t.PartidaId;
            anterior.Codigo = t.Codigo; anterior.Nombre = t.Nombre; anterior.EsResumen = t.EsResumen;
            anterior.Modo = t.Modo; anterior.InicioManual = t.InicioManual; anterior.DuracionDias = t.DuracionDias;
            anterior.FechasImportadasDelphin = t.FechasImportadasDelphin;
            anterior.TipoRestriccion = t.TipoRestriccion; anterior.FechaRestriccion = t.FechaRestriccion;
            anterior.DuracionInicialDias = t.DuracionInicialDias; anterior.CuadrillasIniciales = t.CuadrillasIniciales;
            anterior.Reprogramada = t.Reprogramada; anterior.NumeroCuadrillas = t.NumeroCuadrillas; anterior.Partes = t.Partes;
            anterior.Avance = t.Avance; anterior.Notas = t.Notas; anterior.Responsables = t.Responsables;
            anterior.Predecesoras = t.Predecesoras; anterior.InicioBase = t.InicioBase;
            anterior.FinBase = t.FinBase; anterior.DuracionBase = t.DuracionBase;
            return anterior;
        }).ToList();
    }
    private static MYGCronograma Editar(MYGCronograma plan, Action<MYGCronograma> accion)
    {
        ArgumentNullException.ThrowIfNull(plan); Validar(plan);
        var copia = Copiar(plan); accion(copia); Validar(copia); Aplicar(plan, copia); return plan;
    }

    private static string IdOrigen(string presupuestoId, string partidaId) => partidaId == null
        ? "PRES:" + presupuestoId : "ITEM:" + presupuestoId.Length.ToString(CultureInfo.InvariantCulture) + ":" + presupuestoId + ":" + partidaId;

    private static List<MYGTareaCronograma> Origen(MYGProyectoDocumento doc)
    {
        ArgumentNullException.ThrowIfNull(doc);
        if (doc.Presupuestos == null || doc.Presupuestos.Any(p => p == null || Vacio(p.Id)) ||
            doc.Presupuestos.Select(p => p.Id).Distinct(StringComparer.Ordinal).Count() != doc.Presupuestos.Count)
            throw Error("El proyecto contiene presupuestos incompletos o repetidos.");
        var filas = new List<MYGTareaCronograma>();
        foreach (var p in doc.Presupuestos.OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.Ordinal))
        {
            var raiz = new MYGTareaCronograma { Id = IdOrigen(p.Id, null), PresupuestoId = p.Id,
                Codigo = p.Item, Nombre = Vacio(p.Nombre) ? "Presupuesto" : p.Nombre, EsResumen = true, DuracionDias = 0 };
            filas.Add(raiz);
            if (p.Items == null || p.Items.Any(i => i == null || Vacio(i.Id)) || p.Items.Select(i => i.Id).Distinct(StringComparer.Ordinal).Count() != p.Items.Count)
                throw Error("El presupuesto contiene partidas incompletas o repetidas.");
            foreach (var i in MYGOrdenPresupuestos.FilasOrdenadas(p))
                filas.Add(new MYGTareaCronograma { Id = IdOrigen(p.Id, i.Id), PresupuestoId = p.Id, PartidaId = i.Id,
                    PadreId = Vacio(i.ParentId) ? raiz.Id : IdOrigen(p.Id, i.ParentId), Codigo = i.Item,
                    Nombre = Vacio(i.Descripcion) ? "Partida" : i.Descripcion, EsResumen = MYGProyectoStorage.EsTitulo(i),
                    DuracionDias = MYGProyectoStorage.EsTitulo(i) ? 0 : 1 });
        }
        return filas;
    }

    public static MYGCronograma CrearDesdePresupuestos(MYGProyectoDocumento doc)
    {
        ArgumentNullException.ThrowIfNull(doc);
        var p = new MYGCronograma { FechaInicio = (doc.Datos?.FechaInicio ?? doc.Datos?.FechaElaboracion ?? DateTime.Today).Date,
            Tareas = Origen(doc) };
        Validar(p); return p;
    }

    /// <summary>Las tareas cuyo origen desaparece se conservan como personalizadas,
    /// con avance, notas, vínculos y línea base. Los vínculos incompatibles con un
    /// nodo convertido en resumen se retiran, sin modificar el presupuesto.</summary>
    public static void SincronizarPresupuestos(MYGProyectoDocumento doc, MYGCronograma plan)
    {
        var origen = Origen(doc);
        Editar(plan, copia =>
        {
            var anteriores = new Dictionary<(string Presupuesto, string Partida), MYGTareaCronograma>();
            foreach (var t in copia.Tareas.Where(t => !Vacio(t.PresupuestoId)))
                if (!anteriores.TryAdd((t.PresupuestoId, t.PartidaId ?? ""), t))
                    throw Error("Hay tareas repetidas para el mismo origen del presupuesto.");
            var vigentes = new HashSet<string>(StringComparer.Ordinal);
            var equivalencias = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var o in origen)
            {
                if (!anteriores.TryGetValue((o.PresupuestoId, o.PartidaId ?? ""), out var t))
                { t = Copiar(o); if (copia.Tareas.Any(x => x.Id == t.Id)) t.Id = MYGProyectoStorage.NuevoId(); copia.Tareas.Add(t); }
                t.Nombre = o.Nombre; t.Codigo = o.Codigo;
                t.EsResumen = o.EsResumen || copia.Tareas.Any(x => x.PadreId == t.Id);
                vigentes.Add(t.Id); equivalencias.Add(o.Id, t.Id);
            }
            foreach (var o in origen)
            {
                var t = copia.Tareas.First(t => t.Id == equivalencias[o.Id]);
                t.PadreId = o.PadreId == null ? null : equivalencias.GetValueOrDefault(o.PadreId)
                    ?? throw Error("La jerarquía de origen del presupuesto contiene un padre inexistente.");
            }
            foreach (var t in copia.Tareas.Where(t => !Vacio(t.PresupuestoId) && !vigentes.Contains(t.Id)))
            { t.PresupuestoId = null; t.PartidaId = null; }
            var resumenes = copia.Tareas.Where(t => t.EsResumen).Select(t => t.Id).ToHashSet(StringComparer.Ordinal);
            foreach (var t in copia.Tareas)
            { if (t.EsResumen) t.Predecesoras.Clear(); else t.Predecesoras.RemoveAll(d => resumenes.Contains(d.PredecesoraId)); }
        });
    }

    public static MYGTareaCronograma AgregarTarea(MYGCronograma plan, string padreId, string nombre, bool hito = false)
    {
        if (Vacio(nombre)) throw Error("Indique el nombre de la tarea.");
        var nueva = new MYGTareaCronograma { PadreId = Vacio(padreId) ? null : padreId, Nombre = nombre.Trim(), DuracionDias = hito ? 0 : 1 };
        Editar(plan, copia =>
        {
            if (nueva.PadreId != null)
            { var padre = copia.Tareas.FirstOrDefault(t => t.Id == nueva.PadreId) ?? throw Error("El resumen seleccionado ya no existe."); padre.EsResumen = true; }
            copia.Tareas.Add(nueva);
        });
        return plan.Tareas.Single(t => t.Id == nueva.Id);
    }

    public static void EliminarTarea(MYGCronograma plan, string id) => Editar(plan, copia =>
    {
        if (!copia.Tareas.Any(t => t.Id == id)) throw Error("La tarea seleccionada ya no existe.");
        var borrar = new HashSet<string>(StringComparer.Ordinal) { id };
        bool cambio;
        do { cambio = false; foreach (var t in copia.Tareas) if (!Vacio(t.PadreId) && borrar.Contains(t.PadreId)) cambio |= borrar.Add(t.Id); } while (cambio);
        copia.Tareas.RemoveAll(t => borrar.Contains(t.Id));
        foreach (var t in copia.Tareas) t.Predecesoras.RemoveAll(d => borrar.Contains(d.PredecesoraId));
    });

    public static void EstablecerLineaBase(MYGCronograma plan)
    {
        var calculo = Calcular(plan).Filas.ToDictionary(r => r.Tarea.Id, StringComparer.Ordinal);
        Editar(plan, copia => { foreach (var t in copia.Tareas)
            { var r = calculo[t.Id]; t.InicioBase = r.Inicio; t.FinBase = r.Fin; t.DuracionBase = r.DuracionDias; } });
    }
    public static void QuitarLineaBase(MYGCronograma plan) => Editar(plan, copia =>
    { foreach (var t in copia.Tareas) { t.InicioBase = null; t.FinBase = null; t.DuracionBase = null; } });

    public static List<MYGDependenciaCronograma> LeerPredecesoras(string texto,
        IReadOnlyList<MYGResultadoTarea> filas, string tareaId)
    {
        ArgumentNullException.ThrowIfNull(filas);
        var actual = filas.FirstOrDefault(f => f.Tarea.Id == tareaId) ?? throw Error("La tarea seleccionada ya no existe.");
        if (actual.Tarea.EsResumen) throw Error("Las predecesoras se asignan a tareas o hitos, no a resúmenes.");
        var resultado = new List<MYGDependenciaCronograma>();
        if (Vacio(texto)) return resultado;
        var vistas = new HashSet<string>(StringComparer.Ordinal);
        foreach (var token in texto.Split(';', ','))
        {
            var coincidencia = Regex.Match(token, @"^\s*(\d+)\s*(FC|CC|FF|CF)?\s*([+-]\s*\d+)?\s*$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            if (!coincidencia.Success || !int.TryParse(coincidencia.Groups[1].Value, NumberStyles.None, CultureInfo.InvariantCulture, out int numero))
                throw Error("Predecesora no válida. Use, por ejemplo: 3FC+2;5CC-1.");
            var fila = filas.FirstOrDefault(f => f.Numero == numero);
            if (fila == null || fila.Tarea.EsResumen || fila.Tarea.Id == tareaId || !vistas.Add(fila.Tarea.Id))
                throw Error("La fila predecesora no existe, es un resumen, se repite o referencia la misma tarea.");
            var tipo = coincidencia.Groups[2].Success ? Enum.Parse<MYGTipoVinculo>(coincidencia.Groups[2].Value.ToUpperInvariant()) : MYGTipoVinculo.FC;
            int desfase = 0;
            if (coincidencia.Groups[3].Success && !int.TryParse(Regex.Replace(coincidencia.Groups[3].Value, @"\s", ""), NumberStyles.AllowLeadingSign,
                CultureInfo.InvariantCulture, out desfase)) throw Error("El desfase está fuera del rango permitido.");
            resultado.Add(new MYGDependenciaCronograma { PredecesoraId = fila.Tarea.Id, Tipo = tipo, DesfaseDias = desfase });
        }
        return resultado;
    }

    public static string FormatoPredecesoras(MYGTareaCronograma tarea, IReadOnlyList<MYGResultadoTarea> filas)
    {
        ArgumentNullException.ThrowIfNull(tarea); ArgumentNullException.ThrowIfNull(filas);
        return string.Join(";", tarea.Predecesoras.Select(d =>
        {
            var fila = filas.FirstOrDefault(f => f.Tarea.Id == d.PredecesoraId) ?? throw Error("La predecesora ya no pertenece al cronograma.");
            return fila.Numero.ToString(CultureInfo.InvariantCulture) + d.Tipo + (d.DesfaseDias == 0 ? "" :
                (d.DesfaseDias > 0 ? "+" : "") + d.DesfaseDias.ToString(CultureInfo.InvariantCulture));
        }));
    }

    private static List<string> Seleccion(MYGCronograma copia, IEnumerable<string> ids)
    {
        if (ids == null) throw new ArgumentNullException(nameof(ids));
        var valores = ids.ToList();
        if (valores.Count == 0 || valores.Any(Vacio) || valores.Distinct(StringComparer.Ordinal).Count() != valores.Count ||
            valores.Any(id => !copia.Tareas.Any(t => t.Id == id && !t.EsResumen)))
            throw Error("Seleccione tareas o hitos existentes, sin resúmenes ni filas repetidas.");
        return valores;
    }
    public static void Vincular(MYGCronograma plan, IEnumerable<string> ids, MYGTipoVinculo tipo = MYGTipoVinculo.FC)
    {
        if (!Enum.IsDefined(tipo)) throw Error("El tipo de vínculo no es válido.");
        var seleccion = ids?.ToList() ?? throw new ArgumentNullException(nameof(ids));
        Editar(plan, copia =>
        {
            var valores = Seleccion(copia, seleccion);
            if (valores.Count < 2) throw Error("Seleccione al menos dos tareas para vincularlas.");
            for (int n = 1; n < valores.Count; n++)
            {
                var t = copia.Tareas.Single(t => t.Id == valores[n]);
                var vinculo = t.Predecesoras.FirstOrDefault(d => d.PredecesoraId == valores[n - 1]);
                if (vinculo == null) t.Predecesoras.Add(new MYGDependenciaCronograma { PredecesoraId = valores[n - 1], Tipo = tipo });
                else vinculo.Tipo = tipo;
            }
        });
    }
    /// <summary>Con varias tareas elimina los vínculos entre ellas; con una sola,
    /// retira sus vínculos entrantes y salientes.</summary>
    public static void Desvincular(MYGCronograma plan, IEnumerable<string> ids)
    {
        var seleccion = ids?.ToList() ?? throw new ArgumentNullException(nameof(ids));
        Editar(plan, copia =>
        {
            var valores = Seleccion(copia, seleccion).ToHashSet(StringComparer.Ordinal);
            foreach (var t in copia.Tareas)
                t.Predecesoras.RemoveAll(d => valores.Count == 1 ? valores.Contains(t.Id) || valores.Contains(d.PredecesoraId)
                    : valores.Contains(t.Id) && valores.Contains(d.PredecesoraId));
        });
    }
}
