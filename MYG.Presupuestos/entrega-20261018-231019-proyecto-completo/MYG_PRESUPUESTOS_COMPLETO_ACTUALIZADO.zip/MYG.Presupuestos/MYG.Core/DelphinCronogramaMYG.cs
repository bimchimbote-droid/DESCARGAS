using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

// El modo nativo y la instantánea de fechas son independientes: consultar un
// Gantt no debe convertirlo en manual, desplazarlo ni unir tramos separados.
internal static class DelphinCronogramaMYG
{
    // Las lecturas anteriores no versionaban la correspondencia del modo.
    internal const int VersionLecturaActual = 1;
    internal static MYGCronograma Leer(SqliteConnection conexion, MYGProyectoDocumento documento, SqliteTransaction transaccion = null)
    {
        var costos = Filas(conexion, transaccion, "costo_unitario", "id_costounitario", "duracion", "duracion_new", "es_hito", "task_mode",
            "fecha_inicio", "fecha_fin", "porcentaje_completado", "tipo_restriccion", "fecha_restriccion")
            .ToDictionary(f => f.Texto("id_costounitario"), StringComparer.OrdinalIgnoreCase);
        var programas = Filas(conexion, transaccion, "programacion_costo", "id_programacion", "id_costounitario", "start_date", "end_date",
            "fecha_inicio", "fecha_fin", "duracion", "duracion_new", "cantidad", "porcentaje").GroupBy(f => f.Texto("id_costounitario"), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);
        var ids = documento.Presupuestos.SelectMany(p => p.Items).Select(i => i.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (!costos.Any(x => ids.Contains(x.Key) && Fecha(x.Value.Texto("fecha_inicio")).HasValue) && !programas.Keys.Any(ids.Contains)) return null;
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(documento);
        plan.FechaEstado = plan.FechaInicio;
        LeerCalendario(conexion, transaccion, documento, plan);
        var mapa = plan.Tareas.Where(t => !string.IsNullOrWhiteSpace(t.PartidaId)).ToDictionary(t => t.PartidaId, StringComparer.OrdinalIgnoreCase);
        foreach (var tarea in plan.Tareas.Where(t => !t.EsResumen))
        {
            costos.TryGetValue(tarea.PartidaId, out var costo);
            // El esquema demuestra que existen estos campos, pero no documenta
            // la numeración del selector nativo. No convertirla por coincidencia
            // con los enums de MYG o Project ni invalidar la instantánea al abrir.
            string tipoNativo = costo?.Texto("tipo_restriccion"), fechaNativa = costo?.Texto("fecha_restriccion");
            if (!string.IsNullOrWhiteSpace(tipoNativo) && costo.NumeroOpcional("tipo_restriccion") != 0 ||
                !string.IsNullOrWhiteSpace(fechaNativa))
                plan.AdvertenciasImportacion.Add("La restricción nativa Delphin de «" + tarea.Nombre + "» (tipo=" +
                    (string.IsNullOrWhiteSpace(tipoNativo) ? "sin indicar" : tipoNativo) +
                    (string.IsNullOrWhiteSpace(fechaNativa) ? "" : ", fecha=" + fechaNativa) +
                    ") se conserva en el archivo y en sus fechas importadas. Su código nativo aún no se traduce a una restricción MYG.");
            var tramos = new List<MYGTramoImportadoDelphin>();
            foreach (var fila in programas.GetValueOrDefault(tarea.PartidaId) ?? new())
            {
                var inicioTramo = Fecha(fila.Texto("start_date")) ?? Fecha(fila.Texto("fecha_inicio"));
                var finTramo = Fecha(fila.Texto("end_date")) ?? Fecha(fila.Texto("fecha_fin"));
                if (!inicioTramo.HasValue || !finTramo.HasValue || finTramo < inicioTramo)
                { plan.AdvertenciasImportacion.Add("No se pudo representar el tramo Delphin «" + fila.Texto("id_programacion") + "»: sus fechas no son válidas."); continue; }
                tramos.Add(new() { Id = fila.Texto("id_programacion"), Inicio = inicioTramo.Value, Fin = finTramo.Value,
                    Duracion = fila.NumeroOpcional("duracion_new") is > 0 ? fila.Numero("duracion_new") : fila.Numero("duracion"),
                    Cantidad = fila.Numero("cantidad"), Porcentaje = fila.Numero("porcentaje") });
            }
            // La fila de la tarea contiene sus fechas; los tramos describen su
            // distribución. Solo se usan como alternativa a un par incompleto.
            var inicio = Fecha(costo?.Texto("fecha_inicio"));
            var fin = Fecha(costo?.Texto("fecha_fin"));
            if ((!inicio.HasValue || !fin.HasValue || fin < inicio) && tramos.Count > 0)
            { inicio = tramos.Min(t => t.Inicio); fin = tramos.Max(t => t.Fin); }
            if (!inicio.HasValue || !fin.HasValue || fin < inicio)
            {
                plan.AdvertenciasImportacion.Add("La partida «" + tarea.Nombre + "» carece de fechas de programación válidas; requiere programación en MYG.");
                continue;
            }
            decimal duracion = LeerDuracion(costo, tramos, plan.Calendario, inicio.Value, fin.Value);
            if (duracion < 0 || duracion > 36500 || decimal.Truncate(duracion) != duracion)
            {
                plan.AdvertenciasImportacion.Add("La duración fraccionaria de «" + tarea.Nombre + "» se representa en días laborables completos; se conservan las fechas y tramos nativos.");
                duracion = Math.Clamp(decimal.Ceiling(duracion), 0, 36500);
            }
            tarea.Modo = LeerModo(costo, tarea, plan);
            tarea.InicioManual = inicio.Value;
            tarea.DuracionDias = (int)duracion;
            tarea.Avance = Math.Clamp(costo?.Numero("porcentaje_completado") ?? 0, 0, 100);
            tarea.FechasImportadasDelphin = new() { Inicio = inicio.Value, Fin = fin.Value, DuracionDias = tarea.DuracionDias, ModoOriginal = tarea.Modo,
                VersionLectura = VersionLecturaActual,
                Tramos = tramos.OrderBy(t => t.Inicio).ThenBy(t => t.Id, StringComparer.Ordinal).ToList() };
        }
        foreach (var fila in Filas(conexion, transaccion, "dependencia_tarea", "id_dependencia", "id_costounitarioorigen", "id_costounitariodestino",
            "id_programaciondestino", "id_proyecto", "tipo", "lag_size", "id_tituloorigen", "id_titulodestino", "id_presupuestoorigen", "id_presupuestodestino"))
        {
            if (!string.IsNullOrWhiteSpace(fila.Texto("id_proyecto")) && fila.Texto("id_proyecto") != documento.Id) continue;
            string origen = fila.Texto("id_costounitarioorigen"), destino = fila.Texto("id_costounitariodestino");
            if (string.IsNullOrWhiteSpace(origen)) origen = fila.Texto("id_tituloorigen");
            if (string.IsNullOrWhiteSpace(destino)) destino = fila.Texto("id_titulodestino");
            if (string.IsNullOrWhiteSpace(origen)) origen = fila.Texto("id_presupuestoorigen");
            if (string.IsNullOrWhiteSpace(destino)) destino = fila.Texto("id_presupuestodestino");
            var nativo = new MYGVinculoImportadoDelphin { Id = fila.Texto("id_dependencia"), OrigenId = origen, DestinoId = destino,
                ProgramacionDestinoId = fila.Texto("id_programaciondestino"), Tipo = (int)fila.Numero("tipo"), Desfase = fila.Numero("lag_size") };
            plan.VinculosImportadosDelphin.Add(nativo);
            if (!mapa.TryGetValue(origen, out var anterior) || !mapa.TryGetValue(destino, out var siguiente) || anterior.EsResumen || siguiente.EsResumen ||
                nativo.Tipo < 0 || nativo.Tipo > 3 || nativo.Desfase != decimal.Truncate(nativo.Desfase) || nativo.Desfase < int.MinValue || nativo.Desfase > int.MaxValue ||
                siguiente.Predecesoras.Any(d => d.PredecesoraId == anterior.Id))
            {
                plan.AdvertenciasImportacion.Add("El vínculo Delphin «" + nativo.Id + "» se conserva en el archivo; MYG no puede calcularlo como vínculo entre tareas individuales.");
                continue;
            }
            siguiente.Predecesoras.Add(new() { PredecesoraId = anterior.Id, Tipo = (MYGTipoVinculo)nativo.Tipo, DesfaseDias = (int)nativo.Desfase });
        }
        // Un ciclo nativo no debe impedir consultar las fechas guardadas. Sus
        // vínculos íntegros quedan disponibles en VinculosImportadosDelphin.
        if (TieneCiclo(plan.Tareas))
        {
            foreach (var tarea in plan.Tareas) tarea.Predecesoras.Clear();
            plan.AdvertenciasImportacion.Add("La red Delphin contiene un ciclo. Se muestran las fechas guardadas y se conservan sus vínculos originales, sin calcular la red circular.");
        }
        string firmaCalendario = MYGMotorCronograma.FirmaCalendarioDelphin(plan.Calendario);
        var tareasPorId = plan.Tareas.ToDictionary(t => t.Id, StringComparer.Ordinal);
        foreach (var tarea in plan.Tareas.Where(t => t.FechasImportadasDelphin != null))
        {
            tarea.FechasImportadasDelphin.FirmaPredecesoras = MYGMotorCronograma.FirmaPredecesorasDelphin(tarea);
            tarea.FechasImportadasDelphin.FirmaCalendario = firmaCalendario;
            tarea.FechasImportadasDelphin.InicioProyecto = plan.FechaInicio;
        }
        var resultadoInicial = MYGMotorCronograma.Calcular(plan).Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var tarea in plan.Tareas.Where(t => t.FechasImportadasDelphin != null))
            tarea.FechasImportadasDelphin.FirmaAntecesoras = MYGMotorCronograma.FirmaAntecesorasDelphin(tarea, tareasPorId, resultadoInicial);
        MYGMotorCronograma.Validar(plan);
        return plan;
    }

    private static MYGModoTarea LeerModo(Fila costo, MYGTareaCronograma tarea, MYGCronograma plan)
    {
        // Delphin guarda 1 para automática y 0 para manual. La correspondencia
        // automática se contrastó con el SQLite de CHUMUCH y su Gantt nativo.
        // Las bases anteriores sin ese campo mantienen el modo predeterminado.
        string valor = costo?.Texto("task_mode");
        if (string.IsNullOrWhiteSpace(valor)) return MYGModoTarea.Automatica;
        decimal? modo = costo.NumeroOpcional("task_mode");
        if (modo == 1) return MYGModoTarea.Automatica;
        if (modo == 0) return MYGModoTarea.Manual;
        plan.AdvertenciasImportacion.Add("El modo de tarea Delphin de «" + tarea.Nombre + "» no es reconocido (task_mode=" + valor +
            "); se utiliza Automática y se conservan las fechas importadas.");
        return MYGModoTarea.Automatica;
    }

    private static decimal LeerDuracion(Fila costo, List<MYGTramoImportadoDelphin> tramos, MYGCalendarioTrabajo calendario,
        DateTime inicio, DateTime fin)
    {
        string hito = costo?.Texto("es_hito");
        if (string.Equals(hito, "S", StringComparison.OrdinalIgnoreCase)) return 0;
        decimal? moderna = costo?.NumeroOpcional("duracion_new"), anterior = costo?.NumeroOpcional("duracion");
        if (moderna is > 0) return moderna.Value;
        if (anterior is > 0) return anterior.Value;
        // Un cero guardado sin indicador de hito conserva la compatibilidad con
        // las versiones anteriores; un NULL no convierte un trabajo en hito.
        bool noEsHito = string.Equals(hito, "N", StringComparison.OrdinalIgnoreCase);
        if (!noEsHito && (moderna == 0 || anterior == 0)) return 0;
        decimal? duracionTramos = tramos.Count > 0 ? tramos.Sum(t => t.Duracion) : null;
        if (duracionTramos is > 0) return duracionTramos.Value;
        if (!noEsHito && (moderna.HasValue || anterior.HasValue || duracionTramos.HasValue))
            return moderna ?? anterior ?? duracionTramos.Value;
        return Math.Max(1, calendario.ContarDiasLaborables(inicio, fin));
    }

    private static bool TieneCiclo(List<MYGTareaCronograma> tareas)
    {
        var mapa = tareas.ToDictionary(t => t.Id, StringComparer.Ordinal);
        var estado = new Dictionary<string, int>(StringComparer.Ordinal);
        bool Visitar(MYGTareaCronograma t)
        {
            if (estado.TryGetValue(t.Id, out int v)) return v == 1;
            estado[t.Id] = 1;
            foreach (var d in t.Predecesoras) if (Visitar(mapa[d.PredecesoraId])) return true;
            estado[t.Id] = 2; return false;
        }
        return tareas.Any(Visitar);
    }

    private static void LeerCalendario(SqliteConnection c, SqliteTransaction t, MYGProyectoDocumento documento, MYGCronograma plan)
    {
        string id = documento.Datos?.CalendarioId?.ToString(CultureInfo.InvariantCulture);
        if (string.IsNullOrWhiteSpace(id)) return;
        var horarios = Filas(c, t, "horario", "id_calendario", "dia_semana", "hora_inicio", "hora_fin", "es_laborable")
            .Where(f => f.Texto("id_calendario") == id && !f.Texto("es_laborable").Equals("N", StringComparison.OrdinalIgnoreCase)).ToList();
        var dias = horarios.Select(f => (int)f.Numero("dia_semana")).Where(d => d >= 0 && d <= 6).Distinct().Select(d => (DayOfWeek)d).ToList();
        if (dias.Count > 0) plan.Calendario.DiasLaborables = dias;
        else plan.AdvertenciasImportacion.Add("El calendario Delphin no contiene una semana laborable válida; se utiliza lunes a viernes.");
        var jornadas = horarios.GroupBy(f => f.Texto("dia_semana")).Select(g => g.Sum(f =>
        {
            var inicio = FechaHora(f.Texto("hora_inicio")); var fin = FechaHora(f.Texto("hora_fin"));
            return inicio.HasValue && fin.HasValue && fin > inicio ? (decimal)(fin.Value - inicio.Value).TotalHours : 0;
        })).Where(h => h > 0 && h <= 24).ToList();
        if (jornadas.Count > 0) plan.Calendario.HorasPorDia = jornadas.Max();
        if (jornadas.Distinct().Count() > 1) plan.AdvertenciasImportacion.Add("El calendario Delphin tiene jornadas de distinta duración. MYG conserva las fechas nativas y usa la jornada máxima para tareas nuevas.");
        foreach (var f in Filas(c, t, "excepcion", "id_calendario", "nombre_excepcion", "fecha_inicio", "fecha_fin", "tipo_excepcion", "dia_mes", "numero_mes").Where(f => f.Texto("id_calendario") == id))
        {
            int mes = (int)f.Numero("numero_mes"), dia = (int)f.Numero("dia_mes");
            if (f.Numero("tipo_excepcion") == 4 && mes >= 1 && mes <= 12 && dia >= 1 && dia <= DateTime.DaysInMonth(2000, mes))
            { plan.Calendario.FeriadosAnuales.Add(new() { Mes = mes, Dia = dia }); continue; }
            plan.AdvertenciasImportacion.Add("La excepción de calendario «" + f.Texto("nombre_excepcion") + "» requiere una regla que MYG aún no calcula; las fechas nativas se conservan.");
        }
    }

    private static DateTime? FechaHora(string valor) => DateTime.TryParseExact(valor,
        new[] { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd", "O", "dd/MM/yyyy", "d/M/yyyy" },
        CultureInfo.InvariantCulture, DateTimeStyles.None, out var fecha) ? fecha : null;
    private static DateTime? Fecha(string valor) => FechaHora(valor)?.Date ??
        (DateTime.TryParse(valor, CultureInfo.GetCultureInfo("es-PE"), DateTimeStyles.None, out var fecha) ? fecha.Date : null);
    private static List<Fila> Filas(SqliteConnection c, SqliteTransaction t, string tabla, params string[] campos)
    {
        using var columnas = c.CreateCommand(); columnas.Transaction = t; columnas.CommandText = "PRAGMA table_info(\"" + tabla + "\")";
        var nombres = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var r = columnas.ExecuteReader()) while (r.Read()) nombres.Add(r.GetString(1));
        if (nombres.Count == 0) return new();
        using var cmd = c.CreateCommand(); cmd.Transaction = t;
        cmd.CommandText = "SELECT " + string.Join(",", campos.Select(f => nombres.Contains(f) ? "\"" + f + "\"" : "NULL")) + " FROM \"" + tabla + "\"";
        using var lector = cmd.ExecuteReader(); var filas = new List<Fila>();
        while (lector.Read())
        {
            var fila = new Fila();
            for (int n = 0; n < campos.Length; n++) fila.Valores[campos[n]] = lector.IsDBNull(n) ? null : lector.GetValue(n);
            filas.Add(fila);
        }
        return filas;
    }
    private sealed class Fila
    {
        internal Dictionary<string, object> Valores { get; } = new(StringComparer.OrdinalIgnoreCase);
        internal string Texto(string campo) => Convert.ToString(Valores.GetValueOrDefault(campo), CultureInfo.InvariantCulture) ?? "";
        internal decimal Numero(string campo) => decimal.TryParse(Texto(campo), NumberStyles.Float, CultureInfo.InvariantCulture, out var n) ? n : 0;
        internal decimal? NumeroOpcional(string campo) => decimal.TryParse(Texto(campo), NumberStyles.Float, CultureInfo.InvariantCulture, out var n) ? n : null;
    }
}
