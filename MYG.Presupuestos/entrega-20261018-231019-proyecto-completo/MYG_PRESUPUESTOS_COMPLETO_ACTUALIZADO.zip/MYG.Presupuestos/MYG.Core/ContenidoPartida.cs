using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;

namespace MYG_2027;

/// <summary>Presencia de documentos y origen activo del metrado por partida.</summary>
public static class MYGContenidoPartida
{
    private static readonly Plantilla Estandar = new(MYGPlantillasMetrado.Estandar);
    private static readonly Plantilla Aceros = new(MYGPlantillasMetrado.Aceros);
    private static readonly ConditionalWeakTable<Dictionary<string, string>, Plantilla> plantillasIniciales = new();

    /// <summary>Registra únicamente el contenido automático al crear una hoja
    /// configurada. No debe llamarse al abrir o editar una hoja existente.</summary>
    public static void RegistrarContenidoInicialPlantilla(MYGHojaMetrado hoja)
    {
        ArgumentNullException.ThrowIfNull(hoja);
        if (hoja.IdPlantilla is not (MYGPlantillasMetrado.Estandar or MYGPlantillasMetrado.Aceros))
            throw new ArgumentException("Sólo se puede registrar una plantilla integrada.", nameof(hoja));
        hoja.ContenidoInicialPlantilla = hoja.Celdas.Where(c => !string.IsNullOrWhiteSpace(c.Value?.Contenido))
            .ToDictionary(c => c.Key, c => c.Value.Contenido, StringComparer.OrdinalIgnoreCase);
    }

    private static Plantilla ObtenerPlantilla(MYGHojaMetrado hoja)
    {
        string id = MYGPlantillasMetrado.Identificar(hoja);
        if (id is not (MYGPlantillasMetrado.Estandar or MYGPlantillasMetrado.Aceros)) return null;
        if (hoja.ContenidoInicialPlantilla != null)
        {
            var plantilla = plantillasIniciales.GetValue(hoja.ContenidoInicialPlantilla, contenido => new(id, contenido));
            if (plantilla.Id == id) return plantilla;
        }
        return id == MYGPlantillasMetrado.Estandar ? Estandar : Aceros;
    }

    public static bool TieneEspecificacionGuardada(MYGDatosPartida datos) => datos != null &&
        !datos.EspecificacionEsBorrador && (!string.IsNullOrWhiteSpace(datos.EspecificacionTexto) ||
        TieneContenidoRtf(datos.EspecificacionRtf));

    /// <summary>Indica que la cantidad usa actualmente el metrado de Excel.</summary>
    public static bool TieneMetradoExcelActivo(MYGDatosPartida datos) =>
        datos?.FuenteMetrado == MYGFuenteMetrado.Excel && TieneMetradoExcel(datos);

    public static bool TieneMetradoExcel(MYGDatosPartida datos)
    {
        var hoja = datos?.Hoja;
        if (hoja?.Celdas == null) return false;
        var plantilla = ObtenerPlantilla(hoja);
        if (plantilla == null) return hoja.Celdas.Values.Any(c => !string.IsNullOrWhiteSpace(c?.Contenido));

        // El caso habitual sólo compara el contenido con una plantilla estática.
        // No se ejecutan fórmulas ni se crean hojas/calculadoras por cada fila.
        if (hoja.Celdas.All(c => string.IsNullOrWhiteSpace(c.Value?.Contenido) ||
            plantilla.Contenidos.TryGetValue(c.Key, out var original) && Iguales(c.Value.Contenido, original))) return false;
        var mapa = new MapaPlantilla(hoja, plantilla);
        foreach (var entrada in hoja.Celdas)
        {
            string texto = entrada.Value?.Contenido;
            if (string.IsNullOrWhiteSpace(texto)) continue;
            if (!Coordenadas(entrada.Key, out var posicion) || !mapa.EsContenidoAutomatico(posicion, texto)) return true;
        }
        return false;
    }

    /// <summary>Filas de detalle que sólo contienen las fórmulas automáticas
    /// de una plantilla vacía. La consulta no elimina celdas ni cambia la hoja.</summary>
    internal static IReadOnlyList<int> FilasVaciasPlantilla(MYGHojaMetrado hoja)
    {
        if (hoja?.Celdas == null) return Array.Empty<int>();
        var plantilla = ObtenerPlantilla(hoja);
        // Las hojas importadas conservan su distribución libre.
        if (plantilla == null) return Array.Empty<int>();
        var mapa = new MapaPlantilla(hoja, plantilla, detectarCuerpoAntiguo: true);
        if (mapa.UltimaFila < mapa.PrimeraFila) return Array.Empty<int>();
        var ocupadas = new HashSet<int> { MYGHojaCalculo.Coordenadas(hoja.CeldaTotal).Fila };
        foreach (var entrada in hoja.Celdas)
        {
            if (string.IsNullOrWhiteSpace(entrada.Value?.Contenido)) continue;
            var posicion = MYGHojaCalculo.Coordenadas(entrada.Key);
            if (posicion.Fila >= mapa.PrimeraFila && posicion.Fila <= mapa.UltimaFila &&
                !mapa.EsContenidoAutomatico(posicion, entrada.Value.Contenido)) ocupadas.Add(posicion.Fila);
        }
        // Una combinación vertical mantiene su altura completa, aunque sólo
        // su primera fila contenga texto o una fórmula.
        foreach (string rango in hoja.RangosCombinados)
        {
            var extremos = rango.Split(':');
            int primera = MYGHojaCalculo.Coordenadas(extremos[0]).Fila;
            int ultima = MYGHojaCalculo.Coordenadas(extremos[^1]).Fila;
            if (primera == ultima) continue;
            for (int fila = Math.Max(primera, mapa.PrimeraFila); fila <= Math.Min(ultima, mapa.UltimaFila); fila++)
                ocupadas.Add(fila);
        }
        return Enumerable.Range(mapa.PrimeraFila, mapa.UltimaFila - mapa.PrimeraFila + 1)
            .Where(fila => !ocupadas.Contains(fila)).ToArray();
    }

    private static bool Iguales(string a, string b) => string.Equals(a?.Trim(), b?.Trim(), StringComparison.OrdinalIgnoreCase);
    private static bool Coordenadas(string direccion, out (int Fila, int Columna) posicion)
    {
        posicion = default;
        try { posicion = MYGHojaCalculo.Coordenadas(direccion); return true; }
        catch (FormatException) { return false; }
        catch (OverflowException) { return false; }
    }

    private sealed class Plantilla
    {
        internal readonly string Id;
        internal readonly IReadOnlyDictionary<string, string> Contenidos;
        internal readonly Dictionary<int, string> Cabeceras;
        internal readonly Dictionary<(int Fila, int Columna), string> Textos = new();
        internal readonly Dictionary<(int Fila, int Columna), Formula> Formulas = new();
        internal readonly int FinCuerpo;
        internal Plantilla(string id) : this(id, MYGPlantillasMetrado.Crear(id).Celdas
            .ToDictionary(c => c.Key, c => c.Value.Contenido, StringComparer.OrdinalIgnoreCase)) { }
        internal Plantilla(string id, IReadOnlyDictionary<string, string> contenidos)
        {
            Id = id; Contenidos = contenidos;
            FinCuerpo = id == MYGPlantillasMetrado.Estandar ? 15 : 13;
            Cabeceras = contenidos.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == 2 &&
                !string.IsNullOrWhiteSpace(c.Value)).ToDictionary(c => MYGHojaCalculo.Coordenadas(c.Key).Columna, c => c.Value);
            foreach (var celda in contenidos)
            {
                if (string.IsNullOrWhiteSpace(celda.Value)) continue;
                var posicion = MYGHojaCalculo.Coordenadas(celda.Key);
                if (celda.Value.StartsWith('='))
                {
                    // Todas las filas del cuerpo comparten la misma fórmula relativa.
                    if (posicion.Fila == 3 || posicion.Fila > FinCuerpo) Formulas[posicion] = new(celda.Value);
                }
                else Textos[posicion] = celda.Value;
            }
        }
    }

    private sealed class MapaPlantilla
    {
        private readonly Plantilla plantilla;
        private readonly Dictionary<int, int> columnas = new(), filas = new();
        private readonly Dictionary<(int Fila, int Columna), string> textos = new();
        private readonly int primera, ultima;
        internal int PrimeraFila => primera;
        internal int UltimaFila => ultima;

        internal MapaPlantilla(MYGHojaMetrado hoja, Plantilla plantilla, bool detectarCuerpoAntiguo = false)
        {
            this.plantilla = plantilla;
            var celdas = hoja.Celdas.Where(c => !string.IsNullOrWhiteSpace(c.Value?.Contenido) &&
                Coordenadas(c.Key, out _)).Select(c => (Posicion: MYGHojaCalculo.Coordenadas(c.Key), Texto: c.Value.Contenido.Trim())).ToArray();
            var cabeceras = celdas.Where(c => plantilla.Cabeceras.Values.Contains(c.Texto, StringComparer.OrdinalIgnoreCase))
                .GroupBy(c => c.Posicion.Fila).OrderByDescending(g => g.Select(c => c.Texto).Distinct(StringComparer.OrdinalIgnoreCase).Count()).FirstOrDefault();
            int cabecera = cabeceras?.Key ?? 2;
            filas[2] = cabecera;
            foreach (var original in plantilla.Cabeceras)
            {
                var coincidencias = celdas.Where(c => c.Posicion.Fila == cabecera && Iguales(c.Texto, original.Value)).Take(2).ToArray();
                if (coincidencias.Length == 1) columnas[original.Key] = coincidencias[0].Posicion.Columna;
            }
            int FilaEtiqueta(string etiqueta, int alternativa)
            {
                var coincidencias = celdas.Where(c => Iguales(c.Texto, etiqueta) &&
                    (!columnas.TryGetValue(1, out int izquierda) || c.Posicion.Columna == izquierda)).ToArray();
                return coincidencias.Length == 1 ? coincidencias[0].Posicion.Fila : alternativa;
            }
            int resumen = FilaEtiqueta(plantilla.FinCuerpo == 15 ? "Total:" : "Longitud total x Ø", plantilla.FinCuerpo + cabecera - 1);
            primera = cabecera + 1; ultima = resumen - 1;
            string cuerpo = MYGBordesPlantillaMetrado.ObtenerRango(hoja);
            // Identificar ya comprobó las cabeceras de las hojas estándar
            // anteriores a IdPlantilla. null permite usar el cuerpo inferido;
            // un rango vacío explícito sigue significando cuerpo eliminado.
            if (cuerpo == "" && detectarCuerpoAntiguo && hoja.RangoCuerpoPlantilla == null &&
                string.IsNullOrEmpty(hoja.IdPlantilla)) cuerpo = null;
            if (cuerpo == "") { primera = 1; ultima = 0; }
            else if (cuerpo != null)
            {
                var partes = cuerpo.Split(':');
                if (Coordenadas(partes[0], out var inicio) && Coordenadas(partes[^1], out var fin) &&
                    inicio.Fila > cabecera && fin.Fila < resumen) { primera = inicio.Fila; ultima = fin.Fila; }
            }
            filas[3] = primera; filas[plantilla.FinCuerpo] = ultima;
            filas[plantilla.FinCuerpo + 1] = resumen;
            if (plantilla.FinCuerpo == 13)
            {
                filas[15] = FilaEtiqueta("Peso (kg/m)", resumen + 1);
                filas[16] = FilaEtiqueta("Peso Total (kg)", resumen + 2);
            }
            var titulos = plantilla.Textos.Where(t => t.Key.Fila == 1).Select(t => t.Value).ToArray();
            var superior = celdas.Where(c => titulos.Contains(c.Texto, StringComparer.OrdinalIgnoreCase) && c.Posicion.Fila < cabecera)
                .GroupBy(c => c.Posicion.Fila).OrderByDescending(g => g.Count()).FirstOrDefault();
            filas[1] = superior?.Key ?? cabecera - 1;
            foreach (var texto in plantilla.Textos)
                if (filas.TryGetValue(texto.Key.Fila, out int fila) && columnas.TryGetValue(texto.Key.Columna, out int columna))
                    textos[(fila, columna)] = texto.Value;
        }

        internal bool EsContenidoAutomatico((int Fila, int Columna) posicion, string contenido)
        {
            if (textos.TryGetValue(posicion, out string texto)) return Iguales(contenido, texto);
            if (!contenido.TrimStart().StartsWith('=')) return false;
            int originalColumna = columnas.FirstOrDefault(c => c.Value == posicion.Columna).Key;
            if (originalColumna == 0) return false;
            bool detalle = posicion.Fila >= primera && posicion.Fila <= ultima;
            int originalFila = detalle ? 3 : filas.FirstOrDefault(f => f.Value == posicion.Fila).Key;
            if (!plantilla.Formulas.TryGetValue((originalFila, originalColumna), out var formula)) return false;
            return Iguales(contenido, formula.Traducir(columnas, filas, detalle ? posicion.Fila : null));
        }
    }

    private sealed class Formula
    {
        private static readonly Regex Referencias = new("\"(?:[^\"]|\"\")*\"|(?<a>\\$?[A-Z]{1,3}\\$?[1-9][0-9]*)(?::(?<b>\\$?[A-Z]{1,3}\\$?[1-9][0-9]*))?", RegexOptions.Compiled);
        private readonly (string Texto, string Inicio, string Fin)[] partes;
        internal Formula(string formula)
        {
            var resultado = new List<(string, string, string)>();
            int desde = 0;
            foreach (Match referencia in Referencias.Matches(formula))
            {
                if (!referencia.Groups["a"].Success) continue;
                resultado.Add((formula[desde..referencia.Index], referencia.Groups["a"].Value,
                    referencia.Groups["b"].Success ? referencia.Groups["b"].Value : null));
                desde = referencia.Index + referencia.Length;
            }
            resultado.Add((formula[desde..], null, null)); partes = resultado.ToArray();
        }
        internal string Traducir(Dictionary<int, int> columnas, Dictionary<int, int> filas, int? detalle)
        {
            string Referencia(string original, int fila, int columna)
            {
                int separador = 0;
                while (separador < original.Length && (original[separador] == '$' || char.IsLetter(original[separador]))) separador++;
                return (original.StartsWith('$') ? "$" : "") + MYGHojaCalculo.Columna(columna) +
                    (separador > 0 && original[separador - 1] == '$' ? "$" : "") + fila.ToString(CultureInfo.InvariantCulture);
            }
            int? Fila(int original) => detalle.HasValue && original == 3 ? detalle : filas.TryGetValue(original, out int fila) ? fila : null;
            var resultado = new StringBuilder();
            foreach (var parte in partes)
            {
                resultado.Append(parte.Texto);
                if (parte.Inicio == null) continue;
                var a = MYGHojaCalculo.Coordenadas(parte.Inicio);
                int? fa = Fila(a.Fila);
                if (parte.Fin == null)
                {
                    resultado.Append(fa.HasValue && columnas.TryGetValue(a.Columna, out int ca) ? Referencia(parte.Inicio, fa.Value, ca) : "#REF!");
                    continue;
                }
                var b = MYGHojaCalculo.Coordenadas(parte.Fin);
                int? fb = Fila(b.Fila);
                var existentes = columnas.Where(c => c.Key >= Math.Min(a.Columna, b.Columna) && c.Key <= Math.Max(a.Columna, b.Columna)).OrderBy(c => c.Key).ToArray();
                if (!fa.HasValue || !fb.HasValue || fa > fb || existentes.Length == 0) { resultado.Append("#REF!"); continue; }
                resultado.Append(Referencia(parte.Inicio, fa.Value, existentes[0].Value)).Append(':')
                    .Append(Referencia(parte.Fin, fb.Value, existentes[^1].Value));
            }
            return resultado.ToString();
        }
    }

    private static readonly HashSet<string> DestinosRtf = new(StringComparer.OrdinalIgnoreCase)
    { "fonttbl", "colortbl", "stylesheet", "info", "generator", "listtable", "listoverridetable", "revtbl", "rsidtbl", "fldinst", "xmlnstbl", "themedata", "colorschememapping", "datastore" };
    private static readonly HashSet<string> SimbolosRtf = new(StringComparer.OrdinalIgnoreCase)
    { "bullet", "emdash", "endash", "lquote", "rquote", "ldblquote", "rdblquote" };

    // Lectura de presencia: omite tablas, destinos privados y caracteres de
    // respaldo Unicode. Evita confundir un RTF vacío con una especificación.
    private static bool TieneContenidoRtf(string rtf)
    {
        if (string.IsNullOrWhiteSpace(rtf)) return false;
        if (!rtf.TrimStart().StartsWith(@"{\rtf", StringComparison.OrdinalIgnoreCase)) return true;
        var grupos = new Stack<(bool Ignorar, bool Oculto, int Unicode)>();
        bool ignorar = false, oculto = false; int unicode = 1, respaldo = 0;
        bool Visible(char caracter) => !ignorar && !oculto && !char.IsWhiteSpace(caracter) && caracter != '\0';
        for (int pos = 0; pos < rtf.Length; pos++)
        {
            char actual = rtf[pos];
            if (actual == '{') { grupos.Push((ignorar, oculto, unicode)); continue; }
            if (actual == '}')
            {
                if (grupos.TryPop(out var grupo)) (ignorar, oculto, unicode) = grupo;
                respaldo = 0; continue;
            }
            if (actual != '\\')
            {
                if (respaldo > 0) { respaldo--; continue; }
                if (Visible(actual)) return true;
                continue;
            }
            if (++pos >= rtf.Length) break;
            actual = rtf[pos];
            if (!char.IsAsciiLetter(actual))
            {
                if (actual == '*') { ignorar = true; continue; }
                if (actual == '\'' && pos + 2 < rtf.Length && byte.TryParse(rtf.AsSpan(pos + 1, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out byte codigo))
                { actual = (char)codigo; pos += 2; }
                else if (actual == '~') actual = ' ';
                else if (actual == '_') actual = '-';
                else if (actual is not ('\\' or '{' or '}')) continue;
                if (respaldo > 0) { respaldo--; continue; }
                if (Visible(actual)) return true;
                continue;
            }
            int inicio = pos;
            while (pos < rtf.Length && char.IsAsciiLetter(rtf[pos])) pos++;
            string palabra = rtf[inicio..pos];
            int argumento = pos;
            if (pos < rtf.Length && rtf[pos] == '-') pos++;
            while (pos < rtf.Length && char.IsAsciiDigit(rtf[pos])) pos++;
            bool numerico = int.TryParse(rtf.AsSpan(argumento, pos - argumento), NumberStyles.Integer, CultureInfo.InvariantCulture, out int numero);
            if (pos < rtf.Length && rtf[pos] == ' ') pos++;
            pos--;
            if (palabra.Equals("shppict", StringComparison.OrdinalIgnoreCase))
                ignorar = grupos.TryPeek(out var padre) && padre.Ignorar;
            if (palabra.Equals("pict", StringComparison.OrdinalIgnoreCase) && !ignorar && !oculto) return true;
            if (DestinosRtf.Contains(palabra)) { ignorar = true; continue; }
            if (palabra == "v") oculto = !numerico || numero != 0;
            else if (palabra == "uc" && numerico) unicode = Math.Max(0, numero);
            else if (palabra == "u" && numerico)
            {
                if (Visible(unchecked((char)numero))) return true;
                respaldo = unicode;
            }
            else if (palabra == "bin" && numerico && numero > 0) pos += Math.Min(numero, rtf.Length - pos - 1);
            else if (!ignorar && !oculto && SimbolosRtf.Contains(palabra)) return true;
        }
        return false;
    }
}
