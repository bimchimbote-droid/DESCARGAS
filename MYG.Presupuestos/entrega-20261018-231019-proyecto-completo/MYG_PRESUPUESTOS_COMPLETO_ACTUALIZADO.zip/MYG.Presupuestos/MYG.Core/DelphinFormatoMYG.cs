using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

// Mantiene una representación Delphin 2024 junto al documento completo MYG.
// El esquema procede exclusivamente del DDL de la muestra proporcionada.
// Las filas nativas se actualizan por columnas: nunca se reemplaza una fila
// completa ni se eliminan filas ajenas al registro de propiedad de MYG.
internal static class MYGDelphinFormato
{
    private const string InfraestructuraGeneral = "IN0000000007";
    private static string HashId(string identidad) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(identidad)))[..12];
    internal static string IdNativo(string id) =>
        !string.IsNullOrWhiteSpace(id) && id.Length <= 12 && !id.StartsWith("MYG-", StringComparison.OrdinalIgnoreCase)
            ? id : HashId(id ?? "");
    private static string Tipo(MYGGrupoRecurso grupo) => "TC" + ((int)grupo + 1).ToString("D10", CultureInfo.InvariantCulture);
    private static string Clave(string tabla, string id) => tabla + ":" + id;

    internal static void CrearEsquema(SqliteConnection c, SqliteTransaction t)
    {
        var ensamblado = typeof(MYGDelphinFormato).Assembly;
        string recurso = ensamblado.GetManifestResourceNames().Single(x => x.EndsWith(".Delphin2024.sql", StringComparison.Ordinal));
        using var stream = ensamblado.GetManifestResourceStream(recurso);
        using var lector = new StreamReader(stream, Encoding.UTF8);
        MYGBaseDatos.Ejecutar(c, t, lector.ReadToEnd());
        PrepararRegistro(c, t);
        // Referencias técnicas observadas en la muestra; no se copian usuarios,
        // contraseñas, proyectos, direcciones ni información de sus propietarios.
        MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO infraestructura(id_infraestructura,nombre_infraestructura) VALUES($p0,'GENERAL')", InfraestructuraGeneral);
        for (int n = 0; n < 5; n++)
        {
            var grupo = (MYGGrupoRecurso)n;
            MYGBaseDatos.Ejecutar(c, t, """
                INSERT OR IGNORE INTO tipo_costo(id_tipocosto,descripcion_tipocosto,requiere_productividad,
                    permite_listaprecio,permite_subcontratista,permite_costodependiente,id_tipocostodependiente,custom_orden)
                VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7)
                """, Tipo(grupo), MYGMotorPresupuestos.Grupo(grupo),
                grupo is MYGGrupoRecurso.ManoObra or MYGGrupoRecurso.Equipo ? "S" : "N",
                grupo == MYGGrupoRecurso.Subpartidas ? "N" : "S", grupo == MYGGrupoRecurso.Subcontratos ? "S" : "N",
                grupo == MYGGrupoRecurso.Equipo ? "S" : "N", grupo == MYGGrupoRecurso.Equipo ? Tipo(MYGGrupoRecurso.ManoObra) : null, n + 1);
            MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO categoria(id_categoria,descripcion_categoria,estado_categoria) VALUES($p0,$p1,'S')",
                Tipo(grupo), MYGMotorPresupuestos.Grupo(grupo));
        }
        MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO moneda(id_moneda,nombre_moneda,simbolo_moneda) VALUES('Sol','Sol','S/')");
        MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO pais_info(id_paisinfo,nombre_paisinfo,simbolo_moneda,nombre_moneda,id_moneda) VALUES('es-PE','Perú','S/','Sol','Sol')");
        MYGCatalogosProyecto.Inicializar(c, t);
    }

    internal static void InicializarAccesoHojaNueva(SqliteConnection c, SqliteTransaction t)
    {
        // Solo se llama desde la transacción de una hoja recién creada. Los accesos
        // de bases existentes y las cuentas de la muestra permanecen intactos.
        var ensamblado = typeof(MYGDelphinFormato).Assembly;
        string recurso = ensamblado.GetManifestResourceNames().Single(x => x.EndsWith(".DelphinAccesoInicial.sql", StringComparison.Ordinal));
        using var stream = ensamblado.GetManifestResourceStream(recurso);
        using var lector = new StreamReader(stream, Encoding.UTF8);
        MYGBaseDatos.Ejecutar(c, t, lector.ReadToEnd());
    }

    internal static void InicializarUnidadesHojaNueva(SqliteConnection c, SqliteTransaction t)
    {
        var ensamblado = typeof(MYGDelphinFormato).Assembly;
        string recurso = ensamblado.GetManifestResourceNames().Single(x => x.EndsWith(".DelphinUnidadesIniciales.sql", StringComparison.Ordinal));
        using var stream = ensamblado.GetManifestResourceStream(recurso);
        using var lector = new StreamReader(stream, Encoding.UTF8);
        MYGBaseDatos.Ejecutar(c, t, lector.ReadToEnd());
    }

    private static void PrepararRegistro(SqliteConnection c, SqliteTransaction t)
    {
        MYGBaseDatos.Ejecutar(c, t, """
            CREATE TABLE IF NOT EXISTS myg_delphin_fila(
                propietario TEXT NOT NULL,tabla TEXT NOT NULL,id_nativo TEXT NOT NULL,
                PRIMARY KEY(tabla,id_nativo));
            CREATE INDEX IF NOT EXISTS ix_myg_delphin_propietario ON myg_delphin_fila(propietario);
            """);
    }

    private static bool Existe(SqliteConnection c, SqliteTransaction t, string tabla, string columna, string id)
    {
        using var cmd = MYGBaseDatos.Comando(c, t, "SELECT 1 FROM " + tabla + " WHERE " + columna + "=$p0", id);
        return cmd.ExecuteScalar() != null;
    }
    private static string Texto(SqliteConnection c, SqliteTransaction t, string sql, params object[] valores)
    {
        using var cmd = MYGBaseDatos.Comando(c, t, sql, valores);
        return cmd.ExecuteScalar() as string;
    }
    private static void Registrar(SqliteConnection c, SqliteTransaction t, string propietario,
        string tabla, string id, HashSet<string> presentes)
    {
        string anterior = Texto(c, t, "SELECT propietario FROM myg_delphin_fila WHERE tabla=$p0 AND id_nativo=$p1", tabla, id);
        if (anterior != null && anterior != propietario)
            throw new InvalidOperationException("Una fila Delphin pertenece a otro proyecto o catálogo: " + tabla + ".");
        MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO myg_delphin_fila(propietario,tabla,id_nativo) VALUES($p0,$p1,$p2)", propietario, tabla, id);
        presentes.Add(Clave(tabla, id));
    }
    private static string ColumnaId(string tabla) => tabla switch
    {
        "proyecto" => "id_proyecto",
        "presupuesto" => "id_presupuesto",
        "titulo" => "id_titulo",
        "costo_unitario" => "id_costounitario",
        "producto" => "id_producto",
        "unidad" => "id_unidad",
        "analisis_costo" => "id_analisiscosto",
        "subtotal_costounitario" or "subtotal_analisiscosto" => "id_subtotal",
        "composicion_costounitario" or "composicion_analisiscosto" => "id_composicion",
        _ => throw new InvalidOperationException("Tabla Delphin no gestionada.")
    };
    private static void RetirarAusentes(SqliteConnection c, SqliteTransaction t, string propietario, HashSet<string> presentes)
    {
        var anteriores = new List<(string Tabla, string Id)>();
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT tabla,id_nativo FROM myg_delphin_fila WHERE propietario=$p0", propietario))
        using (var r = cmd.ExecuteReader()) while (r.Read()) anteriores.Add((r.GetString(0), r.GetString(1)));
        foreach (var anterior in anteriores.OrderBy(x => x.Tabla.StartsWith("composicion", StringComparison.Ordinal) ? 0 :
            x.Tabla.StartsWith("subtotal", StringComparison.Ordinal) ? 1 : x.Tabla == "presupuesto" ? 3 : 2))
        {
            if (presentes.Contains(Clave(anterior.Tabla, anterior.Id))) continue;
            // Únicamente IDs expresamente registrados por una sincronización anterior.
            // Recursos auxiliares compartidos se conservan si alguna fila los refiere.
            if (anterior.Tabla == "analisis_costo" && ReferenciadoAnalisis(c, t, anterior.Id)) continue;
            MYGBaseDatos.Ejecutar(c, t, "DELETE FROM " + anterior.Tabla + " WHERE " + ColumnaId(anterior.Tabla) + "=$p0", anterior.Id);
            MYGBaseDatos.Ejecutar(c, t, "DELETE FROM myg_delphin_fila WHERE propietario=$p0 AND tabla=$p1 AND id_nativo=$p2", propietario, anterior.Tabla, anterior.Id);
        }
    }
    private static bool ReferenciadoAnalisis(SqliteConnection c, SqliteTransaction t, string id)
    {
        using var cmd = MYGBaseDatos.Comando(c, t, """
            SELECT 1 FROM costo_unitario WHERE id_analisiscosto=$p0
            UNION ALL SELECT 1 FROM composicion_costounitario WHERE id_costoauxiliar=$p0
            UNION ALL SELECT 1 FROM composicion_analisiscosto WHERE id_costoauxiliar=$p0 LIMIT 1
            """, id);
        return cmd.ExecuteScalar() != null;
    }

    private static void ConservarRecursos(SqliteConnection c, SqliteTransaction t, string idPartida,
        bool analisis, HashSet<string> presentes, HashSet<string> visitados, string propietario = null)
    {
        string tablaSubtotal = analisis ? "subtotal_analisiscosto" : "subtotal_costounitario";
        string tablaComposicion = analisis ? "composicion_analisiscosto" : "composicion_costounitario";
        string columnaPartida = analisis ? "id_analisiscosto" : "id_costounitario";
        if (!visitados.Add(Clave(tablaSubtotal, idPartida))) return;
        var auxiliares = new List<string>();
        var filas = new List<(string Tabla, string Id)>();
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT s.id_subtotal,r.id_composicion,r.id_costoauxiliar FROM " +
            tablaSubtotal + " s LEFT JOIN " + tablaComposicion + " r ON r.id_subtotal=s.id_subtotal WHERE s." + columnaPartida + "=$p0", idPartida))
        using (var r = cmd.ExecuteReader()) while (r.Read())
        {
            filas.Add((tablaSubtotal, r.GetString(0)));
            if (!r.IsDBNull(1)) filas.Add((tablaComposicion, r.GetString(1)));
            if (!r.IsDBNull(2) && !string.IsNullOrWhiteSpace(r.GetString(2))) auxiliares.Add(r.GetString(2));
        }
        foreach (var fila in filas.Distinct())
        {
            if (propietario == null) presentes.Add(Clave(fila.Tabla, fila.Id));
            else Registrar(c, t, propietario, fila.Tabla, fila.Id, presentes);
        }
        foreach (string auxiliar in auxiliares)
        {
            presentes.Add(Clave("analisis_costo", auxiliar));
            ConservarRecursos(c, t, auxiliar, true, presentes, visitados);
        }
    }

    private static bool ArbolGestionado(SqliteConnection c, SqliteTransaction t, string id,
        bool analisis, string propietario)
    {
        string subtotal = analisis ? "subtotal_analisiscosto" : "subtotal_costounitario";
        string composicion = analisis ? "composicion_analisiscosto" : "composicion_costounitario";
        string campo = analisis ? "id_analisiscosto" : "id_costounitario";
        using var cmd = MYGBaseDatos.Comando(c, t,
            "SELECT 1 FROM " + subtotal + " s LEFT JOIN myg_delphin_fila m ON m.tabla=$p1 AND m.id_nativo=s.id_subtotal " +
            "WHERE s." + campo + "=$p0 AND (m.propietario IS NULL OR m.propietario<>$p3) UNION ALL " +
            "SELECT 1 FROM " + composicion + " r JOIN " + subtotal + " s ON s.id_subtotal=r.id_subtotal " +
            "LEFT JOIN myg_delphin_fila m ON m.tabla=$p2 AND m.id_nativo=r.id_composicion WHERE s." + campo +
            "=$p0 AND (m.propietario IS NULL OR m.propietario<>$p3) LIMIT 1", id, subtotal, composicion, propietario);
        return cmd.ExecuteScalar() == null;
    }

    // Los símbolos de unidades se comparan con las mismas reglas que el editor.
    // Una unidad existente conserva todo su resto de metadatos nativos.
    private static string AsegurarUnidad(SqliteConnection c, SqliteTransaction t, string simbolo, string descripcion = null)
    {
        if (string.IsNullOrWhiteSpace(simbolo)) return null;
        simbolo = simbolo.Trim();
        string existente = BuscarUnidad(c, t, null, simbolo);
        if (existente != null) return existente;
        string simboloNormalizado = simbolo.ToLowerInvariant().Replace("²", "2").Replace("³", "3").Replace(" ", "").Replace("m^", "m");
        string id = HashId("unidad:" + simboloNormalizado);
        bool porcentaje = MYGProyectoStorage.MismaUnidad(simbolo, "%mo");
        MYGBaseDatos.Ejecutar(c, t, """
            INSERT INTO unidad(id_unidad,descripcion_unidad,abreviatura_unidad,informacion_unidad,
                magnitud_unidad,id_unidadbase,es_unidadcosto,es_unidadtiempo,es_unidadgasto,en_cronograma,
                es_dependiente,id_tipocostodependencia,tipo_unidad,divisible)
            VALUES($p0,$p1,$p1,$p2,$p3,$p0,'S','N','S','N',$p4,$p5,$p6,'S')
            """, id, simbolo, descripcion ?? simbolo, porcentaje ? 0.01m : 1m,
            porcentaje ? "S" : "N", porcentaje ? Tipo(MYGGrupoRecurso.ManoObra) : null,
            porcentaje ? "P" : MYGProyectoStorage.MismaUnidad(simbolo, "hh") || MYGProyectoStorage.MismaUnidad(simbolo, "hm") ? "H" : "N");
        for (int n = 0; n < 5; n++)
            MYGBaseDatos.Ejecutar(c, t, "INSERT OR IGNORE INTO unidad_tipocosto(id_unidad,id_tipocosto) VALUES($p0,$p1)", id, Tipo((MYGGrupoRecurso)n));
        return id;
    }

    private static string BuscarUnidad(SqliteConnection c, SqliteTransaction t, string id, string simbolo)
    {
        if (!string.IsNullOrWhiteSpace(id) && Existe(c, t, "unidad", "id_unidad", id)) return id;
        // Un símbolo puede tener variantes globales y de costo. El presupuesto
        // necesita primero la variante de costo, conservando su identidad nativa.
        using var cmd = MYGBaseDatos.Comando(c, t, """
            SELECT id_unidad,COALESCE(NULLIF(abreviatura_unidad,''),descripcion_unidad,'') FROM unidad
            ORDER BY CASE WHEN es_unidadcosto='S' THEN 0 ELSE 1 END,
                CASE WHEN tipo_unidad='G' THEN 1 ELSE 0 END,id_unidad
            """);
        using var r = cmd.ExecuteReader();
        while (r.Read()) if (MYGProyectoStorage.MismaUnidad(r.GetString(1), simbolo)) return r.GetString(0);
        return null;
    }

    internal static void SincronizarUnidades(SqliteConnection c, SqliteTransaction t, string id = null)
    {
        PrepararRegistro(c, t);
        var unidades = new List<(string Id, string Simbolo, string Descripcion)>();
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id,simbolo,descripcion FROM catalogo_unidad" +
            (id == null ? "" : " WHERE id=$p0"), id))
        using (var r = cmd.ExecuteReader()) while (r.Read()) unidades.Add((r.GetString(0), r.GetString(1), r.GetString(2)));
        foreach (var u in unidades)
        {
            string existente = BuscarUnidad(c, t, u.Id, u.Simbolo);
            string nativo = existente ?? AsegurarUnidad(c, t, u.Simbolo, u.Descripcion);
            bool propia = Texto(c, t, "SELECT propietario FROM myg_delphin_fila WHERE tabla='unidad' AND id_nativo=$p0", nativo) == "catalogo_unidad";
            // Una sincronización automática no altera ni se apropia del catálogo nativo.
            // La edición explícita de una descripción se limita a la fila seleccionada.
            if (existente == null || propia || id != null)
                MYGBaseDatos.Ejecutar(c, t, "UPDATE unidad SET informacion_unidad=$p1 WHERE id_unidad=$p0", nativo, u.Descripcion);
            if (existente == null || propia)
                Registrar(c, t, "catalogo_unidad", "unidad", nativo, new HashSet<string>(StringComparer.Ordinal));
        }
    }

    internal static bool ActualizarDescripcionUnidad(SqliteConnection c, SqliteTransaction t, string id, string descripcion)
    {
        if (!Existe(c, t, "unidad", "id_unidad", id)) return false;
        MYGBaseDatos.Ejecutar(c, t, "UPDATE unidad SET informacion_unidad=$p1 WHERE id_unidad=$p0", id, descripcion);
        return true;
    }

    internal static void CopiarUnidades(SqliteConnection origen, SqliteTransaction lectura,
        SqliteConnection destino, SqliteTransaction escritura, bool destinoNuevo)
    {
        // Guardar como conserva el catálogo de origen, incluyendo variantes, bajas
        // y metadatos. Solo un destino recién creado puede retirar su catálogo inicial.
        if (destinoNuevo)
        {
            MYGBaseDatos.Ejecutar(destino, escritura, "DELETE FROM unidad_tipocosto");
            MYGBaseDatos.Ejecutar(destino, escritura, "DELETE FROM unidad_tipocostonew");
            MYGBaseDatos.Ejecutar(destino, escritura, "DELETE FROM unidad");
            MYGBaseDatos.Ejecutar(destino, escritura, "DELETE FROM myg_delphin_fila WHERE tabla='unidad'");
            MYGBaseDatos.Ejecutar(destino, escritura, "DELETE FROM secuencia WHERE nombre_secuencia='id_unidad'");
        }
        foreach (string tabla in new[] { "tipo_costo", "unidad", "unidad_tipocosto", "unidad_tipocostonew" })
        {
            if (!MYGBaseDatos.TieneTabla(origen, lectura, tabla)) continue;
            var campos = new List<string>();
            using (var cmd = MYGBaseDatos.Comando(origen, lectura, "PRAGMA table_info(" + tabla + ")"))
            using (var r = cmd.ExecuteReader()) while (r.Read()) campos.Add('"' + r.GetString(1).Replace("\"", "\"\"") + '"');
            using var leer = MYGBaseDatos.Comando(origen, lectura, "SELECT " + string.Join(",", campos) + " FROM " + tabla);
            using var filas = leer.ExecuteReader();
            while (filas.Read())
            {
                var valores = new object[filas.FieldCount]; filas.GetValues(valores);
                MYGBaseDatos.Ejecutar(destino, escritura, "INSERT OR IGNORE INTO " + tabla + "(" + string.Join(",", campos) +
                    ") VALUES(" + string.Join(",", Enumerable.Range(0, valores.Length).Select(n => "$p" + n)) + ")", valores);
            }
        }
        if (MYGBaseDatos.TieneTabla(origen, lectura, "myg_delphin_fila"))
        {
            using var leer = MYGBaseDatos.Comando(origen, lectura, "SELECT propietario,id_nativo FROM myg_delphin_fila WHERE tabla='unidad'");
            using var filas = leer.ExecuteReader();
            while (filas.Read())
                MYGBaseDatos.Ejecutar(destino, escritura,
                    "INSERT OR IGNORE INTO myg_delphin_fila(propietario,tabla,id_nativo) VALUES($p0,'unidad',$p1)", filas.GetString(0), filas.GetString(1));
        }
        if (MYGBaseDatos.TieneTabla(origen, lectura, "secuencia"))
        {
            using var leer = MYGBaseDatos.Comando(origen, lectura, "SELECT ultimo_numero FROM secuencia WHERE nombre_secuencia='id_unidad'");
            object valor = leer.ExecuteScalar();
            if (valor != null) MYGBaseDatos.Ejecutar(destino, escritura,
                "INSERT INTO secuencia(nombre_secuencia,ultimo_numero) VALUES('id_unidad',$p0) " +
                "ON CONFLICT(nombre_secuencia) DO UPDATE SET ultimo_numero=MAX(secuencia.ultimo_numero,excluded.ultimo_numero)", valor);
        }
    }

    private static bool ReferenciaProducto(SqliteConnection c, SqliteTransaction t, string id)
    {
        using var cmd = MYGBaseDatos.Comando(c, t, """
            SELECT 1 FROM composicion_costounitario WHERE id_listaprecio=$p0
            UNION ALL SELECT 1 FROM composicion_analisiscosto WHERE id_listaprecio=$p0 LIMIT 1
            """, id);
        return cmd.ExecuteScalar() != null;
    }

    private static void SincronizarEspecificacion(SqliteConnection c, SqliteTransaction t, string tabla,
        string id, MYGDatosPartida datos)
    {
        string textoActual = "", rtfActual = "";
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT especificaciones,archivo_especificaciones FROM " + tabla +
            " WHERE " + ColumnaId(tabla) + "=$p0", id))
        using (var r = cmd.ExecuteReader()) if (r.Read())
        {
            textoActual = r.IsDBNull(0) ? "" : r.GetString(0);
            if (textoActual.TrimStart().StartsWith(@"{\rtf", StringComparison.OrdinalIgnoreCase))
            { rtfActual = textoActual; textoActual = ""; }
            if (!r.IsDBNull(1))
            {
                string contenido;
                if (r.GetValue(1) is byte[] bytes)
                    contenido = bytes.Length >= 2 && bytes[0] == 255 && bytes[1] == 254 ? Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2) :
                        bytes.Length >= 3 && bytes[0] == 239 && bytes[1] == 187 && bytes[2] == 191 ? Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3) : Encoding.Latin1.GetString(bytes);
                else contenido = r.GetValue(1) as string ?? "";
                if (contenido.TrimStart().StartsWith(@"{\rtf", StringComparison.OrdinalIgnoreCase)) rtfActual = contenido;
            }
        }
        string texto = datos.EspecificacionEsBorrador ? "" : datos.EspecificacionTexto ?? "";
        string rtf = datos.EspecificacionEsBorrador ? "" : datos.EspecificacionRtf ?? "";
        // Un borrador conserva su contenido en el JSON de MYG, pero aún no
        // representa una especificación guardada para Delphin.
        if (!datos.EspecificacionEsBorrador && textoActual == texto && rtfActual == rtf) return;
        MYGBaseDatos.Ejecutar(c, t, "UPDATE " + tabla +
            " SET especificaciones=$p1,archivo_especificaciones=$p2,especificaciones_texto=$p3 WHERE " + ColumnaId(tabla) + "=$p0",
            id, texto, rtf.Length == 0 ? null : Encoding.Latin1.GetBytes(rtf), rtf.Length == 0 ? "S" : "W");
    }

    internal static bool EliminarUnidad(SqliteConnection c, SqliteTransaction t, string identidad, string simbolo)
    {
        PrepararRegistro(c, t);
        string id = BuscarUnidad(c, t, identidad, simbolo);
        if (id == null) return true;
        if (Texto(c, t, "SELECT propietario FROM myg_delphin_fila WHERE tabla='unidad' AND id_nativo=$p0", id) != "catalogo_unidad") return false;
        // Comprueba todos los usos nativos, incluidos módulos que MYG no edita.
        var tablas = new List<string>();
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))
        using (var r = cmd.ExecuteReader()) while (r.Read()) tablas.Add(r.GetString(0));
        foreach (string tabla in tablas)
        {
            if (tabla is "unidad_tipocosto" or "unidad_tipocostonew") continue;
            var columnas = new List<string>();
            string tablaSegura = '"' + tabla.Replace("\"", "\"\"") + '"';
            using (var cmd = MYGBaseDatos.Comando(c, t, "PRAGMA table_info(" + tablaSegura + ")"))
            using (var r = cmd.ExecuteReader()) while (r.Read())
                if (r.GetString(1).StartsWith("id_unidad", StringComparison.OrdinalIgnoreCase)) columnas.Add(r.GetString(1));
            foreach (string columna in columnas)
            {
                if (tabla == "unidad" && columna == "id_unidad") continue;
                string columnaSegura = '"' + columna.Replace("\"", "\"\"") + '"';
                using var cmd = MYGBaseDatos.Comando(c, t, "SELECT 1 FROM " + tablaSegura + " WHERE " + columnaSegura +
                    "=$p0" + (tabla == "unidad" ? " AND id_unidad<>$p0" : "") + " LIMIT 1", id);
                if (cmd.ExecuteScalar() != null) return false;
            }
        }
        MYGBaseDatos.Ejecutar(c, t, "DELETE FROM unidad_tipocosto WHERE id_unidad=$p0", id);
        MYGBaseDatos.Ejecutar(c, t, "DELETE FROM unidad_tipocostonew WHERE id_unidad=$p0", id);
        MYGBaseDatos.Ejecutar(c, t, "DELETE FROM unidad WHERE id_unidad=$p0", id);
        MYGBaseDatos.Ejecutar(c, t, "DELETE FROM myg_delphin_fila WHERE tabla='unidad' AND id_nativo=$p0", id);
        return true;
    }

    private static string Producto(SqliteConnection c, SqliteTransaction t, MYGInsumo insumo, string contexto, bool actualizar)
    {
        string id = IdNativo(insumo.Id);
        string unidad = AsegurarUnidad(c, t, insumo.Unidad);
        // El precio en un presupuesto es su instantánea. Actualizarla no modifica
        // el catálogo global de Delphin; el precio real se escribe en composición.
        string conflicto = actualizar ? "DO UPDATE SET descripcion_producto=excluded.descripcion_producto,id_unidad=excluded.id_unidad," +
            "codigo_producto=excluded.codigo_producto,codigo_electrico=excluded.codigo_electrico,costo_unitariolista=excluded.costo_unitariolista," +
            "costo_unitario=excluded.costo_unitario,id_tipocosto=excluded.id_tipocosto,id_categoria=excluded.id_categoria" : "DO NOTHING";
        MYGBaseDatos.Ejecutar(c, t, """
            INSERT INTO producto(id_producto,descripcion_producto,id_unidad,codigo_producto,codigo_electrico,
                costo_unitariolista,costo_unitario,id_tipocosto,id_categoria,estado_producto)
            VALUES($p0,$p1,$p2,$p3,$p3,$p4,$p4,$p5,$p5,'S') ON CONFLICT(id_producto)
            """ + conflicto, id, insumo.Descripcion, unidad, insumo.Codigo, insumo.Precio, Tipo(insumo.Grupo));
        return id;
    }

    internal static void SincronizarProyecto(SqliteConnection c, SqliteTransaction t, MYGProyectoDocumento documento)
    {
        PrepararRegistro(c, t);
        string propietario = "proyecto:" + documento.Id;
        var presentes = new HashSet<string>(StringComparer.Ordinal);
        string proyectoId = IdNativo(documento.Id);
        string usuario = Texto(c, t, "SELECT id_usuario FROM proyecto WHERE id_proyecto=$p0", proyectoId) ??
            Texto(c, t, "SELECT id_usuario FROM usuario ORDER BY CASE WHEN es_principal='S' THEN 0 ELSE 1 END,id_usuario LIMIT 1") ?? "";
        decimal total = MYGPiePresupuesto.EsPieUnicoDelphin(documento.Presupuestos)
            ? MYGPiePresupuesto.Resumen(documento.Presupuestos).Total
            : documento.Presupuestos.Sum(p => MYGMotorPresupuestos.Resumen(p).Total);
        bool proyectoSinCambios = Existe(c, t, "proyecto", "id_proyecto", proyectoId) &&
            documento.Presupuestos.All(MYGMotorPresupuestos.ConservaPresupuestoDelphin);
        var presupuestosActuales = documento.Presupuestos.Select(p => IdNativo(p.Id)).ToHashSet(StringComparer.Ordinal);
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id_nativo FROM myg_delphin_fila WHERE propietario=$p0 AND tabla='presupuesto'", propietario))
        using (var r = cmd.ExecuteReader()) while (r.Read())
            if (!presupuestosActuales.Contains(r.GetString(0))) proyectoSinCambios = false;
        if (proyectoSinCambios)
        {
            if (Texto(c, t, "SELECT nombre_proyecto FROM proyecto WHERE id_proyecto=$p0", proyectoId) != documento.Nombre)
                MYGBaseDatos.Ejecutar(c, t, "UPDATE proyecto SET nombre_proyecto=$p1 WHERE id_proyecto=$p0", proyectoId, documento.Nombre);
        }
        else
        {
            // Las hojas nuevas usan su cuenta principal inicial. En bases anteriores
            // se conserva el usuario existente, sin crear ni cambiar sus cuentas.
            MYGBaseDatos.Ejecutar(c, t, """
            INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,
                total_proyecto,es_plantilla,fecha_proyecto,estado_proyecto,id_paisinfo,first_id_paisinfo,
                selected_presupuesto,decimales_cantidad,decimales_costo)
            VALUES($p0,$p1,$p2,'Si',$p3,$p4,'N',$p5,'R','es-PE','es-PE',$p6,$p7,$p8)
            ON CONFLICT(id_proyecto) DO UPDATE SET nombre_proyecto=excluded.nombre_proyecto,total_proyecto=excluded.total_proyecto,
                selected_presupuesto=excluded.selected_presupuesto,decimales_cantidad=excluded.decimales_cantidad,decimales_costo=excluded.decimales_costo
            """, proyectoId, usuario, InfraestructuraGeneral, documento.Nombre, total,
                DateTime.UtcNow.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
                documento.PresupuestoActivoId == null ? null : IdNativo(documento.PresupuestoActivoId),
                documento.Presupuestos.FirstOrDefault()?.Costos.DecimalesCantidad ?? 4,
                documento.Presupuestos.FirstOrDefault()?.Costos.DecimalesPrecio ?? 2);
        }
        SincronizarDatosProyecto(c, t, documento, proyectoId);
        Registrar(c, t, propietario, "proyecto", proyectoId, presentes);
        foreach (var p in documento.Presupuestos)
        {
            string presupuestoId = IdNativo(p.Id);
            string proyectoAnterior = Texto(c, t, "SELECT id_proyecto FROM presupuesto WHERE id_presupuesto=$p0", presupuestoId);
            if (proyectoAnterior != null && proyectoAnterior != proyectoId)
                throw new InvalidOperationException("El presupuesto Delphin pertenece a otro proyecto.");
            var resumen = MYGMotorPresupuestos.Resumen(p);
            bool presupuestoSinCambios = proyectoAnterior != null && MYGMotorPresupuestos.ConservaPresupuestoDelphin(p);
            if (!presupuestoSinCambios)
                MYGBaseDatos.Ejecutar(c, t, """
                INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto,
                    costo_directo,porcentaje_gasto,monto_gasto,porcentaje_utilidad,monto_utilidad,porcentaje_igv,monto_igv,
                    parcial_presupuesto,total_presupuesto,porcentaje_impuestootro,monto_impuestootro,estado_expandido)
                VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11,$p12,$p13,$p14,$p15,'S')
                ON CONFLICT(id_presupuesto) DO UPDATE SET nombre_presupuesto=excluded.nombre_presupuesto,
                    posicion_presupuesto=excluded.posicion_presupuesto,numeracion_presupuesto=excluded.numeracion_presupuesto,
                    costo_directo=excluded.costo_directo,porcentaje_gasto=excluded.porcentaje_gasto,monto_gasto=excluded.monto_gasto,
                    porcentaje_utilidad=excluded.porcentaje_utilidad,monto_utilidad=excluded.monto_utilidad,
                    porcentaje_igv=excluded.porcentaje_igv,monto_igv=excluded.monto_igv,parcial_presupuesto=excluded.parcial_presupuesto,
                    total_presupuesto=excluded.total_presupuesto,
                    porcentaje_impuestootro=excluded.porcentaje_impuestootro,monto_impuestootro=excluded.monto_impuestootro
                """, presupuestoId, proyectoId, p.Nombre, p.Posicion, p.Item, resumen.CostoDirecto,
                p.Costos.GastosGeneralesPorcentaje, resumen.GastosGenerales, p.Costos.UtilidadPorcentaje, resumen.Utilidad,
                p.Costos.ImpuestoPorcentaje, resumen.Impuesto, resumen.Subtotal, resumen.Total,
                p.Costos.OtrosImpuestosPorcentaje, resumen.OtrosImpuestos);
            if (!presupuestoSinCambios && MYGPiePresupuesto.EsPieDelphin(p))
                SincronizarPiePresupuesto(c, t, p, proyectoId, presupuestoId);
            Registrar(c, t, propietario, "presupuesto", presupuestoId, presentes);
            var nativos = p.Items.ToDictionary(i => i.Id, i => IdNativo(
                string.IsNullOrWhiteSpace(i.IdInternoDelphin) ? i.Id : i.IdInternoDelphin), StringComparer.OrdinalIgnoreCase);
            var titulosAntiguos = p.Items.Where(MYGProyectoStorage.EsTitulo)
                .Where(i => Existe(c, t, "titulo", "id_titulo", nativos[i.Id])).Select(i => i.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var auxiliares = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var i in p.Items)
            {
                string id = nativos[i.Id];
                string padre = i.ParentId != null && nativos.TryGetValue(i.ParentId, out string parentId) ? parentId : null;
                bool titulo = MYGProyectoStorage.EsTitulo(i);
                string tablaNativa = titulo && titulosAntiguos.Contains(i.Id) ? "titulo" : "costo_unitario";
                string presupuestoItemAnterior = Texto(c, t, "SELECT id_presupuesto FROM " + tablaNativa +
                    " WHERE " + ColumnaId(tablaNativa) + "=$p0", id);
                if (!string.IsNullOrEmpty(presupuestoItemAnterior) && presupuestoItemAnterior != presupuestoId)
                    throw new InvalidOperationException("La partida Delphin pertenece a otro presupuesto.");
                if (MYGMotorPresupuestos.ConservaDatosDelphin(p, i) && Existe(c, t, tablaNativa, ColumnaId(tablaNativa), id))
                {
                    Registrar(c, t, propietario, tablaNativa, id, presentes);
                    if (!titulo) ConservarRecursos(c, t, id, false, presentes, new HashSet<string>(StringComparer.Ordinal), propietario);
                    continue;
                }
                if (titulo && titulosAntiguos.Contains(i.Id))
                {
                    MYGBaseDatos.Ejecutar(c, t, """
                        INSERT INTO titulo(id_titulo,descripcion_titulo,id_titulopadre,id_presupuesto,posicion_titulo,numeracion_titulo,costo_titulo,estado_expandido)
                        VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,'S') ON CONFLICT(id_titulo) DO UPDATE SET
                            descripcion_titulo=excluded.descripcion_titulo,id_titulopadre=excluded.id_titulopadre,
                            id_presupuesto=excluded.id_presupuesto,posicion_titulo=excluded.posicion_titulo,
                            numeracion_titulo=excluded.numeracion_titulo,costo_titulo=excluded.costo_titulo
                        """, id, i.Descripcion, padre, presupuestoId, i.Posicion, i.Item, MYGMotorPresupuestos.TotalPartida(p, i));
                    Registrar(c, t, propietario, "titulo", id, presentes); continue;
                }
                string presupuestoAnterior = Texto(c, t, "SELECT id_presupuesto FROM costo_unitario WHERE id_costounitario=$p0", id);
                if (!string.IsNullOrEmpty(presupuestoAnterior) && presupuestoAnterior != presupuestoId)
                    throw new InvalidOperationException("La partida Delphin pertenece a otro presupuesto.");
                string unidad = titulo ? null : AsegurarUnidad(c, t, i.Unidad);
                decimal cantidad = titulo ? 0 : MYGMotorPresupuestos.Cantidad(p, i);
                var acu = titulo ? new MYGResultadoACU() : MYGMotorPresupuestos.Analizar(p, i);
                bool padreTituloAntiguo = i.ParentId != null && titulosAntiguos.Contains(i.ParentId);
                string padreCosto = padreTituloAntiguo ? null : padre, padreTitulo = padreTituloAntiguo ? padre : null;
                using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id_costopadre,id_titulo FROM costo_unitario WHERE id_costounitario=$p0", id))
                using (var r = cmd.ExecuteReader()) if (r.Read())
                {
                    string costoOriginal = r.IsDBNull(0) ? null : r.GetString(0), tituloOriginal = r.IsDBNull(1) ? null : r.GetString(1);
                    string padreOriginal = !string.IsNullOrWhiteSpace(costoOriginal) ? costoOriginal :
                        !string.IsNullOrWhiteSpace(tituloOriginal) ? tituloOriginal : null;
                    if (padreOriginal == padre) { padreCosto = costoOriginal; padreTitulo = tituloOriginal; }
                }
                if (!titulo && MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i) && Existe(c, t, "costo_unitario", "id_costounitario", id))
                {
                    // Un ACU importado sin cambios mantiene su árbol nativo,
                    // su rendimiento, RTF, dependencias y archivos adjuntos.
                    MYGBaseDatos.Ejecutar(c, t, """
                        UPDATE costo_unitario SET descripcion_costo=$p1,id_unidad=$p2,id_presupuesto=$p3,
                            id_costopadre=$p4,id_titulo=$p5,posicion_costo=$p6,numeracion_costo=$p7,
                            cantidad=$p8,costo_unitario=$p9,parcial_costo=$p10
                        WHERE id_costounitario=$p0
                        """, id, i.Descripcion, unidad, presupuestoId, padreCosto,
                        padreTitulo, i.Posicion, i.Item, cantidad, acu.PrecioUnitario,
                        MYGMotorPresupuestos.TotalPartida(p, i));
                    Registrar(c, t, propietario, "costo_unitario", id, presentes);
                    SincronizarEspecificacion(c, t, "costo_unitario", id, i.Costos);
                    SincronizarOrdenRecursosConservados(c, t, id, i.Costos.Analisis);
                    ConservarRecursos(c, t, id, false, presentes, new HashSet<string>(StringComparer.Ordinal), propietario);
                    continue;
                }
                if (!titulo && i.Id == id && i.Costos.PrecioImportadoDelphin.HasValue &&
                    Existe(c, t, "costo_unitario", "id_costounitario", id) && !ArbolGestionado(c, t, id, false, propietario))
                    // La partida y su presupuesto ya se verificaron arriba. Sus
                    // subtotales/composiciones son exclusivos de este CU; se
                    // registran antes de reemplazarlos. Los análisis auxiliares
                    // compartidos siguen conservándose fuera de su propiedad.
                    ConservarRecursos(c, t, id, false, new HashSet<string>(StringComparer.Ordinal),
                        new HashSet<string>(StringComparer.Ordinal), propietario);
                MYGBaseDatos.Ejecutar(c, t, """
                    INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_unidad,id_presupuesto,id_costopadre,id_titulo,
                        posicion_costo,numeracion_costo,cantidad,cantidad_metrado,costo_unitario,parcial_costo,
                        productividad,magnitud_unidadtiempo,tipo_rendimiento,tiene_composicion,estado_expandido,
                        especificaciones,especificaciones_texto)
                    VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p8,$p9,$p10,$p11,$p12,'D',$p13,'S',$p14,'S')
                    ON CONFLICT(id_costounitario) DO UPDATE SET descripcion_costo=excluded.descripcion_costo,id_unidad=excluded.id_unidad,
                        id_presupuesto=excluded.id_presupuesto,id_costopadre=excluded.id_costopadre,id_titulo=excluded.id_titulo,
                        posicion_costo=excluded.posicion_costo,numeracion_costo=excluded.numeracion_costo,
                        cantidad=excluded.cantidad,costo_unitario=excluded.costo_unitario,
                        parcial_costo=excluded.parcial_costo,productividad=excluded.productividad,
                        magnitud_unidadtiempo=excluded.magnitud_unidadtiempo,tipo_rendimiento=excluded.tipo_rendimiento,
                        tiene_composicion=excluded.tiene_composicion
                    """, id, i.Descripcion, unidad, presupuestoId, padreCosto,
                    padreTitulo, i.Posicion, i.Item, cantidad, acu.PrecioUnitario,
                    MYGMotorPresupuestos.TotalPartida(p, i), titulo ? 0 : i.Costos.RendimientoDiario,
                    titulo ? 0 : i.Costos.JornadaHoras, acu.Recursos.Count == 0 ? "N" : "S",
                    i.Costos.EspecificacionEsBorrador ? "" : i.Costos.EspecificacionTexto);
                Registrar(c, t, propietario, "costo_unitario", id, presentes);
                if (!titulo) SincronizarEspecificacion(c, t, "costo_unitario", id, i.Costos);
                if (!titulo) SincronizarRecursos(c, t, p, i, id, false, propietario, presentes, auxiliares);
            }
        }
        RetirarAusentes(c, t, propietario, presentes);
    }

    private static void SincronizarPiePresupuesto(SqliteConnection c, SqliteTransaction t,
        MYGPresupuestoDocumento presupuesto, string proyectoId, string presupuestoId)
    {
        var pie = presupuesto.Costos.PieDelphin;
        var importes = MYGPiePresupuesto.Filas(new[] { presupuesto });
        for (int n = 0; n < pie.Filas.Count; n++)
        {
            var fila = pie.Filas[n];
            long? id = long.TryParse(fila.IdTitulo, NumberStyles.Integer, CultureInfo.InvariantCulture, out long nativo) && nativo > 0
                ? nativo : null;
            // Una fila pertenece a un presupuesto; su estilo y demás columnas
            // quedan intactos. Las filas ajenas al pie que muestra MYG se conservan.
            string anterior = id.HasValue ? Texto(c, t, "SELECT id_presupuesto FROM titulo_pie WHERE id_titulo=$p0", id.Value) : null;
            if (!id.HasValue || (anterior != null && anterior != presupuestoId))
            {
                // Copiar como plantilla renueva el presupuesto y conserva sus
                // fórmulas. Sus filas reciben identidades propias sin tocar el
                // presupuesto original; al repetir el guardado se reutilizan.
                using var buscar = MYGBaseDatos.Comando(c, t, "SELECT id_titulo FROM titulo_pie " +
                    "WHERE id_presupuesto=$p0 AND clave=$p1 AND seccion_titulo=$p2 ORDER BY id_titulo LIMIT 1",
                    presupuestoId, fila.Clave, fila.Seccion);
                object existente = buscar.ExecuteScalar();
                id = existente == null ? null : Convert.ToInt64(existente, CultureInfo.InvariantCulture);
            }
            MYGBaseDatos.Ejecutar(c, t, """
                INSERT INTO titulo_pie(id_titulo,descripcion_titulo,posicion_titulo,id_presupuesto,
                    tipo_titulo,porcentaje_titulo,costo_titulo,formula,clave,seccion_titulo)
                VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9)
                ON CONFLICT(id_titulo) DO UPDATE SET descripcion_titulo=excluded.descripcion_titulo,
                    posicion_titulo=excluded.posicion_titulo,tipo_titulo=excluded.tipo_titulo,
                    porcentaje_titulo=excluded.porcentaje_titulo,costo_titulo=excluded.costo_titulo,
                    formula=excluded.formula,clave=excluded.clave,seccion_titulo=excluded.seccion_titulo
                """, id, fila.Nombre, fila.Posicion, presupuestoId, fila.Tipo, fila.Porcentaje,
                fila.Tipo == "V" ? fila.Valor : importes[n + 1].Importe,
                fila.Formula, fila.Clave, fila.Seccion);
        }
        if (pie.UnicoPorProyecto)
            MYGBaseDatos.Ejecutar(c, t, "UPDATE proyecto SET tipo_gasto='PR',label_costo_directo=$p1 WHERE id_proyecto=$p0",
                proyectoId, pie.NombreCostoDirecto);
        else
            MYGBaseDatos.Ejecutar(c, t, "UPDATE proyecto SET label_costo_directo=$p1 WHERE id_proyecto=$p0",
                proyectoId, pie.NombreCostoDirecto);
    }

    internal static void SincronizarDatosProyecto(SqliteConnection c, SqliteTransaction t,
        MYGProyectoDocumento documento, string proyectoId)
    {
        var datos = documento.Datos;
        if (datos == null || (!string.IsNullOrWhiteSpace(datos.FirmaImportada) && datos.FirmaImportada == datos.Firma())) return;
        datos.Validar();
        var actuales = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        using (var cmd = MYGBaseDatos.Comando(c, t, """
            SELECT id_propietario,id_portafolio,id_infraestructura,id_ubicacion,id_departamento,id_provincia,id_distrito,id_localidad,
                fecha_proyecto,fecha_inicio,fecha_fin,duracion,duracion_new,id_unidadtiempo,id_calendario,modalidad_ejecucion,acu_mode,fin_periodo
            FROM proyecto WHERE id_proyecto=$p0
            """, proyectoId))
        using (var r = cmd.ExecuteReader())
        {
            if (!r.Read()) throw new InvalidDataException("No existe el proyecto para guardar sus datos.");
            for (int n = 0; n < r.FieldCount; n++) actuales.Add(r.GetName(n), r.IsDBNull(n) ? null : r.GetValue(n));
        }
        string Actual(string columna) => Convert.ToString(actuales[columna], CultureInfo.InvariantCulture);
        bool heredado = !string.IsNullOrWhiteSpace(datos.FirmaImportada);
        var cambios = new List<(string Columna, object Valor)>();
        void Establecer(string columna, object valor)
        {
            string deseado = Convert.ToString(valor, CultureInfo.InvariantCulture);
            if (!string.Equals(Actual(columna), deseado, StringComparison.Ordinal)) cambios.Add((columna, valor));
        }
        void Fecha(string columna, DateTime? fecha)
        {
            if (DateTime.TryParse(Actual(columna), CultureInfo.GetCultureInfo("es-PE"), DateTimeStyles.None, out var actual))
            { if (fecha.HasValue && actual.Date == fecha.Value.Date) return; }
            else if (!fecha.HasValue && string.IsNullOrWhiteSpace(Actual(columna))) return;
            Establecer(columna, fecha?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
        }
        MYGOpcionProyecto Opcion(MYGCatalogoProyecto tipo, string id, string nombre, string columna, bool requerida = false)
        {
            var opciones = MYGCatalogosProyecto.Listar(c, t, tipo);
            MYGOpcionProyecto opcion = string.IsNullOrWhiteSpace(id)
                ? opciones.FirstOrDefault(x => string.Equals(x.Nombre, nombre, StringComparison.OrdinalIgnoreCase))
                : opciones.FirstOrDefault(x => string.Equals(x.Id, id, StringComparison.OrdinalIgnoreCase));
            if (opcion != null) return opcion;
            // Un identificador nativo heredado que falta en su catálogo se deja
            // intacto. Una selección nueva necesita una referencia real.
            if (heredado && !string.IsNullOrWhiteSpace(id) && string.Equals(Actual(columna), id, StringComparison.OrdinalIgnoreCase))
                return new MYGOpcionProyecto { Id = id, Nombre = nombre };
            if (requerida || !string.IsNullOrWhiteSpace(id) || !string.IsNullOrWhiteSpace(nombre))
                throw new InvalidDataException("La selección no existe en el catálogo de " + tipo + ". Cree la opción desde el formulario.");
            return null;
        }
        var propietario = Opcion(MYGCatalogoProyecto.Propietarios, datos.PropietarioId, datos.Propietario, "id_propietario");
        var portafolio = Opcion(MYGCatalogoProyecto.Portafolios, datos.PortafolioId, datos.Portafolio, "id_portafolio");
        var tipoObra = Opcion(MYGCatalogoProyecto.TiposObra, datos.TipoObraId,
            string.IsNullOrWhiteSpace(datos.TipoObra) ? "GENERAL" : datos.TipoObra, "id_infraestructura", true);
        Establecer("id_propietario", propietario?.Id); Establecer("id_portafolio", portafolio?.Id);
        Establecer("id_infraestructura", tipoObra.Id);
        bool ubicacionActual = string.Equals(Actual("id_ubicacion"), "Si", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(Actual("id_ubicacion"), "S", StringComparison.OrdinalIgnoreCase);
        if (ubicacionActual != datos.UsarUbicacion) Establecer("id_ubicacion", datos.UsarUbicacion ? "Si" : "No");
        if (datos.UsarUbicacion)
        {
            var departamento = Opcion(MYGCatalogoProyecto.Departamentos, datos.DepartamentoId, datos.Departamento, "id_departamento", true);
            var provincia = Opcion(MYGCatalogoProyecto.Provincias, datos.ProvinciaId, datos.Provincia, "id_provincia");
            var distrito = Opcion(MYGCatalogoProyecto.Distritos, datos.DistritoId, datos.Distrito, "id_distrito");
            var localidad = Opcion(MYGCatalogoProyecto.Localidades, datos.LocalidadId, datos.Localidad, "id_localidad");
            void ValidarPadre(MYGOpcionProyecto opcion, MYGOpcionProyecto padre, string etiqueta)
            {
                if (opcion != null && (padre == null || (!string.IsNullOrWhiteSpace(opcion.PadreId) &&
                    !string.Equals(opcion.PadreId, padre.Id, StringComparison.OrdinalIgnoreCase))))
                    throw new InvalidDataException("La selección de " + etiqueta + " no pertenece a la ubicación superior.");
            }
            ValidarPadre(provincia, departamento, "provincia"); ValidarPadre(distrito, provincia, "distrito");
            ValidarPadre(localidad, distrito, "localidad");
            Establecer("id_departamento", departamento.Id); Establecer("id_provincia", provincia?.Id);
            Establecer("id_distrito", distrito?.Id); Establecer("id_localidad", localidad?.Id);
        }
        else if (ubicacionActual)
        {
            Establecer("id_departamento", null); Establecer("id_provincia", null);
            Establecer("id_distrito", null); Establecer("id_localidad", null);
        }
        Fecha("fecha_proyecto", datos.FechaElaboracion); Fecha("fecha_inicio", datos.FechaInicio); Fecha("fecha_fin", datos.FechaFin);
        decimal Numero(string columna) => decimal.TryParse(Actual(columna), NumberStyles.Float, CultureInfo.InvariantCulture, out var n) ? n : 0;
        decimal duracionActual = Numero("duracion_new") > 0 ? Numero("duracion_new") : Numero("duracion");
        if (heredado && duracionActual <= 0) duracionActual = 1;
        if (duracionActual != datos.Duracion)
        {
            cambios.Add(("duracion", decimal.Truncate(datos.Duracion)));
            cambios.Add(("duracion_new", datos.Duracion));
        }
        string unidad = AsegurarUnidadTiempo(c, t, MYGDatosProyecto.UnidadCanonica(datos.UnidadDuracion), Actual("id_unidadtiempo"), heredado);
        Establecer("id_unidadtiempo", unidad);
        int? calendario = ResolverCalendario(c, t, datos, proyectoId, heredado, actuales["id_calendario"]);
        Establecer("id_calendario", calendario);
        if (!heredado || !string.IsNullOrWhiteSpace(Actual("modalidad_ejecucion")) || datos.ModalidadEjecucion != "C")
            Establecer("modalidad_ejecucion", datos.ModalidadEjecucion);
        string modo = datos.PorAsignacionRecursos ? "S" : "N";
        if (!heredado || !string.IsNullOrWhiteSpace(Actual("acu_mode")) || modo != "N") Establecer("acu_mode", modo);
        if (string.Equals(datos.Periodos, "Estándar", StringComparison.OrdinalIgnoreCase))
        { if (!heredado || actuales["fin_periodo"] != null) Establecer("fin_periodo", -1); }
        else if (!string.Equals(datos.Periodos, "Fin de período: " + Actual("fin_periodo"), StringComparison.Ordinal))
            throw new InvalidDataException("El período seleccionado no es compatible con el proyecto importado.");
        if (cambios.Count == 0) return;
        var valores = cambios.Select(x => x.Valor).Append(proyectoId).ToArray();
        MYGBaseDatos.Ejecutar(c, t, "UPDATE proyecto SET " + string.Join(",", cambios.Select((x, n) => x.Columna + "=$p" + n)) +
            " WHERE id_proyecto=$p" + cambios.Count, valores);
    }

    private static string AsegurarUnidadTiempo(SqliteConnection c, SqliteTransaction t, string unidad, string actual, bool heredado)
    {
        var unidades = new List<(string Id, string Simbolo, bool EsTiempo)>();
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id_unidad,COALESCE(NULLIF(abreviatura_unidad,''),descripcion_unidad,''),COALESCE(es_unidadtiempo,'N') FROM unidad"))
        using (var r = cmd.ExecuteReader()) while (r.Read()) unidades.Add((r.GetString(0), r.GetString(1), r.GetString(2) == "S"));
        string MarcarTiempo((string Id, string Simbolo, bool EsTiempo) u)
        {
            if (!u.EsTiempo) MYGBaseDatos.Ejecutar(c, t,
                "UPDATE unidad SET es_unidadtiempo='S',en_cronograma='S' WHERE id_unidad=$p0", u.Id);
            return u.Id;
        }
        bool Coincide(string simbolo)
        {
            try { return MYGDatosProyecto.UnidadCanonica(simbolo) == unidad; }
            catch (InvalidDataException) { return false; }
        }
        var existente = unidades.FirstOrDefault(u => u.Id == actual && Coincide(u.Simbolo));
        if (existente.Id != null) return heredado ? existente.Id : MarcarTiempo(existente);
        // El formulario anterior puede mostrar una unidad de tiempo no admitida
        // (por ejemplo años) como MESES. Cambiar otro dato no debe reemplazarla.
        if (heredado && unidad == "MESES" && !unidades.Any(u => u.Id == actual && Coincide(u.Simbolo))) return actual;
        existente = unidades.FirstOrDefault(u => Coincide(u.Simbolo));
        if (existente.Id != null) return MarcarTiempo(existente);
        string simbolo = unidad == "DIAS" ? "dia" : unidad == "SEMANAS" ? "semana" : "meses";
        string id = AsegurarUnidad(c, t, simbolo);
        MYGBaseDatos.Ejecutar(c, t, "UPDATE unidad SET es_unidadtiempo='S',en_cronograma='S' WHERE id_unidad=$p0", id);
        return id;
    }

    private static int? ResolverCalendario(SqliteConnection c, SqliteTransaction t, MYGDatosProyecto datos,
        string proyectoId, bool heredado, object actual)
    {
        if (datos.CalendarioId.HasValue)
        {
            using var cmd = MYGBaseDatos.Comando(c, t, "SELECT id_proyecto FROM calendario WHERE id_calendario=$p0", datos.CalendarioId.Value);
            using var r = cmd.ExecuteReader();
            if (r.Read())
            {
                string propietario = r.IsDBNull(0) ? null : r.GetString(0);
                if (!string.IsNullOrWhiteSpace(propietario) && propietario != proyectoId)
                    throw new InvalidDataException("El calendario pertenece a otro proyecto.");
                return datos.CalendarioId;
            }
            if (heredado && actual != null && Convert.ToInt32(actual, CultureInfo.InvariantCulture) == datos.CalendarioId.Value)
                return datos.CalendarioId;
            throw new InvalidDataException("El calendario seleccionado no existe.");
        }
        string nombre = string.IsNullOrWhiteSpace(datos.Calendario) ? "Predeterminado" : datos.Calendario;
        if (heredado && string.Equals(nombre, "Predeterminado", StringComparison.OrdinalIgnoreCase) &&
            (actual == null || Convert.ToInt32(actual, CultureInfo.InvariantCulture) <= 0))
            return actual == null ? null : Convert.ToInt32(actual, CultureInfo.InvariantCulture);
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id_calendario FROM calendario WHERE nombre_calendario=$p0 COLLATE NOCASE " +
            "AND (id_proyecto IS NULL OR id_proyecto='' OR id_proyecto=$p1) ORDER BY CASE WHEN id_proyecto=$p1 THEN 0 ELSE 1 END,id_calendario LIMIT 1", nombre, proyectoId))
        {
            object id = cmd.ExecuteScalar();
            if (id != null) return Convert.ToInt32(id, CultureInfo.InvariantCulture);
        }
        if (heredado && actual == null && string.Equals(nombre, "Predeterminado", StringComparison.OrdinalIgnoreCase)) return null;
        if (!string.Equals(nombre, "Predeterminado", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("El calendario seleccionado no existe.");
        using var crear = MYGBaseDatos.Comando(c, t,
            "INSERT INTO calendario(nombre_calendario,id_proyecto) VALUES('Predeterminado',$p0) RETURNING id_calendario", proyectoId);
        return Convert.ToInt32(crear.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    private static string Auxiliar(SqliteConnection c, SqliteTransaction t, MYGPresupuestoDocumento p,
        ItemPresupuestoDelphin i, string propietario, HashSet<string> presentes, Dictionary<string, string> auxiliares)
    {
        if (auxiliares.TryGetValue(i.IdLocalMYG, out string actual)) return actual;
        string id = HashId("auxiliar:" + propietario + ":" + p.Id + ":" + i.IdLocalMYG);
        auxiliares.Add(i.IdLocalMYG, id);
        GuardarAnalisis(c, t, p, i, id, i.Item);
        Registrar(c, t, propietario, "analisis_costo", id, presentes);
        SincronizarRecursos(c, t, p, i, id, true, propietario, presentes, auxiliares);
        return id;
    }
    private static void GuardarAnalisis(SqliteConnection c, SqliteTransaction t, MYGPresupuestoDocumento p,
        ItemPresupuestoDelphin i, string id, string codigo)
    {
        var acu = MYGMotorPresupuestos.Analizar(p, i);
        MYGBaseDatos.Ejecutar(c, t, """
            INSERT INTO analisis_costo(id_analisiscosto,descripcion_costo,id_unidad,costo_unitario,productividad,
                magnitud_unidadtiempo,tipo_rendimiento,tiene_composicion,id_infraestructura,codigo_listaprecio,
                especificaciones,especificaciones_texto)
            VALUES($p0,$p1,$p2,$p3,$p4,$p5,'D',$p6,$p7,$p8,$p9,'S') ON CONFLICT(id_analisiscosto) DO UPDATE SET
                descripcion_costo=excluded.descripcion_costo,id_unidad=excluded.id_unidad,costo_unitario=excluded.costo_unitario,
                productividad=excluded.productividad,magnitud_unidadtiempo=excluded.magnitud_unidadtiempo,
                tipo_rendimiento=excluded.tipo_rendimiento,tiene_composicion=excluded.tiene_composicion
            """, id, i.Descripcion, AsegurarUnidad(c, t, i.Unidad), acu.PrecioUnitario, i.Costos.RendimientoDiario,
            i.Costos.JornadaHoras, acu.Recursos.Count > 0 ? "S" : "N", InfraestructuraGeneral, codigo,
            i.Costos.EspecificacionEsBorrador ? "" : i.Costos.EspecificacionTexto);
        SincronizarEspecificacion(c, t, "analisis_costo", id, i.Costos);
        SincronizarCodigoAnalisis(c, t, id, codigo);
    }

    private static void SincronizarCodigoAnalisis(SqliteConnection c, SqliteTransaction t, string id, string codigo)
    {
        string original = "";
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT codigo_clase,codigo_subclase,codigo_listaprecio FROM analisis_costo WHERE id_analisiscosto=$p0", id))
        using (var r = cmd.ExecuteReader()) if (r.Read()) original = string.Join(".", Enumerable.Range(0, 3)
            .Select(n => r.IsDBNull(n) ? "" : r.GetString(n)).Where(x => !string.IsNullOrWhiteSpace(x)));
        if (string.IsNullOrWhiteSpace(original)) original = id;
        if (codigo == original || codigo == original + " [" + id + "]") return;
        string[] partes = (codigo ?? "").Split('.');
        MYGBaseDatos.Ejecutar(c, t, "UPDATE analisis_costo SET codigo_clase=$p1,codigo_subclase=$p2,codigo_listaprecio=$p3 WHERE id_analisiscosto=$p0",
            id, partes.Length == 3 ? partes[0] : null, partes.Length == 3 ? partes[1] : null, partes.Length == 3 ? partes[2] : codigo);
    }

    // Una reordenación visual conserva importes y metadatos nativos. Sólo cambia
    // posiciones dentro de subtotales planos cuyos recursos se identifican exactamente.
    private static void SincronizarOrdenRecursosConservados(SqliteConnection c, SqliteTransaction t, string partida,
        List<MYGRecursoACU> recursos)
    {
        var filas = new List<(string Id, string Subtotal, int Posicion)>();
        using (var cmd = MYGBaseDatos.Comando(c, t, """
            SELECT r.id_composicion,r.id_subtotal,COALESCE(r.posicion_composicion,0)
            FROM composicion_costounitario r JOIN subtotal_costounitario s ON s.id_subtotal=r.id_subtotal
            WHERE s.id_costounitario=$p0 AND COALESCE(s.id_composicionpadre,'')=''
            ORDER BY COALESCE(r.posicion_composicion,0),r.id_composicion
            """, partida))
        using (var lector = cmd.ExecuteReader()) while (lector.Read()) filas.Add((lector.GetString(0), lector.GetString(1), lector.GetInt32(2)));
        var orden = recursos.Select(r => IdNativo(r.Id)).ToList();
        if (orden.Count != filas.Count || orden.Distinct(StringComparer.Ordinal).Count() != orden.Count ||
            !orden.ToHashSet(StringComparer.Ordinal).SetEquals(filas.Select(f => f.Id))) return;
        foreach (var grupo in filas.GroupBy(f => f.Subtotal))
        {
            var actuales = grupo.ToList(); var ids = actuales.Select(f => f.Id).ToHashSet(StringComparer.Ordinal);
            var deseados = orden.Where(ids.Contains).ToList();
            if (actuales.Select(f => f.Id).SequenceEqual(deseados)) continue;
            var posiciones = actuales.Select(f => f.Posicion).ToArray();
            if (posiciones.Distinct().Count() != posiciones.Length) posiciones = Enumerable.Range(0, posiciones.Length).ToArray();
            for (int n = 0; n < deseados.Count; n++) MYGBaseDatos.Ejecutar(c, t,
                "UPDATE composicion_costounitario SET posicion_composicion=$p1 WHERE id_composicion=$p0 AND id_subtotal=$p2", deseados[n], posiciones[n], grupo.Key);
        }
    }

    private static bool AnalisisNativoIntacto(SqliteConnection c, SqliteTransaction t,
        MYGPresupuestoDocumento p, ItemPresupuestoDelphin raiz, string id)
    {
        if (MYGMotorPresupuestos.ConservaAnalisisDelphin(p, raiz)) return true;
        string unidadOriginal = Texto(c, t, """
            SELECT COALESCE(NULLIF(u.abreviatura_unidad,''),NULLIF(u.descripcion_unidad,''),'und')
            FROM analisis_costo a LEFT JOIN unidad u ON u.id_unidad=a.id_unidad WHERE a.id_analisiscosto=$p0
            """, id);
        if (unidadOriginal == null) return false;
        var copia = MYGProyectoStorage.Copia(raiz); copia.Unidad = unidadOriginal;
        return MYGMotorPresupuestos.ConservaAnalisisDelphin(p, copia);
    }

    private static void SincronizarRecursos(SqliteConnection c, SqliteTransaction t, MYGPresupuestoDocumento p,
        ItemPresupuestoDelphin partida, string idPartida, bool analisis, string propietario,
        HashSet<string> presentes, Dictionary<string, string> auxiliares)
    {
        string tablaSubtotal = analisis ? "subtotal_analisiscosto" : "subtotal_costounitario";
        string columnaPartida = analisis ? "id_analisiscosto" : "id_costounitario";
        string tablaComposicion = analisis ? "composicion_analisiscosto" : "composicion_costounitario";
        var acu = MYGMotorPresupuestos.Analizar(p, partida);
        int posicion = 0;
        foreach (var grupo in acu.Recursos.GroupBy(x => x.Recurso.Grupo))
        {
            string tipo = Tipo(grupo.Key);
            string subtotal = Texto(c, t, "SELECT id_subtotal FROM " + tablaSubtotal + " WHERE " + columnaPartida +
                "=$p0 AND id_tipocosto=$p1 AND COALESCE(id_composicionpadre,'')='' ORDER BY id_subtotal LIMIT 1", idPartida, tipo)
                ?? HashId(tablaSubtotal + ":" + idPartida + ":" + tipo);
            MYGBaseDatos.Ejecutar(c, t, "INSERT INTO " + tablaSubtotal + "(id_subtotal," + columnaPartida +
                ",id_tipocosto,subtotal,estado_expandido,factor_cantidad) VALUES($p0,$p1,$p2,$p3,'S',1) " +
                "ON CONFLICT(id_subtotal) DO UPDATE SET subtotal=excluded.subtotal", subtotal, idPartida, tipo, grupo.Sum(x => x.Total));
            Registrar(c, t, propietario, tablaSubtotal, subtotal, presentes);
            foreach (var resultado in grupo)
            {
                var r = resultado.Recurso;
                string id = analisis ? HashId(tablaComposicion + ":" + idPartida + ":" + r.Id) : IdNativo(r.Id);
                string producto = null, auxiliar = null;
                if (r.Grupo == MYGGrupoRecurso.Subpartidas)
                    auxiliar = Auxiliar(c, t, p, p.Items.First(x => x.IdLocalMYG == r.SubpartidaIdLocal), propietario, presentes, auxiliares);
                else producto = Producto(c, t, p.Costos.Insumos.First(x => x.Id == r.InsumoId), p.Id, false);
                string unidad = AsegurarUnidad(c, t, resultado.Unidad);
                decimal factor = r.Modo == MYGModoCantidad.PorcentajeManoObra ? 0.01m : 1m;
                // Las cantidades efectivas ya incluyen desperdicio y precisión MYG;
                // guardarlas como cantidad directa evita aplicar desperdicio dos veces.
                MYGBaseDatos.Ejecutar(c, t, "INSERT INTO " + tablaComposicion + """
                    (id_composicion,descripcion_composicion,id_subtotal,id_unidad,personal_base,magnitud_unidadcomposicion,
                        cantidad_composicion,costo_composicion,parcial_composicion,id_listaprecio,id_costoauxiliar,
                        es_composiciondependiente,es_subcomposicion,posicion_composicion,porcentaje_desperdicio,
                        productividad,magnitud_unidadtiempo,tipo_rendimiento,codigo_listaprecio)
                    VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11,'N',$p12,0,1,$p13,'D',$p14)
                    ON CONFLICT(id_composicion) DO UPDATE SET descripcion_composicion=excluded.descripcion_composicion,
                        id_subtotal=excluded.id_subtotal,id_unidad=excluded.id_unidad,personal_base=excluded.personal_base,
                        magnitud_unidadcomposicion=excluded.magnitud_unidadcomposicion,cantidad_composicion=excluded.cantidad_composicion,
                        costo_composicion=excluded.costo_composicion,parcial_composicion=excluded.parcial_composicion,
                        id_listaprecio=excluded.id_listaprecio,id_costoauxiliar=excluded.id_costoauxiliar,
                        es_composiciondependiente=excluded.es_composiciondependiente,es_subcomposicion=excluded.es_subcomposicion,
                        posicion_composicion=excluded.posicion_composicion,porcentaje_desperdicio=excluded.porcentaje_desperdicio,
                        productividad=excluded.productividad,magnitud_unidadtiempo=excluded.magnitud_unidadtiempo,
                        tipo_rendimiento=excluded.tipo_rendimiento,codigo_listaprecio=excluded.codigo_listaprecio
                    """, id, resultado.Descripcion, subtotal, unidad, r.NumeroRecursos, factor,
                    resultado.Cantidad, resultado.Precio, resultado.Total, producto, auxiliar,
                    r.Modo == MYGModoCantidad.PorcentajeManoObra ? "S" : "N", posicion++, partida.Costos.JornadaHoras, resultado.Codigo);
                Registrar(c, t, propietario, tablaComposicion, id, presentes);
            }
        }
    }

    internal static void SincronizarEntradaCatalogo(SqliteConnection c, SqliteTransaction t, bool partidas, string id)
        => SincronizarCatalogos(c, t, id, partidas);

    internal static bool EliminarEntradaCatalogo(SqliteConnection c, SqliteTransaction t, bool partidas, string id)
    {
        PrepararRegistro(c, t);
        string nativo = IdNativo(id), tabla = partidas ? "analisis_costo" : "producto";
        string propietario = partidas ? "catalogo_partida:" + id : "catalogo_insumo:" + id;
        // Los catálogos externos pueden usarse en almacén, compras, cronogramas
        // y otros módulos ajenos al documento MYG. Sólo las copias creadas con
        // identidad propia MYG participan en la eliminación nativa de catálogo.
        if (id == nativo) return !Existe(c, t, tabla, ColumnaId(tabla), nativo);
        if (Texto(c, t, "SELECT propietario FROM myg_delphin_fila WHERE tabla=$p0 AND id_nativo=$p1", tabla, nativo) != propietario)
            return !Existe(c, t, tabla, ColumnaId(tabla), nativo);
        if (partidas ? ReferenciadoAnalisis(c, t, nativo) : ReferenciaProducto(c, t, nativo)) return false;
        RetirarAusentes(c, t, propietario, new HashSet<string>(StringComparer.Ordinal));
        return true;
    }

    internal static void SincronizarCatalogos(SqliteConnection c, SqliteTransaction t, string idEntrada = null, bool? soloPartidas = null)
    {
        PrepararRegistro(c, t);
        if (idEntrada == null) SincronizarUnidades(c, t);
        var insumos = new List<MYGInsumo>();
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id,codigo,descripcion,unidad,grupo,precio FROM catalogo_insumo" +
            (soloPartidas == true ? " WHERE 0" : idEntrada == null ? "" : " WHERE id=$p0"), idEntrada))
        using (var r = cmd.ExecuteReader()) while (r.Read()) insumos.Add(new MYGInsumo
        {
            Id = r.GetString(0),
            Codigo = r.GetString(1),
            Descripcion = r.GetString(2),
            Unidad = r.GetString(3),
            Grupo = Enum.Parse<MYGGrupoRecurso>(r.GetString(4)),
            Precio = decimal.Parse(r.GetString(5), CultureInfo.InvariantCulture)
        });
        foreach (var i in insumos)
        {
            string nativo = Producto(c, t, i, "catalogo", true);
            Registrar(c, t, "catalogo_insumo:" + i.Id, "producto", nativo, new HashSet<string>(StringComparer.Ordinal));
        }
        var partidas = new List<(string Id, string Codigo, string Json)>();
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id,codigo,json_plantilla FROM catalogo_partida" +
            (soloPartidas == false ? " WHERE 0" : idEntrada == null ? "" : " WHERE id=$p0"), idEntrada))
        using (var r = cmd.ExecuteReader()) while (r.Read()) partidas.Add((r.GetString(0), r.GetString(1), r.GetString(2)));
        foreach (var entrada in partidas)
        {
            var plantilla = System.Text.Json.JsonSerializer.Deserialize<MYGPlantillaPartidaCosto>(entrada.Json, MYGProyectoStorage.Opciones);
            var p = new MYGPresupuestoDocumento
            {
                Id = entrada.Id,
                Nombre = "Catálogo",
                Items = plantilla.Partidas,
                Costos = new MYGCostosPresupuesto
                {
                    Insumos = plantilla.Insumos,
                    DecimalesPrecio = plantilla.DecimalesPrecio,
                    DecimalesCantidad = plantilla.DecimalesCantidad
                }
            };
            var raiz = p.Items.Single(x => x.IdLocalMYG == plantilla.RaizLocalId);
            string propietario = "catalogo_partida:" + entrada.Id;
            var presentes = new HashSet<string>(StringComparer.Ordinal);
            var auxiliares = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string id = IdNativo(entrada.Id);
            auxiliares[raiz.IdLocalMYG] = id;
            bool importada = entrada.Id == id && raiz.Costos.PrecioImportadoDelphin.HasValue &&
                Existe(c, t, "analisis_costo", "id_analisiscosto", id);
            if (importada)
            {
                if (!AnalisisNativoIntacto(c, t, p, raiz, id))
                    throw new InvalidOperationException("Este análisis Delphin contiene una composición nativa importada. " +
                        "Guárdelo con un código nuevo para editar una copia y conservar el análisis original.");
                MYGBaseDatos.Ejecutar(c, t, "UPDATE analisis_costo SET descripcion_costo=$p1,id_unidad=$p2 WHERE id_analisiscosto=$p0",
                    id, raiz.Descripcion, AsegurarUnidad(c, t, raiz.Unidad));
                SincronizarCodigoAnalisis(c, t, id, entrada.Codigo);
                SincronizarEspecificacion(c, t, "analisis_costo", id, raiz.Costos);
                Registrar(c, t, propietario, "analisis_costo", id, presentes);
                ConservarRecursos(c, t, id, true, presentes, new HashSet<string>(StringComparer.Ordinal), propietario);
                using (var precioActual = MYGBaseDatos.Comando(c, t, "SELECT costo_unitario FROM analisis_costo WHERE id_analisiscosto=$p0", id))
                {
                    decimal precioNativo = Convert.ToDecimal(precioActual.ExecuteScalar(), CultureInfo.InvariantCulture);
                    // Al cambiar unidad sin editar recursos, el precio histórico
                    // sigue vigente. Renueva su firma en la plantilla privada.
                    MYGMotorPresupuestos.CapturarPrecioDelphin(p, raiz, precioNativo, 0);
                    MYGBaseDatos.Ejecutar(c, t, "UPDATE catalogo_partida SET json_plantilla=$p1,precio=$p2 WHERE id=$p0",
                        entrada.Id, MYGBaseDatos.Json(plantilla), precioNativo);
                    MYGBaseDatos.Ejecutar(c, t, "UPDATE catalogo_partida_nodo SET json_datos=$p2 WHERE catalogo_id=$p0 AND id_local=$p1",
                        entrada.Id, raiz.IdLocalMYG, MYGBaseDatos.Json(raiz.Costos));
                }
                continue;
            }
            GuardarAnalisis(c, t, p, raiz, id, entrada.Codigo);
            Registrar(c, t, propietario, "analisis_costo", id, presentes);
            SincronizarRecursos(c, t, p, raiz, id, true, propietario, presentes, auxiliares);
            RetirarAusentes(c, t, propietario, presentes);
        }
    }
}
