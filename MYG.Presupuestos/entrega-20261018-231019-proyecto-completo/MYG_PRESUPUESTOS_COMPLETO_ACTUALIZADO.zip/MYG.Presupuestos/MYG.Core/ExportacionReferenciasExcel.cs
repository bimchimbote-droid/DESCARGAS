using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace MYG_2027;

public static partial class MYGExcelPresupuestos
{
    /// <summary>Copia los metrados Excel del presupuesto y todos sus orígenes,
    /// incluidos los de otros presupuestos del proyecto. No modifica las hojas originales.</summary>
    public static IReadOnlyList<MYGHojaMetrado> CrearHojasMetradoParaExportar(
        MYGPresupuestoDocumento presupuesto, IEnumerable<MYGPresupuestoDocumento> presupuestos = null)
    {
        if (presupuesto == null) throw new ArgumentNullException(nameof(presupuesto));
        return CrearHojasMetradoParaExportar(new[] { presupuesto },
            presupuestos ?? presupuesto.ContextoReferencias?.Presupuestos ?? new[] { presupuesto });
    }

    /// <summary>Copia los metrados Excel de todo el proyecto y sus dependencias,
    /// sin repetir una partida compartida por varias fórmulas o presupuestos.</summary>
    public static IReadOnlyList<MYGHojaMetrado> CrearHojasMetradoParaExportar(
        IEnumerable<MYGPresupuestoDocumento> presupuestos)
    {
        if (presupuestos == null) throw new ArgumentNullException(nameof(presupuestos));
        var seleccionados = presupuestos.Where(p => p != null).ToArray();
        return CrearHojasMetradoParaExportar(seleccionados, seleccionados);
    }

    private static IReadOnlyList<MYGHojaMetrado> CrearHojasMetradoParaExportar(
        IReadOnlyList<MYGPresupuestoDocumento> seleccionados, IEnumerable<MYGPresupuestoDocumento> disponibles)
    {
        var partidas = disponibles.Where(p => p != null).Concat(seleccionados)
            .SelectMany(p => (p.Items ?? new()).Where(i => i != null && !MYGProyectoStorage.EsTitulo(i))
                .Select(i => (Presupuesto: p, Partida: i)))
            .GroupBy(x => MYGExportacionReferenciasExcel.Clave(x.Presupuesto.Id, x.Partida.IdLocalMYG ?? x.Partida.Id))
            .ToDictionary(g => g.Key, g => g.Last());
        var pendientes = new Queue<(MYGPresupuestoDocumento Presupuesto, ItemPresupuestoDelphin Partida)>();
        foreach (var p in seleccionados)
            foreach (var i in p.Items ?? new())
                if (i != null && !MYGProyectoStorage.EsTitulo(i) && i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel)
                    pendientes.Enqueue((p, i));
        var incluidas = new HashSet<(string, string)>();
        var hojas = new List<MYGHojaMetrado>();
        while (pendientes.TryDequeue(out var entrada))
        {
            var (p, i) = entrada;
            var clave = MYGExportacionReferenciasExcel.Clave(p.Id, i.IdLocalMYG ?? i.Id);
            if (i.Costos?.Hoja == null || !incluidas.Add(clave)) continue;
            var copia = MYGProyectoStorage.Copia(i.Costos.Hoja);
            copia.PresupuestoReferenciasId = p.Id;
            copia.PartidaReferenciasId = i.IdLocalMYG ?? i.Id;
            string codigoPresupuesto = string.IsNullOrWhiteSpace(p.Item) ? p.Id : p.Item.Trim();
            string codigoPartida = string.IsNullOrWhiteSpace(i.Item) ? i.IdLocalMYG ?? i.Id : i.Item.Trim();
            copia.Nombre = "Metrado " + codigoPresupuesto + "-" + codigoPartida;
            hojas.Add(copia);
            foreach (var r in copia.ReferenciasPartidas ?? new())
                if (partidas.TryGetValue(MYGExportacionReferenciasExcel.Clave(r.PresupuestoId, r.PartidaLocalId), out var origen))
                    pendientes.Enqueue(origen);
        }
        return hojas;
    }
}

// El mapa depende de la identidad guardada de cada partida y de los nombres
// finales del libro. Nunca intenta deducir un origen de su descripción o ítem.
internal sealed class MYGExportacionReferenciasExcel
{
    private static readonly Regex Llamada = new(
        @"METRADO\s*\(\s*""(?<alias>(?:[^""]|"""")*)""\s*[;,]\s*""(?<dir>(?:[^""]|"""")*)""\s*\)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private readonly Dictionary<(string, string), (MYGHojaMetrado Hoja, string Nombre)> origenes = new();
    private readonly MYGSesionHojaCalculo calculo;
    internal IReadOnlyList<string> Nombres { get; }
    internal static (string, string) Clave(string presupuesto, string partida) =>
        ((presupuesto ?? "").ToUpperInvariant(), (partida ?? "").ToUpperInvariant());

    internal MYGExportacionReferenciasExcel(IReadOnlyList<MYGHojaMetrado> hojas)
    {
        var nombres = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var finales = new List<string>();
        foreach (var h in hojas)
        {
            string nombre = Regex.Replace(h.Nombre ?? "Hoja", @"[\[\]:*?/\\]", " ");
            nombre = new string(nombre.Where(XmlConvert.IsXmlChar).ToArray()).Trim(' ', '\'');
            if (nombre.Length == 0) nombre = "Hoja";
            nombre = nombre[..Math.Min(31, nombre.Length)].TrimEnd('\'');
            string baseNombre = nombre;
            for (int numero = 2; !nombres.Add(nombre); numero++)
            {
                string sufijo = " " + numero.ToString(CultureInfo.InvariantCulture);
                nombre = baseNombre[..Math.Min(31 - sufijo.Length, baseNombre.Length)] + sufijo;
            }
            finales.Add(nombre);
            if (!string.IsNullOrEmpty(h.PresupuestoReferenciasId) && !string.IsNullOrEmpty(h.PartidaReferenciasId))
                origenes.TryAdd(Clave(h.PresupuestoReferenciasId, h.PartidaReferenciasId), (h, nombre));
        }
        Nombres = finales;
        // Las fórmulas nativas y su caché deben referirse a las mismas copias.
        // Conservamos los orígenes fuera del libro para el fallback aislado y
        // construimos un contexto privado sin cambiar el proyecto ni sus hojas.
        var presupuestos = hojas.SelectMany(h => h.ContextoReferencias?.Presupuestos ?? Array.Empty<MYGPresupuestoDocumento>())
            .GroupBy(p => p.Id, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => new MYGPresupuestoDocumento
            { Id = g.Key, Items = new(g.First().Items ?? new()) }, StringComparer.OrdinalIgnoreCase);
        foreach (var origen in origenes.Values)
        {
            var h = origen.Hoja;
            if (!presupuestos.TryGetValue(h.PresupuestoReferenciasId, out var p))
            {
                p = new MYGPresupuestoDocumento { Id = h.PresupuestoReferenciasId };
                presupuestos.Add(p.Id, p);
            }
            p.Items.RemoveAll(i => i != null && MYGReferenciasMetrado.Igual(i.IdLocalMYG ?? i.Id, h.PartidaReferenciasId));
            p.Items.Add(new ItemPresupuestoDelphin { Id = h.PartidaReferenciasId, IdLocalMYG = h.PartidaReferenciasId,
                TipoPropuesta = "PARTIDA", Costos = new MYGDatosPartida { Hoja = h } });
        }
        calculo = new MYGSesionHojaCalculo(new MYGContextoReferenciasMetrado(presupuestos.Values));
    }

    internal MYGValorExcel Resultado(MYGHojaMetrado hoja, string direccion) => calculo.Resultado(hoja, direccion);

    internal bool IntentarConvertir(MYGHojaMetrado destino, string formula, out string formulaExcel)
    {
        // Traducir primero conserva el criterio original de coma decimal y los
        // argumentos locales, incluso si al reemplazar METRADO desaparece el ;.
        formula = MYGFuncionesExcel.AOpenXml(formula);
        var salida = new StringBuilder();
        for (int i = 0; i < formula.Length; i++)
        {
            char actual = formula[i];
            if (actual is '"' or '\'')
            {
                char comilla = actual;
                salida.Append(actual);
                while (++i < formula.Length)
                {
                    salida.Append(formula[i]);
                    if (formula[i] != comilla) continue;
                    if (i + 1 < formula.Length && formula[i + 1] == comilla) { salida.Append(formula[++i]); continue; }
                    break;
                }
                continue;
            }
            if (!EsLlamada(formula, i)) { salida.Append(actual); continue; }
            var llamada = Llamada.Match(formula, i);
            if (!llamada.Success || llamada.Index != i) { formulaExcel = null; return false; }
            string alias = llamada.Groups["alias"].Value.Replace("\"\"", "\"");
            string direccion = MYGHojaCalculo.Normalizar(llamada.Groups["dir"].Value.Replace("\"\"", "\""));
            var referencia = destino.ReferenciasPartidas?.FirstOrDefault(r =>
                MYGReferenciasMetrado.Igual(r.Alias, alias) && MYGReferenciasMetrado.Igual(r.DireccionFormula, direccion));
            if (referencia == null || !origenes.TryGetValue(Clave(referencia.PresupuestoId, referencia.PartidaLocalId), out var origen))
            { formulaExcel = null; return false; }
            var ancla = origen.Hoja.AnclasReferencias?.FirstOrDefault(a => MYGReferenciasMetrado.Igual(a.Id, referencia.AnclaId));
            string celda = ancla?.Direccion ?? (referencia.Pendiente ? direccion : "");
            if (string.IsNullOrEmpty(celda) || celda == "#REF!") salida.Append("#REF!");
            else salida.Append('\'').Append(origen.Nombre.Replace("'", "''")).Append("'!").Append(MYGHojaCalculo.Normalizar(celda));
            i += llamada.Length - 1;
        }
        formulaExcel = salida.ToString();
        return true;
    }

    private static bool EsLlamada(string formula, int indice)
    {
        if (indice > 0 && (char.IsLetterOrDigit(formula[indice - 1]) || formula[indice - 1] is '_' or '.')) return false;
        if (!formula.AsSpan(indice).StartsWith("METRADO", StringComparison.OrdinalIgnoreCase)) return false;
        int fin = indice + 7;
        while (fin < formula.Length && char.IsWhiteSpace(formula[fin])) fin++;
        return fin < formula.Length && formula[fin] == '(';
    }
}
