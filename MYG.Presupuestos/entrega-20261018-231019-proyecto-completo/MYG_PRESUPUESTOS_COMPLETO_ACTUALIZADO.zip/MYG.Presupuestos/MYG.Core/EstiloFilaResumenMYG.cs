using System;
using System.IO;

namespace MYG_2027;

public sealed class MYGEstiloFilaResumen
{
    public string Fuente { get; set; } = "Tahoma";
    public decimal Tamano { get; set; } = 8.25m;
    public bool Negrita { get; set; }
    public bool Cursiva { get; set; }
    public bool Tachado { get; set; }
    public bool Subrayado { get; set; }
    public string ColorTexto { get; set; } = "#000000";
    public string ColorFondo { get; set; } = "#FFFFFF";

    internal static void Validar(MYGEstiloFilaResumen estilo)
    {
        if (estilo == null || string.IsNullOrWhiteSpace(estilo.Fuente) || estilo.Fuente.Length > 200 ||
            estilo.Tamano < 1 || estilo.Tamano > 200 || !EsColor(estilo.ColorTexto) || !EsColor(estilo.ColorFondo))
            throw new InvalidDataException("El formato de la fila de resumen contiene una fuente, tamaño o color inválido.");
    }

    private static bool EsColor(string valor) => valor?.Length == 7 && valor[0] == '#' &&
        int.TryParse(valor.AsSpan(1), System.Globalization.NumberStyles.HexNumber, System.Globalization.CultureInfo.InvariantCulture, out _);
}
