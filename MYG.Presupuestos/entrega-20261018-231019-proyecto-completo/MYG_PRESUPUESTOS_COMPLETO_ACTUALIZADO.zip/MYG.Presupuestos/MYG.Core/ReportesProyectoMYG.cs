using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGTipoReporteProyecto
{
    PresupuestoSeleccionado, TodosPresupuestos, HojaResumen, AnalisisCostosUnitarios,
    ConsolidadoCostosUnitarios, Metrados, MetradosAceros
}

public sealed class MYGHojaReporteProyecto
{
    public string Titulo { get; }
    public MYGHojaMetrado Hoja { get; }
    /// <summary>Información de cabecera congelada al crear el informe. No contiene
    /// vínculos a los datos editables del proyecto ni modifica la hoja de metrado.</summary>
    public IReadOnlyList<KeyValuePair<string, string>> DatosProyecto { get; }
    /// <summary>Identifica el informe de partidas del presupuesto de obra.</summary>
    public bool EsPresupuestoObra { get; }
    public bool EsResumenProyecto { get; }
    public bool EsConsolidadoCostosUnitarios { get; }
    public bool EsListadoMetrados { get; }
    public bool EsListaInsumos { get; }
    /// <summary>Comparte la presentación de obra sin cambiar el alcance del informe.</summary>
    public bool UsaFormatoPresupuesto => EsPresupuestoObra || EsResumenProyecto || EsConsolidadoCostosUnitarios || EsListadoMetrados || EsListaInsumos;
    /// <summary>Presentación compacta y continua de los análisis del presupuesto.</summary>
    public bool EsAnalisisCostosUnitarios { get; }
    /// <summary>El título y los datos generales ya están materializados en celdas.</summary>
    public bool CabeceraEnHoja { get; }
    public string TituloImpresion => EsPresupuestoObra ? "PRESUPUESTO DE OBRA"
        : EsResumenProyecto ? "HOJA DE RESUMEN"
        : EsConsolidadoCostosUnitarios ? "CONSOLIDADO DE COSTOS UNITARIOS"
        : EsListadoMetrados ? "METRADOS"
        : EsAnalisisCostosUnitarios ? "Análisis de Costos Unitarios" : Titulo;
    /// <summary>Fila del informe y nivel real en la estructura del presupuesto.
    /// La raíz es nivel cero; no se infiere la jerarquía del texto de los códigos.</summary>
    public IReadOnlyDictionary<int, int> NivelesTitulos { get; }
    // Alturas base de las filas cuyo alto calculado puede variar con el ancho.
    // Sólo pertenecen al informe generado; no se guardan en el proyecto.
    internal IReadOnlyDictionary<int, int> AltosMinimosFilas { get; set; } = new Dictionary<int, int>();
    /// <summary>Filas visibles de la cabecera. Los demás metadatos del proyecto
    /// se conservan en DatosProyecto para los informes que los necesitan.</summary>
    public IReadOnlyList<KeyValuePair<string, string>> CabeceraImpresion
    {
        get
        {
            if (!UsaFormatoPresupuesto && !EsAnalisisCostosUnitarios) return DatosProyecto;
            string Dato(string clave) => DatosProyecto.FirstOrDefault(d => d.Key == clave).Value ?? "No registrado";
            var datos = new List<KeyValuePair<string, string>> { new("PROYECTO", Dato("Proyecto")) };
            if ((!EsResumenProyecto && !EsListaInsumos) || !string.IsNullOrWhiteSpace(Dato("Presupuesto")))
                datos.Add(new("PRESUPUESTO", Dato("Presupuesto")));
            if (EsListaInsumos && DatosProyecto.FirstOrDefault(d => d.Key == "Título").Value is { Length: > 0 } seleccion)
                datos.Add(new("TÍTULO", seleccion));
            datos.AddRange(new KeyValuePair<string, string>[]
            {
                new("PROPIETARIO", Dato("Propietario")),
                new("UBICACIÓN", "DPTO: " + Dato("Departamento") + "  PROV: " + Dato("Provincia") + "  DIST: " + Dato("Distrito")),
                new("FECHA DE PROY.", Dato("Fecha de elaboración"))
            });
            return datos.AsReadOnly();
        }
    }

    public MYGHojaReporteProyecto(string titulo, MYGHojaMetrado hoja,
        IEnumerable<KeyValuePair<string, string>> datosProyecto = null, bool presupuestoObra = false,
        IReadOnlyDictionary<int, int> nivelesTitulos = null, bool analisisCostosUnitarios = false,
        bool cabeceraEnHoja = false, bool resumenProyecto = false, bool consolidadoCostosUnitarios = false,
        bool listadoMetrados = false, bool listaInsumos = false)
    {
        Titulo = titulo ?? "";
        Hoja = hoja ?? throw new ArgumentNullException(nameof(hoja));
        DatosProyecto = Array.AsReadOnly((datosProyecto ?? Array.Empty<KeyValuePair<string, string>>())
            .Select(d => new KeyValuePair<string, string>(d.Key ?? "", d.Value ?? "")).ToArray());
        EsPresupuestoObra = presupuestoObra;
        EsResumenProyecto = resumenProyecto;
        EsConsolidadoCostosUnitarios = consolidadoCostosUnitarios;
        EsListadoMetrados = listadoMetrados;
        EsListaInsumos = listaInsumos;
        EsAnalisisCostosUnitarios = analisisCostosUnitarios;
        CabeceraEnHoja = cabeceraEnHoja;
        NivelesTitulos = new ReadOnlyDictionary<int, int>((nivelesTitulos ?? new Dictionary<int, int>())
            .ToDictionary(n => n.Key, n => n.Value));
    }
}

/// <summary>Instantáneas de impresión. Los cálculos, la validación y los vínculos
/// de metrados viven en una copia completa y nunca cambian el editor abierto.</summary>
public static partial class MYGReportesProyecto
{
    public static IReadOnlyList<MYGHojaReporteProyecto> Crear(MYGProyectoDocumento documento,
        string presupuestoId, MYGTipoReporteProyecto tipo)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (!Enum.IsDefined(tipo)) throw new ArgumentOutOfRangeException(nameof(tipo));
        var trabajo = Preparar(documento);
        if (tipo == MYGTipoReporteProyecto.TodosPresupuestos)
        {
            var presupuestos = trabajo.Presupuestos.OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.OrdinalIgnoreCase).ToArray();
            bool pieUnico = MYGPiePresupuesto.EsPieUnicoDelphin(presupuestos);
            return presupuestos.SelectMany((p, indice) => Presupuesto(trabajo, p, proyectoCompleto: true,
                incluirPie: !pieUnico || indice == presupuestos.Length - 1,
                presupuestosPie: pieUnico ? presupuestos : null)).ToArray();
        }
        var p = Elegir(trabajo, presupuestoId);
        var calculo = MYGMotorPresupuestos.CrearCalculo(p);
        return tipo switch
        {
            MYGTipoReporteProyecto.PresupuestoSeleccionado => Presupuesto(trabajo, p),
            MYGTipoReporteProyecto.HojaResumen => new[] { Resumen(trabajo, p) },
            MYGTipoReporteProyecto.AnalisisCostosUnitarios => Analisis(trabajo, p, Partidas(p), calculo),
            MYGTipoReporteProyecto.ConsolidadoCostosUnitarios => new[] { Consolidado(trabajo, p, calculo) },
            MYGTipoReporteProyecto.Metrados => ListadoMetrados(trabajo, p, calculo),
            MYGTipoReporteProyecto.MetradosAceros => Partidas(p).Where(i => i.Costos.FuenteMetrado == MYGFuenteMetrado.Excel &&
                MYGPlantillasMetrado.Identificar(i.Costos.Hoja) == MYGPlantillasMetrado.Aceros)
                .Select(i => Metrado(trabajo, p, i, calculo)).ToArray(),
            _ => throw new ArgumentOutOfRangeException(nameof(tipo))
        };
    }

    /// <summary>Exporta hojas activas y sus dependencias. null incluye todas las
    /// plantillas; vacío selecciona las hojas importadas o de otras plantillas.
    /// Las hojas estándar antiguas se reconocen con el clasificador integrado.</summary>
    public static IReadOnlyList<MYGHojaMetrado> CrearMetradosExcel(MYGProyectoDocumento documento,
        string presupuestoId, string plantilla = null)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var trabajo = Preparar(documento);
        var p = Elegir(trabajo, presupuestoId);
        return MYGExcelPresupuestos.CrearHojasMetradoParaExportar(p, trabajo.Presupuestos, plantilla);
    }

    /// <summary>Prepara únicamente la partida activa, con la misma cabecera,
    /// formato y aislamiento de los informes completos de metrados.</summary>
    public static MYGHojaReporteProyecto CrearMetrado(MYGProyectoDocumento documento,
        string presupuestoId, string partidaId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var trabajo = Preparar(documento);
        var presupuesto = Elegir(trabajo, presupuestoId);
        var partida = presupuesto.Items.FirstOrDefault(i => string.Equals(i.Id, partidaId, StringComparison.OrdinalIgnoreCase));
        if (partida == null || MYGProyectoStorage.EsTitulo(partida))
            throw new InvalidOperationException("Seleccione una partida del presupuesto para generar su informe de metrados.");
        return Metrado(trabajo, presupuesto, partida, MYGMotorPresupuestos.CrearCalculo(presupuesto));
    }

    private static MYGProyectoDocumento Preparar(MYGProyectoDocumento documento)
    {
        var copia = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(copia);
        return copia;
    }

    private static MYGPresupuestoDocumento Elegir(MYGProyectoDocumento documento, string presupuestoId)
    {
        string id = string.IsNullOrWhiteSpace(presupuestoId) ? documento.PresupuestoActivoId : presupuestoId;
        return documento.Presupuestos.FirstOrDefault(p => string.Equals(p.Id, id, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("Seleccione un presupuesto del proyecto para generar este reporte.");
    }

    private static IEnumerable<ItemPresupuestoDelphin> Partidas(MYGPresupuestoDocumento p) =>
        MYGOrdenPresupuestos.FilasOrdenadas(p).Where(i => !MYGProyectoStorage.EsTitulo(i));
    private static string Num(decimal n) => n.ToString(CultureInfo.InvariantCulture);
    private const string FormatoNumeroInforme = "0.00";
    // La estructura y las especificaciones muestran el presupuesto seguido del
    // código íntegro de la partida. Item ya contiene todos sus capítulos: no se
    // vuelve a reconstruir ni a prefijar la jerarquía a partir de ParentId.
    private static string Codigo(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i)
    {
        // numeracion_costo de Delphin ya incluye el presupuesto. Su impresión
        // utiliza al menos dos dígitos por nivel, sin añadir otra raíz MYG.
        if (EsPartidaImportadaDelphin(i))
            return string.Join(".", (i.Item ?? "").Split('.').Select(parte => parte.All(char.IsDigit) ? parte.PadLeft(2, '0') : parte));
        return string.IsNullOrWhiteSpace(p.Item) ? i.Item ?? ""
            : string.IsNullOrWhiteSpace(i.Item) ? p.Item : p.Item + "." + i.Item;
    }
    private static bool EsPartidaImportadaDelphin(ItemPresupuestoDelphin i) =>
        !string.IsNullOrWhiteSpace(i.IdInternoDelphin) && !string.IsNullOrWhiteSpace(i.Costos.FirmaDatosImportadosDelphin);
    private static string Titulo(string tipo, MYGPresupuestoDocumento p) => tipo + " · " + p;
    private static string PartidaTitulo(string tipo, MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
        Titulo(tipo, p) + " · " + Codigo(p, i) + " " + i.Descripcion + " (" + i.Unidad + ")";

    private static IReadOnlyList<KeyValuePair<string, string>> DatosProyecto(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        bool proyectoCompleto = false)
    {
        var d = doc.Datos;
        static string Texto(string valor) => string.IsNullOrWhiteSpace(valor) ? "No registrado" : valor.Trim();
        static string Fecha(DateTime? valor) => valor.HasValue ? valor.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) : "No registrado";
        return Array.AsReadOnly(new KeyValuePair<string, string>[]
        {
            new("Proyecto", Texto(doc.Nombre)), new("Presupuesto", proyectoCompleto ? "" : Texto(p.ToString())),
            new("Propietario", Texto(d?.Propietario)), new("Portafolio", Texto(d?.Portafolio)),
            new("Tipo de obra", Texto(d?.TipoObra)), new("Departamento", Texto(d?.Departamento)),
            new("Provincia", Texto(d?.Provincia)), new("Distrito", Texto(d?.Distrito)),
            new("Localidad", Texto(d?.Localidad)), new("Fecha de elaboración", Fecha(d?.FechaElaboracion)),
            new("Fecha de inicio", Fecha(d?.FechaInicio)), new("Fecha de término", Fecha(d?.FechaFin)),
            new("Duración", d == null ? "No registrado" : d.Duracion.ToString(FormatoNumeroInforme, CultureInfo.CurrentCulture) + " " + Texto(d.UnidadDuracion)),
            new("Calendario", Texto(d?.Calendario)), new("Periodos", Texto(d?.Periodos)),
            new("Modalidad", d?.ModalidadEjecucion switch { "A" => "Administración directa", "C" => "Contrata", _ => "No registrado" }),
            new("Análisis", d == null ? "No registrado" : d.PorRendimientoCuadrilla ? "Rendimiento de cuadrilla" : "Asignación de recursos"),
            new("Elaborado por", Texto(d?.HechoPor)), new("Moneda", Texto(p.Costos.Moneda))
        });
    }

    private static MYGHojaMetrado Tabla(MYGProyectoDocumento doc, MYGPresupuestoDocumento p, string titulo,
        string[] encabezados, int[] anchos)
    {
        var h = new MYGHojaMetrado
        {
            Nombre = titulo, Filas = 100, Columnas = encabezados.Length, CeldaTotal = "A1",
            LineasDivision = false, Encabezados = false, ImprimirLineasDivision = false,
            ImprimirEncabezados = false, RepetirTitulos = true, FormatoNumeroPredeterminado = FormatoNumeroInforme,
            OrientacionPagina = encabezados.Length > 6 ? "Horizontal" : "Vertical", TamanoPapel = "A4",
            MargenIzquierdo = 0.4m, MargenDerecho = 0.4m, MargenSuperior = 0.5m, MargenInferior = 0.5m,
            AltosFilas = new() { [1] = 30, [2] = 32 }
        };
        h.RangosCombinados.Add("A1:" + MYGHojaCalculo.Columna(h.Columnas) + "1");
        Poner(h, 1, 1, titulo.Split(" · ")[0].ToUpperInvariant(), true);
        h.Celdas["A1"].TamanoFuente = 12;
        h.Celdas["A1"].ColorTexto = "18354F";
        h.Celdas["A1"].AlineacionHorizontal = "Centro";
        for (int c = 1; c <= encabezados.Length; c++)
        {
            h.AnchosColumnas[c] = anchos[c - 1];
            Poner(h, 2, c, encabezados[c - 1], true);
            var celda = h.Celdas[MYGHojaCalculo.Columna(c) + "2"];
            celda.ColorFondo = "18354F"; celda.ColorTexto = "FFFFFF";
            celda.Bordes = true; celda.AjustarTexto = true;
            celda.AlineacionHorizontal = encabezados[c - 1] is "Ítem" or "Código" or "Descripción" or "Concepto"
                or "Recurso" or "Insumo" or "Partida" or "Descripción / referencia" or "Activo BIM" or "Documento" or "Tabla"
                ? "Izquierda" : "Centro";
        }
        return h;
    }

    private static void Poner(MYGHojaMetrado h, int fila, int columna, string valor, bool negrita = false,
        string formato = null, bool centrar = false)
    {
        if (fila > 10000) throw new InvalidDataException("El reporte supera 10.000 filas. Divida el contenido en presupuestos más pequeños.");
        string dir = MYGHojaCalculo.Columna(columna) + fila;
        // Los literales numéricos y los que empiezan por '=' se guardan como
        // fórmulas de texto, para que el mismo motor conserve el código visible
        // y no interprete una descripción como una operación de la hoja.
        bool numero = MYGHojaCalculo.IntentarNumero(valor, out _);
        string contenido = formato == null && (numero || (valor ?? "").StartsWith('='))
            ? "=\"" + (valor ?? "").Replace("\"", "\"\"") + "\"" : valor;
        h.Poner(dir, contenido, negrita);
        var c = h.Celdas[dir];
        c.AlineacionPersonalizada = true; c.AjustarTexto = true;
        c.Fuente = "Arial"; c.TamanoFuente = 10; c.ColorTexto = "243746";
        c.AlineacionHorizontal = formato != null && numero || centrar ? "Centro" : "Izquierda";
        c.FormatoNumero = formato ?? h.FormatoNumeroPredeterminado;
        h.Filas = Math.Max(h.Filas, fila);
    }

    private static void Numero(MYGHojaMetrado h, int f, int c, decimal valor, bool negrita = false) =>
        Poner(h, f, c, Num(valor), negrita, FormatoNumeroInforme);
    private static void Banda(MYGHojaMetrado h, int fila, string titulo)
    {
        Poner(h, fila, 1, titulo, true);
        h.RangosCombinados.Add("A" + fila + ":" + MYGHojaCalculo.Columna(h.Columnas) + fila);
        h.Celdas["A" + fila].ColorFondo = "E7EDF2";
        h.Celdas["A" + fila].ColorTexto = "18354F";
        h.AltosFilas[fila] = 24;
    }
    private static void Terminar(MYGHojaMetrado h, int ultimaFila, int columnaTotal, int filaTotal)
    {
        h.Filas = Math.Max(ultimaFila, 2);
        h.CeldaTotal = MYGHojaCalculo.Columna(columnaTotal) + filaTotal;
        h.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(h.Columnas) + ultimaFila;
        MYGHojaCalculo.Validar(h);
    }

    private static IReadOnlyList<MYGHojaReporteProyecto> Presupuesto(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        bool proyectoCompleto = false, bool incluirPie = true, IReadOnlyList<MYGPresupuestoDocumento> presupuestosPie = null)
    {
        var calculo = MYGMotorPresupuestos.CrearCalculo(p);
        var filas = MYGOrdenPresupuestos.FilasOrdenadas(p).ToArray();
        var niveles = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in filas)
            niveles[item.Id] = !string.IsNullOrEmpty(item.ParentId) && niveles.TryGetValue(item.ParentId, out int padre)
                ? padre + 1 : 1;
        // Un presupuesto grande se reparte en hojas compatibles con el modelo de
        // impresión; sólo la última incluye el pie completo del presupuesto.
        int filasPie = !incluirPie ? 0 : MYGPiePresupuesto.EsPieDelphin(p)
            ? p.Costos.PieDelphin.Filas.Count + 1 : p.Costos.PiePersonalizado == null ? 7 : p.Costos.PiePersonalizado.Count + 1;
        int maximo = 9995 - filasPie;
        if (maximo < 1)
            throw new InvalidDataException("El pie del presupuesto supera las filas disponibles en una hoja de impresión.");
        int cantidad = Math.Max(1, (filas.Length + maximo - 1) / maximo);
        var resultado = new List<MYGHojaReporteProyecto>();
        for (int parte = 0; parte < cantidad; parte++)
        {
            string titulo = Titulo("Presupuesto", p) + (cantidad == 1 ? "" : " · Parte " + (parte + 1));
            var h = Tabla(doc, p, titulo, ["Ítem", "Descripción", "Unid.", "Cant.", "Precio", "Total"], [90, 320, 45, 65, 75, 115]);
            var titulos = new Dictionary<int, int> { [3] = 0 };
            var minimos = new Dictionary<int, int> { [3] = 25 };
            h.Celdas["A1"].Contenido = "PRESUPUESTO DE OBRA";
            Poner(h, 3, 1, p.Item, true); Poner(h, 3, 2, p.Nombre, true);
            Numero(h, 3, 6, calculo.Resumen().CostoDirecto, true);
            foreach (string direccion in new[] { "A3", "B3", "F3" }) h.Celdas[direccion].Subrayado = true;
            h.AltosFilas[3] = 25;
            int f = 4;
            foreach (var i in filas.Skip(parte * maximo).Take(maximo))
            {
                bool esTitulo = MYGProyectoStorage.EsTitulo(i);
                Poner(h, f, 1, Codigo(p, i), esTitulo); Poner(h, f, 2, i.Descripcion, esTitulo);
                if (!esTitulo)
                {
                    Poner(h, f, 3, i.Unidad, centrar: true);
                    Numero(h, f, 4, calculo.Cantidad(i));
                    Numero(h, f, 5, calculo.Analizar(i).PrecioUnitario);
                }
                Numero(h, f, 6, calculo.TotalPartida(i), esTitulo);
                if (esTitulo) { h.AltosFilas[f] = 25; titulos[f] = niveles[i.Id]; }
                minimos[f] = esTitulo ? 25 : 24;
                f++;
            }
            int filaTotal;
            if (parte == cantidad - 1 && incluirPie)
            {
                var calculosPie = presupuestosPie?.Select(MYGMotorPresupuestos.CrearCalculo).ToArray() ?? [calculo];
                filaTotal = Pie(h, p, MYGPiePresupuesto.Resumen(calculosPie), f + 1, 2, 5, 6, presupuestosPie, calculosPie);
            }
            else if (parte == cantidad - 1) filaTotal = Math.Max(3, f - 1);
            else { Poner(h, f + 1, 2, "Continúa en la siguiente hoja", true); filaTotal = f + 1; }
            FormatoPresupuesto(h);
            Terminar(h, filaTotal, 6, filaTotal);
            resultado.Add(new(titulo, h, DatosProyecto(doc, p, proyectoCompleto), presupuestoObra: true, nivelesTitulos: titulos)
            { AltosMinimosFilas = minimos });
        }
        return resultado;
    }

    private static IReadOnlyList<MYGHojaReporteProyecto> ListadoMetrados(MYGProyectoDocumento doc,
        MYGPresupuestoDocumento p, MYGCalculoPresupuesto calculo)
    {
        var filas = MYGOrdenPresupuestos.FilasOrdenadas(p).ToArray();
        var niveles = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in filas)
            niveles[item.Id] = !string.IsNullOrEmpty(item.ParentId) && niveles.TryGetValue(item.ParentId, out int padre)
                ? padre + 1 : 1;
        // Las cuatro columnas se mantienen juntas. Se reservan tres filas de
        // tabla y ocho de cabecera institucional para poder exportar a Excel
        // sin superar las 10.000 filas del modelo.
        const int maximo = 9989;
        int cantidad = Math.Max(1, (filas.Length + maximo - 1) / maximo);
        var resultado = new List<MYGHojaReporteProyecto>();
        for (int parte = 0; parte < cantidad; parte++)
        {
            string titulo = Titulo("Metrados", p) + (cantidad == 1 ? "" : " · Parte " + (parte + 1));
            var h = Tabla(doc, p, titulo, ["Ítem", "Descripción", "Unid.", "Cant."], [90, 480, 50, 90]);
            var titulos = new Dictionary<int, int> { [3] = 0 };
            Poner(h, 3, 1, p.Item, true); Poner(h, 3, 2, p.Nombre, true);
            foreach (string direccion in new[] { "A3", "B3" }) h.Celdas[direccion].Subrayado = true;
            h.AltosFilas[3] = Math.Max(AltoTextoAnalisis(p.Item, 90, 25), AltoTextoAnalisis(p.Nombre, 480, 25));
            int f = 4, ultimaCantidad = 3;
            foreach (var i in filas.Skip(parte * maximo).Take(maximo))
            {
                bool esTitulo = MYGProyectoStorage.EsTitulo(i);
                string codigo = Codigo(p, i);
                Poner(h, f, 1, codigo, esTitulo); Poner(h, f, 2, i.Descripcion, esTitulo);
                if (esTitulo) titulos[f] = niveles[i.Id];
                else
                {
                    Poner(h, f, 3, i.Unidad, centrar: true);
                    // Incluir todos los orígenes y los ceros. No se consultan
                    // precios ni se suman cantidades de unidades distintas.
                    Numero(h, f, 4, calculo.Cantidad(i)); ultimaCantidad = f;
                }
                int minimo = esTitulo ? 25 : 20;
                h.AltosFilas[f] = Math.Max(AltoTextoAnalisis(codigo, 90, minimo),
                    Math.Max(AltoTextoAnalisis(i.Descripcion, 480, minimo), AltoTextoAnalisis(i.Unidad, 50, minimo)));
                f++;
            }
            FormatoPresupuesto(h);
            Terminar(h, f - 1, 4, ultimaCantidad);
            resultado.Add(new(titulo, h, DatosProyecto(doc, p), nivelesTitulos: titulos, listadoMetrados: true));
        }
        return resultado;
    }

    private static void FormatoPresupuesto(MYGHojaMetrado h)
    {
        h.FormatoNumeroPredeterminado = "#,##0.00";
        var calculo = new MYGHojaCalculo(h);
        foreach (var entrada in h.Celdas)
        {
            var c = entrada.Value;
            int fila = MYGHojaCalculo.Coordenadas(entrada.Key).Fila;
            c.ColorTexto = "000000";
            c.ColorFondo = fila == 2 ? "ECEEF1" : c.ColorFondo;
            if (!calculo.Resultado(entrada.Key).EsNumero) continue;
            c.AlineacionHorizontal = "Derecha";
            c.FormatoNumero = "#,##0.00" + (c.FormatoNumero.EndsWith("\" %\"", StringComparison.Ordinal) ? "\" %\"" : "");
        }
    }

    private static int Pie(MYGHojaMetrado h, MYGPresupuestoDocumento p, MYGResumenCostos r,
        int f, int conceptoColumna, int porcentajeColumna, int importeColumna,
        IReadOnlyList<MYGPresupuestoDocumento> presupuestos = null,
        IReadOnlyList<MYGCalculoPresupuesto> calculos = null)
    {
        if ((presupuestos ?? new[] { p }).Any(x => MYGPiePresupuesto.EsPieDelphin(x) || x.Costos.PiePersonalizado != null || x.Costos.ConfiguracionCostoDirecto != null))
        {
            // El informe usa los conceptos activos del mismo motor que el editor.
            // Las tasas conservadas para restaurar el pie no se imprimen ni se suman.
            var filas = MYGPiePresupuesto.Filas(calculos ?? (presupuestos ?? new[] { p })
                .Select(MYGMotorPresupuestos.CrearCalculo).ToArray());
            foreach (var fila in filas)
            {
                bool fuerte = fila.Id is MYGPiePresupuesto.IdCostoDirecto or "parcial" or MYGPiePresupuesto.IdTotal ||
                    (presupuestos ?? new[] { p }).Any(x => MYGPiePresupuesto.EsPieDelphin(x) &&
                        x.Costos.PieDelphin.Filas.Any(n => n.Tipo == "F" && "delphin:" + n.Clave == fila.Id));
                Poner(h, f, conceptoColumna, fila.Nombre, fuerte);
                if (fila.Porcentaje.HasValue)
                    Poner(h, f, porcentajeColumna, Num(fila.Porcentaje.Value), formato: FormatoNumeroInforme + "\" %\"");
                Numero(h, f, importeColumna, fila.Importe, fuerte);
                h.AltosFilas[f] = AltoTextoAnalisis(fila.Nombre, h.AnchosColumnas.GetValueOrDefault(conceptoColumna, 320), 24);
                if (fuerte) SombrearTotal(h, f);
                f++;
            }
            return f - 1;
        }
        decimal? Porcentaje(MYGConceptoPie concepto)
        {
            if (presupuestos == null) return MYGPiePresupuesto.Porcentaje(p, concepto);
            var valores = presupuestos.Select(x => MYGPiePresupuesto.Porcentaje(x, concepto)).Distinct().ToArray();
            // Los importes agregados conservan las tasas y el redondeo de cada
            // presupuesto. Una tasa distinta no se presenta como tasa común.
            return valores.Length == 1 ? valores[0] : null;
        }
        (string Texto, decimal? Porcentaje, decimal Importe)[] conceptos =
        [
            ("Costo directo", null, r.CostoDirecto),
            ("Gastos generales", Porcentaje(MYGConceptoPie.GastosGenerales), r.GastosGenerales),
            ("Utilidad", Porcentaje(MYGConceptoPie.Utilidad), r.Utilidad),
            ("Parcial", null, r.Subtotal),
            ("I.G.V.", Porcentaje(MYGConceptoPie.IGV), r.Impuesto),
            ("Otros impuestos", Porcentaje(MYGConceptoPie.OtrosImpuestos), r.OtrosImpuestos),
            ("Total", null, r.Total)
        ];
        foreach (var concepto in conceptos)
        {
            bool fuerte = concepto.Texto is "Costo directo" or "Parcial" or "Total";
            Poner(h, f, conceptoColumna, concepto.Texto, fuerte);
            if (concepto.Porcentaje.HasValue)
                Poner(h, f, porcentajeColumna, Num(concepto.Porcentaje.Value), formato: FormatoNumeroInforme + "\" %\"");
            Numero(h, f, importeColumna, concepto.Importe, fuerte);
            if (fuerte) SombrearTotal(h, f);
            f++;
        }
        return f - 1;
    }

    private static void SombrearTotal(MYGHojaMetrado h, int fila)
    {
        for (int columna = 1; columna <= h.Columnas; columna++)
        {
            string direccion = MYGHojaCalculo.Columna(columna) + fila;
            if (!h.Celdas.ContainsKey(direccion)) Poner(h, fila, columna, "");
            h.Celdas[direccion].ColorFondo = "ECEEF0";
            h.Celdas[direccion].ColorTexto = "000000";
        }
    }

    /// <summary>El libro de un presupuesto conserva su resumen individual y
    /// sus dependencias de metrados, aunque el proyecto tenga otras monedas.</summary>
    public static MYGHojaReporteProyecto CrearResumenPresupuesto(MYGProyectoDocumento documento, string presupuestoId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var trabajo = Preparar(documento);
        return Resumen(trabajo, Elegir(trabajo, presupuestoId), soloSeleccionado: true);
    }

    private static MYGHojaReporteProyecto Resumen(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        bool soloSeleccionado = false)
    {
        var presupuestos = (soloSeleccionado ? new[] { p } : doc.Presupuestos.AsEnumerable()).OrderBy(x => x.Posicion)
            .ThenBy(x => x.Item, StringComparer.OrdinalIgnoreCase).ToArray();
        if (presupuestos.Select(x => x.Costos.Moneda.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).Skip(1).Any())
            throw new InvalidOperationException("La hoja de resumen requiere que todos los presupuestos tengan la misma moneda; no se suman monedas distintas.");
        var calculos = presupuestos.Select(MYGMotorPresupuestos.CrearCalculo).ToArray();
        var resumen = MYGPiePresupuesto.Resumen(calculos);
        string titulo = soloSeleccionado ? Titulo("Hoja de resumen", p) : "Hoja de resumen";
        var h = Tabla(doc, p, titulo, ["Ítem", "Descripción", "", "", "", "Parcial"], [90, 320, 45, 65, 75, 115]);
        h.RangosCombinados.Add("B2:E2");
        int f = 3;
        foreach (var calculo in calculos)
        {
            var presupuesto = calculo.Presupuesto;
            Poner(h, f, 1, presupuesto.Item, true);
            Poner(h, f, 2, presupuesto.Nombre, true);
            Numero(h, f, 6, calculo.Resumen().CostoDirecto, true);
            h.RangosCombinados.Add("B" + f + ":E" + f);
            h.AltosFilas[f] = AltoTextoAnalisis(presupuesto.Nombre, 505, 25);
            foreach (string columna in new[] { "A", "B", "F" })
            {
                h.Celdas[columna + f].Subrayado = true;
                h.Celdas[columna + f].Bordes = true;
            }
            f++;
        }
        int primeraFilaPie = f + 1;
        int ultima = Pie(h, p, resumen, primeraFilaPie, 2, 5, 6, presupuestos, calculos);
        for (int fila = primeraFilaPie; fila <= ultima; fila++)
        {
            string finConcepto = h.Celdas["B" + fila].Negrita ? "E" : "D";
            h.RangosCombinados.Add("B" + fila + ":" + finConcepto + fila);
            foreach (var celda in h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == fila))
                celda.Value.Bordes = true;
        }
        FormatoPresupuesto(h);
        Terminar(h, ultima, 6, ultima);
        return new(titulo, h, DatosProyecto(doc, p, proyectoCompleto: !soloSeleccionado), resumenProyecto: true);
    }

    /// <summary>La partida activa utiliza el mismo formato y los datos generales
    /// que el informe de análisis completo, sin modificar el proyecto abierto.</summary>
    public static MYGHojaReporteProyecto CrearAnalisis(MYGProyectoDocumento documento,
        string presupuestoId, string partidaId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var trabajo = Preparar(documento);
        var p = Elegir(trabajo, presupuestoId);
        var i = p.Items.FirstOrDefault(i => string.Equals(i.Id, partidaId, StringComparison.OrdinalIgnoreCase));
        if (i == null || MYGProyectoStorage.EsTitulo(i))
            throw new InvalidOperationException("Seleccione una partida del presupuesto para generar su análisis de costos unitarios.");
        return Analisis(trabajo, p, new[] { i }, MYGMotorPresupuestos.CrearCalculo(p)).Single();
    }

    private static IReadOnlyList<MYGHojaReporteProyecto> Analisis(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        IEnumerable<ItemPresupuestoDelphin> partidas, MYGCalculoPresupuesto calculo)
    {
        var informes = new List<MYGHojaReporteProyecto>();
        MYGHojaMetrado h = null;
        Dictionary<int, int> minimos = null;
        int f = 2, filaTotal = 1;
        string titulo = Titulo("Análisis de Costos Unitarios", p);
        void TerminarAnalisis()
        {
            if (h == null) return;
            Terminar(h, f - 1, 7, filaTotal);
            informes.Add(new(titulo, h, DatosProyecto(doc, p), analisisCostosUnitarios: true)
            { AltosMinimosFilas = minimos });
        }
        foreach (var i in partidas)
        {
            var a = calculo.Analizar(i);
            int filasNecesarias = 5 + a.Recursos.Count + a.Recursos.Count(r => r.Recurso.DesperdicioPorcentaje != 0) +
                a.Recursos.Select(r => r.Recurso.Grupo).Distinct().Count() +
                (a.Recursos.Count == 0 || a.PrecioUnitario != a.Recursos.Sum(r => r.Total) ? 1 : 0);
            if (filasNecesarias > 9990)
                throw new InvalidDataException("El análisis de la partida " + Codigo(p, i) + " supera 10.000 filas.");
            if (h != null && f + filasNecesarias > 9990)
            { TerminarAnalisis(); h = null; }
            if (h == null)
            {
                h = Tabla(doc, p, titulo,
                    ["Índice unificado", "Descripción", "Unid.", "Recursos", "Cant.", "Precio", "Parcial"],
                    [95, 310, 50, 65, 80, 85, 85]);
                minimos = new();
                // Cada partida aporta su propia cabecera de columnas; no se
                // repite la banda de la primera partida al paginar el conjunto.
                foreach (string direccion in h.Celdas.Keys.Where(k => MYGHojaCalculo.Coordenadas(k).Fila == 2).ToArray())
                    h.Celdas.Remove(direccion);
                h.Celdas["A1"].Contenido = "Análisis de Costos Unitarios";
                h.Celdas["A1"].ColorTexto = "000000";
                h.OrientacionPagina = "Vertical"; h.RepetirTitulos = false;
                f = 2;
            }
            int cabeceraPartida = f;
            h.AltosFilas[f] = 22;
            Poner(h, f, 1, "Partida: " + Codigo(p, i));
            h.RangosCombinados.Add("A" + f + ":E" + f);
            Poner(h, f, 6, "Rendimiento:");
            Poner(h, f, 7, Num(i.Costos.RendimientoDiario), formato: "0.00\" " + i.Unidad.Replace("\"", "") + "/día\"");
            f++;
            h.AltosFilas[f] = Math.Max(AltoTextoAnalisis(i.Descripcion, 600, 28),
                AltoTextoAnalisis("Costo unit. por " + i.Unidad, 85, 28));
            minimos[f] = 28;
            Poner(h, f, 1, i.Descripcion);
            h.RangosCombinados.Add("A" + f + ":E" + f);
            Poner(h, f, 6, "Costo unit. por " + i.Unidad);
            Numero(h, f, 7, a.PrecioUnitario, true);
            h.Celdas["F" + f].ColorFondo = h.Celdas["G" + f].ColorFondo = "ECEEF1";
            h.Celdas["F" + f].Bordes = h.Celdas["G" + f].Bordes = true;
            filaTotal = f++;
            Poner(h, f, 1, "Jornada: " + Num(i.Costos.JornadaHoras) + " h · Moneda: " + p.Costos.Moneda);
            h.RangosCombinados.Add("A" + f + ":G" + f); h.AltosFilas[f++] = 16;
            bool partidaDelphin = EsPartidaImportadaDelphin(i);
            string[] columnas = [partidaDelphin ? "Código / Índice unificado" : "Índice unificado", "Descripción", "Unid.", "Recursos", "Cant.", "Precio", "Parcial"];
            for (int c = 1; c <= columnas.Length; c++)
            {
                Poner(h, f, c, columnas[c - 1], true);
                var celda = h.Celdas[MYGHojaCalculo.Columna(c) + f];
                celda.ColorFondo = "ECEEF1"; celda.Bordes = true;
                celda.AlineacionHorizontal = c <= 2 ? "Izquierda" : "Centro";
            }
            h.AltosFilas[f++] = partidaDelphin ? 34 : 22;
            if (a.Recursos.Count == 0)
            {
                Poner(h, f, 2, "Precio directo: partida sin desglose de recursos.");
                Numero(h, f++, 7, a.PrecioUnitario);
            }
            else
            {
                foreach (var grupo in MYGOrdenPresupuestos.GruposACU(i))
                {
                    var recursos = a.Recursos.Where(r => r.Recurso.Grupo == grupo).ToArray();
                    if (recursos.Length == 0) continue;
                    Poner(h, f, 2, MYGMotorPresupuestos.Grupo(grupo), true);
                    Numero(h, f++, 7, recursos.Sum(r => r.Total), true);
                    foreach (var r in recursos)
                    {
                        var insumo = p.Costos.Insumos.FirstOrDefault(x => x.Id == r.Recurso.InsumoId);
                        string indiceUnificado = MYGCatalogoIndicesUnificados.CodigoDeClasificacion(insumo?.GrupoGenerico);
                        string codigo = partidaDelphin ? insumo?.Codigo ?? r.Codigo ?? "" : "";
                        string identificacion = !partidaDelphin ? indiceUnificado : codigo +
                            (string.IsNullOrEmpty(indiceUnificado) ? "" : "\nIU: " + indiceUnificado);
                        Poner(h, f, 1, identificacion);
                        Poner(h, f, 2, r.Descripcion); Poner(h, f, 3, r.Unidad, centrar: true);
                        h.AltosFilas[f] = Math.Max(AltoTextoAnalisis(r.Descripcion, 310, 20), AltoTextoAnalisis(identificacion, 95, 20));
                        minimos[f] = 20;
                        if (r.Recurso.Modo == MYGModoCantidad.Rendimiento ||
                            calculo.ConservaRecursosDelphin(i) && r.Recurso.NumeroRecursos > 0 && r.Recurso.Grupo is MYGGrupoRecurso.ManoObra or MYGGrupoRecurso.Equipo)
                            Numero(h, f, 4, r.Recurso.NumeroRecursos);
                        else Poner(h, f, 4, "-", centrar: true);
                        Poner(h, f, 5, Num(r.Cantidad), formato: "0." + new string('0', Math.Max(4, p.Costos.DecimalesCantidad)));
                        Numero(h, f, 6, r.Precio); Numero(h, f++, 7, r.Total);
                        if (r.Recurso.DesperdicioPorcentaje != 0)
                        {
                            // Cant. contiene el coeficiente efectivo del motor,
                            // incluido el desperdicio; se conserva su porcentaje
                            // en una línea asociada sin alterar las siete columnas.
                            Poner(h, f, 2, "Desperdicio: " + Num(r.Recurso.DesperdicioPorcentaje) + " %");
                            h.RangosCombinados.Add("B" + f + ":G" + f); h.AltosFilas[f++] = 16;
                        }
                    }
                }
                decimal diferencia = a.PrecioUnitario - a.Recursos.Sum(r => r.Total);
                if (diferencia != 0 && !calculo.ConservaRecursosDelphin(i))
                {
                    Poner(h, f, 2, "Ajuste del precio unitario importado de Delphin");
                    Numero(h, f++, 7, diferencia);
                }
            }
            h.AltosFilas[f++] = 10;
            foreach (var entrada in h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila >= cabeceraPartida))
            {
                entrada.Value.ColorTexto = "000000";
                entrada.Value.TamanoFuente = 9;
                if (MYGHojaCalculo.IntentarNumero(entrada.Value.Contenido, out _))
                    entrada.Value.AlineacionHorizontal = "Derecha";
            }
        }
        TerminarAnalisis();
        return informes;
    }

    private static int AltoTextoAnalisis(string texto, int ancho, int minimo)
    {
        // También fija una altura legible en Excel, donde las combinaciones
        // no se autoajustan. El impresor vuelve a medir con la fuente real.
        int caracteres = Math.Max(1, (ancho - 10) / 6);
        int lineas = (texto ?? "").Replace("\r\n", "\n").Replace('\r', '\n').Split('\n')
            .Sum(l => Math.Max(1, (l.Length + caracteres - 1) / caracteres));
        return Math.Clamp(16 * lineas + 4, minimo, 1000);
    }

    private static MYGHojaReporteProyecto Consolidado(MYGProyectoDocumento doc, MYGPresupuestoDocumento p, MYGCalculoPresupuesto calculo)
    {
        string titulo = Titulo("Consolidado de costos unitarios", p);
        var h = Tabla(doc, p, titulo, ["Código", "Insumo", "Unidad", "Cantidad", "Precio", "Total"], [90, 320, 45, 65, 75, 115]);
        var recursos = calculo.Consolidar(); int f = 3;
        foreach (var grupo in Enum.GetValues<MYGGrupoRecurso>())
        {
            var lineas = recursos.Where(r => r.Grupo == grupo).ToArray();
            if (lineas.Length == 0) continue;
            Banda(h, f, MYGMotorPresupuestos.Grupo(grupo));
            h.Celdas["A" + f++].ColorFondo = "ECEEF1";
            foreach (var r in lineas)
            {
                Poner(h, f, 1, r.Codigo); Poner(h, f, 2, r.Descripcion); Poner(h, f, 3, r.Unidad, centrar: true);
                Numero(h, f, 4, r.Cantidad);
                Numero(h, f, 5, r.Precio);
                Numero(h, f, 6, r.Total); f++;
            }
        }
        decimal suma = recursos.Sum(r => r.Total), directo = calculo.Resumen().CostoDirecto;
        Poner(h, f, 2, "Total de insumos consolidados", true); Numero(h, f, 6, suma, true);
        SombrearTotal(h, f++);
        if (directo != suma)
        {
            Poner(h, f, 2, "Diferencia por parciales nativos / redondeo"); Numero(h, f++, 6, directo - suma);
        }
        Poner(h, f, 2, "Costo directo del presupuesto", true); Numero(h, f, 6, directo, true);
        SombrearTotal(h, f);
        FormatoPresupuesto(h);
        Terminar(h, f, 6, f);
        return new(titulo, h, DatosProyecto(doc, p), consolidadoCostosUnitarios: true);
    }

    private static MYGHojaReporteProyecto Metrado(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        ItemPresupuestoDelphin i, MYGCalculoPresupuesto calculo)
    {
        string titulo = PartidaTitulo("Metrados", p, i);
        if (i.Costos.FuenteMetrado == MYGFuenteMetrado.Excel)
        {
            var copia = MYGProyectoStorage.Copia(i.Costos.Hoja);
            PrepararImpresionMetrado(copia);
            return new(titulo, copia, DatosProyecto(doc, p));
        }
        MYGHojaMetrado h;
        int f = 3;
        if (i.Costos.FuenteMetrado == MYGFuenteMetrado.Manual)
        {
            h = Tabla(doc, p, titulo, ["Descripción / referencia", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Descuento", "Parcial"],
                [320, 80, 90, 80, 80, 80, 80, 100]);
            foreach (var m in i.Costos.Metrados)
            {
                Poner(h, f, 1, m.Descripcion + (string.IsNullOrWhiteSpace(m.Referencia) ? "" : " · " + m.Referencia));
                Numero(h, f, 2, m.Elementos);
                Numero(h, f, 3, m.CantidadPorElemento);
                if (m.Largo.HasValue) Numero(h, f, 4, m.Largo.Value);
                if (m.Ancho.HasValue) Numero(h, f, 5, m.Ancho.Value);
                if (m.Alto.HasValue) Numero(h, f, 6, m.Alto.Value);
                Poner(h, f, 7, m.Descuento ? "Sí" : "No", centrar: true);
                Numero(h, f++, 8, MYGMotorPresupuestos.Parcial(m));
            }
        }
        else if (i.Costos.FuenteMetrado == MYGFuenteMetrado.BIM)
        {
            h = Tabla(doc, p, titulo, ["Activo BIM", "Documento", "Tabla", "Unidad", "Fecha UTC", "Cantidad"], [200, 180, 180, 70, 150, 110]);
            h.OrientacionPagina = "Horizontal";
            foreach (var m in i.Costos.MetradosBIM)
            {
                Poner(h, f, 1, m.ActivoId); Poner(h, f, 2, m.DocumentoId); Poner(h, f, 3, m.Tabla); Poner(h, f, 4, m.Unidad, centrar: true);
                Poner(h, f, 5, m.FechaUtc == default ? "" : m.FechaUtc.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture), centrar: true);
                Numero(h, f++, 6, m.Cantidad);
            }
        }
        else
        {
            h = Tabla(doc, p, titulo, ["Ítem", "Partida", "Unidad", "Fuente", "Cantidad"], [100, 360, 75, 100, 120]);
            Poner(h, f, 1, Codigo(p, i)); Poner(h, f, 2, i.Descripcion); Poner(h, f, 3, i.Unidad, centrar: true); Poner(h, f, 4, "Cantidad", centrar: true);
            Numero(h, f++, 5, i.Costos.Cantidad);
        }
        Poner(h, f, 1, "Metrado total (" + i.Unidad + ")", true);
        Numero(h, f, h.Columnas, calculo.Cantidad(i), true);
        Terminar(h, f, h.Columnas, f);
        return new(titulo, h, DatosProyecto(doc, p));
    }

    private static void PrepararImpresionMetrado(MYGHojaMetrado h)
    {
        if (string.IsNullOrWhiteSpace(h.AreaImpresion))
        {
            var posiciones = h.Celdas.Keys.Select(MYGHojaCalculo.Coordenadas)
                .Concat(h.RangosCombinados.SelectMany(r => r.Split(':')).Select(MYGHojaCalculo.Coordenadas))
                .Append(MYGHojaCalculo.Coordenadas(h.CeldaTotal)).ToArray();
            int fila = Math.Max(2, posiciones.Max(c => c.Fila)), columna = posiciones.Max(c => c.Columna);
            h.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(columna) + fila;
        }
        var fin = MYGHojaCalculo.Coordenadas(h.AreaImpresion.Split(':')[^1]);
        for (int c = 1; c <= fin.Columna; c++)
            h.AnchosColumnas.TryAdd(c, c == 1 ? 280 : 85);
        // Las hojas existentes conservan papel, orientación, márgenes y títulos
        // que el usuario eligió. El formato de cifras se aplica a la copia de
        // impresión; el contenido, las fórmulas y la exportación Excel directa
        // conservan sus valores y su precisión original.
        h.FormatoNumeroPredeterminado = FormatoNumeroInforme;
        var calculo = new MYGHojaCalculo(h);
        foreach (var entrada in h.Celdas)
        {
            bool numero;
            try { numero = calculo.Resultado(entrada.Key).EsNumero; }
            catch (Exception ex) when (ex is FormatException or InvalidDataException or DivideByZeroException or OverflowException)
            { continue; }
            if (!numero) continue;
            var celda = entrada.Value;
            celda.FormatoNumero = FormatoNumeroInforme;
            celda.AlineacionHorizontal = "Centro";
            celda.AlineacionPersonalizada = true;
        }
        MYGHojaCalculo.Validar(h);
    }
}

public static partial class MYGExcelPresupuestos
{
    /// <summary>Selección por identidad de plantilla con cierre transitivo de
    /// dependencias. Las hojas de soporte no se descartan aunque su plantilla,
    /// presupuesto o fuente de metrado no coincidan con el filtro.</summary>
    public static IReadOnlyList<MYGHojaMetrado> CrearHojasMetradoParaExportar(
        MYGPresupuestoDocumento presupuesto, IEnumerable<MYGPresupuestoDocumento> presupuestos, string plantilla)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        var disponibles = (presupuestos ?? presupuesto.ContextoReferencias?.Presupuestos ?? new[] { presupuesto }).ToArray();
        var seleccion = new MYGPresupuestoDocumento
        {
            Id = presupuesto.Id, Item = presupuesto.Item, Nombre = presupuesto.Nombre,
            Items = MYGOrdenPresupuestos.FilasOrdenadas(presupuesto).Where(i => !MYGProyectoStorage.EsTitulo(i) &&
                i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel &&
                (plantilla == null || string.Equals(MYGPlantillasMetrado.Identificar(i.Costos.Hoja), plantilla, StringComparison.OrdinalIgnoreCase))).ToList()
        };
        var hojas = CrearHojasMetradoParaExportar(new[] { seleccion }, disponibles);
        var primarias = seleccion.Items.Select(i => MYGExportacionReferenciasExcel.Clave(presupuesto.Id, i.IdLocalMYG ?? i.Id)).ToHashSet();
        foreach (var h in hojas)
            if (!primarias.Contains(MYGExportacionReferenciasExcel.Clave(h.PresupuestoReferenciasId, h.PartidaReferenciasId)))
                h.Nombre = "Soporte " + h.Nombre;
        return hojas;
    }
}
