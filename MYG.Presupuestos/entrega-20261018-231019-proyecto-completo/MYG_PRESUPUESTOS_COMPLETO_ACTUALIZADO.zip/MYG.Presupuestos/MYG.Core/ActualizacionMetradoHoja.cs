using System;
using System.IO;
using System.Linq;

namespace MYG_2027;

public sealed record MYGEstadoMetradoHoja(decimal? TotalHoja, decimal? CantidadPresupuesto)
{
    public bool PuedeActualizar => TotalHoja > 0;
    public bool HayDiferencia => PuedeActualizar && CantidadPresupuesto != TotalHoja;
}

/// <summary>Consulta el metrado de la hoja y permite vincular su resultado al presupuesto.</summary>
public static class MYGActualizacionMetradoHoja
{
    // La consulta no valida normalizando el documento: se usa también durante
    // la edición y debe conservar las celdas, las fuentes y sus instancias.
    public static MYGEstadoMetradoHoja Evaluar(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida)
    {
        if (!EsPartidaActual(presupuesto, partida)) return new(null, null);
        decimal? total = TotalHoja(presupuesto, partida.Costos.Hoja);
        decimal? cantidad = CantidadPresupuesto(presupuesto, partida);
        return new(total, cantidad);
    }

    public static bool Actualizar(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida)
    {
        var estado = Evaluar(presupuesto, partida);
        if (!estado.PuedeActualizar)
            throw new InvalidDataException("Seleccione una partida del presupuesto con un total de metrado numérico mayor que cero y dentro del rango permitido.");
        if (partida.Costos.FuenteMetrado == MYGFuenteMetrado.Excel) return false;
        // La fuente Excel vuelve a calcular el resultado de CeldaTotal; las
        // operaciones estructurales de la hoja reubican esa referencia. Se
        // conserva también la cantidad inicial y los datos manuales y BIM.
        // Incluso una cantidad coincidente necesita activar el vínculo.
        partida.Costos.Cantidad = estado.TotalHoja.Value;
        partida.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        return true;
    }

    private static bool EsPartidaActual(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida) =>
        presupuesto?.Costos != null && presupuesto.Costos.DecimalesCantidad is >= 0 and <= 8 &&
        partida?.Costos != null && !MYGProyectoStorage.EsTitulo(partida) &&
        presupuesto.Items != null && presupuesto.Items.Any(actual => ReferenceEquals(actual, partida));

    private static decimal? TotalHoja(MYGPresupuestoDocumento presupuesto, MYGHojaMetrado hoja)
    {
        if (hoja?.Celdas == null || hoja.Filas < 1 || hoja.Columnas < 1 || hoja.Celdas.Values.Any(celda => celda == null)) return null;
        try
        {
            var valor = new MYGHojaCalculo(hoja).Resultado(hoja.CeldaTotal);
            // Numero() convierte los valores lógicos y ciertos textos: aquí
            // se exige un resultado numérico real, incluidos los de fórmulas.
            if (!valor.EsNumero) return null;
            decimal numero = valor.Numero();
            if (numero <= 0 || numero > MYGEdicionPartida.CantidadMaxima) return null;
            decimal total = MYGMotorPresupuestos.Coeficiente(presupuesto, numero);
            return total > 0 ? total : null;
        }
        catch (Exception ex) when (ErrorDeCalculo(ex)) { return null; }
    }

    private static decimal? CantidadPresupuesto(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida)
    {
        var datos = partida.Costos;
        if (!Enum.IsDefined(datos.FuenteMetrado) ||
            datos.FuenteMetrado == MYGFuenteMetrado.Manual && (datos.Metrados == null || datos.Metrados.Any(x => x == null)) ||
            datos.FuenteMetrado == MYGFuenteMetrado.BIM && (datos.MetradosBIM == null || datos.MetradosBIM.Any(x => x == null)) ||
            datos.FuenteMetrado == MYGFuenteMetrado.Excel && (datos.Hoja?.Celdas == null || datos.Hoja.Celdas.Values.Any(celda => celda == null))) return null;
        try
        {
            if (datos.FuenteMetrado == MYGFuenteMetrado.Excel)
            {
                var valor = new MYGHojaCalculo(datos.Hoja).Resultado(datos.Hoja.CeldaTotal);
                if (!valor.EsNumero && !valor.EsVacio) return null;
            }
            decimal cantidad = MYGMotorPresupuestos.Cantidad(presupuesto, partida);
            return cantidad is >= 0 and <= MYGEdicionPartida.CantidadMaxima ? cantidad : null;
        }
        catch (Exception ex) when (ErrorDeCalculo(ex)) { return null; }
    }

    private static bool ErrorDeCalculo(Exception ex) => ex is FormatException or InvalidDataException or
        DivideByZeroException or OverflowException or ArgumentException;
}
