using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGModoRutaCritica { Ninguna, Simple, Multiple }

/// <summary>Selecciona las tareas críticas sin alterar fechas, holguras ni el plan.
/// Simple usa el fin de la obra; Multiple usa el fin de cada red independiente
/// de dependencias. Compartir un resumen no une dos redes.</summary>
public static class MYGRutasCriticasCronograma
{
    public static IReadOnlySet<string> Calcular(MYGCronograma plan, MYGModoRutaCritica modo)
    {
        ArgumentNullException.ThrowIfNull(plan);
        ValidarModo(modo);
        if (modo == MYGModoRutaCritica.Ninguna) return new HashSet<string>(StringComparer.Ordinal);
        return Calcular(plan, MYGMotorCronograma.Calcular(plan), modo);
    }

    /// <summary>Reutiliza una instantánea calculada para este plan y calendario.
    /// Los resúmenes y las tareas manuales conservan la semántica del motor CPM:
    /// las manuales fijan restricciones, pero no se colorean como ruta crítica.</summary>
    public static IReadOnlySet<string> Calcular(MYGCronograma plan,
        MYGResultadoCronograma resultado, MYGModoRutaCritica modo)
    {
        ArgumentNullException.ThrowIfNull(plan);
        ArgumentNullException.ThrowIfNull(resultado);
        ValidarModo(modo);
        var criticas = new HashSet<string>(StringComparer.Ordinal);
        if (modo == MYGModoRutaCritica.Ninguna) return criticas;
        var hojas = resultado.Filas.Where(f => !f.Tarea.EsResumen)
            .ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        if (modo == MYGModoRutaCritica.Simple)
        {
            foreach (var fila in hojas.Values.Where(f => f.EsCritica)) criticas.Add(fila.Tarea.Id);
            return criticas;
        }
        if (hojas.Count == 0) return criticas;

        var calendario = new MYGCalendarioEntero(plan.Calendario);
        var vecinas = hojas.Keys.ToDictionary(id => id, _ => new List<string>(), StringComparer.Ordinal);
        var sucesoras = hojas.Keys.ToDictionary(id => id,
            _ => new List<(MYGResultadoTarea Fila, MYGDependenciaCronograma Vinculo)>(), StringComparer.Ordinal);
        var pendientes = hojas.Values.ToDictionary(f => f.Tarea.Id,
            f => f.Tarea.Predecesoras.Count, StringComparer.Ordinal);
        foreach (var fila in hojas.Values)
            foreach (var vinculo in fila.Tarea.Predecesoras)
            {
                if (!hojas.ContainsKey(vinculo.PredecesoraId))
                    throw new InvalidDataException("La instantánea contiene una predecesora ajena a sus tareas.");
                sucesoras[vinculo.PredecesoraId].Add((fila, vinculo));
                vecinas[fila.Tarea.Id].Add(vinculo.PredecesoraId);
                vecinas[vinculo.PredecesoraId].Add(fila.Tarea.Id);
            }

        // Cada hoja y vínculo se recorren un número constante de veces. No se
        // copia ni recalcula la planificación por cada componente o tarea sola.
        var componente = new Dictionary<string, string>(StringComparer.Ordinal);
        var horizontes = new Dictionary<string, long>(StringComparer.Ordinal);
        foreach (var fila in hojas.Values)
        {
            string raiz = fila.Tarea.Id;
            if (!componente.TryAdd(raiz, raiz)) continue;
            long horizonte = calendario.Primero(fila.Fin);
            var explorar = new Stack<string>(); explorar.Push(raiz);
            while (explorar.TryPop(out string id))
            {
                horizonte = Math.Max(horizonte, calendario.Primero(hojas[id].Fin));
                foreach (string vecina in vecinas[id])
                    if (componente.TryAdd(vecina, raiz)) explorar.Push(vecina);
            }
            horizontes.Add(raiz, horizonte);
        }

        var orden = new List<MYGResultadoTarea>(hojas.Count);
        var disponibles = new Queue<MYGResultadoTarea>(hojas.Values.Where(f => pendientes[f.Tarea.Id] == 0));
        while (disponibles.TryDequeue(out var fila))
        {
            orden.Add(fila);
            foreach (var sucesora in sucesoras[fila.Tarea.Id])
                if (--pendientes[sucesora.Fila.Tarea.Id] == 0) disponibles.Enqueue(sucesora.Fila);
        }
        if (orden.Count != hojas.Count)
            throw new InvalidDataException("La instantánea contiene un ciclo de dependencias.");

        long Extension(MYGResultadoTarea f) => f.Tarea.Modo == MYGModoTarea.Automatica && MYGMotorCronograma.ConservaFechasDelphin(f.Tarea)
            ? Math.Max(0, calendario.Primero(f.Fin) - calendario.Primero(f.Inicio)) : Extent(f.Tarea.DuracionDias);
        var tardio = hojas.Values.ToDictionary(f => f.Tarea.Id,
            f => f.Tarea.Modo == MYGModoTarea.Manual ? calendario.Primero(f.Inicio) :
                horizontes[componente[f.Tarea.Id]] - Extension(f), StringComparer.Ordinal);
        for (int n = orden.Count - 1; n >= 0; n--)
        {
            var fila = orden[n]; var tarea = fila.Tarea;
            if (tarea.Modo == MYGModoTarea.Manual) continue;
            foreach (var sucesora in sucesoras[tarea.Id])
            {
                var siguiente = sucesora.Fila; var vinculo = sucesora.Vinculo;
                long peso = vinculo.Tipo switch
                {
                    MYGTipoVinculo.FC => Extension(fila) + 1L + vinculo.DesfaseDias,
                    MYGTipoVinculo.CC => vinculo.DesfaseDias,
                    MYGTipoVinculo.FF => Extension(fila) - Extension(siguiente) + vinculo.DesfaseDias,
                    _ => -Extension(siguiente) + vinculo.DesfaseDias
                };
                long limite = tardio[siguiente.Tarea.Id];
                if (siguiente.Tarea.Modo == MYGModoTarea.Manual)
                    limite = vinculo.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC
                        ? calendario.AnteriorOIgual(siguiente.Inicio)
                        : calendario.AnteriorOIgual(siguiente.Fin) - Extent(siguiente.Tarea.DuracionDias);
                tardio[tarea.Id] = Math.Min(tardio[tarea.Id], limite - peso);
            }
            if (tardio[tarea.Id] <= calendario.Primero(fila.Inicio)) criticas.Add(tarea.Id);
        }
        return criticas;
    }

    private static int Extent(int duracion) => Math.Max(0, duracion - 1);
    private static void ValidarModo(MYGModoRutaCritica modo)
    {
        if (!Enum.IsDefined(modo)) throw new ArgumentOutOfRangeException(nameof(modo));
    }
}
