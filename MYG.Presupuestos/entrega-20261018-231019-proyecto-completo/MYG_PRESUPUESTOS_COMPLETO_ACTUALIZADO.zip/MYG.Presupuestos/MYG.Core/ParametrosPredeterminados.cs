using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MYG_2027;

public sealed class MYGNivelPolitico
{
    public string Nombre { get; set; } = "";
    public string Abreviatura { get; set; } = "";
}

public sealed class MYGParametroAcero
{
    public string Diametro { get; set; } = "";
    public decimal PesoPorMetro { get; set; }
    public decimal Empalme { get; set; }
    public decimal Gancho { get; set; }
    public decimal DesperdicioPorcentaje { get; set; }
}

/// <summary>Preferencias del usuario. Sólo se aplican explícitamente a datos nuevos;
/// leer documentos anteriores nunca consulta esta configuración.</summary>
public sealed class MYGParametrosPredeterminados
{
    [JsonPropertyName("schemaVersion")]
    public int VersionEsquema { get; set; } = 1;
    public decimal GastosGeneralesPorcentaje { get; set; } = 12;
    public decimal OtrosGastosPorcentaje { get; set; }
    public decimal UtilidadPorcentaje { get; set; } = 10;
    public decimal ImpuestoRentaPorcentaje { get; set; }
    public decimal ImpuestoPorcentaje { get; set; } = 18;
    public decimal OtrosImpuestosPorcentaje { get; set; }
    public string NombreGastosGenerales { get; set; } = "Gastos generales";
    public string AbreviaturaGastosGenerales { get; set; } = "GG";
    public string NombreOtrosGastos { get; set; } = "Otros gastos";
    public string AbreviaturaOtrosGastos { get; set; } = "OG";
    public string NombreImpuestoRenta { get; set; } = "Impuesto a la renta";
    public string NombreImpuesto { get; set; } = "I.G.V.";
    public string NombreOtrosImpuestos { get; set; } = "Otros impuestos";
    public string IndiceGastosGenerales { get; set; } = "";
    public string Moneda { get; set; } = "S/";
    public string NombreMoneda { get; set; } = "Sol";
    public int DecimalesPrecio { get; set; } = 2;
    public int DecimalesCantidad { get; set; } = 4;
    public string UnidadPartida { get; set; } = "und";
    public string UnidadInsumo { get; set; } = "und";
    public string Proveedor { get; set; } = "SIN CLASIFICAR";
    public string PeriodoRendimiento { get; set; } = "Día";
    public decimal Rendimiento { get; set; } = 1;
    public decimal JornadaHoras { get; set; } = 8;
    public List<MYGNivelPolitico> DivisionPolitica { get; set; } = new()
    {
        new() { Nombre = "Departamento", Abreviatura = "DPTO" },
        new() { Nombre = "Provincia", Abreviatura = "PROV" },
        new() { Nombre = "Distrito", Abreviatura = "DIST" },
        new() { Nombre = "Localidad", Abreviatura = "LOC" }
    };
    public List<MYGParametroAcero> Aceros { get; set; } = AcerosIniciales();
    public string UnidadAcero { get; set; } = "kg";
    public List<string> ColoresNiveles { get; set; } = new()
    { "BD353E", "2567B1", "137440", "8742AC", "965800", "006D7A", "A63C66", "56677B", "263446", "263446" };
    public string NombreComercial { get; set; } = "";
    public string LogoBase64 { get; set; } = "";

    private static List<MYGParametroAcero> AcerosIniciales()
    {
        string[] diametros = ["4mm", "4.5mm", "5mm", "5.5mm", "6mm", "1/4″", "6.5mm", "7mm", "7.5mm", "8mm", "8.5mm",
            "3/8″", "12mm", "1/2″", "5/8″", "3/4″", "7/8″", "1″", "1 1/8″", "1 1/4″", "1 3/8″"];
        decimal[] pesos = [0.099m, 0.125m, 0.154m, 0.187m, 0.220m, 0.250m, 0.260m, 0.302m, 0.347m, 0.400m, 0.445m,
            0.580m, 0.890m, 1.020m, 1.600m, 2.260m, 3.040m, 4.000m, 5.060m, 6.400m, 7.910m];
        var aceros = diametros.Select((d, i) => new MYGParametroAcero { Diametro = d, PesoPorMetro = pesos[i] }).ToList();
        var detalles = new (string Diametro, decimal Empalme, decimal Gancho, decimal Desperdicio)[]
        {
            ("6mm", .3m, .15m, 3), ("1/4″", .3m, .15m, 3), ("8mm", .4m, .2m, 3), ("12mm", .5m, .25m, 5),
            ("3/8″", .45m, .2m, 3), ("1/2″", .5m, .25m, 5), ("5/8″", .6m, .35m, 7),
            ("3/4″", .75m, .4m, 8), ("1″", 1.3m, .45m, 10), ("1 3/8″", 1.7m, .6m, 12)
        };
        foreach (var detalle in detalles)
        {
            var acero = aceros.Single(a => a.Diametro == detalle.Diametro);
            acero.Empalme = detalle.Empalme; acero.Gancho = detalle.Gancho;
            acero.DesperdicioPorcentaje = detalle.Desperdicio;
        }
        return aceros;
    }

    public MYGParametrosPredeterminados Copia() =>
        JsonSerializer.Deserialize<MYGParametrosPredeterminados>(JsonSerializer.Serialize(this, MYGParametrosUsuario.Opciones), MYGParametrosUsuario.Opciones);

    public void Validar()
    {
        if (VersionEsquema != 1) throw new InvalidDataException("La versión del archivo de parámetros no es compatible.");
        static void Texto(string valor, string campo, int maximo = 120, bool opcional = false)
        {
            if (valor == null || (!opcional && string.IsNullOrWhiteSpace(valor)) || valor.Length > maximo || valor.Any(char.IsControl))
                throw new InvalidDataException("Indique " + campo + " válido de hasta " + maximo + " caracteres.");
        }
        foreach (var par in new[] { (NombreGastosGenerales, "el nombre de gastos generales"), (NombreOtrosGastos, "el nombre de otros gastos"),
            (NombreImpuestoRenta, "el nombre del impuesto a la renta"), (NombreImpuesto, "el nombre del impuesto"),
            (NombreOtrosImpuestos, "el nombre de otros impuestos"), (NombreMoneda, "el nombre de la moneda"), (Proveedor, "el proveedor") })
            Texto(par.Item1, par.Item2);
        Texto(Moneda, "el símbolo de moneda", 15); Texto(UnidadPartida, "la unidad de partida", 30);
        Texto(UnidadInsumo, "la unidad de insumo", 30); Texto(NombreComercial, "el nombre comercial", 120, true);
        if (!string.IsNullOrWhiteSpace(IndiceGastosGenerales))
            throw new InvalidDataException("Los índices polinómicos de gastos generales requieren una configuración específica del proyecto.");
        if (DecimalesPrecio is < 0 or > 6 || DecimalesCantidad is < 0 or > 8)
            throw new InvalidDataException("Use entre 0 y 6 decimales de precio y entre 0 y 8 decimales de cantidad.");
        foreach (decimal porcentaje in new[] { GastosGeneralesPorcentaje, OtrosGastosPorcentaje, UtilidadPorcentaje,
            ImpuestoRentaPorcentaje, ImpuestoPorcentaje, OtrosImpuestosPorcentaje })
            if (porcentaje < 0 || porcentaje > 10000 || decimal.Round(porcentaje, 4) != porcentaje)
                throw new InvalidDataException("Los porcentajes deben estar entre 0 y 10000 y admitir como máximo cuatro decimales.");
        var identificadores = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "CD", "COSTODIRECTO", "ACUMULADO", "UT", "IR", "IGV", "OI" };
        foreach (string abreviatura in new[] { AbreviaturaGastosGenerales, AbreviaturaOtrosGastos })
            if (!MYGFormulaFilaResumen.EsIdentificador(abreviatura) || !identificadores.Add(abreviatura))
                throw new InvalidDataException("Use abreviaturas diferentes con letras, números o guion bajo, comenzando por letra. CD, COSTODIRECTO, ACUMULADO, UT, IR, IGV y OI están reservadas.");
        if (PeriodoRendimiento is not ("Día" or "Hora") || Rendimiento <= 0 || Rendimiento > 1000000000m || JornadaHoras <= 0 || JornadaHoras > 24)
            throw new InvalidDataException("Seleccione rendimiento por Día u Hora, rendimiento positivo y una jornada mayor que cero y de hasta 24 horas.");
        if (DivisionPolitica == null || DivisionPolitica.Count != 4)
            throw new InvalidDataException("La división política debe contener cuatro niveles.");
        foreach (var nivel in DivisionPolitica)
        {
            if (nivel == null) throw new InvalidDataException("La división política contiene un nivel vacío.");
            Texto(nivel.Nombre, "el nombre del nivel político", 60); Texto(nivel.Abreviatura, "la abreviatura del nivel político", 15);
        }
        static bool ColorValido(string color)
        {
            if (color == null) return false;
            string rgb = color.StartsWith('#') ? color[1..] : color;
            return rgb.Length == 6 && rgb.All(Uri.IsHexDigit);
        }
        if (ColoresNiveles == null || ColoresNiveles.Count != 10 || ColoresNiveles.Any(c => !ColorValido(c)))
            throw new InvalidDataException("Indique diez colores RGB de seis dígitos hexadecimales.");
        if (Aceros == null || Aceros.Count != 21)
            throw new InvalidDataException("La tabla de aceros debe contener 21 diámetros.");
        var canonicos = AcerosIniciales();
        for (int indice = 0; indice < Aceros.Count; indice++)
        {
            var acero = Aceros[indice];
            if (acero == null) throw new InvalidDataException("La tabla de aceros contiene una fila vacía.");
            Texto(acero.Diametro, "el diámetro", 30);
            if (!string.Equals(acero.Diametro, canonicos[indice].Diametro, StringComparison.OrdinalIgnoreCase) ||
                acero.PesoPorMetro <= 0 || acero.PesoPorMetro > 10000 ||
                acero.Empalme < 0 || acero.Empalme > 100 || acero.Gancho < 0 || acero.Gancho > 100 ||
                acero.DesperdicioPorcentaje < 0 || acero.DesperdicioPorcentaje > 100)
                throw new InvalidDataException("Los diámetros deben ser distintos, con peso positivo, gancho y empalme entre 0 y 100 m y desperdicio entre 0 y 100 %.");
        }
        if (UnidadAcero is not ("kg" or "t" or "tn"))
            throw new InvalidDataException("Seleccione kg, t o tn como unidad de acero.");
        if (LogoBase64 == null || LogoBase64.Length > 2796204)
            throw new InvalidDataException("El logo debe ser una imagen PNG o JPEG de hasta 2 MB.");
        if (LogoBase64.Length > 0)
        {
            byte[] imagen;
            try { imagen = Convert.FromBase64String(LogoBase64); }
            catch (FormatException ex) { throw new InvalidDataException("El logo no contiene una imagen codificada válida.", ex); }
            bool png = imagen.Length >= 8 && imagen.AsSpan(0, 8).SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 });
            bool jpeg = imagen.Length >= 4 && imagen[0] == 0xFF && imagen[1] == 0xD8 && imagen[^2] == 0xFF && imagen[^1] == 0xD9;
            if (imagen.Length > 2 * 1024 * 1024 || (!png && !jpeg))
                throw new InvalidDataException("El logo debe ser una imagen PNG o JPEG de hasta 2 MB.");
        }
    }

    /// <summary>Aplica a un presupuesto nuevo. Cada fila conserva una identidad estable
    /// para poder combinar el resumen de varios presupuestos sin duplicar conceptos.</summary>
    public void Aplicar(MYGPresupuestoDocumento presupuesto)
    {
        ArgumentNullException.ThrowIfNull(presupuesto); Validar();
        var costos = presupuesto.Costos ?? new MYGCostosPresupuesto();
        var filas = new List<MYGFilaPiePersonalizada>();
        void Fila(string id, string nombre, string identificador, decimal porcentaje, string formula = null,
            MYGTipoFilaResumen tipo = MYGTipoFilaResumen.CampoPersonalizado)
        {
            filas.Add(new() { Id = "parametros:" + id, Nombre = nombre.Trim(), Identificador = identificador,
                Porcentaje = porcentaje, Base = MYGBaseFilaPie.CostoDirecto, Tipo = tipo,
                Modo = formula == null ? MYGModoFilaResumen.GastoConSustento : MYGModoFilaResumen.OtrosGastos,
                Formula = formula });
        }
        Fila("gg", NombreGastosGenerales, AbreviaturaGastosGenerales, GastosGeneralesPorcentaje, tipo: MYGTipoFilaResumen.GastosGenerales);
        Fila("og", NombreOtrosGastos, AbreviaturaOtrosGastos, OtrosGastosPorcentaje);
        Fila("ut", "Utilidad", "UT", UtilidadPorcentaje, tipo: MYGTipoFilaResumen.Utilidad);
        Fila("ir", NombreImpuestoRenta, "IR", ImpuestoRentaPorcentaje, "UT");
        string subtotal = "CD+" + AbreviaturaGastosGenerales + "+" + AbreviaturaOtrosGastos + "+UT";
        Fila("igv", NombreImpuesto, "IGV", ImpuestoPorcentaje, subtotal);
        Fila("oi", NombreOtrosImpuestos, "OI", OtrosImpuestosPorcentaje, subtotal);
        MYGPiePresupuesto.ValidarFilas(filas);
        costos.Moneda = Moneda.Trim(); costos.DecimalesPrecio = DecimalesPrecio; costos.DecimalesCantidad = DecimalesCantidad;
        costos.GastosGeneralesPorcentaje = GastosGeneralesPorcentaje; costos.UtilidadPorcentaje = UtilidadPorcentaje;
        costos.ImpuestoPorcentaje = ImpuestoPorcentaje; costos.OtrosImpuestosPorcentaje = OtrosImpuestosPorcentaje;
        costos.PiePersonalizado = filas; costos.PieDelphin = null;
        costos.MostrarTotalPiePersonalizado = true;
        presupuesto.Costos = costos;
    }

    public void Aplicar(ItemPresupuestoDelphin partida)
    {
        ArgumentNullException.ThrowIfNull(partida); Validar();
        if (MYGProyectoStorage.EsTitulo(partida)) return;
        partida.Costos ??= new MYGDatosPartida();
        partida.Unidad = UnidadPartida.Trim();
        partida.Costos.JornadaHoras = JornadaHoras;
        partida.Costos.RendimientoDiario = PeriodoRendimiento == "Hora" ? Rendimiento * JornadaHoras : Rendimiento;
    }

    public void Aplicar(MYGInsumo insumo)
    {
        ArgumentNullException.ThrowIfNull(insumo); Validar();
        insumo.Unidad = UnidadInsumo.Trim(); insumo.Proveedor = Proveedor.Trim();
    }

    public MYGHojaMetrado CrearHojaAcero()
    {
        Validar();
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        static string Alias(string diametro) => !diametro.EndsWith('″') ? "" : diametro == "1″" ? "1 pulg" : diametro.TrimEnd('″');
        static string Numero(decimal valor) => valor.ToString("0.############################", CultureInfo.InvariantCulture);
        static string Literal(string texto) => "\"" + texto.Replace("\"", "\"\"") + "\"";
        string Coincide(MYGParametroAcero acero, int fila)
        {
            string alias = Alias(acero.Diametro);
            return alias.Length == 0 ? "$D" + fila + "=" + Literal(acero.Diametro)
                : "OR($D" + fila + "=" + Literal(acero.Diametro) + ",$D" + fila + "=" + Literal(alias) + ")";
        }
        var opciones = Aceros.SelectMany(a => new[] { a.Diametro, Alias(a.Diametro) }).Where(s => s.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        for (int indice = 0; indice < Aceros.Count; indice++)
        {
            var acero = Aceros[indice]; string columna = MYGHojaCalculo.Columna(indice + 9);
            hoja.Celdas[columna + "2"].Contenido = acero.Diametro;
            hoja.Celdas[columna + "15"].Contenido = acero.PesoPorMetro.ToString("0.000#########################", CultureInfo.InvariantCulture);
            for (int fila = 3; fila <= 13; fila++)
                hoja.Celdas[columna + fila].Contenido = "=IF(" + Coincide(acero, fila) + ",$B" + fila + "*$C" + fila + "*SUM($E" + fila + ":$G" + fila + ")*(1+$H" + fila + "/100),0)";
            if (UnidadAcero != "kg") hoja.Celdas[columna + "16"].Contenido = "=" + columna + "14*" + columna + "15/1000";
        }
        for (int fila = 3; fila <= 13; fila++)
        {
            hoja.Celdas["D" + fila].ListaValores = new(opciones);
            foreach (var campo in new (string Columna, Func<MYGParametroAcero, decimal> Valor)[]
                { ("F", a => a.Gancho), ("G", a => a.Empalme), ("H", a => a.DesperdicioPorcentaje) })
            {
                var valores = Aceros.Where(a => campo.Valor(a) != 0).ToArray();
                if (valores.Length > 0)
                    hoja.Celdas[campo.Columna + fila].Contenido = "=SUM(" + string.Join(",", valores.Select(a =>
                        "IF(" + Coincide(a, fila) + "," + Numero(campo.Valor(a)) + ",0)")) + ")";
            }
        }
        hoja.Celdas["A16"].Contenido = "Peso Total (" + UnidadAcero + ")";
        hoja.Celdas["AD14"].Contenido = "Peso Total (" + UnidadAcero + ")";
        MYGContenidoPartida.RegistrarContenidoInicialPlantilla(hoja);
        MYGHojaCalculo.Validar(hoja);
        return hoja;
    }
}

/// <summary>Archivo independiente de los documentos. No mantiene referencias ni caché
/// entre lecturas y un archivo inválido nunca se sustituye durante un guardado normal.</summary>
public static class MYGParametrosUsuario
{
    internal static readonly JsonSerializerOptions Opciones = new()
    { WriteIndented = true, PropertyNameCaseInsensitive = true, UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow };
    private static readonly object puerta = new();
    public static string RutaAlternativaPruebas { get; set; }
    public static string RutaPredeterminada => RutaAlternativaPruebas ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "MYG", "Presupuestos", "parametros-predeterminados.json");

    public static MYGParametrosPredeterminados Leer(string ruta = null)
    {
        ruta = Path.GetFullPath(ruta ?? RutaPredeterminada);
        lock (puerta)
        {
            if (!File.Exists(ruta)) return new();
            if (new FileInfo(ruta).Length > 4 * 1024 * 1024)
                throw new InvalidDataException("El archivo de parámetros supera el tamaño admitido. Se conserva sin cambios.");
            MYGParametrosPredeterminados parametros;
            try { parametros = JsonSerializer.Deserialize<MYGParametrosPredeterminados>(File.ReadAllText(ruta, Encoding.UTF8), Opciones); }
            catch (JsonException ex) { throw new InvalidDataException("El archivo de parámetros no es válido. Se conserva sin cambios: " + ruta, ex); }
            if (parametros == null) throw new InvalidDataException("El archivo de parámetros está vacío. Se conserva sin cambios: " + ruta);
            parametros.Validar(); return parametros;
        }
    }

    public static void Guardar(MYGParametrosPredeterminados parametros, string ruta = null)
    {
        ArgumentNullException.ThrowIfNull(parametros);
        var copia = parametros.Copia(); copia.Validar();
        string contenido = JsonSerializer.Serialize(copia, Opciones);
        ruta = Path.GetFullPath(ruta ?? RutaPredeterminada);
        lock (puerta)
        {
            // También detecta un archivo dañado desde la última apertura del diálogo.
            if (File.Exists(ruta)) Leer(ruta);
            Directory.CreateDirectory(Path.GetDirectoryName(ruta));
            string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                byte[] datos = Encoding.UTF8.GetBytes(contenido);
                using (var archivo = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { archivo.Write(datos); archivo.Flush(true); }
                File.Move(temporal, ruta, true);
            }
            finally { if (File.Exists(temporal)) File.Delete(temporal); }
        }
    }
}
