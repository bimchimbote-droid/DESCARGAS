using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

public sealed class MYGEntradaCatalogo
{
    public string Id { get; set; }
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public string Unidad { get; set; }
    public string Grupo { get; set; }
    public decimal Precio { get; set; }
    public int Revision { get; set; }
    public override string ToString() => Codigo + " · " + Descripcion + " (" + Unidad + ")";
}

public sealed class MYGPlantillaPartidaCosto
{
    public string RaizLocalId { get; set; }
    public string Grupo { get; set; } = "";
    public int DecimalesPrecio { get; set; } = 2;
    public int DecimalesCantidad { get; set; } = 4;
    public List<ItemPresupuestoDelphin> Partidas { get; set; } = new();
    public List<MYGInsumo> Insumos { get; set; } = new();
}

// Guardar el presupuesto y guardar el catálogo son operaciones independientes.
// La edición registra los insumos nuevos mediante RegistrarInsumosAutomaticamente;
// guardar el documento no actualiza las copias reutilizables del catálogo.
public static class MYGCatalogos
{
    private static string Tabla(bool partidas) => partidas ? "catalogo_partida" : "catalogo_insumo";
    private static decimal Decimal(string texto) => decimal.Parse(texto, CultureInfo.InvariantCulture);
    private static string Ruta(string ruta) => Path.GetFullPath(ruta);

    public static List<MYGEntradaCatalogo> Listar(string ruta, bool partidas)
    {
        using var c = MYGBaseDatos.Abrir(ruta, false);
        if (!MYGBaseDatos.TieneTabla(c, null, Tabla(partidas))) return DelphinImportacionMYG.ListarEntradas(c, partidas);
        using var cmd = MYGBaseDatos.Comando(c, null, "SELECT id,codigo,descripcion,unidad,precio,revision," +
            (partidas ? "json_plantilla" : "grupo") + " FROM " + Tabla(partidas) + " ORDER BY codigo COLLATE NOCASE,descripcion");
        using var r = cmd.ExecuteReader(); var resultado = new List<MYGEntradaCatalogo>();
        while (r.Read()) resultado.Add(new MYGEntradaCatalogo
        { Id = r.GetString(0), Codigo = r.GetString(1), Descripcion = r.GetString(2), Unidad = r.GetString(3),
            Precio = Decimal(r.GetString(4)), Revision = r.GetInt32(5), Grupo = partidas ? GrupoPlantilla(r.GetString(6)) : r.GetString(6) });
        return resultado;
    }
    private static string GrupoPlantilla(string json)
    {
        using var datos = JsonDocument.Parse(json);
        foreach (var campo in datos.RootElement.EnumerateObject())
            if (campo.Name.Equals(nameof(MYGPlantillaPartidaCosto.Grupo), StringComparison.OrdinalIgnoreCase))
                return campo.Value.ValueKind == JsonValueKind.String ? campo.Value.GetString() ?? "" : "";
        return "";
    }
    public static List<string> ListarGruposCostos(string ruta) => Listar(ruta, true)
        .Select(x => x.Grupo).Where(x => !string.IsNullOrWhiteSpace(x))
        .Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase).ToList();

    private static string NormalizarGrupo(string grupo, bool obligatorio)
    {
        string nombre = (grupo ?? "").Trim();
        if (obligatorio && nombre.Length == 0)
            throw new InvalidDataException("Seleccione o cree un grupo para grabar los costos múltiples.");
        if (nombre.Length > 120 || nombre.Any(char.IsControl))
            throw new InvalidDataException("El grupo admite hasta 120 caracteres y no puede contener caracteres de control.");
        return nombre;
    }
    public static string SiguienteCodigo(string ruta, bool partidas)
    {
        var usados = Listar(ruta, partidas).Select(x => x.Codigo).ToHashSet(StringComparer.OrdinalIgnoreCase);
        string prefijo = partidas ? "P-" : "I-";
        for (int n = 1; n < int.MaxValue; n++)
        { string codigo = prefijo + n.ToString("D6", CultureInfo.InvariantCulture); if (!usados.Contains(codigo)) return codigo; }
        throw new InvalidOperationException("No se puede generar otro código.");
    }
    private static void ValidarCampos(string codigo, string descripcion, string unidad)
    {
        if (string.IsNullOrWhiteSpace(codigo) || string.IsNullOrWhiteSpace(descripcion) || string.IsNullOrWhiteSpace(unidad))
            throw new InvalidDataException("Indique código, descripción y unidad para el catálogo.");
        if (codigo.Trim().Length > 80 || descripcion.Trim().Length > 2000 || unidad.Trim().Length > 80)
            throw new InvalidDataException("Código, descripción o unidad demasiado largos.");
    }

    public static MYGPlantillaPartidaCosto CrearPlantilla(MYGPresupuestoDocumento p, ItemPresupuestoDelphin raiz)
    {
        ArgumentNullException.ThrowIfNull(p);
        int indice = raiz == null ? -1 : p.Items?.IndexOf(raiz) ?? -1;
        if (indice < 0)
            throw new InvalidOperationException("Seleccione una partida del presupuesto.");
        var copia = MYGProyectoStorage.Copia(p);
        MYGProyectoStorage.ValidarPresupuesto(copia);
        return CrearPlantillaValidada(copia, copia.Items[indice]);
    }
    private static MYGPlantillaPartidaCosto CrearPlantillaValidada(MYGPresupuestoDocumento p, ItemPresupuestoDelphin raiz)
    {
        if (MYGProyectoStorage.EsTitulo(raiz))
            throw new InvalidOperationException("Seleccione una partida del presupuesto.");
        var plantilla = new MYGPlantillaPartidaCosto { RaizLocalId = raiz.IdLocalMYG,
            DecimalesPrecio = p.Costos.DecimalesPrecio, DecimalesCantidad = p.Costos.DecimalesCantidad };
        var visitados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        void Visitar(ItemPresupuestoDelphin i)
        {
            if (!visitados.Add(i.IdLocalMYG)) return;
            // La plantilla reutiliza datos de costo, no metrados ni vínculos de una obra.
            var datos = MYGProyectoStorage.Copia(i.Costos);
            datos.Cantidad = 0; datos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
            datos.Metrados.Clear(); datos.MetradosBIM.Clear(); datos.Hoja = MYGHojaMetrado.Crear();
            datos.CatalogoMYGId = null; datos.CatalogoMYGRuta = null;
            var nodo = new ItemPresupuestoDelphin
            {
                Id = i.IdLocalMYG, IdLocalMYG = i.IdLocalMYG, Descripcion = i.Descripcion, Unidad = i.Unidad,
                TipoPropuesta = "PARTIDA", Costos = datos, Origen = "MODELO", Estado = "PROPUESTA"
            };
            plantilla.Partidas.Add(nodo);
            foreach (var r in datos.Analisis.Where(x => x.Grupo == MYGGrupoRecurso.Subpartidas))
                Visitar(p.Items.First(x => x.IdLocalMYG == r.SubpartidaIdLocal));
        }
        Visitar(raiz);
        var requeridos = plantilla.Partidas.SelectMany(x => x.Costos.Analisis)
            .Where(x => x.Grupo != MYGGrupoRecurso.Subpartidas).Select(x => x.InsumoId).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var insumo in p.Costos.Insumos.Where(x => requeridos.Contains(x.Id)))
        {
            var i = MYGProyectoStorage.Copia(insumo); i.CatalogoMYGId = null; i.CatalogoMYGRuta = null;
            plantilla.Insumos.Add(i);
        }
        ValidarPlantilla(plantilla); return plantilla;
    }
    private static MYGPresupuestoDocumento PresupuestoPlantilla(MYGPlantillaPartidaCosto plantilla) => new()
    {
        Nombre = "Validación de catálogo", Items = plantilla.Partidas,
        Costos = new MYGCostosPresupuesto { Insumos = plantilla.Insumos,
            DecimalesPrecio = plantilla.DecimalesPrecio, DecimalesCantidad = plantilla.DecimalesCantidad }
    };
    private static void ValidarPlantilla(MYGPlantillaPartidaCosto plantilla)
    {
        if (plantilla?.Partidas == null || plantilla.Insumos == null || plantilla.Partidas.Count == 0 ||
            plantilla.Partidas.Any(x => x == null || MYGProyectoStorage.EsTitulo(x) ||
                string.IsNullOrWhiteSpace(x.Descripcion) || string.IsNullOrWhiteSpace(x.Unidad)) ||
            plantilla.Partidas.Count(x => x.IdLocalMYG == plantilla.RaizLocalId) != 1)
            throw new InvalidDataException("La plantilla del catálogo está incompleta.");
        MYGProyectoStorage.ValidarPresupuesto(PresupuestoPlantilla(plantilla));
    }

    public static MYGEntradaCatalogo GuardarPartida(string ruta, MYGPresupuestoDocumento p, ItemPresupuestoDelphin partida,
        string codigo, string descripcion, string unidad, string idExistente = null, int revisionEsperada = 0, string grupo = null)
    {
        ValidarCampos(codigo, descripcion, unidad);
        var plantilla = CrearPlantilla(p, partida);
        if (grupo != null) plantilla.Grupo = NormalizarGrupo(grupo, false);
        string id = string.IsNullOrWhiteSpace(idExistente) ? MYGProyectoStorage.NuevoId() : idExistente;
        using var c = MYGBaseDatos.Abrir(ruta, true); using var t = c.BeginTransaction();
        if (grupo == null && revisionEsperada > 0)
        {
            using var anterior = MYGBaseDatos.Comando(c, t, "SELECT json_plantilla FROM catalogo_partida WHERE id=$p0", id);
            if (anterior.ExecuteScalar() is string jsonAnterior) plantilla.Grupo = GrupoPlantilla(jsonAnterior);
        }
        var entrada = EscribirPartida(c, t, plantilla, id, codigo, descripcion, unidad, revisionEsperada);
        t.Commit();
        return entrada;
    }

    // Cada partida genera una copia nueva del ACU. El lote y sus tablas nativas
    // se confirman juntos; la obra y sus referencias de catálogo no se modifican.
    public static IReadOnlyList<MYGEntradaCatalogo> GuardarPartidas(string ruta, MYGPresupuestoDocumento p,
        IEnumerable<string> partidaIds, string grupo)
    {
        ArgumentNullException.ThrowIfNull(p);
        ArgumentNullException.ThrowIfNull(partidaIds);
        string nombreGrupo = NormalizarGrupo(grupo, true);
        var ids = partidaIds.ToList();
        if (ids.Count == 0) throw new InvalidOperationException("Seleccione al menos una partida para grabar los costos múltiples.");
        if (ids.Any(string.IsNullOrWhiteSpace) || ids.Distinct(StringComparer.OrdinalIgnoreCase).Count() != ids.Count)
            throw new InvalidOperationException("La selección contiene identificadores de partidas vacíos o repetidos.");
        var copia = MYGProyectoStorage.Copia(p);
        MYGProyectoStorage.ValidarPresupuesto(copia);
        var pendientes = new List<MYGPlantillaPartidaCosto>();
        foreach (var id in ids)
        {
            var partida = copia.Items.FirstOrDefault(x => string.Equals(x.IdLocalMYG, id, StringComparison.OrdinalIgnoreCase));
            if (partida == null || MYGProyectoStorage.EsTitulo(partida))
                throw new InvalidOperationException("La selección debe contener sólo partidas del presupuesto activo.");
            ValidarCampos("P-000001", partida.Descripcion, partida.Unidad);
            var plantilla = CrearPlantillaValidada(copia, partida);
            plantilla.Grupo = nombreGrupo;
            pendientes.Add(plantilla);
        }

        using var c = MYGBaseDatos.Abrir(ruta, true); using var t = c.BeginTransaction();
        var usados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT codigo FROM catalogo_partida"))
        using (var r = cmd.ExecuteReader()) while (r.Read()) usados.Add(r.GetString(0));
        int siguiente = 1;
        var entradas = new List<MYGEntradaCatalogo>();
        foreach (var plantilla in pendientes)
        {
            string codigo;
            do
            {
                if (siguiente == int.MaxValue) throw new InvalidOperationException("No se puede generar otro código.");
                codigo = "P-" + (siguiente++).ToString("D6", CultureInfo.InvariantCulture);
            } while (!usados.Add(codigo));
            var raiz = plantilla.Partidas.First(x => x.IdLocalMYG == plantilla.RaizLocalId);
            entradas.Add(EscribirPartida(c, t, plantilla, MYGProyectoStorage.NuevoId(), codigo, raiz.Descripcion, raiz.Unidad, 0));
        }
        t.Commit();
        return entradas;
    }

    private static MYGEntradaCatalogo EscribirPartida(SqliteConnection c, SqliteTransaction t,
        MYGPlantillaPartidaCosto plantilla, string id, string codigo, string descripcion, string unidad, int revisionEsperada)
    {
        var raiz = plantilla.Partidas.First(x => x.IdLocalMYG == plantilla.RaizLocalId);
        raiz.Descripcion = descripcion.Trim(); raiz.Unidad = unidad.Trim();
        ValidarPlantilla(plantilla);
        decimal precio = MYGMotorPresupuestos.Analizar(PresupuestoPlantilla(plantilla), raiz).PrecioUnitario;
        AsegurarCodigoLibre(c, t, true, codigo.Trim(), id);
        string json = MYGBaseDatos.Json(plantilla), fecha = DateTime.UtcNow.ToString("O");
        if (revisionEsperada == 0)
            MYGBaseDatos.Ejecutar(c, t, "INSERT INTO catalogo_partida(id,codigo,descripcion,unidad,precio,json_plantilla,revision,modificado_utc) VALUES($p0,$p1,$p2,$p3,$p4,$p5,1,$p6)",
                id, codigo.Trim(), descripcion.Trim(), unidad.Trim(), precio, json, fecha);
        else
        {
            int n = MYGBaseDatos.Ejecutar(c, t, "UPDATE catalogo_partida SET codigo=$p1,descripcion=$p2,unidad=$p3,precio=$p4,json_plantilla=$p5,revision=revision+1,modificado_utc=$p6 WHERE id=$p0 AND revision=$p7",
                id, codigo.Trim(), descripcion.Trim(), unidad.Trim(), precio, json, fecha, revisionEsperada);
            if (n != 1) throw new InvalidOperationException("La partida del catálogo cambió en otra ventana. Cierre el diálogo y vuelva a intentarlo.");
            MYGBaseDatos.Ejecutar(c, t, "DELETE FROM catalogo_partida_recurso WHERE catalogo_id=$p0", id);
            MYGBaseDatos.Ejecutar(c, t, "DELETE FROM catalogo_partida_nodo WHERE catalogo_id=$p0", id);
            MYGBaseDatos.Ejecutar(c, t, "DELETE FROM catalogo_partida_insumo WHERE catalogo_id=$p0", id);
        }
        foreach (var i in plantilla.Partidas)
            MYGBaseDatos.Ejecutar(c, t, "INSERT INTO catalogo_partida_nodo(catalogo_id,id_local,descripcion,unidad,es_raiz,rendimiento,jornada,precio_directo,json_datos) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8)",
                id, i.IdLocalMYG, i.Descripcion, i.Unidad, i.IdLocalMYG == plantilla.RaizLocalId ? 1 : 0, i.Costos.RendimientoDiario, i.Costos.JornadaHoras, i.Costos.PrecioDirecto, MYGBaseDatos.Json(i.Costos));
        // Los recursos de una plantilla son instantáneas privadas del ACU.
        // Guardar una partida no registra automáticamente cada insumo en catalogo_insumo.
        foreach (var i in plantilla.Insumos)
            MYGBaseDatos.Ejecutar(c, t, "INSERT INTO catalogo_partida_insumo(catalogo_id,id,codigo,descripcion,unidad,grupo,precio) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6)",
                id, i.Id, i.Codigo, i.Descripcion, i.Unidad, i.Grupo.ToString(), i.Precio);
        foreach (var i in plantilla.Partidas)
            foreach (var r in i.Costos.Analisis)
                MYGBaseDatos.Ejecutar(c, t, "INSERT INTO catalogo_partida_recurso(catalogo_id,nodo_local,id,grupo,insumo_id,subpartida_local,modo,numero_recursos,cantidad,desperdicio) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9)",
                    id, i.IdLocalMYG, r.Id, r.Grupo.ToString(), r.Grupo == MYGGrupoRecurso.Subpartidas ? null : r.InsumoId,
                    r.Grupo == MYGGrupoRecurso.Subpartidas ? r.SubpartidaIdLocal : null, r.Modo.ToString(), r.NumeroRecursos, r.Cantidad, r.DesperdicioPorcentaje);
        MYGDelphinFormato.SincronizarEntradaCatalogo(c, t, true, id);
        using (var precioGuardado = MYGBaseDatos.Comando(c, t, "SELECT precio FROM catalogo_partida WHERE id=$p0", id))
            precio = Convert.ToDecimal(precioGuardado.ExecuteScalar(), CultureInfo.InvariantCulture);
        return new MYGEntradaCatalogo { Id = id, Codigo = codigo.Trim(), Descripcion = descripcion.Trim(), Unidad = unidad.Trim(),
            Grupo = plantilla.Grupo, Precio = precio, Revision = revisionEsperada + 1 };
    }

    public static MYGEntradaCatalogo GuardarInsumo(string ruta, MYGInsumo insumo, string idExistente = null, int revisionEsperada = 0)
    {
        ValidarCampos(insumo.Codigo, insumo.Descripcion, insumo.Unidad);
        var comprobacion = new MYGPresupuestoDocumento { Nombre = "Catálogo de insumos" };
        comprobacion.Costos.Insumos.Add(MYGProyectoStorage.Copia(insumo)); MYGProyectoStorage.ValidarPresupuesto(comprobacion);
        var copia = MYGProyectoStorage.Copia(insumo); copia.CatalogoMYGId = null; copia.CatalogoMYGRuta = null;
        copia.Codigo = copia.Codigo.Trim(); copia.Descripcion = copia.Descripcion.Trim(); copia.Unidad = copia.Unidad.Trim();
        string id = string.IsNullOrWhiteSpace(idExistente) ? MYGProyectoStorage.NuevoId() : idExistente;
        copia.Id = id;
        using var c = MYGBaseDatos.Abrir(ruta, true); using var t = c.BeginTransaction();
        AsegurarCodigoLibre(c, t, false, copia.Codigo.Trim(), id);
        EscribirInsumo(c, t, copia, revisionEsperada);
        t.Commit();
        return new MYGEntradaCatalogo { Id = id, Codigo = copia.Codigo.Trim(), Descripcion = copia.Descripcion.Trim(), Unidad = copia.Unidad.Trim(), Grupo = copia.Grupo.ToString(), Precio = copia.Precio, Revision = revisionEsperada + 1 };
    }

    private static void EscribirInsumo(SqliteConnection c, SqliteTransaction t, MYGInsumo copia, int revisionEsperada)
    {
        string id = copia.Id;
        object[] datos = { id, copia.Codigo.Trim(), copia.Descripcion.Trim(), copia.Unidad.Trim(), copia.Grupo.ToString(), copia.Precio, MYGBaseDatos.Json(copia), DateTime.UtcNow.ToString("O"), revisionEsperada };
        if (revisionEsperada == 0)
            MYGBaseDatos.Ejecutar(c, t, "INSERT INTO catalogo_insumo(id,codigo,descripcion,unidad,grupo,precio,json_datos,revision,modificado_utc) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,1,$p7)", datos.Take(8).ToArray());
        else if (MYGBaseDatos.Ejecutar(c, t, "UPDATE catalogo_insumo SET codigo=$p1,descripcion=$p2,unidad=$p3,grupo=$p4,precio=$p5,json_datos=$p6,revision=revision+1,modificado_utc=$p7 WHERE id=$p0 AND revision=$p8", datos) != 1)
            throw new InvalidOperationException("El insumo del catálogo cambió en otra ventana. Cierre el diálogo y vuelva a intentarlo.");
        MYGDelphinFormato.SincronizarEntradaCatalogo(c, t, false, id);
    }

    // Preparar y registrar el lote sin cambiar las copias locales hasta confirmar
    // la transacción. Una referencia válida conserva su instantánea del catálogo.
    public static void RegistrarInsumosAutomaticamente(string ruta, IEnumerable<MYGInsumo> insumos, Action antes = null)
    {
        ArgumentNullException.ThrowIfNull(insumos);
        string destino = Ruta(ruta);
        var pendientes = insumos.Distinct().Select(original =>
        {
            MYGInsumosEdicion.ValidarInsumo(original);
            var copia = MYGProyectoStorage.Copia(original);
            copia.Codigo = (copia.Codigo ?? "").Trim();
            copia.Descripcion = copia.Descripcion.Trim(); copia.Unidad = copia.Unidad.Trim();
            // El código vacío se genera después, dentro de la transacción.
            ValidarCampos(copia.Codigo.Length == 0 ? "I-000001" : copia.Codigo, copia.Descripcion, copia.Unidad);
            return (Original: original, Copia: copia);
        }).ToList();
        if (pendientes.Count == 0) return;

        using var c = MYGBaseDatos.Abrir(destino, true); using var t = c.BeginTransaction();
        var porId = new Dictionary<string, MYGInsumo>(StringComparer.OrdinalIgnoreCase);
        var porCodigo = new Dictionary<string, MYGInsumo>(StringComparer.OrdinalIgnoreCase);
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT id,codigo,json_datos FROM catalogo_insumo"))
        using (var r = cmd.ExecuteReader()) while (r.Read())
        {
            var entrada = JsonSerializer.Deserialize<MYGInsumo>(r.GetString(2), MYGProyectoStorage.Opciones)
                ?? throw new InvalidDataException("El insumo del catálogo está dañado.");
            entrada.Id = r.GetString(0); entrada.Codigo = r.GetString(1);
            porId.Add(entrada.Id, entrada); porCodigo.Add(entrada.Codigo, entrada);
        }

        // Reservar también los códigos explícitos que aparecen más adelante.
        var usados = porCodigo.Keys.Concat(pendientes.Select(x => x.Copia.Codigo).Where(x => x.Length > 0))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var nuevos = new List<MYGInsumo>();
        var resultados = new List<(MYGInsumo Original, string Codigo, string Id)>();
        int siguiente = 1;
        foreach (var pendiente in pendientes)
        {
            var copia = pendiente.Copia;
            if (!string.IsNullOrWhiteSpace(copia.CatalogoMYGId) && porId.TryGetValue(copia.CatalogoMYGId, out var referencia))
            {
                resultados.Add((pendiente.Original, copia.Codigo.Length == 0 ? referencia.Codigo : copia.Codigo, referencia.Id));
                continue;
            }
            if (copia.Codigo.Length == 0)
            {
                string codigo;
                do
                {
                    if (siguiente == int.MaxValue) throw new InvalidOperationException("No se puede generar otro código.");
                    codigo = "I-" + (siguiente++).ToString("D6", CultureInfo.InvariantCulture);
                } while (!usados.Add(codigo));
                copia.Codigo = codigo;
            }
            copia.CatalogoMYGId = null; copia.CatalogoMYGRuta = null;
            if (porCodigo.TryGetValue(copia.Codigo, out var existente))
            {
                if (!MismosDatosInsumo(copia, existente))
                    throw new InvalidOperationException("El código '" + copia.Codigo + "' ya pertenece a otro insumo del catálogo. " +
                        "Cambie el código de '" + copia.Descripcion + "' o seleccione el insumo existente; no se agregó ningún insumo.");
                resultados.Add((pendiente.Original, copia.Codigo, existente.Id));
            }
            else
            {
                copia.Id = MYGProyectoStorage.NuevoId();
                porCodigo.Add(copia.Codigo, copia); porId.Add(copia.Id, copia); nuevos.Add(copia);
                resultados.Add((pendiente.Original, copia.Codigo, copia.Id));
            }
        }
        if (nuevos.Count > 0 || resultados.Any(x => x.Original.Codigo != x.Codigo ||
            x.Original.CatalogoMYGId != x.Id || x.Original.CatalogoMYGRuta != destino)) antes?.Invoke();
        foreach (var nuevo in nuevos) EscribirInsumo(c, t, nuevo, 0);
        t.Commit();
        foreach (var resultado in resultados)
        {
            resultado.Original.Codigo = resultado.Codigo;
            resultado.Original.CatalogoMYGId = resultado.Id;
            resultado.Original.CatalogoMYGRuta = destino;
        }
    }

    private static bool MismosDatosInsumo(MYGInsumo a, MYGInsumo b)
    {
        // JSON incluye todos los metadatos presentes y futuros del modelo.
        // La identidad local y la procedencia no definen el producto reutilizable.
        var izquierda = MYGProyectoStorage.Copia(a); var derecha = MYGProyectoStorage.Copia(b);
        izquierda.Id = derecha.Id = "";
        izquierda.CatalogoMYGId = derecha.CatalogoMYGId = null;
        izquierda.CatalogoMYGRuta = derecha.CatalogoMYGRuta = null;
        izquierda.Codigo = derecha.Codigo = "";
        return MYGBaseDatos.Json(izquierda) == MYGBaseDatos.Json(derecha);
    }
    private static void AsegurarCodigoLibre(SqliteConnection c, SqliteTransaction t, bool partidas, string codigo, string id)
    {
        using var cmd = MYGBaseDatos.Comando(c, t, "SELECT id FROM " + Tabla(partidas) + " WHERE codigo=$p0 AND id<>$p1", codigo, id);
        if (cmd.ExecuteScalar() != null) throw new InvalidOperationException("Ese código ya existe en el catálogo. Use otro código o seleccione la entrada para actualizarla.");
    }
    private static string LeerJson(string ruta, bool partidas, string id, int revisionEsperada = 0)
    {
        using var c = MYGBaseDatos.Abrir(ruta, false);
        if (!MYGBaseDatos.TieneTabla(c, null, Tabla(partidas)))
            return partidas ? MYGBaseDatos.Json(DelphinImportacionMYG.LeerPlantillaPartida(c, id)) : MYGBaseDatos.Json(DelphinImportacionMYG.LeerInsumo(c, id));
        using var cmd = MYGBaseDatos.Comando(c, null, "SELECT " + (partidas ? "json_plantilla" : "json_datos") + ",revision FROM " + Tabla(partidas) + " WHERE id=$p0", id);
        using var r = cmd.ExecuteReader();
        if (!r.Read()) throw new InvalidOperationException("La entrada ya no existe en el catálogo.");
        if (revisionEsperada > 0 && r.GetInt32(1) != revisionEsperada)
            throw new InvalidOperationException("La entrada cambió. Actualice el catálogo y vuelva a seleccionarla.");
        return r.GetString(0);
    }
    public static MYGInsumo LeerInsumo(string ruta, string id, int revisionEsperada = 0) =>
        JsonSerializer.Deserialize<MYGInsumo>(LeerJson(ruta, false, id, revisionEsperada), MYGProyectoStorage.Opciones)
        ?? throw new InvalidDataException("El insumo del catálogo está dañado.");
    public static MYGPlantillaPartidaCosto LeerPartida(string ruta, string id, int revisionEsperada = 0)
    {
        var plantilla = JsonSerializer.Deserialize<MYGPlantillaPartidaCosto>(LeerJson(ruta, true, id, revisionEsperada), MYGProyectoStorage.Opciones);
        ValidarPlantilla(plantilla); return plantilla;
    }

    // Trabaja sobre una copia: el presupuesto original nunca queda a medio modificar.
    // Cada uso recibe identidades nuevas, también los insumos y las subpartidas.
    public static ItemPresupuestoDelphin InsertarPartida(MYGPresupuestoDocumento p, string ruta, MYGEntradaCatalogo entrada, string padreId)
    {
        var plantilla = LeerPartida(ruta, entrada.Id, entrada.Revision);
        var trabajo = MYGProyectoStorage.Copia(p);
        if (!string.IsNullOrWhiteSpace(padreId) && !trabajo.Items.Any(x => x.Id == padreId && MYGProyectoStorage.EsTitulo(x)))
            throw new InvalidOperationException("Seleccione un título como destino.");
        var origen = PresupuestoPlantilla(plantilla);
        bool mismaPrecision = trabajo.Costos.DecimalesPrecio == plantilla.DecimalesPrecio &&
            trabajo.Costos.DecimalesCantidad == plantilla.DecimalesCantidad;
        var redondeos = plantilla.Partidas.Where(x => mismaPrecision && MYGMotorPresupuestos.ConservaAnalisisDelphin(origen, x))
            .ToDictionary(x => x.IdLocalMYG, x => MYGMotorPresupuestos.Analizar(origen, x).PrecioUnitario, StringComparer.OrdinalIgnoreCase);
        var mapaPartidas = plantilla.Partidas.ToDictionary(x => x.IdLocalMYG, x => MYGProyectoStorage.NuevoId(), StringComparer.OrdinalIgnoreCase);
        var mapaInsumos = plantilla.Insumos.ToDictionary(x => x.Id, x => MYGProyectoStorage.NuevoId(), StringComparer.OrdinalIgnoreCase);
        foreach (var original in plantilla.Insumos)
        {
            var i = MYGProyectoStorage.Copia(original); i.Id = mapaInsumos[original.Id];
            i.CatalogoMYGId = null; i.CatalogoMYGRuta = null; trabajo.Costos.Insumos.Add(i);
        }
        int posicion = trabajo.Items.Where(x => x.ParentId == padreId).Select(x => x.Posicion).DefaultIfEmpty().Max();
        ItemPresupuestoDelphin raiz = null;
        foreach (var original in plantilla.Partidas)
        {
            bool principal = original.IdLocalMYG == plantilla.RaizLocalId;
            string id = mapaPartidas[original.IdLocalMYG];
            var i = new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, IdPropuesta = id, ParentId = padreId, TipoPropuesta = "PARTIDA",
                Descripcion = original.Descripcion, Unidad = original.Unidad, Origen = "MODELO", Estado = "PROPUESTA",
                Item = "P-" + (trabajo.Items.Count + 1).ToString("D3"), Posicion = ++posicion,
                Costos = MYGProyectoStorage.Copia(original.Costos)
            };
            // Las firmas contienen las identidades anteriores. Una firma caduca
            // o una precisión distinta exige recalcular en el nuevo presupuesto.
            i.Costos.FirmaDatosImportadosDelphin = null; i.Costos.FirmaAnalisisImportadoDelphin = null;
            i.Costos.PrecioImportadoDelphin = null; i.Costos.ParcialImportadoDelphin = null; i.Costos.CantidadImportadaDelphin = null;
            foreach (var r in i.Costos.Analisis)
            {
                r.Id = MYGProyectoStorage.NuevoId();
                if (r.Grupo == MYGGrupoRecurso.Subpartidas) { r.SubpartidaIdLocal = mapaPartidas[r.SubpartidaIdLocal]; r.InsumoId = null; }
                else { r.InsumoId = mapaInsumos[r.InsumoId]; r.SubpartidaIdLocal = null; }
            }
            if (principal) { raiz = i; i.Costos.CatalogoMYGId = entrada.Id; i.Costos.CatalogoMYGRuta = Ruta(ruta); }
            trabajo.Items.Add(i);
        }
        // Sólo los precios importados que seguían vigentes antes del remapeo
        // renuevan su firma. Los catálogos no trasladan parciales de una obra.
        foreach (var r in redondeos)
        {
            var copiada = trabajo.Items.Single(x => x.IdLocalMYG == mapaPartidas[r.Key]);
            MYGMotorPresupuestos.CapturarPrecioDelphin(trabajo, copiada, r.Value, 0);
            copiada.Costos.ParcialImportadoDelphin = null; copiada.Costos.CantidadImportadaDelphin = null;
        }
        MYGProyectoStorage.ValidarPresupuesto(trabajo);
        if (trabajo.Conexion == null) MYGProyectoStorage.Renumerar(trabajo);
        p.Items = trabajo.Items; p.Costos = trabajo.Costos;
        return raiz;
    }
    public static MYGInsumo InsertarInsumo(MYGPresupuestoDocumento p, string ruta, MYGEntradaCatalogo entrada)
    {
        var i = LeerInsumo(ruta, entrada.Id, entrada.Revision);
        i.Id = MYGProyectoStorage.NuevoId(); i.CatalogoMYGId = entrada.Id; i.CatalogoMYGRuta = Ruta(ruta);
        var trabajo = MYGProyectoStorage.Copia(p); trabajo.Costos.Insumos.Add(i); MYGProyectoStorage.ValidarPresupuesto(trabajo);
        p.Costos.Insumos.Add(i); return i;
    }
    // Identidades globales permiten mover/copiar una base sin perder la referencia.
    // Si una entrada sólo existe en otro catálogo, aquí se ofrece crear una copia local.
    public static MYGEntradaCatalogo Referencia(string ruta, bool partidas, string id, string rutaReferencia) =>
        string.IsNullOrWhiteSpace(id) ? null : Listar(ruta, partidas).FirstOrDefault(x => x.Id == id);
    public static void Eliminar(string ruta, bool partidas, MYGEntradaCatalogo entrada)
    {
        using var c = MYGBaseDatos.Abrir(ruta, true); using var t = c.BeginTransaction();
        if (MYGBaseDatos.Ejecutar(c, t, "DELETE FROM " + Tabla(partidas) + " WHERE id=$p0 AND revision=$p1", entrada.Id, entrada.Revision) != 1)
            throw new InvalidOperationException("La entrada cambió en otra ventana. Actualice el catálogo.");
        if (!MYGDelphinFormato.EliminarEntradaCatalogo(c, t, partidas, entrada.Id))
            throw new InvalidOperationException("La entrada está usada en datos nativos de Delphin y no se puede eliminar sin desvincularlos.");
        t.Commit();
    }
}
