# Dependencias de la distribución

| Componente | Versión | Licencia declarada por el paquete |
| --- | --- | --- |
| Microsoft.Data.Sqlite / Microsoft.Data.Sqlite.Core | 10.0.0 | MIT; © Microsoft Corporation. |
| SQLitePCLRaw.bundle_e_sqlite3 / batteries_v2 / core / provider.e_sqlite3 | 2.1.11 | Apache-2.0; Copyright 2014–2024 SourceGear, LLC. |
| SQLitePCLRaw.lib.e_sqlite3 | 2.1.12 | Apache-2.0; Copyright 2014–2024 SourceGear, LLC. |
| Lanzador .NET para Windows x64 | 10.0.0 | MIT; Microsoft y colaboradores .NET. |

Se fija expresamente la biblioteca nativa `SQLitePCLRaw.lib.e_sqlite3` en **2.1.12**. Esa es la versión incluida en la distribución, aunque los componentes administrados SQLitePCLRaw declaren otra versión.

Los textos de licencia y los avisos del lanzador .NET se incluyen en `licencias`.

Paquetes y repositorios:

- <https://www.nuget.org/packages/Microsoft.Data.Sqlite/10.0.0>
- <https://github.com/dotnet/efcore>
- <https://www.nuget.org/packages/SQLitePCLRaw.lib.e_sqlite3/2.1.12>
- <https://github.com/ericsink/SQLitePCL.raw>
- <https://github.com/dotnet/runtime>

Las referencias `RevitAPI.dll` y `RevitAPIUI.dll` las suministra la instalación de Autodesk Revit 2027. No se redistribuyen en este paquete. Para la comprobación de compilación fuera de Windows se emplearon los paquetes de referencia Nice3point.Revit.Api 2027.0.0; no se necesitan para compilar normalmente con Revit instalado.
