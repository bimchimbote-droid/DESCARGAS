# Corrección de textos del menú contextual

Esta actualización se aplica sobre la entrega de Pegado Especial y Ortografía
publicada en `bimchimbote-droid/DESCARGAS`, commit
`6601d7afaba6d9e15b83a7f7e3613e8a17761be9`.
La base del código continúa siendo `main`, commit
`081ee6172c9274aa37608bf1bbac2980e206fc70`.

## Problema y corrección

Las opciones generales del clic derecho tenían `DisplayStyle.Image`: Windows
dibujaba el icono y omitía la etiqueta. Las sugerencias ortográficas, creadas por
otra ruta, conservaban sus textos. Además, el popup usaba el renderer predeterminado,
por lo que permanecía blanco en modo oscuro.

Ahora las opciones generales muestran **icono y texto en una fila horizontal**.
El menú completo usa la paleta del editor al abrirse y al alternar el tema, con
colores diferenciados para opciones habilitadas, deshabilitadas y seleccionadas.
También se aplica a las sugerencias y los comandos ortográficos.

## Archivos de este ZIP

| Ruta | Acción |
|---|---|
| MYG.Desktop/EspecificacionesContexto.cs | REEMPLAZAR |
| MYG.Desktop/EspecificacionesEditor.cs | REEMPLAZAR |
| MYG.PruebasUI/EspecificacionesContextoCheck.cs | REEMPLAZAR |
| CORRECCION_MENU_ESPECIFICACIONES.md | CREAR |

Los archivos REEMPLAZAR se entregan completos. Este ZIP es incremental y necesita
los demás archivos de la entrega anterior. No contiene el proyecto completo.

## Instalación

1. Respalde o confirme sus cambios locales en Visual Studio.
2. Cierre MYG. Extraiga el ZIP y copie los archivos conservando sus rutas relativas.
   Compare antes de reemplazar si tiene modificaciones locales posteriores.
3. Compile con el SDK .NET 10; `global.json` admite versiones compatibles posteriores
   a 10.0.100:

   ```powershell
   dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
   dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
   dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
   ```

   El último comando requiere Windows y el runtime Windows Desktop.
4. Abra una especificación y pruebe clic derecho sobre texto normal, sobre una palabra
   con error y en el margen de la hoja. Compruebe que todas las etiquetas son legibles
   en modo normal y oscuro, tanto habilitadas como deshabilitadas o seleccionadas.
5. Alterne el tema y vuelva a abrir el menú. Confirme que el documento conserva su
   contenido, formato, selección y posibilidades de Deshacer.
6. Revise **Cambios de Git**, haga Commit y después Push a su rama de trabajo.
   Verifique la rama en GitHub. La publicación del ZIP en DESCARGAS no publica
   automáticamente cambios del repositorio de código.

## Validación y requisitos

La entrega usa C#/.NET 10.0.100. La solución completa se compila con los paquetes de
referencia Revit previstos por el repositorio. Las 206 comprobaciones del ejecutor
Linux continúan pasando; Named Pipes de Windows se omite explícitamente allí.

Se agregaron comprobaciones de etiquetas, distribución horizontal, renderer y colores
del menú en ambos temas, tanto en su versión normal como ortográfica. Las pruebas de
interfaz se compilan en Linux; su ejecución y verificación visual requieren Windows.

No se añaden dependencias, variables ni migraciones de bases de datos. La revisión
ortográfica sigue usando el diccionario español de Windows instalado previamente.
No se necesita Word para esta corrección. Revit no se ejecuta en la validación Linux.
