using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ArrastrePresupuestosCheck
{
    private static void Exige(bool valor, string detalle) { if (!valor) throw new Exception(detalle); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static ItemPresupuestoDelphin Nodo(string nombre, int posicion, bool titulo = false, string padre = null)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new() { Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = nombre, Posicion = posicion,
            ParentId = padre, TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Item = nombre,
            Unidad = titulo ? "" : "und", Estado = "PROPUESTA", Origen = "MODELO" };
    }
    private static MYGProyectoDocumento Crear(out MYGPresupuestoDocumento p, out ItemPresupuestoDelphin a,
        out ItemPresupuestoDelphin a1, out ItemPresupuestoDelphin a2, out ItemPresupuestoDelphin b,
        out ItemPresupuestoDelphin b1, out ItemPresupuestoDelphin c)
    {
        var d = MYGProyectoStorage.Nuevo("ARRASTRE DE ITEMIZADO");
        d.Datos = new MYGDatosProyecto { UsarUbicacion = false }; p = d.Presupuestos.Single();
        a = Nodo("A", 1, true); a1 = Nodo("A1", 1, padre: a.Id); a2 = Nodo("A2", 2, padre: a.Id);
        b = Nodo("B", 2, true); b1 = Nodo("B1", 1, padre: b.Id); c = Nodo("C", 3);
        p.Items.AddRange(new[] { a, a1, a2, b, b1, c });
        a1.Costos.PrecioDirecto = 7; a1.Costos.Cantidad = 2;
        a2.Costos.Metrados.Add(new() { Descripcion = "MANUAL CONSERVADO", Elementos = 1, CantidadPorElemento = 3 });
        a2.Costos.MetradosBIM.Add(new() { ActivoId = "BIM", DocumentoId = "MODELO", Unidad = "und", Cantidad = 4 });
        a2.Costos.Hoja.Poner("G16", "5"); a2.Filtros.Add(new() { Parametro = "Nivel", Regla = "Igual", Valor = "1" });
        c.Costos.Cantidad = 1;
        c.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = a1.IdLocalMYG, Cantidad = 1 });
        MYGProyectoStorage.Renumerar(p); MYGProyectoStorage.Validar(d); return d;
    }
    private static bool Mover(MYGProyectoDocumento d, MYGPresupuestoDocumento p, ItemPresupuestoDelphin origen,
        ItemPresupuestoDelphin destino, MYGDestinoArrastre modo) =>
        MYGArrastrePresupuestos.Mover(d, p.Id, origen.Id, p.Id, destino?.Id, modo);
    private static void RechazaSinCambios(MYGProyectoDocumento d, Action accion)
    {
        string antes = Firma(d); bool rechazada = false;
        try { accion(); }
        catch (Exception ex) when (ex is InvalidDataException or InvalidOperationException or ArgumentException) { rechazada = true; }
        Exige(rechazada && Firma(d) == antes, "Un arrastre inválido se permitió o dejó cambios parciales.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var d = Crear(out var p, out var a, out var a1, out var a2, out var b, out var b1, out var c);
        var lista = p.Items; var costos = a2.Costos; var filtros = a2.Filtros; var acu = c.Costos.Analisis;
        string contenido = Firma(new { a2.Costos, a2.Filtros, ACU = c.Costos, a2.Id, a2.IdLocalMYG, a2.IdPropuesta });
        decimal total = MYGMotorPresupuestos.Resumen(p).Total;
        var antes = MYGProyectoStorage.Copia(d);
        Exige(MYGArrastrePresupuestos.PuedeMover(d, p.Id.ToUpperInvariant(), a2.Id.ToUpperInvariant(), p.Id, b.Id, MYGDestinoArrastre.Dentro) &&
            Mover(d, p, a2, b, MYGDestinoArrastre.Dentro), "No se pudo integrar una partida dentro del título.");
        Exige(a2.ParentId == b.Id && a2.Posicion == 2 && a2.Item == "02.02" && a1.Item == "01.01" &&
            p.Items.SequenceEqual(new[] { a, a1, b, b1, a2, c }) && ReferenceEquals(lista, p.Items) &&
            ReferenceEquals(costos, a2.Costos) && ReferenceEquals(filtros, a2.Filtros) && ReferenceEquals(acu, c.Costos.Analisis) &&
            Firma(new { a2.Costos, a2.Filtros, ACU = c.Costos, a2.Id, a2.IdLocalMYG, a2.IdPropuesta }) == contenido &&
            MYGMotorPresupuestos.Resumen(p).Total == total && antes.Presupuestos.Single().Items.Single(x => x.Id == a2.Id).ParentId == a.Id,
            "Integrar la partida perdió numeración, identidades, fuentes, filtros, referencias, importes o el estado para deshacer.");
        pasa("Arrastrar una partida a un título renumera el itemizado local y conserva instancias, IDs, ACU, filtros, fuentes y estado anterior");

        Exige(Mover(d, p, a2, b1, MYGDestinoArrastre.Antes) && a2.Item == "02.01" && b1.Item == "02.02" &&
            Mover(d, p, a2, b1, MYGDestinoArrastre.Despues) && a2.Item == "02.02", "Insertar antes/después no reordenó hermanos.");
        Exige(Mover(d, p, a, b, MYGDestinoArrastre.Dentro) && a.ParentId == b.Id && a.Item == "01.03" && a1.Item == "01.03.01" &&
            a1.ParentId == a.Id && ReferenceEquals(p.Items.Single(x => x.Id == a1.Id), a1), "Integrar un título perdió su rama o numeración.");
        Exige(Mover(d, p, a, null, MYGDestinoArrastre.Dentro) && a.ParentId == null && a.Item == "03" && a1.Item == "03.01",
            "No se pudo sacar el título al nivel principal del presupuesto.");
        Exige(Mover(d, p, a, b, MYGDestinoArrastre.Antes) && a.Item == "01" && b.Item == "02" && c.Item == "03",
            "El título no se pudo reordenar antes de otro título.");
        string sinCambio = Firma(d);
        Exige(!Mover(d, p, c, null, MYGDestinoArrastre.Dentro) && Firma(d) == sinCambio,
            "Un arrastre a la misma posición produjo cambios falsos.");
        pasa("Arrastre antes/después y dentro mueve ramas completas; permite volver al nivel del presupuesto y detecta posiciones sin cambio");

        RechazaSinCambios(d, () => Mover(d, p, a, a1, MYGDestinoArrastre.Dentro));
        RechazaSinCambios(d, () => Mover(d, p, a, a1, MYGDestinoArrastre.Antes));
        RechazaSinCambios(d, () => Mover(d, p, a2, c, MYGDestinoArrastre.Dentro));
        RechazaSinCambios(d, () => Mover(d, p, a2, a2, MYGDestinoArrastre.Despues));
        RechazaSinCambios(d, () => Mover(d, p, a2, null, MYGDestinoArrastre.Antes));
        RechazaSinCambios(d, () => MYGArrastrePresupuestos.Mover(d, p.Id, "NO-EXISTE", p.Id, a.Id, MYGDestinoArrastre.Dentro));
        RechazaSinCambios(d, () => Mover(d, p, a2, b, (MYGDestinoArrastre)99));
        var otro = new MYGPresupuestoDocumento { Nombre = "OTRO" }; otro.Items.Add(MYGProyectoStorage.Copia(a2));
        otro.Items.Single().ParentId = null; d.Presupuestos.Add(otro);
        RechazaSinCambios(d, () => MYGArrastrePresupuestos.Mover(d, p.Id, a2.Id, otro.Id, null, MYGDestinoArrastre.Dentro));
        Exige(!MYGArrastrePresupuestos.PuedeMover(d, p.Id, a2.Id, otro.Id, null, MYGDestinoArrastre.Dentro), "Se habilitó un arrastre entre presupuestos con IDs coincidentes.");
        // La coincidencia de IDs sólo se usa para probar el límite del arrastre;
        // la proyección nativa de SQLite exige IDs únicos para costo_unitario.
        d.Presupuestos.Remove(otro);
        a1.Costos.Cantidad = -1;
        RechazaSinCambios(d, () => Mover(d, p, a2, a, MYGDestinoArrastre.Dentro)); a1.Costos.Cantidad = 2;
        pasa("Arrastre rechaza ciclos, partidas como contenedor, datos inválidos y cruces de presupuesto incluso con IDs repetidos sin mutar el documento");

        string ruta = Path.Combine(carpeta, "Arrastre jerarquia.sqlite");
        MYGProyectoStorage.Guardar(ruta, d);
        var recuperado = MYGBaseDatos.LeerProyecto(ruta, d.Id).Presupuestos.Single(x => x.Id == p.Id);
        Exige(Firma(recuperado.Items.Select(i => new { i.Id, i.IdLocalMYG, i.ParentId, i.Item, i.Posicion })) ==
            Firma(p.Items.Select(i => new { i.Id, i.IdLocalMYG, i.ParentId, i.Item, i.Posicion })) &&
            recuperado.Items.Single(x => x.Id == a2.Id).Costos.Hoja.Celdas["G16"].Contenido == "5" &&
            recuperado.Items.Single(x => x.Id == c.Id).Costos.Analisis.Single().SubpartidaIdLocal == a1.IdLocalMYG &&
            MYGMotorPresupuestos.Resumen(recuperado).Total == total, "Guardar/reabrir el arrastre perdió padres, itemizado, fuentes o subanálisis.");
        pasa("Jerarquía, orden e itemizado arrastrados persisten al guardar/reabrir SQLite MYG junto con fuentes y subanálisis");

        var conectado = Crear(out var pc, out var titulo, out var f1, out var f2, out var oficial, out var descendiente, out var propuesta);
        pc.Conexion = new() { FuenteId = "FUENTE", RutaSQLite = "oficial.sqlite", ProyectoId = "OBRA", PresupuestoId = "PRESUPUESTO" };
        oficial.IdInternoDelphin = "OFICIAL"; descendiente.IdInternoDelphin = "OFICIAL-HIJO";
        string datosOficiales = Firma(new[] { oficial, descendiente });
        string codigoPropuesta = propuesta.Item, codigoF2 = f2.Item;
        RechazaSinCambios(conectado, () => Mover(conectado, pc, oficial, titulo, MYGDestinoArrastre.Dentro));
        RechazaSinCambios(conectado, () => Mover(conectado, pc, titulo, propuesta, MYGDestinoArrastre.Despues));
        Exige(Mover(conectado, pc, f2, oficial, MYGDestinoArrastre.Dentro) && f2.ParentId == oficial.Id &&
            f2.Item == codigoF2 && propuesta.Item == codigoPropuesta && Firma(new[] { oficial, descendiente }) == datosOficiales,
            "Mover una propuesta dentro de título oficial cambió códigos, posiciones o datos oficiales.");
        var extra = Nodo("OFICIAL EN RAMA", 1, padre: titulo.Id); extra.IdInternoDelphin = "OFICIAL-EXTRA";
        pc.Items.Add(extra);
        RechazaSinCambios(conectado, () => Mover(conectado, pc, titulo, oficial, MYGDestinoArrastre.Dentro));
        var espacios = MYGProyectoStorage.Nuevo("POSICIONES OFICIALES"); espacios.Datos = new MYGDatosProyecto { UsarUbicacion = false };
        var pe = espacios.Presupuestos.Single(); var contenedor = Nodo("CONTENEDOR", 1, true);
        var ancla = Nodo("ANCLA", 1, padre: contenedor.Id); ancla.IdInternoDelphin = "ANCLA-OFICIAL";
        var libre = Nodo("LIBRE", 2); pe.Items.AddRange(new[] { contenedor, ancla, libre });
        MYGProyectoStorage.Validar(espacios);
        RechazaSinCambios(espacios, () => Mover(espacios, pe, libre, ancla, MYGDestinoArrastre.Antes));
        Exige(!MYGArrastrePresupuestos.PuedeMover(espacios, pe.Id, libre.Id, pe.Id, ancla.Id, MYGDestinoArrastre.Antes) &&
            Mover(espacios, pe, libre, ancla, MYGDestinoArrastre.Despues) && libre.ParentId == contenedor.Id && libre.Posicion == 2 && ancla.Posicion == 1,
            "La inserción fabricó espacio desplazando una posición oficial o bloqueó una inserción válida después del ancla.");
        pasa("Arrastre protege ramas con descendientes oficiales y sus posiciones; propuestas conectadas conservan códigos al integrarse dentro de títulos oficiales");

        var limite = MYGProyectoStorage.Nuevo("LÍMITE DE PROFUNDIDAD"); limite.Datos = new MYGDatosProyecto { UsarUbicacion = false };
        var pl = limite.Presupuestos.Single(); ItemPresupuestoDelphin ultimo = null;
        for (int n = 0; n < 65; n++) { var nuevo = Nodo("NIVEL " + n, 1, true, ultimo?.Id); pl.Items.Add(nuevo); ultimo = nuevo; }
        var mover = Nodo("FUERA", 2); pl.Items.Add(mover); MYGProyectoStorage.Validar(limite);
        Exige(!MYGArrastrePresupuestos.PuedeMover(limite, pl.Id, mover.Id, pl.Id, ultimo.Id, MYGDestinoArrastre.Dentro),
            "La previsualización habilitó un destino que supera el límite de profundidad.");
        RechazaSinCambios(limite, () => Mover(limite, pl, mover, ultimo, MYGDestinoArrastre.Dentro));
        pasa("Previsualización y movimiento rechazan jerarquías que superan 64 niveles sin cambios parciales");
    }
}
