using System;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class EspecificacionBorradorPersistenciaCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static object Sql(string ruta, string consulta, params object[] datos)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Pooling = false, ForeignKeys = true }.ToString());
        c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = consulta;
        for (int n = 0; n < datos.Length; n++) cmd.Parameters.AddWithValue("$p" + n, datos[n] ?? DBNull.Value);
        return cmd.ExecuteScalar();
    }

    private static void VerificarContenido(MYGDatosPartida datos, bool borrador, string texto, string rtf)
    {
        Exige(datos.EspecificacionEsBorrador == borrador && datos.EspecificacionTexto == texto &&
            datos.EspecificacionRtf == rtf, "La persistencia perdió el estado o contenido de la especificación.");
    }

    private static void VerificarNativo(string ruta, string tabla, bool borrador, string texto, string rtf)
    {
        Exige(Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM " + tabla)) == 1,
            "La prueba no encontró una única partida en la tabla nativa " + tabla + ".");
        if (borrador)
            Exige(Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM " + tabla +
                " WHERE COALESCE(especificaciones,'')<>'' OR LENGTH(COALESCE(archivo_especificaciones,X''))<>0")) == 0,
                "El borrador se exportó como especificación nativa en " + tabla + ".");
        else
        {
            Exige((string)Sql(ruta, "SELECT especificaciones FROM " + tabla) == texto &&
                Sql(ruta, "SELECT archivo_especificaciones FROM " + tabla) is byte[] bytes &&
                Encoding.Latin1.GetString(bytes) == rtf,
                "Guardar la especificación no restauró su texto y RTF nativos en " + tabla + ".");
        }
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        const string texto = "01 PARTIDA BORRADOR (und)\nDESCRIPCION\n";
        const string rtf = @"{\rtf1\ansi 01 PARTIDA BORRADOR (und)\par \b DESCRIPCION\b0\par}";
        var documento = MYGProyectoStorage.Nuevo("ESPECIFICACIONES EN BORRADOR");
        var presupuesto = documento.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = "CU-BORRADOR", IdLocalMYG = "CU-BORRADOR", IdPropuesta = "CU-BORRADOR",
            Descripcion = "PARTIDA BORRADOR", Unidad = "und", TipoPropuesta = "PARTIDA",
            Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1,
            Costos = new MYGDatosPartida
            {
                Cantidad = 1, PrecioDirecto = 2, EspecificacionTexto = texto,
                EspecificacionRtf = rtf, EspecificacionEsBorrador = true
            }
        };
        presupuesto.Items.Add(partida); MYGProyectoStorage.Renumerar(presupuesto);
        string json = Path.Combine(carpeta, "Especificación en borrador.myg.json");
        string sqlite = MYGBaseDatos.RutaDeProyecto(json);
        MYGProyectoStorage.Guardar(json, documento);
        foreach (string archivo in new[] { json, sqlite })
            VerificarContenido(MYGProyectoStorage.Leer(archivo).Presupuestos.Single().Items.Single().Costos, true, texto, rtf);
        VerificarNativo(sqlite, "costo_unitario", true, texto, rtf);
        pasa("JSON y SQLite conservan el borrador completo sin exportar una especificación técnica nativa");

        var entrada = MYGCatalogos.GuardarPartida(sqlite, presupuesto, partida, "BORRADOR-01", partida.Descripcion, partida.Unidad);
        VerificarContenido(MYGCatalogos.LeerPartida(sqlite, entrada.Id).Partidas.Single().Costos, true, texto, rtf);
        VerificarNativo(sqlite, "analisis_costo", true, texto, rtf);
        pasa("El catálogo conserva el borrador en MYG y omite texto y RTF en el análisis de costo nativo");

        partida.Costos.EspecificacionEsBorrador = false;
        MYGProyectoStorage.Guardar(json, documento);
        entrada = MYGCatalogos.GuardarPartida(sqlite, presupuesto, partida, entrada.Codigo,
            entrada.Descripcion, entrada.Unidad, entrada.Id, entrada.Revision);
        foreach (string archivo in new[] { json, sqlite })
            VerificarContenido(MYGProyectoStorage.Leer(archivo).Presupuestos.Single().Items.Single().Costos, false, texto, rtf);
        VerificarContenido(MYGCatalogos.LeerPartida(sqlite, entrada.Id).Partidas.Single().Costos, false, texto, rtf);
        foreach (string tabla in new[] { "costo_unitario", "analisis_costo" })
            VerificarNativo(sqlite, tabla, false, texto, rtf);
        pasa("Guardar la especificación exporta el mismo texto y RTF a la partida y al análisis nativos");

        partida.Costos.EspecificacionEsBorrador = true;
        MYGProyectoStorage.Guardar(json, documento);
        entrada = MYGCatalogos.GuardarPartida(sqlite, presupuesto, partida, entrada.Codigo,
            entrada.Descripcion, entrada.Unidad, entrada.Id, entrada.Revision);
        foreach (string tabla in new[] { "costo_unitario", "analisis_costo" })
            VerificarNativo(sqlite, tabla, true, texto, rtf);
        VerificarContenido(MYGProyectoStorage.Leer(sqlite).Presupuestos.Single().Items.Single().Costos, true, texto, rtf);
        pasa("Actualizar un borrador limpia las especificaciones nativas anteriores y conserva su contenido editable");

        // Algunos archivos nativos adjuntos no son RTF. Un borrador debe
        // retirarlos también aunque el texto y RTF leídos estén vacíos.
        foreach (string tabla in new[] { "costo_unitario", "analisis_costo" })
            Sql(sqlite, "UPDATE " + tabla + " SET archivo_especificaciones=X'000102'");
        MYGProyectoStorage.Guardar(json, documento);
        MYGCatalogos.GuardarPartida(sqlite, presupuesto, partida, entrada.Codigo,
            entrada.Descripcion, entrada.Unidad, entrada.Id, entrada.Revision);
        foreach (string tabla in new[] { "costo_unitario", "analisis_costo" })
            VerificarNativo(sqlite, tabla, true, texto, rtf);
        pasa("Un borrador tampoco conserva un archivo nativo de especificaciones ajeno al formato RTF");
    }
}
