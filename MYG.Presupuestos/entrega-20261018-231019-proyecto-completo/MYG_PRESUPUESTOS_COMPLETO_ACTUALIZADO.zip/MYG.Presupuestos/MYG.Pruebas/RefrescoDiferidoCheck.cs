using System;
using System.Collections.Generic;
using MYG_2027;

internal static class RefrescoDiferidoCheck
{
    private static void Exige(bool condicion, string detalle)
    {
        if (!condicion) throw new Exception(detalle);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        var cola = new Queue<Action>();
        var aplicados = new List<MYGTipoRefresco>();
        bool disponible = true;
        var refresco = new MYGRefrescoDiferido(cola.Enqueue, () => disponible, aplicados.Add);
        for (int n = 0; n < 1000; n++) refresco.Solicitar(MYGTipoRefresco.Calculos);
        Exige(cola.Count == 1 && aplicados.Count == 0,
            "Las notificaciones de edición no se agruparon en un solo mensaje diferido.");
        cola.Dequeue()();
        Exige(aplicados.Count == 1 && aplicados[0] == MYGTipoRefresco.Calculos && cola.Count == 0,
            "La edición agrupada aplicó más de un refresco o reencoló trabajo ya consumido.");
        pasa("Mil solicitudes de cálculos antes del mensaje UI aplican un solo refresco diferido");

        aplicados.Clear();
        refresco.Solicitar(MYGTipoRefresco.Calculos);
        refresco.Solicitar(MYGTipoRefresco.Estructura);
        refresco.Solicitar(MYGTipoRefresco.Calculos);
        Exige(cola.Count == 1, "El refresco estructural abrió otra cola innecesaria.");
        cola.Dequeue()();
        Exige(aplicados.Count == 1 &&
            aplicados[0] == (MYGTipoRefresco.Calculos | MYGTipoRefresco.Estructura),
            "Combinar solicitudes perdió el cambio estructural o el cálculo pendiente.");
        pasa("Un mensaje combina cálculos y estructura sin perder ninguna solicitud");

        aplicados.Clear(); disponible = false;
        refresco.Solicitar(MYGTipoRefresco.Estructura);
        Exige(cola.Count == 0 && aplicados.Count == 0,
            "Una interfaz no disponible inició una cola de reintentos.");
        disponible = true;
        refresco.Solicitar(MYGTipoRefresco.Calculos);
        Exige(cola.Count == 1, "La nueva solicitud no recuperó el trabajo retenido.");
        cola.Dequeue()();
        Exige(aplicados.Count == 1 &&
            aplicados[0] == (MYGTipoRefresco.Estructura | MYGTipoRefresco.Calculos),
            "La espera de disponibilidad descartó el cambio pendiente.");
        pasa("Interfaz ocupada retiene cambios sin bucle y la siguiente solicitud reintenta");

        aplicados.Clear();
        refresco.Solicitar(MYGTipoRefresco.Estructura);
        disponible = false;
        cola.Dequeue()();
        Exige(aplicados.Count == 0 && cola.Count == 0,
            "Perder disponibilidad después de encolar produjo refresco o reintento automático.");
        disponible = true;
        refresco.Solicitar(MYGTipoRefresco.Calculos);
        cola.Dequeue()();
        Exige(aplicados.Count == 1 &&
            aplicados[0] == (MYGTipoRefresco.Estructura | MYGTipoRefresco.Calculos),
            "Perder disponibilidad después de encolar descartó el trabajo anterior.");
        pasa("Perder disponibilidad entre solicitud y mensaje conserva cambios sin reencolar");

        aplicados.Clear(); disponible = false;
        refresco.Solicitar(MYGTipoRefresco.Calculos);
        refresco.Reintentar();
        Exige(cola.Count == 0, "Reintentar con la interfaz ocupada programó un mensaje.");
        disponible = true;
        refresco.Reintentar();
        Exige(cola.Count == 1 && aplicados.Count == 0,
            "Terminar la edición no recuperó el refresco retenido sin agregar cambios nuevos.");
        cola.Dequeue()();
        refresco.Reintentar();
        refresco.Solicitar(MYGTipoRefresco.Ninguno);
        Exige(aplicados.Count == 1 && aplicados[0] == MYGTipoRefresco.Calculos && cola.Count == 0,
            "Reintentar sin trabajo pendiente generó un refresco o alteró Solicitar(Ninguno).");
        pasa("Finalizar edición reintenta trabajo retenido y no crea refrescos si no hubo cambios");

        aplicados.Clear();
        int profundidad = 0, maximaProfundidad = 0;
        MYGRefrescoDiferido reentrante = null;
        reentrante = new MYGRefrescoDiferido(cola.Enqueue, () => true, tipo =>
        {
            profundidad++; maximaProfundidad = Math.Max(maximaProfundidad, profundidad);
            aplicados.Add(tipo);
            if (aplicados.Count == 1)
            {
                reentrante.Solicitar(MYGTipoRefresco.Estructura);
                reentrante.Solicitar(MYGTipoRefresco.Calculos);
                Exige(cola.Count == 0,
                    "Una solicitud durante el refresco agendó trabajo antes de finalizar.");
            }
            profundidad--;
        });
        reentrante.Solicitar(MYGTipoRefresco.Calculos);
        cola.Dequeue()();
        Exige(aplicados.Count == 1 && cola.Count == 1 && maximaProfundidad == 1,
            "El refresco fue recursivo o perdió las solicitudes recibidas durante su aplicación.");
        cola.Dequeue()();
        Exige(aplicados.Count == 2 && maximaProfundidad == 1 && cola.Count == 0 &&
            aplicados[1] == (MYGTipoRefresco.Estructura | MYGTipoRefresco.Calculos),
            "El segundo mensaje no aplicó exactamente los cambios reentrantes pendientes.");
        pasa("Solicitudes durante un refresco se agrupan en el siguiente mensaje sin recursión");

        aplicados.Clear();
        refresco.Solicitar(MYGTipoRefresco.Calculos);
        refresco.Cancelar();
        cola.Dequeue()();
        refresco.Solicitar(MYGTipoRefresco.Estructura);
        refresco.Reintentar();
        Exige(aplicados.Count == 0 && cola.Count == 0,
            "Cerrar la interfaz permitió ejecutar callbacks previos o admitir cambios nuevos.");
        pasa("Cancelar al cerrar convierte mensajes pendientes en inocuos y rechaza nuevas solicitudes");

        bool fallarCola = true;
        var recuperable = new MYGRefrescoDiferido(accion =>
        {
            if (fallarCola) throw new InvalidOperationException("Cola no disponible");
            cola.Enqueue(accion);
        }, () => true, aplicados.Add);
        bool rechazo = false;
        try { recuperable.Solicitar(MYGTipoRefresco.Estructura); }
        catch (InvalidOperationException) { rechazo = true; }
        Exige(rechazo && cola.Count == 0, "No se detectó el rechazo de la cola.");
        fallarCola = false;
        recuperable.Solicitar(MYGTipoRefresco.Calculos);
        Exige(cola.Count == 1, "El rechazo dejó permanentemente marcado el refresco como programado.");
        cola.Dequeue()();
        Exige(aplicados.Count == 1 &&
            aplicados[0] == (MYGTipoRefresco.Estructura | MYGTipoRefresco.Calculos),
            "Una cola rechazada perdió solicitudes anteriores.");
        pasa("Rechazo de la cola conserva cambios y permite programar de nuevo tras recuperar disponibilidad");
    }
}
