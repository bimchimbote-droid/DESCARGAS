using System;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ContenidoPartidaCheck
{
    private static void Exige(bool condicion, string detalle) { if (!condicion) throw new Exception(detalle); }
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var datos = new MYGDatosPartida();
        Exige(!MYGContenidoPartida.TieneEspecificacionGuardada(null) && !MYGContenidoPartida.TieneEspecificacionGuardada(datos),
            "Una partida sin especificación no debe activar su indicador.");
        foreach (string vacio in new[] { " ", @"{\rtf1\ansi{\fonttbl{\f0 Arial;}}{\colortbl;\red0\green0\blue0;}\f0\fs22\par}",
            @"{\rtf1{\info{\title Sólo metadatos}}{\*\generator MYG;}\uc1\u32?\par}",
            @"{\rtf1{\*\info {\pict\pngblip 89504E47}}\par}",
            MYGEspecificacionesPagina.Guardar(@"{\rtf1\ansi\par}", new MYGPaginaEspecificacion { Encabezado = "Sólo configuración" }) })
        {
            datos.EspecificacionRtf = vacio;
            Exige(!MYGContenidoPartida.TieneEspecificacionGuardada(datos), "RTF vacío, formato o metadatos activaron el indicador.");
        }
        foreach (string contenido in new[] { @"{\rtf1\ansi Especificación\par}", @"{\rtf1\uc1\u233?}",
            @"{\rtf1\'e9}", @"{\rtf1{\pict\pngblip 89504E47}}", @"{\rtf1{\*\shppict{\pict\pngblip 89504E47}}}", @"{\rtf1\bullet}" })
        {
            datos.EspecificacionRtf = contenido;
            Exige(MYGContenidoPartida.TieneEspecificacionGuardada(datos), "El texto o imagen guardados no activaron el indicador.");
        }
        datos.EspecificacionRtf = ""; datos.EspecificacionTexto = "Descripción";
        Exige(MYGContenidoPartida.TieneEspecificacionGuardada(datos), "La especificación de texto de documentos anteriores debe reconocerse.");
        datos.EspecificacionEsBorrador = true;
        Exige(!MYGContenidoPartida.TieneEspecificacionGuardada(datos), "El título inicial en borrador no debe activar el indicador.");
        Exige(MYGContenidoPartida.TieneEspecificacionGuardada(JsonSerializer.Deserialize<MYGDatosPartida>("{\"EspecificacionTexto\":\"Texto anterior\"}")),
            "La ausencia del flag en documentos anteriores no debe ocultar especificaciones guardadas.");
        pasa("Indicador de especificación reconoce texto e imágenes guardadas y omite borradores, RTF vacío y metadatos");

        foreach (string id in new[] { MYGPlantillasMetrado.Estandar, MYGPlantillasMetrado.Aceros })
        {
            datos = new MYGDatosPartida { Hoja = MYGPlantillasMetrado.Crear(id), FuenteMetrado = MYGFuenteMetrado.Excel };
            string antes = JsonSerializer.Serialize(datos);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Seleccionar una plantilla vacía no debe activar el indicador XLS.");
            datos.Hoja.Celdas["A2"].ColorTexto = "FF0000";
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Cambiar formato no constituye un metrado.");
            foreach (string contenido in new[] { "Descripción", "0", "=1-1", "=SUM(B3:F3)" })
            {
                datos.Hoja.Poner("A3", contenido);
                Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "Una entrada real, incluso cero o una fórmula, debe activar XLS.");
                datos.Hoja.Celdas.Remove("A3");
                Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Eliminar el último dato debe apagar XLS.");
            }
            datos.Hoja = MYGPlantillasMetrado.Crear(id);
            MYGEdicionHoja.InsertarFilas(datos.Hoja, 1, 2);
            MYGEdicionHoja.InsertarColumnas(datos.Hoja, 1, 2);
            MYGEdicionHoja.InsertarFilas(datos.Hoja, 7);
            MYGEdicionHoja.InsertarColumnas(datos.Hoja, 5);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Insertar filas y columnas en una plantilla vacía no debe inventar metrado.");
            datos.Hoja.Poner("C5", "Metrado registrado"); datos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
            Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "XLS debe conservarse aunque la cantidad use otra fuente.");
            datos.Hoja.Celdas.Remove("C5");
            MYGEdicionHoja.EliminarColumnas(datos.Hoja, 6);
            MYGEdicionHoja.EliminarFilas(datos.Hoja, 7);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Eliminar estructura vacía y sus referencias no debe activar XLS.");
            datos.Hoja = MYGPlantillasMetrado.Crear(id);
            MYGEdicionHoja.EliminarColumnas(datos.Hoja, id == MYGPlantillasMetrado.Estandar ? 2 : 4);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Las referencias rotas por eliminar columnas automáticas no son datos ingresados.");
            datos = new MYGDatosPartida { Hoja = MYGPlantillasMetrado.Crear(id), FuenteMetrado = MYGFuenteMetrado.Excel };
            Exige(JsonSerializer.Serialize(datos) == antes && !MYGContenidoPartida.TieneMetradoExcel(datos) && JsonSerializer.Serialize(datos) == antes,
                "Consultar presencia debe ser sólo lectura.");
        }
        pasa("Presencia de metrado XLS omite plantillas estándar/aceros vacías y cambios de formato o estructura; reconoce cero, texto y fórmulas sin calcularlos");

        AceroConfigurado(pasa);

        datos = new MYGDatosPartida { Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros) };
        datos.Hoja.Poner("I15", "0.100");
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "Un peso por metro editado debe contar como metrado de usuario.");
        datos.Hoja = new MYGHojaMetrado();
        Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Una hoja importada sin contenido no debe activar XLS.");
        datos.Hoja.Poner("B3", "=1/0");
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "Una hoja importada con fórmula debe activar XLS sin ejecutarla.");
        datos.Hoja = MYGHojaMetrado.Crear(); datos.Hoja.IdPlantilla = ""; datos.Hoja.RangoCuerpoPlantilla = null;
        Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Una plantilla estándar anterior no debe confundirse con metrado ingresado.");
        datos.Hoja.Poner("B3", "2");
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos) && !MYGContenidoPartida.TieneMetradoExcel(null),
            "Debe reconocer contenido de hojas anteriores y admitir datos ausentes.");
        pasa("Presencia de metrado XLS reconoce pesos editados, hojas importadas y documentos anteriores y conserva contenido al cambiar la fuente de cantidad");

        var presupuesto = new MYGPresupuestoDocumento { Nombre = "INDICADOR DE METRADO ACTIVO" };
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        datos = partida.Costos;
        Exige(!MYGContenidoPartida.TieneMetradoExcelActivo(null) && !MYGContenidoPartida.TieneMetradoExcelActivo(datos),
            "Una partida sin metrado actualizado no debe activar el indicador Excel.");
        datos.FuenteMetrado = MYGFuenteMetrado.Excel;
        Exige(!MYGContenidoPartida.TieneMetradoExcelActivo(datos), "Elegir Excel sin contenido no debe activar el indicador.");
        datos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        datos.Hoja.Poner("A3", "Metrado conservado");
        datos.Hoja.Poner("G16", "1");
        datos.Metrados.Add(new() { Descripcion = "Manual conservado", Elementos = 1, CantidadPorElemento = 3 });
        datos.MetradosBIM.Add(new() { ActivoId = "ACTIVO-1", DocumentoId = "MODELO-1", Unidad = "und", Cantidad = 4 });
        var hoja = datos.Hoja; var manual = datos.Metrados; var bim = datos.MetradosBIM;
        string contenidoFuentes = JsonSerializer.Serialize(new { hoja, manual, bim });
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos) && !MYGContenidoPartida.TieneMetradoExcelActivo(datos),
            "La presencia de datos Excel no debe mostrar un vínculo que aún no se ha actualizado.");
        Exige(MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && MYGContenidoPartida.TieneMetradoExcelActivo(datos) &&
            MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 1,
            "Actualizar Excel debe vincular su cantidad y activar el indicador.");
        foreach (decimal cantidadDirecta in new[] { 2m, 1m })
        {
            MYGEdicionPartida.CambiarCantidad(presupuesto, partida, cantidadDirecta);
            Exige(datos.FuenteMetrado == MYGFuenteMetrado.Cantidad && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == cantidadDirecta &&
                !MYGContenidoPartida.TieneMetradoExcelActivo(datos) && MYGContenidoPartida.TieneMetradoExcel(datos),
                "Editar una cantidad directa debe ocultar el indicador incluso si coincide con el total de Excel.");
            Exige(ReferenceEquals(hoja, datos.Hoja) && ReferenceEquals(manual, datos.Metrados) && ReferenceEquals(bim, datos.MetradosBIM) &&
                JsonSerializer.Serialize(new { hoja, manual, bim }) == contenidoFuentes,
                "Ocultar el indicador tras editar la cantidad no debe borrar ni sustituir las fuentes de metrado.");
            Exige(MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && MYGContenidoPartida.TieneMetradoExcelActivo(datos) &&
                MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 1 && JsonSerializer.Serialize(new { hoja, manual, bim }) == contenidoFuentes,
                "Actualizar de nuevo debe recuperar el indicador y la cantidad Excel manteniendo los datos anteriores.");
        }
        foreach (var fuente in new[] { MYGFuenteMetrado.Manual, MYGFuenteMetrado.BIM })
        {
            datos.FuenteMetrado = fuente;
            Exige(!MYGContenidoPartida.TieneMetradoExcelActivo(datos) && MYGContenidoPartida.TieneMetradoExcel(datos) &&
                MYGMotorPresupuestos.Cantidad(presupuesto, partida) == (fuente == MYGFuenteMetrado.Manual ? 3 : 4),
                "Elegir Manual o BIM debe ocultar el indicador Excel conservando la hoja.");
            Exige(MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && MYGContenidoPartida.TieneMetradoExcelActivo(datos) &&
                JsonSerializer.Serialize(new { hoja, manual, bim }) == contenidoFuentes,
                "Actualizar desde Manual o BIM debe restaurar el indicador Excel sin perder ninguna fuente.");
        }
        pasa("Indicador XLS refleja el vínculo activo: Actualizar lo muestra, editar cantidad lo oculta incluso con el mismo valor y conserva las fuentes al reactivar Excel");
    }

    private static void AceroConfigurado(Action<string> pasa)
    {
        var parametros = new MYGParametrosPredeterminados { UnidadAcero = "t" };
        parametros.Aceros[0].PesoPorMetro = .123m;
        parametros.Aceros[0].Gancho = .42m;
        parametros.Aceros[0].Empalme = .75m;
        parametros.Aceros[0].DesperdicioPorcentaje = 7m;
        var datos = new MYGDatosPartida { Hoja = parametros.CrearHojaAcero(), FuenteMetrado = MYGFuenteMetrado.Excel };
        string inicial = JsonSerializer.Serialize(datos);
        Exige(datos.Hoja.ContenidoInicialPlantilla != null && !MYGContenidoPartida.TieneMetradoExcel(datos) &&
            !MYGContenidoPartida.TieneMetradoExcelActivo(datos) &&
            MYGContenidoPartida.FilasVaciasPlantilla(datos.Hoja).SequenceEqual(Enumerable.Range(3, 11)),
            "Los parámetros automáticos de acero no deben activar XLS ni ocupar las filas vacías del reporte.");
        Exige(JsonSerializer.Serialize(datos) == inicial, "Consultar una plantilla configurada debe conservar el documento sin cambios.");
        datos = JsonSerializer.Deserialize<MYGDatosPartida>(inicial);
        parametros.Aceros[0].PesoPorMetro = 9m;
        Exige(!MYGContenidoPartida.TieneMetradoExcel(datos) && datos.Hoja.Celdas["I15"].Contenido == "0.123",
            "Abrir una hoja de acero debe conservar su contenido inicial independientemente de las preferencias actuales.");
        foreach (var entrada in new[] { ("A3", "Metrado real"), ("B3", "0"), ("D3", "4mm"), ("F3", "=1-1") })
        {
            string anterior = datos.Hoja.Celdas.TryGetValue(entrada.Item1, out var celda) ? celda.Contenido : null;
            MYGEdicionHoja.Celda(datos.Hoja, entrada.Item1).Contenido = entrada.Item2;
            Exige(MYGContenidoPartida.TieneMetradoExcelActivo(datos) &&
                !MYGContenidoPartida.FilasVaciasPlantilla(datos.Hoja).Contains(3),
                "Una entrada real en acero, incluso cero o una fórmula, debe activar XLS y conservar su fila al imprimir.");
            if (anterior == null) datos.Hoja.Celdas.Remove(entrada.Item1);
            else datos.Hoja.Celdas[entrada.Item1].Contenido = anterior;
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Restaurar el contenido automático debe apagar el indicador XLS.");
        }
        datos.Hoja.Celdas["I15"].Contenido = "0.124";
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "Cambiar un peso configurado después de crear la hoja debe contar como contenido del usuario.");
        datos.Hoja.Celdas["I15"].Contenido = "0.123";
        MYGEdicionHoja.InsertarFilas(datos.Hoja, 1, 2);
        MYGEdicionHoja.InsertarColumnas(datos.Hoja, 1, 2);
        MYGEdicionHoja.InsertarFilas(datos.Hoja, 7);
        MYGEdicionHoja.InsertarColumnas(datos.Hoja, 5);
        Exige(!MYGContenidoPartida.TieneMetradoExcel(datos) && MYGContenidoPartida.FilasVaciasPlantilla(datos.Hoja).Count == 12,
            "Desplazar filas y columnas de una plantilla de acero configurada no debe inventar metrados.");
        datos.Hoja.Poner("C5", "Metrado desplazado");
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos) && !MYGContenidoPartida.FilasVaciasPlantilla(datos.Hoja).Contains(5),
            "Una entrada en la plantilla desplazada debe conservarse al imprimir.");
        datos.Hoja.Celdas.Remove("C5");
        MYGEdicionHoja.EliminarColumnas(datos.Hoja, 6);
        MYGEdicionHoja.EliminarFilas(datos.Hoja, 7);
        Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Eliminar estructura automática debe conservar vacía la plantilla configurada.");
        pasa("Plantillas de acero configuradas conservan su base al reabrir y editar estructura; XLS y reporte sólo reconocen entradas reales");
    }
}
