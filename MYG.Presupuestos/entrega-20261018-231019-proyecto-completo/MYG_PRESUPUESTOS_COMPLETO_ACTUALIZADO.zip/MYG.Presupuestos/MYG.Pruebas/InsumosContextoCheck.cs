using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

static class InsumosContextoCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new Exception("La lista de insumos aceptó un ámbito o monedas incompatibles.");
    }

    private static ItemPresupuestoDelphin Nodo(MYGPresupuestoDocumento p, string id, string padre = null, bool titulo = false,
        decimal cantidad = 1m)
    {
        var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, ParentId = padre,
            TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Descripcion = id, Unidad = titulo ? "" : "und" };
        i.Costos.Cantidad = cantidad; p.Items.Add(i); return i;
    }

    private static MYGInsumo Insumo(MYGPresupuestoDocumento p, string codigo, string descripcion, string unidad,
        decimal precio, MYGGrupoRecurso grupo, string proveedor = "PROVEEDOR A")
    {
        var i = new MYGInsumo { Codigo = codigo, Descripcion = descripcion, Unidad = unidad, Precio = precio,
            Grupo = grupo, Proveedor = proveedor };
        p.Costos.Insumos.Add(i); return i;
    }

    private static void Recurso(ItemPresupuestoDelphin partida, MYGInsumo insumo, decimal cantidad) =>
        partida.Costos.Analisis.Add(new() { InsumoId = insumo.Id, Grupo = insumo.Grupo, Cantidad = cantidad });

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "PRESUPUESTO 1", Item = "01" };
        var t1 = Nodo(p, "T1", titulo: true);
        Nodo(p, "T11", "T1", titulo: true);
        var a = Nodo(p, "A", "T1", cantidad: 2);
        var b = Nodo(p, "B", "T11", cantidad: 3);
        Nodo(p, "T2", titulo: true);
        var fuera = Nodo(p, "FUERA", "T2", cantidad: 4);
        var mo = Insumo(p, "MO1", "OPERARIO", "hh", 10, MYGGrupoRecurso.ManoObra);
        var material = Insumo(p, "MA1", "ARENA", "m3", 3, MYGGrupoRecurso.Materiales);
        var cero = Insumo(p, "MO0", "PEÓN REFERENCIADO SIN CANTIDAD", "hh", 12, MYGGrupoRecurso.ManoObra);
        Insumo(p, "SINUSO", "CATÁLOGO SIN USO", "und", 100, MYGGrupoRecurso.Materiales);
        Recurso(a, mo, 1); Recurso(a, material, 2); Recurso(a, cero, 0); Recurso(b, mo, 2); Recurso(fuera, material, 1);
        a.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = fuera.IdLocalMYG, Cantidad = .5m });
        MYGProyectoStorage.ValidarPresupuesto(p);
        string original = Firma(p);
        var titulo = MYGListaInsumosContexto.Crear(new[] { p }, p, t1);
        Exige(titulo.Sum(i => i.Total) == 95 && titulo.Single(i => i.Codigo == "MO1").Cantidad == 8 &&
            titulo.Single(i => i.Codigo == "MA1").Cantidad == 5 && titulo.Single(i => i.Codigo == "MO0").Total == 0 &&
            titulo.All(i => i.Codigo != "SINUSO"),
            "El título no limitó las partidas a su rama, perdió un subanálisis o no distinguió ceros referenciados del catálogo sin uso.");
        var presupuesto = MYGListaInsumosContexto.Crear(new[] { p }, p);
        Exige(presupuesto.Sum(i => i.Total) == 107 && presupuesto.Single(i => i.Codigo == "MA1").Cantidad == 9 &&
            presupuesto.Sum(i => i.Total) == MYGMotorPresupuestos.Resumen(p).CostoDirecto && Firma(p) == original,
            "La lista del presupuesto duplicó subanálisis o modificó los modelos al calcular.");
        pasa("Lista contextual limita títulos a sus descendientes, expande subanálisis una vez por uso y conserva ceros referenciados sin incluir catálogo sin uso");

        var p2 = new MYGPresupuestoDocumento { Nombre = "PRESUPUESTO 2", Item = "02" };
        var otra = Nodo(p2, "OTRA");
        Recurso(otra, Insumo(p2, "MO1", "OPERARIO", "hh", 10, MYGGrupoRecurso.ManoObra), 1);
        Recurso(otra, Insumo(p2, "MO1", "OPERARIO", "hh", 10, MYGGrupoRecurso.ManoObra, "PROVEEDOR B"), 1);
        Recurso(otra, Insumo(p2, "MO1", "OPERARIO", "día", 10, MYGGrupoRecurso.ManoObra), 1);
        Recurso(otra, Insumo(p2, "MO1", "OPERARIO", "hh", 11, MYGGrupoRecurso.ManoObra), 1);
        Recurso(otra, Insumo(p2, "MO1", "OTRA DESCRIPCIÓN", "hh", 10, MYGGrupoRecurso.ManoObra), 1);
        MYGProyectoStorage.ValidarPresupuesto(p2);
        string original2 = Firma(p2);
        // El ámbito de proyecto ignora la selección de título de la otra pestaña.
        var proyecto = MYGListaInsumosContexto.Crear(new[] { p, p2 }, titulo: t1);
        var iguales = proyecto.Where(i => i.Codigo == "MO1").ToArray();
        Exige(iguales.Length == 5 && iguales.Single(i => i.Descripcion == "OPERARIO" && i.Unidad == "hh" &&
            i.Precio == 10 && i.Proveedor == "PROVEEDOR A").Cantidad == 9 && proyecto.Sum(i => i.Total) == 158 &&
            Firma(p) == original && Firma(p2) == original2,
            "El proyecto mezcló precios, unidades, descripciones o proveedores distintos o conservó indebidamente el título activo.");
        var vacio = new MYGPresupuestoDocumento { Nombre = "VACÍO" };
        Exige(MYGListaInsumosContexto.Crear(new[] { vacio }).Count == 0 &&
            MYGListaInsumosContexto.Crear(Array.Empty<MYGPresupuestoDocumento>()).Count == 0,
            "Un proyecto o presupuesto vacío generó insumos artificiales.");
        pasa("Lista del proyecto agrupa recursos equivalentes entre presupuestos y separa diferencias de proveedor, unidad, precio y descripción, con entradas vacías seguras");

        var redondeo = new MYGPresupuestoDocumento { Nombre = "IGV Y REDONDEO" };
        redondeo.Costos.ConfiguracionCostoDirecto = new() { IncluirIgvMateriales = true };
        var fraccion = Nodo(redondeo, "FRACCIÓN", cantidad: 1.07m);
        var gravado = Insumo(redondeo, "GRAVADO", "MATERIAL CON IGV", "kg", .21m, MYGGrupoRecurso.Materiales);
        gravado.IGVPorcentaje = 18;
        Recurso(fraccion, gravado, .3333m);
        var porcentaje = Insumo(redondeo, "HM", "HERRAMIENTAS", "%mo", 0, MYGGrupoRecurso.Equipo);
        var obrero = Insumo(redondeo, "OBR", "OBRERO", "hh", 2, MYGGrupoRecurso.ManoObra);
        Recurso(fraccion, obrero, 1);
        fraccion.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Equipo, InsumoId = porcentaje.Id,
            Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 5 });
        var directo = Nodo(redondeo, "DIRECTO", cantidad: 2); directo.Costos.PrecioDirecto = 7.45m;
        MYGProyectoStorage.ValidarPresupuesto(redondeo);
        var originales = MYGMotorPresupuestos.Consolidar(redondeo);
        var filas = MYGListaInsumosContexto.Crear(new[] { redondeo }, redondeo);
        Exige(filas.Single(i => i.Codigo == "GRAVADO").Precio == .2478m &&
            filas.Single(i => i.Codigo == "GRAVADO").Cantidad == .356631m &&
            filas.Single(i => i.Codigo == "HM").Total == .11m &&
            filas.Any(i => i.Descripcion == "Ajuste por redondeo") &&
            filas.All(i => i.Grupo != MYGGrupoRecurso.Subcontratos && i.Codigo != "DIRECTO") &&
            filas.Sum(i => i.Total) == originales.Where(i => !i.Clave.StartsWith("DIRECTO:", StringComparison.Ordinal)).Sum(i => i.Total) &&
            filas.Sum(i => i.Total) + 14.9m == MYGMotorPresupuestos.Resumen(redondeo).CostoDirecto,
            "La lista alteró IGV, porcentajes o redondeos, o convirtió una partida sin ACU en un insumo.");
        pasa("Lista contextual conserva IGV, coeficientes, porcentajes y redondeos reales sin clasificar precios directos como subcontratos");

        var importado = new MYGPresupuestoDocumento { Nombre = "PARCIAL NATIVO" };
        var nativa = Nodo(importado, "NATIVA", cantidad: 3);
        nativa.Costos.PrecioDirecto = 1.11m; nativa.Costos.PrecioImportadoDelphin = 1.11m;
        nativa.Costos.CantidadImportadaDelphin = 3; nativa.Costos.ParcialImportadoDelphin = 3.34m;
        nativa.Costos.FirmaAnalisisImportadoDelphin = MYGMotorPresupuestos.FirmaAnalisis(importado, nativa);
        string firmaImportado = Firma(importado);
        var filasImportadas = MYGListaInsumosContexto.Crear(new[] { importado });
        Exige(filasImportadas.Count == 0 && MYGMotorPresupuestos.Resumen(importado).CostoDirecto == 3.34m &&
            Firma(importado) == firmaImportado,
            "Una partida importada sin ACU fabricó insumos/ajustes o perdió su parcial nativo al consultar.");
        pasa("Partida importada sin ACU conserva su parcial nativo en el presupuesto y no fabrica insumos ni ajustes en la lista");

        var sinAcu = new MYGPresupuestoDocumento { Nombre = "PARTIDAS SIN INSUMOS" };
        var raizSinAcu = Nodo(sinAcu, "TÍTULO SIN ACU", titulo: true);
        Nodo(sinAcu, "VACÍA CON METRADO", raizSinAcu.Id, cantidad: 4);
        var conPrecio = Nodo(sinAcu, "PRECIO SIN ANÁLISIS", raizSinAcu.Id, cantidad: 2);
        conPrecio.Costos.PrecioDirecto = 5;
        var subDirecta = Nodo(sinAcu, "SUBPARTIDA SIN ACU", cantidad: 0);
        subDirecta.Costos.PrecioDirecto = 7;
        var compuesta = Nodo(sinAcu, "REFERENCIA SIN INSUMOS", raizSinAcu.Id, cantidad: 3);
        compuesta.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas,
            SubpartidaIdLocal = subDirecta.IdLocalMYG, Cantidad = .3333m });
        MYGProyectoStorage.ValidarPresupuesto(sinAcu);
        string firmaSinAcu = Firma(sinAcu);
        Exige(MYGListaInsumosContexto.Crear(new[] { sinAcu }, sinAcu).Count == 0 &&
            MYGListaInsumosContexto.Crear(new[] { sinAcu }, sinAcu, raizSinAcu).Count == 0 &&
            MYGListaInsumosContexto.Crear(new[] { sinAcu }).Count == 0 &&
            MYGMotorPresupuestos.Resumen(sinAcu).CostoDirecto == 16.99m && Firma(sinAcu) == firmaSinAcu,
            "Una partida vacía, de precio directo o subpartida sin recursos generó insumos, subcontratos o redondeos ficticios.");
        pasa("Listas de título, presupuesto y proyecto omiten partidas sin ACU incluso con metrado, precio o referencias a subpartidas sin recursos");

        var mixto = new MYGPresupuestoDocumento { Nombre = "INSUMOS REALES Y PRECIOS DIRECTOS" };
        var directaMixta = Nodo(mixto, "PRECIO DIRECTO MIXTO", cantidad: 0);
        directaMixta.Costos.PrecioDirecto = 10;
        var mezcla = Nodo(mixto, "PARTIDA MIXTA", cantidad: 2);
        var contratoReal = Insumo(mixto, "SC-REAL", "SUBCONTRATO REGISTRADO", "und", 8, MYGGrupoRecurso.Subcontratos);
        Recurso(mezcla, contratoReal, 3);
        mezcla.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas,
            SubpartidaIdLocal = directaMixta.IdLocalMYG, Cantidad = 1 });
        MYGMotorPresupuestos.CapturarPrecioDelphin(mixto, mezcla, 34, 68.01m);
        string firmaMixto = Firma(mixto);
        var listaMixta = MYGListaInsumosContexto.Crear(new[] { mixto });
        Exige(listaMixta.Single(i => i.Grupo == MYGGrupoRecurso.Subcontratos).Codigo == "SC-REAL" &&
            listaMixta.Single(i => i.Codigo == "SC-REAL").Cantidad == 6 &&
            listaMixta.Single(i => i.Codigo == "SC-REAL").Total == 48 &&
            listaMixta.Single(i => i.Descripcion == "Ajuste por redondeo importado").Total == .01m &&
            listaMixta.Sum(i => i.Total) == 48.01m && Firma(mixto) == firmaMixto,
            "Se ocultó un subcontrato real o el costo de una subpartida directa reapareció como ajuste ficticio.");
        var incidenciaMixta = MYGPiePresupuesto.Incidencia(new[] { mixto });
        Exige(incidenciaMixta.Single(i => i.Nombre == "SUBCONTRATOS").Importe == 48.01m &&
            incidenciaMixta.Single(i => i.Nombre == "SIN DESGLOSE").Importe == 20 &&
            incidenciaMixta.Sum(i => i.Importe) == 68.01m,
            "Filtrar la lista contextual alteró el costo o la clasificación del gráfico de incidencia.");
        pasa("Subcontratos explícitos y ajustes nativos reales se conservan; una subpartida de precio directo no reaparece como insumo ni ajuste");

        var prefijo = new MYGPresupuestoDocumento { Nombre = "IDENTIDAD DE INSUMO" };
        var partidaPrefijo = Nodo(prefijo, "PARTIDA CON INSUMO REAL", cantidad: 2);
        var insumoPrefijo = Insumo(prefijo, "MAT-REAL", "MATERIAL CON ID HEREDADO", "kg", 4, MYGGrupoRecurso.Materiales);
        insumoPrefijo.Id = "DIRECTO:PROVEEDOR-1";
        Recurso(partidaPrefijo, insumoPrefijo, 3);
        MYGProyectoStorage.ValidarPresupuesto(prefijo);
        var listaPrefijo = MYGListaInsumosContexto.Crear(new[] { prefijo });
        Exige(listaPrefijo.Count == 1 && listaPrefijo.Single().Codigo == "MAT-REAL" &&
            listaPrefijo.Single().Cantidad == 6 && listaPrefijo.Single().Total == 24,
            "El prefijo del identificador de un insumo real lo confundió con una partida sin desglose.");
        pasa("Insumos reales conservan cantidades e importes aunque su identificador heredado use el prefijo DIRECTO");

        p2.Costos.Moneda = "USD";
        Rechaza(() => MYGListaInsumosContexto.Crear(new[] { p, p2 }));
        Exige(MYGListaInsumosContexto.Crear(new[] { p, p2 }, p).Sum(i => i.Total) == 107,
            "Las monedas de otros presupuestos impidieron consultar el presupuesto seleccionado.");
        Rechaza(() => MYGListaInsumosContexto.Crear(new[] { p }, p, otra));
        Rechaza(() => MYGListaInsumosContexto.Crear(new[] { p }, p, a));
        pasa("Lista contextual rechaza sumar monedas distintas y selecciones ajenas o que no sean títulos sin bloquear el presupuesto individual");
    }
}
