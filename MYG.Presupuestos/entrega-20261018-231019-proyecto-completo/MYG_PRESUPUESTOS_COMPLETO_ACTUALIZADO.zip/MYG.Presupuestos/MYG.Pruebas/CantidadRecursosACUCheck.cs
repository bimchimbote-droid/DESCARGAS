using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class CantidadRecursosACUCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza<T>(Action accion, string mensaje) where T : Exception
    {
        try { accion(); }
        catch (T error) when (!string.IsNullOrWhiteSpace(error.Message)) { return; }
        throw new Exception(mensaje);
    }

    private static ItemPresupuestoDelphin Partida(MYGPresupuestoDocumento presupuesto, string descripcion, string unidad = "m²")
    {
        string id = MYGProyectoStorage.NuevoId();
        var partida = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = (presupuesto.Items.Count + 1).ToString("00"),
            Descripcion = descripcion, Unidad = unidad, Posicion = presupuesto.Items.Count + 1, TipoPropuesta = "PARTIDA" };
        presupuesto.Items.Add(partida);
        return partida;
    }

    private static MYGRecursoACU Recurso(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida,
        string unidad, MYGGrupoRecurso grupo, decimal precio, MYGModoCantidad modo, decimal cantidad, decimal numeroRecursos,
        bool calcularPorUnidad = true)
    {
        var insumo = new MYGInsumo { Codigo = "QA-" + presupuesto.Costos.Insumos.Count,
            Descripcion = "RECURSO " + unidad + " QA", Unidad = unidad, Grupo = grupo, Precio = precio };
        presupuesto.Costos.Insumos.Add(insumo);
        var recurso = new MYGRecursoACU { InsumoId = insumo.Id, Grupo = grupo, Modo = modo,
            Cantidad = cantidad, NumeroRecursos = numeroRecursos, CalcularCantidadPorUnidad = calcularPorUnidad };
        partida.Costos.Analisis.Add(recurso);
        return recurso;
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        UnidadesYModos(pasa);
        FormulaYValidacion(pasa);
        MotorRendimiento(pasa);
        CeroYEdicion(pasa);
        ConsumosManuales(pasa);
        InsercionYReemplazo(pasa);
        CompatibilidadAnterior(pasa);
        PreciosImportadosDescendientes(carpeta, pasa);
        Persistencia(carpeta, pasa);
    }

    private static void UnidadesYModos(Action<string> pasa)
    {
        foreach (string unidad in new[] { "he", "HH", "Hm", " hE ", "\tHH\r\n", " hm " })
            Exige(MYGCalculoCantidadRecursoACU.EsUnidadPorRecursos(unidad),
                "La unidad he/hh/hm debe reconocer mayúsculas y espacios exteriores: " + unidad);
        foreach (string unidad in new[] { null, "", " ", "kg", "und", "hor", "hom", "dia", "%mo", "h", "hh/m²", "h h", "h.e", "hect", "hm2" })
            Exige(!MYGCalculoCantidadRecursoACU.EsUnidadPorRecursos(unidad),
                "Sólo las tres unidades exactas deben activar N° Recursos: " + unidad);
        foreach (var grupo in Enum.GetValues<MYGGrupoRecurso>())
        foreach (var modo in Enum.GetValues<MYGModoCantidad>())
        {
            var recurso = new MYGRecursoACU { Grupo = grupo, Modo = modo };
            bool esperado = grupo != MYGGrupoRecurso.Subpartidas && modo != MYGModoCantidad.PorcentajeManoObra;
            Exige(MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(recurso, " HH ") == esperado &&
                !MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(recurso, "hor"),
                "La unidad debe determinar N° Recursos salvo subpartidas y porcentaje de mano de obra, sin activar alias de hora.");
        }
        Exige(!MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(null, "hh"), "Un recurso ausente no debe habilitar N° Recursos.");
        pasa("N° Recursos reconoce únicamente he/hh/hm con espacios y mayúsculas, excluyendo subpartidas y porcentaje MO");
    }

    private static void FormulaYValidacion(Action<string> pasa)
    {
        var datos = new MYGDatosPartida { RendimientoDiario = 13.7m, JornadaHoras = 8m };
        string antes = JsonSerializer.Serialize(datos);
        Exige(MYGCalculoCantidadRecursoACU.Calcular(datos, 2.125m) == 3.6390625m &&
            MYGCalculoCantidadRecursoACU.Calcular(datos, 0) == 0 && JsonSerializer.Serialize(datos) == antes,
            "Cantidad debe ser Rendimiento/Jornada por N° Recursos, con precisión completa, cero permitido y sin cambiar datos.");
        datos.RendimientoDiario = 1; datos.JornadaHoras = 3;
        Exige(MYGCalculoCantidadRecursoACU.Calcular(datos, 2) == 0.6666666666666666666666666666m,
            "El cálculo base debe conservar la precisión decimal y no redondear el cociente antes de multiplicar los recursos.");
        foreach (var valores in new[] { (0m, 8m), (-1m, 8m), (1m, 0m), (1m, -8m) })
        {
            var invalido = new MYGDatosPartida { RendimientoDiario = valores.Item1, JornadaHoras = valores.Item2 };
            string invalidoAntes = JsonSerializer.Serialize(invalido);
            Rechaza<InvalidDataException>(() => MYGCalculoCantidadRecursoACU.Calcular(invalido, 0),
                "Rendimiento y jornada deben ser positivos incluso con cero recursos.");
            Exige(JsonSerializer.Serialize(invalido) == invalidoAntes, "Rechazar un cálculo inválido no debe modificar sus datos.");
        }
        Rechaza<InvalidDataException>(() => MYGCalculoCantidadRecursoACU.Calcular(datos, -0.001m),
            "El cálculo no debe aceptar N° Recursos negativo.");
        Rechaza<ArgumentNullException>(() => MYGCalculoCantidadRecursoACU.Calcular(null, 1),
            "El cálculo debe rechazar datos ausentes con un error claro.");
        pasa("Cantidad usa Rendimiento/Jornada por N° Recursos sin redondeo previo y valida jornada, rendimiento y recursos sin modificar datos");
    }

    private static void MotorRendimiento(Action<string> pasa)
    {
        foreach (var caso in new[] { ("he", MYGGrupoRecurso.Equipo),
            (" HH ", MYGGrupoRecurso.ManoObra), ("Hm", MYGGrupoRecurso.Equipo) })
        foreach (var modo in new[] { MYGModoCantidad.Rendimiento, MYGModoCantidad.Directa })
        {
            var p = new MYGPresupuestoDocumento { Nombre = "CANTIDAD RECURSOS QA", Item = "01" };
            p.Costos.DecimalesCantidad = 4; p.Costos.DecimalesPrecio = 2;
            var partida = Partida(p, "RENDIMIENTO ASIMETRICO QA");
            partida.Costos.Cantidad = 3; partida.Costos.RendimientoDiario = 13.7m; partida.Costos.JornadaHoras = 8m;
            var recurso = Recurso(p, partida, caso.Item1, caso.Item2, 17.3m, modo, 999m, 2.125m);
            recurso.DesperdicioPorcentaje = 2.5m;
            MYGProyectoStorage.ValidarPresupuesto(p);
            string antes = JsonSerializer.Serialize(p);
            var calculo = MYGMotorPresupuestos.CrearCalculo(p);
            var acu = calculo.Analizar(partida); var fila = acu.Recursos.Single();
            Exige(fila.Cantidad == 3.7300m && fila.Precio == 17.3m && fila.Total == 64.53m &&
                acu.PrecioUnitario == 64.53m && calculo.TotalPartida(partida) == 193.59m &&
                calculo.Resumen().CostoDirecto == 193.59m,
                "El motor debe usar la nueva fórmula para " + caso.Item1 + ", aplicar desperdicio una vez y luego redondear coeficiente e importes.");
            var consolidado = calculo.Consolidar(partida).Single(r => r.Clave == recurso.InsumoId);
            Exige(consolidado.Cantidad == 11.19m && consolidado.Total == 193.59m && JsonSerializer.Serialize(p) == antes,
                "El consolidado debe multiplicar el coeficiente efectivo por el metrado sin repetir desperdicio ni modificar el ACU.");

            partida.Costos.RendimientoDiario = 1.23449m; partida.Costos.JornadaHoras = 1m;
            recurso.NumeroRecursos = 1m; recurso.DesperdicioPorcentaje = 50m;
            p.Costos.Insumos.Single().Precio = 100m;
            var preciso = MYGMotorPresupuestos.CrearCalculo(p).Analizar(partida).Recursos.Single();
            Exige(preciso.Cantidad == 1.8517m && preciso.Total == 185.17m,
                "Debe aplicarse desperdicio antes del único redondeo del coeficiente; redondear 1.23449 primero produciría otro importe.");
        }
        pasa("Motor he/hh/hm activado aplica fórmula asimétrica en Directa y Rendimiento, desperdicio una sola vez y redondeo final; ACU, parcial y consolidado concilian");
    }

    private static void CeroYEdicion(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "EDICION RECURSOS QA", Item = "01" };
        var partida = Partida(p, "RECURSOS CERO Y EDICION QA");
        partida.Costos.Cantidad = 4; partida.Costos.RendimientoDiario = 5; partida.Costos.JornadaHoras = 8;
        var recurso = Recurso(p, partida, "hh", MYGGrupoRecurso.ManoObra, 10, MYGModoCantidad.Rendimiento, 999, 0);
        recurso.DesperdicioPorcentaje = 25;
        MYGProyectoStorage.ValidarPresupuesto(p);
        var cero = MYGMotorPresupuestos.CrearCalculo(p);
        Exige(cero.Analizar(partida).Recursos.Single().Cantidad == 0 && cero.Analizar(partida).PrecioUnitario == 0 &&
            cero.TotalPartida(partida) == 0, "Cero recursos debe producir cantidad e importes cero aunque la cantidad guardada tenga otro valor.");
        recurso.NumeroRecursos = 2; recurso.DesperdicioPorcentaje = 0;
        var original = MYGMotorPresupuestos.CrearCalculo(p);
        Exige(original.Analizar(partida).Recursos.Single().Cantidad == 1.25m, "La nueva sesión debe usar los recursos editados.");
        partida.Costos.RendimientoDiario = 10;
        var rendimiento = MYGMotorPresupuestos.CrearCalculo(p);
        Exige(rendimiento.Analizar(partida).Recursos.Single().Cantidad == 2.5m && rendimiento.TotalPartida(partida) == 100m &&
            original.Analizar(partida).Recursos.Single().Cantidad == 1.25m,
            "Cambiar rendimiento debe recalcular con una sesión nueva sin contaminar la sesión anterior.");
        partida.Costos.JornadaHoras = 5;
        var jornada = MYGMotorPresupuestos.CrearCalculo(p);
        Exige(jornada.Analizar(partida).Recursos.Single().Cantidad == 4m && jornada.TotalPartida(partida) == 160m && recurso.Cantidad == 999m,
            "Cambiar jornada debe actualizar el coeficiente calculado sin sobrescribir la cantidad guardada del recurso.");
        pasa("N° Recursos cero anula consumo; nuevas sesiones recalculan al editar recursos, rendimiento o jornada y conservan los datos guardados");
    }

    private static void ConsumosManuales(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "UNIDADES MANUALES QA", Item = "01" };
        var partida = Partida(p, "CONSUMOS MANUALES QA");
        partida.Costos.RendimientoDiario = 13.7m; partida.Costos.JornadaHoras = 8m;
        foreach (string unidad in new[] { "kg", "und", "hor", "hom", "dia" })
            Recurso(p, partida, unidad, MYGGrupoRecurso.Materiales, 3m, MYGModoCantidad.Directa, 2.375m, 999m);
        Recurso(p, partida, "hor", MYGGrupoRecurso.ManoObra, 20m, MYGModoCantidad.Directa, 3.125m, 999m);
        var porcentaje = Recurso(p, partida, "hm", MYGGrupoRecurso.Equipo, 999m, MYGModoCantidad.PorcentajeManoObra, 7.5m, 999m);
        var subpartida = Partida(p, "SUBPARTIDA UNIDAD HH QA", "hh"); subpartida.Costos.PrecioDirecto = 11.25m;
        var recursoSub = new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = subpartida.IdLocalMYG,
            Modo = MYGModoCantidad.Directa, Cantidad = 2.375m, NumeroRecursos = 999m, CalcularCantidadPorUnidad = true };
        partida.Costos.Analisis.Add(recursoSub);
        MYGProyectoStorage.ValidarPresupuesto(p);
        var resultado = MYGMotorPresupuestos.CrearCalculo(p).Analizar(partida);
        Exige(resultado.Recursos.Where(r => r.Recurso.Grupo == MYGGrupoRecurso.Materiales).All(r => r.Cantidad == 2.375m && r.Total == 7.13m) &&
            resultado.Recursos.Single(r => r.Recurso.Grupo == MYGGrupoRecurso.ManoObra).Cantidad == 3.125m &&
            resultado.Recursos.Single(r => r.Recurso == porcentaje) is var filaPorcentaje &&
            filaPorcentaje.Unidad == "%mo" && filaPorcentaje.Cantidad == 7.5m && filaPorcentaje.Precio == 62.50m && filaPorcentaje.Total == 4.69m &&
            resultado.Recursos.Single(r => r.Recurso == recursoSub) is var filaSub && filaSub.Cantidad == 2.375m && filaSub.Total == 26.72m,
            "kg/und/hor/hom/dia deben mantener consumos manuales; %MO y subpartidas conservan su cálculo aunque su unidad almacenada sea hm o hh.");
        string antes = JsonSerializer.Serialize(resultado);
        partida.Costos.RendimientoDiario = 29m; partida.Costos.JornadaHoras = 3m;
        Exige(JsonSerializer.Serialize(MYGMotorPresupuestos.CrearCalculo(p).Analizar(partida)) == antes,
            "Cambiar rendimiento o jornada no debe recalcular consumos manuales, porcentajes MO ni subpartidas.");
        pasa("Consumos kg/und/hor/hom/dia, porcentaje MO y subpartidas mantienen cantidades manuales y permanecen independientes del rendimiento y jornada");
    }

    private static void CompatibilidadAnterior(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "COSTOS ANTERIORES QA", Item = "01" };
        var partida = Partida(p, "ACU HH ANTERIOR QA");
        partida.Costos.Cantidad = 2; partida.Costos.RendimientoDiario = 4; partida.Costos.JornadaHoras = 8;
        Recurso(p, partida, "hh", MYGGrupoRecurso.ManoObra, 10m, MYGModoCantidad.Rendimiento, 999, 2, calcularPorUnidad: false);
        Recurso(p, partida, "hh", MYGGrupoRecurso.ManoObra, 7m, MYGModoCantidad.Directa, 2.5m, 99, calcularPorUnidad: false);
        MYGProyectoStorage.ValidarPresupuesto(p);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, partida, 57.51m, 115.03m);
        string firma = MYGMotorPresupuestos.FirmaAnalisis(p, partida);
        string jsonAnterior = JsonSerializer.Serialize(p);
        Exige(!jsonAnterior.Contains(nameof(MYGRecursoACU.CalcularCantidadPorUnidad), StringComparison.Ordinal),
            "La bandera false debe omitirse del JSON para conservar el formato y las firmas de costos anteriores.");
        var copia = JsonSerializer.Deserialize<MYGPresupuestoDocumento>(jsonAnterior);
        var original = copia.Items.Single();
        var calculo = MYGMotorPresupuestos.CrearCalculo(copia);
        Exige(original.Costos.Analisis.All(r => !r.CalcularCantidadPorUnidad) &&
            calculo.Analizar(original).Recursos.Select(r => r.Cantidad).SequenceEqual(new[] { 4m, 2.5m }) &&
            calculo.Analizar(original).Recursos.Select(r => r.Total).SequenceEqual(new[] { 40m, 17.5m }) &&
            calculo.Analizar(original).PrecioUnitario == 57.51m && calculo.TotalPartida(original) == 115.03m &&
            MYGMotorPresupuestos.FirmaAnalisis(copia, original) == firma && MYGMotorPresupuestos.ConservaAnalisisDelphin(copia, original),
            "Abrir costos HH anteriores debe conservar Rendimiento histórico, consumo Directa manual y firmas/precios/parciales importados.");
        original.Costos.Analisis[0].CalcularCantidadPorUnidad = true;
        var activado = MYGMotorPresupuestos.CrearCalculo(copia).Analizar(original);
        Exige(activado.Recursos[0].Cantidad == 1m && activado.Recursos[1].Cantidad == 2.5m && activado.PrecioUnitario == 27.5m &&
            !MYGMotorPresupuestos.ConservaAnalisisDelphin(copia, original) && MYGMotorPresupuestos.FirmaAnalisis(copia, original) != firma &&
            JsonSerializer.Serialize(p) == jsonAnterior,
            "Activar la nueva regla debe afectar sólo el recurso editado e invalidar su firma importada sin cambiar otros costos ni el documento original.");
        pasa("Costos HH anteriores conservan consumos, precios nativos y firmas; JSON omite false y activar la nueva regla afecta sólo la línea elegida");
    }

    private static void InsercionYReemplazo(Action<string> pasa)
    {
        foreach (string unidad in new[] { "he", "hh", "hm" })
        foreach (var modoOrigen in new[] { MYGModoCantidad.Rendimiento, MYGModoCantidad.Directa })
        {
            var p = new MYGPresupuestoDocumento { Nombre = "INSERTAR RECURSO HORARIO QA", Item = "01" };
            var partida = Partida(p, "INSERCION Y CAMBIO UNIDAD QA");
            partida.Costos.RendimientoDiario = 13.7m; partida.Costos.JornadaHoras = 8m;
            var horario = new MYGInsumo { Codigo = "H-QA", Descripcion = "RECURSO " + unidad,
                Unidad = unidad, Grupo = unidad == "hh" ? MYGGrupoRecurso.ManoObra : MYGGrupoRecurso.Equipo, Precio = 17.3m };
            var manual = new MYGInsumo { Codigo = "UND-QA", Descripcion = "CONSUMO MANUAL QA",
                Unidad = "und", Grupo = MYGGrupoRecurso.Materiales, Precio = 5m };
            p.Costos.Insumos.AddRange(new[] { horario, manual });
            int historial = 0;
            var agregado = MYGInsumosEdicion.Aplicar(p, partida.Id, null, new() { InsumoId = horario.Id }, antes: () => historial++);
            Exige(agregado.CalcularCantidadPorUnidad && agregado.Modo == MYGModoCantidad.Rendimiento && agregado.NumeroRecursos == 1 &&
                MYGMotorPresupuestos.CrearCalculo(p).Analizar(partida).Recursos.Single().Cantidad == 1.7125m && historial == 1,
                "Agregar " + unidad + " debe activar la nueva regla con un recurso y una sola entrada de historial.");
            agregado.NumeroRecursos = 2.125m; agregado.DesperdicioPorcentaje = 2.5m;
            agregado.Modo = modoOrigen; agregado.Cantidad = 999m;
            var consumo = MYGInsumosEdicion.Aplicar(p, partida.Id, agregado.Id, new() { InsumoId = manual.Id }, antes: () => historial++);
            var resultado = MYGMotorPresupuestos.CrearCalculo(p).Analizar(partida).Recursos.Single();
            Exige(consumo.Id == agregado.Id && consumo.Modo == MYGModoCantidad.Directa && !consumo.CalcularCantidadPorUnidad &&
                consumo.Cantidad == 3.6390625m && consumo.NumeroRecursos == 2.125m && consumo.DesperdicioPorcentaje == 2.5m &&
                resultado.Cantidad == 3.7300m && resultado.Total == 18.65m && historial == 2,
                "Reemplazar por und debe conservar el coeficiente base sin desperdicio ni redondeo previo, desactivar la regla y aplicar desperdicio una vez.");
        }
        pasa("Agregar he/hh/hm activa la nueva fórmula; reemplazar Directa/Rendimiento activados por und conserva coeficiente base y un único desperdicio");
    }

    private static decimal NumeroSql(string ruta, string consulta, string descripcion)
    {
        SQLiteDependencyBootstrapper.Initialize();
        using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        conexion.Open(); using var comando = conexion.CreateCommand();
        comando.CommandText = consulta; comando.Parameters.AddWithValue("$p0", descripcion);
        return Convert.ToDecimal(comando.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    private static void PreciosImportadosDescendientes(string carpeta, Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "SUBPARTIDAS IMPORTADAS RECURSOS QA", Item = "01" };
        var nieto = Partida(p, "NIETO HH IMPORTADO QA");
        nieto.Costos.Cantidad = 3; nieto.Costos.RendimientoDiario = 4; nieto.Costos.JornadaHoras = 8;
        var horario = Recurso(p, nieto, "hh", MYGGrupoRecurso.ManoObra, 10, MYGModoCantidad.Rendimiento, 999, 2,
            calcularPorUnidad: false);
        var padre = Partida(p, "PADRE IMPORTADO QA"); padre.Costos.Cantidad = 4;
        padre.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas,
            SubpartidaIdLocal = nieto.IdLocalMYG, Cantidad = 3 });
        var abuelo = Partida(p, "ABUELO IMPORTADO QA"); abuelo.Costos.Cantidad = 5;
        abuelo.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas,
            SubpartidaIdLocal = padre.IdLocalMYG, Cantidad = 2 });
        var titulo = Partida(p, "TITULO DESCENDIENTES IMPORTADOS QA", ""); titulo.TipoPropuesta = "TITULO";
        foreach (var partida in new[] { nieto, padre, abuelo }) partida.ParentId = titulo.Id;
        MYGProyectoStorage.ValidarPresupuesto(p);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, nieto, 40.01m, 120.07m);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, padre, 120.05m, 480.23m);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, abuelo, 240.17m, 1200.87m);
        var partidas = new[] { nieto, padre, abuelo };
        foreach (var partida in p.Items) MYGMotorPresupuestos.CapturarDatosDelphin(p, partida);
        string[] firmas = partidas.Select(i => MYGMotorPresupuestos.FirmaAnalisis(p, i)).ToArray();
        string antes = JsonSerializer.Serialize(p);
        var anterior = MYGMotorPresupuestos.CrearCalculo(p);
        Exige(partidas.All(i => MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i)) &&
            partidas.Select(i => anterior.Analizar(i).PrecioUnitario).SequenceEqual(new[] { 40.01m, 120.05m, 240.17m }) &&
            partidas.Select(anterior.TotalPartida).SequenceEqual(new[] { 120.07m, 480.23m, 1200.87m }) &&
            JsonSerializer.Serialize(p) == antes,
            "La cadena importada sin recursos activados debe conservar exactamente precios, parciales y firmas originales sin cambiar el documento.");
        string ruta = Path.Combine(carpeta, "Cadena importada con recurso horario.sqlite");
        var documento = new MYGProyectoDocumento { Nombre = "CADENA IMPORTADA PERSISTIDA QA",
            Presupuestos = new() { p }, PresupuestoActivoId = p.Id };
        MYGProyectoStorage.Guardar(ruta, documento);
        VerificarSql(new[] { 40.01m, 120.05m, 240.17m }, new[] { 120.07m, 480.23m, 1200.87m },
            new[] { 4m, 3m, 2m }, new[] { 10m, 40.01m, 120.05m }, new[] { 40m, 120.03m, 240.10m }, 1801.17m);
        Exige(p.Items.All(i => MYGMotorPresupuestos.ConservaDatosDelphin(p, i)),
            "La fixture nativa debe conservar firmas de datos importados en las tres partidas y el título antes de activar la regla.");
        horario.CalcularCantidadPorUnidad = true;
        string activadoAntes = JsonSerializer.Serialize(p);
        var actualizado = MYGMotorPresupuestos.CrearCalculo(p);
        Exige(MYGMotorPresupuestos.FirmaAnalisis(p, nieto) != firmas[0] &&
            MYGMotorPresupuestos.FirmaAnalisis(p, padre) == firmas[1] && MYGMotorPresupuestos.FirmaAnalisis(p, abuelo) == firmas[2] &&
            partidas.All(i => !MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i)) &&
            actualizado.Analizar(nieto).Recursos.Single().Cantidad == 1m &&
            partidas.Select(i => actualizado.Analizar(i).PrecioUnitario).SequenceEqual(new[] { 10m, 30m, 60m }) &&
            partidas.Select(actualizado.TotalPartida).SequenceEqual(new[] { 30m, 120m, 300m }) &&
            anterior.Analizar(abuelo).PrecioUnitario == 240.17m && JsonSerializer.Serialize(p) == activadoAntes,
            "Activar un recurso HH del nieto debe invalidar precios y parciales importados de todos sus ancestros aunque sus firmas locales sigan iguales, sin reescribir costos ni contaminar sesiones anteriores.");
        pasa("Cadena importada conserva precios legados; activar HH del nieto recalcula padre y abuelo e invalida sus parciales aunque sus firmas locales no cambien");
        Exige(p.Items.All(i => !MYGMotorPresupuestos.ConservaDatosDelphin(p, i)),
            "Los datos nativos de partidas y título no deben marcarse intactos si cambió el cálculo de un descendiente horario.");
        MYGProyectoStorage.Guardar(ruta, documento);
        VerificarSql(new[] { 10m, 30m, 60m }, new[] { 30m, 120m, 300m }, new[] { 1m, 3m, 2m },
            new[] { 10m, 10m, 30m }, new[] { 10m, 30m, 60m }, 450m);
        var reabierto = MYGProyectoStorage.Leer(ruta).Presupuestos.Single();
        var reabiertas = partidas.Select(i => reabierto.Items.Single(j => j.Id == i.Id)).ToArray();
        var recalculo = MYGMotorPresupuestos.CrearCalculo(reabierto);
        Exige(reabiertas[0].Costos.Analisis.Single().CalcularCantidadPorUnidad &&
            reabiertas.Select(i => recalculo.Analizar(i).PrecioUnitario).SequenceEqual(new[] { 10m, 30m, 60m }) &&
            reabiertas.Select(recalculo.TotalPartida).SequenceEqual(new[] { 30m, 120m, 300m }) &&
            recalculo.TotalPartida(reabierto.Items.Single(i => i.Id == titulo.Id)) == 450m,
            "Reabrir el modelo JSON persistido en SQLite debe conservar la activación y los precios, parciales y título recalculados.");
        pasa("Guardar sobre SQLite importado actualiza precios, parciales y composiciones de nieto/padre/abuelo y total del título; reabrir conserva el modelo recalculado");

        void VerificarSql(decimal[] precios, decimal[] parciales, decimal[] cantidades, decimal[] preciosRecursos,
            decimal[] parcialesRecursos, decimal totalTitulo)
        {
            for (int n = 0; n < partidas.Length; n++)
            {
                string descripcion = partidas[n].Descripcion;
                const string composiciones = " FROM composicion_costounitario r JOIN subtotal_costounitario s ON s.id_subtotal=r.id_subtotal " +
                    "JOIN costo_unitario c ON c.id_costounitario=s.id_costounitario WHERE c.descripcion_costo=$p0";
                Exige(NumeroSql(ruta, "SELECT costo_unitario FROM costo_unitario WHERE descripcion_costo=$p0", descripcion) == precios[n] &&
                    NumeroSql(ruta, "SELECT parcial_costo FROM costo_unitario WHERE descripcion_costo=$p0", descripcion) == parciales[n] &&
                    NumeroSql(ruta, "SELECT r.cantidad_composicion" + composiciones, descripcion) == cantidades[n] &&
                    NumeroSql(ruta, "SELECT r.costo_composicion" + composiciones, descripcion) == preciosRecursos[n] &&
                    NumeroSql(ruta, "SELECT r.parcial_composicion" + composiciones, descripcion) == parcialesRecursos[n],
                    "Las tablas nativas deben reflejar precio, parcial y composición efectivos de " + descripcion + ", sin conservar una caché importada obsoleta.");
            }
            Exige(NumeroSql(ruta, "SELECT parcial_costo FROM costo_unitario WHERE descripcion_costo=$p0", titulo.Descripcion) == totalTitulo,
                "El título nativo también debe actualizar su total cuando cambia un recurso horario descendiente.");
        }
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("PERSISTENCIA N° RECURSOS QA"); var p = doc.Presupuestos.Single();
        var partida = Partida(p, "RECURSO HORARIO PERSISTIDO QA");
        partida.Costos.Cantidad = 2; partida.Costos.RendimientoDiario = 13.7m; partida.Costos.JornadaHoras = 8m;
        var recurso = Recurso(p, partida, "hh", MYGGrupoRecurso.ManoObra, 17.3m, MYGModoCantidad.Directa, 999m, 2.125m);
        recurso.DesperdicioPorcentaje = 2.5m;
        foreach (string extension in new[] { ".myg.json", ".myg.sqlite" })
        {
            string ruta = Path.Combine(carpeta, "Cantidad por recursos persistida" + extension);
            MYGProyectoStorage.Guardar(ruta, doc);
            var reabierto = MYGProyectoStorage.Leer(ruta).Presupuestos.Single(); var fila = reabierto.Items.Single();
            var linea = fila.Costos.Analisis.Single(); var resultado = MYGMotorPresupuestos.CrearCalculo(reabierto);
            Exige(linea.CalcularCantidadPorUnidad && linea.NumeroRecursos == 2.125m && linea.Cantidad == 999m &&
                resultado.Analizar(fila).Recursos.Single().Cantidad == 3.7300m && resultado.TotalPartida(fila) == 129.06m,
                "Guardar y reabrir " + extension + " debe conservar la activación, recursos, consumo guardado y cálculo nuevo sin migrar otras líneas.");
        }
        string rutaCatalogo = Path.Combine(carpeta, "Cantidad por recursos catalogo.myg.sqlite");
        MYGProyectoStorage.Guardar(rutaCatalogo, doc);
        var entrada = MYGCatalogos.GuardarPartida(rutaCatalogo, p, partida, "QA-NREC", partida.Descripcion, partida.Unidad);
        var plantilla = MYGCatalogos.LeerPartida(rutaCatalogo, entrada.Id);
        Exige(plantilla.Partidas.Single().Costos.Analisis.Single().CalcularCantidadPorUnidad,
            "Guardar y leer una partida del catálogo debe conservar la regla de cantidad por unidad.");
        var destino = MYGProyectoStorage.Nuevo("DESTINO RECURSOS QA").Presupuestos.Single();
        var insertada = MYGCatalogos.InsertarPartida(destino, rutaCatalogo, entrada, null);
        Exige(insertada.Costos.Analisis.Single().CalcularCantidadPorUnidad &&
            insertada.Costos.Analisis.Single().NumeroRecursos == 2.125m &&
            MYGMotorPresupuestos.CrearCalculo(destino).Analizar(insertada).PrecioUnitario == 64.53m,
            "Insertar una partida del catálogo debe conservar su nueva regla y reproducir el precio unitario guardado.");
        pasa("JSON, SQLite y catálogo conservan la nueva regla, N° Recursos y resultados al guardar, reabrir e insertar la partida");
    }
}
