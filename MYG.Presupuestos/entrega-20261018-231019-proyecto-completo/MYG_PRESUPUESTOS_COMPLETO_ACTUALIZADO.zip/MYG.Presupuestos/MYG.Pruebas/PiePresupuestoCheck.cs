using System;
using System.IO;
using System.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

static class PiePresupuestoCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static MYGPresupuestoDocumento Directo(string nombre, decimal importe)
    {
        var p = new MYGPresupuestoDocumento { Nombre = nombre };
        var i = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        i.Descripcion = nombre; i.Costos.Cantidad = 1; i.Costos.PrecioDirecto = importe; return p;
    }
    private static MYGPresupuestoDocumento Desglose()
    {
        var p = new MYGPresupuestoDocumento { Nombre = "DESGLOSE" };
        var i = MYGEstructuraPresupuestos.InsertarNodo(p, false); i.Costos.Cantidad = 10;
        var grupos = new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos };
        decimal[] precios = { 3, 6, 0.4m, 0.6m };
        for (int n = 0; n < grupos.Length; n++)
        {
            var insumo = new MYGInsumo { Descripcion = grupos[n].ToString(), Grupo = grupos[n], Precio = precios[n] };
            p.Costos.Insumos.Add(insumo); i.Costos.Analisis.Add(new() { Grupo = grupos[n], InsumoId = insumo.Id, Cantidad = 1 });
        }
        return p;
    }
    private static void Rechaza(Action accion)
    {
        try { accion(); } catch (InvalidOperationException) { return; } catch (InvalidDataException) { return; }
        throw new Exception("Se aceptó una operación inválida.");
    }
    private static object SQL(string ruta, string consulta)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString()); c.Open();
        using var q = c.CreateCommand(); q.CommandText = consulta; return q.ExecuteScalar();
    }
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var a = Directo("PIE A", 1000); var b = Directo("PIE B", 2000);
        a.Costos.GastosGeneralesPorcentaje = 10; a.Costos.UtilidadPorcentaje = 5;
        a.Costos.ImpuestoPorcentaje = 18; a.Costos.OtrosImpuestosPorcentaje = 2;
        b.Costos.GastosGeneralesPorcentaje = 20; b.Costos.OtrosImpuestosPorcentaje = 5;
        var r = MYGMotorPresupuestos.Resumen(a);
        Exige(r.CostoDirecto == 1000 && r.GastosGenerales == 100 && r.Utilidad == 50 &&
            r.Subtotal == 1150 && r.Impuesto == 207 && r.OtrosImpuestos == 23 && r.Total == 1380,
            "El pie aplica un porcentaje a una base incorrecta.");
        var proyecto = new MYGProyectoDocumento { Nombre = "PIE PROYECTO", Datos = new MYGDatosProyecto { UsarUbicacion = false }, Presupuestos = new() { a, b } };
        var suma = MYGPiePresupuesto.Resumen(proyecto.Presupuestos);
        Exige(suma.CostoDirecto == 3000 && suma.GastosGenerales == 500 && suma.Utilidad == 50 &&
            suma.Subtotal == 3550 && suma.Impuesto == 207 && suma.OtrosImpuestos == 143 && suma.Total == 3900,
            "El resumen de proyecto homogenizó tasas o calculó sobre el presupuesto seleccionado.");
        MYGPiePresupuesto.AplicarPorcentaje(proyecto.Presupuestos, MYGConceptoPie.IGV, 19);
        Exige(a.Costos.ImpuestoPorcentaje == 19 && b.Costos.ImpuestoPorcentaje == 19 && a.Costos.GastosGeneralesPorcentaje == 10 &&
            b.Costos.OtrosImpuestosPorcentaje == 5 && MYGPiePresupuesto.Resumen(proyecto.Presupuestos).Total == 4367.5m,
            "Editar una tasa del proyecto cambió conceptos ajenos.");
        pasa("Pie editable calcula GG/utilidad sobre costo directo e impuestos sobre parcial y suma cada presupuesto con sus tasas");

        string firma = MYGProyectoStorage.Firma(proyecto);
        foreach (decimal invalido in new[] { -1m, 10001m, 0.12345m })
        {
            Rechaza(() => MYGPiePresupuesto.AplicarPorcentaje(proyecto.Presupuestos, MYGConceptoPie.Utilidad, invalido));
            Exige(MYGProyectoStorage.Firma(proyecto) == firma, "Una tasa inválida cambió algún presupuesto.");
        }
        b.Costos.Moneda = "USD"; firma = MYGProyectoStorage.Firma(proyecto);
        Rechaza(() => MYGPiePresupuesto.Resumen(proyecto.Presupuestos));
        Rechaza(() => MYGPiePresupuesto.Incidencia(proyecto.Presupuestos));
        Rechaza(() => MYGPiePresupuesto.AplicarPorcentaje(proyecto.Presupuestos, MYGConceptoPie.Utilidad, 5));
        Exige(MYGProyectoStorage.Firma(proyecto) == firma, "Un proyecto de monedas diferentes fue modificado.");
        b.Costos.Moneda = "S/";
        var vacio = MYGPiePresupuesto.Resumen(Array.Empty<MYGPresupuestoDocumento>());
        Exige(vacio.Total == 0 && MYGPiePresupuesto.Incidencia(Array.Empty<MYGPresupuestoDocumento>()).All(x => x.Importe == 0 && x.Porcentaje == 0), "El gráfico vacío produjo datos ficticios.");
        pasa("Porcentajes inválidos y monedas mezcladas se rechazan sin cambios; el alcance vacío tiene importes cero");

        string ruta = Path.Combine(carpeta, "Pie editable.sqlite"); MYGProyectoStorage.Guardar(ruta, proyecto);
        var leido = MYGBaseDatos.LeerProyecto(ruta, proyecto.Id); var guardado = leido.Presupuestos.Single(x => x.Id == a.Id);
        Exige(guardado.Costos.OtrosImpuestosPorcentaje == 2 && guardado.Costos.ImpuestoPorcentaje == 19 &&
            MYGMotorPresupuestos.Resumen(guardado).Total == 1391.5m,
            "SQLite no conservó las tasas editadas.");
        Exige(Convert.ToDecimal(SQL(ruta, "SELECT porcentaje_impuestootro FROM presupuesto WHERE nombre_presupuesto='PIE A'")) == 2 &&
            Convert.ToDecimal(SQL(ruta, "SELECT monto_impuestootro FROM presupuesto WHERE nombre_presupuesto='PIE A'")) == 23 &&
            Convert.ToDecimal(SQL(ruta, "SELECT total_presupuesto FROM presupuesto WHERE nombre_presupuesto='PIE A'")) == 1391.5m,
            "Las columnas nativas no coinciden con el pie MYG.");
        string nativa = Path.Combine(carpeta, "Pie lectura nativa.sqlite"); File.Copy(ruta, nativa);
        SQL(nativa, "DELETE FROM myg_presupuesto; DELETE FROM myg_proyecto;");
        var importado = MYGBaseDatos.LeerProyecto(nativa, LectorDelphin.LeerProyectosSQLite(nativa).Single().Id);
        Exige(importado.Presupuestos.Single(x => x.Nombre == "PIE A").Costos.OtrosImpuestosPorcentaje == 2,
            "La importación nativa ignoró otros impuestos.");
        pasa("Pie persistido reabre tasas e importes coherentes en JSON MYG y columnas nativas SQLite, incluida importación sin snapshot");

        var p = Desglose(); var incidencia = MYGPiePresupuesto.Incidencia(new[] { p });
        Exige(incidencia.Select(x => x.Importe).SequenceEqual(new[] { 30m, 60m, 4m, 6m }) &&
            incidencia.Select(x => x.Porcentaje).SequenceEqual(new[] { 30m, 60m, 4m, 6m }), "El gráfico no utiliza los grupos reales del ACU.");
        p.Costos.ImpuestoPorcentaje = 18; p.Costos.GastosGeneralesPorcentaje = 12;
        Exige(MYGPiePresupuesto.Incidencia(new[] { p }).Sum(x => x.Importe) == 100,
            "El gráfico incluyó impuestos o gastos indirectos en los insumos.");
        var sub = MYGEstructuraPresupuestos.InsertarNodo(p, false); sub.Descripcion = "SUBANÁLISIS";
        var raiz = p.Items.First(); sub.Costos.Analisis = raiz.Costos.Analisis; raiz.Costos.Analisis = new();
        raiz.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = 1 });
        Exige(MYGPiePresupuesto.Incidencia(new[] { p }).Select(x => x.Importe).SequenceEqual(new[] { 30m, 60m, 4m, 6m }),
            "El gráfico contó la subpartida como otro grupo o sumó dos veces su ACU.");
        var precioDirecto = Directo("SIN ACU", 50);
        var mixta = MYGPiePresupuesto.Incidencia(new[] { p, precioDirecto });
        Exige(mixta.Count == 5 && mixta.Single(x => x.Nombre == "SIN DESGLOSE").Importe == 50 && mixta.Sum(x => x.Importe) == 150,
            "El gráfico atribuyó un precio sin ACU a subcontratos.");
        pasa("Incidencia descompone subanálisis en sus grupos, excluye tasas y distingue precios sin desglose");

        var redondeo = Desglose(); var nodo = redondeo.Items.Single();
        MYGMotorPresupuestos.CapturarPrecioDelphin(redondeo, nodo, 10.01m, 100.10m);
        incidencia = MYGPiePresupuesto.Incidencia(new[] { redondeo });
        Exige(incidencia.Sum(x => x.Importe) == 100.10m && incidencia.All(x => x.Importe >= 0) && incidencia.Sum(x => x.Porcentaje) > 99.99m,
            "El gráfico perdió importes nativos al conciliar redondeos.");
        nodo.Costos.Cantidad = 1; foreach (var insumo in redondeo.Costos.Insumos) insumo.Precio = 1;
        MYGMotorPresupuestos.CapturarPrecioDelphin(redondeo, nodo, 0.02m, 0.02m);
        incidencia = MYGPiePresupuesto.Incidencia(new[] { redondeo });
        Exige(incidencia.Sum(x => x.Importe) == 0.02m && incidencia.All(x => x.Importe >= 0),
            "El reparto de centavos creó una barra negativa.");
        pasa("Incidencia concilia parciales nativos y reparte centavos sin barras negativas ni pérdidas de importe");
    }
}
