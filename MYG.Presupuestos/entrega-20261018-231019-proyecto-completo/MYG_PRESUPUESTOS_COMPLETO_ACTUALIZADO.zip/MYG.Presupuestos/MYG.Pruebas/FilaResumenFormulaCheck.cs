using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class FilaResumenFormulaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (InvalidOperationException) { return; }
        throw new Exception("Se aceptó una fila o fórmula de resumen inválida.");
    }

    private static MYGPresupuestoDocumento Directo(string nombre, decimal importe)
    {
        var p = new MYGPresupuestoDocumento { Nombre = nombre };
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        partida.Descripcion = "PARTIDA " + nombre;
        partida.Costos.Cantidad = 1;
        partida.Costos.PrecioDirecto = importe;
        return p;
    }

    private static MYGProyectoDocumento Proyecto(params MYGPresupuestoDocumento[] presupuestos)
    {
        for (int n = 0; n < presupuestos.Length; n++)
        { presupuestos[n].Item = (n + 1).ToString("00"); presupuestos[n].Posicion = n + 1; }
        return new MYGProyectoDocumento
        {
            Nombre = "FILAS Y FORMULAS QA", Datos = new MYGDatosProyecto { UsarUbicacion = false },
            Presupuestos = presupuestos.ToList(), PresupuestoActivoId = presupuestos[0].Id
        };
    }

    private static List<MYGFilaPiePersonalizada> CuatroModos() => new()
    {
        new() { Id = "fila-gg", Nombre = "Administración", Identificador = "GG", Tipo = MYGTipoFilaResumen.GastosGenerales,
            Modo = MYGModoFilaResumen.GastoConSustento, Porcentaje = 10 },
        new() { Id = "fila-otros", Nombre = "Otros gastos", Identificador = "OTROS", Modo = MYGModoFilaResumen.OtrosGastos,
            Porcentaje = 20, Formula = "CD + GG" },
        new() { Id = "fila-fijo", Nombre = "Monto fijo", Identificador = "FIJO", Modo = MYGModoFilaResumen.ValorManual,
            ValorManual = 12.345m },
        new() { Id = "fila-formula", Nombre = "Utilidad calculada", Identificador = "UTIL", Tipo = MYGTipoFilaResumen.Utilidad,
            Modo = MYGModoFilaResumen.Formula, Formula = "= -( -((cd + gg) * 0,18)) + fijo" }
    };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        CalculoCuatroModos(pasa);
        CompatibilidadAnterior(pasa);
        ReferenciasYValidacion(pasa);
        PrevalidacionContextualAtomica(pasa);
        CopiasYAlcances(pasa);
        Persistencia(carpeta, pasa);
    }

    private static void CalculoCuatroModos(Action<string> pasa)
    {
        var p = Directo("CUATRO MODOS", 1000);
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, CuatroModos());
        var filas = MYGPiePresupuesto.Filas(new[] { p });
        Exige(filas.Select(f => f.Importe).SequenceEqual(new[] { 1000m, 100m, 220m, 12.35m, 210.35m }) &&
            MYGMotorPresupuestos.Resumen(p).Total == 1542.70m,
            "Los cuatro modos deben calcular porcentaje directo, porcentaje de fórmula, importe manual y fórmula con referencias redondeadas.");
        Exige(filas[1].Porcentaje == 10 && filas[2].Porcentaje == 20 && filas[1].Editable && filas[2].Editable &&
            filas[3].Porcentaje == null && filas[4].Porcentaje == null && !filas[3].Editable && !filas[4].Editable,
            "Sólo los dos modos porcentuales deben ofrecer edición de la celda de porcentaje.");
        Exige(MYGPiePresupuesto.EvaluarFormula("2 + 3 * 4 - (10 / 2)", 100, 125) == 9 &&
            MYGPiePresupuesto.EvaluarFormula("COSTODIRECTO + acumulado + a", 100, 125,
                new Dictionary<string, decimal> { ["A"] = 5 }) == 230,
            "La fórmula debe respetar precedencia, paréntesis y referencias sin distinguir mayúsculas.");
        pasa("Cuatro modos de fila calculan importes reales, redondean referencias y reservan el porcentaje para los modos porcentuales");
    }

    private static void CompatibilidadAnterior(Action<string> pasa)
    {
        const string anterior = "{\"Id\":\"historica\",\"Nombre\":\"Histórica\",\"Porcentaje\":18,\"Base\":\"Acumulado\"}";
        var fila = JsonSerializer.Deserialize<MYGFilaPiePersonalizada>(anterior);
        // El serializador codifica los acentos; se compara contra la misma política histórica.
        string historicoSerializado = JsonSerializer.Serialize(new
        { fila.Id, fila.Nombre, fila.Porcentaje, fila.Base });
        Exige(JsonSerializer.Serialize(fila) == historicoSerializado && fila.Modo == null && fila.Formula == null &&
            MYGPiePresupuesto.ModoEfectivo(fila) == MYGModoFilaResumen.OtrosGastos && MYGPiePresupuesto.EsPorcentual(fila),
            "Una fila anterior debe conservar exactamente sus campos serializados, sin agregar metadatos por defecto.");
        var p = Directo("LEGADO ACUMULADO", 1000);
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, new()
        { new() { Id = "primera", Nombre = "Primer gasto", Porcentaje = 10 }, fila });
        Exige(MYGMotorPresupuestos.Resumen(p).Total == 1298 &&
            MYGPiePresupuesto.Filas(new[] { p })[2].Importe == 198,
            "Los documentos anteriores deben seguir calculando porcentajes sobre el acumulado sin exigir fórmula nueva.");
        pasa("Filas anteriores mantienen su JSON y firmas sin metadatos nuevos y conservan el cálculo histórico sobre acumulado");
    }

    private static void ReferenciasYValidacion(Action<string> pasa)
    {
        var p = Directo("REFERENCIAS", 1000);
        var valido = CuatroModos();
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, valido);
        string antes = JsonSerializer.Serialize(p);
        var casos = new List<List<MYGFilaPiePersonalizada>>();
        foreach (string identificador in new[] { "CD", "costodirecto", "ACUMULADO", "3ABC", "con-guion", " " })
        {
            var filas = CuatroModos(); filas[0].Identificador = identificador; casos.Add(filas);
        }
        var duplicada = CuatroModos(); duplicada[2].Identificador = "gg"; casos.Add(duplicada);
        foreach (string formula in new[] { "DESCONOCIDA + 1", "UTIL + 1", "FIJO + 1", "CD / 0", "CD / (GG - GG)",
            "(CD + GG", "CD +", "CD ^ 2", "System.Exit(0)", "1..2", "", "79228162514264337593543950335 * 2",
            new string('(', 70) + "1" + new string(')', 70), new string('1', 4097) })
        {
            var filas = CuatroModos(); filas[1].Formula = formula; casos.Add(filas);
        }
        var tipoInvalido = CuatroModos(); tipoInvalido[0].Tipo = (MYGTipoFilaResumen)99; casos.Add(tipoInvalido);
        var modoInvalido = CuatroModos(); modoInvalido[0].Modo = (MYGModoFilaResumen)99; casos.Add(modoInvalido);
        foreach (var filas in casos)
        {
            Rechaza(() => MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, filas));
            Exige(JsonSerializer.Serialize(p) == antes, "Una fórmula inválida modificó el presupuesto antes de validarse.");
        }
        var reordenadas = CuatroModos(); (reordenadas[0], reordenadas[1]) = (reordenadas[1], reordenadas[0]);
        Rechaza(() => MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, reordenadas));
        Exige(JsonSerializer.Serialize(p) == antes, "Reordenar una fórmula antes de su referencia alteró el pie existente.");
        pasa("Fórmulas rechazan referencias futuras o circulares, identificadores inválidos, sintaxis, división por cero y desbordamientos sin guardar cambios");
    }

    private static void PrevalidacionContextualAtomica(Action<string> pasa)
    {
        var a = Directo("ATOMICO FORMULA A", 100);
        var b = Directo("ATOMICO FORMULA B", 200);
        var doc = Proyecto(a, b);
        string antes = MYGProyectoStorage.Firma(doc);
        var filas = new List<MYGFilaPiePersonalizada>
        { new() { Id = "formula-contextual", Nombre = "División contextual", Identificador = "DIV", Modo = MYGModoFilaResumen.Formula, Formula = "100 / (CD - 200)" } };
        Rechaza(() => MYGPiePresupuesto.ValidarPersonalizado(doc.Presupuestos, filas));
        Rechaza(() => MYGPiePresupuesto.EstablecerPersonalizado(doc.Presupuestos, filas));
        Exige(MYGProyectoStorage.Firma(doc) == antes,
            "Un error en el segundo presupuesto debe impedir cualquier modificación en el primero.");
        filas[0].Formula = "100 / CD";
        MYGPiePresupuesto.ValidarPersonalizado(doc.Presupuestos, filas);
        Exige(MYGProyectoStorage.Firma(doc) == antes, "La prevalidación del editor debe ser una operación sin cambios.");
        MYGPiePresupuesto.EstablecerPersonalizado(doc.Presupuestos, filas);
        Exige(MYGMotorPresupuestos.Resumen(a).Total == 101 && MYGMotorPresupuestos.Resumen(b).Total == 200.5m,
            "Una fórmula común debe evaluarse sobre el costo directo de cada presupuesto.");
        var acumulado = new List<MYGFilaPiePersonalizada>
        {
            new() { Id = "monto-previo", Nombre = "Fijo", Identificador = "FIJO", Modo = MYGModoFilaResumen.ValorManual, ValorManual = 5 },
            new() { Id = "sobre-acumulado", Nombre = "Acumulado", Identificador = "AC", Modo = MYGModoFilaResumen.OtrosGastos, Porcentaje = 10, Formula = "ACUMULADO" }
        };
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { a }, acumulado);
        Exige(MYGMotorPresupuestos.Resumen(a).Total == 115.5m,
            "ACUMULADO debe representar el costo directo y todos los importes redondeados anteriores.");
        pasa("Prevalidación comprueba todos los presupuestos sin mutaciones y aplica fórmulas y acumulado en el contexto de cada uno");
    }

    private static void CopiasYAlcances(Action<string> pasa)
    {
        var a = Directo("COPIA A", 1000);
        var b = Directo("COPIA B", 2000);
        var origen = CuatroModos();
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { a, b }, origen);
        Exige(JsonSerializer.Serialize(a.Costos.PiePersonalizado) == JsonSerializer.Serialize(origen) &&
            JsonSerializer.Serialize(b.Costos.PiePersonalizado) == JsonSerializer.Serialize(origen),
            "Copiar un pie debe conservar tipos, identificadores, fórmulas, modo y valor manual.");
        origen[3].Formula = "0"; origen[2].ValorManual = 99;
        Exige(a.Costos.PiePersonalizado[3].Formula != "0" && a.Costos.PiePersonalizado[2].ValorManual == 12.345m,
            "El pie aplicado debe tener una copia independiente del editor o portapapeles.");
        var distintos = MYGProyectoStorage.Copia(b.Costos.PiePersonalizado);
        distintos[1].Formula = "CD + GG + 10";
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { b }, distintos);
        var fila = MYGPiePresupuesto.Filas(new[] { a, b }).Single(f => f.Id == "fila-otros");
        Exige(!fila.Editable && fila.Porcentaje == null && a.Costos.PiePersonalizado[1].Formula == "CD + GG",
            "Un proyecto con fórmulas distintas debe ocultar el porcentaje común y conservar el pie individual.");
        distintos[0].Modo = MYGModoFilaResumen.ValorManual; distintos[0].ValorManual = 100;
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { b }, distintos);
        fila = MYGPiePresupuesto.Filas(new[] { a, b }).Single(f => f.Id == "fila-gg");
        Exige(!fila.Editable && fila.Porcentaje == null,
            "Un mismo concepto con modos distintos debe impedir la edición porcentual conjunta.");
        pasa("Copiar y aplicar pies preserva todos los metadatos y el proyecto impide porcentajes conjuntos con fórmulas o modos distintos");
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var p = Directo("PERSISTENCIA FORMULAS", 1000);
        var doc = Proyecto(p);
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, CuatroModos());
        string ruta = Path.Combine(carpeta, "Filas resumen formulas.myg.json");
        MYGProyectoStorage.Guardar(ruta, doc);
        string esperado = JsonSerializer.Serialize(p.Costos.PiePersonalizado);
        foreach (var reabierto in new[] { MYGProyectoStorage.Leer(ruta),
            MYGBaseDatos.LeerProyecto(MYGBaseDatos.RutaDeProyecto(ruta), doc.Id) })
        {
            var presupuesto = reabierto.Presupuestos.Single();
            Exige(JsonSerializer.Serialize(presupuesto.Costos.PiePersonalizado) == esperado &&
                MYGMotorPresupuestos.Resumen(presupuesto).Total == 1542.7m,
                "JSON y SQLite deben conservar los cuatro modos, sus metadatos y sus cálculos al reabrir.");
        }
        pasa("Guardar y reabrir JSON y SQLite conserva tipo, identificador, modo, fórmula, valor manual y totales calculados");
    }
}
