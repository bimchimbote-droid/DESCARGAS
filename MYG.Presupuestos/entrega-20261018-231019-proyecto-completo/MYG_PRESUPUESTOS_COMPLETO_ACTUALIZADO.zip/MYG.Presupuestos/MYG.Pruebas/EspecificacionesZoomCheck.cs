using System;
using MYG_2027;

internal static class EspecificacionesZoomCheck
{
    private static void Exige(bool condicion, string detalle)
    {
        if (!condicion) throw new Exception(detalle);
    }

    private static bool Cerca(double a, double b) => Math.Abs(a - b) < 1e-9;

    internal static void Ejecutar(Action<string> pasa)
    {
        var pequena = new MYGEspecificacionesZoom();
        var grande = new MYGEspecificacionesZoom();
        pequena.SetImmediate(25); grande.SetImmediate(150);
        pequena.Retarget(120, 0); grande.Retarget(120, 0);
        Exige(Cerca(pequena.Target / 25, 1.08) && Cerca(grande.Target / 150, 1.08),
            "La sensibilidad de la rueda debe ser proporcional en escalas pequeñas y grandes.");
        grande.Advance(.160); grande.Retarget(-120, .200); grande.Advance(.360);
        Exige(Cerca(grande.Current, 150) && !grande.Active,
            "Acercar y alejar un paso completo debe recuperar la escala original sin deriva.");
        pasa("Zoom proporcional conserva sensibilidad y pasos inversos recuperan la escala original");

        var completo = new MYGEspecificacionesZoom();
        var fracciones = new MYGEspecificacionesZoom();
        completo.Retarget(120, 0);
        for (int n = 0; n < 3; n++)
        {
            fracciones.Retarget(40, n * .020);
            fracciones.Advance(n * .020 + .010);
        }
        Exige(Cerca(fracciones.Target, completo.Target) && fracciones.Current > 100 && fracciones.Current < fracciones.Target,
            "Las fracciones de rueda deben responder enseguida y acumular la misma ampliación que un paso completo.");
        fracciones.Advance(.210);
        Exige(Cerca(fracciones.Current, 108) && !fracciones.Active,
            "La transición fraccionaria debe terminar exactamente en su destino.");
        pasa("Rueda de alta resolución responde a fracciones sin esperar un salto completo");

        var rafaga = new MYGEspecificacionesZoom();
        for (int n = 0; n < 5; n++)
        {
            double renderizado = rafaga.Current;
            rafaga.Retarget(120, n * .020);
            Exige(Cerca(rafaga.Current, renderizado), "Retarget no debe introducir un salto antes de dibujar el siguiente cuadro.");
            rafaga.Advance(n * .020 + .010);
        }
        Exige(Cerca(rafaga.Target, 100 * Math.Pow(1.08, 5)),
            "Una ráfaga de rueda perdió parte del recorrido solicitado.");
        rafaga.Advance(.250);
        Exige(Cerca(rafaga.Current, rafaga.Target) && !rafaga.Active,
            "Una ráfaga debe finalizar después del último paso sin dejar un temporizador activo.");
        pasa("Ráfagas acumulan el destino y parten de la última escala dibujada sin saltos");

        var inversion = new MYGEspecificacionesZoom();
        inversion.Retarget(480, 0); inversion.Advance(.025);
        double antes = inversion.Current;
        inversion.Retarget(-120, .030);
        Exige(Cerca(inversion.Current, antes) && inversion.Target < antes,
            "Invertir la rueda debe cancelar la ampliación pendiente sin saltar de escala.");
        double anterior = antes;
        for (int n = 1; n <= 12; n++)
        {
            double actual = inversion.Advance(.030 + n * .015);
            Exige(actual <= anterior && actual >= inversion.Target,
                "La inversión continuó ampliando o sobrepasó su destino.");
            anterior = actual;
        }
        Exige(!inversion.Active && Cerca(inversion.Current, inversion.Target), "La inversión no terminó en su destino.");
        pasa("Invertir la rueda cambia de sentido inmediatamente y termina sin sobrepasar el destino");

        var frecuente = new MYGEspecificacionesZoom();
        var lento = new MYGEspecificacionesZoom();
        frecuente.Retarget(240, 10); lento.Retarget(240, 10);
        double previo = frecuente.Current;
        for (int n = 1; n <= 6; n++)
        {
            double actual = frecuente.Advance(10 + n * .016);
            Exige(actual >= previo && actual <= frecuente.Target, "La animación debe ser monótona y no sobrepasar el destino.");
            previo = actual;
        }
        Exige(Cerca(frecuente.Current, lento.Advance(10.096)),
            "El zoom a igual tiempo transcurrido no debe depender del número de cuadros dibujados.");
        frecuente.Advance(10.300); lento.Advance(10.300);
        Exige(Cerca(frecuente.Current, lento.Current) && !frecuente.Active && !lento.Active,
            "Un cuadro atrasado debe completar la transición, no prolongarla ni sobrepasarla.");
        pasa("Zoom usa tiempo transcurrido y mantiene el mismo recorrido aunque baje la frecuencia de cuadros");

        var limites = new MYGEspecificacionesZoom();
        limites.Retarget(int.MaxValue, 0); limites.Advance(.200);
        Exige(Cerca(limites.Current, 300) && !limites.Active, "La ampliación máxima debe quedar limitada al 300 %.");
        limites.Retarget(120, .210);
        Exige(!limites.Active && Cerca(limites.Current, 300), "Insistir en el límite no debe iniciar una transición vacía.");
        limites.Retarget(int.MinValue, .220); limites.Advance(.400);
        Exige(Cerca(limites.Current, 25) && !limites.Active, "La ampliación mínima debe quedar limitada al 25 %.");
        limites.Retarget(-120, .410);
        Exige(!limites.Active, "Insistir en el mínimo no debe iniciar una transición vacía.");
        limites.Retarget(120, .420); limites.SetImmediate(125); limites.Advance(1);
        Exige(Cerca(limites.Current, 125) && Cerca(limites.Target, 125) && !limites.Active,
            "Un cambio manual debe cancelar la animación pendiente y conservar la escala elegida.");
        pasa("Zoom respeta límites sin animaciones vacías y un cambio manual cancela el recorrido pendiente");
    }
}
