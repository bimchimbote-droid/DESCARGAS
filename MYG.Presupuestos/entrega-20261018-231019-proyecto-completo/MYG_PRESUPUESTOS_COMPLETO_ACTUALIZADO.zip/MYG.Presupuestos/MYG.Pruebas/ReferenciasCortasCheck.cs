using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ReferenciasCortasCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static ItemPresupuestoDelphin Partida(string descripcion, int posicion)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
            Descripcion = descripcion, Posicion = posicion, TipoPropuesta = "PARTIDA", Unidad = "m²" };
    }

    private static (MYGProyectoDocumento Doc, MYGPresupuestoDocumento P,
        ItemPresupuestoDelphin Destino, ItemPresupuestoDelphin Origen) Nuevo()
    {
        var doc = MYGProyectoStorage.Nuevo("REFERENCIAS CORTAS", new string('P', 300));
        var p = doc.Presupuestos.Single();
        var destino = Partida("DESTINO", 1); var origen = Partida(new string('X', 1000), 2);
        p.Items.AddRange(new[] { destino, origen });
        MYGProyectoStorage.Renumerar(p); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        origen.Costos.Hoja.Poner("B3", "7");
        return (doc, p, destino, origen);
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        NombresYRenumeracion(pasa);
        PresupuestosRepetidos(pasa);
        CompatibilidadYBorrador(carpeta, pasa);
        CodigosAlternativos(pasa);
    }

    private static void NombresYRenumeracion(Action<string> pasa)
    {
        var (doc, p, destino, origen) = Nuevo();
        var hoja = destino.Costos.Hoja;
        string fragmento = MYGReferenciasMetrado.CrearReferencia(hoja, p, origen, "B3");
        Exige(fragmento == "METRADO(\"01/02\";\"B3\")",
            "La referencia debe mostrar presupuesto/ítem sin nombres de presupuesto ni descripción de partida.");
        hoja.Poner("B3", "=" + fragmento + "*2");
        string ancla = hoja.ReferenciasPartidas.Single().AnclaId;
        origen.Posicion = 1; destino.Posicion = 2; p.Item = "99";
        MYGProyectoStorage.Renumerar(p); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        Exige(origen.Item == "01" && MYGReferenciasMetrado.CrearReferencia(hoja, p, origen, "B3") == fragmento &&
            hoja.ReferenciasPartidas.Count == 1 && hoja.ReferenciasPartidas.Single().AnclaId == ancla &&
            hoja.Celdas["B3"].Contenido == "=" + fragmento + "*2" && new MYGHojaCalculo(hoja).Numero("B3") == 14,
            "El código corto guardado debe seguir siendo estable y resolver la misma partida después de renumerarla.");
        origen.Costos.Hoja.Poner("B4", "3");
        string otraCelda = MYGReferenciasMetrado.CrearReferencia(hoja, p, origen, "B4");
        Exige(otraCelda == "METRADO(\"01/02\";\"B4\")" && hoja.ReferenciasPartidas.Count == 2,
            "Referenciar otra celda de la misma partida debe reutilizar su código corto guardado.");
        pasa("Las descripciones largas no aparecen en nuevas fórmulas y sus códigos cortos permanecen estables al renumerar");
    }

    private static void PresupuestosRepetidos(Action<string> pasa)
    {
        var (doc, p, destino, origen) = Nuevo();
        var hoja = destino.Costos.Hoja;
        var segundo = new MYGPresupuestoDocumento { Nombre = p.Nombre, Item = "02", Posicion = 2 };
        var otra = Partida(origen.Descripcion, 1); segundo.Items.Add(otra); doc.Presupuestos.Add(segundo);
        MYGProyectoStorage.Renumerar(segundo); otra.Item = origen.Item; otra.Costos.Hoja.Poner("B3", "11");
        MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string uno = MYGReferenciasMetrado.CrearReferencia(hoja, p, origen, "B3");
        string dos = MYGReferenciasMetrado.CrearReferencia(hoja, segundo, otra, "B3");
        hoja.Poner("B3", "=" + uno + "+" + dos);
        Exige(dos == "METRADO(\"02/02\";\"B3\")" && new MYGHojaCalculo(hoja).Numero("B3") == 18,
            "Ítems iguales en diferentes presupuestos deben mostrar sus códigos de presupuesto y resolver orígenes distintos.");

        // Documentos externos pueden traer numeraciones repetidas. Tampoco se
        // deben confundir entre sí al alcanzar sufijos de dos dígitos.
        for (int n = 2; n <= 12; n++)
        {
            var repetido = new MYGPresupuestoDocumento { Nombre = "MISMO CÓDIGO", Item = "01", Posicion = n + 1 };
            var partida = Partida("MISMO ÍTEM", 1); repetido.Items.Add(partida); doc.Presupuestos.Add(repetido);
            MYGProyectoStorage.Renumerar(repetido); partida.Item = "02";
            partida.Costos.Hoja.Poner("B3", n.ToString()); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
            string referencia = MYGReferenciasMetrado.CrearReferencia(hoja, repetido, partida, "B3");
            Exige(referencia == "METRADO(\"01/02 (" + n + ")\";\"B3\")" &&
                MYGReferenciasMetrado.CrearReferencia(hoja, repetido, partida, "B3") == referencia,
                "Cada código duplicado debe distinguir su origen y reutilizar su alias, incluidos sufijos de dos dígitos.");
            hoja.Poner("B" + (n + 2), "=" + referencia);
            Exige(new MYGHojaCalculo(hoja).Numero("B" + (n + 2)) == n,
                "El sufijo del código duplicado debe resolver por identidad y nunca por posición ni nombre.");
        }
        Exige(hoja.ReferenciasPartidas.Count == 13, "Reinsertar referencias cortas no debe crear registros ilimitados.");
        pasa("Los códigos distinguen ítems iguales entre presupuestos y reutilizan referencias incluso con numeraciones duplicadas");
    }

    private static void CompatibilidadYBorrador(string carpeta, Action<string> pasa)
    {
        var (doc, p, destino, origen) = Nuevo();
        var hoja = destino.Costos.Hoja;
        MYGReferenciasMetrado.CrearReferencia(hoja, p, origen, "B3");
        var antiguo = hoja.ReferenciasPartidas.Single();
        antiguo.Alias = "01 PRESUPUESTO DE NOMBRE EXTENSO / 02 - PARTIDA DE NOMBRE EXTENSO";
        string formulaAntigua = "=METRADO(\"" + antiguo.Alias + "\";\"B3\")*2";
        hoja.Poner("B3", formulaAntigua);
        string original = JsonSerializer.Serialize(hoja), originalOrigen = JsonSerializer.Serialize(origen.Costos.Hoja);
        MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        Exige(JsonSerializer.Serialize(hoja) == original,
            "Volver a vincular o abrir un proyecto no debe reescribir las fórmulas antiguas.");

        var borrador = MYGProyectoStorage.Copia(hoja);
        string corto = MYGReferenciasMetrado.CrearReferencia(borrador, p, origen, "B3");
        Exige(corto == "METRADO(\"01/02\";\"B3\")" &&
            MYGReferenciasMetrado.CrearReferencia(borrador, p, origen, "B3") == corto &&
            borrador.ReferenciasPartidas.Count == 2 &&
            borrador.ReferenciasPartidas.All(r => r.AnclaId == antiguo.AnclaId) &&
            JsonSerializer.Serialize(hoja) == original && JsonSerializer.Serialize(origen.Costos.Hoja) == originalOrigen,
            "Insertar de nuevo una referencia antigua en borrador debe dar un código corto con la misma ancla y dejar intacto el proyecto.");
        borrador.Poner("B4", "=" + corto + "+1");
        MYGReferenciasMetrado.AplicarReferenciasPendientes(hoja, borrador, borrador.Celdas["B4"].Contenido);
        hoja.Poner("B4", borrador.Celdas["B4"].Contenido);
        Exige(hoja.Celdas["B3"].Contenido == formulaAntigua && origen.Costos.Hoja.AnclasReferencias.Count == 1 &&
            new MYGHojaCalculo(hoja).Numero("B3") == 14 && new MYGHojaCalculo(hoja).Numero("B4") == 8,
            "Confirmar el código corto debe conservar la fórmula antigua y compartir su identidad de celda origen.");
        string ruta = Path.Combine(carpeta, "referencias_cortas.myg.json");
        MYGProyectoStorage.Guardar(ruta, doc);
        foreach (string archivo in new[] { ruta, MYGBaseDatos.RutaDeProyecto(ruta) })
        {
            var abierto = MYGProyectoStorage.Leer(archivo);
            var abierta = abierto.Presupuestos.Single().Items.Single(i => i.Id == destino.Id).Costos.Hoja;
            Exige(abierta.Celdas["B3"].Contenido == formulaAntigua && abierta.ReferenciasPartidas.Count == 2 &&
                new MYGHojaCalculo(abierta).Numero("B3") == 14 && new MYGHojaCalculo(abierta).Numero("B4") == 8,
                "JSON y SQLite deben conservar y evaluar juntos los alias antiguos y los códigos cortos nuevos.");
        }
        pasa("Las fórmulas antiguas conservan compatibilidad y comparten anclas con nuevos códigos cortos en borradores, JSON y SQLite");
    }

    private static void CodigosAlternativos(Action<string> pasa)
    {
        var (_, p, destino, origen) = Nuevo();
        p.Item = new string('9', 100); origen.Item = ""; origen.CodigoDelphin = "CON-210";
        string referencia = MYGReferenciasMetrado.CrearReferencia(destino.Costos.Hoja, p, origen, "B3");
        Exige(referencia.Length < 50 && destino.Costos.Hoja.ReferenciasPartidas.Single().Alias.EndsWith("/CON-210") &&
            MYGReferenciasMetrado.CrearReferencia(destino.Costos.Hoja, p, origen, "B3") == referencia,
            "Una partida sin ítem debe usar su código de catálogo y un presupuesto sin código breve debe recibir uno estable.");
        origen.CodigoDelphin = "";
        var otraHoja = MYGHojaMetrado.Crear();
        string sinItem = MYGReferenciasMetrado.CrearReferencia(otraHoja, p, origen, "B3");
        otraHoja.Poner("B3", "=" + sinItem);
        Exige(sinItem.Length < 50 && new MYGHojaCalculo(otraHoja).Numero("B3") == 7,
            "Cuando falta tanto ítem como código de catálogo, el código breve interno debe seguir resolviendo el metrado.");
        pasa("Los metrados sin numeración y los códigos excesivamente largos reciben referencias breves estables");
    }
}
