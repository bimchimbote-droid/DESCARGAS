using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class UnidadesDelphinCheck
{
    private const string ColumnasUnidad = "id_unidad,descripcion_unidad,descripcion_singular,orden,operador_fecha," +
        "cantidad_fecha,magnitud_unidad,id_unidadbase,es_unidadcosto,es_unidadtiempo,en_cronograma,es_unidadgasto," +
        "es_dependiente,id_tipocostodependencia,informacion_unidad,tipo_unidad,divisible,abreviatura_unidad,codigo_sunat,es_sistema";

    // Huellas obtenidas independientemente del catálogo técnico de la base nativa.
    // Incluyen todas las columnas, distinguen NULL de cadena vacía y no requieren
    // copiar una base externa ni disponer de los adjuntos al ejecutar las pruebas.
    private static readonly Dictionary<string, (string Columnas, string Huella)> CatalogoNativo = new()
    {
        ["unidad"] = (ColumnasUnidad, "B2C22002530A05D5D4C501C2B372702A8437946E80551072B97E3C22DDF644BC"),
        ["unidad_tipocosto"] = ("id_unidad,id_tipocosto", "7346D83F8427D563371067EB7C9C1C7B7DFC0194F7874ECE1BD2E27249E14F7B"),
        ["unidad_tipocostonew"] = ("id_unidad,id_tipocosto", "8E95E067246408B12F6D249440CC24D0AFD618BA5E63A4C4168565F7FAFECBD5")
    };

    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly,
            Pooling = false, ForeignKeys = true }.ToString());
        c.Open(); return c;
    }

    private static object Valor(string ruta, string sql, params object[] parametros)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand(); cmd.CommandText = sql;
        for (int n = 0; n < parametros.Length; n++) cmd.Parameters.AddWithValue("$p" + n, parametros[n] ?? DBNull.Value);
        return cmd.ExecuteScalar();
    }

    private static string Campo(object valor) => valor == DBNull.Value ? "-" : valor is string texto ?
        "S" + Convert.ToHexString(Encoding.UTF8.GetBytes(texto)) :
        "N" + Convert.ToString(valor, CultureInfo.InvariantCulture);

    private static string Huella(string ruta, string sql, params object[] parametros)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand(); cmd.CommandText = sql;
        for (int n = 0; n < parametros.Length; n++) cmd.Parameters.AddWithValue("$p" + n, parametros[n] ?? DBNull.Value);
        using var r = cmd.ExecuteReader(); var filas = new List<string>();
        while (r.Read())
            filas.Add(string.Join("|", Enumerable.Range(0, r.FieldCount).Select(n => Campo(r.GetValue(n)))));
        filas.Sort(StringComparer.Ordinal);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("\n", filas))));
    }

    internal static Dictionary<string, string> Capturar(string ruta) => CatalogoNativo.ToDictionary(
        entrada => entrada.Key, entrada => Huella(ruta, "SELECT " + entrada.Value.Columnas + " FROM " + entrada.Key));

    internal static void Conservar(string ruta, Dictionary<string, string> originales)
    {
        var actuales = Capturar(ruta);
        foreach (var original in originales)
            Exige(actuales[original.Key] == original.Value,
                "Guardar una obra o catálogo reinicializó unidades o metadatos nativos: " + original.Key + ".");
    }

    internal static void RetirarUnidadSintetica(string ruta)
    {
        // Esta hoja acaba de generarse para la prueba. Simula una baja anterior
        // para detectar si abrir/escribir una base existente reintroduce el catálogo.
        using var c = Conexion(ruta, true); using var cmd = c.CreateCommand();
        cmd.CommandText = """
            DELETE FROM unidad_tipocosto WHERE id_unidad='UN0000000099';
            DELETE FROM unidad_tipocostonew WHERE id_unidad='UN0000000099';
            DELETE FROM catalogo_unidad WHERE id='UN0000000099';
            DELETE FROM unidad WHERE id_unidad='UN0000000099';
            """;
        cmd.ExecuteNonQuery();
    }

    internal static void Ejecutar(string ruta, string carpeta, Action<string> pasa)
    {
        var actual = Capturar(ruta);
        foreach (var tabla in CatalogoNativo)
            Exige(actual[tabla.Key] == tabla.Value.Huella,
                "La hoja nueva no reproduce exactamente las unidades y relaciones nativas: " + tabla.Key + ".");
        Exige(Convert.ToInt64(Valor(ruta, "SELECT ultimo_numero FROM secuencia WHERE nombre_secuencia='id_unidad'")) == 99,
            "La secuencia de unidades puede repetir los identificadores nativos iniciales.");
        Exige(Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM unidad WHERE id_unidadbase=id_unidad")) > 0 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM unidad WHERE tipo_unidad='P' AND es_dependiente='S'")) == 6 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM unidad WHERE tipo_unidad='P' AND COALESCE(id_tipocostodependencia,'')<>''")) == 3,
            "Las unidades base o los porcentajes dependientes perdieron su configuración nativa.");
        pasa("Hoja nueva reproduce las 62 unidades Delphin, sus 20 columnas y las 53/97 relaciones nativas, con secuencia válida");

        string antesLeer = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
        var unidades = MYGCatalogoUnidades.Listar(ruta);
        Exige(unidades.Count == 62 && unidades.Select(u => u.Id).Distinct(StringComparer.Ordinal).Count() == 62,
            "MYG perdió identidades al leer unidades con abreviaturas compartidas.");
        var esperados = new Dictionary<string, int> { ["N"] = 42, ["G"] = 10, ["P"] = 6, ["H"] = 3, ["D"] = 1 };
        foreach (var tipo in esperados)
            Exige(unidades.Count(u => u.Tipo == tipo.Key) == tipo.Value, "El tipo de unidad " + tipo.Key + " no coincide con Delphin.");
        Exige(unidades.Count(u => u.EsCostoUnitario) == 56 && unidades.Count(u => u.EsGastoGeneral) == 17,
            "Los filtros de costos unitarios y gastos generales no usan las marcas nativas.");
        foreach (string simbolo in new[] { "m", "m²", "m³", "mes", "und" })
            Exige(unidades.Count(u => u.Simbolo == simbolo) == 2 &&
                unidades.Single(u => u.Simbolo == simbolo && u.Tipo == "N").Id !=
                unidades.Single(u => u.Simbolo == simbolo && u.Tipo == "G").Id,
                "Se fusionaron las variantes General y Global de " + simbolo + ".");
        Exige(unidades.Count(u => u.Simbolo == "dia") == 3 &&
            unidades.Where(u => u.Simbolo == "dia").Select(u => u.Tipo).OrderBy(x => x).SequenceEqual(new[] { "D", "G", "N" }),
            "Se perdieron las variantes General, Global o Día de trabajo de dia.");
        var nombres = new Dictionary<string, string>
        { ["N"] = "General", ["G"] = "Global", ["P"] = "Porcentaje", ["H"] = "Hora de trabajo", ["D"] = "Día de trabajo" };
        Exige(unidades.All(u => u.TipoDescripcion == nombres[u.Tipo]), "Los nombres de los tipos no corresponden al catálogo Delphin.");
        ComprobarTiposCosto(ruta, unidades);
        Exige(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta))) == antesLeer,
            "Leer el catálogo nativo escribió cambios en la hoja.");
        pasa("MYG muestra todas las variantes por identidad y aplica los tipos y filtros nativos de unidades");
        ComprobarEdicionYCopia(carpeta, pasa);
    }

    private static void ComprobarTiposCosto(string ruta, List<MYGUnidadCatalogo> unidades)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT id_unidad,id_tipocosto FROM unidad_tipocostonew
            UNION SELECT a.id_unidad,a.id_tipocosto FROM unidad_tipocosto a
                WHERE NOT EXISTS(SELECT 1 FROM unidad_tipocostonew n WHERE n.id_unidad=a.id_unidad)
            """;
        var esperados = unidades.ToDictionary(u => u.Id, _ => new HashSet<MYGGrupoRecurso>());
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            MYGGrupoRecurso tipo = r.GetString(1) switch
            {
                "TC0000000001" => MYGGrupoRecurso.ManoObra,
                "TC0000000002" => MYGGrupoRecurso.Materiales,
                "TC0000000003" => MYGGrupoRecurso.Equipo,
                "TC0000000004" => MYGGrupoRecurso.Subcontratos,
                "TC0000000005" => MYGGrupoRecurso.Subpartidas,
                _ => throw new Exception("El catálogo inicial contiene un tipo de costo inesperado.")
            };
            esperados[r.GetString(0)].Add(tipo);
        }
        foreach (var unidad in unidades)
            Exige(esperados[unidad.Id].SetEquals(unidad.TiposCosto),
                "El filtro por tipo de costo perdió las relaciones nativas de la unidad " + unidad.Id + ".");
    }

    private static void Rechaza(Action accion, string detalle)
    {
        bool error = false;
        try { accion(); }
        catch (InvalidDataException) { error = true; }
        catch (InvalidOperationException) { error = true; }
        Exige(error, detalle);
    }

    private static void ComprobarEdicionYCopia(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Edición sintética de variantes Delphin.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        var global = MYGCatalogoUnidades.Listar(ruta).Single(u => u.Id == "UN0000000074");
        string generalAntes = Huella(ruta, "SELECT " + ColumnasUnidad + " FROM unidad WHERE id_unidad='UN0000000003'");
        string columnasSinDescripcion = string.Join(",", ColumnasUnidad.Split(',').Where(c => c != "informacion_unidad"));
        string globalAntes = Huella(ruta, "SELECT " + columnasSinDescripcion + " FROM unidad WHERE id_unidad=$p0", global.Id);
        var relaciones = Capturar(ruta);
        global.Descripcion = "Metro cuadrado global sintético";
        MYGCatalogoUnidades.Guardar(ruta, global);
        Exige((string)Valor(ruta, "SELECT informacion_unidad FROM unidad WHERE id_unidad=$p0", global.Id) == global.Descripcion &&
            Huella(ruta, "SELECT " + ColumnasUnidad + " FROM unidad WHERE id_unidad='UN0000000003'") == generalAntes &&
            Huella(ruta, "SELECT " + columnasSinDescripcion + " FROM unidad WHERE id_unidad=$p0", global.Id) == globalAntes,
            "Editar una descripción global modificó la variante general o los metadatos nativos.");
        var despues = Capturar(ruta);
        Exige(relaciones["unidad_tipocosto"] == despues["unidad_tipocosto"] &&
            relaciones["unidad_tipocostonew"] == despues["unidad_tipocostonew"],
            "Editar una descripción cambió las asociaciones con los tipos de costo.");
        string antesError = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
        Rechaza(() => MYGCatalogoUnidades.Eliminar(ruta, global.Id), "Eliminar una unidad nativa rompió sus variantes.");
        global.Simbolo = "SYN_RENOMBRE_NATIVO";
        Rechaza(() => MYGCatalogoUnidades.Guardar(ruta, global), "Renombrar una unidad nativa rompió sus variantes.");
        Exige(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta))) == antesError,
            "Rechazar una modificación nativa no revirtió todos sus cambios.");
        pasa("Editar una variante por identidad conserva las demás y rechazar su eliminación o renombrado conserva la hoja");

        var propia = MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo
        {
            Simbolo = "SYN_VARIANTE", Descripcion = "Unidad propia sintética"
        });
        propia.Simbolo = "SYN_VARIANTE_EDITADA";
        propia.Descripcion = "Unidad propia editada sintética";
        MYGCatalogoUnidades.Guardar(ruta, propia);
        var leida = MYGCatalogoUnidades.Listar(ruta).Single(u => u.Id == propia.Id);
        Exige(leida.Simbolo == propia.Simbolo && leida.Descripcion == propia.Descripcion && leida.Tipo == "N" &&
            leida.EsCostoUnitario && leida.EsGastoGeneral &&
            new HashSet<MYGGrupoRecurso>(leida.TiposCosto).SetEquals(Enum.GetValues<MYGGrupoRecurso>()) &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad='SYN_VARIANTE'")) == 0,
            "Guardar y editar una unidad propia perdió su tipo, marcas o relaciones nativas.");
        var baja = MYGCatalogoUnidades.Guardar(ruta,
            new MYGUnidadCatalogo { Simbolo = "SYN_BAJA", Descripcion = "Unidad sintética para eliminar" });
        MYGCatalogoUnidades.Eliminar(ruta, baja.Id);
        Exige(!MYGCatalogoUnidades.Listar(ruta).Any(u => u.Id == baja.Id) &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad='SYN_BAJA'")) == 0,
            "Eliminar una unidad propia dejó filas nativas.");
        RetirarUnidadSintetica(ruta);
        var unidadesAntes = Capturar(ruta);
        var documento = MYGProyectoStorage.Nuevo("OBRA SINTÉTICA PARA GUARDAR COMO");
        MYGBaseDatos.GuardarProyecto(ruta, documento);
        Conservar(ruta, unidadesAntes);
        string copia = Path.Combine(carpeta, "Guardar como sintético con unidades Delphin.sqlite");
        MYGBaseDatos.GuardarProyecto(copia, documento, ruta);
        Conservar(copia, unidadesAntes);
        var origen = MYGCatalogoUnidades.Listar(ruta);
        var destino = MYGCatalogoUnidades.Listar(copia);
        Exige(destino.Count == origen.Count && destino.All(u => origen.Any(o =>
            o.Id == u.Id && o.Simbolo == u.Simbolo && o.Descripcion == u.Descripcion && o.Tipo == u.Tipo &&
            o.EsCostoUnitario == u.EsCostoUnitario && o.EsGastoGeneral == u.EsGastoGeneral &&
            new HashSet<MYGGrupoRecurso>(o.TiposCosto).SetEquals(u.TiposCosto))) &&
            !destino.Any(u => u.Id == "UN0000000099"),
            "Guardar como reinicializó unidades dadas de baja o perdió tipos, variantes o identidades.");
        Exige((string)Valor(copia, "PRAGMA integrity_check") == "ok" &&
            Valor(copia, "PRAGMA foreign_key_check") == null,
            "Guardar como produjo relaciones inválidas en el catálogo.");
        pasa("Unidades propias conservan tipo y grupos al editar; guardar como conserva variantes, metadatos y bajas sin reintroducir el catálogo");
    }
}
