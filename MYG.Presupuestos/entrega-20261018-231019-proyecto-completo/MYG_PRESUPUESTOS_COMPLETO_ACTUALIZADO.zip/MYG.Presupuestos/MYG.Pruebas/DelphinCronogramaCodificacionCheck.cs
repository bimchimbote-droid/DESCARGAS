using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinCronogramaCodificacionCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Codificación Delphin: " + mensaje); }

    internal static void Ejecutar(Action<string> pasa)
    {
        SQLiteDependencyBootstrapper.Initialize();
        using var c = new SqliteConnection("Data Source=:memory:"); c.Open();
        using (var cmd = c.CreateCommand())
        {
            // Reproducción mínima anonimizada del esquema antiguo sin
            // duracion_new: 1 significa automática, independientemente de la
            // posición de los valores del enum interno de MYG.
            cmd.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,task_mode INTEGER,
                    es_hito TEXT,fecha_inicio TEXT,fecha_fin TEXT);
                INSERT INTO costo_unitario VALUES
                    ('CU-A',1,1,'N','2023-05-02 08:00:00','2023-05-02 17:00:00'),
                    ('CU-B',2,1,'N','2023-05-03 08:00:00','2023-05-04 17:00:00'),
                    ('CU-C',1,0,'N','2023-05-05 08:00:00','2023-05-05 17:00:00');
                CREATE TABLE programacion_costo(id_programacion TEXT,id_costounitario TEXT,numero_periodo INTEGER,
                    duracion INTEGER,duracion_base NUMERIC,start_date TEXT,end_date TEXT);
                INSERT INTO programacion_costo VALUES
                    ('PG-A','CU-A',0,1,NULL,'2023-05-02 08:00:00','2023-05-02 17:00:00'),
                    ('PG-B','CU-B',0,2,NULL,'2023-05-03 08:00:00','2023-05-04 17:00:00');
                PRAGMA query_only=ON;
                """;
            cmd.ExecuteNonQuery();
        }
        var p = new MYGPresupuestoDocumento { Id = "PP-QA", Nombre = "Prueba", Item = "01" };
        foreach (string id in new[] { "CU-A", "CU-B", "CU-C" })
            p.Items.Add(new() { Id = id, IdLocalMYG = id, IdInternoDelphin = id,
                Item = id, Descripcion = "Tarea de prueba " + id, TipoPropuesta = "PARTIDA", Unidad = "und" });
        var doc = new MYGProyectoDocumento { Id = "PR-QA", Nombre = "Prueba", Presupuestos = new() { p },
            PresupuestoActivoId = p.Id, Datos = new() { FechaInicio = new DateTime(2023, 5, 1) } };
        string antes = JsonSerializer.Serialize(doc);
        var plan = DelphinCronogramaMYG.Leer(c, doc);
        var filas = MYGMotorCronograma.Calcular(plan).Filas.Where(f => !f.Tarea.EsResumen).ToDictionary(f => f.Tarea.PartidaId);
        Exige(filas["CU-A"].Tarea.Modo == MYGModoTarea.Automatica && filas["CU-B"].Tarea.Modo == MYGModoTarea.Automatica &&
            filas["CU-C"].Tarea.Modo == MYGModoTarea.Manual, "se invirtió el modo nativo 1/0 al usar el enum interno.");
        pasa("Regresión del esquema CHUMUCH: task_mode 1 importa Automática y 0 Manual sin convertir indiscriminadamente todas las tareas");
        Exige(filas["CU-A"].DuracionDias == 1 && filas["CU-A"].Inicio == new DateTime(2023, 5, 2) && filas["CU-A"].Fin == filas["CU-A"].Inicio &&
            filas["CU-B"].DuracionDias == 2 && filas["CU-B"].Fin == new DateTime(2023, 5, 4) && JsonSerializer.Serialize(doc) == antes,
            "la lectura duplicó el día de una tarea o redujo a uno una tarea de dos días.");
        pasa("Una tarea nativa de un día sigue durando un día y otra de dos conserva ambos, sin cambiar el documento de origen");
        string ruta = Environment.GetEnvironmentVariable("MYG_QA_CHUMUCH_SQLITE");
        if (!string.IsNullOrWhiteSpace(ruta)) VerificarReal(ruta, pasa);
    }

    private static void VerificarReal(string ruta, Action<string> pasa)
    {
        string Huella() => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
        string antes = Huella();
        var doc = MYGBaseDatos.LeerProyecto(ruta);
        var filas = MYGMotorCronograma.Calcular(doc.Cronograma).Filas.Where(f => !f.Tarea.EsResumen).ToDictionary(f => f.Tarea.PartidaId);
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString()); c.Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT id_costounitario,task_mode,duracion,fecha_inicio,fecha_fin FROM costo_unitario";
        int verificadas = 0;
        using (var r = cmd.ExecuteReader())
            while (r.Read())
            {
                if (!filas.TryGetValue(r.GetString(0), out var fila)) continue;
                Exige(r.GetInt32(1) == 1 && fila.Tarea.Modo == MYGModoTarea.Automatica &&
                    fila.DuracionDias == r.GetInt32(2) &&
                    fila.Inicio == DateTime.Parse(r.GetString(3), CultureInfo.InvariantCulture).Date &&
                    fila.Fin == DateTime.Parse(r.GetString(4), CultureInfo.InvariantCulture).Date,
                    "el resultado de una tarea no coincide con los datos nativos de la muestra externa.");
                verificadas++;
            }
        Exige(verificadas > 0 && verificadas == filas.Count && Huella() == antes,
            "la muestra no verificó todas sus tareas o el archivo de origen cambió.");
        pasa("CHUMUCH real: " + verificadas + " tareas verificadas contra modo, duración, inicio y fin nativos; SHA-256 original intacto");
        var modelo = MYGExportacionCronograma.PrepararProject(doc, doc.Cronograma, incluirRecursos: false);
        Exige(modelo.Tareas.Where(t => !t.Resumen).All(t => !t.Manual) && Huella() == antes,
            "el modelo Project volvió a convertir las tareas nativas automáticas en manuales o cambió el archivo.");
        pasa("CHUMUCH real conserva el modo automático al preparar el modelo de exportación a Project sin modificar el SQLite");
    }
}
