using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using MYG_2027;

internal static class CargarDataCheck
{
    private static void Exige(bool ok, string texto) { if (!ok) throw new Exception(texto); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Rechaza<T>(Action accion) where T : Exception
    { bool error = false; try { accion(); } catch (T) { error = true; } Exige(error, "No rechaza " + typeof(T).Name); }
    private static MYGDataFiltrosArchivo Archivo(params ConfiguracionTablaPlanificacion[] c) =>
        new MYGDataFiltrosArchivo { TotalRegistros = c.Length, Configuraciones = c.ToList() };
    private static MYGDataFiltrosSolicitud Solicitud(ConfiguracionTablaPlanificacion c, ItemPresupuestoDelphin i) =>
        new MYGDataFiltrosSolicitud { Registro = c, Destino = i };
    private static ItemPresupuestoDelphin Destino(ConfiguracionTablaPlanificacion c, string id = null) =>
        new ItemPresupuestoDelphin { Id = id ?? c.IdInterno, IdInternoDelphin = id ?? c.IdInterno,
            IdLocalMYG = MYGProyectoStorage.NuevoId(), Item = c.Item, Descripcion = c.Partida, Unidad = c.Unidad,
            TipoPropuesta = "PARTIDA", Origen = "DELPHIN", Estado = "OFICIAL" };
    private static string Estructura(ItemPresupuestoDelphin i)
    {
        var excluidas = new HashSet<string> { "Plantilla", "Filtros", "Parametro", "Regla", "Valor",
            "IdConfiguracionBibliotecaMYG", "EstadoRevit", "MensajeRevit" };
        return JsonSerializer.Serialize(typeof(ItemPresupuestoDelphin).GetProperties()
            .Where(p => !excluidas.Contains(p.Name)).ToDictionary(p => p.Name, p => p.GetValue(i)));
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string antiguo = Environment.GetEnvironmentVariable("MYG_QA_LEGACY_JSON");
        if(string.IsNullOrWhiteSpace(antiguo))antiguo=CrearEjemplo(carpeta);
        Exige(File.Exists(antiguo), "No existe el JSON indicado.");
        string huellaOriginal = Huella(antiguo);
        var data = MYGDataFiltrosStorage.Leer(antiguo);
        Exige(data.TotalRegistros == 220 && data.Configuraciones.Count == 94 && data.SinConfiguracion == 126,
            "Lectura incorrecta de el JSON de entrada.");
        var primero = data.Configuraciones.First();
        var doble = data.Configuraciones.Single(c => c.IdInterno == "CU0000008810");
        Exige(primero.Filtros.Count == 1 && primero.Filtros[0].Valor == "Refine, nivelación y compactación" &&
            doble.Filtros.Count == 2 && doble.Filtros[0].Parametro == "STR_AnfitriónAcero" &&
            doble.Filtros[1].Valor == "Cerco perimétrico" && data.Configuraciones.Count(c => c.Filtros.Count == 2) == 20,
            "Se alteró texto, acentos u orden de filtros reales.");
        pasa("JSON antiguo: 220 registros, 94 configurados y 20 configuraciones con dos filtros activos");

        var iguales = data.Configuraciones.Select(c => Destino(c)).ToList();
        var coincidencias = MYGDataFiltrosStorage.Sugerir(data, iguales);
        Exige(coincidencias.Count == 94 && coincidencias.All(c => c.Segura && c.Destino != null &&
            c.Destino.Id == c.Registro.IdInterno), "No reconoce los IDs verificados con descripción y unidad.");
        pasa("La importación reconoce IDs antiguos solo junto con descripción y unidad compatibles");

        var cambiados = data.Configuraciones.Select((c, n) => Destino(c, "CU-NUEVA-OBRA-" + n)).ToList();
        coincidencias = MYGDataFiltrosStorage.Sugerir(data, cambiados);
        Exige(coincidencias.All(c => c.Segura && c.Destino != null && c.Destino.Item == c.Registro.Item),
            "No sugiere las correspondencias únicas cuando cambian los IDs.");
        var nombre = Destino(primero, "CU-SIN-ITEM"); nombre.Item = "99.99";
        nombre.Descripcion = "  " + primero.Partida.ToLowerInvariant().Replace(" ", "  ") + "  "; nombre.Unidad = "m2";
        Exige(MYGDataFiltrosStorage.Sugerir(Archivo(primero), new[] { nombre }).Single().Segura,
            "No reconoce descripción única con espacios/capitalización o notación de unidad.");
        pasa("IDs cambiados admiten correspondencias por ítem y descripción, o descripción y unidad únicas");

        var curados = data.Configuraciones.Where(c => c.Partida == "CURADO DE CONCRETO CON ADITIVO QUÍMICO").ToArray();
        var unicoCurado = Destino(curados[0], "CU-CURADO-OTRA-OBRA"); unicoCurado.Item = "99.98";
        coincidencias = MYGDataFiltrosStorage.Sugerir(Archivo(curados), new[] { unicoCurado });
        Exige(curados.Length == 19 && coincidencias.All(c => !c.Segura && c.Destino == null),
            "Asignó 19 usos distintos de curado a una partida por el nombre repetido.");
        var dosIguales = MYGProyectoStorage.Copia(primero);
        coincidencias = MYGDataFiltrosStorage.Sugerir(Archivo(primero, dosIguales), new[] { iguales[0] });
        Exige(coincidencias.All(c => !c.Segura), "Marca dos configuraciones para la misma partida destino.");
        pasa("Descripciones repetidas y varios registros para un destino requieren elección manual");

        var colision = Destino(primero); colision.Descripcion = "PARTIDA DIFERENTE"; colision.CodigoDelphin = primero.CodigoDelphin;
        Exige(MYGDataFiltrosStorage.Sugerir(Archivo(primero), new[] { colision }).Single().Destino == null,
            "Confía en un ID con otra descripción.");
        var unidad = Destino(primero); unidad.Unidad = "m³";
        Exige(MYGDataFiltrosStorage.Sugerir(Archivo(primero), new[] { unidad }).Single().Destino == null,
            "Sugiere una unidad incompatible.");
        var otraBase = MYGProyectoStorage.Copia(primero); otraBase.FuenteCatalogoId = "BASE-ANTIGUA";
        var deOtraBase = Destino(otraBase); deOtraBase.FuenteCatalogoId = "BASE-NUEVA";
        Exige(!MYGDataFiltrosStorage.Sugerir(Archivo(otraBase), new[] { deOtraBase }).Single().Segura,
            "Confía en identidades conocidas de bases diferentes.");
        var sinUnidad = MYGProyectoStorage.Copia(primero); sinUnidad.Unidad = null;
        Exige(!MYGDataFiltrosStorage.Sugerir(Archivo(sinUnidad), new[] { iguales[0] }).Single().Segura,
            "Marca automáticamente un registro sin unidad conocida.");
        pasa("IDs con otra descripción, unidades distintas, otra base y unidades ausentes no se aceptan automáticamente");

        var receptor = Destino(doble, "CU-OFICIAL-ACTUAL"); receptor.ParentId = "TITULO-ACTUAL";
        receptor.IdAnalisisDelphin = receptor.IdCatalogoDelphin = "AC-ACTUAL"; receptor.FuenteCatalogoId = "BASE-ACTUAL";
        receptor.FuenteCatalogoRuta = "BASE-ACTUAL.sqlite"; receptor.CodigoDelphin = "9999";
        receptor.Item = "09.07.01"; receptor.Posicion = 17; receptor.Estado = "PROP. MODIFICAR";
        receptor.PartidaOriginal = "PARTIDA OFICIAL"; receptor.PartidaPropuesta = "PROPUESTA ACTUAL";
        receptor.UnidadOriginal = receptor.Unidad; receptor.UnidadPropuesta = receptor.Unidad;
        receptor.IdConfiguracionBibliotecaMYG = "PERFIL-ANTERIOR"; receptor.EstadoRevit = "REVISADA";
        receptor.MensajeRevit = "Temporal";
        var otra = Destino(primero, "CU-NO-SELECCIONADA"); otra.Plantilla = "PLANTILLA PROPIA";
        otra.Filtros.Add(new FiltroPlanificacion { Parametro = "Nivel", Regla = "es igual a", Valor = "Piso 3" });
        var filas = new List<ItemPresupuestoDelphin> { receptor, otra };
        string estructura = Estructura(receptor), estadoOtra = JsonSerializer.Serialize(otra);
        MYGDataFiltrosStorage.Aplicar(new[] { Solicitud(doble, receptor) });
        Exige(Estructura(receptor) == estructura && filas.Count == 2 && JsonSerializer.Serialize(otra) == estadoOtra &&
            receptor.Plantilla == doble.Plantilla && receptor.Filtros.Count == 2 &&
            receptor.Valor == doble.Filtros[0].Valor && receptor.IdConfiguracionBibliotecaMYG == null &&
            receptor.EstadoRevit == null && receptor.MensajeRevit == null, "La importación cambió datos estructurales o filas no seleccionadas.");
        receptor.Filtros[1].Valor = "Cambio exclusivo del proyecto";
        Exige(doble.Filtros[1].Valor == "Cerco perimétrico", "Comparte por referencia los filtros antiguos.");
        receptor.Filtros[1].Valor = doble.Filtros[1].Valor;
        pasa("Aplicar solo modifica datos BIM; conserva jerarquía, IDs, propuestas, catálogo y filas ajenas con copias independientes");

        var a = Destino(primero, "CU-LOTE-A"); var b = Destino(primero, "CU-LOTE-B");
        string inicialA = JsonSerializer.Serialize(a);
        Rechaza<InvalidDataException>(() => MYGDataFiltrosStorage.Aplicar(new[] { Solicitud(primero, a), Solicitud(doble, a) }));
        Rechaza<InvalidDataException>(() => MYGDataFiltrosStorage.Aplicar(new[] { Solicitud(primero, a), Solicitud(doble, b) }));
        var invalido = MYGProyectoStorage.Copia(primero); invalido.Filtros[0].Regla = null;
        Rechaza<InvalidDataException>(() => MYGDataFiltrosStorage.Aplicar(new[] { Solicitud(primero, a), Solicitud(invalido, b) }));
        var sinPlantilla = MYGProyectoStorage.Copia(primero); sinPlantilla.Plantilla = null;
        Rechaza<InvalidDataException>(() => MYGDataFiltrosStorage.Aplicar(new[] { Solicitud(primero, a), Solicitud(sinPlantilla, b) }));
        b.TipoPropuesta = "TITULO";
        Rechaza<InvalidDataException>(() => MYGDataFiltrosStorage.Aplicar(new[] { Solicitud(primero, a), Solicitud(primero, b) }));
        Exige(JsonSerializer.Serialize(a) == inicialA, "Un lote inválido importó parcialmente la primera fila.");
        pasa("Lotes inválidos por destino duplicado, unidad, filtros incompletos, falta de plantilla o título no aplican parcialmente");

        string viejoSimple = Path.Combine(carpeta, "filtros antiguos simples.json");
        var simple = new ConfiguracionTablaPlanificacion { Item = "01", Partida = "FILTRO ANTIGUO", Unidad = "m²",
            Parametro = "Descripción", Regla = "comienza por", Valor = "ÁREA EXTERIOR",
            Filtros = new List<FiltroPlanificacion> { new FiltroPlanificacion(), null } };
        File.WriteAllText(viejoSimple, JsonSerializer.Serialize(new[] { simple, null,
            new ConfiguracionTablaPlanificacion(), new ConfiguracionTablaPlanificacion { TipoPropuesta = "TITULO", Plantilla = "NO APLICAR" } }));
        var simples = MYGDataFiltrosStorage.Leer(viejoSimple);
        Exige(simples.TotalRegistros == 4 && simples.Configuraciones.Count == 1 && simples.SinConfiguracion == 3 &&
            simples.Configuraciones[0].Filtros.Count == 1 && simples.Configuraciones[0].Filtros[0].Valor == "ÁREA EXTERIOR",
            "Pierde campos antiguos simples o importa registros vacíos/títulos.");
        var conservaPlantilla = Destino(simple, "CU-SIMPLE"); conservaPlantilla.Plantilla = "PLANTILLA DEL PROYECTO";
        MYGDataFiltrosStorage.Aplicar(new[] { Solicitud(simples.Configuraciones[0], conservaPlantilla) });
        Exige(conservaPlantilla.Plantilla == "PLANTILLA DEL PROYECTO", "Borra la plantilla cuando el JSON solo tiene filtros.");
        pasa("Compatibilidad con campos Parametro/Regla/Valor; filas vacías y títulos se omiten y una plantilla local se conserva");

        string ajeno = Path.Combine(carpeta, "archivo incompatible.json");
        File.WriteAllText(ajeno, JsonSerializer.Serialize(MYGProyectoStorage.Nuevo("PROYECTO COMPLETO")));
        Rechaza<InvalidDataException>(() => MYGDataFiltrosStorage.Leer(ajeno));
        File.WriteAllText(ajeno, JsonSerializer.Serialize(new MYGBibliotecaDocumento()));
        Rechaza<InvalidDataException>(() => MYGDataFiltrosStorage.Leer(ajeno));
        File.WriteAllText(ajeno, "[{malformado]"); Rechaza<JsonException>(() => MYGDataFiltrosStorage.Leer(ajeno));
        Exige(Estructura(receptor) == estructura, "Leer un archivo incompatible alteró el proyecto actual.");
        pasa("Cargar Data rechaza proyectos completos, bibliotecas y JSON malformado sin reemplazar el proyecto abierto");

        string banco = Path.Combine(carpeta, "Filtros importados.biblioteca.json");
        var biblioteca = MYGProyectoStorage.LeerBiblioteca(banco);
        biblioteca = MYGBibliotecaPartidas.GuardarConfiguraciones(banco, biblioteca,
            new[] { new MYGGuardarConfiguracionSolicitud { Partida = receptor, Nombre = "Acero — exteriores" } });
        var perfil = biblioteca.Configuraciones.Single(); var referencia = perfil.Referencias.Single();
        Exige(referencia.FuenteId == "BASE-ACTUAL" && referencia.IdAnalisis == "AC-ACTUAL" &&
            perfil.Filtros.Count == 2 && perfil.Filtros[1].Valor == "Cerco perimétrico", "Guardar filtros usa la identidad del JSON antiguo.");
        var siguiente = Destino(doble, "CU-SIGUIENTE-PRESUPUESTO"); siguiente.IdAnalisisDelphin = "AC-ACTUAL";
        siguiente.FuenteCatalogoId = "BASE-ACTUAL"; siguiente.Item = "20.01";
        Exige(MYGBibliotecaPartidas.AplicarUnica(MYGProyectoStorage.LeerBiblioteca(banco), siguiente) &&
            siguiente.Id == "CU-SIGUIENTE-PRESUPUESTO" && siguiente.Item == "20.01" && siguiente.Filtros.Count == 2 &&
            siguiente.Filtros[1].Valor == "Cerco perimétrico", "No reutiliza en la siguiente obra lo importado y guardado.");
        pasa("Importar y Guardar filtros usa el análisis actual y permite traerlos en otra obra con una nueva fila Delphin");

        var proyecto = MYGProyectoStorage.Nuevo("PROYECTO RECEPTOR"); receptor.ParentId = null;
        proyecto.Presupuestos[0].CantidadFiltros = 2; proyecto.Presupuestos[0].Items.Add(receptor);
        string archivoProyecto = Path.Combine(carpeta, "Proyecto con data importada.myg.json");
        MYGProyectoStorage.Guardar(archivoProyecto, proyecto);
        var reabierto = MYGProyectoStorage.Leer(archivoProyecto).Presupuestos[0].Items.Single();
        Exige(reabierto.Id == receptor.Id && reabierto.IdCatalogoDelphin == "AC-ACTUAL" &&
            reabierto.Filtros.Count == 2 && reabierto.IdConfiguracionBibliotecaMYG == perfil.Id &&
            Huella(antiguo) == huellaOriginal, "Reabrir pierde los filtros importados o cambió el JSON de entrada.");
        pasa("Guardar y reabrir el proyecto mantiene los filtros importados y el JSON de entrada permanece intacto");
    }
    private static string CrearEjemplo(string carpeta)
    {
        var filas=new List<ConfiguracionTablaPlanificacion>();
        for(int n=0;n<220;n++)
        {
            bool activo=n<94;
            var c=new ConfiguracionTablaPlanificacion{IdInterno=n==1?"CU0000008810":"QA-"+n,
                Item="01."+n.ToString("D3"),Partida=n>=30 && n<49?"CURADO DE CONCRETO CON ADITIVO QUÍMICO":"PARTIDA DE PRUEBA "+n,
                Unidad=n==1?"kg":"m²",Plantilla=activo?"PLANTILLA DE PRUEBA":null};
            if(activo)c.Filtros.Add(new(){Parametro="Descripción",Regla="es igual a",Valor=n==0?"Refine, nivelación y compactación":"Valor "+n});
            if(n>=1 && n<=20)c.Filtros.Add(new(){Parametro="Nivel",Regla="es igual a",Valor="Piso 1"});
            if(n==1){c.Filtros[0].Parametro="STR_AnfitriónAcero";c.Filtros[1].Valor="Cerco perimétrico";}
            filas.Add(c);
        }
        string archivo=Path.Combine(carpeta,"Filtros antiguos de prueba.json");
        File.WriteAllText(archivo,JsonSerializer.Serialize(filas));return archivo;
    }

}
