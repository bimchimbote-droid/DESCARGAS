using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinRecursosCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Recursos y factores nativos Delphin.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            c.Open(); using var cmd = c.CreateCommand();
            cmd.CommandText = """
                DROP TABLE catalogo_insumo;
                INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,decimales_costo,decimales_cantidad)
                    VALUES('PR-RECURSOS','US0000000001','IN0000000001','No','OBRA SINTÉTICA DE RECURSOS',0,0);
                INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,numeracion_presupuesto,posicion_presupuesto)
                    VALUES('PP-RECURSOS','PR-RECURSOS','PRESUPUESTO DE RECURSOS','1',1);
                INSERT INTO producto(id_producto,descripcion_producto,id_unidad,id_categoria,codigo_clase,codigo_subclase,codigo_producto,costo_unitario,descripcion_proveedor)
                    VALUES('LP-OBRERO','OBRERO SINTÉTICO','UN0000000002','TC0000000001','47','001','0001',10,'PROVEEDOR DEL PRODUCTO');
                INSERT INTO producto(id_producto,descripcion_producto,id_unidad,id_categoria,codigo_clase,codigo_subclase,codigo_producto,costo_unitario)
                    VALUES('LP-MATERIAL','MATERIAL SINTÉTICO','UN0000000010','TC0000000002','04','002','0001',2.5);
                INSERT INTO producto(id_producto,descripcion_producto,id_unidad,id_categoria,codigo_clase,codigo_subclase,codigo_producto,costo_unitario)
                    VALUES('LP-HERRAM','HERRAMIENTAS SINTÉTICAS','UN0000000007','TC0000000003','37','001','0002',3);
                INSERT INTO costo_unitario(id_costounitario,id_presupuesto,descripcion_costo,id_unidad,cantidad,costo_unitario,parcial_costo,numeracion_costo,productividad,magnitud_unidadtiempo)
                    VALUES('CU-RECURSOS','PP-RECURSOS','PARTIDA CON FACTOR EXACTO','UN0000000010',3,4.82,14.46,'1.1',1,8);
                INSERT INTO subtotal_costounitario(id_subtotal,id_costounitario,id_tipocosto,factor_cantidad)
                    VALUES('SU-MO','CU-RECURSOS','TC0000000001',1),('SU-SUB','CU-RECURSOS','TC0000000005',1),('SU-EQ','CU-RECURSOS','TC0000000003',1);
                INSERT INTO subtotal_costounitario(id_subtotal,id_costounitario,id_tipocosto,id_composicionpadre,factor_cantidad)
                    VALUES('SU-MAT','CU-RECURSOS','TC0000000002','CO-SUB',1.23456789);
                INSERT INTO composicion_costounitario(id_composicion,id_subtotal,id_listaprecio,descripcion_composicion,id_unidad,cantidad_composicion,costo_composicion,parcial_composicion,personal_base,posicion_composicion)
                    VALUES('CO-MO','SU-MO','LP-OBRERO','OBRERO SINTÉTICO','UN0000000002',0.3333,10,3.34,1,1);
                INSERT INTO composicion_costounitario(id_composicion,id_subtotal,id_listaprecio,descripcion_composicion,id_unidad,cantidad_composicion,costo_composicion,parcial_composicion,nombre_subcontratista,posicion_composicion)
                    VALUES('CO-MO2','SU-MO','LP-OBRERO','OBRERO SINTÉTICO','UN0000000002',0.1,10,1,'PROVEEDOR DE LA COMPOSICIÓN',2);
                INSERT INTO composicion_costounitario(id_composicion,id_subtotal,id_costoauxiliar,descripcion_composicion,id_unidad,cantidad_composicion,costo_composicion,parcial_composicion)
                    VALUES('CO-SUB','SU-SUB','AC-AUX','SUBANÁLISIS SINTÉTICO','UN0000000010',1.2346,0.28,0.35);
                INSERT INTO composicion_costounitario(id_composicion,id_subtotal,id_listaprecio,descripcion_composicion,id_unidad,cantidad_composicion,costo_composicion,parcial_composicion)
                    VALUES('CO-MAT','SU-MAT','LP-MATERIAL','MATERIAL SINTÉTICO','UN0000000010',0.1111,2.5,0.28);
                INSERT INTO composicion_costounitario(id_composicion,id_subtotal,id_listaprecio,descripcion_composicion,id_unidad,cantidad_composicion,costo_composicion,parcial_composicion,es_composiciondependiente)
                    VALUES('CO-HERRAM','SU-EQ','LP-HERRAM','HERRAMIENTAS SINTÉTICAS','UN0000000007',3,4.34,0.13,'S');
                """;
            cmd.ExecuteNonQuery();
        }
        string huella = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
        var d = MYGBaseDatos.LeerProyecto(ruta); var p = d.Presupuestos.Single(); var i = p.Items.Single();
        var a = MYGMotorPresupuestos.Analizar(p, i);
        var recursos = MYGListaInsumosContexto.Crear(d.Presupuestos);
        Exige(p.Costos.DecimalesPrecio == 2 && p.Costos.DecimalesCantidad == 4 &&
            a.Recursos.Single(r => r.Recurso.Id == "CO-MO").Cantidad == 0.3333m &&
            a.Recursos.Single(r => r.Recurso.Id == "CO-MO").Total == 3.34m && a.PrecioUnitario == 4.82m,
            "La precisión nativa cero descartó coeficientes o los parciales propios de Delphin.");
        var manoObra = recursos.Where(r => r.Grupo == MYGGrupoRecurso.ManoObra).ToArray();
        Exige(manoObra.Length == 2 && manoObra.Sum(r => r.Total) == 13.02m &&
            manoObra.Single(r => r.Proveedor == "PROVEEDOR DEL PRODUCTO").Cantidad == 1.002m &&
            manoObra.All(r => r.Codigo == "470010001") &&
            MYGCatalogos.Listar(ruta, false).Single(r => r.Id == "LP-OBRERO").Grupo == MYGGrupoRecurso.ManoObra.ToString(),
            "La lista nativa perdió el código, proveedor, categoría o cantidad derivada del parcial/precio.");
        Exige(recursos.Single(r => r.Grupo == MYGGrupoRecurso.Materiales).Total == 1.0370370276m &&
            recursos.All(r => !r.Descripcion.Contains("Ajuste", StringComparison.OrdinalIgnoreCase)) &&
            MYGMotorPresupuestos.Resumen(p).CostoDirecto == 14.46m && recursos.Sum(r => r.Total) == 14.46m &&
            recursos.Single(r => r.Grupo == MYGGrupoRecurso.Equipo).Total == 0.4029629724m &&
            recursos.Single(r => r.Grupo == MYGGrupoRecurso.Equipo).Precio == 13.02m &&
            decimal.Round(recursos.Single(r => r.Grupo == MYGGrupoRecurso.Equipo).Cantidad, 4) == 2.9954m &&
            recursos.Single(r => r.Grupo == MYGGrupoRecurso.Equipo).Unidad == "%mo",
            "El subanálisis perdió su factor exacto o fabricó un insumo por diferencias de redondeo.");
        Exige(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta))) == huella,
            "Consultar los recursos modificó la base nativa.");
        pasa("Recursos Delphin conservan parciales, factores exactos, precisión predeterminada, códigos, categorías y proveedores sin insumos de ajuste");

        var copia = MYGProyectoStorage.Copia(d);
        Exige(JsonSerializer.Serialize(MYGListaInsumosContexto.Crear(copia.Presupuestos)) == JsonSerializer.Serialize(recursos),
            "Serializar el proyecto perdió los parciales nativos por recurso.");
        i.Costos.Cantidad = 4;
        Exige(MYGListaInsumosContexto.Crear(d.Presupuestos).Where(r => r.Grupo == MYGGrupoRecurso.ManoObra).Sum(r => r.Total) == 17.36m,
            "Cambiar el metrado dejó de aplicar los parciales nativos del ACU intacto.");
        p.Costos.Insumos.Single(r => r.Id == "LP-OBRERO").Precio = 12;
        a = MYGMotorPresupuestos.Analizar(p, i);
        Exige(!MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i) &&
            a.Recursos.Single(r => r.Recurso.Id == "CO-MO").Total == 4m,
            "Editar el precio reutilizó indebidamente un parcial importado anterior.");
        pasa("Parciales Delphin sobreviven a serialización y cambios de metrado y se recalculan al editar el ACU");
    }
}
