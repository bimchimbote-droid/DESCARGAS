using System.Buffers.Binary;
using System.IO.Pipes;
using System.Net;
using System.Text.Json;
using MYG.Externo;
using MYG_2027;

internal static class LicenciaProtocoloCheck
{
    private static void Exige(bool ok,string mensaje){if(!ok)throw new Exception(mensaje);}
    private static void Rechaza(Action a){try{a();}catch(InvalidDataException){return;}throw new Exception("Se aceptó una solicitud inválida.");}
    private static async Task RechazaAsync<T>(Func<Task> a) where T:Exception
    {try{await a();}catch(T){return;}throw new Exception("No rechazó "+typeof(T).Name);}
    private static SolicitudRevit Crear()=>new(){Accion="CREAR",DocumentoId="MODELO-A",ProyectoId="PROYECTO-A",PresupuestoId="PRESUPUESTO-A",
        Configuraciones=new(){new(){IdInterno="PARTIDA-A",Item="01.01",Partida="Concreto",Unidad="m³",Plantilla="PLANTILLA CONCRETO",
            Filtros=new(){new(){Parametro="Nivel",Regla="es igual a",Valor="Cimentación"}}}}};
    private static HttpResponseMessage Respuesta(string texto,HttpStatusCode codigo=HttpStatusCode.OK)=>new(codigo){Content=new StringContent(texto)};

    internal static async Task EjecutarAsync(Action<string> pasa)
    {
        string token=new('A',64);
        Exige(LicenciaServicio.Interpretar("OK",false).Ok && LicenciaServicio.Interpretar("OK|"+token,false).Token==token,"No acepta el protocolo manual MYG.");
        Exige(LicenciaServicio.Interpretar("OK",true).Ok && !LicenciaServicio.Interpretar("OK|"+token,true).Ok,"El ingreso automático aceptó una respuesta ajena a su protocolo.");
        foreach(string error in new[]{"EXPIRADO","BLOQUEADO","OTRA_PC","CLAVE_ERROR","NO_EXISTE","TOKEN_INVALIDO","AUTO_NO","DATOS_INCOMPLETOS","SIN_HOJA","FECHA_INVALIDA","OK|corto","<html>OK</html>","OK\nEXPIRADO",""})
            Exige(!LicenciaServicio.Interpretar(error,false).Ok && !LicenciaServicio.Interpretar(error,true).Ok,"Se aceptó una respuesta inválida: "+error);
        pasa("Licencia: acepta los protocolos existentes y rechaza errores, tokens cortos y respuestas HTML");

        string consulta=null,formulario=null;HttpMethod metodo=null;
        using(var http=new HttpClient(new HttpSimulado(async(r,ct)=>{metodo=r.Method;consulta=r.RequestUri.Query;formulario=r.Content==null?null:await r.Content.ReadAsStringAsync(ct);return Respuesta(r.Method==HttpMethod.Get?"OK|"+token:"OK");})))
        {
            var servicio=new LicenciaServicio(http,"PC-SIMULADA","https://licencias.example.invalid/exec");
            var r=await servicio.ValidarAsync(new(){Usuario=" usuario&prueba ",Clave=" clave +/? ",RecordarIngreso=true});
            Exige(r.Ok && r.Token==token && metodo==HttpMethod.Get && consulta.Contains("usuario=usuario%26prueba") && consulta.Contains("clave=clave%20%2B%2F%3F") && consulta.Contains("pc=PC-SIMULADA"),"No preserva los nombres o la codificación del protocolo manual.");
            r=await servicio.ValidarAsync(new(){Usuario="usuario&prueba",Automatico=true,Token=token});
            Exige(r.Ok && metodo==HttpMethod.Post && consulta=="" && formulario.Contains("usuario=usuario%26prueba") && formulario.Contains("token="+token) && formulario.Contains("pc=PC-SIMULADA") && !formulario.Contains("clave="),"No preserva el ingreso automático MYG.");
        }
        pasa("Licencia: GET usuario/clave/pc y POST usuario/token/pc conservan los campos y codifican caracteres especiales");

        int peticiones=0;
        using(var http=new HttpClient(new HttpSimulado((r,ct)=>{peticiones++;return Task.FromResult(Respuesta("OK"));})))
        {
            var l=new LicenciaServicio(http,"PC","https://licencias.example.invalid/exec");
            Exige(!(await l.ValidarAsync(null)).Ok && !(await l.ValidarAsync(new(){Usuario="usuario"})).Ok && !(await l.ValidarAsync(new(){Usuario="usuario",Automatico=true,Token="corto"})).Ok && peticiones==0,"Envió datos incompletos al servicio.");
        }
        pasa("Licencia: datos vacíos y tokens incompletos se rechazan antes de realizar una petición");

        using(var http=new HttpClient(new HttpSimulado((r,ct)=>Task.FromResult(Respuesta("OK",HttpStatusCode.Forbidden)))))
            Exige(!(await new LicenciaServicio(http,"PC").ValidarAsync(new(){Usuario="qa",Clave="qa"})).Ok,"Acepta un error HTTP que contiene OK.");
        using(var http=new HttpClient(new HttpSimulado((r,ct)=>throw new HttpRequestException("Sin conexión simulada"))))
            Exige(!(await new LicenciaServicio(http,"PC").ValidarAsync(new(){Usuario="qa",Clave="qa"})).Ok,"Acepta la falta de conexión.");
        using(var http=new HttpClient(new HttpSimulado((r,ct)=>throw new OperationCanceledException())))
            Exige(!(await new LicenciaServicio(http,"PC").ValidarAsync(new(){Usuario="qa",Clave="qa"})).Ok,"Acepta una validación cancelada.");
        pasa("Licencia: HTTP rechazado, desconexión y cancelación mantienen el acceso desautorizado");

        var manual=new CredencialMYG{Usuario="qa",Clave="secreto-de-prueba"};
        var auto=new CredencialMYG{Usuario="qa",Token="secreto-de-prueba",Automatico=true};
        Exige(manual.Identidad()!=auto.Identidad() && !manual.Identidad().Contains(manual.Clave),"Se reutiliza la autorización entre modos de ingreso.");
        Exige(new CredencialMYG{Usuario="qa|False|",Clave="abc"}.Identidad()!=new CredencialMYG{Usuario="qa",Clave="|False|abc"}.Identidad(),"Se confunden credenciales con separadores internos.");
        pasa("Licencia: la identidad de autorización diferencia credenciales manuales y automáticas");

        var solicitud=Crear();ProtocoloMYG.Validar(solicitud);
        using(var memoria=new MemoryStream())
        {
            await ProtocoloMYG.EscribirAsync(memoria,solicitud,CancellationToken.None);
            using var fragmentado=new FlujoFragmentado(memoria.ToArray());
            var leida=await ProtocoloMYG.LeerAsync<SolicitudRevit>(fragmentado,CancellationToken.None);
            Exige(leida.Id==solicitud.Id && leida.Configuraciones[0].Unidad=="m³" && leida.Configuraciones[0].Filtros[0].Valor=="Cimentación","Pierde datos con lecturas fragmentadas.");
        }
        var info=new DocumentoRevitInfo{Parametros=new(){["PLANTILLA CONCRETO"]=new(){"Nivel"}},Reglas=new(){["PLANTILLA CONCRETO"]=new(){["Nivel"]=new(){"es igual a"}}}};
        var datos=JsonSerializer.Deserialize<DocumentoRevitInfo>(JsonSerializer.Serialize(info,ProtocoloMYG.Json),ProtocoloMYG.Json);
        Exige(datos.Parametros.ContainsKey("plantilla concreto") && datos.Reglas["plantilla concreto"].ContainsKey("nivel"),"La transmisión altera las búsquedas sin distinción de mayúsculas.");
        pasa("Conector: reconstruye mensajes fragmentados y conserva UTF-8, filtros e identificadores");

        foreach(int size in new[]{0,-1,ProtocoloMYG.MaxBytes+1})
        {
            byte[] h=new byte[4];BinaryPrimitives.WriteInt32LittleEndian(h,size);
            using var f=new MemoryStream(h);await RechazaAsync<InvalidDataException>(async()=>{await ProtocoloMYG.LeerAsync<SolicitudRevit>(f,CancellationToken.None);});
        }
        using(var f=new MemoryStream(new byte[]{9,0,0,0,123}))
            await RechazaAsync<EndOfStreamException>(async()=>{await ProtocoloMYG.LeerAsync<SolicitudRevit>(f,CancellationToken.None);});
        pasa("Conector: mensajes excesivos, tamaños inválidos y payloads incompletos se rechazan");

        var mala=Crear();mala.Version=2;Rechaza(()=>ProtocoloMYG.Validar(mala));
        mala=Crear();mala.Id="otro";Rechaza(()=>ProtocoloMYG.Validar(mala));
        mala=Crear();mala.Accion="SQL_ESCRIBIR";Rechaza(()=>ProtocoloMYG.Validar(mala));
        mala=Crear();mala.DocumentoId=null;Rechaza(()=>ProtocoloMYG.Validar(mala));
        mala=Crear();mala.PresupuestoId=null;Rechaza(()=>ProtocoloMYG.Validar(mala));
        mala=Crear();mala.Configuraciones.Clear();Rechaza(()=>ProtocoloMYG.Validar(mala));
        mala=Crear();mala.Configuraciones[0].Filtros=Enumerable.Range(0,9).Select(_=>new FiltroPlanificacion()).ToList();Rechaza(()=>ProtocoloMYG.Validar(mala));
        mala=Crear();mala.Configuraciones[0].Filtros=new(){null};Rechaza(()=>ProtocoloMYG.Validar(mala));
        pasa("Conector: exige versión, ID de operación, modelo, ámbito, partidas y hasta ocho filtros válidos");

        var pendiente=new OperacionPendiente(Crear());
        Exige(pendiente.CancelarAntesDeIniciar() && !pendiente.Iniciar() && !(await pendiente.Fin.Task).Ok,"La operación cancelada puede ejecutarse.");
        var iniciada=new OperacionPendiente(Crear());
        Exige(iniciada.Iniciar() && !iniciada.Iniciar() && !iniciada.CancelarAntesDeIniciar(),"Cancela una operación que ya comenzó.");
        iniciada.Completar(new(){Id=iniciada.Solicitud.Id,Ok=true});
        Exige((await iniciada.Fin.Task).Ok,"No entrega el resultado final.");
        pasa("Conector: cancelar una petición pendiente impide ejecutarla; una operación iniciada conserva su resultado");

        ProtocoloMYG.ValidarRespuesta(solicitud,new(){Id=solicitud.Id,Ok=true});
        Rechaza(()=>ProtocoloMYG.ValidarRespuesta(solicitud,new(){Id=Guid.NewGuid().ToString("N"),Ok=true}));
        Rechaza(()=>ProtocoloMYG.ValidarRespuesta(solicitud,null));
        Exige(!JsonSerializer.Serialize(new RespuestaRevit{Id=solicitud.Id,Ok=true}).Contains("Credencial"),"Una respuesta contiene campos de credenciales.");
        pasa("Conector: rechaza respuestas de otra operación o nulas y no retorna campos de credenciales");

        if(!OperatingSystem.IsWindows())
        {Console.WriteLine("OMITIDA: prueba de Named Pipes de Windows; ejecutar MYG.Pruebas en Windows para comprobar el canal local.");return;}
        using(var limite=new CancellationTokenSource(TimeSpan.FromSeconds(15)))
        {
            for(int vuelta=0;vuelta<2;vuelta++)
            {
                using var server=new NamedPipeServerStream(ProtocoloMYG.Pipe(Environment.ProcessId),PipeDirection.InOut,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous|PipeOptions.CurrentUserOnly);
                bool alterar=vuelta==1;
                var recibir=Task.Run(async()=>{
                    await server.WaitForConnectionAsync(limite.Token);
                    var s=await ProtocoloMYG.LeerAsync<SolicitudRevit>(server,limite.Token);
                    Exige(s.Accion=="INFO" && s.Credencial.Clave=="prueba","No recibe la credencial en la petición.");
                    await ProtocoloMYG.EscribirAsync(server,new RespuestaRevit{Id=alterar?Guid.NewGuid().ToString("N"):s.Id,Ok=true,Documento=new(){Id="MODELO-QA",Nombre="Modelo de prueba"}},limite.Token);
                });
                var c=new ClienteRevit();var s=new SolicitudRevit{Accion="INFO",Credencial=new(){Usuario="qa",Clave="prueba"}};
                if(alterar)await RechazaAsync<InvalidDataException>(async()=>{await c.EnviarAsync(Environment.ProcessId,s,limite.Token);});
                else Exige((await c.EnviarAsync(Environment.ProcessId,s,limite.Token)).Documento.Id=="MODELO-QA","Falla el canal entre cliente y receptor.");
                await recibir;
            }
        }
        pasa("Conector: canal local Windows real recibe y responde; el cliente rechaza respuestas de otra operación");
    }
    private sealed class HttpSimulado(Func<HttpRequestMessage,CancellationToken,Task<HttpResponseMessage>> responder):HttpMessageHandler
    {protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage r,CancellationToken ct)=>responder(r,ct);}
    private sealed class FlujoFragmentado(byte[] datos):MemoryStream(datos)
    {public override ValueTask<int> ReadAsync(Memory<byte> buffer,CancellationToken ct=default)=>base.ReadAsync(buffer[..Math.Min(1,buffer.Length)],ct);}
}
