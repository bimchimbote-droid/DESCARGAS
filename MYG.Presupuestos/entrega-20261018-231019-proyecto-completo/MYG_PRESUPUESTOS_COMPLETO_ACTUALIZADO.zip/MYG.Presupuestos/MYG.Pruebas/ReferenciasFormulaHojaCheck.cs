using System;
using System.Linq;
using MYG_2027;

static class ReferenciasFormulaHojaCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }

    public static void Ejecutar(Action<string> pasa)
    {
        string formula = " =SUM($b$8 : $a$3)+A3+$A$3+A3:A3+B8+LOG10(C4)";
        var referencias = MYGReferenciasFormulaHoja.Extraer(formula, 100, 12);
        Exige(referencias.Select(r => r.Rango).SequenceEqual(new[] { "A3:B8", "A3", "A3", "A3", "B8", "C4" }),
            "Las referencias absolutas, los rangos invertidos y las funciones deben extraerse y normalizarse sin alterar el orden.");
        Exige(referencias[0].FilaInicial == 3 && referencias[0].FilaFinal == 8 &&
            referencias[0].ColumnaInicial == 1 && referencias[0].ColumnaFinal == 2 &&
            formula.Substring(referencias[0].Inicio, referencias[0].Longitud) == "$b$8 : $a$3" &&
            formula.Substring(referencias[2].Inicio, referencias[2].Longitud) == "$A$3" &&
            referencias.All(r => r.Inicio >= 0 && r.Longitud > 0 && r.Inicio + r.Longitud <= formula.Length),
            "Las coordenadas y posiciones deben identificar exactamente el texto original de cada referencia.");
        Exige(referencias.Select(r => r.IndiceColor).SequenceEqual(new[] { 0, 1, 1, 1, 2, 3 }),
            "Las referencias equivalentes deben compartir color y las diferentes conservar el orden de color.");
        pasa("Colores de fórmulas extraen referencias y rangos absolutos/invertidos con posiciones precisas y colores estables");

        referencias = MYGReferenciasFormulaHoja.Extraer("=IF(A1=\"B2\",\"Texto \"\"C3\"\"\",D4)+\"E5\"+F6", 100, 12);
        Exige(referencias.Select(r => r.Rango).SequenceEqual(new[] { "A1", "D4", "F6" }),
            "Las direcciones dentro de literales, incluidas las comillas escapadas, no deben colorearse.");
        referencias = MYGReferenciasFormulaHoja.Extraer("=Tabla1[[#Headers],[A1]]+Tabla2[B2]+_C3+D4_nombre+Nombre.E5+1E10+LOG10(F6)+R1C1+G7", 100, 16384);
        Exige(referencias.Select(r => r.Rango).SequenceEqual(new[] { "F6", "G7" }),
            "No se deben confundir nombres, tablas estructuradas, notación científica ni funciones con direcciones locales.");
        referencias = MYGReferenciasFormulaHoja.Extraer("='A1 y B2'!C3:D4+'O''Brien'!E5+Hoja1!F6+[Libro.xlsx]Hoja2!G7+H8", 100, 12);
        Exige(referencias.Count == 1 && referencias[0].Rango == "H8",
            "Las referencias a otra hoja o libro no deben colorear celdas locales con la misma dirección.");
        referencias = MYGReferenciasFormulaHoja.Extraer("=A1!B2+C3:D4!E5+F6+'Hoja'!A1:B2+C4", 100, 12);
        Exige(referencias.Select(r => r.Rango).SequenceEqual(new[] { "F6", "C4" }),
            "Una hoja o rango 3D cuyo nombre parece una dirección no debe producir referencias locales falsas.");
        pasa("Colores de fórmulas omiten literales, nombres, funciones, tablas y referencias externas sin evaluar contenido");

        referencias = MYGReferenciasFormulaHoja.Extraer("=A1:XFD1048576+M2+L101+M101:XFD1048576+L100+A0+A01+XFE1+A1048577", 100, 12);
        Exige(referencias.Count == 2 && referencias[0].Rango == "A1:L100" && referencias[1].Rango == "L100" &&
            referencias.All(r => r.FilaInicial >= 1 && r.FilaFinal <= 100 && r.ColumnaInicial >= 1 && r.ColumnaFinal <= 12),
            "Los rangos deben intersectarse con la hoja y las referencias inválidas o totalmente externas deben omitirse.");
        var grande = MYGReferenciasFormulaHoja.Extraer("=A1:D20+B2", 100, 12);
        var pequena = MYGReferenciasFormulaHoja.Extraer("=A1:D20+B2", 1, 1);
        Exige(grande.Count == 2 && grande[0].Rango == "A1:D20" && pequena.Count == 1 && pequena[0].Rango == "A1" &&
            MYGReferenciasFormulaHoja.Extraer("=A1", 0, 12).Count == 0 && MYGReferenciasFormulaHoja.Extraer("=A1", 10, -1).Count == 0,
            "Extraer la misma fórmula en otra hoja no debe reutilizar referencias con dimensiones anteriores.");
        pasa("Colores de fórmulas respetan las dimensiones actuales y recortan rangos sin crear referencias fuera de la hoja");

        referencias = MYGReferenciasFormulaHoja.Extraer("=SUM(A1:B3)+C4+", 100, 12);
        Exige(referencias.Select(r => r.Rango).SequenceEqual(new[] { "A1:B3", "C4" }) &&
            MYGReferenciasFormulaHoja.Extraer("=SUM($A$1:", 100, 12).Single().Rango == "A1" &&
            MYGReferenciasFormulaHoja.Extraer("=A1+\"B2", 100, 12).Single().Rango == "A1" &&
            MYGReferenciasFormulaHoja.Extraer("=#REF!+B2/0", 100, 12).Single().Rango == "B2",
            "La edición incompleta y los errores deben conservar las referencias ya escritas sin exigir una fórmula válida.");
        Exige(MYGReferenciasFormulaHoja.Extraer(null, 100, 12).Count == 0 &&
            MYGReferenciasFormulaHoja.Extraer(" ", 100, 12).Count == 0 &&
            MYGReferenciasFormulaHoja.Extraer("Descripción A1:B2", 100, 12).Count == 0 &&
            MYGReferenciasFormulaHoja.Extraer("A1", 100, 12).Count == 0 &&
            MYGReferenciasFormulaHoja.Extraer("=", 100, 12).Count == 0,
            "El resaltado debe estar vacío para texto, contenido ausente y fórmulas sin referencias.");
        string repetida = "=" + string.Join("+", Enumerable.Repeat("A1", MYGReferenciasFormulaHoja.MaximoReferencias + 50));
        referencias = MYGReferenciasFormulaHoja.Extraer(repetida, 100, 12);
        Exige(referencias.Count == MYGReferenciasFormulaHoja.MaximoReferencias && referencias.All(r => r.IndiceColor == 0) &&
            MYGReferenciasFormulaHoja.Extraer("=" + new string('A', MYGReferenciasFormulaHoja.MaximoCaracteresFormula), 100, 12).Count == 0 &&
            MYGReferenciasFormulaHoja.Extraer("=A9999999999999999999+B2", 100, 12).Single().Rango == "B2",
            "El resaltado debe limitar fórmulas excesivas y tolerar coordenadas desbordadas sin excepciones.");
        pasa("Colores de fórmulas funcionan mientras se escribe y limitan contenido excesivo sin ejecutar fórmulas ni lanzar por referencias inválidas");
    }
}
