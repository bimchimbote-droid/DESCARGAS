using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinPieCheck
{
    private static readonly decimal[] ImportesEsperados =
    { 2402490.56m, 400685.85m, 240249.06m, 3043425.47m, 547816.58m, 3591242.05m, 262565.96m, 5598.29m, 3859406.30m };

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Pie nativo Delphin.sqlite");
        CrearMuestra(ruta);
        string huella = Huella(ruta);
        var proyecto = MYGBaseDatos.LeerProyecto(ruta);
        VerificarPie(proyecto);
        Exige(MYGPiePresupuesto.Filas(new[] { proyecto.Presupuestos[0] }).Select(f => f.Importe)
            .SequenceEqual(new[] { 700982.42m, 116909.40m, 70098.24m, 887990.06m, 159838.21m, 1047828.27m, 76609.72m, 5598.29m, 1130036.28m }),
            "El pie individual no conserva las fórmulas nativas y sus subtotales.");
        Exige(proyecto.Presupuestos[0].Costos.PieDelphin.Filas[0].Porcentaje == 16.6779364993634m &&
            proyecto.Presupuestos[0].Costos.PieDelphin.Filas[5].Porcentaje == 7.31128563410477m,
            "La importación truncó los porcentajes de alta precisión del pie Delphin.");
        pasa("Pie Delphin importa filas C/X/V/F, fórmulas con corchetes y porcentajes de alta precisión sin sumar subtotales");
        pasa("Pie único de proyecto recalcula sobre el costo directo global y aplica el expediente técnico una sola vez");

        string copia = Path.Combine(carpeta, "Pie Delphin persistido.sqlite");
        MYGBaseDatos.GuardarProyecto(copia, proyecto, ruta);
        VerificarPie(MYGProyectoStorage.Leer(copia));
        Exige(Huella(ruta) == huella, "Leer y guardar una copia del pie alteró la base de origen.");
        pasa("Guardar y reabrir conserva el alcance, las filas y el total del pie nativo sin alterar su SQLite fuente");

        var editado = MYGProyectoStorage.Copia(proyecto);
        var p = editado.Presupuestos[0];
        p.Items[0].Costos.Cantidad = 2;
        var filas = MYGPiePresupuesto.Filas(editado.Presupuestos);
        Exige(filas[0].Importe == 3103472.98m && filas[1].Importe == decimal.Round(3103472.98m * 16.6779364993634m / 100, 2, MidpointRounding.AwayFromZero) && filas[7].Importe == 5598.29m,
            "Cambiar el metrado no recalculó el pie global o multiplicó su importe manual.");
        MYGPiePresupuesto.AplicarPorcentajeDelphin(editado.Presupuestos, "delphin:porcentaje_gsgs", 12.5m);
        Exige(editado.Presupuestos.All(x => x.Costos.PieDelphin.Filas[0].Porcentaje == 12.5m) &&
            MYGPiePresupuesto.Filas(editado.Presupuestos)[1].Importe == 387934.12m,
            "Editar un porcentaje nativo no recalculó el mismo concepto para todo el alcance.");
        MYGBaseDatos.GuardarProyecto(copia, editado, ruta);
        var reabierto = MYGProyectoStorage.Leer(copia);
        Exige(reabierto.Presupuestos.All(x => x.Costos.PieDelphin.Filas[0].Porcentaje == 12.5m) &&
            MYGPiePresupuesto.Filas(reabierto.Presupuestos)[1].Importe == 387934.12m,
            "Guardar y reabrir perdió la edición del porcentaje del pie nativo.");
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = copia, Mode = SqliteOpenMode.ReadOnly }.ToString()))
        {
            c.Open(); using var cmd = c.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM titulo_pie WHERE clave='porcentaje_gsgs' AND porcentaje_titulo=12.5";
            Exige(Convert.ToInt32(cmd.ExecuteScalar()) == 6, "El porcentaje editado no se reflejó en las filas nativas titulo_pie.");
        }
        MYGPiePresupuesto.Limpiar(editado.Presupuestos);
        Exige(editado.Presupuestos.All(x => x.Costos.PieDelphin == null) && MYGPiePresupuesto.Filas(editado.Presupuestos).Count == 1,
            "Limpiar el pie dejó fórmulas nativas activas.");
        pasa("Las ediciones de metrado y porcentajes recalculan el pie nativo; limpiar desactiva todos sus conceptos");

        var invalido = MYGProyectoStorage.Copia(proyecto.Presupuestos[0]);
        invalido.Costos.PieDelphin.Filas[2].Formula = "[user_fila_posterior] + 1";
        try { MYGProyectoStorage.ValidarPresupuesto(invalido); throw new Exception("Se aceptó una referencia nativa inexistente."); }
        catch (InvalidDataException) { }
        invalido = MYGProyectoStorage.Copia(proyecto.Presupuestos[0]);
        invalido.Costos.PieDelphin.Filas[2].Formula = "[costo_directo]; DELETE FROM proyecto";
        try { MYGProyectoStorage.ValidarPresupuesto(invalido); throw new Exception("Se aceptó código externo en una fórmula nativa."); }
        catch (InvalidDataException) { }
        Exige(Huella(ruta) == huella, "Validar fórmulas modificó el archivo nativo.");
        pasa("El pie nativo rechaza referencias inexistentes y expresiones ajenas al lenguaje aritmético seguro");

        string real = Environment.GetEnvironmentVariable("MYG_QA_LLACUSBAMBA_SQLITE");
        if (!string.IsNullOrWhiteSpace(real) && File.Exists(real))
        {
            string antes = Huella(real);
            VerificarPie(MYGBaseDatos.LeerProyecto(real));
            Exige(Huella(real) == antes, "La validación del pie LLACUSBAMBA alteró la base original.");
            pasa("Base real LLACUSBAMBA coincide con los nueve importes del pie exportado por Delphin, incluido S/ 3,859,406.30");
        }
    }

    private static void VerificarPie(MYGProyectoDocumento proyecto)
    {
        var filas = MYGPiePresupuesto.Filas(proyecto.Presupuestos);
        Exige(MYGPiePresupuesto.EsPieUnicoDelphin(proyecto.Presupuestos) && filas.Select(f => f.Importe).SequenceEqual(ImportesEsperados),
            "El pie único Delphin difiere del resumen original: " + string.Join("; ", filas.Select(f => f.Nombre + "=" + f.Importe)));
        var resumen = MYGPiePresupuesto.Resumen(proyecto.Presupuestos);
        Exige(resumen.CostoDirecto == 2402490.56m && resumen.GastosGenerales == 400685.85m && resumen.Utilidad == 240249.06m &&
            resumen.Subtotal == 3043425.47m && resumen.Impuesto == 547816.58m && resumen.Total == 3859406.30m,
            "El resumen numérico no corresponde a las filas visibles del pie nativo.");
        Exige(filas[^1].Id == MYGPiePresupuesto.IdTotal && filas.Count == 9,
            "El pie nativo debe mantener sus nueve filas y su última fórmula como total.");
    }

    private static void CrearMuestra(string ruta)
    {
        SQLiteDependencyBootstrapper.Initialize();
        MYGBaseDatos.CrearBaseVacia(ruta);
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString());
        c.Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = """
            INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,tipo_gasto,decimales_costo)
            VALUES('PR1','US0000000001','IN0000000007','No','PROYECTO PIE UNICO','PR',2);
            INSERT INTO unidad(id_unidad,abreviatura_unidad) VALUES('U1','glb');
            """;
        cmd.ExecuteNonQuery();
        decimal[] costos = { 700982.42m, 633740.94m, 604009.78m, 183313.15m, 19113m, 261331.27m };
        for (int n = 0; n < costos.Length; n++)
        {
            cmd.Parameters.Clear(); cmd.Parameters.AddWithValue("$id", "PP" + n); cmd.Parameters.AddWithValue("$pos", n);
            cmd.Parameters.AddWithValue("$directo", costos[n]);
            cmd.CommandText = """
                INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto)
                VALUES($id,'PR1','PRESUPUESTO ' || $pos,$pos,CAST($pos+1 AS TEXT));
                INSERT INTO costo_unitario(id_costounitario,id_presupuesto,id_unidad,descripcion_costo,cantidad,costo_unitario,parcial_costo)
                VALUES('CU' || $pos,$id,'U1','PARTIDA ' || $pos,1,$directo,$directo);
                INSERT INTO titulo_pie(descripcion_titulo,posicion_titulo,id_presupuesto,tipo_titulo,porcentaje_titulo,costo_titulo,formula,clave,seccion_titulo) VALUES
                ('GASTOS GENERALES',2,$id,'C',16.6779364993634,0,'','porcentaje_gsgs','N'),
                ('UTLIDADES',3,$id,'C',10,0,'','porcentaje_utilidad','N'),
                ('SUB TOTAL',4,$id,'F',0,0,'[costo_directo] + [monto_gsgs] + [monto_utilidad]','user_sub_total','N'),
                ('IGV',5,$id,'X',18,0,'[user_sub_total]','user_igv','N'),
                ('VALOR REFERENCIAL',6,$id,'F',0,0,'[user_sub_total] + [user_igv]','user_total_del_presupuesto','N'),
                ('GASTOS DE SUPERVISION',7,$id,'X',7.31128563410477,0,'[user_total_del_presupuesto]','user_gastos_de_supervision','N'),
                ('EXPEDIENTE TECNICO',8,$id,'V',0,5598.29166666667,'','user_expediente_tecnico','N'),
                ('COSTO TOTAL DE EJECUCION',9,$id,'F',0,0,'[user_total_del_presupuesto] + [user_gastos_de_supervision] + [user_expediente_tecnico]','user_costo_total_de_ejecucion','N');
                """;
            cmd.ExecuteNonQuery();
        }
    }
}
