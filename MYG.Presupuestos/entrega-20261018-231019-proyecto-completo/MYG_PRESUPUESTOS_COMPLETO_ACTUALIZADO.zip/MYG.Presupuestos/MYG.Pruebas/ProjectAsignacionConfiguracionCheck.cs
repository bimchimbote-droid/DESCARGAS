using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.Json;
using MYG_2027;

static class ProjectAsignacionConfiguracionCheck
{
    private static void Exige(bool condicion, string mensaje)
    {
        if (!condicion) throw new Exception(mensaje);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        ComprobarRestauracion(pasa);
        ComprobarDedicacionYTrabajo(pasa);
        ComprobarTolerancias(pasa);
        ComprobarRechazoPersistente(pasa);
        ComprobarExcepciones(pasa);
        ComprobarCulturas(pasa);
    }

    private static void ComprobarRestauracion(Action<string> pasa)
    {
        foreach (int tipo in new[] { 0, 1, 2 })
        {
            var datos = Datos(tipo);
            string origen = JsonSerializer.Serialize(datos);
            string campo = Campo(tipo);
            decimal esperado = Esperado(datos, tipo);
            // Una tarea de tres jornadas puede recalcular Units/Work al fijar
            // su duración. El contrato debe reponer la magnitud del ACU.
            var project = new AsignacionSimulada(campo, esperado / 3m, datos.Costo);
            Exige(MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, project.Leer, project.Escribir),
                "No se restauró la asignación alterada al recalcular la duración de tres jornadas.");
            Exige(project.Escrituras.Count == 1 && project.Escrituras[0] == campo &&
                Convert.ToDecimal(project.Valor, CultureInfo.InvariantCulture) == esperado,
                "Restaurar debe escribir una sola vez la magnitud propia del tipo de recurso.");
            MYGConfiguracionAsignacionProject.Verificar(datos, tipo, "Recurso QA", "Tarea QA", project.Leer);
            Exige(!MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, project.Leer, project.Escribir) &&
                project.Escrituras.Count == 1 && JsonSerializer.Serialize(datos) == origen,
                "Restaurar no es idempotente o modificó los datos originales de la asignación.");
            if (tipo == 1)
                Exige(esperado == 495m && datos.TrabajoHoras == 8.25m,
                    "Las 8,25 horas de trabajo deben enviarse como 495 minutos a Project.");
            if (tipo == 0)
                Exige(esperado == 3.456789m && datos.Cantidad == esperado,
                    "El alquiler mensual material de tres jornadas perdió la cantidad fija del ACU.");
            Exige(tipo == 2 || !project.Escrituras.Contains("Cost"),
                "Restaurar convirtió trabajo o material en un costo artificial en vez de conservar su magnitud.");
        }
        pasa("Project restaura trabajo en minutos, cantidad fija del alquiler mensual y costo explícito tras recalcular tres jornadas; la restauración es idempotente y conserva el DTO");
    }

    private static void ComprobarDedicacionYTrabajo(Action<string> pasa)
    {
        // Reproduce OPERARIO de la captura: cuatro horas de ACU a S/10
        // en una tarea de dos jornadas, con dedicación asignada del 100 %.
        var datos = Datos(1) with { Cantidad = 4, TrabajoHoras = 4, Unidades = 1, Costo = 40 };
        var project = new AsignacionSimulada("Work", 960m, datos.Costo)
        { Unidades = .25m, RecalcularTrabajoAlCambiarUnidades = true };
        Exige(MYGConfiguracionAsignacionProject.Restaurar(datos, 1, project.Leer, project.Escribir) &&
            project.Escrituras.Count == 2 && project.Escrituras[0] == "Units" && project.Escrituras[1] == "Work" &&
            project.Unidades == 1 && Convert.ToDecimal(project.Valor, CultureInfo.InvariantCulture) == 240m &&
            project.Costo == 40 && !project.Escrituras.Contains("Cost"),
            "La restauración debe fijar 100 % antes de reponer cuatro horas, manteniendo S/40 sin sobrescribir el costo.");
        MYGConfiguracionAsignacionProject.Verificar(datos, 1, "OPERARIO", "Cartel", project.Leer);
        Exige(!MYGConfiguracionAsignacionProject.Restaurar(datos, 1, project.Leer, project.Escribir),
            "Una asignación al 100 % con horas y costo correctos no debe reescribirse.");
        project.Unidades = .25m;
        string fallo = Captura<InvalidOperationException>(() => MYGConfiguracionAsignacionProject.Verificar(
            datos, 1, "OPERARIO", "Cartel", project.Leer)).Message;
        Exige(fallo.Contains("Units", StringComparison.Ordinal), "La comprobación no detectó que Project cambió 100 % por 25 %.");
        project.Unidades = 1;
        project.Costo = 160;
        fallo = Captura<InvalidOperationException>(() => MYGConfiguracionAsignacionProject.Verificar(
            datos, 1, "OPERARIO", "Cartel", project.Leer)).Message;
        Exige(fallo.Contains("Cost", StringComparison.Ordinal),
            "La comprobación debe rechazar un costo recalculado incorrecto aunque Units y Work sean correctos.");
        pasa("Project conserva 100 % asignado, horas originales y S/40 de mano de obra; verifica dedicación y costo sin escribir costos artificiales");
    }

    private static void ComprobarTolerancias(Action<string> pasa)
    {
        foreach (int tipo in new[] { 0, 1, 2 })
        {
            var datos = Datos(tipo);
            decimal esperado = Esperado(datos, tipo), tolerancia = Tolerancia(tipo);
            foreach (decimal diferencia in new[] { -tolerancia, 0m, tolerancia })
            {
                var project = new AsignacionSimulada(Campo(tipo), esperado + diferencia, datos.Costo);
                Exige(!MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, project.Leer, project.Escribir) &&
                    project.Escrituras.Count == 0,
                    "Una diferencia dentro de la tolerancia provocó una escritura innecesaria en Project.");
                MYGConfiguracionAsignacionProject.Verificar(datos, tipo, "Recurso QA", "Tarea QA", project.Leer);
            }
            foreach (decimal signo in new[] { -1m, 1m })
            {
                decimal recibido = esperado + signo * (tolerancia + 0.0000001m);
                var project = new AsignacionSimulada(Campo(tipo), recibido, datos.Costo);
                Captura<InvalidOperationException>(() => MYGConfiguracionAsignacionProject.Verificar(
                    datos, tipo, "Recurso QA", "Tarea QA", project.Leer));
                Exige(MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, project.Leer, project.Escribir) &&
                    project.Escrituras.Count == 1,
                    "Una diferencia superior a la tolerancia se aceptó sin restaurar la asignación.");
            }
        }
        pasa("Project mantiene las tolerancias de 0,01 minutos, 0,000001 unidades y 0,02 de costo, y rechaza diferencias mayores en ambos sentidos");
    }

    private static void ComprobarRechazoPersistente(Action<string> pasa)
    {
        foreach (int tipo in new[] { 0, 1, 2 })
        {
            var datos = Datos(tipo);
            decimal esperado = Esperado(datos, tipo), recibido = esperado + Tolerancia(tipo) * 3m;
            var project = new AsignacionSimulada(Campo(tipo), recibido, datos.Costo) { IgnorarEscritura = true };
            Exige(MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, project.Leer, project.Escribir) &&
                project.Escrituras.Count == 1,
                "Restaurar debe informar de su única escritura aunque Project ignore el valor.");
            string mensaje = Captura<InvalidOperationException>(() => MYGConfiguracionAsignacionProject.Verificar(
                datos, tipo, "ALQUILER MES QA", "ALQUILER DE ALMACÉN QA", project.Leer)).Message;
            Exige(mensaje.Contains("ALQUILER MES QA", StringComparison.Ordinal) &&
                mensaje.Contains("ALQUILER DE ALMACÉN QA", StringComparison.Ordinal) &&
                mensaje.Contains(Campo(tipo), StringComparison.Ordinal) &&
                mensaje.Contains("Esperado: " + esperado.ToString(CultureInfo.InvariantCulture), StringComparison.Ordinal) &&
                mensaje.Contains("recibido: " + recibido.ToString(CultureInfo.InvariantCulture), StringComparison.Ordinal) &&
                project.Escrituras.Count == 1,
                "Una asignación que Project no conserva debe fallar con recurso, tarea, campo y valores concretos, sin más escrituras.");
        }
        // También una escritura aceptada con redondeo insuficiente debe fallar.
        var material = Datos(0);
        object unidadesRedondeadas = 0m;
        MYGConfiguracionAsignacionProject.Restaurar(material, 0, _ => unidadesRedondeadas,
            (_, valor) => unidadesRedondeadas = Math.Round(Convert.ToDecimal(valor, CultureInfo.InvariantCulture), 3));
        Captura<InvalidOperationException>(() => MYGConfiguracionAsignacionProject.Verificar(
            material, 0, "Alquiler mes", "Tres jornadas", _ => unidadesRedondeadas));
        pasa("Project rechaza asignaciones ignoradas o redondeadas fuera de tolerancia y muestra el recurso, tarea, campo y valores esperado y recibido");
    }

    private static void ComprobarExcepciones(Action<string> pasa)
    {
        var datos = Datos(1);
        var falloLectura = new IOException("Fallo COM de lectura QA");
        var falloEscritura = new IOException("Fallo COM de escritura QA");
        Exige(ReferenceEquals(falloLectura, Captura<IOException>(() =>
            MYGConfiguracionAsignacionProject.Restaurar(datos, 1, _ => throw falloLectura, (_, _) => { }))) &&
            ReferenceEquals(falloLectura, Captura<IOException>(() =>
            MYGConfiguracionAsignacionProject.Verificar(datos, 1, "Operario", "Tarea", _ => throw falloLectura))) &&
            ReferenceEquals(falloEscritura, Captura<IOException>(() =>
            MYGConfiguracionAsignacionProject.Restaurar(datos, 1, _ => 0m, (_, _) => throw falloEscritura))),
            "Las excepciones de lectura o escritura de Project fueron ocultadas o sustituidas.");
        foreach (int tipo in new[] { -1, 3 })
        {
            Captura<InvalidDataException>(() => MYGConfiguracionAsignacionProject.Restaurar(datos, tipo,
                _ => throw new Exception("No debe leer un tipo desconocido."),
                (_, _) => throw new Exception("No debe escribir un tipo desconocido.")));
            Captura<InvalidDataException>(() => MYGConfiguracionAsignacionProject.Verificar(datos, tipo,
                "Operario", "Tarea", _ => throw new Exception("No debe leer un tipo desconocido.")));
        }
        pasa("Project propaga fallos reales de lectura y escritura y rechaza tipos de recurso desconocidos antes de acceder a la asignación");
    }

    private static void ComprobarCulturas(Action<string> pasa)
    {
        var culturaAnterior = CultureInfo.CurrentCulture;
        var culturaInterfazAnterior = CultureInfo.CurrentUICulture;
        try
        {
            foreach (string cultura in new[] { "es-PE", "es-ES", "en-US" })
            {
                CultureInfo.CurrentCulture = CultureInfo.CurrentUICulture = CultureInfo.GetCultureInfo(cultura);
                foreach (int tipo in new[] { 0, 1, 2 })
                {
                    var datos = Datos(tipo);
                    var project = new AsignacionSimulada(Campo(tipo), (double)(Esperado(datos, tipo) / 3m), datos.Costo);
                    Exige(MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, project.Leer, project.Escribir),
                        "La cultura activa impidió restaurar una magnitud numérica de Project.");
                    MYGConfiguracionAsignacionProject.Verificar(datos, tipo, "Recurso QA", "Tarea QA", project.Leer);
                    Exige(!MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, project.Leer, project.Escribir),
                        "La cultura activa alteró el valor numérico ya restaurado.");
                    // Conservar la compatibilidad previa con Variant numérico
                    // representado como texto invariante por el proveedor COM.
                    string numero = Esperado(datos, tipo).ToString(CultureInfo.InvariantCulture);
                    object LeerNumero(string campo) => campo == "Cost" ? datos.Costo :
                        tipo == 1 && campo == "Units" ? 1m : numero;
                    MYGConfiguracionAsignacionProject.Verificar(datos, tipo, "Recurso QA", "Tarea QA", LeerNumero);
                    Exige(!MYGConfiguracionAsignacionProject.Restaurar(datos, tipo, LeerNumero,
                        (_, _) => throw new Exception("No debe reescribir un Variant numérico equivalente.")),
                        "Se rechazó un Variant numérico equivalente compatible con la validación anterior.");
                }
            }
        }
        finally
        {
            CultureInfo.CurrentCulture = culturaAnterior;
            CultureInfo.CurrentUICulture = culturaInterfazAnterior;
        }
        pasa("Project conserva decimales numéricos de trabajo, material y costo bajo las culturas de Perú, España y Estados Unidos");
    }

    private static MYGAsignacionExportacionProject Datos(int tipo) => new(
        4, 10 + tipo, tipo == 1 ? 8.25m : 3.456789m,
        tipo == 1 ? 8.25m : null,
        tipo == 0 ? 3.456789m : tipo == 1 ? 1m : null,
        tipo switch { 0 => 345.6789m, 1 => 412.5m, _ => 73.17m },
        new DateTime(2024, 9, 1, 8, 0, 0), new DateTime(2024, 9, 3, 17, 0, 0));

    private static string Campo(int tipo) => tipo switch { 0 => "Units", 1 => "Work", _ => "Cost" };
    private static decimal Esperado(MYGAsignacionExportacionProject datos, int tipo) =>
        tipo switch { 0 => datos.Unidades.Value, 1 => datos.TrabajoHoras.Value * 60m, _ => datos.Costo };
    private static decimal Tolerancia(int tipo) => tipo switch { 0 => 0.000001m, 1 => 0.01m, _ => 0.02m };

    private static T Captura<T>(Action accion) where T : Exception
    {
        try { accion(); }
        catch (T excepcion) { return excepcion; }
        throw new Exception("Se esperaba " + typeof(T).Name + ".");
    }

    private sealed class AsignacionSimulada
    {
        private readonly string campo;
        internal object Valor;
        internal decimal Unidades = 1, Costo;
        internal bool IgnorarEscritura;
        internal bool RecalcularTrabajoAlCambiarUnidades;
        internal readonly List<string> Escrituras = new();

        internal AsignacionSimulada(string campo, object valor, decimal costo)
        { this.campo = campo; Valor = valor; Costo = costo; }

        internal object Leer(string nombre)
        {
            if (nombre == "Units" && campo == "Work") return Unidades;
            if (nombre == "Cost" && campo != "Cost") return Costo;
            Exige(nombre == campo, "Se leyó una magnitud ajena al tipo de asignación: " + nombre + ".");
            return Valor;
        }

        internal void Escribir(string nombre, object valor)
        {
            Exige(nombre == campo || nombre == "Units" && campo == "Work",
                "Se escribió una magnitud ajena al tipo de asignación: " + nombre + ".");
            Escrituras.Add(nombre);
            if (IgnorarEscritura) return;
            if (nombre == "Units" && campo == "Work")
            {
                Unidades = Convert.ToDecimal(valor, CultureInfo.InvariantCulture);
                if (RecalcularTrabajoAlCambiarUnidades) Valor = 960m * Unidades;
            }
            else Valor = valor;
        }
    }
}
