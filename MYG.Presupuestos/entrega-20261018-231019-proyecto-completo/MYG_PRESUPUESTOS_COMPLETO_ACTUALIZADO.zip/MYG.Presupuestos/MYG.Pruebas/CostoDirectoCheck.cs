using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG_2027;

internal static class CostoDirectoCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new Exception("Se aceptó una configuración de costo directo o fuente inválida.");
    }

    private static MYGProyectoDocumento Crear()
    {
        var doc = MYGProyectoStorage.Nuevo("CONFIGURACIÓN COSTO DIRECTO QA");
        var p = doc.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        partida.Costos.Cantidad = 2;
        var grupos = new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales,
            MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos };
        var tasas = new[] { 10m, 20m, 5m, 18m };
        for (int n = 0; n < grupos.Length; n++)
        {
            var insumo = new MYGInsumo { Descripcion = "INSUMO " + grupos[n], Codigo = "R" + n,
                Grupo = grupos[n], Precio = (n + 1) * 10, IGVPorcentaje = tasas[n] };
            p.Costos.Insumos.Add(insumo);
            partida.Costos.Analisis.Add(new MYGRecursoACU { Grupo = grupos[n], InsumoId = insumo.Id, Cantidad = 1 });
        }
        MYGProyectoStorage.Validar(doc);
        return doc;
    }

    private static MYGConfiguracionCostoDirecto Todo(string nombre = "Costo directo propio") => new()
    { Nombre = nombre, IncluirIgvManoObra = true, IncluirIgvMateriales = true,
        IncluirIgvEquipo = true, IncluirIgvSubcontratos = true };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        HistoricoYGrupos(pasa);
        SubpartidasYFirmas(pasa);
        EquipoPorcentual(pasa);
        Persistencia(carpeta, pasa);
        Validacion(pasa);
    }

    private static void HistoricoYGrupos(Action<string> pasa)
    {
        var doc = Crear(); var p = doc.Presupuestos.Single(); var i = p.Items.Single(); var d = i.Costos;
        string historica = JsonSerializer.Serialize(new
        {
            i.Unidad, d.PrecioDirecto, d.RendimientoDiario, d.JornadaHoras,
            p.Costos.DecimalesCantidad, p.Costos.DecimalesPrecio, d.Analisis,
            Insumos = d.Analisis.Where(r => r.Grupo != MYGGrupoRecurso.Subpartidas)
                .Select(r => p.Costos.Insumos.Single(x => x.Id == r.InsumoId))
                .Select(x => new { x.Id, x.Precio, x.Unidad }).ToList()
        });
        string firmaHistorica = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(historica)));
        Exige(MYGMotorPresupuestos.FirmaAnalisis(p, i) == firmaHistorica &&
            !JsonSerializer.Serialize(p.Costos).Contains("ConfiguracionCostoDirecto") &&
            !JsonSerializer.Serialize(p.Costos).Contains("EstilosFilasResumen") &&
            MYGMotorPresupuestos.Resumen(p).CostoDirecto == 200,
            "Un presupuesto anterior cambió su JSON, firma o cálculo sin configurar el costo directo.");
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, i, 100.01m, 200.03m);
        MYGMotorPresupuestos.CapturarDatosDelphin(p, i);
        MYGMotorPresupuestos.CapturarPresupuestoDelphin(p);
        MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { p }, new() { Nombre = "Costo renombrado" });
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i) && MYGMotorPresupuestos.ConservaDatosDelphin(p, i) &&
            MYGMotorPresupuestos.ConservaPresupuestoDelphin(p) && MYGMotorPresupuestos.TotalPartida(p, i) == 200.03m &&
            MYGPiePresupuesto.Filas(new[] { p })[0].Nombre == "Costo renombrado",
            "Renombrar el costo directo sin aplicar IGV perdió redondeos importados o la etiqueta.");
        MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { p }, new() { IncluirIgvMateriales = true });
        var a = MYGMotorPresupuestos.Analizar(p, i);
        Exige(a.Recursos.Select(x => x.Precio).SequenceEqual(new[] { 10m, 24m, 30m, 40m }) &&
            a.PrecioUnitario == 104 && MYGMotorPresupuestos.Resumen(p).CostoDirecto == 208 &&
            !MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i) &&
            p.Costos.Insumos.Select(x => x.Precio).SequenceEqual(new[] { 10m, 20m, 30m, 40m }),
            "El IGV debe modificar sólo el precio efectivo del grupo seleccionado y recalcular los importados.");
        MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { p }, Todo());
        a = MYGMotorPresupuestos.Analizar(p, i);
        Exige(a.Recursos.Select(x => x.Precio).SequenceEqual(new[] { 11m, 24m, 31.5m, 47.2m }) &&
            a.PrecioUnitario == 113.7m && MYGMotorPresupuestos.Consolidar(p).Sum(x => x.Total) == 227.4m,
            "Los cuatro grupos deben aplicar su propia tasa y coincidir con el consolidado.");
        MYGPiePresupuesto.Limpiar(new[] { p });
        Exige(MYGPiePresupuesto.Filas(new[] { p }).Single().Nombre == "Costo directo propio",
            "El pie personalizado perdió el nombre configurado del costo directo.");
        var hoja = MYGReportesProyecto.CrearResumenPresupuesto(doc, p.Id).Hoja;
        Exige(hoja.Celdas.Values.Any(c => c.Contenido == "Costo directo propio"),
            "El informe del presupuesto no conserva el nombre configurado del costo directo.");
        pasa("Costo directo mantiene firmas y JSON históricos, permite renombrar y aplica IGV independiente por grupo sin cambiar precios base");
    }

    private static void SubpartidasYFirmas(Action<string> pasa)
    {
        var doc = Crear(); var p = doc.Presupuestos.Single(); var sub = p.Items.Single();
        sub.Costos.Cantidad = 0;
        var padre = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        padre.Costos.Cantidad = 2;
        padre.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas,
            SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = 3 });
        padre.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Materiales,
            InsumoId = p.Costos.Insumos.Single(x => x.Grupo == MYGGrupoRecurso.Materiales).Id, Cantidad = 1 });
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, sub, 100, 0);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, padre, 320.01m, 640.03m);
        MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { p }, Todo());
        Exige(!MYGMotorPresupuestos.ConservaAnalisisDelphin(p, sub) && !MYGMotorPresupuestos.ConservaAnalisisDelphin(p, padre) &&
            MYGMotorPresupuestos.Analizar(p, padre).PrecioUnitario == 365.1m &&
            MYGMotorPresupuestos.Resumen(p).CostoDirecto == 730.2m && MYGMotorPresupuestos.Consolidar(p).Sum(x => x.Total) == 730.2m,
            "El IGV de subpartidas debe invalidar el precio importado del padre y consolidarse sin gravar dos veces.");
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, padre, 365.11m, 730.23m);
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(p, padre),
            "Una firma capturada con IGV debe poder conservarse sin nuevas modificaciones.");
        p.Costos.ConfiguracionCostoDirecto.Nombre = "Sólo cambia la etiqueta";
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(p, padre),
            "El nombre visible no debe invalidar firmas de importación numéricas.");
        var sinEfecto = Crear().Presupuestos.Single(); var vacia = sinEfecto.Items.Single();
        foreach (var insumo in sinEfecto.Costos.Insumos) insumo.IGVPorcentaje = 0;
        MYGMotorPresupuestos.CapturarPrecioDelphin(sinEfecto, vacia, 100.01m, 200.03m);
        MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { sinEfecto }, Todo());
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(sinEfecto, vacia) && MYGMotorPresupuestos.TotalPartida(sinEfecto, vacia) == 200.03m,
            "Activar grupos con IGV cero no debe invalidar precios importados.");
        foreach (var insumo in sinEfecto.Costos.Insumos) { insumo.IGVPorcentaje = 18; insumo.Precio = 0; }
        MYGMotorPresupuestos.CapturarPrecioDelphin(sinEfecto, vacia, 0.01m, 0.03m);
        sinEfecto.Costos.ConfiguracionCostoDirecto = null;
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(sinEfecto, vacia),
            "Cambiar la selección sin efecto monetario no debe invalidar el precio importado.");
        pasa("Subpartidas aplican IGV una vez, actualizan firmas de sus padres y conservan importados cuando la selección no cambia importes");
    }

    private static void EquipoPorcentual(Action<string> pasa)
    {
        var p = Crear().Presupuestos.Single(); var i = p.Items.Single();
        i.Costos.Analisis.RemoveAll(x => x.Grupo is MYGGrupoRecurso.Materiales or MYGGrupoRecurso.Subcontratos);
        var mano = p.Costos.Insumos.Single(x => x.Grupo == MYGGrupoRecurso.ManoObra);
        mano.Precio = 100; mano.IGVPorcentaje = 18;
        var equipo = p.Costos.Insumos.Single(x => x.Grupo == MYGGrupoRecurso.Equipo);
        equipo.Precio = 0; equipo.IGVPorcentaje = 10;
        var herramienta = i.Costos.Analisis.Single(x => x.Grupo == MYGGrupoRecurso.Equipo);
        herramienta.Modo = MYGModoCantidad.PorcentajeManoObra; herramienta.Cantidad = 5;
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, i, 105, 210);
        MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { p }, new() { IncluirIgvEquipo = true });
        Exige(MYGMotorPresupuestos.Analizar(p, i).PrecioUnitario == 105.5m &&
            !MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i),
            "El IGV del equipo porcentual debe gravar su costo derivado aunque su precio de catálogo sea cero.");
        p.Costos.ConfiguracionCostoDirecto.IncluirIgvManoObra = true;
        Exige(MYGMotorPresupuestos.Analizar(p, i).PrecioUnitario == 124.49m &&
            MYGMotorPresupuestos.Consolidar(p).Sum(x => x.Total) == 248.98m,
            "El equipo porcentual debe usar mano de obra con IGV y coincidir con el consolidado.");
        pasa("Equipo calculado como porcentaje de mano de obra aplica su IGV sobre el costo derivado y conserva totales coherentes");
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var doc = Crear(); var p = doc.Presupuestos.Single();
        MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { p }, Todo("Costo directo persistido"));
        p.Costos.EstilosFilasResumen = new() { [MYGPiePresupuesto.IdCostoDirecto] = new()
        { Fuente = "Tahoma", Tamano = 7.8m, Negrita = true, Cursiva = true, Tachado = true,
            Subrayado = true, ColorTexto = "#123456", ColorFondo = "#ABCDEF" } };
        string firma = MYGMotorPresupuestos.FirmaAnalisis(p, p.Items.Single());
        string ruta = Path.Combine(carpeta, "Costo directo y fuente.myg.json");
        MYGProyectoStorage.Guardar(ruta, doc);
        foreach (var reabierto in new[] { MYGProyectoStorage.Leer(ruta), MYGBaseDatos.LeerProyecto(MYGBaseDatos.RutaDeProyecto(ruta), doc.Id) })
        {
            var copia = reabierto.Presupuestos.Single(); var c = copia.Costos.ConfiguracionCostoDirecto;
            var estilo = copia.Costos.EstilosFilasResumen.Single();
            Exige(c.Nombre == "Costo directo persistido" && c.IncluirIgvManoObra && c.IncluirIgvMateriales &&
                c.IncluirIgvEquipo && c.IncluirIgvSubcontratos && MYGMotorPresupuestos.Resumen(copia).CostoDirecto == 227.4m &&
                estilo.Key == MYGPiePresupuesto.IdCostoDirecto && estilo.Value.Fuente == "Tahoma" && estilo.Value.Tamano == 7.8m &&
                estilo.Value.Negrita && estilo.Value.Cursiva && estilo.Value.Tachado && estilo.Value.Subrayado &&
                estilo.Value.ColorTexto == "#123456" && estilo.Value.ColorFondo == "#ABCDEF" &&
                MYGMotorPresupuestos.FirmaAnalisis(copia, copia.Items.Single()) == firma,
                "JSON o SQLite perdieron configuración, fuente exclusiva de fila, efectos, colores o precisión del costo directo.");
            copia.Costos.EstilosFilasResumen = null;
            Exige(MYGMotorPresupuestos.FirmaAnalisis(copia, copia.Items.Single()) == firma,
                "Cambiar sólo la fuente de una fila debe conservar las firmas numéricas de importación.");
        }
        pasa("JSON y SQLite conservan nombre, grupos de IGV y fuente de una sola fila sin alterar firmas numéricas");
    }

    private static void Validacion(Action<string> pasa)
    {
        var doc = Crear(); var p = doc.Presupuestos.Single(); string antes = MYGProyectoStorage.Firma(doc);
        foreach (string nombre in new[] { "", " ", new string('x', 251) })
        {
            Rechaza(() => MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { p }, new() { Nombre = nombre }));
            Exige(MYGProyectoStorage.Firma(doc) == antes, "Una configuración inválida modificó parcialmente el documento.");
        }
        foreach (decimal tasa in new[] { -1m, 101m })
        {
            var copia = MYGProyectoStorage.Copia(p); copia.Costos.Insumos[0].IGVPorcentaje = tasa;
            Rechaza(() => MYGPiePresupuesto.ConfigurarCostoDirecto(new[] { copia }, Todo()));
            Exige(copia.Costos.ConfiguracionCostoDirecto == null, "Se guardó una selección con IGV de insumo inválido.");
        }
        foreach (var estilo in new MYGEstiloFilaResumen[] { null, new() { Fuente = " " }, new() { Tamano = 0 },
            new() { Tamano = 201 }, new() { ColorTexto = "rojo" }, new() { ColorFondo = "#GGGGGG" } })
        {
            var copia = MYGProyectoStorage.Copia(p);
            copia.Costos.EstilosFilasResumen = new() { [MYGPiePresupuesto.IdCostoDirecto] = estilo };
            Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(copia));
        }
        var sinClave = MYGProyectoStorage.Copia(p); sinClave.Costos.EstilosFilasResumen = new() { [""] = new() };
        Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(sinClave));
        pasa("Configuración inválida se rechaza sin cambios parciales y las fuentes validan nombres, tamaño, colores e identidad de fila");
    }
}
