using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class IndicesUnificadosCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static SqliteConnection Conexion(string ruta)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false }.ToString());
        c.Open(); return c;
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Índices oficiales 2026.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        string antesLeer = Huella(ruta);
        var indices = MYGCatalogoIndicesUnificados.Listar(ruta);
        Exige(indices.Count == 78 && indices.Select(i => i.Codigo).Distinct().Count() == 78,
            "El catálogo inicial no contiene los 78 códigos únicos del Anexo 1.");
        Exige(indices.Single(i => i.Codigo == "21").Descripcion == "Cemento Portland e hidráulico" &&
            indices.Single(i => i.Codigo == "47-1").Descripcion == "Mano de obra de alta especialización (incluye leyes sociales)" &&
            indices.Single(i => i.Codigo == "95").Descripcion == "Equipamiento permanente de obra",
            "El catálogo perdió una denominación nueva o el código compuesto 47-1.");
        Exige(new[] { "47-1" }.Concat(Enumerable.Range(81, 15).Select(n => n.ToString()))
            .All(codigo => indices.Any(i => i.Codigo == codigo)), "Faltan índices creados por la norma de 2026.");
        Exige(!new[] { "22", "23", "45", "64", "69", "70", "73" }
            .Any(codigo => indices.Any(i => i.Codigo == codigo)), "Se ofrecen códigos reagrupados como vigentes.");
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT COUNT(*) FROM myg_indice_unificado WHERE periodo_base='Diciembre 2025=100' AND resolucion='016-2026-INEI'";
            Exige(Convert.ToInt64(cmd.ExecuteScalar()) == 78, "La base no conserva la referencia normativa de los índices.");
            cmd.CommandText = "PRAGMA integrity_check";
            Exige((string)cmd.ExecuteScalar() == "ok", "La base inicial con índices no supera integrity_check.");
        }
        Exige(Huella(ruta) == antesLeer, "Consultar el catálogo inicial modificó la base.");
        pasa("Bases nuevas incluyen 78 IUPC del Anexo 1, códigos 47-1 y 81–95, nueva base y denominaciones, sin códigos reagrupados");

        var documento = MYGProyectoStorage.Nuevo("ÍNDICES Y UNIDADES");
        var insumo = new MYGInsumo { Codigo = "CEM-QA", Descripcion = "CEMENTO DE PRUEBA", Unidad = "Bls", Precio = 28,
            GrupoGenerico = indices.Single(i => i.Codigo == "21").ToString() };
        documento.Presupuestos[0].Costos.Insumos.Add(insumo);
        MYGProyectoStorage.Guardar(ruta, documento);
        MYGCatalogos.GuardarInsumo(ruta, insumo);
        var entrada = MYGCatalogos.Listar(ruta, false).Single();
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, documento.Id).Presupuestos[0].Costos.Insumos.Single();
        var catalogado = MYGCatalogos.LeerInsumo(ruta, entrada.Id, entrada.Revision);
        Exige(reabierto.GrupoGenerico == insumo.GrupoGenerico && reabierto.Unidad == "Bls" &&
            catalogado.GrupoGenerico == insumo.GrupoGenerico && catalogado.Unidad == "Bls",
            "Guardar proyecto o catálogo perdió la clasificación IU o la unidad de bolsas.");
        string copia = Path.Combine(carpeta, "Copia con catálogo IU.sqlite");
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            // Una copia debe leer y conservar el catálogo de origen, no reemplazarlo por el del ejecutable.
            cmd.CommandText = "UPDATE myg_indice_unificado SET descripcion='Aditivo de prueba conservado' WHERE codigo='81'";
            cmd.ExecuteNonQuery();
        }
        MYGProyectoStorage.Guardar(copia, documento, ruta);
        Exige(MYGCatalogoIndicesUnificados.Listar(ruta).Single(i => i.Codigo == "81").Descripcion == "Aditivo de prueba conservado" &&
            MYGCatalogoIndicesUnificados.Listar(copia).Single(i => i.Codigo == "81").Descripcion == "Aditivo de prueba conservado" &&
            MYGCatalogoIndicesUnificados.Listar().Single(i => i.Codigo == "81").Descripcion == "Aditivo de concreto y similar",
            "El selector o Guardar copia ignora el catálogo de la base o altera los valores predeterminados.");
        pasa("Clasificación IU y Bls persisten en proyecto y catálogo; Guardar copia conserva el catálogo de índices del archivo");

        string anterior = Path.Combine(carpeta, "Base anterior sin IUPC.sqlite");
        MYGBaseDatos.CrearBaseVacia(anterior);
        insumo.GrupoGenerico = "22 · Cemento Portland tipo II";
        MYGProyectoStorage.Guardar(anterior, documento);
        using (var c = Conexion(anterior))
        using (var cmd = c.CreateCommand())
        { cmd.CommandText = "DROP TABLE myg_indice_unificado"; cmd.ExecuteNonQuery(); }
        string huellaAnterior = Huella(anterior);
        var disponibles = MYGCatalogoIndicesUnificados.Listar(anterior);
        Exige(disponibles.Count == 78 && MYGBaseDatos.LeerProyecto(anterior, documento.Id)
            .Presupuestos[0].Costos.Insumos.Single().GrupoGenerico == "22 · Cemento Portland tipo II",
            "Consultar una base anterior reclasificó el insumo histórico o no ofreció los IUPC actuales.");
        Exige(Huella(anterior) == huellaAnterior, "Leer IUPC en una base anterior realizó una migración no solicitada.");
        MYGProyectoStorage.Guardar(anterior, MYGBaseDatos.LeerProyecto(anterior, documento.Id));
        Exige(MYGBaseDatos.LeerProyecto(anterior, documento.Id).Presupuestos[0].Costos.Insumos.Single().GrupoGenerico ==
            "22 · Cemento Portland tipo II", "Guardar sin reclasificar cambió la asociación histórica.");
        pasa("Bases anteriores ofrecen IUPC nuevos sin escribir al consultarlas y conservan la clasificación histórica al guardar");
    }
}
