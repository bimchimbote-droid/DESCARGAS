using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using MYG_2027;

internal static class PlantillasMetradoCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Rechaza(Action accion, string mensaje)
    { try { accion(); } catch (InvalidDataException) { return; } throw new Exception(mensaje); }
    private static void Entrada(MYGHojaMetrado hoja, string direccion, string contenido)
    {
        MYGEdicionHoja.ValidarEntrada(hoja, direccion, contenido);
        MYGEdicionHoja.Celda(hoja, direccion).Contenido = contenido;
    }
    private static MYGHojaMetrado Ejemplo()
    {
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        Entrada(hoja, "A3", "Barras con gancho y empalme");
        Entrada(hoja, "B3", "2"); Entrada(hoja, "C3", "3"); Entrada(hoja, "D3", "3/8");
        Entrada(hoja, "E3", "4"); Entrada(hoja, "F3", "0.3"); Entrada(hoja, "G3", "0.5"); Entrada(hoja, "H3", "5");
        Entrada(hoja, "B4", "1"); Entrada(hoja, "C4", "2"); Entrada(hoja, "D4", "12mm"); Entrada(hoja, "E4", "3.2");
        Entrada(hoja, "B5", "3"); Entrada(hoja, "C5", "2"); Entrada(hoja, "D5", "3/8″"); Entrada(hoja, "E5", "1");
        Entrada(hoja, "B6", "1"); Entrada(hoja, "C6", "1"); Entrada(hoja, "D6", "1 pulg"); Entrada(hoja, "E6", "2");
        Entrada(hoja, "AD3", "E-01");
        return hoja;
    }

    public static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var estandar = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Estandar);
        var aceros = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        Exige(MYGPlantillasMetrado.Disponibles.Count == 2 &&
            MYGPlantillasMetrado.Disponibles.Select(p => p.Id).SequenceEqual(new[] { "estandar", "aceros" }) &&
            MYGPlantillasMetrado.Disponibles.All(p => !string.IsNullOrWhiteSpace(p.Nombre)) &&
            estandar.IdPlantilla == "estandar" && estandar.CeldaTotal == "G16" && aceros.IdPlantilla == "aceros",
            "Deben existir exactamente las dos plantillas integradas, con la estándar como selección inicial.");
        var otraEstandar = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Estandar);
        Entrada(otraEstandar, "A3", "Datos de otra partida"); otraEstandar.RangosCombinados.Clear();
        Exige(!estandar.Celdas.ContainsKey("A3") && estandar.RangosCombinados.Contains("A1:C1"),
            "Las hojas estándar de dos partidas deben ser independientes.");
        var otra = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        aceros.Celdas["D3"].ListaValores.Clear(); aceros.Celdas["I15"].Contenido = "100";
        Exige(otra.Celdas["D3"].ListaValores.Contains("3/8") && otra.Celdas["I15"].Contenido == "0.099",
            "Las plantillas de dos partidas no pueden compartir celdas ni listas de validación.");
        string legadoJson = JsonSerializer.Serialize(estandar).Replace("\"IdPlantilla\":\"estandar\",", "", StringComparison.Ordinal);
        var legado = JsonSerializer.Deserialize<MYGHojaMetrado>(legadoJson);
        string antes = JsonSerializer.Serialize(legado);
        Exige(legado.IdPlantilla == "" && MYGPlantillasMetrado.Identificar(legado) == "estandar" && JsonSerializer.Serialize(legado) == antes,
            "Identificar una hoja estándar anterior no debe modificar sus datos.");
        var personalizada = new MYGHojaMetrado(); personalizada.Poner("A1", "Planilla propia");
        string personalAntes = JsonSerializer.Serialize(personalizada);
        Exige(MYGPlantillasMetrado.Identificar(personalizada) == "" && JsonSerializer.Serialize(personalizada) == personalAntes &&
            MYGPlantillasMetrado.Identificar(null) == "", "Una hoja personalizada no debe convertirse ni modificarse al abrirla.");
        pasa("Dos plantillas integradas e independientes, con identidad persistente y detección de hojas anteriores sin cambios");

        VerificarCompatibilidad(legado, pasa);
        VerificarCalculo(pasa);
        VerificarEdicion(pasa);
        VerificarExcel(carpeta, pasa);
        VerificarSQLite(carpeta, pasa);
    }

    private static void VerificarCompatibilidad(MYGHojaMetrado legado, Action<string> pasa)
    {
        var datos = new MYGDatosPartida { Hoja = legado };
        string antes = JsonSerializer.Serialize(datos);
        Exige(!MYGMotorPresupuestos.TieneDatosPropios(datos) && JsonSerializer.Serialize(datos) == antes,
            "La identidad vacía de una hoja estándar anterior no debe crear datos propios ni cambiar la hoja.");
        var editados = MYGProyectoStorage.Copia(datos);
        editados.Hoja.Celdas["A2"].Subrayado = true;
        Exige(MYGMotorPresupuestos.TieneDatosPropios(editados), "Ignorar la identidad anterior no debe ocultar estilos editados.");
        editados = MYGProyectoStorage.Copia(datos); editados.Hoja.Zoom = 125;
        Exige(MYGMotorPresupuestos.TieneDatosPropios(editados), "Ignorar la identidad anterior no debe ocultar configuración editada.");
        editados = MYGProyectoStorage.Copia(datos); Entrada(editados.Hoja, "A3", "Metrado propio");
        Exige(MYGMotorPresupuestos.TieneDatosPropios(editados) &&
            MYGMotorPresupuestos.TieneDatosPropios(new MYGDatosPartida { Hoja = MYGPlantillasMetrado.Crear("aceros") }),
            "Las celdas modificadas y la plantilla de aceros deben seguir siendo datos propios.");

        var presupuesto = new MYGPresupuestoDocumento { Nombre = "VINCULAR HOJA ESTÁNDAR ANTERIOR" };
        var oficial = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        oficial.Costos.Cantidad = 7; oficial.Costos.PrecioDirecto = 4;
        var insumo = new MYGInsumo { Descripcion = "INSUMO OFICIAL", Unidad = "kg", Precio = 3, Grupo = MYGGrupoRecurso.Materiales };
        presupuesto.Costos.Insumos.Add(insumo);
        oficial.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Cantidad = 2, Grupo = MYGGrupoRecurso.Materiales });
        var propuesta = new ItemPresupuestoDelphin
        { Id = MYGProyectoStorage.NuevoId(), Descripcion = "PROPUESTA ANTERIOR", Unidad = "kg", TipoPropuesta = "PARTIDA", Costos = datos };
        var costosOficiales = oficial.Costos;
        string oficialesAntes = JsonSerializer.Serialize(costosOficiales);
        MYGProyectoStorage.Vincular(propuesta, oficial);
        Exige(ReferenceEquals(oficial.Costos, costosOficiales) && JsonSerializer.Serialize(oficial.Costos) == oficialesAntes &&
            oficial.Costos.Cantidad == 7 && oficial.Costos.PrecioDirecto == 4 && oficial.Costos.Analisis.Single().InsumoId == insumo.Id &&
            MYGMotorPresupuestos.Analizar(presupuesto, oficial).PrecioUnitario == 6 && JsonSerializer.Serialize(datos) == antes,
            "Vincular una propuesta anterior sin datos propios no debe borrar ni sustituir el ACU oficial.");
        pasa("Una hoja estándar anterior sin identidad conserva el ACU oficial al vincular; estilos, celdas y vistas editadas siguen siendo datos propios");
    }

    private static void VerificarCalculo(Action<string> pasa)
    {
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        var calculo = new MYGHojaCalculo(hoja);
        Exige(hoja.CeldaTotal == "AD16" && hoja.AreaImpresion == "A1:AD16" && hoja.OrientacionPagina == "Horizontal" &&
            hoja.RangosCombinados.Contains("I1:AC1") && hoja.RangosCombinados.Contains("AD14:AD15") &&
            Enumerable.Range(9, 21).All(c => calculo.Numero(MYGHojaCalculo.Columna(c) + "14") == 0) &&
            hoja.Celdas.Where(c => c.Value.Contenido.StartsWith('=')).All(c => calculo.Mostrar(c.Key) != "#ERROR") && calculo.Numero("AD16") == 0,
            "La plantilla de aceros vacía debe tener 21 diámetros y calcular cero sin errores.");
        decimal[] pesos = [0.099m, 0.125m, 0.154m, 0.187m, 0.220m, 0.250m, 0.260m, 0.302m, 0.347m, 0.400m, 0.445m,
            0.580m, 0.890m, 1.020m, 1.600m, 2.260m, 3.040m, 4.000m, 5.060m, 6.400m, 7.910m];
        for (int indice = 0; indice < pesos.Length; indice++)
        {
            string columna = MYGHojaCalculo.Columna(indice + 9);
            Entrada(hoja, "B3", "2"); Entrada(hoja, "C3", "3"); Entrada(hoja, "D3", hoja.Celdas[columna + "2"].Contenido); Entrada(hoja, "E3", "4");
            calculo = new MYGHojaCalculo(hoja);
            Exige(calculo.Numero(columna + "14") == 24 && calculo.Numero(columna + "15") == pesos[indice] &&
                calculo.Numero("AD16") == 24 * pesos[indice], "El diámetro " + columna + " no usa su peso por metro.");
        }
        hoja = Ejemplo(); calculo = new MYGHojaCalculo(hoja);
        Exige(calculo.Numero("T3") == 30.24m && calculo.Numero("T14") == 36.24m && calculo.Numero("U14") == 6.4m &&
            calculo.Numero("Z14") == 2 && calculo.Numero("AD16") == 34.7152m,
            "Gancho, empalme, desperdicio, alias en pulgadas y pesos deben producir el total real de acero.");
        Entrada(hoja, "E3", "=SUMA(3;1)");
        Exige(new MYGHojaCalculo(hoja).Numero("AD16") == 34.7152m,
            "Las entradas de acero deben aceptar las funciones Excel existentes del software.");
        Entrada(hoja, "B7", "2"); Entrada(hoja, "C7", "3"); Entrada(hoja, "E7", "100");
        Entrada(hoja, "D8", "4mm"); Entrada(hoja, "E8", "100");
        Exige(new MYGHojaCalculo(hoja).Numero("AD16") == 34.7152m,
            "Las filas sin diámetro o sin cantidades no deben añadir longitud de acero.");
        Entrada(hoja, "T15", "0.600");
        Exige(new MYGHojaCalculo(hoja).Numero("AD16") == 35.44m, "Cambiar un peso por metro debe recalcular el peso total.");
        Rechaza(() => Entrada(hoja, "D3", "99mm"), "Se aceptó un diámetro que no figura en la plantilla.");
        Rechaza(() => Entrada(hoja, "H3", "-1"), "Se aceptó desperdicio negativo.");
        Rechaza(() => Entrada(hoja, "T15", "-0.5"), "Se aceptó peso por metro negativo.");
        Exige(hoja.Celdas["H3"].FormatoNumero == "0.##", "El desperdicio 5 debe significar 5%, sin aplicar formato porcentual dos veces.");
        pasa("Aceros calcula los 21 diámetros, ganchos, empalmes, desperdicio y pesos editables con validación y filas vacías seguras");
    }

    private static void VerificarEdicion(Action<string> pasa)
    {
        var hoja = Ejemplo();
        MYGEdicionHoja.InsertarFilas(hoja, 4);
        Exige(hoja.CeldaTotal == "AD17" && hoja.Celdas["T15"].Contenido == "=SUM(T3:T14)" &&
            hoja.AreaImpresion == "A1:AD17" && new MYGHojaCalculo(hoja).Numero(hoja.CeldaTotal) == 34.7152m,
            "Insertar una fila debe extender las referencias y conservar el total de aceros.");
        MYGEdicionHoja.RellenarRango(hoja, "A3:AD3", "A3:AD4");
        Exige(hoja.Celdas["T4"].Contenido.Contains("$D4=T$2", StringComparison.Ordinal) &&
            hoja.Celdas["D4"].ListaValores.Contains("3/8") && new MYGHojaCalculo(hoja).Numero(hoja.CeldaTotal) == 52.2544m,
            "Rellenar una fila insertada debe trasladar fórmulas y conservar las reglas de entrada.");
        MYGEdicionHoja.EliminarFilas(hoja, 4);
        MYGEdicionHoja.InsertarColumnas(hoja, 5);
        Exige(hoja.IdPlantilla == "aceros" && hoja.CeldaTotal == "AE16" && hoja.AreaImpresion == "A1:AE16" &&
            hoja.Celdas["U3"].Contenido.Contains("$D3=U$2", StringComparison.Ordinal) &&
            new MYGHojaCalculo(hoja).Numero(hoja.CeldaTotal) == 34.7152m,
            "Insertar una columna debe ajustar fórmulas, área de impresión y total sin perder la plantilla.");
        pasa("Aceros admite insertar, rellenar y eliminar filas y columnas con referencias, validaciones y total coherentes");
    }

    private static void VerificarExcel(string carpeta, Action<string> pasa)
    {
        var hoja = Ejemplo();
        hoja.Celdas["A3"].Cursiva = true; hoja.Celdas["A3"].ColorTexto = "123456";
        hoja.Celdas["A3"].ColorFondo = "FEDCBA"; hoja.Celdas["A3"].Subrayado = true;
        hoja.Zoom = 125; hoja.FilasOcultas.Add(12); hoja.ColumnasInmovilizadas = 1;
        string ruta = Path.Combine(carpeta, "Plantilla aceros completa.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { hoja });
        var importada = MYGExcelPresupuestos.Importar(ruta, hoja.Nombre, hoja.CeldaTotal);
        Exige(importada.IdPlantilla == "" && MYGPlantillasMetrado.Identificar(importada) == "" &&
            importada.RangosCombinados.SequenceEqual(hoja.RangosCombinados) && importada.AreaImpresion == hoja.AreaImpresion &&
            importada.Zoom == 125 && importada.ColumnasInmovilizadas == 1 && importada.FilasOcultas.Contains(12) &&
            importada.OrientacionPagina == "Horizontal" && importada.AnchosColumnas[30] == hoja.AnchosColumnas[30] &&
            importada.AltosFilas[2] == hoja.AltosFilas[2] && new MYGHojaCalculo(importada).Numero(importada.CeldaTotal) == 34.7152m,
            "El intercambio XLSX debe conservar la planilla de aceros completa sin imponer una identidad de plantilla al importar.");
        foreach (var celda in hoja.Celdas)
            Exige(importada.Celdas.TryGetValue(celda.Key, out var equivalente) &&
                JsonElement.DeepEquals(JsonSerializer.SerializeToElement(celda.Value), JsonSerializer.SerializeToElement(equivalente)),
                "XLSX perdió contenido, formato o reglas en " + celda.Key + ".");
        pasa("Aceros exporta e importa XLSX con todas sus celdas, fórmulas, estilos, listas, combinaciones y configuración de impresión");
    }

    private static void VerificarSQLite(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Plantillas SQLite vacío.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        string inicial = Huella(ruta);
        Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 0 && MYGPlantillasMetrado.Disponibles.Count == 2,
            "Las dos plantillas deben estar disponibles sin proyectos ni registros de plantilla en SQLite.");
        foreach (var plantilla in MYGPlantillasMetrado.Disponibles)
            Exige(MYGPlantillasMetrado.Identificar(MYGPlantillasMetrado.Crear(plantilla.Id)) == plantilla.Id, "No se identificó una plantilla integrada.");
        Exige(Huella(ruta) == inicial, "Mostrar las plantillas en una base vacía no debe escribir en SQLite.");
        var documento = MYGProyectoStorage.Nuevo("METRADO DE ACEROS", "ESTRUCTURAS");
        string id = MYGProyectoStorage.NuevoId();
        var partida = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = "ACERO DE REFUERZO", Unidad = "kg",
            TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1
        };
        partida.Costos.Hoja = Ejemplo(); partida.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        documento.Presupuestos[0].Items.Add(partida);
        MYGBaseDatos.GuardarProyecto(ruta, documento);
        string guardada = Huella(ruta);
        var leido = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        var hojaLeida = leido.Presupuestos[0].Items.Single().Costos.Hoja;
        Exige(hojaLeida.IdPlantilla == "aceros" && MYGPlantillasMetrado.Identificar(hojaLeida) == "aceros" &&
            JsonElement.DeepEquals(JsonSerializer.SerializeToElement(hojaLeida), JsonSerializer.SerializeToElement(partida.Costos.Hoja)) &&
            new MYGHojaCalculo(hojaLeida).Numero(hojaLeida.CeldaTotal) == 34.7152m && Huella(ruta) == guardada,
            "Guardar y reabrir SQLite debe conservar identidad, formatos y cálculo sin escribir al abrir.");
        pasa("SQLite vacío ofrece las dos plantillas sin migración; guardar y reabrir conserva la hoja de aceros sin escrituras de apertura");
    }
}
