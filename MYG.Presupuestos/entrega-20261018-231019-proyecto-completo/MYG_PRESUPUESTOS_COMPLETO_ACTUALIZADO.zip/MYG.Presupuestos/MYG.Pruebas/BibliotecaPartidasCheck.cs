using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using MYG_2027;

internal static class BibliotecaPartidasCheck
{
    private static void Exige(bool ok, string texto) { if (!ok) throw new Exception(texto); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Rechaza<T>(Action accion) where T : Exception
    { bool rechazada = false; try { accion(); } catch (T) { rechazada = true; } Exige(rechazada, "La operación inválida no fue rechazada: " + typeof(T).Name); }
    private static ItemPresupuestoDelphin Partida(string analisis = "AC-FALSO-PISO", string fuente = "CATALOGO-A", string valor = null)
    {
        string id = MYGProyectoStorage.NuevoId();
        var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = "FALSO PISO",
            CodigoDelphin = "0001", Unidad = "m²", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA",
            IdCatalogoDelphin = analisis, FuenteCatalogoId = fuente, FuenteCatalogoRuta = "BASE_GENERAL.sqlite" };
        if (valor != null)
        {
            i.Plantilla = "PLANTILLA_SUELOS_M2";
            i.Filtros.Add(new FiltroPlanificacion { Parametro = "Descripción", Regla = "es igual a", Valor = valor });
            i.Filtros.Add(new FiltroPlanificacion());
        }
        return i;
    }
    private static MYGGuardarConfiguracionSolicitud Guardar(ItemPresupuestoDelphin i, string nombre, string actualizar = null) =>
        new MYGGuardarConfiguracionSolicitud { Partida = i, Nombre = nombre, IdActualizar = actualizar };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Biblioteca común ; filtros.biblioteca.json");
        var vieja = new MYGBibliotecaDocumento { Version = 1 };
        var presupuesto = MYGProyectoStorage.Nuevo("PROYECTO ANTERIOR").Presupuestos[0];
        var anterior = Partida(valor: "Falso piso e=0.10m"); presupuesto.Items.Add(anterior);
        vieja.Plantillas.Add(new MYGPlantillaPresupuesto { Nombre = "Presupuesto anterior", Presupuesto = presupuesto });
        File.WriteAllText(ruta, JsonSerializer.Serialize(vieja));
        var b = MYGProyectoStorage.LeerBiblioteca(ruta);
        Exige(b.Version == 1 && b.Configuraciones.Count == 0 && b.Plantillas[0].Presupuesto.Items[0].Filtros[0].Valor == "Falso piso e=0.10m",
            "No abre una biblioteca anterior.");
        b = MYGBibliotecaPartidas.GuardarConfiguraciones(ruta, b, new[] { Guardar(anterior, "Falso piso — interiores") });
        Exige(b.Version == 2 && MYGProyectoStorage.LeerBiblioteca(ruta).Plantillas.Count == 1 && File.Exists(ruta + ".bak"),
            "Actualizar la biblioteca borró sus presupuestos anteriores.");
        pasa("Biblioteca v1 migra a v2 conservando presupuestos y respaldo, sin crear un banco separado");

        var perfil = b.Configuraciones.Single();
        Exige(perfil.Referencias.Single().IdAnalisis == "AC-FALSO-PISO" && perfil.Referencias.Single().FuenteId == "CATALOGO-A" &&
            perfil.Filtros.Count == 1 && anterior.IdConfiguracionBibliotecaMYG == perfil.Id, "No se guarda la identidad de catálogo junto con los filtros.");
        var otroPresupuesto = Partida(); otroPresupuesto.Id = otroPresupuesto.IdInternoDelphin = "CU-PRESUPUESTO-NUEVO";
        otroPresupuesto.IdPropuesta = null; otroPresupuesto.Item = "09.07"; otroPresupuesto.Descripcion = "PARTIDA EN OTRO PROYECTO";
        string idLocal = otroPresupuesto.IdLocalMYG;
        Exige(MYGBibliotecaPartidas.AplicarUnica(b, otroPresupuesto), "No trae automáticamente una configuración única.");
        Exige(otroPresupuesto.Item == "09.07" && otroPresupuesto.Id == "CU-PRESUPUESTO-NUEVO" && otroPresupuesto.IdLocalMYG == idLocal &&
            otroPresupuesto.Filtros[0].Valor == "Falso piso e=0.10m" && otroPresupuesto.Plantilla == "PLANTILLA_SUELOS_M2",
            "Aplicar filtros cambia la partida o pierde configuración.");
        Exige(MYGBibliotecaPartidas.Estado(b, otroPresupuesto) == "Guardada", "Estado incorrecto tras aplicar.");
        pasa("Otra obra reutiliza plantilla y filtros por análisis interno conservando su fila, ítem e identidad local");

        Exige(MYGBibliotecaPartidas.Disponibles(b, Partida("AC-OTRO")).Count == 0 &&
            MYGBibliotecaPartidas.Disponibles(b, Partida(fuente: "CATALOGO-B")).Count == 0, "Coincidencia por código visible o por ID de otra base.");
        var unidadDiferente = Partida(); unidadDiferente.Unidad = "m³";
        Exige(MYGBibliotecaPartidas.Disponibles(b, unidadDiferente).Count == 0, "Se reutiliza una configuración con unidad distinta.");
        Rechaza<InvalidDataException>(() => MYGBibliotecaPartidas.Aplicar(unidadDiferente, perfil));
        pasa("Códigos visibles repetidos, IDs de otra base y unidades diferentes no generan coincidencias falsas");

        string sinCambios = Huella(ruta); otroPresupuesto.Filtros[0].Valor = "Ajuste exclusivo de esta obra";
        Exige(MYGBibliotecaPartidas.Estado(b, otroPresupuesto) == "Editada en proyecto" &&
            perfil.Filtros[0].Valor == "Falso piso e=0.10m" && Huella(ruta) == sinCambios, "La edición local cambia la biblioteca.");
        Exige(!MYGBibliotecaPartidas.AplicarUnica(b, otroPresupuesto) && !MYGBibliotecaPartidas.Aplicar(otroPresupuesto, perfil),
            "La aplicación predeterminada sobrescribe filtros locales.");
        pasa("Editar una obra conserva la biblioteca y la aplicación predeterminada respeta filas configuradas");

        var exteriores = Partida(valor: "Falso piso exterior");
        b = MYGBibliotecaPartidas.GuardarConfiguraciones(ruta, b, new[] { Guardar(exteriores, "Falso piso — exteriores") });
        var nueva = Partida();
        Exige(MYGBibliotecaPartidas.Disponibles(b, nueva).Count == 2 && !MYGBibliotecaPartidas.AplicarUnica(b, nueva) &&
            !MYGProyectoStorage.TieneBim(nueva), "Se escoge arbitrariamente una variante.");
        MYGBibliotecaPartidas.Aplicar(nueva, b.Configuraciones.Single(c => c.Nombre.Contains("exteriores")));
        Exige(nueva.Filtros[0].Valor == "Falso piso exterior", "La selección de variante no se aplica.");
        pasa("Varias configuraciones del mismo análisis exigen elegir y conservan filtros independientes");

        var unaObraAnterior = MYGProyectoStorage.Copia(otroPresupuesto);
        anterior.Filtros[0].Valor = "Interior actualizado";
        int cantidad = b.Configuraciones.Count;
        b = MYGBibliotecaPartidas.GuardarConfiguraciones(ruta, b, new[] { Guardar(anterior, "Falso piso — interiores", perfil.Id) });
        Exige(b.Configuraciones.Count == cantidad && b.Configuraciones.Single(c => c.Id == perfil.Id).Filtros[0].Valor == "Interior actualizado" &&
            b.Configuraciones.Single(c => c.Nombre.Contains("exteriores")).Filtros[0].Valor == "Falso piso exterior" &&
            unaObraAnterior.Filtros[0].Valor == "Ajuste exclusivo de esta obra", "Actualizar una variante cambia otra o una obra anterior.");
        pasa("Actualizar una configuración conserva su ID, otras variantes y las copias usadas por proyectos anteriores");

        string previo = Huella(ruta); string perfilAnterior = anterior.IdConfiguracionBibliotecaMYG;
        var invalida = Partida("AC-INCOMPLETO", valor: "Nuevo filtro"); invalida.Plantilla = null;
        var valida = Partida("AC-VALIDO", valor: "Filtro correcto");
        Rechaza<InvalidDataException>(() => MYGBibliotecaPartidas.GuardarConfiguraciones(ruta, b,
            new[] { Guardar(valida, "Válida"), Guardar(invalida, "Incompleta") }));
        Exige(Huella(ruta) == previo && valida.IdConfiguracionBibliotecaMYG == null &&
            anterior.IdConfiguracionBibliotecaMYG == perfilAnterior, "Un lote rechazado guarda parcialmente.");
        Rechaza<InvalidDataException>(() => MYGBibliotecaPartidas.GuardarConfiguraciones(ruta, b,
            new[] { Guardar(anterior, "Uno", perfil.Id), Guardar(anterior, "Dos", perfil.Id) }));
        Exige(Huella(ruta) == previo, "Actualizar dos veces el mismo perfil modifica el archivo.");
        pasa("Un lote inválido y dos actualizaciones del mismo perfil se rechazan sin escrituras parciales");

        var deOtraBase = Partida("AC-9988", "CATALOGO-B");
        Exige(MYGBibliotecaPartidas.Disponibles(b, deOtraBase).Count == 0, "La base nueva ya aparece vinculada.");
        var asociada = MYGProyectoStorage.Copia(b); asociada.FirmaLectura = b.FirmaLectura;
        MYGBibliotecaPartidas.Asociar(asociada.Configuraciones.Single(c => c.Id == perfil.Id), deOtraBase);
        MYGBibliotecaPartidas.Guardar(ruta, asociada); b = MYGProyectoStorage.LeerBiblioteca(ruta);
        Exige(MYGBibliotecaPartidas.Disponibles(b, deOtraBase).Single().Id == perfil.Id &&
            MYGBibliotecaPartidas.Disponibles(b, Partida()).Count == 2, "Recordar una equivalencia pierde la referencia anterior.");
        pasa("Asociación manual con otra base o análisis se guarda una vez conservando las referencias originales");

        var desactualizada = MYGProyectoStorage.LeerBiblioteca(ruta);
        var simultanea = MYGProyectoStorage.LeerBiblioteca(ruta);
        simultanea.Configuraciones[0].Nombre = "Nombre cambiado por otra ventana";
        MYGBibliotecaPartidas.Guardar(ruta, simultanea); previo = Huella(ruta);
        desactualizada.Configuraciones[0].Nombre = "Cambio sobre una lectura antigua";
        Rechaza<IOException>(() => MYGBibliotecaPartidas.Guardar(ruta, desactualizada));
        Exige(Huella(ruta) == previo, "Una lectura antigua sobrescribe los cambios nuevos.");
        b = MYGProyectoStorage.LeerBiblioteca(ruta);
        pasa("El guardado detecta una biblioteca modificada por otra ventana y evita perder configuraciones");

        var local = Partida(null, null, "Configuración sin Delphin");
        b = MYGBibliotecaPartidas.GuardarConfiguraciones(ruta, b, new[] { Guardar(local, "Partida libre") });
        var libre = Partida(null, null); var perfilLibre = b.Configuraciones.Single(c => c.Id == local.IdConfiguracionBibliotecaMYG);
        Exige(MYGBibliotecaPartidas.Disponibles(b, libre).Count == 0, "Una partida libre se relaciona por descripción.");
        MYGBibliotecaPartidas.Aplicar(libre, perfilLibre);
        Exige(MYGBibliotecaPartidas.Disponibles(b, libre).Single().Id == perfilLibre.Id, "Una elección manual libre no conserva su configuración.");
        pasa("Partidas creadas sin SQL pueden guardar configuraciones y reutilizarlas mediante elección manual");

        var nuevoDoc = MYGProyectoStorage.Nuevo("PROYECTO CON BIBLIOTECA"); nuevoDoc.Presupuestos[0].Items.Add(libre);
        string proyecto = Path.Combine(carpeta, "proyecto_con_biblioteca.myg.json");
        MYGProyectoStorage.Guardar(proyecto, nuevoDoc);
        var recuperada = MYGProyectoStorage.Leer(proyecto).Presupuestos[0].Items.Single();
        Exige(recuperada.IdConfiguracionBibliotecaMYG == perfilLibre.Id && recuperada.Filtros[0].Valor == "Configuración sin Delphin",
            "Reabrir un proyecto pierde la copia local o la referencia al perfil.");
        var reutilizado = MYGProyectoStorage.CopiarComoPlantilla(nuevoDoc.Presupuestos[0], "Otra obra");
        Exige(reutilizado.Items.Single().IdConfiguracionBibliotecaMYG == perfilLibre.Id &&
            MYGBibliotecaPartidas.Disponibles(b, reutilizado.Items.Single()).Single().Id == perfilLibre.Id, "Copiar un presupuesto pierde la configuración libre.");
        pasa("Reabrir y copiar un proyecto conserva filtros locales y la referencia a su configuración reutilizable");

        var propuesta = Partida(valor: "Configuración conciliada"); propuesta.IdConfiguracionBibliotecaMYG = perfil.Id;
        var oficial = new ItemPresupuestoDelphin { Id = "CU-99", IdAnalisisDelphin = "AC-FALSO-PISO", Unidad = "m²", Descripcion = "OFICIAL", Posicion = 1 };
        MYGProyectoStorage.Vincular(propuesta, oficial);
        var conectado = new MYGPresupuestoDocumento { Nombre = "CONECTADO", Conexion = new MYGConexionDelphin
            { FuenteId = "CATALOGO-A", RutaSQLite = "base.sqlite", ProyectoId = "PR2", PresupuestoId = "PP2" },
            Items = new List<ItemPresupuestoDelphin> { oficial } };
        var lectura = new ItemPresupuestoDelphin { Id = "CU-99", IdAnalisisDelphin = "AC-FALSO-PISO", Unidad = "m²", Descripcion = "ACTUALIZADA", Posicion = 1 };
        MYGProyectoStorage.ActualizarDesdeDelphin(conectado, new List<ItemPresupuestoDelphin> { lectura });
        Exige(conectado.Items.Single().IdConfiguracionBibliotecaMYG == perfil.Id &&
            conectado.Items.Single().Filtros[0].Valor == "Configuración conciliada", "Conciliar o actualizar pierde el perfil.");
        pasa("Reconciliar y actualizar desde Delphin conserva la referencia a biblioteca junto con los filtros");

        var parcial = Partida("AC-LEGACY"); parcial.Plantilla = "PLANTILLA_SUELOS_M2";
        parcial.Parametro = "Descripción"; parcial.Regla = "es igual a"; parcial.Valor = "Filtro antiguo";
        parcial.Filtros.Add(new FiltroPlanificacion());
        Exige(MYGBibliotecaPartidas.FiltrosGuardables(parcial).Single().Valor == "Filtro antiguo", "No recupera los filtros antiguos con relleno vacío.");
        var nula = MYGProyectoStorage.Copia(b); nula.Configuraciones[0].Filtros = new List<FiltroPlanificacion>
            { new FiltroPlanificacion { Parametro = "Descripción", Valor = "Sin regla" } };
        Rechaza<InvalidDataException>(() => MYGBibliotecaPartidas.Validar(nula));
        var demasiados = MYGProyectoStorage.Copia(b); demasiados.Configuraciones[0].Filtros = Enumerable.Range(1, 9)
            .Select(n => new FiltroPlanificacion { Parametro = "Descripción", Regla = "es igual a", Valor = n.ToString() }).ToList();
        Rechaza<InvalidDataException>(() => MYGBibliotecaPartidas.Validar(demasiados));
        var futura = MYGProyectoStorage.Copia(b); futura.Version = 99;
        Rechaza<InvalidDataException>(() => MYGBibliotecaPartidas.Validar(futura));
        pasa("Recupera filtros antiguos y rechaza reglas incompletas, más de ocho filtros y versiones futuras");

        MYGIndiceLocal.RecordarBiblioteca(ruta);
        Exige(MYGIndiceLocal.RutaBiblioteca() == Path.GetFullPath(ruta) && MYGIndiceLocal.Recientes().Count > 0,
            "Recordar la biblioteca pierde las asociaciones de proyectos existentes.");
        pasa("El add-in recuerda una única biblioteca sin perder el índice previo de proyectos y bases");
    }
}
