using System;
using System.IO;
using System.Text.Json;
using MYG_2027;

internal static class ArrastreHojaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var serie = Nueva();
        serie.Poner("A3", "1"); serie.Poner("A4", "3");
        MYGEdicionHoja.RellenarRango(serie, "A3:A4", "A3:A7");
        Exige(serie.Celdas["A3"].Contenido == "1" && serie.Celdas["A4"].Contenido == "3" &&
            new MYGHojaCalculo(serie).Numero("A5") == 5m && new MYGHojaCalculo(serie).Numero("A7") == 9m,
            "El tirador debe extender la serie numérica sin modificar su origen.");
        serie.Poner("J5", "10"); serie.Poner("K5", "20");
        MYGEdicionHoja.RellenarRango(serie, "J5:K5", "J5:L5");
        Exige(new MYGHojaCalculo(serie).Numero("L5") == 30m, "El relleno horizontal debe extender la serie por columnas.");
        pasa("Arrastre de relleno extiende series numéricas por filas y columnas conservando el origen");

        serie.Poner("J1", "10"); serie.Poner("B3", "=A3+$J$1");
        serie.Celdas["B3"].ColorFondo = "C6EFCE";
        MYGEdicionHoja.RellenarRango(serie, "B3", "B3:B7");
        Exige(serie.Celdas["B7"].Contenido == "=A7+$J$1" &&
            serie.Celdas["B7"].ColorFondo == "C6EFCE" && new MYGHojaCalculo(serie).Numero("B7") == 19m,
            "El relleno debe trasladar referencias relativas y conservar referencias absolutas y formato.");
        pasa("Relleno de fórmulas conserva valores calculados, referencias absolutas y formato de las celdas");

        var validada = Nueva(); validada.Poner("A2", "4"); validada.Poner("A3", "=A2+1");
        var reglaDestino = MYGEdicionHoja.Celda(validada, "A5");
        reglaDestino.TipoValidacion = "Numero"; reglaDestino.Maximo = 6;
        RechazaSinCambios(validada, () => MYGEdicionHoja.RellenarRango(validada, "A3", "A3:A5"));
        reglaDestino.Maximo = null; reglaDestino.Minimo = 6;
        MYGEdicionHoja.RellenarRango(validada, "A3", "A3:A5");
        Exige(new MYGHojaCalculo(validada).Numero("A5") == 7m,
            "La regla del destino debe evaluar la hoja final, incluyendo las fórmulas anteriores del mismo relleno.");
        var moveValidado = Nueva(); moveValidado.Poner("A3", "2"); moveValidado.Poner("B3", "=A3*2");
        var reglaMover = MYGEdicionHoja.Celda(moveValidado, "E5"); reglaMover.TipoValidacion = "Numero"; reglaMover.Minimo = 4;
        MYGEdicionHoja.MoverRango(moveValidado, "A3:B3", "D5");
        Exige(new MYGHojaCalculo(moveValidado).Numero("E5") == 4m,
            "Validar un movimiento debe usar las referencias ya reubicadas y no las celdas vacías de la hoja original.");
        pasa("Validaciones de destino aceptan o rechazan fórmulas usando los resultados finales de todo el arrastre");

        var mover = Nueva(); mover.CeldaTotal = "B3";
        mover.Poner("A3", "2"); mover.Poner("A4", "4"); mover.Poner("J1", "10");
        mover.Poner("B3", "=A3*2+$J$1"); mover.Celdas["A3"].ColorTexto = "006100";
        mover.Poner("H10", "=$A$3+A4+SUM(A3:B4)");
        decimal resultado = new MYGHojaCalculo(mover).Numero("H10");
        MYGEdicionHoja.MoverRango(mover, "A3:B4", "D5");
        Exige(!mover.Celdas.ContainsKey("A3") && !mover.Celdas.ContainsKey("B3") &&
            mover.Celdas["D5"].Contenido == "2" && mover.Celdas["D5"].ColorTexto == "006100" &&
            mover.Celdas["E5"].Contenido == "=D5*2+$J$1" && mover.CeldaTotal == "E5" &&
            mover.Celdas["H10"].Contenido == "=$D$5+D6+SUM(D5:E6)" &&
            new MYGHojaCalculo(mover).Numero("H10") == resultado,
            "Mover celdas debe conservar su contenido, formato y resultados y actualizar las referencias al bloque y el total.");
        pasa("Mover un bloque conserva sus datos y recalcula referencias internas, externas y la celda total");

        var solapado = Nueva(); solapado.Poner("A3", "1"); solapado.Poner("A4", "2");
        MYGEdicionHoja.MoverRango(solapado, "A3:A4", "A4");
        Exige(!solapado.Celdas.ContainsKey("A3") && solapado.Celdas["A4"].Contenido == "1" &&
            solapado.Celdas["A5"].Contenido == "2", "Un movimiento solapado no debe borrar los valores desplazados.");
        pasa("Mover un rango sobre parte de su origen preserva todas las celdas desplazadas");

        var ocupado = Nueva(); ocupado.Poner("A3", "original"); ocupado.Poner("B3", "existente");
        RechazaSinCambios(ocupado, () => MYGEdicionHoja.MoverRango(ocupado, "A3", "B3"));
        RechazaSinCambios(ocupado, () => MYGEdicionHoja.RellenarRango(ocupado, "A3", "A3:B3"));
        RechazaSinCambios(ocupado, () => MYGEdicionHoja.MoverRango(ocupado, "A3:B3", "L30"));
        ocupado.RangosCombinados.Add("A3:A4");
        RechazaSinCambios(ocupado, () => MYGEdicionHoja.MoverRango(ocupado, "A3:A4", "D5"));
        RechazaSinCambios(ocupado, () => MYGEdicionHoja.RellenarRango(ocupado, "A3:A4", "A3:A7"));
        ocupado.RangosCombinados.Clear(); ocupado.FilasOcultas.Add(4);
        RechazaSinCambios(ocupado, () => MYGEdicionHoja.MoverRango(ocupado, "A3:A4", "D5"));
        RechazaSinCambios(ocupado, () => MYGEdicionHoja.RellenarRango(ocupado, "A3", "A3:A7"));
        var dependencia = Nueva(); dependencia.Poner("A3", "2"); dependencia.Poner("H10", "=SUM(A3:A5)");
        RechazaSinCambios(dependencia, () => MYGEdicionHoja.MoverRango(dependencia, "A3", "D5"));
        pasa("Arrastres inválidos rechazan destinos ocupados, límites, combinaciones y filas ocultas sin cambios parciales");

        string ruta = Path.Combine(carpeta, "Arrastre de metrados.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { mover });
        var reabierta = MYGExcelPresupuestos.Importar(ruta, mover.Nombre, mover.CeldaTotal);
        Exige(reabierta.Celdas["E5"].Contenido == mover.Celdas["E5"].Contenido &&
            new MYGHojaCalculo(reabierta).Numero("H10") == resultado &&
            new MYGHojaCalculo(reabierta).Numero(reabierta.CeldaTotal) == 14m,
            "El intercambio XLSX debe conservar las fórmulas y los resultados después del arrastre.");
        pasa("Guardar y reabrir XLSX conserva fórmulas, total y referencias después de mover celdas");
    }

    private static MYGHojaMetrado Nueva() => new() { Filas = 30, Columnas = 12, FilasInmovilizadas = 0, CeldaTotal = "L30" };

    private static void RechazaSinCambios(MYGHojaMetrado hoja, Action accion)
    {
        string firma = JsonSerializer.Serialize(hoja);
        bool rechazado = false;
        try { accion(); }
        catch (Exception e) when (e is InvalidDataException or InvalidOperationException or ArgumentException) { rechazado = true; }
        Exige(rechazado && JsonSerializer.Serialize(hoja) == firma, "El rechazo del arrastre debe conservar íntegra la hoja.");
    }
}
