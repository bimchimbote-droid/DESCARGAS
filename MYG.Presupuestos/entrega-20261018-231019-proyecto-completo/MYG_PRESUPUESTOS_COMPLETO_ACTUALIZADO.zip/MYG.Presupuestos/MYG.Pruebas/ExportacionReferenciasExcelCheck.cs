using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ExportacionReferenciasExcelCheck
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static ItemPresupuestoDelphin Partida(string item)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
            Item = item, Descripcion = "Partida " + item, TipoPropuesta = "PARTIDA", Unidad = "und" };
    }

    private static (MYGPresupuestoDocumento P, ItemPresupuestoDelphin A, ItemPresupuestoDelphin B,
        ItemPresupuestoDelphin C) Nuevo()
    {
        var p = new MYGPresupuestoDocumento { Item = "01", Nombre = "Presupuesto" };
        var a = Partida("01.01"); var b = Partida("01.02"); var c = Partida("01.03");
        p.Items.AddRange(new[] { a, b, c });
        MYGReferenciasMetrado.Vincular(new[] { p });
        return (p, a, b, c);
    }

    private static XDocument Xml(string ruta, string parte)
    {
        using var zip = ZipFile.OpenRead(ruta);
        using var entrada = zip.GetEntry(parte).Open();
        return XDocument.Load(entrada);
    }

    private static XElement Celda(string ruta, int hoja, string direccion) =>
        Xml(ruta, "xl/worksheets/sheet" + hoja + ".xml").Descendants(S + "c")
            .Single(c => (string)c.Attribute("r") == direccion);
    private static string Referencia(string nombre, string direccion) => "'" + nombre.Replace("'", "''") + "'!" + direccion;

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        VerificarConversionCompleta(carpeta, pasa);
        VerificarTiposYLiterales(carpeta, pasa);
        VerificarAnclas(carpeta, pasa);
        VerificarHojaAislada(carpeta, pasa);
        VerificarDependenciasProyecto(carpeta, pasa);
    }

    private static void VerificarConversionCompleta(string carpeta, Action<string> pasa)
    {
        var (p, a, b, c) = Nuevo();
        b.Costos.Hoja.Poner("B3", "7"); c.Costos.Hoja.Poner("B3", "2");
        a.Costos.Hoja.Poner("C3", "3"); a.Costos.Hoja.Poner("D3", "4");
        string rb = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3");
        string rc = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, c, "B3");
        a.Costos.Hoja.Poner("B3", "=" + rb + "*2+SUMA(C3:D3)+" + rc);
        a.Costos.Hoja.Poner("E3", "=" + rb + "+1,5");
        string original = JsonSerializer.Serialize(p);
        var hojas = new[] { a.Costos.Hoja, b.Costos.Hoja, c.Costos.Hoja }.Select(MYGProyectoStorage.Copia).ToArray();
        foreach (var h in hojas) h.Nombre = "  O'Brien/[Metrado]" + new string('x', 45);
        string ruta = Path.Combine(carpeta, "Referencias Excel completas.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        string[] nombres = MYGExcelPresupuestos.Hojas(ruta);
        Exige(nombres.Distinct(StringComparer.OrdinalIgnoreCase).Count() == 3 && nombres.All(n => n.Length <= 31 && !n.Contains('[') && !n.Contains('/')),
            "Los nombres saneados y truncados deben ser únicos.");
        var celda = Celda(ruta, 1, "B3");
        string esperada = Referencia(nombres[1], "B3") + "*2+SUM(C3:D3)+" + Referencia(nombres[2], "B3");
        Exige((string)celda.Element(S + "f") == esperada && (string)celda.Element(S + "v") == "23",
            "La fórmula completa debe señalar los nombres finales del libro y conservar aritmética, rangos locales y valor calculado.");
        Exige((string)Celda(ruta, 1, "E3").Element(S + "f") == Referencia(nombres[1], "B3") + "+1.5",
            "Al eliminar METRADO debe conservarse la interpretación de coma decimal.");
        hojas[1].Poner("B3", "9");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        Exige((string)Celda(ruta, 1, "B3").Element(S + "v") == "27",
            "La caché exportada debe calcular la copia del origen incluida en el libro y no el origen original.");
        Exige(JsonSerializer.Serialize(p) == original,
            "Convertir referencias Excel no debe modificar fórmulas, alias, anclas o nombres del proyecto original.");
        pasa("XLSX convierte METRADO a referencias de hojas finales únicas, conserva cálculo local/decimales y deja intacto el proyecto");
    }

    private static void VerificarTiposYLiterales(string carpeta, Action<string> pasa)
    {
        var (p, a, b, _) = Nuevo();
        b.Costos.Hoja.Nombre = "Origen";
        b.Costos.Hoja.Poner("A3", "ZAPATA"); b.Costos.Hoja.Poner("B3", "=VERDADERO");
        a.Costos.Hoja.Poner("A3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "A3") + "&\" extra\"");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3"));
        const string literal = "=\"METRADO(\"\"no registrado\"\";\"\"B3\"\")\"";
        a.Costos.Hoja.Poner("C3", literal);
        a.Costos.Hoja.Poner("D3", "METRADO(\"no registrado\";\"B3\")");
        string ruta = Path.Combine(carpeta, "Referencias Excel texto y logica.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { a.Costos.Hoja, b.Costos.Hoja });
        var texto = Celda(ruta, 1, "A3"); var logico = Celda(ruta, 1, "B3");
        Exige((string)texto.Element(S + "f") == "'Origen'!A3&\" extra\"" &&
            (string)texto.Attribute("t") == "str" && (string)texto.Element(S + "v") == "ZAPATA extra",
            "Una referencia textual debe conservar fórmula y resultado de texto.");
        Exige((string)logico.Element(S + "f") == "'Origen'!B3" &&
            (string)logico.Attribute("t") == "b" && (string)logico.Element(S + "v") == "1",
            "Una referencia lógica debe conservar fórmula y resultado booleano.");
        Exige((string)Celda(ruta, 1, "C3").Element(S + "f") == literal[1..] &&
            (string)Celda(ruta, 1, "D3").Attribute("t") == "inlineStr",
            "METRADO dentro de literales o de celdas de texto nunca debe convertirse en una referencia.");
        pasa("XLSX conserva vínculos de texto/lógicos y respeta METRADO escrito dentro de literales o texto ordinario");
    }

    private static void VerificarAnclas(string carpeta, Action<string> pasa)
    {
        var (p, a, b, _) = Nuevo();
        b.Costos.Hoja.Nombre = "Origen movido"; b.Costos.Hoja.Poner("B3", "8");
        string referencia = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3");
        a.Costos.Hoja.Poner("B3", "=SI.ERROR(" + referencia + ";12)");
        // La copia destino conserva B3; la identidad del ancla debe resolver la
        // nueva dirección B4 aunque esa copia no se haya sincronizado todavía.
        var destino = MYGProyectoStorage.Copia(a.Costos.Hoja);
        MYGEdicionHoja.InsertarFilas(b.Costos.Hoja, 3, 1);
        string ruta = Path.Combine(carpeta, "Referencias Excel ancla movida.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { destino, MYGProyectoStorage.Copia(b.Costos.Hoja) });
        Exige((string)Celda(ruta, 1, "B3").Element(S + "f") == "IFERROR('Origen movido'!B4,12)" &&
            (string)Celda(ruta, 1, "B3").Element(S + "v") == "8",
            "Exportar debe resolver la dirección actual por ancla, incluso para una copia de destino anterior.");
        MYGEdicionHoja.EliminarFilas(b.Costos.Hoja, 4, 1);
        ruta = Path.Combine(carpeta, "Referencias Excel ancla eliminada.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { destino, MYGProyectoStorage.Copia(b.Costos.Hoja) });
        Exige((string)Celda(ruta, 1, "B3").Element(S + "f") == "IFERROR(#REF!,12)" &&
            (string)Celda(ruta, 1, "B3").Element(S + "v") == "12",
            "Un ancla eliminada debe producir #REF! en la fórmula normal, conservando la rama SI.ERROR.");
        pasa("Exportar resuelve anclas movidas y convierte anclas eliminadas a #REF! sin perder las ramas SI.ERROR");
    }

    private static void VerificarHojaAislada(string carpeta, Action<string> pasa)
    {
        var (p, a, b, _) = Nuevo();
        b.Costos.Hoja.Poner("B3", "5");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3") + "*2");
        a.Costos.Hoja.Poner("C3", "=METRADO(\"no registrado\";\"B3\")");
        a.Costos.Hoja.Poner("C4", "=METRADO(\"no registrado\";\"NO ES CELDA\")");
        a.Costos.Hoja.Poner("D3", "=SUMA(1;2)");
        string ruta = Path.Combine(carpeta, "Referencias Excel hoja aislada.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { a.Costos.Hoja });
        Exige(Celda(ruta, 1, "B3").Element(S + "f") == null && (string)Celda(ruta, 1, "B3").Element(S + "v") == "10",
            "Una hoja aislada debe conservar el valor cuando su origen queda fuera del libro.");
        Exige(Celda(ruta, 1, "C3").Element(S + "f") == null && (string)Celda(ruta, 1, "C3").Attribute("t") == "e" &&
            (string)Celda(ruta, 1, "C3").Element(S + "v") == "#REF!",
            "Una referencia desconocida debe conservar #REF! y nunca convertirse en cero.");
        Exige(Celda(ruta, 1, "C4").Element(S + "f") == null && (string)Celda(ruta, 1, "C4").Attribute("t") == "e",
            "Una dirección manual inválida debe conservar su error sin impedir exportar el resto del libro.");
        Exige((string)Celda(ruta, 1, "D3").Element(S + "f") == "SUM(1,2)",
            "El fallback aislado no debe borrar las fórmulas locales.");
        pasa("Exportar una hoja aislada conserva valores o #REF! si no incluye el origen y mantiene las fórmulas locales");
    }

    private static void VerificarDependenciasProyecto(string carpeta, Action<string> pasa)
    {
        var (p, a, _, _) = Nuevo();
        var otro = new MYGPresupuestoDocumento { Item = "02", Nombre = "Otro presupuesto" };
        var b = Partida("01.01"); var c = Partida("01.02"); otro.Items.AddRange(new[] { b, c });
        MYGReferenciasMetrado.Vincular(new[] { p, otro });
        a.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        b.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        c.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        c.Costos.Hoja.Poner("B3", "7");
        b.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(b.Costos.Hoja, otro, c, "B3") + "*2");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, otro, b, "B3") + "+1");
        var hojas = MYGExcelPresupuestos.CrearHojasMetradoParaExportar(p);
        var todas = MYGExcelPresupuestos.CrearHojasMetradoParaExportar(new[] { p, otro });
        Exige(hojas.Count == 3 && todas.Count == 3 && hojas.All(h =>
            !ReferenceEquals(h, a.Costos.Hoja) && !ReferenceEquals(h, b.Costos.Hoja) && !ReferenceEquals(h, c.Costos.Hoja)),
            "La exportación completa debe copiar el cierre transitivo entre presupuestos sin duplicar partidas ni exigir fuente Excel a sus orígenes.");
        string ruta = Path.Combine(carpeta, "Referencias Excel otros presupuestos.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        string[] nombres = MYGExcelPresupuestos.Hojas(ruta);
        Exige((string)Celda(ruta, 1, "B3").Element(S + "f") == Referencia(nombres[1], "B3") + "+1" &&
            (string)Celda(ruta, 2, "B3").Element(S + "f") == Referencia(nombres[2], "B3") + "*2" &&
            (string)Celda(ruta, 1, "B3").Element(S + "v") == "15",
            "La cadena exportada entre presupuestos debe mantener fórmulas de todas las dependencias y resultados correctos.");
        var desconectados = JsonSerializer.Deserialize<MYGPresupuestoDocumento[]>(JsonSerializer.Serialize(new[] { p, otro }));
        string antes = JsonSerializer.Serialize(desconectados);
        var sinContexto = MYGExcelPresupuestos.CrearHojasMetradoParaExportar(desconectados);
        MYGExcelPresupuestos.Guardar(ruta, sinContexto);
        Exige((string)Celda(ruta, 1, "B3").Element(S + "v") == "15" && JsonSerializer.Serialize(desconectados) == antes,
            "Exportar copias sin vincular previamente el proyecto debe crear una sesión privada correcta sin mutar los originales.");
        // Cierre circular: todos los orígenes deben aparecer una vez, y el error
        // se conserva en caché sin impedir construir un libro recalculable.
        c.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(c.Costos.Hoja, p, a, "B3"));
        Exige(MYGExcelPresupuestos.CrearHojasMetradoParaExportar(new[] { p, otro }).Count == 3,
            "El cierre de dependencias debe terminar cuando contiene un ciclo.");
        pasa("Exportación completa añade orígenes transitivos de otros presupuestos y fuentes inactivas, deduplica partidas y termina ante ciclos");
    }
}
