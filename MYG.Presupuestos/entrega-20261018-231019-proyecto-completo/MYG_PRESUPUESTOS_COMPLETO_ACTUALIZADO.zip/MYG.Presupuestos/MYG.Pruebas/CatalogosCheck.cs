using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

// Pruebas reales de la nueva funcionalidad; ejecutar desde MYG.Pruebas.
// Esta entrega no declara estas pruebas ejecutadas si falta el SDK de .NET.
internal static class CatalogosCheck
{
    private static void Exige(bool ok, string texto) { if (!ok) throw new Exception(texto); }
    private static void Rechaza(Action a)
    { bool rechazado = false; try { a(); } catch (InvalidOperationException) { rechazado = true; } catch (InvalidDataException) { rechazado = true; } Exige(rechazado, "Se aceptó una operación inválida."); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static long Cuenta(string ruta, string tabla)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT COUNT(*) FROM " + tabla;
        return Convert.ToInt64(cmd.ExecuteScalar());
    }
    private static ItemPresupuestoDelphin Nodo(string nombre, bool titulo = false, string padre = null)
    {
        string id = MYGProyectoStorage.NuevoId(); return new ItemPresupuestoDelphin
        { Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = nombre, Unidad = titulo ? "" : "m²",
            ParentId = padre, TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA" };
    }
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Catalogos ; proyecto.myg.sqlite");
        var d = MYGProyectoStorage.Nuevo("OBRA CON CATÁLOGOS"); var p = d.Presupuestos[0];
        MYGProyectoStorage.Guardar(ruta, d);
        Exige(MYGProyectoStorage.Leer(ruta).Presupuestos.Single().Items.Count == 0, "La hoja nueva no está vacía.");
        Exige(Cuenta(ruta, "presupuesto") == 1 && Cuenta(ruta, "catalogo_partida") == 0 && Cuenta(ruta, "catalogo_insumo") == 0,
            "La hoja nueva creó entradas de catálogo sin autorización del usuario.");
        pasa("Nueva hoja crea SQLite con presupuesto vacío y catálogos vacíos");

        var titulo = Nodo("ESTRUCTURAS", true);
        titulo.ParentId = ""; // Compatibilidad con raíces de importadores/JSON anteriores.
        var sub = Nodo("SUBANÁLISIS", padre: titulo.Id); sub.Costos.PrecioDirecto = 7.12m;
        var principal = Nodo("FALSO PISO de prueba", padre: titulo.Id);
        principal.Costos.Cantidad = 25m; principal.Costos.RendimientoDiario = 8m;
        principal.Costos.EspecificacionTexto = "Especificación conservada";
        principal.Plantilla = "METRADO DE PISOS";
        principal.Filtros.Add(new FiltroPlanificacion { Parametro = "GEN_Nivel", Regla = "igual", Valor = "N01" });
        var insumo = new MYGInsumo { Codigo = "MAT-01", Descripcion = "Material de prueba", Unidad = "kg", Precio = 12.345678m };
        p.Costos.DecimalesPrecio = 6; p.Costos.DecimalesCantidad = 8; p.Costos.Insumos.Add(insumo);
        principal.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 0.12345678m });
        principal.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = 2m });
        p.Items.AddRange(new[] { titulo, principal, sub }); MYGProyectoStorage.Renumerar(p);
        MYGProyectoStorage.Guardar(ruta, d);
        Exige(titulo.ParentId == null, "No se normalizó el padre vacío de la raíz antes de escribir sus relaciones SQL.");
        Exige(Cuenta(ruta, "partida_presupuesto") == 3 && Cuenta(ruta, "insumo_presupuesto") == 1 && Cuenta(ruta, "recurso_presupuesto") == 2,
            "El presupuesto y su ACU no se guardaron en las tablas SQL.");
        Exige(MYGCatalogos.Listar(ruta, true).Count == 0 && MYGCatalogos.Listar(ruta, false).Count == 0,
            "Guardar proyecto agregó entradas al catálogo.");
        pasa("Partidas de texto, insumos y ACU se guardan en el presupuesto sin registrarse en los catálogos");

        var entrada = MYGCatalogos.GuardarPartida(ruta, p, principal, "P-000001", principal.Descripcion, principal.Unidad);
        principal.Costos.CatalogoMYGId = entrada.Id; principal.Costos.CatalogoMYGRuta = ruta;
        Exige(MYGCatalogos.Listar(ruta, true).Count == 1 && MYGCatalogos.Listar(ruta, false).Count == 0,
            "Guardar una partida alteró el catálogo independiente de insumos.");
        Exige(Cuenta(ruta, "catalogo_partida_nodo") == 2 && Cuenta(ruta, "catalogo_partida_insumo") == 1 && Cuenta(ruta, "catalogo_partida_recurso") == 2,
            "La plantilla no conserva las subpartidas y los recursos.");
        var plantilla = MYGCatalogos.LeerPartida(ruta, entrada.Id);
        Exige(plantilla.Partidas.All(x => x.Costos.Cantidad == 0 && x.Costos.Metrados.Count == 0 && x.Costos.MetradosBIM.Count == 0 && x.Filtros.Count == 0),
            "Una plantilla de catálogo arrastró metrados o filtros de la obra.");
        pasa("Guardar partida es explícito y conserva ACU, subpartidas y especificación como plantilla independiente");

        var entradaInsumo = MYGCatalogos.GuardarInsumo(ruta, insumo);
        Exige(MYGCatalogos.LeerInsumo(ruta, entradaInsumo.Id).Precio == 12.345678m, "Se perdió precisión decimal.");
        principal.Descripcion = "PARTIDA MODIFICADA EN LA OBRA"; insumo.Precio = 999m; MYGProyectoStorage.Guardar(ruta, d);
        Exige(MYGCatalogos.Listar(ruta, true).Single().Descripcion == entrada.Descripcion &&
            MYGCatalogos.LeerInsumo(ruta, entradaInsumo.Id).Precio == 12.345678m,
            "Guardar proyecto actualizó automáticamente los catálogos.");
        Exige(MYGProyectoStorage.Leer(ruta).Presupuestos[0].Items.Single(x => x.Id == principal.Id).Filtros[0].Valor == "N01",
            "El proyecto SQLite perdió sus filtros BIM.");
        pasa("Reabrir conserva datos BIM y editar el presupuesto no modifica las entradas del catálogo");

        var destino = MYGProyectoStorage.Nuevo("OTRA OBRA").Presupuestos[0]; destino.Costos.DecimalesPrecio = 6; destino.Costos.DecimalesCantidad = 8;
        var a = MYGCatalogos.InsertarPartida(destino, ruta, entrada, null);
        var b = MYGCatalogos.InsertarPartida(destino, ruta, entrada, null);
        Exige(a.Id != b.Id && destino.Items.Select(x => x.IdLocalMYG).Distinct().Count() == 4 && destino.Costos.Insumos.Select(x => x.Id).Distinct().Count() == 2,
            "Usar dos veces una plantilla mezcló identidades.");
        Exige(MYGMotorPresupuestos.Analizar(destino, a).PrecioUnitario == entrada.Precio && a.Costos.Cantidad == 0 &&
            a.Costos.EspecificacionTexto == "Especificación conservada", "El ACU importado no coincide con su plantilla.");
        destino.Costos.Insumos[0].Precio = 77m;
        Exige(MYGMotorPresupuestos.Analizar(destino, b).PrecioUnitario == entrada.Precio,
            "Editar un uso de la plantilla cambió el otro.");
        pasa("Reutilización entre proyectos remapea recursos y subpartidas, con copias independientes y metrado cero");

        var siguiente = MYGCatalogos.GuardarPartida(ruta, p, principal, entrada.Codigo, principal.Descripcion, principal.Unidad, entrada.Id, entrada.Revision);
        string antes = Huella(ruta);
        Rechaza(() => MYGCatalogos.GuardarPartida(ruta, p, principal, entrada.Codigo, principal.Descripcion, principal.Unidad, entrada.Id, entrada.Revision));
        Rechaza(() => MYGCatalogos.GuardarPartida(ruta, p, principal, entrada.Codigo.ToLowerInvariant(), "DUPLICADA", principal.Unidad));
        Exige(Huella(ruta) == antes && MYGCatalogos.Listar(ruta, true).Single().Revision == siguiente.Revision,
            "Un conflicto o duplicado modificó el catálogo.");
        pasa("Códigos duplicados y revisiones antiguas se rechazan sin alterar datos");

        string copiaRuta = Path.Combine(carpeta, "Copia completa.myg.sqlite"); MYGProyectoStorage.Guardar(copiaRuta, MYGProyectoStorage.Copia(d), ruta);
        Exige(MYGCatalogos.Listar(copiaRuta, true).Single().Id == entrada.Id &&
            MYGCatalogos.Listar(copiaRuta, false).Single().Id == entradaInsumo.Id && Cuenta(copiaRuta, "catalogo_partida_recurso") == 2,
            "Guardar como perdió el catálogo.");
        var otro = MYGProyectoStorage.Nuevo("OTRO PROYECTO");
        MYGProyectoStorage.Guardar(ruta, otro);
        Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 2 && MYGBaseDatos.LeerProyecto(ruta, d.Id).Nombre == d.Nombre,
            "Guardar otro proyecto eliminó el proyecto anterior.");
        MYGCatalogos.Eliminar(ruta, true, siguiente);
        Exige(MYGCatalogos.Listar(ruta, true).Count == 0 && MYGMotorPresupuestos.Analizar(destino, b).PrecioUnitario == entrada.Precio,
            "Eliminar una plantilla dañó sus copias en los presupuestos.");
        pasa("Guardar como copia catálogos y eliminar del catálogo conserva las copias del presupuesto");

        string externa = Path.Combine(carpeta, "Delphin protegida.sqlite");
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = externa, Pooling = false }.ToString()))
        { c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = "CREATE TABLE analisis_costo(id_analisiscosto TEXT,descripcion_costo TEXT)"; cmd.ExecuteNonQuery(); }
        string huellaExterna = Huella(externa);
        Rechaza(() => MYGProyectoStorage.Guardar(externa, d)); Rechaza(() => MYGCatalogos.Listar(externa, true));
        Exige(Huella(externa) == huellaExterna, "Se escribió en una base externa de Delphin.");
        pasa("Las operaciones MYG rechazan bases externas sin modificar la base Delphin");

        RegistroAutomatico(carpeta, pasa);
        CostosMultiples(carpeta, pasa);
    }

    private static string Datos(object valor) => JsonSerializer.Serialize(valor, MYGProyectoStorage.Opciones);

    private static void CostosMultiples(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Costos múltiples.sqlite");
        var documento = MYGProyectoStorage.Nuevo("OBRA COSTOS MÚLTIPLES");
        var p = documento.Presupuestos.Single();
        var titulo = Nodo("ESTRUCTURAS", true);
        var principal = Nodo("CONCRETO", padre: titulo.Id);
        var auxiliar = Nodo("ACU AUXILIAR", padre: titulo.Id);
        var directa = Nodo("PARTIDA CON PRECIO DIRECTO", padre: titulo.Id);
        p.Items.AddRange(new[] { titulo, principal, auxiliar, directa });
        p.Costos.DecimalesPrecio = 6; p.Costos.DecimalesCantidad = 8;
        principal.Costos.RendimientoDiario = 3.5m; principal.Costos.JornadaHoras = 6.5m;
        principal.Costos.Cantidad = 40m; principal.IdInternoDelphin = "COSTO-ORIGINAL";
        principal.Costos.EspecificacionTexto = "Especificación del ACU múltiple";
        principal.Costos.EspecificacionRtf = @"{\rtf1 Especificación del ACU múltiple}";
        principal.Costos.CatalogoMYGId = "REFERENCIA-ANTERIOR";
        principal.Costos.CatalogoMYGRuta = "catalogo_anterior.sqlite";
        principal.Filtros.Add(new FiltroPlanificacion { Parametro = "Nivel", Regla = "igual", Valor = "01" });
        principal.Costos.Responsables.Add(new MYGResponsablePresupuesto { Nombre = "Responsable ACU", Cargo = "Especialista" });
        directa.Costos.PrecioDirecto = 12.345678m; auxiliar.Costos.PrecioDirecto = 2.125m;
        foreach (var grupo in new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos })
        {
            var i = new MYGInsumo { Codigo = grupo.ToString(), Descripcion = "INSUMO " + grupo, Unidad = "und", Grupo = grupo,
                Precio = 2.345678m, Marca = "MARCA", CodigoAlterno = "ALT-" + grupo, Proveedor = "PROVEEDOR",
                CatalogoMYGId = "REF-" + grupo, CatalogoMYGRuta = "catalogo_anterior.sqlite" };
            p.Costos.Insumos.Add(i);
            principal.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = i.Id, Grupo = grupo, Cantidad = 0.12345678m,
                NumeroRecursos = 2m, DesperdicioPorcentaje = 1.5m });
        }
        principal.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = auxiliar.IdLocalMYG, Cantidad = 2m });
        MYGProyectoStorage.Guardar(ruta, documento);
        var reservada = MYGCatalogos.GuardarPartida(ruta, p, directa, "p-000002", directa.Descripcion, directa.Unidad);
        long analisisIniciales = Cuenta(ruta, "analisis_costo"), composicionesIniciales = Cuenta(ruta, "composicion_analisiscosto");
        string reservadaAntes = Datos(MYGCatalogos.LeerPartida(ruta, reservada.Id));
        string proyectoGuardado = Datos(MYGBaseDatos.LeerProyecto(ruta, documento.Id));
        // La validación normaliza estos campos en su copia; la API de guardar
        // el catálogo debe conservar incluso los datos aún no normalizados de la UI.
        p.IdPresupuestoRevit = null; titulo.ParentId = "";
        string original = Datos(p);
        var referenciaItems = p.Items; var referenciaCostos = principal.Costos; var referenciaInsumo = p.Costos.Insumos[0];
        var entradas = MYGCatalogos.GuardarPartidas(ruta, p,
            new[] { directa.IdLocalMYG.ToLowerInvariant(), principal.IdLocalMYG, auxiliar.IdLocalMYG }, "  ESTRUCTURAS  ");
        Exige(entradas.Select(x => x.Codigo).SequenceEqual(new[] { "P-000001", "P-000003", "P-000004" }) &&
            entradas.Select(x => x.Descripcion).SequenceEqual(new[] { directa.Descripcion, principal.Descripcion, auxiliar.Descripcion }) &&
            entradas.All(x => x.Revision == 1 && x.Grupo == "ESTRUCTURAS") &&
            Datos(MYGCatalogos.LeerPartida(ruta, reservada.Id)) == reservadaAntes,
            "El lote no respetó el orden, los códigos libres, el grupo o la entrada anterior.");
        Exige(Datos(p) == original && ReferenceEquals(p.Items, referenciaItems) && ReferenceEquals(principal.Costos, referenciaCostos) &&
            ReferenceEquals(p.Costos.Insumos[0], referenciaInsumo) &&
            Datos(MYGBaseDatos.LeerProyecto(ruta, documento.Id)) == proyectoGuardado && MYGCatalogos.Listar(ruta, false).Count == 0,
            "Grabar costos múltiples modificó datos, identidades, referencias, obra guardada o catálogo de insumos.");
        pasa("Costos múltiples crea copias nuevas en el orden elegido, genera códigos libres y conserva obra y referencias originales");

        var plantilla = MYGCatalogos.LeerPartida(ruta, entradas[1].Id);
        var raiz = plantilla.Partidas.Single(x => x.IdLocalMYG == plantilla.RaizLocalId);
        Exige(plantilla.Grupo == "ESTRUCTURAS" && plantilla.DecimalesPrecio == 6 && plantilla.DecimalesCantidad == 8 &&
            plantilla.Partidas.Count == 2 && plantilla.Insumos.Count == 4 && Datos(raiz.Costos.Analisis) == Datos(principal.Costos.Analisis) &&
            raiz.Costos.RendimientoDiario == 3.5m && raiz.Costos.JornadaHoras == 6.5m && raiz.Costos.EspecificacionTexto == principal.Costos.EspecificacionTexto &&
            raiz.Costos.EspecificacionRtf == principal.Costos.EspecificacionRtf && Datos(raiz.Costos.Responsables) == Datos(principal.Costos.Responsables) &&
            raiz.Costos.CatalogoMYGId == null && raiz.Costos.CatalogoMYGRuta == null && raiz.Costos.Cantidad == 0 && raiz.Filtros.Count == 0 &&
            plantilla.Insumos.All(x => x.CatalogoMYGId == null && x.CatalogoMYGRuta == null && x.Precio == 2.345678m && x.Marca == "MARCA"),
            "El lote perdió grupos de recursos, subpartidas, metadatos, precisión o limpieza de vínculos y metrados.");
        var reutilizacion = MYGProyectoStorage.Nuevo("OBRA REUTILIZADA").Presupuestos.Single();
        reutilizacion.Costos.DecimalesPrecio = 6; reutilizacion.Costos.DecimalesCantidad = 8;
        foreach (var entrada in entradas)
        {
            var insertada = MYGCatalogos.InsertarPartida(reutilizacion, ruta, entrada, null);
            Exige(MYGMotorPresupuestos.Analizar(reutilizacion, insertada).PrecioUnitario == entrada.Precio,
                "Una partida del lote no conserva su costo al reutilizar el ACU.");
        }
        Exige(Cuenta(ruta, "catalogo_partida") == 4 && Cuenta(ruta, "analisis_costo") == analisisIniciales + 4 &&
            Cuenta(ruta, "catalogo_partida_recurso") == 5 && Cuenta(ruta, "composicion_analisiscosto") == composicionesIniciales + 5,
            "El lote no sincronizó sus ACUs nativos y recursos completos.");
        pasa("Reabrir y reutilizar costos múltiples conserva todos los tipos del ACU, subpartidas, precisión, especificaciones y datos nativos");

        Exige(MYGCatalogos.Listar(ruta, true).Single(x => x.Id == entradas[1].Id).Grupo == "ESTRUCTURAS" &&
            MYGCatalogos.ListarGruposCostos(ruta).SequenceEqual(new[] { "ESTRUCTURAS" }), "El grupo no se recupera al reabrir el catálogo.");
        var actualizada = MYGCatalogos.GuardarPartida(ruta, p, principal, entradas[1].Codigo, principal.Descripcion, principal.Unidad,
            entradas[1].Id, entradas[1].Revision);
        Exige(actualizada.Grupo == "ESTRUCTURAS" && MYGCatalogos.LeerPartida(ruta, actualizada.Id).Grupo == "ESTRUCTURAS",
            "Una actualización individual sin grupo eliminó el grupo del lote.");
        var otroGrupo = MYGCatalogos.GuardarPartida(ruta, p, directa, "OTRO-GRUPO", directa.Descripcion, directa.Unidad, grupo: "  ACABADOS  ");
        MYGCatalogos.GuardarPartida(ruta, p, directa, "OTRO-CASO", directa.Descripcion, directa.Unidad, grupo: "estructuras");
        Exige(MYGCatalogos.ListarGruposCostos(ruta).SequenceEqual(new[] { "ACABADOS", "ESTRUCTURAS" }, StringComparer.OrdinalIgnoreCase),
            "El catálogo de grupos no ordena o duplica los nombres por mayúsculas.");
        var sinGrupo = MYGCatalogos.GuardarPartida(ruta, p, directa, otroGrupo.Codigo, directa.Descripcion, directa.Unidad,
            otroGrupo.Id, otroGrupo.Revision, grupo: "");
        Exige(sinGrupo.Grupo == "" && MYGCatalogos.LeerPartida(ruta, sinGrupo.Id).Grupo == "", "No se puede retirar explícitamente el grupo individual.");
        pasa("Grupos se recuperan sin migración, no duplican nombres por mayúsculas y se conservan en actualizaciones individuales");

        // Simular el JSON de una entrega antigua que no contiene la propiedad Grupo.
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            c.Open(); using var cmd = c.CreateCommand();
            var antiguo = JsonNode.Parse(reservadaAntes).AsObject(); antiguo.Remove("Grupo");
            cmd.CommandText = "UPDATE catalogo_partida SET json_plantilla=$json WHERE id=$id";
            cmd.Parameters.AddWithValue("$json", antiguo.ToJsonString()); cmd.Parameters.AddWithValue("$id", reservada.Id); cmd.ExecuteNonQuery();
        }
        Exige(MYGCatalogos.LeerPartida(ruta, reservada.Id).Grupo == "" && MYGCatalogos.Listar(ruta, true).Single(x => x.Id == reservada.Id).Grupo == "",
            "Una entrada antigua sin Grupo dejó de ser compatible.");
        string native = Path.Combine(carpeta, "Catálogo nativo sin grupos.sqlite");
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = native, Pooling = false }.ToString()))
        {
            c.Open(); using var cmd = c.CreateCommand();
            cmd.CommandText = """
                CREATE TABLE proyecto(id_proyecto TEXT,nombre_proyecto TEXT);
                CREATE TABLE presupuesto(id_presupuesto TEXT,id_proyecto TEXT);
                CREATE TABLE costo_unitario(id_costounitario TEXT);
                CREATE TABLE unidad(id_unidad TEXT,abreviatura_unidad TEXT);
                CREATE TABLE analisis_costo(id_analisiscosto TEXT,descripcion_costo TEXT,id_unidad TEXT,costo_unitario TEXT);
                INSERT INTO unidad VALUES('U1','m');
                INSERT INTO analisis_costo VALUES('A1','ACU NATIVO','U1','12.34');
                """;
            cmd.ExecuteNonQuery();
        }
        string nativeAntes = Huella(native);
        Exige(MYGCatalogos.Listar(native, true).Single().Grupo == "" && MYGCatalogos.ListarGruposCostos(native).Count == 0 &&
            Huella(native) == nativeAntes, "Consultar grupos nativos creó tablas o modificó el catálogo Delphin.");
        pasa("Catálogos anteriores sin Grupo y entradas nativas siguen disponibles sin escrituras al consultarlos");

        string huella = Huella(ruta);
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, p, Array.Empty<string>(), "GRUPO"));
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG, "NO-EXISTE" }, "GRUPO"));
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG, titulo.IdLocalMYG }, "GRUPO"));
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG, principal.IdLocalMYG.ToLowerInvariant() }, "GRUPO"));
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG }, " "));
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG }, new string('A', 121)));
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG }, "GRUPO\nINVÁLIDO"));
        string nueva = Path.Combine(carpeta, "Lote inválido no crea base.sqlite");
        Rechaza(() => MYGCatalogos.GuardarPartidas(nueva, p, new[] { principal.IdLocalMYG, titulo.IdLocalMYG }, "GRUPO"));
        var invalido = MYGProyectoStorage.Copia(p); invalido.Items.Single(x => x.IdLocalMYG == directa.IdLocalMYG).Unidad = "";
        string datosInvalidos = Datos(invalido);
        Rechaza(() => MYGCatalogos.GuardarPartidas(ruta, invalido, new[] { principal.IdLocalMYG, directa.IdLocalMYG }, "GRUPO"));
        Exige(Huella(ruta) == huella && Datos(p) == original && Datos(invalido) == datosInvalidos && !File.Exists(nueva),
            "Una selección, grupo o partida inválida modificó el catálogo, normalizó datos originales o creó una base.");
        pasa("Lotes vacíos, títulos, IDs repetidos o ausentes y grupos inválidos se rechazan completos sin modificar datos");

        string codigoFallo = "P-000006";
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            c.Open(); using var cmd = c.CreateCommand();
            cmd.CommandText = "CREATE TRIGGER fallo_costos_multiples BEFORE INSERT ON catalogo_partida " +
                "WHEN NEW.codigo='" + codigoFallo + "' BEGIN SELECT RAISE(ABORT,'Fallo de prueba de lote'); END";
            cmd.ExecuteNonQuery();
        }
        huella = Huella(ruta);
        long entradasAntes = Cuenta(ruta, "catalogo_partida"), analisisAntes = Cuenta(ruta, "analisis_costo"), productosAntes = Cuenta(ruta, "producto");
        long composicionesAntes = Cuenta(ruta, "composicion_analisiscosto"), nodosAntes = Cuenta(ruta, "catalogo_partida_nodo");
        bool fallo = false;
        try { MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG, directa.IdLocalMYG }, "GRUPO REVERSIÓN"); }
        catch (SqliteException) { fallo = true; }
        Exige(fallo && Huella(ruta) == huella && Datos(p) == original && Cuenta(ruta, "catalogo_partida") == entradasAntes &&
            Cuenta(ruta, "analisis_costo") == analisisAntes && Cuenta(ruta, "producto") == productosAntes &&
            Cuenta(ruta, "composicion_analisiscosto") == composicionesAntes && Cuenta(ruta, "catalogo_partida_nodo") == nodosAntes &&
            !MYGCatalogos.ListarGruposCostos(ruta).Contains("GRUPO REVERSIÓN"),
            "Un fallo después del primer ACU dejó escrituras parciales, grupo persistido o referencias locales modificadas.");
        pasa("Un fallo SQL después del primer ACU revierte el lote, grupos, recursos y todas las copias nativas");

        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        { c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = "DROP TRIGGER fallo_costos_multiples"; cmd.ExecuteNonQuery(); }
        var repetidas = MYGCatalogos.GuardarPartidas(ruta, p, new[] { principal.IdLocalMYG, directa.IdLocalMYG }, "SEGUNDO LOTE");
        Exige(repetidas.Select(x => x.Codigo).SequenceEqual(new[] { "P-000005", "P-000006" }) &&
            repetidas.All(x => !entradas.Any(e => e.Id == x.Id)) && MYGCatalogos.Listar(ruta, true).Count == entradasAntes + 2 && Datos(p) == original,
            "Repetir el guardado sobrescribió las entradas anteriores o no reutilizó códigos del rollback.");
        pasa("Repetir costos múltiples crea instantáneas independientes y reutiliza los códigos liberados por el rollback");
    }

    private static void RegistroAutomatico(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Registro automático de insumos.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        var manoObra = new MYGInsumo { Descripcion = "OPERARIO", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 18m };
        var material = new MYGInsumo { Codigo = "I-000001", Descripcion = "CEMENTO", Unidad = "bol", Grupo = MYGGrupoRecurso.Materiales,
            Precio = 12.345678m, CodigoAlterno = "ALT-C", UsarCodigoAlterno = true, GrupoGenerico = "AGLOMERANTES", Proveedor = "PROVEEDOR",
            DescripcionBase = "BASE CEMENTO", PrecioBase = 12m, FechaBase = new DateTime(2026, 1, 2), UnidadBase = "bol",
            Marca = "MARCA", Especificaciones = "ESPECIFICACIONES", ImagenRuta = "imagen.png", IGVPorcentaje = 18m,
            FechaCompra = new DateTime(2026, 2, 3), FichaTecnicaRuta = "ficha.pdf" };
        var equipo = new MYGInsumo { Codigo = "EQ-01", Descripcion = "MEZCLADORA", Unidad = "hm", Grupo = MYGGrupoRecurso.Equipo, Precio = 50m };
        var subcontrato = new MYGInsumo { Codigo = "SUB-01", Descripcion = "SERVICIO", Unidad = "und", Grupo = MYGGrupoRecurso.Subcontratos, Precio = 100m };
        var herramienta = new MYGInsumo { Descripcion = "HERRAMIENTAS", Unidad = "%mo", Grupo = MYGGrupoRecurso.Equipo, Precio = 3m };
        var lote = new[] { manoObra, material, equipo, subcontrato, herramienta };
        string originales = Datos(lote); int historiales = 0;
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, lote, () =>
        {
            historiales++;
            Exige(Datos(lote) == originales && Cuenta(ruta, "catalogo_insumo") == 0 && Cuenta(ruta, "producto") == 0,
                "El callback debe ver los insumos y el catálogo anteriores a la operación.");
        });
        Exige(historiales == 1 && manoObra.Codigo == "I-000002" && herramienta.Codigo == "I-000003" &&
            material.Codigo == "I-000001", "El código automático consumió un código explícito posterior del lote.");
        Exige(lote.All(x => x.CatalogoMYGRuta == Path.GetFullPath(ruta) && !string.IsNullOrWhiteSpace(x.CatalogoMYGId) && x.Id != x.CatalogoMYGId),
            "El registro no publicó referencias sin cambiar las identidades del presupuesto.");
        var entradas = MYGCatalogos.Listar(ruta, false);
        Exige(entradas.Count == 5 && Cuenta(ruta, "producto") == 5 &&
            lote.All(x => entradas.Single(e => e.Id == x.CatalogoMYGId).Grupo == x.Grupo.ToString() &&
                MYGCatalogos.LeerInsumo(ruta, x.CatalogoMYGId).Grupo == x.Grupo),
            "Reabrir el catálogo perdió insumos o el tipo de mano de obra, material, equipo o subcontrato.");
        var recuperado = MYGCatalogos.LeerInsumo(ruta, material.CatalogoMYGId);
        var esperado = MYGProyectoStorage.Copia(material);
        esperado.Id = material.CatalogoMYGId; esperado.CatalogoMYGId = null; esperado.CatalogoMYGRuta = null;
        Exige(Datos(recuperado) == Datos(esperado), "El registro automático perdió precisión o metadatos del insumo.");
        pasa("Registro automático reabre todos los tipos, metadatos y productos nativos con códigos únicos y un solo historial");

        string huella = Huella(ruta); historiales = 0;
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, lote.Concat(new[] { material }), () => historiales++);
        Exige(historiales == 0 && Huella(ruta) == huella && entradas.All(x => MYGCatalogos.Listar(ruta, false).Single(e => e.Id == x.Id).Revision == 1),
            "Repetir el registro duplicó entradas, revisiones o historial.");
        material.Precio = 99m; material.Descripcion = "CEMENTO EDITADO EN OBRA";
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, lote, () => historiales++);
        Exige(historiales == 0 && Huella(ruta) == huella && MYGCatalogos.LeerInsumo(ruta, material.CatalogoMYGId).Precio == 12.345678m,
            "Registrar una referencia válida sobrescribió el catálogo con la edición local.");
        pasa("Registro repetido es idempotente y conserva las entradas de catálogo ante ediciones locales");

        var igual = MYGProyectoStorage.Copia(recuperado);
        igual.Id = MYGProyectoStorage.NuevoId(); igual.Codigo = igual.Codigo.ToLowerInvariant();
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, new[] { igual }, () => historiales++);
        Exige(historiales == 1 && igual.CatalogoMYGId == material.CatalogoMYGId && Huella(ruta) == huella &&
            MYGCatalogos.Listar(ruta, false).Count == 5, "Un código con los mismos datos no reutilizó la entrada existente.");
        var igualesNuevos = new[]
        {
            new MYGInsumo { Codigo = "MAT-IGUAL", Descripcion = "AGREGADO", Unidad = "m³", Precio = 5m },
            new MYGInsumo { Codigo = "mat-igual", Descripcion = "AGREGADO", Unidad = "m³", Precio = 5m }
        };
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, igualesNuevos);
        Exige(igualesNuevos[0].CatalogoMYGId == igualesNuevos[1].CatalogoMYGId && MYGCatalogos.Listar(ruta, false).Count == 6,
            "Dos códigos iguales del mismo lote crearon entradas duplicadas.");
        pasa("Códigos repetidos con todos los datos iguales reutilizan la entrada existente o una sola entrada del lote");

        huella = Huella(ruta); historiales = 0;
        var nuevo = new MYGInsumo { Descripcion = "INSUMO PREVIO AL CONFLICTO", Unidad = "kg" };
        var distinto = MYGProyectoStorage.Copia(recuperado); distinto.Id = MYGProyectoStorage.NuevoId(); distinto.Marca = "OTRA MARCA";
        var conflicto = new[] { nuevo, distinto }; originales = Datos(conflicto);
        string mensaje = null;
        try { MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, conflicto, () => historiales++); }
        catch (InvalidOperationException ex) { mensaje = ex.Message; }
        Exige(mensaje != null && mensaje.Contains(distinto.Codigo) && mensaje.Contains("Cambie el código") &&
            historiales == 0 && Huella(ruta) == huella && Datos(conflicto) == originales,
            "El conflicto de metadatos no rechazó todo el lote con información útil y sin alterar objetos o catálogo.");
        var conflictoInterno = new[]
        {
            new MYGInsumo { Codigo = "CONFLICTO-NUEVO", Descripcion = "MATERIAL A", Unidad = "kg" },
            new MYGInsumo { Codigo = "conflicto-nuevo", Descripcion = "MATERIAL B", Unidad = "kg" }
        };
        Rechaza(() => MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, conflictoInterno, () => historiales++));
        Exige(historiales == 0 && Huella(ruta) == huella && conflictoInterno.All(x => x.CatalogoMYGId == null),
            "El conflicto interno publicó parcialmente el lote.");
        pasa("Conflictos contra catálogo o dentro del lote se rechazan por completo antes del historial");

        var invalido = new MYGInsumo { Descripcion = "PRECIO INVÁLIDO", Precio = -1m };
        originales = Datos(nuevo);
        Rechaza(() => MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, new[] { nuevo, invalido }, () => historiales++));
        Rechaza(() => MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, new[] { nuevo }, () => throw new InvalidOperationException("No guardar historial")));
        Exige(historiales == 0 && Huella(ruta) == huella && Datos(nuevo) == originales,
            "La validación o el callback fallido alteró insumos o catálogo.");
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, Array.Empty<MYGInsumo>(), () => historiales++);
        Exige(historiales == 0 && Huella(ruta) == huella, "Un lote vacío cambió el catálogo o agregó historial.");
        pasa("Lotes inválidos, vacíos y callback fallido conservan insumos y catálogo sin publicaciones parciales");

        // Simular un fallo de escritura después del primer insumo verifica también
        // el rollback de las filas nativas, no sólo la validación en memoria.
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            c.Open(); using var cmd = c.CreateCommand();
            cmd.CommandText = "CREATE TRIGGER fallo_registro BEFORE INSERT ON catalogo_insumo WHEN NEW.codigo='FALLO-DB' BEGIN SELECT RAISE(ABORT,'Fallo de prueba'); END";
            cmd.ExecuteNonQuery();
        }
        huella = Huella(ruta); long productos = Cuenta(ruta, "producto");
        var fallaEscritura = new[] { nuevo, new MYGInsumo { Codigo = "FALLO-DB", Descripcion = "FALLO SIMULADO", Unidad = "kg" } };
        originales = Datos(fallaEscritura); bool fallo = false;
        try { MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, fallaEscritura); }
        catch (SqliteException) { fallo = true; }
        Exige(fallo && Huella(ruta) == huella && Cuenta(ruta, "producto") == productos && Datos(fallaEscritura) == originales &&
            MYGCatalogos.Listar(ruta, false).Count == 6, "Un fallo SQL dejó insumos, referencias o productos nativos parciales.");
        pasa("La transacción revierte catálogo, productos nativos y referencias locales cuando falla una escritura posterior");

        string rutaAnterior = Path.Combine(carpeta, "Insumos locales de una obra anterior.sqlite");
        var obraAnterior = MYGProyectoStorage.Nuevo("OBRA ANTERIOR");
        var presupuestoAnterior = obraAnterior.Presupuestos.Single();
        var partidaAnterior = Nodo("ACU CON INSUMOS LOCALES"); presupuestoAnterior.Items.Add(partidaAnterior);
        foreach (var fuente in new[] { manoObra, recuperado, equipo, subcontrato })
        {
            var local = MYGProyectoStorage.Copia(fuente); local.Id = MYGProyectoStorage.NuevoId(); local.Codigo = "";
            local.CatalogoMYGId = null; local.CatalogoMYGRuta = null;
            presupuestoAnterior.Costos.Insumos.Add(local);
            partidaAnterior.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = local.Id, Grupo = local.Grupo, Cantidad = 1m });
        }
        // Una referencia a otra base que no existe aquí también se recupera.
        presupuestoAnterior.Costos.Insumos[0].CatalogoMYGId = MYGProyectoStorage.NuevoId();
        presupuestoAnterior.Costos.Insumos[0].CatalogoMYGRuta = "otro_catalogo.sqlite";
        MYGProyectoStorage.Guardar(rutaAnterior, obraAnterior);
        obraAnterior = MYGProyectoStorage.Leer(rutaAnterior); presupuestoAnterior = obraAnterior.Presupuestos.Single();
        Exige(MYGCatalogos.Listar(rutaAnterior, false).Count == 0, "El guardado de la obra registró insumos antes de la recuperación.");
        string analisisAnterior = Datos(presupuestoAnterior.Items.Single().Costos.Analisis);
        MYGCatalogos.RegistrarInsumosAutomaticamente(rutaAnterior, presupuestoAnterior.Costos.Insumos);
        MYGProyectoStorage.Guardar(rutaAnterior, obraAnterior);
        var reabierto = MYGProyectoStorage.Leer(rutaAnterior).Presupuestos.Single();
        Exige(MYGCatalogos.Listar(rutaAnterior, false).Count == 4 && reabierto.Costos.Insumos.All(x =>
                MYGCatalogos.LeerInsumo(rutaAnterior, x.CatalogoMYGId).Grupo == x.Grupo && !string.IsNullOrWhiteSpace(x.Codigo)) &&
            Datos(reabierto.Items.Single().Costos.Analisis) == analisisAnterior,
            "La recuperación perdió el tipo, las referencias persistidas o las líneas del ACU anterior.");
        pasa("Recuperar insumos locales anteriores o referencias ausentes llena el catálogo y persiste tipos y vínculos sin alterar el ACU");
    }
}
