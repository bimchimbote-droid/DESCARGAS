# Pruebas de interfaz en Windows

Estas comprobaciones necesitan Windows y el SDK .NET 10.0.100. Desde la raíz del repositorio:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Se abren y cierran automáticamente los diálogos de prueba. Se verifica que la unidad de una partida (`und`, `m²` o una unidad propia) sobreviva al mostrar el formulario y renovar su `BindingContext`, y que elegir otra unidad funcione.

También se ejercita el mismo punto de aplicación del arrastre por IDs: el mensaje debe mostrar origen y destino, Enter y Escape deben cancelar, rechazar o cerrar no debe modificar el documento ni agregar historial, y aceptar debe aplicar el movimiento una sola vez. No necesita conexión a Revit ni simula OLE.

Se comprueban ambas paletas, colores opacos y la conservación de textos, opciones, contenido RTF y una edición pendiente al alternar. Estas pruebas no guardan ni cambian la preferencia de apariencia del usuario.

En Linux se puede compilar con `dotnet build MYG.PruebasUI/MYG.PruebasUI.csproj -c Release`; la ejecución requiere el runtime Windows Desktop.
