using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using MYG_2027;

static class ProjectAperturaCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        ComprobarFirmaMinima(pasa);
        ComprobarResultado(pasa);
        ComprobarRutaInvalida(pasa);
        ComprobarDiagnostico(pasa);
        ComprobarIdentidadYVisibilidad(pasa);
    }

    private static void ComprobarFirmaMinima(Action<string> pasa)
    {
        string ruta = Path.Combine(Path.GetTempPath(), "MYG exportación ñ " + Guid.NewGuid().ToString("N"),
            "Cronograma de obra.MPP");
        int llamadas = 0;
        MYGAperturaProject.AbrirMpp(ruta, argumentos =>
        {
            llamadas++;
            // Es un contrato de llamada conforme a la firma de FileOpenEx;
            // no sustituye una ejecución real de la automatización de Office.
            Exige(argumentos.Length == 7 && argumentos[0] is string nombre && nombre == ruta,
                "FileOpenEx debe recibir la ruta MPP completa como primer argumento, conservando espacios y Unicode.");
            Exige(argumentos[1] is bool soloLectura && !soloLectura &&
                argumentos[6] is bool sinMacros && sinMacros,
                "FileOpenEx debe abrir para edición y evitar ejecutar macros Auto_Open.");
            for (int i = 2; i <= 5; i++)
                Exige(ReferenceEquals(argumentos[i], Type.Missing),
                    "Merge, TaskInformation, Table y Sheet deben conservar sus valores predeterminados.");
            return true;
        });
        Exige(llamadas == 1 && !File.Exists(ruta),
            "AbrirMpp debe llamar una sola vez a FileOpenEx y no exigir ni crear el archivo durante este contrato.");
        pasa("El contrato prepara la apertura MPP con espacios y Unicode mediante la firma mínima de FileOpenEx y conserva ausentes los opcionales de importación");
    }

    private static void ComprobarResultado(Action<string> pasa)
    {
        foreach (object resultado in new object[] { false, null, 1, "true", Type.Missing })
        {
            int llamadas = 0;
            Captura<InvalidOperationException>(() => MYGAperturaProject.AbrirMpp("resultado.mpp", _ =>
            {
                llamadas++;
                return resultado;
            }));
            Exige(llamadas == 1,
                "Un resultado de apertura distinto de bool true debe rechazarse sin reintentos silenciosos.");
        }
        pasa("Project exige bool true para confirmar FileOpenEx y rechaza cancelación, respuesta nula y tipos inesperados");
    }

    private static void ComprobarRutaInvalida(Action<string> pasa)
    {
        foreach (string ruta in new[] { null, "", "  ", "cronograma.xml", "cronograma.mpp.xml" })
        {
            int llamadas = 0;
            Captura<ArgumentException>(() => MYGAperturaProject.AbrirMpp(ruta, _ =>
            {
                llamadas++;
                return true;
            }));
            Exige(llamadas == 0,
                "Una ruta vacía o ajena al formato MPP debe rechazarse antes de acceder a Project.");
        }
        pasa("Project rechaza rutas vacías y formatos distintos de MPP antes de ejecutar la apertura");
    }

    private static void ComprobarDiagnostico(Action<string> pasa)
    {
        const int tiposIncompatibles = unchecked((int)0x80020005);
        foreach (string operacion in new[] { "FileOpenEx", "Visible" })
        {
            var causa = new COMException("Fallo COM de prueba", tiposIncompatibles);
            Exception fallo = operacion == "FileOpenEx" ? causa : new TargetInvocationException(causa);
            var error = Captura<InvalidOperationException>(() =>
                MYGAperturaProject.Ejecutar<int>(operacion, () => throw fallo));
            Exige(error.Message.Contains(operacion, StringComparison.Ordinal) &&
                error.Message.Contains("0x80020005", StringComparison.OrdinalIgnoreCase) &&
                ReferenceEquals(error.GetBaseException(), causa),
                "El diagnóstico debe identificar la operación, mostrar el HRESULT y preservar la causa COM.");
        }
        var causaReflexion = new InvalidCastException("Causa de reflexión de prueba");
        var errorReflexion = Captura<InvalidOperationException>(() =>
            MYGAperturaProject.Ejecutar<int>("ActiveProject.FullName", () =>
                throw new TargetInvocationException(causaReflexion)));
        Exige(errorReflexion.Message.Contains("ActiveProject.FullName", StringComparison.Ordinal) &&
            ReferenceEquals(errorReflexion.GetBaseException(), causaReflexion),
            "Una excepción de reflexión debe conservar la operación y su causa original.");
        var falloLocal = new IOException("Fallo local de prueba");
        Exige(ReferenceEquals(falloLocal, Captura<IOException>(() =>
            MYGAperturaProject.Ejecutar<int>("FileOpenEx", () => throw falloLocal))),
            "Las excepciones ajenas a COM y reflexión deben propagarse sin sustitución.");
        Exige(MYGAperturaProject.Ejecutar("FileOpenEx", () => 7) == 7,
            "La ejecución sin error debe conservar el resultado original.");
        pasa("Project distingue fallos de FileOpenEx y visibilidad, informa el HRESULT y conserva la causa COM o de reflexión sin ocultar otros errores");
    }

    private static void ComprobarIdentidadYVisibilidad(Action<string> pasa)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG exportación ñ");
        string esperado = Path.Combine(carpeta, "Cronograma.mpp");
        string equivalente = Path.Combine(carpeta, ".", "CRONOGRAMA.MPP");
        MYGAperturaProject.VerificarApertura(esperado, equivalente, true);
        Captura<InvalidOperationException>(() => MYGAperturaProject.VerificarApertura(
            esperado, Path.Combine(carpeta, "Otro cronograma.mpp"), true));
        Captura<InvalidOperationException>(() => MYGAperturaProject.VerificarApertura(
            esperado, esperado, false));
        pasa("Project confirma el archivo activo por su ruta completa sin distinguir mayúsculas y exige que la aplicación esté visible");
    }

    private static void Exige(bool condicion, string mensaje)
    {
        if (!condicion) throw new Exception(mensaje);
    }

    private static T Captura<T>(Action accion) where T : Exception
    {
        try { accion(); }
        catch (T error) { return error; }
        throw new Exception("Se esperaba " + typeof(T).Name + ".");
    }
}
