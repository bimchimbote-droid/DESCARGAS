using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

static class EdicionPartidaCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Rechaza(Action accion, string mensaje)
    {
        try { accion(); }
        catch (InvalidOperationException) { return; }
        catch (InvalidDataException) { return; }
        throw new Exception(mensaje);
    }
    private static MYGPresupuestoDocumento Crear(MYGFuenteMetrado fuente = MYGFuenteMetrado.Cantidad)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "EDICIÓN EN TABLA", Item = "01" };
        var i = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        i.Descripcion = "PARTIDA EDITABLE"; i.Unidad = "und";
        i.Costos.Cantidad = 2.5m; i.Costos.PrecioDirecto = 10;
        i.Costos.Metrados.Add(new() { Descripcion = "METRADO CONSERVADO", Elementos = 1, CantidadPorElemento = 7 });
        i.Costos.MetradosBIM.Add(new() { ActivoId = "ACTIVO-1", DocumentoId = "MODELO-1", Unidad = "und", Cantidad = 8 });
        i.Costos.Hoja.Poner("G16", "9.1256");
        i.Costos.FuenteMetrado = fuente;
        MYGProyectoStorage.ValidarPresupuesto(p);
        return p;
    }
    private static object SQL(string ruta, string consulta)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString()); c.Open();
        using var q = c.CreateCommand(); q.CommandText = consulta; return q.ExecuteScalar();
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        foreach (var fuente in Enum.GetValues<MYGFuenteMetrado>())
        {
            var p = Crear(fuente); var i = p.Items.Single(); var costos = i.Costos;
            var items = p.Items; var manual = costos.Metrados; var bim = costos.MetradosBIM; var hoja = costos.Hoja; var acu = costos.Analisis;
            string fuentes = Firma(new { manual, bim, hoja, acu });
            var instantanea = MYGProyectoStorage.Copia(p);
            MYGEdicionPartida.CambiarCantidad(p, i, 12.34m);
            Exige(i.Costos.Cantidad == 12.34m && i.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
                MYGMotorPresupuestos.Cantidad(p, i) == 12.34m && MYGMotorPresupuestos.TotalPartida(p, i) == 123.40m,
                "Editar la cantidad no activó el metrado directo o no recalculó el total.");
            Exige(ReferenceEquals(items, p.Items) && ReferenceEquals(i, p.Items.Single()) && ReferenceEquals(costos, i.Costos) &&
                ReferenceEquals(manual, i.Costos.Metrados) && ReferenceEquals(bim, i.Costos.MetradosBIM) &&
                ReferenceEquals(hoja, i.Costos.Hoja) && ReferenceEquals(acu, i.Costos.Analisis) &&
                Firma(new { manual, bim, hoja, acu }) == fuentes,
                "Editar cantidad perdió datos de fuentes o sustituyó instancias usadas por el editor.");
            Exige(instantanea.Items.Single().Costos.FuenteMetrado == fuente && instantanea.Items.Single().Costos.Cantidad == 2.5m,
                "La instantánea anterior a la edición se alteró.");
            i.Costos.FuenteMetrado = fuente;
            decimal esperado = fuente switch { MYGFuenteMetrado.Manual => 7m, MYGFuenteMetrado.BIM => 8m, MYGFuenteMetrado.Excel => 9.1256m, _ => 12.34m };
            Exige(MYGMotorPresupuestos.Cantidad(p, i) == esperado, "No se pudo recuperar el metrado anterior desde su fuente.");
        }
        pasa("Edición de cantidad activa el valor directo sin perder fuentes Manual/BIM/Excel, referencias ni instantáneas de historial");

        var limites = Crear(); var partida = limites.Items.Single();
        foreach (decimal cantidad in new[] { 0m, 0.01m, 12.34m, MYGEdicionPartida.CantidadMaxima })
        {
            MYGEdicionPartida.CambiarCantidad(limites, partida, cantidad);
            Exige(MYGMotorPresupuestos.Cantidad(limites, partida) == cantidad, "Se rechazó o redondeó una cantidad válida.");
        }
        foreach (decimal cantidad in new[] { -0.01m, 0.001m, 12.345m, MYGEdicionPartida.CantidadMaxima + 0.01m })
        {
            string antes = Firma(limites);
            Rechaza(() => MYGEdicionPartida.CambiarCantidad(limites, partida, cantidad), "Se aceptó cantidad negativa, excesiva o con más de dos decimales.");
            Exige(Firma(limites) == antes, "Rechazar una cantidad dejó cambios parciales.");
        }
        string firma = Firma(limites);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(limites, Crear().Items.Single(), 1), "Se editó una partida de otro presupuesto.");
        Exige(Firma(limites) == firma, "La referencia inválida cambió el presupuesto.");
        var titulo = MYGEstructuraPresupuestos.InsertarNodo(limites, true); firma = Firma(limites);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(limites, titulo, 1), "Se asignó cantidad a un título.");
        Rechaza(() => MYGEdicionPartida.CambiarUnidad(limites, titulo, "m"), "Se asignó unidad a un título.");
        Exige(Firma(limites) == firma, "Editar un título dejó cambios parciales.");
        var excesivo = Crear(); var enorme = excesivo.Items.Single(); enorme.Costos.Cantidad = 0; enorme.Costos.PrecioDirecto = decimal.MaxValue;
        firma = Firma(excesivo);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(excesivo, enorme, 10), "Se aceptó un importe que desborda decimal.");
        Exige(Firma(excesivo) == firma, "El desbordamiento mutó el presupuesto.");
        pasa("Cantidades admiten cero y dos decimales; límites, títulos, referencias inválidas y desbordamientos se rechazan atómicamente");

        var unidades = Crear(); var conBim = unidades.Items.Single();
        conBim.Unidad = "m2"; conBim.Costos.MetradosBIM.Single().Unidad = "m²";
        MYGEdicionPartida.CambiarUnidad(unidades, conBim, " m² ");
        Exige(conBim.Unidad == "m²" && conBim.Costos.MetradosBIM.Single().Cantidad == 8, "No se aceptó una unidad BIM equivalente.");
        foreach (string invalida in new[] { "m3", "", "   " })
        {
            firma = Firma(unidades);
            Rechaza(() => MYGEdicionPartida.CambiarUnidad(unidades, conBim, invalida), "Se aceptó una unidad vacía o incompatible con BIM.");
            Exige(Firma(unidades) == firma, "La unidad rechazada dejó cambios parciales.");
        }
        conBim.Costos.MetradosBIM.Clear();
        MYGEdicionPartida.CambiarUnidad(unidades, conBim, "m3");
        Exige(conBim.Unidad == "m3" && conBim.Costos.Metrados.Count == 1 && conBim.Costos.Hoja.Celdas["G16"].Contenido == "9.1256",
            "El cambio de unidad perdió los metrados que conserva el usuario.");
        conBim.IdInternoDelphin = "PARTIDA-OFICIAL"; firma = Firma(unidades);
        Rechaza(() => MYGEdicionPartida.CambiarUnidad(unidades, conBim, "m"), "Se cambió la unidad oficial Delphin.");
        Exige(Firma(unidades) == firma, "La unidad oficial rechazada mutó el documento.");
        pasa("Unidades protegen metrados BIM incluso con fuente directa, permiten símbolos equivalentes y conservan identidad oficial Delphin");

        var nativo = Crear(); var oficial = nativo.Items.Single(); oficial.IdInternoDelphin = "NATIVA-ORIGINAL";
        oficial.Costos.Cantidad = 3; oficial.Costos.PrecioDirecto = 0.62m;
        MYGMotorPresupuestos.CapturarPrecioDelphin(nativo, oficial, 0.63m, 1.88m);
        string identidad = Firma(new { oficial.Id, oficial.IdLocalMYG, oficial.IdInternoDelphin, oficial.Item, oficial.Descripcion, oficial.Unidad });
        string firmaAnalisis = oficial.Costos.FirmaAnalisisImportadoDelphin;
        Exige(MYGMotorPresupuestos.TotalPartida(nativo, oficial) == 1.88m, "La partida no conserva el parcial inicial nativo.");
        MYGEdicionPartida.CambiarCantidad(nativo, oficial, 4.25m);
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(nativo, oficial) && MYGMotorPresupuestos.Analizar(nativo, oficial).PrecioUnitario == 0.63m &&
            MYGMotorPresupuestos.TotalPartida(nativo, oficial) == 2.68m && oficial.Costos.FirmaAnalisisImportadoDelphin == firmaAnalisis &&
            oficial.Costos.CantidadImportadaDelphin == 3 && oficial.Costos.ParcialImportadoDelphin == 1.88m &&
            Firma(new { oficial.Id, oficial.IdLocalMYG, oficial.IdInternoDelphin, oficial.Item, oficial.Descripcion, oficial.Unidad }) == identidad,
            "Editar cantidad oficial alteró identidad, precio/firma ACU o reutilizó el parcial importado.");
        var proyecto = new MYGProyectoDocumento { Nombre = "EDICIÓN PERSISTIDA", Datos = new MYGDatosProyecto { UsarUbicacion = false }, Presupuestos = new() { nativo } };
        string ruta = Path.Combine(carpeta, "Edición partida.sqlite"); MYGProyectoStorage.Guardar(ruta, proyecto);
        var leido = MYGBaseDatos.LeerProyecto(ruta, proyecto.Id).Presupuestos.Single(); var reabierta = leido.Items.Single();
        Exige(reabierta.Costos.Cantidad == 4.25m && reabierta.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
            reabierta.Costos.Metrados.Count == 1 && reabierta.Costos.MetradosBIM.Single().Cantidad == 8 &&
            MYGMotorPresupuestos.TotalPartida(leido, reabierta) == 2.68m &&
            Convert.ToDecimal(SQL(ruta, "SELECT cantidad FROM costo_unitario WHERE descripcion_costo='PARTIDA EDITABLE'")) == 4.25m &&
            Convert.ToDecimal(SQL(ruta, "SELECT parcial_costo FROM costo_unitario WHERE descripcion_costo='PARTIDA EDITABLE'")) == 2.68m,
            "SQLite no conservó la edición o difiere de las columnas nativas.");
        string rutaUnidad = Path.Combine(carpeta, "Edición unidad.sqlite");
        var unidadPropia = Crear(); var sinBim = unidadPropia.Items.Single(); sinBim.Costos.MetradosBIM.Clear();
        MYGEdicionPartida.CambiarUnidad(unidadPropia, sinBim, "m3");
        proyecto = new MYGProyectoDocumento { Nombre = "UNIDAD PERSISTIDA", Datos = new MYGDatosProyecto { UsarUbicacion = false }, Presupuestos = new() { unidadPropia } };
        MYGProyectoStorage.Guardar(rutaUnidad, proyecto);
        Exige(MYGBaseDatos.LeerProyecto(rutaUnidad, proyecto.Id).Presupuestos.Single().Items.Single().Unidad == "m3",
            "SQLite no conservó la unidad editada.");
        pasa("Edición oficial conserva precio y firma ACU, recalcula el parcial y persiste cantidades/unidades en SQLite MYG y formato nativo");

        foreach (string nombreCultura in new[] { "en-US", "es-PE", "es-ES" })
        {
            var cultura = CultureInfo.GetCultureInfo(nombreCultura);
            foreach (string texto in new[] { "1234.56", "1234,56", "1,234.56", "1.234,56", " +1234.56 " })
                Exige(MYGFormatoPresupuesto.IntentarCantidad(texto, cultura, out var numero) && numero == 1234.56m,
                    "La cantidad no interpreta separadores explícitos en " + nombreCultura + ": " + texto);
            foreach (string texto in new[] { "1,234", "1.234", "12,34.56", "1,23,456.78", "1.234.56", "1234.567", "-1", "1e3", "NaN", "", "1000000000000.01" })
                Exige(!MYGFormatoPresupuesto.IntentarCantidad(texto, cultura, out _),
                    "La cantidad aceptó separadores ambiguos, precisión/rango inválido en " + nombreCultura + ": " + texto);
            Exige(MYGFormatoPresupuesto.IntentarCantidad("0", cultura, out var cero) && cero == 0 &&
                MYGFormatoPresupuesto.IntentarCantidad("1,234,567.89", cultura, out var miles) && miles == 1234567.89m,
                "La cantidad no admite cero o miles agrupados correctamente.");
        }
        Exige(MYGFormatoPresupuesto.Dinero(1234567.89m) == "1,234,567.89" && MYGFormatoPresupuesto.Cantidad(12.3m) == "12.30" &&
            MYGFormatoPresupuesto.Cantidad(9.1256m) == "9.13", "El formato visual no aplica dos decimales y miles invariantes.");
        pasa("Formato visual usa 1,234,567.89 y dos decimales; entrada en-US/es-PE/es-ES rechaza separadores ambiguos y agrupaciones inválidas");

        var exportacion = MYGExcelPresupuestos.Tabla("FORMATOS", new[] { "Cantidad", "Precio", "Total", "Coeficiente" },
            new[] { new object[] { 1234.5678m, 1234567.8912m, "=A2*B2", 0.1234m }, new object[] { 12.3456m, 33.3333m } });
        foreach (string direccion in new[] { "A2", "B2", "C2", "A3", "B3" }) exportacion.Celdas[direccion].FormatoNumero = "#,##0.00";
        exportacion.Celdas["A3"].Negrita = true; exportacion.Celdas["B3"].Cursiva = true;
        string excel = Path.Combine(carpeta, "Formatos presupuesto.xlsx"); MYGExcelPresupuestos.Guardar(excel, new[] { exportacion });
        using (var libro = ZipFile.OpenRead(excel))
        {
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            XDocument Leer(string parte) { using var flujo = libro.GetEntry(parte).Open(); return XDocument.Load(flujo); }
            var estilos = Leer("xl/styles.xml"); var celdas = Leer("xl/worksheets/sheet1.xml").Descendants(s + "c")
                .ToDictionary(x => (string)x.Attribute("r"));
            var formatos = estilos.Descendants(s + "numFmt").ToDictionary(x => (int)x.Attribute("numFmtId"), x => (string)x.Attribute("formatCode"));
            var xfs = estilos.Root.Element(s + "cellXfs").Elements(s + "xf").ToArray();
            XElement Estilo(string direccion) => xfs[(int)celdas[direccion].Attribute("s")];
            string Formato(string direccion) => formatos[(int)Estilo(direccion).Attribute("numFmtId")];
            decimal Valor(string direccion) => decimal.Parse(celdas[direccion].Element(s + "v").Value, CultureInfo.InvariantCulture);
            Exige(new[] { "A2", "B2", "C2", "A3", "B3" }.All(d => Formato(d) == "#,##0.00") && Formato("D2") == "0.0000" &&
                Valor("A2") == 1234.5678m && Valor("B2") == 1234567.8912m && Valor("D2") == 0.1234m &&
                Valor("C2") == 1234.5678m * 1234567.8912m && celdas["C2"].Element(s + "f").Value == "A2*B2",
                "Excel no distingue importes/cantidades de dos decimales y coeficientes de cuatro, o redondeó valores/fórmulas.");
            Exige((int)Estilo("A3").Attribute("fontId") == 1 && (int)Estilo("B3").Attribute("fontId") == 2,
                "El nuevo formato numérico eliminó negrita o cursiva.");
        }
        pasa("Excel conserva valores y fórmulas sin redondear y aplica dos decimales con miles a presupuesto, cuatro a coeficientes y estilos de texto");
    }
}
