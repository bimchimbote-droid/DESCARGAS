using System;
using System.Globalization;
using System.Text;
using MYG_2027;

internal static class EspecificacionesPegadoCheck
{
    private static void Exige(bool condicion, string detalle)
    {
        if (!condicion) throw new Exception(detalle);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        var formato = MYGEspecificacionesHtmlPegado.Convertir("<p><b>Hormigón <i>armado</i></b> y <u>acero</u>, H<sub>2</sub>O / m<sup>2</sup></p><p><s>Anterior</s></p>");
        Exige(formato.Texto == "Hormigón armado y acero, H2O / m2\nAnterior\n", "El pegado HTML perdió caracteres, espacios o párrafos.");
        Exige(formato.Rtf.Contains("{\\b ") && formato.Rtf.Contains("{\\i ") && formato.Rtf.Contains("{\\ul ")
            && formato.Rtf.Contains("{\\sub ") && formato.Rtf.Contains("{\\super ") && formato.Rtf.Contains("{\\strike "),
            "El HTML debe conservar los estilos y la posición de los caracteres.");
        Exige(GruposEquilibrados(formato.Rtf), "Los estilos anidados generaron un RTF desequilibrado.");
        pasa("Pegado HTML conserva negrita, cursiva, subrayado, tachado, subíndices y párrafos");

        var seguro = MYGEspecificacionesHtmlPegado.Convertir("<head><title>Invisible</title></head><p onclick='alert(1)'>Seguro<script>robar()</script><style>.x {display:none}</style><iframe src='https://example.com'>oculto</iframe><object>objeto</object><svg><text>vector</text></svg><a href='javascript:alert(1)'> enlace</a><img src='https://example.com/privado' alt=' sin red'></p>");
        Exige(seguro.Texto == "Seguro enlace sin red\n", "El pegado incluyó contenido ejecutable u oculto.");
        Exige(!seguro.Rtf.Contains("robar") && !seguro.Rtf.Contains("javascript") && !seguro.Rtf.Contains("https") && !seguro.Rtf.Contains("\\field"),
            "La importación HTML no debe construir referencias activas ni descargar recursos.");
        pasa("Pegado HTML omite scripts, objetos, estilos y destinos de red mientras conserva texto visible");

        var unicode = MYGEspecificacionesHtmlPegado.Convertir("<span>á&amp;ñ &lt;{\\rtf1}&gt; &#x1F600; &nbsp; fin</span>");
        Exige(unicode.Texto == "á&ñ <{\\rtf1}> 😀 \u00a0 fin", "El HTML debe decodificar entidades y conservar Unicode.");
        Exige(unicode.Rtf.Contains("\\u225?") && unicode.Rtf.Contains("\\u-10179?\\u-8704?")
            && unicode.Rtf.Contains("\\{\\\\rtf1\\}") && GruposEquilibrados(unicode.Rtf),
            "El texto pegado debe escapar instrucciones RTF y codificar correctamente los pares suplentes Unicode.");
        pasa("Pegado HTML decodifica entidades, conserva Unicode y escapa instrucciones RTF en el texto");

        var css = MYGEspecificacionesHtmlPegado.Convertir("<p style=\"text-align:center\"><span style=\"font-family:'Arial Narrow';font-size:12pt;font-weight:700;font-style:italic;color:#a12;background-color:yellow\">Medida</span></p>");
        Exige(css.Texto == "Medida\n" && css.Rtf.Contains("Arial Narrow;") && css.Rtf.Contains("\\f1 ")
            && css.Rtf.Contains("\\fs24 ") && css.Rtf.Contains("\\red170\\green17\\blue34;")
            && css.Rtf.Contains("\\red255\\green255\\blue0;") && css.Rtf.Contains("\\qc ")
            && css.Rtf.Contains("\\highlight2 "), "El pegado HTML debe conservar el formato CSS básico.");
        pasa("Pegado HTML conserva fuentes, tamaños, alineación, colores y resaltado CSS básicos");

        var rgb = MYGEspecificacionesHtmlPegado.Convertir("<span style='color:rgb(100%,0%,50%);font-size:16px'>Color</span>");
        Exige(rgb.Rtf.Contains("\\red255\\green0\\blue128;") && rgb.Rtf.Contains("\\fs24 "),
            "El HTML de navegadores debe convertir colores RGB y tamaños de píxeles a puntos.");
        pasa("Pegado HTML reconoce colores RGB de navegadores y convierte tamaños en píxeles");

        var listas = MYGEspecificacionesHtmlPegado.Convertir("<ol start='3'><li>Uno</li><li>Dos<ul><li>Subpartida</li></ul></li></ol><pre>A\n  B\tC</pre>");
        Exige(listas.Texto == "3. Uno\n4. Dos\n• Subpartida\nA\n  B\tC\n", "El HTML perdió numeración de listas o espacios preformateados.");
        Exige(GruposEquilibrados(listas.Rtf), "Las listas anidadas generaron un RTF desequilibrado.");
        pasa("Pegado HTML conserva numeración de listas anidadas y espacios de bloques preformateados");

        string conMarcadores = "Version:1.0\r\nSourceURL:https://example.com/\r\n<html><body>fuera<!--StartFragment--><b>Adentro</b><!--EndFragment-->fuera</body></html>";
        Exige(MYGEspecificacionesHtmlPegado.Convertir(conMarcadores).Texto == "Adentro", "CF_HTML debe pegar sólo el fragmento seleccionado.");
        string fragmento = "<b>acción 😀</b>";
        string encabezado = "Version:1.0\r\nStartHTML:0000000000\r\nEndHTML:0000000000\r\nStartFragment:0000000000\r\nEndFragment:0000000000\r\n";
        string antes = "<html><body>ñ";
        int startHtml = Encoding.UTF8.GetByteCount(encabezado), startFragment = startHtml + Encoding.UTF8.GetByteCount(antes);
        int endFragment = startFragment + Encoding.UTF8.GetByteCount(fragmento), endHtml = endFragment + Encoding.UTF8.GetByteCount("</body></html>");
        string cfHtml = "Version:1.0\r\nStartHTML:" + startHtml.ToString("D10", CultureInfo.InvariantCulture)
            + "\r\nEndHTML:" + endHtml.ToString("D10", CultureInfo.InvariantCulture)
            + "\r\nStartFragment:" + startFragment.ToString("D10", CultureInfo.InvariantCulture)
            + "\r\nEndFragment:" + endFragment.ToString("D10", CultureInfo.InvariantCulture) + "\r\n" + antes + fragmento + "</body></html>";
        Exige(MYGEspecificacionesHtmlPegado.ExtraerFragmento(cfHtml) == fragmento
            && MYGEspecificacionesHtmlPegado.Convertir(cfHtml).Texto == "acción 😀",
            "CF_HTML debe interpretar los offsets como bytes UTF-8, incluso con caracteres multibyte antes del fragmento.");
        pasa("CF_HTML respeta fragmentos seleccionados y offsets UTF-8 con acentos y emoji");

        var htmlIncompleto = MYGEspecificacionesHtmlPegado.Convertir("<p>inicio <b title='mayor > menor'>fuerte<i>cursiva</p><p>fin<!-- sin cierre");
        Exige(htmlIncompleto.Texto == "inicio fuertecursiva\nfin" && GruposEquilibrados(htmlIncompleto.Rtf),
            "El HTML incompleto debe cerrar estilos de forma segura y respetar comillas en atributos.");
        string anidado = new StringBuilder().Insert(0, "<span>", 257).Append('x').ToString();
        bool limitado = false;
        try { MYGEspecificacionesHtmlPegado.Convertir(anidado); }
        catch (ArgumentException) { limitado = true; }
        Exige(limitado, "El pegado debe limitar el anidamiento de HTML externo.");
        pasa("Pegado HTML tolera etiquetas incompletas y comillas, y limita el anidamiento externo");
    }

    private static bool GruposEquilibrados(string rtf)
    {
        int profundidad = 0;
        for (int i = 0; i < rtf.Length; i++)
        {
            if (rtf[i] == '\\' && i + 1 < rtf.Length && rtf[i + 1] is '\\' or '{' or '}') { i++; continue; }
            if (rtf[i] == '{') profundidad++;
            if (rtf[i] == '}' && --profundidad < 0) return false;
        }
        return profundidad == 0;
    }
}
