using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using MYG_2027;

static class RendimientoCalculoCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidOperationException) { return; }
        catch (InvalidDataException) { return; }
        throw new Exception("El cálculo aceptó una edición/datos inválidos.");
    }

    internal static MYGPresupuestoDocumento AltaCardinalidad(int numero)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "PERFIL ALTA CARDINALIDAD", Item = "01" };
        p.Items.Add(new() { Id = "T", IdLocalMYG = "T", Item = "01", TipoPropuesta = "TITULO", Descripcion = "TÍTULO" });
        for (int n = 0; n < numero; n++)
        {
            var i = new ItemPresupuestoDelphin { Id = "P" + n, IdLocalMYG = "P" + n, ParentId = "T", Item = "01." + n,
                TipoPropuesta = "PARTIDA", Descripcion = "PARTIDA " + n, Unidad = "m2" };
            i.Costos.Cantidad = 10.25m;
            for (int l = 0; l < 12; l++)
            {
                string clave = "R" + n + ":" + l;
                p.Costos.Insumos.Add(new() { Id = clave, Codigo = clave, Descripcion = clave, Unidad = "und",
                    Grupo = MYGGrupoRecurso.Materiales, Precio = (l + 1) / 3m });
                i.Costos.Analisis.Add(new() { Id = clave, InsumoId = clave, Grupo = MYGGrupoRecurso.Materiales,
                    Cantidad = (l + 1) / 7m, DesperdicioPorcentaje = l / 3m });
            }
            p.Items.Add(i);
        }
        p.Costos.GastosGeneralesPorcentaje = 10; p.Costos.UtilidadPorcentaje = 10; p.Costos.ImpuestoPorcentaje = 18;
        return p;
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var p = AltaCardinalidad(400);
        MYGProyectoStorage.ValidarPresupuesto(p);
        var calculo = MYGMotorPresupuestos.CrearCalculo(p);
        var resumen = calculo.Resumen(); var filas = calculo.Consolidar();
        // Huella capturada ejecutando el motor anterior, con los mismos 400
        // análisis y 4800 insumos distintos, antes de esta optimización.
        string huella = Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(filas)));
        Exige(huella == "CBD347AE0E217F8C70A8347055EDAD5E218A20613CEAC91B272A7438136B86E5" &&
            filas.Count == 4801 && filas.Sum(x => x.Total) == 130420m && filas.Sum(x => x.Cantidad) == 46793.91m,
            "El consolidado cambió datos, agrupación u orden respecto al motor original.");
        Exige(resumen.CostoDirecto == 130420m && calculo.TotalPartida(p.Items[0]) == resumen.CostoDirecto &&
            resumen.GastosGenerales == 13042m && resumen.Utilidad == 13042m && resumen.Subtotal == 156504m &&
            resumen.Impuesto == 28170.72m && resumen.Total == 184674.72m,
            "El cálculo compartido cambió totales o redondeos del presupuesto grande.");
        var incidencia = MYGPiePresupuesto.Incidencia(new[] { calculo });
        Exige(incidencia.Sum(x => x.Importe) == resumen.CostoDirecto && incidencia.Single(x => x.Nombre == "MATERIALES").Porcentaje == 100m &&
            Firma(MYGPiePresupuesto.Resumen(new[] { calculo })) == Firma(resumen),
            "El pie compartido no concilia incidencia y resumen.");
        pasa("400 partidas y 4800 insumos conservan la huella completa del consolidado anterior, redondeos, títulos, resumen e incidencia");

        var partida = p.Items[^1]; decimal antes = partida.Costos.Cantidad; int llamadas = 0;
        MYGEdicionPartida.CambiarCantidad(p, partida, 12.34m, () =>
        {
            llamadas++; Exige(partida.Costos.Cantidad == antes, "El historial se captura después de aplicar la cantidad.");
        });
        Exige(llamadas == 1 && partida.Costos.Cantidad == 12.34m &&
            MYGMotorPresupuestos.CrearCalculo(p).Resumen().CostoDirecto == 130486.49m &&
            calculo.Resumen().CostoDirecto == 130420m,
            "No se creó una sesión nueva tras editar o el callback se repitió.");
        string firma = Firma(p);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(p, partida, -1, () => llamadas++));
        Exige(llamadas == 1 && Firma(p) == firma, "Una edición inválida creó historial o modificó el presupuesto.");
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(p, partida, 13, () => throw new InvalidOperationException("Historial rechazado")));
        Exige(Firma(p) == firma, "Un error al preparar el historial dejó una edición parcial.");
        MYGEdicionPartida.CambiarUnidad(p, partida, "m3", () => { llamadas++; Exige(partida.Unidad == "m2", "El historial de unidad se capturó tarde."); });
        Exige(llamadas == 2 && partida.Unidad == "m3", "Cambiar unidad no capturó el historial una sola vez.");
        pasa("Edición validada captura historial una vez antes de aplicar; cantidades inválidas y fallos del historial son atómicos; otra sesión recalcula la edición");

        // Se calculan primero las hojas y luego sus padres: compartir resultados
        // no puede ocultar una cadena de subpartidas de más de 64 niveles.
        var cadena = new MYGPresupuestoDocumento { Nombre = "SUBANÁLISIS" };
        ItemPresupuestoDelphin hijo = null;
        for (int n = 0; n < 65; n++)
        {
            var i = new ItemPresupuestoDelphin { Id = "S" + n, IdLocalMYG = "S" + n, TipoPropuesta = "PARTIDA", Descripcion = "SUB " + n, Unidad = "und" };
            i.Costos.PrecioDirecto = 1;
            if (hijo != null) i.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = hijo.IdLocalMYG, Cantidad = 1 });
            cadena.Items.Add(i); hijo = i;
        }
        var subanalisis = MYGMotorPresupuestos.CrearCalculo(cadena);
        foreach (var i in cadena.Items.Take(64)) Exige(subanalisis.Analizar(i).PrecioUnitario == 1, "Se rechazó una cadena de 64 subpartidas.");
        Rechaza(() => subanalisis.Analizar(cadena.Items[^1]));
        Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(cadena));
        var ciclo = AltaCardinalidad(1); var circular = ciclo.Items[1];
        circular.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = circular.IdLocalMYG });
        Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(ciclo));
        var ausente = AltaCardinalidad(1); ausente.Items[1].Costos.Analisis[0].InsumoId = "INEXISTENTE";
        Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(ausente));
        var grupo = AltaCardinalidad(1); grupo.Items[1].Costos.Analisis[0].Grupo = MYGGrupoRecurso.Equipo;
        Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(grupo));
        pasa("Índices y caché temporal siguen rechazando insumos ausentes/grupos incompatibles, ciclos y cadenas de 65 niveles aun calculando primero las hojas");

        // Una firma importada y un parcial nativo no se pierden al reutilizar
        // ACU/total dentro del mismo refresco; editar precio invalida otra sesión.
        var importado = AltaCardinalidad(1); var oficial = importado.Items[1];
        MYGMotorPresupuestos.CapturarPrecioDelphin(importado, oficial, 32.01m, 328.11m);
        string firmaImportada = oficial.Costos.FirmaAnalisisImportadoDelphin;
        var original = MYGMotorPresupuestos.CrearCalculo(importado);
        Exige(original.Analizar(oficial).PrecioUnitario == 32.01m && original.TotalPartida(oficial) == 328.11m,
            "La sesión descartó precio/parcial importado de Delphin.");
        MYGEdicionPartida.CambiarCantidad(importado, oficial, 11);
        var editado = MYGMotorPresupuestos.CrearCalculo(importado);
        Exige(editado.TotalPartida(oficial) == 352.11m && editado.Analizar(oficial).PrecioUnitario == 32.01m &&
            oficial.Costos.FirmaAnalisisImportadoDelphin == firmaImportada && MYGMotorPresupuestos.ConservaAnalisisDelphin(importado, oficial),
            "Editar cantidad alteró firma/precio nativo o reutilizó el parcial antiguo.");
        importado.Costos.Insumos[0].Precio += 1;
        Exige(!MYGMotorPresupuestos.ConservaAnalisisDelphin(importado, oficial) &&
            MYGMotorPresupuestos.CrearCalculo(importado).Analizar(oficial).PrecioUnitario != 32.01m,
            "Una sesión nueva reutilizó precios/firma obsoletos tras editar un recurso.");
        pasa("Firma ACU y parciales importados se conservan al cambiar cantidad; una sesión nueva detecta cambios de precio sin caché global");

        VerificarEquivalencia();
        pasa("63 combinaciones de precisión conservan byte por byte resultados y firmas del motor anterior: rendimiento, porcentaje MO, desperdicio, subpartidas, metrado e importación");
    }

    private static void VerificarEquivalencia()
    {
        // La matriz se ejecutó también con MotorPresupuestos.cs de HEAD antes
        // de cambiarlo; su JSON completo fija la huella como oráculo externo.
        var resultados = new List<object>();
        for (int precision = 0; precision <= 6; precision++)
        for (int coeficiente = 0; coeficiente <= 8; coeficiente++)
        {
            var p = new MYGPresupuestoDocumento { Id = "P", IdPresupuestoRevit = "P", Nombre = "SEMÁNTICA", Item = "01" };
            p.Costos.DecimalesPrecio = precision; p.Costos.DecimalesCantidad = coeficiente;
            p.Costos.GastosGeneralesPorcentaje = 11.1234m; p.Costos.UtilidadPorcentaje = 10.17m;
            p.Costos.ImpuestoPorcentaje = 18; p.Costos.OtrosImpuestosPorcentaje = 0.0123m;
            p.Items.Add(new() { Id = "T", IdLocalMYG = "T", TipoPropuesta = "TITULO", Item = "01", Descripcion = "TÍTULO" });
            p.Items.Add(new() { Id = "TT", IdLocalMYG = "TT", ParentId = "T", TipoPropuesta = "TITULO", Item = "01.01", Descripcion = "SUBTÍTULO" });
            var baseSub = new ItemPresupuestoDelphin { Id = "SUB", IdLocalMYG = "SUB", ParentId = "TT", TipoPropuesta = "PARTIDA", Descripcion = "DIRECTA", Unidad = "und", Item = "01.01.01" };
            baseSub.Costos.PrecioDirecto = 987.654m; baseSub.Costos.Cantidad = 1.38742m; p.Items.Add(baseSub);
            for (int grupo = 0; grupo < 4; grupo++)
            for (int n = 0; n < 2; n++)
            {
                string id = "R" + grupo + n;
                p.Costos.Insumos.Add(new() { Id = id, Codigo = id, Descripcion = id, Unidad = "und", Grupo = (MYGGrupoRecurso)grupo,
                    Precio = (grupo + 1) * 17.45321m + n * 10.2777m });
            }
            for (int n = 0; n < 20; n++)
            {
                var i = new ItemPresupuestoDelphin { Id = "I" + n, IdLocalMYG = "I" + n, ParentId = n % 2 == 0 ? "TT" : "T",
                    Item = "01." + n, TipoPropuesta = "PARTIDA", Descripcion = "MIXTA " + n, Unidad = "und" };
                var d = i.Costos; d.Cantidad = 4.3745m + n * 0.01m; d.RendimientoDiario = 2.71m; d.JornadaHoras = 7.33m;
                d.FuenteMetrado = (MYGFuenteMetrado)(n % 4);
                d.Metrados.Add(new() { Elementos = 2.134m, CantidadPorElemento = 3.44m, Largo = 0.137m, Ancho = 2.535m });
                d.Metrados.Add(new() { Descuento = true, Elementos = 0.1m, CantidadPorElemento = 0.2m });
                d.MetradosBIM.Add(new() { ActivoId = "BIM", Cantidad = 1.312354m, Unidad = "und" });
                d.Hoja.Poner("G16", "2.3456789");
                d.Analisis.Add(new() { Id = i.Id + "MO0", Grupo = MYGGrupoRecurso.ManoObra, InsumoId = "R00", Modo = MYGModoCantidad.Rendimiento, NumeroRecursos = 2.123m, DesperdicioPorcentaje = 1.7m });
                d.Analisis.Add(new() { Id = i.Id + "MO1", Grupo = MYGGrupoRecurso.ManoObra, InsumoId = "R01", Cantidad = 0.1m });
                d.Analisis.Add(new() { Id = i.Id + "MA", Grupo = MYGGrupoRecurso.Materiales, InsumoId = "R10", Cantidad = 0.312123123m, DesperdicioPorcentaje = 2.7m });
                d.Analisis.Add(new() { Id = i.Id + "EQ", Grupo = MYGGrupoRecurso.Equipo, InsumoId = "R20", Cantidad = 0.03123m });
                d.Analisis.Add(new() { Id = i.Id + "EQMO", Grupo = MYGGrupoRecurso.Equipo, InsumoId = "R21", Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 3.63m, DesperdicioPorcentaje = 0.1m });
                d.Analisis.Add(new() { Id = i.Id + "SC", Grupo = MYGGrupoRecurso.Subcontratos, InsumoId = "R30", Cantidad = 0.0345m });
                d.Analisis.Add(new() { Id = i.Id + "SUB", Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = "SUB", Cantidad = 0.00033m });
                p.Items.Add(i);
            }
            for (int n = 3; n < p.Items.Count; n += 3)
            {
                var i = p.Items[n]; var a = MYGMotorPresupuestos.Analizar(p, i); var q = MYGMotorPresupuestos.Cantidad(p, i);
                MYGMotorPresupuestos.CapturarPrecioDelphin(p, i, a.PrecioUnitario + 0.0123m, MYGMotorPresupuestos.Dinero(p, q * a.PrecioUnitario) + 0.0345m);
            }
            MYGProyectoStorage.ValidarPresupuesto(p); MYGMotorPresupuestos.CapturarPresupuestoDelphin(p);
            var antes = new { Analisis = p.Items.Select(i => MYGMotorPresupuestos.FirmaAnalisis(p, i)).ToArray(), TotalPartidas = p.Items.Select(i => MYGMotorPresupuestos.TotalPartida(p,i)).ToArray(),
                Resumen = MYGMotorPresupuestos.Resumen(p), Consolidado = MYGMotorPresupuestos.Consolidar(p), Seleccion = MYGMotorPresupuestos.Consolidar(p, p.Items[5]),
                Incidencia = MYGPiePresupuesto.Incidencia(new[] { p }), Conserva = MYGMotorPresupuestos.ConservaPresupuestoDelphin(p) };
            MYGEdicionPartida.CambiarCantidad(p, p.Items[3], 3.15m);
            var despues = new { TotalPartidas = p.Items.Select(i => MYGMotorPresupuestos.TotalPartida(p,i)).ToArray(), Resumen = MYGMotorPresupuestos.Resumen(p),
                Consolidado = MYGMotorPresupuestos.Consolidar(p), Incidencia = MYGPiePresupuesto.Incidencia(new[] { p }), Conserva = MYGMotorPresupuestos.ConservaPresupuestoDelphin(p) };
            resultados.Add(new { precision, coeficiente, antes, despues });
        }

        string huella = Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(resultados)));
        Exige(huella == "3780B0E36E17EA17DA844CAE195262BF4449D4F56BBBB67F23B703321D867608",
            "Cambió el resultado o la firma de una combinación de precisión/modo/importación respecto al motor anterior.");
    }
}
