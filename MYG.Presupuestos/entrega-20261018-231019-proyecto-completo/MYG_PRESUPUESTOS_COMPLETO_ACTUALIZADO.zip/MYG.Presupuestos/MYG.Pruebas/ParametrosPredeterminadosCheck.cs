using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG_2027;

internal static class ParametrosPredeterminadosCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Json(object valor) => JsonSerializer.Serialize(valor);
    private static string Huella(object valor) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Json(valor))));
    private static void Rechaza(Action accion, string mensaje)
    { try { accion(); } catch (InvalidDataException) { return; } throw new Exception(mensaje); }

    internal static void VerificarOtraEjecucion(string ruta, string huella)
    {
        MYGParametrosUsuario.RutaAlternativaPruebas = ruta;
        Exige(Huella(MYGParametrosUsuario.Leer()) == huella,
            "Los parámetros no se conservaron después de iniciar otro proceso.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "parametros", "usuario.json");
        string anterior = MYGParametrosUsuario.RutaAlternativaPruebas;
        MYGParametrosUsuario.RutaAlternativaPruebas = ruta;
        try
        {
            Predeterminados(ruta, pasa);
            Persistencia(ruta, pasa);
            Rechazos(ruta, pasa);
            ArchivosInvalidos(carpeta, pasa);
            AplicacionPresupuesto(pasa);
            TotalesEnReportes(carpeta, pasa);
            AplicacionPartidasInsumos(pasa);
            Aceros(pasa);
            AislamientoDocumentos(ruta, carpeta, pasa);
        }
        finally { MYGParametrosUsuario.RutaAlternativaPruebas = anterior; }
    }

    private static void Predeterminados(string ruta, Action<string> pasa)
    {
        var a = MYGParametrosUsuario.Leer(); var b = MYGParametrosUsuario.Leer(); a.Validar();
        Exige(!File.Exists(ruta) && a.GastosGeneralesPorcentaje == 12 && a.UtilidadPorcentaje == 10 &&
            a.ImpuestoPorcentaje == 18 && a.Aceros.Count == 21 && a.DivisionPolitica.Count == 4 && a.ColoresNiveles.Count == 10,
            "La lectura inicial debe devolver los valores de referencia sin crear archivos.");
        a.Aceros[0].PesoPorMetro = 9; a.DivisionPolitica[0].Nombre = "Región"; a.ColoresNiveles[0] = "123456";
        Exige(b.Aceros[0].PesoPorMetro == .099m && b.DivisionPolitica[0].Nombre == "Departamento" && b.ColoresNiveles[0] == "BD353E",
            "Las lecturas iniciales comparten listas o filas mutables.");
        pasa("Parámetros iniciales completos y aislados; consultar preferencias no crea archivos");
    }

    private static void Persistencia(string ruta, Action<string> pasa)
    {
        var origen = new MYGParametrosPredeterminados { Moneda = "€", NombreMoneda = "Euro", NombreComercial = "Empresa de prueba",
            DecimalesPrecio = 3, OtrosGastosPorcentaje = 2.1234m };
        origen.DivisionPolitica[0].Nombre = "Región"; origen.Aceros[0].PesoPorMetro = .105m;
        MYGParametrosUsuario.Guardar(origen);
        var primera = MYGParametrosUsuario.Leer();
        Exige(File.Exists(ruta) && Huella(origen) == Huella(primera) && Directory.GetFiles(Path.GetDirectoryName(ruta), "*.tmp").Length == 0,
            "El archivo persistente perdió datos o dejó temporales.");
        primera.Moneda = "$"; primera.Aceros[0].PesoPorMetro = 99;
        var segunda = MYGParametrosUsuario.Leer(ruta);
        Exige(segunda.Moneda == "€" && segunda.Aceros[0].PesoPorMetro == .105m && origen.Aceros[0].PesoPorMetro == .105m,
            "Editar el resultado de una lectura alteró el archivo o la configuración original.");
        var copia = origen.Copia(); copia.DivisionPolitica[0].Nombre = "Cambio"; copia.ColoresNiveles.Clear();
        Exige(origen.DivisionPolitica[0].Nombre == "Región" && origen.ColoresNiveles.Count == 10,
            "Copia debe aislar los objetos anidados.");
        var inicio = new ProcessStartInfo { FileName = Environment.ProcessPath, RedirectStandardOutput = true,
            RedirectStandardError = true, UseShellExecute = false };
        if (string.Equals(Path.GetFileNameWithoutExtension(Environment.ProcessPath), "dotnet", StringComparison.OrdinalIgnoreCase))
            inicio.ArgumentList.Add(Assembly.GetExecutingAssembly().Location);
        inicio.ArgumentList.Add("--verificar-parametros"); inicio.ArgumentList.Add(ruta); inicio.ArgumentList.Add(Huella(origen));
        using var proceso = Process.Start(inicio);
        if (!proceso.WaitForExit(15000)) { proceso.Kill(true); throw new Exception("La verificación independiente de parámetros no terminó."); }
        Exige(proceso.ExitCode == 0, "Otro proceso no pudo recuperar las preferencias: " + proceso.StandardError.ReadToEnd());
        pasa("Guardar y abrir parámetros desde otro proceso conserva valores y crea copias independientes");
    }

    private static void Rechazos(string ruta, Action<string> pasa)
    {
        byte[] antes = File.ReadAllBytes(ruta);
        var original = MYGParametrosUsuario.Leer();
        foreach (var cambiar in new Action<MYGParametrosPredeterminados>[]
        {
            p => p.DecimalesPrecio = 7, p => p.DecimalesCantidad = 9, p => p.GastosGeneralesPorcentaje = -.1m,
            p => p.ImpuestoPorcentaje = 1.12345m, p => p.JornadaHoras = 25, p => p.Rendimiento = 0,
            p => p.PeriodoRendimiento = "Semana", p => p.AbreviaturaGastosGenerales = "CD",
            p => p.AbreviaturaOtrosGastos = "gg", p => p.AbreviaturaOtrosGastos = "sin espacios",
            p => p.Aceros[0].PesoPorMetro = 0, p => p.Aceros[0].Gancho = -1,
            p => p.Aceros[1].Diametro = p.Aceros[0].Diametro, p => p.DivisionPolitica.RemoveAt(0),
            p => p.ColoresNiveles[0] = "azul", p => p.ColoresNiveles.Clear(), p => p.LogoBase64 = "no es base64",
            p => p.LogoBase64 = Convert.ToBase64String(Encoding.UTF8.GetBytes("texto")),
            p => p.NombreComercial = "empresa\ninválida", p => p.VersionEsquema = 2,
            p => p.IndiceGastosGenerales = "índice sin conexión"
        })
        {
            var invalido = original.Copia(); cambiar(invalido);
            Rechaza(() => MYGParametrosUsuario.Guardar(invalido), "Se guardaron parámetros inválidos.");
            Exige(File.ReadAllBytes(ruta).SequenceEqual(antes), "El rechazo cambió preferencias válidas guardadas.");
        }
        var logoGrande = original.Copia(); byte[] imagen = new byte[2 * 1024 * 1024 + 1];
        new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }.CopyTo(imagen, 0);
        logoGrande.LogoBase64 = Convert.ToBase64String(imagen);
        Rechaza(() => MYGParametrosUsuario.Guardar(logoGrande), "Se permitió un logo de más de 2 MB.");
        Exige(Directory.GetFiles(Path.GetDirectoryName(ruta), "*.tmp").Length == 0, "Un rechazo dejó un archivo temporal.");
        pasa("Validación de precisión, porcentajes, referencias, colores y logo rechaza errores sin cambiar el archivo anterior");
    }

    private static void ArchivosInvalidos(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "parametros-invalido.json");
        foreach (string contenido in new[] { "{json inválido", "null", "{\"schemaVersion\":2}", "{\"campoDesconocido\":true}" })
        {
            File.WriteAllText(ruta, contenido);
            Rechaza(() => MYGParametrosUsuario.Leer(ruta), "Se ocultó un archivo inválido devolviendo valores iniciales.");
            Rechaza(() => MYGParametrosUsuario.Guardar(new(), ruta), "Se sustituyó silenciosamente un archivo dañado.");
            Exige(File.ReadAllText(ruta) == contenido, "El archivo inválido debía conservarse para revisión.");
        }
        using (var archivo = new FileStream(ruta, FileMode.Create)) archivo.SetLength(4 * 1024 * 1024 + 1);
        Rechaza(() => MYGParametrosUsuario.Leer(ruta), "Se aceptó un archivo de preferencias excesivo.");
        pasa("Archivos dañados, futuros o excesivos se informan y conservan sin sobrescritura silenciosa");
    }

    private static void AplicacionPresupuesto(Action<string> pasa)
    {
        var config = new MYGParametrosPredeterminados { GastosGeneralesPorcentaje = 12, OtrosGastosPorcentaje = 3,
            UtilidadPorcentaje = 10, ImpuestoRentaPorcentaje = 20, ImpuestoPorcentaje = 18, OtrosImpuestosPorcentaje = 2,
            NombreGastosGenerales = "Administración", NombreOtrosGastos = "Seguros", NombreImpuestoRenta = "Renta de prueba",
            AbreviaturaGastosGenerales = "GG_A", AbreviaturaOtrosGastos = "OG_A", Moneda = "US$" };
        var doc = MYGProyectoStorage.Nuevo("PREFERENCIAS", "PRESUPUESTO"); var p = doc.Presupuestos[0];
        config.Aplicar(p); var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        partida.Costos.Cantidad = 2; partida.Costos.PrecioDirecto = 50;
        var filas = MYGPiePresupuesto.Filas(new[] { p });
        decimal Importe(string id) => filas.Single(f => f.Id == "parametros:" + id).Importe;
        Exige(p.Costos.Moneda == "US$" && Importe("gg") == 12 && Importe("og") == 3 && Importe("ut") == 10 &&
            Importe("ir") == 2 && Importe("igv") == 22.5m && Importe("oi") == 2.5m && MYGMotorPresupuestos.Resumen(p).Total == 152,
            "El pie no calculó GG/OG/utilidad sobre CD, renta sobre utilidad e impuestos sobre el subtotal.");
        Exige(filas.Single(f => f.Id == "parametros:gg").Nombre == "Administración" &&
            filas.Single(f => f.Id == "parametros:og").Nombre == "Seguros", "No se vincularon las denominaciones configuradas.");
        var otro = new MYGPresupuestoDocumento { Nombre = "OTRO", Item = "02", Posicion = 2 }; config.Aplicar(otro);
        Exige(otro.Costos.PiePersonalizado.Select(f => f.Id).SequenceEqual(p.Costos.PiePersonalizado.Select(f => f.Id)),
            "Los conceptos predeterminados necesitan identidades compartidas para combinar los resúmenes.");
        otro.Costos.PiePersonalizado[0].Nombre = "Otro";
        Exige(p.Costos.PiePersonalizado[0].Nombre == "Administración", "Dos presupuestos comparten filas mutables.");
        pasa("Parámetros crean un pie funcional con nombres propios, renta sobre utilidad e impuestos sobre subtotal sin duplicar conceptos");
    }

    private static void AplicacionPartidasInsumos(Action<string> pasa)
    {
        var config = new MYGParametrosPredeterminados { PeriodoRendimiento = "Hora", Rendimiento = 3.5m, JornadaHoras = 6,
            UnidadPartida = "m²", UnidadInsumo = "kg", Proveedor = "Proveedor de prueba" };
        var partida = new ItemPresupuestoDelphin { TipoPropuesta = "PARTIDA", Unidad = "und" }; config.Aplicar(partida);
        Exige(partida.Unidad == "m²" && partida.Costos.RendimientoDiario == 21 && partida.Costos.JornadaHoras == 6,
            "El rendimiento horario debe convertirse a diario para el motor actual.");
        var titulo = new ItemPresupuestoDelphin { TipoPropuesta = "TITULO", Unidad = "" }; string antes = Json(titulo); config.Aplicar(titulo);
        Exige(Json(titulo) == antes, "La configuración de partidas no debe modificar títulos.");
        var insumo = new MYGInsumo { Descripcion = "Acero", Precio = 5 }; config.Aplicar(insumo);
        Exige(insumo.Unidad == "kg" && insumo.Proveedor == "Proveedor de prueba" && insumo.Precio == 5,
            "La aplicación de preferencias de insumo alteró su precio o no copió unidad/proveedor.");
        config.PeriodoRendimiento = "Día"; config.Aplicar(partida);
        Exige(partida.Costos.RendimientoDiario == 3.5m, "El rendimiento diario no debe multiplicarse por la jornada.");
        pasa("Partidas e insumos nuevos reciben unidades y proveedor; rendimiento por hora se convierte para el cálculo existente");
    }

    private static void TotalesEnReportes(string carpeta, Action<string> pasa)
    {
        var config = new MYGParametrosPredeterminados { GastosGeneralesPorcentaje = 12, OtrosGastosPorcentaje = 3,
            UtilidadPorcentaje = 10, ImpuestoRentaPorcentaje = 20, ImpuestoPorcentaje = 18, OtrosImpuestosPorcentaje = 2 };
        var doc = MYGProyectoStorage.Nuevo("TOTALES CON PARÁMETROS", "PRIMERO");
        var primero = doc.Presupuestos[0]; config.Aplicar(primero);
        var partida = MYGEstructuraPresupuestos.InsertarNodo(primero, false);
        partida.Costos.Cantidad = 2; partida.Costos.PrecioDirecto = 50;
        Exige(primero.Costos.MostrarTotalPiePersonalizado && MYGProyectoStorage.Copia(primero).Costos.MostrarTotalPiePersonalizado &&
            !Json(new MYGCostosPresupuesto()).Contains("MostrarTotalPiePersonalizado", StringComparison.Ordinal),
            "La opción de total debe conservarse por copia y omitirse en documentos históricos.");
        var jsonReabierto = JsonSerializer.Deserialize<MYGPresupuestoDocumento>(Json(primero));
        Exige(jsonReabierto.Costos.MostrarTotalPiePersonalizado,
            "La opción de total se perdió en el intercambio JSON del presupuesto.");
        var conFirma = MYGProyectoStorage.Copia(primero);
        MYGMotorPresupuestos.CapturarPresupuestoDelphin(conFirma);
        Exige(MYGMotorPresupuestos.ConservaPresupuestoDelphin(conFirma), "La firma inicial no reconoce el presupuesto con total visible.");
        conFirma.Costos.MostrarTotalPiePersonalizado = false;
        Exige(!MYGMotorPresupuestos.ConservaPresupuestoDelphin(conFirma), "Cambiar la opción de total debe invalidar la firma del presupuesto.");
        MYGMotorPresupuestos.CapturarPresupuestoDelphin(conFirma);
        Exige(MYGMotorPresupuestos.ConservaPresupuestoDelphin(conFirma), "Los presupuestos sin la opción de total deben conservar su firma anterior.");
        static void TotalReporte(MYGHojaReporteProyecto reporte, decimal importe)
        {
            var hoja = reporte.Hoja; var calculo = new MYGHojaCalculo(hoja);
            int fila = MYGHojaCalculo.Coordenadas(hoja.CeldaTotal).Fila;
            Exige(hoja.CeldaTotal == "F" + fila && fila == hoja.Filas &&
                string.Equals(hoja.Celdas["B" + fila].Contenido, "Total", StringComparison.OrdinalIgnoreCase) &&
                calculo.Numero(hoja.CeldaTotal) == importe,
                "El último concepto y CeldaTotal del informe deben representar el total completo del presupuesto.");
        }
        TotalReporte(MYGReportesProyecto.Crear(doc, primero.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado).Single(), 152);
        TotalReporte(MYGReportesProyecto.CrearResumenPresupuesto(doc, primero.Id), 152);
        Exige(MYGPiePresupuesto.Filas(new[] { primero }).Last().Id == MYGPiePresupuesto.IdTotal &&
            MYGMotorPresupuestos.Resumen(primero).Total == 152,
            "Mostrar la fila total no debe volver a sumarla en el motor.");
        string ruta = Path.Combine(carpeta, "parametros-total.sqlite"); MYGProyectoStorage.Guardar(ruta, doc);
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, doc.Id);
        Exige(reabierto.Presupuestos[0].Costos.MostrarTotalPiePersonalizado,
            "La opción de total del pie se perdió al guardar y volver a abrir SQLite.");
        TotalReporte(MYGReportesProyecto.Crear(reabierto, primero.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado).Single(), 152);
        pasa("Presupuestos con parámetros muestran Total y CeldaTotal correctos en informes individuales, sin duplicar cálculo y tras reabrir SQLite");

        var segundo = MYGEstructuraPresupuestos.AgregarPresupuesto(doc); segundo.Nombre = "SEGUNDO"; config.Aplicar(segundo);
        var otraPartida = MYGEstructuraPresupuestos.InsertarNodo(segundo, false);
        otraPartida.Costos.Cantidad = 4; otraPartida.Costos.PrecioDirecto = 50;
        var filas = MYGPiePresupuesto.Filas(doc.Presupuestos);
        Exige(filas.Count(f => f.Id == MYGPiePresupuesto.IdTotal) == 1 && filas.Last().Importe == 456 &&
            MYGPiePresupuesto.Resumen(doc.Presupuestos).Total == 456,
            "Combinar presupuestos debe producir una sola fila Total con todos sus importes.");
        TotalReporte(MYGReportesProyecto.Crear(doc, primero.Id, MYGTipoReporteProyecto.HojaResumen).Single(), 456);
        var todos = MYGReportesProyecto.Crear(doc, primero.Id, MYGTipoReporteProyecto.TodosPresupuestos);
        TotalReporte(todos[0], 152); TotalReporte(todos[1], 304);
        var historico = MYGProyectoStorage.Copia(segundo); historico.Costos.MostrarTotalPiePersonalizado = false;
        Exige(MYGPiePresupuesto.Filas(new[] { historico }).All(f => f.Id != MYGPiePresupuesto.IdTotal),
            "Los pies personalizados históricos no deben adquirir una fila Total implícita.");
        var mixto = MYGPiePresupuesto.Filas(new[] { primero, historico });
        Exige(mixto.Last().Id == MYGPiePresupuesto.IdTotal && mixto.Last().Importe == 456,
            "Un alcance mixto debe incluir también el importe del presupuesto sin fila Total.");
        pasa("Resumen de varios presupuestos concilia un solo Total, informes completos conservan cada importe y pies históricos mantienen sus filas");
    }

    private static void Aceros(Action<string> pasa)
    {
        var config = new MYGParametrosPredeterminados(); var barra = config.Aceros.Single(a => a.Diametro == "3/8″");
        barra.PesoPorMetro = .6m; barra.Gancho = .2m; barra.Empalme = .5m; barra.DesperdicioPorcentaje = 5;
        var hoja = config.CrearHojaAcero(); var calculo = new MYGHojaCalculo(hoja);
        hoja.Celdas["D3"].Contenido = "3/8"; hoja.Celdas["B3"].Contenido = "2";
        hoja.Celdas["C3"].Contenido = "3"; hoja.Celdas["E3"].Contenido = "4";
        calculo = new(hoja);
        Exige(calculo.Numero("F3") == .2m && calculo.Numero("G3") == .5m && calculo.Numero("H3") == 5 &&
            calculo.Numero("AD16") == 17.766m,
            "La hoja de acero no usa los parámetros por diámetro al calcular longitud y peso.");
        hoja.Celdas["D3"].Contenido = "1/2″"; calculo = new(hoja);
        Exige(calculo.Numero("G3") == .5m && calculo.Numero("F3") == .25m && calculo.Numero("H3") == 5,
            "Cambiar diámetro debe actualizar automáticamente los valores iniciales de metrado.");
        config.UnidadAcero = "t"; var toneladas = config.CrearHojaAcero();
        toneladas.Celdas["D3"].Contenido = "3/8"; toneladas.Celdas["B3"].Contenido = "2";
        toneladas.Celdas["C3"].Contenido = "3"; toneladas.Celdas["E3"].Contenido = "4";
        Exige(new MYGHojaCalculo(toneladas).Numero("AD16") == .017766m && toneladas.Celdas["A16"].Contenido == "Peso Total (t)",
            "El peso total debe convertirse al seleccionar toneladas.");
        var otra = config.CrearHojaAcero(); otra.Celdas["I15"].Contenido = "99"; otra.Celdas["D3"].ListaValores.Clear();
        var canonica = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        Exige(hoja.Celdas["I15"].Contenido != "99" && hoja.Celdas["D3"].ListaValores.Count > 0 &&
            canonica.Celdas["T15"].Contenido == "0.580" && string.IsNullOrEmpty(canonica.Celdas["F3"].Contenido),
            "Crear hojas con preferencias debe aislar las celdas y conservar la plantilla canónica anterior.");
        pasa("Plantilla de acero vincula diámetro, peso, gancho, empalme y desperdicio; convierte toneladas y conserva hojas anteriores");
    }

    private static void AislamientoDocumentos(string ruta, string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("OBRA EXISTENTE", "HISTÓRICO");
        var p = doc.Presupuestos[0]; p.Costos.Moneda = "S/"; p.Costos.DecimalesPrecio = 2;
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false); partida.Costos.JornadaHoras = 7;
        partida.Costos.PrecioDirecto = 11.25m; partida.Costos.Cantidad = 3;
        string archivo = Path.Combine(carpeta, "presupuesto-previo.sqlite"); MYGProyectoStorage.Guardar(archivo, doc);
        byte[] antes = File.ReadAllBytes(archivo); string json = Json(doc);
        var config = MYGParametrosUsuario.Leer(ruta); config.Moneda = "US$"; config.JornadaHoras = 4;
        MYGParametrosUsuario.Guardar(config, ruta); var leido = MYGBaseDatos.LeerProyecto(archivo, doc.Id);
        Exige(File.ReadAllBytes(archivo).SequenceEqual(antes) && Json(doc) == json &&
            leido.Presupuestos[0].Costos.Moneda == "S/" && leido.Presupuestos[0].Items[0].Costos.JornadaHoras == 7 &&
            MYGMotorPresupuestos.Resumen(leido.Presupuestos[0]).Total == 33.75m,
            "Guardar preferencias alteró datos o cálculos de un proyecto existente.");
        pasa("Guardar preferencias y volver a abrir un presupuesto histórico conserva su archivo, moneda, jornada y total");
    }
}
