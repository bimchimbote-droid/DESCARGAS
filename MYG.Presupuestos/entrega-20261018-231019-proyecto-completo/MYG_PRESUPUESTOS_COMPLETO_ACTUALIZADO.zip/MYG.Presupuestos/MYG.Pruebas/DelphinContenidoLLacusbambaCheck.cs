using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinContenidoLLacusbambaCheck
{
    private sealed record Contenido(string Presupuesto, decimal Cantidad, string Rtf);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Environment.GetEnvironmentVariable("MYG_QA_LLACUSBAMBA_SQLITE");
        if (string.IsNullOrWhiteSpace(ruta))
        {
            Console.WriteLine("OMITIDA: contenido real LLACUSBAMBA (MYG_QA_LLACUSBAMBA_SQLITE no definido).");
            return;
        }
        Exige(File.Exists(ruta), "No existe MYG_QA_LLACUSBAMBA_SQLITE.");
        string antes = Huella(ruta);
        var esperado = LeerContenido(ruta);
        Exige(esperado.Count == 658 && esperado.Values.All(x => x.Cantidad > 0 && x.Rtf.StartsWith(@"{\rtf", StringComparison.Ordinal)),
            "La muestra LLACUSBAMBA no contiene las 658 cantidades y especificaciones RTF esperadas.");
        using (var c = Conexion(ruta))
        {
            using var cmd = c.CreateCommand();
            cmd.CommandText = "SELECT (SELECT COUNT(*) FROM metrado) + " +
                "(SELECT COUNT(*) FROM costo_unitario WHERE LENGTH(archivo_metrado)>0)";
            Exige(Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) == 0,
                "La muestra tiene un desglose de metrado distinto de las cantidades directas auditadas.");
        }

        var proyectos = MYGBaseDatos.ListarProyectos(ruta);
        Exige(proyectos.Count == 1, "La muestra LLACUSBAMBA debe contener un proyecto.");
        var documento = MYGBaseDatos.LeerProyecto(ruta, proyectos[0].Id);
        ComprobarContenido(documento, esperado);
        var datos = documento.Datos;
        Exige(datos.UsarUbicacion && datos.DepartamentoId == "02" && datos.Departamento == "ANCASH" &&
            datos.ProvinciaId == "0209" && datos.Provincia == "CORONGO" &&
            datos.DistritoId == "020905" && datos.Distrito == "LA PAMPA" &&
            datos.LocalidadId == "02090501" && datos.Localidad == "LLACUSBAMBA",
            "La ubicación nativa perdió identificadores o nombres al importarse.");
        Exige(datos.Duracion == 270 && datos.UnidadDuracion == "DIAS" &&
            datos.FechaInicio == new DateTime(2024, 12, 2) && datos.FechaFin == new DateTime(2025, 8, 28),
            "La lectura alteró las fechas o la duración nativa del proyecto.");
        Exige(Huella(ruta) == antes, "La consulta de cantidades, ubicación o RTF modificó la base del usuario.");
        pasa("LLACUSBAMBA: 658 cantidades directas y 658 RTF íntegros, ubicación y plazo nativos, sin inventar metrados");

        string destino = Path.Combine(carpeta, "Contenido completo LLACUSBAMBA.sqlite");
        MYGBaseDatos.GuardarProyecto(destino, documento, ruta);
        var reabierto = MYGBaseDatos.LeerProyecto(destino, documento.Id);
        ComprobarContenido(reabierto, esperado);
        var guardado = LeerContenido(destino);
        Exige(esperado.Count == guardado.Count && esperado.All(x => guardado.TryGetValue(x.Key, out var valor) && valor == x.Value),
            "Guardar como perdió cantidades o bytes de los RTF nativos.");
        Exige(Huella(ruta) == antes, "Guardar una copia de contenido modificó la base original.");
        pasa("LLACUSBAMBA: guardar como y reabrir conserva las 658 cantidades y especificaciones originales byte a byte");
    }

    private static void ComprobarContenido(MYGProyectoDocumento documento, Dictionary<string, Contenido> esperado)
    {
        var partidas = documento.Presupuestos.SelectMany(p => p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i))
            .Select(i => (Presupuesto: p, Item: i))).ToList();
        Exige(partidas.Count == esperado.Count, "La importación perdió partidas con cantidad y especificación.");
        foreach (var (p, i) in partidas)
        {
            Exige(esperado.TryGetValue(i.IdInternoDelphin, out var nativo), "Una partida perdió su identidad nativa.");
            Exige(p.Id == nativo.Presupuesto && i.Costos.Cantidad == nativo.Cantidad &&
                MYGMotorPresupuestos.Cantidad(p, i) == nativo.Cantidad,
                "Una cantidad directa nativa fue redondeada o reemplazada por cantidad_metrado vacía.");
            Exige(i.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad && i.Costos.Metrados.Count == 0 && i.Costos.MetradosBIM.Count == 0,
                "La muestra sin metrado detallado recibió filas o geometría no presentes en el SQLite.");
            Exige(i.Costos.EspecificacionRtf == nativo.Rtf &&
                Encoding.Latin1.GetBytes(i.Costos.EspecificacionRtf).SequenceEqual(Encoding.Latin1.GetBytes(nativo.Rtf)),
                "La especificación perdió contenido o codificación RTF al importarse.");
        }
    }

    private static Dictionary<string, Contenido> LeerContenido(string ruta)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT id_costounitario,id_presupuesto,cantidad,archivo_especificaciones " +
            "FROM costo_unitario WHERE id_unidad IS NOT NULL";
        using var r = cmd.ExecuteReader(); var filas = new Dictionary<string, Contenido>(StringComparer.OrdinalIgnoreCase);
        while (r.Read()) filas.Add(r.GetString(0), new Contenido(r.GetString(1), r.GetDecimal(2),
            r.IsDBNull(3) ? "" : Encoding.Latin1.GetString((byte[])r.GetValue(3))));
        return filas;
    }

    private static SqliteConnection Conexion(string ruta)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open(); return c;
    }

    private static string Huella(string ruta)
    {
        using var archivo = File.OpenRead(ruta);
        return Convert.ToHexString(SHA256.HashData(archivo));
    }

    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }
}
