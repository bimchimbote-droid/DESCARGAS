using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ReferenciasMetradoPartidasCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static ItemPresupuestoDelphin Nodo(string descripcion, int posicion)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = descripcion,
            Unidad = "m²", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = posicion
        };
    }

    private static (MYGProyectoDocumento Documento, MYGPresupuestoDocumento Presupuesto,
        ItemPresupuestoDelphin A, ItemPresupuestoDelphin B, ItemPresupuestoDelphin C) Nuevo()
    {
        var documento = MYGProyectoStorage.Nuevo("METRADOS RELACIONADOS", "ESTRUCTURAS");
        var presupuesto = documento.Presupuestos.Single();
        var a = Nodo("DESTINO", 1); var b = Nodo("ORIGEN", 2); var c = Nodo("ORIGEN INDIRECTO", 3);
        presupuesto.Items.AddRange(new[] { a, b, c });
        MYGProyectoStorage.Renumerar(presupuesto);
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        return (documento, presupuesto, a, b, c);
    }

    private static void Numero(MYGHojaMetrado hoja, string celda, decimal esperado, string mensaje)
    {
        decimal obtenido = new MYGHojaCalculo(hoja).Numero(celda);
        Exige(obtenido == esperado, mensaje + " Obtenido: " + obtenido + "; esperado: " + esperado + ".");
    }

    private static void Error(MYGHojaMetrado hoja, string celda, string mensaje, string esperado = "#REF!")
    {
        bool rechazado = false;
        try { new MYGHojaCalculo(hoja).Numero(celda); }
        catch (Exception ex) when (ex is FormatException or InvalidDataException or DivideByZeroException or OverflowException)
        { rechazado = true; }
        Exige(rechazado && new MYGHojaCalculo(hoja).Mostrar(celda) == esperado, mensaje);
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        VerificarFormulaYActualizacion(pasa);
        VerificarCadenaYCache(pasa);
        VerificarIdentidades(pasa);
        VerificarEstructuraOrigen(pasa);
        VerificarEdicionOrigenEnCopia(pasa);
        VerificarReferenciasAusentes(pasa);
        VerificarCiclosYRamas(pasa);
        VerificarValidacion(pasa);
        VerificarBorradorYConfirmacion(pasa);
        VerificarPersistencia(carpeta, pasa);
        VerificarCopias(pasa);
        VerificarExportacion(carpeta, pasa);
    }

    private static void VerificarFormulaYActualizacion(Action<string> pasa)
    {
        var (_, presupuesto, a, b, _) = Nuevo();
        b.Costos.Hoja.Poner("B3", "4");
        string referencia = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3");
        a.Costos.Hoja.Poner("B3", "=" + referencia + "*2+SUMA(C3:D3)");
        a.Costos.Hoja.Poner("C3", "2"); a.Costos.Hoja.Poner("D3", "3");
        a.Costos.Hoja.Poner(a.Costos.Hoja.CeldaTotal, "=B3"); a.Costos.PrecioDirecto = 10;
        string formula = a.Costos.Hoja.Celdas["B3"].Contenido;
        Numero(a.Costos.Hoja, "B3", 13, "La referencia de otra partida debe combinarse con aritmética y rangos locales.");
        Exige(MYGActualizacionMetradoHoja.Evaluar(presupuesto, a).TotalHoja == 13 &&
            MYGActualizacionMetradoHoja.Actualizar(presupuesto, a) &&
            MYGMotorPresupuestos.Cantidad(presupuesto, a) == 13 &&
            MYGMotorPresupuestos.TotalPartida(presupuesto, a) == 130,
            "Actualizar el destino debe usar el metrado relacionado para su cantidad y costo.");
        b.Costos.Hoja.Poner("B3", "5");
        Exige(MYGMotorPresupuestos.Cantidad(presupuesto, a) == 15 &&
            MYGMotorPresupuestos.TotalPartida(presupuesto, a) == 150 &&
            a.Costos.Cantidad == 13 && a.Costos.Hoja.Celdas["B3"].Contenido == formula,
            "Editar el origen debe recalcular el vínculo Excel del destino sin sustituir su fórmula ni su cantidad inicial almacenada.");
        b.Costos.Hoja.Poner("A3", "ZAPATA");
        a.Costos.Hoja.Poner("A3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "A3") + "&\" extra\"");
        var texto = new MYGHojaCalculo(a.Costos.Hoja); texto.ValidarResultado("A3");
        Exige(texto.Mostrar("A3") == "ZAPATA extra",
            "Una referencia de texto concatenada debe validarse y mostrarse sin forzarla a cantidad numérica.");
        pasa("Referenciar otra partida combina fórmulas y rangos locales y Actualizar recalcula cantidad e importe al editar el origen");
    }

    private static void VerificarCadenaYCache(Action<string> pasa)
    {
        var (documento, presupuesto, a, b, c) = Nuevo();
        c.Costos.Hoja.Poner("B3", "5");
        b.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(b.Costos.Hoja, presupuesto, c, "B3") + "*2");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3") + "+1");
        Numero(a.Costos.Hoja, "B3", 11, "La cadena A → B → C debe calcularse en una sesión compartida.");
        c.Costos.Hoja.Poner("B3", "7");
        Numero(a.Costos.Hoja, "B3", 15, "Una nueva evaluación no debe reutilizar el valor anterior de una dependencia indirecta.");
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        Numero(a.Costos.Hoja, "B3", 15, "Volver a vincular el documento no debe perder una cadena de referencias.");
        pasa("Referencias encadenadas entre tres metrados recalculan cambios indirectos sin conservar cachés de evaluaciones anteriores");
    }

    private static void VerificarIdentidades(Action<string> pasa)
    {
        var (documento, presupuesto, a, b, _) = Nuevo();
        var segundo = new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 };
        var mismaNumeracion = Nodo("ORIGEN", 1); segundo.Items.Add(mismaNumeracion);
        documento.Presupuestos.Add(segundo); MYGProyectoStorage.Renumerar(segundo);
        b.Costos.Hoja.Poner("B3", "6"); mismaNumeracion.Costos.Hoja.Poner("B3", "40");
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3") +
            "+" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, segundo, mismaNumeracion, "B3"));
        Numero(a.Costos.Hoja, "B3", 46, "Presupuestos con descripciones iguales deben conservar sus destinos distintos.");
        b.Posicion = 1; a.Posicion = 2; b.Descripcion = "ORIGEN RENOMBRADO";
        presupuesto.Nombre = "PRESUPUESTO RENOMBRADO"; segundo.Nombre = "OTRO NOMBRE";
        MYGProyectoStorage.Renumerar(presupuesto); MYGProyectoStorage.Renumerar(segundo);
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        Numero(a.Costos.Hoja, "B3", 46, "Renumerar y renombrar partidas o presupuestos no debe retargetear el vínculo.");
        pasa("Referencias distinguen partidas de diferentes presupuestos y conservan identidades después de renumerar y renombrar");
    }

    private static void VerificarEstructuraOrigen(Action<string> pasa)
    {
        var (documento, presupuesto, a, b, _) = Nuevo();
        b.Costos.Hoja.Poner("B3", "8");
        string referencia = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3");
        a.Costos.Hoja.Poner("B3", "=" + referencia);
        MYGEdicionHoja.InsertarFilas(b.Costos.Hoja, 3, 2);
        MYGEdicionHoja.InsertarColumnas(b.Costos.Hoja, 2);
        b.Costos.Hoja.Poner("B3", "999");
        b.Costos.Hoja.Poner("C5", "12");
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        Numero(a.Costos.Hoja, "B3", 12, "El vínculo debe seguir B3 hasta C5 al insertar filas y columnas de origen.");
        MYGEdicionHoja.EliminarFilas(b.Costos.Hoja, 3, 2);
        MYGEdicionHoja.EliminarColumnas(b.Costos.Hoja, 2);
        Numero(a.Costos.Hoja, "B3", 12, "Eliminar únicamente las filas y columnas insertadas debe devolver el ancla a B3.");
        MYGEdicionHoja.EliminarFilas(b.Costos.Hoja, 3);
        b.Costos.Hoja.Poner("B3", "1000");
        Error(a.Costos.Hoja, "B3", "Eliminar la fila referenciada debe mostrar un error aunque otra celda ocupe después B3.");

        var (_, p2, a2, b2, _) = Nuevo(); b2.Costos.Hoja.Poner("B3", "8");
        a2.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a2.Costos.Hoja, p2, b2, "B3"));
        MYGEdicionHoja.EliminarColumnas(b2.Costos.Hoja, 2);
        b2.Costos.Hoja.Poner("B3", "1000");
        Error(a2.Costos.Hoja, "B3", "Eliminar la columna referenciada no debe dirigir el vínculo a los datos que la reemplazan.");

        var (_, p3, a3, b3, _) = Nuevo();
        b3.Costos.Hoja.Poner("B3", "3"); b3.Costos.Hoja.Poner("B4", "4");
        a3.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a3.Costos.Hoja, p3, b3, "B3"));
        a3.Costos.Hoja.Poner("B4", "=" + MYGReferenciasMetrado.CrearReferencia(a3.Costos.Hoja, p3, b3, "B4"));
        MYGEdicionHoja.EliminarFilas(b3.Costos.Hoja, 3);
        Error(a3.Costos.Hoja, "B3", "La referencia eliminada no debe colisionar con una segunda referencia desplazada hasta su posición anterior.");
        Numero(a3.Costos.Hoja, "B4", 4, "La referencia al antiguo B4 debe seguir B3 aunque la referencia original a B3 se haya eliminado.");
        pasa("Referencias siguen celdas de origen al insertar filas/columnas y detectan la eliminación real sin tomar la celda sustituta");
    }

    private static void VerificarReferenciasAusentes(Action<string> pasa)
    {
        var (documento, presupuesto, a, b, _) = Nuevo();
        b.Costos.Hoja.Poner("B3", "8");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3"));
        presupuesto.Items.Remove(b); MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        Error(a.Costos.Hoja, "B3", "Una partida eliminada debe producir un error visible y nunca un metrado cero.");
        a.Costos.Hoja.Poner("B4", "=METRADO(\"referencia-inexistente\";\"B3\")");
        Error(a.Costos.Hoja, "B4", "Una fórmula con un alias inexistente no debe calcular silenciosamente cero.");
        a.Costos.Hoja.Poner("B5", "=SI.ERROR(B4;9)");
        Numero(a.Costos.Hoja, "B5", 9, "SI.ERROR debe permitir tratar expresamente un vínculo roto.");
        pasa("Partidas eliminadas y vínculos desconocidos muestran error en lugar de cero y admiten tratamiento explícito con SI.ERROR");
    }

    private static void VerificarEdicionOrigenEnCopia(Action<string> pasa)
    {
        var (documento, presupuesto, a, b, _) = Nuevo();
        b.Costos.Hoja.Poner("B3", "4");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3"));
        string formulaAntes = a.Costos.Hoja.Celdas["B3"].Contenido;
        string referenciasAntes = JsonSerializer.Serialize(a.Costos.Hoja.ReferenciasPartidas);
        string origenAntes = JsonSerializer.Serialize(b.Costos.Hoja);
        var copia = MYGProyectoStorage.Copia(b.Costos.Hoja);
        MYGEdicionHoja.InsertarFilas(copia, 3);
        Exige(a.Costos.Hoja.Celdas["B3"].Contenido == formulaAntes &&
            JsonSerializer.Serialize(a.Costos.Hoja.ReferenciasPartidas) == referenciasAntes &&
            JsonSerializer.Serialize(b.Costos.Hoja) == origenAntes,
            "Previsualizar una inserción en una copia de la hoja origen no debe modificar fórmulas ni referencias del proyecto.");
        Numero(a.Costos.Hoja, "B3", 4, "El vínculo del proyecto debe seguir usando el origen original durante la previsualización.");

        b.Costos.Hoja = copia; MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        MYGReferenciasMetrado.SincronizarOrigen(copia);
        Exige(a.Costos.Hoja.ReferenciasPartidas.Single().DireccionFormula == "B4" &&
            a.Costos.Hoja.Celdas["B3"].Contenido.Contains("\"B4\"", StringComparison.Ordinal) &&
            !a.Costos.Hoja.Celdas["B3"].Contenido.Contains("\"B3\"", StringComparison.Ordinal),
            "Confirmar la copia origen debe sincronizar tanto la dirección visible de la fórmula como el registro hacia B4.");
        Numero(a.Costos.Hoja, "B3", 4, "El vínculo confirmado debe conservar el valor de la celda desplazada.");
        copia.Poner("B3", "7");
        a.Costos.Hoja.Poner("B5", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3"));
        Numero(a.Costos.Hoja, "B3", 4, "Seleccionar de nuevo B3 no debe cambiar la referencia anterior que ahora apunta a B4.");
        Numero(a.Costos.Hoja, "B5", 7, "Una nueva selección de B3 debe referenciar su nuevo contenido y no reutilizar el ancla desplazada hasta B4.");
        Exige(a.Costos.Hoja.ReferenciasPartidas.Select(r => r.DireccionFormula).Order().SequenceEqual(new[] { "B3", "B4" }),
            "El destino debe guardar dos vínculos distintos para las celdas de origen B3 y B4 después de confirmar la copia.");

        // El editor también confirma copias al arrastrar una celda. Una hoja
        // simple evita la prohibición independiente de mover rangos parciales.
        var (d2, p2, a2, b2, _) = Nuevo();
        b2.Costos.Hoja = new MYGHojaMetrado { CeldaTotal = "G16", FilasInmovilizadas = 0 };
        b2.Costos.Hoja.Poner("B3", "5"); b2.Costos.Hoja.Poner("G16", "=B3");
        MYGReferenciasMetrado.Vincular(d2.Presupuestos);
        a2.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a2.Costos.Hoja, p2, b2, "B3"));
        formulaAntes = a2.Costos.Hoja.Celdas["B3"].Contenido;
        referenciasAntes = JsonSerializer.Serialize(a2.Costos.Hoja.ReferenciasPartidas);
        var movida = MYGProyectoStorage.Copia(b2.Costos.Hoja);
        MYGEdicionHoja.MoverRango(movida, "B3", "D5");
        Exige(a2.Costos.Hoja.Celdas["B3"].Contenido == formulaAntes &&
            JsonSerializer.Serialize(a2.Costos.Hoja.ReferenciasPartidas) == referenciasAntes,
            "Previsualizar un arrastre en una copia de origen debe dejar intacto el destino real.");
        b2.Costos.Hoja = movida; MYGReferenciasMetrado.Vincular(d2.Presupuestos);
        MYGReferenciasMetrado.SincronizarOrigen(movida);
        Exige(a2.Costos.Hoja.ReferenciasPartidas.Single().DireccionFormula == "D5" &&
            a2.Costos.Hoja.Celdas["B3"].Contenido.Contains("\"D5\"", StringComparison.Ordinal),
            "Confirmar un arrastre en una copia debe sincronizar el vínculo visible hacia la celda D5.");
        Numero(a2.Costos.Hoja, "B3", 5, "El vínculo debe seguir la celda de origen arrastrada después de confirmar.");
        pasa("Edición estructural y arrastre en copias de origen mantienen el proyecto intacto hasta confirmar y sincronizan fórmulas, registros y nuevas selecciones");
    }

    private static void VerificarCiclosYRamas(Action<string> pasa)
    {
        var (_, presupuesto, a, b, _) = Nuevo();
        string haciaB = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3");
        string haciaA = MYGReferenciasMetrado.CrearReferencia(b.Costos.Hoja, presupuesto, a, "B3");
        a.Costos.Hoja.Poner("B3", "=" + haciaB + "+1"); b.Costos.Hoja.Poner("B3", "=" + haciaA + "+1");
        Error(a.Costos.Hoja, "B3", "Un ciclo A → B → A debe detenerse con error en lugar de recursión infinita.", "#ERROR");
        a.Costos.Hoja.Poner("B3", "=SI(0;" + haciaB + ";7)");
        Numero(a.Costos.Hoja, "B3", 7, "SI no debe evaluar una dependencia circular en la rama no seleccionada.");
        Numero(b.Costos.Hoja, "B3", 8, "La evaluación de un ciclo rechazado no debe contaminar las evaluaciones válidas siguientes.");
        string propia = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, a, "B3");
        a.Costos.Hoja.Poner("B3", "=" + propia + "+1");
        Error(a.Costos.Hoja, "B3", "La autorreferencia mediante METRADO debe detectarse como circular.", "#ERROR");
        pasa("Referencias detectan ciclos y autorreferencias, respetan ramas diferidas de SI y permiten evaluar después de corregir un ciclo");
    }

    private static void VerificarValidacion(Action<string> pasa)
    {
        var (_, presupuesto, a, b, _) = Nuevo(); b.Costos.Hoja.Poner("B3", "4");
        string referencia = MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3");
        var entrada = MYGEdicionHoja.Celda(a.Costos.Hoja, "B3");
        entrada.TipoValidacion = "Entero"; entrada.Minimo = 0; entrada.Maximo = 10; entrada.Contenido = "3";
        MYGEdicionHoja.ValidarEntrada(a.Costos.Hoja, "B3", "=" + referencia + "*2");
        Exige(entrada.Contenido == "3", "Validar un vínculo en una copia temporal no debe modificar la celda editada.");
        b.Costos.Hoja.Poner("B3", "6"); bool rechazado = false;
        try { MYGEdicionHoja.ValidarEntrada(a.Costos.Hoja, "B3", "=" + referencia + "*2"); }
        catch (InvalidDataException) { rechazado = true; }
        Exige(rechazado && entrada.Contenido == "3", "La validación debe rechazar el resultado relacionado fuera de rango sin modificar la hoja.");
        pasa("Validación de celdas evalúa fórmulas relacionadas en una copia temporal y respeta límites sin modificar el documento");
    }

    private static void VerificarPersistencia(string carpeta, Action<string> pasa)
    {
        var (documento, presupuesto, a, b, _) = Nuevo(); b.Costos.Hoja.Poner("B3", "9");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3") + "*2");
        a.Costos.Hoja.Poner(a.Costos.Hoja.CeldaTotal, "=B3");
        MYGActualizacionMetradoHoja.Actualizar(presupuesto, a);
        MYGEdicionHoja.InsertarFilas(b.Costos.Hoja, 3); MYGEdicionHoja.InsertarColumnas(b.Costos.Hoja, 2);
        string json = Path.Combine(carpeta, "Metrados relacionados.myg.json");
        MYGProyectoStorage.Guardar(json, documento);
        foreach (string ruta in new[] { json, MYGBaseDatos.RutaDeProyecto(json) })
        {
            var reabierto = MYGProyectoStorage.Leer(ruta); MYGReferenciasMetrado.Vincular(reabierto.Presupuestos);
            var p = reabierto.Presupuestos.Single(); var destino = p.Items.Single(x => x.Id == a.Id);
            var origen = p.Items.Single(x => x.Id == b.Id);
            Numero(destino.Costos.Hoja, "B3", 18, "Guardar y abrir debe conservar referencias y anclas desplazadas: " + Path.GetExtension(ruta));
            origen.Costos.Hoja.Poner("C4", "10");
            Exige(MYGMotorPresupuestos.Cantidad(p, destino) == 20,
                "El vínculo cargado debe recalcular el metrado tras editar la celda de origen desplazada.");
        }
        var copia = MYGProyectoStorage.Copia(documento); MYGReferenciasMetrado.Vincular(copia.Presupuestos);
        Numero(copia.Presupuestos.Single().Items.Single(x => x.Id == a.Id).Costos.Hoja, "B3", 18,
            "Una copia JSON del documento debe conservar referencias sin serializar el contexto de cálculo runtime.");
        pasa("Guardar y abrir JSON/SQLite y copiar el proyecto conservan vínculos activos y anclas desplazadas que siguen recalculando");
    }

    private static void VerificarBorradorYConfirmacion(Action<string> pasa)
    {
        var (_, presupuesto, a, b, _) = Nuevo(); b.Costos.Hoja.Poner("B3", "4");
        string destinoAntes = JsonSerializer.Serialize(a.Costos.Hoja), origenAntes = JsonSerializer.Serialize(b.Costos.Hoja);
        var borrador = MYGProyectoStorage.Copia(a.Costos.Hoja);
        borrador.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(borrador, presupuesto, b, "B3") + "*2");
        Numero(borrador, "B3", 8, "La selección pendiente debe permitir previsualizar la fórmula antes de confirmar.");
        var segundoBorrador = MYGProyectoStorage.Copia(borrador);
        Numero(segundoBorrador, "B3", 8, "Una copia usada para validar el borrador debe conservar su referencia pendiente.");
        Exige(JsonSerializer.Serialize(a.Costos.Hoja) == destinoAntes && JsonSerializer.Serialize(b.Costos.Hoja) == origenAntes,
            "Elegir y previsualizar una celda de otra partida no debe modificar ninguna hoja del proyecto antes de confirmar.");
        MYGReferenciasMetrado.AplicarReferenciasPendientes(a.Costos.Hoja, segundoBorrador);
        a.Costos.Hoja.Poner("B3", segundoBorrador.Celdas["B3"].Contenido);
        Numero(a.Costos.Hoja, "B3", 8, "Confirmar debe convertir la selección pendiente en un vínculo persistente calculable.");
        Exige(a.Costos.Hoja.ReferenciasPartidas.Count == 1 && b.Costos.Hoja.AnclasReferencias.Count == 1,
            "Confirmar una selección debe registrar un único vínculo y una única ancla de origen.");

        var (d2, p2, a2, b2, c2) = Nuevo();
        var rechazadoBorrador = MYGProyectoStorage.Copia(a2.Costos.Hoja);
        string primero = MYGReferenciasMetrado.CrearReferencia(rechazadoBorrador, p2, b2, "B3");
        string segundo = MYGReferenciasMetrado.CrearReferencia(rechazadoBorrador, p2, c2, "B3");
        rechazadoBorrador.Poner("B3", "=" + primero + "+" + segundo);
        p2.Items.Remove(c2); MYGReferenciasMetrado.Vincular(d2.Presupuestos);
        destinoAntes = JsonSerializer.Serialize(a2.Costos.Hoja); origenAntes = JsonSerializer.Serialize(b2.Costos.Hoja);
        bool rechazado = false;
        try { MYGReferenciasMetrado.AplicarReferenciasPendientes(a2.Costos.Hoja, rechazadoBorrador); }
        catch (FormatException) { rechazado = true; }
        Exige(rechazado && JsonSerializer.Serialize(a2.Costos.Hoja) == destinoAntes &&
            JsonSerializer.Serialize(b2.Costos.Hoja) == origenAntes,
            "Si un origen pendiente desaparece, confirmar debe rechazar todos los vínculos sin registrar parcialmente el primero.");
        pasa("Elegir celdas y previsualizar referencias mantiene el proyecto intacto hasta confirmar y una confirmación fallida es atómica");
    }

    private static void VerificarCopias(Action<string> pasa)
    {
        var (_, presupuesto, a, b, _) = Nuevo(); b.Costos.Hoja.Poner("B3", "6");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, presupuesto, b, "B3") + "*2");
        var plantilla = MYGProyectoStorage.CopiarComoPlantilla(presupuesto, "COPIA AUTÓNOMA");
        MYGReferenciasMetrado.Vincular(new[] { presupuesto, plantilla });
        var destino = plantilla.Items.Single(x => x.Descripcion == a.Descripcion);
        var origen = plantilla.Items.Single(x => x.Descripcion == b.Descripcion);
        origen.Costos.Hoja.Poner("B3", "7");
        Numero(destino.Costos.Hoja, "B3", 14, "La plantilla debe remapear un vínculo interno hacia su propia partida copiada.");
        Numero(a.Costos.Hoja, "B3", 12, "Editar el origen de una plantilla no debe alterar el vínculo del presupuesto original.");
        MYGReferenciasMetrado.Vincular(new[] { plantilla });
        Numero(destino.Costos.Hoja, "B3", 14, "Una plantilla con sus partidas debe funcionar aunque el presupuesto original ya no esté abierto.");
        plantilla.Items.Remove(origen); MYGReferenciasMetrado.Vincular(new[] { plantilla });
        Error(destino.Costos.Hoja, "B3", "Una copia que perdió su origen no debe leer accidentalmente el presupuesto original.");
        pasa("Copiar un presupuesto como plantilla remapea referencias internas y mantiene independencia del documento original");
    }

    private static void VerificarExportacion(string carpeta, Action<string> pasa)
    {
        var (_, presupuesto, a, b, _) = Nuevo(); b.Costos.Hoja.Poner("B3", "7");
        var hoja = a.Costos.Hoja; hoja.Nombre = "Destino exportado";
        hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(hoja, presupuesto, b, "B3") + "*3");
        hoja.Poner("C4", "=SUM(1,2)");
        string formula = hoja.Celdas["B3"].Contenido;
        string ruta = Path.Combine(carpeta, "Metrados relacionados.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { hoja });
        using (var zip = ZipFile.OpenRead(ruta))
        using (var entrada = zip.GetEntry("xl/worksheets/sheet1.xml").Open())
        {
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            var xml = XDocument.Load(entrada);
            var celda = xml.Descendants(ns + "c").Single(x => (string)x.Attribute("r") == "B3");
            Exige(!xml.Descendants(ns + "f").Any(x => x.Value.Contains("METRADO", StringComparison.OrdinalIgnoreCase)) &&
                (string)celda.Element(ns + "v") == "21",
                "El XLSX debe exportar el resultado relacionado sin una función METRADO que Excel no pueda recalcular.");
        }
        var importado = MYGExcelPresupuestos.Importar(ruta, hoja.Nombre, hoja.CeldaTotal);
        Numero(importado, "B3", 21, "Importar el XLSX compartido debe recuperar el metrado relacionado como un valor autónomo.");
        Numero(importado, "C4", 3, "La exportación de vínculos no debe alterar fórmulas locales ordinarias.");
        Exige(importado.Celdas["C4"].Contenido.StartsWith('=') && hoja.Celdas["B3"].Contenido == formula,
            "Exportar debe conservar fórmulas locales en XLSX y todos los vínculos editables del proyecto MYG original.");
        presupuesto.Items.Remove(b);
        MYGReferenciasMetrado.Vincular(new[] { presupuesto });
        string rota = Path.Combine(carpeta, "Metrado con origen eliminado.xlsx");
        MYGExcelPresupuestos.Guardar(rota, new[] { hoja });
        using (var zip = ZipFile.OpenRead(rota))
        using (var entrada = zip.GetEntry("xl/worksheets/sheet1.xml").Open())
        {
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            var celda = XDocument.Load(entrada).Descendants(ns + "c").Single(x => (string)x.Attribute("r") == "B3");
            Exige((string)celda.Attribute("t") == "e" && (string)celda.Element(ns + "v") == "#REF!",
                "Exportar un vínculo roto debe conservar el error de referencia sin convertirlo en cero.");
        }
        pasa("Exportar a XLSX captura valores o errores de vínculos sin funciones exclusivas de MYG y conserva fórmulas locales y proyecto original");
    }
}
