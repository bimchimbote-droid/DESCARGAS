using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.Json;
using MYG_2027;

static class ProjectProgramacionConfiguracionCheck
{
    private static void Exige(bool condicion, string mensaje)
    {
        if (!condicion) throw new Exception(mensaje);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        ComprobarConfiguracion(pasa);
        ComprobarDivisiones(pasa);
        ComprobarOrdenAvance(pasa);
        ComprobarRecalculo(pasa);
        ComprobarValoresInvalidos(pasa);
        ComprobarFallosReales(pasa);
        ComprobarCulturas(pasa);
    }

    private static void ComprobarOrdenAvance(Action<string> pasa)
    {
        var datos = Datos() with { Avance = 37.5m };
        var pasos = new List<string>();
        DateTime provisional = datos.Inicio.AddMonths(-1), programado = datos.Inicio.AddDays(3), actual = default;
        DateTime inicio = provisional;
        bool sinRestricciones = false;
        MYGConfiguracionProgramacionProject.CalcularConAvance(new[]
            { datos, datos with { Uid = 8, Avance = 0 }, datos with { Uid = 9, Resumen = true, Avance = 50m } },
            () => { sinRestricciones = true; pasos.Add("ASAP"); },
            () =>
            {
                Exige(sinRestricciones, "Debe quitar restricciones inmediatamente antes de cada cálculo.");
                inicio = programado;
                pasos.Add("Calcular");
            },
            (tarea, porcentaje) =>
            {
                Exige(tarea.Uid == datos.Uid && porcentaje == 38, "Se aplicó avance a un resumen, cero avance o con redondeo diferente.");
                actual = inicio; // Project fija ActualStart al recibir avance.
                sinRestricciones = false;
                pasos.Add("Avance");
            });
        Exige(actual == programado && actual != provisional && string.Join(",", pasos) == "ASAP,Calcular,Avance,ASAP,Calcular",
            "El avance tomó el inicio provisional o faltó liberar restricciones y recalcular después.");
        pasos.Clear();
        MYGConfiguracionProgramacionProject.CalcularConAvance(new[] { datos with { Avance = 0m } },
            () => pasos.Add("ASAP"), () => pasos.Add("Calcular"),
            (_, _) => throw new Exception("No escribir avance inexistente."));
        Exige(string.Join(",", pasos) == "ASAP,Calcular", "Sin avance solo hace falta el cálculo inicial.");
        var fallo = new IOException("Falló el primer cálculo QA");
        Exige(ReferenceEquals(fallo, Captura<IOException>(() =>
            MYGConfiguracionProgramacionProject.CalcularConAvance(new[] { datos }, () => { }, () => throw fallo,
                (_, _) => throw new Exception("No aplicar avance después de un cálculo fallido.")))),
            "El fallo inicial no debe ocultarse ni permitir importar avance sobre fechas sin calcular.");
        pasa("Project calcula fechas y vínculos sin restricciones antes del avance para evitar ActualStart provisional, y recalcula solo cuando aplica progreso");
    }

    private static void ComprobarDivisiones(Action<string> pasa)
    {
        var datos = Datos() with { Inicio = Datos().Inicio.AddMonths(3), Fin = Datos().Fin.AddMonths(3) };
        var tramos = new[]
        {
            new MYGTramoTareaExportacionProject(datos.Inicio, datos.Inicio.AddHours(4)),
            new MYGTramoTareaExportacionProject(datos.Inicio.AddDays(2), datos.Fin.AddDays(2))
        };
        string original = JsonSerializer.Serialize(datos);
        object restriccion = 0, inicio = new DateTime(2023, 5, 1, 8, 0, 0);
        var escrituras = new List<(string Campo, object Valor)>();
        void Escribir(string campo, object valor)
        {
            escrituras.Add((campo, valor));
            if (campo == "Start")
            {
                inicio = valor;
                restriccion = 4; // Project puede generar SNET al escribir Start.
            }
            if (campo == "ConstraintType") restriccion = valor;
        }
        MYGConfiguracionProgramacionProject.ConfigurarAutomatica(datos, Escribir);
        MYGConfiguracionProgramacionProject.AnclarDivision(datos, tramos, Escribir);
        Exige((DateTime)inicio == datos.Inicio && (int)restriccion == 4,
            "La división absoluta debe recibir el inicio original antes de aplicar Split.");
        // Después de Split, liberar el anclaje antes de calcular y guardar.
        MYGConfiguracionProgramacionProject.QuitarRestricciones(datos, Escribir);
        Exige(escrituras.Count == 3 && escrituras[0].Campo == "Duration" && escrituras[1].Campo == "Start" &&
            escrituras[^1].Campo == "ConstraintType" && (int)restriccion == 0 &&
            !escrituras.Exists(e => e.Campo == "ConstraintDate" || e.Campo == "Calendar" ||
                e.Campo == "ConstraintType" && (int)e.Valor == 2) && JsonSerializer.Serialize(datos) == original,
            "El anclaje temporal de una división dejó restricciones MSO/SNET o modificó el origen.");
        foreach (var tarea in new[] { datos with { Manual = true }, datos with { Resumen = true } })
            MYGConfiguracionProgramacionProject.AnclarDivision(tarea, tramos,
                (_, _) => throw new Exception("No anclar manuales ni resúmenes."));
        MYGConfiguracionProgramacionProject.AnclarDivision(datos, new[] { tramos[0] },
            (_, _) => throw new Exception("Una tarea sin pausa no necesita anclaje."));
        pasa("Project ancla temporalmente las divisiones absolutas para conservar pausas y termina en ASAP sin MSO, calendario propio ni cambios en MYG");
    }

    private static void ComprobarConfiguracion(Action<string> pasa)
    {
        foreach (bool importada in new[] { false, true })
        {
            var datos = Datos() with { ConservarFechasImportadas = importada };
            string original = JsonSerializer.Serialize(datos);
            var escrituras = new List<(string Campo, object Valor)>();
            MYGConfiguracionProgramacionProject.ConfigurarAutomatica(datos, (campo, valor) => escrituras.Add((campo, valor)));
            // Simular que las dependencias, avance o divisiones introducen una
            // restricción y luego terminar con ASAP antes del cálculo.
            escrituras.Add(("ConstraintType", 4));
            MYGConfiguracionProgramacionProject.QuitarRestricciones(datos, (campo, valor) => escrituras.Add((campo, valor)));
            Exige(escrituras.Count == 3 && escrituras[0].Campo == "Duration" &&
                Convert.ToDecimal(escrituras[0].Valor, CultureInfo.InvariantCulture) == datos.DuracionMinutos &&
                escrituras[^1].Campo == "ConstraintType" && (int)escrituras[^1].Valor == 0 &&
                !escrituras.Exists(e => e.Campo == "Calendar" || e.Campo == "Start" || e.Campo == "ConstraintDate") &&
                JsonSerializer.Serialize(datos) == original,
                "Una tarea automática impuso calendario/fecha, no terminó en ASAP o alteró el origen.");
        }
        var manual = Datos() with { Manual = true };
        MYGConfiguracionProgramacionProject.ConfigurarAutomatica(manual, (_, _) => throw new Exception("No reprogramar manuales."));
        MYGConfiguracionProgramacionProject.QuitarRestricciones(manual, (_, _) => throw new Exception("No reprogramar manuales."));
        var resumen = manual with { Resumen = true };
        int llamadas = 0;
        MYGConfiguracionProgramacionProject.ConfigurarAutomatica(resumen, (_, _) => throw new Exception("No fijar duración de resumen."));
        MYGConfiguracionProgramacionProject.QuitarRestricciones(resumen, (campo, valor) =>
        {
            Exige(campo == "ConstraintType" && (int)valor == 0, "Un resumen debe quedar sin restricciones.");
            llamadas++;
        });
        Exige(llamadas == 1, "No se quitó la restricción de la tarea resumen automática.");
        pasa("Project hereda el calendario sin imponer Start ni restricciones importadas y termina con ASAP; no altera tareas manuales ni fija duración de resúmenes");
    }

    private static void ComprobarRecalculo(Action<string> pasa)
    {
        var datos = Datos();
        string original = JsonSerializer.Serialize(datos);
        var campos = Campos(datos);
        Exige(MYGConfiguracionProgramacionProject.Verificar(datos, campo => campos[campo]) == null,
            "Una programación idéntica produjo un aviso de recálculo.");
        campos["Start"] = datos.Inicio.AddDays(1);
        campos["Finish"] = datos.Fin.AddDays(2);
        campos["Duration"] = datos.DuracionMinutos + 480m;
        string aviso = MYGConfiguracionProgramacionProject.Verificar(datos, campo => campos[campo]);
        Exige(aviso.Contains(datos.Nombre, StringComparison.Ordinal) && aviso.Contains("UID 7", StringComparison.Ordinal) &&
            aviso.Contains("inicio 2023-05-03 08:00 → 2023-05-04 08:00", StringComparison.Ordinal) &&
            aviso.Contains("fin 2023-05-04 17:00 → 2023-05-06 17:00", StringComparison.Ordinal) &&
            aviso.Contains("duración 960 → 1440 minutos", StringComparison.Ordinal) &&
            JsonSerializer.Serialize(datos) == original,
            "El recálculo no informa tarea y valores anteriores/resultantes o alteró los datos de MYG.");
        var resumen = datos with { Resumen = true, Manual = true };
        Exige(MYGConfiguracionProgramacionProject.Verificar(resumen, campo => campos[campo]).Contains("tarea resumen", StringComparison.Ordinal),
            "El recálculo de un resumen se omitió o lo trató como tarea manual.");
        campos = Campos(datos);
        campos["Start"] = datos.Inicio.AddMilliseconds(999);
        campos["Duration"] = datos.DuracionMinutos + 0.01m;
        Exige(MYGConfiguracionProgramacionProject.Verificar(datos, campo => campos[campo]) == null,
            "Una diferencia dentro de la precisión soportada produjo un aviso.");
        campos["Finish"] = datos.Fin.AddDays(1);
        aviso = MYGConfiguracionProgramacionProject.Verificar(datos, campo => campos[campo]);
        Exige(aviso.Contains("fin ", StringComparison.Ordinal) && !aviso.Contains("inicio ", StringComparison.Ordinal) &&
            !aviso.Contains("duración ", StringComparison.Ordinal), "El aviso debe enumerar únicamente los campos modificados.");
        Exige(MYGConfiguracionProgramacionProject.Verificar(datos with { Manual = true },
            _ => throw new Exception("La verificación manual tiene su propio contrato.")) == null,
            "La programación automática no debe sustituir la verificación de textos manuales.");
        pasa("Project permite recálculos válidos y avisa solo de cambios reales con tarea, fechas y duración anteriores/resultantes, incluidos resúmenes, sin modificar el origen");
    }

    private static void ComprobarValoresInvalidos(Action<string> pasa)
    {
        var datos = Datos();
        var invalidos = new (string Campo, object Valor)[]
        {
            ("Manual", true), ("Manual", null), ("Manual", "False"),
            ("ConstraintType", 2), ("ConstraintType", 4), ("ConstraintType", null), ("ConstraintType", true),
            ("Start", "NA"), ("Start", null), ("Start", DateTime.MinValue), ("Start", DateTime.MaxValue),
            ("Finish", "NA"), ("Finish", null), ("Finish", datos.Inicio.AddMinutes(-1)),
            ("Duration", -1m), ("Duration", null), ("Duration", double.NaN),
            ("Duration", double.PositiveInfinity), ("Duration", true), ("Duration", "NA")
        };
        foreach (var invalido in invalidos)
        {
            var campos = Campos(datos);
            campos[invalido.Campo] = invalido.Valor;
            string mensaje = Captura<InvalidOperationException>(() =>
                MYGConfiguracionProgramacionProject.Verificar(datos, campo => campos[campo])).Message;
            Exige(mensaje.Contains(datos.Nombre, StringComparison.Ordinal) &&
                mensaje.Contains("No se reemplazó el archivo de destino", StringComparison.Ordinal),
                "Un modo, restricción o valor inválido no debe quedar oculto como aviso de fechas.");
        }
        pasa("Project rechaza modo incorrecto, restricciones residuales, fechas ausentes o invertidas y duraciones negativas, no numéricas o no finitas");
    }

    private static void ComprobarFallosReales(Action<string> pasa)
    {
        var datos = Datos();
        var fallo = new IOException("Fallo de acceso COM QA");
        Exige(ReferenceEquals(fallo, Captura<IOException>(() =>
            MYGConfiguracionProgramacionProject.Verificar(datos, _ => throw fallo))) &&
            ReferenceEquals(fallo, Captura<IOException>(() =>
            MYGConfiguracionProgramacionProject.ConfigurarAutomatica(datos, (_, _) => throw fallo))) &&
            ReferenceEquals(fallo, Captura<IOException>(() =>
            MYGConfiguracionProgramacionProject.QuitarRestricciones(datos, (_, _) => throw fallo))),
            "Los errores reales de lectura/escritura de Project no deben convertirse en advertencias.");
        pasa("Project propaga los fallos reales de acceso a programación y restricciones sin convertirlos en avisos de recálculo");
    }

    private static void ComprobarCulturas(Action<string> pasa)
    {
        var anterior = CultureInfo.CurrentCulture;
        try
        {
            foreach (string cultura in new[] { "es-PE", "es-ES", "en-US" })
            {
                CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo(cultura);
                var datos = Datos();
                var campos = Campos(datos);
                campos["Duration"] = "960.125";
                string aviso = MYGConfiguracionProgramacionProject.Verificar(datos, campo => campos[campo]);
                Exige(aviso.Contains("960 → 960.125 minutos", StringComparison.Ordinal),
                    "El aviso perdió precisión decimal al cambiar la cultura de Windows.");
            }
        }
        finally { CultureInfo.CurrentCulture = anterior; }
        pasa("Project informa fechas y duraciones con precisión estable bajo las culturas de Perú, España y Estados Unidos");
    }

    private static MYGTareaExportacionProject Datos() => new(7, "QA", 0, 1, "1", "01", "CARTEL QA",
        false, false, false, false, new DateTime(2023, 5, 3, 8, 0, 0), new DateTime(2023, 5, 4, 17, 0, 0),
        960m, 0m, null, null, null, "");

    private static Dictionary<string, object> Campos(MYGTareaExportacionProject datos) => new()
    {
        ["Manual"] = false, ["ConstraintType"] = 0, ["Start"] = datos.Inicio,
        ["Finish"] = datos.Fin, ["Duration"] = datos.DuracionMinutos
    };

    private static T Captura<T>(Action accion) where T : Exception
    {
        try { accion(); }
        catch (T excepcion) { return excepcion; }
        throw new Exception("Se esperaba " + typeof(T).Name + ".");
    }
}
