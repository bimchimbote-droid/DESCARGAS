using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

static class ReporteInsumosContextoCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static int Fila(MYGHojaMetrado h, string texto) => h.Celdas
        .Where(c => new MYGHojaCalculo(h).Mostrar(c.Key) == texto)
        .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (ArgumentException) { return; }
        catch (InvalidDataException) { return; }
        throw new Exception("El informe aceptó un proyecto, ámbito o insumo no válido.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("PROYECTO DE IMPRESIÓN", "PRESUPUESTO PRINCIPAL");
        documento.Datos = new MYGDatosProyecto { Propietario = "PROPIETARIO QA", Departamento = "ÁNCASH",
            Provincia = "SANTA", Distrito = "CHIMBOTE", FechaElaboracion = new DateTime(2026, 9, 1) };
        var p = documento.Presupuestos.Single();
        var material = new MYGInsumoContexto { Grupo = MYGGrupoRecurso.Materiales, Codigo = "00012",
            Descripcion = "=DESCRIPCIÓN LITERAL", Unidad = "kg", Cantidad = 1.234567m, Precio = 3.4567m,
            Total = 4.27m, Proveedor = "PROVEEDOR QUE NO SE IMPRIME" };
        var contrato = new MYGInsumoContexto { Grupo = MYGGrupoRecurso.Subcontratos, Codigo = "SC-REAL",
            Descripcion = "SUBCONTRATO REAL", Unidad = "und", Cantidad = 2, Precio = 5, Total = 10 };
        var sinCantidad = new MYGInsumoContexto { Grupo = MYGGrupoRecurso.Materiales, Codigo = "CERO",
            Descripcion = "RECURSO REFERENCIADO SIN METRADO", Unidad = "m3", Cantidad = 0, Precio = 7, Total = 0 };
        var entrada = new[] { contrato, material, sinCantidad };
        string antes = Firma(documento), antesEntrada = Firma(entrada);
        var reporte = MYGReportesProyecto.CrearListaInsumos(documento, p, entrada, tituloSeleccionado: "01.02 ESTRUCTURAS");
        var h = reporte.Hoja; var calculo = new MYGHojaCalculo(h);
        int filaMaterial = Fila(h, material.Descripcion), filaContrato = Fila(h, contrato.Descripcion);
        int filaGrupo = Fila(h, "MATERIALES"), filaTotal = MYGHojaCalculo.Coordenadas(h.CeldaTotal).Fila;
        Exige(h.Columnas == 6 && Enumerable.Range(1, 6).Select(c => calculo.Mostrar(MYGHojaCalculo.Columna(c) + "1"))
            .SequenceEqual(new[] { "Código", "Descripción", "Unid.", "Cantidad", "Costo", "Total" }) &&
            calculo.Mostrar("A" + filaMaterial) == "00012" && calculo.Mostrar("B" + filaMaterial) == "=DESCRIPCIÓN LITERAL" &&
            calculo.Mostrar("C" + filaMaterial) == "kg" && calculo.Numero("D" + filaMaterial) == 1.234567m &&
            calculo.Numero("E" + filaMaterial) == 3.4567m && h.Celdas["D" + filaMaterial].FormatoNumero == "#,##0.0000" &&
            h.Celdas["E" + filaMaterial].FormatoNumero == "#,##0.00" &&
            calculo.Numero("F" + filaGrupo) == 4.27m && calculo.Numero(h.CeldaTotal) == 14.27m &&
            h.Celdas["B" + filaGrupo].Negrita && h.Celdas["F" + filaGrupo].Negrita &&
            h.RangosCombinados.Contains("B" + filaGrupo + ":E" + filaGrupo) &&
            filaGrupo < filaMaterial && filaMaterial < filaContrato && Fila(h, sinCantidad.Descripcion) > 1,
            "La impresión alteró recursos, literales, precisión, grupos o importes recibidos.");
        Exige(h.TamanoPapel == "A4" && h.OrientacionPagina == "Vertical" && h.AnchosColumnas.Values.Sum() <= 660 &&
            h.MargenIzquierdo == .7m && h.MargenDerecho == .7m && h.MargenSuperior == .75m && h.MargenInferior == .65m &&
            h.RepetirTitulos && h.FilasInmovilizadas == 1 && h.FilasOcultas.Count == 0 &&
            h.Celdas.Values.All(c => c.Fuente == "Arial Narrow" && c.TamanoFuente == 9 && c.ColorTexto == "000000") &&
            h.Celdas.All(c => c.Value.Bordes == (MYGHojaCalculo.Coordenadas(c.Key).Fila == 1 ||
                MYGHojaCalculo.Coordenadas(c.Key).Fila == filaTotal)) &&
            Enumerable.Range(1, 6).All(c => h.Celdas[MYGHojaCalculo.Columna(c) + "1"].ColorFondo == "ECEEF1") &&
            h.Celdas["E" + filaTotal].ColorFondo == "ECEEF1" && h.Celdas["F" + filaTotal].ColorFondo == "ECEEF1" &&
            !h.Celdas.Keys.Any(k => MYGHojaCalculo.Coordenadas(k).Fila == filaTotal && MYGHojaCalculo.Coordenadas(k).Columna < 5) &&
            h.Celdas["E" + filaTotal].AlineacionHorizontal == "Derecha" && calculo.Mostrar("E" + filaTotal) == "TOTAL:" &&
            h.Celdas.Values.All(c => !c.Contenido.Contains("PROVEEDOR QUE NO SE IMPRIME", StringComparison.Ordinal)),
            "El formato no conserva A4 vertical, columnas separadas, cabecera gris y total sombreado sólo a la derecha.");
        Exige(reporte.EsListaInsumos && reporte.UsaFormatoPresupuesto &&
            reporte.TituloImpresion == "LISTA DE INSUMOS DEL PRESUPUESTO" &&
            reporte.CabeceraImpresion.Count == 6 && reporte.CabeceraImpresion.Any(d => d.Key == "TÍTULO" && d.Value == "01.02 ESTRUCTURAS") &&
            reporte.CabeceraImpresion.Any(d => d.Key == "PROPIETARIO" && d.Value == "PROPIETARIO QA") &&
            reporte.CabeceraImpresion.Any(d => d.Value == "DPTO: ÁNCASH  PROV: SANTA  DIST: CHIMBOTE") &&
            reporte.CabeceraImpresion.Any(d => d.Value == "01/09/2026") && Firma(documento) == antes && Firma(entrada) == antesEntrada,
            "El informe perdió la cabecera del presupuesto/título o modificó los datos consultados.");
        pasa("Impresión de insumos conserva literales, cantidades, costos, grupos y total en A4 vertical con cabecera institucional y unidad independiente");

        var filtrado = MYGReportesProyecto.CrearListaInsumos(documento, p, new[] { material });
        Exige(filtrado.CabeceraImpresion.Count == 5 && new MYGHojaCalculo(filtrado.Hoja).Numero(filtrado.Hoja.CeldaTotal) == 4.27m &&
            !filtrado.Hoja.Celdas.Values.Any(c => c.Contenido == contrato.Descripcion),
            "El informe recalculó el catálogo completo en lugar de respetar los insumos filtrados recibidos.");
        var proyecto = MYGReportesProyecto.CrearListaInsumos(documento, p, entrada, proyectoCompleto: true, tituloSeleccionado: "NO APLICABLE");
        Exige(proyecto.TituloImpresion == "LISTA DE INSUMOS DEL PROYECTO" && proyecto.CabeceraImpresion.Count == 4 &&
            proyecto.CabeceraImpresion.All(d => d.Key != "PRESUPUESTO" && d.Key != "TÍTULO"),
            "La lista del proyecto conservó indebidamente la selección de un presupuesto o título.");
        var vacio = MYGReportesProyecto.CrearListaInsumos(documento, p, Array.Empty<MYGInsumoContexto>());
        Exige(vacio.Hoja.Filas == 2 && vacio.Hoja.CeldaTotal == "F2" && new MYGHojaCalculo(vacio.Hoja).Numero("F2") == 0,
            "La lista vacía inventó recursos o perdió la fila total.");
        var ajuste = new MYGInsumoContexto { Grupo = MYGGrupoRecurso.Equipo, Descripcion = "Ajuste por redondeo",
            Unidad = "S/", Cantidad = -.01m, Precio = 1, Total = -.01m };
        var conAjuste = MYGReportesProyecto.CrearListaInsumos(documento, p, new[] { material, ajuste });
        Exige(new MYGHojaCalculo(conAjuste.Hoja).Numero(conAjuste.Hoja.CeldaTotal) == 4.26m,
            "La impresión rechazó o eliminó un ajuste negativo válido del consolidado.");
        pasa("Listas de impresión respetan filtros, alcance de proyecto, entradas vacías y ajustes negativos sin inventar recursos");

        var vista = new MYGConfiguracionVistaReporte(new[] { reporte });
        Exige(vista.Reportes.Single().EsListaInsumos && vista.Reportes.Single().TituloImpresion == reporte.TituloImpresion &&
            vista.Reportes.Single().CabeceraImpresion.SequenceEqual(reporte.CabeceraImpresion),
            "La copia de vista previa perdió la identidad o cabecera de la lista de insumos.");
        vista.Fuente("Arial"); vista.ConfigurarPagina("A3", "Horizontal", .2m, .2m, .2m, .2m);
        Exige(h.OrientacionPagina == "Vertical" && h.Celdas.Values.All(c => c.Fuente == "Arial Narrow"),
            "Configurar la vista previa modificó la instantánea original.");
        var hojas = MYGReportesExcel.CrearHojas(new[] { reporte });
        string ruta = Path.Combine(carpeta, "Lista de insumos formato impresion.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        var reabierta = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta).Single(), hojas.Single().CeldaTotal);
        var excel = new MYGHojaCalculo(reabierta);
        Exige(reabierta.TamanoPapel == "A4" && reabierta.OrientacionPagina == "Vertical" &&
            excel.Numero(reabierta.CeldaTotal) == 14.27m && reabierta.Celdas.Keys.Any(k => excel.Mostrar(k) == "00012") &&
            reabierta.Celdas.Keys.Any(k => excel.Mostrar(k) == "=DESCRIPCIÓN LITERAL") &&
            reabierta.Celdas.Keys.Any(k => excel.Mostrar(k) == "LISTA DE INSUMOS DEL PRESUPUESTO") &&
            reabierta.Celdas.Keys.Any(k => excel.Mostrar(k) == "PROPIETARIO QA") && Firma(documento) == antes && Firma(entrada) == antesEntrada,
            "La exportación de la vista previa perdió la cabecera, literales, total o aislamiento del informe.");
        material.Descripcion = "RECURSO EDITADO DESPUÉS"; documento.Datos.Propietario = "PROPIETARIO EDITADO";
        Exige(calculo.Mostrar("B" + filaMaterial) == "=DESCRIPCIÓN LITERAL" &&
            reporte.CabeceraImpresion.Any(d => d.Value == "PROPIETARIO QA"),
            "La impresión mantuvo referencias mutables a los insumos o metadatos del proyecto.");
        pasa("Vista previa y Excel conservan cabecera y totales por copia, sin mutar ni depender del proyecto y recursos originales");

        Rechaza(() => MYGReportesProyecto.CrearListaInsumos(documento, new MYGPresupuestoDocumento(), entrada));
        Rechaza(() => MYGReportesProyecto.CrearListaInsumos(documento, p, new MYGInsumoContexto[] { null }));
        Rechaza(() => MYGReportesProyecto.CrearListaInsumos(documento, p,
            new[] { new MYGInsumoContexto { Grupo = (MYGGrupoRecurso)999, Descripcion = "INVÁLIDO", Unidad = "und" } }));
        Rechaza(() => MYGReportesProyecto.CrearListaInsumos(documento, p,
            new[] { new MYGInsumoContexto { Grupo = MYGGrupoRecurso.Materiales, Descripcion = "INVÁLIDO", Unidad = "und", Precio = -1 } }));
        documento.Presupuestos.Add(new MYGPresupuestoDocumento { Nombre = "OTRA MONEDA", Costos = new() { Moneda = "USD" } });
        Rechaza(() => MYGReportesProyecto.CrearListaInsumos(documento, p, entrada, proyectoCompleto: true));
        Exige(MYGReportesProyecto.CrearListaInsumos(documento, p, entrada).CabeceraImpresion.Any(d => d.Key == "PRESUPUESTO"),
            "Otro presupuesto de distinta moneda impidió imprimir la selección individual.");
        pasa("Impresión rechaza presupuestos ajenos, filas inválidas y monedas mezcladas sin bloquear el presupuesto individual");
    }
}
