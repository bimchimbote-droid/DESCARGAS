using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ActualizacionMetradoHojaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
    private static (MYGPresupuestoDocumento Presupuesto, ItemPresupuestoDelphin Partida) Nuevo()
    {
        var presupuesto = new MYGPresupuestoDocumento { Nombre = "VÍNCULO DINÁMICO DE METRADO" };
        var partida = Nodo(); presupuesto.Items.Add(partida);
        return (presupuesto, partida);
    }
    private static ItemPresupuestoDelphin Nodo(bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        { Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = titulo ? "TÍTULO" : "PARTIDA", Unidad = titulo ? "" : "m²", TipoPropuesta = titulo ? "TITULO" : "PARTIDA" };
    }
    private static void Entrada(MYGHojaMetrado hoja, string celda, string contenido) =>
        MYGEdicionHoja.Celda(hoja, celda).Contenido = contenido;
    private static void RechazaSinCambios(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, string mensaje)
    {
        string antes = Datos(presupuesto), partidaAntes = Datos(partida);
        bool rechazado = false;
        try { MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida); }
        catch (InvalidDataException) { rechazado = true; }
        Exige(rechazado && Datos(presupuesto) == antes && Datos(partida) == partidaAntes, mensaje);
    }

    public static void Ejecutar(Action<string> pasa)
    {
        VerificarActualizacion(pasa);
        VerificarPrecision(pasa);
        VerificarInvalidos(pasa);
        VerificarFuentes(pasa);
        VerificarCeldaTotal(pasa);
        VerificarVinculoEstructural(pasa);
        VerificarPersistencia(pasa);
        VerificarPartidaActual(pasa);
    }

    private static void VerificarActualizacion(Action<string> pasa)
    {
        var (presupuesto, partida) = Nuevo();
        var hoja = partida.Costos.Hoja;
        Entrada(hoja, "A3", "Partida 2"); Entrada(hoja, "B3", "1"); Entrada(hoja, "C3", "2");
        Entrada(hoja, "D3", "0.3"); Entrada(hoja, "E3", "0.5"); Entrada(hoja, "F3", "2");
        partida.Costos.PrecioDirecto = 62;
        var vecino = Nodo(); presupuesto.Items.Add(vecino);
        vecino.Costos.Cantidad = 2; vecino.Costos.PrecioDirecto = 44;
        string antes = Datos(presupuesto), vecinoAntes = Datos(vecino), hojaAntes = Datos(hoja);
        var estado = MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida);
        Exige(estado.TotalHoja == 0.6m && estado.CantidadPresupuesto == 0 && estado.PuedeActualizar && estado.HayDiferencia &&
            Datos(presupuesto) == antes, "Consultar el total 0.6000 debe detectar la diferencia sin modificar el presupuesto.");
        Exige(MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) &&
            partida.Costos.Cantidad == 0.6m && partida.Costos.FuenteMetrado == MYGFuenteMetrado.Excel &&
            ReferenceEquals(hoja, partida.Costos.Hoja) && Datos(hoja) == hojaAntes && Datos(vecino) == vecinoAntes &&
            MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == 37.2m && MYGMotorPresupuestos.Resumen(presupuesto).CostoDirecto == 125.2m,
            "Actualizar debe vincular 0.6, recalcular el importe y conservar la hoja y las partidas vecinas.");
        antes = Datos(presupuesto);
        estado = MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida);
        Exige(estado.PuedeActualizar && !estado.HayDiferencia && !MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) &&
            Datos(presupuesto) == antes, "Repetir una actualización coincidente no debe cambiar el documento.");
        Entrada(hoja, "C3", "3");
        estado = MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida);
        Exige(estado.TotalHoja == 0.9m && estado.CantidadPresupuesto == 0.9m && !estado.HayDiferencia &&
            MYGMotorPresupuestos.TotalPartida(presupuesto, partida) == 55.8m &&
            MYGMotorPresupuestos.Resumen(presupuesto).CostoDirecto == 143.8m && partida.Costos.Cantidad == 0.6m,
            "Editar la hoja vinculada debe recalcular cantidad e importes conservando la cantidad inicial almacenada.");
        Exige(!MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida),
            "Actualizar de nuevo una hoja vinculada no debe crear cambios redundantes.");
        pasa("Actualizar vincula el metrado y recalcula cantidades y costos al editar la hoja; conserva vecinos y repetir es inocuo");
    }

    private static void VerificarPrecision(Action<string> pasa)
    {
        for (int precision = 0; precision <= 8; precision++)
        {
            var (presupuesto, partida) = Nuevo(); presupuesto.Costos.DecimalesCantidad = precision;
            Entrada(partida.Costos.Hoja, "G16", "1.234567895");
            decimal esperado = decimal.Round(1.234567895m, precision, MidpointRounding.AwayFromZero);
            Exige(MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).TotalHoja == esperado &&
                MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && partida.Costos.Cantidad == esperado &&
                MYGMotorPresupuestos.Cantidad(presupuesto, partida) == esperado,
                "La actualización no respetó la precisión de cantidad " + precision + ".");
            // La cantidad almacenada sigue disponible, pero una fuente Excel
            // vinculada siempre toma el resultado calculado de la hoja.
            partida.Costos.Cantidad = precision == 8 ? 1.234567896m : 1.234567895m;
            string antes = Datos(presupuesto);
            Exige(!MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).HayDiferencia &&
                !MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && Datos(presupuesto) == antes,
                "Una cantidad equivalente después de redondear debe ser inocua con precisión " + precision + ".");
        }
        var (p, i) = Nuevo(); p.Costos.DecimalesCantidad = 2; Entrada(i.Costos.Hoja, "G16", "0.00001");
        Exige(!MYGActualizacionMetradoHoja.Evaluar(p, i).PuedeActualizar,
            "Un total que redondea a cero no debe habilitar una actualización vacía.");
        RechazaSinCambios(p, i, "Un total que redondea a cero no debe modificar el documento.");
        pasa("Metrado usa precisión del presupuesto entre 0 y 8 decimales, compara cantidades efectivas y rechaza valores que redondean a cero");
    }

    private static void VerificarInvalidos(Action<string> pasa)
    {
        string[] contenidos = ["", "0", "-0.1", "texto", "=\"0.6\"", "=TRUE()", "=FALSE()", "=1/0", "=G16+1", "=Z999", "1000000000000.0001", "=9999999999999999999999999999*100"];
        foreach (string contenido in contenidos)
        {
            var (presupuesto, partida) = Nuevo(); partida.Costos.Cantidad = 7;
            Entrada(partida.Costos.Hoja, "G16", contenido);
            string antes = Datos(presupuesto);
            var estado = MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida);
            Exige(!estado.PuedeActualizar && !estado.HayDiferencia && estado.CantidadPresupuesto == 7 && Datos(presupuesto) == antes,
                "El total no válido habilitó cambios o modificó el documento: " + contenido);
            RechazaSinCambios(presupuesto, partida, "Se actualizó con un total no válido: " + contenido);
        }
        var (p, i) = Nuevo(); Entrada(i.Costos.Hoja, "G16", "1");
        foreach (string referencia in new[] { "", "A0", "M16", "G101" })
        {
            i.Costos.Hoja.CeldaTotal = referencia;
            Exige(!MYGActualizacionMetradoHoja.Evaluar(p, i).PuedeActualizar, "Se admitió una referencia total inválida: " + referencia);
            RechazaSinCambios(p, i, "Una celda total inválida modificó el documento.");
        }
        i.Costos.Hoja.CeldaTotal = "G16";
        foreach (int precision in new[] { -1, 9 })
        {
            p.Costos.DecimalesCantidad = precision;
            Exige(!MYGActualizacionMetradoHoja.Evaluar(p, i).PuedeActualizar, "Se admitió una precisión fuera de rango.");
            RechazaSinCambios(p, i, "Una precisión inválida modificó el documento.");
        }
        p.Costos.DecimalesCantidad = 8; Entrada(i.Costos.Hoja, "G16", "1000000000000");
        Exige(MYGActualizacionMetradoHoja.Actualizar(p, i) && i.Costos.Cantidad == MYGEdicionPartida.CantidadMaxima,
            "El límite máximo de cantidad permitido debe aceptarse sin restringir a dos decimales.");
        var (malformado, partidaMalformada) = Nuevo(); partidaMalformada.Costos.Hoja.Celdas["G16"] = null;
        Exige(!MYGActualizacionMetradoHoja.Evaluar(malformado, partidaMalformada).PuedeActualizar,
            "Una celda total malformada debe ocultar la actualización sin fallar ni normalizarla.");
        RechazaSinCambios(malformado, partidaMalformada, "Una celda total malformada modificó el documento.");
        pasa("Totales vacíos, cero, negativos, texto, lógicos, errores, circularidad, desbordamientos y referencias/precisiones inválidas se rechazan sin cambios");
    }

    private static void VerificarFuentes(Action<string> pasa)
    {
        foreach (MYGFuenteMetrado fuente in Enum.GetValues<MYGFuenteMetrado>())
        {
            var (presupuesto, partida) = Nuevo(); var datos = partida.Costos;
            Entrada(datos.Hoja, "G16", "0.6");
            datos.Hoja.Celdas["G16"].ColorTexto = "123456"; datos.Hoja.Celdas["G16"].FormatoNumero = "0.00000000";
            datos.PrecioDirecto = 62; datos.EspecificacionTexto = "Especificación conservada";
            datos.PrecioImportadoDelphin = 62; datos.FirmaAnalisisImportadoDelphin = "Firma conservada";
            var insumo = new MYGInsumo { Descripcion = "Material conservado", Unidad = "kg", Precio = 4 };
            presupuesto.Costos.Insumos.Add(insumo);
            datos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Cantidad = 3, Grupo = MYGGrupoRecurso.Materiales });
            datos.Cantidad = 0.6m;
            datos.Metrados.Add(new MYGLineaMetrado { Descripcion = "Manual conservado", Elementos = 2, CantidadPorElemento = 0.3m });
            datos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = "BIM-CONSERVADO", Cantidad = 0.6m, Unidad = "m²" });
            datos.FuenteMetrado = fuente;
            var copiaEsperada = MYGProyectoStorage.Copia(datos);
            copiaEsperada.FuenteMetrado = MYGFuenteMetrado.Excel;
            Exige(MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).CantidadPresupuesto == 0.6m &&
                !MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).HayDiferencia,
                "Comparar fuentes con igual cantidad debe conservar la comparación efectiva: " + fuente);
            if (fuente == MYGFuenteMetrado.Excel)
            {
                string vinculada = Datos(presupuesto);
                Exige(!MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && Datos(presupuesto) == vinculada,
                    "Las hojas previamente vinculadas a Excel no deben generar cambios redundantes.");
            }
            else Exige(MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida),
                "Actualizar debe activar el vínculo aunque la cantidad actual coincida: " + fuente);
            Exige(ReferenceEquals(datos, partida.Costos) && Datos(datos) == Datos(copiaEsperada),
                "Vincular debe conservar fórmulas, formatos, metrados manuales y BIM, ACU y datos de costo: " + fuente);
            Entrada(datos.Hoja, "G16", "1.2");
            string antes = Datos(presupuesto);
            Exige(!MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).HayDiferencia &&
                !MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && Datos(presupuesto) == antes &&
                MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 1.2m && datos.Cantidad == 0.6m,
                "El vínculo debe leer el nuevo total y conservar todos los datos previos: " + fuente);
        }
        var (p, i) = Nuevo(); Entrada(i.Costos.Hoja, "G16", "0.6"); i.Costos.Cantidad = -1;
        var estado = MYGActualizacionMetradoHoja.Evaluar(p, i);
        Exige(estado.PuedeActualizar && estado.HayDiferencia && estado.CantidadPresupuesto == null &&
            MYGActualizacionMetradoHoja.Actualizar(p, i) && i.Costos.Cantidad == 0.6m,
            "Una cantidad de presupuesto inválida debe detectarse como desconocida y poder corregirse con el total válido.");
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        i.Costos.Metrados.Add(new MYGLineaMetrado { Elementos = decimal.MaxValue, CantidadPorElemento = 2 });
        string manualAntes = Datos(p);
        estado = MYGActualizacionMetradoHoja.Evaluar(p, i);
        Exige(estado.CantidadPresupuesto == null && estado.HayDiferencia && Datos(p) == manualAntes &&
            MYGActualizacionMetradoHoja.Actualizar(p, i) && i.Costos.Metrados.Single().Elementos == decimal.MaxValue,
            "Un metrado manual desbordado debe poder reemplazarse por la cantidad de hoja conservando sus datos.");
        i.Costos.FuenteMetrado = (MYGFuenteMetrado)999;
        estado = MYGActualizacionMetradoHoja.Evaluar(p, i);
        Exige(estado.CantidadPresupuesto == null && estado.HayDiferencia && MYGActualizacionMetradoHoja.Actualizar(p, i),
            "Una fuente inválida debe informar cantidad desconocida y corregirse al copiar el total válido.");
        pasa("Actualizar activa el vínculo incluso con cantidades iguales desde Cantidad, Manual y BIM; conserva datos y corrige cantidades inválidas");
    }

    private static void VerificarCeldaTotal(Action<string> pasa)
    {
        var (presupuesto, partida) = Nuevo();
        var acero = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros); partida.Costos.Hoja = acero;
        Entrada(acero, "B3", "2"); Entrada(acero, "C3", "3"); Entrada(acero, "D3", "3/8"); Entrada(acero, "E3", "4");
        Exige(MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).TotalHoja == 13.92m &&
            MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && partida.Costos.Cantidad == 13.92m,
            "La actualización debe usar AD16 en la plantilla de aceros.");
        MYGEdicionHoja.InsertarFilas(acero, 4); MYGEdicionHoja.InsertarColumnas(acero, 5);
        Entrada(acero, "B3", "3");
        Exige(acero.CeldaTotal == "AE17" && MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).TotalHoja == 20.88m &&
            !MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 20.88m,
            "El vínculo debe seguir el total desplazado al insertar filas y columnas.");
        var hoja = new MYGHojaMetrado { CeldaTotal = "$J$22" }; Entrada(hoja, "J22", "=SUM(0.2,0.4)"); partida.Costos.Hoja = hoja;
        partida.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        Exige(MYGActualizacionMetradoHoja.Evaluar(presupuesto, partida).TotalHoja == 0.6m &&
            MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) && partida.Costos.Cantidad == 0.6m,
            "Las hojas personalizadas deben usar su celda total seleccionada, incluidas referencias absolutas.");
        pasa("El vínculo usa el total de estándar, aceros y hojas personalizadas, incluso después de insertar filas y columnas");
    }

    private static void VerificarVinculoEstructural(Action<string> pasa)
    {
        var (presupuesto, partida) = Nuevo(); var hoja = partida.Costos.Hoja;
        Entrada(hoja, "B3", "2"); Entrada(hoja, "C3", "3");
        Entrada(hoja, "B4", "1"); Entrada(hoja, "C4", "4");
        Exige(MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida) &&
            MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 10m,
            "El vínculo inicial debe sumar los dos detalles.");
        MYGEdicionHoja.InsertarFilas(hoja, 3, 2); MYGEdicionHoja.InsertarColumnas(hoja, 2);
        Exige(hoja.CeldaTotal == "H18" && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 10m,
            "Insertar antes de los datos debe desplazar el total vinculado y conservar el resultado.");
        MYGEdicionHoja.EliminarFilas(hoja, 5); MYGEdicionHoja.EliminarColumnas(hoja, 2);
        Exige(hoja.CeldaTotal == "G17" && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 4m &&
            !MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida),
            "Eliminar detalles y columnas debe recalcular el vínculo sin volver a seleccionar su dirección.");
        MYGEdicionHoja.MoverRango(hoja, "G17", "J22");
        Entrada(hoja, "G17", "999"); Entrada(hoja, "J23", "4"); Entrada(hoja, "C5", "7");
        Exige(hoja.CeldaTotal == "J22" && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 7m,
            "Mover el total debe seguir su fórmula sin confundir su antigua dirección ni otros valores iguales.");
        MYGEdicionHoja.EliminarFilas(hoja, 1); MYGEdicionHoja.EliminarColumnas(hoja, 1);
        Exige(hoja.CeldaTotal == "I21" && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 7m,
            "Eliminar filas y columnas anteriores debe reubicar el total trasladado y sus referencias.");
        MYGEdicionHoja.Combinar(hoja, "H21:I21");
        Exige(hoja.CeldaTotal == "H21" && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 7m &&
            hoja.Celdas["I21"].Contenido == "",
            "Combinar debe seguir el resultado total cuando su fórmula se traslada al ancla.");
        MYGEdicionHoja.Separar(hoja, "H21:I21");
        Entrada(hoja, "G21", "Otro contenido"); string antes = Datos(hoja); bool rechazado = false;
        try { MYGEdicionHoja.Combinar(hoja, "G21:H21"); }
        catch (InvalidDataException) { rechazado = true; }
        Exige(rechazado && Datos(hoja) == antes && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 7m,
            "Una combinación no debe sustituir el total por otro contenido ni modificar parcialmente la hoja.");
        Entrada(hoja, "B4", "0");
        Exige(MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 0m && partida.Costos.Cantidad == 10m,
            "Una hoja ya vinculada debe reflejar también un total que baja a cero sin restaurar la cantidad anterior.");
        pasa("El total vinculado sigue inserciones, eliminaciones, movimiento y combinación; evita direcciones antiguas y valores iguales y admite bajar a cero");
    }

    private static void VerificarPersistencia(Action<string> pasa)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg_vinculo_metrado_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            var documento = MYGProyectoStorage.Nuevo("METRADO VINCULADO");
            var presupuesto = documento.Presupuestos[0]; var partida = Nodo(); presupuesto.Items.Add(partida);
            MYGProyectoStorage.Renumerar(presupuesto);
            Entrada(partida.Costos.Hoja, "B3", "2"); Entrada(partida.Costos.Hoja, "C3", "3");
            MYGActualizacionMetradoHoja.Actualizar(presupuesto, partida);
            MYGEdicionHoja.InsertarFilas(partida.Costos.Hoja, 3); MYGEdicionHoja.InsertarColumnas(partida.Costos.Hoja, 2);
            string ruta = Path.Combine(carpeta, "Vínculo.myg.json");
            MYGProyectoStorage.Guardar(ruta, documento);
            foreach (string archivo in new[] { ruta, MYGBaseDatos.RutaDeProyecto(ruta) })
            {
                var reabierto = MYGProyectoStorage.Leer(archivo).Presupuestos[0]; var copia = reabierto.Items.Single();
                Exige(copia.Costos.FuenteMetrado == MYGFuenteMetrado.Excel && copia.Costos.Hoja.CeldaTotal == "H17" &&
                    MYGMotorPresupuestos.Cantidad(reabierto, copia) == 6m,
                    "Guardar y reabrir JSON y SQLite debe conservar el vínculo y la dirección desplazada.");
                Entrada(copia.Costos.Hoja, "D4", "5");
                Exige(MYGMotorPresupuestos.Cantidad(reabierto, copia) == 10m && copia.Costos.Cantidad == 6m &&
                    !MYGActualizacionMetradoHoja.Actualizar(reabierto, copia),
                    "El documento reabierto debe volver a calcular el metrado sin depender del total guardado.");
            }
        }
        finally { Directory.Delete(carpeta, true); }
        pasa("Guardar y reabrir proyectos JSON y SQLite conserva el vínculo dinámico y vuelve a calcular fórmulas tras editar");
    }

    private static void VerificarPartidaActual(Action<string> pasa)
    {
        var (presupuesto, partida) = Nuevo(); Entrada(partida.Costos.Hoja, "G16", "0.6");
        var obsoleta = MYGProyectoStorage.Copia(partida);
        Exige(!MYGActualizacionMetradoHoja.Evaluar(presupuesto, obsoleta).PuedeActualizar,
            "Una instancia antigua con el mismo identificador no debe actualizar la partida actual.");
        RechazaSinCambios(presupuesto, obsoleta, "Una instancia obsoleta modificó el presupuesto.");
        var otro = new MYGPresupuestoDocumento { Nombre = "OTRO" };
        RechazaSinCambios(otro, partida, "Una partida ajena modificó otro presupuesto.");
        var titulo = Nodo(true); presupuesto.Items.Add(titulo); Entrada(titulo.Costos.Hoja, "G16", "0.6");
        RechazaSinCambios(presupuesto, titulo, "Se permitió actualizar un título.");
        presupuesto.Items.Remove(partida);
        RechazaSinCambios(presupuesto, partida, "Se permitió actualizar una partida eliminada.");
        Exige(!MYGActualizacionMetradoHoja.Evaluar(null, partida).PuedeActualizar &&
            !MYGActualizacionMetradoHoja.Evaluar(presupuesto, null).PuedeActualizar,
            "La consulta sin presupuesto o partida debe ocultar la actualización sin fallar.");
        pasa("Actualizar exige la instancia actual de una partida del presupuesto y rechaza títulos, partidas ajenas, eliminadas y obsoletas");
    }
}
