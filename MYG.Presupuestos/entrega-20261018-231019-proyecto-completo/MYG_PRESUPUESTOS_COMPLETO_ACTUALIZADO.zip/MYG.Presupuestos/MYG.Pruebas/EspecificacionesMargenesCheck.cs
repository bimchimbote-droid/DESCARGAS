using System;
using MYG_2027;

internal static class EspecificacionesMargenesCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (ArgumentException) { return; }
        throw new Exception(detalle);
    }

    private static void Comprueba(decimal longitud, decimal inicio, decimal fin, decimal posicion,
        bool moverInicio, decimal esperadoInicio, decimal esperadoFin, string detalle, decimal minimo = 10m)
    {
        var resultado = MYGEspecificacionesMargenes.Arrastrar(longitud, inicio, fin, posicion, moverInicio, minimo);
        Exige(resultado == (esperadoInicio, esperadoFin), detalle);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        foreach (var caso in new[]
        {
            (Horizontal: false, Ancho: 210m, Alto: 297m, PosicionDerecha: 165m, PosicionInferior: 262m),
            (Horizontal: true, Ancho: 297m, Alto: 210m, PosicionDerecha: 252m, PosicionInferior: 175m)
        })
        {
            var pagina = new MYGPaginaEspecificacion { Horizontal = caso.Horizontal };
            decimal ancho = pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm;
            decimal alto = pagina.Horizontal ? pagina.AnchoMm : pagina.AltoMm;
            Exige(ancho == caso.Ancho && alto == caso.Alto, "La hoja A4 no tiene las dimensiones de su orientación.");
            Comprueba(ancho, 25m, 25m, 32.5m, true, 32.5m, 25m,
                "Arrastrar el margen izquierdo no sigue la posición o altera el derecho.");
            Comprueba(ancho, 25m, 25m, caso.PosicionDerecha, false, 25m, 45m,
                "Arrastrar el margen derecho no sigue la posición o altera el izquierdo.");
            Comprueba(alto, 25m, 25m, 30m, true, 30m, 25m,
                "Arrastrar el margen superior no sigue la posición o altera el inferior.");
            Comprueba(alto, 25m, 25m, caso.PosicionInferior, false, 25m, 35m,
                "Arrastrar el margen inferior no sigue la posición o altera el superior.");
        }
        pasa("Los cuatro márgenes se arrastran con medidas físicas en A4 vertical y horizontal sin mover el opuesto");

        foreach (var caso in new[]
        {
            (Longitud: 210m, Maximo: 175m, PosicionFin: 35m),
            (Longitud: 297m, Maximo: 262m, PosicionFin: 35m)
        })
        {
            Comprueba(caso.Longitud, 25m, 25m, -50m, true, 0m, 25m,
                "El margen inicial arrastrado fuera de la hoja debe quedar en cero.");
            Comprueba(caso.Longitud, 25m, 25m, 1000m, true, caso.Maximo, 25m,
                "El margen inicial debe dejar al menos 10 mm de texto sin alterar el opuesto.");
            Comprueba(caso.Longitud, 25m, 25m, 1000m, false, 25m, 0m,
                "El margen final arrastrado fuera de la hoja debe quedar en cero.");
            Comprueba(caso.Longitud, 25m, 25m, -50m, false, 25m, caso.Maximo,
                "El margen final debe dejar al menos 10 mm de texto sin alterar el opuesto.");
            Comprueba(caso.Longitud, 25m, 25m, caso.Maximo, true, caso.Maximo, 25m,
                "El límite exacto de 10 mm de texto debe poder alcanzarse con el margen inicial.");
            Comprueba(caso.Longitud, 25m, 25m, caso.PosicionFin, false, 25m, caso.Maximo,
                "El límite exacto de 10 mm de texto debe poder alcanzarse con el margen final.");
        }
        Comprueba(210m, 25m, 25m, 200m, true, 155m, 25m,
            "Un mínimo de texto personalizado no se respetó.", 30m);
        Comprueba(210m, 25m, 25m, 0m, false, 25m, 155m,
            "Un mínimo personalizado no se respetó al mover el margen final.", 30m);
        Comprueba(10m, 0m, 0m, 5m, true, 0m, 0m,
            "Una hoja del tamaño mínimo no debe perder su área de texto.");
        pasa("El arrastre limita posiciones negativas y externas y conserva el área de texto mínima y el margen opuesto");

        Comprueba(210m, 90m, 115m, 209m, true, 90m, 115m,
            "Una hoja heredada con 5 mm de texto no debe empeorar ni desplazar el margen derecho.");
        Comprueba(210m, 90m, 115m, -100m, false, 90m, 115m,
            "Una hoja heredada con 5 mm de texto no debe empeorar ni desplazar el margen izquierdo.");
        Comprueba(210m, 90m, 115m, 85m, true, 85m, 115m,
            "Debe poder ampliarse el área de texto heredada moviendo el margen izquierdo.");
        Comprueba(210m, 90m, 115m, 100m, false, 90m, 110m,
            "Debe poder ampliarse el área de texto heredada moviendo el margen derecho.");
        Comprueba(297m, 140m, 153m, 290m, true, 140m, 153m,
            "Una hoja heredada de 4 mm no debe perder texto al arrastrar el inicio.");
        Comprueba(297m, 140m, 153m, 0m, false, 140m, 153m,
            "Una hoja heredada de 4 mm no debe perder texto al arrastrar el fin.");
        pasa("Las páginas heredadas con menos de 10 mm conservan su área útil y permiten ampliarla sin mover el margen opuesto");

        foreach (var caso in new[]
        {
            (Longitud: 0m, Inicio: 0m, Fin: 0m, Minimo: 10m),
            (Longitud: -210m, Inicio: 0m, Fin: 0m, Minimo: 10m),
            (Longitud: 210m, Inicio: -1m, Fin: 25m, Minimo: 10m),
            (Longitud: 210m, Inicio: 25m, Fin: -1m, Minimo: 10m),
            (Longitud: 210m, Inicio: 210m, Fin: 0m, Minimo: 10m),
            (Longitud: 210m, Inicio: 100m, Fin: 110m, Minimo: 10m),
            (Longitud: 210m, Inicio: 100m, Fin: 111m, Minimo: 10m),
            (Longitud: 210m, Inicio: decimal.MaxValue, Fin: 0m, Minimo: 10m),
            (Longitud: 210m, Inicio: 0m, Fin: decimal.MaxValue, Minimo: 10m),
            (Longitud: 210m, Inicio: 25m, Fin: 25m, Minimo: 0m),
            (Longitud: 210m, Inicio: 25m, Fin: 25m, Minimo: -1m),
            (Longitud: 210m, Inicio: 25m, Fin: 25m, Minimo: 211m)
        })
            foreach (bool moverInicio in new[] { true, false })
                Rechaza(() => MYGEspecificacionesMargenes.Arrastrar(caso.Longitud, caso.Inicio, caso.Fin,
                    50m, moverInicio, caso.Minimo), "El arrastre aceptó una página, margen o mínimo de texto inválido.");
        pasa("El arrastre rechaza tamaños, márgenes y mínimos inválidos en ambos extremos de la página");

        Persistencia(pasa);
    }

    private static void Persistencia(Action<string> pasa)
    {
        const string cuerpo = @"{\rtf1\ansi{\fonttbl{\f0 Arial Narrow;}}{\*\otraextension intacta}" +
            @"\f0\fs22 01.02 PARTIDA ACTUAL\par \b DESCRIPCI\'d3N:\b0\par Texto con \u241? y \{llaves\}" +
            @"\par \trowd\cellx2400\cellx4800\intbl Material\cell Unidad\cell\row}";
        var pagina = new MYGPaginaEspecificacion { Horizontal = true, NumerarPaginas = true,
            Encabezado = "Proyecto actual / partida", Pie = "Especificación técnica — m³" };
        string anterior = MYGEspecificacionesPagina.Guardar(cuerpo, pagina);
        (pagina.MargenIzquierdoMm, pagina.MargenDerechoMm) =
            MYGEspecificacionesMargenes.Arrastrar(297m, 25m, 25m, 32.5m, true);
        (pagina.MargenIzquierdoMm, pagina.MargenDerechoMm) =
            MYGEspecificacionesMargenes.Arrastrar(297m, pagina.MargenIzquierdoMm, pagina.MargenDerechoMm, 257m, false);
        (pagina.MargenSuperiorMm, pagina.MargenInferiorMm) =
            MYGEspecificacionesMargenes.Arrastrar(210m, 25m, 25m, 16.25m, true);
        (pagina.MargenSuperiorMm, pagina.MargenInferiorMm) =
            MYGEspecificacionesMargenes.Arrastrar(210m, pagina.MargenSuperiorMm, pagina.MargenInferiorMm, 183.5m, false);
        MYGEspecificacionesPagina.Validar(pagina);
        string guardado = MYGEspecificacionesPagina.Guardar(anterior, pagina);
        var leido = MYGEspecificacionesPagina.Leer(guardado);
        Exige(leido.MargenIzquierdoMm == 32.5m && leido.MargenDerechoMm == 40m &&
            leido.MargenSuperiorMm == 16.25m && leido.MargenInferiorMm == 26.5m,
            "Guardar y leer la página no conservó los cuatro márgenes arrastrados.");
        Exige(leido.AnchoMm == 210m && leido.AltoMm == 297m && leido.Horizontal && leido.NumerarPaginas &&
            leido.Encabezado == pagina.Encabezado && leido.Pie == pagina.Pie,
            "Arrastrar y persistir los márgenes alteró tamaño, orientación, numeración, encabezado o pie.");
        Exige(MYGEspecificacionesPagina.QuitarMetadatos(guardado) == cuerpo,
            "Persistir los márgenes reescribió el texto, formato, tabla o extensiones del documento.");
        Exige(MYGEspecificacionesPagina.Guardar(guardado, leido) == guardado,
            "Guardar los márgenes de nuevo acumuló metadatos o alteró el documento.");
        Exige(MYGEspecificacionesPagina.Leer(anterior).MargenIzquierdoMm == 25m,
            "La edición de márgenes modificó la versión anterior del documento.");
        pasa("Los márgenes arrastrados completan el ciclo RTF sin cambiar el cuerpo ni las demás propiedades de página");
    }
}
