using System;
using System.IO;
using System.Linq;
using System.Text;
using MYG_2027;

internal static class EspecificacionesPaginaCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (ArgumentException) { return; }
        throw new Exception(detalle);
    }

    private static bool EsPredeterminada(MYGPaginaEspecificacion p) => p.AnchoMm == 210m && p.AltoMm == 297m &&
        p.MargenIzquierdoMm == 25m && p.MargenDerechoMm == 25m && p.MargenSuperiorMm == 25m &&
        p.MargenInferiorMm == 25m && !p.Horizontal && !p.NumerarPaginas && p.Encabezado == "" && p.Pie == "";

    private static string Metadatos(string json) => @"{\rtf1{\*\mygpagina " +
        Convert.ToBase64String(Encoding.UTF8.GetBytes(json)) + @"}\ansi Texto intacto}";

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        const string rtf = @"{\rtf1\ansi\ansicpg1252{\fonttbl{\f0 Arial;}}{\*\otraextension original}" +
            @"\f0\fs22 ESPECIFICACI\'d3N \u233? técnica — m³\par \b Materiales\b0 " +
            @"\{\*\mygpagina NO ES UN GRUPO\}\par {\pict\bin4 {}\a} Fin}";
        Exige(EsPredeterminada(MYGEspecificacionesPagina.Leer(rtf)) &&
            EsPredeterminada(MYGEspecificacionesPagina.Leer(null)), "Una especificación antigua no recibió la página A4 predeterminada.");
        var a = new MYGPaginaEspecificacion { AnchoMm = 215.9m, AltoMm = 279.4m, Horizontal = true,
            MargenIzquierdoMm = 18.5m, MargenDerechoMm = 21m, MargenSuperiorMm = 12m, MargenInferiorMm = 15m,
            Encabezado = "Obra: Cimentación — Chimbote {A}", Pie = "Especificación de hormigón / m³", NumerarPaginas = true };
        string guardado = MYGEspecificacionesPagina.Guardar(rtf, a);
        var leido = MYGEspecificacionesPagina.Leer(guardado);
        Exige(leido.AnchoMm == a.AnchoMm && leido.AltoMm == a.AltoMm && leido.Horizontal && leido.NumerarPaginas &&
            leido.MargenIzquierdoMm == a.MargenIzquierdoMm && leido.MargenDerechoMm == a.MargenDerechoMm &&
            leido.MargenSuperiorMm == a.MargenSuperiorMm && leido.MargenInferiorMm == a.MargenInferiorMm &&
            leido.Encabezado == a.Encabezado && leido.Pie == a.Pie, "La configuración de página no completó el ciclo RTF.");
        Exige(MYGEspecificacionesPagina.QuitarMetadatos(guardado) == rtf, "Guardar página modificó texto, Unicode, escapes, imágenes o destinos ajenos.");
        pasa("Página por especificación conserva configuración, Unicode, contenido RTF y extensiones ajenas sin reescribirlos");

        for (int n = 0; n < 20; n++) guardado = MYGEspecificacionesPagina.Guardar(guardado, a);
        Exige(guardado == MYGEspecificacionesPagina.Guardar(rtf, a), "Guardar repetidamente acumula metadatos o modifica el contenido.");
        string grupoDuplicado = guardado.Insert(6, @"{\*\mygpagina corrupto}");
        Exige(MYGEspecificacionesPagina.Guardar(grupoDuplicado, a) == guardado,
            "Guardar no reemplazó todos los metadatos propios anteriores.");
        a.Pie = "Pie corregido";
        guardado = MYGEspecificacionesPagina.Guardar(guardado, a);
        Exige(MYGEspecificacionesPagina.Leer(guardado).Pie == "Pie corregido" &&
            MYGEspecificacionesPagina.QuitarMetadatos(guardado) == rtf, "Cambiar el pie pierde el contenido o conserva una configuración anterior.");
        pasa("Guardar repetidamente y corregir la página reemplaza metadatos anteriores sin aumentar el documento");

        foreach (string invalido in new[]
        {
            @"{\rtf1{\*\mygpagina %%%} Texto}", Metadatos("{malformado"),
            Metadatos("{\"Version\":99,\"Pagina\":{\"AnchoMm\":300}}"),
            Metadatos("{\"Version\":1,\"Pagina\":{\"AnchoMm\":0}}"),
            Metadatos("{\"Version\":1,\"Pagina\":null}"), @"{\rtf1{\*\mygpagina MISSING}", "texto plano"
        })
            Exige(EsPredeterminada(MYGEspecificacionesPagina.Leer(invalido)), "Metadatos corruptos o futuros afectaron la apertura de la especificación.");
        var independiente = MYGEspecificacionesPagina.Leer(rtf); independiente.Encabezado = "Cambio local";
        Exige(EsPredeterminada(MYGEspecificacionesPagina.Leer(rtf)), "Las especificaciones antiguas comparten la misma página mutable.");
        pasa("Metadatos ausentes, corruptos o futuros se leen de forma segura con páginas predeterminadas independientes");

        Rechaza(() => MYGEspecificacionesPagina.Guardar("texto plano", a), "Se aceptó texto plano como RTF.");
        Rechaza(() => MYGEspecificacionesPagina.Guardar(@"{\rtf1\b Incompleto", a), "Se aceptó un documento RTF incompleto.");
        Rechaza(() => MYGEspecificacionesPagina.Guardar(@"{\rtf1} contenido externo", a), "Se aceptó contenido fuera del documento RTF.");
        Rechaza(() => MYGEspecificacionesPagina.Validar(null), "Se aceptó una configuración de página nula.");
        Rechaza(() => MYGEspecificacionesPagina.Validar(new() { AnchoMm = 0 }), "Se aceptó una hoja de ancho cero.");
        Rechaza(() => MYGEspecificacionesPagina.Validar(new() { AltoMm = 2001 }), "Se aceptó una hoja fuera del tamaño soportado.");
        Rechaza(() => MYGEspecificacionesPagina.Validar(new() { MargenIzquierdoMm = -1 }), "Se aceptó un margen negativo.");
        Rechaza(() => MYGEspecificacionesPagina.Validar(new() { MargenIzquierdoMm = 185 }), "Se aceptó una hoja sin ancho imprimible.");
        Rechaza(() => MYGEspecificacionesPagina.Validar(new() { MargenDerechoMm = decimal.MaxValue }), "Se aceptó un margen extremo.");
        Rechaza(() => MYGEspecificacionesPagina.Validar(new() { Encabezado = new string('a', 2001) }), "Se aceptó un encabezado excesivo.");
        MYGEspecificacionesPagina.Validar(new() { Horizontal = true, MargenIzquierdoMm = 220 });
        Rechaza(() => MYGEspecificacionesPagina.Validar(new() { Horizontal = true, MargenSuperiorMm = 200 }),
            "La orientación horizontal no se aplicó al área imprimible.");
        pasa("Validación rechaza RTF incompleto, tamaños y márgenes inválidos y respeta la orientación de la hoja");

        Persistencia(carpeta, rtf, guardado, pasa);
    }

    private static void Persistencia(string carpeta, string rtf, string primeraRtf, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("OBRA CON ESPECIFICACIONES");
        var presupuesto = documento.Presupuestos[0];
        string segundaRtf = MYGEspecificacionesPagina.Guardar(rtf, new MYGPaginaEspecificacion
        { Encabezado = "Segunda partida", MargenIzquierdoMm = 30m });
        foreach (var datos in new[] { (Nombre: "CONCRETO", Rtf: primeraRtf), (Nombre: "ACERO", Rtf: segundaRtf) })
        {
            string id = MYGProyectoStorage.NuevoId();
            presupuesto.Items.Add(new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
                Descripcion = datos.Nombre, TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Unidad = "m³",
                Costos = new MYGDatosPartida { EspecificacionRtf = datos.Rtf, EspecificacionTexto = "Especificación técnica" } });
        }
        MYGProyectoStorage.Renumerar(presupuesto);
        string ruta = Path.Combine(carpeta, "Especificaciones independientes.myg.json");
        MYGProyectoStorage.Guardar(ruta, documento);
        foreach (string archivo in new[] { ruta, MYGBaseDatos.RutaDeProyecto(ruta) })
        {
            var partidas = MYGProyectoStorage.Leer(archivo).Presupuestos[0].Items;
            Exige(partidas.Count == 2 && partidas[0].Costos.EspecificacionRtf == primeraRtf &&
                partidas[1].Costos.EspecificacionRtf == segundaRtf, "Guardar y reabrir JSON/SQLite mezcló las especificaciones de dos partidas.");
            Exige(MYGEspecificacionesPagina.Leer(partidas[0].Costos.EspecificacionRtf).Pie == "Pie corregido" &&
                MYGEspecificacionesPagina.Leer(partidas[1].Costos.EspecificacionRtf).Encabezado == "Segunda partida" &&
                MYGEspecificacionesPagina.Leer(partidas[1].Costos.EspecificacionRtf).MargenIzquierdoMm == 30m,
                "La persistencia no conservó las páginas independientes de las partidas.");
        }
        var copia = MYGProyectoStorage.CopiarComoPlantilla(presupuesto, "OTRA OBRA");
        Exige(copia.Items.Select(i => i.Costos.EspecificacionRtf).SequenceEqual(new[] { primeraRtf, segundaRtf }),
            "Copiar el presupuesto como plantilla perdió las páginas de sus especificaciones.");
        pasa("JSON, SQLite y copias de presupuestos conservan especificaciones y páginas independientes por partida");
    }
}
