using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class GuardarComoDelphinCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open(); return c;
    }

    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static string Identificador(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";

    private static string Instantanea(string ruta, string consulta)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand(); cmd.CommandText = consulta;
        using var r = cmd.ExecuteReader(); var filas = new List<string>();
        while (r.Read())
        {
            var valores = new object[r.FieldCount];
            for (int n = 0; n < valores.Length; n++) valores[n] = r.IsDBNull(n) ? null : r.GetValue(n);
            filas.Add(JsonSerializer.Serialize(valores));
        }
        filas.Sort(StringComparer.Ordinal);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("\n", filas))));
    }

    private static Dictionary<string, string> CapturarNativas(string ruta)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'myg_%' " +
            "AND name NOT IN ('partida_presupuesto','insumo_presupuesto','recurso_presupuesto') " +
            "AND name NOT LIKE 'catalogo_%' ORDER BY name";
        using var r = cmd.ExecuteReader(); var tablas = new List<string>();
        while (r.Read()) tablas.Add(r.GetString(0));
        return tablas.ToDictionary(x => x, x => Instantanea(ruta, "SELECT * FROM " + Identificador(x)));
    }

    private static void Conservar(string ruta, Dictionary<string, string> antes)
    {
        foreach (var tabla in antes)
            Exige(Instantanea(ruta, "SELECT * FROM " + Identificador(tabla.Key)) == tabla.Value,
                "Guardar como alteró o perdió una tabla nativa: " + tabla.Key + ".");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string origen = Path.Combine(carpeta, "Hoja completa origen guardar como.sqlite");
        var documento = MYGProyectoStorage.Nuevo("OBRA PARA GUARDAR COMO");
        documento.Datos = MYGDatosProyecto.Crear();
        var otra = MYGProyectoStorage.Nuevo("OTRA OBRA DE LA MISMA HOJA");
        MYGProyectoStorage.Guardar(origen, documento); MYGProyectoStorage.Guardar(origen, otra);
        using (var c = Conexion(origen, true))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = """
                INSERT INTO calendario(id_calendario,nombre_calendario) VALUES(77,'CALENDARIO CONSERVADO');
                CREATE TABLE extension_delphin_futura(id INTEGER PRIMARY KEY,descripcion TEXT,contenido BLOB);
                INSERT INTO extension_delphin_futura VALUES(11,'Programación y adjunto no representados',X'00010200FF');
                CREATE VIEW vista_extension_delphin AS SELECT id,contenido FROM extension_delphin_futura;
                CREATE TRIGGER conservar_extension_delphin AFTER INSERT ON extension_delphin_futura
                    WHEN NEW.descripcion IS NULL BEGIN UPDATE extension_delphin_futura SET descripcion='Sin descripción' WHERE id=NEW.id; END;
                PRAGMA user_version=4242;
                PRAGMA application_id=1297696519;
                """;
            cmd.ExecuteNonQuery();
        }
        documento.Datos.CalendarioId = 77; documento.Datos.Calendario = "CALENDARIO CONSERVADO";
        MYGProyectoStorage.Guardar(origen, documento);
        var nativas = CapturarNativas(origen);
        string esquema = Instantanea(origen, "SELECT type,name,tbl_name,sql FROM sqlite_master");
        string huella = Huella(origen);
        string firmaOtra = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(origen, otra.Id));
        string copia = Path.Combine(carpeta, "Hoja completa destino guardar como.sqlite");
        using (File.Create(copia)) { }
        MYGProyectoStorage.Guardar(copia, documento, origen);
        Exige(Huella(origen) == huella, "Guardar como modificó la hoja original.");
        Exige(Instantanea(copia, "SELECT type,name,tbl_name,sql FROM sqlite_master") == esquema,
            "Guardar como perdió tablas, vistas, índices o desencadenadores de la hoja original.");
        Conservar(copia, nativas);
        Exige(MYGBaseDatos.ListarProyectos(copia).Count == 2 &&
            MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(copia, otra.Id)) == firmaOtra &&
            MYGBaseDatos.LeerProyecto(copia, documento.Id).Datos.CalendarioId == 77,
            "Guardar como perdió otra obra o el calendario referenciado.");
        using (var c = Conexion(copia))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "PRAGMA user_version";
            Exige(Convert.ToInt32(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) == 4242,
                "Guardar como no conservó la revisión privada del archivo.");
            cmd.CommandText = "PRAGMA application_id";
            Exige(Convert.ToInt32(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) == 1297696519,
                "Guardar como no conservó el identificador SQLite de la aplicación.");
        }
        documento.Nombre += " ACTUALIZADA";
        string editada = Path.Combine(carpeta, "Hoja completa destino editado.sqlite");
        MYGProyectoStorage.Guardar(editada, documento, origen);
        Exige(MYGBaseDatos.LeerProyecto(editada, documento.Id).Nombre == documento.Nombre &&
            MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(editada, otra.Id)) == firmaOtra &&
            Instantanea(editada, "SELECT * FROM extension_delphin_futura") == nativas["extension_delphin_futura"] &&
            Huella(origen) == huella,
            "Guardar como no aplicó los cambios propios conservando los datos ajenos y el origen.");
        pasa("Guardar como conserva hoja SQLite completa, otras obras, calendarios, adjuntos, vistas y revisiones mientras aplica cambios propios");

        var invalido = MYGProyectoStorage.Copia(documento);
        invalido.Datos.CalendarioId = 99999;
        string fallido = Path.Combine(carpeta, "Destino que no debe publicarse.sqlite");
        bool rechazo = false;
        try { MYGProyectoStorage.Guardar(fallido, invalido, origen); }
        catch (InvalidDataException) { rechazo = true; }
        Exige(rechazo && !File.Exists(fallido) && Directory.GetFiles(carpeta, Path.GetFileName(fallido) + ".*.tmp*").Length == 0 &&
            Huella(origen) == huella, "Un Guardar como fallido publicó una hoja parcial o alteró el origen.");
        pasa("Un fallo al guardar la copia descarta el destino temporal y conserva intacto el archivo original");

        var independiente = MYGProyectoStorage.Nuevo("PROYECTO QUE USA SÓLO EL CATÁLOGO");
        string catalogo = Path.Combine(carpeta, "Destino con catálogo independiente.sqlite");
        MYGProyectoStorage.Guardar(catalogo, independiente, origen);
        Exige(MYGBaseDatos.ListarProyectos(catalogo).Single().Id == independiente.Id,
            "Usar una hoja ajena como catálogo copió proyectos que no se estaban guardando.");
        pasa("Copiar un catálogo de otra hoja sigue creando únicamente el proyecto solicitado");

        ComprobarWAL(carpeta, pasa);
        ComprobarPieCopiado(carpeta, pasa);

        string muestra = Environment.GetEnvironmentVariable("MYG_QA_LLACUSBAMBA_SQLITE");
        if (!string.IsNullOrWhiteSpace(muestra)) ComprobarMuestra(Path.GetFullPath(muestra), carpeta, pasa);
    }

    private static void ComprobarPieCopiado(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Hoja con presupuesto y pie copiados.sqlite");
        var documento = MYGProyectoStorage.Nuevo("OBRA CON PIE COPIADO");
        var presupuesto = documento.Presupuestos[0];
        presupuesto.Costos.PieDelphin = new()
        {
            ProyectoId = documento.Id,
            Filas = new()
            {
                new() { IdTitulo = "1", Clave = "porcentaje_gsgs", Nombre = "Gastos", Tipo = "C", Porcentaje = 10, Posicion = 1 },
                new() { IdTitulo = "2", Clave = "total_pie", Nombre = "Total", Tipo = "F", Formula = "[costo_directo]+[monto_gsgs]", Posicion = 2 }
            }
        };
        MYGProyectoStorage.Guardar(ruta, documento);
        string originales = Instantanea(ruta, "SELECT * FROM titulo_pie WHERE id_titulo IN (1,2)");
        var copia = MYGProyectoStorage.CopiarComoPlantilla(presupuesto, "PRESUPUESTO COPIADO");
        copia.Item = "02"; copia.Posicion = 2; documento.Presupuestos.Add(copia);
        MYGProyectoStorage.Guardar(ruta, documento);
        string todas = Instantanea(ruta, "SELECT * FROM titulo_pie");
        MYGProyectoStorage.Guardar(ruta, documento);
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM titulo_pie";
        Exige(Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) == 4 &&
            Instantanea(ruta, "SELECT * FROM titulo_pie WHERE id_titulo IN (1,2)") == originales &&
            Instantanea(ruta, "SELECT * FROM titulo_pie") == todas,
            "Copiar un presupuesto reutilizó las filas del pie original o las duplicó al guardar otra vez.");
        pasa("Copiar un presupuesto asigna filas nativas propias a su pie y repetir el guardado mantiene sus identidades");
    }

    private static void ComprobarWAL(string carpeta, Action<string> pasa)
    {
        string origen = Path.Combine(carpeta, "Hoja origen con WAL pendiente.sqlite");
        string copia = Path.Combine(carpeta, "Hoja copia incluye WAL.sqlite");
        var documento = MYGProyectoStorage.Nuevo("OBRA CON TRANSACCIONES WAL");
        MYGProyectoStorage.Guardar(origen, documento);
        using (var escritor = Conexion(origen, true))
        using (var cmd = escritor.CreateCommand())
        {
            // Se mantiene abierta la conexión para que los cambios confirmados
            // sigan en WAL y una copia simple del archivo principal los pierda.
            cmd.CommandText = "PRAGMA journal_mode=WAL; CREATE TABLE datos_confirmados_wal(valor BLOB); " +
                "INSERT INTO datos_confirmados_wal VALUES(X'001122FF');";
            cmd.ExecuteNonQuery();
            Exige(File.Exists(origen + "-wal") && new FileInfo(origen + "-wal").Length > 0,
                "La prueba no dejó transacciones confirmadas en WAL.");
            string antes = Huella(origen);
            string contenido = Instantanea(origen, "SELECT * FROM datos_confirmados_wal");
            MYGProyectoStorage.Guardar(copia, documento, origen);
            Exige(Instantanea(copia, "SELECT * FROM datos_confirmados_wal") == contenido && Huella(origen) == antes,
                "Guardar como perdió cambios confirmados de WAL o escribió en el origen.");
        }
        pasa("La copia SQLite incluye transacciones confirmadas en WAL sin modificar la hoja de origen");
    }

    private static void ComprobarMuestra(string muestra, string carpeta, Action<string> pasa)
    {
        string huella = Huella(muestra);
        var nativas = CapturarNativas(muestra);
        string esquema = Instantanea(muestra, "SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'");
        var obras = MYGBaseDatos.ListarProyectos(muestra);
        var documento = MYGBaseDatos.LeerProyecto(muestra, obras.OrderByDescending(x => x.CantidadPresupuestos).First().Id);
        string copia = Path.Combine(carpeta, "LLACUSBAMBA guardar como sin reconstruir.sqlite");
        MYGProyectoStorage.Guardar(copia, documento, muestra);
        Conservar(copia, nativas);
        Exige(Huella(muestra) == huella && MYGBaseDatos.ListarProyectos(copia).Count == obras.Count &&
            MYGBaseDatos.LeerProyecto(copia, documento.Id).Presupuestos.Count == documento.Presupuestos.Count,
            "Guardar como la base LLACUSBAMBA alteró el origen o perdió proyectos y presupuestos.");
        // La huella del esquema de origen permanece estable; las extensiones MYG
        // se añaden únicamente en la copia y nunca sustituyen tablas nativas.
        Exige(Instantanea(muestra, "SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'") == esquema,
            "El guardado modificó el esquema del archivo adjunto.");
        pasa("Guardar como BASE_LLACUSBAMBA conserva todas las tablas y datos nativos Delphin y reabre los seis presupuestos");
    }
}
