using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class AlertasPartidaCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static ItemPresupuestoDelphin Nodo(MYGPresupuestoDocumento p, string descripcion = "PARTIDA DE PRUEBA", string unidad = "m²")
    {
        string id = MYGProyectoStorage.NuevoId();
        var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = descripcion,
            Unidad = unidad, TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA" };
        p.Items.Add(i); return i;
    }
    private static void Recurso(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i, decimal precio = 10m)
    {
        var insumo = new MYGInsumo { Codigo = "I-" + p.Costos.Insumos.Count, Descripcion = "MATERIAL", Unidad = "kg", Precio = precio };
        p.Costos.Insumos.Add(insumo);
        i.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Cantidad = 2m });
    }
    private static MYGDiagnosticoPartida Evaluar(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i,
        MYGEstadoRegistroACU registro = MYGEstadoRegistroACU.Registrado) => MYGAlertasPartida.Evaluar(p, i, registro: registro);
    private static bool Tiene(MYGDiagnosticoPartida d, MYGTipoAlertaPartida t) => d.Alertas.Any(a => a.Tipo == t);

    public static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "ALERTAS" };
        var i = Nodo(p, "hhh", "und");
        string antes = JsonSerializer.Serialize(p);
        var vacia = Evaluar(p, i, MYGEstadoRegistroACU.NoRegistrado);
        Exige(vacia.EsPartida && !vacia.Completa && vacia.Cantidad == 0 && vacia.PrecioUnitario == 0 && vacia.Total == 0 &&
            vacia.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.SinRegistroACU).Mensaje == "ACU no registrado en base de datos :\nhhh" &&
            vacia.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.SinAnalisis).Mensaje == "El costo unitario no tiene análisis" &&
            vacia.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.TotalCero).Mensaje == "El total de la partida es cero" &&
            Tiene(vacia, MYGTipoAlertaPartida.CantidadCero) && Tiene(vacia, MYGTipoAlertaPartida.PrecioCero) &&
            vacia.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.TotalCero).Titulo == "Alerta" &&
            JsonSerializer.Serialize(p) == antes, "La partida vacía debe mostrar las alertas exactas sin modificar el documento.");
        i.Costos.Cantidad = 3; i.Costos.PrecioDirecto = 10;
        var directa = Evaluar(p, i);
        Exige(directa.Total == 30 && !directa.Completa && directa.Alertas.Single().Tipo == MYGTipoAlertaPartida.SinAnalisis &&
            directa.Alertas.Single().Severidad == MYGSeveridadAlertaPartida.Mensaje &&
            !directa.Alertas.Any(a => a.Severidad == MYGSeveridadAlertaPartida.Error),
            "Un precio directo válido debe calcular y mantener el análisis pendiente sin inventar un error.");
        Recurso(p, i);
        var completa = Evaluar(p, i);
        Exige(completa.Completa && completa.Total == 60 && completa.Alertas.Single().Tipo == MYGTipoAlertaPartida.Completa,
            "Una partida registrada con campos, metrado, ACU y total positivos debe superar las comprobaciones.");
        var pendiente = Evaluar(p, i, MYGEstadoRegistroACU.NoRegistrado);
        Exige(!pendiente.Completa && Tiene(pendiente, MYGTipoAlertaPartida.SinRegistroACU) && pendiente.Total == 60,
            "Un total positivo no debe certificar una partida sin registro de ACU.");
        pasa("Alertas exactas de partida vacía, precio directo informativo y comprobación completa sólo con ACU registrado");

        VerificarFuentes(pasa);
        VerificarRecursos(pasa);
        VerificarErrores(pasa);
        VerificarRedondeoYCampos(pasa);
        VerificarCatalogo(carpeta, pasa);
    }

    private static void VerificarFuentes(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento(); var i = Nodo(p); Recurso(p, i);
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        i.Costos.Metrados.Add(new MYGLineaMetrado { Elementos = 2, CantidadPorElemento = 3, Largo = 4 });
        Exige(Evaluar(p, i).Cantidad == 24 && Evaluar(p, i).Total == 480, "Las alertas deben usar el metrado manual real.");
        i.Costos.FuenteMetrado = MYGFuenteMetrado.BIM;
        i.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = "BIM-01", Cantidad = 7, Unidad = i.Unidad });
        Exige(Evaluar(p, i).Cantidad == 7 && Evaluar(p, i).Total == 140, "Las alertas deben usar el metrado BIM real.");
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Excel; i.Costos.Hoja.Poner("G16", "=SUMA(2;3)");
        Exige(Evaluar(p, i).Cantidad == 5 && Evaluar(p, i).Total == 100, "Las alertas deben usar las fórmulas de la hoja Excel.");
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad; i.Costos.Cantidad = 4;
        var calculo = MYGMotorPresupuestos.CrearCalculo(p); calculo.Cantidad(i); calculo.Analizar(i); calculo.TotalPartida(i);
        string antes = JsonSerializer.Serialize(p);
        var d = MYGAlertasPartida.Evaluar(p, i, calculo, MYGEstadoRegistroACU.Registrado);
        Exige(d.Completa && d.Cantidad == 4 && d.Total == 80 && JsonSerializer.Serialize(p) == antes,
            "El diagnóstico debe reutilizar el cálculo de la actualización sin escribir resultados en el documento.");
        var ajeno = new MYGPresupuestoDocumento(); ajeno.Costos.Insumos.Add(new MYGInsumo { Id = p.Costos.Insumos[0].Id, Precio = 1000 });
        Exige(MYGAlertasPartida.Evaluar(p, i, MYGMotorPresupuestos.CrearCalculo(ajeno), MYGEstadoRegistroACU.Registrado).Total == 80,
            "Un cálculo suministrado de otro presupuesto no debe contaminar los importes.");
        pasa("Alertas usan metrado manual, BIM y fórmulas XLS, reutilizan el cálculo de la actualización y no mutan el documento");
    }

    private static void VerificarErrores(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento(); var i = Nodo(p); Recurso(p, i);
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Excel; i.Costos.Hoja.Poner("G16", "=1/0");
        var formula = Evaluar(p, i);
        Exige(formula.Cantidad == null && formula.Total == null && formula.PrecioUnitario == 20 &&
            Tiene(formula, MYGTipoAlertaPartida.ErrorCantidad) && !Tiene(formula, MYGTipoAlertaPartida.CantidadCero) && !Tiene(formula, MYGTipoAlertaPartida.TotalCero),
            "Una fórmula fallida debe conservar importe desconocido, no cantidad ni total falsos de cero.");
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad; i.Costos.Cantidad = 2; i.Costos.Analisis[0].InsumoId = "NO-EXISTE";
        var insumo = Evaluar(p, i);
        Exige(insumo.Cantidad == 2 && insumo.PrecioUnitario == null && insumo.Total == null &&
            Tiene(insumo, MYGTipoAlertaPartida.ErrorAnalisis) && insumo.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.ErrorAnalisis).Detalle.Contains("No existe el insumo"),
            "Un insumo ausente debe identificar el fallo del ACU, sin convertirlo en precio cero.");
        i.Costos.Analisis.Clear(); i.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = "AUSENTE" });
        Exige(Evaluar(p, i).Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.ErrorAnalisis).Detalle.Contains("Subpartida inexistente"),
            "Debe identificarse una subpartida que ya no existe.");
        i.Costos.Analisis[0].SubpartidaIdLocal = i.IdLocalMYG;
        var buena = Nodo(p, "OTRA PARTIDA"); buena.Costos.Cantidad = 2; Recurso(p, buena);
        var calculo = MYGMotorPresupuestos.CrearCalculo(p);
        var circular = MYGAlertasPartida.Evaluar(p, i, calculo, MYGEstadoRegistroACU.Registrado);
        var otra = MYGAlertasPartida.Evaluar(p, buena, calculo, MYGEstadoRegistroACU.Registrado);
        Exige(circular.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.ErrorAnalisis).Detalle.Contains("circular") &&
            otra.Completa && otra.Total == 40, "Un ciclo debe alertar en su partida sin abortar la revisión de las otras.");
        i.Costos = null;
        Exige(Tiene(Evaluar(p, i), MYGTipoAlertaPartida.DatosCostoIncompletos), "Una partida con datos ausentes debe dar diagnóstico sin excepción.");
        pasa("Errores de fórmula, insumo, subpartida y ciclo dan importes desconocidos y no interrumpen las otras partidas");
    }

    private static void VerificarRecursos(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento(); var i = Nodo(p); i.Costos.Cantidad = 2;
        Recurso(p, i); Recurso(p, i, 0);
        var sinPrecio = Evaluar(p, i);
        Exige(sinPrecio.Total == 40 && !sinPrecio.Completa && Tiene(sinPrecio, MYGTipoAlertaPartida.RecursoSinPrecio) &&
            sinPrecio.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.RecursoSinPrecio).Mensaje.Contains("I-1 · MATERIAL") &&
            !sinPrecio.Alertas.Any(a => a.Severidad == MYGSeveridadAlertaPartida.Error),
            "Un total positivo no debe ocultar un insumo sin precio, y éste no es un fallo del cálculo.");
        p.Costos.Insumos[1].Precio = 3;
        Exige(Evaluar(p, i).Completa, "Corregir el precio del insumo debe completar las comprobaciones.");
        i.Costos.Analisis[1].Cantidad = 0;
        Exige(!Evaluar(p, i).Completa && Tiene(Evaluar(p, i), MYGTipoAlertaPartida.RecursoSinCantidad),
            "Una línea de ACU sin cantidad debe indicar qué recurso está pendiente.");
        i.Costos.Analisis[1].Cantidad = 2; p.Costos.Insumos[1].Unidad = "";
        Exige(!Evaluar(p, i).Completa && Tiene(Evaluar(p, i), MYGTipoAlertaPartida.RecursoSinUnidad),
            "Una unidad de recurso vacía debe alertar aunque las cifras sean positivas.");
        p.Costos.Insumos[1].Unidad = "kg";
        var herramientas = new MYGInsumo { Codigo = "EQ-01", Descripcion = "Herramientas", Unidad = "%mo", Grupo = MYGGrupoRecurso.Equipo, Precio = 0 };
        p.Costos.Insumos.Add(herramientas);
        i.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Equipo, InsumoId = herramientas.Id,
            Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 3 });
        var sinBase = Evaluar(p, i);
        Exige(!sinBase.Completa && sinBase.Total == 52 && sinBase.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.RecursoSinPrecio)
            .Mensaje.Contains("base de mano de obra"), "Un porcentaje de mano de obra sin base debe explicar la falta del recurso.");
        var manoObra = new MYGInsumo { Codigo = "MO-01", Descripcion = "Operario", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 5 };
        p.Costos.Insumos.Add(manoObra);
        i.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = manoObra.Id, Cantidad = 2 });
        Exige(Evaluar(p, i).Completa, "Un porcentaje con base real de mano de obra no debe exigir un precio directo de herramienta.");
        var sub = Nodo(p, "SUBPARTIDA SIN UNIDAD", ""); sub.Costos.PrecioDirecto = 1;
        i.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG });
        var subPendiente = Evaluar(p, i);
        Exige(!subPendiente.Completa && subPendiente.Alertas.Single(a => a.Tipo == MYGTipoAlertaPartida.RecursoSinUnidad).Mensaje
            .StartsWith("La subpartida", StringComparison.Ordinal), "El aviso debe distinguir la unidad pendiente de una subpartida.");
        sub.Unidad = "m";
        Exige(Evaluar(p, i).Completa, "Corregir la unidad de la subpartida debe completar las comprobaciones.");
        pasa("Total positivo conserva alertas de insumos y subpartidas sin precio, cantidad o unidad y de porcentajes sin base de mano de obra");
    }

    private static void VerificarRedondeoYCampos(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento(); var i = Nodo(p); Recurso(p, i, 0.5m); i.Costos.Cantidad = 0.004m;
        var redondeo = Evaluar(p, i);
        Exige(redondeo.Cantidad == 0.004m && redondeo.PrecioUnitario == 1 && redondeo.Total == 0 &&
            Tiene(redondeo, MYGTipoAlertaPartida.TotalCero) && !Tiene(redondeo, MYGTipoAlertaPartida.CantidadCero) &&
            !Tiene(redondeo, MYGTipoAlertaPartida.PrecioCero), "El total cero debe respetar el redondeo monetario del presupuesto.");
        i.Costos.Cantidad = 2; i.Descripcion = " "; i.Unidad = "";
        var campos = Evaluar(p, i);
        Exige(!campos.Completa && Tiene(campos, MYGTipoAlertaPartida.DescripcionVacia) && Tiene(campos, MYGTipoAlertaPartida.UnidadVacia),
            "Un importe positivo no debe ocultar la falta de descripción o unidad.");
        i.TipoPropuesta = "TITULO";
        var titulo = Evaluar(p, i);
        Exige(!titulo.EsPartida && !titulo.Completa && titulo.Alertas.Count == 0 && titulo.Cantidad == null && titulo.Total == null &&
            !MYGAlertasPartida.Evaluar(p, null).EsPartida, "Los títulos y filas de presupuesto no deben recibir marcadores de partida.");
        pasa("Alertas respetan el redondeo del total, detectan descripción y unidad pendientes y omiten títulos y filas de presupuesto");
    }

    private static void VerificarCatalogo(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Alertas catálogo actual.sqlite"); MYGBaseDatos.CrearBaseVacia(ruta);
        var p = new MYGPresupuestoDocumento { Nombre = "CATÁLOGO ALERTAS" }; var i = Nodo(p); i.Costos.Cantidad = 2; Recurso(p, i);
        var entrada = MYGCatalogos.GuardarPartida(ruta, p, i, "P-ALERTA-01", i.Descripcion, i.Unidad);
        i.Costos.CatalogoMYGId = entrada.Id; i.Costos.CatalogoMYGRuta = ruta;
        string hash = Huella(ruta), antes = JsonSerializer.Serialize(p);
        var registro = MYGRegistroACUCatalogo.Leer(ruta);
        Exige(registro.Disponible && registro.Estado(i) == MYGEstadoRegistroACU.Registrado &&
            MYGAlertasPartida.Evaluar(p, i, registro: registro.Estado(i)).Completa && Huella(ruta) == hash && JsonSerializer.Serialize(p) == antes,
            "La verificación debe confirmar el ID existente en SQLite sin cambiar base ni documento.");
        var otra = Nodo(p, i.Descripcion); otra.Item = entrada.Codigo; otra.CodigoDelphin = entrada.Codigo;
        Exige(registro.Estado(otra) == MYGEstadoRegistroACU.NoRegistrado,
            "No debe registrarse por coincidencia de descripción, Item de jerarquía o código visible.");
        otra.CodigoCatalogoDelphin = entrada.Codigo;
        Exige(registro.Estado(otra) == MYGEstadoRegistroACU.Registrado, "El código explícito del catálogo debe resolver una entrada cuando no hay ID.");
        otra.IdCatalogoDelphin = entrada.Id;
        Exige(registro.Estado(otra) == MYGEstadoRegistroACU.Registrado, "Debe reconocer el ID de catálogo Delphin existente en la base activa.");
        otra.IdCatalogoDelphin = "ID-ELIMINADO";
        Exige(registro.Estado(otra) == MYGEstadoRegistroACU.NoRegistrado,
            "El ID ausente no debe aceptarse por coincidir con el código de otro registro.");
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            c.Open(); using var cmd = c.CreateCommand();
            cmd.CommandText = "UPDATE catalogo_partida SET precio='999999999999999999999999999999999999999999999'"; cmd.ExecuteNonQuery();
        }
        string catalogoInvalido = Huella(ruta);
        var precioInvalido = MYGRegistroACUCatalogo.Leer(ruta);
        Exige(!precioInvalido.Disponible && precioInvalido.Estado(i) == MYGEstadoRegistroACU.SinVerificar &&
            Huella(ruta) == catalogoInvalido && MYGAlertasPartida.Evaluar(p, i, registro: precioInvalido.Estado(i)).Total == 40,
            "Un registro de catálogo dañado no debe abortar el cálculo de las partidas ni corregir la base.");
        MYGCatalogos.Eliminar(ruta, true, entrada);
        var actualizado = MYGRegistroACUCatalogo.Leer(ruta);
        Exige(actualizado.Estado(i) == MYGEstadoRegistroACU.NoRegistrado && registro.Estado(i) == MYGEstadoRegistroACU.Registrado,
            "Una nueva instantánea debe detectar la eliminación y la anterior mantener su estado por actualización.");
        string ausente = Path.Combine(carpeta, "No debe crearse una base de alertas.sqlite");
        var noExiste = MYGRegistroACUCatalogo.Leer(ausente);
        Exige(!noExiste.Disponible && noExiste.Estado(i) == MYGEstadoRegistroACU.SinVerificar && !File.Exists(ausente) &&
            !MYGRegistroACUCatalogo.Leer(null).Disponible && noExiste.Detalle.Length > 0,
            "Consultar una ruta ausente debe indicar sin verificar y nunca crear SQLite.");
        string invalida = Path.Combine(carpeta, "No es SQLite para alertas.sqlite"); File.WriteAllText(invalida, "contenido inválido");
        string invalidaAntes = Huella(invalida);
        Exige(!MYGRegistroACUCatalogo.Leer(invalida).Disponible && Huella(invalida) == invalidaAntes,
            "Una base inválida debe dar estado sin verificar sin modificarse.");
        var desconocida = MYGAlertasPartida.Evaluar(p, i, registro: noExiste.Estado(i), detalleRegistro: noExiste.Detalle);
        Exige(Tiene(desconocida, MYGTipoAlertaPartida.RegistroACUSinVerificar) && !Tiene(desconocida, MYGTipoAlertaPartida.SinRegistroACU) && !desconocida.Completa,
            "No poder leer SQLite no equivale a demostrar que falta el ACU.");
        pasa("Registro de ACU se verifica en SQLite actual sin escrituras, detecta IDs eliminados y evita coincidencias falsas o crear bases ausentes");
    }
}
