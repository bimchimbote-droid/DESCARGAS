using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

static class ModeloExportacionProjectCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);

    internal static void Ejecutar(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        string documentoAntes = Firma(proyecto), planAntes = Firma(plan);
        var solo = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
        Exige(solo.Recursos.Count == 0 && solo.Asignaciones.Count == 0 &&
            modelo.Tareas.Count == 7 && modelo.Tareas.Select(t => t.Uid).SequenceEqual(Enumerable.Range(1, 7)) &&
            solo.Tareas.SequenceEqual(modelo.Tareas) && solo.Dependencias.SequenceEqual(modelo.Dependencias) &&
            modelo.Tareas[0].Resumen && modelo.Tareas[1].PadreUid == modelo.Tareas[0].Uid &&
            modelo.Tareas[1].Nivel == 2 && modelo.Tareas[1].Esquema == "1.1" && modelo.Tareas[1].Codigo == "0001" &&
            modelo.Tareas[1].DuracionMinutos == 1170 && modelo.Tareas[1].Avance == 37.5m &&
            modelo.Tareas.Single(t => t.IdMYG == "H").Hito && modelo.Tareas.Single(t => t.IdMYG == "H").DuracionMinutos == 0,
            "El modelo Project perdió tareas, jerarquía, duración real, avance o hitos; sólo tareas debe conservar todo excepto los recursos.");
        var manual = modelo.Tareas.Single(t => t.IdMYG == "E");
        Exige(manual.Manual && manual.Inicio == new DateTime(2026, 2, 1, 8, 0, 0) &&
            manual.Fin == new DateTime(2026, 2, 7, 15, 30, 0) && manual.DuracionMinutos == 780 &&
            manual.InicioBase == new DateTime(2025, 12, 30, 8, 0, 0) && manual.FinBase == new DateTime(2026, 1, 2, 15, 30, 0) &&
            manual.DuracionBaseMinutos == 1170 && manual.Notas == "Fechas importadas" &&
            modelo.MinutosPorDia == 390 && modelo.MinutosPorSemana == 1950,
            "El modelo Project recalculó las fechas manuales importadas o perdió línea base, notas o minutos de trabajo.");
        pasa("Modelo directo de Project mantiene jerarquía, duración horaria, hitos, avance fraccionario, fechas manuales y línea base; sólo tareas excluye recursos y asignaciones");

        var material = modelo.Recursos.Single(r => r.Nombre == "Arena QA");
        var trabajador = modelo.Recursos.Single(r => r.Nombre == "Operario QA");
        var porcentaje = modelo.Recursos.Single(r => r.Nombre == "Herramientas QA");
        var aMaterial = modelo.Asignaciones.Single(a => a.RecursoUid == material.Uid);
        var aTrabajo = modelo.Asignaciones.Single(a => a.RecursoUid == trabajador.Uid);
        var aPorcentaje = modelo.Asignaciones.Single(a => a.RecursoUid == porcentaje.Uid);
        Exige(modelo.Recursos.Count == 3 && modelo.Asignaciones.Count == 3 &&
            material.Tipo == 0 && material.Unidad == "m3" && material.Tarifa == 10 && material.Codigo == "0007" &&
            aMaterial.Cantidad == 8 && aMaterial.Unidades == 8 && aMaterial.TrabajoHoras == null && aMaterial.Costo == 80 &&
            trabajador.Tipo == 1 && trabajador.Tarifa == 20 && aTrabajo.TrabajoHoras == 8 &&
            aTrabajo.Costo == 160 && aTrabajo.Unidades == 1 &&
            porcentaje.Tipo == 0 && porcentaje.Unidad == "%mo" && porcentaje.Tarifa == .8m &&
            aPorcentaje.Cantidad == 10 && aPorcentaje.Costo == 8 && aPorcentaje.TrabajoHoras == null && aPorcentaje.Unidades == 10 &&
            modelo.Asignaciones.All(a => modelo.Tareas.Any(t => t.Uid == a.TareaUid && !t.Resumen)) &&
            modelo.Recursos.All(r => r.Nombre != "Sin uso" && r.Nombre != "Precio directo"),
            "La exportación directa no extrajo los insumos/asignaciones reales del ACU o confundió trabajo, material y costo porcentual.");
        Exige(modelo.Dependencias.Count == 4 && modelo.Dependencias.Select(d => d.Tipo).Distinct().Count() == 4 &&
            modelo.Dependencias.Single(d => d.Tipo == MYGTipoVinculo.FC).DesfaseMinutos == 780 &&
            modelo.Dependencias.Single(d => d.Tipo == MYGTipoVinculo.CC).DesfaseMinutos == -390 &&
            modelo.Dependencias.All(d => modelo.Tareas.Any(t => t.Uid == d.TareaUid) && modelo.Tareas.Any(t => t.Uid == d.PredecesoraUid)),
            "La exportación directa perdió vínculos FC/CC/FF/CF, sus extremos o los desfases en minutos.");
        pasa("Modelo directo de Project extrae recursos reales y subanálisis del ACU, asigna cantidades/trabajo/costos correctos y mantiene las cuatro dependencias con desfases");

        Exige(Firma(proyecto) == documentoAntes && Firma(plan) == planAntes &&
            Firma(MYGExportacionCronograma.PrepararProject(proyecto, plan, true)) == Firma(modelo),
            "Preparar Project modificó documentos o no produjo identidades deterministas.");
        bool bloqueada = false;
        try { ((IList<MYGTareaExportacionProject>)modelo.Tareas)[0] = modelo.Tareas[1]; }
        catch (NotSupportedException) { bloqueada = true; }
        plan.Tareas[1].Nombre = "Modificada después";
        plan.Calendario.HorasPorDia = 2;
        proyecto.Presupuestos[0].Costos.Insumos[0].Precio = 999;
        Exige(bloqueada && modelo.Tareas[1].Nombre == "Excavación QA" && modelo.MinutosPorDia == 390 && material.Tarifa == 10,
            "La instantánea directa retiene referencias editables al documento o permite reemplazar sus listas.");
        pasa("Preparar Project es determinista, conserva el origen y entrega una instantánea independiente con listas de sólo lectura");

        proyecto = Datos(out plan);
        proyecto.Presupuestos[0].Costos.Insumos.Clear();
        bool rechazada = false;
        var tareasSinAnalisis = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        try { MYGExportacionCronograma.PrepararProject(proyecto, plan, true); }
        catch (InvalidDataException) { rechazada = true; }
        Exige(tareasSinAnalisis.Tareas.Count == plan.Tareas.Count && tareasSinAnalisis.Recursos.Count == 0 && rechazada,
            "Sólo tareas validó recursos que no debe exportar, o con recursos aceptó un análisis con insumos inexistentes.");
        plan.Tareas.Single(t => t.Id == "B").Predecesoras[0].PredecesoraId = "NO EXISTE";
        rechazada = false;
        try { MYGExportacionCronograma.PrepararProject(proyecto, plan, false); }
        catch (InvalidDataException) { rechazada = true; }
        Exige(rechazada, "Sólo tareas omitió validar las dependencias del cronograma.");
        pasa("Sólo tareas omite el cálculo de recursos incluso con ACU inválido, pero sigue validando las tareas y dependencias");

        ComprobarCalendario(pasa);
        ComprobarRecursosDelphin(pasa);
        ComprobarPorcentajesConSubanalisis(pasa);
        ComprobarDuracionAutomaticaImportada(pasa);
        ComprobarDuracionAutomaticaPorTramos(pasa);
        ComprobarTramosConHitoInicial(pasa);
        ComprobarFechasImportadasConVinculos(pasa);
        ComprobarLiberacionDeFechasImportadas(pasa);
    }

    private static void ComprobarRecursosDelphin(Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Recursos Delphin QA");
        var p = proyecto.Presupuestos.Single();
        MYGInsumo Insumo(string id, string codigo, string nombre, string unidad, decimal precio, MYGGrupoRecurso grupo)
        {
            var insumo = new MYGInsumo { Id = id, Codigo = codigo, Descripcion = nombre, Unidad = unidad, Precio = precio, Grupo = grupo };
            p.Costos.Insumos.Add(insumo); return insumo;
        }
        var operario = Insumo("O", "Z9", "OPERARIO", "hh", 10, MYGGrupoRecurso.ManoObra);
        var peon = Insumo("P", "Z8", "PEON", "hh", 20, MYGGrupoRecurso.ManoObra);
        var clavos = Insumo("C", "Z7", "CLAVOS PARA MADERA CON CABEZA DE 3\"", "kg", 10.3m, MYGGrupoRecurso.Materiales);
        var cemento = Insumo("CE", "Z6", "CEMENTO PORTLAND TIPO I (42.5 kg)", "bol", 43, MYGGrupoRecurso.Materiales);
        var hormigon = Insumo("H", "Z5", "HORMIGON", "m³", 85, MYGGrupoRecurso.Materiales);
        var gigantografia = Insumo("G", "Z4", "GIGANTOGRAFIA DE 2.40X3.60 M.", "und", 300, MYGGrupoRecurso.Materiales);
        var madera = Insumo("M", "Z3", "MADERA TORNILLO", "p²", 5, MYGGrupoRecurso.Materiales);
        var herramientas = Insumo("HE", "Z2", "HERRAMIENTAS MANUALES 46", "%mo", 0, MYGGrupoRecurso.Equipo);
        ItemPresupuestoDelphin Partida(string id, decimal horasPeon, decimal porcentaje, decimal parcialHerramientas, decimal conciliacion)
        {
            var item = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, Descripcion = id, Unidad = "und", TipoPropuesta = "PARTIDA" };
            item.Costos.Cantidad = 1;
            void Recurso(MYGInsumo insumo, decimal cantidad, decimal parcial, bool porcentual = false) =>
                item.Costos.Analisis.Add(new() { InsumoId = insumo.Id, Grupo = insumo.Grupo, Cantidad = cantidad,
                    ParcialImportadoDelphin = parcial, Modo = porcentual ? MYGModoCantidad.PorcentajeManoObra : MYGModoCantidad.Directa });
            Recurso(operario, 4, 40); Recurso(peon, horasPeon, horasPeon * 20);
            if (id == "N1")
            {
                Recurso(clavos, .6m, 6.18m); Recurso(cemento, 1, 43); Recurso(hormigon, .1m, 8.5m);
                Recurso(gigantografia, 1, 300); Recurso(madera, 10, 50);
            }
            Recurso(herramientas, porcentaje, parcialHerramientas, true);
            item.Costos.PrecioImportadoDelphin = item.Costos.Analisis.Sum(r => r.ParcialImportadoDelphin.Value) + conciliacion;
            p.Items.Add(item);
            item.Costos.FirmaAnalisisImportadoDelphin = MYGMotorPresupuestos.FirmaAnalisis(p, item);
            return item;
        }
        var primera = Partida("N1", 4, 1, 6, 0);
        var segunda = Partida("N2", 8, 5, 10, .01m);
        var plan = new MYGCronograma
        {
            FechaInicio = new DateTime(2023, 5, 2), FechaEstado = new DateTime(2023, 5, 2),
            Tareas = new()
            {
                new() { Id = "N1", Nombre = "Cartel", DuracionDias = 2, PresupuestoId = p.Id, PartidaId = primera.Id },
                new() { Id = "N2", Nombre = "Otra partida", DuracionDias = 2, PresupuestoId = p.Id, PartidaId = segunda.Id }
            }
        };
        string origen = Firma(proyecto), cronograma = Firma(plan);
        var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
        var recursosPorUid = modelo.Recursos.ToDictionary(r => r.Uid);
        var asignacionesPrimera = modelo.Asignaciones.Where(a => a.TareaUid == modelo.Tareas[0].Uid).ToArray();
        Exige(asignacionesPrimera.Select(a => recursosPorUid[a.RecursoUid].Nombre).SequenceEqual(p.Costos.Insumos.Select(i => i.Descripcion)) &&
            modelo.Recursos.Select(r => r.Codigo).Distinct().SequenceEqual(p.Costos.Insumos.Select(i => i.Codigo)) &&
            modelo.Recursos.All(r => p.Costos.Insumos.Any(i => i.Codigo == r.Codigo && i.Descripcion == r.Nombre && i.Unidad == r.Unidad)),
            "Project debe conservar nombres, códigos, unidades Unicode y orden de los insumos de la base, incluso cuando el código ordenaría al revés.");
        foreach (var a in modelo.Asignaciones.Where(a => recursosPorUid[a.RecursoUid].Nombre == "OPERARIO"))
            Exige(a.Cantidad == 4 && a.TrabajoHoras == 4 && a.Unidades == 1 && a.Costo == 40 && recursosPorUid[a.RecursoUid].Tarifa == 10,
                "OPERARIO debe exportarse con 100 % asignado, cuatro horas a S/10 y costo S/40, sin convertirlo en material ni alterar tarifa.");
        var porcentajes = modelo.Asignaciones.Where(a => recursosPorUid[a.RecursoUid].Unidad == "%mo").ToArray();
        Exige(porcentajes.Length == 2 && porcentajes[0].Cantidad == 1 && porcentajes[0].Unidades == 1 && porcentajes[0].Costo == 6 &&
            porcentajes[1].Cantidad == 5 && porcentajes[1].Unidades == 5 && porcentajes[1].Costo == 10.01m &&
            porcentajes.All(a => a.TrabajoHoras == null && recursosPorUid[a.RecursoUid].Tipo == 0 &&
                recursosPorUid[a.RecursoUid].Tarifa * a.Cantidad == a.Costo) &&
            porcentajes[0].RecursoUid != porcentajes[1].RecursoUid &&
            porcentajes.All(a => recursosPorUid[a.RecursoUid].Nombre == herramientas.Descripcion),
            "El %mo nativo debe conservar cantidades de origen 1 y 5: MO S/120 con herramientas de cantidad 1/parcial S/6 no debe convertirse en 5; debe mantener conciliación, unidad y nombre sin sufijos.");
        Exige(Firma(proyecto) == origen && Firma(plan) == cronograma && modelo.Advertencias.Count == 0,
            "Preparar recursos nativos modificó el proyecto/cronograma o generó advertencias de conversión para tasas nativas recuperables.");
        pasa("Project reproduce herramientas 1 %mo/S6 con MO S120 de la captura, conserva cantidad nativa 5 y conciliación, orden/nombres/unidades, y OPERARIO al 100 % con S/40");
    }

    private static void ComprobarPorcentajesConSubanalisis(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        var p = proyecto.Presupuestos.Single();
        var sub = p.Items.Single(i => i.Id == "SUB");
        sub.Costos.Analisis.Add(new() { InsumoId = "OPERARIO", Grupo = MYGGrupoRecurso.ManoObra, Cantidad = 2 });
        sub.Costos.Analisis.Add(new() { InsumoId = "HERRAMIENTAS", Grupo = MYGGrupoRecurso.Equipo,
            Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 10 });
        string origen = Firma(proyecto), cronograma = Firma(plan);
        var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
        var herramientas = modelo.Recursos.Single(r => r.Unidad == "%mo");
        var asignacion = modelo.Asignaciones.Single(a => a.RecursoUid == herramientas.Uid);
        Exige(herramientas.Tipo == 0 && herramientas.Nombre == "Herramientas QA" && herramientas.Tarifa == .6m &&
            asignacion.Cantidad == 20 && asignacion.Unidades == 20 && asignacion.Costo == 12 &&
            modelo.Asignaciones.Where(a => modelo.Recursos.Single(r => r.Uid == a.RecursoUid).Grupo == "MANO DE OBRA").Sum(a => a.Costo) == 200 &&
            Firma(proyecto) == origen && Firma(plan) == cronograma,
            "El recurso local debe sumar consumo fuente 5×2 directo más 10×0,5×2 del subanálisis: 20 unidades %mo y S/12, sin inventar una tasa económica ni alterar el origen.");
        pasa("Project conserva consumo ACU consolidado de 20 unidades %mo y S/12 con factores de metrado/subanálisis, sin reconstruir cantidades desde importes");

        var gravado = MYGProyectoStorage.Copia(proyecto);
        var presupuestoGravado = gravado.Presupuestos.Single();
        presupuestoGravado.Costos.ConfiguracionCostoDirecto ??= new();
        presupuestoGravado.Costos.ConfiguracionCostoDirecto.IncluirIgvEquipo = true;
        presupuestoGravado.Costos.Insumos.Single(i => i.Id == "HERRAMIENTAS").IGVPorcentaje = 18;
        var modeloGravado = MYGExportacionCronograma.PrepararProject(gravado, plan, true);
        var recursoGravado = modeloGravado.Recursos.Single(r => r.Unidad == "%mo");
        var asignacionGravada = modeloGravado.Asignaciones.Single(a => a.RecursoUid == recursoGravado.Uid);
        Exige(asignacionGravada.Cantidad == 20 && asignacionGravada.Unidades == 20 && asignacionGravada.Costo == 14.16m &&
            recursoGravado.Tarifa == .708m,
            "El IGV de equipo debe conservar 20 unidades %mo de origen y cambiar sólo su tarifa/costo a S/14,16; no debe inflar la cantidad en 18 %.");
        pasa("Project conserva cantidad %mo de origen cuando el IGV cambia su costo y tarifa");

        // Un parcial nativo puede conservar un costo porcentual sin mano de
        // obra. La conversión debe ser visible, no descartar el importe.
        p.Items = new() { sub };
        sub.Costos.Cantidad = 1;
        sub.Costos.Analisis = new()
        {
            new() { InsumoId = "HERRAMIENTAS", Grupo = MYGGrupoRecurso.Equipo, Cantidad = 0,
                Modo = MYGModoCantidad.PorcentajeManoObra, ParcialImportadoDelphin = 6 }
        };
        sub.Costos.PrecioImportadoDelphin = 6;
        sub.Costos.FirmaAnalisisImportadoDelphin = MYGMotorPresupuestos.FirmaAnalisis(p, sub);
        plan.Tareas = new() { new() { Id = "SIN-MO", Nombre = "Parcial sin MO", DuracionDias = 1, PresupuestoId = p.Id, PartidaId = sub.Id } };
        modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
        Exige(modelo.Recursos.Single().Unidad == "%mo" && modelo.Recursos.Single().Tarifa == 6 &&
            modelo.Asignaciones.Single().Cantidad == 1 && modelo.Asignaciones.Single().Costo == 6 &&
            modelo.Advertencias.Any(a => a.Contains("Herramientas QA", StringComparison.Ordinal) &&
                a.Contains("Parcial sin MO", StringComparison.Ordinal) && a.Contains("porcentual", StringComparison.Ordinal)),
            "Un costo porcentual nativo sin base de MO debe conservar S/6 como una unidad %mo y avisar claramente la conversión.");
        pasa("Project conserva el costo porcentual sin base de mano de obra mediante una unidad %mo y advierte qué recurso/tarea se convirtieron");
    }

    private static void ComprobarFechasImportadasConVinculos(Action<string> pasa)
    {
        var proyecto = DatosConFechasImportadas(out var plan);
        string documentoAntes = Firma(proyecto), planAntes = Firma(plan);
        var solo = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        var completo = MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
        foreach (var modelo in new[] { solo, completo })
        {
            var revestimiento = modelo.Tareas.Single(t => t.IdMYG == "A");
            var anterior = modelo.Tareas.Single(t => t.IdMYG == "79");
            var vinculo = modelo.Dependencias.Single();
            Exige(!revestimiento.Manual && revestimiento.ConservarFechasImportadas &&
                revestimiento.Inicio == new DateTime(2023, 9, 20, 8, 0, 0) &&
                revestimiento.Fin == new DateTime(2023, 9, 26, 17, 0, 0) && revestimiento.DuracionMinutos == 3360 &&
                anterior.Inicio == new DateTime(2023, 9, 20, 8, 0, 0) &&
                anterior.Fin == new DateTime(2023, 9, 21, 17, 0, 0) &&
                vinculo.TareaUid == revestimiento.Uid && vinculo.PredecesoraUid == anterior.Uid &&
                vinculo.Tipo == MYGTipoVinculo.CC && vinculo.DesfaseMinutos == 960,
                "El modelo debe retener 3360 minutos y las fechas importadas del 20 al 26 como referencia para informar el recálculo de Project; el vínculo 79CC+2 incompatible debe permanecer íntegro.");
            Exige(modelo.Tareas.Single(t => t.IdMYG == "79").ConservarFechasImportadas &&
                !modelo.Tareas.Single(t => t.IdMYG == "NORMAL").ConservarFechasImportadas &&
                !modelo.Tareas.Single(t => t.IdMYG == "MANUAL").ConservarFechasImportadas &&
                !modelo.Tareas.Single(t => t.IdMYG == "R").ConservarFechasImportadas,
                "La conservación de fechas importadas debe reservarse a las automáticas con instantánea vigente, excluyendo automáticas normales, manuales y resúmenes.");
        }
        Exige(solo.Tareas.SequenceEqual(completo.Tareas) && solo.Dependencias.SequenceEqual(completo.Dependencias) &&
            solo.Recursos.Count == 0 && solo.Asignaciones.Count == 0 && completo.Recursos.Count == 3 &&
            completo.Asignaciones.Count == 3 && completo.Asignaciones.All(a =>
                a.Inicio == new DateTime(2023, 9, 20, 8, 0, 0) && a.Fin == new DateTime(2023, 9, 26, 17, 0, 0)) &&
            Firma(proyecto) == documentoAntes && Firma(plan) == planAntes,
            "Exportar con o sin recursos cambió tareas, vínculos, fechas de asignaciones o el documento/cronograma importado de origen.");
        pasa("El modelo distingue automáticas importadas y retiene fechas del 20–26/09 para comparar el recálculo, 3360 minutos y vínculo 79CC+2 íntegro, con y sin recursos y sin modificar el origen");
    }

    private static void ComprobarLiberacionDeFechasImportadas(Action<string> pasa)
    {
        var proyecto = DatosConFechasImportadas(out var original);
        string documentoAntes = Firma(proyecto), originalAntes = Firma(original);
        var cambios = new (string Nombre, Action<MYGCronograma> Aplicar)[]
        {
            ("duración de la tarea", p => p.Tareas.Single(t => t.Id == "A").DuracionDias = 8),
            ("calendario", p => p.Calendario.HorasPorDia = 7),
            ("inicio del proyecto", p => p.FechaInicio = new DateTime(2023, 9, 25)),
            ("duración de la predecesora", p => p.Tareas.Single(t => t.Id == "79").DuracionDias = 4),
            ("desfase del vínculo", p => p.Tareas.Single(t => t.Id == "A").Predecesoras.Single().DesfaseDias = 3)
        };
        foreach (var cambio in cambios)
        {
            var editado = MYGProyectoStorage.Copia(original);
            cambio.Aplicar(editado);
            string editadoAntes = Firma(editado);
            var calculada = MYGMotorCronograma.Calcular(editado).Filas.Single(f => f.Tarea.Id == "A");
            Exige(calculada.Tarea.FechasImportadasDelphin == null,
                "La edición de " + cambio.Nombre + " no liberó la instantánea del motor usada por la exportación.");
            foreach (bool incluirRecursos in new[] { false, true })
            {
                var modelo = MYGExportacionCronograma.PrepararProject(proyecto, editado, incluirRecursos);
                var tarea = modelo.Tareas.Single(t => t.IdMYG == "A");
                Exige(!tarea.Manual && !tarea.ConservarFechasImportadas &&
                    tarea.Inicio == calculada.Inicio.AddHours(8) &&
                    tarea.Fin.Date == calculada.Fin && tarea.Inicio.Date != new DateTime(2023, 9, 20),
                    "La edición de " + cambio.Nombre + " debe exportar la programación automática calculada y quitar la conservación de fechas importadas en ambos modos de recursos.");
                Exige(Firma(editado) == editadoAntes && Firma(original) == originalAntes && Firma(proyecto) == documentoAntes,
                    "Exportar después de editar " + cambio.Nombre + " modificó el plan editado o los datos originales.");
            }
        }
        pasa("Project libera las fechas importadas al editar duración, calendario, inicio del proyecto, duración de la predecesora o desfase del vínculo y exporta el resultado automático sin modificar el origen");
    }

    private static MYGProyectoDocumento DatosConFechasImportadas(out MYGCronograma plan)
    {
        var proyecto = Datos(out plan);
        var revestimiento = plan.Tareas.Single(t => t.Id == "A");
        revestimiento.Nombre = "REVESTIMIENTO CON MICROCEMENTO GRIS OSCURO";
        revestimiento.InicioManual = new DateTime(2023, 9, 20);
        revestimiento.DuracionDias = 7;
        revestimiento.Predecesoras = new() { new() { PredecesoraId = "79", Tipo = MYGTipoVinculo.CC, DesfaseDias = 2 } };
        MYGFechasImportadasDelphin Fechas(DateTime inicio, DateTime fin, int duracion, MYGModoTarea modo = MYGModoTarea.Automatica) => new()
        {
            Inicio = inicio, Fin = fin, DuracionDias = duracion, ModoOriginal = modo,
            VersionLectura = DelphinCronogramaMYG.VersionLecturaActual
        };
        revestimiento.FechasImportadasDelphin = Fechas(revestimiento.InicioManual.Value, new DateTime(2023, 9, 26), 7);
        plan.FechaInicio = plan.FechaEstado = new DateTime(2023, 9, 19);
        plan.Calendario = new() { HorasPorDia = 8, DiasLaborables = Enum.GetValues<DayOfWeek>().ToList() };
        plan.Tareas = new()
        {
            new() { Id = "R", Nombre = "Resumen importado", EsResumen = true, InicioManual = revestimiento.InicioManual,
                DuracionDias = 7, FechasImportadasDelphin = Fechas(revestimiento.InicioManual.Value, new DateTime(2023, 9, 26), 7) },
            new() { Id = "79", PadreId = "R", Codigo = "79", Nombre = "Predecesora importada", InicioManual = new DateTime(2023, 9, 20), DuracionDias = 2,
                FechasImportadasDelphin = Fechas(new DateTime(2023, 9, 20), new DateTime(2023, 9, 21), 2) },
            revestimiento,
            new() { Id = "NORMAL", PadreId = "R", Nombre = "Automática sin instantánea", DuracionDias = 2 },
            new() { Id = "MANUAL", PadreId = "R", Nombre = "Manual importada", Modo = MYGModoTarea.Manual,
                InicioManual = revestimiento.InicioManual, DuracionDias = 7,
                FechasImportadasDelphin = Fechas(revestimiento.InicioManual.Value, new DateTime(2023, 9, 26), 7, MYGModoTarea.Manual) }
        };
        plan.VinculosImportadosDelphin = new()
        {
            new() { Id = "DP-REVESTIMIENTO", OrigenId = "79", DestinoId = "A", Tipo = (int)MYGTipoVinculo.CC, Desfase = 2 }
        };
        // Reproduce las firmas que registra el lector Delphin. Así las ediciones
        // del contexto invalidan la instantánea igual que en un documento real.
        foreach (var tarea in plan.Tareas.Where(t => t.FechasImportadasDelphin != null))
        {
            tarea.FechasImportadasDelphin.FirmaPredecesoras = MYGMotorCronograma.FirmaPredecesorasDelphin(tarea);
            tarea.FechasImportadasDelphin.FirmaCalendario = MYGMotorCronograma.FirmaCalendarioDelphin(plan.Calendario);
            tarea.FechasImportadasDelphin.InicioProyecto = plan.FechaInicio;
        }
        var tareas = plan.Tareas.ToDictionary(t => t.Id, StringComparer.Ordinal);
        var resultados = MYGMotorCronograma.Calcular(plan).Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var tarea in plan.Tareas.Where(t => t.FechasImportadasDelphin != null))
            tarea.FechasImportadasDelphin.FirmaAntecesoras = MYGMotorCronograma.FirmaAntecesorasDelphin(tarea, tareas, resultados);
        return proyecto;
    }

    private static void ComprobarDuracionAutomaticaImportada(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        var fecha = new DateTime(2023, 5, 2);
        var automatica = plan.Tareas.Single(t => t.Id == "A");
        automatica.PadreId = null;
        automatica.Nombre = "Alquiler importado con recursos";
        automatica.InicioManual = fecha;
        automatica.DuracionDias = 2;
        automatica.FechasImportadasDelphin = new()
        {
            Inicio = fecha, Fin = fecha, DuracionDias = 2,
            ModoOriginal = MYGModoTarea.Automatica, VersionLectura = DelphinCronogramaMYG.VersionLecturaActual
        };
        plan.FechaInicio = plan.FechaEstado = fecha;
        plan.Calendario = new() { HorasPorDia = 8 };
        plan.Tareas = new()
        {
            automatica,
            new() { Id = "MANUAL", Nombre = "Manual con extremos independientes", Modo = MYGModoTarea.Manual,
                InicioManual = fecha, DuracionDias = 2, FechasImportadasDelphin = new()
                {
                    Inicio = fecha, Fin = fecha, DuracionDias = 2,
                    ModoOriginal = MYGModoTarea.Manual, VersionLectura = DelphinCronogramaMYG.VersionLecturaActual
                } },
            new() { Id = "HITO", Nombre = "Hito importado", InicioManual = fecha, DuracionDias = 0,
                FechasImportadasDelphin = new()
                {
                    Inicio = fecha, Fin = fecha, DuracionDias = 0,
                    ModoOriginal = MYGModoTarea.Automatica, VersionLectura = DelphinCronogramaMYG.VersionLecturaActual
                } }
        };
        string documentoAntes = Firma(proyecto), planAntes = Firma(plan);
        var solo = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        var completo = MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
        foreach (var modelo in new[] { solo, completo })
        {
            var tarea = modelo.Tareas.Single(t => t.IdMYG == "A");
            var manual = modelo.Tareas.Single(t => t.IdMYG == "MANUAL");
            var hito = modelo.Tareas.Single(t => t.IdMYG == "HITO");
            Exige(!tarea.Manual && tarea.Inicio == fecha.AddHours(8) && tarea.Fin == fecha.AddHours(17) &&
                tarea.DuracionMinutos == 480 && manual.Manual && manual.Inicio == tarea.Inicio && manual.Fin == tarea.Fin &&
                manual.DuracionMinutos == 960 && hito.Hito && !hito.Manual && hito.DuracionMinutos == 0 &&
                hito.Inicio == fecha.AddHours(8) && hito.Fin == hito.Inicio,
                "La automática importada de un día y duración nativa de dos días debe exportar 480 minutos sin desplazar fechas ni cambiar modo; la manual debe mantener 960 minutos y el hito cero.");
        }
        Exige(solo.Tareas.SequenceEqual(completo.Tareas) && solo.Recursos.Count == 0 && solo.Asignaciones.Count == 0,
            "Añadir recursos cambió las fechas, la duración o el modo de las tareas importadas.");
        pasa("Project exporta la automática importada con inicio y fin el mismo día como 480 minutos en ambos modos; conserva 960 minutos manuales y cero en hitos");

        var trabajador = completo.Recursos.Single(r => r.Nombre == "Operario QA");
        var trabajo = completo.Asignaciones.Single(a => a.RecursoUid == trabajador.Uid);
        var exportada = completo.Tareas.Single(t => t.IdMYG == "A");
        Exige(trabajo.TareaUid == exportada.Uid && trabajo.TrabajoHoras == 8 && trabajo.Unidades == 1 &&
            trabajo.Costo == 160 && trabajo.Inicio == exportada.Inicio && trabajo.Fin == exportada.Fin &&
            Firma(proyecto) == documentoAntes && Firma(plan) == planAntes,
            "La automática importada alteró sus ocho horas de trabajo, dedicación del 100 %, costo, fechas de asignación o datos de origen.");
        pasa("Las ocho horas de mano de obra de la automática importada se exportan con dedicación del 100 % y costo intacto, sin modificar proyecto ni cronograma");
    }

    private static void ComprobarDuracionAutomaticaPorTramos(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        var inicio = new DateTime(2023, 5, 2);
        var fin = new DateTime(2023, 5, 8);
        plan.FechaInicio = inicio;
        plan.FechaEstado = fin;
        plan.Calendario = new() { HorasPorDia = 8 };
        foreach (var dia in new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday })
            plan.Calendario.HorariosSemanales.Add(new() { Dia = dia, Tramos = new()
            {
                new() { InicioMinuto = 480, FinMinuto = 720 },
                new() { InicioMinuto = 780, FinMinuto = dia == DayOfWeek.Tuesday ? 900 : 1020 }
            } });
        MYGTareaCronograma Tarea(string id, List<MYGTramoImportadoDelphin> tramos) => new()
        {
            Id = id, Nombre = id, InicioManual = inicio, DuracionDias = 2,
            FechasImportadasDelphin = new()
            {
                Inicio = inicio, Fin = fin, DuracionDias = 2, ModoOriginal = MYGModoTarea.Automatica,
                VersionLectura = DelphinCronogramaMYG.VersionLecturaActual, Tramos = tramos
            }
        };
        plan.Tareas = new()
        {
            Tarea("SEPARADA", new()
            {
                new() { Id = "S2", Inicio = new DateTime(2023, 5, 5), Fin = new DateTime(2023, 5, 5), Duracion = 1 },
                new() { Id = "S1", Inicio = new DateTime(2023, 5, 3), Fin = new DateTime(2023, 5, 3), Duracion = 1 }
            }),
            Tarea("SOLAPADA", new()
            {
                new() { Id = "O2", Inicio = new DateTime(2023, 5, 4), Fin = new DateTime(2023, 5, 5), Duracion = 2 },
                new() { Id = "O1", Inicio = new DateTime(2023, 5, 3), Fin = new DateTime(2023, 5, 5), Duracion = 3 }
            })
        };
        string documentoAntes = Firma(proyecto), planAntes = Firma(plan);
        foreach (bool incluirRecursos in new[] { false, true })
        {
            var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, incluirRecursos);
            var separada = modelo.Tareas.Single(t => t.IdMYG == "SEPARADA");
            var solapada = modelo.Tareas.Single(t => t.IdMYG == "SOLAPADA");
            Exige(modelo.Tareas.All(t => !t.Manual && t.Inicio == inicio.AddHours(8) && t.Fin == fin.AddHours(17)) &&
                separada.DuracionMinutos == 1800 && solapada.DuracionMinutos == 2280 &&
                modelo.TramosPorTarea[separada.Uid].Select(t => t.Inicio.Date).SequenceEqual(new[] { new DateTime(2023, 5, 3), new DateTime(2023, 5, 5) }) &&
                modelo.TramosPorTarea[solapada.Uid].Count == 2,
                "La automática por tramos debe usar las 38 horas del rango real, descontar sólo las ocho horas del hueco interno y no duplicar solapes ni quitar los bordes exteriores a los tramos.");
            Exige(Firma(proyecto) == documentoAntes && Firma(plan) == planAntes,
                "Calcular la duración automática con tramos separados o solapados modificó el proyecto o cronograma de origen.");
        }
        pasa("Project calcula las horas del calendario explícito en automáticas por tramos: descuenta sólo huecos internos, une solapes y conserva los extremos de la tarea y el origen");
    }

    private static void ComprobarTramosConHitoInicial(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        var inicio = new DateTime(2023, 5, 1);
        var jueves = new DateTime(2023, 5, 4);
        plan.FechaInicio = inicio;
        plan.FechaEstado = jueves;
        plan.Calendario = new() { HorasPorDia = 8 };
        MYGTareaCronograma Tarea(string id, DateTime fin) => new()
        {
            Id = id, Nombre = id, InicioManual = inicio, DuracionDias = 1,
            FechasImportadasDelphin = new()
            {
                Inicio = inicio, Fin = fin, DuracionDias = 1, ModoOriginal = MYGModoTarea.Automatica,
                VersionLectura = DelphinCronogramaMYG.VersionLecturaActual, Tramos = new()
                {
                    new() { Id = id + "-HITO", Inicio = inicio, Fin = inicio, Duracion = 0 },
                    new() { Id = id + "-TRABAJO", Inicio = fin, Fin = fin, Duracion = 1 }
                }
            }
        };
        plan.Tareas = new() { Tarea("HITO-Y-JUEVES", jueves), Tarea("HITO-Y-TRABAJO-MISMO-DIA", inicio) };
        string documentoAntes = Firma(proyecto), planAntes = Firma(plan);
        foreach (bool incluirRecursos in new[] { false, true })
        {
            var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, incluirRecursos);
            var separada = modelo.Tareas.Single(t => t.IdMYG == "HITO-Y-JUEVES");
            var mismoDia = modelo.Tareas.Single(t => t.IdMYG == "HITO-Y-TRABAJO-MISMO-DIA");
            var tramosSeparados = modelo.TramosPorTarea[separada.Uid];
            var tramosMismoDia = modelo.TramosPorTarea[mismoDia.Uid];
            Exige(!separada.Manual && separada.DuracionMinutos == 480 && separada.Inicio == inicio.AddHours(8) &&
                separada.Fin == jueves.AddHours(17) && tramosSeparados.Count == 2 &&
                tramosSeparados[0].Inicio == inicio.AddHours(8) && tramosSeparados[0].Fin == inicio.AddHours(8) &&
                tramosSeparados[1].Inicio == jueves.AddHours(8) && tramosSeparados[1].Fin == jueves.AddHours(17),
                "El hito inicial del lunes debe terminar a las 08:00 y descontar la jornada restante antes del trabajo del jueves, conservando los extremos y sólo 480 minutos de duración automática.");
            Exige(!mismoDia.Manual && mismoDia.DuracionMinutos == 480 && mismoDia.Inicio == inicio.AddHours(8) &&
                mismoDia.Fin == inicio.AddHours(17) && tramosMismoDia.Count == 2 &&
                tramosMismoDia[0].Fin == inicio.AddHours(8) && tramosMismoDia[1].Inicio == inicio.AddHours(8) &&
                tramosMismoDia[1].Fin == inicio.AddHours(17),
                "El hito y el tramo de trabajo del mismo día no deben descontar ni duplicar las ocho horas de trabajo automático.");
            Exige(Firma(proyecto) == documentoAntes && Firma(plan) == planAntes,
                "Exportar una automática con hito inicial modificó el proyecto o cronograma de origen.");
        }
        pasa("Project descuenta el hueco desde la hora exacta del hito inicial hasta el siguiente tramo, sin restar trabajo cuando ambos comienzan el mismo día");
    }

    private static void ComprobarCalendario(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        plan.Tareas = new()
        {
            new() { Id = "A", Nombre = "Turnos", DuracionDias = 5, InicioBase = new DateTime(2026, 12, 24),
                FinBase = new DateTime(2026, 12, 30), DuracionBase = 5 }
        };
        plan.FechaInicio = new DateTime(2026, 12, 24); plan.FechaEstado = new DateTime(2027, 1, 1);
        var calendario = new MYGCalendarioTrabajo { Nombre = "Obra y guardias", HorasPorDia = 8 };
        foreach (var dia in new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday })
            calendario.HorariosSemanales.Add(new() { Dia = dia, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 }, new() { InicioMinuto = 780, FinMinuto = 1020 } } });
        calendario.HorariosSemanales.Add(new() { Dia = DayOfWeek.Saturday, Tramos = new() { new() { InicioMinuto = 540, FinMinuto = 780 } } });
        calendario.FeriadosAnuales.Add(new() { Mes = 12, Dia = 25 });
        calendario.Excepciones.Add(new() { Id = "NAVIDAD", Nombre = "Navidad", Anual = true, Mes = 12, Dia = 25, Laborable = false });
        calendario.Excepciones.Add(new() { Id = "GUARDIA", Nombre = "Guardia", Inicio = new DateTime(2026, 12, 25), Fin = new DateTime(2026, 12, 25), Laborable = true,
            Tramos = new() { new() { InicioMinuto = 600, FinMinuto = 720 } } });
        calendario.Excepciones.Add(new() { Id = "CIERRE", Inicio = new DateTime(2026, 12, 26), Fin = new DateTime(2026, 12, 27), Laborable = false });
        calendario.Excepciones.Add(new() { Id = "CORTA", Inicio = new DateTime(2026, 12, 28), Fin = new DateTime(2026, 12, 29), Laborable = true,
            Tramos = new() { new() { InicioMinuto = 540, FinMinuto = 720 } } });
        plan.Calendario = calendario;
        var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        var guardia = modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2026, 12, 25));
        Exige(modelo.Calendario.Dias.Count == 7 && modelo.MinutosPorSemana == 2640 &&
            modelo.Calendario.Dias.Single(d => d.Dia == DayOfWeek.Monday).Tramos.SequenceEqual(new[] { new MYGTramoExportacionProject(480, 720), new MYGTramoExportacionProject(780, 1020) }) &&
            modelo.Calendario.Dias.Single(d => d.Dia == DayOfWeek.Saturday).Tramos.Single() == new MYGTramoExportacionProject(540, 780) &&
            guardia.Fin == guardia.Inicio && guardia.Tramos.Single() == new MYGTramoExportacionProject(600, 720) &&
            modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2026, 12, 26)).Tramos.Count == 0 &&
            modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2026, 12, 28)).Fin == new DateTime(2026, 12, 29) &&
            modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2027, 12, 25)).Tramos.Count == 0 &&
            modelo.Tareas[0].DuracionMinutos == 1440 && modelo.Tareas[0].DuracionBaseMinutos == 1440 &&
            modelo.Tareas[0].Fin == new DateTime(2026, 12, 30, 17, 0, 0),
            "La instantánea directa perdió turnos partidos, sábado, guardias, prioridad de excepciones, fechas inclusivas u horas reales de tarea/línea base.");
        var orden = modelo.Calendario.Excepciones.OrderBy(e => e.Inicio).ToArray();
        Exige(orden.Zip(orden.Skip(1), (a, b) => a.Fin < b.Inicio).All(x => x), "El calendario directo contiene excepciones solapadas.");
        pasa("Calendario directo de Project conserva turnos partidos, sábados, excepciones por rango y prioridad de guardias sobre feriados anuales, con duración y línea base en minutos reales");
    }

    private static MYGProyectoDocumento Datos(out MYGCronograma plan)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Proyecto directo QA"); var p = proyecto.Presupuestos.Single();
        var material = new MYGInsumo { Id = "ARENA", Codigo = "0007", Descripcion = "Arena QA", Unidad = "m3", Precio = 10 };
        var trabajo = new MYGInsumo { Id = "OPERARIO", Codigo = "0008", Descripcion = "Operario QA", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 20 };
        var porcentaje = new MYGInsumo { Id = "HERRAMIENTAS", Codigo = "0009", Descripcion = "Herramientas QA", Unidad = "%mo", Grupo = MYGGrupoRecurso.Equipo };
        p.Costos.Insumos.AddRange(new[] { material, trabajo, porcentaje, new MYGInsumo { Id = "SINUSO", Codigo = "99", Descripcion = "Sin uso", Precio = 123 } });
        ItemPresupuestoDelphin Partida(string id, decimal cantidad)
        {
            var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, Descripcion = id, TipoPropuesta = "PARTIDA", Unidad = "und" };
            i.Costos.Cantidad = cantidad; p.Items.Add(i); return i;
        }
        var partida = Partida("PARTIDA", 2); var sub = Partida("SUB", 0); var directa = Partida("DIRECTA", 1); directa.Costos.PrecioDirecto = 45;
        sub.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 });
        partida.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 3 });
        partida.Costos.Analisis.Add(new() { InsumoId = trabajo.Id, Grupo = MYGGrupoRecurso.ManoObra, Cantidad = 4 });
        partida.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = .5m });
        partida.Costos.Analisis.Add(new() { InsumoId = porcentaje.Id, Grupo = MYGGrupoRecurso.Equipo, Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 5 });
        plan = new MYGCronograma
        {
            FechaInicio = new DateTime(2026, 1, 30), FechaEstado = new DateTime(2026, 2, 4),
            Calendario = new() { HorasPorDia = 6.5m, Feriados = new() { new DateTime(2026, 2, 2) }, FeriadosAnuales = new() { new() { Mes = 2, Dia = 3 } } },
            Tareas = new()
            {
                new() { Id = "R", Nombre = "Resumen", EsResumen = true },
                new() { Id = "A", PadreId = "R", Codigo = "0001", Nombre = "Excavación QA", DuracionDias = 3, Avance = 37.5m, PresupuestoId = p.Id, PartidaId = partida.Id },
                new() { Id = "B", PadreId = "R", Nombre = "Precio directo", DuracionDias = 2, PresupuestoId = p.Id, PartidaId = directa.Id,
                    Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.FC, DesfaseDias = 2 } } },
                new() { Id = "C", PadreId = "R", Nombre = "Comienzo comienzo", Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.CC, DesfaseDias = -1 } } },
                new() { Id = "D", PadreId = "R", Nombre = "Fin fin", Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.FF, DesfaseDias = 1 } } },
                new() { Id = "E", PadreId = "R", Nombre = "Manual importada", Modo = MYGModoTarea.Manual, InicioManual = new DateTime(2026, 2, 1), DuracionDias = 2, Notas = "Fechas importadas",
                    FechasImportadasDelphin = new() { Inicio = new DateTime(2026, 2, 1), Fin = new DateTime(2026, 2, 7), DuracionDias = 2 },
                    InicioBase = new DateTime(2025, 12, 30), FinBase = new DateTime(2026, 1, 2), DuracionBase = 3,
                    Predecesoras = new() { new() { PredecesoraId = "D", Tipo = MYGTipoVinculo.CF, DesfaseDias = -1 } } },
                new() { Id = "H", Nombre = "Hito", DuracionDias = 0 }
            }
        };
        return proyecto;
    }
}
