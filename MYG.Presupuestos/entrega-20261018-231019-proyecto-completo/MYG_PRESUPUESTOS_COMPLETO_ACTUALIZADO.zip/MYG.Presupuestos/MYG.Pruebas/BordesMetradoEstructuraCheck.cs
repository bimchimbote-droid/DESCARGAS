using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class BordesMetradoEstructuraCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Bordes después de eliminar filas");
        var partida = MYGEstructuraPresupuestos.InsertarNodo(proyecto.Presupuestos.Single(), false);
        var hoja = partida.Costos.Hoja;
        hoja.Poner("B3", "2"); hoja.Poner("C3", "3");
        hoja.Poner("A12", "Dato que debe subir");
        hoja.Celdas["A12"].ColorFondo = "ABCDEF";
        hoja.Celdas["A12"].Bordes = true;
        hoja.Poner("A20", "Dato exterior");
        MYGEdicionHoja.EliminarFilas(hoja, 7, 5);
        Exige(hoja.CeldaTotal == "G11" && hoja.Celdas["A11"].Contenido == "Total:" &&
            hoja.Celdas["G11"].Contenido == "=SUM(G3:G10)" && new MYGHojaCalculo(hoja).Numero("G11") == 6m &&
            hoja.Celdas["A7"].Contenido == "Dato que debe subir" && hoja.Celdas["A7"].ColorFondo == "ABCDEF" &&
            hoja.Celdas["A7"].Bordes && hoja.Celdas["A15"].Contenido == "Dato exterior",
            "Eliminar cinco filas debe subir conjuntamente los datos, la suma, el total y sus formatos, incluyendo datos exteriores al bloque.");
        Exige(Cuerpo(hoja, 3, 10, 1, 8) && Enumerable.Range(11, 6).All(f => !MYGBordesPlantillaMetrado.Contiene(hoja, f, 7)),
            "Después de eliminar las filas 7 a 11, el cuerpo debe terminar en la fila 10 y no dejar bordes debajo del total G11.");
        MYGEdicionHoja.EliminarColumnas(hoja, 4, 3);
        Exige(Cuerpo(hoja, 3, 10, 1, 5) && hoja.CeldaTotal == "D11" &&
            hoja.Celdas["E2"].Contenido == "Plano / Referencia" && new MYGHojaCalculo(hoja).Numero("D11") == 6m &&
            !MYGBordesPlantillaMetrado.Contiene(hoja, 3, 6),
            "Eliminar D:F debe llevar los encabezados, el parcial y el total a la izquierda, sin bordes fantasma en F:H.");
        string ruta = Path.Combine(carpeta, "Metrado con filas y columnas eliminadas.myg");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        var reabierta = MYGProyectoStorage.Leer(ruta).Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Costos.Hoja;
        Exige(Cuerpo(reabierta, 3, 10, 1, 5) && reabierta.Celdas["A7"].ColorFondo == "ABCDEF" &&
            new MYGHojaCalculo(reabierta).Numero(reabierta.CeldaTotal) == 6m,
            "Guardar y reabrir debe conservar los límites reducidos y la relación entre datos y total.");
        MYGEdicionHoja.InsertarFilas(reabierta, 7, 5);
        MYGEdicionHoja.InsertarColumnas(reabierta, 2, 3);
        Exige(Cuerpo(reabierta, 3, 15, 1, 8) && reabierta.CeldaTotal == "G16" &&
            reabierta.Celdas["A12"].Contenido == "Dato que debe subir",
            "Insertar dentro del cuerpo debe ampliar sus bordes y desplazar el total, con las nuevas filas y columnas incluidas.");
        MYGEdicionHoja.InsertarFilas(reabierta, 1, 2);
        MYGEdicionHoja.InsertarColumnas(reabierta, 1, 2);
        Exige(Cuerpo(reabierta, 5, 17, 3, 10) && !MYGBordesPlantillaMetrado.Contiene(reabierta, 3, 1),
            "Insertar antes de la plantilla debe desplazar también el inicio del cuerpo y dejar libres las nuevas posiciones anteriores.");
        reabierta.CeldaTotal = "L30";
        Exige(Cuerpo(reabierta, 5, 17, 3, 10) && !MYGBordesPlantillaMetrado.Contiene(reabierta, 29, 11),
            "Seleccionar un total ajeno a la plantilla no debe extender sus bordes hasta esa celda.");
        pasa("Eliminar e insertar varias filas o columnas desplaza datos, formatos, suma y cuerpo; guardar conserva sus límites sin bordes fantasma");

        VerificarHojasAnteriores(pasa);
        VerificarAcerosYLimites(pasa);
    }

    private static void VerificarHojasAnteriores(Action<string> pasa)
    {
        var sinLimites = new MYGDatosPartida();
        sinLimites.Hoja.RangoCuerpoPlantilla = null;
        string sinLimitesAntes = JsonSerializer.Serialize(sinLimites);
        Exige(!MYGMotorPresupuestos.TieneDatosPropios(sinLimites) && JsonSerializer.Serialize(sinLimites) == sinLimitesAntes,
            "La falta del nuevo límite de bordes no debe convertir una hoja estándar anterior en datos propios ni modificarla al comparar.");
        sinLimites.Hoja.Celdas["A2"].Subrayado = true;
        Exige(MYGMotorPresupuestos.TieneDatosPropios(sinLimites),
            "La compatibilidad de los límites anteriores no debe ocultar personalizaciones de la hoja.");
        var anterior = MYGHojaMetrado.Crear();
        MYGEdicionHoja.EliminarFilas(anterior, 7, 5);
        MYGEdicionHoja.EliminarColumnas(anterior, 4, 3);
        anterior.RangoCuerpoPlantilla = null; // JSON de una versión anterior a estos límites.
        anterior.CeldaTotal = "I30";
        string antes = JsonSerializer.Serialize(anterior);
        Exige(Cuerpo(anterior, 3, 10, 1, 5) && JsonSerializer.Serialize(anterior) == antes,
            "Los bordes de una hoja anterior ya reducida deben recuperarse desde sus cabeceras y Total reales sin modificar datos ni seguir otro total vinculado.");
        MYGEdicionHoja.InsertarFilas(anterior, 5, 2);
        Exige(anterior.RangoCuerpoPlantilla == "A3:E12" && Cuerpo(anterior, 3, 12, 1, 5),
            "Una edición estructural de una hoja anterior debe conservar y desplazar los límites recuperados.");
        anterior.RangoCuerpoPlantilla = null;
        anterior.Poner("A21", "Total:", true);
        Exige(MYGBordesPlantillaMetrado.ObtenerRango(anterior) == "",
            "Una cabecera ambigua con varias leyendas Total no debe recibir bordes inferidos sobre datos personalizados.");
        var importada = MYGHojaMetrado.Crear();
        importada.IdPlantilla = ""; importada.RangoCuerpoPlantilla = null;
        MYGEdicionHoja.Celda(importada, "J25").Bordes = true;
        Exige(MYGBordesPlantillaMetrado.ObtenerRango(importada) == "",
            "Una hoja importada con etiquetas iguales no debe recibir el cuerpo de una plantilla nativa.");
        MYGEdicionHoja.EliminarFilas(importada, 7, 5);
        Exige(importada.Celdas["J20"].Bordes && !MYGBordesPlantillaMetrado.Contiene(importada, 3, 1),
            "Las operaciones de una hoja importada deben desplazar sus bordes explícitos sin agregar bordes de plantilla.");
        var sinCuerpo = MYGHojaMetrado.Crear();
        MYGEdicionHoja.EliminarFilas(sinCuerpo, 3, 13);
        Exige(sinCuerpo.RangoCuerpoPlantilla == "" && sinCuerpo.CeldaTotal == "G3" &&
            !MYGBordesPlantillaMetrado.Contiene(MYGProyectoStorage.Copia(sinCuerpo), 3, 1),
            "Eliminar todo el cuerpo debe conservar el total y guardar que no quedan bordes de datos para evitar su reconstrucción.");
        pasa("Hojas anteriores recuperan su cuerpo reducido desde leyendas reales; importaciones, cabeceras ambiguas y cuerpos eliminados conservan sus formatos");
    }

    private static void VerificarAcerosYLimites(Action<string> pasa)
    {
        var aceros = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        MYGEdicionHoja.EliminarFilas(aceros, 7, 5);
        MYGEdicionHoja.EliminarColumnas(aceros, 5, 2);
        Exige(Cuerpo(aceros, 3, 8, 1, 28) && aceros.CeldaTotal == "AB11" &&
            aceros.Celdas["A9"].Contenido == "Longitud total x Ø" && aceros.Celdas["A9"].Bordes,
            "La plantilla de aceros debe contraer el cuerpo antes de sus tres filas de resumen.");
        aceros.RangoCuerpoPlantilla = null;
        Exige(Cuerpo(aceros, 3, 8, 1, 28),
            "Una plantilla de aceros anterior debe recuperar el límite de su cuerpo desde los resúmenes desplazados.");
        var invalida = MYGHojaMetrado.Crear(); invalida.RangoCuerpoPlantilla = "A3:Z900";
        bool rechazada = false;
        try { MYGHojaCalculo.Validar(invalida); } catch (InvalidDataException) { rechazada = true; }
        Exige(rechazada, "Un rango de cuerpo guardado fuera de la hoja debe rechazarse como cualquier otro rango.");
        pasa("Cuerpo de aceros acompaña filas y columnas sin invadir sus resúmenes y los límites guardados se validan");
    }

    private static bool Cuerpo(MYGHojaMetrado hoja, int f1, int f2, int c1, int c2) =>
        Enumerable.Range(f1, f2 - f1 + 1).All(f => Enumerable.Range(c1, c2 - c1 + 1)
            .All(c => MYGBordesPlantillaMetrado.Contiene(hoja, f, c))) &&
        !MYGBordesPlantillaMetrado.Contiene(hoja, f1 - 1, c1) && !MYGBordesPlantillaMetrado.Contiene(hoja, f2 + 1, c1) &&
        !MYGBordesPlantillaMetrado.Contiene(hoja, f1, c1 - 1) && !MYGBordesPlantillaMetrado.Contiene(hoja, f1, c2 + 1);
}
