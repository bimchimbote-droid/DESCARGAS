using System;
using System.Globalization;
using System.IO;
using System.Linq;
using MYG_2027;

internal static class FormatoPartidaNuevaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("FORMATO DE PARTIDAS NUEVAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var primera = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        var hoja = primera.Costos.Hoja;
        VerificarFormato(hoja);
        Exige(!MYGMotorPresupuestos.TieneDatosPropios(primera.Costos),
            "La presentación estándar de una partida nueva no debe crear datos propios.");

        MYGEdicionHoja.Celda(hoja, "B3").Contenido = "1";
        MYGEdicionHoja.Celda(hoja, "C3").Contenido = "3";
        var calculo = new MYGHojaCalculo(hoja);
        string Tres() => 3m.ToString("0.00", CultureInfo.CurrentCulture);
        Exige(calculo.Mostrar("B3") == 1m.ToString("0.00", CultureInfo.CurrentCulture) &&
            calculo.Mostrar("C3") == Tres() && calculo.Mostrar("G3") == Tres() &&
            calculo.Mostrar("G4") == "-" && calculo.Mostrar("G16") == Tres(),
            "La partida nueva debe mostrar dos decimales en las entradas y resultados, con guion para parciales vacíos.");

        // A second insertion validates the same creation path without sharing
        // the first sheet's values or later user formatting.
        hoja.Celdas["A2"].ColorFondo = "ABCDEF";
        var segunda = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        VerificarFormato(segunda.Costos.Hoja);
        Exige(new MYGHojaCalculo(segunda.Costos.Hoja).Numero("G16") == 0,
            "Una segunda partida debe recibir una hoja estándar independiente.");
        primera = presupuesto.Items.Single(i => i.Id == primera.Id);
        hoja = primera.Costos.Hoja;
        Exige(hoja.Celdas["A2"].ColorFondo == "ABCDEF",
            "Crear otra partida debe conservar el formato personalizado de la partida existente.");
        hoja.Celdas["A2"].ColorFondo = "EFF9FC";

        string ruta = Path.Combine(carpeta, "Partidas nuevas con formato.myg");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        var guardada = MYGProyectoStorage.Leer(ruta).Presupuestos.Single().Items.Single(i => i.Id == primera.Id).Costos.Hoja;
        VerificarFormato(guardada);
        Exige(new MYGHojaCalculo(guardada).Mostrar("G16") == Tres() && guardada.FormatoNumeroPredeterminado == "0.00",
            "Guardar y reabrir una partida debe conservar el formato visual del total.");

        string excel = Path.Combine(carpeta, "Partida nueva con formato.xlsx");
        MYGExcelPresupuestos.Guardar(excel, new[] { guardada });
        var importada = MYGExcelPresupuestos.Importar(excel, guardada.Nombre, guardada.CeldaTotal);
        VerificarFormato(importada);
        Exige(new MYGHojaCalculo(importada).Mostrar("G3") == Tres() &&
            new MYGHojaCalculo(importada).Mostrar("G4") == "-",
            "El intercambio XLSX debe conservar los dos decimales y los guiones para ceros.");
        pasa("Partidas nuevas conservan ambos encabezados celestes, Datos centrado, dos decimales y Total a la derecha en proyecto y XLSX");
        VerificarDecimalesPredeterminados(guardada, pasa);
        VerificarReparacionRelleno(carpeta, pasa);
        VerificarTotalVisibleTrasEliminar(carpeta, pasa);
    }

    private static void VerificarFormato(MYGHojaMetrado hoja)
    {
        Exige(new[] { "A1:C1", "D1:F1", "G1:H1" }.All(hoja.RangosCombinados.Contains) &&
            MYGEdicionHoja.Direcciones(hoja, "A1:H2").All(d => hoja.Celdas[d].ColorFondo == "EFF9FC") &&
            MYGEdicionHoja.AlineacionCelda(hoja.Celdas["A1"], "A1") == "Centro" &&
            MYGEdicionHoja.AlineacionCelda(hoja.Celdas["A2"], "A2") == "Izquierda",
            "Ambos encabezados deben llevar relleno celeste, con Datos centrado y Descripción a la izquierda.");
        Exige(hoja.Celdas.Values.All(c => c.Fuente == "Arial Narrow" && c.TamanoFuente == 9) &&
            Enumerable.Range(3, 13).All(f => hoja.Celdas["G" + f].FormatoNumero == "0.00;-0.00;-") &&
            hoja.Celdas["G16"].FormatoNumero == "0.00" &&
            hoja.Celdas["A16"].Negrita && hoja.Celdas["G16"].Negrita &&
            MYGEdicionHoja.AlineacionCelda(hoja.Celdas["A16"], "A16") == "Derecha",
            "La plantilla nueva debe conservar fuente, dos decimales y etiqueta Total en negrita a la derecha.");
    }

    private static void VerificarDecimalesPredeterminados(MYGHojaMetrado hoja, Action<string> pasa)
    {
        // Una celda que todavía no existe debe recibir el mismo formato que
        // los factores iniciales; el formato no debe redondear su valor real.
        MYGEdicionHoja.Celda(hoja, "J20").Contenido = "1.23456";
        hoja.Poner("K20", "2.34567");
        var calculo = new MYGHojaCalculo(hoja);
        Exige(calculo.Mostrar("J20") == 1.23m.ToString("0.00", CultureInfo.CurrentCulture) &&
            calculo.Mostrar("K20") == 2.35m.ToString("0.00", CultureInfo.CurrentCulture) &&
            calculo.Numero("J20") == 1.23456m && calculo.Numero("K20") == 2.34567m,
            "Las celdas adicionales de una partida nueva deben usar dos decimales sin perder precisión.");
        MYGEdicionHoja.InsertarFilas(hoja, 20);
        MYGEdicionHoja.Celda(hoja, "J20").Contenido = "4";
        Exige(hoja.FormatoNumeroPredeterminado == "0.00" &&
            new MYGHojaCalculo(hoja).Mostrar("J20") == 4m.ToString("0.00", CultureInfo.CurrentCulture),
            "Insertar filas debe conservar el formato predeterminado de dos decimales.");

        var anterior = System.Text.Json.JsonSerializer.Deserialize<MYGHojaMetrado>("{\"Celdas\":{}}");
        MYGEdicionHoja.Celda(anterior, "B3").Contenido = "1.23456";
        Exige(anterior.FormatoNumeroPredeterminado == "0.0000" &&
            new MYGHojaCalculo(anterior).Mostrar("B3") == 1.2346m.ToString("0.0000", CultureInfo.CurrentCulture),
            "Las hojas anteriores sin nuevo formato predeterminado deben conservar sus cuatro decimales.");
        var personalizada = MYGHojaMetrado.Crear();
        MYGEdicionHoja.Celda(personalizada, "B3").FormatoNumero = "0.000000";
        personalizada.Celdas["A1"].AlineacionHorizontal = "Izquierda";
        personalizada.Celdas["A1"].AlineacionPersonalizada = true;
        var copia = MYGProyectoStorage.Copia(personalizada);
        Exige(copia.Celdas["B3"].FormatoNumero == "0.000000" &&
            MYGEdicionHoja.AlineacionCelda(copia.Celdas["A1"], "A1") == "Izquierda",
            "Los formatos personalizados deben conservarse al copiar o reabrir los datos.");
        pasa("Dos decimales se aplican a celdas nuevas y filas insertadas sin redondear datos ni alterar formatos guardados o heredados");
    }

    private static void VerificarTotalVisibleTrasEliminar(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Total visible tras eliminar");
        var partida = MYGEstructuraPresupuestos.InsertarNodo(documento.Presupuestos.Single(), false);
        var h = partida.Costos.Hoja;
        h.Poner("B3", "2"); h.Poner("C3", "3");
        Exige(new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 6m, "La prueba debe comenzar con un total distinto de cero.");
        MYGEdicionHoja.EliminarFilas(h, 3, 5);
        string cero = 0m.ToString("0.00", CultureInfo.CurrentCulture);
        Exige(h.CeldaTotal == "G11" && h.Celdas["A11"].Contenido == "Total:" &&
            new MYGHojaCalculo(h).Mostrar("G11") == cero && new MYGHojaCalculo(h).Mostrar("G3") == "-",
            "Eliminar las filas debe subir el total y su etiqueta a la fila 11; el total cero permanece visible con dos decimales.");
        h.Celdas[h.CeldaTotal].FormatoNumero = "0.00;-0.00;-"; // Formato de la entrega anterior.
        string formula = h.Celdas[h.CeldaTotal].Contenido;
        Exige(MYGEdicionHoja.RepararFormatoTotalMetrado(h) &&
            h.Celdas[h.CeldaTotal].Contenido == formula && new MYGHojaCalculo(h).Mostrar(h.CeldaTotal) == cero &&
            !MYGEdicionHoja.RepararFormatoTotalMetrado(h),
            "La reparación del formato anterior debe conservar la fórmula y hacer visible el total cero sin cambios repetidos.");
        MYGEdicionHoja.EliminarColumnas(h, 2);
        Exige(h.CeldaTotal == "F11" && new MYGHojaCalculo(h).Mostrar(h.CeldaTotal) == cero,
            "Eliminar columnas también debe trasladar el total conservando su formato visible.");
        string ruta = Path.Combine(carpeta, "Total visible eliminado.myg");
        MYGProyectoStorage.Guardar(ruta, documento);
        var reabierta = MYGProyectoStorage.Leer(ruta).Presupuestos.Single().Items.Single().Costos.Hoja;
        Exige(reabierta.CeldaTotal == "F11" && new MYGHojaCalculo(reabierta).Mostrar("F11") == cero,
            "Guardar y reabrir debe conservar la nueva ubicación y el cero visible del total.");
        h.Celdas[h.CeldaTotal].FormatoNumero = "#,##0.000";
        Exige(!MYGEdicionHoja.RepararFormatoTotalMetrado(h) && h.Celdas[h.CeldaTotal].FormatoNumero == "#,##0.000",
            "La corrección no debe cambiar formatos de total personalizados.");
        pasa("Eliminar filas y columnas desplaza el total y su etiqueta; los totales cero se muestran con dos decimales y persisten");
    }

    private static MYGHojaMetrado CabeceraAnterior()
    {
        var hoja = MYGHojaMetrado.Crear();
        hoja.RellenoCabeceraEstandarAplicado = false;
        foreach (string d in MYGEdicionHoja.Direcciones(hoja, "A2:H2")) hoja.Celdas[d].ColorFondo = "";
        return hoja;
    }

    private static void VerificarReparacionRelleno(string carpeta, Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Cabecera guardada sin relleno");
        var partida = MYGEstructuraPresupuestos.InsertarNodo(proyecto.Presupuestos.Single(), false);
        var hoja = partida.Costos.Hoja = CabeceraAnterior();
        hoja.Poner("A3", "Columna existente");
        hoja.Poner("B3", "1.23456");
        hoja.Celdas["B3"].FormatoNumero = "0.0000";
        hoja.Celdas["B3"].ColorFondo = "FEDCBA";
        hoja.Celdas["A2"].Fuente = "Arial";
        hoja.Celdas["A2"].TamanoFuente = 11;
        hoja.Celdas["A2"].ColorFondo = "ABCDEF";
        hoja.Celdas["B2"].ColorFondo = "#FFFFFF";
        hoja.Celdas["C2"].ColorFondo = "FFFFFF";
        string ruta = Path.Combine(carpeta, "Cabecera anterior sin relleno.myg");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        proyecto = MYGProyectoStorage.Leer(ruta);
        hoja = proyecto.Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Costos.Hoja;
        Exige(!hoja.RellenoCabeceraEstandarAplicado && hoja.Celdas["D2"].ColorFondo == "",
            "La prueba debe reabrir una cabecera anterior cuyo relleno todavía falta.");
        var esperada = MYGProyectoStorage.Copia(hoja);
        foreach (string d in MYGEdicionHoja.Direcciones(esperada, "A1:H2"))
            if (string.IsNullOrEmpty(esperada.Celdas[d].ColorFondo)) esperada.Celdas[d].ColorFondo = "EFF9FC";
        esperada.RellenoCabeceraEstandarAplicado = true;
        Exige(MYGEdicionHoja.RepararRellenoCabeceraMetrado(hoja) &&
            System.Text.Json.JsonSerializer.Serialize(hoja) == System.Text.Json.JsonSerializer.Serialize(esperada),
            "Reparar el relleno debe cambiar únicamente los fondos omitidos de A1:H2 y conservar fondos explícitos, datos, fórmulas y formatos.");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        hoja = MYGProyectoStorage.Leer(ruta).Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Costos.Hoja;
        Exige(hoja.RellenoCabeceraEstandarAplicado && hoja.Celdas["D2"].ColorFondo == "EFF9FC" &&
            !MYGEdicionHoja.RepararRellenoCabeceraMetrado(hoja),
            "Guardar y reabrir debe conservar el relleno reparado sin volver a migrar la cabecera.");
        hoja.Celdas["D2"].ColorFondo = ""; // Borrado manual posterior a la reparación.
        hoja = MYGProyectoStorage.Copia(hoja);
        MYGEdicionHoja.InsertarFilas(hoja, 5);
        Exige(!MYGEdicionHoja.RepararRellenoCabeceraMetrado(hoja) && hoja.Celdas["D2"].ColorFondo == "",
            "La reparación debe respetar un relleno borrado manualmente incluso al reabrir e insertar filas.");

        void Conserva(MYGHojaMetrado original, string mensaje)
        {
            string antes = System.Text.Json.JsonSerializer.Serialize(original);
            Exige(!MYGEdicionHoja.RepararRellenoCabeceraMetrado(original) &&
                System.Text.Json.JsonSerializer.Serialize(original) == antes, mensaje);
        }
        var personalizada = CabeceraAnterior(); personalizada.Celdas["D2"].Contenido = "Longitud propia";
        Conserva(personalizada, "La reparación no debe imponer relleno a una cabecera renombrada.");
        var desplazada = CabeceraAnterior(); MYGEdicionHoja.InsertarFilas(desplazada, 1);
        Conserva(desplazada, "La reparación no debe colorear posiciones originales después de desplazar filas de la cabecera.");
        desplazada = CabeceraAnterior(); MYGEdicionHoja.InsertarColumnas(desplazada, 2);
        Conserva(desplazada, "La reparación no debe colorear posiciones originales después de desplazar columnas de la cabecera.");
        var conDatoOculto = CabeceraAnterior(); conDatoOculto.Poner("B1", "Dato secundario conservado");
        Conserva(conDatoOculto, "Una cabecera con contenido secundario debe conservarse sin imponerle un formato estándar.");
        var nueva = MYGHojaMetrado.Crear(); nueva.Celdas["D2"].ColorFondo = "";
        Conserva(nueva, "Una partida nueva debe permitir borrar manualmente el relleno sin que reaparezca al recargarla.");
        string excel = Path.Combine(carpeta, "Cabecera sin relleno importada.xlsx");
        var exportada = CabeceraAnterior();
        MYGExcelPresupuestos.Guardar(excel, new[] { exportada });
        var importada = MYGExcelPresupuestos.Importar(excel, exportada.Nombre, exportada.CeldaTotal);
        Exige(importada.IdPlantilla == "" && importada.Celdas["D2"].ColorFondo == "",
            "La importación debe conservar la identidad y el fondo vacío de la hoja externa.");
        Conserva(importada, "La reparación no debe colorear hojas importadas aunque sus etiquetas coincidan con la plantilla.");
        pasa("Cabeceras estándar guardadas completan el relleno omitido una sola vez, conservando personalizaciones, datos, importaciones y estructuras desplazadas");
    }
}
