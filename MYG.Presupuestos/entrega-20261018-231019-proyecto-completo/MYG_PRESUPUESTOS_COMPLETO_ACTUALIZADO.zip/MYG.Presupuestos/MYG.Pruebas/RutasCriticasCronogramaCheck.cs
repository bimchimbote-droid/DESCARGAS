using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class RutasCriticasCronogramaCheck
{
    private static readonly DateTime Lunes = new(2026, 10, 5);
    private static MYGCronograma Plan() => new() { FechaInicio = Lunes, FechaEstado = Lunes };
    private static MYGTareaCronograma Tarea(MYGCronograma plan, string id, int dias = 1, string padre = null,
        bool resumen = false)
    {
        var tarea = new MYGTareaCronograma { Id = id, Nombre = id, DuracionDias = dias,
            PadreId = padre, EsResumen = resumen };
        plan.Tareas.Add(tarea); return tarea;
    }
    private static void Depende(MYGTareaCronograma tarea, string anterior,
        MYGTipoVinculo tipo = MYGTipoVinculo.FC, int desfase = 0) =>
        tarea.Predecesoras.Add(new() { PredecesoraId = anterior, Tipo = tipo, DesfaseDias = desfase });
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Rutas críticas: " + detalle); }
    private static void Son(IReadOnlySet<string> actual, params string[] esperadas) =>
        Exige(actual.SetEquals(esperadas), "se esperaban [" + string.Join(", ", esperadas) +
            "] y se obtuvieron [" + string.Join(", ", actual.Order()) + "].");

    internal static void Ejecutar(Action<string> pasa)
    {
        RedesIndependientes(pasa);
        RamasEmpatadas(pasa);
        TiposDeVinculo(pasa);
        ManualesEHitos(pasa);
        Importados(pasa);
        ModosYEscala(pasa);
    }

    private static void RedesIndependientes(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "OBRA", resumen: true);
        Tarea(plan, "LARGA A", 3, "OBRA");
        Depende(Tarea(plan, "LARGA B", 3, "OBRA"), "LARGA A");
        Tarea(plan, "CORTA A", 1, "OBRA");
        Depende(Tarea(plan, "CORTA B", 1, "OBRA"), "CORTA A");
        Tarea(plan, "AISLADA", 2, "OBRA");
        string antes = JsonSerializer.Serialize(plan);
        var resultado = MYGMotorCronograma.Calcular(plan);
        string calculoAntes = JsonSerializer.Serialize(resultado);
        var simple = MYGRutasCriticasCronograma.Calcular(plan, resultado, MYGModoRutaCritica.Simple);
        var multiple = MYGRutasCriticasCronograma.Calcular(plan, resultado, MYGModoRutaCritica.Multiple);
        Son(simple, "LARGA A", "LARGA B");
        Son(multiple, "LARGA A", "LARGA B", "CORTA A", "CORTA B", "AISLADA");
        Exige(simple.SetEquals(resultado.Filas.Where(f => !f.Tarea.EsResumen && f.EsCritica).Select(f => f.Tarea.Id)),
            "Simple debe usar las holguras CPM al horizonte global.");
        Exige(multiple.SetEquals(MYGRutasCriticasCronograma.Calcular(plan, MYGModoRutaCritica.Multiple)),
            "la sobrecarga que reutiliza resultados no coincide con el cálculo completo.");
        Exige(JsonSerializer.Serialize(plan) == antes && JsonSerializer.Serialize(resultado) == calculoAntes,
            "seleccionar rutas modificó el plan o la instantánea CPM.");
        pasa("Ruta Simple usa el fin global; Múltiple destaca redes cortas y tareas aisladas bajo el mismo resumen sin mutar fechas ni holguras");
    }

    private static void RamasEmpatadas(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "INICIO");
        Depende(Tarea(plan, "RAMA A", 2), "INICIO");
        Depende(Tarea(plan, "RAMA B", 2), "INICIO");
        Tarea(plan, "RAMA CORTA");
        var fin = Tarea(plan, "FIN");
        Depende(fin, "RAMA A"); Depende(fin, "RAMA B"); Depende(fin, "RAMA CORTA");
        plan.Tareas.Reverse();
        foreach (var modo in new[] { MYGModoRutaCritica.Simple, MYGModoRutaCritica.Multiple })
            Son(MYGRutasCriticasCronograma.Calcular(plan, modo), "INICIO", "RAMA A", "RAMA B", "FIN");
        pasa("Ambos modos mantienen las dos ramas críticas empatadas y excluyen una rama con holgura aunque la tabla esté desordenada");
    }

    private static void TiposDeVinculo(Action<string> pasa)
    {
        foreach (var caso in new[] {
            (Tipo: MYGTipoVinculo.FC, Desfase: -1, Ambas: true),
            (Tipo: MYGTipoVinculo.CC, Desfase: 1, Ambas: false),
            (Tipo: MYGTipoVinculo.FF, Desfase: 0, Ambas: true),
            (Tipo: MYGTipoVinculo.CF, Desfase: 3, Ambas: false) })
        {
            var plan = Plan(); plan.Calendario.Feriados.Add(new(2026, 10, 7));
            Tarea(plan, "HORIZONTE GLOBAL", 20); Tarea(plan, "A", 5);
            Depende(Tarea(plan, "B", 2), "A", caso.Tipo, caso.Desfase);
            Son(MYGRutasCriticasCronograma.Calcular(plan, MYGModoRutaCritica.Simple), "HORIZONTE GLOBAL");
            Son(MYGRutasCriticasCronograma.Calcular(plan, MYGModoRutaCritica.Multiple),
                caso.Ambas ? new[] { "HORIZONTE GLOBAL", "A", "B" } : new[] { "HORIZONTE GLOBAL", "A" });
        }
        pasa("Múltiple calcula holguras locales con vínculos FC/CC/FF/CF, desfase negativo y calendario con feriados");
    }

    private static void ManualesEHitos(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "HORIZONTE GLOBAL", 20); Tarea(plan, "ANTERIOR");
        var manual = Tarea(plan, "FECHA FIJA"); manual.Modo = MYGModoTarea.Manual;
        manual.InicioManual = new(2026, 10, 8); Depende(manual, "ANTERIOR");
        Depende(Tarea(plan, "POSTERIOR"), manual.Id);
        Depende(Tarea(plan, "ENTREGA", 0), "POSTERIOR");
        Son(MYGRutasCriticasCronograma.Calcular(plan, MYGModoRutaCritica.Simple), "HORIZONTE GLOBAL");
        Son(MYGRutasCriticasCronograma.Calcular(plan, MYGModoRutaCritica.Multiple),
            "HORIZONTE GLOBAL", "POSTERIOR", "ENTREGA");
        Exige(MYGMotorCronograma.Calcular(plan).Filas.Single(f => f.Tarea.Id == "ANTERIOR").HolguraDias == 2,
            "la fecha fija debe dejar dos jornadas de holgura a su predecesora.");

        // Una restricción manual incumplida da holgura negativa en su
        // predecesora, sin cambiar la fecha fijada ni marcar el manual.
        var incompatible = Plan(); Tarea(incompatible, "HORIZONTE GLOBAL", 20);
        Tarea(incompatible, "ATRASADA", 5);
        var fija = Tarea(incompatible, "MANUAL"); fija.Modo = MYGModoTarea.Manual;
        fija.InicioManual = Lunes.AddDays(1); Depende(fija, "ATRASADA");
        foreach (var modo in new[] { MYGModoRutaCritica.Simple, MYGModoRutaCritica.Multiple })
            Son(MYGRutasCriticasCronograma.Calcular(incompatible, modo), "HORIZONTE GLOBAL", "ATRASADA");
        pasa("Múltiple respeta anclas manuales, conserva holguras antes de la fecha fija, incluye hitos y mantiene restricciones incumplidas sin mover tareas");
    }

    private static void Importados(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "OTRA RED", 20); Tarea(plan, "PREVIA", 2);
        var manual = Tarea(plan, "IMPORTADA", 2); manual.Modo = MYGModoTarea.Manual;
        manual.InicioManual = new(2026, 10, 8);
        manual.FechasImportadasDelphin = new() { Inicio = manual.InicioManual.Value,
            Fin = new(2026, 10, 10), DuracionDias = 2 };
        Depende(manual, "PREVIA", MYGTipoVinculo.FF);
        Depende(Tarea(plan, "POSTERIOR", 2), manual.Id);
        var hito = Tarea(plan, "HITO MANUAL", 0); hito.Modo = MYGModoTarea.Manual;
        hito.InicioManual = new(2026, 10, 17);
        string antes = JsonSerializer.Serialize(plan);
        var esperadas = new HashSet<string>(StringComparer.Ordinal);
        foreach (string[] ids in new[] { new[] { "OTRA RED" }, new[] { "PREVIA", "IMPORTADA", "POSTERIOR" },
            new[] { "HITO MANUAL" } })
        {
            var red = JsonSerializer.Deserialize<MYGCronograma>(antes);
            red.Tareas.RemoveAll(t => !ids.Contains(t.Id));
            esperadas.UnionWith(MYGMotorCronograma.Calcular(red).Filas.Where(f => f.EsCritica).Select(f => f.Tarea.Id));
        }
        Exige(MYGRutasCriticasCronograma.Calcular(plan, MYGModoRutaCritica.Multiple).SetEquals(esperadas),
            "las fechas importadas y manuales inhábiles no coinciden con el CPM de sus redes independientes.");
        Exige(JsonSerializer.Serialize(plan) == antes, "el cálculo modificó las fechas importadas.");
        pasa("Múltiple coincide con CPM por red al conservar finales importados y un hito manual en sábado");
    }

    private static void ModosYEscala(Action<string> pasa)
    {
        var vacio = Plan(); Tarea(vacio, "RESUMEN VACÍO", resumen: true);
        foreach (var modo in Enum.GetValues<MYGModoRutaCritica>())
            Son(MYGRutasCriticasCronograma.Calcular(vacio, modo));
        var plan = Plan();
        for (int n = 0; n < 256; n++) Tarea(plan, "AISLADA " + n, n % 8 + 1);
        var resultado = MYGMotorCronograma.Calcular(plan);
        Son(MYGRutasCriticasCronograma.Calcular(plan, resultado, MYGModoRutaCritica.Ninguna));
        Exige(MYGRutasCriticasCronograma.Calcular(plan, resultado, MYGModoRutaCritica.Multiple).Count == 256 &&
            MYGRutasCriticasCronograma.Calcular(plan, resultado, MYGModoRutaCritica.Simple).Count == 32,
            "las tareas aisladas deben usar horizontes propios sin unirse por ausencia de vínculos.");
        bool rechazado = false;
        try { MYGRutasCriticasCronograma.Calcular(plan, (MYGModoRutaCritica)999); }
        catch (ArgumentOutOfRangeException) { rechazado = true; }
        Exige(rechazado, "se aceptó un modo de ruta crítica inexistente.");
        pasa("Ninguna oculta todas las rutas, los resúmenes vacíos no se colorean y 256 redes aisladas conservan horizontes independientes");
    }
}
