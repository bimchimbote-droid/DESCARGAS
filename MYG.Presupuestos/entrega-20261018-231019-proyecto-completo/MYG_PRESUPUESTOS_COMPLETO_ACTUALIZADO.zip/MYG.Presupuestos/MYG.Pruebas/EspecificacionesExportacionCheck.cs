using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class EspecificacionesExportacionCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (ArgumentException) { return; }
        catch (InvalidOperationException) { return; }
        catch (InvalidDataException) { return; }
        throw new Exception(detalle);
    }

    private static string Firma(object valor) => JsonSerializer.Serialize(valor);

    private static ItemPresupuestoDelphin Nodo(string id, int posicion, string padre = null, bool titulo = false)
        => new() { Id = id, Item = "ITEM-" + id, Descripcion = "Partida " + id, Unidad = "m³",
            ParentId = padre, Posicion = posicion, TipoPropuesta = titulo ? "TITULO" : "PARTIDA" };

    private static MYGProyectoDocumento Crear()
    {
        var a = new MYGPresupuestoDocumento { Id = "P-A", Nombre = "ESTRUCTURAS", Item = "02", Posicion = 2 };
        var b = new MYGPresupuestoDocumento { Id = "P-B", Nombre = "ARQUITECTURA", Item = "03", Posicion = 3 };
        var vacio = new MYGPresupuestoDocumento { Id = "P-V", Nombre = "VACÍO", Item = "01", Posicion = 1 };
        a.Items.AddRange(new[] { Nodo("A2", 2, "TA"), Nodo("B1", 1, "SB"), Nodo("RAIZ", 3),
            Nodo("TB", 2, titulo: true), Nodo("A1", 1, "TA"), Nodo("SB", 1, "TB", true), Nodo("TA", 1, titulo: true) });
        b.Items.Add(Nodo("A1", 1)); // El mismo ID en otro presupuesto no amplía el alcance.
        return new MYGProyectoDocumento { Nombre = "OBRA ABIERTA", Version = 2,
            PresupuestoActivoId = b.Id, Presupuestos = new() { b, a, vacio } };
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        var d = Crear(); string antes = Firma(d);
        var proyecto = MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Proyecto);
        Exige(proyecto.Select(s => s.Presupuesto.Id).SequenceEqual(new[] { "P-V", "P-A", "P-B" }) &&
            proyecto[0].Partidas.Count == 0 && proyecto[1].Partidas.Select(i => i.Id)
                .SequenceEqual(new[] { "A1", "A2", "B1", "RAIZ" }) && proyecto[2].Partidas.Single().Id == "A1" &&
            proyecto.All(s => s.Partidas.All(i => !MYGProyectoStorage.EsTitulo(i))) && Firma(d) == antes,
            "La exportación de proyecto pierde presupuestos vacíos, mezcla partidas o altera el orden jerárquico y los títulos.");
        var empate = Crear(); empate.Presupuestos[0].Posicion = 2; empate.Presupuestos[0].Item = "01";
        Exige(MYGEspecificacionesExportacion.Seleccionar(empate, MYGAlcanceEspecificaciones.Proyecto)
            .Select(s => s.Presupuesto.Id).SequenceEqual(new[] { "P-V", "P-B", "P-A" }),
            "La exportación no aplica el desempate por ítem del editor.");
        pasa("Exportación de proyecto respeta el orden de presupuestos, títulos y subtítulos; incluye secciones vacías sin modificar la obra");

        var presupuesto = MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "p-a");
        Exige(presupuesto.Count == 1 && presupuesto[0].Presupuesto.Id == "P-A" &&
            presupuesto[0].Partidas.Select(i => i.Id).SequenceEqual(new[] { "A1", "A2", "B1", "RAIZ" }) &&
            d.PresupuestoActivoId == "P-B", "Se exportó el presupuesto activo en vez del elegido o se incluyó otro presupuesto.");
        var ajeno = Crear(); ajeno.Id = "PROYECTO-AJENO"; ajeno.Presupuestos[0].Id = "P-AJENO";
        Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "P-AJENO"),
            "Se aceptó un presupuesto de otro proyecto.");
        d.Presupuestos[1].Conexion = new MYGConexionDelphin { RutaSQLite = Path.Combine(Path.GetTempPath(), "NO-EXISTE.sqlite"),
            ProyectoId = "CATALOGO-AJENO", PresupuestoId = "ORIGEN-AJENO" };
        Exige(MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "P-A")
            .Single().Partidas.Count == 4, "Exportar consultó el origen SQLite en vez del proyecto abierto.");
        pasa("Exportación por presupuesto incluye sólo la selección del proyecto abierto, independientemente del activo y de sus vínculos SQLite");

        var origen = d.Presupuestos.Single(p => p.Id == "P-A");
        var rtf = MYGEspecificacionesPagina.Guardar(@"{\rtf1\ansi{\fonttbl{\f0 Arial;}}\b Materiales\b0\par Unicode \u233? {\pict\pngblip 89504E47}}",
            new MYGPaginaEspecificacion { Encabezado = "Encabezado conservado", MargenIzquierdoMm = 28 });
        origen.Items.Single(i => i.Id == "A1").Costos.EspecificacionRtf = rtf;
        origen.Items.Single(i => i.Id == "A1").Costos.EspecificacionTexto = "Texto paralelo intacto";
        origen.Items.Single(i => i.Id == "A2").Costos.EspecificacionTexto = "Texto plano\nLínea dos — m³";
        origen.Items.Single(i => i.Id == "B1").Costos.EspecificacionRtf = "";
        origen.Items.Single(i => i.Id == "B1").Costos.EspecificacionTexto = "";
        origen.Items.Single(i => i.Id == "RAIZ").Costos = null;
        var contenidos = MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "P-A")[0];
        Exige(contenidos.Partidas[0].Costos.EspecificacionRtf == rtf &&
            contenidos.Partidas[0].Costos.EspecificacionTexto == "Texto paralelo intacto" &&
            contenidos.Partidas[1].Costos.EspecificacionTexto == "Texto plano\nLínea dos — m³" &&
            contenidos.Partidas[2].Costos.EspecificacionRtf == "" && contenidos.Partidas[2].Costos.EspecificacionTexto == "" &&
            contenidos.Partidas[3].Costos == null && contenidos.Presupuesto.Items.Count == 7,
            "La selección reescribió RTF, metadatos, texto plano, especificaciones vacías o la estructura del presupuesto.");
        pasa("Selección conserva RTF con imagen y página, texto plano, cuerpos vacíos y títulos necesarios para resolver los códigos visibles");

        antes = Firma(d);
        var instantanea = MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Proyecto);
        Exige(Firma(d) == antes && d.Version == 2 && origen.Items.All(i => i.IdLocalMYG == null) &&
            !ReferenceEquals(instantanea[1].Presupuesto, origen) &&
            ReferenceEquals(instantanea[1].Partidas[0], instantanea[1].Presupuesto.Items.Single(i => i.Id == "A1")),
            "Exportar normalizó el modelo o dejó referencias a objetos de la obra.");
        origen.Nombre = "CAMBIO POSTERIOR"; origen.Items.Single(i => i.Id == "A1").Costos.EspecificacionRtf = "CAMBIO";
        Exige(instantanea[1].Presupuesto.Nombre == "ESTRUCTURAS" && instantanea[1].Partidas[0].Costos.EspecificacionRtf == rtf,
            "Una edición posterior del proyecto modificó la instantánea de exportación.");
        instantanea[1].Partidas[1].Descripcion = "CAMBIO DE LA VISTA PREVIA";
        Exige(origen.Items.Single(i => i.Id == "A2").Descripcion == "Partida A2", "Editar la vista previa modificó la obra.");
        RechazaLista(instantanea); RechazaLista(instantanea[1].Partidas);
        pasa("Instantánea de exportación aísla ediciones posteriores y de la vista previa; sus listas son de sólo lectura y no normaliza identidades");

        d = Crear(); antes = Firma(d);
        Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(null, MYGAlcanceEspecificaciones.Proyecto), "Se aceptó proyecto nulo.");
        Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, (MYGAlcanceEspecificaciones)99), "Se aceptó un alcance desconocido.");
        foreach (string id in new string[] { null, "", " ", "NO-EXISTE" })
            Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, id), "Se aceptó selección vacía o ausente.");
        Exige(Firma(d) == antes, "Una selección inválida cambió el documento.");
        var duplicado = MYGProyectoStorage.Copia(d.Presupuestos[1]); duplicado.Id = "p-a"; d.Presupuestos.Add(duplicado); antes = Firma(d);
        Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Proyecto), "Se aceptaron presupuestos duplicados.");
        Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "P-A"), "Se eligió arbitrariamente un presupuesto duplicado.");
        Exige(Firma(d) == antes, "Rechazar presupuestos duplicados modificó el documento.");
        pasa("Selección rechaza proyectos nulos, alcances desconocidos, presupuestos ausentes o ajenos y duplicados sin cambios parciales");

        Jerarquias(pasa);
        Compatibilidad(pasa);
        Archivos(pasa);
    }

    private static void RechazaLista<T>(IReadOnlyList<T> lista)
    {
        try { ((IList<T>)lista).Clear(); }
        catch (NotSupportedException) { return; }
        throw new Exception("La lista de exportación permite cambiar su selección.");
    }

    private static void Jerarquias(Action<string> pasa)
    {
        var cambios = new Action<MYGPresupuestoDocumento>[]
        {
            p => p.Items[0].ParentId = "PADRE-AUSENTE",
            p => p.Items.Single(i => i.Id == "TA").ParentId = "TA",
            p => { p.Items.Single(i => i.Id == "TA").ParentId = "SB"; p.Items.Single(i => i.Id == "TB").ParentId = "TA"; },
            p => p.Items[0].Id = p.Items[1].Id,
            p => p.Items.Add(null),
            p => p.Items[0].Id = "",
            p => p.Items.Single(i => i.Id == "TA").TipoPropuesta = "PARTIDA",
            p => { p.Items.Clear(); for (int n = 0; n < 66; n++) p.Items.Add(Nodo("N" + n, 1, n == 0 ? null : "N" + (n - 1), true)); }
        };
        foreach (var cambio in cambios)
        {
            var d = Crear(); cambio(d.Presupuestos.Single(p => p.Id == "P-A")); string antes = Firma(d);
            Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "P-A"),
                "La exportación aceptó una jerarquía incompleta, circular, duplicada o excesiva.");
            Exige(Firma(d) == antes, "Una jerarquía rechazada dejó cambios parciales.");
            Exige(MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "P-B")
                .Single().Partidas.Count == 1, "Un presupuesto ajeno malformado bloqueó la selección válida.");
            Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Proyecto),
                "La exportación de proyecto omitió un presupuesto malformado sin informar.");
        }
        pasa("Exportación rechaza jerarquías incompletas, circulares, duplicadas y profundas; un presupuesto ajeno malformado no bloquea la selección válida");
    }

    private static void Compatibilidad(Action<string> pasa)
    {
        var d = Crear(); var p = d.Presupuestos.Single(x => x.Id == "P-A");
        p.Items.Single(i => i.Id == "TA").TipoPropuesta = null;
        p.Items.Single(i => i.Id == "RAIZ").ParentId = "__ROOT__";
        d.Presupuestos.Single(x => x.Id == "P-V").Items = null;
        string antes = Firma(d);
        var seleccionado = MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Proyecto);
        Exige(seleccionado[0].Partidas.Count == 0 && seleccionado[1].Partidas.Select(i => i.Id)
            .SequenceEqual(new[] { "A1", "A2", "B1", "RAIZ" }) && Firma(d) == antes,
            "La exportación de una jerarquía antigua perdió partidas o normalizó la obra.");
        var vacio = new MYGProyectoDocumento { Nombre = "VACÍO", Presupuestos = null };
        Exige(MYGEspecificacionesExportacion.Seleccionar(vacio, MYGAlcanceEspecificaciones.Proyecto).Count == 0 && vacio.Presupuestos == null,
            "Un proyecto sin presupuestos cambió al consultar su exportación.");
        d.Presupuestos.Add(null); d.Presupuestos.Add(new MYGPresupuestoDocumento { Id = "" });
        Exige(MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Presupuesto, "P-A").Count == 1,
            "Un presupuesto ajeno incompleto bloqueó la selección válida.");
        Rechaza(() => MYGEspecificacionesExportacion.Seleccionar(d, MYGAlcanceEspecificaciones.Proyecto), "Se aceptó un presupuesto nulo o sin ID en el proyecto.");
        pasa("Exportación acepta raíces e inferencia de títulos antiguas en su copia y secciones vacías, sin normalizar el documento abierto");
    }

    private static void Archivos(Action<string> pasa)
    {
        var d = Crear(); d.Nombre = "../OBRA: \\ norte/<>|?*\"\u0001\r\n.";
        d.Presupuestos.Single(p => p.Id == "P-A").Nombre = "Estructuras: m³ / A"; string antes = Firma(d);
        string proyecto = MYGEspecificacionesExportacion.NombreArchivo(d, MYGAlcanceEspecificaciones.Proyecto);
        string presupuesto = MYGEspecificacionesExportacion.NombreArchivo(d, MYGAlcanceEspecificaciones.Presupuesto, "P-A");
        Exige(proyecto.EndsWith(".doc", StringComparison.Ordinal) && presupuesto == "Especificaciones - Estructuras_ m³ _ A.doc" &&
            proyecto.All(c => !char.IsControl(c) && !"<>:\"/\\|?*".Contains(c)) && Firma(d) == antes,
            "El nombre sugerido contiene caracteres inválidos de Windows o no corresponde al alcance.");
        d.Nombre = new string('A', 1000);
        Exige(MYGEspecificacionesExportacion.NombreArchivo(d, MYGAlcanceEspecificaciones.Proyecto).Length <= 160,
            "El nombre sugerido supera el límite de longitud previsto.");
        d.Nombre = " "; d.Presupuestos[1].Nombre = null;
        Exige(MYGEspecificacionesExportacion.NombreArchivo(d, MYGAlcanceEspecificaciones.Proyecto) == "Especificaciones - Proyecto.doc" &&
            MYGEspecificacionesExportacion.NombreArchivo(d, MYGAlcanceEspecificaciones.Presupuesto, "P-A") == "Especificaciones - Presupuesto.doc",
            "Los documentos sin nombre no tienen una sugerencia segura.");
        Rechaza(() => MYGEspecificacionesExportacion.NombreArchivo(d, MYGAlcanceEspecificaciones.Presupuesto, "AJENO"),
            "El nombre sugerido aceptó un presupuesto ajeno.");
        pasa("Nombres .doc corresponden al alcance y conservan Unicode, eliminan caracteres y rutas inválidos de Windows y limitan su longitud");
    }
}
