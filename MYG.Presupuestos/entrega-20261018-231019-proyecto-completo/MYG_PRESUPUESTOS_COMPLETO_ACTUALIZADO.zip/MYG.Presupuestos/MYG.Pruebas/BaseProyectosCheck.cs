using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class BaseProyectosCheck
{
    private static void Exige(bool ok, string texto) { if (!ok) throw new Exception(texto); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Rechaza(Action accion, string detalle)
    {
        bool error = false;
        try { accion(); }
        catch (InvalidDataException) { error = true; }
        catch (InvalidOperationException) { error = true; }
        catch (SqliteException) { error = true; }
        catch (IOException) { error = true; }
        catch (ArgumentException) { error = true; }
        Exige(error, detalle);
    }
    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWriteCreate : SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open(); return c;
    }
    private static long Cuenta(string ruta, string tabla)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM " + tabla;
        return Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture);
    }
    private static void Integridad(string ruta)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "PRAGMA integrity_check";
        Exige((string)cmd.ExecuteScalar() == "ok", "La base no supera integrity_check.");
        cmd.CommandText = "PRAGMA foreign_key_check";
        using var r = cmd.ExecuteReader();
        Exige(!r.Read(), "La base contiene relaciones SQL sin destino.");
    }
    private static ItemPresupuestoDelphin Partida(string descripcion, string unidad = "prb")
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        { Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = descripcion, Unidad = unidad,
            TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1 };
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Base de varias obras ; prueba.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        Exige(Encoding.ASCII.GetString(File.ReadAllBytes(ruta), 0, 16) == "SQLite format 3\0", "El archivo no es SQLite real.");
        Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 0 && Cuenta(ruta, "presupuesto") == 0 &&
            MYGCatalogos.Listar(ruta, true).Count == 0 && MYGCatalogos.Listar(ruta, false).Count == 0,
            "Una base nueva debe iniciar sin proyectos, presupuestos, partidas ni insumos.");
        var basicas = MYGCatalogoUnidades.Listar(ruta);
        Exige(basicas.Count == 62 && new[] { "und", "m", "m²", "m³", "kg", "t", "l", "gbl", "hh", "hm", "dia", "mes", "bol" }
            .All(simbolo => basicas.Any(u => u.Simbolo == simbolo)), "La base nueva no contiene el catálogo de 62 unidades de Delphin.");
        Exige(basicas.Single(u => u.Simbolo == "bol").Descripcion == "Bolsa" &&
            !basicas.Any(u => u.Simbolo is "m2" or "m3" or "Bls" or "glb"),
            "Las unidades iniciales no respetan las abreviaturas nativas y los superíndices de Delphin.");
        Exige(basicas.Select(u => u.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() == 62 &&
            basicas.Count(u => u.Simbolo == "m²") == 2 && basicas.Count(u => u.Simbolo == "m³") == 2 &&
            basicas.Single(u => u.Simbolo == "m²" && u.Tipo == "N").Descripcion == "Metro Cuadrado" &&
            basicas.Single(u => u.Simbolo == "m²" && u.Tipo == "G").Descripcion == "Metro cuadrado",
            "Se mezclaron las identidades o las variantes General/Global de las unidades iniciales.");
        string inicial = Huella(ruta);
        Rechaza(() => MYGBaseDatos.CrearBaseVacia(ruta), "Crear base permitió sobrescribir una base existente.");
        Exige(Huella(ruta) == inicial, "Crear base alteró el archivo existente.");
        Rechaza(() => MYGBaseDatos.CrearBaseVacia(Path.Combine(carpeta, "extension incorrecta.sql")),
            "Crear base aceptó una extensión distinta de .sqlite.");
        pasa("Base nueva es SQLite, inicia sin obras y contiene las 62 unidades nativas con variantes General/Global, sin sobrescribir archivos");
        ComprobarUnidadesLegadas(carpeta, pasa);
        ComprobarCatalogoAnteriorTrece(carpeta, pasa);

        var unidad = MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo { Simbolo = "prb", Descripcion = "Unidad de prueba" });
        string unidadesAntes = Huella(ruta);
        Rechaza(() => MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo { Simbolo = "PRB", Descripcion = "Duplicada" }),
            "Se aceptó un símbolo de unidad duplicado con distinto uso de mayúsculas.");
        Exige(Huella(ruta) == unidadesAntes, "Rechazar una unidad duplicada alteró la base.");
        var libre = MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo { Simbolo = "libre", Descripcion = "Sin uso" });
        libre.Simbolo = "libre2";
        MYGCatalogoUnidades.Guardar(ruta, libre);
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad='libre'";
            Exige(Convert.ToInt64(cmd.ExecuteScalar()) == 0, "Renombrar una unidad sin uso dejó el símbolo anterior en Delphin.");
            cmd.CommandText = "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad='libre2'";
            Exige(Convert.ToInt64(cmd.ExecuteScalar()) == 1, "La unidad renombrada no aparece una sola vez en Delphin.");
        }
        MYGCatalogoUnidades.Eliminar(ruta, libre.Id);
        Exige(!MYGCatalogoUnidades.Listar(ruta).Any(u => u.Id == libre.Id), "No se eliminó una unidad sin uso.");
        pasa("Catálogo de unidades admite símbolos propios, rechaza duplicados y elimina unidades sin uso");

        var primera = MYGProyectoStorage.Nuevo("PRIMERA OBRA", "ESTRUCTURAS");
        var partida = Partida("PARTIDA DE LA PRIMERA OBRA");
        partida.Costos.Cantidad = 2.3456m; partida.Costos.PrecioDirecto = 12.34m;
        partida.Filtros.Add(new FiltroPlanificacion { Parametro = "Nivel", Regla = "igual", Valor = "N01" });
        primera.Presupuestos[0].Items.Add(partida);
        primera.Presupuestos.Add(new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 });
        var segunda = MYGProyectoStorage.Nuevo("SEGUNDA OBRA", "INSTALACIONES");
        var insumo = new MYGInsumo { Codigo = "I-QA", Descripcion = "Material compartido en catálogo", Unidad = "kg", Precio = 9.25m };
        var partidaDos = Partida("PARTIDA DE LA SEGUNDA OBRA", "m2");
        segunda.Presupuestos[0].Costos.Insumos.Add(insumo);
        partidaDos.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Cantidad = 0.5m });
        segunda.Presupuestos[0].Items.Add(partidaDos);
        MYGProyectoStorage.Guardar(ruta, primera); MYGProyectoStorage.Guardar(ruta, segunda);
        MYGCatalogos.GuardarInsumo(ruta, insumo);
        var resumenes = MYGBaseDatos.ListarProyectos(ruta);
        Exige(resumenes.Count == 2 && resumenes.Single(x => x.Id == primera.Id).CantidadPresupuestos == 2 &&
            resumenes.Single(x => x.Id == segunda.Id).CantidadPresupuestos == 1,
            "El listado no incluye todos los proyectos y sus cantidades de presupuestos.");
        Exige(MYGBaseDatos.LeerProyecto(ruta, primera.Id).Presupuestos[0].Items.Single().Filtros.Single().Valor == "N01" &&
            MYGBaseDatos.LeerProyecto(ruta, segunda.Id).Presupuestos.Single().Items.Single().Descripcion == partidaDos.Descripcion,
            "La lectura por proyecto mezcló partidas o filtros.");
        Rechaza(() => MYGBaseDatos.LeerProyecto(ruta), "La lectura sin identificar proyecto eligió una obra arbitraria.");
        Exige(Cuenta(ruta, "proyecto") == 2 && Cuenta(ruta, "presupuesto") == 3 && Cuenta(ruta, "partida_presupuesto") == 2,
            "Las tablas SQL no representan los dos proyectos y sus presupuestos.");
        pasa("Un solo archivo contiene varias obras, sus presupuestos y filtros; abrir exige identificar la obra");

        string segundaAntes = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id));
        primera.Nombre = "PRIMERA OBRA ACTUALIZADA";
        primera.Presupuestos.RemoveAt(1); partida.Costos.Cantidad = 7.25m;
        MYGProyectoStorage.Guardar(ruta, primera);
        Exige(MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id)) == segundaAntes &&
            MYGBaseDatos.LeerProyecto(ruta, primera.Id).Presupuestos.Count == 1 && Cuenta(ruta, "presupuesto") == 2,
            "Guardar una obra eliminó o modificó presupuestos de otra obra.");
        Exige(MYGCatalogos.Listar(ruta, false).Single().Codigo == insumo.Codigo &&
            MYGCatalogoUnidades.Listar(ruta).Count == basicas.Count + 1,
            "Guardar una obra modificó los catálogos comunes o duplicó unidades.");
        pasa("Guardar y quitar presupuestos en una obra conserva las otras obras y los catálogos comunes");

        Rechaza(() => MYGCatalogoUnidades.Eliminar(ruta, unidad.Id), "Se eliminó una unidad usada por una partida.");
        Rechaza(() => MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo
            { Id = unidad.Id, Simbolo = "renombrada", Descripcion = unidad.Descripcion }),
            "Se cambió el símbolo de una unidad usada por una partida.");
        MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo { Id = unidad.Id, Simbolo = "prb", Descripcion = "Descripción actualizada" });
        Exige(MYGCatalogoUnidades.Listar(ruta).Single(u => u.Id == unidad.Id).Descripcion == "Descripción actualizada",
            "No se actualizó la descripción de una unidad conservando su símbolo.");
        pasa("Una unidad en uso conserva su símbolo y permite corregir su descripción");

        string primeraAntes = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, primera.Id));
        var conflicto = MYGProyectoStorage.Copia(primera);
        conflicto.Presupuestos[0].Id = segunda.Presupuestos[0].Id;
        Rechaza(() => MYGProyectoStorage.Guardar(ruta, conflicto), "Se aceptó un presupuesto con identidad de otra obra.");
        Exige(MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, primera.Id)) == primeraAntes &&
            MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id)) == segundaAntes,
            "Un fallo de guardado no revirtió completamente sus cambios.");
        Integridad(ruta);
        pasa("Conflictos de identidad revierten la transacción completa y la base mantiene integridad SQL");

        string antigua = Path.Combine(carpeta, "Base MYG versión uno.sqlite");
        var legado = MYGProyectoStorage.Nuevo("OBRA GUARDADA ANTES DE LA MIGRACIÓN");
        MYGProyectoStorage.Validar(legado);
        CrearVersionUno(antigua, legado);
        string antiguaAntes = Huella(antigua);
        Exige(MYGBaseDatos.LeerProyecto(antigua, legado.Id).Nombre == legado.Nombre &&
            MYGBaseDatos.ListarProyectos(antigua).Single().CantidadPresupuestos == 1 &&
            MYGCatalogoUnidades.Listar(antigua).Any(u => u.Simbolo == "leg"),
            "No se abrió la base v1 o no se reconocieron sus unidades existentes.");
        Exige(Huella(antigua) == antiguaAntes, "Una lectura de base v1 cambió el archivo.");
        MYGProyectoStorage.Guardar(antigua, legado);
        using (var c = Conexion(antigua))
        using (var cmd = c.CreateCommand())
        { cmd.CommandText = "SELECT version FROM myg_info"; Exige(Convert.ToInt64(cmd.ExecuteScalar()) == 3, "No se actualizó el esquema v1."); }
        Exige(MYGCatalogos.Listar(antigua, false).Single().Codigo == "LEG-01" &&
            MYGCatalogoUnidades.Listar(antigua).Any(u => u.Simbolo == "leg"),
            "La migración perdió el catálogo anterior o sus unidades.");
        MYGProyectoStorage.Guardar(antigua, MYGProyectoStorage.Nuevo("SEGUNDA OBRA TRAS MIGRAR"));
        Exige(MYGBaseDatos.ListarProyectos(antigua).Count == 2, "La base migrada no admite varios proyectos.");
        Integridad(antigua);
        pasa("Bases MYG v1 se leen sin cambios y migran al formato nativo al escribir conservando obra, catálogos y unidades");
    }

    private static void ComprobarUnidadesLegadas(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Unidades anteriores m2 y m3.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        var originales = MYGCatalogoUnidades.Listar(ruta).Where(u => u.Simbolo is "m²" or "m³").ToList();
        using (var c = Conexion(ruta, true))
        using (var cmd = c.CreateCommand())
        {
            // Simula una base guardada con los símbolos históricos, manteniendo sus identificadores.
            cmd.CommandText = "UPDATE catalogo_unidad SET simbolo=REPLACE(REPLACE(simbolo,'²','2'),'³','3'); " +
                "UPDATE unidad SET abreviatura_unidad=REPLACE(REPLACE(abreviatura_unidad,'²','2'),'³','3')," +
                "descripcion_unidad=REPLACE(REPLACE(descripcion_unidad,'²','2'),'³','3');";
            cmd.ExecuteNonQuery();
        }
        string antes = Huella(ruta);
        var legadas = MYGCatalogoUnidades.Listar(ruta);
        foreach (var original in originales)
        {
            var legada = legadas.Single(u => u.Id == original.Id);
            Exige(legada.Simbolo == (original.Simbolo == "m²" ? "m2" : "m3") &&
                legada.SimboloVisible == original.Simbolo && legada.ToString().StartsWith(original.Simbolo + " · "),
                "Una unidad anterior perdió su símbolo o su identidad al mostrar el superíndice.");
            Rechaza(() => MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo
                { Simbolo = original.Simbolo, Descripcion = original.Descripcion }),
                "Se duplicó una unidad anterior al usar su representación con superíndice.");
        }
        Exige(Huella(ruta) == antes, "Consultar unidades anteriores o rechazar un alias modificó la base.");
        var documento = MYGProyectoStorage.Nuevo("OBRA CON UNIDADES HISTÓRICAS");
        documento.Presupuestos[0].Items.Add(Partida("SUPERFICIE ANTERIOR", "m2"));
        documento.Presupuestos[0].Items.Add(Partida("VOLUMEN ANTERIOR", "m3"));
        MYGProyectoStorage.Guardar(ruta, documento);
        var reabiertas = MYGCatalogoUnidades.Listar(ruta);
        var partidas = MYGBaseDatos.LeerProyecto(ruta, documento.Id).Presupuestos[0].Items;
        Exige(reabiertas.Count == legadas.Count && originales.All(original =>
            reabiertas.Single(u => u.Id == original.Id).Simbolo == (original.Simbolo == "m²" ? "m2" : "m3")) &&
            partidas.Single(i => i.Descripcion == "SUPERFICIE ANTERIOR").Unidad == "m2" &&
            partidas.Single(i => i.Descripcion == "VOLUMEN ANTERIOR").Unidad == "m3",
            "Guardar una obra cambió símbolos anteriores, perdió identidades o duplicó unidades equivalentes.");
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad IN ('m2','m3')";
            Exige(Convert.ToInt64(cmd.ExecuteScalar()) == originales.Count && originales.Count == 4 && Cuenta(ruta, "unidad") == 62,
                "Guardar unidades anteriores cambió los símbolos nativos o agregó equivalentes duplicados.");
        }
        Integridad(ruta);
        pasa("m2/m3 anteriores conservan símbolos e identidades al leer y guardar, se muestran m²/m³ y rechazan alias duplicados");
    }

    private static void ComprobarCatalogoAnteriorTrece(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Catálogo MYG anterior con trece unidades.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        (string Simbolo, string Descripcion)[] anteriores =
        {
            ("und", "Unidad"), ("m", "Metro"), ("m2", "Metro cuadrado"), ("m3", "Metro cúbico"),
            ("kg", "Kilogramo"), ("t", "Tonelada"), ("l", "Litro"), ("glb", "Global"),
            ("hh", "Hora hombre"), ("hm", "Hora máquina"), ("día", "Día"), ("mes", "Mes"), ("Bls", "Bolsas")
        };
        using (var c = Conexion(ruta, true))
        using (var t = c.BeginTransaction())
        using (var cmd = c.CreateCommand())
        {
            cmd.Transaction = t;
            // Reproduce el catálogo anterior sin copiar ninguna base: trece símbolos
            // únicos, identidades MYG y enlaces nativos a los cinco tipos de costo.
            cmd.CommandText = "DELETE FROM unidad_map; DELETE FROM unidad_tipocosto; DELETE FROM unidad_tipocostonew; " +
                "DELETE FROM unidad; DELETE FROM myg_delphin_fila WHERE tabla='unidad'; DROP TABLE catalogo_unidad; " +
                "CREATE TABLE catalogo_unidad(id TEXT PRIMARY KEY COLLATE NOCASE," +
                "simbolo TEXT NOT NULL COLLATE NOCASE UNIQUE,descripcion TEXT NOT NULL);";
            cmd.ExecuteNonQuery();
            foreach (var (simbolo, descripcion) in anteriores)
            {
                string id = "MYG-UNIDAD-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(simbolo.ToUpperInvariant())))[..16];
                string normalizado = simbolo.ToLowerInvariant().Replace("²", "2").Replace("³", "3").Replace(" ", "").Replace("m^", "m");
                string nativo = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("unidad:" + normalizado)))[..12];
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("$id", id); cmd.Parameters.AddWithValue("$nativo", nativo);
                cmd.Parameters.AddWithValue("$simbolo", simbolo); cmd.Parameters.AddWithValue("$descripcion", descripcion);
                cmd.Parameters.AddWithValue("$tipo", simbolo is "hh" or "hm" ? "H" : "N");
                cmd.CommandText = "INSERT INTO catalogo_unidad VALUES($id,$simbolo,$descripcion); " +
                    "INSERT INTO unidad(id_unidad,descripcion_unidad,abreviatura_unidad,informacion_unidad," +
                    "magnitud_unidad,id_unidadbase,es_unidadcosto,es_unidadtiempo,es_unidadgasto,en_cronograma," +
                    "es_dependiente,tipo_unidad,divisible) " +
                    "VALUES($nativo,$simbolo,$simbolo,$descripcion,1,$nativo,'S','N','S','N','N',$tipo,'S'); " +
                    "INSERT INTO myg_delphin_fila VALUES('catalogo_unidad','unidad',$nativo);";
                cmd.ExecuteNonQuery();
                foreach (var grupo in Enum.GetValues<MYGGrupoRecurso>())
                {
                    cmd.CommandText = "INSERT INTO unidad_tipocosto VALUES($nativo,$grupo)";
                    cmd.Parameters.AddWithValue("$grupo", "TC" + ((int)grupo + 1).ToString("D10", CultureInfo.InvariantCulture));
                    cmd.ExecuteNonQuery(); cmd.Parameters.RemoveAt("$grupo");
                }
            }
            t.Commit();
        }
        string antes = Huella(ruta);
        var originales = MYGCatalogoUnidades.Listar(ruta);
        Exige(originales.Count == 13 && anteriores.All(u => originales.Any(x => x.Simbolo == u.Simbolo && x.Descripcion == u.Descripcion)) &&
            originales.All(u => u.EsCostoUnitario && u.EsGastoGeneral && u.TiposCosto.Count == 5) &&
            Cuenta(ruta, "unidad_tipocostonew") == 0,
            "Consultar el catálogo anterior cambió sus trece símbolos o ignoró las relaciones antiguas por tipo de costo.");
        Exige(originales.Single(u => u.Simbolo == "m2").SimboloVisible == "m²" &&
            originales.Single(u => u.Simbolo == "m3").SimboloVisible == "m³" && Huella(ruta) == antes,
            "Leer el catálogo anterior modificó el archivo o la representación visible de m2/m3.");
        Rechaza(() => MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo { Simbolo = "m²", Descripcion = "Alias de superficie" }),
            "El catálogo anterior aceptó duplicar m2 con su alias m².");
        Exige(Huella(ruta) == antes, "Rechazar un alias alteró el catálogo anterior.");
        var documento = MYGProyectoStorage.Nuevo("OBRA SINTÉTICA CON EL CATÁLOGO ANTERIOR");
        documento.Presupuestos[0].Items.Add(Partida("SUPERFICIE ANTERIOR", "m2"));
        documento.Presupuestos[0].Items.Add(Partida("VOLUMEN ANTERIOR", "m3"));
        MYGProyectoStorage.Guardar(ruta, documento);
        var reabiertas = MYGCatalogoUnidades.Listar(ruta);
        Exige(reabiertas.Count == 13 && Cuenta(ruta, "unidad") == 13 && Cuenta(ruta, "catalogo_unidad") == 13 &&
            originales.All(u => reabiertas.Any(x => x.Id == u.Id && x.Simbolo == u.Simbolo && x.Descripcion == u.Descripcion)),
            "Guardar una base anterior reemplazó sus trece unidades por las 62 iniciales o cambió sus identidades.");
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad IN ('m2','m3')";
            Exige(Convert.ToInt64(cmd.ExecuteScalar()) == 2, "Guardar la base anterior cambió los símbolos nativos m2/m3.");
            cmd.CommandText = "SELECT sql FROM sqlite_master WHERE type='table' AND name='catalogo_unidad'";
            Exige(((string)cmd.ExecuteScalar()).Contains("UNIQUE", StringComparison.OrdinalIgnoreCase),
                "Guardar la base anterior reconstruyó su catálogo o eliminó su restricción histórica de símbolos únicos.");
        }
        Integridad(ruta);
        pasa("Catálogo anterior de trece unidades conserva símbolos, identidades, UNIQUE y relaciones por tipo de costo; no recibe las 62 unidades nuevas");
    }

    private static void CrearVersionUno(string ruta, MYGProyectoDocumento documento)
    {
        using var c = Conexion(ruta, true); using var t = c.BeginTransaction();
        using var cmd = c.CreateCommand(); cmd.Transaction = t; cmd.CommandText = EsquemaVersionUno; cmd.ExecuteNonQuery();
        cmd.CommandText = "INSERT INTO myg_info VALUES('MYG_SQLITE',1); " +
            "INSERT INTO proyecto VALUES($id,$nombre,$json,$fecha); " +
            "INSERT INTO presupuesto VALUES($presupuesto,$id,'01','PRESUPUESTO GENERAL',1,$costos); " +
            "INSERT INTO catalogo_insumo VALUES('LEG-INSUMO','LEG-01','Catálogo anterior','leg','Materiales','1.25',$insumo,1,$fecha);";
        cmd.Parameters.AddWithValue("$id", documento.Id); cmd.Parameters.AddWithValue("$nombre", documento.Nombre);
        cmd.Parameters.AddWithValue("$json", JsonSerializer.Serialize(documento));
        cmd.Parameters.AddWithValue("$fecha", DateTime.UtcNow.ToString("O"));
        cmd.Parameters.AddWithValue("$presupuesto", documento.Presupuestos[0].Id);
        cmd.Parameters.AddWithValue("$costos", JsonSerializer.Serialize(documento.Presupuestos[0].Costos));
        cmd.Parameters.AddWithValue("$insumo", JsonSerializer.Serialize(new MYGInsumo
            { Id = "LEG-INSUMO", Codigo = "LEG-01", Descripcion = "Catálogo anterior", Unidad = "leg", Precio = 1.25m }));
        cmd.ExecuteNonQuery(); t.Commit();
    }

    // Esquema histórico v1 independiente del esquema vigente para verificar su migración.
    private const string EsquemaVersionUno = """
        CREATE TABLE myg_info(formato TEXT NOT NULL,version INTEGER NOT NULL);
        CREATE TABLE proyecto(id TEXT PRIMARY KEY COLLATE NOCASE,nombre TEXT NOT NULL,json_documento TEXT NOT NULL,modificado_utc TEXT NOT NULL);
        CREATE TABLE presupuesto(id TEXT PRIMARY KEY COLLATE NOCASE,proyecto_id TEXT NOT NULL REFERENCES proyecto(id),codigo TEXT,nombre TEXT NOT NULL,posicion INTEGER NOT NULL,json_datos TEXT NOT NULL);
        CREATE TABLE partida_presupuesto(
            presupuesto_id TEXT NOT NULL REFERENCES presupuesto(id) ON DELETE CASCADE,id TEXT NOT NULL COLLATE NOCASE,id_local TEXT NOT NULL COLLATE NOCASE,
            padre_id TEXT COLLATE NOCASE,item TEXT,descripcion TEXT,unidad TEXT,tipo TEXT NOT NULL,posicion INTEGER NOT NULL,cantidad TEXT NOT NULL,precio_directo TEXT NOT NULL,json_datos TEXT NOT NULL,
            PRIMARY KEY(presupuesto_id,id),UNIQUE(presupuesto_id,id_local),
            FOREIGN KEY(presupuesto_id,padre_id) REFERENCES partida_presupuesto(presupuesto_id,id) DEFERRABLE INITIALLY DEFERRED);
        CREATE TABLE insumo_presupuesto(presupuesto_id TEXT NOT NULL REFERENCES presupuesto(id) ON DELETE CASCADE,id TEXT NOT NULL COLLATE NOCASE,codigo TEXT,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,grupo TEXT NOT NULL,precio TEXT NOT NULL,json_datos TEXT NOT NULL,PRIMARY KEY(presupuesto_id,id));
        CREATE TABLE recurso_presupuesto(
            presupuesto_id TEXT NOT NULL,partida_id TEXT NOT NULL,id TEXT NOT NULL,grupo TEXT NOT NULL,insumo_id TEXT,subpartida_local TEXT,
            modo TEXT NOT NULL,numero_recursos TEXT NOT NULL,cantidad TEXT NOT NULL,desperdicio TEXT NOT NULL,PRIMARY KEY(presupuesto_id,partida_id,id),
            FOREIGN KEY(presupuesto_id,partida_id) REFERENCES partida_presupuesto(presupuesto_id,id) ON DELETE CASCADE,
            FOREIGN KEY(presupuesto_id,insumo_id) REFERENCES insumo_presupuesto(presupuesto_id,id) DEFERRABLE INITIALLY DEFERRED,
            FOREIGN KEY(presupuesto_id,subpartida_local) REFERENCES partida_presupuesto(presupuesto_id,id_local) DEFERRABLE INITIALLY DEFERRED);
        CREATE TABLE catalogo_partida(id TEXT PRIMARY KEY COLLATE NOCASE,codigo TEXT NOT NULL COLLATE NOCASE UNIQUE,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,precio TEXT NOT NULL,json_plantilla TEXT NOT NULL,revision INTEGER NOT NULL,modificado_utc TEXT NOT NULL);
        CREATE TABLE catalogo_insumo(id TEXT PRIMARY KEY COLLATE NOCASE,codigo TEXT NOT NULL COLLATE NOCASE UNIQUE,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,grupo TEXT NOT NULL,precio TEXT NOT NULL,json_datos TEXT NOT NULL,revision INTEGER NOT NULL,modificado_utc TEXT NOT NULL);
        CREATE TABLE catalogo_partida_nodo(catalogo_id TEXT NOT NULL REFERENCES catalogo_partida(id) ON DELETE CASCADE,id_local TEXT NOT NULL,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,es_raiz INTEGER NOT NULL,rendimiento TEXT NOT NULL,jornada TEXT NOT NULL,precio_directo TEXT NOT NULL,json_datos TEXT NOT NULL,PRIMARY KEY(catalogo_id,id_local));
        CREATE TABLE catalogo_partida_insumo(catalogo_id TEXT NOT NULL REFERENCES catalogo_partida(id) ON DELETE CASCADE,id TEXT NOT NULL,codigo TEXT,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,grupo TEXT NOT NULL,precio TEXT NOT NULL,PRIMARY KEY(catalogo_id,id));
        CREATE TABLE catalogo_partida_recurso(catalogo_id TEXT NOT NULL,nodo_local TEXT NOT NULL,id TEXT NOT NULL,grupo TEXT NOT NULL,insumo_id TEXT,subpartida_local TEXT,modo TEXT NOT NULL,numero_recursos TEXT NOT NULL,cantidad TEXT NOT NULL,desperdicio TEXT NOT NULL,PRIMARY KEY(catalogo_id,nodo_local,id),
            FOREIGN KEY(catalogo_id,nodo_local) REFERENCES catalogo_partida_nodo(catalogo_id,id_local) ON DELETE CASCADE,
            FOREIGN KEY(catalogo_id,insumo_id) REFERENCES catalogo_partida_insumo(catalogo_id,id) DEFERRABLE INITIALLY DEFERRED,
            FOREIGN KEY(catalogo_id,subpartida_local) REFERENCES catalogo_partida_nodo(catalogo_id,id_local) DEFERRABLE INITIALLY DEFERRED);
        CREATE INDEX ix_partida_padre ON partida_presupuesto(presupuesto_id,padre_id);
        CREATE INDEX ix_catalogo_partida_descripcion ON catalogo_partida(descripcion);
        CREATE INDEX ix_catalogo_insumo_descripcion ON catalogo_insumo(descripcion);
        """;
}
