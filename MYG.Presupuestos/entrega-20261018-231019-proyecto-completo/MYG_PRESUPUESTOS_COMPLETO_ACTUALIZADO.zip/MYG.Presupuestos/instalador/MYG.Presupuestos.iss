; Compilar con Inno Setup 7 (o 6.3 o posterior).
; Primero genere dist con scripts\Publicar.ps1.
#ifndef MyAppVersion
  #define MyAppVersion "1.0.0"
#endif
#define MyAppName "MYG Presupuestos"
#define MyAppExe "MYG.Presupuestos.exe"

[Setup]
AppId=MYG.Presupuestos.Desktop
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=MYG
DefaultDirName={localappdata}\Programs\MYG Presupuestos
DefaultGroupName=MYG Presupuestos
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible and not arm64
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
SourceDir=..
OutputDir=dist\Instalador
OutputBaseFilename=MYG_Presupuestos_Setup_{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExe}
CloseApplications=no
RestartApplications=no

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"
Name: "conectorrevit"; Description: "Instalar el conector para Revit 2027"; GroupDescription: "Conexión con Revit:"

[Files]
Source: "dist\MYG\*"; DestDir: "{app}"; Excludes: "*.pdb,*.myg.json,*.biblioteca.json,*.sqlite,*.db,sesion_automatica.dat"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "licencias\*"; DestDir: "{app}\licencias"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "instalador\USO_MYG_Presupuestos.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\Conector\*"; DestDir: "{userappdata}\Autodesk\Revit\Addins\2027\MYG_Externo"; Excludes: "RevitAPI.dll,RevitAPIUI.dll,*.pdb"; Tasks: conectorrevit; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "instalador\MYG_Conector_Externo.addin"; DestDir: "{userappdata}\Autodesk\Revit\Addins\2027"; Tasks: conectorrevit; Flags: ignoreversion; AfterInstall: ConfigurarManifest

[Icons]
Name: "{autoprograms}\MYG Presupuestos"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"
Name: "{autodesktop}\MYG Presupuestos"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Abrir MYG Presupuestos"; Flags: nowait postinstall skipifsilent runasoriginaluser

[Code]
function EscapeXml(Value: String): String;
begin
  StringChangeEx(Value, '&', '&amp;', True);
  StringChangeEx(Value, '<', '&lt;', True);
  StringChangeEx(Value, '>', '&gt;', True);
  StringChangeEx(Value, '"', '&quot;', True);
  StringChangeEx(Value, '''', '&apos;', True);
  Result := Value;
end;

procedure ConfigurarManifest;
var
  Filename, AssemblyPath: String;
  Lines: TArrayOfString;
  I, Replacements: Integer;
begin
  Filename := ExpandConstant('{userappdata}\Autodesk\Revit\Addins\2027\MYG_Conector_Externo.addin');
  AssemblyPath := ExpandConstant('{userappdata}\Autodesk\Revit\Addins\2027\MYG_Externo\MYG.Revit2027.dll');
  if not FileExists(AssemblyPath) then
    RaiseException('No se encontró el archivo del conector de Revit 2027.');
  if not LoadStringsFromFile(Filename, Lines) then
    RaiseException('No se pudo leer el registro del conector de Revit.');
  Replacements := 0;
  for I := 0 to GetArrayLength(Lines) - 1 do
    Replacements := Replacements + StringChangeEx(Lines[I], '@MYG_ASSEMBLY@', EscapeXml(AssemblyPath), True);
  if Replacements <> 1 then
    RaiseException('El registro del conector de Revit no tiene el formato esperado.');
  if not SaveStringsToUTF8FileWithoutBOM(Filename, Lines, False) then
    RaiseException('No se pudo guardar el registro del conector de Revit.');
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Script, Params: String;
  ResultCode: Integer;
begin
  Result := '';
  Script := 'if (Get-Process -Name ''MYG.Presupuestos'' -ErrorAction SilentlyContinue) { exit 12 }; ';
  if WizardIsTaskSelected('conectorrevit') then
    Script := Script + 'if (Get-Process -Name ''Revit'' -ErrorAction SilentlyContinue) { exit 11 }; ';
  Script := Script + 'exit 0';
  Params := '-NoProfile -NonInteractive -Command "' + Script + '"';
  if not Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
    Params, '', SW_HIDE, ewWaitUntilTerminated, ResultCode) then
  begin
    Result := 'No se pudo comprobar si los programas están cerrados. Vuelva a ejecutar el instalador.';
    Exit;
  end;
  if ResultCode = 12 then
    Result := 'Cierre MYG Presupuestos y vuelva a intentar la instalación.'
  else if ResultCode = 11 then
    Result := 'Cierre todas las sesiones de Revit antes de instalar o actualizar su conector.'
  else if ResultCode <> 0 then
    Result := 'No se pudo comprobar si los programas están cerrados. Vuelva a ejecutar el instalador.';
end;
