# Actualización del editor Metrado Xls

Base: bimchimbote-droid/MYG.Presupuestos, rama remota main, commit 0845f78825ab633e6e0729144817297c25af9130.

## Implementación

El detalle de la partida incorpora cabecera «Metrado», acceso XLSX, cinta con Archivo, Inicio, Celdas, Diseño de Página, Fórmulas, Insertar, Datos, Revisar y Vista, barra de fórmulas y pestaña inferior de hoja.
Usa la misma cinta y paleta que especificaciones técnicas. Cada partida conserva su propia hoja y origen de metrado.

Se pueden editar y pegar datos, copiar/cortar/rellenar, combinar celdas sin perder contenido, aplicar fuente, formato numérico, colores, bordes y alineación, insertar/eliminar filas y columnas ajustando referencias, ordenar un rango, buscar/reemplazar, validar valores, filtrar y ocultar filas.
Los estilos, combinaciones, dimensiones, filas ocultas, zoom, inmovilización y configuración de impresión se guardan en MYG y se exportan a XLSX. El filtro de texto es local y se limpia al cambiar de partida.
«Usar total Excel» selecciona explícitamente la celda total y el origen Excel para calcular la cantidad. Editar la hoja por sí solo conserva el origen anterior (cantidad directa, manual o BIM). Deshacer y rehacer usan el historial del proyecto.

No hace falta instalar Excel para estos comandos. El motor admite aritmética, referencias, SUM/SUMA, PRODUCT/PRODUCTO, COUNT/CONTAR, MIN, MAX, AVERAGE/PROMEDIO, IF/SI, ABS y ROUND/REDONDEAR.
Las fórmulas no compatibles se conservan y muestran #ERROR; no se sustituyen por resultados antiguos guardados por Excel.

## Instalación manual

1. Cerrar MYG; guardar o confirmar los cambios locales.
2. Respaldar el código y usar copias de las bases para la comprobación manual.
3. Extraer el ZIP y copiar el contenido en la raíz de D:\ADDIN\repos\MYG.Presupuestos_GITHUB, conservando las rutas.
4. Reemplazar los archivos existentes entregados completos y crear los nuevos. No hay archivos que eliminar ni parches.
5. Abrir la solución en Visual Studio 2026. Los proyectos SDK incluyen automáticamente los archivos C# nuevos; no hay que editar .csproj.
6. Restaurar, compilar y validar con los comandos siguientes.

Los archivos completos corresponden al commit base indicado. Si tienes modificaciones locales o posteriores, combinar los cambios con una herramienta de diferencias antes de reemplazarlos.

## Dependencias, compilación y comprobaciones

SDK validado: .NET 10.0.100. No se agregan paquetes ni cambian versiones, proyectos o lockfiles. Se mantiene SQLite y la persistencia existente, sin migración manual de bases.
Los documentos anteriores conservan sus datos; los atributos nuevos usan valores predeterminados.

Desde la raíz del repositorio:

    dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
    dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
    dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore

UseRevitReferencePackages permite compilar el conector con referencias de NuGet. Con Revit 2027 instalado puede utilizarse el flujo habitual y sus DLL.

En Windows, ejecutar las pruebas de interfaz y abrir la aplicación:

    dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
    dotnet run --project MYG.Desktop/MYG.Desktop.csproj -c Release

## Resultados

La solución completa se compiló en Linux con .NET 10.0.100: cero errores y advertencias. Se ejecutaron 211 comprobaciones, incluidos los nuevos grupos sobre persistencia, referencias/operaciones estructurales, ordenación/combinación, validación y formato/configuración XLSX.
Named Pipes se omite explícitamente en Linux. Las pruebas UI se compilaron pero no se ejecutaron: requieren Windows. No se validó una sesión real de Revit, el servicio de licencias, una impresora real ni el instalador.
La nueva prueba UI comprueba las nueve pestañas, disposición, selección de rangos, edición/cálculo, fórmulas, formato, historial, cambio de partida, filtro, zoom y tema.

## Límites y revisión manual

La presentación sigue las imágenes y el editor de especificaciones. No se ha verificado una reproducción píxel por píxel en Windows. Revisar el aspecto a 100%, 125% y 150% de escala, las cintas en un panel estrecho y los temas claro y oscuro.
Gráficos, imágenes flotantes, tablas dinámicas, formato condicional, cifrado/protección, nombres definidos y comentarios están visibles y deshabilitados con explicación. Las funciones financieras, fecha/texto, búsqueda y trigonometría no están implementadas en el motor.
La hoja integrada no ofrece toda la compatibilidad de Excel. La importación rechaza validaciones XLSX que no puede conservar; no garantiza conservar macros, gráficos ni imágenes. Exportar a un archivo nuevo y conservar el original.
Comprobar guardar/reabrir una copia de proyecto, intercambiar XLSX con Excel, deshacer/rehacer, escoger el total y revisar la cantidad de presupuesto, además de vista previa e impresión.

## Publicación del código

No se hizo commit ni push al repositorio de código. En Visual Studio, abrir Cambios de Git, revisar, confirmar y publicar manualmente en la rama elegida; verificar luego los cambios en GitHub.
La publicación del ZIP en DESCARGAS no aplica estos cambios a la carpeta local del usuario.
