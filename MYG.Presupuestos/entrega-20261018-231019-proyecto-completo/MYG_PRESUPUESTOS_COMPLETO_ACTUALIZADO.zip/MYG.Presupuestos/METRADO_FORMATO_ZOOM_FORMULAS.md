# Metrado: datos centrados, zoom con rueda y referencias de fórmulas

Aplicar sobre la corrección anterior de Metrado Xls (entrega DESCARGAS 3a071ab26063866dbd29e4f117c1e9f842c57245). Base del código: main, 0845f78825ab633e6e0729144817297c25af9130.

## Correcciones

- Arial Narrow continúa como fuente de los datos. Los números de filas y letras de columnas usan nuevamente Segoe UI de 9 puntos, sin cambiar de tamaño con el zoom.
- Los datos se centran por defecto salvo la columna A (Descripción), que queda a la izquierda. Las hojas anteriores con alineación predeterminada izquierda reciben esta presentación. Las alineaciones nuevas elegidas desde la cinta y las alineaciones explícitas de XLSX se conservan; los informes de presupuesto mantienen su diseño anterior.
- Ctrl + rueda del mouse acerca y aleja la hoja en pasos de 10 puntos, entre 25% y 300%, incluso durante la edición de una celda o de la barra de fórmulas. Sin Ctrl se mantiene el desplazamiento normal. La selección, posición de escritura y borrador se conservan.
- Al editar una fórmula, cada referencia recibe un color y el rango correspondiente se muestra con fondo tenue y contorno. Las referencias repetidas mantienen su color. Los colores son temporales: no cambian el documento ni el formato guardado.

## Uso

Un clic selecciona una celda. Para editar, utilizar doble clic, F2 o comenzar a escribir. En G16, editar =SUM(G3:G15) debe dibujar un contorno sobre G3:G15. Con =B3*C3 se deben distinguir B3 y C3 por color.
El resaltado se actualiza al escribir, también en la barra de fórmulas. Enter o confirmar aplica el cambio; Escape o el botón × descarta la edición y limpia los colores. Cambiar de partida o salir de la pestaña limpia el resaltado.
Se reconocen referencias locales simples, rangos y referencias absolutas como $B$3. Los textos entre comillas y referencias a otros libros/hojas no se resaltan como celdas locales. El resaltado no evalúa ni amplía las funciones admitidas por el motor.

## Instalación

1. Cerrar MYG y respaldar o confirmar los cambios locales.
2. Extraer el ZIP sobre la raíz del proyecto, conservando todas las rutas.
3. Reemplazar los archivos existentes incluidos y crear los archivos nuevos. Mantener los otros archivos de las entregas anteriores; no hay eliminaciones ni parches.
4. Si hay cambios propios en un archivo entregado completo, combinarlos antes de reemplazar.
5. Compilar y ejecutar las comprobaciones siguientes. Los proyectos SDK incluyen automáticamente los C# nuevos.

## Compilación y comprobación

.NET SDK validado 10.0.100; sin paquetes nuevos ni migraciones manuales de SQLite.

    dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
    dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
    dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore

En Windows:

    dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release

La solución completa se compiló sin errores ni advertencias. Se ejecutaron 219 comprobaciones aprobadas, incluidas alineación/compatibilidad XLSX y detección de referencias. Named Pipes se omite explícitamente en Linux.
Las pruebas UI se compilaron pero no se ejecutaron en Linux. Incluyen mensajes nativos de rueda, edición pendiente, selección, zoom, encabezados y pintura de los contornos de referencias. La validación visual requiere Windows.
Comprobar ambos temas, las escalas DPI habituales, Ctrl + rueda mientras se escribe, resaltado de varias referencias, Escape, guardar/reabrir y exportar a un XLSX nuevo conservando el original.

## GitHub

Se publica únicamente el ZIP en una carpeta nueva de DESCARGAS; no se sobrescriben entregas anteriores ni se publica el código en su repositorio.
Después de aplicar y revisar los cambios, hacer Commit y Push manualmente desde Cambios de Git en Visual Studio y verificar la rama de trabajo.
