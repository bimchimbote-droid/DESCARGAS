# Generar el instalador de MYG Presupuestos

## El ejecutable actual y sus dependencias

El ejecutable generado en `MYG.Desktop\bin\Release\net10.0-windows` necesita las DLL y archivos de configuración de esa carpeta. La compilación normal también necesita .NET Desktop Runtime 10 x64 instalado en la PC que ejecuta el programa.

Una publicación con `SelfContained=true` incluye .NET dentro de la distribución. Sigue siendo una carpeta de archivos. Un instalador empaqueta esa carpeta en un único archivo de descarga y copia los componentes al equipo del usuario.

La configuración de esta entrega utiliza ese método y añade el conector opcional para Revit 2027. El usuario recibe el instalador; después abre MYG desde su acceso directo.

## Archivos incluidos

| Archivo | Función |
| --- | --- |
| `instalador\MYG.Presupuestos.iss` | Configuración de Inno Setup. |
| `instalador\MYG_Conector_Externo.addin` | Plantilla de registro del conector; la ruta se completa durante la instalación. |
| `instalador\USO_MYG_Presupuestos.txt` | Instrucciones para el usuario del programa. |
| `scripts\Generar-Instalador.ps1` | Publica la aplicación y el conector, y compila el instalador. |

El archivo `.iss` contiene el código del instalador. El archivo `Setup.exe` se genera después de compilarlo en Windows; no está incluido como binario en esta entrega.

## 1. Incorporar la configuración a su proyecto actual

Si ya está trabajando en `D:\ADDIN\repos\MYG.Presupuestos`, descargue `MYG_Presupuestos_Archivos_Instalador.zip`.

Extraiga su contenido directamente en esa carpeta. Este ZIP contiene `instalador`, el script nuevo dentro de `scripts` y esta guía. Los archivos C# que está editando permanecen en su proyecto actual.

Compruebe que existen:

```text
D:\ADDIN\repos\MYG.Presupuestos\scripts\Generar-Instalador.ps1
D:\ADDIN\repos\MYG.Presupuestos\instalador\MYG.Presupuestos.iss
```

El paquete completo de código `MYG_Presupuestos_Codigo_2027.zip` también incluye esta configuración si necesita comenzar con una copia completa.

## 2. Instalar la herramienta que compila el instalador

Instale Inno Setup en su PC de desarrollo desde su página oficial:

https://jrsoftware.org/isdl.php

Utilice Inno Setup 7. La configuración también utiliza funciones disponibles desde Inno Setup 6.3. El script busca el compilador ISCC.exe en las ubicaciones habituales; si lo instaló en otra carpeta, podrá indicarla como parámetro.

También necesita el SDK .NET 10 y su instalación de Revit 2027. Sus usuarios necesitan Windows x64 y una licencia MYG válida; requieren Revit 2027 únicamente para las operaciones dentro del modelo. Los usuarios no necesitan Visual Studio ni Inno Setup.

## 3. Generar el instalador

1. Guarde todos sus cambios en Visual Studio.
2. Cierre MYG Presupuestos y Revit para evitar bloqueos de archivos de una ejecución anterior.
3. Abra el Explorador de archivos en `D:\ADDIN\repos\MYG.Presupuestos`.
4. En la barra de dirección, escriba `powershell` y presione Enter.
5. Pegue el comando y presione Enter:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1
```

El script ejecuta `Publicar.ps1`. Se publican el escritorio en `dist\MYG` con .NET incluido y el conector en `dist\Conector`. Después Inno Setup empaqueta los archivos.

Espere hasta que aparezca `Instalador generado:` con la ruta del resultado. Si hay un error de publicación o compilación, el script se detiene y muestra ese error.

El archivo generado será:

```text
D:\ADDIN\repos\MYG.Presupuestos\dist\Instalador\MYG_Presupuestos_Setup_1.0.0.exe
```

La compilación normal en Visual Studio genera el programa. Este comando genera la distribución y su instalador.

## 4. Ubicaciones personalizadas

Si Revit está instalado en otra carpeta:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1 -RevitInstallDir 'D:\Autodesk\Revit 2027'
```

Si Inno Setup está instalado en otra carpeta:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1 -IsccPath 'C:\SuCarpeta\Inno Setup 7\ISCC.exe'
```

Puede combinar ambos parámetros. Las rutas entre comillas deben corresponder a su instalación real.

Si ya generó `dist` con el script `Publicar.ps1` y desea solamente empaquetarlo:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1 -OmitirPublicacion
```

Esta opción comprueba que la publicación contiene el runtime .NET antes de generar el instalador.

## 5. Compilar desde la ventana de Inno Setup

Después de publicar `dist`, también puede abrir Inno Setup Compiler, usar **File → Open** y elegir `instalador\MYG.Presupuestos.iss`. Use **Build → Compile** para generar el instalador con la versión predeterminada 1.0.0. El resultado se guarda en `dist\Instalador`.

## 6. Qué hace el instalador para el usuario

1. El usuario recibe `MYG_Presupuestos_Setup_1.0.0.exe` y lo abre con su cuenta habitual de Windows.
2. El instalador permite crear el acceso directo e instalar el conector de Revit 2027. Ambas opciones se ofrecen en la selección de tareas.
3. Comprueba que MYG esté cerrado; si se seleccionó el conector, comprueba también que Revit esté cerrado. Solicita cerrar las aplicaciones cuando corresponde.
4. Copia MYG Presupuestos y sus dependencias a:

```text
%LOCALAPPDATA%\Programs\MYG Presupuestos
```

5. Si se seleccionó el conector, copia sus archivos a:

```text
%APPDATA%\Autodesk\Revit\Addins\2027\MYG_Externo
```

6. Registra `MYG_Conector_Externo.addin` con la ruta real del usuario.
7. Crea el acceso del menú Inicio y, si se seleccionó, el acceso del escritorio. Incluye el desinstalador.
8. El usuario abre MYG e ingresa con su licencia. Para trabajar en Revit, abre un modelo, crea o abre un proyecto MYG y pulsa **Buscar Revit**.

La instalación se realiza para el usuario actual y no solicita elevar permisos. Revit y MYG deben ejecutarse con el mismo usuario y nivel de permisos. La instalación opcional del conector prepara sus archivos; Revit 2027 debe estar instalado para poder cargarlo.

Los presupuestos, biblioteca y credenciales se crean durante el uso del programa y se guardan en sus ubicaciones correspondientes. El instalador no incluye datos ni credenciales de su PC de desarrollo.

## 7. Compartir y actualizar

Después de comprobar la instalación en Windows, comparta el archivo `MYG_Presupuestos_Setup_1.0.0.exe`. Sus usuarios no necesitan recibir la solución ni los archivos C#.

Para generar una actualización con otro número de versión:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1 -Version 1.0.1
```

El identificador del programa permanece estable para que el instalador actualice la misma instalación. En esta configuración las actualizaciones se distribuyen como un nuevo instalador; la descarga e instalación automática no está implementada.

## Estado de validación

Se revisaron las rutas de publicación, el registro XML del conector, los filtros de archivos y las funciones empleadas contra la documentación oficial. Los archivos C# de la aplicación no se modificaron en esta actualización.

La compilación de Inno Setup y las pruebas de instalación, actualización y desinstalación deben ejecutarse en Windows. No se ha generado ni probado aquí un archivo `Setup.exe`. Compruebe también el acceso con una licencia MYG real y la conexión con Revit en un equipo de prueba antes de repartirlo.

Fuentes: [Publicación .NET](https://learn.microsoft.com/dotnet/core/deploying/), [Inno Setup](https://jrsoftware.org/ishelp/), [Archivos del instalador](https://jrsoftware.org/ishelp/topic_filessection.htm).
