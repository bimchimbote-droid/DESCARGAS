using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security;
using System.Text.Json;
using System.Windows.Forms;

namespace MYG_2027;

// La presentación puede continuar con valores de fábrica si la preferencia
// local no se puede leer. El diálogo lee directamente el archivo e informa el
// error antes de permitir reemplazar una configuración dañada.
internal static class MYGParametrosAplicacionUI
{
    private static MYGParametrosPredeterminados actual;
    private static bool coloresGuardados;
    internal static event EventHandler Cambio;
    internal static string ErrorLectura { get; private set; }

    internal static MYGParametrosPredeterminados Actual
    {
        get { if (actual == null) Leer(); return actual; }
    }

    private static void Leer()
    {
        ErrorLectura = null;
        try
        {
            coloresGuardados = File.Exists(MYGParametrosUsuario.RutaPredeterminada);
            actual = MYGParametrosUsuario.Leer();
        }
        catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or SecurityException
            or JsonException or ArgumentException or FormatException)
        {
            coloresGuardados = false;
            actual = new MYGParametrosPredeterminados();
            ErrorLectura = ex.Message;
        }
    }

    internal static void Actualizar()
    {
        Leer();
        MYG2027_TemaComercial.ActualizarColoresParametros();
        Cambio?.Invoke(null, EventArgs.Empty);
    }

    internal static bool TryColorNivel(int nivel, out Color color)
    {
        var parametros = Actual;
        color = Color.Empty;
        if (!coloresGuardados || nivel < 0 || nivel >= parametros.ColoresNiveles.Count
            || !int.TryParse(parametros.ColoresNiveles[nivel].TrimStart('#'), NumberStyles.HexNumber,
                CultureInfo.InvariantCulture, out int rgb) || rgb < 0 || rgb > 0xFFFFFF) return false;
        color = Color.FromArgb(255, (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255);
        return true;
    }

    internal static string NombreDivision(MYGCatalogoProyecto tipo, bool abreviado = false)
    {
        int indice = tipo switch
        {
            MYGCatalogoProyecto.Departamentos => 0, MYGCatalogoProyecto.Provincias => 1,
            MYGCatalogoProyecto.Distritos => 2, MYGCatalogoProyecto.Localidades => 3, _ => -1
        };
        if (indice < 0) throw new ArgumentOutOfRangeException(nameof(tipo));
        var nivel = Actual.DivisionPolitica[indice];
        return abreviado ? nivel.Nombre + " (" + nivel.Abreviatura + ")" : nivel.Nombre;
    }

    // Inicio aloja este control en su cabecera. Sus imágenes son copias locales
    // y se liberan al actualizar el logotipo o al cerrar la ventana.
    internal static Control CrearIdentidadEmpresa()
    {
        var panel = new Panel
        {
            Name = "identidadEmpresaInicio", Dock = DockStyle.Top, Height = 52,
            Padding = new(22, 4, 22, 4), AccessibleName = "Empresa actual"
        };
        var logo = new PictureBox
        {
            Name = "logoEmpresaInicio", Dock = DockStyle.Left, Width = 76,
            SizeMode = PictureBoxSizeMode.Zoom, TabStop = false,
            AccessibleName = "Logo de la empresa"
        };
        var nombre = new Label
        {
            Name = "nombreEmpresaInicio", Dock = DockStyle.Fill, AutoEllipsis = true,
            TextAlign = ContentAlignment.MiddleLeft, Padding = new(10, 0, 0, 0)
        };
        panel.Controls.Add(nombre); panel.Controls.Add(logo);
        void ActualizarEmpresa(object sender, EventArgs args)
        {
            var parametros = Actual;
            var anterior = logo.Image;
            logo.Image = null;
            anterior?.Dispose();
            nombre.Text = parametros.NombreComercial ?? "";
            if (!string.IsNullOrWhiteSpace(parametros.LogoBase64))
            {
                try
                {
                    using var flujo = new MemoryStream(Convert.FromBase64String(parametros.LogoBase64));
                    using var imagen = Image.FromStream(flujo, true, true);
                    if (imagen.Width <= 8192 && imagen.Height <= 8192
                        && (long)imagen.Width * imagen.Height <= 16000000) logo.Image = new Bitmap(imagen);
                }
                catch (Exception ex) when (ex is ArgumentException or FormatException or ExternalException
                    or OutOfMemoryException) { }
            }
            logo.Visible = logo.Image != null;
            panel.Visible = nombre.Text.Length > 0 || logo.Visible;
        }
        Cambio += ActualizarEmpresa;
        panel.Disposed += (_, _) =>
        {
            Cambio -= ActualizarEmpresa;
            logo.Image?.Dispose(); logo.Image = null;
        };
        ActualizarEmpresa(null, EventArgs.Empty);
        return panel;
    }
}
