using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGGraficoIncidencia
{
    private readonly List<(string Nombre, ToolStripItem[] Elementos)> gruposBarrasGrafico = new();
    private string firmaBarrasGrafico;

    private void ActualizarBarrasPersonalizadas()
    {
        if (barraGrafico == null || botonMasGrafico == null) return;
        string firma = JsonSerializer.Serialize(configuracion.BarrasPersonalizadas.Select(b => new { b.Nombre, b.Comandos }));
        if (firma != firmaBarrasGrafico)
        {
            foreach (var grupo in gruposBarrasGrafico)
                foreach (var item in grupo.Elementos)
                {
                    barraGrafico.Items.Remove(item);
                    item.Dispose();
                }
            gruposBarrasGrafico.Clear();
            foreach (var barra in configuracion.BarrasPersonalizadas)
            {
                var elementos = new List<ToolStripItem>
                {
                    new ToolStripSeparator { Overflow = ToolStripItemOverflow.AsNeeded },
                    new ToolStripLabel(barra.Nombre.Length > 12 ? barra.Nombre[..11] + "…" : barra.Nombre)
                    {
                        AccessibleName = "Barra " + barra.Nombre, ToolTipText = barra.Nombre,
                        AutoSize = false, AutoToolTip = false,
                        Size = new Size(MedidaHerramienta(95), MedidaHerramienta(24)),
                        TextAlign = ContentAlignment.MiddleLeft, DisplayStyle = ToolStripItemDisplayStyle.Text,
                        Overflow = ToolStripItemOverflow.AsNeeded
                    }
                };
                foreach (string id in barra.Comandos)
                {
                    var comando = comandosGrafico.FirstOrDefault(c => c.Id == id);
                    if (comando == null) continue;
                    elementos.Add(new ToolStripButton(comando.Texto, IconoHerramienta(comando.Icono),
                        (_, _) => EjecutarComandoGrafico(comando.Id, comando.Ejecutar))
                    {
                        Name = "personalizado-" + gruposBarrasGrafico.Count + "-" + id,
                        AccessibleName = comando.Texto, Tag = comando,
                        AutoToolTip = false, ImageScaling = ToolStripItemImageScaling.SizeToFit,
                        Overflow = ToolStripItemOverflow.AsNeeded
                    });
                }
                int posicion = barraGrafico.Items.IndexOf(botonMasGrafico);
                foreach (var item in elementos) barraGrafico.Items.Insert(posicion++, item);
                gruposBarrasGrafico.Add((barra.Nombre, elementos.ToArray()));
            }
            firmaBarrasGrafico = firma;
        }
        foreach (var grupo in gruposBarrasGrafico)
        {
            bool visible = configuracion.BarrasPersonalizadas.Any(b => b.Nombre == grupo.Nombre && b.Visible);
            foreach (var item in grupo.Elementos)
            {
                item.Available = visible;
                if (item is ToolStripLabel) item.Size = new Size(MedidaHerramienta(95), MedidaHerramienta(24));
                if (item.Tag is not ComandoGrafico comando) continue;
                item.DisplayStyle = configuracion.MostrarTextos ? ToolStripItemDisplayStyle.ImageAndText : ToolStripItemDisplayStyle.Image;
                item.TextImageRelation = TextImageRelation.ImageBeforeText;
                string atajo = AtajoGrafico(comando.Id);
                item.ToolTipText = comando.Texto + (configuracion.MostrarAtajos && atajo.Length > 0 ? " (" + atajo + ")" : "") + "\n" + comando.Descripcion;
            }
        }
        foreach (var par in botonesGrafico)
            par.Value.Available = configuracion.BarraVisible && !configuracion.BotonesOcultos.Contains(par.Key);
        barraGrafico.Visible = configuracion.BarraVisible || configuracion.BarrasPersonalizadas.Any(b => b.Visible);
    }

    /// <summary>La acción devuelta sincroniza los controles después de cambiar opciones en otra pestaña.</summary>
    private Action PrepararPanelBarras(TabPage pagina)
    {
        var distribucion = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, Padding = new Padding(12), ColumnCount = 2, RowCount = 4,
            ColumnStyles = { new ColumnStyle(SizeType.Percent, 100), new ColumnStyle(SizeType.Absolute, 146) },
            RowStyles = { new RowStyle(SizeType.Absolute, 24), new RowStyle(SizeType.Absolute, 146), new RowStyle(SizeType.Absolute, 28), new RowStyle(SizeType.Percent, 100) }
        };
        var listaBarras = new CheckedListBox
        {
            Dock = DockStyle.Fill, CheckOnClick = true, IntegralHeight = false,
            AccessibleName = "Barras de herramientas", HorizontalScrollbar = true
        };
        var acciones = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(5, 0, 0, 0) };
        var nuevo = new Button { Text = "Nuevo", Size = new Size(128, 28) };
        var renombrar = new Button { Text = "Renombrar", Size = new Size(128, 28) };
        var eliminar = new Button { Text = "Eliminar", Size = new Size(128, 28) };
        var restablecer = new Button { Text = "Restablecer", Size = new Size(128, 28) };
        acciones.Controls.AddRange(new Control[] { nuevo, renombrar, eliminar, restablecer });
        var etiquetaBotones = new Label { Text = "Botones de Tipo de gráfico:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        var listaBotones = new CheckedListBox
        {
            Dock = DockStyle.Fill, CheckOnClick = true, IntegralHeight = false,
            AccessibleName = "Comandos de la barra seleccionada", HorizontalScrollbar = true
        };
        distribucion.Controls.Add(new Label { Text = "Barras:", Dock = DockStyle.Fill }, 0, 0);
        distribucion.Controls.Add(listaBarras, 0, 1);
        distribucion.Controls.Add(acciones, 1, 1);
        distribucion.Controls.Add(etiquetaBotones, 0, 2); distribucion.SetColumnSpan(etiquetaBotones, 2);
        distribucion.Controls.Add(listaBotones, 0, 3); distribucion.SetColumnSpan(listaBotones, 2);
        pagina.Controls.Add(distribucion);
        bool sincronizando = false;
        var comandosEnLista = new List<(string Id, string Texto)>();

        string NombreSeleccionado() => listaBarras.SelectedItem as string ?? "Tipo de gráfico";
        MYGBarraGraficoIncidencia BarraSeleccionada() => listaBarras.SelectedIndex <= 0 ? null :
            configuracion.BarrasPersonalizadas.FirstOrDefault(b => b.Nombre == NombreSeleccionado());

        void RefrescarComandos()
        {
            bool anterior = sincronizando; sincronizando = true;
            try
            {
                var barra = BarraSeleccionada();
                bool baseSeleccionada = listaBarras.SelectedIndex == 0;
                string idSeleccionado = listaBotones.SelectedIndex >= 0 && listaBotones.SelectedIndex < comandosEnLista.Count ? comandosEnLista[listaBotones.SelectedIndex].Id : null;
                etiquetaBotones.Text = "Botones de " + NombreSeleccionado() + ":";
                renombrar.Enabled = eliminar.Enabled = barra != null;
                restablecer.Enabled = baseSeleccionada || barra != null;
                nuevo.Enabled = configuracion.BarrasPersonalizadas.Count < 8;
                listaBotones.BeginUpdate(); listaBotones.Items.Clear(); comandosEnLista.Clear();
                foreach (var comando in comandosGrafico.Where(c => !baseSeleccionada || botonesGrafico.ContainsKey(c.Id)))
                    comandosEnLista.Add((comando.Id, comando.Texto));
                if (barra != null)
                    foreach (string id in barra.Comandos.Where(id => !comandosEnLista.Any(c => c.Id == id)).Distinct())
                        comandosEnLista.Add((id, "Comando no disponible: " + id));
                foreach (var comando in comandosEnLista)
                    listaBotones.Items.Add(comando.Texto, baseSeleccionada ? !configuracion.BotonesOcultos.Contains(comando.Id) : barra?.Comandos.Contains(comando.Id) == true);
                int seleccion = comandosEnLista.FindIndex(c => c.Id == idSeleccionado);
                if (seleccion >= 0) listaBotones.SelectedIndex = seleccion;
                listaBotones.Enabled = baseSeleccionada || barra != null;
                listaBotones.EndUpdate();
            }
            finally { sincronizando = anterior; }
        }

        void Sincronizar(string nombrePreferido = null)
        {
            bool anterior = sincronizando; sincronizando = true;
            try
            {
                string nombre = nombrePreferido ?? NombreSeleccionado();
                listaBarras.BeginUpdate(); listaBarras.Items.Clear();
                listaBarras.Items.Add("Tipo de gráfico", configuracion.BarraVisible);
                foreach (var barra in configuracion.BarrasPersonalizadas) listaBarras.Items.Add(barra.Nombre, barra.Visible);
                int indice = listaBarras.Items.IndexOf(nombre);
                listaBarras.SelectedIndex = indice >= 0 ? indice : 0;
                listaBarras.EndUpdate();
                RefrescarComandos();
            }
            finally { sincronizando = anterior; }
        }

        listaBarras.SelectedIndexChanged += (_, _) => { if (!sincronizando) RefrescarComandos(); };
        listaBarras.ItemCheck += (_, e) =>
        {
            if (sincronizando) return;
            string nombre = listaBarras.Items[e.Index] as string;
            EjecutarHerramienta(() => CambiarGrafico(c =>
            {
                if (e.Index == 0) c.BarraVisible = e.NewValue == CheckState.Checked;
                else c.BarrasPersonalizadas.First(b => b.Nombre == nombre).Visible = e.NewValue == CheckState.Checked;
            }));
        };
        listaBotones.ItemCheck += (_, e) =>
        {
            if (sincronizando || e.Index < 0 || e.Index >= comandosEnLista.Count) return;
            string id = comandosEnLista[e.Index].Id;
            if (listaBarras.SelectedIndex == 0)
            {
                EjecutarHerramienta(() => CambiarGrafico(c => c.BotonesOcultos = e.NewValue == CheckState.Checked
                    ? c.BotonesOcultos.Where(x => x != id).ToArray() : c.BotonesOcultos.Append(id).Distinct().ToArray()));
                return;
            }
            var barra = BarraSeleccionada();
            if (barra == null) { e.NewValue = e.CurrentValue; return; }
            if ((e.NewValue == CheckState.Unchecked && barra.Comandos.Length == 1) ||
                (e.NewValue == CheckState.Checked && barra.Comandos.Length >= 40 && !barra.Comandos.Contains(id)))
            {
                e.NewValue = e.CurrentValue;
                MessageBox.Show(pagina.FindForm(), "Una barra debe contener entre 1 y 40 comandos.", "Barras de herramientas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string nombre = barra.Nombre;
            EjecutarHerramienta(() => CambiarGrafico(c =>
            {
                var seleccionada = c.BarrasPersonalizadas.First(b => b.Nombre == nombre);
                seleccionada.Comandos = e.NewValue == CheckState.Checked ? seleccionada.Comandos.Append(id).Distinct().ToArray() : seleccionada.Comandos.Where(x => x != id).ToArray();
            }));
        };
        nuevo.Click += (_, _) => EjecutarHerramienta(() =>
        {
            if (configuracion.BarrasPersonalizadas.Count >= 8) return;
            var barra = CrearBarraPersonalizadaGrafico(pagina.FindForm());
            if (barra == null) return;
            CambiarGrafico(c => c.BarrasPersonalizadas.Add(barra));
            Sincronizar(barra.Nombre);
        });
        renombrar.Click += (_, _) => EjecutarHerramienta(() =>
        {
            var barra = BarraSeleccionada(); if (barra == null) return;
            string anterior = barra.Nombre;
            string nombre = PedirNombreBarraGrafico(pagina.FindForm(), anterior);
            if (nombre == null) return;
            CambiarGrafico(c => c.BarrasPersonalizadas.First(b => b.Nombre == anterior).Nombre = nombre);
            Sincronizar(nombre);
        });
        eliminar.Click += (_, _) => EjecutarHerramienta(() =>
        {
            var barra = BarraSeleccionada(); if (barra == null) return;
            string nombre = barra.Nombre;
            CambiarGrafico(c => c.BarrasPersonalizadas.RemoveAll(b => b.Nombre == nombre));
            Sincronizar();
        });
        restablecer.Click += (_, _) => EjecutarHerramienta(() =>
        {
            var barra = BarraSeleccionada();
            if (listaBarras.SelectedIndex == 0) RestablecerBarraGrafico();
            else if (barra != null)
            {
                string nombre = barra.Nombre;
                string[] predeterminados = comandosGrafico.Where(c => botonesGrafico.ContainsKey(c.Id)).Select(c => c.Id).ToArray();
                CambiarGrafico(c =>
                {
                    var seleccionada = c.BarrasPersonalizadas.First(b => b.Nombre == nombre);
                    seleccionada.Comandos = predeterminados; seleccionada.Visible = true;
                });
            }
            Sincronizar();
        });
        Sincronizar();
        return () => Sincronizar();
    }

    private MYGBarraGraficoIncidencia CrearBarraPersonalizadaGrafico(IWin32Window propietario)
    {
        using var dialogo = DialogoGrafico("Nueva barra de herramientas", 480, 465);
        var distribucion = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, Padding = new Padding(12), ColumnCount = 1, RowCount = 5,
            RowStyles = { new RowStyle(SizeType.Absolute, 24), new RowStyle(SizeType.Absolute, 32), new RowStyle(SizeType.Absolute, 28), new RowStyle(SizeType.Percent, 100), new RowStyle(SizeType.Absolute, 42) }
        };
        var nombre = new TextBox { Dock = DockStyle.Fill, MaxLength = 80, AccessibleName = "Nombre de la barra" };
        var comandos = new CheckedListBox { Dock = DockStyle.Fill, CheckOnClick = true, IntegralHeight = false, HorizontalScrollbar = true, AccessibleName = "Comandos de la nueva barra" };
        var disponibles = comandosGrafico.ToArray();
        foreach (var comando in disponibles) comandos.Items.Add(comando.Texto, botonesGrafico.ContainsKey(comando.Id));
        var acciones = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(0, 5, 0, 0) };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, AutoSize = true };
        var aceptar = new Button { Text = "Crear", AutoSize = true };
        acciones.Controls.AddRange(new Control[] { cancelar, aceptar });
        distribucion.Controls.Add(new Label { Text = "Nombre:", Dock = DockStyle.Fill }, 0, 0);
        distribucion.Controls.Add(nombre, 0, 1);
        distribucion.Controls.Add(new Label { Text = "Seleccione los comandos de la barra (1 a 40):", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 2);
        distribucion.Controls.Add(comandos, 0, 3); distribucion.Controls.Add(acciones, 0, 4);
        dialogo.Controls.Add(distribucion); dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
        MYGBarraGraficoIncidencia resultado = null;
        aceptar.Click += (_, _) =>
        {
            string texto = nombre.Text.Trim();
            if (!NombreBarraGraficoValido(texto, null, out string error))
            {
                MessageBox.Show(dialogo, error, dialogo.Text, MessageBoxButtons.OK, MessageBoxIcon.Information); nombre.Focus(); return;
            }
            if (comandos.CheckedIndices.Count is < 1 or > 40)
            {
                MessageBox.Show(dialogo, "Seleccione entre 1 y 40 comandos.", dialogo.Text, MessageBoxButtons.OK, MessageBoxIcon.Information); comandos.Focus(); return;
            }
            resultado = new MYGBarraGraficoIncidencia { Nombre = texto, Comandos = comandos.CheckedIndices.Cast<int>().Select(i => disponibles[i].Id).ToArray() };
            dialogo.DialogResult = DialogResult.OK;
        };
        dialogo.Shown += (_, _) => nombre.Focus();
        return dialogo.ShowDialog(propietario) == DialogResult.OK ? resultado : null;
    }

    private string PedirNombreBarraGrafico(IWin32Window propietario, string anterior)
    {
        using var dialogo = DialogoGrafico("Renombrar barra de herramientas", 440, 135);
        var nombre = new TextBox { Text = anterior, MaxLength = 80, Bounds = new Rectangle(15, 38, 410, 25), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right, AccessibleName = "Nombre de la barra" };
        var aceptar = new Button { Text = "Aceptar", Bounds = new Rectangle(237, 87, 90, 28), Anchor = AnchorStyles.Bottom | AnchorStyles.Right };
        var cancelar = new Button { Text = "Cancelar", Bounds = new Rectangle(335, 87, 90, 28), Anchor = AnchorStyles.Bottom | AnchorStyles.Right, DialogResult = DialogResult.Cancel };
        dialogo.Controls.AddRange(new Control[] { new Label { Text = "Nombre:", Bounds = new Rectangle(15, 14, 200, 22) }, nombre, aceptar, cancelar });
        dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
        aceptar.Click += (_, _) =>
        {
            if (!NombreBarraGraficoValido(nombre.Text.Trim(), anterior, out string error))
            { MessageBox.Show(dialogo, error, dialogo.Text, MessageBoxButtons.OK, MessageBoxIcon.Information); nombre.Focus(); return; }
            dialogo.DialogResult = DialogResult.OK;
        };
        dialogo.Shown += (_, _) => { nombre.SelectAll(); nombre.Focus(); };
        return dialogo.ShowDialog(propietario) == DialogResult.OK ? nombre.Text.Trim() : null;
    }

    private bool NombreBarraGraficoValido(string nombre, string excluir, out string error)
    {
        error = "";
        if (string.IsNullOrWhiteSpace(nombre) || nombre.Length > 80) error = "Escriba un nombre de entre 1 y 80 caracteres.";
        else if (string.Equals(nombre, "Tipo de gráfico", StringComparison.OrdinalIgnoreCase) ||
            configuracion.BarrasPersonalizadas.Any(b => b.Nombre != excluir && string.Equals(b.Nombre, nombre, StringComparison.OrdinalIgnoreCase)))
            error = "Ya existe una barra con ese nombre. Elija otro nombre.";
        return error.Length == 0;
    }
}
