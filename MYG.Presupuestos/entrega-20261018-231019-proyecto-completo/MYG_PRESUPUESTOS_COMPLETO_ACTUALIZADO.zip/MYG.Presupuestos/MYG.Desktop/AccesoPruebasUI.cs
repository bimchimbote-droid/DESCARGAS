using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("MYG.PruebasUI")]
