using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace MYG_2027;

// Project ofrece los campos *Text para introducir valores de tareas manuales.
// Comprobar lo introducido; no sustituirlo por una duración inferida del intervalo.
internal sealed record MYGTextoTareaManualProject(string Inicio, string Fin, string Duracion);

internal static class MYGConfiguracionTareaManualProject
{
    internal static void Restaurar(MYGTextoTareaManualProject texto,
        Func<string, object> leer, Action<string, object> escribir)
    {
        if (!Convert.ToBoolean(leer("Manual"), CultureInfo.InvariantCulture)) escribir("Manual", true);
        // El avance, las asignaciones y los vínculos se aplican antes de esta
        // restauración. No convertir la tarea a automática para fijar sus fechas.
        Fijar("StartText", texto.Inicio);
        Fijar("FinishText", texto.Fin);
        Fijar("DurationText", texto.Duracion);

        void Fijar(string campo, string valor)
        {
            if (!TextoIgual(leer(campo), valor)) escribir(campo, valor);
        }
    }

    internal static void Verificar(MYGTareaExportacionProject datos, MYGTextoTareaManualProject texto,
        Func<string, object> leer, Func<string, object> interpretarDuracion = null)
    {
        if (!Convert.ToBoolean(leer("Manual"), CultureInfo.InvariantCulture))
            Fallo("modo", "manual", "automático");
        Fecha("StartText", "Start", texto.Inicio, datos.Inicio);
        Fecha("FinishText", "Finish", texto.Fin, datos.Fin);
        // Project puede normalizar el texto al idioma y unidad de su interfaz.
        // Solo admitirlo si el texto y los minutos tipados conservan el valor;
        // DurationValue respeta las horas/día configuradas en Project.
        object duracion = leer("DurationText");
        if (!TextoIgual(duracion, texto.Duracion) &&
            (!NumeroIgual(leer("Duration"), datos.DuracionMinutos) ||
                (!TextoVacio(duracion) && !DuracionTextoIgual(duracion, datos.DuracionMinutos, interpretarDuracion))))
            Fallo("duración", texto.Duracion, duracion);

        void Fecha(string campoTexto, string campoFecha, string esperadoTexto, DateTime esperado)
        {
            object actual = leer(campoTexto);
            if (TextoIgual(actual, esperadoTexto)) return;
            object fechaTipada = leer(campoFecha);
            bool tipadaCorrecta = FechaIgual(fechaTipada, esperado);
            // La vista «mar 3/12/24» omite la hora. Su fecha debe coincidir y
            // Start/Finish deben conservar la hora exacta; nunca inferir 08:00.
            bool correcto = TextoVacio(actual) ? tipadaCorrecta :
                (!(fechaTipada is DateTime) || tipadaCorrecta) && FechaTextoIgual(actual, esperado, tipadaCorrecta);
            if (!correcto) Fallo(campoFecha == "Start" ? "inicio" : "fin", esperadoTexto, actual);
        }
        void Fallo(string campo, object esperado, object actual) =>
            throw new InvalidOperationException("Microsoft Project cambió el " + campo + " de la tarea manual «" + datos.Nombre +
                "». Esperado: " + esperado + "; recibido: " + actual + ". No se reemplazó el archivo de destino.");
    }

    private static bool TextoIgual(object valor, string esperado) =>
        string.Equals(Convert.ToString(valor, CultureInfo.InvariantCulture)?.Trim(), esperado?.Trim(), StringComparison.OrdinalIgnoreCase);

    private static bool TextoVacio(object valor) => string.IsNullOrWhiteSpace(Convert.ToString(valor, CultureInfo.InvariantCulture));

    private static bool FechaIgual(object valor, DateTime esperado) => valor is DateTime fecha &&
        Math.Abs((fecha - esperado).TotalSeconds) < 1;

    private static bool FechaTextoIgual(object valor, DateTime esperado, bool horaTipadaCorrecta)
    {
        string texto = Convert.ToString(valor, CultureInfo.InvariantCulture)?.Trim();
        var cultura = CultureInfo.CurrentCulture;
        // Usar la cultura activa, sin probar otras que podrían interpretar
        // 3/12 como 12 de marzo. Todos los patrones exigen un año explícito.
        var fechas = new HashSet<string>(cultura.DateTimeFormat.GetAllDateTimePatterns('d')
            .Concat(cultura.DateTimeFormat.GetAllDateTimePatterns('D')).Where(p => p.Contains('y')), StringComparer.Ordinal);
        foreach (string patron in fechas.ToArray())
        {
            string corto = Regex.Replace(Regex.Replace(patron, "(?<!d)dd(?!d)", "d"), "(?<!M)MM(?!M)", "M");
            fechas.Add(corto);
            fechas.Add(corto.Replace("yyyy", "yy"));
        }
        fechas.Add("d MMMM yyyy");
        fechas.Add("MMMM d yyyy");
        foreach (string patron in fechas.ToArray())
        {
            fechas.Add("ddd " + patron);
            fechas.Add("dddd " + patron);
        }
        if (DateTime.TryParseExact(texto, fechas.ToArray(), cultura, DateTimeStyles.AllowWhiteSpaces, out DateTime fecha))
            return horaTipadaCorrecta && fecha.Date == esperado.Date;
        string[] horas = { "H:mm", "H:mm:ss", "h:mm tt", "h:mm:ss tt",
            cultura.DateTimeFormat.ShortTimePattern, cultura.DateTimeFormat.LongTimePattern };
        string[] fechasHoras = fechas.SelectMany(f => horas.Select(h => f + " " + h)).Distinct().ToArray();
        return DateTime.TryParseExact(texto, fechasHoras, cultura, DateTimeStyles.AllowWhiteSpaces, out fecha) &&
            FechaIgual(fecha, esperado);
    }

    private static bool DuracionTextoIgual(object valor, decimal esperado, Func<string, object> interpretar)
    {
        string texto = Convert.ToString(valor, CultureInfo.InvariantCulture)?.Trim();
        if (interpretar != null)
        {
            try { return NumeroIgual(interpretar(texto), esperado); }
            catch (Exception) { return false; } // Texto que Project no puede convertir: rechazar con el diagnóstico del campo.
        }
        // Respaldo sin Office: minutos, horas y segundos tienen conversión
        // inequívoca. Días y semanas necesitan DurationValue y su calendario.
        var partes = Regex.Match(texto ?? "", @"^([+-]?\d+(?:[.,]\d+)?)\s*(min(?:s|uto(?:s)?|ute(?:s)?)?|m|h(?:r(?:s)?|ora(?:s)?|our(?:s)?)?|s(?:eg(?:undo(?:s)?)?|ec(?:ond(?:s)?)?)?)\.?$",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        if (!partes.Success || !decimal.TryParse(partes.Groups[1].Value,
            NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint, CultureInfo.CurrentCulture, out decimal cantidad)) return false;
        string unidad = partes.Groups[2].Value.ToLowerInvariant();
        try
        {
            decimal minutos = unidad.StartsWith('h') ? cantidad * 60m : unidad.StartsWith('s') ? cantidad / 60m : cantidad;
            return Math.Abs(minutos - esperado) <= 0.01m;
        }
        catch (OverflowException) { return false; }
    }

    private static bool NumeroIgual(object valor, decimal esperado)
    {
        if (valor == null || valor is string) return false;
        try { return Math.Abs(Convert.ToDecimal(valor, CultureInfo.InvariantCulture) - esperado) <= 0.01m; }
        catch (FormatException) { return false; }
        catch (InvalidCastException) { return false; }
        catch (OverflowException) { return false; }
    }
}
