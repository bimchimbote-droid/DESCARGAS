using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGConfirmarPlantillaMetradoForm : Form
{
    private const int TiempoCancelacion = 10;
    private const int TiempoLectura = 3;
    private readonly System.Windows.Forms.Timer temporizador = new() { Interval = 250 };
    private readonly Stopwatch tiempo = new();
    private readonly Button aceptar;
    private readonly Button cancelar;
    private readonly Label advertencia;
    private readonly Label cuentaRegresiva;
    private readonly Font fuenteFormulario = new("Segoe UI", 10F);
    private readonly Font fuenteAdvertencia = new("Segoe UI", 11F, FontStyle.Bold);
    private readonly Bitmap imagenInformacion = SystemIcons.Information.ToBitmap();
    private int segundosTranscurridos;

    internal MYGConfirmarPlantillaMetradoForm(string nombrePlantilla)
    {
        Name = "plantilla_confirmacion";
        Text = "Nueva Plantilla";
        Font = fuenteFormulario;
        AutoScaleDimensions = new(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new(580, 340);
        MinimumSize = new(500, 300);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        BackColor = MYG2027_TemaComercial.Fondo;
        ForeColor = MYG2027_TemaComercial.Texto;
        AccessibleName = "Confirmar cambio de plantilla de metrado";
        string plantilla = string.IsNullOrWhiteSpace(nombrePlantilla) ? "la plantilla seleccionada" : nombrePlantilla;
        string mensaje = "Plantilla: " + plantilla + ".\n\n"
            + "Se reemplazarán los datos, las fórmulas y los formatos de la hoja de metrado de la partida actual. "
            + "Podrá deshacer este cambio con Ctrl+Z.";
        AccessibleDescription = mensaje;

        var contenido = new TableLayoutPanel
        {
            Name = "plantilla_confirmacion_contenido", Dock = DockStyle.Fill,
            Padding = new(22, 18, 22, 14), ColumnCount = 1, RowCount = 6, AutoScroll = true
        };
        contenido.ColumnStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Absolute, 44));
        contenido.RowStyles.Add(new(SizeType.AutoSize));
        contenido.RowStyles.Add(new(SizeType.AutoSize));
        contenido.RowStyles.Add(new(SizeType.AutoSize));
        contenido.RowStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Absolute, 52));
        var icono = new PictureBox
        {
            Name = "plantilla_confirmacion_icono", Image = imagenInformacion,
            Size = new(32, 32), SizeMode = PictureBoxSizeMode.Zoom, Anchor = AnchorStyles.None,
            Margin = new(0, 0, 0, 8), TabStop = false, AccessibleName = "Información"
        };
        advertencia = new Label
        {
            Name = "plantilla_confirmacion_advertencia", Text = "¡Está por abrir una nueva plantilla XLS!",
            Font = fuenteAdvertencia, AutoSize = true, Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter, Margin = new(0, 0, 0, 14)
        };
        var detalle = new Label
        {
            Name = "plantilla_confirmacion_mensaje", Text = mensaje, AutoSize = true,
            Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft,
            Margin = new(0, 0, 0, 12), AccessibleName = "Consecuencias del cambio de plantilla"
        };
        cuentaRegresiva = new Label
        {
            Name = "plantilla_confirmacion_tiempo", AutoSize = true, Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter, Margin = new(0, 0, 0, 10),
            ForeColor = MYG2027_TemaComercial.Secundario, AccessibleName = "Cancelación automática"
        };
        var botones = new FlowLayoutPanel
        {
            Name = "plantilla_confirmacion_botones", Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Padding = new(0, 5, 0, 0)
        };
        cancelar = MYGProyectoUI.Boton("Cancelar");
        cancelar.Name = "plantilla_confirmacion_cancelar";
        cancelar.Width = 146;
        cancelar.TabIndex = 0;
        cancelar.DialogResult = DialogResult.Cancel;
        cancelar.AccessibleName = "Cancelar cambio de plantilla";
        cancelar.Click += (_, _) => CancelarCambio();
        aceptar = MYGProyectoUI.Boton("Aceptar", 1);
        aceptar.Name = "plantilla_confirmacion_aceptar";
        aceptar.Width = 146;
        aceptar.TabIndex = 1;
        aceptar.AccessibleName = "Aceptar cambio de plantilla";
        aceptar.AccessibleDescription = "Se habilita después de tres segundos para permitir leer la advertencia.";
        aceptar.Click += (_, _) =>
        {
            if (tiempo.IsRunning) ActualizarEspera((int)tiempo.Elapsed.TotalSeconds);
            if (IsDisposed || Disposing || DialogResult != DialogResult.None) return;
            if (!aceptar.Enabled || segundosTranscurridos >= TiempoCancelacion) return;
            DialogResult = DialogResult.OK;
            Close();
        };
        botones.Controls.Add(cancelar);
        botones.Controls.Add(aceptar);
        contenido.Controls.Add(icono, 0, 0);
        contenido.Controls.Add(advertencia, 0, 1);
        contenido.Controls.Add(detalle, 0, 2);
        contenido.Controls.Add(cuentaRegresiva, 0, 3);
        contenido.Controls.Add(botones, 0, 5);
        Controls.Add(contenido);

        // Enter, Escape, la X y el vencimiento conservan la hoja actual.
        AcceptButton = cancelar;
        CancelButton = cancelar;
        ActualizarEspera(0);
        temporizador.Tick += (_, _) => ActualizarEspera((int)tiempo.Elapsed.TotalSeconds);
        MYG2027_TemaComercial.CambioTema += ActualizarTema;
        ActualizarTema(null, EventArgs.Empty);
    }

    // Permite verificar las transiciones de la cuenta regresiva sin esperas reales.
    internal void ActualizarEspera(int segundos)
    {
        if (IsDisposed || Disposing || DialogResult != DialogResult.None) return;
        segundosTranscurridos = Math.Max(segundosTranscurridos, Math.Clamp(segundos, 0, TiempoCancelacion));
        int restantes = TiempoCancelacion - segundosTranscurridos;
        int lectura = Math.Max(0, TiempoLectura - segundosTranscurridos);
        aceptar.Enabled = lectura == 0 && restantes > 0;
        aceptar.Text = lectura > 0 ? "Aceptar (" + lectura + ")" : "Aceptar";
        cancelar.Text = "Cancelar (" + restantes + ")";
        cuentaRegresiva.Text = "Se cerrará automáticamente en " + restantes + " segundos, sin cambiar la plantilla.";
        if (restantes == 0) CancelarCambio();
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        if (DialogResult != DialogResult.None) return;
        MYG2027_TemaComercial.AjustarAlAreaDeTrabajo(this);
        cancelar.Focus();
        tiempo.Restart();
        temporizador.Start();
    }

    protected override bool ProcessDialogKey(Keys keyData)
    {
        if (keyData == Keys.Enter || keyData == Keys.Escape)
        {
            CancelarCambio();
            return true;
        }
        return base.ProcessDialogKey(keyData);
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        temporizador.Stop();
        tiempo.Stop();
        if (DialogResult != DialogResult.OK) DialogResult = DialogResult.Cancel;
        base.OnFormClosing(e);
    }

    private void CancelarCambio()
    {
        temporizador.Stop();
        DialogResult = DialogResult.Cancel;
        Close();
    }

    private void ActualizarTema(object sender, EventArgs e)
    {
        MYG2027_TemaComercial.Aplicar(this);
        advertencia.ForeColor = SystemInformation.HighContrast ? SystemColors.WindowText
            : MYG2027_TemaComercial.ColorTitulo(0);
        cuentaRegresiva.ForeColor = MYG2027_TemaComercial.Secundario;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            MYG2027_TemaComercial.CambioTema -= ActualizarTema;
            temporizador.Dispose();
            tiempo.Stop();
        }
        base.Dispose(disposing);
        if (disposing)
        {
            imagenInformacion.Dispose();
            fuenteAdvertencia.Dispose();
            fuenteFormulario.Dispose();
        }
    }
}
