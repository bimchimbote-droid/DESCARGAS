using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>
/// Anotaciones de la partida. RichEdit descarta los destinos desconocidos al cargar;
/// el editor conserva este destino ignorable junto con la configuración de página.
/// </summary>
internal sealed class MYGEspecificacionesAnotaciones : IDisposable
{
    private const string Destino = @"{\*\myganotaciones";
    private const int LimiteElementos = 500, LimiteComentario = 20000, LimiteMetadatos = 16 * 1024 * 1024;
    private const int LimiteEdicionMetadatos = 8 * 1024 * 1024;
    private readonly RichTextBox documento;
    private readonly IWin32Window propietario;
    private readonly Action<Action> aplicar;
    private readonly List<Anotacion> elementos = new();
    private readonly List<EstadoTexto> historial = new();
    private readonly List<EstadoVinculos> historialVinculos = new();
    private string textoAnterior;
    private string ultimoRtfVinculos;
    private readonly record struct Rango(int Inicio, int Longitud, string Ancla);
    private sealed record EstadoTexto(string Huella, Dictionary<string, Rango> Rangos);
    private readonly record struct Vinculo(string Texto, string Direccion);
    private sealed record EstadoVinculos(string Huella, Dictionary<string, Vinculo> Vinculos);

    internal sealed class Anotacion
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public string Tipo { get; set; } = "";
        public string Texto { get; set; } = "";
        public string Direccion { get; set; } = "";
        public int Inicio { get; set; }
        public int Longitud { get; set; }
        public string Ancla { get; set; } = "";
        public Anotacion() { }
        public override string ToString() => Tipo == "comentario"
            ? Texto.Replace('\r', ' ').Replace('\n', ' ') : Texto;
    }

    private sealed class Datos
    {
        public int Version { get; set; } = 1;
        public List<Anotacion> Elementos { get; set; } = new();
        public Datos() { }
    }

    private readonly record struct Grupo(int Inicio, int Fin, int Contenido);

    internal IReadOnlyList<Anotacion> Elementos => elementos.AsReadOnly();

    internal MYGEspecificacionesAnotaciones(RichTextBox documento, IWin32Window propietario, Action<Action> aplicarFormato)
    {
        this.documento = documento ?? throw new ArgumentNullException(nameof(documento));
        this.propietario = propietario;
        aplicar = aplicarFormato ?? throw new ArgumentNullException(nameof(aplicarFormato));
        textoAnterior = documento.Text;
        documento.TextChanged += TextoCambiado;
    }

    /// <summary>Llamar después de cargar el RTF o el texto de la nueva partida.</summary>
    internal void Leer(string rtf)
    {
        elementos.Clear();
        historial.Clear();
        historialVinculos.Clear(); ultimoRtfVinculos = null;
        textoAnterior = documento.Text;
        if (!Analizar(rtf, out _, out var grupos) || grupos.Count == 0) return;
        var grupo = grupos[0];
        int largo = grupo.Fin - grupo.Contenido - 1;
        if (largo < 1 || largo > LimiteMetadatos) return;
        try
        {
            var datos = JsonSerializer.Deserialize<Datos>(Convert.FromBase64String(rtf.Substring(grupo.Contenido, largo)));
            if (datos?.Version != 1 || datos.Elementos == null || datos.Elementos.Count > LimiteElementos) return;
            foreach (var item in datos.Elementos)
            {
                if (!Valida(item) || elementos.Any(x => x.Id == item.Id)) continue;
                item.Inicio = Math.Clamp(item.Inicio, 0, textoAnterior.Length);
                item.Longitud = Math.Clamp(item.Longitud, 0, textoAnterior.Length - item.Inicio);
                // El ancla permite recuperar una posición tras importar un RTF normalizado.
                if (item.Ancla.Length > 0 && item.Longitud > 0 &&
                    (item.Longitud < item.Ancla.Length ||
                        !textoAnterior.AsSpan(item.Inicio, item.Ancla.Length).SequenceEqual(item.Ancla)))
                {
                    int posicion = textoAnterior.IndexOf(item.Ancla, StringComparison.Ordinal);
                    if (posicion >= 0) { item.Inicio = posicion; item.Longitud = Math.Min(item.Longitud, textoAnterior.Length - posicion); }
                }
                elementos.Add(item);
            }
        }
        catch (FormatException) { }
        catch (JsonException) { }
        catch (ArgumentException) { }
        Recordar(textoAnterior);
    }

    internal string Guardar(string rtf)
    {
        ActualizarTexto();
        SincronizarVinculos();
        if (!Analizar(rtf, out int cabecera, out var grupos))
            throw new ArgumentException("Las anotaciones requieren un documento RTF completo.", nameof(rtf));
        var limpio = Quitar(rtf, grupos);
        if (elementos.Count == 0) return limpio;
        var datos = Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(new Datos { Elementos = elementos }));
        if (datos.Length > LimiteMetadatos)
            throw new InvalidOperationException("Las anotaciones superan el tamaño permitido. Reduzca sus comentarios.");
        return limpio.Insert(cabecera, Destino + " " + datos + "}");
    }

    internal static string QuitarMetadatos(string rtf) => Analizar(rtf, out _, out var grupos) ? Quitar(rtf, grupos) : rtf ?? "";

    private void TextoCambiado(object sender, EventArgs e) => ActualizarTexto();

    internal void ActualizarTexto()
    {
        string actual = documento.Text;
        if (actual == textoAnterior) return;
        Recordar(textoAnterior);
        string huella = Huella(actual);
        var conocido = historial.LastOrDefault(x => x.Huella == huella);
        ActualizarRangos(elementos, textoAnterior, actual);
        if (conocido != null)
            foreach (var item in elementos)
                if (conocido.Rangos.TryGetValue(item.Id, out var rango))
                {
                    item.Inicio = Math.Clamp(rango.Inicio, 0, actual.Length);
                    item.Longitud = Math.Clamp(rango.Longitud, 0, actual.Length - item.Inicio);
                    item.Ancla = rango.Ancla;
                }
        textoAnterior = actual;
        Recordar(actual, huella);
    }

    // Mantiene las posiciones de textos visitados para Undo/Redo. Sólo restaura
    // elementos todavía presentes: eliminar un comentario no lo hace reaparecer.
    private void Recordar(string texto, string huella = null)
    {
        huella ??= Huella(texto);
        var rangos = elementos.ToDictionary(x => x.Id, x => new Rango(x.Inicio, x.Longitud, x.Ancla));
        historial.RemoveAll(x => x.Huella == huella);
        historial.Add(new(huella, rangos));
        if (historial.Count > 64) historial.RemoveAt(0);
    }

    private static string Huella(string texto) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(texto)));

    // Cambiar sólo la dirección mantiene el mismo texto, pero crea una entrada
    // Undo nativa del campo. La firma RTF permite recuperar también su destino.
    private void SincronizarVinculos()
    {
        var vinculos = elementos.Where(x => x.Tipo == "hipervinculo").ToArray();
        if (vinculos.Length == 0) return;
        string huella = Huella(documento.Rtf);
        if (huella != ultimoRtfVinculos)
        {
            var conocido = historialVinculos.LastOrDefault(x => x.Huella == huella);
            if (conocido != null)
                foreach (var item in vinculos)
                    if (conocido.Vinculos.TryGetValue(item.Id, out var anterior))
                    { item.Texto = anterior.Texto; item.Direccion = anterior.Direccion; }
        }
        historialVinculos.RemoveAll(x => x.Huella == huella);
        historialVinculos.Add(new(huella, vinculos.ToDictionary(x => x.Id, x => new Vinculo(x.Texto, x.Direccion))));
        if (historialVinculos.Count > 64) historialVinculos.RemoveAt(0);
        ultimoRtfVinculos = huella;
    }

    // Un único intervalo cambiado cubre también pegado, reemplazo, deshacer y rehacer.
    internal static void ActualizarRangos(IEnumerable<Anotacion> anotaciones, string anterior, string actual)
    {
        int inicio = 0;
        while (inicio < anterior.Length && inicio < actual.Length && anterior[inicio] == actual[inicio]) inicio++;
        int finAnterior = anterior.Length, finActual = actual.Length;
        while (finAnterior > inicio && finActual > inicio && anterior[finAnterior - 1] == actual[finActual - 1])
        { finAnterior--; finActual--; }
        int delta = finActual - finAnterior;
        foreach (var item in anotaciones)
        {
            int desde = Math.Clamp(item.Inicio, 0, anterior.Length);
            int hasta = desde + Math.Clamp(item.Longitud, 0, anterior.Length - desde);
            int nuevoDesde = desde < inicio ? desde : desde >= finAnterior ? desde + delta : inicio;
            int nuevoHasta = hasta <= inicio ? hasta : hasta >= finAnterior ? hasta + delta : finActual;
            if (desde == hasta) nuevoHasta = nuevoDesde;
            nuevoDesde = Math.Clamp(nuevoDesde, 0, actual.Length);
            nuevoHasta = Math.Clamp(nuevoHasta, nuevoDesde, actual.Length);
            item.Inicio = nuevoDesde; item.Longitud = nuevoHasta - nuevoDesde;
            if (item.Longitud > 0)
            {
                int largoAncla = Math.Min(item.Longitud, 2000);
                if (item.Ancla == null || item.Ancla.Length != largoAncla ||
                    !actual.AsSpan(item.Inicio, largoAncla).SequenceEqual(item.Ancla))
                    item.Ancla = actual.Substring(item.Inicio, largoAncla);
            }
        }
    }

    internal void AgregarMarcador(string nombre)
    {
        nombre = nombre?.Trim() ?? "";
        if (nombre.Length is < 1 or > 40 || !(char.IsLetter(nombre[0]) || nombre[0] == '_') ||
            nombre.Any(c => !char.IsLetterOrDigit(c) && c != '_'))
            throw new ArgumentException("Use hasta 40 letras, números o guiones bajos; empiece con una letra o un guion bajo.", nameof(nombre));
        var existente = elementos.FirstOrDefault(x => x.Tipo == "marcador" && x.Texto.Equals(nombre, StringComparison.OrdinalIgnoreCase));
        if (existente == null) ComprobarCapacidad();
        int inicio = documento.SelectionStart, longitud = documento.SelectionLength;
        var candidato = Copiar(existente) ?? new Anotacion { Tipo = "marcador" };
        candidato.Texto = nombre; EstablecerRango(candidato, inicio, longitud); ComprobarTamano(candidato, existente);
        aplicar(() =>
        {
            var item = existente ?? new Anotacion { Tipo = "marcador" };
            item.Texto = nombre; EstablecerRango(item, inicio, longitud);
            if (existente == null) elementos.Add(item);
        });
    }

    internal void AgregarComentario(string texto)
    {
        ValidarComentario(texto); ComprobarCapacidad();
        int inicio = documento.SelectionStart, longitud = documento.SelectionLength;
        var candidato = new Anotacion { Tipo = "comentario", Texto = texto.Trim() };
        EstablecerRango(candidato, inicio, longitud); ComprobarTamano(candidato);
        aplicar(() =>
        {
            elementos.Add(candidato);
        });
    }

    internal void Ir(Anotacion item)
    {
        ActualizarTexto();
        documento.Select(Math.Clamp(item.Inicio, 0, documento.TextLength),
            Math.Clamp(item.Longitud, 0, documento.TextLength - Math.Clamp(item.Inicio, 0, documento.TextLength)));
        documento.ScrollToCaret(); documento.Focus();
    }

    internal void Eliminar(Anotacion item) => aplicar(() => elementos.Remove(item));

    internal void Marcadores()
    {
        using var dialogo = CrearDialogo("Marcador", "espec_marcadores", 490, 328);
        var nombre = new TextBox { Name = "espec_marcador_nombre", Location = new(18, 41), Width = 454, MaxLength = 40 };
        var lista = new ListBox { Name = "espec_marcador_lista", Location = new(18, 84), Size = new(454, 177) };
        dialogo.Controls.AddRange(new Control[] { Etiqueta("Nombre del marcador", 18, 17, 440), nombre, lista });
        void Llenar()
        {
            lista.Items.Clear();
            lista.Items.AddRange(elementos.Where(x => x.Tipo == "marcador").OrderBy(x => x.Texto).Cast<object>().ToArray());
        }
        lista.SelectedIndexChanged += (_, _) => { if (lista.SelectedItem is Anotacion item) nombre.Text = item.Texto; };
        Boton(dialogo, "Agregar", "espec_marcador_agregar", 18, 281, () => Ejecutar(dialogo, () => { AgregarMarcador(nombre.Text); Llenar(); }));
        Boton(dialogo, "Ir a", "espec_marcador_ir", 133, 281, () => { if (lista.SelectedItem is Anotacion item) { Ir(item); dialogo.Close(); } });
        Boton(dialogo, "Eliminar", "espec_marcador_eliminar", 248, 281, () => { if (lista.SelectedItem is Anotacion item) { Eliminar(item); Llenar(); } });
        BotonCerrar(dialogo, 363, 281);
        Llenar(); Mostrar(dialogo);
    }

    internal void Comentarios(bool nuevo = true)
    {
        using var dialogo = CrearDialogo("Comentarios de la especificación", "espec_comentarios", 650, 425);
        var lista = new ListBox { Name = "espec_comentario_lista", Location = new(18, 40), Size = new(220, 290) };
        var ancla = Etiqueta("", 256, 40, 374); ancla.Height = 55; ancla.AutoEllipsis = true;
        var texto = new TextBox { Name = "espec_comentario_texto", Multiline = true, AcceptsReturn = true, ScrollBars = ScrollBars.Vertical,
            Location = new(256, 105), Size = new(374, 225), MaxLength = LimiteComentario };
        dialogo.Controls.AddRange(new Control[] { Etiqueta("Comentarios guardados", 18, 17, 260), lista, ancla, texto });
        int inicioNuevo = documento.SelectionStart, longitudNueva = documento.SelectionLength;
        string anclaNueva = documento.SelectedText;
        void Llenar(Anotacion seleccionado = null)
        {
            lista.Items.Clear(); lista.Items.AddRange(elementos.Where(x => x.Tipo == "comentario").Cast<object>().ToArray());
            if (seleccionado != null) lista.SelectedItem = seleccionado;
        }
        void Nuevo()
        {
            lista.SelectedIndex = -1; texto.Clear();
            ancla.Text = "Texto comentado: " + (anclaNueva.Length > 0 ? anclaNueva : "posición del cursor"); texto.Focus();
        }
        lista.SelectedIndexChanged += (_, _) =>
        {
            if (lista.SelectedItem is not Anotacion item) return;
            texto.Text = item.Texto; ancla.Text = "Texto comentado: " + (item.Ancla.Length > 0 ? item.Ancla : "posición del cursor");
        };
        Boton(dialogo, "Nuevo", "espec_comentario_nuevo", 18, 351, Nuevo);
        Boton(dialogo, "Guardar", "espec_comentario_guardar", 133, 351, () => Ejecutar(dialogo, () =>
        {
            ValidarComentario(texto.Text);
            var existente = lista.SelectedItem as Anotacion;
            if (existente == null) ComprobarCapacidad();
            var candidato = Copiar(existente) ?? new Anotacion { Tipo = "comentario" };
            candidato.Texto = texto.Text.Trim();
            if (existente == null) EstablecerRango(candidato, inicioNuevo, longitudNueva);
            ComprobarTamano(candidato, existente);
            aplicar(() =>
            {
                if (existente != null) { existente.Texto = texto.Text.Trim(); return; }
                existente = candidato; elementos.Add(existente);
            });
            Llenar(existente);
        }));
        Boton(dialogo, "Eliminar", "espec_comentario_eliminar", 248, 351, () =>
        { if (lista.SelectedItem is Anotacion item) { Eliminar(item); Llenar(); Nuevo(); } });
        Boton(dialogo, "Ir al texto", "espec_comentario_ir", 363, 351, () =>
        { if (lista.SelectedItem is Anotacion item) { Ir(item); dialogo.Close(); } });
        BotonCerrar(dialogo, 518, 351);
        dialogo.Controls.Add(Etiqueta("Guarde el comentario antes de cerrar esta ventana.", 18, 394, 615));
        Llenar();
        if (nuevo || lista.Items.Count == 0) Nuevo(); else lista.SelectedIndex = 0;
        Mostrar(dialogo);
    }

    internal void Hipervinculo()
    {
        var existente = elementos.FirstOrDefault(x => x.Tipo == "hipervinculo" &&
            documento.SelectionStart >= x.Inicio && documento.SelectionStart < x.Inicio + x.Longitud);
        int inicio = existente?.Inicio ?? documento.SelectionStart;
        int longitud = existente?.Longitud ?? documento.SelectionLength;
        using var dialogo = CrearDialogo("Hipervínculo", "espec_hipervinculo", 520, 225);
        var etiqueta = new TextBox { Name = "espec_hipervinculo_etiqueta", Location = new(18, 43), Width = 484, MaxLength = 2000,
            Text = longitud > 0 ? documento.Text.Substring(inicio, longitud) : "" };
        var direccion = new TextBox { Name = "espec_hipervinculo_direccion", Location = new(18, 107), Width = 484, MaxLength = 4000,
            Text = existente?.Direccion ?? "https://" };
        dialogo.Controls.AddRange(new Control[] { Etiqueta("Texto para mostrar", 18, 18, 480), etiqueta,
            Etiqueta("Dirección (https://, http:// o mailto:)", 18, 82, 480), direccion });
        var aceptar = Boton(dialogo, "Aceptar", "espec_hipervinculo_aceptar", 287, 174, () => Ejecutar(dialogo, () =>
        {
            InsertarHipervinculo(etiqueta.Text, direccion.Text, inicio, longitud, existente); dialogo.DialogResult = DialogResult.OK;
        }));
        var cancelar = BotonCerrar(dialogo, 402, 174); cancelar.Text = "Cancelar";
        dialogo.AcceptButton = aceptar;
        Mostrar(dialogo);
    }

    internal void InsertarHipervinculo(string etiqueta, string direccion, int? inicio = null, int? longitud = null, Anotacion existente = null)
    {
        etiqueta = etiqueta?.Trim() ?? "";
        if (etiqueta.Length is < 1 or > 2000 || etiqueta.IndexOfAny(['\r', '\n', '\0']) >= 0)
            throw new ArgumentException("Escriba un texto de enlace de una sola línea, de hasta 2000 caracteres.", nameof(etiqueta));
        string destino = ValidarDireccion(direccion);
        if (existente == null) ComprobarCapacidad();
        int desde = inicio ?? documento.SelectionStart, largo = longitud ?? documento.SelectionLength;
        if (desde < 0 || largo < 0 || desde > documento.TextLength || largo > documento.TextLength - desde)
            throw new ArgumentOutOfRangeException(nameof(inicio));
        var candidato = Copiar(existente) ?? new Anotacion { Tipo = "hipervinculo" };
        candidato.Texto = etiqueta; candidato.Direccion = destino; candidato.Inicio = desde;
        candidato.Longitud = etiqueta.Length; candidato.Ancla = etiqueta;
        ComprobarTamano(candidato, existente);
        aplicar(() =>
        {
            documento.Select(desde, largo);
            string campo = @"{\rtf1\ansi\uc1{\colortbl ;\red0\green102\blue204;}" +
                @"{\field{\*\fldinst HYPERLINK """ + EscaparRtf(destino) + @"""}{\fldrslt\ul\cf1 " + EscaparRtf(etiqueta) + "}}}";
            documento.SelectedRtf = campo;
            var item = existente ?? new Anotacion { Tipo = "hipervinculo" };
            item.Texto = etiqueta; item.Direccion = destino; EstablecerRango(item, desde, etiqueta.Length);
            if (existente == null) elementos.Add(item);
            documento.Select(desde + etiqueta.Length, 0);
        });
    }

    internal static string ValidarDireccion(string direccion)
    {
        if (string.IsNullOrWhiteSpace(direccion) || direccion.Length > 4000 || direccion.Any(char.IsControl) ||
            !Uri.TryCreate(direccion.Trim(), UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeMailto) ||
            ((uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps) && string.IsNullOrEmpty(uri.Host)) ||
            (uri.Scheme == Uri.UriSchemeMailto && (string.IsNullOrEmpty(uri.UserInfo) || string.IsNullOrEmpty(uri.Host))))
            throw new ArgumentException("Escriba una dirección válida que empiece con https://, http:// o mailto:.", nameof(direccion));
        return uri.AbsoluteUri;
    }

    /// <summary>Exportación legible de los comentarios, sin modificar el documento editable.</summary>
    internal void AñadirComentariosParaExportacion(RichTextBox copia)
    {
        var comentarios = elementos.Where(x => x.Tipo == "comentario").ToArray();
        if (comentarios.Length == 0) return;
        copia.Select(copia.TextLength, 0);
        copia.SelectedText = "\n\nCOMENTARIOS DE LA ESPECIFICACIÓN\n";
        for (int i = 0; i < comentarios.Length; i++)
        {
            var item = comentarios[i];
            copia.SelectedText = (i + 1) + ". " + (item.Ancla.Length > 0 ? "Texto: «" + item.Ancla + "»\n" : "") + item.Texto + "\n\n";
        }
    }

    private void EstablecerRango(Anotacion item, int inicio, int longitud)
    {
        item.Inicio = Math.Clamp(inicio, 0, documento.TextLength);
        item.Longitud = Math.Clamp(longitud, 0, documento.TextLength - item.Inicio);
        item.Ancla = documento.Text.Substring(item.Inicio, Math.Min(item.Longitud, 2000));
    }

    private static bool Valida(Anotacion item)
    {
        if (item == null || !Guid.TryParseExact(item.Id, "N", out _) || item.Inicio < 0 || item.Longitud < 0 ||
            item.Ancla == null || item.Ancla.Length > 2000 || item.Texto == null || item.Direccion == null) return false;
        if (item.Tipo == "marcador") return item.Texto.Length is >= 1 and <= 40;
        if (item.Tipo == "comentario") return item.Texto.Length is >= 1 and <= LimiteComentario;
        if (item.Tipo != "hipervinculo" || item.Texto.Length is < 1 or > 2000) return false;
        try { ValidarDireccion(item.Direccion); return true; } catch (ArgumentException) { return false; }
    }

    private static void ValidarComentario(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto) || texto.Length > LimiteComentario)
            throw new ArgumentException("Escriba un comentario de hasta 20 000 caracteres.", nameof(texto));
    }

    private void ComprobarCapacidad()
    {
        if (elementos.Count >= LimiteElementos)
            throw new InvalidOperationException("La especificación admite hasta 500 marcadores, comentarios e hipervínculos.");
    }

    private void ComprobarTamano(Anotacion candidato, Anotacion existente = null)
    {
        var siguientes = elementos.Where(x => !ReferenceEquals(x, existente)).Append(candidato).ToList();
        int bytes = JsonSerializer.SerializeToUtf8Bytes(new Datos { Elementos = siguientes }).Length;
        // Reserva espacio para actualizar los textos ancla sin impedir guardar
        // un documento cuya edición aún no alcanzó el límite de anotaciones.
        if ((bytes + 2L) / 3 * 4 > LimiteEdicionMetadatos)
            throw new InvalidOperationException("Las anotaciones ocupan demasiado espacio. Reduzca o elimine algunos comentarios antes de agregar más.");
    }

    private static Anotacion Copiar(Anotacion item) => item == null ? null : new()
    {
        Id = item.Id, Tipo = item.Tipo, Texto = item.Texto, Direccion = item.Direccion,
        Inicio = item.Inicio, Longitud = item.Longitud, Ancla = item.Ancla
    };

    private static Form CrearDialogo(string titulo, string nombre, int ancho, int alto) => new()
    {
        Name = nombre, Text = titulo, ClientSize = new(ancho, alto), FormBorderStyle = FormBorderStyle.FixedDialog,
        StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false, ShowInTaskbar = false
    };

    private static Label Etiqueta(string texto, int x, int y, int ancho) => new()
    { Text = texto, Location = new(x, y), Width = ancho, Height = 22 };

    private static Button Boton(Form dialogo, string texto, string nombre, int x, int y, Action accion)
    {
        var boton = new Button { Name = nombre, Text = texto, Location = new(x, y), Size = new(110, 30) };
        boton.Click += (_, _) => accion(); dialogo.Controls.Add(boton); return boton;
    }

    private static Button BotonCerrar(Form dialogo, int x, int y)
    {
        var boton = Boton(dialogo, "Cerrar", "espec_anotaciones_cerrar", x, y, dialogo.Close);
        boton.DialogResult = DialogResult.Cancel; dialogo.CancelButton = boton; return boton;
    }

    private void Mostrar(Form dialogo)
    { MYGEspecificacionesCinta.AplicarTema(dialogo); dialogo.ShowDialog(propietario); }

    private static void Ejecutar(IWin32Window ventana, Action accion)
    {
        try { accion(); }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException)
        { MessageBox.Show(ventana, ex.Message, "Anotaciones", MessageBoxButtons.OK, MessageBoxIcon.Information); }
    }

    private static string EscaparRtf(string texto)
    {
        var resultado = new StringBuilder(texto.Length);
        foreach (char c in texto)
        {
            if (c is '\\' or '{' or '}') resultado.Append('\\').Append(c);
            else if (c > 127) resultado.Append(@"\u").Append((short)c).Append('?');
            else resultado.Append(c);
        }
        return resultado.ToString();
    }

    private static string Quitar(string rtf, List<Grupo> grupos)
    {
        if (grupos.Count == 0) return rtf;
        var texto = new StringBuilder(rtf.Length); int desde = 0;
        foreach (var grupo in grupos)
        {
            if (grupo.Inicio < desde) continue;
            texto.Append(rtf, desde, grupo.Inicio - desde); desde = grupo.Fin;
        }
        return texto.Append(rtf, desde, rtf.Length - desde).ToString();
    }

    // La extensión puede coexistir con imágenes \bin, llaves escapadas y mygpagina.
    private static bool Analizar(string rtf, out int cabecera, out List<Grupo> grupos)
    {
        cabecera = 0; grupos = new();
        if (string.IsNullOrEmpty(rtf)) return false;
        int inicio = 0; while (inicio < rtf.Length && char.IsWhiteSpace(rtf[inicio])) inicio++;
        if (!rtf.AsSpan(inicio).StartsWith(@"{\rtf", StringComparison.Ordinal)) return false;
        int pos = inicio + 5, numero = pos;
        while (pos < rtf.Length && Digito(rtf[pos])) pos++;
        if (pos == numero || rtf.AsSpan(numero, pos - numero).IndexOfAnyExcept('0') < 0 || pos >= rtf.Length || Letra(rtf[pos])) return false;
        cabecera = pos;
        var abiertos = new Stack<(int Inicio, int Contenido)>(); pos = inicio;
        while (pos < rtf.Length)
        {
            char c = rtf[pos];
            if (c == '{')
            {
                int contenido = -1;
                if (rtf.AsSpan(pos).StartsWith(Destino, StringComparison.Ordinal))
                {
                    int fin = pos + Destino.Length;
                    if (fin < rtf.Length && (char.IsWhiteSpace(rtf[fin]) || rtf[fin] == '}')) contenido = fin;
                }
                abiertos.Push((pos, contenido)); pos++;
            }
            else if (c == '}')
            {
                if (abiertos.Count == 0) return false;
                var grupo = abiertos.Pop();
                if (grupo.Contenido >= 0) grupos.Add(new(grupo.Inicio, pos + 1, grupo.Contenido));
                pos++;
                if (abiertos.Count == 0)
                {
                    while (pos < rtf.Length && char.IsWhiteSpace(rtf[pos])) pos++;
                    if (pos != rtf.Length) return false;
                    grupos.Sort((a, b) => a.Inicio.CompareTo(b.Inicio)); return true;
                }
            }
            else if (c == '\\')
            {
                pos++; if (pos >= rtf.Length) return false;
                if (!Letra(rtf[pos]))
                {
                    if (rtf[pos] == '\'')
                    {
                        if (pos + 2 >= rtf.Length || !Hexadecimal(rtf[pos + 1]) || !Hexadecimal(rtf[pos + 2])) return false;
                        pos += 3;
                    }
                    else pos++;
                    continue;
                }
                int palabra = pos; while (pos < rtf.Length && Letra(rtf[pos])) pos++;
                bool binario = rtf.AsSpan(palabra, pos - palabra).SequenceEqual("bin");
                int argumento = pos; if (pos < rtf.Length && rtf[pos] == '-') pos++;
                while (pos < rtf.Length && Digito(rtf[pos])) pos++;
                int finArgumento = pos; if (pos < rtf.Length && rtf[pos] == ' ') pos++;
                if (binario)
                {
                    if (!int.TryParse(rtf.AsSpan(argumento, finArgumento - argumento), out int bytes) || bytes < 0 || bytes > rtf.Length - pos) return false;
                    pos += bytes;
                }
            }
            else pos++;
        }
        return false;
    }

    private static bool Letra(char c) => c is >= 'a' and <= 'z' or >= 'A' and <= 'Z';
    private static bool Digito(char c) => c is >= '0' and <= '9';
    private static bool Hexadecimal(char c) => Digito(c) || c is >= 'a' and <= 'f' or >= 'A' and <= 'F';
    public void Dispose() => documento.TextChanged -= TextoCambiado;
}
