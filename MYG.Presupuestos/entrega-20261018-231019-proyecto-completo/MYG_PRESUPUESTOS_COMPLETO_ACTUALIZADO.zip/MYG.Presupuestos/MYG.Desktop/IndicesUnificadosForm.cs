using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGSelectorIndiceUnificadoForm : Form
{
    private readonly List<MYGIndiceUnificado> indices;
    private readonly TextBox buscar = new() { Dock = DockStyle.Fill, PlaceholderText = "Buscar por código o descripción…",
        AccessibleName = "Buscar índice unificado" };
    private readonly Label resultados = new() { Dock = DockStyle.Fill, AutoSize = true, Padding = new(0, 6, 0, 0),
        ForeColor = MYG2027_TemaComercial.Secundario };
    private readonly DataGridView tabla = new() { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, AllowUserToResizeRows = false, RowHeadersVisible = false,
        AutoGenerateColumns = false, MultiSelect = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        AccessibleName = "Catálogo de índices unificados INEI" };
    private readonly Button elegir;

    internal MYGIndiceUnificado Seleccion { get; private set; }

    internal MYGSelectorIndiceUnificadoForm(IEnumerable<MYGIndiceUnificado> indices, string actual = null)
    {
        this.indices = indices.ToList();
        MYGInsumosUI.Preparar(this, "Seleccionar índice unificado"); ClientSize = new(860, 590); MinimumSize = new(680, 450);
        var cabecera = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 1, Padding = new(18, 14, 18, 10) };
        cabecera.ColumnStyles.Add(new(SizeType.Percent, 100));
        cabecera.Controls.Add(new Label { Text = "Índices unificados de precios de la construcción", AutoSize = true,
            Dock = DockStyle.Fill, ForeColor = MYG2027_TemaComercial.Marino, Font = new("Segoe UI", 14, FontStyle.Bold) }, 0, 0);
        cabecera.Controls.Add(new Label { Text = "INEI · Base diciembre 2025 = 100 · Resolución Jefatural N.° 016-2026-INEI",
            Dock = DockStyle.Fill, AutoSize = true, Padding = new(0, 4, 0, 12), ForeColor = MYG2027_TemaComercial.Secundario }, 0, 1);
        cabecera.Controls.Add(buscar, 0, 2); cabecera.Controls.Add(resultados, 0, 3);
        for (int fila = 0; fila < 4; fila++) cabecera.RowStyles.Add(new(SizeType.AutoSize));
        tabla.Columns.Add(new DataGridViewTextBoxColumn { Name = "CODIGO", HeaderText = "Código I.U.", Width = 110,
            MinimumWidth = 90, SortMode = DataGridViewColumnSortMode.NotSortable });
        tabla.Columns.Add(new DataGridViewTextBoxColumn { Name = "DESCRIPCION", HeaderText = "Descripción oficial",
            AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, MinimumWidth = 280, SortMode = DataGridViewColumnSortMode.NotSortable });
        MYG2027_TemaComercial.EstilizarTabla(tabla);
        tabla.Columns["CODIGO"].DefaultCellStyle.Font = new("Segoe UI", 10, FontStyle.Bold);
        tabla.Columns["DESCRIPCION"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        tabla.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
        var contenedor = new Panel { Dock = DockStyle.Fill, Padding = new(18, 0, 18, 12) }; contenedor.Controls.Add(tabla);
        elegir = MYGInsumosUI.Boton("Usar índice", "aceptar"); MYG2027_TemaComercial.EstilizarBoton(elegir, 1);
        var cancelar = MYGInsumosUI.Boton("Cancelar", "cerrar"); MYG2027_TemaComercial.EstilizarBoton(cancelar); cancelar.DialogResult = DialogResult.Cancel;
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 56, Padding = new(8),
            BackColor = Color.White, FlowDirection = FlowDirection.RightToLeft };
        pie.Controls.Add(cancelar); pie.Controls.Add(elegir); Controls.Add(contenedor); Controls.Add(cabecera); Controls.Add(pie);
        AcceptButton = elegir; CancelButton = cancelar;
        elegir.Click += (s, e) => Aceptar();
        buscar.TextChanged += (s, e) => Filtrar();
        tabla.SelectionChanged += (s, e) => elegir.Enabled = tabla.CurrentRow?.Tag is MYGIndiceUnificado;
        tabla.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) Aceptar(); };
        Shown += (s, e) => buscar.Focus();
        Filtrar(actual);
    }

    private void Filtrar(string actual = null)
    {
        string anterior = actual ?? (tabla.CurrentRow?.Tag as MYGIndiceUnificado)?.ToString();
        string filtro = buscar.Text.Trim(); tabla.Rows.Clear();
        foreach (var indice in indices.Where(x => CultureInfo.CurrentCulture.CompareInfo.IndexOf(
            x.Codigo + " " + x.Descripcion, filtro, CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0))
            tabla.Rows[tabla.Rows.Add(indice.Codigo, indice.Descripcion)].Tag = indice;
        var fila = tabla.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => ((MYGIndiceUnificado)x.Tag).ToString() == anterior);
        if (fila != null) { tabla.CurrentCell = fila.Cells[0]; fila.Selected = true; }
        elegir.Enabled = tabla.CurrentRow?.Tag is MYGIndiceUnificado;
        resultados.Text = tabla.Rows.Count == 0 ? "No se encontraron índices. Pruebe otro código o descripción."
            : tabla.Rows.Count + " de " + indices.Count + " índices · Seleccione una fila y pulse «Usar índice».";
    }

    private void Aceptar()
    {
        if (tabla.CurrentRow?.Tag is not MYGIndiceUnificado indice) return;
        Seleccion = indice; DialogResult = DialogResult.OK;
    }
}
