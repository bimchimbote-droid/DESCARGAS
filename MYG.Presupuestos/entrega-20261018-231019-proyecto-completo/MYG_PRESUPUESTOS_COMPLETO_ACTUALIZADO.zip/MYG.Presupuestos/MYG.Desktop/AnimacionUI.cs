using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

internal static class MYGAnimacionUI
{
    private static readonly ConditionalWeakTable<WinForms.Button, TransicionBoton> botones = new();

    // Una transición por botón sirve tanto al dibujo comercial como al botón
    // nativo. El texto, el tamaño, el foco y los eventos de clic se conservan.
    internal static void PrepararBoton(WinForms.Button boton)
    {
        if (boton == null || boton.IsDisposed || boton.FlatStyle != WinForms.FlatStyle.Flat) return;
        botones.GetValue(boton, b => new TransicionBoton(b));
    }

    internal static void ActualizarColores(WinForms.Button boton)
    {
        if (botones.TryGetValue(boton, out var transicion)) transicion.ActualizarColores();
    }

    internal static Drawing.Color ColorActual(WinForms.Button boton, Drawing.Color alternativa)
        => botones.TryGetValue(boton, out var transicion) ? transicion.Color : alternativa;

    private sealed class TransicionBoton
    {
        private readonly WinForms.Button boton;
        private readonly WinForms.Timer reloj = new() { Interval = 16 };
        private readonly Stopwatch tiempo = new();
        private Drawing.Color normal, sobre, pulsado;
        private Drawing.Color desde, hasta;
        private bool encima, presionado, liberado;
        internal Drawing.Color Color { get; private set; }

        internal TransicionBoton(WinForms.Button boton)
        {
            this.boton = boton;
            ActualizarColores();
            boton.MouseEnter += Entrar; boton.MouseLeave += Salir;
            boton.MouseDown += Pulsar; boton.MouseUp += Soltar;
            boton.KeyDown += TeclaPulsada; boton.KeyUp += TeclaSoltada;
            boton.LostFocus += PerderFoco; boton.EnabledChanged += Habilitar;
            boton.VisibleChanged += Visibilidad; boton.HandleDestroyed += Detener;
            boton.Disposed += Liberar;
            reloj.Tick += Actualizar;
        }

        internal void ActualizarColores()
        {
            if (liberado) return;
            reloj.Stop(); tiempo.Reset();
            normal = boton.BackColor;
            sobre = boton.FlatAppearance.MouseOverBackColor.IsEmpty
                ? Mezclar(normal, MYG2027_TemaComercial.Azul, .09)
                : boton.FlatAppearance.MouseOverBackColor;
            pulsado = boton.FlatAppearance.MouseDownBackColor.IsEmpty
                ? Mezclar(normal, MYG2027_TemaComercial.Azul, .16)
                : boton.FlatAppearance.MouseDownBackColor;
            Pintar(Destino());
        }

        private Drawing.Color Destino() => !boton.Enabled || !boton.Visible ? normal
            : presionado ? pulsado : encima ? sobre : normal;
        private void Entrar(object sender, EventArgs e) { encima = true; Cambiar(Destino()); }
        private void Salir(object sender, EventArgs e) { encima = false; presionado = false; Cambiar(Destino()); }
        private void Pulsar(object sender, WinForms.MouseEventArgs e)
        { if (e.Button == WinForms.MouseButtons.Left) { presionado = true; Cambiar(Destino()); } }
        private void Soltar(object sender, WinForms.MouseEventArgs e)
        { if (e.Button == WinForms.MouseButtons.Left) { presionado = false; Cambiar(Destino()); } }
        private void TeclaPulsada(object sender, WinForms.KeyEventArgs e)
        { if (e.KeyCode == WinForms.Keys.Space && !presionado) { presionado = true; Cambiar(Destino()); } }
        private void TeclaSoltada(object sender, WinForms.KeyEventArgs e)
        { if (e.KeyCode == WinForms.Keys.Space) { presionado = false; Cambiar(Destino()); } }
        private void PerderFoco(object sender, EventArgs e) { presionado = false; Cambiar(Destino()); }
        private void Habilitar(object sender, EventArgs e)
        { if (!boton.Enabled) { presionado = false; encima = false; } Cambiar(Destino(), inmediato: true); }
        private void Visibilidad(object sender, EventArgs e)
        { presionado = false; encima = false; Cambiar(normal, inmediato: true); }
        private void Detener(object sender, EventArgs e)
        { reloj.Stop(); tiempo.Reset(); presionado = false; encima = false; Pintar(normal); }

        private void Cambiar(Drawing.Color destino, bool inmediato = false)
        {
            if (liberado || boton.IsDisposed || boton.Disposing) return;
            if (inmediato || !boton.Visible || !boton.IsHandleCreated ||
                !WinForms.SystemInformation.IsMenuAnimationEnabled || WinForms.SystemInformation.HighContrast ||
                WinForms.SystemInformation.TerminalServerSession)
            { reloj.Stop(); tiempo.Reset(); Pintar(destino); return; }
            if (Color == destino) { reloj.Stop(); return; }
            desde = Color; hasta = destino;
            tiempo.Restart(); reloj.Start();
        }

        private void Actualizar(object sender, EventArgs e)
        {
            if (liberado || boton.IsDisposed || boton.Disposing || !boton.Visible || !boton.IsHandleCreated)
            { reloj.Stop(); tiempo.Reset(); return; }
            if (!WinForms.SystemInformation.IsMenuAnimationEnabled || WinForms.SystemInformation.HighContrast ||
                WinForms.SystemInformation.TerminalServerSession)
            { reloj.Stop(); tiempo.Reset(); Pintar(hasta); return; }
            double progreso = Math.Min(1, tiempo.Elapsed.TotalMilliseconds / 140);
            Pintar(Mezclar(desde, hasta, progreso * progreso * (3 - 2 * progreso)));
            if (progreso >= 1) { reloj.Stop(); tiempo.Reset(); }
        }

        private void Pintar(Drawing.Color color)
        {
            Color = color;
            // El comercial mantiene su BackColor semántico. Los nativos usan
            // el mismo color en sus tres estados para evitar saltos de pintura.
            if (boton is not MYG2027_BotonComercial)
            {
                boton.BackColor = color;
                boton.FlatAppearance.MouseOverBackColor = color;
                boton.FlatAppearance.MouseDownBackColor = color;
            }
            boton.Invalidate();
        }

        private void Liberar(object sender, EventArgs e)
        {
            if (liberado) return;
            liberado = true;
            reloj.Stop(); reloj.Tick -= Actualizar; reloj.Dispose(); tiempo.Reset();
            boton.MouseEnter -= Entrar; boton.MouseLeave -= Salir;
            boton.MouseDown -= Pulsar; boton.MouseUp -= Soltar;
            boton.KeyDown -= TeclaPulsada; boton.KeyUp -= TeclaSoltada;
            boton.LostFocus -= PerderFoco; boton.EnabledChanged -= Habilitar;
            boton.VisibleChanged -= Visibilidad; boton.HandleDestroyed -= Detener;
            boton.Disposed -= Liberar;
            botones.Remove(boton);
        }
    }

    private static Drawing.Color Mezclar(Drawing.Color a, Drawing.Color b, double proporcion)
        => Drawing.Color.FromArgb(255, (int)Math.Round(a.R + (b.R - a.R) * proporcion),
            (int)Math.Round(a.G + (b.G - a.G) * proporcion), (int)Math.Round(a.B + (b.B - a.B) * proporcion));
}
