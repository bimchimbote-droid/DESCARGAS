using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly ToolStripDropDownButton resumenOpciones = new("Resumen") { Name = "resumenOpciones" };
    private readonly List<Image> iconosResumen = new();
    private ContextMenuStrip menuResumen;
    private readonly Dictionary<string, Font> fuentesFilasResumen = new();
    private readonly Dictionary<string, MYGEstiloFilaResumen> estilosVisiblesResumen = new();
    private const string FormatoPortapapelesResumen = "MYG.Presupuestos.Resumen.v1";

    private ToolStripMenuItem AccionResumen(ToolStripItemCollection destino, string nombre, string texto, string icono, Action accion)
    {
        var imagen = MYGResumenPieIconos.Crear(icono); iconosResumen.Add(imagen);
        var item = new ToolStripMenuItem(texto, imagen) { Name = nombre };
        item.Click += (_, _) => Intentar(accion);
        destino.Add(item); return item;
    }

    private Control PrepararOpcionesResumen()
    {
        var barra = new ToolStrip { Dock = DockStyle.Fill, GripStyle = ToolStripGripStyle.Hidden, Padding = new(0),
            ImageScalingSize = new(20, 20), AutoSize = false };
        resumenOpciones.Image = MYGResumenPieIconos.Crear("opciones"); iconosResumen.Add(resumenOpciones.Image);
        barra.Items.Add(resumenOpciones);
        AccionResumen(resumenOpciones.DropDownItems, "piePorPresupuesto", "Pie resumen por presupuesto", "resumen", () => CambiarAlcancePie(0));
        AccionResumen(resumenOpciones.DropDownItems, "piePorProyecto", "Pie resumen único por proyecto", "proyecto", () => CambiarAlcancePie(1));
        resumenOpciones.DropDownItems.Add(new ToolStripSeparator());
        AccionResumen(resumenOpciones.DropDownItems, "limpiarResumen", "Limpiar resumen", "limpiar", LimpiarResumenPie);
        resumenOpciones.DropDownOpening += (_, _) => ActualizarMenuResumen();
        Disposed += (_, _) =>
        {
            menuResumen?.Dispose(); alcancePie.Dispose();
            foreach (var imagen in iconosResumen) imagen.Dispose();
            foreach (var fuente in fuentesFilasResumen.Values) fuente.Dispose();
        };
        return barra;
    }

    private void CambiarAlcancePie(int indice)
    {
        // Confirmar antes de cambiar evita aplicar la celda en edición al otro alcance.
        FinalizarEdicion(); alcancePie.SelectedIndex = indice;
        ActualizarMenuResumen();
    }

    private static bool EsConceptoEditablePie(object etiqueta) => etiqueta is MYGConceptoPie || etiqueta is MYGFilaResumenPie;
    private static string IdFilaResumen(DataGridViewRow fila) => fila?.HeaderCell.Tag as string ?? (fila?.Tag switch
    {
        MYGFilaResumenPie f => f.Id,
        MYGConceptoPie c => c.ToString(),
        _ => fila?.Index == 0 ? MYGPiePresupuesto.IdCostoDirecto : null
    });

    private static bool PiesCompatibles(List<MYGPresupuestoDocumento> presupuestos)
    {
        if (presupuestos.Count == 0) return false;
        if (presupuestos.Any(MYGPiePresupuesto.EsPieDelphin))
        {
            if (!presupuestos.All(MYGPiePresupuesto.EsPieDelphin)) return false;
            string Estructura(MYGPresupuestoDocumento p) => JsonSerializer.Serialize(new
            {
                p.Costos.PieDelphin.ProyectoId, p.Costos.PieDelphin.UnicoPorProyecto,
                p.Costos.PieDelphin.NombreCostoDirecto, p.Costos.PieDelphin.Decimales,
                Filas = p.Costos.PieDelphin.Filas.Select(f => new { f.Clave, f.Nombre, f.Tipo, f.Posicion, f.Seccion, f.Formula })
            });
            string primera = Estructura(presupuestos[0]);
            return presupuestos.All(p => Estructura(p) == primera);
        }
        var primero = presupuestos[0].Costos.PiePersonalizado;
        return presupuestos.All(p => primero == null ? p.Costos.PiePersonalizado == null :
            p.Costos.PiePersonalizado != null && primero.Select(f => (f.Id, f.Nombre, f.Base, f.Tipo, f.Identificador, f.Modo, f.Formula))
                .SequenceEqual(p.Costos.PiePersonalizado.Select(f => (f.Id, f.Nombre, f.Base, f.Tipo, f.Identificador, f.Modo, f.Formula))));
    }

    private void PrepararMenuResumen()
    {
        menuResumen = new ContextMenuStrip { ShowImageMargin = true, ImageScalingSize = new(20, 20) };
        tablaPie.ContextMenuStrip = menuResumen;
        AccionResumen(menuResumen.Items, "agregarFilaResumen", "Agregar fila bajo la selección", "insertar_final", AgregarFilaResumenPie);
        AccionResumen(menuResumen.Items, "editarFilaResumen", "Editar fila", "editar", EditarFilaResumenPie);
        AccionResumen(menuResumen.Items, "eliminarFilaResumen", "Eliminar fila", "eliminar", EliminarFilaResumenPie);
        AccionResumen(menuResumen.Items, "subirFilaResumen", "Subir", "arriba", () => MoverFilaResumenPie(-1));
        AccionResumen(menuResumen.Items, "bajarFilaResumen", "Bajar", "abajo", () => MoverFilaResumenPie(1));
        menuResumen.Items.Add(new ToolStripSeparator());
        AccionResumen(menuResumen.Items, "copiarResumen", "Copiar resumen", "copiar", CopiarResumenPie);
        AccionResumen(menuResumen.Items, "pegarResumen", "Pegar resumen", "pegar", PegarResumenPie);
        menuResumen.Items.Add(new ToolStripSeparator());
        AccionResumen(menuResumen.Items, "limpiarResumenContextual", "Limpiar resumen", "limpiar", LimpiarResumenPie);
        AccionResumen(menuResumen.Items, "restaurarResumen", "Mostrar Resumen predeterminado", "restaurar", RestaurarResumenPie);
        AccionResumen(menuResumen.Items, "fuenteResumen", "Fuente", "fuente", FuenteResumenPie);
        menuResumen.Opening += (_, _) => ActualizarMenuResumen();
        tablaPie.CellMouseDown += (_, e) =>
        {
            if (e.Button != MouseButtons.Right) return;
            // La validación de la celda previa debe terminar antes de mover la selección.
            Intentar(() =>
            {
                FinalizarEdicion(); tablaPie.ClearSelection();
                if (e.RowIndex < 0) { tablaPie.CurrentCell = null; return; }
                tablaPie.CurrentCell = tablaPie.Rows[e.RowIndex].Cells[Math.Max(0, e.ColumnIndex)];
                tablaPie.Rows[e.RowIndex].Selected = true;
            });
        };
        tablaPie.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0 && e.ColumnIndex == 0) Intentar(EditarFilaResumenPie); };
    }

    private void ActualizarMenuResumen()
    {
        var presupuestos = AlcancePie(); bool hay = presupuestos.Count > 0;
        bool compatibles = PiesCompatibles(presupuestos);
        bool personalizado = hay && presupuestos.All(p => p.Costos.PiePersonalizado != null);
        bool algunoPersonalizado = presupuestos.Any(p => p.Costos.PiePersonalizado != null);
        bool nativo = presupuestos.Any(MYGPiePresupuesto.EsPieDelphin);
        bool autorizado = autorizarCatalogos?.Invoke() == true;
        if (resumenOpciones.DropDownItems["piePorPresupuesto"] is ToolStripMenuItem individual)
            individual.Checked = alcancePie.SelectedIndex == 0;
        if (resumenOpciones.DropDownItems["piePorProyecto"] is ToolStripMenuItem proyecto)
            proyecto.Checked = alcancePie.SelectedIndex == 1;
        if (resumenOpciones.DropDownItems["limpiarResumen"] is ToolStripMenuItem limpiar)
        {
            limpiar.Enabled = hay && autorizado && !nativo;
            limpiar.ToolTipText = nativo ? "El resumen conserva fórmulas y valores nativos de Delphin. Edite sus porcentajes sin sustituir su estructura." : "";
        }
        if (menuResumen == null) return;
        void Estado(string nombre, bool habilitado, bool visible = true)
        { menuResumen.Items[nombre].Enabled = habilitado; menuResumen.Items[nombre].Visible = visible; }
        var fila = tablaPie.CurrentRow?.Tag as MYGFilaResumenPie;
        int indice = fila == null || !personalizado ? -1 : presupuestos[0].Costos.PiePersonalizado.FindIndex(f => f.Id == fila.Id);
        bool costoDirecto = IdFilaResumen(tablaPie.CurrentRow) == MYGPiePresupuesto.IdCostoDirecto;
        bool editable = hay && (nativo ? compatibles && fila?.Editable == true :
            costoDirecto || compatibles && (tablaPie.CurrentRow?.Tag is MYGConceptoPie || indice >= 0));
        menuResumen.Items["editarFilaResumen"].Text = costoDirecto ? "Editar Fila" : "Editar fila";
        Estado("agregarFilaResumen", personalizado && compatibles && autorizado, personalizado);
        Estado("editarFilaResumen", editable && autorizado);
        Estado("eliminarFilaResumen", personalizado && compatibles && indice >= 0 && autorizado);
        Estado("subirFilaResumen", personalizado && compatibles && indice > 0 && autorizado);
        Estado("bajarFilaResumen", personalizado && compatibles && indice >= 0 && indice < presupuestos[0].Costos.PiePersonalizado.Count - 1 && autorizado);
        Estado("copiarResumen", hay && ContenidosResumen(presupuestos).Count == 1);
        bool puedePegar;
        try
        {
            puedePegar = Clipboard.ContainsData(FormatoPortapapelesResumen);
            if (puedePegar)
            {
                Clipboard.TryGetData<string>(FormatoPortapapelesResumen, out string contenido);
                puedePegar = contenido?.Length <= 2000000 && PuedePegarResumen(presupuestos, JsonSerializer.Deserialize<ResumenCopiado>(contenido));
            }
        }
        catch (Exception ex) when (ex is System.Runtime.InteropServices.ExternalException or JsonException or ArgumentNullException)
        { puedePegar = false; }
        Estado("pegarResumen", hay && autorizado && puedePegar);
        Estado("limpiarResumenContextual", hay && autorizado && !nativo, !personalizado);
        Estado("restaurarResumen", hay && autorizado && !nativo, algunoPersonalizado);
        Estado("fuenteResumen", hay && tablaPie.CurrentRow != null && autorizado);
    }

    private void CambiarResumenPie(Action<List<MYGPresupuestoDocumento>> accion)
    {
        RequerirPermisoCatalogos(); FinalizarEdicion();
        var destino = AlcancePie();
        if (destino.Count == 0) throw new InvalidOperationException("Seleccione un presupuesto.");
        // Ningún fallo de validación deja cambios parciales ni entradas de historial.
        var copias = destino.Select(MYGProyectoStorage.Copia).ToList(); accion(copias);
        MYGPiePresupuesto.Moneda(copias);
        foreach (var copia in copias) { MYGProyectoStorage.ValidarPresupuesto(copia); MYGMotorPresupuestos.Resumen(copia); }
        if (destino.Select(p => JsonSerializer.Serialize(p.Costos)).SequenceEqual(copias.Select(p => JsonSerializer.Serialize(p.Costos)))) return;
        antes();
        for (int n = 0; n < destino.Count; n++)
        {
            destino[n].Costos.PiePersonalizado = copias[n].Costos.PiePersonalizado;
            destino[n].Costos.PieDelphin = copias[n].Costos.PieDelphin;
            destino[n].Costos.GastosGeneralesPorcentaje = copias[n].Costos.GastosGeneralesPorcentaje;
            destino[n].Costos.UtilidadPorcentaje = copias[n].Costos.UtilidadPorcentaje;
            destino[n].Costos.ImpuestoPorcentaje = copias[n].Costos.ImpuestoPorcentaje;
            destino[n].Costos.OtrosImpuestosPorcentaje = copias[n].Costos.OtrosImpuestosPorcentaje;
            destino[n].Costos.ConfiguracionCostoDirecto = copias[n].Costos.ConfiguracionCostoDirecto;
            destino[n].Costos.EstilosFilasResumen = copias[n].Costos.EstilosFilasResumen;
        }
        Cambiado(); RefrescarPiePresupuesto();
    }

    private void LimpiarResumenPie()
    {
        if (!AlcancePie().Any(MYGPiePresupuesto.EsPieDelphin)) CambiarResumenPie(MYGPiePresupuesto.Limpiar);
    }
    private void RestaurarResumenPie()
    {
        if (!AlcancePie().Any(MYGPiePresupuesto.EsPieDelphin)) CambiarResumenPie(MYGPiePresupuesto.RestaurarPredeterminado);
    }

    private static void AplicarPorcentajeFilaPie(List<MYGPresupuestoDocumento> destino, object etiqueta, decimal porcentaje)
    {
        if (etiqueta is MYGConceptoPie concepto) { MYGPiePresupuesto.AplicarPorcentaje(destino, concepto, porcentaje); return; }
        var fila = (MYGFilaResumenPie)etiqueta;
        if (destino.All(MYGPiePresupuesto.EsPieDelphin))
        { MYGPiePresupuesto.AplicarPorcentajeDelphin(destino, fila.Id, porcentaje); return; }
        foreach (var p in destino)
        {
            var filas = MYGProyectoStorage.Copia(p.Costos.PiePersonalizado);
            var editable = filas?.FirstOrDefault(f => f.Id == fila.Id) ?? throw new InvalidOperationException("La fila ya no existe en este resumen.");
            if (!MYGPiePresupuesto.EsPorcentual(editable)) throw new InvalidOperationException("Esta fila se edita desde Editar fila.");
            editable.Porcentaje = porcentaje;
            MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, filas);
        }
    }

    private void RequerirPiePersonalizadoCompatible()
    {
        var presupuestos = AlcancePie();
        if (!PiesCompatibles(presupuestos) || presupuestos.Any(p => p.Costos.PiePersonalizado == null))
            throw new InvalidOperationException("Limpie el resumen o seleccione un presupuesto con pie personalizado para editar sus filas.");
    }

    private void AgregarFilaResumenPie()
    {
        RequerirPermisoCatalogos(); FinalizarEdicion(); RequerirPiePersonalizadoCompatible();
        string despuesId = (tablaPie.CurrentRow?.Tag as MYGFilaResumenPie)?.Id;
        bool agregarAlFinal = IdFilaResumen(tablaPie.CurrentRow) == MYGPiePresupuesto.IdTotal;
        using var editor = new MYGEditarFilaResumenForm(new MYGFilaPiePersonalizada { Nombre = "", Identificador = "" },
            presupuestos: AlcancePie(), insertarDespuesId: agregarAlFinal ? MYGPiePresupuesto.IdTotal : despuesId, nueva: true);
        if (editor.ShowDialog(this) != DialogResult.OK) return;
        CambiarResumenPie(destino =>
        {
            foreach (var p in destino)
            {
                var filas = MYGProyectoStorage.Copia(p.Costos.PiePersonalizado);
                int indice = despuesId == null ? -1 : filas.FindIndex(f => f.Id == despuesId);
                // Seleccionar Total agrega al final; seleccionar Costo directo agrega al inicio.
                if (agregarAlFinal) indice = filas.Count - 1;
                filas.Insert(indice + 1, MYGProyectoStorage.Copia(editor.Valor));
                MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, filas);
            }
        });
    }

    private void EditarFilaResumenPie()
    {
        RequerirPermisoCatalogos(); FinalizarEdicion();
        if (AlcancePie().Any(MYGPiePresupuesto.EsPieDelphin))
        {
            if (PiesCompatibles(AlcancePie()) && tablaPie.CurrentRow?.Tag is MYGFilaResumenPie { Editable: true })
            {
                tablaPie.CurrentCell = tablaPie.CurrentRow.Cells["PORC"];
                tablaPie.BeginEdit(true);
            }
            return;
        }
        if (IdFilaResumen(tablaPie.CurrentRow) == MYGPiePresupuesto.IdCostoDirecto)
        {
            var presupuestos = AlcancePie();
            if (presupuestos.Count == 0) return;
            using var editorCosto = new MYGConfigurarCostoDirectoForm(presupuestos[0].Costos.ConfiguracionCostoDirecto);
            if (editorCosto.ShowDialog(this) == DialogResult.OK)
                CambiarResumenPie(destino => MYGPiePresupuesto.ConfigurarCostoDirecto(destino, editorCosto.Valor));
            return;
        }
        object seleccion = tablaPie.CurrentRow?.Tag;
        if (!PiesCompatibles(AlcancePie()) || !EsConceptoEditablePie(seleccion)) return;
        if (seleccion is MYGConceptoPie concepto)
        {
            var valores = AlcancePie().Select(p => MYGPiePresupuesto.Porcentaje(p, concepto)).Distinct().ToList();
            using var editor = new MYGEditarFilaResumenForm(new MYGFilaPiePersonalizada
                { Nombre = Convert.ToString(tablaPie.CurrentRow.Cells["CONCEPTO"].Value), Porcentaje = valores[0] }, true, valores.Count > 1);
            if (editor.ShowDialog(this) == DialogResult.OK)
                CambiarResumenPie(destino => MYGPiePresupuesto.AplicarPorcentaje(destino, concepto, editor.Valor.Porcentaje));
            return;
        }
        RequerirPiePersonalizadoCompatible();
        var seleccionada = (MYGFilaResumenPie)seleccion;
        var original = AlcancePie()[0].Costos.PiePersonalizado.First(f => f.Id == seleccionada.Id);
        bool varios = AlcancePie().Select(p => p.Costos.PiePersonalizado.First(f => f.Id == seleccionada.Id))
            .Select(f => (f.Porcentaje, f.ValorManual)).Distinct().Count() > 1;
        using var formulario = new MYGEditarFilaResumenForm(original, false, varios, presupuestos: AlcancePie());
        if (formulario.ShowDialog(this) != DialogResult.OK) return;
        CambiarResumenPie(destino =>
        {
            foreach (var p in destino)
            {
                var filas = MYGProyectoStorage.Copia(p.Costos.PiePersonalizado);
                filas[filas.FindIndex(f => f.Id == seleccionada.Id)] = MYGProyectoStorage.Copia(formulario.Valor);
                MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, filas);
            }
        });
    }

    private void EliminarFilaResumenPie() => ModificarOrdenResumenPie(null);
    private void MoverFilaResumenPie(int direccion) => ModificarOrdenResumenPie(direccion);
    private void ModificarOrdenResumenPie(int? direccion)
    {
        RequerirPermisoCatalogos(); FinalizarEdicion(); RequerirPiePersonalizadoCompatible();
        string id = (tablaPie.CurrentRow?.Tag as MYGFilaResumenPie)?.Id;
        if (id == null) return;
        CambiarResumenPie(destino =>
        {
            foreach (var p in destino)
            {
                var filas = MYGProyectoStorage.Copia(p.Costos.PiePersonalizado); int indice = filas.FindIndex(f => f.Id == id);
                if (indice < 0) throw new InvalidOperationException("La fila ya no existe.");
                if (!direccion.HasValue) filas.RemoveAt(indice);
                else
                {
                    int nuevo = indice + direccion.Value;
                    if (nuevo < 0 || nuevo >= filas.Count) continue;
                    (filas[indice], filas[nuevo]) = (filas[nuevo], filas[indice]);
                }
                MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, filas);
            }
        });
    }

    private sealed class ResumenCopiado
    {
        public ResumenCopiado() { }
        public int Version { get; set; } = 1;
        public decimal Gastos { get; set; }
        public decimal Utilidad { get; set; }
        public decimal Impuesto { get; set; }
        public decimal Otros { get; set; }
        [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingDefault)]
        public bool MostrarTotalPiePersonalizado { get; set; }
        public List<MYGFilaPiePersonalizada> Filas { get; set; }
        public MYGConfiguracionPieDelphin PieDelphin { get; set; }
        public MYGConfiguracionCostoDirecto CostoDirecto { get; set; }
        public Dictionary<string, MYGEstiloFilaResumen> Estilos { get; set; }
    }
    private static ResumenCopiado CapturarResumen(MYGPresupuestoDocumento p) => new()
    { Gastos = p.Costos.GastosGeneralesPorcentaje, Utilidad = p.Costos.UtilidadPorcentaje,
        Impuesto = p.Costos.ImpuestoPorcentaje, Otros = p.Costos.OtrosImpuestosPorcentaje, Filas = MYGProyectoStorage.Copia(p.Costos.PiePersonalizado),
        PieDelphin = MYGProyectoStorage.Copia(p.Costos.PieDelphin),
        MostrarTotalPiePersonalizado = p.Costos.MostrarTotalPiePersonalizado,
        CostoDirecto = MYGProyectoStorage.Copia(p.Costos.ConfiguracionCostoDirecto), Estilos = MYGProyectoStorage.Copia(p.Costos.EstilosFilasResumen) };

    private static List<string> ContenidosResumen(List<MYGPresupuestoDocumento> presupuestos)
    {
        var origen = MYGPiePresupuesto.EsPieUnicoDelphin(presupuestos)
            ? presupuestos.OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.OrdinalIgnoreCase).Take(1)
            : presupuestos.AsEnumerable();
        return origen.Select(p => JsonSerializer.Serialize(CapturarResumen(p))).Distinct().ToList();
    }

    private static bool PuedePegarResumen(List<MYGPresupuestoDocumento> destino, ResumenCopiado copiado)
    {
        if (copiado == null || copiado.Version != 1) return false;
        if (copiado.PieDelphin == null) return !destino.Any(MYGPiePresupuesto.EsPieDelphin);
        // Los IDs de titulo_pie pertenecen a su presupuesto SQLite. Copiar un
        // resumen modifica sus valores, conservando la identidad de cada destino.
        return copiado.Filas == null && copiado.PieDelphin.Filas != null && destino.All(p =>
            MYGPiePresupuesto.EsPieDelphin(p) && p.Costos.PieDelphin.Filas.Select(f => f.Clave)
                .SequenceEqual(copiado.PieDelphin.Filas.Select(f => f.Clave), StringComparer.OrdinalIgnoreCase));
    }

    private void CopiarResumenPie()
    {
        FinalizarEdicion(); var presupuestos = AlcancePie();
        var contenidos = ContenidosResumen(presupuestos);
        if (contenidos.Count != 1) throw new InvalidOperationException("Seleccione un presupuesto para copiar su resumen; los pies del proyecto son diferentes.");
        var datos = new DataObject(); datos.SetData(FormatoPortapapelesResumen, contenidos[0]); Clipboard.SetDataObject(datos, true);
    }

    private void PegarResumenPie()
    {
        RequerirPermisoCatalogos(); FinalizarEdicion();
        Clipboard.TryGetData<string>(FormatoPortapapelesResumen, out string texto);
        if (texto == null || texto.Length > 2000000) throw new InvalidOperationException("Copie primero un resumen MYG válido.");
        var copiado = JsonSerializer.Deserialize<ResumenCopiado>(texto);
        if (copiado == null || copiado.Version != 1) throw new InvalidOperationException("El resumen copiado no es compatible.");
        if (!PuedePegarResumen(AlcancePie(), copiado)) return;
        if (copiado.PieDelphin == null)
            foreach (decimal porcentaje in new[] { copiado.Gastos, copiado.Utilidad, copiado.Impuesto, copiado.Otros })
                if (porcentaje < 0 || porcentaje > 10000 || decimal.Round(porcentaje, 4) != porcentaje)
                    throw new InvalidOperationException("El resumen copiado contiene un porcentaje inválido.");
        CambiarResumenPie(destino =>
        {
            var piesPropios = destino.Select(p => p.Costos.PieDelphin).ToArray();
            foreach (var p in destino)
            {
                p.Costos.ConfiguracionCostoDirecto = MYGProyectoStorage.Copia(copiado.CostoDirecto);
                p.Costos.EstilosFilasResumen = MYGProyectoStorage.Copia(copiado.Estilos);
            }
            MYGPiePresupuesto.EstablecerPersonalizado(destino, copiado.Filas);
            for (int indice = 0; indice < destino.Count; indice++)
            {
                var p = destino[indice];
                p.Costos.PieDelphin = MYGProyectoStorage.Copia(copiado.PieDelphin);
                if (p.Costos.PieDelphin != null)
                {
                    p.Costos.PieDelphin.ProyectoId = piesPropios[indice].ProyectoId;
                    p.Costos.PieDelphin.UnicoPorProyecto = piesPropios[indice].UnicoPorProyecto;
                    foreach (var fila in p.Costos.PieDelphin.Filas)
                        fila.IdTitulo = piesPropios[indice].Filas.First(f => f.Clave.Equals(fila.Clave, StringComparison.OrdinalIgnoreCase)).IdTitulo;
                }
                p.Costos.GastosGeneralesPorcentaje = copiado.Gastos; p.Costos.UtilidadPorcentaje = copiado.Utilidad;
                p.Costos.ImpuestoPorcentaje = copiado.Impuesto; p.Costos.OtrosImpuestosPorcentaje = copiado.Otros;
                p.Costos.MostrarTotalPiePersonalizado = copiado.MostrarTotalPiePersonalizado;
            }
        });
    }

    private void FuenteResumenPie()
    {
        RequerirPermisoCatalogos(); FinalizarEdicion();
        var fila = tablaPie.CurrentRow;
        string id = IdFilaResumen(fila);
        if (id == null) return;
        var estilo = fila.Cells["CONCEPTO"].InheritedStyle;
        // El porcentaje de lectura es local: el diálogo edita el tamaño del
        // documento, no el tamaño temporal con el que se muestra en pantalla.
        using var dialogo = new MYGFuenteResumenForm(MYGTamanoTextoUI.FuenteOriginal(estilo.Font ?? tablaPie.Font),
            estilo.ForeColor, estilo.BackColor);
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        var fuente = dialogo.FuenteElegida;
        var formato = new MYGEstiloFilaResumen { Fuente = fuente.FontFamily.Name, Tamano = (decimal)fuente.SizeInPoints,
            Negrita = fuente.Bold, Cursiva = fuente.Italic, Tachado = fuente.Strikeout, Subrayado = fuente.Underline,
            ColorTexto = "#" + (dialogo.ColorTexto.ToArgb() & 0xffffff).ToString("X6"),
            ColorFondo = "#" + (dialogo.ColorFondo.ToArgb() & 0xffffff).ToString("X6") };
        CambiarResumenPie(destino =>
        {
            foreach (var p in destino)
            {
                p.Costos.EstilosFilasResumen ??= new();
                p.Costos.EstilosFilasResumen[id] = MYGProyectoStorage.Copia(formato);
            }
        });
    }

    private void PrepararFormatosFilasResumen(List<MYGPresupuestoDocumento> presupuestos)
    {
        foreach (var fuente in fuentesFilasResumen.Values) fuente.Dispose();
        fuentesFilasResumen.Clear(); estilosVisiblesResumen.Clear();
        if (presupuestos.Count == 0 || presupuestos[0].Costos.EstilosFilasResumen == null) return;
        foreach (var par in presupuestos[0].Costos.EstilosFilasResumen)
        {
            string formato = JsonSerializer.Serialize(par.Value);
            if (presupuestos.Any(p => p.Costos.EstilosFilasResumen == null ||
                !p.Costos.EstilosFilasResumen.TryGetValue(par.Key, out var otro) || JsonSerializer.Serialize(otro) != formato)) continue;
            var e = par.Value;
            var estilo = (e.Negrita ? FontStyle.Bold : FontStyle.Regular) | (e.Cursiva ? FontStyle.Italic : FontStyle.Regular) |
                (e.Tachado ? FontStyle.Strikeout : FontStyle.Regular) | (e.Subrayado ? FontStyle.Underline : FontStyle.Regular);
            fuentesFilasResumen[par.Key] = new Font(e.Fuente, (float)e.Tamano, estilo, GraphicsUnit.Point);
            estilosVisiblesResumen[par.Key] = e;
        }
    }

    private void AplicarFormatoFilaResumen(DataGridViewRow fila, DataGridViewCellStyle estilo)
    {
        string id = IdFilaResumen(fila);
        if (id == null || !estilosVisiblesResumen.TryGetValue(id, out var formato)) return;
        estilo.Font = fuentesFilasResumen[id];
        estilo.ForeColor = ColorTranslator.FromHtml(formato.ColorTexto);
        estilo.BackColor = ColorTranslator.FromHtml(formato.ColorFondo);
    }
}
