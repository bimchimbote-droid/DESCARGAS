# Iconos de MYG Presupuestos

Estos 33 iconos son dibujos originales creados para MYG. Los archivos PNG tienen
32 × 32 píxeles y fondo transparente; no requieren bibliotecas adicionales para
ejecutar el programa.

`MYGIconos.Obtener("editar")` carga `Iconos/editar.png` junto al ejecutable. Si el
archivo no existe, está dañado o no se puede leer, utiliza el mismo icono
incrustado en el ensamblado. Cada llamada devuelve una imagen independiente que
el control debe liberar cuando se cierre. El proyecto copia los PNG a las
carpetas de compilación y publicación, y también los incrusta como respaldo.

Si el recurso incrustado también falta o está dañado, el cargador genera un
icono básico en memoria para que el editor pueda abrirse. Para recuperar los
dibujos originales, copie los PNG a `MYG.Desktop/Iconos`, conserve el `.csproj`
actualizado y vuelva a compilar. La carpeta `Iconos` se copia junto al ejecutable.

Para personalizar un icono, conserve su nombre de archivo y sustitúyalo en la
carpeta `Iconos` junto al ejecutable. Use PNG con transparencia, preferiblemente
de 32 × 32 píxeles. Para incorporar el cambio de forma permanente, sustituya el
archivo de esta carpeta en el proyecto y vuelva a compilar.

Los nombres utilizados son: `guardar`, `agregar`, `titulo`, `partida`, `catalogo`,
`editar`, `eliminar`, `proyecto`, `excel`, `imprimir`, `resumen`, `insumos`,
`unidades`, `especificacion`, `deshacer`, `rehacer`, `bim`, `sesion`, `arriba`,
`abajo`, `expandir`, `contraer`, `insertar_sobre`, `insertar_final`, `recalcular`,
`codigo_estandar`, `codigo_alterno`, `buscar`, `aceptar`, `cerrar`, `acu`, `imagen`
y `marca`.

Puede regenerar los originales ejecutando `python scripts/Generar-Iconos.py`
desde la raíz del repositorio. Esta herramienta de desarrollo requiere Python 3
y Pillow; Visual Studio y la aplicación no necesitan Python ni Pillow.
