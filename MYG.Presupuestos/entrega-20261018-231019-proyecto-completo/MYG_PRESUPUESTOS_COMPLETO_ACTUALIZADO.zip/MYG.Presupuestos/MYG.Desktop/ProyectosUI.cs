using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGProyectosUI
{
    internal static string Elegir(IWin32Window propietario, string ruta)
        => Elegir(propietario, ruta, MYGBaseDatos.ListarProyectos(ruta));

    internal static string Elegir(IWin32Window propietario, string ruta, List<MYGProyectoResumen> proyectos)
    {
        if (proyectos.Count == 0) throw new InvalidDataException("Esta base todavía no tiene proyectos. Créelos desde la ventana principal.");
        if (proyectos.Count == 1) return proyectos[0].Id;
        using var f = new Form(); MYGProyectoUI.Preparar(f, "Elegir proyecto", 650, 440);
        var lista = new ListBox { Dock = DockStyle.Fill, DataSource = proyectos, DisplayMember = nameof(MYGProyectoResumen.Nombre), IntegralHeight = false };
        var aceptar = MYGProyectoUI.Boton("Abrir proyecto", 1); aceptar.DialogResult = DialogResult.OK;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        var titulo = new Label { Text = "Proyectos de " + Path.GetFileName(ruta), Dock = DockStyle.Top, Height = 44 };
        f.Padding = new Padding(20); f.Controls.Add(lista); f.Controls.Add(titulo); f.Controls.Add(MYGBibliotecaUI.Pie(aceptar, cancelar));
        lista.DoubleClick += (s, e) => { if (lista.SelectedItem != null) f.DialogResult = DialogResult.OK; };
        f.AcceptButton = aceptar; f.CancelButton = cancelar;
        return f.ShowDialog(propietario) == DialogResult.OK ? (lista.SelectedItem as MYGProyectoResumen)?.Id : null;
    }
}
