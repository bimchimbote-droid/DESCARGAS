using System;
using System.Linq;
using System.Threading.Tasks;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private async Task EjecutarAccionBarraEstructura(string comando, object contexto)
    {
        if (ocupado) return;
        string presupuestoId = PropietarioEstructura(contexto)?.Id;
        string partidaId = (contexto as ItemPresupuestoDelphin)?.Id;
        await Ejecutar(() =>
        {
            // La verificación de sesión y la edición pendiente pueden reemplazar
            // los objetos. Resolver por identidad antes de reutilizar los comandos.
            var propietario = documento.Presupuestos.FirstOrDefault(p => p.Id == presupuestoId);
            object vigente = partidaId == null ? propietario : propietario?.Items.FirstOrDefault(i => i.Id == partidaId);
            if (contexto != null && vigente == null)
                throw new InvalidOperationException("La fila seleccionada ya no existe. Seleccione nuevamente el presupuesto, título o partida.");
            switch (comando)
            {
                case "eliminar":
                    if (vigente != null) EliminarEstructura(vigente);
                    break;
                case "copiar":
                    if (vigente != null) CopiarEstructura(vigente);
                    break;
                case "pegar":
                    PegarEstructura(vigente, true);
                    break;
                case "recalcular":
                    MYGProyectoStorage.Validar(documento);
                    Refrescar();
                    if (vigente != null) panelPresupuesto.SeleccionarEstructura(vigente);
                    estado.Text = "Importes recalculados. Se conservan las cantidades, fórmulas y datos del presupuesto.";
                    break;
                default:
                    throw new ArgumentException("Herramienta del presupuesto desconocida.", nameof(comando));
            }
            return Task.CompletedTask;
        }, necesitaLicencia: comando is "eliminar" or "pegar");
    }
}
