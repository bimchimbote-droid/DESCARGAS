using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGCronogramaDialogoUI
{
    internal static void Preparar(Form formulario, string nombre, string titulo, Size tamano, bool redimensionable = false)
    {
        formulario.Name = nombre;
        formulario.Text = titulo;
        formulario.ClientSize = tamano;
        formulario.Font = new Font("Segoe UI", 9F);
        formulario.AutoScaleMode = AutoScaleMode.Font;
        formulario.StartPosition = FormStartPosition.CenterParent;
        formulario.FormBorderStyle = redimensionable ? FormBorderStyle.Sizable : FormBorderStyle.FixedDialog;
        formulario.MaximizeBox = redimensionable;
        formulario.MinimizeBox = false;
        formulario.ShowInTaskbar = false;
        formulario.Shown += (_, _) => MYG2027_TemaComercial.AjustarAlAreaDeTrabajo(formulario);
    }

    internal static TableLayoutPanel Tabla()
    {
        var tabla = new TableLayoutPanel
        {
            Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 2, Padding = new Padding(14, 12, 14, 8)
        };
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 135));
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        return tabla;
    }

    internal static void Campo(TableLayoutPanel tabla, string etiqueta, Control control, int alto = 36)
    {
        int fila = tabla.RowCount++;
        tabla.RowStyles.Add(new RowStyle(SizeType.Absolute, alto));
        tabla.Controls.Add(new Label
        {
            Text = etiqueta, AutoSize = true, Anchor = AnchorStyles.Left,
            Margin = new Padding(0, 3, 8, 3)
        }, 0, fila);
        control.Dock = DockStyle.Fill;
        control.Margin = new Padding(3, 4, 3, 4);
        tabla.Controls.Add(control, 1, fila);
    }

    internal static Label Error(string prefijo) => new()
    {
        Name = prefijo + "_error", Dock = DockStyle.Bottom, Height = 48,
        Padding = new Padding(16, 4, 16, 4), AutoEllipsis = true, AccessibleName = "Resultado de la validación"
    };

    internal static void Botones(Form formulario, string prefijo, Label error, Action aceptar)
    {
        var pie = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom, Height = 50, Padding = new Padding(12, 7, 12, 7),
            FlowDirection = FlowDirection.RightToLeft, WrapContents = false
        };
        var cancelar = new Button
        {
            Name = prefijo + "_cancelar", Text = "Cancelar", DialogResult = DialogResult.Cancel,
            AutoSize = true, MinimumSize = new Size(90, 30)
        };
        var aplicar = new Button
        {
            Name = prefijo + "_aceptar", Text = "Aceptar", AutoSize = true, MinimumSize = new Size(90, 30)
        };
        aplicar.Click += (_, _) =>
        {
            try
            {
                error.Text = "";
                aceptar();
                formulario.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                error.ForeColor = Color.Firebrick;
                error.Text = ex.Message;
            }
        };
        pie.Controls.Add(cancelar);
        pie.Controls.Add(aplicar);
        formulario.Controls.Add(error);
        formulario.Controls.Add(pie);
        formulario.AcceptButton = aplicar;
        formulario.CancelButton = cancelar;
    }

    internal static void Tema(Form formulario)
    {
        void Cambiar(object sender, EventArgs e)
        {
            MYG2027_TemaComercial.Aplicar(formulario);
            if (formulario.AcceptButton is Button aceptar) MYG2027_TemaComercial.EstilizarBoton(aceptar, 1);
            formulario.Invalidate(true);
        }
        Cambiar(null, EventArgs.Empty);
        MYG2027_TemaComercial.CambioTema += Cambiar;
        formulario.Disposed += (_, _) => MYG2027_TemaComercial.CambioTema -= Cambiar;
    }

    internal static DateTimePicker Fecha(string nombre, DateTime fecha) => new()
    {
        Name = nombre, Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy",
        Value = fecha < DateTimePicker.MinimumDateTime ? DateTimePicker.MinimumDateTime :
            fecha > DateTimePicker.MaximumDateTime ? DateTimePicker.MaximumDateTime : fecha.Date
    };

    internal static List<string> LeerNombres(string texto)
    {
        var nombres = (texto ?? "").Split(new[] { '\r', '\n', ';' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => x.Trim()).Where(x => x.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (nombres.Any(x => x.Length > 160))
            throw new InvalidOperationException("Cada responsable puede tener hasta 160 caracteres.");
        return nombres;
    }
}

internal sealed class MYGTareaCronogramaDialog : Form
{
    internal MYGTareaCronograma Valor { get; private set; }

    internal MYGTareaCronogramaDialog(MYGTareaCronograma tarea, IReadOnlyList<MYGResultadoTarea> filas,
        IReadOnlyList<string> responsablesDisponibles = null, MYGCalendarioTrabajo calendario = null)
    {
        ArgumentNullException.ThrowIfNull(tarea);
        if (tarea.EsResumen) throw new ArgumentException("Las fechas y el avance de los resúmenes se calculan a partir de sus tareas.", nameof(tarea));
        var original = MYGProyectoStorage.Copia(tarea);
        var calendarioTrabajo = MYGProyectoStorage.Copia(calendario ?? new MYGCalendarioTrabajo());
        Valor = MYGProyectoStorage.Copia(tarea);
        filas ??= Array.Empty<MYGResultadoTarea>();
        MYGCronogramaDialogoUI.Preparar(this, "cronograma_tarea_dialogo", "Información de la tarea", new Size(710, 662));
        var cuerpo = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        var tabla = MYGCronogramaDialogoUI.Tabla();
        var error = MYGCronogramaDialogoUI.Error("cronograma_tarea");
        var nombre = new TextBox { Name = "cronograma_tarea_nombre", Text = original.Nombre ?? "", MaxLength = 500 };
        var modo = new ComboBox { Name = "cronograma_tarea_modo", DropDownStyle = ComboBoxStyle.DropDownList };
        modo.Items.AddRange(new object[] { "Automática", "Manual (fecha fija)" });
        modo.SelectedIndex = original.Modo == MYGModoTarea.Manual ? 1 : 0;
        var filaOriginal = filas.FirstOrDefault(f => f.Tarea?.Id == original.Id);
        DateTime inicioOriginal = filaOriginal?.Inicio ?? original.InicioManual ?? DateTime.Today;
        DateTime finOriginal = filaOriginal?.Fin ?? (original.DuracionDias == 0 ? inicioOriginal :
            calendarioTrabajo.SumarDiasLaborables(inicioOriginal, Math.Max(0, original.DuracionDias - 1)));
        var inicio = MYGCronogramaDialogoUI.Fecha("cronograma_tarea_inicio", inicioOriginal);
        var fin = MYGCronogramaDialogoUI.Fecha("cronograma_tarea_fin", finOriginal);
        var duracion = new NumericUpDown
        {
            Name = "cronograma_tarea_duracion", Minimum = 0, Maximum = 36500,
            DecimalPlaces = 0, Value = Math.Clamp(original.DuracionDias, 0, 36500), ThousandsSeparator = true
        };
        bool sincronizandoFechas = false;
        string errorFechas = null;
        DateTime ultimoFinSincronizado = fin.Value.Date;
        void ErrorFecha(Exception ex)
        {
            errorFechas = ex.Message;
            error.ForeColor = Color.Firebrick;
            error.Text = errorFechas;
        }
        void LimpiarErrorFecha()
        {
            errorFechas = null;
            error.Text = "";
        }
        void ActualizarFin()
        {
            int dias = decimal.ToInt32(duracion.Value);
            DateTime fecha = dias == 0 ? inicio.Value.Date : calendarioTrabajo.SumarDiasLaborables(inicio.Value.Date, dias - 1);
            if (fecha < fin.MinDate || fecha > fin.MaxDate)
                throw new InvalidOperationException("La fecha de fin excede el rango permitido. Revise el inicio y la duración.");
            sincronizandoFechas = true;
            try { fin.Value = fecha; ultimoFinSincronizado = fecha.Date; }
            finally { sincronizandoFechas = false; }
            LimpiarErrorFecha();
        }
        inicio.ValueChanged += (_, _) =>
        {
            if (sincronizandoFechas) return;
            try
            {
                if (inicio.Value.Date != inicioOriginal.Date) modo.SelectedIndex = 1;
                ActualizarFin();
            }
            catch (Exception ex) { ErrorFecha(ex); }
        };
        duracion.ValueChanged += (_, _) =>
        {
            if (sincronizandoFechas) return;
            try { ActualizarFin(); }
            catch (Exception ex) { ErrorFecha(ex); }
        };
        fin.ValueChanged += (_, _) =>
        {
            if (sincronizandoFechas || fin.Value.Date == ultimoFinSincronizado) return;
            try
            {
                DateTime desde = inicio.Value.Date, hasta = fin.Value.Date;
                if (hasta < desde) throw new InvalidOperationException("El fin no puede ser anterior al inicio de la tarea.");
                bool hito = duracion.Value == 0 && hasta == desde;
                if (!hito && !calendarioTrabajo.EsLaborable(hasta))
                    throw new InvalidOperationException("Seleccione un día hábil para el fin de la tarea. Un hito puede coincidir con su inicio en un día no laborable.");
                int dias = hito ? 0 : calendarioTrabajo.ContarDiasLaborables(desde, hasta);
                if (dias < 0 || dias > 36500) throw new InvalidOperationException("La duración debe estar entre 0 y 36.500 días hábiles.");
                sincronizandoFechas = true;
                try
                {
                    duracion.Value = dias;
                    modo.SelectedIndex = 1;
                    ultimoFinSincronizado = hasta;
                }
                finally { sincronizandoFechas = false; }
                LimpiarErrorFecha();
            }
            catch (Exception ex) { ErrorFecha(ex); }
        };
        modo.SelectedIndexChanged += (_, _) =>
        {
            if (sincronizandoFechas || modo.SelectedIndex != 0) return;
            try { ActualizarFin(); }
            catch (Exception ex) { ErrorFecha(ex); }
        };
        var ayudaFechas = new ToolTip();
        ayudaFechas.SetToolTip(inicio, "Editar Inicio o Fin fija programación Manual.");
        ayudaFechas.SetToolTip(fin, "Editar Inicio o Fin fija programación Manual.");
        ayudaFechas.SetToolTip(duracion, "Cambiar la duración reprograma cuadrillas y restablece la distribución de partes. Puede volver a dividirla desde Información de tarea.");
        Disposed += (_, _) => ayudaFechas.Dispose();
        var avance = new NumericUpDown
        {
            Name = "cronograma_tarea_avance", Minimum = 0, Maximum = 100, DecimalPlaces = 2,
            Value = Math.Clamp(original.Avance, 0, 100), Increment = 1
        };
        var predecesoras = new TextBox
        {
            Name = "cronograma_tarea_predecesoras", Text = MYGMotorCronograma.FormatoPredecesoras(original, filas)
        };
        var responsables = new TextBox
        {
            Name = "cronograma_tarea_responsables", Text = string.Join(Environment.NewLine, original.Responsables ?? new List<string>()),
            Multiline = true, ScrollBars = ScrollBars.Vertical, AcceptsReturn = true
        };
        Control editorResponsables = responsables;
        var disponibles = (responsablesDisponibles ?? Array.Empty<string>()).Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        if (disponibles.Length > 0)
        {
            var seleccion = new ComboBox
            {
                Name = "cronograma_tarea_responsables_disponibles", DropDownStyle = ComboBoxStyle.DropDownList,
                Dock = DockStyle.Top, Width = 170
            };
            seleccion.Items.AddRange(disponibles);
            seleccion.SelectedIndex = 0;
            var agregar = new Button
            {
                Name = "cronograma_tarea_agregar_responsable", Text = "Agregar responsable", Dock = DockStyle.Top, Height = 29
            };
            agregar.Click += (_, _) =>
            {
                var elegidos = MYGCronogramaDialogoUI.LeerNombres(responsables.Text);
                string elegido = seleccion.SelectedItem as string;
                if (!string.IsNullOrWhiteSpace(elegido) && !elegidos.Contains(elegido, StringComparer.OrdinalIgnoreCase)) elegidos.Add(elegido);
                responsables.Text = string.Join(Environment.NewLine, elegidos);
            };
            var elegir = new Panel { Dock = DockStyle.Fill, Padding = new Padding(6, 0, 0, 0) };
            elegir.Controls.Add(agregar);
            elegir.Controls.Add(seleccion);
            var contenedor = new TableLayoutPanel { ColumnCount = 2, RowCount = 1, Margin = Padding.Empty };
            contenedor.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            contenedor.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));
            responsables.Dock = DockStyle.Fill;
            contenedor.Controls.Add(responsables, 0, 0);
            contenedor.Controls.Add(elegir, 1, 0);
            editorResponsables = contenedor;
        }
        var notas = new TextBox
        {
            Name = "cronograma_tarea_notas", Text = original.Notas ?? "", Multiline = true,
            ScrollBars = ScrollBars.Vertical, AcceptsReturn = true, MaxLength = 20000
        };
        MYGCronogramaDialogoUI.Campo(tabla, "Nombre", nombre);
        MYGCronogramaDialogoUI.Campo(tabla, "Programación", modo);
        MYGCronogramaDialogoUI.Campo(tabla, "Inicio", inicio);
        MYGCronogramaDialogoUI.Campo(tabla, "Fin", fin);
        MYGCronogramaDialogoUI.Campo(tabla, "Duración (días hábiles)", duracion);
        MYGCronogramaDialogoUI.Campo(tabla, "Avance (%)", avance);
        MYGCronogramaDialogoUI.Campo(tabla, "Predecesoras", predecesoras);
        MYGCronogramaDialogoUI.Campo(tabla, "", new Label
        {
            Name = "cronograma_tarea_ayuda", Text = "Ejemplo: 3FC+2; 5CC-1. Use el número de fila.\nDuración 0 = hito. Se trabaja en días enteros.\nEditar Inicio o Fin fija programación Manual.", AutoSize = false
        }, 62);
        MYGCronogramaDialogoUI.Campo(tabla, "Responsables\n(uno por línea)", editorResponsables, 86);
        MYGCronogramaDialogoUI.Campo(tabla, "Notas", notas, 94);
        cuerpo.Controls.Add(tabla);
        Controls.Add(cuerpo);
        MYGCronogramaDialogoUI.Botones(this, "cronograma_tarea", error, () =>
        {
            if (string.IsNullOrWhiteSpace(nombre.Text)) throw new InvalidOperationException("Escriba el nombre de la tarea.");
            if (!string.IsNullOrWhiteSpace(errorFechas)) throw new InvalidOperationException(errorFechas);
            var propuesta = MYGProyectoStorage.Copia(original);
            propuesta.Nombre = nombre.Text.Trim();
            propuesta.Modo = modo.SelectedIndex == 1 ? MYGModoTarea.Manual : MYGModoTarea.Automatica;
            propuesta.InicioManual = propuesta.Modo == MYGModoTarea.Manual ? inicio.Value.Date : original.InicioManual;
            int diasPropuestos = decimal.ToInt32(duracion.Value);
            if (diasPropuestos != propuesta.DuracionDias) MYGInformacionTarea.Reprogramar(propuesta, diasPropuestos);
            propuesta.Avance = avance.Value;
            propuesta.Predecesoras = MYGMotorCronograma.LeerPredecesoras(predecesoras.Text, filas, original.Id);
            propuesta.Responsables = MYGCronogramaDialogoUI.LeerNombres(responsables.Text);
            propuesta.Notas = notas.Text.Trim();
            Valor = propuesta;
        });
        MYGCronogramaDialogoUI.Tema(this);
    }
}

internal sealed class MYGCalendarioCronogramaDialog : Form
{
    internal MYGCronograma Valor { get; private set; }

    internal MYGCalendarioCronogramaDialog(MYGCronograma plan)
    {
        ArgumentNullException.ThrowIfNull(plan);
        var original = MYGProyectoStorage.Copia(plan);
        original.Calendario ??= new MYGCalendarioTrabajo();
        Valor = MYGProyectoStorage.Copia(original);
        MYGCronogramaDialogoUI.Preparar(this, "cronograma_calendario_dialogo", "Tiempo de trabajo", new Size(610, 608));
        var cuerpo = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        var tabla = MYGCronogramaDialogoUI.Tabla();
        var inicio = MYGCronogramaDialogoUI.Fecha("cronograma_calendario_inicio", original.FechaInicio);
        var estado = MYGCronogramaDialogoUI.Fecha("cronograma_calendario_estado", original.FechaEstado);
        var dias = new CheckedListBox
        {
            Name = "cronograma_calendario_dias", CheckOnClick = true, IntegralHeight = false, BorderStyle = BorderStyle.FixedSingle
        };
        var diasSemana = new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday, DayOfWeek.Sunday };
        var nombres = new[] { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo" };
        for (int n = 0; n < diasSemana.Length; n++)
            dias.Items.Add(nombres[n], original.Calendario.DiasLaborables?.Contains(diasSemana[n]) == true);
        var horas = new NumericUpDown
        {
            Name = "cronograma_calendario_horas", Minimum = 0.01M, Maximum = 24, DecimalPlaces = 2,
            Increment = 0.25M, Value = Math.Clamp(original.Calendario.HorasPorDia, 0.01M, 24)
        };
        var feriados = new TextBox
        {
            Name = "cronograma_calendario_feriados", Multiline = true, ScrollBars = ScrollBars.Vertical, AcceptsReturn = true,
            Text = string.Join(Environment.NewLine, (original.Calendario.Feriados ?? new List<DateTime>()).OrderBy(x => x)
                .Select(x => x.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)))
        };
        MYGCronogramaDialogoUI.Campo(tabla, "Inicio del proyecto", inicio);
        MYGCronogramaDialogoUI.Campo(tabla, "Fecha de estado", estado);
        MYGCronogramaDialogoUI.Campo(tabla, "Días de trabajo", dias, 164);
        MYGCronogramaDialogoUI.Campo(tabla, "Horas por día", horas);
        MYGCronogramaDialogoUI.Campo(tabla, "Feriados", feriados, 142);
        MYGCronogramaDialogoUI.Campo(tabla, "", new Label
        {
            Name = "cronograma_calendario_ayuda", Text = "Un feriado por línea: dd/MM/aaaa.\nLas duraciones se programan en días hábiles enteros.", AutoSize = false
        }, 46);
        cuerpo.Controls.Add(tabla);
        Controls.Add(cuerpo);
        var error = MYGCronogramaDialogoUI.Error("cronograma_calendario");
        MYGCronogramaDialogoUI.Botones(this, "cronograma_calendario", error, () =>
        {
            var laborables = dias.CheckedIndices.Cast<int>().Select(i => diasSemana[i]).ToList();
            if (laborables.Count == 0) throw new InvalidOperationException("Seleccione por lo menos un día de trabajo.");
            var fechas = new List<DateTime>();
            foreach (string texto in feriados.Text.Split(new[] { '\r', '\n', ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string fecha = texto.Trim();
                if (fecha.Length == 0) continue;
                if (!DateTime.TryParseExact(fecha, new[] { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd" }, CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out DateTime valor))
                    throw new InvalidOperationException("Feriado inválido: " + fecha + ". Use dd/MM/aaaa.");
                fechas.Add(valor.Date);
            }
            var propuesta = MYGProyectoStorage.Copia(original);
            propuesta.FechaInicio = inicio.Value.Date;
            propuesta.FechaEstado = estado.Value.Date;
            propuesta.Calendario.DiasLaborables = laborables;
            propuesta.Calendario.HorasPorDia = horas.Value;
            propuesta.Calendario.Feriados = fechas.Distinct().OrderBy(x => x).ToList();
            MYGMotorCronograma.Calcular(propuesta);
            Valor = propuesta;
        });
        MYGCronogramaDialogoUI.Tema(this);
    }
}

internal sealed class MYGResponsablesCronogramaDialog : Form
{
    internal IReadOnlyList<string> Valor { get; private set; }

    internal MYGResponsablesCronogramaDialog(IEnumerable<string> responsables)
    {
        var originales = (responsables ?? Array.Empty<string>()).Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        Valor = originales.AsReadOnly();
        MYGCronogramaDialogoUI.Preparar(this, "cronograma_responsables_dialogo", "Responsables de la tarea", new Size(480, 408));
        var instrucciones = new Label
        {
            Name = "cronograma_responsables_ayuda", Dock = DockStyle.Top, Height = 54, Padding = new Padding(14, 12, 14, 4),
            Text = "Escriba un responsable por línea.\nPara quitar una asignación, borre su nombre."
        };
        var nombres = new TextBox
        {
            Name = "cronograma_responsables_nombres", Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Vertical,
            AcceptsReturn = true, Text = string.Join(Environment.NewLine, originales)
        };
        var cuerpo = new Panel { Dock = DockStyle.Fill, Padding = new Padding(14, 0, 14, 8) };
        cuerpo.Controls.Add(nombres);
        Controls.Add(cuerpo);
        Controls.Add(instrucciones);
        var error = MYGCronogramaDialogoUI.Error("cronograma_responsables");
        MYGCronogramaDialogoUI.Botones(this, "cronograma_responsables", error,
            () => Valor = MYGCronogramaDialogoUI.LeerNombres(nombres.Text).AsReadOnly());
        MYGCronogramaDialogoUI.Tema(this);
    }
}

internal sealed class MYGRedCronogramaDialog : Form
{
    internal MYGRedCronogramaDialog(MYGResultadoCronograma resultado)
    {
        ArgumentNullException.ThrowIfNull(resultado);
        MYGCronogramaDialogoUI.Preparar(this, "cronograma_red_dialogo", "Diagrama de red", new Size(1050, 650), true);
        MinimumSize = new Size(580, 380);
        var red = new RedPanel(resultado) { Name = "cronograma_red_panel", Dock = DockStyle.Fill };
        var ayuda = new Label
        {
            Name = "cronograma_red_ayuda", Dock = DockStyle.Top, Height = 44, Padding = new Padding(14, 12, 14, 4),
            Text = "Las flechas muestran las dependencias. Rojo: tarea crítica. Verde: avance. Desplace la vista para recorrer la red."
        };
        var pie = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom, Height = 50, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(12, 7, 12, 7)
        };
        var cerrar = new Button
        {
            Name = "cronograma_red_cerrar", Text = "Cerrar", DialogResult = DialogResult.Cancel,
            AutoSize = true, MinimumSize = new Size(90, 30)
        };
        pie.Controls.Add(cerrar);
        Controls.Add(red);
        Controls.Add(ayuda);
        Controls.Add(pie);
        CancelButton = cerrar;
        MYGCronogramaDialogoUI.Tema(this);
    }

    private sealed class RedPanel : Panel
    {
        private readonly List<MYGResultadoTarea> filas;
        private readonly Dictionary<string, Rectangle> cajas = new(StringComparer.Ordinal);
        private readonly Dictionary<string, MYGResultadoTarea> mapa;
        private readonly ToolTip detalle = new();
        private string bajoCursor;
        private const int Ancho = 246, Alto = 108, PasoX = 322, PasoY = 138;

        internal RedPanel(MYGResultadoCronograma resultado)
        {
            AutoScroll = true;
            DoubleBuffered = true;
            ResizeRedraw = true;
            filas = (resultado.Filas ?? Array.Empty<MYGResultadoTarea>())
                .Where(f => f?.Tarea != null && !f.Tarea.EsResumen).ToList();
            mapa = filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
            var niveles = mapa.Keys.ToDictionary(id => id, _ => 0, StringComparer.Ordinal);
            var pendientes = mapa.Keys.ToDictionary(id => id, _ => 0, StringComparer.Ordinal);
            var sucesoras = mapa.Keys.ToDictionary(id => id, _ => new List<string>(), StringComparer.Ordinal);
            foreach (var fila in filas)
            {
                foreach (string anterior in (fila.Tarea.Predecesoras ?? new List<MYGDependenciaCronograma>())
                    .Where(d => mapa.ContainsKey(d.PredecesoraId)).Select(d => d.PredecesoraId).Distinct())
                {
                    pendientes[fila.Tarea.Id]++;
                    sucesoras[anterior].Add(fila.Tarea.Id);
                }
            }
            var disponibles = new Queue<string>(filas.Where(f => pendientes[f.Tarea.Id] == 0).Select(f => f.Tarea.Id));
            while (disponibles.Count > 0)
            {
                string anterior = disponibles.Dequeue();
                foreach (string sucesora in sucesoras[anterior])
                {
                    niveles[sucesora] = Math.Max(niveles[sucesora], niveles[anterior] + 1);
                    if (--pendientes[sucesora] == 0) disponibles.Enqueue(sucesora);
                }
            }
            var posiciones = new Dictionary<int, int>();
            foreach (var fila in filas)
            {
                int nivel = niveles[fila.Tarea.Id];
                int posicion = posiciones.GetValueOrDefault(nivel);
                posiciones[nivel] = posicion + 1;
                cajas[fila.Tarea.Id] = new Rectangle(24 + nivel * PasoX, 24 + posicion * PasoY, Ancho, Alto);
            }
            AutoScrollMinSize = cajas.Count == 0 ? Size.Empty : new Size(cajas.Values.Max(r => r.Right) + 24, cajas.Values.Max(r => r.Bottom) + 24);
            MouseMove += MostrarDetalle;
            Scroll += (_, _) => Invalidate();
            Disposed += (_, _) => detalle.Dispose();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.Clear(MYG2027_TemaComercial.Fondo);
            if (filas.Count == 0)
            {
                TextRenderer.DrawText(e.Graphics, "El cronograma no contiene tareas para mostrar.", Font, ClientRectangle,
                    MYG2027_TemaComercial.Secundario, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                return;
            }
            var estado = e.Graphics.Save();
            e.Graphics.TranslateTransform(AutoScrollPosition.X, AutoScrollPosition.Y);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var flecha = new AdjustableArrowCap(4, 5, true);
            using var conexion = new Pen(MYG2027_TemaComercial.Secundario, 1.4F) { CustomEndCap = flecha };
            foreach (var fila in filas)
            {
                var destino = cajas[fila.Tarea.Id];
                foreach (var dependencia in fila.Tarea.Predecesoras ?? new List<MYGDependenciaCronograma>())
                {
                    if (!cajas.TryGetValue(dependencia.PredecesoraId, out var origen)) continue;
                    var salida = new Point(origen.Right, origen.Top + Alto / 2);
                    var entrada = new Point(destino.Left - 2, destino.Top + Alto / 2);
                    int intermedio = salida.X + Math.Max(18, (entrada.X - salida.X) / 2);
                    e.Graphics.DrawLines(conexion, new[] { salida, new Point(intermedio, salida.Y), new Point(intermedio, entrada.Y), entrada });
                    string vinculo = dependencia.Tipo + (dependencia.DesfaseDias == 0 ? "" : dependencia.DesfaseDias.ToString("+0;-0", CultureInfo.InvariantCulture));
                    var etiqueta = new Rectangle(salida.X + 3, salida.Y - 22, Math.Max(38, intermedio - salida.X - 4), 20);
                    TextRenderer.DrawText(e.Graphics, vinculo, Font, etiqueta, MYG2027_TemaComercial.Secundario,
                        MYG2027_TemaComercial.Fondo, TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix |
                        TextFormatFlags.PreserveGraphicsClipping | TextFormatFlags.PreserveGraphicsTranslateTransform);
                }
            }
            var visible = new Rectangle(-AutoScrollPosition.X, -AutoScrollPosition.Y, ClientSize.Width, ClientSize.Height);
            using var titulo = new Font(Font, FontStyle.Bold);
            foreach (var fila in filas)
            {
                var caja = cajas[fila.Tarea.Id];
                if (!caja.IntersectsWith(visible)) continue;
                using var fondo = new SolidBrush(MYG2027_TemaComercial.Superficie);
                using var borde = new Pen(fila.EsCritica ? Color.Firebrick : MYG2027_TemaComercial.Azul, fila.EsCritica ? 2 : 1);
                e.Graphics.FillRectangle(fondo, caja);
                e.Graphics.DrawRectangle(borde, caja);
                var barra = new Rectangle(caja.Left + 10, caja.Bottom - 14, caja.Width - 20, 5);
                using var baseBarra = new SolidBrush(MYG2027_TemaComercial.Borde);
                using var avance = new SolidBrush(Color.SeaGreen);
                e.Graphics.FillRectangle(baseBarra, barra);
                e.Graphics.FillRectangle(avance, new Rectangle(barra.X, barra.Y, (int)(barra.Width * Math.Clamp(fila.Tarea.Avance, 0, 100) / 100M), barra.Height));
                TextRenderer.DrawText(e.Graphics, fila.Numero + ". " + fila.Tarea.Nombre, titulo,
                    new Rectangle(caja.X + 10, caja.Y + 8, caja.Width - 20, 35), MYG2027_TemaComercial.Texto,
                    TextFormatFlags.WordBreak | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix |
                    TextFormatFlags.PreserveGraphicsClipping | TextFormatFlags.PreserveGraphicsTranslateTransform);
                string periodo = fila.Inicio.ToString("dd/MM/yy") + " – " + fila.Fin.ToString("dd/MM/yy");
                string resumen = fila.DuracionDias == 0 ? "Hito" : fila.DuracionDias + " días hábiles";
                resumen += "  ·  " + fila.Tarea.Avance.ToString("0.##", CultureInfo.CurrentCulture) + "%";
                TextRenderer.DrawText(e.Graphics, periodo + "\n" + resumen, Font,
                    new Rectangle(caja.X + 10, caja.Y + 47, caja.Width - 20, 38), MYG2027_TemaComercial.Secundario,
                    TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix |
                    TextFormatFlags.PreserveGraphicsClipping | TextFormatFlags.PreserveGraphicsTranslateTransform);
            }
            e.Graphics.Restore(estado);
        }

        private void MostrarDetalle(object sender, MouseEventArgs e)
        {
            var punto = new Point(e.X - AutoScrollPosition.X, e.Y - AutoScrollPosition.Y);
            string id = cajas.FirstOrDefault(p => p.Value.Contains(punto)).Key;
            if (id == bajoCursor) return;
            bajoCursor = id;
            if (id == null) { detalle.SetToolTip(this, ""); return; }
            var fila = mapa[id];
            string responsables = string.Join(", ", fila.Tarea.Responsables ?? new List<string>());
            detalle.SetToolTip(this, fila.Numero + ". " + fila.Tarea.Nombre + "\n" +
                (fila.EsCritica ? "Ruta crítica" : "Holgura: " + fila.HolguraDias + " días hábiles") +
                (responsables.Length > 0 ? "\nResponsables: " + responsables : "") +
                (!string.IsNullOrWhiteSpace(fila.Tarea.Notas) ? "\n" + fila.Tarea.Notas : ""));
        }
    }
}
