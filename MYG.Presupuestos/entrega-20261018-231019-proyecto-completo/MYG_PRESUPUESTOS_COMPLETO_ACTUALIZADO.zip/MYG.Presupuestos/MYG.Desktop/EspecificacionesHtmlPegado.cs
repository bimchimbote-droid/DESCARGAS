using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;

namespace MYG_2027;

/// <summary>Importación local del subconjunto de HTML de texto. Nunca ejecuta ni descarga contenido.</summary>
internal static class MYGEspecificacionesHtmlPegado
{
    internal sealed record Resultado(string Rtf, string Texto);
    private sealed record Elemento(string Nombre, bool Pre, int Lista = 0);
    private static readonly HashSet<string> Bloques = new(StringComparer.OrdinalIgnoreCase)
    { "p", "div", "section", "article", "header", "footer", "blockquote", "h1", "h2", "h3", "h4", "h5", "h6", "pre" };
    private static readonly HashSet<string> Omitidos = new(StringComparer.OrdinalIgnoreCase)
    { "head", "script", "style", "iframe", "object", "svg", "math", "template", "noscript" };
    private static readonly HashSet<string> Vacios = new(StringComparer.OrdinalIgnoreCase)
    { "br", "hr", "img", "meta", "link", "input", "embed", "area", "base", "col", "param", "source", "track", "wbr" };

    internal static Resultado Convertir(string contenido)
    {
        ArgumentNullException.ThrowIfNull(contenido);
        if (contenido.Length > 16 * 1024 * 1024) throw new ArgumentException("El HTML supera el tamaño permitido para pegar.", nameof(contenido));
        string html = ExtraerFragmento(contenido);
        var rtf = new StringBuilder(); var texto = new StringBuilder();
        var fuentes = new List<string> { "Arial" }; var colores = new List<int>();
        var elementos = new List<Elemento>(); var listas = new Stack<(bool Numerada, int Numero)>();
        bool espacio = false, inicioLinea = true;

        void Caracter(char c)
        {
            texto.Append(c);
            if (c is '\\' or '{' or '}') rtf.Append('\\').Append(c);
            else if (c == '\t') rtf.Append("\\tab ");
            else if (c >= 32 && c <= 126) rtf.Append(c);
            else rtf.Append("\\u").Append(unchecked((short)c).ToString(CultureInfo.InvariantCulture)).Append('?');
            inicioLinea = false;
        }
        void Linea(bool forzar = false)
        {
            espacio = false;
            if (forzar || !inicioLinea) { texto.Append('\n'); rtf.Append("\\par "); }
            inicioLinea = true;
        }
        void Escribir(string valor, bool pre)
        {
            foreach (char c in WebUtility.HtmlDecode(valor))
            {
                if (c == '\0' || (c < 32 && c is not '\r' and not '\n' and not '\t')) continue;
                if (pre)
                {
                    if (c == '\r') continue;
                    if (c == '\n') { Linea(true); continue; }
                }
                else if (c != '\u00a0' && char.IsWhiteSpace(c)) { espacio = true; continue; }
                if (espacio && !inicioLinea) Caracter(' ');
                espacio = false; Caracter(c);
            }
        }
        void Estilo(Dictionary<string, string> atributos, string nombre)
        {
            rtf.Append(nombre switch
            {
                "b" or "strong" => "\\b ", "i" or "em" => "\\i ", "u" => "\\ul ",
                "s" or "strike" or "del" => "\\strike ", "sub" => "\\sub ", "sup" => "\\super ",
                "h1" => "\\b\\fs40 ", "h2" => "\\b\\fs32 ", "h3" => "\\b\\fs28 ",
                "h4" or "h5" or "h6" => "\\b ", _ => ""
            });
            var css = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (atributos.TryGetValue("style", out string style))
                foreach (string declaracion in style.Split(';'))
                {
                    int separador = declaracion.IndexOf(':');
                    if (separador > 0) css[declaracion[..separador].Trim()] = declaracion[(separador + 1)..].Trim();
                }
            if (atributos.TryGetValue("face", out string face)) css.TryAdd("font-family", face);
            if (atributos.TryGetValue("color", out string color)) css.TryAdd("color", color);
            if (atributos.TryGetValue("align", out string align)) css.TryAdd("text-align", align);
            foreach ((string propiedad, string valorOriginal) in css)
            {
                string valor = valorOriginal.ToLowerInvariant();
                switch (propiedad.ToLowerInvariant())
                {
                    case "font-weight":
                        if (valor is "bold" or "bolder" || int.TryParse(valor, out int peso) && peso >= 600) rtf.Append("\\b ");
                        else if (valor == "normal" || int.TryParse(valor, out peso) && peso < 600) rtf.Append("\\b0 ");
                        break;
                    case "font-style":
                        if (valor is "italic" or "oblique") rtf.Append("\\i ");
                        else if (valor == "normal") rtf.Append("\\i0 ");
                        break;
                    case "text-decoration":
                        if (valor.Contains("underline", StringComparison.Ordinal)) rtf.Append("\\ul ");
                        if (valor.Contains("line-through", StringComparison.Ordinal)) rtf.Append("\\strike ");
                        if (valor == "none") rtf.Append("\\ulnone\\strike0 ");
                        break;
                    case "font-family":
                        string fuente = valorOriginal.Split(',')[0].Trim(' ', '\'', '"');
                        if (fuente.Length is > 0 and <= 64 && !fuente.Any(char.IsControl) && !fuente.Contains('\\'))
                        {
                            int indice = fuentes.IndexOf(fuente);
                            if (indice < 0) { indice = fuentes.Count; fuentes.Add(fuente); }
                            rtf.Append("\\f").Append(indice).Append(' ');
                        }
                        break;
                    case "font-size":
                        double factor = valor.EndsWith("pt", StringComparison.Ordinal) ? 2 : valor.EndsWith("px", StringComparison.Ordinal) ? 1.5 : 0;
                        if (factor != 0 && double.TryParse(valor[..^2], NumberStyles.Float, CultureInfo.InvariantCulture, out double tamano)
                            && double.IsFinite(tamano) && tamano >= 1 && tamano <= 1638)
                            rtf.Append("\\fs").Append((int)Math.Round(tamano * factor)).Append(' ');
                        break;
                    case "color": case "background-color":
                        if (ColorHtml(valor) is int rgb)
                        {
                            int indice = colores.IndexOf(rgb);
                            if (indice < 0) { indice = colores.Count; colores.Add(rgb); }
                            rtf.Append(propiedad.Equals("color", StringComparison.OrdinalIgnoreCase) ? "\\cf" : "\\highlight").Append(indice + 1).Append(' ');
                        }
                        break;
                    case "text-align":
                        rtf.Append(valor switch { "center" => "\\qc ", "right" => "\\qr ", "justify" => "\\qj ", "left" => "\\ql ", _ => "" });
                        break;
                }
            }
        }

        for (int posicion = 0; posicion < html.Length;)
        {
            if (html[posicion] != '<')
            {
                int fin = html.IndexOf('<', posicion); if (fin < 0) fin = html.Length;
                Escribir(html[posicion..fin], elementos.Any(e => e.Pre)); posicion = fin; continue;
            }
            if (html.AsSpan(posicion).StartsWith("<!--", StringComparison.Ordinal))
            {
                int fin = html.IndexOf("-->", posicion + 4, StringComparison.Ordinal);
                posicion = fin < 0 ? html.Length : fin + 3; continue;
            }
            int cierre = FinEtiqueta(html, posicion);
            if (cierre < 0) { Escribir(html[posicion..], elementos.Any(e => e.Pre)); break; }
            string etiqueta = html[(posicion + 1)..cierre].Trim(); posicion = cierre + 1;
            if (etiqueta.Length == 0 || etiqueta[0] is '!' or '?') continue;
            bool cerrar = etiqueta[0] == '/', autocierre = etiqueta.EndsWith('/');
            if (cerrar) etiqueta = etiqueta[1..].TrimStart();
            int largoNombre = 0;
            while (largoNombre < etiqueta.Length && (char.IsAsciiLetterOrDigit(etiqueta[largoNombre]) || etiqueta[largoNombre] is ':' or '-')) largoNombre++;
            if (largoNombre == 0) { Escribir("<" + etiqueta + ">", elementos.Any(e => e.Pre)); continue; }
            string nombre = etiqueta[..largoNombre].ToLowerInvariant();
            if (Omitidos.Contains(nombre))
            {
                if (!cerrar && !autocierre)
                {
                    int fin = html.IndexOf("</" + nombre, posicion, StringComparison.OrdinalIgnoreCase);
                    int finEtiqueta = fin < 0 ? -1 : FinEtiqueta(html, fin);
                    posicion = finEtiqueta < 0 ? html.Length : finEtiqueta + 1;
                }
                continue;
            }
            if (cerrar)
            {
                int indice = elementos.FindLastIndex(e => e.Nombre == nombre);
                if (indice < 0) continue;
                for (int i = elementos.Count - 1; i >= indice; i--)
                {
                    Elemento elemento = elementos[i];
                    // El terminador debe conservar el formato de su párrafo.
                    // Cerrar el grupo antes de \par restauraría la alineación anterior.
                    if (Bloques.Contains(elemento.Nombre) || elemento.Nombre is "li" or "tr") Linea();
                    rtf.Append('}'); elementos.RemoveAt(i);
                    if (elemento.Lista != 0 && listas.Count > 0) listas.Pop();
                    if (elemento.Nombre is "td" or "th") { Caracter('\t'); espacio = false; }
                }
                continue;
            }
            var atributos = Atributos(etiqueta[largoNombre..]);
            if (nombre is "br" or "hr") { Linea(true); continue; }
            if (nombre == "img") { if (atributos.TryGetValue("alt", out string alt)) Escribir(alt, false); continue; }
            if (Vacios.Contains(nombre)) continue;
            if (Bloques.Contains(nombre) || nombre is "li" or "tr" or "ul" or "ol") Linea();
            if (elementos.Count >= 256) throw new ArgumentException("El HTML tiene demasiados niveles de formato.", nameof(contenido));
            rtf.Append('{');
            if (Bloques.Contains(nombre) || nombre is "li" or "tr") rtf.Append("\\pard ");
            Estilo(atributos, nombre);
            if (nombre is "ul" or "ol")
            {
                int primero = atributos.TryGetValue("start", out string start) && int.TryParse(start, out int n) && n > 0 ? n : 1;
                listas.Push((nombre == "ol", primero));
            }
            if (nombre == "li")
            {
                if (listas.Count > 0 && listas.Peek().Numerada)
                {
                    var lista = listas.Pop(); Escribir(lista.Numero.ToString(CultureInfo.InvariantCulture) + ". ", true);
                    listas.Push((true, lista.Numero == int.MaxValue ? int.MaxValue : lista.Numero + 1));
                }
                else { Caracter('\u2022'); Caracter(' '); }
            }
            if (autocierre) rtf.Append('}');
            else elementos.Add(new(nombre, nombre == "pre", nombre is "ul" or "ol" ? 1 : 0));
        }
        for (int i = elementos.Count - 1; i >= 0; i--) rtf.Append('}');
        var salida = new StringBuilder("{\\rtf1\\ansi\\ansicpg1252\\uc1\\deff0{\\fonttbl");
        for (int i = 0; i < fuentes.Count; i++) salida.Append("{\\f").Append(i).Append(' ').Append(Escapar(fuentes[i])).Append(";}");
        salida.Append('}');
        if (colores.Count > 0)
        {
            salida.Append("{\\colortbl;");
            foreach (int rgb in colores) salida.Append("\\red").Append((rgb >> 16) & 255).Append("\\green").Append((rgb >> 8) & 255).Append("\\blue").Append(rgb & 255).Append(';');
            salida.Append('}');
        }
        salida.Append("\\f0\\fs22 ").Append(rtf).Append('}');
        return new(salida.ToString(), texto.ToString());
    }

    /// <summary>CF_HTML usa posiciones en bytes UTF-8, no índices UTF-16.</summary>
    internal static string ExtraerFragmento(string contenido)
    {
        int inicio = contenido.IndexOf("<!--StartFragment-->", StringComparison.OrdinalIgnoreCase);
        int fin = inicio < 0 ? -1 : contenido.IndexOf("<!--EndFragment-->", inicio + 20, StringComparison.OrdinalIgnoreCase);
        if (inicio >= 0 && fin >= inicio + 20) return contenido[(inicio + 20)..fin];
        string cabecera = contenido[..Math.Min(contenido.Length, 4096)];
        int Offset(string nombre)
        {
            foreach (string linea in cabecera.Split('\n'))
                if (linea.StartsWith(nombre + ":", StringComparison.OrdinalIgnoreCase)
                    && int.TryParse(linea[(nombre.Length + 1)..].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int posicion)) return posicion;
            return -1;
        }
        byte[] bytes = null;
        foreach (var nombres in new[] { ("StartFragment", "EndFragment"), ("StartHTML", "EndHTML") })
        {
            int desde = Offset(nombres.Item1), hasta = Offset(nombres.Item2);
            if (desde < 0 || hasta < desde) continue;
            bytes ??= Encoding.UTF8.GetBytes(contenido);
            if (hasta <= bytes.Length)
            {
                try { return new UTF8Encoding(false, true).GetString(bytes, desde, hasta - desde); }
                catch (DecoderFallbackException) { }
            }
        }
        int html = contenido.IndexOf('<');
        return contenido.StartsWith("Version:", StringComparison.OrdinalIgnoreCase) && html >= 0 ? contenido[html..] : contenido;
    }

    private static int FinEtiqueta(string html, int inicio)
    {
        char comilla = '\0';
        for (int i = inicio + 1; i < html.Length; i++)
        {
            char c = html[i];
            if (comilla != '\0') { if (c == comilla) comilla = '\0'; }
            else if (c is '\'' or '"') comilla = c;
            else if (c == '>') return i;
        }
        return -1;
    }

    private static Dictionary<string, string> Atributos(string texto)
    {
        var resultado = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < texto.Length;)
        {
            while (i < texto.Length && (char.IsWhiteSpace(texto[i]) || texto[i] == '/')) i++;
            int inicio = i;
            while (i < texto.Length && !char.IsWhiteSpace(texto[i]) && texto[i] is not '=' and not '/') i++;
            string nombre = texto[inicio..i];
            if (nombre.Length == 0) { i++; continue; }
            while (i < texto.Length && char.IsWhiteSpace(texto[i])) i++;
            string valor = "";
            if (i < texto.Length && texto[i] == '=')
            {
                i++; while (i < texto.Length && char.IsWhiteSpace(texto[i])) i++;
                if (i < texto.Length && texto[i] is '\'' or '"')
                {
                    char comilla = texto[i++]; inicio = i;
                    while (i < texto.Length && texto[i] != comilla) i++;
                    valor = texto[inicio..i]; if (i < texto.Length) i++;
                }
                else
                {
                    inicio = i; while (i < texto.Length && !char.IsWhiteSpace(texto[i])) i++;
                    valor = texto[inicio..i];
                }
            }
            resultado[nombre] = WebUtility.HtmlDecode(valor);
        }
        return resultado;
    }

    private static int? ColorHtml(string valor)
    {
        if (valor.StartsWith('#'))
        {
            string hex = valor[1..];
            if (hex.Length == 3) hex = string.Concat(hex.Select(c => new string(c, 2)));
            if (hex.Length == 6 && int.TryParse(hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out int rgb)) return rgb;
        }
        if (valor.StartsWith("rgb(", StringComparison.Ordinal) && valor.EndsWith(')'))
        {
            string[] canales = valor[4..^1].Split(',');
            if (canales.Length == 3)
            {
                int rgb = 0;
                foreach (string canalOriginal in canales)
                {
                    string canal = canalOriginal.Trim(); bool porcentaje = canal.EndsWith('%');
                    if (!double.TryParse(porcentaje ? canal[..^1] : canal, NumberStyles.Float, CultureInfo.InvariantCulture, out double n)
                        || !double.IsFinite(n) || n < 0 || n > (porcentaje ? 100 : 255)) return null;
                    rgb = (rgb << 8) | (int)Math.Round(porcentaje ? n * 255 / 100 : n);
                }
                return rgb;
            }
        }
        return valor switch
        {
            "black" => 0x000000, "white" => 0xffffff, "red" => 0xff0000, "green" => 0x008000,
            "blue" => 0x0000ff, "yellow" => 0xffff00, "gray" or "grey" => 0x808080,
            "orange" => 0xffa500, "purple" => 0x800080, "navy" => 0x000080, _ => null
        };
    }

    private static string Escapar(string valor)
    {
        var salida = new StringBuilder();
        foreach (char c in valor)
            if (c is '\\' or '{' or '}') salida.Append('\\').Append(c);
            else if (c is >= ' ' and <= '~' && c != ';') salida.Append(c);
            else salida.Append("\\u").Append(unchecked((short)c).ToString(CultureInfo.InvariantCulture)).Append('?');
        return salida.ToString();
    }
}
