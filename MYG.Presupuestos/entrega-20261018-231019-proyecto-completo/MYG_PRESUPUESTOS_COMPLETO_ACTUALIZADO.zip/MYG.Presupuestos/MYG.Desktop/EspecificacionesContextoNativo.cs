using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

// RichEdit puede mover el cursor antes de emitir MouseDown. El clic derecho
// sólo abre el menú: no se envía a su lógica de selección de texto.
internal sealed class MYGEspecificacionesContextoNativo : NativeWindow, IDisposable
{
    private const int WmContextMenu = 0x007B, WmRightDown = 0x0204, WmRightUp = 0x0205;
    private const int WmRightDoubleClick = 0x0206, WmCancelMode = 0x001F, WmCaptureChanged = 0x0215;
    private readonly RichTextBox documento;
    private readonly ContextMenuStrip menu;
    private readonly Action<Point?> preparar;
    private bool pulsado, eliminado;

    internal MYGEspecificacionesContextoNativo(RichTextBox documento, ContextMenuStrip menu, Action<Point?> preparar)
    {
        this.documento = documento;
        this.menu = menu;
        this.preparar = preparar;
        documento.HandleCreated += CrearHandle;
        documento.HandleDestroyed += DestruirHandle;
        if (documento.IsHandleCreated) AssignHandle(documento.Handle);
    }

    private void CrearHandle(object sender, EventArgs e) => AssignHandle(documento.Handle);
    private void DestruirHandle(object sender, EventArgs e)
    {
        pulsado = false;
        if (Handle != IntPtr.Zero) ReleaseHandle();
    }

    protected override void WndProc(ref Message mensaje)
    {
        if (!eliminado)
        {
            if (mensaje.Msg is WmRightDown or WmRightDoubleClick)
            {
                pulsado = true;
                preparar(Coordenadas(mensaje.LParam));
                mensaje.Result = IntPtr.Zero;
                return;
            }
            if (mensaje.Msg == WmRightUp)
            {
                bool mostrar = pulsado;
                pulsado = false;
                if (mostrar) Mostrar(Coordenadas(mensaje.LParam));
                mensaje.Result = IntPtr.Zero;
                return;
            }
            if (mensaje.Msg == WmContextMenu)
            {
                pulsado = false;
                if (mensaje.LParam.ToInt64() == -1)
                {
                    preparar(null); // Apps / Mayús+F10: el cursor existente.
                    Point cursor = documento.GetPositionFromCharIndex(documento.SelectionStart);
                    int altura = (int)Math.Ceiling(documento.Font.Height * documento.ZoomFactor);
                    menu.Show(documento, new Point(Math.Clamp(cursor.X, 0, Math.Max(0, documento.ClientSize.Width - 1)),
                        Math.Clamp(cursor.Y + altura, 0, Math.Max(0, documento.ClientSize.Height - 1))));
                }
                else Mostrar(documento.PointToClient(Coordenadas(mensaje.LParam)));
                mensaje.Result = IntPtr.Zero;
                return;
            }
            if (mensaje.Msg is WmCancelMode or WmCaptureChanged) pulsado = false;
        }
        base.WndProc(ref mensaje);
    }

    private void Mostrar(Point posicion)
    {
        preparar(posicion);
        menu.Show(documento, posicion);
    }

    private static Point Coordenadas(IntPtr datos)
    {
        long valor = datos.ToInt64();
        return new Point(unchecked((short)valor), unchecked((short)(valor >> 16)));
    }

    public void Dispose()
    {
        if (eliminado) return;
        eliminado = true; pulsado = false;
        documento.HandleCreated -= CrearHandle;
        documento.HandleDestroyed -= DestruirHandle;
        if (Handle != IntPtr.Zero) ReleaseHandle();
    }
}
