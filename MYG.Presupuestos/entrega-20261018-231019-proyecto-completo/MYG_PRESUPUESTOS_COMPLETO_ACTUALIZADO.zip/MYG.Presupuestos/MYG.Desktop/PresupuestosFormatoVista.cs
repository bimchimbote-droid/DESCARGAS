using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    // Preferencia de esta vista: no se escribe en el proyecto ni en sus reportes.
    private Font fuenteVistaEstructura, fuenteTituloVistaEstructura;
    private Color tintaVistaEstructura, fondoVistaEstructura;
    private bool formatoVistaEstructuraInicializado;

    private void InicializarFormatoVistaEstructura()
    {
        if (formatoVistaEstructuraInicializado) return;
        formatoVistaEstructuraInicializado = true;
        estructura.CellFormatting += FormatearVistaEstructura;
        estructura.EditingControlShowing += FormatearEditorVistaEstructura;
        estructura.DpiChangedAfterParent += AjustarAlturasFormatoVistaEstructura;
        MYGTamanoTextoUI.CambioTamano += AjustarAlturasFormatoVistaEstructura;
        Disposed += (_, _) =>
        {
            MYGTamanoTextoUI.CambioTamano -= AjustarAlturasFormatoVistaEstructura;
            fuenteVistaEstructura?.Dispose();
            fuenteTituloVistaEstructura?.Dispose();
        };
    }

    private void ElegirFuenteEstructura()
    {
        var estilo = estructura.DefaultCellStyle;
        using var dialogo = new MYGFuenteResumenForm(
            fuenteVistaEstructura ?? MYGTamanoTextoUI.FuenteOriginal(estilo.Font ?? estructura.Font),
            fuenteVistaEstructura == null ? estilo.ForeColor : tintaVistaEstructura,
            fuenteVistaEstructura == null ? estilo.BackColor : fondoVistaEstructura)
        { Text = "Fuente del presupuesto", Name = "fuentePresupuestoDialogo" };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        AplicarFormatoVistaEstructura(dialogo.FuenteElegida, dialogo.ColorTexto, dialogo.ColorFondo);
    }

    internal void AplicarFormatoVistaEstructura(Font fuente, Color tinta, Color fondo)
    {
        ArgumentNullException.ThrowIfNull(fuente);
        // FuenteOriginal evita guardar otra vez el porcentaje global de lectura.
        var nueva = (Font)MYGTamanoTextoUI.FuenteOriginal(fuente).Clone();
        Font titulo;
        try { titulo = new Font(nueva, nueva.Style | FontStyle.Bold); }
        catch { nueva.Dispose(); throw; }
        var anterior = fuenteVistaEstructura;
        var tituloAnterior = fuenteTituloVistaEstructura;
        fuenteVistaEstructura = nueva;
        fuenteTituloVistaEstructura = titulo;
        tintaVistaEstructura = tinta.IsEmpty ? MYG2027_TemaComercial.Texto : tinta;
        fondoVistaEstructura = fondo.IsEmpty ? MYG2027_TemaComercial.Superficie : fondo;
        AjustarAlturasFormatoVistaEstructura(null, EventArgs.Empty);
        anterior?.Dispose();
        tituloAnterior?.Dispose();
    }

    private Font FuenteFormatoVistaEstructura(DataGridViewRow fila)
    {
        bool titulo = fila.Tag is MYGPresupuestoDocumento ||
            fila.Tag is ItemPresupuestoDelphin item && MYGProyectoStorage.EsTitulo(item);
        // Las fuentes escaladas pertenecen al caché compartido de la interfaz.
        return MYGTamanoTextoUI.Fuente(titulo ? fuenteTituloVistaEstructura : fuenteVistaEstructura);
    }

    private Font FuenteMedicionEstructura(DataGridViewRow fila) => fuenteVistaEstructura == null
        ? MYGTamanoTextoUI.Fuente(fila.DefaultCellStyle.Font ?? estructura.Font)
        : FuenteFormatoVistaEstructura(fila);

    private void FormatearVistaEstructura(object sender, DataGridViewCellFormattingEventArgs e)
    {
        if (fuenteVistaEstructura == null || e.RowIndex < 0) return;
        e.CellStyle.Font = FuenteFormatoVistaEstructura(estructura.Rows[e.RowIndex]);
        AplicarColoresFormatoVistaEstructura(e.CellStyle);
    }

    private void AplicarColoresFormatoVistaEstructura(DataGridViewCellStyle estilo)
    {
        bool contraste = SystemInformation.HighContrast;
        estilo.ForeColor = contraste ? SystemColors.WindowText : tintaVistaEstructura;
        estilo.BackColor = contraste ? SystemColors.Window : fondoVistaEstructura;
        estilo.SelectionBackColor = contraste ? SystemColors.Highlight : MYG2027_TemaComercial.Seleccion;
        estilo.SelectionForeColor = contraste ? SystemColors.HighlightText : MYG2027_TemaComercial.TextoSeleccion;
    }

    private void FormatearEditorVistaEstructura(object sender, DataGridViewEditingControlShowingEventArgs e)
    {
        if (fuenteVistaEstructura == null || estructura.CurrentRow == null) return;
        e.CellStyle.Font = FuenteFormatoVistaEstructura(estructura.CurrentRow);
        AplicarColoresFormatoVistaEstructura(e.CellStyle);
        e.Control.Font = e.CellStyle.Font;
        e.Control.ForeColor = e.CellStyle.ForeColor;
        e.Control.BackColor = e.CellStyle.BackColor;
    }

    private void AjustarAlturasFormatoVistaEstructura(object sender, EventArgs e)
    {
        if (fuenteVistaEstructura == null || IsDisposed || Disposing || estructura.IsDisposed) return;
        if (filasEstructura.Count > 0)
            estructura.Columns["ITEM"].Width = Math.Max(105, Math.Min(300, filasEstructura.Max(fila =>
                TextRenderer.MeasureText(Convert.ToString(CeldaEstructura(fila, "ITEM").Value), FuenteMedicionEstructura(fila)).Width +
                CeldaEstructura(fila, "ITEM").Style.Padding.Horizontal + 8)));
        // La tabla conserva su ajuste de texto y mide con CellFormatting, también
        // después de reconstruir filas o de volver a mostrar ramas plegadas.
        if (estructura.Rows.Count > 0)
            estructura.AutoResizeRows(DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders);
        estructura.Invalidate();
    }
}
