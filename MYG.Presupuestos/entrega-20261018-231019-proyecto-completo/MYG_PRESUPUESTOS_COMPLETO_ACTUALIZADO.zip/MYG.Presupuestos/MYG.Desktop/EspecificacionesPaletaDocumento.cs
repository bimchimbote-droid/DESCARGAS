﻿using System;
namespace MYG_2027;
// Paleta exclusiva de pantalla: no cambia el RTF, el formato ni los colores
// utilizados al guardar o imprimir. La entrada y la salida son RGB de 24 bits.
internal static class MYGEspecificacionesPaletaDocumento
{
    internal const int PapelRgb = 0x303640;
    internal const int TextoRgb = 0xEDF2F7;
    internal static int TransformarRgb(int rgb)
    {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        int minimo = Math.Min(r, Math.Min(g, b));
        int maximo = Math.Max(r, Math.Max(g, b));
        int diferencia = maximo - minimo;
        // Blanco y los grises de suavizado se acercan gradualmente al papel;
        // transformar de otro modo los bordes casi blancos crea halos claros.
        if (diferencia == 0)
            return (Mezclar(48, 237, 255 - minimo) << 16)
                | (Mezclar(54, 242, 255 - minimo) << 8)
                | Mezclar(64, 247, 255 - minimo);
        // La tinta oscura se aclara hacia un pastel del mismo tono. Los colores
        // muy luminosos, habituales en resaltados, pasan a un tinte oscuro:
        // así el texto negro convertido en claro sigue contrastando sobre ellos.
        // La transición evita cambios bruscos en los bordes suavizados.
        int luminosidad = (54 * r + 183 * g + 19 * b + 128) / 256;
        int transicion = Math.Clamp(luminosidad - 110, 0, 60);
        int baseColor = 160 - 2 * transicion;
        int amplitud = 77 - (21 * transicion + 30) / 60;
        // La saturación determina la mezcla con la tinta normal. El mínimo
        // estima la cobertura contra el blanco del renderizado nativo, de modo
        // que las muestras casi blancas se funden con el papel sin crear halos.
        int cobertura = 255 - minimo;
        int tintaR = Tinta(r, minimo, maximo, diferencia, 237, baseColor, amplitud);
        int tintaG = Tinta(g, minimo, maximo, diferencia, 242, baseColor, amplitud);
        int tintaB = Tinta(b, minimo, maximo, diferencia, 247, baseColor, amplitud);
        return (Mezclar(48, tintaR, cobertura) << 16)
            | (Mezclar(54, tintaG, cobertura) << 8)
            | Mezclar(64, tintaB, cobertura);
    }
    private static int Tinta(int componente, int minimo, int maximo, int diferencia, int normal, int baseColor, int amplitud)
        => (normal * minimo + baseColor * diferencia + amplitud * (componente - minimo) + maximo / 2) / maximo;
    private static int Mezclar(int papel, int tinta, int cobertura)
        => (papel * (255 - cobertura) + tinta * cobertura + 127) / 255;
}
