using System;
using System.Runtime.CompilerServices;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

// Los controles de edición conservan su cursor. La mano sólo indica acciones
// habilitadas, incluso en barras, menús y pestañas creados después de abrir la ventana.
internal static class MYGCursoresUI
{
    private static readonly ConditionalWeakTable<WinForms.Control, EstadoControl> controles = new();
    private static readonly ConditionalWeakTable<WinForms.ToolStripItem, EstadoItem> items = new();

    internal static void Aplicar(WinForms.Control control)
    {
        if (control == null || control.IsDisposed || control.Disposing || controles.TryGetValue(control, out _)) return;
        var estado = new EstadoControl(control);
        controles.Add(control, estado);
        estado.Preparar();
    }

    internal static WinForms.Cursor CursorEn(WinForms.Control control, Drawing.Point punto)
    {
        if (control == null || control.IsDisposed || !control.Enabled) return WinForms.Cursors.Default;
        if (control.UseWaitCursor) return WinForms.Cursors.WaitCursor;
        if (control is WinForms.ButtonBase) return WinForms.Cursors.Hand;
        if (control is WinForms.TabControl pestanas && pestanas.IsHandleCreated)
        {
            for (int i = 0; i < pestanas.TabCount; i++)
                if (pestanas.TabPages[i].Enabled && pestanas.GetTabRect(i).Contains(punto)) return WinForms.Cursors.Hand;
        }
        else if (control is WinForms.ToolStrip barra)
        {
            var item = barra.GetItemAt(punto);
            if (item is { Enabled: true } && (item is WinForms.ToolStripButton or WinForms.ToolStripDropDownItem
                || item is WinForms.ToolStripLabel { IsLink: true })) return WinForms.Cursors.Hand;
        }
        return WinForms.Cursors.Default;
    }

    private static void PrepararItem(WinForms.ToolStripItem item)
    {
        if (item == null || item.IsDisposed || items.TryGetValue(item, out _)) return;
        var estado = new EstadoItem(item);
        items.Add(item, estado);
        estado.Preparar();
    }

    private sealed class EstadoControl : WinForms.NativeWindow
    {
        private readonly WinForms.Control control;
        private bool liberado;
        private bool CursorPorZona => control is WinForms.TabControl or WinForms.ToolStrip;

        internal EstadoControl(WinForms.Control control) => this.control = control;

        internal void Preparar()
        {
            control.ControlAdded += AgregarControl;
            control.ContextMenuStripChanged += CambiarMenu;
            control.Disposed += Liberar;
            if (control is WinForms.ButtonBase)
            {
                control.EnabledChanged += HabilitarBoton;
                HabilitarBoton(null, EventArgs.Empty);
            }
            if (CursorPorZona)
            {
                control.HandleCreated += CrearHandle;
                control.HandleDestroyed += DestruirHandle;
                if (control.IsHandleCreated) AssignHandle(control.Handle);
            }
            if (control is WinForms.ToolStrip barra)
            {
                barra.ItemAdded += AgregarItem;
                foreach (WinForms.ToolStripItem item in barra.Items) PrepararItem(item);
                if (barra is not WinForms.ToolStripDropDown) PrepararItem(barra.OverflowButton);
            }
            foreach (WinForms.Control hijo in control.Controls) Aplicar(hijo);
            if (control.ContextMenuStrip != null) Aplicar(control.ContextMenuStrip);
        }

        private void AgregarControl(object sender, WinForms.ControlEventArgs e) => Aplicar(e.Control);
        private void CambiarMenu(object sender, EventArgs e)
        { if (control.ContextMenuStrip != null) Aplicar(control.ContextMenuStrip); }
        private void AgregarItem(object sender, WinForms.ToolStripItemEventArgs e) => PrepararItem(e.Item);
        private void HabilitarBoton(object sender, EventArgs e)
            => control.Cursor = control.Enabled ? WinForms.Cursors.Hand : WinForms.Cursors.Default;
        private void CrearHandle(object sender, EventArgs e) => AssignHandle(control.Handle);
        private void DestruirHandle(object sender, EventArgs e) => ReleaseHandle();

        protected override void WndProc(ref WinForms.Message mensaje)
        {
            // WM_SETCURSOR se propaga también desde ventanas hijas. Limitarlo
            // al HWND de la barra evita heredar la mano en celdas, cuadros de
            // texto, desplegables alojados y botones nativos de desplazamiento.
            if (!liberado && mensaje.Msg == 0x0020 && mensaje.WParam == Handle &&
                (mensaje.LParam.ToInt64() & 0xFFFF) == 1 &&
                CursorEn(control, control.PointToClient(WinForms.Cursor.Position)) == WinForms.Cursors.Hand)
            {
                WinForms.Cursor.Current = WinForms.Cursors.Hand;
                mensaje.Result = new IntPtr(1);
                return;
            }
            base.WndProc(ref mensaje);
        }

        private void Liberar(object sender, EventArgs e)
        {
            if (liberado) return;
            liberado = true;
            control.ControlAdded -= AgregarControl;
            control.ContextMenuStripChanged -= CambiarMenu;
            control.Disposed -= Liberar;
            if (control is WinForms.ButtonBase) control.EnabledChanged -= HabilitarBoton;
            if (CursorPorZona)
            {
                control.HandleCreated -= CrearHandle;
                control.HandleDestroyed -= DestruirHandle;
                ReleaseHandle();
            }
            if (control is WinForms.ToolStrip barra) barra.ItemAdded -= AgregarItem;
            controles.Remove(control);
        }
    }

    private sealed class EstadoItem
    {
        private readonly WinForms.ToolStripItem item;
        internal EstadoItem(WinForms.ToolStripItem item) => this.item = item;

        internal void Preparar()
        {
            item.Disposed += Liberar;
            if (item is WinForms.ToolStripControlHost alojado) Aplicar(alojado.Control);
            if (item is WinForms.ToolStripDropDownItem menu)
            {
                menu.DropDownOpening += AbrirMenu;
                if (menu.HasDropDownItems) Aplicar(menu.DropDown);
            }
        }

        private void AbrirMenu(object sender, EventArgs e)
        { if (item is WinForms.ToolStripDropDownItem menu) Aplicar(menu.DropDown); }
        private void Liberar(object sender, EventArgs e)
        {
            item.Disposed -= Liberar;
            if (item is WinForms.ToolStripDropDownItem menu) menu.DropDownOpening -= AbrirMenu;
            items.Remove(item);
        }
    }
}
