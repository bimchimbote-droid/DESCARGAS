using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal enum MYGDestinoExportacionCronograma
{ Nativo, ProjectTareas, ProjectRecursos, XmlTareas, XmlRecursos, Pdf, Xlsx, Texto, Mht, Csv }

internal static class MYGMenuExportacionCronograma
{
    internal static ContextMenuStrip Crear(Action<MYGDestinoExportacionCronograma> ejecutar)
    {
        var menu = new ContextMenuStrip { Name = "cronograma_menu_exportar", ImageScalingSize = new Size(20, 20) };
        void Opcion(MYGDestinoExportacionCronograma destino, string id, string texto, string ayuda, string icono)
        {
            var imagen = MYGIconos.Obtener(icono);
            var item = new ToolStripMenuItem(texto, imagen, (_, _) => ejecutar(destino))
            {
                Name = "cronograma_exportar_" + id, Tag = destino,
                ToolTipText = ayuda, AccessibleDescription = ayuda, AccessibleName = texto
            };
            item.Disposed += (_, _) => imagen.Dispose();
            menu.Items.Add(item);
        }
        Opcion(MYGDestinoExportacionCronograma.Nativo, "nativo", "Exportar a archivo nativo MYG (.sqlite)",
            "Copia del proyecto y su cronograma en SQLite MYG; conserva el archivo abierto.", "guardar");
        Opcion(MYGDestinoExportacionCronograma.ProjectTareas, "project_tareas", "Exportar a MS-Project (sólo tareas)",
            "Archivo .mpp real. Requiere Microsoft Project instalado en Windows.", "proyecto");
        Opcion(MYGDestinoExportacionCronograma.ProjectRecursos, "project_recursos", "Exportar a MS-Project (tareas y recursos)",
            "Archivo .mpp real con recursos y asignaciones. Requiere Microsoft Project instalado.", "proyecto");
        Opcion(MYGDestinoExportacionCronograma.XmlTareas, "xml_tareas", "Exportar a XML (sólo tareas)",
            "XML estándar de Microsoft Project; no requiere Microsoft Project para generarlo.", "especificacion");
        Opcion(MYGDestinoExportacionCronograma.XmlRecursos, "xml_recursos", "Exportar a XML (tareas y recursos)",
            "XML estándar de Microsoft Project con recursos reales vinculados al presupuesto.", "especificacion");
        menu.Items.Add(new ToolStripSeparator());
        Opcion(MYGDestinoExportacionCronograma.Pdf, "pdf", "Exportar a PDF",
            "Vista previa del Gantt y exportación mediante Microsoft Print to PDF.", "imprimir");
        Opcion(MYGDestinoExportacionCronograma.Xlsx, "xlsx", "Exportar a XLSX", "Libro Excel con la programación y el Gantt.", "excel");
        Opcion(MYGDestinoExportacionCronograma.Texto, "texto", "Exportar a Texto", "Lista de tareas en texto delimitado por tabulaciones.", "especificacion");
        Opcion(MYGDestinoExportacionCronograma.Mht, "mht", "Exportar a MHT", "Informe de Gantt en una página web de archivo único.", "especificacion");
        menu.Items.Add(new ToolStripSeparator());
        Opcion(MYGDestinoExportacionCronograma.Csv, "csv", "Lista de tareas CSV", "Lista estructurada de tareas con identificadores y fechas ISO.", "excel");
        return menu;
    }
}
