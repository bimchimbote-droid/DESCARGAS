using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Linq;
using MYG.Externo;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace MYG_2027;

// Editor del programa independiente. La API de Revit se ejecuta exclusivamente
// en el conector mediante ClienteRevit; esta ventana no referencia RevitAPI.
internal sealed partial class EditorForm : WinForms.Form
{
    private MYGProyectoDocumento documento;
    private string archivo, firmaGuardada;
    private readonly SesionDesktop sesion;
    private readonly WinForms.DataGridView grid = new MYG2027_TablaPresupuesto();
    private readonly WinForms.ComboBox presupuesto = new() { DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly WinForms.ComboBox revit = new() { Width = 420, DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly WinForms.Label estado = new() { AutoEllipsis = true };
    private readonly WinForms.Label resumen = new() { AutoEllipsis = true };
    private readonly WinForms.Label estadoRevit = new() { Text = "Revit: sin conexión", AutoEllipsis = true };
    private readonly WinForms.LinkLabel enlaceRevit = new() { Text = "Conectar Revit", AutoEllipsis = true };
    private readonly WinForms.Button login = MYGProyectoUI.Boton("Iniciar sesión");
    private WinForms.Button botonQuitar, botonSubir, botonBajar, botonDeshacer, botonRehacer;
    private readonly WinForms.Label marca = new()
    {
        Text = "MYG BIM  /  Tablas Automáticas",
        ForeColor = Color.White,
        BackColor = Color.Transparent,
        Font = new("Segoe UI", 16F, FontStyle.Bold),
        AutoEllipsis = true
    };
    private readonly WinForms.Label proyectoNombre = new()
    {
        ForeColor = Color.FromArgb(192, 212, 241),
        BackColor = Color.Transparent,
        Font = new("Segoe UI", 9F),
        AutoEllipsis = true
    };
    private readonly WinForms.Label archivoNombre = new()
    {
        ForeColor = Color.FromArgb(201, 222, 248),
        BackColor = Color.Transparent,
        Font = new("Segoe UI", 8.25F, FontStyle.Bold),
        TextAlign = ContentAlignment.MiddleRight,
        AutoEllipsis = true
    };
    private readonly WinForms.TableLayoutPanel raiz = new()
    { Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 5, Margin = new(0) };
    private readonly MYG2027_CabeceraComercial cabecera = new() { Dock = WinForms.DockStyle.Fill, Margin = new(0) };
    private readonly WinForms.Panel selector = new() { Dock = WinForms.DockStyle.Fill, Margin = new(0) };
    private readonly WinForms.Label presupuestoTitulo = new()
    { Text = "PRESUPUESTO DE TRABAJO", Font = new("Segoe UI", 9F, FontStyle.Bold) };
    private readonly WinForms.FlowLayoutPanel acciones = new()
    {
        Dock = WinForms.DockStyle.Fill,
        WrapContents = true,
        Margin = new(0),
        BackColor = MYG2027_TemaComercial.Fondo
    };
    private readonly WinForms.Panel tablaPanel = new() { Dock = WinForms.DockStyle.Fill, Margin = new(0) };
    private readonly MYG2027_CabeceraFiltros cabeceraFiltros = new() { Height = 28 };
    private readonly WinForms.Panel inferior = new() { Dock = WinForms.DockStyle.Fill, BackColor = Color.White, Margin = new(0) };
    private readonly WinForms.FlowLayoutPanel pie = new() { WrapContents = true, Margin = new(0), BackColor = Color.White };
    private readonly WinForms.TextBox buscarItem = new(), buscarPartida = new(), buscarUnidad = new();
    private readonly Dictionary<WinForms.Control, Rectangle> medidas = new();
    private readonly Dictionary<string, HashSet<string>> contraidos = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> columnasOcultas = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> anchosColumnas = new(StringComparer.OrdinalIgnoreCase);
    private readonly Stack<MYGProyectoDocumento> undo = new(), redo = new();
    private readonly ClienteRevit cliente = new();
    private readonly WinForms.ToolTip ayudas = new() { AutoPopDelay = 10000, InitialDelay = 350, ReshowDelay = 100 };
    private readonly System.ComponentModel.Container componentesMenus = new();
    private DocumentoRevitInfo modelo;
    private MYGBibliotecaDocumento biblioteca;
    private string rutaBiblioteca, carpetaMetrados, columnaEdicion, valorAntesEdicion;
    private bool cargando, ocupado, sincronizando, ajustandoBarras, aplicandoVista;
    private MYGPresupuestoDocumento P => documento.Presupuestos.FirstOrDefault(x => x.Id == documento.PresupuestoActivoId);
    private IEnumerable<ItemPresupuestoDelphin> Partidas => P?.Items.Where(i => !MYGProyectoStorage.EsTitulo(i)) ?? Enumerable.Empty<ItemPresupuestoDelphin>();
    private List<ItemPresupuestoDelphin> Seleccionadas => grid.SelectedCells.Cast<WinForms.DataGridViewCell>()
        .Where(c => c.OwningRow.Visible).Select(c => c.OwningRow.Tag as ItemPresupuestoDelphin).Where(i => i != null).Distinct().ToList();
    private HashSet<string> Contraidos
    {
        get
        {
            string id = P?.Id ?? "";
            if (!contraidos.TryGetValue(id, out var valores)) contraidos[id] = valores = new(StringComparer.OrdinalIgnoreCase);
            return valores;
        }
    }

    internal EditorForm(MYGProyectoDocumento doc, string ruta, SesionDesktop sesion, string firmaAnterior = null)
    {
        MYGProyectoStorage.Validar(doc);
        documento = doc; archivo = ruta; this.sesion = sesion;
        if (!string.IsNullOrWhiteSpace(ruta)) MYGBaseDatos.AsegurarParaProyecto(ruta, doc);
        firmaGuardada = firmaAnterior ?? (string.IsNullOrWhiteSpace(ruta) ? null : MYGProyectoStorage.Firma(doc));
        MYGProyectoUI.Preparar(this, "Presupuesto y tablas automáticas", 1440, 860);
        Text = "MYG BIM | Presupuesto y tablas automáticas";
        MinimumSize = new(900, 540); ShowInTaskbar = true; DoubleBuffered = true; KeyPreview = true;
        foreach (int h in new[] { 88, 76, 78, 0, 118 })
            raiz.RowStyles.Add(h == 0 ? new(WinForms.SizeType.Percent, 100) : new(WinForms.SizeType.Absolute, h));
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        cabecera.Controls.AddRange(new WinForms.Control[] { marca, proyectoNombre, archivoNombre });
        selector.Controls.AddRange(new WinForms.Control[] { presupuestoTitulo, presupuesto });
        presupuesto.Font = new("Segoe UI", 10F); presupuesto.BackColor = Color.White;
        presupuesto.ForeColor = presupuestoTitulo.ForeColor = MYG2027_TemaComercial.Texto;
        raiz.Controls.Add(cabecera, 0, 0); raiz.Controls.Add(selector, 0, 1); raiz.Controls.Add(acciones, 0, 2);
        raiz.Controls.Add(tablaPanel, 0, 3); raiz.Controls.Add(inferior, 0, 4); Controls.Add(raiz);

        acciones.Controls.Add(Grupo("ESTRUCTURA Y PROYECTO",
            BotonAccion("+ Título", MenuTitulo, 0, 108),
            BotonAccion("+ Partida", MenuNuevaPartida, 1, 112),
            BotonAsync("Conectar / actualizar", ConectarDelphin, true, 174),
            BotonAccion("Proyecto / biblioteca", MenuProyecto, 0, 172)));
        acciones.Controls.Add(Grupo("BIBLIOTECA BIM",
            BotonAccion("Guardar filtros", () => GuardarFiltros(false), 1, 130),
            BotonAccion("Traer filtros", () => TraerFiltros(false), 0, 118),
            BotonAccion("Biblioteca", MenuBiblioteca, 0, 108)));
        acciones.Controls.Add(Grupo("NAVEGACIÓN",
            BotonAccion("Expandir todo", () => PlegarTodo(false), 0, 110),
            BotonAccion("Contraer todo", () => PlegarTodo(true), 0, 112)));
        acciones.Controls.Add(Grupo("CONFIGURACIÓN BIM",
            BotonAccion("+ Agregar filtro", () => CambiarFiltros(1), 2, 120),
            BotonAccion("− Quitar filtro", () => CambiarFiltros(-1), 2, 120)));
        var exportar = BotonAccion("Exportar presupuesto", ExportarCsv, 2, 150);
        acciones.Controls.Add(Grupo("COORDINACIÓN",
            botonQuitar = BotonAccion("− Quitar propuesta", Quitar, 0, 138),
            botonSubir = BotonAccion("↑", () => MoverPropuesta(-1), 0, 30),
            botonBajar = BotonAccion("↓", () => MoverPropuesta(1), 0, 30),
            BotonAccion("Reconciliar Delphin", Reconciliar, 2, 145), exportar));
        acciones.Controls.Add(Grupo("HERRAMIENTAS",
            BotonAccion("Columnas", ElegirColumnas, 0, 112),
            botonDeshacer = BotonAccion("↶", () => Historial(false), 0, 30),
            botonRehacer = BotonAccion("↷", () => Historial(true), 0, 30),
            BotonAsync("Actualizar plantillas", ActualizarPlantillas, true, 130, 2)));

        MYG2027_TemaComercial.EstilizarTablaPresupuesto(grid);
        cabeceraFiltros.Tabla = grid; tablaPanel.Controls.AddRange(new WinForms.Control[] { cabeceraFiltros, grid });
        foreach (var b in new[] { buscarItem, buscarPartida, buscarUnidad })
        {
            b.Font = new("Segoe UI", 9F); b.BorderStyle = WinForms.BorderStyle.FixedSingle;
            b.TextChanged += (s, e) => { if (!cargando) AplicarVista(); };
            b.KeyDown += (s, e) => { if (e.KeyCode == WinForms.Keys.Escape) { b.Clear(); e.SuppressKeyPress = true; } };
            cabeceraFiltros.Controls.Add(b);
        }
        ayudas.SetToolTip(buscarItem, "Buscar por ITEM. Escape limpia el buscador.");
        ayudas.SetToolTip(buscarPartida, "Buscar por PARTIDA. Conserva los títulos de las coincidencias.");
        ayudas.SetToolTip(buscarUnidad, "Buscar por UNIDAD.");
        grid.Scroll += (s, e) => AlinearCabecera();
        grid.ColumnWidthChanged += (s, e) =>
        {
            if (!cargando && e.Column.AutoSizeMode != WinForms.DataGridViewAutoSizeColumnMode.Fill)
                anchosColumnas[e.Column.Name] = (int)Math.Round(e.Column.Width * 96F / Math.Max(96, DeviceDpi));
            AlinearCabecera();
        };
        grid.ColumnDisplayIndexChanged += (s, e) => AlinearCabecera();
        grid.ColumnStateChanged += (s, e) => AlinearCabecera();
        grid.Resize += (s, e) => AlinearCabecera();
        grid.SelectionChanged += (s, e) => { if (!cargando && !aplicandoVista) ActualizarDisponibilidad(); };
        grid.CellBeginEdit += (s, e) =>
        {
            if (cargando || !sesion.Autorizado) return;
            columnaEdicion = grid.Columns[e.ColumnIndex].Name;
            valorAntesEdicion = grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString(); Recordar();
        };
        grid.CellValidating += (s, e) =>
        {
            if (cargando || e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (grid.Rows[e.RowIndex].Cells[e.ColumnIndex] is WinForms.DataGridViewComboBoxCell c)
            {
                string texto = e.FormattedValue?.ToString() ?? "";
                if (!c.Items.Contains(texto)) c.Items.Add(texto);
            }
        };
        grid.EditingControlShowing += (s, e) =>
        { if (e.Control is WinForms.DataGridViewComboBoxEditingControl c) c.DropDownStyle = WinForms.ComboBoxStyle.DropDown; };
        grid.CellEndEdit += (s, e) =>
        {
            if (cargando || sincronizando || e.RowIndex < 0) return;
            var fila = grid.Rows[e.RowIndex];
            string col = grid.Columns[e.ColumnIndex].Name;
            if (col == columnaEdicion && fila.Cells[col].Value?.ToString() != valorAntesEdicion && fila.Tag is ItemPresupuestoDelphin i)
            { i.EstadoRevit = null; i.MensajeRevit = null; }
            Sincronizar(); OpcionesFila(fila); ActualizarCeldaRevit(fila); ActualizarResumen();
        };
        grid.CellClick += (s, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || grid.Columns[e.ColumnIndex].Name != "EXPANDIR") return;
            if (grid.Rows[e.RowIndex].Tag is ItemPresupuestoDelphin i && P.Items.Any(h => h.ParentId == i.Id))
            { Sincronizar(); if (!Contraidos.Add(i.Id)) Contraidos.Remove(i.Id); AplicarVista(); }
        };
        grid.CellDoubleClick += async (s, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            string col = grid.Columns[e.ColumnIndex].Name;
            if (col == "BIBLIOTECA") await Ejecutar(() => { TraerFiltros(true); return Task.CompletedTask; });
            else if (col.StartsWith("V", StringComparison.Ordinal) && int.TryParse(col[1..], out int n))
                await Ejecutar(() => ElegirValorRevit(grid.Rows[e.RowIndex], n));
        };
        grid.CellMouseDown += (s, e) =>
        {
            if (e.Button != WinForms.MouseButtons.Right || e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (!grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Selected) { grid.ClearSelection(); grid.CurrentCell = grid.Rows[e.RowIndex].Cells[e.ColumnIndex]; grid.CurrentCell.Selected = true; }
            MenuFila();
        };
        grid.DataError += (s, e) => { e.ThrowException = false; estado.Text = "Revise el valor de la celda seleccionada."; };
        presupuesto.SelectedIndexChanged += (s, e) =>
        {
            if (cargando) return;
            Sincronizar();
            if (presupuesto.SelectedItem is MYGPresupuestoDocumento p) { documento.PresupuestoActivoId = p.Id; Refrescar(); }
        };

        pie.Controls.Add(GrupoPie("Proyecto MYG",
            BotonAsync("Guardar", () => { Guardar(false); return Task.CompletedTask; }, false, 100),
            BotonAsync("Abrir proyecto", AbrirProyecto, false, 100),
            BotonAsync("Cargar Data", CargarData, true, 100, 2)));
        pie.Controls.Add(GrupoPie("Tablas de planificación",
            BotonAsync("Revisar Revit", () => OperarRevit("REVISAR"), true, 110, 2),
            BotonAsync("Actualizar tabla(s)", () => OperarRevit("ACTUALIZAR"), true, 142, 2),
            BotonAsync("Crear tablas", () => OperarRevit("CREAR"), true, 160, 1)));
        pie.Controls.Add(GrupoPie("Metrados por activo",
            BotonAsync("Actualizar activo", ActualizarActivo, true, 135, 2),
            BotonAsync("Federar metrados", FederarMetrados, true, 125, 2)));
        var cerrarDirecto = MYGProyectoUI.Boton("Cerrar"); cerrarDirecto.Width = 78; cerrarDirecto.Height = 32;
        cerrarDirecto.Click += (s, e) => Close();
        pie.Controls.Add(cerrarDirecto); medidas[cerrarDirecto] = new Rectangle(0, 25, 78, 32);
        foreach (var l in new[] { resumen, estado, estadoRevit }) { l.Font = new("Segoe UI", 8.5F); l.ForeColor = MYG2027_TemaComercial.Secundario; }
        enlaceRevit.Font = new("Segoe UI", 8.5F); enlaceRevit.LinkColor = MYG2027_TemaComercial.Azul;
        enlaceRevit.LinkClicked += (s, e) => MostrarConexionRevit();
        login.Font = new("Segoe UI", 8F, FontStyle.Bold); login.Click += (s, e) => { using var f = new LoginForm(sesion); f.ShowDialog(this); };
        inferior.Controls.AddRange(new WinForms.Control[] { pie, resumen, estado, enlaceRevit, login });
        revit.SelectedIndexChanged += (s, e) => { modelo = null; estadoRevit.Text = "Revit: pendiente de conectar"; ActualizarEstadoConexion(); };
        sesion.Cambio += EstadoSesion; FormClosing += Cerrar;
        Disposed += (s, e) => { sesion.Cambio -= EstadoSesion; componentesMenus.Dispose(); ayudas.Dispose(); revit.Dispose(); estadoRevit.Dispose(); };
        Shown += (s, e) => AjustarBarras(); ClientSizeChanged += (s, e) => AjustarBarras(); DpiChanged += (s, e) => AjustarBarras();
        InicializarPresupuestos(); CargarBiblioteca(); Refrescar(); EstadoSesion();
        MYG2027_TemaComercial.Aplicar(this); ActualizarTemaEditor(this, EventArgs.Empty);
    }

    private MYG2027_TarjetaComercial Grupo(string titulo, params WinForms.Control[] botones)
    {
        var g = MYG2027_TemaComercial.GrupoAcciones(titulo, botones); RegistrarMedidas(g); return g;
    }
    private WinForms.GroupBox GrupoPie(string titulo, params WinForms.Button[] botones)
    {
        int ancho = 16 + botones.Sum(b => b.Width + 8);
        var g = new WinForms.GroupBox
        {
            Text = titulo,
            Width = ancho,
            Height = 70,
            Font = new("Segoe UI", 8F, FontStyle.Bold),
            ForeColor = MYG2027_TemaComercial.Secundario,
            BackColor = Color.White,
            Margin = new(0, 0, 8, 8)
        };
        int x = 8;
        foreach (var b in botones) { b.SetBounds(x, 25, b.Width, 32); g.Controls.Add(b); x += b.Width + 8; }
        RegistrarMedidas(g); return g;
    }
    private void RegistrarMedidas(WinForms.Control g)
    { medidas[g] = g.Bounds; foreach (WinForms.Control c in g.Controls) medidas[c] = c.Bounds; }
    private WinForms.Button BotonAccion(string texto, Action accion, int estilo = 0, int ancho = 110)
        => BotonAsync(texto, () => { accion(); return Task.CompletedTask; }, true, ancho, estilo);
    private WinForms.Button BotonAsync(string texto, Func<Task> accion, bool necesitaLicencia, int ancho, int estilo = 0)
    {
        var b = MYGProyectoUI.Boton(texto, estilo); b.Width = ancho; b.Height = 30;
        MYGAnimacionUI.PrepararBoton(b);
        ayudas.SetToolTip(b, texto == "↶" ? "Deshacer (Ctrl+Z)" : texto == "↷" ? "Rehacer (Ctrl+Y)" : texto);
        b.Click += async (s, e) => await Ejecutar(accion, necesitaLicencia); return b;
    }
    private void ItemMenu(WinForms.ContextMenuStrip menu, string texto, Action accion)
        => ItemMenuAsync(menu, texto, () => { accion(); return Task.CompletedTask; });
    private void ItemMenuAsync(WinForms.ContextMenuStrip menu, string texto, Func<Task> accion)
    {
        menu.Items.Add(texto, null, (s, e) =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated) return;
            // El clic debe terminar antes de abrir un diálogo u otro menú.
            // ShowDialog procesa mensajes y podría liberar el menú anterior
            // mientras WinForms todavía está terminando su cierre.
            BeginInvoke(new Action(async () =>
            {
                if (IsDisposed || Disposing) return;
                await Ejecutar(accion);
            }));
        });
    }
    private WinForms.ContextMenuStrip CrearMenuContextual() => new(componentesMenus);
    private void MostrarMenu(WinForms.ContextMenuStrip menu)
    {
        if (IsDisposed || Disposing || !IsHandleCreated || menu.IsDisposed) return;
        menu.Closed += (s, e) =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated || menu.IsDisposed) return;
            // Closed aún forma parte del cierre interno de WinForms.
            // Se programa la liberación en la ventana, nunca en el propio menú.
            BeginInvoke(new Action(() =>
            {
                if (!menu.IsDisposed && !menu.Disposing) menu.Dispose();
            }));
        };
        menu.Show(this, PointToClient(WinForms.Cursor.Position));
    }
    private void MenuTitulo()
    {
        var m = CrearMenuContextual();
        ItemMenu(m, "Nuevo título en la raíz", () => NuevoNodo(true, 0));
        ItemMenu(m, "Nuevo título al mismo nivel", () => NuevoNodo(true, 1));
        ItemMenu(m, "Nuevo subtítulo dentro del seleccionado", () => NuevoNodo(true, 2)); MostrarMenu(m);
    }
    private void MenuNuevaPartida()
    {
        var m = CrearMenuContextual();
        ItemMenu(m, "Crear partida de texto", () => NuevoNodo(false, 2));
        ItemMenu(m, "Elegir del catálogo MYG", AbrirCatalogoPartidasPropio);
        ItemMenu(m, "Guardar partida en catálogo MYG", GuardarPartidaCatalogoSeleccionada);
        ItemMenu(m, "Elegir del catálogo Delphin", Catalogo); MostrarMenu(m);
    }
    private void MenuProyecto()
    {
        var m = CrearMenuContextual(); ItemMenu(m, "Administrar presupuestos / especialidades", MenuPresupuestos);
        ItemMenu(m, "Datos del proyecto", EditarDatosProyecto);
        m.Items.Add(new WinForms.ToolStripMenuItem("Volver a mis proyectos", null, (_, _) =>
        {
            if (IsHandleCreated) BeginInvoke(new Action(IrInicio));
        }));
        ItemMenu(m, "Guardar copia del proyecto como...", () => Guardar(true)); ItemMenuAsync(m, "Abrir otro proyecto...", AbrirProyecto);
        ItemMenuAsync(m, "Importar filtros antiguos (.json)", CargarData); m.Items.Add(new WinForms.ToolStripSeparator());
        ItemMenu(m, "Proyecto / biblioteca de presupuestos", MenuBiblioteca); MostrarMenu(m);
    }
    private void EditarDatosProyecto()
    {
        using var d = new MYGDatosProyectoForm(RutaCatalogoPropio(), documento.Nombre, documento.Datos,
            sesion.Credencial?.Usuario, "Datos del proyecto", documento.Id);
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        Recordar(); documento.Nombre = d.Nombre; documento.Datos = d.Datos; Refrescar();
    }
    private void MenuFila()
    {
        var m = CrearMenuContextual(); ItemMenu(m, "Nuevo título", MenuTitulo); ItemMenu(m, "Nueva partida", MenuNuevaPartida);
        ItemMenu(m, "Quitar propuesta", Quitar); m.Items.Add(new WinForms.ToolStripSeparator());
        ItemMenu(m, "Guardar filtros seleccionados", () => GuardarFiltros(false));
        ItemMenu(m, "Traer filtros seleccionados", () => TraerFiltros(true));
        ItemMenu(m, "Consultar valores Revit", () => { if (grid.CurrentCell != null) estado.Text = "Haga doble clic en la celda VALOR para consultar el modelo."; });
        ItemMenu(m, "Copiar", () => { var datos = grid.GetClipboardContent(); if (datos != null) WinForms.Clipboard.SetDataObject(datos); }); MostrarMenu(m);
    }
    private void AjustarBarras()
    {
        if (ajustandoBarras || !IsHandleCreated) return;
        ajustandoBarras = true; raiz.SuspendLayout();
        try
        {
            float escala = DeviceDpi / 96F; int E(int v) => (int)Math.Round(v * escala);
            int margen = E(20), ancho = Math.Max(1, ClientSize.Width - 2 * margen);
            bool compacto = ClientSize.Height / escala < 540F;
            foreach (WinForms.Control g in acciones.Controls)
            {
                Rectangle r = medidas[g]; g.Size = new(E(r.Width), E(compacto ? 46 : 70)); g.Margin = new(0, 0, E(10), E(8));
                foreach (WinForms.Control c in g.Controls)
                {
                    r = medidas[c]; c.SetBounds(E(r.X), E(c is WinForms.Button && compacto ? 8 : r.Y), E(r.Width), E(r.Height));
                    if (c is WinForms.Label) c.Visible = !compacto;
                }
            }
            foreach (WinForms.Control g in pie.Controls)
            {
                Rectangle r = medidas[g];
                if (g is WinForms.GroupBox)
                {
                    g.Size = new(E(r.Width), E(compacto ? 56 : 70)); g.Margin = new(0, 0, E(8), E(8));
                    foreach (WinForms.Control c in g.Controls) { r = medidas[c]; c.SetBounds(E(r.X), E(compacto ? 20 : r.Y), E(r.Width), E(r.Height)); }
                }
                else { g.Size = new(E(r.Width), E(r.Height)); g.Margin = new(0, E(compacto ? 20 : 25), 0, E(8)); }
            }
            acciones.Padding = new(margen, 0, margen, 0); acciones.AutoScroll = false; acciones.WrapContents = !compacto;
            pie.Padding = new(0); pie.SetBounds(margen, E(compacto ? 28 : 32), ancho, E(78)); pie.WrapContents = !compacto; pie.AutoScroll = false;
            acciones.PerformLayout(); pie.PerformLayout();
            int altoAcciones = Math.Max(E(78), MYG2027_TemaComercial.AlturaFlujo(acciones));
            int altoPie = Math.Max(E(78), MYG2027_TemaComercial.AlturaFlujo(pie));
            int altoCabecera = E(compacto ? 64 : 88), altoSelector = E(compacto ? 64 : 76);
            if (ClientSize.Height - altoCabecera - altoSelector - altoAcciones - altoPie - E(72) < E(132))
            {
                acciones.WrapContents = pie.WrapContents = false; acciones.AutoScroll = pie.AutoScroll = true;
                altoAcciones = E(compacto ? 76 : 100); altoPie = E(compacto ? 80 : 100);
            }
            raiz.RowStyles[0].Height = altoCabecera; raiz.RowStyles[1].Height = altoSelector;
            if (espacioPresupuestos != null) { raiz.RowStyles[0].Height = 0; raiz.RowStyles[1].Height = 0; }
            raiz.RowStyles[2].Height = altoAcciones; raiz.RowStyles[4].Height = pie.Top + altoPie + E(8); pie.Height = altoPie;
            marca.SetBounds(margen, E(compacto ? 7 : 12), ancho, E(compacto ? 29 : 32));
            int anchoArchivo = Math.Min(E(320), ancho / 3);
            proyectoNombre.SetBounds(margen, E(compacto ? 38 : 49), Math.Max(1, ancho - anchoArchivo - E(20)), E(compacto ? 22 : 32));
            archivoNombre.SetBounds(ClientSize.Width - margen - anchoArchivo, E(compacto ? 38 : 48), anchoArchivo, E(compacto ? 22 : 30));
            presupuestoTitulo.SetBounds(margen, E(13), ancho, E(20));
            if (espacioPresupuestos == null) presupuesto.SetBounds(margen, E(36), ancho, E(28));
            tablaPanel.Padding = new(margen, E(4), margen, E(compacto ? 8 : 12));
            cabeceraFiltros.Dock = WinForms.DockStyle.Top; cabeceraFiltros.Height = E(28);
            grid.Dock = WinForms.DockStyle.Fill; grid.BringToFront();
            resumen.SetBounds(margen, E(7), Math.Max(E(240), ancho / 2), E(20));
            login.SetBounds(ClientSize.Width - margen - E(105), E(3), E(105), E(25));
            enlaceRevit.SetBounds(login.Left - E(185), E(7), E(175), E(20));
            estado.SetBounds(resumen.Right + E(12), E(7), Math.Max(1, enlaceRevit.Left - resumen.Right - E(20)), E(20));
            grid.RowTemplate.Height = E(25); grid.ColumnHeadersHeight = E(38);
        }
        finally { raiz.ResumeLayout(true); ajustandoBarras = false; AlinearCabecera(); }
    }
    private void AlinearCabecera()
    {
        if (cargando || grid.Columns.Count == 0) return;
        cabeceraFiltros.CantidadFiltros = P?.CantidadFiltros ?? 1;
        float s = DeviceDpi / 96F;
        var limites = new Rectangle(0, 0, grid.ClientSize.Width - (grid.Controls.OfType<WinForms.VScrollBar>().Any(v => v.Visible) ? WinForms.SystemInformation.VerticalScrollBarWidth : 0), cabeceraFiltros.Height);
        var pares = new[] { (buscarItem, "ITEM"), (buscarPartida, "PARTIDA"), (buscarUnidad, "UNIDAD") };
        foreach (var (b, nombre) in pares)
        {
            if (!grid.Columns.Contains(nombre) || !grid.Columns[nombre].Visible) { b.Visible = false; continue; }
            var r = grid.GetColumnDisplayRectangle(grid.Columns[nombre].Index, false); r.Y = 1; r.Height = cabeceraFiltros.Height - 3;
            r = Rectangle.Intersect(r, limites); b.Visible = r.Width > 8;
            if (b.Visible) b.SetBounds(r.X + 1, 1, Math.Max(1, r.Width - 2), Math.Max(1, (int)(23 * s)));
        }
        cabeceraFiltros.Invalidate();
    }
    private async Task Ejecutar(Func<Task> accion, bool necesitaLicencia = true)
    {
        if (ocupado) return;
        ocupado = true; acciones.Enabled = presupuesto.Enabled = false; grid.Enabled = false; UseWaitCursor = true;
        EstadoCintaPresupuestos();
        try
        {
            if (necesitaLicencia && !await sesion.VerificarAsync()) throw new InvalidOperationException("Inicie sesión para continuar. Puede guardar el trabajo actual.");
            Sincronizar(); await accion();
        }
        catch (Exception ex) { estado.Text = ex.Message; MYGProyectoUI.Error(this, ex); }
        finally { ocupado = false; UseWaitCursor = false; grid.Enabled = true; EstadoSesion(); ActualizarResumen(); }
    }
    private void EstadoSesion()
    {
        if (IsDisposed) return;
        grid.ReadOnly = !sesion.Autorizado; acciones.Enabled = presupuesto.Enabled = !ocupado && sesion.Autorizado;
        estado.Text = sesion.Autorizado ? "Usuario: " + sesion.Credencial.Usuario : "Inicie sesión para continuar. Puede guardar el trabajo.";
        ActualizarEstadoConexion();
        ActualizarDisponibilidad();
        if (panelPresupuesto != null) panelPresupuesto.Enabled = !ocupado && sesion.Autorizado;
        EstadoCintaPresupuestos();
    }
    private void ActualizarEstadoConexion()
    {
        enlaceRevit.Text = modelo == null ? "Conectar Revit" : "Revit: " + modelo.Nombre;
        ayudas.SetToolTip(enlaceRevit, estadoRevit.Text + " · Clic para elegir el modelo o actualizar la conexión.");
    }
    private void ActualizarIndicadorArchivo()
    {
        bool pendiente = firmaGuardada == null || MYGProyectoStorage.Firma(documento) != firmaGuardada;
        archivoNombre.Text = "PROYECTO MYG: " + (string.IsNullOrWhiteSpace(archivo) ? "PENDIENTE DE GUARDAR" : Path.GetFileName(archivo)) + (pendiente && !string.IsNullOrWhiteSpace(archivo) ? " *" : "");
        ayudas.SetToolTip(archivoNombre, archivo ?? "El proyecto aún no tiene un archivo de trabajo.");
        CambiosPendientes = pendiente;
        ProyectoActualizado?.Invoke();
    }
    private void ActualizarResumen()
    {
        var items = P?.Items ?? new List<ItemPresupuestoDelphin>();
        int nuevas = items.Count(i => string.Equals(i.Estado, "PROPUESTA", StringComparison.OrdinalIgnoreCase));
        int modificar = items.Count(i => string.Equals(i.Estado, "PROP. MODIFICAR", StringComparison.OrdinalIgnoreCase));
        int eliminar = items.Count(i => string.Equals(i.Estado, "PROP. ELIMINAR", StringComparison.OrdinalIgnoreCase));
        resumen.Text = $"{items.Count} ítem(s)  |  {nuevas} propuesta(s) nueva(s)  |  {modificar} modificación(es) propuesta(s)  |  {eliminar} eliminación(es) propuesta(s)";
        ActualizarIndicadorArchivo();
        ActualizarDisponibilidad();
    }
    private void ActualizarDisponibilidad()
    {
        if (botonQuitar == null || cargando || aplicandoVista) return;
        var elegidas = Seleccionadas;
        bool propuestas = elegidas.Count > 0 && elegidas.All(i => string.IsNullOrWhiteSpace(i.IdInternoDelphin));
        botonQuitar.Enabled = !ocupado && sesion.Autorizado && propuestas;
        botonSubir.Enabled = botonBajar.Enabled = false;
        if (!ocupado && sesion.Autorizado && propuestas && elegidas.Count == 1 && P != null)
        {
            var i = elegidas[0];
            var hermanos = P.Items.Where(x => x.ParentId == i.ParentId).OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
            int indice = hermanos.IndexOf(i); botonSubir.Enabled = indice > 0; botonBajar.Enabled = indice >= 0 && indice < hermanos.Count - 1;
        }
        botonDeshacer.Enabled = !ocupado && sesion.Autorizado && undo.Count > 0;
        botonRehacer.Enabled = !ocupado && sesion.Autorizado && redo.Count > 0;
    }
    private void CargarBiblioteca()
    {
        rutaBiblioteca = MYGIndiceLocal.RutaBiblioteca();
        try { biblioteca = MYGProyectoStorage.LeerBiblioteca(rutaBiblioteca); }
        catch { biblioteca = null; estado.Text = "No se pudo leer la biblioteca seleccionada."; }
    }
    private MYGBibliotecaDocumento Banco()
    { CargarBiblioteca(); return biblioteca ?? throw new InvalidDataException("Seleccione una biblioteca válida."); }
    private void Recordar() { undo.Push(MYGProyectoStorage.Copia(documento)); redo.Clear(); ActualizarDisponibilidad(); }
    private void Historial(bool rehacer)
    {
        var desde = rehacer ? redo : undo; var hacia = rehacer ? undo : redo;
        if (desde.Count == 0) return; hacia.Push(MYGProyectoStorage.Copia(documento)); documento = desde.Pop(); Refrescar();
    }
    private void Refrescar()
    {
        var seleccion = Seleccionadas.Select(i => i.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        string activa = grid.CurrentCell?.OwningColumn.Name;
        cargando = true; grid.SuspendLayout();
        try
        {
            presupuesto.DataSource = documento.Presupuestos.ToList(); presupuesto.SelectedItem = P;
            proyectoNombre.Text = documento.Nombre; ayudas.SetToolTip(proyectoNombre, documento.Nombre);
            if (nombreProyectoPresupuesto != null) nombreProyectoPresupuesto.Text = documento.Nombre;
            grid.Rows.Clear(); grid.Columns.Clear(); CrearColumnas();
            if (P == null) return;
            var indices = P.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
            var padres = P.Items.Where(i => !string.IsNullOrWhiteSpace(i.ParentId)).Select(i => i.ParentId).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var i in OrdenJerarquia(P.Items))
            {
                bool titulo = MYGProyectoStorage.EsTitulo(i), libre = string.IsNullOrWhiteSpace(i.IdInternoDelphin);
                var f = MYGBibliotecaPartidas.FiltrosGuardables(i);
                var valores = new List<object>
                {
                    padres.Contains(i.Id) ? "−" : "", i.IdInternoDelphin ?? (libre ? "" : i.Id),
                    i.CodigoDelphin ?? i.CodigoCatalogoDelphin, i.IdPropuesta, i.Origen, i.Estado, i.Item,
                    string.IsNullOrWhiteSpace(i.PartidaPropuesta) ? i.Descripcion : i.PartidaPropuesta,
                    string.IsNullOrWhiteSpace(i.UnidadPropuesta) ? i.Unidad : i.UnidadPropuesta,
                    titulo ? "" : TextoEstadoRevit(i), titulo ? "" : i.Plantilla,
                    titulo ? "" : biblioteca == null ? "Revisar biblioteca" : MYGBibliotecaPartidas.Estado(biblioteca, i)
                };
                for (int n = 0; n < P.CantidadFiltros; n++)
                { var v = n < f.Count ? f[n] : new FiltroPlanificacion(); valores.AddRange(new object[] { v.Parametro ?? "", v.Regla ?? "", v.Valor ?? "" }); }
                var fila = grid.Rows[grid.Rows.Add(valores.ToArray())]; fila.Tag = i; fila.Height = (int)Math.Round(25F * DeviceDpi / 96F);
                fila.Cells["PARTIDA"].ReadOnly = fila.Cells["UNIDAD"].ReadOnly = !libre;
                int profundidad = 0; string padre = i.ParentId; var visitados = new HashSet<string>();
                while (!string.IsNullOrWhiteSpace(padre) && indices.TryGetValue(padre, out var p) && visitados.Add(padre)) { profundidad++; padre = p.ParentId; }
                if (titulo)
                {
                    foreach (WinForms.DataGridViewCell celda in fila.Cells) celda.ReadOnly = true;
                    fila.Cells["PARTIDA"].ReadOnly = !libre;
                    fila.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.ColorTitulo(profundidad);
                    fila.DefaultCellStyle.BackColor = MYG2027_TemaComercial.AzulSuave;
                    fila.DefaultCellStyle.Font = grid.ColumnHeadersDefaultCellStyle.Font;
                    foreach (WinForms.DataGridViewCell c in fila.Cells)
                        if (c.OwningColumn.Name == "PLANTILLA" || EsFiltro(c.OwningColumn.Name) || c.OwningColumn.Name == "BIBLIOTECA" || c.OwningColumn.Name == "REVIT")
                        { c.Value = ""; c.Style.BackColor = fila.DefaultCellStyle.BackColor; }
                }
                else { OpcionesFila(fila); ActualizarCeldaRevit(fila); }
                fila.Cells["ITEM"].Style.Padding = new((int)Math.Round(profundidad * 4F * DeviceDpi / 96F), 0, 0, 0);
            }
            grid.ClearSelection();
            foreach (WinForms.DataGridViewRow fila in grid.Rows)
                if (fila.Tag is ItemPresupuestoDelphin i && seleccion.Contains(i.Id))
                { var c = fila.Cells[activa != null && grid.Columns.Contains(activa) && grid.Columns[activa].Visible ? activa : grid.Columns.Cast<WinForms.DataGridViewColumn>().First(c => c.Visible).Name]; c.Selected = true; }
        }
        finally { cargando = false; grid.ResumeLayout(true); AplicarVista(); ActualizarResumen(); AlinearCabecera(); if (!cambiandoPresupuestoEstructura) panelPresupuesto?.Refrescar(); RefrescarCronogramaEditor(); }
    }
    private void CrearColumnas()
    {
        void Texto(string nombre, string titulo, int ancho, bool soloLectura = true)
        {
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn
            {
                Name = nombre,
                HeaderText = titulo,
                Width = (int)Math.Round((anchosColumnas.TryGetValue(nombre, out var guardado) ? guardado : ancho) * DeviceDpi / 96F),
                ReadOnly = soloLectura,
                SortMode = WinForms.DataGridViewColumnSortMode.NotSortable
            });
        }
        Texto("EXPANDIR", "", 32); Texto("CODIGO", "ID INTERNO", 145); Texto("CODIGO_DELPHIN", "COD. DELPHIN", 105);
        Texto("ID_PROPUESTA", "ID PROPUESTA", 125); Texto("ORIGEN", "ORIGEN", 80); Texto("ESTADO", "ESTADO", 95);
        Texto("ITEM", "ITEM", 145); Texto("PARTIDA", "PARTIDA", 420, false); Texto("UNIDAD", "UNIDAD", 85, false);
        Texto("REVIT", "REVIT", 115); Texto("PLANTILLA", "PLANTILLA", 220, false); Texto("BIBLIOTECA", "BIBLIOTECA BIM", 165);
        grid.Columns["PARTIDA"].MinimumWidth = (int)Math.Round(280F * DeviceDpi / 96F); grid.Columns["PARTIDA"].FillWeight = 220;
        grid.Columns["PARTIDA"].AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill;
        grid.Columns["PLANTILLA"].MinimumWidth = (int)Math.Round(180F * DeviceDpi / 96F); grid.Columns["PLANTILLA"].FillWeight = 110;
        grid.Columns["PLANTILLA"].AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill;
        foreach (string c in new[] { "EXPANDIR", "UNIDAD", "REVIT" })
        { grid.Columns[c].DefaultCellStyle.Alignment = WinForms.DataGridViewContentAlignment.MiddleCenter; grid.Columns[c].HeaderCell.Style.Alignment = WinForms.DataGridViewContentAlignment.MiddleCenter; }
        grid.Columns["REVIT"].DefaultCellStyle.Font = new("Segoe UI", 8.2F, FontStyle.Bold);
        for (int n = 1; n <= (P?.CantidadFiltros ?? 1); n++)
        {
            foreach (var c in new[] { ("P", "PARÁMETRO", 155), ("R", "REGLA", 145), ("V", "VALOR", 160) })
            {
                Texto(c.Item1 + n, c.Item2, c.Item3, false);
                var col = grid.Columns[c.Item1 + n]; col.DefaultCellStyle.BackColor = MYG2027_TemaComercial.ColorFiltro(n);
                col.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto; col.DefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
                col.DefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.Texto; col.HeaderCell.Style.BackColor = MYG2027_TemaComercial.ColorCabeceraFiltro(n);
                col.HeaderCell.Style.ForeColor = MYG2027_TemaComercial.Texto; col.HeaderCell.Style.SelectionBackColor = col.HeaderCell.Style.BackColor;
                col.HeaderCell.Style.SelectionForeColor = MYG2027_TemaComercial.Texto;
            }
        }
        foreach (WinForms.DataGridViewColumn c in grid.Columns) c.Visible = !columnasOcultas.Contains(c.Name);
    }
    private static bool EsFiltro(string col) => col.Length > 1 && col[0] is 'P' or 'R' or 'V' && int.TryParse(col[1..], out _);
    private static IEnumerable<ItemPresupuestoDelphin> OrdenJerarquia(List<ItemPresupuestoDelphin> items, string padre = null)
    {
        foreach (var i in items.Where(x => string.IsNullOrWhiteSpace(padre) ? string.IsNullOrWhiteSpace(x.ParentId) : x.ParentId == padre).OrderBy(x => x.Posicion).ThenBy(x => x.Item))
        { yield return i; foreach (var hijo in OrdenJerarquia(items, i.Id)) yield return hijo; }
    }
    private void Combo(WinForms.DataGridViewRow fila, string columna, IEnumerable<string> opciones)
    {
        string valor = fila.Cells[columna].Value?.ToString() ?? "";
        var valores = new[] { "" }.Concat(opciones ?? Enumerable.Empty<string>()).Concat(new[] { valor }).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        var estilo = fila.Cells[columna].Style.Clone();
        var c = new WinForms.DataGridViewComboBoxCell { FlatStyle = WinForms.FlatStyle.Flat, DisplayStyle = WinForms.DataGridViewComboBoxDisplayStyle.DropDownButton, Style = estilo };
        c.Items.AddRange(valores); c.Value = valores.FirstOrDefault(v => string.Equals(v, valor, StringComparison.OrdinalIgnoreCase)) ?? valor;
        fila.Cells[columna] = c;
    }
    private void OpcionesFila(WinForms.DataGridViewRow fila)
    {
        if (fila.Tag is not ItemPresupuestoDelphin i || MYGProyectoStorage.EsTitulo(i)) return;
        bool anterior = cargando; cargando = true;
        try
        {
            Combo(fila, "PLANTILLA", modelo?.Plantillas); string plantilla = fila.Cells["PLANTILLA"].Value?.ToString();
            for (int n = 1; n <= (P?.CantidadFiltros ?? 1); n++)
            {
                var campos = modelo != null && modelo.Parametros.TryGetValue(plantilla ?? "", out var cp) ? cp : new List<string>();
                Combo(fila, "P" + n, campos); string parametro = fila.Cells["P" + n].Value?.ToString();
                var reglas = modelo != null && modelo.Reglas.TryGetValue(plantilla ?? "", out var rp) && rp.TryGetValue(parametro ?? "", out var rs) ? rs : new List<string>();
                Combo(fila, "R" + n, reglas); Combo(fila, "V" + n, Array.Empty<string>());
            }
        }
        finally { cargando = anterior; }
    }
    private static string TextoEstadoRevit(ItemPresupuestoDelphin i) => (i.EstadoRevit ?? "").ToUpperInvariant() switch
    {
        "LISTO" => "✓ LISTO",
        "ALERTA" => "⚠ ALERTA",
        "ERROR" => "✕ ERROR",
        "SIN BIM" => "— SIN BIM",
        _ => MYGProyectoStorage.TieneBim(i) ? "○ SIN REVISAR" : "— SIN BIM"
    };
    private void ActualizarCeldaRevit(WinForms.DataGridViewRow fila)
    {
        if (fila.Tag is not ItemPresupuestoDelphin i || MYGProyectoStorage.EsTitulo(i)) return;
        var c = fila.Cells["REVIT"]; c.Value = TextoEstadoRevit(i); c.ToolTipText = i.MensajeRevit ?? "Pulse Revisar Revit para comprobar la configuración contra el modelo conectado.";
        bool oscuro = MYG2027_TemaComercial.Oscuro;
        (Color fondo, Color texto) = (i.EstadoRevit ?? "").ToUpperInvariant() switch
        {
            "LISTO" => oscuro ? (Color.FromArgb(30, 55, 46), Color.FromArgb(129, 220, 167)) : (Color.FromArgb(232, 247, 239), Color.FromArgb(25, 119, 77)),
            "ERROR" => oscuro ? (Color.FromArgb(65, 36, 42), Color.FromArgb(255, 157, 157)) : (Color.FromArgb(255, 235, 235), Color.Firebrick),
            "ALERTA" => oscuro ? (Color.FromArgb(58, 50, 31), Color.FromArgb(244, 208, 123)) : (Color.FromArgb(255, 249, 230), Color.FromArgb(145, 102, 0)),
            _ => (MYG2027_TemaComercial.Superficie, MYG2027_TemaComercial.Secundario)
        };
        c.Style.BackColor = fondo; c.Style.ForeColor = texto;
    }

    private void ActualizarTemaEditor(object sender, EventArgs e)
    {
        if (IsDisposed || Disposing || WinForms.SystemInformation.HighContrast) return;
        // Recolorear sin reconstruir filas ni cerrar la celda que se está editando.
        foreach (WinForms.DataGridViewColumn columna in grid.Columns)
        {
            if (!EsFiltro(columna.Name)) continue;
            int numero = int.Parse(columna.Name[1..], CultureInfo.InvariantCulture);
            columna.DefaultCellStyle.BackColor = MYG2027_TemaComercial.ColorFiltro(numero);
            columna.DefaultCellStyle.ForeColor = columna.DefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.Texto;
            columna.DefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
            columna.HeaderCell.Style.BackColor = columna.HeaderCell.Style.SelectionBackColor = MYG2027_TemaComercial.ColorCabeceraFiltro(numero);
            columna.HeaderCell.Style.ForeColor = columna.HeaderCell.Style.SelectionForeColor = MYG2027_TemaComercial.Texto;
        }
        var items = (P?.Items ?? new()).ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
        foreach (WinForms.DataGridViewRow fila in grid.Rows)
        {
            if (fila.Tag is not ItemPresupuestoDelphin item) continue;
            if (!MYGProyectoStorage.EsTitulo(item)) { ActualizarCeldaRevit(fila); continue; }
            int nivel = 0; string padre = item.ParentId; var visitados = new HashSet<string>();
            while (!string.IsNullOrWhiteSpace(padre) && items.TryGetValue(padre, out var superior) && visitados.Add(padre))
            { nivel++; padre = superior.ParentId; }
            fila.DefaultCellStyle.BackColor = MYG2027_TemaComercial.AzulSuave;
            fila.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.ColorTitulo(nivel);
            foreach (WinForms.DataGridViewCell celda in fila.Cells)
                if (celda.OwningColumn.Name is "PLANTILLA" or "BIBLIOTECA" or "REVIT" || EsFiltro(celda.OwningColumn.Name))
                    celda.Style.BackColor = fila.DefaultCellStyle.BackColor;
        }
        panelPresupuesto?.AplicarTemaPresupuestos();
        panelCronograma?.AplicarTema();
        EstadoHerramientasCronograma();
        cabeceraFiltros.Invalidate(); grid.Invalidate();
    }
    private void Sincronizar()
    {
        if (cronogramaVisible) panelCronograma?.FinalizarEdicion();
        panelPresupuesto?.FinalizarEdicion();
        if (cargando || sincronizando || P == null) return;
        sincronizando = true;
        try
        {
            grid.EndEdit();
            foreach (WinForms.DataGridViewRow fila in grid.Rows)
            {
                if (fila.Tag is not ItemPresupuestoDelphin i) continue;
                string Celda(string nombre) => fila.Cells[nombre].Value?.ToString();
                if (string.IsNullOrWhiteSpace(i.IdInternoDelphin)) { i.Descripcion = Celda("PARTIDA"); i.Unidad = Celda("UNIDAD"); }
                if (MYGProyectoStorage.EsTitulo(i)) continue;
                i.Plantilla = Celda("PLANTILLA"); i.Filtros = new();
                for (int n = 1; n <= P.CantidadFiltros; n++) i.Filtros.Add(new() { Parametro = Celda("P" + n), Regla = Celda("R" + n), Valor = Celda("V" + n) });
                i.Parametro = null; i.Regla = null; i.Valor = null; i.Filtros = MYGBibliotecaPartidas.FiltrosGuardables(i);
                var f = i.Filtros.FirstOrDefault(); i.Parametro = f?.Parametro; i.Regla = f?.Regla; i.Valor = f?.Valor;
                fila.Cells["BIBLIOTECA"].Value = biblioteca == null ? "Revisar biblioteca" : MYGBibliotecaPartidas.Estado(biblioteca, i);
            }
        }
        finally { sincronizando = false; }
    }
    private void AplicarVista()
    {
        if (cargando || aplicandoVista || P == null) return;
        aplicandoVista = true;
        try
        {
            Sincronizar();
            var indices = P.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
            bool busqueda = buscarItem.Text.Length + buscarPartida.Text.Length + buscarUnidad.Text.Length > 0;
            var permitidos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            bool Coincide(string valor, string filtro) => (valor ?? "").Contains(filtro.Trim(), StringComparison.OrdinalIgnoreCase);
            if (busqueda)
                foreach (var i in P.Items.Where(i => Coincide(i.Item, buscarItem.Text) && Coincide(i.Descripcion, buscarPartida.Text) && Coincide(i.Unidad, buscarUnidad.Text)))
                {
                    permitidos.Add(i.Id); string padre = i.ParentId; var visitados = new HashSet<string>();
                    while (!string.IsNullOrWhiteSpace(padre) && indices.TryGetValue(padre, out var p) && visitados.Add(padre)) { permitidos.Add(padre); padre = p.ParentId; }
                }
            var seleccion = Seleccionadas.Select(i => i.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
            string colActual = grid.CurrentCell?.OwningColumn.Name; grid.CurrentCell = null;
            foreach (WinForms.DataGridViewRow fila in grid.Rows)
            {
                var i = (ItemPresupuestoDelphin)fila.Tag; bool visible = !busqueda || permitidos.Contains(i.Id);
                if (!busqueda)
                {
                    string padre = i.ParentId; var visitados = new HashSet<string>();
                    while (!string.IsNullOrWhiteSpace(padre) && indices.TryGetValue(padre, out var p) && visitados.Add(padre))
                    { if (Contraidos.Contains(padre)) { visible = false; break; } padre = p.ParentId; }
                }
                fila.Visible = visible;
                if (P.Items.Any(h => h.ParentId == i.Id)) fila.Cells["EXPANDIR"].Value = busqueda || !Contraidos.Contains(i.Id) ? "−" : "+";
            }
            grid.ClearSelection();
            foreach (WinForms.DataGridViewRow fila in grid.Rows)
                if (fila.Visible && fila.Tag is ItemPresupuestoDelphin i && seleccion.Contains(i.Id))
                { string col = colActual != null && grid.Columns.Contains(colActual) && grid.Columns[colActual].Visible ? colActual : grid.Columns.Cast<WinForms.DataGridViewColumn>().First(c => c.Visible).Name; fila.Cells[col].Selected = true; }
        }
        finally { aplicandoVista = false; ActualizarDisponibilidad(); }
    }
    private void PlegarTodo(bool plegar)
    { Contraidos.Clear(); if (plegar && P != null) foreach (var i in P.Items.Where(i => P.Items.Any(h => h.ParentId == i.Id))) Contraidos.Add(i.Id); AplicarVista(); }


    private void CambiarFiltros(int delta)
    {
        if (P == null) return; int cantidad = Math.Clamp(P.CantidadFiltros + delta, 1, 8); if (cantidad == P.CantidadFiltros) return;
        if (delta < 0 && Partidas.Any(i => i.Filtros.Count > cantidad && !i.Filtros[cantidad].EstaVacio()) &&
            WinForms.MessageBox.Show(this, "Se quitarán los filtros de la última columna. ¿Continuar?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNo) != WinForms.DialogResult.Yes) return;
        Recordar(); P.CantidadFiltros = cantidad;
        foreach (var i in Partidas) if (i.Filtros.Count > cantidad) i.Filtros.RemoveRange(cantidad, i.Filtros.Count - cantidad); Refrescar();
    }
    private void NuevoNodo(bool titulo, int ubicacion)
    {
        if (P == null) throw new InvalidOperationException("Cree un presupuesto.");
        var elegida = Seleccionadas.FirstOrDefault(); string padre = null;
        if (ubicacion == 1) padre = elegida?.ParentId;
        if (ubicacion == 2) padre = MYGProyectoStorage.EsTitulo(elegida) ? elegida.Id : elegida?.ParentId;
        var parametros = titulo ? null : MYGParametrosUsuario.Leer();
        using var d = new MYGCamposProyectoForm(titulo ? "Nuevo título" : "Nueva partida", titulo ? new[] { "Nombre" } : new[] { "Descripción", "Unidad" }, titulo ? new[] { "" } : new[] { "", parametros.UnidadPartida },
            unidades: titulo ? null : MYGCatalogoUnidades.Listar(RutaCatalogoPropio()), conservarUnidadInicial: true);
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return; Recordar(); string id = MYGProyectoStorage.NuevoId();
        var nuevo = new ItemPresupuestoDelphin
        {
            Id = id,
            IdLocalMYG = id,
            IdPropuesta = id,
            Descripcion = d.Valores[0],
            Unidad = titulo ? "" : d.Valores[1],
            ParentId = padre,
            TipoPropuesta = titulo ? "TITULO" : "PARTIDA",
            Origen = "MODELO",
            Estado = "PROPUESTA",
            Posicion = P.Items.Where(i => i.ParentId == padre).Select(i => i.Posicion).DefaultIfEmpty().Max() + 1,
            Item = "P-" + (P.Items.Count + 1).ToString("D3")
        };
        if (!titulo) { parametros.Aplicar(nuevo); nuevo.Unidad = d.Valores[1]; }
        P.Items.Add(nuevo);
        if (P.Conexion == null) MYGProyectoStorage.Renumerar(P); Refrescar();
    }
    private void Catalogo()
    {
        if (P == null) return;
        using var d = new MYGCatalogoPartidasForm(documento.FuenteCatalogo, P.Items, P.Conexion?.FuenteId, Banco());
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return; Recordar(); documento.FuenteCatalogo = d.Fuente;
        var a = d.Seleccionada; var elegida = Seleccionadas.FirstOrDefault(); string id = MYGProyectoStorage.NuevoId();
        var i = new ItemPresupuestoDelphin
        {
            Id = id,
            IdLocalMYG = id,
            IdPropuesta = id,
            Descripcion = a.Descripcion,
            Unidad = a.Unidad,
            IdCatalogoDelphin = a.Id,
            FuenteCatalogoId = a.FuenteId,
            FuenteCatalogoRuta = a.RutaSQLite,
            CodigoCatalogoDelphin = a.Codigo,
            CodigoDelphin = a.Codigo,
            TipoPropuesta = "PARTIDA",
            Origen = "MODELO",
            Estado = "PROPUESTA",
            ParentId = MYGProyectoStorage.EsTitulo(elegida) ? elegida.Id : elegida?.ParentId,
            Posicion = P.Items.Count + 1,
            Item = "P-" + (P.Items.Count + 1).ToString("D3")
        };
        if (d.ConfiguracionSeleccionada != null) MYGBibliotecaPartidas.Aplicar(i, d.ConfiguracionSeleccionada);
        P.Items.Add(i); if (P.Conexion == null) MYGProyectoStorage.Renumerar(P); AsegurarColumnas(); Refrescar();
    }
    private void AsegurarColumnas() { if (P != null) P.CantidadFiltros = Math.Max(P.CantidadFiltros, Math.Clamp(Partidas.Select(i => i.Filtros?.Count ?? 0).DefaultIfEmpty(1).Max(), 1, 8)); }
    private void MenuPresupuestos()
    {
        var m = CrearMenuContextual();
        ItemMenu(m, "Agregar presupuesto", () => AgregarPresupuestoEnTabla());
        ItemMenu(m, "Añadir presupuesto Delphin", AnadirPresupuestoDelphin);
        ItemMenu(m, "Renombrar presupuesto", () => { if (P == null) return; using var d = new MYGCamposProyectoForm("Renombrar presupuesto", new[] { "Código", "Nombre" }, new[] { P.Item, P.Nombre }); if (d.ShowDialog(this) != WinForms.DialogResult.OK) return; Recordar(); P.Item = d.Valores[0]; P.Nombre = d.Valores[1]; Refrescar(); });
        ItemMenu(m, "Eliminar presupuesto MYG", () => { if (P == null || WinForms.MessageBox.Show(this, "¿Eliminar este presupuesto del proyecto MYG?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNo) != WinForms.DialogResult.Yes) return; Recordar(); documento.Presupuestos.Remove(P); documento.PresupuestoActivoId = documento.Presupuestos.FirstOrDefault()?.Id; Refrescar(); });
        MostrarMenu(m);
    }
    private void AnadirPresupuestoDelphin()
    {
        using var d = new MYGConectarDelphinForm(null, documento.FuenteCatalogo?.RutaSQLite);
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        var c = d.Conexion;
        var anterior = documento.Presupuestos.FirstOrDefault(p => p.Conexion?.FuenteId == c.FuenteId && p.Conexion.ProyectoId == c.ProyectoId && p.Conexion.PresupuestoId == c.PresupuestoId);
        if (anterior != null) { documento.PresupuestoActivoId = anterior.Id; Refrescar(); estado.Text = "El presupuesto ya está incluido en este proyecto."; return; }
        var p = new MYGPresupuestoDocumento { Nombre = d.NombrePresupuesto, Item = d.CodigoPresupuesto, Posicion = documento.Presupuestos.Count + 1, Conexion = c };
        MYGProyectoStorage.ActualizarDesdeDelphin(p, LectorDelphin.LeerItemsPresupuestoSQLite(c.RutaSQLite, c.PresupuestoId));
        Recordar(); documento.Presupuestos.Add(p); documento.PresupuestoActivoId = p.Id; documento.FuenteCatalogo = new() { Id = c.FuenteId, RutaSQLite = c.RutaSQLite }; MYGProyectoStorage.Validar(documento); Refrescar();
    }
    private void Quitar()
    {
        var elegidas = Seleccionadas; if (elegidas.Any(i => !string.IsNullOrWhiteSpace(i.IdInternoDelphin))) throw new InvalidOperationException("Esta acción elimina propuestas MYG. Las filas oficiales se mantienen en Delphin.");
        if (elegidas.Count == 0) return;
        var ids = elegidas.Select(i => i.Id).ToHashSet(); bool mas; do { mas = false; foreach (var i in P.Items) if (ids.Contains(i.ParentId ?? "") && ids.Add(i.Id)) mas = true; } while (mas);
        if (P.Items.Any(i => ids.Contains(i.Id) && !string.IsNullOrWhiteSpace(i.IdInternoDelphin)))
            throw new InvalidOperationException("El título contiene filas oficiales de Delphin. Seleccione únicamente las propuestas que desea quitar.");
        var locales = P.Items.Where(i => ids.Contains(i.Id)).Select(i => i.IdLocalMYG).ToHashSet();
        if (P.Items.Any(i => !ids.Contains(i.Id) && i.Costos.Analisis.Any(r => locales.Contains(r.SubpartidaIdLocal))))
            throw new InvalidOperationException("Una partida que desea quitar está usada como subanálisis. Quite esa referencia del ACU primero.");
        if (WinForms.MessageBox.Show(this, "¿Quitar " + ids.Count + " fila(s) del proyecto MYG?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNo) != WinForms.DialogResult.Yes) return;
        Recordar(); P.Items.RemoveAll(i => ids.Contains(i.Id)); if (P.Conexion == null) MYGProyectoStorage.Renumerar(P); Refrescar();
    }
    private bool Guardar(bool como)
    {
        panelCronograma?.GuardarTiempoTrabajoPendiente();
        Sincronizar(); string destino = archivo;
        if (como || string.IsNullOrWhiteSpace(destino))
        {
            using var d = new WinForms.SaveFileDialog
            {
                Filter = "Base SQLite (*.sqlite)|*.sqlite",
                DefaultExt = "sqlite",
                AddExtension = true,
                FileName = string.IsNullOrWhiteSpace(archivo) ? "MYG_PRESUPUESTOS.sqlite" : Path.ChangeExtension(Path.GetFileName(archivo), ".sqlite")
            };
            if (d.ShowDialog(this) != WinForms.DialogResult.OK) return false; destino = d.FileName;
        }
        if (!MYGBaseDatos.EsRutaSQLite(destino))
            throw new InvalidOperationException("Guarde el proyecto en un archivo con extensión .sqlite.");
        string origenCatalogos = null;
        bool cambiaArchivo = !string.IsNullOrWhiteSpace(archivo) &&
            !string.Equals(Path.GetFullPath(destino), Path.GetFullPath(archivo), StringComparison.OrdinalIgnoreCase);
        if (cambiaArchivo)
        {
            string destinoBase = MYGBaseDatos.RutaDeProyecto(destino);
            string origenBase = MYGBaseDatos.RutaDeProyecto(archivo);
            bool mismaBase = string.Equals(destinoBase, origenBase, StringComparison.OrdinalIgnoreCase);
            if (!mismaBase && File.Exists(destinoBase))
                throw new InvalidOperationException("Para Guardar como elija un archivo SQLite nuevo; así se conserva el catálogo completo de origen.");
            if (!mismaBase) origenCatalogos = MYGBaseDatos.AsegurarParaProyecto(archivo, documento);
        }
        var copia = MYGProyectoStorage.Copia(documento);
        if (origenCatalogos != null)
        {
            string nuevaBase = MYGBaseDatos.RutaDeProyecto(destino);
            foreach (var p in copia.Presupuestos)
            {
                foreach (var i in p.Items)
                    if (!string.IsNullOrWhiteSpace(i.Costos.CatalogoMYGRuta) && string.Equals(Path.GetFullPath(i.Costos.CatalogoMYGRuta), origenCatalogos, StringComparison.OrdinalIgnoreCase))
                        i.Costos.CatalogoMYGRuta = nuevaBase;
                foreach (var i in p.Costos.Insumos)
                    if (!string.IsNullOrWhiteSpace(i.CatalogoMYGRuta) && string.Equals(Path.GetFullPath(i.CatalogoMYGRuta), origenCatalogos, StringComparison.OrdinalIgnoreCase))
                        i.CatalogoMYGRuta = nuevaBase;
            }
        }
        MYGProyectoStorage.Guardar(destino, copia, origenCatalogos);
        documento = copia; archivo = destino; ProyectoGuardado?.Invoke(archivo); Refrescar(); firmaGuardada = MYGProyectoStorage.Firma(documento); MYGIndiceLocal.Registrar(documento, archivo); ActualizarIndicadorArchivo(); estado.Text = "Proyecto guardado: " + Path.GetFileName(archivo); return true;
    }
    private void Cerrar(object sender, WinForms.FormClosingEventArgs e)
    {
        if (cierreConfirmado) return;
        if (ocupado) { e.Cancel = true; estado.Text = "Espere a que finalice la operación."; return; }
        try
        {
            if (panelCronograma?.ConfirmarSalidaTiempoTrabajo() == false) { e.Cancel = true; return; }
            Sincronizar(); if (MYGProyectoStorage.Firma(documento) == firmaGuardada) return; var r = WinForms.MessageBox.Show(this, "Hay cambios pendientes. ¿Guardar antes de cerrar?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNoCancel);
            if (r == WinForms.DialogResult.Cancel || (r == WinForms.DialogResult.Yes && !Guardar(false))) e.Cancel = true;
        }
        catch (Exception ex) { e.Cancel = true; MYGProyectoUI.Error(this, ex); }
    }
    private void GuardarFiltros(bool todas)
    {
        var items = (todas ? Partidas : Seleccionadas.Where(i => !MYGProyectoStorage.EsTitulo(i))).Where(MYGProyectoStorage.TieneBim).ToList();
        if (items.Count == 0) throw new InvalidOperationException("Seleccione partidas que tengan plantilla y filtros.");
        using var d = new MYGGuardarConfiguracionesForm(items, Banco(), rutaBiblioteca); if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        biblioteca = MYGBibliotecaPartidas.GuardarConfiguraciones(rutaBiblioteca, biblioteca, d.Solicitudes); Refrescar();
    }
    private string Revision(MYGConfiguracionPartida c)
    {
        if (modelo == null) return "Revisar: no hay un modelo conectado";
        if (!modelo.Parametros.TryGetValue(c.Plantilla ?? "", out var p)) return "Revisar: plantilla ausente en el modelo";
        if (c.Filtros.Any(f => !f.EstaVacio() && !p.Contains(f.Parametro, StringComparer.OrdinalIgnoreCase))) return "Revisar: parámetro ausente en la plantilla";
        return "Plantilla disponible; ejecutar Revisar Revit";
    }
    private void TraerFiltros(bool seleccion)
    {
        using var d = new MYGAplicarConfiguracionesForm(seleccion ? Seleccionadas : Partidas, Banco(), Revision);
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        int reemplazos = d.Solicitudes.Count(s => MYGProyectoStorage.TieneBim(s.Partida));
        if (reemplazos > 0 && WinForms.MessageBox.Show(this, "Se reemplazarán los filtros de " + reemplazos + " partida(s). ¿Continuar?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNo) != WinForms.DialogResult.Yes) return;
        var cambio = MYGProyectoStorage.Copia(biblioteca); cambio.FirmaLectura = biblioteca.FirmaLectura;
        if (d.RecordarAsociaciones) { foreach (var s in d.Solicitudes) MYGBibliotecaPartidas.Asociar(cambio.Configuraciones.Single(c => c.Id == s.Configuracion.Id), s.Partida); MYGBibliotecaPartidas.Guardar(rutaBiblioteca, cambio); biblioteca = cambio; }
        Recordar(); foreach (var s in d.Solicitudes) MYGBibliotecaPartidas.Aplicar(s.Partida, s.Configuracion, true); AsegurarColumnas(); Refrescar();
    }
    private void MenuBiblioteca()
    {
        var m = CrearMenuContextual();
        ItemMenu(m, "Guardar filtros de todas las partidas configuradas", () => GuardarFiltros(true));
        ItemMenu(m, "Traer filtros a las partidas seleccionadas", () => TraerFiltros(true));
        ItemMenu(m, "Elegir biblioteca existente", () => { using var d = new WinForms.OpenFileDialog { Filter = "Biblioteca MYG (*.biblioteca.json;*.json)|*.biblioteca.json;*.json" }; if (d.ShowDialog(this) == WinForms.DialogResult.OK) { MYGProyectoStorage.LeerBiblioteca(d.FileName); MYGIndiceLocal.RecordarBiblioteca(d.FileName); CargarBiblioteca(); Refrescar(); } });
        ItemMenu(m, "Crear biblioteca en otra ubicación", () => { using var d = new WinForms.SaveFileDialog { Filter = "Biblioteca MYG (*.biblioteca.json)|*.biblioteca.json", FileName = "MYG_BIBLIOTECA.biblioteca.json" }; if (d.ShowDialog(this) == WinForms.DialogResult.OK) { MYGProyectoStorage.LeerBiblioteca(d.FileName); MYGIndiceLocal.RecordarBiblioteca(d.FileName); CargarBiblioteca(); Refrescar(); } });
        ItemMenu(m, "Ver ubicación", () => WinForms.MessageBox.Show(this, rutaBiblioteca, "Biblioteca MYG"));
        ItemMenu(m, "Guardar presupuesto completo en biblioteca", () => { if (P == null) throw new InvalidOperationException("Cree un presupuesto."); using var d = new MYGCamposProyectoForm("Guardar presupuesto", new[] { "Nombre de la plantilla" }, new[] { P.Nombre }); if (d.ShowDialog(this) != WinForms.DialogResult.OK) return; MYGProyectoStorage.AgregarPlantilla(rutaBiblioteca, d.Valores[0], P); CargarBiblioteca(); });
        ItemMenu(m, "Usar presupuesto de biblioteca", () => { using var d = new MYGElegirPlantillaForm(Banco().Plantillas); if (d.ShowDialog(this) != WinForms.DialogResult.OK) return; Recordar(); var p = MYGProyectoStorage.CopiarComoPlantilla(d.Elegida.Presupuesto, d.Elegida.Nombre); p.Posicion = documento.Presupuestos.Count + 1; documento.Presupuestos.Add(p); documento.PresupuestoActivoId = p.Id; Refrescar(); });
        MostrarMenu(m);
    }
    private async Task CargarData()
    {
        if (!Partidas.Any()) throw new InvalidOperationException("Agregue o cargue las partidas que recibirán los filtros.");
        using var f = new WinForms.OpenFileDialog { Filter = "Filtros antiguos (*.json)|*.json" }; if (f.ShowDialog(this) != WinForms.DialogResult.OK) return;
        string ruta = f.FileName;
        var datos = await MYGCargaAnimada.EjecutarAsync(this, "Leyendo filtros…", () => MYGDataFiltrosStorage.Leer(ruta));
        if (!sesion.Autorizado) throw new InvalidOperationException("Inicie sesión para importar filtros.");
        using var d = new MYGCargarDataFiltrosForm(datos, P.Items, Path.GetFileName(ruta));
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        if (d.Solicitudes.Any(s => MYGProyectoStorage.TieneBim(s.Destino)) && WinForms.MessageBox.Show(this, "Se reemplazarán las configuraciones seleccionadas. ¿Continuar?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNo) != WinForms.DialogResult.Yes) return;
        if (!sesion.Autorizado) throw new InvalidOperationException("Inicie sesión para importar filtros.");
        Recordar(); MYGDataFiltrosStorage.Aplicar(d.Solicitudes); AsegurarColumnas(); Refrescar(); estado.Text = "Filtros importados. Guardar filtros incorpora las configuraciones a la biblioteca.";
    }
    private async Task ConectarDelphin()
    {
        using var d = new MYGConectarDelphinForm(P?.Conexion, documento.FuenteCatalogo?.RutaSQLite);
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        var c = d.Conexion;
        var items = await MYGCargaAnimada.EjecutarAsync(this, "Cargando partidas Delphin…", () => LectorDelphin.LeerItemsPresupuestoSQLite(c.RutaSQLite, c.PresupuestoId));
        if (!sesion.Autorizado) throw new InvalidOperationException("Inicie sesión para actualizar el presupuesto.");
        Recordar();
        if (P == null) { var p = new MYGPresupuestoDocumento { Nombre = "PRESUPUESTO DELPHIN", Item = "01" }; documento.Presupuestos.Add(p); documento.PresupuestoActivoId = p.Id; }
        if (P.Conexion != null && P.Conexion.FuenteId != c.FuenteId)
        {
            if (WinForms.MessageBox.Show(this, "La base seleccionada es distinta. Las filas anteriores se conservarán como propuestas. ¿Continuar?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNo) != WinForms.DialogResult.Yes) return;
            P.Items = MYGProyectoStorage.DesvincularComoPropuestas(P);
        }
        P.Conexion = c; documento.FuenteCatalogo = new() { Id = c.FuenteId, RutaSQLite = c.RutaSQLite };
        var info = MYGProyectoStorage.ActualizarDesdeDelphin(P, items); AsegurarColumnas(); Refrescar(); estado.Text = info.Nuevas + " filas agregadas; " + info.Actualizadas + " actualizadas.";
    }
    private void Reconciliar()
    {
        if (P?.Conexion == null) throw new InvalidOperationException("Conecte el presupuesto oficial antes de reconciliar.");
        using var d = new ReconciliarForm(P); if (d.ShowDialog(this) != WinForms.DialogResult.OK) return; Recordar();
        foreach (var par in d.Elegidas)
        {
            string localAnterior = par.Oficial.IdLocalMYG;
            MYGProyectoStorage.Vincular(par.Propuesta, par.Oficial);
            foreach (var i in P.Items)
                foreach (var recurso in i.Costos.Analisis.Where(r => r.SubpartidaIdLocal == localAnterior))
                    recurso.SubpartidaIdLocal = par.Oficial.IdLocalMYG;
            P.Items.Remove(par.Propuesta);
        }
        Refrescar();
    }
    private async Task BuscarRevit()
    {
        revit.Items.Clear(); modelo = null; string errorConector = null;
        foreach (var p in Process.GetProcessesByName("Revit"))
        {
            try
            {
                estado.Text = "Consultando Revit · PID " + p.Id;
                var r = await cliente.EnviarAsync(p.Id, new() { Accion = "INFO", Credencial = sesion.Credencial });
                if (r.Ok) revit.Items.Add(new RevitOpcion(p.Id, r.Documento.Nombre));
                else errorConector = r.Mensaje;
            }
            catch (Exception ex) when (ex is IOException or TimeoutException or OperationCanceledException or InvalidOperationException) { }
            finally { p.Dispose(); }
        }
        if (revit.Items.Count == 0) throw new InvalidOperationException(errorConector ?? "No se encontró un modelo con el conector MYG. Abra Revit 2027 con un proyecto y compruebe que el conector esté instalado.");
        revit.SelectedIndex = 0; await ConectarModelo();
    }
    private async Task ConectarModelo()
    {
        if (revit.SelectedItem is not RevitOpcion r) throw new InvalidOperationException("Pulse Buscar Revit y seleccione una sesión.");
        var respuesta = await cliente.EnviarAsync(r.Pid, new() { Accion = "INFO", Credencial = sesion.Credencial });
        if (!respuesta.Ok) throw new InvalidOperationException(respuesta.Mensaje);
        modelo = respuesta.Documento; estadoRevit.Text = "Revit: " + modelo.Nombre;
        foreach (var i in documento.Presupuestos.SelectMany(p => p.Items)) { i.EstadoRevit = null; i.MensajeRevit = null; }
        ActualizarEstadoConexion(); Refrescar();
    }
    private async Task ElegirValorRevit(WinForms.DataGridViewRow row, int numero)
    {
        if (row.Tag is not ItemPresupuestoDelphin i || MYGProyectoStorage.EsTitulo(i)) return;
        if (modelo == null || revit.SelectedItem is not RevitOpcion r)
            throw new InvalidOperationException("Conecte un modelo mediante Buscar Revit para consultar sus valores. También puede escribir el valor directamente.");
        string parametro = row.Cells["P" + numero].Value as string;
        if (string.IsNullOrWhiteSpace(i.Plantilla) || string.IsNullOrWhiteSpace(parametro))
            throw new InvalidOperationException("Seleccione una plantilla y un parámetro antes de consultar valores.");
        var respuesta = await cliente.EnviarAsync(r.Pid, new() { Accion = "VALORES", Credencial = sesion.Credencial, DocumentoId = modelo.Id, Plantilla = i.Plantilla, Parametro = parametro });
        if (!respuesta.Ok) throw new InvalidOperationException(respuesta.Mensaje);
        using var f = new ValorRevitForm(parametro, respuesta.Valores, row.Cells["V" + numero].Value as string);
        if (f.ShowDialog(this) != WinForms.DialogResult.OK) return;
        Recordar(); row.Cells["V" + numero].Value = f.Valor; Sincronizar();
    }
    private async Task OperarRevit(string accion)
    {
        MYGProyectoStorage.Validar(documento);
        if (modelo == null || revit.SelectedItem is not RevitOpcion r) throw new InvalidOperationException("Conecte un modelo mediante Buscar Revit.");
        var items = (accion == "ACTUALIZAR" ? Seleccionadas : Partidas).Where(i => !MYGProyectoStorage.EsTitulo(i)).ToList();
        if (items.Count == 0) throw new InvalidOperationException("No hay partidas para procesar.");
        if (accion == "CREAR" && WinForms.MessageBox.Show(this, "Se sincronizarán las tablas MYG de este presupuesto en " + modelo.Nombre + ". La sincronización puede reemplazar o quitar tablas MYG del mismo ámbito. ¿Continuar?", "MYG Presupuestos", WinForms.MessageBoxButtons.YesNo) != WinForms.DialogResult.Yes) return;
        if ((accion is "CREAR" or "ACTUALIZAR") && !Guardar(false)) return;
        var configs = Configuraciones(items);
        estado.Text = "Esperando a Revit. Finalice cualquier comando activo en el modelo.";
        RespuestaRevit respuesta;
        try
        {
            respuesta = await cliente.EnviarAsync(r.Pid, new()
            {
                Accion = accion,
                Credencial = sesion.Credencial,
                DocumentoId = modelo.Id,
                ProyectoId = documento.IdProyectoRevit,
                ProyectoNombre = documento.Nombre,
                PresupuestoId = P.IdPresupuestoRevit,
                Configuraciones = configs
            });
        }
        catch (IOException) { throw new IOException("Se interrumpió la conexión. Compruebe el resultado en Revit antes de repetir la operación."); }
        catch (OperationCanceledException) { throw new TimeoutException("Revit no respondió dentro del tiempo disponible. Compruebe el resultado en Revit antes de repetir la operación."); }
        if (!respuesta.Ok) throw new InvalidOperationException(respuesta.Mensaje);
        MostrarResultadosRevit(respuesta, items);
    }
    private void ExportarCsv() => ExportarPresupuesto();
    private void MoverPropuesta(int sentido)
    {
        if (P == null) return;
        var elegidas = Seleccionadas;
        if (elegidas.Count != 1) throw new InvalidOperationException("Seleccione una sola propuesta para cambiar su posición.");
        var i = elegidas[0];
        if (!string.IsNullOrWhiteSpace(i.IdInternoDelphin)) throw new InvalidOperationException("Solo pueden moverse las propuestas MYG.");
        var hermanos = P.Items.Where(x => x.ParentId == i.ParentId).OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        int indice = hermanos.IndexOf(i), destino = indice + sentido;
        if (destino < 0 || destino >= hermanos.Count) return;
        Recordar(); hermanos.RemoveAt(indice); hermanos.Insert(destino, i);
        for (int n = 0; n < hermanos.Count; n++) hermanos[n].Posicion = n + 1;
        if (P.Conexion == null) MYGProyectoStorage.Renumerar(P); Refrescar();
    }
    private void ElegirColumnas()
    {
        using var f = new WinForms.Form(); MYGProyectoUI.Preparar(f, "Visibilidad de columnas", 550, 610);
        var lista = new WinForms.CheckedListBox { Dock = WinForms.DockStyle.Fill, CheckOnClick = true, BorderStyle = WinForms.BorderStyle.None };
        foreach (WinForms.DataGridViewColumn c in grid.Columns)
        {
            string texto = c.HeaderText;
            if (EsFiltro(c.Name)) texto = "FILTRO " + c.Name[1..].PadLeft(2, '0') + " · " + texto;
            if (c.Name == "EXPANDIR") texto = "Expandir / contraer títulos";
            lista.Items.Add(new OpcionColumna(c.Name, texto), c.Visible);
        }
        var aceptar = MYGProyectoUI.Boton("Aplicar", 1); var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        aceptar.Click += (s, e) =>
        {
            if (lista.CheckedItems.Count == 0) { WinForms.MessageBox.Show(f, "Mantenga al menos una columna visible.", "MYG BIM"); return; }
            columnasOcultas.Clear();
            for (int n = 0; n < lista.Items.Count; n++) if (!lista.GetItemChecked(n)) columnasOcultas.Add(((OpcionColumna)lista.Items[n]).Nombre);
            grid.CurrentCell = null;
            foreach (WinForms.DataGridViewColumn c in grid.Columns) c.Visible = !columnasOcultas.Contains(c.Name);
            AlinearCabecera(); f.DialogResult = WinForms.DialogResult.OK;
        };
        f.Padding = new(18); f.Controls.Add(lista); f.Controls.Add(MYGBibliotecaUI.Pie(aceptar, cancelar)); f.ShowDialog(this);
    }
    private sealed record OpcionColumna(string Nombre, string Texto) { public override string ToString() => Texto; }
    private async Task AbrirProyecto()
    {
        using var d = new WinForms.OpenFileDialog { Filter = "Base SQLite (*.sqlite)|*.sqlite" };
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        if (!MYGBaseDatos.EsRutaSQLite(d.FileName))
            throw new InvalidOperationException("Seleccione una base con extensión .sqlite.");
        // Leer y validar primero: un archivo inválido no reemplaza el trabajo abierto.
        string ruta = d.FileName;
        var proyectos = await MYGCargaAnimada.EjecutarAsync(this, "Leyendo proyectos de la base…", () => MYGBaseDatos.ListarProyectos(ruta));
        string proyectoId = MYGProyectosUI.Elegir(this, ruta, proyectos);
        if (proyectoId == null) return;
        var nuevo = await MYGCargaAnimada.EjecutarAsync(this, "Abriendo proyecto…", () => MYGBaseDatos.LeerProyecto(ruta, proyectoId));
        if (AbrirEnPestana != null)
        {
            AbrirEnPestana(ruta, nuevo);
            return;
        }
        if (MYGProyectoStorage.Firma(documento) != firmaGuardada)
        {
            var r = WinForms.MessageBox.Show(this, "Hay cambios pendientes. ¿Guardar antes de abrir otro proyecto?", "MYG BIM", WinForms.MessageBoxButtons.YesNoCancel);
            if (r == WinForms.DialogResult.Cancel || (r == WinForms.DialogResult.Yes && !Guardar(false))) return;
            // Si Guardar utilizó el mismo destino, releer su contenido actualizado.
            if (string.Equals(Path.GetFullPath(d.FileName), string.IsNullOrWhiteSpace(archivo) ? "" : Path.GetFullPath(archivo), StringComparison.OrdinalIgnoreCase))
                nuevo = await MYGCargaAnimada.EjecutarAsync(this, "Actualizando proyecto guardado…", () => MYGBaseDatos.LeerProyecto(ruta, proyectoId));
        }
        await MYGCargaAnimada.EjecutarAsync(this, "Preparando el proyecto…", () => MYGBaseDatos.AsegurarParaProyecto(ruta, nuevo));
        documento = nuevo; archivo = d.FileName; firmaGuardada = MYGProyectoStorage.Firma(documento);
        undo.Clear(); redo.Clear(); contraidos.Clear(); carpetaMetrados = null;
        cargando = true; buscarItem.Clear(); buscarPartida.Clear(); buscarUnidad.Clear(); cargando = false;
        MYGIndiceLocal.Registrar(documento, archivo); CargarBiblioteca(); Refrescar();
    }
    private void MostrarConexionRevit()
    {
        if (ocupado) return;
        using var f = new WinForms.Form(); MYGProyectoUI.Preparar(f, "Conexión Revit 2027", 690, 240);
        var detalle = new WinForms.Label { Text = "Abra el modelo en Revit 2027 y pulse Buscar Revit. El modelo seleccionado debe permanecer activo en Revit.", Left = 22, Top = 20, Width = 638, Height = 48 };
        revit.SetBounds(22, 78, 430, 28); estadoRevit.SetBounds(22, 121, 638, 28);
        var buscar = BotonAsync("Buscar Revit", BuscarRevit, true, 170, 2); buscar.SetBounds(466, 77, 170, 30);
        var actualizar = BotonAsync("Actualizar plantillas", ActualizarPlantillas, true, 180, 2); actualizar.SetBounds(22, 170, 180, 32);
        var cerrar = MYGProyectoUI.Boton("Cerrar"); cerrar.SetBounds(526, 170, 110, 32); cerrar.DialogResult = WinForms.DialogResult.OK;
        f.Controls.AddRange(new WinForms.Control[] { detalle, revit, estadoRevit, buscar, actualizar, cerrar });
        try { f.ShowDialog(this); }
        finally { f.Controls.Remove(revit); f.Controls.Remove(estadoRevit); ActualizarEstadoConexion(); }
    }
    private async Task ActualizarPlantillas()
    {
        if (revit.SelectedItem is not RevitOpcion) await BuscarRevit(); else await ConectarModelo();
        ActualizarEstadoConexion();
    }
    protected override bool ProcessCmdKey(ref WinForms.Message msg, WinForms.Keys keyData)
    {
        // Los cuadros de texto conservan sus propios atajos mientras se editan.
        bool texto = grid.IsCurrentCellInEditMode || buscarItem.Focused || buscarPartida.Focused || buscarUnidad.Focused || panelPresupuesto?.EditandoTexto == true || cronogramaVisible && panelCronograma?.EditandoTexto == true;
        if (!texto && !ocupado && sesion.Autorizado && (keyData == (WinForms.Keys.Control | WinForms.Keys.Z) || keyData == (WinForms.Keys.Control | WinForms.Keys.Y)))
        { Sincronizar(); Historial(keyData == (WinForms.Keys.Control | WinForms.Keys.Y)); return true; }
        if (keyData == (WinForms.Keys.Control | WinForms.Keys.S) && !ocupado)
        { try { Guardar(false); } catch (Exception ex) { MYGProyectoUI.Error(this, ex); } return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }
    private List<ConfiguracionTablaPlanificacion> Configuraciones(IEnumerable<ItemPresupuestoDelphin> items)
        => items.Select(i => new ConfiguracionTablaPlanificacion
        {
            IdInterno = i.Id,
            ParentId = i.ParentId,
            IdInternoDelphin = i.IdInternoDelphin,
            IdLocalMYG = i.IdLocalMYG,
            IdPropuesta = i.IdPropuesta,
            IdAnalisisDelphin = i.IdAnalisisDelphin,
            IdCatalogoDelphin = i.IdCatalogoDelphin,
            FuenteCatalogoId = i.FuenteCatalogoId,
            FuenteCatalogoRuta = i.FuenteCatalogoRuta,
            CodigoCatalogoDelphin = i.CodigoCatalogoDelphin,
            CodigoDelphin = i.CodigoDelphin,
            IdConfiguracionBibliotecaMYG = i.IdConfiguracionBibliotecaMYG,
            Item = i.Item,
            Partida = i.Descripcion,
            Unidad = i.Unidad,
            Plantilla = i.Plantilla,
            Filtros = MYGProyectoStorage.Copia(i.Filtros),
            Estado = i.Estado,
            Origen = i.Origen,
            TipoPropuesta = i.TipoPropuesta,
            Posicion = i.Posicion,
            PartidaOriginal = i.PartidaOriginal,
            UnidadOriginal = i.UnidadOriginal,
            PartidaPropuesta = i.PartidaPropuesta,
            UnidadPropuesta = i.UnidadPropuesta
        }).ToList();
    private void MostrarResultadosRevit(RespuestaRevit r, IEnumerable<ItemPresupuestoDelphin> items)
    {
        foreach (var i in items)
        {
            var resultado = r.Resultados.FirstOrDefault(x => x.ClavePartida == i.Id ||
                (!string.IsNullOrWhiteSpace(i.IdInternoDelphin) && x.ClavePartida == i.IdInternoDelphin) ||
                (!string.IsNullOrWhiteSpace(i.IdPropuesta) && x.ClavePartida == i.IdPropuesta));
            if (resultado != null) { i.EstadoRevit = resultado.Estado; i.MensajeRevit = resultado.Mensaje; }
        }
        foreach (WinForms.DataGridViewRow fila in grid.Rows) ActualizarCeldaRevit(fila);
        using var d = new ResultadosForm(r); d.ShowDialog(this); estado.Text = r.Mensaje;
    }
    private async Task ActualizarActivo()
    {
        MYGProyectoStorage.Validar(documento);
        if (modelo == null || revit.SelectedItem is not RevitOpcion r)
            throw new InvalidOperationException("Conecte el modelo con Actualizar plantillas o con el enlace Conectar Revit.");
        var partidas = Partidas.Where(i => !string.IsNullOrWhiteSpace(i.Plantilla)).ToList();
        if (partidas.Count == 0) throw new InvalidOperationException("No hay partidas con una plantilla BIM para consultar sus metrados.");
        using var datos = new MYGCamposProyectoForm("Metrado del activo", new[] { "Nombre / ID del activo" }, new[] { modelo.Nombre });
        if (datos.ShowDialog(this) != WinForms.DialogResult.OK) return;
        string activo = datos.Valores[0].Trim();
        if (activo.Length == 0 || activo.Length > 128) throw new InvalidOperationException("El nombre del activo debe tener entre 1 y 128 caracteres.");
        using var carpeta = new WinForms.FolderBrowserDialog { Description = "Carpeta donde se guardarán los metrados de los activos", SelectedPath = carpetaMetrados ?? Path.GetDirectoryName(archivo) ?? "", UseDescriptionForTitle = true };
        if (carpeta.ShowDialog(this) != WinForms.DialogResult.OK) return;
        carpetaMetrados = carpeta.SelectedPath;
        estado.Text = "Leyendo los metrados de las tablas existentes en Revit...";
        var respuesta = await cliente.EnviarAsync(r.Pid, new()
        {
            Accion = "METRADO",
            Credencial = sesion.Credencial,
            DocumentoId = modelo.Id,
            ProyectoId = documento.IdProyectoRevit,
            ProyectoNombre = documento.Nombre,
            PresupuestoId = P.IdPresupuestoRevit,
            ActivoId = activo,
            Configuraciones = Configuraciones(partidas)
        });
        if (!respuesta.Ok) throw new InvalidOperationException(respuesta.Mensaje);
        if (string.IsNullOrWhiteSpace(respuesta.MetradoJson)) throw new InvalidDataException("El conector no devolvió el metrado del activo. Recompile también MYG.Revit2027 con MotorTablas.cs actualizado.");
        var contenido = JsonSerializer.Deserialize<SnapshotMetrados>(respuesta.MetradoJson, ProtocoloMYG.Json);
        if (contenido == null || contenido.VersionFormato != 1 || !string.Equals(contenido.ActivoId, activo, StringComparison.Ordinal))
            throw new InvalidDataException("La respuesta de metrados no corresponde al activo seleccionado.");
        // El nombre distingue presupuesto y activo, evitando reemplazar otra especialidad.
        string presupuestoId = NombreSeguro(P.IdPresupuestoRevit);
        string destino = Path.Combine(carpetaMetrados, "MYG_METRADO_" + NombreSeguro(P.Nombre) + "_" + presupuestoId + "_" + NombreSeguro(activo) + ".json");
        MYGProyectoStorage.EscribirAtomico(destino, respuesta.MetradoJson);
        Recordar(); MYGMotorPresupuestos.ImportarMetradoBIM(documento, P, respuesta.MetradoJson); panelPresupuesto?.Refrescar(); ActualizarResumen();
        WinForms.MessageBox.Show(this, $"Activo: {activo}\nPartidas exportadas: {contenido.Partidas.Count}\nAdvertencias: {contenido.Advertencias.Count}\n\n{destino}", "MYG BIM | Metrado actualizado");
        estado.Text = "Metrado del activo actualizado.";
    }
    private Task FederarMetrados()
    {
        if (P == null || !Partidas.Any()) throw new InvalidOperationException("Abra un presupuesto con partidas antes de federar metrados.");
        using var elegir = new WinForms.OpenFileDialog { Title = "Seleccione los JSON de los activos que desea federar", Filter = "Metrados MYG (*.json)|*.json", Multiselect = true, InitialDirectory = carpetaMetrados ?? Path.GetDirectoryName(archivo) ?? "" };
        if (elegir.ShowDialog(this) != WinForms.DialogResult.OK) return Task.CompletedTask;
        var activos = new List<SnapshotMetrados>();
        foreach (string ruta in elegir.FileNames)
        {
            var s = JsonSerializer.Deserialize<SnapshotMetrados>(File.ReadAllText(ruta), ProtocoloMYG.Json);
            if (s == null || s.VersionFormato != 1 || string.IsNullOrWhiteSpace(s.ActivoId) || s.Partidas == null || s.Advertencias == null)
                throw new InvalidDataException("No es un metrado MYG válido: " + Path.GetFileName(ruta));
            if (!string.Equals(s.Proyecto?.Trim(), documento.Nombre?.Trim(), StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("El archivo pertenece a otro proyecto: " + Path.GetFileName(ruta));
            if (!string.IsNullOrWhiteSpace(s.ProyectoId) && !string.Equals(s.ProyectoId, documento.IdProyectoRevit, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("El archivo pertenece a otro proyecto MYG: " + Path.GetFileName(ruta));
            if (!string.IsNullOrWhiteSpace(s.PresupuestoId) && !string.Equals(s.PresupuestoId, P.IdPresupuestoRevit, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("El archivo pertenece a otro presupuesto: " + Path.GetFileName(ruta));
            if (s.Partidas.Any(x => x == null || !double.IsFinite(x.Metrado))) throw new InvalidDataException("El archivo contiene metrados no válidos: " + Path.GetFileName(ruta));
            activos.Add(s);
        }
        var duplicado = activos.GroupBy(a => a.ActivoId, StringComparer.OrdinalIgnoreCase).FirstOrDefault(g => g.Count() > 1);
        if (duplicado != null) throw new InvalidDataException("Seleccione un solo archivo por activo para evitar duplicar el metrado: " + duplicado.Key);
        var titulos = new[] { "ITEM", "PARTIDA", "UNIDAD" }.Concat(activos.Select(a => a.ActivoId)).Concat(new[] { "METRADO TOTAL", "OBSERVACIONES" }).ToArray();
        var filas = new List<object[]>();
        foreach (var i in Partidas)
        {
            var fila = new List<object> { i.Item, i.Descripcion, i.Unidad }; double total = 0; bool completo = true;
            var observaciones = new List<string>();
            foreach (var a in activos)
            {
                var matches = a.Partidas.Where(x => (!string.IsNullOrWhiteSpace(x.ClavePartida) && (x.ClavePartida == i.Id || x.ClavePartida == i.IdInternoDelphin || x.ClavePartida == i.IdPropuesta)) ||
                    (!string.IsNullOrWhiteSpace(x.IdInternoDelphin) && x.IdInternoDelphin == i.IdInternoDelphin) ||
                    (!string.IsNullOrWhiteSpace(x.IdPropuesta) && x.IdPropuesta == i.IdPropuesta)).ToList();
                if (matches.Count != 1)
                { completo = false; fila.Add(null); observaciones.Add(a.ActivoId + (matches.Count == 0 ? ": sin dato" : ": partida duplicada")); continue; }
                var m = matches[0];
                if (!MYGProyectoStorage.MismaUnidad(i.Unidad, m.Unidad) || !string.IsNullOrWhiteSpace(m.Advertencia))
                { completo = false; fila.Add(null); observaciones.Add(a.ActivoId + ": " + (m.Advertencia ?? "unidad incompatible")); continue; }
                fila.Add(m.Metrado); total += m.Metrado;
            }
            // Un dato ausente nunca se convierte en cero ni produce un total aparente.
            fila.Add(completo ? total : null); fila.Add(string.Join(" | ", observaciones)); filas.Add(fila.ToArray());
        }
        using var vista = new WinForms.Form(); MYGProyectoUI.Preparar(vista, "Federación de metrados", 1280, 700);
        var g = MYGBibliotecaUI.Tabla(); MYG2027_TemaComercial.EstilizarTablaPresupuesto(g); g.ReadOnly = true;
        for (int n = 0; n < titulos.Length; n++)
        {
            var c = new WinForms.DataGridViewTextBoxColumn { Name = "C" + n, HeaderText = titulos[n], Width = n == 1 ? 420 : n == titulos.Length - 1 ? 350 : 145, SortMode = WinForms.DataGridViewColumnSortMode.NotSortable };
            if (n >= 3 && n < titulos.Length - 1) { c.DefaultCellStyle.Format = "N2"; c.DefaultCellStyle.Alignment = WinForms.DataGridViewContentAlignment.MiddleRight; }
            g.Columns.Add(c);
        }
        foreach (var fila in filas) g.Rows.Add(fila);
        var exportar = MYGProyectoUI.Boton("Exportar Excel", 1); var cerrar = MYGProyectoUI.Boton("Cerrar"); cerrar.DialogResult = WinForms.DialogResult.OK;
        exportar.Click += (s, e) =>
        {
            try
            {
                using var d = new WinForms.SaveFileDialog { Filter = "Libro Excel (*.xlsx)|*.xlsx", FileName = "MYG_METRADOS_FEDERADOS.xlsx" };
                if (d.ShowDialog(vista) == WinForms.DialogResult.OK) EscribirExcel(d.FileName, titulos, filas);
            }
            catch (Exception ex) { MYGProyectoUI.Error(vista, ex); }
        };
        int avisos = activos.Sum(a => a.Advertencias.Count);
        vista.Padding = new(18); vista.Controls.Add(g);
        vista.Controls.Add(new WinForms.Label { Dock = WinForms.DockStyle.Top, Height = 52, Text = $"{activos.Count} activo(s) · {filas.Count} partida(s) · {avisos} advertencia(s) de origen.\nLos totales quedan vacíos cuando falta un dato, hay duplicidad o las unidades no coinciden." });
        vista.Controls.Add(MYGBibliotecaUI.Pie(exportar, cerrar)); vista.ShowDialog(this); return Task.CompletedTask;
    }
    private sealed class SnapshotMetrados
    {
        public SnapshotMetrados() { }
        public int VersionFormato { get; set; }
        public string Proyecto { get; set; }
        public string ProyectoId { get; set; }
        public string PresupuestoId { get; set; }
        public string ActivoId { get; set; }
        public string ArchivoRvt { get; set; }
        public DateTime FechaUtc { get; set; }
        public List<PartidaMetrada> Partidas { get; set; } = new();
        public List<string> Advertencias { get; set; } = new();
    }
    private sealed class PartidaMetrada
    {
        public PartidaMetrada() { }
        public string ClavePartida { get; set; }
        public string IdInternoDelphin { get; set; }
        public string IdPropuesta { get; set; }
        public string Item { get; set; }
        public string Partida { get; set; }
        public string Unidad { get; set; }
        public double Metrado { get; set; }
        public string TablaPlanificacion { get; set; }
        public string Advertencia { get; set; }
    }
    private static string NombreSeguro(string texto)
    {
        var invalidos = Path.GetInvalidFileNameChars().Concat(new[] { '/', '\\', ':' }).ToHashSet();
        string limpio = new((texto ?? "").Select(c => invalidos.Contains(c) ? '_' : c).Take(64).ToArray());
        limpio = limpio.Trim().TrimEnd('.'); return string.IsNullOrWhiteSpace(limpio) ? "ACTIVO" : limpio;
    }
    private void ExportarPresupuesto()
    {
        if (P == null) throw new InvalidOperationException("Abra un presupuesto para exportar.");
        using var d = new WinForms.SaveFileDialog
        { Filter = "Libro Excel (*.xlsx)|*.xlsx|Tabla CSV (*.csv)|*.csv", DefaultExt = "xlsx", FileName = NombreSeguro(P.Nombre) + ".xlsx" };
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        var titulos = new List<string> { "ID INTERNO", "COD. DELPHIN", "ID PROPUESTA", "ORIGEN", "ESTADO", "ITEM", "PARTIDA", "UNIDAD", "REVIT", "PLANTILLA", "BIBLIOTECA BIM" };
        for (int n = 1; n <= P.CantidadFiltros; n++) titulos.AddRange(new[] { "PARÁMETRO " + n, "REGLA " + n, "VALOR " + n });
        var filas = new List<object[]>();
        foreach (var i in OrdenJerarquia(P.Items))
        {
            bool titulo = MYGProyectoStorage.EsTitulo(i);
            var fila = new List<object> { i.IdInternoDelphin, i.CodigoDelphin ?? i.CodigoCatalogoDelphin, i.IdPropuesta, i.Origen, i.Estado,
                i.Item, i.PartidaPropuesta ?? i.Descripcion, i.UnidadPropuesta ?? i.Unidad, titulo ? "" : TextoEstadoRevit(i),
                titulo ? "" : i.Plantilla, titulo ? "" : biblioteca == null ? "Revisar biblioteca" : MYGBibliotecaPartidas.Estado(biblioteca, i) };
            var filtros = MYGBibliotecaPartidas.FiltrosGuardables(i);
            for (int n = 0; n < P.CantidadFiltros; n++)
            { var f = !titulo && n < filtros.Count ? filtros[n] : new FiltroPlanificacion(); fila.AddRange(new object[] { f.Parametro, f.Regla, f.Valor }); }
            filas.Add(fila.ToArray());
        }
        if (d.FilterIndex == 2 || string.Equals(Path.GetExtension(d.FileName), ".csv", StringComparison.OrdinalIgnoreCase))
        {
            string Q(object o) => "\"" + (Convert.ToString(o, CultureInfo.InvariantCulture) ?? "").Replace("\"", "\"\"") + "\"";
            File.WriteAllLines(d.FileName, new[] { string.Join(";", titulos.Select(x => Q(x))) }.Concat(filas.Select(f => string.Join(";", f.Select(Q)))), new UTF8Encoding(true));
        }
        else EscribirExcel(d.FileName, titulos.ToArray(), filas);
        estado.Text = "Presupuesto exportado: " + Path.GetFileName(d.FileName);
    }
    // XLSX real con Open XML y bibliotecas del propio .NET. No añade paquetes
    // ni cambia la licencia de EPPlus de otros proyectos de la solución.
    private static void EscribirExcel(string ruta, string[] titulos, List<object[]> filas)
    {
        XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        XNamespace r = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        XNamespace rel = "http://schemas.openxmlformats.org/package/2006/relationships";
        XNamespace ct = "http://schemas.openxmlformats.org/package/2006/content-types";
        string Col(int n)
        {
            string resultado = ""; for (n++; n > 0; n = (n - 1) / 26) resultado = (char)('A' + (n - 1) % 26) + resultado; return resultado;
        }
        XElement Celda(object valor, int fila, int columna, int estilo)
        {
            string referencia = Col(columna) + fila;
            if (valor is double numero && double.IsFinite(numero))
                return new XElement(s + "c", new XAttribute("r", referencia), new XAttribute("s", 2), new XElement(s + "v", numero.ToString("R", CultureInfo.InvariantCulture)));
            string texto = Convert.ToString(valor, CultureInfo.InvariantCulture) ?? "";
            texto = new string(texto.Where(c => c == '\n' || c == '\r' || c == '\t' || c >= ' ').Take(32767).ToArray());
            return new XElement(s + "c", new XAttribute("r", referencia), new XAttribute("s", estilo), new XAttribute("t", "inlineStr"),
                new XElement(s + "is", new XElement(s + "t", new XAttribute(XNamespace.Xml + "space", "preserve"), texto)));
        }
        var datos = new XElement(s + "sheetData", new XElement(s + "row", new XAttribute("r", 1), titulos.Select((v, n) => Celda(v, 1, n, 1))));
        for (int n = 0; n < filas.Count; n++) datos.Add(new XElement(s + "row", new XAttribute("r", n + 2), filas[n].Select((v, c) => Celda(v, n + 2, c, 0))));
        string rango = "A1:" + Col(titulos.Length - 1) + (filas.Count + 1);
        var hoja = new XDocument(new XElement(s + "worksheet",
            new XElement(s + "dimension", new XAttribute("ref", rango)),
            new XElement(s + "sheetViews", new XElement(s + "sheetView", new XAttribute("workbookViewId", 0), new XElement(s + "pane", new XAttribute("ySplit", 1), new XAttribute("topLeftCell", "A2"), new XAttribute("activePane", "bottomLeft"), new XAttribute("state", "frozen")))),
            new XElement(s + "sheetFormatPr", new XAttribute("defaultRowHeight", 18)),
            new XElement(s + "cols", titulos.Select((v, n) => new XElement(s + "col", new XAttribute("min", n + 1), new XAttribute("max", n + 1), new XAttribute("width", v == "PARTIDA" ? 65 : v == "OBSERVACIONES" ? 55 : 21), new XAttribute("customWidth", 1)))),
            datos, new XElement(s + "autoFilter", new XAttribute("ref", rango)),
            new XElement(s + "pageMargins", new XAttribute("left", 0.3), new XAttribute("right", 0.3), new XAttribute("top", 0.5), new XAttribute("bottom", 0.5), new XAttribute("header", 0.2), new XAttribute("footer", 0.2)),
            new XElement(s + "pageSetup", new XAttribute("orientation", "landscape"), new XAttribute("paperSize", 9))));
        var estilos = new XDocument(new XElement(s + "styleSheet",
            new XElement(s + "numFmts", new XAttribute("count", 1), new XElement(s + "numFmt", new XAttribute("numFmtId", 164), new XAttribute("formatCode", "0.00"))),
            new XElement(s + "fonts", new XAttribute("count", 2),
                new XElement(s + "font", new XElement(s + "sz", new XAttribute("val", 11)), new XElement(s + "name", new XAttribute("val", "Calibri"))),
                new XElement(s + "font", new XElement(s + "b"), new XElement(s + "sz", new XAttribute("val", 11)), new XElement(s + "color", new XAttribute("rgb", "FFFFFFFF")), new XElement(s + "name", new XAttribute("val", "Calibri")))),
            new XElement(s + "fills", new XAttribute("count", 3),
                new XElement(s + "fill", new XElement(s + "patternFill", new XAttribute("patternType", "none"))),
                new XElement(s + "fill", new XElement(s + "patternFill", new XAttribute("patternType", "gray125"))),
                new XElement(s + "fill", new XElement(s + "patternFill", new XAttribute("patternType", "solid"), new XElement(s + "fgColor", new XAttribute("rgb", "FF0F1F38")), new XElement(s + "bgColor", new XAttribute("indexed", 64))))),
            new XElement(s + "borders", new XAttribute("count", 1), new XElement(s + "border", new XElement(s + "left"), new XElement(s + "right"), new XElement(s + "top"), new XElement(s + "bottom"), new XElement(s + "diagonal"))),
            new XElement(s + "cellStyleXfs", new XAttribute("count", 1), new XElement(s + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 0), new XAttribute("fillId", 0), new XAttribute("borderId", 0))),
            new XElement(s + "cellXfs", new XAttribute("count", 3),
                new XElement(s + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 0), new XAttribute("fillId", 0), new XAttribute("borderId", 0), new XAttribute("xfId", 0)),
                new XElement(s + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 1), new XAttribute("fillId", 2), new XAttribute("borderId", 0), new XAttribute("xfId", 0), new XAttribute("applyFont", 1), new XAttribute("applyFill", 1)),
                new XElement(s + "xf", new XAttribute("numFmtId", 164), new XAttribute("fontId", 0), new XAttribute("fillId", 0), new XAttribute("borderId", 0), new XAttribute("xfId", 0), new XAttribute("applyNumberFormat", 1))),
            new XElement(s + "cellStyles", new XAttribute("count", 1), new XElement(s + "cellStyle", new XAttribute("name", "Normal"), new XAttribute("xfId", 0), new XAttribute("builtinId", 0)))));
        string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var z = new ZipArchive(File.Create(temporal), ZipArchiveMode.Create))
            {
                void Guardar(string nombre, XDocument xml) { using var salida = z.CreateEntry(nombre).Open(); xml.Save(salida); }
                Guardar("[Content_Types].xml", new XDocument(new XElement(ct + "Types",
                    new XElement(ct + "Default", new XAttribute("Extension", "rels"), new XAttribute("ContentType", "application/vnd.openxmlformats-package.relationships+xml")),
                    new XElement(ct + "Default", new XAttribute("Extension", "xml"), new XAttribute("ContentType", "application/xml")),
                    new XElement(ct + "Override", new XAttribute("PartName", "/xl/workbook.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")),
                    new XElement(ct + "Override", new XAttribute("PartName", "/xl/worksheets/sheet1.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")),
                    new XElement(ct + "Override", new XAttribute("PartName", "/xl/styles.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")))));
                Guardar("_rels/.rels", new XDocument(new XElement(rel + "Relationships", new XElement(rel + "Relationship", new XAttribute("Id", "rId1"), new XAttribute("Type", r.NamespaceName + "/officeDocument"), new XAttribute("Target", "xl/workbook.xml")))));
                Guardar("xl/workbook.xml", new XDocument(new XElement(s + "workbook", new XAttribute(XNamespace.Xmlns + "r", r), new XElement(s + "sheets", new XElement(s + "sheet", new XAttribute("name", "Presupuesto"), new XAttribute("sheetId", 1), new XAttribute(r + "id", "rId1"))))));
                Guardar("xl/_rels/workbook.xml.rels", new XDocument(new XElement(rel + "Relationships",
                    new XElement(rel + "Relationship", new XAttribute("Id", "rId1"), new XAttribute("Type", r.NamespaceName + "/worksheet"), new XAttribute("Target", "worksheets/sheet1.xml")),
                    new XElement(rel + "Relationship", new XAttribute("Id", "rId2"), new XAttribute("Type", r.NamespaceName + "/styles"), new XAttribute("Target", "styles.xml")))));
                Guardar("xl/worksheets/sheet1.xml", hoja); Guardar("xl/styles.xml", estilos);
            }
            File.Move(temporal, ruta, true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }


    private sealed record RevitOpcion(int Pid, string Nombre) { public override string ToString() => Nombre + " · PID " + Pid; }
}

internal sealed class ValorRevitForm : WinForms.Form
{
    internal string Valor { get; private set; }
    internal ValorRevitForm(string parametro, List<string> valores, string actual)
    {
        MYGProyectoUI.Preparar(this, "Valores Revit | " + parametro, 650, 540);
        var lista = new WinForms.ListBox { Dock = WinForms.DockStyle.Fill, HorizontalScrollbar = true };
        var texto = new WinForms.TextBox { Dock = WinForms.DockStyle.Top, Text = actual ?? "" };
        var nota = new WinForms.Label { Dock = WinForms.DockStyle.Top, Height = 46, Text = "Seleccione un valor del modelo o escriba uno. El texto filtra la lista de valores disponibles." };
        var aceptar = MYGProyectoUI.Boton("Usar valor", 1); var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        void Filtrar() { lista.Items.Clear(); lista.Items.AddRange(valores.Where(v => v.Contains(texto.Text, StringComparison.OrdinalIgnoreCase)).Cast<object>().ToArray()); }
        texto.TextChanged += (s, e) => Filtrar();
        aceptar.Click += (s, e) => { Valor = lista.SelectedItem as string ?? texto.Text; DialogResult = WinForms.DialogResult.OK; };
        lista.DoubleClick += (s, e) => { if (lista.SelectedItem is string v) { Valor = v; DialogResult = WinForms.DialogResult.OK; } };
        Controls.Add(lista); Controls.Add(texto); Controls.Add(nota); Controls.Add(MYGBibliotecaUI.Pie(aceptar, cancelar)); Padding = new(18); Filtrar();
    }
}

internal sealed class ReconciliarForm : WinForms.Form
{
    internal List<(ItemPresupuestoDelphin Propuesta, ItemPresupuestoDelphin Oficial)> Elegidas { get; } = new();
    internal ReconciliarForm(MYGPresupuestoDocumento p)
    {
        MYGProyectoUI.Preparar(this, "Reconciliar partidas", 1100, 600);
        var oficiales = p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i) && !string.IsNullOrWhiteSpace(i.IdInternoDelphin) && !MYGProyectoStorage.TieneBim(i)).ToList();
        var propuestas = p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i) && string.IsNullOrWhiteSpace(i.IdInternoDelphin)).ToList();
        var g = MYGBibliotecaUI.Tabla(); g.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "PROPUESTA", HeaderText = "Propuesta MYG", Width = 460, ReadOnly = true }); g.Columns.Add(new WinForms.DataGridViewComboBoxColumn { Name = "OFICIAL", HeaderText = "Partida oficial", Width = 540 });
        foreach (var i in propuestas)
        {
            var opciones = new List<MYGConfiguracionOpcion> { new() { Id = "", Texto = "Sin vincular" } };
            opciones.AddRange(oficiales.Where(o => MYGProyectoStorage.MismaUnidad(i.Unidad, o.Unidad)).Select(o => new MYGConfiguracionOpcion { Id = o.Id, Texto = o.Item + " · " + o.Descripcion + " · " + o.Unidad }));
            var row = g.Rows[g.Rows.Add(i.Item + " · " + i.Descripcion, null)]; row.Tag = i; row.Cells["OFICIAL"] = MYGBibliotecaUI.Opciones(opciones);
            row.Cells["OFICIAL"].Value = MYGProyectoStorage.VinculoAutomatico(i, propuestas, oficiales, p.Conexion.FuenteId)?.Id ?? "";
        }
        var b = MYGProyectoUI.Boton("Vincular seleccionadas", 1); b.Width = 200; var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        b.Click += (s, e) => { g.EndEdit(); var ids = new HashSet<string>(); Elegidas.Clear(); foreach (WinForms.DataGridViewRow row in g.Rows) { string id = row.Cells["OFICIAL"].Value as string; if (string.IsNullOrWhiteSpace(id)) continue; if (!ids.Add(id)) { WinForms.MessageBox.Show(this, "Una fila oficial solo puede vincularse con una propuesta.", "MYG Presupuestos"); return; } Elegidas.Add((row.Tag as ItemPresupuestoDelphin, oficiales.Single(i => i.Id == id))); } if (Elegidas.Count > 0) DialogResult = WinForms.DialogResult.OK; };
        var detalle = new WinForms.Label { Dock = WinForms.DockStyle.Top, Height = 50, Text = "Elija las correspondencias. Se conservan los filtros de cada propuesta. Las partidas oficiales ya configuradas no se ofrecen." };
        Controls.Add(g); Controls.Add(detalle); Controls.Add(MYGBibliotecaUI.Pie(b, cancelar)); Padding = new(18);
    }
}
internal sealed class ResultadosForm : WinForms.Form
{
    internal ResultadosForm(RespuestaRevit r)
    {
        MYGProyectoUI.Preparar(this, "Resultados Revit", 1000, 560);
        var g = MYGBibliotecaUI.Tabla(); g.ReadOnly = true;
        foreach (var c in new[] { ("ID", "Partida", 180), ("ESTADO", "Estado", 130), ("MENSAJE", "Resultado", 620) }) g.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = c.Item1, HeaderText = c.Item2, Width = c.Item3 });
        foreach (var x in r.Resultados) g.Rows.Add(x.ClavePartida, x.Estado, x.Mensaje);
        Controls.Add(g); Controls.Add(new WinForms.Label { Dock = WinForms.DockStyle.Top, Height = 42, Text = r.Mensaje }); Padding = new(18);
    }
}
