using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGGuardarPartidaCatalogoForm : Form
{
    internal string Codigo => codigo.Text.Trim();
    internal string Descripcion => descripcion.Text.Trim();
    internal string Unidad => MYGUnidadesUI.Valor(unidad);
    internal bool ComoNueva => nueva.Checked;
    private readonly TextBox codigo = new(), descripcion = new();
    private readonly ComboBox unidad;
    private readonly CheckBox nueva = new() { Text = "Guardar como una entrada nueva", AutoSize = true };
    internal MYGGuardarPartidaCatalogoForm(string codigoInicial, string descripcionInicial, string unidadInicial, bool actualizacion,
        IEnumerable<MYGUnidadCatalogo> unidades, bool conservarUnidadInicial = true)
    {
        Text = actualizacion ? "Actualizar partida del catálogo MYG" : "Guardar partida en catálogo MYG";
        StartPosition = FormStartPosition.CenterParent; ClientSize = new(650, 290); MinimumSize = new(600, 330);
        Font = new("Segoe UI", 10); codigo.Text = codigoInicial; descripcion.Text = descripcionInicial;
        unidad = MYGUnidadesUI.Selector(unidades, unidadInicial, conservarUnidadInicial);
        var tabla = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 5, Padding = new(16) };
        tabla.ColumnStyles.Add(new(SizeType.Absolute, 110)); tabla.ColumnStyles.Add(new(SizeType.Percent, 100));
        Control[] controles = { codigo, descripcion, unidad }; string[] nombres = { "Código", "Descripción", "Unidad" };
        for (int n = 0; n < 3; n++)
        {
            tabla.RowStyles.Add(new(SizeType.Absolute, 37)); controles[n].Dock = DockStyle.Fill;
            tabla.Controls.Add(new Label { Text = nombres[n], AutoSize = true }, 0, n); tabla.Controls.Add(controles[n], 1, n);
        }
        nueva.Visible = actualizacion; tabla.Controls.Add(nueva, 1, 3);
        var aviso = new Label { AutoSize = true, MaximumSize = new(580, 0),
            Text = "Se guardan la descripción, unidad, ACU y especificaciones. Los metrados pertenecen a la obra. " +
                "Los insumos del ACU se conservan en la plantilla; su registro en el catálogo de insumos es independiente." };
        tabla.Controls.Add(aviso, 0, 4); tabla.SetColumnSpan(aviso, 2);
        var guardar = new Button { Text = "Guardar en catálogo", AutoSize = true, Height = 34 };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Width = 100, Height = 34 };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, Padding = new(6), FlowDirection = FlowDirection.RightToLeft };
        pie.Controls.AddRange(new Control[] { cancelar, guardar });
        guardar.Click += (s, e) =>
        {
            if (Codigo.Length == 0 || Descripcion.Length == 0 || Unidad.Length == 0)
            { MessageBox.Show(this, "Indique código, descripción y unidad."); return; }
            DialogResult = DialogResult.OK;
        };
        Controls.Add(tabla); Controls.Add(pie); AcceptButton = guardar; CancelButton = cancelar;
    }
}

// Catálogo propio de MYG, separado del selector del catálogo Delphin.
internal sealed class MYGCatalogoPropioForm : Form
{
    internal string Ruta { get; private set; }
    internal MYGEntradaCatalogo Seleccionada { get; private set; }
    internal IReadOnlyList<MYGEntradaCatalogo> Seleccionadas { get; private set; } = Array.Empty<MYGEntradaCatalogo>();
    private readonly bool partidas;
    private readonly bool seleccionMultiple;
    private readonly Func<bool> autorizado;
    private readonly DataGridView tabla = new() { Name = "selectorCatalogoInsumos", Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, RowHeadersVisible = false, MultiSelect = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        AutoGenerateColumns = false, BackgroundColor = Color.White };
    private readonly TextBox buscar = new() { Name = "txtFiltroCatalogo", Dock = DockStyle.Top, PlaceholderText = "Buscar por código, descripción, unidad o grupo…" };
    private readonly Label rutaVisible = new() { Dock = DockStyle.Top, Height = 42, Padding = new(8), AutoEllipsis = true };
    private readonly Label cantidadSeleccionados = new() { Name = "lblCatalogoSeleccionados", AutoSize = true, Padding = new(4, 8, 0, 0) };
    private readonly HashSet<string> marcados = new(StringComparer.OrdinalIgnoreCase);
    private bool actualizandoTabla;
    private bool seleccionPorCasillas;
    private List<MYGEntradaCatalogo> datos = new();
    internal MYGCatalogoPropioForm(string ruta, bool partidas, Func<bool> autorizado, bool soloAdministrar = false)
    {
        Ruta = Path.GetFullPath(ruta); this.partidas = partidas; this.autorizado = autorizado;
        seleccionMultiple = !partidas && !soloAdministrar;
        Text = partidas ? "MYG | Catálogo de partidas" : "MYG | Catálogo de insumos";
        Font = new("Segoe UI", 10); StartPosition = FormStartPosition.CenterParent;
        ClientSize = new(1050, 600); MinimumSize = new(750, 450);
        if (seleccionMultiple)
        {
            tabla.ReadOnly = false; tabla.MultiSelect = true;
            tabla.Columns.Add(new DataGridViewCheckBoxColumn { Name = "SEL", HeaderText = "Sel.", Width = 48,
                MinimumWidth = 48, ReadOnly = false, ThreeState = false, Frozen = true, SortMode = DataGridViewColumnSortMode.NotSortable,
                ToolTipText = "Marcar para agregar el insumo. Las marcas se conservan al filtrar." });
            tabla.CurrentCellDirtyStateChanged += (s, e) =>
            {
                if (!actualizandoTabla && tabla.IsCurrentCellDirty && tabla.CurrentCell?.OwningColumn.Name == "SEL")
                    tabla.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            tabla.CellValueChanged += (s, e) =>
            {
                if (actualizandoTabla || e.RowIndex < 0 || e.ColumnIndex < 0 || tabla.Columns[e.ColumnIndex].Name != "SEL") return;
                var fila = tabla.Rows[e.RowIndex]; if (fila.Tag is not MYGEntradaCatalogo entrada) return;
                seleccionPorCasillas = true;
                if (fila.Cells["SEL"].Value is true) marcados.Add(entrada.Id); else marcados.Remove(entrada.Id);
                ActualizarCantidad();
            };
            tabla.SelectionChanged += (s, e) => { if (!actualizandoTabla) ActualizarCantidad(); };
            tabla.CellMouseClick += (s, e) =>
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && tabla.Columns[e.ColumnIndex].Name != "SEL" && marcados.Count == 0)
                { seleccionPorCasillas = false; ActualizarCantidad(); }
            };
        }
        void Columna(string campo, string titulo, int ancho) => tabla.Columns.Add(new DataGridViewTextBoxColumn
        { Name = campo, HeaderText = titulo, Width = ancho, ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable });
        Columna("COD", "Código", 120); Columna("DESC", "Descripción", 380); tabla.Columns["DESC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        Columna("UND", "Unidad", 80); Columna("GRUPO", partidas ? "Grupo de costos unitarios" : "Grupo", partidas ? 190 : 145);
        Columna("PRECIO", partidas ? "Precio unitario" : "Precio", 125);
        tabla.Columns["PRECIO"].DefaultCellStyle.Format = "N6"; tabla.Columns["PRECIO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        var barra = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 45, Padding = new(5), WrapContents = false, AutoScroll = true };
        Button Boton(string texto, Action accion)
        {
            var b = new Button { Text = texto, AutoSize = true, Height = 32 }; b.Click += (s, e) => Intentar(accion); barra.Controls.Add(b); return b;
        }
        Boton("Nueva", Crear); Boton("Editar datos", Editar); Boton("Eliminar", Eliminar);
        Boton("Actualizar lista", Cargar); Boton("Abrir otro catálogo MYG", OtroCatalogo);
        var usar = new Button { Name = "btnUsarCatalogoSeleccion", Text = "Usar selección", Width = 150, Height = 34 };
        var cancelar = new Button { Text = "Cerrar", DialogResult = DialogResult.Cancel, Width = 100, Height = 34 };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, Padding = new(6), FlowDirection = FlowDirection.RightToLeft };
        pie.Controls.Add(cancelar); if (!soloAdministrar) pie.Controls.Add(usar); usar.Click += (s, e) => Intentar(Elegir);
        tabla.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && tabla.Columns[e.ColumnIndex].Name != "SEL") Intentar(soloAdministrar ? Editar : Elegir); };
        buscar.TextChanged += (s, e) => Filtrar();
        Controls.Add(tabla); Controls.Add(buscar); Controls.Add(barra); Controls.Add(rutaVisible); Controls.Add(pie);
        if (seleccionMultiple)
        {
            var seleccion = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 46, Padding = new(3), WrapContents = false };
            var marcar = MYGInsumosUI.Boton("Marcar visibles", "aceptar"); marcar.Name = "btnMarcarCatalogoVisibles";
            marcar.Click += (s, e) =>
            {
                tabla.EndEdit(); seleccionPorCasillas = true;
                foreach (DataGridViewRow fila in tabla.Rows) fila.Cells["SEL"].Value = true; ActualizarCantidad();
            };
            var limpiar = MYGInsumosUI.Boton("Limpiar selección", "cerrar"); limpiar.Name = "btnLimpiarCatalogoSeleccion";
            limpiar.Click += (s, e) =>
            {
                tabla.EndEdit(); marcados.Clear(); seleccionPorCasillas = false; actualizandoTabla = true;
                try { foreach (DataGridViewRow fila in tabla.Rows) fila.Cells["SEL"].Value = false; tabla.ClearSelection(); }
                finally { actualizandoTabla = false; ActualizarCantidad(); }
            };
            seleccion.Controls.AddRange(new Control[] { marcar, limpiar, cantidadSeleccionados }); Controls.Add(seleccion);
            Controls.Add(new Label { Dock = DockStyle.Bottom, Height = 64, Padding = new(8), BackColor = MYGPanelPresupuesto.AzulClaro,
                Text = "Marque las casillas o seleccione varias filas con Ctrl o Shift. Las marcas se conservan al filtrar y se incluyen aunque estén ocultas. Al abrir otro catálogo se limpia la selección." });
        }
        if (!soloAdministrar) AcceptButton = usar; CancelButton = cancelar; Cargar();
    }
    private void Intentar(Action a)
    { try { a(); } catch (Exception ex) { MessageBox.Show(this, ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); } }
    private void RequerirPermiso()
    { if (autorizado?.Invoke() != true) throw new InvalidOperationException("Inicie una sesión autorizada para modificar los catálogos."); }
    private MYGEntradaCatalogo Actual => tabla.CurrentRow?.Tag as MYGEntradaCatalogo;
    private void Cargar()
    {
        tabla.EndEdit(); datos = MYGCatalogos.Listar(Ruta, partidas);
        marcados.IntersectWith(datos.Select(x => x.Id)); rutaVisible.Text = "Catálogo: " + Ruta; Filtrar();
    }
    private void Filtrar()
    {
        tabla.EndEdit(); string id = Actual?.Id, filtro = buscar.Text.Trim(); actualizandoTabla = true;
        try
        {
            tabla.Rows.Clear();
            foreach (var i in datos.Where(x => (x.Codigo + " " + x.Descripcion + " " + x.Unidad + " " + (partidas ? x.Grupo : GrupoVisible(x.Grupo))).Contains(filtro, StringComparison.OrdinalIgnoreCase)))
            {
                object[] valores = { i.Codigo, i.Descripcion, i.Unidad, partidas ? i.Grupo : GrupoVisible(i.Grupo), i.Precio };
                if (seleccionMultiple) valores = new object[] { marcados.Contains(i.Id) }.Concat(valores).ToArray();
                var r = tabla.Rows[tabla.Rows.Add(valores)]; r.Tag = i;
            }
            if (seleccionMultiple) tabla.ClearSelection();
            else
            {
                var elegida = tabla.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => ((MYGEntradaCatalogo)x.Tag).Id == id);
                if (elegida != null) { tabla.CurrentCell = elegida.Cells[0]; elegida.Selected = true; }
            }
        }
        finally { actualizandoTabla = false; ActualizarCantidad(); }
    }
    private void Elegir()
    {
        RequerirPermiso(); tabla.EndEdit();
        var elegidas = seleccionMultiple
            ? seleccionPorCasillas ? datos.Where(x => marcados.Contains(x.Id)).ToList()
                : tabla.SelectedRows.Cast<DataGridViewRow>().OrderBy(x => x.Index).Select(x => x.Tag).OfType<MYGEntradaCatalogo>().ToList()
            : Actual == null ? new List<MYGEntradaCatalogo>() : new List<MYGEntradaCatalogo> { Actual };
        if (elegidas.Count == 0) throw new InvalidOperationException("Seleccione " + (partidas ? "una partida." : "un insumo del catálogo."));
        Seleccionadas = elegidas.AsReadOnly(); Seleccionada = elegidas[0]; DialogResult = DialogResult.OK;
    }
    private void OtroCatalogo()
    {
        using var d = new OpenFileDialog { Title = "Abrir el catálogo de otro proyecto MYG", Filter = "Base de datos MYG (*.sqlite)|*.sqlite" };
        if (d.ShowDialog(this) != DialogResult.OK) return;
        var nuevos = MYGCatalogos.Listar(d.FileName, partidas); // Validar antes de sustituir el catálogo activo.
        tabla.EndEdit(); marcados.Clear(); seleccionPorCasillas = false;
        Ruta = Path.GetFullPath(d.FileName); datos = nuevos; rutaVisible.Text = "Catálogo: " + Ruta; buscar.Clear(); Filtrar();
    }
    private static string GrupoVisible(string grupo) => Enum.TryParse<MYGGrupoRecurso>(grupo, true, out var valor) && Enum.IsDefined(valor)
        ? MYGMotorPresupuestos.Grupo(valor) : grupo;
    private void ActualizarCantidad()
    {
        int cantidad = marcados.Count;
        if (!seleccionPorCasillas) cantidad = tabla.SelectedRows.Count;
        cantidadSeleccionados.Text = cantidad + " seleccionados";
    }
    private void Crear()
    {
        RequerirPermiso();
        var parametros = MYGParametrosUsuario.Leer();
        if (partidas)
        {
            using var f = new MYGGuardarPartidaCatalogoForm(MYGCatalogos.SiguienteCodigo(Ruta, true), "", parametros.UnidadPartida, false,
                MYGCatalogoUnidades.Listar(Ruta), conservarUnidadInicial: true);
            if (f.ShowDialog(this) != DialogResult.OK) return;
            RequerirPermiso();
            var p = new MYGPresupuestoDocumento { Nombre = "Catálogo" }; string id = MYGProyectoStorage.NuevoId();
            var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Descripcion = f.Descripcion, Unidad = f.Unidad, TipoPropuesta = "PARTIDA" };
            parametros.Aplicar(p); parametros.Aplicar(i); i.Unidad = f.Unidad;
            p.Items.Add(i); MYGCatalogos.GuardarPartida(Ruta, p, i, f.Codigo, f.Descripcion, f.Unidad);
        }
        else
        {
            var nuevo = new MYGInsumo { Codigo = MYGCatalogos.SiguienteCodigo(Ruta, false) }; parametros.Aplicar(nuevo);
            using var f = new MYGInsumoForm(nuevo, MYGCatalogoUnidades.Listar(Ruta), conservarUnidadInicial: true);
            if (f.ShowDialog(this) != DialogResult.OK) return; RequerirPermiso(); MYGCatalogos.GuardarInsumo(Ruta, f.Valor);
        }
        Cargar();
    }
    private void Editar()
    {
        RequerirPermiso(); var e = Actual; if (e == null) return;
        if (partidas)
        {
            var modelo = MYGCatalogos.LeerPartida(Ruta, e.Id, e.Revision);
            var p = new MYGPresupuestoDocumento { Nombre = "Catálogo", Items = modelo.Partidas,
                Costos = new MYGCostosPresupuesto { Insumos = modelo.Insumos, DecimalesPrecio = modelo.DecimalesPrecio, DecimalesCantidad = modelo.DecimalesCantidad } };
            var i = p.Items.First(x => x.IdLocalMYG == modelo.RaizLocalId);
            using var f = new MYGGuardarPartidaCatalogoForm(e.Codigo, e.Descripcion, e.Unidad, true, MYGCatalogoUnidades.Listar(Ruta));
            if (f.ShowDialog(this) != DialogResult.OK) return;
            RequerirPermiso();
            MYGCatalogos.GuardarPartida(Ruta, p, i, f.Codigo, f.Descripcion, f.Unidad, f.ComoNueva ? null : e.Id, f.ComoNueva ? 0 : e.Revision);
        }
        else
        {
            using var f = new MYGInsumoForm(MYGCatalogos.LeerInsumo(Ruta, e.Id, e.Revision), MYGCatalogoUnidades.Listar(Ruta));
            if (f.ShowDialog(this) != DialogResult.OK) return; RequerirPermiso(); MYGCatalogos.GuardarInsumo(Ruta, f.Valor, e.Id, e.Revision);
        }
        Cargar();
    }
    private void Eliminar()
    {
        RequerirPermiso(); var i = Actual; if (i == null) return;
        if (MessageBox.Show(this, "¿Eliminar del catálogo «" + i.Descripcion + "»? Las copias usadas en presupuestos se conservan.",
            Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        RequerirPermiso();
        MYGCatalogos.Eliminar(Ruta, partidas, i); Cargar();
    }
}
