using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly RadioButton porRendimientoACU = new() { Name = "acu_por_rendimiento", Text = "Por rendimiento", AutoSize = true, Margin = new(4, 5, 10, 0) };
    private readonly RadioButton porAsignacionACU = new() { Name = "acu_por_asignacion", Text = "Por asignación", AutoSize = true, Margin = new(4, 5, 10, 0) };
    private readonly Label unidadRendimientoACU = Etiqueta("unidad/día ×");
    private FlowLayoutPanel barraRendimientoACU;
    private readonly Label totalPrecioACU = new()
    {
        Name = "acu_total_precio_unitario", Text = "Total ACU · —", Dock = DockStyle.Bottom,
        TextAlign = ContentAlignment.MiddleRight, AutoEllipsis = true, Padding = new(8, 4, 12, 4)
    };

    private Control PrepararBarraRendimientoACU()
    {
        rendimiento.Name = "acu_rendimiento";
        jornada.Name = "acu_jornada";
        precioDirecto.Name = "acu_precio_directo";
        unidadRendimientoACU.Name = "acu_unidad_rendimiento";
        porRendimientoACU.AccessibleDescription = porAsignacionACU.AccessibleDescription =
            "Forma de análisis del proyecto, compartida con Info. proyecto. El cálculo de cada recurso se elige en su menú contextual.";
        porRendimientoACU.CheckedChanged += (_, _) => CambiarFormaAnalisisACU(porRendimientoACU);
        porAsignacionACU.CheckedChanged += (_, _) => CambiarFormaAnalisisACU(porAsignacionACU);
        FlowLayoutPanel Grupo(params Control[] controles)
        {
            var grupo = new FlowLayoutPanel
            {
                AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                WrapContents = false, Margin = Padding.Empty
            };
            grupo.Controls.AddRange(controles);
            return grupo;
        }
        var barra = barraRendimientoACU = new FlowLayoutPanel
        {
            Name = "acu_barra_rendimiento", Dock = DockStyle.Top,
            AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = true, Padding = new(4), Margin = Padding.Empty,
            BackColor = MYG2027_TemaComercial.Superficie
        };
        barra.Controls.AddRange(new Control[]
        {
            Grupo(porRendimientoACU, porAsignacionACU),
            Grupo(Etiqueta("Rend.:"), rendimiento, unidadRendimientoACU),
            Grupo(jornada, Etiqueta("Horas / día"))
        });
        return barra;
    }

    private void PrepararTotalACU(TabPage pagina)
    {
        // Usa la misma fuente administrada por el panel; no introduce otro recurso GDI.
        totalPrecioACU.Font = negrita;
        void Dimensionar() => totalPrecioACU.Height = (int)Math.Round(36F * DeviceDpi / 96F);
        DpiChangedAfterParent += (_, _) => Dimensionar();
        Dimensionar();
        pagina.Controls.Add(totalPrecioACU);
        AplicarTemaContextoACU();
    }

    private void AplicarTemaContextoACU()
    {
        totalPrecioACU.BackColor = MYG2027_TemaComercial.SuperficieAlterna;
        totalPrecioACU.ForeColor = MYG2027_TemaComercial.Texto;
        if (barraRendimientoACU != null)
        {
            barraRendimientoACU.BackColor = MYG2027_TemaComercial.Superficie;
            foreach (Control grupo in barraRendimientoACU.Controls) grupo.BackColor = MYG2027_TemaComercial.Superficie;
        }
        foreach (Control control in new Control[] { porRendimientoACU, porAsignacionACU, unidadRendimientoACU })
        {
            control.BackColor = MYG2027_TemaComercial.Superficie;
            control.ForeColor = MYG2027_TemaComercial.Texto;
        }
    }

    private void CambiarFormaAnalisisACU(RadioButton opcion)
    {
        if (cargando || !opcion.Checked || !HayPartida) return;
        Intentar(() =>
        {
            try
            {
                FinalizarEdicion();
                var proyecto = obtenerProyectoEstructura?.Invoke();
                if (proyecto?.Datos == null) return;
                bool rendimientoElegido = opcion == porRendimientoACU;
                if (proyecto.Datos.PorRendimientoCuadrilla == rendimientoElegido &&
                    proyecto.Datos.PorAsignacionRecursos == !rendimientoElegido) return;
                antes();
                // Reutiliza el ajuste existente del proyecto. No convierte las modalidades
                // Directa/Rendimiento/%MO almacenadas por cada línea del análisis.
                proyecto.Datos.PorRendimientoCuadrilla = rendimientoElegido;
                proyecto.Datos.PorAsignacionRecursos = !rendimientoElegido;
                Cambiado();
            }
            finally { ActualizarContextoACU(); }
        });
    }

    private void ActualizarContextoACU(MYGCalculoPresupuesto calculo = null)
    {
        if (cabeceraACU == null) return;
        bool previo = cargando;
        cargando = true;
        try
        {
            var partida = PartidaActual;
            bool valida = partida != null && !MYGProyectoStorage.EsTitulo(partida);
            var datos = obtenerProyectoEstructura?.Invoke()?.Datos;
            porRendimientoACU.Enabled = porAsignacionACU.Enabled = valida && datos != null;
            porRendimientoACU.Checked = datos?.PorRendimientoCuadrilla == true;
            porAsignacionACU.Checked = datos?.PorAsignacionRecursos == true;
            unidadRendimientoACU.Text = valida ? partida.Unidad + "/día ×" : "unidad/día ×";
            totalPrecioACU.AccessibleDescription = "Precio unitario del análisis de costos de la partida.";
            if (!valida || P == null)
            {
                cabeceraACU.ActualizarTiempoEjecucion("—", "—");
                totalPrecioACU.Text = "Total ACU · —";
                return;
            }
            try
            {
                calculo ??= MYGMotorPresupuestos.CrearCalculo(P);
                decimal cantidad = calculo.Cantidad(partida);
                decimal dias = cantidad / partida.Costos.RendimientoDiario;
                cabeceraACU.ActualizarTiempoEjecucion(cantidad.ToString("N3", CultureInfo.InvariantCulture) + " " + partida.Unidad,
                    dias.ToString("N3", CultureInfo.InvariantCulture) + " días");
                totalPrecioACU.Text = "Total ACU · " + P.Costos.Moneda + " " +
                    MYGFormatoPresupuesto.Dinero(calculo.Analizar(partida).PrecioUnitario);
            }
            catch (Exception ex)
            {
                cabeceraACU.ActualizarTiempoEjecucion("No disponible", "—");
                totalPrecioACU.Text = "Total ACU · Error de cálculo";
                totalPrecioACU.AccessibleDescription = ex.Message;
            }
        }
        finally { cargando = previo; }
    }
}
