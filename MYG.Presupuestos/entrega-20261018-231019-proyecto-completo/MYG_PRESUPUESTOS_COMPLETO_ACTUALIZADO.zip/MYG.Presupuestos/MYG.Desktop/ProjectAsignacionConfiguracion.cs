using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace MYG_2027;

// Project puede recalcular las asignaciones al cambiar duración, avance o
// divisiones. Compartir estas operaciones permite comprobar el contrato sin COM.
internal static class MYGConfiguracionAsignacionProject
{
    internal static bool Restaurar(MYGAsignacionExportacionProject datos, int tipo,
        Func<string, object> leer, Action<string, object> escribir)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(leer);
        ArgumentNullException.ThrowIfNull(escribir);
        bool restaurada = false;
        foreach (var (campo, esperado, tolerancia) in Magnitudes(datos, tipo))
        {
            if (NumeroIgual(leer(campo), esperado, tolerancia)) continue;
            // No escribir Cost en trabajo/material: se calcula con la tarifa.
            // Establecer primero Units y después Work conserva las horas del
            // ACU aunque fijar la dedicación haya recalculado el trabajo.
            // Project distingue Units asignadas de PeakUnits efectivas.
            escribir(campo, (double)esperado);
            restaurada = true;
        }
        return restaurada;
    }

    internal static void Verificar(MYGAsignacionExportacionProject datos, int tipo,
        string nombreRecurso, string nombreTarea, Func<string, object> leer)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(leer);
        foreach (var magnitud in Magnitudes(datos, tipo))
            VerificarMagnitud(magnitud, nombreRecurso, nombreTarea, leer);
        // Comprobar también el resultado económico calculado por Project.
        // Una cantidad correcta no basta si Project cambió la tarifa o costo.
        if (tipo != 2) VerificarMagnitud(("Cost", datos.Costo, 0.02m), nombreRecurso, nombreTarea, leer);
    }

    private static void VerificarMagnitud((string Campo, decimal Esperado, decimal Tolerancia) magnitud,
        string nombreRecurso, string nombreTarea, Func<string, object> leer)
    {
        var (campo, esperado, tolerancia) = magnitud;
        object recibido = leer(campo);
        if (!NumeroIgual(recibido, esperado, tolerancia))
            throw new InvalidOperationException("Microsoft Project cambió la asignación del recurso «" + nombreRecurso +
                "» en la tarea «" + nombreTarea + "». Campo: " + campo +
                (campo == "Work" ? " (minutos)" : "") + ". Esperado: " + esperado.ToString(CultureInfo.InvariantCulture) +
                "; recibido: " + (recibido == null || recibido == DBNull.Value ? "(sin valor)" : Convert.ToString(recibido, CultureInfo.InvariantCulture)) +
                ". No se reemplazó el archivo de destino.");
    }

    private static IReadOnlyList<(string Campo, decimal Esperado, decimal Tolerancia)> Magnitudes(
        MYGAsignacionExportacionProject datos, int tipo)
    {
        if (tipo is not (0 or 1 or 2))
            throw new InvalidDataException("Tipo de recurso de Microsoft Project desconocido.");
        var campos = new List<(string, decimal, decimal)>();
        if ((tipo is 0 or 1) && datos.Unidades.HasValue)
            campos.Add(("Units", datos.Unidades.Value, 0.000001m));
        if (tipo == 1 && datos.TrabajoHoras.HasValue)
            campos.Add(("Work", datos.TrabajoHoras.Value * 60m, 0.01m));
        if (tipo == 2) campos.Add(("Cost", datos.Costo, 0.02m));
        return campos;
    }

    private static bool NumeroIgual(object valor, decimal esperado, decimal tolerancia)
    {
        if (valor == null) return false;
        try { return Math.Abs(Convert.ToDecimal(valor, CultureInfo.InvariantCulture) - esperado) <= tolerancia; }
        catch (FormatException) { return false; }
        catch (InvalidCastException) { return false; }
        catch (OverflowException) { return false; }
    }
}
