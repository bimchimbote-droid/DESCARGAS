using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelCronograma
{
    private MYGCronogramaDetallesControl detallesTarea;
    private bool actualizandoDetalle;
    private string detalleSeleccionado;
    private bool detallePendiente;

    private void ProgramarDetalleTarea()
    {
        // SelectionChanged precede a CurrentCellChanged. Esperar a que termine
        // el cambio de celda evita leer la fila anterior y reconstruir la tabla
        // dentro de SetCurrentCellAddressCore al guardar un borrador.
        if (cargando || aplicando || detallePendiente || !IsHandleCreated || IsDisposed) return;
        detallePendiente = true;
        BeginInvoke((Action)(() =>
        {
            detallePendiente = false;
            if (!IsDisposed && !cargando && !aplicando) Intentar(ActualizarDetalleTarea);
        }));
    }

    private void InicializarDetalleTarea()
    {
        detallesTarea = new MYGCronogramaDetallesControl(obtener, obtenerProyecto,
            plan => AplicarCopia(plan), () => Editable)
        { Name = "cronograma_detalles_tarea", Dock = DockStyle.Bottom, Height = 360, Visible = false };
        detallesTarea.OpcionesCambiadas += opciones =>
        {
            gantt.ConfigurarPresentacion(opciones, obtenerProyecto());
            tabla.Invalidate();
        };
        detallesTarea.CerrarSolicitado += () =>
        {
            if (!detallesTarea.ConfirmarSalida()) return;
            detallesTarea.Visible = false;
            AplicarTema();
        };
        Controls.Add(detallesTarea);
        Controls.SetChildIndex(detallesTarea, 1);
        SizeChanged += (_, _) => DimensionarDetalleTarea();
        DpiChangedAfterParent += (_, _) => DimensionarDetalleTarea();
    }

    private void DimensionarDetalleTarea()
    {
        if (detallesTarea?.Visible != true) return;
        int preferido = (int)Math.Round(360 * DeviceDpi / 96F);
        detallesTarea.Height = Math.Min(preferido, Math.Max(140, ClientSize.Height - 200));
    }

    private void InformacionTarea()
    {
        FinalizarEdicion();
        if (tiempoTrabajo.Visible)
        {
            if (!tiempoTrabajo.ConfirmarCierre()) return;
            tiempoTrabajo.Visible = false;
        }
        detallesTarea.Visible = true;
        detallesTarea.SeleccionarInformacion();
        ActualizarDetalleTarea();
        DimensionarDetalleTarea();
        AplicarTema();
    }

    private void ActualizarDetalleTarea()
    {
        if (actualizandoDetalle || detallesTarea == null || resultado == null) return;
        actualizandoDetalle = true;
        try
        {
            string id = Actual?.Tarea.Id;
            if (detalleSeleccionado != id && detallesTarea.TieneCambios && !detallesTarea.ConfirmarSalida(false))
            {
                var anterior = tabla.Rows.Cast<System.Windows.Forms.DataGridViewRow>()
                    .FirstOrDefault(r => (r.Tag as MYGResultadoTarea)?.Tarea.Id == detalleSeleccionado);
                if (anterior != null)
                {
                    tabla.ClearSelection(); tabla.CurrentCell = anterior.Cells["NOMBRE"]; anterior.Selected = true;
                    gantt.Seleccionar(new[] { detalleSeleccionado });
                }
                return;
            }
            // También carga las preferencias guardadas al volver a abrir el proyecto.
            detallesTarea.Cargar(id);
            detalleSeleccionado = id;
            gantt.ConfigurarPresentacion(detallesTarea.Opciones, obtenerProyecto());
        }
        finally { actualizandoDetalle = false; }
    }
}
