using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;

namespace MYG_2027;

/// <summary>Exporta el mismo plan paginado de la vista, sin perder las páginas restantes.</summary>
internal static class MYGReportesImagenExportacion
{
    private const int Resolucion = 150;

    // En un ZIP cada página conserva su propio tamaño, orientación y formato.
    // La interfaz consulta esta ruta antes de solicitar confirmación de sobrescritura.
    internal static string RutaSalida(string rutaImagen, int desde, int hasta)
    {
        ValidarExtension(rutaImagen);
        if (desde < 1 || hasta < desde) throw new ArgumentOutOfRangeException(nameof(desde), "El rango de páginas no es válido.");
        return hasta > desde ? Path.ChangeExtension(rutaImagen, ".zip") : rutaImagen;
    }

    internal static IReadOnlyList<string> Guardar(string rutaImagen, MYGReportesImpresion.Vista vista, int desde, int hasta)
    {
        ArgumentNullException.ThrowIfNull(vista);
        string salida = Path.GetFullPath(RutaSalida(rutaImagen, desde, hasta));
        if (hasta > vista.CantidadPaginas) throw new ArgumentOutOfRangeException(nameof(hasta), "El rango supera las páginas del informe.");
        string extension = ValidarExtension(rutaImagen);
        string temporal = Path.Combine(Path.GetDirectoryName(salida)!, "." + Path.GetFileName(salida) + "." + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using (var archivo = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                if (desde == hasta)
                    EscribirPagina(archivo, vista, desde - 1, extension);
                else
                {
                    using var zip = new ZipArchive(archivo, ZipArchiveMode.Create, leaveOpen: true);
                    for (int numero = desde; numero <= hasta; numero++)
                    {
                        var entrada = zip.CreateEntry("pagina-" + numero.ToString("000", CultureInfo.InvariantCulture) + extension, CompressionLevel.Optimal);
                        using var contenido = new MemoryStream();
                        EscribirPagina(contenido, vista, numero - 1, extension);
                        contenido.Position = 0;
                        using var destino = entrada.Open();
                        contenido.CopyTo(destino);
                    }
                }
            }
            File.Move(temporal, salida, overwrite: true);
            return new[] { salida };
        }
        finally
        {
            if (File.Exists(temporal)) File.Delete(temporal);
        }
    }

    private static string ValidarExtension(string ruta)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(ruta);
        string extension = Path.GetExtension(ruta).ToLowerInvariant();
        if (extension is not (".bmp" or ".gif" or ".jpg" or ".jpeg" or ".png" or ".tif" or ".tiff" or ".emf" or ".wmf"))
            throw new ArgumentException("Seleccione BMP, GIF, JPEG, PNG, TIFF, EMF o WMF.", nameof(ruta));
        return extension;
    }

    private static void EscribirPagina(Stream destino, MYGReportesImpresion.Vista vista, int indice, string extension)
    {
        if (extension is ".emf" or ".wmf")
        {
            EscribirMetarchivo(destino, vista, indice, extension == ".wmf");
            return;
        }
        SizeF papel = vista.TamanoPagina(indice);
        using var imagen = new Bitmap((int)Math.Ceiling(papel.Width * Resolucion), (int)Math.Ceiling(papel.Height * Resolucion), PixelFormat.Format24bppRgb);
        imagen.SetResolution(Resolucion, Resolucion);
        using (var dibujo = Graphics.FromImage(imagen))
        {
            dibujo.Clear(Color.White);
            dibujo.SmoothingMode = SmoothingMode.HighQuality;
            dibujo.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            vista.DibujarPagina(dibujo, indice);
        }
        ImageFormat formato = extension switch
        {
            ".bmp" => ImageFormat.Bmp,
            ".gif" => ImageFormat.Gif,
            ".jpg" or ".jpeg" => ImageFormat.Jpeg,
            ".tif" or ".tiff" => ImageFormat.Tiff,
            _ => ImageFormat.Png
        };
        imagen.Save(destino, formato);
    }

    private static void EscribirMetarchivo(Stream destino, MYGReportesImpresion.Vista vista, int indice, bool wmf)
    {
        SizeF papel = vista.TamanoPagina(indice);
        using var referencia = Graphics.FromHwnd(IntPtr.Zero);
        IntPtr hdc = referencia.GetHdc();
        try
        {
            using var contenido = new MemoryStream();
            using (var metarchivo = new Metafile(contenido, hdc, new RectangleF(PointF.Empty, papel), MetafileFrameUnit.Inch, EmfType.EmfOnly))
            {
                using (var dibujo = Graphics.FromImage(metarchivo)) vista.DibujarPagina(dibujo, indice);
                if (wmf)
                {
                    IntPtr handle = metarchivo.GetHenhmetafile();
                    try
                    {
                        uint longitud = GetWinMetaFileBits(handle, 0, null, 8, hdc);
                        if (longitud == 0) throw new Win32Exception(Marshal.GetLastWin32Error(), "No se pudo convertir la página a WMF.");
                        var datos = new byte[checked((int)longitud)];
                        if (GetWinMetaFileBits(handle, longitud, datos, 8, hdc) != longitud)
                            throw new Win32Exception(Marshal.GetLastWin32Error(), "No se pudo completar el archivo WMF.");
                        // Cabecera placeable de Aldus: dimensiones físicas en twips y suma XOR.
                        ushort[] cabecera = { 0xCDD7, 0x9AC6, 0, 0, 0, checked((ushort)Math.Round(papel.Width * 1440)),
                            checked((ushort)Math.Round(papel.Height * 1440)), 1440, 0, 0 };
                        ushort suma = 0;
                        using var escritor = new BinaryWriter(destino, System.Text.Encoding.UTF8, leaveOpen: true);
                        foreach (ushort palabra in cabecera) { escritor.Write(palabra); suma ^= palabra; }
                        escritor.Write(suma);
                        escritor.Write(datos);
                    }
                    finally { DeleteEnhMetaFile(handle); }
                    return;
                }
            }
            contenido.Position = 0;
            contenido.CopyTo(destino);
        }
        finally { referencia.ReleaseHdc(hdc); }
    }

    [DllImport("gdi32.dll", SetLastError = true)]
    private static extern uint GetWinMetaFileBits(IntPtr metarchivo, uint longitud, [Out] byte[] datos, int modoMapeo, IntPtr referencia);
    [DllImport("gdi32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DeleteEnhMetaFile(IntPtr metarchivo);
}
