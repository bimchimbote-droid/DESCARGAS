using WinForms = System.Windows.Forms;

namespace MYG.Externo;
internal static class Program
{
    [STAThread]
    public static void Main()
    {
        WinForms.Application.SetHighDpiMode(WinForms.HighDpiMode.PerMonitorV2);
        WinForms.Application.EnableVisualStyles(); WinForms.Application.SetCompatibleTextRenderingDefault(false);
        MYG_2027.MYG2027_TemaComercial.Inicializar();
        using var sesion = new SesionDesktop();
        using var login = new LoginForm(sesion);
        if (login.ShowDialog() != WinForms.DialogResult.OK) return;
        WinForms.Application.Run(new MYG_2027.InicioForm(sesion));
    }
}
