using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MYG_2027;

internal enum MYGFormatoVistaReporte { Pdf, Html, Mht, Rtf, Xls, Xlsx, Csv, Texto, Imagen }

/// <summary>Las dos listas de formatos comparten nombres, descripciones y dibujos.</summary>
internal static class MYGVistaPreliminarExportacionMenu
{
    internal sealed record Formato(MYGFormatoVistaReporte Valor, string Id, string Titulo, string Descripcion,
        string Extension, string Filtro);

    internal static readonly Formato[] Formatos =
    {
        new(MYGFormatoVistaReporte.Pdf, "pdf", "Documento PDF", "Formato Adobe PDF", "pdf", "Documento PDF (*.pdf)|*.pdf"),
        new(MYGFormatoVistaReporte.Html, "html", "Documento HTML", "Página Web", "html", "Documento HTML (*.html)|*.html"),
        new(MYGFormatoVistaReporte.Mht, "mht", "Documento MHT", "Página Web simple", "mht", "Documento MHT (*.mht)|*.mht"),
        new(MYGFormatoVistaReporte.Rtf, "rtf", "Documento RTF", "Texto con formato enriquecido", "rtf", "Documento RTF (*.rtf)|*.rtf"),
        new(MYGFormatoVistaReporte.Xls, "xls", "Documento XLS", "Libro Microsoft Excel", "xls", "Libro Microsoft Excel 97-2003 (*.xls)|*.xls"),
        new(MYGFormatoVistaReporte.Xlsx, "xlsx", "Documento XLSX", "Libro Microsoft Excel", "xlsx", "Libro Microsoft Excel (*.xlsx)|*.xlsx"),
        new(MYGFormatoVistaReporte.Csv, "csv", "Documento CSV", "Texto separado por comas", "csv", "Documento CSV (*.csv)|*.csv"),
        new(MYGFormatoVistaReporte.Texto, "txt", "Documento de Texto", "Texto Simple", "txt", "Documento de Texto (*.txt)|*.txt"),
        new(MYGFormatoVistaReporte.Imagen, "img", "Documento de Imagen", "BMP, GIF, JPEG, PNG, TIFF, EMF, WMF", "png",
            "Imagen PNG (*.png)|*.png|Imagen BMP (*.bmp)|*.bmp|Imagen GIF (*.gif)|*.gif|Imagen JPEG (*.jpg)|*.jpg|Imagen TIFF (*.tiff)|*.tiff|Metarchivo EMF (*.emf)|*.emf|Metarchivo WMF (*.wmf)|*.wmf")
    };

    internal static void Preparar(ToolStripDropDownButton boton, bool correo, Action<Formato> seleccionar)
    {
        var menu = new MenuFormatos { Name = correo ? "vista_menu_email" : "vista_menu_exportar" };
        boton.DropDown = menu;
        boton.Disposed += (_, _) => menu.Dispose();
        foreach (var formato in Formatos)
        {
            // La referencia de correo omite HTML; MHT contiene la página en un solo archivo.
            if (correo && formato.Valor == MYGFormatoVistaReporte.Html) continue;
            var item = new OpcionFormato(formato, correo)
            {
                Name = "vista_" + (correo ? "email_" : "exportar_") + formato.Id,
                Tag = formato.Valor,
                AccessibleName = formato.Titulo,
                AccessibleDescription = formato.Descripcion,
                ToolTipText = formato.Valor == MYGFormatoVistaReporte.Xls
                    ? "Exporta todas las hojas. Requiere Microsoft Excel instalado."
                    : formato.Valor is MYGFormatoVistaReporte.Pdf or MYGFormatoVistaReporte.Imagen
                        ? formato.Descripcion + ". Respeta el rango de páginas indicado."
                        : formato.Descripcion + ". Exporta todas las hojas del informe."
            };
            MYGEspecificacionesCinta.Icono(item, item.IdIcono,
                MYGVistaPreliminarCintaIconos.Dibujar, 40, true);
            item.Click += (_, _) => seleccionar(formato);
            menu.Items.Add(item);
        }
    }

    private sealed class MenuFormatos : ToolStripDropDownMenu
    {
        private readonly ToolStripRenderer propio = new RendererFormatos();
        private bool restaurando;
        internal MenuFormatos()
        {
            ShowImageMargin = false; ShowCheckMargin = false;
            Padding = new Padding(2); Renderer = propio;
        }
        protected override void OnRendererChanged(EventArgs e)
        {
            base.OnRendererChanged(e);
            if (propio == null || restaurando || ReferenceEquals(Renderer, propio)) return;
            restaurando = true;
            try { Renderer = propio; }
            finally { restaurando = false; }
        }
    }

    private sealed class RendererFormatos : ToolStripProfessionalRenderer
    {
        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {
            using var fondo = new SolidBrush(SystemInformation.HighContrast ? SystemColors.Menu
                : MYG2027_TemaComercial.Oscuro ? MYGEspecificacionesCinta.AzulFondo : Color.White);
            e.Graphics.FillRectangle(fondo, e.AffectedBounds);
        }
        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
        {
            if (!e.Item.Selected) return;
            var area = new Rectangle(1, 1, e.Item.Width - 3, e.Item.Height - 2);
            if (SystemInformation.HighContrast)
            {
                using var fondo = new SolidBrush(SystemColors.Highlight);
                e.Graphics.FillRectangle(fondo, area);
            }
            else
            {
                using var fondo = new LinearGradientBrush(area, Color.FromArgb(255, 230, 137), Color.FromArgb(255, 213, 83), 90f);
                using var borde = new Pen(Color.FromArgb(213, 171, 56));
                e.Graphics.FillRectangle(fondo, area); e.Graphics.DrawRectangle(borde, area);
            }
        }
    }

    internal sealed class OpcionFormato : ToolStripMenuItem
    {
        private readonly Font fuente = new("Segoe UI", 10);
        internal Formato Formato { get; }
        internal readonly string IdIcono;
        internal OpcionFormato(Formato formato, bool correo) : base(formato.Titulo + "\n" + formato.Descripcion)
        {
            Formato = formato;
            IdIcono = "formato_" + formato.Id + (correo ? "_email" : "");
            Padding = Padding.Empty; Margin = Padding.Empty;
            Font = fuente;
        }
        public override Size GetPreferredSize(Size constrainingSize)
        {
            float factor = (Owner?.DeviceDpi ?? 96) / 96f;
            using var negrita = new Font(Font, FontStyle.Bold);
            var flags = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            int ancho = Math.Max(TextRenderer.MeasureText(Formato.Titulo, negrita, Size.Empty, flags).Width,
                TextRenderer.MeasureText(Formato.Descripcion, Font, Size.Empty, flags).Width);
            return new Size(ancho + (int)Math.Ceiling(76 * factor), Math.Max((int)Math.Ceiling(60 * factor), Font.Height * 2 + (int)Math.Ceiling(14 * factor)));
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Owner?.Renderer.DrawMenuItemBackground(new ToolStripItemRenderEventArgs(e.Graphics, this));
            float factor = (Owner?.DeviceDpi ?? 96) / 96f;
            int P(int valor) => (int)Math.Ceiling(valor * factor);
            int lado = P(40);
            // Dibujar al DPI actual evita ampliar el bitmap creado antes de abrir el menú.
            using (var icono = MYGVistaPreliminarCintaIconos.Dibujar(IdIcono, lado, Selected))
                e.Graphics.DrawImageUnscaled(icono, P(8), (Height - lado) / 2);
            Color texto = SystemInformation.HighContrast ? Selected ? SystemColors.HighlightText : SystemColors.MenuText
                : Selected ? Color.FromArgb(34, 53, 73) : MYGEspecificacionesCinta.Texto;
            using var negrita = new Font(Font, FontStyle.Bold);
            var flags = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter;
            int alto = Font.Height + P(2), y = (Height - alto * 2) / 2;
            var titulo = new Rectangle(P(58), y, Width - P(66), alto);
            var descripcion = new Rectangle(titulo.X, y + alto, titulo.Width, alto);
            TextRenderer.DrawText(e.Graphics, Formato.Titulo, negrita, titulo, texto, flags);
            TextRenderer.DrawText(e.Graphics, Formato.Descripcion, Font, descripcion, texto, flags);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing) fuente.Dispose();
            base.Dispose(disposing);
        }
    }
}
