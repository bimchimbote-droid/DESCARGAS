using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MYG_2027;

// Paleta de pantalla: RichEdit sigue editando, guardando e imprimiendo el RTF original.
// Cada cuadro se genera desde el control, nunca desde píxeles ya transformados.
internal sealed class MYGEspecificacionesVistaOscura : NativeWindow, IDisposable
{
    private const int WmSetRedraw = 0x000B, WmPaint = 0x000F, WmEraseBkgnd = 0x0014;
    private const int WmPrintClient = 0x0318, EmSetBkgndColor = 0x0443;
    [DllImport("user32.dll")] private static extern IntPtr BeginPaint(IntPtr hwnd, out Pintura pintura);
    [DllImport("user32.dll")] private static extern bool EndPaint(IntPtr hwnd, ref Pintura pintura);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr hwnd, int msg, IntPtr wp, IntPtr lp);
    [DllImport("gdi32.dll")] private static extern bool SetViewportOrgEx(IntPtr dc, int x, int y, IntPtr anterior);
    [StructLayout(LayoutKind.Sequential)]
    private struct Pintura
    {
        internal IntPtr dc;
        internal int borrar, izquierda, arriba, derecha, abajo, restaurar, actualizar;
        internal int reservado1, reservado2, reservado3, reservado4, reservado5, reservado6, reservado7, reservado8;
    }

    private readonly RichTextBox documento;
    private readonly Dictionary<int, int> colores = new();
    private Bitmap imagen;
    private byte[] pixeles;
    private bool oscuro, dibujando, repintadoSuspendido;
    private Color fondoDocumento = Color.White;

    // Adornos de pantalla (por ejemplo, ortografía). No participan en la
    // captura WM_PRINTCLIENT, el RTF ni las salidas de impresión/exportación.
    internal Action<Graphics, Rectangle> PinturaAdicional { get; set; }

    // Color de autor utilizado para el papel. La paleta de pantalla nunca lo
    // sustituye ni escribe colores de tema en el documento RTF.
    internal Color FondoDocumento
    {
        get => fondoDocumento;
        set
        {
            if (fondoDocumento == value) return;
            fondoDocumento = value;
            AplicarTema();
        }
    }

    internal MYGEspecificacionesVistaOscura(RichTextBox documento)
    {
        this.documento = documento;
        documento.HandleCreated += CrearHandle;
        documento.HandleDestroyed += DestruirHandle;
        documento.TextChanged += Actualizar;
        documento.SelectionChanged += Actualizar;
        documento.VScroll += Actualizar;
        documento.HScroll += Actualizar;
        documento.SizeChanged += Actualizar;
        if (documento.IsHandleCreated) AssignHandle(documento.Handle);
        AplicarTema();
    }

    internal void AplicarTema()
    {
        oscuro = MYG2027_TemaComercial.Oscuro && !SystemInformation.HighContrast;
        // El fondo real de RichEdit también debe ser oscuro: al tomar el foco,
        // editar o desplazar, Windows puede pintar antes de nuestro WM_PAINT.
        documento.BackColor = oscuro
            ? Color.FromArgb(unchecked((int)0xff000000) |
                MYGEspecificacionesPaletaDocumento.TransformarRgb(fondoDocumento.ToArgb() & 0xffffff))
            : fondoDocumento;
        documento.Invalidate();
    }
    private void CrearHandle(object sender, EventArgs e)
    {
        repintadoSuspendido = false;
        AssignHandle(documento.Handle);
        AplicarTema();
    }
    private void DestruirHandle(object sender, EventArgs e)
    {
        ReleaseHandle();
        repintadoSuspendido = false;
    }
    private void Actualizar(object sender, EventArgs e)
    {
        if ((oscuro || PinturaAdicional != null) && !dibujando) documento.Invalidate();
    }

    protected override void WndProc(ref Message mensaje)
    {
        // Cambiar temporalmente el COLORREF para WM_PRINTCLIENT puede pedir
        // un repintado síncrono. Nunca dejar que ese mensaje pinte los colores
        // originales en pantalla: el cuadro exterior consumirá la invalidación.
        if (oscuro && dibujando && (mensaje.Msg is WmPaint or WmEraseBkgnd))
        {
            mensaje.Result = mensaje.Msg == WmEraseBkgnd ? new IntPtr(1) : IntPtr.Zero;
            return;
        }
        // Una operación de zoom puede haber suspendido ya el dibujo. Las
        // capturas deben respetarlo y no reactivarlo antes de su Dispose.
        if (mensaje.Msg == WmSetRedraw)
            repintadoSuspendido = mensaje.WParam == IntPtr.Zero;
        if (oscuro && !dibujando)
        {
            if (documento.Visible && mensaje.Msg == WmEraseBkgnd) { mensaje.Result = new IntPtr(1); return; }
            if (documento.Visible && !repintadoSuspendido && mensaje.Msg == WmPaint)
            { Pintar(); mensaje.Result = IntPtr.Zero; return; }
            if (mensaje.Msg == WmPrintClient)
            {
                // WM_PRINTCLIENT solicita los colores originales; no es un
                // repintado de la vista oscura ni una modificación del RTF.
                dibujando = true;
                IntPtr anterior = PrepararFondoOriginal();
                try { base.WndProc(ref mensaje); }
                finally
                {
                    RestaurarFondo(anterior);
                    dibujando = false;
                }
                documento.Invalidate();
                return;
            }
        }
        base.WndProc(ref mensaje);
        if (!oscuro && mensaje.Msg == WmPaint && !repintadoSuspendido && documento.Visible && PinturaAdicional != null)
        {
            Rectangle region = RegionVisible();
            if (region.Width > 0 && region.Height > 0)
            {
                using var grafico = Graphics.FromHwnd(Handle);
                PinturaAdicional(grafico, region);
            }
        }
        // RichEdit también dibuja directamente al mover selección, foco o caret.
        if ((oscuro || PinturaAdicional != null) && !dibujando && (mensaje.Msg is 0x0007 or 0x0008 or 0x0100 or 0x0102 or 0x010F
            or 0x0201 or 0x0202 or 0x0203 or 0x020A or 0x020E or 0x0114 or 0x0115
            or 0x0047 or 0x04DE // WM_WINDOWPOSCHANGED, EM_SETSCROLLPOS.
            || (mensaje.Msg == WmSetRedraw && mensaje.WParam != IntPtr.Zero)
            || (mensaje.Msg == 0x0200 && (mensaje.WParam.ToInt64() & 1) != 0)))
            documento.Invalidate();
    }

    private Rectangle RegionVisible()
    {
        Rectangle region = documento.ClientRectangle;
        for (Control padre = documento.Parent; padre != null; padre = padre.Parent)
        {
            region.Intersect(documento.RectangleToClient(padre.RectangleToScreen(padre.ClientRectangle)));
            if (region.IsEmpty) break;
        }
        return region;
    }

    private void Pintar()
    {
        Rectangle region = RegionVisible();
        bool preparada = false;
        dibujando = true;
        try
        {
            if (region.Width <= 0 || region.Height <= 0) return;
            if (imagen == null || imagen.Size != region.Size)
            {
                imagen?.Dispose();
                imagen = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppRgb);
                pixeles = new byte[checked(region.Width * region.Height * 4)];
            }
            using (var origen = Graphics.FromImage(imagen))
            {
                origen.Clear(fondoDocumento);
                IntPtr memoria = origen.GetHdc();
                try
                {
                    SetViewportOrgEx(memoria, -region.X, -region.Y, IntPtr.Zero);
                    // RichEdit conserva su fondo oscuro entre cuadros. Sólo
                    // esta captura usa el color de autor y luego se transforma.
                    IntPtr anterior = PrepararFondoOriginal();
                    try
                    {
                        // PRF_CLIENT | PRF_ERASEBKGND.
                        SendMessage(Handle, WmPrintClient, memoria, new IntPtr(0x0004 | 0x0008));
                    }
                    finally { RestaurarFondo(anterior); }
                }
                finally { origen.ReleaseHdc(memoria); }
            }
            var datos = imagen.LockBits(new Rectangle(Point.Empty, imagen.Size),
                ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            try
            {
                Marshal.Copy(datos.Scan0, pixeles, 0, pixeles.Length);
                for (int i = 0; i < pixeles.Length; i += 4)
                {
                    int rgb = pixeles[i + 2] << 16 | pixeles[i + 1] << 8 | pixeles[i];
                    if (!colores.TryGetValue(rgb, out int nuevo))
                    {
                        nuevo = MYGEspecificacionesPaletaDocumento.TransformarRgb(rgb);
                        if (colores.Count < 32768) colores.Add(rgb, nuevo);
                    }
                    pixeles[i] = (byte)nuevo;
                    pixeles[i + 1] = (byte)(nuevo >> 8);
                    pixeles[i + 2] = (byte)(nuevo >> 16);
                }
                Marshal.Copy(pixeles, 0, datos.Scan0, pixeles.Length);
            }
            finally { imagen.UnlockBits(datos); }
            DibujarSeleccion(region);
            preparada = true;
        }
        finally
        {
            // EM_SETBKGNDCOLOR puede invalidar RichEdit. BeginPaint se hace
            // DESPUÉS de restaurar su fondo real: consume esa invalidación y
            // evita un ciclo continuo de WM_PAINT o un cuadro blanco intermedio.
            IntPtr dc = BeginPaint(Handle, out var pintura);
            try
            {
                if (dc != IntPtr.Zero && region.Width > 0 && region.Height > 0)
                {
                    using var destino = Graphics.FromHdc(dc);
                    if (preparada) destino.DrawImageUnscaled(imagen, region.Location);
                    else
                    {
                        using var fondo = new SolidBrush(documento.BackColor);
                        destino.FillRectangle(fondo, region);
                    }
                    PinturaAdicional?.Invoke(destino, region);
                }
            }
            finally
            {
                EndPaint(Handle, ref pintura);
                dibujando = false;
            }
        }
    }

    private IntPtr PrepararFondoOriginal()
    {
        // No alternar WM_SETREDRAW dentro de WM_PAINT. DefWindowProc cambia
        // WS_VISIBLE y la reactivación permite repintados nativos intermedios
        // al desplazar una hoja recortada por sus padres.
        // El mensaje devuelve el COLORREF anterior. BackColor administrado,
        // los colores de caracteres y el historial permanecen intactos.
        return SendMessage(Handle, EmSetBkgndColor, IntPtr.Zero,
            new IntPtr(ColorTranslator.ToWin32(fondoDocumento)));
    }

    private void RestaurarFondo(IntPtr anterior)
    {
        // El guard de dibujando sigue activo hasta restaurar el fondo oscuro.
        SendMessage(Handle, EmSetBkgndColor, IntPtr.Zero, anterior);
    }

    private void DibujarSeleccion(Rectangle region)
    {
        // WM_PRINTCLIENT puede omitir la selección activa; dibujarla en la copia
        // mantiene visibles las selecciones de texto sin cambiar el documento.
        if (documento.SelectionLength == 0 || (!documento.Focused && documento.HideSelection)) return;
        int inicio = documento.SelectionStart, fin = inicio + documento.SelectionLength;
        int primera = Math.Max(documento.GetLineFromCharIndex(inicio),
            documento.GetLineFromCharIndex(documento.GetCharIndexFromPosition(region.Location)));
        int ultima = Math.Min(documento.GetLineFromCharIndex(fin),
            documento.GetLineFromCharIndex(documento.GetCharIndexFromPosition(new Point(region.Right - 1, region.Bottom - 1))) + 1);
        using var grafico = Graphics.FromImage(imagen);
        grafico.TranslateTransform(-region.X, -region.Y);
        using var fondo = new SolidBrush(Color.FromArgb(95, MYG2027_TemaComercial.Seleccion));
        using var fuenteSeleccion = documento.SelectionFont;
        for (int linea = primera; linea <= ultima; linea++)
        {
            int indice = documento.GetFirstCharIndexFromLine(linea);
            if (indice < 0 || indice >= fin) break;
            int siguiente = documento.GetFirstCharIndexFromLine(linea + 1);
            int hasta = Math.Min(fin, siguiente < 0 ? documento.TextLength : siguiente);
            Point desde = documento.GetPositionFromCharIndex(Math.Max(inicio, indice));
            Point final = documento.GetPositionFromCharIndex(hasta);
            int derecha = final.Y == desde.Y ? final.X : documento.ClientSize.Width;
            int alto = siguiente >= 0 ? documento.GetPositionFromCharIndex(siguiente).Y - desde.Y
                : (int)Math.Ceiling((fuenteSeleccion?.Height ?? documento.Font.Height) * documento.ZoomFactor);
            if (derecha > desde.X)
                grafico.FillRectangle(fondo, desde.X, desde.Y, derecha - desde.X, Math.Max(1, alto));
        }
    }

    public void Dispose()
    {
        PinturaAdicional = null;
        documento.HandleCreated -= CrearHandle;
        documento.HandleDestroyed -= DestruirHandle;
        documento.TextChanged -= Actualizar;
        documento.SelectionChanged -= Actualizar;
        documento.VScroll -= Actualizar;
        documento.HScroll -= Actualizar;
        documento.SizeChanged -= Actualizar;
        ReleaseHandle();
        imagen?.Dispose();
        imagen = null;
        pixeles = null;
        colores.Clear();
    }
}
