using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private sealed record ArrastreFila(MYGPanelPresupuesto Origen, string PresupuestoId, string ItemId);
    private Func<bool> autorizarArrastreEstructura;
    private Action sincronizarArrastreEstructura, refrescarEditorArrastre;
    private ArrastreFila candidatoArrastre, filaEnArrastre;
    private string tokenArrastre;
    private Point inicioArrastre;
    private string presupuestoDestinoArrastre, itemDestinoArrastre, ayudaArrastre;
    private MYGDestinoArrastre modoDestinoArrastre;
    private int filaDestinoArrastre = -1, direccionScrollArrastre;
    private readonly System.Windows.Forms.Timer scrollArrastre = new() { Interval = 140 };
    private readonly ToolTip ayudaInicioArrastre = new();

    internal void InicializarArrastreEstructura(Func<bool> autorizado, Action sincronizar, Action refrescarEditor)
    { autorizarArrastreEstructura = autorizado; sincronizarArrastreEstructura = sincronizar; refrescarEditorArrastre = refrescarEditor; }

    private void PrepararArrastreEstructura()
    {
        estructura.AllowDrop = true;
        ayudaInicioArrastre.SetToolTip(estructura, "Arrastre desde el ítem o la descripción. Centro de un título: integrar dentro. Borde superior/inferior: insertar antes/después. Esc: cancelar.");
        estructura.MouseDown += (s, e) =>
        {
            candidatoArrastre = null;
            if (e.Button != MouseButtons.Left || cargando || estructura.IsCurrentCellInEditMode || autorizarArrastreEstructura?.Invoke() != true) return;
            var hit = estructura.HitTest(e.X, e.Y);
            if (hit.RowIndex < 0 || hit.ColumnIndex < 0 || estructura.Columns[hit.ColumnIndex].Name is not ("ITEM" or "DESC")) return;
            var fila = estructura.Rows[hit.RowIndex];
            if (fila.Tag is not ItemPresupuestoDelphin item || !propietariosEstructura.TryGetValue(fila, out var p)) return;
            if (estructura.Columns[hit.ColumnIndex].Name == "ITEM" && PuedeExpandir(item))
            {
                var celda = estructura.GetCellDisplayRectangle(hit.ColumnIndex, hit.RowIndex, false);
                if (e.X - celda.Left < SangriaEstructura(fila) + (int)(20 * DeviceDpi / 96F)) return;
            }
            try { if (MYGEstructuraPresupuestos.Rama(p, item).Any(x => !string.IsNullOrWhiteSpace(x.IdInternoDelphin))) return; }
            catch (Exception ex) when (ex is InvalidOperationException or InvalidDataException) { return; }
            inicioArrastre = e.Location; candidatoArrastre = new(this, p.Id, item.Id);
        };
        estructura.MouseUp += (s, e) => candidatoArrastre = null;
        estructura.MouseMove += (s, e) =>
        {
            if (candidatoArrastre == null || e.Button != MouseButtons.Left || autorizarArrastreEstructura?.Invoke() != true) return;
            var tolerancia = new Rectangle(inicioArrastre.X - SystemInformation.DragSize.Width / 2,
                inicioArrastre.Y - SystemInformation.DragSize.Height / 2, SystemInformation.DragSize.Width, SystemInformation.DragSize.Height);
            if (tolerancia.Contains(e.Location)) return;
            var origen = candidatoArrastre; candidatoArrastre = null;
            Intentar(() =>
            {
                FinalizarEdicion(); filaEnArrastre = origen; tokenArrastre = Guid.NewGuid().ToString("N");
                // OLE intercambia texto estándar. Los IDs y objetos permanecen
                // en este panel; no se serializan objetos con BinaryFormatter.
                try { estructura.DoDragDrop(new DataObject(DataFormats.UnicodeText, tokenArrastre), DragDropEffects.Move); }
                finally { filaEnArrastre = null; tokenArrastre = null; LimpiarDestinoArrastre(); }
            });
        };
        estructura.DragEnter += (s, e) => ActualizarDestinoArrastre(e);
        estructura.DragOver += (s, e) => ActualizarDestinoArrastre(e);
        estructura.DragLeave += (s, e) => LimpiarDestinoArrastre();
        estructura.QueryContinueDrag += (s, e) =>
        { if (e.EscapePressed || autorizarArrastreEstructura?.Invoke() != true) e.Action = DragAction.Cancel; };
        estructura.DragDrop += (s, e) =>
        {
            ActualizarDestinoArrastre(e);
            if (e.Effect != DragDropEffects.Move || filaEnArrastre == null) { LimpiarDestinoArrastre(); return; }
            var origen = filaEnArrastre; string presupuestoId = presupuestoDestinoArrastre, destinoId = itemDestinoArrastre;
            var modo = modoDestinoArrastre; LimpiarDestinoArrastre();
            Intentar(() => AplicarArrastreEstructura(origen.PresupuestoId, origen.ItemId, presupuestoId, destinoId, modo));
        };
        estructura.Paint += PintarDestinoArrastre;
        scrollArrastre.Tick += (s, e) =>
        {
            if (filaEnArrastre == null || direccionScrollArrastre == 0 || estructura.Rows.Count == 0) return;
            int primera = estructura.FirstDisplayedScrollingRowIndex;
            int siguiente = Math.Clamp(primera + direccionScrollArrastre, 0, estructura.Rows.Count - 1);
            if (primera >= 0 && siguiente != primera) estructura.FirstDisplayedScrollingRowIndex = siguiente;
            // Tras desplazar las filas, recalcular el destino usando el cursor actual.
            var cursor = Cursor.Position;
            ActualizarDestinoArrastre(new DragEventArgs(new DataObject(DataFormats.UnicodeText, tokenArrastre), 0, cursor.X, cursor.Y, DragDropEffects.Move, DragDropEffects.None));
        };
        Disposed += (s, e) => { scrollArrastre.Stop(); scrollArrastre.Dispose(); ayudaInicioArrastre.Dispose(); };
    }

    private void ActualizarDestinoArrastre(DragEventArgs e)
    {
        e.Effect = DragDropEffects.None;
        filaDestinoArrastre = -1; ayudaArrastre = null;
        var origen = filaEnArrastre;
        if (autorizarArrastreEstructura?.Invoke() != true || origen == null || !ReferenceEquals(origen.Origen, this) ||
            tokenArrastre == null || e.Data?.GetData(DataFormats.UnicodeText, false) is not string token || token != tokenArrastre)
        { LimpiarDestinoArrastre(); return; }
        var punto = estructura.PointToClient(new(e.X, e.Y));
        int margen = (int)(28 * DeviceDpi / 96F);
        direccionScrollArrastre = punto.Y <= estructura.ColumnHeadersHeight + margen ? -1 : punto.Y >= estructura.ClientSize.Height - margen ? 1 : 0;
        if (direccionScrollArrastre == 0) scrollArrastre.Stop(); else scrollArrastre.Start();
        var hit = estructura.HitTest(punto.X, punto.Y);
        if (hit.RowIndex < 0) { estructura.Invalidate(); return; }
        var fila = estructura.Rows[hit.RowIndex];
        if (!propietariosEstructura.TryGetValue(fila, out var p)) { estructura.Invalidate(); return; }
        var item = fila.Tag as ItemPresupuestoDelphin;
        var rectangulo = estructura.GetRowDisplayRectangle(fila.Index, false);
        float proporcion = (punto.Y - rectangulo.Top) / (float)Math.Max(1, rectangulo.Height);
        var modo = fila.Tag is MYGPresupuestoDocumento ? MYGDestinoArrastre.Dentro :
            MYGProyectoStorage.EsTitulo(item) && proporcion >= .25F && proporcion <= .75F ? MYGDestinoArrastre.Dentro :
            proporcion < .5F ? MYGDestinoArrastre.Antes : MYGDestinoArrastre.Despues;
        if (!MYGArrastrePresupuestos.PuedeMover(obtenerProyectoEstructura?.Invoke(), origen.PresupuestoId, origen.ItemId, p.Id, item?.Id, modo, out string motivo))
        { ayudaArrastre = motivo; estructura.Invalidate(); return; }
        presupuestoDestinoArrastre = p.Id; itemDestinoArrastre = item?.Id; modoDestinoArrastre = modo; filaDestinoArrastre = fila.Index;
        string donde = modo == MYGDestinoArrastre.Dentro ? "dentro de" : modo == MYGDestinoArrastre.Antes ? "antes de" : "después de";
        ayudaArrastre = "Soltar " + donde + " «" + (item?.Descripcion ?? p.Nombre) + "»";
        e.Effect = DragDropEffects.Move; estructura.Invalidate();
    }

    internal void AplicarArrastreEstructura(string presupuestoOrigenId, string itemOrigenId, string presupuestoId, string destinoId, MYGDestinoArrastre modo)
    {
        if (autorizarArrastreEstructura?.Invoke() != true) throw new InvalidOperationException("Inicie una sesión autorizada y espere a que termine la operación actual para mover filas.");
        RequerirPermisoCatalogos(); FinalizarEdicion(); sincronizarArrastreEstructura?.Invoke();
        var proyecto = obtenerProyectoEstructura?.Invoke() ?? throw new InvalidOperationException("El proyecto ya no está abierto.");
        // Comprobar datos, profundidad y posiciones antes de registrar deshacer.
        var prueba = MYGProyectoStorage.Copia(proyecto);
        if (!MYGArrastrePresupuestos.Mover(prueba, presupuestoOrigenId, itemOrigenId, presupuestoId, destinoId, modo)) return;
        var p = proyecto.Presupuestos.Single(x => string.Equals(x.Id, presupuestoOrigenId, StringComparison.OrdinalIgnoreCase));
        var item = p.Items.Single(x => string.Equals(x.Id, itemOrigenId, StringComparison.OrdinalIgnoreCase));
        var destino = p.Items.FirstOrDefault(x => string.Equals(x.Id, destinoId, StringComparison.OrdinalIgnoreCase));
        var padre = p.Items.FirstOrDefault(x => string.Equals(x.Id, item.ParentId, StringComparison.OrdinalIgnoreCase));
        string Nombre(ItemPresupuestoDelphin fila) => "«" + CodigoEstructura(p, fila) + " " + fila.Descripcion + "»";
        string ubicacionActual = padre == null ? "nivel principal de «" + p.Nombre + "»" : "dentro de " + Nombre(padre);
        string donde = modo == MYGDestinoArrastre.Dentro ? "dentro de" : modo == MYGDestinoArrastre.Antes ? "antes de" : "después de";
        string ubicacionNueva = destino == null ? "nivel principal de «" + p.Nombre + "»" : donde + " " + Nombre(destino);
        string mensaje = "¿Está seguro de mover " + (MYGProyectoStorage.EsTitulo(item) ? "el título " : "la partida ") + Nombre(item) + "?" +
            "\n\nOrigen: " + ubicacionActual + ".\nDestino: " + ubicacionNueva + "." +
            (MYGProyectoStorage.EsTitulo(item) ? "\n\nTambién se moverán todas sus partidas y subtítulos." : "");
        if (!MYGConfirmacionUI.Confirmar(this, mensaje, "Confirmar movimiento")) return;
        // El diálogo procesa mensajes: comprobar de nuevo permisos y el proyecto
        // antes de registrar el movimiento en el historial.
        if (autorizarArrastreEstructura?.Invoke() != true)
            throw new InvalidOperationException("La sesión ya no permite mover filas.");
        RequerirPermisoCatalogos();
        if (!ReferenceEquals(proyecto, obtenerProyectoEstructura?.Invoke()))
            throw new InvalidOperationException("El proyecto cambió mientras se confirmaba el movimiento. Vuelva a intentarlo.");
        prueba = MYGProyectoStorage.Copia(proyecto);
        if (!MYGArrastrePresupuestos.Mover(prueba, presupuestoOrigenId, itemOrigenId, presupuestoId, destinoId, modo)) return;
        antes(); MYGArrastrePresupuestos.Mover(proyecto, presupuestoOrigenId, itemOrigenId, presupuestoId, destinoId, modo);
        actual = p.Items.Single(x => string.Equals(x.Id, itemOrigenId, StringComparison.OrdinalIgnoreCase));
        nodoEstructura = actual; seleccionVaciaEstructura = false;
        contraidos.Remove(IdNodoEstructura(p));
        string padreId = actual.ParentId;
        while (!string.IsNullOrWhiteSpace(padreId))
        {
            contraidos.Remove("I:" + padreId);
            padreId = p.Items.FirstOrDefault(x => string.Equals(x.Id, padreId, StringComparison.OrdinalIgnoreCase))?.ParentId;
        }
        // Refrescar sin SeleccionarEstructura: ese método borra el filtro de búsqueda.
        if (refrescarEditorArrastre != null) refrescarEditorArrastre(); else Refrescar();
        despues(); estructura.Focus();
    }

    private void LimpiarDestinoArrastre()
    {
        scrollArrastre.Stop(); direccionScrollArrastre = 0; filaDestinoArrastre = -1;
        presupuestoDestinoArrastre = itemDestinoArrastre = ayudaArrastre = null;
        if (!estructura.IsDisposed) estructura.Invalidate();
    }

    private void PintarDestinoArrastre(object sender, PaintEventArgs e)
    {
        if (filaEnArrastre == null) return;
        float escala = DeviceDpi / 96F;
        if (filaDestinoArrastre >= 0 && filaDestinoArrastre < estructura.Rows.Count)
        {
            var r = estructura.GetRowDisplayRectangle(filaDestinoArrastre, false);
            using var linea = new Pen(MYG2027_TemaComercial.Azul, 2 * escala);
            if (modoDestinoArrastre == MYGDestinoArrastre.Dentro)
                e.Graphics.DrawRectangle(linea, r.Left + 1, r.Top + 1, Math.Max(1, r.Width - 3), Math.Max(1, r.Height - 3));
            else
            {
                float y = modoDestinoArrastre == MYGDestinoArrastre.Antes ? r.Top + 1 : r.Bottom - 1;
                e.Graphics.DrawLine(linea, r.Left + 2, y, r.Right - 2, y);
                using var color = new SolidBrush(linea.Color);
                e.Graphics.FillPolygon(color, new[] { new PointF(r.Left + 2, y - 5 * escala), new PointF(r.Left + 9 * escala, y), new PointF(r.Left + 2, y + 5 * escala) });
            }
        }
        if (string.IsNullOrWhiteSpace(ayudaArrastre)) return;
        int alto = (int)(28 * escala);
        var banda = new Rectangle(2, Math.Max(estructura.ColumnHeadersHeight, estructura.ClientSize.Height - alto - 18), Math.Max(1, estructura.ClientSize.Width - 22), alto);
        using var fondo = new SolidBrush(MYG2027_TemaComercial.AzulSuave); e.Graphics.FillRectangle(fondo, banda);
        TextRenderer.DrawText(e.Graphics, ayudaArrastre, estructura.Font, banda, filaDestinoArrastre >= 0 ? MYG2027_TemaComercial.Texto : MYG2027_TemaComercial.ColorTitulo(0),
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
    }
}
