using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;

namespace MYG_2027;

internal static class MYGHerramientasSistemaPresupuesto
{
    internal static void AbrirLupa() => Abrir("Magnify.exe", "la Lupa de Windows");
    internal static void AbrirCalculadora() => Abrir("calc.exe", "la Calculadora de Windows");

    internal static ProcessStartInfo CrearInicio(string nombre)
    {
        if (!string.Equals(nombre, "Magnify.exe", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(nombre, "calc.exe", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("La herramienta debe ser la Lupa o la Calculadora de Windows.", nameof(nombre));
        if (!OperatingSystem.IsWindows() || string.IsNullOrWhiteSpace(Environment.SystemDirectory))
            throw new PlatformNotSupportedException("La Lupa y la Calculadora del sistema requieren Windows.");
        return new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, nombre))
        { UseShellExecute = true };
    }

    private static void Abrir(string nombre, string descripcion)
    {
        var inicio = CrearInicio(nombre);
        try
        {
            using var proceso = Process.Start(inicio);
            // ShellExecute también puede activar una instancia existente y
            // devolver null sin que la apertura haya fallado.
        }
        catch (Win32Exception ex)
        {
            throw new InvalidOperationException("No se pudo abrir " + descripcion +
                ". Compruebe que está disponible y permitida en este equipo. " + ex.Message, ex);
        }
        catch (FileNotFoundException ex)
        {
            throw new InvalidOperationException("No se encontró " + descripcion + " en este equipo.", ex);
        }
    }
}
