using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGGraficoIncidencia
{
    // La preferencia de lectura pertenece a la pantalla; no modifica las
    // fuentes de la plantilla, los importes ni el tamaño de las exportaciones.
    private float EscalaTextoPantalla => MYGTamanoTextoUI.Porcentaje / 100F;
    private int MedidaHerramienta(int valor) => Math.Max(1, (int)Math.Round(valor * DeviceDpi / 96d * EscalaTextoPantalla));

    private sealed record MedidaControlGaleria(Control Control, Rectangle Limites, Padding Margen, Padding Relleno, Image Imagen);
    private sealed record MedidasGaleria(Panel Panel, ToolStripControlHost Host, Size Tamano, Size Desplazamiento, Padding Relleno,
        MedidaControlGaleria[] Controles);
    private readonly List<MedidasGaleria> medidasGalerias = new();
    private readonly Dictionary<(Image Original, int Ancho, int Alto), Image> miniaturasEscaladas = new();
    private (int Dpi, int Porcentaje) escalaGaleriasAplicada;
    private sealed record FuenteBaseHerramienta(string Nombre, float Tamano, FontStyle Estilo, GraphicsUnit Unidad,
        byte Caracteres, bool Vertical, int Dpi);
    private readonly ConditionalWeakTable<ToolStripItem, FuenteBaseHerramienta> fuentesBaseHerramientas = new();

    private void ActualizarEscalaTextoHerramientas() => ActualizarHerramientas();

    private void ActualizarFuentesHerramientas(ToolStripItemCollection elementos)
    {
        foreach (ToolStripItem elemento in elementos)
        {
            // El host transmite Font a su control. Cada control de la galería
            // se registra por separado para conservar sus fuentes originales.
            if (elemento is not ToolStripControlHost) ActualizarFuenteHerramienta(elemento);
            if (elemento is ToolStripDropDownItem desplegable)
                ActualizarFuentesHerramientas(desplegable.DropDownItems);
        }
    }

    private void ActualizarFuenteHerramienta(ToolStripItem elemento)
    {
        if (elemento.IsDisposed) return;
        int dpi = elemento.Owner?.DeviceDpi ?? DeviceDpi;
        var original = fuentesBaseHerramientas.GetValue(elemento, item =>
        {
            var fuente = MYGTamanoTextoUI.FuenteOriginal(item.Font);
            return new(fuente.Name, fuente.Size, fuente.Style, fuente.Unit,
                fuente.GdiCharSet, fuente.GdiVerticalFont, dpi);
        });
        // ToolStrip clona las fuentes explícitas al cambiar de monitor. Esa
        // copia ya incluye el porcentaje anterior y pierde su asociación con
        // la fuente original: se restituye siempre la base conocida del ítem.
        using var fuenteBase = new Font(original.Nombre, original.Tamano * dpi / original.Dpi, original.Estilo,
            original.Unidad, original.Caracteres, original.Vertical);
        // Fuente devuelve una referencia compartida que nunca se libera aquí.
        // Sólo fuenteBase, creada para esta medida, pertenece a este método.
        elemento.Font = MYGTamanoTextoUI.Fuente(fuenteBase);
        MYGTamanoTextoUI.Aplicar(elemento);
    }

    private void RegistrarMedidasGaleria(Panel panel, ToolStripControlHost host)
    {
        var controles = panel.Controls.Cast<Control>().Select(c => new MedidaControlGaleria(c, c.Bounds, c.Margin, c.Padding,
            c is Button boton ? boton.Image : null)).ToArray();
        medidasGalerias.Add(new(panel, host, panel.Size, panel.AutoScrollMinSize, panel.Padding, controles));
        ActualizarMedidasGalerias(forzar: true);
    }

    private void ActualizarMedidasGalerias(bool forzar = false)
    {
        var actual = (DeviceDpi, MYGTamanoTextoUI.Porcentaje);
        if (!forzar && escalaGaleriasAplicada == actual) return;
        float escala = DeviceDpi / 96F * EscalaTextoPantalla;
        int S(int valor) => (int)Math.Round(valor * escala);
        Padding P(Padding margen) => new(S(margen.Left), S(margen.Top), S(margen.Right), S(margen.Bottom));
        var pantalla = Screen.FromControl(this).WorkingArea;
        foreach (var medidas in medidasGalerias)
        {
            if (medidas.Panel.IsDisposed) continue;
            var panel = medidas.Panel;
            panel.SuspendLayout();
            try
            {
                // Se vuelve siempre a las coordenadas de origen: 85 → 115 →
                // 100 no introduce redondeos acumulados ni reconstruye ventanas.
                panel.AutoScrollPosition = Point.Empty;
                panel.Size = new Size(Math.Min(S(medidas.Tamano.Width), Math.Max(100, pantalla.Width - S(40))),
                    Math.Min(S(medidas.Tamano.Height), Math.Max(100, pantalla.Height - S(90))));
                panel.Padding = P(medidas.Relleno);
                foreach (var original in medidas.Controles)
                {
                    var control = original.Control;
                    if (control.IsDisposed) continue;
                    var r = original.Limites;
                    control.Bounds = new Rectangle(S(r.X), S(r.Y), Math.Max(1, S(r.Width)), Math.Max(1, S(r.Height)));
                    control.Margin = P(original.Margen); control.Padding = P(original.Relleno);
                    MYGTamanoTextoUI.Aplicar(control);
                    if (control is Button boton && original.Imagen != null)
                        boton.Image = MiniaturaEscalada(original.Imagen, escala);
                }
                int anchoContenido = medidas.Controles.Length == 0 ? 0 : medidas.Controles.Max(c => S(c.Limites.Right)) + panel.Padding.Right;
                panel.AutoScrollMinSize = new Size(Math.Max(S(medidas.Desplazamiento.Width), anchoContenido), S(medidas.Desplazamiento.Height));
                medidas.Host.Size = panel.Size;
            }
            finally { panel.ResumeLayout(true); }
        }
        escalaGaleriasAplicada = actual;
    }

    private Image MiniaturaEscalada(Image original, float escala)
    {
        int ancho = Math.Max(1, (int)Math.Round(original.Width * escala));
        int alto = Math.Max(1, (int)Math.Round(original.Height * escala));
        if (ancho == original.Width && alto == original.Height) return original;
        var clave = (original, ancho, alto);
        if (miniaturasEscaladas.TryGetValue(clave, out var existente)) return existente;
        var imagen = new Bitmap(ancho, alto);
        try
        {
            using var grafico = Graphics.FromImage(imagen);
            grafico.InterpolationMode = InterpolationMode.HighQualityBicubic;
            grafico.PixelOffsetMode = PixelOffsetMode.HighQuality;
            grafico.DrawImage(original, new Rectangle(0, 0, ancho, alto));
        }
        catch { imagen.Dispose(); throw; }
        miniaturasEscaladas.Add(clave, imagen); imagenesHerramientas.Add(imagen);
        return imagen;
    }
}
