using System;

namespace MYG_2027;

// La rueda expresa una proporción; el reloj determina la transición, no los FPS.
internal sealed class MYGEspecificacionesZoom
{
    internal const double Minimum = 25, Maximum = 300, DurationSeconds = .160;
    private const double StepFactor = 1.08;
    private double from = 100, started, progress;

    internal double Current { get; private set; } = 100;
    internal double Target { get; private set; } = 100;
    internal bool Active => Current != Target;

    internal void SetImmediate(double value)
    {
        if (!double.IsFinite(value)) throw new ArgumentOutOfRangeException(nameof(value));
        Current = Target = from = Math.Clamp(value, Minimum, Maximum);
        progress = 0;
    }

    internal void Retarget(int delta, double timeSeconds)
    {
        if (!double.IsFinite(timeSeconds)) throw new ArgumentOutOfRangeException(nameof(timeSeconds));
        if (delta == 0) return;
        // Una inversión cancela el recorrido pendiente; no sigue alejándose del cursor.
        double basis = Active && Math.Sign(delta) != Math.Sign(Target - Current) ? Current : Target;
        Target = Math.Clamp(basis * Math.Exp(Math.Log(StepFactor) * delta / 120d), Minimum, Maximum);
        from = Current; // Siempre partir de la escala que realmente llegó a dibujarse.
        started = timeSeconds;
        progress = 0;
    }

    internal double Advance(double timeSeconds)
    {
        if (!double.IsFinite(timeSeconds)) throw new ArgumentOutOfRangeException(nameof(timeSeconds));
        if (!Active) return Current;
        progress = Math.Max(progress, Math.Clamp((timeSeconds - started) / DurationSeconds, 0, 1));
        if (progress >= 1) return Current = Target;
        double remaining = 1 - progress;
        double eased = 1 - remaining * remaining * remaining;
        return Current = from + (Target - from) * eased;
    }
}
