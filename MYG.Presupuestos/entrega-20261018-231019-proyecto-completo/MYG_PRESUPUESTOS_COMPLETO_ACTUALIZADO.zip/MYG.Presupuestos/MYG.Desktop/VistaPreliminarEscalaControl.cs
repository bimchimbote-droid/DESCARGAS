using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Edita una propuesta de escala; únicamente Aceptar la aplica al informe.</summary>
internal sealed class MYGEscalaImpresionControl : UserControl
{
    private readonly RadioButton porcentaje = new() { Name = "vista_escala_porcentaje", Text = "Ajustar a:", AutoSize = true, Checked = true };
    private readonly RadioButton anchura = new() { Name = "vista_escala_anchura", Text = "Ajustar a", AutoSize = true };
    private readonly NumericUpDown valor = new() { Name = "vista_escala_valor", Minimum = 25, Maximum = 200, Value = 100, Width = 88 };
    private readonly NumericUpDown paginas = new() { Name = "vista_escala_paginas", Minimum = 1, Maximum = 10, Value = 1, Width = 88 };

    internal event EventHandler Aceptar;
    internal event EventHandler Cancelar;
    internal float Escala => (float)valor.Value / 100;
    internal int PaginasDeAncho => anchura.Checked ? (int)paginas.Value : 0;

    internal MYGEscalaImpresionControl()
    {
        Name = "vista_escala_panel";
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96, 96);
        Font = new Font("Segoe UI", 9);
        BackColor = Color.FromArgb(224, 235, 247);
        Size = new Size(410, 160);
        Padding = new Padding(16);
        var filas = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 3 };
        filas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
        filas.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
        filas.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        filas.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        filas.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        filas.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        foreach (Control c in new Control[] { porcentaje, anchura, valor, paginas }) c.Anchor = AnchorStyles.Left;
        filas.Controls.Add(porcentaje, 0, 0); filas.Controls.Add(valor, 1, 0);
        filas.Controls.Add(new Label { Text = "% tamaño normal", AutoSize = true, Anchor = AnchorStyles.Left }, 2, 0);
        filas.Controls.Add(anchura, 0, 1); filas.Controls.Add(paginas, 1, 1);
        filas.Controls.Add(new Label { Text = "página(s) de ancho", AutoSize = true, Anchor = AnchorStyles.Left }, 2, 1);
        var botones = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false };
        var cancelar = new Button { Name = "vista_escala_cancelar", Text = "Cancelar", Width = 86, Height = 28 };
        var aceptar = new Button { Name = "vista_escala_aceptar", Text = "Aceptar", Width = 86, Height = 28 };
        cancelar.Click += (_, _) => Descartar();
        aceptar.Click += (_, _) => Confirmar();
        botones.Controls.Add(cancelar); botones.Controls.Add(aceptar);
        filas.Controls.Add(botones, 0, 2); filas.SetColumnSpan(botones, 3);
        Controls.Add(filas);
        porcentaje.CheckedChanged += (_, _) => ActualizarModo();
        anchura.CheckedChanged += (_, _) => ActualizarModo();
        ActualizarModo();
    }

    internal void Cargar(float escala, int paginasDeAncho)
    {
        valor.Value = Math.Clamp((decimal)escala * 100, valor.Minimum, valor.Maximum);
        paginas.Value = Math.Clamp(paginasDeAncho, (int)paginas.Minimum, (int)paginas.Maximum);
        anchura.Checked = paginasDeAncho > 0;
        porcentaje.Checked = paginasDeAncho == 0;
        ActualizarModo();
    }

    private void ActualizarModo()
    {
        valor.Enabled = porcentaje.Checked;
        paginas.Enabled = anchura.Checked;
    }

    internal void Confirmar() => Aceptar?.Invoke(this, EventArgs.Empty);
    internal void Descartar() => Cancelar?.Invoke(this, EventArgs.Empty);

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (keyData == Keys.Escape) { Descartar(); return true; }
        if (keyData == Keys.Enter) { Confirmar(); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }
}
