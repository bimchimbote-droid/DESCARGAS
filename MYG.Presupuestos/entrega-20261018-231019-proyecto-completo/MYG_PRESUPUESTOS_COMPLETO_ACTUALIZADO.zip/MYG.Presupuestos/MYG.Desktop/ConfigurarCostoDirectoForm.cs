using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGConfigurarCostoDirectoForm : Form
{
    internal MYGConfiguracionCostoDirecto Valor { get; private set; }
    private readonly Font fuenteDialogo = new("Tahoma", 8.25F);

    internal MYGConfigurarCostoDirectoForm(MYGConfiguracionCostoDirecto configuracion)
    {
        var original = MYGProyectoStorage.Copia(configuracion ?? new MYGConfiguracionCostoDirecto());
        Text = "Configurar tipo de costo"; Name = "configurarCostoDirecto";
        StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
        Font = fuenteDialogo; AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(350, 400); BackColor = Color.FromArgb(211, 224, 239);
        var nombre = new TextBox { Name = "nombreCostoDirecto", Text = original.Nombre, MaxLength = 120,
            Bounds = new Rectangle(30, 54, 292, 22) };
        Controls.Add(new Label { Text = "Renombrar tipo costo seleccionado:", AutoSize = true, Location = new Point(30, 34) });
        Controls.Add(nombre);
        Controls.Add(new Label { Text = "Incluir I.G.V. en insumos de:", AutoSize = true, Location = new Point(30, 96) });
        var grupos = new Panel { Bounds = new Rectangle(30, 118, 292, 130), BorderStyle = BorderStyle.FixedSingle, AutoScroll = true };
        string[] nombres = { "MANO DE OBRA", "MATERIALES", "EQUIPO", "SUB CONTRATOS" };
        string[] ids = { "igvManoObra", "igvMateriales", "igvEquipo", "igvSubcontratos" };
        bool[] valores = { original.IncluirIgvManoObra, original.IncluirIgvMateriales, original.IncluirIgvEquipo, original.IncluirIgvSubcontratos };
        var casillas = new CheckBox[4];
        for (int n = 0; n < casillas.Length; n++)
        {
            casillas[n] = new CheckBox { Name = ids[n], Text = nombres[n], Checked = valores[n],
                CheckAlign = ContentAlignment.MiddleRight, Bounds = new Rectangle(24, 24 + n * 24, 224, 22) };
            grupos.Controls.Add(casillas[n]);
        }
        Controls.Add(grupos);
        var aceptar = new Button { Name = "aceptarCostoDirecto", Text = "✓ Aceptar", Bounds = new Rectangle(154, 368, 80, 25), Enabled = !string.IsNullOrWhiteSpace(nombre.Text) };
        var cerrar = new Button { Name = "cerrarCostoDirecto", Text = "✕ Cerrar", Bounds = new Rectangle(242, 368, 80, 25), DialogResult = DialogResult.Cancel };
        nombre.TextChanged += (_, _) => aceptar.Enabled = !string.IsNullOrWhiteSpace(nombre.Text);
        aceptar.Click += (_, _) =>
        {
            Valor = new MYGConfiguracionCostoDirecto { Nombre = nombre.Text.Trim(),
                IncluirIgvManoObra = casillas[0].Checked, IncluirIgvMateriales = casillas[1].Checked,
                IncluirIgvEquipo = casillas[2].Checked, IncluirIgvSubcontratos = casillas[3].Checked };
            DialogResult = DialogResult.OK;
        };
        Controls.Add(aceptar); Controls.Add(cerrar); AcceptButton = aceptar; CancelButton = cerrar;
        MYG2027_TemaComercial.Aplicar(this);
        MYG2027_TemaComercial.CambioTema += AplicarColores;
        AplicarColores(null, EventArgs.Empty);
    }

    private void AplicarColores(object sender, EventArgs e)
    {
        void Aplicar(Control control)
        {
            control.Font = fuenteDialogo;
            control.BackColor = control is TextBox ? SystemColors.Window : SystemInformation.HighContrast
                ? SystemColors.Control : Color.FromArgb(211, 224, 239);
            control.ForeColor = SystemColors.ControlText;
            foreach (Control hijo in control.Controls) Aplicar(hijo);
        }
        Aplicar(this);
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        AplicarColores(null, EventArgs.Empty);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) MYG2027_TemaComercial.CambioTema -= AplicarColores;
        base.Dispose(disposing);
        if (disposing) fuenteDialogo.Dispose();
    }
}
