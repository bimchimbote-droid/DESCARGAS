using System.Security.Cryptography;
using System.Net.Http;
using System.IO;
using System.Text;

namespace MYG.Externo;
public static partial class AccesoWindows
{
    private static string RutaToken => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG_Addin", "sesion_automatica.dat");
    public static CredencialMYG LeerAutomatico()
    {
        try
        {
            byte[] datos = ProtectedData.Unprotect(File.ReadAllBytes(RutaToken), null, DataProtectionScope.CurrentUser);
            string s = Encoding.UTF8.GetString(datos); int n = s.IndexOf('\n');
            if (n <= 0 || n >= s.Length - 1) return null;
            string usuario = s[..n].Trim(), token = s[(n + 1)..].Trim();
            return token.Length < 32 ? null : new() { Usuario = usuario, Token = token, Automatico = true, RecordarIngreso = true };
        }
        catch { return null; }
    }
    public static bool GuardarAutomatico(string usuario, string token)
    {
        if (string.IsNullOrWhiteSpace(usuario) || token == null || token.Length < 32) return false;
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(RutaToken));
            byte[] datos = ProtectedData.Protect(Encoding.UTF8.GetBytes(usuario.Trim() + "\n" + token), null, DataProtectionScope.CurrentUser);
            string temporal = RutaToken + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try { File.WriteAllBytes(temporal, datos); File.Move(temporal, RutaToken, true); }
            finally { if (File.Exists(temporal)) File.Delete(temporal); }
            return true;
        }
        catch { return false; }
    }
    public static LicenciaServicio Servicio() => new(new HttpClient { Timeout = Timeout.InfiniteTimeSpan }, ObtenerMachineId());
}
