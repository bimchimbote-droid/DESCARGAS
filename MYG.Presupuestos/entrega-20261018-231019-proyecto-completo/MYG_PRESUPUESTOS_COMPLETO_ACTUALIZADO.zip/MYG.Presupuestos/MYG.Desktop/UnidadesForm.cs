using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGUnidadesUI
{
    private sealed class Opcion
    {
        public string Simbolo { get; init; }
        public string Texto { get; init; }
    }

    internal static ComboBox Selector(IEnumerable<MYGUnidadCatalogo> unidades, string inicial, bool conservarUnidadInicial = true)
    {
        var opciones = (unidades ?? Array.Empty<MYGUnidadCatalogo>())
            .Where(x => x != null && !string.IsNullOrWhiteSpace(x.Simbolo))
            // Las partidas almacenan el símbolo. El catálogo conserva variantes
            // por tipo, pero el selector ofrece una sola opción por símbolo.
            .GroupBy(x => x.Simbolo.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => g.OrderByDescending(x => x.EsCostoUnitario).ThenBy(x => x.Tipo == "N" ? 0 : 1).First())
            .Select(x => new Opcion { Simbolo = x.Simbolo, Texto = x.SimboloVisible + " · " + x.Descripcion }).ToList();
        string simbolo = inicial?.Trim() ?? "";
        if (conservarUnidadInicial && simbolo.Length > 0 && !opciones.Any(x => string.Equals(x.Simbolo, simbolo, StringComparison.OrdinalIgnoreCase)))
        {
            // Una unidad anterior m2/m3 se ve con superíndice, pero no se cambia al aceptar una edición.
            int equivalente = opciones.FindIndex(x => MYGProyectoStorage.MismaUnidad(x.Simbolo, simbolo));
            var opcion = new Opcion { Simbolo = simbolo, Texto = equivalente >= 0
                ? opciones[equivalente].Texto : MYGCatalogoUnidades.SimboloVisible(simbolo) };
            if (equivalente >= 0) opciones[equivalente] = opcion;
            else opciones.Add(opcion);
        }
        var selector = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList,
            DisplayMember = nameof(Opcion.Texto), ValueMember = nameof(Opcion.Simbolo),
            DropDownWidth = 340, IntegralHeight = false, MaxDropDownItems = 12 };
        // Las opciones son una lista estática. Evitar DataSource impide que un nuevo
        // BindingContext al abrir el formulario restablezca la primera unidad.
        selector.Items.AddRange(opciones.Cast<object>().ToArray());
        var seleccion = opciones.FirstOrDefault(x => string.Equals(x.Simbolo, simbolo, StringComparison.OrdinalIgnoreCase))
            ?? opciones.FirstOrDefault(x => MYGProyectoStorage.MismaUnidad(x.Simbolo, simbolo))
            ?? opciones.FirstOrDefault(x => string.Equals(x.Simbolo, "und", StringComparison.OrdinalIgnoreCase))
            ?? opciones.FirstOrDefault();
        selector.SelectedItem = seleccion;
        return selector;
    }

    internal static string Valor(Control control) => control is ComboBox combo
        ? (combo.SelectedItem is Opcion opcion ? opcion.Simbolo : combo.SelectedValue as string ?? "").Trim()
        : control.Text.Trim();
}

internal sealed class MYGUnidadesForm : Form
{
    private readonly string ruta;
    private readonly Func<bool> autorizado;
    private readonly DataGridView tabla = new() { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, RowHeadersVisible = false, AutoGenerateColumns = false, MultiSelect = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect, BackgroundColor = Color.White };
    private readonly TextBox buscar = new() { Dock = DockStyle.Top, PlaceholderText = "Buscar unidad o descripción…" };
    private readonly TreeView grupos = new() { Dock = DockStyle.Left, Width = 210, HideSelection = false,
        ShowLines = false, ShowRootLines = false, BorderStyle = BorderStyle.FixedSingle };
    private readonly Label cantidad = new() { Dock = DockStyle.Bottom, Height = 30, Padding = new(8, 4, 0, 0) };
    private List<MYGUnidadCatalogo> unidades = new();

    private sealed record Grupo(string Nombre, Func<MYGUnidadCatalogo, bool> Incluye);

    internal MYGUnidadesForm(string ruta, Func<bool> autorizado)
    {
        this.ruta = ruta; this.autorizado = autorizado;
        MYGProyectoUI.Preparar(this, "Catálogo de unidades", 1000, 580);
        tabla.Columns.Add(new DataGridViewTextBoxColumn { Name = "SIMBOLO", HeaderText = "Abreviatura", Width = 130 });
        tabla.Columns.Add(new DataGridViewTextBoxColumn { Name = "DESC", HeaderText = "Descripción", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
        tabla.Columns.Add(new DataGridViewTextBoxColumn { Name = "TIPO", HeaderText = "Tipo", Width = 150 });
        TreeNode AñadirGrupo(string nombre, Func<MYGUnidadCatalogo, bool> incluye)
        {
            var nodo = new TreeNode(nombre) { Tag = new Grupo(nombre, incluye) };
            grupos.Nodes.Add(nodo); return nodo;
        }
        AñadirGrupo("Todos", _ => true);
        AñadirGrupo("Costos unitarios", u => u.EsCostoUnitario);
        AñadirGrupo("Gastos Generales", u => u.EsGastoGeneral);
        var porCosto = AñadirGrupo("Por tipo de costo", _ => true);
        foreach (var (tipo, nombre) in new[]
        {
            (MYGGrupoRecurso.ManoObra, "Mano de obra"), (MYGGrupoRecurso.Materiales, "Materiales"),
            (MYGGrupoRecurso.Equipo, "Equipo"), (MYGGrupoRecurso.Subcontratos, "Subcontratos"),
            (MYGGrupoRecurso.Subpartidas, "Subpartidas")
        })
            porCosto.Nodes.Add(new TreeNode(nombre) { Tag = new Grupo(nombre, u => u.TiposCosto.Contains(tipo)) });
        grupos.SelectedNode = grupos.Nodes[0];
        var barra = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 48, Padding = new(5), WrapContents = false, AutoScroll = true };
        void Boton(string texto, Action accion, bool modifica = false)
        {
            var b = new Button { Text = texto, AutoSize = true, Height = 34, Enabled = !modifica || autorizado?.Invoke() == true };
            b.Click += (s, e) => Intentar(accion); barra.Controls.Add(b);
        }
        Boton("Nueva unidad", () => Editar(null), true);
        Boton("Editar", () => { if (Actual != null) Editar(Actual); }, true);
        Boton("Eliminar", Eliminar, true); Boton("Actualizar lista", Cargar);
        var detalle = new Label { Dock = DockStyle.Top, Height = 52, Padding = new(8),
            Text = "Estas unidades se ofrecen al crear partidas e insumos de esta hoja. Puedes añadir las que necesites." };
        var cerrar = new Button { Text = "Cerrar", DialogResult = DialogResult.Cancel, Width = 110, Height = 34 };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, Padding = new(6), FlowDirection = FlowDirection.RightToLeft };
        var lista = new Panel { Dock = DockStyle.Fill };
        lista.Controls.Add(tabla); lista.Controls.Add(buscar); lista.Controls.Add(cantidad);
        var contenido = new Panel { Dock = DockStyle.Fill, Padding = new(6) };
        contenido.Controls.Add(lista); contenido.Controls.Add(grupos);
        pie.Controls.Add(cerrar); Controls.Add(contenido); Controls.Add(barra); Controls.Add(detalle); Controls.Add(pie);
        buscar.TextChanged += (s, e) => Filtrar();
        grupos.AfterSelect += (s, e) => Filtrar();
        tabla.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0 && Actual != null) Intentar(() => Editar(Actual)); };
        CancelButton = cerrar; Cargar();
    }

    private MYGUnidadCatalogo Actual => tabla.CurrentRow?.Tag as MYGUnidadCatalogo;
    private void Intentar(Action accion)
    { try { accion(); } catch (Exception ex) { MYGProyectoUI.Error(this, ex); } }
    private void RequerirPermiso()
    { if (autorizado?.Invoke() != true) throw new InvalidOperationException("Inicie una sesión autorizada para modificar el catálogo de unidades."); }
    private void Cargar() { unidades = MYGCatalogoUnidades.Listar(ruta); Filtrar(); }
    private void Filtrar()
    {
        string id = Actual?.Id, filtro = buscar.Text.Trim(); tabla.Rows.Clear();
        var grupo = grupos.SelectedNode?.Tag as Grupo;
        foreach (var unidad in unidades.Where(x => (grupo?.Incluye(x) ?? true) &&
            (x.Simbolo + " " + x.SimboloVisible + " " + x.Descripcion + " " + x.TipoDescripcion).Contains(filtro, StringComparison.OrdinalIgnoreCase)))
            tabla.Rows[tabla.Rows.Add(unidad.SimboloVisible, unidad.Descripcion, unidad.TipoDescripcion)].Tag = unidad;
        cantidad.Text = (grupo?.Nombre ?? "Todos") + " · " + tabla.Rows.Count +
            (tabla.Rows.Count == 1 ? " unidad" : " unidades");
        var fila = tabla.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => ((MYGUnidadCatalogo)x.Tag).Id == id);
        if (fila != null) { tabla.CurrentCell = fila.Cells[0]; fila.Selected = true; }
    }
    private void Editar(MYGUnidadCatalogo unidad)
    {
        RequerirPermiso();
        using var f = new MYGCamposProyectoForm(unidad == null ? "Nueva unidad" : "Editar unidad",
            new[] { "Unidad / símbolo", "Descripción" }, new[] { unidad?.Simbolo ?? "", unidad?.Descripcion ?? "" });
        if (f.ShowDialog(this) != DialogResult.OK) return;
        RequerirPermiso();
        var guardada = MYGCatalogoUnidades.Guardar(ruta, new MYGUnidadCatalogo
            { Id = unidad?.Id, Simbolo = f.Valores[0], Descripcion = f.Valores[1],
                Tipo = unidad?.Tipo ?? "N", EsCostoUnitario = unidad?.EsCostoUnitario ?? true,
                EsGastoGeneral = unidad?.EsGastoGeneral ?? true,
                TiposCosto = unidad?.TiposCosto.ToList() ?? Enum.GetValues<MYGGrupoRecurso>().ToList() });
        buscar.Clear(); Cargar();
        var fila = tabla.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => ((MYGUnidadCatalogo)x.Tag).Id == guardada.Id);
        if (fila != null) tabla.CurrentCell = fila.Cells[0];
    }
    private void Eliminar()
    {
        RequerirPermiso(); var unidad = Actual; if (unidad == null) return;
        if (MessageBox.Show(this, "¿Eliminar la unidad «" + unidad.Simbolo + "»?", Text,
            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        RequerirPermiso(); MYGCatalogoUnidades.Eliminar(ruta, unidad.Id); Cargar();
    }
}
