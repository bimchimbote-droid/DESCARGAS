using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGInsumosUI
{
    internal static Button Boton(string texto, string icono)
    {
        var imagen = MYGIconos.Obtener(icono);
        var b = new Button { Text = texto, Image = imagen, ImageAlign = ContentAlignment.MiddleLeft,
            TextImageRelation = TextImageRelation.ImageBeforeText, AutoSize = true, MinimumSize = new(110, 36),
            BackColor = MYG2027_TemaComercial.AzulSuave, FlatStyle = FlatStyle.Flat, Padding = new(4, 0, 4, 0) };
        MYG2027_TemaComercial.EstilizarBoton(b, 2);
        b.Disposed += (s, e) => imagen.Dispose(); return b;
    }
    internal static void Preparar(Form f, string titulo)
    {
        f.Text = "MYG | " + titulo; f.StartPosition = FormStartPosition.CenterParent;
        f.ClientSize = new(1060, 670); f.MinimumSize = new(780, 560); f.Font = new("Segoe UI", 10);
        f.AutoScaleMode = AutoScaleMode.Dpi; f.BackColor = MYG2027_TemaComercial.Fondo;
        f.ForeColor = MYG2027_TemaComercial.Texto; f.Shown += (s, e) => MYG2027_TemaComercial.AjustarAlAreaDeTrabajo(f);
    }
    internal static FlowLayoutPanel Pie(Form f, Action aceptar)
    {
        var ok = Boton("Aceptar", "aceptar"); MYG2027_TemaComercial.EstilizarBoton(ok, 1);
        var cerrar = Boton("Cancelar", "cerrar"); MYG2027_TemaComercial.EstilizarBoton(cerrar); cerrar.DialogResult = DialogResult.Cancel;
        ok.Click += (s, e) => { try { aceptar(); } catch (Exception ex) { MessageBox.Show(f, ex.Message, f.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); } };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 56, Padding = new(8), FlowDirection = FlowDirection.RightToLeft, BackColor = Color.White };
        pie.Controls.Add(cerrar); pie.Controls.Add(ok); f.AcceptButton = ok; f.CancelButton = cerrar; return pie;
    }
}

internal sealed class MYGInsumoCampos : UserControl
{
    private sealed record OpcionTipo(MYGGrupoRecurso Valor, string Texto)
    {
        public override string ToString() => Texto;
    }

    private sealed record OpcionIndice(string Valor, string Texto)
    {
        public override string ToString() => Texto;
    }

    private readonly MYGInsumo original;
    private readonly TextBox codigo, alterno, descripcion, especificaciones, imagen, ficha;
    private readonly ComboBox grupoGenerico, proveedor, marca;
    private readonly CheckBox usarAlterno, habilitado;
    private readonly ComboBox unidad, tipo;
    private readonly NumericUpDown precio, igv;
    private readonly DateTimePicker compra;

    internal MYGInsumoCampos(MYGInsumo valor, IEnumerable<MYGUnidadCatalogo> unidades, bool conservarUnidadInicial = true,
        IEnumerable<MYGInsumo> opciones = null, string rutaCatalogos = null)
    {
        original = MYGProyectoStorage.Copia(valor); Dock = DockStyle.Fill; AutoScroll = true;
        BackColor = MYG2027_TemaComercial.Fondo; ForeColor = MYG2027_TemaComercial.Texto;
        var contenido = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 1,
            Padding = new(16), BackColor = MYG2027_TemaComercial.Fondo };
        contenido.ColumnStyles.Add(new(SizeType.Percent, 100));
        int bloque = 0;
        void Agregar(Control control)
        {
            contenido.RowStyles.Add(new(SizeType.AutoSize)); contenido.Controls.Add(control, 0, bloque++);
        }
        Label Ayuda(string texto) => new() { Text = texto, AutoSize = true, Dock = DockStyle.Fill,
            Padding = new(0, 3, 0, 9), ForeColor = MYG2027_TemaComercial.Secundario, MaximumSize = new(0, 0) };
        Agregar(new Label { Text = "Datos del insumo", AutoSize = true, Dock = DockStyle.Fill,
            Font = new("Segoe UI", 15, FontStyle.Bold), ForeColor = MYG2027_TemaComercial.Marino, Padding = new(0, 0, 0, 2) });
        Agregar(Ayuda("Complete la descripción, el índice unificado, la unidad y el precio. Los datos adicionales son opcionales."));

        TableLayoutPanel Seccion(string titulo)
        {
            var seccion = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 4,
                Padding = new(12), Margin = new(0, 0, 0, 12), BackColor = Color.White,
                GrowStyle = TableLayoutPanelGrowStyle.AddRows };
            seccion.ColumnStyles.Add(new(SizeType.Absolute, 130)); seccion.ColumnStyles.Add(new(SizeType.Percent, 54));
            seccion.ColumnStyles.Add(new(SizeType.Absolute, 125)); seccion.ColumnStyles.Add(new(SizeType.Percent, 46));
            seccion.Controls.Add(new Label { Text = titulo, AutoSize = true, Dock = DockStyle.Fill, Padding = new(0, 0, 0, 8),
                ForeColor = MYG2027_TemaComercial.Azul, Font = new("Segoe UI", 10, FontStyle.Bold) }, 0, 0);
            seccion.SetColumnSpan(seccion.Controls[0], 4); seccion.RowStyles.Add(new(SizeType.AutoSize));
            return seccion;
        }
        TextBox Texto(string texto, bool lectura = false) => new() { Text = texto ?? "", Dock = DockStyle.Fill,
            ReadOnly = lectura, MaxLength = 4000, BackColor = lectura ? MYG2027_TemaComercial.Fondo : Color.White };
        ComboBox Lista(string texto, Func<MYGInsumo, string> elegir)
        {
            var combo = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDown,
                AutoCompleteMode = AutoCompleteMode.SuggestAppend, AutoCompleteSource = AutoCompleteSource.ListItems };
            combo.Items.AddRange((opciones ?? Array.Empty<MYGInsumo>()).Select(elegir).Append(texto)
                .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).Cast<object>().ToArray());
            combo.Text = texto ?? ""; return combo;
        }
        void Campo(TableLayoutPanel seccion, string nombre, Control control, string otro = null, Control segundo = null, int alto = 42)
        {
            int fila = seccion.RowStyles.Count; seccion.RowStyles.Add(new(SizeType.Absolute, alto));
            var etiqueta = new Label { Text = nombre, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            seccion.Controls.Add(etiqueta, 0, fila); control.AccessibleName = nombre.TrimEnd(':'); seccion.Controls.Add(control, 1, fila);
            if (segundo == null) seccion.SetColumnSpan(control, 3);
            else
            {
                seccion.Controls.Add(new Label { Text = otro, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 2, fila);
                segundo.AccessibleName = string.IsNullOrWhiteSpace(otro) ? segundo.Text : otro.TrimEnd(':'); seccion.Controls.Add(segundo, 3, fila);
            }
        }
        Control Ruta(TextBox texto, string icono, string filtro)
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Margin = new(0) };
            panel.ColumnStyles.Add(new(SizeType.Percent, 100)); panel.ColumnStyles.Add(new(SizeType.Absolute, 38));
            var boton = MYGInsumosUI.Boton("", icono); boton.MinimumSize = Size.Empty; boton.Dock = DockStyle.Fill; boton.AutoSize = false;
            boton.AccessibleName = "Seleccionar archivo";
            boton.Click += (s, e) => { using var d = new OpenFileDialog { Filter = filtro, CheckFileExists = true }; if (d.ShowDialog(this) == DialogResult.OK) texto.Text = d.FileName; };
            panel.Controls.Add(texto, 0, 0); panel.Controls.Add(boton, 1, 0); return panel;
        }

        var principal = Seccion("Identificación y costo");
        descripcion = Texto(valor.Descripcion); descripcion.Font = new("Segoe UI", 11, FontStyle.Bold);
        descripcion.PlaceholderText = "Describa el material, la mano de obra o el equipo"; Campo(principal, "Descripción:", descripcion, alto: 46);
        codigo = Texto(valor.Codigo); alterno = Texto(valor.CodigoAlterno);
        usarAlterno = new() { Text = "", Checked = valor.UsarCodigoAlterno, Dock = DockStyle.Fill, AccessibleName = "Usar código alterno" };
        var panelAlterno = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Margin = new(0) };
        panelAlterno.ColumnStyles.Add(new(SizeType.Absolute, 26)); panelAlterno.ColumnStyles.Add(new(SizeType.Percent, 100));
        panelAlterno.Controls.Add(usarAlterno, 0, 0); panelAlterno.Controls.Add(alterno, 1, 0);
        alterno.Enabled = usarAlterno.Checked; usarAlterno.CheckedChanged += (s, e) => alterno.Enabled = usarAlterno.Checked;
        Campo(principal, "Código estándar:", codigo, "Código alterno:", panelAlterno);

        var indices = MYGCatalogoIndicesUnificados.Listar(rutaCatalogos);
        var opcionesIndice = new List<OpcionIndice> { new("", "Sin índice asignado") };
        opcionesIndice.AddRange(indices.Select(x => new OpcionIndice(x.ToString(), x.ToString())));
        var inicial = opcionesIndice.FirstOrDefault(x => string.Equals(x.Valor, valor.GrupoGenerico, StringComparison.Ordinal));
        if (inicial == null)
        {
            // Una clasificación anterior se conserva literalmente. Sólo elegir otro índice la sustituye.
            inicial = new(valor.GrupoGenerico, string.IsNullOrWhiteSpace(valor.GrupoGenerico)
                ? "Sin índice asignado" : valor.GrupoGenerico + " (clasificación existente)");
            opcionesIndice.Insert(1, inicial);
        }
        // Sin DataSource: mostrar el formulario o renovar su BindingContext no
        // debe sustituir el índice guardado o elegido por "Sin índice asignado".
        grupoGenerico = new() { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList,
            DropDownWidth = 700, IntegralHeight = false, MaxDropDownItems = 14,
            DisplayMember = nameof(OpcionIndice.Texto), ValueMember = nameof(OpcionIndice.Valor), AccessibleName = "Grupo genérico, índice unificado" };
        grupoGenerico.Items.AddRange(opcionesIndice.Cast<object>().ToArray());
        grupoGenerico.SelectedItem = inicial;
        var panelIndice = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Margin = new(0) };
        panelIndice.ColumnStyles.Add(new(SizeType.Percent, 100)); panelIndice.ColumnStyles.Add(new(SizeType.Absolute, 116));
        var buscarIndice = MYGInsumosUI.Boton("Buscar índice", "buscar"); buscarIndice.MinimumSize = Size.Empty;
        buscarIndice.Dock = DockStyle.Fill; buscarIndice.AutoSize = false; buscarIndice.AccessibleName = "Buscar índice por código o descripción";
        buscarIndice.Click += (s, e) =>
        {
            using var selector = new MYGSelectorIndiceUnificadoForm(indices, (grupoGenerico.SelectedItem as OpcionIndice)?.Valor);
            if (selector.ShowDialog(this) != DialogResult.OK) return;
            grupoGenerico.SelectedItem = opcionesIndice.First(x => string.Equals(x.Valor, selector.Seleccion.ToString(), StringComparison.Ordinal));
        };
        panelIndice.Controls.Add(grupoGenerico, 0, 0); panelIndice.Controls.Add(buscarIndice, 1, 0);
        Campo(principal, "Grupo genérico:", panelIndice, alto: 44);
        int filaAyuda = principal.RowStyles.Count; principal.RowStyles.Add(new(SizeType.AutoSize));
        var baseIndice = Ayuda("Índices unificados INEI · Base diciembre 2025 = 100 · R. J. 016-2026-INEI.");
        principal.Controls.Add(baseIndice, 1, filaAyuda); principal.SetColumnSpan(baseIndice, 3);
        // Sin DataSource: mostrar el formulario o renovar su BindingContext no
        // debe seleccionar de nuevo el primer tipo (Mano de obra).
        tipo = new() { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList,
            DisplayMember = nameof(OpcionTipo.Texto), AccessibleName = "Tipo de insumo" };
        var tipos = Enum.GetValues<MYGGrupoRecurso>().Where(x => x != MYGGrupoRecurso.Subpartidas)
            .Select(x => new OpcionTipo(x, MYGMotorPresupuestos.Grupo(x))).ToArray();
        tipo.Items.AddRange(tipos);
        tipo.SelectedItem = tipos.FirstOrDefault(x => x.Valor == valor.Grupo);
        habilitado = new() { Text = "Insumo habilitado", Checked = valor.Habilitado, Dock = DockStyle.Fill };
        Campo(principal, "Tipo de insumo:", tipo, "", habilitado);
        unidad = MYGUnidadesUI.Selector(unidades, valor.Unidad, conservarUnidadInicial);
        precio = new() { Dock = DockStyle.Fill, DecimalPlaces = 6, Maximum = Math.Max(1000000000000m, valor.Precio),
            Value = Math.Max(0, valor.Precio), ThousandsSeparator = true, Font = new("Segoe UI", 10, FontStyle.Bold) };
        Campo(principal, "Unidad:", unidad, "Precio unitario:", precio, alto: 46); Agregar(principal);

        var mostrarDetalles = new CheckBox { Text = "▸ Mostrar información adicional", Appearance = Appearance.Button,
            AutoSize = false, Height = 38, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft,
            FlatStyle = FlatStyle.Flat, Padding = new(10, 0, 0, 0), Margin = new(0, 0, 0, 10),
            BackColor = Color.White, ForeColor = MYG2027_TemaComercial.Azul, AccessibleName = "Mostrar información adicional" };
        mostrarDetalles.FlatAppearance.BorderColor = MYG2027_TemaComercial.Borde; Agregar(mostrarDetalles);
        var detalles = Seccion("Proveedor y documentación"); detalles.Visible = false;
        proveedor = Lista(valor.Proveedor, x => x.Proveedor); Campo(detalles, "Proveedor:", proveedor);
        marca = Lista(valor.Marca, x => x.Marca); imagen = Texto(valor.ImagenRuta);
        var panelMarca = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, Margin = new(0) };
        panelMarca.ColumnStyles.Add(new(SizeType.Percent, 100));
        for (int n = 0; n < 3; n++) panelMarca.ColumnStyles.Add(new(SizeType.Absolute, 30));
        panelMarca.Controls.Add(marca, 0, 0);
        void MarcaBoton(string texto, string ayuda, int columna, Action accion)
        {
            var b = new Button { Text = texto, Dock = DockStyle.Fill, Margin = new(0), AccessibleName = ayuda };
            MYG2027_TemaComercial.EstilizarBoton(b); b.Click += (s, e) => accion(); panelMarca.Controls.Add(b, columna, 0);
        }
        void EditarMarca(bool nueva)
        {
            using var f = new MYGCamposProyectoForm(nueva ? "Añadir marca" : "Editar marca", new[] { "Marca" }, new[] { nueva ? "" : marca.Text });
            if (f.ShowDialog(this) != DialogResult.OK || string.IsNullOrWhiteSpace(f.Valores[0])) return;
            string texto = f.Valores[0].Trim(); if (!marca.Items.Contains(texto)) marca.Items.Add(texto); marca.Text = texto;
        }
        MarcaBoton("+", "Añadir marca", 1, () => EditarMarca(true)); MarcaBoton("×", "Quitar marca", 2, () => marca.Text = "");
        MarcaBoton("✎", "Editar marca", 3, () => EditarMarca(false)); Campo(detalles, "Marca:", panelMarca);
        especificaciones = Texto(valor.Especificaciones); especificaciones.Multiline = true; especificaciones.ScrollBars = ScrollBars.Vertical;
        Campo(detalles, "Especificaciones:", especificaciones, alto: 86);
        Campo(detalles, "Imagen:", Ruta(imagen, "imagen", "Imágenes|*.png;*.jpg;*.jpeg;*.bmp|Todos los archivos|*.*"));
        igv = new() { Dock = DockStyle.Fill, DecimalPlaces = 2, Maximum = 100, Value = Math.Clamp(valor.IGVPorcentaje, 0, 100) };
        compra = new() { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Short, ShowCheckBox = true, Checked = valor.FechaCompra.HasValue };
        if (valor.FechaCompra >= compra.MinDate && valor.FechaCompra <= compra.MaxDate) compra.Value = valor.FechaCompra.Value;
        Campo(detalles, "IGV informativo %:", igv, "Fecha de compra:", compra);
        ficha = Texto(valor.FichaTecnicaRuta); Campo(detalles, "Ficha técnica:", Ruta(ficha, "buscar", "Ficha técnica|*.pdf;*.doc;*.docx;*.txt|Todos los archivos|*.*"));
        Agregar(detalles);
        var referencia = Seccion("Referencia inicial · sólo lectura"); referencia.Visible = false;
        Campo(referencia, "Descripción base:", Texto(string.IsNullOrWhiteSpace(valor.DescripcionBase) ? "No registrada" : valor.DescripcionBase, true));
        Campo(referencia, "Unidad base:", Texto(string.IsNullOrWhiteSpace(valor.UnidadBase) ? "No registrada" : MYGCatalogoUnidades.SimboloVisible(valor.UnidadBase), true),
            "Precio base:", Texto(valor.PrecioBase?.ToString("N2") ?? "No registrado", true));
        Campo(referencia, "Fecha base:", Texto(valor.FechaBase?.ToString("dd MMM yyyy") ?? "No registrada", true)); Agregar(referencia);
        mostrarDetalles.CheckedChanged += (s, e) =>
        {
            detalles.Visible = referencia.Visible = mostrarDetalles.Checked;
            mostrarDetalles.Text = mostrarDetalles.Checked ? "▾ Ocultar información adicional" : "▸ Mostrar información adicional";
            mostrarDetalles.AccessibleName = mostrarDetalles.Text[2..];
        };
        contenido.RowCount = bloque; Controls.Add(contenido);
    }

    internal MYGInsumo Leer()
    {
        var valor = MYGProyectoStorage.Copia(original);
        valor.Codigo = codigo.Text.Trim(); valor.CodigoAlterno = alterno.Text.Trim(); valor.UsarCodigoAlterno = usarAlterno.Checked;
        valor.GrupoGenerico = grupoGenerico.SelectedItem is OpcionIndice indice ? indice.Valor : original.GrupoGenerico;
        valor.Proveedor = proveedor.Text.Trim(); valor.Descripcion = descripcion.Text.Trim();
        valor.Unidad = MYGUnidadesUI.Valor(unidad);
        valor.Grupo = tipo.SelectedItem is OpcionTipo elegido ? elegido.Valor
            : throw new InvalidOperationException("Seleccione el tipo de insumo.");
        valor.Precio = precio.Value;
        valor.Marca = marca.Text.Trim(); valor.Especificaciones = especificaciones.Text; valor.ImagenRuta = imagen.Text.Trim();
        valor.FichaTecnicaRuta = ficha.Text.Trim(); valor.IGVPorcentaje = igv.Value;
        valor.FechaCompra = compra.Checked ? compra.Value.Date : null; valor.Habilitado = habilitado.Checked;
        // Fijar la referencia al crear; las referencias de un insumo existente se conservan,
        // incluso si proceden de un archivo anterior que todavía no tenía estos metadatos.
        if (string.IsNullOrWhiteSpace(original.Descripcion))
        {
            if (string.IsNullOrWhiteSpace(valor.DescripcionBase)) valor.DescripcionBase = valor.Descripcion;
            valor.PrecioBase ??= valor.Precio;
            if (string.IsNullOrWhiteSpace(valor.UnidadBase)) valor.UnidadBase = valor.Unidad;
        }
        if (valor.UsarCodigoAlterno && valor.CodigoAlterno.Length == 0) throw new InvalidOperationException("Indique el código alterno o desactive su casilla.");
        MYGInsumosEdicion.ValidarInsumo(valor); return valor;
    }
}

internal sealed class MYGInsumoForm : Form
{
    internal MYGInsumo Valor { get; private set; }
    internal MYGInsumoForm(MYGInsumo valor, IEnumerable<MYGUnidadCatalogo> unidades, bool conservarUnidadInicial = true, string rutaCatalogos = null)
    {
        MYGInsumosUI.Preparar(this, "Editar insumo");
        var campos = new MYGInsumoCampos(valor, unidades, conservarUnidadInicial, rutaCatalogos: rutaCatalogos);
        Controls.Add(campos); Controls.Add(MYGInsumosUI.Pie(this, () => { Valor = campos.Leer(); DialogResult = DialogResult.OK; }));
    }
}

internal sealed class MYGSelectorInsumoForm : Form
{
    internal MYGSeleccionInsumo Seleccion { get; private set; }
    internal IReadOnlyList<MYGSeleccionInsumo> Selecciones { get; private set; } = Array.Empty<MYGSeleccionInsumo>();
    private readonly TabControl tabs = new() { Dock = DockStyle.Fill };
    private readonly MYGInsumoCampos campos;
    private readonly DataGridView insumos = Tabla(), subpartidas = Tabla();
    private readonly TextBox filtro = new() { Name = "txtFiltroInsumos", Dock = DockStyle.Top, Height = 30, PlaceholderText = "Buscar código, descripción, unidad o tipo…" };
    private readonly TextBox filtroSub = new() { Name = "txtFiltroSubpartidas", Dock = DockStyle.Top, Height = 30, PlaceholderText = "Buscar subpartida…" };
    private readonly ComboBox origen = new() { Name = "cboOrigenInsumos", DropDownStyle = ComboBoxStyle.DropDownList, Width = 230 };
    private readonly Label cantidadInsumos = new() { Name = "lblInsumosSeleccionados", AutoSize = true, Padding = new(4, 8, 0, 0) };
    private readonly Label cantidadSubpartidas = new() { Name = "lblSubpartidasSeleccionadas", AutoSize = true, Padding = new(4, 8, 0, 0) };
    private readonly HashSet<string> insumosMarcados = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> subpartidasMarcadas = new(StringComparer.OrdinalIgnoreCase);
    private bool actualizandoTablas;
    private bool casillasInsumosUtilizadas, casillasSubpartidasUtilizadas;
    private readonly string rutaCatalogos;
    private readonly MYGPresupuestoDocumento presupuesto;
    private readonly ItemPresupuestoDelphin partida;
    private readonly MYGRecursoACU recurso;
    private List<MYGEntradaCatalogo> entradas;

    internal MYGSelectorInsumoForm(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, MYGRecursoACU recurso,
        IEnumerable<MYGUnidadCatalogo> unidades, string rutaCatalogos, MYGGrupoRecurso? grupoInicial = null)
    {
        this.presupuesto = presupuesto; this.partida = partida; this.recurso = recurso; this.rutaCatalogos = rutaCatalogos;
        MYGInsumosUI.Preparar(this, recurso == null ? "Agregar insumo al ACU" : "Editar y reemplazar insumo");
        insumos.Name = "selectorInsumos"; subpartidas.Name = "selectorSubpartidas";
        insumos.MultiSelect = subpartidas.MultiSelect = recurso == null;
        if (recurso == null) { PrepararCasillas(insumos); PrepararCasillas(subpartidas); }
        var original = recurso?.InsumoId == null ? null : presupuesto.Costos.Insumos.FirstOrDefault(x => x.Id == recurso.InsumoId);
        var buscar = new TabPage(recurso == null ? "Buscar insumo" : "Reemplazar por") { BackColor = Color.White };
        var editar = new TabPage(recurso == null ? "Crear nuevo insumo" : original == null ? "Crear y reemplazar" : "Editar y reemplazar") { BackColor = Color.White };
        var compuesto = new TabPage("Insumo compuesto (ACU)") { BackColor = Color.White };
        tabs.TabPages.AddRange(new[] { buscar, editar, compuesto });
        var imagenes = new ImageList { ImageSize = new(20, 20), ColorDepth = ColorDepth.Depth32Bit };
        // ImageList crea su recurso nativo al mostrar las pestañas y conserva las
        // imágenes originales hasta entonces; no deben liberarse dentro del bucle.
        var iconosPestanas = new List<Image>();
        Disposed += (s, e) =>
        {
            imagenes.Dispose();
            foreach (var icono in iconosPestanas) icono.Dispose();
        };
        foreach (string nombre in new[] { "buscar", "editar", "acu" })
        {
            var icono = MYGIconos.Obtener(nombre);
            iconosPestanas.Add(icono); imagenes.Images.Add(icono);
        }
        tabs.ImageList = imagenes; for (int n = 0; n < 3; n++) tabs.TabPages[n].ImageIndex = n;
        foreach (var (nombre, texto, ancho) in new[] { ("TIPO", "Tipo", 125), ("PROV", "Proveedor", 125), ("COD", "Código", 100), ("ALT", "Código alterno", 110), ("DESC", "Descripción", 270), ("UND", "Unidad", 65), ("PRECIO", "Precio", 95) })
            insumos.Columns.Add(new DataGridViewTextBoxColumn { Name = nombre, HeaderText = texto, Width = ancho, ReadOnly = true });
        insumos.Columns["DESC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; insumos.Columns["DESC"].MinimumWidth = 190;
        insumos.Columns["PRECIO"].DefaultCellStyle.Format = "N2";
        origen.Items.Add("Insumos del presupuesto"); if (!string.IsNullOrWhiteSpace(rutaCatalogos)) origen.Items.Add("Catálogo de insumos"); origen.SelectedIndex = 0;
        var barra = new FlowLayoutPanel { Dock = DockStyle.Top, Height = recurso == null ? 46 : 38, Padding = new(3) }; barra.Controls.Add(origen);
        if (recurso == null) AgregarControlesSeleccion(barra, insumos, cantidadInsumos, "Insumos");
        buscar.Controls.Add(insumos); buscar.Controls.Add(filtro); buscar.Controls.Add(barra);
        var nuevo = original == null ? new MYGInsumo { Grupo = grupoInicial is null or MYGGrupoRecurso.Subpartidas ? MYGGrupoRecurso.Materiales : grupoInicial.Value } : MYGProyectoStorage.Copia(original);
        if (original == null) MYGParametrosUsuario.Leer().Aplicar(nuevo);
        campos = new(nuevo, unidades, conservarUnidadInicial: true, opciones: presupuesto.Costos.Insumos, rutaCatalogos: rutaCatalogos); editar.Controls.Add(campos);
        var aviso = new Label { Dock = DockStyle.Bottom, Height = 52, Padding = new(10), ForeColor = Color.FromArgb(110, 68, 10), BackColor = Color.FromArgb(255, 250, 224),
            Text = original == null ? string.IsNullOrWhiteSpace(rutaCatalogos)
                ? "Se creará un insumo para este presupuesto."
                : "Se agregará automáticamente al catálogo de insumos con el tipo elegido al aceptar. El título donde lo crea determina el tipo inicial."
                :
            "Las modificaciones se aplicarán a todas las apariciones de este insumo en los ACU de este presupuesto." };
        editar.Controls.Add(aviso);
        foreach (var (nombre, texto, ancho) in new[] { ("ITEM", "Ítem", 110), ("DESC", "Descripción", 400), ("UND", "Unidad", 90), ("PRECIO", "Precio ACU", 120) })
            subpartidas.Columns.Add(new DataGridViewTextBoxColumn { Name = nombre, HeaderText = texto, Width = ancho, ReadOnly = true });
        subpartidas.Columns["DESC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; subpartidas.Columns["PRECIO"].DefaultCellStyle.Format = "N2";
        compuesto.Controls.Add(subpartidas); compuesto.Controls.Add(filtroSub);
        if (recurso == null)
        {
            var barraSub = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 46, Padding = new(3) };
            AgregarControlesSeleccion(barraSub, subpartidas, cantidadSubpartidas, "Subpartidas"); compuesto.Controls.Add(barraSub);
        }
        compuesto.Controls.Add(new Label { Dock = DockStyle.Bottom, Height = 42, Padding = new(8), Text = "El precio usa el ACU de la subpartida. No se permiten referencias circulares." });
        Controls.Add(tabs); Controls.Add(MYGInsumosUI.Pie(this, Aceptar));
        Controls.Add(new Label { Dock = DockStyle.Bottom, Height = recurso == null ? 72 : 52, Padding = new(8), BackColor = MYGPanelPresupuesto.AzulClaro,
            Text = recurso == null
                ? "Marque las casillas para agregar varios insumos. Las marcas se conservan al filtrar y Aceptar incluye las ocultas. También puede seleccionar filas con Ctrl o Shift. Al cambiar el origen se limpia la selección."
                : "Conserva cantidad, cuadrilla y desperdicio. De rendimiento a consumo conserva el coeficiente calculado. Para cambiar entre consumo y % mano de obra, agregue un recurso." });
        filtro.TextChanged += (s, e) => Filtrar(); filtroSub.TextChanged += (s, e) => FiltrarSub();
        origen.SelectedIndexChanged += (s, e) => { insumos.EndEdit(); insumosMarcados.Clear(); casillasInsumosUtilizadas = false; try { if (origen.SelectedIndex == 1 && entradas == null) entradas = MYGCatalogos.Listar(rutaCatalogos, false); Filtrar(); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, Text); origen.SelectedIndex = 0; } };
        insumos.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && insumos.Columns[e.ColumnIndex].Name != "SEL") IntentarAceptar(); };
        subpartidas.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && subpartidas.Columns[e.ColumnIndex].Name != "SEL") IntentarAceptar(); };
        if (origen.Items.Count > 1) origen.SelectedIndex = 1; else Filtrar();
        FiltrarSub(); tabs.SelectedIndex = recurso == null ? 0 : recurso.Grupo == MYGGrupoRecurso.Subpartidas ? 2 : 1;
    }
    internal void MostrarCompuesto() => tabs.SelectedIndex = 2;
    private static DataGridView Tabla() => new() { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
        BackgroundColor = Color.White, BorderStyle = BorderStyle.FixedSingle, EnableHeadersVisualStyles = false,
        ColumnHeadersDefaultCellStyle = new() { BackColor = MYGPanelPresupuesto.AzulClaro },
        DefaultCellStyle = new() { SelectionBackColor = Color.FromArgb(210, 228, 251), SelectionForeColor = Color.Black }, GridColor = Color.FromArgb(194, 208, 225) };
    private void Filtrar()
    {
        insumos.EndEdit(); actualizandoTablas = true;
        try
        {
            insumos.Rows.Clear(); string texto = filtro.Text.Trim();
            if (origen.SelectedIndex == 0)
            {
                foreach (var i in presupuesto.Costos.Insumos.Where(x => x.Habilitado &&
                    (x.Codigo + " " + x.CodigoAlterno + " " + x.Descripcion + " " + x.Unidad + " " + MYGMotorPresupuestos.Grupo(x.Grupo)).Contains(texto, StringComparison.OrdinalIgnoreCase)))
                    AgregarFila(insumos, i, MYGMotorPresupuestos.Grupo(i.Grupo), i.Proveedor, i.Codigo, i.CodigoAlterno, i.Descripcion, i.Unidad, i.Precio);
            }
            else foreach (var e in (entradas ?? new()).Where(x => (x.Codigo + " " + x.Descripcion + " " + x.Unidad + " " + GrupoCatalogo(x.Grupo)).Contains(texto, StringComparison.OrdinalIgnoreCase)))
                AgregarFila(insumos, e, GrupoCatalogo(e.Grupo), "", e.Codigo, "", e.Descripcion, e.Unidad, e.Precio);
            if (recurso == null) insumos.ClearSelection();
        }
        finally { actualizandoTablas = false; ActualizarCantidad(insumos); }
    }
    private void FiltrarSub()
    {
        subpartidas.EndEdit(); actualizandoTablas = true;
        try
        {
            subpartidas.Rows.Clear();
            var calculo = MYGMotorPresupuestos.CrearCalculo(presupuesto);
            foreach (var i in presupuesto.Items.Where(x => x.Id != partida.Id && !MYGProyectoStorage.EsTitulo(x) &&
                (x.Item + " " + x.Descripcion + " " + x.Unidad).Contains(filtroSub.Text.Trim(), StringComparison.OrdinalIgnoreCase)))
                AgregarFila(subpartidas, i, i.Item, i.Descripcion, i.Unidad, calculo.Analizar(i).PrecioUnitario);
            if (recurso == null) subpartidas.ClearSelection();
        }
        finally { actualizandoTablas = false; ActualizarCantidad(subpartidas); }
    }
    private void IntentarAceptar() { try { Aceptar(); } catch (Exception ex) { MessageBox.Show(this, ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); } }
    private void Aceptar()
    {
        insumos.EndEdit(); subpartidas.EndEdit();
        var seleccionados = new List<MYGSeleccionInsumo>();
        if (tabs.SelectedIndex == 0)
        {
            foreach (var valor in ValoresSeleccionados(insumos))
            {
                if (valor is MYGInsumo i) seleccionados.Add(new() { InsumoId = i.Id });
                else if (valor is MYGEntradaCatalogo e)
                {
                    var copia = MYGCatalogos.LeerInsumo(rutaCatalogos, e.Id, e.Revision);
                    copia.Id = MYGProyectoStorage.NuevoId(); copia.CatalogoMYGId = e.Id; copia.CatalogoMYGRuta = Path.GetFullPath(rutaCatalogos);
                    seleccionados.Add(new() { NuevoInsumo = copia });
                }
            }
            if (seleccionados.Count == 0) throw new InvalidOperationException("Seleccione un insumo de la lista.");
        }
        else if (tabs.SelectedIndex == 1) seleccionados.Add(new() { NuevoInsumo = campos.Leer(), EditarCompartido = recurso?.InsumoId != null });
        else
        {
            foreach (var valor in ValoresSeleccionados(subpartidas))
                if (valor is ItemPresupuestoDelphin sub) seleccionados.Add(new() { SubpartidaIdLocal = sub.IdLocalMYG });
            if (seleccionados.Count == 0) throw new InvalidOperationException("Seleccione una subpartida.");
        }
        // Comprobar el mismo cambio sobre una copia antes de cerrar; así un ciclo
        // o un dato inválido mantiene abierto el diálogo con todos sus campos.
        var prueba = MYGProyectoStorage.Copia(presupuesto);
        if (recurso == null) MYGInsumosEdicion.AplicarVarios(prueba, partida.Id, seleccionados);
        else MYGInsumosEdicion.Aplicar(prueba, partida.Id, recurso.Id, seleccionados.Single());
        Selecciones = seleccionados.AsReadOnly(); Seleccion = seleccionados[0];
        DialogResult = DialogResult.OK;
    }
    private IEnumerable<DataGridViewRow> FilasSeleccionadas(DataGridView tabla) => recurso == null
        ? tabla.SelectedRows.Cast<DataGridViewRow>().OrderBy(x => x.Index)
        : tabla.CurrentRow == null ? Enumerable.Empty<DataGridViewRow>() : new[] { tabla.CurrentRow };

    private static string GrupoCatalogo(string grupo) => Enum.TryParse<MYGGrupoRecurso>(grupo, true, out var valor) && Enum.IsDefined(valor)
        ? MYGMotorPresupuestos.Grupo(valor) : grupo;

    private HashSet<string> Marcados(DataGridView tabla) => tabla == insumos ? insumosMarcados : subpartidasMarcadas;
    private bool ModoCasillas(DataGridView tabla) => tabla == insumos ? casillasInsumosUtilizadas : casillasSubpartidasUtilizadas;
    private void UsarCasillas(DataGridView tabla, bool valor)
    { if (tabla == insumos) casillasInsumosUtilizadas = valor; else casillasSubpartidasUtilizadas = valor; }
    private static string Clave(object valor) => valor switch
    {
        MYGInsumo i => i.Id,
        MYGEntradaCatalogo e => e.Id,
        ItemPresupuestoDelphin p => p.IdLocalMYG,
        _ => null
    };
    private void AgregarFila(DataGridView tabla, object valor, params object[] celdas)
    {
        if (recurso == null) celdas = new object[] { Marcados(tabla).Contains(Clave(valor)) }.Concat(celdas).ToArray();
        tabla.Rows[tabla.Rows.Add(celdas)].Tag = valor;
    }
    private void PrepararCasillas(DataGridView tabla)
    {
        tabla.ReadOnly = false;
        tabla.Columns.Add(new DataGridViewCheckBoxColumn { Name = "SEL", HeaderText = "Sel.", Width = 48,
            MinimumWidth = 48, ReadOnly = false, ThreeState = false, Frozen = true, SortMode = DataGridViewColumnSortMode.NotSortable,
            ToolTipText = "Marcar para agregar este insumo. Las marcas se conservan al filtrar." });
        tabla.CurrentCellDirtyStateChanged += (s, e) =>
        {
            if (!actualizandoTablas && tabla.IsCurrentCellDirty && tabla.CurrentCell?.OwningColumn.Name == "SEL")
                tabla.CommitEdit(DataGridViewDataErrorContexts.Commit);
        };
        tabla.CellValueChanged += (s, e) =>
        {
            if (actualizandoTablas || e.RowIndex < 0 || e.ColumnIndex < 0 || tabla.Columns[e.ColumnIndex].Name != "SEL") return;
            var fila = tabla.Rows[e.RowIndex]; string clave = Clave(fila.Tag); if (clave == null) return;
            UsarCasillas(tabla, true);
            if (fila.Cells["SEL"].Value is true) Marcados(tabla).Add(clave); else Marcados(tabla).Remove(clave);
            ActualizarCantidad(tabla);
        };
        tabla.SelectionChanged += (s, e) => { if (!actualizandoTablas) ActualizarCantidad(tabla); };
        tabla.CellMouseClick += (s, e) =>
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && tabla.Columns[e.ColumnIndex].Name != "SEL" && Marcados(tabla).Count == 0)
            { UsarCasillas(tabla, false); ActualizarCantidad(tabla); }
        };
    }
    private void AgregarControlesSeleccion(FlowLayoutPanel barra, DataGridView tabla, Label cantidad, string sufijo)
    {
        var marcar = MYGInsumosUI.Boton("Marcar visibles", "aceptar"); marcar.Name = "btnMarcar" + sufijo + "Visibles";
        var limpiar = MYGInsumosUI.Boton("Limpiar selección", "cerrar"); limpiar.Name = "btnLimpiar" + sufijo + "Seleccion";
        marcar.Click += (s, e) =>
        {
            tabla.EndEdit(); UsarCasillas(tabla, true);
            foreach (DataGridViewRow fila in tabla.Rows) fila.Cells["SEL"].Value = true;
            ActualizarCantidad(tabla);
        };
        limpiar.Click += (s, e) =>
        {
            tabla.EndEdit(); Marcados(tabla).Clear(); UsarCasillas(tabla, false); actualizandoTablas = true;
            try { foreach (DataGridViewRow fila in tabla.Rows) fila.Cells["SEL"].Value = false; tabla.ClearSelection(); }
            finally { actualizandoTablas = false; ActualizarCantidad(tabla); }
        };
        barra.Controls.Add(marcar); barra.Controls.Add(limpiar); barra.Controls.Add(cantidad);
        ActualizarCantidad(tabla);
    }
    private void ActualizarCantidad(DataGridView tabla)
    {
        int cantidad = Marcados(tabla).Count;
        if (!ModoCasillas(tabla)) cantidad = tabla.SelectedRows.Count;
        (tabla == insumos ? cantidadInsumos : cantidadSubpartidas).Text = cantidad + " seleccionados";
    }
    private IEnumerable<object> ValoresSeleccionados(DataGridView tabla)
    {
        var marcados = Marcados(tabla);
        if (recurso != null || !ModoCasillas(tabla)) return FilasSeleccionadas(tabla).Select(x => x.Tag);
        // Recorrer la fuente completa conserva el orden e incluye las marcas ocultas por el filtro.
        IEnumerable<object> fuente = tabla == subpartidas
            ? presupuesto.Items.Where(x => x.Id != partida.Id && !MYGProyectoStorage.EsTitulo(x))
            : origen.SelectedIndex == 0 ? presupuesto.Costos.Insumos.Where(x => x.Habilitado) : entradas ?? new();
        return fuente.Where(x => marcados.Contains(Clave(x)));
    }
}

internal sealed class MYGDescripcionInsumoCell : DataGridViewTextBoxCell
{
    protected override void Paint(Graphics graphics, Rectangle clipBounds, Rectangle cellBounds, int rowIndex,
        DataGridViewElementStates cellState, object value, object formattedValue, string errorText,
        DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
    {
        if (DataGridView.Rows[rowIndex].Tag is not MYGRecursoACU)
        { base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, cellStyle, advancedBorderStyle, paintParts); return; }
        int ancho = (int)Math.Round(22F * DataGridView.DeviceDpi / 96F);
        var estilo = cellStyle.Clone(); estilo.Padding = new Padding(cellStyle.Padding.Left, cellStyle.Padding.Top, ancho + 2, cellStyle.Padding.Bottom);
        base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, estilo, advancedBorderStyle, paintParts);
        var box = new Rectangle(cellBounds.Right - ancho - 1, cellBounds.Top + 1, ancho, cellBounds.Height - 2);
        using var relleno = new SolidBrush(MYGPanelPresupuesto.AzulClaro); graphics.FillRectangle(relleno, box);
        using var borde = new Pen(Color.FromArgb(175, 195, 218)); graphics.DrawRectangle(borde, box);
        int x = box.Left + box.Width / 2, y = box.Top + box.Height / 2;
        using var tinta = new SolidBrush(Color.FromArgb(36, 53, 73)); graphics.FillPolygon(tinta, new[] { new Point(x - 4, y - 2), new Point(x + 4, y - 2), new Point(x, y + 3) });
    }
}
