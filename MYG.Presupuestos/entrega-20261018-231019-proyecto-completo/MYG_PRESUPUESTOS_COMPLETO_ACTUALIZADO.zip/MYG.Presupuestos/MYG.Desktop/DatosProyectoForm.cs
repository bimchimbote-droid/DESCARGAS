using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGDatosProyectoForm : Form
{
    private sealed class Opcion
    {
        public string Id { get; init; }
        public string Nombre { get; init; }
        public bool Conservada { get; init; }
        public string Texto => !string.IsNullOrWhiteSpace(Nombre) ? Nombre
            + (Conservada ? " (actual)" : "") : string.IsNullOrWhiteSpace(Id) ? "— Sin seleccionar —" : "Selección actual";
    }

    private static Color Fondo => MYG2027_TemaComercial.Fondo;
    private readonly string ruta, proyectoId;
    private readonly MYGDatosProyecto original;
    private readonly bool edicion;
    private readonly TextBox nombre = new() { Dock = DockStyle.Fill, MaxLength = 2000 };
    private readonly Dictionary<MYGCatalogoProyecto, ComboBox> catalogos = new();
    private readonly Dictionary<MYGCatalogoProyecto, Opcion> seleccionesIniciales = new();
    private readonly List<Control> controlesUbicacion = new();
    private readonly ToolTip ayudas = new();
    private readonly CheckBox usarUbicacion = new() { Text = "Registrar ubicación", AutoSize = true, BackColor = Fondo };
    private readonly DateTimePicker elaboracion = Fecha(), inicio = Fecha();
    private readonly TextBox fin = new() { Dock = DockStyle.Fill, ReadOnly = true, TabStop = false };
    private readonly NumericUpDown duracion = new() { Dock = DockStyle.Fill, DecimalPlaces = 2, Minimum = 0, Maximum = 1000000m };
    private readonly ComboBox unidadDuracion = Lista(), periodos = Lista();
    private readonly RadioButton contrata = new() { Text = "Por contrata", Dock = DockStyle.Fill };
    private readonly RadioButton administracion = new() { Text = "Administración directa", Dock = DockStyle.Fill };
    private readonly CheckBox rendimiento = new() { Text = "Por rendimiento de cuadrilla", Dock = DockStyle.Fill };
    private readonly CheckBox asignacion = new() { Text = "Por asignación de recursos", Dock = DockStyle.Fill };
    private readonly TextBox hechoPor = new() { Dock = DockStyle.Fill, ReadOnly = true, TabStop = false };
    private bool cargando = true, ajustandoCostos, fechasModificadas;
    private string errorFin;

    internal string Nombre { get; private set; }
    internal MYGDatosProyecto Datos { get; private set; }

    internal MYGDatosProyectoForm(string ruta, string nombre, MYGDatosProyecto datos = null,
        string usuario = null, string titulo = "Nuevo proyecto", string proyectoId = null)
    {
        this.ruta = ruta; this.proyectoId = proyectoId;
        original = MYGProyectoStorage.Copia(datos ?? MYGDatosProyecto.Crear());
        edicion = datos != null;
        if (!edicion && !string.IsNullOrWhiteSpace(MYGParametrosAplicacionUI.Actual.NombreComercial))
        {
            original.Propietario = MYGParametrosAplicacionUI.Actual.NombreComercial;
            original.PropietarioId = null;
        }
        fechasModificadas = datos == null || !original.FechaFin.HasValue;
        Text = "MYG Presupuestos | " + titulo;
        ClientSize = new(700, 550); MinimumSize = new(540, 400);
        AutoScaleDimensions = new(96F, 96F); AutoScaleMode = AutoScaleMode.Dpi;
        Font = new("Segoe UI", 9F); BackColor = Fondo; ForeColor = MYG2027_TemaComercial.Texto;
        StartPosition = FormStartPosition.CenterParent; ShowInTaskbar = false;
        this.nombre.Text = nombre ?? "";

        var raiz = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2,
            Padding = new(10), BackColor = Fondo };
        raiz.ColumnStyles.Add(new(SizeType.Percent, 100));
        raiz.RowStyles.Add(new(SizeType.Percent, 100)); raiz.RowStyles.Add(new(SizeType.Absolute, 46));
        var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Fondo, Margin = new(0) };
        var contenido = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 2, RowCount = 4, BackColor = Fondo, MinimumSize = new(630, 0), Margin = new(0), Padding = new(0) };
        contenido.ColumnStyles.Add(new(SizeType.Percent, 64)); contenido.ColumnStyles.Add(new(SizeType.Percent, 36));
        contenido.RowStyles.Add(new(SizeType.Absolute, 146)); contenido.RowStyles.Add(new(SizeType.Absolute, 94));
        contenido.RowStyles.Add(new(SizeType.Absolute, 198)); contenido.RowStyles.Add(new(SizeType.Absolute, 34));
        scroll.Controls.Add(contenido); raiz.Controls.Add(scroll, 0, 0);

        var proyecto = Grupo("Datos del proyecto");
        var tablaProyecto = Tabla(4, 3, 112, 27);
        Campo(tablaProyecto, 0, "Nombre", this.nombre); tablaProyecto.SetColumnSpan(this.nombre, 2);
        CampoCatalogo(tablaProyecto, 1, "Propietario", MYGCatalogoProyecto.Propietarios);
        CampoCatalogo(tablaProyecto, 2, "Portafolio", MYGCatalogoProyecto.Portafolios);
        CampoCatalogo(tablaProyecto, 3, "Tipo de obra", MYGCatalogoProyecto.TiposObra);
        proyecto.Controls.Add(tablaProyecto); contenido.Controls.Add(proyecto, 0, 0); contenido.SetColumnSpan(proyecto, 2);

        var ubicacion = Grupo("Ubicación");
        usarUbicacion.Location = new(90, 0); usarUbicacion.Checked = original.UsarUbicacion;
        var tablaUbicacion = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 7, RowCount = 2,
            Padding = new(7, 3, 7, 3), BackColor = Fondo };
        int anchoDivision = Math.Min(156, Math.Max(112, new[] { MYGCatalogoProyecto.Departamentos,
            MYGCatalogoProyecto.Provincias, MYGCatalogoProyecto.Distritos, MYGCatalogoProyecto.Localidades }
            .Max(tipo => TextRenderer.MeasureText(MYGParametrosAplicacionUI.NombreDivision(tipo, true), Font).Width + 8)));
        contenido.MinimumSize = new(Math.Max(630, 430 + anchoDivision * 2), 0);
        tablaUbicacion.ColumnStyles.Add(new(SizeType.Absolute, anchoDivision)); tablaUbicacion.ColumnStyles.Add(new(SizeType.Percent, 50));
        tablaUbicacion.ColumnStyles.Add(new(SizeType.Absolute, 28)); tablaUbicacion.ColumnStyles.Add(new(SizeType.Absolute, 8));
        tablaUbicacion.ColumnStyles.Add(new(SizeType.Absolute, anchoDivision)); tablaUbicacion.ColumnStyles.Add(new(SizeType.Percent, 50));
        tablaUbicacion.ColumnStyles.Add(new(SizeType.Absolute, 28));
        tablaUbicacion.RowStyles.Add(new(SizeType.Percent, 50)); tablaUbicacion.RowStyles.Add(new(SizeType.Percent, 50));
        CampoUbicacion(tablaUbicacion, 0, 0, MYGCatalogoProyecto.Departamentos);
        CampoUbicacion(tablaUbicacion, 0, 4, MYGCatalogoProyecto.Provincias);
        CampoUbicacion(tablaUbicacion, 1, 0, MYGCatalogoProyecto.Distritos);
        CampoUbicacion(tablaUbicacion, 1, 4, MYGCatalogoProyecto.Localidades);
        ubicacion.Controls.Add(tablaUbicacion); ubicacion.Controls.Add(usarUbicacion); usarUbicacion.BringToFront();
        contenido.Controls.Add(ubicacion, 0, 1); contenido.SetColumnSpan(ubicacion, 2);

        var duracionGrupo = Grupo("Duración");
        var tablaDuracion = Tabla(6, 3, 92, 27);
        Campo(tablaDuracion, 0, "Elaboración", elaboracion); tablaDuracion.SetColumnSpan(elaboracion, 2);
        var plazo = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new(0) };
        plazo.ColumnStyles.Add(new(SizeType.Percent, 52)); plazo.ColumnStyles.Add(new(SizeType.Percent, 48));
        plazo.Controls.Add(duracion, 0, 0); plazo.Controls.Add(unidadDuracion, 1, 0);
        Campo(tablaDuracion, 1, "Duración", plazo); tablaDuracion.SetColumnSpan(plazo, 2);
        Campo(tablaDuracion, 2, "Inicio", inicio); tablaDuracion.SetColumnSpan(inicio, 2);
        Campo(tablaDuracion, 3, "Fin", fin); tablaDuracion.SetColumnSpan(fin, 2);
        CampoCatalogo(tablaDuracion, 4, "Calendario", MYGCatalogoProyecto.Calendarios);
        Campo(tablaDuracion, 5, "Periodos", periodos); tablaDuracion.SetColumnSpan(periodos, 2);
        duracionGrupo.Controls.Add(tablaDuracion); contenido.Controls.Add(duracionGrupo, 0, 2);

        var lateral = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Margin = new(0), Padding = new(0) };
        lateral.ColumnStyles.Add(new(SizeType.Percent, 100));
        lateral.RowStyles.Add(new(SizeType.Percent, 50)); lateral.RowStyles.Add(new(SizeType.Percent, 50));
        var modalidad = Grupo("Modalidad de ejecución");
        modalidad.Controls.Add(Opciones(contrata, administracion)); lateral.Controls.Add(modalidad, 0, 0);
        var calculo = Grupo("Cálculo de costos");
        calculo.Controls.Add(Opciones(rendimiento, asignacion)); lateral.Controls.Add(calculo, 0, 1);
        contenido.Controls.Add(lateral, 1, 2);

        var autor = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new(8, 5, 8, 0), Margin = new(0) };
        autor.ColumnStyles.Add(new(SizeType.Absolute, 104)); autor.ColumnStyles.Add(new(SizeType.Percent, 100));
        autor.Controls.Add(Etiqueta("Hecho por"), 0, 0); autor.Controls.Add(hechoPor, 1, 0);
        contenido.Controls.Add(autor, 0, 3); contenido.SetColumnSpan(autor, 2);

        var aceptar = new Button { Text = "Aceptar", Width = 108, Height = 32, BackColor = Color.FromArgb(44, 109, 174), ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Margin = new(6, 6, 0, 0) };
        aceptar.FlatAppearance.BorderColor = aceptar.BackColor;
        MYG2027_TemaComercial.EstilizarBoton(aceptar, 1);
        var cancelar = new Button { Text = "Cancelar", Width = 108, Height = 32, DialogResult = DialogResult.Cancel, Margin = new(6, 6, 0, 0) };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Margin = new(0) };
        pie.Controls.Add(cancelar); pie.Controls.Add(aceptar); raiz.Controls.Add(pie, 0, 1); Controls.Add(raiz);
        AcceptButton = aceptar; CancelButton = cancelar;
        aceptar.Click += (s, e) => Aceptar();

        CargarCatalogosIniciales();
        foreach (var tipo in catalogos.Keys) seleccionesIniciales.Add(tipo, Actual(tipo));
        AsignarFecha(elaboracion, original.FechaElaboracion);
        AsignarFecha(inicio, original.FechaInicio);
        duracion.Maximum = Math.Max(duracion.Maximum, original.Duracion);
        duracion.Value = Math.Max(duracion.Minimum, original.Duracion);
        unidadDuracion.Items.AddRange(new object[] { "DIAS", "SEMANAS", "MESES" });
        SeleccionarTexto(unidadDuracion, string.IsNullOrWhiteSpace(original.UnidadDuracion) ? "DIAS" : original.UnidadDuracion);
        periodos.Items.Add("Estándar"); SeleccionarTexto(periodos, string.IsNullOrWhiteSpace(original.Periodos) ? "Estándar" : original.Periodos);
        administracion.Checked = string.Equals(original.ModalidadEjecucion, "A", StringComparison.OrdinalIgnoreCase);
        contrata.Checked = !administracion.Checked;
        asignacion.Checked = original.PorAsignacionRecursos && !original.PorRendimientoCuadrilla;
        rendimiento.Checked = !asignacion.Checked;
        hechoPor.Text = edicion ? original.HechoPor ?? ""
            : string.IsNullOrWhiteSpace(usuario) ? original.HechoPor ?? "" : usuario.Trim();
        cargando = false; HabilitarUbicacion(); CalcularFin();

        usarUbicacion.CheckedChanged += (s, e) => HabilitarUbicacion();
        foreach (var tipo in new[] { MYGCatalogoProyecto.Departamentos, MYGCatalogoProyecto.Provincias, MYGCatalogoProyecto.Distritos })
        {
            var actual = tipo;
            catalogos[tipo].SelectedIndexChanged += (s, e) => { if (!cargando) Intentar(() => RecargarHijos(actual)); };
        }
        inicio.ValueChanged += (s, e) => MarcarCambioFechas(); duracion.ValueChanged += (s, e) => MarcarCambioFechas();
        unidadDuracion.SelectedIndexChanged += (s, e) => MarcarCambioFechas();
        rendimiento.CheckedChanged += (s, e) => CostosExclusivos(rendimiento, asignacion);
        asignacion.CheckedChanged += (s, e) => CostosExclusivos(asignacion, rendimiento);
        Shown += (s, e) => { MYG2027_TemaComercial.AjustarAlAreaDeTrabajo(this); this.nombre.Focus(); };
        Disposed += (_, _) => ayudas.Dispose();
    }

    private static ComboBox Lista() => new() { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList,
        IntegralHeight = false, MaxDropDownItems = 12 };
    private static DateTimePicker Fecha() => new() { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Custom,
        CustomFormat = "dd/MM/yyyy", ShowCheckBox = true };
    private static Label Etiqueta(string texto) => new() { Text = texto, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Margin = new(0, 0, 4, 0) };
    private static GroupBox Grupo(string texto) => new() { Text = texto, Dock = DockStyle.Fill, Padding = new(3, 8, 3, 3), Margin = new(3), BackColor = Fondo };
    private static TableLayoutPanel Tabla(int filas, int columnas, int etiqueta, int alto)
    {
        var tabla = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = columnas, RowCount = filas, Padding = new(7, 1, 7, 3), Margin = new(0) };
        tabla.ColumnStyles.Add(new(SizeType.Absolute, etiqueta)); tabla.ColumnStyles.Add(new(SizeType.Percent, 100));
        if (columnas > 2) tabla.ColumnStyles.Add(new(SizeType.Absolute, 28));
        for (int n = 0; n < filas; n++) tabla.RowStyles.Add(new(SizeType.Absolute, alto));
        return tabla;
    }
    private static TableLayoutPanel Opciones(params Control[] opciones)
    {
        var tabla = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = opciones.Length, Padding = new(7, 0, 3, 3), Margin = new(0) };
        tabla.ColumnStyles.Add(new(SizeType.Percent, 100));
        for (int n = 0; n < opciones.Length; n++)
        { tabla.RowStyles.Add(new(SizeType.Percent, 100F / opciones.Length)); tabla.Controls.Add(opciones[n], 0, n); }
        return tabla;
    }
    private static void Campo(TableLayoutPanel tabla, int fila, string texto, Control campo)
    { tabla.Controls.Add(Etiqueta(texto), 0, fila); tabla.Controls.Add(campo, 1, fila); }
    private void CampoCatalogo(TableLayoutPanel tabla, int fila, string texto, MYGCatalogoProyecto tipo)
    {
        var combo = Lista(); catalogos.Add(tipo, combo); Campo(tabla, fila, texto, combo);
        tabla.Controls.Add(BotonAgregar(tipo), 2, fila);
    }
    private void CampoUbicacion(TableLayoutPanel tabla, int fila, int columna, MYGCatalogoProyecto tipo)
    {
        var combo = Lista(); catalogos.Add(tipo, combo); var agregar = BotonAgregar(tipo);
        string denominacion = MYGParametrosAplicacionUI.NombreDivision(tipo, true);
        var etiqueta = Etiqueta(denominacion); etiqueta.AutoEllipsis = true;
        combo.AccessibleName = denominacion; ayudas.SetToolTip(etiqueta, denominacion);
        tabla.Controls.Add(etiqueta, columna, fila); tabla.Controls.Add(combo, columna + 1, fila); tabla.Controls.Add(agregar, columna + 2, fila);
        controlesUbicacion.Add(combo); controlesUbicacion.Add(agregar);
    }
    private Button BotonAgregar(MYGCatalogoProyecto tipo)
    {
        var boton = new Button { Text = "+", Dock = DockStyle.Fill, Margin = new(1, 3, 0, 3), Padding = new(0), TabStop = true,
            AccessibleName = "Añadir " + NombreCatalogo(tipo), FlatStyle = FlatStyle.System };
        boton.Click += (s, e) => Intentar(() => AgregarOpcion(tipo)); return boton;
    }
    private static string NombreCatalogo(MYGCatalogoProyecto tipo) => tipo switch
    {
        MYGCatalogoProyecto.Propietarios => "propietario", MYGCatalogoProyecto.Portafolios => "portafolio",
        MYGCatalogoProyecto.TiposObra => "tipo de obra",
        MYGCatalogoProyecto.Departamentos or MYGCatalogoProyecto.Provincias or MYGCatalogoProyecto.Distritos
            or MYGCatalogoProyecto.Localidades => MYGParametrosAplicacionUI.NombreDivision(tipo, true),
        MYGCatalogoProyecto.Calendarios => "calendario", _ => "opción"
    };
    private static Opcion Actual(ComboBox combo) => combo.SelectedItem as Opcion;
    private Opcion Actual(MYGCatalogoProyecto tipo) => Actual(catalogos[tipo]);
    private string Padre(MYGCatalogoProyecto tipo) => tipo switch
    {
        MYGCatalogoProyecto.Provincias => Actual(MYGCatalogoProyecto.Departamentos)?.Id,
        MYGCatalogoProyecto.Distritos => Actual(MYGCatalogoProyecto.Provincias)?.Id,
        MYGCatalogoProyecto.Localidades => Actual(MYGCatalogoProyecto.Distritos)?.Id, _ => null
    };
    private static bool EsDependiente(MYGCatalogoProyecto tipo) => tipo is MYGCatalogoProyecto.Provincias or MYGCatalogoProyecto.Distritos or MYGCatalogoProyecto.Localidades;
    private void Cargar(MYGCatalogoProyecto tipo, string id = null, string texto = null, bool conservarSinId = false)
    {
        string padre = tipo == MYGCatalogoProyecto.Calendarios ? proyectoId : Padre(tipo);
        var lista = !EsDependiente(tipo) || !string.IsNullOrWhiteSpace(padre)
            ? MYGCatalogosProyecto.Listar(ruta, tipo, padre) : new List<MYGOpcionProyecto>();
        var opciones = lista.Select(x => new Opcion { Id = x.Id, Nombre = x.Nombre }).ToList();
        var seleccion = !string.IsNullOrWhiteSpace(id)
            ? opciones.FirstOrDefault(x => string.Equals(x.Id, id, StringComparison.OrdinalIgnoreCase))
            : conservarSinId ? null : opciones.FirstOrDefault(x => !string.IsNullOrWhiteSpace(texto) && string.Equals(x.Nombre, texto, StringComparison.OrdinalIgnoreCase));
        if (!edicion && seleccion == null && opciones.Count > 0 && (!string.IsNullOrWhiteSpace(id) || !string.IsNullOrWhiteSpace(texto))
            && tipo is MYGCatalogoProyecto.TiposObra or MYGCatalogoProyecto.Portafolios)
            seleccion = tipo == MYGCatalogoProyecto.TiposObra
                ? opciones.FirstOrDefault(x => string.Equals(x.Nombre, "GENERAL", StringComparison.OrdinalIgnoreCase)) ?? opciones[0]
                : opciones[0];
        if (seleccion == null && (!string.IsNullOrWhiteSpace(id) || !string.IsNullOrWhiteSpace(texto)))
        {
            seleccion = new Opcion { Id = id, Nombre = texto,
                Conservada = opciones.Any(x => !string.IsNullOrWhiteSpace(texto) && string.Equals(x.Nombre, texto, StringComparison.OrdinalIgnoreCase)) };
            opciones.Add(seleccion);
        }
        opciones.Insert(0, new Opcion { Id = null, Nombre = null });
        bool anterior = cargando; cargando = true;
        try
        {
            var combo = catalogos[tipo]; combo.DisplayMember = nameof(Opcion.Texto); combo.ValueMember = nameof(Opcion.Id);
            combo.DataSource = opciones; combo.SelectedItem = seleccion ?? opciones[0];
        }
        finally { cargando = anterior; }
    }
    private void CargarCatalogosIniciales()
    {
        Cargar(MYGCatalogoProyecto.Propietarios, original.PropietarioId, original.Propietario, edicion);
        Cargar(MYGCatalogoProyecto.Portafolios, original.PortafolioId, original.Portafolio, edicion);
        Cargar(MYGCatalogoProyecto.TiposObra, original.TipoObraId, original.TipoObra, edicion);
        Cargar(MYGCatalogoProyecto.Departamentos, original.DepartamentoId, original.Departamento, edicion);
        Cargar(MYGCatalogoProyecto.Provincias, original.ProvinciaId, original.Provincia, edicion);
        Cargar(MYGCatalogoProyecto.Distritos, original.DistritoId, original.Distrito, edicion);
        Cargar(MYGCatalogoProyecto.Localidades, original.LocalidadId, original.Localidad, edicion);
        Cargar(MYGCatalogoProyecto.Calendarios, original.CalendarioId?.ToString(CultureInfo.InvariantCulture), original.Calendario, edicion);
    }
    private void RecargarHijos(MYGCatalogoProyecto tipo)
    {
        if (tipo == MYGCatalogoProyecto.Departamentos) Cargar(MYGCatalogoProyecto.Provincias);
        if (tipo is MYGCatalogoProyecto.Departamentos or MYGCatalogoProyecto.Provincias) Cargar(MYGCatalogoProyecto.Distritos);
        if (tipo is MYGCatalogoProyecto.Departamentos or MYGCatalogoProyecto.Provincias or MYGCatalogoProyecto.Distritos) Cargar(MYGCatalogoProyecto.Localidades);
    }
    private void AgregarOpcion(MYGCatalogoProyecto tipo)
    {
        string padre = Padre(tipo);
        if (EsDependiente(tipo) && string.IsNullOrWhiteSpace(padre))
        {
            var superior = tipo switch
            {
                MYGCatalogoProyecto.Provincias => MYGCatalogoProyecto.Departamentos,
                MYGCatalogoProyecto.Distritos => MYGCatalogoProyecto.Provincias,
                _ => MYGCatalogoProyecto.Distritos
            };
            throw new InvalidOperationException("Seleccione primero " + NombreCatalogo(superior) + ".");
        }
        using var formulario = new MYGCamposProyectoForm("Añadir " + NombreCatalogo(tipo), new[] { "Nombre" }, new[] { "" });
        if (formulario.ShowDialog(this) != DialogResult.OK) return;
        var guardada = MYGCatalogosProyecto.Guardar(ruta, tipo, formulario.Valores[0], padre);
        Cargar(tipo, guardada.Id, guardada.Nombre); RecargarHijos(tipo);
    }
    private void HabilitarUbicacion()
    { foreach (var control in controlesUbicacion) control.Enabled = usarUbicacion.Checked; }
    private static void AsignarFecha(DateTimePicker campo, DateTime? fecha)
    {
        if (fecha.HasValue) campo.Value = fecha.Value.Date;
        campo.Checked = fecha.HasValue;
    }
    private static DateTime? ValorFecha(DateTimePicker campo) => campo.Checked ? campo.Value.Date : null;
    private static void SeleccionarTexto(ComboBox combo, string texto)
    {
        var seleccion = combo.Items.Cast<string>().FirstOrDefault(x => string.Equals(x, texto, StringComparison.OrdinalIgnoreCase));
        if (seleccion == null) { combo.Items.Add(texto); seleccion = texto; }
        combo.SelectedItem = seleccion;
    }
    private void CalcularFin()
    {
        if (cargando) return;
        if (!fechasModificadas)
        {
            fin.Text = original.FechaFin?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "";
            errorFin = null; return;
        }
        try
        {
            var fecha = ValorFecha(inicio);
            fin.Text = fecha.HasValue ? MYGDatosProyecto.CalcularFin(fecha.Value, duracion.Value, unidadDuracion.SelectedItem as string)
                .ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) : "";
            errorFin = null;
        }
        catch (Exception ex) { errorFin = ex.Message; fin.Text = "Revise la duración"; }
    }
    private void MarcarCambioFechas()
    {
        if (cargando) return;
        fechasModificadas |= FechasDistintas(); CalcularFin();
    }
    private bool FechasDistintas() => ValorFecha(inicio) != original.FechaInicio?.Date || duracion.Value != original.Duracion
        || !string.Equals(unidadDuracion.SelectedItem as string, original.UnidadDuracion, StringComparison.OrdinalIgnoreCase);
    private bool CatalogoCambiado(MYGCatalogoProyecto tipo) => !edicion || !ReferenceEquals(Actual(tipo), seleccionesIniciales[tipo]);
    private void CostosExclusivos(CheckBox marcada, CheckBox otra)
    {
        if (cargando || ajustandoCostos) return;
        ajustandoCostos = true;
        try { if (marcada.Checked) otra.Checked = false; else if (!otra.Checked) marcada.Checked = true; }
        finally { ajustandoCostos = false; }
    }
    private void Aceptar() => Intentar(() =>
    {
        string texto = nombre.Text.Trim();
        if (texto.Length == 0) { nombre.Focus(); throw new InvalidOperationException("Indique el nombre del proyecto."); }
        fechasModificadas |= FechasDistintas();
        CalcularFin();
        if (errorFin != null) { duracion.Focus(); throw new InvalidOperationException(errorFin); }
        var resultado = MYGProyectoStorage.Copia(original);
        if (CatalogoCambiado(MYGCatalogoProyecto.Propietarios))
        { resultado.PropietarioId = Actual(MYGCatalogoProyecto.Propietarios)?.Id; resultado.Propietario = Actual(MYGCatalogoProyecto.Propietarios)?.Nombre; }
        if (CatalogoCambiado(MYGCatalogoProyecto.Portafolios))
        { resultado.PortafolioId = Actual(MYGCatalogoProyecto.Portafolios)?.Id; resultado.Portafolio = Actual(MYGCatalogoProyecto.Portafolios)?.Nombre; }
        if (CatalogoCambiado(MYGCatalogoProyecto.TiposObra))
        { resultado.TipoObraId = Actual(MYGCatalogoProyecto.TiposObra)?.Id; resultado.TipoObra = Actual(MYGCatalogoProyecto.TiposObra)?.Nombre; }
        resultado.UsarUbicacion = usarUbicacion.Checked;
        if (CatalogoCambiado(MYGCatalogoProyecto.Departamentos))
        { resultado.DepartamentoId = Actual(MYGCatalogoProyecto.Departamentos)?.Id; resultado.Departamento = Actual(MYGCatalogoProyecto.Departamentos)?.Nombre; }
        if (CatalogoCambiado(MYGCatalogoProyecto.Provincias))
        { resultado.ProvinciaId = Actual(MYGCatalogoProyecto.Provincias)?.Id; resultado.Provincia = Actual(MYGCatalogoProyecto.Provincias)?.Nombre; }
        if (CatalogoCambiado(MYGCatalogoProyecto.Distritos))
        { resultado.DistritoId = Actual(MYGCatalogoProyecto.Distritos)?.Id; resultado.Distrito = Actual(MYGCatalogoProyecto.Distritos)?.Nombre; }
        if (CatalogoCambiado(MYGCatalogoProyecto.Localidades))
        { resultado.LocalidadId = Actual(MYGCatalogoProyecto.Localidades)?.Id; resultado.Localidad = Actual(MYGCatalogoProyecto.Localidades)?.Nombre; }
        resultado.FechaElaboracion = ValorFecha(elaboracion); resultado.FechaInicio = ValorFecha(inicio);
        resultado.Duracion = duracion.Value; resultado.UnidadDuracion = unidadDuracion.SelectedItem as string;
        if (!edicion || !string.Equals(periodos.SelectedItem as string, original.Periodos, StringComparison.OrdinalIgnoreCase))
            resultado.Periodos = periodos.SelectedItem as string;
        if (CatalogoCambiado(MYGCatalogoProyecto.Calendarios))
        {
            string calendarioId = Actual(MYGCatalogoProyecto.Calendarios)?.Id;
            if (!string.IsNullOrWhiteSpace(calendarioId) && !int.TryParse(calendarioId, NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
                throw new InvalidOperationException("Seleccione un calendario válido.");
            resultado.CalendarioId = string.IsNullOrWhiteSpace(calendarioId) ? null : int.Parse(calendarioId, CultureInfo.InvariantCulture);
            resultado.Calendario = Actual(MYGCatalogoProyecto.Calendarios)?.Nombre;
        }
        resultado.ModalidadEjecucion = administracion.Checked ? "A" : "C";
        resultado.PorRendimientoCuadrilla = rendimiento.Checked; resultado.PorAsignacionRecursos = asignacion.Checked;
        resultado.HechoPor = edicion ? original.HechoPor : hechoPor.Text;
        if (fechasModificadas) resultado.CalcularFin();
        resultado.Validar();
        // Un propietario predeterminado nuevo se propone sin escribir en la
        // base. Sólo se registra cuando el usuario confirma datos válidos.
        if (!edicion && string.IsNullOrWhiteSpace(resultado.PropietarioId)
            && !string.IsNullOrWhiteSpace(resultado.Propietario))
        {
            var propietario = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Propietarios, resultado.Propietario);
            resultado.PropietarioId = propietario.Id; resultado.Propietario = propietario.Nombre;
        }
        Nombre = texto; Datos = resultado; DialogResult = DialogResult.OK;
    });
    private void Intentar(Action accion)
    { try { accion(); } catch (Exception ex) { MessageBox.Show(this, ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); } }
}
