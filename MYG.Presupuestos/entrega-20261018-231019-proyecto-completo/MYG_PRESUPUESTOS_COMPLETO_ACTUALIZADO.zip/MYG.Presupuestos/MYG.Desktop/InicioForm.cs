using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;
namespace MYG_2027;

public sealed partial class InicioForm : WinForms.Form
{
    private readonly MYG.Externo.SesionDesktop sesion;
    private readonly WinForms.Panel contenido = new() { Dock = WinForms.DockStyle.Fill };
    private readonly WinForms.Label baseVisible = new()
    {
        Dock = WinForms.DockStyle.Top,
        Height = 44,
        TextAlign = Drawing.ContentAlignment.MiddleLeft,
        Padding = new(22, 0, 22, 0)
    };
    private readonly WinForms.TextBox buscar = new() { Dock = WinForms.DockStyle.Fill, PlaceholderText = "Buscar proyecto aquí" };
    private readonly WinForms.ComboBox tipoObra = new() { Dock = WinForms.DockStyle.Fill, DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly WinForms.DataGridView proyectos = MYGBibliotecaUI.Tabla();
    private List<MYGProyectoResumen> datos = new();
    private string rutaBase;
    private bool ocupado, cerrandoInicio;
    private string refrescoPendiente;
    public InicioForm(MYG.Externo.SesionDesktop sesion)
    {
        this.sesion = sesion;
        MYGProyectoUI.Preparar(this, "Bases de datos y proyectos", 1220, 760);
        MinimumSize = new(900, 540); ShowInTaskbar = true; Text = "MYG Presupuestos";
        var cabecera = new MYG2027_CabeceraComercial { Dock = WinForms.DockStyle.Top, Height = 100 };
        // Distribuir desde el tamaño real de la cabecera evita que Anchor.Right
        // conserve márgenes negativos al acoplarla o al maximizar la ventana.
        var barraCabecera = new WinForms.TableLayoutPanel
        {
            Name = "barraCabeceraInicio", Dock = WinForms.DockStyle.Fill,
            ColumnCount = 4, RowCount = 1, Padding = new(24, 24, 24, 24), Margin = new(0)
        };
        barraCabecera.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        barraCabecera.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 164));
        barraCabecera.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 164));
        barraCabecera.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 164));
        barraCabecera.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        barraCabecera.Controls.Add(new WinForms.Label
        {
            Name = "tituloInicio",
            Text = "MYG Presupuestos",
            Dock = WinForms.DockStyle.Fill,
            TextAlign = Drawing.ContentAlignment.MiddleLeft,
            AutoEllipsis = true, Margin = new(0, 0, 16, 0),
            Font = new("Segoe UI", 25, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.White,
            BackColor = Drawing.Color.Transparent
        }, 0, 0);
        var cuenta = MYGProyectoUI.Boton("Iniciar sesión");
        cuenta.Name = "iniciarSesionInicio";
        cuenta.Dock = WinForms.DockStyle.Fill; cuenta.Margin = new(7, 5, 7, 5);
        MYGAnimacionUI.PrepararBoton(cuenta);
        cuenta.Click += (s, e) => { using var login = new MYG.Externo.LoginForm(sesion); login.ShowDialog(this); };
        var tema = MYG2027_TemaComercial.CrearBotonAlternar();
        tema.Dock = WinForms.DockStyle.Fill; tema.Margin = new(7, 5, 7, 5);
        var tamanoTexto = MYGTamanoTextoUI.CrearBoton();
        tamanoTexto.Name = "tamanoTextoInicio";
        tamanoTexto.Dock = WinForms.DockStyle.Fill; tamanoTexto.Margin = new(7, 5, 7, 5);
        barraCabecera.Controls.Add(tamanoTexto, 1, 0);
        barraCabecera.Controls.Add(tema, 2, 0); barraCabecera.Controls.Add(cuenta, 3, 0);
        cabecera.Controls.Add(barraCabecera);
        MYG2027_TemaComercial.EstilizarCabecera(barraCabecera);
        InicializarProyectosAbiertos(cabecera);
        sesion.Cambio += EstadoSesion; Disposed += (s, e) => sesion.Cambio -= EstadoSesion;
        FormClosing += (s, e) =>
        {
            if (ocupado) { e.Cancel = true; return; }
            cerrandoInicio = true;
            if (!CerrarProyectos()) { e.Cancel = true; cerrandoInicio = false; }
        };
        Shown += (s, e) => EstadoSesion(); MostrarInicio();
    }
    private void EstadoSesion()
    {
        if (IsDisposed) return;
        contenido.Enabled = sesion.Autorizado;
        if (sesion.Autorizado && pestanasProyectos.SelectedTab == paginaInicio) SolicitarRefrescoInicio();
    }
    private void Intentar(Action accion)
    {
        if (ocupado) return;
        try { if (!sesion.Autorizado) throw new InvalidOperationException("Inicie una sesión autorizada para continuar."); accion(); }
        catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
    }
    private async Task IntentarAsync(Func<Task> accion)
    {
        if (ocupado || IsDisposed || Disposing) return;
        try
        {
            RequerirSesion(); ocupado = true;
            await accion();
        }
        catch (Exception ex) { if (!IsDisposed && !Disposing) MYGProyectoUI.Error(this, ex); }
        finally
        {
            ocupado = false;
            ProgramarRefrescoInicio();
        }
    }
    private void RequerirSesion()
    { if (!sesion.Autorizado) throw new InvalidOperationException("Inicie una sesión autorizada para continuar."); }
    private void Boton(WinForms.FlowLayoutPanel barra, string texto, Action accion, int estilo = 0)
    {
        var b = MYGProyectoUI.Boton(texto, estilo); b.AutoSize = true;
        MYGAnimacionUI.PrepararBoton(b); b.Click += (s, e) => Intentar(accion); barra.Controls.Add(b);
    }
    private void Boton(WinForms.FlowLayoutPanel barra, string texto, Func<Task> accion, int estilo = 0)
    {
        var b = MYGProyectoUI.Boton(texto, estilo); b.AutoSize = true;
        MYGAnimacionUI.PrepararBoton(b); b.Click += async (s, e) => await IntentarAsync(accion); barra.Controls.Add(b);
    }
    private void LimpiarContenido()
    {
        // Estos dos controles se reutilizan al cambiar de base.
        if (buscar.Parent != null) buscar.Parent.Controls.Remove(buscar);
        if (proyectos.Parent != null) proyectos.Parent.Controls.Remove(proyectos);
        if (tipoObra.Parent != null) tipoObra.Parent.Controls.Remove(tipoObra);
        foreach (var control in contenido.Controls.Cast<WinForms.Control>().ToArray()) control.Dispose();
    }
    private void MostrarInicio()
    {
        LimpiarContenido(); baseVisible.Text = "Cree o abra un archivo .sqlite para trabajar con sus proyectos y catálogos.";
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new(24) };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 210)); raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 42));
        raiz.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        var opciones = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        opciones.ColumnStyles.Add(new(WinForms.SizeType.Percent, 50)); opciones.ColumnStyles.Add(new(WinForms.SizeType.Percent, 50));
        opciones.Controls.Add(Tarjeta("Crear hoja en blanco", "Crear una base SQLite vacía con unidades básicas. Después podrá agregar proyectos y presupuestos.",
            "Crear archivo .sqlite", CrearBase), 0, 0);
        opciones.Controls.Add(Tarjeta("Abrir base de datos", "Abrir una base MYG o Delphin 2024 y ver todos sus proyectos, presupuestos y catálogos.",
            "Abrir archivo .sqlite", AbrirBase), 1, 0);
        raiz.Controls.Add(opciones, 0, 0);
        raiz.Controls.Add(new WinForms.Label
        {
            Text = "BASES RECIENTES",
            Dock = WinForms.DockStyle.Fill,
            Padding = new(0, 12, 0, 0),
            Font = new("Segoe UI", 10, Drawing.FontStyle.Bold)
        }, 0, 1);
        var recientes = new WinForms.ListBox { Dock = WinForms.DockStyle.Fill, IntegralHeight = false, HorizontalScrollbar = true };
        try
        {
            recientes.Items.AddRange(MYGIndiceLocal.Recientes().Where(MYGBaseDatos.EsRutaSQLite)
                .Distinct(StringComparer.OrdinalIgnoreCase).Cast<object>().ToArray());
        }
        catch { }
        recientes.DoubleClick += async (s, e) => { if (recientes.SelectedItem is string ruta) await IntentarAsync(() => CargarBase(ruta)); };
        raiz.Controls.Add(recientes, 0, 2); contenido.Controls.Add(raiz);
    }
    private WinForms.Control Tarjeta(string titulo, string detalle, string accion, Func<Task> ejecutar)
    {
        var p = new MYG2027_TarjetaComercial { Dock = WinForms.DockStyle.Fill, Padding = new(20), Margin = new(0, 0, 16, 0) };
        var b = MYGProyectoUI.Boton(accion, 1); b.Dock = WinForms.DockStyle.Bottom;
        MYGAnimacionUI.PrepararBoton(b); b.Click += async (s, e) => await IntentarAsync(ejecutar);
        p.Controls.Add(new WinForms.Label { Text = detalle, Dock = WinForms.DockStyle.Fill, Padding = new(0, 10, 0, 0) });
        p.Controls.Add(new WinForms.Label { Text = titulo, Dock = WinForms.DockStyle.Top, Height = 46, Font = new("Segoe UI", 17, Drawing.FontStyle.Bold) });
        p.Controls.Add(b); return p;
    }
    private async Task CrearBase()
    {
        using var d = new WinForms.SaveFileDialog
        {
            Title = "Crear una base de datos SQLite",
            Filter = "Base SQLite (*.sqlite)|*.sqlite",
            DefaultExt = "sqlite",
            AddExtension = true,
            FileName = "MYG_PRESUPUESTOS.sqlite",
            OverwritePrompt = true
        };
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        if (File.Exists(d.FileName)) throw new InvalidOperationException("Ese archivo ya existe. Use Abrir base de datos o elija un nombre nuevo.");
        RequerirSesion();
        string ruta = d.FileName;
        var lista = await MYGCargaAnimada.EjecutarAsync(this, "Creando base de datos…", () =>
        { MYGBaseDatos.CrearBaseVacia(ruta); return LeerListaProyectos(ruta); });
        RequerirSesion(); rutaBase = Path.GetFullPath(ruta); datos = lista.Proyectos;
        RegistrarListaProyectos(ruta, lista.Revision); MostrarProyectos();
    }
    private async Task AbrirBase()
    {
        using var d = new WinForms.OpenFileDialog { Title = "Abrir base de datos", Filter = "Base SQLite (*.sqlite)|*.sqlite" };
        if (d.ShowDialog(this) == WinForms.DialogResult.OK) await CargarBase(d.FileName);
    }
    private async Task CargarBase(string ruta)
    {
        if (!MYGBaseDatos.EsRutaSQLite(ruta))
            throw new InvalidOperationException("Seleccione una base con extensión .sqlite.");
        // Cambiar la base de Inicio conserva los proyectos abiertos en sus pestañas.
        var lista = await MYGCargaAnimada.EjecutarAsync(this, "Abriendo base de datos…", () => LeerListaProyectos(ruta));
        RequerirSesion();
        rutaBase = Path.GetFullPath(ruta); datos = lista.Proyectos;
        RegistrarListaProyectos(ruta, lista.Revision); MostrarProyectos();
    }
    private void MostrarProyectos()
    {
        LimpiarContenido(); baseVisible.Text = "BASE DE DATOS: " + rutaBase;
        buscar.Clear();
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new(20) };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 73)); raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 27));
        var izquierda = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 3, Margin = new(0, 0, 16, 0) };
        izquierda.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        izquierda.RowStyles.Add(new(WinForms.SizeType.Absolute, 42)); izquierda.RowStyles.Add(new(WinForms.SizeType.Absolute, 60));
        izquierda.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        buscar.PlaceholderText = "Buscar proyecto o propietario";
        buscar.TextChanged -= FiltrarProyectos; buscar.TextChanged += FiltrarProyectos;
        var filtros = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new(0) };
        filtros.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100)); filtros.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 190));
        filtros.Controls.Add(buscar, 0, 0); filtros.Controls.Add(tipoObra, 1, 0); izquierda.Controls.Add(filtros, 0, 0);
        var acciones = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill };
        Boton(acciones, "Nuevo proyecto", CrearProyecto, 1); Boton(acciones, "Abrir proyecto", AbrirProyectoSeleccionado);
        Boton(acciones, "Nuevo presupuesto", CrearPresupuestoSeleccionado);
        Boton(acciones, "Datos del proyecto", EditarProyectoSeleccionado); izquierda.Controls.Add(acciones, 0, 1);
        proyectos.ReadOnly = true; proyectos.MultiSelect = false; proyectos.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect;
        proyectos.Columns.Clear();
        proyectos.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "NOMBRE", HeaderText = "Proyectos", AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill });
        proyectos.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "PRESUPUESTOS", HeaderText = "Presupuestos", Width = 110 });
        proyectos.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "FECHA", HeaderText = "Actualizado", Width = 120 });
        proyectos.Columns["NOMBRE"].DefaultCellStyle.WrapMode = WinForms.DataGridViewTriState.True;
        proyectos.RowTemplate.Height = 88; proyectos.CellDoubleClick -= DobleClickProyecto; proyectos.CellDoubleClick += DobleClickProyecto;
        CargarTiposObra(); tipoObra.SelectedIndexChanged -= FiltrarProyectos; tipoObra.SelectedIndexChanged += FiltrarProyectos;
        izquierda.Controls.Add(proyectos, 0, 2); raiz.Controls.Add(izquierda, 0, 0);
        var opciones = new WinForms.FlowLayoutPanel { Name = "opcionesInicio", Dock = WinForms.DockStyle.Fill, FlowDirection = WinForms.FlowDirection.TopDown, WrapContents = false, AutoScroll = true };
        opciones.Controls.Add(new WinForms.Label { Text = "Opciones", Width = 240, Height = 42, Font = new("Segoe UI", 17, Drawing.FontStyle.Bold) });
        BotonOpcion(opciones, "Catálogo de partidas", () => Catalogos(true));
        BotonOpcion(opciones, "Catálogo de insumos", () => Catalogos(false));
        BotonOpcion(opciones, "Unidades", () => { using var f = new MYGUnidadesForm(rutaBase, () => sesion.Autorizado); f.ShowDialog(this); });
        BotonOpcion(opciones, "Importar presupuesto Delphin", ImportarDelphin);
        BotonOpcion(opciones, "Abrir otra base", AbrirBase);
        BotonOpcion(opciones, "Crear otra base", CrearBase);
        opciones.Controls.Add(CrearOpcionParametrosInicio());
        raiz.Controls.Add(opciones, 1, 0); contenido.Controls.Add(raiz); FiltrarProyectos(null, EventArgs.Empty);
    }
    private void BotonOpcion(WinForms.FlowLayoutPanel panel, string texto, Action accion)
    {
        var b = new WinForms.Button
        {
            Text = texto,
            Width = 250,
            Height = 72,
            FlatStyle = WinForms.FlatStyle.Flat,
            Font = new("Segoe UI", 11, Drawing.FontStyle.Bold),
            Margin = new(0, 0, 0, 10)
        };
        MYG2027_TemaComercial.EstilizarBoton(b, 2); MYGAnimacionUI.PrepararBoton(b);
        b.Click += (s, e) => Intentar(accion); panel.Controls.Add(b);
    }
    private void BotonOpcion(WinForms.FlowLayoutPanel panel, string texto, Func<Task> accion)
    {
        var b = new WinForms.Button
        {
            Text = texto,
            Width = 250,
            Height = 72,
            FlatStyle = WinForms.FlatStyle.Flat,
            Font = new("Segoe UI", 11, Drawing.FontStyle.Bold),
            Margin = new(0, 0, 0, 10)
        };
        MYG2027_TemaComercial.EstilizarBoton(b, 2); MYGAnimacionUI.PrepararBoton(b);
        b.Click += async (s, e) => await IntentarAsync(accion); panel.Controls.Add(b);
    }
    private async void DobleClickProyecto(object sender, WinForms.DataGridViewCellEventArgs e)
    { if (e.RowIndex >= 0) await IntentarAsync(AbrirProyectoSeleccionado); }
    private MYGProyectoResumen Actual => proyectos.CurrentRow?.Tag as MYGProyectoResumen;
    private async Task RefrescarProyectosAsync(string seleccionar = null)
    {
        string ruta = rutaBase;
        var lista = await MYGCargaAnimada.EjecutarAsync(this, "Actualizando proyectos…", () => LeerListaProyectos(ruta));
        RequerirSesion();
        if (!MismaRuta(ruta, rutaBase)) { SolicitarRefrescoInicio(); return; }
        bool cambioBase = !MismaRuta(ruta, rutaProyectosCargados);
        datos = lista.Proyectos;
        RegistrarListaProyectos(ruta, lista.Revision);
        baseVisible.Text = "BASE DE DATOS: " + rutaBase;
        if (cambioBase || !proyectos.Columns.Contains("NOMBRE")) MostrarProyectos();
        AplicarProyectos(seleccionar);
    }
    private void AplicarProyectos(string seleccionar)
    {
        CargarTiposObra(); FiltrarProyectos(null, EventArgs.Empty);
        SeleccionarProyecto(seleccionar);
    }
    private void SeleccionarProyecto(string seleccionar)
    {
        if (string.IsNullOrEmpty(seleccionar)) return;
        var fila = proyectos.Rows.Cast<WinForms.DataGridViewRow>().FirstOrDefault(r => ((MYGProyectoResumen)r.Tag).Id == seleccionar);
        if (seleccionar != null && fila == null && datos.Any(p => p.Id == seleccionar))
        {
            buscar.Clear(); tipoObra.SelectedIndex = 0; FiltrarProyectos(null, EventArgs.Empty);
            fila = proyectos.Rows.Cast<WinForms.DataGridViewRow>().FirstOrDefault(r => ((MYGProyectoResumen)r.Tag).Id == seleccionar);
        }
        if (fila != null) proyectos.CurrentCell = fila.Cells[0];
    }
    private void FiltrarProyectos(object sender, EventArgs e)
    {
        proyectos.Rows.Clear();
        if (!proyectos.Columns.Contains("NOMBRE")) return;
        string filtro = buscar.Text.Trim(), tipo = tipoObra.SelectedIndex > 0 ? tipoObra.SelectedItem as string : null;
        foreach (var p in datos.Where(p => (p.Nombre + " " + p.Propietario + " " + p.TipoObra).Contains(filtro, StringComparison.OrdinalIgnoreCase) &&
            (tipo == null || string.Equals(p.TipoObra, tipo, StringComparison.OrdinalIgnoreCase))))
        {
            string detalle = string.Join(" · ", new[] { p.Propietario, p.TipoObra }.Where(x => !string.IsNullOrWhiteSpace(x)));
            int n = proyectos.Rows.Add(p.Nombre + (detalle.Length == 0 ? "" : "\n" + detalle), p.CantidadPresupuestos, p.ModificadoUtc.ToLocalTime().ToString("dd/MM/yyyy"));
            proyectos.Rows[n].Tag = p;
        }
    }
    private void CargarTiposObra()
    {
        string seleccionado = tipoObra.SelectedItem as string;
        tipoObra.Items.Clear(); tipoObra.Items.Add("Todos los tipos de obra");
        tipoObra.Items.AddRange(datos.Select(x => x.TipoObra).Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).Cast<object>().ToArray());
        tipoObra.SelectedIndex = seleccionado != null && tipoObra.Items.Contains(seleccionado) ? tipoObra.Items.IndexOf(seleccionado) : 0;
    }
    private async Task CrearProyecto()
    {
        using var d = new MYGDatosProyectoForm(rutaBase, "", usuario: sesion.Credencial?.Usuario);
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        RequerirSesion();
        var doc = new MYGProyectoDocumento { Nombre = d.Nombre, Datos = d.Datos };
        string ruta = rutaBase;
        var lista = await MYGCargaAnimada.EjecutarAsync(this, "Creando proyecto…", () =>
        { MYGProyectoStorage.Guardar(ruta, doc); return LeerListaProyectos(ruta); });
        RequerirSesion(); datos = lista.Proyectos; RegistrarListaProyectos(ruta, lista.Revision); AplicarProyectos(doc.Id);
        AbrirEditor(doc);
    }
    private async Task EditarProyectoSeleccionado()
    {
        var elegido = Actual ?? throw new InvalidOperationException("Seleccione un proyecto.");
        var abierto = BuscarEditor(rutaBase, elegido.Id);
        if (abierto != null)
        {
            SeleccionarEditor(abierto);
            abierto.EditarDatosProyectoAbierto();
            return;
        }
        var doc = await LeerProyectoAsync(elegido.Id);
        using var d = new MYGDatosProyectoForm(rutaBase, doc.Nombre, doc.Datos, sesion.Credencial?.Usuario, "Datos del proyecto", doc.Id);
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        RequerirSesion();
        doc.Nombre = d.Nombre; doc.Datos = d.Datos;
        string ruta = rutaBase;
        var lista = await MYGCargaAnimada.EjecutarAsync(this, "Guardando datos del proyecto…", () =>
        { MYGProyectoStorage.Guardar(ruta, doc); return LeerListaProyectos(ruta); });
        RequerirSesion(); datos = lista.Proyectos; RegistrarListaProyectos(ruta, lista.Revision); AplicarProyectos(doc.Id);
    }
    private async Task CrearPresupuestoSeleccionado()
    {
        var elegido = Actual ?? throw new InvalidOperationException("Seleccione un proyecto.");
        var abierto = BuscarEditor(rutaBase, elegido.Id);
        if (abierto != null)
        {
            SeleccionarEditor(abierto); abierto.AgregarPresupuestoEnTabla(); return;
        }
        var doc = await LeerProyectoAsync(elegido.Id);
        AbrirEditor(doc).AgregarPresupuestoEnTabla();
    }
    private async Task AbrirProyectoSeleccionado()
    {
        var elegido = Actual ?? throw new InvalidOperationException("Seleccione un proyecto.");
        var abierto = BuscarEditor(rutaBase, elegido.Id);
        if (abierto != null) { SeleccionarEditor(abierto); return; }
        var doc = await LeerProyectoAsync(elegido.Id);
        AbrirEditor(doc);
    }
    private async Task<MYGProyectoDocumento> LeerProyectoAsync(string id)
    {
        string ruta = rutaBase;
        var doc = await MYGCargaAnimada.EjecutarAsync(this, "Cargando proyecto y presupuestos…", () => MYGBaseDatos.LeerProyecto(ruta, id));
        RequerirSesion(); return doc;
    }
    private void Catalogos(bool partidas)
    { using var f = new MYGCatalogoPropioForm(rutaBase, partidas, () => sesion.Autorizado, soloAdministrar: true); f.ShowDialog(this); }
    private async Task ImportarDelphin()
    {
        using var d = new MYGConectarDelphinForm();
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        RequerirSesion();
        var c = d.Conexion;
        string nombre = d.NombrePresupuesto, codigo = d.CodigoPresupuesto, ruta = rutaBase;
        var resultado = await MYGCargaAnimada.EjecutarAsync(this, "Importando presupuesto Delphin…", () =>
        {
            var doc = new MYGProyectoDocumento
            {
                Nombre = LectorDelphin.LeerProyectosSQLite(c.RutaSQLite).First(p => p.Id == c.ProyectoId).Nombre,
                FuenteCatalogo = new MYGFuenteDelphin { Id = c.FuenteId, RutaSQLite = c.RutaSQLite }
            };
            var p = new MYGPresupuestoDocumento { Nombre = nombre, Item = codigo, Posicion = 1, Conexion = c };
            MYGProyectoStorage.ActualizarDesdeDelphin(p, LectorDelphin.LeerItemsPresupuestoSQLite(c.RutaSQLite, c.PresupuestoId));
            doc.Presupuestos.Add(p); doc.PresupuestoActivoId = p.Id;
            MYGProyectoStorage.Guardar(ruta, doc);
            return (Documento: doc, Lista: LeerListaProyectos(ruta));
        });
        RequerirSesion(); datos = resultado.Lista.Proyectos; RegistrarListaProyectos(ruta, resultado.Lista.Revision);
        AplicarProyectos(resultado.Documento.Id); AbrirEditor(resultado.Documento);
    }
}
