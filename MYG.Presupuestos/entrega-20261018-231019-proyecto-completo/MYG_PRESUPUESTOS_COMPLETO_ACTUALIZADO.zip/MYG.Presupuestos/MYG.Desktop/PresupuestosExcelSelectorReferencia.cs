using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGElegirPartidaReferenciaHojaForm : Form
{
    private readonly List<(MYGPresupuestoDocumento Presupuesto, ItemPresupuestoDelphin Partida)> partidas;
    private readonly ComboBox presupuesto = new() { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox buscar = new() { Dock = DockStyle.Fill, PlaceholderText = "Buscar por ítem, descripción o unidad…" };
    private readonly DataGridView lista = new()
    {
        Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        AllowUserToOrderColumns = false, AutoGenerateColumns = false, RowHeadersVisible = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, BorderStyle = BorderStyle.None
    };
    internal MYGPresupuestoDocumento Presupuesto { get; private set; }
    internal ItemPresupuestoDelphin Partida { get; private set; }

    internal MYGElegirPartidaReferenciaHojaForm(IEnumerable<MYGPresupuestoDocumento> presupuestos, string presupuestoDestino, string partidaDestino)
    {
        Text = "Referenciar otra partida"; Name = "metrado_selector_referencia"; StartPosition = FormStartPosition.CenterParent;
        ClientSize = new(740, 440); MinimumSize = new(540, 340); Font = new("Segoe UI", 9.5f);
        MinimizeBox = false; ShowInTaskbar = false;
        var documentos = presupuestos.OrderBy(p => p.Posicion).ThenBy(p => p.Item).ToArray();
        partidas = documentos.SelectMany(p => MYGOrdenPresupuestos.FilasOrdenadas(p)
            .Where(i => !MYGProyectoStorage.EsTitulo(i) && (p.Id != presupuestoDestino || i.Id != partidaDestino))
            .Select(i => (p, i))).ToList();
        var cabecera = new TableLayoutPanel { Dock = DockStyle.Top, Height = 98, ColumnCount = 2, RowCount = 3, Padding = new(12, 8, 12, 5) };
        cabecera.ColumnStyles.Add(new(SizeType.Absolute, 94)); cabecera.ColumnStyles.Add(new(SizeType.Percent, 100));
        var instruccion = new Label { Text = "1. Elija la partida de origen. Después podrá señalar la celda en su hoja de metrado.", AutoSize = true, Dock = DockStyle.Fill };
        cabecera.Controls.Add(instruccion, 0, 0); cabecera.SetColumnSpan(instruccion, 2);
        cabecera.Controls.Add(new Label { Text = "Presupuesto", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);
        cabecera.Controls.Add(presupuesto, 1, 1);
        cabecera.Controls.Add(new Label { Text = "Buscar", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 2);
        cabecera.Controls.Add(buscar, 1, 2);
        presupuesto.Name = "metrado_selector_presupuesto"; buscar.Name = "metrado_selector_buscar"; lista.Name = "metrado_selector_partidas";
        presupuesto.Items.Add(new OpcionPresupuesto(null));
        foreach (var p in documentos) presupuesto.Items.Add(new OpcionPresupuesto(p));
        presupuesto.SelectedIndex = 0;
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "PRES", HeaderText = "Presupuesto", Width = 170 });
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "ITEM", HeaderText = "Ítem", Width = 78 });
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "DESC", HeaderText = "Descripción", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "UND", HeaderText = "Unidad", Width = 62 });
        foreach (DataGridViewColumn columna in lista.Columns) columna.SortMode = DataGridViewColumnSortMode.NotSortable;
        var botones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 46, FlowDirection = FlowDirection.RightToLeft, Padding = new(9), WrapContents = false };
        var aceptar = new Button { Text = "Ir al metrado →", AutoSize = true, Height = 29, Name = "metrado_selector_abrir" };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, AutoSize = true, Height = 29 };
        botones.Controls.Add(aceptar); botones.Controls.Add(cancelar);
        AcceptButton = aceptar; CancelButton = cancelar;
        aceptar.Click += (_, _) => Elegir();
        lista.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) Elegir(); };
        presupuesto.SelectedIndexChanged += (_, _) => Filtrar(); buscar.TextChanged += (_, _) => Filtrar();
        lista.SelectionChanged += (_, _) => aceptar.Enabled = lista.CurrentRow != null;
        Controls.Add(lista); Controls.Add(botones); Controls.Add(cabecera);
        BackColor = MYG2027_TemaComercial.Superficie; ForeColor = MYG2027_TemaComercial.Texto;
        lista.BackgroundColor = MYG2027_TemaComercial.Superficie;
        lista.DefaultCellStyle.BackColor = MYG2027_TemaComercial.Superficie; lista.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
        lista.DefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.Seleccion; lista.DefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
        Filtrar(); Shown += (_, _) => buscar.Focus();
    }

    private void Filtrar()
    {
        lista.Rows.Clear(); string filtro = buscar.Text.Trim();
        string id = (presupuesto.SelectedItem as OpcionPresupuesto)?.Documento?.Id;
        foreach (var par in partidas.Where(p => (id == null || p.Presupuesto.Id == id) &&
            (filtro.Length == 0 || (p.Presupuesto.Nombre + " " + p.Presupuesto.Item + " " + p.Partida.Item + " " + p.Partida.Descripcion + " " + p.Partida.Unidad)
                .Contains(filtro, StringComparison.CurrentCultureIgnoreCase))))
        {
            var fila = lista.Rows[lista.Rows.Add(par.Presupuesto.Item + " - " + par.Presupuesto.Nombre, par.Partida.Item, par.Partida.Descripcion, par.Partida.Unidad)];
            fila.Tag = par;
        }
        if (lista.Rows.Count > 0) lista.CurrentCell = lista.Rows[0].Cells["DESC"];
    }

    private void Elegir()
    {
        if (lista.CurrentRow?.Tag is not ValueTuple<MYGPresupuestoDocumento, ItemPresupuestoDelphin> par) return;
        Presupuesto = par.Item1; Partida = par.Item2; DialogResult = DialogResult.OK;
    }

    private sealed record OpcionPresupuesto(MYGPresupuestoDocumento Documento)
    {
        public override string ToString() => Documento == null ? "Todos los presupuestos del proyecto" : Documento.Item + " - " + Documento.Nombre;
    }
}
