using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Información de la selección, editada sobre una copia hasta Guardar cambios.</summary>
internal sealed class MYGInformacionTareaControl : UserControl
{
    private const string Prefijo = "cronograma_info_";
    private readonly Func<MYGCronograma> obtener;
    private readonly Func<MYGProyectoDocumento> obtenerProyecto;
    private readonly Action<MYGCronograma> aplicar;
    private readonly Func<bool> puedeEditar;
    private readonly Label cabecera = new() { Name = Prefijo + "cabecera", Dock = DockStyle.Top, Height = 36, Padding = new(7, 5, 7, 3), AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly Label duracionInicial = Etiqueta("duracion_inicial");
    private readonly NumericUpDown cuadrillasIniciales = Numero("cuadrillas_iniciales", .0001m, 1000000m, 4);
    private readonly CheckBox reprogramar = new() { Name = Prefijo + "reprogramar", Text = "Reprog.", AutoSize = true };
    private readonly NumericUpDown nuevaDuracion = Numero("nueva_duracion", 0, 36500);
    private readonly Label cuadrillasActuales = Etiqueta("cuadrillas_actuales");
    private readonly ComboBox restriccion = Selector("restriccion");
    private readonly DateTimePicker fechaRestriccion = MYGCronogramaDialogoUI.Fecha(Prefijo + "fecha_restriccion", DateTime.Today);
    private readonly DataGridView dependencias = Tabla("dependencias");
    private readonly DataGridView partes = Tabla("partes");
    private readonly NumericUpDown dividirNumero = Numero("dividir_numero", 1, 1000);
    private readonly NumericUpDown dividirIntervalo = Numero("dividir_intervalo", 0, 36500);
    private readonly Label duracionPartes = Etiqueta("duracion_partes");
    private readonly Label totales = new() { Name = Prefijo + "totales", Dock = DockStyle.Bottom, Height = 32, TextAlign = ContentAlignment.MiddleLeft, Padding = new(6, 3, 6, 3), AutoEllipsis = true };
    private readonly Label mensaje = new() { Name = Prefijo + "mensaje", Dock = DockStyle.Bottom, Height = 32, Padding = new(7, 4, 7, 3), AutoEllipsis = true, AccessibleName = "Resultado de la validación de la información de tarea" };
    private readonly TextBox nombre = new() { Name = Prefijo + "nombre", MaxLength = 500 };
    private readonly ComboBox modo = Selector("modo");
    private readonly DateTimePicker inicio = MYGCronogramaDialogoUI.Fecha(Prefijo + "inicio", DateTime.Today);
    private readonly NumericUpDown duracion = Numero("duracion", 0, 36500);
    private readonly NumericUpDown avance = Numero("avance", 0, 100, 2);
    private readonly TextBox responsables = new() { Name = Prefijo + "responsables", Multiline = true, AcceptsReturn = true, ScrollBars = ScrollBars.Vertical };
    private readonly TextBox notas = new() { Name = Prefijo + "notas", Multiline = true, AcceptsReturn = true, ScrollBars = ScrollBars.Vertical, MaxLength = 20000 };
    private readonly List<Control> editores = new();
    private readonly List<Button> botones = new();
    private readonly ToolTip ayuda = new();
    private MYGCronograma copia;
    private MYGTareaCronograma tarea;
    private MYGResultadoTarea fila;
    private string seleccionId, firmaOriginal, firmaControles;
    private DateTime inicioPartes;
    private decimal? cantidadTotal;
    private string unidad;
    private bool cargando, aplicando, partesModificadas, mostrandoTramosImportados;

    internal MYGInformacionTareaControl(Func<MYGCronograma> obtener, Func<MYGProyectoDocumento> obtenerProyecto,
        Action<MYGCronograma> aplicar, Func<bool> puedeEditar)
    {
        this.obtener = obtener ?? throw new ArgumentNullException(nameof(obtener));
        this.obtenerProyecto = obtenerProyecto ?? throw new ArgumentNullException(nameof(obtenerProyecto));
        this.aplicar = aplicar ?? throw new ArgumentNullException(nameof(aplicar));
        this.puedeEditar = puedeEditar ?? throw new ArgumentNullException(nameof(puedeEditar));
        Name = "cronograma_informacion_tarea";
        AccessibleName = "Información de la tarea: planificación, dependencias y partes";
        Dock = DockStyle.Fill;
        Font = new Font("Segoe UI", 9F);
        AutoScaleMode = AutoScaleMode.Font;
        AutoScroll = true;
        Height = 350;
        var contenido = new TableLayoutPanel
        {
            Name = Prefijo + "contenido", Dock = DockStyle.Fill, MinimumSize = new Size(1270, 268),
            Padding = new Padding(4), ColumnCount = 3, RowCount = 1
        };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 295));
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        PrepararDependencias();
        PrepararPartes();
        contenido.Controls.Add(CrearPlanificacion(), 0, 0);
        contenido.Controls.Add(CrearDependencias(), 1, 0);
        contenido.Controls.Add(CrearPartes(), 2, 0);
        var pie = new FlowLayoutPanel { Name = Prefijo + "acciones", Dock = DockStyle.Bottom, Height = 37, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(4), WrapContents = false };
        pie.Controls.Add(Boton("Guardar cambios", "guardar", GuardarCambios));
        pie.Controls.Add(Boton("Cancelar cambios", "cancelar", () => CargarCopia(seleccionId)));
        Controls.Add(contenido);
        Controls.Add(cabecera);
        Controls.Add(mensaje);
        Controls.Add(pie);
        editores.AddRange(new Control[] { cuadrillasIniciales, reprogramar, nuevaDuracion, restriccion,
            fechaRestriccion, dividirNumero, dividirIntervalo, nombre, modo, inicio, duracion, avance, responsables, notas });
        PrepararEventos();
        MYG2027_TemaComercial.CambioTema += CambioTema;
        Disposed += (_, _) => { MYG2027_TemaComercial.CambioTema -= CambioTema; ayuda.Dispose(); Font.Dispose(); };
        AplicarTema();
        Cargar(null);
    }

    private bool Editable => tarea != null && !tarea.EsResumen && puedeEditar();
    internal bool TieneCambios => tarea != null && (dependencias.IsCurrentCellDirty || partes.IsCurrentCellDirty || FirmaControles() != firmaControles);

    private Control CrearPlanificacion()
    {
        var paginas = new TabControl { Name = Prefijo + "planificacion_paginas", Dock = DockStyle.Fill };
        var planificacion = new TabPage("Planificación de tarea") { AutoScroll = true, Padding = new Padding(3) };
        var general = new TabPage("General") { AutoScroll = true, Padding = new Padding(3) };
        var tabla = Campos();
        Campo(tabla, "Duración inicial", duracionInicial);
        Campo(tabla, "N.º cuadrillas iniciales", cuadrillasIniciales);
        Campo(tabla, "Reprogramación", reprogramar);
        Campo(tabla, "Nueva duración (días)", nuevaDuracion);
        Campo(tabla, "N.º cuadrillas actuales", cuadrillasActuales);
        restriccion.Items.AddRange(MYGInformacionTarea.NombresRestricciones.Cast<object>().ToArray());
        Campo(tabla, "Tipo de restricción", restriccion, 45);
        Campo(tabla, "Fecha de restricción", fechaRestriccion);
        planificacion.Controls.Add(tabla);
        var campos = Campos();
        modo.Items.AddRange(new object[] { "Automática", "Manual" });
        Campo(campos, "Nombre", nombre);
        Campo(campos, "Programación", modo);
        Campo(campos, "Inicio manual", inicio);
        Campo(campos, "Duración (días hábiles)", duracion);
        Campo(campos, "Avance (%)", avance);
        Campo(campos, "Responsables", responsables, 64);
        Campo(campos, "Notas", notas, 70);
        general.Controls.Add(campos);
        paginas.TabPages.Add(planificacion);
        paginas.TabPages.Add(general);
        ayuda.SetToolTip(cuadrillasIniciales, "Cuadrillas de la planificación inicial; la reprogramación conserva el esfuerzo inicial.");
        ayuda.SetToolTip(cuadrillasActuales, "Cuadrillas iniciales × duración inicial ÷ nueva duración.");
        ayuda.SetToolTip(responsables, "Un responsable por línea. Se conserva su identidad; las cuadrillas no sustituyen a los responsables.");
        return paginas;
    }

    private Control CrearDependencias()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(4, 0, 4, 0) };
        panel.Controls.Add(dependencias);
        panel.Controls.Add(Titulo("Dependencias (predecesoras)"));
        var acciones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 35, WrapContents = false };
        acciones.Controls.Add(Boton("+ Agregar", "dependencia_agregar", AgregarDependencia));
        acciones.Controls.Add(Boton("Elegir tarea…", "dependencia_elegir", ElegirDependencia));
        acciones.Controls.Add(Boton("Eliminar", "dependencia_eliminar", EliminarDependencia));
        panel.Controls.Add(acciones);
        return panel;
    }

    private Control CrearPartes()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(4, 0, 0, 0) };
        var barra = new FlowLayoutPanel { Name = Prefijo + "dividir_barra", Dock = DockStyle.Top, Height = 60, AutoScroll = true, WrapContents = true };
        dividirNumero.Width = 52;
        dividirIntervalo.Width = 54;
        barra.Controls.Add(duracionPartes);
        barra.Controls.Add(new Label { Text = "Dividir en", AutoSize = true, Padding = new Padding(0, 6, 0, 0) });
        barra.Controls.Add(dividirNumero);
        barra.Controls.Add(new Label { Text = "partes con", AutoSize = true, Padding = new Padding(0, 6, 0, 0) });
        barra.Controls.Add(dividirIntervalo);
        barra.Controls.Add(new Label { Text = "días de intervalo", AutoSize = true, Padding = new Padding(0, 6, 0, 0) });
        barra.Controls.Add(Boton("Aplicar", "dividir_aplicar", Dividir));
        panel.Controls.Add(partes);
        panel.Controls.Add(barra);
        panel.Controls.Add(totales);
        ayuda.SetToolTip(dividirIntervalo, "Días laborables sin trabajo entre una parte y la siguiente. Aplicar prepara la división; Guardar cambios la incorpora al proyecto.");
        ayuda.SetToolTip(partes, "Edite Inicio como dd/MM/aaaa, Duración en días laborables, Cantidad y % valorizado. El fin se calcula con el calendario del proyecto.");
        return panel;
    }

    private void PrepararDependencias()
    {
        dependencias.AccessibleName = "Predecesoras de la tarea seleccionada";
        dependencias.Columns.Add(new DataGridViewComboBoxColumn
        {
            Name = "TAREA_ID", HeaderText = "Id", Width = 72, DisplayMember = nameof(OpcionTarea.Numero), ValueMember = nameof(OpcionTarea.Id),
            DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        dependencias.Columns.Add(new DataGridViewTextBoxColumn { Name = "NOMBRE", HeaderText = "Tarea dependiente", ReadOnly = true, AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, MinimumWidth = 140 });
        var tipo = new DataGridViewComboBoxColumn { Name = "TIPO", HeaderText = "Tipo", Width = 128, DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton, SortMode = DataGridViewColumnSortMode.NotSortable };
        tipo.Items.AddRange("FC (Final - Inicio)", "FF (Final - Final)", "CF (Inicio - Final)", "CC (Inicio - Inicio)");
        dependencias.Columns.Add(tipo);
        dependencias.Columns.Add(new DataGridViewTextBoxColumn { Name = "DESFASE", HeaderText = "Desfase (d)", Width = 75, SortMode = DataGridViewColumnSortMode.NotSortable });
    }

    private void PrepararPartes()
    {
        partes.AccessibleName = "Partes de la tarea y distribución del metrado";
        void Columna(string nombreColumna, string titulo, int ancho, bool lectura = false, string formato = null)
        {
            var columna = new DataGridViewTextBoxColumn { Name = nombreColumna, HeaderText = titulo, Width = ancho, ReadOnly = lectura, SortMode = DataGridViewColumnSortMode.NotSortable };
            if (formato != null) columna.DefaultCellStyle.Format = formato;
            partes.Columns.Add(columna);
        }
        Columna("INICIO", "Inicio", 92, false, "dd/MM/yyyy");
        Columna("DURACION", "Duración (d)", 78);
        Columna("FIN", "Fin", 92, true, "dd/MM/yyyy");
        Columna("CANTIDAD", "Cantidad", 90, false, "0.####");
        Columna("PORCENTAJE", "% Valorizado", 90, false, "0.###");
        partes.Columns["PORCENTAJE"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
    }

    private void PrepararEventos()
    {
        restriccion.SelectedIndexChanged += (_, _) => ActualizarPermisos();
        modo.SelectedIndexChanged += (_, _) => ActualizarPermisos();
        cuadrillasIniciales.ValueChanged += (_, _) => ActualizarCuadrillas();
        reprogramar.CheckedChanged += (_, _) =>
        {
            if (cargando || tarea == null) return;
            if (!reprogramar.Checked) nuevaDuracion.Value = Math.Clamp(tarea.DuracionInicialDias ?? tarea.DuracionDias, 0, 36500);
            ActualizarPermisos();
            SincronizarDuracion(nuevaDuracion);
        };
        nuevaDuracion.ValueChanged += (_, _) => SincronizarDuracion(nuevaDuracion);
        duracion.ValueChanged += (_, _) => SincronizarDuracion(duracion);
        inicio.ValueChanged += (_, _) =>
        {
            if (cargando || tarea == null || modo.SelectedIndex != 1) return;
            Intentar(() =>
            {
                partesModificadas = true;
                var lista = mostrandoTramosImportados ? LeerPartes() : LeerPartesSinFechas();
                if (mostrandoTramosImportados) ValidarConversionImportada(lista);
                inicioPartes = copia.Calendario.SiguienteLaborable(inicio.Value.Date);
                MostrarPartes(lista);
            });
        };
        foreach (var tabla in new[] { dependencias, partes })
        {
            tabla.CurrentCellDirtyStateChanged += (_, _) => { if (tabla.IsCurrentCellDirty && tabla.CurrentCell is DataGridViewComboBoxCell) tabla.CommitEdit(DataGridViewDataErrorContexts.Commit); };
            tabla.DataError += (_, e) => { e.ThrowException = false; e.Cancel = true; MostrarError("El valor de la celda no es válido. Revise la fecha, el número o la tarea seleccionada."); };
        }
        dependencias.CellValueChanged += (_, e) =>
        {
            if (!cargando && e.RowIndex >= 0 && e.ColumnIndex == dependencias.Columns["TAREA_ID"].Index)
                ActualizarNombreDependencia(dependencias.Rows[e.RowIndex]);
        };
        dependencias.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dependencias.Columns["NOMBRE"].Index)
                Intentar(ElegirDependencia);
        };
        dependencias.KeyDown += (_, e) =>
        {
            if (e.KeyCode != Keys.F4 || !Editable) return;
            e.Handled = true;
            Intentar(ElegirDependencia);
        };
        partes.CellValueChanged += (_, e) =>
        {
            if (cargando || e.RowIndex < 0 || partes.Columns[e.ColumnIndex].Name == "FIN") return;
            partesModificadas = true;
            Intentar(() =>
            {
                string columna = partes.Columns[e.ColumnIndex].Name;
                if (!mostrandoTramosImportados || columna is "INICIO" or "DURACION")
                    ActualizarFinParte(partes.Rows[e.RowIndex]);
                ActualizarTotales();
            });
        };
    }

    internal void Cargar(string tareaId)
    {
        if (cargando || aplicando || IsDisposed) return;
        var original = obtener()?.Tareas?.FirstOrDefault(t => t.Id == tareaId);
        if (seleccionId == tareaId && tarea != null && Firma(original) == firmaOriginal)
        { ActualizarPermisos(); return; }
        if (tarea != null && TieneCambios && !ConfirmarSalida()) return;
        CargarCopia(tareaId);
    }

    private void CargarCopia(string tareaId)
    {
        cargando = true;
        try
        {
            seleccionId = tareaId;
            copia = MYGProyectoStorage.Copia(obtener());
            tarea = copia?.Tareas?.FirstOrDefault(t => t.Id == tareaId);
            fila = tarea == null ? null : MYGMotorCronograma.Calcular(copia).Filas.FirstOrDefault(f => f.Tarea.Id == tareaId);
            firmaOriginal = Firma(tarea);
            partesModificadas = false;
            mostrandoTramosImportados = false;
            cantidadTotal = null;
            unidad = "";
            dependencias.Rows.Clear();
            partes.Rows.Clear();
            mensaje.Text = "";
            if (tarea == null)
            {
                cabecera.Text = "Seleccione una tarea del cronograma para consultar su información.";
                duracionInicial.Text = cuadrillasActuales.Text = duracionPartes.Text = totales.Text = "—";
                nombre.Text = responsables.Text = notas.Text = "";
                reprogramar.Checked = false;
                restriccion.SelectedIndex = -1;
                modo.SelectedIndex = -1;
                firmaControles = FirmaControles();
                ActualizarPermisos();
                return;
            }
            LeerPartida();
            cabecera.Text = (tarea.Codigo ?? "") + "  " + tarea.Nombre + "     Und.: " + (string.IsNullOrWhiteSpace(unidad) ? "—" : unidad) +
                "   Cantidad: " + (cantidadTotal?.ToString("0.####", CultureInfo.CurrentCulture) ?? "—");
            nombre.Text = tarea.Nombre ?? "";
            modo.SelectedIndex = tarea.Modo == MYGModoTarea.Manual ? 1 : 0;
            AsignarFecha(inicio, tarea.InicioManual ?? fila?.Inicio ?? copia.FechaInicio);
            duracion.Value = nuevaDuracion.Value = Math.Clamp(tarea.DuracionDias, 0, 36500);
            duracionInicial.Text = (tarea.DuracionInicialDias ?? tarea.DuracionDias).ToString(CultureInfo.CurrentCulture) + " días";
            decimal cuadrillasBase = tarea.DuracionInicialDias.HasValue ? tarea.CuadrillasIniciales : tarea.NumeroCuadrillas;
            cuadrillasIniciales.Value = Math.Clamp(cuadrillasBase, cuadrillasIniciales.Minimum, cuadrillasIniciales.Maximum);
            reprogramar.Checked = tarea.Reprogramada;
            avance.Value = Math.Clamp(tarea.Avance, 0, 100);
            responsables.Text = string.Join(Environment.NewLine, tarea.Responsables ?? new List<string>());
            notas.Text = tarea.Notas ?? "";
            restriccion.SelectedIndex = (int)tarea.TipoRestriccion;
            AsignarFecha(fechaRestriccion, tarea.FechaRestriccion ?? fila?.Inicio ?? copia.FechaInicio);
            inicioPartes = fila?.Inicio ?? copia.FechaInicio;
            var opciones = MYGMotorCronograma.Calcular(copia).Filas.Where(f => !f.Tarea.EsResumen && f.Tarea.Id != tarea.Id)
                .Select(f => new OpcionTarea { Id = f.Tarea.Id, Numero = f.Numero.ToString(CultureInfo.CurrentCulture), Nombre = f.Tarea.Nombre }).ToList();
            ((DataGridViewComboBoxColumn)dependencias.Columns["TAREA_ID"]).DataSource = opciones;
            foreach (var d in tarea.Predecesoras)
            {
                int indice = dependencias.Rows.Add(d.PredecesoraId, "", TextoTipo(d.Tipo), d.DesfaseDias);
                ActualizarNombreDependencia(dependencias.Rows[indice]);
            }
            if (tarea.Partes?.Count > 0) MostrarPartes(tarea.Partes);
            else if (MYGMotorCronograma.ConservaFechasDelphin(tarea) && tarea.FechasImportadasDelphin.Tramos.Count > 0)
                MostrarTramosImportados(tarea.FechasImportadasDelphin.Tramos);
            else MostrarPartes(ParteUnica(tarea.DuracionDias));
            dividirNumero.Value = Math.Clamp(partes.Rows.Count > 1 ? partes.Rows.Count : 2, 1, 1000);
            dividirIntervalo.Value = 0;
            ActualizarCuadrillas();
            ActualizarPermisos();
            if (tarea.EsResumen) mensaje.Text = "Resumen: las fechas y el avance se calculan a partir de sus tareas.";
            else if (!puedeEditar()) mensaje.Text = "Consulta: inicie una sesión con permiso de edición para modificar la tarea.";
            else if (mostrandoTramosImportados) mensaje.Text = "Tramos originales de Delphin. Consultar o editar notas conserva sus fechas y su distribución.";
            firmaControles = FirmaControles();
        }
        finally { cargando = false; }
    }

    private void LeerPartida()
    {
        var proyecto = obtenerProyecto();
        var presupuesto = proyecto?.Presupuestos?.FirstOrDefault(p => p.Id == tarea.PresupuestoId);
        var partida = presupuesto?.Items?.FirstOrDefault(i => i.Id == tarea.PartidaId);
        if (partida == null) return;
        unidad = partida.Unidad ?? "";
        try { cantidadTotal = MYGMotorPresupuestos.Cantidad(presupuesto, partida); }
        catch (Exception ex) { mensaje.Text = "No se pudo obtener el metrado de la partida: " + ex.Message; }
    }

    private void SincronizarDuracion(NumericUpDown origen)
    {
        if (cargando || tarea == null) return;
        bool cambio = duracion.Value != origen.Value || nuevaDuracion.Value != origen.Value;
        cargando = true;
        try { duracion.Value = nuevaDuracion.Value = origen.Value; }
        finally { cargando = false; }
        if (cambio)
        {
            MostrarPartes(ParteUnica(decimal.ToInt32(duracion.Value)));
            partesModificadas = true;
        }
        ActualizarCuadrillas();
    }

    private void ActualizarCuadrillas()
    {
        if (tarea == null) return;
        decimal dias = nuevaDuracion.Value;
        int diasIniciales = tarea.DuracionInicialDias ?? tarea.DuracionDias;
        decimal numero = !reprogramar.Checked || dias == 0 || diasIniciales == 0 ? cuadrillasIniciales.Value :
            cuadrillasIniciales.Value * diasIniciales / dias;
        cuadrillasActuales.Text = numero.ToString("0.####", CultureInfo.CurrentCulture);
        duracionPartes.Text = "Duración de tarea: " + duracion.Value.ToString("0", CultureInfo.CurrentCulture) + " días";
    }

    private void ActualizarPermisos()
    {
        bool editar = Editable;
        foreach (var control in editores) control.Enabled = editar;
        foreach (var boton in botones) boton.Enabled = editar;
        dependencias.ReadOnly = partes.ReadOnly = !editar;
        dependencias.Columns["NOMBRE"].ReadOnly = true;
        partes.Columns["FIN"].ReadOnly = true;
        nuevaDuracion.Enabled = editar && reprogramar.Checked;
        fechaRestriccion.Enabled = editar && restriccion.SelectedIndex >= 2;
        inicio.Enabled = editar && modo.SelectedIndex == 1;
        foreach (var boton in botones.Where(b => b.Name == Prefijo + "dividir_aplicar")) boton.Enabled = editar && duracion.Value > 0;
        dividirNumero.Enabled = dividirIntervalo.Enabled = editar && duracion.Value > 0;
    }

    private void AgregarDependencia()
    {
        if (!Editable) return;
        FinalizarEdicion();
        var usadas = dependencias.Rows.Cast<DataGridViewRow>().Select(r => Convert.ToString(r.Cells["TAREA_ID"].Value)).ToHashSet(StringComparer.Ordinal);
        var opciones = (IEnumerable<OpcionTarea>)((DataGridViewComboBoxColumn)dependencias.Columns["TAREA_ID"]).DataSource;
        var opcion = opciones.FirstOrDefault(o => !usadas.Contains(o.Id));
        if (opcion == null) { mensaje.Text = "No hay más tareas disponibles como predecesoras."; return; }
        int indice = dependencias.Rows.Add(opcion.Id, opcion.Nombre, TextoTipo(MYGTipoVinculo.FC), 0);
        dependencias.CurrentCell = dependencias.Rows[indice].Cells["TAREA_ID"];
    }

    private void EliminarDependencia()
    {
        if (!Editable || dependencias.CurrentRow == null) return;
        dependencias.Rows.Remove(dependencias.CurrentRow);
    }

    private void ElegirDependencia()
    {
        if (!Editable) return;
        FinalizarEdicion();
        var registro = dependencias.CurrentRow;
        string actualId = Convert.ToString(registro?.Cells["TAREA_ID"].Value);
        var usadas = dependencias.Rows.Cast<DataGridViewRow>().Where(r => r != registro)
            .Select(r => Convert.ToString(r.Cells["TAREA_ID"].Value)).ToHashSet(StringComparer.Ordinal);
        var opciones = MYGMotorCronograma.Calcular(copia).Filas
            .Where(f => !f.Tarea.EsResumen && f.Tarea.Id != tarea.Id && !usadas.Contains(f.Tarea.Id)).ToList();
        if (opciones.Count == 0) { mensaje.Text = "No hay tareas disponibles como predecesoras."; return; }
        using var dialogo = new Form();
        MYGCronogramaDialogoUI.Preparar(dialogo, Prefijo + "dependencia_selector", "Elegir tarea predecesora", new Size(780, 470), true);
        dialogo.MinimumSize = new Size(510, 320);
        var buscar = new TextBox
        {
            Name = Prefijo + "dependencia_selector_buscar", Dock = DockStyle.Fill,
            PlaceholderText = "Buscar por nombre, código o número…", AccessibleName = "Buscar tarea predecesora"
        };
        var cabeceraSelector = new Panel { Dock = DockStyle.Top, Height = 42, Padding = new Padding(8) };
        cabeceraSelector.Controls.Add(buscar);
        var tablaSelector = Tabla("dependencia_selector_tabla");
        tablaSelector.ReadOnly = true;
        tablaSelector.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        tablaSelector.AccessibleName = "Tareas disponibles como predecesoras, con su nivel jerárquico";
        tablaSelector.Columns.Add(new DataGridViewTextBoxColumn { Name = "NUMERO", HeaderText = "Id", Width = 55 });
        tablaSelector.Columns.Add(new DataGridViewTextBoxColumn { Name = "CODIGO", HeaderText = "Código", Width = 135 });
        tablaSelector.Columns.Add(new DataGridViewTextBoxColumn { Name = "NOMBRE", HeaderText = "Tarea", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, MinimumWidth = 200 });
        var acciones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 44, Padding = new Padding(7), FlowDirection = FlowDirection.RightToLeft };
        var aceptar = new Button { Name = Prefijo + "dependencia_selector_aceptar", Text = "Elegir tarea", AutoSize = true, MinimumSize = new Size(100, 28) };
        var cancelar = new Button { Name = Prefijo + "dependencia_selector_cancelar", Text = "Cancelar", AutoSize = true, MinimumSize = new Size(85, 28), DialogResult = DialogResult.Cancel };
        acciones.Controls.Add(cancelar);
        acciones.Controls.Add(aceptar);
        var estadoSelector = new Label { Name = Prefijo + "dependencia_selector_estado", Dock = DockStyle.Bottom, Height = 27, Padding = new Padding(8, 3, 8, 3) };
        dialogo.Controls.Add(tablaSelector);
        dialogo.Controls.Add(cabeceraSelector);
        dialogo.Controls.Add(estadoSelector);
        dialogo.Controls.Add(acciones);
        dialogo.AcceptButton = aceptar;
        dialogo.CancelButton = cancelar;
        MYGResultadoTarea seleccionada = null;
        void Seleccionar()
        {
            if (tablaSelector.CurrentRow?.Tag is not MYGResultadoTarea candidata) return;
            seleccionada = candidata;
            dialogo.DialogResult = DialogResult.OK;
        }
        void Filtrar()
        {
            string idElegido = (tablaSelector.CurrentRow?.Tag as MYGResultadoTarea)?.Tarea.Id ?? actualId;
            string filtro = buscar.Text.Trim();
            tablaSelector.Rows.Clear();
            DataGridViewRow conservar = null;
            foreach (var opcion in opciones.Where(f => filtro.Length == 0 ||
                (f.Tarea.Nombre ?? "").Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                (f.Tarea.Codigo ?? "").Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                f.Numero.ToString(CultureInfo.CurrentCulture).Contains(filtro, StringComparison.OrdinalIgnoreCase)))
            {
                int indice = tablaSelector.Rows.Add(opcion.Numero, opcion.Tarea.Codigo ?? "", opcion.Tarea.Nombre);
                var filaSelector = tablaSelector.Rows[indice];
                filaSelector.Tag = opcion;
                filaSelector.Cells["NOMBRE"].Style.Padding = new Padding(Math.Min(opcion.Nivel, 12) * 14, 0, 0, 0);
                if (opcion.Tarea.Id == idElegido) conservar = filaSelector;
            }
            if (conservar != null) tablaSelector.CurrentCell = conservar.Cells["NOMBRE"];
            aceptar.Enabled = tablaSelector.CurrentRow != null;
            estadoSelector.Text = tablaSelector.Rows.Count + " tareas disponibles. Se excluyen resúmenes, la tarea actual y predecesoras ya elegidas.";
        }
        buscar.TextChanged += (_, _) => Filtrar();
        tablaSelector.SelectionChanged += (_, _) => aceptar.Enabled = tablaSelector.CurrentRow != null;
        tablaSelector.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) Seleccionar(); };
        aceptar.Click += (_, _) => Seleccionar();
        dialogo.Shown += (_, _) => buscar.Focus();
        Filtrar();
        MYGCronogramaDialogoUI.Tema(dialogo);
        MYG2027_TemaComercial.EstilizarTabla(tablaSelector, 27);
        if (dialogo.ShowDialog(FindForm()) != DialogResult.OK || seleccionada == null || !Editable) return;
        if (registro == null)
        {
            int indice = dependencias.Rows.Add(seleccionada.Tarea.Id, seleccionada.Tarea.Nombre, TextoTipo(MYGTipoVinculo.FC), 0);
            dependencias.CurrentCell = dependencias.Rows[indice].Cells["NOMBRE"];
        }
        else registro.Cells["TAREA_ID"].Value = seleccionada.Tarea.Id;
    }

    private void ActualizarNombreDependencia(DataGridViewRow registro)
    {
        string id = Convert.ToString(registro.Cells["TAREA_ID"].Value);
        registro.Cells["NOMBRE"].Value = copia?.Tareas?.FirstOrDefault(t => t.Id == id)?.Nombre ?? "Tarea no disponible";
    }

    private void Dividir()
    {
        if (!Editable) return;
        FinalizarEdicion();
        if (mostrandoTramosImportados) ValidarConversionImportada(LeerPartes());
        var propuesta = Propuesta(false);
        decimal cantidad = cantidadTotal ?? LeerPartes().Sum(p => p.Cantidad);
        MYGInformacionTarea.Dividir(propuesta, decimal.ToInt32(dividirNumero.Value), decimal.ToInt32(dividirIntervalo.Value), cantidad);
        MostrarPartes(propuesta.Partes);
        partesModificadas = true;
        mensaje.ForeColor = MYG2027_TemaComercial.Texto;
        mensaje.Text = "División preparada. Pulse Guardar cambios para incorporarla al cronograma.";
    }

    private List<MYGParteTarea> ParteUnica(int dias) => new()
    {
        new MYGParteTarea { DesfaseInicioDias = 0, DuracionDias = dias,
            Cantidad = cantidadTotal ?? (tarea?.Partes?.Count > 0 ? tarea.Partes.Sum(p => p.Cantidad) :
                tarea?.FechasImportadasDelphin?.Tramos?.Sum(p => p.Cantidad) ?? 0), Porcentaje = 100 }
    };

    private void MostrarTramosImportados(IEnumerable<MYGTramoImportadoDelphin> tramos)
    {
        bool anterior = cargando;
        cargando = true;
        try
        {
            partes.Rows.Clear();
            mostrandoTramosImportados = true;
            foreach (var tramo in tramos)
                partes.Rows.Add(tramo.Inicio, tramo.Duracion, tramo.Fin, tramo.Cantidad, tramo.Porcentaje);
            ActualizarTotales();
        }
        finally { cargando = anterior; }
    }

    private void MostrarPartes(IEnumerable<MYGParteTarea> lista)
    {
        bool anterior = cargando;
        cargando = true;
        try
        {
            partes.Rows.Clear();
            mostrandoTramosImportados = false;
            foreach (var parte in lista)
            {
                DateTime desde = copia.Calendario.SumarDiasLaborables(inicioPartes, parte.DesfaseInicioDias);
                DateTime hasta = parte.DuracionDias == 0 ? desde : copia.Calendario.SumarDiasLaborables(desde, parte.DuracionDias - 1);
                int indice = partes.Rows.Add(desde, parte.DuracionDias, hasta, parte.Cantidad, parte.Porcentaje);
                partes.Rows[indice].Tag = parte.DesfaseInicioDias;
            }
            ActualizarTotales();
        }
        finally { cargando = anterior; }
    }

    private List<MYGParteTarea> LeerPartesSinFechas() => partes.Rows.Cast<DataGridViewRow>().Select(r => new MYGParteTarea
    {
        DesfaseInicioDias = r.Tag is int desfase ? desfase : 0,
        DuracionDias = DiasParte(r.Cells["DURACION"].Value),
        Cantidad = Decimal(r.Cells["CANTIDAD"].Value, "Cantidad"),
        Porcentaje = Decimal(r.Cells["PORCENTAJE"].Value, "% valorizado")
    }).ToList();

    private List<MYGParteTarea> LeerPartes()
    {
        var lista = new List<MYGParteTarea>();
        foreach (DataGridViewRow registro in partes.Rows)
        {
            DateTime desde = Fecha(registro.Cells["INICIO"].Value);
            if (!copia.Calendario.EsLaborable(desde)) throw new InvalidDataException("El inicio de cada parte debe ser un día laborable.");
            if (desde < copia.Calendario.SiguienteLaborable(inicioPartes)) throw new InvalidDataException("Las partes no pueden comenzar antes de la tarea.");
            int desfase = copia.Calendario.ContarDiasLaborables(inicioPartes, desde) - 1;
            int dias = DiasParte(registro.Cells["DURACION"].Value);
            if (mostrandoTramosImportados && Fecha(registro.Cells["FIN"].Value) !=
                (dias == 0 ? desde : copia.Calendario.SumarDiasLaborables(desde, dias - 1)))
                throw new InvalidDataException("Las fechas de los tramos importados no coinciden con jornadas enteras del calendario actual. Consérvelos sin editar o prepare una nueva planificación.");
            lista.Add(new MYGParteTarea { DesfaseInicioDias = desfase, DuracionDias = dias,
                Cantidad = Decimal(registro.Cells["CANTIDAD"].Value, "Cantidad"), Porcentaje = Decimal(registro.Cells["PORCENTAJE"].Value, "% valorizado") });
        }
        return lista;
    }

    private int DiasParte(object valor)
    {
        decimal dias = Decimal(valor, "Duración");
        if (dias != decimal.Truncate(dias))
            throw new InvalidDataException(mostrandoTramosImportados
                ? "Los tramos importados tienen duración fraccionaria. Se conservan en la consulta; para convertirlos en partes MYG debe indicar duraciones en jornadas enteras."
                : "La duración de una parte debe expresarse en jornadas enteras.");
        if (dias < 0 || dias > 36500)
            throw new InvalidDataException("La duración de una parte debe estar entre 0 y 36.500 días.");
        return decimal.ToInt32(dias);
    }

    private void ValidarConversionImportada(List<MYGParteTarea> lista)
    {
        var conversion = MYGProyectoStorage.Copia(tarea);
        conversion.DuracionDias = decimal.ToInt32(duracion.Value);
        conversion.FechasImportadasDelphin = null;
        conversion.Partes = lista.OrderBy(p => p.DesfaseInicioDias).ToList();
        try { MYGInformacionTarea.Validar(conversion); }
        catch (InvalidDataException ex)
        {
            throw new InvalidDataException("No se pueden convertir los tramos importados en partes MYG sin cambiar su programación. " + ex.Message, ex);
        }
    }

    private void ActualizarFinParte(DataGridViewRow registro)
    {
        DateTime desde = Fecha(registro.Cells["INICIO"].Value);
        int dias = DiasParte(registro.Cells["DURACION"].Value);
        if (dias < 0 || dias > 36500) throw new InvalidDataException("La duración de una parte debe estar entre 0 y 36.500 días.");
        if (!copia.Calendario.EsLaborable(desde)) throw new InvalidDataException("El inicio de una parte debe ser un día laborable.");
        registro.Cells["FIN"].Value = dias == 0 ? desde : copia.Calendario.SumarDiasLaborables(desde, dias - 1);
        registro.Tag = copia.Calendario.ContarDiasLaborables(inicioPartes, desde) - 1;
    }

    private void ActualizarTotales()
    {
        decimal dias = 0, cantidad = 0, porcentaje = 0;
        foreach (DataGridViewRow registro in partes.Rows)
        {
            dias += Decimal(registro.Cells["DURACION"].Value, "Duración");
            cantidad += Decimal(registro.Cells["CANTIDAD"].Value, "Cantidad");
            porcentaje += Decimal(registro.Cells["PORCENTAJE"].Value, "% valorizado");
        }
        totales.Text = "Total programado (partes):  " + dias.ToString("0.######", CultureInfo.CurrentCulture) + " días    " +
            cantidad.ToString("0.####", CultureInfo.CurrentCulture) + " " + unidad + "    " + porcentaje.ToString("0.###", CultureInfo.CurrentCulture) + " %";
    }

    internal void FinalizarEdicion()
    {
        if (cargando || aplicando) return;
        if (!dependencias.EndEdit() || !partes.EndEdit()) throw new InvalidDataException("Corrija la celda que está editando antes de continuar.");
    }

    internal bool ConfirmarSalida()
    {
        if (aplicando || cargando || !TieneCambios) return true;
        var respuesta = MessageBox.Show(FindForm(),
            "Hay cambios pendientes en la información de la tarea.\n\nSí: guardar los cambios.\nNo: descartarlos.\nCancelar: continuar editando.",
            "Información de la tarea", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
        if (respuesta == DialogResult.Cancel) return false;
        if (respuesta == DialogResult.No) { CargarCopia(seleccionId); return true; }
        if (!Editable) { MostrarError("Se requiere permiso de edición para guardar los cambios pendientes."); return false; }
        try { GuardarCambios(); return true; }
        catch (Exception ex) { MostrarError(ex.Message); return false; }
    }

    private MYGTareaCronograma Propuesta(bool incluirPartes)
    {
        var propuesta = MYGProyectoStorage.Copia(tarea);
        if (string.IsNullOrWhiteSpace(nombre.Text)) throw new InvalidDataException("Escriba el nombre de la tarea.");
        propuesta.Nombre = nombre.Text.Trim();
        propuesta.Modo = modo.SelectedIndex == 1 ? MYGModoTarea.Manual : MYGModoTarea.Automatica;
        propuesta.InicioManual = propuesta.Modo == MYGModoTarea.Manual ? inicio.Value.Date : tarea.InicioManual;
        propuesta.CuadrillasIniciales = cuadrillasIniciales.Value;
        int dias = decimal.ToInt32(duracion.Value);
        if (reprogramar.Checked)
        {
            if (!propuesta.DuracionInicialDias.HasValue) propuesta.NumeroCuadrillas = propuesta.CuadrillasIniciales;
            MYGInformacionTarea.Reprogramar(propuesta, dias);
        }
        else
        {
            propuesta.Reprogramada = false;
            propuesta.DuracionDias = dias;
            propuesta.NumeroCuadrillas = propuesta.CuadrillasIniciales;
            if (dias != tarea.DuracionDias) { propuesta.FechasImportadasDelphin = null; propuesta.Partes = new List<MYGParteTarea>(); }
        }
        propuesta.Avance = avance.Value;
        propuesta.Responsables = MYGCronogramaDialogoUI.LeerNombres(responsables.Text);
        propuesta.Notas = notas.Text.Trim();
        propuesta.TipoRestriccion = (MYGTipoRestriccion)Math.Max(0, restriccion.SelectedIndex);
        propuesta.FechaRestriccion = restriccion.SelectedIndex >= 2 ? fechaRestriccion.Value.Date : null;
        propuesta.Predecesoras = dependencias.Rows.Cast<DataGridViewRow>().Select(r => new MYGDependenciaCronograma
        {
            PredecesoraId = Convert.ToString(r.Cells["TAREA_ID"].Value),
            Tipo = LeerTipo(Convert.ToString(r.Cells["TIPO"].Value)),
            DesfaseDias = Entero(r.Cells["DESFASE"].Value, "Desfase")
        }).ToList();
        if (incluirPartes && (partesModificadas || tarea.Partes?.Count > 0))
        {
            if (dias == 0)
            {
                if (mostrandoTramosImportados) throw new InvalidDataException("Los tramos importados de un hito se conservan para consulta; un hito no admite partes de trabajo.");
                propuesta.Partes = new List<MYGParteTarea>(); return propuesta;
            }
            var lista = LeerPartes();
            if (mostrandoTramosImportados) ValidarConversionImportada(lista);
            if (lista.Count == 0) throw new InvalidDataException("Debe existir al menos una parte.");
            if (lista.Any(p => p.DuracionDias <= 0 || p.Cantidad < 0 || p.Porcentaje < 0 || p.Porcentaje > 100))
                throw new InvalidDataException("Las partes requieren duración, cantidad y porcentaje válidos.");
            if (lista.Sum(p => p.DuracionDias) != dias) throw new InvalidDataException("La suma de las duraciones de las partes debe coincidir con la duración de la tarea.");
            if (lista.Sum(p => p.Porcentaje) != 100m) throw new InvalidDataException("El porcentaje valorizado de las partes debe sumar exactamente 100 %.");
            if (cantidadTotal.HasValue && Math.Abs(lista.Sum(p => p.Cantidad) - cantidadTotal.Value) > .0001m)
                throw new InvalidDataException("La suma de las cantidades debe coincidir con el metrado de la partida.");
            var ordenadas = lista.OrderBy(p => p.DesfaseInicioDias).ToList();
            if (ordenadas[0].DesfaseInicioDias != 0) throw new InvalidDataException("La primera parte debe comenzar al inicio de la tarea.");
            for (int indice = 1; indice < ordenadas.Count; indice++)
                if (ordenadas[indice].DesfaseInicioDias < ordenadas[indice - 1].DesfaseInicioDias + ordenadas[indice - 1].DuracionDias)
                    throw new InvalidDataException("Las partes de la tarea no pueden solaparse.");
            propuesta.Partes = ordenadas;
            propuesta.FechasImportadasDelphin = null;
        }
        return propuesta;
    }

    internal void GuardarCambios()
    {
        if (!Editable) return;
        FinalizarEdicion();
        if (!TieneCambios) { mensaje.Text = "No hay cambios pendientes."; return; }
        var actual = obtener();
        var original = actual?.Tareas?.FirstOrDefault(t => t.Id == seleccionId);
        if (original == null || Firma(original) != firmaOriginal)
            throw new InvalidOperationException("La tarea cambió desde que abrió su información. Cancele los cambios para cargar la versión actual.");
        var propuesta = Propuesta(true);
        var plan = MYGProyectoStorage.Copia(actual);
        plan.Tareas[plan.Tareas.FindIndex(t => t.Id == seleccionId)] = propuesta;
        MYGMotorCronograma.Calcular(plan);
        aplicando = true;
        try { aplicar(plan); }
        finally { aplicando = false; }
        CargarCopia(seleccionId);
        mensaje.ForeColor = MYG2027_TemaComercial.Texto;
        mensaje.Text = "Información de la tarea guardada.";
    }

    private string FirmaControles()
    {
        var valores = new object[] { nombre.Text, modo.SelectedIndex, inicio.Value.Date, duracion.Value, avance.Value,
            responsables.Text, notas.Text, cuadrillasIniciales.Value, reprogramar.Checked, nuevaDuracion.Value,
            restriccion.SelectedIndex, fechaRestriccion.Value.Date,
            dependencias.Rows.Cast<DataGridViewRow>().Select(r => r.Cells.Cast<DataGridViewCell>().Select(c => Convert.ToString(c.Value)).ToArray()).ToArray(),
            partes.Rows.Cast<DataGridViewRow>().Select(r => r.Cells.Cast<DataGridViewCell>().Select(c => Convert.ToString(c.Value)).ToArray()).ToArray() };
        return JsonSerializer.Serialize(valores);
    }

    internal void AplicarTema()
    {
        MYG2027_TemaComercial.Aplicar(this);
        MYG2027_TemaComercial.EstilizarTabla(dependencias, 25);
        MYG2027_TemaComercial.EstilizarTabla(partes, 25);
        foreach (var boton in botones) MYG2027_TemaComercial.EstilizarBoton(boton, boton.Name == Prefijo + "guardar" ? 1 : 0);
    }

    private void CambioTema(object sender, EventArgs e) => AplicarTema();
    private void Intentar(Action accion) { if (cargando) return; try { accion(); } catch (Exception ex) { MostrarError(ex.Message); } }
    private void MostrarError(string texto) { mensaje.ForeColor = MYG2027_TemaComercial.Oscuro ? Color.Salmon : Color.Firebrick; mensaje.Text = texto; }
    private Button Boton(string texto, string id, Action accion)
    {
        var boton = new Button { Name = Prefijo + id, Text = texto, AutoSize = true, MinimumSize = new Size(60, 27), Margin = new Padding(3, 0, 3, 0) };
        boton.Click += (_, _) => Intentar(accion);
        botones.Add(boton);
        return boton;
    }
    private static DataGridView Tabla(string id) => new()
    {
        Name = Prefijo + id, Dock = DockStyle.Fill, AutoGenerateColumns = false, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, AllowUserToResizeRows = false, RowHeadersVisible = false, MultiSelect = false,
        SelectionMode = DataGridViewSelectionMode.CellSelect, EditMode = DataGridViewEditMode.EditOnEnter
    };
    private static Label Etiqueta(string id) => new() { Name = Prefijo + id, AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 5, 0, 0) };
    private static Label Titulo(string texto) => new() { Text = texto, Dock = DockStyle.Top, Height = 26, Padding = new Padding(3, 4, 3, 0) };
    private static ComboBox Selector(string id) => new() { Name = Prefijo + id, DropDownStyle = ComboBoxStyle.DropDownList, DropDownWidth = 270 };
    private static NumericUpDown Numero(string id, decimal minimo, decimal maximo, int decimales = 0) => new()
    { Name = Prefijo + id, Minimum = minimo, Maximum = maximo, Value = minimo, DecimalPlaces = decimales, ThousandsSeparator = true };
    private static TableLayoutPanel Campos()
    {
        var tabla = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Padding = new Padding(2), Margin = Padding.Empty };
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 53));
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 47));
        return tabla;
    }
    private static void Campo(TableLayoutPanel tabla, string texto, Control control, int alto = 31)
    {
        int indice = tabla.RowCount++;
        tabla.RowStyles.Add(new RowStyle(SizeType.Absolute, alto));
        tabla.Controls.Add(new Label { Text = texto, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, indice);
        control.Dock = DockStyle.Fill;
        tabla.Controls.Add(control, 1, indice);
    }
    private static void AsignarFecha(DateTimePicker control, DateTime fecha) => control.Value = fecha < control.MinDate ? control.MinDate : fecha > control.MaxDate ? control.MaxDate : fecha.Date;
    private static string Firma(MYGTareaCronograma valor) => JsonSerializer.Serialize(valor);
    private static int Entero(object valor, string campo)
    {
        if (!int.TryParse(Convert.ToString(valor, CultureInfo.CurrentCulture), NumberStyles.Integer, CultureInfo.CurrentCulture, out int numero))
            throw new InvalidDataException(campo + ": indique un número entero.");
        return numero;
    }
    private static decimal Decimal(object valor, string campo)
    {
        if (valor is decimal d) return d;
        if (!decimal.TryParse(Convert.ToString(valor, CultureInfo.CurrentCulture), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal numero))
            throw new InvalidDataException(campo + ": indique un número válido.");
        return numero;
    }
    private static DateTime Fecha(object valor)
    {
        if (valor is DateTime fecha) return fecha.Date;
        string texto = Convert.ToString(valor);
        if (!DateTime.TryParseExact(texto, new[] { "d/M/yyyy", "dd/MM/yyyy", "yyyy-MM-dd" }, CultureInfo.InvariantCulture,
            DateTimeStyles.None, out fecha) && !DateTime.TryParse(texto, CultureInfo.CurrentCulture, DateTimeStyles.None, out fecha))
            throw new InvalidDataException("Indique una fecha válida para el inicio de la parte (dd/MM/aaaa).");
        return fecha.Date;
    }
    private static string TextoTipo(MYGTipoVinculo tipo) => tipo switch
    {
        MYGTipoVinculo.FC => "FC (Final - Inicio)", MYGTipoVinculo.FF => "FF (Final - Final)",
        MYGTipoVinculo.CF => "CF (Inicio - Final)", MYGTipoVinculo.CC => "CC (Inicio - Inicio)", _ => throw new InvalidDataException("Tipo de vínculo no válido.")
    };
    private static MYGTipoVinculo LeerTipo(string texto) => texto switch
    {
        "FC (Final - Inicio)" => MYGTipoVinculo.FC, "FF (Final - Final)" => MYGTipoVinculo.FF,
        "CF (Inicio - Final)" => MYGTipoVinculo.CF, "CC (Inicio - Inicio)" => MYGTipoVinculo.CC,
        _ => throw new InvalidDataException("Seleccione un tipo de dependencia válido.")
    };
    private sealed class OpcionTarea
    {
        public string Id { get; set; }
        public string Numero { get; set; }
        public string Nombre { get; set; }
    }
}
