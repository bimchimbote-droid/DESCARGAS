using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Preferencias del cronograma guardadas con el proyecto, sin modificar sus fechas.</summary>
internal sealed class MYGOpcionesVistaCronograma
{
    public int ColorCriticaArgb { get; set; } = Color.Firebrick.ToArgb();
    public int ColorDependenciasCriticasArgb { get; set; } = Color.Firebrick.ToArgb();
    public bool ImprimirLeyenda { get; set; } = true;
    public bool ImprimirInformacionPagina { get; set; }
    public string TipoInformacionPagina { get; set; } = "Número del total";
    public string TituloPagina { get; set; } = "";
    public bool Horizontal { get; set; } = true;
    public string Papel { get; set; } = "A3";
    public DateTime? InicioImpresion { get; set; }
    public DateTime? FinImpresion { get; set; }
    public string AparienciaBarra { get; set; } = "Sólida";
    public int ColorAvanceArgb { get; set; } = Color.MediumVioletRed.ToArgb();
    public bool OcultarAvance { get; set; }
    public string TextoIzquierda { get; set; } = "Sin texto";
    public string TextoCentro { get; set; } = "Sin texto";
    public string TextoDerecha { get; set; } = "@Descripción";
    public string PosicionMensaje { get; set; } = "Parte superior derecha";
}

/// <summary>Panel de detalle con datos reales del ACU. El cálculo pesado se ejecuta fuera del hilo de interfaz.</summary>
internal sealed class MYGCronogramaDetallesControl : UserControl
{
    private readonly Func<MYGCronograma> obtener;
    private readonly Func<MYGProyectoDocumento> obtenerProyecto;
    private readonly Action<MYGCronograma> aplicar;
    private readonly Func<bool> puedeEditar;
    private readonly TabControl pestanas = new() { Name = "cronograma_detalle_pestanas", Dock = DockStyle.Fill };
    private readonly MYGInformacionTareaControl informacion;
    private readonly DataGridView recursos = Tabla("cronograma_recursos_programados");
    private readonly Label titulo = new() { Name = "cronograma_detalle_titulo", Dock = DockStyle.Top, Height = 27, AutoEllipsis = true, Padding = new Padding(7, 5, 3, 0) };
    private readonly Label estado = new() { Name = "cronograma_detalle_estado", Dock = DockStyle.Bottom, Height = 30, AutoEllipsis = true, Padding = new Padding(7, 5, 3, 0) };
    private readonly ComboBox escala = Lista("cronograma_recursos_escala", "Día", "Semana", "Mes");
    private readonly ComboBox contenido = Lista("cronograma_recursos_contenido", "Cantidad y valorizado", "Cantidad", "Valorizado", "Recurso x cuadrilla");
    private readonly ComboBox grupo = Lista("cronograma_recursos_grupo", "Todos los tipos");
    private readonly DateTimePicker desde = Fecha("cronograma_recursos_desde");
    private readonly DateTimePicker hasta = Fecha("cronograma_recursos_hasta");
    private readonly VistaGrafico bi;
    private readonly VistaGrafico curva;
    private readonly TabPage paginaInformacion;
    private readonly Button aplicarOpciones = new() { Name = "cronograma_opciones_aplicar", Text = "Aplicar opciones", AutoSize = true };
    private readonly Button imprimirRecursos = new() { Name = "cronograma_recursos_imprimir", Text = "Imprimir recursos…", AutoSize = true, Enabled = false };
    private readonly Label estadoOpciones = new() { Name = "cronograma_opciones_estado", AutoSize = true, MaximumSize = new Size(900, 0) };
    private readonly Dictionary<string, Control> controlesOpciones = new(StringComparer.Ordinal);
    private readonly System.Windows.Forms.Timer retardo = new() { Interval = 180 };
    private MYGOpcionesVistaCronograma opciones = new();
    private MYGModeloExportacionProject modelo;
    private MYGCronograma planModelo;
    private MYGProyectoDocumento proyectoModelo;
    private string tareaId, jsonOpciones, firmaCamposOpciones;
    private bool cargando, calculando, recalcular, aplicandoOpciones, confirmandoSalida;
    private int revision;
    private List<Periodo> periodos = new();
    private List<FilaRecurso> filas = new();
    internal event Action<MYGOpcionesVistaCronograma> OpcionesCambiadas;
    internal event Action CerrarSolicitado;
    internal MYGOpcionesVistaCronograma Opciones => opciones;
    internal bool TieneCambios => informacion.TieneCambios || OpcionesPendientes;
    private bool OpcionesPendientes => firmaCamposOpciones != null && firmaCamposOpciones != JsonSerializer.Serialize(LeerOpciones());
    internal string TareaIdActual => tareaId;

    internal MYGCronogramaDetallesControl(Func<MYGCronograma> obtener, Func<MYGProyectoDocumento> obtenerProyecto,
        Action<MYGCronograma> aplicar, Func<bool> puedeEditar)
    {
        this.obtener = obtener ?? throw new ArgumentNullException(nameof(obtener));
        this.obtenerProyecto = obtenerProyecto ?? throw new ArgumentNullException(nameof(obtenerProyecto));
        this.aplicar = aplicar ?? throw new ArgumentNullException(nameof(aplicar));
        this.puedeEditar = puedeEditar ?? throw new ArgumentNullException(nameof(puedeEditar));
        Name = "cronograma_detalles"; Dock = DockStyle.Fill; Height = 360;
        Font = new Font("Segoe UI", 9F); AutoScaleMode = AutoScaleMode.Font;
        informacion = new MYGInformacionTareaControl(obtener, obtenerProyecto, aplicar, puedeEditar) { Dock = DockStyle.Fill };
        var paginaRecursos = Pagina("Recursos programados", "recursos");
        var herramientas = Barra();
        herramientas.Controls.Add(imprimirRecursos);
        imprimirRecursos.Click += (_, _) =>
        {
            try { MYGReportesImpresion.Imprimir(FindForm(), "Recursos programados", CrearReporteRecursos()); }
            catch (Exception ex) { estado.Text = "No se pudo preparar la impresión: " + ex.Message; }
        };
        Campo(herramientas, "Mostrar", contenido); Campo(herramientas, "Período", escala); Campo(herramientas, "Tipo", grupo);
        Campo(herramientas, "Desde", desde); Campo(herramientas, "Hasta", hasta);
        paginaRecursos.Controls.Add(recursos); paginaRecursos.Controls.Add(herramientas);
        paginaInformacion = Pagina("Información de tarea", "informacion"); paginaInformacion.Controls.Add(informacion);
        void CambiarEscala(string unidad) { escala.SelectedItem = unidad; SolicitarCalculo(); }
        bi = new VistaGrafico(false, CambiarEscala); curva = new VistaGrafico(true, CambiarEscala);
        Pagina("Tableros de acción (BI)", "bi").Controls.Add(bi);
        Pagina("Curva S", "curva").Controls.Add(curva);
        Pagina("Opciones generales", "opciones").Controls.Add(CrearOpciones());
        var cabecera = new Panel { Dock = DockStyle.Top, Height = 28 };
        var cerrar = new Button { Name = "cronograma_detalles_ocultar", Text = "Ocultar ▲", Dock = DockStyle.Right, Width = 90 };
        cerrar.Click += (_, _) => CerrarSolicitado?.Invoke();
        titulo.Dock = DockStyle.Fill; cabecera.Controls.Add(titulo); cabecera.Controls.Add(cerrar);
        Controls.Add(pestanas); Controls.Add(cabecera); Controls.Add(estado);
        foreach (var control in new[] { escala, contenido, grupo }) control.SelectedIndexChanged += (_, _) => { if (!cargando) SolicitarCalculo(); };
        desde.ValueChanged += (_, _) => { if (!cargando) SolicitarCalculo(); };
        hasta.ValueChanged += (_, _) => { if (!cargando) SolicitarCalculo(); };
        pestanas.SelectedIndexChanged += (_, _) => { if (pestanas.SelectedIndex is 0 or 2 or 3) SolicitarCalculo(); };
        VisibleChanged += (_, _) => { if (Visible && pestanas.SelectedIndex is 0 or 2 or 3) SolicitarCalculo(); };
        retardo.Tick += async (_, _) => { retardo.Stop(); await CalcularAsync(); };
        aplicarOpciones.Click += (_, _) => GuardarOpciones();
        MYG2027_TemaComercial.CambioTema += CambioTema;
        Disposed += (_, _) => { revision++; retardo.Dispose(); MYG2027_TemaComercial.CambioTema -= CambioTema; Font.Dispose(); };
        AplicarTema();
    }

    internal void SeleccionarInformacion() => pestanas.SelectedTab = paginaInformacion;
    internal void FinalizarEdicion() => informacion.FinalizarEdicion();
    internal bool ConfirmarSalida(bool incluirOpciones = true)
    {
        if (confirmandoSalida || aplicandoOpciones) return true;
        confirmandoSalida = true;
        try
        {
            if (!informacion.ConfirmarSalida()) return false;
            if (!incluirOpciones || !OpcionesPendientes) return true;
            var respuesta = MessageBox.Show(FindForm(),
                "Hay opciones generales sin aplicar.\n\nSí: aplicar las opciones.\nNo: descartarlas.\nCancelar: continuar editando.",
                "Opciones del cronograma", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (respuesta == DialogResult.Cancel) return false;
            if (respuesta == DialogResult.No) { CargarCamposOpciones(obtener()); return true; }
            return GuardarOpciones(false);
        }
        finally { confirmandoSalida = false; }
    }

    internal void Cargar(string id)
    {
        if (id != tareaId && informacion.TieneCambios && !informacion.ConfirmarSalida()) return;
        var plan = obtener();
        if (plan == null) return;
        bool cambioTarea = tareaId != id;
        tareaId = id;
        informacion.Cargar(id);
        var tarea = plan.Tareas.FirstOrDefault(t => t.Id == id);
        titulo.Text = tarea == null ? "Seleccione una tarea para consultar su detalle." :
            (tarea.Codigo ?? "") + "  " + tarea.Nombre + (tarea.EsResumen ? "  · Incluye sus tareas descendientes" : "");
        CargarOpciones(plan);
        if (cambioTarea)
        {
            try
            {
                var resultado = MYGMotorCronograma.Calcular(plan);
                var fila = resultado.Filas.FirstOrDefault(t => t.Tarea.Id == id);
                cargando = true;
                desde.Value = LimitarFecha(fila?.Inicio ?? resultado.Inicio);
                hasta.Value = LimitarFecha(fila?.Fin ?? resultado.Fin);
                if ((hasta.Value - desde.Value).TotalDays > 180) escala.SelectedIndex = 2;
            }
            finally { cargando = false; }
        }
        modelo = null; planModelo = null; proyectoModelo = null; revision++;
        imprimirRecursos.Enabled = false;
        if (pestanas.SelectedIndex is 0 or 2 or 3) SolicitarCalculo();
    }

    private TabPage Pagina(string texto, string nombre)
    {
        var pagina = new TabPage(texto) { Name = "cronograma_detalle_" + nombre, Padding = new Padding(3) };
        pestanas.TabPages.Add(pagina); return pagina;
    }
    private static ComboBox Lista(string nombre, params string[] valores)
    {
        var lista = new ComboBox { Name = nombre, DropDownStyle = ComboBoxStyle.DropDownList, Width = 145 };
        lista.Items.AddRange(valores); if (valores.Length > 0) lista.SelectedIndex = 0; return lista;
    }
    private static DateTimePicker Fecha(string nombre) => new() { Name = nombre, Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy", Width = 112 };
    private static DateTime LimitarFecha(DateTime fecha) => fecha < DateTimePicker.MinimumDateTime ? DateTimePicker.MinimumDateTime : fecha > DateTimePicker.MaximumDateTime ? DateTimePicker.MaximumDateTime : fecha;
    private static FlowLayoutPanel Barra() => new() { Dock = DockStyle.Top, Height = 39, Padding = new Padding(3), WrapContents = false, AutoScroll = true };
    private static void Campo(FlowLayoutPanel barra, string texto, Control control)
    {
        barra.Controls.Add(new Label { Text = texto, AutoSize = true, Margin = new Padding(4, 6, 3, 0) }); barra.Controls.Add(control);
    }
    private static DataGridView Tabla(string nombre) => new()
    {
        Name = nombre, Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, AllowUserToResizeRows = false, AutoGenerateColumns = false,
        RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.CellSelect,
        ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
    };

    private void SolicitarCalculo()
    {
        if (IsDisposed || cargando || !Visible) return;
        imprimirRecursos.Enabled = false;
        recalcular = true; revision++; retardo.Stop(); retardo.Start();
    }

    private async Task CalcularAsync()
    {
        if (calculando || IsDisposed || !recalcular) return;
        if (string.IsNullOrWhiteSpace(tareaId)) { estado.Text = "Seleccione una tarea."; recursos.Rows.Clear(); bi.Vaciar(); curva.Vaciar(); return; }
        if (hasta.Value.Date < desde.Value.Date) { estado.Text = "La fecha Hasta debe ser igual o posterior a Desde."; return; }
        calculando = true; recalcular = false; int version = revision;
        estado.Text = "Calculando recursos del ACU y distribución por calendario…";
        try
        {
            var plan = planModelo ?? MYGProyectoStorage.Copia(obtener());
            var proyecto = proyectoModelo ?? MYGProyectoStorage.Copia(obtenerProyecto());
            var modeloAnterior = modelo;
            string id = tareaId;
            DateTime inicio = desde.Value.Date, fin = hasta.Value.Date;
            string unidad = Convert.ToString(escala.SelectedItem);
            var datos = await Task.Run(() =>
            {
                var instantanea = modeloAnterior ?? MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
                var resultado = CalcularRecursos(instantanea, plan, id, inicio, fin, unidad);
                CompletarCuadrillas(resultado, instantanea, plan, proyecto, id);
                return (Modelo: instantanea, Datos: resultado);
            });
            if (IsDisposed || version != revision) return;
            modelo = datos.Modelo; planModelo = plan; proyectoModelo = proyecto;
            periodos = datos.Datos.Periodos; filas = datos.Datos.Filas;
            cargando = true;
            string tipoAnterior = Convert.ToString(grupo.SelectedItem);
            grupo.Items.Clear(); grupo.Items.Add("Todos los tipos");
            grupo.Items.AddRange(filas.Select(f => f.Recurso.Grupo).Distinct().OrderBy(t => t).Cast<object>().ToArray());
            grupo.SelectedItem = grupo.Items.Contains(tipoAnterior) ? tipoAnterior : "Todos los tipos";
            cargando = false;
            MostrarRecursos(); bi.Cargar(periodos, filas, modelo.Moneda, unidad); curva.Cargar(periodos, filas, modelo.Moneda, unidad);
            imprimirRecursos.Enabled = recursos.RowCount > 0;
            estado.Text = filas.Count == 0 ? "La selección no tiene recursos vinculados a partidas con ACU. No se han generado cantidades ni costos ficticios." :
                filas.Count + " recursos · Distribución proporcional a horas laborables y porcentajes de partes; no representa un avance ejecutado. " + datos.Datos.Aviso;
            if (modelo.Advertencias.Count > 0) estado.Text += " · " + string.Join(" · ", modelo.Advertencias.Take(3));
            if (contenido.SelectedIndex == 3) estado.Text = "Recurso x cuadrilla: Nro. Rec. del ACU × cuadrillas de la tarea; máximo simultáneo en jornadas activas. Las celdas sin dotación verificable quedan vacías. " + datos.Datos.Aviso;
        }
        catch (Exception ex)
        {
            if (!IsDisposed && version == revision) { recursos.Rows.Clear(); bi.Vaciar(); curva.Vaciar(); estado.Text = "No se pudo calcular el detalle: " + ex.Message; }
        }
        finally
        {
            cargando = false; calculando = false;
            if (!IsDisposed && recalcular) { retardo.Stop(); retardo.Start(); }
        }
    }

    private void MostrarRecursos()
    {
        recursos.SuspendLayout();
        try
        {
            recursos.Rows.Clear(); recursos.Columns.Clear();
            void Columna(string nombre, string texto, int ancho, bool numero = false)
            {
                var c = new DataGridViewTextBoxColumn { Name = nombre, HeaderText = texto, Width = ancho, SortMode = DataGridViewColumnSortMode.NotSortable };
                if (numero) { c.DefaultCellStyle.Format = "N3"; c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; }
                recursos.Columns.Add(c);
            }
            Columna("TIPO", "Tipo", 125); Columna("DESCRIPCION", "Descripción", 265); Columna("UNIDAD", "Unidad", 65); Columna("PRECIO", "Precio unit.", 90, true);
            for (int i = 0; i < 4; i++) recursos.Columns[i].Frozen = true;
            bool cuadrillas = contenido.SelectedIndex == 3;
            bool cantidades = contenido.SelectedIndex != 2 && !cuadrillas, costos = contenido.SelectedIndex != 1 && !cuadrillas;
            for (int i = 0; i < periodos.Count; i++)
            {
                if (cantidades) Columna("CANTIDAD_" + i, periodos[i].Etiqueta + "\nCantidad", 102, true);
                if (costos) Columna("COSTO_" + i, periodos[i].Etiqueta + "\n" + (modelo?.Moneda ?? "Valorizado"), 102, true);
                if (cuadrillas) Columna("CUADRILLAS_" + i, periodos[i].Etiqueta + "\nRecursos (máx.)", 110, true);
            }
            if (cuadrillas) Columna("CUADRILLA_MAXIMA", "Máximo simultáneo", 130, true);
            else { Columna("TOTAL_CANTIDAD", "Cantidad total", 105, true); Columna("TOTAL_COSTO", "Valorizado total", 115, true); }
            foreach (var fila in filas.Where(f => grupo.SelectedIndex <= 0 || f.Recurso.Grupo == Convert.ToString(grupo.SelectedItem)))
            {
                var valores = new List<object> { fila.Recurso.Grupo, fila.Recurso.Nombre, fila.Recurso.Unidad, fila.Recurso.Tarifa };
                for (int i = 0; i < periodos.Count; i++)
                { if (cantidades) valores.Add(fila.Cantidades[i]); if (costos) valores.Add(fila.Costos[i]); if (cuadrillas) valores.Add(fila.Cuadrillas?[i]); }
                if (cuadrillas) valores.Add(fila.CuadrillaMaxima);
                else { valores.Add(fila.CantidadTotal); valores.Add(fila.CostoTotal); }
                int indice = recursos.Rows.Add(valores.ToArray());
                if (cuadrillas)
                    foreach (DataGridViewCell celda in recursos.Rows[indice].Cells) celda.ToolTipText = fila.AvisoCuadrilla;
                else
                {
                    recursos.Rows[indice].Cells["TOTAL_CANTIDAD"].ToolTipText = "Cantidad completa de la tarea, incluidos períodos fuera del rango visible.";
                    recursos.Rows[indice].Cells["TOTAL_COSTO"].ToolTipText = "Valorizado completo de la tarea, incluidos períodos fuera del rango visible.";
                }
            }
            recursos.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;
            recursos.ColumnHeadersHeight = 44;
        }
        finally { recursos.ResumeLayout(); }
    }

    internal IReadOnlyList<MYGHojaReporteProyecto> CrearReporteRecursos()
    {
        if (recursos.RowCount == 0 || recursos.ColumnCount == 0 || calculando || recalcular)
            throw new InvalidOperationException("Espere al cálculo y seleccione recursos para imprimir.");
        var columnas = recursos.Columns.Cast<DataGridViewColumn>().Where(c => c.Visible).OrderBy(c => c.DisplayIndex).ToArray();
        var registros = recursos.Rows.Cast<DataGridViewRow>().Where(r => r.Visible).ToArray();
        if (registros.Length == 0) throw new InvalidOperationException("El filtro actual no tiene recursos para imprimir.");
        var reportes = new List<MYGHojaReporteProyecto>();
        // La hoja admite 200 columnas/200.000 celdas. Las bandas repiten la
        // identidad del recurso y conservan todos los períodos de la vista.
        var identidad = columnas.Take(4).ToArray();
        var periodicas = columnas.Skip(4).ToArray();
        foreach (var banda in periodicas.Chunk(176))
        {
            var elegidas = identidad.Concat(banda).ToArray();
            int maximoFilas = Math.Min(9999, 199000 / elegidas.Length - 1);
            foreach (var bloque in registros.Chunk(maximoFilas))
            {
                var hoja = new MYGHojaMetrado
                {
                    Nombre = "Recursos " + (reportes.Count + 1), Filas = bloque.Length + 1, Columnas = elegidas.Length,
                    CeldaTotal = "A1", FilasInmovilizadas = 1, ColumnasInmovilizadas = 4, RepetirTitulos = true,
                    TamanoPapel = opciones.Papel, OrientacionPagina = opciones.Horizontal ? "Horizontal" : "Vertical",
                    ImprimirLineasDivision = true, AreaImpresion = "A1:" + MYGHojaCalculo.Columna(elegidas.Length) + (bloque.Length + 1)
                };
                for (int c = 0; c < elegidas.Length; c++)
                {
                    string direccion = MYGHojaCalculo.Columna(c + 1) + "1";
                    hoja.Poner(direccion, "'" + elegidas[c].HeaderText, true);
                    hoja.Celdas[direccion].ColorFondo = "D5E2F2"; hoja.Celdas[direccion].AjustarTexto = true;
                    hoja.AnchosColumnas[c + 1] = Math.Clamp(elegidas[c].Width, 65, 280);
                    for (int f = 0; f < bloque.Length; f++)
                    {
                        string celda = MYGHojaCalculo.Columna(c + 1) + (f + 2);
                        // Se congela el texto mostrado; un nombre que comienza
                        // con '=' o una cantidad formateada nunca se evalúa.
                        hoja.Poner(celda, "'" + Convert.ToString(bloque[f].Cells[elegidas[c].Index].FormattedValue));
                        hoja.Celdas[celda].AlineacionHorizontal = c >= 3 ? "Derecha" : "Izquierda";
                        hoja.Celdas[celda].AjustarTexto = c == 1;
                    }
                }
                hoja.AltosFilas[1] = 42;
                MYGHojaCalculo.Validar(hoja);
                reportes.Add(new MYGHojaReporteProyecto("RECURSOS PROGRAMADOS", hoja, new KeyValuePair<string, string>[]
                {
                    new("Selección", titulo.Text), new("Mostrar", Convert.ToString(contenido.SelectedItem)),
                    new("Tipo", Convert.ToString(grupo.SelectedItem)), new("Rango", desde.Value.ToString("dd/MM/yyyy") + " – " + hasta.Value.ToString("dd/MM/yyyy")),
                    new("Detalle", contenido.SelectedIndex == 3 ? "Dotación ACU × cuadrillas; máximo simultáneo. Celdas vacías: dotación no verificable." : "Períodos del rango visible; totales completos de la selección.")
                }));
            }
        }
        return reportes.AsReadOnly();
    }

    internal sealed record Periodo(DateTime Inicio, DateTime Fin, string Etiqueta);
    internal sealed class FilaRecurso
    {
        internal MYGRecursoExportacionProject Recurso;
        internal decimal CantidadTotal, CostoTotal;
        internal decimal[] Cantidades, Costos;
        internal decimal?[] Cuadrillas;
        internal decimal? CuadrillaMaxima;
        internal string AvisoCuadrilla;
    }
    private sealed record DatosRecursos(List<Periodo> Periodos, List<FilaRecurso> Filas, string Aviso);
    private sealed record Tramo(DateTime Inicio, DateTime Fin, decimal Peso);

    private static DatosRecursos CalcularRecursos(MYGModeloExportacionProject modelo, MYGCronograma plan, string id,
        DateTime desde, DateTime hasta, string escala)
    {
        var seleccion = modelo.Tareas.FirstOrDefault(t => t.IdMYG == id);
        if (seleccion == null) return new(new(), new(), "");
        var ids = new HashSet<int> { seleccion.Uid };
        foreach (var tarea in modelo.Tareas) if (ids.Contains(tarea.PadreUid)) ids.Add(tarea.Uid);
        var asignaciones = modelo.Asignaciones.Where(a => ids.Contains(a.TareaUid)).ToArray();
        var periodos = new List<Periodo>();
        DateTime inicio = escala == "Mes" ? new DateTime(desde.Year, desde.Month, 1) : escala == "Semana" ? desde.AddDays(-((7 + (int)desde.DayOfWeek - (int)DayOfWeek.Monday) % 7)) : desde;
        while (inicio <= hasta && periodos.Count < 180)
        {
            DateTime siguiente = escala == "Mes" ? inicio.AddMonths(1) : inicio.AddDays(escala == "Semana" ? 7 : 1);
            DateTime fin = siguiente.AddDays(-1);
            periodos.Add(new(inicio < desde ? desde : inicio, fin > hasta ? hasta : fin,
                escala == "Mes" ? inicio.ToString("MMM yyyy", CultureInfo.GetCultureInfo("es-PE")) : inicio.ToString("dd/MM/yy")));
            inicio = siguiente;
        }
        string aviso = inicio <= hasta ? "Se muestran los primeros 180 períodos; ajuste Desde/Hasta o cambie la escala. Los totales incluyen toda la selección." :
            "Los totales incluyen toda la selección; el rango sólo limita las columnas y los gráficos.";
        var tareas = modelo.Tareas.ToDictionary(t => t.Uid);
        var origenes = plan.Tareas.ToDictionary(t => t.Id);
        var recursos = modelo.Recursos.ToDictionary(r => r.Uid);
        var pesos = new Dictionary<int, decimal[]>();
        var salida = new Dictionary<int, FilaRecurso>();
        var asignadas = asignaciones.Select(a => a.TareaUid).Distinct().ToArray();
        if (asignadas.Length == 0) return new(periodos, new(), aviso);
        DateTime minimo = asignadas.Select(uid => tareas[uid].Inicio.Date).Min();
        DateTime maximo = asignadas.Select(uid => tareas[uid].Fin.Date).Max();
        // Una tabla de horas por fecha se comparte entre todas las tareas y recursos.
        // Evita recorrer cada jornada una vez por cada recurso del ACU.
        int dias = (maximo - minimo).Days + 1;
        var horas = new decimal[dias + 1];
        for (int i = 0; i < dias; i++) horas[i + 1] = horas[i] + plan.Calendario.HorasDelDia(minimo.AddDays(i));
        decimal Horas(DateTime a, DateTime b)
        {
            if (a > b || b < minimo || a > maximo) return 0;
            a = a < minimo ? minimo : a; b = b > maximo ? maximo : b;
            return horas[(b - minimo).Days + 1] - horas[(a - minimo).Days];
        }
        foreach (int uid in asignadas)
        {
            var tarea = tareas[uid]; var origen = origenes[tarea.IdMYG];
            var tramos = new List<Tramo>();
            if (origen.Partes.Count > 0)
            {
                foreach (var parte in origen.Partes)
                {
                    DateTime a = plan.Calendario.SumarDiasLaborables(tarea.Inicio.Date, parte.DesfaseInicioDias);
                    DateTime b = plan.Calendario.SumarDiasLaborables(a, parte.DuracionDias - 1);
                    tramos.Add(new(a, b, parte.Porcentaje));
                }
            }
            else if (MYGMotorCronograma.ConservaFechasDelphin(origen) && origen.FechasImportadasDelphin.Tramos.Count > 1)
            {
                var originales = origen.FechasImportadasDelphin.Tramos;
                bool porcentajes = originales.Sum(t => t.Porcentaje) > 0;
                bool cantidades = originales.Sum(t => t.Cantidad) > 0;
                foreach (var parte in originales)
                    tramos.Add(new(parte.Inicio.Date, parte.Fin.Date, porcentajes ? parte.Porcentaje : cantidades ? parte.Cantidad : Math.Max(1, Horas(parte.Inicio.Date, parte.Fin.Date))));
            }
            else tramos.Add(new(tarea.Inicio.Date, tarea.Fin.Date, 100));
            decimal pesoTotal = tramos.Sum(t => t.Peso);
            var distribucion = new decimal[periodos.Count];
            foreach (var tramo in tramos)
            {
                decimal totalHoras = Horas(tramo.Inicio, tramo.Fin);
                for (int i = 0; i < periodos.Count; i++)
                {
                    DateTime a = periodos[i].Inicio > tramo.Inicio ? periodos[i].Inicio : tramo.Inicio;
                    DateTime b = periodos[i].Fin < tramo.Fin ? periodos[i].Fin : tramo.Fin;
                    if (a > b) continue;
                    decimal proporcion = totalHoras > 0 ? Horas(a, b) / totalHoras : ((b - a).Days + 1m) / ((tramo.Fin - tramo.Inicio).Days + 1m);
                    if (pesoTotal > 0) distribucion[i] += tramo.Peso / pesoTotal * proporcion;
                }
            }
            pesos.Add(uid, distribucion);
        }
        foreach (var asignacion in asignaciones)
        {
            if (!salida.TryGetValue(asignacion.RecursoUid, out var fila))
            {
                fila = new() { Recurso = recursos[asignacion.RecursoUid], Cantidades = new decimal[periodos.Count], Costos = new decimal[periodos.Count] };
                salida.Add(asignacion.RecursoUid, fila);
            }
            fila.CantidadTotal += asignacion.Cantidad; fila.CostoTotal += asignacion.Costo;
            var distribucion = pesos[asignacion.TareaUid];
            for (int i = 0; i < periodos.Count; i++) { fila.Cantidades[i] += asignacion.Cantidad * distribucion[i]; fila.Costos[i] += asignacion.Costo * distribucion[i]; }
        }
        return new(periodos, salida.Values.OrderBy(r => r.Recurso.Grupo).ThenBy(r => r.Recurso.Nombre).ToList(), aviso);
    }

    private static void CompletarCuadrillas(DatosRecursos datos, MYGModeloExportacionProject modelo,
        MYGCronograma plan, MYGProyectoDocumento proyecto, string id)
    {
        var seleccion = modelo.Tareas.FirstOrDefault(t => t.IdMYG == id);
        if (seleccion == null) return;
        var ids = new HashSet<int> { seleccion.Uid };
        foreach (var tarea in modelo.Tareas) if (ids.Contains(tarea.PadreUid)) ids.Add(tarea.Uid);
        var tareas = modelo.Tareas.ToDictionary(t => t.Uid);
        var origenes = plan.Tareas.ToDictionary(t => t.Id);
        var presupuestos = proyecto.Presupuestos.ToDictionary(p => p.Id, StringComparer.OrdinalIgnoreCase);
        var porRecurso = datos.Filas.ToDictionary(f => f.Recurso.Uid);
        var eventos = new Dictionary<int, SortedDictionary<DateTime, decimal>>();
        var incompletos = new Dictionary<int, string>();
        foreach (var fila in datos.Filas)
        {
            fila.Cuadrillas = new decimal?[datos.Periodos.Count];
            fila.AvisoCuadrilla = "Este recurso no declara dotación de mano de obra o equipo en unidades he, hh o hm.";
        }
        foreach (var asignacion in modelo.Asignaciones.Where(a => ids.Contains(a.TareaUid)))
        {
            var fila = porRecurso[asignacion.RecursoUid];
            if (!MYGCalculoCantidadRecursoACU.EsUnidadPorRecursos(fila.Recurso.Unidad) ||
                fila.Recurso.Grupo != MYGMotorPresupuestos.Grupo(MYGGrupoRecurso.ManoObra) &&
                fila.Recurso.Grupo != MYGMotorPresupuestos.Grupo(MYGGrupoRecurso.Equipo)) continue;
            var tarea = tareas[asignacion.TareaUid]; var origen = origenes[tarea.IdMYG];
            if (!presupuestos.TryGetValue(origen.PresupuestoId ?? "", out var presupuesto)) continue;
            var partida = presupuesto.Items.FirstOrDefault(p => string.Equals(p.Id, origen.PartidaId, StringComparison.OrdinalIgnoreCase));
            var candidatos = presupuesto.Costos.Insumos.Where(i => (i.Codigo ?? "") == fila.Recurso.Codigo &&
                i.Descripcion == fila.Recurso.Nombre && (i.Unidad ?? "") == fila.Recurso.Unidad &&
                MYGMotorPresupuestos.Grupo(i.Grupo) == fila.Recurso.Grupo).ToArray();
            if (partida == null || candidatos.Length != 1)
            {
                incompletos[asignacion.RecursoUid] = "La identidad del insumo no permite verificar su Nro. Rec. del ACU sin ambigüedad."; continue;
            }
            if (partida.Costos.Analisis.Any(r => r.Grupo == MYGGrupoRecurso.Subpartidas))
            {
                incompletos[asignacion.RecursoUid] = "ACU con subpartidas: no se infiere si sus dotaciones se necesitan simultáneamente."; continue;
            }
            var lineas = partida.Costos.Analisis.Where(r => r.InsumoId == candidatos[0].Id).ToArray();
            if (tarea.Hito || lineas.Length == 0 || lineas.Any(r => !MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(r, candidatos[0].Unidad)))
            {
                incompletos[asignacion.RecursoUid] = "La asignación no tiene jornadas de trabajo y una dotación verificable en el ACU."; continue;
            }
            // Nro. Rec. es el valor guardado y mostrado por el editor del ACU
            // (incluido personal_base importado). No se reconstruye a partir de hh.
            decimal dotacion = lineas.Sum(r => r.NumeroRecursos) * origen.NumeroCuadrillas;
            if (!eventos.TryGetValue(asignacion.RecursoUid, out var cambios))
                eventos.Add(asignacion.RecursoUid, cambios = new());
            var tramos = new List<(DateTime Inicio, DateTime Fin)>();
            if (origen.Partes.Count > 0)
            {
                foreach (var parte in origen.Partes)
                {
                    DateTime a = plan.Calendario.SumarDiasLaborables(tarea.Inicio.Date, parte.DesfaseInicioDias);
                    tramos.Add((a, plan.Calendario.SumarDiasLaborables(a, parte.DuracionDias - 1)));
                }
            }
            else if (MYGMotorCronograma.ConservaFechasDelphin(origen) && origen.FechasImportadasDelphin.Tramos.Count > 1)
                tramos.AddRange(origen.FechasImportadasDelphin.Tramos.Select(t => (t.Inicio.Date, t.Fin.Date)));
            else tramos.Add((tarea.Inicio.Date, tarea.Fin.Date));
            // Una tarea aporta su dotación una vez aunque sus tramos importados
            // se solapen. Las distintas tareas sí se suman cuando coinciden.
            var unidos = new List<(DateTime Inicio, DateTime Fin)>();
            foreach (var tramo in tramos.OrderBy(t => t.Inicio))
            {
                if (unidos.Count == 0 || tramo.Inicio > unidos[^1].Fin.AddDays(1)) unidos.Add(tramo);
                else unidos[^1] = (unidos[^1].Inicio, tramo.Fin > unidos[^1].Fin ? tramo.Fin : unidos[^1].Fin);
            }
            foreach (var tramo in unidos)
            {
                cambios[tramo.Inicio] = cambios.GetValueOrDefault(tramo.Inicio) + dotacion;
                DateTime despues = tramo.Fin.AddDays(1);
                cambios[despues] = cambios.GetValueOrDefault(despues) - dotacion;
            }
        }
        foreach (var fila in datos.Filas)
        {
            if (incompletos.TryGetValue(fila.Recurso.Uid, out string motivo)) { fila.AvisoCuadrilla = motivo; continue; }
            if (!eventos.TryGetValue(fila.Recurso.Uid, out var cambios)) continue;
            fila.CuadrillaMaxima = 0;
            for (int i = 0; i < fila.Cuadrillas.Length; i++) fila.Cuadrillas[i] = 0;
            var puntos = cambios.ToArray(); decimal actual = 0;
            for (int i = 0; i < puntos.Length - 1; i++)
            {
                actual += puntos[i].Value;
                DateTime a = puntos[i].Key, b = puntos[i + 1].Key.AddDays(-1);
                if (actual <= 0 || plan.Calendario.SiguienteLaborable(a) > b) continue;
                fila.CuadrillaMaxima = Math.Max(fila.CuadrillaMaxima.Value, actual);
                for (int j = 0; j < datos.Periodos.Count; j++)
                {
                    DateTime desde = a > datos.Periodos[j].Inicio ? a : datos.Periodos[j].Inicio;
                    DateTime hasta = b < datos.Periodos[j].Fin ? b : datos.Periodos[j].Fin;
                    if (desde <= hasta && plan.Calendario.SiguienteLaborable(desde) <= hasta)
                        fila.Cuadrillas[j] = Math.Max(fila.Cuadrillas[j].Value, actual);
                }
            }
            fila.AvisoCuadrilla = "Dotación del ACU (Nro. Rec.) × cuadrillas de tarea, sin convertir horas a personas. Cada período muestra el máximo simultáneo en días laborables; el total es el máximo de toda la selección.";
        }
    }

    private Control CrearOpciones()
    {
        var exterior = new Panel { Dock = DockStyle.Fill };
        var contenido = new FlowLayoutPanel { Name = "cronograma_opciones_contenido", Dock = DockStyle.Fill, AutoScroll = true, WrapContents = true, Padding = new Padding(4) };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 38, Padding = new Padding(3) };
        var descartar = new Button { Name = "cronograma_opciones_descartar", Text = "Descartar opciones", AutoSize = true };
        descartar.Click += (_, _) => { CargarCamposOpciones(obtener()); estadoOpciones.Text = "Se recuperaron las opciones aplicadas al proyecto."; };
        pie.Controls.Add(aplicarOpciones); pie.Controls.Add(descartar); pie.Controls.Add(estadoOpciones);
        exterior.Controls.Add(contenido); exterior.Controls.Add(pie);
        TableLayoutPanel Grupo(string texto, int ancho)
        {
            var caja = new GroupBox { Text = texto, Width = ancho, Height = 320, Padding = new Padding(8, 22, 8, 8) };
            var tabla = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, AutoScroll = true };
            tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43)); tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57));
            caja.Controls.Add(tabla); contenido.Controls.Add(caja); return tabla;
        }
        void Campo(TableLayoutPanel tabla, string clave, string texto, Control control)
        {
            int fila = tabla.RowCount++; tabla.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tabla.Controls.Add(new Label { Text = texto, AutoSize = true, Dock = DockStyle.Fill, Padding = new Padding(0, 5, 1, 3) }, 0, fila);
            control.Name = "cronograma_opciones_" + clave; control.Dock = DockStyle.Top; tabla.Controls.Add(control, 1, fila);
            controlesOpciones.Add(clave, control);
        }
        Button ColorBoton(int valor)
        {
            var boton = new Button { Text = "Elegir color…", Tag = valor, Height = 27 };
            boton.Paint += (_, e) => { using var color = new SolidBrush(Color.FromArgb((int)boton.Tag)); e.Graphics.FillRectangle(color, 5, 7, 15, 12); };
            boton.Click += (_, _) =>
            {
                using var dialogo = new ColorDialog { Color = Color.FromArgb((int)boton.Tag), FullOpen = true };
                if (dialogo.ShowDialog(FindForm()) == DialogResult.OK) { boton.Tag = dialogo.Color.ToArgb(); boton.Invalidate(); }
            };
            return boton;
        }
        var critica = Grupo("Personalizar ruta crítica", 280);
        Campo(critica, "ColorCriticaArgb", "Color de tareas", ColorBoton(opciones.ColorCriticaArgb));
        Campo(critica, "ColorDependenciasCriticasArgb", "Color de dependencias", ColorBoton(opciones.ColorDependenciasCriticasArgb));
        var impresion = Grupo("Opciones de impresión", 385);
        Campo(impresion, "ImprimirLeyenda", "Imprimir leyenda", new CheckBox());
        Campo(impresion, "ImprimirInformacionPagina", "Información de página", new CheckBox());
        Campo(impresion, "TipoInformacionPagina", "Tipo de información", Lista("", "Ninguno", "Fecha y hora", "Número", "Número del total", "Total", "Usuario"));
        Campo(impresion, "TituloPagina", "Título de página", new TextBox { MaxLength = 240 });
        Campo(impresion, "Horizontal", "Orientación", Lista("", "Vertical", "Horizontal"));
        Campo(impresion, "Papel", "Papel", Lista("", "A2", "A3", "A4", "A5", "A6", "B4", "B5", "Carta", "Oficio"));
        var inicio = Fecha(""); inicio.ShowCheckBox = true;
        var fin = Fecha(""); fin.ShowCheckBox = true;
        Campo(impresion, "InicioImpresion", "Fecha de inicio", inicio); Campo(impresion, "FinImpresion", "Fecha de fin", fin);
        var tarea = Grupo("Personalizar tarea", 370);
        Campo(tarea, "AparienciaBarra", "Apariencia de barra", Lista("", "Sólida", "Contorno"));
        Campo(tarea, "ColorAvanceArgb", "Color de avance", ColorBoton(opciones.ColorAvanceArgb));
        Campo(tarea, "OcultarAvance", "Ocultar avance", new CheckBox());
        string[] textos = { "Sin texto", "@Inicio", "@Fin", "@Duración", "@Descripción", "@Metrado", "@Valorizado" };
        Campo(tarea, "TextoIzquierda", "Texto a la izquierda", Lista("", textos));
        Campo(tarea, "TextoCentro", "Texto en el centro", Lista("", textos));
        Campo(tarea, "TextoDerecha", "Texto a la derecha", Lista("", textos));
        Campo(tarea, "PosicionMensaje", "Mensajes de tarea", Lista("", "Defecto", "Arriba a la izquierda", "Parte superior derecha", "Parte inferior izquierda", "Parte inferior derecha", "Ninguno"));
        return exterior;
    }

    private void CargarOpciones(MYGCronograma plan)
    {
        string guardado = plan.OpcionesVista?.GetValueOrDefault("Presentacion") ?? "";
        bool cambio = jsonOpciones != guardado;
        if (cambio)
        {
            bool conservarEdicion = OpcionesPendientes && !aplicandoOpciones;
            try { opciones = string.IsNullOrWhiteSpace(guardado) ? new() : JsonSerializer.Deserialize<MYGOpcionesVistaCronograma>(guardado) ?? new(); }
            catch (JsonException) { opciones = new(); estadoOpciones.Text = "Se cargaron los valores predeterminados; las preferencias guardadas no son válidas."; }
            jsonOpciones = guardado;
            if (!conservarEdicion) CargarCamposOpciones(plan);
            else estadoOpciones.Text = "Se conservan sus opciones sin aplicar. Use Aplicar opciones o Descartar opciones.";
            OpcionesCambiadas?.Invoke(opciones);
        }
        bool editable = puedeEditar();
        foreach (var control in controlesOpciones.Values) control.Enabled = editable;
        aplicarOpciones.Enabled = editable;
    }

    private void CargarCamposOpciones(MYGCronograma plan)
    {
        foreach (var propiedad in typeof(MYGOpcionesVistaCronograma).GetProperties())
        {
            if (!controlesOpciones.TryGetValue(propiedad.Name, out var control)) continue;
            object valor = propiedad.GetValue(opciones);
            if (control is Button boton) { boton.Tag = valor; boton.Invalidate(); }
            else if (control is CheckBox check) check.Checked = valor is true;
            else if (control is DateTimePicker fecha) { fecha.Value = LimitarFecha(valor is DateTime fechaValor ? fechaValor : plan.FechaInicio); fecha.Checked = valor != null; }
            else if (control is ComboBox combo)
            {
                if (propiedad.Name == "Horizontal") combo.SelectedIndex = opciones.Horizontal ? 1 : 0;
                else combo.SelectedItem = combo.Items.Contains(valor ?? "") ? valor : combo.Items[0];
            }
            else control.Text = Convert.ToString(valor);
        }
        firmaCamposOpciones = JsonSerializer.Serialize(LeerOpciones());
    }

    private MYGOpcionesVistaCronograma LeerOpciones()
    {
        var nuevas = new MYGOpcionesVistaCronograma();
        foreach (var propiedad in typeof(MYGOpcionesVistaCronograma).GetProperties())
        {
            var control = controlesOpciones[propiedad.Name];
            object valor = control is Button boton ? boton.Tag : control is CheckBox check ? check.Checked :
                control is DateTimePicker fecha ? fecha.Checked ? fecha.Value.Date : null :
                control is ComboBox combo ? propiedad.Name == "Horizontal" ? combo.SelectedIndex == 1 : Convert.ToString(combo.SelectedItem) : control.Text;
            propiedad.SetValue(nuevas, valor);
        }
        return nuevas;
    }

    private bool GuardarOpciones(bool confirmarInformacion = true)
    {
        if (!OpcionesPendientes) return true;
        if (!puedeEditar()) { estadoOpciones.Text = "Se requiere permiso de edición para aplicar opciones."; return false; }
        if (confirmarInformacion && !informacion.ConfirmarSalida()) return false;
        try
        {
            var nuevas = LeerOpciones();
            if (nuevas.InicioImpresion.HasValue && nuevas.FinImpresion.HasValue && nuevas.FinImpresion < nuevas.InicioImpresion)
                throw new InvalidOperationException("La fecha de fin de impresión debe ser igual o posterior al inicio.");
            var copia = MYGProyectoStorage.Copia(obtener());
            copia.OpcionesVista ??= new();
            string json = JsonSerializer.Serialize(nuevas);
            copia.OpcionesVista["Presentacion"] = json;
            aplicandoOpciones = true;
            aplicar(copia);
            opciones = nuevas; jsonOpciones = json;
            firmaCamposOpciones = json;
            OpcionesCambiadas?.Invoke(opciones);
            estadoOpciones.Text = "Opciones aplicadas al proyecto. Use Guardar para conservar el archivo.";
            return true;
        }
        catch (Exception ex) { estadoOpciones.Text = ex.Message; return false; }
        finally { aplicandoOpciones = false; }
    }

    private void CambioTema(object sender, EventArgs e) => AplicarTema();
    private void AplicarTema()
    {
        MYG2027_TemaComercial.Aplicar(this);
        MYG2027_TemaComercial.EstilizarTabla(recursos, 44);
        bi?.ActualizarTema(); curva?.ActualizarTema();
    }

    private sealed class VistaGrafico : UserControl
    {
        private readonly ComboBox control = Lista("", "Valorizado", "Cantidad");
        private readonly ComboBox tipo = Lista("", "Todos los tipos");
        private readonly ComboBox recurso = Lista("", "Todos los recursos");
        private readonly ComboBox escala = Lista("", "Día", "Semana", "Mes");
        private readonly CheckBox acumulado = new() { Text = "Ver montos acumulados", AutoSize = true };
        private readonly CheckBox cuadricula = new() { Text = "Cuadrícula", AutoSize = true, Checked = true };
        private readonly CheckBox etiquetas = new() { Text = "Ver etiquetas", AutoSize = true };
        private readonly NumericUpDown separacion = new() { Minimum = 0, Maximum = 80, Value = 18, Width = 60 };
        private readonly MYGGraficoProgramacion grafico;
        private readonly Label resumen = new() { Dock = DockStyle.Bottom, Height = 31, Padding = new Padding(5), AutoEllipsis = true };
        private List<Periodo> periodos = new();
        private List<FilaRecurso> filas = new();
        private string moneda;
        private bool cargando;
        internal VistaGrafico(bool esCurva, Action<string> cambioEscala)
        {
            Name = esCurva ? "cronograma_curva_s" : "cronograma_bi"; Dock = DockStyle.Fill;
            control.Name = Name + "_control"; tipo.Name = Name + "_tipo"; recurso.Name = Name + "_recurso"; escala.Name = Name + "_escala";
            acumulado.Name = Name + "_acumulado"; cuadricula.Name = Name + "_cuadricula"; etiquetas.Name = Name + "_etiquetas"; separacion.Name = Name + "_separacion";
            grafico = new MYGGraficoProgramacion { Name = Name + "_grafico", Dock = DockStyle.Fill, Linea = esCurva };
            var opciones = new FlowLayoutPanel { Dock = DockStyle.Right, Width = 245, AutoScroll = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(7) };
            void Agregar(string texto, Control campo)
            {
                opciones.Controls.Add(new Label { Text = texto, AutoSize = true, Margin = new Padding(0, 7, 0, 2) });
                campo.Width = 214; opciones.Controls.Add(campo);
            }
            acumulado.Checked = esCurva; acumulado.Enabled = !esCurva;
            opciones.Controls.Add(acumulado);
            Agregar("Tipo de control", control); Agregar("Tipo de costo", tipo); Agregar("Descripción del recurso", recurso); Agregar("Unidad de tiempo", escala);
            opciones.Controls.Add(cuadricula); opciones.Controls.Add(etiquetas);
            if (!esCurva) Agregar("Separación entre barras (%)", separacion);
            Controls.Add(grafico); Controls.Add(opciones); Controls.Add(resumen);
            foreach (var combo in new[] { control, tipo, recurso }) combo.SelectedIndexChanged += (_, _) => { if (!cargando) Mostrar(); };
            acumulado.CheckedChanged += (_, _) => Mostrar(); cuadricula.CheckedChanged += (_, _) => Mostrar(); etiquetas.CheckedChanged += (_, _) => Mostrar(); separacion.ValueChanged += (_, _) => Mostrar();
            escala.SelectedIndexChanged += (_, _) => { if (!cargando) cambioEscala(Convert.ToString(escala.SelectedItem)); };
        }
        internal void Vaciar() { filas.Clear(); grafico.Datos(Array.Empty<string>(), Array.Empty<decimal>(), "", false, true, false, 18); resumen.Text = ""; }
        internal void Cargar(List<Periodo> nuevosPeriodos, List<FilaRecurso> nuevasFilas, string nuevaMoneda, string unidad)
        {
            periodos = nuevosPeriodos; filas = nuevasFilas; moneda = nuevaMoneda;
            cargando = true;
            string anteriorTipo = Convert.ToString(tipo.SelectedItem);
            string anteriorRecurso = (recurso.SelectedItem as RecursoItem)?.Id.ToString(CultureInfo.InvariantCulture);
            tipo.Items.Clear(); tipo.Items.Add("Todos los tipos"); tipo.Items.AddRange(filas.Select(f => f.Recurso.Grupo).Distinct().OrderBy(t => t).Cast<object>().ToArray());
            tipo.SelectedItem = tipo.Items.Contains(anteriorTipo) ? anteriorTipo : tipo.Items[0];
            recurso.Items.Clear(); recurso.Items.Add("Todos los recursos");
            foreach (var fila in filas) recurso.Items.Add(new RecursoItem(fila.Recurso.Uid, fila.Recurso.Nombre + " (" + fila.Recurso.Unidad + ")"));
            recurso.SelectedIndex = 0;
            if (anteriorRecurso != null)
                foreach (var item in recurso.Items.OfType<RecursoItem>()) if (item.Id.ToString(CultureInfo.InvariantCulture) == anteriorRecurso) { recurso.SelectedItem = item; break; }
            escala.SelectedItem = unidad; cargando = false; Mostrar();
        }
        private void Mostrar()
        {
            if (cargando) return;
            var seleccion = filas.Where(f => tipo.SelectedIndex <= 0 || f.Recurso.Grupo == Convert.ToString(tipo.SelectedItem))
                .Where(f => recurso.SelectedItem is not RecursoItem item || f.Recurso.Uid == item.Id).ToArray();
            bool cantidad = control.SelectedIndex == 1;
            string[] unidades = seleccion.Select(f => f.Recurso.Unidad).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            if (cantidad && unidades.Length > 1)
            {
                grafico.Datos(Array.Empty<string>(), Array.Empty<decimal>(), "Seleccione un recurso o un tipo con una sola unidad para graficar cantidades.", false, cuadricula.Checked, etiquetas.Checked, (int)separacion.Value);
                resumen.Text = "Las cantidades con unidades diferentes se consultan por recurso."; return;
            }
            decimal[] valores = new decimal[periodos.Count];
            foreach (var fila in seleccion)
                for (int i = 0; i < valores.Length; i++) valores[i] += cantidad ? fila.Cantidades[i] : fila.Costos[i];
            decimal total = valores.Sum();
            if (acumulado.Checked) for (int i = 1; i < valores.Length; i++) valores[i] += valores[i - 1];
            string unidad = cantidad ? unidades.FirstOrDefault() ?? "" : moneda ?? "Moneda del presupuesto";
            grafico.Datos(periodos.Select(p => p.Etiqueta).ToArray(), valores, unidad, acumulado.Checked, cuadricula.Checked, etiquetas.Checked, (int)separacion.Value);
            resumen.Text = "Programado en el rango: " + total.ToString("N3") + " " + unidad + " · " + seleccion.Length + " recursos · " + (acumulado.Checked ? "Acumulado del rango visible" : "Importe por período");
        }
        internal void ActualizarTema() => grafico.Invalidate();
        private sealed record RecursoItem(int Id, string Descripcion) { public override string ToString() => Descripcion; }
    }
}

/// <summary>Gráfico ligero de planificación; no usa bibliotecas ni procesos externos.</summary>
internal sealed class MYGGraficoProgramacion : Control
{
    private string[] nombres = Array.Empty<string>();
    private decimal[] valores = Array.Empty<decimal>();
    private string unidad = "";
    private bool cuadricula = true, etiquetas, acumulado;
    private int separacion = 18;
    private RectangleF area;
    private readonly ToolTip ayuda = new();
    private int ultimo = -1;
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal bool Linea { get; set; }
    internal MYGGraficoProgramacion()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        AccessibleName = "Gráfico de cantidades y montos programados por período";
        MouseMove += (_, e) =>
        {
            if (valores.Length == 0 || area.Width <= 0 || !area.Contains(e.Location)) { if (ultimo != -1) { ayuda.Hide(this); ultimo = -1; } return; }
            int i = Math.Clamp((int)((e.X - area.Left) / area.Width * valores.Length), 0, valores.Length - 1);
            if (ultimo == i) return;
            ultimo = i; ayuda.SetToolTip(this, nombres[i] + "\n" + valores[i].ToString("N3") + " " + unidad + (acumulado ? " (acumulado)" : ""));
        };
        MouseLeave += (_, _) => { ultimo = -1; ayuda.Hide(this); };
        Disposed += (_, _) => ayuda.Dispose();
    }
    internal void Datos(string[] periodos, decimal[] nuevos, string nuevaUnidad, bool esAcumulado, bool verCuadricula, bool verEtiquetas, int espacio)
    {
        nombres = periodos; valores = nuevos; unidad = nuevaUnidad; acumulado = esAcumulado; cuadricula = verCuadricula; etiquetas = verEtiquetas; separacion = espacio; ultimo = -1;
        AccessibleDescription = valores.Length + " períodos. " + unidad + ". " + (acumulado ? "Acumulado" : "Por período"); Invalidate();
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics; g.Clear(MYG2027_TemaComercial.Superficie); g.SmoothingMode = SmoothingMode.AntiAlias;
        var texto = MYG2027_TemaComercial.Texto; var color = MYG2027_TemaComercial.Azul;
        if (ClientSize.Width < 160 || ClientSize.Height < 100) return;
        if (valores.Length == 0)
        {
            TextRenderer.DrawText(g, string.IsNullOrEmpty(unidad) ? "Sin recursos programados en la selección." : unidad, Font, ClientRectangle, texto, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak); return;
        }
        decimal maximo = valores.Select(Math.Abs).DefaultIfEmpty(0m).Max(); if (maximo == 0) maximo = 1;
        int anchoEtiquetas = TextRenderer.MeasureText(g, maximo.ToString("N0"), Font).Width + 15;
        area = new RectangleF(Math.Max(65, anchoEtiquetas), 25, ClientSize.Width - Math.Max(65, anchoEtiquetas) - 20, ClientSize.Height - 78);
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        using var eje = new Pen(MYG2027_TemaComercial.Secundario);
        using var trazo = new Pen(color, 2);
        using var relleno = new SolidBrush(Color.FromArgb(180, color));
        for (int i = 0; i <= 4; i++)
        {
            float y = area.Bottom - area.Height * i / 4;
            if (cuadricula) g.DrawLine(borde, area.Left, y, area.Right, y);
            TextRenderer.DrawText(g, (maximo * i / 4).ToString("N0"), Font, new Rectangle(0, (int)y - Font.Height / 2, (int)area.Left - 6, Font.Height + 2), texto, TextFormatFlags.Right);
        }
        g.DrawLine(eje, area.Left, area.Top, area.Left, area.Bottom); g.DrawLine(eje, area.Left, area.Bottom, area.Right, area.Bottom);
        float ancho = area.Width / valores.Length; var puntos = new PointF[valores.Length];
        int paso = Math.Max(1, (int)Math.Ceiling(valores.Length * 80d / area.Width));
        for (int i = 0; i < valores.Length; i++)
        {
            float x = area.Left + ancho * (i + .5F), y = area.Bottom - (float)(valores[i] / maximo) * area.Height;
            puntos[i] = new PointF(x, y);
            if (!Linea) g.FillRectangle(relleno, area.Left + ancho * i + ancho * separacion / 200, y, Math.Max(1, ancho * (100 - separacion) / 100), Math.Max(1, area.Bottom - y));
            if (i % paso == 0 || i == valores.Length - 1)
                TextRenderer.DrawText(g, nombres[i], Font, new Rectangle((int)x - 45, (int)area.Bottom + 4, 90, Font.Height + 4), texto, TextFormatFlags.HorizontalCenter | TextFormatFlags.EndEllipsis);
            if (etiquetas && i % paso == 0)
                TextRenderer.DrawText(g, valores[i].ToString("N2"), Font, new Rectangle((int)x - 50, Math.Max(3, (int)y - Font.Height - 3), 100, Font.Height + 2), texto, TextFormatFlags.HorizontalCenter | TextFormatFlags.EndEllipsis);
        }
        if (Linea)
        {
            if (puntos.Length > 1) g.DrawLines(trazo, puntos);
            foreach (var punto in puntos) g.FillEllipse(relleno, punto.X - 2.5F, punto.Y - 2.5F, 5, 5);
        }
        TextRenderer.DrawText(g, unidad + (acumulado ? " · Acumulado" : " · Por período"), Font, new Rectangle((int)area.Left, 3, (int)area.Width, Font.Height + 2), texto);
    }
}
