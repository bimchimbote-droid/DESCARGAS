using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private IReadOnlyList<MYGReferenciaFormulaHoja> referenciasFormulaHoja = Array.Empty<MYGReferenciaFormulaHoja>();
    private IReadOnlyList<MYGReferenciaFormulaHoja> referenciasVisualesHoja = Array.Empty<MYGReferenciaFormulaHoja>();
    private TextBoxBase editorReferenciasHoja;
    private bool editandoFormulaBarraHoja;
    private object partidaReferenciasHoja;
    private static readonly Color[] coloresReferenciasClarosHoja =
        [Color.FromArgb(38, 111, 214), Color.FromArgb(212, 67, 48), Color.FromArgb(126, 78, 186), Color.FromArgb(39, 148, 81), Color.FromArgb(220, 134, 23), Color.FromArgb(0, 130, 151)];
    private static readonly Color[] coloresReferenciasOscurosHoja =
        [Color.FromArgb(94, 166, 255), Color.FromArgb(255, 126, 119), Color.FromArgb(186, 148, 247), Color.FromArgb(103, 205, 138), Color.FromArgb(255, 186, 90), Color.FromArgb(81, 204, 215)];

    // Se conserva una referencia por aparición para comprobar también que las
    // referencias repetidas mantienen su color. El pintado usa rangos únicos.
    internal IReadOnlyList<MYGReferenciaFormulaHoja> EstadoReferenciasHoja => referenciasFormulaHoja;

    private void PrepararReferenciasHoja()
    {
        hoja.EditingControlShowing += MostrarEditorReferenciasHoja;
        hoja.CellEndEdit += TerminarEditorReferenciasHoja;
        // Este manejador se registra después del pintado de bordes y combinaciones.
        hoja.CellPainting += PintarReferenciasHoja;
        hoja.Paint += PintarTiradoresReferenciasHoja;
        formula.Enter += EntrarFormulaReferenciasHoja;
        formula.TextChanged += CambiarFormulaReferenciasHoja;
        formula.Leave += SalirFormulaReferenciasHoja;
        formula.KeyDown += TeclaFormulaReferenciasHoja;
        paginaExcel.VisibleChanged += VisibilidadReferenciasHoja;
        detalle.SelectedIndexChanged += CambiarPaginaReferenciasHoja;
        Disposed += LiberarReferenciasHoja;
    }

    private void MostrarEditorReferenciasHoja(object sender, DataGridViewEditingControlShowingEventArgs e)
    {
        DesvincularEditorReferenciasHoja();
        editandoFormulaBarraHoja = false;
        if (cargando || !HayPartida || e.Control is not TextBoxBase editor) { LimpiarReferenciasHoja(); return; }
        editorReferenciasHoja = editor;
        editor.TextChanged += CambiarEditorReferenciasHoja;
        editor.KeyDown += TeclaEditorReferenciasHoja;
        SincronizarBarraEditorReferenciasHoja();
        ActualizarReferenciasHoja(editor.Text);
    }

    private void CambiarEditorReferenciasHoja(object sender, EventArgs e)
    {
        if (!cargando && sender == editorReferenciasHoja)
        {
            SincronizarBarraEditorReferenciasHoja();
            ActualizarReferenciasHoja(editorReferenciasHoja.Text);
        }
    }

    private void SincronizarBarraEditorReferenciasHoja()
    {
        if (editorReferenciasHoja == null || formula.Text == editorReferenciasHoja.Text) return;
        bool previo = actualizandoFormulaHoja;
        actualizandoFormulaHoja = true;
        try { formula.Text = editorReferenciasHoja.Text; formulaPendienteHoja = false; }
        finally { actualizandoFormulaHoja = previo; }
    }

    private void TeclaEditorReferenciasHoja(object sender, KeyEventArgs e)
    {
        if (e.Handled) return;
        if (e.KeyCode == Keys.Escape) LimpiarReferenciasHoja();
    }

    private void TerminarEditorReferenciasHoja(object sender, DataGridViewCellEventArgs e) => LimpiarReferenciasHoja();

    private void EntrarFormulaReferenciasHoja(object sender, EventArgs e)
    {
        if (cargando || !HayPartida) return;
        editandoFormulaBarraHoja = true;
        ActualizarReferenciasHoja(formula.Text);
    }

    private void CambiarFormulaReferenciasHoja(object sender, EventArgs e)
    {
        if (editandoFormulaBarraHoja && !actualizandoFormulaHoja && !cargando)
            ActualizarReferenciasHoja(formula.Text);
    }

    private void SalirFormulaReferenciasHoja(object sender, EventArgs e) => LimpiarReferenciasHoja();

    private void TeclaFormulaReferenciasHoja(object sender, KeyEventArgs e)
    {
        if (e.Handled) return;
        if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.Enter && !formulaPendienteHoja)
            LimpiarReferenciasHoja();
    }

    private void VisibilidadReferenciasHoja(object sender, EventArgs e)
    {
        if (!paginaExcel.Visible) LimpiarReferenciasHoja();
    }

    private void CambiarPaginaReferenciasHoja(object sender, EventArgs e)
    {
        if (detalle.SelectedTab != paginaExcel) LimpiarReferenciasHoja();
    }

    private void ActualizarReferenciasHoja(string texto)
    {
        if (!HayPartida) { LimpiarReferenciasHoja(); return; }
        var libro = actual.Costos.Hoja;
        referenciasFormulaHoja = MYGReferenciasFormulaHoja.Extraer(texto, libro.Filas, libro.Columnas);
        referenciasVisualesHoja = referenciasFormulaHoja.DistinctBy(r => r.Rango).Select(ExpandirReferenciaVisualHoja).ToArray();
        partidaReferenciasHoja = actual.Id;
        ActualizarColoresReferenciasHoja();
        if (!hoja.IsDisposed) hoja.Invalidate();
    }

    private void LimpiarReferenciasHoja()
    {
        bool habiaReferencias = referenciasFormulaHoja.Count != 0;
        referenciasFormulaHoja = referenciasVisualesHoja = Array.Empty<MYGReferenciaFormulaHoja>();
        editandoFormulaBarraHoja = false;
        partidaReferenciasHoja = null;
        formula.ColorearReferencias(Array.Empty<MYGReferenciaFormulaHoja>(), ColorReferenciaHoja);
        if (editorReferenciasHoja is MYGEditorTextoFormulaHoja editor)
            editor.ColorearReferencias(Array.Empty<MYGReferenciaFormulaHoja>(), ColorReferenciaHoja);
        DesvincularEditorReferenciasHoja();
        if (habiaReferencias && !hoja.IsDisposed) hoja.Invalidate();
    }

    private void DesvincularEditorReferenciasHoja()
    {
        if (editorReferenciasHoja == null) return;
        editorReferenciasHoja.TextChanged -= CambiarEditorReferenciasHoja;
        editorReferenciasHoja.KeyDown -= TeclaEditorReferenciasHoja;
        editorReferenciasHoja = null;
    }

    private void LiberarReferenciasHoja(object sender, EventArgs e)
    {
        DesvincularEditorReferenciasHoja();
        hoja.EditingControlShowing -= MostrarEditorReferenciasHoja;
        hoja.CellEndEdit -= TerminarEditorReferenciasHoja;
        hoja.CellPainting -= PintarReferenciasHoja;
        hoja.Paint -= PintarTiradoresReferenciasHoja;
        formula.Enter -= EntrarFormulaReferenciasHoja;
        formula.TextChanged -= CambiarFormulaReferenciasHoja;
        formula.Leave -= SalirFormulaReferenciasHoja;
        formula.KeyDown -= TeclaFormulaReferenciasHoja;
        paginaExcel.VisibleChanged -= VisibilidadReferenciasHoja;
        detalle.SelectedIndexChanged -= CambiarPaginaReferenciasHoja;
        Disposed -= LiberarReferenciasHoja;
        referenciasFormulaHoja = referenciasVisualesHoja = Array.Empty<MYGReferenciaFormulaHoja>();
    }

    private Color ColorReferenciaHoja(int indice)
    {
        Color[] colores = MYG2027_TemaComercial.Oscuro ? coloresReferenciasOscurosHoja : coloresReferenciasClarosHoja;
        return colores[indice % colores.Length];
    }

    private void ActualizarColoresReferenciasHoja()
    {
        var vacias = Array.Empty<MYGReferenciaFormulaHoja>();
        formula.ColorearReferencias(editandoFormulaBarraHoja || editorReferenciasHoja != null &&
            formula.Text == editorReferenciasHoja.Text ? referenciasFormulaHoja : vacias, ColorReferenciaHoja);
        if (editorReferenciasHoja is MYGEditorTextoFormulaHoja editor && !editor.IsDisposed)
            editor.ColorearReferencias(referenciasFormulaHoja, ColorReferenciaHoja);
    }

    private MYGReferenciaFormulaHoja ExpandirReferenciaVisualHoja(MYGReferenciaFormulaHoja referencia)
    {
        int f1 = referencia.FilaInicial, f2 = referencia.FilaFinal;
        int c1 = referencia.ColumnaInicial, c2 = referencia.ColumnaFinal;
        bool ampliada;
        do
        {
            ampliada = false;
            foreach (string combinacion in actual.Costos.Hoja.RangosCombinados)
            {
                var r = RangoHoja(combinacion);
                if (r.f1 + 1 > f2 || r.f2 + 1 < f1 || r.c1 + 1 > c2 || r.c2 + 1 < c1) continue;
                int nf1 = Math.Min(f1, r.f1 + 1), nf2 = Math.Max(f2, r.f2 + 1);
                int nc1 = Math.Min(c1, r.c1 + 1), nc2 = Math.Max(c2, r.c2 + 1);
                if (nf1 != f1 || nf2 != f2 || nc1 != c1 || nc2 != c2) ampliada = true;
                (f1, f2, c1, c2) = (nf1, nf2, nc1, nc2);
            }
        } while (ampliada);
        return referencia with { FilaInicial = f1, FilaFinal = f2, ColumnaInicial = c1, ColumnaFinal = c2 };
    }

    private Rectangle TiradorReferenciaHoja(MYGReferenciaFormulaHoja referencia)
    {
        if (!HayPartida || !Equals(partidaReferenciasHoja, actual.Id) ||
            referencia.FilaFinal > hoja.RowCount || referencia.ColumnaFinal > hoja.ColumnCount ||
            !hoja.Rows[referencia.FilaFinal - 1].Visible || !hoja.Columns[referencia.ColumnaFinal - 1].Visible)
            return Rectangle.Empty;
        var celda = hoja.GetCellDisplayRectangle(referencia.ColumnaFinal - 1, referencia.FilaFinal - 1, false);
        if (celda.Width <= 0 || celda.Height <= 0 ||
            !AreaCeldasHoja().Contains(new Point(celda.Right - 2, celda.Bottom - 2))) return Rectangle.Empty;
        int tamano = Math.Max(7, (int)Math.Ceiling(8 * hoja.DeviceDpi / 96d));
        return new(celda.Right - 2 - tamano / 2, celda.Bottom - 2 - tamano / 2, tamano, tamano);
    }

    private MYGReferenciaFormulaHoja ReferenciaTiradorHoja(Point punto, TextBoxBase editor)
    {
        if (editor == null || editor.ReadOnly || !AreaCeldasHoja().Contains(punto)) return null;
        // Un mismo marco puede representar varias apariciones. Se ajusta la
        // más próxima al cursor de texto, sin reemplazar las otras referencias.
        return referenciasFormulaHoja
            .Where(r => TiradorReferenciaHoja(ExpandirReferenciaVisualHoja(r)).Contains(punto))
            .OrderBy(r => editor.SelectionStart < r.Inicio ? r.Inicio - editor.SelectionStart :
                Math.Max(0, editor.SelectionStart - r.Inicio - r.Longitud))
            .FirstOrDefault();
    }

    private void PintarTiradoresReferenciasHoja(object sender, PaintEventArgs e)
    {
        if (EditorActivoElegirReferenciasHoja() == null || referenciasVisualesHoja.Count == 0) return;
        var estado = e.Graphics.Save();
        try
        {
            e.Graphics.SetClip(AreaCeldasHoja());
            foreach (var referencia in referenciasVisualesHoja)
            {
                var tirador = TiradorReferenciaHoja(referencia);
                if (tirador.IsEmpty) continue;
                using var fondo = new SolidBrush(ColorReferenciaHoja(referencia.IndiceColor));
                e.Graphics.FillRectangle(fondo, tirador);
                using var borde = new Pen(MYG2027_TemaComercial.Superficie);
                e.Graphics.DrawRectangle(borde, tirador.X, tirador.Y, tirador.Width - 1, tirador.Height - 1);
            }
        }
        finally { e.Graphics.Restore(estado); }
    }

    private void PintarReferenciasHoja(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex < 0 || referenciasVisualesHoja.Count == 0 ||
            !HayPartida || !Equals(partidaReferenciasHoja, actual.Id)) return;
        int fila = e.RowIndex + 1, columna = e.ColumnIndex + 1;
        MYGReferenciaFormulaHoja primera = null;
        foreach (var referencia in referenciasVisualesHoja)
            if (fila >= referencia.FilaInicial && fila <= referencia.FilaFinal &&
                columna >= referencia.ColumnaInicial && columna <= referencia.ColumnaFinal)
            { primera = referencia; break; }
        if (primera == null) return;

        // No se cambian Cell.Style ni el modelo. Se añade el color sólo durante
        // la edición, conservando selección, texto, bordes y combinaciones.
        if (!e.Handled) e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
        var estado = e.Graphics.Save();
        try
        {
            e.Graphics.SetClip(Rectangle.Intersect(e.ClipBounds, e.CellBounds));
            Color fondo = (e.State & DataGridViewElementStates.Selected) != 0
                ? e.CellStyle.SelectionBackColor : e.CellStyle.BackColor;
            Color color = ColorReferenciaHoja(primera.IndiceColor);
            double opacidad = MYG2027_TemaComercial.Oscuro ? .23 : .13;
            Color tinte = Color.FromArgb(
                (int)Math.Round(fondo.R * (1 - opacidad) + color.R * opacidad),
                (int)Math.Round(fondo.G * (1 - opacidad) + color.G * opacidad),
                (int)Math.Round(fondo.B * (1 - opacidad) + color.B * opacidad));
            using (var pincel = new SolidBrush(tinte))
                e.Graphics.FillRectangle(pincel, e.CellBounds.X + 1, e.CellBounds.Y + 1,
                    Math.Max(0, e.CellBounds.Width - 2), Math.Max(0, e.CellBounds.Height - 2));
            PintarContenidoReferenciaHoja(e);
            foreach (var referencia in referenciasVisualesHoja)
            {
                if (fila < referencia.FilaInicial || fila > referencia.FilaFinal ||
                    columna < referencia.ColumnaInicial || columna > referencia.ColumnaFinal) continue;
                using var borde = new Pen(ColorReferenciaHoja(referencia.IndiceColor), Math.Max(2f, 2f * DeviceDpi / 96f));
                var r = e.CellBounds;
                // Los segmentos sólo forman el contorno exterior del rango;
                // su coste no depende del número de celdas que éste contiene.
                if (fila == referencia.FilaInicial) e.Graphics.DrawLine(borde, r.Left, r.Top + 1, r.Right, r.Top + 1);
                if (fila == referencia.FilaFinal) e.Graphics.DrawLine(borde, r.Left, r.Bottom - 2, r.Right, r.Bottom - 2);
                if (columna == referencia.ColumnaInicial) e.Graphics.DrawLine(borde, r.Left + 1, r.Top, r.Left + 1, r.Bottom);
                if (columna == referencia.ColumnaFinal) e.Graphics.DrawLine(borde, r.Right - 2, r.Top, r.Right - 2, r.Bottom);
            }
            e.Handled = true;
        }
        finally { e.Graphics.Restore(estado); }
    }

    private void PintarContenidoReferenciaHoja(DataGridViewCellPaintingEventArgs e)
    {
        foreach (string combinacion in actual.Costos.Hoja.RangosCombinados)
        {
            var r = RangoHoja(combinacion);
            if (e.RowIndex < r.f1 || e.RowIndex > r.f2 || e.ColumnIndex < r.c1 || e.ColumnIndex > r.c2) continue;
            var union = LimitesCombinacionHoja(r);
            if (union == null) return;
            var ancla = hoja[r.c1, r.f1];
            if (EstaEditandoCombinacionHoja(e.RowIndex, e.ColumnIndex)) return;
            TextRenderer.DrawText(e.Graphics, Convert.ToString(ancla.Value), ancla.Style.Font ?? hoja.Font,
                union.Value, ancla.Style.ForeColor, FormatoTextoCombinadoMetrado(ancla));
            return;
        }
        e.Paint(e.ClipBounds, DataGridViewPaintParts.ContentForeground | DataGridViewPaintParts.ErrorIcon);
    }
}
