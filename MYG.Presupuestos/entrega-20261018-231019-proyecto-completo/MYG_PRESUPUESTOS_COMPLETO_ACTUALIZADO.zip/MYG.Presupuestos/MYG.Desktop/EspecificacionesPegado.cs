using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace MYG_2027;

internal enum MYGFormatoPegado { Automatico, Rtf, Html, Texto }

/// <summary>Copia inmutable de los datos: cambiar el portapapeles mientras se elige no altera el pegado.</summary>
internal sealed record MYGEspecificacionesPortapapeles(string Rtf, string Html, string Texto)
{
    internal bool Disponible(MYGFormatoPegado formato) => formato switch
    {
        MYGFormatoPegado.Rtf => !string.IsNullOrEmpty(Rtf),
        MYGFormatoPegado.Html => !string.IsNullOrEmpty(Html),
        MYGFormatoPegado.Texto => Texto != null,
        _ => !string.IsNullOrEmpty(Rtf) || !string.IsNullOrEmpty(Html) || Texto != null
    };
}

internal sealed record MYGEspecificacionesContenidoPegado(string Rtf, string Texto);

internal static class MYGEspecificacionesPegado
{
    internal static MYGEspecificacionesPortapapeles Capturar(IDataObject datos)
    {
        if (datos == null) return new(null, null, null);
        string Leer(string formato, bool convertir, Encoding encoding)
        {
            if (!datos.GetDataPresent(formato, convertir)) return null;
            object valor = datos.GetData(formato, convertir);
            if (valor is string texto) return texto.TrimEnd('\0');
            if (valor is MemoryStream memoria) return encoding.GetString(memoria.ToArray()).TrimEnd('\0');
            return null;
        }
        return new(Leer(DataFormats.Rtf, false, Encoding.Latin1), Leer(DataFormats.Html, false, Encoding.UTF8),
            Leer(DataFormats.UnicodeText, true, Encoding.Unicode) ?? Leer(DataFormats.Text, true, Encoding.Latin1));
    }

    /// <summary>Prepara todo el contenido antes de tocar el documento o registrar su historial.</summary>
    internal static MYGEspecificacionesContenidoPegado Preparar(MYGEspecificacionesPortapapeles datos, MYGFormatoPegado formato)
    {
        ArgumentNullException.ThrowIfNull(datos);
        if (!datos.Disponible(formato)) return null;
        if (formato == MYGFormatoPegado.Automatico)
            formato = datos.Disponible(MYGFormatoPegado.Rtf) ? MYGFormatoPegado.Rtf
                : datos.Disponible(MYGFormatoPegado.Html) ? MYGFormatoPegado.Html : MYGFormatoPegado.Texto;
        if (formato == MYGFormatoPegado.Texto) return new(null, datos.Texto);
        string rtf = formato == MYGFormatoPegado.Html ? MYGEspecificacionesHtmlPegado.Convertir(datos.Html).Rtf : datos.Rtf;
        // RichEdit valida la copia; se conserva el RTF original, incluido su formato mixto.
        using var validar = new RichTextBox { Rtf = rtf };
        return new(rtf, null);
    }

    internal static MYGEspecificacionesContenidoPegado Mostrar(IWin32Window propietario, MYGEspecificacionesPortapapeles datos)
    {
        using var dialogo = new MYGEspecificacionesPegadoForm(datos);
        return dialogo.ShowDialog(propietario) == DialogResult.OK ? dialogo.Contenido : null;
    }

    internal static void Aplicar(RichTextBox documento, MYGEspecificacionesContenidoPegado contenido)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (contenido == null || documento.ReadOnly) return;
        if (contenido.Rtf != null) documento.SelectedRtf = contenido.Rtf;
        else documento.SelectedText = contenido.Texto ?? "";
    }
}

internal sealed class MYGEspecificacionesPegadoForm : Form
{
    private readonly MYGEspecificacionesPortapapeles datos;
    private readonly ListBox formatos;
    private readonly Button aceptar;
    internal MYGEspecificacionesContenidoPegado Contenido { get; private set; }
    internal ListBox Formatos => formatos;

    internal MYGEspecificacionesPegadoForm(MYGEspecificacionesPortapapeles datos)
    {
        this.datos = datos ?? throw new ArgumentNullException(nameof(datos));
        Name = "espec_pegado_especial"; Text = "Pegado Especial";
        StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
        ClientSize = new(570, 345); AutoScaleMode = AutoScaleMode.Dpi;
        Controls.Add(new Label { Text = "Pegar Como:", AutoSize = true, Location = new(18, 18) });
        formatos = new ListBox
        {
            Name = "espec_pegado_formatos", AccessibleName = "Formato de pegado", Location = new(18, 45), Size = new(534, 240),
            DrawMode = DrawMode.OwnerDrawFixed, ItemHeight = Math.Max(24, Font.Height + 8), IntegralHeight = false,
            BorderStyle = BorderStyle.FixedSingle
        };
        formatos.Items.AddRange(new object[] { "Pegar", "Texto con Formato (RTF)", "Formato HTML", "Texto sin formato" });
        formatos.DrawItem += DibujarFormato;
        formatos.SelectedIndexChanged += (_, _) => aceptar.Enabled = formatos.SelectedIndex >= 0 && datos.Disponible((MYGFormatoPegado)formatos.SelectedIndex);
        formatos.DoubleClick += (_, _) => { if (aceptar.Enabled) Aceptar(); };
        aceptar = new Button { Name = "espec_pegado_aceptar", Text = "Aceptar", Width = 100, Height = 29, Location = new(342, 302) };
        var cancelar = new Button { Name = "espec_pegado_cancelar", Text = "Cancelar", Width = 100, Height = 29, Location = new(452, 302), DialogResult = DialogResult.Cancel };
        aceptar.Click += (_, _) => Aceptar();
        Controls.AddRange(new Control[] { formatos, aceptar, cancelar }); AcceptButton = aceptar; CancelButton = cancelar;
        formatos.SelectedIndex = 0;
        MYG2027_TemaComercial.Aplicar(this);
    }

    private void DibujarFormato(object sender, DrawItemEventArgs e)
    {
        if (e.Index < 0) return;
        bool disponible = datos.Disponible((MYGFormatoPegado)e.Index);
        bool seleccionado = (e.State & DrawItemState.Selected) != 0;
        using var fondo = new SolidBrush(seleccionado ? SystemColors.Highlight : formatos.BackColor);
        e.Graphics.FillRectangle(fondo, e.Bounds);
        Color color = disponible ? seleccionado ? SystemColors.HighlightText : formatos.ForeColor : SystemColors.GrayText;
        TextRenderer.DrawText(e.Graphics, (string)formatos.Items[e.Index], formatos.Font, Rectangle.Inflate(e.Bounds, -5, 0), color,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        e.DrawFocusRectangle();
    }

    private void Aceptar()
    {
        if (!aceptar.Enabled) return;
        try
        {
            Contenido = MYGEspecificacionesPegado.Preparar(datos, (MYGFormatoPegado)formatos.SelectedIndex);
            if (Contenido != null) DialogResult = DialogResult.OK;
        }
        catch (ArgumentException ex)
        {
            MessageBox.Show(this, "No se puede pegar este contenido en el formato elegido.\n" + ex.Message,
                "Pegado Especial", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
