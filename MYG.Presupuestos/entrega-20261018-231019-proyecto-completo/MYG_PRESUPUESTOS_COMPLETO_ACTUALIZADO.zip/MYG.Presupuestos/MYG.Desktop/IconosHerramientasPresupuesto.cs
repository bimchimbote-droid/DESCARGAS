using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace MYG_2027;

/// <summary>Iconos propios de las herramientas del presupuesto. El llamador libera el bitmap devuelto.</summary>
internal static class MYGIconosHerramientasPresupuesto
{
    private static readonly Color Azul = Color.FromArgb(78, 133, 211);
    private static readonly Color AzulOscuro = Color.FromArgb(56, 96, 163);
    private static readonly Color AzulClaro = Color.FromArgb(173, 205, 249);
    private static readonly Color BordeHoja = Color.FromArgb(123, 151, 190);
    private static readonly Color Oro = Color.FromArgb(210, 153, 42);

    internal static Bitmap Obtener(string nombre)
    {
        // Se dibuja a triple resolución para conservar bordes suaves también con escalado de pantalla.
        using var original = new Bitmap(96, 96, PixelFormat.Format32bppPArgb);
        using (var g = Graphics.FromImage(original))
        {
            g.Clear(Color.Transparent);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.ScaleTransform(3, 3);
            switch ((nombre ?? "").ToLowerInvariant())
            {
                case "detalle": DibujarDetalle(g); break;
                case "arriba": DibujarFlecha(g, false); break;
                case "abajo": DibujarFlecha(g, true); break;
                case "eliminar": DibujarEliminar(g); break;
                case "copiar": DibujarCopiar(g); break;
                case "pegar": DibujarPegar(g); break;
                case "recalcular": DibujarRecalcular(g); break;
                case "fuente": DibujarFuente(g); break;
                case "vista": DibujarVista(g); break;
                case "calculadora": DibujarCalculadora(g); break;
                case "grabar": DibujarGrabar(g); break;
                default: throw new ArgumentException("Herramienta de presupuesto desconocida.", nameof(nombre));
            }
        }

        var imagen = new Bitmap(32, 32, PixelFormat.Format32bppPArgb);
        try
        {
            using var g = Graphics.FromImage(imagen);
            g.CompositingMode = CompositingMode.SourceCopy;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.DrawImage(original, new Rectangle(0, 0, 32, 32), 0, 0, 96, 96, GraphicsUnit.Pixel);
            return imagen;
        }
        catch
        {
            imagen.Dispose();
            throw;
        }
    }

    private static void DibujarDetalle(Graphics g)
    {
        Degradado(g, new(2.5f, 2.5f, 27, 27), Color.FromArgb(255, 243, 150), Color.FromArgb(255, 211, 65));
        Marco(g, Color.FromArgb(220, 165, 38), 1, new(2.5f, 2.5f, 27, 27));
        Relleno(g, Color.FromArgb(250, 252, 255), new(7, 6.5f, 17, 19));
        Marco(g, AzulOscuro, 1.1f, new(7, 6.5f, 17, 19));
        Relleno(g, Azul, new(8, 7.5f, 3.5f, 17));
        Poligono(g, Color.White, new(13, 10), new(20, 10), new(20, 7), new(28, 16), new(20, 25), new(20, 21.5f), new(13, 21.5f));
        Poligono(g, Color.FromArgb(232, 171, 39), new(14, 12), new(21, 12), new(21, 10), new(26.2f, 16), new(21, 22), new(21, 19.5f), new(14, 19.5f));
    }

    private static void DibujarFlecha(Graphics g, bool abajo)
    {
        var estado = g.Save();
        if (abajo)
        {
            g.TranslateTransform(32, 32);
            g.RotateTransform(180);
        }
        using var forma = new GraphicsPath();
        forma.AddPolygon(new[] { new PointF(16, 3), new(27, 14), new(21, 14), new(21, 28), new(11, 28), new(11, 14), new(5, 14) });
        using var relleno = new LinearGradientBrush(new PointF(8, 6), new PointF(24, 26), AzulClaro, Azul);
        using var borde = new Pen(AzulOscuro, 1.1f) { LineJoin = LineJoin.Round };
        g.FillPath(relleno, forma);
        g.DrawPath(borde, forma);
        Linea(g, Color.FromArgb(225, 239, 255), 1.1f, new(9, 12.5f), new(16, 5.5f), new(22.5f, 12));
        Linea(g, Color.FromArgb(225, 239, 255), 1, new(12.5f, 15), new(12.5f, 26));
        g.Restore(estado);
    }

    private static void DibujarEliminar(Graphics g)
    {
        using var forma = new GraphicsPath();
        forma.AddPolygon(new[] { new PointF(8, 4), new(16, 12), new(24, 4), new(28, 8), new(20, 16), new(28, 24), new(24, 28), new(16, 20), new(8, 28), new(4, 24), new(12, 16), new(4, 8) });
        using var relleno = new LinearGradientBrush(new PointF(6, 5), new PointF(25, 27), Color.FromArgb(247, 145, 129), Color.FromArgb(210, 56, 45));
        using var borde = new Pen(Color.FromArgb(172, 62, 53), 1) { LineJoin = LineJoin.Round };
        g.FillPath(relleno, forma);
        g.DrawPath(borde, forma);
        Linea(g, Color.FromArgb(255, 205, 190), 1.2f, new(7, 8), new(16, 17));
        Linea(g, Color.FromArgb(255, 205, 190), 1.2f, new(18, 13), new(24, 7));
    }

    private static void DibujarCopiar(Graphics g)
    {
        Hoja(g, 10, 3, 16, 21, Color.FromArgb(225, 235, 250));
        Hoja(g, 5, 8, 16, 21, Color.White);
        Linea(g, Color.FromArgb(211, 224, 240), 1, new(8, 12), new(17.5f, 12));
        Linea(g, Color.FromArgb(211, 224, 240), 1, new(8, 15.5f), new(17.5f, 15.5f));
    }

    private static void DibujarPegar(Graphics g)
    {
        Degradado(g, new(5, 4.5f, 19, 24), Color.FromArgb(255, 230, 166), Color.FromArgb(217, 175, 92));
        Marco(g, Oro, 1.2f, new(5, 4.5f, 19, 24));
        Relleno(g, Color.FromArgb(225, 232, 239), new(10, 2.5f, 10, 5));
        Marco(g, BordeHoja, 1, new(10, 2.5f, 10, 5));
        Hoja(g, 11, 11, 16, 19, Color.White);
        Linea(g, Color.FromArgb(190, 207, 226), 1, new(14, 16), new(24, 16));
        Linea(g, Color.FromArgb(190, 207, 226), 1, new(14, 20), new(24, 20));
        Linea(g, Color.FromArgb(190, 207, 226), 1, new(14, 24), new(22, 24));
    }

    private static void DibujarRecalcular(Graphics g)
    {
        using var trazo = new Pen(Azul, 4.4f) { StartCap = LineCap.Round, EndCap = LineCap.Flat };
        g.DrawArc(trazo, 5.5f, 5.5f, 21, 21, 192, 145);
        g.DrawArc(trazo, 5.5f, 5.5f, 21, 21, 12, 145);
        Poligono(g, Azul, new(28.5f, 3), new(28, 14), new(18, 9.5f));
        Poligono(g, Azul, new(3.5f, 29), new(4, 18), new(14, 22.5f));
        using var brillo = new Pen(AzulClaro, .9f);
        g.DrawArc(brillo, 5.5f, 5.5f, 21, 21, 205, 89);
        g.DrawArc(brillo, 5.5f, 5.5f, 21, 21, 25, 89);
    }

    private static void DibujarFuente(Graphics g)
    {
        // La letra es vectorial para que el icono no dependa de las fuentes instaladas.
        using var letra = new Pen(Azul, 3) { StartCap = LineCap.Square, EndCap = LineCap.Square, LineJoin = LineJoin.Round };
        g.DrawLines(letra, new[] { new PointF(4.5f, 25), new(12.5f, 4.5f), new(20.5f, 25) });
        g.DrawLine(letra, 8, 17, 17, 17);
        Poligono(g, Color.FromArgb(187, 49, 46), new(15, 26), new(25.5f, 13.5f), new(29, 16.5f), new(18.5f, 29));
        Poligono(g, Color.FromArgb(244, 110, 91), new(15, 26), new(25.5f, 13.5f), new(27, 14.8f), new(16.5f, 27.3f));
        Poligono(g, Color.FromArgb(250, 219, 170), new(15, 26), new(18.5f, 29), new(13, 30));
        Poligono(g, Color.FromArgb(69, 76, 91), new(13.8f, 27.8f), new(15.2f, 29.5f), new(13, 30));
        Poligono(g, Color.FromArgb(185, 200, 216), new(25.5f, 13.5f), new(27.3f, 11.4f), new(30.8f, 14.4f), new(29, 16.5f));
    }

    private static void DibujarVista(Graphics g)
    {
        using var ojo = new GraphicsPath();
        ojo.AddBezier(2.5f, 16, 10, 5, 22, 5, 29.5f, 16);
        ojo.AddBezier(29.5f, 16, 22, 27, 10, 27, 2.5f, 16);
        using var blanco = new SolidBrush(Color.FromArgb(244, 250, 255));
        using var borde = new Pen(Azul, 2.5f) { LineJoin = LineJoin.Round };
        g.FillPath(blanco, ojo);
        g.DrawPath(borde, ojo);
        Elipse(g, Color.FromArgb(100, 166, 80), new(10, 10, 12, 12));
        using var iris = new Pen(Color.FromArgb(63, 128, 67), 1);
        g.DrawEllipse(iris, 10, 10, 12, 12);
        Elipse(g, Color.FromArgb(53, 83, 115), new(13, 13, 6, 6));
        Elipse(g, Color.White, new(12.5f, 11.5f, 3, 3));
    }

    private static void DibujarCalculadora(Graphics g)
    {
        Degradado(g, new(6, 2.5f, 20, 27), Color.FromArgb(189, 211, 243), Color.FromArgb(113, 153, 208));
        Marco(g, AzulOscuro, 1, new(6, 2.5f, 20, 27));
        Relleno(g, Color.FromArgb(241, 250, 233), new(9, 6, 14, 6));
        Marco(g, BordeHoja, .8f, new(9, 6, 14, 6));
        Linea(g, Color.FromArgb(119, 148, 125), .9f, new(18, 8), new(20.5f, 8), new(20.5f, 10));
        for (var fila = 0; fila < 3; fila++)
        {
            for (var columna = 0; columna < 3; columna++)
            {
                var r = new RectangleF(9 + columna * 5, 15 + fila * 4.3f, 3.2f, 2.8f);
                Relleno(g, columna == 2 && fila == 2 ? Color.FromArgb(243, 188, 73) : Color.FromArgb(240, 246, 255), r);
                Marco(g, AzulOscuro, .65f, r);
            }
        }
    }

    private static void DibujarGrabar(Graphics g)
    {
        Poligono(g, AzulOscuro, new(3, 3), new(19, 3), new(23, 7), new(23, 27), new(3, 27));
        Relleno(g, Azul, new(4, 4, 18, 22));
        Relleno(g, Color.FromArgb(239, 245, 254), new(7, 4, 11, 8));
        Relleno(g, AzulOscuro, new(14, 5, 2.5f, 5));
        Relleno(g, Color.FromArgb(238, 245, 255), new(7, 16, 12, 10));
        Linea(g, AzulClaro, 1, new(9, 19), new(17, 19));
        Linea(g, AzulClaro, 1, new(9, 22), new(16, 22));
        Degradado(g, new(17, 14, 12, 14), Color.FromArgb(255, 230, 161), Color.FromArgb(213, 157, 55), LinearGradientMode.Horizontal);
        Elipse(g, Color.FromArgb(213, 157, 55), new(17, 25, 12, 5));
        using var borde = new Pen(Color.FromArgb(163, 117, 43), .9f);
        g.DrawArc(borde, 17, 25, 12, 5, 0, 180);
        g.DrawLine(borde, 17, 14.5f, 17, 27.5f);
        g.DrawLine(borde, 29, 14.5f, 29, 27.5f);
        g.DrawArc(borde, 17, 17, 12, 5, 0, 180);
        g.DrawArc(borde, 17, 21, 12, 5, 0, 180);
        Elipse(g, Color.FromArgb(255, 237, 188), new(17, 11.5f, 12, 5));
        g.DrawEllipse(borde, 17, 11.5f, 12, 5);
    }

    private static void Hoja(Graphics g, float x, float y, float ancho, float alto, Color fondo)
    {
        Relleno(g, fondo, new(x, y, ancho, alto));
        Marco(g, BordeHoja, 1.1f, new(x, y, ancho, alto));
        Linea(g, Color.FromArgb(232, 240, 251), .8f, new(x + 1.6f, y + alto - 1.5f), new(x + 1.6f, y + 1.5f), new(x + ancho - 1.5f, y + 1.5f));
    }

    private static void Degradado(Graphics g, RectangleF r, Color inicio, Color fin, LinearGradientMode direccion = LinearGradientMode.Vertical)
    {
        using var relleno = new LinearGradientBrush(r, inicio, fin, direccion);
        g.FillRectangle(relleno, r);
    }

    private static void Relleno(Graphics g, Color color, RectangleF r)
    {
        using var relleno = new SolidBrush(color);
        g.FillRectangle(relleno, r);
    }

    private static void Marco(Graphics g, Color color, float ancho, RectangleF r)
    {
        using var borde = new Pen(color, ancho);
        g.DrawRectangle(borde, r.X, r.Y, r.Width, r.Height);
    }

    private static void Poligono(Graphics g, Color color, params PointF[] puntos)
    {
        using var relleno = new SolidBrush(color);
        g.FillPolygon(relleno, puntos);
    }

    private static void Linea(Graphics g, Color color, float ancho, params PointF[] puntos)
    {
        using var trazo = new Pen(color, ancho) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
        g.DrawLines(trazo, puntos);
    }

    private static void Elipse(Graphics g, Color color, RectangleF r)
    {
        using var relleno = new SolidBrush(color);
        g.FillEllipse(relleno, r);
    }
}
