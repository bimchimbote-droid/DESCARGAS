using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;

namespace MYG_2027;

internal sealed partial class MYGGraficoIncidencia
{
    private readonly List<(RectangleF Area, MYGIncidenciaCosto Valor, float Y)> columnasInteractivas = new();
    private MYGIncidenciaCosto datoResaltado;
    private PointF? puntoResaltado;
    private Rectangle destinoPantalla;
    private RectangleF areaColumnasPantalla;
    private float escalaPantalla;
    private readonly List<(MYGIncidenciaCosto Valor, PointF Ancla, string TextoEje)> referenciasInteractivas = new();
    private RectangleF areaDatosPantalla;
    private bool ejesCartesianosPantalla, horizontalPantalla;

    private void RegistrarRegion(Graphics g, Region area, MYGIncidenciaCosto valor)
    {
        regiones.Add((area, valor));
        if (!ReferenceEquals(datoResaltado, valor) || !configuracion.MostrarAyudas) return;
        Color trama = System.Windows.Forms.SystemInformation.HighContrast
            ? SystemColors.WindowText : Color.FromArgb(135, Color.White);
        using var tramado = new HatchBrush(HatchStyle.LightDownwardDiagonal, trama, Color.Transparent);
        g.FillRegion(tramado, area);
    }

    private void CambiarTamanoTexto(object sender, EventArgs e)
    {
        if (IsDisposed || Disposing) return;
        LimpiarResaltado(); LimpiarRegiones(); columnasInteractivas.Clear();
        ActualizarEscalaTextoHerramientas();
        Invalidate();
    }

    private void LimpiarResaltado()
    { datoResaltado = null; puntoResaltado = null; }

    private static string NumeroEje(double valor) => valor.ToString("#,##0.##", CultureInfo.InvariantCulture);

    private (Color Superior, Color Inferior) DegradadoColumna(int serie, Color color)
    {
        if (configuracion.Paleta == "Clasica" && serie < 4)
            return serie switch
            {
                0 => (Color.FromArgb(39, 145, 245), Color.FromArgb(43, 97, 150)),
                1 => (Color.FromArgb(231, 0, 5), Color.FromArgb(144, 9, 25)),
                2 => (Color.FromArgb(11, 114, 5), Color.FromArgb(25, 85, 22)),
                _ => (Color.FromArgb(135, 192, 226), Color.FromArgb(105, 152, 178))
            };
        return (color, Tono(color, .65f));
    }

    // La presentación clásica reproduce el gráfico de columnas de la referencia.
    // El resto de tipos y sus opciones conserva su propio dibujador.
    private void DibujarColumnasReferencia(Graphics g, RectangleF r, MYGTipoGraficoIncidencia tipo,
        Font fuente, Color tinta, Color fondo, bool registrar)
    {
        double minimo = configuracion.MinimoEje != 0 ? (double)configuracion.MinimoEje : Math.Min(0, (double)datos.Min(d => d.Importe));
        double maximo = configuracion.MaximoEje != 0 ? (double)configuracion.MaximoEje : Math.Max(0, (double)datos.Max(d => d.Importe)) * 1.1;
        if (maximo <= minimo) maximo = minimo + Math.Max(1, Math.Abs(minimo) * .1);
        double bruto = (maximo - minimo) / 5;
        double potencia = Math.Pow(10, Math.Floor(Math.Log10(bruto)));
        double normal = bruto / potencia;
        double pasoEje = (normal < 1.5 ? 1 : normal < 3.5 ? 2 : normal < 7.5 ? 5 : 10) * potencia;
        var marcas = new List<double>();
        for (double v = Math.Ceiling(minimo / pasoEje) * pasoEje; v <= maximo && marcas.Count < 20; v += pasoEje) marcas.Add(v);
        float altoTexto = fuente.GetHeight(g);
        float margenIzquierdo = configuracion.MostrarEjes
            ? marcas.Select(v => g.MeasureString(NumeroEje(v), fuente).Width).DefaultIfEmpty(0).Max() + 13 : 8;
        float altoCategorias = configuracion.MostrarEjes ? altoTexto * 2 + 12 : 8;
        var area = new RectangleF(r.Left + margenIzquierdo, r.Top + 8,
            r.Width - margenIzquierdo - 8, r.Height - altoCategorias - 8);
        if (area.Width < 20 || area.Height < 15) return;
        if (registrar)
        { areaColumnasPantalla = area; areaDatosPantalla = area; ejesCartesianosPantalla = true; }
        float Pos(double v) => Math.Clamp(area.Bottom - (float)((v - minimo) / (maximo - minimo)) * area.Height, area.Top, area.Bottom);
        using var cuadricula = new Pen(Color.FromArgb(45, tinta));
        using var eje = new Pen(Color.FromArgb(135, tinta));
        foreach (double v in marcas)
        {
            float y = Pos(v);
            if (configuracion.MostrarCuadricula) g.DrawLine(cuadricula, area.Left, y, area.Right, y);
            if (configuracion.MostrarEjes)
            {
                g.DrawLine(eje, area.Left - 4, y, area.Left, y);
                Texto(g, NumeroEje(v), fuente, tinta,
                    new RectangleF(r.Left, y - altoTexto / 2, margenIzquierdo - 7, altoTexto), StringAlignment.Far);
            }
        }
        if (configuracion.MostrarEjes) g.DrawRectangle(eje, area.X, area.Y, area.Width, area.Height);
        if (configuracion.MostrarEjes)
            for (int marca = 0; marca < 80; marca++)
            {
                double v = (Math.Ceiling(minimo / (pasoEje / 4)) + marca) * (pasoEje / 4);
                if (v > maximo) break;
                float y = Pos(v);
                g.DrawLine(eje, area.Left - 2, y, area.Left, y);
            }
        float paso = area.Width / datos.Count;
        for (int n = 0; n < datos.Count; n++)
        {
            var dato = datos[n];
            float y = Pos((double)dato.Importe), cero = Pos(0), centro = area.Left + (n + .5f) * paso;
            var barra = new RectangleF(centro - paso * .3f, Math.Min(y, cero), paso * .6f, Math.Max(1, Math.Abs(cero - y)));
            Color color = ColorSerie(n);
            var degradado = DegradadoColumna(n, color);
            using (var gradiente = new LinearGradientBrush(barra, degradado.Superior, degradado.Inferior, 90))
            using (var borde = new Pen(Tono(color, .75f)))
            {
                // Los modos de apariencia adicionales siguen distinguiéndose.
                if (System.Windows.Forms.SystemInformation.HighContrast)
                { using var solido = new SolidBrush(color); g.FillRectangle(solido, barra); }
                else if (configuracion.Apariencia is 0 or 1 or 4) g.FillRectangle(gradiente, barra);
                else { using var solido = new SolidBrush(color); g.FillRectangle(solido, barra); }
                g.DrawRectangle(borde, barra.X, barra.Y, barra.Width, barra.Height);
            }
            if (registrar)
            {
                RegistrarRegion(g, new Region(barra), dato);
                columnasInteractivas.Add((barra, dato, y));
                referenciasInteractivas.Add((dato, new PointF(centro, y), NumeroEje(Math.Round((double)dato.Importe))));
            }
            if (configuracion.MostrarEtiquetas)
            {
                string texto = Etiqueta(dato);
                if (texto.Length > 0)
                {
                    var medida = g.MeasureString(texto, fuente);
                    float ancho = Math.Min(r.Width, medida.Width + 4), alto = medida.Height + 2;
                    bool fuera = barra.Height < alto * 1.5f;
                    float etiquetaY = fuera ? barra.Top - alto - 10 : barra.Top + (barra.Height - alto) / 2;
                    var etiqueta = new RectangleF(Math.Clamp(centro - ancho / 2, r.Left, Math.Max(r.Left, r.Right - ancho)),
                        Math.Max(r.Top, etiquetaY), ancho, alto);
                    if (fuera) g.DrawLine(eje, centro, etiqueta.Bottom, centro, barra.Top);
                    using var blanco = new SolidBrush(fondo); using var borde = new Pen(color);
                    g.FillRectangle(blanco, etiqueta); g.DrawRectangle(borde, etiqueta.X, etiqueta.Y, etiqueta.Width, etiqueta.Height);
                    Texto(g, texto, fuente, color, etiqueta);
                }
            }
            if (configuracion.MostrarEjes)
            {
                g.DrawLine(eje, centro, area.Bottom, centro, area.Bottom + 4);
                float alto = altoTexto + 3;
                float ancho = Math.Min(area.Width, Math.Max(paso, g.MeasureString(dato.Nombre, fuente).Width + 4));
                var etiqueta = new RectangleF(Math.Clamp(centro - ancho / 2, area.Left, Math.Max(area.Left, area.Right - ancho)),
                    area.Bottom + 5 + (n % 2 == 0 ? alto : 0), ancho, alto);
                Texto(g, dato.Nombre.Replace("SUBCONTRATOS", "SUB-CONTRATOS"), fuente, tinta, etiqueta);
            }
        }
    }

    private void DibujarSeguimiento(Graphics g, RectangleF lienzo, Font fuente, Color fondo, Color tinta)
    {
        if (!configuracion.MostrarAyudas || !regiones.Any(r => ReferenceEquals(r.Valor, datoResaltado))) return;
        var area = areaDatosPantalla;
        if (area.Width <= 0 || area.Height <= 0) return;
        var referencia = referenciasInteractivas.FirstOrDefault(r => ReferenceEquals(r.Valor, datoResaltado));
        PointF punto = puntoResaltado.Value;
        float x = Math.Clamp(horizontalPantalla && referencia.Valor != null ? referencia.Ancla.X : punto.X, area.Left, area.Right);
        float y = Math.Clamp(!horizontalPantalla && referencia.Valor != null ? referencia.Ancla.Y : punto.Y, area.Top, area.Bottom);
        using var cruz = new Pen(tinta);
        g.DrawLine(cruz, x, area.Top, x, area.Bottom);
        g.DrawLine(cruz, area.Left, y, area.Right, y);
        if (configuracion.MostrarEjes && ejesCartesianosPantalla && referencia.Valor != null)
        {
            string nombre = datoResaltado.Nombre.Replace("SUBCONTRATOS", "SUB-CONTRATOS");
            RecuadroEje(g, horizontalPantalla ? nombre : referencia.TextoEje, fuente,
                new PointF(area.Left - 4, y), true, lienzo);
            RecuadroEje(g, horizontalPantalla ? referencia.TextoEje : nombre, fuente,
                new PointF(x, area.Bottom + fuente.GetHeight(g) + 8), false, lienzo);
        }
        string importe = moneda + "  " + datoResaltado.Importe.ToString("#,##0.00", CultureInfo.InvariantCulture);
        var medida = g.MeasureString(importe, fuente);
        float muestra = Math.Max(9, fuente.GetHeight(g) * .85f);
        float ancho = Math.Min(lienzo.Width - 4, medida.Width + muestra + 22), alto = fuente.GetHeight(g) + 20;
        float tooltipX = punto.X + 14;
        if (tooltipX + ancho > lienzo.Right) tooltipX = punto.X - ancho - 14;
        var tooltip = new RectangleF(Math.Clamp(tooltipX, lienzo.Left, Math.Max(lienzo.Left, lienzo.Right - ancho)),
            Math.Clamp(punto.Y - alto - 9, lienzo.Top, Math.Max(lienzo.Top, lienzo.Bottom - alto)), ancho, alto);
        using var sombra = new SolidBrush(Color.FromArgb(30, Color.Black));
        g.FillRectangle(sombra, tooltip.X + 2, tooltip.Y + 2, tooltip.Width, tooltip.Height);
        using var blanco = new SolidBrush(fondo); using var borde = new Pen(Color.FromArgb(100, tinta));
        g.FillRectangle(blanco, tooltip); g.DrawRectangle(borde, tooltip.X, tooltip.Y, tooltip.Width, tooltip.Height);
        int serie = datos.IndexOf(datoResaltado);
        using var color = new SolidBrush(ColorSerie(Math.Max(0, serie)));
        g.FillRectangle(color, tooltip.X + 8, tooltip.Y + (alto - muestra) / 2, muestra, muestra);
        Texto(g, importe, fuente, tinta, new RectangleF(tooltip.X + muestra + 14, tooltip.Y,
            Math.Max(1, tooltip.Width - muestra - 18), alto), StringAlignment.Near);
    }

    private static void RecuadroEje(Graphics g, string texto, Font fuente, PointF ancla, bool izquierda, RectangleF limite)
    {
        var medida = g.MeasureString(texto, fuente);
        float ancho = Math.Min(limite.Width, medida.Width + 6), alto = medida.Height + 2;
        var caja = new RectangleF(Math.Clamp(izquierda ? ancla.X - ancho : ancla.X - ancho / 2,
            limite.Left, Math.Max(limite.Left, limite.Right - ancho)),
            Math.Clamp(izquierda ? ancla.Y - alto / 2 : ancla.Y, limite.Top, Math.Max(limite.Top, limite.Bottom - alto)), ancho, alto);
        using var negro = new SolidBrush(Color.Black); g.FillRectangle(negro, caja);
        Texto(g, texto, fuente, Color.White, caja);
    }
}
