using System;
using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGConfirmacionUI
{
    internal static bool Confirmar(IWin32Window propietario, string mensaje, string titulo)
    {
        using var dialogo = new Form { FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false, MinimizeBox = false };
        MYGProyectoUI.Preparar(dialogo, titulo, 600, 300);
        dialogo.AccessibleDescription = mensaje;
        var contenido = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(22),
            ColumnCount = 1, RowCount = 2 };
        contenido.ColumnStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Absolute, 58));
        var detalle = new TextBox { Text = mensaje, ReadOnly = true, Multiline = true,
            BorderStyle = BorderStyle.None, Dock = DockStyle.Fill, ScrollBars = ScrollBars.Vertical,
            TabStop = false, AccessibleName = "Detalle del movimiento" };
        var botones = new FlowLayoutPanel { Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft, WrapContents = false };
        var no = MYGProyectoUI.Boton("No, conservar posición");
        no.Width = 192; no.DialogResult = DialogResult.No;
        var si = MYGProyectoUI.Boton("Sí, mover", 1);
        si.Width = 126; si.DialogResult = DialogResult.Yes;
        botones.Controls.Add(no); botones.Controls.Add(si);
        contenido.Controls.Add(detalle, 0, 0); contenido.Controls.Add(botones, 0, 1);
        dialogo.Controls.Add(contenido);
        // Enter, Escape y cerrar la ventana deben conservar la posición.
        dialogo.AcceptButton = no; dialogo.CancelButton = no;
        dialogo.Shown += (s, e) => no.Focus();
        MYG2027_TemaComercial.Aplicar(dialogo);
        return dialogo.ShowDialog(propietario) == DialogResult.Yes;
    }
}
