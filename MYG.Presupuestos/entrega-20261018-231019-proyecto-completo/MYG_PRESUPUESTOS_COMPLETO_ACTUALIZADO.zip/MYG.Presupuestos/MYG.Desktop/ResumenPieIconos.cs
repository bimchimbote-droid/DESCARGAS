using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGResumenPieIconos
{
    internal static Bitmap Crear(string nombre)
    {
        if (nombre is "copiar" or "pegar" or "fuente")
            return MYGEspecificacionesCinta.DibujarIcono(nombre, 20);
        if (nombre is not ("limpiar" or "restaurar" or "opciones" or "formula")) return MYGIconos.Obtener(nombre);
        var imagen = new Bitmap(24, 24);
        using var g = Graphics.FromImage(imagen);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        Color azul = SystemInformation.HighContrast ? SystemColors.ControlText : Color.FromArgb(66, 130, 178);
        using var tinta = new Pen(azul, 1.8F);
        using var relleno = new SolidBrush(azul);
        if (nombre == "formula")
        {
            using var letra = new Font("Georgia", 12, FontStyle.Italic);
            g.DrawRectangle(tinta, 1, 1, 18, 18); g.DrawString("ƒx", letra, relleno, 1, 1);
            using var verde = new Pen(SystemInformation.HighContrast ? azul : Color.FromArgb(68, 160, 69), 3);
            g.DrawLine(verde, 18, 14, 18, 23); g.DrawLine(verde, 14, 18, 23, 18);
        }
        else if (nombre == "limpiar")
        {
            using var naranja = new SolidBrush(SystemInformation.HighContrast ? azul : Color.FromArgb(223, 118, 79));
            using var claro = new SolidBrush(SystemInformation.HighContrast ? SystemColors.Control : Color.FromArgb(168, 213, 231));
            g.FillPolygon(naranja, new[] { new Point(4, 14), new Point(13, 4), new Point(21, 11), new Point(12, 21) });
            g.FillPolygon(claro, new[] { new Point(4, 14), new Point(8, 10), new Point(16, 17), new Point(12, 21) });
            g.DrawLine(tinta, 4, 22, 21, 22);
        }
        else if (nombre == "restaurar")
        {
            g.DrawBezier(tinta, 2, 12, 7, 3, 17, 3, 22, 12);
            g.DrawBezier(tinta, 2, 12, 7, 21, 17, 21, 22, 12);
            g.FillEllipse(relleno, 8, 7, 9, 10);
            using var blanco = new SolidBrush(SystemColors.Window);
            g.FillEllipse(blanco, 10, 8, 3, 3);
        }
        else
        {
            var puntos = new PointF[32];
            for (int n = 0; n < puntos.Length; n++)
            {
                double a = n * Math.PI / 16; float radio = n % 4 is 1 or 2 ? 10 : 7.8F;
                puntos[n] = new(12 + radio * (float)Math.Cos(a), 12 + radio * (float)Math.Sin(a));
            }
            g.FillPolygon(relleno, puntos);
            using var hueco = new SolidBrush(SystemInformation.HighContrast ? SystemColors.Control : MYG2027_TemaComercial.Superficie);
            g.FillEllipse(hueco, 8, 8, 8, 8);
        }
        return imagen;
    }
}
