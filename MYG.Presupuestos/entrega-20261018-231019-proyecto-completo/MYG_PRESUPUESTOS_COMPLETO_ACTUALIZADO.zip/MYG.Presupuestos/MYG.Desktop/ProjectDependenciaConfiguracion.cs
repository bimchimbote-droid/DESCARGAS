using System;
using System.IO;

namespace MYG_2027;

internal static class MYGConfiguracionDependenciaProject
{
    /// <summary>Prepara la llamada posicional TaskDependencies.Add(From, Type, Lag).
    /// From siempre es el objeto Task original; Type es un Long COM y los
    /// desfases numéricos representan minutos, con su signo original.</summary>
    internal static object Ejecutar(MYGDependenciaExportacionProject datos, object origen,
        Func<object[], object> agregar)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(origen);
        ArgumentNullException.ThrowIfNull(agregar);
        if (datos.TareaUid <= 0 || datos.PredecesoraUid <= 0 || datos.TareaUid == datos.PredecesoraUid)
            throw new InvalidDataException("La dependencia debe conectar dos tareas existentes y distintas.");
        int tipo = datos.Tipo switch
        {
            MYGTipoVinculo.FF => 0, MYGTipoVinculo.FC => 1,
            MYGTipoVinculo.CF => 2, MYGTipoVinculo.CC => 3,
            _ => throw new InvalidDataException("Tipo de dependencia de Microsoft Project desconocido.")
        };
        // Lag es Variant en la API oficial: cualquier valor numérico se
        // interpreta como minutos. Usar Int32 para los enteros representables
        // mejora la interoperabilidad sin eliminar fracciones admitidas por MYG.
        object minutos = datos.DesfaseMinutos == decimal.Truncate(datos.DesfaseMinutos) &&
            datos.DesfaseMinutos >= int.MinValue && datos.DesfaseMinutos <= int.MaxValue
                ? (object)decimal.ToInt32(datos.DesfaseMinutos) : (double)datos.DesfaseMinutos;
        // Omitir el parámetro opcional es distinto de enviar un Double 0 a
        // IDispatch. Project aplica su valor predeterminado de cero minutos.
        // Los tres argumentos, cuando existen, se envían por posición.
        object[] argumentos = datos.DesfaseMinutos == 0
            ? new object[] { origen, tipo }
            : new object[] { origen, tipo, minutos };
        // No hay reintentos que cambien tipo, eliminen el desfase o conviertan
        // la relación en otra distinta. Los rechazos reales deben informarse.
        return agregar(argumentos) ?? throw new InvalidOperationException(
            "Microsoft Project no devolvió la dependencia creada.");
    }
}
