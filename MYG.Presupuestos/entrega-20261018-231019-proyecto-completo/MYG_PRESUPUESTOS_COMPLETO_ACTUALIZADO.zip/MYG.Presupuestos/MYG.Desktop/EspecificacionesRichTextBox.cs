using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

// La fuente base pertenece al documento y se expresa en puntos, no en la
// fuente de interfaz que WinForms escala y redondea al cambiar de pantalla.
internal sealed class MYGEspecificacionesRichTextBox : RichTextBox
{
    private Font fuenteDocumento;
    private readonly Font fuenteInicial;

    internal MYGEspecificacionesRichTextBox()
    {
        fuenteInicial = MYGEspecificacionesFormato.CrearFuenteReferencia();
        Font = fuenteInicial;
    }

    public override Font Font
    {
        get => fuenteDocumento ?? base.Font;
        set
        {
            // Un cambio explícito de Font sigue siendo una elección válida.
            // El escalado de DPI de WinForms no invoca este setter.
            fuenteDocumento = value ?? fuenteInicial ?? Control.DefaultFont;
            base.Font = fuenteDocumento;
            if (IsHandleCreated && TextLength == 0)
            {
                MYGEspecificacionesFormato.EstablecerFuentePredeterminada(this, fuenteDocumento.Name, fuenteDocumento.SizeInPoints);
                MYGEspecificacionesFormato.EstablecerFuente(this, fuenteDocumento.Name, fuenteDocumento.SizeInPoints);
            }
        }
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        if (fuenteDocumento == null) return;
        MYGEspecificacionesFormato.EstablecerFuentePredeterminada(this, fuenteDocumento.Name, fuenteDocumento.SizeInPoints);
        if (TextLength == 0)
            MYGEspecificacionesFormato.EstablecerFuente(this, fuenteDocumento.Name, fuenteDocumento.SizeInPoints);
    }

    protected override void WndProc(ref Message mensaje)
    {
        if (mensaje.Msg == 0x0030 && fuenteDocumento != null) // WM_SETFONT de la interfaz.
        {
            // RichEdit recibe sus fuentes por EM_SETCHARFORMAT/RTF. Un HFONT de
            // DPI no debe cambiar el default, la selección ni el documento.
            mensaje.Result = IntPtr.Zero;
            return;
        }
        base.WndProc(ref mensaje);
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (disposing) fuenteInicial?.Dispose();
    }
}
