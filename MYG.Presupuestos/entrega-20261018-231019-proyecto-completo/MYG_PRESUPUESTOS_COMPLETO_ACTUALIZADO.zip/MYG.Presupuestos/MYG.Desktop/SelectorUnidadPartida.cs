using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

// Selector de dos columnas: conserva el símbolo como valor y muestra su descripción sin concatenarlos.
internal sealed class MYGSelectorUnidadPartida : ToolStripDropDown
{
    private readonly DataGridView tabla;
    private readonly ToolStripControlHost alojamiento;
    private readonly Action<string> seleccionar;
    private bool confirmado;
    private Control propietario;
    internal bool Confirmado => confirmado;

    internal MYGSelectorUnidadPartida(IEnumerable<MYGUnidadCatalogo> unidades, string actual, Font fuente,
        float escala, Action<string> seleccionar)
    {
        this.seleccionar = seleccionar;
        AutoSize = false; AutoClose = true; Padding = new(1); Margin = System.Windows.Forms.Padding.Empty;
        DropShadowEnabled = true; AccessibleName = "Seleccionar unidad de medida";
        tabla = new DataGridView
        {
            AutoSize = false, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false, AllowUserToResizeColumns = false, RowHeadersVisible = false,
            MultiSelect = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoGenerateColumns = false, BorderStyle = BorderStyle.None, BackgroundColor = Color.White,
            Font = fuente, StandardTab = true, EditMode = DataGridViewEditMode.EditProgrammatically,
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
            ScrollBars = ScrollBars.Vertical, AccessibleName = "Unidades: abreviatura y descripción"
        };
        tabla.EnableHeadersVisualStyles = false;
        tabla.ColumnHeadersDefaultCellStyle.BackColor = MYGPanelPresupuesto.AzulClaro;
        tabla.DefaultCellStyle.SelectionBackColor = Color.FromArgb(213, 230, 249);
        tabla.DefaultCellStyle.SelectionForeColor = Color.FromArgb(28, 54, 85);
        tabla.DefaultCellStyle.Padding = new(5, 2, 5, 2);
        tabla.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        tabla.GridColor = Color.FromArgb(224, 232, 242);
        tabla.RowTemplate.Height = (int)Math.Round(28 * escala);
        tabla.ColumnHeadersHeight = (int)Math.Round(30 * escala);
        tabla.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "ABREVIATURA", HeaderText = "Abreviatura", Width = (int)Math.Round(115 * escala),
            SortMode = DataGridViewColumnSortMode.NotSortable
        });
        tabla.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "DESCRIPCION", HeaderText = "Descripción", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
            SortMode = DataGridViewColumnSortMode.NotSortable
        });
        foreach (var u in (unidades ?? Enumerable.Empty<MYGUnidadCatalogo>())
            .Where(u => u != null && !string.IsNullOrWhiteSpace(u.Simbolo))
            .GroupBy(u => u.Simbolo.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => g.OrderByDescending(u => u.EsCostoUnitario).ThenBy(u => u.Tipo == "N" ? 0 : 1)
                .ThenByDescending(u => !string.IsNullOrWhiteSpace(u.Descripcion) && u.Descripcion != u.Simbolo).First())
            .OrderBy(u => u.Simbolo, StringComparer.OrdinalIgnoreCase))
        {
            int n = tabla.Rows.Add(u.SimboloVisible, string.IsNullOrWhiteSpace(u.Descripcion) ? u.SimboloVisible : u.Descripcion.Trim());
            tabla.Rows[n].Tag = u.Simbolo.Trim();
        }
        alojamiento = new ToolStripControlHost(tabla) { AutoSize = false, Margin = System.Windows.Forms.Padding.Empty, Padding = System.Windows.Forms.Padding.Empty };
        Items.Add(alojamiento);
        tabla.CellMouseClick += (s, e) => { if (e.Button == MouseButtons.Left && e.RowIndex >= 0) Confirmar(); };
        tabla.KeyDown += (s, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            { e.Handled = e.SuppressKeyPress = true; Confirmar(); }
            else if (e.KeyCode is Keys.Escape or Keys.Tab)
            { e.Handled = e.SuppressKeyPress = true; Close(ToolStripDropDownCloseReason.Keyboard); }
            else if (!e.Control && !e.Alt && e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z)
            {
                // Buscar por inicial sin activar una tercera columna o un campo adicional.
                string inicial = ((char)('a' + (int)e.KeyCode - (int)Keys.A)).ToString();
                int inicio = (tabla.CurrentRow?.Index ?? -1) + 1;
                for (int n = 0; n < tabla.Rows.Count; n++)
                {
                    var fila = tabla.Rows[(inicio + n) % tabla.Rows.Count];
                    if (!Convert.ToString(fila.Tag).StartsWith(inicial, StringComparison.OrdinalIgnoreCase)) continue;
                    tabla.CurrentCell = fila.Cells[0]; e.Handled = e.SuppressKeyPress = true; break;
                }
            }
        };
        var elegida = tabla.Rows.Cast<DataGridViewRow>().FirstOrDefault(r =>
            string.Equals(Convert.ToString(r.Tag), actual, StringComparison.OrdinalIgnoreCase));
        if (elegida != null) tabla.CurrentCell = elegida.Cells[0];
        else if (tabla.Rows.Count > 0) tabla.CurrentCell = tabla.Rows[0].Cells[0];
        Closed += (s, e) =>
        {
            // El cierre puede nacer de CellMouseClick: disponer el grid una vez terminado ese evento.
            if (propietario != null && !propietario.IsDisposed && propietario.IsHandleCreated)
                propietario.BeginInvoke(new Action(Dispose));
            else Dispose();
        };
    }

    internal void Abrir(Control propietario, Rectangle celdaPantalla)
    {
        this.propietario = propietario;
        AplicarTema();
        var area = Screen.FromRectangle(celdaPantalla).WorkingArea;
        float escala = propietario.DeviceDpi / 96F;
        int ancho = Math.Min(area.Width, Math.Max(celdaPantalla.Width, (int)Math.Round(390 * escala)));
        int altoDeseado = tabla.ColumnHeadersHeight + Math.Max(1, Math.Min(10, tabla.Rows.Count)) * tabla.RowTemplate.Height + 2;
        int debajo = Math.Max(0, area.Bottom - celdaPantalla.Bottom), encima = Math.Max(0, celdaPantalla.Top - area.Top);
        bool arriba = debajo < altoDeseado && encima > debajo;
        int alto = Math.Max(1, Math.Min(altoDeseado, arriba ? encima : debajo));
        Size = new(ancho, alto); alojamiento.Size = new(Math.Max(1, ancho - 2), Math.Max(1, alto - 2));
        tabla.Size = alojamiento.Size;
        int x = Math.Clamp(celdaPantalla.Left, area.Left, Math.Max(area.Left, area.Right - ancho));
        int y = arriba ? celdaPantalla.Top - alto : celdaPantalla.Bottom;
        Show(propietario, propietario.PointToClient(new Point(x, y)));
        tabla.Focus();
        if (tabla.CurrentRow != null) tabla.FirstDisplayedScrollingRowIndex = tabla.CurrentRow.Index;
    }

    internal void AplicarTema()
    {
        if (IsDisposed || tabla.IsDisposed) return;
        // El selector usa la misma paleta que la grilla que lo abre. Así acompaña
        // cambios de tema sin depender de propiedades añadidas en otras versiones.
        var origen = propietario as DataGridView;
        Color Usar(Color? color, Color respaldo) => color.HasValue && !color.Value.IsEmpty ? color.Value : respaldo;
        var fondo = Usar(origen?.BackgroundColor, Color.White);
        var texto = Usar(origen?.DefaultCellStyle.ForeColor, MYG2027_TemaComercial.Texto);
        var seleccion = Usar(origen?.DefaultCellStyle.SelectionBackColor, Color.FromArgb(213, 230, 249));
        var textoSeleccion = Usar(origen?.DefaultCellStyle.SelectionForeColor, texto);
        var cabecera = Usar(origen?.ColumnHeadersDefaultCellStyle.BackColor, MYG2027_TemaComercial.Marino);
        var textoCabecera = Usar(origen?.ColumnHeadersDefaultCellStyle.ForeColor, Color.White);
        BackColor = tabla.BackgroundColor = fondo;
        ForeColor = tabla.ForeColor = texto;
        tabla.EnableHeadersVisualStyles = false;
        tabla.GridColor = Usar(origen?.GridColor, MYG2027_TemaComercial.Borde);
        tabla.DefaultCellStyle.BackColor = fondo;
        tabla.DefaultCellStyle.ForeColor = texto;
        tabla.DefaultCellStyle.SelectionBackColor = seleccion;
        tabla.DefaultCellStyle.SelectionForeColor = textoSeleccion;
        tabla.AlternatingRowsDefaultCellStyle.BackColor = Usar(origen?.AlternatingRowsDefaultCellStyle.BackColor, fondo);
        tabla.AlternatingRowsDefaultCellStyle.ForeColor = texto;
        tabla.AlternatingRowsDefaultCellStyle.SelectionBackColor = seleccion;
        tabla.AlternatingRowsDefaultCellStyle.SelectionForeColor = textoSeleccion;
        tabla.ColumnHeadersDefaultCellStyle.BackColor = cabecera;
        tabla.ColumnHeadersDefaultCellStyle.ForeColor = textoCabecera;
        tabla.ColumnHeadersDefaultCellStyle.SelectionBackColor = Usar(origen?.ColumnHeadersDefaultCellStyle.SelectionBackColor, cabecera);
        tabla.ColumnHeadersDefaultCellStyle.SelectionForeColor = Usar(origen?.ColumnHeadersDefaultCellStyle.SelectionForeColor, textoCabecera);
        tabla.Invalidate(); Invalidate();
    }

    private void Confirmar()
    {
        if (confirmado || tabla.CurrentRow?.Tag is not string simbolo) return;
        confirmado = true;
        var destino = propietario;
        Close(ToolStripDropDownCloseReason.ItemClicked);
        // Salir del evento del grid antes de reconstruir las filas del presupuesto.
        if (destino != null && !destino.IsDisposed && destino.IsHandleCreated)
            destino.BeginInvoke(new Action(() => { if (!destino.IsDisposed) seleccionar(simbolo); }));
    }
}
