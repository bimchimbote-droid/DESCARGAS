using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;
namespace MYG_2027
{
    internal static class MYGProyectoUI
    {
        internal static WinForms.Button Boton(string texto, int estilo = 0)
        {
            var b = new MYG2027_BotonComercial
            {
                Text = texto,
                Height = 40,
                Width = 150,
                Margin = new WinForms.Padding(6),
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold)
            };
            MYG2027_TemaComercial.EstilizarBoton(b, estilo);
            return b;
        }
        internal static void Preparar(WinForms.Form f, string titulo, int ancho, int alto)
        {
            f.Text = "MYG Presupuestos | " + titulo; f.Font = new Drawing.Font("Segoe UI", 10F);
            f.AutoScaleDimensions = new Drawing.SizeF(96F, 96F); f.AutoScaleMode = WinForms.AutoScaleMode.Dpi;
            f.ClientSize = new Drawing.Size(ancho, alto); f.MinimumSize = new Drawing.Size(Math.Min(ancho, 520), Math.Min(alto, 340));
            f.StartPosition = WinForms.FormStartPosition.CenterParent; f.BackColor = MYG2027_TemaComercial.Fondo;
            f.ForeColor = MYG2027_TemaComercial.Texto;
            f.ShowInTaskbar = false;
            f.Shown += (s, e) => MYG2027_TemaComercial.AjustarAlAreaDeTrabajo(f);
        }
        internal static void Error(WinForms.IWin32Window propietario, Exception ex) => WinForms.MessageBox.Show(
            propietario, ex.Message, "MYG Presupuestos", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Error);
    }

    internal sealed class MYGConfiguracionOpcion
    {
        public string Id { get; set; }
        public string Texto { get; set; }
    }

    internal sealed class MYGAplicarConfiguracionSolicitud
    {
        internal ItemPresupuestoDelphin Partida { get; set; }
        internal MYGConfiguracionPartida Configuracion { get; set; }
    }

    internal static class MYGBibliotecaUI
    {
        internal static WinForms.DataGridView Tabla()
        {
            var g = new WinForms.DataGridView
            {
                Dock = WinForms.DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                AutoGenerateColumns = false,
                BackgroundColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.None,
                SelectionMode = WinForms.DataGridViewSelectionMode.CellSelect,
                AutoSizeRowsMode = WinForms.DataGridViewAutoSizeRowsMode.None,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 40,
                RowTemplate = { Height = 34 }
            };
            MYG2027_TemaComercial.EstilizarTabla(g);
            g.CurrentCellDirtyStateChanged += (s, e) =>
            { if (g.IsCurrentCellDirty) g.CommitEdit(WinForms.DataGridViewDataErrorContexts.Commit); };
            return g;
        }

        internal static WinForms.TableLayoutPanel Raiz(WinForms.Form f, string texto, string detalle)
        {
            var r = new WinForms.TableLayoutPanel
            {
                Dock = WinForms.DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new WinForms.Padding(22)
            };
            r.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            r.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, 36));
            r.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, 68));
            r.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Percent, 100));
            r.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, 106));
            r.Controls.Add(new WinForms.Label
            {
                Text = texto,
                Dock = WinForms.DockStyle.Fill,
                Font = new Drawing.Font("Segoe UI", 12F, Drawing.FontStyle.Bold),
                ForeColor = MYG2027_TemaComercial.Texto
            }, 0, 0);
            r.Controls.Add(new WinForms.Label
            {
                Text = detalle,
                Dock = WinForms.DockStyle.Fill,
                ForeColor = Drawing.Color.FromArgb(75, 92, 116)
            }, 0, 1);
            f.Controls.Add(r); return r;
        }

        internal static WinForms.FlowLayoutPanel Pie(WinForms.Button aceptar, WinForms.Button cancelar)
        {
            var pie = new WinForms.FlowLayoutPanel
            {
                Dock = WinForms.DockStyle.Bottom,
                Height = 62,
                FlowDirection = WinForms.FlowDirection.RightToLeft
            };
            pie.Controls.Add(aceptar); pie.Controls.Add(cancelar); return pie;
        }

        internal static WinForms.DataGridViewComboBoxCell Opciones(IEnumerable<MYGConfiguracionOpcion> opciones)
        {
            return new WinForms.DataGridViewComboBoxCell
            {
                DataSource = opciones.ToList(),
                DisplayMember = "Texto",
                ValueMember = "Id",
                FlatStyle = WinForms.FlatStyle.Flat,
                DisplayStyle = WinForms.DataGridViewComboBoxDisplayStyle.DropDownButton
            };
        }

        internal static string NombreSugerido(ItemPresupuestoDelphin i)
        {
            string valores = string.Join(" / ", MYGBibliotecaPartidas.FiltrosGuardables(i)
                .Where(f => !string.IsNullOrWhiteSpace(f.Valor)).Take(2).Select(f => f.Valor));
            string nombre = i.Descripcion + (string.IsNullOrWhiteSpace(valores) ? "" : " — " + valores);
            return nombre.Length > 220 ? nombre.Substring(0, 220) : nombre;
        }
    }

    internal sealed class MYGGuardarConfiguracionesForm : WinForms.Form
    {
        private readonly WinForms.DataGridView grid;
        private readonly MYGBibliotecaDocumento biblioteca;
        private bool inicializando = true;
        internal List<MYGGuardarConfiguracionSolicitud> Solicitudes { get; private set; }
        internal MYGGuardarConfiguracionesForm(IEnumerable<ItemPresupuestoDelphin> items, MYGBibliotecaDocumento b, string archivo)
        {
            biblioteca = b;
            MYGProyectoUI.Preparar(this, "Guardar filtros por partida", 1120, 620);
            var raiz = MYGBibliotecaUI.Raiz(this, "Guardar configuraciones en la biblioteca",
                "Elige las filas y el nombre de cada variante. Puedes crear una configuración o actualizar una guardada.\nBiblioteca: " + archivo);
            grid = MYGBibliotecaUI.Tabla();
            grid.Columns.Add(new WinForms.DataGridViewCheckBoxColumn { Name = "USAR", HeaderText = "Guardar", Width = 66 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn
            {
                Name = "PARTIDA",
                HeaderText = "Partida",
                ReadOnly = true,
                AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill,
                FillWeight = 120,
                MinimumWidth = 230
            });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn
            {
                Name = "NOMBRE",
                HeaderText = "Nombre de la configuración",
                AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill,
                FillWeight = 100,
                MinimumWidth = 230
            });
            grid.Columns.Add(new WinForms.DataGridViewComboBoxColumn { Name = "DESTINO", HeaderText = "Crear / actualizar", Width = 250 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "FILTROS", HeaderText = "Filtros", ReadOnly = true, Width = 60 });
            foreach (var i in items)
            {
                var disponibles = MYGBibliotecaPartidas.Disponibles(b, i);
                var anterior = disponibles.FirstOrDefault(c => c.Id == i.IdConfiguracionBibliotecaMYG)
                    ?? disponibles.FirstOrDefault(c => MYGBibliotecaPartidas.MismoContenido(i, c));
                int n = grid.Rows.Add(true, i.Item + "  " + i.Descripcion, anterior?.Nombre ?? MYGBibliotecaUI.NombreSugerido(i), null,
                    MYGBibliotecaPartidas.FiltrosGuardables(i).Count);
                var fila = grid.Rows[n]; fila.Tag = i;
                var opciones = new List<MYGConfiguracionOpcion> { new MYGConfiguracionOpcion { Id = "", Texto = "Crear nueva variante" } };
                opciones.AddRange(disponibles.Select(c => new MYGConfiguracionOpcion { Id = c.Id, Texto = "Actualizar: " + c.Nombre }));
                fila.Cells["DESTINO"] = MYGBibliotecaUI.Opciones(opciones); fila.Cells["DESTINO"].Value = anterior?.Id ?? "";
            }
            inicializando = false;
            grid.CellValueChanged += (s, e) =>
            {
                if (inicializando || e.RowIndex < 0 || e.ColumnIndex < 0 || grid.Columns[e.ColumnIndex].Name != "DESTINO") return;
                var fila = grid.Rows[e.RowIndex]; var i = fila.Tag as ItemPresupuestoDelphin;
                string id = fila.Cells["DESTINO"].Value as string;
                var c = b.Configuraciones.FirstOrDefault(x => x.Id == id);
                fila.Cells["NOMBRE"].Value = c?.Nombre ?? (MYGBibliotecaUI.NombreSugerido(i) + " (variante)");
            };
            raiz.Controls.Add(grid, 0, 2);
            var guardar = MYGProyectoUI.Boton("Guardar filtros", 1); var cancelar = MYGProyectoUI.Boton("Cancelar");
            cancelar.DialogResult = WinForms.DialogResult.Cancel;
            var pie = new WinForms.Panel { Dock = WinForms.DockStyle.Fill };
            pie.Controls.Add(new WinForms.Label
            {
                Dock = WinForms.DockStyle.Top,
                Height = 34,
                Text = "La biblioteca almacena configuraciones por partida. Cada presupuesto conserva su propia copia de los filtros."
            });
            pie.Controls.Add(MYGBibliotecaUI.Pie(guardar, cancelar)); raiz.Controls.Add(pie, 0, 3);
            guardar.Click += (s, e) =>
            {
                grid.EndEdit(); Solicitudes = new List<MYGGuardarConfiguracionSolicitud>();
                foreach (WinForms.DataGridViewRow fila in grid.Rows)
                    if (Convert.ToBoolean(fila.Cells["USAR"].Value ?? false))
                    {
                        string nombre = (fila.Cells["NOMBRE"].Value?.ToString() ?? "").Trim();
                        if (nombre.Length == 0) { WinForms.MessageBox.Show(this, "Escribe un nombre para cada configuración seleccionada.", "MYG Presupuestos"); return; }
                        Solicitudes.Add(new MYGGuardarConfiguracionSolicitud
                        {
                            Partida = fila.Tag as ItemPresupuestoDelphin,
                            Nombre = nombre,
                            IdActualizar = fila.Cells["DESTINO"].Value as string
                        });
                    }
                if (Solicitudes.Count == 0) { WinForms.MessageBox.Show(this, "Selecciona al menos una fila para guardar.", "MYG Presupuestos"); return; }
                try { MYGBibliotecaPartidas.PrepararGuardado(biblioteca, Solicitudes); }
                catch (Exception ex) { MYGProyectoUI.Error(this, ex); return; }
                DialogResult = WinForms.DialogResult.OK;
            };
            AcceptButton = guardar; CancelButton = cancelar;
        }
    }

    internal sealed class MYGAplicarConfiguracionesForm : WinForms.Form
    {
        private readonly WinForms.DataGridView grid;
        private readonly WinForms.CheckBox asociar;
        private readonly MYGBibliotecaDocumento biblioteca;
        private readonly Func<MYGConfiguracionPartida, string> comprobar;
        private bool inicializando = true;
        internal bool RecordarAsociaciones => asociar.Checked;
        internal List<MYGAplicarConfiguracionSolicitud> Solicitudes { get; private set; }
        internal MYGAplicarConfiguracionesForm(IEnumerable<ItemPresupuestoDelphin> items, MYGBibliotecaDocumento b,
            Func<MYGConfiguracionPartida, string> revision)
        {
            biblioteca = b; comprobar = revision;
            MYGProyectoUI.Preparar(this, "Traer filtros de biblioteca", 1160, 650);
            var raiz = MYGBibliotecaUI.Raiz(this, "Aplicar configuraciones de la biblioteca",
                "Las coincidencias únicas sin configuración se seleccionan inicialmente. Elige la variante si hay varias.\nLas opciones «Asociar» pertenecen a otra referencia: selecciónalas solo cuando correspondan a esta partida.");
            grid = MYGBibliotecaUI.Tabla();
            grid.Columns.Add(new WinForms.DataGridViewCheckBoxColumn { Name = "USAR", HeaderText = "Aplicar", Width = 65 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn
            {
                Name = "PARTIDA",
                HeaderText = "Partida de este presupuesto",
                ReadOnly = true,
                AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill,
                FillWeight = 110,
                MinimumWidth = 260
            });
            grid.Columns.Add(new WinForms.DataGridViewComboBoxColumn { Name = "CONFIG", HeaderText = "Configuración guardada", Width = 350 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "ESTADO", HeaderText = "Revisión", ReadOnly = true, Width = 280 });
            foreach (var i in items)
            {
                var exactas = MYGBibliotecaPartidas.Disponibles(b, i);
                var opciones = new List<MYGConfiguracionOpcion> { new MYGConfiguracionOpcion { Id = "", Texto = "Elegir configuración..." } };
                opciones.AddRange(exactas.Select(c => new MYGConfiguracionOpcion { Id = c.Id, Texto = c.Nombre }));
                opciones.AddRange(b.Configuraciones.Where(c => MYGProyectoStorage.MismaUnidad(c.Unidad, i.Unidad) &&
                    !exactas.Any(x => x.Id == c.Id)).OrderBy(c => c.Nombre).Select(c => new MYGConfiguracionOpcion
                    { Id = c.Id, Texto = "Asociar: " + c.Nombre }));
                var inicial = exactas.Count == 1 ? exactas[0] : exactas.FirstOrDefault(c => c.Id == i.IdConfiguracionBibliotecaMYG);
                int n = grid.Rows.Add(inicial != null && !MYGProyectoStorage.TieneBim(i), i.Item + "  " + i.Descripcion, null, "");
                var fila = grid.Rows[n]; fila.Tag = i;
                fila.Cells["CONFIG"] = MYGBibliotecaUI.Opciones(opciones); fila.Cells["CONFIG"].Value = inicial?.Id ?? "";
                ActualizarRevision(fila);
            }
            inicializando = false;
            grid.CellValueChanged += (s, e) =>
            {
                if (inicializando || e.RowIndex < 0 || e.ColumnIndex < 0 || grid.Columns[e.ColumnIndex].Name != "CONFIG") return;
                var fila = grid.Rows[e.RowIndex]; fila.Cells["USAR"].Value = !string.IsNullOrWhiteSpace(fila.Cells["CONFIG"].Value as string);
                ActualizarRevision(fila);
            };
            raiz.Controls.Add(grid, 0, 2);
            var aplicar = MYGProyectoUI.Boton("Aplicar seleccionadas", 1); aplicar.Width = 185;
            var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
            var pie = new WinForms.Panel { Dock = WinForms.DockStyle.Fill };
            asociar = new WinForms.CheckBox
            {
                Text = "Recordar las asociaciones elegidas para utilizarlas en futuros proyectos",
                Checked = true,
                Dock = WinForms.DockStyle.Top,
                Height = 38
            };
            pie.Controls.Add(asociar); pie.Controls.Add(MYGBibliotecaUI.Pie(aplicar, cancelar)); raiz.Controls.Add(pie, 0, 3);
            aplicar.Click += (s, e) =>
            {
                grid.EndEdit(); Solicitudes = new List<MYGAplicarConfiguracionSolicitud>();
                foreach (WinForms.DataGridViewRow fila in grid.Rows)
                    if (Convert.ToBoolean(fila.Cells["USAR"].Value ?? false))
                    {
                        string id = fila.Cells["CONFIG"].Value as string;
                        var c = b.Configuraciones.FirstOrDefault(x => x.Id == id);
                        if (c == null) { WinForms.MessageBox.Show(this, "Elige una configuración en cada fila seleccionada.", "MYG Presupuestos"); return; }
                        Solicitudes.Add(new MYGAplicarConfiguracionSolicitud { Partida = fila.Tag as ItemPresupuestoDelphin, Configuracion = c });
                    }
                if (Solicitudes.Count == 0) { WinForms.MessageBox.Show(this, "Selecciona las partidas que recibirán una configuración.", "MYG Presupuestos"); return; }
                DialogResult = WinForms.DialogResult.OK;
            };
            AcceptButton = aplicar; CancelButton = cancelar;
        }
        private void ActualizarRevision(WinForms.DataGridViewRow fila)
        {
            var i = fila.Tag as ItemPresupuestoDelphin;
            var c = biblioteca.Configuraciones.FirstOrDefault(x => x.Id == fila.Cells["CONFIG"].Value as string);
            string texto = c == null ? (MYGBibliotecaPartidas.Disponibles(biblioteca, i).Count > 1 ? "Elige una variante" : "Sin coincidencia seleccionada") : comprobar(c);
            if (c != null && !MYGBibliotecaPartidas.Disponibles(biblioteca, i).Any(x => x.Id == c.Id)) texto = "Asociación manual · " + texto;
            if (MYGProyectoStorage.TieneBim(i)) texto = "Ya configurada · " + texto;
            fila.Cells["ESTADO"].Value = texto; fila.Cells["ESTADO"].ToolTipText = texto;
        }
    }

    internal sealed class MYGElegirConfiguracionPartidaForm : WinForms.Form
    {
        private readonly WinForms.ListBox lista;
        private readonly WinForms.TextBox detalle;
        internal MYGConfiguracionPartida Elegida => lista.SelectedItem as MYGConfiguracionPartida;
        internal MYGElegirConfiguracionPartidaForm(IEnumerable<MYGConfiguracionPartida> opciones, string partida)
        {
            MYGProyectoUI.Preparar(this, "Elegir configuración BIM", 720, 520);
            var raiz = MYGBibliotecaUI.Raiz(this, "Configuraciones disponibles para la partida", partida);
            var contenido = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            contenido.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            contenido.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Percent, 45));
            contenido.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Percent, 55));
            lista = new WinForms.ListBox { Dock = WinForms.DockStyle.Fill, HorizontalScrollbar = true };
            detalle = new WinForms.TextBox
            {
                Dock = WinForms.DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                ScrollBars = WinForms.ScrollBars.Vertical,
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };
            lista.Items.AddRange(opciones.Cast<object>().ToArray());
            lista.SelectedIndexChanged += (s, e) =>
            {
                var c = Elegida; detalle.Text = c == null ? "" : "Plantilla: " + c.Plantilla + "\r\nUnidad: " + c.Unidad + "\r\n\r\n" +
                    string.Join("\r\n", c.Filtros.Where(f => !f.EstaVacio()).Select(f => f.Parametro + " · " + f.Regla + " · " + f.Valor));
            };
            if (lista.Items.Count > 0) lista.SelectedIndex = 0;
            contenido.Controls.Add(lista, 0, 0); contenido.Controls.Add(detalle, 0, 1); raiz.Controls.Add(contenido, 0, 2);
            var usar = MYGProyectoUI.Boton("Usar configuración", 1); usar.Width = 170;
            var sin = MYGProyectoUI.Boton("Agregar sin filtros"); sin.Width = 170; sin.DialogResult = WinForms.DialogResult.Ignore;
            var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
            var pie = MYGBibliotecaUI.Pie(usar, cancelar); pie.Controls.Add(sin); raiz.Controls.Add(pie, 0, 3);
            usar.Click += (s, e) => { if (Elegida != null) DialogResult = WinForms.DialogResult.OK; };
            AcceptButton = usar; CancelButton = cancelar;
        }
    }

    internal sealed class MYGCargarDataFiltrosForm : WinForms.Form
    {
        private readonly WinForms.DataGridView grid;
        private readonly List<ItemPresupuestoDelphin> actuales;
        private bool inicializando = true;
        internal List<MYGDataFiltrosSolicitud> Solicitudes { get; private set; }
        internal MYGCargarDataFiltrosForm(MYGDataFiltrosArchivo archivo, IEnumerable<ItemPresupuestoDelphin> items, string nombre)
        {
            actuales = items.Where(i => !MYGProyectoStorage.EsTitulo(i)).ToList();
            var sugeridas = MYGDataFiltrosStorage.Sugerir(archivo, actuales);
            MYGProyectoUI.Preparar(this, "Cargar Data de filtros antiguos", 1260, 690);
            var raiz = MYGBibliotecaUI.Raiz(this, "Importar filtros al presupuesto actual",
                nombre + ": " + archivo.TotalRegistros + " registros; " + archivo.Configuraciones.Count + " configurados; " + archivo.SinConfiguracion + " sin datos BIM.\n" +
                "Revisa el destino de cada configuración. Las descripciones repetidas requieren elegir; las filas ya configuradas quedan sin marcar.");
            grid = MYGBibliotecaUI.Tabla();
            grid.Columns.Add(new WinForms.DataGridViewCheckBoxColumn { Name = "USAR", HeaderText = "Importar", Width = 62 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn
            {
                Name = "ANTIGUA",
                HeaderText = "Partida del JSON antiguo",
                ReadOnly = true,
                AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill,
                MinimumWidth = 240,
                FillWeight = 100
            });
            grid.Columns.Add(new WinForms.DataGridViewComboBoxColumn { Name = "DESTINO", HeaderText = "Partida de este presupuesto", Width = 375 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "CONFIG", HeaderText = "Plantilla / filtros", ReadOnly = true, Width = 240 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "MOTIVO", HeaderText = "Correspondencia", ReadOnly = true, Width = 225 });
            foreach (var f in sugeridas)
            {
                var c = f.Registro;
                var opciones = new List<MYGConfiguracionOpcion> { new MYGConfiguracionOpcion { Id = "", Texto = "Omitir / elegir partida..." } };
                opciones.AddRange(actuales.Where(i => MYGDataFiltrosStorage.UnidadCompatible(c, i)).OrderBy(i => i.Item)
                    .Select(i => new MYGConfiguracionOpcion { Id = i.Id, Texto = i.Item + " · " + i.Descripcion + " · " + i.Unidad }));
                int n = grid.Rows.Add(f.Segura && f.Destino != null && !MYGProyectoStorage.TieneBim(f.Destino),
                    c.Item + " · " + c.Partida + " · " + c.Unidad, null, c.Plantilla + " · " + c.Filtros.Count + " filtro(s)", f.Motivo);
                var fila = grid.Rows[n]; fila.Tag = c;
                fila.Cells["DESTINO"] = MYGBibliotecaUI.Opciones(opciones); fila.Cells["DESTINO"].Value = f.Destino?.Id ?? "";
                if (f.Destino != null && MYGProyectoStorage.TieneBim(f.Destino)) fila.Cells["MOTIVO"].Value = "Ya configurada: importar reemplaza sus filtros";
                fila.Cells["ANTIGUA"].ToolTipText = "ID antiguo: " + (c.IdInternoDelphin ?? c.IdInterno) + "\n" + c.Partida;
                fila.Cells["CONFIG"].ToolTipText = "Plantilla: " + c.Plantilla + "\n" + string.Join("\n", c.Filtros.Select(x => x.Parametro + " · " + x.Regla + " · " + x.Valor));
                fila.Cells["MOTIVO"].ToolTipText = fila.Cells["MOTIVO"].Value?.ToString();
            }
            inicializando = false;
            grid.CellValueChanged += (s, e) =>
            {
                if (inicializando || e.RowIndex < 0 || e.ColumnIndex < 0 || grid.Columns[e.ColumnIndex].Name != "DESTINO") return;
                var fila = grid.Rows[e.RowIndex];
                string id = fila.Cells["DESTINO"].Value as string;
                var destino = actuales.FirstOrDefault(i => i.Id == id);
                fila.Cells["USAR"].Value = destino != null;
                fila.Cells["MOTIVO"].Value = destino == null ? "Registro omitido" :
                    (MYGProyectoStorage.TieneBim(destino) ? "Elección manual: reemplaza configuración local" : "Partida destino elegida manualmente");
            };
            raiz.Controls.Add(grid, 0, 2);
            var importar = MYGProyectoUI.Boton("Cargar seleccionadas", 1); importar.Width = 190;
            var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
            var pie = new WinForms.Panel { Dock = WinForms.DockStyle.Fill };
            pie.Controls.Add(new WinForms.Label
            {
                Text = "Se importan plantilla y filtros a las filas seleccionadas. Guardar filtros incorpora estas configuraciones a la biblioteca.",
                Dock = WinForms.DockStyle.Top,
                Height = 40
            });
            pie.Controls.Add(MYGBibliotecaUI.Pie(importar, cancelar)); raiz.Controls.Add(pie, 0, 3);
            importar.Click += (s, e) =>
            {
                grid.EndEdit(); Solicitudes = new List<MYGDataFiltrosSolicitud>();
                foreach (WinForms.DataGridViewRow fila in grid.Rows)
                    if (Convert.ToBoolean(fila.Cells["USAR"].Value ?? false))
                        Solicitudes.Add(new MYGDataFiltrosSolicitud
                        {
                            Registro = fila.Tag as ConfiguracionTablaPlanificacion,
                            Destino = actuales.FirstOrDefault(i => i.Id == fila.Cells["DESTINO"].Value as string)
                        });
                if (Solicitudes.Count == 0) { WinForms.MessageBox.Show(this, "Selecciona las configuraciones que quieres cargar y su partida destino.", "MYG Presupuestos"); return; }
                try { MYGDataFiltrosStorage.ValidarLote(Solicitudes); }
                catch (Exception ex) { MYGProyectoUI.Error(this, ex); return; }
                DialogResult = WinForms.DialogResult.OK;
            };
            AcceptButton = importar; CancelButton = cancelar;
        }
    }

    internal sealed class MYGCamposProyectoForm : WinForms.Form
    {
        private readonly List<WinForms.Control> campos = new List<WinForms.Control>();
        private readonly bool[] requeridos;
        internal string[] Valores => campos.Select(MYGUnidadesUI.Valor).ToArray();
        internal MYGCamposProyectoForm(string titulo, string[] etiquetas, string[] valores, bool[] obligatorios = null,
            IEnumerable<MYGUnidadCatalogo> unidades = null, bool conservarUnidadInicial = true)
        {
            requeridos = obligatorios ?? etiquetas.Select(x => true).ToArray();
            MYGProyectoUI.Preparar(this, titulo, 560, 130 + etiquetas.Length * 75);
            var tabla = new WinForms.TableLayoutPanel
            {
                Dock = WinForms.DockStyle.Fill,
                ColumnCount = 1,
                RowCount = etiquetas.Length * 2 + 1,
                Padding = new WinForms.Padding(24)
            };
            tabla.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            for (int n = 0; n < etiquetas.Length; n++)
            {
                tabla.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, 27));
                tabla.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, 48));
                tabla.Controls.Add(new WinForms.Label
                {
                    Text = etiquetas[n],
                    Dock = WinForms.DockStyle.Fill,
                    ForeColor = MYG2027_TemaComercial.Texto
                }, 0, n * 2);
                string inicial = valores != null && n < valores.Length ? valores[n] : "";
                WinForms.Control c = unidades != null && string.Equals(etiquetas[n], "Unidad", StringComparison.OrdinalIgnoreCase)
                    ? MYGUnidadesUI.Selector(unidades, inicial, conservarUnidadInicial)
                    : new WinForms.TextBox { Text = inicial, MaxLength = 500 };
                c.Dock = WinForms.DockStyle.Top; c.TabIndex = n;
                campos.Add(c); tabla.Controls.Add(c, 0, n * 2 + 1);
            }
            tabla.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Percent, 100));
            var pie = new WinForms.FlowLayoutPanel
            {
                Dock = WinForms.DockStyle.Fill,
                FlowDirection = WinForms.FlowDirection.RightToLeft
            };
            var ok = MYGProyectoUI.Boton("Continuar", 1); var cancelar = MYGProyectoUI.Boton("Cancelar");
            cancelar.DialogResult = WinForms.DialogResult.Cancel;
            ok.Click += (s, e) =>
            {
                for (int n = 0; n < campos.Count; n++)
                    if (requeridos[n] && string.IsNullOrWhiteSpace(MYGUnidadesUI.Valor(campos[n])))
                    { campos[n].Focus(); WinForms.MessageBox.Show(this, "Completa " + etiquetas[n].ToLowerInvariant() + ".", "MYG Presupuestos"); return; }
                DialogResult = WinForms.DialogResult.OK;
            };
            pie.Controls.Add(ok); pie.Controls.Add(cancelar); tabla.Controls.Add(pie, 0, etiquetas.Length * 2);
            Controls.Add(tabla); AcceptButton = ok; CancelButton = cancelar;
        }
    }

    internal sealed class MYGElegirArchivoProyectoForm : WinForms.Form
    {
        private readonly WinForms.ListBox lista;
        internal string Archivo => lista.SelectedItem as string;
        internal MYGElegirArchivoProyectoForm(IEnumerable<string> archivos)
        {
            MYGProyectoUI.Preparar(this, "Elegir proyecto MYG asociado", 680, 360);
            lista = new WinForms.ListBox { Dock = WinForms.DockStyle.Fill, HorizontalScrollbar = true };
            lista.Items.AddRange(archivos.Cast<object>().ToArray());
            if (lista.Items.Count > 0) lista.SelectedIndex = 0;
            var pie = new WinForms.FlowLayoutPanel
            {
                Dock = WinForms.DockStyle.Bottom,
                Height = 62,
                FlowDirection = WinForms.FlowDirection.RightToLeft
            };
            var abrir = MYGProyectoUI.Boton("Abrir proyecto", 1); var cancelar = MYGProyectoUI.Boton("Cancelar");
            abrir.Click += (s, e) => { if (Archivo != null) DialogResult = WinForms.DialogResult.OK; };
            cancelar.DialogResult = WinForms.DialogResult.Cancel;
            pie.Controls.Add(abrir); pie.Controls.Add(cancelar); Controls.Add(lista); Controls.Add(pie);
            Padding = new WinForms.Padding(20); AcceptButton = abrir; CancelButton = cancelar;
        }
    }

    internal sealed class MYGConectarDelphinForm : WinForms.Form
    {
        private readonly WinForms.TextBox ruta;
        private readonly WinForms.ComboBox proyectos;
        private readonly WinForms.ComboBox presupuestos;
        private readonly WinForms.Button aceptar;
        private readonly MYGConexionDelphin inicial;
        internal MYGConexionDelphin Conexion { get; private set; }
        internal string NombrePresupuesto => (presupuestos.SelectedItem as PresupuestoDelphin)?.Nombre;
        internal string CodigoPresupuesto => (presupuestos.SelectedItem as PresupuestoDelphin)?.Item;
        internal MYGConectarDelphinForm(MYGConexionDelphin conexion = null, string rutaSugerida = null)
        {
            inicial = conexion;
            MYGProyectoUI.Preparar(this, "Conectar presupuesto Delphin", 660, 385);
            var tabla = new WinForms.TableLayoutPanel
            {
                Dock = WinForms.DockStyle.Fill,
                Padding = new WinForms.Padding(24),
                ColumnCount = 2,
                RowCount = 7
            };
            tabla.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            tabla.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Absolute, 136));
            foreach (float h in new[] { 28F, 50F, 28F, 48F, 28F, 48F, 70F })
                tabla.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, h));
            var lbl = new WinForms.Label { Text = "Base SQLite de Delphin", Dock = WinForms.DockStyle.Fill };
            tabla.Controls.Add(lbl, 0, 0); tabla.SetColumnSpan(lbl, 2);
            ruta = new WinForms.TextBox
            {
                ReadOnly = true,
                Dock = WinForms.DockStyle.Top,
                Text = conexion?.RutaSQLite ?? rutaSugerida ?? ""
            };
            var buscar = MYGProyectoUI.Boton("Examinar"); buscar.Dock = WinForms.DockStyle.Fill;
            buscar.Click += (s, e) =>
            {
                using (var d = new WinForms.OpenFileDialog
                {
                    Title = "Base de datos Delphin",
                    Filter = "Bases SQLite (*.sqlite)|*.sqlite"
                })
                    if (d.ShowDialog(this) == WinForms.DialogResult.OK) { ruta.Text = d.FileName; CargarProyectos(); }
            };
            tabla.Controls.Add(ruta, 0, 1); tabla.Controls.Add(buscar, 1, 1);
            var lp = new WinForms.Label { Text = "Proyecto", Dock = WinForms.DockStyle.Fill };
            tabla.Controls.Add(lp, 0, 2); tabla.SetColumnSpan(lp, 2);
            proyectos = new WinForms.ComboBox { Dock = WinForms.DockStyle.Top, DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
            tabla.Controls.Add(proyectos, 0, 3); tabla.SetColumnSpan(proyectos, 2);
            var lb = new WinForms.Label { Text = "Presupuesto oficial", Dock = WinForms.DockStyle.Fill };
            tabla.Controls.Add(lb, 0, 4); tabla.SetColumnSpan(lb, 2);
            presupuestos = new WinForms.ComboBox { Dock = WinForms.DockStyle.Top, DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
            tabla.Controls.Add(presupuestos, 0, 5); tabla.SetColumnSpan(presupuestos, 2);
            aceptar = MYGProyectoUI.Boton("Conectar", 1); aceptar.Enabled = false;
            var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
            var pie = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, FlowDirection = WinForms.FlowDirection.RightToLeft };
            pie.Controls.Add(aceptar); pie.Controls.Add(cancelar); tabla.Controls.Add(pie, 0, 6); tabla.SetColumnSpan(pie, 2);
            Controls.Add(tabla); AcceptButton = aceptar; CancelButton = cancelar;
            proyectos.SelectedIndexChanged += (s, e) => CargarPresupuestos();
            presupuestos.SelectedIndexChanged += (s, e) => aceptar.Enabled = presupuestos.SelectedItem != null;
            aceptar.Click += (s, e) =>
            {
                try
                {
                    if (!(proyectos.SelectedItem is ProyectoDelphin p) || !(presupuestos.SelectedItem is PresupuestoDelphin b)) return;
                    Conexion = new MYGConexionDelphin
                    {
                        RutaSQLite = ruta.Text,
                        ProyectoId = p.Id,
                        PresupuestoId = b.Id,
                        FuenteId = inicial != null && string.Equals(Path.GetFullPath(inicial.RutaSQLite), Path.GetFullPath(ruta.Text),
                            StringComparison.OrdinalIgnoreCase) ? inicial.FuenteId : MYGIndiceLocal.FuenteId(ruta.Text)
                    };
                    DialogResult = WinForms.DialogResult.OK;
                }
                catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
            };
            Shown += (s, e) => { if (File.Exists(ruta.Text)) CargarProyectos(); };
        }
        private void CargarProyectos()
        {
            try
            {
                proyectos.Items.Clear(); presupuestos.Items.Clear(); aceptar.Enabled = false;
                var lista = LectorDelphin.LeerProyectosSQLite(ruta.Text);
                proyectos.Items.AddRange(lista.Cast<object>().ToArray());
                proyectos.SelectedItem = lista.FirstOrDefault(p => p.Id == inicial?.ProyectoId) ?? lista.FirstOrDefault();
            }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        }
        private void CargarPresupuestos()
        {
            try
            {
                presupuestos.Items.Clear(); aceptar.Enabled = false;
                if (!(proyectos.SelectedItem is ProyectoDelphin p)) return;
                var lista = LectorDelphin.LeerPresupuestosSQLite(ruta.Text, p.Id);
                presupuestos.Items.AddRange(lista.Cast<object>().ToArray());
                presupuestos.SelectedItem = lista.FirstOrDefault(b => b.Id == inicial?.PresupuestoId) ?? lista.FirstOrDefault();
            }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        }
    }

    internal sealed class MYGCatalogoPartidasForm : WinForms.Form
    {
        private readonly WinForms.TextBox ruta;
        private readonly WinForms.TextBox buscar;
        private readonly WinForms.DataGridView grid;
        private readonly WinForms.Label resumen;
        private readonly WinForms.Button agregar;
        private readonly WinForms.Button examinar;
        private readonly WinForms.CheckBox fuera;
        private readonly WinForms.CheckBox usarGuardadas;
        private readonly MYGBibliotecaDocumento biblioteca;
        private readonly WinForms.Timer espera;
        private readonly List<ItemPresupuestoDelphin> actuales;
        private readonly string fuentePresupuesto;
        private readonly string fuenteInicial;
        private readonly string rutaInicial;
        private List<MYGPartidaCatalogo> catalogo = new List<MYGPartidaCatalogo>();
        internal MYGConfiguracionPartida ConfiguracionSeleccionada { get; private set; }
        internal MYGPartidaCatalogo Seleccionada { get; private set; }
        internal MYGFuenteDelphin Fuente { get; private set; }
        internal MYGCatalogoPartidasForm(MYGFuenteDelphin fuente, IEnumerable<ItemPresupuestoDelphin> items, string fuenteOficial, MYGBibliotecaDocumento configuraciones = null)
        {
            biblioteca = configuraciones ?? new MYGBibliotecaDocumento();
            actuales = items?.ToList() ?? new List<ItemPresupuestoDelphin>(); fuentePresupuesto = fuenteOficial;
            fuenteInicial = fuente?.Id; rutaInicial = fuente?.RutaSQLite;
            MYGProyectoUI.Preparar(this, "Banco de partidas Delphin", 1040, 610);
            var raiz = new WinForms.TableLayoutPanel
            {
                Dock = WinForms.DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 5,
                Padding = new WinForms.Padding(20)
            };
            raiz.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            foreach (float h in new[] { 45F, 48F, 45F }) raiz.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, h));
            raiz.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Percent, 100));
            raiz.RowStyles.Add(new WinForms.RowStyle(WinForms.SizeType.Absolute, 60));
            raiz.Controls.Add(new WinForms.Label
            {
                Text = "Selección de partidas del catálogo Delphin.",
                Dock = WinForms.DockStyle.Fill,
                ForeColor = MYG2027_TemaComercial.Texto,
                Font = new Drawing.Font("Segoe UI", 12F, Drawing.FontStyle.Bold)
            }, 0, 0);
            var fila = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2 };
            fila.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            fila.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Absolute, 160));
            ruta = new WinForms.TextBox { ReadOnly = true, Text = rutaInicial ?? "", Dock = WinForms.DockStyle.Top };
            examinar = MYGProyectoUI.Boton("Elegir base"); examinar.Dock = WinForms.DockStyle.Fill;
            fila.Controls.Add(ruta, 0, 0); fila.Controls.Add(examinar, 1, 0); raiz.Controls.Add(fila, 0, 1);
            var busqueda = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 3 };
            busqueda.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            busqueda.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Absolute, 220));
            busqueda.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Absolute, 205));
            buscar = new WinForms.TextBox { Dock = WinForms.DockStyle.Top, PlaceholderText = "Buscar código, descripción o unidad" };
            fuera = new WinForms.CheckBox { Text = "Fuera del presupuesto oficial", Dock = WinForms.DockStyle.Fill };
            usarGuardadas = new WinForms.CheckBox { Text = "Traer filtros guardados", Checked = true, Dock = WinForms.DockStyle.Fill };
            busqueda.Controls.Add(buscar, 0, 0); busqueda.Controls.Add(fuera, 1, 0); busqueda.Controls.Add(usarGuardadas, 2, 0); raiz.Controls.Add(busqueda, 0, 2);
            grid = new WinForms.DataGridView
            {
                Dock = WinForms.DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                MultiSelect = false,
                RowHeadersVisible = false,
                SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Drawing.Color.White,
                AutoSizeRowsMode = WinForms.DataGridViewAutoSizeRowsMode.None,
                BorderStyle = WinForms.BorderStyle.None
            };
            MYG2027_TemaComercial.EstilizarTabla(grid);
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "CODIGO", HeaderText = "Código", Width = 135 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn
            {
                Name = "DESCRIPCION",
                HeaderText = "Partida / análisis",
                AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill
            });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "UNIDAD", HeaderText = "Unidad", Width = 75 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "ESTADO", HeaderText = "En este presupuesto", Width = 190 });
            grid.Columns.Add(new WinForms.DataGridViewTextBoxColumn { Name = "CONFIG_BIM", HeaderText = "Configuración BIM", Width = 175 });
            grid.Columns["DESCRIPCION"].MinimumWidth = 240;
            raiz.Controls.Add(grid, 0, 3);
            var pie = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 3 };
            pie.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Percent, 100));
            pie.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Absolute, 170));
            pie.ColumnStyles.Add(new WinForms.ColumnStyle(WinForms.SizeType.Absolute, 125));
            resumen = new WinForms.Label { Dock = WinForms.DockStyle.Fill, TextAlign = Drawing.ContentAlignment.MiddleLeft };
            agregar = MYGProyectoUI.Boton("Agregar partida", 1); agregar.Dock = WinForms.DockStyle.Fill; agregar.Enabled = false;
            var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.Dock = WinForms.DockStyle.Fill; cancelar.DialogResult = WinForms.DialogResult.Cancel;
            pie.Controls.Add(resumen, 0, 0); pie.Controls.Add(agregar, 1, 0); pie.Controls.Add(cancelar, 2, 0);
            raiz.Controls.Add(pie, 0, 4); Controls.Add(raiz); CancelButton = cancelar;
            espera = new WinForms.Timer { Interval = 180 };
            espera.Tick += (s, e) => { espera.Stop(); Filtrar(); };
            buscar.TextChanged += (s, e) => { espera.Stop(); espera.Start(); };
            fuera.CheckedChanged += (s, e) => Filtrar();
            examinar.Click += async (s, e) =>
            {
                using (var d = new WinForms.OpenFileDialog { Filter = "Bases SQLite (*.sqlite)|*.sqlite" })
                    if (d.ShowDialog(this) == WinForms.DialogResult.OK) { ruta.Text = d.FileName; await CargarAsync(); }
            };
            agregar.Click += (s, e) => Elegir(); grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) Elegir(); };
            grid.SelectionChanged += (s, e) => agregar.Enabled = grid.CurrentRow?.Tag is MYGPartidaCatalogo;
            Shown += async (s, e) =>
            { if (File.Exists(ruta.Text)) await CargarAsync(); else resumen.Text = "Selecciona una base que contenga el catálogo de análisis."; };
            FormClosed += (s, e) => { espera.Stop(); espera.Dispose(); };
        }
        private async System.Threading.Tasks.Task CargarAsync()
        {
            examinar.Enabled = false; agregar.Enabled = false; grid.Enabled = false; resumen.Text = "Leyendo análisis disponibles...";
            string archivo = ruta.Text;
            try
            {
                var lista = await System.Threading.Tasks.Task.Run(() => LectorDelphin.LeerCatalogoPartidasSQLite(archivo));
                if (IsDisposed) return;
                string id = !string.IsNullOrWhiteSpace(fuenteInicial) && string.Equals(archivo, rutaInicial,
                    StringComparison.OrdinalIgnoreCase) ? fuenteInicial : MYGIndiceLocal.FuenteId(archivo);
                Fuente = new MYGFuenteDelphin { Id = id, RutaSQLite = archivo };
                foreach (var p in lista) { p.FuenteId = id; p.RutaSQLite = archivo; }
                catalogo = lista; Filtrar();
            }
            catch (Exception ex) { if (!IsDisposed) { catalogo.Clear(); grid.Rows.Clear(); resumen.Text = "No se pudo leer el catálogo."; MYGProyectoUI.Error(this, ex); } }
            finally
            {
                if (!IsDisposed)
                {
                    examinar.Enabled = true; grid.Enabled = true;
                    agregar.Enabled = grid.CurrentRow?.Tag is MYGPartidaCatalogo;
                }
            }
        }
        private bool Oficial(MYGPartidaCatalogo p) => p.FuenteId == fuentePresupuesto && actuales.Any(i =>
            !string.IsNullOrWhiteSpace(i.IdInternoDelphin) && i.IdAnalisisDelphin == p.Id);
        private void Filtrar()
        {
            string[] palabras = buscar.Text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var lista = catalogo.Where(p => (!fuera.Checked || !Oficial(p)) && palabras.All(t =>
                ((p.Codigo ?? "") + " " + p.Descripcion + " " + p.Unidad).IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
            grid.SuspendLayout();
            try
            {
                grid.Rows.Clear();
                foreach (var p in lista.Take(2000))
                {
                    bool propuesta = actuales.Any(i => i.IdCatalogoDelphin == p.Id && i.FuenteCatalogoId == p.FuenteId &&
                        string.IsNullOrWhiteSpace(i.IdInternoDelphin));
                    int n = grid.Rows.Add(p.Codigo, p.Descripcion, p.Unidad,
                        Oficial(p) ? "Ya en presupuesto" : propuesta ? "Propuesta en la hoja" : "Disponible en la base",
                        EstadoConfiguracion(p));
                    grid.Rows[n].Tag = p;
                }
            }
            finally { grid.ResumeLayout(); }
            resumen.Text = lista.Count > 2000 ? "Mostrando 2,000 de " + lista.Count + ". Refina la búsqueda." : lista.Count + " análisis encontrados";
            agregar.Enabled = grid.CurrentRow?.Tag is MYGPartidaCatalogo;
        }
        private string EstadoConfiguracion(MYGPartidaCatalogo p)
        {
            int cantidad = MYGBibliotecaPartidas.Disponibles(biblioteca, p).Count;
            return cantidad == 0 ? "Sin configuración" : cantidad + (cantidad == 1 ? " guardada" : " guardadas");
        }
        private void Elegir()
        {
            if (!(grid.CurrentRow?.Tag is MYGPartidaCatalogo p)) return;
            ConfiguracionSeleccionada = null;
            if (usarGuardadas.Checked)
            {
                var opciones = MYGBibliotecaPartidas.Disponibles(biblioteca, p);
                if (opciones.Count == 1) ConfiguracionSeleccionada = opciones[0];
                else if (opciones.Count > 1)
                    using (var d = new MYGElegirConfiguracionPartidaForm(opciones, p.Descripcion))
                    {
                        var respuesta = d.ShowDialog(this);
                        if (respuesta == WinForms.DialogResult.OK) ConfiguracionSeleccionada = d.Elegida;
                        else if (respuesta != WinForms.DialogResult.Ignore) return;
                    }
            }
            Seleccionada = p; DialogResult = WinForms.DialogResult.OK;
        }
    }

    internal sealed class MYGElegirPlantillaForm : WinForms.Form
    {
        private readonly WinForms.ListBox lista;
        internal MYGPlantillaPresupuesto Elegida => lista.SelectedItem as MYGPlantillaPresupuesto;
        internal MYGElegirPlantillaForm(IEnumerable<MYGPlantillaPresupuesto> plantillas)
        {
            MYGProyectoUI.Preparar(this, "Presupuestos con filtros guardados", 620, 360);
            lista = new WinForms.ListBox { Dock = WinForms.DockStyle.Fill };
            lista.Items.AddRange(plantillas.Cast<object>().ToArray()); if (lista.Items.Count > 0) lista.SelectedIndex = 0;
            var pie = new WinForms.FlowLayoutPanel
            {
                Dock = WinForms.DockStyle.Bottom,
                Height = 60,
                FlowDirection = WinForms.FlowDirection.RightToLeft
            };
            var usar = MYGProyectoUI.Boton("Usar plantilla", 1); var cancelar = MYGProyectoUI.Boton("Cancelar");
            usar.Click += (s, e) => { if (Elegida != null) DialogResult = WinForms.DialogResult.OK; };
            cancelar.DialogResult = WinForms.DialogResult.Cancel; pie.Controls.Add(usar); pie.Controls.Add(cancelar);
            Controls.Add(lista); Controls.Add(pie); Padding = new WinForms.Padding(20); AcceptButton = usar; CancelButton = cancelar;
        }
    }
}
