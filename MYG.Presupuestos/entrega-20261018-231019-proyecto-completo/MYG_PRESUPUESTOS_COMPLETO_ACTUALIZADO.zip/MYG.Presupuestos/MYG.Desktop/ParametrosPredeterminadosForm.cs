using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGParametrosPredeterminadosForm : Form
{
    private readonly MYGParametrosPredeterminados edicion;
    private readonly Dictionary<string, TextBox> textos = new();
    private readonly Dictionary<string, NumericUpDown> numeros = new();
    private readonly TabControl pestanas = new() { Name = "pestanasParametros", Dock = DockStyle.Fill, Multiline = true };
    private readonly Label error = new() { Name = "errorParametros", AutoSize = true, Visible = false,
        ForeColor = Color.FromArgb(183, 39, 48), Margin = new(0, 8, 0, 0) };
    private readonly ComboBox unidadPartida = Selector("UnidadPartida"), unidadInsumo = Selector("UnidadInsumo"),
        proveedor = Selector("Proveedor"), periodo = Selector("PeriodoRendimiento", false),
        unidadAcero = Selector("UnidadAcero", false);
    private readonly DataGridView aceros = new() { Name = "tablaAceros", Dock = DockStyle.Fill,
        AutoGenerateColumns = false, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        AllowUserToResizeRows = false, RowHeadersVisible = false, MultiSelect = false,
        SelectionMode = DataGridViewSelectionMode.CellSelect, EditMode = DataGridViewEditMode.EditOnEnter,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, Height = 370, MinimumSize = new(620, 240) };
    private readonly List<(TextBox Nombre, TextBox Abreviatura)> niveles = new();
    private readonly PictureBox logo = new() { Name = "logoEmpresa", SizeMode = PictureBoxSizeMode.Zoom,
        Dock = DockStyle.Fill, Height = 150, MinimumSize = new(180, 150), BorderStyle = BorderStyle.FixedSingle,
        AccessibleName = "Vista previa del logo de la empresa" };
    private readonly Label estadoLogo = new() { Name = "estadoLogo", AutoSize = true, Text = "Sin logo seleccionado" };
    private bool guardando;

    internal MYGParametrosPredeterminadosForm(string rutaBase = null)
    {
        edicion = MYGParametrosUsuario.Leer().Copia();
        Name = "parametrosPredeterminadosForm";
        MYGProyectoUI.Preparar(this, "Parámetros predeterminados", 920, 710);
        MinimumSize = new(620, 430);
        var raiz = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new(14) };
        raiz.ColumnStyles.Add(new(SizeType.Percent, 100));
        raiz.RowStyles.Add(new(SizeType.AutoSize)); raiz.RowStyles.Add(new(SizeType.Percent, 100));
        raiz.RowStyles.Add(new(SizeType.AutoSize)); raiz.RowStyles.Add(new(SizeType.Absolute, 48));
        var alcance = new Label { Name = "alcanceParametros", AutoSize = true, Dock = DockStyle.Fill,
            Text = "Define los valores para presupuestos, partidas e insumos nuevos. Personaliza las denominaciones de ubicación, los colores y la empresa actual.",
            Margin = new(0, 0, 0, 12) };
        raiz.Controls.Add(alcance, 0, 0); raiz.Controls.Add(pestanas, 0, 1); raiz.Controls.Add(error, 0, 2);
        raiz.SizeChanged += (_, _) =>
        {
            int ancho = Math.Max(280, raiz.ClientSize.Width - raiz.Padding.Horizontal);
            alcance.MaximumSize = new(ancho, 0); error.MaximumSize = new(ancho, 0);
        };
        CrearPresupuestos(); CrearCostos(rutaBase); CrearDivision(); CrearAceros(); CrearColores(); CrearGeneral();

        var aceptar = new Button { Name = "aceptarParametros", Text = "Aceptar", Width = 112, Height = 34,
            Margin = new(8, 8, 0, 0) };
        var cerrar = new Button { Name = "cerrarParametros", Text = "Cerrar", Width = 112, Height = 34,
            DialogResult = DialogResult.Cancel, CausesValidation = false, Margin = new(8, 8, 0, 0) };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false, Margin = new(0) };
        pie.Controls.Add(cerrar); pie.Controls.Add(aceptar); raiz.Controls.Add(pie, 0, 3);
        Controls.Add(raiz); AcceptButton = aceptar; CancelButton = cerrar;
        aceptar.Click += (_, _) => Guardar();
        MYG2027_TemaComercial.Aplicar(this);
        MYG2027_TemaComercial.EstilizarBoton(aceptar, 1);
        MYGTemaPestanas.Preparar(pestanas);
    }

    private void CrearPresupuestos()
    {
        var pagina = Pagina("Presupuestos", "presupuestos");
        var generales = Seccion(pagina, "Gastos generales");
        Campo(generales, "Porcentaje (%)", Numero("GastosGeneralesPorcentaje", edicion.GastosGeneralesPorcentaje, 0, 10000, 4));
        Campo(generales, "Nombre / abreviatura", Pareja(
            Texto("NombreGastosGenerales", edicion.NombreGastosGenerales), Texto("AbreviaturaGastosGenerales", edicion.AbreviaturaGastosGenerales)));
        var otros = Seccion(pagina, "Otros gastos");
        Campo(otros, "Porcentaje (%)", Numero("OtrosGastosPorcentaje", edicion.OtrosGastosPorcentaje, 0, 10000, 4));
        Campo(otros, "Nombre / abreviatura", Pareja(
            Texto("NombreOtrosGastos", edicion.NombreOtrosGastos), Texto("AbreviaturaOtrosGastos", edicion.AbreviaturaOtrosGastos)));
        var utilidad = Seccion(pagina, "Utilidad");
        Campo(utilidad, "Porcentaje (%)", Numero("UtilidadPorcentaje", edicion.UtilidadPorcentaje, 0, 10000, 4));

        var impuestos = Seccion(pagina, "Impuestos · denominación y porcentaje");
        Campo(impuestos, "A la utilidad", Pareja(Texto("NombreImpuestoRenta", edicion.NombreImpuestoRenta),
            Numero("ImpuestoRentaPorcentaje", edicion.ImpuestoRentaPorcentaje, 0, 10000, 4)));
        Campo(impuestos, "A las ventas", Pareja(Texto("NombreImpuesto", edicion.NombreImpuesto),
            Numero("ImpuestoPorcentaje", edicion.ImpuestoPorcentaje, 0, 10000, 4)));
        Campo(impuestos, "Otros impuestos", Pareja(Texto("NombreOtrosImpuestos", edicion.NombreOtrosImpuestos),
            Numero("OtrosImpuestosPorcentaje", edicion.OtrosImpuestosPorcentaje, 0, 10000, 4)));

        var moneda = Seccion(pagina, "Moneda y precisión");
        Campo(moneda, "Símbolo / denominación", Pareja(Texto("Moneda", edicion.Moneda), Texto("NombreMoneda", edicion.NombreMoneda), 230));
        Campo(moneda, "Decimales de precio", Numero("DecimalesPrecio", edicion.DecimalesPrecio, 0, 6, 0));
        Campo(moneda, "Decimales de cantidad", Numero("DecimalesCantidad", edicion.DecimalesCantidad, 0, 8, 0));
        Nota(pagina, "Los porcentajes se incorporan al resumen de cada presupuesto nuevo. El impuesto a la utilidad se calcula sobre la utilidad; los impuestos a las ventas se calculan sobre el subtotal.");
    }

    private void CrearCostos(string rutaBase)
    {
        var pagina = Pagina("Costos e Insumos", "costosInsumos");
        var unidades = new[] { "und", "m", "m²", "m³", "kg", "t", "l", "glb", "hh", "hm", "día", "mes", "Bls" }.ToList();
        if (!string.IsNullOrWhiteSpace(rutaBase) && File.Exists(rutaBase))
        {
            try { unidades = MYGCatalogoUnidades.Listar(rutaBase).Select(u => u.Simbolo).ToList(); }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or Microsoft.Data.Sqlite.SqliteException or InvalidDataException)
            { Nota(pagina, "No se pudo leer el catálogo de unidades de la base actual. Puedes escribir la unidad predeterminada."); }
        }
        Llenar(unidadPartida, unidades, edicion.UnidadPartida); Llenar(unidadInsumo, unidades, edicion.UnidadInsumo);
        Llenar(proveedor, new[] { "SIN CLASIFICAR" }, edicion.Proveedor);
        Llenar(periodo, new[] { "Día", "Hora" }, edicion.PeriodoRendimiento);
        var costos = Seccion(pagina, "Costos unitarios");
        Campo(costos, "Unidad predeterminada", unidadPartida);
        Campo(costos, "Período del rendimiento", periodo);
        var rendimiento = Numero("Rendimiento", edicion.Rendimiento, 0.0001m, 1000000000m, 4);
        Campo(costos, "Rendimiento predeterminado", rendimiento);
        Campo(costos, "Jornada (horas por día)", Numero("JornadaHoras", edicion.JornadaHoras, 0.01m, 24, 2));
        var ayuda = Nota(pagina, ""); ayuda.Name = "ayudaRendimiento";
        void ExplicarRendimiento() => ayuda.Text = periodo.Text == "Hora"
            ? "El rendimiento se expresa en unidades por hora. Al crear una partida se convierte a rendimiento diario multiplicándolo por las horas de jornada."
            : "El rendimiento se expresa en unidades por día. La jornada define las horas de trabajo de ese día.";
        periodo.SelectedIndexChanged += (_, _) => ExplicarRendimiento(); ExplicarRendimiento();
        var insumos = Seccion(pagina, "Insumos");
        Campo(insumos, "Unidad predeterminada", unidadInsumo); Campo(insumos, "Proveedor predeterminado", proveedor);
        Nota(pagina, "Puedes seleccionar una unidad del catálogo o escribir otra. El proveedor se utiliza al crear nuevos insumos.");
    }

    private void CrearDivision()
    {
        var pagina = Pagina("División política", "divisionPolitica");
        Nota(pagina, "Personaliza los nombres y abreviaturas de los cuatro niveles de ubicación. Los registros de ubicación conservan sus datos.");
        var grupo = Seccion(pagina, "Denominación / abreviatura");
        for (int i = 0; i < edicion.DivisionPolitica.Count; i++)
        {
            var nivel = edicion.DivisionPolitica[i];
            var nombre = Texto("NombreNivelPolitico" + (i + 1), nivel.Nombre);
            var abreviatura = Texto("AbreviaturaNivelPolitico" + (i + 1), nivel.Abreviatura);
            niveles.Add((nombre, abreviatura)); Campo(grupo, (i + 1) + ".º nivel", Pareja(nombre, abreviatura));
        }
    }

    private void CrearAceros()
    {
        var pagina = Pagina("Parámetros de Fierros y Aceros", "fierrosAceros");
        var grupo = Seccion(pagina, "Metrados de acero");
        unidadAcero.DisplayMember = "Texto"; unidadAcero.ValueMember = "Valor";
        unidadAcero.Items.Add(new OpcionAcero("kg", "Kilogramos (kg)"));
        unidadAcero.Items.Add(new OpcionAcero("t", "Toneladas (t)"));
        unidadAcero.SelectedIndex = edicion.UnidadAcero is "t" or "tn" ? 1 : 0;
        Campo(grupo, "Unidad del resultado", unidadAcero);
        Nota(pagina, "Estos valores se usan al crear hojas de metrado de acero. Los pesos se expresan siempre en kg/m y las longitudes en metros. Las hojas existentes conservan sus parámetros.");
        aceros.Columns.Add(new DataGridViewTextBoxColumn { Name = "Diametro", HeaderText = "Diámetro", ReadOnly = true, FillWeight = 19, MinimumWidth = 95 });
        foreach (var (nombre, titulo) in new[] { ("PesoPorMetro", "Peso (kg/m)"), ("Empalme", "Empalme (m)"),
            ("Gancho", "Gancho (m)"), ("DesperdicioPorcentaje", "Desperdicio (%)") })
            aceros.Columns.Add(new DataGridViewTextBoxColumn { Name = nombre, HeaderText = titulo, FillWeight = 21,
                MinimumWidth = 110, ValueType = typeof(decimal), DefaultCellStyle = new DataGridViewCellStyle
                { Format = "0.####", Alignment = DataGridViewContentAlignment.MiddleRight } });
        foreach (var acero in edicion.Aceros)
            aceros.Rows.Add(acero.Diametro, acero.PesoPorMetro, acero.Empalme, acero.Gancho, acero.DesperdicioPorcentaje);
        aceros.DataError += (_, e) =>
        {
            e.ThrowException = false; MostrarError("Escribe un número válido para el parámetro de acero.");
        };
        aceros.CellValidating += (_, e) =>
        {
            if (e.ColumnIndex == 0 || e.RowIndex < 0) return;
            if (!LeerDecimal(e.FormattedValue, out decimal valor) || valor < 0 || (e.ColumnIndex == 1 && valor == 0))
            {
                e.Cancel = true; aceros.Rows[e.RowIndex].ErrorText = "Indica un valor válido, mayor que cero para el peso y no negativo para los demás parámetros.";
                MostrarError(aceros.Rows[e.RowIndex].ErrorText);
            }
            else aceros.Rows[e.RowIndex].ErrorText = "";
        };
        Añadir(pagina, aceros);
    }

    private void CrearColores()
    {
        var pagina = Pagina("Colores de Partidas", "coloresPartidas");
        Nota(pagina, "Selecciona los colores de los niveles del árbol de presupuestos y partidas. Se muestran en las ventanas del software.");
        var grupo = Seccion(pagina, "Colores por nivel");
        for (int i = 0; i < edicion.ColoresNiveles.Count; i++)
        {
            int indice = i;
            var boton = new BotonColor { Name = "colorNivel" + (i + 1), Dock = DockStyle.Fill, Height = 31,
                ColorSeleccionado = ColorTranslator.FromHtml("#" + edicion.ColoresNiveles[i].TrimStart('#')),
                AccessibleName = "Color del nivel " + (i + 1) };
            boton.Click += (_, _) =>
            {
                using var dialogo = new ColorDialog { Color = boton.ColorSeleccionado, FullOpen = true, AnyColor = true };
                if (dialogo.ShowDialog(this) != DialogResult.OK) return;
                boton.ColorSeleccionado = dialogo.Color;
                edicion.ColoresNiveles[indice] = ColorHex(dialogo.Color); boton.Invalidate();
            };
            Campo(grupo, i == 0 ? "Nivel 1 · Presupuesto" : "Nivel " + (i + 1), boton);
        }
    }

    private void CrearGeneral()
    {
        var pagina = Pagina("General", "general");
        var grupo = Seccion(pagina, "Empresa (propietario de obra) actual");
        Campo(grupo, "Nombre comercial", Texto("NombreComercial", edicion.NombreComercial));
        Campo(grupo, "Logo", logo);
        var botones = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true, Margin = new(0) };
        var seleccionar = new Button { Name = "seleccionarLogo", Text = "Seleccionar logo…", AutoSize = true, Height = 32 };
        var quitar = new Button { Name = "quitarLogo", Text = "Quitar logo", AutoSize = true, Height = 32 };
        seleccionar.Click += (_, _) => SeleccionarLogo();
        quitar.Click += (_, _) => { edicion.LogoBase64 = ""; MostrarLogo(); };
        botones.Controls.Add(seleccionar); botones.Controls.Add(quitar); Campo(grupo, "", botones); Campo(grupo, "", estadoLogo);
        Nota(pagina, "El nombre comercial se propone como propietario al crear proyectos. El logo y el nombre se muestran en Inicio. Selecciona una imagen PNG o JPEG de hasta 2 MB; se guarda una copia dentro de la configuración.");
        MostrarLogo();
    }

    private void Guardar()
    {
        if (guardando) return;
        error.Visible = false;
        try
        {
            if (!ValidateChildren() || !aceros.EndEdit())
                throw new InvalidDataException("Revisa el valor de acero que estás editando antes de guardar.");
            edicion.GastosGeneralesPorcentaje = Valor("GastosGeneralesPorcentaje");
            edicion.OtrosGastosPorcentaje = Valor("OtrosGastosPorcentaje"); edicion.UtilidadPorcentaje = Valor("UtilidadPorcentaje");
            edicion.ImpuestoRentaPorcentaje = Valor("ImpuestoRentaPorcentaje"); edicion.ImpuestoPorcentaje = Valor("ImpuestoPorcentaje");
            edicion.OtrosImpuestosPorcentaje = Valor("OtrosImpuestosPorcentaje");
            edicion.NombreGastosGenerales = Cadena("NombreGastosGenerales"); edicion.AbreviaturaGastosGenerales = Cadena("AbreviaturaGastosGenerales");
            edicion.NombreOtrosGastos = Cadena("NombreOtrosGastos"); edicion.AbreviaturaOtrosGastos = Cadena("AbreviaturaOtrosGastos");
            edicion.NombreImpuestoRenta = Cadena("NombreImpuestoRenta"); edicion.NombreImpuesto = Cadena("NombreImpuesto");
            edicion.NombreOtrosImpuestos = Cadena("NombreOtrosImpuestos");
            edicion.Moneda = Cadena("Moneda"); edicion.NombreMoneda = Cadena("NombreMoneda");
            edicion.DecimalesPrecio = (int)Valor("DecimalesPrecio"); edicion.DecimalesCantidad = (int)Valor("DecimalesCantidad");
            edicion.UnidadPartida = unidadPartida.Text.Trim(); edicion.UnidadInsumo = unidadInsumo.Text.Trim();
            edicion.Proveedor = proveedor.Text.Trim(); edicion.PeriodoRendimiento = periodo.Text;
            edicion.Rendimiento = Valor("Rendimiento"); edicion.JornadaHoras = Valor("JornadaHoras");
            for (int i = 0; i < niveles.Count; i++)
            {
                edicion.DivisionPolitica[i].Nombre = niveles[i].Nombre.Text.Trim();
                edicion.DivisionPolitica[i].Abreviatura = niveles[i].Abreviatura.Text.Trim();
            }
            for (int i = 0; i < edicion.Aceros.Count; i++)
            {
                decimal Celda(string nombre)
                {
                    if (LeerDecimal(aceros.Rows[i].Cells[nombre].Value, out decimal numero)) return numero;
                    pestanas.SelectedTab = pestanas.TabPages[3];
                    aceros.CurrentCell = aceros.Rows[i].Cells[nombre];
                    throw new InvalidDataException("Revisa los parámetros del diámetro " + edicion.Aceros[i].Diametro + ".");
                }
                var acero = edicion.Aceros[i]; acero.PesoPorMetro = Celda("PesoPorMetro"); acero.Empalme = Celda("Empalme");
                acero.Gancho = Celda("Gancho"); acero.DesperdicioPorcentaje = Celda("DesperdicioPorcentaje");
            }
            edicion.UnidadAcero = (unidadAcero.SelectedItem as OpcionAcero)?.Valor ?? "kg";
            edicion.NombreComercial = Cadena("NombreComercial");
            edicion.Validar(); guardando = true;
            MYGParametrosUsuario.Guardar(edicion); DialogResult = DialogResult.OK; Close();
        }
        catch (Exception ex) when (ex is InvalidDataException or ArgumentException or InvalidOperationException
            or IOException or UnauthorizedAccessException or System.Security.SecurityException)
        { guardando = false; MostrarError(ex.Message); }
    }

    private void SeleccionarLogo()
    {
        using var dialogo = new OpenFileDialog { Title = "Seleccionar logo de la empresa",
            Filter = "Imágenes PNG o JPEG|*.png;*.jpg;*.jpeg", CheckFileExists = true, Multiselect = false };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            const int limite = 2 * 1024 * 1024;
            if (new FileInfo(dialogo.FileName).Length > limite) throw new InvalidDataException("El logo admite imágenes de hasta 2 MB.");
            using var archivo = File.OpenRead(dialogo.FileName);
            using var imagen = Image.FromStream(archivo, true, true);
            if (imagen.RawFormat.Guid != ImageFormat.Png.Guid && imagen.RawFormat.Guid != ImageFormat.Jpeg.Guid)
                throw new InvalidDataException("Selecciona una imagen PNG o JPEG válida.");
            if ((long)imagen.Width * imagen.Height > 16000000 || imagen.Width > 8192 || imagen.Height > 8192)
                throw new InvalidDataException("El logo es demasiado grande. Usa una imagen de hasta 16 megapíxeles y 8192 píxeles por lado.");
            using var copia = new Bitmap(imagen.Width, imagen.Height, PixelFormat.Format32bppArgb);
            using (var grafico = Graphics.FromImage(copia)) grafico.DrawImage(imagen, new Rectangle(0, 0, copia.Width, copia.Height));
            using var salida = new MemoryStream(); copia.Save(salida, ImageFormat.Png);
            if (salida.Length > limite) throw new InvalidDataException("La copia PNG del logo supera 2 MB. Selecciona una imagen más pequeña.");
            edicion.LogoBase64 = Convert.ToBase64String(salida.ToArray()); MostrarLogo(); error.Visible = false;
        }
        catch (Exception ex) when (ex is InvalidDataException or IOException or UnauthorizedAccessException or ArgumentException
            or System.Runtime.InteropServices.ExternalException or OutOfMemoryException)
        { MostrarError(ex is OutOfMemoryException ? "No se pudo leer la imagen. Selecciona un archivo PNG o JPEG válido y más pequeño." : ex.Message); }
    }

    private void MostrarLogo()
    {
        Image anterior = logo.Image; logo.Image = null; anterior?.Dispose();
        estadoLogo.Text = "Sin logo seleccionado";
        if (string.IsNullOrEmpty(edicion.LogoBase64)) return;
        try
        {
            using var datos = new MemoryStream(Convert.FromBase64String(edicion.LogoBase64));
            using var imagen = Image.FromStream(datos, true, true);
            logo.Image = new Bitmap(imagen); estadoLogo.Text = "Logo guardado en la configuración";
        }
        catch (Exception ex) when (ex is FormatException or ArgumentException or System.Runtime.InteropServices.ExternalException or OutOfMemoryException)
        { estadoLogo.Text = "No se pudo mostrar el logo guardado. Puedes seleccionar otra imagen o quitarlo."; }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { var imagen = logo.Image; logo.Image = null; imagen?.Dispose(); }
        base.Dispose(disposing);
    }

    private TableLayoutPanel Pagina(string titulo, string nombre)
    {
        var pagina = new TabPage(titulo) { Name = nombre, Padding = new(2) };
        var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new(10) };
        var contenido = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1, MinimumSize = new(640, 0), Padding = new(0, 0, 4, 8), Margin = new(0) };
        contenido.ColumnStyles.Add(new(SizeType.Percent, 100));
        scroll.Controls.Add(contenido); pagina.Controls.Add(scroll); pestanas.TabPages.Add(pagina); return contenido;
    }

    private static TableLayoutPanel Seccion(TableLayoutPanel pagina, string titulo)
    {
        var grupo = new GroupBox { Text = titulo, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Dock = DockStyle.Fill, Padding = new(12, 22, 12, 10), Margin = new(0, 0, 0, 12) };
        var campos = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 2, Margin = new(0) };
        campos.ColumnStyles.Add(new(SizeType.Absolute, 212)); campos.ColumnStyles.Add(new(SizeType.Percent, 100));
        grupo.Controls.Add(campos); Añadir(pagina, grupo); return campos;
    }

    private static void Campo(TableLayoutPanel tabla, string etiqueta, Control control)
    {
        int fila = tabla.RowCount++; tabla.RowStyles.Add(new(SizeType.AutoSize));
        var label = new Label { Text = etiqueta, AutoSize = true, Anchor = AnchorStyles.Left,
            Margin = new(0, 7, 8, 7), MaximumSize = new(200, 0) };
        control.Margin = new(0, 4, 0, 4);
        if (control is not NumericUpDown) control.Dock = DockStyle.Fill;
        control.AccessibleName ??= etiqueta;
        tabla.Controls.Add(label, 0, fila); tabla.Controls.Add(control, 1, fila);
    }

    private static Control Pareja(Control primero, Control segundo, int anchoSegundo = 124)
    {
        var panel = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2, Margin = new(0) };
        panel.ColumnStyles.Add(new(SizeType.Percent, 100)); panel.ColumnStyles.Add(new(SizeType.Absolute, anchoSegundo));
        primero.Dock = DockStyle.Fill; segundo.Dock = DockStyle.Fill; primero.Margin = new(0, 0, 8, 0); segundo.Margin = new(0);
        panel.Controls.Add(primero, 0, 0); panel.Controls.Add(segundo, 1, 0); return panel;
    }

    private static void Añadir(TableLayoutPanel tabla, Control control)
    { int fila = tabla.RowCount++; tabla.RowStyles.Add(new(SizeType.AutoSize)); tabla.Controls.Add(control, 0, fila); }

    private static Label Nota(TableLayoutPanel pagina, string texto)
    {
        var label = new Label { Text = texto, AutoSize = true, Dock = DockStyle.Top,
            ForeColor = MYG2027_TemaComercial.Secundario, Margin = new(1, 0, 1, 12), MaximumSize = new(760, 0) };
        pagina.SizeChanged += (_, _) => label.MaximumSize = new(Math.Max(280, pagina.ClientSize.Width - 12), 0);
        Añadir(pagina, label); return label;
    }

    private TextBox Texto(string nombre, string valor)
    {
        int maximo = nombre.StartsWith("NombreNivelPolitico", StringComparison.Ordinal) ? 60
            : nombre.StartsWith("AbreviaturaNivelPolitico", StringComparison.Ordinal) || nombre == "Moneda" ? 15 : 120;
        var caja = new TextBox { Name = nombre, Text = valor ?? "", Dock = DockStyle.Fill, MaxLength = maximo,
            AccessibleName = nombre };
        textos.Add(nombre, caja); return caja;
    }

    private NumericUpDown Numero(string nombre, decimal valor, decimal minimo, decimal maximo, int decimales)
    {
        int precision = (decimal.GetBits(valor)[3] >> 16) & 0x7F;
        var caja = new NumericUpDown { Name = nombre, DecimalPlaces = Math.Max(decimales, precision), Minimum = Math.Min(minimo, valor),
            Maximum = Math.Max(maximo, valor), Width = 140, Anchor = AnchorStyles.Left,
            Increment = decimales == 0 ? 1 : 0.01m, ThousandsSeparator = true, AccessibleName = nombre };
        caja.Value = valor; numeros.Add(nombre, caja); return caja;
    }

    private static ComboBox Selector(string nombre, bool editable = true) => new()
    { Name = nombre, Dock = DockStyle.Fill, DropDownStyle = editable ? ComboBoxStyle.DropDown : ComboBoxStyle.DropDownList,
        MaxLength = 200, IntegralHeight = false, MaxDropDownItems = 14, AccessibleName = nombre };

    private static void Llenar(ComboBox selector, IEnumerable<string> opciones, string valor)
    {
        selector.Items.AddRange(opciones.Append(valor).Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase).Cast<object>().ToArray());
        if (selector.DropDownStyle == ComboBoxStyle.DropDownList)
            selector.SelectedIndex = Math.Max(0, selector.FindStringExact(valor ?? ""));
        else selector.Text = valor ?? "";
    }

    private string Cadena(string nombre) => textos[nombre].Text.Trim();
    private decimal Valor(string nombre) => numeros[nombre].Value;
    private void MostrarError(string mensaje) { error.Text = mensaje; error.Visible = true; }
    private static string ColorHex(Color color) => color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
    private static bool LeerDecimal(object valor, out decimal numero) =>
        decimal.TryParse(Convert.ToString(valor, CultureInfo.CurrentCulture), NumberStyles.Number, CultureInfo.CurrentCulture, out numero);
    private sealed record OpcionAcero(string Valor, string Texto);

    // La muestra se dibuja con el valor seleccionado para que conserve su color al cambiar de tema.
    private sealed class BotonColor : Button
    {
        internal Color ColorSeleccionado;
        protected override void OnPaint(PaintEventArgs pevent)
        {
            Text = "#" + ColorHex(ColorSeleccionado) + "    ·    Cambiar…";
            TextAlign = ContentAlignment.MiddleLeft; Padding = new(10, 0, 48, 0);
            base.OnPaint(pevent);
            int margen = Math.Max(5, (int)Math.Round(6 * DeviceDpi / 96F));
            var muestra = new Rectangle(Width - margen - 32, margen, 32, Math.Max(8, Height - margen * 2));
            using var relleno = new SolidBrush(ColorSeleccionado); pevent.Graphics.FillRectangle(relleno, muestra);
            using var borde = new Pen(MYG2027_TemaComercial.Borde); pevent.Graphics.DrawRectangle(borde, muestra);
        }
    }
}
