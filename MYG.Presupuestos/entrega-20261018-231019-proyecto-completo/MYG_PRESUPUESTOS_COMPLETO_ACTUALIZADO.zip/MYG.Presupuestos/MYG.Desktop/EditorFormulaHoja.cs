using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MYG_2027;

// El modelo recibe siempre Text. El formato sirve sólo para relacionar cada
// referencia con su contorno en la hoja y nunca se guarda como RTF.
internal class MYGEditorTextoFormulaHoja : RichTextBox
{
    internal bool AplicandoFormato { get; private set; }

    public MYGEditorTextoFormulaHoja()
    {
        Multiline = true;
        WordWrap = false;
        DetectUrls = false;
        EnableAutoDragDrop = false;
        AcceptsTab = false;
        HideSelection = false;
        ScrollBars = RichTextBoxScrollBars.None;
        MaxLength = MYGReferenciasFormulaHoja.MaximoCaracteresFormula;
    }

    internal virtual void AplicarTema()
    {
        EstablecerColoresSinHistorial(MYG2027_TemaComercial.Superficie, MYG2027_TemaComercial.Texto);
    }

    protected void EstablecerColoresSinHistorial(Color fondo, Color texto)
    {
        BackColor = Color.FromArgb(255, fondo);
        if (ForeColor != texto) AplicarFormatoSinHistorial(() => ForeColor = texto);
    }

    internal void CambiarFuenteSinHistorial(Font fuente)
    {
        if (Font != fuente) AplicarFormatoSinHistorial(() => Font = fuente);
    }

    internal void ColorearReferencias(IReadOnlyList<MYGReferenciaFormulaHoja> referencias, Func<int, Color> color)
    {
        AplicarFormatoSinHistorial(() =>
        {
            SelectAll();
            SelectionColor = ForeColor;
            foreach (var referencia in referencias)
            {
                if (referencia.Inicio < 0 || referencia.Longitud <= 0 || referencia.Inicio + referencia.Longitud > TextLength)
                    continue;
                Select(referencia.Inicio, referencia.Longitud);
                SelectionColor = color(referencia.IndiceColor);
            }
        });
    }

    // TOM suspende sólo el registro de formato; conserva las operaciones de
    // texto que ya existían, incluidas las que pueden rehacerse. No se asigna
    // Text/RTF, ni se borra Deshacer para colorear una fórmula.
    protected void AplicarFormatoSinHistorial(Action aplicar)
    {
        if (AplicandoFormato || IsDisposed) return;
        int inicio = SelectionStart, longitud = SelectionLength;
        bool modificado = Modified;
        var desplazamiento = new PuntoNativo();
        using var historial = new SuspenderHistorial(Handle);
        // RichEdit de Windows proporciona TOM. Si un control alternativo no
        // lo ofrece, conservar la edición es preferible a borrar su historial.
        if (!historial.Activo) return;
        SendMessagePunto(Handle, 0x04DD, IntPtr.Zero, ref desplazamiento); // EM_GETSCROLLPOS.
        AplicandoFormato = true;
        SendMessage(Handle, 0x000B, IntPtr.Zero, IntPtr.Zero); // WM_SETREDRAW.
        try
        {
            aplicar();
        }
        finally
        {
            Select(Math.Min(inicio, TextLength), Math.Min(longitud, Math.Max(0, TextLength - inicio)));
            if (SelectionLength == 0) SelectionColor = ForeColor;
            Modified = modificado;
            SendMessagePunto(Handle, 0x04DE, IntPtr.Zero, ref desplazamiento); // EM_SETSCROLLPOS.
            SendMessage(Handle, 0x000B, new IntPtr(1), IntPtr.Zero);
            AplicandoFormato = false;
            Invalidate();
        }
    }

    protected override void OnTextChanged(EventArgs e)
    {
        if (!AplicandoFormato) base.OnTextChanged(e);
    }

    protected override void OnSelectionChanged(EventArgs e)
    {
        if (!AplicandoFormato) base.OnSelectionChanged(e);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0302) // WM_PASTE: fórmulas y celdas reciben texto plano.
        {
            try
            {
                if (!ReadOnly && Clipboard.ContainsText(TextDataFormat.UnicodeText))
                {
                    string texto = Clipboard.GetText(TextDataFormat.UnicodeText);
                    int disponibles = Math.Max(0, MaxLength - (TextLength - SelectionLength));
                    if (texto.Length > disponibles) texto = texto[..disponibles];
                    if (texto.Length != 0 || SelectionLength != 0) SelectedText = texto;
                }
            }
            catch (ExternalException) { } // El portapapeles puede estar ocupado por otro proceso.
            return;
        }
        base.WndProc(ref m);
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct PuntoNativo { public int X, Y; }

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr hwnd, int mensaje, IntPtr wp, IntPtr lp);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessagePunto(IntPtr hwnd, int mensaje, IntPtr wp, ref PuntoNativo punto);

    private sealed class SuspenderHistorial : IDisposable
    {
        private IntPtr documento;
        private CambiarHistorial cambiar;
        internal bool Activo { get; private set; }

        [DllImport("user32.dll", EntryPoint = "SendMessageW")]
        private static extern IntPtr ObtenerOle(IntPtr hwnd, int mensaje, IntPtr wp, out IntPtr ole);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate int CambiarHistorial(IntPtr documento, int cantidad, out int realizadas);

        internal SuspenderHistorial(IntPtr handle)
        {
            IntPtr ole = IntPtr.Zero;
            try
            {
                ObtenerOle(handle, 0x043C, IntPtr.Zero, out ole); // EM_GETOLEINTERFACE.
                if (ole == IntPtr.Zero) return;
                var id = new Guid("8CC497C0-A1DF-11CE-8098-00AA0047BE5D"); // ITextDocument.
                if (Marshal.QueryInterface(ole, in id, out documento) < 0 || documento == IntPtr.Zero) return;
                // IUnknown (3), IDispatch (4), 15 métodos anteriores a Undo.
                cambiar = Marshal.GetDelegateForFunctionPointer<CambiarHistorial>(
                    Marshal.ReadIntPtr(Marshal.ReadIntPtr(documento), 22 * IntPtr.Size));
                Activo = cambiar(documento, -9999995, out _) >= 0; // tomSuspend.
            }
            finally { if (ole != IntPtr.Zero) Marshal.Release(ole); }
        }

        public void Dispose()
        {
            if (documento == IntPtr.Zero) return;
            try { if (Activo) cambiar(documento, -9999994, out _); } // tomResume.
            finally { Marshal.Release(documento); documento = IntPtr.Zero; Activo = false; }
        }
    }
}

// Conserva confirmación, validación y cancelación propias de DataGridView.
// El RichEdit sustituye únicamente al TextBox que no puede colorear tokens.
internal sealed class MYGEditorCeldaMetradoHoja : MYGEditorTextoFormulaHoja, IDataGridViewEditingControl
{
    private bool inicializando;
    private bool reposicionar;
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataGridView EditingControlDataGridView { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int EditingControlRowIndex { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool EditingControlValueChanged { get; set; }
    public Cursor EditingPanelCursor => Cursors.IBeam;
    public bool RepositionEditingControlOnValueChange => reposicionar;
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public object EditingControlFormattedValue
    {
        get => Text;
        set => Text = Convert.ToString(value) ?? "";
    }

    public MYGEditorCeldaMetradoHoja()
    {
        TabStop = false;
        BorderStyle = BorderStyle.None;
    }

    internal override void AplicarTema()
    {
        if (EditingControlDataGridView?.CurrentCell is MYGCeldaMetradoCombinada celda &&
            celda.ConfigurarEdicion?.Invoke(celda.RowIndex, celda.ColumnIndex) is { } combinada)
            EstablecerColoresSinHistorial(combinada.Estilo.BackColor, combinada.Estilo.ForeColor);
        else base.AplicarTema();
    }

    internal void Inicializar(string texto, DataGridViewCellStyle estilo, int maximo)
    {
        inicializando = true;
        try
        {
            MaxLength = Math.Min(maximo, MYGReferenciasFormulaHoja.MaximoCaracteresFormula);
            ApplyCellStyleToEditingControl(estilo);
            Text = texto;
            AplicarAlineacion(estilo.Alignment);
            ClearUndo();
            Modified = false;
            EditingControlValueChanged = false;
        }
        finally { inicializando = false; }
    }

    public object GetEditingControlFormattedValue(DataGridViewDataErrorContexts context) => Text;

    public void ApplyCellStyleToEditingControl(DataGridViewCellStyle dataGridViewCellStyle)
    {
        ArgumentNullException.ThrowIfNull(dataGridViewCellStyle);
        // RichEdit conserva también los saltos pegados cuando la celda no
        // ajusta texto; WordWrap decide la presentación, sin recrear el handle.
        WordWrap = dataGridViewCellStyle.WrapMode == DataGridViewTriState.True;
        reposicionar = WordWrap && dataGridViewCellStyle.Alignment is not
            (DataGridViewContentAlignment.TopLeft or DataGridViewContentAlignment.TopCenter or DataGridViewContentAlignment.TopRight);
        BackColor = Color.FromArgb(255, dataGridViewCellStyle.BackColor);
        if (EditingControlDataGridView != null) EditingControlDataGridView.EditingPanel.BackColor = BackColor;
        AplicarFormatoSinHistorial(() =>
        {
            Font = dataGridViewCellStyle.Font ?? Control.DefaultFont;
            ForeColor = dataGridViewCellStyle.ForeColor;
            AplicarAlineacion(dataGridViewCellStyle.Alignment);
        });
    }

    private void AplicarAlineacion(DataGridViewContentAlignment alineacion)
    {
        SelectAll();
        SelectionAlignment = alineacion switch
        {
            DataGridViewContentAlignment.TopRight or DataGridViewContentAlignment.MiddleRight or DataGridViewContentAlignment.BottomRight => HorizontalAlignment.Right,
            DataGridViewContentAlignment.TopCenter or DataGridViewContentAlignment.MiddleCenter or DataGridViewContentAlignment.BottomCenter => HorizontalAlignment.Center,
            _ => HorizontalAlignment.Left
        };
    }

    public void PrepareEditingControlForEdit(bool selectAll)
    {
        if (selectAll) SelectAll();
        else Select(TextLength, 0);
    }

    public bool EditingControlWantsInputKey(Keys keyData, bool dataGridViewWantsInputKey)
    {
        switch (keyData & Keys.KeyCode)
        {
            case Keys.Left:
                return SelectionLength > 0 || (RightToLeft == RightToLeft.No ? SelectionStart > 0 : SelectionStart < TextLength);
            case Keys.Right:
                return SelectionLength > 0 || (RightToLeft == RightToLeft.No ? SelectionStart < TextLength : SelectionStart > 0);
            case Keys.Up:
                return Multiline && GetLineFromCharIndex(SelectionStart) > 0;
            case Keys.Down:
                return Multiline && GetLineFromCharIndex(SelectionStart + SelectionLength) < GetLineFromCharIndex(TextLength);
            case Keys.Home:
            case Keys.End:
                return SelectionLength != TextLength;
            case Keys.Delete:
                return SelectionLength > 0 || SelectionStart < TextLength;
            case Keys.Enter:
                return (keyData & (Keys.Control | Keys.Alt | Keys.Shift)) == Keys.Shift && PermitirSaltoLinea;
            case Keys.Escape:
            case Keys.Tab:
                return false;
            case Keys.Prior:
            case Keys.Next:
                return EditingControlValueChanged;
        }
        return !dataGridViewWantsInputKey;
    }

    protected override bool ProcessKeyEventArgs(ref Message m)
    {
        if (m.Msg == 0x0102 && (m.WParam.ToInt32() == '\r' || m.WParam.ToInt32() == '\n') &&
            !(ModifierKeys == Keys.Shift && PermitirSaltoLinea)) return true;
        if (m.Msg == 0x0100 && (Keys)m.WParam.ToInt32() == Keys.A && ModifierKeys == Keys.Control)
        { SelectAll(); return true; }
        return base.ProcessKeyEventArgs(ref m);
    }

    private bool PermitirSaltoLinea => WordWrap || Text.Contains('\n');

    protected override void OnTextChanged(EventArgs e)
    {
        if (AplicandoFormato) return;
        base.OnTextChanged(e);
        if (inicializando) return;
        EditingControlValueChanged = true;
        EditingControlDataGridView?.NotifyCurrentCellDirty(true);
    }
}
