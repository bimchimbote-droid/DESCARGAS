using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Herramientas de presentación: ninguna acción escribe en el presupuesto.</summary>
internal sealed partial class MYGGraficoIncidencia
{
    private ToolStrip barraGrafico;
    private readonly Dictionary<string, ToolStripItem> botonesGrafico = new();
    private readonly List<Image> imagenesHerramientas = new();
    private readonly Dictionary<string, Image> iconosHerramientas = new();
    private readonly ToolTip ayudasGalerias = new();
    private Font fuenteMiniaturas;
    private Font fuenteGrupos;
    private readonly List<ToolStripDropDown> galeriasGrafico = new();
    private readonly List<ComandoGrafico> comandosGrafico = new();
    private ContextMenuStrip menuGrafico;
    private ToolStripDropDownButton botonMasGrafico;
    private bool actualizandoHerramientas;
    private readonly List<System.Windows.Forms.Timer> temporizadoresHerramientas = new();
    private readonly HashSet<ToolStripDropDown> menusConEfectos = new();

    private sealed record ComandoGrafico(string Id, string Texto, string Icono, string Descripcion, Action Ejecutar);

    private void PrepararHerramientas()
    {
        fuenteMiniaturas = new Font(SystemFonts.MessageBoxFont.FontFamily, 7.5f);
        fuenteGrupos = new Font(SystemFonts.MessageBoxFont, FontStyle.Bold);
        barraGrafico = new ToolStrip
        {
            Name = "barraTipoGrafico", Dock = DockStyle.Left, AutoSize = true,
            LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow,
            GripStyle = ToolStripGripStyle.Visible, CanOverflow = true,
            BackColor = SystemColors.Control, Padding = new Padding(2),
            AccessibleName = "Tipo de gráfico", ImageScalingSize = new Size(24, 24),
            ShowItemToolTips = true, TabStop = true
        };
        Controls.Add(barraGrafico);
        void Comando(string id, string texto, string icono, string descripcion, Action ejecutar, bool barra = true)
        {
            var comando = new ComandoGrafico(id, texto, icono, descripcion, ejecutar);
            comandosGrafico.Add(comando);
            if (!barra) return;
            var boton = new ToolStripButton(texto, IconoHerramienta(icono), (_, _) => EjecutarComandoGrafico(id, ejecutar))
            {
                Name = id, AccessibleName = texto, ToolTipText = texto + "\n" + descripcion,
                DisplayStyle = ToolStripItemDisplayStyle.Image, AutoToolTip = false,
                ImageScaling = ToolStripItemImageScaling.SizeToFit, Overflow = ToolStripItemOverflow.AsNeeded
            };
            botonesGrafico.Add(id, boton); barraGrafico.Items.Add(boton);
        }
        void Galeria(string id, string texto, string icono, string descripcion, Func<ToolStripDropDown> crear)
        {
            var desplegable = crear();
            comandosGrafico.Add(new(id, texto, icono, descripcion, () => MostrarGaleria(desplegable, barraGrafico)));
            var boton = new ToolStripDropDownButton(texto, IconoHerramienta(icono))
            {
                Name = id, AccessibleName = texto, ToolTipText = texto + "\n" + descripcion,
                DisplayStyle = ToolStripItemDisplayStyle.Image, AutoToolTip = false, ShowDropDownArrow = true,
                Overflow = ToolStripItemOverflow.AsNeeded
            };
            boton.DropDown = desplegable; galeriasGrafico.Add(desplegable);
            boton.DropDownOpened += (_, _) => RegistrarUsoGrafico(id);
            botonesGrafico.Add(id, boton); barraGrafico.Items.Add(boton);
        }
        Comando("restaurar", "R", "restaurar", "Restaurar la presentación predeterminada del gráfico.", RestaurarGrafico);
        Comando("cargar", "Cargar Plantilla", "cargar", "Aplicar una plantilla JSON de presentación sin cambiar los costos.", CargarPlantillaGrafico);
        Comando("guardar", "Mostrar como Plantilla", "guardar", "Guardar la configuración del gráfico como una plantilla JSON reutilizable.", GuardarPlantillaGrafico);
        var exportar = new ToolStripDropDownButton("Exportar", IconoHerramienta("exportar"))
        {
            Name = "exportar", AccessibleName = "Exportar", ToolTipText = "Exportar el gráfico y sus datos", DisplayStyle = ToolStripItemDisplayStyle.Image
        };
        botonesGrafico.Add("exportar", exportar); barraGrafico.Items.Add(exportar);
        comandosGrafico.Add(new("exportar", "Exportar", "exportar", "Guardar el gráfico y sus valores originales en otro formato.", () => ExportarGrafico("png")));
        PrepararExportacionesGrafico(exportar);
        Comando("asistente", "Lanzar el Asistente de Gráficos", "asistente", "Elegir el tipo, la rotación, las etiquetas, los ejes, la leyenda, los títulos y la fuente.", () => EditarPresentacionGrafico(true));
        Galeria("columnas", "Columna", "columnas", "Columnas 2D, 3D, cilindros, conos y pirámides.", () => CrearGaleriaTipos(t => t.Familia == "columnas", true));
        Galeria("lineas", "Línea", "lineas", "Líneas, curvas y áreas en dos y tres dimensiones.", () => CrearGaleriaTipos(t => t.Familia is "lineas" or "area"));
        Galeria("circular", "Tarta", "circular", "Tartas, donas y tartas explosionadas 2D y 3D.", () => CrearGaleriaTipos(t => t.Familia == "circular"));
        Galeria("otros", "Otros Gráficos", "otros", "Radar, radar de área y polar.", () => CrearGaleriaTipos(t => t.Familia == "radar"));
        Galeria("paleta", "Paleta", "paleta", "Elegir los colores de las series.", CrearGaleriaPaletas);
        Comando("previsualizar", "Imprimir Previsualización", "previsualizar", "Ver la página antes de imprimir.", () => ImprimirGrafico(true));
        Comando("imprimir", "Imprimir", "imprimir", "Seleccionar la impresora e imprimir el gráfico completo.", () => ImprimirGrafico(false));
        Galeria("apariencia", "Apariencia", "apariencia", "35 combinaciones de color y apariencia.", CrearGaleriaApariencias);
        Comando("barras", "Barras", "barras", "Mostrar barras horizontales.", () => CambiarGrafico(c => { c.Tipo = "columnas-0"; c.Horizontal = true; }), false);
        Comando("area", "Área", "area", "Mostrar un gráfico de área.", () => CambiarGrafico(c => { c.Tipo = "area-0"; c.Horizontal = false; }), false);
        Comando("propiedades", "Propiedades del gráfico", "propiedades", "Ajustar toda la presentación del gráfico.", () => EditarPresentacionGrafico(false), false);
        Comando("titulos", "Títulos", "titulos", "Editar el título, subtítulo y títulos adicionales.", EditarTitulosGrafico, false);
        Comando("anotaciones", "Anotaciones", "anotaciones", "Añadir notas de texto en posiciones relativas del gráfico.", EditarAnotacionesGrafico, false);
        foreach (string formato in new[] { "PDF", "HTML", "MHT", "XLS", "XLSX", "RTF", "BMP", "GIF", "JPEG", "PNG", "TIFF" })
        {
            string extension = formato.ToLowerInvariant();
            Comando("exportar-" + extension, "Exportar a " + formato, "exportar-" + extension, "Exportar el gráfico en formato " + formato + ".", () => ExportarGrafico(extension), false);
        }
        botonMasGrafico = new ToolStripDropDownButton("Agregar o quitar botones", IconoHerramienta("personalizar"))
        {
            Name = "personalizar", AccessibleName = "Agregar o quitar botones", ToolTipText = "Agregar o quitar botones y personalizar la barra",
            DisplayStyle = ToolStripItemDisplayStyle.Image, Overflow = ToolStripItemOverflow.Never
        };
        botonMasGrafico.DropDownOpening += (_, _) => RellenarMenuBarra(botonMasGrafico.DropDownItems);
        barraGrafico.Items.Add(botonMasGrafico);
        PrepararEfectoMenu(botonMasGrafico.DropDown);
        // ToolStripOverflow.Items es de solo lectura; un menú propio permite incluir
        // la personalización junto con copias de los comandos que no caben.
        var menuDesbordamiento = new ContextMenuStrip();
        barraGrafico.OverflowButton.DropDown = menuDesbordamiento;
        galeriasGrafico.Add(menuDesbordamiento); PrepararEfectoMenu(menuDesbordamiento);
        barraGrafico.OverflowButton.DropDownOpening += (_, _) =>
        {
            VaciarMenu(menuDesbordamiento.Items);
            foreach (ToolStripItem original in barraGrafico.Items)
            {
                if (!original.Available || original.Placement != ToolStripItemPlacement.Overflow || original == botonMasGrafico) continue;
                var comando = comandosGrafico.FirstOrDefault(c => c.Id == original.Name);
                if (comando != null)
                    menuDesbordamiento.Items.Add(comando.Texto, IconoHerramienta(comando.Icono), (_, _) => EjecutarComandoGrafico(comando.Id, comando.Ejecutar));
                else if (original is ToolStripButton)
                {
                    var boton = original;
                    menuDesbordamiento.Items.Add(original.Text, original.Image, (_, _) => boton.PerformClick());
                }
            }
            if (menuDesbordamiento.Items.Count > 0) menuDesbordamiento.Items.Add(new ToolStripSeparator());
            var opciones = new ToolStripMenuItem("Agregar o quitar botones"); RellenarMenuBarra(opciones.DropDownItems); menuDesbordamiento.Items.Add(opciones);
        };
        menuDesbordamiento.Opening += (_, e) => e.Cancel = false;
        menuGrafico = new ContextMenuStrip();
        menuGrafico.Opening += (_, apertura) =>
        {
            VaciarMenu(menuGrafico.Items);
            menuGrafico.Items.Add("Propiedades del gráfico...", null, (_, _) => EjecutarHerramienta(() => EditarPresentacionGrafico(false)));
            menuGrafico.Items.Add("Títulos...", null, (_, _) => EjecutarHerramienta(EditarTitulosGrafico));
            menuGrafico.Items.Add("Anotaciones...", null, (_, _) => EjecutarHerramienta(EditarAnotacionesGrafico));
            menuGrafico.Items.Add(new ToolStripSeparator());
            var barra = new ToolStripMenuItem("Mostrar barra Tipo de gráfico") { Checked = configuracion.BarraVisible, CheckOnClick = true };
            barra.Click += (_, _) => CambiarGrafico(c => c.BarraVisible = barra.Checked); menuGrafico.Items.Add(barra);
            var botones = new ToolStripMenuItem("Agregar o quitar botones"); RellenarMenuBarra(botones.DropDownItems); menuGrafico.Items.Add(botones);
            apertura.Cancel = false;
        };
        ContextMenuStrip = menuGrafico; barraGrafico.ContextMenuStrip = menuGrafico;
        PrepararEfectoMenu(menuGrafico);
        ActualizarHerramientas();
    }

    private Image IconoHerramienta(string clave)
    {
        if (iconosHerramientas.TryGetValue(clave, out var existente)) return existente;
        var imagen = MYGIconosGraficoIncidencia.Crear(clave, 32); imagenesHerramientas.Add(imagen); iconosHerramientas.Add(clave, imagen); return imagen;
    }

    private void ActualizarHerramientas()
    {
        if (barraGrafico == null || actualizandoHerramientas) return;
        actualizandoHerramientas = true;
        try
        {
            barraGrafico.SuspendLayout();
            barraGrafico.Visible = configuracion.BarraVisible;
            int lado = MedidaHerramienta(configuracion.IconosGrandes ? 32 : 24);
            barraGrafico.ImageScalingSize = new Size(lado, lado);
            barraGrafico.Padding = new Padding(MedidaHerramienta(2));
            barraGrafico.ShowItemToolTips = configuracion.MostrarAyudas;
            ayudasGalerias.Active = configuracion.MostrarAyudas;
            var ocultos = new HashSet<string>(configuracion.BotonesOcultos, StringComparer.Ordinal);
            foreach (var par in botonesGrafico)
            {
                par.Value.Available = !ocultos.Contains(par.Key);
                par.Value.DisplayStyle = configuracion.MostrarTextos ? ToolStripItemDisplayStyle.ImageAndText : ToolStripItemDisplayStyle.Image;
                par.Value.TextImageRelation = TextImageRelation.ImageBeforeText;
                var comando = comandosGrafico.First(c => c.Id == par.Key);
                string atajo = AtajoGrafico(par.Key);
                par.Value.ToolTipText = comando.Texto + (configuracion.MostrarAtajos && atajo.Length > 0 ? " (" + atajo + ")" : "") + "\n" + comando.Descripcion;
            }
            botonMasGrafico.DisplayStyle = configuracion.MostrarTextos ? ToolStripItemDisplayStyle.ImageAndText : ToolStripItemDisplayStyle.Image;
            ActualizarBarrasPersonalizadas();
            ActualizarFuentesHerramientas(barraGrafico.Items);
            foreach (var menu in galeriasGrafico) ActualizarFuentesHerramientas(menu.Items);
            ActualizarMedidasGalerias();
            barraGrafico.ResumeLayout(true); Invalidate();
        }
        finally { actualizandoHerramientas = false; }
    }

    private static string AtajoGrafico(string id) => id switch
    { "imprimir" => "Ctrl+P", "guardar" => "Ctrl+Mayús+S", "restaurar" => "F5", _ => "" };

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        string id = keyData switch
        {
            Keys.Control | Keys.P => "imprimir",
            Keys.Control | Keys.Shift | Keys.S => "guardar",
            Keys.F5 => "restaurar", _ => ""
        };
        var comando = comandosGrafico.FirstOrDefault(c => c.Id == id);
        if (comando == null) return base.ProcessCmdKey(ref msg, keyData);
        EjecutarComandoGrafico(comando.Id, comando.Ejecutar); return true;
    }

    private void EjecutarComandoGrafico(string id, Action accion) => EjecutarHerramienta(() =>
    { accion(); RegistrarUsoGrafico(id); });

    private void RegistrarUsoGrafico(string id)
    {
        CambiarGrafico(c => c.UsosComandos[id] = Math.Min(1_000_000, c.UsosComandos.GetValueOrDefault(id) + 1));
    }

    private bool FiltrarPorFrecuenciaGrafico() => !configuracion.MenusCompletos &&
        configuracion.UsosComandos.Values.Sum(v => (long)v) >= 12 && configuracion.UsosComandos.Values.Any(v => v >= 3);

    private void PrepararExportacionesGrafico(ToolStripDropDownButton exportar)
    {
        var items = new List<(ToolStripItem Item, string Id)>();
        foreach (string formato in new[] { "PDF", "HTML", "MHT", "XLS", "XLSX", "RTF" })
        {
            string extension = formato.ToLowerInvariant(); string id = "exportar-" + extension;
            var item = new ToolStripMenuItem("Exportar a " + formato, IconoHerramienta(id), (_, _) => EjecutarComandoGrafico(id, () => ExportarGrafico(extension)));
            exportar.DropDownItems.Add(item); items.Add((item, id));
        }
        var imagen = new ToolStripMenuItem("Exportar a Imagen", IconoHerramienta("exportar-png"));
        foreach (string formato in new[] { "BMP", "GIF", "JPEG", "PNG", "TIFF" })
        {
            string extension = formato.ToLowerInvariant(); string id = "exportar-" + extension;
            imagen.DropDownItems.Add(formato, IconoHerramienta(id), (_, _) => EjecutarComandoGrafico(id, () => ExportarGrafico(extension)));
        }
        exportar.DropDownItems.Add(imagen);
        var separador = new ToolStripSeparator(); var todos = new ToolStripMenuItem("Mostrar todos los comandos");
        exportar.DropDownItems.Add(separador); exportar.DropDownItems.Add(todos);
        var temporizador = new System.Windows.Forms.Timer { Interval = 900 }; temporizadoresHerramientas.Add(temporizador);
        void Expandir()
        {
            temporizador.Stop(); exportar.DropDown.SuspendLayout();
            foreach (var item in items) item.Item.Available = true;
            separador.Available = todos.Available = false; exportar.DropDown.ResumeLayout(true);
        }
        exportar.DropDownOpening += (_, _) =>
        {
            bool frecuente = FiltrarPorFrecuenciaGrafico();
            foreach (var item in items) item.Item.Available = !frecuente || item.Id == "exportar-pdf" || configuracion.UsosComandos.GetValueOrDefault(item.Id) >= 2;
            separador.Available = todos.Available = items.Any(i => !i.Item.Available);
        };
        exportar.DropDownOpened += (_, _) => { if (configuracion.ExpandirMenus && todos.Available) temporizador.Start(); };
        exportar.DropDownClosed += (_, _) => temporizador.Stop();
        temporizador.Tick += (_, _) => Expandir();
        todos.Click += (_, _) =>
        {
            exportar.DropDown.AutoClose = false; Expandir();
            exportar.DropDown.BeginInvoke(new Action(() => { if (!exportar.IsDisposed) exportar.DropDown.AutoClose = true; }));
        };
        PrepararEfectoMenu(exportar.DropDown); PrepararEfectoMenu(imagen.DropDown);
    }

    private void PrepararEfectoMenu(ToolStripDropDown menu)
    {
        if (!menusConEfectos.Add(menu)) return;
        var temporizador = new System.Windows.Forms.Timer { Interval = 20 }; temporizadoresHerramientas.Add(temporizador);
        temporizador.Tick += (_, _) =>
        {
            if (menu.IsDisposed || !menu.Visible) { temporizador.Stop(); return; }
            menu.Opacity = Math.Min(1, menu.Opacity + .16);
            if (menu.Opacity >= 1) temporizador.Stop();
        };
        menu.Opening += (_, _) =>
        {
            ActualizarFuentesHerramientas(menu.Items);
            menu.Opacity = configuracion.EfectosMenus == "Desvanecer" ? .05 : 1;
        };
        menu.Opened += (_, _) => { if (configuracion.EfectosMenus == "Desvanecer") temporizador.Start(); };
        menu.Closed += (_, _) => { temporizador.Stop(); if (!menu.IsDisposed) menu.Opacity = 1; };
        menu.Disposed += (_, _) => temporizador.Dispose();
    }

    private void CambiarGrafico(Action<MYGConfiguracionGraficoIncidencia> cambiar)
    {
        var copia = configuracion.Copia(); cambiar(copia); Configurar(copia);
    }

    private void EjecutarHerramienta(Action accion)
    {
        try { accion(); }
        catch (Exception ex) when (ex is not OutOfMemoryException and not StackOverflowException)
        { MessageBox.Show(this, ex.Message, "Gráfico de incidencia de costos", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private static void VaciarMenu(ToolStripItemCollection items)
    {
        while (items.Count > 0) { var item = items[0]; items.RemoveAt(0); item.Dispose(); }
    }

    private void RellenarMenuBarra(ToolStripItemCollection items)
    {
        VaciarMenu(items);
        var tipo = new ToolStripMenuItem("Tipo de gráfico");
        foreach (var comando in comandosGrafico.Where(c => botonesGrafico.ContainsKey(c.Id)))
        {
            var item = new ToolStripMenuItem(comando.Texto) { Checked = !configuracion.BotonesOcultos.Contains(comando.Id), CheckOnClick = true };
            item.Click += (_, _) => CambiarGrafico(c => c.BotonesOcultos = item.Checked ? c.BotonesOcultos.Where(x => x != comando.Id).ToArray() : c.BotonesOcultos.Append(comando.Id).Distinct().ToArray());
            tipo.DropDownItems.Add(item);
        }
        tipo.DropDownItems.Add(new ToolStripSeparator());
        tipo.DropDownItems.Add("Restablecer barra", null, (_, _) => RestablecerBarraGrafico());
        items.Add(tipo); items.Add("Personalizar ...", null, (_, _) => EjecutarHerramienta(PersonalizarBarraGrafico));
        ActualizarFuentesHerramientas(items);
    }

    private void RestablecerBarraGrafico() => CambiarGrafico(c =>
    { c.BotonesOcultos = Array.Empty<string>(); c.BarraVisible = true; c.IconosGrandes = false; c.MostrarAyudas = true; c.MostrarTextos = false; });

    private void RestaurarGrafico()
    {
        // Conserva las preferencias de acceso a la barra; R restablece la presentación.
        var nueva = new MYGConfiguracionGraficoIncidencia
        {
            BarraVisible = configuracion.BarraVisible, BotonesOcultos = configuracion.BotonesOcultos.ToArray(),
            IconosGrandes = configuracion.IconosGrandes, MostrarAyudas = configuracion.MostrarAyudas, MostrarTextos = configuracion.MostrarTextos,
            MenusCompletos = configuracion.MenusCompletos, ExpandirMenus = configuracion.ExpandirMenus, MostrarAtajos = configuracion.MostrarAtajos,
            EfectosMenus = configuracion.EfectosMenus, UsosComandos = new Dictionary<string, int>(configuracion.UsosComandos),
            BarrasPersonalizadas = configuracion.Copia().BarrasPersonalizadas
        };
        Configurar(nueva);
    }

    private void CargarPlantillaGrafico()
    {
        using var dialogo = new OpenFileDialog { Title = "Cargar Plantilla de gráfico", Filter = "Plantilla de gráfico (*.json)|*.json", CheckFileExists = true, Multiselect = false };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        if (new FileInfo(dialogo.FileName).Length > 1_000_000) throw new InvalidDataException("La plantilla supera el tamaño permitido de 1 MB.");
        var plantilla = MYGConfiguracionGraficoIncidencia.DesdeJson(File.ReadAllText(dialogo.FileName));
        Configurar(plantilla);
    }

    private void GuardarPlantillaGrafico()
    {
        using var dialogo = new SaveFileDialog { Title = "Mostrar como Plantilla — guardar presentación", Filter = "Plantilla de gráfico (*.json)|*.json", DefaultExt = "json", AddExtension = true, FileName = "Incidencia de Costos.json", OverwritePrompt = true };
        if (dialogo.ShowDialog(this) == DialogResult.OK) File.WriteAllText(dialogo.FileName, configuracion.AJson());
    }

    private void ExportarGrafico(string extension)
    {
        string nombre = extension.ToUpperInvariant();
        using var dialogo = new SaveFileDialog
        {
            Title = "Exportar a " + nombre, Filter = nombre + " (*." + extension + ")|*." + extension,
            DefaultExt = extension, AddExtension = true, FileName = "Incidencia de Costos." + extension, OverwritePrompt = true
        };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        using var imagen = CrearImagen();
        MYGGraficoIncidenciaExportacion.Guardar(dialogo.FileName, datos, moneda, configuracion.Titulo, imagen);
    }

    private void ImprimirGrafico(bool previsualizar)
    {
        using var imagen = CrearImagen(1600, 1000);
        using var documento = new PrintDocument { DocumentName = string.IsNullOrWhiteSpace(configuracion.Titulo) ? "Incidencia de Costos" : configuracion.Titulo };
        documento.DefaultPageSettings.Landscape = true;
        documento.PrintPage += (_, e) =>
        {
            if (e.Graphics == null) return;
            var limites = e.MarginBounds;
            float escala = Math.Min(limites.Width / (float)imagen.Width, limites.Height / (float)imagen.Height);
            var destino = new RectangleF(limites.Left + (limites.Width - imagen.Width * escala) / 2,
                limites.Top + (limites.Height - imagen.Height * escala) / 2, imagen.Width * escala, imagen.Height * escala);
            e.Graphics.DrawImage(imagen, destino); e.HasMorePages = false;
        };
        if (previsualizar)
        {
            using var vista = new PrintPreviewDialog { Document = documento, Width = 1050, Height = 740, UseAntiAlias = true, Text = "Imprimir Previsualización — Incidencia de Costos" };
            vista.ShowDialog(this);
        }
        else
        {
            using var dialogo = new PrintDialog { Document = documento, UseEXDialog = true, AllowSomePages = false, AllowCurrentPage = false };
            if (dialogo.ShowDialog(this) == DialogResult.OK) documento.Print();
        }
    }

    private ToolStripDropDown CrearGaleriaTipos(Func<MYGTipoGraficoIncidencia, bool> filtro, bool orientar = false)
    {
        var tipos = MYGCatalogoGraficosIncidencia.Tipos.Where(filtro).ToList();
        bool columnas = tipos.Any(t => t.Familia == "columnas");
        bool circular = tipos.Any(t => t.Familia == "circular");
        int columnasGaleria = columnas ? 4 : 3;
        // Se conservan las medidas a 96 DPI / 100 %. La galería aplica la
        // preferencia de lectura al alojarla y cuando vuelve a cambiar.
        int S(int valor) => valor;
        var grupos = tipos.GroupBy(t => circular && t.Forma == "explosionada" ? "Tartas explosionadas" : t.Grupo)
            .OrderBy(g => circular ? g.Key == "Tartas 2D" ? 0 : g.Key == "Tartas 3D" ? 1 : 2 : 0).ToList();
        int altoContenido = grupos.Sum(g => 25 + ((g.Count() + columnasGaleria - 1) / columnasGaleria) * 56 + 4) + (orientar ? 33 : 0) + 8;
        var contenido = PanelGaleria(S(columnas ? 235 : 180), S(Math.Min(365, altoContenido)));
        int fila = S(4);
        foreach (var grupo in grupos)
        {
            var etiqueta = new Label
            {
                Text = grupo.Key, AutoSize = false, Bounds = new Rectangle(S(4), fila, S(columnas ? 208 : 153), S(22)),
                Font = fuenteGrupos, BackColor = Color.FromArgb(232, 237, 244), TextAlign = ContentAlignment.MiddleLeft
            };
            contenido.Controls.Add(etiqueta); fila += S(25); int columna = 0;
            var ordenados = grupo.OrderBy(t => circular ? t.Forma switch { "tarta" => 0, "dona" => 1, "dona-anidada" => 2, _ => 3 } : t.Variante);
            foreach (var tipo in ordenados)
            {
                var miniatura = MYGIconosGraficoIncidencia.Miniatura(tipo, S(48), S(38)); imagenesHerramientas.Add(miniatura);
                var boton = BotonGaleria(tipo.Nombre, miniatura, new Rectangle(S(4 + columna * 53), fila, S(51), S(52)));
                boton.Text = ""; boton.TextImageRelation = TextImageRelation.Overlay; boton.ImageAlign = ContentAlignment.MiddleCenter; boton.Tag = tipo.Id;
                boton.Click += (_, _) =>
                {
                    CerrarGalerias(); CambiarGrafico(c => { c.Tipo = tipo.Id; if (tipo.Familia != "columnas") c.Horizontal = false; });
                };
                contenido.Controls.Add(boton); columna++;
                if (columna == columnasGaleria) { columna = 0; fila += S(56); }
            }
            if (columna > 0) fila += S(56);
            fila += S(4);
        }
        if (orientar)
        {
            var horizontal = new CheckBox { Text = "Barras horizontales", Bounds = new Rectangle(S(5), fila + S(2), S(207), S(27)), AutoSize = false };
            horizontal.CheckedChanged += (_, _) => { if (!actualizandoHerramientas) CambiarGrafico(c => c.Horizontal = horizontal.Checked); };
            contenido.Controls.Add(horizontal); fila += S(33); contenido.Tag = horizontal;
        }
        contenido.AutoScrollMinSize = new Size(0, fila + S(8));
        var menu = AlojarGaleria(contenido); PrepararEfectoMenu(menu);
        menu.Opening += (_, _) =>
        {
            foreach (var boton in contenido.Controls.OfType<Button>()) MarcarGaleria(boton, (string)boton.Tag == configuracion.Tipo);
            if (contenido.Tag is CheckBox horizontal) { actualizandoHerramientas = true; horizontal.Checked = configuracion.Horizontal; actualizandoHerramientas = false; }
        };
        return menu;
    }

    private ToolStripDropDown CrearGaleriaPaletas()
    {
        var panel = PanelGaleria(290, 360); int y = 5;
        foreach (var paleta in MYGCatalogoGraficosIncidencia.Paletas)
        {
            var miniatura = MYGIconosGraficoIncidencia.Estilo(paleta.Key, 0, 112, 47); imagenesHerramientas.Add(miniatura);
            var boton = BotonGaleria(paleta.Key, miniatura, new Rectangle(7, y, 265, 55));
            boton.TextImageRelation = TextImageRelation.ImageBeforeText; boton.Tag = paleta.Key;
            boton.Click += (_, _) => { CerrarGalerias(); CambiarGrafico(c => c.Paleta = paleta.Key); };
            panel.Controls.Add(boton); y += 59;
        }
        panel.AutoScrollMinSize = new Size(0, y + 5); var menu = AlojarGaleria(panel); PrepararEfectoMenu(menu);
        menu.Opening += (_, _) => { foreach (var boton in panel.Controls.OfType<Button>()) MarcarGaleria(boton, (string)boton.Tag == configuracion.Paleta); };
        return menu;
    }

    private ToolStripDropDown CrearGaleriaApariencias()
    {
        var panel = PanelGaleria(604, 330);
        string[] paletas = { "Multicolor", "Azul", "Roja", "Verde", "Violeta", "Turquesa", "Naranja" };
        string[] estilos = { "Fondo claro", "Degradado claro", "Fondo negro", "Negro con contornos", "Contornos suaves" };
        for (int fila = 0; fila < 5; fila++)
            for (int col = 0; col < paletas.Length; col++)
            {
                int apariencia = fila; string paleta = paletas[col];
                var miniatura = MYGIconosGraficoIncidencia.Estilo(paleta, apariencia, 75, 54); imagenesHerramientas.Add(miniatura);
                var boton = BotonGaleria(paleta + " · " + estilos[fila], miniatura, new Rectangle(5 + col * 83, 5 + fila * 65, 80, 61));
                boton.Text = ""; boton.AccessibleName = paleta + " · " + estilos[fila]; boton.Tag = (paleta, apariencia);
                boton.Click += (_, _) => { CerrarGalerias(); CambiarGrafico(c => { c.Paleta = paleta; c.Apariencia = apariencia; }); };
                panel.Controls.Add(boton);
            }
        panel.AutoScrollMinSize = new Size(0, 335); var menu = AlojarGaleria(panel); PrepararEfectoMenu(menu);
        menu.Opening += (_, _) =>
        {
            foreach (var boton in panel.Controls.OfType<Button>())
            {
                var valor = ((string paleta, int apariencia))boton.Tag;
                MarcarGaleria(boton, valor.paleta == configuracion.Paleta && valor.apariencia == configuracion.Apariencia);
            }
        };
        return menu;
    }

    private static Panel PanelGaleria(int ancho, int alto) => new()
    {
        Size = new Size(ancho, alto), AutoScroll = true, BackColor = SystemColors.Window,
        Padding = new Padding(3), AccessibleName = "Galería de gráficos", TabStop = true
    };

    private Button BotonGaleria(string texto, Image imagen, Rectangle limites)
    {
        var boton = new Button
        {
            Text = texto, Image = imagen, Bounds = limites, FlatStyle = FlatStyle.Flat,
            TextImageRelation = TextImageRelation.ImageAboveText, Font = fuenteMiniaturas,
            AccessibleName = texto, BackColor = Color.White, UseVisualStyleBackColor = false, TabStop = true
        };
        ayudasGalerias.SetToolTip(boton, texto);
        boton.FlatAppearance.BorderSize = 1; boton.FlatAppearance.BorderColor = Color.FromArgb(211, 218, 228);
        boton.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 237, 173);
        boton.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 220, 116);
        return boton;
    }

    private static void MarcarGaleria(Button boton, bool seleccionado)
    {
        boton.BackColor = seleccionado ? Color.FromArgb(255, 229, 151) : Color.White;
        boton.FlatAppearance.BorderColor = seleccionado ? Color.FromArgb(225, 162, 25) : Color.FromArgb(211, 218, 228);
    }

    private ToolStripDropDown AlojarGaleria(Panel panel)
    {
        var host = new ToolStripControlHost(panel) { AutoSize = false, Size = panel.Size, Margin = Padding.Empty, Padding = Padding.Empty };
        var menu = new ToolStripDropDown { AutoSize = true, Padding = new Padding(1), AutoClose = true };
        menu.Items.Add(host);
        RegistrarMedidasGaleria(panel, host);
        return menu;
    }

    private void MostrarGaleria(ToolStripDropDown menu, Control origen)
    {
        if (!galeriasGrafico.Contains(menu)) galeriasGrafico.Add(menu);
        menu.Show(origen, new Point(origen.Width, 0));
    }

    private void CerrarGalerias()
    {
        foreach (var galeria in galeriasGrafico) if (!galeria.IsDisposed) galeria.Close(ToolStripDropDownCloseReason.ItemClicked);
    }

    private static Form DialogoGrafico(string titulo, int ancho, int alto) => new()
    {
        Text = titulo, StartPosition = FormStartPosition.CenterParent, ClientSize = new Size(ancho, alto),
        MinimumSize = new Size(ancho + 16, alto + 39), AutoScaleMode = AutoScaleMode.Dpi,
        FormBorderStyle = FormBorderStyle.Sizable, MaximizeBox = false, MinimizeBox = false, ShowInTaskbar = false,
        Font = SystemFonts.MessageBoxFont
    };

    private static TableLayoutPanel FormularioGrafico() => new()
    {
        Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Padding = new Padding(12),
        ColumnStyles = { new ColumnStyle(SizeType.Absolute, 170), new ColumnStyle(SizeType.Percent, 100) }
    };

    private static void FilaGrafico(TableLayoutPanel panel, string texto, Control editor)
    {
        int fila = panel.RowCount++; panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        var etiqueta = new Label { Text = texto, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(3, 8, 8, 8) };
        editor.Anchor = AnchorStyles.Left | AnchorStyles.Right; editor.Margin = new Padding(3, 5, 3, 5);
        panel.Controls.Add(etiqueta, 0, fila); panel.Controls.Add(editor, 1, fila);
    }

    private static NumericUpDown NumeroGrafico(decimal valor, decimal minimo, decimal maximo, int decimales = 0) => new()
    { Minimum = minimo, Maximum = maximo, Value = Math.Clamp(valor, minimo, maximo), DecimalPlaces = decimales, Width = 180, ThousandsSeparator = true };

    private static CheckBox CasillaGrafico(string texto, bool marcada) => new() { Text = texto, Checked = marcada, AutoSize = true };

    private void EditarPresentacionGrafico(bool asistente)
    {
        var copia = configuracion.Copia();
        using var dialogo = DialogoGrafico(asistente ? "Asistente de Gráficos" : "Propiedades del gráfico", 760, 535);
        var tabs = new TabControl { Dock = DockStyle.Fill };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(8) };
        var aceptar = new Button { Text = asistente ? "Finalizar" : "Aceptar", Width = 95 };
        var cancelar = new Button { Text = "Cancelar", Width = 95, DialogResult = DialogResult.Cancel };
        var siguiente = new Button { Text = "Siguiente >", Width = 100, Visible = asistente };
        var anterior = new Button { Text = "< Anterior", Width = 100, Visible = asistente };
        pie.Controls.Add(cancelar); pie.Controls.Add(aceptar); pie.Controls.Add(siguiente); pie.Controls.Add(anterior);
        dialogo.Controls.Add(tabs); dialogo.Controls.Add(pie); dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
        TableLayoutPanel Pagina(string titulo)
        {
            var pagina = new TabPage(titulo) { AutoScroll = true }; var formulario = FormularioGrafico(); pagina.Controls.Add(formulario); tabs.TabPages.Add(pagina); return formulario;
        }
        var tipoPanel = Pagina("Tipo de gráfico");
        var tipo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DisplayMember = "Nombre", ValueMember = "Id", Width = 450, DataSource = MYGCatalogoGraficosIncidencia.Tipos.ToList() };
        tipo.SelectedValue = copia.Tipo;
        var horizontal = CasillaGrafico("Barras horizontales", copia.Horizontal);
        var paleta = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DataSource = MYGCatalogoGraficosIncidencia.Paletas.Keys.ToList() }; paleta.SelectedItem = copia.Paleta;
        var apariencia = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DataSource = new[] { "Fondo claro", "Degradado claro", "Fondo negro", "Negro con contornos", "Contornos suaves" }, SelectedIndex = copia.Apariencia };
        var muestra = new PictureBox { SizeMode = PictureBoxSizeMode.Zoom, Height = 165, BorderStyle = BorderStyle.FixedSingle };
        bool preparandoMuestra = true;
        void ActualizarMuestra()
        {
            if (preparandoMuestra) return;
            horizontal.Enabled = tipo.SelectedItem is MYGTipoGraficoIncidencia t && t.Familia == "columnas";
            if (tipo.SelectedItem is not MYGTipoGraficoIncidencia elegido) return;
            var muestraConfiguracion = copia.Copia();
            muestraConfiguracion.Tipo = elegido.Id; muestraConfiguracion.Horizontal = horizontal.Enabled && horizontal.Checked;
            muestraConfiguracion.Paleta = (string)paleta.SelectedItem; muestraConfiguracion.Apariencia = apariencia.SelectedIndex;
            var anteriorConfiguracion = configuracion;
            Bitmap nueva;
            try { configuracion = muestraConfiguracion; nueva = CrearImagen(600, 340); }
            finally { configuracion = anteriorConfiguracion; }
            var vieja = muestra.Image; muestra.Image = nueva; vieja?.Dispose();
        }
        tipo.SelectedIndexChanged += (_, _) => ActualizarMuestra();
        paleta.SelectedIndexChanged += (_, _) => ActualizarMuestra();
        apariencia.SelectedIndexChanged += (_, _) => ActualizarMuestra();
        horizontal.CheckedChanged += (_, _) => ActualizarMuestra();
        FilaGrafico(tipoPanel, "Tipo:", tipo); FilaGrafico(tipoPanel, "Orientación:", horizontal); FilaGrafico(tipoPanel, "Paleta:", paleta);
        FilaGrafico(tipoPanel, "Apariencia:", apariencia); FilaGrafico(tipoPanel, "Vista previa:", muestra);
        tipo.SelectedValue = copia.Tipo; paleta.SelectedItem = copia.Paleta; apariencia.SelectedIndex = copia.Apariencia; preparandoMuestra = false; ActualizarMuestra();
        var rotacion = Pagina("Rotación");
        var angulo = NumeroGrafico(copia.Angulo, 0, 360); var inclinacion = NumeroGrafico(copia.Inclinacion, 0, 75); var separacion = NumeroGrafico(copia.Separacion, 0, 40);
        FilaGrafico(rotacion, "Rotación (grados):", angulo); FilaGrafico(rotacion, "Inclinación 3D:", inclinacion); FilaGrafico(rotacion, "Separación (%):", separacion);
        var etiquetas = Pagina("Etiquetas");
        var mostrarEtiquetas = CasillaGrafico("Mostrar etiquetas de datos", copia.MostrarEtiquetas);
        FilaGrafico(etiquetas, "Etiquetas:", mostrarEtiquetas);
        FilaGrafico(etiquetas, "Contenido:", new Label { Text = "Porcentaje de incidencia (p. ej., 43.73 %)", AutoSize = true });
        var ejes = Pagina("Ejes y cuadrícula");
        var mostrarEjes = CasillaGrafico("Mostrar ejes", copia.MostrarEjes); var cuadricula = CasillaGrafico("Mostrar cuadrícula", copia.MostrarCuadricula);
        var minimo = NumeroGrafico(copia.MinimoEje, -1000000000000m, 1000000000000m, 2); var maximo = NumeroGrafico(copia.MaximoEje, -1000000000000m, 1000000000000m, 2);
        FilaGrafico(ejes, "Ejes:", mostrarEjes); FilaGrafico(ejes, "Cuadrícula:", cuadricula); FilaGrafico(ejes, "Mínimo del eje:", minimo); FilaGrafico(ejes, "Máximo (0 = automático):", maximo);
        var leyendaPanel = Pagina("Leyenda"); var leyenda = CasillaGrafico("Mostrar leyenda de conceptos", copia.MostrarLeyenda); FilaGrafico(leyendaPanel, "Leyenda:", leyenda);
        var tituloPanel = Pagina("Títulos");
        var mostrarTitulo = CasillaGrafico("Mostrar títulos", copia.MostrarTitulo); var titulo = new TextBox { Text = copia.Titulo, MaxLength = 300 }; var subtitulo = new TextBox { Text = copia.Subtitulo, MaxLength = 500 };
        var adicionales = new TextBox { Multiline = true, ScrollBars = ScrollBars.Vertical, Height = 130, Text = string.Join(Environment.NewLine, copia.Titulos), MaxLength = 6020 };
        FilaGrafico(tituloPanel, "Visibilidad:", mostrarTitulo); FilaGrafico(tituloPanel, "Título principal:", titulo); FilaGrafico(tituloPanel, "Subtítulo:", subtitulo); FilaGrafico(tituloPanel, "Títulos adicionales\n(uno por línea):", adicionales);
        var fuentePanel = Pagina("Fuente"); var fuente = NumeroGrafico((decimal)copia.TamanoFuente, 6, 32, 1);
        var textoMuestra = new Label { Text = "Incidencia de Costos  43.73 %", Height = 65, AutoSize = false, TextAlign = ContentAlignment.MiddleLeft };
        Font fuenteMuestra = null;
        void CambiarFuenteMuestra() { var vieja = fuenteMuestra; fuenteMuestra = new Font(SystemFonts.MessageBoxFont.FontFamily, (float)fuente.Value); textoMuestra.Font = fuenteMuestra; vieja?.Dispose(); }
        fuente.ValueChanged += (_, _) => CambiarFuenteMuestra(); FilaGrafico(fuentePanel, "Tamaño (puntos):", fuente); FilaGrafico(fuentePanel, "Muestra:", textoMuestra); CambiarFuenteMuestra();
        anterior.Click += (_, _) => tabs.SelectedIndex = Math.Max(0, tabs.SelectedIndex - 1);
        siguiente.Click += (_, _) => tabs.SelectedIndex = Math.Min(tabs.TabPages.Count - 1, tabs.SelectedIndex + 1);
        void Navegacion() { anterior.Enabled = tabs.SelectedIndex > 0; siguiente.Enabled = tabs.SelectedIndex < tabs.TabPages.Count - 1; }
        tabs.SelectedIndexChanged += (_, _) => Navegacion(); Navegacion();
        aceptar.Click += (_, _) =>
        {
            EjecutarHerramienta(() =>
            {
                copia.Tipo = ((MYGTipoGraficoIncidencia)tipo.SelectedItem).Id; copia.Horizontal = horizontal.Enabled && horizontal.Checked;
                copia.Paleta = (string)paleta.SelectedItem; copia.Apariencia = apariencia.SelectedIndex;
                copia.Angulo = (int)angulo.Value; copia.Inclinacion = (int)inclinacion.Value; copia.Separacion = (int)separacion.Value;
                copia.MostrarEtiquetas = mostrarEtiquetas.Checked; copia.EtiquetaNombre = false; copia.EtiquetaPorcentaje = true; copia.EtiquetaImporte = false;
                copia.MostrarEjes = mostrarEjes.Checked; copia.MostrarCuadricula = cuadricula.Checked; copia.MinimoEje = minimo.Value; copia.MaximoEje = maximo.Value;
                copia.MostrarLeyenda = leyenda.Checked; copia.MostrarTitulo = mostrarTitulo.Checked; copia.Titulo = titulo.Text; copia.Subtitulo = subtitulo.Text;
                copia.Titulos = adicionales.Lines.Where(x => !string.IsNullOrWhiteSpace(x)).ToArray(); copia.TamanoFuente = (float)fuente.Value;
                copia.Validar(); Configurar(copia); dialogo.DialogResult = DialogResult.OK; dialogo.Close();
            });
        };
        try { dialogo.ShowDialog(this); }
        finally { muestra.Image?.Dispose(); muestra.Image = null; fuenteMuestra?.Dispose(); }
    }

    private void EditarTitulosGrafico()
    {
        var copia = configuracion.Copia();
        using var dialogo = DialogoGrafico("Títulos del gráfico", 620, 365);
        var formulario = FormularioGrafico();
        var visible = CasillaGrafico("Mostrar títulos", copia.MostrarTitulo); var titulo = new TextBox { Text = copia.Titulo, MaxLength = 300 }; var subtitulo = new TextBox { Text = copia.Subtitulo, MaxLength = 500 };
        var otros = new TextBox { Text = string.Join(Environment.NewLine, copia.Titulos), Multiline = true, ScrollBars = ScrollBars.Vertical, Height = 120, MaxLength = 6020 };
        FilaGrafico(formulario, "Visibilidad:", visible); FilaGrafico(formulario, "Título:", titulo); FilaGrafico(formulario, "Subtítulo:", subtitulo); FilaGrafico(formulario, "Títulos adicionales\n(uno por línea):", otros);
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(8) };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel }; var aceptar = new Button { Text = "Aceptar" }; pie.Controls.Add(cancelar); pie.Controls.Add(aceptar);
        aceptar.Click += (_, _) => EjecutarHerramienta(() => { copia.MostrarTitulo = visible.Checked; copia.Titulo = titulo.Text; copia.Subtitulo = subtitulo.Text; copia.Titulos = otros.Lines.Where(x => !string.IsNullOrWhiteSpace(x)).ToArray(); copia.Validar(); Configurar(copia); dialogo.DialogResult = DialogResult.OK; dialogo.Close(); });
        dialogo.Controls.Add(formulario); dialogo.Controls.Add(pie); dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar; dialogo.ShowDialog(this);
    }

    private void EditarAnotacionesGrafico()
    {
        var copia = configuracion.Copia(); var notas = new BindingList<MYGAnotacionGrafico>(copia.Anotaciones);
        using var dialogo = DialogoGrafico("Anotaciones del gráfico", 710, 420);
        var instruccion = new Label { Dock = DockStyle.Top, Height = 48, Padding = new Padding(10), Text = "Cada posición se expresa como porcentaje del área del gráfico (X: izquierda a derecha; Y: arriba abajo)." };
        var tabla = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = false, DataSource = notas, AllowUserToAddRows = false, AllowUserToDeleteRows = true, RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
        tabla.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Texto", HeaderText = "Texto", FillWeight = 70, MaxInputLength = 500 });
        tabla.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "X", HeaderText = "X (%)", FillWeight = 15 });
        tabla.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Y", HeaderText = "Y (%)", FillWeight = 15 });
        tabla.DataError += (_, e) => { e.ThrowException = false; MessageBox.Show(dialogo, "Introduzca una posición numérica entre 0 y 100.", "Anotación", MessageBoxButtons.OK, MessageBoxIcon.Information); };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 46, Padding = new Padding(8) };
        var agregar = new Button { Text = "Añadir" }; var eliminar = new Button { Text = "Eliminar" }; var aceptar = new Button { Text = "Aceptar" }; var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel };
        agregar.Click += (_, _) => { if (notas.Count < 50) { notas.Add(new MYGAnotacionGrafico()); tabla.CurrentCell = tabla.Rows[tabla.Rows.Count - 1].Cells[0]; tabla.BeginEdit(true); } else MessageBox.Show(dialogo, "Puede añadir hasta 50 anotaciones."); };
        eliminar.Click += (_, _) => { if (tabla.CurrentRow?.DataBoundItem is MYGAnotacionGrafico nota) notas.Remove(nota); };
        aceptar.Click += (_, _) => EjecutarHerramienta(() => { if (!tabla.EndEdit()) return; ((CurrencyManager)tabla.BindingContext[notas]).EndCurrentEdit(); copia.Anotaciones = notas.ToList(); copia.Validar(); Configurar(copia); dialogo.DialogResult = DialogResult.OK; dialogo.Close(); });
        pie.Controls.Add(agregar); pie.Controls.Add(eliminar); pie.Controls.Add(aceptar); pie.Controls.Add(cancelar);
        dialogo.Controls.Add(tabla); dialogo.Controls.Add(instruccion); dialogo.Controls.Add(pie); dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar; dialogo.ShowDialog(this);
    }

    private void PersonalizarBarraGrafico()
    {
        using var dialogo = DialogoGrafico("Personalización", 675, 500);
        var tabs = new TabControl { Dock = DockStyle.Fill };
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(8) };
        var cerrar = new Button { Text = "Cerrar", DialogResult = DialogResult.OK }; pie.Controls.Add(cerrar); dialogo.Controls.Add(tabs); dialogo.Controls.Add(pie); dialogo.CancelButton = cerrar;
        var barras = new TabPage("Barras de Herramientas"); tabs.TabPages.Add(barras);
        var sincronizarBarras = PrepararPanelBarras(barras);
        var comandos = new TabPage("Comandos"); tabs.TabPages.Add(comandos);
        var categorias = new ListBox { Bounds = new Rectangle(12, 65, 200, 265) }; categorias.Items.AddRange(new object[] { "(Elementos sin asignar)", "(Todos los elementos)", "Tipos de gráfico", "Exportar", "Presentación", "Imprimir" }); categorias.SelectedIndex = 1;
        var buscarCategoria = new TextBox { Bounds = new Rectangle(12, 36, 200, 25), PlaceholderText = "Introduzca texto a buscar..." };
        var buscarComando = new TextBox { Bounds = new Rectangle(225, 36, 405, 25), PlaceholderText = "Introduzca texto a buscar..." };
        var listaComandos = new ListBox { Bounds = new Rectangle(225, 65, 405, 265), DisplayMember = "Texto", DrawMode = DrawMode.OwnerDrawFixed, ItemHeight = 27 };
        listaComandos.DrawItem += (_, e) =>
        {
            e.DrawBackground();
            if (e.Index >= 0 && e.Index < listaComandos.Items.Count && listaComandos.Items[e.Index] is ComandoGrafico comando)
            {
                e.Graphics.DrawImage(IconoHerramienta(comando.Icono), new Rectangle(e.Bounds.Left + 3, e.Bounds.Top + 2, 23, 23));
                TextRenderer.DrawText(e.Graphics, comando.Texto, e.Font, new Rectangle(e.Bounds.Left + 32, e.Bounds.Top, e.Bounds.Width - 34, e.Bounds.Height), e.ForeColor, TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            }
            e.DrawFocusRectangle();
        };
        var descripcion = new TextBox { Bounds = new Rectangle(12, 357, 495, 56), Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical };
        var ejecutar = new Button { Text = "Ejecutar", Bounds = new Rectangle(521, 365, 109, 30) };
        var mostrarTodos = new Button { Text = "Mostrar todos los comandos", Bounds = new Rectangle(427, 332, 203, 24), Visible = false };
        bool mostrarTodosComandos = false;
        using var pausaComandos = new System.Windows.Forms.Timer { Interval = 900 };
        comandos.Controls.Add(new Label { Text = "Categorías:", Bounds = new Rectangle(12, 12, 180, 22) }); comandos.Controls.Add(new Label { Text = "Comandos:", Bounds = new Rectangle(225, 12, 180, 22) });
        comandos.Controls.Add(new Label { Text = "Descripción:", Bounds = new Rectangle(12, 334, 200, 22) });
        foreach (Control c in new Control[] { categorias, buscarCategoria, buscarComando, listaComandos, descripcion, ejecutar, mostrarTodos }) comandos.Controls.Add(c);
        string[] orden = { "columnas", "lineas", "circular", "barras", "area", "otros", "paleta", "apariencia", "asistente", "guardar", "cargar", "previsualizar", "imprimir", "exportar" };
        var ordenados = comandosGrafico.OrderBy(c => Array.IndexOf(orden, c.Id) is int n && n >= 0 ? n : 100 + comandosGrafico.IndexOf(c)).ToList();
        void FiltrarComandos()
        {
            string categoria = categorias.SelectedItem as string ?? "(Todos los elementos)";
            bool Incluido(ComandoGrafico c) => categoria switch
            {
                "Tipos de gráfico" => new[] { "columnas", "lineas", "circular", "barras", "area", "otros" }.Contains(c.Id),
                "Exportar" => c.Id.StartsWith("exportar", StringComparison.Ordinal),
                "Presentación" => new[] { "paleta", "apariencia", "asistente", "propiedades", "titulos", "anotaciones", "restaurar", "guardar", "cargar" }.Contains(c.Id),
                "Imprimir" => c.Id is "previsualizar" or "imprimir", _ => true
            };
            var encontrados = ordenados.Where(c => Incluido(c) && c.Texto.Contains(buscarComando.Text, StringComparison.CurrentCultureIgnoreCase)).ToList();
            bool filtrar = !mostrarTodosComandos && buscarComando.Text.Length == 0 && FiltrarPorFrecuenciaGrafico();
            var visibles = encontrados.Where(c => !filtrar || c.Id is "columnas" or "asistente" or "exportar" or "imprimir" || configuracion.UsosComandos.GetValueOrDefault(c.Id) >= 2).ToList();
            mostrarTodos.Visible = visibles.Count < encontrados.Count; listaComandos.DataSource = visibles;
            if (mostrarTodos.Visible && configuracion.ExpandirMenus && tabs.SelectedTab == comandos) pausaComandos.Start();
        }
        mostrarTodos.Click += (_, _) => { pausaComandos.Stop(); mostrarTodosComandos = true; FiltrarComandos(); };
        pausaComandos.Tick += (_, _) => { pausaComandos.Stop(); if (tabs.SelectedTab == comandos && configuracion.ExpandirMenus) { mostrarTodosComandos = true; FiltrarComandos(); } };
        listaComandos.MouseEnter += (_, _) => { if (mostrarTodos.Visible && configuracion.ExpandirMenus) pausaComandos.Start(); };
        buscarComando.TextChanged += (_, _) => FiltrarComandos(); categorias.SelectedIndexChanged += (_, _) => FiltrarComandos();
        buscarCategoria.TextChanged += (_, _) =>
        {
            var seleccion = categorias.SelectedItem; categorias.Items.Clear();
            categorias.Items.AddRange(new[] { "(Elementos sin asignar)", "(Todos los elementos)", "Tipos de gráfico", "Exportar", "Presentación", "Imprimir" }.Where(s => s.Contains(buscarCategoria.Text, StringComparison.CurrentCultureIgnoreCase)).Cast<object>().ToArray());
            if (seleccion != null && categorias.Items.Contains(seleccion)) categorias.SelectedItem = seleccion; else if (categorias.Items.Count > 0) categorias.SelectedIndex = 0;
            FiltrarComandos();
        };
        listaComandos.SelectedIndexChanged += (_, _) => { descripcion.Text = (listaComandos.SelectedItem as ComandoGrafico)?.Descripcion ?? ""; ejecutar.Enabled = listaComandos.SelectedItem != null; };
        void EjecutarSeleccion() { if (listaComandos.SelectedItem is ComandoGrafico c) EjecutarComandoGrafico(c.Id, c.Ejecutar); }
        ejecutar.Click += (_, _) => EjecutarSeleccion(); listaComandos.DoubleClick += (_, _) => EjecutarSeleccion();
        var opciones = new TabPage("Opciones") { AutoScroll = true }; tabs.TabPages.Add(opciones);
        var grupoMenus = new GroupBox { Text = "Personalizar Menús y Barras de Herramientas", Dock = DockStyle.Top, Height = 174 };
        var completos = new RadioButton { Text = "Siempre mostrar menús completos", Checked = configuracion.MenusCompletos, Bounds = new Rectangle(15, 25, 580, 25) };
        var frecuentes = new RadioButton { Text = "Only show frequently used commands", Checked = !configuracion.MenusCompletos, Bounds = new Rectangle(15, 53, 580, 25) };
        var expandir = new CheckBox { Text = "Mostrar menús completos después de una breve pausa", Checked = configuracion.ExpandirMenus, Bounds = new Rectangle(34, 82, 580, 25), Enabled = !configuracion.MenusCompletos };
        var reiniciarUso = new Button { Text = "Reiniciar datos de empleo", Bounds = new Rectangle(34, 120, 235, 29) };
        foreach (Control c in new Control[] { completos, frecuentes, expandir, reiniciarUso }) grupoMenus.Controls.Add(c);
        var grupoOtros = new GroupBox { Text = "Otros", Dock = DockStyle.Top, Height = 235 };
        var grandes = new CheckBox { Text = "Iconos Grandes", Checked = configuracion.IconosGrandes, Bounds = new Rectangle(15, 23, 590, 25) };
        var ayudas = new CheckBox { Text = "Mostrar Consejos en barras de herramientas", Checked = configuracion.MostrarAyudas, Bounds = new Rectangle(15, 52, 590, 25) };
        var atajos = new CheckBox { Text = "Mostrar teclas de atajo en consejos", Checked = configuracion.MostrarAtajos, Bounds = new Rectangle(15, 81, 590, 25) };
        var efectos = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Bounds = new Rectangle(160, 113, 210, 25), DataSource = new[] { "Predeterminado", "Sin animación", "Desvanecer" } };
        efectos.SelectedItem = configuracion.EfectosMenus;
        grupoOtros.Controls.Add(new Label { Text = "Efectos de Menus:", Bounds = new Rectangle(15, 115, 140, 24) });
        var textos = new CheckBox { Text = "Mostrar nombres junto a los iconos", Checked = configuracion.MostrarTextos, Bounds = new Rectangle(15, 149, 590, 25) };
        var visible = new CheckBox { Text = "Mostrar barra Tipo de gráfico", Checked = configuracion.BarraVisible, Bounds = new Rectangle(15, 179, 590, 25) };
        foreach (Control c in new Control[] { grandes, ayudas, atajos, efectos, textos, visible }) grupoOtros.Controls.Add(c);
        opciones.Controls.Add(grupoOtros); opciones.Controls.Add(grupoMenus);
        completos.CheckedChanged += (_, _) => { if (completos.Checked) { CambiarGrafico(c => c.MenusCompletos = true); expandir.Enabled = false; FiltrarComandos(); } };
        frecuentes.CheckedChanged += (_, _) => { if (frecuentes.Checked) { CambiarGrafico(c => c.MenusCompletos = false); expandir.Enabled = true; mostrarTodosComandos = false; FiltrarComandos(); } };
        expandir.CheckedChanged += (_, _) => { CambiarGrafico(c => c.ExpandirMenus = expandir.Checked); if (!expandir.Checked) pausaComandos.Stop(); };
        reiniciarUso.Click += (_, _) => { CambiarGrafico(c => c.UsosComandos.Clear()); mostrarTodosComandos = false; FiltrarComandos(); };
        grandes.CheckedChanged += (_, _) => CambiarGrafico(c => c.IconosGrandes = grandes.Checked);
        ayudas.CheckedChanged += (_, _) => CambiarGrafico(c => c.MostrarAyudas = ayudas.Checked);
        atajos.CheckedChanged += (_, _) => CambiarGrafico(c => c.MostrarAtajos = atajos.Checked);
        efectos.SelectedIndexChanged += (_, _) => CambiarGrafico(c => c.EfectosMenus = (string)efectos.SelectedItem);
        textos.CheckedChanged += (_, _) => CambiarGrafico(c => c.MostrarTextos = textos.Checked);
        visible.CheckedChanged += (_, _) => { CambiarGrafico(c => c.BarraVisible = visible.Checked); sincronizarBarras(); };
        tabs.SelectedIndexChanged += (_, _) =>
        {
            pausaComandos.Stop();
            if (tabs.SelectedTab == comandos) FiltrarComandos();
            if (tabs.SelectedTab == opciones)
            {
                grandes.Checked = configuracion.IconosGrandes; ayudas.Checked = configuracion.MostrarAyudas;
                atajos.Checked = configuracion.MostrarAtajos; textos.Checked = configuracion.MostrarTextos;
                visible.Checked = configuracion.BarraVisible; efectos.SelectedItem = configuracion.EfectosMenus;
            }
        };
        sincronizarBarras(); FiltrarComandos(); dialogo.ShowDialog(this);
    }

    private void LiberarHerramientas()
    {
        foreach (var temporizador in temporizadoresHerramientas) temporizador.Dispose();
        temporizadoresHerramientas.Clear(); menusConEfectos.Clear();
        foreach (var galeria in galeriasGrafico.Distinct()) galeria.Dispose();
        galeriasGrafico.Clear(); menuGrafico?.Dispose();
        foreach (var imagen in imagenesHerramientas) imagen.Dispose();
        imagenesHerramientas.Clear(); iconosHerramientas.Clear(); ayudasGalerias.Dispose(); fuenteMiniaturas?.Dispose(); fuenteGrupos?.Dispose();
        medidasGalerias.Clear(); miniaturasEscaladas.Clear();
    }
}
