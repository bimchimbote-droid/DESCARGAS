using System;
namespace MYG.Externo;
public static partial class AccesoWindows { private static string _machineIdCache="";
public static string ObtenerMachineId()
        {
            if (!string.IsNullOrWhiteSpace(_machineIdCache))
                return _machineIdCache;

            try
            {
                string machineGuid = "";

                using (Microsoft.Win32.RegistryKey key =
                    Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                        @"SOFTWARE\Microsoft\Cryptography"))
                {
                    if (key != null)
                    {
                        object value = key.GetValue("MachineGuid");

                        if (value != null)
                            machineGuid = value.ToString();
                    }
                }

                if (!string.IsNullOrWhiteSpace(machineGuid))
                {
                    _machineIdCache = Sha256(machineGuid);
                    return _machineIdCache;
                }
            }
            catch
            {
            }

            string respaldo =
                Environment.MachineName + "|" +
                Environment.UserName + "|" +
                Environment.UserDomainName;

            _machineIdCache = Sha256(respaldo);
            return _machineIdCache;
        }
private static string Sha256(string s)=>Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(s)));
}
