using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGFuenteResumenForm : Form
{
    private static readonly string[] Estilos = { "Normal", "Cursiva", "Negrita", "Negrita Cursiva" };
    private static readonly float[] Tamanos = { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 };
    private readonly TextBox nombreFuente, estiloFuente, tamanoFuente;
    private readonly ListBox familias, estilos, tamanos;
    private readonly CheckBox tachado, subrayado;
    private readonly SelectorColor colorTexto, colorFondo;
    private readonly MuestraFuente ejemplo;
    private readonly Button aceptar;
    private readonly ErrorProvider errores;
    private readonly Font fuenteInicial;
    private readonly Font fuenteInterfaz;
    private readonly Color tintaInicial, fondoInicial;
    private readonly string[] nombresFuentes;
    private Font fuenteActual;
    private bool sincronizando;

    // El diálogo es propietario de esta fuente; el consumidor debe clonarla antes de cerrarlo.
    internal Font FuenteElegida { get; private set; }
    internal Color ColorTexto { get; private set; }
    internal Color ColorFondo { get; private set; }

    internal MYGFuenteResumenForm(Font fuente, Color color, Color fondo)
    {
        ArgumentNullException.ThrowIfNull(fuente);
        fuenteInicial = (Font)fuente.Clone();
        tintaInicial = color.IsEmpty ? Color.Black : color;
        fondoInicial = fondo.IsEmpty ? Color.White : fondo;
        ColorTexto = tintaInicial; ColorFondo = fondoInicial;
        Text = "Fuente"; Name = "fuenteResumenDialogo";
        ClientSize = new(460, 416);
        StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
        fuenteInterfaz = new Font("Tahoma", 8.25F); Font = fuenteInterfaz;
        AutoScaleDimensions = new(96, 96); AutoScaleMode = AutoScaleMode.Dpi;
        errores = new ErrorProvider { ContainerControl = this, BlinkStyle = ErrorBlinkStyle.NeverBlink };

        using (var instaladas = new InstalledFontCollection())
            nombresFuentes = instaladas.Families.Select(f => f.Name).Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(n => n, StringComparer.CurrentCultureIgnoreCase).ToArray();

        Controls.Add(new Label { Text = "Fuente:", AutoSize = true, Location = new(14, 18) });
        Controls.Add(new Label { Text = "Estilo:", AutoSize = true, Location = new(274, 18) });
        Controls.Add(new Label { Text = "Tamaño:", AutoSize = true, Location = new(392, 18) });
        nombreFuente = Entrada("nombreFuenteResumen", 14, 38, 252);
        estiloFuente = Entrada("estiloFuenteResumen", 274, 38, 110);
        tamanoFuente = Entrada("tamanoFuenteResumen", 392, 38, 54);
        tamanoFuente.MaxLength = 8;
        familias = Lista("familiasFuenteResumen", 14, 66, 252);
        estilos = Lista("estilosFuenteResumen", 274, 66, 110);
        tamanos = Lista("tamanosFuenteResumen", 392, 66, 54);
        familias.DrawMode = DrawMode.OwnerDrawFixed; familias.ItemHeight = 21;
        familias.DrawItem += DibujarFamilia;
        familias.Items.AddRange(nombresFuentes);
        estilos.Items.AddRange(Estilos);
        tamanos.Items.AddRange(Tamanos.Select(t => (object)t.ToString("0.##", CultureInfo.CurrentCulture)).ToArray());
        Controls.AddRange(new Control[] { nombreFuente, estiloFuente, tamanoFuente, familias, estilos, tamanos });

        var efectos = new GroupBox { Text = "Efectos", Location = new(14, 238), Size = new(252, 88) };
        tachado = new CheckBox { Name = "tachadoFuenteResumen", Text = "Tachado", AutoSize = true, Location = new(10, 29) };
        subrayado = new CheckBox { Name = "subrayadoFuenteResumen", Text = "Subrayado", AutoSize = true, Location = new(10, 56) };
        efectos.Controls.AddRange(new Control[] { tachado, subrayado });
        var grupoEjemplo = new GroupBox { Text = "Ejemplo", Location = new(274, 238), Size = new(172, 88) };
        ejemplo = new MuestraFuente { Name = "ejemploFuenteResumen", Location = new(7, 21), Size = new(158, 60),
            AccessibleName = "Vista previa de fuente, color y fondo", AccessibleRole = AccessibleRole.Graphic };
        grupoEjemplo.Controls.Add(ejemplo);
        Controls.Add(efectos); Controls.Add(grupoEjemplo);

        Controls.Add(new Label { Text = "Color:", AutoSize = true, Location = new(14, 345) });
        Controls.Add(new Label { Text = "Fondo:", AutoSize = true, Location = new(248, 345) });
        colorTexto = new SelectorColor { Name = "colorTextoResumen", Location = new(59, 338), Size = new(180, 23),
            AccessibleName = "Color del texto" };
        colorFondo = new SelectorColor { Name = "colorFondoResumen", Location = new(294, 338), Size = new(118, 23),
            AccessibleName = "Color del fondo" };
        var restablecer = new Button { Name = "restablecerFuenteResumen", Location = new(418, 336), Size = new(30, 27),
            FlatStyle = FlatStyle.Flat, AccessibleName = "Restablecer formato inicial", Image = CrearIcono("restablecer") };
        restablecer.FlatAppearance.BorderSize = 0;
        Controls.AddRange(new Control[] { colorTexto, colorFondo, restablecer });

        aceptar = new Button { Name = "aceptarFuenteResumen", Text = "Aceptar", Location = new(262, 382), Size = new(88, 27),
            Image = CrearIcono("aceptar"), TextImageRelation = TextImageRelation.ImageBeforeText };
        var cerrar = new Button { Name = "cerrarFuenteResumen", Text = "Cerrar", Location = new(360, 382), Size = new(86, 27),
            Image = CrearIcono("cerrar"), TextImageRelation = TextImageRelation.ImageBeforeText, DialogResult = DialogResult.Cancel };
        Controls.Add(aceptar); Controls.Add(cerrar); AcceptButton = aceptar; CancelButton = cerrar;

        nombreFuente.TextChanged += (_, _) => Actualizar();
        estiloFuente.TextChanged += (_, _) => Actualizar();
        tamanoFuente.TextChanged += (_, _) => Actualizar();
        familias.SelectedIndexChanged += (_, _) => Seleccionar(familias, nombreFuente);
        estilos.SelectedIndexChanged += (_, _) => Seleccionar(estilos, estiloFuente);
        tamanos.SelectedIndexChanged += (_, _) => Seleccionar(tamanos, tamanoFuente);
        tachado.CheckedChanged += (_, _) => Actualizar(); subrayado.CheckedChanged += (_, _) => Actualizar();
        colorTexto.ColorChanged += (_, _) => ActualizarColoresEjemplo();
        colorFondo.ColorChanged += (_, _) => ActualizarColoresEjemplo();
        restablecer.Click += (_, _) => Restablecer();
        aceptar.Click += (_, _) =>
        {
            if (!Actualizar()) return;
            FuenteElegida?.Dispose(); FuenteElegida = (Font)fuenteActual.Clone();
            ColorTexto = colorTexto.ColorElegido; ColorFondo = colorFondo.ColorElegido;
            DialogResult = DialogResult.OK;
        };
        foreach (var boton in new[] { restablecer, aceptar, cerrar })
            boton.Disposed += (_, _) => boton.Image?.Dispose();

        // Registrar la ventana evita que el filtro de tema reemplace luego sus controles.
        // La muestra dibuja los colores elegidos directamente, sin traducirlos a la paleta de interfaz.
        MYG2027_TemaComercial.Aplicar(this);
        MYG2027_TemaComercial.CambioTema += CambiarTema;
        AplicarColoresDialogo(); Restablecer();
    }

    private static TextBox Entrada(string nombre, int x, int y, int ancho) => new()
        { Name = nombre, Location = new(x, y), Size = new(ancho, 23) };
    private static ListBox Lista(string nombre, int x, int y, int ancho) => new()
        { Name = nombre, Location = new(x, y), Size = new(ancho, 164), IntegralHeight = false };

    private void Seleccionar(ListBox lista, TextBox entrada)
    {
        if (sincronizando || lista.SelectedIndex < 0) return;
        entrada.Text = lista.GetItemText(lista.SelectedItem);
    }

    private void Restablecer()
    {
        sincronizando = true;
        try
        {
            nombreFuente.Text = fuenteInicial.Name;
            estiloFuente.Text = Estilos[(fuenteInicial.Bold ? 2 : 0) | (fuenteInicial.Italic ? 1 : 0)];
            tamanoFuente.Text = fuenteInicial.SizeInPoints.ToString("0.###", CultureInfo.CurrentCulture);
            tachado.Checked = fuenteInicial.Strikeout; subrayado.Checked = fuenteInicial.Underline;
            colorTexto.ColorElegido = tintaInicial; colorFondo.ColorElegido = fondoInicial;
        }
        finally { sincronizando = false; }
        Actualizar();
    }

    private bool Actualizar()
    {
        if (sincronizando) return false;
        int indiceFuente = Array.FindIndex(nombresFuentes, n => n.Equals(nombreFuente.Text.Trim(), StringComparison.OrdinalIgnoreCase));
        int indiceEstilo = Array.FindIndex(Estilos, n => n.Equals(estiloFuente.Text.Trim(), StringComparison.OrdinalIgnoreCase));
        string numero = tamanoFuente.Text.Trim().Replace(',', '.');
        bool tamanoValido = float.TryParse(numero, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out float tamano)
            && float.IsFinite(tamano) && tamano >= 1 && tamano <= 200;
        errores.SetError(nombreFuente, indiceFuente < 0 ? "Seleccione una fuente instalada." : "");
        errores.SetError(estiloFuente, indiceEstilo < 0 ? "Seleccione uno de los cuatro estilos." : "");
        errores.SetError(tamanoFuente, tamanoValido ? "" : "Ingrese un tamaño entre 1 y 200 puntos.");
        sincronizando = true;
        try
        {
            familias.SelectedIndex = indiceFuente;
            estilos.SelectedIndex = indiceEstilo;
            tamanos.SelectedIndex = tamanoValido ? Array.IndexOf(Tamanos, tamano) : -1;
        }
        finally { sincronizando = false; }
        aceptar.Enabled = indiceFuente >= 0 && indiceEstilo >= 0 && tamanoValido;
        if (!aceptar.Enabled) return false;
        FontStyle estilo = indiceEstilo switch { 1 => FontStyle.Italic, 2 => FontStyle.Bold,
            3 => FontStyle.Bold | FontStyle.Italic, _ => FontStyle.Regular };
        if (tachado.Checked) estilo |= FontStyle.Strikeout;
        if (subrayado.Checked) estilo |= FontStyle.Underline;
        try
        {
            var siguiente = new Font(nombresFuentes[indiceFuente], tamano, estilo, GraphicsUnit.Point);
            var anterior = fuenteActual; fuenteActual = siguiente; ejemplo.FuenteMuestra = siguiente;
            anterior?.Dispose(); ActualizarColoresEjemplo();
            return true;
        }
        catch (ArgumentException)
        {
            errores.SetError(estiloFuente, "Esta fuente no admite el estilo seleccionado."); aceptar.Enabled = false;
            return false;
        }
    }

    private void ActualizarColoresEjemplo()
    {
        ejemplo.Tinta = colorTexto.ColorElegido; ejemplo.Papel = colorFondo.ColorElegido; ejemplo.Invalidate();
    }

    private void DibujarFamilia(object sender, DrawItemEventArgs e)
    {
        if (e.Index < 0) return;
        e.DrawBackground();
        Font muestra = null;
        try { muestra = new Font(nombresFuentes[e.Index], 10F); }
        catch (ArgumentException) { }
        TextRenderer.DrawText(e.Graphics, nombresFuentes[e.Index], muestra ?? familias.Font, e.Bounds, e.ForeColor,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        muestra?.Dispose(); e.DrawFocusRectangle();
    }

    private void CambiarTema(object sender, EventArgs e) => AplicarColoresDialogo();
    private void AplicarColoresDialogo()
    {
        Color fondo = SystemInformation.HighContrast ? SystemColors.Control : Color.FromArgb(210, 224, 241);
        void Aplicar(Control control)
        {
            control.Font = fuenteInterfaz;
            control.BackColor = control is TextBox or ListBox or ComboBox ? SystemColors.Window : fondo;
            control.ForeColor = SystemColors.ControlText;
            foreach (Control hijo in control.Controls) Aplicar(hijo);
        }
        Aplicar(this);
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        // El filtro global aplica el tema en WM_SHOWWINDOW, después de construir el diálogo.
        AplicarColoresDialogo();
    }

    private static Bitmap CrearIcono(string accion)
    {
        var imagen = new Bitmap(18, 18);
        using var g = Graphics.FromImage(imagen); g.SmoothingMode = SmoothingMode.AntiAlias;
        if (accion == "aceptar")
        {
            using var verde = new Pen(Color.FromArgb(58, 157, 78), 2.5F);
            g.DrawLines(verde, new[] { new Point(2, 9), new Point(7, 14), new Point(16, 3) });
        }
        else if (accion == "cerrar")
        {
            using var rojo = new SolidBrush(Color.FromArgb(220, 67, 94)); g.FillEllipse(rojo, 1, 1, 16, 16);
            using var blanco = new Pen(Color.White, 1.6F); g.DrawLine(blanco, 5, 5, 13, 13); g.DrawLine(blanco, 13, 5, 5, 13);
        }
        else
        {
            using var azul = new Pen(Color.FromArgb(72, 131, 192), 1.5F);
            g.DrawArc(azul, 2, 2, 14, 14, 190, 300);
            g.DrawLines(azul, new[] { new Point(2, 1), new Point(2, 6), new Point(7, 6) });
        }
        return imagen;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            MYG2027_TemaComercial.CambioTema -= CambiarTema;
            errores?.Dispose(); fuenteInicial?.Dispose(); fuenteActual?.Dispose(); FuenteElegida?.Dispose(); fuenteInterfaz?.Dispose();
        }
        base.Dispose(disposing);
    }

    private sealed class MuestraFuente : Control
    {
        internal Font FuenteMuestra;
        internal Color Tinta, Papel;
        internal MuestraFuente() => SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Papel);
            if (FuenteMuestra != null)
                TextRenderer.DrawText(e.Graphics, "AaBbCc", FuenteMuestra, ClientRectangle, Tinta, Papel,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
        }
    }

    private sealed class SelectorColor : ComboBox
    {
        private sealed record Opcion(string Nombre, Color Color, bool Elegir = false)
        { public override string ToString() => Nombre; }
        private Color elegido;
        private bool actualizando;
        internal event EventHandler ColorChanged;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal Color ColorElegido
        {
            get => elegido;
            set
            {
                elegido = value; actualizando = true;
                try
                {
                    int indice = Items.Cast<Opcion>().ToList().FindIndex(o => !o.Elegir && o.Color.ToArgb() == value.ToArgb());
                    if (indice < 0) { indice = Items.Count - 1; Items.Insert(indice, new Opcion("Personalizado", value)); }
                    SelectedIndex = indice;
                }
                finally { actualizando = false; }
                Invalidate(); ColorChanged?.Invoke(this, EventArgs.Empty);
            }
        }
        internal SelectorColor()
        {
            DropDownStyle = ComboBoxStyle.DropDownList; DrawMode = DrawMode.OwnerDrawFixed; ItemHeight = 17;
            Items.AddRange(new object[] { new Opcion("Negro", Color.Black), new Opcion("Blanco", Color.White),
                new Opcion("Gris", Color.Gray), new Opcion("Rojo", Color.Red), new Opcion("Naranja", Color.Orange),
                new Opcion("Amarillo", Color.Yellow), new Opcion("Verde", Color.Green), new Opcion("Azul", Color.Blue),
                new Opcion("Violeta", Color.Purple), new Opcion("Más colores…", Color.Empty, true) });
            SelectedIndexChanged += (_, _) =>
            {
                if (actualizando || SelectedItem is not Opcion opcion) return;
                if (opcion.Elegir)
                {
                    using var dialogo = new ColorDialog { Color = elegido, FullOpen = true };
                    ColorElegido = dialogo.ShowDialog(FindForm()) == DialogResult.OK ? dialogo.Color : elegido;
                }
                else { elegido = opcion.Color; ColorChanged?.Invoke(this, EventArgs.Empty); }
            };
        }
        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            e.DrawBackground();
            if (e.Index < 0 || Items[e.Index] is not Opcion opcion) return;
            if (opcion.Elegir)
                TextRenderer.DrawText(e.Graphics, opcion.Nombre, Font, e.Bounds, e.ForeColor, TextFormatFlags.VerticalCenter);
            else
            {
                var muestra = new Rectangle(e.Bounds.X + 5, e.Bounds.Y + 3, 25, Math.Max(5, e.Bounds.Height - 6));
                using var relleno = new SolidBrush(opcion.Color); e.Graphics.FillRectangle(relleno, muestra);
                e.Graphics.DrawRectangle(SystemPens.WindowText, muestra);
                if ((e.State & DrawItemState.ComboBoxEdit) == 0)
                    TextRenderer.DrawText(e.Graphics, opcion.Nombre, Font,
                        new Rectangle(e.Bounds.X + 37, e.Bounds.Y, e.Bounds.Width - 37, e.Bounds.Height), e.ForeColor,
                        TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            }
            e.DrawFocusRectangle();
        }
    }
}
