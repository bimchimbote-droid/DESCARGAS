using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGGrabarCostosMultiplesForm : Form
{
    internal string Grupo { get; private set; }
    internal IReadOnlyList<string> PartidasSeleccionadas { get; private set; } = Array.Empty<string>();
    private readonly ComboBox grupo = new() { Name = "cmbGrupoCostos", Dock = DockStyle.Fill,
        DropDownStyle = ComboBoxStyle.DropDownList, AccessibleName = "Grupo de costos unitarios" };
    private readonly DataGridView tabla = new() { Name = "tablaCostosMultiples", Dock = DockStyle.Fill,
        AllowUserToAddRows = false, AllowUserToDeleteRows = false, RowHeadersVisible = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
        BackgroundColor = Color.White, AutoGenerateColumns = false, EnableHeadersVisualStyles = false };
    private readonly TextBox filtro = new() { Name = "txtFiltroCostosMultiples", Dock = DockStyle.Top,
        PlaceholderText = "Buscar partida por ítem, descripción o unidad…" };
    private readonly Label cantidad = new() { Name = "lblCostosMultiplesSeleccionados", AutoSize = true, Padding = new(5, 8, 0, 0) };
    private readonly List<ItemPresupuestoDelphin> partidas;
    private readonly HashSet<string> marcadas = new(StringComparer.OrdinalIgnoreCase);
    private bool cargando;

    internal MYGGrabarCostosMultiplesForm(IEnumerable<ItemPresupuestoDelphin> partidas,
        IEnumerable<string> seleccionInicial, IEnumerable<string> grupos)
    {
        Name = "frmGrabarCostosMultiples";
        MYGInsumosUI.Preparar(this, "Grabar data de costos múltiples");
        ClientSize = new(850, 560); MinimumSize = new(720, 450);
        this.partidas = partidas.Where(x => !MYGProyectoStorage.EsTitulo(x)).ToList();
        marcadas.UnionWith(seleccionInicial ?? Array.Empty<string>());
        marcadas.IntersectWith(this.partidas.Select(x => x.IdLocalMYG));
        var opciones = (grupos ?? Array.Empty<string>()).Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToArray();
        grupo.Items.AddRange(opciones.Length == 0 ? new[] { "GENERAL" } : opciones);
        grupo.SelectedIndex = 0;
        var cabecera = new TableLayoutPanel { Dock = DockStyle.Top, Height = 54, ColumnCount = 3, Padding = new(10) };
        cabecera.ColumnStyles.Add(new(SizeType.Absolute, 65)); cabecera.ColumnStyles.Add(new(SizeType.Percent, 100));
        cabecera.ColumnStyles.Add(new(SizeType.Absolute, 38));
        cabecera.Controls.Add(new Label { Text = "Grupo:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        cabecera.Controls.Add(grupo, 1, 0);
        var nuevoGrupo = new Button { Name = "btnNuevoGrupoCostos", Text = "+", Dock = DockStyle.Fill,
            AccessibleName = "Crear grupo de costos unitarios" };
        MYG2027_TemaComercial.EstilizarBoton(nuevoGrupo);
        nuevoGrupo.Click += (s, e) =>
        {
            using var nuevo = new MYGCamposProyectoForm("Nuevo grupo de costos unitarios", new[] { "Grupo" }, new[] { "" });
            if (nuevo.ShowDialog(this) != DialogResult.OK) return;
            string nombre = nuevo.Valores[0].Trim();
            if (nombre.Length == 0 || nombre.Length > 120 || nombre.Any(char.IsControl))
            { MessageBox.Show(this, "Indique un grupo de entre 1 y 120 caracteres.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            int existente = Enumerable.Range(0, grupo.Items.Count).FirstOrDefault(n =>
                string.Equals(Convert.ToString(grupo.Items[n]), nombre, StringComparison.OrdinalIgnoreCase), -1);
            grupo.SelectedIndex = existente >= 0 ? existente : grupo.Items.Add(nombre);
        };
        cabecera.Controls.Add(nuevoGrupo, 2, 0);
        tabla.Columns.Add(new DataGridViewCheckBoxColumn { Name = "SEL", HeaderText = "Sel.", Width = 48,
            Frozen = true, SortMode = DataGridViewColumnSortMode.NotSortable });
        foreach (var (nombre, titulo, ancho) in new[] { ("ITEM", "Ítem", 100), ("DESC", "Partida / costo unitario", 450), ("UND", "Unidad", 80) })
            tabla.Columns.Add(new DataGridViewTextBoxColumn { Name = nombre, HeaderText = titulo, Width = ancho,
                ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable });
        tabla.Columns["DESC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        tabla.ColumnHeadersDefaultCellStyle.BackColor = MYGPanelPresupuesto.AzulClaro;
        tabla.CurrentCellDirtyStateChanged += (s, e) =>
        { if (!cargando && tabla.IsCurrentCellDirty && tabla.CurrentCell?.OwningColumn.Name == "SEL") tabla.CommitEdit(DataGridViewDataErrorContexts.Commit); };
        tabla.CellValueChanged += (s, e) =>
        {
            if (cargando || e.RowIndex < 0 || e.ColumnIndex < 0 || tabla.Columns[e.ColumnIndex].Name != "SEL") return;
            var partida = (ItemPresupuestoDelphin)tabla.Rows[e.RowIndex].Tag;
            if (tabla.Rows[e.RowIndex].Cells["SEL"].Value is true) marcadas.Add(partida.IdLocalMYG); else marcadas.Remove(partida.IdLocalMYG);
            ActualizarCantidad();
        };
        var seleccion = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, Padding = new(5), WrapContents = false };
        var marcar = MYGInsumosUI.Boton("Marcar visibles", "aceptar"); marcar.Name = "btnMarcarCostosVisibles";
        var limpiar = MYGInsumosUI.Boton("Limpiar selección", "cerrar"); limpiar.Name = "btnLimpiarCostosMultiples";
        marcar.Click += (s, e) => { tabla.EndEdit(); foreach (DataGridViewRow fila in tabla.Rows) fila.Cells["SEL"].Value = true; };
        limpiar.Click += (s, e) => { tabla.EndEdit(); marcadas.Clear(); Filtrar(); };
        seleccion.Controls.AddRange(new Control[] { marcar, limpiar, cantidad });
        filtro.TextChanged += (s, e) => Filtrar();
        Controls.Add(tabla); Controls.Add(filtro); Controls.Add(seleccion); Controls.Add(cabecera);
        Controls.Add(new Label { Dock = DockStyle.Bottom, Height = 42, Padding = new(8),
            Text = "Las partidas marcadas se guardarán con su ACU en el grupo elegido del catálogo de partidas." });
        Controls.Add(MYGInsumosUI.Pie(this, Aceptar));
        Filtrar();
    }
    private void Filtrar()
    {
        tabla.EndEdit(); cargando = true;
        try
        {
            tabla.Rows.Clear(); string texto = filtro.Text.Trim();
            foreach (var partida in partidas.Where(x => (x.Item + " " + x.Descripcion + " " + x.Unidad)
                .Contains(texto, StringComparison.OrdinalIgnoreCase)))
                tabla.Rows[tabla.Rows.Add(marcadas.Contains(partida.IdLocalMYG), partida.Item, partida.Descripcion, partida.Unidad)].Tag = partida;
            tabla.ClearSelection();
        }
        finally { cargando = false; ActualizarCantidad(); }
    }
    private void ActualizarCantidad()
    {
        cantidad.Text = marcadas.Count + " seleccionados";
        if (AcceptButton is Button aceptar) aceptar.Enabled = marcadas.Count > 0;
    }
    private void Aceptar()
    {
        tabla.EndEdit(); string nombre = Convert.ToString(grupo.SelectedItem)?.Trim();
        if (string.IsNullOrWhiteSpace(nombre)) throw new InvalidOperationException("Seleccione o cree un grupo de costos unitarios.");
        var seleccion = partidas.Where(x => marcadas.Contains(x.IdLocalMYG)).Select(x => x.IdLocalMYG).ToArray();
        if (seleccion.Length == 0) throw new InvalidOperationException("Marque las partidas que desea grabar.");
        Grupo = nombre; PartidasSeleccionadas = Array.AsReadOnly(seleccion); DialogResult = DialogResult.OK;
    }
}
