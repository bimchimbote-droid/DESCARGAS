using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace MYG_2027;

/// <summary>Iconos originales de MYG, con reemplazos locales y respaldo incrustado.</summary>
internal static class MYGIconos
{
    private const string PrefijoRecurso = "MYG_2027.Iconos.";
    private static readonly HashSet<string> Nombres = new(StringComparer.OrdinalIgnoreCase)
    {
        "guardar", "agregar", "titulo", "partida", "catalogo", "editar", "eliminar", "proyecto",
        "excel", "imprimir", "resumen", "insumos", "unidades", "especificacion", "deshacer", "rehacer",
        "bim", "sesion", "arriba", "abajo", "expandir", "contraer", "insertar_sobre", "insertar_final",
        "recalcular", "codigo_estandar", "codigo_alterno", "buscar", "aceptar", "cerrar", "acu", "imagen", "marca"
    };

    /// <summary>Devuelve una imagen independiente. El control que la recibe debe liberarla al cerrarse.</summary>
    internal static Bitmap Obtener(string nombre)
    {
        nombre = (nombre ?? "").Trim().ToLowerInvariant();
        if (!Nombres.Contains(nombre)) throw new ArgumentException("Icono MYG desconocido: " + nombre, nameof(nombre));
        var ruta = Path.Combine(AppContext.BaseDirectory, "Iconos", nombre + ".png");
        if (File.Exists(ruta))
        {
            try
            {
                using var archivo = File.OpenRead(ruta);
                using var imagen = Image.FromStream(archivo, useEmbeddedColorManagement: true, validateImageData: true);
                return new Bitmap(imagen);
            }
            catch (Exception ex) when (ErrorDeImagen(ex))
            {
                // Un reemplazo dañado o inaccesible conserva el icono original incrustado.
            }
        }
        var ensamblado = typeof(MYGIconos).Assembly;
        string esperado = PrefijoRecurso + nombre + ".png";
        string recursoNombre = ensamblado.GetManifestResourceNames().FirstOrDefault(n => n.Equals(esperado, StringComparison.OrdinalIgnoreCase))
            ?? ensamblado.GetManifestResourceNames().FirstOrDefault(n => n.EndsWith(".Iconos." + nombre + ".png", StringComparison.OrdinalIgnoreCase));
        if (recursoNombre != null)
        {
            try
            {
                using var recurso = ensamblado.GetManifestResourceStream(recursoNombre);
                if (recurso != null)
                {
                    using var original = Image.FromStream(recurso, useEmbeddedColorManagement: true, validateImageData: true);
                    return new Bitmap(original);
                }
            }
            catch (Exception ex) when (ErrorDeImagen(ex))
            {
                // Un recurso inválido usa el respaldo dibujado igual que uno ausente.
            }
        }
        // El editor debe poder abrirse incluso si se copiaron los .cs sin los PNG
        // o se compiló con un proyecto que no incrustó los recursos.
        return DibujarRespaldo(nombre);
    }

    private static bool ErrorDeImagen(Exception ex) => ex is IOException or UnauthorizedAccessException
        or ArgumentException or OutOfMemoryException or ExternalException or NotSupportedException;

    private static Bitmap DibujarRespaldo(string nombre)
    {
        var imagen = new Bitmap(32, 32);
        using var g = Graphics.FromImage(imagen);
        g.Clear(Color.Transparent); g.SmoothingMode = SmoothingMode.AntiAlias;
        using var azul = new SolidBrush(Color.FromArgb(47, 104, 174));
        using var blanco = new SolidBrush(Color.White);
        using var linea = new Pen(Color.FromArgb(47, 104, 174), 2.5F) { LineJoin = LineJoin.Round };
        if (nombre == "guardar")
        {
            g.FillPolygon(azul, new[] { new Point(5, 4), new Point(23, 4), new Point(27, 8), new Point(27, 28), new Point(5, 28) });
            g.FillRectangle(blanco, 10, 5, 11, 8); g.FillRectangle(blanco, 9, 19, 14, 8);
            g.DrawLine(linea, 12, 23, 20, 23);
        }
        else if (nombre is "cerrar" or "eliminar")
        {
            using var rojo = new Pen(Color.FromArgb(213, 73, 82), 4F) { StartCap = LineCap.Round, EndCap = LineCap.Round };
            g.DrawLine(rojo, 8, 8, 24, 24); g.DrawLine(rojo, 24, 8, 8, 24);
        }
        else if (nombre == "aceptar")
        {
            using var verde = new Pen(Color.FromArgb(104, 159, 59), 4F) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
            g.DrawLines(verde, new[] { new Point(6, 17), new Point(13, 24), new Point(27, 8) });
        }
        else if (nombre is "arriba" or "abajo")
        {
            if (nombre == "abajo") { g.TranslateTransform(32, 32); g.RotateTransform(180); }
            g.FillPolygon(azul, new[] { new Point(16, 4), new Point(4, 17), new Point(11, 17), new Point(11, 28), new Point(21, 28), new Point(21, 17), new Point(28, 17) });
        }
        else
        {
            g.FillRectangle(blanco, 6, 4, 20, 24); g.DrawRectangle(linea, 6, 4, 20, 24);
            g.DrawLine(linea, 10, 11, 22, 11); g.DrawLine(linea, 10, 17, 22, 17); g.DrawLine(linea, 10, 23, 18, 23);
        }
        return imagen;
    }

    internal static IReadOnlyList<string> Disponibles => Nombres.OrderBy(n => n, StringComparer.Ordinal).ToArray();
}
