using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGEditarFormulaResumenForm : Form
{
    internal string Formula { get; private set; }
    internal MYGEditarFormulaResumenForm(string formula, IReadOnlyList<(string Identificador, string Nombre)> anteriores, Action<string> validar)
    {
        Text = "Editar fórmulas"; ClientSize = new(560, 370); StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false; Font = new("Segoe UI", 10);
        var contenido = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(12), ColumnCount = 1, RowCount = 5 };
        contenido.RowStyles.Add(new(SizeType.Absolute, 40)); contenido.RowStyles.Add(new(SizeType.Absolute, 65));
        contenido.RowStyles.Add(new(SizeType.Absolute, 24)); contenido.RowStyles.Add(new(SizeType.Percent, 100)); contenido.RowStyles.Add(new(SizeType.Absolute, 45));
        contenido.Controls.Add(new Label { Dock = DockStyle.Fill, Text = "Use +, −, *, / y paréntesis. Puede usar CD, ACUMULADO y los identificadores de las filas anteriores." }, 0, 0);
        var expresion = new TextBox { Name = "expresionFormulaResumen", Dock = DockStyle.Fill, Multiline = true, Text = formula, MaxLength = 2000 };
        contenido.Controls.Add(expresion, 0, 1);
        contenido.Controls.Add(new Label { Text = "Doble clic para insertar una variable:", AutoSize = true }, 0, 2);
        var variables = new ListBox { Name = "variablesFormulaResumen", Dock = DockStyle.Fill };
        var tokens = new List<string> { "CD", "ACUMULADO" };
        variables.Items.AddRange(new object[] { "CD — Costo directo", "ACUMULADO — Costo directo y conceptos anteriores" });
        foreach (var anterior in anteriores) { tokens.Add(anterior.Identificador); variables.Items.Add(anterior.Identificador + " — " + anterior.Nombre); }
        variables.DoubleClick += (_, _) => { if (variables.SelectedIndex < 0) return; expresion.SelectedText = tokens[variables.SelectedIndex]; expresion.Focus(); };
        contenido.Controls.Add(variables, 0, 3);
        var estado = new Label { Dock = DockStyle.Fill, AutoEllipsis = true };
        contenido.Controls.Add(estado, 0, 4);
        var botones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45, FlowDirection = FlowDirection.RightToLeft, Padding = new(5) };
        var cerrar = new Button { Text = "Cerrar", DialogResult = DialogResult.Cancel, AutoSize = true };
        var aceptar = new Button { Text = "Aceptar", AutoSize = true, Enabled = !string.IsNullOrWhiteSpace(expresion.Text) };
        expresion.TextChanged += (_, _) => { aceptar.Enabled = !string.IsNullOrWhiteSpace(expresion.Text); estado.Text = ""; };
        aceptar.Click += (_, _) =>
        {
            try { validar(expresion.Text.Trim()); Formula = expresion.Text.Trim(); DialogResult = DialogResult.OK; }
            catch (Exception ex) { estado.ForeColor = Color.Firebrick; estado.Text = ex.Message; }
        };
        botones.Controls.Add(cerrar); botones.Controls.Add(aceptar);
        Controls.Add(contenido); Controls.Add(botones); AcceptButton = aceptar; CancelButton = cerrar;
        MYG2027_TemaComercial.Aplicar(this);
    }
}
