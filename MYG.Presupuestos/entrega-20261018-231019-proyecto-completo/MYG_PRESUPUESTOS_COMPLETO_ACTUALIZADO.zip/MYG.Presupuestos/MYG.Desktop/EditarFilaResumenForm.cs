using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGEditarFilaResumenForm : Form
{
    internal MYGFilaPiePersonalizada Valor { get; private set; }
    private string formulaEditada;

    internal MYGEditarFilaResumenForm(MYGFilaPiePersonalizada fila, bool predeterminada = false, bool varios = false,
        IReadOnlyList<MYGPresupuestoDocumento> presupuestos = null, string insertarDespuesId = null, bool nueva = false)
    {
        StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
        Font = new("Segoe UI", 10); AutoScaleMode = AutoScaleMode.Font;
        if (predeterminada) { PrepararPredeterminada(fila, varios); return; }
        Text = "Fila de resumen"; ClientSize = new(720, 450);
        var original = MYGProyectoStorage.Copia(fila);
        var modoInicial = MYGPiePresupuesto.ModoEfectivo(original);
        formulaEditada = original.Formula ?? (original.Modo == null && original.Base == MYGBaseFilaPie.Acumulado ? "ACUMULADO" : "");
        var tipo = new ComboBox { Name = "tipoFilaResumen", DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
        tipo.Items.AddRange(new object[] { "Campo personalizado", "Gastos Generales", "Utilidad" }); tipo.SelectedIndex = (int)original.Tipo;
        var etiqueta = new TextBox { Name = "etiquetaFilaResumen", Text = original.Nombre, Dock = DockStyle.Fill, MaxLength = 120 };
        var identificador = new TextBox { Name = "identificadorFilaResumen", Text = original.Identificador ?? "", Dock = DockStyle.Fill, MaxLength = 64 };
        if (!nueva && string.IsNullOrWhiteSpace(identificador.Text)) identificador.Text = IdentificadorDisponible(presupuestos, original.Id, "FILA");
        var cabecera = new TableLayoutPanel { Dock = DockStyle.Top, Height = 130, Padding = new(16), ColumnCount = 2 };
        cabecera.ColumnStyles.Add(new(SizeType.Absolute, 125)); cabecera.ColumnStyles.Add(new(SizeType.Percent, 100));
        void Campo(string texto, Control control, int indice)
        {
            cabecera.RowStyles.Add(new(SizeType.Absolute, 33));
            cabecera.Controls.Add(new Label { Text = texto, AutoSize = true, Anchor = AnchorStyles.Right, Margin = new(0, 0, 12, 0) }, 0, indice);
            cabecera.Controls.Add(control, 1, indice);
        }
        Campo("Tipo:", tipo, 0); Campo("Etiqueta:", etiqueta, 1); Campo("Identificador:", identificador, 2);
        var opciones = new TableLayoutPanel { Dock = DockStyle.Top, Height = 184, Padding = new(137, 2, 12, 2), ColumnCount = 2 };
        opciones.ColumnStyles.Add(new(SizeType.Percent, 100)); opciones.ColumnStyles.Add(new(SizeType.AutoSize));
        var radios = new[]
        {
            new RadioButton { Name = "gastoConSustento", Text = "Gasto con sustento (% del costo directo)", AutoSize = true },
            new RadioButton { Name = "otrosGastosFormula", Text = "Otros Gastos con o sin sustento (% de fórmula)", AutoSize = true },
            new RadioButton { Name = "valorManualResumen", Text = "Valor ingresado manualmente", AutoSize = true },
            new RadioButton { Name = "formulaResumen", Text = "Fórmula", AutoSize = true }
        };
        for (int n = 0; n < radios.Length; n++)
        { opciones.RowStyles.Add(new(SizeType.Absolute, 44)); opciones.Controls.Add(radios[n], 0, n); if (n < 3) opciones.SetColumnSpan(radios[n], 2); }
        radios[(int)modoInicial].Checked = true;
        var valor = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 36, Padding = new(137, 0, 12, 0), WrapContents = false };
        var tituloValor = new Label { AutoSize = true, Margin = new(0, 6, 8, 0) };
        var porcentaje = new NumericUpDown { Name = "porcentajeFilaResumen", Minimum = 0, Maximum = 10000, DecimalPlaces = 4,
            Value = Math.Clamp(original.Porcentaje, 0, 10000), Width = 100, ThousandsSeparator = true };
        var manual = new NumericUpDown { Name = "importeManualResumen", Minimum = decimal.MinValue, Maximum = decimal.MaxValue, DecimalPlaces = 6,
            Value = original.ValorManual, Width = 160, ThousandsSeparator = true };
        var editarFormula = new Button { Name = "editarFormulasResumen", Text = "Editar fórmulas…", AutoSize = true, Height = 30, Margin = new(14, 0, 0, 0) };
        editarFormula.Image = MYGResumenPieIconos.Crear("formula"); editarFormula.ImageAlign = ContentAlignment.MiddleLeft;
        editarFormula.TextImageRelation = TextImageRelation.ImageBeforeText;
        editarFormula.Disposed += (_, _) => editarFormula.Image?.Dispose();
        opciones.Controls.Add(editarFormula, 1, 3);
        valor.Controls.AddRange(new Control[] { tituloValor, porcentaje, manual });
        var mensaje = new Label { Name = "estadoFilaResumen", Dock = DockStyle.Fill, Padding = new(18, 4, 18, 0), AutoEllipsis = true };
        var botones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, FlowDirection = FlowDirection.RightToLeft, Padding = new(12, 5, 12, 5) };
        var cerrar = new Button { Name = "cerrarFilaResumen", Text = "Cerrar", DialogResult = DialogResult.Cancel, AutoSize = true };
        var aceptar = new Button { Name = "aceptarFilaResumen", Text = "Aceptar", AutoSize = true };
        botones.Controls.Add(cerrar); botones.Controls.Add(aceptar);
        MYGModoFilaResumen Modo() => (MYGModoFilaResumen)Array.FindIndex(radios, r => r.Checked);
        MYGFilaPiePersonalizada Propuesta() => new()
        {
            Id = original.Id, Nombre = etiqueta.Text.Trim(), Identificador = identificador.Text.Trim(), Tipo = (MYGTipoFilaResumen)tipo.SelectedIndex,
            Modo = Modo(), Porcentaje = porcentaje.Value, ValorManual = manual.Value, Formula = formulaEditada, Base = original.Base
        };
        void ActualizarEstado()
        {
            var modo = Modo(); bool formula = modo is MYGModoFilaResumen.OtrosGastos or MYGModoFilaResumen.Formula;
            bool porcentual = modo is MYGModoFilaResumen.GastoConSustento or MYGModoFilaResumen.OtrosGastos;
            editarFormula.Visible = formula;
            porcentaje.Visible = porcentual; manual.Visible = modo == MYGModoFilaResumen.ValorManual;
            tituloValor.Text = porcentual ? "Porcentaje (%)" : modo == MYGModoFilaResumen.ValorManual ? "Importe" : "";
            tituloValor.Visible = porcentual || modo == MYGModoFilaResumen.ValorManual;
            aceptar.Enabled = !string.IsNullOrWhiteSpace(etiqueta.Text) &&
                Regex.IsMatch(identificador.Text.Trim(), @"^[A-Za-z_][A-Za-z0-9_]*$") && (!formula || !string.IsNullOrWhiteSpace(formulaEditada));
            mensaje.ForeColor = MYG2027_TemaComercial.Texto;
            mensaje.Text = varios ? "Hay valores distintos. Aceptar aplicará los valores indicados a todos los presupuestos del alcance." :
                "Identificador: letras, números y guion bajo; empiece con una letra o guion bajo. Se puede usar en las fórmulas de las filas siguientes.";
        }
        void ValidarPropuesta(MYGFilaPiePersonalizada propuesta)
        {
            var destinos = presupuestos?.Count > 0 ? presupuestos : new[] { new MYGPresupuestoDocumento { Nombre = "Resumen" } };
            foreach (var destino in destinos)
            {
                var filas = MYGProyectoStorage.Copia(destino.Costos.PiePersonalizado) ?? new List<MYGFilaPiePersonalizada>();
                int indice = filas.FindIndex(f => f.Id == propuesta.Id);
                if (indice >= 0) filas[indice] = MYGProyectoStorage.Copia(propuesta);
                else
                {
                    int anterior = insertarDespuesId == MYGPiePresupuesto.IdTotal ? filas.Count - 1 :
                        insertarDespuesId == null ? -1 : filas.FindIndex(f => f.Id == insertarDespuesId);
                    filas.Insert(anterior + 1, MYGProyectoStorage.Copia(propuesta));
                }
                MYGPiePresupuesto.ValidarPersonalizado(new[] { destino }, filas);
            }
        }
        editarFormula.Click += (_, _) =>
        {
            var anteriores = presupuestos?.FirstOrDefault()?.Costos.PiePersonalizado ?? new List<MYGFilaPiePersonalizada>();
            int posicion = anteriores.FindIndex(f => f.Id == original.Id);
            if (posicion < 0) posicion = insertarDespuesId == MYGPiePresupuesto.IdTotal ? anteriores.Count :
                insertarDespuesId == null ? 0 : anteriores.FindIndex(f => f.Id == insertarDespuesId) + 1;
            var variables = anteriores.Take(posicion).Where(f => !string.IsNullOrWhiteSpace(f.Identificador))
                .Select(f => (f.Identificador, f.Nombre)).ToList();
            using var editor = new MYGEditarFormulaResumenForm(formulaEditada, variables, texto =>
            {
                var propuesta = Propuesta(); propuesta.Formula = texto;
                // Se puede definir la expresión antes de completar los campos del diálogo principal.
                if (string.IsNullOrWhiteSpace(propuesta.Nombre)) propuesta.Nombre = "Nueva fila";
                if (string.IsNullOrWhiteSpace(propuesta.Identificador)) propuesta.Identificador = null;
                ValidarPropuesta(propuesta);
            });
            if (editor.ShowDialog(this) == DialogResult.OK) { formulaEditada = editor.Formula; ActualizarEstado(); }
        };
        aceptar.Click += (_, _) =>
        {
            try { var propuesta = Propuesta(); ValidarPropuesta(propuesta); Valor = propuesta; DialogResult = DialogResult.OK; }
            catch (Exception ex) { mensaje.ForeColor = Color.Firebrick; mensaje.Text = ex.Message; }
        };
        foreach (var radio in radios) radio.CheckedChanged += (_, _) => ActualizarEstado();
        etiqueta.TextChanged += (_, _) =>
        {
            identificador.Text = IdentificadorDesdeEtiqueta(etiqueta.Text);
            ActualizarEstado();
        };
        identificador.TextChanged += (_, _) => ActualizarEstado();
        tipo.SelectedIndexChanged += (_, _) =>
        {
            if (tipo.SelectedIndex is 1 or 2)
            {
                if (string.IsNullOrWhiteSpace(etiqueta.Text) || etiqueta.Text is "Gastos Generales" or "Utilidad") etiqueta.Text = tipo.Text;
                if (string.IsNullOrWhiteSpace(identificador.Text)) identificador.Text = IdentificadorDisponible(presupuestos, original.Id, tipo.SelectedIndex == 1 ? "GG" : "UT");
            }
            ActualizarEstado();
        };
        Controls.Add(mensaje); Controls.Add(valor); Controls.Add(opciones); Controls.Add(cabecera); Controls.Add(botones);
        AcceptButton = aceptar; CancelButton = cerrar;
        MYG2027_TemaComercial.Aplicar(this); ActualizarEstado();
    }

    private static string IdentificadorDesdeEtiqueta(string etiqueta)
    {
        if (string.IsNullOrEmpty(etiqueta)) return "";
        var resultado = new StringBuilder("user_");
        foreach (char caracter in etiqueta.Normalize(NormalizationForm.FormD).ToLowerInvariant())
        {
            if (caracter == ' ') resultado.Append('_');
            else if (caracter is >= 'a' and <= 'z') resultado.Append(caracter);
            if (resultado.Length == 64) break;
        }
        return resultado.ToString();
    }

    private static string IdentificadorDisponible(IReadOnlyList<MYGPresupuestoDocumento> presupuestos, string id, string prefijo)
    {
        var usados = new HashSet<string>((presupuestos ?? Array.Empty<MYGPresupuestoDocumento>())
            .SelectMany(p => p.Costos.PiePersonalizado ?? new()).Where(f => f.Id != id).Select(f => f.Identificador ?? ""), StringComparer.OrdinalIgnoreCase);
        string candidato = prefijo; int numero = 1;
        while (usados.Contains(candidato)) candidato = prefijo + numero++;
        return candidato;
    }

    private void PrepararPredeterminada(MYGFilaPiePersonalizada fila, bool varios)
    {
        Text = "MYG | Editar fila del resumen"; ClientSize = new(490, 240);
        var tabla = new TableLayoutPanel { Dock = DockStyle.Top, Height = 95, ColumnCount = 2, Padding = new(12) };
        tabla.ColumnStyles.Add(new(SizeType.Absolute, 120)); tabla.ColumnStyles.Add(new(SizeType.Percent, 100));
        var porcentaje = new NumericUpDown { Dock = DockStyle.Fill, Minimum = 0, Maximum = 10000, DecimalPlaces = 4,
            Value = Math.Clamp(fila.Porcentaje, 0, 10000), ThousandsSeparator = true };
        tabla.Controls.Add(new Label { Text = "Concepto", AutoSize = true }, 0, 0);
        tabla.Controls.Add(new TextBox { Text = fila.Nombre, ReadOnly = true, Dock = DockStyle.Fill }, 1, 0);
        tabla.Controls.Add(new Label { Text = "Porcentaje (%)", AutoSize = true }, 0, 1); tabla.Controls.Add(porcentaje, 1, 1);
        var nota = new Label { Dock = DockStyle.Fill, Padding = new(12), Text = (varios ? "Hay porcentajes distintos. Aplicar usará el valor indicado en todo el alcance.\n" : "") +
            "Gastos generales y utilidad usan el costo directo. Los impuestos usan el parcial." };
        var botones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45, FlowDirection = FlowDirection.RightToLeft, Padding = new(5) };
        var cerrar = new Button { Text = "Cerrar", DialogResult = DialogResult.Cancel, AutoSize = true };
        var aceptar = new Button { Text = "Aplicar", AutoSize = true };
        aceptar.Click += (_, _) => { Valor = MYGProyectoStorage.Copia(fila); Valor.Porcentaje = porcentaje.Value; DialogResult = DialogResult.OK; };
        botones.Controls.Add(cerrar); botones.Controls.Add(aceptar);
        Controls.Add(nota); Controls.Add(tabla); Controls.Add(botones); AcceptButton = aceptar; CancelButton = cerrar;
        MYG2027_TemaComercial.Aplicar(this);
    }
}
