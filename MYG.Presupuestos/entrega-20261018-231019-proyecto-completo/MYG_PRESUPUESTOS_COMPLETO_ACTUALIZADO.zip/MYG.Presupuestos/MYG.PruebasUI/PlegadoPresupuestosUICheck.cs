using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class PlegadoPresupuestosUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Plegado sin recalcular");
        var primero = proyecto.Presupuestos.Single(); primero.Nombre = "PRIMER PRESUPUESTO";
        var segundo = MYGEstructuraPresupuestos.AgregarPresupuesto(proyecto); segundo.Nombre = "SEGUNDO PRESUPUESTO";
        var titulo = Nodo("TÍTULO PRINCIPAL", 1, titulo: true);
        var subtitulo = Nodo("TÍTULO ANIDADO", 1, titulo.Id, titulo: true);
        var partida = Nodo("PARTIDA ANIDADA", 1, subtitulo.Id);
        var otraRama = Nodo("OTRO TÍTULO", 2, titulo: true);
        var otraPartida = Nodo("OTRA PARTIDA", 1, otraRama.Id);
        var partidaSegundo = Nodo("PARTIDA DEL SEGUNDO PRESUPUESTO", 1);
        primero.Items.AddRange([titulo, subtitulo, partida, otraRama, otraPartida]);
        segundo.Items.Add(partidaSegundo);
        MYGProyectoStorage.Renumerar(primero); MYGProyectoStorage.Renumerar(segundo);
        MYGPresupuestoDocumento activo = primero;
        int ediciones = 0, guardados = 0;
        using var panel = new MYGPanelPresupuesto(() => activo, () => { }, () => { },
            _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
        panel.InicializarEstructura(() => proyecto, id =>
        {
            if (id != null) activo = proyecto.Presupuestos.Single(p => p.Id == id);
        }, _ => { }, (nodo, columna, texto) =>
        {
            if (columna != "CANT" || nodo is not ItemPresupuestoDelphin item ||
                !MYGFormatoPresupuesto.IntentarCantidad(texto, out decimal cantidad))
                throw new InvalidOperationException("Cantidad inválida.");
            item.Costos.Cantidad = cantidad; ediciones++;
        }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1700, 1000) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); Application.DoEvents();
        var tabla = Campo<DataGridView>(panel, "estructura");
        var sesiones = Campo<Dictionary<MYGPresupuestoDocumento, MYGCalculoPresupuesto>>(panel, "calculosEstructura");
        var sesionPrimera = sesiones[primero]; var sesionSegunda = sesiones[segundo];
        var filas = tabla.Rows.Cast<DataGridViewRow>().ToArray();
        var filaPartida = Fila(partida); var filaOtra = Fila(otraPartida);
        var diagnostico = panel.DiagnosticoAlertasPartida(otraPartida);
        string firma = MYGProyectoStorage.Firma(proyecto);
        Seleccionar(titulo);
        var listaContexto = Campo<DataGridView>(panel, "tablaInsumosContexto");
        var filasContexto = listaContexto.Rows.Cast<DataGridViewRow>().ToArray();
        var celda = tabla.CurrentCell;

        Alternar(otraRama);
        exige(filaOtra.DataGridView == null && ReferenceEquals(tabla.CurrentCell, celda) && activo == primero,
            "Plegar otra rama debe retirar sólo sus descendientes, conservando la selección y el presupuesto activo.");
        exige(listaContexto.Rows.Cast<DataGridViewRow>().SequenceEqual(filasContexto),
            "Plegar una rama debe conservar las filas del detalle de insumos de la selección vigente.");
        Alternar(otraRama);
        exige(tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas) && ReferenceEquals(Fila(otraPartida), filaOtra),
            "Reabrir una rama debe reutilizar las mismas filas y conservar el orden completo de la estructura.");
        exige(ReferenceEquals(panel.DiagnosticoAlertasPartida(otraPartida), diagnostico) &&
            sesiones[primero] == sesionPrimera && sesiones[segundo] == sesionSegunda &&
            MYGProyectoStorage.Firma(proyecto) == firma && ediciones == 0 && guardados == 0,
            "El plegado debe reutilizar cálculos y diagnósticos sin modificar el documento, editar ni guardar.");

        Alternar(subtitulo); Alternar(titulo); Alternar(titulo);
        exige(Fila(subtitulo).DataGridView == tabla && filaPartida.DataGridView == null,
            "Reabrir un título debe respetar el estado plegado de sus títulos anidados.");
        Alternar(subtitulo);
        exige(ReferenceEquals(Fila(partida), filaPartida),
            "Reabrir un título anidado debe recuperar la fila original de su partida.");

        // Una edición pendiente debe confirmarse antes de retirar su fila.
        Seleccionar(partida);
        tabla.CurrentCell = filaPartida.Cells["CANT"]; tabla.BeginEdit(true);
        ((DataGridViewTextBoxEditingControl)tabla.EditingControl).Text = "6.50";
        Alternar(titulo); Application.DoEvents();
        exige(ediciones == 1 && partida.Costos.Cantidad == 6.5m && filaPartida.DataGridView == null &&
            ReferenceEquals(panel.SeleccionEstructura, titulo) && activo == primero,
            "Plegar el antecesor debe confirmar la cantidad pendiente y seleccionar el antecesor visible del mismo presupuesto.");
        Alternar(titulo);
        exige(ReferenceEquals(Fila(partida), filaPartida) && Convert.ToDecimal(filaPartida.Cells["TOTAL"].Value) == 26m,
            "Las filas plegadas deben recibir los cálculos posteriores a una edición y mostrar el importe actualizado al reabrirse.");

        Seleccionar(partida);
        tabla.CurrentCell = filaPartida.Cells["CANT"]; tabla.BeginEdit(true);
        ((DataGridViewTextBoxEditingControl)tabla.EditingControl).Text = "inválida";
        bool rechazada = false;
        try { Invocar(panel, "AlternarNodo", titulo); }
        catch (InvalidOperationException) { rechazada = true; }
        exige(rechazada && tabla.IsCurrentCellInEditMode && filaPartida.DataGridView == tabla && ediciones == 1,
            "Una cantidad inválida debe impedir el plegado y conservar la celda para su corrección.");
        tabla.CancelEdit(); Application.DoEvents();

        // Seleccionar otro presupuesto conserva las sesiones, pero debe
        // actualizar el pie y marcar la lista de costos de ese presupuesto.
        Campo<ComboBox>(panel, "alcancePie").SelectedIndex = 0;
        typeof(MYGPanelPresupuesto).GetField("listaCostosPendiente", Privados).SetValue(panel, false);
        Seleccionar(partidaSegundo);
        exige(activo == segundo && Campo<Label>(panel, "tituloPie").Text.Contains(segundo.Nombre, StringComparison.Ordinal) &&
            Campo<bool>(panel, "listaCostosPendiente"),
            "Cambiar de presupuesto mediante selección debe actualizar su resumen y su lista de costos.");
        var sesionTrasEditar = sesiones[primero];
        Invocar(panel, "PlegarTodaEstructura", true); Application.DoEvents();
        exige(tabla.Rows.Count == 2 && tabla.Rows.Cast<DataGridViewRow>().All(r => r.Tag is MYGPresupuestoDocumento) &&
            ReferenceEquals(panel.SeleccionEstructura, segundo) && activo == segundo,
            "Contraer todo debe mostrar los presupuestos y mantener activo el presupuesto de la selección anterior.");
        Invocar(panel, "PlegarTodaEstructura", false); Application.DoEvents();
        exige(tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas) && sesiones[primero] == sesionTrasEditar &&
            ediciones == 1 && guardados == 0,
            "Expandir todo debe reutilizar todas las filas y los cálculos vigentes sin crear otra edición.");
        formulario.Close();

        DataGridViewRow Fila(object nodo) => tabla.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, nodo));
        void Seleccionar(object nodo) { tabla.CurrentCell = Fila(nodo).Cells["DESC"]; Application.DoEvents(); }
        void Alternar(object nodo) { Invocar(panel, "AlternarNodo", nodo); Application.DoEvents(); }
    }

    private static ItemPresupuestoDelphin Nodo(string descripcion, int posicion, string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, ParentId = padre,
            Descripcion = descripcion, Posicion = posicion, Unidad = titulo ? "" : "und",
            TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida { Cantidad = 3m, PrecioDirecto = 4m }
        };
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
