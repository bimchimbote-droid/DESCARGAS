using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesOscuroScrollCheck
{
    private const int WmMouseWheel = 0x020A, WmVScroll = 0x0115;
    private const int EmGetScrollPos = 0x04DD, EmSetScrollPos = 0x04DE;
    private const uint SmtoAbortIfHung = 0x0002;

    [DllImport("user32.dll", EntryPoint = "SendMessageTimeoutW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, uint mensaje, IntPtr wParam,
        IntPtr lParam, uint flags, uint timeout, out UIntPtr resultado);
    [DllImport("user32.dll", EntryPoint = "SendMessageTimeoutW")]
    private static extern IntPtr EnviarPunto(IntPtr ventana, uint mensaje, IntPtr wParam,
        ref Point punto, uint flags, uint timeout, out UIntPtr resultado);
    [DllImport("user32.dll", EntryPoint = "PeekMessageW")]
    private static extern bool LeerMensaje(out Mensaje mensaje, IntPtr ventana, uint minimo, uint maximo, uint quitar);
    [DllImport("user32.dll")]
    private static extern bool TranslateMessage(ref Mensaje mensaje);
    [DllImport("user32.dll", EntryPoint = "DispatchMessageW")]
    private static extern IntPtr DispatchMessage(ref Mensaje mensaje);

    [StructLayout(LayoutKind.Sequential)]
    private struct Mensaje
    {
        internal IntPtr Ventana;
        internal uint Numero;
        internal IntPtr WParam, LParam;
        internal uint Tiempo;
        internal Point Posicion;
        internal uint Privado;
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        if (!OperatingSystem.IsWindows() || SystemInformation.HighContrast) return;
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            // Abrir directamente en oscuro debe funcionar sin recibir CambioTema.
            if (!MYG2027_TemaComercial.Oscuro) MYG2027_TemaComercial.Alternar(false);
            int antes = 0, cambios = 0;
            using var documento = new RichTextBox { Font = new Font("Arial", 16), DetectUrls = false };
            using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
                () => "PARTIDA DE PRUEBA", () => "und", () => "01.02", () => "PRESUPUESTO DE PRUEBA");
            Rectangle pantalla = Screen.PrimaryScreen.WorkingArea;
            using var formulario = new Form
            {
                Text = "Prueba de hoja oscura y desplazamiento",
                StartPosition = FormStartPosition.Manual,
                Location = new Point(pantalla.Left + 10, pantalla.Top + 10),
                ClientSize = new Size(Math.Min(980, pantalla.Width - 40), Math.Min(760, pantalla.Height - 80))
            };
            MYG2027_TemaComercial.Aplicar(formulario);
            formulario.Controls.Add(editor);
            formulario.Show();
            editor.Cargar("oscuro-scroll", CrearRtf(), "");
            var controles = Descendientes(editor).ToArray();
            var lienzo = (Panel)controles.Single(x => x.Name == "espec_lienzo");
            var zoom = controles.OfType<NumericUpDown>().Single(x => x.Name == "espec_zoom");
            zoom.Value = 100;
            ProcesarMensajes();
            documento.ClearUndo();
            string textoSinEdicion = documento.Text;
            documento.Select(documento.TextLength, 0);
            documento.Focus();
            int antesEdicion = antes, cambiosEdicion = cambios;
            editor.AplicarFormato(() => documento.SelectedText = "\nEdicion recuperable para comprobar Deshacer.");
            documento.Select(8, 4);
            lienzo.AutoScrollPosition = Point.Empty;
            EstablecerScrollNativo(documento, Point.Empty);
            ProcesarMensajes();
            exige(documento.CanUndo && antes == antesEdicion + 1 && cambios == cambiosEdicion + 1,
                "La prueba de scroll oscuro debe comenzar con una sola edición recuperable y callbacks controlados.");
            var estado = new Estado(editor, documento, antes, cambios);

            Comprobar("apertura directamente en oscuro");
            Rueda(lienzo, -360);
            exige(lienzo.AutoScrollPosition.Y < 0,
                "La rueda real del lienzo debe desplazar la hoja para probar las zonas recién reveladas.");
            Comprobar("rueda hacia abajo sobre el lienzo");
            Rueda(lienzo, 360);
            exige(lienzo.AutoScrollPosition.Y == 0,
                "La rueda inversa debe revelar de nuevo el inicio de la hoja.");
            Comprobar("rueda hacia arriba sobre el lienzo");

            zoom.Value = 150;
            ProcesarMensajes();
            Point origenTexto = lienzo.PointToClient(documento.PointToScreen(Point.Empty));
            int recorteX = origenTexto.X + 80, recorteY = origenTexto.Y + 100;
            lienzo.AutoScrollPosition = new Point(recorteX, recorteY);
            ProcesarMensajes();
            exige(lienzo.AutoScrollPosition.X < 0 && lienzo.AutoScrollPosition.Y < 0 &&
                documento.RectangleToScreen(documento.ClientRectangle).Left <
                    lienzo.RectangleToScreen(lienzo.ClientRectangle).Left &&
                documento.RectangleToScreen(documento.ClientRectangle).Top <
                    lienzo.RectangleToScreen(lienzo.ClientRectangle).Top,
                "La prueba debe recortar realmente el texto por arriba y por la izquierda.");
            Comprobar("hoja recortada al desplazar ambos ejes");
            lienzo.AutoScrollPosition = new Point(0, recorteY);
            ProcesarMensajes();
            Comprobar("margen izquierdo recién revelado");
            lienzo.AutoScrollPosition = new Point(int.MaxValue / 2, int.MaxValue / 2);
            ProcesarMensajes();
            Comprobar("extremo inferior y margen derecho de la hoja");
            lienzo.AutoScrollPosition = Point.Empty;
            ProcesarMensajes();
            Comprobar("inicio restaurado tras desplazar ambos ejes");

            // RichEdit desplaza su propio contenido además del desplazamiento
            // del papel. Una hoja larga garantiza que ambas rutas se ejerciten.
            zoom.Value = 100;
            lienzo.AutoScrollPosition = Point.Empty;
            EstablecerScrollNativo(documento, Point.Empty);
            ProcesarMensajes();
            Point scrollInicial = LeerScrollNativo(documento);
            using var muestraInicial = Capturar(Visible(documento));
            string huellaInicial = Huella(muestraInicial);
            Enviar(documento, WmVScroll, new IntPtr(3), IntPtr.Zero); // SB_PAGEDOWN
            ProcesarMensajes();
            exige(LeerScrollNativo(documento).Y > scrollInicial.Y,
                "WM_VSCROLL debe mover contenido nativo de RichEdit, no sólo la hoja exterior.");
            exige(documento.GetCharIndexFromPosition(Point.Empty) > 0,
                "El scroll nativo debe revelar líneas posteriores del documento de prueba.");
            Comprobar("desplazamiento nativo WM_VSCROLL");
            using (var muestraDesplazada = Capturar(Visible(documento)))
                exige(Huella(muestraDesplazada) != huellaInicial,
                    "El scroll nativo debe pintar el texto recién visible, sin reutilizar una captura anterior.");

            EstablecerScrollNativo(documento, new Point(0, 310));
            ProcesarMensajes();
            exige(LeerScrollNativo(documento).Y > 0,
                "EM_SETSCROLLPOS debe mantener un desplazamiento real para comprobar su repintado.");
            Comprobar("desplazamiento nativo EM_SETSCROLLPOS");
            Enviar(documento, WmVScroll, new IntPtr(6), IntPtr.Zero); // SB_TOP
            ProcesarMensajes();
            exige(LeerScrollNativo(documento).Y == 0, "SB_TOP debe devolver el contenido nativo al inicio.");
            Comprobar("inicio restaurado tras scroll nativo");

            Rectangle visibleAntesSuspension = Visible(documento);
            using (new MYGEspecificacionesRepintado(documento))
            {
                Enviar(documento, 0x000F, IntPtr.Zero, IntPtr.Zero); // WM_PAINT durante WM_SETREDRAW=FALSE.
                ProcesarMensajes(15);
                using var muestraSuspendida = Capturar(visibleAntesSuspension);
                var pixels = Contar(muestraSuspendida, documento.BackColor.ToArgb());
                exige(pixels.Fondo > pixels.Total * .55 && pixels.Claros > 100 && pixels.Blancos < pixels.Total * .01,
                    "Suspender el repintado durante el zoom debe conservar el cuadro oscuro sin pintar blanco.");
            }
            ProcesarMensajes();
            Comprobar("repintado nativo reanudado tras suspensión");

            Rueda(documento, 120, control: true);
            var plazoZoom = Stopwatch.StartNew();
            while (editor.ZoomEnCurso && plazoZoom.Elapsed.TotalSeconds < 2) ProcesarMensajes(10);
            exige(!editor.ZoomEnCurso && documento.ZoomFactor > 1,
                "El zoom animado debe terminar dentro del plazo conservando la hoja oscura.");
            Comprobar("zoom animado con Ctrl y rueda");
            zoom.Value = 150;
            lienzo.AutoScrollPosition = new Point(recorteX, recorteY);
            ProcesarMensajes();
            foreach (bool oscuro in new[] { false, true, false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                ProcesarMensajes();
                Comprobar(oscuro ? "vuelta a oscuro con la hoja recortada" : "vuelta a normal con la hoja recortada");
            }
            lienzo.AutoScrollPosition = Point.Empty;
            zoom.Value = 100;
            ProcesarMensajes();
            Comprobar("restauración final de la hoja oscura");
            documento.Undo();
            ProcesarMensajes();
            exige(documento.Text == textoSinEdicion,
                "Deshacer debe recuperar la edición original tras scroll, zoom y cambios de tema.");
            formulario.Close();

            void Comprobar(string paso)
            {
                VerificarVista(editor, controles, MYG2027_TemaComercial.Oscuro, paso, exige);
                estado.Verificar(editor, documento, antes, cambios, paso, exige);
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static string CrearRtf()
    {
        var rtf = new StringBuilder(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}{\colortbl;\red0\green0\blue0;\red0\green100\blue0;\red0\green0\blue180;}\f0\fs32\cf1 ");
        for (int i = 0; i < 90; i++)
        {
            rtf.Append("Linea ").Append(i.ToString("000")).Append(": ")
                .Append(new string((char)('A' + i % 26), 3 + i % 17))
                .Append(@" negro \cf2 verde oscuro \cf3 azul.\cf1\par ");
        }
        return rtf.Append('}').ToString();
    }

    private static void VerificarVista(MYGEspecificacionesEditor editor, Control[] controles,
        bool oscuro, string paso, Action<bool, string> exige)
    {
        var documento = editor.Documento;
        Control papel = controles.Single(x => x.Name == "espec_papel");
        Control lienzo = controles.Single(x => x.Name == "espec_lienzo");
        Control cabecera = controles.Single(x => x.Name == "espec_cabecera");
        int fondo = oscuro ? Color.FromArgb(unchecked((int)0xff303640)).ToArgb() : Color.White.ToArgb();
        exige(documento.BackColor.ToArgb() == fondo && papel.BackColor.ToArgb() == fondo,
            $"Texto y todos los márgenes de papel deben compartir el fondo del tema ({paso}).");
        if (oscuro)
        {
            exige(new[] { "espec_cabecera", "espec_lienzo", "espec_barra_titulo", "espec_regla_horizontal", "espec_regla_vertical" }
                .All(nombre => controles.Single(x => x.Name == nombre).BackColor.GetBrightness() < .3f),
                $"Cabecera, fondo, reglas y barra inferior deben permanecer oscuros ({paso}).");
            exige(Descendientes(cabecera).OfType<Label>().All(x => x.ForeColor.GetBrightness() > .7f),
                $"Todas las etiquetas de la cabecera necesitan texto claro ({paso}).");
        }

        Rectangle textoVisible = Visible(documento);
        exige(textoVisible.Width > 120 && textoVisible.Height > 60,
            $"La prueba requiere texto visible después del recorte ({paso}).");
        using (var muestra = Capturar(textoVisible))
        {
            var pixels = Contar(muestra, fondo);
            exige(pixels.Fondo > pixels.Total * .55 && (oscuro ? pixels.Claros : pixels.Oscuros) > 100,
                $"El dibujo real necesita papel uniforme y letras contrastadas, incluso tras scroll ({paso}).");
            if (oscuro)
                exige(pixels.Blancos < pixels.Total * .01,
                    $"El área del documento no debe revelar bandas ni cuadros blancos al desplazarse ({paso}).");
        }

        // Muestrear una línea en su posición nativa también comprueba texto
        // posterior al principio cuando el papel o RichEdit están desplazados.
        Rectangle textoCliente = documento.RectangleToClient(textoVisible);
        int primeraLinea = documento.GetLineFromCharIndex(documento.GetCharIndexFromPosition(textoCliente.Location));
        int ultimaLinea = documento.GetLineFromCharIndex(documento.TextLength);
        int altoLinea = Math.Max(12, (int)Math.Ceiling(documento.Font.Height * documento.ZoomFactor));
        Rectangle lineaVisible = Rectangle.Empty;
        for (int linea = primeraLinea; linea <= ultimaLinea; linea++)
        {
            int indice = documento.GetFirstCharIndexFromLine(linea);
            if (indice < 0) break;
            Point posicion = documento.GetPositionFromCharIndex(indice);
            if (posicion.Y < textoCliente.Top) continue;
            if (posicion.Y + altoLinea > textoCliente.Bottom) break;
            lineaVisible = new Rectangle(textoVisible.Left, documento.PointToScreen(posicion).Y,
                Math.Min(350, textoVisible.Width), altoLinea);
            break;
        }
        exige(!lineaVisible.IsEmpty, $"Debe existir una línea posterior completamente visible para muestrear ({paso}).");
        using (var muestraLinea = Capturar(lineaVisible))
        {
            var pixels = Contar(muestraLinea, fondo);
            exige((oscuro ? pixels.Claros : pixels.Oscuros) > 30,
                $"La línea visible en su posición nativa debe tener letras legibles ({paso}).");
        }

        // Los márgenes son controles distintos; comprobar sólo RichEdit deja
        // sin detectar hojas parcialmente blancas alrededor del texto.
        Rectangle hojaVisible = Visible(papel);
        Rectangle rectanguloTexto = documento.RectangleToScreen(documento.ClientRectangle);
        foreach (Rectangle margen in Restar(hojaVisible, rectanguloTexto))
            VerificarFondo(margen, oscuro, paso + ": margen de papel", exige);
        foreach (Rectangle exterior in Restar(Visible(lienzo), papel.RectangleToScreen(papel.ClientRectangle)))
            VerificarFondo(exterior, oscuro, paso + ": exterior del papel", exige);

        // La zona inferior de la cabecera no contiene iconos ni etiquetas.
        Rectangle encabezado = cabecera.RectangleToScreen(cabecera.ClientRectangle);
        VerificarFondo(new Rectangle(encabezado.Left + 4, encabezado.Bottom - 14, encabezado.Width - 8, 10),
            oscuro, paso + ": cabecera", exige);
        Control titulo = controles.Single(x => x.Name == "espec_cabecera_titulo");
        using var muestraTitulo = Capturar(Visible(titulo));
        var pixelsTitulo = Contar(muestraTitulo, fondo);
        exige((oscuro ? pixelsTitulo.Claros : pixelsTitulo.Oscuros) > 50,
            $"El título de la cabecera debe dibujarse con contraste real ({paso}).");
    }

    private static void VerificarFondo(Rectangle region, bool oscuro, string paso, Action<bool, string> exige)
    {
        region.Inflate(-3, -3);
        if (region.Width < 4 || region.Height < 4) return;
        using var muestra = Capturar(region);
        var pixels = Contar(muestra, 0);
        exige((oscuro ? pixels.Oscuros : pixels.Claros) > pixels.Total * .95,
            $"La superficie completa debe seguir el tema en la captura de pantalla ({paso}).");
    }

    private static Rectangle Visible(Control control)
    {
        Rectangle visible = control.RectangleToScreen(control.ClientRectangle);
        for (Control padre = control.Parent; padre != null; padre = padre.Parent)
            visible.Intersect(padre.RectangleToScreen(padre.ClientRectangle));
        visible.Intersect(Screen.FromControl(control).Bounds);
        return visible;
    }

    private static IEnumerable<Rectangle> Restar(Rectangle exterior, Rectangle interior)
    {
        Rectangle interseccion = Rectangle.Intersect(exterior, interior);
        if (interseccion.Width <= 0 || interseccion.Height <= 0) { yield return exterior; yield break; }
        yield return Rectangle.FromLTRB(exterior.Left, exterior.Top, exterior.Right, interseccion.Top);
        yield return Rectangle.FromLTRB(exterior.Left, interseccion.Bottom, exterior.Right, exterior.Bottom);
        yield return Rectangle.FromLTRB(exterior.Left, interseccion.Top, interseccion.Left, interseccion.Bottom);
        yield return Rectangle.FromLTRB(interseccion.Right, interseccion.Top, exterior.Right, interseccion.Bottom);
    }

    private static Bitmap Capturar(Rectangle region)
    {
        if (region.Width <= 0 || region.Height <= 0)
            throw new InvalidOperationException("La captura de la hoja exige una región visible en pantalla.");
        var muestra = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppRgb);
        using var grafico = Graphics.FromImage(muestra);
        // DrawToBitmap/WM_PRINTCLIENT conserva los colores de impresión y no
        // representa lo que ve el usuario en modo oscuro.
        grafico.CopyFromScreen(region.Location, Point.Empty, muestra.Size);
        return muestra;
    }

    private static (int Total, int Fondo, int Claros, int Oscuros, int Blancos) Contar(Bitmap imagen, int esperado)
    {
        byte[] datos = Pixeles(imagen);
        int fondo = 0, claros = 0, oscuros = 0, blancos = 0;
        for (int i = 0; i < datos.Length; i += 4)
        {
            int r = datos[i + 2], g = datos[i + 1], b = datos[i];
            int brillo = Math.Max(r, Math.Max(g, b)) + Math.Min(r, Math.Min(g, b));
            if (unchecked((int)0xff000000) + (r << 16) + (g << 8) + b == esperado) fondo++;
            if (brillo > 331) claros++; // GetBrightness() > .65
            if (brillo < 179) oscuros++; // GetBrightness() < .35
            if (r >= 250 && g >= 250 && b >= 250) blancos++;
        }
        return (datos.Length / 4, fondo, claros, oscuros, blancos);
    }

    private static byte[] Pixeles(Bitmap imagen)
    {
        var bloqueo = imagen.LockBits(new Rectangle(Point.Empty, imagen.Size), ImageLockMode.ReadOnly, PixelFormat.Format32bppRgb);
        try
        {
            var datos = new byte[checked(imagen.Width * imagen.Height * 4)];
            for (int y = 0; y < imagen.Height; y++)
                Marshal.Copy(IntPtr.Add(bloqueo.Scan0, y * bloqueo.Stride), datos, y * imagen.Width * 4, imagen.Width * 4);
            // El byte sin usar de RGB32 no forma parte del color ni de la huella.
            for (int i = 3; i < datos.Length; i += 4) datos[i] = 0;
            return datos;
        }
        finally { imagen.UnlockBits(bloqueo); }
    }

    private static string Huella(Bitmap imagen) => Convert.ToHexString(SHA256.HashData(Pixeles(imagen)));

    private static void Rueda(Control destino, int delta, bool control = false)
    {
        Point punto = destino.PointToScreen(new Point(10, 10));
        Enviar(destino, WmMouseWheel, new IntPtr(unchecked((delta << 16) | (control ? 8 : 0))),
            new IntPtr(unchecked((punto.Y << 16) | (punto.X & 0xffff))));
        ProcesarMensajes();
    }

    private static void Enviar(Control destino, uint mensaje, IntPtr wParam, IntPtr lParam)
    {
        if (EnviarMensaje(destino.Handle, mensaje, wParam, lParam, SmtoAbortIfHung, 2000, out _) == IntPtr.Zero)
            throw new InvalidOperationException($"El mensaje nativo 0x{mensaje:X} no terminó dentro del plazo.");
    }

    private static Point LeerScrollNativo(RichTextBox documento)
    {
        Point scroll = Point.Empty;
        EnviarScroll(documento, EmGetScrollPos, ref scroll);
        return scroll;
    }

    private static void EstablecerScrollNativo(RichTextBox documento, Point scroll) => EnviarScroll(documento, EmSetScrollPos, ref scroll);

    private static void EnviarScroll(RichTextBox documento, uint mensaje, ref Point scroll)
    {
        if (EnviarPunto(documento.Handle, mensaje, IntPtr.Zero, ref scroll, SmtoAbortIfHung, 2000, out _) == IntPtr.Zero)
            throw new InvalidOperationException($"El scroll nativo 0x{mensaje:X} no terminó dentro del plazo.");
    }

    private static void ProcesarMensajes(int milisegundos = 70)
    {
        var plazo = Stopwatch.StartNew();
        int procesados = 0;
        while (plazo.ElapsedMilliseconds < milisegundos)
        {
            if (!LeerMensaje(out var mensaje, IntPtr.Zero, 0, 0, 1)) { Thread.Sleep(1); continue; }
            if (mensaje.Numero == 0x0012) throw new InvalidOperationException("La ventana de prueba recibió WM_QUIT inesperadamente.");
            if (++procesados > 4096) throw new InvalidOperationException("La hoja generó un bucle de repintado durante el scroll.");
            TranslateMessage(ref mensaje);
            DispatchMessage(ref mensaje);
        }
    }

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }

    private sealed class Estado
    {
        private readonly string rtf, salida;
        private readonly int seleccion, longitud, antes, cambios;
        private readonly bool undo;

        internal Estado(MYGEspecificacionesEditor editor, RichTextBox documento, int antes, int cambios)
        {
            rtf = editor.DocumentoRtf; salida = editor.RtfParaArchivo;
            seleccion = documento.SelectionStart; longitud = documento.SelectionLength;
            undo = documento.CanUndo; this.antes = antes; this.cambios = cambios;
        }

        internal void Verificar(MYGEspecificacionesEditor editor, RichTextBox documento, int antes, int cambios,
            string paso, Action<bool, string> exige) =>
            exige(editor.DocumentoRtf == rtf && editor.RtfParaArchivo == salida && documento.CanUndo == undo &&
                documento.SelectionStart == seleccion && documento.SelectionLength == longitud &&
                antes == this.antes && cambios == this.cambios,
                $"Scroll, zoom y tema deben conservar RTF, exportación, selección, Deshacer y callbacks ({paso}).");
    }
}
