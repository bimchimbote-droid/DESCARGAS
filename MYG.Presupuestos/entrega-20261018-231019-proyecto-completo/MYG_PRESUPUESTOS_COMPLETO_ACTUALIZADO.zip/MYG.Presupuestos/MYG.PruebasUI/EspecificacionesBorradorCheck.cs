using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesBorradorCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Proyecto de prueba", "PRESUPUESTO");
        var presupuesto = proyecto.Presupuestos.Single();
        var primera = NuevaPartida("CONCRETO SIMPLE", "m³", 1);
        var existente = NuevaPartida("PARTIDA EXISTENTE", "m²", 2);
        existente.Costos.EspecificacionTexto = "Especificación anterior conservada.";
        var sinEditar = NuevaPartida("PARTIDA NUEVA", "und", 3);
        presupuesto.Items.AddRange(new[] { primera, existente, sinEditar });
        int cambios = 0, guardados = 0;
        string identidadGuardada = null;
        bool confirmadaAntesDeGuardarProyecto = true;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => { }, () => cambios++,
            _ => { }, () => Task.CompletedTask, _ => { }, () =>
            {
                guardados++;
                confirmadaAntesDeGuardarProyecto &= MYGContenidoPartida.TieneEspecificacionGuardada(
                    presupuesto.Items.Single(i => i.Id == identidadGuardada).Costos);
            });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (nodo, columna, valor) =>
        {
            var partida = presupuesto.Items.Single(i => i.Id == ((ItemPresupuestoDelphin)nodo).Id);
            if (columna == "DESC") partida.Descripcion = valor;
            else if (columna == "UND") partida.Unidad = valor;
            else if (columna == "ITEM") partida.Item = valor;
        }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1400, 840) };
        formulario.Controls.Add(panel);
        formulario.Show(); panel.Refrescar();
        panel.SeleccionarEstructura(primera); panel.MostrarEspecificacion(); Application.DoEvents();
        var editor = Controles(panel).OfType<MYGEspecificacionesEditor>().Single();
        var documento = editor.Documento;
        exige(documento.Text == "01.01  CONCRETO SIMPLE   (unidad de medida: m³)\n\nDESCRIPCIÓN:\n\n",
            "Una partida sin especificación debe presentar automáticamente ítem, nombre, unidad y DESCRIPCIÓN como Insertar título.");
        exige(cambios == 0 && string.IsNullOrEmpty(primera.Costos.EspecificacionRtf) &&
            string.IsNullOrEmpty(primera.Costos.EspecificacionTexto) &&
            !MYGContenidoPartida.TieneEspecificacionGuardada(primera.Costos),
            "El título inicial debe permanecer en la vista, sin modificar el modelo ni activar la especificación.");
        VerificarFormatoTitulo(documento, exige);
        exige(!documento.CanUndo,
            "El encabezado inicial no debe aparecer como una edición pendiente de Deshacer.");

        primera.Descripcion = "CONCRETO ACTUALIZADO";
        primera.Unidad = "m2";
        panel.Refrescar(); Application.DoEvents();
        exige(documento.Text.StartsWith("01.01  CONCRETO ACTUALIZADO   (unidad de medida: m2)", StringComparison.Ordinal) &&
            cambios == 0 && string.IsNullOrEmpty(primera.Costos.EspecificacionTexto),
            "El encabezado provisional debe actualizar nombre y unidad sin guardar una especificación.");

        documento.Select(documento.TextLength, 0);
        editor.AplicarFormato(() => documento.SelectedText = "Contenido técnico todavía sin guardar.");
        string textoBorrador = documento.Text, rtfBorrador = editor.DocumentoRtf;
        exige(primera.Costos.EspecificacionEsBorrador && primera.Costos.EspecificacionTexto == textoBorrador &&
            primera.Costos.EspecificacionRtf == rtfBorrador && !MYGContenidoPartida.TieneEspecificacionGuardada(primera.Costos),
            "Editar una especificación nueva debe conservar el borrador con formato y mantener el indicador desactivado.");

        panel.SeleccionarEstructura(existente); Application.DoEvents();
        exige(documento.Text == "Especificación anterior conservada." &&
            MYGContenidoPartida.TieneEspecificacionGuardada(existente.Costos),
            "Una especificación de versiones anteriores debe conservar su contenido y su estado guardado.");
        panel.SeleccionarEstructura(primera); Application.DoEvents();
        exige(documento.Text == textoBorrador && editor.DocumentoRtf == rtfBorrador && primera.Costos.EspecificacionEsBorrador,
            "Cambiar de partida y volver debe conservar el borrador sin confirmarlo.");

        presupuesto = MYGProyectoStorage.Copia(presupuesto);
        proyecto.Presupuestos[0] = presupuesto;
        primera = presupuesto.Items.Single(i => i.Id == primera.Id);
        sinEditar = presupuesto.Items.Single(i => i.Id == sinEditar.Id);
        panel.Refrescar(); Application.DoEvents();
        exige(primera.Costos.EspecificacionEsBorrador && documento.Text == textoBorrador &&
            !MYGContenidoPartida.TieneEspecificacionGuardada(primera.Costos),
            "Serializar y restaurar el modelo debe conservar el borrador y mantener desactivado el indicador.");

        identidadGuardada = primera.Id;
        PulsarGuardar(editor); Application.DoEvents();
        exige(!primera.Costos.EspecificacionEsBorrador && MYGContenidoPartida.TieneEspecificacionGuardada(primera.Costos) &&
            primera.Costos.EspecificacionTexto == textoBorrador && primera.Costos.EspecificacionRtf == rtfBorrador &&
            guardados == 1 && confirmadaAntesDeGuardarProyecto,
            "Guardar debe confirmar el borrador y su formato antes de solicitar el guardado del proyecto.");

        panel.SeleccionarEstructura(sinEditar); Application.DoEvents();
        exige(string.IsNullOrEmpty(sinEditar.Costos.EspecificacionTexto) &&
            !MYGContenidoPartida.TieneEspecificacionGuardada(sinEditar.Costos),
            "Otra partida nueva debe seguir sin especificación guardada aunque se haya guardado la primera.");
        var estructura = Controles(panel).OfType<DataGridView>().Single(c => c.Columns.Contains("EXP") && c.Columns.Contains("ITEM"));
        var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is ItemPresupuestoDelphin i && i.Id == sinEditar.Id);
        estructura.CurrentCell = fila.Cells["DESC"];
        exige(estructura.BeginEdit(true) && estructura.EditingControl is TextBox,
            "La prueba de Guardar debe permitir un nombre pendiente en la celda de la partida nueva.");
        ((TextBox)estructura.EditingControl).Text = "TÍTULO CONFIRMADO AL GUARDAR";
        identidadGuardada = sinEditar.Id;
        PulsarGuardar(editor); Application.DoEvents();
        exige(!estructura.IsCurrentCellInEditMode && sinEditar.Descripcion == "TÍTULO CONFIRMADO AL GUARDAR" &&
            sinEditar.Costos.EspecificacionTexto.Contains("TÍTULO CONFIRMADO AL GUARDAR", StringComparison.Ordinal) &&
            sinEditar.Costos.EspecificacionTexto.Contains("DESCRIPCIÓN:", StringComparison.Ordinal) &&
            MYGContenidoPartida.TieneEspecificacionGuardada(sinEditar.Costos) && guardados == 2 && confirmadaAntesDeGuardarProyecto,
            "Guardar sin editar el documento debe confirmar la celda pendiente y guardar el encabezado inicial actualizado.");

        string textoConfirmado = documento.Text;
        sinEditar.Descripcion = "NOMBRE POSTERIOR";
        panel.Refrescar(); Application.DoEvents();
        exige(documento.Text == textoConfirmado && sinEditar.Costos.EspecificacionTexto == textoConfirmado,
            "Después de Guardar, actualizar la partida debe conservar el documento confirmado sin reescribir su encabezado.");
    }

    private static ItemPresupuestoDelphin NuevaPartida(string descripcion, string unidad, int posicion) => new()
    {
        Item = posicion.ToString("00"), Descripcion = descripcion, Unidad = unidad,
        TipoPropuesta = "PARTIDA", Posicion = posicion
    };

    private static void VerificarFormatoTitulo(RichTextBox documento, Action<bool, string> exige)
    {
        documento.Select(0, "01.01  CONCRETO SIMPLE".Length);
        using (var fuente = documento.SelectionFont)
            exige(fuente?.Bold == true && Math.Abs(fuente.SizeInPoints - 11) < .1,
                "El ítem y nombre automáticos deben utilizar la negrita de Insertar título.");
        documento.Select(documento.Text.IndexOf("DESCRIPCIÓN:", StringComparison.Ordinal), "DESCRIPCIÓN:".Length);
        using (var fuente = documento.SelectionFont)
            exige(fuente?.Bold == true,
                "El subtítulo DESCRIPCIÓN inicial debe tener el mismo énfasis que Insertar título.");
        documento.Select(documento.TextLength, 0);
        using (var fuente = documento.SelectionFont)
            exige(fuente != null && !fuente.Bold && Math.Abs(fuente.SizeInPoints - 11) < .1,
                "El cuerpo de la especificación inicial debe permitir escribir con formato normal.");
    }

    private static void PulsarGuardar(Control editor)
    {
        var cinta = Controles(editor).OfType<TabControl>().Single(t => t.Name == "espec_cinta");
        cinta.SelectedTab = cinta.TabPages.Cast<TabPage>().Single(p => p.Text == "Fichero");
        Application.DoEvents();
        var boton = Controles(editor).OfType<ToolStrip>().SelectMany(t => t.Items.Cast<ToolStripItem>())
            .First(i => i.Name == "espec_Guardar");
        boton.PerformClick();
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
