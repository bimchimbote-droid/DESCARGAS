using System;
using System.Drawing;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class InformacionTareaUICheck
{
    private const string Prefijo = "cronograma_info_";

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Información de tarea UI");
        var presupuesto = documento.Presupuestos[0];
        var partida = new ItemPresupuestoDelphin { Id = "PARTIDA", IdLocalMYG = "PARTIDA", Item = "01",
            Descripcion = "Concreto de prueba", TipoPropuesta = "PARTIDA", Unidad = "m3" };
        partida.Costos.Cantidad = 17.5m; partida.Costos.PrecioDirecto = 3; presupuesto.Items.Add(partida);
        var lunes = new DateTime(2026, 10, 5);
        var plan = new MYGCronograma { FechaInicio = lunes, FechaEstado = lunes };
        var original = new MYGTareaCronograma { Id = "PRINCIPAL", Nombre = "Concreto de prueba", DuracionDias = 10,
            NumeroCuadrillas = 2, CuadrillasIniciales = 2, PresupuestoId = presupuesto.Id, PartidaId = partida.Id };
        plan.Tareas.Add(original);
        plan.Tareas.Add(new() { Id = "OTRA", Nombre = "Inspección", DuracionDias = 1 });
        string inicial = Huella(plan), originalInicial = Huella(original), presupuestoInicial = Huella(documento.Presupuestos);
        int aplicaciones = 0; bool permitido = true, copiasIndependientes = true;
        MYGInformacionTareaControl control = null;
        control = new MYGInformacionTareaControl(() => plan, () => documento, nueva =>
        {
            copiasIndependientes &= !ReferenceEquals(plan, nueva) && nueva.Tareas.All(t =>
                plan.Tareas.All(anterior => !ReferenceEquals(t, anterior)));
            plan = nueva; aplicaciones++;
            control.Cargar(original.Id);
        }, () => permitido);
        using (control)
        using (var ventana = new Form { ClientSize = new Size(1650, 620) })
        {
            control.Dock = DockStyle.Fill; ventana.Controls.Add(control);
            ventana.Show(); control.Cargar(original.Id); Application.DoEvents();
            var restriccion = Campo<ComboBox>(control, "restriccion");
            var fecha = Campo<DateTimePicker>(control, "fecha_restriccion");
            var nombre = Campo<TextBox>(control, "nombre");
            exige(restriccion.Items.Count == 8 && restriccion.SelectedIndex == 0 &&
                nombre.Text == original.Nombre && Campo<NumericUpDown>(control, "duracion").Value == 10 &&
                !control.TieneCambios && aplicaciones == 0 && Huella(plan) == inicial,
                "Información de tarea debe cargar nombre, duración y las ocho restricciones sin crear historial.");

            nombre.Text = "Borrador por descartar";
            Campo<TextBox>(control, "notas").Text = "Edición pendiente";
            control.Cargar(original.Id);
            exige(control.TieneCambios && nombre.Text == "Borrador por descartar" && aplicaciones == 0 && Huella(plan) == inicial,
                "Refrescar la misma selección debe conservar el borrador sin tocar el proyecto.");
            Boton(control, "cancelar").PerformClick(); Application.DoEvents();
            exige(!control.TieneCambios && nombre.Text == original.Nombre && aplicaciones == 0 && Huella(plan) == inicial,
                "Cancelar debe recuperar los datos guardados sin modificar la tarea ni el historial.");

            restriccion.SelectedIndex = (int)MYGTipoRestriccion.NoComenzarAntesDe;
            fecha.Value = lunes.AddDays(2);
            Campo<CheckBox>(control, "reprogramar").Checked = true;
            Campo<NumericUpDown>(control, "nueva_duracion").Value = 5;
            Campo<TextBox>(control, "responsables").Text = "ANA; LUIS";
            Campo<TextBox>(control, "notas").Text = "Verificado en información de tarea";
            control.GuardarCambios(); Application.DoEvents();
            var guardada = plan.Tareas.Single(t => t.Id == original.Id);
            exige(aplicaciones == 1 && copiasIndependientes && !control.TieneCambios &&
                guardada.TipoRestriccion == MYGTipoRestriccion.NoComenzarAntesDe && guardada.FechaRestriccion == lunes.AddDays(2) &&
                guardada.Reprogramada && guardada.DuracionInicialDias == 10 && guardada.DuracionDias == 5 &&
                guardada.NumeroCuadrillas == 4 && guardada.CuadrillasIniciales == 2 &&
                guardada.Responsables.Contains("ANA") && guardada.Responsables.Contains("LUIS") &&
                guardada.Notas == "Verificado en información de tarea" && Huella(original) == originalInicial,
                "Guardar debe aplicar una única copia con restricción, responsables y reprogramación proporcional, conservando el original.");
            control.GuardarCambios();
            exige(aplicaciones == 1, "Guardar sin cambios debe conservar el historial.");

            Campo<NumericUpDown>(control, "dividir_numero").Value = 3;
            Campo<NumericUpDown>(control, "dividir_intervalo").Value = 1;
            string antesDividir = Huella(plan);
            Boton(control, "dividir_aplicar").PerformClick(); Application.DoEvents();
            var partes = Campo<DataGridView>(control, "partes");
            exige(control.TieneCambios && partes.Rows.Count == 3 && aplicaciones == 1 && Huella(plan) == antesDividir,
                "Dividir debe mostrar tres partes editables en el borrador antes de confirmar la tarea.");
            control.GuardarCambios(); Application.DoEvents();
            guardada = plan.Tareas.Single(t => t.Id == original.Id);
            exige(aplicaciones == 2 && guardada.Partes.Count == 3 && guardada.Partes.Sum(p => p.DuracionDias) == 5 &&
                guardada.Partes.Sum(p => p.Cantidad) == 17.5m && guardada.Partes.Sum(p => p.Porcentaje) == 100 &&
                Huella(documento.Presupuestos) == presupuestoInicial,
                "Confirmar las partes debe preservar cinco jornadas, metrado y 100 % sin modificar el presupuesto.");

            string antesCancelarPartes = Huella(plan);
            Campo<NumericUpDown>(control, "dividir_numero").Value = 2;
            Boton(control, "dividir_aplicar").PerformClick();
            Boton(control, "cancelar").PerformClick(); Application.DoEvents();
            exige(partes.Rows.Count == 3 && !control.TieneCambios && aplicaciones == 2 && Huella(plan) == antesCancelarPartes,
                "Cancelar una nueva división debe restaurar las partes guardadas y conservar el historial.");

            partes.Rows[0].Cells["PORCENTAJE"].Value = 101m;
            bool rechazado = false;
            try { control.GuardarCambios(); } catch (InvalidDataException) { rechazado = true; }
            exige(rechazado && control.TieneCambios && aplicaciones == 2 && Huella(plan) == antesCancelarPartes,
                "Un porcentaje inválido debe rechazarse conservando el borrador para corregirlo y la tarea guardada sin cambios.");
            Boton(control, "cancelar").PerformClick();
            Boton(control, "dependencia_agregar").PerformClick();
            var dependencias = Campo<DataGridView>(control, "dependencias");
            exige(dependencias.Rows.Count == 1 && aplicaciones == 2,
                "Agregar una dependencia debe preparar una predecesora real sin modificar todavía la tarea.");
            dependencias.Rows[0].Cells["TIPO"].Value = "CC (Inicio - Inicio)";
            dependencias.Rows[0].Cells["DESFASE"].Value = -1;
            control.GuardarCambios(); Application.DoEvents();
            var dependencia = plan.Tareas.Single(t => t.Id == original.Id).Predecesoras.Single();
            exige(aplicaciones == 3 && dependencia.PredecesoraId == "OTRA" &&
                dependencia.Tipo == MYGTipoVinculo.CC && dependencia.DesfaseDias == -1,
                "Guardar dependencias debe resolver identidad estable, tipo y desfase negativo en una única modificación.");

            nombre.Text = "Nombre final";
            plan.Tareas.Single(t => t.Id == "OTRA").Notas = "Cambio externo que debe conservarse";
            control.GuardarCambios(); Application.DoEvents();
            exige(aplicaciones == 4 && plan.Tareas.Single(t => t.Id == original.Id).Nombre == "Nombre final" &&
                plan.Tareas.Single(t => t.Id == "OTRA").Notas == "Cambio externo que debe conservarse",
                "Guardar información debe aplicar la tarea editada sobre el plan actual y preservar cambios recientes de otras tareas.");

            permitido = false; control.Cargar(original.Id); Application.DoEvents();
            string soloLectura = Huella(plan);
            exige(!Boton(control, "guardar").Enabled && !Boton(control, "dividir_aplicar").Enabled &&
                !Boton(control, "dependencia_elegir").Enabled &&
                partes.ReadOnly && dependencias.ReadOnly && Huella(plan) == soloLectura && aplicaciones == 4,
                "La consulta sin permiso de edición debe deshabilitar guardar y dividir sin alterar el proyecto.");
            control.Cargar(null); Application.DoEvents();
            exige(!Boton(control, "guardar").Enabled && aplicaciones == 4,
                "Una selección vacía debe dejar el panel sin una tarea editable.");
        }
        IntegracionPanel(exige);
        DistribucionRecursos(exige);
        CuadrillasRecursos(exige);
        TramosNativos(exige);
    }

    private static void IntegracionPanel(Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Información integrada");
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 10, 5), FechaEstado = new DateTime(2026, 10, 5) };
        plan.Tareas.Add(new() { Id = "PRIMERA", Nombre = "Primera tarea", DuracionDias = 2 });
        plan.Tareas.Add(new() { Id = "SEGUNDA", Nombre = "Segunda tarea", DuracionDias = 3 });
        int aplicaciones = 0; string antes = Huella(plan);
        using var panel = new MYGPanelCronograma(() => plan, nueva => { plan = nueva; aplicaciones++; },
            () => true, () => { }, () => { }, () => { }, () => documento);
        using var ventana = new Form { ClientSize = new Size(1700, 900) };
        var cinta = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 80, WrapContents = false, AutoScroll = true };
        cinta.Controls.AddRange(panel.BotonesCinta.Cast<Control>().ToArray());
        ventana.Controls.Add(panel); ventana.Controls.Add(cinta); ventana.Show(); panel.Refrescar(); Application.DoEvents();
        var tabla = panel.Controls.Find("cronograma_tareas", true).OfType<DataGridView>().Single();
        DataGridViewRow Fila(string id) => tabla.Rows.Cast<DataGridViewRow>().Single(r => ((MYGResultadoTarea)r.Tag).Tarea.Id == id);
        tabla.CurrentCell = Fila("SEGUNDA").Cells["NOMBRE"];
        var informacion = panel.BotonesCinta.Single(b => b.Name == "cronograma_informacion");
        informacion.PerformClick(); Application.DoEvents();
        var detalle = panel.Controls.Find("cronograma_detalles_tarea", true).OfType<MYGCronogramaDetallesControl>().Single();
        var pestanas = detalle.Controls.Find("cronograma_detalle_pestanas", true).OfType<TabControl>().Single();
        exige(detalle.Visible && pestanas.SelectedTab.Name == "cronograma_detalle_informacion" &&
            Campo<TextBox>(detalle, "nombre").Text == "Segunda tarea" && aplicaciones == 0 && Huella(plan) == antes,
            "El botón Información de tarea debe abrir el panel integrado en la tarea seleccionada sin un diálogo ni historial.");
        exige(detalle.Controls.Find("cronograma_recursos_contenido", true).OfType<ComboBox>().Single().Items.Contains("Recurso x cuadrilla"),
            "Recursos programados debe ofrecer la consulta Recurso x cuadrilla junto a cantidad y valorizado.");
        tabla.CurrentCell = Fila("PRIMERA").Cells["NOMBRE"]; Application.DoEvents();
        exige(Campo<TextBox>(detalle, "nombre").Text == "Primera tarea" && detalle.TareaIdActual == "PRIMERA" &&
            !detalle.TieneCambios && aplicaciones == 0 && Huella(plan) == antes,
            "Cambiar la selección limpia debe actualizar el panel integrado y conservar el historial.");
        pestanas.SelectedTab = pestanas.TabPages.Cast<TabPage>().Single(p => p.Name == "cronograma_detalle_opciones");
        var tituloPagina = detalle.Controls.Find("cronograma_opciones_TituloPagina", true).OfType<TextBox>().Single();
        tituloPagina.Text = "Opción pendiente"; detalle.Cargar("PRIMERA");
        exige(detalle.TieneCambios && tituloPagina.Text == "Opción pendiente" && aplicaciones == 0 && Huella(plan) == antes,
            "Un refresco de la misma tarea debe conservar las opciones pendientes sin guardar historial.");
        detalle.Controls.Find("cronograma_opciones_descartar", true).OfType<Button>().Single().PerformClick();
        exige(!detalle.TieneCambios && tituloPagina.Text == "" && aplicaciones == 0 && Huella(plan) == antes,
            "Descartar opciones debe recuperar los valores aplicados sin modificar el proyecto.");
        string tareasAntes = Huella(plan.Tareas);
        tituloPagina.Text = "CONTROL INTEGRADO";
        var aplicarOpciones = detalle.Controls.Find("cronograma_opciones_aplicar", true).OfType<Button>().Single();
        aplicarOpciones.PerformClick(); Application.DoEvents(); aplicarOpciones.PerformClick();
        exige(aplicaciones == 1 && !detalle.TieneCambios && Huella(plan.Tareas) == tareasAntes &&
            plan.OpcionesVista["Presentacion"].Contains("CONTROL INTEGRADO", StringComparison.Ordinal),
            "Aplicar opciones debe guardar una sola copia y preservar toda la programación, incluso si vuelve a pulsarse Aplicar.");
        string conOpciones = Huella(plan);
        detalle.Controls.Find("cronograma_detalles_ocultar", true).OfType<Button>().Single().PerformClick(); Application.DoEvents();
        exige(!detalle.Visible && aplicaciones == 1 && Huella(plan) == conOpciones,
            "Ocultar Información sin cambios debe recuperar el espacio del cronograma sin modificar la planificación.");
    }

    private static void DistribucionRecursos(Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Distribución por partes UI"); var presupuesto = documento.Presupuestos[0];
        var recurso = new MYGInsumo { Id = "MATERIAL", Codigo = "01", Descripcion = "Material de prueba", Unidad = "m3",
            Grupo = MYGGrupoRecurso.Materiales, Precio = 10 };
        presupuesto.Costos.Insumos.Add(recurso);
        var partida = new ItemPresupuestoDelphin { Id = "PARTIDA", IdLocalMYG = "PARTIDA", Item = "01",
            Descripcion = "Partida dividida", TipoPropuesta = "PARTIDA", Unidad = "m3" };
        partida.Costos.Cantidad = 10;
        partida.Costos.Analisis.Add(new() { InsumoId = recurso.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 });
        presupuesto.Items.Add(partida);
        var lunes = new DateTime(2026, 10, 5);
        var plan = new MYGCronograma { FechaInicio = lunes, FechaEstado = lunes };
        plan.Calendario.Excepciones.Add(new() { Id = "MEDIA JORNADA", Inicio = lunes, Fin = lunes, Laborable = true,
            Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } });
        plan.Tareas.Add(new() { Id = "RESUMEN", Nombre = "Resumen", EsResumen = true });
        plan.Tareas.Add(new() { Id = "PARTIDA", Nombre = "Partida dividida", PadreId = "RESUMEN", DuracionDias = 3,
            PresupuestoId = presupuesto.Id, PartidaId = partida.Id, Partes = new()
            {
                new() { DesfaseInicioDias = 0, DuracionDias = 2, Cantidad = 2.5m, Porcentaje = 25 },
                new() { DesfaseInicioDias = 4, DuracionDias = 1, Cantidad = 7.5m, Porcentaje = 75 }
            } });
        string antes = Huella(plan), presupuestoAntes = Huella(documento.Presupuestos);
        var modelo = MYGExportacionCronograma.PrepararProject(documento, plan, true);
        var calcular = typeof(MYGCronogramaDetallesControl).GetMethod("CalcularRecursos", BindingFlags.Static | BindingFlags.NonPublic);
        List<MYGCronogramaDetallesControl.FilaRecurso> Filas(DateTime desde, DateTime hasta)
        {
            var resultado = calcular.Invoke(null, new object[] { modelo, plan, "RESUMEN", desde, hasta, "Día" });
            return (List<MYGCronogramaDetallesControl.FilaRecurso>)resultado.GetType().GetProperty("Filas").GetValue(resultado);
        }
        var fila = Filas(lunes, lunes.AddDays(4)).Single();
        bool Cerca(decimal a, decimal b) => Math.Abs(a - b) < .000001m;
        exige(fila.CantidadTotal == 20 && fila.CostoTotal == 200 && fila.Recurso.Unidad == "m3" &&
            Cerca(fila.Cantidades[0], 5m / 3) && Cerca(fila.Cantidades[1], 10m / 3) &&
            fila.Cantidades[2] == 0 && fila.Cantidades[3] == 0 && fila.Cantidades[4] == 15 &&
            Cerca(fila.Cantidades.Sum(), 20) && Cerca(fila.Costos.Sum(), 200),
            "Recursos y BI deben incluir descendientes, distribuir 25/75 por partes y horas reales y dejar vacíos los días de pausa sin perder cantidad, costo o unidad.");
        var recortada = Filas(lunes.AddDays(4), lunes.AddDays(4)).Single();
        exige(recortada.CantidadTotal == 20 && recortada.CostoTotal == 200 && recortada.Cantidades.Single() == 15 &&
            recortada.Costos.Single() == 150 && Huella(plan) == antes && Huella(documento.Presupuestos) == presupuestoAntes,
            "Recortar el rango de recursos debe limitar columnas/gráficos y conservar los totales de toda la selección sin alterar el origen.");
    }

    private static void TramosNativos(Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Tramos nativos UI"); var presupuesto = documento.Presupuestos[0];
        var partida = new ItemPresupuestoDelphin { Id = "PARTIDA", IdLocalMYG = "PARTIDA", Item = "01",
            Descripcion = "Trabajo importado", TipoPropuesta = "PARTIDA", Unidad = "m3" };
        partida.Costos.Cantidad = 17.5m; presupuesto.Items.Add(partida);
        var lunes = new DateTime(2026, 10, 5);
        var plan = new MYGCronograma { FechaInicio = lunes, FechaEstado = lunes };
        var tarea = new MYGTareaCronograma { Id = "NATIVA", Nombre = "Trabajo importado", DuracionDias = 5,
            Modo = MYGModoTarea.Manual, InicioManual = lunes, PresupuestoId = presupuesto.Id, PartidaId = partida.Id,
            FechasImportadasDelphin = new() { Inicio = lunes, Fin = lunes.AddDays(14), DuracionDias = 5,
                ModoOriginal = MYGModoTarea.Manual, Tramos = new()
                {
                    new() { Id = "N1", Inicio = lunes, Fin = lunes.AddDays(1), Duracion = 2, Cantidad = 5, Porcentaje = 35 },
                    new() { Id = "N2", Inicio = lunes.AddDays(10), Fin = lunes.AddDays(14), Duracion = 3, Cantidad = 12.5m, Porcentaje = 65 }
                } } };
        plan.Tareas.Add(tarea);
        var fraccionaria = MYGProyectoStorage.Copia(tarea); fraccionaria.Id = "FRACCIÓN";
        fraccionaria.Nombre = "Duración nativa fraccionaria"; fraccionaria.DuracionDias = 2;
        fraccionaria.FechasImportadasDelphin = new() { Inicio = lunes, Fin = lunes.AddDays(1), DuracionDias = 2,
            ModoOriginal = MYGModoTarea.Manual, Tramos = new()
            { new() { Id = "NF", Inicio = lunes, Fin = lunes.AddDays(1), Duracion = 1.5m, Cantidad = 17.5m, Porcentaje = 100 } } };
        plan.Tareas.Add(fraccionaria);
        string snapshot = Huella(tarea.FechasImportadasDelphin), inicial = Huella(plan);
        int aplicaciones = 0;
        using var control = new MYGInformacionTareaControl(() => plan, () => documento, nueva => { plan = nueva; aplicaciones++; }, () => true);
        using var ventana = new Form { ClientSize = new Size(1650, 620) };
        ventana.Controls.Add(control); ventana.Show(); control.Cargar(tarea.Id); Application.DoEvents();
        var partes = Campo<DataGridView>(control, "partes");
        exige(partes.Rows.Count == 2 && Convert.ToDecimal(partes.Rows[0].Cells["DURACION"].Value) == 2 &&
            Convert.ToDateTime(partes.Rows[1].Cells["INICIO"].Value) == lunes.AddDays(10) &&
            Convert.ToDateTime(partes.Rows[1].Cells["FIN"].Value) == lunes.AddDays(14) &&
            Convert.ToDecimal(partes.Rows[0].Cells["PORCENTAJE"].Value) == 35 && !control.TieneCambios && Huella(plan) == inicial,
            "La consulta debe mostrar ambos tramos nativos con fechas, hueco y porcentaje originales sin convertirlos ni crear historial.");
        Campo<TextBox>(control, "notas").Text = "Sólo se agregó una nota"; control.GuardarCambios();
        var guardada = plan.Tareas.Single(t => t.Id == tarea.Id);
        exige(aplicaciones == 1 && guardada.Partes.Count == 0 && Huella(guardada.FechasImportadasDelphin) == snapshot,
            "Guardar una nota debe conservar íntegra la instantánea nativa y sus tramos sin crear partes MYG.");
        control.Cargar(fraccionaria.Id);
        exige(Convert.ToDecimal(partes.Rows[0].Cells["DURACION"].Value) == 1.5m,
            "La consulta debe mostrar una duración nativa fraccionaria sin redondearla en la tabla de partes.");
        string snapshotFraccionario = Huella(fraccionaria.FechasImportadasDelphin);
        Campo<TextBox>(control, "notas").Text = "Nota válida con duración fraccionaria"; control.GuardarCambios();
        exige(aplicaciones == 2 && Huella(plan.Tareas.Single(t => t.Id == fraccionaria.Id).FechasImportadasDelphin) == snapshotFraccionario,
            "Una nota en una tarea fraccionaria debe guardarse conservando sus fechas y duración originales.");
        string antesInvalido = Huella(plan);
        partes.Rows[0].Cells["CANTIDAD"].Value = 17m;
        bool rechazada = false;
        try { control.GuardarCambios(); } catch (InvalidDataException) { rechazada = true; }
        exige(rechazada && aplicaciones == 2 && Huella(plan) == antesInvalido && control.TieneCambios,
            "Convertir partes nativas fraccionarias debe rechazar datos no representables sin perder el borrador ni modificar el proyecto.");
        Boton(control, "cancelar").PerformClick();
    }

    private static void CuadrillasRecursos(Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Dotación real por cuadrilla"); var presupuesto = documento.Presupuestos[0];
        var operario = new MYGInsumo { Id = "OPERARIO", Codigo = "MO1", Descripcion = "Operario", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 10 };
        var equipo = new MYGInsumo { Id = "EQUIPO", Codigo = "EQ1", Descripcion = "Equipo", Unidad = "hm", Grupo = MYGGrupoRecurso.Equipo, Precio = 5 };
        var material = new MYGInsumo { Id = "MATERIAL", Codigo = "MAT1", Descripcion = "Material", Unidad = "m3", Grupo = MYGGrupoRecurso.Materiales, Precio = 1 };
        presupuesto.Costos.Insumos.AddRange(new[] { operario, equipo, material });
        ItemPresupuestoDelphin Partida(string id)
        {
            var p = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, Descripcion = id, TipoPropuesta = "PARTIDA", Unidad = "und" };
            p.Costos.Cantidad = 1; presupuesto.Items.Add(p); return p;
        }
        var primera = Partida("A"); var segunda = Partida("B");
        primera.Costos.Analisis.Add(new() { InsumoId = operario.Id, Grupo = MYGGrupoRecurso.ManoObra, NumeroRecursos = 3, Cantidad = 10 });
        primera.Costos.Analisis.Add(new() { InsumoId = equipo.Id, Grupo = MYGGrupoRecurso.Equipo, NumeroRecursos = .5m, Cantidad = 5 });
        primera.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, NumeroRecursos = 99, Cantidad = 2 });
        segunda.Costos.Analisis.Add(new() { InsumoId = operario.Id, Grupo = MYGGrupoRecurso.ManoObra, NumeroRecursos = 1.5m, Cantidad = 99 });
        var lunes = new DateTime(2026, 10, 5);
        var plan = new MYGCronograma { FechaInicio = lunes, FechaEstado = lunes };
        plan.Tareas.Add(new() { Id = "RESUMEN", Nombre = "Resumen", EsResumen = true });
        var tareaA = new MYGTareaCronograma { Id = "A", PadreId = "RESUMEN", Nombre = "A", DuracionDias = 2,
            PresupuestoId = presupuesto.Id, PartidaId = primera.Id, NumeroCuadrillas = 2, CuadrillasIniciales = 2 };
        MYGInformacionTarea.Dividir(tareaA, 2, 2, 1); plan.Tareas.Add(tareaA);
        var tareaB = new MYGTareaCronograma { Id = "B", PadreId = "RESUMEN", Nombre = "B", DuracionDias = 3,
            PresupuestoId = presupuesto.Id, PartidaId = segunda.Id, NumeroCuadrillas = 2, CuadrillasIniciales = 2,
            Modo = MYGModoTarea.Manual, InicioManual = lunes.AddDays(1) };
        plan.Tareas.Add(tareaB);
        var calcular = typeof(MYGCronogramaDetallesControl).GetMethod("CalcularRecursos", BindingFlags.Static | BindingFlags.NonPublic);
        var completar = typeof(MYGCronogramaDetallesControl).GetMethod("CompletarCuadrillas", BindingFlags.Static | BindingFlags.NonPublic);
        List<MYGCronogramaDetallesControl.FilaRecurso> Filas(string id, DateTime desde, DateTime hasta, string escala = "Día")
        {
            var modelo = MYGExportacionCronograma.PrepararProject(documento, plan, true);
            var resultado = calcular.Invoke(null, new object[] { modelo, plan, id, desde, hasta, escala });
            completar.Invoke(null, new object[] { resultado, modelo, plan, documento, id });
            return (List<MYGCronogramaDetallesControl.FilaRecurso>)resultado.GetType().GetProperty("Filas").GetValue(resultado);
        }
        string antes = Huella(plan), presupuestoAntes = Huella(documento.Presupuestos);
        var filas = Filas("RESUMEN", lunes, lunes.AddDays(6));
        var manoObra = filas.Single(f => f.Recurso.Codigo == operario.Codigo);
        var maquinaria = filas.Single(f => f.Recurso.Codigo == equipo.Codigo);
        var materiales = filas.Single(f => f.Recurso.Codigo == material.Codigo);
        exige(manoObra.Cuadrillas.SequenceEqual(new decimal?[] { 6, 3, 3, 9, 0, 0, 0 }) && manoObra.CuadrillaMaxima == 9 &&
            manoObra.CantidadTotal == 109 && maquinaria.Cuadrillas.SequenceEqual(new decimal?[] { 1, 0, 0, 1, 0, 0, 0 }) &&
            maquinaria.CuadrillaMaxima == 1 && materiales.CuadrillaMaxima == null && materiales.Cuadrillas.All(v => v == null),
            "Recurso x cuadrilla debe multiplicar 3×2 y 1,5×2 recursos reales, sumar 9 sólo donde coinciden y dejar materiales sin dotación inferida desde horas o cantidades.");
        var semanal = Filas("RESUMEN", lunes, lunes.AddDays(6), "Semana").Single(f => f.Recurso.Codigo == operario.Codigo);
        var pausa = Filas("A", lunes, lunes.AddDays(6)).Single(f => f.Recurso.Codigo == operario.Codigo);
        var recorte = Filas("RESUMEN", lunes.AddDays(4), lunes.AddDays(4)).Single(f => f.Recurso.Codigo == operario.Codigo);
        exige(semanal.Cuadrillas.Single() == 9 && semanal.CuadrillaMaxima == 9 &&
            pausa.Cuadrillas.SequenceEqual(new decimal?[] { 6, 0, 0, 6, 0, 0, 0 }) &&
            recorte.Cuadrillas.Single() == 0 && recorte.CuadrillaMaxima == 9 &&
            Huella(plan) == antes && Huella(documento.Presupuestos) == presupuestoAntes,
            "El máximo semanal debe ser simultáneo y conservarse al recortar el rango, con dotación cero durante las pausas y sin cambiar ACU ni tareas.");
        tareaB.DuracionDias = 7;
        var finSemana = Filas("RESUMEN", lunes.AddDays(5), lunes.AddDays(6)).Single(f => f.Recurso.Codigo == operario.Codigo);
        exige(finSemana.Cuadrillas.All(v => v == 0),
            "Las tareas que abarcan sábado y domingo deben tener dotación cero en esos días inhábiles.");
        tareaB.DuracionDias = 3;

        tareaA.Partes.Clear(); tareaA.DuracionDias = 3; tareaA.Modo = MYGModoTarea.Manual; tareaA.InicioManual = lunes;
        tareaA.FechasImportadasDelphin = new() { Inicio = lunes, Fin = lunes.AddDays(2), DuracionDias = 3,
            ModoOriginal = MYGModoTarea.Manual, Tramos = new()
            {
                new() { Inicio = lunes, Fin = lunes.AddDays(1), Duracion = 2, Cantidad = .5m, Porcentaje = 50 },
                new() { Inicio = lunes.AddDays(1), Fin = lunes.AddDays(2), Duracion = 2, Cantidad = .5m, Porcentaje = 50 }
            } };
        var solape = Filas("A", lunes, lunes.AddDays(3)).Single(f => f.Recurso.Codigo == operario.Codigo);
        exige(solape.Cuadrillas.SequenceEqual(new decimal?[] { 6, 6, 6, 0 }) && solape.CuadrillaMaxima == 6,
            "Dos tramos nativos solapados de la misma tarea deben aportar una sola dotación en el día compartido.");
        var subpartida = Partida("SUB");
        subpartida.Costos.Analisis.Add(new() { InsumoId = operario.Id, Grupo = MYGGrupoRecurso.ManoObra, NumeroRecursos = 7, Cantidad = 8 });
        primera.Costos.Analisis.Clear();
        primera.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = subpartida.IdLocalMYG, Cantidad = 1 });
        var sinSemantica = Filas("A", lunes, lunes.AddDays(3)).Single(f => f.Recurso.Codigo == operario.Codigo);
        exige(sinSemantica.CuadrillaMaxima == null && sinSemantica.Cuadrillas.All(v => v == null) &&
            sinSemantica.AvisoCuadrilla.Contains("subpartidas", StringComparison.OrdinalIgnoreCase),
            "Una dotación procedente de subanálisis debe quedar vacía con una explicación cuando no se conoce su simultaneidad.");
    }

    private static T Campo<T>(Control raiz, string nombre) where T : Control =>
        raiz.Controls.Find(Prefijo + nombre, true).OfType<T>().Single();
    private static Button Boton(Control raiz, string nombre) => Campo<Button>(raiz, nombre);
    private static string Huella(object valor) => JsonSerializer.Serialize(valor);
}
