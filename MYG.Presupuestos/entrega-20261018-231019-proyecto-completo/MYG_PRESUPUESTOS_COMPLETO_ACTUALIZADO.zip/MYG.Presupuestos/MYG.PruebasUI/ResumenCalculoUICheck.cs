using System;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class ResumenCalculoUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Resumen sin cambios en el original");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        partida.Costos.Cantidad = 1;
        partida.Costos.PrecioDirecto = 1000;
        presupuesto.Costos.Moneda = "S/";
        presupuesto.Costos.GastosGeneralesPorcentaje = 10;
        presupuesto.Costos.UtilidadPorcentaje = 5;
        presupuesto.Costos.ImpuestoPorcentaje = 18;
        presupuesto.Costos.OtrosImpuestosPorcentaje = 2;
        string firma = MYGProyectoStorage.Firma(proyecto);

        using var ventana = new MYGResumenCostosForm(presupuesto);
        var tabla = ventana.Controls.OfType<TableLayoutPanel>().Single();
        var texto = ventana.Controls.OfType<Label>().Single();
        var moneda = (TextBox)tabla.GetControlFromPosition(1, 0);
        var gastos = (NumericUpDown)tabla.GetControlFromPosition(1, 1);
        var utilidad = (NumericUpDown)tabla.GetControlFromPosition(1, 2);
        var impuesto = (NumericUpDown)tabla.GetControlFromPosition(1, 3);
        var otros = (NumericUpDown)tabla.GetControlFromPosition(1, 4);

        void Total(decimal valor, string simbolo)
        {
            exige(texto.Text.Contains("\n\nTOTAL: " + simbolo + " " + MYGFormatoPresupuesto.Dinero(valor), StringComparison.Ordinal),
                "El resumen debe conciliar su total y moneda después de cada edición.");
            exige(MYGProyectoStorage.Firma(proyecto) == firma,
                "Consultar y editar la vista previa del resumen no debe modificar el presupuesto original.");
        }

        Total(1380, "S/");
        gastos.Value = 20;
        Total(1500, "S/");
        utilidad.Value = 10;
        Total(1560, "S/");
        impuesto.Value = 10;
        Total(1456, "S/");
        otros.Value = 0;
        Total(1430, "S/");
        moneda.Text = "USD";
        Total(1430, "USD");
        gastos.Value = 10;
        utilidad.Value = 5;
        impuesto.Value = 18;
        otros.Value = 2;
        Total(1380, "USD");
        ventana.Close();
        exige(MYGProyectoStorage.Firma(proyecto) == firma,
            "Cerrar el resumen sin aplicar debe conservar los importes y porcentajes del proyecto.");
    }
}
