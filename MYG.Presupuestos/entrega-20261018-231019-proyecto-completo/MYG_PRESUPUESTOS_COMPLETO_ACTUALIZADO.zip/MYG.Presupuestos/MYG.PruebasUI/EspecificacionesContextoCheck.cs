using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesContextoCheck
{
    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);
    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessagePunto(IntPtr ventana, int mensaje, IntPtr wParam, ref Point punto);
    [System.Runtime.InteropServices.DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr objeto);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarFormatosPegado(exige);
        VerificarOrtografia(exige);
        VerificarHitTestFuenteGrande(exige);
        VerificarAnotaciones(exige);
        VerificarEditor(exige);
        VerificarMenuEnTemas(exige);
        VerificarCursorContextualNativo(exige);
        VerificarFuentePredeterminada(exige);
        VerificarFuenteAnteHfontDpi(exige);
    }

    private sealed record EstadoCursor(string Rtf, int Inicio, int Longitud, string Fuente, string RtfSeleccion,
        int Color, int Fondo, int Alineacion, int Sangria, int SangriaDerecha, int SangriaFrancesa,
        bool Deshacer, bool Rehacer, Point ScrollTexto, Point ScrollHoja, int Antes, int Cambios);

    private static EstadoCursor CapturarCursor(MYGEspecificacionesEditor editor, RichTextBox documento, Panel lienzo,
        Func<(int Antes, int Cambios)> callbacks)
    {
        Point scroll = Point.Empty;
        SendMessagePunto(documento.Handle, 0x04DD, IntPtr.Zero, ref scroll); // EM_GETSCROLLPOS.
        var fuente = documento.SelectionFont;
        string estilo = fuente == null ? "mixto" : fuente.Name + ":" + fuente.SizeInPoints + ":" + fuente.Style;
        var contadores = callbacks();
        return new(editor.DocumentoRtf, documento.SelectionStart, documento.SelectionLength, estilo, documento.SelectedRtf,
            documento.SelectionColor.ToArgb(), documento.SelectionBackColor.ToArgb(), (int)documento.SelectionAlignment,
            documento.SelectionIndent, documento.SelectionRightIndent, documento.SelectionHangingIndent,
            documento.CanUndo, documento.CanRedo, scroll, lienzo.AutoScrollPosition, contadores.Antes, contadores.Cambios);
    }

    private static void VerificarCursorContextualNativo(Action<bool, string> exige)
    {
        int antes = 0, cambios = 0;
        using var documento = new RichTextBox { Font = new Font("Arial", 11), DetectUrls = false };
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "Prueba del cursor", () => "und", () => "01", comprobarOrtografia: BuscarErrores,
            sugerirOrtografia: _ => new[] { "hormigón" });
        using var formulario = new Form { ClientSize = new Size(950, 740) };
        formulario.Controls.Add(editor); formulario.Show(); Application.DoEvents();
        string texto = "REMOTO\nTexto correcto entre ambas posiciones\nError: hormigonx final\n" +
            string.Concat(Enumerable.Repeat("Línea para comprobar desplazamiento del documento.\n", 70));
        editor.Cargar("cursor-nativo", "", texto);
        documento.Select(0, 6);
        editor.AplicarFormato(() =>
        {
            documento.SelectionFont = new Font("Courier New", 14, FontStyle.Bold);
            documento.SelectionColor = Color.DarkBlue;
        });
        int error = documento.Text.IndexOf("hormigonx", StringComparison.Ordinal);
        documento.Select(error, 9);
        editor.AplicarFormato(() => documento.SelectionColor = Color.DarkGreen);
        var corrector = (MYGEspecificacionesOrtografia)typeof(MYGEspecificacionesEditor)
            .GetField("ortografia", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        corrector.ComprobarAhora();
        var lienzo = (Panel)Controles(editor).Single(x => x.Name == "espec_lienzo");
        var papel = Controles(editor).Single(x => x.Name == "espec_papel");
        var menu = documento.ContextMenuStrip;
        var zoom = Controles(editor).OfType<NumericUpDown>().Single(x => x.Name == "espec_zoom");
        zoom.Value = 100;
        foreach (int longitud in new[] { 6, 0 })
        {
            documento.Focus(); documento.Select(longitud == 0 ? 2 : 0, longitud);
            lienzo.AutoScrollPosition = new Point(0, 40);
            Point scrollTexto = new(0, 12);
            SendMessagePunto(documento.Handle, 0x04DE, IntPtr.Zero, ref scrollTexto); // EM_SETSCROLLPOS.
            Application.DoEvents();
            var original = CapturarCursor(editor, documento, lienzo, () => (antes, cambios));
            exige(original.Deshacer && original.ScrollHoja.Y < 0 && original.ScrollTexto.Y > 0,
                "La prueba del clic derecho debe usar una edición deshacible y desplazamiento real en la hoja y en RichEdit.");
            Point punto = PuntoCaracter(documento, error + 1);
            SendMessage(documento.Handle, 0x0204, new IntPtr(2), Empaquetar(punto)); // WM_RBUTTONDOWN.
            Application.DoEvents();
            exige(CapturarCursor(editor, documento, lienzo, () => (antes, cambios)) == original,
                "WM_RBUTTONDOWN sobre una palabra remota debe conservar cursor, selección, formato, scroll, Deshacer y callbacks.");
            SendMessage(documento.Handle, 0x0206, new IntPtr(2), Empaquetar(punto)); // WM_RBUTTONDBLCLK.
            Application.DoEvents();
            exige(CapturarCursor(editor, documento, lienzo, () => (antes, cambios)) == original,
                "El doble clic derecho nativo debe conservar la selección y el formato del cursor original.");
            CompletarClicDerecho(documento, punto);
            exige(menu.Visible && Opcion(menu, "hormigón").Visible &&
                CapturarCursor(editor, documento, lienzo, () => (antes, cambios)) == original,
                "El menú nativo debe ofrecer la corrección bajo el mouse conservando la selección o el cursor remoto.");
            menu.Close();

            SendMessage(documento.Handle, 0x007B, documento.Handle, Empaquetar(documento.PointToScreen(punto)));
            Application.DoEvents();
            exige(menu.Visible && Opcion(menu, "hormigón").Visible &&
                CapturarCursor(editor, documento, lienzo, () => (antes, cambios)) == original,
                "WM_CONTEXTMENU con coordenadas de pantalla debe corregir bajo el mouse sin alterar el cursor ni el scroll.");
            menu.Close();

            foreach (var (destino, margen) in new[]
            {
                (destino: (Control)documento, margen: new Point(documento.ClientSize.Width - 8, 50)),
                (destino: papel, margen: new Point(3, 3))
            })
            {
                original = CapturarCursor(editor, documento, lienzo, () => (antes, cambios));
                AbrirMenu(destino, margen);
                exige(menu.Visible && !menu.Items.OfType<ToolStripMenuItem>().Any(x => x.Text == "hormigón") &&
                    CapturarCursor(editor, documento, lienzo, () => (antes, cambios)) == original,
                    "El clic derecho en el margen del texto o del papel debe abrir el menú normal sin mover el cursor ni desplazar la hoja.");
                menu.Close();
            }
        }

        documento.Select(0, 6);
        AbrirMenuTeclado(documento);
        exige(menu.Visible && !menu.Items.OfType<ToolStripMenuItem>().Any(x => x.Text == "hormigón") &&
            documento.SelectionStart == 0 && documento.SelectionLength == 6,
            "El menú solicitado por teclado debe tomar la selección activa y descartar el último error señalado por el mouse.");
        menu.Close(); documento.Select(error + 1, 0);
        var teclado = CapturarCursor(editor, documento, lienzo, () => (antes, cambios));
        AbrirMenuTeclado(documento);
        exige(menu.Visible && Opcion(menu, "hormigón").Visible &&
            CapturarCursor(editor, documento, lienzo, () => (antes, cambios)) == teclado,
            "El menú por teclado sobre un error debe ofrecer sus sugerencias sin cambiar selección, formato o scroll.");
        menu.Close();

        documento.Select(0, 6); int antesComando = antes, cambiosComando = cambios;
        AbrirMenu(documento, PuntoCaracter(documento, error + 1));
        Opcion(menu, "hormigón").PerformClick(); menu.Close();
        exige(documento.Text == texto.Replace("hormigonx", "hormigón", StringComparison.Ordinal) &&
            antes == antesComando + 1 && cambios == cambiosComando + 1,
            "La sugerencia debe corregir la palabra bajo el mouse y registrar un único cambio aunque la selección esté lejos.");
        documento.Select(0, 6);
        exige(documento.SelectedText == "REMOTO" && documento.SelectionFont?.Name == "Courier New" &&
            documento.SelectionFont.Bold && documento.SelectionColor.ToArgb() == Color.DarkBlue.ToArgb(),
            "Corregir una palabra remota debe conservar el contenido y el formato de la selección original.");

        IDataObject previo = Clipboard.GetDataObject();
        try
        {
            editor.Cargar("cursor-cortar", "", texto); corrector.ComprobarAhora(); documento.Focus(); documento.Select(0, 6);
            antesComando = antes; cambiosComando = cambios;
            AbrirMenu(documento, PuntoCaracter(documento, error + 1));
            exige(Opcion(menu, "Cortar").Enabled, "Cortar debe seguir disponible para la selección remota conservada.");
            Opcion(menu, "Cortar").PerformClick(); menu.Close();
            exige(documento.Text == texto[6..] && documento.Text.Contains("hormigonx") &&
                antes == antesComando + 1 && cambios == cambiosComando + 1,
                "Cortar desde el menú debe actuar sobre la selección original y conservar la palabra bajo el mouse.");
            editor.Cargar("cursor-pegar", "", texto); corrector.ComprobarAhora(); documento.Focus(); documento.Select(0, 6);
            Clipboard.SetText("[PEGADO]"); antesComando = antes; cambiosComando = cambios;
            AbrirMenu(documento, PuntoCaracter(documento, error + 1));
            exige(Opcion(menu, "Pegar").Enabled, "Pegar debe usar el contenido disponible del portapapeles.");
            Opcion(menu, "Pegar").PerformClick(); menu.Close();
            exige(documento.Text == "[PEGADO]" + texto[6..] && documento.Text.Contains("hormigonx") &&
                antes == antesComando + 1 && cambios == cambiosComando + 1,
                "Pegar desde el menú debe reemplazar la selección original y conservar la palabra señalada por el mouse.");
        }
        finally
        {
            if (previo != null) Clipboard.SetDataObject(previo, true);
            else Clipboard.Clear();
        }
        formulario.Close();
    }

    private static void VerificarFuentePredeterminada(Action<bool, string> exige)
    {
        int antes = 0, cambios = 0;
        using var documento = new RichTextBox();
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "CONCRETO ARMADO", () => "m³", () => "01.01", comprobarOrtografia: _ => Array.Empty<MYGErrorOrtografico>());
        using var formulario = new Form { ClientSize = new Size(950, 740) };
        formulario.Controls.Add(editor); formulario.Show(); Application.DoEvents();
        string familia = FontFamily.Families.Any(x => x.Name.Equals("Arial Narrow", StringComparison.OrdinalIgnoreCase))
            ? "Arial Narrow" : "Arial";
        var combos = Controles(editor).OfType<ToolStrip>().SelectMany(x => x.Items.OfType<ToolStripComboBox>()).ToArray();
        var fuenteCinta = combos.Single(x => x.Name == "espec_fuente");
        var tamanoCinta = combos.Single(x => x.Name == "espec_tamano");
        var inicial = (antes, cambios);
        editor.Cargar("fuente-vacia", "", "");
        exige(EsFuente(documento.Font, familia, 11) && EsFuente(documento.SelectionFont, familia, 11),
            "Una nueva especificación debe tener fuente base e inserción de 11 puntos, con Arial Narrow cuando está instalada.");
        exige(fuenteCinta.Text == familia && decimal.TryParse(tamanoCinta.Text, out decimal tamano) && tamano == 11 &&
            (antes, cambios) == inicial,
            "La cinta debe mostrar la fuente predeterminada y 11 puntos sin guardar ni agregar historial durante la carga.");

        const string plano = "Descripción inicial\nControl de calidad\n\n";
        editor.Cargar("fuente-texto", "", plano);
        documento.SelectAll();
        exige(documento.Text == plano && EsFuente(documento.SelectionFont, familia, 11) && documento.SelectionFont.Style == FontStyle.Regular,
            "Cargar una especificación de texto plano debe usar 11 puntos en todos los párrafos sin heredar formato de otra partida.");
        documento.Select(documento.TextLength, 0);
        exige(EsFuente(documento.SelectionFont, familia, 11) && decimal.TryParse(tamanoCinta.Text, out tamano) && tamano == 11,
            "El último párrafo vacío debe conservar 11 puntos y mostrar ese tamaño en la cinta.");
        editor.Cargar("fuente-titulo", "", "");
        var insertarTitulo = Controles(editor).OfType<Button>().Single(x => x.Name == "espec_insertar_titulo");
        inicial = (antes, cambios); insertarTitulo.PerformClick();
        exige(documento.Text.Contains("01.01  CONCRETO ARMADO") &&
            antes == inicial.antes + 1 && cambios == inicial.cambios + 1,
            "Insertar título debe crear el encabezado de la partida y registrar una única modificación.");
        documento.Select(0, "01.01  CONCRETO ARMADO".Length);
        exige(EsFuente(documento.SelectionFont, familia, 11) && documento.SelectionFont.Bold,
            "El título insertado debe usar 11 puntos y conservar su negrita.");
        documento.Select(documento.TextLength, 0);
        exige(EsFuente(documento.SelectionFont, familia, 11) && !documento.SelectionFont.Bold,
            "El cursor al final del título debe quedar en un párrafo vacío de 11 puntos sin heredar la negrita del encabezado.");
        editor.AplicarFormato(() => documento.SelectedText = "Texto escrito después del título\n\n");
        documento.Select(documento.TextLength, 0);
        exige(EsFuente(documento.SelectionFont, familia, 11) && !documento.SelectionFont.Bold,
            "Escribir texto y terminar con un párrafo vacío debe conservar la fuente y el tamaño de inserción predeterminados.");

        string rtf = editor.DocumentoRtf; int seleccion = documento.SelectionStart;
        bool undo = documento.CanUndo; inicial = (antes, cambios);
        var zoom = Controles(editor).OfType<NumericUpDown>().Single(x => x.Name == "espec_zoom");
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            foreach (int ampliacion in new[] { 125, 150, 100 })
            {
                zoom.Value = ampliacion; MYG2027_TemaComercial.Alternar(false); Application.DoEvents();
                exige(EsFuente(documento.Font, familia, 11) && EsFuente(documento.SelectionFont, familia, 11) &&
                    decimal.TryParse(tamanoCinta.Text, out tamano) && tamano == 11 && editor.DocumentoRtf == rtf &&
                    documento.SelectionStart == seleccion && documento.SelectionLength == 0 && documento.CanUndo == undo &&
                    (antes, cambios) == inicial,
                    "Cambiar zoom y tema debe conservar 11 puntos en el párrafo vacío, RTF, cursor, Deshacer y callbacks.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }

        const string distinto = @"{\rtf1\ansi\deff0{\fonttbl{\f0 Courier New;}}\f0\fs34\i Formato existente\i0\par}";
        editor.Cargar("fuente-existente", distinto, "Formato existente\n");
        documento.Select(0, "Formato existente".Length);
        exige(EsFuente(documento.SelectionFont, "Courier New", 17) && documento.SelectionFont.Italic,
            "Cargar un RTF existente debe respetar su fuente, 17 puntos y cursiva aunque la fuente base sea de 11 puntos.");
        editor.Cargar("fuente-vacia-explicita", @"{\rtf1\ansi\deff0{\fonttbl{\f0 Courier New;}}\f0\fs40\par}", "\n");
        documento.Select(0, 0);
        exige(EsFuente(documento.SelectionFont, "Courier New", 20),
            "Un párrafo vacío con fuente explícita en el RTF debe conservar Courier New y 20 puntos.");
        editor.Cargar("fuente-limpia", "", "Nuevo texto\n\n");
        documento.SelectAll();
        exige(EsFuente(documento.SelectionFont, familia, 11) && documento.SelectionFont.Style == FontStyle.Regular,
            "Volver a una especificación de texto plano debe restablecer 11 puntos sin heredar los 17 puntos del RTF anterior.");
        formulario.Close();
    }

    private static bool EsFuente(Font fuente, string familia, float tamano) => fuente != null &&
        fuente.Name.Equals(familia, StringComparison.OrdinalIgnoreCase) && Math.Abs(fuente.SizeInPoints - tamano) < .01;

    private static void VerificarFuenteAnteHfontDpi(Action<bool, string> exige)
    {
        int antes = 0, cambios = 0;
        using var documento = new MYGEspecificacionesRichTextBox();
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "Partida para DPI", () => "und", () => "01", comprobarOrtografia: _ => Array.Empty<MYGErrorOrtografico>());
        using var formulario = new Form { ClientSize = new Size(950, 740) };
        formulario.Controls.Add(editor); formulario.Show(); Application.DoEvents();
        string familia = documento.Font.Name;
        editor.Cargar("hfont-dpi", "", "Texto formateado\nPárrafo final\n\n");
        documento.Select(0, 5);
        editor.AplicarFormato(() => documento.SelectionFont = new Font("Courier New", 17, FontStyle.Italic));
        documento.Select(documento.TextLength, 0); documento.Focus(); Application.DoEvents();
        var lienzo = (Panel)Controles(editor).Single(x => x.Name == "espec_lienzo");
        var original = CapturarCursor(editor, documento, lienzo, () => (antes, cambios));
        foreach (float escala in new[] { 1.25f, 1.5f })
        {
            // WinForms transmite un HFONT escalado al actualizar el DPI. Este
            // mensaje real reproduce ese paso sin depender de mover la ventana
            // a un segundo monitor con otra resolución.
            using var fuenteInterfaz = new Font(familia, 11 * escala, FontStyle.Regular, GraphicsUnit.Point);
            IntPtr hfont = fuenteInterfaz.ToHfont();
            try
            {
                SendMessage(documento.Handle, 0x0030, hfont, new IntPtr(1)); // WM_SETFONT.
                Application.DoEvents();
                exige(CapturarCursor(editor, documento, lienzo, () => (antes, cambios)) == original &&
                    EsFuente(documento.Font, familia, 11) && EsFuente(documento.SelectionFont, familia, 11),
                    "Un HFONT de interfaz al 125 % o 150 % debe conservar 11 puntos, formatos mixtos, RTF, cursor, scroll y callbacks.");
            }
            finally { DeleteObject(hfont); }
        }
        documento.Select(0, 5);
        exige(EsFuente(documento.SelectionFont, "Courier New", 17) && documento.SelectionFont.Italic,
            "Filtrar el HFONT del DPI debe conservar las fuentes explícitas del contenido existente.");
        formulario.Close();
    }

    private static void VerificarMenuEnTemas(Action<bool, string> exige)
    {
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            int antes = 0, cambios = 0;
            using var documento = new RichTextBox { Font = new Font("Arial", 11), DetectUrls = false };
            using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
                () => "Partida de prueba", () => "und", () => "01", comprobarOrtografia: BuscarErrores,
                sugerirOrtografia: _ => new[] { "hormigón" });
            using var formulario = new Form { ClientSize = new Size(950, 740) };
            MYG2027_TemaComercial.Aplicar(formulario);
            formulario.Controls.Add(editor); formulario.Show(); Application.DoEvents();
            editor.Cargar("contexto-temas", "", "Correcto hormigonx y hormigonx");
            documento.Select(documento.TextLength, 0);
            editor.AplicarFormato(() => documento.SelectedText = "\nEdición para comprobar Deshacer.");
            var corrector = (MYGEspecificacionesOrtografia)typeof(MYGEspecificacionesEditor)
                .GetField("ortografia", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
            corrector.ComprobarAhora();
            var menu = documento.ContextMenuStrip;
            var rendererCinta = Controles(editor).OfType<ToolStrip>().First().Renderer;
            foreach (bool oscuro in new[] { false, true })
            {
                foreach (bool sobreError in new[] { false, true })
                {
                    if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                    documento.Focus(); documento.Select(sobreError ? 9 : 0, sobreError ? 9 : 8);
                    Application.DoEvents();
                    string rtf = editor.DocumentoRtf;
                    int posicion = documento.SelectionStart, longitud = documento.SelectionLength;
                    bool undo = documento.CanUndo;
                    var callbacks = (antes, cambios);
                    var errores = corrector.Errores.ToArray();
                    AbrirMenu(documento, documento.GetPositionFromCharIndex(sobreError ? 10 : 1));
                    exige(menu.Visible && menu.Items.OfType<ToolStripMenuItem>().Any(x => x.Text == "hormigón") == sobreError,
                        "El menú normal y el menú ortográfico deben abrirse con sus opciones correspondientes en ambos temas.");
                    var items = menu.Items.Cast<ToolStripItem>().ToArray();
                    VerificarPresentacionMenu(menu, rendererCinta, oscuro, exige);
                    MYG2027_TemaComercial.Alternar(false); Application.DoEvents();
                    exige(menu.Visible && menu.Items.Cast<ToolStripItem>().SequenceEqual(items),
                        "Cambiar el tema con el menú abierto debe conservar su ventana y sus opciones sin duplicarlas.");
                    VerificarPresentacionMenu(menu, rendererCinta, !oscuro, exige);
                    exige(editor.DocumentoRtf == rtf && documento.SelectionStart == posicion &&
                        documento.SelectionLength == longitud && documento.CanUndo == undo && (antes, cambios) == callbacks &&
                        corrector.RevisionCompleta && corrector.Errores.SequenceEqual(errores),
                        "Abrir el menú y cambiar su tema debe conservar RTF, selección, Deshacer, callbacks y resultados ortográficos.");
                    menu.Close();
                }
            }
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarPresentacionMenu(ContextMenuStrip menu, ToolStripRenderer rendererCinta,
        bool oscuro, Action<bool, string> exige)
    {
        var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
        var normales = opciones.Where(x => x.Name.StartsWith("espec_contexto_", StringComparison.Ordinal) &&
            x.Name != "espec_contexto_ortografia").ToArray();
        exige(normales.Length == 11 && normales.All(x => x.DisplayStyle == ToolStripItemDisplayStyle.ImageAndText && x.Image != null),
            "Cada herramienta contextual debe mostrar su etiqueta junto al icono, incluso las opciones deshabilitadas.");
        exige(normales.All(x => x.TextImageRelation == TextImageRelation.ImageBeforeText &&
            x.TextAlign == ContentAlignment.MiddleLeft && x.ImageAlign == ContentAlignment.MiddleLeft),
            "Las filas del menú deben disponer el icono antes del texto y mantener la alineación horizontal a la izquierda.");
        exige(opciones.All(x => (x.DisplayStyle & ToolStripItemDisplayStyle.Text) != 0 &&
            x.TextDirection == ToolStripTextDirection.Horizontal && x.Bounds.Width > TextRenderer.MeasureText(x.Text, x.Font,
                Size.Empty, TextFormatFlags.SingleLine | TextFormatFlags.NoPadding).Width + 24),
            "El menú debe reservar espacio horizontal para leer tanto los comandos como las sugerencias ortográficas.");
        exige(ReferenceEquals(menu.Renderer, rendererCinta) && menu.Renderer is ToolStripProfessionalRenderer,
            "El menú contextual debe conservar el renderer especializado del editor en claro y oscuro.");
        var renderer = (ToolStripProfessionalRenderer)menu.Renderer;
        using var imagen = new Bitmap(menu.Width, menu.Height);
        using (var dibujo = Graphics.FromImage(imagen))
        {
            dibujo.Clear(Color.Magenta);
            renderer.DrawToolStripBackground(new ToolStripRenderEventArgs(dibujo, menu));
        }
        Color fondo = imagen.GetPixel(imagen.Width - 4, imagen.Height - 4);
        exige(fondo.ToArgb() == renderer.ColorTable.ToolStripDropDownBackground.ToArgb() &&
            menu.BackColor.ToArgb() == fondo.ToArgb(),
            "El fondo dibujado del menú debe coincidir con la paleta activa del renderer.");
        if (!SystemInformation.HighContrast)
            exige(oscuro ? fondo.GetBrightness() < .3f : fondo.GetBrightness() > .8f,
                "El menú debe tener un fondo oscuro en modo oscuro y un fondo claro en modo claro.");

        var habilitada = Opcion(menu, "Fuente");
        Opcion(menu, "Copiar").Select();
        Color textoNormal = DibujarTextoMenu(renderer, habilitada);
        exige(textoNormal.ToArgb() == MYGEspecificacionesCinta.Texto.ToArgb(),
            "El renderer debe dibujar el texto de los comandos habilitados con el color del tema.");
        habilitada.Select();
        exige(habilitada.Selected, "La prueba debe seleccionar una fila real del menú sin ejecutar su comando.");
        Color textoSeleccionado = DibujarTextoMenu(renderer, habilitada);
        Color esperadoSeleccionado = SystemInformation.HighContrast ? SystemColors.HighlightText : MYGEspecificacionesCinta.Texto;
        exige(textoSeleccionado.ToArgb() == esperadoSeleccionado.ToArgb(),
            "El texto de la fila seleccionada debe conservar contraste con su resaltado en ambos temas.");
        using var resaltado = new Bitmap(habilitada.Width, habilitada.Height);
        using (var dibujo = Graphics.FromImage(resaltado))
        {
            dibujo.Clear(fondo); renderer.DrawMenuItemBackground(new ToolStripItemRenderEventArgs(dibujo, habilitada));
        }
        Color seleccionado = resaltado.GetPixel(resaltado.Width - 12, resaltado.Height / 2);
        exige(seleccionado.ToArgb() != fondo.ToArgb(), "Seleccionar una fila debe dibujar un resaltado visible.");
        if (!SystemInformation.HighContrast)
            exige(oscuro ? seleccionado.GetBrightness() < .4f : seleccionado.GetBrightness() > .6f,
                "El resaltado del menú debe seguir la paleta clara u oscura sin dejar un fondo claro en modo oscuro.");

        var deshabilitada = Opcion(menu, "Cortar"); bool estabaHabilitada = deshabilitada.Enabled;
        try
        {
            deshabilitada.Enabled = false;
            Color textoDeshabilitado = DibujarTextoMenu(renderer, deshabilitada);
            Color esperado = SystemInformation.HighContrast ? SystemColors.GrayText :
                oscuro ? MYG2027_TemaComercial.Secundario : Color.Gray;
            exige(textoDeshabilitado.ToArgb() == esperado.ToArgb() && textoDeshabilitado.ToArgb() != textoNormal.ToArgb(),
                "El renderer debe distinguir comandos deshabilitados sin ocultar sus etiquetas en ninguno de los temas.");
        }
        finally { deshabilitada.Enabled = estabaHabilitada; }
    }

    private static Color DibujarTextoMenu(ToolStripRenderer renderer, ToolStripMenuItem item)
    {
        using var imagen = new Bitmap(item.Width, item.Height);
        using var dibujo = Graphics.FromImage(imagen);
        var evento = new ToolStripItemTextRenderEventArgs(dibujo, item, item.Text,
            new Rectangle(32, 0, Math.Max(1, item.Width - 36), item.Height), Color.Magenta, item.Font,
            TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
        renderer.DrawItemText(evento);
        return evento.TextColor;
    }

    private static void VerificarHitTestFuenteGrande(Action<bool, string> exige)
    {
        using var documento = new RichTextBox { Font = new Font("Arial", 11), Text = "hormigonx", Dock = DockStyle.Fill };
        using var formulario = new Form { ClientSize = new Size(600, 200) };
        using var grande = new Font("Arial", 36, FontStyle.Bold);
        formulario.Controls.Add(documento); formulario.Show();
        documento.SelectAll(); documento.SelectionFont = grande;
        Application.DoEvents();
        Point inicio = documento.GetPositionFromCharIndex(0), fin = documento.GetPositionFromCharIndex(1);
        Point interior = new((inicio.X + fin.X) / 2, inicio.Y + grande.Height / 2);
        exige(MYGEspecificacionesOrtografia.ContieneCaracter(documento, 0, interior),
            "El clic derecho debe reconocer la mitad inferior de un carácter cuya fuente es mayor que la fuente base.");
        exige(!MYGEspecificacionesOrtografia.ContieneCaracter(documento, 0, new Point(interior.X, 180)),
            "El margen vacío debajo de una palabra no debe reconocerse como un carácter ortográfico.");
    }

    private static void VerificarFormatosPegado(Action<bool, string> exige)
    {
        using var fuente = new RichTextBox { Font = new Font("Arial", 11), Text = "Hormigón armado" };
        fuente.Select(0, 8);
        fuente.SelectionFont = new Font("Arial", 14, FontStyle.Bold);
        fuente.SelectionColor = Color.DarkGreen;
        fuente.Select(9, 6);
        fuente.SelectionFont = new Font("Courier New", 10, FontStyle.Italic);
        var datos = new DataObject();
        datos.SetData(DataFormats.Rtf, false, fuente.Rtf);
        datos.SetData(DataFormats.Html, false, "<p><b>Hormigón</b> <i>armado</i></p>");
        datos.SetData(DataFormats.UnicodeText, false, fuente.Text);
        var copia = MYGEspecificacionesPegado.Capturar(datos);
        exige(Enum.GetValues<MYGFormatoPegado>().All(copia.Disponible),
            "El pegado debe reconocer RTF, HTML y texto del mismo IDataObject.");
        datos.SetData(DataFormats.UnicodeText, false, "Cambiado después de abrir el diálogo");
        exige(copia.Texto == "Hormigón armado", "El diálogo debe conservar la copia del portapapeles tomada al abrirse.");

        using var destino = new RichTextBox { Font = new Font("Arial", 11) };
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(copia, MYGFormatoPegado.Automatico));
        destino.Select(0, 8);
        exige(destino.Text == fuente.Text && destino.SelectionFont?.Bold == true &&
            Math.Abs(destino.SelectionFont.Size - 14) < .01 && destino.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "Pegar automáticamente debe elegir RTF y conservar tamaño, negrita y color del primer fragmento.");
        destino.Select(9, 6);
        exige(destino.SelectionFont?.Italic == true && destino.SelectionFont.Name == "Courier New",
            "El RTF pegado debe conservar el formato distinto del segundo fragmento.");
        destino.Clear(); destino.Font = new Font("Arial", 11);
        destino.SelectAll(); destino.SelectionFont = destino.Font; destino.SelectionColor = Color.Black;
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(copia, MYGFormatoPegado.Texto));
        destino.SelectAll();
        exige(destino.Text == fuente.Text && destino.SelectionFont is Font plano && !plano.Bold && !plano.Italic &&
            Math.Abs(plano.Size - 11) < .01 && destino.SelectionColor.ToArgb() == Color.Black.ToArgb(),
            "Texto sin formato debe pegar los mismos caracteres sin importar las fuentes ni los colores del RTF.");

        var html = new DataObject();
        html.SetData(DataFormats.Html, false, "<b>Seguro</b><script>oculto()</script><img src='https://example.com/img' alt=' visible'>");
        var copiaHtml = MYGEspecificacionesPegado.Capturar(html);
        exige(copiaHtml.Disponible(MYGFormatoPegado.Html) && !copiaHtml.Disponible(MYGFormatoPegado.Rtf),
            "Un portapapeles HTML no debe anunciar disponibilidad de RTF.");
        destino.Clear();
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(copiaHtml, MYGFormatoPegado.Automatico));
        destino.Select(0, 6);
        exige(destino.Text == "Seguro visible" && destino.SelectionFont?.Bold == true &&
            !destino.Rtf.Contains("https", StringComparison.OrdinalIgnoreCase) && !destino.Text.Contains("oculto"),
            "El pegado HTML automático debe conservar formato visible y excluir scripts y recursos remotos.");

        var streams = new DataObject();
        var alineado = new MYGEspecificacionesPortapapeles(null,
            "<p style='text-align:center'>Centro</p><p style='text-align:right'>Derecha</p><p>Izquierda</p>", null);
        destino.Clear();
        MYGEspecificacionesPegado.Aplicar(destino, MYGEspecificacionesPegado.Preparar(alineado, MYGFormatoPegado.Html));
        destino.Select(0, 6);
        exige(destino.SelectionAlignment == HorizontalAlignment.Center, "El HTML debe conservar la alineación centrada del primer párrafo.");
        destino.Select(destino.Text.IndexOf("Derecha", StringComparison.Ordinal), 7);
        exige(destino.SelectionAlignment == HorizontalAlignment.Right, "El HTML debe conservar la alineación derecha sin extenderla al siguiente párrafo.");
        destino.Select(destino.Text.IndexOf("Izquierda", StringComparison.Ordinal), 9);
        exige(destino.SelectionAlignment == HorizontalAlignment.Left, "Un párrafo HTML sin alineación debe conservar la alineación izquierda.");
        streams.SetData(DataFormats.Rtf, false, new MemoryStream(Encoding.Latin1.GetBytes(fuente.Rtf + '\0')));
        streams.SetData(DataFormats.UnicodeText, false, new MemoryStream(Encoding.Unicode.GetBytes("área\0")));
        var copiaStream = MYGEspecificacionesPegado.Capturar(streams);
        exige(copiaStream.Rtf == fuente.Rtf && copiaStream.Texto == "área",
            "Capturar el portapapeles debe decodificar streams RTF/texto Unicode y quitar el terminador nulo.");

        var texto = new DataObject(); texto.SetData(DataFormats.UnicodeText, false, "Sólo texto");
        using var dialogo = new MYGEspecificacionesPegadoForm(MYGEspecificacionesPegado.Capturar(texto));
        exige(dialogo.Formatos.Items.Cast<string>().SequenceEqual(new[] { "Pegar", "Texto con Formato (RTF)", "Formato HTML", "Texto sin formato" }),
            "Pegado Especial debe mostrar las cuatro opciones de la captura en su orden.");
        dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Rtf;
        exige(!((Button)dialogo.AcceptButton).Enabled, "Aceptar debe estar deshabilitado si falta el formato RTF elegido.");
        dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Html;
        exige(!((Button)dialogo.AcceptButton).Enabled, "Aceptar debe estar deshabilitado si falta el formato HTML elegido.");
        dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Texto;
        exige(((Button)dialogo.AcceptButton).Enabled, "Texto sin formato debe estar disponible cuando el portapapeles contiene texto.");
        var vacio = MYGEspecificacionesPegado.Capturar(null);
        exige(!Enum.GetValues<MYGFormatoPegado>().Any(vacio.Disponible) &&
            MYGEspecificacionesPegado.Preparar(vacio, MYGFormatoPegado.Automatico) == null,
            "Un portapapeles vacío no debe producir contenido ni anunciar formatos disponibles.");
    }

    private static void VerificarOrtografia(Action<bool, string> exige)
    {
        using var documento = new RichTextBox { Font = new Font("Arial", 14), Text = "Correcto hormigonx y hormigonx final", Dock = DockStyle.Fill };
        using var formulario = new Form { ClientSize = new Size(700, 250) };
        formulario.Controls.Add(documento); formulario.Show(); Application.DoEvents();
        documento.Select(9, 9); documento.SelectionFont = new Font("Arial", 14, FontStyle.Bold);
        documento.SelectionColor = Color.DarkGreen;
        documento.Select(documento.Text.IndexOf("final", StringComparison.Ordinal), 5);
        documento.SelectionFont = new Font("Courier New", 12, FontStyle.Italic);
        documento.ClearUndo(); documento.Select(2, 3);
        int cambiosTexto = 0, altasDiccionario = 0;
        documento.TextChanged += (_, _) => cambiosTexto++;
        using var corrector = new MYGEspecificacionesOrtografia(documento, BuscarErrores,
            _ => new[] { "hormigón", "hormigón", "hormigon" }, _ => altasDiccionario++);
        corrector.ComprobarAhora();
        exige(corrector.RevisionCompleta && corrector.Errores.Count == 2 && corrector.ObtenerError(9)?.Palabra == "hormigonx" &&
            corrector.ObtenerError(18) == null && corrector.ObtenerError(-1) == null,
            "La revisión debe localizar cada aparición y respetar los límites de las palabras.");
        exige(corrector.Sugerencias(corrector.Errores[0]).SequenceEqual(new[] { "hormigón", "hormigon" }),
            "Las sugerencias ortográficas deben conservar su orden sin duplicarlas.");

        string rtf = documento.Rtf; int inicio = documento.SelectionStart, longitud = documento.SelectionLength;
        bool deshacer = documento.CanUndo; using var imagen = new Bitmap(documento.Width, documento.Height);
        using (var dibujo = Graphics.FromImage(imagen))
        {
            dibujo.Clear(Color.White); corrector.Pintar(dibujo, documento.ClientRectangle);
        }
        bool hayRojo = false;
        for (int y = 0; y < imagen.Height && !hayRojo; y++)
            for (int x = 0; x < imagen.Width && !hayRojo; x++)
            {
                Color color = imagen.GetPixel(x, y);
                hayRojo = color.R > 150 && color.G < 100 && color.B < 110;
            }
        exige(hayRojo, "Los errores deben dibujarse con un subrayado rojo visible.");
        exige(documento.Rtf == rtf && documento.SelectionStart == inicio && documento.SelectionLength == longitud &&
            documento.CanUndo == deshacer && cambiosTexto == 0,
            "Pintar la ortografía no debe cambiar RTF, selección, Deshacer ni emitir un cambio del texto.");

        corrector.Ignorar(corrector.Errores[0]);
        exige(corrector.Errores.Count == 1 && corrector.Errores[0].Inicio == 21 && documento.Rtf == rtf && cambiosTexto == 0,
            "Ignorar debe retirar sólo la aparición elegida sin modificar el documento.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        exige(corrector.Errores.Count == 2, "Cargar otra partida debe volver a revisar las apariciones ignoradas.");
        corrector.IgnorarTodo(corrector.Errores[0]);
        exige(corrector.Errores.Count == 0 && documento.Rtf == rtf && cambiosTexto == 0,
            "Ignorar todo debe retirar ambas marcas sin tocar RTF ni emitir cambios.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        corrector.AgregarAlDiccionario(corrector.Errores[0]);
        exige(altasDiccionario == 1 && corrector.Errores.Count == 0 && documento.Rtf == rtf && cambiosTexto == 0,
            "Agregar al diccionario debe usar el proveedor una vez y retirar las marcas sin editar la especificación.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        var anterior = corrector.Errores[0]; corrector.Corregir(anterior, "hormigón");
        exige(documento.Text == "Correcto hormigón y hormigonx final" && cambiosTexto == 1,
            "Corregir debe reemplazar sólo la aparición elegida del error.");
        documento.Select(9, 8);
        exige(documento.SelectionFont?.Bold == true && documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "Una sugerencia debe conservar la negrita y el color de la palabra corregida.");
        documento.Select(documento.Text.IndexOf("final", StringComparison.Ordinal), 5);
        exige(documento.SelectionFont?.Italic == true && documento.SelectionFont.Name == "Courier New",
            "Corregir una palabra no debe homogeneizar el formato del resto de la especificación.");
        rtf = documento.Rtf; corrector.Corregir(anterior, "reemplazo obsoleto");
        exige(documento.Rtf == rtf && cambiosTexto == 1, "Una sugerencia obsoleta no debe reemplazar texto que ya cambió.");
        corrector.ComprobarAhora(); documento.ReadOnly = true;
        corrector.Corregir(corrector.Errores[0], "hormigón");
        exige(documento.Rtf == rtf && cambiosTexto == 1, "El corrector debe respetar los documentos de sólo lectura.");
        formulario.Close();
    }

    private static void VerificarEditor(Action<bool, string> exige)
    {
        // Las pruebas usan un proveedor determinista: no dependen de los
        // diccionarios personales ni de los idiomas instalados en Windows.
        int antes = 0, cambios = 0;
        using var documento = new RichTextBox { Font = new Font("Arial", 11), DetectUrls = false };
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "Partida de prueba", () => "und", () => "01", comprobarOrtografia: BuscarErrores,
            sugerirOrtografia: _ => new[] { "hormigón" });
        using var formulario = new Form { ClientSize = new Size(950, 740) };
        formulario.Controls.Add(editor); formulario.Show(); Application.DoEvents();
        editor.Cargar("contexto-A", "", "Correcto hormigonx y hormigonx");
        documento.Focus(); Application.DoEvents();
        var corrector = (MYGEspecificacionesOrtografia)typeof(MYGEspecificacionesEditor)
            .GetField("ortografia", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        corrector.ComprobarAhora();
        var menu = documento.ContextMenuStrip;
        var papel = Controles(editor).Single(x => x.Name == "espec_papel");
        exige(menu != null && ReferenceEquals(papel.ContextMenuStrip, menu),
            "La hoja y el texto deben compartir el menú contextual de la especificación.");
        var originales = new[] { "Cortar", "Copiar", "Pegar", "Aumentar Sangría", "Disminuir Sangría", "Fuente", "Párrafo", "Lista Enumerada", "Marcador...", "Hipervínculo...", "Nuevo comentario" };
        documento.Select(0, 0); AbrirMenu(documento, new Point(2, 2));
        exige(menu.Items.OfType<ToolStripMenuItem>().Select(x => x.Text).SequenceEqual(originales),
            "El clic derecho en texto correcto debe ofrecer todas las herramientas de la segunda captura.");
        exige(!Opcion(menu, "Cortar").Enabled && !Opcion(menu, "Copiar").Enabled,
            "Cortar y Copiar deben estar deshabilitados si no hay texto seleccionado.");
        menu.Close();
        documento.Select(0, 8); AbrirMenu(documento, documento.GetPositionFromCharIndex(1));
        exige(documento.SelectionStart == 0 && documento.SelectionLength == 8 &&
            Opcion(menu, "Cortar").Enabled && Opcion(menu, "Copiar").Enabled,
            "El clic derecho dentro de una selección debe conservarla y habilitar Cortar/Copiar.");
        menu.Close(); documento.ReadOnly = true;
        AbrirMenu(documento, documento.GetPositionFromCharIndex(1));
        exige(!Opcion(menu, "Cortar").Enabled && Opcion(menu, "Copiar").Enabled &&
            menu.Items.OfType<ToolStripMenuItem>().Where(x => x.Text != "Copiar").All(x => !x.Enabled),
            "El menú de sólo lectura debe permitir copiar y bloquear comandos que editan el documento.");
        menu.Close(); documento.ReadOnly = false;

        documento.Select(9, 9); documento.SelectionFont = new Font("Arial", 13, FontStyle.Bold);
        documento.SelectionColor = Color.DarkGreen;
        documento.Select(9, 0);
        int antesInicial = antes, cambiosInicial = cambios; string rtf = editor.DocumentoRtf;
        AbrirMenu(documento, documento.GetPositionFromCharIndex(10));
        var opcionesOrtografia = menu.Items.OfType<ToolStripMenuItem>().Select(x => x.Text).ToArray();
        exige(opcionesOrtografia.Take(5).SequenceEqual(new[] { "hormigón", "Ignorar", "Ignorar todo", "Agregar al Diccionario", "Comprobar ortografía" }) &&
            opcionesOrtografia.Skip(5).SequenceEqual(originales),
            "El clic derecho sobre un error debe anteponer sugerencias y las opciones ortográficas de la tercera captura.");
        Opcion(menu, "Ignorar").PerformClick(); menu.Close();
        exige(corrector.Errores.Count == 1 && editor.DocumentoRtf == rtf && antes == antesInicial && cambios == cambiosInicial,
            "Ignorar desde el menú no debe guardar la partida ni agregar historial.");
        AbrirMenu(papel, new Point(3, 3));
        exige(menu.Items.OfType<ToolStripMenuItem>().Select(x => x.Text).SequenceEqual(originales),
            "El clic derecho en el margen de la hoja no debe mostrar sugerencias del cursor anterior.");
        menu.Close();
        AbrirMenu(documento, documento.GetPositionFromCharIndex(22));
        Opcion(menu, "Ignorar todo").PerformClick(); menu.Close();
        exige(corrector.Errores.Count == 0 && editor.DocumentoRtf == rtf && antes == antesInicial && cambios == cambiosInicial,
            "Ignorar todo desde el menú debe retirar las marcas sin generar una modificación del presupuesto.");
        corrector.ReiniciarDocumento(); corrector.ComprobarAhora();
        AbrirMenu(documento, documento.GetPositionFromCharIndex(10));
        Opcion(menu, "hormigón").PerformClick(); menu.Close();
        exige(documento.Text == "Correcto hormigón y hormigonx" && antes == antesInicial + 1 && cambios == cambiosInicial + 1,
            "Aceptar una sugerencia contextual debe corregir una palabra y registrar una sola modificación.");
        documento.Select(9, 8);
        exige(documento.SelectionFont?.Bold == true && documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "La corrección contextual debe conservar el formato de la palabra reemplazada.");
        VerificarCancelacionPegado(editor, documento, () => (antes, cambios), exige);
        VerificarAnotacionesPartida(editor, documento, () => (antes, cambios), exige);
        formulario.Close();
    }

    private static void VerificarAnotaciones(Action<bool, string> exige)
    {
        using var documento = new RichTextBox { Text = "Concreto armado conforme al plano" };
        int operaciones = 0;
        using var anotaciones = new MYGEspecificacionesAnotaciones(documento, null, accion => { operaciones++; accion(); });
        documento.Select(9, 6); string rtfSinAnotaciones = documento.Rtf;
        anotaciones.AgregarMarcador("Armadura_01"); anotaciones.AgregarComentario("Verificar diámetro y posición de las barras.");
        exige(operaciones == 2 && documento.Rtf == rtfSinAnotaciones && anotaciones.Elementos.Count == 2,
            "Marcadores y comentarios deben guardar metadatos sin insertar texto ni homogeneizar el formato del documento.");
        var marcador = anotaciones.Elementos.Single(x => x.Tipo == "marcador");
        var comentario = anotaciones.Elementos.Single(x => x.Tipo == "comentario");
        exige(marcador.Inicio == 9 && marcador.Longitud == 6 && comentario.Ancla == "armado",
            "Las anotaciones deben conservar la selección que identifica el texto comentado.");
        string guardado = anotaciones.Guardar(documento.Rtf);
        using var copia = new RichTextBox { Rtf = guardado };
        using var recuperadas = new MYGEspecificacionesAnotaciones(copia, null, accion => accion());
        recuperadas.Leer(guardado);
        exige(copia.Text == documento.Text && recuperadas.Elementos.Count == 2 &&
            recuperadas.Elementos.Single(x => x.Tipo == "comentario").Texto == comentario.Texto &&
            recuperadas.Elementos.Single(x => x.Tipo == "marcador").Id == marcador.Id &&
            recuperadas.Elementos.All(x => x.Inicio == 9 && x.Longitud == 6),
            "El RTF guardado debe recuperar textos Unicode, identificadores y rangos de comentarios/marcadores.");
        string guardadoOtraVez = anotaciones.Guardar(guardado);
        exige(guardadoOtraVez == guardado,
            "Guardar anotaciones dos veces no debe duplicar sus metadatos en el RTF.");

        documento.ClearUndo(); documento.Select(0, 0); documento.SelectedText = "Inicio: ";
        exige(anotaciones.Elementos.All(x => x.Inicio == 17 && x.Longitud == 6),
            "Insertar texto antes de una anotación debe desplazar su rango sin cambiar su longitud.");
        documento.Undo();
        exige(anotaciones.Elementos.All(x => x.Inicio == 9 && x.Longitud == 6),
            "Deshacer el prefijo debe recuperar las posiciones originales de las anotaciones.");
        documento.ClearUndo(); documento.SelectAll(); documento.SelectedText = "";
        exige(anotaciones.Elementos.All(x => x.Inicio == 0 && x.Longitud == 0),
            "Borrar el texto comentado debe colapsar sus rangos sin perder los comentarios.");
        documento.Undo();
        exige(documento.Text == "Concreto armado conforme al plano" &&
            anotaciones.Elementos.All(x => x.Inicio == 9 && x.Longitud == 6),
            "Deshacer el borrado debe recuperar también la selección completa de los comentarios/marcadores.");
        documento.Redo();
        exige(documento.TextLength == 0 && anotaciones.Elementos.All(x => x.Inicio == 0 && x.Longitud == 0),
            "Rehacer el borrado debe volver a colapsar los rangos de las anotaciones.");
        anotaciones.Eliminar(comentario); documento.Undo();
        exige(anotaciones.Elementos.All(x => x.Tipo != "comentario"),
            "Deshacer texto no debe resucitar un comentario que se eliminó explícitamente.");

        documento.Select(9, 6); int antes = operaciones;
        anotaciones.InsertarHipervinculo("Armadura", "https://example.com/planos?tipo=armado");
        exige(operaciones == antes + 1 && documento.Text == "Concreto Armadura conforme al plano" &&
            documento.Rtf.Contains("HYPERLINK", StringComparison.Ordinal) &&
            anotaciones.Elementos.Single(x => x.Tipo == "hipervinculo").Direccion == "https://example.com/planos?tipo=armado",
            "Insertar un hipervínculo debe crear un campo RTF y conservar el texto alrededor del enlace.");
        var vinculo = anotaciones.Elementos.Single(x => x.Tipo == "hipervinculo");
        documento.ClearUndo(); anotaciones.Guardar(documento.Rtf);
        anotaciones.InsertarHipervinculo("Armadura", "https://example.com/planos?tipo=revisado", vinculo.Inicio, vinculo.Longitud, vinculo);
        anotaciones.Guardar(documento.Rtf);
        exige(documento.Text == "Concreto Armadura conforme al plano" && documento.CanUndo &&
            vinculo.Direccion == "https://example.com/planos?tipo=revisado",
            "Editar únicamente el destino debe guardar un campo nuevo sin cambiar la etiqueta del hipervínculo.");
        documento.Undo(); anotaciones.Guardar(documento.Rtf);
        exige(vinculo.Direccion == "https://example.com/planos?tipo=armado" &&
            documento.Rtf.Contains("tipo=armado", StringComparison.Ordinal),
            "Deshacer un destino con etiqueta idéntica debe sincronizar el campo RTF y la dirección de sus metadatos.");
        documento.Redo(); anotaciones.Guardar(documento.Rtf);
        exige(vinculo.Direccion == "https://example.com/planos?tipo=revisado" &&
            documento.Rtf.Contains("tipo=revisado", StringComparison.Ordinal),
            "Rehacer el cambio de destino debe recuperar también la dirección persistida del hipervínculo.");
        antes = operaciones; string anterior = documento.Rtf; bool rechazo = false;
        try { anotaciones.InsertarHipervinculo("Archivo", "javascript:alert(1)"); }
        catch (ArgumentException) { rechazo = true; }
        exige(rechazo && operaciones == antes && documento.Rtf == anterior,
            "Un destino de hipervínculo no admitido debe rechazarse antes de modificar el documento o el historial.");

        documento.Select(0, 8); anotaciones.AgregarComentario("Control adicional");
        using var exportacion = new RichTextBox { Rtf = documento.Rtf };
        anterior = documento.Rtf;
        anotaciones.AñadirComentariosParaExportacion(exportacion);
        exige(exportacion.Text.Contains("COMENTARIOS DE LA ESPECIFICACIÓN") && exportacion.Text.Contains("Control adicional") &&
            documento.Rtf == anterior,
            "Exportar los comentarios debe agregarlos a la copia de salida y conservar el documento editable.");

        using var largo = new RichTextBox { Text = "Antes " + new string('x', 2300) + " después" };
        using var anotacionesLargas = new MYGEspecificacionesAnotaciones(largo, null, accion => accion());
        largo.Select(6, 2300); anotacionesLargas.AgregarComentario("Selección extensa");
        string rtfLargo = anotacionesLargas.Guardar(largo.Rtf); anotacionesLargas.Leer(rtfLargo);
        exige(anotacionesLargas.Elementos.Single().Longitud == 2300 && anotacionesLargas.Elementos.Single().Ancla.Length == 2000,
            "Recuperar comentarios extensos debe conservar su rango completo aunque el texto de referencia esté limitado.");
    }

    private static void VerificarAnotacionesPartida(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int antes, int cambios)> estado, Action<bool, string> exige)
    {
        var anotaciones = (MYGEspecificacionesAnotaciones)typeof(MYGEspecificacionesEditor)
            .GetField("anotaciones", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        documento.Focus(); documento.Select(0, 8); Application.DoEvents();
        var inicial = estado();
        anotaciones.AgregarMarcador("Descripcion"); anotaciones.AgregarComentario("Comentario persistente de la partida A");
        var despues = estado(); string rtf = editor.DocumentoRtf, texto = documento.Text;
        exige(despues.antes == inicial.antes + 2 && despues.cambios == inicial.cambios + 2,
            "Agregar marcador y comentario a la partida debe registrar una modificación por cada comando.");
        editor.Cargar("contexto-B", "", "Otra especificación");
        exige(anotaciones.Elementos.Count == 0 && estado() == despues,
            "Cambiar de partida debe limpiar sus anotaciones sin generar historial ni guardar la especificación abandonada.");
        editor.Cargar("contexto-A", rtf, texto);
        exige(anotaciones.Elementos.Count == 2 && anotaciones.Elementos.Single(x => x.Tipo == "comentario").Texto ==
            "Comentario persistente de la partida A" && editor.DocumentoRtf == rtf && estado() == despues,
            "Volver a una partida debe recuperar sus comentarios y marcadores del RTF sin volver a guardarlos.");
        documento.Select(2, 3); bool deshacer = documento.CanUndo;
        editor.Cargar("contexto-A", rtf, texto);
        exige(documento.SelectionStart == 2 && documento.SelectionLength == 3 && documento.CanUndo == deshacer &&
            anotaciones.Elementos.Count == 2 && estado() == despues,
            "Refrescar la misma partida debe conservar la selección, el historial y las anotaciones.");
    }

    private static void VerificarCancelacionPegado(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int antes, int cambios)> estado, Action<bool, string> exige)
    {
        IDataObject previo = Clipboard.GetDataObject();
        try
        {
            Clipboard.SetText("Contenido que no debe insertarse");
            documento.Select(2, 4); documento.Focus(); Application.DoEvents();
            var inicial = estado(); string rtf = editor.DocumentoRtf;
            bool deshacer = documento.CanUndo; int inicio = documento.SelectionStart, longitud = documento.SelectionLength;
            bool mostrado = false; Exception fallo = null;
            var plazo = Stopwatch.StartNew();
            using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
            temporizador.Tick += (_, _) =>
            {
                if (plazo.Elapsed > TimeSpan.FromSeconds(10))
                {
                    Console.Error.WriteLine("Pegado Especial quedó bloqueado en un diálogo inesperado.");
                    Environment.Exit(1);
                }
                var dialogo = Application.OpenForms.OfType<MYGEspecificacionesPegadoForm>().FirstOrDefault();
                if (dialogo == null || mostrado) return;
                mostrado = true;
                try
                {
                    dialogo.Formatos.SelectedIndex = (int)MYGFormatoPegado.Texto;
                    ((Button)dialogo.CancelButton).PerformClick();
                }
                catch (Exception ex) { fallo = ex; dialogo.Close(); }
            };
            var especial = Controles(editor).OfType<ToolStrip>().SelectMany(x => x.Items.OfType<ToolStripButton>())
                .Single(x => x.Text == "Pegado especial");
            temporizador.Start(); especial.PerformClick(); temporizador.Stop(); Application.DoEvents();
            exige(mostrado && fallo == null, fallo?.Message ?? "El botón Pegado especial debe abrir el selector modal de formatos.");
            exige(editor.DocumentoRtf == rtf && documento.SelectionStart == inicio && documento.SelectionLength == longitud &&
                documento.CanUndo == deshacer && estado() == inicial,
                "Cancelar Pegado Especial debe conservar texto, formato, selección, Deshacer y callbacks del presupuesto.");
        }
        finally
        {
            if (previo != null) Clipboard.SetDataObject(previo, true);
            else Clipboard.Clear();
        }
    }

    private static IReadOnlyList<MYGErrorOrtografico> BuscarErrores(string texto)
    {
        var errores = new List<MYGErrorOrtografico>();
        for (int desde = 0; desde < texto.Length;)
        {
            int inicio = texto.IndexOf("hormigonx", desde, StringComparison.Ordinal);
            if (inicio < 0) break;
            errores.Add(new(inicio, 9, "hormigonx")); desde = inicio + 9;
        }
        return errores;
    }

    private static ToolStripMenuItem Opcion(ContextMenuStrip menu, string texto) =>
        menu.Items.OfType<ToolStripMenuItem>().Single(x => x.Text == texto);

    private static void AbrirMenu(Control destino, Point punto)
    {
        // Los mensajes reales ejercitan RichEdit y el filtro nativo: invocar
        // OnMouseDown o Show directamente no detecta un cursor movido por Windows.
        SendMessage(destino.Handle, 0x0204, new IntPtr(2), Empaquetar(punto));
        CompletarClicDerecho(destino, punto);
    }

    private static void CompletarClicDerecho(Control destino, Point punto)
    {
        SendMessage(destino.Handle, 0x0205, IntPtr.Zero, Empaquetar(punto)); // WM_RBUTTONUP.
        Application.DoEvents();
    }

    private static void AbrirMenuTeclado(Control destino)
    {
        SendMessage(destino.Handle, 0x007B, destino.Handle, new IntPtr(-1)); // WM_CONTEXTMENU por teclado.
        Application.DoEvents();
    }

    private static IntPtr Empaquetar(Point punto) => new(unchecked((punto.Y << 16) | (punto.X & 0xffff)));

    private static Point PuntoCaracter(RichTextBox documento, int indice)
    {
        Point inicio = documento.GetPositionFromCharIndex(indice);
        Point fin = documento.GetPositionFromCharIndex(indice + 1);
        return new(inicio.X + Math.Max(1, (fin.X - inicio.X) / 2), inicio.Y + Math.Max(1, documento.Font.Height / 2));
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
