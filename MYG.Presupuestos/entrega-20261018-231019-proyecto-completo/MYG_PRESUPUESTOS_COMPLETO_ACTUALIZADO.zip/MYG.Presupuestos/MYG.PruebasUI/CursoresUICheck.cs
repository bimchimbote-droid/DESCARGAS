using System;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MYG_2027;

internal static class CursoresUICheck
{
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        Point ratonOriginal = Cursor.Position;
        try
        {
            using var formulario = new Form { ClientSize = new Size(760, 460) };
            using var barra = new ToolStrip { Dock = DockStyle.Top };
            var herramienta = new ToolStripButton("Guardar");
            var separador = new ToolStripSeparator();
            var inactiva = new ToolStripButton("Inactiva") { Enabled = false };
            var menu = new ToolStripDropDownButton("Opciones");
            var opcion = new ToolStripMenuItem("Aplicar");
            var entrada = new ToolStripTextBox();
            menu.DropDownItems.Add(opcion);
            barra.Items.AddRange(new ToolStripItem[] { herramienta, separador, inactiva, menu, entrada });
            using var pestanas = new TabControl { Dock = DockStyle.Fill, Alignment = TabAlignment.Bottom };
            using var pagina = new TabPage("Presupuesto");
            using var otra = new TabPage("Metrado");
            using var texto = new TextBox { Location = new Point(30, 30), Width = 200 };
            using var boton = new Button { Text = "Aceptar", Location = new Point(30, 80) };
            pagina.Controls.Add(texto); pagina.Controls.Add(boton);
            pestanas.TabPages.AddRange(new[] { pagina, otra });
            formulario.Controls.Add(pestanas); formulario.Controls.Add(barra);
            formulario.Show(); formulario.Activate();
            int clics = 0, comandos = 0;
            boton.Click += (_, _) => clics++;
            herramienta.Click += (_, _) => comandos++;
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                MYG2027_TemaComercial.Aplicar(formulario);
                MYG2027_TemaComercial.Aplicar(formulario);
                Application.DoEvents();
                exige(boton.Cursor == Cursors.Hand, "Los botones habilitados deben mostrar la mano en ambos temas.");
                MostrarCursor(boton, new Point(10, 10));
                exige(Cursor.Current == Cursors.Hand, "Windows debe presentar la mano al pasar por un botón.");
                boton.Enabled = false;
                exige(boton.Cursor != Cursors.Hand, "Un botón deshabilitado no debe anunciar una acción disponible.");
                boton.Enabled = true;
                exige(boton.Cursor == Cursors.Hand, "Rehabilitar el botón debe restaurar la mano.");

                MostrarCursor(barra, Centro(herramienta.Bounds));
                exige(Cursor.Current == Cursors.Hand, "Los iconos habilitados de las barras deben mostrar la mano.");
                MostrarCursor(barra, Centro(menu.Bounds));
                exige(Cursor.Current == Cursors.Hand, "Los botones desplegables deben mostrar la mano.");
                MostrarCursor(barra, Centro(separador.Bounds));
                exige(Cursor.Current != Cursors.Hand, "Los separadores de herramientas deben conservar la flecha.");
                MostrarCursor(barra, Centro(inactiva.Bounds));
                exige(Cursor.Current != Cursors.Hand, "Las herramientas deshabilitadas no deben mostrar la mano.");
                MostrarCursor(entrada.TextBox, new Point(8, entrada.TextBox.Height / 2));
                exige(Cursor.Current == Cursors.IBeam, "Los campos alojados en una barra deben conservar el cursor de escritura.");

                MostrarCursor(pestanas, Centro(pestanas.GetTabRect(1)));
                exige(Cursor.Current == Cursors.Hand && pestanas.SelectedTab == pagina,
                    "Pasar por una pestaña debe mostrar la mano sin seleccionarla.");
                MostrarCursor(texto, new Point(8, texto.Height / 2));
                exige(Cursor.Current == Cursors.IBeam && pestanas.Cursor != Cursors.Hand && barra.Cursor != Cursors.Hand,
                    "La mano de pestañas y herramientas no debe heredarse al contenido editable.");
                menu.ShowDropDown(); Application.DoEvents();
                MostrarCursor(menu.DropDown, Centro(opcion.Bounds));
                exige(Cursor.Current == Cursors.Hand, "Las opciones habilitadas de los menús deben mostrar la mano.");
                menu.HideDropDown();
                boton.PerformClick(); herramienta.PerformClick();
            }
            exige(clics == 2 && comandos == 2,
                "Reaplicar cursores y temas no debe duplicar los comandos ni sus eventos de clic.");
            using var dinamico = new Button { Text = "Nuevo", Location = new Point(150, 80) };
            pagina.Controls.Add(dinamico);
            exige(dinamico.Cursor == Cursors.Hand, "Los botones añadidos después de preparar el formulario también deben usar la mano.");
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
            Cursor.Position = ratonOriginal;
        }
    }

    private static Point Centro(Rectangle r) => new(r.Left + r.Width / 2, r.Top + r.Height / 2);

    private static void MostrarCursor(Control control, Point punto)
    {
        Cursor.Position = control.PointToScreen(punto);
        Enviar(control.Handle, 0x0200, IntPtr.Zero, new IntPtr((punto.Y << 16) | (punto.X & 0xffff)));
        Application.DoEvents();
        Enviar(control.Handle, 0x0020, control.Handle, new IntPtr((0x0200 << 16) | 1));
    }
}
