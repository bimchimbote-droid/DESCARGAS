using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using MYG_2027;

// Contrato de las escrituras de recurso usadas por el adaptador COM.
// Se ejecuta también en Linux sin Office ni WinForms.
internal static class ProjectRecursoConfiguracionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarUnidades(exige);
        VerificarTipos(exige);
        VerificarCampoLiteral(exige);
        VerificarUnidadVisibleAlternativa(exige);
        VerificarErrores(exige);
    }

    private static void VerificarUnidades(Action<bool, string> exige)
    {
        // El setter simulado acepta unidades literales; no presupone que
        // Project necesite o permita prefijos inventados.
        foreach (string unidad in new[] { "mes", "kg", "m³", "p²", "kg/m³", "%mo", "und", "bol", "área", "日本語", "", null, " m³ " })
        {
            var datos = Recurso(unidad);
            var original = datos with { };
            var simulado = new RecursoSimulado();
            string aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir, simulado.EscribirCampo);
            exige((string)simulado.Valores["MaterialLabel"] == (unidad ?? "") &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }) &&
                simulado.Operaciones.Count(o => o == "set:MaterialLabel") == 1 &&
                simulado.Operaciones.Contains("get:MaterialLabel") && datos == original && aviso == null &&
                !simulado.Operaciones.Any(o => o.StartsWith("setfield:", StringComparison.Ordinal)),
                "MaterialLabel debe conservar y verificar la unidad exacta de la base, incluidos Unicode, símbolos, espacios y vacío, sin modificar el DTO.");
            exige(simulado.Valores.Keys.All(p => p is "Type" or "Code" or "Group" or "MaterialLabel" or "StandardRate") &&
                (string)simulado.Valores["Code"] == datos.Codigo && (string)simulado.Valores["Group"] == datos.Grupo,
                "Exportar una unidad no debe añadir Text1/Notes decorativos ni alterar código, grupo o nombre del origen.");
        }

        var culturaOriginal = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
            var datos = Recurso("%mo") with { Tarifa = 1234.56789m };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            exige(simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                (string)simulado.Valores["MaterialLabel"] == "%mo",
                "El recurso porcentual material debe recibir %mo literal y una tarifa numérica independiente de la cultura.");
        }
        finally { CultureInfo.CurrentCulture = culturaOriginal; }
    }

    private static void VerificarTipos(Action<bool, string> exige)
    {
        foreach (int tipo in new[] { 1, 2 })
        {
            var datos = Recurso(tipo == 1 ? "hh" : "%mo") with { Tipo = tipo };
            var original = datos with { };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Calendario específico", simulado.Leer, simulado.Escribir);
            exige(Convert.ToInt32(simulado.Valores["Type"], CultureInfo.InvariantCulture) == (tipo == 1 ? 0 : 2) &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }) &&
                !simulado.Valores.ContainsKey("MaterialLabel") && datos == original,
                "Los recursos de trabajo y el tipo de costo explícito legado deben confirmar su tipo COM sin recibir una etiqueta material.");
            exige(tipo == 1
                    ? simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                      (string)simulado.Valores["BaseCalendar"] == "Calendario específico"
                    : !simulado.Valores.ContainsKey("StandardRate") && !simulado.Valores.ContainsKey("BaseCalendar"),
                "El trabajo conserva tarifa y calendario, y el costo explícito legado no debe convertirse en trabajo o material.");
        }
    }

    private static void VerificarCampoLiteral(Action<bool, string> exige)
    {
        foreach (int codigo in new[] { RecursoSimulado.Error1101, RecursoSimulado.ErrorArgumento })
        {
            var datos = Recurso("mes");
            var simulado = new RecursoSimulado
            {
                FalloEtiqueta = new TargetInvocationException(new COMException("Argumento rechazado", codigo))
            };
            string aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir, simulado.EscribirCampo);
            exige(aviso == null && (string)simulado.Valores["MaterialLabel"] == "mes" &&
                simulado.Operaciones.Count(o => o == "setfield:205521195") == 1 &&
                !simulado.Valores.ContainsKey("Text1") && !simulado.Valores.ContainsKey("Notes") &&
                simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                (int)simulado.Valores["Type"] == 1,
                "SetField(pjResourceMaterialLabel) debe recuperar mes literal tras 1101/E_INVALIDARG envuelto por reflexión, conservando tipo/tarifa y sin prefijos ni campo alternativo.");
        }
        var cambiado = new RecursoSimulado { ReemplazoEtiqueta = "meses" };
        string resultado = MYGConfiguracionRecursoProject.Configurar(Recurso("mes"), "Obra", cambiado.Leer, cambiado.Escribir, cambiado.EscribirCampo);
        exige(resultado == null && (string)cambiado.Valores["MaterialLabel"] == "mes" &&
            cambiado.Operaciones.Contains("setfield:205521195"),
            "Una etiqueta normalizada al escribir la propiedad debe recuperarse literalmente mediante la API de campo y verificarse.");
    }

    private static void VerificarUnidadVisibleAlternativa(Action<bool, string> exige)
    {
        var datos = Recurso("mes");
        var original = datos with { };
        var simulado = new RecursoSimulado
        {
            FalloEtiqueta = new COMException("MaterialLabel temporal", RecursoSimulado.Error1101),
            FalloCampo = new TargetInvocationException(new COMException("SetField temporal", RecursoSimulado.ErrorArgumento))
        };
        string aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir, simulado.EscribirCampo);
        exige((string)simulado.Valores["MaterialLabel"] == "" && (string)simulado.Valores["Text1"] == "mes" &&
            (int)simulado.Valores["Type"] == 1 && simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
            aviso != null && aviso.Contains("mes", StringComparison.Ordinal) && aviso.Contains(datos.Nombre, StringComparison.Ordinal) &&
            aviso.Contains("Texto1", StringComparison.Ordinal) && aviso.Contains("cantidad, tarifa y costo conservados", StringComparison.Ordinal) &&
            datos == original && simulado.Operaciones.Count(o => o == "set:Type") == 1 &&
            simulado.Valores.Keys.All(p => p is "Type" or "Code" or "Group" or "MaterialLabel" or "Text1" or "StandardRate"),
            "Si Project rechaza mes por ambas APIs, debe mantener material y tarifa, dejar vacía la etiqueta, conservar mes en Texto1 y avisar claramente sin inventar unidades ni escribir cantidades/costos.");

        var normalizado = new RecursoSimulado { ReemplazoEtiqueta = "meses", ReemplazoCampo = "meses" };
        aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", normalizado.Leer, normalizado.Escribir, normalizado.EscribirCampo);
        exige(aviso != null && (string)normalizado.Valores["MaterialLabel"] == "" && (string)normalizado.Valores["Text1"] == "mes",
            "Si ambas APIs cambian la unidad en vez de rechazarla, la alternativa visible debe conservar la unidad exacta y explicarlo.");
    }

    private static void VerificarErrores(Action<bool, string> exige)
    {
        var datos = Recurso("mes");
        var tipoRechazado = new RecursoSimulado { TipoLeido = 0 };
        Exception fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoRechazado.Leer, tipoRechazado.Escribir));
        exige(fallo is InvalidOperationException && tipoRechazado.Operaciones.SequenceEqual(new[] { "set:Type", "get:Type" }),
            "Si Project no conserva el tipo material, la configuración debe abortar antes de escribir etiquetas o tarifas.");

        var rechazoEtiqueta = new COMException("Fallo COM ajeno a validación", unchecked((int)0x80004005));
        var etiquetaConError = new RecursoSimulado { FalloEtiqueta = rechazoEtiqueta };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", etiquetaConError.Leer, etiquetaConError.Escribir, etiquetaConError.EscribirCampo));
        exige(ReferenceEquals(fallo, rechazoEtiqueta) &&
            etiquetaConError.Operaciones.Count(o => o == "set:MaterialLabel") == 1 &&
            etiquetaConError.Operaciones.Last() == "set:MaterialLabel" && !etiquetaConError.Valores.ContainsKey("StandardRate") &&
            !etiquetaConError.Operaciones.Any(o => o.StartsWith("setfield:", StringComparison.Ordinal)),
            "Un fallo COM ajeno a validación debe propagarse con HRESULT/causa, sin ocultarlo usando campos alternativos ni continuar con tarifas.");

        var campoConError = new RecursoSimulado { FalloEtiqueta = new COMException("Etiqueta inválida", RecursoSimulado.Error1101), FalloCampo = rechazoEtiqueta };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", campoConError.Leer, campoConError.Escribir, campoConError.EscribirCampo));
        exige(ReferenceEquals(fallo, rechazoEtiqueta) && !campoConError.Valores.ContainsKey("Text1"),
            "Un fallo COM real en SetField debe propagarse sin disfrazarlo como rechazo de etiqueta ni guardar una exportación incompleta.");

        var textoConError = new RecursoSimulado
        {
            FalloEtiqueta = new COMException("Etiqueta inválida", RecursoSimulado.Error1101),
            FalloCampo = new COMException("Campo inválido", RecursoSimulado.Error1101), FalloTexto = rechazoEtiqueta
        };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", textoConError.Leer, textoConError.Escribir, textoConError.EscribirCampo));
        exige(ReferenceEquals(fallo, rechazoEtiqueta) && !textoConError.Valores.ContainsKey("StandardRate"),
            "Un error al conservar la unidad en Texto1 debe propagarse y nunca producir un aviso de éxito falso.");

        var textoCambiado = new RecursoSimulado
        {
            FalloEtiqueta = new COMException("Etiqueta inválida", RecursoSimulado.Error1101),
            FalloCampo = new COMException("Campo inválido", RecursoSimulado.Error1101), ReemplazoTexto = "m"
        };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", textoCambiado.Leer, textoCambiado.Escribir, textoCambiado.EscribirCampo));
        exige(fallo is InvalidOperationException && fallo.Message.Contains("Texto1", StringComparison.Ordinal) && !textoCambiado.Valores.ContainsKey("StandardRate"),
            "La alternativa visible debe verificar la unidad exacta; una cadena cambiada o truncada no puede pasar como exportación conservada.");

        var errorTipo = new COMException("Fallo COM al asignar Type", unchecked((int)0x80020009));
        var tipoConError = new RecursoSimulado { FalloTipo = errorTipo };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoConError.Leer, tipoConError.Escribir));
        exige(ReferenceEquals(fallo, errorTipo) && tipoConError.Operaciones.SequenceEqual(new[] { "set:Type" }),
            "Un error COM al establecer el tipo debe propagarse sin continuar con otros datos.");

        var errorTarifa = new COMException("Error COM específico en StandardRate", unchecked((int)0x80020009));
        var tarifaConError = new RecursoSimulado { FalloTarifa = errorTarifa };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tarifaConError.Leer, tarifaConError.Escribir));
        exige(ReferenceEquals(fallo, errorTarifa) && tarifaConError.Operaciones.Count(o => o == "set:StandardRate") == 1 &&
            tarifaConError.Operaciones.Last() == "set:StandardRate" && (string)tarifaConError.Valores["MaterialLabel"] == "mes",
            "Un error de tarifa debe conservar su excepción sin reintentos que lo oculten como un problema de unidades.");

        var desconocido = new RecursoSimulado();
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos with { Tipo = 37 }, "Obra", desconocido.Leer, desconocido.Escribir));
        exige(fallo is InvalidDataException && desconocido.Operaciones.Count == 0,
            "Un tipo de recurso desconocido debe rechazarse antes de cualquier escritura COM.");
    }

    private static MYGRecursoExportacionProject Recurso(string unidad) =>
        new(27, 0, "Recurso de prueba", "130001", "Materiales", unidad, 22.07m);

    private static Exception Capturar(Action accion)
    {
        try { accion(); return null; }
        catch (Exception ex) { return ex; }
    }

    private sealed class RecursoSimulado
    {
        internal const int Error1101 = unchecked((int)0x800A044D), ErrorArgumento = unchecked((int)0x80070057);
        internal readonly Dictionary<string, object> Valores = new(StringComparer.Ordinal);
        internal readonly List<string> Operaciones = new();
        internal int? TipoLeido;
        internal string ReemplazoEtiqueta, ReemplazoCampo, ReemplazoTexto;
        internal Exception FalloTipo, FalloEtiqueta, FalloCampo, FalloTarifa, FalloTexto;
        private bool tipoConfirmado;

        internal object Leer(string propiedad)
        {
            Operaciones.Add("get:" + propiedad);
            object valor = propiedad == "Type" && TipoLeido.HasValue ? TipoLeido.Value : Valores[propiedad];
            if (propiedad == "Type") tipoConfirmado = Convert.ToInt32(valor, CultureInfo.InvariantCulture) ==
                Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture);
            return valor;
        }

        internal void Escribir(string propiedad, object valor)
        {
            Operaciones.Add("set:" + propiedad);
            if (propiedad == "Type")
            {
                tipoConfirmado = false;
                if (FalloTipo != null) throw FalloTipo;
            }
            if (propiedad == "MaterialLabel")
            {
                if (!tipoConfirmado || Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture) != 1)
                    throw new InvalidOperationException("MaterialLabel requiere Type material confirmado.");
                if ((string)valor != "" && FalloEtiqueta != null) throw FalloEtiqueta;
                if ((string)valor != "" && ReemplazoEtiqueta != null) valor = ReemplazoEtiqueta;
            }
            if (propiedad == "Text1" && FalloTexto != null) throw FalloTexto;
            if (propiedad == "Text1" && ReemplazoTexto != null) valor = ReemplazoTexto;
            if (propiedad == "StandardRate" && FalloTarifa != null) throw FalloTarifa;
            Valores[propiedad] = valor;
        }

        internal void EscribirCampo(int campo, string valor)
        {
            Operaciones.Add("setfield:" + campo.ToString(CultureInfo.InvariantCulture));
            if (campo != MYGConfiguracionRecursoProject.CampoEtiquetaMaterial) throw new Exception("Se intentó escribir un campo distinto de MaterialLabel.");
            if (FalloCampo != null) throw FalloCampo;
            Valores["MaterialLabel"] = ReemplazoCampo ?? valor;
        }
    }
}
