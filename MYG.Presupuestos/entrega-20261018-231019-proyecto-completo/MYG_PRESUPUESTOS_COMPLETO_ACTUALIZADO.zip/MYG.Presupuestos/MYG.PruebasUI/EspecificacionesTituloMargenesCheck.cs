using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesTituloMargenesCheck
{
    private const int WmLButtonDown = 0x0201, WmMouseMove = 0x0200, WmLButtonUp = 0x0202;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarTituloActual(exige);
        VerificarArrastreMargenes(exige);
    }

    private static void VerificarTituloActual(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Proyecto de prueba", "PRESUPUESTO");
        var presupuesto = proyecto.Presupuestos.Single();
        var original = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "PARTIDA", Unidad = "und",
            TipoPropuesta = "PARTIDA", Posicion = 1
        };
        presupuesto.Items.Add(original);
        int guardados = 0, antes = 0, cambios = 0, ediciones = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antes++, () => cambios++,
            _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (nodo, columna, valor) =>
        {
            if (string.IsNullOrWhiteSpace(valor)) throw new InvalidOperationException("El nombre no puede estar vacío.");
            var identidad = ((ItemPresupuestoDelphin)nodo).Id;
            var vigente = presupuesto.Items.Single(i => i.Id == identidad);
            if (columna == "DESC") vigente.Descripcion = valor;
            else if (columna == "ITEM") vigente.Item = valor;
            else if (columna == "UND") vigente.Unidad = valor;
            ediciones++;
        }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1400, 840) };
        formulario.Controls.Add(panel);
        formulario.Show();
        panel.Refrescar();
        panel.SeleccionarEstructura(original);
        panel.MostrarEspecificacion();
        Application.DoEvents();
        var documento = Controles(panel).OfType<RichTextBox>().Single(c => c.Name == "espec_documento");
        var insertar = Controles(panel).OfType<Button>().Single(c => c.Name == "espec_insertar_titulo");
        var estructura = Controles(panel).OfType<DataGridView>().Single(c =>
            c.Columns.Contains("EXP") && c.Columns.Contains("ITEM"));
        exige(insertar.Enabled && estructura.Rows.Cast<DataGridViewRow>().Any(r => ReferenceEquals(r.Tag, original)),
            "La prueba del título debe comenzar con una partida seleccionada en el panel real.");

        // El historial y las transacciones sustituyen los objetos conservando
        // sus Id. Se mantienen deliberadamente los Tags de las filas anteriores.
        presupuesto = MYGProyectoStorage.Copia(presupuesto);
        proyecto.Presupuestos[0] = presupuesto;
        var actual = presupuesto.Items.Single(i => i.Id == original.Id);
        actual.Descripcion = "PARTIDA2";
        actual.Unidad = "m³";
        int antesInicial = antes, cambiosInicial = cambios;
        insertar.PerformClick();
        Application.DoEvents();
        exige(documento.Text.Contains("01.01  PARTIDA2", StringComparison.Ordinal) &&
            documento.Text.Contains("unidad de medida: m³", StringComparison.Ordinal),
            "Insertar título debe leer nombre, código y unidad del modelo vigente sin guardar ni refrescar sus filas.");
        exige(actual.Costos.EspecificacionTexto == documento.Text &&
            actual.Costos.EspecificacionRtf.Contains(@"\rtf", StringComparison.Ordinal) &&
            string.IsNullOrEmpty(original.Costos.EspecificacionTexto) && string.IsNullOrEmpty(original.Costos.EspecificacionRtf),
            "La especificación insertada debe escribirse en la instancia vigente y conservar intacta la copia reemplazada.");
        exige(guardados == 0 && antes == antesInicial + 1 && cambios == cambiosInicial + 1,
            "Insertar el título actualizado debe crear una sola modificación en memoria y no guardar el proyecto a disco.");
        VerificarCabeceras(panel, "PARTIDA2", exige);

        // PerformClick no provoca la validación automática de un clic físico.
        // El comando debe confirmar por sí mismo la edición pendiente de DESC.
        var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r =>
            r.Tag is ItemPresupuestoDelphin i && i.Id == actual.Id);
        estructura.CurrentCell = fila.Cells["DESC"];
        exige(estructura.BeginEdit(true) && estructura.EditingControl is TextBox,
            "Debe ser posible editar el nombre de la partida en la celda real de la estructura.");
        ((TextBox)estructura.EditingControl).Text = "PARTIDA3";
        exige(estructura.IsCurrentCellInEditMode && actual.Descripcion == "PARTIDA2",
            "El caso pendiente debe conservar el nombre anterior en el modelo hasta ejecutar Insertar título.");
        documento.Select(documento.TextLength, 0);
        int inicioSegundoTitulo = documento.TextLength;
        int edicionesIniciales = ediciones;
        insertar.PerformClick();
        Application.DoEvents();
        exige(!estructura.IsCurrentCellInEditMode && ediciones == edicionesIniciales + 1 && actual.Descripcion == "PARTIDA3",
            "Insertar título debe confirmar exactamente una vez el texto que todavía está en edición.");
        exige(documento.Text.Substring(inicioSegundoTitulo).Contains("01.01  PARTIDA3", StringComparison.Ordinal) &&
            actual.Costos.EspecificacionTexto == documento.Text && guardados == 0,
            "El título y el RTF deben utilizar el nombre recién editado sin exigir Guardar antes del comando.");
        VerificarCabeceras(panel, "PARTIDA3", exige);

        // La confirmación programática también se usa antes de guardar y no
        // puede depender de que el usuario cambie de foco con el ratón.
        EditarNombre("PARTIDA12145");
        edicionesIniciales = ediciones;
        panel.FinalizarEdicion();
        exige(actual.Descripcion == "PARTIDA12145" && !estructura.IsCurrentCellInEditMode &&
            ediciones == edicionesIniciales + 1,
            "FinalizarEdicion debe aplicar el nombre visible al modelo exactamente una vez antes de EndEdit.");
        panel.FinalizarEdicion();
        exige(ediciones == edicionesIniciales + 1,
            "Confirmar de nuevo una celda ya cerrada no debe duplicar la edición ni el historial.");
        documento.Select(documento.TextLength, 0);
        int inicioTercerTitulo = documento.TextLength;
        insertar.PerformClick();
        Application.DoEvents();
        exige(documento.Text.Substring(inicioTercerTitulo).StartsWith("01.01  PARTIDA12145", StringComparison.Ordinal) &&
            actual.Costos.EspecificacionTexto == documento.Text && guardados == 0,
            "El título debe coincidir con PARTIDA12145 recién confirmado y guardarse sólo en memoria.");
        VerificarCabeceras(panel, "PARTIDA12145", exige);

        EditarNombre("   ");
        bool rechazado = false;
        edicionesIniciales = ediciones;
        try { panel.FinalizarEdicion(); }
        catch (InvalidOperationException) { rechazado = true; }
        exige(rechazado && estructura.IsCurrentCellInEditMode && actual.Descripcion == "PARTIDA12145" &&
            ediciones == edicionesIniciales && !string.IsNullOrEmpty(estructura.CurrentRow.ErrorText),
            "La confirmación programática debe rechazar una descripción inválida y conservar la edición para corregirla.");
        estructura.CancelEdit();
        EditarNombre("NOMBRE CANCELADO");
        estructura.CancelEdit();
        panel.FinalizarEdicion();
        exige(actual.Descripcion == "PARTIDA12145" && ediciones == edicionesIniciales,
            "Cancelar la celda debe conservar el nombre anterior sin cambios ni historial.");
        formulario.Close();

        void EditarNombre(string nombre)
        {
            var filaActual = estructura.Rows.Cast<DataGridViewRow>().Single(r =>
                r.Tag is ItemPresupuestoDelphin i && i.Id == actual.Id);
            estructura.CurrentCell = filaActual.Cells["DESC"];
            exige(estructura.BeginEdit(true) && estructura.EditingControl is TextBox,
                "La regresión debe editar una celda real de descripción.");
            ((TextBox)estructura.EditingControl).Text = nombre;
        }
    }

    private static void VerificarCabeceras(MYGPanelPresupuesto panel, string nombre, Action<bool, string> exige)
    {
        var etiquetas = Controles(panel).OfType<Label>().ToArray();
        foreach (string cabecera in new[] { "espec_cabecera", "acu_cabecera" })
            exige(etiquetas.Any(e => e.Parent.Name == cabecera && e.Text == nombre) &&
                etiquetas.Any(e => e.Parent.Name == cabecera && e.Text == "01.01"),
                "Las cabeceras de cada sección deben mostrar la partida vigente después de insertar o confirmar la edición.");
    }

    private static void VerificarArrastreMargenes(Action<bool, string> exige)
    {
        int antes = 0, cambios = 0;
        using var documento = new MYGEspecificacionesRichTextBox { DetectUrls = false, HideSelection = false };
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "PARTIDA", () => "und", () => "01.01");
        using var formulario = new Form { ClientSize = new Size(980, 780) };
        formulario.Controls.Add(editor);
        formulario.Show();
        var pagina = new MYGPaginaEspecificacion
        {
            MargenIzquierdoMm = 20, MargenDerechoMm = 20, MargenSuperiorMm = 20, MargenInferiorMm = 20
        };
        editor.Cargar("margenes-regla", MYGEspecificacionesPagina.Guardar(CrearRtf(), pagina), "");
        var controles = Controles(editor).ToArray();
        var regla = controles.OfType<MYGEspecificacionesRegla>().Single(c => c.Name == "espec_regla_horizontal");
        var vertical = controles.OfType<MYGEspecificacionesRegla>().Single(c => c.Name == "espec_regla_vertical");
        var lienzo = controles.OfType<Panel>().Single(c => c.Name == "espec_lienzo");
        var papel = controles.OfType<Panel>().Single(c => c.Name == "espec_papel");
        var zoom = controles.OfType<NumericUpDown>().Single(c => c.Name == "espec_zoom");
        zoom.Value = 100;
        Application.DoEvents();
        documento.Focus();
        documento.Select(1, 6);
        Application.DoEvents();
        exige(regla.EdicionHabilitada && vertical.EdicionHabilitada,
            "Las dos reglas deben permitir editar los márgenes de una partida en vista de impresión.");

        var estado = new EstadoContenido(documento);
        string rtfInicial = editor.DocumentoRtf;
        Rectangle limitesIniciales = documento.Bounds;
        int anchoInicial = documento.RightMargin;
        Point textoInicial = papel.PointToClient(documento.PointToScreen(documento.GetPositionFromCharIndex(0)));
        var contadores = (Antes: antes, Cambios: cambios);
        Point pin = Pin(editor, regla, papel, inicio: true, vertical: false);
        Point destino = DesplazarPin(pin, editor, 10, vertical: false);
        Presionar(regla, pin);
        exige(regla.Arrastrando && regla.Capture, "El pin izquierdo debe iniciar un arrastre nativo con captura de ratón.");
        Mover(regla, destino);
        exige(Cerca(editor.PaginaDocumento.MargenIzquierdoMm, 30) && documento.Left > limitesIniciales.Left &&
            documento.Width < limitesIniciales.Width && documento.RightMargin < anchoInicial,
            "Arrastrar el margen izquierdo debe mover el área del texto y reducir su ancho de ajuste durante la vista previa.");
        Point textoDesplazado = papel.PointToClient(documento.PointToScreen(documento.GetPositionFromCharIndex(0)));
        exige(textoDesplazado.X > textoInicial.X && (antes, cambios) == contadores,
            "El texto debe acompañar al pin en tiempo real sin generar callbacks durante la vista previa.");
        estado.Verificar(documento, exige, "vista previa del margen izquierdo");
        Soltar(regla, destino);
        exige(!regla.Arrastrando && !regla.Capture && (antes, cambios) == (contadores.Antes + 1, contadores.Cambios + 1),
            "Soltar el pin debe liberar la captura y registrar una única modificación del diseño.");
        estado.Verificar(documento, exige, "margen izquierdo confirmado");
        string rtfIzquierdo = editor.DocumentoRtf;
        exige(Cerca(MYGEspecificacionesPagina.Leer(rtfIzquierdo).MargenIzquierdoMm, 30),
            "El margen arrastrado debe persistirse en los metadatos del RTF de la partida.");
        Pulsar(editor, "Deshacer diseño");
        exige(editor.DocumentoRtf == rtfInicial && documento.Bounds == limitesIniciales,
            "Una sola acción Deshacer diseño debe recuperar todo el arrastre y sus límites originales.");
        Pulsar(editor, "Rehacer diseño");
        exige(editor.DocumentoRtf == rtfIzquierdo && (antes, cambios) == (contadores.Antes + 3, contadores.Cambios + 3),
            "Rehacer diseño debe recuperar el margen confirmado con un único callback por acción de historial.");

        // Escape cancela una vista previa real del margen superior; el historial
        // anterior y el cuerpo RTF deben seguir disponibles sin una edición nueva.
        lienzo.AutoScrollPosition = Point.Empty;
        Application.DoEvents();
        Rectangle antesCancelar = documento.Bounds;
        contadores = (antes, cambios);
        pin = Pin(editor, vertical, papel, inicio: true, vertical: true);
        destino = DesplazarPin(pin, editor, 12, vertical: true);
        Presionar(vertical, pin);
        Mover(vertical, destino);
        exige(vertical.Arrastrando && documento.Top > antesCancelar.Top && documento.Height < antesCancelar.Height,
            "La vista previa del pin superior debe desplazar también el texto verticalmente.");
        Enviar(documento.Handle, 0x0100, new IntPtr((int)Keys.Escape), IntPtr.Zero);
        Application.DoEvents();
        exige(!vertical.Arrastrando && editor.DocumentoRtf == rtfIzquierdo && documento.Bounds == antesCancelar &&
            (antes, cambios) == contadores,
            "Escape desde el documento debe cancelar el arrastre, recuperar los márgenes y no registrar modificaciones.");
        estado.Verificar(documento, exige, "cancelación del margen superior");

        // Perder captura también debe cancelar, por ejemplo al cambiar de ventana.
        pin = Pin(editor, vertical, papel, inicio: true, vertical: true);
        Presionar(vertical, pin);
        Mover(vertical, DesplazarPin(pin, editor, 5, vertical: true));
        vertical.Capture = false;
        Application.DoEvents();
        exige(!vertical.Arrastrando && editor.DocumentoRtf == rtfIzquierdo && (antes, cambios) == contadores,
            "Perder la captura durante el arrastre debe restaurar la página sin callbacks ni estados parciales.");

        pin = Pin(editor, vertical, papel, inicio: true, vertical: true);
        destino = DesplazarPin(pin, editor, 12, vertical: true);
        Presionar(vertical, pin);
        Mover(vertical, destino);
        Soltar(vertical, destino);
        exige(Cerca(editor.PaginaDocumento.MargenSuperiorMm, 32) && documento.Top > antesCancelar.Top &&
            (antes, cambios) == (contadores.Antes + 1, contadores.Cambios + 1),
            "Confirmar el pin superior debe guardar el margen y mover el cuerpo una sola vez.");
        estado.Verificar(documento, exige, "margen superior confirmado");
        string rtfDosMargenes = editor.DocumentoRtf;

        contadores = (antes, cambios);
        pin = Pin(editor, regla, papel, inicio: true, vertical: false);
        Presionar(regla, pin);
        Soltar(regla, pin);
        exige(editor.DocumentoRtf == rtfDosMargenes && (antes, cambios) == contadores,
            "Presionar y soltar un pin sin moverlo debe conservar el documento y el historial.");

        string texto = documento.Text;
        editor.Cargar("otra-partida", "", "Otra especificación");
        editor.Cargar("margenes-recargados", rtfDosMargenes, texto);
        exige(Cerca(editor.PaginaDocumento.MargenIzquierdoMm, 30) &&
            Cerca(editor.PaginaDocumento.MargenSuperiorMm, 32) && documento.Text == texto,
            "Volver a cargar la partida debe recuperar sus márgenes arrastrados y el contenido completo del RTF.");
        VerificarEstilos(documento, exige);

        // Los pines derecho e inferior deben funcionar con otra orientación,
        // zoom y la página recortada por desplazamiento en los dos ejes.
        pagina = editor.PaginaDocumento;
        pagina.Horizontal = true;
        editor.Cargar("margenes-horizontal", MYGEspecificacionesPagina.Guardar(editor.DocumentoRtf, pagina), texto);
        zoom.Value = 150;
        lienzo.AutoScrollPosition = new Point(int.MaxValue / 2, int.MaxValue / 2);
        Application.DoEvents();
        exige(lienzo.AutoScrollPosition.X < 0 && lienzo.AutoScrollPosition.Y < 0 &&
            Math.Abs(documento.ZoomFactor - 1.5f) < .01f,
            "La prueba de los pines finales debe desplazar realmente la hoja en ambos ejes con zoom del 150 %. ");
        documento.Select(1, 6);
        estado = new EstadoContenido(documento);
        limitesIniciales = documento.Bounds;
        anchoInicial = documento.RightMargin;
        contadores = (antes, cambios);
        pin = Pin(editor, regla, papel, inicio: false, vertical: false);
        exige(regla.ClientRectangle.Contains(pin), "El pin derecho debe estar visible tras desplazar la página ampliada.");
        destino = DesplazarPin(pin, editor, -15, vertical: false);
        Presionar(regla, pin);
        Mover(regla, destino);
        exige(Cerca(editor.PaginaDocumento.MargenDerechoMm, 35) && documento.Width < limitesIniciales.Width &&
            documento.RightMargin < anchoInicial && documento.Left == limitesIniciales.Left && (antes, cambios) == contadores,
            "El pin derecho debe reducir el ancho de texto y el ajuste de líneas con zoom y scroll, conservando el margen izquierdo.");
        estado.Verificar(documento, exige, "pin derecho con zoom y scroll");
        Soltar(regla, destino);
        exige((antes, cambios) == (contadores.Antes + 1, contadores.Cambios + 1),
            "El pin derecho ampliado debe confirmar una sola modificación.");

        limitesIniciales = documento.Bounds;
        contadores = (antes, cambios);
        pin = Pin(editor, vertical, papel, inicio: false, vertical: true);
        exige(vertical.ClientRectangle.Contains(pin), "El pin inferior debe estar visible tras desplazar la página ampliada.");
        destino = DesplazarPin(pin, editor, -15, vertical: true);
        Presionar(vertical, pin);
        Mover(vertical, destino);
        exige(Cerca(editor.PaginaDocumento.MargenInferiorMm, 35) && documento.Height < limitesIniciales.Height &&
            documento.Top == limitesIniciales.Top && (antes, cambios) == contadores,
            "El pin inferior debe reducir la altura disponible durante la vista previa sin cambiar el margen superior.");
        estado.Verificar(documento, exige, "pin inferior con zoom y scroll");
        Soltar(vertical, destino);
        exige((antes, cambios) == (contadores.Antes + 1, contadores.Cambios + 1),
            "El pin inferior ampliado debe confirmar una sola modificación.");
        string rtfFinal = editor.DocumentoRtf;
        editor.Cargar("margenes-finales", rtfFinal, texto);
        pagina = editor.PaginaDocumento;
        exige(pagina.Horizontal && Cerca(pagina.MargenIzquierdoMm, 30) && Cerca(pagina.MargenDerechoMm, 35) &&
            Cerca(pagina.MargenSuperiorMm, 32) && Cerca(pagina.MargenInferiorMm, 35) && documento.Text == texto,
            "Los cuatro márgenes, la orientación y el texto deben persistir juntos al recargar el RTF final.");
        VerificarEstilos(documento, exige);

        VerificarCancelacionesDuranteEdicion(editor, documento, regla, papel, lienzo, () => (antes, cambios), exige);
        VerificarLimiteYBloqueo(editor, documento, regla, vertical, papel, lienzo, () => (antes, cambios), exige);
        formulario.Close();
    }

    private static void VerificarCancelacionesDuranteEdicion(MYGEspecificacionesEditor editor, RichTextBox documento,
        MYGEspecificacionesRegla regla, Panel papel, Panel lienzo,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        string rtf = editor.DocumentoRtf, texto = documento.Text;
        var pagina = editor.PaginaDocumento;
        lienzo.AutoScrollPosition = Point.Empty;
        documento.Focus();
        documento.Select(documento.TextLength, 0);
        Application.DoEvents();
        var inicial = contadores();
        Point pin = Pin(editor, regla, papel, inicio: true, vertical: false);
        Point destino = DesplazarPin(pin, editor, 5, vertical: false);
        Presionar(regla, pin);
        Mover(regla, destino);
        exige(regla.Arrastrando && !MismosMargenes(editor.PaginaDocumento, pagina),
            "La edición durante un arrastre debe partir de una vista previa pendiente de confirmar.");
        editor.AplicarFormato(() => documento.SelectedText = "NOTA");
        exige(!regla.Arrastrando && !regla.Capture && MismosMargenes(editor.PaginaDocumento, pagina) &&
            documento.Text == texto + "NOTA" && contadores() == (inicial.Antes + 1, inicial.Cambios + 1),
            "Un comando de formato durante el arrastre debe cancelar su vista previa y guardar sólo la edición del texto.");
        Soltar(regla, destino);
        exige(MismosMargenes(editor.PaginaDocumento, pagina) && contadores() == (inicial.Antes + 1, inicial.Cambios + 1),
            "El botón soltado después de aplicar formato no debe confirmar un margen cancelado ni añadir otro callback.");

        editor.Cargar("margenes-cancelar-teclado", rtf, texto);
        lienzo.AutoScrollPosition = Point.Empty;
        documento.Focus();
        documento.Select(documento.TextLength, 0);
        Application.DoEvents();
        inicial = contadores();
        pin = Pin(editor, regla, papel, inicio: true, vertical: false);
        destino = DesplazarPin(pin, editor, 5, vertical: false);
        Presionar(regla, pin);
        Mover(regla, destino);
        Enviar(documento.Handle, 0x0100, new IntPtr((int)Keys.A), IntPtr.Zero);
        Application.DoEvents();
        exige(!regla.Arrastrando && MismosMargenes(editor.PaginaDocumento, pagina) && contadores() == inicial,
            "Comenzar a escribir durante el arrastre debe cancelar el margen pendiente antes de procesar la tecla.");
        Enviar(documento.Handle, 0x0102, new IntPtr('a'), IntPtr.Zero); // WM_CHAR.
        Application.DoEvents();
        exige(documento.Text == texto + "a" && MismosMargenes(editor.PaginaDocumento, pagina) &&
            contadores() == (inicial.Antes, inicial.Cambios + 1),
            "La tecla debe insertarse en el cursor conservado y persistir únicamente el texto con los márgenes anteriores.");

        editor.Cargar("margenes-cancelar-bloqueo", rtf, texto);
        lienzo.AutoScrollPosition = Point.Empty;
        Application.DoEvents();
        var contenido = new EstadoContenido(documento);
        Rectangle limites = documento.Bounds;
        inicial = contadores();
        pin = Pin(editor, regla, papel, inicio: true, vertical: false);
        destino = DesplazarPin(pin, editor, 5, vertical: false);
        Presionar(regla, pin);
        Mover(regla, destino);
        exige(regla.Arrastrando, "El caso de bloqueo debe mantener un arrastre activo antes de cambiar ReadOnly.");
        documento.ReadOnly = true;
        Soltar(regla, destino);
        exige(!regla.Arrastrando && !regla.Capture && MismosMargenes(editor.PaginaDocumento, pagina) &&
            documento.Bounds == limites && contadores() == inicial,
            "Bloquear el documento justo antes de soltar debe cancelar la vista previa sin guardar diseño ni callbacks.");
        contenido.Verificar(documento, exige, "bloqueo entre el último movimiento y soltar el pin");
        editor.Cargar("margenes-edicion-restaurada", rtf, texto);
    }

    private static bool MismosMargenes(MYGPaginaEspecificacion a, MYGPaginaEspecificacion b) =>
        a.MargenIzquierdoMm == b.MargenIzquierdoMm && a.MargenDerechoMm == b.MargenDerechoMm &&
        a.MargenSuperiorMm == b.MargenSuperiorMm && a.MargenInferiorMm == b.MargenInferiorMm &&
        a.Horizontal == b.Horizontal && a.AnchoMm == b.AnchoMm && a.AltoMm == b.AltoMm;

    private static void VerificarLimiteYBloqueo(MYGEspecificacionesEditor editor, RichTextBox documento,
        MYGEspecificacionesRegla regla, MYGEspecificacionesRegla vertical, Panel papel, Panel lienzo,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        lienzo.AutoScrollPosition = Point.Empty;
        Application.DoEvents();
        Point pin = Pin(editor, regla, papel, inicio: true, vertical: false);
        Presionar(regla, pin);
        Point destino = DesplazarPin(pin, editor, 400, vertical: false);
        Mover(regla, destino);
        Soltar(regla, destino);
        var pagina = editor.PaginaDocumento;
        decimal ancho = pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm;
        exige(pagina.MargenIzquierdoMm >= 0 && pagina.MargenDerechoMm >= 0 &&
            ancho - pagina.MargenIzquierdoMm - pagina.MargenDerechoMm >= 9.9m,
            "Los pines no deben cruzarse ni dejar una franja de texto menor de diez milímetros.");
        MYGEspecificacionesPagina.Validar(pagina);

        string rtf = editor.DocumentoRtf;
        var inicial = contadores();
        Pulsar(editor, "Vista simple");
        exige(!regla.EdicionHabilitada && !vertical.EdicionHabilitada && editor.DocumentoRtf == rtf && contadores() == inicial,
            "La vista simple debe deshabilitar los pines de página sin cambiar los márgenes ni el RTF.");
        Pulsar(editor, "Distribución de impresión");
        exige(regla.EdicionHabilitada && vertical.EdicionHabilitada,
            "Volver a la vista de impresión debe habilitar de nuevo los pines de una partida editable.");
        editor.Cargar("", "", "");
        exige(documento.ReadOnly && !regla.EdicionHabilitada && !vertical.EdicionHabilitada,
            "Sin partida activa los márgenes deben permanecer deshabilitados como el propio documento.");
        inicial = contadores();
        rtf = editor.DocumentoRtf;
        pin = Pin(editor, regla, papel, inicio: true, vertical: false);
        Presionar(regla, pin);
        Mover(regla, DesplazarPin(pin, editor, 10, vertical: false));
        Soltar(regla, pin);
        exige(!regla.Arrastrando && editor.DocumentoRtf == rtf && contadores() == inicial,
            "Arrastrar una regla deshabilitada no debe editar la página ni emitir callbacks.");
    }

    private static string CrearRtf()
    {
        var rtf = new StringBuilder(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}{\f1 Courier New;}}{\colortbl;\red0\green100\blue0;}\f0\fs26\cf1\b\ul Cabecera\b0\ulnone\cf0\par\f1\fs20\i Cuerpo conservado\i0\par\f0\fs22 ");
        for (int i = 0; i < 12; i++)
            rtf.Append("Linea ").Append(i).Append(": texto extenso para comprobar el ajuste de palabras dentro de los margenes de la pagina. ")
                .Append("Este contenido debe conservar su formato al mover todos los pines.\\par ");
        return rtf.Append('}').ToString();
    }

    private static void VerificarEstilos(RichTextBox documento, Action<bool, string> exige)
    {
        documento.Select(0, "Cabecera".Length);
        using var cabecera = documento.SelectionFont;
        exige(cabecera != null && cabecera.Bold && cabecera.Underline && Math.Abs(cabecera.SizeInPoints - 13) < .01 &&
            documento.SelectionColor.ToArgb() == Color.FromArgb(0, 100, 0).ToArgb(),
            "Arrastrar y recargar los márgenes debe conservar negrita, subrayado, tamaño y color del encabezado.");
        documento.Select(documento.Text.IndexOf("Cuerpo", StringComparison.Ordinal), "Cuerpo conservado".Length);
        using var cuerpo = documento.SelectionFont;
        exige(cuerpo != null && cuerpo.Name == "Courier New" && cuerpo.Italic && Math.Abs(cuerpo.SizeInPoints - 10) < .01,
            "Los márgenes deben conservar también la fuente y la cursiva de los fragmentos de cuerpo.");
    }

    private sealed class EstadoContenido
    {
        private readonly string texto, rtf;
        private readonly int inicio, longitud;
        private readonly bool undo, redo;
        internal EstadoContenido(RichTextBox documento)
        {
            texto = documento.Text; rtf = documento.Rtf;
            inicio = documento.SelectionStart; longitud = documento.SelectionLength;
            undo = documento.CanUndo; redo = documento.CanRedo;
        }
        internal void Verificar(RichTextBox documento, Action<bool, string> exige, string paso) =>
            exige(documento.Text == texto && documento.Rtf == rtf && documento.SelectionStart == inicio &&
                documento.SelectionLength == longitud && documento.CanUndo == undo && documento.CanRedo == redo,
                "Mover márgenes debe conservar contenido, estilos, selección y el historial nativo del texto: " + paso + ".");
    }

    private static bool Cerca(decimal actual, decimal esperado) => Math.Abs(actual - esperado) <= .25m;

    private static Point Pin(MYGEspecificacionesEditor editor, Control regla, Panel papel, bool inicio, bool vertical)
    {
        var pagina = editor.PaginaDocumento;
        float escala = editor.DeviceDpi * editor.Documento.ZoomFactor / 25.4f;
        Point origen = regla.PointToClient(papel.PointToScreen(Point.Empty));
        decimal longitud = vertical ? pagina.Horizontal ? pagina.AnchoMm : pagina.AltoMm
            : pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm;
        decimal posicion = vertical ? inicio ? pagina.MargenSuperiorMm : longitud - pagina.MargenInferiorMm
            : inicio ? pagina.MargenIzquierdoMm : longitud - pagina.MargenDerechoMm;
        return vertical ? new Point((int)(regla.Width * .65f), origen.Y + (int)Math.Round((float)posicion * escala))
            : new Point(origen.X + (int)Math.Round((float)posicion * escala), regla.Height / 2);
    }

    private static Point DesplazarPin(Point pin, MYGEspecificacionesEditor editor, float mm, bool vertical)
    {
        int delta = (int)Math.Round(mm * editor.DeviceDpi * editor.Documento.ZoomFactor / 25.4f);
        return vertical ? new Point(pin.X, pin.Y + delta) : new Point(pin.X + delta, pin.Y);
    }

    private static void Presionar(Control regla, Point punto)
    {
        Enviar(regla.Handle, WmLButtonDown, new IntPtr(1), Coordenadas(punto));
        Application.DoEvents();
    }
    private static void Mover(Control regla, Point punto)
    {
        Enviar(regla.Handle, WmMouseMove, new IntPtr(1), Coordenadas(punto));
        Application.DoEvents();
    }
    private static void Soltar(Control regla, Point punto)
    {
        Enviar(regla.Handle, WmLButtonUp, IntPtr.Zero, Coordenadas(punto));
        Application.DoEvents();
    }
    private static IntPtr Coordenadas(Point punto) => new(unchecked((punto.Y << 16) | (punto.X & 0xffff)));

    private static void Pulsar(MYGEspecificacionesEditor editor, string texto)
    {
        var boton = Herramientas(editor).Single(c => c.Name.Replace('\n', ' ') == "espec_" + texto);
        var propietario = boton;
        while (propietario.OwnerItem != null) propietario = propietario.OwnerItem;
        Control padre = propietario.Owner.Parent;
        while (padre != null && padre is not TabPage) padre = padre.Parent;
        if (padre is TabPage pagina && pagina.Parent is TabControl cinta) cinta.SelectedTab = pagina;
        boton.PerformClick();
        Application.DoEvents();
    }

    private static IEnumerable<ToolStripItem> Herramientas(Control control)
    {
        foreach (var barra in Controles(control).OfType<ToolStrip>())
            foreach (ToolStripItem item in barra.Items)
                foreach (var descendiente in Items(item)) yield return descendiente;
    }
    private static IEnumerable<ToolStripItem> Items(ToolStripItem item)
    {
        yield return item;
        if (item is ToolStripDropDownItem grupo)
            foreach (ToolStripItem hijo in grupo.DropDownItems)
                foreach (var descendiente in Items(hijo)) yield return descendiente;
    }
    private static IEnumerable<Control> Controles(Control control)
    {
        foreach (Control hijo in control.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
