using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG_2027;

internal static class FuenteResumenDialogoCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarEdicionYVistaPrevia(exige);
        VerificarCancelacionYRestablecer(exige);
    }

    private static void VerificarEdicionYVistaPrevia(Action<bool, string> exige)
    {
        using var original = new Font("Segoe UI", 9F, FontStyle.Bold);
        using var dialogo = new MYGFuenteResumenForm(original, Color.DarkBlue, Color.LightYellow);
        dialogo.Show(); Application.DoEvents();
        var aceptar = Buscar<Button>(dialogo, "aceptarFuenteResumen");
        var tamano = Buscar<TextBox>(dialogo, "tamanoFuenteResumen");
        var estilo = Buscar<ListBox>(dialogo, "estilosFuenteResumen");
        exige(dialogo.Text == "Fuente" && aceptar.Enabled && estilo.Items.Cast<string>().SequenceEqual(
            new[] { "Normal", "Cursiva", "Negrita", "Negrita Cursiva" }),
            "Fuente debe ofrecer la selección de familia, tamaño y los cuatro estilos de la referencia.");
        tamano.Text = "7.8"; estilo.SelectedIndex = 3;
        Buscar<CheckBox>(dialogo, "tachadoFuenteResumen").Checked = true;
        Buscar<CheckBox>(dialogo, "subrayadoFuenteResumen").Checked = true;
        var fuenteVista = (Font)typeof(MYGFuenteResumenForm).GetField("fuenteActual", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(dialogo);
        exige(aceptar.Enabled && Math.Abs(fuenteVista.SizeInPoints - 7.8F) < 0.001F && fuenteVista.Bold && fuenteVista.Italic &&
            fuenteVista.Strikeout && fuenteVista.Underline,
            "La vista previa debe actualizar el tamaño decimal y todos los efectos mientras se editan.");
        ElegirColor(Buscar<ComboBox>(dialogo, "colorTextoResumen"), "Rojo");
        ElegirColor(Buscar<ComboBox>(dialogo, "colorFondoResumen"), "Amarillo");
        var muestra = dialogo.Controls.Find("ejemploFuenteResumen", true).Single();
        using (var imagen = new Bitmap(muestra.Width, muestra.Height))
        {
            muestra.DrawToBitmap(imagen, muestra.ClientRectangle);
            exige(imagen.GetPixel(1, 1).ToArgb() == Color.Yellow.ToArgb(), "El ejemplo debe mostrar el fondo elegido en tiempo real.");
            MYG2027_TemaComercial.Alternar(false);
            try
            {
                muestra.DrawToBitmap(imagen, muestra.ClientRectangle);
                exige(imagen.GetPixel(1, 1).ToArgb() == Color.Yellow.ToArgb(),
                    "Cambiar el tema de la aplicación debe conservar los colores elegidos para la fila.");
            }
            finally { MYG2027_TemaComercial.Alternar(false); }
        }
        tamano.Text = "0";
        exige(!aceptar.Enabled, "Fuente debe impedir aceptar tamaños inválidos.");
        tamano.Text = "200";
        exige(aceptar.Enabled, "Fuente debe permitir el tamaño máximo de 200 puntos admitido por el documento.");
        tamano.Text = "201";
        exige(!aceptar.Enabled, "Fuente debe rechazar tamaños superiores al máximo de 200 puntos del documento.");
        tamano.Text = "7,8";
        aceptar.PerformClick();
        exige(dialogo.DialogResult == DialogResult.OK && dialogo.FuenteElegida != null &&
            Math.Abs(dialogo.FuenteElegida.SizeInPoints - 7.8F) < 0.001F && dialogo.FuenteElegida.Bold &&
            dialogo.FuenteElegida.Italic && dialogo.FuenteElegida.Strikeout && dialogo.FuenteElegida.Underline &&
            dialogo.ColorTexto.ToArgb() == Color.Red.ToArgb() && dialogo.ColorFondo.ToArgb() == Color.Yellow.ToArgb(),
            "Aceptar debe devolver fuente, efectos, tamaño decimal, color de texto y color de fondo.");
        exige(original.SizeInPoints == 9F && original.Style == FontStyle.Bold,
            "Editar el formato debe conservar la fuente recibida por el diálogo.");
        using var elegida = (Font)dialogo.FuenteElegida.Clone();
        dialogo.Dispose();
        exige(elegida.SizeInPoints > 0 && original.SizeInPoints == 9F,
            "La fuente clonada por el consumidor y la fuente original deben sobrevivir al cierre del diálogo.");
    }

    private static void VerificarCancelacionYRestablecer(Action<bool, string> exige)
    {
        using var original = new Font("Segoe UI", 11F, FontStyle.Italic | FontStyle.Underline);
        using var dialogo = new MYGFuenteResumenForm(original, Color.Navy, Color.Beige);
        dialogo.Show(); Application.DoEvents();
        Buscar<TextBox>(dialogo, "tamanoFuenteResumen").Text = "24";
        Buscar<ListBox>(dialogo, "estilosFuenteResumen").SelectedIndex = 2;
        Buscar<CheckBox>(dialogo, "tachadoFuenteResumen").Checked = true;
        ElegirColor(Buscar<ComboBox>(dialogo, "colorFondoResumen"), "Rojo");
        Buscar<Button>(dialogo, "restablecerFuenteResumen").PerformClick();
        var vista = (Font)typeof(MYGFuenteResumenForm).GetField("fuenteActual", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(dialogo);
        exige(vista.SizeInPoints == 11F && vista.Style == original.Style &&
            !Buscar<CheckBox>(dialogo, "tachadoFuenteResumen").Checked,
            "El botón circular debe restablecer la familia, tamaño y efectos iniciales.");
        Buscar<TextBox>(dialogo, "tamanoFuenteResumen").Text = "16";
        Buscar<Button>(dialogo, "cerrarFuenteResumen").PerformClick();
        exige(dialogo.DialogResult == DialogResult.Cancel && dialogo.FuenteElegida == null &&
            dialogo.ColorTexto.ToArgb() == Color.Navy.ToArgb() && dialogo.ColorFondo.ToArgb() == Color.Beige.ToArgb() &&
            original.SizeInPoints == 11F && original.Style == (FontStyle.Italic | FontStyle.Underline),
            "Cerrar debe descartar la edición y conservar el formato recibido sin entregar una fuente nueva.");
    }

    private static T Buscar<T>(Form formulario, string nombre) where T : Control =>
        (T)formulario.Controls.Find(nombre, true).Single();

    private static void ElegirColor(ComboBox selector, string nombre) => selector.SelectedIndex =
        selector.Items.Cast<object>().Select((opcion, indice) => (opcion, indice)).Single(o => o.opcion.ToString() == nombre).indice;
}
