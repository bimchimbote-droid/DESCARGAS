using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoSeleccionEncabezadosCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Selección de encabezados", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "CONCRETO",
            Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
        };
        partida.Costos.Hoja.Poner("A20", "Fila de referencia");
        partida.Costos.Hoja.Poner("I20", "Columna de referencia");
        presupuesto.Items.Add(partida);
        int anteriores = 0, cambios = 0, guardados = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
            _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1800, 1000) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        ((TabControl)pagina.Parent).SelectedTab = pagina;
        Application.DoEvents();
        var hoja = Campo<DataGridView>(panel, "hoja");
        string original = Estado(partida.Costos.Hoja);

        Arrastrar(hoja, Centro(hoja.GetCellDisplayRectangle(-1, 3, false)), Centro(hoja.GetCellDisplayRectangle(-1, 6, false)));
        exige(Filas(hoja, 3, 6) && !hoja.Capture,
            "Arrastrar los números 4 a 7 debe seleccionar cuatro filas completas y soltar la captura del ratón.");
        Arrastrar(hoja, Centro(hoja.GetCellDisplayRectangle(4, -1, false)), Centro(hoja.GetCellDisplayRectangle(2, -1, false)));
        exige(Columnas(hoja, 2, 4) && !hoja.Capture,
            "Arrastrar las letras E a C en sentido inverso debe seleccionar las tres columnas completas.");

        Point inicio = Centro(hoja.GetCellDisplayRectangle(-1, 3, false));
        Mouse(hoja, 0x0201, inicio, 1);
        Mouse(hoja, 0x0200, Centro(hoja.GetCellDisplayRectangle(-1, 8, false)), 1);
        Mouse(hoja, 0x0200, Centro(hoja.GetCellDisplayRectangle(-1, 5, false)), 1);
        Mouse(hoja, 0x0202, Centro(hoja.GetCellDisplayRectangle(-1, 5, false)));
        exige(Filas(hoja, 3, 5),
            "Volver hacia el inicio del arrastre debe contraer la selección y quitar las filas que quedan fuera del intervalo.");

        var seleccion = Seleccion(hoja);
        Anticlic(hoja, Centro(hoja.GetCellDisplayRectangle(-1, 4, false)));
        exige(seleccion.SetEquals(Seleccion(hoja)) && hoja.ContextMenuStrip.Visible,
            "El anticlic sobre una fila seleccionada debe abrir las herramientas y conservar todas las filas seleccionadas.");
        hoja.ContextMenuStrip.Close();
        Anticlic(hoja, Centro(hoja.GetCellDisplayRectangle(2, 4, false)));
        exige(seleccion.SetEquals(Seleccion(hoja)),
            "El anticlic dentro de las celdas de varias filas seleccionadas también debe conservar la selección completa.");
        hoja.ContextMenuStrip.Close();
        Anticlic(hoja, Centro(hoja.GetCellDisplayRectangle(-1, 9, false)));
        exige(Filas(hoja, 9, 9),
            "El anticlic sobre una fila ajena a la selección debe seleccionar esa fila completa antes de mostrar sus herramientas.");
        hoja.ContextMenuStrip.Close();

        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 3, true, false);
        exige(hoja.SelectedCells.Count == 2 * hoja.RowCount && hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.ColumnIndex is 1 or 3),
            "Ctrl más una letra debe añadir esa columna sin perder la columna seleccionada anteriormente.");
        seleccion = Seleccion(hoja);
        Anticlic(hoja, Centro(hoja.GetCellDisplayRectangle(3, -1, false)));
        exige(seleccion.SetEquals(Seleccion(hoja)),
            "El menú de una columna seleccionada debe conservar también selecciones de columnas no contiguas.");
        hoja.ContextMenuStrip.Close();
        ExigirRechazoSinCambios(panel, partida, "eliminar_columnas", "columnas contiguas", exige);
        Invocar(panel, "SeleccionarEncabezadoHoja", 3, -1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", 5, -1, true, false);
        ExigirRechazoSinCambios(panel, partida, "insertar_filas", "filas contiguas", exige);
        Invocar(panel, "SeleccionarEncabezadoHoja", 7, -1, false, true);
        exige(Filas(hoja, 5, 7), "Mayús más un encabezado debe seguir ampliando desde su ancla después de usar Ctrl.");

        inicio = Centro(hoja.GetCellDisplayRectangle(-1, 3, false));
        Mouse(hoja, 0x0201, inicio, 1);
        Mouse(hoja, 0x0200, Centro(hoja.GetCellDisplayRectangle(-1, 6, false)), 1);
        EnviarMensaje(hoja.Handle, 0x0100, new IntPtr((int)Keys.Escape), IntPtr.Zero);
        exige(!hoja.Capture && !Campo<bool>(panel, "arrastrandoEncabezadosHoja"),
            "Escape debe finalizar la selección por arrastre sin dejar captura ni una operación pendiente.");
        Mouse(hoja, 0x0201, inicio, 1); hoja.Capture = false;
        exige(!Campo<bool>(panel, "arrastrandoEncabezadosHoja"),
            "Perder la captura del ratón debe cancelar también el arrastre de encabezados.");
        var separador = hoja.GetCellDisplayRectangle(2, -1, false);
        exige(!(bool)Invocar(panel, "ProcesarRatonArrastreHoja", 0x0201, new Point(separador.Right - 1, separador.Top + separador.Height / 2)),
            "El separador de columnas debe conservar el ajuste de ancho nativo y no iniciar una selección de encabezados.");

        inicio = Centro(hoja.GetCellDisplayRectangle(-1, 8, false));
        int scrollAntes = hoja.FirstDisplayedScrollingRowIndex;
        Mouse(hoja, 0x0201, inicio, 1);
        var fuera = new Point(inicio.X, hoja.ClientSize.Height + 12);
        Mouse(hoja, 0x0200, fuera, 1);
        Invocar(panel, "DesplazarSeleccionEncabezadosHoja", null, EventArgs.Empty);
        Mouse(hoja, 0x0202, fuera);
        exige(hoja.FirstDisplayedScrollingRowIndex > scrollAntes && !hoja.Capture,
            "Arrastrar filas por debajo del área visible debe desplazar la hoja y ampliar la selección a las filas siguientes.");
        exige(Estado(partida.Costos.Hoja) == original && (anteriores, cambios, guardados) == (0, 0, 0),
            "Arrastres, selección múltiple, menús, desplazamiento y cancelación deben conservar datos, formatos e historial.");

        // Ejecutar las acciones reales del menú y comprobar sus límites sobre
        // datos de referencia fuera del encabezado y del total de la plantilla.
        hoja.FirstDisplayedScrollingRowIndex = 2;
        Invocar(panel, "SeleccionarEncabezadoHoja", 19, -1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", 21, -1, false, true);
        int filas = partida.Costos.Hoja.Filas;
        Opcion(hoja, "Insertar filas").PerformClick();
        exige(partida.Costos.Hoja.Filas == filas + 3 && Contenido(partida.Costos.Hoja, "A23") == "Fila de referencia",
            "Insertar filas desde el menú debe insertar exactamente las tres filas seleccionadas y desplazar los datos.");
        Invocar(panel, "SeleccionarEncabezadoHoja", 19, -1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", 21, -1, false, true);
        Opcion(hoja, "Eliminar filas").PerformClick();
        exige(partida.Costos.Hoja.Filas == filas && Contenido(partida.Costos.Hoja, "A20") == "Fila de referencia",
            "Eliminar las tres filas insertadas debe devolver los datos a sus filas originales.");
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 2, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 4, false, true);
        int columnas = partida.Costos.Hoja.Columnas;
        Opcion(hoja, "Insertar columnas").PerformClick();
        exige(partida.Costos.Hoja.Columnas == columnas + 3 && Contenido(partida.Costos.Hoja, "L20") == "Columna de referencia",
            "El menú debe permitir insertar exactamente las tres columnas seleccionadas.");
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 2, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 4, false, true);
        Opcion(hoja, "Eliminar columnas").PerformClick();
        exige(partida.Costos.Hoja.Columnas == columnas && Contenido(partida.Costos.Hoja, "I20") == "Columna de referencia" &&
            (anteriores, cambios, guardados) == (4, 4, 0),
            "Eliminar columnas debe respetar el intervalo seleccionado y cada acción estructural debe registrar un único cambio sin guardar.");
        VerificarDesplazamientoDelCuerpo(panel, hoja, partida, exige);
        formulario.Close();
    }

    private static void VerificarDesplazamientoDelCuerpo(MYGPanelPresupuesto panel, DataGridView hoja,
        ItemPresupuestoDelphin partida, Action<bool, string> exige)
    {
        partida.Costos.Hoja = MYGHojaMetrado.Crear();
        partida.Costos.Hoja.Poner("B3", "2"); partida.Costos.Hoja.Poner("C3", "3");
        partida.Costos.Hoja.Poner("A12", "Fila que sube");
        Invocar(panel, "CargarHoja");
        Invocar(panel, "SeleccionarEncabezadoHoja", 6, -1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", 10, -1, false, true);
        Opcion(hoja, "Eliminar filas").PerformClick();
        exige(partida.Costos.Hoja.CeldaTotal == "G11" && Convert.ToString(hoja[0, 6].Value) == "Fila que sube" &&
            Convert.ToString(hoja[0, 10].Value) == "Total:" &&
            Convert.ToString(hoja[6, 10].Value) == 6m.ToString("0.00"),
            "Eliminar las filas 7 a 11 desde su selección múltiple debe subir la fila 12 y mostrar en la fila 11 tanto Total como su resultado.");
        exige(PintaBordePlantilla(panel, hoja, 9, 6) && !PintaBordePlantilla(panel, hoja, 10, 6) &&
            !PintaBordePlantilla(panel, hoja, 11, 6) && !PintaBordePlantilla(panel, hoja, 14, 6),
            "El pintado real debe terminar los bordes punteados justo antes del total desplazado y dejar sin esos bordes las posiciones antiguas.");
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 3, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 5, false, true);
        Opcion(hoja, "Eliminar columnas").PerformClick();
        exige(partida.Costos.Hoja.CeldaTotal == "D11" && Convert.ToString(hoja[3, 10].Value) == 6m.ToString("0.00") &&
            PintaBordePlantilla(panel, hoja, 2, 4) && !PintaBordePlantilla(panel, hoja, 2, 5),
            "Eliminar D:F debe mover el total a D11 y hacer que los bordes del cuerpo terminen en E, sin mantener la anchura anterior.");
        Invocar(panel, "SeleccionarEncabezadoHoja", 4, -1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", 6, -1, false, true);
        Opcion(hoja, "Insertar filas").PerformClick();
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 3, false, true);
        Opcion(hoja, "Insertar columnas").PerformClick();
        exige(partida.Costos.Hoja.CeldaTotal == "G14" && PintaBordePlantilla(panel, hoja, 12, 7) &&
            !PintaBordePlantilla(panel, hoja, 13, 7) && !PintaBordePlantilla(panel, hoja, 12, 8),
            "Insertar varias filas y columnas dentro del cuerpo debe ampliar su pintado hasta H13 y mantener el resumen fuera del cuerpo.");
    }

    private static bool PintaBordePlantilla(MYGPanelPresupuesto panel, DataGridView hoja, int fila, int columna)
    {
        using var imagen = new Bitmap(hoja.ClientSize.Width, hoja.ClientSize.Height);
        using var dibujo = Graphics.FromImage(imagen);
        var celda = hoja[columna, fila];
        var limites = hoja.GetCellDisplayRectangle(columna, fila, false);
        var evento = new DataGridViewCellPaintingEventArgs(hoja, dibujo, limites, limites, fila, columna,
            celda.State, celda.Value, celda.FormattedValue, "", celda.InheritedStyle,
            hoja.AdvancedCellBorderStyle, DataGridViewPaintParts.All);
        Invocar(panel, "PintarCeldaHoja", hoja, evento);
        return evento.Handled;
    }

    private static void ExigirRechazoSinCambios(MYGPanelPresupuesto panel, ItemPresupuestoDelphin partida,
        string comando, string mensaje, Action<bool, string> exige)
    {
        string antes = Estado(partida.Costos.Hoja);
        bool rechazado = false;
        try { Invocar(panel, "EjecutarComandoHoja", comando); }
        catch (InvalidOperationException ex) { rechazado = ex.Message.Contains(mensaje, StringComparison.Ordinal); }
        exige(rechazado && Estado(partida.Costos.Hoja) == antes,
            "Una operación estructural sobre selecciones separadas debe explicar que requiere un intervalo contiguo y conservar los datos intermedios.");
    }

    private static bool Filas(DataGridView hoja, int primera, int ultima) => hoja.SelectedCells.Count == (ultima - primera + 1) * hoja.ColumnCount &&
        hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.RowIndex >= primera && c.RowIndex <= ultima);
    private static bool Columnas(DataGridView hoja, int primera, int ultima) => hoja.SelectedCells.Count == (ultima - primera + 1) * hoja.RowCount &&
        hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.ColumnIndex >= primera && c.ColumnIndex <= ultima);
    private static HashSet<Point> Seleccion(DataGridView hoja) => hoja.SelectedCells.Cast<DataGridViewCell>()
        .Select(c => new Point(c.ColumnIndex, c.RowIndex)).ToHashSet();
    private static string Estado(MYGHojaMetrado hoja) => JsonSerializer.Serialize(hoja);
    private static string Contenido(MYGHojaMetrado hoja, string direccion) => new MYGHojaCalculo(hoja).Contenido(direccion);
    private static Point Centro(Rectangle rectangulo) => new(rectangulo.Left + rectangulo.Width / 2, rectangulo.Top + rectangulo.Height / 2);
    private static ToolStripItem Opcion(DataGridView hoja, string texto) => hoja.ContextMenuStrip.Items.Cast<ToolStripItem>().Single(i => i.Text == texto);
    private static void Arrastrar(DataGridView hoja, Point inicio, Point fin)
    { Mouse(hoja, 0x0201, inicio, 1); Mouse(hoja, 0x0200, fin, 1); Mouse(hoja, 0x0202, fin); }
    private static void Anticlic(DataGridView hoja, Point punto)
    { Mouse(hoja, 0x0204, punto, 2); Mouse(hoja, 0x0205, punto); }
    private static void Mouse(Control control, int mensaje, Point punto, int botones = 0)
    {
        EnviarMensaje(control.Handle, mensaje, new IntPtr(botones), new IntPtr((punto.Y << 16) | (punto.X & 0xffff)));
        Application.DoEvents();
    }
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
