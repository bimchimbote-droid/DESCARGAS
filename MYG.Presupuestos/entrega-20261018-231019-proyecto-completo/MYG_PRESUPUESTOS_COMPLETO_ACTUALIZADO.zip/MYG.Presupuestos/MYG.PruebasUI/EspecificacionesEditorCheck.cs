using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesEditorCheck
{
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    private static void Rueda(Control destino, int delta, bool control = false,
        Point? puntoPantalla = null, bool procesarMensajes = true)
    {
        Point punto = puntoPantalla ?? destino.PointToScreen(new Point(10, 10));
        int teclas = control ? 0x0008 : 0;
        SendMessage(destino.Handle, 0x020A, new IntPtr(unchecked((delta << 16) | teclas)),
            new IntPtr(unchecked((punto.Y << 16) | (punto.X & 0xffff))));
        if (procesarMensajes) Application.DoEvents();
    }

    private static void EsperarZoom(MYGEspecificacionesEditor editor, Action<bool, string> exige)
    {
        var reloj = Stopwatch.StartNew();
        while (editor.ZoomEnCurso && reloj.Elapsed.TotalSeconds < 2)
        {
            Application.DoEvents();
            Thread.Sleep(1);
        }
        exige(!editor.ZoomEnCurso, "La transición de zoom debe finalizar sin dejar el temporizador activo.");
    }

    private static void ProcesarDurante(int milisegundos)
    {
        var reloj = Stopwatch.StartNew();
        while (reloj.ElapsedMilliseconds < milisegundos)
        {
            Application.DoEvents();
            Thread.Sleep(1);
        }
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        int antes = 0, cambios = 0;
        string guardadoRtf = null, guardadoTexto = null;
        var documento = new RichTextBox
        {
            Font = new Font("Arial", 11), AcceptsTab = true,
            DetectUrls = false, HideSelection = false
        };
        MYGEspecificacionesEditor editor = null;
        using (editor = new MYGEspecificacionesEditor(documento, () => antes++, () =>
        {
            cambios++;
            guardadoRtf = editor.DocumentoRtf;
            guardadoTexto = documento.Text;
        }, () => "CONCRETO SIMPLE", () => "m³", () => "01.02", () => "PRESUPUESTO DE PRUEBA"))
        using (var formulario = new Form { Text = "Prueba del editor de especificaciones", ClientSize = new(946, 780) })
        {
            formulario.Controls.Add(editor);
            formulario.Show();
            Application.DoEvents();
            const string textoA = "Descripción de la partida\nEjecución y control de calidad";
            int antesInicial = antes, cambiosInicial = cambios;
            editor.Cargar("partida-A", "", textoA);
            int antesCarga = antes, cambiosCarga = cambios;
            exige(ReferenceEquals(editor.Documento, documento) && documento.Text == textoA,
                "El editor debe conservar el RichTextBox y cargar el texto de la partida.");
            exige(antes == antesInicial && cambios == cambiosInicial,
                "Cargar inicialmente una especificación no debe modificar el presupuesto ni agregar historial.");
            VerificarDisposicion(editor, exige);

            const string antiguoRtf = @"{\rtf1\ansi\b Especificacion existente\b0\par Texto conservado.}";
            editor.Cargar("partida-antigua", antiguoRtf, "Especificacion existente\nTexto conservado.");
            documento.Select(3, 6);
            bool undoAntiguo = documento.CanUndo;
            string normalizadoAntiguo = editor.DocumentoRtf;
            editor.Cargar("partida-antigua", antiguoRtf, "Especificacion existente\nTexto conservado.");
            exige(documento.SelectionStart == 3 && documento.SelectionLength == 6 &&
                documento.CanUndo == undoAntiguo && editor.DocumentoRtf == normalizadoAntiguo,
                "Refrescar RTF existente sin metadatos debe conservar la selección y el documento normalizado.");
            exige(antes == antesCarga && cambios == cambiosCarga,
                "La normalización de un RTF existente no debe reescribir la partida durante la carga.");
            editor.Cargar("partida-A", "", textoA);

            // Una combinación de estilos y fuentes debe sobrevivir al guardado RTF
            // y a salir de la partida; esto detecta conversiones accidentales a TXT.
            documento.Select(0, "Descripción".Length);
            editor.AplicarFormato(() => documento.SelectionFont = new Font("Arial", 13, FontStyle.Bold | FontStyle.Underline));
            exige(antes == antesCarga + 1 && cambios == cambiosCarga + 1,
                "Aplicar formato debe guardar un único estado anterior y una única modificación.");
            editor.AplicarFormato(() => documento.SelectionColor = Color.DarkGreen);
            int segundo = documento.Text.IndexOf("Ejecución", StringComparison.Ordinal);
            documento.Select(segundo, "Ejecución".Length);
            editor.AplicarFormato(() => documento.SelectionFont = new Font("Courier New", 10, FontStyle.Italic));
            documento.Select(segundo, 0);
            editor.AplicarFormato(() => documento.SelectionAlignment = HorizontalAlignment.Center);
            documento.SelectAll();
            exige(documento.SelectionFont == null && MYGEspecificacionesFormato.TieneEstilo(documento, FontStyle.Bold) == null,
                "La selección de prueba debe conservar fuentes y estilos diferentes.");
            editor.AplicarFormato(() => MYGEspecificacionesFormato.AlternarEstilo(documento, FontStyle.Strikeout));
            documento.Select(0, "Descripción".Length);
            exige(documento.SelectionFont is Font primeraMixta && primeraMixta.Bold && primeraMixta.Underline &&
                primeraMixta.Strikeout && Math.Abs(primeraMixta.Size - 13) < .01 &&
                documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
                "Formatear una selección mixta perdió estilos, tamaño o color del primer fragmento.");
            documento.Select(segundo, "Ejecución".Length);
            exige(documento.SelectionFont is Font segundaMixta && segundaMixta.Italic && !segundaMixta.Bold &&
                segundaMixta.Strikeout && Math.Abs(segundaMixta.Size - 10) < .01,
                "Formatear una selección mixta perdió estilos o tamaño del segundo fragmento.");
            exige(guardadoTexto == textoA && !string.IsNullOrWhiteSpace(guardadoRtf),
                "El formato debe guardar texto y RTF sin alterar el contenido de la partida.");
            string partidaARtf = guardadoRtf;

            documento.Select(2, 5);
            int seleccion = documento.SelectionStart, longitud = documento.SelectionLength;
            bool undo = documento.CanUndo;
            antesCarga = antes; cambiosCarga = cambios;
            editor.Cargar("partida-A", partidaARtf, textoA);
            exige(documento.SelectionStart == seleccion && documento.SelectionLength == longitud && documento.CanUndo == undo,
                "Refrescar la misma partida debe conservar la selección y el historial del editor.");
            exige(antes == antesCarga && cambios == cambiosCarga && editor.DocumentoRtf == partidaARtf,
                "Recargar una partida sin cambios no debe volver a guardarla ni modificar su RTF.");

            // La selección de otra partida no puede heredar Deshacer ni escribir
            // su documento en la partida que se acaba de abandonar.
            editor.Cargar("partida-B", "", "Especificación de otra partida");
            exige(documento.Text == "Especificación de otra partida" && !documento.CanUndo,
                "Cambiar de partida debe cargar su especificación y vaciar Deshacer nativo.");
            exige(antes == antesCarga && cambios == cambiosCarga,
                "Cambiar de partida no debe crear historial ni callbacks de guardado.");
            editor.Cargar("partida-A", partidaARtf, textoA);
            documento.Select(0, "Descripción".Length);
            var primeraFuente = documento.SelectionFont;
            exige(primeraFuente != null && primeraFuente.Bold && primeraFuente.Underline &&
                Math.Abs(primeraFuente.Size - 13) < .01 && documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
                "Volver a la partida perdió tamaño, negrita, subrayado o color del RTF.");
            documento.Select(segundo, "Ejecución".Length);
            var segundaFuente = documento.SelectionFont;
            exige(segundaFuente != null && segundaFuente.Italic &&
                Math.Abs(segundaFuente.Size - 10) < .01 && documento.SelectionAlignment == HorizontalAlignment.Center,
                "Volver a la partida perdió el segundo estilo o la alineación del párrafo.");
            exige(primeraFuente != null && segundaFuente != null && primeraFuente.Name != segundaFuente.Name,
                "Cargar el RTF homogeneizó las fuentes de la especificación.");

            // Historial global reemplaza el modelo manteniendo el ID de partida.
            // La carga debe detectar el contenido distinto aunque el ID coincida.
            editor.Cargar("partida-A", "", "Estado anterior del documento");
            exige(documento.Text == "Estado anterior del documento" && !documento.CanUndo,
                "Una restauración con el mismo ID debe reemplazar el contenido obsoleto.");
            exige(antes == antesCarga && cambios == cambiosCarga,
                "Restaurar el documento debe cargarlo sin agregar otra modificación.");

            editor.Cargar("partida-A", partidaARtf, textoA);
            documento.Select(0, "Descripción".Length);
            var negrita = Herramientas(editor).OfType<ToolStripButton>().SingleOrDefault(x => x.Name == "espec_negrita");
            exige(negrita != null, "La cinta debe ofrecer el comando de negrita con un nombre accesible estable.");
            negrita.Owner.Focus();
            Application.DoEvents();
            antesCarga = antes; cambiosCarga = cambios;
            negrita.PerformClick();
            exige(antes == antesCarga + 1 && cambios == cambiosCarga + 1 && documento.SelectionFont?.Bold == false,
                "El botón de formato debe cambiar la selección una sola vez, incluso al recuperar el foco del texto.");

            editor.Cargar("partida-C", "", "");
            var plantilla = Herramientas(editor).OfType<ToolStripButton>().SingleOrDefault(x => x.Name == "espec_plantilla");
            exige(plantilla != null, "La cinta debe ofrecer una plantilla para generar la especificación de la partida.");
            var cinta = Descendientes(editor).OfType<TabControl>().Single(x => x.Name == "espec_cinta");
            cinta.SelectedTab = cinta.TabPages.Cast<TabPage>().Single(x => x.Text == "Insertar");
            Application.DoEvents();
            antesCarga = antes; cambiosCarga = cambios;
            plantilla.PerformClick();
            exige(documento.Text.Contains("01.02  CONCRETO SIMPLE") && documento.Text.Contains("Unidad de medida: m³") &&
                documento.Text.Contains("A. DESCRIPCIÓN") && documento.Text.Contains("G. CONDICIONES DE PAGO"),
                "La plantilla debe generar título, unidad y estructura técnica para la partida activa.");
            exige(antes == antesCarga + 1 && cambios == cambiosCarga + 1,
                "Generar la estructura técnica debe guardar una sola modificación.");

            VerificarInsercionTitulo(editor, documento, () => (antes, cambios), exige);
            VerificarFormatoNativo(editor, documento, () => (antes, cambios), exige);
            VerificarDiseno(editor, documento, () => (antes, cambios), exige);
            VerificarContenido(editor, documento, () => (antes, cambios), exige);
            VerificarExportacionRtf(editor, documento, () => (antes, cambios), exige);
            VerificarVista(editor, documento, () => (antes, cambios), exige);
            antesCarga = antes; cambiosCarga = cambios;
            editor.Cargar("", "", "");
            editor.AplicarFormato(() => documento.SelectedText = "Edición sin partida");
            exige(documento.ReadOnly && documento.TextLength == 0 && antes == antesCarga && cambios == cambiosCarga,
                "Sin una partida activa el editor debe impedir cambios y no generar historial.");
            var insertarTitulo = Descendientes(editor).OfType<Button>().Single(x => x.Name == "espec_insertar_titulo");
            insertarTitulo.PerformClick();
            exige(documento.TextLength == 0 && antes == antesCarga && cambios == cambiosCarga,
                "Insertar título sin una partida activa no debe agregar texto ni guardar modificaciones.");
            formulario.Close();
        }
        VerificarDibujoTema(exige);
        VerificarIntegracionTema(exige);
    }

    private static void VerificarDibujoTema(Action<bool, string> exige)
    {
        if (SystemInformation.HighContrast) return;
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        using var documento = new RichTextBox { Font = new Font("Arial", 16) };
        using var editor = new MYGEspecificacionesEditor(documento, () => { }, () => { },
            () => "Partida", () => "und", () => "01");
        using var formulario = new Form { ClientSize = new Size(950, 740) };
        formulario.Controls.Add(editor);
        formulario.Show();
        editor.Cargar("prueba-dibujo", @"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}\f0\fs32 Texto negro de prueba}", "");
        var zoom = Descendientes(editor).OfType<NumericUpDown>().Single(x => x.Name == "espec_zoom");
        zoom.Value = 100;
        string original = editor.DocumentoRtf;
        try
        {
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                documento.Refresh();
                Application.DoEvents();
                VerificarDibujoDocumento(editor, oscuro, exige);
                exige(editor.DocumentoRtf == original,
                    "Pintar las letras con contraste no debe modificar los colores ni el contenido guardado.");
            }
        }
        finally
        {
            formulario.Close();
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarIntegracionTema(Action<bool, string> exige)
    {
        if (SystemInformation.HighContrast) return;
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            // Iniciar ya en oscuro no emite CambioTema para el editor nuevo.
            if (!MYG2027_TemaComercial.Oscuro) MYG2027_TemaComercial.Alternar(false);
            int cambios = 0;
            using var documento = new RichTextBox { Font = new Font("Arial", 16) };
            using var editor = new MYGEspecificacionesEditor(documento, () => { }, () => cambios++,
                () => "Partida", () => "und", () => "01");
            using var formulario = new Form { ClientSize = new Size(950, 740) };
            MYG2027_TemaComercial.Aplicar(formulario);
            formulario.Controls.Add(editor); // Ejecuta el ControlAdded del tema global.
            formulario.Show();
            editor.Cargar("prueba-integracion-tema", @"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}\f0\fs32 Texto negro de prueba}", "");
            var controles = Descendientes(editor).ToArray();
            var cinta = controles.OfType<TabControl>().Single(x => x.Name == "espec_cinta");
            controles.OfType<NumericUpDown>().Single(x => x.Name == "espec_zoom").Value = 100;
            Application.DoEvents();
            documento.Select(documento.TextLength, 0);
            editor.AplicarFormato(() => documento.SelectedText = "\nNota para comprobar Deshacer.");
            documento.Select(6, 4);
            string original = editor.DocumentoRtf, salida = editor.RtfParaArchivo;
            int posicion = documento.SelectionStart, longitud = documento.SelectionLength, cambiosOriginal = cambios;
            bool undo = documento.CanUndo;
            exige(undo, "La integración del tema debe comprobarse con una edición recuperable en Deshacer.");
            var menu = Herramientas(cinta).OfType<ToolStripDropDownItem>()
                .First(x => x.Owner != null && x.Owner.Visible && x.DropDownItems.Count > 0);
            ToolStrip herramientas = menu.Owner;
            ToolStripRenderer renderer = herramientas.Renderer;
            var destinos = new Control[] { formulario, editor, documento, cinta, herramientas, menu.DropDown };
            foreach (bool oscuro in new[] { true, false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                foreach (Control destino in destinos)
                {
                    MYG2027_TemaComercial.Aplicar(destino);
                    MYG2027_TemaComercial.Aplicar(destino);
                    Application.DoEvents();
                    exige(ReferenceEquals(herramientas.Renderer, renderer) &&
                        ReferenceEquals(menu.DropDown.Renderer, renderer),
                        "Aplicar el tema global a un editor, hijo o menú debe conservar su renderer especializado.");
                    if (oscuro)
                    {
                        exige(controles.Where(x => x is TabPage || x.Name.StartsWith("espec_grupo_", StringComparison.Ordinal))
                            .All(x => x.BackColor.GetBrightness() < .3f && x.ForeColor.GetBrightness() > .7f),
                            "Las pestañas y todos los grupos de herramientas deben mantenerse oscuros con texto claro.");
                        exige(new[] { "espec_cabecera", "espec_barra_titulo", "espec_regla_horizontal", "espec_regla_vertical" }
                            .All(nombre => controles.Single(x => x.Name == nombre).BackColor.GetBrightness() < .3f),
                            "La aplicación global del tema no debe aclarar cabecera, reglas ni barra inferior.");
                    }
                    VerificarDibujoDocumento(editor, oscuro, exige);
                    exige(editor.DocumentoRtf == original && editor.RtfParaArchivo == salida &&
                        documento.CanUndo == undo && documento.SelectionStart == posicion &&
                        documento.SelectionLength == longitud && cambios == cambiosOriginal,
                        "Reaplicar el tema por cualquier punto de entrada debe conservar RTF, salida, selección, Deshacer y cambios.");
                }
                menu.ShowDropDown();
                Application.DoEvents();
                exige(ReferenceEquals(menu.DropDown.Renderer, renderer) &&
                    (!oscuro || menu.DropDown.BackColor.GetBrightness() < .3f && menu.DropDown.ForeColor.GetBrightness() > .7f),
                    "Abrir un menú nativo debe conservar la paleta y el renderer del editor en oscuro.");
                menu.HideDropDown();
                formulario.Hide();
                formulario.Show();
                Application.DoEvents();
                VerificarDibujoDocumento(editor, oscuro, exige);
                exige(editor.DocumentoRtf == original && editor.RtfParaArchivo == salida &&
                    documento.CanUndo == undo && documento.SelectionStart == posicion &&
                    documento.SelectionLength == longitud && cambios == cambiosOriginal,
                    "Reabrir el menú y mostrar otra vez la ventana debe conservar documento, selección e historial.");
            }
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    internal static void VerificarDibujoDocumento(MYGEspecificacionesEditor editor, bool oscuro, Action<bool, string> exige)
    {
        if (SystemInformation.HighContrast) return;
        var documento = editor.Documento;
        int esperado = oscuro ? unchecked((int)0xff303640) : Color.White.ToArgb();
        exige(documento.BackColor.ToArgb() == esperado && documento.Parent.BackColor.ToArgb() == esperado,
            "El fondo nativo del texto y su hoja deben seguir el tema, incluso antes de pintar.");
        Rectangle visible = documento.RectangleToScreen(documento.ClientRectangle);
        for (Control padre = documento.Parent; padre != null; padre = padre.Parent)
            visible.Intersect(padre.RectangleToScreen(padre.ClientRectangle));
        int indice = 0;
        while (indice < documento.TextLength && char.IsWhiteSpace(documento.Text[indice])) indice++;
        Point origen = documento.PointToScreen(documento.GetPositionFromCharIndex(indice));
        Rectangle region = Rectangle.Intersect(visible, new Rectangle(origen, new Size(200, 40)));
        exige(region.Width > 40 && region.Height > 12, "La comprobación visual debe incluir texto realmente visible en pantalla.");
        using var muestra = new Bitmap(region.Width, region.Height);
        using (var grafico = Graphics.FromImage(muestra))
            grafico.CopyFromScreen(region.Location, Point.Empty, muestra.Size);
        int tinta = 0, papel = 0;
        for (int y = 0; y < muestra.Height; y++)
            for (int x = 0; x < muestra.Width; x++)
            {
                Color color = muestra.GetPixel(x, y);
                if (color.ToArgb() == esperado) papel++;
                if (oscuro ? color.GetBrightness() > .65f : color.GetBrightness() < .35f) tinta++;
            }
        exige(papel > 500 && tinta > 50,
            "El dibujo real debe incluir papel y letras contrastadas; un fondo vacío o blanco en oscuro no valida la vista.");
    }

    private static void VerificarDisposicion(MYGEspecificacionesEditor editor, Action<bool, string> exige)
    {
        var controles = Descendientes(editor).ToArray();
        var cabecera = controles.Single(x => x.Name == "espec_cabecera");
        var cinta = controles.OfType<TabControl>().Single(x => x.Name == "espec_cinta");
        var lienzo = controles.Single(x => x.Name == "espec_lienzo");
        var papel = controles.Single(x => x.Name == "espec_papel");
        var reglaHorizontal = controles.Single(x => x.Name == "espec_regla_horizontal");
        var reglaVertical = controles.Single(x => x.Name == "espec_regla_vertical");
        var titulo = controles.OfType<Button>().Single(x => x.Name == "espec_insertar_titulo");
        var etiquetasCabecera = Descendientes(cabecera).OfType<Label>().ToArray();
        var word = controles.OfType<Button>().Single(x => x.Name == "espec_exportar_word");
        var pdf = controles.OfType<Button>().Single(x => x.Name == "espec_exportar_pdf");
        exige(etiquetasCabecera.Single(x => x.Name == "espec_cabecera_titulo").Text == "Especificaciones técnicas" &&
            etiquetasCabecera.Single(x => x.Name == "espec_cabecera_presupuesto").Text == "PRESUPUESTO DE PRUEBA" &&
            etiquetasCabecera.Single(x => x.Name == "espec_cabecera_item").Text == "01.02" &&
            etiquetasCabecera.Single(x => x.Name == "espec_cabecera_partida").Text == "CONCRETO SIMPLE",
            "El encabezado debe presentar el presupuesto y los datos de la partida activa.");
        exige(word.Parent == cabecera && pdf.Parent == cabecera && word.Image != null && pdf.Image != null &&
            word.Right <= pdf.Left + 2 && word.Top == pdf.Top && pdf.Right >= cabecera.Width - 20 * editor.DeviceDpi / 96f,
            "Los botones Word y PDF deben mantener sus iconos y su posición juntos arriba a la derecha.");
        exige(cinta.TabPages.Cast<TabPage>().Select(x => x.Text).SequenceEqual(new[]
            { "Fichero", "Inicio", "Insertar", "Distribución de Página", "Vista" }),
            "La cinta debe reproducir las cinco pestañas y el orden de la referencia.");
        exige(cinta.SelectedTab?.Text == "Inicio",
            "Al abrir las especificaciones debe mostrarse la pestaña Inicio de la referencia.");
        string[] grupos = { "Portapapeles", "Acciones", "Fuente", "Párrafo", "Estilos", "Edición" };
        var paneles = grupos.Select(nombre => Descendientes(cinta.SelectedTab)
            .Single(x => x.Name == "espec_grupo_" + nombre)).ToArray();
        exige(paneles.All(x => x.Visible && x.Right <= x.Parent.ClientSize.Width) && paneles.Zip(paneles.Skip(1),
                (izquierda, derecha) => izquierda.Left < derecha.Left && izquierda.Right <= derecha.Left + 2).All(x => x),
            "Los grupos de Inicio deben conservar su ubicación de izquierda a derecha, sin superponerse.");
        Rectangle Encaja(Control control) => new(editor.PointToClient(control.PointToScreen(Point.Empty)), control.Size);
        var rCabecera = Encaja(cabecera); var rCinta = Encaja(cinta);
        var rLienzo = Encaja(lienzo); var rPapel = Encaja(papel);
        var rHorizontal = Encaja(reglaHorizontal); var rVertical = Encaja(reglaVertical);
        var rTitulo = Encaja(titulo);
        exige(rCabecera.Top == 0 && rCabecera.Bottom <= rCinta.Top && rCinta.Bottom <= rHorizontal.Bottom &&
            rHorizontal.Top < rPapel.Top && rVertical.Left < rPapel.Left && rLienzo.Top < rPapel.Top,
            "El encabezado, la cinta y las reglas deben enmarcar la hoja como en la referencia.");
        int margen = (int)Math.Ceiling(20 * editor.DeviceDpi / 96f);
        exige(titulo.Text == "Insertar título" && !Descendientes(cinta).Contains(titulo) &&
            rTitulo.Top >= rLienzo.Bottom && editor.ClientSize.Width - rTitulo.Right <= margen &&
            editor.ClientSize.Height - rTitulo.Bottom <= margen,
            "Insertar título debe permanecer fuera de la cinta, debajo del documento y en el extremo derecho.");
        Color fondoEsperado = MYG2027_TemaComercial.Oscuro && !SystemInformation.HighContrast
            ? Color.FromArgb(unchecked((int)0xff303640)) : Color.White;
        exige(papel.BackColor.ToArgb() == fondoEsperado.ToArgb() && papel.Contains(editor.Documento) &&
            lienzo.BackColor.ToArgb() == MYG2027_TemaComercial.Fondo.ToArgb(),
            "La vista debe mostrar la hoja y el fondo de edición con la paleta del tema activo.");
    }

    private static void VerificarInsercionTitulo(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        const string texto = "Texto anterior\nContenido técnico existente";
        editor.Cargar("partida-titulo", "", texto);
        int inicioContenido = documento.Text.IndexOf("Contenido", StringComparison.Ordinal);
        documento.Select(inicioContenido, "Contenido técnico existente".Length);
        editor.AplicarFormato(() => documento.SelectionFont = new Font("Courier New", 10, FontStyle.Italic));
        editor.AplicarFormato(() => documento.SelectionColor = Color.DarkGreen);
        documento.Select(inicioContenido, 0);
        var inicial = contadores();
        var boton = Descendientes(editor).OfType<Button>().Single(x => x.Name == "espec_insertar_titulo");
        boton.PerformClick();
        const string encabezado = "01.02  CONCRETO SIMPLE";
        int inicioTitulo = documento.Text.IndexOf(encabezado, StringComparison.Ordinal);
        int inicioDescripcion = documento.Text.IndexOf("DESCRIPCIÓN:", StringComparison.Ordinal);
        exige(inicioTitulo == inicioContenido && inicioDescripcion > inicioTitulo &&
            documento.Text.Contains("(unidad de medida: m³)", StringComparison.Ordinal) &&
            documento.Text.StartsWith("Texto anterior\n", StringComparison.Ordinal) &&
            documento.Text.EndsWith("Contenido técnico existente", StringComparison.Ordinal),
            "Insertar título debe usar el ítem, nombre y unidad de la partida en el cursor, conservando el texto existente.");
        exige(contadores() == (inicial.Antes + 1, inicial.Cambios + 1),
            "El botón Insertar título debe crear una sola modificación y un único estado de historial.");
        documento.Select(inicioTitulo, encabezado.Length);
        exige(documento.SelectionFont?.Bold == true,
            "El ítem y nombre insertados deben resaltarse en negrita como en la referencia.");
        documento.Select(inicioDescripcion, "DESCRIPCIÓN:".Length);
        exige(documento.SelectionFont?.Bold == true,
            "La sección DESCRIPCIÓN insertada debe mostrarse en negrita.");
        const string textoUnidad = "(unidad de medida: m³)";
        documento.Select(documento.Text.IndexOf(textoUnidad, StringComparison.Ordinal), textoUnidad.Length);
        exige(documento.SelectionFont is Font fuenteUnidad && !fuenteUnidad.Bold && Math.Abs(fuenteUnidad.Size - 11) < .01,
            "La unidad de medida insertada debe conservar el tamaño de texto normal sin negrita.");
        int finalContenido = documento.Text.IndexOf("Contenido técnico existente", StringComparison.Ordinal);
        documento.Select(finalContenido, "Contenido técnico existente".Length);
        exige(documento.SelectionFont is Font fuente && fuente.Italic && fuente.Name == "Courier New" &&
            Math.Abs(fuente.Size - 10) < .01 && documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "Insertar título no debe cambiar los formatos del contenido técnico existente.");
        string rtf = editor.DocumentoRtf, completo = documento.Text;
        var despues = contadores();
        editor.Cargar("partida-titulo-otra", "", "Otra especificación");
        editor.Cargar("partida-titulo", rtf, completo);
        exige(documento.Text == completo && contadores() == despues,
            "El título insertado debe conservarse al cambiar y volver a la partida sin un guardado adicional.");
    }

    private static void VerificarFormatoNativo(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        const string texto = "Medición\nSe usa CO2 y se cuantifica en m3\nControl de calidad";
        editor.Cargar("partida-formato-nativo", "", texto);
        var inicial = contadores();
        documento.SelectAll();
        editor.AplicarFormato(() => MYGEspecificacionesFormato.Lista(documento, true));
        editor.AplicarFormato(() => MYGEspecificacionesFormato.Alinear(documento, 4));
        editor.AplicarFormato(() => MYGEspecificacionesFormato.Interlineado(documento, 1.5f));
        int subindice = documento.Text.IndexOf("CO2", StringComparison.Ordinal) + 2;
        int superindice = documento.Text.IndexOf("m3", StringComparison.Ordinal) + 1;
        documento.Select(subindice, 1);
        editor.AplicarFormato(() => MYGEspecificacionesFormato.PosicionCaracter(documento, -1));
        documento.Select(superindice, 1);
        editor.AplicarFormato(() => MYGEspecificacionesFormato.PosicionCaracter(documento, 1));
        exige(contadores() == (inicial.Antes + 5, inicial.Cambios + 5),
            "Lista, alineación, interlineado y posiciones de caracteres deben guardar un cambio por comando.");
        string guardado = editor.DocumentoRtf;
        var despuesFormato = contadores();
        editor.Cargar("partida-intermedia", "", "Otro documento");
        editor.Cargar("partida-formato-nativo", guardado, texto);
        exige(documento.Text == texto && documento.Rtf.Contains(@"\pndec", StringComparison.Ordinal),
            "Recargar la especificación debe conservar el cuerpo y la lista numerada nativa.");
        documento.SelectAll();
        exige(MYGEspecificacionesFormato.ObtenerAlineacion(documento) == 4 &&
            MYGEspecificacionesFormato.ObtenerInterlineado(documento) is float factor && Math.Abs(factor - 1.5f) < .01,
            "La justificación y el interlineado deben conservarse en todos los párrafos tras cargar RTF.");
        documento.Select(subindice, 1);
        exige(MYGEspecificacionesFormato.ObtenerPosicionCaracter(documento) == -1,
            "El subíndice químico debe conservarse al volver a la partida.");
        documento.Select(superindice, 1);
        exige(MYGEspecificacionesFormato.ObtenerPosicionCaracter(documento) == 1,
            "El superíndice de la unidad de medida debe conservarse al volver a la partida.");
        exige(contadores() == despuesFormato && !documento.CanUndo,
            "Recargar formatos nativos no debe crear modificaciones ni mezclar el historial entre partidas.");
    }

    private static void VerificarDiseno(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        editor.Cargar("partida-diseno", "", "El contenido de esta partida conserva sus formatos.");
        documento.SelectAll();
        editor.AplicarFormato(() => documento.SelectionFont = new Font("Arial", 12, FontStyle.Bold));
        string cuerpo = documento.Rtf;
        var inicial = contadores();
        Pulsar(editor, "Horizontal");
        Pulsar(editor, "Carta");
        Pulsar(editor, "Número de página");
        var pagina = MYGEspecificacionesPagina.Leer(editor.DocumentoRtf);
        exige(pagina.Horizontal && pagina.AnchoMm == 215.9m && pagina.AltoMm == 279.4m && pagina.NumerarPaginas,
            "La cinta debe guardar orientación, papel Carta y numeración para la partida.");
        exige(documento.Rtf == cuerpo && contadores() == (inicial.Antes + 3, inicial.Cambios + 3),
            "Configurar página debe conservar el cuerpo y guardar una única modificación por comando.");
        string configurado = editor.DocumentoRtf;
        editor.Cargar("partida-diseno", configurado, documento.Text);
        Pulsar(editor, "Deshacer diseño");
        pagina = MYGEspecificacionesPagina.Leer(editor.DocumentoRtf);
        exige(pagina.Horizontal && pagina.AnchoMm == 215.9m && !pagina.NumerarPaginas,
            "Deshacer diseño debe revertir la numeración y conservar los cambios de página anteriores.");
        Pulsar(editor, "Deshacer diseño");
        pagina = MYGEspecificacionesPagina.Leer(editor.DocumentoRtf);
        exige(pagina.Horizontal && pagina.AnchoMm == 210m && pagina.AltoMm == 297m,
            "Deshacer papel Carta debe recuperar A4 sin alterar la orientación.");
        Pulsar(editor, "Deshacer diseño");
        pagina = MYGEspecificacionesPagina.Leer(editor.DocumentoRtf);
        exige(!pagina.Horizontal && !pagina.NumerarPaginas,
            "Deshacer la orientación debe recuperar la configuración inicial de página.");
        Pulsar(editor, "Rehacer diseño");
        Pulsar(editor, "Rehacer diseño");
        Pulsar(editor, "Rehacer diseño");
        exige(editor.DocumentoRtf == configurado && documento.Rtf == cuerpo &&
            contadores() == (inicial.Antes + 9, inicial.Cambios + 9),
            "Rehacer diseño debe recuperar toda la configuración sin modificar el cuerpo y con callbacks únicos.");
        editor.Cargar("partida-diseno-nueva", "", "Una partida independiente");
        var trasCambio = contadores();
        string independiente = editor.DocumentoRtf;
        Pulsar(editor, "Deshacer diseño");
        Pulsar(editor, "Rehacer diseño");
        exige(editor.DocumentoRtf == independiente && contadores() == trasCambio,
            "Cambiar de partida debe vaciar ambos historiales de diseño y evitar modificaciones sin cambios.");
        editor.Cargar("partida-diseno", configurado, "El contenido de esta partida conserva sus formatos.");
        pagina = MYGEspecificacionesPagina.Leer(editor.DocumentoRtf);
        exige(pagina.Horizontal && pagina.AnchoMm == 215.9m && pagina.NumerarPaginas && documento.Rtf == cuerpo,
            "Volver a la partida debe restaurar su diseño y sus formatos propios.");
    }

    private static void VerificarContenido(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-especificaciones-ui-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string imagen = Path.Combine(carpeta, "referencia.bmp");
            using (var bitmap = new Bitmap(16, 12))
            {
                using (var grafico = Graphics.FromImage(bitmap))
                {
                    grafico.Clear(Color.DarkGreen);
                    grafico.FillRectangle(Brushes.Gold, 3, 2, 8, 6);
                }
                bitmap.Save(imagen, ImageFormat.Bmp);
            }
            editor.Cargar("partida-contenido", "", "Texto de introducción\n");
            string portapapeles = HuellaPortapapeles();
            var inicial = contadores();
            documento.Select(documento.TextLength, 0);
            editor.AplicarFormato(() => MYGEspecificacionesDocumento.InsertarTabla(documento, 2, 2, 7000));
            documento.Select(documento.TextLength, 0);
            editor.AplicarFormato(() => documento.SelectedText = "\nImagen de referencia:\n");
            editor.AplicarFormato(() => MYGEspecificacionesDocumento.InsertarImagen(documento, imagen, 7000));
            exige(documento.Rtf.Contains(@"\trowd", StringComparison.Ordinal) && documento.Rtf.Contains(@"\pict", StringComparison.Ordinal),
                "Insertar tabla e imagen debe guardar ambos contenidos en el RTF del documento.");
            exige(HuellaPortapapeles() == portapapeles && contadores() == (inicial.Antes + 3, inicial.Cambios + 3),
                "Insertar contenido debe conservar el portapapeles y guardar una modificación por comando.");
            string guardado = editor.DocumentoRtf, texto = documento.Text;
            var despuesInsercion = contadores();
            editor.Cargar("partida-contenido-otra", "", "Otro contenido");
            editor.Cargar("partida-contenido", guardado, texto);
            exige(documento.Text == texto && documento.Rtf.Contains(@"\trowd", StringComparison.Ordinal) &&
                documento.Rtf.Contains(@"\pict", StringComparison.Ordinal) && contadores() == despuesInsercion,
                "Las tablas e imágenes deben conservarse al cambiar y volver a la partida, sin reescribirla.");

            editor.Cargar("partida-salto", "", "Antes del salto\nDespués del salto");
            documento.Select(documento.Text.IndexOf("Después", StringComparison.Ordinal), 0);
            inicial = contadores();
            editor.AplicarFormato(() => MYGEspecificacionesDocumento.InsertarSaltoPagina(documento));
            exige(documento.Rtf.Contains(@"\pagebb", StringComparison.Ordinal) &&
                contadores() == (inicial.Antes + 1, inicial.Cambios + 1),
                "El salto debe guardarse como salto nativo antes del párrafo con una sola modificación.");
            guardado = editor.DocumentoRtf; texto = documento.Text;
            editor.Cargar("partida-salto-otra", "", "Otro documento");
            editor.Cargar("partida-salto", guardado, texto);
            exige(documento.Rtf.Contains(@"\pagebb", StringComparison.Ordinal) &&
                documento.Text.Contains("Antes del salto") && documento.Text.Contains("Después del salto"),
                "Recargar RTF debe conservar el salto de página y el contenido a ambos lados.");
            exige(HuellaPortapapeles() == portapapeles,
                "Cambiar partidas y cargar contenido RTF tampoco debe alterar el portapapeles.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static void VerificarExportacionRtf(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        string cuerpo = documento.Rtf, guardado = editor.DocumentoRtf;
        var inicial = contadores();
        const string encabezado = "Especificación {concreto} \\ técnico 🏗";
        const string pie = "Obra — Chimbote, Perú";
        var pagina = new PageSettings
        {
            PaperSize = new PaperSize("Carta", 850, 1100), Landscape = true,
            Margins = new Margins(100, 90, 80, 70)
        };
        string exportado = MYGEspecificacionesDocumento.RtfConPagina(documento, pagina, encabezado, pie, numeroPagina: true);
        exige(exportado.Contains(@"\paperw15840", StringComparison.Ordinal) &&
            exportado.Contains(@"\paperh12240", StringComparison.Ordinal) && exportado.Contains(@"\landscape", StringComparison.Ordinal),
            "Exportar RTF debe incluir el papel Carta horizontal con dimensiones nativas correctas.");
        exige(exportado.Contains(@"{\header", StringComparison.Ordinal) && exportado.Contains(@"{\footer", StringComparison.Ordinal) &&
            exportado.Contains(@"\fldinst PAGE", StringComparison.Ordinal) && exportado.Contains(@"\u243?", StringComparison.Ordinal) &&
            exportado.Contains(@"\u233?", StringComparison.Ordinal) && exportado.Contains(@"\{concreto\}", StringComparison.Ordinal),
            "La exportación debe incluir encabezado, pie, campo de página y escapes Unicode y de llaves válidos.");
        using (var copia = new RichTextBox { Rtf = exportado })
            exige(copia.Text == documento.Text && copia.Rtf.Contains(@"\pagebb", StringComparison.Ordinal),
                "Un lector RTF debe cargar el cuerpo exportado conservando los saltos nativos.");
        var metadatos = new MYGPaginaEspecificacion
        {
            AnchoMm = 215.9m, AltoMm = 279.4m, Horizontal = true, NumerarPaginas = true,
            Encabezado = encabezado, Pie = pie
        };
        string portable = MYGEspecificacionesPagina.Guardar(exportado, metadatos);
        var leido = MYGEspecificacionesPagina.Leer(portable);
        exige(leido.Encabezado == encabezado && leido.Pie == pie && leido.Horizontal && leido.NumerarPaginas &&
            MYGEspecificacionesPagina.QuitarMetadatos(portable) == exportado,
            "Los metadatos de página deben poder añadirse y leerse en el RTF exportado sin alterar el documento.");
        exige(documento.Rtf == cuerpo && editor.DocumentoRtf == guardado && contadores() == inicial,
            "Preparar una exportación no debe modificar el documento, sus metadatos ni el historial de la partida.");
    }

    private static string HuellaPortapapeles()
    {
        var datos = Clipboard.GetDataObject();
        string formatos = datos == null ? "" : string.Join("\n", datos.GetFormats(autoConvert: false).OrderBy(x => x, StringComparer.Ordinal));
        string texto = Clipboard.ContainsText() ? Clipboard.GetText() : "";
        string imagen = "";
        using (var bitmap = Clipboard.GetImage())
        {
            if (bitmap != null)
            {
                using var flujo = new MemoryStream();
                bitmap.Save(flujo, ImageFormat.Bmp);
                imagen = Convert.ToHexString(SHA256.HashData(flujo.ToArray()));
            }
        }
        return formatos + "\n" + texto + "\n" + imagen;
    }

    private static void Pulsar(MYGEspecificacionesEditor editor, string texto)
    {
        var boton = Herramientas(editor).Single(x => x.Name == "espec_" + texto);
        var propietario = boton;
        while (propietario.OwnerItem != null) propietario = propietario.OwnerItem;
        var pestana = propietario.Owner.Parent;
        while (pestana != null && pestana is not TabPage) pestana = pestana.Parent;
        if (pestana is TabPage tab && tab.Parent is TabControl cinta) cinta.SelectedTab = tab;
        boton.PerformClick();
    }

    private static void VerificarVista(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        var inicial = contadores();
        string rtf = editor.DocumentoRtf;
        documento.Select(1, 4);
        int posicion = documento.SelectionStart, longitud = documento.SelectionLength;
        var controles = Descendientes(editor).ToArray();
        var regla = controles.OfType<CheckBox>().SingleOrDefault(x => x.Name == "espec_regla");
        exige(regla != null, "La cinta debe incluir el control para mostrar u ocultar la regla.");
        regla.Checked = !regla.Checked;
        regla.Checked = !regla.Checked;
        var zoom = controles.OfType<NumericUpDown>().SingleOrDefault(x => x.Name == "espec_zoom");
        exige(zoom != null, "La cinta debe incluir el control de ampliación del documento.");
        zoom.Value = 125;
        Application.DoEvents();
        exige(Math.Abs(documento.ZoomFactor - 1.25f) < .01,
            "El documento debe admitir ampliación sin alterar el texto.");
        var papel = controles.Single(x => x.Name == "espec_papel");
        var lienzo = (Panel)controles.Single(x => x.Name == "espec_lienzo");
        foreach (Control destino in new Control[] { documento, papel, lienzo })
        {
            lienzo.AutoScrollPosition = Point.Empty;
            Rueda(destino, -120);
            exige(lienzo.AutoScrollPosition.Y < 0,
                "La rueda debe desplazar la hoja también sobre el texto, el margen y el fondo.");
            Rueda(destino, 120);
            exige(lienzo.AutoScrollPosition.Y == 0,
                "La rueda hacia arriba debe volver al inicio de la hoja.");
            Size anterior = papel.Size;
            double ampliacion = documento.ZoomFactor;
            Rueda(destino, 120, control: true, procesarMensajes: false);
            exige(editor.ZoomEnCurso && papel.Size == anterior && Math.Abs(documento.ZoomFactor - ampliacion) < .001,
                "Ctrl+rueda debe iniciar una transición sin saltar inmediatamente el papel ni el texto.");
            EsperarZoom(editor, exige);
            exige(papel.Width > anterior.Width && papel.Height > anterior.Height &&
                Math.Abs(documento.ZoomFactor - ampliacion * 1.08) < .002,
                "Ctrl+rueda debe ampliar proporcionalmente el papel y el texto hasta el destino común.");
            Rueda(destino, -120, control: true);
            EsperarZoom(editor, exige);
            exige(Math.Abs(documento.ZoomFactor - ampliacion) < .002 &&
                Math.Abs(papel.Width - anterior.Width) <= 1 && Math.Abs(papel.Height - anterior.Height) <= 1,
                "Ctrl+rueda hacia abajo debe restaurar las dimensiones de la hoja.");
        }
        zoom.Value = zoom.Maximum;
        Rueda(documento, 120, control: true);
        exige(zoom.Value == zoom.Maximum && Math.Abs(documento.ZoomFactor - 3f) < .01,
            "El límite superior debe impedir que RichEdit aplique un zoom independiente.");
        zoom.Value = zoom.Minimum;
        Rueda(documento, -120, control: true);
        exige(zoom.Value == zoom.Minimum && Math.Abs(documento.ZoomFactor - .25f) < .01,
            "El límite inferior debe impedir que RichEdit aplique un zoom independiente.");
        zoom.Value = 125;
        Size inicialFraccion = papel.Size;
        Rueda(documento, 60, control: true, procesarMensajes: false);
        exige(editor.ZoomEnCurso && zoom.Value > 125 && papel.Size == inicialFraccion,
            "Una fracción de rueda debe iniciar su propio recorrido sin esperar otro evento ni saltar de escala.");
        EsperarZoom(editor, exige);
        exige(papel.Width > inicialFraccion.Width && Math.Abs(documento.ZoomFactor - 1.25 * Math.Sqrt(1.08)) < .002,
            "Media rueda debe producir una ampliación proporcional intermedia.");
        Rueda(documento, 60, control: true);
        EsperarZoom(editor, exige);
        exige(Math.Abs(documento.ZoomFactor - 1.35) < .002,
            "Dos fracciones de rueda deben conservar el destino equivalente a un paso completo.");

        zoom.Value = 150;
        Rueda(documento, 120, control: true, procesarMensajes: false);
        Rueda(documento, 120, control: true, procesarMensajes: false);
        exige(zoom.Value == 175 && Math.Abs(documento.ZoomFactor - 1.5) < .002,
            "Una ráfaga debe acumular ambos destinos y conservar la escala dibujada hasta el siguiente cuadro.");
        EsperarZoom(editor, exige);
        exige(Math.Abs(documento.ZoomFactor - 1.5 * 1.08 * 1.08) < .002,
            "La transición de una ráfaga no debe perder solicitudes de rueda.");
        zoom.Value = 150;
        Rueda(documento, 240, control: true, procesarMensajes: false);
        Rueda(documento, -120, control: true, procesarMensajes: false);
        exige(zoom.Value < 150 && Math.Abs(documento.ZoomFactor - 1.5) < .002,
            "Invertir la rueda debe cancelar la ampliación pendiente sin introducir un salto visual.");
        EsperarZoom(editor, exige);
        exige(Math.Abs(documento.ZoomFactor - 1.5 / 1.08) < .002,
            "Invertir la rueda debe cambiar de sentido desde la escala actualmente dibujada.");

        zoom.Value = 150;
        lienzo.AutoScrollPosition = new Point(100, 200);
        Application.DoEvents();
        Point ancla = new(lienzo.ClientSize.Width / 2, lienzo.ClientSize.Height / 2);
        Point pantalla = lienzo.PointToScreen(ancla);
        double hojaX = (ancla.X - papel.Left) / (double)papel.Width;
        double hojaY = (ancla.Y - papel.Top) / (double)papel.Height;
        bool foco = documento.Focused;
        exige(lienzo.AutoScrollPosition.X < 0 && lienzo.AutoScrollPosition.Y < 0 &&
            hojaX > 0 && hojaX < 1 && hojaY > 0 && hojaY < 1,
            "La prueba de anclaje debe disponer de desplazamiento en ambos ejes y un punto interior de la hoja.");
        Rueda(documento, 120, control: true, puntoPantalla: pantalla, procesarMensajes: false);
        EsperarZoom(editor, exige);
        exige(Math.Abs(papel.Left + hojaX * papel.Width - ancla.X) <= 3 &&
            Math.Abs(papel.Top + hojaY * papel.Height - ancla.Y) <= 3,
            "Acercar debe conservar el mismo punto de la hoja bajo el cursor dentro de tres píxeles.");
        exige(documento.Focused == foco,
            "La rueda enviada sobre el documento debe conservar el foco durante la transición.");

        zoom.Value = 150;
        Rueda(documento, 120, control: true, procesarMensajes: false);
        zoom.Value = 90;
        exige(!editor.ZoomEnCurso, "Elegir manualmente otro zoom debe cancelar la transición pendiente.");
        ProcesarDurante(250);
        exige(zoom.Value == 90 && Math.Abs(documento.ZoomFactor - .9) < .002,
            "Un temporizador pendiente no debe sobrescribir el zoom elegido manualmente.");
        exige(editor.DocumentoRtf == rtf && contadores() == inicial &&
            documento.SelectionStart == posicion && documento.SelectionLength == longitud,
            "Desplazamiento, zoom animado, ráfagas, inversión y cambios manuales deben conservar documento, selección e historial.");
        int cambiosAntesOcultar = contadores().Cambios;
        zoom.Value = 150;
        Rueda(documento, 120, control: true, procesarMensajes: false);
        editor.Visible = false;
        exige(!editor.ZoomEnCurso, "Ocultar el editor debe cancelar la transición pendiente.");
        ProcesarDurante(250);
        editor.Visible = true;
        Application.DoEvents();
        exige(!editor.ZoomEnCurso && Math.Abs(documento.ZoomFactor - 1.5) < .002,
            "Volver a mostrar el editor no debe reproducir mensajes de zoom anteriores.");
        exige(editor.DocumentoRtf == rtf && contadores().Cambios == cambiosAntesOcultar,
            "Ocultar y mostrar el editor no debe guardar ni modificar la especificación.");
        // Recuperar el foco puede registrar legítimamente un estado anterior en Enter.
        inicial = contadores();
        zoom.Value = 125;
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            string salidaOriginal = editor.RtfParaArchivo;
            bool undoOriginal = documento.CanUndo;
            foreach (bool oscuro in new[] { true, false, true, false })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                Application.DoEvents();
                var tituloCabecera = controles.Single(x => x.Name == "espec_cabecera_titulo");
                var reglaHorizontal = controles.Single(x => x.Name == "espec_regla_horizontal");
                var grupo = controles.Single(x => x.Name == "espec_grupo_Ampliación");
                if (!SystemInformation.HighContrast)
                {
                    exige(oscuro ? papel.BackColor.GetBrightness() < .3f : papel.BackColor == Color.White,
                        "La hoja visible debe adoptar el modo oscuro y recuperar el papel blanco en modo normal.");
                    exige(oscuro ? grupo.BackColor.GetBrightness() < .3f && grupo.ForeColor.GetBrightness() > .7f
                        : grupo.BackColor.GetBrightness() > .7f,
                        "Los grupos de herramientas deben seguir la paleta con textos contrastados.");
                    exige(!oscuro || tituloCabecera.ForeColor.GetBrightness() > .7f &&
                        reglaHorizontal.ForeColor.GetBrightness() > .7f && zoom.BackColor.GetBrightness() < .3f,
                        "Cabecera, reglas y entrada de zoom deben tener contraste en modo oscuro.");

                    // Comprobar el dibujo real: DrawToBitmap/WM_PRINT conserva
                    // deliberadamente los colores originales para las salidas.
                    Rectangle visible = documento.RectangleToScreen(documento.ClientRectangle);
                    visible.Intersect(lienzo.RectangleToScreen(lienzo.ClientRectangle));
                    exige(visible.Width > 20 && visible.Height > 20, "La muestra visual requiere documento visible.");
                    using var muestra = new Bitmap(1, 1);
                    using (var grafico = Graphics.FromImage(muestra))
                        grafico.CopyFromScreen(new Point(visible.Right - 10, visible.Bottom - 10),
                            Point.Empty, new Size(1, 1));
                    Color esperado = oscuro ? Color.FromArgb(unchecked((int)0xff303640)) : Color.White;
                    exige(muestra.GetPixel(0, 0).ToArgb() == esperado.ToArgb(),
                        "El área vacía del texto debe pintarse con la misma paleta de la hoja, sin quedar blanca en oscuro.");
                }
                exige(editor.DocumentoRtf == rtf && editor.RtfParaArchivo == salidaOriginal &&
                    documento.CanUndo == undoOriginal && contadores() == inicial &&
                    documento.SelectionStart == posicion && documento.SelectionLength == longitud,
                    "Alternar el tema debe conservar RTF, colores de exportación, selección, Deshacer y callbacks.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal)
            {
                MYG2027_TemaComercial.Alternar(false);
                editor.AplicarTema();
            }
        }
        exige(editor.DocumentoRtf == rtf && contadores() == inicial,
            "Ampliación, regla o cambio de tema no deben modificar ni guardar la especificación.");
        Color fondoEsperado = MYG2027_TemaComercial.Oscuro && !SystemInformation.HighContrast
            ? Color.FromArgb(unchecked((int)0xff303640)) : Color.White;
        exige(documento.SelectionStart == posicion && documento.SelectionLength == longitud &&
            documento.BackColor.ToArgb() == fondoEsperado.ToArgb(),
            "Las opciones de vista deben conservar la selección y el fondo de página correspondiente al tema activo.");
    }

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }

    private static IEnumerable<ToolStripItem> Herramientas(Control padre) => Descendientes(padre)
        .OfType<ToolStrip>().SelectMany(x => Herramientas(x.Items));

    private static IEnumerable<ToolStripItem> Herramientas(ToolStripItemCollection items)
    {
        foreach (ToolStripItem item in items)
        {
            yield return item;
            if (item is ToolStripDropDownItem menu)
                foreach (var hijo in Herramientas(menu.DropDownItems)) yield return hijo;
        }
    }
}
