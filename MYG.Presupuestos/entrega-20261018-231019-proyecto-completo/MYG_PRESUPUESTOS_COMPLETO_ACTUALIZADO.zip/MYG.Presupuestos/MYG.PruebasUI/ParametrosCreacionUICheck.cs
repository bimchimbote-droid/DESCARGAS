using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class ParametrosCreacionUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-ParametrosCreacion-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        string rutaAnterior = MYGParametrosUsuario.RutaAlternativaPruebas;
        try
        {
            MYGParametrosUsuario.RutaAlternativaPruebas = Path.Combine(carpeta, "parametros.json");
            var parametros = MYGParametrosUsuario.Leer();
            parametros.UnidadPartida = "m²";
            parametros.UnidadInsumo = "caja";
            parametros.Proveedor = "Proveedor predeterminado";
            parametros.GastosGeneralesPorcentaje = 12m;
            parametros.UtilidadPorcentaje = 8m;
            parametros.ImpuestoPorcentaje = 18m;
            parametros.DecimalesPrecio = 3;
            parametros.DecimalesCantidad = 5;
            parametros.Rendimiento = 15m;
            parametros.PeriodoRendimiento = "Hora";
            parametros.UnidadAcero = "t";
            parametros.Aceros[0].PesoPorMetro = 0.123m;
            parametros.Aceros[0].Gancho = 0.15m;
            parametros.Aceros[0].Empalme = 0.25m;
            parametros.Aceros[0].DesperdicioPorcentaje = 5m;
            MYGParametrosUsuario.Guardar(parametros);
            MYGParametrosAplicacionUI.Actualizar();

            var proyecto = MYGProyectoStorage.Nuevo("Parámetros de creación", "EXISTENTE");
            var existente = proyecto.Presupuestos.Single();
            existente.Costos.GastosGeneralesPorcentaje = 3.21m;
            var insumoExistente = new MYGInsumo
            {
                Descripcion = "INSUMO EXISTENTE", Unidad = "kg", Proveedor = "Proveedor existente",
                Grupo = MYGGrupoRecurso.Materiales, Precio = 7.5m
            };
            existente.Costos.Insumos.Add(insumoExistente);
            MYGProyectoStorage.Validar(proyecto);
            string estadoExistente = Estado(existente);
            // La sesión se prepara sólo en memoria: estas comprobaciones no
            // consultan el servicio de licencia ni guardan credenciales.
            using var sesion = new SesionDesktop();
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial)).SetValue(sesion,
                new CredencialMYG { Usuario = "Pruebas locales" });
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
            using var editor = new EditorForm(proyecto, null, sesion);
            editor.Show(); Application.DoEvents();
            exige(Estado(existente) == estadoExistente,
                "Abrir un proyecto debe conservar los costos y los insumos existentes aunque cambien los parámetros predeterminados.");

            editor.AgregarPresupuestoEnTabla(); Application.DoEvents();
            var nuevo = proyecto.Presupuestos.Single(p => p.Id != existente.Id);
            var esperado = new MYGPresupuestoDocumento(); parametros.Aplicar(esperado);
            exige(Estado(nuevo.Costos) == Estado(esperado.Costos) && Estado(existente) == estadoExistente,
                "Agregar un presupuesto debe aplicar los parámetros guardados y conservar íntegro el presupuesto existente.");

            Invocar(editor, "InsertarEnEstructura", false, 0);
            var partida = nuevo.Items.Single();
            var partidaEsperada = new ItemPresupuestoDelphin { TipoPropuesta = "PARTIDA" };
            parametros.Aplicar(partidaEsperada);
            exige(partida.Unidad == parametros.UnidadPartida &&
                partida.Costos.RendimientoDiario == partidaEsperada.Costos.RendimientoDiario &&
                partida.Costos.JornadaHoras == partidaEsperada.Costos.JornadaHoras,
                "Crear una partida en la estructura debe usar su unidad, jornada y rendimiento, incluida la conversión del período por hora.");
            var panel = Campo<MYGPanelPresupuesto>(editor, "panelPresupuesto");
            panel.SeleccionarEstructura(nuevo);
            Invocar(editor, "InsertarEnEstructura", true, 0);
            exige(nuevo.Items.Single(MYGProyectoStorage.EsTitulo).Unidad == "" &&
                nuevo.Items.Single(MYGProyectoStorage.EsTitulo).Costos.RendimientoDiario == 1m,
                "Crear un título debe conservar su unidad vacía y no convertirlo en una partida con parámetros de ACU.");

            using (var selector = new MYGSelectorInsumoForm(nuevo, partida, null,
                Array.Empty<MYGUnidadCatalogo>(), null, MYGGrupoRecurso.Equipo))
            {
                var valor = Campo<MYGInsumoCampos>(selector, "campos").Leer();
                exige(valor.Unidad == parametros.UnidadInsumo && valor.Proveedor == parametros.Proveedor &&
                    valor.Grupo == MYGGrupoRecurso.Equipo,
                    "Crear un insumo desde el ACU debe usar la unidad y el proveedor predeterminados y conservar el tipo elegido.");
            }
            var recurso = new MYGRecursoACU { InsumoId = insumoExistente.Id, Grupo = insumoExistente.Grupo };
            using (var selector = new MYGSelectorInsumoForm(existente, partida, recurso,
                Array.Empty<MYGUnidadCatalogo>(), null))
            {
                var valor = Campo<MYGInsumoCampos>(selector, "campos").Leer();
                exige(valor.Unidad == insumoExistente.Unidad && valor.Proveedor == insumoExistente.Proveedor &&
                    valor.Precio == insumoExistente.Precio,
                    "Editar un insumo existente desde el ACU debe conservar sus datos y no reaplicar los parámetros nuevos.");
            }

            panel.SeleccionarEstructura(partida);
            panel.ConfirmarCambioPlantillaMetrado = _ => true;
            panel.ElegirPlantillaMetrado(MYGPlantillasMetrado.Aceros);
            exige(Estado(partida.Costos.Hoja) == Estado(parametros.CrearHojaAcero()),
                "Elegir la plantilla de fierros y aceros debe crear una hoja con los parámetros guardados.");
            string hojaAnterior = Estado(partida.Costos.Hoja);
            parametros.UnidadPartida = "m³"; MYGParametrosUsuario.Guardar(parametros);
            panel.ElegirPlantillaMetrado(MYGPlantillasMetrado.Aceros);
            exige(Estado(partida.Costos.Hoja) == hojaAnterior && Estado(existente) == estadoExistente,
                "Guardar parámetros o elegir de nuevo la plantilla activa debe conservar la hoja y los datos que ya existen.");

            panel.SeleccionarEstructura(nuevo);
            Invocar(panel, "CopiarResumenPie");
            editor.AgregarPresupuestoEnTabla();
            var destinoResumen = proyecto.Presupuestos.Last();
            destinoResumen.Costos.PiePersonalizado = null;
            destinoResumen.Costos.MostrarTotalPiePersonalizado = false;
            panel.SeleccionarEstructura(destinoResumen);
            Invocar(panel, "PegarResumenPie");
            exige(destinoResumen.Costos.MostrarTotalPiePersonalizado &&
                MYGPiePresupuesto.Filas(new[] { destinoResumen }).Last().Id == MYGPiePresupuesto.IdTotal,
                "Copiar y pegar un resumen creado con parámetros debe conservar su total visible.");

            panel.FinalizarEdicion();
            string documentoAnterior = MYGProyectoStorage.Firma(proyecto);
            File.WriteAllText(MYGParametrosUsuario.RutaPredeterminada, "{archivo inválido");
            bool rechazado = false;
            try { editor.AgregarPresupuestoEnTabla(); }
            catch (InvalidDataException) { rechazado = true; }
            exige(rechazado && MYGProyectoStorage.Firma(proyecto) == documentoAnterior,
                "Un archivo de parámetros inválido debe impedir la creación antes de modificar el proyecto o agregar un presupuesto parcial.");
        }
        finally
        {
            MYGParametrosUsuario.RutaAlternativaPruebas = rutaAnterior;
            MYGParametrosAplicacionUI.Actualizar();
            Directory.Delete(carpeta, recursive: true);
        }
    }

    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static object Invocar(object objeto, string nombre, params object[] argumentos) =>
        objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);
    private static string Estado(object objeto) => JsonSerializer.Serialize(objeto);
}
