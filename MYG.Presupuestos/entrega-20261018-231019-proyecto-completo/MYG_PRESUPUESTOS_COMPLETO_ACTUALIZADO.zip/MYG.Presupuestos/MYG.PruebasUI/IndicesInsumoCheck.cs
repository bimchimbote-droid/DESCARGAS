using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class IndicesInsumoCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var indices = MYGCatalogoIndicesUnificados.Listar();
        string inicial = indices.Single(x => x.Codigo == "21").ToString();
        string elegido = indices.Single(x => x.Codigo == "81").ToString();
        const string historico = "22 · Cemento Portland tipo II";

        foreach (string clasificacion in new[] { inicial, "", historico })
        {
            var documento = MYGProyectoStorage.Nuevo("ÍNDICE DEL INSUMO");
            documento.Datos = new MYGDatosProyecto { UsarUbicacion = false };
            var presupuesto = documento.Presupuestos.Single();
            var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
            partida.Descripcion = "PARTIDA DE PRUEBA";
            var otraPartida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
            otraPartida.Descripcion = "OTRA APARICIÓN DEL INSUMO";
            partida = presupuesto.Items.Single(x => x.Id == partida.Id);
            otraPartida = presupuesto.Items.Single(x => x.Id == otraPartida.Id);
            var insumo = new MYGInsumo { Codigo = "CEM-01", Descripcion = "CEMENTO", Unidad = "Bls",
                Precio = 28, GrupoGenerico = clasificacion };
            presupuesto.Costos.Insumos.Add(insumo);
            var recurso = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, null, new() { InsumoId = insumo.Id });
            var otroRecurso = MYGInsumosEdicion.Aplicar(presupuesto, otraPartida.Id, null, new() { InsumoId = insumo.Id });
            string firma = MYGProyectoStorage.Firma(documento);
            string textoInicial = clasificacion == "" ? "Sin índice asignado"
                : clasificacion == historico ? historico + " (clasificación existente)" : clasificacion;

            MYGSelectorInsumoForm Abrir() => new(presupuesto, partida, recurso,
                Array.Empty<MYGUnidadCatalogo>(), null);

            // Aceptar sin reclasificar conserva también los valores de bases antiguas.
            using (var sinCambios = Abrir())
            {
                ComprobarAlAbrir(sinCambios, textoInicial, exige);
                ((Button)sinCambios.AcceptButton).PerformClick();
                exige(sinCambios.DialogResult == DialogResult.OK &&
                    sinCambios.Seleccion.NuevoInsumo.GrupoGenerico == clasificacion &&
                    MYGProyectoStorage.Firma(documento) == firma,
                    "Aceptar sin editar perdió el índice existente o cambió el presupuesto antes de aplicar.");
                recurso = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, recurso.Id, sinCambios.Seleccion);
                exige(MYGProyectoStorage.Firma(documento) == firma,
                    "Aplicar una edición sin reclasificar cambió el índice existente del insumo.");
                sinCambios.Close();
            }

            using (var editar = Abrir())
            {
                var selector = ComprobarAlAbrir(editar, textoInicial, exige);
                Elegir(selector, elegido);
                editar.BindingContext = new BindingContext();
                Application.DoEvents();
                exige(selector.GetItemText(selector.SelectedItem) == elegido,
                    "Renovar BindingContext perdió el índice elegido explícitamente.");
                ((Button)editar.AcceptButton).PerformClick();
                exige(editar.DialogResult == DialogResult.OK && editar.Seleccion.EditarCompartido &&
                    editar.Seleccion.NuevoInsumo.GrupoGenerico == elegido &&
                    MYGProyectoStorage.Firma(documento) == firma,
                    "Aceptar Editar y reemplazar perdió el índice elegido o publicó cambios antes de aplicar.");
                recurso = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, recurso.Id, editar.Seleccion);
                exige(presupuesto.Costos.Insumos.Count == 1 &&
                    presupuesto.Costos.Insumos.Single(x => x.Id == recurso.InsumoId).GrupoGenerico == elegido &&
                    presupuesto.Costos.Insumos.Single(x => x.Id == otroRecurso.InsumoId).GrupoGenerico == elegido,
                    "Editar y reemplazar no conservó el índice en las apariciones del insumo compartido.");
                editar.Close();
            }

            firma = MYGProyectoStorage.Firma(documento);
            using (var reabrir = Abrir())
            {
                var selector = ComprobarAlAbrir(reabrir, elegido, exige);
                Elegir(selector, inicial);
                ((Button)reabrir.CancelButton).PerformClick();
                exige(reabrir.DialogResult == DialogResult.Cancel && MYGProyectoStorage.Firma(documento) == firma,
                    "Cancelar una reclasificación al reabrir modificó el índice guardado.");
                reabrir.Close();
            }

            using (var quitar = Abrir())
            {
                var selector = ComprobarAlAbrir(quitar, elegido, exige);
                Elegir(selector, "Sin índice asignado");
                ((Button)quitar.AcceptButton).PerformClick();
                exige(quitar.DialogResult == DialogResult.OK && quitar.Seleccion.NuevoInsumo.GrupoGenerico == "",
                    "Elegir Sin índice asignado no eliminó la clasificación explícitamente.");
                recurso = MYGInsumosEdicion.Aplicar(presupuesto, partida.Id, recurso.Id, quitar.Seleccion);
                quitar.Close();
            }

            using (var sinIndice = Abrir())
            {
                ComprobarAlAbrir(sinIndice, "Sin índice asignado", exige);
                exige(presupuesto.Costos.Insumos.Single().GrupoGenerico == "",
                    "Reabrir el editor recuperó un índice que se había quitado.");
                sinIndice.Close();
            }
        }
    }

    private static ComboBox ComprobarAlAbrir(MYGSelectorInsumoForm formulario, string esperado,
        Action<bool, string> exige)
    {
        var selector = Controles(formulario).OfType<ComboBox>()
            .Single(x => x.AccessibleName == "Grupo genérico, índice unificado");
        exige(selector.GetItemText(selector.SelectedItem) == esperado,
            "El constructor de Editar y reemplazar no conserva el índice del insumo.");
        formulario.Show();
        Application.DoEvents();
        exige(selector.GetItemText(selector.SelectedItem) == esperado,
            "Mostrar Editar y reemplazar cambió el índice del insumo.");
        formulario.BindingContext = new BindingContext();
        Application.DoEvents();
        exige(selector.GetItemText(selector.SelectedItem) == esperado,
            "Renovar BindingContext cambió el índice existente del insumo.");
        return selector;
    }

    private static void Elegir(ComboBox selector, string texto) => selector.SelectedIndex =
        Enumerable.Range(0, selector.Items.Count).Single(n => selector.GetItemText(selector.Items[n]) == texto);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
