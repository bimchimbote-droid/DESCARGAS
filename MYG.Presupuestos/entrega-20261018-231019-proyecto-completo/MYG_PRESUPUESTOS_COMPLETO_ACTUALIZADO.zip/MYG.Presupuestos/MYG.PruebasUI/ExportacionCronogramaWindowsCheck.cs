using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class ExportacionCronogramaWindowsCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-ExportacionCronograma-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("EXPORTACIÓN NATIVA", "PRESUPUESTO");
            var plan = MYGMotorCronograma.CrearDesdePresupuestos(proyecto);
            var primera = MYGMotorCronograma.AgregarTarea(plan, null, "Excavación");
            primera.DuracionDias = 3;
            var segunda = MYGMotorCronograma.AgregarTarea(plan, null, "Cimentación");
            segunda.Predecesoras.Add(new() { PredecesoraId = primera.Id, Tipo = MYGTipoVinculo.FC, DesfaseDias = -1 });
            primera = plan.Tareas.Single(t => t.Id == primera.Id);
            primera.Avance = 25;
            primera.Responsables.Add("Residente");
            plan.Calendario.Feriados.Add(new DateTime(2026, 7, 28));
            MYGMotorCronograma.EstablecerLineaBase(plan);
            string firmaDocumento = JsonSerializer.Serialize(proyecto), firmaPlan = JsonSerializer.Serialize(plan);
            string destino = Path.Combine(carpeta, "cronograma.sqlite");
            MYGExportacionCronogramaWindows.GuardarNativo(destino, proyecto, plan);
            var recuperado = MYGBaseDatos.LeerProyecto(destino, proyecto.Id);
            exige(recuperado.Id == proyecto.Id && recuperado.Presupuestos[0].Id == proyecto.Presupuestos[0].Id &&
                JsonSerializer.Serialize(recuperado.Cronograma) == firmaPlan &&
                recuperado.Cronograma.Tareas.Single(t => t.Id == primera.Id).Avance == 25 &&
                recuperado.Cronograma.Tareas.Single(t => t.Id == primera.Id).Responsables.Contains("Residente"),
                "El archivo nativo debe reabrir el proyecto y conservar tareas, vínculos, responsables, avance, calendario y línea base.");
            exige(JsonSerializer.Serialize(proyecto) == firmaDocumento && JsonSerializer.Serialize(plan) == firmaPlan &&
                proyecto.Cronograma == null,
                "Exportar el cronograma temporal debe conservar intactos el documento abierto y el plan recibido.");

            byte[] antes = File.ReadAllBytes(destino);
            foreach (string extension in new[] { "xml", "txt", "csv", "pdf", "mht", "xlsx" })
                Rechaza(() => MYGExportacionCronogramaWindows.ValidarDestino(destino, extension, destino), exige,
                    "Un destino con extensión incorrecta no debe permitir reemplazar la hoja abierta desde " + extension + ".");
            Rechaza(() => MYGExportacionCronogramaWindows.ValidarDestino(destino, "sqlite", destino), exige,
                "La validación común debe rechazar la hoja abierta también cuando la extensión coincide.");
            MYGExportacionCronogramaWindows.ValidarDestino(Path.Combine(carpeta, "seguro.xml"), "xml", destino);
            Rechaza(() => MYGExportacionCronogramaWindows.GuardarNativo(destino, proyecto, plan, destino), exige,
                "Exportar al archivo SQLite de origen debe rechazarse antes de escribir.");
            exige(antes.SequenceEqual(File.ReadAllBytes(destino)), "Rechazar la ruta de origen debe conservar el archivo original byte a byte.");
            Rechaza(() => MYGExportacionCronogramaWindows.GuardarNativo(Path.Combine(carpeta, "falso.DelphinExpress"), proyecto, plan), exige,
                "El archivo MYG no debe hacerse pasar por el formato propietario DelphinExpress.");
            Rechaza(() => MYGExportacionCronogramaWindows.GuardarProject(Path.Combine(carpeta, "falso.xml"), proyecto, plan, false), exige,
                "La ruta MPP debe validarse sin iniciar Microsoft Project ni escribir XML con una extensión distinta.");
            Rechaza(() => MYGExportacionCronogramaWindows.GuardarProject(Path.Combine(carpeta, "invalido.mpp"), null, plan, true), exige,
                "Un proyecto nulo debe rechazarse sin activar la automatización de Microsoft Project.");

            using (var bloqueado = new FileStream(destino, FileMode.Open, FileAccess.Read, FileShare.None))
                Rechaza(() => MYGExportacionCronogramaWindows.GuardarNativo(destino, proyecto, plan), exige,
                    "Un destino abierto con bloqueo exclusivo debe rechazarse sin reemplazarlo.");
            exige(antes.SequenceEqual(File.ReadAllBytes(destino)), "Un error de bloqueo debe conservar el archivo de destino sin cambios.");

            var invalido = MYGProyectoStorage.Copia(plan);
            invalido.Tareas.Last().Predecesoras.Add(new() { PredecesoraId = "NO-EXISTE" });
            Rechaza(() => MYGExportacionCronogramaWindows.GuardarNativo(destino, proyecto, invalido), exige,
                "Un vínculo inválido debe rechazarse antes de reemplazar el archivo existente.");
            exige(antes.SequenceEqual(File.ReadAllBytes(destino)), "Un plan inválido debe conservar el destino anterior byte a byte.");

            VerificarCopiaDeHoja(carpeta, proyecto, plan, exige);
            exige(!Directory.EnumerateFiles(carpeta).Any(r => Path.GetFileName(r).StartsWith(".myg-cronograma-", StringComparison.Ordinal)),
                "La exportación nativa debe limpiar sus archivos temporales tras éxito y rechazo.");
        }
        finally
        {
            SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void VerificarCopiaDeHoja(string carpeta, MYGProyectoDocumento proyecto, MYGCronograma plan,
        Action<bool, string> exige)
    {
        string origen = Path.Combine(carpeta, "origen.sqlite"), destino = Path.Combine(carpeta, "copia.sqlite");
        MYGBaseDatos.GuardarProyecto(origen, MYGProyectoStorage.Copia(proyecto));
        var otro = MYGProyectoStorage.Nuevo("OTRO PROYECTO DE LA HOJA");
        MYGBaseDatos.GuardarProyecto(origen, otro);
        using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = origen, Pooling = false }.ToString()))
        {
            conexion.Open();
            using var comando = conexion.CreateCommand();
            comando.CommandText = "CREATE TABLE extension_qa(dato TEXT); INSERT INTO extension_qa VALUES('conservar');";
            comando.ExecuteNonQuery();
        }
        string huella = Huella(origen);
        MYGExportacionCronogramaWindows.GuardarNativo(destino, proyecto, plan, origen);
        exige(Huella(origen) == huella && MYGBaseDatos.LeerProyecto(origen, proyecto.Id).Cronograma == null,
            "Exportar desde una hoja existente debe dejar el SQLite original y su cronograma guardado sin modificaciones.");
        exige(MYGBaseDatos.ListarProyectos(destino).Count == 2 &&
            MYGBaseDatos.LeerProyecto(destino, otro.Id).Nombre == otro.Nombre &&
            JsonSerializer.Serialize(MYGBaseDatos.LeerProyecto(destino, proyecto.Id).Cronograma) == JsonSerializer.Serialize(plan),
            "La copia de una hoja existente debe conservar sus demás proyectos y actualizar sólo la copia del cronograma exportado.");
        using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = destino, Pooling = false }.ToString()))
        {
            conexion.Open();
            using var comando = conexion.CreateCommand();
            comando.CommandText = "SELECT dato FROM extension_qa";
            exige(comando.ExecuteScalar() as string == "conservar", "La copia nativa debe conservar las tablas de origen no representadas por el editor.");
        }
        // Reemplazar un destino cerrado también debe funcionar atómicamente.
        var editado = MYGProyectoStorage.Copia(plan);
        editado.Tareas.Last().Nombre = "Cronograma actualizado";
        MYGExportacionCronogramaWindows.GuardarNativo(destino, proyecto, editado, origen);
        exige(MYGBaseDatos.LeerProyecto(destino, proyecto.Id).Cronograma.Tareas.Last().Nombre == "Cronograma actualizado" && Huella(origen) == huella,
            "Reexportar a un destino cerrado debe reemplazarlo por el cronograma nuevo y conservar la hoja de trabajo original.");
    }

    private static string Huella(string ruta)
    { using var archivo = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(archivo)); }

    private static void Rechaza(Action accion, Action<bool, string> exige, string mensaje)
    {
        bool rechazo = false;
        try { accion(); }
        catch (Exception ex) when (ex is ArgumentException || ex is InvalidOperationException || ex is IOException || ex is InvalidDataException)
        { rechazo = true; }
        exige(rechazo, mensaje);
    }
}
