using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using MYG_2027;

// Comprueba el contrato del helper con una bolsa de propiedades, sin emular
// el motor de programación de Office ni sustituir su validación en Windows.
internal static class ProjectTareaManualConfiguracionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var datos = Tarea();
        var texto = Texto();
        var datosOriginales = datos with { };
        var textoOriginal = texto with { };
        var campos = new CamposTarea(datos, texto);
        // Forzar diferencias en las lecturas tipadas comprueba que el contrato
        // valida los textos introducidos. No afirma cómo los recalcula Office.
        campos.Valores["Start"] = datos.Inicio.AddDays(5);
        campos.Valores["Finish"] = datos.Inicio.AddDays(7);
        campos.Valores["Duration"] = 2400d;
        MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer);
        exige(campos.Lecturas.SequenceEqual(new[] { "Manual", "StartText", "FinishText", "DurationText" }) &&
            datos.Fin - datos.Inicio > TimeSpan.FromDays(100) && datos.DuracionMinutos == 960,
            "Los textos manuales de enero a octubre y duración de 960 minutos deben validarse como campos introducidos por el exportador.");

        campos.Valores["StartText"] = "inicio desplazado tras avance o cálculo";
        campos.Valores["FinishText"] = "fin desplazado tras avance o cálculo";
        campos.Valores["DurationText"] = "duración recalculada";
        MYGConfiguracionTareaManualProject.Restaurar(texto, campos.Leer, campos.Escribir);
        MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer);
        exige(campos.Escrituras.Select(e => e.Campo).SequenceEqual(new[] { "StartText", "FinishText", "DurationText" }) &&
            (string)campos.Valores["StartText"] == texto.Inicio && (string)campos.Valores["FinishText"] == texto.Fin &&
            (string)campos.Valores["DurationText"] == texto.Duracion && (DateTime)campos.Valores["Start"] != datos.Inicio,
            "Restaurar los valores movidos debe escribir los campos manuales sin sobrescribir lecturas tipadas ni cambiar a modo automático.");

        campos.Escrituras.Clear();
        MYGConfiguracionTareaManualProject.Restaurar(texto, campos.Leer, campos.Escribir);
        exige(campos.Escrituras.Count == 0,
            "Restaurar una tarea manual con textos idénticos no debe provocar escrituras ni recálculos adicionales.");
        campos.Valores["DurationText"] = "  960 MIN  ";
        MYGConfiguracionTareaManualProject.Restaurar(texto, campos.Leer, campos.Escribir);
        exige(campos.Escrituras.Count == 0,
            "Las diferencias de mayúsculas y espacios exteriores en el texto manual no deben forzar escrituras equivalentes.");

        campos = new CamposTarea(datos, texto);
        campos.Valores["Manual"] = false;
        campos.Valores["StartText"] = "otro inicio";
        MYGConfiguracionTareaManualProject.Restaurar(texto, campos.Leer, campos.Escribir);
        MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer);
        exige(campos.Escrituras.Select(e => e.Campo).SequenceEqual(new[] { "Manual", "StartText" }) &&
            campos.Escrituras[0].Valor is true,
            "Una tarea convertida a automática debe recuperar primero el modo manual y después sus textos, sin volver a activar la programación automática.");

        campos = new CamposTarea(datos, texto);
        campos.Valores["StartText"] = "";
        campos.Valores["FinishText"] = " ";
        campos.Valores["DurationText"] = null;
        MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer);
        exige(campos.Lecturas.Contains("Start") && campos.Lecturas.Contains("Finish") &&
            campos.Lecturas.Contains("Duration") && campos.Escrituras.Count == 0,
            "Si Office devuelve los textos vacíos, los valores numéricos exactos de inicio, fin y duración deben permitir la validación sin reescribir la tarea.");

        VerificarRechazos(datos, texto, exige);
        VerificarTextosNormalizados(exige);
        exige(datos == datosOriginales && texto == textoOriginal,
            "Restaurar y verificar la tarea manual, incluidos los rechazos, debe conservar intactos los datos originales y sus textos de exportación.");
    }

    private static void VerificarRechazos(MYGTareaExportacionProject datos, MYGTextoTareaManualProject texto,
        Action<bool, string> exige)
    {
        foreach (string campo in new[] { "inicio", "fin", "duración", "modo" })
        {
            var campos = new CamposTarea(datos, texto);
            string esperado, recibido;
            switch (campo)
            {
                case "inicio":
                    campos.Valores["StartText"] = recibido = "inicio alterado";
                    campos.Valores["Start"] = datos.Inicio.AddDays(1);
                    esperado = texto.Inicio;
                    break;
                case "fin":
                    campos.Valores["FinishText"] = recibido = "fin alterado";
                    campos.Valores["Finish"] = datos.Fin.AddDays(-1);
                    esperado = texto.Fin;
                    break;
                case "duración":
                    campos.Valores["DurationText"] = recibido = "duración alterada";
                    campos.Valores["Duration"] = datos.DuracionMinutos + 1;
                    esperado = texto.Duracion;
                    break;
                default:
                    campos.Valores["Manual"] = false;
                    esperado = "manual";
                    recibido = "automático";
                    break;
            }
            Exception fallo = Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer));
            exige(fallo is InvalidOperationException && fallo.Message.Contains(campo, StringComparison.Ordinal) &&
                fallo.Message.Contains(datos.Nombre, StringComparison.Ordinal) &&
                fallo.Message.Contains("Esperado: " + esperado, StringComparison.Ordinal) &&
                fallo.Message.Contains("recibido: " + recibido, StringComparison.Ordinal) &&
                fallo.Message.Contains("No se reemplazó el archivo de destino", StringComparison.Ordinal) &&
                campos.Escrituras.Count == 0,
                "Una alteración real del " + campo + " manual debe abortar con nombre de tarea, campo, esperado y recibido, conservando la protección del archivo de destino.");
        }
        foreach (string campo in new[] { "StartText", "FinishText", "DurationText" })
        {
            var campos = new CamposTarea(datos, texto);
            campos.Valores[campo] = "texto visible incorrecto";
            Exception fallo = Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer));
            exige(fallo is InvalidOperationException && fallo.Message.Contains("recibido: texto visible incorrecto", StringComparison.Ordinal) &&
                campos.Escrituras.Count == 0,
                "Un texto visible incorrecto en " + campo + " debe rechazarse aunque su valor numérico interno siga coincidiendo con el original.");
        }
        foreach (object valor in new object[] { null, "960", "no numérica", new object(), double.MaxValue })
        {
            var campos = new CamposTarea(datos, texto);
            campos.Valores["DurationText"] = "";
            campos.Valores["Duration"] = valor;
            Exception fallo = Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer));
            exige(fallo is InvalidOperationException && fallo.Message.Contains("duración", StringComparison.Ordinal),
                "Una duración tipada ausente, textual o no convertible debe rechazarse con el diagnóstico de exportación cuando no hay texto manual que validar.");
        }
    }

    private static void VerificarTextosNormalizados(Action<bool, string> exige)
    {
        var datos = Tarea() with { Inicio = new DateTime(2024, 12, 3, 8, 0, 0),
            Fin = new DateTime(2024, 12, 9, 17, 0, 0), DuracionMinutos = 1920 };
        var texto = new MYGTextoTareaManualProject("3 diciembre 2024 08:00", "9 diciembre 2024 17:00", "1920 min");
        CultureInfo culturaAnterior = CultureInfo.CurrentCulture;
        try
        {
            foreach (string idioma in new[] { "es-PE", "es-ES" })
            {
                CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo(idioma);
                var campos = Normalizados();
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) == null &&
                    campos.Lecturas.Contains("Start") && campos.Lecturas.Contains("Finish") && campos.Escrituras.Count == 0,
                    "La representación «mar 3/12/24» de la captura debe aceptarse en " + idioma + " cuando las fechas tipadas conservan día y hora exactos.");
                campos.Valores["StartText"] = "mar 3/12/24 08:00";
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) == null,
                    "Una fecha localizada con hora explícita y día de la semana debe conservar el mismo valor en " + idioma + ".");

                foreach (object alterada in new object[] { datos.Inicio.AddDays(1), datos.Inicio.AddHours(1), null, "03/12/2024 08:00" })
                {
                    campos = Normalizados();
                    campos.Valores["Start"] = alterada;
                    exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) is InvalidOperationException,
                        "Una vista sin hora no debe ocultar un día/hora tipado distinto ni inferir la hora si no existe un DateTime válido, en " + idioma + ".");
                }
                foreach (string alterada in new[] { "mié 4/12/24", "mar 3/12/24 09:00", "3/12", "fecha arbitraria" })
                {
                    campos = Normalizados();
                    campos.Valores["StartText"] = alterada;
                    exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) is InvalidOperationException,
                        "Un texto visible con día/hora distinto, sin año o inválido debe rechazarse aunque el DateTime sea correcto, en " + idioma + ".");
                }
                campos = Normalizados();
                campos.Valores["StartText"] = "mar 3/12/24 08:00";
                campos.Valores["Start"] = datos.Inicio.AddHours(1);
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) is InvalidOperationException,
                    "La normalización con hora explícita tampoco debe ocultar una hora tipada alterada en " + idioma + ".");

                campos = Normalizados();
                campos.Valores["DurationText"] = "32 horas";
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) == null,
                    "La normalización de minutos a horas debe aceptarse solo si los minutos tipados y el texto coinciden.");
                campos.Valores["Duration"] = 1921d;
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) is InvalidOperationException,
                    "Una duración numérica modificada debe rechazarse aunque las horas visibles sean las originales.");
                campos.Valores["Duration"] = 1920d;
                campos.Valores["DurationText"] = "31 horas";
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer)) is InvalidOperationException,
                    "Una duración visible modificada debe rechazarse aunque los minutos tipados sean los originales.");

                campos = Normalizados();
                campos.Valores["DurationText"] = "4 días";
                var conversiones = new List<string>();
                object Interpretar(string valor) { conversiones.Add(valor); return valor == "4 días" ? 1920d : 0d; }
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer, Interpretar)) == null &&
                    conversiones.SequenceEqual(new[] { "4 días" }),
                    "Los días de Project deben convertirse mediante DurationValue y compararse con los minutos exactos, sin inventar horas por día.");
                campos.Valores["DurationText"] = "3 días";
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer, Interpretar)) is InvalidOperationException,
                    "Una conversión Office que revela otra duración debe rechazarse aunque Duration conserve el número previo.");
                campos.Valores["DurationText"] = "4 días";
                exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, campos.Leer,
                    _ => throw new FormatException("Texto no reconocido"))) is InvalidOperationException,
                    "Un fallo de interpretación de Project debe conservar el diagnóstico y la protección del archivo de destino.");
            }
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("en-US");
            var ambiguos = Normalizados();
            ambiguos.Valores["StartText"] = "3/12/24";
            exige(Capturar(() => MYGConfiguracionTareaManualProject.Verificar(datos, texto, ambiguos.Leer)) is InvalidOperationException,
                "No se deben probar culturas alternativas para convertir una fecha ambigua incompatible con la cultura activa.");
        }
        finally { CultureInfo.CurrentCulture = culturaAnterior; }

        CamposTarea Normalizados()
        {
            var campos = new CamposTarea(datos, texto);
            campos.Valores["StartText"] = "mar 3/12/24";
            campos.Valores["FinishText"] = "lun 9/12/24";
            return campos;
        }
    }

    private static MYGTareaExportacionProject Tarea() =>
        new(2, "alquiler", 1, 2, "1.1", "01.01", "ALQUILER DE ALMACÉN, OFICINA Y GUARDIANÍA", true,
            false, false, false, new DateTime(2026, 1, 5, 8, 0, 0), new DateTime(2026, 10, 1, 17, 0, 0),
            960, 25, null, null, null, "Fechas originales");

    private static MYGTextoTareaManualProject Texto() =>
        new("05/01/2026 08:00", "01/10/2026 17:00", "960 min");

    private static Exception Capturar(Action accion)
    {
        try { accion(); return null; }
        catch (Exception ex) { return ex; }
    }

    private sealed class CamposTarea
    {
        internal readonly Dictionary<string, object> Valores;
        internal readonly List<string> Lecturas = new();
        internal readonly List<(string Campo, object Valor)> Escrituras = new();

        internal CamposTarea(MYGTareaExportacionProject datos, MYGTextoTareaManualProject texto) =>
            Valores = new(StringComparer.Ordinal)
            {
                ["Manual"] = true, ["StartText"] = texto.Inicio, ["FinishText"] = texto.Fin,
                ["DurationText"] = texto.Duracion, ["Start"] = datos.Inicio, ["Finish"] = datos.Fin,
                ["Duration"] = (double)datos.DuracionMinutos
            };

        internal object Leer(string campo)
        {
            Lecturas.Add(campo);
            return Valores[campo];
        }

        internal void Escribir(string campo, object valor)
        {
            Escrituras.Add((campo, valor));
            Valores[campo] = valor;
        }
    }
}
