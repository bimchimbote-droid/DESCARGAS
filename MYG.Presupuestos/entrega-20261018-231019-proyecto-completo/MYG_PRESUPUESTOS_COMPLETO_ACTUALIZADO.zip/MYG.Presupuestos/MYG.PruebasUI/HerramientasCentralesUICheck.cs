using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class HerramientasCentralesUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        int tamanoOriginal = MYGTamanoTextoUI.Porcentaje;
        try
        {
            MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
            VerificarBarra(exige);
            VerificarHerramientasSistema(exige);
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
            MYGTamanoTextoUI.Cambiar(tamanoOriginal, guardarPreferencia: false);
        }
    }

    private static void VerificarBarra(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Herramientas centrales", "ESTRUCTURAS");
        var primero = proyecto.Presupuestos.Single();
        primero.Item = "01";
        var titulo = Partida("01", "TÍTULO", 1); titulo.TipoPropuesta = "TITULO";
        var partida = Partida("01.01", "PARTIDA DE ORIGEN", 2); partida.ParentId = titulo.Id;
        primero.Items.AddRange(new[] { titulo, partida });
        var segundo = new MYGPresupuestoDocumento { Item = "02", Nombre = "PRESUPUESTO DE DESTINO", Posicion = 2 };
        var destino = Partida("01", "PARTIDA DE DESTINO", 1);
        segundo.Items.Add(destino); proyecto.Presupuestos.Add(segundo);
        MYGProyectoStorage.Validar(proyecto);

        var activo = primero;
        bool autorizado = true, disponible = true, hayCopia = false, permitirSubir = true, permitirBajar = true;
        bool esperarRecalculo = false;
        int antes = 0, despues = 0, guardados = 0;
        var acciones = new List<(string Comando, object Nodo)>();
        var movimientos = new List<(object Nodo, int Sentido)>();
        TaskCompletionSource<bool> pendiente = null;
        using var panel = new MYGPanelPresupuesto(() => activo, () => antes++, () => despues++,
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto,
            id => { if (id != null) activo = proyecto.Presupuestos.Single(p => p.Id == id); }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        panel.InicializarCatalogos(() => null, () => autorizado, () => { });
        panel.InicializarHerramientas(
            (nodo, sentido) => nodo != null && (sentido < 0 ? permitirSubir : permitirBajar),
            (nodo, sentido) => movimientos.Add((nodo, sentido)), () => guardados++);
        panel.InicializarAccionesEstructura(() => disponible, () => hayCopia, (comando, nodo) =>
        {
            acciones.Add((comando, nodo));
            if (comando == "copiar") hayCopia = true;
            if (comando == "recalcular" && esperarRecalculo)
            {
                disponible = false; panel.ActualizarHerramientas();
                return pendiente.Task;
            }
            return Task.CompletedTask;
        });
        using var formulario = new Form { ClientSize = new Size(1600, 900) };
        formulario.Controls.Add(panel); formulario.Show();
        panel.Refrescar(); panel.SeleccionarEstructura(partida); Application.DoEvents();

        var barra = Controles(panel).OfType<ToolStrip>().Single(t => t.Name == "barraHerramientasEstructura");
        var division = Controles(panel).OfType<SplitContainer>().Single(s => s.Name == "divisionPresupuesto");
        var estructura = Controles(panel).OfType<DataGridView>().Single(t => t.Columns.Contains("EXP"));
        var botones = barra.Items.OfType<ToolStripButton>().ToArray();
        string[] nombres =
        {
            "alternarDetallePresupuesto", "subirFilaEstructura", "bajarFilaEstructura", "eliminarFilaEstructura",
            "copiarFilaEstructura", "pegarFilaEstructura", "recalcularEstructura", "fuenteEstructura",
            "lupaPresupuesto", "calculadoraPresupuesto", "grabarCostosMultiplesEstructura"
        };
        exige(botones.Select(b => b.Name).SequenceEqual(nombres),
            "La franja central debe ofrecer exactamente las once herramientas solicitadas y en el orden de la referencia.");
        exige(barra.ShowItemToolTips && !string.IsNullOrWhiteSpace(barra.AccessibleName) &&
            botones.All(b => b.Image != null && b.Image.Width > 0 && b.Image.Height > 0 &&
                b.DisplayStyle == ToolStripItemDisplayStyle.Image && !string.IsNullOrWhiteSpace(b.ToolTipText) &&
                b.AccessibleName == b.ToolTipText),
            "Cada herramienta central debe tener icono, ayuda y nombre accesible, sin depender del texto visible.");
        VerificarDisposicion();
        string firma = MYGProyectoStorage.Firma(proyecto);
        object seleccion = panel.SeleccionEstructura;
        int anchoAnterior = division.SplitterDistance;
        int ventanas = Application.OpenForms.Count;
        var alternar = Boton("alternarDetallePresupuesto");
        exige(alternar.Checked && alternar.ToolTipText.Contains("Ocultar", StringComparison.OrdinalIgnoreCase),
            "El botón de detalle debe indicar que el panel está visible antes de ocultarlo.");
        alternar.PerformClick(); Application.DoEvents();
        exige(division.Panel2Collapsed && barra.Visible && !alternar.Checked &&
            alternar.ToolTipText.Contains("Mostrar", StringComparison.OrdinalIgnoreCase),
            "Ocultar detalle debe ampliar la estructura y conservar visible el acceso para restaurarlo.");
        VerificarDisposicion();
        alternar.PerformClick(); Application.DoEvents();
        exige(!division.Panel2Collapsed && alternar.Checked && division.SplitterDistance == anchoAnterior &&
            ReferenceEquals(panel.SeleccionEstructura, seleccion),
            "Restaurar detalle debe recuperar su proporción y la misma selección de estructura.");
        VerificarDisposicion();
        exige(MYGProyectoStorage.Firma(proyecto) == firma && antes == 0 && despues == 0,
            "Ocultar y restaurar detalle no debe cambiar el proyecto ni agregar historial.");

        exige(!Boton("pegarFilaEstructura").Enabled, "Pegar debe iniciar deshabilitado mientras no exista una copia.");
        Boton("pegarFilaEstructura").PerformClick();
        exige(acciones.Count == 0, "Pegar deshabilitado no debe despachar acciones.");
        foreach (object origen in new object[] { primero, titulo, partida })
        {
            panel.SeleccionarEstructura(origen); Application.DoEvents();
            PulsarAccion("copiarFilaEstructura", "copiar", origen);
            exige(Boton("pegarFilaEstructura").Enabled, "Copiar debe habilitar Pegar sin reconstruir el editor.");
            panel.SeleccionarEstructura(destino); Application.DoEvents();
            PulsarAccion("pegarFilaEstructura", "pegar", destino);
            exige(ReferenceEquals(activo, segundo) && ReferenceEquals(panel.SeleccionEstructura, destino),
                "Pegar debe enviar la selección del presupuesto de destino, aunque se haya copiado en otro presupuesto.");
        }
        foreach (object nodo in new object[] { primero, titulo, partida })
        {
            panel.SeleccionarEstructura(nodo); Application.DoEvents();
            PulsarAccion("eliminarFilaEstructura", "eliminar", nodo);
            int cantidadMovimientos = movimientos.Count;
            Boton("subirFilaEstructura").PerformClick(); Boton("bajarFilaEstructura").PerformClick();
            Boton("grabarCostosMultiplesEstructura").PerformClick();
            exige(movimientos.Count == cantidadMovimientos + 2 &&
                ReferenceEquals(movimientos[^2].Nodo, nodo) && movimientos[^2].Sentido == -1 &&
                ReferenceEquals(movimientos[^1].Nodo, nodo) && movimientos[^1].Sentido == 1,
                "Subir y bajar deben conservar el callback anterior y enviar el nodo y sentido seleccionados.");
        }
        exige(guardados == 3, "Grabar data debe conservar su callback anterior y ejecutarlo una sola vez por clic.");
        permitirSubir = false; permitirBajar = true; panel.ActualizarHerramientas();
        exige(!Boton("subirFilaEstructura").Enabled && Boton("bajarFilaEstructura").Enabled,
            "Los extremos de la estructura deben respetar la disponibilidad independiente de subir y bajar.");
        permitirSubir = true; permitirBajar = false; panel.ActualizarHerramientas();
        exige(Boton("subirFilaEstructura").Enabled && !Boton("bajarFilaEstructura").Enabled,
            "Cambiar de extremo debe actualizar los permisos de movimiento sin reconstruir la barra.");
        permitirBajar = true;

        autorizado = false; panel.ActualizarHerramientas();
        string[] modifican = { "subirFilaEstructura", "bajarFilaEstructura", "eliminarFilaEstructura",
            "pegarFilaEstructura", "grabarCostosMultiplesEstructura" };
        exige(modifican.All(n => !Boton(n).Enabled) && new[] { "copiarFilaEstructura", "recalcularEstructura",
            "fuenteEstructura", "lupaPresupuesto", "calculadoraPresupuesto", "alternarDetallePresupuesto" }
            .All(n => Boton(n).Enabled),
            "Sin permiso de edición deben bloquearse los cambios y conservarse las consultas y utilidades.");
        int accionesAntes = acciones.Count, movimientosAntes = movimientos.Count, guardadosAntes = guardados;
        foreach (string nombre in modifican) Boton(nombre).PerformClick();
        exige(acciones.Count == accionesAntes && movimientos.Count == movimientosAntes && guardados == guardadosAntes,
            "Los comandos sin autorización no deben alcanzar callbacks de modificación.");
        PulsarAccion("copiarFilaEstructura", "copiar", partida);
        autorizado = true; hayCopia = false;
        panel.SeleccionarEstructura(null); Application.DoEvents(); panel.ActualizarHerramientas();
        exige(new[] { "subirFilaEstructura", "bajarFilaEstructura", "eliminarFilaEstructura", "copiarFilaEstructura",
            "pegarFilaEstructura", "grabarCostosMultiplesEstructura" }.All(n => !Boton(n).Enabled),
            "Una selección vacía y sin copia debe deshabilitar las herramientas que necesitan un nodo.");

        panel.SeleccionarEstructura(partida); Application.DoEvents();
        esperarRecalculo = true; pendiente = new TaskCompletionSource<bool>();
        try
        {
            accionesAntes = acciones.Count;
            Boton("recalcularEstructura").PerformClick(); Application.DoEvents();
            exige(acciones.Count == accionesAntes + 1 && acciones[^1].Comando == "recalcular" &&
                ReferenceEquals(acciones[^1].Nodo, partida) && botones.All(b => !b.Enabled),
                "Mientras un recálculo está pendiente deben bloquearse todas las herramientas y conservarse su contexto.");
            movimientosAntes = movimientos.Count; guardadosAntes = guardados;
            foreach (var boton in botones) boton.PerformClick();
            exige(acciones.Count == accionesAntes + 1 && movimientos.Count == movimientosAntes && guardados == guardadosAntes &&
                !division.Panel2Collapsed && ReferenceEquals(panel.SeleccionEstructura, partida),
                "Los clics durante una operación pendiente no deben duplicar acciones ni alterar la selección o el detalle.");
        }
        finally
        {
            disponible = true; esperarRecalculo = false; pendiente.TrySetResult(true); Application.DoEvents();
        }
        exige(Boton("copiarFilaEstructura").Enabled && Boton("recalcularEstructura").Enabled &&
            !Boton("pegarFilaEstructura").Enabled,
            "Completar la operación debe restaurar las herramientas y mantener Pegar deshabilitado si no hay copia.");
        exige(MYGProyectoStorage.Firma(proyecto) == firma && antes == 0 && despues == 0 && Application.OpenForms.Count == ventanas,
            "Ejercitar los callbacks y la disponibilidad no debe alterar el modelo, abrir diálogos ni crear historial.");

        VerificarFormato(panel, estructura, proyecto, primero, titulo, partida, exige);
        foreach (var tamano in new[] { new Size(1300, 730), new Size(1600, 900) })
        {
            formulario.ClientSize = tamano; Application.DoEvents(); VerificarDisposicion();
        }
        formulario.Close();

        ToolStripButton Boton(string nombre) => botones.Single(b => b.Name == nombre);
        void PulsarAccion(string nombre, string comando, object nodo)
        {
            int anteriores = acciones.Count;
            exige(Boton(nombre).Enabled, "La herramienta autorizada debe estar habilitada: " + nombre);
            Boton(nombre).PerformClick(); Application.DoEvents();
            exige(acciones.Count == anteriores + 1 && acciones[^1].Comando == comando && ReferenceEquals(acciones[^1].Nodo, nodo),
                "La herramienta debe despachar exactamente una vez el comando y nodo seleccionados: " + comando);
        }
        void VerificarDisposicion()
        {
            exige(ReferenceEquals(barra.Parent, division.Panel1) && barra.Dock == DockStyle.Right && barra.Visible &&
                barra.Top == 0 && barra.Bottom == division.Panel1.ClientSize.Height && barra.Right == division.Panel1.ClientSize.Width,
                "La barra debe ocupar toda la altura de Panel1 del divisor principal, junto a estructura, gráfico y resumen.");
            var contenido = division.Panel1.Controls.OfType<SplitContainer>().Single();
            exige(contenido.Right <= barra.Left && botones.All(b => b.Available && b.Placement == ToolStripItemPlacement.Main),
                "La estructura y su resumen no deben quedar bajo la barra ni ocultar herramientas en el desbordamiento.");
        }
    }

    private static void VerificarFormato(MYGPanelPresupuesto panel, DataGridView estructura, MYGProyectoDocumento proyecto,
        MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin titulo, ItemPresupuestoDelphin partida, Action<bool, string> exige)
    {
        string firma = MYGProyectoStorage.Firma(proyecto);
        using var fuente = new Font("Segoe UI", 12.5f, FontStyle.Italic);
        var tinta = Color.FromArgb(52, 41, 96);
        var fondo = Color.FromArgb(243, 239, 220);
        panel.AplicarFormatoVistaEstructura(fuente, tinta, fondo);
        foreach (bool oscuro in new[] { false, true })
        foreach (int porcentaje in new[] { 100, 115, 100 })
        {
            if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos();
            MYGTamanoTextoUI.Cambiar(porcentaje, guardarPreferencia: false);
            panel.Refrescar(); Application.DoEvents();
            exige(ReferenceEquals(panel.SeleccionEstructura, partida),
                "Cambiar fuente, tema o tamaño de lectura y refrescar debe conservar la selección.");
            var codigo = estructura.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, partida)).Cells["ITEM"];
            int anchoTexto = TextRenderer.MeasureText(Convert.ToString(codigo.Value), Formato(codigo).Font).Width;
            exige(estructura.Columns["ITEM"].Width >= anchoTexto + codigo.Style.Padding.Horizontal + 8 ||
                estructura.Columns["ITEM"].Width == 300,
                "El ancho de códigos debe medir la fuente visible, hasta el límite de 300 píxeles de la columna.");
            foreach (object nodo in new object[] { presupuesto, titulo, partida })
            {
                var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, nodo));
                foreach (string columna in new[] { "DESC", "TOTAL" })
                {
                    var estilo = Formato(fila.Cells[columna]);
                    bool esTitulo = !ReferenceEquals(nodo, partida);
                    exige(estilo.Font != null && estilo.Font.Name == fuente.Name && estilo.Font.Italic &&
                        estilo.Font.Bold == esTitulo && Math.Abs(estilo.Font.SizeInPoints - fuente.SizeInPoints * porcentaje / 100f) < .15f,
                        "La fuente de vista debe conservar su tamaño y cursiva; presupuestos y títulos deben añadir negrita en toda la fila.");
                    exige(estilo.ForeColor.ToArgb() == (SystemInformation.HighContrast ? SystemColors.WindowText : tinta).ToArgb() &&
                        estilo.BackColor.ToArgb() == (SystemInformation.HighContrast ? SystemColors.Window : fondo).ToArgb(),
                        "Los colores de vista deben sobrevivir al refresco y al tema, respetando el alto contraste de Windows.");
                    exige(estilo.SelectionForeColor.ToArgb() == (SystemInformation.HighContrast
                            ? SystemColors.HighlightText : MYG2027_TemaComercial.TextoSeleccion).ToArgb() &&
                        estilo.SelectionBackColor.ToArgb() == (SystemInformation.HighContrast
                            ? SystemColors.Highlight : MYG2027_TemaComercial.Seleccion).ToArgb() &&
                        estilo.SelectionForeColor.ToArgb() != estilo.SelectionBackColor.ToArgb(),
                        "El formato personalizado debe conservar los colores legibles de selección del tema o de alto contraste.");
                }
            }
            exige(MYGProyectoStorage.Firma(proyecto) == firma,
                "Personalizar la fuente de la vista no debe escribir fuentes, colores, importes ni otros cambios en el proyecto.");
        }
    }

    private static void VerificarHerramientasSistema(Action<bool, string> exige)
    {
        foreach (string nombre in new[] { "Magnify.exe", "calc.exe", "MAGNIFY.EXE", "CALC.EXE" })
        {
            var inicio = MYGHerramientasSistemaPresupuesto.CrearInicio(nombre);
            exige(Path.IsPathFullyQualified(inicio.FileName) &&
                string.Equals(Path.GetDirectoryName(inicio.FileName), Environment.SystemDirectory, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(Path.GetFileName(inicio.FileName), nombre, StringComparison.OrdinalIgnoreCase) &&
                inicio.UseShellExecute && string.IsNullOrEmpty(inicio.Arguments) && inicio.ArgumentList.Count == 0 &&
                string.IsNullOrEmpty(inicio.Verb),
                "Lupa y Calculadora deben resolverse exclusivamente desde el directorio del sistema, sin argumentos ni elevación.");
        }
        foreach (string nombre in new[] { null, "", "cmd.exe", "powershell.exe", "../calc.exe", @"C:\temp\calc.exe", "calc.exe /c", "Magnify.exe " })
        {
            bool rechazado = false;
            try { MYGHerramientasSistemaPresupuesto.CrearInicio(nombre); }
            catch (ArgumentException) { rechazado = true; }
            exige(rechazado, "Las utilidades deben rechazar nombres, rutas y argumentos fuera de la lista permitida.");
        }
    }

    private static DataGridViewCellStyle Formato(DataGridViewCell celda)
    {
        var evento = new DataGridViewCellFormattingEventArgs(celda.ColumnIndex, celda.RowIndex, celda.Value,
            typeof(string), celda.InheritedStyle.Clone());
        typeof(DataGridView).GetMethod("OnCellFormatting", BindingFlags.Instance | BindingFlags.NonPublic)
            .Invoke(celda.DataGridView, new object[] { evento });
        return evento.CellStyle;
    }

    private static ItemPresupuestoDelphin Partida(string item, string descripcion, int posicion) => new()
    {
        Id = MYGProyectoStorage.NuevoId(), Item = item, Descripcion = descripcion, Unidad = "m³",
        TipoPropuesta = "PARTIDA", Posicion = posicion,
        Costos = new MYGDatosPartida { Cantidad = 4m, PrecioDirecto = 10m }
    };

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control control in padre.Controls)
        {
            yield return control;
            foreach (var descendiente in Controles(control)) yield return descendiente;
        }
    }
}
