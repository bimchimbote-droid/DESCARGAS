using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG_2027;

internal static class ParametrosDialogoUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg_parametros_dialogo_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        string rutaAnterior = MYGParametrosUsuario.RutaAlternativaPruebas;
        try
        {
            MYGParametrosUsuario.RutaAlternativaPruebas = Path.Combine(carpeta, "parametros.json");
            using (var ventana = new MYGParametrosPredeterminadosForm())
            {
                ventana.Show(); Application.DoEvents();
                var pestanas = Buscar<TabControl>(ventana, "pestanasParametros");
                exige(pestanas.TabPages.Cast<TabPage>().Select(p => p.Text).SequenceEqual(new[]
                {
                    "Presupuestos", "Costos e Insumos", "División política",
                    "Parámetros de Fierros y Aceros", "Colores de Partidas", "General"
                }), "Los parámetros deben presentar las seis pestañas de la referencia, con General al final.");
                exige(Buscar<DataGridView>(ventana, "tablaAceros").Rows.Count == 21,
                    "La tabla de fierros debe conservar los 21 diámetros de las plantillas del software.");
                foreach (var pagina in pestanas.TabPages.Cast<TabPage>())
                {
                    pestanas.SelectedTab = pagina; Application.DoEvents();
                    exige(pagina.Controls.OfType<Panel>().Any(p => p.AutoScroll),
                        "Cada pestaña debe permitir desplazarse para acceder a todos los campos.");
                }
                Buscar<TextBox>(ventana, "NombreComercial").Text = "CAMBIO CANCELADO";
                Buscar<Button>(ventana, "cerrarParametros").PerformClick();
                exige(ventana.DialogResult == DialogResult.Cancel && !File.Exists(MYGParametrosUsuario.RutaPredeterminada),
                    "Cerrar los parámetros debe descartar la edición sin crear un archivo de preferencias.");
            }

            var configuracion = new MYGParametrosPredeterminados();
            MYGParametrosUsuario.Guardar(configuracion);
            string original = File.ReadAllText(MYGParametrosUsuario.RutaPredeterminada);
            using (var ventana = new MYGParametrosPredeterminadosForm())
            {
                ventana.Show(); Application.DoEvents();
                Buscar<TextBox>(ventana, "AbreviaturaGastosGenerales").Text = "CD";
                Buscar<Button>(ventana, "aceptarParametros").PerformClick(); Application.DoEvents();
                exige(ventana.DialogResult != DialogResult.OK && Buscar<Label>(ventana, "errorParametros").Visible
                    && File.ReadAllText(MYGParametrosUsuario.RutaPredeterminada) == original,
                    "Una abreviatura reservada debe mostrar el error y conservar el archivo de parámetros.");
                Buscar<TextBox>(ventana, "AbreviaturaGastosGenerales").Text = "GG";
                Buscar<NumericUpDown>(ventana, "GastosGeneralesPorcentaje").Value = 12.3456m;
                Buscar<NumericUpDown>(ventana, "DecimalesCantidad").Value = 8;
                Buscar<TextBox>(ventana, "NombreComercial").Text = "EMPRESA DE PRUEBA";
                Buscar<Button>(ventana, "aceptarParametros").PerformClick(); Application.DoEvents();
                var guardada = MYGParametrosUsuario.Leer();
                exige(ventana.DialogResult == DialogResult.OK && guardada.NombreComercial == "EMPRESA DE PRUEBA"
                    && guardada.GastosGeneralesPorcentaje == 12.3456m && guardada.DecimalesCantidad == 8,
                    "Aceptar debe guardar los valores válidos conservando los cuatro decimales de porcentaje y la precisión de cantidad.");
            }
            using (var ventana = new MYGParametrosPredeterminadosForm())
            {
                exige(Buscar<TextBox>(ventana, "NombreComercial").Text == "EMPRESA DE PRUEBA"
                    && Buscar<NumericUpDown>(ventana, "GastosGeneralesPorcentaje").Value == 12.3456m,
                    "Volver a abrir los parámetros debe recuperar las preferencias aceptadas.");
            }
            using var sesion = new MYG.Externo.SesionDesktop();
            using var inicio = new InicioForm(sesion);
            string rutaBase = Path.Combine(carpeta, "proyectos.sqlite");
            MYGBaseDatos.CrearBaseVacia(rutaBase);
            const BindingFlags privados = BindingFlags.Instance | BindingFlags.NonPublic;
            typeof(InicioForm).GetField("rutaBase", privados).SetValue(inicio, rutaBase);
            typeof(InicioForm).GetMethod("MostrarProyectos", privados).Invoke(inicio, null);
            inicio.Show(); Application.DoEvents();
            var boton = Buscar<Button>(inicio, "parametrosPredeterminadosInicio");
            var opciones = Buscar<FlowLayoutPanel>(inicio, "opcionesInicio");
            var crearBase = opciones.Controls.OfType<Button>().Single(b => b.Text == "Crear otra base");
            exige(ReferenceEquals(boton.Parent, opciones) && opciones.Controls.IndexOf(boton) == opciones.Controls.IndexOf(crearBase) + 1,
                "Parámetros predeterminados debe ser la opción siguiente a Crear otra base.");
            exige(boton.Size == crearBase.Size && boton.Margin == crearBase.Margin && boton.Dock == DockStyle.None,
                "Parámetros predeterminados debe compartir el tamaño y la disposición de las demás opciones.");
            exige(!Controles(inicio).Any(c => c.Name == "barraParametrosInicio") &&
                Controles(inicio).Count(c => c.Name == "parametrosPredeterminadosInicio") == 1,
                "Inicio debe contener un único botón de parámetros dentro de Opciones y ninguna barra superior de parámetros.");
        }
        finally
        {
            MYGParametrosUsuario.RutaAlternativaPruebas = rutaAnterior;
            MYGParametrosAplicacionUI.Actualizar();
            Directory.Delete(carpeta, true);
        }
    }

    private static T Buscar<T>(Control raiz, string nombre) where T : Control =>
        Controles(raiz).OfType<T>().Single(c => c.Name == nombre);
    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (var control in Controles(hijo)) yield return control;
    }
}
