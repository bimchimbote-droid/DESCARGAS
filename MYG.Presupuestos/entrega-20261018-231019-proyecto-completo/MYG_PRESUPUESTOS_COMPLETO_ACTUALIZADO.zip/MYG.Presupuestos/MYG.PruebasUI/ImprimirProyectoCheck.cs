using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class ImprimirProyectoCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private static readonly string[] Nombres =
    {
        "imprimir_presupuesto_seleccionado", "imprimir_todos_presupuestos", "imprimir_hoja_resumen",
        "imprimir_analisis_costos_unitarios", "imprimir_consolidado_costos_unitarios", "imprimir_metrados",
        "exportar_metrados_excel", "imprimir_metrados_aceros", "exportar_metrados_aceros_excel",
        "exportar_metrados_por_plantilla_excel"
    };
    private static readonly string[] Textos =
    {
        "Presupuesto seleccionado", "Todos los presupuestos", "Hoja de resumen", "Análisis de costos unitarios",
        "Consolidado de costos unitarios", "Metrados", "Metrados (Formato DE Excel)", "Metrados de fierros y aceros",
        "Metrados de fierros y aceros (Formato DE Excel)", "Metrados por tipo de plantilla (Formato DE Excel)"
    };

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarDestinos(exige);
        VerificarDisponibilidad(exige);
        VerificarCintaYDesplegable(exige);
        VerificarAperturaLigera(exige);
    }

    private static void VerificarDestinos(Action<bool, string> exige)
    {
        var ejecuciones = new List<string>();
        var menu = EditorForm.CrearMenuImprimirProyecto(
            tipo => ejecuciones.Add("imprimir:" + tipo),
            plantilla => ejecuciones.Add("excel:" + (plantilla ?? "todas")),
            () => ejecuciones.Add("excel:por_plantilla"), true, true, true, true, true);
        var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
        var imagenes = opciones.Select(o => o.Image).ToArray();
        try
        {
            exige(menu.Items.Count == 12 && opciones.Length == 10 &&
                menu.Items[5] is ToolStripSeparator && menu.Items[9] is ToolStripSeparator,
                "Imprimir debe tener diez destinos y separar el consolidado y los metrados de acero como en la referencia.");
            exige(opciones.Select(o => o.Name).SequenceEqual(Nombres) && opciones.Select(o => o.Text).SequenceEqual(Textos),
                "El desplegable de Imprimir debe conservar el orden y los nombres de las diez opciones solicitadas.");
            exige(opciones.All(o => o.Enabled && o.Image != null && o.Image.Width > 0 && o.Image.Height > 0),
                "Cada destino de Imprimir debe mostrar su icono y estar disponible cuando existen todos los datos.");
            exige(ejecuciones.Count == 0, "Crear el menú no debe imprimir ni exportar archivos.");
            foreach (var opcion in opciones) opcion.PerformClick();
            exige(ejecuciones.SequenceEqual(new[]
            {
                "imprimir:" + MYGTipoReporteProyecto.PresupuestoSeleccionado,
                "imprimir:" + MYGTipoReporteProyecto.TodosPresupuestos,
                "imprimir:" + MYGTipoReporteProyecto.HojaResumen,
                "imprimir:" + MYGTipoReporteProyecto.AnalisisCostosUnitarios,
                "imprimir:" + MYGTipoReporteProyecto.ConsolidadoCostosUnitarios,
                "imprimir:" + MYGTipoReporteProyecto.Metrados,
                "excel:todas", "imprimir:" + MYGTipoReporteProyecto.MetradosAceros,
                "excel:" + MYGPlantillasMetrado.Aceros, "excel:por_plantilla"
            }), "Cada opción de Imprimir debe ejecutar una vez su reporte o exportación, con el alcance correcto.");
        }
        finally { menu.Dispose(); }
        exige(imagenes.All(ImagenLiberada), "Cerrar y disponer el menú debe liberar los iconos de sus diez destinos.");
    }

    private static void VerificarDisponibilidad(Action<bool, string> exige)
    {
        Verificar(false, false, false, false, false, Array.Empty<int>(),
            "Un proyecto sin presupuestos no debe ofrecer impresiones ni exportaciones vacías.");
        Verificar(true, true, false, false, false, new[] { 0, 1, 2 },
            "Un presupuesto vacío debe permitir su presupuesto y resumen, conservando bloqueados los reportes que necesitan partidas.");
        Verificar(true, true, true, true, false, new[] { 0, 1, 2, 3, 4, 5, 6, 9 },
            "Sin plantilla de acero deben seguir disponibles los metrados generales y bloquearse sólo los dos destinos de acero.");
        Verificar(true, true, true, false, false, new[] { 0, 1, 2, 3, 4, 5 },
            "Los metrados sin hojas Excel deben poder imprimirse y mantener bloqueadas las exportaciones de hojas.");

        void Verificar(bool presupuesto, bool proyecto, bool partidas, bool excel, bool aceros,
            int[] disponibles, string mensaje)
        {
            int ejecuciones = 0;
            using var menu = EditorForm.CrearMenuImprimirProyecto(_ => ejecuciones++, _ => ejecuciones++, () => ejecuciones++,
                presupuesto, proyecto, partidas, excel, aceros);
            var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
            exige(opciones.Select((o, i) => (o, i)).Where(x => x.o.Enabled).Select(x => x.i).SequenceEqual(disponibles), mensaje);
            foreach (var opcion in opciones.Where(o => !o.Enabled)) opcion.PerformClick();
            exige(ejecuciones == 0, "Un destino bloqueado de Imprimir no debe ejecutar su acción.");
        }
    }

    private static void VerificarCintaYDesplegable(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("PRUEBA DEL MENÚ DE IMPRESIÓN", "ESTRUCTURAS");
        using var sesion = new SesionDesktop();
        using var editor = new EditorForm(proyecto, null, sesion);
        editor.WindowState = FormWindowState.Normal; editor.ClientSize = new Size(1600, 900);
        editor.Show(); Application.DoEvents();
        var barra = Campo<FlowLayoutPanel>(editor, "cintaPresupuestos");
        var boton = barra.Controls.OfType<Button>().Single(b => b.Name == "imprimir_proyecto_button");
        string[] botones =
        {
            "ir_inicio_button", "guardar_proyecto_button", "imprimir_proyecto_button", "info_proyecto_button", "exportar_proyecto_button",
            "formula_polinomica_button", "calendario_adquisiciones_button", "calendario_valorizado_button", "resumen_costos_button",
            "responsables_proyecto_button", "especificaciones_button", "valorizacion_button", "permisos_proyecto_button",
            "tamano_texto_button"
        };
        exige(barra.Controls.OfType<Button>().Select(b => b.Name).SequenceEqual(botones) &&
            boton.Text == "Imprimir / PDF ▾" && boton.AccessibleName == "Imprimir / PDF" && boton.Image != null,
            "Imprimir / PDF debe mostrar la flecha con su icono, conservar su nombre accesible y mantener las herramientas de la cinta.");
        exige(!sesion.Autorizado && !boton.Enabled && boton.Tag is not false,
            "Agregar el desplegable no debe cambiar los permisos existentes del botón de impresión.");
        var documento = Campo<MYGProyectoDocumento>(editor, "documento");
        string firma = MYGProyectoStorage.Firma(documento);
        var undo = Campo<Stack<MYGProyectoDocumento>>(editor, "undo").ToArray();
        var redo = Campo<Stack<MYGProyectoDocumento>>(editor, "redo").ToArray();
        var ventanas = Application.OpenForms.Cast<Form>().ToArray();
        var componentes = Campo<Container>(editor, "componentesMenus");
        for (int apertura = 0; apertura < 2; apertura++)
        {
            var anteriores = componentes.Components.OfType<ContextMenuStrip>().ToArray();
            // Invocar sólo la apertura evita iniciar sesión, imprimir o abrir diálogos de guardado.
            typeof(EditorForm).GetMethod("MenuImprimirProyecto", Privados).Invoke(editor, new object[] { boton });
            Application.DoEvents();
            var menu = componentes.Components.OfType<ContextMenuStrip>().Except(anteriores).Single();
            exige(menu.Visible && menu.Items.OfType<ToolStripMenuItem>().Select(o => o.Text).SequenceEqual(Textos),
                "Abrir Imprimir / PDF debe mostrar inmediatamente el desplegable con sus diez opciones.");
            exige(ReferenceEquals(documento, Campo<MYGProyectoDocumento>(editor, "documento")) &&
                MYGProyectoStorage.Firma(documento) == firma &&
                Campo<Stack<MYGProyectoDocumento>>(editor, "undo").SequenceEqual(undo) &&
                Campo<Stack<MYGProyectoDocumento>>(editor, "redo").SequenceEqual(redo) &&
                Application.OpenForms.Cast<Form>().SequenceEqual(ventanas),
                "Abrir el desplegable no debe cambiar el documento ni el historial, ni iniciar impresión o exportación.");
            menu.Close(ToolStripDropDownCloseReason.CloseCalled); Application.DoEvents();
            exige(menu.IsDisposed, "Cerrar el desplegable de Imprimir debe liberar su menú antes de volver a abrirlo.");
        }
    }

    private static void VerificarAperturaLigera(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("DESPLEGABLES SIN RECALCULAR", "ESTRUCTURAS");
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Posicion = 1, TipoPropuesta = "PARTIDA",
            Descripcion = "PARTIDA DE PRUEBA", Unidad = "m²", Estado = "PROPUESTA",
            Filtros = new() { new() { Parametro = "Mark", Regla = "=", Valor = "PRUEBA" } },
            Costos = new() { Cantidad = 3m, PrecioDirecto = 25m }
        };
        proyecto.Presupuestos.Single().Items.Add(partida);
        using var respuestas = new LicenciasSimuladas();
        using var http = new HttpClient(respuestas);
        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetField("licencia", Privados).SetValue(sesion,
            new LicenciaServicio(http, "PC-PRUEBA", "https://licencias.example.invalid/exec"));
        Campo<System.Windows.Forms.Timer>(sesion, "reloj").Stop();
        exige(sesion.EntrarAsync(new() { Usuario = "prueba-local", Clave = "prueba-local" }).GetAwaiter().GetResult().Ok,
            "La prueba de menús debe usar exclusivamente una licencia simulada local.");
        using var editor = new EditorForm(proyecto, null, sesion);
        editor.WindowState = FormWindowState.Normal; editor.ClientSize = new Size(1600, 900);
        editor.Show(); Application.DoEvents(); Application.DoEvents();
        var barra = Campo<FlowLayoutPanel>(editor, "cintaPresupuestos");
        var componentes = Campo<Container>(editor, "componentesMenus");
        var panel = Campo<MYGPanelPresupuesto>(editor, "panelPresupuesto");
        var acu = Campo<DataGridView>(panel, "acu");
        var filtros = partida.Filtros;
        var filasACU = acu.Rows.Cast<DataGridViewRow>().ToArray();
        string firma = MYGProyectoStorage.Firma(proyecto);
        var undo = Campo<Stack<MYGProyectoDocumento>>(editor, "undo").ToArray();
        var redo = Campo<Stack<MYGProyectoDocumento>>(editor, "redo").ToArray();
        int actualizaciones = 0, solicitudes = respuestas.Solicitudes;
        editor.ProyectoActualizado += () => actualizaciones++;
        // La siguiente operación efectiva necesitará renovar la licencia. Abrir
        // un desplegable no debe consumir esa consulta ni esperar a la red.
        typeof(SesionDesktop).GetField("validadoTick", Privados).SetValue(sesion,
            System.Diagnostics.Stopwatch.GetTimestamp() - 46L * System.Diagnostics.Stopwatch.Frequency);
        foreach (string nombre in new[] { "imprimir_proyecto_button", "exportar_proyecto_button", "responsables_proyecto_button", "permisos_proyecto_button" })
        {
            var anteriores = componentes.Components.OfType<ContextMenuStrip>().ToArray();
            var boton = barra.Controls.OfType<Button>().Single(b => b.Name == nombre);
            exige(boton.Enabled, "Los desplegables deben conservar su habilitación con la sesión autorizada.");
            boton.PerformClick(); Application.DoEvents();
            var menu = componentes.Components.OfType<ContextMenuStrip>().Except(anteriores).Single();
            exige(menu.Visible && !editor.OperacionEnCurso && respuestas.Solicitudes == solicitudes && actualizaciones == 0,
                "Abrir " + nombre + " debe mostrar sus opciones sin consultar la licencia, firmar el proyecto ni iniciar una operación.");
            exige(ReferenceEquals(partida.Filtros, filtros) && MYGProyectoStorage.Firma(proyecto) == firma &&
                acu.Rows.Cast<DataGridViewRow>().SequenceEqual(filasACU) &&
                Campo<Stack<MYGProyectoDocumento>>(editor, "undo").SequenceEqual(undo) &&
                Campo<Stack<MYGProyectoDocumento>>(editor, "redo").SequenceEqual(redo),
                "Abrir " + nombre + " debe conservar los filtros, las filas calculadas, el documento y el historial.");
            menu.Close(ToolStripDropDownCloseReason.CloseCalled); Application.DoEvents();
            exige(menu.IsDisposed, "El cierre diferido debe liberar cada desplegable de la cinta.");
        }
        int ejecuciones = 0;
        typeof(EditorForm).GetMethod("EjecutarDesdeMenuProyecto", Privados).Invoke(editor,
            new object[] { (Action)(() => ejecuciones++), true });
        Application.DoEvents(); Application.DoEvents();
        exige(ejecuciones == 1 && respuestas.Solicitudes == solicitudes + 1 && !ReferenceEquals(partida.Filtros, filtros) &&
            actualizaciones > 0 && !editor.OperacionEnCurso,
            "Ejecutar un destino debe conservar la renovación de licencia, la sincronización y la actualización del proyecto.");
    }

    private sealed class LicenciasSimuladas : HttpMessageHandler
    {
        internal int Solicitudes { get; private set; }
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Solicitudes++;
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("OK") });
        }
    }

    private static bool ImagenLiberada(Image imagen)
    {
        if (imagen == null) return false;
        try { _ = imagen.Width; return false; }
        catch (ArgumentException) { return true; }
        catch (ObjectDisposedException) { return true; }
    }

    private static T Campo<T>(object objeto, string nombre)
        => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
}
