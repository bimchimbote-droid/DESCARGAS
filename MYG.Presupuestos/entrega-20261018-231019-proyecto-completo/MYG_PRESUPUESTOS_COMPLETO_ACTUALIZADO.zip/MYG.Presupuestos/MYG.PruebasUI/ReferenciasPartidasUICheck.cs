using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class ReferenciasPartidasUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarBarraYEnlaces(exige);
        VerificarEditorDeCelda(exige);
        VerificarCancelacionYCambioDeModelo(exige);
    }

    private static void VerificarBarraYEnlaces(Action<bool, string> exige)
    {
        using var contexto = new Contexto();
        var panel = contexto.Panel;
        var hoja = contexto.Hoja;
        var formula = contexto.Formula;
        exige(Controles(contexto.PaginaExcel).OfType<Button>().Any(b =>
                b.Text.Contains("Referenciar", StringComparison.OrdinalIgnoreCase) &&
                b.Text.Contains("partida", StringComparison.OrdinalIgnoreCase)),
            "La hoja debe ofrecer un botón visible para referenciar otra partida sin escribir sus identificadores.");

        Seleccionar(hoja, "I20");
        Escribir(formula, "=SUMA(");
        string destinoAntes = Estado(contexto.Destino.Costos.Hoja);
        string origenAntes = Estado(contexto.Origen.Costos);
        string datosOrigenAntes = EstadoDatosOrigen(contexto.Origen.Costos);
        var contadores = contexto.Contadores;
        Iniciar(contexto);
        exige(Eligiendo(panel) && contexto.PresupuestoActivo.Id == contexto.PresupuestoOrigen.Id &&
                ReferenceEquals(Campo<ItemPresupuestoDelphin>(panel, "actual"), contexto.Origen) &&
                ((TabControl)contexto.PaginaExcel.Parent).SelectedTab == contexto.PaginaExcel &&
                hoja.Visible && hoja.Tag?.ToString() == contexto.Origen.Id,
            "Elegir una partida de otro presupuesto debe llevar automáticamente a su hoja de metrados en el panel principal.");
        exige(Estado(contexto.Destino.Costos.Hoja) == destinoAntes && Estado(contexto.Origen.Costos) == origenAntes &&
                contexto.Contadores == contadores,
            "Navegar al origen debe conservar la fórmula incompleta en memoria sin guardar ni generar historial.");
        exige(Campo<Label>(panel, "indicacionReferenciaPartidaHoja").Text.Contains("celda", StringComparison.OrdinalIgnoreCase) &&
                Campo<Label>(panel, "indicacionReferenciaPartidaHoja").Text.Contains("I20", StringComparison.Ordinal),
            "Durante la selección debe mostrarse una indicación de elegir celda y la dirección del destino para orientar al usuario.");
        VerificarOrigenSoloLectura(contexto, origenAntes, destinoAntes, contadores, exige);

        ElegirConClic(contexto, "B3", exige);
        string primeraReferencia = formula.Text;
        exige(!Eligiendo(panel) && contexto.PresupuestoActivo.Id == contexto.PresupuestoDestino.Id &&
                Campo<ItemPresupuestoDelphin>(panel, "actual").Id == contexto.Destino.Id &&
                DireccionActual(hoja) == "I20" && formula.Focused &&
                formula.SelectionStart == formula.TextLength && formula.SelectionLength == 0 &&
                primeraReferencia.StartsWith("=SUMA(METRADO(", StringComparison.OrdinalIgnoreCase) &&
                primeraReferencia.Contains("B3", StringComparison.Ordinal) &&
                !primeraReferencia.Contains(contexto.Origen.Id, StringComparison.Ordinal),
            "Un clic en B3 debe volver al destino e insertar una referencia legible dentro de SUMA, con el cursor listo para continuar.");
        exige(!hoja.ReadOnly && !formula.ReadOnly && Estado(contexto.Destino.Costos.Hoja) == destinoAntes &&
                Estado(contexto.Origen.Costos) == origenAntes && contexto.Contadores == contadores,
            "Seleccionar el origen debe restaurar la edición del destino y mantener pendiente todo el cambio.");

        formula.SelectedText = "+";
        Application.DoEvents();
        Iniciar(contexto);
        Elegir(contexto, "B4");
        exige(formula.Text.StartsWith(primeraReferencia + "+METRADO(", StringComparison.OrdinalIgnoreCase) &&
                formula.Text.Contains("B4", StringComparison.Ordinal) &&
                Estado(contexto.Destino.Costos.Hoja) == destinoAntes &&
                Estado(contexto.Origen.Costos) == origenAntes && contexto.Contadores == contadores,
            "Elegir dos celdas de la misma partida debe conservar ambas referencias y el borrador sin sobrescribir la primera.");
        formula.SelectedText = ")";
        string completa = formula.Text;
        Invocar(panel, "AplicarFormula");
        Application.DoEvents();
        exige(Contenido(contexto.Destino.Costos.Hoja, "I20") == completa &&
                contexto.Contadores == (contadores.Antes + 1, contadores.Cambios + 1, contadores.Guardados) &&
                EstadoDatosOrigen(contexto.Origen.Costos) == datosOrigenAntes &&
                !contexto.EstadoAnterior.Celdas.ContainsKey("I20"),
            "Aplicar debe persistir las dos referencias únicamente en la celda de destino y registrar un solo cambio que pueda deshacerse.");
        exige(NumeroMostrado(hoja, "I20") == 8m,
            "El resultado mostrado debe sumar B3 y B4 del otro presupuesto y calcular ocho.");

        // El historial reemplaza modelos completos: la selección conserva Id,
        // mientras las referencias deben volver a leer la instancia vigente.
        contexto.Proyecto = MYGProyectoStorage.Copia(contexto.Proyecto);
        contexto.Origen.Costos.Hoja.Poner("B3", "11");
        panel.Refrescar();
        Application.DoEvents();
        exige(NumeroMostrado(hoja, "I20") == 16m &&
                Contenido(contexto.Destino.Costos.Hoja, "I20") == completa &&
                contexto.Contadores == (contadores.Antes + 1, contadores.Cambios + 1, contadores.Guardados),
            "Refrescar después de restaurar el modelo debe leer los nuevos valores del origen sin cambiar la fórmula ni generar otra edición.");
    }

    private static void VerificarEditorDeCelda(Action<bool, string> exige)
    {
        using var contexto = new Contexto();
        var panel = contexto.Panel;
        var hoja = contexto.Hoja;
        Seleccionar(hoja, "I21");
        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is RichTextBox,
            "La referencia a otra partida también debe poder comenzar desde el editor real de la celda.");
        var editor = (RichTextBox)hoja.EditingControl;
        Escribir(editor, "=1+9");
        editor.Select(3, 1);
        string destinoAntes = Estado(contexto.Destino.Costos.Hoja);
        string origenAntes = Estado(contexto.Origen.Costos);
        string datosOrigenAntes = EstadoDatosOrigen(contexto.Origen.Costos);
        var contadores = contexto.Contadores;
        Iniciar(contexto);
        Elegir(contexto, "C8");
        string texto = contexto.Formula.Text;
        exige(texto.StartsWith("=1+METRADO(", StringComparison.OrdinalIgnoreCase) &&
                texto.Contains("B8", StringComparison.Ordinal) && !texto.Contains("C8", StringComparison.Ordinal) &&
                !hoja.IsCurrentCellInEditMode && contexto.Formula.Focused &&
                contexto.Formula.SelectionStart == contexto.Formula.TextLength && contexto.Formula.SelectionLength == 0 &&
                DireccionActual(hoja) == "I21" &&
                Estado(contexto.Destino.Costos.Hoja) == destinoAntes && Estado(contexto.Origen.Costos) == origenAntes &&
                contexto.Contadores == contadores,
            "Elegir C8 de B8:C8 debe insertar el ancla B8 sobre el texto seleccionado y volver a la barra editable para continuar la fórmula sin confirmar.");
        Invocar(panel, "AplicarFormula");
        Application.DoEvents();
        exige(!hoja.IsCurrentCellInEditMode && Contenido(contexto.Destino.Costos.Hoja, "I21") == texto &&
                NumeroMostrado(hoja, "I21") == 8m && EstadoDatosOrigen(contexto.Origen.Costos) == datosOrigenAntes &&
                contexto.Contadores == (contadores.Antes + 1, contadores.Cambios + 1, contadores.Guardados),
            "Aplicar en la barra debe confirmar solamente el destino, calcular ocho y registrar un único estado anterior.");

        // La posición de inserción también debe respetarse en una fórmula que
        // ya contiene operandos después del cursor, sin reemplazar su sufijo.
        Seleccionar(hoja, "I22");
        Escribir(contexto.Formula, "=1++9");
        contexto.Formula.Select(3, 0);
        contadores = contexto.Contadores;
        destinoAntes = Estado(contexto.Destino.Costos.Hoja);
        Iniciar(contexto);
        Elegir(contexto, "B3");
        exige(contexto.Formula.Text.StartsWith("=1+METRADO(", StringComparison.OrdinalIgnoreCase) &&
                contexto.Formula.Text.EndsWith("+9", StringComparison.Ordinal) &&
                contexto.Formula.SelectionStart == contexto.Formula.TextLength - 2 &&
                Estado(contexto.Destino.Costos.Hoja) == destinoAntes && contexto.Contadores == contadores,
            "Insertar en mitad de una fórmula debe respetar el cursor y conservar los operandos escritos después de él.");
        Invocar(panel, "CancelarEdicionHoja");
        Application.DoEvents();
        exige(Estado(contexto.Destino.Costos.Hoja) == destinoAntes && contexto.Contadores == contadores,
            "Cancelar la fórmula que recibió una referencia debe descartar el borrador completo sin persistir enlaces ni historial.");
    }

    private static void VerificarCancelacionYCambioDeModelo(Action<bool, string> exige)
    {
        using var contexto = new Contexto();
        var panel = contexto.Panel;
        var hoja = contexto.Hoja;
        var formula = contexto.Formula;
        Seleccionar(hoja, "I23");
        Escribir(formula, "=SUMA(");
        string destinoAntes = Estado(contexto.Destino.Costos.Hoja);
        string origenAntes = Estado(contexto.Origen.Costos);
        var contadores = contexto.Contadores;
        Iniciar(contexto);
        Invocar(panel, "CancelarReferenciaPartidaHoja");
        Application.DoEvents();
        VerificarBorradorRestaurado(contexto, "I23", "=SUMA(", destinoAntes, contadores, exige);
        exige(Estado(contexto.Origen.Costos) == origenAntes,
            "Cancelar la elección debe conservar completamente el metrado y la fuente de cantidad de la partida de origen.");

        Iniciar(contexto);
        var filtro = Campo<IMessageFilter>(panel, "filtroElegirReferenciasHoja");
        var escape = Message.Create(hoja.Handle, 0x0100, new IntPtr((int)Keys.Escape), IntPtr.Zero);
        exige(filtro.PreFilterMessage(ref escape),
            "El filtro de selección debe interceptar Escape desde la hoja de origen y cancelar la navegación.");
        Application.DoEvents();
        VerificarBorradorRestaurado(contexto, "I23", "=SUMA(", destinoAntes, contadores, exige);

        Iniciar(contexto);
        contexto.Proyecto = MYGProyectoStorage.Copia(contexto.Proyecto);
        Invocar(panel, "CancelarReferenciaPartidaHoja");
        Application.DoEvents();
        VerificarBorradorRestaurado(contexto, "I23", "=SUMA(", destinoAntes, contadores, exige);
        exige(ReferenceEquals(Campo<ItemPresupuestoDelphin>(panel, "actual"), contexto.Destino),
            "Al cancelar después de reemplazar el proyecto, el destino debe recuperarse por su Id usando la instancia vigente.");

        Iniciar(contexto);
        contexto.PresupuestoOrigen.Items.Remove(contexto.Origen);
        Invocar(panel, "CancelarReferenciaPartidaHoja");
        Application.DoEvents();
        VerificarBorradorRestaurado(contexto, "I23", "=SUMA(", destinoAntes, contadores, exige);
        Invocar(panel, "CancelarEdicionHoja");
        Application.DoEvents();
        exige(Estado(contexto.Destino.Costos.Hoja) == destinoAntes && contexto.Contadores == contadores &&
                formula.Text == Contenido(contexto.Destino.Costos.Hoja, "I23"),
            "Eliminar el origen durante la elección debe permitir volver y descartar el borrador sin escribir una referencia inválida.");

        // Cancelar también restaura el editor de celda, no sólo la barra.
        contexto.PresupuestoOrigen.Items.Add(Partida(contexto.IdOrigen, "02", "COLUMNA RESTAURADA", 4m));
        Seleccionar(hoja, "I24");
        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is RichTextBox,
            "Debe poder iniciar otra referencia después de cancelar la navegación anterior.");
        Escribir((RichTextBox)hoja.EditingControl, "=");
        Iniciar(contexto);
        Invocar(panel, "CancelarReferenciaPartidaHoja");
        Application.DoEvents();
        exige(hoja.IsCurrentCellInEditMode && hoja.EditingControl is RichTextBox editor && editor.Text == "=" &&
                editor.Focused && editor.SelectionStart == 1 && DireccionActual(hoja) == "I24" &&
                Estado(contexto.Destino.Costos.Hoja) == destinoAntes && contexto.Contadores == contadores,
            "Cancelar desde un borrador de celda debe volver al mismo editor con el igual y el cursor, sin confirmar su contenido.");
        InvocarEn(typeof(DataGridView), hoja, "ProcessEscapeKey", Keys.Escape);
        Application.DoEvents();
        exige(!hoja.IsCurrentCellInEditMode && Estado(contexto.Destino.Costos.Hoja) == destinoAntes &&
                contexto.Contadores == contadores,
            "Escape en el editor restaurado debe abandonar la fórmula incompleta sin modificar el proyecto.");
    }

    private static void VerificarOrigenSoloLectura(Contexto contexto, string origenAntes, string destinoAntes,
        (int Antes, int Cambios, int Guardados) contadores, Action<bool, string> exige)
    {
        var panel = contexto.Panel;
        var hoja = contexto.Hoja;
        exige(hoja.ReadOnly && contexto.Formula.ReadOnly && !hoja.BeginEdit(true),
            "La hoja de origen y su barra de fórmula deben permanecer en modo de selección, sin permitir editar sus celdas.");
        Tecla(hoja, Keys.Delete);
        foreach (var comando in new[] { "limpiar", "insertar_filas", "eliminar_columnas" })
        {
            try { Invocar(panel, "EjecutarComandoHoja", comando); }
            catch (InvalidOperationException) { }
            exige(Eligiendo(panel) && Estado(contexto.Origen.Costos) == origenAntes &&
                    Estado(contexto.Destino.Costos.Hoja) == destinoAntes && contexto.Contadores == contadores,
                "Los comandos de edición deben bloquearse mientras se elige la celda de otra partida, sin escribir el origen ni confirmar el destino.");
        }
        try { Invocar(panel, "UsarTotalHoja"); }
        catch (InvalidOperationException) { }
        exige(Eligiendo(panel) && Estado(contexto.Origen.Costos) == origenAntes && contexto.Contadores == contadores,
            "Usar total Excel durante la elección no debe cambiar la cantidad ni el origen del metrado de la partida consultada.");
    }

    private static void VerificarBorradorRestaurado(Contexto contexto, string direccion, string borrador,
        string destinoAntes, (int Antes, int Cambios, int Guardados) contadores, Action<bool, string> exige)
    {
        exige(!Eligiendo(contexto.Panel) && contexto.PresupuestoActivo.Id == contexto.PresupuestoDestino.Id &&
                Campo<ItemPresupuestoDelphin>(contexto.Panel, "actual").Id == contexto.Destino.Id &&
                DireccionActual(contexto.Hoja) == direccion && contexto.Formula.Text == borrador &&
                contexto.Formula.SelectionStart == borrador.Length && contexto.Formula.Focused &&
                !contexto.Hoja.ReadOnly && !contexto.Formula.ReadOnly &&
                Estado(contexto.Destino.Costos.Hoja) == destinoAntes && contexto.Contadores == contadores,
            "Cancelar o pulsar Escape debe volver a la celda de destino con su borrador, foco y cursor intactos, sin guardar ni generar historial.");
    }

    private sealed class Contexto : IDisposable
    {
        internal MYGProyectoDocumento Proyecto;
        internal readonly string IdPresupuestoDestino, IdPresupuestoOrigen, IdDestino, IdOrigen;
        internal string IdPresupuestoActivo;
        internal int Antes, Cambios, Guardados;
        internal MYGHojaMetrado EstadoAnterior;
        internal readonly MYGPanelPresupuesto Panel;
        internal readonly Form Formulario;
        internal DataGridView Hoja => Campo<DataGridView>(Panel, "hoja");
        internal RichTextBox Formula => Campo<RichTextBox>(Panel, "formula");
        internal TabPage PaginaExcel => Campo<TabPage>(Panel, "paginaExcel");
        internal MYGPresupuestoDocumento PresupuestoActivo => Proyecto.Presupuestos.Single(p => p.Id == IdPresupuestoActivo);
        internal MYGPresupuestoDocumento PresupuestoDestino => Proyecto.Presupuestos.Single(p => p.Id == IdPresupuestoDestino);
        internal MYGPresupuestoDocumento PresupuestoOrigen => Proyecto.Presupuestos.Single(p => p.Id == IdPresupuestoOrigen);
        internal ItemPresupuestoDelphin Destino => PresupuestoDestino.Items.Single(i => i.Id == IdDestino);
        internal ItemPresupuestoDelphin Origen => PresupuestoOrigen.Items.Single(i => i.Id == IdOrigen);
        internal (int Antes, int Cambios, int Guardados) Contadores => (Antes, Cambios, Guardados);

        internal Contexto()
        {
            Proyecto = MYGProyectoStorage.Nuevo("Referencias entre partidas", "ARQUITECTURA");
            IdPresupuestoDestino = Proyecto.Presupuestos.Single().Id;
            var presupuestoOrigen = new MYGPresupuestoDocumento
            { Nombre = "ESTRUCTURAS", Item = "02", Posicion = 2 };
            Proyecto.Presupuestos.Add(presupuestoOrigen);
            IdPresupuestoOrigen = presupuestoOrigen.Id;
            IdPresupuestoActivo = IdPresupuestoDestino;
            IdDestino = MYGProyectoStorage.NuevoId();
            IdOrigen = MYGProyectoStorage.NuevoId();
            PresupuestoDestino.Items.Add(Partida(IdDestino, "01", "ENCOFRADO", 1m));
            presupuestoOrigen.Items.Add(Partida(IdOrigen, "02", "CONCRETO EN COLUMNAS", 4m));
            Origen.Costos.Hoja.Poner("B3", "3");
            Origen.Costos.Hoja.Poner("B4", "5");
            Origen.Costos.Hoja.Poner("B8", "7");
            MYGEdicionHoja.Combinar(Origen.Costos.Hoja, "B8:C8");
            Panel = new MYGPanelPresupuesto(() => PresupuestoActivo,
                () => { Antes++; EstadoAnterior = MYGProyectoStorage.Copia(Destino.Costos.Hoja); },
                () => Cambios++, _ => { }, () => Task.CompletedTask, _ => { }, () => Guardados++);
            Panel.InicializarEstructura(() => Proyecto,
                id => { if (id != null) { IdPresupuestoActivo = id; Proyecto.PresupuestoActivoId = id; } },
                _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
            Formulario = new Form { ClientSize = new Size(1800, 1100) };
            Formulario.Controls.Add(Panel);
            Formulario.Show();
            Panel.Refrescar();
            // Cargar ambas hojas antes de capturar sus estados evita confundir
            // la reparación de formatos antiguos con el acto de referenciar.
            Panel.SeleccionarEstructura(Origen);
            ((TabControl)PaginaExcel.Parent).SelectedTab = PaginaExcel;
            Application.DoEvents();
            Panel.SeleccionarEstructura(Destino);
            ((TabControl)PaginaExcel.Parent).SelectedTab = PaginaExcel;
            Application.DoEvents();
        }

        public void Dispose() { Formulario.Close(); Formulario.Dispose(); Panel.Dispose(); }
    }

    private static ItemPresupuestoDelphin Partida(string id, string item, string descripcion, decimal cantidad) => new()
    {
        Id = id, Item = item, Descripcion = descripcion, Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
        Costos = new MYGDatosPartida { Cantidad = cantidad, PrecioDirecto = 10m }
    };
    private static void Iniciar(Contexto contexto)
    {
        Invocar(contexto.Panel, "IniciarReferenciaPartidaHoja", contexto.PresupuestoOrigen, contexto.Origen);
        Application.DoEvents();
    }
    private static void Elegir(Contexto contexto, string direccion)
    {
        var celda = MYGHojaCalculo.Coordenadas(direccion);
        Invocar(contexto.Panel, "SeleccionarCeldaReferenciaPartidaHoja", celda.Fila - 1, celda.Columna - 1);
        Application.DoEvents();
    }
    private static void ElegirConClic(Contexto contexto, string direccion, Action<bool, string> exige)
    {
        var celda = MYGHojaCalculo.Coordenadas(direccion);
        var area = contexto.Hoja.GetCellDisplayRectangle(celda.Columna - 1, celda.Fila - 1, false);
        int x = area.Left + area.Width / 2, y = area.Top + area.Height / 2;
        var mensaje = Message.Create(contexto.Hoja.Handle, 0x0201, new IntPtr(1),
            new IntPtr((x & 0xffff) | ((y & 0xffff) << 16)));
        exige(Campo<IMessageFilter>(contexto.Panel, "filtroElegirReferenciasHoja").PreFilterMessage(ref mensaje),
            "El clic real sobre la hoja de origen debe consumirse para elegir su celda sin iniciar una edición.");
        Application.DoEvents();
    }
    private static bool Eligiendo(MYGPanelPresupuesto panel) =>
        (bool)panel.GetType().GetProperty("EligiendoReferenciaPartidaHoja", Privados).GetValue(panel);
    private static string Estado<T>(T valor) => JsonSerializer.Serialize(valor);
    private static string EstadoDatosOrigen(MYGDatosPartida datos)
    {
        // Al aplicar, las anclas de seguimiento se añaden al origen para
        // conservar la referencia después de insertar filas. Los valores,
        // formatos y la fuente de cantidad del origen deben seguir intactos.
        var copia = MYGProyectoStorage.Copia(datos);
        copia.Hoja.AnclasReferencias.Clear();
        return Estado(copia);
    }
    private static string Contenido(MYGHojaMetrado hoja, string direccion) =>
        hoja.Celdas.TryGetValue(direccion, out var celda) ? celda.Contenido : "";
    private static decimal NumeroMostrado(DataGridView hoja, string direccion)
    {
        var celda = MYGHojaCalculo.Coordenadas(direccion);
        return decimal.Parse(Convert.ToString(hoja[celda.Columna - 1, celda.Fila - 1].Value),
            System.Globalization.CultureInfo.CurrentCulture);
    }
    private static IEnumerable<Control> Controles(Control control)
    {
        yield return control;
        foreach (Control hijo in control.Controls)
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
    }
    private static void Seleccionar(DataGridView hoja, string direccion)
    {
        var celda = MYGHojaCalculo.Coordenadas(direccion);
        hoja.ClearSelection();
        hoja.CurrentCell = hoja[celda.Columna - 1, celda.Fila - 1];
        hoja.CurrentCell.Selected = true;
        Application.DoEvents();
    }
    private static void Escribir(TextBoxBase editor, string texto)
    { editor.Focus(); editor.Text = texto; editor.Select(texto.Length, 0); Application.DoEvents(); }
    private static string DireccionActual(DataGridView hoja) =>
        MYGHojaCalculo.Columna(hoja.CurrentCell.ColumnIndex + 1) + (hoja.CurrentCell.RowIndex + 1);
    private static void Tecla(Control control, Keys tecla)
    { InvocarEn(typeof(Control), control, "OnKeyDown", new KeyEventArgs(tecla)); Application.DoEvents(); }
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static void Invocar(object objeto, string nombre, params object[] argumentos) =>
        InvocarEn(objeto.GetType(), objeto, nombre, argumentos);
    private static object InvocarEn(Type tipo, object objeto, string nombre, params object[] argumentos)
    {
        try
        {
            var metodo = tipo.GetMethods(Privados).Single(m => m.Name == nombre &&
                m.GetParameters().Length == argumentos.Length &&
                m.GetParameters().Select((p, i) => argumentos[i] == null ||
                    p.ParameterType.IsInstanceOfType(argumentos[i])).All(coincide => coincide));
            return metodo.Invoke(objeto, argumentos);
        }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
