using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoAutocompletadoCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarTokens(exige);
        var proyecto = MYGProyectoStorage.Nuevo("Funciones predictivas", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "CONCRETO",
            Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
        };
        partida.Costos.Hoja.Poner("B3", "2"); partida.Costos.Hoja.Poner("C3", "3");
        presupuesto.Items.Add(partida);
        int anteriores = 0, cambios = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1800, 1000) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        ((TabControl)pagina.Parent).SelectedTab = pagina;
        Application.DoEvents();
        var hoja = Campo<DataGridView>(panel, "hoja");
        var formula = Campo<TextBoxBase>(panel, "formula");
        Seleccionar(hoja, "I20");

        Escribir(panel, formula, "=S");
        exige(panel.EstadoAutocompletadoHoja.Count > 1 && panel.EstadoAutocompletadoHoja.Any(x => x.Nombre == "SUMA") &&
            panel.EstadoAutocompletadoHoja.Any(x => x.Nombre == "SI") && formula.Focused,
            "Escribir =S en la barra debe mostrar las funciones en español sin robar el foco.");
        var lista = Campo<MYGListaFuncionesHoja>(panel, "listaFuncionesHoja");
        var descripcion = Controles(lista).OfType<Label>().Single(x => x.Name == "metrado_descripcion_funcion");
        exige(descripcion.Text.Contains(lista.Seleccionada.Descripcion) && descripcion.Text.Contains(lista.Seleccionada.Sintaxis),
            "La función seleccionada debe mostrar su descripción y sintaxis.");
        string primera = lista.Seleccionada.Nombre;
        exige(Pulsar(panel, formula, Keys.Down) && lista.Seleccionada.Nombre != primera && formula.Focused && formula.Text == "=S",
            "Flecha abajo debe recorrer la lista sin mover la celda ni alterar la fórmula.");
        exige(Pulsar(panel, formula, Keys.Up) && lista.Seleccionada.Nombre == primera,
            "Flecha arriba debe regresar a la función anterior.");
        var posicion = lista.Location;
        formulario.Location = new Point(formulario.Left + 12, formulario.Top + 8); Application.DoEvents();
        exige(lista.Location != posicion && formula.Focused,
            "Mover la ventana principal debe mantener la lista junto al editor.");

        Escribir(panel, formula, "=1+SUM(B3:C3)+5", "=1+SU".Length);
        exige(Pulsar(panel, formula, Keys.Tab) && formula.Text == "=1+SUMA(B3:C3)+5" &&
            formula.SelectionStart == "=1+SUMA(".Length && !lista.Visible && formula.Focused &&
            !partida.Costos.Hoja.Celdas.ContainsKey("I20") && anteriores == 0 && cambios == 0,
            "Tab debe reemplazar el token completo y conservar argumentos, resto de la fórmula y modelo sin confirmar la celda.");
        Escribir(panel, formula, "=RA");
        exige(Pulsar(panel, formula, Keys.Enter) && formula.Text == "=RADIANES(" && formula.Focused &&
            !partida.Costos.Hoja.Celdas.ContainsKey("I20"),
            "Enter sobre una sugerencia debe insertar la función con paréntesis y mantener la edición pendiente.");

        Escribir(panel, formula, "=S");
        exige(Pulsar(panel, formula, Keys.Escape) && !lista.Visible && formula.Text == "=S" && formula.Focused,
            "Escape debe cerrar sólo la lista sin descartar la fórmula.");
        Invocar(panel, "ActualizarAutocompletadoHoja", formula);
        exige(!lista.Visible, "Soltar Escape no debe volver a abrir la misma lista descartada.");
        Escribir(panel, formula, "=SE");
        exige(lista.Visible, "Cambiar el prefijo después de Escape debe permitir nuevas sugerencias.");
        Invocar(panel, "CancelarEdicionHoja");

        Escribir(panel, formula, "=SQ");
        exige(panel.EstadoAutocompletadoHoja.Any(x => x.Nombre == "RAIZ"),
            "Un prefijo inglés debe sugerir la función equivalente en español.");
        Escribir(panel, formula, "=SI(A1=\"S");
        exige(!lista.Visible, "Un literal de texto dentro de una fórmula no debe sugerir funciones.");
        Escribir(panel, formula, "SUMA");
        exige(!lista.Visible, "Un texto que no comienza con igual no debe sugerir funciones.");
        Invocar(panel, "CancelarEdicionHoja");

        Seleccionar(hoja, "I20"); hoja.BeginEdit(true); Application.DoEvents();
        var editor = (TextBoxBase)hoja.EditingControl;
        Escribir(panel, editor, "=SU");
        exige(panel.EstadoAutocompletadoHoja.Count != 0 && editor.Focused,
            "Editar una celda debe ofrecer la misma lista predictiva que la barra de fórmulas.");
        exige(Pulsar(panel, editor, Keys.Tab) && editor.Text == "=SUMA(" && hoja.IsCurrentCellInEditMode && editor.Focused,
            "Tab en una celda debe insertar la función sin saltar a otra celda ni finalizar la edición.");
        editor.Text = "=SUMA(B3:C3)";
        exige(hoja.EndEdit(), "Debe poder confirmarse la fórmula completada en la celda.");
        Application.DoEvents();
        exige(!lista.Visible && partida.Costos.Hoja.Celdas["I20"].Contenido == "=SUMA(B3:C3)" &&
            new MYGHojaCalculo(partida.Costos.Hoja).Numero("I20") == 5m && anteriores == 1 && cambios == 1,
            "Confirmar la fórmula debe cerrar la lista y guardar una sola modificación calculable.");

        Seleccionar(hoja, "I21"); hoja.BeginEdit(true); Application.DoEvents();
        var reutilizado = (TextBoxBase)hoja.EditingControl;
        Escribir(panel, reutilizado, "=S");
        exige(ReferenceEquals(editor, reutilizado) && lista.Visible,
            "El editor reutilizado por DataGridView debe conservar el autocompletado en otra celda.");
        primera = lista.Seleccionada.Nombre;
        Pulsar(panel, reutilizado, Keys.Down);
        exige(lista.Seleccionada.Nombre == panel.EstadoAutocompletadoHoja[1].Nombre && lista.Seleccionada.Nombre != primera,
            "Reutilizar el editor no debe duplicar los manejadores de navegación.");
        exige(Pulsar(panel, reutilizado, Keys.Escape) && hoja.IsCurrentCellInEditMode && reutilizado.Text == "=S" && !lista.Visible,
            "Escape con sugerencias en una celda debe mantener el texto y la edición.");
        hoja.CancelEdit(); Application.DoEvents();
        exige(!lista.Visible && !partida.Costos.Hoja.Celdas.ContainsKey("I21") && anteriores == 1 && cambios == 1,
            "Cancelar una celda debe conservar los datos previos y cerrar las sugerencias.");
        formulario.Close();
    }

    private static void VerificarTokens(Action<bool, string> exige)
    {
        foreach (string texto in new[] { "=SU", "=1+SU", "=SI(1;SU", "=SI.ERROR", "=LOG10" })
            exige(MYGPanelPresupuesto.BuscarTokenFuncionHoja(texto, texto.Length, out _, out _, out _),
                $"Debe reconocerse el token de función en {texto}.");
        foreach (string texto in new[] { "SU", "=", "=SUMA(\"SU", "=\"Texto \"\"SU", "='SU", "=$SU", "=A1:SU", "=Hoja!SU" })
            exige(!MYGPanelPresupuesto.BuscarTokenFuncionHoja(texto, texto.Length, out _, out _, out _),
                $"No debe sugerirse una función dentro de texto, referencias o tokens vacíos: {texto}.");
        exige(MYGPanelPresupuesto.BuscarTokenFuncionHoja("=1+SUM(B3)", 5, out int inicio, out int fin, out string prefijo) &&
            inicio == 3 && fin == 6 && prefijo == "SU",
            "El cursor dentro de un identificador debe reconocer el prefijo y todo el token a reemplazar.");
    }

    private static void Escribir(MYGPanelPresupuesto panel, TextBoxBase editor, string texto, int? cursor = null)
    {
        editor.Focus(); editor.Text = texto; editor.Select(cursor ?? texto.Length, 0);
        Invocar(panel, "ActualizarAutocompletadoHoja", editor); Application.DoEvents();
    }

    private static bool Pulsar(MYGPanelPresupuesto panel, TextBoxBase editor, Keys tecla)
    {
        // Se usa el mismo filtro que precede al procesamiento de teclas de
        // diálogo del DataGridView; KeyDown por sí solo no reproduce Tab/Enter.
        var filtro = Campo<IMessageFilter>(panel, "filtroFuncionesHoja");
        var mensaje = Message.Create(editor.Handle, 0x100, new IntPtr((int)tecla), IntPtr.Zero);
        bool consumida = filtro.PreFilterMessage(ref mensaje); Application.DoEvents();
        return consumida;
    }

    private static void Seleccionar(DataGridView hoja, string direccion)
    {
        var c = MYGHojaCalculo.Coordenadas(direccion);
        hoja.ClearSelection(); hoja.CurrentCell = hoja[c.Columna - 1, c.Fila - 1]; hoja.CurrentCell.Selected = true;
        Application.DoEvents();
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static void Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
