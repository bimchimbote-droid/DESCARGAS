using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoCierreFormulaCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Cierre de fórmulas", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "CONCRETO",
            Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
        };
        partida.Costos.Hoja.Poner("B3", "2"); partida.Costos.Hoja.Poner("C3", "3");
        presupuesto.Items.Add(partida);
        int anteriores = 0, cambios = 0;
        MYGHojaMetrado estadoAnterior = null;
        using var panel = new MYGPanelPresupuesto(() => presupuesto,
            () => { anteriores++; estadoAnterior = MYGProyectoStorage.Copia(partida.Costos.Hoja); },
            () => cambios++, _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1800, 1000) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        ((TabControl)pagina.Parent).SelectedTab = pagina;
        Application.DoEvents();
        var hoja = Campo<DataGridView>(panel, "hoja");
        var formula = Campo<TextBoxBase>(panel, "formula");

        Seleccionar(hoja, "I20");
        formula.Focus(); formula.Text = "=SUMA(B3:C3"; formula.Select(formula.TextLength, 0);
        var previo = (anteriores, cambios);
        Tecla(formula, Keys.Enter);
        exige(partida.Costos.Hoja.Celdas["I20"].Contenido == "=SUMA(B3:C3)" &&
            formula.Text == "=SUMA(B3:C3)" && new MYGHojaCalculo(partida.Costos.Hoja).Numero("I20") == 5m &&
            (anteriores, cambios) == (previo.anteriores + 1, previo.cambios + 1) &&
            !estadoAnterior.Celdas.ContainsKey("I20"),
            "Enter en la barra debe completar el cierre, calcular cinco y registrar un solo estado anterior a la edición.");

        formula.Focus(); formula.Text = "=SUMA(B3:C3"; formula.Select(formula.TextLength, 0);
        previo = (anteriores, cambios);
        Invocar(panel, "AplicarFormula"); Application.DoEvents();
        exige(formula.Text == "=SUMA(B3:C3)" && (anteriores, cambios) == previo &&
            !Campo<bool>(panel, "formulaPendienteHoja"),
            "Confirmar la misma fórmula sin su cierre debe mostrarla completa y no crear otro cambio ni dejarla pendiente.");

        Seleccionar(hoja, "I21"); hoja.BeginEdit(true); Application.DoEvents();
        var editor = (TextBoxBase)hoja.EditingControl;
        editor.Text = "=SI(1;SUMA(B3:C3";
        previo = (anteriores, cambios);
        exige(hoja.EndEdit(), "Debe poder confirmarse una función anidada con dos cierres pendientes.");
        Application.DoEvents();
        exige(partida.Costos.Hoja.Celdas["I21"].Contenido == "=SI(1;SUMA(B3:C3))" &&
            new MYGHojaCalculo(partida.Costos.Hoja).Numero("I21") == 5m &&
            formula.Text == "=SI(1;SUMA(B3:C3))" &&
            (anteriores, cambios) == (previo.anteriores + 1, previo.cambios + 1) &&
            !estadoAnterior.Celdas.ContainsKey("I21"),
            "Confirmar desde la celda debe cerrar todas las funciones, sincronizar la barra y conservar un solo cambio para deshacer.");

        var regla = MYGEdicionHoja.Celda(partida.Costos.Hoja, "I22");
        regla.TipoValidacion = "Entero"; regla.Minimo = 0; regla.Maximo = 10;
        Seleccionar(hoja, "I22"); hoja.BeginEdit(true); Application.DoEvents();
        ((TextBoxBase)hoja.EditingControl).Text = "=SUMA(B3:C3";
        exige(hoja.EndEdit(), "La validación numérica debe evaluar la fórmula con su cierre completado.");
        Application.DoEvents();
        exige(regla.Contenido == "=SUMA(B3:C3)" && new MYGHojaCalculo(partida.Costos.Hoja).Numero("I22") == 5m,
            "Una celda con validación debe guardar la fórmula completa que satisface sus límites.");

        hoja.BeginEdit(true); Application.DoEvents();
        ((TextBoxBase)hoja.EditingControl).Text = "=SUMA(B3:C3;100";
        previo = (anteriores, cambios);
        exige(!hoja.EndEdit() && regla.Contenido == "=SUMA(B3:C3)" && (anteriores, cambios) == previo,
            "El autocierre no debe permitir que una fórmula sobrepase los límites de validación ni modificar el historial.");
        hoja.CancelEdit(); Application.DoEvents();

        formula.Focus(); formula.Text = "=SUMA(B3:C3;100";
        bool rechazada = false;
        try { Invocar(panel, "AplicarFormula"); }
        catch (InvalidDataException) { rechazada = true; }
        exige(rechazada && regla.Contenido == "=SUMA(B3:C3)" && formula.Text == "=SUMA(B3:C3;100" &&
            (anteriores, cambios) == previo,
            "La barra debe conservar la fórmula pendiente y el modelo cuando la fórmula completada no cumple su validación.");
        Invocar(panel, "CancelarEdicionHoja");

        partida.Costos.Hoja.Poner("I23", "=SUMA(B3:C3");
        Invocar(panel, "RecalcularHoja");
        Seleccionar(hoja, "I23"); hoja.BeginEdit(true); Application.DoEvents();
        ((TextBoxBase)hoja.EditingControl).Text = "=SUMA(B3:C3;4";
        previo = (anteriores, cambios);
        hoja.CancelEdit(); Application.DoEvents();
        exige(partida.Costos.Hoja.Celdas["I23"].Contenido == "=SUMA(B3:C3" && (anteriores, cambios) == previo,
            "Cancelar la celda debe recuperar exactamente una fórmula antigua incompleta sin cerrarla ni crear historial.");

        Seleccionar(hoja, "I24"); formula.Focus(); formula.Text = "=SUMA(B3:C3";
        Tecla(formula, Keys.Escape);
        exige(!partida.Costos.Hoja.Celdas.ContainsKey("I24") && formula.Text == "" && (anteriores, cambios) == previo,
            "Escape en la barra debe descartar una fórmula con cierres pendientes sin guardarla.");

        Seleccionar(hoja, "I25"); hoja.BeginEdit(true); Application.DoEvents();
        ((TextBoxBase)hoja.EditingControl).Text = "Texto (sin cierre";
        exige(hoja.EndEdit(), "Debe poder guardarse texto normal con paréntesis abiertos.");
        Application.DoEvents();
        exige(partida.Costos.Hoja.Celdas["I25"].Contenido == "Texto (sin cierre",
            "El cierre automático debe aplicarse sólo a fórmulas.");
        formulario.Close();
    }

    private static void Seleccionar(DataGridView hoja, string direccion)
    {
        var c = MYGHojaCalculo.Coordenadas(direccion);
        hoja.ClearSelection(); hoja.CurrentCell = hoja[c.Columna - 1, c.Fila - 1]; hoja.CurrentCell.Selected = true;
        Application.DoEvents();
    }

    private static void Tecla(Control control, Keys tecla)
    {
        typeof(Control).GetMethod("OnKeyDown", Privados).Invoke(control, new object[] { new KeyEventArgs(tecla) });
        Application.DoEvents();
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static void Invocar(object objeto, string nombre)
    {
        try { objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, null); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
