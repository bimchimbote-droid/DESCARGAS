using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class CronogramaMenusUICheck
{
    internal static readonly string[] NombresImpresion =
    {
        "imprimir_presupuesto_seleccionado", "imprimir_todos_presupuestos", "imprimir_hoja_resumen",
        "imprimir_analisis_costos_unitarios", "imprimir_consolidado_costos_unitarios", "imprimir_metrados",
        "exportar_metrados_excel", "imprimir_metrados_aceros", "exportar_metrados_aceros_excel",
        "exportar_metrados_por_plantilla_excel", "imprimir_programacion_gantt"
    };

    internal static readonly string[] NombresExportacion =
    {
        "cronograma_exportar_nativo", "cronograma_exportar_project_tareas", "cronograma_exportar_project_recursos",
        "cronograma_exportar_xml_tareas", "cronograma_exportar_xml_recursos", "cronograma_exportar_pdf",
        "cronograma_exportar_xlsx", "cronograma_exportar_texto", "cronograma_exportar_mht", "cronograma_exportar_csv"
    };

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarExportacion(exige);
        VerificarImpresion(exige);
    }

    private static void VerificarExportacion(Action<bool, string> exige)
    {
        var ejecuciones = new List<MYGDestinoExportacionCronograma>();
        using var menu = MYGMenuExportacionCronograma.Crear(ejecuciones.Add);
        var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
        var destinos = new[]
        {
            MYGDestinoExportacionCronograma.Nativo,
            MYGDestinoExportacionCronograma.ProjectTareas, MYGDestinoExportacionCronograma.ProjectRecursos,
            MYGDestinoExportacionCronograma.XmlTareas, MYGDestinoExportacionCronograma.XmlRecursos,
            MYGDestinoExportacionCronograma.Pdf, MYGDestinoExportacionCronograma.Xlsx,
            MYGDestinoExportacionCronograma.Texto, MYGDestinoExportacionCronograma.Mht,
            MYGDestinoExportacionCronograma.Csv
        };
        exige(opciones.Select(o => o.Name).SequenceEqual(NombresExportacion) && opciones.All(o => o.Enabled),
            "Exportar cronograma debe ofrecer sus diez destinos en el orden solicitado, separando Project y XML, tareas y recursos.");
        exige(ejecuciones.Count == 0,
            "Construir el desplegable de Exportar no debe generar archivos ni iniciar aplicaciones externas.");
        foreach (var opcion in opciones) opcion.PerformClick();
        exige(ejecuciones.SequenceEqual(destinos),
            "Cada destino de Exportar debe invocar una sola vez su callback exacto, sin intercambiar tareas, recursos, MPP ni XML.");

        foreach (var alcance in new[] { "tareas", "recursos" })
        {
            var mpp = opciones.Single(o => o.Name == "cronograma_exportar_project_" + alcance);
            var xml = opciones.Single(o => o.Name == "cronograma_exportar_xml_" + alcance);
            string Descripcion(ToolStripMenuItem item) => item.Text + " " + item.ToolTipText + " " + item.AccessibleDescription;
            exige(Descripcion(mpp).Contains(".mpp", StringComparison.OrdinalIgnoreCase) &&
                Descripcion(xml).Contains("XML", StringComparison.OrdinalIgnoreCase) && mpp.Text != xml.Text,
                "Los destinos Project y XML deben explicar formatos distintos; un archivo XML no debe presentarse como un MPP nativo.");
        }
    }

    private static void VerificarImpresion(Action<bool, string> exige)
    {
        var ejecuciones = new List<string>();
        using var menu = EditorForm.CrearMenuImprimirProyecto(
            tipo => ejecuciones.Add("imprimir:" + tipo),
            plantilla => ejecuciones.Add("excel:" + (plantilla ?? "todas")),
            () => ejecuciones.Add("excel:por_plantilla"), true, true, true, true, true,
            () => ejecuciones.Add("gantt"));
        var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
        exige(opciones.Select(o => o.Name).SequenceEqual(NombresImpresion) && opciones.All(o => o.Enabled),
            "Imprimir desde CPM debe conservar los diez reportes de presupuesto y añadir Programación Gantt como último destino.");
        exige(opciones[^1].Text.Contains("Gantt", StringComparison.OrdinalIgnoreCase) && ejecuciones.Count == 0,
            "Abrir el menú de impresión debe identificar Programación Gantt sin imprimir ni abrir todavía una vista previa.");
        foreach (var opcion in opciones) opcion.PerformClick();
        exige(ejecuciones.SequenceEqual(new[]
        {
            "imprimir:" + MYGTipoReporteProyecto.PresupuestoSeleccionado,
            "imprimir:" + MYGTipoReporteProyecto.TodosPresupuestos,
            "imprimir:" + MYGTipoReporteProyecto.HojaResumen,
            "imprimir:" + MYGTipoReporteProyecto.AnalisisCostosUnitarios,
            "imprimir:" + MYGTipoReporteProyecto.ConsolidadoCostosUnitarios,
            "imprimir:" + MYGTipoReporteProyecto.Metrados,
            "excel:todas", "imprimir:" + MYGTipoReporteProyecto.MetradosAceros,
            "excel:" + MYGPlantillasMetrado.Aceros, "excel:por_plantilla", "gantt"
        }), "Los destinos heredados de presupuesto y Programación Gantt deben conservar su enrutado y ejecutarse una sola vez por clic.");
    }
}
