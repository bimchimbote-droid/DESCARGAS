using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesMargenesDibujoCheck
{
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")]
    private static extern bool RedrawWindow(IntPtr ventana, IntPtr rectangulo, IntPtr region, uint opciones);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        if (!OperatingSystem.IsWindows() || SystemInformation.HighContrast) return;
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        Point cursorOriginal = Cursor.Position;
        try
        {
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                Verificar(oscuro, exige);
            }
        }
        finally
        {
            Cursor.Position = cursorOriginal;
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void Verificar(bool oscuro, Action<bool, string> exige)
    {
        int cambios = 0;
        using var documento = new MYGEspecificacionesRichTextBox { DetectUrls = false, HideSelection = false };
        using var editor = new MYGEspecificacionesEditor(documento, () => { }, () => cambios++,
            () => "PARTIDA", () => "m²", () => "01.01",
            comprobarOrtografia: _ => Array.Empty<MYGErrorOrtografico>());
        Rectangle pantalla = Screen.PrimaryScreen.WorkingArea;
        using var formulario = new Form
        {
            Text = "Prueba del dibujo al arrastrar márgenes",
            StartPosition = FormStartPosition.Manual,
            Location = new Point(pantalla.Left + 10, pantalla.Top + 10),
            ClientSize = new Size(Math.Min(980, pantalla.Width - 40), Math.Min(780, pantalla.Height - 80))
        };
        // Mantener el foco fuera de RichEdit evita que el caret parpadeante
        // cambie las capturas mientras se comparan píxeles reales de pantalla.
        using var foco = new Button { Text = "Foco de prueba", Dock = DockStyle.Bottom, Height = 24 };
        formulario.Controls.Add(editor);
        formulario.Controls.Add(foco);
        formulario.Show();
        editor.Cargar("margenes-dibujo", CrearRtf(), "");
        var controles = Descendientes(editor).ToArray();
        var papel = controles.OfType<Panel>().Single(c => c.Name == "espec_papel");
        var lienzo = controles.OfType<Panel>().Single(c => c.Name == "espec_lienzo");
        var horizontal = controles.OfType<MYGEspecificacionesRegla>().Single(c => c.Name == "espec_regla_horizontal");
        var vertical = controles.OfType<MYGEspecificacionesRegla>().Single(c => c.Name == "espec_regla_vertical");
        var zoom = controles.OfType<NumericUpDown>().Single(c => c.Name == "espec_zoom");
        foco.Focus();
        Cursor.Position = foco.PointToScreen(new Point(8, 8));
        documento.Select(0, 0);
        string texto = documento.Text, contenido = documento.Rtf;

        foreach (int porcentaje in new[] { 100, 150 })
        {
            zoom.Value = porcentaje;
            Application.DoEvents();
            foreach (var (esVertical, inicio) in new[] { (false, true), (false, false), (true, true), (true, false) })
            {
                var regla = esVertical ? vertical : horizontal;
                // Mostrar también los pines derecho e inferior de una hoja
                // ampliada y recortada por el desplazamiento del lienzo.
                lienzo.AutoScrollPosition = esVertical
                    ? new Point(0, inicio ? 0 : int.MaxValue / 2)
                    : new Point(inicio ? 0 : int.MaxValue / 2, 0);
                Application.DoEvents();
                Point pin = Pin(editor, regla, papel, esVertical, inicio);
                exige(regla.ClientRectangle.Contains(pin), "La prueba visual debe arrastrar un pin visible.");
                int cambiosIniciales = cambios;
                EnviarRaton(regla, 0x0201, pin, presionado: true);
                exige(regla.Arrastrando, "El arrastre visual debe comenzar en el pin real de la regla.");
                Point destino = pin;
                foreach (int mm in new[] { 6, 12, 4 })
                {
                    int desplazamiento = (int)Math.Round(mm * editor.DeviceDpi * documento.ZoomFactor / 25.4f)
                        * (inicio ? 1 : -1);
                    destino = esVertical ? new Point(pin.X, pin.Y + desplazamiento)
                        : new Point(pin.X + desplazamiento, pin.Y);
                    EnviarRaton(regla, 0x0200, destino, presionado: true);
                    VerificarCuadro(papel, documento, oscuro, exige,
                        $"margen {(esVertical ? "vertical" : "horizontal")}, {(inicio ? "inicial" : "final")}, {porcentaje} %, {mm} mm");
                    exige(documento.Text == texto && documento.Rtf == contenido && cambios == cambiosIniciales,
                        "La vista previa del margen sólo debe cambiar el diseño, sin duplicar texto ni registrar ediciones.");
                }
                EnviarRaton(regla, 0x0202, destino, presionado: false);
                VerificarCuadro(papel, documento, oscuro, exige, "margen confirmado");
                exige(!regla.Arrastrando && documento.Text == texto && documento.Rtf == contenido &&
                    cambios == cambiosIniciales + 1,
                    "Confirmar el margen debe conservar el texto y guardar una sola modificación del diseño.");
            }
        }
        formulario.Close();
    }

    private static void VerificarCuadro(Panel papel, RichTextBox documento, bool oscuro,
        Action<bool, string> exige, string paso)
    {
        Rectangle visible = Visible(papel);
        exige(visible.Width > 80 && visible.Height > 80, "El dibujo del margen debe comprobar una región visible del papel.");
        byte[] antes = Capturar(visible);
        // La imagen que deja el arrastre debe coincidir con una reconstrucción
        // completa desde RichEdit. El borrado explícito de referencia descubre
        // letras o fragmentos de líneas que quedan pegados en posiciones viejas.
        const uint Invalidar = 0x0001, Borrar = 0x0004, Hijos = 0x0080, Ahora = 0x0100, Marco = 0x0400;
        RedrawWindow(papel.Handle, IntPtr.Zero, IntPtr.Zero, Invalidar | Borrar | Hijos | Ahora | Marco);
        Application.DoEvents();
        byte[] despues = Capturar(visible);
        exige(antes.SequenceEqual(despues),
            "Arrastrar márgenes debe dejar un cuadro limpio sin texto superpuesto antes de un repintado adicional: " + paso + ".");
        byte[] letras = Capturar(Visible(documento));
        int tinta = 0;
        for (int i = 0; i < letras.Length; i += 4)
        {
            int brillo = Math.Max(letras[i], Math.Max(letras[i + 1], letras[i + 2]))
                + Math.Min(letras[i], Math.Min(letras[i + 1], letras[i + 2]));
            if (oscuro ? brillo > 331 : brillo < 179) tinta++;
        }
        exige(tinta > 100, "La comparación del margen debe incluir texto dibujado y no sólo fondo vacío: " + paso + ".");
    }

    private static byte[] Capturar(Rectangle region)
    {
        if (region.Width <= 0 || region.Height <= 0)
            throw new InvalidOperationException("La captura exige una región visible en pantalla.");
        using var imagen = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppRgb);
        using (var grafico = Graphics.FromImage(imagen))
            grafico.CopyFromScreen(region.Location, Point.Empty, imagen.Size);
        var bloqueo = imagen.LockBits(new Rectangle(Point.Empty, imagen.Size), ImageLockMode.ReadOnly, PixelFormat.Format32bppRgb);
        try
        {
            var pixeles = new byte[checked(imagen.Width * imagen.Height * 4)];
            for (int y = 0; y < imagen.Height; y++)
                Marshal.Copy(IntPtr.Add(bloqueo.Scan0, y * bloqueo.Stride), pixeles, y * imagen.Width * 4, imagen.Width * 4);
            for (int i = 3; i < pixeles.Length; i += 4) pixeles[i] = 0;
            return pixeles;
        }
        finally { imagen.UnlockBits(bloqueo); }
    }

    private static Rectangle Visible(Control control)
    {
        Rectangle visible = control.RectangleToScreen(control.ClientRectangle);
        for (Control padre = control.Parent; padre != null; padre = padre.Parent)
            visible.Intersect(padre.RectangleToScreen(padre.ClientRectangle));
        visible.Intersect(Screen.FromControl(control).Bounds);
        return visible;
    }

    private static Point Pin(MYGEspecificacionesEditor editor, Control regla, Panel papel, bool vertical, bool inicio)
    {
        var pagina = editor.PaginaDocumento;
        float escala = editor.DeviceDpi * editor.Documento.ZoomFactor / 25.4f;
        Point origen = regla.PointToClient(papel.PointToScreen(Point.Empty));
        decimal longitud = vertical ? pagina.AltoMm : pagina.AnchoMm;
        decimal posicion = vertical ? inicio ? pagina.MargenSuperiorMm : longitud - pagina.MargenInferiorMm
            : inicio ? pagina.MargenIzquierdoMm : longitud - pagina.MargenDerechoMm;
        return vertical ? new Point((int)(regla.Width * .65f), origen.Y + (int)Math.Round((float)posicion * escala))
            : new Point(origen.X + (int)Math.Round((float)posicion * escala), regla.Height / 2);
    }

    private static void EnviarRaton(Control regla, int mensaje, Point punto, bool presionado)
    {
        Enviar(regla.Handle, mensaje, new IntPtr(presionado ? 1 : 0),
            new IntPtr(unchecked((punto.Y << 16) | (punto.X & 0xffff))));
        Application.DoEvents();
    }

    private static string CrearRtf()
    {
        var rtf = new StringBuilder(@"{\rtf1\ansi\deff0\uc1{\fonttbl{\f0 Arial;}}\f0\fs22\b 01.01 PARTIDA\b0  (unidad de medida: m\u178?)\par\par\b DESCRIPCI\u211?N:\b0\par ");
        for (int i = 0; i < 140; i++)
            rtf.Append("Linea ").Append(i).Append(@": texto conservado al arrastrar los margenes de la pagina.\par ");
        return rtf.Append('}').ToString();
    }

    private static IEnumerable<Control> Descendientes(Control control)
    {
        foreach (Control hijo in control.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
