using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoSeleccionReferenciasCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private const int MouseDown = 0x0201, MouseMove = 0x0200, MouseUp = 0x0202;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Referencias seleccionadas", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            var partida = new ItemPresupuestoDelphin
            {
                Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "CONCRETO",
                Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
                Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
            };
            partida.Costos.Hoja.Poner("C3", "2");
            partida.Costos.Hoja.Poner("C7", "5");
            presupuesto.Items.Add(partida);
            int anteriores = 0, cambios = 0, guardados = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1800, 1000) };
            formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
            var pagina = Campo<TabPage>(panel, "paginaExcel");
            ((TabControl)pagina.Parent).SelectedTab = pagina;
            Application.DoEvents();
            var hoja = Campo<DataGridView>(panel, "hoja");
            var formula = Campo<RichTextBox>(panel, "formula");
            Func<(int, int, int)> contadores = () => (anteriores, cambios, guardados);

            // Los mensajes pasan por el mismo filtro que intercepta el clic
            // antes de que DataGridView termine la edición de la celda origen.
            Seleccionar(hoja, "E12"); hoja.Focus();
            exige(hoja.BeginEdit(true) && hoja.EditingControl is RichTextBox,
                "La celda de fórmula debe abrir un editor que admita colores de referencias.");
            var editor = (RichTextBox)hoja.EditingControl;
            string original = Estado(partida.Costos.Hoja);
            var sinCambios = contadores();
            Escribir(editor, "=");
            Clic(panel, hoja, "C3", exige);
            exige(editor.Text == "=C3" && editor.SelectionStart == 3 && editor.Focused &&
                hoja.IsCurrentCellInEditMode && DireccionActual(hoja) == "E12" &&
                ReferenceEquals(editor, hoja.EditingControl),
                "Después de igual, un clic debe insertar C3 y conservar editor, foco y celda de destino.");
            editor.SelectedText = "+"; Application.DoEvents();
            Clic(panel, hoja, "C7", exige);
            exige(editor.Text == "=C3+C7" && formula.Text == editor.Text && editor.SelectionStart == editor.TextLength && editor.Focused &&
                DireccionActual(hoja) == "E12" && Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "Agregar un operador y elegir C7 debe formar =C3+C7 sin guardar borradores ni crear historial.");
            VerificarColores(panel, hoja, editor, true, exige);
            VerificarColores(panel, hoja, formula, false, exige);
            InvocarEn(typeof(DataGridView), hoja, "ProcessEnterKey", Keys.Enter);
            Application.DoEvents();
            exige(!hoja.IsCurrentCellInEditMode && new MYGHojaCalculo(partida.Costos.Hoja).Contenido("E12") == "=C3+C7" &&
                new MYGHojaCalculo(partida.Costos.Hoja).Numero("E12") == 7m &&
                contadores() == (sinCambios.Item1 + 1, sinCambios.Item2 + 1, sinCambios.Item3) &&
                panel.EstadoReferenciasHoja.Count == 0 && !hoja.Capture,
                "Enter debe guardar sólo la celda original, calcular siete y registrar una sola modificación.");

            Seleccionar(hoja, "E13"); Escribir(formula, "=SUMA(");
            original = Estado(partida.Costos.Hoja); sinCambios = contadores();
            Arrastrar(panel, hoja, "C3", "F5", exige);
            exige(formula.Text == "=SUMA(C3:F5" && formula.Focused && DireccionActual(hoja) == "E13" &&
                formula.SelectionStart == formula.TextLength && !hoja.Capture &&
                Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "Arrastrar desde la barra debe insertar un único rango y mantener la celda de destino sin confirmar.");
            formula.SelectedText = ")"; Application.DoEvents();
            VerificarColores(panel, hoja, formula, true, exige);
            Tecla(formula, Keys.Enter); Application.DoEvents();
            exige(new MYGHojaCalculo(partida.Costos.Hoja).Contenido("E13") == "=SUMA(C3:F5)" &&
                new MYGHojaCalculo(partida.Costos.Hoja).Numero("E13") == 2m &&
                contadores() == (sinCambios.Item1 + 1, sinCambios.Item2 + 1, sinCambios.Item3),
                "Enter en la barra debe conservar la fórmula del rango y registrar una sola modificación calculable.");

            Seleccionar(hoja, "E15"); Escribir(formula, "=SUMA($C$3:F$5)+SUMA($C$3:F$5)+10");
            original = Estado(partida.Costos.Hoja); sinCambios = contadores();
            var segunda = panel.EstadoReferenciasHoja[1];
            Point tirador = CentroTirador(panel, segunda, exige);
            exige(FiltrarMouse(panel, hoja, MouseMove, tirador) && hoja.Cursor == Cursors.SizeNWSE &&
                FiltrarMouse(panel, hoja, MouseDown, tirador) && FiltrarMouse(panel, hoja, MouseUp, tirador) &&
                formula.Text == "=SUMA($C$3:F$5)+SUMA($C$3:F$5)+10",
                "El tirador debe mostrar el cursor de ajuste y un clic sin arrastrar debe conservar el rango completo.");
            Redimensionar(panel, hoja, panel.EstadoReferenciasHoja[1], "H8", exige);
            exige(formula.Text == "=SUMA($C$3:F$5)+SUMA($C$3:H$8)+10" && formula.Focused &&
                DireccionActual(hoja) == "E15" && !hoja.Capture &&
                Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "El tirador debe ampliar sólo la aparición elegida, conservar signos $ y mantener el borrador sin historial.");
            Redimensionar(panel, hoja, panel.EstadoReferenciasHoja[1], "C3", exige);
            exige(formula.Text == "=SUMA($C$3:F$5)+SUMA($C$3)+10",
                "El tirador debe permitir reducir el rango a una sola celda sin cambiar la función ni el sufijo.");
            Tecla(formula, Keys.Escape); Application.DoEvents();
            exige(Estado(partida.Costos.Hoja) == original && contadores() == sinCambios &&
                panel.EstadoReferenciasHoja.Count == 0 && !hoja.Capture,
                "Escape debe descartar la referencia redimensionada y liberar el ratón.");

            Seleccionar(hoja, "E15"); hoja.Focus(); hoja.BeginEdit(true); Application.DoEvents();
            editor = (RichTextBox)hoja.EditingControl; Escribir(editor, "=SUMA(C3:F5)");
            Redimensionar(panel, hoja, panel.EstadoReferenciasHoja[0], "D4", exige);
            exige(editor.Text == "=SUMA(C3:D4)" && editor.Focused && hoja.IsCurrentCellInEditMode &&
                DireccionActual(hoja) == "E15" && Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "El tirador debe ajustar una referencia con el cursor fuera del token también desde el editor de celda.");
            InvocarEn(typeof(DataGridView), hoja, "ProcessEnterKey", Keys.Enter); Application.DoEvents();
            exige(new MYGHojaCalculo(partida.Costos.Hoja).Contenido("E15") == "=SUMA(C3:D4)" &&
                new MYGHojaCalculo(partida.Costos.Hoja).Numero("E15") == 2m &&
                contadores() == (sinCambios.Item1 + 1, sinCambios.Item2 + 1, sinCambios.Item3),
                "Confirmar después de redimensionar debe calcular el rango y registrar una sola modificación.");

            Seleccionar(hoja, "E14"); Escribir(formula, "=SUMA(B3)+10");
            formula.Select(6, 2); original = Estado(partida.Costos.Hoja); sinCambios = contadores();
            Arrastrar(panel, hoja, "B3", "D3", exige);
            exige(formula.Text == "=SUMA(B3:D3)+10" && formula.SelectionStart == 11 &&
                formula.SelectionLength == 0 && formula.Focused && DireccionActual(hoja) == "E14",
                "Elegir un rango sobre una referencia seleccionada debe conservar la función y el resto de la fórmula.");
            Tecla(formula, Keys.Escape); Application.DoEvents();
            exige(Estado(partida.Costos.Hoja) == original && contadores() == sinCambios &&
                panel.EstadoReferenciasHoja.Count == 0 && !hoja.Capture,
                "Escape en la barra debe descartar el rango elegido sin modificar modelo, estilos ni historial.");

            Seleccionar(hoja, "E14"); hoja.Focus(); hoja.BeginEdit(true); Application.DoEvents();
            editor = (RichTextBox)hoja.EditingControl; Escribir(editor, "=C3+");
            Point dentroEditor = new(Math.Min(12, editor.Width - 1), editor.Height / 2);
            exige(!FiltrarMouse(panel, editor, MouseDown, dentroEditor) &&
                !FiltrarMouse(panel, editor, MouseUp, dentroEditor),
                "El filtro debe dejar pasar los clics dentro del editor para colocar el cursor y seleccionar texto.");
            Point destinoEditor = editor.PointToClient(hoja.PointToScreen(Centro(hoja, "C9")));
            exige(FiltrarMouse(panel, hoja, MouseDown, Centro(hoja, "C7")) &&
                FiltrarMouse(panel, editor, MouseMove, destinoEditor) && FiltrarMouse(panel, editor, MouseUp, destinoEditor),
                "Durante una selección capturada, los mensajes del editor deben traducirse a coordenadas de la hoja.");
            Application.DoEvents();
            exige(editor.Text == "=C3+C7:C9" && DireccionActual(hoja) == "E14" && editor.Focused,
                "El editor de celda debe admitir también rangos elegidos después de un operador.");
            EscapeCelda(hoja); Application.DoEvents();
            exige(!hoja.IsCurrentCellInEditMode && Estado(partida.Costos.Hoja) == original && contadores() == sinCambios &&
                panel.EstadoReferenciasHoja.Count == 0 && !hoja.Capture,
                "Cancelar el editor debe liberar el ratón y quitar referencias sin guardar la fórmula incompleta.");

            Seleccionar(hoja, "E14"); hoja.Focus(); hoja.BeginEdit(true); Application.DoEvents();
            editor = (RichTextBox)hoja.EditingControl; Escribir(editor, "=");
            int filaVisible = hoja.FirstDisplayedScrollingRowIndex, columnaVisible = hoja.FirstDisplayedScrollingColumnIndex;
            Rectangle area = Invocar<Rectangle>(panel, "AreaCeldasHoja");
            exige(FiltrarMouse(panel, hoja, MouseDown, Centro(hoja, "C3")) &&
                FiltrarMouse(panel, hoja, MouseMove, new Point(area.Right - 2, area.Bottom - 2)),
                "Un arrastre hacia el borde debe mantener activa la selección de referencias del editor.");
            Invocar(panel, "DesplazarElegirReferenciasHoja", null, EventArgs.Empty);
            exige(hoja.FirstDisplayedScrollingRowIndex == filaVisible &&
                hoja.FirstDisplayedScrollingColumnIndex == columnaVisible && hoja.IsCurrentCellInEditMode &&
                DireccionActual(hoja) == "E14" && Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "El desplazamiento automático durante la edición de una celda debe evitar confirmar el borrador mediante DataGridView.");
            EscapeCelda(hoja); Application.DoEvents();
            exige(!hoja.IsCurrentCellInEditMode && !hoja.Capture &&
                Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "Escape después de arrastrar al borde debe conservar íntegra la hoja y cancelar el borrador.");

            Seleccionar(hoja, "E14"); Escribir(formula, "=SUMA(");
            Clic(panel, hoja, "C1", exige);
            exige(formula.Text == "=SUMA(A1" && DireccionActual(hoja) == "E14" && formula.Focused,
                "Elegir cualquier miembro de una celda combinada debe insertar la dirección de su ancla.");
            Escribir(formula, "=SUMA(");
            Arrastrar(panel, hoja, "C3", "E1", exige);
            exige(formula.Text == "=SUMA(C1:F3" && DireccionActual(hoja) == "E14" && formula.Focused && !hoja.Capture,
                "Un rango con extremo combinado debe incluir toda la combinación y mantener el destino de la fórmula.");
            Escribir(formula, "=SUMA($C3:F$5)");
            Redimensionar(panel, hoja, panel.EstadoReferenciasHoja[0], "H2", exige);
            exige(formula.Text == "=SUMA($C$2:H3)",
                "Al subir por encima del ancla, el tirador debe conservar los indicadores absolutos de cada eje.");
            Escribir(formula, "=SUMA(C3:F5)");
            Redimensionar(panel, hoja, panel.EstadoReferenciasHoja[0], "E1", exige);
            exige(formula.Text == "=SUMA(C1:F3)",
                "Redimensionar hacia una celda combinada debe incluir su combinación completa.");
            Tecla(formula, Keys.Escape); Application.DoEvents();
            exige(Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "Cancelar referencias a combinadas debe conservar los valores, combinaciones e historial de la hoja.");

            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos(); Application.DoEvents();
                Seleccionar(hoja, "E14");
                Escribir(formula, "=SUMA(C3:F5)");
                var rangoTema = panel.EstadoReferenciasHoja[0];
                Point centroTema = CentroTirador(panel, rangoTema, exige);
                using (var captura = new Bitmap(hoja.ClientSize.Width, hoja.ClientSize.Height))
                {
                    hoja.DrawToBitmap(captura, hoja.ClientRectangle);
                    exige(captura.GetPixel(centroTema.X, centroTema.Y).ToArgb() ==
                        Invocar<Color>(panel, "ColorReferenciaHoja", rangoTema.IndiceColor).ToArgb(),
                        "El punto de la esquina debe dibujarse con el color del rango en ambos temas.");
                }
                Redimensionar(panel, hoja, rangoTema, "D4", exige);
                exige(formula.Text == "=SUMA(C3:D4)", "El tirador debe funcionar en ambos temas.");
                Tecla(formula, Keys.Escape); Application.DoEvents();
                Escribir(formula, "=\"C3\"&$C$3+C7+C3");
                formula.Select(7, 3);
                VerificarColores(panel, hoja, formula, true, exige);
                exige(formula.SelectionStart == 7 && formula.SelectionLength == 3 &&
                    panel.EstadoReferenciasHoja.Count == 3 &&
                    panel.EstadoReferenciasHoja[0].IndiceColor == panel.EstadoReferenciasHoja[2].IndiceColor &&
                    panel.EstadoReferenciasHoja[0].IndiceColor != panel.EstadoReferenciasHoja[1].IndiceColor,
                    "La barra debe repetir el color de la misma celda y conservar la selección escrita en ambos temas.");
                exige(ColorTexto(formula, 2, 2).ToArgb() == formula.ForeColor.ToArgb() &&
                    ColorTexto(formula, 10, 1).ToArgb() == formula.ForeColor.ToArgb(),
                    "Las direcciones dentro de comillas y los operadores deben conservar el color normal del texto.");
                VerificarDeshacerTexto(panel, formula, exige);
                Tecla(formula, Keys.Escape); Application.DoEvents();

                Seleccionar(hoja, "E14"); hoja.Focus(); hoja.BeginEdit(true); Application.DoEvents();
                editor = (RichTextBox)hoja.EditingControl; Escribir(editor, "=C3+C7+C3");
                editor.Select(4, 2); VerificarColores(panel, hoja, editor, true, exige);
                exige(editor.SelectionStart == 4 && editor.SelectionLength == 2,
                    "Colorear las referencias del editor debe conservar el cursor y la selección del usuario.");
                VerificarDeshacerTexto(panel, editor, exige);
                EscapeCelda(hoja); Application.DoEvents();
            }
            exige(Estado(partida.Costos.Hoja) == original && contadores() == sinCambios,
                "Colores, tema y deshacer texto pendiente no deben escribir fórmulas ni generar historial del proyecto.");
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarDeshacerTexto(MYGPanelPresupuesto panel, RichTextBox editor, Action<bool, string> exige)
    {
        string texto = editor.Text;
        editor.Select(editor.TextLength, 0); editor.ClearUndo();
        EnviarMensaje(editor.Handle, 0x0102, new IntPtr('+'), IntPtr.Zero); Application.DoEvents();
        exige(editor.Text == texto + "+" && editor.CanUndo,
            "Escribir después de una referencia coloreada debe conservar el deshacer nativo del editor.");
        editor.Select(4, 2);
        Invocar(panel, "ActualizarReferenciasHoja", editor.Text);
        exige(editor.Text == texto + "+" && editor.SelectionStart == 4 && editor.SelectionLength == 2 && editor.CanUndo,
            "Actualizar colores debe conservar texto, selección y la edición pendiente que puede deshacerse.");
        editor.Undo(); Application.DoEvents();
        exige(editor.Text == texto,
            "Deshacer dentro del editor debe quitar el carácter escrito sin deshacer un cambio de color.");
    }

    private static void VerificarColores(MYGPanelPresupuesto panel, DataGridView hoja, RichTextBox editor,
        bool verificarBordes, Action<bool, string> exige)
    {
        foreach (var referencia in panel.EstadoReferenciasHoja)
        {
            Color esperado = Invocar<Color>(panel, "ColorReferenciaHoja", referencia.IndiceColor);
            exige(ColorTexto(editor, referencia.Inicio, referencia.Longitud).ToArgb() == esperado.ToArgb(),
                $"El token {referencia.Rango} debe tener el mismo color que su marco en la hoja.");
            if (verificarBordes) VerificarBorde(hoja, referencia, esperado, exige);
        }
    }

    private static Color ColorTexto(RichTextBox editor, int inicio, int longitud)
    {
        int seleccion = editor.SelectionStart, cantidad = editor.SelectionLength;
        try { editor.Select(inicio, longitud); return editor.SelectionColor; }
        finally { editor.Select(seleccion, cantidad); }
    }

    private static void VerificarBorde(DataGridView hoja, MYGReferenciaFormulaHoja referencia, Color color,
        Action<bool, string> exige)
    {
        Rectangle celda = hoja.GetCellDisplayRectangle(referencia.ColumnaInicial - 1, referencia.FilaInicial - 1, false);
        using var captura = new Bitmap(hoja.ClientSize.Width, hoja.ClientSize.Height);
        hoja.DrawToBitmap(captura, hoja.ClientRectangle);
        var borde = Rectangle.Intersect(hoja.ClientRectangle, new Rectangle(celda.Left, celda.Top, celda.Width, 4));
        bool encontrado = false;
        for (int y = borde.Top; y < borde.Bottom && !encontrado; y++)
            for (int x = borde.Left; x < borde.Right && !encontrado; x++)
            {
                Color pixel = captura.GetPixel(x, y);
                encontrado = Math.Abs(pixel.R - color.R) <= 3 && Math.Abs(pixel.G - color.G) <= 3 && Math.Abs(pixel.B - color.B) <= 3;
            }
        exige(encontrado, $"El marco de {referencia.Rango} debe dibujarse con el mismo color que el token de fórmula.");
    }

    private static void Clic(MYGPanelPresupuesto panel, DataGridView hoja, string direccion, Action<bool, string> exige)
    {
        Point punto = Centro(hoja, direccion);
        exige(FiltrarMouse(panel, hoja, MouseDown, punto) && FiltrarMouse(panel, hoja, MouseUp, punto),
            "El filtro de referencias debe consumir el clic antes de que cambie la celda activa.");
        Application.DoEvents();
    }

    private static Point CentroTirador(MYGPanelPresupuesto panel, MYGReferenciaFormulaHoja referencia, Action<bool, string> exige)
    {
        var visual = Invocar<MYGReferenciaFormulaHoja>(panel, "ExpandirReferenciaVisualHoja", referencia);
        Rectangle tirador = Invocar<Rectangle>(panel, "TiradorReferenciaHoja", visual);
        exige(!tirador.IsEmpty, "Una referencia visible debe tener un tirador en su esquina inferior derecha.");
        return new Point(tirador.Left + tirador.Width / 2, tirador.Top + tirador.Height / 2);
    }

    private static void Redimensionar(MYGPanelPresupuesto panel, DataGridView hoja, MYGReferenciaFormulaHoja referencia,
        string fin, Action<bool, string> exige)
    {
        Point inicio = CentroTirador(panel, referencia, exige), destino = Centro(hoja, fin);
        exige(FiltrarMouse(panel, hoja, MouseDown, inicio) && FiltrarMouse(panel, hoja, MouseMove, destino) &&
            FiltrarMouse(panel, hoja, MouseUp, destino), "El tirador debe consumir el arrastre sin confirmar la celda.");
        Application.DoEvents();
    }

    private static void Arrastrar(MYGPanelPresupuesto panel, DataGridView hoja, string inicio, string fin,
        Action<bool, string> exige)
    {
        Point primero = Centro(hoja, inicio), ultimo = Centro(hoja, fin);
        exige(FiltrarMouse(panel, hoja, MouseDown, primero) && FiltrarMouse(panel, hoja, MouseMove, ultimo) &&
            FiltrarMouse(panel, hoja, MouseUp, ultimo),
            "El filtro de referencias debe consumir el arrastre completo mientras se edita una fórmula.");
        Application.DoEvents();
    }

    private static bool FiltrarMouse(MYGPanelPresupuesto panel, Control destino, int mensaje, Point punto)
    {
        var filtro = Campo<IMessageFilter>(panel, "filtroElegirReferenciasHoja");
        var posicion = new IntPtr((punto.X & 0xffff) | ((punto.Y & 0xffff) << 16));
        var msg = Message.Create(destino.Handle, mensaje, new IntPtr(mensaje == MouseUp ? 0 : 1), posicion);
        return filtro.PreFilterMessage(ref msg);
    }

    private static Point Centro(DataGridView hoja, string direccion)
    {
        var c = MYGHojaCalculo.Coordenadas(direccion);
        Rectangle r = hoja.GetCellDisplayRectangle(c.Columna - 1, c.Fila - 1, false);
        return new Point(r.Left + r.Width / 2, r.Top + r.Height / 2);
    }

    private static void Escribir(TextBoxBase editor, string texto)
    { editor.Focus(); editor.Text = texto; editor.Select(texto.Length, 0); Application.DoEvents(); }
    private static void Seleccionar(DataGridView hoja, string direccion)
    {
        var c = MYGHojaCalculo.Coordenadas(direccion);
        hoja.ClearSelection(); hoja.CurrentCell = hoja[c.Columna - 1, c.Fila - 1]; hoja.CurrentCell.Selected = true;
        Application.DoEvents();
    }
    private static string Estado(MYGHojaMetrado modelo) => JsonSerializer.Serialize(modelo);
    private static string DireccionActual(DataGridView hoja) => MYGHojaCalculo.Columna(hoja.CurrentCell.ColumnIndex + 1) + (hoja.CurrentCell.RowIndex + 1);
    private static void EscapeCelda(DataGridView hoja) => InvocarEn(typeof(DataGridView), hoja, "ProcessEscapeKey", Keys.Escape);
    private static void Tecla(Control control, Keys tecla) => InvocarEn(typeof(Control), control, "OnKeyDown", new KeyEventArgs(tecla));
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static void Invocar(object objeto, string nombre, params object[] argumentos) => InvocarEn(objeto.GetType(), objeto, nombre, argumentos);
    private static T Invocar<T>(object objeto, string nombre, params object[] argumentos) => (T)InvocarEn(objeto.GetType(), objeto, nombre, argumentos);
    private static object InvocarEn(Type tipo, object objeto, string nombre, params object[] argumentos)
    {
        try { return tipo.GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
