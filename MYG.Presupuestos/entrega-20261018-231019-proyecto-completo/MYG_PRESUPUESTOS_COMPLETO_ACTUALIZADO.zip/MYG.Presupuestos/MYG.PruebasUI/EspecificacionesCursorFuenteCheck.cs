using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesCursorFuenteCheck
{
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessagePunto(IntPtr ventana, int mensaje, IntPtr wParam, ref Point punto);

    private sealed class DocumentoRecreable : RichTextBox
    {
        internal void RecrearVentana() => RecreateHandle();
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarProveedoresOrtografia(exige);
        int antes = 0, cambios = 0;
        using var documento = new DocumentoRecreable
        {
            Font = new Font("Arial", 11.5f), DetectUrls = false, HideSelection = false
        };
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "CONCRETO SIMPLE", () => "m³", () => "01.02");
        using var formulario = new Form { ClientSize = new Size(946, 780) };
        formulario.Controls.Add(editor);
        formulario.Show();
        Application.DoEvents();

        string fuentePredeterminada;
        using (var instaladas = new System.Drawing.Text.InstalledFontCollection())
            fuentePredeterminada = instaladas.Families.Any(f => f.Name.Equals("Arial Narrow", StringComparison.OrdinalIgnoreCase))
                ? "Arial Narrow" : "Arial";

        VerificarFuente(editor, documento, fuentePredeterminada, exige);
        VerificarRtfExistente(editor, documento, fuentePredeterminada, exige);
        VerificarContexto(editor, documento, () => (antes, cambios), exige);

        documento.RecrearVentana();
        Application.DoEvents();
        VerificarContexto(editor, documento, () => (antes, cambios), exige);
        VerificarMenuExistente(exige);
        formulario.Close();
    }

    private static void VerificarProveedoresOrtografia(Action<bool, string> exige)
    {
        int revisiones = 0;
        string textoRevisado = null, palabraSugerida = null, palabraAgregada = null;
        using var documento = new RichTextBox();
        using var editor = new MYGEspecificacionesEditor(documento, () => { }, () => { },
            () => "PARTIDA", () => "und", () => "01",
            comprobarOrtografia: texto =>
            {
                revisiones++; textoRevisado = texto;
                int inicio = texto.IndexOf("hormigonx", StringComparison.Ordinal);
                return inicio < 0 ? Array.Empty<MYGErrorOrtografico>()
                    : new[] { new MYGErrorOrtografico(inicio, 9, "hormigonx") };
            },
            sugerirOrtografia: palabra => { palabraSugerida = palabra; return new[] { "hormigón" }; },
            agregarOrtografia: palabra => palabraAgregada = palabra);
        editor.Cargar("proveedores-ortografia", "", "Correcto hormigonx");
        var corrector = (MYGEspecificacionesOrtografia)typeof(MYGEspecificacionesEditor)
            .GetField("ortografia", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        exige(corrector != null && corrector.Disponible,
            "El constructor debe inicializar el corrector con los proveedores ortográficos opcionales.");
        corrector.ComprobarAhora();
        exige(revisiones > 0 && textoRevisado == documento.Text && corrector.RevisionCompleta &&
            corrector.Errores.Count == 1 && corrector.Errores[0].Palabra == "hormigonx",
            "Comprobar ortografía debe ejecutar el proveedor recibido y conservar sus errores para el menú.");
        var error = corrector.Errores.Single();
        exige(corrector.Sugerencias(error).SequenceEqual(new[] { "hormigón" }) && palabraSugerida == "hormigonx",
            "Las sugerencias deben proceder del proveedor recibido por el constructor.");
        string rtf = editor.DocumentoRtf;
        corrector.AgregarAlDiccionario(error);
        exige(palabraAgregada == "hormigonx" && corrector.Errores.Count == 0 && editor.DocumentoRtf == rtf,
            "Agregar al diccionario debe ejecutar el proveedor recibido sin modificar el documento.");
    }

    private static void VerificarFuente(MYGEspecificacionesEditor editor, RichTextBox documento,
        string nombreFuente, Action<bool, string> exige)
    {
        editor.Cargar("fuente-vacia", "", "");
        exige(documento.Font.Name == nombreFuente && Math.Abs(documento.Font.SizeInPoints - 11) < .01,
            "La fuente base del documento debe ser Arial Narrow de 11 puntos, con Arial como alternativa si no está instalada.");
        ComprobarFuente(documento, nombreFuente, exige, "Una hoja vacía debe comenzar con la fuente de 11 puntos y sin estilos heredados.");

        editor.AplicarFormato(() => documento.SelectionFont = new Font("Courier New", 16, FontStyle.Bold));
        editor.Cargar("fuente-texto", "", "Primera línea\n\nTercera línea\n");
        documento.SelectAll();
        ComprobarFuente(documento, nombreFuente, exige,
            "Cargar texto sin RTF debe aplicar la fuente predeterminada a todas las líneas, sin heredar la partida anterior.");
        documento.Select(documento.TextLength, 0);
        ComprobarFuente(documento, nombreFuente, exige,
            "El párrafo vacío al final del texto debe conservar la fuente predeterminada de 11 puntos.");

        editor.Cargar("fuente-titulo", "", "");
        Descendientes(editor).OfType<Button>().Single(x => x.Name == "espec_insertar_titulo").PerformClick();
        documento.Select(documento.TextLength, 0);
        ComprobarFuente(documento, nombreFuente, exige,
            "Después de Insertar título, el cursor debe quedar preparado para escribir texto normal de 11 puntos.");
        int inicio = documento.TextLength;
        documento.SelectedText = "Texto debajo del título\nNueva línea\n";
        documento.Select(inicio, documento.TextLength - inicio);
        ComprobarFuente(documento, nombreFuente, exige,
            "Las líneas escritas debajo del título deben mantener Arial Narrow 11 en todo su contenido.");
        documento.Select(documento.TextLength, 0);
        var fuente = Herramientas(editor).OfType<ToolStripComboBox>().Single(x => x.Name == "espec_fuente");
        var tamano = Herramientas(editor).OfType<ToolStripComboBox>().Single(x => x.Name == "espec_tamano");
        exige(fuente.Text == nombreFuente && tamano.Text == "11",
            "La cinta debe mostrar la fuente predeterminada y tamaño 11 al situar el cursor debajo del título.");

        editor.Cargar("fuente-plantilla", "", "");
        Herramientas(editor).Single(x => x.Name == "espec_plantilla").PerformClick();
        documento.Select(documento.TextLength, 0);
        ComprobarFuente(documento, nombreFuente, exige,
            "El final de una plantilla debe permitir escribir con la fuente normal de 11 puntos.");
    }

    private static void ComprobarFuente(RichTextBox documento, string nombre, Action<bool, string> exige, string mensaje)
    {
        using var fuente = documento.SelectionFont;
        exige(fuente != null && fuente.Name == nombre && Math.Abs(fuente.SizeInPoints - 11) < .01 &&
            fuente.Style == FontStyle.Regular, mensaje);
    }

    private static void VerificarRtfExistente(MYGEspecificacionesEditor editor, RichTextBox documento,
        string fuentePredeterminada, Action<bool, string> exige)
    {
        const string rtf = @"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}{\f1 Courier New;}}\f0\fs26\b Encabezado\b0\par\f1\fs20\i Cuerpo existente\i0}";
        editor.Cargar("fuente-rtf", rtf, "Encabezado\nCuerpo existente");
        documento.Select(0, "Encabezado".Length);
        using var encabezado = documento.SelectionFont;
        exige(encabezado != null && encabezado.Name == "Arial" && encabezado.Bold && Math.Abs(encabezado.SizeInPoints - 13) < .01,
            "Configurar la fuente predeterminada no debe reemplazar el formato explícito del encabezado de un RTF existente.");
        documento.Select(documento.Text.IndexOf("Cuerpo", StringComparison.Ordinal), "Cuerpo existente".Length);
        using var cuerpo = documento.SelectionFont;
        exige(cuerpo != null && cuerpo.Name == "Courier New" && cuerpo.Italic && Math.Abs(cuerpo.SizeInPoints - 10) < .01,
            "El RTF existente debe conservar las fuentes, tamaños y estilos elegidos para su cuerpo.");
        documento.Select(documento.TextLength, 0);
        using var insercionCuerpo = documento.SelectionFont;
        exige(insercionCuerpo != null && insercionCuerpo.Name == "Courier New" && insercionCuerpo.Italic &&
            Math.Abs(insercionCuerpo.SizeInPoints - 10) < .01,
            "Un párrafo de contenido con formato explícito debe mantener ese formato al continuar escribiendo en su final.");

        string rtfAntiguo = @"{\rtf1\ansi\deff0{\fonttbl{\f0 " + fuentePredeterminada +
            @";}{\f1 Arial;}}\f0\fs22\b Encabezado anterior\b0\par\f1\fs23\par}";
        editor.Cargar("fuente-rtf-vacio-antiguo", rtfAntiguo, "Encabezado anterior\n\n");
        documento.Select(documento.TextLength, 0);
        ComprobarFuente(documento, fuentePredeterminada, exige,
            "Un RTF anterior con el último párrafo vacío en Arial 11.5 debe quedar preparado para escribir con la fuente normal de 11 puntos.");
        documento.Select(0, "Encabezado anterior".Length);
        using var encabezadoAnterior = documento.SelectionFont;
        exige(encabezadoAnterior != null && encabezadoAnterior.Name == fuentePredeterminada && encabezadoAnterior.Bold &&
            Math.Abs(encabezadoAnterior.SizeInPoints - 11) < .01,
            "Corregir el último párrafo vacío de un RTF anterior debe conservar el formato de su contenido.");
    }

    private static void VerificarContexto(MYGEspecificacionesEditor editor, RichTextBox documento,
        Func<(int Antes, int Cambios)> contadores, Action<bool, string> exige)
    {
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                editor.Cargar("cursor-contexto-" + oscuro, "", "Primera línea\nSegunda línea\nTercera línea");
                documento.Focus();
                editor.AplicarFormato(() => documento.SelectedText = "Nota: ");
                Application.DoEvents();
                var menu = documento.ContextMenuStrip;
                exige(menu != null && menu.Name == "espec_menu_documento",
                    "El documento debe ofrecer un menú contextual de edición sin depender del menú nativo que mueve el cursor.");

                foreach (int longitud in new[] { 0, 6 })
                {
                    documento.Select(documento.Text.IndexOf("Segunda", StringComparison.Ordinal) + 2, longitud);
                    int posicion = documento.SelectionStart;
                    var inicial = contadores();
                    string rtf = editor.DocumentoRtf;
                    bool undo = documento.CanUndo;
                    Point scroll = ObtenerScroll(documento);
                    var lienzo = Descendientes(editor).OfType<Panel>().Single(x => x.Name == "espec_lienzo");
                    Point scrollLienzo = lienzo.AutoScrollPosition;
                    Point punto = documento.GetPositionFromCharIndex(0);
                    ClicDerecho(documento, punto);
                    exige(menu.Visible && documento.SelectionStart == posicion && documento.SelectionLength == longitud,
                        "El clic derecho completo debe abrir el menú automáticamente en otra línea y conservar el cursor y la selección originales.");
                    menu.Close(ToolStripDropDownCloseReason.Keyboard);
                    Application.DoEvents();
                    exige(documento.SelectionStart == posicion && documento.SelectionLength == longitud &&
                        editor.DocumentoRtf == rtf && documento.CanUndo == undo && contadores() == inicial &&
                        ObtenerScroll(documento) == scroll && lienzo.AutoScrollPosition == scrollLienzo,
                        "Cancelar el menú contextual no debe mover el cursor ni modificar el contenido, el historial o el desplazamiento.");

                    SendMessage(documento.Handle, 0x0206, new IntPtr(2), Coordenadas(punto)); // WM_RBUTTONDBLCLK.
                    exige(documento.SelectionStart == posicion && documento.SelectionLength == longitud,
                        "El doble clic derecho tampoco debe trasladar el cursor ni reemplazar la selección.");
                    SendMessage(documento.Handle, 0x007B, documento.Handle, new IntPtr(-1)); // WM_CONTEXTMENU por teclado.
                    Application.DoEvents();
                    exige(menu.Visible && documento.SelectionStart == posicion && documento.SelectionLength == longitud,
                        "El menú contextual invocado por teclado debe usar la selección actual.");
                    menu.Close(ToolStripDropDownCloseReason.Keyboard);
                }

                foreach (int longitud in new[] { 0, 7 })
                {
                    const string pegado = "PEGADO";
                    documento.Focus();
                    int posicion = documento.Text.IndexOf("Segunda", StringComparison.Ordinal);
                    documento.Select(posicion, longitud);
                    string esperado = documento.Text.Remove(posicion, longitud).Insert(posicion, pegado);
                    var inicial = contadores();
                    Clipboard.SetText(pegado);
                    ClicDerecho(documento, documento.GetPositionFromCharIndex(0));
                    MostrarContexto(documento, documento.GetPositionFromCharIndex(0));
                    var pegar = menu.Items.OfType<ToolStripMenuItem>().Single(x => x.Name == "espec_contexto_pegar");
                    exige(pegar.Enabled, "Pegar debe estar disponible cuando el portapapeles contiene texto y la partida permite editar.");
                    pegar.PerformClick();
                    menu.Close();
                    Application.DoEvents();
                    exige(documento.Text == esperado && contadores() == (inicial.Antes + 1, inicial.Cambios + 1),
                        "Pegar desde el menú debe insertar o reemplazar en la posición original y guardar una sola modificación.");
                    // Volver al mismo texto permite comprobar las dos longitudes por separado.
                    editor.Cargar("cursor-pegar-" + oscuro + "-" + longitud, "", "Primera línea\nSegunda línea\nTercera línea");
                }
            }
        }
        finally
        {
            documento.ContextMenuStrip?.Close();
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarMenuExistente(Action<bool, string> exige)
    {
        using var menu = new ContextMenuStrip();
        menu.Items.Add("Opciones existentes");
        using var documento = new RichTextBox { ContextMenuStrip = menu };
        using var editor = new MYGEspecificacionesEditor(documento, () => { }, () => { },
            () => "PARTIDA", () => "und", () => "01");
        exige(ReferenceEquals(documento.ContextMenuStrip, menu),
            "Preparar el editor debe conservar un menú contextual que ya haya sido asignado por el propietario.");
    }

    private static void ClicDerecho(RichTextBox documento, Point punto)
    {
        SendMessage(documento.Handle, 0x0204, new IntPtr(2), Coordenadas(punto)); // WM_RBUTTONDOWN.
        SendMessage(documento.Handle, 0x0205, IntPtr.Zero, Coordenadas(punto)); // WM_RBUTTONUP.
        Application.DoEvents();
    }

    private static void MostrarContexto(RichTextBox documento, Point punto)
    {
        SendMessage(documento.Handle, 0x007B, documento.Handle, Coordenadas(documento.PointToScreen(punto)));
        Application.DoEvents();
    }

    private static IntPtr Coordenadas(Point punto) => new(unchecked((punto.Y << 16) | (punto.X & 0xffff)));

    private static Point ObtenerScroll(RichTextBox documento)
    {
        var punto = new Point();
        SendMessagePunto(documento.Handle, 0x04DD, IntPtr.Zero, ref punto); // EM_GETSCROLLPOS.
        return punto;
    }

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }

    private static IEnumerable<ToolStripItem> Herramientas(Control padre) => Descendientes(padre)
        .OfType<ToolStrip>().SelectMany(x => Herramientas(x.Items));

    private static IEnumerable<ToolStripItem> Herramientas(ToolStripItemCollection items)
    {
        foreach (ToolStripItem item in items)
        {
            yield return item;
            if (item is ToolStripDropDownItem menu)
                foreach (ToolStripItem hijo in Herramientas(menu.DropDownItems)) yield return hijo;
        }
    }
}
