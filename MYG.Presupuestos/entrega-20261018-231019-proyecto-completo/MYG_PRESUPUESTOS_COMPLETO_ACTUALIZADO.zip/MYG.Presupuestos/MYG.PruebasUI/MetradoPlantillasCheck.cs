using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoPlantillasCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Plantillas", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        ItemPresupuestoDelphin Partida(string nombre) => new()
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = nombre,
            Unidad = "kg", TipoPropuesta = "PARTIDA", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 12m, FuenteMetrado = MYGFuenteMetrado.Cantidad }
        };
        var primera = Partida("ACERO"); var segunda = Partida("OTRA PARTIDA");
        primera.Costos.Hoja.Poner("A3", "Dato original");
        primera.Costos.Hoja.Celdas["A3"].ColorFondo = "C6EFCE";
        segunda.Costos.Hoja.Poner("A3", "Hoja vecina intacta");
        presupuesto.Items.AddRange([primera, segunda]);
        int anteriores = 0, cambios = 0, guardados = 0, avisos = 0;
        var historial = new Stack<MYGDatosPartida>();
        MYGPanelPresupuesto panel = null;
        using var control = panel = new MYGPanelPresupuesto(() => presupuesto,
            () => { anteriores++; historial.Push(MYGProyectoStorage.Copia(primera.Costos)); },
            () => cambios++, _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++,
            () => { primera.Costos = historial.Pop(); panel.Refrescar(); panel.SeleccionarEstructura(primera); });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1800, 1000) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(primera);
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        ((TabControl)pagina.Parent).SelectedTab = pagina;
        Application.DoEvents();
        var hoja = Campo<DataGridView>(panel, "hoja");
        var cabecera = Campo<MYGMetradoCabecera>(panel, "cabeceraExcel");
        var menu = Campo<ContextMenuStrip>(cabecera, "menu");
        cabecera.ActualizarPlantillas();
        exige(menu.Items.Count == 2 && menu.Items.Cast<ToolStripMenuItem>().All(m => m.Enabled) &&
            ((ToolStripMenuItem)menu.Items[0]).Checked && !((ToolStripMenuItem)menu.Items[1]).Checked &&
            menu.Items[0].Text == "PLANTILLA ESTÁNDAR" && menu.Items[1].Text == "PLANTILLA DE FIERROS Y ACEROS",
            "El botón XLS debe mostrar sólo las dos plantillas integradas y marcar la plantilla actual.");
        exige(cabecera.Controls.Find("metrado_plantilla_xls", true).Single().AccessibleName == "Seleccionar plantilla de metrado",
            "El botón de la cabecera debe identificar selección de plantilla, sin acciones de exportación.");
        string original = Estado(primera.Costos), vecina = Estado(segunda.Costos);
        panel.ConfirmarCambioPlantillaMetrado = _ => { avisos++; return false; };
        menu.Items[1].PerformClick(); Application.DoEvents();
        exige(Estado(primera.Costos) == original && Estado(segunda.Costos) == vecina &&
            anteriores == 0 && cambios == 0 && guardados == 0 && avisos == 1,
            "Cancelar la advertencia debe conservar hojas, formatos, costos y el historial.");
        menu.Items[0].PerformClick();
        exige(avisos == 1 && Estado(primera.Costos) == original && anteriores == 0,
            "Elegir la plantilla ya marcada debe conservar la hoja editada sin reiniciarla ni mostrar advertencias.");

        panel.ConfirmarCambioPlantillaMetrado = _ => { avisos++; return true; };
        menu.Items[1].PerformClick(); Application.DoEvents();
        exige(primera.Costos.Hoja.IdPlantilla == MYGPlantillasMetrado.Aceros && hoja.ColumnCount == 34 &&
            primera.Costos.Hoja.CeldaTotal == "AD16" && new MYGHojaCalculo(primera.Costos.Hoja).Numero("AD16") == 0 &&
            Estado(segunda.Costos) == vecina && primera.Costos.Cantidad == 12m &&
            primera.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
            anteriores == 1 && cambios == 1 && guardados == 0 &&
            ((ToolStripMenuItem)menu.Items[1]).Checked && !((ToolStripMenuItem)menu.Items[0]).Checked,
            "Aceptar debe aplicar aceros sólo a la partida actual, conservar los otros datos y registrar un único cambio.");
        typeof(MYGPanelPresupuesto).GetField("filtroTextoHoja", Privados).SetValue(panel, "sin coincidencias");
        Invocar(panel, "FiltrarHoja");
        exige(!hoja.Rows[2].Visible && hoja.Rows[13].Visible && hoja.Rows[14].Visible && hoja.Rows[15].Visible,
            "El filtro de aceros debe conservar las tres filas de resumen y ocultar sólo los detalles que no coincidan.");
        typeof(MYGPanelPresupuesto).GetField("filtroTextoHoja", Privados).SetValue(panel, "");
        Invocar(panel, "FiltrarHoja");
        var acero = primera.Costos.Hoja;
        MYGEdicionHoja.Celda(acero, "B3").Contenido = "2";
        MYGEdicionHoja.Celda(acero, "C3").Contenido = "3";
        MYGEdicionHoja.Celda(acero, "D3").Contenido = "3/8";
        MYGEdicionHoja.Celda(acero, "E3").Contenido = "4";
        Invocar(panel, "CargarHoja");
        hoja.CurrentCell = hoja[29, 15]; // La selección de AD no existe en la plantilla estándar.
        string aceroEditado = Estado(primera.Costos);
        menu.Items[0].PerformClick(); Application.DoEvents();
        exige(primera.Costos.Hoja.IdPlantilla == MYGPlantillasMetrado.Estandar && hoja.ColumnCount == 12 &&
            hoja.CurrentCell.ColumnIndex < 12 && anteriores == 2 && cambios == 2 && Estado(segunda.Costos) == vecina,
            "Volver a estándar debe reconstruir la selección sin índices de la plantilla ancha ni afectar la otra partida.");
        Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
        exige(Estado(primera.Costos) == aceroEditado && Estado(segunda.Costos) == vecina &&
            primera.Costos.Hoja.IdPlantilla == MYGPlantillasMetrado.Aceros && hoja.ColumnCount == 34,
            "Deshacer debe recuperar íntegros los datos, las fórmulas y los formatos de la plantilla anterior.");
        var reemplazo = MYGProyectoStorage.Copia(primera);
        int avisosPrevios = avisos;
        panel.ConfirmarCambioPlantillaMetrado = _ =>
        {
            avisos++;
            presupuesto.Items[presupuesto.Items.IndexOf(primera)] = reemplazo;
            return true;
        };
        panel.ElegirPlantillaMetrado(MYGPlantillasMetrado.Estandar);
        exige(avisos == avisosPrevios + 1 && Estado(primera.Costos) == aceroEditado &&
            Estado(reemplazo.Costos) == aceroEditado && anteriores == 2 && cambios == 2,
            "Una partida sustituida durante la advertencia no debe recibir cambios mediante una referencia obsoleta.");
        presupuesto.Items[presupuesto.Items.IndexOf(reemplazo)] = primera;

        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                using var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla de fierros y aceros");
                var aceptar = aviso.Controls.Find("plantilla_confirmacion_aceptar", true).Single();
                var cancelar = aviso.Controls.Find("plantilla_confirmacion_cancelar", true).Single();
                exige(!aceptar.Enabled && aviso.AcceptButton == cancelar && aviso.CancelButton == cancelar,
                    "La advertencia debe permitir leer antes de aceptar y usar Cancelar por defecto en ambos temas.");
                aviso.ActualizarEspera(3);
                exige(aceptar.Enabled && cancelar.Text == "Cancelar (7)",
                    "Aceptar debe habilitarse tras tres segundos y el contador debe indicar la cancelación pendiente.");
                aviso.ActualizarEspera(10);
                exige(aviso.DialogResult == DialogResult.Cancel,
                    "El vencimiento de la advertencia debe cancelar siempre, sin aceptar el cambio.");
            }
        }
        finally { if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false); }
        foreach (Keys tecla in new[] { Keys.Enter, Keys.Escape })
        {
            using var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla estándar");
            aviso.ActualizarEspera(3);
            Invocar(aviso, "ProcessDialogKey", tecla);
            exige(aviso.DialogResult == DialogResult.Cancel,
                "Enter y Escape deben cancelar aunque el botón Aceptar ya esté habilitado.");
        }
        using (var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla estándar"))
        {
            aviso.Show(formulario); Application.DoEvents();
            aviso.ActualizarEspera(3);
            ((Button)aviso.Controls.Find("plantilla_confirmacion_aceptar", true).Single()).PerformClick();
            exige(aviso.DialogResult == DialogResult.OK, "La advertencia debe aceptar sólo mediante el botón habilitado.");
        }
        using (var aviso = new MYGConfirmarPlantillaMetradoForm("Plantilla estándar"))
        {
            aviso.Show(formulario); Application.DoEvents(); aviso.Close();
            exige(aviso.DialogResult == DialogResult.Cancel, "Cerrar la advertencia con la X debe cancelar el cambio.");
        }
        using (var cabeceraVacia = new MYGMetradoCabecera(() => "", () => "", () => "", () => "", _ => { }, () => false))
        {
            var opciones = Campo<ContextMenuStrip>(cabeceraVacia, "menu");
            exige(opciones.Items.Count == 2 && opciones.Items.Cast<ToolStripMenuItem>().All(m => !m.Enabled),
                "Una base sin partidas debe mostrar ambas plantillas sin permitir un cambio hasta seleccionar una partida.");
        }
        formulario.Close();
        VerificarActualizacionMetrado(exige);
    }

    private static void VerificarActualizacionMetrado(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Actualizar metrados", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            var primera = new ItemPresupuestoDelphin
            {
                Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "CONCRETO",
                Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
                Costos = new MYGDatosPartida { Cantidad = 12m, PrecioDirecto = 10m }
            };
            var segunda = new ItemPresupuestoDelphin
            {
                Id = MYGProyectoStorage.NuevoId(), Item = "02", Descripcion = "PARTIDA VECINA",
                Unidad = "kg", TipoPropuesta = "PARTIDA", Posicion = 2,
                Costos = new MYGDatosPartida { Cantidad = 8m, PrecioDirecto = 4m }
            };
            primera.Costos.Hoja.Poner("A3", "Hoja conservada");
            primera.Costos.Hoja.Celdas["A3"].ColorFondo = "C6EFCE";
            primera.Costos.Metrados.Add(new MYGLineaMetrado { Descripcion = "Metrado manual", Elementos = 2m, CantidadPorElemento = 3m });
            primera.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = "activo-conservado", Unidad = "m³", Cantidad = 9m });
            presupuesto.Items.AddRange([primera, segunda]);
            int anteriores = 0, cambios = 0, guardados = 0;
            var historial = new Stack<MYGDatosPartida>();
            MYGPanelPresupuesto panel = null;
            using var control = panel = new MYGPanelPresupuesto(() => presupuesto,
                () => { anteriores++; historial.Push(MYGProyectoStorage.Copia(primera.Costos)); },
                () => cambios++, _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++,
                () => { primera.Costos = historial.Pop(); panel.Refrescar(); panel.SeleccionarEstructura(primera); });
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1800, 1000) };
            formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(primera);
            var pagina = Campo<TabPage>(panel, "paginaExcel");
            ((TabControl)pagina.Parent).SelectedTab = pagina;
            Application.DoEvents();
            var hoja = Campo<DataGridView>(panel, "hoja");
            var cabecera = Campo<MYGMetradoCabecera>(panel, "cabeceraExcel");
            var actualizar = (Button)cabecera.Controls.Find("metrado_actualizar", true).Single();
            var advertencia = (Label)cabecera.Controls.Find("metrado_advertencia", true).Single();
            var xls = (Button)cabecera.Controls.Find("metrado_plantilla_xls", true).Single();
            var menu = Campo<ContextMenuStrip>(cabecera, "menu");
            string vecina = Estado(segunda.Costos);
            exige(!actualizar.Visible && !advertencia.Visible && primera.Costos.Cantidad == 12m,
                "Una hoja nueva con total cero debe ocultar Actualizar y la advertencia sin borrar la cantidad del presupuesto.");

            foreach (string contenido in new[] { "=1/0", "=G16", "texto sin número", "-1", "0" })
            {
                primera.Costos.Hoja.Poner("G16", contenido);
                Invocar(panel, "RecalcularHoja"); Application.DoEvents();
                exige(!actualizar.Visible && !advertencia.Visible && primera.Costos.Cantidad == 12m &&
                    anteriores == 0 && cambios == 0 && guardados == 0,
                    "Cero, fórmulas inválidas, texto o total negativo deben ocultar la actualización y el desajuste sin crear cambios.");
            }
            primera.Costos.Hoja.Poner("B3", "0.2");
            primera.Costos.Hoja.Poner("C3", "3");
            primera.Costos.Hoja.Poner("G16", "=B3*C3");
            Invocar(panel, "RecalcularHoja"); Application.DoEvents();
            exige(actualizar.Visible && actualizar.Enabled && advertencia.Visible &&
                advertencia.Text == "⚠ El metrado (" + 0.6m.ToString("0.########", CultureInfo.CurrentCulture) +
                    ") no coincide con el ingresado en el presupuesto (12)" &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("G16") == 0.6m && primera.Costos.Cantidad == 12m,
                "Una fórmula con total 0.6 debe mostrar Actualizar y explicar el desajuste con los doce del presupuesto.");
            var costosOriginales = primera.Costos;
            var hojaOriginal = primera.Costos.Hoja;
            var esperado = MYGProyectoStorage.Copia(primera.Costos);
            esperado.Cantidad = 0.6m; esperado.FuenteMetrado = MYGFuenteMetrado.Excel;
            string hojaAplicada = Estado(hojaOriginal);
            actualizar.PerformClick(); Application.DoEvents();
            exige(Estado(primera.Costos) == Estado(esperado) && ReferenceEquals(primera.Costos, costosOriginales) &&
                ReferenceEquals(primera.Costos.Hoja, hojaOriginal) && Estado(segunda.Costos) == vecina &&
                anteriores == 1 && cambios == 1 && guardados == 0 &&
                actualizar.Visible && actualizar.Enabled && !advertencia.Visible &&
                MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 0.6m &&
                Equals(Campo<ComboBox>(panel, "fuente").SelectedItem, MYGFuenteMetrado.Excel),
                "Actualizar debe vincular el total Excel, conservar hojas y otros metrados, y registrar un solo cambio sin guardar.");
            actualizar.PerformClick(); Application.DoEvents();
            exige(anteriores == 1 && cambios == 1 && guardados == 0,
                "Con el metrado aplicado, repetir el clic no debe crear otro cambio.");

            primera.Costos.Hoja.Poner("B3", "0.4");
            Invocar(panel, "RecalcularHoja"); Application.DoEvents();
            exige(actualizar.Enabled && !advertencia.Visible && primera.Costos.Cantidad == 0.6m &&
                primera.Costos.FuenteMetrado == MYGFuenteMetrado.Excel &&
                MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 1.2m,
                "Editar después la hoja debe recalcular el metrado vinculado sin necesitar otro clic en Actualizar.");
            Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
            exige(primera.Costos.Cantidad == 12m && primera.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
                Estado(primera.Costos.Hoja) == hojaAplicada &&
                actualizar.Visible && actualizar.Enabled && advertencia.Visible && Estado(segunda.Costos) == vecina,
                "Deshacer la aplicación debe recuperar la cantidad previa y su hoja completa, y recalcular el aviso.");

            hoja.CurrentCell = hoja[1, 2];
            exige(hoja.BeginEdit(true), "Debe poder editarse el factor B3 antes de actualizar el presupuesto.");
            ((TextBoxBase)hoja.EditingControl).Text = "0.5";
            var previo = (anteriores, cambios);
            actualizar.PerformClick(); Application.DoEvents();
            exige(!hoja.IsCurrentCellInEditMode && primera.Costos.Hoja.Celdas["B3"].Contenido == "0.5" &&
                primera.Costos.Cantidad == 1.5m && primera.Costos.FuenteMetrado == MYGFuenteMetrado.Excel &&
                anteriores == previo.anteriores + 2 && cambios == previo.cambios + 2 &&
                historial.Peek().Cantidad == 12m && historial.Peek().Hoja.Celdas["B3"].Contenido == "0.5" &&
                !advertencia.Visible && actualizar.Enabled,
                "El clic debe confirmar primero la celda pendiente y vincular su total nuevo: un cambio por edición y otro por actualización.");

            hoja.CurrentCell = hoja[6, 15];
            var formula = Campo<TextBoxBase>(panel, "formula");
            formula.Focus(); formula.Text = "=B3*C3+0.25";
            previo = (anteriores, cambios);
            actualizar.PerformClick(); Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["G16"].Contenido == "=B3*C3+0.25" && primera.Costos.Cantidad == 1.5m &&
                primera.Costos.FuenteMetrado == MYGFuenteMetrado.Excel &&
                MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 1.75m &&
                anteriores == previo.anteriores + 1 && cambios == previo.cambios + 1 &&
                !Campo<bool>(panel, "formulaPendienteHoja") && !advertencia.Visible && actualizar.Enabled,
                "Actualizar debe confirmar la fórmula pendiente y recalcular 1.75 sin registrar otra vinculación cuando ya está activa.");

            VerificarVinculoEstructural(panel, hoja, presupuesto, primera, actualizar, advertencia,
                () => (anteriores, cambios, guardados), exige);

            primera.Costos.Cantidad = 8m;
            primera.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
            primera.Costos.Hoja.Poner("G16", "=1.23456");
            Invocar(panel, "RecalcularHoja"); Application.DoEvents();
            previo = (anteriores, cambios);
            actualizar.PerformClick(); Application.DoEvents();
            exige(MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 1.2346m &&
                actualizar.Visible && actualizar.Enabled && !advertencia.Visible &&
                anteriores == previo.anteriores + 1 && cambios == previo.cambios + 1,
                "Aplicar un total con más precisión debe respetar los cuatro decimales del presupuesto sin dejar una advertencia falsa.");

            primera.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
            Invocar(panel, "RecalcularHoja"); Application.DoEvents();
            previo = (anteriores, cambios);
            exige(!advertencia.Visible && actualizar.Visible && actualizar.Enabled,
                "Una cantidad coincidente debe permitir activar el vínculo aunque no exista advertencia de desajuste.");
            actualizar.PerformClick(); Application.DoEvents();
            exige(primera.Costos.FuenteMetrado == MYGFuenteMetrado.Excel &&
                anteriores == previo.anteriores + 1 && cambios == previo.cambios + 1 && !advertencia.Visible,
                "Actualizar con cantidades coincidentes debe vincular la hoja y registrar una sola modificación.");

            primera.Costos.Cantidad = 2m;
            primera.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
            Invocar(panel, "ActualizarCalculos"); Application.DoEvents();
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos(); Application.DoEvents();
                int S(int n) => (int)Math.Round(n * cabecera.DeviceDpi / 96d);
                exige(xls.Width == S(90) && xls.Height == S(60) && xls.Top == S(4) &&
                    actualizar.Width == S(90) && actualizar.Height == S(26) && actualizar.Top == S(70) &&
                    actualizar.Left == xls.Left && actualizar.Top >= xls.Bottom &&
                    cabecera.ClientRectangle.Contains(xls.Bounds) && cabecera.ClientRectangle.Contains(actualizar.Bounds) &&
                    advertencia.Visible && !advertencia.Bounds.IntersectsWith(xls.Bounds) &&
                    !advertencia.Bounds.IntersectsWith(actualizar.Bounds),
                    "XLS debe ser compacto arriba a la derecha, con Actualizar debajo y la advertencia sin superponer controles en ambos temas.");
                exige(menu.Items.Count == 2 && menu.Items[0].Text == "PLANTILLA ESTÁNDAR" &&
                    menu.Items[1].Text == "PLANTILLA DE FIERROS Y ACEROS" &&
                    xls.AccessibleName == "Seleccionar plantilla de metrado",
                    "La actualización y los temas deben conservar el menú XLS de las dos plantillas.");
            }
            previo = (anteriores, cambios);
            panel.SeleccionarEstructura(segunda); Application.DoEvents();
            exige(!actualizar.Visible && !advertencia.Visible && Estado(segunda.Costos) == vecina,
                "Seleccionar una partida vecina sin total de hoja debe ocultar el botón y su aviso sin heredar el desajuste anterior.");
            panel.SeleccionarEstructura(primera); Application.DoEvents();
            exige(actualizar.Visible && actualizar.Enabled && advertencia.Visible &&
                (anteriores, cambios) == previo && guardados == 0 && Estado(segunda.Costos) == vecina,
                "Volver a la partida debe restaurar su propio desajuste sin crear historial ni guardar el proyecto.");
            var reemplazo = MYGProyectoStorage.Copia(primera);
            presupuesto.Items[presupuesto.Items.IndexOf(primera)] = reemplazo;
            string originalObsoleto = Estado(primera.Costos), originalVigente = Estado(reemplazo.Costos);
            actualizar.PerformClick(); Application.DoEvents();
            exige(Estado(primera.Costos) == originalObsoleto && Estado(reemplazo.Costos) == originalVigente &&
                (anteriores, cambios) == previo && guardados == 0,
                "Un detalle obsoleto no debe confirmar ediciones ni copiar su metrado a una instancia sustituida del mismo ítem.");
            formulario.Close();
        }
        finally { if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false); }
    }

    private static void VerificarVinculoEstructural(MYGPanelPresupuesto panel, DataGridView hoja,
        MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, Button actualizar, Label advertencia,
        Func<(int Anteriores, int Cambios, int Guardados)> contadores, Action<bool, string> exige)
    {
        void Seleccionar(string direccion)
        {
            var celda = MYGHojaCalculo.Coordenadas(direccion);
            hoja.ClearSelection();
            hoja.CurrentCell = hoja[celda.Columna - 1, celda.Fila - 1];
            hoja.CurrentCell.Selected = true;
        }
        void Comando(string direccion, string comando)
        {
            Seleccionar(direccion);
            Invocar(panel, "EjecutarComandoHoja", comando); Application.DoEvents();
        }
        void ExigirTotal(string direccion, decimal cantidad, string mensaje)
        {
            var estructura = Campo<DataGridView>(panel, "estructura");
            var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, partida));
            exige(partida.Costos.FuenteMetrado == MYGFuenteMetrado.Excel && partida.Costos.Hoja.CeldaTotal == direccion &&
                Campo<TextBox>(panel, "celdaTotal").Text == direccion &&
                MYGMotorPresupuestos.Cantidad(presupuesto, partida) == cantidad &&
                Convert.ToDecimal(fila.Cells["CANT"].Value) == cantidad &&
                Convert.ToDecimal(fila.Cells["TOTAL"].Value) == cantidad * 10m &&
                actualizar.Visible && actualizar.Enabled && !advertencia.Visible, mensaje);
        }

        Comando("A4", "insertar_filas");
        ExigirTotal("G17", 1.75m, "Insertar filas debe desplazar el total vinculado y mantener la cantidad y el importe del presupuesto.");
        Comando("F4", "insertar_columnas");
        ExigirTotal("H17", 1.75m, "Insertar columnas debe conservar el vínculo aunque el total deje de estar en G16.");
        Comando("A4", "eliminar_filas");
        ExigirTotal("H16", 1.75m, "Eliminar una fila anterior al total debe actualizar su dirección sin perder el metrado.");
        Comando("F3", "eliminar_columnas");
        ExigirTotal("G16", 1.75m, "Eliminar una columna anterior al total debe conservar la fórmula y el vínculo del presupuesto.");
        Comando("A4", "eliminar_filas");
        Comando("F3", "eliminar_columnas");
        ExigirTotal("F15", 1.75m, "El vínculo debe seguir el resultado después de eliminar filas y columnas de la plantilla original.");

        Seleccionar("B3");
        exige(hoja.BeginEdit(true), "Debe poder editarse un factor después de desplazar el total vinculado.");
        ((TextBoxBase)hoja.EditingControl).Text = "0.75";
        var previo = contadores();
        actualizar.PerformClick(); Application.DoEvents();
        ExigirTotal("F15", 2.5m, "Editar el metrado con el total desplazado debe recalcular la cantidad y el importe visibles.");
        exige(contadores() == (previo.Anteriores + 1, previo.Cambios + 1, previo.Guardados),
            "Confirmar un factor con el vínculo activo debe registrar sólo su edición, sin otra aplicación ni guardado automático.");

        Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
        ExigirTotal("F15", 1.75m, "Deshacer un factor debe recalcular el presupuesto conservando el vínculo y la dirección desplazada.");
        Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
        ExigirTotal("G15", 1.75m, "Deshacer la eliminación de una columna debe restablecer la dirección del total vinculado.");
        Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
        ExigirTotal("G16", 1.75m, "Deshacer la eliminación de una fila debe restablecer el total original manteniendo el vínculo Excel.");

        Seleccionar("F16"); hoja[6, 15].Selected = true;
        Invocar(panel, "EjecutarComandoHoja", "combinar"); Application.DoEvents();
        ExigirTotal("F16", 1.75m, "Combinar el total con la celda vacía de su izquierda debe mover también la dirección visible al ancla combinada.");
        exige(partida.Costos.Hoja.Celdas["F16"].Contenido == "=B3*C3+0.25",
            "Combinar el total debe conservar su fórmula en el ancla combinada.");
        Invocar(panel, "UsarTotalHoja"); Application.DoEvents();
        ExigirTotal("F16", 1.75m, "Usar el total después de combinarlo debe conservar el resultado y evitar volver a su celda vacía anterior.");
        Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
        Invocar(panel, "EjecutarComandoHoja", "deshacer"); Application.DoEvents();
        ExigirTotal("G16", 1.75m, "Deshacer la combinación debe restaurar la fórmula y el vínculo en la dirección previa del total.");
    }

    private static string Estado(object valor) => JsonSerializer.Serialize(valor);
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
