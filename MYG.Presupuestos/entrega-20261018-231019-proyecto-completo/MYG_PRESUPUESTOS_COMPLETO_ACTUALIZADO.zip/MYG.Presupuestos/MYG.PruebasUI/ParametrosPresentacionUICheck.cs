using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG_2027;

internal static class ParametrosPresentacionUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-ParametrosPresentacion-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        string rutaAnterior = MYGParametrosUsuario.RutaAlternativaPruebas;
        bool oscuroAnterior = MYG2027_TemaComercial.Oscuro;
        try
        {
            MYGParametrosUsuario.RutaAlternativaPruebas = Path.Combine(carpeta, "parametros.json");
            MYGParametrosAplicacionUI.Actualizar();
            if (MYG2027_TemaComercial.Oscuro) MYG2027_TemaComercial.Alternar(false);
            Color claro = MYG2027_TemaComercial.ColorTitulo(0);
            MYG2027_TemaComercial.Alternar(false);
            Color oscuro = MYG2027_TemaComercial.ColorTitulo(0);
            exige(SystemInformation.HighContrast || claro != oscuro,
                "Sin parámetros guardados deben conservarse las paletas originales de los modos normal y oscuro.");

            var parametros = MYGParametrosUsuario.Leer();
            parametros.NombreComercial = "Empresa de prueba";
            parametros.DivisionPolitica[0].Nombre = "Región";
            parametros.DivisionPolitica[0].Abreviatura = "REG";
            parametros.ColoresNiveles[9] = "812345";
            using (var imagen = new Bitmap(3, 2))
            using (var flujo = new MemoryStream())
            {
                imagen.Save(flujo, ImageFormat.Png);
                parametros.LogoBase64 = Convert.ToBase64String(flujo.ToArray());
            }
            MYGParametrosUsuario.Guardar(parametros);
            MYGParametrosAplicacionUI.Actualizar();
            exige((SystemInformation.HighContrast || MYG2027_TemaComercial.ColorTitulo(9).ToArgb() == Color.FromArgb(0x81, 0x23, 0x45).ToArgb())
                && MYG2027_TemaComercial.ColorTituloImpresion(9).ToArgb() == Color.FromArgb(0x81, 0x23, 0x45).ToArgb(),
                "Los diez niveles configurables deben afectar a los títulos y a su impresión, respetando alto contraste en pantalla.");
            using var identidad = MYGParametrosAplicacionUI.CrearIdentidadEmpresa();
            var logo = (PictureBox)identidad.Controls.Find("logoEmpresaInicio", true).Single();
            var empresa = (Label)identidad.Controls.Find("nombreEmpresaInicio", true).Single();
            exige(empresa.Text == parametros.NombreComercial && logo.Image?.Width == 3 && logo.Image.Height == 2,
                "La identidad de Inicio debe mostrar el nombre comercial y una copia del logotipo guardado.");

            string baseDatos = Path.Combine(carpeta, "proyectos.sqlite");
            MYGBaseDatos.CrearBaseVacia(baseDatos);
            byte[] antes = File.ReadAllBytes(baseDatos);
            using (var nuevo = new MYGDatosProyectoForm(baseDatos, "Proyecto cancelado"))
            {
                var propietarios = Catalogos(nuevo)[MYGCatalogoProyecto.Propietarios];
                exige(NombreSeleccion(propietarios) == parametros.NombreComercial && IdSeleccion(propietarios) == null,
                    "Un proyecto nuevo debe proponer la empresa sin crear todavía un propietario en el catálogo.");
                exige(Controles(nuevo).OfType<Label>().Any(l => l.Text == "Región (REG)"),
                    "La ubicación debe usar el nombre y la abreviatura configurados para la división política.");
            }
            exige(antes.SequenceEqual(File.ReadAllBytes(baseDatos)) &&
                MYGCatalogosProyecto.Listar(baseDatos, MYGCatalogoProyecto.Propietarios).Count == 0,
                "Abrir y cancelar el proyecto debe conservar la base y su catálogo de propietarios sin cambios.");
            string propietarioId;
            using (var nuevo = new MYGDatosProyectoForm(baseDatos, "Proyecto aceptado"))
            {
                typeof(MYGDatosProyectoForm).GetMethod("Aceptar", Privados).Invoke(nuevo, null);
                propietarioId = nuevo.Datos?.PropietarioId;
                exige(nuevo.DialogResult == DialogResult.OK && !string.IsNullOrWhiteSpace(propietarioId)
                    && nuevo.Datos.Propietario == parametros.NombreComercial,
                    "Aceptar un proyecto válido debe registrar el propietario predeterminado y devolver su identificador.");
            }
            using (var nuevo = new MYGDatosProyectoForm(baseDatos, "Segundo proyecto"))
                exige(IdSeleccion(Catalogos(nuevo)[MYGCatalogoProyecto.Propietarios]) == propietarioId &&
                    MYGCatalogosProyecto.Listar(baseDatos, MYGCatalogoProyecto.Propietarios).Count == 1,
                    "Los siguientes proyectos deben reutilizar el propietario existente sin duplicarlo.");
            var datosAnteriores = MYGDatosProyecto.Crear(); datosAnteriores.Propietario = "Propietario conservado";
            using (var editar = new MYGDatosProyectoForm(baseDatos, "Proyecto existente", datosAnteriores))
                exige(NombreSeleccion(Catalogos(editar)[MYGCatalogoProyecto.Propietarios]) == datosAnteriores.Propietario,
                    "Editar un proyecto debe conservar su propietario aunque el usuario cambie de empresa predeterminada.");

            parametros.NombreComercial = "Empresa actualizada"; parametros.LogoBase64 = "";
            MYGParametrosUsuario.Guardar(parametros); MYGParametrosAplicacionUI.Actualizar();
            exige(empresa.Text == parametros.NombreComercial && logo.Image == null,
                "Guardar parámetros debe actualizar la identidad visible y retirar un logotipo eliminado.");
            parametros.LogoBase64 = Convert.ToBase64String(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 });
            MYGParametrosUsuario.Guardar(parametros); MYGParametrosAplicacionUI.Actualizar();
            exige(empresa.Text == parametros.NombreComercial && logo.Image == null,
                "Un logo con cabecera reconocible pero contenido dañado no debe bloquear Inicio ni ocultar el nombre comercial.");
            File.WriteAllText(MYGParametrosUsuario.RutaPredeterminada, "{archivo dañado");
            MYGParametrosAplicacionUI.Actualizar();
            exige(MYGParametrosAplicacionUI.ErrorLectura != null &&
                MYG2027_TemaComercial.ColorTitulo(0) == oscuro &&
                File.ReadAllText(MYGParametrosUsuario.RutaPredeterminada) == "{archivo dañado",
                "Un archivo dañado debe recuperar la paleta original para dibujar sin sobrescribirlo ni ocultar el diagnóstico.");
        }
        finally
        {
            MYGParametrosUsuario.RutaAlternativaPruebas = rutaAnterior;
            MYGParametrosAplicacionUI.Actualizar();
            if (MYG2027_TemaComercial.Oscuro != oscuroAnterior) MYG2027_TemaComercial.Alternar(false);
            Directory.Delete(carpeta, recursive: true);
        }
    }

    private static Dictionary<MYGCatalogoProyecto, ComboBox> Catalogos(MYGDatosProyectoForm formulario) =>
        (Dictionary<MYGCatalogoProyecto, ComboBox>)typeof(MYGDatosProyectoForm).GetField("catalogos", Privados).GetValue(formulario);
    private static string IdSeleccion(ComboBox combo) => (string)combo.SelectedItem.GetType().GetProperty("Id").GetValue(combo.SelectedItem);
    private static string NombreSeleccion(ComboBox combo) => (string)combo.SelectedItem.GetType().GetProperty("Nombre").GetValue(combo.SelectedItem);
    private static IEnumerable<Control> Controles(Control control)
    {
        foreach (Control hijo in control.Controls)
        {
            yield return hijo;
            foreach (Control nieto in Controles(hijo)) yield return nieto;
        }
    }
}
