using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class VistaPreliminarExportacionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var hoja = MYGExcelPresupuestos.Tabla("Presupuesto", new[] { "Descripción", "Importe" }, new[] { new object[] { "Partida", 88m } });
        using var formulario = new MYGVistaPreliminarReportesForm("Exportación", new[] { new MYGHojaReporteProyecto("Presupuesto", hoja) });
        var acciones = Controles(formulario).OfType<ToolStrip>().SelectMany(s => s.Items.Cast<ToolStripItem>())
            .Where(i => !string.IsNullOrEmpty(i.Name)).ToDictionary(i => i.Name);
        var exportar = acciones["vista_pdf_barra"] as ToolStripDropDownButton;
        var correo = acciones["vista_email"] as ToolStripDropDownButton;
        exige(exportar != null && correo != null && exportar.Text == "Exportar\ncomo" && correo.Text == "E-Mail\nComo",
            "La cinta debe mostrar Exportar como y E-Mail Como como botones desplegables independientes.");
        string[] formatos = { "pdf", "html", "mht", "rtf", "xls", "xlsx", "csv", "txt", "img" };
        exige(exportar.DropDownItems.Cast<ToolStripItem>().Select(i => i.Name).SequenceEqual(formatos.Select(f => "vista_exportar_" + f)) &&
            correo.DropDownItems.Cast<ToolStripItem>().Select(i => i.Name).SequenceEqual(formatos.Where(f => f != "html").Select(f => "vista_email_" + f)),
            "Exportar debe ofrecer los nueve formatos de referencia en orden y E-Mail los mismos ocho sin HTML.");
        foreach (var boton in new[] { exportar, correo })
        {
            var renderer = boton.DropDown.Renderer;
            MYG2027_TemaComercial.Aplicar(formulario);
            exige(ReferenceEquals(renderer, boton.DropDown.Renderer),
                "Cambiar el tema debe conservar el dibujo con título, descripción y selección amarilla de los formatos.");
            foreach (MYGVistaPreliminarExportacionMenu.OpcionFormato item in boton.DropDownItems)
            {
                var formato = item.Formato;
                Size medida = item.GetPreferredSize(Size.Empty);
                exige(item.Text == formato.Titulo + "\n" + formato.Descripcion && item.AccessibleName == formato.Titulo &&
                    item.AccessibleDescription == formato.Descripcion && item.Image is { Width: >= 40, Height: >= 40 } &&
                    medida.Height >= 60 && medida.Width >= 150,
                    "Cada formato debe presentar su icono grande, título y descripción completos y nombre accesible.");
            }
        }
        var exportacion = exportar.DropDownItems.Cast<ToolStripItem>().ToDictionary(i => i.Name["vista_exportar_".Length..]);
        foreach (var item in correo.DropDownItems.Cast<ToolStripItem>())
        {
            string formato = item.Name["vista_email_".Length..];
            using var normal = new Bitmap(exportacion[formato].Image);
            using var email = new Bitmap(item.Image);
            exige(Firma(normal) != Firma(email), "Cada icono de E-Mail debe incluir el sobre y diferenciarse del icono de exportación de " + formato + ".");
        }
        var firmas = exportar.DropDownItems.Cast<ToolStripItem>().Select(i => { using var b = new Bitmap(i.Image); return Firma(b); }).ToArray();
        exige(firmas.Distinct().Count() == formatos.Length, "Los nueve formatos deben tener iconos distintos, con su extensión y color propios.");
        exige(MYGVistaPreliminarExportacionMenu.Formatos.Single(f => f.Valor == MYGFormatoVistaReporte.Imagen).Filtro
                .Contains("Metarchivo EMF (*.emf)|*.emf|Metarchivo WMF (*.wmf)|*.wmf"),
            "El selector de imágenes debe ofrecer también EMF y WMF, además de los cinco formatos de mapa de bits.");
        var menus = new[] { exportar.DropDown, correo.DropDown };
        var opciones = menus.SelectMany(m => m.Items.Cast<ToolStripItem>()).ToArray();
        formulario.Dispose();
        exige(menus.All(m => m.IsDisposed) && opciones.All(i => i.IsDisposed),
            "Cerrar la vista debe liberar los dos menús asignados y todos sus iconos y opciones.");
        VerificarImagenes(exige);
    }

    private static void VerificarImagenes(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Imagenes-QA-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            var hoja = new MYGHojaMetrado { Filas = 100, Columnas = 2, CeldaTotal = "B100", AreaImpresion = "A1:B100" };
            for (int i = 1; i <= 100; i++) { hoja.Poner("A" + i, "Partida " + i); hoja.Poner("B" + i, i.ToString()); }
            var vista = MYGReportesImpresion.PrepararVista(new[] { new MYGHojaReporteProyecto("Imágenes", hoja) });
            exige(vista.CantidadPaginas > 1, "La exportación de imágenes debe comprobarse con un informe de varias páginas.");
            var firmas = new Dictionary<string, byte[]>
            {
                ["png"] = new byte[] { 0x89, 0x50, 0x4e, 0x47 }, ["bmp"] = new byte[] { 0x42, 0x4d },
                ["gif"] = new byte[] { 0x47, 0x49, 0x46 }, ["jpg"] = new byte[] { 0xff, 0xd8 },
                ["tiff"] = new byte[] { 0x49, 0x49 }, ["emf"] = new byte[] { 1, 0, 0, 0 },
                ["wmf"] = new byte[] { 0xd7, 0xcd, 0xc6, 0x9a }
            };
            foreach (var formato in firmas)
            {
                string ruta = Path.Combine(carpeta, "pagina." + formato.Key);
                var escritos = MYGReportesImagenExportacion.Guardar(ruta, vista, 1, 1);
                exige(escritos.Single() == ruta && File.ReadAllBytes(ruta).Take(formato.Value.Length).SequenceEqual(formato.Value),
                    "La exportación " + formato.Key + " debe generar su formato real y devolver el archivo creado.");
            }
            using (var imagen = Image.FromFile(Path.Combine(carpeta, "pagina.png")))
            {
                SizeF papel = vista.TamanoPagina(0);
                exige(imagen.Width == (int)Math.Ceiling(papel.Width * 150) && imagen.Height == (int)Math.Ceiling(papel.Height * 150),
                    "La imagen debe conservar la página completa con su tamaño y orientación a 150 DPI.");
            }
            string solicitada = Path.Combine(carpeta, "seleccion.png");
            int primera = vista.CantidadPaginas > 2 ? 2 : 1;
            string salida = MYGReportesImagenExportacion.RutaSalida(solicitada, primera, vista.CantidadPaginas);
            var archivos = MYGReportesImagenExportacion.Guardar(solicitada, vista, primera, vista.CantidadPaginas);
            using (var zip = ZipFile.OpenRead(archivos.Single()))
                exige(salida.EndsWith(".zip", StringComparison.Ordinal) && archivos.Single() == salida &&
                    zip.Entries.Select(e => e.Name).SequenceEqual(Enumerable.Range(primera, vista.CantidadPaginas - primera + 1).Select(i => "pagina-" + i.ToString("000") + ".png")),
                    "Exportar un rango a imágenes debe incluir exactamente esas páginas numeradas en un único ZIP.");
            byte[] antes = File.ReadAllBytes(salida);
            bool rechazo = false;
            try { MYGReportesImagenExportacion.Guardar(solicitada, vista, 1, vista.CantidadPaginas + 1); }
            catch (ArgumentOutOfRangeException) { rechazo = true; }
            exige(rechazo && File.ReadAllBytes(salida).SequenceEqual(antes),
                "Un rango fuera del informe debe fallar sin reemplazar un archivo de imágenes anterior.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static IEnumerable<Control> Controles(Control control)
    {
        yield return control;
        foreach (Control hijo in control.Controls)
            foreach (var item in Controles(hijo)) yield return item;
    }
    private static long Firma(Bitmap imagen)
    {
        unchecked
        {
            long firma = 17;
            for (int y = 0; y < imagen.Height; y++)
                for (int x = 0; x < imagen.Width; x++) firma = firma * 31 + imagen.GetPixel(x, y).ToArgb();
            return firma;
        }
    }
}
