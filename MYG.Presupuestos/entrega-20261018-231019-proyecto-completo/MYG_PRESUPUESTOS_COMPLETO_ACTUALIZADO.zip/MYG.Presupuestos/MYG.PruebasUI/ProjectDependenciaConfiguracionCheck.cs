using System;
using System.IO;
using System.Runtime.InteropServices;
using MYG_2027;

internal static class ProjectDependenciaConfiguracionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        object tareaOrigen = new(), dependencia = new();
        foreach (var caso in new[]
        {
            (MYGTipoVinculo.FF, 0), (MYGTipoVinculo.FC, 1),
            (MYGTipoVinculo.CF, 2), (MYGTipoVinculo.CC, 3)
        })
        {
            object[] recibidos = null;
            object resultado = MYGConfiguracionDependenciaProject.Ejecutar(
                new MYGDependenciaExportacionProject(20, 10, caso.Item1, 0), tareaOrigen, argumentos =>
                {
                    recibidos = argumentos;
                    FirmaEstricta(argumentos);
                    return dependencia;
                });
            exige(ReferenceEquals(resultado, dependencia) && recibidos.Length == 2 &&
                ReferenceEquals(recibidos[0], tareaOrigen) && recibidos[1] is int tipo && tipo == caso.Item2,
                "La dependencia " + caso.Item1 + " debe enviar el objeto predecesor exacto, su tipo COM y omitir el desfase cero.");
        }
        foreach (int minutos in new[] { 1, 480, -1, -960, int.MaxValue, int.MinValue })
        {
            object[] recibidos = null;
            MYGConfiguracionDependenciaProject.Ejecutar(new(20, 10, MYGTipoVinculo.FC, minutos), tareaOrigen, argumentos =>
            {
                recibidos = argumentos;
                FirmaEstricta(argumentos);
                return dependencia;
            });
            exige(recibidos.Length == 3 && ReferenceEquals(recibidos[0], tareaOrigen) &&
                recibidos[2] is int valor && valor == minutos,
                "El desfase " + minutos + " debe conservarse como minutos Int32 por posición, incluido su signo.");
        }
        foreach (decimal minutos in new[] { 0.25m, -0.5m, (decimal)int.MaxValue + 1, (decimal)int.MinValue - 1 })
        {
            object[] recibidos = null;
            MYGConfiguracionDependenciaProject.Ejecutar(new(20, 10, MYGTipoVinculo.FC, minutos), tareaOrigen, argumentos =>
            {
                recibidos = argumentos;
                FirmaEstricta(argumentos);
                return dependencia;
            });
            exige(recibidos.Length == 3 && recibidos[2] is double valor && valor == (double)minutos,
                "El desfase " + minutos + " debe conservarse numéricamente por posición, sin redondear sus fracciones ni forzarlo a Int32.");
        }
        foreach (var invalida in new[]
        {
            new MYGDependenciaExportacionProject(20, 10, (MYGTipoVinculo)999, 0),
            new MYGDependenciaExportacionProject(20, 20, MYGTipoVinculo.FC, 0),
            new MYGDependenciaExportacionProject(0, 10, MYGTipoVinculo.FC, 0),
            new MYGDependenciaExportacionProject(20, 0, MYGTipoVinculo.FC, 0)
        })
        {
            int llamadas = 0; bool rechazado = false;
            try
            {
                MYGConfiguracionDependenciaProject.Ejecutar(invalida, tareaOrigen, argumentos =>
                { llamadas++; return dependencia; });
            }
            catch (InvalidDataException) { rechazado = true; }
            exige(rechazado && llamadas == 0,
                "Una dependencia inválida debe rechazarse antes de invocar Project, sin redondear o reinterpretar sus valores.");
        }
        var falloCom = new COMException("El valor del argumento no es válido.", unchecked((int)0x800A044D));
        Exception recibido = null; int intentos = 0;
        try
        {
            MYGConfiguracionDependenciaProject.Ejecutar(new(20, 10, MYGTipoVinculo.FC, -480), tareaOrigen, argumentos =>
            { intentos++; throw falloCom; });
        }
        catch (COMException ex) { recibido = ex; }
        exige(ReferenceEquals(recibido, falloCom) && intentos == 1,
            "Un rechazo COM debe propagarse intacto, sin reintentar otra relación ni eliminar su adelanto.");
        bool sinResultado = false;
        try { MYGConfiguracionDependenciaProject.Ejecutar(new(20, 10, MYGTipoVinculo.FC, 0), tareaOrigen, _ => null); }
        catch (InvalidOperationException) { sinResultado = true; }
        exige(sinResultado, "Project debe devolver la dependencia; un resultado nulo nunca debe declararse exitoso.");
    }

    // Este sustituto exige el tipo numérico compatible para cada valor y los
    // argumentos posicionales; permite ejecutar la regresión sin Office.
    private static void FirmaEstricta(object[] argumentos)
    {
        if (argumentos.Length is not (2 or 3) || argumentos[0] == null || argumentos[1] is not int ||
            (argumentos.Length == 3 && argumentos[2] is not (int or double)))
            throw new ArgumentException("Firma posicional de TaskDependencies.Add incompatible.");
        if (argumentos.Length == 3 && argumentos[2] is double numero &&
            numero == Math.Truncate(numero) && numero >= int.MinValue && numero <= int.MaxValue)
            throw new ArgumentException("Los desfases enteros representables deben enviarse como Int32.");
    }
}
