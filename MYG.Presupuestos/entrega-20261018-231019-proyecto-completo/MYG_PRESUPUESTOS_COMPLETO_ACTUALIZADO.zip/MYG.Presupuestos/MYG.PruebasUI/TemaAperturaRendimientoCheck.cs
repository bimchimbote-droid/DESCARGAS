using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class TemaAperturaRendimientoCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuro = MYG2027_TemaComercial.Oscuro;
        try
        {
            VerificarFormulario(exige);
            VerificarMenuOculto(exige);
            VerificarMenuEspecificaciones(exige);
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarFormulario(Action<bool, string> exige)
    {
        using var formulario = new FormColores { ClientSize = new Size(420, 220) };
        using var etiqueta = new Label { Text = "Presupuesto", Dock = DockStyle.Top };
        using var tabla = new DataGridView { Dock = DockStyle.Fill, AllowUserToAddRows = false };
        tabla.Columns.Add("descripcion", "Descripción");
        tabla.Rows.Add("Partida que debe conservarse");
        formulario.Controls.Add(tabla);
        formulario.Controls.Add(etiqueta);
        formulario.Show();
        MYG2027_TemaComercial.Aplicar(formulario);
        int invalidaciones = 0;
        etiqueta.Invalidated += (_, _) => invalidaciones++;
        for (int i = 0; i < 20; i++)
        {
            Filtrar(formulario, mostrar: true);
            Filtrar(tabla, mostrar: false);
        }
        exige(invalidaciones == 0 && Convert.ToString(tabla[0, 0].Value) == "Partida que debe conservarse",
            "Mostrar o repintar una ventana ya preparada no debe recorrer e invalidar de nuevo sus controles ni cambiar sus datos.");

        using var nueva = new Label { Text = "Control nuevo", ForeColor = Color.Black, BackColor = Color.White };
        formulario.Controls.Add(nueva);
        exige(nueva.ForeColor == MYG2027_TemaComercial.Texto && nueva.BackColor == MYG2027_TemaComercial.Superficie,
            "Los controles añadidos después de preparar una ventana deben recibir la paleta sin renovar todo el formulario.");

        formulario.CambiarColoresSistema();
        invalidaciones = 0;
        Filtrar(formulario, mostrar: true);
        exige(invalidaciones > 0,
            "Una notificación de colores del sistema debe permitir renovar la paleta en la siguiente apertura.");
        invalidaciones = 0;
        Filtrar(formulario, mostrar: true);
        exige(invalidaciones == 0,
            "Tras renovar los colores del sistema, las aperturas siguientes deben reutilizar la preparación.");
        formulario.Close();
    }

    private static void VerificarMenuOculto(Action<bool, string> exige)
    {
        using var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Imprimir"));
        _ = menu.Handle;
        MYG2027_TemaComercial.Aplicar(menu);
        int invalidaciones = 0;
        menu.Invalidated += (_, _) => invalidaciones++;
        Filtrar(menu, mostrar: true);
        exige(invalidaciones == 0,
            "Reabrir un menú ya preparado debe reutilizar sus estilos.");

        MYG2027_TemaComercial.Alternar(false);
        Filtrar(menu, mostrar: true);
        exige(menu.BackColor == MYG2027_TemaComercial.Superficie && menu.Items[0].ForeColor == MYG2027_TemaComercial.Texto,
            "Un menú cerrado durante el cambio de tema debe actualizar su paleta antes de volver a mostrarse.");
        invalidaciones = 0;
        Filtrar(menu, mostrar: false);
        exige(invalidaciones == 0,
            "Repintar el menú después del cambio de tema no debe volver a aplicarlo.");

        MYG2027_TemaComercial.ActualizarColoresParametros();
        invalidaciones = 0;
        Filtrar(menu, mostrar: true);
        exige(invalidaciones > 0,
            "Los cambios de colores predeterminados deben renovar también los menús que estaban cerrados.");
        menu.Items.Add(new ToolStripMenuItem("Exportar") { ForeColor = Color.Black });
        exige(menu.Items[1].ForeColor == MYG2027_TemaComercial.Texto,
            "Las opciones añadidas a un menú preparado deben recibir inmediatamente la paleta actual.");
    }

    private static void VerificarMenuEspecificaciones(Action<bool, string> exige)
    {
        int antes = 0, cambios = 0;
        using var documento = new RichTextBox { DetectUrls = false };
        using var editor = new MYGEspecificacionesEditor(documento, () => antes++, () => cambios++,
            () => "Partida de prueba", () => "und", () => "01");
        using var formulario = new Form { ClientSize = new Size(980, 740) };
        formulario.Controls.Add(editor);
        formulario.Show();
        MYG2027_TemaComercial.Aplicar(formulario);
        editor.Cargar("tema-apertura", @"{\rtf1\ansi Texto \b de autor\b0.}", "");
        documento.Select(2, 3);
        string rtf = editor.DocumentoRtf;
        bool undo = documento.CanUndo;
        var callbacks = (antes, cambios);
        var menu = documento.ContextMenuStrip;
        menu.Show(documento, new Point(4, 4));
        Filtrar(menu, mostrar: true);
        int invalidaciones = 0;
        documento.Invalidated += (_, _) => invalidaciones++;
        for (int i = 0; i < 20; i++)
        {
            Filtrar(menu, mostrar: false);
            Filtrar(menu, mostrar: true);
        }
        exige(invalidaciones == 0,
            "Mostrar y repintar el menú de especificaciones no debe volver a recorrer e invalidar su editor en cada mensaje.");
        var renderer = Descendientes(editor).OfType<ToolStrip>().First().Renderer;
        exige(ReferenceEquals(menu.Renderer, renderer) && editor.DocumentoRtf == rtf
            && documento.SelectionStart == 2 && documento.SelectionLength == 3
            && documento.CanUndo == undo && (antes, cambios) == callbacks,
            "Reutilizar la preparación del menú debe conservar su renderer especializado, RTF, selección, Deshacer y callbacks.");
        menu.Close();
        formulario.Close();
    }

    private static void Filtrar(Control control, bool mostrar)
    {
        var mensaje = Message.Create(control.Handle, mostrar ? 0x0018 : 0x000F,
            mostrar ? new IntPtr(1) : IntPtr.Zero, IntPtr.Zero);
        Application.FilterMessage(ref mensaje);
    }

    private static System.Collections.Generic.IEnumerable<Control> Descendientes(Control raiz)
    {
        foreach (Control hijo in raiz.Controls)
        {
            yield return hijo;
            foreach (var nieto in Descendientes(hijo)) yield return nieto;
        }
    }

    private sealed class FormColores : Form
    {
        internal void CambiarColoresSistema() => OnSystemColorsChanged(EventArgs.Empty);
    }
}
