using System;
using System.Drawing;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesVistaPreliminarCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var original = new RichTextBox
        {
            Rtf = @"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}{\f1 Courier New;}}{\colortbl;\red0\green0\blue255;}" +
                @"\pard\qc\f0\fs32\b Encabezado\b0\par\pard\ql\f1\fs20\i\ul\cf1 Cuerpo con formato\ul0\i0\cf0\par" +
                @"\trowd\trgaph90\cellx2000\cellx4000\pard\intbl A\cell B\cell\row\pard\par}"
        };
        original.Select(2, 5);
        original.Modified = false;
        string rtfOriginal = original.Rtf;
        using var copia = MYGEspecificacionesDocumento.CrearCopiaImpresion(original);
        exige(copia.Text == original.Text && copia.Rtf.Contains("Arial Narrow;", StringComparison.Ordinal) &&
                copia.Rtf.Contains(@"\trowd", StringComparison.Ordinal),
            "La copia de impresión debe usar Arial Narrow y conservar el texto y las tablas de la especificación.");

        copia.Select(0, "Encabezado".Length);
        using (var titulo = copia.SelectionFont)
            exige(titulo != null && titulo.Bold && Math.Abs(titulo.SizeInPoints - 16) < .01 &&
                    copia.SelectionAlignment == HorizontalAlignment.Center,
                "La fuente de impresión debe conservar el tamaño, negrita y alineación del encabezado RTF.");
        copia.Select(copia.Text.IndexOf("Cuerpo", StringComparison.Ordinal), "Cuerpo con formato".Length);
        using (var cuerpo = copia.SelectionFont)
            exige(cuerpo != null && cuerpo.Italic && cuerpo.Underline && Math.Abs(cuerpo.SizeInPoints - 10) < .01 &&
                    copia.SelectionColor.ToArgb() == Color.Blue.ToArgb(),
                "Cambiar la familia de impresión debe conservar cursiva, subrayado, tamaño y color de una selección mixta.");
        exige(original.Rtf == rtfOriginal && original.SelectionStart == 2 && original.SelectionLength == 5 && !original.Modified,
            "Preparar Arial Narrow para la vista y la impresión no debe modificar el RTF, la selección ni el estado del editor.");
    }
}
