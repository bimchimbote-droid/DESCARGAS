using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class InsumosContextoUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Insumos por selección", "ESTRUCTURAS");
        proyecto.Datos ??= new MYGDatosProyecto();
        proyecto.Datos.Propietario = "PROPIETARIO DE INSUMOS";
        proyecto.Datos.FechaElaboracion = new DateTime(2026, 10, 12);
        var presupuesto = proyecto.Presupuestos.Single();
        var otroPresupuesto = MYGEstructuraPresupuestos.AgregarPresupuesto(proyecto);
        otroPresupuesto.Nombre = "ARQUITECTURA";
        var operario = Insumo("L01", "OPERARIO", "hh", MYGGrupoRecurso.ManoObra, 10m);
        var cemento = Insumo("M01", "CEMENTO", "bls", MYGGrupoRecurso.Materiales, 2m);
        var equipo = Insumo("E01", "MEZCLADORA", "hm", MYGGrupoRecurso.Equipo, 4m);
        presupuesto.Costos.Insumos.AddRange(new[] { operario, cemento, equipo });
        // Una entrada del catálogo sin referencias no pertenece a esta vista.
        presupuesto.Costos.Insumos.Add(Insumo("SIN_USO", "INSUMO SIN USO", "und", MYGGrupoRecurso.Materiales, 50m));
        var titulo = Item("01", "ESTRUCTURAS DEL TÍTULO", null, true, 1);
        var subtitulo = Item("01.01", "SUBTÍTULO", titulo.Id, true, 1);
        var primera = Item("01.01.01", "CONCRETO", subtitulo.Id, false, 1);
        primera.Costos.Cantidad = 2m;
        primera.Costos.RendimientoDiario = 3m;
        primera.Costos.JornadaHoras = 6m;
        primera.Costos.EspecificacionTexto = "Especificación de concreto conservada.";
        primera.Costos.Hoja.Poner("G16", "13.25");
        Agregar(primera, operario, 3m);
        Agregar(primera, cemento, 5m);
        var segunda = Item("01.02", "ACERO", titulo.Id, false, 2);
        segunda.Costos.Cantidad = 4m;
        Agregar(segunda, operario, 1m);
        var sinAnalisis = Item("01.03", "PARTIDA SIN ACU", titulo.Id, false, 3);
        sinAnalisis.Costos.Cantidad = 4m;
        var precioDirecto = Item("01.04", "PARTIDA CON PRECIO DIRECTO", titulo.Id, false, 4);
        precioDirecto.Costos.Cantidad = 3m;
        precioDirecto.Costos.PrecioDirecto = 20m;
        var otroTitulo = Item("02", "OTRO TÍTULO", null, true, 2);
        var exterior = Item("02.01", "EQUIPO FUERA DEL TÍTULO", otroTitulo.Id, false, 1);
        exterior.Costos.Cantidad = 3m;
        Agregar(exterior, equipo, 2m);
        presupuesto.Items.AddRange(new[] { titulo, subtitulo, primera, segunda, sinAnalisis, precioDirecto, otroTitulo, exterior });
        var otroInsumo = Insumo("P02", "PINTURA", "gal", MYGGrupoRecurso.Materiales, 7m);
        otroPresupuesto.Costos.Insumos.Add(otroInsumo);
        var otraPartida = Item("01", "PINTURA DE MUROS", null, false, 1);
        otraPartida.Costos.Cantidad = 5m;
        Agregar(otraPartida, otroInsumo, 2m);
        otroPresupuesto.Items.Add(otraPartida);
        MYGProyectoStorage.Validar(proyecto);

        var activo = presupuesto;
        int antes = 0, cambios = 0, guardados = 0;
        using var panel = new MYGPanelPresupuesto(() => activo, () => antes++, () => cambios++,
            _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
        panel.InicializarEstructura(() => proyecto,
            id => activo = proyecto.Presupuestos.Single(p => p.Id == id),
            _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1500, 900) };
        formulario.Controls.Add(panel);
        formulario.Show();
        panel.Refrescar();
        panel.SeleccionarEstructura(primera);
        Application.DoEvents();

        var contexto = Control<Control>(panel, "presupuesto_insumos_contexto");
        var vistas = Control<Panel>(panel, "presupuesto_vistas");
        var principal = Control<Panel>(panel, "presupuesto_vista_principal");
        var pestanas = Control<TabControl>(panel, "insumos_contexto_pestanas");
        var tabla = Control<DataGridView>(panel, "insumos_contexto_tabla");
        var detalle = Controles(panel).OfType<TabControl>().Single(t =>
            t.TabPages.Cast<TabPage>().Any(p => p.Text == "Análisis de C.U."));
        var paginaExcel = detalle.TabPages.Cast<TabPage>().Single(p => p.Text == "Metrados en Excel");
        var hoja = Controles(paginaExcel).OfType<DataGridView>().Single();
        var especificacion = Controles(panel).OfType<MYGEspecificacionesEditor>().Single();
        var rendimiento = Control<NumericUpDown>(panel, "acu_rendimiento");
        var jornada = Control<NumericUpDown>(panel, "acu_jornada");
        exige(detalle.Visible && !contexto.Visible,
            "Seleccionar una partida debe mostrar su detalle y mantener oculta la lista contextual de insumos.");
        string[] pestanasEliminadas = { "Proyecto / Presupuesto", "Lista de Insumos", "Lista de Costos" };
        exige(!Controles(panel).OfType<TabControl>().SelectMany(t => t.TabPages.Cast<TabPage>())
                .Any(p => pestanasEliminadas.Contains(p.Text, StringComparer.OrdinalIgnoreCase)),
            "El panel no debe conservar las pestañas inferiores redundantes de proyecto/presupuesto, insumos o costos.");
        exige(vistas.Bounds == panel.ClientRectangle && principal.Bounds == vistas.ClientRectangle,
            "La vista principal debe ocupar toda el área del panel sin reservar una franja para las pestañas eliminadas.");
        detalle.SelectedTab = paginaExcel;
        Application.DoEvents();
        string textoEspecificacion = especificacion.Documento.Text;
        object valorExcel = hoja.Rows[15].Cells["G"].Value;
        decimal rendimientoInicial = rendimiento.Value, jornadaInicial = jornada.Value;
        string firma = MYGProyectoStorage.Firma(proyecto);
        var contadores = (antes, cambios, guardados);

        Seleccionar(presupuesto);
        exige(contexto.Visible && !detalle.Visible && !Controles(detalle).Any(c => c.Visible),
            "Seleccionar un presupuesto debe sustituir el detalle de la partida por la lista de insumos, sin dejar un ACU gris visible.");
        exige(pestanas.Alignment == TabAlignment.Top && pestanas.TabPages.Cast<TabPage>().Select(p => p.Text).SequenceEqual(
                new[] { "Lista de insumos del presupuesto", "Lista de insumos del proyecto" }),
            "La lista debe presentar arriba las dos pestañas de presupuesto y proyecto con los textos de la referencia.");
        exige(new[] { "COD", "DESC", "PROVEEDOR", "CANT", "PRECIO", "TOTAL" }.All(tabla.Columns.Contains) &&
                tabla.Columns["COD"].HeaderText == "Cod." && tabla.Columns["DESC"].HeaderText == "Descripción" &&
                tabla.Columns["PROVEEDOR"].HeaderText == "Proveedor" && tabla.Columns["CANT"].HeaderText == "Cantidad" &&
                tabla.Columns["PRECIO"].HeaderText == "Precio Unit." && tabla.Columns["TOTAL"].HeaderText == "Total",
            "La tabla contextual debe conservar código, descripción, proveedor, cantidad, precio unitario y total como en la referencia.");
        exige(tabla.Rows.Count > 0 && Equals(tabla.Rows[0].Tag, "filtros") &&
                tabla.Rows.Cast<DataGridViewRow>().Where(f => f.Tag is MYGInsumoContexto).All(f => f.ReadOnly),
            "La tabla debe incluir la fila de filtros y proteger de edición los insumos calculados.");
        VerificarFilas(new[] { "L01", "M01", "E01" }, 144m,
            "El presupuesto debe listar sus insumos utilizados y excluir los del otro presupuesto y las entradas sin uso.");
        exige(Control<Label>(panel, "insumos_contexto_presupuesto").Text.Contains(presupuesto.Nombre, StringComparison.Ordinal) &&
                Control<Label>(panel, "insumos_contexto_total").Text.Contains(MYGFormatoPresupuesto.Dinero(144m), StringComparison.Ordinal),
            "La cabecera debe identificar el presupuesto y el pie debe mostrar el total de sus insumos.");
        foreach (string nombre in new[] { "informacion", "copiar", "excel", "imprimir" })
        {
            var boton = Control<Button>(panel, "insumos_contexto_" + nombre);
            exige(boton.Visible && boton.Image != null && !string.IsNullOrWhiteSpace(boton.AccessibleName),
                $"La herramienta {nombre} debe estar visible, tener su icono y un nombre accesible.");
        }
        VerificarImpresion(new[] { "L01", "M01", "E01" }, 144m);

        Seleccionar(titulo);
        exige(contexto.Visible && !detalle.Visible &&
                Control<Label>(panel, "insumos_contexto_seleccion").Text.Contains(titulo.Descripcion, StringComparison.Ordinal),
            "Seleccionar un título debe mostrar su contexto en la cabecera y ocultar todo el detalle de partidas.");
        VerificarFilas(new[] { "L01", "M01" }, 120m,
            "El título debe incluir sus descendientes directos y anidados, excluyendo las partidas de otros títulos.");
        exige(Filas().All(i => i.Grupo != MYGGrupoRecurso.Subcontratos) &&
                MYGMotorPresupuestos.TotalPartida(presupuesto, precioDirecto) == 60m,
            "Las partidas sin ACU o con precio directo deben conservar su importe sin convertirse en subcontratos de la lista de insumos.");
        var manoObra = Filas().Single(i => i.Codigo == "L01");
        exige(manoObra.Cantidad == 10m && manoObra.Total == 100m,
            "Los insumos compartidos por dos partidas del título deben aparecer consolidados con su metrado y total correctos.");
        VerificarImpresion(new[] { "L01", "M01" }, 120m, seleccion: titulo.Descripcion);

        pestanas.SelectedIndex = 1;
        Application.DoEvents();
        VerificarFilas(new[] { "L01", "M01", "E01", "P02" }, 214m,
            "La pestaña del proyecto debe reunir ambos presupuestos aunque la selección activa sea un título.");
        VerificarImpresion(new[] { "L01", "M01", "E01", "P02" }, 214m, proyectoCompleto: true);
        pestanas.SelectedIndex = 0;
        Application.DoEvents();
        VerificarFilas(new[] { "L01", "M01" }, 120m,
            "Volver a la pestaña del presupuesto debe recuperar el alcance del título seleccionado.");

        tabla.CurrentCell = tabla.Rows[0].Cells["COD"];
        tabla.Focus();
        tabla.BeginEdit(false);
        var editorFiltro = tabla.EditingControl as TextBox;
        exige(editorFiltro != null && tabla.IsCurrentCellInEditMode && panel.EditandoTexto,
            "La fila superior debe permitir escribir un filtro mediante el editor real de la tabla y reconocer la edición de texto activa.");
        editorFiltro.Text = "l01";
        panel.Refrescar();
        Application.DoEvents();
        exige(tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.EditingControl, editorFiltro) && editorFiltro.Text == "l01",
            "Refrescar el presupuesto mientras se escribe un filtro debe conservar el editor y su texto sin confirmar.");
        bool oscuroInicial = MYG2027_TemaComercial.Oscuro;
        try
        {
            MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos();
            Application.DoEvents();
            exige(tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.EditingControl, editorFiltro) &&
                    editorFiltro.Text == "l01" && panel.EditandoTexto,
                "Cambiar de tema durante la edición del filtro debe conservar su borrador y reconocer que se sigue escribiendo.");
            exige(tabla.Rows[0].Cells.Cast<DataGridViewCell>().All(c =>
                    c.InheritedStyle.BackColor.ToArgb() == MYG2027_TemaComercial.SuperficieAlterna.ToArgb()),
                "La fila de filtros debe adoptar el fondo alterno del nuevo tema sin reconstruir el editor activo.");
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroInicial) MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos();
            Application.DoEvents();
        }
        panel.MostrarInsumos();
        Application.DoEvents();
        exige(!tabla.IsCurrentCellInEditMode && !principal.Visible &&
                Control<Panel>(panel, "presupuesto_vista_catalogo_insumos").Visible,
            "Cambiar de vista debe confirmar el filtro pendiente antes de ocultar su editor.");
        Seleccionar(titulo);
        VerificarFilas(new[] { "L01" }, 100m,
            "Volver desde el catálogo debe conservar el filtro confirmado en minúsculas y mostrar únicamente sus insumos coincidentes.");
        var reporteFiltrado = (MYGHojaReporteProyecto)typeof(MYGPanelPresupuesto)
            .GetMethod("CrearReporteInsumosContexto", Privados).Invoke(panel, null);
        var contenidoReporte = reporteFiltrado.Hoja.Celdas.Values.Select(c => c.Contenido).ToArray();
        exige(contenidoReporte.Contains("L01") && !contenidoReporte.Contains("M01") && !contenidoReporte.Contains("P02"),
            "El informe usado por Excel y copiar debe respetar los filtros de la lista sin incluir otros insumos.");
        exige(!reporteFiltrado.EsListaInsumos && reporteFiltrado.Hoja.Celdas["C1"].Contenido == "Proveedor" &&
                reporteFiltrado.Hoja.Celdas["E1"].Contenido == "Precio Unit." && reporteFiltrado.Hoja.OrientacionPagina == "Horizontal",
            "Cambiar el formato de impresión no debe alterar las columnas ni la orientación del informe de Excel y copiar.");
        Filtrar("COD", "");
        tabla.CurrentCell = tabla.Rows[0].Cells["COD"];
        tabla.Focus(); tabla.BeginEdit(false);
        ((TextBox)tabla.EditingControl).Text = "l01";
        VerificarImpresion(new[] { "L01" }, 100m, seleccion: titulo.Descripcion);
        exige(!tabla.IsCurrentCellInEditMode,
            "Imprimir debe confirmar el filtro que todavía se está escribiendo antes de generar el informe.");
        Filtrar("COD", "");
        var grupo = tabla.Rows.Cast<DataGridViewRow>().Single(f => f.Tag is MYGGrupoRecurso.ManoObra);
        PulsarGrupo(grupo);
        exige(Filas().All(i => i.Grupo != MYGGrupoRecurso.ManoObra) && Filas().Any(i => i.Codigo == "M01"),
            "Pulsar el título de Mano de obra debe contraer sus insumos sin ocultar los otros grupos.");
        VerificarImpresion(new[] { "L01", "M01" }, 120m, seleccion: titulo.Descripcion, desdeMenu: true);
        exige(Filas().All(i => i.Grupo != MYGGrupoRecurso.ManoObra),
            "Imprimir los insumos de un grupo contraído debe conservar su estado en pantalla.");
        grupo = tabla.Rows.Cast<DataGridViewRow>().Single(f => f.Tag is MYGGrupoRecurso.ManoObra);
        PulsarGrupo(grupo);
        VerificarFilas(new[] { "L01", "M01" }, 120m,
            "Pulsar nuevamente el grupo debe recuperar sus insumos y sus importes.");

        Seleccionar(primera);
        exige(detalle.Visible && !contexto.Visible && detalle.SelectedTab == paginaExcel && hoja.Visible &&
                Equals(hoja.Rows[15].Cells["G"].Value, valorExcel) &&
                especificacion.Documento.Text == textoEspecificacion &&
                rendimiento.Value == rendimientoInicial && jornada.Value == jornadaInicial,
            "Volver a la partida debe recuperar su pestaña elegida, hoja, especificación y valores del ACU.");
        Seleccionar(otroPresupuesto);
        exige(activo == otroPresupuesto && contexto.Visible && !detalle.Visible,
            "Seleccionar otro presupuesto debe activar su propia lista contextual en lugar del ACU.");
        VerificarFilas(new[] { "P02" }, 70m,
            "Cambiar de presupuesto debe descartar los insumos de la selección anterior.");
        VerificarImpresion(new[] { "P02" }, 70m);
        Seleccionar(subtitulo);
        VerificarFilas(new[] { "L01", "M01" }, 80m,
            "Seleccionar un subtítulo debe limitar los insumos a su única partida descendiente.");
        Seleccionar(primera);
        exige(MYGProyectoStorage.Firma(proyecto) == firma && (antes, cambios, guardados) == contadores,
            "Navegar entre partidas, títulos, presupuestos y alcances, filtrar, contraer y preparar el informe no debe modificar datos ni crear historial o guardados.");
        formulario.Close();

        void Seleccionar(object nodo)
        {
            panel.SeleccionarEstructura(nodo);
            Application.DoEvents();
            exige(principal.Visible && principal.Bounds == vistas.ClientRectangle,
                "Seleccionar un título, presupuesto o partida debe conservar la vista principal completa sin restaurar la barra inferior.");
        }

        MYGInsumoContexto[] Filas() => tabla.Rows.Cast<DataGridViewRow>()
            .Where(f => f.Visible).Select(f => f.Tag).OfType<MYGInsumoContexto>().ToArray();

        void VerificarFilas(string[] codigos, decimal total, string mensaje)
        {
            var filas = Filas();
            exige(filas.Select(i => i.Codigo).OrderBy(c => c, StringComparer.Ordinal)
                    .SequenceEqual(codigos.OrderBy(c => c, StringComparer.Ordinal)) && filas.Sum(i => i.Total) == total, mensaje);
        }

        void Filtrar(string columna, string texto)
        {
            var fila = tabla.Rows.Cast<DataGridViewRow>().Single(f => Equals(f.Tag, "filtros"));
            fila.Cells[columna].Value = texto;
            typeof(DataGridView).GetMethod("OnCellEndEdit", Privados).Invoke(tabla,
                new object[] { new DataGridViewCellEventArgs(tabla.Columns[columna].Index, fila.Index) });
            Application.DoEvents();
        }

        void PulsarGrupo(DataGridViewRow fila)
        {
            typeof(DataGridView).GetMethod("OnCellClick", Privados).Invoke(tabla,
                new object[] { new DataGridViewCellEventArgs(tabla.Columns["DESC"].Index, fila.Index) });
            Application.DoEvents();
        }

        void VerificarImpresion(string[] codigos, decimal total, bool proyectoCompleto = false,
            string seleccion = null, bool desdeMenu = false)
        {
            string firmaAntes = MYGProyectoStorage.Firma(proyecto);
            var historialAntes = (antes, cambios, guardados);
            MostrarVistaImpresion(() =>
            {
                if (!desdeMenu) Control<Button>(panel, "insumos_contexto_imprimir").PerformClick();
                else
                {
                    var menu = tabla.ContextMenuStrip;
                    menu.Show(tabla, new Point(8, 8)); Application.DoEvents();
                    menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Text == "Vista previa e impresión").PerformClick();
                    menu.Close();
                }
            }, vista =>
            {
                var reporte = vista.Configuracion.Reportes.Single();
                var h = reporte.Hoja;
                exige(reporte.EsListaInsumos && reporte.UsaFormatoPresupuesto &&
                        h.TamanoPapel == "A4" && h.OrientacionPagina == "Vertical",
                    "El botón y el menú de impresión deben abrir el formato institucional de insumos en A4 vertical.");
                string[] encabezados = { "Código", "Descripción", "Unid.", "Cantidad", "Costo", "Total" };
                exige(Enumerable.Range(1, h.Filas).Any(f => Enumerable.Range(1, 6)
                        .Select(c => h.Celdas.GetValueOrDefault(MYGHojaCalculo.Columna(c) + f)?.Contenido ?? "")
                        .SequenceEqual(encabezados)),
                    "La impresión debe separar unidad, cantidad y costo con las seis columnas de la referencia.");
                string[] todos = { "L01", "M01", "E01", "P02" };
                var filas = h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == 1 && todos.Contains(c.Value.Contenido))
                    .ToDictionary(c => c.Value.Contenido, c => MYGHojaCalculo.Coordenadas(c.Key).Fila);
                exige(filas.Keys.OrderBy(c => c).SequenceEqual(codigos.OrderBy(c => c)) &&
                        new MYGHojaCalculo(h).Numero(h.CeldaTotal) == total,
                    "El informe abierto debe conservar exactamente los insumos y el total del presupuesto, título, proyecto o filtro seleccionados.");
                var unidades = new Dictionary<string, string> { ["L01"] = "hh", ["M01"] = "bls", ["E01"] = "hm", ["P02"] = "gal" };
                exige(filas.All(f => h.Celdas["C" + f.Value].Contenido == unidades[f.Key] &&
                        new MYGHojaCalculo(h).Numero("D" + f.Value) > 0),
                    "Las unidades del catálogo deben imprimirse en su columna y las cantidades deben seguir siendo numéricas.");
                exige(reporte.CabeceraImpresion.Any(d => d.Key == "PROYECTO" && d.Value.Contains(proyecto.Nombre, StringComparison.Ordinal)) &&
                        reporte.CabeceraImpresion.Any(d => d.Key == "PROPIETARIO" && d.Value == proyecto.Datos.Propietario) &&
                        reporte.CabeceraImpresion.Any(d => d.Key == "FECHA DE PROY." && d.Value.Contains("2026", StringComparison.Ordinal)),
                    "La vista debe usar el proyecto, propietario y fecha reales en su cabecera de impresión.");
                exige(proyectoCompleto
                        ? reporte.CabeceraImpresion.All(d => d.Key is not ("PRESUPUESTO" or "TÍTULO"))
                        : reporte.CabeceraImpresion.Any(d => d.Key == "PRESUPUESTO" && d.Value.Contains(activo.Nombre, StringComparison.Ordinal)) &&
                            (seleccion == null ? reporte.CabeceraImpresion.All(d => d.Key != "TÍTULO")
                                : reporte.CabeceraImpresion.Any(d => d.Key == "TÍTULO" && d.Value.Contains(seleccion, StringComparison.Ordinal))),
                    "La cabecera debe identificar el presupuesto y título actuales, y usar el alcance completo al imprimir el proyecto.");
                h.Poner("A1", "CAMBIO AISLADO DE VISTA PREVIA");
                vista.Configuracion.ConfigurarPagina("A3", "Horizontal", .5m, .5m, .5m, .5m);
            }, exige);
            exige(MYGProyectoStorage.Firma(proyecto) == firmaAntes && (antes, cambios, guardados) == historialAntes,
                "Abrir, configurar y cerrar la vista previa de insumos no debe cambiar el proyecto ni su historial ni guardarlo.");
        }
    }

    private static void MostrarVistaImpresion(Action abrir, Action<MYGVistaPreliminarReportesForm> verificar,
        Action<bool, string> exige)
    {
        bool mostrado = false;
        string error = null;
        var plazo = System.Diagnostics.Stopwatch.StartNew();
        using var temporizador = new System.Windows.Forms.Timer { Interval = 40 };
        temporizador.Tick += (_, _) =>
        {
            if (plazo.Elapsed > TimeSpan.FromSeconds(15))
            {
                Console.Error.WriteLine("La vista previa de insumos quedó bloqueada en un diálogo inesperado.");
                Environment.Exit(1); return;
            }
            if (mostrado) return;
            var vista = Application.OpenForms.OfType<MYGVistaPreliminarReportesForm>().FirstOrDefault();
            if (vista == null) return;
            mostrado = true;
            try { verificar(vista); }
            catch (Exception ex) { error = ex.ToString(); }
            finally { vista.Close(); }
        };
        temporizador.Start();
        abrir(); Application.DoEvents();
        temporizador.Stop();
        exige(mostrado && error == null, error ?? "La acción no abrió la vista previa real de insumos.");
    }

    private static MYGInsumo Insumo(string codigo, string descripcion, string unidad, MYGGrupoRecurso grupo, decimal precio) =>
        new() { Codigo = codigo, Descripcion = descripcion, Unidad = unidad, Grupo = grupo, Precio = precio, Proveedor = "PROVEEDOR DE PRUEBA" };

    private static ItemPresupuestoDelphin Item(string item, string descripcion, string padre, bool titulo, int posicion)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Item = item, Descripcion = descripcion,
            ParentId = padre, TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Unidad = titulo ? "" : "m³",
            Origen = "MODELO", Estado = "PROPUESTA", Posicion = posicion, Costos = new MYGDatosPartida()
        };
    }

    private static void Agregar(ItemPresupuestoDelphin partida, MYGInsumo insumo, decimal cantidad) =>
        partida.Costos.Analisis.Add(new MYGRecursoACU
            { Grupo = insumo.Grupo, InsumoId = insumo.Id, Modo = MYGModoCantidad.Directa, Cantidad = cantidad });

    private static T Control<T>(Control padre, string nombre) where T : Control =>
        Controles(padre).OfType<T>().Single(c => c.Name == nombre);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
