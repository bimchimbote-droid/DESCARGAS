#!/usr/bin/env python3
"""Regenera los iconos originales de MYG. Requiere Python 3 y Pillow solo para esta tarea."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

DESTINO = Path(__file__).resolve().parents[1] / "MYG.Desktop" / "Iconos"
ESCALA = 4
AZUL = "#2f68ae"
CELESTE = "#a4c7ed"
BLANCO = "#ffffff"
VERDE = "#6f9e3e"
ROJO = "#d45c64"
AMARILLO = "#ecb342"
GRIS = "#667789"


def generar(nombre):
    imagen = Image.new("RGBA", (32 * ESCALA, 32 * ESCALA), (0, 0, 0, 0))
    dibujo = ImageDraw.Draw(imagen)

    def caja(xy, relleno, linea=None, radio=0, ancho=1.6):
        coordenadas = tuple(round(x * ESCALA) for x in xy)
        if radio:
            dibujo.rounded_rectangle(coordenadas, radius=round(radio * ESCALA), fill=relleno,
                                      outline=linea, width=round(ancho * ESCALA))
        else:
            dibujo.rectangle(coordenadas, fill=relleno, outline=linea, width=round(ancho * ESCALA))

    def linea(puntos, color=AZUL, ancho=2):
        dibujo.line([(round(x * ESCALA), round(y * ESCALA)) for x, y in puntos],
                     fill=color, width=round(ancho * ESCALA), joint="curve")

    def poligono(puntos, color=AZUL):
        dibujo.polygon([(round(x * ESCALA), round(y * ESCALA)) for x, y in puntos], fill=color)

    def circulo(xy, relleno, contorno=None, ancho=1.6):
        dibujo.ellipse(tuple(round(x * ESCALA) for x in xy), fill=relleno,
                       outline=contorno, width=round(ancho * ESCALA))

    def texto(valor, x, y, tam=11, color=AZUL):
        fuente = ImageFont.load_default(size=round(tam * ESCALA))
        dibujo.text((round(x * ESCALA), round(y * ESCALA)), valor, fill=color, font=fuente)

    def documento():
        caja((6, 3, 24, 29), BLANCO, AZUL, radio=2)
        for y in (10, 15, 20):
            linea(((10, y), (20, y)), CELESTE, 1.5)

    def signo_mas(x=23, y=23):
        circulo((x - 7, y - 7, x + 7, y + 7), VERDE)
        linea(((x - 4, y), (x + 4, y)), BLANCO, 2)
        linea(((x, y - 4), (x, y + 4)), BLANCO, 2)

    if nombre == "guardar":
        poligono(((4, 3), (24, 3), (29, 8), (29, 29), (4, 29)))
        caja((9, 4, 22, 12), BLANCO)
        caja((19, 5, 21, 10), CELESTE)
        caja((9, 19, 24, 28), BLANCO, radio=1)
        linea(((12, 23), (21, 23)), AZUL, 1.4)
    elif nombre in ("agregar", "aceptar", "cerrar", "eliminar"):
        color = ROJO if nombre in ("cerrar", "eliminar") else VERDE
        if nombre == "eliminar":
            caja((8, 9, 24, 28), color, radio=2)
            linea(((6, 7), (26, 7)), color, 3)
            linea(((12, 4), (20, 4)), color, 3)
            for x in (12, 16, 20):
                linea(((x, 13), (x, 24)), BLANCO, 1.3)
        elif nombre == "agregar":
            signo_mas(16, 16)
        elif nombre == "aceptar":
            linea(((4, 16), (12, 24), (28, 7)), color, 4)
        else:
            linea(((7, 7), (25, 25)), color, 4)
            linea(((25, 7), (7, 25)), color, 4)
    elif nombre in ("arriba", "abajo"):
        puntos = [(16, 3), (3, 16), (10, 16), (10, 29), (22, 29), (22, 16), (29, 16)]
        if nombre == "abajo":
            puntos = [(x, 32 - y) for x, y in puntos]
        poligono(puntos)
    elif nombre in ("expandir", "contraer"):
        caja((9, 9, 29, 29), None, CELESTE, radio=1)
        caja((3, 3, 24, 24), BLANCO, AZUL, radio=2)
        linea(((7, 13), (20, 13)), AZUL, 2)
        if nombre == "expandir":
            linea(((13.5, 7), (13.5, 20)), AZUL, 2)
    elif nombre in ("insertar_sobre", "insertar_final"):
        caja((3, 4, 18, 28), BLANCO, AZUL, radio=1)
        for y in (9, 15, 21):
            caja((5, y - 2, 16, y + 2), CELESTE)
        y = 9 if nombre == "insertar_sobre" else 24
        linea(((20, y), (28, y)), VERDE, 2)
        linea(((24, y - 4), (24, y + 4)), VERDE, 2)
        poligono(((20, y - 5), (20, y + 5), (15, y)), VERDE)
    elif nombre in ("editar", "especificacion"):
        if nombre == "especificacion":
            documento()
        poligono(((5, 23), (21, 7), (27, 13), (11, 29)), AMARILLO)
        poligono(((21, 7), (24, 4), (30, 10), (27, 13)), ROJO)
        poligono(((5, 23), (11, 29), (3, 31)), GRIS)
        linea(((9, 24), (24, 9)), "#ffe0a0", 1.5)
    elif nombre == "buscar":
        circulo((3, 3, 23, 23), "#e8f3ff", AZUL, 2.5)
        linea(((21, 21), (29, 29)), AZUL, 4)
        linea(((7, 12), (8, 8), (12, 7)), BLANCO, 2)
    elif nombre == "codigo_estandar":
        documento()
        caja((2, 4, 16, 14), AMARILLO, radio=1)
        texto("01", 4, 3, 10, BLANCO)
        linea(((10, 25), (20, 25)), AZUL, 1.5)
    elif nombre == "codigo_alterno":
        caja((2, 7, 30, 25), "#fff2c9", AMARILLO, radio=3)
        poligono(((3, 16), (9, 10), (16, 8), (23, 10), (29, 16), (23, 22), (16, 24), (9, 22)), CELESTE)
        circulo((11, 11, 21, 21), BLANCO, AZUL)
        circulo((14, 14, 18, 18), AZUL)
    elif nombre in ("recalcular", "acu", "resumen"):
        caja((6, 2, 26, 30), BLANCO, AZUL, radio=2)
        caja((9, 5, 23, 11), CELESTE)
        for y in (15, 21, 26):
            for x in (10, 16, 22):
                caja((x - 1.8, y - 1.8, x + 1.8, y + 1.8), AMARILLO if x == 22 else AZUL, radio=0.4)
        if nombre == "resumen":
            caja((1, 13, 16, 31), BLANCO)
            texto("S", 3, 12, 17, AMARILLO)
        elif nombre == "recalcular":
            linea(((1, 13), (1, 5), (4, 2), (10, 2)), VERDE, 2)
            poligono(((7, 0), (12, 2), (7, 5)), VERDE)
    elif nombre == "excel":
        caja((10, 4, 29, 28), BLANCO, VERDE, radio=1)
        for y in (10, 15, 20):
            linea(((13, y), (27, y)), VERDE, 1)
        for x in (18, 23):
            linea(((x, 7), (x, 24)), VERDE, 1)
        caja((2, 10, 18, 24), VERDE, radio=1)
        texto("X", 5, 9, 13, BLANCO)
    elif nombre == "imprimir":
        caja((8, 2, 24, 14), BLANCO, AZUL)
        caja((3, 10, 29, 24), AZUL, radio=3)
        circulo((24, 13, 26, 15), VERDE)
        caja((8, 18, 24, 30), BLANCO, AZUL)
        for y in (22, 26):
            linea(((11, y), (21, y)), CELESTE, 1.5)
    elif nombre in ("titulo", "partida", "proyecto"):
        if nombre == "proyecto":
            caja((5, 5, 22, 29), CELESTE, AZUL)
            caja((20, 13, 28, 29), BLANCO, AZUL)
            for x in (10, 16):
                for y in (10, 16, 22):
                    caja((x, y, x + 2, y + 2), AZUL)
        else:
            documento()
            if nombre == "titulo":
                texto("T", 9, 8, 15, AZUL)
            else:
                signo_mas()
    elif nombre == "catalogo":
        for x, color in ((3, AZUL), (12, VERDE), (21, AMARILLO)):
            caja((x, 4, x + 7, 28), color, radio=1)
            linea(((x + 2, 8), (x + 5, 8)), BLANCO, 1.4)
            linea(((x + 2, 23), (x + 5, 23)), BLANCO, 1.4)
    elif nombre in ("insumos", "bim"):
        poligono(((16, 2), (29, 9), (16, 16), (3, 9)), AMARILLO if nombre == "insumos" else "#e56561")
        poligono(((3, 10), (15, 17), (15, 30), (3, 23)), CELESTE)
        poligono(((17, 17), (29, 10), (29, 23), (17, 30)), AZUL)
    elif nombre == "unidades":
        poligono(((2, 23), (24, 2), (30, 8), (8, 30)), AMARILLO)
        for i in range(5):
            linea(((7 + 4 * i, 22 - 4 * i), (10 + 4 * i, 25 - 4 * i)), AZUL, 1.5)
    elif nombre in ("deshacer", "rehacer"):
        puntos = [(4, 10), (14, 2), (14, 7), (20, 7), (26, 10), (29, 15), (29, 26), (23, 26), (23, 16), (20, 13), (14, 13), (14, 18)]
        if nombre == "rehacer":
            puntos = [(32 - x, y) for x, y in puntos]
        poligono(puntos)
    elif nombre == "sesion":
        circulo((10, 2, 22, 14), CELESTE, AZUL)
        caja((5, 17, 27, 30), AZUL, radio=8)
        circulo((20, 19, 31, 30), VERDE)
        linea(((23, 24), (25, 26), (29, 22)), BLANCO, 1.5)
    elif nombre == "imagen":
        caja((2, 5, 30, 28), BLANCO, AZUL, radio=2)
        circulo((20, 9, 25, 14), AMARILLO)
        poligono(((5, 25), (12, 14), (19, 25)), VERDE)
        poligono(((14, 25), (22, 17), (28, 25)), CELESTE)
    elif nombre == "marca":
        poligono(((2, 5), (20, 5), (30, 16), (20, 27), (2, 27)), CELESTE)
        circulo((22, 13, 28, 19), BLANCO, AZUL)
        linea(((7, 12), (16, 12)), AZUL)
        linea(((7, 19), (16, 19)), AZUL)
    else:
        raise ValueError(nombre)
    imagen.resize((32, 32), Image.Resampling.LANCZOS).save(DESTINO / (nombre + ".png"), optimize=True)


if __name__ == "__main__":
    DESTINO.mkdir(parents=True, exist_ok=True)
    nombres = ("guardar agregar titulo partida catalogo editar eliminar proyecto excel imprimir resumen insumos "
               "unidades especificacion deshacer rehacer bim sesion arriba abajo expandir contraer insertar_sobre "
               "insertar_final recalcular codigo_estandar codigo_alterno buscar aceptar cerrar acu imagen marca").split()
    for nombre in nombres:
        generar(nombre)
    print(f"{len(nombres)} iconos PNG transparentes (32 x 32) guardados en {DESTINO}")
