param([string]$Origen = "")
$ErrorActionPreference = 'Stop'
if (Get-Process -Name Revit -ErrorAction SilentlyContinue) {
    throw 'Cierre Revit antes de instalar o actualizar el conector MYG.'
}
$raiz = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($Origen)) {
    foreach($candidato in @((Join-Path $raiz 'Conector'), (Join-Path $raiz 'dist\Conector'), (Join-Path $raiz 'MYG.Revit2027\bin\Release\net10.0-windows'))) {
        if(Test-Path (Join-Path $candidato 'MYG.Revit2027.dll')) { $Origen=$candidato; break }
    }
    if([string]::IsNullOrWhiteSpace($Origen)) { throw 'Primero compile MYG.Revit2027 en Release o ejecute Publicar.ps1.' }
}
$Origen = (Resolve-Path $Origen).Path
foreach ($dll in @('MYG.Revit2027.dll', 'MYG.Core.dll')) {
    if (!(Test-Path (Join-Path $Origen $dll))) { throw "Falta $dll. Primero compile MYG.Revit2027 en Release." }
}
$addins = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2027'
$destino = Join-Path $addins 'MYG_Externo'
New-Item -ItemType Directory -Force -Path $destino | Out-Null
Get-ChildItem $Origen -File | Where-Object { $_.Name -notin @('RevitAPI.dll', 'RevitAPIUI.dll') } |
    Copy-Item -Destination $destino -Force
if (Test-Path (Join-Path $Origen 'runtimes')) {
    Copy-Item (Join-Path $Origen 'runtimes') -Destination $destino -Recurse -Force
}
# Revit suministra sus propias API. Nunca instalar copias de referencia en la carpeta del conector.
foreach ($api in @('RevitAPI.dll', 'RevitAPIUI.dll')) {
    $copia = Join-Path $destino $api
    if (Test-Path $copia) { Remove-Item $copia -Force }
}
$assembly = [System.Security.SecurityElement]::Escape((Join-Path $destino 'MYG.Revit2027.dll'))
$manifest = @"
<?xml version="1.0" encoding="utf-8"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>MYG Presupuestos - Conector Revit</Name>
    <Assembly>$assembly</Assembly>
    <AddInId>F8045AE4-B3D5-49D5-9546-53024F94A289</AddInId>
    <FullClassName>MYG.Conector.Aplicacion</FullClassName>
    <VendorId>MYGB</VendorId>
    <VendorDescription>MYG Presupuestos</VendorDescription>
  </AddIn>
</RevitAddIns>
"@
$archivo = Join-Path $addins 'MYG_Conector_Externo.addin'
[System.IO.File]::WriteAllText($archivo, $manifest, [System.Text.UTF8Encoding]::new($false))
Write-Host "Conector instalado: $archivo"
Write-Host 'Abra Revit 2027, abra un modelo y pulse Buscar Revit en MYG Presupuestos.'
