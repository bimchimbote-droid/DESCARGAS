$ErrorActionPreference = 'Stop'
if (Get-Process -Name Revit -ErrorAction SilentlyContinue) { throw 'Cierre Revit antes de desinstalar el conector MYG.' }
$addins = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2027'
$manifest = Join-Path $addins 'MYG_Conector_Externo.addin'
$carpeta = Join-Path $addins 'MYG_Externo'
if (Test-Path $manifest) { Remove-Item $manifest -Force }
if (Test-Path $carpeta) { Remove-Item $carpeta -Recurse -Force }
Write-Host 'Conector Revit de MYG Presupuestos desinstalado. Los proyectos, filtros y el add-in anterior permanecen disponibles.'
