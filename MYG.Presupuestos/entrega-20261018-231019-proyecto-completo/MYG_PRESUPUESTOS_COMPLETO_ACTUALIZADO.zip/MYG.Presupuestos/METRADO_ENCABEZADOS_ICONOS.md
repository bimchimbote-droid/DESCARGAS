# Metrado: iconos, encabezados y selección

Aplicar sobre la entrega anterior de formato/zoom/fórmulas (DESCARGAS bc4cf32c7b8d6b688614baeb72e6180cca13c8db). Base del código: main, 0845f78825ab633e6e0729144817297c25af9130.

## Correcciones

- Los iconos de la cinta se generan al tamaño físico del monitor y del rectángulo donde se dibujan, con texto suavizado y transparencia. Se evita ampliar una imagen fija de 18 píxeles. La cinta compartida de Word y los iconos propios XLS conservan sus paletas, estados y alto contraste.
- Las letras A, B, C y los números 1, 2, 3 se dibujan centrados horizontal y verticalmente, manteniendo Segoe UI 9.
- La primera fila combina Datos en A1:C1, Dimensiones en D1:F1 y Total en G1:H1. Se restauran estos grupos en hojas antiguas reconocidas como la plantilla de metrado.
- Un clic sobre C selecciona C1 hasta la última fila. Un clic sobre 2 selecciona toda la fila 2. Mayús extiende el intervalo de encabezados y Ctrl permite agregar selecciones. La dirección refleja el rango seleccionado sin modificar el metrado.

La reparación automática de combinaciones preserva el contenido y las combinaciones personalizadas. Si hay texto en una celda secundaria o una combinación que cruza grupos, no se impone la reparación que lo ocultaría. La reparación repetida no duplica rangos.

## Instalación

1. Cerrar MYG y respaldar o confirmar los cambios locales.
2. Extraer el ZIP sobre la raíz del proyecto, conservando las rutas.
3. Reemplazar los siete C# existentes incluidos, crear PresupuestosExcelSeleccion.cs y este documento, y conservar todos los otros archivos de las entregas anteriores.
4. Si hay cambios propios en los archivos completos, combinarlos antes de reemplazar.
5. Abrir el proyecto y compilar. No hay eliminaciones, parches, paquetes nuevos ni migraciones manuales de SQLite.

## Compilación y validación

Con .NET SDK 10.0.100, desde la raíz:

    dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
    dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
    dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore

En Windows:

    dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release

La solución completa se compiló sin errores ni advertencias. Se ejecutaron 220 comprobaciones aprobadas, incluidas la reparación de cabeceras antiguas, protección de datos y conservación de las combinaciones en XLSX. Named Pipes se omite explícitamente en Linux.
Las pruebas de interfaz se compilaron pero no se ejecutaron en Linux. Incluyen encabezados centrados, combinación dibujada, clics de fila y columna, selección ampliada, tamaños de iconos y ambos temas.

## Revisión manual

En Windows, comprobar la nitidez en claro/oscuro y a 100%, 125% y 150% de escala; abrir una hoja antigua de metrado y revisar los tres grupos; seleccionar C y 2 desde sus encabezados y confirmar el rango en el cuadro de dirección. Guardar/reabrir una copia del proyecto e intercambiar XLSX.
La validación visual en Windows queda pendiente; la compilación no la sustituye.

## GitHub

El ZIP se publica en una carpeta nueva de DESCARGAS sin sobrescribir entregas anteriores. No se hace commit ni push al repositorio del código.
Después de instalar y revisar, hacer Commit y Push manualmente desde Cambios de Git de Visual Studio y verificar la rama de trabajo.
