# Guardar y editar MYG Presupuestos en Visual Studio

El código fuente está preparado para colocarse en `D:\ADDIN\repos\MYG.Presupuestos`, junto a sus otras aplicaciones. El archivo de entrada es `MYG.Presupuestos.sln`. La solución utiliza rutas relativas para sus proyectos.

## 1. Colocar el proyecto en su carpeta de repositorios

1. Descargue `MYG_Codigo_SQLite.zip`.
2. Abra el Explorador de archivos y entre en `D:\ADDIN\repos`.
3. Extraiga el ZIP en esa ubicación. El ZIP ya contiene una carpeta principal llamada `MYG.Presupuestos`.
4. Compruebe que existe `D:\ADDIN\repos\MYG.Presupuestos\MYG.Presupuestos.sln`.
5. Mantenga dentro de esa carpeta `MYG.Desktop`, `MYG.Core`, `MYG.Revit2027`, `MYG.Pruebas`, `scripts` y los archivos de configuración incluidos.

Si Windows creó una carpeta adicional con el nombre del ZIP, mueva la carpeta interior `MYG.Presupuestos` a `D:\ADDIN\repos`. Si ya estaba trabajando con el código en otra ubicación, cierre Visual Studio y mueva la carpeta completa de la solución; luego abra la solución desde su ubicación nueva.

El archivo `.sln` organiza los proyectos. Los archivos `.cs` contienen el código. Los `.csproj` contienen la configuración de compilación. El `.exe` es el programa generado al compilar. Para continuar editando debe conservar toda la carpeta fuente.

## 2. Abrir el proyecto

1. Haga doble clic en `MYG.Presupuestos.sln`.
2. Si Windows pide elegir una aplicación, seleccione Visual Studio. También puede abrir Visual Studio y utilizar **Archivo → Abrir → Proyecto o solución**, buscando la ruta indicada.
3. Utilice Visual Studio 2026, versión 18.0 o posterior, con **Desarrollo de escritorio con .NET** y el SDK .NET 10. Los requisitos completos están en `LEEME.md`.
4. Espere la restauración de NuGet. Si hace falta, clic derecho en la solución → **Restaurar paquetes NuGet**.
5. Abra **Ver → Explorador de soluciones** si el panel no está visible.
6. Clic derecho en `MYG.Desktop` → **Establecer como proyecto de inicio**.
7. Seleccione **Release / x64**. Revise la ruta de Revit 2027 en `MYG.Revit2027\MYG.Revit2027.csproj`.
8. Utilice **Compilar → Compilar solución**. Después de una compilación sin errores, pulse el triángulo verde para abrir MYG Presupuestos.

Puede compilar únicamente `MYG.Desktop` con clic derecho → **Compilar** para trabajar con el escritorio sin compilar el conector.

## 3. Volver a editar otro día

1. Abra de nuevo `D:\ADDIN\repos\MYG.Presupuestos\MYG.Presupuestos.sln`.
2. Expanda el proyecto `MYG.Desktop` en el Explorador de soluciones.
3. Haga doble clic en el archivo que desea modificar.
4. Edite su código y seleccione **Archivo → Guardar todo**.
5. Cierre la aplicación MYG que esté ejecutándose. Si se abrió desde Visual Studio, utilice **Depurar → Detener depuración**.
6. Use **Compilar → Compilar solución** y pulse el triángulo verde para comprobar los cambios.

Se utiliza la misma solución cada vez. La interfaz de esta entrega se construye en C#: los textos, controles y posiciones se editan en sus archivos de código.

| Archivo | Qué controla |
| --- | --- |
| `MYG.Desktop\LoginForm.cs` | Ventana de acceso con licencia MYG. |
| `MYG.Desktop\InicioForm.cs` | Crear/abrir SQLite, ventana de proyectos y catálogos compartidos. |
| `MYG.Desktop\DatosProyectoForm.cs` | Ficha de datos del proyecto, ubicación, duración y parámetros de ejecución. |
| `MYG.Desktop\EditorForm.cs` | Editor de presupuestos, títulos, partidas y filtros. |
| `MYG.Desktop\PresupuestosPanel.cs` | Presupuestos, ACU, insumos, metrados y especificaciones. |
| `MYG.Desktop\CatalogosForm.cs`, `UnidadesForm.cs` | Catálogos compartidos y selección de unidades. |
| `MYG.Desktop\DialogosProyecto.cs` | Ventanas de biblioteca, importación y conexión. |
| `MYG.Desktop\Tema.cs` | Colores y apariencia de los controles. |
| `MYG.Desktop\MYG.Desktop.csproj` | Nombre del ejecutable y metadatos del programa. |
| `MYG.Core` | Guardado SQLite, catálogos, cálculos, integración Delphin, biblioteca de filtros y licencia. |
| `MYG.Revit2027` | Conexión y operaciones dentro de Revit 2027. |

## 4. Ejecutar la aplicación compilada

El paquete `MYG_Aplicacion_Windows.zip` permite utilizar el programa ya compilado. Extraiga todo su contenido en otra carpeta y abra `MYG\MYG.Presupuestos.exe`. Mantenga todos los archivos de esa distribución juntos. Esta distribución requiere .NET Desktop Runtime 10 x64.

En una compilación normal realizada en Windows, el ejecutable se genera dentro de `MYG.Desktop\bin\Release\net10.0-windows`. Publicaciones que indican un identificador de ejecución como `win-x64` pueden añadir una subcarpeta. Para desarrollar, el triángulo verde de Visual Studio utiliza automáticamente la salida apropiada.

Después de iniciar sesión, **Crear archivo .sqlite** crea una base vacía con 12 unidades básicas; **Abrir archivo .sqlite** muestra los proyectos y presupuestos de una base existente MYG o Delphin 2024 reconocida. En la ventana principal cree **Nuevo proyecto**, complete su ficha y después cree **Nuevo presupuesto**. Cada proyecto tiene sus datos propios y puede contener varios presupuestos; cada presupuesto pertenece al proyecto en el que se creó. Los catálogos de partidas, insumos y unidades se comparten entre los proyectos de la base; los formularios de nuevas partidas e insumos usan ese catálogo de unidades.

La ficha **Datos del proyecto** registra propietario, portafolio, tipo de obra, ubicación encadenada (departamento, provincia, distrito y localidad), elaboración, duración, inicio y fin calculado con el primer día incluido, calendario, periodos, modalidad de ejecución, método de costos y autor del proyecto, conservado al editar la ficha. Puede editarla con **Datos del proyecto** en la ventana principal o **Proyecto → Datos del proyecto** en el editor. Los botones **+** permiten crear opciones de catálogo. Las hojas nuevas incluyen la referencia geográfica pública de departamentos, provincias y distritos, sin copiar propietarios, usuarios ni localidades privadas de la muestra. La búsqueda de la ventana principal incluye propietario y tipo de obra, y dispone de un filtro por tipo.

El calendario **Predeterminado**, los periodos **Estándar**, las modalidades **Por contrata / Administración directa** y los métodos **Por rendimiento de cuadrilla / Por asignación de recursos** se registran como parámetros del proyecto. Seleccionar estos datos no crea un cronograma ni añade un motor de planificación por asignación. Los metadatos de proyectos nativos existentes se conservan cuando no se modifica su ficha.

El botón **Guardar** dentro de MYG guarda la ficha del proyecto, sus presupuestos y filtros en el mismo archivo `*.sqlite`, sin JSON auxiliar de proyecto. Los datos se conservan en el documento MYG interno y en las columnas nativas correspondientes. Al abrir directamente una base nativa Delphin, el guardado escribe sus tablas nativas y añade datos MYG de versión 3. **Importar presupuesto Delphin** es un flujo aparte que consulta otra base en modo de lectura e incorpora el presupuesto a la base de destino. **Archivo → Guardar todo** en Visual Studio guarda el código que está modificando.

Las lecturas no modifican la base. El guardado sin cambios se comprobó sobre una copia de la muestra Delphin 2024, conservando los datos de sus 198 tablas originales. La apertura del resultado dentro del programa Delphin 2024 sigue pendiente de validación en Windows; una extensión `.sqlite` por sí sola no confirma esa compatibilidad.

## 5. Actualizar el conector cuando cambie su código

Si cambia `MYG.Revit2027` o `MYG.Core`, cierre Revit, compile en Release y abra PowerShell en `D:\ADDIN\repos\MYG.Presupuestos`. Ejecute:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Instalar-Conector.ps1
```

Vuelva a abrir Revit y su modelo. En MYG, abra un proyecto y pulse **Buscar Revit**. El instalador utiliza los mismos archivos de registro y destino del conector anterior para actualizar esa instalación.

Para generar una distribución con el runtime incluido, ejecute `scripts\Publicar.ps1` desde la carpeta de la solución, siguiendo `LEEME.md`.

## 6. Conservar sus cambios

Mantenga una copia de toda la carpeta fuente. Si utiliza Git, cree el repositorio en `D:\ADDIN\repos\MYG.Presupuestos` y confirme los archivos fuente; la configuración incluida excluye las salidas de compilación y los datos de obras con las extensiones indicadas.

Los proyectos, presupuestos y catálogos se guardan en el archivo SQLite elegido dentro de MYG. La biblioteca heredada de filtros mantiene su archivo JSON independiente. Puede almacenarlos en una carpeta de trabajo de la obra separada del código fuente.

La aplicación incluye edición de precios y ACU, metrados, especificaciones y resumen de costos, además de las funciones de filtros y conexión con Revit. Las pruebas de la interfaz y del flujo completo en Windows, Delphin 2024 y Revit 2027 se detallan en `VERIFICACION.md`.
