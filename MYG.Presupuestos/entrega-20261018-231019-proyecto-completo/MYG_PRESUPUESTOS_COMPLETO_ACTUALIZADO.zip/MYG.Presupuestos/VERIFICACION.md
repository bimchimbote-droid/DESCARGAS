# Verificación de MYG Presupuestos

## Flujo SQLite con varios proyectos (7 de octubre de 2026)

- Compilación completa Release con SDK .NET 10.0.100 y paquetes de referencia Revit: **0 errores y 0 advertencias**.
- Suite actual: **92 comprobaciones correctas**: 88 con datos sintéticos y 4 con la muestra nativa `PODER JUDICIAL 1.sqlite`. Incluye creación de una base vacía con doce unidades básicas, varios proyectos/presupuestos en un archivo, guardado aislado de cada obra, unidades en uso, transacciones y migración MYG v1 al esquema nativo + MYG v3.
- La ficha **Datos del proyecto** registra propietario, portafolio, tipo de obra, ubicación, fechas, duración, calendario, modalidad, método de costos y autor. Sus presupuestos conservan identidades propias dentro de ese proyecto. Las pruebas verifican persistencia en MYG y columnas nativas, jerarquías geográficas, fechas inclusivas, calendarios privados/globales, rechazo de referencias ajenas y conservación de valores heredados nulos.
- Las bases nuevas incorporan departamentos, provincias y distritos de la referencia pública de la muestra. No copian propietarios, usuarios ni localidades privadas. La creación de opciones de catálogo se valida y evita duplicados por nombre y padre.
- Las pruebas verifican SQLite real, `integrity_check` y relaciones con `foreign_key_check`. Las bases nuevas no presentan referencias inválidas. La muestra nativa ya contiene 39 referencias pendientes en `unidad_map` y `perfil_map`; las copias guardadas conservan exactamente esas mismas referencias, sin añadir anomalías. Leer una base existente no modifica su contenido.
- Los formularios permiten crear/abrir `.sqlite`, listar proyectos y administrar los catálogos compartidos; partidas e insumos usan un selector de unidades. Estos cambios compilaron, pero su ejecución visual necesita Windows.
- Se extrajo el esquema de las 198 tablas nativas de Delphin 2024, sin datos de obras ni credenciales. Las hojas nuevas guardan proyectos, presupuestos, recursos, ACU, catálogos y unidades en tablas nativas, junto a las extensiones MYG de versión 3.
- La muestra se leyó con sus 3 proyectos y 10 presupuestos. Guardar una copia sin cambios conserva el esquema y todos los datos de las 198 tablas originales; renombrar una obra conserva los demás metadatos y todas las otras obras. La huella SHA-256 del archivo adjunto original permanece intacta.
- Las pruebas de edición verifican que el primer cambio de un ACU importado gestione sólo su árbol exclusivo, retire composiciones antiguas sin duplicarlas y preserve presupuestos vecinos. Las composiciones compartidas del catálogo nativo se conservan al editar metadatos; modificar su ACU exige una copia nueva, y los rechazos revierten la transacción.
- **Falta comprobar la apertura del resultado en el programa Delphin 2024 de Windows.** El esquema y la lectura/escritura SQLite están comprobados; el entorno Linux no permite ejecutar su interfaz ni confirmar sus reglas internas de usuario.
- La prueba de Named Pipes de Windows se omite en Linux. La interfaz, el servicio de licencia real, el instalador y Revit siguen pendientes de prueba en Windows.

Los resultados descritos más abajo corresponden a la entrega anterior.

Fecha: 6 de octubre de 2026.

## Cambios de esta actualización

- Nombre visible: **MYG Presupuestos**, en inicio de sesión, ventana inicial, editor y mensajes.
- Solución editable: `MYG.Presupuestos.sln`. Carpeta fuente: `MYG.Presupuestos`.
- Ejecutable: `MYG.Presupuestos.exe`. Metadatos Product y AssemblyTitle actualizados.
- El nombre de carga del conector es `MYG Presupuestos - Conector Revit`; se mantienen sus archivos de registro y destino para actualizar la instalación anterior.
- Se incluyen instrucciones para guardar la carpeta completa en `D:\ADDIN\repos` y volver a editarla en Visual Studio.

## Comprobado en esta actualización

- Solución completa en Release, .NET SDK 10.0.100: **0 errores y 0 advertencias**.
- Conector compilado con referencias Revit API 2027.0.0. La compilación normal en Windows utiliza las DLL de la instalación local de Revit 2027.
- **53 comprobaciones correctas** de la suite incluida: proyectos JSON, varios presupuestos, filtros, biblioteca, importación de datos antiguos, reconciliación, lectura SQLite, licencia simulada y protocolo. Se utilizaron datos sintéticos; no se accedió al servidor de licencias con credenciales reales.
- Publicación de Windows x64 dependiente de .NET Desktop Runtime 10.
- El ejecutable publicado tiene cabecera PE/MZ, apunta a `MYG.Presupuestos.dll` y contiene el nombre actualizado en sus recursos de versión.
- Todas las referencias relativas de proyectos resuelven dentro de la carpeta fuente.
- El ensamblado MYG.Core de escritorio y del conector tiene el mismo SHA-256.
- Los paquetes de entrega excluyen los archivos RevitAPI.dll y RevitAPIUI.dll, datos de obras, salidas de compilación en el ZIP fuente y símbolos PDB en la distribución.

## Pendiente de comprobar en Windows y Revit

- Aspecto visual, navegación y escalado DPI de los formularios.
- Inicio de sesión e ingreso automático con una licencia MYG real.
- Ejecución del instalador PowerShell y comunicación Named Pipes entre procesos Windows.
- Carga en Revit 2027, consulta del modelo y creación o actualización de tablas en un proyecto real.

La compilación y las pruebas de datos no certifican estos puntos. La versión actual incluye precios, ACU, metrados y resumen económico; la integración S10 permanece pendiente.

## Comandos de validación

```text
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet publish MYG.Desktop/MYG.Desktop.csproj -c Release -r win-x64 --self-contained false
```

Para repetir las cuatro comprobaciones de la muestra nativa en Windows, coloque una copia de ese archivo fuera del repositorio y ejecute:

```powershell
$env:MYG_QA_DELPHIN_SQLITE = 'C:\SuCarpeta\PODER JUDICIAL 1.sqlite'
dotnet run --project .\MYG.Pruebas\MYG.Pruebas.csproj -c Release
Remove-Item Env:\MYG_QA_DELPHIN_SQLITE
```

Las pruebas escriben únicamente copias temporales y verifican que la huella del original no cambie. La muestra no se incluye en el código ni en los paquetes de distribución.

Las referencias NuGet se utilizaron para la comprobación en este entorno. Para trabajar en su PC, siga `LEEME.md` y `GUARDAR_Y_EDITAR.md`.

## Configuración de instalador añadida

Se añadieron la configuración de Inno Setup y un script de generación. Se revisaron sus rutas y la plantilla XML. Los archivos C# permanecen iguales a la versión verificada. La compilación del instalador y las pruebas de instalación, actualización y desinstalación quedan pendientes de ejecución en Windows.
