# Actualización del editor de especificaciones

Base de código: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`081ee6172c9274aa37608bf1bbac2980e206fc70`.
La entrega se prepara en una rama local de trabajo; no publica cambios del código.

## Cambios

- **Pegado Especial** muestra Pegar, Texto con Formato (RTF), Formato HTML y Texto sin formato.
  Los formatos ausentes se muestran deshabilitados. Cancelar no cambia contenido ni historial.
  Atajo: Ctrl+Mayús+V.
- **Clic derecho en la hoja** ofrece Cortar, Copiar, Pegar, Aumentar Sangría,
  Disminuir Sangría, Fuente, Párrafo, Lista Enumerada, Marcador..., Hipervínculo...
  y Nuevo comentario. Las acciones respetan la selección y el modo de solo lectura.
- **Ortografía en español** usa el corrector nativo de Windows. Tras una pausa al escribir
  aparecen ondas rojas; el menú ofrece sugerencias, Ignorar, Ignorar todo, Agregar al
  Diccionario y Comprobar ortografía. F7 recorre los errores. Las ondas son una capa visual:
  no se guardan como subrayado de autor, no cambian el RTF y no aparecen en las salidas impresas.
- Marcadores y comentarios se conservan en los metadatos del documento MYG/RTF.
  Sus ventanas permiten guardar, localizar, editar o eliminar las anotaciones.
  Los hipervínculos aceptan HTTP, HTTPS y mailto. Insertarlos no abre su destino.

## Aplicación manual

1. En Visual Studio, revise **Cambios de Git** y respalde o confirme su trabajo local.
2. Cierre MYG. Extraiga el ZIP en una carpeta temporal.
3. Copie los archivos sobre la raíz de su checkout conservando sus rutas relativas.
   Los archivos existentes se entregan completos: compare antes de reemplazar si tiene
   modificaciones locales o trabaja sobre un commit posterior a la base indicada.
4. No elimine archivos ni bases de datos. No hay migraciones ni paquetes nuevos.
5. Restaure y compile con el SDK .NET 10:

   ```powershell
   dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false --no-restore
   dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
   dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
   ```

   El último comando requiere Windows y el runtime Windows Desktop. Los paquetes de
   referencia permiten compilar el conector; su ejecución necesita Revit 2027.
6. Abra MYG y realice las comprobaciones manuales indicadas abajo.
7. Revise el diff en **Cambios de Git**, haga Commit y después Push a su rama elegida.
   Verifique la rama en GitHub. Publicar el ZIP en DESCARGAS no aplica los cambios a este checkout.

## Configuración y límites

- El SDK utilizado para esta entrega es **.NET 10.0.100**, compatible con `global.json`.
- El corrector necesita un idioma español admitido instalado en **Configuración de Windows >
  Hora e idioma > Idioma y región**. Prefiere es-PE y después otros diccionarios españoles.
  Si no encuentra uno, el editor sigue disponible y Comprobar ortografía explica el requisito.
  Esta revisión integrada no requiere Word.
- Agregar al Diccionario guarda una palabra en el diccionario personal de Windows del idioma activo.
  Ignorar e Ignorar todo se aplican a la especificación cargada y no cambian su contenido.
- HTML conserva texto, párrafos, estilos, fuentes, colores y listas básicos. No reproduce
  páginas web completas, imágenes remotas ni CSS avanzado.
- Los comentarios y marcadores son anotaciones de MYG. El destino RTF es ignorable por otros
  editores; no equivale a globos de comentario de Word y no se incluye como comentario nativo en DOCX/PDF.
  Conserve el documento MYG o el RTF guardado por MYG para mantener estos metadatos.
- No se modificó el esquema SQLite ni se necesitan credenciales nuevas.

## Evidencia de validación

- Compilación Release de toda la solución en Linux: 0 errores y 0 advertencias.
- Pruebas ejecutadas del núcleo y del importador HTML: **206 comprobaciones aprobadas**.
- Prueba de Named Pipes de Windows: omitida explícitamente por el ejecutor en Linux.
- Pruebas de interfaz nuevas y existentes: compiladas; **no ejecutadas en Linux**.
  Las nuevas usan un corrector simulado para comprobar posiciones, menús, formato,
  cancelación y persistencia de anotaciones sin depender de un diccionario concreto.
- No se ejecutó MYG Windows ni Revit en este entorno. La interoperabilidad del corrector
  nativo y la apariencia de las ondas se deben comprobar en Windows.

## Comprobaciones manuales en Windows

1. Copie texto con dos formatos distintos. Abra Pegado Especial y pruebe RTF, HTML y texto;
   compruebe que Cancelar conserva la selección y el documento.
2. Haga clic derecho en texto y en el margen blanco. Compruebe las opciones, selecciones,
   sangrías, fuente, párrafo y numeración. Cortar/Copiar deben respetar la selección.
3. Escriba `hormigonx`, espere un segundo y compruebe la onda roja. Corrija desde el menú;
   pruebe Ignorar, Ignorar todo y F7. Pruebe el diccionario con una palabra técnica que quiera guardar.
4. Desplace y amplíe la hoja y alterne el tema. Verifique que las ondas sigan a las palabras
   y que las salidas RTF/PDF no adquieran subrayados ortográficos permanentes.
5. Cree un marcador y un comentario sobre una selección. Guarde, cambie de partida y vuelva;
   compruebe que se conservan. Inserte texto antes de la selección y pruebe Deshacer/Rehacer.
6. Inserte un hipervínculo y compruebe su texto y dirección al volver a abrir su ventana.
