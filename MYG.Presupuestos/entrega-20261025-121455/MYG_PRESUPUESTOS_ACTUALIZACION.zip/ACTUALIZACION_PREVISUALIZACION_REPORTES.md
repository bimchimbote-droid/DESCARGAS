# Previsualización de presupuestos, costos y metrados

Base del código: `bimchimbote-droid/MYG.Presupuestos`, rama `main`, commit
`c95ab893faf6bcab97492a6ebe53b720b33229c7`.
La entrega es acumulativa e incluye las mejoras anteriores de especificaciones
y de apertura de proyectos. Sólo contiene archivos nuevos o modificados frente
a esa base; no incluye ejecutables, paquetes, bases de datos ni credenciales.

## Comportamiento de las vistas

- La mejora se aplica al componente común de vista preliminar: presupuesto
  seleccionado, todos los presupuestos, hoja de resumen, análisis de costos,
  consolidado, metrados y metrados de fierros/aceros. También lo usan las vistas
  de impresión de metrados Excel y los informes de programación.
- Ctrl + rueda acerca y aleja suavemente entre 10 % y 500 %, manteniendo el punto
  bajo el cursor. La lista, los botones y el deslizador usan el mismo rango.
- Al alejar lo suficiente, se muestran dos hojas cuando caben y existen varias
  páginas. Al acercar vuelve a una. El botón Varias páginas permite elegir el
  modo manual; Página completa ajusta el modo elegido.
- Navegar y alternar entre una y dos páginas reutiliza los metaficheros de las
  páginas ya visitadas. La caché conserva hasta 128 páginas y 128 MiB de buffers
  EMF, retirando las menos recientes. Las páginas visibles se conservan aunque
  por sí solas superen ese presupuesto. No es un límite de toda la RAM de GDI.
- Los cortes de página y cálculos se preparan una vez por configuración. Cambiar
  zoom o navegar no repagina el informe. Cambiar papel, márgenes, fuente, escala
  de impresión o impresora sí necesita volver a preparar sus cortes.
- Color de página y filigrana renuevan el dibujo sin recalcular las fórmulas ni
  los saltos de página. Las imágenes anteriores se invalidan para que no aparezca
  una decoración obsoleta.
- La composición, las copias de hojas y la paginación se realizan fuera de la
  interfaz, mientras el diálogo muestra etapas reales. La carga se mantiene
  hasta preparar los controles y dibujar la primera página. Mostrar después la
  ventana preparada no repite la paginación.
- Las opciones de metrados en formato Excel conservan su vista de celdas y sus
  funciones. Su apertura también informa las etapas de preparación; al entrar
  en su vista de impresión se utiliza el previsualizador común actualizado.

## Impresión y exportación

Impresión y Microsoft Print to PDF continúan usando el mismo plan y los mismos
cortes revisados en la vista. Si se cambia al controlador PDF, hay que revisar
las páginas recalculadas antes de confirmar la exportación, como en el flujo
existente. El rango de páginas y las copias siguen disponibles.

Los reportes no requieren Microsoft Word. Los formatos editables de exportación
conservan su funcionamiento: pueden volver a distribuirse en el programa que
los abra. La coincidencia de esta vista corresponde a impresión/PDF con la misma
configuración, no a una promesa de paginación de todos los formatos editables.

## Aplicar la entrega

1. Respalde o confirme sus modificaciones locales. Compare con la base indicada
   si tiene cambios posteriores: se entregan archivos completos para reemplazar.
2. Extraiga el ZIP sobre la raíz de `MYG.Presupuestos`, conservando las carpetas.
   Cree los archivos nuevos y sustituya los indicados en la tabla de la respuesta.
3. No hay eliminaciones, nuevos paquetes ni migraciones de bases de datos.
4. Restaure y compile con .NET 10.0.100 o una versión admitida por `global.json`:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2
```

La opción de referencias Revit ya existe en el proyecto y permite compilar sin
tener Autodesk instalado. No instala Revit ni permite ejecutarlo en Linux.

## Validación

Resultado de esta entrega: solución completa compilada en Release con .NET
10.0.100, cero errores y cero advertencias. `MYG.Pruebas` completó 596
comprobaciones, incluida la nueva comparación de los siete tipos de reporte
con y sin progreso, sin alterar el proyecto de origen. `MYG.PruebasNube`
completó 39 grupos principales y 982 comprobaciones de contrato HTTP simulado.
Las pruebas gráficas nuevas se compilaron, pero no se ejecutaron en Linux.
Se omitieron Named Pipes de Windows y la base privada LLACUSBAMBA.

Pruebas portables de lógica, fórmulas y composición de todos los tipos de reporte:

```powershell
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release
```

Pruebas específicas de la carga, reutilización de páginas, zoom y configuración,
en Windows x64 con .NET Desktop Runtime 10:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --reportes-previsualizacion
```

Las comprobaciones gráficas se compilan en Linux pero necesitan Windows para
ejecutarse. No se midieron tiempos con la base privada LLACUSBAMBA de la captura,
que no está disponible en este entorno. Consulte la respuesta de entrega para
los resultados efectivos de compilación y pruebas.

Revise manualmente los informes del menú, Ctrl + rueda en ambos sentidos, la
transición a dos hojas, el regreso a páginas visitadas y el rango de impresión.
Cambie orientación/márgenes y compruebe que la carga acompaña la actualización.
Pruebe color y filigrana, y revise los mismos cortes al exportar PDF. Confirme
también la apertura y la vista de impresión de los metrados Excel disponibles.

Después de validar, revise los cambios en Visual Studio, haga Commit y Push a su
rama y compruébelos en GitHub. Publicar el ZIP en DESCARGAS no modifica la rama
del código ni aplica automáticamente los cambios en su equipo.

## Archivos de esta entrega

Acciones respecto de la base `main` indicada. Si un archivo marcado CREAR ya
existe por una entrega anterior, compare y reemplace esa copia con la incluida.

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `ACTUALIZACION_ESPECIFICACIONES_ZOOM_WORD.md` | CREAR | Instrucciones anteriores y resultados actualizados. |
| 2 | `ACTUALIZACION_PREVISUALIZACION_REPORTES.md` | CREAR | Instalación, alcance, pruebas y lista de archivos. |
| 3 | `MYG.Core/BaseDatosMYG.cs` | REEMPLAZAR | Etapas de lectura de proyectos SQLite. |
| 4 | `MYG.Core/DelphinImportacionMYG.cs` | REEMPLAZAR | Progreso de lectura por presupuesto Delphin. |
| 5 | `MYG.Core/ReportesProyectoMYG.cs` | REEMPLAZAR | Composición de los reportes con progreso real. |
| 6 | `MYG.Desktop/CargaAnimada.cs` | REEMPLAZAR | Carga modal, historial y trabajo STA con interfaz activa. |
| 7 | `MYG.Desktop/CronogramaFuncionesVideo.cs` | REEMPLAZAR | Preparación de la vista PDF de programación. |
| 8 | `MYG.Desktop/EditorExportacionPresupuesto.cs` | REEMPLAZAR | Preparación de la vista PDF de presupuesto. |
| 9 | `MYG.Desktop/EditorForm.cs` | REEMPLAZAR | Etapas de preparación del editor de proyectos. |
| 10 | `MYG.Desktop/EditorHerramientas.cs` | REEMPLAZAR | Carga desde los menús de reportes y metrados Excel. |
| 11 | `MYG.Desktop/EditorPresupuestos.cs` | REEMPLAZAR | Apertura preparada de las especificaciones. |
| 12 | `MYG.Desktop/EspecificacionesComposicion.cs` | REEMPLAZAR | Etapas de composición de especificaciones. |
| 13 | `MYG.Desktop/EspecificacionesEditor.cs` | REEMPLAZAR | Liberación de entregas almacenadas. |
| 14 | `MYG.Desktop/EspecificacionesEntregaNativa.cs` | REEMPLAZAR | Preparación nativa y progreso de exportación. |
| 15 | `MYG.Desktop/EspecificacionesEntregaWord.cs` | REEMPLAZAR | Paginación Word y memoria de las entregas. |
| 16 | `MYG.Desktop/EspecificacionesExportacionForm.cs` | REEMPLAZAR | Carga hasta preparar la ventana de especificaciones. |
| 17 | `MYG.Desktop/EspecificacionesPaginasNativas.cs` | REEMPLAZAR | Progreso de páginas RichEdit. |
| 18 | `MYG.Desktop/EspecificacionesVistaPaginada.cs` | REEMPLAZAR | Zoom y reutilización de las páginas de especificaciones. |
| 19 | `MYG.Desktop/EspecificacionesVistaPaginadaEditor.cs` | REEMPLAZAR | Caché por formato y actualización al editar. |
| 20 | `MYG.Desktop/InicioForm.cs` | REEMPLAZAR | Apertura de proyectos bajo el diálogo de carga. |
| 21 | `MYG.Desktop/ProyectosAbiertos.cs` | REEMPLAZAR | Presentación del editor y limpieza ante errores. |
| 22 | `MYG.Desktop/ReportesImpresion.cs` | REEMPLAZAR | Plan común de vista, impresión y PDF con progreso. |
| 23 | `MYG.Desktop/VistaPaginaControl.cs` | REEMPLAZAR | Zoom automático de una/dos hojas y caché vectorial. |
| 24 | `MYG.Desktop/VistaPreliminarReportesForm.cs` | REEMPLAZAR | Preparación completa y configuración común de los reportes. |
| 25 | `MYG.Pruebas/CargaProyectoProgresoCheck.cs` | CREAR | Prueba SQLite de lectura con progreso. |
| 26 | `MYG.Pruebas/Program.cs` | REEMPLAZAR | Registro de la prueba portable de carga. |
| 27 | `MYG.Pruebas/ReportesProyectoCheck.cs` | REEMPLAZAR | Prueba de progreso e integridad de los siete tipos. |
| 28 | `MYG.PruebasUI/CargaAnimadaCheck.cs` | CREAR | Pruebas del diálogo, STA y errores. |
| 29 | `MYG.PruebasUI/EspecificacionesEntregaNativaCheck.cs` | REEMPLAZAR | Pruebas de progreso de entrega nativa. |
| 30 | `MYG.PruebasUI/EspecificacionesExportacionCheck.cs` | REEMPLAZAR | Compatibilidad de la exportación y controles. |
| 31 | `MYG.PruebasUI/EspecificacionesNavegacionCheck.cs` | REEMPLAZAR | Pruebas de zoom, navegación y páginas compartidas. |
| 32 | `MYG.PruebasUI/EspecificacionesVistaPreliminarCheck.cs` | REEMPLAZAR | Pruebas de Word, caché y guardado. |
| 33 | `MYG.PruebasUI/Program.cs` | REEMPLAZAR | Nueva ejecución específica de previsualización de reportes. |
| 34 | `MYG.PruebasUI/ReportesCargaProgresoCheck.cs` | CREAR | Pruebas de carga, presentación y fallos de los reportes. |
| 35 | `MYG.PruebasUI/VistaPreliminarReportesCheck.cs` | REEMPLAZAR | Pruebas de zoom, caché, dos páginas y errores de dibujo. |
