using System;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class CargaAnimadaCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Carga-UI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        var indice = typeof(MYGIndiceLocal).GetProperty("RutaAlternativaPruebas", BindingFlags.Static | BindingFlags.NonPublic);
        string anterior = (string)indice.GetValue(null);
        try
        {
            indice.SetValue(null, Path.Combine(carpeta, "indice.json"));
            MYGIndiceLocal.RecordarBiblioteca(Path.Combine(carpeta, "biblioteca.json"));
            EjecutarVentana(exige);
        }
        finally
        {
            indice.SetValue(null, anterior);
            Directory.Delete(carpeta, true);
        }
    }

    private static void EjecutarVentana(Action<bool, string> exige)
    {
        using var host = new Form { ClientSize = new System.Drawing.Size(900, 600), ShowInTaskbar = false };
        ExceptionDispatchInfo fallo = null;
        host.Shown += async (_, _) =>
        {
            try
            {
                MYGDialogoCarga dialogo = null;
                await MYGCargaAnimada.EjecutarConProgresoAsync(host, "Comenzando lectura…", async progreso =>
                {
                    dialogo = host.OwnedForms.OfType<MYGDialogoCarga>().Single();
                    exige(dialogo.Visible && dialogo.Opacity == 1 && !host.Enabled,
                        "El diálogo debe ser visible desde el inicio y bloquear al propietario hasta terminar todos los procesos.");
                    progreso.Report("Leyendo presupuestos…");
                    exige(dialogo.EtapaActual == "Leyendo presupuestos…",
                        "Una etapa UI debe actualizar inmediatamente su descripción sin esperar al final de la apertura.");
                    await Task.Yield();
                    exige(dialogo.Visible && !host.Enabled,
                        "El diálogo debe seguir presente después de la lectura mientras se prepara la interfaz.");
                    using var sesion = new MYG.Externo.SesionDesktop();
                    using var editor = new EditorForm(MYGProyectoStorage.Nuevo("PROYECTO DE CARGA", "PRESUPUESTO"), "", sesion,
                        informarCarga: progreso.Report);
                    exige(dialogo.Visible && dialogo.Etapas.Any(e => e.Contains("resúmenes", StringComparison.Ordinal)) &&
                            dialogo.EtapaActual.Contains("apariencia", StringComparison.Ordinal),
                        "La construcción real del editor debe informar presupuesto, biblioteca, resúmenes y apariencia con la carga aún visible.");
                    for (int i = 0; i < 10; i++) progreso.Report("Proceso " + i);
                    exige(dialogo.Etapas.Length == 5 && dialogo.EtapaActual == "Proceso 9",
                        "El historial de carga debe conservar las últimas cinco etapas y mantener la actual separada.");
                    return true;
                });
                exige(host.Enabled && dialogo.IsDisposed,
                    "Terminar la operación completa debe retirar el diálogo y restaurar al propietario.");

                bool recibioError = false;
                try
                {
                    await MYGCargaAnimada.EjecutarConProgresoAsync<bool>(host, "Leyendo…", async progreso =>
                    {
                        progreso.Report("Validando…");
                        await Task.Yield();
                        throw new InvalidOperationException("fallo controlado de carga");
                    });
                }
                catch (InvalidOperationException ex) when (ex.Message == "fallo controlado de carga") { recibioError = true; }
                exige(recibioError && host.Enabled && !host.OwnedForms.OfType<MYGDialogoCarga>().Any(),
                    "Una excepción debe propagarse conservando la ventana habilitada y sin dejar un diálogo de carga huérfano.");

                VerificarSta(host, exige);
            }
            catch (Exception ex) { fallo = ExceptionDispatchInfo.Capture(ex); }
            finally { host.Close(); }
        };
        host.ShowDialog();
        fallo?.Throw();
    }

    private static void VerificarSta(Form host, Action<bool, string> exige)
    {
        int hiloUi = Environment.CurrentManagedThreadId;
        bool etapaVista = false;
        int pulsos = 0;
        using var continuar = new ManualResetEventSlim();
        using var reloj = new System.Windows.Forms.Timer { Interval = 15 };
        reloj.Tick += (_, _) =>
        {
            pulsos++;
            var dialogo = host.OwnedForms.OfType<MYGDialogoCarga>().FirstOrDefault();
            if (dialogo?.EtapaActual == "Paginando en STA…")
            {
                etapaVista = dialogo.Visible && !host.Enabled;
                continuar.Set();
            }
        };
        reloj.Start();
        var resultado = MYGCargaAnimada.EjecutarSta(host, "Preparando páginas…", progreso =>
        {
            bool sta = Thread.CurrentThread.GetApartmentState() == ApartmentState.STA &&
                Environment.CurrentManagedThreadId != hiloUi;
            progreso("Paginando en STA…");
            if (!continuar.Wait(TimeSpan.FromSeconds(10))) throw new TimeoutException("La ventana de carga no procesó el progreso STA.");
            return sta;
        });
        reloj.Stop();
        exige(resultado && etapaVista && pulsos > 0 && host.Enabled,
            "El trabajo STA debe usar otro hilo mientras el bucle modal procesa etapas y animación, y restaurar la ventana al terminar.");
        bool recibioError = false;
        try { MYGCargaAnimada.EjecutarSta<bool>(host, "Preparando…", _ => throw new InvalidOperationException("fallo STA")); }
        catch (InvalidOperationException ex) when (ex.Message == "fallo STA") { recibioError = true; }
        exige(recibioError && host.Enabled && !host.OwnedForms.OfType<MYGDialogoCarga>().Any(),
            "Un fallo del hilo STA debe propagarse sin perder el control ni dejar la carga abierta.");
    }
}
