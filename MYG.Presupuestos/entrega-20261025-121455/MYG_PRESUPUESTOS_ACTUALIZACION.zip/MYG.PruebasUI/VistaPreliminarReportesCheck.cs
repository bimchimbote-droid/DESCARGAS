using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class VistaPreliminarReportesCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarVistaSinImpresora(exige);
        VerificarCabeceraInstitucional(exige);
        VerificarBandasAcero(exige);
        VerificarSuperficie(exige);
        VerificarCacheYPaginasAutomaticas(exige);
        VerificarErroresSuperficie(exige);
        VerificarFondoYBusqueda(exige);
        VerificarFormulario(exige);
        VerificarEscalaYMargenes(exige);
        VerificarFuenteYOrientacion(exige);
        VerificarUnidadesPagina(exige);
        VerificarGuiasMargenes(exige);
        VistaPreliminarExportacionCheck.Ejecutar(exige);
    }

    private static void VerificarFuenteYOrientacion(Action<bool, string> exige)
    {
        var reportes = new[] { ReporteLargo()[0], ReporteLargo()[0] };
        foreach (var celda in reportes[1].Hoja.Celdas.Values) celda.Fuente = "Times New Roman";
        string originales = Datos(reportes);
        using var formulario = new MYGVistaPreliminarReportesForm("Fuente y orientación", reportes);
        var controles = Controles(formulario).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
        var acciones = Controles(formulario).OfType<ToolStrip>().SelectMany(b => Acciones(b.Items))
            .Where(a => !string.IsNullOrEmpty(a.Name)).ToDictionary(a => a.Name);
        exige(controles["vista_fuente"].Text == "Arial Narrow" && formulario.Configuracion.Reportes
                .SelectMany(r => r.Hoja.Celdas.Values).All(c => c.Fuente == "Arial Narrow") && Datos(reportes) == originales,
            "Abrir cualquier reporte debe aplicar Arial Narrow a todas las hojas de la vista y conservar las fuentes guardadas en el proyecto.");
        var retrato = (ToolStripMenuItem)acciones["vista_orientacion_retrato"];
        var apaisado = (ToolStripMenuItem)acciones["vista_orientacion_apaisado"];
        exige(retrato.Text == "Retrato" && apaisado.Text == "Apaisado" &&
                retrato.Image is { Width: >= 24, Height: >= 24 } && apaisado.Image is { Width: >= 24, Height: >= 24 },
            "El desplegable de orientación debe ofrecer Retrato y Apaisado con sus iconos legibles.");
        using (var imagenRetrato = new Bitmap(retrato.Image))
        using (var imagenApaisado = new Bitmap(apaisado.Image))
            exige(FirmaRegion(imagenRetrato, new Rectangle(Point.Empty, imagenRetrato.Size)) !=
                    FirmaRegion(imagenApaisado, new Rectangle(Point.Empty, imagenApaisado.Size)),
                "Los iconos de Retrato y Apaisado deben distinguir visualmente las dos orientaciones del papel.");
        apaisado.PerformClick();
        exige(controles["vista_orientacion"].Text == "Horizontal" && apaisado.Checked && !retrato.Checked &&
                formulario.Configuracion.Reportes.All(r => r.Hoja.OrientacionPagina == "Horizontal"),
            "Elegir Apaisado debe girar todas las hojas y señalar únicamente esa orientación en el menú.");
        retrato.PerformClick();
        exige(controles["vista_orientacion"].Text == "Vertical" && retrato.Checked && !apaisado.Checked &&
                formulario.Configuracion.Reportes.All(r => r.Hoja.OrientacionPagina == "Vertical"),
            "Elegir Retrato debe recuperar la orientación vertical y actualizar la selección del menú.");
        formulario.Configuracion.Fuente("Courier New");
        acciones["vista_restaurar"].PerformClick();
        exige(controles["vista_fuente"].Text == "Arial Narrow" && formulario.Configuracion.Reportes
                .SelectMany(r => r.Hoja.Celdas.Values).All(c => c.Fuente == "Arial Narrow") && Datos(reportes) == originales,
            "Restablecer la vista debe recuperar Arial Narrow sin cambiar las fuentes originales, fórmulas ni formatos del proyecto.");
    }

    private static void VerificarUnidadesPagina(Action<bool, string> exige)
    {
        var iniciales = new MYGAjustesPaginaReporte("A3", "Horizontal", 18.123456m, 19.75m, 20.25m, 21.5m);
        using var dialogo = new MYGConfigurarPaginaReporteDialog(iniciales);
        dialogo.CreateControl(); dialogo.PerformLayout();
        var campos = Controles(dialogo).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
        var unidad = (ComboBox)campos["vista_pagina_unidad"];
        var izquierda = (NumericUpDown)campos["vista_pagina_izquierda"];
        var derecha = (NumericUpDown)campos["vista_pagina_derecha"];
        var superior = (NumericUpDown)campos["vista_pagina_superior"];
        var inferior = (NumericUpDown)campos["vista_pagina_inferior"];
        exige(unidad.DropDownStyle == ComboBoxStyle.DropDownList && unidad.Items.Cast<string>()
                .SequenceEqual(new[] { "Inch", "Millimeter", "Pixel" }) && unidad.Text == "Millimeter",
            "Configurar página debe ofrecer las tres unidades de la referencia y comenzar en milímetros.");
        for (int vuelta = 0; vuelta < 8; vuelta++)
            foreach (string nombre in new[] { "Inch", "Pixel", "Millimeter" })
            {
                unidad.SelectedItem = nombre;
                exige(dialogo.Ajustes == iniciales,
                    "Alternar la unidad de visualización debe conservar exactamente los márgenes físicos, sin acumular redondeos.");
            }
        exige(campos["vista_pagina_ancho"].Text == "420 mm" && campos["vista_pagina_alto"].Text == "297 mm",
            "Volver a Millimeter debe recuperar las dimensiones físicas del papel A3 apaisado.");
        unidad.SelectedItem = "Inch";
        exige(izquierda.Maximum == 3 && campos["vista_pagina_ancho"].Text.EndsWith(" in"),
            "Inch debe convertir dimensiones y límites de los márgenes a pulgadas.");
        izquierda.Value = 1; derecha.Value = .5m; superior.Value = .75m; inferior.Value = .25m;
        var unaPulgada = new MYGAjustesPaginaReporte("A3", "Horizontal", 25.4m, 12.7m, 19.05m, 6.35m);
        exige(dialogo.Ajustes == unaPulgada,
            "Editar márgenes en pulgadas debe guardar los cuatro valores físicos equivalentes en milímetros.");
        unidad.SelectedItem = "Pixel";
        exige(izquierda.Value == 96 && derecha.Value == 48 && superior.Value == 72 && inferior.Value == 24 &&
                izquierda.Maximum == 288 && campos["vista_pagina_ancho"].Text.Contains("96 DPI"),
            "Pixel debe representar una pulgada como 96 píxeles e indicar la resolución usada para la conversión.");
        izquierda.Value = 120;
        exige(dialogo.Ajustes.IzquierdaMm == 31.75m && dialogo.Ajustes.DerechaMm == 12.7m,
            "Editar 120 píxeles debe guardar 31.75 mm y conservar los márgenes que no se editaron.");
        unidad.SelectedItem = "Millimeter";
        exige(izquierda.Value == 31.75m && derecha.Value == 12.7m && superior.Value == 19.05m && inferior.Value == 6.35m &&
                dialogo.IntentarAceptar() && dialogo.Ajustes.IzquierdaMm == 31.75m,
            "Aceptar después de editar en píxeles debe conservar las medidas físicas al regresar a milímetros.");
        var retrato = (RadioButton)campos["vista_pagina_vertical"];
        var apaisado = (RadioButton)campos["vista_pagina_horizontal"];
        exige(retrato.Text.Contains("Retrato") && apaisado.Text.Contains("Apaisado") &&
                retrato.Image != null && apaisado.Image != null,
            "Las dos opciones de orientación del diálogo también deben mostrar sus nombres e iconos.");
    }

    private static void VerificarGuiasMargenes(Action<bool, string> exige)
    {
        var primeraHoja = ReporteLargo()[0];
        var segundaHoja = ReporteLargo()[0];
        primeraHoja.Hoja.MargenIzquierdo = .6m; primeraHoja.Hoja.MargenDerecho = .8m;
        primeraHoja.Hoja.MargenSuperior = .7m; primeraHoja.Hoja.MargenInferior = .9m;
        segundaHoja.Hoja.OrientacionPagina = "Horizontal";
        segundaHoja.Hoja.MargenIzquierdo = 1.1m; segundaHoja.Hoja.MargenDerecho = 1.2m;
        segundaHoja.Hoja.MargenSuperior = .8m; segundaHoja.Hoja.MargenInferior = 1m;
        var vista = MYGReportesImpresion.PrepararVista(new[] { primeraHoja, segundaHoja });
        int inicioSegunda = MYGReportesImpresion.PrepararVista(new[] { primeraHoja }).CantidadPaginas;
        using var superficie = new MYGVistaPaginaControl { Dock = DockStyle.None, Size = new Size(1600, 1000) };
        superficie.CreateControl();
        float dpi = superficie.DeviceDpi / 96f;
        superficie.Size = new Size((int)(1600 * dpi), (int)(1000 * dpi));
        foreach (int indice in new[] { 0, inicioSegunda - 1, inicioSegunda, vista.CantidadPaginas - 1 })
        {
            var hoja = indice < inicioSegunda ? primeraHoja.Hoja : segundaHoja.Hoja;
            SizeF medida = vista.TamanoPagina(indice);
            RectangleF area = vista.AreaMargenes(indice);
            exige(Cerca(area.Left, (float)hoja.MargenIzquierdo) && Cerca(area.Top, (float)hoja.MargenSuperior) &&
                    Cerca(area.Right, medida.Width - (float)hoja.MargenDerecho) &&
                    Cerca(area.Bottom, medida.Height - (float)hoja.MargenInferior),
                "Cada página debe exponer los cuatro márgenes de su propia hoja, también al cambiar de informe y orientación.");
            using var salida = Dibujar(vista, indice);
            var papelSalida = new RectangleF(0, 0, medida.Width * 96, medida.Height * 96);
            exige(GuiasVisibles(salida, papelSalida, Proyectar(area, medida, papelSalida), false),
                "El dibujo compartido por impresión y PDF debe dejar blancos los márgenes sin incluir las guías de pantalla.");
            superficie.Cargar(vista, indice);
            foreach (float zoom in new[] { .4f, .55f })
            {
                superficie.CambiarZoom(zoom);
                using var pantalla = DibujarControl(superficie);
                RectangleF papel = superficie.RectanguloPapel;
                exige(GuiasVisibles(pantalla, papel, Proyectar(area, medida, papel), true),
                    "La vista preliminar debe dibujar las cuatro guías grises discontinuas hasta los bordes del papel y conservar su posición al cambiar el zoom.");
            }
        }
        superficie.VariasPaginas = true;
        superficie.Cargar(vista, inicioSegunda - 1);
        superficie.CambiarZoom(.5f);
        superficie.ProcesarRueda(120, true, new Point(superficie.ClientSize.Width / 2, superficie.ClientSize.Height / 2));
        superficie.AvanzarZoom(.05);
        using var animada = DibujarControl(superficie);
        exige(superficie.ZoomEnCurso && superficie.RectangulosPapel.Count == 2,
            "La comprobación de márgenes debe incluir dos informes visibles durante una animación de zoom.");
        for (int posicion = 0; posicion < superficie.RectangulosPapel.Count; posicion++)
        {
            int indice = inicioSegunda - 1 + posicion;
            RectangleF papel = superficie.RectangulosPapel[posicion];
            exige(GuiasVisibles(animada, papel, Proyectar(vista.AreaMargenes(indice), vista.TamanoPagina(indice), papel), true),
                "Durante el zoom animado, cada hoja visible debe mantener sus propias cuatro guías, aunque cambien su orientación y márgenes.");
        }
    }

    private static void VerificarEscalaYMargenes(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        using var formulario = new MYGVistaPreliminarReportesForm("Opciones de impresión", reportes);
        formulario.ActualizarVista();
        var controles = Controles(formulario).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
        var acciones = Controles(formulario).OfType<ToolStrip>().SelectMany(b => Acciones(b.Items))
            .Where(a => !string.IsNullOrEmpty(a.Name)).ToDictionary(a => a.Name);
        var menuEscala = (ToolStripDropDownButton)acciones["vista_escala_barra"];
        var editor = (MYGEscalaImpresionControl)menuEscala.DropDownItems.OfType<ToolStripControlHost>().Single().Control;
        var entradas = Controles(editor).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
        var porcentaje = (RadioButton)entradas["vista_escala_porcentaje"];
        var anchura = (RadioButton)entradas["vista_escala_anchura"];
        var valor = (NumericUpDown)entradas["vista_escala_valor"];
        var paginas = (NumericUpDown)entradas["vista_escala_paginas"];
        editor.Cargar(formulario.Configuracion.Escala, formulario.Configuracion.PaginasDeAncho);
        exige(porcentaje.Checked && valor.Enabled && !paginas.Enabled && valor.Value == 100,
            "El desplegable de escala debe comenzar con porcentaje y habilitar solo la entrada del modo elegido.");
        valor.Value = 75; anchura.Checked = true; paginas.Value = 2;
        editor.Descartar();
        exige(formulario.Configuracion.Escala == 1 && formulario.Configuracion.PaginasDeAncho == 0,
            "Cancelar el desplegable de escala debe descartar tanto el porcentaje como la anchura propuesta.");
        editor.Cargar(formulario.Configuracion.Escala, formulario.Configuracion.PaginasDeAncho);
        exige(valor.Value == 100 && porcentaje.Checked,
            "Reabrir el editor de escala debe recuperar los valores aplicados y descartar la edición cancelada.");
        anchura.Checked = true; paginas.Value = 2;
        editor.Confirmar();
        exige(formulario.Configuracion.PaginasDeAncho == 2 && !controles["vista_escala"].Enabled && formulario.CantidadPaginas > 0,
            "Aceptar la anchura debe aplicarla al plan de impresión y desactivar el porcentaje lateral mientras está activa.");
        editor.Cargar(formulario.Configuracion.Escala, formulario.Configuracion.PaginasDeAncho);
        exige(anchura.Checked && paginas.Value == 2 && !valor.Enabled && paginas.Enabled,
            "El editor debe recuperar el número de páginas de ancho aceptado.");
        porcentaje.Checked = true; valor.Value = 75;
        editor.Confirmar();
        exige(Cerca(formulario.Configuracion.Escala, .75f) && formulario.Configuracion.PaginasDeAncho == 0 && controles["vista_escala"].Enabled,
            "Aceptar porcentaje debe volver al modo de escala fija y actualizar el control lateral.");

        foreach (var preset in new[] { ("normal", 25m, 25m), ("estrecho", 13m, 13m), ("moderado", 19m, 25m), ("ancho", 51m, 25m) })
        {
            acciones["vista_margenes_" + preset.Item1].PerformClick();
            exige(formulario.Configuracion.Reportes.All(r =>
                    Math.Abs(r.Hoja.MargenIzquierdo * 25.4m - preset.Item2) < .0001m &&
                    Math.Abs(r.Hoja.MargenDerecho * 25.4m - preset.Item2) < .0001m &&
                    Math.Abs(r.Hoja.MargenSuperior * 25.4m - preset.Item3) < .0001m &&
                    Math.Abs(r.Hoja.MargenInferior * 25.4m - preset.Item3) < .0001m),
                "El preajuste " + preset.Item1 + " debe aplicar exactamente los cuatro márgenes de referencia, en milímetros.");
        }
        var ajustesIniciales = MYGAjustesPaginaReporte.Desde(formulario.Configuracion.Reportes[0].Hoja);
        using (var dialogo = new MYGConfigurarPaginaReporteDialog(ajustesIniciales))
        {
            dialogo.CreateControl(); dialogo.PerformLayout();
            var campos = Controles(dialogo).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
            ((ComboBox)campos["vista_pagina_papel"]).SelectedItem = "A3";
            ((RadioButton)campos["vista_pagina_horizontal"]).Checked = true;
            ((NumericUpDown)campos["vista_pagina_izquierda"]).Value = 18;
            ((NumericUpDown)campos["vista_pagina_derecha"]).Value = 17;
            ((NumericUpDown)campos["vista_pagina_superior"]).Value = 16;
            ((NumericUpDown)campos["vista_pagina_inferior"]).Value = 15;
            exige(campos["vista_pagina_ancho"].Text == "420 mm" && campos["vista_pagina_alto"].Text == "297 mm",
                "El diálogo de página debe mostrar las dimensiones orientadas en milímetros al elegir A3 apaisado.");
            var muestra = (MYGMargenesPaginaControl)campos["vista_pagina_muestra"];
            using var imagen = DibujarControl(muestra);
            exige(muestra.PapelVisible.Width > muestra.PapelVisible.Height &&
                    muestra.AreaVisible.Left > muestra.PapelVisible.Left && muestra.AreaVisible.Right < muestra.PapelVisible.Right,
                "La muestra de página debe girar con la orientación y colocar las guías de los márgenes dentro del papel.");
            exige(MYGAjustesPaginaReporte.Desde(formulario.Configuracion.Reportes[0].Hoja) == ajustesIniciales,
                "Editar papel, orientación y márgenes dentro del diálogo debe conservar la vista hasta Aceptar.");
            exige(dialogo.IntentarAceptar() && dialogo.DialogResult == DialogResult.OK,
                "El diálogo debe aceptar una propuesta válida de papel y márgenes.");
            formulario.AplicarAjustesPagina(dialogo.Ajustes);
        }
        var aplicada = MYGAjustesPaginaReporte.Desde(formulario.Configuracion.Reportes[0].Hoja);
        exige(aplicada.Papel == "A3" && aplicada.Orientacion == "Horizontal" &&
                Math.Abs(aplicada.IzquierdaMm - 18) < .0001m && Math.Abs(aplicada.DerechaMm - 17) < .0001m &&
                Math.Abs(aplicada.SuperiorMm - 16) < .0001m && Math.Abs(aplicada.InferiorMm - 15) < .0001m,
            "Aceptar márgenes personalizados debe aplicar juntos el papel, la orientación y los cuatro valores sin redondearlos a centímetros.");
        using (var dialogo = new MYGConfigurarPaginaReporteDialog(aplicada))
        {
            var campos = Controles(dialogo).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
            ((ComboBox)campos["vista_pagina_papel"]).SelectedItem = "Carta";
            ((NumericUpDown)campos["vista_pagina_izquierda"]).Value = 5;
            dialogo.DialogResult = DialogResult.Cancel;
        }
        exige(MYGAjustesPaginaReporte.Desde(formulario.Configuracion.Reportes[0].Hoja) == aplicada,
            "Cancelar márgenes personalizados debe conservar todo el papel y los márgenes aplicados anteriormente.");
        acciones["vista_restaurar"].PerformClick();
        exige(formulario.Configuracion.Escala == 1 && formulario.Configuracion.PaginasDeAncho == 0 &&
                formulario.Configuracion.Reportes[0].Hoja.TamanoPapel == reportes[0].Hoja.TamanoPapel && Datos(reportes) == originales,
            "Restablecer debe recuperar escala y papel originales sin modificar ninguna hoja del proyecto.");
    }

    private static void VerificarVistaSinImpresora(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        var configuracion = new MYGConfiguracionVistaReporte(reportes);
        var vertical = MYGReportesImpresion.PrepararVista(configuracion.Reportes);
        exige(vertical.CantidadPaginas > 3,
            "La vista sin impresora debe paginar un reporte largo y conservar sus filas combinadas y ocultas.");
        SizeF papelVertical = vertical.TamanoPagina(0);
        exige(Cerca(papelVertical.Width, 8.27f) && Cerca(papelVertical.Height, 11.69f),
            "La vista lógica debe usar el tamaño A4 vertical sin consultar una impresora.");
        using var primera = Dibujar(vertical, 0);
        using var ultima = Dibujar(vertical, vertical.CantidadPaginas - 1);
        exige(TieneContenido(primera) && TieneContenido(ultima),
            "La primera y última página deben dibujar contenido real sobre el papel blanco.");
        exige(FirmaContenido(primera) != FirmaContenido(ultima),
            "La paginación debe cambiar el cuerpo dibujado entre la primera y la última página, además del número del pie.");
        for (int indice = 0; indice < vertical.CantidadPaginas; indice++)
        {
            using var imagen = Dibujar(vertical, indice);
            exige(!ContieneFilaOculta(imagen),
                "La vista preliminar debe omitir el relleno magenta de las filas ocultas en todas sus páginas.");
        }

        configuracion.ConfigurarPagina("A4", "Horizontal", .5m, .5m, .5m, .5m);
        var horizontal = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala, null);
        SizeF papelHorizontal = horizontal.TamanoPagina(0);
        exige(Cerca(papelHorizontal.Width, papelVertical.Height) && Cerca(papelHorizontal.Height, papelVertical.Width),
            "Cambiar a horizontal debe intercambiar el ancho y alto del papel de la vista preliminar.");
        exige(horizontal.CantidadPaginas > vertical.CantidadPaginas,
            "Un reporte angosto y largo debe necesitar más páginas cuando la orientación reduce el alto disponible.");

        configuracion.ConfigurarPagina("A3", "Vertical", .5m, .5m, .5m, .5m);
        var a3 = MYGReportesImpresion.PrepararVista(configuracion.Reportes);
        exige(Cerca(a3.TamanoPagina(0).Width, 11.69f) && Cerca(a3.TamanoPagina(0).Height, 16.54f) &&
            a3.CantidadPaginas < vertical.CantidadPaginas,
            "Elegir A3 debe recalcular el tamaño y reducir las páginas del reporte largo.");

        configuracion.ConfigurarPagina("A4", "Vertical", .5m, .5m, .5m, .5m);
        configuracion.Escala = .5f;
        var reducido = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala);
        exige(reducido.CantidadPaginas < vertical.CantidadPaginas,
            "Reducir la escala de impresión debe recalcular los saltos de página sin cambiar el tamaño del papel.");
        using var paginaReducida = Dibujar(reducido, 0);
        exige(TieneContenido(paginaReducida) && FirmaContenido(paginaReducida) != FirmaContenido(primera),
            "La escala elegida debe afectar el contenido dibujado y conservar una página visible.");
        configuracion.Restaurar();
        var restaurada = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala);
        using var paginaRestaurada = Dibujar(restaurada, 0);
        exige(restaurada.CantidadPaginas == vertical.CantidadPaginas && FirmaContenido(paginaRestaurada) == FirmaContenido(primera),
            "Restablecer debe recuperar los saltos y la representación original del reporte.");
        exige(Datos(reportes) == originales,
            "Preparar, dibujar, configurar y restablecer la vista debe conservar los datos, fórmulas y dimensiones de origen.");
    }

    private static void VerificarCabeceraInstitucional(Action<bool, string> exige)
    {
        var originales = ReporteLargo();
        string datosOriginales = Datos(originales);
        string[] campos = { "Proyecto", "Presupuesto", "Propietario", "Portafolio", "Tipo de obra", "Departamento",
            "Provincia", "Distrito", "Localidad", "Fecha de elaboración", "Fecha de inicio", "Fecha de término",
            "Duración", "Calendario", "Periodos", "Modalidad", "Análisis", "Elaborado por", "Moneda" };
        var datos = campos.Select((campo, indice) => new KeyValuePair<string, string>(campo,
            "Registro " + (indice + 1).ToString("00", System.Globalization.CultureInfo.InvariantCulture))).ToArray();
        datos[0] = new("Proyecto", "Mejoramiento integral de la infraestructura educativa y de los espacios públicos de la localidad de prueba institucional");
        var reportes = new[] { new MYGHojaReporteProyecto(originales[0].Titulo, originales[0].Hoja, datos) };
        string reportesOriginales = Datos(reportes);
        var sinDatos = MYGReportesImpresion.PrepararVista(originales);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        exige(vista.CantidadPaginas > sinDatos.CantidadPaginas &&
            vista.AreaCabecera(0).Height > sinDatos.AreaCabecera(0).Height + 2,
            "La cabecera completa debe reservar altura para los diecinueve datos del proyecto y recalcular la paginación sin superponer el presupuesto.");
        RectangleF area = vista.AreaCabecera(0);
        exige(area.Bottom < vista.TamanoPagina(0).Height - .5f &&
            vista.AreaCabecera(vista.CantidadPaginas - 1) == area,
            "La cabecera institucional debe conservar sus medidas en todas las páginas y dejar espacio útil para las filas del reporte.");
        using var primera = Dibujar(vista, 0);
        using var ultima = Dibujar(vista, vista.CantidadPaginas - 1);
        Rectangle pixelesCabecera = Rectangle.Ceiling(new RectangleF(area.X * 96, area.Y * 96, area.Width * 96, area.Height * 96));
        pixelesCabecera.Inflate(-2, -2);
        ulong firma = FirmaRegion(primera, pixelesCabecera);
        exige(firma == FirmaRegion(ultima, pixelesCabecera) && FirmaContenido(primera) != FirmaContenido(ultima),
            "La información completa del proyecto debe repetirse idéntica en la primera y última página mientras cambia el cuerpo del presupuesto.");
        for (int indice = 0; indice < datos.Length; indice++)
        {
            exige(vista.BuscarPagina(datos[indice].Key, vista.CantidadPaginas - 1) == vista.CantidadPaginas - 1 &&
                vista.BuscarPagina(datos[indice].Value, vista.CantidadPaginas - 1) == vista.CantidadPaginas - 1,
                "La búsqueda debe encontrar cada etiqueta y valor de la cabecera en cualquier página del informe.");
            var cambiados = datos.ToArray();
            string valor = cambiados[indice].Value;
            cambiados[indice] = new(cambiados[indice].Key, "X" + valor[1..]);
            var variante = MYGReportesImpresion.PrepararVista(new[]
                { new MYGHojaReporteProyecto(reportes[0].Titulo, reportes[0].Hoja, cambiados) });
            using var modificada = Dibujar(variante, 0);
            exige(FirmaRegion(modificada, pixelesCabecera) != firma,
                "Cambiar el valor de cada dato del proyecto debe cambiar realmente el texto dibujado en la cabecera, sin omitir campos finales.");
        }
        using var formulario = new MYGVistaPreliminarReportesForm("Proyecto institucional", reportes);
        formulario.ActualizarVista();
        var vistaFormulario = MYGReportesImpresion.PrepararVista(formulario.Configuracion.Reportes);
        exige(formulario.CantidadPaginas == vistaFormulario.CantidadPaginas &&
            formulario.Configuracion.Reportes[0].DatosProyecto.SequenceEqual(datos),
            "La ventana debe preservar los datos completos en su copia temporal y paginar con la misma cabecera que se imprimirá.");
        formulario.Configuracion.Restaurar();
        formulario.ActualizarVista();
        exige(formulario.Configuracion.Reportes[0].DatosProyecto.SequenceEqual(datos) &&
            Datos(originales) == datosOriginales && Datos(reportes) == reportesOriginales,
            "Dibujar, configurar y restablecer la cabecera institucional debe conservar las hojas y la información de origen.");
    }

    private static void VerificarBandasAcero(Action<bool, string> exige)
    {
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        hoja.AreaImpresion = "A1:AH16";
        hoja.Poner("A3", "Viga principal"); hoja.Poner("B3", "2"); hoja.Poner("C3", "4");
        hoja.Poner("D3", "3/8"); hoja.Poner("E3", "5");
        for (int columna = 31; columna <= 34; columna++)
        {
            string letra = MYGHojaCalculo.Columna(columna);
            hoja.Poner(letra + "2", letra, true);
            hoja.Poner(letra + "3", "Dato " + letra);
            hoja.Celdas[letra + "3"].ColorFondo = "D7EBC4";
        }
        var reportes = new[] { new MYGHojaReporteProyecto("Metrado de fierros y aceros", hoja) };
        string originales = Datos(reportes);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        exige(vista.CantidadPaginas > 1,
            "La vista preliminar de aceros debe generar bandas horizontales legibles para sus 34 columnas.");
        using var primera = Dibujar(vista, 0);
        using var ultima = Dibujar(vista, vista.CantidadPaginas - 1);
        exige(TieneContenido(primera) && TieneContenido(ultima) && FirmaContenido(primera) != FirmaContenido(ultima),
            "La última banda de acero debe dibujar sus propios datos y no repetir únicamente la primera página.");
        exige(ContieneColor(ultima, Color.FromArgb(215, 235, 196)),
            "Las columnas finales AE–AH deben permanecer visibles en la última banda de la hoja de aceros.");
        exige(Datos(reportes) == originales,
            "Segmentar y dibujar la plantilla de aceros debe conservar todas las fórmulas y anchos originales.");
    }

    private static void VerificarSuperficie(Action<bool, string> exige)
    {
        var vista = MYGReportesImpresion.PrepararVista(ReporteLargo());
        using var superficie = new MYGVistaPaginaControl { Dock = DockStyle.None, Size = new Size(900, 700) };
        superficie.CreateControl();
        float dpi = superficie.DeviceDpi / 96f;
        superficie.Size = new Size((int)(900 * dpi), (int)(700 * dpi));
        superficie.Cargar(vista, 0);
        superficie.CambiarZoom(.4f);
        superficie.VariasPaginas = false;
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize),
            "Una hoja que cabe en la superficie debe quedar centrada horizontal y verticalmente.");
        superficie.Size = new Size((int)(1100 * dpi), (int)(820 * dpi));
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize),
            "Redimensionar la ventana debe conservar el papel centrado en el área disponible.");
        superficie.CambiarZoom(.55f);
        superficie.VariasPaginas = false;
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize),
            "Cambiar el zoom de una hoja que cabe debe recalcular su posición centrada.");

        superficie.CambiarZoom(1.5f);
        var ancla = new Point((int)(300 * dpi), (int)(300 * dpi));
        PointF antes = Relativo(superficie.RectanguloPapel, ancla);
        int cambiosZoom = 0;
        superficie.AmpliacionChanged += (_, _) => cambiosZoom++;
        superficie.ProcesarRueda(60, true, ancla);
        float objetivo = 1.5f * (float)Math.Sqrt(1.12);
        exige(Cerca(superficie.Ampliacion, 1.5f) && Cerca(superficie.AmpliacionObjetivo, objetivo) &&
            superficie.ZoomEnCurso && cambiosZoom == 0,
            "Ctrl y rueda deben preparar un objetivo proporcional sin saltar al zoom final antes de animar.");
        float anteriorZoom = superficie.Ampliacion;
        for (int fotograma = 0; fotograma < 7; fotograma++)
        {
            superficie.AvanzarZoom(.015);
            PointF despues = Relativo(superficie.RectanguloPapel, ancla);
            exige(superficie.Ampliacion > anteriorZoom && superficie.Ampliacion < objetivo && superficie.ZoomEnCurso,
                "Cada fotograma del acercamiento debe avanzar hacia el objetivo sin saltos ni sobrepasarlo.");
            exige(Math.Abs(antes.X - despues.X) < .005f && Math.Abs(antes.Y - despues.Y) < .005f,
                "La animación debe conservar el punto del documento bajo el cursor en todos sus fotogramas.");
            anteriorZoom = superficie.Ampliacion;
        }
        superficie.AvanzarZoom(.05);
        exige(Cerca(superficie.Ampliacion, objetivo) && !superficie.ZoomEnCurso && cambiosZoom >= 8,
            "La animación debe llegar al objetivo, avisar durante el movimiento y detener el temporizador al terminar.");
        float terminado = superficie.Ampliacion;
        superficie.AvanzarZoom(1);
        exige(Cerca(superficie.Ampliacion, terminado),
            "Avanzar el reloj después de terminar no debe seguir moviendo el documento.");

        superficie.CambiarZoom(1);
        superficie.ProcesarRueda(60, true, ancla);
        superficie.ProcesarRueda(60, true, ancla);
        float dosMediosPasos = superficie.AmpliacionObjetivo;
        superficie.CambiarZoom(1);
        superficie.ProcesarRueda(120, true, ancla);
        exige(Cerca(superficie.AmpliacionObjetivo, dosMediosPasos),
            "Dos deltas parciales deben acumular el mismo zoom que un paso completo de la rueda.");
        superficie.AvanzarZoom(.035);
        float durante = superficie.Ampliacion;
        superficie.ProcesarRueda(120, true, ancla);
        exige(Cerca(superficie.Ampliacion, durante) && Cerca(superficie.AmpliacionObjetivo, 1.12f * 1.12f),
            "La rueda recibida durante una animación debe acumular el destino sin cambiar bruscamente la ampliación visible.");
        superficie.ProcesarRueda(-120, true, ancla);
        superficie.ProcesarRueda(-120, true, ancla);
        exige(Cerca(superficie.Ampliacion, durante) && Cerca(superficie.AmpliacionObjetivo, 1) && superficie.ZoomEnCurso,
            "Invertir la rueda durante el movimiento debe iniciar el regreso desde el zoom visible y recuperar su objetivo original.");
        superficie.AvanzarZoom(.035);
        exige(superficie.Ampliacion > 1 && superficie.Ampliacion < durante,
            "El primer fotograma al alejar debe disminuir suavemente sin saltar de inmediato al objetivo.");
        superficie.AvanzarZoom(.14);
        exige(Cerca(superficie.Ampliacion, 1) && !superficie.ZoomEnCurso,
            "El regreso animado debe terminar exactamente en la ampliación original.");
        exige(!superficie.ProcesarRueda(120, false, ancla) && Cerca(superficie.Ampliacion, 1),
            "La rueda sin Ctrl debe conservar el zoom y quedar disponible para el desplazamiento normal.");
        superficie.ProcesarRueda(0, true, ancla);
        exige(!superficie.ZoomEnCurso && Cerca(superficie.Ampliacion, 1),
            "Un delta nulo no debe activar un temporizador ni producir movimientos de zoom.");
        superficie.ProcesarRueda(int.MaxValue, true, ancla);
        exige(Cerca(superficie.AmpliacionObjetivo, 5),
            "La rueda acumulada debe limitar su objetivo al 500% antes de dibujar cualquier fotograma.");
        superficie.AvanzarZoom(.2);
        superficie.ProcesarRueda(int.MinValue, true, ancla);
        exige(Cerca(superficie.AmpliacionObjetivo, .1f),
            "Alejar de forma extrema debe limitar el objetivo al 10% y conservar un tamaño de papel válido.");
        superficie.AvanzarZoom(.2);
        superficie.CambiarZoom(100);
        exige(Cerca(superficie.Ampliacion, 5), "La ampliación debe limitarse al 500% sin crear una página rasterizada gigante.");
        superficie.CambiarZoom(.01f);
        exige(Cerca(superficie.Ampliacion, .1f), "El zoom manual debe limitarse al 10% para conservar una página utilizable.");

        superficie.VariasPaginas = false;
        superficie.AjustarPagina();
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize) &&
            superficie.RectanguloPapel.Width <= superficie.ClientSize.Width && superficie.RectanguloPapel.Height <= superficie.ClientSize.Height,
            "Página completa debe ajustar y centrar el papel dentro del área visible.");
        superficie.VariasPaginas = true;
        superficie.AjustarPagina();
        var papeles = superficie.RectangulosPapel;
        var grupo = papeles.Count == 2 ? RectangleF.Union(papeles[0], papeles[1]) : RectangleF.Empty;
        exige(papeles.Count == 2 && papeles[0].Right < papeles[1].Left && PapelCentrado(grupo, superficie.ClientSize),
            "Varias páginas debe mostrar dos hojas separadas y centrar el conjunto completo.");
        superficie.CambiarZoom(1.5f);
        superficie.VariasPaginas = true;
        superficie.Cargar(vista, 0);
        RectangleF segundoPapel = superficie.RectangulosPapel[1];
        var anclaSegunda = new Point((int)(segundoPapel.Left + 60 * dpi), (int)(300 * dpi));
        superficie.ProcesarRueda(120, true, anclaSegunda);
        for (int fotograma = 0; fotograma < 4; fotograma++)
        {
            superficie.AvanzarZoom(.04);
            exige(superficie.RectangulosPapel.Count == 1 && !superficie.VariasPaginas,
                "Acercar desde dos páginas manuales debe recuperar una sola hoja sin usar un ancla fuera de rango de la segunda página retirada.");
        }
        superficie.Arrastrar = true;
        exige(superficie.Arrastrar && superficie.Cursor == Cursors.Hand,
            "La herramienta mano debe activar el desplazamiento del papel con el cursor de arrastre.");
        superficie.Arrastrar = false;
        exige(!superficie.Arrastrar && superficie.Cursor == Cursors.Default,
            "La herramienta puntero debe salir del modo de arrastre.");
        superficie.Cargar(vista, vista.CantidadPaginas - 1);
        exige(superficie.RectangulosPapel.Count == 1,
            "Varias páginas en el final del reporte debe mostrar una sola hoja sin intentar leer una página inexistente.");
        superficie.VariasPaginas = false;
        superficie.Size = new Size(600, 600);
        superficie.Cargar(vista, 0);
        superficie.CambiarZoom(4, Point.Empty);
        // Se muestra el comienzo del contenido, también en monitores con DPI alto.
        int margen = (int)(.4f * superficie.DeviceDpi * superficie.Ampliacion);
        superficie.AutoScrollPosition = new Point(margen, margen);
        VerificarNitidez(superficie, vista, exige);
        superficie.ProcesarRueda(-120, true, ancla);
        superficie.Limpiar();
        exige(superficie.TamanoPapel.IsEmpty && superficie.RectangulosPapel.Count == 0 &&
            !superficie.ZoomEnCurso && !superficie.ProcesarRueda(120, true, ancla),
            "Limpiar debe cancelar la animación pendiente, liberar las páginas y dejar inactivos el dibujo y la rueda.");
        superficie.Cargar(vista, 0);
        superficie.CambiarZoom(1);
        superficie.ProcesarRueda(120, true, ancla);
        superficie.Dispose();
        superficie.AvanzarZoom(.2);
        exige(superficie.IsDisposed && !superficie.ZoomEnCurso && superficie.RectangulosPapel.Count == 0,
            "Cerrar una superficie con zoom pendiente debe liberar el temporizador y evitar nuevos fotogramas sobre páginas descartadas.");
    }

    private static void VerificarCacheYPaginasAutomaticas(Action<bool, string> exige)
    {
        var vista = MYGReportesImpresion.PrepararVista(ReporteLargo());
        using var superficie = new MYGVistaPaginaControl { Dock = DockStyle.None, Size = new Size(1100, 820) };
        superficie.CreateControl();
        superficie.Cargar(vista, 0);
        int inicial = superficie.ContadorGrabaciones;
        superficie.Cargar(vista, 1);
        superficie.Cargar(vista, 0);
        exige(superficie.ContadorGrabaciones == inicial + 1 && superficie.CantidadPaginasCache == 2 && superficie.BytesPaginasCache > 0,
            "Volver a una página visitada debe reutilizar su EMF y mantener sus bytes en la caché, sin volver a dibujar el informe.");
        superficie.VariasPaginas = true;
        superficie.AjustarPagina();
        exige(superficie.RectangulosPapel.Count == 2 && superficie.ContadorGrabaciones == inicial + 1,
            "Elegir y ajustar dos páginas debe reutilizar las dos hojas ya preparadas sin repetir grabaciones.");
        superficie.CambiarZoom(.1f);
        exige(superficie.VariasPaginas && superficie.RectangulosPapel.Count == 2 && Cerca(superficie.Ampliacion, .1f),
            "Alejar hasta el 10% debe mostrar automáticamente dos hojas del mismo plan.");
        superficie.CambiarZoom(5);
        exige(!superficie.VariasPaginas && superficie.RectangulosPapel.Count == 1 && superficie.ContadorGrabaciones == inicial + 1,
            "Acercar debe volver a una hoja y mantener las páginas de la caché, sin repaginar ni grabarlas otra vez.");
        superficie.CambiarZoom(.1f);
        exige(superficie.VariasPaginas && superficie.ContadorGrabaciones == inicial + 1,
            "Volver a alejar debe recuperar inmediatamente las dos páginas conservadas.");
        superficie.VariasPaginas = false;
        int antesColor = superficie.ContadorGrabaciones;
        vista.ColorPagina = Color.Honeydew;
        superficie.Cargar(vista, 0);
        exige(superficie.ContadorGrabaciones == antesColor + 1 && superficie.CantidadPaginasCache == 1,
            "Cambiar el color de la misma vista debe retirar los EMF anteriores y preparar sólo la hoja visible.");
        vista.Filigrana = "NUEVA MARCA";
        superficie.InvalidarPaginas();
        exige(superficie.ContadorGrabaciones == antesColor + 2 && superficie.CantidadPaginasCache == 1,
            "Invalidar la decoración debe actualizar la hoja visible sin conservar la marca anterior.");
        superficie.Limpiar();
        exige(superficie.CantidadPaginasCache == 0 && superficie.BytesPaginasCache == 0,
            "Cerrar o limpiar la superficie debe liberar todas las imágenes vectoriales y sus buffers.");

        var hoja = new MYGHojaMetrado { Nombre = "Breve", Filas = 4, Columnas = 1, CeldaTotal = "A4", AreaImpresion = "A1:A4" };
        hoja.Poner("A1", "REPORTE BREVE");
        hoja.Poner("A4", "0");
        var unica = MYGReportesImpresion.PrepararVista(new[] { new MYGHojaReporteProyecto("Una página", hoja) });
        exige(unica.CantidadPaginas == 1, "El reporte breve de prueba debe producir una sola página.");
        superficie.VariasPaginas = true;
        superficie.Cargar(unica, 0);
        superficie.CambiarZoom(1);
        superficie.CambiarZoom(.1f);
        exige(!superficie.VariasPaginas && superficie.RectangulosPapel.Count == 1,
            "Alejar un reporte de una sola página no debe inventar una segunda hoja.");
    }

    private static void VerificarErroresSuperficie(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        using var superficie = new MYGVistaPaginaControl { Dock = DockStyle.None, Size = new Size(1100, 820) };
        superficie.CreateControl();
        superficie.Cargar(vista, 0);
        superficie.VariasPaginas = true;
        // Los estilos pertenecen al documento de prueba. Un color inválido
        // provoca un fallo real de dibujo, sin sustituir el renderer por un mock.
        foreach (var celda in reportes[0].Hoja.Celdas.Values) celda.ColorTexto = "COLOR_INVALIDO_PARA_PRUEBA";
        bool rechazado = false;
        try { superficie.Cargar(vista, vista.CantidadPaginas - 1); }
        catch (ArgumentException) { rechazado = true; }
        exige(rechazado && superficie.RectangulosPapel.Count == 0 && superficie.CantidadPaginasCache == 0 &&
                superficie.BytesPaginasCache == 0,
            "Un fallo al preparar otra página debe propagarse y retirar por completo el plan, los EMF y los índices anteriores.");

        foreach (var celda in reportes[0].Hoja.Celdas.Values) celda.ColorTexto = "";
        superficie.VariasPaginas = false;
        superficie.Cargar(vista, 0);
        superficie.CambiarZoom(1);
        foreach (var celda in reportes[0].Hoja.Celdas.Values) celda.ColorTexto = "COLOR_INVALIDO_PARA_PRUEBA";
        Exception errorNotificado = null;
        int avisos = 0;
        superficie.ErrorPreparacion += error => { errorNotificado = error; avisos++; };
        superficie.ProcesarRueda(int.MinValue, true, new Point(300, 300));
        var plazo = System.Diagnostics.Stopwatch.StartNew();
        while (errorNotificado == null && plazo.Elapsed < TimeSpan.FromSeconds(3))
        {
            Application.DoEvents();
            System.Threading.Thread.Sleep(10);
        }
        exige(errorNotificado != null && avisos == 1 && !superficie.ZoomEnCurso &&
                superficie.RectangulosPapel.Count == 0 && superficie.CantidadPaginasCache == 0,
            "Un fallo al incorporar la segunda hoja desde el timer debe detener la animación, liberar la vista y notificar una sola vez.");
        superficie.AvanzarZoom(1);
        exige(avisos == 1 && superficie.RectangulosPapel.Count == 0,
            "Después de notificar el fallo no debe repetirse la preparación en nuevos fotogramas.");
        foreach (var celda in reportes[0].Hoja.Celdas.Values) celda.ColorTexto = "";
        superficie.Cargar(vista, 0);
        exige(superficie.RectangulosPapel.Count > 0,
            "Una superficie vaciada por error debe admitir cargar de nuevo un informe corregido.");
    }

    private static void VerificarNitidez(MYGVistaPaginaControl superficie, MYGReportesImpresion.Vista vista,
        Action<bool, string> exige)
    {
        // Sólo se dibuja el área visible de 600 px. La página completa al 400%
        // sigue guardada como vectores y no necesita una captura de varios miles de píxeles.
        using var ampliada = DibujarControl(superficie);
        using var directa = new Bitmap(superficie.Width, superficie.Height);
        directa.SetResolution(96, 96);
        RectangleF papel = superficie.RectanguloPapel;
        using (var g = Graphics.FromImage(directa))
        {
            g.Clear(superficie.BackColor);
            Calidad(g, true);
            g.SetClip(papel);
            g.PageUnit = GraphicsUnit.Inch;
            g.TranslateTransform(papel.X / g.DpiX, papel.Y / g.DpiY);
            SizeF medida = vista.TamanoPagina(0);
            g.ScaleTransform(papel.Width / (medida.Width * g.DpiX), papel.Height / (medida.Height * g.DpiY));
            vista.DibujarPagina(g, 0);
        }
        using var captura96 = Dibujar(vista, 0);
        using var estirada = new Bitmap(superficie.Width, superficie.Height);
        using (var g = Graphics.FromImage(estirada))
        {
            g.Clear(superficie.BackColor);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.DrawImage(captura96, papel);
        }
        var papelVisible = RectangleF.Intersect(papel, new RectangleF(PointF.Empty, superficie.ClientSize));
        var errores = ErrorDeTexto(ampliada, directa, estirada, papelVisible);
        exige(errores.Pixeles > 500 && errores.Vector < errores.Raster,
            "Al 400%, el texto vectorial debe aproximarse al dibujo directo mejor que una captura de 96 DPI estirada.");
    }

    private static void VerificarFondoYBusqueda(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        int encontrada = vista.BuscarPagina("Elemento 170", 0);
        exige(encontrada > 0 && encontrada < vista.CantidadPaginas && vista.BuscarPagina("Texto inexistente", 0) == -1,
            "Buscar debe encontrar el contenido en su página y distinguir un texto ausente.");
        exige(vista.BuscarPagina("Elemento 170", encontrada + 1) == encontrada,
            "La búsqueda debe recorrer el documento y volver al principio cuando el texto queda en una página anterior.");
        using var original = Dibujar(vista, 0);
        vista.ColorPagina = Color.AliceBlue;
        using var coloreada = Dibujar(vista, 0);
        exige(coloreada.GetPixel(8, 8).ToArgb() == Color.AliceBlue.ToArgb(),
            "El color de página debe aplicarse al papel real del mismo plan utilizado para imprimir y exportar.");
        vista.ColorPagina = Color.White;
        vista.Filigrana = "CONFIDENCIAL";
        using var marcada = Dibujar(vista, 0);
        exige(FirmaContenido(marcada) != FirmaContenido(original) && Datos(reportes) == originales,
            "La filigrana debe dibujarse en la página sin modificar las hojas del proyecto.");
    }

    private static void VerificarFormulario(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        using var formulario = new MYGVistaPreliminarReportesForm("Prueba de vista preliminar", reportes);
        exige(formulario.Name == "vista_preliminar_reportes" && formulario.Text.Contains("Prueba de vista preliminar"),
            "La ventana de vista preliminar debe identificar el documento que se configura.");
        var controles = Controles(formulario).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
        string[] nombres = { "vista_impresora", "vista_orientacion", "vista_papel", "vista_fuente", "vista_escala",
            "vista_margen_izquierdo", "vista_margen_derecho", "vista_margen_superior", "vista_margen_inferior",
            "vista_rango", "vista_desde", "vista_hasta", "vista_copias", "vista_imprimir", "vista_pdf", "vista_zoom" };
        exige(nombres.All(controles.ContainsKey),
            "La vista debe ofrecer impresora, papel, orientación, márgenes, fuente, escala, rango, copias, PDF, impresión y ampliación.");
        exige(controles.TryGetValue("vista_cinta", out var cinta) && cinta is TabControl,
            "La vista debe presentar las herramientas en una cinta con grupos y pestaña de previsualización.");
        var accionesBarra = Controles(formulario).OfType<ToolStrip>().SelectMany(b => Acciones(b.Items))
            .Where(a => !string.IsNullOrEmpty(a.Name)).ToDictionary(a => a.Name);
        string[] acciones = { "vista_volver", "vista_imprimir_barra", "vista_pdf_barra", "vista_primera", "vista_anterior",
            "vista_siguiente", "vista_ultima", "vista_alejar", "vista_acercar", "vista_ajustar", "vista_restaurar" };
        string[] accionesImagen = { "vista_impresion_rapida", "vista_escala_barra", "vista_margenes_barra",
            "vista_orientacion_barra", "vista_tamano_barra", "vista_buscar", "vista_varias_paginas",
            "vista_puntero", "vista_mano", "vista_color_pagina", "vista_filigrana", "vista_email", "vista_guardar", "vista_abrir" };
        exige(acciones.Concat(accionesImagen).All(accionesBarra.ContainsKey),
            "La cinta debe incluir impresión, configuración, búsqueda, navegación, zoom, fondo, archivos y modos de puntero/mano.");
        exige(acciones.Concat(accionesImagen).All(nombre => accionesBarra[nombre].Image is { Width: >= 24, Height: >= 24 }),
            "Las herramientas de la cinta deben mostrar iconos de tamaño legible en lugar de botones solo de texto.");
        exige(acciones.Concat(accionesImagen).Except(new[] { "vista_puntero", "vista_mano", "vista_varias_paginas" })
            .All(nombre => accionesBarra[nombre].DisplayStyle == ToolStripItemDisplayStyle.ImageAndText),
            "Las herramientas principales deben acompañar sus iconos con sus nombres.");
        VerificarCinta(formulario, exige);
        var impresora = (ComboBox)controles["vista_impresora"];
        exige(impresora.SelectedIndex < 0,
            "Construir la ventana sin mostrarla no debe seleccionar ni consultar una impresora.");
        formulario.ActualizarVista();
        var superficie = (MYGVistaPaginaControl)controles["vista_superficie"];
        using var primeraImagen = DibujarControl(superficie);
        exige(formulario.CantidadPaginas > 3 && !superficie.TamanoPapel.IsEmpty && TieneContenido(primeraImagen),
            "Actualizar la ventana sin impresora debe generar páginas y dibujar la primera vista real.");
        exige(!Controles(formulario).OfType<PictureBox>().Any(),
            "La vista preliminar debe usar una superficie vectorial y no estirar una captura de baja resolución.");
        exige(!controles["vista_imprimir"].Enabled && controles["vista_pdf"].Enabled,
            "La vista lógica debe permitir preparar PDF y mantener la impresión desactivada hasta elegir una impresora.");
        exige(!accionesBarra["vista_primera"].Enabled && !accionesBarra["vista_anterior"].Enabled &&
            accionesBarra["vista_siguiente"].Enabled && accionesBarra["vista_ultima"].Enabled,
            "La primera página debe ofrecer avance sin permitir navegar antes del comienzo.");
        ulong primera = FirmaContenido(primeraImagen);
        accionesBarra["vista_ultima"].PerformClick();
        using var ultimaImagen = DibujarControl(superficie);
        exige(FirmaContenido(ultimaImagen) != primera && accionesBarra["vista_anterior"].Enabled &&
            !accionesBarra["vista_siguiente"].Enabled,
            "Navegar a la última página debe cambiar el contenido y detener el avance al final.");
        accionesBarra["vista_primera"].PerformClick();
        using var primeraOtraVez = DibujarControl(superficie);
        exige(FirmaContenido(primeraOtraVez) == primera,
            "Volver a la primera página debe recuperar su contenido sin cambiar los datos del reporte.");

        var rango = (CheckBox)controles["vista_rango"];
        var desde = (NumericUpDown)controles["vista_desde"];
        var hasta = (NumericUpDown)controles["vista_hasta"];
        rango.Checked = true; desde.Value = 2; hasta.Value = 3;
        formulario.Configuracion.ConfigurarPagina("A4", "Horizontal", .5m, .5m, .5m, .5m);
        formulario.ActualizarVista();
        exige(desde.Enabled && hasta.Enabled && desde.Value == 2 && hasta.Value == 3,
            "Actualizar la configuración debe conservar el rango de páginas elegido cuando continúa siendo válido.");
        using var horizontal = DibujarControl(superficie);
        exige(superficie.TamanoPapel.Width > superficie.TamanoPapel.Height && TieneContenido(horizontal),
            "Aplicar orientación horizontal debe reconstruir una página ancha con contenido visible.");

        formulario.Configuracion.ConfigurarPagina("A3", "Vertical", .5m, .5m, .5m, .5m);
        formulario.Configuracion.Escala = .5f;
        formulario.ActualizarVista();
        exige(formulario.CantidadPaginas > 0 && superficie.TamanoPapel.Width < superficie.TamanoPapel.Height &&
            desde.Maximum == formulario.CantidadPaginas && hasta.Maximum == formulario.CantidadPaginas,
            "Cambiar papel y escala debe actualizar la imagen y los límites del rango de impresión.");

        formulario.Configuracion.Reportes[0].Hoja.AreaImpresion = "A1:D999";
        Exception error = null;
        try { formulario.ActualizarVista(); }
        catch (InvalidOperationException ex) { error = ex; }
        exige(error != null && formulario.CantidadPaginas == 0 && superficie.TamanoPapel.IsEmpty && superficie.RectangulosPapel.Count == 0,
            "Una configuración que no se puede renderizar debe invalidar la vista anterior y liberar sus páginas vectoriales.");
        exige(!controles["vista_imprimir"].Enabled && !controles["vista_pdf"].Enabled &&
            !accionesBarra["vista_primera"].Enabled && !accionesBarra["vista_ultima"].Enabled,
            "Una vista inválida debe desactivar impresión, PDF y navegación para impedir exportar páginas antiguas.");
        formulario.Configuracion.Restaurar();
        formulario.ActualizarVista();
        exige(formulario.CantidadPaginas > 3 && !superficie.TamanoPapel.IsEmpty,
            "Restaurar después de un error debe permitir reconstruir la vista preliminar.");
        formulario.Close(); formulario.Dispose();
        exige(formulario.IsDisposed && Datos(reportes) == originales,
            "Configurar, navegar, recuperar un error y cerrar la vista preliminar debe dejar intactas las hojas originales.");
    }

    private static void VerificarCinta(MYGVistaPreliminarReportesForm formulario, Action<bool, string> exige)
    {
        formulario.CreateControl();
        var grupos = Controles(formulario).OfType<MYGVistaPreliminarCintaDiseno.GrupoPanel>().ToArray();
        var renderers = grupos.SelectMany(g => g.Controls.OfType<ToolStrip>())
            .ToDictionary(fila => fila, fila => fila.Renderer);
        MYG2027_TemaComercial.Aplicar(formulario);
        exige(renderers.Count > 0 && renderers.All(fila => ReferenceEquals(fila.Key.Renderer, fila.Value) &&
                fila.Key.Renderer.GetType().DeclaringType == typeof(MYGVistaPreliminarCintaDiseno)),
            "Aplicar el tema global de la aplicación debe conservar el renderer de la vista preliminar y la alineación de sus iconos y textos.");
        foreach (var grupo in grupos)
        {
            grupo.CreateControl();
            grupo.Recalcular();
            foreach (var fila in grupo.Controls.OfType<ToolStrip>())
            {
                fila.CreateControl();
                fila.PerformLayout();
            }
        }
        formulario.PerformLayout();
        foreach (var padre in grupos.Select(g => g.Parent).Distinct()) padre.PerformLayout();
        exige(grupos.Length == 7 && grupos.Select(g => g.Height).Distinct().Count() == 1 &&
            grupos.Select(g => g.SeparadorY).Distinct().Count() == 1 &&
            grupos.Select(g => g.Pie.Top).Distinct().Count() == 1 &&
            grupos.Select(g => g.Pie.Height).Distinct().Count() == 1,
            "Los siete grupos de la cinta deben compartir la altura, la línea divisoria y la línea base de sus nombres.");
        foreach (var grupo in grupos)
        {
            float factor = grupo.DeviceDpi / 96f;
            exige(grupo.Pie.TextAlign == ContentAlignment.MiddleCenter && !grupo.Pie.AutoEllipsis &&
                grupo.Pie.Top == grupo.SeparadorY && grupo.Pie.Bottom == grupo.ClientSize.Height,
                "Cada nombre de agrupamiento debe quedar centrado debajo de su línea horizontal, sin texto abreviado.");
            using var contexto = grupo.CreateGraphics();
            Size nombre = TextRenderer.MeasureText(contexto, grupo.Pie.Text, grupo.Pie.Font, Size.Empty,
                TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
            exige(nombre.Width <= grupo.Pie.ClientSize.Width && nombre.Height <= grupo.Pie.ClientSize.Height &&
                grupo.Height <= grupo.Parent.ClientSize.Height,
                "Los títulos completos y sus separadores deben caber en la cinta, incluso cuando aparece la barra de desplazamiento horizontal.");
            foreach (var fila in grupo.Controls.OfType<ToolStrip>())
            {
                exige(fila.Top >= 0 && fila.Left >= 0 && fila.Right <= grupo.ClientSize.Width &&
                    fila.Bottom < grupo.SeparadorY,
                    "Todas las filas de iconos deben quedar completas dentro de su grupo y por encima del separador horizontal.");
                using var dibujo = fila.CreateGraphics();
                foreach (ToolStripItem item in fila.Items)
                {
                    bool pequeno = item.DisplayStyle == ToolStripItemDisplayStyle.Image;
                    int lado = (int)Math.Ceiling((pequeno ? 24 : 32) * factor);
                    int yIcono = (int)Math.Ceiling(4 * factor);
                    exige(item.Image != null && item.Image.Width >= lado && item.Image.Height >= lado &&
                        item.Width >= lado && yIcono + lado <= item.Height && item.Bounds.Right <= fila.ClientSize.Width,
                        "Cada icono debe disponer de todos sus píxeles al DPI actual, sin recorte por el botón ni por su fila.");
                    if (pequeno) continue;
                    int margen = (int)Math.Ceiling(4 * factor);
                    int flecha = item is ToolStripDropDownButton ? (int)Math.Ceiling(14 * factor) : 0;
                    int yTexto = (int)Math.Ceiling(42 * factor);
                    var espacio = new Size(item.Width - 2 * margen - flecha, item.Height - yTexto - margen);
                    Size texto = TextRenderer.MeasureText(dibujo, item.Text, item.Font,
                        new Size(espacio.Width, int.MaxValue), TextFormatFlags.WordBreak | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
                    exige(!string.IsNullOrWhiteSpace(item.Text) && yIcono + lado < yTexto &&
                        texto.Width <= espacio.Width && texto.Height <= espacio.Height,
                        "El nombre completo de cada herramienta debe caber bajo su icono sin invadir la flecha del menú ni quedar cortado.");
                    exige(item.AccessibleName == item.Text.Replace('\n', ' '),
                        "El nombre accesible de cada acción debe conservar el texto completo mostrado en la cinta.");
                }
            }
        }
    }

    private static MYGHojaReporteProyecto[] ReporteLargo()
    {
        var hoja = new MYGHojaMetrado
        {
            Nombre = "Metrados", Filas = 182, Columnas = 3, CeldaTotal = "C182", AreaImpresion = "A1:C182",
            RepetirTitulos = true, FilasInmovilizadas = 2, ImprimirLineasDivision = true,
            AnchosColumnas = new() { [1] = 220, [2] = 120, [3] = 120 }
        };
        hoja.RangosCombinados.Add("A1:C1");
        hoja.Poner("A1", "METRADOS DEL PROYECTO", true);
        hoja.Poner("A2", "Descripción", true); hoja.Poner("B2", "Cantidad", true); hoja.Poner("C2", "Parcial", true);
        for (int fila = 3; fila < 182; fila++)
        {
            hoja.AltosFilas[fila] = 24;
            hoja.Poner("A" + fila, "Elemento " + fila);
            hoja.Poner("B" + fila, fila.ToString(System.Globalization.CultureInfo.InvariantCulture));
            hoja.Poner("C" + fila, "=B" + fila + "*2");
            hoja.Celdas["A" + fila].ColorFondo = fila < 80 ? "D8E9F8" : "E4EBD2";
        }
        hoja.Poner("A182", "TOTAL", true); hoja.Poner("C182", "=SUM(C3:C181)", true);
        hoja.FilasOcultas.AddRange(new[] { 10, 95 });
        // Si la fila oculta entra en el plan, su altura excede el área A4 y su
        // relleno permite detectar que fue dibujada en cualquier página.
        hoja.AltosFilas[10] = 1000;
        foreach (string columna in new[] { "A", "B", "C" }) hoja.Celdas[columna + "10"].ColorFondo = "FF00FF";
        foreach (var celda in hoja.Celdas.Values) celda.Fuente = "Arial";
        MYGHojaCalculo.Validar(hoja);
        return new[] { new MYGHojaReporteProyecto("Metrados de prueba", hoja) };
    }

    private static Bitmap Dibujar(MYGReportesImpresion.Vista vista, int indice)
    {
        SizeF medida = vista.TamanoPagina(indice);
        var imagen = new Bitmap((int)Math.Ceiling(medida.Width * 96), (int)Math.Ceiling(medida.Height * 96));
        imagen.SetResolution(96, 96);
        using var graphics = Graphics.FromImage(imagen);
        graphics.Clear(Color.White);
        Calidad(graphics);
        vista.DibujarPagina(graphics, indice);
        return imagen;
    }

    private static Bitmap DibujarControl(Control control)
    {
        var imagen = new Bitmap(Math.Max(1, control.Width), Math.Max(1, control.Height));
        imagen.SetResolution(96, 96);
        control.DrawToBitmap(imagen, new Rectangle(Point.Empty, imagen.Size));
        return imagen;
    }

    private static RectangleF Proyectar(RectangleF area, SizeF medida, RectangleF papel) => new(
        papel.Left + area.Left / medida.Width * papel.Width,
        papel.Top + area.Top / medida.Height * papel.Height,
        area.Width / medida.Width * papel.Width, area.Height / medida.Height * papel.Height);

    private static bool GuiasVisibles(Bitmap imagen, RectangleF papel, RectangleF area, bool visibles)
    {
        // Las muestras quedan fuera del contenido y lejos del borde del papel.
        // Así detectan las guías completas sin confundirlas con tablas o cabeceras.
        float desdeY = papel.Top + 4, hastaY = papel.Top + (area.Top - papel.Top) * .65f;
        float desdeX = papel.Left + 4, hastaX = papel.Left + (area.Left - papel.Left) * .65f;
        var segmentos = new[]
        {
            (new PointF(area.Left, desdeY), new PointF(area.Left, hastaY)),
            (new PointF(area.Right, desdeY), new PointF(area.Right, hastaY)),
            (new PointF(desdeX, area.Top), new PointF(hastaX, area.Top)),
            (new PointF(desdeX, area.Bottom), new PointF(hastaX, area.Bottom))
        };
        foreach (var (desde, hasta) in segmentos)
        {
            bool vertical = desde.X == hasta.X;
            int longitud = (int)Math.Floor(vertical ? hasta.Y - desde.Y : hasta.X - desde.X);
            int trazos = 0, espacios = 0;
            if (longitud < 6) return false;
            for (int paso = 0; paso <= longitud; paso++)
            {
                bool gris = false, blanco = true;
                for (int desplazamiento = -2; desplazamiento <= 2; desplazamiento++)
                {
                    int x = (int)Math.Round(desde.X + (vertical ? desplazamiento : paso));
                    int y = (int)Math.Round(desde.Y + (vertical ? paso : desplazamiento));
                    if (x < 0 || y < 0 || x >= imagen.Width || y >= imagen.Height) return false;
                    Color color = imagen.GetPixel(x, y);
                    blanco &= color.ToArgb() == Color.White.ToArgb();
                    gris |= color.R == color.G && color.G == color.B && color.R is >= 80 and <= 245;
                }
                if (gris) trazos++;
                if (blanco) espacios++;
                if (!visibles && !blanco) return false;
            }
            if (visibles && (trazos < 2 || espacios < 1)) return false;
        }
        return true;
    }

    private static void Calidad(Graphics graphics, bool textoPantalla = false)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
        graphics.CompositingQuality = CompositingQuality.HighQuality;
        graphics.TextRenderingHint = textoPantalla ? TextRenderingHint.ClearTypeGridFit : TextRenderingHint.AntiAliasGridFit;
    }

    private static bool PapelCentrado(RectangleF papel, Size area) => !papel.IsEmpty &&
        Math.Abs(papel.Left + papel.Width / 2 - area.Width / 2f) < 1.1f &&
        Math.Abs(papel.Top + papel.Height / 2 - area.Height / 2f) < 1.1f;

    private static PointF Relativo(RectangleF papel, Point punto) =>
        new((punto.X - papel.Left) / papel.Width, (punto.Y - papel.Top) / papel.Height);

    private static (double Vector, double Raster, int Pixeles) ErrorDeTexto(Bitmap vector, Bitmap directa,
        Bitmap raster, RectangleF papel)
    {
        double errorVector = 0, errorRaster = 0;
        int pixeles = 0;
        var area = Rectangle.Intersect(Rectangle.Ceiling(papel), new Rectangle(Point.Empty, directa.Size));
        area.Inflate(-3, -3);
        for (int y = area.Top; y < area.Bottom; y++)
            for (int x = area.Left; x < area.Right; x++)
            {
                Color esperado = directa.GetPixel(x, y), real = vector.GetPixel(x, y), antiguo = raster.GetPixel(x, y);
                // Compara contornos de texto y líneas; el papel en blanco no
                // puede ocultar una diferencia de nitidez en unos pocos glifos.
                if (esperado.R + esperado.G + esperado.B >= 540 && real.R + real.G + real.B >= 540 &&
                    antiguo.R + antiguo.G + antiguo.B >= 540) continue;
                errorVector += Math.Abs(real.R - esperado.R) + Math.Abs(real.G - esperado.G) + Math.Abs(real.B - esperado.B);
                errorRaster += Math.Abs(antiguo.R - esperado.R) + Math.Abs(antiguo.G - esperado.G) + Math.Abs(antiguo.B - esperado.B);
                pixeles++;
            }
        return (errorVector, errorRaster, pixeles);
    }

    private static bool TieneContenido(Bitmap imagen)
    {
        int tinta = 0;
        for (int y = 0; y < imagen.Height; y += 4)
            for (int x = 0; x < imagen.Width; x += 4)
                if (imagen.GetPixel(x, y).ToArgb() != Color.White.ToArgb() && ++tinta > 100) return true;
        return false;
    }

    private static ulong FirmaContenido(Bitmap imagen)
    {
        // Excluye el título y el pie: los números de página por sí solos no
        // demuestran que cambió el cuerpo del informe.
        ulong firma = 14695981039346656037;
        for (int y = 96; y < imagen.Height - 96; y += 4)
            for (int x = 48; x < imagen.Width - 48; x += 4)
                firma = unchecked((firma ^ (uint)imagen.GetPixel(x, y).ToArgb()) * 1099511628211);
        return firma;
    }

    private static ulong FirmaRegion(Bitmap imagen, Rectangle region)
    {
        ulong firma = 14695981039346656037;
        Rectangle area = Rectangle.Intersect(region, new Rectangle(Point.Empty, imagen.Size));
        for (int y = area.Top; y < area.Bottom; y += 2)
            for (int x = area.Left; x < area.Right; x += 2)
                firma = unchecked((firma ^ (uint)imagen.GetPixel(x, y).ToArgb()) * 1099511628211);
        return firma;
    }

    private static bool ContieneFilaOculta(Bitmap imagen) => ContieneColor(imagen, Color.Magenta);
    private static bool ContieneColor(Bitmap imagen, Color color)
    {
        for (int y = 0; y < imagen.Height; y += 4)
            for (int x = 0; x < imagen.Width; x += 4)
                if (imagen.GetPixel(x, y).ToArgb() == color.ToArgb()) return true;
        return false;
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Controles(hijo)) yield return descendiente;
        }
    }

    private static IEnumerable<ToolStripItem> Acciones(ToolStripItemCollection items)
    {
        foreach (ToolStripItem item in items)
        {
            yield return item;
            if (item is ToolStripDropDownItem desplegable)
                foreach (var hijo in Acciones(desplegable.DropDownItems)) yield return hijo;
        }
    }

    private static bool Cerca(float a, float b) => Math.Abs(a - b) < .01f;
    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
}
