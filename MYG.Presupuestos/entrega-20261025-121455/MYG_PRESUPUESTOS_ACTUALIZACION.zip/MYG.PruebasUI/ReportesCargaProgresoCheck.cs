using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text.Json;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class ReportesCargaProgresoCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var host = new Form { ClientSize = new Size(1000, 720), ShowInTaskbar = false };
        ExceptionDispatchInfo fallo = null;
        host.Shown += (_, _) =>
        {
            try
            {
                VerificarProductorYPreparacion(host, exige);
                VerificarListaYProgreso(host, exige);
                VerificarError(host, exige);
            }
            catch (Exception ex) { fallo = ExceptionDispatchInfo.Capture(ex); }
            finally { host.Close(); }
        };
        host.ShowDialog();
        fallo?.Throw();
    }

    private static void VerificarProductorYPreparacion(Form host, Action<bool, string> exige)
    {
        var reportes = ReportesDePrueba();
        string originales = JsonSerializer.Serialize(reportes);
        int hiloUi = Environment.CurrentManagedThreadId, producciones = 0, pulsos = 0;
        bool hiloSta = false, cargaVista = false;
        using var continuar = new ManualResetEventSlim();
        using var reloj = new System.Windows.Forms.Timer { Interval = 15 };
        reloj.Tick += (_, _) =>
        {
            pulsos++;
            var carga = host.OwnedForms.OfType<MYGDialogoCarga>().FirstOrDefault();
            if (carga?.EtapaActual == "Componiendo los reportes de prueba…")
            {
                cargaVista = carga.Visible && carga.Opacity == 1 && !host.Enabled;
                continuar.Set();
            }
        };
        reloj.Start();
        using var preparada = MYGVistaPreliminarReportesForm.CrearPreparada(host, "Carga de varios reportes", informar =>
        {
            producciones++;
            hiloSta = Thread.CurrentThread.GetApartmentState() == ApartmentState.STA &&
                Environment.CurrentManagedThreadId != hiloUi;
            informar("Componiendo los reportes de prueba…");
            if (!continuar.Wait(TimeSpan.FromSeconds(10)))
                throw new TimeoutException("La carga de reportes no pudo mostrar su etapa mientras se componían los datos.");
            return reportes;
        });
        reloj.Stop();

        exige(producciones == 1 && hiloSta && cargaVista && pulsos > 0,
            "Componer el informe debe usar un hilo STA independiente mientras la misma ventana de carga actualiza sus etapas y la UI procesa mensajes.");
        exige(host.Enabled && !host.OwnedForms.OfType<MYGDialogoCarga>().Any(),
            "La carga sólo debe retirarse al terminar la preparación completa y restaurar a su propietario.");
        VerificarPreparada(preparada, exige);
        int preparaciones = preparada.PreparacionesVista;
        preparada.Show(host);
        Application.DoEvents();
        exige(preparada.PreparacionesVista == preparaciones && preparaciones == 1,
            "Presentar una vista ya preparada no debe volver a calcular sus fórmulas ni paginar el informe.");
        preparada.Hide();
        exige(JsonSerializer.Serialize(reportes) == originales && reportes.All(r => r.Hoja.Celdas.Values.All(c => c.Fuente == "Arial")),
            "Preparar presupuesto, resumen y metrados debe conservar el contenido y las fuentes del informe original.");
        exige(preparada.Configuracion.Reportes.All(r => r.Hoja.Celdas.Values.All(c => c.Fuente == "Arial Narrow")),
            "La copia preparada debe conservar la fuente predeterminada de las vistas de reportes sin cambiar el documento de origen.");
    }

    private static void VerificarListaYProgreso(Form host, Action<bool, string> exige)
    {
        var reportes = new[] { ReportesDePrueba()[2] };
        string originales = JsonSerializer.Serialize(reportes);
        using var preparada = MYGVistaPreliminarReportesForm.CrearPreparada(host, "Carga de metrados ya compuestos", reportes);
        VerificarPreparada(preparada, exige);
        var etapas = new List<string>();
        var impresoras = Controles(preparada).OfType<ComboBox>().Single(c => c.Name == "vista_impresora");
        var impresora = impresoras.SelectedIndex > 0 ? new PrinterSettings { PrinterName = impresoras.Text } : null;
        var plan = MYGReportesImpresion.PrepararVista(preparada.Configuracion.Reportes,
            preparada.Configuracion.Escala, impresora, preparada.Configuracion.PaginasDeAncho, etapas.Add);
        exige(plan.CantidadPaginas == preparada.CantidadPaginas && plan.CantidadPaginas > 1,
            "El previsualizador ya preparado debe mostrar la misma cantidad de páginas del plan que usa impresión y PDF con su configuración actual.");
        exige(etapas.Any(x => x.Contains("fórmulas", StringComparison.Ordinal)) &&
                etapas.Any(x => x.Contains("alturas", StringComparison.Ordinal)) &&
                etapas.Last().Contains(plan.CantidadPaginas.ToString(CultureInfo.InvariantCulture), StringComparison.Ordinal),
            "La paginación debe informar cálculo de fórmulas, medición de filas y la cantidad real de páginas terminadas.");
        exige(JsonSerializer.Serialize(reportes) == originales,
            "Cargar una lista de informes ya compuestos no debe alterar sus celdas, fórmulas ni configuración guardada.");
    }

    private static void VerificarPreparada(MYGVistaPreliminarReportesForm preparada, Action<bool, string> exige)
    {
        var superficie = Controles(preparada).OfType<MYGVistaPaginaControl>().Single();
        exige(!preparada.Visible && preparada.IsHandleCreated && superficie.IsHandleCreated &&
                preparada.CantidadPaginas > 1 && !superficie.TamanoPapel.IsEmpty && superficie.RectangulosPapel.Count > 0,
            "La fábrica debe devolver la ventana aún oculta, con handles, paginación y primera hoja listos antes de cerrar la carga y presentar el previsualizador.");
    }

    private static void VerificarError(Form host, Action<bool, string> exige)
    {
        bool recibioError = false;
        try
        {
            using var inesperada = MYGVistaPreliminarReportesForm.CrearPreparada(host, "Informe con error",
                (Func<Action<string>, IReadOnlyList<MYGHojaReporteProyecto>>)(informar =>
                {
                    informar("Leyendo las partidas del informe…");
                    throw new InvalidOperationException("fallo controlado de composición del informe");
                }));
        }
        catch (InvalidOperationException ex) when (ex.Message == "fallo controlado de composición del informe")
        { recibioError = true; }
        exige(recibioError && host.Enabled && !host.OwnedForms.OfType<MYGDialogoCarga>().Any(),
            "Un error al componer reportes debe propagarse, cerrar la carga y permitir reintentar sin una ventana huérfana.");
    }

    private static MYGHojaReporteProyecto[] ReportesDePrueba()
    {
        var resultado = new List<MYGHojaReporteProyecto>();
        foreach (string nombre in new[] { "Presupuesto", "Resumen", "Metrados" })
        {
            const int ultima = 150;
            var hoja = new MYGHojaMetrado
            {
                Nombre = nombre, Filas = ultima, Columnas = 3, AreaImpresion = "A1:C150", CeldaTotal = "C150",
                RepetirTitulos = true, FilasInmovilizadas = 2,
                AnchosColumnas = new() { [1] = 220, [2] = 100, [3] = 110 }
            };
            hoja.Poner("A1", nombre.ToUpperInvariant(), true);
            hoja.RangosCombinados.Add("A1:C1");
            hoja.Poner("A2", "Descripción", true); hoja.Poner("B2", "Cantidad", true); hoja.Poner("C2", "Parcial", true);
            for (int fila = 3; fila < ultima; fila++)
            {
                hoja.AltosFilas[fila] = 24;
                hoja.Poner("A" + fila, "Partida o elemento " + fila);
                hoja.Poner("B" + fila, fila.ToString(CultureInfo.InvariantCulture));
                hoja.Poner("C" + fila, "=B" + fila + "*2");
            }
            hoja.Poner("A150", "TOTAL", true); hoja.Poner("C150", "=SUM(C3:C149)", true);
            foreach (var celda in hoja.Celdas.Values) celda.Fuente = "Arial";
            resultado.Add(new MYGHojaReporteProyecto(nombre + " para validar carga", hoja,
                presupuestoObra: nombre == "Presupuesto", resumenProyecto: nombre == "Resumen", listadoMetrados: nombre == "Metrados"));
        }
        return resultado.ToArray();
    }

    private static IEnumerable<Control> Controles(Control control)
    {
        yield return control;
        foreach (Control hijo in control.Controls)
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
    }
}
