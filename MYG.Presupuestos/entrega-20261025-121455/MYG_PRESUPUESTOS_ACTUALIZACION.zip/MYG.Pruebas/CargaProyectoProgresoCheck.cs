using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MYG_2027;

internal static class CargaProyectoProgresoCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Progreso-Proyecto-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "proyectos.sqlite");
            var origen = MYGProyectoStorage.Nuevo("PROYECTO PARA VALIDAR CARGA", "ESTRUCTURAS");
            string idPartida = MYGProyectoStorage.NuevoId();
            var partida = new ItemPresupuestoDelphin
            {
                Id = idPartida, IdLocalMYG = idPartida, IdPropuesta = idPartida, Descripcion = "PARTIDA CON ESPECIFICACIÓN",
                Item = "01", Unidad = "m²", TipoPropuesta = "PARTIDA", Estado = "PROPUESTA", Origen = "MODELO", Posicion = 1
            };
            partida.Costos.EspecificacionTexto = "Descripción técnica que debe sobrevivir a la lectura con progreso.";
            origen.Presupuestos[0].Items.Add(partida);
            origen.Presupuestos.Add(new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 });
            MYGProyectoStorage.Guardar(ruta, origen);
            string firma = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, origen.Id));
            var etapas = new List<string>();
            var leido = MYGBaseDatos.LeerProyecto(ruta, origen.Id, etapas.Add);
            Exige(leido.Presupuestos.Count == 2 && MYGProyectoStorage.Firma(leido) == firma &&
                    leido.Presupuestos[0].Items.Single().Costos.EspecificacionTexto == partida.Costos.EspecificacionTexto,
                "Informar etapas alteró el documento o perdió sus presupuestos.");
            Exige(etapas.Any(x => x.Contains("SQLite", StringComparison.Ordinal)) &&
                    etapas.Any(x => x.Contains("presupuestos", StringComparison.Ordinal)) &&
                    etapas.Last().Contains("Validando", StringComparison.Ordinal),
                "La lectura no informó conexión, contenido y validación real.");
            Exige(MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, origen.Id)) == firma,
                "La lectura con progreso modificó el proyecto persistido.");
            etapas.Clear();
            bool rechazado = false;
            try { MYGBaseDatos.LeerProyecto(ruta, "proyecto-inexistente", etapas.Add); }
            catch (InvalidDataException) { rechazado = true; }
            Exige(rechazado && etapas.Count > 0 && !etapas.Any(x => x.StartsWith("Validando", StringComparison.Ordinal)),
                "Una lectura fallida anunció la validación de un documento que no existe.");
            pasa("Carga de proyectos informa etapas de SQLite, contenido y validación sin alterar presupuestos ni ocultar errores");
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new InvalidOperationException(detalle); }
}
