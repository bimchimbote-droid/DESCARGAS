using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace MYG_2027;

internal static partial class MYGEspecificacionesDocumento
{
    // RichEdit compone sobre un contexto de pantalla y registra cada página en
    // EMF. No se abre Office, no se enumera una impresora y no se imprime papel.
    internal static (PreviewPageInfo[] Paginas, MemoryStream[] Flujos) CrearPaginasNativas(
        RichTextBox editor, PageSettings pagina, string encabezado, string pie, bool numeroPagina,
        Action<string> progreso = null)
    {
        ArgumentNullException.ThrowIfNull(editor);
        ArgumentNullException.ThrowIfNull(pagina);
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("La vista de especificaciones utiliza RichEdit de Windows.");
        if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
            throw new InvalidOperationException("La vista de especificaciones debe prepararse en un hilo STA de Windows.");

        // Con PaperSize explícito, Bounds sólo aplica la orientación al papel.
        // No se consultan HardMargin ni capacidades de PrinterSettings.
        Rectangle papel = pagina.Bounds;
        var margenes = pagina.Margins;
        if (papel.Width is <= 0 or > 10000 || papel.Height is <= 0 or > 10000 ||
            margenes.Left < 0 || margenes.Right < 0 || margenes.Top < 0 || margenes.Bottom < 0)
            throw new InvalidOperationException("El tamaño de papel o los márgenes no son válidos.");
        var interior = new Rectangle(margenes.Left, margenes.Top,
            papel.Width - margenes.Left - margenes.Right, papel.Height - margenes.Top - margenes.Bottom);
        var contenido = interior;
        const int reserva = 34;
        if (!string.IsNullOrEmpty(encabezado)) { contenido.Y += reserva; contenido.Height -= reserva; }
        if (!string.IsNullOrEmpty(pie) || numeroPagina) contenido.Height -= reserva;
        if (contenido.Width <= 0 || contenido.Height <= 0)
            throw new InvalidOperationException("Los márgenes no dejan espacio para las especificaciones.");

        var paginas = new List<PreviewPageInfo>();
        var flujos = new List<MemoryStream>();
        // La nueva vista conserva también la familia elegida por el usuario.
        using var copia = new RichTextBox { Font = editor.Font, DetectUrls = false, Rtf = editor.Rtf };
        try
        {
            var saltos = ObtenerSaltosPagina(copia);
            using var referencia = copia.CreateGraphics();
            IntPtr hdcReferencia = referencia.GetHdc();
            try
            {
                int inicio = 0;
                do
                {
                    progreso?.Invoke("Preparando la página " + (paginas.Count + 1).ToString(CultureInfo.CurrentCulture) + "…");
                    int limite = copia.TextLength;
                    foreach (int salto in saltos)
                        if (salto > inicio) { limite = salto; break; }
                    MemoryStream flujo = null;
                    Metafile imagen = null;
                    try
                    {
                        flujo = new MemoryStream();
                        imagen = new Metafile(flujo, hdcReferencia,
                            new RectangleF(0, 0, papel.Width / 100f, papel.Height / 100f),
                            MetafileFrameUnit.Inch, EmfType.EmfPlusDual);
                        using (var dibujo = Graphics.FromImage(imagen))
                        {
                            // GDI de RichEdit y GDI+ usan los mismos píxeles del
                            // contexto de referencia; el marco EMF guarda sus pulgadas.
                            dibujo.PageUnit = GraphicsUnit.Pixel;
                            dibujo.FillRectangle(Brushes.White, 0, 0,
                                papel.Width * dibujo.DpiX / 100f, papel.Height * dibujo.DpiY / 100f);
                            IntPtr hdcDibujo = dibujo.GetHdc();
                            int siguiente;
                            try
                            {
                                var rango = new FormatRange
                                {
                                    Hdc = hdcDibujo, HdcTarget = hdcReferencia,
                                    Pagina = RectanguloTwips(papel, 0, 0),
                                    Contenido = RectanguloTwips(contenido, 0, 0),
                                    Caracteres = new CharacterRange { Inicio = inicio, Fin = limite }
                                };
                                siguiente = checked((int)SendMessageFormato(copia.Handle, EmFormatRange, new IntPtr(1), ref rango));
                            }
                            finally
                            {
                                dibujo.ReleaseHdc(hdcDibujo);
                                // La siguiente página utiliza otro HDC EMF.
                                // RichEdit no debe retener la caché de éste.
                                LiberarFormato(copia);
                            }
                            if (inicio < copia.TextLength && (siguiente <= inicio || siguiente > limite))
                                throw new InvalidOperationException("No se pudo distribuir el documento. Revise el tamaño de papel y los márgenes.");
                            inicio = siguiente;
                            DibujarEncabezadoPieNativo(dibujo, interior, encabezado, pie,
                                numeroPagina ? paginas.Count + 1 : 0, reserva);
                        }
                        paginas.Add(new PreviewPageInfo(imagen, papel.Size));
                        flujos.Add(flujo);
                        imagen = null;
                        flujo = null;
                    }
                    finally
                    {
                        imagen?.Dispose();
                        flujo?.Dispose();
                    }
                } while (inicio < copia.TextLength);
            }
            finally { referencia.ReleaseHdc(hdcReferencia); }
            return (paginas.ToArray(), flujos.ToArray());
        }
        catch
        {
            try { foreach (var hoja in paginas) hoja.Image?.Dispose(); }
            finally { foreach (var flujo in flujos) flujo.Dispose(); }
            throw;
        }
        finally { LiberarFormato(copia); }
    }

    private static void DibujarEncabezadoPieNativo(Graphics dibujo, Rectangle interior,
        string encabezado, string pie, int numero, int reserva)
    {
        using var fuente = new Font("Arial", 9);
        using var formato = new StringFormat
        {
            Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center,
            Trimming = StringTrimming.EllipsisCharacter
        };
        float escalaX = dibujo.DpiX / 100f, escalaY = dibujo.DpiY / 100f;
        if (!string.IsNullOrEmpty(encabezado))
            dibujo.DrawString(encabezado, fuente, Brushes.Black,
                new RectangleF(interior.X * escalaX, interior.Y * escalaY,
                    interior.Width * escalaX, reserva * escalaY), formato);
        if (!string.IsNullOrEmpty(pie) || numero > 0)
        {
            string texto = pie ?? "";
            if (numero > 0) texto += (texto.Length > 0 ? "   ·   " : "") + "Página " + numero.ToString(CultureInfo.CurrentCulture);
            formato.Alignment = StringAlignment.Far;
            dibujo.DrawString(texto, fuente, Brushes.Black,
                new RectangleF(interior.X * escalaX, (interior.Bottom - reserva) * escalaY,
                    interior.Width * escalaX, reserva * escalaY), formato);
        }
    }
}
