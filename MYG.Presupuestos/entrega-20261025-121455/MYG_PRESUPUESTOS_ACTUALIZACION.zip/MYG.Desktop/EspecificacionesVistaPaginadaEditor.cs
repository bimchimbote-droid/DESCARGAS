using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGEspecificacionesEditor
{
    private MYGEspecificacionesVistaPaginada vistaPaginada;
    private bool vistaPaginadaActiva, actualizacionPaginadaPendiente;
    private bool reglaVerticalAntesPrevia = true;
    private string rtfVistaPaginada;
    private string formatoEntrega = ".docx";
    private ToolStripComboBox selectorFormatoEntrega;
    private readonly Dictionary<string, MYGEspecificacionesEntregaPaginada> entregasPreparadas = new();
    private readonly LinkedList<string> ordenEntregas = new();
    private string contenidoEntregas;
    private const long LimiteBytesEntregas = 256L * 1024 * 1024;

    internal string ExtensionEntrega => formatoEntrega;

    private void PrepararVistaPaginadaExportacion()
    {
        if (vistaPaginada != null) return;
        vistaPaginada = new MYGEspecificacionesVistaPaginada { Dock = DockStyle.Fill, Visible = false };
        lienzo.Parent.Controls.Add(vistaPaginada);
        var fichero = (FlowLayoutPanel)cinta.TabPages[0].Controls[0];
        var grupoFormato = MYGEspecificacionesCinta.Grupo(fichero, "Formato de salida", 210);
        selectorFormatoEntrega = new ToolStripComboBox
        {
            Name = "espec_formato_entrega", AccessibleName = "Formato del documento que se muestra y exporta",
            DropDownStyle = ComboBoxStyle.DropDownList, AutoSize = false, Width = 185
        };
        selectorFormatoEntrega.Items.AddRange(new object[] { "Documento Word (.docx)", "Documento RTF (.rtf)", "Word 97-2003 (.doc; requiere Word)" });
        selectorFormatoEntrega.SelectedIndex = 0;
        selectorFormatoEntrega.SelectedIndexChanged += (_, _) =>
        {
            formatoEntrega = selectorFormatoEntrega.SelectedIndex switch { 1 => ".rtf", 2 => ".doc", _ => ".docx" };
            rtfVistaPaginada = null;
            ActualizarDocumentoVistaPaginada();
        };
        MYGEspecificacionesCinta.Fila(grupoFormato, 16, selectorFormatoEntrega);
        cinta.SelectedIndexChanged += (_, _) => ActualizarModoVistaPaginada();
        documento.TextChanged += (_, _) => ProgramarActualizacionVistaPaginada();
        ActualizarModoVistaPaginada();
    }

    private void ActualizarModoVistaPaginada()
    {
        if (vistaPaginada == null || IsDisposed || Disposing) return;
        bool mostrar = modoExportacion && cinta.SelectedIndex == 0;
        if (mostrar && !vistaPaginadaActiva)
        {
            CancelarArrastreMargenes(); DetenerZoom();
            if (lienzo.Visible) reglaVerticalAntesPrevia = reglaVertical.Visible;
        }
        vistaPaginadaActiva = mostrar;
        lienzo.Visible = !mostrar;
        regla.Visible = !mostrar && verRegla.Checked;
        reglaVertical.Visible = !mostrar && reglaVerticalAntesPrevia;
        vistaPaginada.Visible = mostrar;
        if (mostrar)
        {
            vistaPaginada.BringToFront();
            ActualizarDocumentoVistaPaginada();
        }
        else
        {
            // La vista deja de tomar prestadas las páginas. La caché conserva
            // las entregas hasta que cambie el contenido o se cierre el editor.
            vistaPaginada.LiberarDocumento();
            rtfVistaPaginada = null;
            ActualizarVista();
        }
    }

    private void ActualizarDocumentoVistaPaginada()
    {
        if (!vistaPaginadaActiva || vistaPaginada == null || IsDisposed || Disposing) return;
        string rtf = DocumentoRtf, clave = formatoEntrega + rtf;
        if (clave == rtfVistaPaginada) return;
        try
        {
            int paginaAnterior = Math.Max(1, vistaPaginada.PaginaActual);
            AsegurarContenidoEntregas(rtf);
            string extension = formatoEntrega;
            var crear = entregasPreparadas.ContainsKey(extension) ? null : CrearSolicitudEntrega(extension);
            vistaPaginada.Cargar(() =>
            {
                if (ObtenerEntregaPreparada(extension, out var preparada)) return preparada;
                var generada = MYGCargaAnimada.EjecutarSta(FindForm(),
                    "Preparando vista preliminar de especificaciones…", crear);
                RegistrarEntrega(extension, generada);
                return generada;
            }, liberarEntrega: false, paginaInicial: paginaAnterior);
            rtfVistaPaginada = clave;
            // Un formato ya visitado se presenta ahora, sin volver a iniciar
            // Word ni esperar al siguiente callback de pintura.
            if (entregasPreparadas.ContainsKey(extension)) vistaPaginada.PrepararEntregaAhora();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            vistaPaginada.MostrarError("No se pudo preparar la vista por páginas. " + ex.Message);
        }
    }

    private Func<Action<string>, MYGEspecificacionesEntregaPaginada> CrearSolicitudEntrega(string extension)
    {
        // Capturar únicamente datos en el hilo de UI. El RichTextBox del trabajo
        // pertenece al hilo STA aislado; nunca se pasa el control del editor.
        string contenido = documento.Rtf;
        string rtfArchivo = extension == ".rtf" ? RtfParaArchivo : null;
        var configuracion = ConfiguracionImpresion();
        string encabezado = pagina.Encabezado, pie = pagina.Pie;
        bool numerar = pagina.NumerarPaginas;
        return informar =>
        {
            informar?.Invoke("Cargando el contenido y la configuración de las hojas…");
            using var copia = new RichTextBox { Rtf = contenido, DetectUrls = false };
            return MYGEspecificacionesDocumento.CrearEntregaParaVista(copia, extension, configuracion,
                encabezado, pie, numerar, rtfArchivo, progreso: informar);
        };
    }

    internal async Task PrepararEntregaInicialAsync(IProgress<string> progreso)
    {
        MostrarVistaPreviaExportacionDirecta();
        string rtf = DocumentoRtf, extension = formatoEntrega;
        AsegurarContenidoEntregas(rtf);
        if (!ObtenerEntregaPreparada(extension, out var preparada))
        {
            preparada = await MYGCargaAnimada.EnStaAsync(CrearSolicitudEntrega(extension), progreso.Report);
            RegistrarEntrega(extension, preparada);
        }
        vistaPaginada.Cargar(() => preparada, liberarEntrega: false);
        rtfVistaPaginada = extension + rtf;
        if (!vistaPaginada.PrepararEntregaAhora())
            throw new InvalidOperationException("No se pudo preparar la vista preliminar de especificaciones.");
    }

    private void AsegurarContenidoEntregas(string rtf)
    {
        if (rtf == contenidoEntregas) return;
        LiberarEntregasPreparadas();
        contenidoEntregas = rtf;
    }

    private bool ObtenerEntregaPreparada(string extension, out MYGEspecificacionesEntregaPaginada preparada)
    {
        if (!entregasPreparadas.TryGetValue(extension, out preparada)) return false;
        ordenEntregas.Remove(extension);
        ordenEntregas.AddLast(extension);
        return true;
    }

    private void RegistrarEntrega(string extension, MYGEspecificacionesEntregaPaginada preparada)
    {
        entregasPreparadas.Add(extension, preparada);
        ordenEntregas.AddLast(extension);
        // Tres formatos como máximo; además acotar los bytes EMF retenidos.
        // La entrega actual permanece utilizable aunque ella sola supere el tope.
        while (entregasPreparadas.Count > 1 && entregasPreparadas.Values.Sum(e => e.BytesPaginas) > LimiteBytesEntregas)
        {
            string anterior = ordenEntregas.First.Value;
            ordenEntregas.RemoveFirst();
            var retirar = entregasPreparadas[anterior];
            entregasPreparadas.Remove(anterior);
            retirar.Dispose();
        }
    }

    private void LiberarEntregasPreparadas()
    {
        vistaPaginada?.LiberarDocumento();
        foreach (var preparada in entregasPreparadas.Values) preparada.Dispose();
        entregasPreparadas.Clear();
        ordenEntregas.Clear();
        contenidoEntregas = null;
    }

    private void ProgramarActualizacionVistaPaginada()
    {
        if (!vistaPaginadaActiva || actualizacionPaginadaPendiente || !IsHandleCreated || IsDisposed || Disposing) return;
        actualizacionPaginadaPendiente = true;
        BeginInvoke(new Action(() =>
        {
            actualizacionPaginadaPendiente = false;
            if (!IsDisposed && !Disposing) ActualizarDocumentoVistaPaginada();
        }));
    }

    private void MostrarVistaPreliminarPaginada()
    {
        // Una petición explícita también reintenta aunque el texto no haya cambiado.
        rtfVistaPaginada = null;
        cinta.SelectedIndex = 0;
        ActualizarModoVistaPaginada();
        vistaPaginada?.Focus();
    }

    // La ventana llama también desde Shown: la primera vista siempre es la
    // entrega paginada, sin una casilla ni una orden previa del usuario.
    internal void MostrarVistaPreviaExportacionDirecta()
    {
        cinta.SelectedIndex = 0;
        PrepararVistaPaginadaExportacion();
        ActualizarModoVistaPaginada();
    }

    internal void GuardarEntregaExportacion(string ruta)
    {
        string extension = Path.GetExtension(ruta).ToLowerInvariant();
        int indice = extension switch { ".docx" => 0, ".rtf" => 1, ".doc" => 2,
            _ => throw new InvalidOperationException("Elija una extensión .doc, .docx o .rtf.") };
        MostrarVistaPreviaExportacionDirecta();
        selectorFormatoEntrega.SelectedIndex = indice;
        var entrega = ExigirEntregaExportacion();
        if (entrega.Extension != extension)
            throw new InvalidOperationException("El formato de la vista previa no corresponde al destino.");
        entrega.Guardar(ruta);
    }

    private MYGEspecificacionesEntregaPaginada ExigirEntregaExportacion()
    {
        MostrarVistaPreviaExportacionDirecta();
        // Reintentar si la preparación anterior falló.
        if (vistaPaginada.EntregaActual == null) rtfVistaPaginada = null;
        ActualizarDocumentoVistaPaginada();
        if (!vistaPaginada.PrepararEntregaAhora() || vistaPaginada.EntregaActual == null)
            throw new InvalidOperationException("No se pudo preparar el documento de entrega. Revise el mensaje de la vista previa.");
        return vistaPaginada.EntregaActual;
    }

    private void ImprimirEntregaExportacion()
    {
        var entrega = ExigirEntregaExportacion();
        // Imprimir las mismas páginas vectoriales de la vista evita recomponer
        // el texto con otra fuente o motor al enviar el trabajo a la impresora.
        using var impresion = new PrintDocument { DocumentName = titulo(), DefaultPageSettings = ConfiguracionImpresion() };
        int indice = 0;
        impresion.BeginPrint += (_, _) => indice = 0;
        impresion.QueryPageSettings += (_, e) =>
        {
            var medida = entrega.Paginas[indice].PhysicalSize;
            bool horizontal = medida.Width > medida.Height;
            e.PageSettings.PaperSize = new PaperSize("MYG", horizontal ? medida.Height : medida.Width,
                horizontal ? medida.Width : medida.Height);
            e.PageSettings.Landscape = horizontal;
        };
        impresion.PrintPage += (_, e) =>
        {
            var hoja = entrega.Paginas[indice++];
            var destino = new RectangleF(-e.PageSettings.HardMarginX, -e.PageSettings.HardMarginY,
                hoja.PhysicalSize.Width, hoja.PhysicalSize.Height);
            e.Graphics.DrawImage(hoja.Image, destino);
            e.HasMorePages = indice < entrega.Paginas.Length;
        };
        using var dialogo = new PrintDialog { Document = impresion, UseEXDialog = true, AllowSomePages = false, AllowSelection = false };
        if (dialogo.ShowDialog(this) == DialogResult.OK) impresion.Print();
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (vistaPaginadaActiva && keyData == (Keys.Control | Keys.S))
        { Intentar(() => guardarExportacion?.Invoke()); return true; }
        if (vistaPaginadaActiva && keyData == (Keys.Control | Keys.P))
        { Intentar(() => Imprimir(false)); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }
}
