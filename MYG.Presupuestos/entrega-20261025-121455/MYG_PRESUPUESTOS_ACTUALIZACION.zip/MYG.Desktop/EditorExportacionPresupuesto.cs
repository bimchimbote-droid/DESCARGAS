using System;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private void ExportarDestinoPresupuesto(MYGDestinoExportacionCronograma destino)
    {
        if (!Enum.IsDefined(destino)) throw new ArgumentOutOfRangeException(nameof(destino));
        if (destino is MYGDestinoExportacionCronograma.Nativo or
            MYGDestinoExportacionCronograma.ProjectTareas or MYGDestinoExportacionCronograma.ProjectRecursos or
            MYGDestinoExportacionCronograma.XmlTareas or MYGDestinoExportacionCronograma.XmlRecursos)
        {
            // Estos formatos conservan el proyecto y su programación, también
            // cuando se accede a ellos desde la cinta del presupuesto.
            panelCronograma.ExportarDestino(destino, archivo);
            return;
        }

        if (P == null) throw new InvalidOperationException("Seleccione un presupuesto para exportar.");
        if (destino == MYGDestinoExportacionCronograma.Xlsx)
        {
            // El libro existente incluye las hojas auxiliares y sus fórmulas.
            panelPresupuesto.ExportarPresupuesto();
            return;
        }

        if (destino == MYGDestinoExportacionCronograma.Pdf)
        {
            var proyecto = documento;
            string presupuestoId = P.Id;
            using var vista = MYGVistaPreliminarReportesForm.CrearPreparada(this, "Presupuesto",
                informar => MYGReportesProyecto.Crear(proyecto, presupuestoId, MYGTipoReporteProyecto.PresupuestoSeleccionado, informar),
                validarDestino: (ruta, extension) => MYGExportacionCronogramaWindows.ValidarDestino(ruta, extension, archivo));
            vista.Shown += (_, _) => vista.BeginInvoke((Action)(() => vista.ExportarComo(MYGFormatoVistaReporte.Pdf)));
            vista.ShowDialog(this);
            return;
        }

        var reportes = MYGReportesProyecto.Crear(documento, P.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado);

        (string extension, string descripcion, MYGFormatoExportacionReporte formato) = destino switch
        {
            MYGDestinoExportacionCronograma.Texto => ("txt", "Texto de presupuesto", MYGFormatoExportacionReporte.Texto),
            MYGDestinoExportacionCronograma.Mht => ("mht", "Página web de archivo único", MYGFormatoExportacionReporte.Mht),
            MYGDestinoExportacionCronograma.Csv => ("csv", "Lista de partidas CSV", MYGFormatoExportacionReporte.Csv),
            _ => throw new ArgumentOutOfRangeException(nameof(destino))
        };
        using var dialogo = new SaveFileDialog
        {
            Title = "Exportar presupuesto · " + descripcion, AddExtension = true, DefaultExt = extension,
            Filter = descripcion + " (*." + extension + ")|*." + extension, FileName = "Presupuesto." + extension
        };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        MYGExportacionCronogramaWindows.ValidarDestino(dialogo.FileName, extension, archivo);
        MYGReportesExportacion.Guardar(dialogo.FileName, formato, reportes);
        estado.Text = "Presupuesto exportado: " + dialogo.FileName;
    }
}
