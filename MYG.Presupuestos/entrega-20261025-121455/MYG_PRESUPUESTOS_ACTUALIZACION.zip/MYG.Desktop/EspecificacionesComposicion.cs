using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Compone una copia editable del informe sin alterar las especificaciones de origen.</summary>
internal static class MYGEspecificacionesComposicion
{
    internal static string Crear(MYGProyectoDocumento proyecto, MYGAlcanceEspecificaciones alcance,
        string presupuestoId = null, Action<string> progreso = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        var secciones = MYGEspecificacionesExportacion.Seleccionar(proyecto, alcance, presupuestoId);
        int total = secciones.Sum(s => s.Partidas.Count), preparadas = 0;
        progreso?.Invoke("Preparando portada y datos del proyecto…");
        using var fuente = FuenteReferencia();
        using var documento = new RichTextBox
        {
            Font = fuente, DetectUrls = false, AcceptsTab = true,
            MaxLength = int.MaxValue, WordWrap = true
        };

        var cabecera = CabeceraRtf(fuente.Name);
        cabecera.Append(@"\pard\plain\qc\f0\fs28\b ")
            .Append(Escapar("ESPECIFICACIONES TECNICAS")).Append(@"\b0\par\par ");
        var datos = proyecto.Datos;
        AgregarDato(cabecera, "PROYECTO", proyecto.Nombre);
        AgregarDato(cabecera, "PRESUPUESTO", alcance == MYGAlcanceEspecificaciones.Proyecto
            ? "TODOS LOS PRESUPUESTOS" : secciones[0].Presupuesto.Nombre);
        AgregarDato(cabecera, "PROPIETARIO", datos?.Propietario);
        AgregarDato(cabecera, "LOCALIDAD", datos?.Localidad);
        AgregarDato(cabecera, "DISTRITO", datos?.Distrito);
        AgregarDato(cabecera, "PROVINCIA", datos?.Provincia);
        AgregarDato(cabecera, "DEPARTAMENTO", datos?.Departamento);
        AgregarDato(cabecera, "FECHA PROY", datos?.FechaElaboracion?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
        cabecera.Append(@"\pard\plain\ql\f0\fs22\par }");
        AgregarRtf(documento, cabecera.ToString());

        foreach (var seccion in secciones)
        {
            if (alcance == MYGAlcanceEspecificaciones.Proyecto)
            {
                var encabezadoPresupuesto = CabeceraRtf(fuente.Name);
                AgregarDato(encabezadoPresupuesto, "PRESUPUESTO", seccion.Presupuesto.Nombre);
                encabezadoPresupuesto.Append(@"\pard\plain\ql\f0\fs22\par }");
                AgregarRtf(documento, encabezadoPresupuesto.ToString());
            }

            foreach (var partida in seccion.Partidas)
            {
                preparadas++;
                if (preparadas == 1 || preparadas % 10 == 0 || preparadas == total)
                    progreso?.Invoke($"Componiendo especificaciones: partida {preparadas} de {total}…");
                string codigo = CodigoVisible(seccion.Presupuesto, partida);
                string nombre = string.IsNullOrWhiteSpace(codigo) ? partida.Descripcion ?? ""
                    : codigo + "  " + (partida.Descripcion ?? "");
                var encabezadoPartida = CabeceraRtf(fuente.Name);
                encabezadoPartida.Append(@"\pard\plain\ql\f0\fs22\b ")
                    .Append(Escapar(nombre)).Append(@"\b0 ")
                    .Append(Escapar("   (unidad de medida: " + (partida.Unidad ?? "") + ")"))
                    .Append(@"\par }");
                AgregarRtf(documento, encabezadoPartida.ToString());

                using var contenido = CargarFuente(partida, fuente);
                int inicio = InicioCuerpo(contenido.Text, codigo, partida);
                if (inicio < contenido.TextLength)
                {
                    // RichEdit combina las tablas de fuentes, colores y listas de cada
                    // fragmento. El cuerpo no recibe cambios de formato posteriores.
                    contenido.Select(inicio, contenido.TextLength - inicio);
                    AgregarRtf(documento, contenido.SelectedRtf);
                }

                // Cerrar primero el párrafo de origen conserva su alineación y sangrías.
                // El siguiente párrafo vuelve a los valores del informe, sin heredar listas.
                var separador = CabeceraRtf(fuente.Name);
                separador.Append(@"\par\pard\plain\ql\f0\fs22\par }");
                AgregarRtf(documento, separador.ToString());
            }
        }

        progreso?.Invoke("Preparando el documento consolidado y sus márgenes…");
        return MYGEspecificacionesPagina.Guardar(documento.Rtf, new MYGPaginaEspecificacion
        {
            AnchoMm = 210, AltoMm = 297,
            MargenIzquierdoMm = 20, MargenDerechoMm = 20,
            MargenSuperiorMm = 20, MargenInferiorMm = 20
        });
    }

    private static RichTextBox CargarFuente(ItemPresupuestoDelphin partida, Font fuente)
    {
        var contenido = new RichTextBox
        {
            Font = fuente, DetectUrls = false, AcceptsTab = true, MaxLength = int.MaxValue
        };
        string rtf = partida.Costos?.EspecificacionRtf ?? "";
        string texto = partida.Costos?.EspecificacionTexto ?? "";
        try
        {
            if (string.IsNullOrWhiteSpace(rtf)) contenido.Text = texto;
            else
            {
                // Guardar valida el documento completo; QuitarMetadatos deja el contenido
                // de origen sin la configuración de página particular de esa partida.
                contenido.Rtf = MYGEspecificacionesPagina.QuitarMetadatos(
                    MYGEspecificacionesPagina.Guardar(rtf, new MYGPaginaEspecificacion()));
            }
            return contenido;
        }
        catch (ArgumentException ex)
        {
            if (!string.IsNullOrEmpty(texto))
            {
                contenido.Clear();
                contenido.Text = texto;
                return contenido;
            }
            contenido.Dispose();
            throw new InvalidOperationException("La especificación de la partida «" + partida.Item + " " +
                partida.Descripcion + "» contiene un RTF no válido y no dispone de texto recuperable.", ex);
        }
        catch
        {
            contenido.Dispose();
            throw;
        }
    }

    private static int InicioCuerpo(string texto, string codigo, ItemPresupuestoDelphin partida)
    {
        // Retirar únicamente el encabezado reconocible de Insertar título o de la
        // plantilla antigua. Las demás líneas, espacios y estilos son parte del cuerpo.
        int inicio = 0;
        string primera = LeerLinea(texto, ref inicio);
        while (string.IsNullOrWhiteSpace(primera) && inicio < texto.Length)
            primera = LeerLinea(texto, ref inicio);
        string unidad = "(unidad de medida: " + (partida.Unidad ?? "") + ")";
        foreach (string prefijo in new[] { codigo, partida.Item, "" })
        {
            string nombre = string.IsNullOrWhiteSpace(prefijo) ? partida.Descripcion ?? ""
                : prefijo + " " + (partida.Descripcion ?? "");
            if (IgualLinea(primera, nombre + " " + unidad)) return inicio;
            if (!IgualLinea(primera, nombre)) continue;
            int siguiente = inicio;
            string segunda = LeerLinea(texto, ref siguiente);
            if (IgualLinea(segunda, "Unidad de medida: " + (partida.Unidad ?? ""))) return siguiente;
        }
        return 0;
    }

    private static string LeerLinea(string texto, ref int posicion)
    {
        int inicio = posicion;
        while (posicion < texto.Length && texto[posicion] is not '\r' and not '\n') posicion++;
        string linea = texto.Substring(inicio, posicion - inicio);
        if (posicion < texto.Length && texto[posicion] == '\r') posicion++;
        if (posicion < texto.Length && texto[posicion] == '\n') posicion++;
        return linea;
    }

    private static bool IgualLinea(string a, string b) =>
        string.Equals(NormalizarLinea(a), NormalizarLinea(b), StringComparison.OrdinalIgnoreCase);

    private static string NormalizarLinea(string texto)
    {
        var resultado = new StringBuilder();
        bool espacio = false;
        foreach (char caracter in texto ?? "")
        {
            if (char.IsWhiteSpace(caracter)) { espacio = resultado.Length > 0; continue; }
            if (espacio) resultado.Append(' ');
            resultado.Append(caracter); espacio = false;
        }
        return resultado.ToString().Replace(" :", ":").Replace(": ", ":");
    }

    private static string CodigoVisible(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida) =>
        string.IsNullOrWhiteSpace(presupuesto.Item) ? partida.Item ?? ""
            : string.IsNullOrWhiteSpace(partida.Item) ? presupuesto.Item : presupuesto.Item + "." + partida.Item;

    private static void AgregarRtf(RichTextBox documento, string rtf)
    {
        documento.Select(documento.TextLength, 0);
        documento.SelectedRtf = rtf;
    }

    private static StringBuilder CabeceraRtf(string fuente) => new StringBuilder(@"{\rtf1\ansi\deff0\uc1{\fonttbl{\f0\fnil ")
        .Append(Escapar(fuente)).Append(@";}}");

    private static void AgregarDato(StringBuilder rtf, string etiqueta, string valor) =>
        rtf.Append(@"\pard\plain\ql\f0\fs22\b ").Append(Escapar(etiqueta + ": "))
            .Append(@"\b0 ").Append(Escapar(valor ?? "")).Append(@"\par ");

    private static Font FuenteReferencia()
    {
        var preferida = new Font("Arial Narrow", 11, FontStyle.Regular, GraphicsUnit.Point);
        if (preferida.FontFamily.Name.Equals("Arial Narrow", StringComparison.OrdinalIgnoreCase)) return preferida;
        preferida.Dispose();
        return new Font("Arial", 11, FontStyle.Regular, GraphicsUnit.Point);
    }

    private static string Escapar(string texto)
    {
        var resultado = new StringBuilder();
        foreach (char caracter in texto ?? "")
        {
            if (caracter is '\\' or '{' or '}') resultado.Append('\\').Append(caracter);
            else if (caracter == '\n') resultado.Append(@"\line ");
            else if (caracter == '\r') { }
            else if (caracter == '\t') resultado.Append(@"\tab ");
            else if (caracter is >= ' ' and <= '~') resultado.Append(caracter);
            else resultado.Append(@"\u").Append(unchecked((short)caracter).ToString(CultureInfo.InvariantCulture)).Append('?');
        }
        return resultado.ToString();
    }
}
