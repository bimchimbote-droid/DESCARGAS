using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class TamanoTextoUICheck
{
    private delegate bool EnumerarVentana(IntPtr ventana, IntPtr datos);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")]
    private static extern bool EnumThreadWindows(uint hilo, EnumerarVentana enumerar, IntPtr datos);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        int original = MYGTamanoTextoUI.Porcentaje;
        bool oscuro = MYG2027_TemaComercial.Oscuro;
        try
        {
            MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
            VerificarMenuInicio(exige);
            VerificarLecturaYEdicion(exige);
            VerificarDocumentos(exige);
            VerificarCambioDpi(exige);
            VerificarEditorCompacto(exige);
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
            MYGTamanoTextoUI.Cambiar(original, guardarPreferencia: false);
        }
    }

    private static void VerificarMenuInicio(Action<bool, string> exige)
    {
        // Los clics ejercitan el guardado real; conservar incluso el contenido
        // original del archivo evita modificar la preferencia del usuario.
        string ruta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "MYG", "Presupuestos", "tamano-texto.txt");
        bool existia = File.Exists(ruta);
        byte[] preferencia = existia ? File.ReadAllBytes(ruta) : null;
        var errores = new List<Exception>();
        System.Threading.ThreadExceptionEventHandler capturar = (_, e) => errores.Add(e.Exception);
        Application.ThreadException += capturar;
        InicioForm inicio = null;
        try
        {
            using var sesion = new MYG.Externo.SesionDesktop();
            inicio = new InicioForm(sesion);
            inicio.Show(); Application.DoEvents();
            var boton = inicio.Controls.Find("tamanoTextoInicio", true).OfType<Button>().Single();
            float fuenteBase = boton.Font.SizeInPoints;
            ContextMenuStrip menu = null;
            int cierres = 0;
            ToolStripDropDownCloseReason motivo = default;
            int[] secuencia = { 85, 115, 100, 85, 115, 100 };
            foreach (int porcentaje in secuencia)
            {
                boton.PerformClick(); Application.DoEvents();
                var abierto = MenuAbierto(boton);
                exige(abierto != null, "El botón Texto de Inicio debe abrir su menú de tamaños.");
                if (menu == null)
                {
                    menu = abierto;
                    menu.Closed += (_, e) => { cierres++; motivo = e.CloseReason; };
                }
                exige(ReferenceEquals(abierto, menu) && !menu.IsDisposed,
                    "Reabrir Texto debe reutilizar el menú vivo del botón de Inicio.");
                exige(menu.Items.OfType<ToolStripMenuItem>().Where(x => x.Checked)
                    .Select(x => x.Name).SequenceEqual(new[] { "tamano_texto_" + MYGTamanoTextoUI.Porcentaje }),
                    "Cada apertura debe marcar únicamente el tamaño de texto vigente.");
                var opcion = menu.Items.OfType<ToolStripMenuItem>().Single(x => x.Name == "tamano_texto_" + porcentaje);
                int anteriores = cierres;
                PulsarOpcion(menu, opcion);
                Application.DoEvents();
                exige(errores.Count == 0,
                    "Elegir el tamaño desde el menú de Inicio debe terminar sin excepciones: " + errores.FirstOrDefault());
                exige(cierres == anteriores + 1 && motivo == ToolStripDropDownCloseReason.ItemClicked
                    && !menu.Visible && !menu.IsDisposed,
                    "Elegir una opción debe cerrar el desplegable una sola vez y conservarlo hasta liberar el botón.");
                exige(MYGTamanoTextoUI.Porcentaje == porcentaje && boton.Text == $"Texto {porcentaje} % ▾"
                    && Cerca(boton.Font.SizeInPoints, MYGTamanoTextoUI.TamanoLectura(fuenteBase, porcentaje)),
                    "Elegir compacto, grande y normal repetidamente debe actualizar el botón sin acumular escala.");
            }

            boton.PerformClick(); Application.DoEvents();
            exige(ReferenceEquals(MenuAbierto(boton), menu),
                "El menú debe seguir disponible después de cambiar el tamaño varias veces.");
            int antesDeCancelar = MYGTamanoTextoUI.Porcentaje;
            menu.Close(ToolStripDropDownCloseReason.CloseCalled); Application.DoEvents();
            exige(!menu.Visible && !menu.IsDisposed && MYGTamanoTextoUI.Porcentaje == antesDeCancelar,
                "Cancelar el menú debe conservarlo y mantener el porcentaje de texto.");
            boton.PerformClick(); Application.DoEvents();
            inicio.Close(); Application.DoEvents();
            exige(inicio.IsDisposed && boton.IsDisposed && menu.IsDisposed,
                "Cerrar Inicio debe liberar también el menú de tamaños de su botón.");
            exige(errores.Count == 0,
                "Cancelar el menú y cerrar Inicio deben terminar sin excepciones: " + errores.FirstOrDefault());
        }
        finally
        {
            try { inicio?.Dispose(); }
            finally
            {
                Application.ThreadException -= capturar;
                if (existia) File.WriteAllBytes(ruta, preferencia);
                else if (File.Exists(ruta)) File.Delete(ruta);
                MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
            }
        }
    }

    private static ContextMenuStrip MenuAbierto(Control boton)
    {
        ContextMenuStrip encontrado = null;
        EnumThreadWindows(GetCurrentThreadId(), (ventana, _) =>
        {
            if (Control.FromHandle(ventana) is ContextMenuStrip menu && menu.Visible
                && menu.Name == "menu_tamano_texto" && ReferenceEquals(menu.SourceControl, boton))
            {
                encontrado = menu;
                return false;
            }
            return true;
        }, IntPtr.Zero);
        return encontrado;
    }

    private static void PulsarOpcion(ContextMenuStrip menu, ToolStripItem opcion)
    {
        Point punto = new(opcion.Bounds.Left + opcion.Bounds.Width / 2, opcion.Bounds.Top + opcion.Bounds.Height / 2);
        IntPtr posicion = new(unchecked((punto.Y << 16) | (punto.X & 0xffff)));
        IntPtr ventana = menu.Handle;
        // Recorrer el despacho del ratón hace que WinForms cierre el menú antes
        // de invocar Click. Llamar Cambiar directamente omitiría el fallo original.
        SendMessage(ventana, 0x0200, IntPtr.Zero, posicion); // WM_MOUSEMOVE.
        SendMessage(ventana, 0x0201, new IntPtr(1), posicion); // WM_LBUTTONDOWN.
        SendMessage(ventana, 0x0202, IntPtr.Zero, posicion); // WM_LBUTTONUP.
    }

    private static void VerificarLecturaYEdicion(Action<bool, string> exige)
    {
        using var normal = new Font("Segoe UI", 9);
        using var negrita = new Font("Segoe UI", 9, FontStyle.Bold);
        using var formulario = new Form { ClientSize = new Size(900, 550), Font = normal };
        using var contenedor = new Panel { Dock = DockStyle.Fill, Font = normal };
        using var etiqueta = new Label { Text = "Presupuesto", Font = negrita, AutoSize = true, Dock = DockStyle.Top };
        using var boton = MYGTamanoTextoUI.CrearBoton();
        using var selector = MYGTamanoTextoUI.CrearSelector();
        using var otroSelector = MYGTamanoTextoUI.CrearSelector();
        using var tabla = new DataGridView
        {
            Dock = DockStyle.Fill, Font = normal, AllowUserToAddRows = false,
            DefaultCellStyle = new DataGridViewCellStyle { Font = normal },
            ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { Font = negrita }
        };
        // El pie de costos conserva colores y formato de autor: eso no debe
        // impedir una escala de lectura reversible de su texto en pantalla.
        MYG2027_TemaComercial.ConservarColoresDocumento(tabla);
        tabla.Columns.Add("descripcion", "Descripción");
        tabla.Rows.Add("Trabajo original");
        tabla.Rows[0].DefaultCellStyle.Font = negrita;
        var opciones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 80 };
        opciones.Controls.AddRange(new Control[] { boton, selector, otroSelector });
        contenedor.Controls.Add(tabla); contenedor.Controls.Add(etiqueta); contenedor.Controls.Add(opciones);
        formulario.Controls.Add(contenedor);
        formulario.Show();
        MYG2027_TemaComercial.Aplicar(formulario);
        Application.DoEvents();
        exige(selector.DropDownStyle == ComboBoxStyle.DropDownList && selector.Items.Count == 3
            && selector.Items.Cast<object>().Select(x => x.ToString()).SequenceEqual(new[]
                { "Compacto (85 %)", "Normal (100 %)", "Grande (115 %)" }),
            "Tamaño del texto debe ofrecer compacto, normal y grande mediante una lista de opciones explícitas.");

        Font efectiva = null;
        tabla.CellFormatting += (_, e) => { if (e.RowIndex == 0) efectiva = e.CellStyle.Font; };
        foreach (int porcentaje in new[] { 85, 115, 100, 85, 100 })
        {
            MYGTamanoTextoUI.Cambiar(porcentaje, guardarPreferencia: false);
            // Renovar el tema no debe reinterpretar el tamaño reducido como un
            // nuevo tamaño base ni restaurar el mínimo histórico de 9 puntos.
            MYG2027_TemaComercial.Aplicar(formulario);
            MYG2027_TemaComercial.Aplicar(formulario);
            Application.DoEvents();
            float esperado = porcentaje == 85 ? 8.5f : 9 * porcentaje / 100f;
            exige(Cerca(etiqueta.Font.SizeInPoints, esperado) && etiqueta.Font.Bold
                && Cerca(boton.Font.SizeInPoints, esperado)
                && Cerca(tabla.DefaultCellStyle.Font.SizeInPoints, esperado)
                && Cerca(tabla.ColumnHeadersDefaultCellStyle.Font.SizeInPoints, esperado)
                && tabla.ColumnHeadersDefaultCellStyle.Font.Bold,
                "Cambiar el tamaño y renovar la apariencia debe conservar la escala exacta y las negritas sin acumular ajustes.");
            _ = tabla.Rows[0].Cells[0].FormattedValue;
            exige(efectiva != null && Cerca(efectiva.SizeInPoints, esperado) && efectiva.Bold,
                "Los estilos explícitos de las filas deben usar el mismo tamaño del texto que la interfaz.");
            exige(Cerca(MYGTamanoTextoUI.FuenteOriginal(efectiva).SizeInPoints, 9)
                && MYGTamanoTextoUI.FuenteOriginal(efectiva).Bold,
                "Una tabla con colores propios debe permitir recuperar la fuente de autor sin la escala de lectura.");
            exige(selector.SelectedIndex == otroSelector.SelectedIndex
                && selector.Text.Contains(porcentaje.ToString()) && boton.Text == $"Texto {porcentaje} % ▾",
                "Los accesos al tamaño del texto deben reflejar el mismo valor al cambiarlo desde otra ventana.");
            exige(Cerca(formulario.Font.SizeInPoints, 9) && Cerca(contenedor.Font.SizeInPoints, 9),
                "La preferencia de lectura no debe modificar las fuentes de formularios ni contenedores.");
        }

        MYGTamanoTextoUI.Cambiar(85, guardarPreferencia: false);
        tabla.Rows.Clear(); tabla.Rows.Add("Fila regenerada");
        tabla.Rows[0].DefaultCellStyle.Font = negrita;
        efectiva = null;
        _ = tabla.Rows[0].Cells[0].FormattedValue;
        exige(efectiva != null && Cerca(efectiva.SizeInPoints, 8.5f) && efectiva.Bold,
            "La escala debe aplicarse también a las filas creadas después de refrescar los datos.");
        using (var nueva = new Label { Text = "Creada después", Font = normal, AutoSize = true })
        {
            opciones.Controls.Add(nueva);
            exige(Cerca(nueva.Font.SizeInPoints, 8.5f),
                "Los controles de interfaz creados después del cambio deben heredar la preferencia de lectura.");
        }
        tabla.CurrentCell = tabla.Rows[0].Cells[0]; tabla.BeginEdit(true);
        var editor = (TextBox)tabla.EditingControl;
        editor.Text = "Edición pendiente"; editor.Select(3, 4);
        MYGTamanoTextoUI.Cambiar(115, guardarPreferencia: false);
        exige(tabla.IsCurrentCellInEditMode && editor.Text == "Edición pendiente"
            && editor.SelectionStart == 3 && editor.SelectionLength == 4
            && Cerca(editor.Font.SizeInPoints, 10.35f),
            "Cambiar el tamaño debe conservar la edición de una celda y su selección sin confirmar ni perder el texto.");
        tabla.CancelEdit(); formulario.Close();
    }

    private static void VerificarDocumentos(Action<bool, string> exige)
    {
        MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
        using var fuente = new Font("Arial", 11);
        using var formulario = new Form { ClientSize = new Size(900, 650) };
        using var documento = new RichTextBox
        {
            Dock = DockStyle.Top, Height = 120, Font = fuente,
            Rtf = @"{\rtf1\ansi{\fonttbl{\f0 Arial;}{\f1 Courier New;}}\f0\fs22\b Título\b0\par\f1\fs19 Texto de autor.}"
        };
        using var hoja = new DataGridView
        {
            Name = "metrado_hoja", Dock = DockStyle.Fill, Font = fuente, AllowUserToAddRows = false,
            DefaultCellStyle = new DataGridViewCellStyle { Font = fuente }
        };
        hoja.Columns.Add("celda", "A"); hoja.Rows.Add("=B2*C2");
        MYG2027_TemaComercial.ConservarColoresDocumento(hoja);
        formulario.Controls.Add(hoja); formulario.Controls.Add(documento);
        formulario.Show(); MYG2027_TemaComercial.Aplicar(formulario); Application.DoEvents();
        documento.Select(3, 4);
        string rtf = documento.Rtf;
        Font fuenteCelda = hoja.DefaultCellStyle.Font;
        foreach (int valor in new[] { 85, 115, 100 })
        {
            MYGTamanoTextoUI.Cambiar(valor, guardarPreferencia: false);
            MYG2027_TemaComercial.Aplicar(formulario);
            exige(documento.Rtf == rtf && documento.SelectionStart == 3 && documento.SelectionLength == 4,
                "La escala de texto de interfaz debe conservar exactamente el RTF y la selección del documento.");
            exige(ReferenceEquals(hoja.DefaultCellStyle.Font, fuenteCelda)
                && Cerca(hoja.Font.SizeInPoints, 11) && Convert.ToString(hoja[0, 0].Value) == "=B2*C2",
                "La escala de interfaz debe conservar las fuentes y fórmulas de la hoja de metrado.");
        }
        formulario.Close();
    }

    private static void VerificarEditorCompacto(Action<bool, string> exige)
    {
        MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
        var proyecto = MYGProyectoStorage.Nuevo("Lectura en laptop", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "Oficinas provisionales",
            Unidad = "m²", TipoPropuesta = "PARTIDA", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 18, PrecioDirecto = 20, EspecificacionTexto = "Descripción de la partida y procedimiento de ejecución." }
        };
        presupuesto.Items.Add(partida);
        partida.Costos.Hoja.Poner("B3", "2"); partida.Costos.Hoja.Poner("C3", "9");
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => { }, () => { },
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1366, 768), ShowInTaskbar = false };
        formulario.Controls.Add(panel); formulario.Show();
        panel.Refrescar(); panel.SeleccionarEstructura(partida); Application.DoEvents();
        var paginaExcel = panel.Controls.Find("metrado_pagina", true).OfType<TabPage>().Single();
        var detalle = (TabControl)paginaExcel.Parent;
        // Completar primero las reparaciones de plantillas heredadas y la
        // carga inicial de RTF. Después sólo debe cambiar la presentación.
        foreach (TabPage pagina in detalle.TabPages) { detalle.SelectedTab = pagina; Application.DoEvents(); }
        string datos = JsonSerializer.Serialize(partida.Costos);
        var hoja = panel.Controls.Find("metrado_hoja", true).OfType<DataGridView>().Single();
        var cabecera = panel.Controls.Find("metrado_cabecera", true).Single();
        var especificaciones = Descendientes(panel).OfType<MYGEspecificacionesEditor>().Single();
        string rtf = especificaciones.Documento.Rtf;
        foreach (Size pantalla in new[] { new Size(1366, 768), new Size(1920, 1080) })
        {
            formulario.ClientSize = pantalla;
            MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
            detalle.SelectedTab = paginaExcel; Application.DoEvents();
            int altoNormal = cabecera.Height;
            foreach (int valor in new[] { 85, 115, 100, 85, 100 })
            {
                MYGTamanoTextoUI.Cambiar(valor, guardarPreferencia: false);
                MYG2027_TemaComercial.Aplicar(formulario); Application.DoEvents();
                foreach (TabPage pagina in detalle.TabPages)
                {
                    detalle.SelectedTab = pagina; Application.DoEvents();
                    exige(pagina.ClientSize.Width > 0 && pagina.ClientSize.Height > 0,
                        "Las vistas de detalle deben conservar espacio de trabajo a " + valor + " % en " + pantalla + ".");
                    foreach (var cinta in Descendientes(pagina).OfType<TabControl>()
                        .Where(c => c.Name is "espec_cinta" or "metrado_cinta").ToArray())
                    {
                        foreach (TabPage comandos in cinta.TabPages)
                        {
                            cinta.SelectedTab = comandos; Application.DoEvents();
                            foreach (var fila in Descendientes(comandos).OfType<ToolStrip>().Where(f => f.Visible))
                            {
                                exige(fila.Right <= fila.Parent.ClientSize.Width && fila.Bottom <= fila.Parent.ClientSize.Height,
                                    "Cada fila debe permanecer dentro de su grupo al cambiar la escala sin acumular anchura.");
                                exige(fila.Items.Cast<ToolStripItem>().Where(i => i.Available).All(i =>
                                        i.Bounds.Bottom <= fila.ClientSize.Height && i.Bounds.Right <= fila.ClientSize.Width),
                                    "Las cintas deben mostrar completos sus comandos sin recortarlos a " + valor + " %: " + comandos.Text);
                            }
                            foreach (var grupo in Descendientes(comandos).Where(c => c.Name.StartsWith("espec_grupo_", StringComparison.Ordinal)))
                            {
                                var areas = grupo.Controls.Cast<Control>().Where(c => c.Visible && c.Dock == DockStyle.None)
                                    .Select(c => new Rectangle(c.Location, c is ToolStrip fila
                                        ? new Size(fila.Items.Cast<ToolStripItem>().Where(i => i.Available)
                                            .Select(i => i.Bounds.Right + fila.Padding.Right).DefaultIfEmpty(1).Max(), c.Height)
                                        : c.Size)).ToArray();
                                exige(!areas.Where((area, i) => areas.Skip(i + 1).Any(otra => area.IntersectsWith(otra))).Any(),
                                    "Las filas y controles vecinos de una cinta deben permanecer separados a " + valor + " %: " + grupo.Name);
                            }
                        }
                    }
                }
                detalle.SelectedTab = paginaExcel; Application.DoEvents();
                float esperado = valor == 85 ? 8.5f : 9 * valor / 100f;
                exige(Cerca(hoja.Rows[2].Cells[1].Style.Font.SizeInPoints, esperado)
                    && Cerca(hoja.ColumnHeadersDefaultCellStyle.Font.SizeInPoints, esperado),
                    "Las fuentes de celdas y encabezados deben seguir la lectura de interfaz sin acumular escala.");
                exige(valor != 85 || cabecera.Height < altoNormal,
                    "El modo compacto debe recuperar espacio vertical de la cabecera del metrado.");
                exige(datos == JsonSerializer.Serialize(partida.Costos) && especificaciones.Documento.Rtf == rtf,
                    "Cambiar tamaño y recorrer todas las vistas debe conservar metrados, fuentes de autor, zoom guardado y RTF exactamente.");
                var paginaEspecificacion = detalle.TabPages.Cast<TabPage>().Single(p => p.Contains(especificaciones));
                detalle.SelectedTab = paginaEspecificacion; Application.DoEvents();
                var ajustar = (CheckBox)typeof(MYGEspecificacionesEditor).GetField("ajustar",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).GetValue(especificaciones);
                ajustar.Checked = true; Application.DoEvents();
                float ajuste = especificaciones.Documento.ZoomFactor;
                ajustar.Checked = false; Application.DoEvents();
                exige(Math.Abs(especificaciones.Documento.ZoomFactor - ajuste) < .015f,
                    "Salir de Ajustar al ancho debe conservar el tamaño visible con lectura compacta, normal y grande.");
            }
        }
        formulario.Close();
    }

    private static IEnumerable<Control> Descendientes(Control raiz)
    {
        foreach (Control hijo in raiz.Controls)
        {
            yield return hijo;
            foreach (var nieto in Descendientes(hijo)) yield return nieto;
        }
    }

    private static bool Cerca(float actual, float esperado) => Math.Abs(actual - esperado) < .03f;

    private sealed class EtiquetaDpiPrueba : Label
    {
        internal void SimularCambioDpi(float factor)
        {
            OnDpiChangedBeforeParent(EventArgs.Empty);
            using var nativa = new Font(Font.FontFamily, Font.Size * factor, Font.Style, Font.Unit);
            Font = nativa;
            OnDpiChangedAfterParent(EventArgs.Empty);
        }
    }

    private static void VerificarCambioDpi(Action<bool, string> exige)
    {
        MYGTamanoTextoUI.Cambiar(85, guardarPreferencia: false);
        using var fuente = new Font("Segoe UI", 9);
        using var etiqueta = new EtiquetaDpiPrueba { Font = fuente, Text = "Cambio de monitor" };
        MYG2027_TemaComercial.Aplicar(etiqueta);
        etiqueta.SimularCambioDpi(1.5f);
        exige(Cerca(etiqueta.Font.SizeInPoints, 9 * .85f * 1.5f),
            "Una fuente nativa nueva durante el cambio de DPI debe conservar el porcentaje de lectura sin aplicarlo dos veces.");
        MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
        exige(Cerca(etiqueta.Font.SizeInPoints, 9 * 1.5f),
            "Volver al tamaño normal después de cambiar de monitor debe conservar el factor de DPI nativo.");
        MYGTamanoTextoUI.Cambiar(85, guardarPreferencia: false);
        etiqueta.SimularCambioDpi(1 / 1.5f);
        exige(Cerca(etiqueta.Font.SizeInPoints, 8.5f),
            "Regresar al DPI inicial debe recuperar el tamaño compacto sin acumular reducciones.");
        using var explicita = new Font("Segoe UI", 12, FontStyle.Bold);
        etiqueta.Font = explicita;
        exige(Cerca(etiqueta.Font.SizeInPoints, 12 * .85f) && etiqueta.Font.Bold,
            "Un cambio explícito de fuente fuera de una notificación DPI debe respetarse como un nuevo tamaño base.");
    }
}
