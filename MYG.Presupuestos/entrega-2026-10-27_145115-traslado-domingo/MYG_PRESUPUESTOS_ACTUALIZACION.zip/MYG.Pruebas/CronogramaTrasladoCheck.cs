using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class CronogramaTrasladoCheck
{
    private static readonly DateTime Inicio = new(2026, 10, 5);
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Traslado del cronograma: " + detalle); }

    internal static void Ejecutar(Action<string> pasa)
    {
        RedDePredecesoras(pasa);
        ConfiguracionYLineaBase(pasa);
        JornadasYFeriados(pasa);
        InstantaneasImportadas(pasa);
        DiasNoLaborables(pasa);
        AutomaticasImportadasEnDomingo(pasa);
        FinImportadoEnDomingoYRed(pasa);
        HitoAutomaticoImportadoEnDomingo(pasa);
        IntervalosNoLaborablesIncompatibles(pasa);
        MismoInicioYPlanVacio(pasa);
        RechazoAtomico(pasa);
    }

    private static MYGCronograma Plan(bool todosLosDias = false)
    {
        var plan = new MYGCronograma { FechaInicio = Inicio, FechaEstado = Inicio.AddDays(2) };
        if (todosLosDias) plan.Calendario.DiasLaborables = Enum.GetValues<DayOfWeek>().ToList();
        return plan;
    }
    private static MYGTareaCronograma Tarea(MYGCronograma plan, string id, int dias = 1,
        MYGModoTarea modo = MYGModoTarea.Automatica, DateTime? fecha = null)
    {
        var t = new MYGTareaCronograma { Id = id, Nombre = id, DuracionDias = dias, Modo = modo, InicioManual = fecha };
        plan.Tareas.Add(t); return t;
    }
    private static void Depende(MYGTareaCronograma t, MYGTareaCronograma anterior, MYGTipoVinculo tipo, int lag = 0) =>
        t.Predecesoras.Add(new MYGDependenciaCronograma { PredecesoraId = anterior.Id, Tipo = tipo, DesfaseDias = lag });
    private static Dictionary<string, MYGResultadoTarea> Filas(MYGCronograma plan) =>
        MYGMotorCronograma.Calcular(plan).Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
    private static int DiferenciaJornadas(MYGCalendarioTrabajo calendario, DateTime desde, DateTime hasta)
    {
        desde = calendario.SiguienteLaborable(desde); hasta = calendario.SiguienteLaborable(hasta);
        return hasta >= desde ? calendario.ContarDiasLaborables(desde, hasta) - 1 :
            -(calendario.ContarDiasLaborables(hasta, desde) - 1);
    }
    private static void VerificarTraslacion(MYGCronograma original, MYGCronograma trasladado, DateTime nuevoInicio)
    {
        int delta = DiferenciaJornadas(original.Calendario, original.FechaInicio, nuevoInicio);
        var antes = Filas(original); var despues = Filas(trasladado);
        Exige(trasladado.FechaInicio == nuevoInicio.Date && despues.Count == antes.Count,
            "el inicio o el número de tareas del bloque cambió incorrectamente.");
        foreach (var (id, fila) in antes)
        {
            var nueva = despues[id];
            Exige(nueva.Inicio == original.Calendario.SumarDiasLaborables(fila.Inicio, delta) &&
                nueva.Fin == original.Calendario.SumarDiasLaborables(fila.Fin, delta),
                "se perdió la separación laborable de «" + id + "» al trasladar todo el bloque.");
            Exige(nueva.DuracionDias == fila.DuracionDias && nueva.Avance == fila.Avance,
                "el traslado alteró duración o avance de «" + id + "».");
        }
    }

    private static void RedDePredecesoras(Action<string> pasa)
    {
        var plan = Plan(true);
        var raiz = Tarea(plan, "RAIZ", 4);
        var fc = Tarea(plan, "FC+2", 2); Depende(fc, raiz, MYGTipoVinculo.FC, 2);
        var cc = Tarea(plan, "CC-1", 2); Depende(cc, raiz, MYGTipoVinculo.CC, -1);
        var ff = Tarea(plan, "FF+1", 3); Depende(ff, raiz, MYGTipoVinculo.FF, 1);
        var cf = Tarea(plan, "CF+3", 2); Depende(cf, raiz, MYGTipoVinculo.CF, 3);
        var varias = Tarea(plan, "DOS PREDECESORAS", 2);
        Depende(varias, fc, MYGTipoVinculo.FC, -1); Depende(varias, ff, MYGTipoVinculo.CC, 1);
        var restringida = Tarea(plan, "RESTRICCIÓN", 2);
        restringida.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe;
        restringida.FechaRestriccion = Inicio.AddDays(12);
        var exacta = Tarea(plan, "FECHA FIJA", 2);
        exacta.TipoRestriccion = MYGTipoRestriccion.DebeComenzarEl;
        exacta.FechaRestriccion = Inicio.AddDays(15);
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddDays(21));
        VerificarTraslacion(plan, movido, Inicio.AddDays(21));
        Exige(Firma(plan) == original && !ReferenceEquals(movido, plan) &&
            Firma(movido.Tareas.Select(t => t.Predecesoras)) == Firma(plan.Tareas.Select(t => t.Predecesoras)),
            "se mutó el origen o se cambiaron tipos, desfases o identidades de las predecesoras.");
        Exige(movido.Tareas.Single(t => t.Id == exacta.Id).FechaRestriccion == exacta.FechaRestriccion.Value.AddDays(21) &&
            movido.Tareas.Single(t => t.Id == restringida.Id).TipoRestriccion == restringida.TipoRestriccion &&
            MYGMotorCronograma.Calcular(movido).Advertencias.Count == 0,
            "las restricciones no acompañaron al bloque o aparecieron conflictos nuevos.");
        pasa("Trasladar el inicio conserva la red FC/CC/FF/CF, desfases positivos y negativos, múltiples predecesoras y restricciones sin mutar el plan");
    }

    private static void ConfiguracionYLineaBase(Action<string> pasa)
    {
        var plan = Plan(true);
        plan.OpcionesVista["Presentacion"] = "{\"ColorCriticaArgb\":-65536,\"OcultarAvance\":false}";
        plan.Calendarios.Add(MYGProyectoStorage.Copia(plan.Calendario));
        var resumen = Tarea(plan, "TÍTULO"); resumen.EsResumen = true;
        var manual = Tarea(plan, "MANUAL", 2, MYGModoTarea.Manual, Inicio.AddDays(2)); manual.PadreId = resumen.Id;
        manual.Avance = 37.5m; manual.Responsables.Add("Residente"); manual.Codigo = "01.01";
        manual.InicioBase = new DateTime(2025, 11, 3); manual.FinBase = new DateTime(2025, 11, 4); manual.DuracionBase = 2;
        var dividida = Tarea(plan, "DIVIDIDA", 4); dividida.PadreId = resumen.Id;
        Depende(dividida, manual, MYGTipoVinculo.FC);
        dividida.Partes.Add(new MYGParteTarea { DesfaseInicioDias = 0, DuracionDias = 2, Cantidad = 4, Porcentaje = 50 });
        dividida.Partes.Add(new MYGParteTarea { DesfaseInicioDias = 4, DuracionDias = 2, Cantidad = 4, Porcentaje = 50 });
        var hito = Tarea(plan, "HITO", 0); hito.PadreId = resumen.Id; Depende(hito, dividida, MYGTipoVinculo.FC);
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddDays(14));
        VerificarTraslacion(plan, movido, Inicio.AddDays(14));
        Exige(Firma(plan) == original && movido.FechaEstado == plan.FechaEstado &&
            Firma(movido.Calendario) == Firma(plan.Calendario) && Firma(movido.Calendarios) == Firma(plan.Calendarios) &&
            Firma(movido.OpcionesVista) == Firma(plan.OpcionesVista),
            "se cambiaron fecha de estado, calendarios, presentación o documento original.");
        foreach (var t in plan.Tareas)
        {
            var m = movido.Tareas.Single(x => x.Id == t.Id);
            Exige(m.PadreId == t.PadreId && m.Modo == t.Modo && m.EsResumen == t.EsResumen &&
                m.InicioBase == t.InicioBase && m.FinBase == t.FinBase && m.DuracionBase == t.DuracionBase &&
                Firma(m.Partes) == Firma(t.Partes) && Firma(m.Responsables) == Firma(t.Responsables),
                "se alteraron jerarquía, modo, línea base, responsables o la distribución por partes.");
        }
        pasa("El traslado conserva resúmenes, hitos, manuales, partes, línea base, fecha de estado, calendarios y opciones del Gantt");
    }

    private static void JornadasYFeriados(Action<string> pasa)
    {
        var plan = Plan(); plan.Calendario.Feriados.Add(new DateTime(2026, 10, 12));
        var manual = Tarea(plan, "ANCLA", 2, MYGModoTarea.Manual, Inicio.AddDays(3));
        var sucesora = Tarea(plan, "DESPUÉS DEL FERIADO", 3); Depende(sucesora, manual, MYGTipoVinculo.FC, 1);
        string original = Firma(plan);
        foreach (var destino in new[] { new DateTime(2026, 10, 13), new DateTime(2026, 9, 28) })
        {
            var movido = MYGTrasladoCronograma.MoverAlInicio(plan, destino);
            VerificarTraslacion(plan, movido, destino);
            Exige(Firma(plan) == original && Firma(movido.Calendario.Feriados) == Firma(plan.Calendario.Feriados),
                "adelantar o atrasar el bloque movió los feriados o tocó el origen.");
            Exige(!MYGMotorCronograma.Calcular(movido).Advertencias.Any(a => a.Contains("antes de lo requerido", StringComparison.Ordinal)),
                "el fin de semana o feriado produjo un incumplimiento de predecesoras al mover el bloque.");
        }
        pasa("Mover hacia adelante o atrás usa jornadas laborables y conserva los desfases al cruzar fines de semana y feriados");
    }

    private static void InstantaneasImportadas(Action<string> pasa)
    {
        var plan = Plan(true); plan.AdvertenciasImportacion.Add("Restricción nativa no interpretada; se conserva como información importada.");
        var a = Tarea(plan, "IMPORTADA-A", 2, MYGModoTarea.Automatica, Inicio.AddDays(1));
        a.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        {
            Inicio = Inicio.AddDays(1).AddHours(8), Fin = Inicio.AddDays(3).AddHours(17), DuracionDias = 2,
            ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = plan.FechaInicio, VersionLectura = 1,
            Tramos = new List<MYGTramoImportadoDelphin>
            {
                new() { Id = "PG-1", Inicio = Inicio.AddDays(1).AddHours(8), Fin = Inicio.AddDays(1).AddHours(17), Duracion = 1, Cantidad = 3, Porcentaje = 50 },
                new() { Id = "PG-2", Inicio = Inicio.AddDays(3).AddHours(8), Fin = Inicio.AddDays(3).AddHours(17), Duracion = 1, Cantidad = 3, Porcentaje = 50 }
            }
        };
        var b = Tarea(plan, "IMPORTADA-B", 1, MYGModoTarea.Automatica, Inicio.AddDays(4)); Depende(b, a, MYGTipoVinculo.FC);
        b.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        {
            Inicio = Inicio.AddDays(4), Fin = Inicio.AddDays(4), DuracionDias = 1,
            ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = plan.FechaInicio
        };
        var obsoleta = Tarea(plan, "OBSOLETA", 2, MYGModoTarea.Automatica, Inicio.AddDays(20));
        obsoleta.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        {
            Inicio = Inicio.AddDays(20), Fin = Inicio.AddDays(21), DuracionDias = 2,
            ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = Inicio.AddDays(10)
        };
        var antes = Filas(plan);
        Exige(antes[a.Id].Tarea.FechasImportadasDelphin != null && antes[b.Id].Tarea.FechasImportadasDelphin != null &&
            antes[obsoleta.Id].Tarea.FechasImportadasDelphin == null, "la muestra de instantáneas activas y obsoletas no está correctamente diferenciada.");
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddDays(14));
        VerificarTraslacion(plan, movido, Inicio.AddDays(14));
        var despues = Filas(movido); var otraVez = Filas(MYGProyectoStorage.Copia(movido));
        Exige(despues[a.Id].Tarea.FechasImportadasDelphin != null && despues[b.Id].Tarea.FechasImportadasDelphin != null &&
            despues[obsoleta.Id].Tarea.FechasImportadasDelphin == null && Firma(plan) == original &&
            Firma(movido.AdvertenciasImportacion) == Firma(plan.AdvertenciasImportacion),
            "se perdieron instantáneas activas, se reactivó una obsoleta o se alteró el historial importado.");
        var importada = movido.Tareas.Single(t => t.Id == a.Id).FechasImportadasDelphin;
        Exige(importada.Tramos.Count == 2 && importada.Tramos[0].Inicio == a.FechasImportadasDelphin.Tramos[0].Inicio.AddDays(14) &&
            importada.Tramos[1].Fin == a.FechasImportadasDelphin.Tramos[1].Fin.AddDays(14) &&
            importada.Tramos[0].Cantidad == 3 && importada.Tramos[1].Porcentaje == 50 &&
            despues[a.Id].Inicio == otraVez[a.Id].Inicio && despues[b.Id].Inicio == otraVez[b.Id].Inicio &&
            despues[a.Id].Fin == otraVez[a.Id].Fin,
            "el traslado perdió pausas, horas, cantidades o estabilidad de las fechas tras copiar y recalcular.");
        pasa("Trasladar instantáneas Delphin conserva sus tramos y firmas, no reactiva fechas obsoletas y sigue estable al volver a calcular");
    }

    private static void DiasNoLaborables(Action<string> pasa)
    {
        var plan = Plan(); var hito = Tarea(plan, "HITO DEL SÁBADO", 0, MYGModoTarea.Manual, new DateTime(2026, 10, 10));
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 12));
        Exige(Filas(movido)[hito.Id].Inicio == new DateTime(2026, 10, 17) && Firma(plan) == original,
            "se normalizó silenciosamente un hito del sábado en vez de conservar su posición entre jornadas.");
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 6)),
            "un hueco de fin de semana que no existe en el calendario destino");
        Exige(Firma(plan) == original, "rechazar un traslado no laborable dejó fechas parciales en el original.");
        pasa("Los días no laborables conservan su posición si existe un hueco equivalente y rechazan un traslado incompatible sin cambios parciales");
    }

    private static MYGTareaCronograma Importada(MYGCronograma plan, string id, DateTime inicio, DateTime fin, int duracion)
    {
        var tarea = Tarea(plan, id, duracion, MYGModoTarea.Automatica, inicio);
        tarea.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        {
            Inicio = inicio, Fin = fin, DuracionDias = duracion,
            ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = plan.FechaInicio
        };
        return tarea;
    }

    private static MYGCronograma PlanDelCasoDomingo() => new()
    {
        FechaInicio = new DateTime(2026, 6, 8), FechaEstado = new DateTime(2026, 6, 8)
    };

    private static void AutomaticasImportadasEnDomingo(Action<string> pasa)
    {
        var plan = PlanDelCasoDomingo();
        var curado = Importada(plan, "CURADO DE CONCRETO CON ADITIVO QUÍMICO",
            new DateTime(2026, 9, 6, 8, 0, 0), new DateTime(2026, 9, 9, 17, 0, 0), 3);
        curado.InicioBase = new DateTime(2026, 8, 31); curado.FinBase = new DateTime(2026, 9, 2); curado.DuracionBase = 3;
        curado.FechasImportadasDelphin.Tramos.Add(new()
        {
            Id = "CURADO-TRAMO", Inicio = curado.FechasImportadasDelphin.Inicio,
            Fin = curado.FechasImportadasDelphin.Fin, Duracion = 3, Cantidad = 12, Porcentaje = 100
        });
        var fc = Importada(plan, "SUCESORA FC", new DateTime(2026, 9, 10), new DateTime(2026, 9, 11), 2);
        Depende(fc, curado, MYGTipoVinculo.FC);
        var cc = Importada(plan, "SUCESORA CC", new DateTime(2026, 9, 6), new DateTime(2026, 9, 8), 2);
        Depende(cc, curado, MYGTipoVinculo.CC);
        var antes = Filas(plan);
        Exige(antes[curado.Id].Inicio == new DateTime(2026, 9, 6) &&
            antes[curado.Id].Tarea.FechasImportadasDelphin != null,
            "la reproducción debe contener un inicio automático importado de domingo que todavía interviene en la programación.");
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 27));
        var despues = Filas(movido);
        Exige(despues[curado.Id].Inicio == new DateTime(2027, 1, 26) &&
            despues[curado.Id].Fin == new DateTime(2027, 1, 28) &&
            despues[fc.Id].Inicio == new DateTime(2027, 1, 29) &&
            despues[cc.Id].Inicio == despues[curado.Id].Inicio,
            "el curado de domingo debe ajustarse al laborable correspondiente sin romper FC ni CC al mover el proyecto del 08/06 al 27/10.");
        var datos = movido.Tareas.Single(t => t.Id == curado.Id);
        Exige(datos.Modo == MYGModoTarea.Automatica && datos.DuracionDias == 3 &&
            datos.InicioBase == curado.InicioBase && datos.FinBase == curado.FinBase &&
            datos.FechasImportadasDelphin.Tramos.Single().Inicio == new DateTime(2027, 1, 26, 8, 0, 0) &&
            datos.FechasImportadasDelphin.Tramos.Single().Fin == new DateTime(2027, 1, 28, 17, 0, 0) &&
            datos.FechasImportadasDelphin.Tramos.Single().Cantidad == 12 &&
            Firma(movido.Tareas.Select(t => t.Predecesoras)) == Firma(plan.Tareas.Select(t => t.Predecesoras)) &&
            movido.FechaEstado == plan.FechaEstado && Firma(plan) == original,
            "ajustar una automática de domingo no debe alterar modo, duración, tramos, cantidades, predecesoras, base, estado ni el documento original.");
        Exige(despues.Values.All(f => f.Tarea.FechasImportadasDelphin != null) &&
            Firma(Filas(MYGProyectoStorage.Copia(movido)).Select(p => new { p.Key, p.Value.Inicio, p.Value.Fin })) ==
            Firma(despues.Select(p => new { p.Key, p.Value.Inicio, p.Value.Fin })) &&
            !MYGMotorCronograma.Calcular(movido).Advertencias.Any(a => a.Contains("antes de lo requerido", StringComparison.Ordinal)),
            "las instantáneas ajustadas deben seguir activas y estables al copiar y recalcular, sin conflictos nuevos de predecesoras.");
        pasa("El curado automático importado del domingo 06/09 se traslada al calendario laborable conservando FC, CC, tramos y configuración");
    }

    private static void FinImportadoEnDomingoYRed(Action<string> pasa)
    {
        var plan = PlanDelCasoDomingo();
        var importada = Importada(plan, "FIN EN DOMINGO", new DateTime(2026, 9, 4), new DateTime(2026, 9, 6), 1);
        var fc = Tarea(plan, "FC ESTÁNDAR"); Depende(fc, importada, MYGTipoVinculo.FC);
        var ff = Tarea(plan, "FF ESTÁNDAR"); Depende(ff, importada, MYGTipoVinculo.FF);
        var anticipada = Tarea(plan, "FC-1 ESTÁNDAR"); Depende(anticipada, importada, MYGTipoVinculo.FC, -1);
        var diferida = Tarea(plan, "FF+1 ESTÁNDAR"); Depende(diferida, importada, MYGTipoVinculo.FF, 1);
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 27));
        var filas = Filas(movido);
        Exige(filas[importada.Id].Inicio == new DateTime(2027, 1, 25) &&
            filas[importada.Id].Fin == new DateTime(2027, 1, 25) &&
            filas[fc.Id].Inicio == new DateTime(2027, 1, 26) &&
            filas[ff.Id].Fin == new DateTime(2027, 1, 25) &&
            filas[anticipada.Id].Inicio == new DateTime(2027, 1, 25) &&
            filas[diferida.Id].Fin == new DateTime(2027, 1, 26),
            "un fin importado en domingo debe ajustarse al laborable anterior y recalcular sus sucesoras según FC/FF y los desfases, no exigir posiciones antiguas incompatibles.");
        Exige(Firma(plan) == original &&
            Firma(movido.Tareas.Select(t => t.Predecesoras)) == Firma(plan.Tareas.Select(t => t.Predecesoras)) &&
            !MYGMotorCronograma.Calcular(movido).Advertencias.Any(a => a.Contains("antes de lo requerido", StringComparison.Ordinal)),
            "la adaptación de un fin de domingo no debe introducir conflictos ni modificar los vínculos o el origen.");
        pasa("Los fines automáticos importados en domingo conservan FC/FF y desfases al recalcular las sucesoras en jornadas laborables");
    }

    private static void HitoAutomaticoImportadoEnDomingo(Action<string> pasa)
    {
        var plan = PlanDelCasoDomingo();
        var hito = Importada(plan, "HITO AUTOMÁTICO DEL DOMINGO", new DateTime(2026, 9, 6), new DateTime(2026, 9, 6), 0);
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 27));
        var fila = Filas(movido)[hito.Id];
        Exige(fila.Inicio == new DateTime(2027, 1, 26) && fila.Fin == fila.Inicio && fila.DuracionDias == 0 &&
            fila.Tarea.Modo == MYGModoTarea.Automatica && fila.Tarea.FechasImportadasDelphin != null && Firma(plan) == original,
            "un hito automático importado debe ajustarse como un punto único, sin invertir inicio/fin ni crear duración o mutar el origen.");
        hito.Codigo = "H-01"; hito.InicioBase = hito.InicioManual; hito.FinBase = hito.InicioManual; hito.DuracionBase = 0;
        var sucesora = Importada(plan, "SUCESORA DEL HITO", new DateTime(2026, 9, 7), new DateTime(2026, 9, 7), 1);
        sucesora.Codigo = "H-02"; Depende(sucesora, hito, MYGTipoVinculo.FC);
        var nieta = Importada(plan, "NIETA DEL HITO", new DateTime(2026, 9, 8), new DateTime(2026, 9, 8), 1);
        nieta.Codigo = "H-03"; Depende(nieta, sucesora, MYGTipoVinculo.FC);
        original = Firma(plan);
        var cadena = MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 27));
        var filas = Filas(cadena);
        Exige(filas[hito.Id].Inicio == new DateTime(2027, 1, 26) &&
            filas[sucesora.Id].Inicio == new DateTime(2027, 1, 27) &&
            filas[nieta.Id].Inicio == new DateTime(2027, 1, 28) &&
            filas.Values.All(f => f.Tarea.FechasImportadasDelphin != null) &&
            Firma(plan) == original &&
            Firma(cadena.Tareas.Select(t => new { t.Id, t.Codigo, t.Predecesoras, t.InicioBase, t.FinBase, t.DuracionBase })) ==
            Firma(plan.Tareas.Select(t => new { t.Id, t.Codigo, t.Predecesoras, t.InicioBase, t.FinBase, t.DuracionBase })),
            "normalizar el hito debe propagar el nuevo FC por sus sucesoras importadas sin desactivar instantáneas, alterar identidades, códigos, desfases o línea base, ni mutar el origen.");
        Exige(!MYGMotorCronograma.Calcular(cadena).Advertencias.Any(a => a.Contains("antes de lo requerido", StringComparison.Ordinal)),
            "la reparación de una sucesora del hito debe alcanzar también a su nieta y no dejar un FC incumplido.");
        pasa("Un hito automático importado en domingo se adapta como punto único y propaga sus nuevas necesidades FC por la red importada");
    }

    private static void IntervalosNoLaborablesIncompatibles(Action<string> pasa)
    {
        var plan = PlanDelCasoDomingo();
        Importada(plan, "INTERVALO SIN JORNADAS", new DateTime(2026, 9, 6), new DateTime(2026, 9, 6), 1);
        string original = Firma(plan);
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 27)),
            "un intervalo con trabajo declarado que quedaría invertido al adaptar sus extremos");
        Exige(Firma(plan) == original, "rechazar un intervalo invertido dejó cambios parciales.");

        var tramos = PlanDelCasoDomingo();
        var importada = Importada(tramos, "TRAMO SIN JORNADAS", new DateTime(2026, 9, 6), new DateTime(2026, 9, 9), 3);
        importada.FechasImportadasDelphin.Tramos.Add(new()
        {
            Id = "SOLO-DOMINGO", Inicio = new DateTime(2026, 9, 6, 8, 0, 0),
            Fin = new DateTime(2026, 9, 6, 17, 0, 0), Duracion = 1
        });
        original = Firma(tramos);
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(tramos, new DateTime(2026, 10, 27)),
            "un tramo importado que quedaría invertido al adaptar sus extremos");
        Exige(Firma(tramos) == original, "rechazar un tramo invertido modificó el documento original.");

        var fija = Plan();
        var tarea = Tarea(fija, "FECHA FIJA DEL DOMINGO");
        tarea.TipoRestriccion = MYGTipoRestriccion.DebeComenzarEl;
        tarea.FechaRestriccion = new DateTime(2026, 10, 11);
        original = Firma(fija);
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(fija, new DateTime(2026, 10, 6)),
            "una fecha fija de domingo sin un hueco no laborable equivalente");
        Exige(Firma(fija) == original, "normalizar una automática no autoriza a modificar una fecha fija incompatible.");
        pasa("Los intervalos y tramos invertidos y las fechas fijas incompatibles se rechazan sin aplicar cambios parciales");
    }

    private static void MismoInicioYPlanVacio(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "SIN CAMBIO", 2);
        string original = Firma(plan);
        var copia = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddHours(12));
        Exige(Firma(copia) == original && !ReferenceEquals(copia, plan) && Firma(plan) == original,
            "confirmar el mismo día debe devolver una copia sin reprogramar la configuración.");
        var vacio = Plan(); string vacioAntes = Firma(vacio);
        var actualizado = MYGTrasladoCronograma.MoverAlInicio(vacio, Inicio.AddDays(7));
        Exige(actualizado.Tareas.Count == 0 && actualizado.FechaInicio == Inicio.AddDays(7) &&
            actualizado.FechaEstado == vacio.FechaEstado && Firma(vacio) == vacioAntes,
            "un cronograma vacío debe poder cambiar su ancla sin crear tareas ni modificar el documento original.");
        pasa("Mismo inicio no reprograma y un plan vacío cambia su ancla sin crear tareas ni tocar el origen");
    }

    private static void RechazoAtomico(Action<string> pasa)
    {
        var ciclo = Plan(); var a = Tarea(ciclo, "A"); var b = Tarea(ciclo, "B");
        Depende(a, b, MYGTipoVinculo.FC); Depende(b, a, MYGTipoVinculo.FC);
        string antes = Firma(ciclo);
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(ciclo, Inicio.AddDays(7)), "una red circular");
        Exige(Firma(ciclo) == antes, "el traslado rechazado de una red circular mutó el plan.");
        var extremo = Plan(true); Tarea(extremo, "SE SALE DEL CALENDARIO", 2);
        antes = Firma(extremo);
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(extremo, DateTime.MaxValue.Date), "fechas que desbordan el calendario");
        Exige(Firma(extremo) == antes, "el error de rango dejó el origen parcialmente movido.");
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(extremo, default), "una fecha de inicio no válida");
        pasa("Los ciclos y fechas fuera del rango se rechazan antes de mutar el cronograma original");
    }

    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (ArgumentException) { return; }
        catch (InvalidOperationException) { return; }
        catch (OverflowException) { return; }
        throw new Exception("Traslado aceptó " + detalle + ".");
    }
}
