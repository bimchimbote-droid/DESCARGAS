using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

/// <summary>Traslada una copia del cronograma por jornadas laborables, sin
/// cambiar sus vínculos, modos, duraciones, línea base ni configuración.</summary>
public static class MYGTrasladoCronograma
{
    public static MYGCronograma MoverAlInicio(MYGCronograma original, DateTime nuevoInicio)
    {
        ArgumentNullException.ThrowIfNull(original);
        if (nuevoInicio == default) throw new InvalidDataException("Indique una fecha de inicio válida para trasladar el cronograma.");
        var antes = MYGMotorCronograma.Calcular(original);
        var copia = MYGProyectoStorage.Copia(original);
        if (nuevoInicio.Date == original.FechaInicio.Date) return copia;
        var calendario = new MYGCalendarioEntero(original.Calendario);
        long desfase = calendario.Primero(nuevoInicio) - calendario.Primero(original.FechaInicio);
        var activas = antes.Filas.Where(f => MYGMotorCronograma.ConservaFechasDelphin(f.Tarea))
            .Select(f => f.Tarea.Id).ToHashSet(StringComparer.Ordinal);
        var conflictosAntes = Conflictos(original, antes, calendario);
        bool hayAjustes = false;
        bool AutomaticaAjustable(MYGTareaCronograma tarea) => tarea.Modo == MYGModoTarea.Automatica &&
            !tarea.EsResumen && tarea.TipoRestriccion is not MYGTipoRestriccion.DebeComenzarEl and not MYGTipoRestriccion.DebeFinalizarEl;

        DateTime MoverFecha(DateTime fecha, MYGTareaCronograma tarea, string campo, long jornadas,
            bool fin = false, bool ajustar = false)
        {
            if (jornadas == 0) return fecha;
            try
            {
                DateTime destino;
                if (original.Calendario.EsLaborable(fecha))
                    destino = calendario.Fecha(calendario.Primero(fecha) + jornadas);
                else
                {
                    // Conservar el hueco cuando exista. Sólo las tareas
                    // automáticas pueden ajustarse a jornadas laborables;
                    // las fechas manuales y restricciones fijas siguen exactas.
                    DateTime? equivalente = null;
                    try
                    {
                        long anterior = calendario.AnteriorOIgual(fecha);
                        DateTime previoOriginal = calendario.Fecha(anterior);
                        DateTime previoNuevo = calendario.Fecha(anterior + jornadas);
                        DateTime siguienteNuevo = calendario.Fecha(calendario.Primero(fecha) + jornadas);
                        int posicion = (fecha.Date - previoOriginal).Days;
                        if (posicion < (siguienteNuevo - previoNuevo).Days)
                            equivalente = previoNuevo.AddDays(posicion);
                    }
                    catch (InvalidDataException) when (ajustar) { }
                    if (equivalente.HasValue) destino = equivalente.Value;
                    else if (ajustar)
                    {
                        destino = calendario.Fecha((fin ? calendario.AnteriorOIgual(fecha) : calendario.Primero(fecha)) + jornadas);
                        hayAjustes = true;
                    }
                    else throw new InvalidDataException("El calendario de destino no contiene un día no laborable equivalente.");
                }
                return DateTime.SpecifyKind(destino.Add(fecha.TimeOfDay), fecha.Kind);
            }
            catch (Exception ex) when (ex is InvalidDataException or ArgumentOutOfRangeException or OverflowException)
            {
                throw new InvalidDataException("No se puede conservar " + campo + " de la tarea «" + tarea.Nombre +
                    "» (" + fecha.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + ") al trasladar el bloque: " + ex.Message, ex);
            }
        }

        void MoverInstantanea(MYGTareaCronograma tarea, long jornadas)
        {
            var importadas = tarea.FechasImportadasDelphin;
            bool ajustar = AutomaticaAjustable(tarea);
            bool hito = tarea.DuracionDias == 0 && importadas.Inicio.Date == importadas.Fin.Date;
            if (tarea.InicioManual.HasValue)
                tarea.InicioManual = MoverFecha(tarea.InicioManual.Value, tarea, "el inicio guardado", jornadas, ajustar: ajustar);
            importadas.Inicio = MoverFecha(importadas.Inicio, tarea, "el inicio importado", jornadas, ajustar: ajustar);
            importadas.Fin = MoverFecha(importadas.Fin, tarea, "el fin importado", jornadas, fin: !hito, ajustar: ajustar);
            if (importadas.Fin.Date < importadas.Inicio.Date)
                throw new InvalidDataException("El intervalo importado de «" + tarea.Nombre +
                    "» queda sin jornadas laborables al trasladarlo. Revise sus fechas y calendario; no se aplicó el cambio.");
            foreach (var tramo in importadas.Tramos)
            {
                bool punto = tramo.Duracion == 0 && tramo.Inicio.Date == tramo.Fin.Date;
                tramo.Inicio = MoverFecha(tramo.Inicio, tarea, "el inicio del tramo importado", jornadas, ajustar: ajustar);
                tramo.Fin = MoverFecha(tramo.Fin, tarea, "el fin del tramo importado", jornadas, fin: !punto, ajustar: ajustar);
                if (tramo.Fin.Date < tramo.Inicio.Date)
                    throw new InvalidDataException("El tramo importado «" + tramo.Id + "» de la tarea «" + tarea.Nombre +
                        "» queda sin jornadas laborables al trasladarlo. Revise sus fechas y calendario; no se aplicó el cambio.");
            }
        }

        copia.FechaInicio = nuevoInicio.Date;
        string firmaCalendario = MYGMotorCronograma.FirmaCalendarioDelphin(copia.Calendario);
        foreach (var tarea in copia.Tareas)
        {
            if (tarea.InicioManual.HasValue && tarea.Modo == MYGModoTarea.Manual && !activas.Contains(tarea.Id))
                tarea.InicioManual = MoverFecha(tarea.InicioManual.Value, tarea, "el inicio guardado", desfase);
            if (tarea.FechaRestriccion.HasValue)
                tarea.FechaRestriccion = MoverFecha(tarea.FechaRestriccion.Value, tarea, "la fecha de restricción", desfase);
            if (tarea.FechasImportadasDelphin is not { } importadas) continue;
            if (!activas.Contains(tarea.Id))
            {
                // Los datos históricos que ya no programan esta tarea no
                // deben bloquear el traslado ni recuperar vigencia por azar.
                if (tarea.Modo == MYGModoTarea.Automatica)
                    importadas.FirmaAntecesoras = "MYG_TRASLADO_INSTANTANEA_OBSOLETA";
                continue;
            }
            MoverInstantanea(tarea, desfase);
            if (activas.Contains(tarea.Id))
            {
                importadas.InicioProyecto = copia.FechaInicio;
                importadas.FirmaCalendario = firmaCalendario;
                importadas.FirmaPredecesoras = MYGMotorCronograma.FirmaPredecesorasDelphin(tarea);
                // Primera pasada: todas las instantáneas activas ya contienen
                // las fechas trasladadas. Después se sellan sus antecesoras.
                importadas.FirmaAntecesoras = null;
            }
        }
        var intermedio = MYGMotorCronograma.Calcular(copia);
        var tareas = copia.Tareas.ToDictionary(t => t.Id, StringComparer.Ordinal);
        if (hayAjustes)
        {
            var hojas = copia.Tareas.Where(t => !t.EsResumen).ToList();
            var sucesoras = hojas.ToDictionary(t => t.Id, _ => new List<MYGTareaCronograma>(), StringComparer.Ordinal);
            var pendientes = hojas.ToDictionary(t => t.Id, t => t.Predecesoras.Count, StringComparer.Ordinal);
            foreach (var tarea in hojas)
                foreach (var vinculo in tarea.Predecesoras) sucesoras[vinculo.PredecesoraId].Add(tarea);
            var disponibles = new Queue<MYGTareaCronograma>(hojas.Where(t => pendientes[t.Id] == 0));
            var orden = new List<MYGTareaCronograma>();
            while (disponibles.TryDequeue(out var preparada))
            {
                orden.Add(preparada);
                foreach (var sucesora in sucesoras[preparada.Id])
                    if (--pendientes[sucesora.Id] == 0) disponibles.Enqueue(sucesora);
            }
            // Calcular por pasada, no por tarea. Una cadena de instantáneas
            // se resuelve en orden topológico dentro de la misma pasada; las
            // tareas normales y resúmenes se actualizan al terminarla.
            for (int pasada = 0; pasada < hojas.Count; pasada++)
            {
                var filas = intermedio.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
                bool corregido = false;
                foreach (var tarea in orden.Where(t => activas.Contains(t.Id) && AutomaticaAjustable(t)))
                {
                    var fila = filas[tarea.Id];
                    long jornadas = 0;
                    foreach (var vinculo in tarea.Predecesoras)
                    {
                        var anterior = filas[vinculo.PredecesoraId];
                        long requerido = Requerido(vinculo, anterior, calendario);
                        DateTime actual = vinculo.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC ? fila.Inicio : fila.Fin;
                        long tolerado = conflictosAntes.GetValueOrDefault(new("vínculo " + vinculo.Tipo, tarea.Id, vinculo.PredecesoraId));
                        jornadas = Math.Max(jornadas, requerido - calendario.AnteriorOIgual(actual) - tolerado);
                    }
                    if (jornadas <= 0) continue;
                    MoverInstantanea(tarea, jornadas);
                    fila.Inicio = tarea.FechasImportadasDelphin.Inicio.Date;
                    fila.Fin = tarea.FechasImportadasDelphin.Fin.Date;
                    corregido = true;
                }
                if (!corregido) break;
                intermedio = MYGMotorCronograma.Calcular(copia);
            }
        }
        var filasIntermedias = intermedio.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var tarea in copia.Tareas.Where(t => activas.Contains(t.Id)))
            tarea.FechasImportadasDelphin.FirmaAntecesoras = MYGMotorCronograma.FirmaAntecesorasDelphin(tarea, tareas, filasIntermedias);
        var despues = MYGMotorCronograma.Calcular(copia);
        var filasAntes = antes.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var fila in despues.Filas)
        {
            var anterior = filasAntes[fila.Tarea.Id];
            bool activaDespues = MYGMotorCronograma.ConservaFechasDelphin(fila.Tarea);
            bool flexible = hayAjustes && (fila.Tarea.EsResumen || AutomaticaAjustable(fila.Tarea));
            if (activaDespues != activas.Contains(fila.Tarea.Id) ||
                (!(flexible && fila.Tarea.EsResumen) && fila.DuracionDias != anterior.DuracionDias) ||
                (!flexible && (calendario.Primero(fila.Inicio) - calendario.Primero(anterior.Inicio) != desfase ||
                    calendario.AnteriorOIgual(fila.Fin) - calendario.AnteriorOIgual(anterior.Fin) != desfase)))
                throw new InvalidDataException("No se puede trasladar el bloque conservando las fechas relativas y la configuración de «" + fila.Tarea.Nombre + "». No se aplicó el cambio.");
        }
        foreach (var conflicto in Conflictos(copia, despues, calendario))
            if (conflicto.Value > conflictosAntes.GetValueOrDefault(conflicto.Key))
                throw new InvalidDataException("El traslado introduciría o empeoraría un conflicto de " + conflicto.Key.Tipo +
                    " en la tarea «" + tareas[conflicto.Key.Tarea].Nombre + "». No se aplicó el cambio; revise sus predecesoras y restricciones.");
        return copia;
    }

    private readonly record struct ClaveConflicto(string Tipo, string Tarea, string Predecesora = "");

    private static long Requerido(MYGDependenciaCronograma vinculo, MYGResultadoTarea anterior, MYGCalendarioEntero calendario) =>
        vinculo.Tipo switch
        {
            MYGTipoVinculo.FC => calendario.Despues(anterior.Fin) + vinculo.DesfaseDias,
            MYGTipoVinculo.CC => calendario.Primero(anterior.Inicio) + vinculo.DesfaseDias,
            MYGTipoVinculo.FF => calendario.Primero(anterior.Fin) + vinculo.DesfaseDias,
            _ => calendario.Primero(anterior.Inicio) + vinculo.DesfaseDias
        };

    private static Dictionary<ClaveConflicto, long> Conflictos(MYGCronograma plan, MYGResultadoCronograma resultado,
        MYGCalendarioEntero calendario)
    {
        var conflictos = new Dictionary<ClaveConflicto, long>();
        var filas = resultado.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var tarea in plan.Tareas.Where(t => !t.EsResumen))
        {
            var fila = filas[tarea.Id];
            foreach (var vinculo in tarea.Predecesoras)
            {
                var anterior = filas[vinculo.PredecesoraId];
                long requerido = Requerido(vinculo, anterior, calendario);
                DateTime actual = vinculo.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC ? fila.Inicio : fila.Fin;
                long incumplimiento = requerido - calendario.AnteriorOIgual(actual);
                if (incumplimiento > 0)
                    conflictos[new("vínculo " + vinculo.Tipo, tarea.Id, vinculo.PredecesoraId)] = incumplimiento;
            }
            if (MYGInformacionTarea.RequiereFecha(tarea.TipoRestriccion))
            {
                DateTime fecha = tarea.FechaRestriccion.Value.Date;
                bool incumple = tarea.TipoRestriccion switch
                {
                    MYGTipoRestriccion.NoComenzarAntesDe => fila.Inicio < fecha,
                    MYGTipoRestriccion.NoComenzarDespuesDe => fila.Inicio > fecha,
                    MYGTipoRestriccion.NoFinalizarAntesDe => fila.Fin < fecha,
                    MYGTipoRestriccion.NoFinalizarDespuesDe => fila.Fin > fecha,
                    MYGTipoRestriccion.DebeComenzarEl => fila.Inicio != fecha,
                    _ => fila.Fin != fecha
                };
                if (incumple) conflictos[new("restricción", tarea.Id)] = 1;
                if (tarea.TipoRestriccion is MYGTipoRestriccion.DebeComenzarEl or MYGTipoRestriccion.DebeFinalizarEl &&
                    !plan.Calendario.EsLaborable(fecha))
                    conflictos[new("restricción en día no laborable", tarea.Id)] = 1;
            }
            if (tarea.Modo == MYGModoTarea.Automatica && fila.HolguraDias < 0)
                conflictos[new("holgura negativa", tarea.Id)] = -(long)fila.HolguraDias;
        }
        return conflictos;
    }
}
