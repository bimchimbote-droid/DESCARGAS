using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGMoverTareasProyectoDialog : Form
{
    private readonly RadioButton radioMover = new()
    {
        Name = "mover_tareas_si", Text = "Mover tareas", AutoSize = true, Checked = true
    };
    private readonly RadioButton radioNoMover = new()
    {
        Name = "mover_tareas_no", Text = "No mover tareas", AutoSize = true
    };

    internal bool MoverTareas => radioMover.Checked;

    internal MYGMoverTareasProyectoDialog(DateTime inicioActual, DateTime nuevoInicio)
    {
        MYGCronogramaDialogoUI.Preparar(this, "mover_tareas_dialogo", "Mover tareas", new Size(630, 370));
        var contenido = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(16, 12, 16, 8)
        };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        contenido.Controls.Add(new Label
        {
            Name = "mover_tareas_mensaje", Dock = DockStyle.Fill,
            Text = "La fecha de inicio del proyecto ha cambiado. ¿Desea trasladar las tareas de acuerdo con la nueva fecha de inicio?"
        }, 0, 0);
        contenido.Controls.Add(new Label
        {
            Name = "mover_tareas_fechas", Dock = DockStyle.Fill,
            Text = "Inicio del cronograma: " + inicioActual.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) +
                "  →  " + nuevoInicio.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)
        }, 0, 1);
        var opciones = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false
        };
        opciones.Controls.Add(radioMover); opciones.Controls.Add(radioNoMover);
        contenido.Controls.Add(opciones, 0, 2);
        contenido.Controls.Add(new Label
        {
            Name = "mover_tareas_detalle", Dock = DockStyle.Fill,
            Text = "Se conservan vínculos, desfases, duraciones, modos y configuración. Las fechas de restricciones se trasladan con el bloque; la línea base y fecha de estado se conservan.\n\n" +
                "Las fechas automáticas importadas en días no laborables se ajustan al calendario y a sus predecesoras. Si una fecha manual o fija no puede conservarse, no se aplica el cambio."
        }, 0, 3);
        var aceptar = new Button
        {
            Name = "mover_tareas_aceptar", Text = "Aceptar", DialogResult = DialogResult.OK,
            AutoSize = true, MinimumSize = new Size(96, 30)
        };
        var cerrar = new Button
        {
            Name = "mover_tareas_cerrar", Text = "Cerrar", DialogResult = DialogResult.Cancel,
            AutoSize = true, MinimumSize = new Size(96, 30)
        };
        var botones = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false
        };
        botones.Controls.Add(cerrar); botones.Controls.Add(aceptar);
        contenido.Controls.Add(botones, 0, 4); Controls.Add(contenido);
        AcceptButton = aceptar; CancelButton = cerrar;
        MYGCronogramaDialogoUI.Tema(this);
    }
}

internal static class MYGCambioInicioProyecto
{
    // Prepara el documento completo antes de registrar historial o escribir en
    // SQLite. Cancelar o un fallo del motor deja el original intacto.
    internal static bool Preparar(IWin32Window owner, MYGProyectoDocumento original, string nombre,
        MYGDatosProyecto datos, out MYGProyectoDocumento candidato)
    {
        ArgumentNullException.ThrowIfNull(original);
        ArgumentNullException.ThrowIfNull(datos);
        candidato = null;
        if (string.IsNullOrWhiteSpace(nombre)) throw new InvalidOperationException("Indique el nombre del proyecto.");
        var propuesta = MYGProyectoStorage.Copia(original);
        propuesta.Nombre = nombre; propuesta.Datos = MYGProyectoStorage.Copia(datos);
        DateTime? anterior = original.Datos?.FechaInicio?.Date, nuevo = datos.FechaInicio?.Date;
        if (anterior != nuevo && nuevo.HasValue)
        {
            var plan = original.Cronograma != null
                ? MYGProyectoStorage.Copia(original.Cronograma)
                : MYGMotorCronograma.CrearDesdePresupuestos(original);
            if (plan.Tareas.Count > 0)
            {
                using var dialogo = new MYGMoverTareasProyectoDialog(plan.FechaInicio, nuevo.Value);
                if (dialogo.ShowDialog(owner) != DialogResult.OK) return false;
                // También conservar un plan generado al elegir No mover:
                // regenerarlo desde los datos nuevos desplazaría sus tareas.
                propuesta.Cronograma = dialogo.MoverTareas
                    ? MYGTrasladoCronograma.MoverAlInicio(plan, nuevo.Value) : plan;
            }
            else if (propuesta.Cronograma != null)
                propuesta.Cronograma.FechaInicio = nuevo.Value;
        }
        propuesta.Datos.Validar();
        if (propuesta.Cronograma != null) MYGMotorCronograma.Validar(propuesta.Cronograma);
        candidato = propuesta;
        return true;
    }
}
