using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

static class HojaMetradoCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static void Rechaza(Action accion, string mensaje)
    { try { accion(); } catch (InvalidDataException) { return; } throw new Exception(mensaje); }
    public static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var h = MYGHojaMetrado.Crear(); h.Poner("B3", "2"); h.Poner("C3", "3"); h.Poner("D3", "4");
        var c = MYGEdicionHoja.Celda(h, "A3"); c.Contenido = "Zapata"; c.Fuente = "Arial"; c.TamanoFuente = 12m;
        c.Negrita = c.Cursiva = c.Subrayado = c.Tachado = c.Bordes = c.AjustarTexto = true;
        c.ColorTexto = "123456"; c.ColorFondo = "FEDCBA"; c.AlineacionHorizontal = "Centro"; c.AlineacionVertical = "Abajo";
        var cantidad = MYGEdicionHoja.Celda(h, "B3"); cantidad.FormatoNumero = "0.00";
        h.Zoom = 125; h.LineasDivision = false; h.Encabezados = false; h.ColumnasInmovilizadas = 1;
        h.OrientacionPagina = "Horizontal"; h.TamanoPapel = "A3"; h.AreaImpresion = "A1:H16";
        h.ImprimirLineasDivision = h.ImprimirEncabezados = h.RepetirTitulos = true;
        h.MargenIzquierdo = 0.25m; h.MargenSuperior = 0.75m; h.FilasOcultas.Add(5); h.AltosFilas[5] = 30;
        cantidad.TipoValidacion = "Entero"; cantidad.Minimo = 0; cantidad.Maximo = 10;
        var lista = MYGEdicionHoja.Celda(h, "H3"); lista.TipoValidacion = "Lista"; lista.ListaValores.AddRange(new[] { "P-01", "P-02" }); lista.Contenido = "P-01";
        MYGHojaCalculo.Validar(h);
        var json = MYGProyectoStorage.Copia(h);
        Exige(json.Celdas["A3"].Subrayado && json.Celdas["A3"].TamanoFuente == 12 && json.FilasOcultas.SequenceEqual(new[] { 5 }) && json.RepetirTitulos,
            "La copia persistente perdió estilos y configuración de página.");
        Exige(new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 24 && new MYGHojaCalculo(h).Mostrar("B3") == 2m.ToString("0.00", CultureInfo.CurrentCulture),
            "El formato visual alteró el metrado o no se aplicó a un número.");
        var datos = new MYGDatosPartida(); Exige(!MYGMotorPresupuestos.TieneDatosPropios(datos), "La plantilla de hoja genera datos propios falsos.");
        datos.Hoja.Celdas["A2"].Subrayado = true; Exige(MYGMotorPresupuestos.TieneDatosPropios(datos), "Una biblioteca perdería formato sin datos nuevos.");
        datos = new(); datos.Hoja.Zoom = 125; Exige(MYGMotorPresupuestos.TieneDatosPropios(datos), "Una biblioteca perdería la vista personalizada.");
        pasa("Metrado XLS persiste fuente, estilos, formato numérico, vista y página sin alterar cantidades; biblioteca detecta cambios de formato");

        Exige(MYGEdicionHoja.TrasladarFormula("=SUM(A3:$B$5)+C$2+$D4", 2, 1) == "=SUM(B5:$B$5)+D$2+$D6", "Rellenar no respetó referencias absolutas y mixtas.");
        Exige(MYGEdicionHoja.TrasladarFormula("=IF(A3>0,LOG10(A3),\"A3\")", 1, 0) == "=IF(A4>0,LOG10(A4),\"A3\")", "Rellenar cambió texto literal o nombre de función.");
        Exige(MYGEdicionHoja.TrasladarFormula("=A1+$B$2", -1, 0) == "=#REF!+$B$2", "Referencia trasladada fuera de hoja no produce #REF!.");
        MYGEdicionHoja.InsertarFilas(h, 3, 2);
        Exige(h.CeldaTotal == "G18" && h.Celdas["G18"].Contenido == "=SUM(G5:G17)" && h.Celdas["A5"].Fuente == "Arial" &&
            h.Celdas["G5"].Contenido == "=PRODUCT(B5:F5)*IF(COUNT(B5:F5)=0,0,1)" && new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 24 && h.AreaImpresion == "A1:H18" && h.FilasOcultas.Contains(7),
            "Insertar filas perdió total, referencias, estilos o metadatos de impresión.");
        MYGEdicionHoja.InsertarColumnas(h, 2);
        Exige(h.CeldaTotal == "H18" && h.Celdas["H5"].Contenido.Contains("C5:G5") && h.RangosCombinados.Contains("A1:D1") && h.AnchosColumnas[3] == 58,
            "Insertar columnas no desplazó las referencias y combinaciones.");
        MYGEdicionHoja.EliminarColumnas(h, 2); MYGEdicionHoja.EliminarFilas(h, 3, 2);
        Exige(h.CeldaTotal == "G16" && new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 24 && h.RangosCombinados.Contains("A1:C1"), "La inserción/eliminación no conserva el metrado.");
        string antes = JsonSerializer.Serialize(h);
        Rechaza(() => MYGEdicionHoja.EliminarFilas(h, 16), "Se eliminó el metrado total.");
        Rechaza(() => MYGEdicionHoja.InsertarFilas(h, 1, 10000), "Se admitió una hoja excesiva.");
        Exige(JsonSerializer.Serialize(h) == antes, "Una operación estructural rechazada modificó la hoja.");
        var rangos = new MYGHojaMetrado { CeldaTotal = "G10", Filas = 20, Columnas = 8, FilasInmovilizadas = 0 };
        rangos.Poner("G10", "=SUM($A$3:A5)+A3"); rangos.Poner("A3", "1"); rangos.Poner("A4", "2"); rangos.Poner("A5", "3");
        MYGEdicionHoja.EliminarFilas(rangos, 3);
        Exige(rangos.Celdas["G9"].Contenido == "=SUM($A$3:A4)+#REF!" && new MYGHojaCalculo(rangos).Mostrar("G9") == "#ERROR",
            "Eliminar no contrajo un rango o dejó una referencia directa apuntando a otros datos.");
        var absolutas = new MYGHojaMetrado { CeldaTotal = "G10", Filas = 20, Columnas = 8 };
        absolutas.Poner("G10", "=$A$3+A$3+$A3"); MYGEdicionHoja.InsertarFilas(absolutas, 3);
        Exige(absolutas.Celdas["G11"].Contenido == "=$A$4+A$4+$A4", "La inserción estructural no ajustó referencias absolutas.");
        pasa("Insertar/eliminar filas y columnas ajusta fórmulas absolutas, rangos, total, combinaciones y dimensiones con atomicidad");

        var ordenar = new MYGHojaMetrado { CeldaTotal = "G10", Filas = 20, Columnas = 8 };
        ordenar.Poner("B1", "10"); ordenar.Poner("A3", "Zapata"); ordenar.Poner("B3", "3"); ordenar.Poner("C3", "=B3*$B$1");
        ordenar.Poner("A4", "Muro"); ordenar.Poner("B4", "1"); ordenar.Poner("C4", "=B4*$B$1"); ordenar.Celdas["A4"].ColorTexto = "FF0000";
        ordenar.Poner("A5", "Viga"); ordenar.Poner("B5", "2"); ordenar.Poner("C5", "=B5*$B$1");
        MYGEdicionHoja.Ordenar(ordenar, "A3:C5", 2);
        Exige(ordenar.Celdas["A3"].Contenido == "Muro" && ordenar.Celdas["A3"].ColorTexto == "FF0000" && ordenar.Celdas["C3"].Contenido == "=B3*$B$1" &&
            new MYGHojaCalculo(ordenar).Numero("C3") == 10 && ordenar.Celdas["A5"].Contenido == "Zapata", "Ordenar separó las fórmulas/estilos de sus filas.");
        MYGEdicionHoja.Ordenar(ordenar, "A3:C5", 2, true); Exige(ordenar.Celdas["A3"].Contenido == "Zapata", "Orden descendente incorrecto.");
        MYGEdicionHoja.Combinar(ordenar, "D3:F3");
        Rechaza(() => MYGEdicionHoja.Combinar(ordenar, "E3:G3"), "Se superpusieron combinaciones.");
        MYGEdicionHoja.Separar(ordenar, "E3"); Exige(ordenar.RangosCombinados.Count == 0, "Separar no detectó combinación dentro de la selección.");
        Rechaza(() => MYGEdicionHoja.Combinar(ordenar, "A3:B3"), "Combinar perdió un valor secundario.");
        pasa("Ordenar conserva filas, referencias relativas y estilos; combinar evita solapamientos y pérdida de contenido");

        MYGEdicionHoja.ValidarEntrada(h, "B3", "=2+3"); MYGEdicionHoja.ValidarEntrada(h, "B3", "");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "B3", "1.5"), "Validación entera admitió decimal.");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "B3", "11"), "Validación admitió número fuera de límites.");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "B3", "=B3+1"), "Validación admitió fórmula circular.");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "H3", "P-03"), "Validación admitió valor ajeno a lista.");
        MYGEdicionHoja.ValidarEntrada(h, "A4", "=FUNCION_NO_SOPORTADA(A1)");
        h.Poner("A4", "=FUNCION_NO_SOPORTADA(A1)"); Exige(new MYGHojaCalculo(h).Mostrar("A4") == "#ERROR", "No se puede conservar una fórmula no soportada como error visible.");
        pasa("Validación numérica/entera/lista aplica límites y evalúa fórmulas sin impedir el guardado de errores en celdas sin regla");

        string ruta = Path.Combine(carpeta, "Metrado estilos.xlsx"); MYGExcelPresupuestos.Guardar(ruta, new[] { h });
        var excel = MYGExcelPresupuestos.Importar(ruta, h.Nombre, h.CeldaTotal); var estilo = excel.Celdas["A3"];
        Exige(estilo.Negrita && estilo.Cursiva && estilo.Subrayado && estilo.Tachado && estilo.Bordes && estilo.AjustarTexto && estilo.Fuente == "Arial" && estilo.TamanoFuente == 12 &&
            estilo.ColorTexto == "123456" && estilo.ColorFondo == "FEDCBA" && estilo.AlineacionHorizontal == "Centro" && estilo.AlineacionVertical == "Abajo",
            "Excel perdió formato de celda durante exportación/importación.");
        Exige(excel.Zoom == 125 && !excel.LineasDivision && !excel.Encabezados && excel.ColumnasInmovilizadas == 1 && excel.OrientacionPagina == "Horizontal" && excel.TamanoPapel == "A3" &&
            excel.AreaImpresion == "A1:H16" && excel.RepetirTitulos && excel.MargenIzquierdo == 0.25m && excel.MargenSuperior == 0.75m && excel.ImprimirEncabezados && excel.ImprimirLineasDivision &&
            excel.AnchosColumnas[1] == 288 && excel.AltosFilas[5] == 30 && excel.FilasOcultas.Contains(5) && excel.RangosCombinados.Contains("D1:F1"),
            "Excel perdió vista, dimensiones, impresión o combinaciones.");
        Exige(excel.Celdas["B3"].TipoValidacion == "Entero" && excel.Celdas["B3"].Minimo == 0 && excel.Celdas["B3"].Maximo == 10 &&
            excel.Celdas["H3"].ListaValores.SequenceEqual(new[] { "P-01", "P-02" }) && new MYGHojaCalculo(excel).Numero(excel.CeldaTotal) == 24,
            "Excel perdió reglas de validación o valores/fórmulas.");
        using (var z = ZipFile.OpenRead(ruta))
        {
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            using var flujo = z.GetEntry("xl/worksheets/sheet1.xml").Open(); var hojaXml = XDocument.Load(flujo);
            Exige(hojaXml.Root.Elements().Select(x => x.Name.LocalName).SequenceEqual(new[] { "sheetViews", "sheetFormatPr", "cols", "sheetData", "mergeCells", "dataValidations", "printOptions", "pageMargins", "pageSetup" }),
                "La exportación incumple el orden de partes de una hoja OOXML.");
        }
        pasa("Excel exporta e importa formatos, reglas, combinaciones, zoom, inmovilización, tamaño de filas/columnas y configuración de impresión");
    }
}
