using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoExcelCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Proyecto de metrados", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            presupuesto.Item = "01";
            var primera = Partida("01", "CONCRETO EN COLUMNAS", 1);
            var segunda = Partida("02", "ACERO EN COLUMNAS", 2);
            primera.Costos.Hoja.Poner("A3", "Columna C-01");
            primera.Costos.Hoja.Celdas["A3"].ColorFondo = "C6EFCE";
            primera.Costos.Hoja.Celdas["A3"].ColorTexto = "006100";
            primera.Costos.Hoja.Poner("B3", "2");
            primera.Costos.Hoja.Poner("C3", "3");
            primera.Costos.Hoja.Poner("D3", "4");
            segunda.Costos.Hoja.Poner("A3", "Metrado de acero conservado");
            presupuesto.Items.AddRange(new[] { primera, segunda });
            int anteriores = 0, cambios = 0, guardados = 0, deshacer = 0, rehacer = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++, () => deshacer++, () => rehacer++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1800, 1000) };
            formulario.Controls.Add(panel);
            formulario.Show();
            panel.Refrescar();
            panel.SeleccionarEstructura(primera);
            var pagina = Campo<TabPage>(panel, "paginaExcel");
            var detalle = (TabControl)pagina.Parent;
            detalle.SelectedTab = pagina;
            Application.DoEvents();

            var hoja = Campo<DataGridView>(panel, "hoja");
            var cinta = Campo<TabControl>(panel, "cintaHoja");
            var cabecera = Campo<Control>(panel, "cabeceraExcel");
            var formula = Campo<TextBox>(panel, "formula");
            var direccion = Campo<TextBox>(panel, "direccion");
            var barraFormula = Controles(pagina).Single(c => c.Name == "metrado_barra_formula");
            var pestanas = Controles(pagina).OfType<TabControl>().Single(c => c.Name == "metrado_hojas");
            string[] titulos = { "Archivo", "Inicio", "Celdas", "Diseño de Página", "Fórmulas", "Insertar", "Datos", "Revisar", "Vista" };
            exige(cinta.Name == "metrado_cinta" && cinta.TabPages.Cast<TabPage>().Select(p => p.Text).SequenceEqual(titulos),
                "La cinta Excel debe ofrecer las nueve pestañas de las imágenes en el orden indicado.");
            exige(hoja.Name == "metrado_hoja" && pagina.Controls.Contains(hoja) && hoja.Columns.Contains("G") && hoja.Rows.Count >= 16,
                "La hoja debe conservar su integración directa con la página y cargar los datos antes de editar.");
            exige(hoja.Rows[2].Cells[0].Style.BackColor.ToArgb() == Color.FromArgb(198, 239, 206).ToArgb() &&
                hoja.Rows[2].Cells[0].Style.ForeColor.ToArgb() == Color.FromArgb(0, 97, 0).ToArgb(),
                "La hoja debe mostrar colores RGB de seis dígitos sin prefijo, como los importados de Excel.");
            exige(!direccion.ReadOnly && Controles(barraFormula).Contains(formula) && Controles(barraFormula).Contains(direccion),
                "La barra de fórmulas debe mostrar una dirección editable y el contenido de la celda.");
            exige(pestanas.TabPages.Count >= 1 && pestanas.TabPages[0].Text == primera.Costos.Hoja.Nombre,
                "La pestaña inferior debe identificar la hoja de metrado de la partida.");
            VerificarCabecera(cabecera, presupuesto.Nombre, "01.01", primera.Descripcion, exige);
            exige(cabecera.Top == 0 && cinta.PointToScreen(Point.Empty).Y >= cabecera.PointToScreen(new Point(0, cabecera.Height)).Y &&
                barraFormula.PointToScreen(Point.Empty).Y >= cinta.PointToScreen(new Point(0, cinta.Height)).Y &&
                hoja.PointToScreen(Point.Empty).Y >= barraFormula.PointToScreen(new Point(0, barraFormula.Height)).Y,
                "La cabecera, cinta, barra de fórmulas y hoja deben disponerse sin superposiciones.");

            // Cambiar la cinta es una acción de presentación y no debe tocar datos.
            var sinCambios = (anteriores, cambios, guardados);
            Seleccionar(hoja, "D7");
            foreach (TabPage pestana in cinta.TabPages)
            {
                cinta.SelectedTab = pestana;
                Application.DoEvents();
                exige(hoja.Visible && DireccionActual(hoja) == "D7",
                    $"La pestaña {pestana.Text} debe mantener visible la hoja y conservar la celda seleccionada.");
            }
            exige((anteriores, cambios, guardados) == sinCambios,
                "Recorrer la cinta no debe crear historial, modificar el metrado ni guardar el proyecto.");

            direccion.Text = "A4:C6";
            Invocar(panel, "IrDireccionHoja");
            Application.DoEvents();
            exige(hoja.SelectedCells.Count == 9 && DireccionActual(hoja) == "A4" &&
                hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.RowIndex >= 3 && c.RowIndex <= 5 && c.ColumnIndex <= 2),
                "La dirección debe seleccionar el rango completo indicado sin cambiar su contenido.");
            var seleccionAntes = hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex)).ToHashSet();
            direccion.Text = "A0:C6";
            bool direccionRechazada = false;
            try { Invocar(panel, "IrDireccionHoja"); }
            catch (Exception ex) when (ex is FormatException or InvalidOperationException or System.IO.InvalidDataException)
            { direccionRechazada = true; }
            exige(direccionRechazada && DireccionActual(hoja) == "A4" &&
                seleccionAntes.SetEquals(hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex))),
                "Una dirección inválida debe conservar el rango seleccionado y rechazar la navegación sin modificar datos.");
            exige((anteriores, cambios, guardados) == sinCambios,
                "Seleccionar un rango o rechazar una dirección no debe modificar el presupuesto.");
            Comando(panel, "deshacer");
            Comando(panel, "rehacer");
            exige(deshacer == 1 && rehacer == 1 && (anteriores, cambios, guardados) == sinCambios,
                "Deshacer y rehacer de la cinta deben invocar el historial del proyecto sin crear otro historial independiente.");

            EditarCelda(panel, hoja, "B3", "5", exige);
            exige(primera.Costos.Hoja.Celdas["B3"].Contenido == "5" &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("G3") == 60m &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("G16") == 60m,
                "Editar una dimensión en la tabla debe actualizar el modelo, el parcial y el total de metrado.");
            exige(anteriores == sinCambios.anteriores + 1 && cambios == sinCambios.cambios + 1 && guardados == 0,
                "Confirmar una celda debe registrar una modificación sin guardar automáticamente el proyecto.");

            Seleccionar(hoja, "I5");
            exige(direccion.Text == "I5", "Seleccionar una celda debe actualizar la dirección de la barra de fórmulas.");
            formula.Text = "=SUM(B3:C3)";
            Invocar(panel, "AplicarFormula");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["I5"].Contenido == "=SUM(B3:C3)" &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("I5") == 8m && formula.Text == "=SUM(B3:C3)",
                "La barra debe guardar la fórmula original y mostrar su resultado calculado en la hoja.");

            Seleccionar(hoja, "A3");
            Comando(panel, "negrita");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["A3"].Negrita && hoja.Rows[2].Cells[0].Style.Font?.Bold == true,
                "Negrita debe actualizar el estilo guardado y la celda visible de la selección.");
            Comando(panel, "cursiva");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["A3"].Negrita && primera.Costos.Hoja.Celdas["A3"].Cursiva &&
                hoja.Rows[2].Cells[0].Style.Font is Font fuenteMixta && fuenteMixta.Bold && fuenteMixta.Italic,
                "Combinar negrita y cursiva debe conservar ambos estilos en el modelo y en la celda visible.");
            sinCambios = (anteriores, cambios, guardados);
            var hojaAntesDeRechazo = primera.Costos.Hoja;
            bool formatoRechazado = false;
            try { Invocar(panel, "EditarFormatoHoja", (Action<MYGCeldaHoja>)(c => c.ColorFondo = "Red")); }
            catch (System.IO.InvalidDataException) { formatoRechazado = true; }
            exige(formatoRechazado && ReferenceEquals(primera.Costos.Hoja, hojaAntesDeRechazo) &&
                (anteriores, cambios, guardados) == sinCambios,
                "Un color inválido debe rechazarse antes de sustituir la hoja o crear historial.");
            bool validacionRechazada = false;
            try
            {
                Invocar(panel, "EditarFormatoHoja", (Action<MYGCeldaHoja>)(c =>
                { c.TipoValidacion = "Lista"; c.ListaValores = new() { new string('X', 254) }; }));
            }
            catch (System.IO.InvalidDataException) { validacionRechazada = true; }
            exige(validacionRechazada && ReferenceEquals(primera.Costos.Hoja, hojaAntesDeRechazo) &&
                (anteriores, cambios, guardados) == sinCambios,
                "Una regla de validación demasiado larga debe rechazarse sin dejar datos o estilos parcialmente modificados.");

            string formulaGuardada = primera.Costos.Hoja.Celdas["I5"].Contenido;
            Seleccionar(hoja, "J8");
            formula.Text = "=SUM(B3:C3)";
            // Cambiar de partida también debe confirmar el borrador de la barra.
            panel.SeleccionarEstructura(segunda);
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas.TryGetValue("J8", out var borrador) && borrador.Contenido == "=SUM(B3:C3)" &&
                !segunda.Costos.Hoja.Celdas.ContainsKey("J8"),
                "Cambiar de partida debe confirmar la fórmula pendiente en la partida de origen sin escribirla en la siguiente.");
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();
            sinCambios = (anteriores, cambios, guardados);
            panel.SeleccionarEstructura(segunda);
            Application.DoEvents();
            exige(Convert.ToString(hoja.Rows[2].Cells[0].Value) == "Metrado de acero conservado",
                "Cambiar de partida debe cargar su propia hoja sin heredar contenido de la anterior.");
            VerificarCabecera(cabecera, presupuesto.Nombre, "01.02", segunda.Descripcion, exige);
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["I5"].Contenido == formulaGuardada &&
                primera.Costos.Hoja.Celdas["A3"].Negrita && primera.Costos.Hoja.Celdas["A3"].Cursiva &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("I5") == 8m,
                "Volver a una partida debe conservar fórmulas, contenido y estilo sin convertir fórmulas en resultados.");
            exige((anteriores, cambios, guardados) == sinCambios,
                "Cambiar de partida y volver no debe crear modificaciones ni guardar el proyecto.");

            Seleccionar(hoja, "A4");
            int filasAntes = primera.Costos.Hoja.Filas;
            Comando(panel, "insertar_filas");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Filas == filasAntes + 1 && hoja.Rows.Count == primera.Costos.Hoja.Filas &&
                primera.Costos.Hoja.CeldaTotal == "G17" && new MYGHojaCalculo(primera.Costos.Hoja).Numero("G17") == 60m &&
                primera.Costos.Hoja.Celdas["I6"].Contenido == formulaGuardada,
                "Insertar una fila debe desplazar contenido y celda total, conservando el cálculo y las referencias.");

            // La restauración del historial reemplaza instancias conservando los Id.
            presupuesto = MYGProyectoStorage.Copia(presupuesto);
            proyecto.Presupuestos[0] = presupuesto;
            var vigente = presupuesto.Items.Single(i => i.Id == primera.Id);
            vigente.Descripcion = "CONCRETO RESTAURADO";
            vigente.Costos.Hoja.Celdas["A3"].Contenido = "Contenido restaurado desde historial";
            vigente.Costos.Hoja.Celdas["A3"].Negrita = true;
            panel.Refrescar();
            Application.DoEvents();
            exige(Convert.ToString(hoja.Rows[2].Cells[0].Value) == "Contenido restaurado desde historial",
                "Refrescar una partida con el mismo Id debe cargar el modelo vigente tras una restauración de historial.");
            VerificarCabecera(cabecera, presupuesto.Nombre, "01.01", vigente.Descripcion, exige);

            Seleccionar(hoja, "D7");
            Comando(panel, "zoom_mas");
            Application.DoEvents();
            exige(vigente.Costos.Hoja.Zoom == 110 && DireccionActual(hoja) == "D7",
                "Cambiar el zoom debe redimensionar la hoja conservando la celda seleccionada.");
            Comando(panel, "zoom_100");
            Application.DoEvents();
            exige(vigente.Costos.Hoja.Zoom == 100 && DireccionActual(hoja) == "D7",
                "Restablecer el zoom debe mantener la selección y la dirección de edición.");
            bool lineasAntes = vigente.Costos.Hoja.LineasDivision;
            Comando(panel, "lineas_division");
            Application.DoEvents();
            exige(vigente.Costos.Hoja.LineasDivision != lineasAntes && DireccionActual(hoja) == "D7",
                "Alternar las líneas de división debe conservar la celda seleccionada.");
            Comando(panel, "lineas_division");
            Application.DoEvents();
            sinCambios = (anteriores, cambios, guardados);
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos();
                Application.DoEvents();
                exige(DireccionActual(hoja) == "D7" && vigente.Costos.Hoja.Celdas["A3"].Contenido == "Contenido restaurado desde historial",
                    "Cambiar el tema debe preservar selección, datos y fórmulas de la hoja.");
                exige(hoja.CellBorderStyle == (vigente.Costos.Hoja.LineasDivision ? DataGridViewCellBorderStyle.Single : DataGridViewCellBorderStyle.None) &&
                    hoja.Rows[2].Cells[0].Style.BackColor.ToArgb() == Color.FromArgb(198, 239, 206).ToArgb() &&
                    hoja.Rows[2].Cells[0].Style.ForeColor.ToArgb() == Color.FromArgb(0, 97, 0).ToArgb(),
                    "El tema debe conservar la cuadrícula elegida y los colores de documento importados de Excel.");
                VerificarCabecera(cabecera, presupuesto.Nombre, "01.01", vigente.Descripcion, exige);
            }
            exige((anteriores, cambios, guardados) == sinCambios,
                "Aplicar la paleta no debe registrar modificaciones ni guardar el metrado.");

            typeof(MYGPanelPresupuesto).GetField("filtroTextoHoja", Privados).SetValue(panel, "restaurado");
            Comando(panel, "reaplicar_filtro");
            Application.DoEvents();
            exige(hoja.Rows[2].Visible && !hoja.Rows[3].Visible && hoja.CurrentCell != null && hoja.CurrentCell.OwningRow.Visible,
                "El filtro debe usar el contenido del modelo y trasladar la selección a una fila visible.");
            Invocar(panel, "CargarHoja");
            Application.DoEvents();
            exige(hoja.Rows[2].Visible && !hoja.Rows[3].Visible && hoja.CurrentCell?.RowIndex == 2,
                "Recargar una hoja filtrada debe calcular sus datos antes de filtrar y mantener una celda visible.");
            panel.SeleccionarEstructura(presupuesto.Items.Single(i => i.Id == segunda.Id));
            Application.DoEvents();
            exige(hoja.Rows[3].Visible && Convert.ToString(hoja.Rows[2].Cells[0].Value) == "Metrado de acero conservado",
                "Cambiar de partida debe limpiar el filtro local para evitar ocultar datos de la siguiente hoja.");
            panel.SeleccionarEstructura(vigente);
            Application.DoEvents();
            exige((anteriores, cambios, guardados) == sinCambios,
                "Filtrar, recargar y cambiar de partida deben conservar los datos sin crear historial de contenido.");

            panel.SeleccionarEstructura(presupuesto);
            Application.DoEvents();
            exige(!pagina.Enabled && hoja.Rows.Count == 0 && formula.Text == "" && direccion.Text == "",
                "Sin una partida editable, la página debe deshabilitarse y vaciar el contenido de la selección anterior.");
            exige(Etiqueta(cabecera, "item").Text == "" && Etiqueta(cabecera, "partida").Text != vigente.Descripcion,
                "Seleccionar el presupuesto debe limpiar el contexto de la partida en la cabecera de metrado.");
            exige(guardados == 0, "Las comprobaciones de metrado no deben guardar archivos ni bases de datos.");
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static ItemPresupuestoDelphin Partida(string item, string descripcion, int posicion) => new()
    {
        Id = MYGProyectoStorage.NuevoId(), Item = item, Descripcion = descripcion,
        Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = posicion,
        Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
    };

    private static void EditarCelda(MYGPanelPresupuesto panel, DataGridView hoja, string direccion, string texto, Action<bool, string> exige)
    {
        Seleccionar(hoja, direccion);
        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is TextBox,
            "La comprobación debe editar la celda real de la hoja.");
        ((TextBox)hoja.EditingControl).Text = texto;
        panel.FinalizarEdicion();
        Application.DoEvents();
    }

    private static void Seleccionar(DataGridView hoja, string direccion)
    {
        var posicion = MYGHojaCalculo.Coordenadas(direccion);
        hoja.ClearSelection();
        hoja.CurrentCell = hoja.Rows[posicion.Fila - 1].Cells[posicion.Columna - 1];
        hoja.CurrentCell.Selected = true;
    }

    private static string DireccionActual(DataGridView hoja) => hoja.CurrentCell == null ? "" :
        MYGHojaCalculo.Columna(hoja.CurrentCell.ColumnIndex + 1) + (hoja.CurrentCell.RowIndex + 1);

    private static T Campo<T>(object objeto, string nombre) =>
        (T)(objeto.GetType().GetField(nombre, Privados)?.GetValue(objeto)
            ?? throw new InvalidOperationException("No se encontró el campo de integración de metrado: " + nombre));

    private static void Comando(MYGPanelPresupuesto panel, string comando) => Invocar(panel, "EjecutarComandoHoja", comando);

    private static void Invocar(object objeto, string nombre, params object[] argumentos)
    {
        var metodo = objeto.GetType().GetMethod(nombre, Privados)
            ?? throw new InvalidOperationException("No se encontró el método de metrado: " + nombre);
        try { metodo.Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        {
            ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
            throw;
        }
    }

    private static void VerificarCabecera(Control cabecera, string presupuesto, string item, string descripcion, Action<bool, string> exige)
    {
        exige(Etiqueta(cabecera, "titulo").Text == "Metrado" && Etiqueta(cabecera, "presupuesto").Text == presupuesto &&
            Etiqueta(cabecera, "item").Text == item && Etiqueta(cabecera, "partida").Text == descripcion,
            "La cabecera de metrado debe compartir el contexto de especificaciones con los datos de la partida vigente.");
    }

    private static Label Etiqueta(Control cabecera, string dato) =>
        Controles(cabecera).OfType<Label>().Single(e => e.Name == cabecera.Name + "_" + dato);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
