# Agregar colaborador: una obra dentro de la misma base

## A. Implementación y estado real

Esta entrega incluye el cliente, el servicio .NET y la migración para colaborar
sobre una obra del mismo SQLite. **Para activarla en el equipo del usuario hay
que desplegar el servicio HTTPS y configurar su dirección. Copiar el ZIP por sí
solo no activa ese servidor.** No se ha desplegado ni contratado alojamiento,
ni se ha modificado el Supabase de producción desde esta sesión.

El mensaje de la captura provenía del bloqueo preventivo de la entrega anterior.
El botón ahora comprueba el servicio, registra una referencia con permisos y abre
la gestión de colaboradores. Antes de conceder acceso también comprueba que la
obra exista en la revisión publicada; sincronice la base antes de compartir obras
recién creadas localmente.

Al agregar un colaborador se guardan únicamente identidad de base, identidad de
obra y permisos. No se crea otro proyecto con datos, paquete persistido ni archivo
Storage de esa obra. El colaborador no recibe membresía de la base completa.
El servicio verifica su sesión, entrega solo la obra autorizada y aplica sus
cambios en la misma base con comparación de revisión. Las demás obras se protegen
contra modificaciones y no se entregan en el paquete de respuesta.

Se trabajó sobre `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`df8392a5d2910216a097349add3d20ba6103bdf5`. Este commit incorporó las entregas
anteriores durante la sesión. Se actualizaron las referencias locales comprobando
que los contenidos de 709 archivos permanecían iguales. No se hizo push al
repositorio del código. La rama local de trabajo es `work`.

## B. Archivos completos que aplicar

La tabla corresponde a las diferencias con ese commit. No hay eliminaciones ni
parches parciales. Si un archivo marcado CREAR ya existe por una entrega anterior,
compare su contenido y sustitúyalo por la versión completa de esta entrega.

| N.º | Ruta exacta | Acción | Descripción |
| --- | --- | --- | --- |
| 1 | `.dockerignore` | CREAR | Excluye salidas y configuración privada del contexto Docker. |
| 2 | `COLABORACION_MISMA_BASE.md` | CREAR | Instalación, activación, límites y evidencia de validación. |
| 3 | `MYG.Colaboracion/ClienteNubeCambios.cs` | REEMPLAZAR | Conserva operaciones completas para las vistas. |
| 4 | `MYG.Colaboracion/ClienteNubeComprimida.cs` | REEMPLAZAR | Evita subidas independientes de adjuntos para vistas. |
| 5 | `MYG.Colaboracion/ClienteNubeMismaBase.cs` | CREAR | Cliente de vistas, salud HTTPS y rutas autorizadas. |
| 6 | `MYG.Colaboracion/ClienteNubeProyectos.cs` | REEMPLAZAR | Listado, lectura, guardado y gestión de vistas. |
| 7 | `MYG.Colaboracion/ConfiguracionServicioNube.cs` | REEMPLAZAR | Conserva y valida ServicioBasesUrl. |
| 8 | `MYG.Colaboracion/ModelosNubeProyectos.cs` | REEMPLAZAR | Identifica obra virtual y su base original. |
| 9 | `MYG.Colaboracion/PublicacionObraBasePendiente.cs` | REEMPLAZAR | Compatibilidad que registra permisos sin publicar otra obra. |
| 10 | `MYG.Colaboracion/SincronizadorProyectoNube.cs` | REEMPLAZAR | Sincroniza la obra con revisión de su base. |
| 11 | `MYG.Desktop/ExploradorNubePresentacion.cs` | REEMPLAZAR | Identifica las obras que pertenecen a una base. |
| 12 | `MYG.Desktop/InicioColaboracionObraBase.cs` | REEMPLAZAR | Abre Agregar colaborador con la vista comprobada. |
| 13 | `MYG.Desktop/InicioNube.cs` | REEMPLAZAR | Abre y exporta únicamente el contenido autorizado. |
| 14 | `MYG.Desktop/NubeConfiguracion.cs` | REEMPLAZAR | Propaga la dirección del servicio sin credenciales secretas. |
| 15 | `MYG.Desktop/NubeForm.cs` | REEMPLAZAR | Explica el alcance de la obra compartida. |
| 16 | `MYG.Presupuestos.sln` | REEMPLAZAR | Incluye el servicio y sus pruebas. |
| 17 | `MYG.PruebasNube/ConfiguracionNubeCheck.cs` | REEMPLAZAR | Persistencia y validación de la nueva dirección. |
| 18 | `MYG.PruebasNube/MismaBaseClienteCheck.cs` | CREAR | Pruebas de cliente, sesiones y ausencia de copias. |
| 19 | `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Integra las comprobaciones y sus selectores. |
| 20 | `MYG.ServidorColaboracion.Pruebas/MYG.ServidorColaboracion.Pruebas.csproj` | CREAR | Proyecto de pruebas ejecutables del servidor. |
| 21 | `MYG.ServidorColaboracion.Pruebas/Program.cs` | CREAR | SQLite real, aislamiento, concurrencia e integridad. |
| 22 | `MYG.ServidorColaboracion.Pruebas/RepositorioHttpCheck.cs` | CREAR | Contrato HTTP, sesiones y errores de Supabase. |
| 23 | `MYG.ServidorColaboracion/Contratos.cs` | CREAR | Contexto autorizado y protocolo de confirmación. |
| 24 | `MYG.ServidorColaboracion/Dockerfile` | CREAR | Construcción y ejecución del servicio sin incluir claves. |
| 25 | `MYG.ServidorColaboracion/MYG.ServidorColaboracion.csproj` | CREAR | Proyecto ASP.NET .NET 10. |
| 26 | `MYG.ServidorColaboracion/MotorColaboracionBase.cs` | CREAR | Proyección y edición protegida del mismo SQLite. |
| 27 | `MYG.ServidorColaboracion/Program.cs` | CREAR | API con límites de solicitudes y autenticación. |
| 28 | `MYG.ServidorColaboracion/RepositorioSupabase.cs` | CREAR | Auth, Storage y RPC exclusivamente de servidor. |
| 29 | `scripts/pruebas/Probar-ColaboracionMismaBase.sh` | CREAR | PostgreSQL desechable y dos conexiones concurrentes. |
| 30 | `supabase/migraciones/20261105_colaboracion_misma_base.sql` | CREAR | Permisos por documento y CAS sobre la base existente. |
| 31 | `supabase/pruebas/colaboracion_misma_base.sql` | CREAR | Autorización, privacidad, revocación y migración repetible. |

## C. Descarga

`MYG_PRESUPUESTOS_ACTUALIZACION.zip` incluye únicamente los archivos de la tabla,
con sus rutas relativas. El ZIP se publica en una carpeta nueva de
`bimchimbote-droid/DESCARGAS`. La respuesta de entrega proporciona el enlace
público fijado al commit y el resultado de la descarga comparada por SHA-256.

## D. Instalación y activación, en este orden

1. Respaldar o confirmar los cambios locales. Revisar diferencias antes de
   reemplazar código modificado después del commit base. Respaldar también el
   proyecto Supabase antes de ejecutar migraciones.
2. Extraer el ZIP en la raíz del proyecto, por ejemplo
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, conservando las carpetas.
3. En SQL Editor del Supabase correcto, confirmar que ya están aplicadas
   `20261030_archivos_sqlite.sql`, `20261101_bases_obras.sql` y
   `20261104_modeladores_bim.sql`, con sus prerrequisitos. La migración nueva
   también reconoce el borrado seguro existente. No reinstalar la base a ciegas.
   La instalación se detiene si falta la guarda de
   base privada o hay miembros antiguos con acceso al SQLite completo; esos
   permisos deben revisarse antes de prometer acceso exclusivo a una obra.
4. Ejecutar COMPLETA `supabase/migraciones/20261105_colaboracion_misma_base.sql`,
   incluido BEGIN hasta COMMIT. Se puede repetir sin reemplazar permisos ya
   asignados. Si se produce un error, corregirlo antes de continuar; usar
   `ROLLBACK;` si SQL Editor quedó en una transacción abortada.
5. Instalar el servicio en un equipo o servidor confiable que permanezca disponible
   mientras se colabora. Publicarlo mediante HTTPS con un certificado válido.
   No instalar credenciales administrativas en los equipos de los colaboradores.
6. Configurar sus dos variables, mediante la configuración segura DEL SERVIDOR:
   - `MYG_SUPABASE_URL`: URL HTTPS del mismo proyecto Supabase que utiliza MYG.
   - `MYG_SUPABASE_SERVICE_ROLE_KEY`: clave administrativa service_role de ese
     proyecto. No ponerla en el ZIP, el repositorio, el JSON de MYG ni el chat.
7. En cada instalación de MYG, agregar `ServicioBasesUrl` con la dirección HTTPS
   pública del servicio a su configuración. Conservar Nombre, Url y ClavePublicable:
   ```json
   "ServicioBasesUrl": "https://SU-DOMINIO-DE-COLABORACION"
   ```
   El archivo local es `%LOCALAPPDATA%\MYG\Nube\config.json`. Si existe,
   prevalece sobre `nube-myg.json` junto al ejecutable. La dirección no admite
   usuario/contraseña, rutas, query ni fragmento. Nunca insertar service_role allí.
8. Compilar el programa en Release con .NET 10 y abrir la base desde Nube MYG.
   Guardar y sincronizar sus cambios antes de compartir una obra.
9. Pulsar Agregar colaborador en la obra, indicar su usuario MYG, elegir rol y
   módulos, y confirmar. El propietario y el colaborador deben usar la versión
   actualizada y el mismo servicio. El colaborador entra con SU cuenta; en Nube
   MYG verá la obra autorizada y podrá abrirla. Repetir Actualizar tras cambios
   de permisos. El rol lector sigue sin permitir edición.
10. Como comprobación manual, usar una base de prueba con dos obras y un segundo
    usuario: conceder solo la primera, verificar que la segunda no aparece ni se
    descarga; editar la primera, sincronizar y comprobar desde el propietario
    que ambos ven la misma edición y que la otra obra conserva sus datos.

### Ejecutar el servicio con .NET 10 instalado

Para compilar se necesita el SDK .NET 10. El host del servicio debe tener
ASP.NET Core Runtime 10 (el Desktop Runtime del programa Windows por sí solo
no basta), o utilizar la imagen Docker que ya incluye ASP.NET.

Desde la raíz del código:

```text
dotnet publish MYG.ServidorColaboracion/MYG.ServidorColaboracion.csproj -c Release -o servicio-colaboracion
```

Tras configurar las variables en el host, ejecutar el DLL publicado:

```text
dotnet MYG.ServidorColaboracion.dll --urls http://127.0.0.1:8080
```

La escucha de loopback sirve para el proxy HTTPS del mismo host. El cliente MYG
se conecta al dominio HTTPS publicado, no a ese puerto interno. La comprobación
`GET /health` informa servicio MYG_BASES, versión 1 y URL del Supabase configurado,
sin exigir ni devolver credenciales. MYG verifica esos valores antes de enviar
la sesión del usuario.

### Alternativa Docker

Desde la raíz del código, con Docker y los destinos oficiales de Microsoft y
NuGet permitidos:

```text
docker build -f MYG.ServidorColaboracion/Dockerfile -t myg-colaboracion:1 .
docker run --name myg-colaboracion --restart unless-stopped --env-file /RUTA-PRIVADA/myg-servidor.env -p 127.0.0.1:8080:8080 myg-colaboracion:1
```

El archivo privado de variables se crea fuera del checkout con acceso restringido
al administrador del servidor. No se incluye en la entrega. El contenedor usa
un usuario sin privilegios y los temporales se limpian al terminar cada petición.
El proxy HTTPS se configura en el host. La CA `proxy_ca` de BuildKit es opcional;
en un entorno con proxy corporativo debe montarse un bundle de confianza válido,
sin desactivar TLS ni copiar certificados/credenciales de la sesión a la imagen.

## E. Requisitos y límites

- Cliente y servicio: .NET 10; interfaz Windows Forms/WPF y Revit 2027 requieren
  Windows. El servicio puede ejecutarse en Windows o Linux. No se añaden paquetes
  NuGet al motor existente; el proyecto nuevo usa ASP.NET y las bibliotecas del repo.
- Los permisos por obra están en tablas privadas. Solo las RPC autenticadas
  administran acceso y solo service_role obtiene contexto de Storage/confirma CAS.
  No cambiar RLS ni hacer público el bucket para que funcione.
- La misma base conserva sus snapshots por revisión, como el protocolo anterior.
  Compartir/leer no sube snapshots. Guardar sí crea una nueva revisión normal.
  Un guardado que falla después de subir puede dejar un objeto no referenciado;
  no se borra automáticamente ante una confirmación incierta porque podría estar
  siendo usado por otra transacción. No se promete consumo cero por historial.
- No se borran ni migran automáticamente copias colaborativas ya creadas. Permanecen
  accesibles desde sus entradas anteriores. La modalidad nueva es Obra de la base.
- El protocolo requiere recursos y catálogos incorporados al SQLite. Las referencias
  a archivos externos del servidor se rechazan. Cambios que afectarían catálogos de
  otras obras o no se puedan representar íntegramente se rechazan conservando los
  pendientes; no se sustituyen por una copia independiente ni se descartan datos.
- El límite del archivo es 300 MiB, sujeto al plan y a los recursos del host. Hay dos
  operaciones simultáneas como máximo por proceso. Los tests usan datos sintéticos;
  no certifican rendimiento para cualquier base de 300 MiB ni concurrencia de producción.
- Registrar permisos no publica cambios locales sin sincronizar. Si una obra solo
  existe en el archivo local, sincronizar primero. El servicio comprueba la revisión
  real antes de que la UI permita conceder accesos.

## F. Validación real

SDK .NET **10.0.100**, Linux x64, compilación final de toda la solución y
publicación del servicio: **0 errores y 0 advertencias**.

| Comprobación ejecutada | Resultado real |
| --- | --- |
| Pruebas principales de MYG.Core | 810 aprobadas; Named Pipes de Windows y muestras privadas externas omitidos. |
| Cliente de misma base | 55 aprobadas, incluido reintento 401 con mismos bytes/UUID y cambio de identidad. |
| Configuración del servicio | 72 aprobadas. |
| Compatibilidad de colaboradores | 154 aprobadas. |
| Base SQLite única | 59 aprobadas. |
| API antigua sin servicio configurado | 11 aprobadas; no crea archivos ni publicaciones. |
| Motor del servidor | 15 casos y 119 comprobaciones aprobados con SQLite real. |
| Adaptador Supabase | 6 casos y 75 comprobaciones HTTP simuladas aprobados. |
| PostgreSQL 17 desechable | 244 comprobaciones aprobadas: 196 de prerrequisitos y 48 específicas, incluidas dos conexiones concurrentes y rechazo de instalaciones sin la guarda del archivo completo. |
| Servicio publicado arrancado como proceso | Salud HTTP 200; GET y POST sin sesión devuelven 401, incluso con JSON roto. |

Las 119 pruebas del motor incluyen un recorrido integrado con ClienteSupabase y
SincronizadorProyectoNube reales contra el motor real, usando HTTP y repositorio
simulados: descargar una sola obra, editarla, guardar sobre la misma base,
conservar la otra obra, confirmar la cola durable, releer sin cambios fantasma y
revocar el acceso. Las autorreferencias y el JSON de catálogos no exponen rutas
temporales del servidor y sobreviven al guardado y reintento. No duplicar el
recuento del adaptador porque su consola imprime dos resúmenes del mismo grupo.

La suite completa MYG.PruebasNube **se ejecutó y terminó con exit 1** en el defecto
previo `PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`: el mensaje de
renovación identifica una fase distinta de la esperada. Ese mismo fallo se había
observado antes de este cambio. No se ocultó ni se deshabilitó la prueba; los
casos posteriores a ese punto no llegaron a ejecutarse. Las comprobaciones
específicas de esta entrega sí se ejecutaron y aprobaron.

La construcción de la imagen Docker **no se pudo completar**: el proxy rechazó
`centralus.data.mcr.microsoft.com` al descargar la imagen oficial. Se añadió ese
dominio al borrador de red conservando los existentes, pero el cambio no está
aplicado a la instancia. No se desactivaron TLS ni verificaciones. La publicación
con dotnet y el arranque nativo sí se completaron; no se afirma que la imagen
Docker se haya construido o iniciado en este entorno.

No se probaron la interfaz Windows, Revit ni el Supabase real. Las muestras de
producción y los benchmarks de archivos máximos tampoco se ejecutaron.

Comandos para repetir las comprobaciones desde la raíz:

```text
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.ServidorColaboracion.Pruebas/MYG.ServidorColaboracion.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --misma-base-cliente
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --configuracion-nube
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --compatibilidad-colaboradores
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --base-sqlite-unica
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
bash scripts/pruebas/Probar-ColaboracionMismaBase.sh
```

Las pruebas `supabase/pruebas/*.sql` y el runner son exclusivamente para PostgreSQL
DESECHABLE. Nunca ejecutarlas en el Supabase real: crean fixtures, roles y simulan
Storage. En producción se ejecuta solo la migración indicada.

## G. Publicación del código

Se publica únicamente el ZIP en DESCARGAS. No se hace push del código de la aplicación.
Después de aplicar y validar, abrir Cambios de Git en Visual Studio, revisar todos
los archivos y su diff, confirmar con un mensaje como Implementar colaboración por
obra en la misma base, hacer Push a la rama de trabajo y comprobar su commit en
GitHub. Si se realizaron cambios locales posteriores, integrarlos antes de copiar
archivos completos. La descarga del ZIP no aplica ni publica esos cambios por sí sola.

## H. Pendiente de producción

Elegir/configurar un host HTTPS disponible para el servicio, introducir sus valores
privados mediante un canal seguro e instalar la migración en el proyecto real.
No se dispone de ese host ni de autorización/configuración para desplegarlo desde
esta sesión. Windows, Revit y el Supabase del usuario requieren la comprobación
manual descrita; no se presentan como probados. Esta entrega implementa el flujo y
lo valida localmente; su activación real necesita esos pasos adicionales.
