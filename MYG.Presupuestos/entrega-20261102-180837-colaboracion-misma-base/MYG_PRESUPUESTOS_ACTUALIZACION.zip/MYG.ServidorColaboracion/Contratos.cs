using System.Text.Json;
using System.Text.Json.Serialization;
using MYG_2027;

namespace MYG.ServidorColaboracion;

public sealed record ArchivoBase(string Ruta, string Sha256, long Bytes);
public sealed record ContextoBase(Guid Vista, Guid Base, string Documento, Guid Propietario,
    long Revision, string Rol, MYGPermisosModulos Permisos, ArchivoBase Archivo, JsonElement Proyecto);
public sealed record SolicitudGuardar(
    [property: JsonPropertyName("operacion_id")] Guid OperacionId,
    [property: JsonPropertyName("revision")] long Revision,
    [property: JsonPropertyName("contenido")] JsonElement Contenido);
public sealed record Confirmacion(string Estado, long Revision, Guid OperacionId);
public sealed record CambioBase(Guid Vista, Guid Actor, Guid Operacion, long Revision,
    ArchivoBase Archivo, JsonElement Anterior, JsonElement Nuevo, string SolicitudSha);

/// <summary>La implementación productiva es el único lugar que conserva la credencial del servidor.</summary>
public interface IRepositorioBase
{
    Task<Guid> AutenticarAsync(string bearer, CancellationToken ct);
    Task<ContextoBase> ContextoAsync(Guid vista, Guid actor, long? revision, CancellationToken ct);
    Task DescargarAsync(ArchivoBase archivo, string destino, CancellationToken ct);
    Task SubirAsync(ArchivoBase archivo, string fuente, CancellationToken ct);
    Task<Confirmacion> ConfirmarAsync(CambioBase cambio, CancellationToken ct);
}

public sealed class ErrorServicio(int estado, string codigo, string mensaje) : Exception(mensaje)
{
    public int Estado { get; } = estado;
    public string Codigo { get; } = codigo;
}
