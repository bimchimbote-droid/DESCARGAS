using System.Net;
using System.Text.Json;
using Microsoft.AspNetCore.Http.Features;
using MYG.ServidorColaboracion;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = 320L * 1024 * 1024);
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.MaxDepth = 128);
string url = Environment.GetEnvironmentVariable("MYG_SUPABASE_URL") ?? "";
string clave = Environment.GetEnvironmentVariable("MYG_SUPABASE_SERVICE_ROLE_KEY") ?? "";
var repositorio = new RepositorioSupabase(url, clave);
builder.Services.AddSingleton<IRepositorioBase>(repositorio);
builder.Services.AddSingleton<MotorColaboracionBase>();
var app = builder.Build();
// Un límite global acota el coste de los snapshots grandes; nunca se acumulan
// cuerpos de solicitudes esperando turno ni se registran tokens o paquetes.
using var concurrencia = new SemaphoreSlim(2, 2);
app.Use(async (contexto, siguiente) =>
{
    if (contexto.Request.Path == "/health") { await siguiente(); return; }
    if (!await concurrencia.WaitAsync(0, contexto.RequestAborted))
    {
        contexto.Response.StatusCode = 429;
        await contexto.Response.WriteAsJsonAsync(new { codigo = "MYG_SERVICIO_OCUPADO", mensaje = "El servicio está ocupado. Reintente la misma operación." });
        return;
    }
    using var limite = CancellationTokenSource.CreateLinkedTokenSource(contexto.RequestAborted);
    limite.CancelAfter(TimeSpan.FromMinutes(3));
    contexto.RequestAborted = limite.Token;
    try { await siguiente(); }
    catch (ErrorServicio error)
    {
        contexto.Response.StatusCode = error.Estado;
        await contexto.Response.WriteAsJsonAsync(new { codigo = error.Codigo, mensaje = error.Message }, CancellationToken.None);
    }
    catch (OperationCanceledException)
    {
        contexto.Response.StatusCode = 504;
        await contexto.Response.WriteAsJsonAsync(new { codigo = "MYG_TIEMPO_AGOTADO", mensaje = "Se agotó la espera. Conserve y reintente la misma operación pendiente." }, CancellationToken.None);
    }
    catch (BadHttpRequestException error)
    {
        contexto.Response.StatusCode = error.StatusCode;
        await contexto.Response.WriteAsJsonAsync(new { codigo = "MYG_SOLICITUD_INVALIDA", mensaje = "La solicitud no tiene un formato o tamaño admitido." }, CancellationToken.None);
    }
    catch (JsonException)
    {
        contexto.Response.StatusCode = 400;
        await contexto.Response.WriteAsJsonAsync(new { codigo = "MYG_CONTENIDO_INVALIDO", mensaje = "El contenido JSON de la solicitud no es válido." }, CancellationToken.None);
    }
    catch (Exception)
    {
        // No serializar Exception.Message: puede contener rutas locales, SQL,
        // respuestas remotas o valores privados de las obras.
        contexto.Response.StatusCode = 502;
        await contexto.Response.WriteAsJsonAsync(new { codigo = "MYG_SERVICIO_NO_DISPONIBLE", mensaje = "No se pudo completar la operación. Conserve los cambios pendientes." }, CancellationToken.None);
    }
    finally { concurrencia.Release(); }
});
app.MapGet("/health", () => Results.Json(new { servicio = "MYG_BASES", version = 1, supabase_url = repositorio.Url }));
app.MapGet("/obras/{vista:guid}", async (Guid vista, HttpContext http, IRepositorioBase r, MotorColaboracionBase motor) =>
    Results.Json(await motor.AbrirAsync(vista, await Actor(http, r), http.RequestAborted)));
app.MapPost("/obras/{vista:guid}/guardar", async (Guid vista, HttpContext http, IRepositorioBase r, MotorColaboracionBase motor) =>
{
    // Autenticar antes de materializar el paquete (puede ser grande). El límite
    // de Kestrel y la cancelación siguen aplicándose durante la lectura.
    Guid actor = await Actor(http, r);
    if (!http.Request.HasJsonContentType())
        throw new ErrorServicio(415, "MYG_CONTENIDO_INVALIDO", "La solicitud debe usar contenido JSON.");
    var solicitud = await http.Request.ReadFromJsonAsync<SolicitudGuardar>(http.RequestAborted)
        ?? throw new ErrorServicio(400, "MYG_CONTENIDO_INVALIDO", "La solicitud está vacía.");
    return Results.Json(await motor.GuardarAsync(vista, actor, solicitud, http.RequestAborted));
});
app.Run();

static Task<Guid> Actor(HttpContext http, IRepositorioBase repositorio)
{
    string cabecera = http.Request.Headers.Authorization.ToString();
    if (!cabecera.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        throw new ErrorServicio(401, "MYG_SESION_INVALIDA", "Inicie sesión para acceder a esta obra.");
    return repositorio.AutenticarAsync(cabecera[7..], http.RequestAborted);
}

public partial class Program;
