using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using MYG_2027;

namespace MYG.ServidorColaboracion;

public sealed class RepositorioSupabase : IRepositorioBase
{
    private readonly HttpClient http;
    private readonly string clave;
    public string Url { get; }

    public RepositorioSupabase(string url, string claveServicio, HttpClient? cliente = null)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var u) || u.Scheme != "https" || u.UserInfo.Length != 0
            || u.AbsolutePath != "/" || u.Query.Length != 0 || u.Fragment.Length != 0)
            throw new InvalidOperationException("Configure MYG_SUPABASE_URL con la URL HTTPS del proyecto.");
        if (string.IsNullOrWhiteSpace(claveServicio)) throw new InvalidOperationException("Configure MYG_SUPABASE_SERVICE_ROLE_KEY solo en el servidor.");
        Url = u.GetLeftPart(UriPartial.Authority);
        clave = claveServicio;
        http = cliente ?? new HttpClient(new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false }) { Timeout = TimeSpan.FromSeconds(150) };
    }

    public async Task<Guid> AutenticarAsync(string bearer, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(bearer) || bearer.Length > 16384 || bearer.Any(char.IsWhiteSpace)) throw Auth();
        using var q = Solicitud(HttpMethod.Get, "auth/v1/user", bearer);
        using var r = await http.SendAsync(q, HttpCompletionOption.ResponseHeadersRead, ct);
        if (!r.IsSuccessStatusCode) throw Auth();
        using var j = await LeerJson(r, 65536, ct);
        if (!j.RootElement.TryGetProperty("id", out var id) || !Guid.TryParse(id.GetString(), out var actor) || actor == Guid.Empty) throw Auth();
        return actor;
    }

    public async Task<ContextoBase> ContextoAsync(Guid vista, Guid actor, long? revision, CancellationToken ct)
    {
        using var j = await Rpc("myg_base_contexto_servidor", new { p_id = vista, p_actor = actor, p_revision = revision }, ct);
        var r = j.RootElement;
        try
        {
            var proyecto = r.GetProperty("proyecto");
            var permisos = r.GetProperty("permisos_modulos");
            string[] campos = ["acu", "especificaciones", "metrados_excel", "metrados_revit"];
            if (permisos.ValueKind != JsonValueKind.Object || permisos.EnumerateObject().Count() != 4
                || permisos.EnumerateObject().Select(x => x.Name).Distinct(StringComparer.Ordinal).Count() != 4
                || campos.Any(c => !permisos.TryGetProperty(c, out var v) || v.ValueKind is not (JsonValueKind.True or JsonValueKind.False))) throw Denegado();
            var flags = permisos.Deserialize<MYGPermisosModulos>()!; flags.MetradosRevitDisponible = true;
            var archivo = r.GetProperty("archivo_sqlite");
            var contexto = new ContextoBase(proyecto.GetProperty("id").GetGuid(), r.GetProperty("base_id").GetGuid(),
                r.GetProperty("documento_id").GetString()!, r.GetProperty("propietario").GetGuid(), r.GetProperty("revision").GetInt64(),
                r.GetProperty("rol").GetString()!, flags,
                new(archivo.GetProperty("ruta").GetString()!, archivo.GetProperty("sha256").GetString()!, archivo.GetProperty("bytes").GetInt64()), proyecto.Clone());
            ValidarArchivo(contexto.Archivo);
            return contexto;
        }
        catch (Exception ex) when (ex is KeyNotFoundException or InvalidOperationException or FormatException)
        { throw new ErrorServicio(502, "MYG_CONTEXTO_INVALIDO", "El servidor no devolvió el contexto autorizado de la obra."); }
    }

    public async Task DescargarAsync(ArchivoBase archivo, string destino, CancellationToken ct)
    {
        ValidarArchivo(archivo);
        using var q = Solicitud(HttpMethod.Get, "storage/v1/object/myg-nube-sqlite/" + archivo.Ruta);
        using var r = await http.SendAsync(q, HttpCompletionOption.ResponseHeadersRead, ct);
        if (!r.IsSuccessStatusCode || r.Content.Headers.ContentLength is long bytes && bytes != archivo.Bytes) throw Upstream();
        await using var fuente = await r.Content.ReadAsStreamAsync(ct);
        await using var salida = new FileStream(destino, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536, true);
        var buffer = new byte[65536]; long total = 0; int n;
        while ((n = await fuente.ReadAsync(buffer, ct)) != 0)
        {
            total += n;
            if (total > archivo.Bytes || total > MotorColaboracionBase.MaxBytes) throw Upstream();
            await salida.WriteAsync(buffer.AsMemory(0, n), ct);
        }
        if (total != archivo.Bytes) throw Upstream();
    }

    public async Task SubirAsync(ArchivoBase archivo, string fuente, CancellationToken ct)
    {
        ValidarArchivo(archivo);
        await using var lectura = File.OpenRead(fuente);
        using var q = Solicitud(HttpMethod.Post, "storage/v1/object/myg-nube-sqlite/" + archivo.Ruta);
        q.Content = new StreamContent(lectura); q.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
        q.Headers.Add("x-upsert", "false");
        using var r = await http.SendAsync(q, HttpCompletionOption.ResponseHeadersRead, ct);
        if (r.IsSuccessStatusCode) return;
        if (r.StatusCode == HttpStatusCode.Conflict || r.StatusCode == HttpStatusCode.BadRequest)
        {
            // Una subida repetida solo se adopta después de comprobar los bytes
            // existentes; un HTTP 400 aislado no prueba que sea el mismo objeto.
            string temporal = Path.GetTempFileName(); File.Delete(temporal);
            try
            {
                await DescargarAsync(archivo, temporal, ct);
                using var previo = File.OpenRead(temporal);
                string hash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(previo));
                if (hash.Equals(archivo.Sha256, StringComparison.OrdinalIgnoreCase)) return;
            }
            finally { if (File.Exists(temporal)) File.Delete(temporal); }
        }
        throw Upstream();
    }

    public async Task<Confirmacion> ConfirmarAsync(CambioBase c, CancellationToken ct)
    {
        using var j = await Rpc("myg_base_confirmar_servidor", new
        {
            p_id = c.Vista, p_actor = c.Actor, p_operacion = c.Operacion, p_revision = c.Revision,
            p_ruta = c.Archivo.Ruta, p_sha256 = c.Archivo.Sha256, p_bytes = c.Archivo.Bytes,
            p_anterior = c.Anterior, p_nuevo = c.Nuevo, p_solicitud_sha = c.SolicitudSha
        }, ct);
        try
        {
            var r = j.RootElement;
            return new(r.GetProperty("estado").GetString()!, r.GetProperty("revision").GetInt64(), r.GetProperty("operacion_id").GetGuid());
        }
        catch (Exception ex) when (ex is KeyNotFoundException or InvalidOperationException or FormatException) { throw Upstream(); }
    }

    private async Task<JsonDocument> Rpc(string funcion, object cuerpo, CancellationToken ct)
    {
        using var q = Solicitud(HttpMethod.Post, "rest/v1/rpc/" + funcion);
        q.Content = new StringContent(JsonSerializer.Serialize(cuerpo, new JsonSerializerOptions { MaxDepth = 128 }), Encoding.UTF8, "application/json");
        using var r = await http.SendAsync(q, HttpCompletionOption.ResponseHeadersRead, ct);
        if (!r.IsSuccessStatusCode)
        {
            string? codigo = null;
            try { using var error = await LeerJson(r, 65536, ct); if (error.RootElement.TryGetProperty("code", out var c) && c.ValueKind == JsonValueKind.String) codigo = c.GetString(); }
            catch (Exception ex) when (ex is JsonException or ErrorServicio) { }
            if (codigo == "42501" || r.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized) throw Denegado();
            if (codigo is "22023" or "23505") throw new ErrorServicio(400, "MYG_OPERACION_INVALIDA", "La operación o su identificador no son válidos; se conservan los cambios pendientes.");
            if (codigo is "55P03" or "55006" or "40001") throw new ErrorServicio(409, "MYG_BASE_OCUPADA", "La base está ocupada. Reintente la misma operación.");
            throw Upstream();
        }
        return await LeerJson(r, 2 * 1024 * 1024, ct);
    }

    private HttpRequestMessage Solicitud(HttpMethod metodo, string ruta, string? bearer = null)
    {
        var q = new HttpRequestMessage(metodo, Url + "/" + ruta);
        q.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer ?? clave);
        q.Headers.Add("apikey", clave);
        return q;
    }

    private static async Task<JsonDocument> LeerJson(HttpResponseMessage r, int maximo, CancellationToken ct)
    {
        if (r.Content.Headers.ContentLength > maximo) throw Upstream();
        await using var s = await r.Content.ReadAsStreamAsync(ct); using var m = new MemoryStream();
        var buffer = new byte[8192]; int n;
        while ((n = await s.ReadAsync(buffer, ct)) != 0)
        { if (m.Length + n > maximo) throw Upstream(); m.Write(buffer, 0, n); }
        return JsonDocument.Parse(m.ToArray(), new JsonDocumentOptions { MaxDepth = 128 });
    }

    private static void ValidarArchivo(ArchivoBase a)
    {
        var partes = a.Ruta?.Split('/');
        if (partes?.Length != 3 || !Guid.TryParseExact(partes[0], "D", out var usuario) || usuario == Guid.Empty
            || !Guid.TryParseExact(partes[1], "N", out var b) || b == Guid.Empty || partes[2] != a.Sha256 + ".sqlite"
            || a.Sha256.Length != 64 || a.Sha256.Any(c => !char.IsAsciiHexDigit(c))
            || a.Bytes is < 512 or > MotorColaboracionBase.MaxBytes) throw Upstream();
    }
    private static ErrorServicio Auth() => new(401, "MYG_SESION_INVALIDA", "Inicie sesión de nuevo para acceder a esta obra.");
    private static ErrorServicio Denegado() => new(403, "MYG_ACCESO_DENEGADO", "No tiene permiso para acceder o guardar esta obra.");
    private static ErrorServicio Upstream() => new(502, "MYG_SERVICIO_NO_DISPONIBLE", "No se pudo confirmar la comunicación con el almacenamiento. Conserve la operación pendiente y reintente.");
}
