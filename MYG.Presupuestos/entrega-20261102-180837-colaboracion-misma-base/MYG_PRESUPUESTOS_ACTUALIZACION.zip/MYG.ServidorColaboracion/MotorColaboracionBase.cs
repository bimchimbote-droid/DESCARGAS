using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Encodings.Web;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

namespace MYG.ServidorColaboracion;

/// <summary>Solo procesa temporales privados. La autorización y el CAS se revalidan al confirmar en PostgreSQL.</summary>
public sealed class MotorColaboracionBase(IRepositorioBase repositorio, string? carpetaTemporal = null)
{
    public const long MaxBytes = 300L * 1024 * 1024;
    private readonly string raiz = carpetaTemporal ?? Path.Combine(Path.GetTempPath(), "myg-servidor-colaboracion");
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };

    public async Task<JsonElement> AbrirAsync(Guid vista, Guid actor, CancellationToken ct = default)
    {
        ValidarIdentidades(vista, actor);
        var contexto = await repositorio.ContextoAsync(vista, actor, null, ct);
        ValidarContexto(contexto, vista);
        return await EnTemporal(async carpeta =>
        {
            string archivo = await Descargar(contexto, carpeta, ct);
            var contenido = Proyectar(archivo, contexto.Documento);
            var actual = await repositorio.ContextoAsync(vista, actor, contexto.Revision, ct);
            ValidarContexto(actual, vista);
            return ConContenido(actual, contenido);
        });
    }

    public async Task<JsonElement> GuardarAsync(Guid vista, Guid actor, SolicitudGuardar solicitud,
        CancellationToken ct = default)
    {
        ValidarIdentidades(vista, actor);
        if (solicitud.OperacionId == Guid.Empty || solicitud.Revision < 1 || solicitud.Revision == long.MaxValue)
            throw Invalido();
        var contexto = await repositorio.ContextoAsync(vista, actor, null, ct);
        ValidarContexto(contexto, vista);
        if (contexto.Rol is not ("propietario" or "administrador" or "editor")) throw Denegado();
        var contenido = ValidarContenido(solicitud.Contenido, contexto.Documento);
        string fingerprint = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(
            vista.ToString("D") + "\n" + actor.ToString("D") + "\n" + solicitud.OperacionId.ToString("D")
            + "\n" + solicitud.Revision.ToString(CultureInfo.InvariantCulture) + "\n" + contenido.GetRawText()))).ToLowerInvariant();

        return await EnTemporal(async carpeta =>
        {
            string original = await Descargar(contexto, carpeta, ct);
            var anterior = Proyectar(original, contexto.Documento);
            Confirmacion respuesta;
            if (contexto.Revision != solicitud.Revision)
            {
                // La RPC distingue un ACK perdido de un UUID nuevo con revisión obsoleta.
                // Ninguno de estos dos casos necesita subir otro archivo.
                respuesta = await repositorio.ConfirmarAsync(new(vista, actor, solicitud.OperacionId,
                    solicitud.Revision, contexto.Archivo, anterior, anterior, fingerprint), ct);
            }
            else
            {
                var documentoAnterior = PaqueteNube.LeerDocumento(anterior);
                var documentoNuevo = PaqueteNube.LeerDocumento(contenido);
                try { MYGCambiosModulosNube.ExigirPermitidos(documentoAnterior, documentoNuevo, contexto.Permisos); }
                catch (InvalidOperationException) { throw Denegado(); }

                // Comparar todas las demás obras antes/después protege también contra
                // triggers de SQLite y cambios accidentales en catálogos compartidos.
                var otras = MYGBaseDatos.ListarProyectos(original).Where(p => p.Id != contexto.Documento)
                    .ToDictionary(p => p.Id, p => PaqueteNube.FirmaDatosCompartidos(Proyectar(original, p.Id)), StringComparer.Ordinal);
                string trabajo = Path.Combine(carpeta, "trabajo.sqlite");
                File.Copy(original, trabajo);
                ReubicarCatalogosDelTemporal(trabajo);
                var nuevo = PaqueteNube.MaterializarDocumento(contenido, trabajo);
                using (var c = AbrirSqlite(trabajo, false))
                using (var t = c.BeginTransaction())
                {
                    PaqueteNube.AplicarDependencias(contenido, c, t);
                    t.Commit();
                }
                MYGBaseDatos.GuardarProyecto(trabajo, nuevo);
                ct.ThrowIfCancellationRequested();
                foreach (var otra in otras)
                    if (PaqueteNube.FirmaDatosCompartidos(Proyectar(trabajo, otra.Key)) != otra.Value)
                        throw new ErrorServicio(400, "MYG_OTRA_OBRA_PROTEGIDA", "El cambio afectaría a otra obra. No se confirmó ninguna modificación.");
                if (!MYGBaseDatos.ListarProyectos(trabajo).Select(p => p.Id).Order().SequenceEqual(
                    MYGBaseDatos.ListarProyectos(original).Select(p => p.Id).Order())) throw Invalido();

                var proyectado = Proyectar(trabajo, contexto.Documento);
                if (PaqueteNube.FirmaDatosCompartidos(proyectado) != PaqueteNube.FirmaDatosCompartidos(contenido))
                    throw new ErrorServicio(400, "MYG_CAMBIO_NO_REPRESENTABLE", "El cambio no puede incorporarse íntegramente a esta obra. No se guardó otra versión.");

                string snapshot = Path.Combine(carpeta, "confirmacion.sqlite");
                CopiaSqliteNube.CrearSnapshot(trabajo, snapshot, ct);
                ArchivoPublicacionSqlitePendiente.NormalizarCopiaPortable(snapshot, trabajo, ct);
                ValidarSqlite(snapshot);
                string hash = Hash(snapshot);
                var archivo = new ArchivoBase(actor.ToString("D") + "/" + contexto.Base.ToString("N") + "/" + hash + ".sqlite",
                    hash, new FileInfo(snapshot).Length);
                if (archivo.Bytes > MaxBytes) throw Invalido();
                // El cálculo puede tomar tiempo. Revalidar antes de subir evita
                // crear otro objeto por una revocación o CAS ya observable.
                var antesDeSubir = await repositorio.ContextoAsync(vista, actor, null, ct);
                ValidarContexto(antesDeSubir, vista);
                if (antesDeSubir.Rol is not ("propietario" or "administrador" or "editor")) throw Denegado();
                try { MYGCambiosModulosNube.ExigirPermitidos(documentoAnterior, documentoNuevo, antesDeSubir.Permisos); }
                catch (InvalidOperationException) { throw Denegado(); }
                if (antesDeSubir.Revision != solicitud.Revision)
                    respuesta = await repositorio.ConfirmarAsync(new(vista, actor, solicitud.OperacionId,
                        solicitud.Revision, antesDeSubir.Archivo, anterior, anterior, fingerprint), ct);
                else
                {
                    await repositorio.SubirAsync(archivo, snapshot, ct);
                    respuesta = await repositorio.ConfirmarAsync(new(vista, actor, solicitud.OperacionId,
                        solicitud.Revision, archivo, anterior, proyectado, fingerprint), ct);
                }
            }
            if (respuesta.OperacionId != solicitud.OperacionId || respuesta.Estado is not ("aplicada" or "conflicto")
                || respuesta.Revision < 1) throw new ErrorServicio(502, "MYG_RESPUESTA_INVALIDA", "No se pudo verificar la confirmación del servidor.");
            // La operación puede ser idempotente o haber quedado en conflicto. Solo
            // se devuelve su revisión autorizada, nunca el snapshot completo.
            var confirmado = await repositorio.ContextoAsync(vista, actor, respuesta.Revision, ct);
            ValidarContexto(confirmado, vista);
            string retorno = await Descargar(confirmado, carpeta, ct, "respuesta.sqlite");
            var contenidoRespuesta = Proyectar(retorno, confirmado.Documento);
            // Una retirada de acceso durante la descarga tampoco entrega datos.
            ValidarContexto(await repositorio.ContextoAsync(vista, actor, respuesta.Revision, ct), vista);
            return JsonSerializer.SerializeToElement(new
            {
                estado = respuesta.Estado, revision = respuesta.Revision, operacion_id = respuesta.OperacionId,
                contenido = contenidoRespuesta
            }, Json);
        });
    }

    private async Task<T> EnTemporal<T>(Func<string, Task<T>> accion)
    {
        Directory.CreateDirectory(raiz);
        string carpeta = Path.Combine(raiz, Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(carpeta, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        try { return await accion(carpeta); }
        catch (ErrorServicio) { throw; }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex) when (ex is InvalidDataException or InvalidOperationException or JsonException or SqliteException or ArgumentException)
        { throw Invalido(); }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private async Task<string> Descargar(ContextoBase contexto, string carpeta, CancellationToken ct, string nombre = "original.sqlite")
    {
        string ruta = Path.Combine(carpeta, nombre);
        await repositorio.DescargarAsync(contexto.Archivo, ruta, ct);
        if (new FileInfo(ruta).Length != contexto.Archivo.Bytes || !Hash(ruta).Equals(contexto.Archivo.Sha256, StringComparison.OrdinalIgnoreCase))
            throw new ErrorServicio(502, "MYG_SQLITE_INTEGRIDAD", "La revisión SQLite no pasó la comprobación de integridad.");
        ValidarSqlite(ruta);
        return ruta;
    }

    private static JsonElement Proyectar(string ruta, string documento)
    {
        // Validar antes de cualquier API que pueda abrir archivos referidos en los
        // datos. Solo se admiten autorreferencias y recursos ya embebidos en SQLite.
        ExigirReferenciasSeguras(ruta);
        var doc = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documento);
        ExigirRutas(JsonSerializer.SerializeToElement(doc, Json), ruta);
        return NormalizarReferenciasDeRespuesta(PaqueteNube.CrearContenido(doc, ruta, "obra", compacto: false));
    }

    private static JsonElement NormalizarReferenciasDeRespuesta(JsonElement paquete)
    {
        // CrearContenido trabaja con rutas locales para resolver dependencias.
        // Ninguna ruta del temporal del servidor debe formar parte del contrato:
        // los clientes materializan el alias propio en su archivo de trabajo.
        var nodo = JsonNode.Parse(paquete.GetRawText())!;
        NormalizarReferenciasJson(nodo);
        if (nodo["tablas"] is JsonArray tablas)
            foreach (var tabla in tablas.OfType<JsonObject>())
            {
                if (tabla["Columnas"] is not JsonArray columnas || tabla["Filas"] is not JsonArray filas) continue;
                for (int i = 0; i < columnas.Count; i++)
                {
                    if (columnas[i] is not JsonValue columna || !columna.TryGetValue<string>(out string? nombre)
                        || nombre is null || !nombre.StartsWith("json_", StringComparison.OrdinalIgnoreCase)) continue;
                    foreach (var fila in filas.OfType<JsonArray>())
                    {
                        if (i >= fila.Count || fila[i] is not JsonObject celda || celda["Tipo"]?.GetValue<string>() != "texto"
                            || celda["Valor"] is not JsonValue valor || !valor.TryGetValue<string>(out string? texto)
                            || string.IsNullOrWhiteSpace(texto)) continue;
                        JsonNode? interno;
                        try { interno = JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 }); }
                        catch (JsonException) { continue; }
                        if (NormalizarReferenciasJson(interno)) celda["Valor"] = interno!.ToJsonString(Json);
                    }
                }
            }
        return JsonSerializer.SerializeToElement(nodo, Json);
    }

    private static bool NormalizarReferenciasJson(JsonNode? nodo)
    {
        bool cambio = false;
        if (nodo is JsonObject objeto)
            foreach (var campo in objeto.ToArray())
            {
                bool referencia = campo.Key.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase);
                if (referencia && campo.Value is JsonValue valor && valor.TryGetValue<string>(out string? texto)
                    && !string.IsNullOrWhiteSpace(texto) && texto != ArchivoPublicacionSqlitePendiente.ReferenciaPropia)
                {
                    objeto[campo.Key] = ArchivoPublicacionSqlitePendiente.ReferenciaPropia;
                    cambio = true;
                }
                else cambio |= NormalizarReferenciasJson(campo.Value);
            }
        else if (nodo is JsonArray lista)
            foreach (var hijo in lista) cambio |= NormalizarReferenciasJson(hijo);
        return cambio;
    }

    private static void ReubicarCatalogosDelTemporal(string ruta)
    {
        // AplicarDependencias materializa los aliases del paquete en la ruta de
        // trabajo. Reubicar los mismos aliases del catálogo existente permite
        // comparar filas equivalentes sin confundir una ruta con un cambio de
        // datos compartidos. Solo se modifica este temporal, nunca el original;
        // NormalizarCopiaPortable vuelve a guardar el alias al confirmar.
        using var c = AbrirSqlite(ruta, false);
        using var t = c.BeginTransaction();
        var json = new JsonSerializerOptions { MaxDepth = 128, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
        foreach (var campo in new[] { ("catalogo_insumo", "json_datos"), ("catalogo_partida", "json_plantilla"), ("catalogo_partida_nodo", "json_datos") })
        {
            var cambios = new List<(long Fila, string Json)>();
            using (var q = c.CreateCommand())
            {
                q.Transaction = t;
                q.CommandText = "SELECT rowid," + Identificador(campo.Item2) + " FROM " + Identificador(campo.Item1);
                using var r = q.ExecuteReader();
                while (r.Read())
                {
                    if (r.GetValue(1) is not string texto) continue;
                    JsonNode? nodo;
                    try { nodo = JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 }); }
                    catch (JsonException) { continue; }
                    if (ReubicarAliasJson(nodo, ruta)) cambios.Add((r.GetInt64(0), nodo!.ToJsonString(json)));
                }
            }
            foreach (var cambio in cambios)
            {
                using var q = c.CreateCommand(); q.Transaction = t;
                q.CommandText = "UPDATE " + Identificador(campo.Item1) + " SET " + Identificador(campo.Item2) + "=$json WHERE rowid=$id";
                q.Parameters.AddWithValue("$json", cambio.Json); q.Parameters.AddWithValue("$id", cambio.Fila); q.ExecuteNonQuery();
            }
        }
        t.Commit();
    }

    private static bool ReubicarAliasJson(JsonNode? nodo, string destino)
    {
        bool cambio = false;
        if (nodo is JsonObject objeto)
            foreach (var campo in objeto.ToArray())
            {
                bool referencia = campo.Key.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase)
                    || campo.Key.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase);
                if (referencia && campo.Value is JsonValue valor && valor.TryGetValue<string>(out string? texto)
                    && texto == ArchivoPublicacionSqlitePendiente.ReferenciaPropia)
                { objeto[campo.Key] = destino; cambio = true; }
                else cambio |= ReubicarAliasJson(campo.Value, destino);
            }
        else if (nodo is JsonArray lista)
            foreach (var hijo in lista) cambio |= ReubicarAliasJson(hijo, destino);
        return cambio;
    }

    private static JsonElement ValidarContenido(JsonElement contenido, string documento)
    {
        try { return ValidarContenidoInterno(contenido, documento); }
        catch (ErrorServicio) { throw; }
        catch (Exception ex) when (ex is InvalidDataException or InvalidOperationException or JsonException
            or ArgumentException or KeyNotFoundException or IndexOutOfRangeException or FormatException)
        { throw Invalido(); }
    }

    private static JsonElement ValidarContenidoInterno(JsonElement contenido, string documento)
    {
        contenido = FormatoPaqueteNube.Expandir(contenido);
        if (contenido.ValueKind != JsonValueKind.Object || !contenido.TryGetProperty("alcance", out var a) || a.GetString() != "obra"
            || !contenido.TryGetProperty("documentos", out var documentos) || documentos.ValueKind != JsonValueKind.Array
            || documentos.GetArrayLength() != 1 || PaqueteNube.LeerDocumento(contenido).Id != documento)
            throw Invalido();
        var unico = documentos[0].Deserialize<MYGProyectoDocumento>(new JsonSerializerOptions { PropertyNameCaseInsensitive = true, MaxDepth = 128 });
        if (unico?.Id != documento || MYGProyectoStorage.Firma(unico) != MYGProyectoStorage.Firma(PaqueteNube.LeerDocumento(contenido))) throw Invalido();
        if (contenido.TryGetProperty("recursos", out var r) && (r.ValueKind != JsonValueKind.Array || r.GetArrayLength() != 0))
            throw new ErrorServicio(400, "MYG_RECURSOS_SQLITE", "Los adjuntos deben estar embebidos en SQLite; no se guardan archivos externos por obra.");
        ExigirRutas(contenido, null);
        if (contenido.TryGetProperty("tablas", out var tablas))
            foreach (var tabla in tablas.EnumerateArray())
            {
                var columnas = tabla.GetProperty("Columnas").EnumerateArray().Select(x => x.GetString()!).ToArray();
                foreach (var fila in tabla.GetProperty("Filas").EnumerateArray())
                    for (int i = 0; i < columnas.Length; i++)
                        if (columnas[i].StartsWith("json_", StringComparison.OrdinalIgnoreCase)
                            && fila[i].TryGetProperty("Valor", out var valor) && valor.ValueKind == JsonValueKind.String)
                        {
                            try { using var json = JsonDocument.Parse(valor.GetString()!, new JsonDocumentOptions { MaxDepth = 128 }); ExigirRutas(json.RootElement, null); }
                            catch (JsonException) { }
                        }
            }
        return contenido.Clone();
    }

    private static void ValidarContexto(ContextoBase c, Guid vista)
    {
        if (c.Vista != vista || c.Base == Guid.Empty || c.Base == vista || c.Revision < 1 || string.IsNullOrWhiteSpace(c.Documento)
            || c.Rol is not ("propietario" or "administrador" or "editor" or "lector")
            || c.Archivo.Bytes is < 512 or > MaxBytes || c.Archivo.Sha256.Length != 64) throw Denegado();
    }

    private static JsonElement ConContenido(ContextoBase c, JsonElement contenido)
    {
        var salida = JsonNode.Parse(c.Proyecto.GetRawText())!.AsObject();
        salida.Remove("archivo_sqlite"); salida.Remove("ruta");
        salida["vista_base"] = true;
        salida["base_id"] = c.Base.ToString("D"); salida["documento_id"] = c.Documento;
        salida["revision"] = c.Revision;
        salida["contenido"] = JsonNode.Parse(contenido.GetRawText());
        return JsonSerializer.SerializeToElement(salida, Json);
    }

    private static void ExigirReferenciasSeguras(string ruta)
    {
        using var c = AbrirSqlite(ruta, true);
        var escaneos = new List<(string Tabla, string Columna)>();
        using (var q = c.CreateCommand())
        {
            q.CommandText = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'";
            using var r = q.ExecuteReader();
            var tablas = new List<string>(); while (r.Read()) tablas.Add(r.GetString(0));
            r.Close();
            foreach (string tabla in tablas)
            {
                using var info = c.CreateCommand(); info.CommandText = "PRAGMA table_info(" + Identificador(tabla) + ")";
                using var cols = info.ExecuteReader();
                while (cols.Read()) if (cols.GetString(1).StartsWith("json_", StringComparison.OrdinalIgnoreCase)) escaneos.Add((tabla, cols.GetString(1)));
            }
        }
        foreach (var campo in escaneos)
        {
            using var q = c.CreateCommand(); q.CommandText = "SELECT " + Identificador(campo.Columna) + " FROM " + Identificador(campo.Tabla);
            using var r = q.ExecuteReader();
            while (r.Read()) if (r.GetValue(0) is string texto && !string.IsNullOrWhiteSpace(texto))
                try { using var j = JsonDocument.Parse(texto, new JsonDocumentOptions { MaxDepth = 128 }); ExigirRutas(j.RootElement, ruta); }
                catch (JsonException) { }
        }
    }

    private static void ExigirRutas(JsonElement valor, string? propia)
    {
        if (valor.ValueKind == JsonValueKind.Object)
        {
            var vistos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in valor.EnumerateObject())
            {
                if (!vistos.Add(p.Name)) throw Invalido();
                if (p.Value.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(p.Value.GetString()))
                {
                    if (p.Name.Equals("ImagenRuta", StringComparison.OrdinalIgnoreCase) || p.Name.Equals("FichaTecnicaRuta", StringComparison.OrdinalIgnoreCase)) throw Invalido();
                    if (p.Name.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase) || p.Name.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase) || p.Name.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase))
                    {
                        string r = p.Value.GetString()!;
                        if (r != ArchivoPublicacionSqlitePendiente.ReferenciaPropia && (propia is null || r != propia))
                        {
                            // Rutas propias del cliente no se abren al materializar:
                            // el normalizador de PaqueteNube las reubica a la base temporal.
                            if (propia != null) throw Invalido();
                        }
                    }
                }
                ExigirRutas(p.Value, propia);
            }
        }
        else if (valor.ValueKind == JsonValueKind.Array) foreach (var hijo in valor.EnumerateArray()) ExigirRutas(hijo, propia);
    }

    private static void ValidarSqlite(string ruta)
    {
        if (new FileInfo(ruta).Length is < 512 or > MaxBytes) throw Invalido();
        using var c = AbrirSqlite(ruta, true);
        using var q = c.CreateCommand(); q.CommandText = "PRAGMA integrity_check";
        using var r = q.ExecuteReader();
        if (!r.Read() || r.GetString(0) != "ok" || r.Read()) throw Invalido();
    }
    private static SqliteConnection AbrirSqlite(string ruta, bool lectura)
    {
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = lectura ? SqliteOpenMode.ReadOnly : SqliteOpenMode.ReadWrite, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = "PRAGMA trusted_schema=OFF; PRAGMA foreign_keys=ON;"; q.ExecuteNonQuery(); return c;
    }
    private static string Hash(string ruta) { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)).ToLowerInvariant(); }
    private static string Identificador(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";
    private static void ValidarIdentidades(Guid vista, Guid actor) { if (vista == Guid.Empty || actor == Guid.Empty) throw Denegado(); }
    private static ErrorServicio Invalido() => new(400, "MYG_CONTENIDO_INVALIDO", "El contenido no corresponde a la obra o no es compatible con la base. No se confirmó ningún cambio.");
    private static ErrorServicio Denegado() => new(403, "MYG_ACCESO_DENEGADO", "No tiene permiso para realizar esta operación en la obra.");
}
