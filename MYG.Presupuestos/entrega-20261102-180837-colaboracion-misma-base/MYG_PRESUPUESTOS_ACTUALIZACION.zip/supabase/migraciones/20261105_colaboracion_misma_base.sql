-- Vistas autorizadas de una obra del MISMO SQLite. Solo guarda metadatos de
-- permisos; no publica proyectos, paquetes ni objetos de Storage adicionales.
-- Requiere 20261104_modeladores_bim.sql. El acceso al binario completo sigue
-- privado: solo un backend de confianza usa los dos RPC *_servidor.
begin;

do $preflight$
begin
    if to_regclass('myg_nube_privado.sqlite_proyectos') is null
       or to_regclass('myg_nube_privado.sqlite_revisiones') is null
       or to_regprocedure('myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb)') is null
       or to_regprocedure('myg_nube_privado.bim_paquete(jsonb)') is null then
        raise exception 'Aplique primero archivos SQLite y 20261104_modeladores_bim.sql.';
    end if;
    if to_regprocedure('myg_nube_privado.base_proteger_miembro()') is null
       or not exists(select 1 from pg_trigger where tgrelid='public.myg_nube_miembros'::regclass
           and tgname='myg_base_privada_miembro' and not tgisinternal and tgenabled in ('O','A')) then
        raise exception 'Aplique primero 20261101_bases_obras.sql con su protección de base privada habilitada.';
    end if;
    if exists(select 1 from public.myg_nube_proyectos p
        join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
        join public.myg_nube_miembros m on m.proyecto_id=p.id
        where p.alcance='base' and (m.usuario_id<>p.propietario or m.rol<>'propietario')) then
        raise exception 'Hay accesos previos al SQLite completo. Revise esos accesos antes de compartir solo una obra; no se modificaron sus permisos.';
    end if;
end $preflight$;

create table if not exists myg_nube_privado.base_vistas (
    id uuid primary key default gen_random_uuid(),
    base_id uuid not null references myg_nube_privado.sqlite_proyectos(proyecto_id) on delete cascade,
    documento_id text not null check(length(documento_id) between 1 and 200
        and documento_id=btrim(documento_id) and documento_id !~ '[[:cntrl:]]'),
    nombre text not null check(length(btrim(nombre)) between 1 and 2000 and nombre !~ '[[:cntrl:]]'),
    creado_en timestamptz not null default clock_timestamp(),
    unique(base_id,documento_id)
);
create table if not exists myg_nube_privado.base_vista_miembros (
    vista_id uuid not null references myg_nube_privado.base_vistas(id) on delete cascade,
    usuario_id uuid not null,
    rol text not null check(rol in ('propietario','administrador','editor','lector')),
    permisos_modulos jsonb not null,
    primary key(vista_id,usuario_id)
);
create table if not exists myg_nube_privado.base_vista_operaciones (
    vista_id uuid not null references myg_nube_privado.base_vistas(id) on delete cascade,
    usuario_id uuid not null, operacion_id uuid not null,
    revision_base bigint not null, permisos_requeridos jsonb not null, solicitud_sha text not null check(solicitud_sha ~ '^[0-9a-f]{64}$'),
    estado text not null check(estado in ('aplicada','conflicto')), revision bigint not null,
    creado_en timestamptz not null default clock_timestamp(),
    primary key(usuario_id,operacion_id)
);
alter table myg_nube_privado.base_vistas enable row level security;
alter table myg_nube_privado.base_vista_miembros enable row level security;
alter table myg_nube_privado.base_vista_operaciones enable row level security;
revoke all on myg_nube_privado.base_vistas,myg_nube_privado.base_vista_miembros,
    myg_nube_privado.base_vista_operaciones from public,anon,authenticated,service_role;

create or replace function myg_nube_privado.base_permisos_validos(p jsonb)
returns boolean language sql immutable set search_path=pg_catalog as $fn$
    select coalesce(jsonb_typeof(p)='object'
        and p ?& array['acu','especificaciones','metrados_excel','metrados_revit']
        and p-array['acu','especificaciones','metrados_excel','metrados_revit']='{}'::jsonb
        and jsonb_typeof(p->'acu')='boolean' and jsonb_typeof(p->'especificaciones')='boolean'
        and jsonb_typeof(p->'metrados_excel')='boolean' and jsonb_typeof(p->'metrados_revit')='boolean',false);
$fn$;

create or replace function myg_nube_privado.base_vista_rol(p_id uuid,p_actor uuid)
returns text language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare b uuid; dueno uuid; r text;
begin
    if not exists(select 1 from myg_nube_privado.identidades_verificadas
        where auth_usuario_id=p_actor and activo) then return null; end if;
    select v.base_id,p.propietario into b,dueno
    from myg_nube_privado.base_vistas v join public.myg_nube_proyectos p on p.id=v.base_id
    where v.id=p_id and p.alcance='base';
    if not found then return null; end if;
    if p_actor=dueno then r:='propietario';
    else
        select rol into r from myg_nube_privado.base_vista_miembros
        where vista_id=p_id and usuario_id=p_actor and rol<>'propietario';
    end if;
    if r is null then return null; end if;
    -- Autorizar antes de consultar el borrado. Una base ajena pendiente no
    -- puede impedir el listado de las vistas autorizadas de otra cuenta.
    if to_regprocedure('myg_nube_privado.eliminacion_exigir_activo(uuid)') is not null then
        begin
            perform myg_nube_privado.eliminacion_exigir_activo(b);
        exception when sqlstate '55000' or sqlstate '55006' then return null;
        end;
    end if;
    return r;
end $fn$;

create or replace function myg_nube_privado.base_vista_meta(p_id uuid,p_actor uuid,p_revision bigint default null)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare r text:=myg_nube_privado.base_vista_rol(p_id,p_actor); j jsonb;
begin
    if r is null then return null; end if;
    select jsonb_build_object('id',v.id,'codigo','VISTA-'||replace(v.id::text,'-',''),
        'nombre',v.nombre,'rol',r,'revision',coalesce(p_revision,p.revision),'alcance','obra',
        'base_id',v.base_id,'documento_id',v.documento_id,'vista_base',true,'actualizado_en',p.actualizado_en,
        'permisos_modulos',case when r='propietario' then
            '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}'::jsonb
            else m.permisos_modulos end) into j
    from myg_nube_privado.base_vistas v join public.myg_nube_proyectos p on p.id=v.base_id
    left join myg_nube_privado.base_vista_miembros m on m.vista_id=v.id and m.usuario_id=p_actor
    where v.id=p_id;
    return j;
end $fn$;

-- Todas las mutaciones de miembros bloquean la MISMA fila de la base que las
-- confirmaciones del backend: una revocación gana antes o después de un guardado.
create or replace function myg_nube_privado.base_vista_administrar(p_id uuid,p_actor uuid,p_usuario uuid,p_rol text)
returns void language plpgsql security definer set search_path=pg_catalog as $fn$
declare b uuid; r text; anterior text; dueno uuid;
begin
    select base_id into b from myg_nube_privado.base_vistas where id=p_id;
    select propietario into dueno from public.myg_nube_proyectos where id=b for update;
    r:=myg_nube_privado.base_vista_rol(p_id,p_actor);
    if r is null or r not in ('propietario','administrador') then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    if p_usuario is null or p_usuario='00000000-0000-0000-0000-000000000000'::uuid
       or (p_rol is not null and p_rol not in ('administrador','editor','lector')) then
        raise exception using errcode='22023',message='MYG_ROL_INVALIDO';
    end if;
    select rol into anterior from myg_nube_privado.base_vista_miembros where vista_id=p_id and usuario_id=p_usuario;
    if p_usuario=dueno or anterior='propietario'
       or (r='administrador' and (anterior='administrador' or p_rol='administrador')) then
        raise exception using errcode='42501',message='MYG_JERARQUIA_PROTEGIDA';
    end if;
end $fn$;

create or replace function public.myg_base_registrar(p_base uuid,p_documento text,p_nombre text)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); v uuid; dueno uuid;
begin
    select p.propietario into dueno from public.myg_nube_proyectos p
    join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
    where p.id=p_base and p.alcance='base' for update of p;
    if dueno is distinct from u then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    if to_regprocedure('myg_nube_privado.eliminacion_exigir_activo(uuid)') is not null then
        perform myg_nube_privado.eliminacion_exigir_activo(p_base);
    end if;
    if p_documento is null or length(p_documento) not between 1 and 200
       or p_documento<>btrim(p_documento) or p_documento ~ '[[:cntrl:]]'
       or p_nombre is null or length(btrim(p_nombre)) not between 1 and 2000 or p_nombre ~ '[[:cntrl:]]' then
        raise exception using errcode='22023',message='MYG_OBRA_INVALIDA';
    end if;
    insert into myg_nube_privado.base_vistas(base_id,documento_id,nombre)
        values(p_base,p_documento,btrim(p_nombre))
        on conflict(base_id,documento_id) do update set nombre=excluded.nombre returning id into v;
    insert into myg_nube_privado.base_vista_miembros(vista_id,usuario_id,rol,permisos_modulos)
        values(v,u,'propietario','{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}')
        on conflict(vista_id,usuario_id) do nothing;
    return myg_nube_privado.base_vista_meta(v,u);
end $fn$;

create or replace function public.myg_base_listar()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); j jsonb;
begin
    select coalesce(jsonb_agg(m order by m->>'nombre',m->>'id'),'[]'::jsonb) into j
    from (select myg_nube_privado.base_vista_meta(id,u) m from myg_nube_privado.base_vistas) s where m is not null;
    return j;
end $fn$;

create or replace function public.myg_base_resolver(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin return myg_nube_privado.base_vista_meta(p_id,myg_nube_privado.identidad()); end $fn$;

create or replace function public.myg_base_miembros(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); r text; j jsonb; dueno uuid;
begin
    r:=myg_nube_privado.base_vista_rol(p_id,u);
    if r is null then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    select p.propietario into dueno from myg_nube_privado.base_vistas v join public.myg_nube_proyectos p on p.id=v.base_id where v.id=p_id;
    select coalesce(jsonb_agg(jsonb_build_object('usuario_id',m.usuario_id,'rol',m.rol,
        'usuario_myg',lower(btrim(i.usuario_myg)),'permisos_modulos',m.permisos_modulos) order by m.usuario_id),'[]'::jsonb) into j
    from myg_nube_privado.base_vista_miembros m left join myg_nube_privado.identidades_verificadas i
        on i.auth_usuario_id=m.usuario_id and i.activo
    where m.vista_id=p_id and (m.rol<>'propietario' or m.usuario_id=dueno);
    return j;
end $fn$;

create or replace function public.myg_base_solicitudes(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if myg_nube_privado.base_vista_rol(p_id,myg_nube_privado.identidad()) is null then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    return '[]'::jsonb;
end $fn$;

create or replace function public.myg_base_compartir_usuario(p_id uuid,p_usuario_myg text,p_rol text,p_permisos_modulos jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); destino uuid; numero integer; b uuid; r text;
begin
    select base_id into b from myg_nube_privado.base_vistas where id=p_id;
    perform 1 from public.myg_nube_proyectos where id=b for update;
    r:=myg_nube_privado.base_vista_rol(p_id,u);
    if r is null or r not in ('propietario','administrador') then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    if p_usuario_myg is null or length(btrim(p_usuario_myg)) not between 1 and 256 or p_usuario_myg ~ '[[:cntrl:]]'
       or p_rol is null or p_rol not in ('administrador','editor','lector')
       or not myg_nube_privado.base_permisos_validos(p_permisos_modulos) then
        raise exception using errcode='22023',message='MYG_COLABORADOR_INVALIDO';
    end if;
    select count(*),min(auth_usuario_id::text)::uuid into numero,destino from myg_nube_privado.identidades_verificadas
    where activo and lower(btrim(usuario_myg))=lower(btrim(p_usuario_myg));
    if numero<>1 then raise exception using errcode='22023',message='MYG_DESTINATARIO_NO_VERIFICADO'; end if;
    perform myg_nube_privado.base_vista_administrar(p_id,u,destino,p_rol);
    insert into myg_nube_privado.base_vista_miembros(vista_id,usuario_id,rol,permisos_modulos)
        values(p_id,destino,p_rol,p_permisos_modulos)
        on conflict(vista_id,usuario_id) do update set rol=excluded.rol,permisos_modulos=excluded.permisos_modulos;
    return '{"estado":"actualizada"}'::jsonb;
end $fn$;

create or replace function public.myg_base_rol(p_id uuid,p_usuario uuid,p_rol text)
returns boolean language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad();
begin
    perform myg_nube_privado.base_vista_administrar(p_id,u,p_usuario,p_rol);
    if not exists(select 1 from myg_nube_privado.base_vista_miembros where vista_id=p_id and usuario_id=p_usuario) then
        raise exception using errcode='22023',message='MYG_MIEMBRO_NO_EXISTE';
    end if;
    if p_rol is null then delete from myg_nube_privado.base_vista_miembros where vista_id=p_id and usuario_id=p_usuario;
    else update myg_nube_privado.base_vista_miembros set rol=p_rol where vista_id=p_id and usuario_id=p_usuario; end if;
    return true;
end $fn$;

create or replace function public.myg_base_permisos(p_id uuid,p_usuario uuid,p_permisos_modulos jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); r text;
begin
    -- Bloquear y autorizar antes de inspeccionar el rol del destino.
    perform myg_nube_privado.base_vista_administrar(p_id,u,p_usuario,'editor');
    select rol into r from myg_nube_privado.base_vista_miembros where vista_id=p_id and usuario_id=p_usuario;
    if r is null or not myg_nube_privado.base_permisos_validos(p_permisos_modulos) then
        raise exception using errcode='22023',message='MYG_PERMISOS_INVALIDOS';
    end if;
    perform myg_nube_privado.base_vista_administrar(p_id,u,p_usuario,r);
    update myg_nube_privado.base_vista_miembros set permisos_modulos=p_permisos_modulos where vista_id=p_id and usuario_id=p_usuario;
    return '{"estado":"actualizada"}'::jsonb;
end $fn$;

-- Solo el backend posee la clave service_role. Los clientes no reciben esta
-- respuesta porque contiene la ubicación del archivo de TODAS las obras.
create or replace function public.myg_base_contexto_servidor(p_id uuid,p_actor uuid,p_revision bigint default null)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare meta jsonb; b uuid; actual bigint; rev bigint; archivo jsonb; dueno uuid;
begin
    meta:=myg_nube_privado.base_vista_meta(p_id,p_actor);
    if meta is null then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    b:=(meta->>'base_id')::uuid; actual:=(meta->>'revision')::bigint;
    rev:=coalesce(p_revision,actual);
    if rev<1 or rev>actual then raise exception using errcode='22023',message='MYG_REVISION_INVALIDA'; end if;
    select jsonb_build_object('ruta',ruta,'sha256',sha256,'bytes',bytes) into archivo
    from myg_nube_privado.sqlite_revisiones where proyecto_id=b and revision=rev;
    if archivo is null then raise exception using errcode='22023',message='MYG_REVISION_NO_DISPONIBLE'; end if;
    select propietario into dueno from public.myg_nube_proyectos where id=b;
    return jsonb_build_object('proyecto',jsonb_set(meta,'{revision}',to_jsonb(rev)),
        'base_id',b,'documento_id',meta->>'documento_id','propietario',dueno,'archivo_sqlite',archivo,
        'revision',rev,'rol',meta->>'rol','permisos_modulos',meta->'permisos_modulos');
end $fn$;

create or replace function public.myg_base_confirmar_servidor(p_id uuid,p_actor uuid,p_operacion uuid,
    p_revision bigint,p_ruta text,p_sha256 text,p_bytes bigint,p_anterior jsonb,p_nuevo jsonb,p_solicitud_sha text)
returns jsonb language plpgsql security definer set search_path=pg_catalog set statement_timeout='30s' as $fn$
declare b uuid; actual bigint; meta jsonb; previa myg_nube_privado.base_vista_operaciones%rowtype;
    estado text; rev bigint;
begin
    if p_operacion is null or p_operacion='00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision<1 or p_revision=9223372036854775807
       or p_solicitud_sha is null or p_solicitud_sha !~ '^[0-9a-f]{64}$' then
        raise exception using errcode='22023',message='MYG_OPERACION_INVALIDA';
    end if;
    select base_id into b from myg_nube_privado.base_vistas where id=p_id;
    begin
        select revision into actual from public.myg_nube_proyectos where id=b for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;
    meta:=myg_nube_privado.base_vista_meta(p_id,p_actor);
    if actual is null or meta is null or meta->>'rol' not in ('propietario','administrador','editor')
       or not myg_nube_privado.base_permisos_validos(meta->'permisos_modulos') then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-op:'||p_actor::text||':'||p_operacion::text,0)) then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end if;
    select * into previa from myg_nube_privado.base_vista_operaciones where usuario_id=p_actor and operacion_id=p_operacion;
    if found then
        if previa.vista_id<>p_id or previa.revision_base<>p_revision or previa.solicitud_sha<>p_solicitud_sha then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        -- Un replay no elude una revocación posterior. Se guarda solo la
        -- máscara observada, sin copiar los paquetes de la obra.
        if not (meta->'permisos_modulos' @> (select coalesce(jsonb_object_agg(key,value),'{}'::jsonb)
            from jsonb_each(previa.permisos_requeridos) where value='true'::jsonb)) then
            raise exception using errcode='42501',message='MYG_PERMISO_REVOCADO';
        end if;
        return jsonb_build_object('estado',previa.estado,'revision',previa.revision,'operacion_id',p_operacion);
    end if;
    if exists(select 1 from public.myg_nube_operaciones where usuario_id=p_actor and operacion_id=p_operacion)
       or exists(select 1 from myg_nube_privado.sqlite_operaciones where usuario_id=p_actor and operacion_id=p_operacion) then
        raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
    end if;
    rev:=actual;
    if actual<>p_revision then estado:='conflicto';
    else
        perform myg_nube_privado.sqlite_validar_datos(b,p_ruta,p_sha256,p_bytes,p_actor);
        if p_anterior is null or p_nuevo is null or jsonb_typeof(p_anterior)<>'object' or jsonb_typeof(p_nuevo)<>'object' then
            raise exception using errcode='22023',message='MYG_PAQUETE_INVALIDO';
        end if;
        perform myg_nube_privado.exigir_modulos(p_anterior,p_nuevo,meta->'permisos_modulos');
        perform myg_nube_privado.sqlite_validar_objeto(b,p_ruta,p_sha256,p_bytes,p_actor);
        estado:='aplicada'; rev:=actual+1;
        insert into myg_nube_privado.sqlite_revisiones(proyecto_id,revision,usuario_id,ruta,sha256,bytes)
            values(b,rev,p_actor,p_ruta,p_sha256,p_bytes);
        update public.myg_nube_proyectos set revision=rev,actualizado_en=clock_timestamp() where id=b;
    end if;
    insert into myg_nube_privado.base_vista_operaciones(vista_id,usuario_id,operacion_id,revision_base,permisos_requeridos,solicitud_sha,estado,revision)
        values(p_id,p_actor,p_operacion,p_revision,meta->'permisos_modulos',p_solicitud_sha,estado,rev);
    -- Reserva global del UUID, solo huellas y metadatos; no se almacena la obra.
    insert into public.myg_nube_operaciones(usuario_id,operacion_id,proyecto_id,solicitud,respuesta)
        values(p_actor,p_operacion,b,jsonb_build_object('formato','MYG_VISTA_BASE','vista',p_id,'sha256',p_solicitud_sha),
            jsonb_build_object('estado',estado,'revision',rev,'operacion_id',p_operacion));
    return jsonb_build_object('estado',estado,'revision',rev,'operacion_id',p_operacion);
end $fn$;

revoke all on function myg_nube_privado.base_permisos_validos(jsonb),
    myg_nube_privado.base_vista_rol(uuid,uuid),myg_nube_privado.base_vista_meta(uuid,uuid,bigint),
    myg_nube_privado.base_vista_administrar(uuid,uuid,uuid,text) from public,anon,authenticated,service_role;
revoke all on function public.myg_base_registrar(uuid,text,text),public.myg_base_listar(),public.myg_base_resolver(uuid),
    public.myg_base_miembros(uuid),public.myg_base_solicitudes(uuid),public.myg_base_compartir_usuario(uuid,text,text,jsonb),
    public.myg_base_rol(uuid,uuid,text),public.myg_base_permisos(uuid,uuid,jsonb) from public,anon;
grant execute on function public.myg_base_registrar(uuid,text,text),public.myg_base_listar(),public.myg_base_resolver(uuid),
    public.myg_base_miembros(uuid),public.myg_base_solicitudes(uuid),public.myg_base_compartir_usuario(uuid,text,text,jsonb),
    public.myg_base_rol(uuid,uuid,text),public.myg_base_permisos(uuid,uuid,jsonb) to authenticated,service_role;
revoke all on function public.myg_base_contexto_servidor(uuid,uuid,bigint),
    public.myg_base_confirmar_servidor(uuid,uuid,uuid,bigint,text,text,bigint,jsonb,jsonb,text) from public,anon,authenticated;
grant execute on function public.myg_base_contexto_servidor(uuid,uuid,bigint),
    public.myg_base_confirmar_servidor(uuid,uuid,uuid,bigint,text,text,bigint,jsonb,jsonb,text) to service_role;

-- Integrar únicamente las relaciones oficiales de BIM y vistas con el borrado
-- existente. Se conserva el rechazo de cualquier dependencia personalizada.
do $borrado$
declare d text; cambiado text; firma text; tabla text; tr record;
begin
    if to_regprocedure('myg_nube_privado.eliminacion_exigir_esquema()') is null then return; end if;
    d:=pg_get_functiondef('myg_nube_privado.eliminacion_exigir_esquema()'::regprocedure);
    if position('myg_nube_privado.base_vista_operaciones' in d)=0 then
        cambiado:=replace(d,'''myg_nube_privado.historial_cambios'']) n;',
            '''myg_nube_privado.historial_cambios'',''myg_nube_privado.bim_documentos'',''myg_nube_privado.bim_operaciones'',
            ''myg_nube_privado.base_vistas'',''myg_nube_privado.base_vista_miembros'',''myg_nube_privado.base_vista_operaciones'']) n;');
        cambiado:=replace(cambiado,
            'and v_fk.columnas=array[''proyecto_id'']::text[])',
            'and v_fk.columnas=array[''proyecto_id'']::text[])'
            ||' or (v_fk.referencia=''public.myg_nube_proyectos'' and v_fk.referidas=array[''id'']::text[]'
            ||' and v_fk.relacion=''myg_nube_privado.bim_documentos'' and v_fk.columnas=array[''proyecto_id'']::text[] and v_fk.confdeltype=''c'')'
            ||' or (v_fk.referencia=''myg_nube_privado.sqlite_proyectos'' and v_fk.referidas=array[''proyecto_id'']::text[]'
            ||' and v_fk.relacion=''myg_nube_privado.base_vistas'' and v_fk.columnas=array[''base_id'']::text[] and v_fk.confdeltype=''c'')'
            ||' or (v_fk.referencia=''myg_nube_privado.base_vistas'' and v_fk.referidas=array[''id'']::text[]'
            ||' and v_fk.relacion in (''myg_nube_privado.base_vista_miembros'',''myg_nube_privado.base_vista_operaciones'')'
            ||' and v_fk.columnas=array[''vista_id'']::text[] and v_fk.confdeltype=''c'')');
        cambiado:=replace(cambiado,'''myg_nube_privado.historial_cambios''] loop',
            '''myg_nube_privado.historial_cambios'',''myg_nube_privado.bim_documentos'',''myg_nube_privado.bim_operaciones''] loop');
        if cambiado=d or position('myg_nube_privado.base_vista_operaciones' in cambiado)=0
           or position('v_fk.referencia=''myg_nube_privado.base_vistas''' in cambiado)=0
           or position('v_fk.relacion=''myg_nube_privado.bim_documentos''' in cambiado)=0 then
            raise exception 'El comprobador de borrado contiene una personalización desconocida; no se modificó la instalación.';
        end if;
        execute cambiado;
    end if;
    -- Las operaciones BIM anteriores no tienen FK; se limpian exclusivamente
    -- dentro del borrado autorizado y usando su columna proyecto_id conocida.
    firma:='public.myg_nube_base_eliminacion_finalizar(uuid)';
    if to_regprocedure(firma) is null then raise exception 'Falta el finalizador oficial de borrado.'; end if;
    d:=pg_get_functiondef(to_regprocedure(firma));
    if position('myg_nube_privado.bim_operaciones' in d)=0 then
        cambiado:=replace(d,'''myg_nube_privado.historial_cambios'',''public.myg_nube_operaciones''',
            '''myg_nube_privado.historial_cambios'',''myg_nube_privado.bim_documentos'',''myg_nube_privado.bim_operaciones'',''public.myg_nube_operaciones''');
        if cambiado=d then raise exception 'El finalizador de borrado contiene una personalización desconocida; se conserva intacto.'; end if;
        execute cambiado;
    end if;
    -- Congelar las dos tablas BIM durante el mismo job, como las tablas SQLite.
    foreach tabla in array array['myg_nube_privado.bim_documentos','myg_nube_privado.bim_operaciones'] loop
        select * into tr from pg_trigger where tgrelid=to_regclass(tabla) and tgname='myg_eliminacion_congelar';
        if found then
            if tr.tgfoid<>'myg_nube_privado.eliminacion_guardar_mutacion()'::regprocedure or tr.tgtype<>23
               or tr.tgenabled<>'O' or tr.tgqual is not null or tr.tgattr<>''::int2vector then
                raise exception 'La guarda de borrado de % es personalizada; se conserva intacta.',tabla;
            end if;
        else
            execute format('create trigger myg_eliminacion_congelar before insert or update on %s for each row execute function myg_nube_privado.eliminacion_guardar_mutacion()',tabla);
        end if;
    end loop;
end $borrado$;
notify pgrst,'reload schema';
commit;
