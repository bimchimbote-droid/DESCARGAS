-- SOLO PostgreSQL desechable. No ejecutar en Supabase real.
\set ON_ERROR_STOP on
\ir modeladores_bim.sql
reset role;
-- Configuración productiva de bases privadas/borrado: los miembros del fixture
-- antiguo se retiran solo en esta base desechable antes de instalar sus guards.
delete from public.myg_nube_miembros m using public.myg_nube_proyectos p
where m.proyecto_id=p.id and p.id='d9000000-0000-0000-0000-000000000001' and m.usuario_id<>p.propietario;
\ir ../migraciones/20261101_bases_obras.sql
\ir ../migraciones/20261103_eliminar_bases_storage.sql
grant usage on schema qa to service_role;
create table qa.base_vista_antes as select
    (select count(*) from public.myg_nube_proyectos) proyectos,
    (select count(*) from storage.objects) objetos,
    (select count(*) from myg_nube_privado.sqlite_revisiones) revisiones;
\ir ../migraciones/20261105_colaboracion_misma_base.sql
\ir ../migraciones/20261105_colaboracion_misma_base.sql
select qa.exige(not has_table_privilege('authenticated','myg_nube_privado.base_vistas','select')
    and not has_table_privilege('service_role','myg_nube_privado.base_vista_miembros','update')
    and not has_function_privilege('anon','public.myg_base_listar()','execute')
    and not has_function_privilege('authenticated','public.myg_base_contexto_servidor(uuid,uuid,bigint)','execute')
    and not has_function_privilege('authenticated','public.myg_base_confirmar_servidor(uuid,uuid,uuid,bigint,text,text,bigint,jsonb,jsonb,text)','execute')
    and has_function_privilege('service_role','public.myg_base_contexto_servidor(uuid,uuid,bigint)','execute'),
    'Misma base: tablas privadas y contexto/confirmación exclusivos del backend');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
create temporary table vistas_qa as select
    public.myg_base_registrar('d9000000-0000-0000-0000-000000000001','DOC-OBRA-A','Obra autorizada') a,
    public.myg_base_registrar('d9000000-0000-0000-0000-000000000001','DOC-OBRA-B','Obra privada') b;
select qa.exige((a->>'vista_base')::boolean and a->>'alcance'='obra'
    and a->>'base_id'='d9000000-0000-0000-0000-000000000001'
    and a->>'id'<>a->>'base_id' and a->>'documento_id'='DOC-OBRA-A'
    and not a ?| array['contenido','archivo_sqlite','ruta'],
    'Misma base: referencia virtual sin contenido ni ubicación del SQLite') from vistas_qa;
select qa.exige(public.myg_base_registrar('d9000000-0000-0000-0000-000000000001','DOC-OBRA-A','Obra autorizada')->>'id'=a->>'id',
    'Misma base: registrar dos veces conserva identidad sin duplicar permisos') from vistas_qa;
select qa.rechaza($$select public.myg_base_compartir_usuario((a->>'id')::uuid,'ajeno','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}') from vistas_qa$$,
    '22023','Misma base: usuarios MYG normalizados ambiguos se rechazan');
reset role;
-- El fixture anterior dejó deliberadamente una cuenta ambigua. Esta suite
-- usa una identidad de destino única a partir de aquí.
update myg_nube_privado.identidades_verificadas set activo=false where auth_usuario_id='00000000-0000-0000-0000-000000000010';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_base_compartir_usuario((a->>'id')::uuid,'aJeNo','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}') from vistas_qa;
select public.myg_base_compartir_usuario((a->>'id')::uuid,'administrador','administrador',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}') from vistas_qa;
select public.myg_base_compartir_usuario((a->>'id')::uuid,'lector','lector',
    '{"acu":false,"especificaciones":false,"metrados_excel":false,"metrados_revit":false}') from vistas_qa;
select public.myg_base_compartir_usuario((a->>'id')::uuid,'admin2','administrador',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}') from vistas_qa;
select qa.rechaza($$select public.myg_base_compartir_usuario((a->>'id')::uuid,'editor','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true}') from vistas_qa$$,'22023',
    'Misma base: permiso Revit no se inventa por omisión');
select qa.rechaza($$select public.myg_base_compartir_usuario((a->>'id')::uuid,'inactivo','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}') from vistas_qa$$,'22023',
    'Misma base: usuario MYG debe tener identidad activa');
select qa.rechaza($$select public.myg_base_permisos((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":"true"}') from vistas_qa$$,'22023',
    'Misma base: bandera no booleana rechazada');
reset role;
grant select on vistas_qa to authenticated,service_role;
create table qa.vistas_reinstalacion as select
    (select jsonb_agg(to_jsonb(v) order by id) from myg_nube_privado.base_vistas v) vistas,
    (select jsonb_agg(to_jsonb(m) order by vista_id,usuario_id) from myg_nube_privado.base_vista_miembros m) miembros,
    (select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from myg_nube_privado.base_vista_operaciones o) operaciones;
\ir ../migraciones/20261105_colaboracion_misma_base.sql
select qa.exige((select vistas is not distinct from
        (select jsonb_agg(to_jsonb(v) order by id) from myg_nube_privado.base_vistas v)
    and miembros is not distinct from
        (select jsonb_agg(to_jsonb(m) order by vista_id,usuario_id) from myg_nube_privado.base_vista_miembros m)
    and operaciones is not distinct from
        (select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from myg_nube_privado.base_vista_operaciones o)
    from qa.vistas_reinstalacion),
    'Misma base: reinstalar después de compartir conserva identidades, roles y permisos exactos');
select qa.exige((select proyectos from qa.base_vista_antes)=(select count(*) from public.myg_nube_proyectos)
    and (select objetos from qa.base_vista_antes)=(select count(*) from storage.objects)
    and (select revisiones from qa.base_vista_antes)=(select count(*) from myg_nube_privado.sqlite_revisiones),
    'Misma base: registrar y compartir no publica otra obra, no sube objetos y no crea revisiones');
select qa.exige(not exists(select 1 from public.myg_nube_miembros
    where proyecto_id='d9000000-0000-0000-0000-000000000001' and usuario_id='00000000-0000-0000-0000-000000000002'),
    'Misma base: el administrador de obra nunca recibe membresía del binario de base');
-- El usuario ajeno ya participaba en fixtures BIM, por lo que se elimina solo
-- ese acceso anterior directo para probar el caso de usuario exclusivo de vista.
delete from public.myg_nube_miembros where proyecto_id='d9000000-0000-0000-0000-000000000001'
    and usuario_id='00000000-0000-0000-0000-000000000007';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige(jsonb_array_length(public.myg_base_listar())=1
    and public.myg_base_listar()->0->>'documento_id'='DOC-OBRA-A'
    and public.myg_base_resolver((select (b->>'id')::uuid from vistas_qa)) is null,
    'Misma base: colaborador solo lista y resuelve su obra autorizada');
select qa.exige(public.myg_base_resolver('d9000000-0000-0000-0000-000000000001') is null,
    'Misma base: UUID de respaldo no se confunde con vista');
select qa.rechaza($$select public.myg_base_registrar('d9000000-0000-0000-0000-000000000001','DOC-OBRA-C','No permitido')$$,
    '42501','Misma base: un colaborador no enumera ni registra obras de la base');
select qa.rechaza($$select public.myg_base_compartir_usuario((a->>'id')::uuid,'editor','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}') from vistas_qa$$,
    '42501','Misma base: editor no concede acceso');
select qa.exige(not myg_nube_privado.sqlite_objeto_acceso(
    (select ruta from qa.sqlite_casos where nombre='inicial'),false),
    'Misma base: miembro de vista no puede descargar snapshot completo por Storage');
select qa.rechaza($$select public.myg_base_contexto_servidor((a->>'id')::uuid,
    '00000000-0000-0000-0000-000000000007',null) from vistas_qa$$,'42501',
    'Misma base: usuario no puede invocar RPC servidor aunque conozca sus UUID');
select qa.rechaza($$select public.myg_base_miembros((b->>'id')::uuid) from vistas_qa$$,'42501',
    'Misma base: miembros de obra privada no se enumeran');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000002';
select qa.rechaza($$select public.myg_base_rol((a->>'id')::uuid,'00000000-0000-0000-0000-000000000001','editor') from vistas_qa$$,
    '42501','Misma base: administrador no modifica al propietario');
select qa.rechaza($$select public.myg_base_rol((a->>'id')::uuid,'00000000-0000-0000-0000-000000000008','editor') from vistas_qa$$,
    '42501','Misma base: administrador no modifica otro administrador');
select qa.rechaza($$select public.myg_base_rol((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007','administrador') from vistas_qa$$,
    '42501','Misma base: administrador no eleva un editor');
select qa.exige(public.myg_base_rol((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007','lector'),
    'Misma base: administrador sí puede reducir editor a lector') from vistas_qa;
select qa.exige(public.myg_base_rol((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007','editor'),
    'Misma base: administrador puede restaurar editor sin elevarlo') from vistas_qa;
reset role;
-- Los RPC servidor no dependen del GUC editable de usuario: reciben actor solo
-- desde backend, cuya clave no se entrega a clientes.
set role service_role;
set request.jwt.claim.sub=''; -- La clave del servidor no es una sesión de usuario.
select qa.exige(current_setting('request.jwt.claim.sub',true)='',
    'Misma base: el backend opera sin suplantar un JWT de usuario en PostgreSQL');
select qa.exige(public.myg_base_contexto_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007')->>'documento_id'='DOC-OBRA-A'
    and public.myg_base_contexto_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007')->'proyecto'->>'vista_base'='true',
    'Misma base: contexto solo servidor contiene vista y ubicación del snapshot') from vistas_qa;
select qa.rechaza($$select public.myg_base_contexto_servidor((b->>'id')::uuid,'00000000-0000-0000-0000-000000000007') from vistas_qa$$,
    '42501','Misma base: backend también comprueba permiso para cada obra');
select qa.rechaza($$select public.myg_base_confirmar_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000004',
    'c0100000-0000-0000-0000-000000000001',3,'x',repeat('e',64),4096,'{}','{}',repeat('1',64)) from vistas_qa$$,
    '42501','Misma base: backend no confirma escritura de un lector');
reset role;
create table qa.vista_estado as select revision from public.myg_nube_proyectos where id='d9000000-0000-0000-0000-000000000001';
grant select on qa.vista_estado,qa.paquetes to service_role;
insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000007/d9000000000000000000000000000001/'||repeat('e',64)||'.sqlite','{"size":4096}');
set role service_role;
set request.jwt.claim.sub=''; -- La clave del servidor no es una sesión de usuario.
select qa.exige((select public.myg_base_confirmar_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    'c0100000-0000-0000-0000-000000000002',(select revision from qa.vista_estado),
    '00000000-0000-0000-0000-000000000007/d9000000000000000000000000000001/'||repeat('e',64)||'.sqlite',repeat('e',64),4096,
    contenido,contenido,repeat('2',64))->>'estado'='aplicada' from vistas_qa,qa.paquetes where nombre='baseline'),
    'Misma base: guardado autorizado avanza revisión de la MISMA base');
select qa.exige((select public.myg_base_confirmar_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    'c0100000-0000-0000-0000-000000000002',(select revision from qa.vista_estado),
    'ruta-no-usada-en-replay',repeat('f',64),999,contenido,contenido,repeat('2',64))->>'revision'=((select revision from qa.vista_estado)+1)::text
    from vistas_qa,qa.paquetes where nombre='baseline'),
    'Misma base: ACK perdido recupera respuesta original sin otra revisión ni subida');
select qa.rechaza($$select public.myg_base_confirmar_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    'c0100000-0000-0000-0000-000000000002',(select revision from qa.vista_estado),'x',repeat('e',64),4096,'{}','{}',repeat('3',64)) from vistas_qa$$,
    '22023','Misma base: UUID no admite otro contenido/fingerprint');
select qa.exige((select public.myg_base_confirmar_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    'c0100000-0000-0000-0000-000000000003',(select revision from qa.vista_estado),'sin-subida',repeat('e',64),4096,
    contenido,contenido,repeat('3',64))->>'estado'='conflicto' from vistas_qa,qa.paquetes where nombre='baseline'),
    'Misma base: CAS antiguo devuelve conflicto antes de validar ruta y sin publicar snapshot');
select qa.exige((public.myg_base_contexto_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    (select revision from qa.vista_estado))->>'revision')::bigint=(select revision from qa.vista_estado),
    'Misma base: snapshot histórico usa autorización actual y revisión solicitada') from vistas_qa;
reset role;
select qa.exige((select count(*) from public.myg_nube_proyectos)=(select proyectos from qa.base_vista_antes)
    and (select revision from public.myg_nube_proyectos where id='d9000000-0000-0000-0000-000000000001')=(select revision+1 from qa.vista_estado),
    'Misma base: no existe proyecto nuevo al guardar; ambas vistas observan revisión compartida');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_base_permisos((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":false}') from vistas_qa;
reset role;
set role service_role;
set request.jwt.claim.sub=''; -- La clave del servidor no es una sesión de usuario.
select qa.rechaza($$select public.myg_base_confirmar_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    'c0100000-0000-0000-0000-000000000002',(select revision from qa.vista_estado),'x',repeat('e',64),4096,'{}','{}',repeat('2',64)) from vistas_qa$$,
    '42501','Misma base: replay no evita revocación de permiso posterior');
reset role;
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_base_rol((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',null) from vistas_qa;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige(public.myg_base_listar()='[]'::jsonb and public.myg_base_resolver((select (a->>'id')::uuid from vistas_qa)) is null,
    'Misma base: retirar miembro retira listado y resolución');
reset role;
set role service_role;
set request.jwt.claim.sub=''; -- La clave del servidor no es una sesión de usuario.
select qa.rechaza($$select public.myg_base_contexto_servidor((a->>'id')::uuid,'00000000-0000-0000-0000-000000000007',
    (select revision from qa.vista_estado)) from vistas_qa$$,'42501',
    'Misma base: revocación también impide descargar revisión histórica');
reset role;
-- El borrado existente reconoce exclusivamente las nuevas relaciones conocidas.
select myg_nube_privado.eliminacion_exigir_esquema();
select qa.exige(true,'Misma base: extensión de permisos conserva borrado seguro de bases');
create table qa.fk_personalizada(vista uuid references myg_nube_privado.base_vistas(id));
select qa.rechaza($$select myg_nube_privado.eliminacion_exigir_esquema()$$,'55000',
    'Misma base: comprobador sigue rechazando dependencias ajenas');
drop table qa.fk_personalizada;
alter table myg_nube_privado.base_vista_miembros add constraint qa_fk_entre_tablas_conocidas
    foreign key(usuario_id) references myg_nube_privado.base_vistas(id) not valid;
select qa.rechaza($$select myg_nube_privado.eliminacion_exigir_esquema()$$,'55000',
    'Misma base: una FK personalizada entre tablas conocidas sigue rechazada');
alter table myg_nube_privado.base_vista_miembros drop constraint qa_fk_entre_tablas_conocidas;
-- Otra cuenta mantiene una vista autorizada mientras la base original se borra.
insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000002/d9100000000000000000000000000001/'||repeat('9',64)||'.sqlite','{"size":4096}');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000002';
select public.myg_nube_sqlite_crear('d9100000-0000-0000-0000-000000000001','Otra base QA','base','DOC-OTRA',
    '00000000-0000-0000-0000-000000000002/d9100000000000000000000000000001/'||repeat('9',64)||'.sqlite',repeat('9',64),4096);
create temporary table otra_vista_qa as select public.myg_base_registrar(
    'd9100000-0000-0000-0000-000000000001','DOC-OTRA','Otra obra autorizada') meta;
grant select on otra_vista_qa to authenticated,service_role;
reset role;
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',
    'c0100000-0000-0000-0000-000000000099');
select qa.rechaza($$select public.myg_base_registrar('d9000000-0000-0000-0000-000000000001','DOC-C','C')$$,
    '55006','Misma base: base en proceso de borrado no acepta nuevos permisos');
select qa.exige(public.myg_base_listar()='[]'::jsonb,
    'Misma base: propietario no lista vistas mientras su base se elimina');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000002';
select qa.exige(jsonb_array_length(public.myg_base_listar())=1
    and public.myg_base_listar()->0->>'base_id'='d9100000-0000-0000-0000-000000000001',
    'Misma base: un borrado ajeno no bloquea el listado de otra base autorizada');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige(public.myg_base_listar()='[]'::jsonb,
    'Misma base: cuenta sin membresía no recibe errores de una base ajena en borrado');
reset role;
select qa.rechaza($$insert into myg_nube_privado.bim_operaciones(usuario_id,operacion_id,proyecto_id,solicitud,respuesta)
    values('00000000-0000-0000-0000-000000000001',gen_random_uuid(),
    'd9000000-0000-0000-0000-000000000001','{}','{}')$$,'55006',
    'Misma base: el borrado congela también las operaciones BIM');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
-- Solo el fixture simula la API Storage mediante su tabla de metadatos.
delete from storage.objects where bucket_id='myg-nube-sqlite'
    and split_part(name,'/',2)='d9000000000000000000000000000001';
select public.myg_nube_base_eliminacion_finalizar('c0100000-0000-0000-0000-000000000099');
reset role;
select qa.exige(not exists(select 1 from myg_nube_privado.base_vistas where base_id='d9000000-0000-0000-0000-000000000001')
    and not exists(select 1 from myg_nube_privado.base_vista_miembros m join vistas_qa v on m.vista_id in ((v.a->>'id')::uuid,(v.b->>'id')::uuid))
    and not exists(select 1 from myg_nube_privado.base_vista_operaciones o join vistas_qa v on o.vista_id in ((v.a->>'id')::uuid,(v.b->>'id')::uuid))
    and not exists(select 1 from myg_nube_privado.bim_documentos where proyecto_id='d9000000-0000-0000-0000-000000000001')
    and not exists(select 1 from myg_nube_privado.bim_operaciones where proyecto_id='d9000000-0000-0000-0000-000000000001'),
    'Misma base: borrado autorizado limpia referencias y permisos, sin huérfanos');
select qa.exige(exists(select 1 from myg_nube_privado.base_vistas where base_id='d9100000-0000-0000-0000-000000000001'),
    'Misma base: borrar una base conserva vistas y permisos de la otra');
select 'COLABORACION_MISMA_BASE_SQL_APROBADA' resultado;
