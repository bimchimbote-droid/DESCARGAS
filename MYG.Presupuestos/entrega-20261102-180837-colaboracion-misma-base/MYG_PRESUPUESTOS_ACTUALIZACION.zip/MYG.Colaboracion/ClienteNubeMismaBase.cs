#nullable enable
using System.Collections.Concurrent;
using System.Net;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG_2027;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    private Uri? servicioBases;
    private string? servicioBasesComprobado;
    private readonly ConcurrentDictionary<Guid, ProyectoNube> vistasMismaBase = new();

    /// <summary>Destino HTTPS configurado expresamente para el lector seguro de SQLite.
    /// Nunca se obtiene de respuestas remotas ni de datos contenidos en una obra.</summary>
    public string? ServicioBasesUrl
    {
        get => servicioBases?.GetLeftPart(UriPartial.Authority);
        set
        {
            Uri? destino = null;
            if (!string.IsNullOrWhiteSpace(value))
            {
                if (!Uri.TryCreate(value.Trim(), UriKind.Absolute, out destino)
                    || destino.Scheme != Uri.UriSchemeHttps || destino.UserInfo.Length != 0
                    || destino.AbsolutePath != "/" || destino.Query.Length != 0 || destino.Fragment.Length != 0)
                    throw new NubeException("El servicio de colaboración necesita una dirección HTTPS sin credenciales, rutas ni parámetros.");
                destino = new Uri(destino.GetLeftPart(UriPartial.Authority) + "/");
            }
            servicioBases = destino;
            servicioBasesComprobado = null;
            vistasMismaBase.Clear();
        }
    }

    private Uri ExigirServicioBases() => servicioBases
        ?? throw new NubeException("Configure la dirección HTTPS del servicio de colaboración de la misma base. No se creó ninguna copia.",
            codigo: "MYG_BASE_REQUIERE_SERVIDOR");

    private void ExigirDestinoBasesActual(Uri esperado)
    {
        if (servicioBases != esperado)
            throw new NubeException("La configuración del servicio cambió durante la operación. Reintente con la conexión actual.");
    }

    /// <summary>Comprueba el servicio y su Supabase sin transmitir ninguna credencial.</summary>
    public async Task ComprobarServicioBasesAsync(CancellationToken ct = default)
    {
        Uri destino = ExigirServicioBases();
        if (servicioBasesComprobado == destino.AbsoluteUri) return;
        await EjecutarAsync(async token =>
        {
            ExigirDestinoBasesActual(destino);
            using var solicitud = new HttpRequestMessage(HttpMethod.Get, new Uri(destino, "health"));
            solicitud.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            using var respuesta = await _http.SendAsync(solicitud, HttpCompletionOption.ResponseHeadersRead, token);
            if (!respuesta.IsSuccessStatusCode)
                throw new NubeException("El servicio de colaboración no está disponible. No se creó ninguna copia.", esErrorDeConexion: true);
            using var json = await LeerJsonAsync(respuesta, token, 16384, 8, nube: true);
            JsonElement raiz = json.RootElement;
            if (TextoNube(raiz, "servicio", 32) != "MYG_BASES"
                || !raiz.TryGetProperty("version", out var version) || version.ValueKind != JsonValueKind.Number
                || !version.TryGetInt32(out int v) || v != 1
                || !Uri.TryCreate(TextoNube(raiz, "supabase_url", 2048), UriKind.Absolute, out var supabase)
                || supabase.Scheme != Uri.UriSchemeHttps || supabase.UserInfo.Length != 0
                || supabase.AbsolutePath != "/" || supabase.Query.Length != 0 || supabase.Fragment.Length != 0
                || !string.Equals(supabase.GetLeftPart(UriPartial.Authority), UrlServidor, StringComparison.OrdinalIgnoreCase))
                throw new NubeException("El servicio de colaboración no corresponde al servidor de sus obras. No se envió la sesión.");
            ExigirDestinoBasesActual(destino);
            servicioBasesComprobado = destino.AbsoluteUri;
            return true;
        }, ct);
    }

    /// <summary>Registra exclusivamente una referencia y sus permisos; no publica otro contenido.</summary>
    public async Task<ProyectoNube> RegistrarObraMismaBaseAsync(Guid baseId, string documentoId,
        string nombre, CancellationToken ct = default)
    {
        ValidarIdNube(baseId);
        if (!TextoEntradaValido(documentoId, 200) || documentoId != documentoId.Trim())
            throw new NubeException("Seleccione una obra con identidad válida.");
        nombre = ValidarNombreNube(nombre);
        await ComprobarServicioBasesAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        ProyectoNube vista = await EjecutarRpcNubeAsync("myg_base_registrar", new
        {
            p_base = baseId, p_documento = documentoId, p_nombre = nombre
        }, raiz => LeerVistaMismaBase(raiz), ct, identidadEsperada: usuario);
        if (vista.BaseId != baseId || vista.DocumentoId != documentoId || vista.Rol != "propietario")
            throw RespuestaNubeInvalida();
        vistasMismaBase[vista.Id] = vista;
        return vista;
    }

    private async Task<IReadOnlyList<ProyectoNube>> ListarObrasMismaBaseAsync(string usuario, CancellationToken ct)
    {
        return await EjecutarRpcNubeAsync("myg_base_listar", new { }, raiz =>
        {
            ValidarArrayNube(raiz);
            var resultado = new List<ProyectoNube>();
            var ids = new HashSet<Guid>();
            foreach (var elemento in raiz.EnumerateArray())
            {
                var vista = LeerVistaMismaBase(elemento);
                if (!ids.Add(vista.Id)) throw RespuestaNubeInvalida();
                vistasMismaBase[vista.Id] = vista;
                resultado.Add(vista);
            }
            return (IReadOnlyList<ProyectoNube>)resultado.AsReadOnly();
        }, ct, identidadEsperada: usuario);
    }

    private async Task<ProyectoNube?> ResolverObraMismaBaseAsync(Guid id, CancellationToken ct)
    {
        if (ServicioBasesUrl is null) return null;
        return await EjecutarRpcNubeAsync("myg_base_resolver", new { p_id = id }, raiz =>
        {
            if (raiz.ValueKind == JsonValueKind.Null) return null;
            var vista = LeerVistaMismaBase(raiz, esperado: id);
            vistasMismaBase[id] = vista;
            return vista;
        }, ct);
    }

    /// <summary>Reconoce referencias de la misma base también tras volver a iniciar sesión.</summary>
    public async Task<bool> EsObraMismaBaseAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return ServicioBasesUrl is not null && (vistasMismaBase.ContainsKey(id)
            || await ResolverObraMismaBaseAsync(id, ct) is not null);
    }

    private static ProyectoNube LeerVistaMismaBase(JsonElement raiz, bool contenido = false, Guid? esperado = null)
    {
        var vista = LeerProyectoNube(raiz, contenido, esperado);
        if (!vista.EsObraMismaBase) throw RespuestaNubeInvalida();
        if (contenido) ValidarContenidoObraMismaBase(vista.Contenido, vista.DocumentoId!);
        return vista;
    }

    private async Task<ProyectoNube> AbrirObraMismaBaseAsync(Guid id, CancellationToken ct)
    {
        var esperado = vistasMismaBase.TryGetValue(id, out var conocido) ? conocido : null;
        var vista = await EjecutarServicioBasesAsync(HttpMethod.Get, $"obras/{id:D}", null, raiz =>
            LeerVistaMismaBase(raiz, contenido: true, esperado: id), ct);
        if (esperado is not null && (vista.BaseId != esperado.BaseId || vista.DocumentoId != esperado.DocumentoId))
            throw RespuestaNubeInvalida();
        vistasMismaBase[id] = vista;
        return vista;
    }

    private async Task<RespuestaGuardarNube> GuardarObraMismaBaseAsync(Guid id, Guid operacion,
        long revision, JsonElement contenido, CancellationToken ct)
    {
        if (!vistasMismaBase.TryGetValue(id, out var vista)) throw RespuestaNubeInvalida();
        ValidarContenidoObraMismaBase(contenido, vista.DocumentoId!);
        byte[] cuerpo = JsonSerializer.SerializeToUtf8Bytes(new { operacion_id = operacion, revision, contenido }, OpcionesNube);
        if (cuerpo.Length > MaxRespuestaNubeBytes) throw new NubeException("El contenido supera el tamaño admitido para la colaboración.");
        return await EjecutarServicioBasesAsync(HttpMethod.Post, $"obras/{id:D}/guardar", cuerpo, raiz =>
        {
            string estado = TextoNube(raiz, "estado", 32);
            if (estado is not ("aplicada" or "conflicto") || GuidNube(raiz, "operacion_id") != operacion)
                throw RespuestaNubeInvalida();
            long recibida = RevisionNube(raiz);
            if (recibida < revision || (estado == "aplicada" && recibida != revision + 1)) throw RespuestaNubeInvalida();
            JsonElement recibido = ContenidoNube(raiz);
            ValidarContenidoObraMismaBase(recibido, vista.DocumentoId!);
            return new RespuestaGuardarNube(estado, recibida, recibido, operacion);
        }, ct);
    }

    private static void ValidarContenidoObraMismaBase(JsonElement contenido, string documentoId)
    {
        try
        {
            var paquete = FormatoPaqueteNube.Expandir(contenido);
            if (PaqueteNube.LeerDocumento(paquete).Id != documentoId
                || !paquete.TryGetProperty("alcance", out var alcance) || alcance.ValueKind != JsonValueKind.String
                || alcance.GetString() != "obra"
                || !paquete.TryGetProperty("documentos", out var documentos) || documentos.ValueKind != JsonValueKind.Array
                || documentos.GetArrayLength() != 1
                || documentos[0].Deserialize<MYGProyectoDocumento>(OpcionesNube)?.Id != documentoId)
                throw RespuestaNubeInvalida();
        }
        catch (Exception ex) when (ex is JsonException or InvalidDataException or InvalidOperationException or FormatException)
        {
            throw RespuestaNubeInvalida();
        }
    }

    private async Task<T> EjecutarServicioBasesAsync<T>(HttpMethod metodo, string ruta, byte[]? cuerpo,
        Func<JsonElement, T> leer, CancellationToken ct)
    {
        Uri destino = ExigirServicioBases();
        await ComprobarServicioBasesAsync(ct);
        return await EjecutarAsync(async token =>
        {
            ExigirDestinoBasesActual(destino);
            Sesion sesion = await AsegurarSesionAsync(false, token, nube: true);
            string usuario = sesion.Usuario;
            for (int intento = 0; ; intento++)
            {
                ExigirDestinoBasesActual(destino);
                using var solicitud = new HttpRequestMessage(metodo, new Uri(destino, ruta));
                solicitud.Headers.Authorization = new AuthenticationHeaderValue("Bearer", sesion.Acceso);
                solicitud.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                if (cuerpo is not null)
                {
                    solicitud.Content = new ByteArrayContent(cuerpo);
                    solicitud.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json") { CharSet = "utf-8" };
                }
                using var respuesta = await _http.SendAsync(solicitud, HttpCompletionOption.ResponseHeadersRead, token);
                if (respuesta.StatusCode == HttpStatusCode.Unauthorized && intento == 0)
                {
                    sesion = await AsegurarSesionAsync(true, token, nube: true);
                    if (sesion.Usuario != usuario) throw new NubeException("Cambió la cuenta durante la operación.", necesitaIniciarSesion: true);
                    continue;
                }
                if (!respuesta.IsSuccessStatusCode)
                {
                    if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        LimpiarSesion();
                        throw new NubeException("La sesión no permite acceder al servicio de colaboración. Vuelva a iniciar sesión.", necesitaIniciarSesion: true);
                    }
                    if (respuesta.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.NotFound)
                        throw new NubeException("La obra no está disponible para su cuenta o se retiró su acceso.", accesoDenegado: true);
                    if ((int)respuesta.StatusCode >= 500 || respuesta.StatusCode is HttpStatusCode.Conflict or HttpStatusCode.RequestTimeout or HttpStatusCode.TooManyRequests)
                        throw new NubeException("El servicio no pudo confirmar la operación. Se conserva el intento para reintentar.", esErrorDeConexion: true);
                    throw new NubeException("El servicio rechazó los cambios de la obra. Revise sus permisos y el contenido; se conserva el intento pendiente.");
                }
                using var json = await LeerJsonAsync(respuesta, token, MaxRespuestaNubeBytes, MaxProfundidadNube, nube: true);
                ExigirDestinoBasesActual(destino);
                if (Volatile.Read(ref _sesion)?.Usuario != usuario)
                    throw new NubeException("Cambió la cuenta durante la operación.", necesitaIniciarSesion: true);
                return leer(json.RootElement);
            }
        }, ct, plazo: TimeSpan.FromSeconds(150));
    }

    private async Task<(string Funcion, object Parametros)> AdaptarGestionObraMismaBaseAsync(
        string funcion, object parametros, CancellationToken ct)
    {
        if (ServicioBasesUrl is null || funcion is not ("myg_nube_miembros" or "myg_nube_solicitudes"
            or "myg_nube_rol" or "myg_nube_compartir_usuario" or "myg_nube_permisos" or "myg_nube_revision"
            or "myg_nube_resolver")) return (funcion, parametros);
        JsonElement cuerpo = JsonSerializer.SerializeToElement(parametros, OpcionesNube);
        Guid id = GuidNube(cuerpo, "p_id");
        if (!await EsObraMismaBaseAsync(id, ct)) return (funcion, parametros);
        if (funcion == "myg_nube_resolver")
            throw new NubeException("Las obras de una misma base se comparten directamente por usuario MYG; no utilizan solicitudes por código.");
        if (cuerpo.TryGetProperty("p_permisos_modulos", out var permisos))
        {
            if (permisos.ValueKind != JsonValueKind.Object) throw RespuestaNubeInvalida();
            var objeto = JsonNode.Parse(cuerpo.GetRawText())!.AsObject();
            var mascara = objeto["p_permisos_modulos"]!.AsObject();
            if (!mascara.ContainsKey("metrados_revit")) mascara["metrados_revit"] = false;
            parametros = JsonSerializer.SerializeToElement(objeto, OpcionesNube);
        }
        string destino = funcion switch
        {
            "myg_nube_miembros" => "myg_base_miembros",
            "myg_nube_solicitudes" => "myg_base_solicitudes",
            "myg_nube_rol" => "myg_base_rol",
            "myg_nube_compartir_usuario" => "myg_base_compartir_usuario",
            "myg_nube_permisos" => "myg_base_permisos",
            "myg_nube_revision" => "myg_base_resolver",
            _ => throw RespuestaNubeInvalida()
        };
        return (destino, parametros);
    }
}
