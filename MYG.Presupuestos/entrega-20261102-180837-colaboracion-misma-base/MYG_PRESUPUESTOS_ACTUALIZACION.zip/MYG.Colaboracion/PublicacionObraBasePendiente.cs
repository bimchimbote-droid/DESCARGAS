namespace MYG.Colaboracion;

/// <summary>
/// Punto de compatibilidad del antiguo flujo de copias por obra. Crear una
/// colaboración ya no puede publicar un paquete independiente de la base.
/// Las publicaciones existentes se conservan y siguen disponibles desde Nube.
/// </summary>
public sealed class PublicacionObraBasePendiente
{
    private readonly string servidor, usuario;
    public PublicacionObraBasePendiente(string carpeta, string servidor, string usuario)
    {
        if (string.IsNullOrWhiteSpace(carpeta))
            throw new ArgumentException("Indique la carpeta de publicaciones de obras.", nameof(carpeta));
        if (!Uri.TryCreate(servidor, UriKind.Absolute, out var destino)
            || destino.Scheme != Uri.UriSchemeHttps || destino.UserInfo.Length != 0
            || destino.AbsolutePath != "/" || destino.Query.Length != 0 || destino.Fragment.Length != 0)
            throw new ArgumentException("Indique el servidor HTTPS de nube sin credenciales ni rutas.", nameof(servidor));
        if (!Guid.TryParse(usuario, out var identidad) || identidad == Guid.Empty)
            throw new ArgumentException("Indique la identidad de la cuenta de nube.", nameof(usuario));
        // Validar la ruta no crea la carpeta ni lee intentos de la versión anterior.
        _ = Path.GetFullPath(carpeta);
        this.servidor = destino.GetLeftPart(UriPartial.Authority);
        this.usuario = identidad.ToString("D");
    }

    public async Task<ObraBaseNube> PrepararYEnviarAsync(ClienteSupabase cliente, Guid baseId,
        string rutaSQLite, string documentoId, CancellationToken ct = default,
        IProgress<string>? progreso = null)
    {
        ArgumentNullException.ThrowIfNull(cliente);
        ct.ThrowIfCancellationRequested();
        if (cliente.UrlServidor != servidor || cliente.UsuarioId != usuario)
            throw new NubeException("Abra la base con la misma cuenta y servidor.", accesoDenegado: true);
        // Sin servicio no leer archivos ni recuperar intentos antiguos. Con él,
        // registrar únicamente metadatos; nunca publicar un paquete de la obra.
        await cliente.ComprobarServicioBasesAsync(ct);
        var resumen = MYG_2027.MYGBaseDatos.ListarProyectos(rutaSQLite)
            .SingleOrDefault(p => p.Id == documentoId)
            ?? throw new InvalidDataException("La obra elegida no está en esta base.");
        var vista = await cliente.RegistrarObraMismaBaseAsync(baseId, documentoId, resumen.Nombre, ct);
        return new ObraBaseNube(vista, documentoId);
    }

    public static NubeException ServicioRequerido() => new(
        "No se creó ninguna copia ni se cambiaron los permisos. "
        + "Configure ServicioBasesUrl con la dirección HTTPS del servicio de colaboración "
        + "e instale la migración 20261105_colaboracion_misma_base.sql para compartir "
        + "una obra dentro de la misma base SQLite. "
        + "La base original y las colaboraciones anteriores se conservan.",
        codigo: "MYG_BASE_REQUIERE_SERVIDOR");
}
