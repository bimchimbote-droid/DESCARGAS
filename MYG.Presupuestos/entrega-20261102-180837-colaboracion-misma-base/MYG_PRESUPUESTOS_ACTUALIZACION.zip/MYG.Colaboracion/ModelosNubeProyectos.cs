#nullable enable
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>Proyecto visible para la identidad autenticada. El listado no descarga su contenido.</summary>
public sealed record ProyectoNube(
    [property: JsonPropertyName("id")] Guid Id,
    [property: JsonPropertyName("codigo")] string Codigo,
    [property: JsonPropertyName("nombre")] string Nombre,
    [property: JsonPropertyName("rol")] string Rol,
    [property: JsonPropertyName("revision")] long Revision,
    [property: JsonPropertyName("alcance")] string Alcance,
    [property: JsonPropertyName("contenido")] JsonElement Contenido)
{
    /// <summary>Identidad de la base original para una vista autorizada; no es una publicación independiente.</summary>
    [JsonPropertyName("base_id")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Guid? BaseId { get; init; }

    [JsonPropertyName("documento_id")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? DocumentoId { get; init; }

    [JsonPropertyName("vista_base")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public bool EsObraMismaBase => BaseId.HasValue;

    /// <summary>Último cambio confirmado por el servidor. Null conserva compatibilidad con servidores anteriores.</summary>
    [JsonPropertyName("actualizado_en")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public DateTimeOffset? ActualizadoEn { get; init; }

    /// <summary>El servidor conserva el proyecto visible mientras completa su eliminación recuperable.</summary>
    [JsonPropertyName("eliminacion_pendiente")]
    public bool EliminacionPendiente { get; init; }

    /// <summary>Bytes informados por el servidor, sin descargar el contenido.
    /// Null identifica un servidor anterior que todavía no informa tamaños.</summary>
    [JsonPropertyName("tamano_bytes")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public long? TamanoBytes { get; init; }

    [JsonPropertyName("tamano_formato")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? TamanoFormato { get; init; }

    [JsonPropertyName("permisos_modulos")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public MYGPermisosModulos? PermisosModulos { get; init; }
}

public sealed record MiembroNube(
    [property: JsonPropertyName("usuario_id")] string UsuarioId,
    [property: JsonPropertyName("rol")] string Rol)
{
    [JsonPropertyName("usuario_myg")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? UsuarioMyg { get; init; }

    [JsonPropertyName("permisos_modulos")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public MYGPermisosModulos? PermisosModulos { get; init; }

    /// <summary>
    /// Usa el nombre de la sesión MYG verificada únicamente para su mismo UUID.
    /// Para los demás miembros, el nombre debe proceder del servidor.
    /// </summary>
    public string? ObtenerUsuarioMyg(string? usuarioIdSesion, string? usuarioMygSesion)
    {
        if (!string.IsNullOrWhiteSpace(usuarioMygSesion)
            && Guid.TryParse(UsuarioId, out Guid miembro) && miembro != Guid.Empty
            && Guid.TryParse(usuarioIdSesion, out Guid sesion) && sesion == miembro)
            return usuarioMygSesion.Trim();
        return string.IsNullOrWhiteSpace(UsuarioMyg) ? null : UsuarioMyg;
    }
}

public sealed record SolicitudNube(
    [property: JsonPropertyName("usuario_id")] string UsuarioId,
    [property: JsonPropertyName("estado")] string Estado);

/// <summary>La revisión y el contenido siempre corresponden al estado confirmado por el servidor.</summary>
public sealed record RespuestaGuardarNube(
    [property: JsonPropertyName("estado")] string Estado,
    [property: JsonPropertyName("revision")] long Revision,
    [property: JsonPropertyName("contenido")] JsonElement Contenido,
    [property: JsonPropertyName("operacion_id")] Guid OperacionId);
