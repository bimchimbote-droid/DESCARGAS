using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Contrato cliente de vistas autorizadas de una misma base, sin copias remotas; HTTP simulado.</summary>
internal static class MismaBaseClienteCheck
{
    private const string Supabase = "https://misma-base-qa.supabase.co";
    private const string Servicio = "https://servicio.example";
    private const string Clave = "sb_publishable_misma_base_qa";
    private const string Acceso = "acceso_sintetico_misma_base";
    private const string Privado = "SUR-PRIVADO-NO-ENTREGAR-6AAB4DD6";
    private static readonly Guid Usuario = Guid.Parse("65736f60-a81c-47bd-a52e-909202bb94f4");
    private static readonly Guid Base = Guid.Parse("5071c74e-a52b-49e2-8a1c-e19bfd417054");
    private static readonly Guid Vista = Guid.Parse("9e29e756-41df-4281-a8c7-01c472c4977b");
    private static readonly Guid Legado = Guid.Parse("33fc1f82-f7ad-4099-9fb3-ff9c18011977");
    private static readonly Guid Colaborador = Guid.Parse("e73d512e-b9db-4120-9609-3d86d354037c");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string temporal = Path.Combine(Path.GetTempPath(), "MYG-Misma-Base-Cliente-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temporal);
        try
        {
            var datos = Preparar(temporal);
            await SinConfiguracionConservaLegado(datos);
            await SaludYDestinos(datos);
            await RegistrarListarAbrirGuardar(datos);
            await ReaperturaFriaYRevocacion(datos);
            await AdministrarPermisos(datos);
            await RenovacionConservaOperacion(datos);
            await Segundo401CierraSesion(datos);
            await ListadoNoMezclaSesiones(datos);
            Exige(Hash(datos.Ruta) == datos.Huella && MYGBaseDatos.ListarProyectos(datos.Ruta).Count == 2,
                "las operaciones cliente deben conservar los bytes de la base original de dos obras.");
            Console.WriteLine($"OK Misma base cliente: {comprobaciones} comprobaciones de registro sin datos, destino HTTPS, aislamiento de obra, reapertura, permisos y revocación; HTTP simulado y SQLite real.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(temporal, true); }
    }

    private sealed record Datos(string Ruta, string Huella, string Documento, string Nombre, JsonElement Contenido);

    private static Datos Preparar(string temporal)
    {
        string ruta = Path.Combine(temporal, "base-dos-obras.sqlite");
        var norte = MYGProyectoStorage.Nuevo("Norte autorizada QA", "Presupuesto norte QA");
        var sur = MYGProyectoStorage.Nuevo(Privado, "Presupuesto sur privado");
        MYGProyectoStorage.Guardar(ruta, norte); MYGProyectoStorage.Guardar(ruta, sur);
        var contenido = PaqueteNube.CrearContenido(norte, ruta, "obra", compacto: false);
        Exige(PaqueteNube.LeerDocumento(contenido).Id == norte.Id
            && !contenido.GetRawText().Contains(Privado, StringComparison.Ordinal),
            "el fixture del servidor debe proyectar únicamente la obra norte del SQLite de dos obras.");
        return new(ruta, Hash(ruta), norte.Id, norte.Nombre, contenido);
    }

    private static async Task SinConfiguracionConservaLegado(Datos datos)
    {
        using var http = new Transporte(datos);
        using var cliente = await Conectar(http, configurar: false);
        var lista = await cliente.ListarProyectosAsync();
        Exige(lista.Count == 1 && lista[0].Id == Legado && !lista[0].EsObraMismaBase,
            "sin URL de servicio, el listado legado debe conservar su contrato.");
        Exige(!http.Rutas.Any(x => x.Contains("myg_base_", StringComparison.Ordinal)
            || x.StartsWith(Servicio, StringComparison.Ordinal)),
            "una instalación sin configuración no debe intentar el protocolo nuevo.");
        int antes = http.Rutas.Count;
        await Rechaza(() => cliente.ComprobarServicioBasesAsync());
        Exige(http.Rutas.Count == antes, "sin servicio configurado no se debe enviar una comprobación ni credenciales.");
    }

    private static async Task SaludYDestinos(Datos datos)
    {
        foreach (string url in new[] { "http://servicio.example", "https://usuario:clave@servicio.example", "https://servicio.example?secreto=1", "https://servicio.example#fragmento" })
        {
            using var http = new Transporte(datos);
            using var cliente = await Conectar(http, configurar: false);
            int antes = http.Rutas.Count;
            try
            {
                cliente.ServicioBasesUrl = url;
                await cliente.ComprobarServicioBasesAsync();
                throw new InvalidOperationException("Misma base cliente: aceptó un destino inválido " + url.Split(':')[0]);
            }
            catch (Exception error) when (error is NubeException or ArgumentException)
            {
                Exige(http.Rutas.Count == antes, "un destino inseguro debe rechazarse sin tráfico ni JWT.");
            }
        }
        foreach (string salud in new[] { "otro-supabase", "redireccion" })
        {
            using var http = new Transporte(datos) { Salud = salud };
            using var cliente = await Conectar(http);
            await Rechaza(() => cliente.ComprobarServicioBasesAsync());
            Exige(http.SaludSinCredenciales == 1 && http.ServicioConBearer == 0,
                "una salud ajena o redirigida debe rechazarse antes de entregar el JWT al servicio.");
            Exige(!http.Rutas.Any(x => x.StartsWith("https://destino-ajeno.example", StringComparison.Ordinal)),
                "la comprobación de salud no debe seguir redirecciones.");
        }
    }

    private static async Task RegistrarListarAbrirGuardar(Datos datos)
    {
        using var http = new Transporte(datos);
        using var cliente = await Conectar(http);
        await cliente.ComprobarServicioBasesAsync();
        var registrada = await cliente.RegistrarObraMismaBaseAsync(Base, datos.Documento, datos.Nombre);
        Exige(registrada.Id == Vista && registrada.EsObraMismaBase && registrada.BaseId == Base
            && registrada.DocumentoId == datos.Documento && registrada.Revision == 17 && registrada.Alcance == "obra",
            "registrar la vista debe conservar documento y revisión global de la misma base.");
        Exige(http.Registros == 1 && http.RegistroSoloMetadatos,
            "registrar colaboración debe enviar únicamente base, documento y nombre, sin paquete ni archivo.");
        var lista = await cliente.ListarProyectosAsync();
        Exige(lista.Count == 2 && lista.Any(p => p.Id == Legado && !p.EsObraMismaBase)
            && lista.Single(p => p.Id == Vista).EsObraMismaBase,
            "el listado debe combinar entradas legadas y la vista sin duplicar la base.");
        var abierto = await cliente.AbrirProyectoAsync(Vista);
        Exige(abierto.BaseId == Base && abierto.DocumentoId == datos.Documento
            && PaqueteNube.LeerDocumento(abierto.Contenido).Id == datos.Documento,
            "abrir debe usar la vista autorizada y conservar su documento.");
        Exige(!abierto.Contenido.GetRawText().Contains(Privado, StringComparison.Ordinal),
            "el contenido devuelto al colaborador no debe incluir la obra vecina privada.");
        Guid operacion = Guid.NewGuid();
        var guardado = await cliente.GuardarProyectoAsync(Vista, operacion, 17, abierto.Contenido);
        Exige(guardado.Estado == "aplicada" && guardado.Revision == 18 && guardado.OperacionId == operacion
            && PaqueteNube.LeerDocumento(guardado.Contenido).Id == datos.Documento,
            "guardar debe devolver el ACK de la operación y la nueva revisión de la base.");
        Exige(http.Guardados == 1 && http.OperacionGuardada == operacion && http.RevisionGuardada == 17,
            "guardar debe conservar UUID y revisión base mediante el endpoint de la vista.");
        Exige(http.SaludSinCredenciales == 1 && http.ServicioConBearer == 2,
            "salud debe preceder al tráfico autenticado y las lecturas/guardados deben usar la sesión actual.");
        ExigeSinCopias(http);
    }

    private static async Task ReaperturaFriaYRevocacion(Datos datos)
    {
        using var http = new Transporte(datos);
        using var cliente = await Conectar(http);
        var abierto = await cliente.AbrirProyectoAsync(Vista);
        Exige(http.Resoluciones >= 1 && abierto.EsObraMismaBase && http.Lecturas == 1,
            "una sesión nueva debe resolver la vista antes de abrirla por la ruta correcta.");
        Exige(await cliente.EsObraMismaBaseAsync(Vista), "resolver la vista no debe depender de haberla registrado en memoria.");
        http.Revocado = true;
        var error = await Rechaza(() => cliente.AbrirProyectoAsync(Vista));
        Exige(error.AccesoDenegado && http.Lecturas == 2,
            "la revocación debe ser consultada por el servicio aunque exista una resolución local anterior.");
        Exige(http.AperturasLegadas == 0,
            "un rechazo del servicio no debe intentar abrir la misma identidad por la ruta legada.");
        ExigeSinCopias(http);
    }

    private static async Task AdministrarPermisos(Datos datos)
    {
        using var http = new Transporte(datos);
        using var cliente = await Conectar(http);
        Exige(await cliente.EsObraMismaBaseAsync(Vista), "la administración debe resolver una vista en una sesión nueva.");
        var miembros = await cliente.ListarMiembrosAsync(Vista);
        Exige(miembros.Count == 1 && miembros[0].UsuarioId == Colaborador.ToString("D")
            && miembros[0].PermisosModulos is { Acu: false, Especificaciones: true, MetradosExcel: false, MetradosRevit: false },
            "listar miembros debe preservar los cuatro permisos explícitos de la obra.");
        Exige((await cliente.ListarSolicitudesAsync(Vista)).Count == 0,
            "listar solicitudes de una vista debe usar su ámbito de permisos.");
        var permisos = new MYGPermisosModulos { Acu = false, Especificaciones = true, MetradosExcel = false, MetradosRevit = false };
        await cliente.CompartirConUsuarioMygAsync(Vista, "colaborador", "editor", permisos);
        await cliente.CambiarPermisosMiembroAsync(Vista, Colaborador.ToString("D"), permisos);
        await cliente.CambiarRolAsync(Vista, Colaborador.ToString("D"), null);
        Exige(http.MascarasAdministrativas.Count == 2 && http.MascarasAdministrativas.All(j =>
            j.EnumerateObject().Count() == 4 && !j.GetProperty("acu").GetBoolean()
            && j.GetProperty("especificaciones").GetBoolean() && !j.GetProperty("metrados_excel").GetBoolean()
            && !j.GetProperty("metrados_revit").GetBoolean()),
            "compartir y revocar un módulo deben enviar siempre los cuatro booleanos, incluido Revit=false.");
        Exige(http.Administrativas.SetEquals(new[] { "myg_base_miembros", "myg_base_solicitudes", "myg_base_compartir_usuario", "myg_base_permisos", "myg_base_rol" }),
            "la gestión de la vista debe dirigirse a las RPC de permisos de obra dentro de la base.");
        ExigeSinCopias(http);
    }

    private static async Task RenovacionConservaOperacion(Datos datos)
    {
        foreach (bool cambiaIdentidad in new[] { false, true })
        {
            using var http = new Transporte(datos)
            {
                GuardarDevuelve401 = true,
                CambiaIdentidadEnRefresco = cambiaIdentidad
            };
            using var cliente = await Conectar(http);
            await cliente.RegistrarObraMismaBaseAsync(Base, datos.Documento, datos.Nombre);
            Guid operacion = Guid.NewGuid();
            if (cambiaIdentidad)
            {
                var error = await Rechaza(() => cliente.GuardarProyectoAsync(Vista, operacion, 17, datos.Contenido));
                Exige(error.NecesitaIniciarSesion && !cliente.SesionIniciada,
                    "una renovación con otra identidad debe cerrar la sesión local y cancelar la operación.");
                Exige(http.CuerposGuardados.Count == 1 && http.Guardados == 0,
                    "el cuerpo pendiente nunca debe reenviarse con la identidad cambiada.");
            }
            else
            {
                var respuesta = await cliente.GuardarProyectoAsync(Vista, operacion, 17, datos.Contenido);
                Exige(respuesta.Estado == "aplicada" && respuesta.OperacionId == operacion && respuesta.Revision == 18,
                    "la misma operación debe confirmarse tras renovar la sesión una sola vez.");
                Exige(http.CuerposGuardados.Count == 2 && http.CuerposGuardados[0].SequenceEqual(http.CuerposGuardados[1]),
                    "el reintento 401 debe conservar exactamente los bytes del paquete, UUID y revisión.");
                Exige(http.Guardados == 1 && cliente.UsuarioId == Usuario.ToString("D"),
                    "solo el segundo envío debe aplicarse y debe conservar la cuenta original.");
            }
            Exige(http.Refrescos == 1, "un rechazo 401 debe provocar una sola renovación de sesión.");
            ExigeSinCopias(http);
        }
    }

    private static async Task ListadoNoMezclaSesiones(Datos datos)
    {
        using var http = new Transporte(datos);
        using var cliente = await Conectar(http);
        Task? ingreso = null;
        http.UsuarioDeIngreso = Colaborador;
        // La segunda sesión queda en espera del cerrojo mientras la primera RPC
        // está en curso. Debe detectarse antes de pedir las vistas de esa cuenta.
        http.AlListarLegado = () => ingreso = cliente.IniciarSesionAsync("otra@myg.example", "otra_clave_sintetica");
        var error = await Rechaza(() => cliente.ListarProyectosAsync());
        if (ingreso is not null) await ingreso;
        Exige(error.NecesitaIniciarSesion && cliente.UsuarioId == Colaborador.ToString("D"),
            "un cambio de sesión entre las dos RPC del listado debe abortar el resultado combinado.");
        Exige(!http.Rutas.Any(x => x.EndsWith("/myg_base_listar", StringComparison.Ordinal)),
            "no deben combinarse las entradas de la cuenta anterior con las vistas de la cuenta nueva.");
        ExigeSinCopias(http);
    }

    private static async Task Segundo401CierraSesion(Datos datos)
    {
        using var http = new Transporte(datos) { GuardarDevuelve401Siempre = true };
        using var cliente = await Conectar(http);
        await cliente.RegistrarObraMismaBaseAsync(Base, datos.Documento, datos.Nombre);
        var error = await Rechaza(() => cliente.GuardarProyectoAsync(Vista, Guid.NewGuid(), 17, datos.Contenido));
        Exige(error.NecesitaIniciarSesion && !cliente.SesionIniciada,
            "un segundo 401 debe invalidar la sesión local para permitir un ingreso nuevo.");
        Exige(http.Refrescos == 1 && http.CuerposGuardados.Count == 2 && http.Guardados == 0
            && http.CuerposGuardados[0].SequenceEqual(http.CuerposGuardados[1]),
            "el segundo 401 debe detener los reintentos sin cambiar el cuerpo ni aplicar la operación.");
        ExigeSinCopias(http);
    }

    private static async Task<ClienteSupabase> Conectar(Transporte http, bool configurar = true)
    {
        var cliente = new ClienteSupabase(Supabase, Clave, http);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        if (configurar) cliente.ServicioBasesUrl = Servicio;
        return cliente;
    }

    private static void ExigeSinCopias(Transporte http) => Exige(!http.Rutas.Any(x =>
        x.Contains("/storage/", StringComparison.Ordinal) || x.Contains("myg_nube_crear", StringComparison.Ordinal)
        || x.Contains("myg_nube_base_obra_vincular", StringComparison.Ordinal)
        || x.Contains("myg_nube_sqlite_abrir", StringComparison.Ordinal)),
        "colaborar no debe subir Storage, crear publicaciones, vincular copias ni descargar la base completa.");

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error) { comprobaciones++; return error; }
        throw new InvalidOperationException("Misma base cliente: faltó el rechazo esperado.");
    }

    private static string Hash(string ruta)
    { using var archivo = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(archivo)); }

    private static void Exige(bool condicion, string detalle)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException("Misma base cliente: " + detalle); }

    private sealed class Transporte(Datos datos) : HttpMessageHandler
    {
        internal string Salud = "";
        internal bool Revocado, RegistroSoloMetadatos;
        internal bool GuardarDevuelve401, GuardarDevuelve401Siempre, CambiaIdentidadEnRefresco;
        internal Guid UsuarioDeIngreso = Usuario;
        internal Action? AlListarLegado;
        internal int Refrescos;
        internal int SaludSinCredenciales, ServicioConBearer, Registros, Resoluciones, Lecturas, Guardados, AperturasLegadas;
        internal Guid OperacionGuardada;
        internal long RevisionGuardada;
        internal readonly List<string> Rutas = new();
        internal readonly List<JsonElement> MascarasAdministrativas = new();
        internal readonly HashSet<string> Administrativas = new(StringComparer.Ordinal);
        internal readonly List<byte[]> CuerposGuardados = new();
        private string tokenActual = Acceso;

        private object Permisos() => new { acu = false, especificaciones = true, metrados_excel = false, metrados_revit = false };
        private Dictionary<string, object?> Descriptor(bool contenido = false)
        {
            var d = new Dictionary<string, object?>
            {
                ["id"] = Vista, ["codigo"] = "MYG-VISTA-QA", ["nombre"] = datos.Nombre,
                ["rol"] = "propietario", ["revision"] = 17, ["alcance"] = "obra",
                ["vista_base"] = true, ["base_id"] = Base, ["documento_id"] = datos.Documento,
                ["permisos_modulos"] = Permisos()
            };
            if (contenido) d["contenido"] = datos.Contenido;
            return d;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            Rutas.Add(request.RequestUri!.GetLeftPart(UriPartial.Path));
            string host = request.RequestUri.Host, path = request.RequestUri.AbsolutePath;
            if (host == new Uri(Supabase).Host && path == "/auth/v1/token")
            {
                bool refresco = request.RequestUri.Query == "?grant_type=refresh_token";
                if (refresco)
                {
                    Refrescos++;
                    tokenActual = Acceso + "_renovado";
                }
                Guid cuenta = refresco && CambiaIdentidadEnRefresco ? Colaborador : UsuarioDeIngreso;
                return Json(new { access_token = tokenActual, refresh_token = "refresco_qa", expires_in = 3600, user = new { id = cuenta } });
            }
            if (host == new Uri(Servicio).Host)
            {
                if (path == "/health")
                {
                    if (request.Headers.Authorization is not null || request.Headers.Contains("apikey"))
                        throw new InvalidOperationException("Misma base cliente: la comprobación de destino filtró credenciales.");
                    SaludSinCredenciales++;
                    if (Salud == "redireccion")
                    {
                        var respuesta = new HttpResponseMessage(HttpStatusCode.Found);
                        respuesta.Headers.Location = new Uri("https://destino-ajeno.example/health");
                        return respuesta;
                    }
                    return Json(new { servicio = "MYG_BASES", version = 1,
                        supabase_url = Salud == "otro-supabase" ? "https://otro.supabase.co" : Supabase });
                }
                if (SaludSinCredenciales != 1 || request.Headers.Authorization?.Scheme != "Bearer"
                    || request.Headers.Authorization.Parameter != tokenActual)
                    throw new InvalidOperationException("Misma base cliente: se envió una operación sin validar el destino o sin la cuenta actual.");
                ServicioConBearer++;
                if (path == "/obras/" + Vista.ToString("D") && request.Method == HttpMethod.Get)
                {
                    Lecturas++;
                    return Revocado ? Json(new { code = "42501", message = "Acceso denegado" }, HttpStatusCode.Forbidden) : Json(Descriptor(contenido: true));
                }
                if (path == "/obras/" + Vista.ToString("D") + "/guardar" && request.Method == HttpMethod.Post)
                {
                    byte[] bytes = await request.Content!.ReadAsByteArrayAsync(ct);
                    CuerposGuardados.Add(bytes);
                    using var json = JsonDocument.Parse(bytes);
                    var cuerpo = json.RootElement;
                    OperacionGuardada = cuerpo.GetProperty("operacion_id").GetGuid();
                    RevisionGuardada = cuerpo.GetProperty("revision").GetInt64();
                    var contenido = cuerpo.GetProperty("contenido");
                    if (PaqueteNube.LeerDocumento(contenido).Id != datos.Documento
                        || contenido.GetRawText().Contains(Privado, StringComparison.Ordinal))
                        throw new InvalidOperationException("Misma base cliente: el guardado transportó otra obra.");
                    if (GuardarDevuelve401Siempre || GuardarDevuelve401 && CuerposGuardados.Count == 1)
                        return Json(new { message = "Sesión de prueba vencida" }, HttpStatusCode.Unauthorized);
                    Guardados++;
                    return Json(new { estado = "aplicada", revision = 18, operacion_id = OperacionGuardada, contenido });
                }
                throw new InvalidOperationException("Misma base cliente: endpoint de servicio inesperado " + path);
            }
            if (host != new Uri(Supabase).Host || !path.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal))
                throw new InvalidOperationException("Misma base cliente: destino inesperado " + host + path);
            if (request.Headers.Authorization?.Parameter != tokenActual || !request.Headers.Contains("apikey"))
                throw new InvalidOperationException("Misma base cliente: la RPC perdió la sesión Supabase.");
            string funcion = path.Split('/').Last();
            using var solicitud = JsonDocument.Parse(await request.Content!.ReadAsStringAsync(ct));
            var p = solicitud.RootElement;
            if (funcion == "myg_nube_listar")
            {
                AlListarLegado?.Invoke();
                return Json(new[] { new
                    { id = Legado, codigo = "MYG-LEGADO", nombre = "Entrada anterior QA", rol = "editor", revision = 2, alcance = "obra" } });
            }
            if (funcion == "myg_base_listar") return Json(new[] { Descriptor() });
            if (funcion == "myg_base_resolver")
            {
                Resoluciones++;
                return Json(p.GetProperty("p_id").GetGuid() == Vista ? Descriptor() : null);
            }
            if (funcion == "myg_base_registrar")
            {
                Registros++;
                RegistroSoloMetadatos = p.EnumerateObject().Count() == 3
                    && p.GetProperty("p_base").GetGuid() == Base
                    && p.GetProperty("p_documento").GetString() == datos.Documento
                    && p.GetProperty("p_nombre").GetString() == datos.Nombre;
                return Json(Descriptor());
            }
            if (funcion == "myg_nube_abrir") AperturasLegadas++;
            if (funcion.StartsWith("myg_base_", StringComparison.Ordinal))
            {
                if (p.GetProperty("p_id").GetGuid() != Vista)
                    throw new InvalidOperationException("Misma base cliente: administró otra vista.");
                Administrativas.Add(funcion);
                if (funcion == "myg_base_miembros") return Json(new[] { new
                    { usuario_id = Colaborador, usuario_myg = "colaborador", rol = "editor", permisos_modulos = Permisos() } });
                if (funcion == "myg_base_solicitudes") return Json(Array.Empty<object>());
                if (funcion is "myg_base_compartir_usuario" or "myg_base_permisos")
                {
                    MascarasAdministrativas.Add(p.GetProperty("p_permisos_modulos").Clone());
                    return Json(new { estado = "actualizada" });
                }
                if (funcion == "myg_base_rol") return Json(true);
            }
            throw new InvalidOperationException("Misma base cliente: RPC inesperada " + funcion);
        }

        private static HttpResponseMessage Json(object? valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
