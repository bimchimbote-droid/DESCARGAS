using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

internal static class ConfiguracionNubeCheck
{
    internal static Task RunAsync()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-configuracion-nube-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        int comprobaciones = 0;
        void Exige(bool condicion, string mensaje)
        {
            comprobaciones++;
            if (!condicion) throw new InvalidOperationException("Configuración de nube: " + mensaje);
        }
        void Rechaza(Action accion, string mensaje)
        {
            try { accion(); }
            catch (Exception ex) when (ex is InvalidDataException or JsonException or NubeException
                or IOException or UnauthorizedAccessException or ArgumentException)
            { comprobaciones++; return; }
            throw new InvalidOperationException("Configuración de nube: " + mensaje);
        }
        var local = new ConfiguracionServicioNube("Conexión anterior", "https://anterior.supabase.co", "sb_publishable_local_sintetica");
        var oficial = new ConfiguracionServicioNube("Nube MYG", "https://oficial.supabase.co", "sb_publishable_oficial_sintetica");
        string rutaLocal = Path.Combine(carpeta, "perfil", "config.json");
        string rutaOficial = Path.Combine(carpeta, "instalacion", "nube-myg.json");
        try
        {
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) is null,
                "sin archivos debe conservar el estado sin configurar.");
            Exige(!Directory.Exists(Path.GetDirectoryName(rutaLocal)), "cargar no crea el perfil.");

            ConfiguracionServicioNube.Guardar(rutaOficial, oficial);
            byte[] copiaOficial = File.ReadAllBytes(rutaOficial);
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == oficial,
                "una instalación nueva utiliza la conexión distribuida.");
            Exige(!File.Exists(rutaLocal), "utilizar el archivo distribuido no crea ni fija una copia local.");

            ConfiguracionServicioNube.Guardar(rutaLocal, local);
            byte[] copiaLocal = File.ReadAllBytes(rutaLocal);
            DateTime escrituraLocal = File.GetLastWriteTimeUtc(rutaLocal);
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == local,
                "el destino previo del perfil prevalece sobre el oficial.");
            Exige(File.ReadAllBytes(rutaLocal).SequenceEqual(copiaLocal)
                && File.GetLastWriteTimeUtc(rutaLocal) == escrituraLocal
                && File.ReadAllBytes(rutaOficial).SequenceEqual(copiaOficial),
                "leer no cambia ninguno de los archivos ni la fecha de la conexión previa.");

            File.WriteAllText(rutaOficial, "archivo oficial inválido");
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == local,
                "un archivo oficial dañado no afecta una configuración local correcta.");
            File.Delete(rutaOficial);
            Directory.CreateDirectory(rutaOficial);
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == local,
                "el destino distribuido ni siquiera se abre cuando existe el local válido.");
            Directory.Delete(rutaOficial);
            ConfiguracionServicioNube.Guardar(rutaOficial, oficial);

            foreach (string invalida in new[]
            {
                "{", "", "null", "{}",
                JsonSerializer.Serialize(local with { Nombre = "" }),
                JsonSerializer.Serialize(local with { Nombre = new string('a', 101) }),
                JsonSerializer.Serialize(local with { Url = "http://anterior.supabase.co" }),
                JsonSerializer.Serialize(local with { Url = "https://anterior.supabase.co/ruta" }),
                JsonSerializer.Serialize(local with { ClavePublicable = "sb_secret_NO_DISTRIBUIR" }),
                JsonSerializer.Serialize(local with { ClavePublicable = Jwt("service_role") })
            })
            {
                File.WriteAllText(rutaLocal, invalida);
                Rechaza(() => ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial),
                    "un archivo local inválido no debe cambiar de servidor usando el oficial.");
                Exige(File.ReadAllText(rutaLocal) == invalida, "el fallo conserva intacto el archivo local para recuperarlo.");
            }
            File.WriteAllBytes(rutaLocal, Encoding.ASCII.GetBytes("{\"Nombre\":\"").Concat(new byte[] { 0xff })
                .Concat(Encoding.ASCII.GetBytes("\",\"Url\":\"https://anterior.supabase.co\",\"ClavePublicable\":\"sb_publishable_prueba\"}")).ToArray());
            Rechaza(() => ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial), "debe rechazar UTF-8 inválido.");
            File.WriteAllText(rutaLocal, new string(' ', 64 * 1024 + 1));
            Rechaza(() => ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial), "debe limitar los archivos a 64 KiB.");
            var utf16 = new UnicodeEncoding(false, true, true);
            File.WriteAllBytes(rutaLocal, utf16.GetPreamble().Concat(utf16.GetBytes(new string(' ', 32 * 1024))).ToArray());
            Rechaza(() => ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial),
                "el límite debe contar bytes UTF-16 y BOM, aunque el texto decodificado sea más pequeño.");
            File.Delete(rutaLocal);
            Directory.CreateDirectory(rutaLocal);
            Rechaza(() => ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial),
                "una ruta local que es un directorio no debe activar el fallback.");
            Directory.Delete(rutaLocal);

            File.WriteAllText(rutaOficial, "{\"Nombre\":");
            Rechaza(() => ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial), "debe rechazar un archivo oficial truncado.");
            Exige(!File.Exists(rutaLocal), "un error de instalación no crea configuración local.");
            ConfiguracionServicioNube.Guardar(rutaOficial, oficial);

            var unicode = local with { Nombre = "Nube Áncash — 日本語 🏗️" };
            foreach (Encoding codificacion in new Encoding[]
            {
                new UTF8Encoding(true, true), new UnicodeEncoding(false, true, true),
                new UnicodeEncoding(true, true, true), new UTF32Encoding(false, true, true),
                new UTF32Encoding(true, true, true)
            })
            {
                byte[] heredada = codificacion.GetPreamble()
                    .Concat(codificacion.GetBytes(JsonSerializer.Serialize(unicode))).ToArray();
                File.WriteAllBytes(rutaLocal, heredada);
                Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == unicode,
                    "una conexión local con BOM " + codificacion.WebName + " conserva su destino y texto Unicode.");
                Exige(File.ReadAllBytes(rutaLocal).SequenceEqual(heredada),
                    "cargar una conexión heredada con BOM no debe reescribirla.");
                File.Delete(rutaLocal);
                byte[] distribuida = codificacion.GetPreamble()
                    .Concat(codificacion.GetBytes(JsonSerializer.Serialize(oficial))).ToArray();
                File.WriteAllBytes(rutaOficial, distribuida);
                Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == oficial,
                    "la conexión distribuida admite BOM " + codificacion.WebName + ".");
                Exige(!File.Exists(rutaLocal), "utilizar una conexión con BOM no crea una copia local.");
            }
            ConfiguracionServicioNube.Guardar(rutaOficial, oficial);
            ConfiguracionServicioNube.Guardar(rutaLocal, unicode);
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == unicode,
                "guardar y cargar conserva el nombre Unicode y la conexión exacta.");
            byte[] anterior = File.ReadAllBytes(rutaLocal);
            Rechaza(() => ConfiguracionServicioNube.Guardar(rutaLocal, unicode with { ClavePublicable = "sb_secret_NO_DISTRIBUIR" }),
                "guardar una clave secreta debe fallar.");
            Exige(File.ReadAllBytes(rutaLocal).SequenceEqual(anterior), "validar antes de guardar conserva una conexión válida.");
            Rechaza(() => ConfiguracionServicioNube.Guardar(rutaLocal, unicode with { Url = "https://externo.example" }),
                "un destino que no es Supabase debe rechazarse.");
            Exige(File.ReadAllBytes(rutaLocal).SequenceEqual(anterior), "un destino inválido no reemplaza la conexión previa.");

            string conSesion = JsonSerializer.Serialize(local).TrimEnd('}')
                + ",\"Acceso\":\"TOKEN_NO_EXPORTAR\",\"Refresco\":\"REFRESCO_NO_EXPORTAR\",\"Usuario\":\"CUENTA_NO_EXPORTAR\"}";
            File.WriteAllText(rutaLocal, conSesion);
            var limpia = ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial)!;
            ConfiguracionServicioNube.Guardar(rutaLocal, limpia);
            using (var json = JsonDocument.Parse(File.ReadAllBytes(rutaLocal)))
                Exige(json.RootElement.EnumerateObject().Select(x => x.Name)
                    .OrderBy(x => x).SequenceEqual(new[] { "ClavePublicable", "Nombre", "Url" }),
                    "la configuración distribuible sólo contiene los tres datos públicos, nunca sesiones.");

            var anon = local with { ClavePublicable = Jwt("anon") };
            ConfiguracionServicioNube.Guardar(rutaLocal, anon);
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == anon,
                "la clave anon anterior sigue siendo compatible.");
            Exige(!Directory.EnumerateFiles(carpeta, "*.tmp", SearchOption.AllDirectories).Any(),
                "una escritura correcta no deja archivos temporales.");

            string destinoDirectorio = Path.Combine(carpeta, "no-reemplazar.json");
            Directory.CreateDirectory(destinoDirectorio);
            Rechaza(() => ConfiguracionServicioNube.Guardar(destinoDirectorio, oficial),
                "un fallo al reemplazar el destino debe propagarse.");
            Exige(Directory.Exists(destinoDirectorio)
                && !Directory.EnumerateFiles(carpeta, "*.tmp", SearchOption.AllDirectories).Any(),
                "una escritura fallida conserva el destino y limpia su temporal.");
            Exige(File.ReadAllBytes(rutaOficial).SequenceEqual(copiaOficial),
                "los guardados locales nunca modifican la conexión oficial.");
            var conServicio = local with { ServicioBasesUrl = "https://colaboracion.example" };
            ConfiguracionServicioNube.Guardar(rutaLocal, conServicio);
            Exige(ConfiguracionServicioNube.Cargar(rutaLocal, rutaOficial) == conServicio,
                "la dirección pública del servicio de obras se conserva sin sesiones ni secretos.");
            byte[] conServicioGuardado = File.ReadAllBytes(rutaLocal);
            foreach (string destinoInvalido in new[] { "http://colaboracion.example", "https://usuario:clave@colaboracion.example", "https://colaboracion.example?token=privado" })
            {
                Rechaza(() => ConfiguracionServicioNube.Guardar(rutaLocal,
                    conServicio with { ServicioBasesUrl = destinoInvalido }),
                    "la dirección del servicio debe ser HTTPS sin credenciales ni query.");
                Exige(File.ReadAllBytes(rutaLocal).SequenceEqual(conServicioGuardado),
                    "una dirección inválida no reemplaza la configuración del servicio existente.");
            }
            Console.WriteLine($"OK Configuración distribuida: {comprobaciones} comprobaciones de prioridad, validación, escritura y privacidad; sin red.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static string Jwt(string rol)
    {
        static string Base64(string texto) => Convert.ToBase64String(Encoding.UTF8.GetBytes(texto))
            .TrimEnd('=').Replace('+', '-').Replace('/', '_');
        return Base64("{\"alg\":\"HS256\"}") + "." + Base64(JsonSerializer.Serialize(new { role = rol })) + ".firma_sintetica";
    }
}
