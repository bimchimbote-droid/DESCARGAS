using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG.ServidorColaboracion;

/// <summary>Comprueba el adaptador real con HTTP simulado, sin credenciales ni destinos productivos.</summary>
internal static class RepositorioHttpCheck
{
    private const string Url = "https://servidor-qa.supabase.co";
    private const string Clave = "service_role_sintetica_no_productiva";
    private const string Token = "sesion_usuario_sintetica";
    private static readonly Guid Actor = Guid.Parse("236cefb9-64e7-493a-b817-724d79a6ec6a");
    private static readonly Guid Base = Guid.Parse("909f7792-55b1-4794-a521-ad20c7cbf555");
    private static readonly Guid Vista = Guid.Parse("3b415134-59c4-4fd1-b7a7-747c008e88aa");
    private static int casos, comprobaciones;

    internal static async Task<(int Casos, int Comprobaciones)> RunAsync()
    {
        casos = comprobaciones = 0;
        await Caso("Auth verifica sesión con credenciales separadas", Autenticacion);
        await Caso("Contexto exige cuatro permisos explícitos y conserva false", Contexto);
        await Caso("Descarga rechaza rutas y cuerpos truncados/excesivos", Descarga);
        await Caso("Subida duplicada verifica bytes antes de adoptar objeto", Subida);
        await Caso("Confirmación conserva UUID, revisión y paquetes", Confirmacion);
        await Caso("Errores remotos se clasifican sin divulgar cuerpos", Errores);
        Console.WriteLine($"REPOSITORIO_HTTP_APROBADO: {casos} casos, {comprobaciones} comprobaciones; HTTP simulado, sin red.");
        return (casos, comprobaciones);
    }

    private static async Task Caso(string nombre, Func<Task> accion)
    { await accion(); casos++; Console.WriteLine("OK Adaptador: " + nombre); }

    private static async Task Autenticacion()
    {
        using var t = new Transporte(); using var http = new HttpClient(t);
        var repo = new RepositorioSupabase(Url, Clave, http);
        t.Paso(HttpMethod.Get, "/auth/v1/user", q =>
        {
            Headers(q, Token);
            return Task.FromResult(Json(new { id = Actor }));
        });
        Exige(await repo.AutenticarAsync(Token, default) == Actor, "la identidad debe venir de Auth, no del cliente");
        await Rechaza(() => repo.AutenticarAsync("", default), 401);
        await Rechaza(() => repo.AutenticarAsync("token con espacio", default), 401);
        Exige(t.Peticiones == 1, "tokens inválidos deben rechazarse sin red");
        t.Paso(HttpMethod.Get, "/auth/v1/user", q =>
        {
            Headers(q, Token);
            var r = new HttpResponseMessage(HttpStatusCode.Redirect);
            r.Headers.Location = new Uri("https://ajeno.example/recibir-token");
            return Task.FromResult(r);
        });
        await Rechaza(() => repo.AutenticarAsync(Token, default), 401);
        Exige(t.Peticiones == 2, "una redirección no debe reenviar la sesión a otro destino");
        t.Completo();
    }

    private static async Task Contexto()
    {
        using var t = new Transporte(); using var http = new HttpClient(t);
        var repo = new RepositorioSupabase(Url, Clave, http);
        t.Paso(HttpMethod.Post, "/rest/v1/rpc/myg_base_contexto_servidor", async q =>
        {
            Headers(q, Clave);
            using var j = JsonDocument.Parse(await q.Content!.ReadAsStringAsync());
            Exige(j.RootElement.GetProperty("p_id").GetGuid() == Vista
                && j.RootElement.GetProperty("p_actor").GetGuid() == Actor
                && j.RootElement.GetProperty("p_revision").GetInt64() == 3,
                "el contexto debe conservar vista, identidad autenticada y revisión histórica");
            return Json(ContextoJson());
        });
        var c = await repo.ContextoAsync(Vista, Actor, 3, default);
        Exige(c.Vista == Vista && c.Base == Base && c.Revision == 3 && c.Documento == "OBRA-QA",
            "debe leer el contrato de contexto sin cambiar identidades");
        Exige(!c.Permisos.Acu && !c.Permisos.Especificaciones && !c.Permisos.MetradosExcel
            && c.Permisos.MetradosRevit && c.Permisos.MetradosRevitDisponible,
            "los tres false deben conservarse; no usar defaults permisivos");
        foreach (string mascara in new[]
        {
            "{\"acu\":false,\"especificaciones\":false,\"metrados_excel\":false}",
            "{\"acu\":false,\"especificaciones\":false,\"metrados_excel\":false,\"metrados_revit\":true,\"otro\":false}",
            "{\"acu\":false,\"especificaciones\":false,\"metrados_excel\":false,\"metrados_revit\":\"true\"}",
            "{\"acu\":false,\"acu\":true,\"especificaciones\":false,\"metrados_excel\":false,\"metrados_revit\":true}"
        })
        {
            var nodo = ContextoJson(); nodo["permisos_modulos"] = JsonNode.Parse(mascara);
            // Preservar el caso duplicado literalmente, sin normalizarlo con JsonNode.
            string cuerpo = mascara.Contains("\"acu\":false,\"acu\":true", StringComparison.Ordinal)
                ? ContextoJson().ToJsonString().Replace("\"permisos_modulos\":{\"acu\":false,\"especificaciones\":false,\"metrados_excel\":false,\"metrados_revit\":true}", "\"permisos_modulos\":" + mascara, StringComparison.Ordinal)
                : nodo.ToJsonString();
            t.Paso(HttpMethod.Post, "/rest/v1/rpc/myg_base_contexto_servidor", _ => Task.FromResult(JsonTexto(cuerpo)));
            await Rechaza(() => repo.ContextoAsync(Vista, Actor, null, default), 403);
        }
        t.Completo();
    }

    private static async Task Descarga()
    {
        using var t = new Transporte(); using var http = new HttpClient(t);
        var repo = new RepositorioSupabase(Url, Clave, http);
        byte[] bytes = Bytes(); var a = Archivo(bytes);
        string temporal = Path.Combine(Path.GetTempPath(), "myg-adapter-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temporal);
        try
        {
            await Rechaza(() => repo.DescargarAsync(a with { Ruta = "../privado.env" }, Path.Combine(temporal, "no-creado"), default), 502);
            Exige(t.Peticiones == 0 && !Directory.EnumerateFiles(temporal).Any(), "una ruta inválida no puede generar solicitud ni archivo");
            t.Paso(HttpMethod.Get, "/storage/v1/object/myg-nube-sqlite/" + a.Ruta, q =>
            { Headers(q, Clave); return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new SinLargo(bytes) }); });
            string buena = Path.Combine(temporal, "buena.sqlite");
            await repo.DescargarAsync(a, buena, default);
            Exige(File.ReadAllBytes(buena).SequenceEqual(bytes), "la descarga debe conservar los bytes completos");
            foreach (byte[] alterado in new[] { bytes[..^1], bytes.Concat(new byte[] { 7 }).ToArray() })
            {
                t.Paso(HttpMethod.Get, "/storage/v1/object/myg-nube-sqlite/" + a.Ruta,
                    _ => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new SinLargo(alterado) }));
                await Rechaza(() => repo.DescargarAsync(a, Path.Combine(temporal, Guid.NewGuid().ToString("N")), default), 502);
            }
            t.Completo();
        }
        finally { Directory.Delete(temporal, true); }
    }

    private static async Task Subida()
    {
        using var t = new Transporte(); using var http = new HttpClient(t);
        var repo = new RepositorioSupabase(Url, Clave, http);
        byte[] bytes = Bytes(); var a = Archivo(bytes);
        string ruta = Path.GetTempFileName(); File.WriteAllBytes(ruta, bytes);
        try
        {
            t.Paso(HttpMethod.Post, "/storage/v1/object/myg-nube-sqlite/" + a.Ruta, async q =>
            {
                Headers(q, Clave);
                Exige(q.Headers.GetValues("x-upsert").Single() == "false", "una subida no debe sobrescribir objetos existentes");
                Exige((await q.Content!.ReadAsByteArrayAsync()).SequenceEqual(bytes), "la subida debe transportar el snapshot completo");
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            });
            t.Paso(HttpMethod.Get, "/storage/v1/object/myg-nube-sqlite/" + a.Ruta,
                _ => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(bytes) }));
            await repo.SubirAsync(a, ruta, default);
            Exige(t.Peticiones == 2, "HTTP 400 solo se adopta después de descargar y verificar el objeto");
            byte[] diferente = bytes.ToArray(); diferente[^1] ^= 1;
            t.Paso(HttpMethod.Post, "/storage/v1/object/myg-nube-sqlite/" + a.Ruta,
                _ => Task.FromResult(new HttpResponseMessage(HttpStatusCode.Conflict)));
            t.Paso(HttpMethod.Get, "/storage/v1/object/myg-nube-sqlite/" + a.Ruta,
                _ => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(diferente) }));
            await Rechaza(() => repo.SubirAsync(a, ruta, default), 502);
            Exige(t.Peticiones == 4, "un objeto con hash diferente se rechaza sin sobrescribir ni reintentar");
            t.Completo();
        }
        finally { File.Delete(ruta); }
    }

    private static async Task Confirmacion()
    {
        using var t = new Transporte(); using var http = new HttpClient(t);
        var repo = new RepositorioSupabase(Url, Clave, http);
        Guid operacion = Guid.NewGuid(); var a = Archivo(Bytes());
        var anterior = JsonSerializer.SerializeToElement(new { texto = "Anterior sintético" });
        var nuevo = JsonSerializer.SerializeToElement(new { texto = "Nuevo sintético" });
        var cambio = new CambioBase(Vista, Actor, operacion, 3, a, anterior, nuevo, new string('b', 64));
        t.Paso(HttpMethod.Post, "/rest/v1/rpc/myg_base_confirmar_servidor", async q =>
        {
            Headers(q, Clave);
            using var j = JsonDocument.Parse(await q.Content!.ReadAsStringAsync()); var r = j.RootElement;
            Exige(r.GetProperty("p_id").GetGuid() == Vista && r.GetProperty("p_actor").GetGuid() == Actor
                && r.GetProperty("p_operacion").GetGuid() == operacion && r.GetProperty("p_revision").GetInt64() == 3,
                "CAS e idempotencia deben conservar las identidades y la revisión");
            Exige(r.GetProperty("p_ruta").GetString() == a.Ruta && r.GetProperty("p_sha256").GetString() == a.Sha256
                && r.GetProperty("p_bytes").GetInt64() == a.Bytes && r.GetProperty("p_solicitud_sha").GetString() == cambio.SolicitudSha,
                "la confirmación debe describir el snapshot subido y la huella del intento");
            Exige(r.GetProperty("p_anterior").GetRawText() == anterior.GetRawText()
                && r.GetProperty("p_nuevo").GetRawText() == nuevo.GetRawText(), "debe validar ambos paquetes reales en SQL");
            return Json(new { estado = "aplicada", revision = 4, operacion_id = operacion });
        });
        var respuesta = await repo.ConfirmarAsync(cambio, default);
        Exige(respuesta == new Confirmacion("aplicada", 4, operacion), "debe interpretar la confirmación real sin alterar el UUID");
        t.Completo();
    }

    private static async Task Errores()
    {
        using var t = new Transporte(); using var http = new HttpClient(t);
        var repo = new RepositorioSupabase(Url, Clave, http);
        foreach (var (codigo, estado) in new[] { ("42501", 403), ("22023", 400), ("55006", 409), ("40001", 409), ("XX000", 502) })
        {
            t.Paso(HttpMethod.Post, "/rest/v1/rpc/myg_base_contexto_servidor", _ => Task.FromResult(
                Json(new { code = codigo, message = "SECRETO-REMOTO-NO-DIVULGAR " + Clave }, HttpStatusCode.BadRequest)));
            try { await repo.ContextoAsync(Vista, Actor, null, default); throw new InvalidOperationException("Debía rechazarse el error remoto"); }
            catch (ErrorServicio error)
            {
                Exige(error.Estado == estado, "debe clasificar SQLSTATE " + codigo + " como HTTP " + estado);
                Exige(!error.Message.Contains(Clave, StringComparison.Ordinal)
                    && !error.Message.Contains("SECRETO-REMOTO", StringComparison.Ordinal), "no debe divulgar el cuerpo remoto ni la credencial");
            }
        }
        t.Completo();
    }

    private static JsonObject ContextoJson() => JsonSerializer.SerializeToNode(new
    {
        proyecto = new { id = Vista, codigo = "VISTA-QA", nombre = "Obra QA", rol = "editor", revision = 3, alcance = "obra", vista_base = true },
        base_id = Base, documento_id = "OBRA-QA", propietario = Actor, revision = 3, rol = "editor",
        permisos_modulos = new { acu = false, especificaciones = false, metrados_excel = false, metrados_revit = true },
        archivo_sqlite = Archivo(Bytes())
    })!.AsObject().ConArchivo();

    private static JsonObject ConArchivo(this JsonObject nodo)
    {
        var a = Archivo(Bytes()); nodo["archivo_sqlite"] = JsonSerializer.SerializeToNode(new { ruta = a.Ruta, sha256 = a.Sha256, bytes = a.Bytes });
        return nodo;
    }
    private static byte[] Bytes() => Enumerable.Range(0, 512).Select(n => (byte)(n % 251)).ToArray();
    private static ArchivoBase Archivo(byte[] bytes)
    {
        string hash = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        return new(Actor.ToString("D") + "/" + Base.ToString("N") + "/" + hash + ".sqlite", hash, bytes.Length);
    }
    private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => JsonTexto(JsonSerializer.Serialize(valor), estado);
    private static HttpResponseMessage JsonTexto(string texto, HttpStatusCode estado = HttpStatusCode.OK) => new(estado) { Content = new StringContent(texto, Encoding.UTF8, "application/json") };
    private static void Headers(HttpRequestMessage q, string bearer)
    {
        Exige(q.RequestUri?.Scheme == "https" && q.RequestUri.Host == "servidor-qa.supabase.co", "las credenciales solo se envían al proyecto configurado");
        Exige(q.Headers.Authorization?.Scheme == "Bearer" && q.Headers.Authorization.Parameter == bearer
            && q.Headers.GetValues("apikey").Single() == Clave, "la sesión y la credencial de servidor deben ocupar sus cabeceras correctas");
    }
    private static async Task Rechaza(Func<Task> accion, int estado)
    {
        try { await accion(); }
        catch (ErrorServicio error) { Exige(error.Estado == estado, "HTTP esperado " + estado + ", recibido " + error.Estado); return; }
        throw new InvalidOperationException("La operación debía ser rechazada");
    }
    private static void Exige(bool condicion, string mensaje)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException(mensaje); }

    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<(HttpMethod Metodo, string Ruta, Func<HttpRequestMessage, Task<HttpResponseMessage>> Responder)> pasos = new();
        internal int Peticiones;
        internal void Paso(HttpMethod metodo, string ruta, Func<HttpRequestMessage, Task<HttpResponseMessage>> responder) => pasos.Enqueue((metodo, ruta, responder));
        internal void Completo() => Exige(pasos.Count == 0, "se deben ejecutar todas las solicitudes previstas");
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Peticiones++;
            if (!pasos.TryDequeue(out var paso)) throw new InvalidOperationException("Solicitud HTTP inesperada");
            Exige(request.Method == paso.Metodo && request.RequestUri?.PathAndQuery == paso.Ruta, "método o ruta HTTP incorrectos");
            return paso.Responder(request);
        }
    }
    private sealed class SinLargo(byte[] bytes) : HttpContent
    {
        protected override bool TryComputeLength(out long length) { length = 0; return false; }
        protected override Task SerializeToStreamAsync(Stream stream, TransportContext? context) => stream.WriteAsync(bytes).AsTask();
    }
}
