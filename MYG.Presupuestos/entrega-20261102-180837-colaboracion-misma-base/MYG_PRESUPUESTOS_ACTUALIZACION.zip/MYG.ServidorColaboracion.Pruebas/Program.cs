using System.Security.Cryptography;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG.ServidorColaboracion;
using MYG_2027;

internal static class PruebasMotor
{
    private static int casos, comprobaciones;

    public static async Task<int> Main()
    {
        try
        {
            await Caso("GET proyecta una sola obra y no escribe", Lectura);
            await Caso("Autorreferencias portables no exponen temporales y sobreviven guardar/replay", AutorreferenciasPortables);
            await Caso("Cliente y sincronizador reales guardan mediante el motor en la misma base", IntegracionClienteSincronizador);
            await Caso("Guardar actualiza la misma base y conserva la otra obra", Guardado);
            await Caso("Permisos y rol lector deniegan guardados", Permisos);
            await Caso("Cambiar identidad o agregar otra obra se rechaza", Identidad);
            await Caso("CAS y replay no duplican subidas ni revisiones", Idempotencia);
            await Caso("Revocación durante guardado evita confirmación", Revocacion);
            await Caso("Revocación durante GET no entrega contenido", RevocacionLectura);
            await Caso("Cambios de permiso y CAS antes de subir evitan objetos nuevos", CarreraAntesDeSubir);
            await Caso("Filas nativas de otra obra y contenido mal formado se rechazan", InyeccionTablas);
            await Caso("Cancelación durante descarga limpia el temporal", Cancelacion);
            await Caso("SQLite alterado se rechaza y limpia temporales", Integridad);
            await Caso("Referencia a un archivo privado del servidor no se abre", Referencias);
            await Caso("Error de confirmación no altera la revisión autoritativa", FalloConfirmacion);
            var adaptador = await RepositorioHttpCheck.RunAsync();
            Console.WriteLine($"ADAPTADOR_SUPABASE_APROBADO: {adaptador.Casos} casos, {adaptador.Comprobaciones} comprobaciones HTTP simuladas.");
            Console.WriteLine($"SERVIDOR_MISMA_BASE_APROBADO: {casos} casos, {comprobaciones} comprobaciones, SQLite real y repositorio simulado; sin red.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            return 1;
        }
    }

    private static async Task Caso(string nombre, Func<Task> accion)
    { await accion(); casos++; Console.WriteLine("OK " + nombre); }

    private static async Task Lectura()
    {
        using var e = new Entorno();
        string hash = Hash(e.Repo.BytesActuales);
        var r = await e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor);
        var contenido = r.GetProperty("contenido");
        Exige(r.GetProperty("vista_base").GetBoolean() && r.GetProperty("base_id").GetGuid() == e.Repo.Base, "el resultado debe conservar la referencia de la base original");
        Exige(PaqueteNube.LeerDocumento(contenido).Id == e.Repo.Obra && contenido.GetProperty("documentos").GetArrayLength() == 1, "solo debe entregarse el documento autorizado");
        Exige(!r.GetRawText().Contains(Entorno.SecretoObra, StringComparison.Ordinal), "el paquete filtró datos únicos de la otra obra");
        Exige(!r.TryGetProperty("archivo_sqlite", out _) && !r.GetRawText().Contains(e.Repo.ArchivoActual.Ruta, StringComparison.Ordinal), "no debe entregar el archivo ni su ruta en Storage");
        Exige(e.Repo.Subidas == 0 && e.Repo.Confirmaciones == 0 && e.Repo.Revision == 1 && Hash(e.Repo.BytesActuales) == hash, "leer no debe generar objetos, confirmaciones ni cambios de bytes");
        e.ExigirLimpieza();
    }

    private static async Task Guardado()
    {
        using var e = new Entorno();
        var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 37.25m);
        string firmaPrivada = e.FirmaOtra();
        var r = await e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud);
        Exige(r.GetProperty("estado").GetString() == "aplicada" && r.GetProperty("revision").GetInt64() == 2, "debe confirmar una sola revisión nueva");
        Exige(e.Repo.Revision == 2 && e.Repo.Subidas == 1 && e.Repo.Confirmaciones == 1, "el guardado debe subir/confirmar una sola base");
        Exige(e.LeerActual(e.Repo.Obra).Presupuestos[0].Items[0].Costos.Cantidad == 37.25m, "la cantidad editada debe estar dentro del SQLite autoritativo");
        Exige(e.FirmaOtra() == firmaPrivada && e.ObrasActuales().Count == 2, "la otra obra y ambas identidades deben conservarse");
        Exige(e.Repo.UltimoCambio!.Archivo.Ruta.Split('/')[1] == e.Repo.Base.ToString("N") && e.Repo.Publicaciones == 1, "no debe crear una publicación ni identidad de base diferente");
        Exige(!r.GetRawText().Contains(Entorno.SecretoObra, StringComparison.Ordinal), "la confirmación no debe filtrar otra obra");
        e.ExigirLimpieza();
    }

    private static async Task AutorreferenciasPortables()
    {
        using var e = new Entorno(referenciasPropias: true);
        string hashOriginal = Hash(e.Repo.BytesActuales);
        var lectura = await e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor);
        ExigirSinRutasServidor(lectura, e.Temporales);
        var paquete = lectura.GetProperty("contenido");
        var campos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        int referencias = ExigirReferenciasPropias(paquete, campos);
        Exige(referencias >= 6 && campos.SetEquals(new[] { "RutaSQLite", "FuenteCatalogoRuta", "CatalogoMYGRuta" }),
            "el paquete de prueba debe ejercer las tres clases de autorreferencia y no solo campos vacíos");
        int referenciasTablas = 0;
        foreach (var tabla in paquete.GetProperty("tablas").EnumerateArray())
        {
            var columnas = tabla.GetProperty("Columnas").EnumerateArray().Select(c => c.GetString()!).ToArray();
            foreach (var fila in tabla.GetProperty("Filas").EnumerateArray())
                for (int i = 0; i < columnas.Length; i++)
                    if (columnas[i].StartsWith("json_", StringComparison.OrdinalIgnoreCase)
                        && fila[i].GetProperty("Tipo").GetString() == "texto"
                        && fila[i].GetProperty("Valor").ValueKind == JsonValueKind.String)
                    {
                        using var interno = JsonDocument.Parse(fila[i].GetProperty("Valor").GetString()!);
                        referenciasTablas += ExigirReferenciasPropias(interno.RootElement, new(StringComparer.OrdinalIgnoreCase));
                    }
        }
        Exige(referenciasTablas > 0, "el test debe comprobar autorreferencias dentro de JSON serializado en tablas nativas");
        Exige(Hash(e.Repo.BytesActuales) == hashOriginal && e.Repo.Subidas == 0,
            "sanitizar la respuesta GET no debe cambiar bytes ni subir la base");

        string cliente = Path.Combine(e.Carpeta, "obra-cliente.sqlite");
        PaqueteNube.Descargar(paquete, cliente);
        var doc = MYGBaseDatos.LeerProyecto(cliente, e.Repo.Obra);
        Exige(doc.FuenteCatalogo?.RutaSQLite == Path.GetFullPath(cliente),
            "el cliente debe reubicar el alias propio en su archivo local, sin una ruta del servidor");
        doc.Presupuestos[0].Items[0].Costos.Cantidad = 82.5m;
        MYGProyectoStorage.Guardar(cliente, doc);
        var intencion = PaqueteNube.CrearContenido(doc, cliente, "obra", compacto: false);
        var solicitud = new SolicitudGuardar(Guid.NewGuid(), 1, intencion);
        string otra = e.FirmaOtra();
        var respuesta = await e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud);
        ExigirSinRutasServidor(respuesta, e.Temporales);
        Exige(respuesta.GetProperty("estado").GetString() == "aplicada"
            && e.LeerActual(e.Repo.Obra).Presupuestos[0].Items[0].Costos.Cantidad == 82.5m,
            "guardar desde una proyección portable debe conservar y aplicar la edición de la misma obra");
        Exige(PaqueteNube.FirmaDatosCompartidos(respuesta.GetProperty("contenido")) == PaqueteNube.FirmaDatosCompartidos(intencion),
            "la normalización de rutas no debe cambiar la firma de los datos ni perder la intención del cliente");
        Exige(e.FirmaOtra() == otra && e.Repo.Subidas == 1 && e.Repo.Publicaciones == 1,
            "el roundtrip portable debe preservar la obra privada y usar solo una publicación de base");
        var replay = await e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud);
        ExigirSinRutasServidor(replay, e.Temporales);
        Exige(replay.GetRawText() == respuesta.GetRawText() && e.Repo.Subidas == 1 && e.Repo.Revision == 2,
            "el ACK perdido debe ser estable sin rutas variables del temporal ni duplicar subidas");
        e.ExigirLimpieza();
    }

    private static void ExigirSinRutasServidor(JsonElement respuesta, string raizTemporal)
    {
        string texto = respuesta.GetRawText();
        Exige(!texto.Contains(raizTemporal, StringComparison.Ordinal) && !texto.Contains("/tmp/", StringComparison.Ordinal),
            "la respuesta no debe exponer rutas físicas del servidor ni de los temporales internos de PaqueteNube");
    }

    private static async Task IntegracionClienteSincronizador()
    {
        using var e = new Entorno(referenciasPropias: true);
        using var transporte = new TransporteIntegrado(e);
        using var cliente = new ClienteSupabase(TransporteIntegrado.Supabase,
            "sb_publishable_integracion_sintetica", transporte) { ServicioBasesUrl = TransporteIntegrado.Servicio };
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        var remoto = await cliente.AbrirProyectoAsync(e.Repo.Vista);
        Exige(remoto.EsObraMismaBase && remoto.BaseId == e.Repo.Base && remoto.DocumentoId == e.Repo.Obra,
            "el cliente debe identificar la vista real y conservar la identidad de la misma base");
        ExigirSinRutasServidor(remoto.Contenido, e.Temporales);
        string local = Path.Combine(e.Carpeta, "cliente-sincronizador.sqlite");
        PaqueteNube.Descargar(remoto.Contenido, local);
        var documento = MYGBaseDatos.LeerProyecto(local, e.Repo.Obra);
        MYGColaboracionLocal.Vincular(local, documento, new MYGVinculoNube
        {
            ProyectoId = remoto.Id, Servidor = cliente.UrlServidor, UsuarioId = cliente.UsuarioId,
            Revision = remoto.Revision, Rol = remoto.Rol, PermisosModulos = remoto.PermisosModulos!.Copiar(),
            JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento),
            JsonPaqueteConfirmado = remoto.Contenido.GetRawText()
        });
        string privada = e.FirmaOtra();
        var vinculo = MYGColaboracionLocal.Leer(local, documento.Id)!;
        documento.Presupuestos[0].Items[0].Costos.Cantidad = 64.75m;
        MYGColaboracionLocal.Guardar(local, documento, vinculo);
        Exige(MYGColaboracionLocal.Leer(local, documento.Id)!.Pendiente is not null,
            "la edición debe crear una operación durable antes de enviarse");
        var resultado = await SincronizadorProyectoNube.EjecutarAsync(cliente, local, documento);
        Exige(resultado.Vinculo.Revision == 2 && resultado.Vinculo.Pendiente is null
            && resultado.Vinculo.Estado == "Sincronizado",
            "el sincronizador real debe adoptar el ACK y cerrar su cola sin generar otra edición por las rutas");
        Exige(e.Repo.Revision == 2 && e.Repo.Subidas == 1 && e.Repo.Publicaciones == 1,
            "el flujo de escritorio debe modificar solo una revisión de la misma base");
        ExigirSinRutasServidor(e.Repo.UltimoCambio!.Anterior, e.Temporales);
        ExigirSinRutasServidor(e.Repo.UltimoCambio.Nuevo, e.Temporales);
        Exige(e.LeerActual(e.Repo.Obra).Presupuestos[0].Items[0].Costos.Cantidad == 64.75m
            && e.FirmaOtra() == privada && e.ObrasActuales().Count == 2,
            "la sincronización real debe guardar la cantidad y conservar la otra obra privada");
        Exige(MYGBaseDatos.ListarProyectos(local).Count == 1
            && File.ReadAllBytes(local).AsSpan().IndexOf(Encoding.UTF8.GetBytes(Entorno.SecretoObra)) < 0,
            "la copia de trabajo del colaborador debe contener únicamente la obra autorizada");
        Exige(transporte.Guardados == 1 && transporte.Lecturas >= 2 && transporte.LegadoOStorage == 0,
            "cliente y sincronizador deben usar el servicio de la obra sin publicar ni descargar el SQLite completo");
        var lecturaFinal = await SincronizadorProyectoNube.EjecutarAsync(cliente, local, resultado.Documento, soloLeer: true);
        Exige(lecturaFinal.Vinculo.Pendiente is null && e.Repo.Subidas == 1 && e.Repo.Revision == 2,
            "releer después del ACK no debe producir otra operación ni subir snapshots por una diferencia de autorreferencias");
        e.Repo.Revocado = true;
        try { await cliente.AbrirProyectoAsync(e.Repo.Vista); }
        catch (NubeException error) when (error.AccesoDenegado)
        {
            Exige(e.Repo.Subidas == 1 && transporte.LegadoOStorage == 0,
                "la revocación real debe llegar al cliente como acceso denegado sin fallback ni nuevas subidas");
            e.ExigirLimpieza();
            return;
        }
        throw new InvalidOperationException("Una membresía revocada no debe entregar otra proyección al cliente.");
    }

    private sealed class TransporteIntegrado(Entorno entorno) : HttpMessageHandler
    {
        public const string Supabase = "https://integracion-qa.supabase.co";
        public const string Servicio = "https://servicio-integracion.example";
        private const string Acceso = "acceso_integracion_sintetico";
        public int Guardados, Lecturas, LegadoOStorage;

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            var destino = solicitud.RequestUri!;
            if (destino.Host == new Uri(Supabase).Host && solicitud.Method == HttpMethod.Post
                && destino.PathAndQuery == "/auth/v1/token?grant_type=password")
                return Json(new { access_token = Acceso, refresh_token = "refresco_integracion", expires_in = 3600, user = new { id = entorno.Repo.Actor } });
            if (destino.Host == new Uri(Servicio).Host && solicitud.Method == HttpMethod.Get && destino.AbsolutePath == "/health")
            {
                Exige(solicitud.Headers.Authorization is null && !solicitud.Headers.Contains("apikey"),
                    "health debe consultarse sin enviar credenciales antes de confiar en el servicio");
                return Json(new { servicio = "MYG_BASES", version = 1, supabase_url = Supabase });
            }
            if (solicitud.Headers.Authorization?.ToString() != "Bearer " + Acceso)
                throw new InvalidOperationException("El contrato integrado requiere la sesión del colaborador autenticado.");
            if (destino.Host == new Uri(Supabase).Host && solicitud.Method == HttpMethod.Post
                && destino.AbsolutePath == "/rest/v1/rpc/myg_base_resolver")
            {
                using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(ct));
                Exige(cuerpo.RootElement.GetProperty("p_id").GetGuid() == entorno.Repo.Vista,
                    "el resolver solo debe solicitar la identidad de la vista autorizada");
                var contexto = await entorno.Repo.ContextoAsync(entorno.Repo.Vista, entorno.Repo.Actor, null, ct);
                return Json(contexto.Proyecto);
            }
            if (destino.Host == new Uri(Servicio).Host && destino.AbsolutePath == "/obras/" + entorno.Repo.Vista.ToString("D")
                && solicitud.Method == HttpMethod.Get)
            {
                Lecturas++;
                return await ResponderMotor(() => entorno.Motor.AbrirAsync(entorno.Repo.Vista, entorno.Repo.Actor, ct));
            }
            if (destino.Host == new Uri(Servicio).Host && destino.AbsolutePath == "/obras/" + entorno.Repo.Vista.ToString("D") + "/guardar"
                && solicitud.Method == HttpMethod.Post)
            {
                Guardados++;
                string texto = await solicitud.Content!.ReadAsStringAsync(ct);
                Exige(!texto.Contains(Entorno.SecretoObra, StringComparison.Ordinal),
                    "el cliente no debe reenviar datos de otra obra en su solicitud");
                var cambio = JsonSerializer.Deserialize<SolicitudGuardar>(texto, new JsonSerializerOptions { MaxDepth = 128 })!;
                return await ResponderMotor(() => entorno.Motor.GuardarAsync(entorno.Repo.Vista, entorno.Repo.Actor, cambio, ct));
            }
            LegadoOStorage++;
            throw new InvalidOperationException("El flujo integrado intentó una ruta ajena al servicio de obra: " + destino.AbsolutePath);
        }

        private static HttpResponseMessage Json(object valor) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(valor, new JsonSerializerOptions { MaxDepth = 128 }), Encoding.UTF8, "application/json") };

        private static async Task<HttpResponseMessage> ResponderMotor(Func<Task<JsonElement>> accion)
        {
            try { return Json(await accion()); }
            catch (ErrorServicio error)
            {
                var respuesta = Json(new { codigo = error.Codigo, mensaje = error.Message });
                respuesta.StatusCode = (HttpStatusCode)error.Estado;
                return respuesta;
            }
        }
    }

    private static int ExigirReferenciasPropias(JsonElement valor, HashSet<string> campos)
    {
        int cantidad = 0;
        if (valor.ValueKind == JsonValueKind.Object)
            foreach (var campo in valor.EnumerateObject())
            {
                bool referencia = campo.Name.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase)
                    || campo.Name.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase)
                    || campo.Name.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase);
                if (referencia && campo.Value.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(campo.Value.GetString()))
                {
                    Exige(campo.Value.GetString() == ArchivoPublicacionSqlitePendiente.ReferenciaPropia,
                        "toda autorreferencia no vacía debe usar exclusivamente el alias portable");
                    campos.Add(campo.Name); cantidad++;
                }
                else cantidad += ExigirReferenciasPropias(campo.Value, campos);
            }
        else if (valor.ValueKind == JsonValueKind.Array)
            foreach (var hijo in valor.EnumerateArray()) cantidad += ExigirReferenciasPropias(hijo, campos);
        return cantidad;
    }

    private static async Task Permisos()
    {
        using (var e = new Entorno())
        {
            var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.PrecioDirecto = 999m);
            e.Repo.Permisos.Acu = false;
            await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud), 403);
            Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 1, "ACU sin permiso no debe subir snapshot");
            e.ExigirLimpieza();
        }
        using (var e = new Entorno())
        {
            var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 101m);
            e.Repo.Rol = "lector";
            await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud), 403);
            Exige(e.Repo.Subidas == 0 && e.Repo.Descargas == 0, "un lector se rechaza antes de descargar o subir la base");
            var lectura = await e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor);
            Exige(lectura.GetProperty("rol").GetString() == "lector", "el lector autorizado debe seguir consultando solo su obra");
            e.ExigirLimpieza();
        }
    }

    private static async Task Identidad()
    {
        using var e = new Entorno();
        var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 20m);
        var nodo = JsonNode.Parse(solicitud.Contenido.GetRawText())!.AsObject();
        nodo["documento"]!["Id"] = e.Repo.OtraObra;
        await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud with { Contenido = JsonSerializer.SerializeToElement(nodo) }), 400);
        nodo = JsonNode.Parse(solicitud.Contenido.GetRawText())!.AsObject();
        nodo["documentos"]!.AsArray().Add(JsonSerializer.SerializeToNode(e.LeerActual(e.Repo.OtraObra)));
        await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud with { Contenido = JsonSerializer.SerializeToElement(nodo) }), 400);
        await Rechaza(() => e.Motor.AbrirAsync(Guid.NewGuid(), e.Repo.Actor), 403);
        await Rechaza(() => e.Motor.AbrirAsync(e.Repo.Vista, Guid.NewGuid()), 403);
        Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 1, "identidades ajenas no deben alterar ni subir datos");
        e.ExigirLimpieza();
    }

    private static async Task Idempotencia()
    {
        using (var e = new Entorno())
        {
            var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 2m);
            var primera = await e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud);
            var repetida = await e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud);
            Exige(primera.GetRawText() == repetida.GetRawText(), "un ACK perdido debe recuperar exactamente la confirmación original");
            Exige(e.Repo.Revision == 2 && e.Repo.Subidas == 1 && e.Repo.Operaciones.Count == 1, "repetir UUID/cuerpo no debe duplicar snapshot ni revisión");
            var cambiada = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 5m) with { OperacionId = solicitud.OperacionId, Revision = 1 };
            await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, cambiada), 400);
            Exige(e.Repo.Revision == 2 && e.Repo.Subidas == 1, "el mismo UUID con contenido distinto debe rechazarse sin subida");
            e.Repo.Permisos.Acu = false;
            await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud), 403);
            e.ExigirLimpieza();
        }
        using (var e = new Entorno())
        {
            var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 7m);
            e.Repo.AvanzarSinCambios();
            var r = await e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud);
            Exige(r.GetProperty("estado").GetString() == "conflicto" && r.GetProperty("revision").GetInt64() == 2, "una revisión obsoleta debe devolver conflicto sobre la base vigente");
            Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 2, "un CAS obsoleto no necesita subir ningún snapshot");
            e.ExigirLimpieza();
        }
    }

    private static async Task Revocacion()
    {
        using var e = new Entorno();
        var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 13m);
        e.Repo.AlSubir = () => e.Repo.Revocado = true;
        await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud), 403);
        Exige(e.Repo.Revision == 1 && e.Repo.Subidas == 1 && e.Repo.Operaciones.Count == 0, "una revocación durante el procesamiento debe impedir confirmar la base");
        await Rechaza(() => e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor), 403);
        e.ExigirLimpieza();
    }

    private static async Task Integridad()
    {
        using var e = new Entorno();
        e.Repo.CorromperDescarga = true;
        await Rechaza(() => e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor), 502);
        Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 1, "un hash incorrecto debe rechazarse sin cambios");
        e.ExigirLimpieza();
    }

    private static async Task RevocacionLectura()
    {
        using var e = new Entorno();
        e.Repo.AlDescargar = () => e.Repo.Revocado = true;
        await Rechaza(() => e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor), 403);
        Exige(e.Repo.Descargas == 1 && e.Repo.Subidas == 0 && e.Repo.Confirmaciones == 0,
            "la revocación durante descarga debe impedir devolver la obra sin escribir datos");
        e.ExigirLimpieza();
    }

    private static async Task CarreraAntesDeSubir()
    {
        using (var e = new Entorno())
        {
            var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.PrecioDirecto = 777m);
            e.Repo.AlConsultarContexto = numero => { if (numero == 2) e.Repo.Permisos.Acu = false; };
            await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud), 403);
            Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 1,
                "un permiso retirado durante el cálculo debe impedir incluso la subida del snapshot");
            e.ExigirLimpieza();
        }
        using (var e = new Entorno())
        {
            var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 45m);
            e.Repo.AlConsultarContexto = numero => { if (numero == 2) e.Repo.AvanzarSinCambios(); };
            var respuesta = await e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud);
            Exige(respuesta.GetProperty("estado").GetString() == "conflicto"
                && respuesta.GetProperty("revision").GetInt64() == 2,
                "una revisión que cambió durante el cálculo debe devolver conflicto de la misma base");
            Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 2,
                "el CAS ya observable debe resolverse antes de subir otro snapshot");
            Exige(e.LeerActual(e.Repo.Obra).Presupuestos[0].Items[0].Costos.Cantidad == 12m,
                "el conflicto no debe aplicar los cambios pendientes del colaborador");
            e.ExigirLimpieza();
        }
    }

    private static async Task InyeccionTablas()
    {
        using var e = new Entorno();
        var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 21m);
        var propia = JsonNode.Parse(solicitud.Contenido.GetRawText())!.AsObject();
        var ajena = JsonNode.Parse(e.PaqueteActual(e.Repo.OtraObra).GetRawText())!.AsObject();
        var tablaAjena = ajena["tablas"]!.AsArray().Single(t => t!["Nombre"]!.GetValue<string>() == "proyecto")!;
        var tablaPropia = propia["tablas"]!.AsArray().Single(t => t!["Nombre"]!.GetValue<string>() == "proyecto")!;
        foreach (var fila in tablaAjena["Filas"]!.AsArray()) tablaPropia["Filas"]!.AsArray().Add(fila!.DeepClone());
        string hash = Hash(e.Repo.BytesActuales);
        await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor,
            solicitud with { Contenido = JsonSerializer.SerializeToElement(propia) }), 400);
        using var vacio = JsonDocument.Parse("{}");
        await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor,
            solicitud with { Contenido = vacio.RootElement.Clone() }), 400);
        Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 1 && Hash(e.Repo.BytesActuales) == hash,
            "datos ajenos o solicitudes mal formadas no deben modificar ni subir la base");
        e.ExigirLimpieza();
    }

    private static async Task Cancelacion()
    {
        using var e = new Entorno();
        using var cancelacion = new CancellationTokenSource();
        e.Repo.AlDescargar = cancelacion.Cancel;
        try { await e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor, cancelacion.Token); }
        catch (OperationCanceledException)
        {
            Exige(e.Repo.Subidas == 0 && e.Repo.Confirmaciones == 0 && e.Repo.Revision == 1,
                "cancelar una lectura no debe subir ni confirmar modificaciones");
            e.ExigirLimpieza();
            return;
        }
        throw new InvalidOperationException("La lectura cancelada no debe devolver contenido.");
    }

    private static async Task Referencias()
    {
        using var e = new Entorno();
        string secreto = Path.Combine(e.Carpeta, "credencial-servidor.txt");
        File.WriteAllText(secreto, "SECRETO-SERVIDOR-QUE-NUNCA-DEBE-LEERSE");
        e.MutarActual(d => d.Presupuestos[0].Items[0].Costos.Metrados.Add(
            new MYGLineaMetrado { Descripcion = "Referencia externa QA", ImagenRuta = secreto }));
        await Rechaza(() => e.Motor.AbrirAsync(e.Repo.Vista, e.Repo.Actor), 400);
        Exige(e.Repo.Subidas == 0 && e.Repo.Revision == 1, "una referencia externa no debe producir paquete ni nueva revisión");
        Exige(File.ReadAllText(secreto) == "SECRETO-SERVIDOR-QUE-NUNCA-DEBE-LEERSE", "el archivo externo debe quedar intacto");
        e.ExigirLimpieza();
    }

    private static async Task FalloConfirmacion()
    {
        using var e = new Entorno();
        var solicitud = e.Cambio(d => d.Presupuestos[0].Items[0].Costos.Cantidad = 999m);
        string hash = Hash(e.Repo.BytesActuales);
        e.Repo.FallarConfirmacion = true;
        await Rechaza(() => e.Motor.GuardarAsync(e.Repo.Vista, e.Repo.Actor, solicitud), 502);
        Exige(e.Repo.Subidas == 1 && e.Repo.Revision == 1 && Hash(e.Repo.BytesActuales) == hash,
            "una subida sin confirmación no debe sustituir la base autoritativa");
        Exige(e.Repo.Operaciones.Count == 0 && e.Repo.Publicaciones == 1, "un fallo no debe inventar confirmaciones o publicaciones de obra");
        e.ExigirLimpieza();
    }

    private static async Task Rechaza(Func<Task> accion, int estado)
    {
        try { await accion(); }
        catch (ErrorServicio e) { Exige(e.Estado == estado, "estado esperado " + estado + ", recibido " + e.Estado + ": " + e.Codigo); return; }
        throw new InvalidOperationException("La operación debía rechazarse con HTTP " + estado);
    }

    private static void Exige(bool condicion, string mensaje)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException(mensaje); }
    private static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();

    private sealed class Entorno : IDisposable
    {
        public const string SecretoObra = "OTRA-OBRA-PRIVADA-638219";
        public string Carpeta { get; } = Path.Combine(Path.GetTempPath(), "MYG-Motor-QA-" + Guid.NewGuid().ToString("N"));
        public string Temporales => Path.Combine(Carpeta, "procesamiento");
        public RepositorioFalso Repo { get; }
        public MotorColaboracionBase Motor { get; }
        public Entorno(bool referenciasPropias = false)
        {
            Directory.CreateDirectory(Carpeta);
            string origen = Path.Combine(Carpeta, "original.sqlite");
            var propia = CrearObra("OBRA-AUTORIZADA-QA", 12m, 15.31m);
            var otra = CrearObra(SecretoObra, 638219.61m, 917283.42m);
            if (referenciasPropias)
            {
                propia.FuenteCatalogo = new MYGFuenteDelphin { Id = "CATALOGO-PROPIO-QA", RutaSQLite = origen };
                propia.Presupuestos[0].Items[0].FuenteCatalogoRuta = origen;
                propia.Presupuestos[0].Items[0].Costos.CatalogoMYGRuta = origen;
                propia.Presupuestos[0].Costos.Insumos.Add(new MYGInsumo
                {
                    Id = "INSUMO-PRESUPUESTO-QA", Codigo = "INS-QA", Descripcion = "Insumo propio QA", Unidad = "und", Precio = 4.5m,
                    CatalogoMYGId = "CATALOGO-INSUMO-QA", CatalogoMYGRuta = origen
                });
            }
            MYGProyectoStorage.Guardar(origen, propia);
            MYGProyectoStorage.Guardar(origen, otra);
            if (referenciasPropias)
            {
                var insumoCatalogo = new MYGInsumo
                {
                    Id = "CATALOGO-INSUMO-QA", Codigo = "INS-QA", Descripcion = "Insumo propio QA", Unidad = "und", Precio = 4.5m,
                    CatalogoMYGId = "CATALOGO-INSUMO-QA", CatalogoMYGRuta = origen
                };
                using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = origen, Pooling = false }.ToString());
                c.Open(); using var q = c.CreateCommand();
                q.CommandText = "INSERT INTO catalogo_insumo(id,codigo,descripcion,unidad,grupo,precio,json_datos,revision,modificado_utc) VALUES($id,'INS-QA','Insumo propio QA','und','Materiales','4.5',$json,1,$fecha)";
                q.Parameters.AddWithValue("$id", insumoCatalogo.Id);
                q.Parameters.AddWithValue("$json", JsonSerializer.Serialize(insumoCatalogo));
                q.Parameters.AddWithValue("$fecha", DateTime.UtcNow.ToString("O"));
                q.ExecuteNonQuery();
            }
            string canonica = Path.Combine(Carpeta, "canonica.sqlite");
            CopiaSqliteNube.CrearSnapshot(origen, canonica);
            ArchivoPublicacionSqlitePendiente.NormalizarCopiaPortable(canonica, origen);
            Repo = new RepositorioFalso(File.ReadAllBytes(canonica), propia.Id, otra.Id);
            Motor = new MotorColaboracionBase(Repo, Temporales);
        }
        public SolicitudGuardar Cambio(Action<MYGProyectoDocumento> editar)
        {
            string local = Path.Combine(Carpeta, "cliente-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.WriteAllBytes(local, Repo.BytesActuales);
            var d = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(local, Repo.Obra);
            editar(d); MYGProyectoStorage.Guardar(local, d);
            return new(Guid.NewGuid(), Repo.Revision, PaqueteNube.CrearContenido(d, local, "obra", compacto: false));
        }
        public MYGProyectoDocumento LeerActual(string documento)
        {
            string p = Path.Combine(Carpeta, "lectura-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.WriteAllBytes(p, Repo.BytesActuales);
            return ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(p, documento);
        }
        public JsonElement PaqueteActual(string documento)
        {
            string p = Path.Combine(Carpeta, "paquete-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.WriteAllBytes(p, Repo.BytesActuales);
            var d = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(p, documento);
            return PaqueteNube.CrearContenido(d, p, "obra", compacto: false);
        }
        public string FirmaOtra()
        {
            var d = LeerActual(Repo.OtraObra);
            return MYGProyectoStorage.Firma(d);
        }
        public IReadOnlyList<MYGProyectoResumen> ObrasActuales()
        {
            string p = Path.Combine(Carpeta, "lista-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.WriteAllBytes(p, Repo.BytesActuales); return MYGBaseDatos.ListarProyectos(p);
        }
        public void MutarActual(Action<MYGProyectoDocumento> editar)
        {
            string p = Path.Combine(Carpeta, "mutar.sqlite"); File.WriteAllBytes(p, Repo.BytesActuales);
            var d = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(p, Repo.Obra); editar(d); MYGProyectoStorage.Guardar(p, d);
            Repo.ReemplazarRevisionActual(File.ReadAllBytes(p));
        }
        public void ExigirLimpieza() => Exige(!Directory.Exists(Temporales) || !Directory.EnumerateFileSystemEntries(Temporales).Any(), "deben limpiarse los temporales de cada operación");
        public void Dispose() { SqliteConnection.ClearAllPools(); Directory.Delete(Carpeta, true); }
        private static MYGProyectoDocumento CrearObra(string nombre, decimal cantidad, decimal precio)
        {
            var d = MYGProyectoStorage.Nuevo(nombre, "PRESUPUESTO " + nombre);
            string id = MYGProyectoStorage.NuevoId();
            d.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, IdPropuesta = id, TipoPropuesta = "PARTIDA", Posicion = 1,
                Descripcion = "PARTIDA " + nombre, Unidad = "m³", Origen = "MODELO", Estado = "PROPUESTA",
                Costos = new MYGDatosPartida { Cantidad = cantidad, PrecioDirecto = precio }
            }); return d;
        }
    }

    private sealed class RepositorioFalso : IRepositorioBase
    {
        public Guid Vista { get; } = Guid.Parse("c47b4fae-4a97-441a-b917-d900f19d6b4f");
        public Guid Base { get; } = Guid.Parse("4dd06ff9-393b-487f-91b8-0af5db4ea275");
        public Guid Actor { get; } = Guid.Parse("423fd03a-d74f-419f-b2c6-38a594e1c1fa");
        public string Obra { get; }
        public string OtraObra { get; }
        public long Revision { get; private set; } = 1;
        public string Rol { get; set; } = "editor";
        public MYGPermisosModulos Permisos { get; } = new() { Acu = true, Especificaciones = true, MetradosExcel = true, MetradosRevit = true, MetradosRevitDisponible = true };
        public bool Revocado, CorromperDescarga, FallarConfirmacion;
        public Action? AlSubir;
        public Action? AlDescargar;
        public Action<int>? AlConsultarContexto;
        public int ConsultasContexto;
        public int Subidas, Descargas, Confirmaciones;
        public int Publicaciones => 1;
        public CambioBase? UltimoCambio;
        public Dictionary<Guid, (string Fingerprint, Confirmacion Respuesta, MYGPermisosModulos Flags)> Operaciones { get; } = new();
        private readonly Dictionary<string, byte[]> objetos = new(StringComparer.Ordinal);
        private readonly Dictionary<long, ArchivoBase> revisiones = new();
        public ArchivoBase ArchivoActual => revisiones[Revision];
        public byte[] BytesActuales => objetos[ArchivoActual.Ruta];
        public RepositorioFalso(byte[] bytes, string obra, string otra)
        { Obra = obra; OtraObra = otra; ReemplazarRevisionActual(bytes); }
        public void ReemplazarRevisionActual(byte[] bytes)
        {
            string hash = Hash(bytes); var a = new ArchivoBase(Actor.ToString("D") + "/" + Base.ToString("N") + "/" + hash + ".sqlite", hash, bytes.Length);
            objetos[a.Ruta] = bytes.ToArray(); revisiones[Revision] = a;
        }
        public void AvanzarSinCambios() { var a = ArchivoActual; Revision++; revisiones[Revision] = a; }
        public Task<Guid> AutenticarAsync(string bearer, CancellationToken ct) => Task.FromResult(Actor);
        public Task<ContextoBase> ContextoAsync(Guid vista, Guid actor, long? revision, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested(); AlConsultarContexto?.Invoke(++ConsultasContexto); Validar(vista, actor);
            long r = revision ?? Revision;
            if (!revisiones.TryGetValue(r, out var archivo)) throw new ErrorServicio(403, "QA_REVISION", "Revisión no disponible");
            var meta = JsonSerializer.SerializeToElement(new
            {
                id = Vista, codigo = "VISTA-QA", nombre = "OBRA-AUTORIZADA-QA", rol = Rol, revision = r,
                alcance = "obra", vista_base = true, base_id = Base, documento_id = Obra, permisos_modulos = Permisos
            });
            return Task.FromResult(new ContextoBase(Vista, Base, Obra, Actor, r, Rol, Permisos.Copiar(), archivo, meta));
        }
        public Task DescargarAsync(ArchivoBase archivo, string destino, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested(); Descargas++;
            byte[] bytes = objetos[archivo.Ruta].ToArray(); if (CorromperDescarga) bytes[^1] ^= 0x7f;
            File.WriteAllBytes(destino, bytes); AlDescargar?.Invoke(); return Task.CompletedTask;
        }
        public Task SubirAsync(ArchivoBase archivo, string fuente, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested(); Subidas++;
            Exige(archivo.Ruta.Split('/')[1] == Base.ToString("N"), "el upload debe pertenecer a la misma base");
            var bytes = File.ReadAllBytes(fuente); Exige(Hash(bytes) == archivo.Sha256 && bytes.Length == archivo.Bytes, "el upload debe describir sus bytes reales");
            objetos[archivo.Ruta] = bytes; AlSubir?.Invoke(); return Task.CompletedTask;
        }
        public Task<Confirmacion> ConfirmarAsync(CambioBase cambio, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested(); Confirmaciones++; Validar(cambio.Vista, cambio.Actor);
            if (Rol is not ("propietario" or "administrador" or "editor")) throw Denegado();
            if (FallarConfirmacion) throw new ErrorServicio(502, "QA_FALLO_CONFIRMACION", "Fallo sintético de confirmación");
            if (Operaciones.TryGetValue(cambio.Operacion, out var previa))
            {
                if (previa.Fingerprint != cambio.SolicitudSha) throw new ErrorServicio(400, "QA_UUID_DISTINTO", "UUID usado con otro cuerpo");
                if (previa.Flags.Acu && !Permisos.Acu || previa.Flags.Especificaciones && !Permisos.Especificaciones
                    || previa.Flags.MetradosExcel && !Permisos.MetradosExcel || previa.Flags.MetradosRevit && !Permisos.MetradosRevit) throw Denegado();
                return Task.FromResult(previa.Respuesta);
            }
            if (cambio.Revision != Revision) return Task.FromResult(new Confirmacion("conflicto", Revision, cambio.Operacion));
            Exige(objetos.ContainsKey(cambio.Archivo.Ruta), "solo puede confirmar un snapshot ya subido");
            UltimoCambio = cambio; Revision++; revisiones[Revision] = cambio.Archivo;
            var respuesta = new Confirmacion("aplicada", Revision, cambio.Operacion);
            Operaciones.Add(cambio.Operacion, (cambio.SolicitudSha, respuesta, Permisos.Copiar()));
            return Task.FromResult(respuesta);
        }
        private void Validar(Guid vista, Guid actor) { if (Revocado || vista != Vista || actor != Actor) throw Denegado(); }
        private static ErrorServicio Denegado() => new(403, "QA_ACCESO_DENEGADO", "Acceso revocado o ajeno");
    }
}
