# Pruebas de interfaz en Windows

Estas comprobaciones necesitan Windows y el SDK .NET 10.0.100. Desde la raíz del repositorio:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Se abren y cierran automáticamente los diálogos de prueba. Se verifica que la unidad de una partida (`und`, `m²` o una unidad propia) sobreviva al mostrar el formulario y renovar su `BindingContext`, y que elegir otra unidad funcione.

También se ejercita el mismo punto de aplicación del arrastre por IDs: el mensaje debe mostrar origen y destino, Enter y Escape deben cancelar, rechazar o cerrar no debe modificar el documento ni agregar historial, y aceptar debe aplicar el movimiento una sola vez. No necesita conexión a Revit ni simula OLE.

Se comprueban ambas paletas, colores opacos y la conservación de textos, opciones, contenido RTF y una edición pendiente al alternar. Estas pruebas no guardan ni cambian la preferencia de apariencia del usuario.

El tamaño de texto se comprueba desde el menú real de Inicio: se seleccionan 85 %, 115 % y 100 % varias veces, se cancela y se vuelve a abrir el menú, y se cierra la ventana con el menú abierto. Se verifica que no aparezcan excepciones, que la escala no se acumule y que el menú se libere junto con su botón. El archivo de preferencia de tamaño se restaura al terminar.

También se abre el selector de insumos del ACU con códigos heredados en conflicto: consultar o cancelar no debe registrar otros insumos ni modificar el catálogo. La cinta de Metrado Xls se abre y recorre con texto al 85 %, 115 % y 100 %, verificando que sus ventanas se estabilicen y que se conserven fórmulas, formatos e historial.

En Linux se puede compilar con `dotnet build MYG.PruebasUI/MYG.PruebasUI.csproj -c Release`; la ejecución requiere el runtime Windows Desktop.
