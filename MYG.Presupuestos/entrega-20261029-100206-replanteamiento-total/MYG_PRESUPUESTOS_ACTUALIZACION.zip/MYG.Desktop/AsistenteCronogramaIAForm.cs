using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Intercambio manual con la IA elegida por el usuario. La ventana
/// trabaja con copias; sólo devuelve un cronograma al aceptar la revisión.</summary>
internal sealed class MYGAsistenteCronogramaIAForm : Form
{
    private const int LimiteArchivo = 8 * 1024 * 1024;
    private readonly Func<MYGProyectoDocumento> obtenerProyecto;
    private readonly Func<MYGCronograma> obtenerPlan;
    private readonly Func<bool> puedeEditar;
    private readonly MYGProyectoDocumento proyecto;
    private readonly MYGCronograma plan;
    private readonly string origenSQLite;
    private readonly bool fechasDelProyecto;
    private readonly DateTimePicker inicio;
    private readonly NumericUpDown plazo = new() { Name = "cronograma_ia_plazo", Minimum = 1, Maximum = 36500, Value = 180, Width = 95 };
    private readonly Label fin = new() { Name = "cronograma_ia_fin", AutoSize = true, Anchor = AnchorStyles.Left };
    private readonly CheckBox recalcular = new() { Name = "cronograma_ia_recalcular", Text = "Calcular duraciones desde metrado, rendimiento y cuadrillas", Checked = true, AutoSize = true };
    private readonly CheckBox reprogramar = new() { Name = "cronograma_ia_reprogramar", Text = "Permitir reprogramar tareas manuales o importadas", AutoSize = true };
    private readonly CheckBox replantearTodas = new() { Name = "cronograma_ia_replantear_todas", Text = "Replantear todas las tareas elegibles (exigir respuesta completa)", Checked = true, AutoSize = true };
    private readonly TextBox contexto = new() { Name = "cronograma_ia_contexto", Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Vertical, MaxLength = 12000, PlaceholderText = "Sectores, frentes, cuadrillas y equipos disponibles, hitos, suministros, curados y restricciones que la IA debe respetar…" };
    private readonly DataGridView datos = Tabla("cronograma_ia_datos");
    private readonly DataGridView cambios = Tabla("cronograma_ia_cambios");
    private readonly MYGCronogramaGanttControl gantt = new() { Name = "cronograma_ia_gantt" };
    private readonly TextBox avisos = new() { Name = "cronograma_ia_avisos", Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, AccessibleName = "Resultado y advertencias de la propuesta IA" };
    private readonly Label estado = new() { Name = "cronograma_ia_estado", Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly Button aplicar = new() { Name = "cronograma_ia_aplicar", Text = "Aplicar seleccionadas", AutoSize = true, MinimumSize = new Size(155, 32), Enabled = false };
    private readonly Button copiarPrompt;
    private readonly TabControl pestanas = new() { Name = "cronograma_ia_pestanas", Dock = DockStyle.Fill };
    private readonly HashSet<string> seleccion = new(StringComparer.Ordinal);
    private List<MYGCambioCronogramaIA> propuestas = new();
    private MYGPaqueteCronogramaIA paquete;
    private MYGVistaPreviaCronogramaIA vista;
    private string respuesta;
    private bool cargando;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal MYGCronograma Valor { get; private set; }
    internal MYGPaqueteCronogramaIA Paquete => AsegurarPaquete();
    internal bool PuedeAplicar => fechasDelProyecto && puedeEditar?.Invoke() == true && vista?.CumplePlazo == true && seleccion.Count > 0 &&
        (paquete?.Opciones.ReplantearTodasLasTareas != true || seleccion.Count == propuestas.Count);

    internal MYGAsistenteCronogramaIAForm(Func<MYGProyectoDocumento> obtenerProyecto,
        Func<MYGCronograma> obtenerPlan, Func<bool> puedeEditar, string origenSQLite = null)
    {
        this.obtenerProyecto = obtenerProyecto ?? throw new ArgumentNullException(nameof(obtenerProyecto));
        this.obtenerPlan = obtenerPlan ?? throw new ArgumentNullException(nameof(obtenerPlan));
        this.puedeEditar = puedeEditar;
        this.origenSQLite = origenSQLite;
        proyecto = MYGProyectoStorage.Copia(obtenerProyecto()) ?? throw new InvalidOperationException("No hay proyecto disponible.");
        plan = MYGProyectoStorage.Copia(obtenerPlan()) ?? throw new InvalidOperationException("No hay cronograma disponible.");
        MYGCronogramaDialogoUI.Preparar(this, "cronograma_ia_dialogo", "Asistente IA para cronograma", new Size(1180, 850), redimensionable: true);
        MinimumSize = new Size(900, 720);
        inicio = MYGCronogramaDialogoUI.Fecha("cronograma_ia_inicio", proyecto.Datos?.FechaInicio ?? plan.FechaInicio);
        inicio.Width = 135;
        if (proyecto.Datos?.FechaInicio is DateTime desde && desde != default &&
            proyecto.Datos.FechaFin is DateTime hasta && hasta.Date >= desde.Date)
        {
            plazo.Value = Math.Clamp((hasta.Date - desde.Date).Days + 1, 1, 36500);
            fechasDelProyecto = true;
            inicio.Enabled = false;
            plazo.Enabled = false;
        }

        var cuerpo = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 7, Padding = new Padding(12) };
        cuerpo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        foreach (int alto in new[] { 52, 148 }) cuerpo.RowStyles.Add(new RowStyle(SizeType.Absolute, alto));
        cuerpo.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        foreach (int alto in new[] { 52, 82, 52, 45 }) cuerpo.RowStyles.Add(new RowStyle(SizeType.Absolute, alto));
        cuerpo.Controls.Add(new Label
        {
            Dock = DockStyle.Fill, Text = "1. Exporte los datos y adjúntelos a la IA con las reglas constructivas del prompt.  2. Importe su respuesta JSON.  3. Revise frentes, vínculos, duraciones y cuadrillas.\nLa propuesta debe comenzar y terminar exactamente en las fechas del proyecto para poder aplicarse. No se envían datos automáticamente.",
            AutoEllipsis = true
        }, 0, 0);
        cuerpo.Controls.Add(CrearOpciones(), 0, 1);
        CrearPestanas(); cuerpo.Controls.Add(pestanas, 0, 2);
        var acciones = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = true, AutoScroll = true, Margin = new Padding(0), Padding = new Padding(0, 6, 0, 0) };
        Accion(acciones, "Revisar datos", "revisar", RevisarDatos);
        Accion(acciones, "Exportar presupuesto + ACU", "exportar", ExportarDatos);
        copiarPrompt = Accion(acciones, "Copiar prompt", "prompt", () => { Clipboard.SetText(CrearPromptParaIA()); estado.Text = EstadoCobertura() + Environment.NewLine + "Prompt copiado. Adjunte también el archivo de datos exportado a la IA."; });
        copiarPrompt.Enabled = false;
        Accion(acciones, "Abrir paquete exportado…", "abrir_paquete", AbrirPaquete);
        Accion(acciones, "Importar propuesta JSON…", "importar", ImportarPropuesta);
        cuerpo.Controls.Add(acciones, 0, 3); cuerpo.Controls.Add(avisos, 0, 4); cuerpo.Controls.Add(estado, 0, 5);
        var pie = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Margin = new Padding(0), Padding = new Padding(0, 5, 0, 0) };
        var cerrar = new Button { Name = "cronograma_ia_cerrar", Text = "Cerrar sin aplicar", AutoSize = true, MinimumSize = new Size(125, 32), DialogResult = DialogResult.Cancel };
        pie.Controls.Add(cerrar); pie.Controls.Add(aplicar); cuerpo.Controls.Add(pie, 0, 6); Controls.Add(cuerpo);
        CancelButton = cerrar;
        // Enter en una tabla o al copiar el prompt nunca aplica una propuesta.
        aplicar.Click += (_, _) => Intentar(AplicarSeleccion);
        inicio.ValueChanged += (_, _) => InvalidarOpciones(); plazo.ValueChanged += (_, _) => InvalidarOpciones();
        recalcular.CheckedChanged += (_, _) => InvalidarOpciones(); reprogramar.CheckedChanged += (_, _) => InvalidarOpciones();
        replantearTodas.CheckedChanged += (_, _) => InvalidarOpciones();
        contexto.TextChanged += (_, _) => InvalidarOpciones();
        cambios.CurrentCellDirtyStateChanged += (_, _) => { if (cambios.IsCurrentCellDirty) cambios.CommitEdit(DataGridViewDataErrorContexts.Commit); };
        cambios.CellValueChanged += (_, e) =>
        {
            if (cargando || e.RowIndex < 0 || e.ColumnIndex != cambios.Columns["SELECCION"].Index) return;
            string id = (string)cambios.Rows[e.RowIndex].Tag;
            if (cambios.Rows[e.RowIndex].Cells["SELECCION"].Value is true) seleccion.Add(id); else seleccion.Remove(id);
            Intentar(RecalcularPrevia);
        };
        cambios.SelectionChanged += (_, _) => { if (cambios.CurrentRow?.Tag is string id) gantt.Seleccionar(new[] { id }); };
        gantt.AccessibleDescription = "Vista previa. Las barras no modifican el cronograma. Se muestran todos los vínculos, incluidos los de tareas no seleccionadas. Clic derecho en el Gantt permite filtrar los vínculos de seleccionadas u ocultarlos.";
        MYGCronogramaDialogoUI.Tema(this);
        void Tema(object sender, EventArgs e) => AplicarTemaTablas();
        MYG2027_TemaComercial.CambioTema += Tema;
        Disposed += (_, _) => MYG2027_TemaComercial.CambioTema -= Tema;
        AplicarTemaTablas();
        Intentar(RevisarDatos);
    }

    private Control CrearOpciones()
    {
        var opciones = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Margin = new Padding(0) };
        opciones.RowStyles.Add(new RowStyle(SizeType.Absolute, 37));
        opciones.RowStyles.Add(new RowStyle(SizeType.Absolute, 31));
        opciones.RowStyles.Add(new RowStyle(SizeType.Absolute, 31));
        opciones.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var fechas = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, AutoScroll = true, Margin = new Padding(0) };
        fechas.Controls.Add(new Label { Text = "Inicio", AutoSize = true, Margin = new Padding(0, 7, 6, 3) }); fechas.Controls.Add(inicio);
        fechas.Controls.Add(new Label { Text = "Plazo en días calendario", AutoSize = true, Margin = new Padding(16, 7, 6, 3) }); fechas.Controls.Add(plazo);
        fin.Margin = new Padding(16, 7, 0, 3); fechas.Controls.Add(fin); opciones.Controls.Add(fechas, 0, 0);
        var casillas = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, AutoScroll = true, Margin = new Padding(0) };
        casillas.Controls.Add(recalcular); reprogramar.Margin = new Padding(18, 3, 0, 3); casillas.Controls.Add(reprogramar); opciones.Controls.Add(casillas, 0, 1);
        var cobertura = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, AutoScroll = true, Margin = new Padding(0) };
        cobertura.Controls.Add(replantearTodas); opciones.Controls.Add(cobertura, 0, 2);
        opciones.Controls.Add(new Label
        {
            Name = "cronograma_ia_regla_fechas", Dock = DockStyle.Fill, AutoEllipsis = true,
            Text = (fechasDelProyecto ? "Inicio y fin fijados por la ficha: para cambiarlos, edite Datos del proyecto. " : "Puede simular fechas; para aplicar, registre inicio y fin en Datos del proyecto. ") +
                "El fin es inclusivo y debe coincidir exactamente. Las tareas manuales/importadas autorizadas pasan a automáticas; avance y restricciones se conservan."
        }, 0, 3);
        return opciones;
    }

    private void CrearPestanas()
    {
        var datosPagina = new TabPage("1. Datos para IA") { Padding = new Padding(6) };
        var datosContenido = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
        datosContenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 24)); datosContenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 76)); datosContenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        datosContenido.Controls.Add(new Label { Dock = DockStyle.Fill, Text = "Contexto de planificación y recursos disponibles (opcional, se incluye en la exportación):" }, 0, 0);
        datosContenido.Controls.Add(contexto, 0, 1); datosContenido.Controls.Add(datos, 0, 2); datosPagina.Controls.Add(datosContenido);
        Columna(datos, "NUMERO", "ID", 45); Columna(datos, "NOMBRE", "Tarea", 285); Columna(datos, "METRADO", "Metrado", 85);
        Columna(datos, "RENDIMIENTO", "Rendimiento/día", 105); Columna(datos, "CUADRILLAS", "Cuadrillas", 75);
        Columna(datos, "ACTUAL", "Días actuales", 85); Columna(datos, "PROPUESTA", "Días desde ACU", 95); Columna(datos, "ESTADO", "Revisión de datos", 300);
        var cambiosPagina = new TabPage("2. Revisar propuesta") { Padding = new Padding(6) };
        cambios.Columns.Add(new DataGridViewCheckBoxColumn { Name = "SELECCION", HeaderText = "Aplicar", Width = 52, ReadOnly = false });
        Columna(cambios, "NOMBRE", "Tarea", 250); Columna(cambios, "ANTES", "Predecesoras actuales", 145); Columna(cambios, "DESPUES", "Predecesoras seleccionadas", 165);
        Columna(cambios, "DURACION", "Duración actual → nueva", 130); Columna(cambios, "CUADRILLAS", "Cuadrillas actuales → nuevas", 155);
        Columna(cambios, "INICIO", "Inicio resultante", 105); Columna(cambios, "FIN", "Fin resultante", 105);
        Columna(cambios, "MOTIVO", "Justificación de la IA", 270); cambiosPagina.Controls.Add(cambios);
        var ganttPagina = new TabPage("3. Gantt resultante") { Padding = new Padding(6) };
        ganttPagina.Controls.Add(gantt); ganttPagina.Controls.Add(gantt.Cabecera);
        pestanas.TabPages.AddRange(new[] { datosPagina, cambiosPagina, ganttPagina });
        pestanas.SelectedIndexChanged += (_, _) => { if (pestanas.SelectedIndex == 2 && vista != null) gantt.AjustarProyecto(); };
    }

    private static DataGridView Tabla(string nombre) => new()
    {
        Name = nombre, Dock = DockStyle.Fill, AutoGenerateColumns = false, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, AllowUserToResizeRows = false, RowHeadersVisible = false,
        AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        MultiSelect = false, EditMode = DataGridViewEditMode.EditOnEnter
    };
    private static void Columna(DataGridView tabla, string nombre, string titulo, int ancho) => tabla.Columns.Add(new DataGridViewTextBoxColumn
    { Name = nombre, HeaderText = titulo, Width = ancho, ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable });
    private Button Accion(FlowLayoutPanel padre, string texto, string nombre, Action accion)
    {
        var boton = new Button { Name = "cronograma_ia_" + nombre, Text = texto, AutoSize = true, MinimumSize = new Size(90, 32) };
        boton.Click += (_, _) => Intentar(accion); padre.Controls.Add(boton);
        return boton;
    }

    private MYGOpcionesCronogramaIA Opciones() => new()
    {
        FechaInicio = inicio.Value.Date, PlazoDiasCalendario = (int)plazo.Value, Contexto = contexto.Text,
        RecalcularDuraciones = recalcular.Checked, ReprogramarManualesEImportadas = reprogramar.Checked,
        ReplantearTodasLasTareas = replantearTodas.Checked
    };
    private void InvalidarOpciones()
    {
        if (cargando) return;
        paquete = null; LimpiarPropuesta(); datos.Rows.Clear();
        copiarPrompt.Enabled = false;
        Intentar(ActualizarFin);
        estado.Text = "Opciones cambiadas: revise y genere datos y prompt nuevos antes de pedir otra propuesta.";
        avisos.Text = "Pulse Revisar datos, exporte un NUEVO archivo de datos y copie un NUEVO prompt. " +
            "El paquete y la respuesta anteriores ya no corresponden a estas opciones. Solicite una respuesta nueva a la IA. " +
            "Cambiar esta casilla u otras opciones sólo prepara la revisión: las tareas originales permanecen intactas hasta Aplicar.";
    }
    private void ActualizarFin()
    {
        DateTime objetivo;
        try { objetivo = inicio.Value.Date.AddDays((int)plazo.Value - 1); }
        catch (ArgumentOutOfRangeException) { throw new InvalidOperationException("El plazo excede la fecha máxima admitida."); }
        fin.Text = "Fin objetivo: " + objetivo.ToString("dd/MM/yyyy") + " (inclusivo)";
    }
    private MYGPaqueteCronogramaIA AsegurarPaquete()
    {
        if (paquete == null) RevisarDatos();
        return paquete;
    }
    private void RevisarDatos()
    {
        ActualizarFin();
        var nuevo = MYGAsistenteCronogramaIA.CrearPaquete(proyecto, plan, Opciones());
        paquete = nuevo; LimpiarPropuesta(); MostrarDatos();
        MostrarEstadoPaquete();
    }
    private void MostrarEstadoPaquete(string prefijo = "")
    {
        int editables = paquete.Tareas.Count(t => t.Editable);
        copiarPrompt.Enabled = editables > 0;
        avisos.Text = string.Join(Environment.NewLine, paquete.Advertencias.Concat(paquete.DiagnosticoRedActual));
        if (editables > 0)
        {
            estado.Text = prefijo + EstadoCobertura() + Environment.NewLine +
                (fechasDelProyecto ? "Exporte un solo JSON con presupuesto, ACU y calendario." :
                    "Aplicar bloqueado: registre inicio y fin en Datos del proyecto antes de aplicar una propuesta.");
            return;
        }
        estado.Text = prefijo + EstadoCobertura() + Environment.NewLine + "0 tareas admiten propuesta. Copiar prompt está deshabilitado; revise el recuadro de avisos.";
        bool manualesOImportadas = paquete.Tareas.Any(t => !t.EsResumen &&
            (t.ModoActual == MYGModoTarea.Manual.ToString() || t.FechasImportadas));
        string accion = manualesOImportadas && !paquete.Opciones.ReprogramarManualesEImportadas
            ? "Si desea que la IA proponga una nueva secuencia para las tareas manuales o importadas, marque explícitamente «Permitir reprogramar tareas manuales o importadas». " +
                "Hágalo sólo si acepta revisar sus nuevas fechas: las tareas seleccionadas pasarán a automáticas al aplicar. "
            : "Revise la columna Revisión de datos: las tareas con avance, partes, restricciones especiales, hitos o resúmenes mantienen su protección. " +
                "Este paquete puede exportarse como referencia, pero no permite solicitar una propuesta aplicable. ";
        avisos.Text = "NO HAY TAREAS EDITABLES PARA LA IA. " + accion +
            "Después de ajustar las opciones pulse Revisar datos, exporte un NUEVO archivo de datos y copie un NUEVO prompt. " +
            "Solicite otra respuesta a la IA con esos archivos nuevos; el paquete y la respuesta anteriores no sirven tras el cambio. " +
            "No se cambian los modos ni los vínculos originales durante esta revisión." + Environment.NewLine + Environment.NewLine + avisos.Text;
    }
    private string EstadoCobertura()
    {
        int elegibles = paquete.Tareas.Count(t => t.Editable);
        int protegidas = paquete.Tareas.Count(t => !t.EsResumen && !t.Editable);
        int resumenes = paquete.Tareas.Count(t => t.EsResumen);
        return (paquete.Opciones.ReplantearTodasLasTareas
            ? $"Cobertura requerida: {elegibles} elegibles; recibidas: {propuestas.Count}; seleccionadas: {seleccion.Count}. "
            : $"Modo parcial: {elegibles} elegibles; recibidas: {propuestas.Count}; seleccionadas: {seleccion.Count}. ") +
            $"Protegidas: {protegidas}; resúmenes: {resumenes}.";
    }
    private void MostrarDatos()
    {
        cargando = true;
        try
        {
            datos.Rows.Clear();
            foreach (var tarea in paquete.Tareas)
            {
                string revision = tarea.EsResumen ? "Resumen calculado" : tarea.Editable
                    ? "Revisar rendimiento y cuadrillas antes de exportar" : tarea.MotivoProteccion;
                if (tarea.Advertencias.Count > 0) revision += ". " + string.Join(" ", tarea.Advertencias);
                datos.Rows.Add(tarea.Numero, tarea.Codigo + " " + tarea.Nombre, tarea.Metrado?.ToString("0.####") ?? "—",
                    tarea.RendimientoDiario?.ToString("0.####") ?? "—", tarea.NumeroCuadrillas.ToString("0.##"), tarea.DuracionActual,
                    tarea.DuracionPropuesta?.ToString() ?? "Se conserva", revision);
            }
        }
        finally { cargando = false; }
    }
    internal string CrearDatosParaIA() => MYGAsistenteCronogramaIA.SerializarPaquete(AsegurarPaquete());
    internal string CrearPromptParaIA() => MYGAsistenteCronogramaIA.CrearPrompt(AsegurarPaquete());

    internal void CargarPaquete(string json)
    {
        LimpiarPropuesta();
        var nuevo = MYGAsistenteCronogramaIA.LeerPaquete(proyecto, plan, json);
        cargando = true;
        try
        {
            inicio.Value = nuevo.Opciones.FechaInicio;
            plazo.Value = nuevo.Opciones.PlazoDiasCalendario;
            recalcular.Checked = nuevo.Opciones.RecalcularDuraciones;
            reprogramar.Checked = nuevo.Opciones.ReprogramarManualesEImportadas;
            replantearTodas.Checked = nuevo.Opciones.ReplantearTodasLasTareas;
            contexto.Text = nuevo.Opciones.Contexto ?? "";
            paquete = nuevo;
        }
        finally { cargando = false; }
        ActualizarFin(); LimpiarPropuesta(); MostrarDatos();
        MostrarEstadoPaquete("Paquete recuperado. ");
    }
    internal void CargarPropuesta(string json)
    {
        var origen = AsegurarPaquete();
        LimpiarPropuesta();
        MYGVistaPreviaCronogramaIA nuevaVista;
        try { nuevaVista = MYGAsistenteCronogramaIA.PrepararPropuesta(proyecto, plan, origen, json); }
        catch (InvalidDataException ex)
        {
            string mensaje = ex.Message.Length > 2000 ? ex.Message[..2000] + "…" : ex.Message;
            estado.Text = EstadoCobertura() + Environment.NewLine + "Propuesta rechazada. Aplicar bloqueado: " + mensaje;
            avisos.Text = mensaje;
            throw;
        }
        respuesta = json; propuestas = nuevaVista.Cambios.ToList();
        foreach (var cambio in propuestas) seleccion.Add(cambio.TareaId);
        MostrarCambios(nuevaVista); vista = nuevaVista; MostrarPrevia(); pestanas.SelectedIndex = 1;
    }
    internal void SeleccionarTareas(IEnumerable<string> ids)
    {
        if (respuesta == null) throw new InvalidOperationException("Importe primero una propuesta de IA.");
        var elegidas = (ids ?? throw new ArgumentNullException(nameof(ids))).ToArray();
        if (elegidas.Distinct(StringComparer.Ordinal).Count() != elegidas.Length || elegidas.Any(id => propuestas.All(p => p.TareaId != id)))
            throw new InvalidOperationException("La selección contiene una tarea inexistente o repetida.");
        seleccion.Clear(); foreach (string id in elegidas) seleccion.Add(id);
        RecalcularPrevia();
    }
    private void RecalcularPrevia()
    {
        vista = null; aplicar.Enabled = false;
        if (respuesta == null) return;
        vista = MYGAsistenteCronogramaIA.PrepararPropuesta(proyecto, plan, paquete, respuesta, seleccion);
        MostrarCambios(vista); MostrarPrevia();
    }
    private void MostrarCambios(MYGVistaPreviaCronogramaIA previa)
    {
        string elegida = cambios.CurrentRow?.Tag as string;
        int columnaActual = cambios.CurrentCell?.ColumnIndex ?? 1;
        bool reconstruir = cambios.Rows.Count != propuestas.Count || cambios.Rows.Cast<DataGridViewRow>()
            .Select(r => r.Tag as string).Where((id, indice) => id != propuestas[indice].TareaId).Any();
        var filas = previa.Resultado.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        var origen = MYGMotorCronograma.Calcular(plan).Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        cargando = true;
        try
        {
            // El cambio de una casilla llega durante CommitEdit. Conservar las
            // filas y celdas evita destruir la celda que está confirmándose y
            // mantiene su foco; sólo una propuesta nueva reconstruye la tabla.
            if (reconstruir) cambios.Rows.Clear();
            for (int indice = 0; indice < propuestas.Count; indice++)
            {
                var cambio = propuestas[indice];
                var fila = filas[cambio.TareaId]; var anterior = origen[cambio.TareaId];
                object[] valores = { seleccion.Contains(cambio.TareaId), cambio.Nombre, cambio.PredecesorasAntes,
                    MYGMotorCronograma.FormatoPredecesoras(fila.Tarea, previa.Resultado.Filas),
                    anterior.DuracionDias + " → " + fila.DuracionDias,
                    anterior.Tarea.NumeroCuadrillas.ToString("0.####") + " → " + fila.Tarea.NumeroCuadrillas.ToString("0.####"),
                    fila.Inicio.ToString("dd/MM/yyyy"), fila.Fin.ToString("dd/MM/yyyy"), cambio.Justificacion };
                if (reconstruir)
                {
                    int n = cambios.Rows.Add(valores);
                    cambios.Rows[n].Tag = cambio.TareaId;
                }
                else
                {
                    var actual = cambios.Rows[indice];
                    for (int columna = 0; columna < valores.Length; columna++)
                        if (!Equals(actual.Cells[columna].Value, valores[columna])) actual.Cells[columna].Value = valores[columna];
                }
            }
            if (reconstruir)
            {
                var actual = cambios.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => (string)r.Tag == elegida);
                if (actual != null) cambios.CurrentCell = actual.Cells[columnaActual];
            }
        }
        finally { cargando = false; }
    }
    private void MostrarPrevia()
    {
        gantt.Cargar(vista.Resultado.Filas, vista.Plan.Calendario, vista.Plan.FechaEstado, paquete.Opciones.FechaInicio, paquete.FinObjetivo);
        // La selección inicial de la tabla puede notificarse antes de asignar el Tag.
        gantt.Seleccionar(cambios.CurrentRow?.Tag is string id ? new[] { id } : Array.Empty<string>());
        avisos.Text = string.Join(Environment.NewLine, vista.Advertencias);
        var bloqueos = new List<string>();
        if (!fechasDelProyecto) bloqueos.Add("registre inicio y fin en Datos del proyecto");
        if (!vista.CumplePlazo) bloqueos.Add("no coincide con el inicio y fin del proyecto; revise la propuesta y las cuadrillas");
        if (paquete.Opciones.ReplantearTodasLasTareas && seleccion.Count != propuestas.Count)
            bloqueos.Add($"faltan {propuestas.Count - seleccion.Count} tareas por seleccionar; el replanteamiento completo exige aplicar todas las elegibles");
        else if (seleccion.Count == 0) bloqueos.Add("seleccione al menos una tarea");
        if (puedeEditar?.Invoke() != true) bloqueos.Add("sesión de sólo lectura");
        estado.Text = EstadoCobertura() + Environment.NewLine +
            $"Inicio: {vista.Resultado.Inicio:dd/MM/yyyy}; fin: {vista.Resultado.Fin:dd/MM/yyyy}. " +
            (bloqueos.Count > 0 ? "Aplicar bloqueado: " + string.Join("; ", bloqueos) + "." :
                "Coincide con ambas fechas objetivo. Puede aplicar y luego usar Deshacer.");
        aplicar.Enabled = PuedeAplicar;
    }
    private void LimpiarPropuesta()
    {
        respuesta = null; vista = null; Valor = null; propuestas.Clear(); seleccion.Clear(); cambios.Rows.Clear();
        aplicar.Enabled = false; avisos.Text = "";
        gantt.Cargar(Array.Empty<MYGResultadoTarea>(), plan.Calendario, plan.FechaEstado);
        gantt.Seleccionar(Array.Empty<string>());
    }

    internal MYGCronograma PrepararAplicacion(MYGProyectoDocumento actual, MYGCronograma planActual)
    {
        if (puedeEditar?.Invoke() != true) throw new InvalidOperationException("Inicie una sesión autorizada para modificar el cronograma.");
        if (respuesta == null || seleccion.Count == 0) throw new InvalidOperationException("Importe una propuesta y seleccione al menos una tarea.");
        return MYGAsistenteCronogramaIA.PrepararAplicacion(actual, planActual, paquete, respuesta, seleccion);
    }
    internal void AplicarSeleccion()
    {
        if (!PuedeAplicar) throw new InvalidOperationException("Seleccione una propuesta cuyo inicio y fin coincidan exactamente con el proyecto y use una sesión autorizada para aplicarla.");
        Valor = PrepararAplicacion(obtenerProyecto(), obtenerPlan());
        DialogResult = DialogResult.OK;
    }

    private void ExportarDatos()
    {
        string json = CrearDatosParaIA();
        using var dialogo = new SaveFileDialog { Title = "Exportar presupuesto, ACU y calendario para IA", Filter = "Datos para IA (*.json)|*.json", DefaultExt = "json", AddExtension = true, FileName = "Cronograma_IA_Datos.json" };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        MYGExportacionCronogramaWindows.ValidarDestino(dialogo.FileName, "json", origenSQLite);
        GuardarTextoAtomico(dialogo.FileName, json);
        if (paquete.Tareas.Any(t => t.Editable))
            estado.Text = EstadoCobertura() + Environment.NewLine + "Datos exportados. Adjunte este JSON a su IA y use Copiar prompt. Conserve el paquete para recuperar la propuesta otro día.";
        else MostrarEstadoPaquete("Datos exportados sólo como referencia. ");
    }
    private void AbrirPaquete()
    {
        using var dialogo = new OpenFileDialog { Title = "Abrir el paquete de datos enviado a la IA", Filter = "Datos para IA (*.json)|*.json", CheckFileExists = true };
        if (dialogo.ShowDialog(this) == DialogResult.OK) CargarPaquete(LeerTextoLimitado(dialogo.FileName, MYGAsistenteCronogramaIA.MaximoBytesJson));
    }
    private void ImportarPropuesta()
    {
        using var dialogo = new OpenFileDialog { Title = "Importar respuesta JSON de la IA", Filter = "Propuesta IA (*.json)|*.json", CheckFileExists = true };
        if (dialogo.ShowDialog(this) == DialogResult.OK) CargarPropuesta(LeerTextoLimitado(dialogo.FileName, LimiteArchivo));
    }
    private static string LeerTextoLimitado(string ruta, int limite)
    {
        using var archivo = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (archivo.Length > limite) throw new InvalidDataException("El archivo supera " + (limite / (1024 * 1024)) + " MiB. Reduzca su contenido antes de importarlo.");
        using var lector = new StreamReader(archivo, new UTF8Encoding(false, true), detectEncodingFromByteOrderMarks: true);
        return lector.ReadToEnd();
    }
    private static void GuardarTextoAtomico(string destino, string texto)
    {
        string temporal = MYGExportacionCronogramaWindows.TemporalJuntoA(destino, ".json");
        try
        {
            File.WriteAllText(temporal, texto, new UTF8Encoding(false));
            if (File.Exists(destino)) File.Replace(temporal, destino, null); else File.Move(temporal, destino);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }
    private void AplicarTemaTablas()
    {
        MYG2027_TemaComercial.EstilizarTabla(datos, 40); MYG2027_TemaComercial.EstilizarTabla(cambios, 44);
        gantt.BackColor = MYG2027_TemaComercial.Superficie;
        avisos.BackColor = MYG2027_TemaComercial.Superficie; avisos.ForeColor = MYG2027_TemaComercial.Texto;
        MYG2027_TemaComercial.EstilizarBoton(aplicar, 1);
    }
    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception ex)
        {
            estado.Text = (paquete != null ? EstadoCobertura() + Environment.NewLine : "") + ex.Message;
            avisos.Text = ex.Message;
            aplicar.Enabled = PuedeAplicar;
        }
    }
}
