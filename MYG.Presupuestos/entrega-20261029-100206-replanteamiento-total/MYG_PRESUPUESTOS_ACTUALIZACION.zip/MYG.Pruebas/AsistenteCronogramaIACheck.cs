using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG_2027;

internal static class AsistenteCronogramaIACheck
{
    private static readonly DateTime Lunes = new(2026, 10, 5);
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };
    private static string Firma(object valor) => JsonSerializer.Serialize(valor, Json);
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Asistente IA: " + mensaje); }
    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (ArgumentException) { return; }
        catch (JsonException) { return; }
        throw new Exception("Asistente IA aceptó " + detalle + ".");
    }
    private static string MensajeRechazo(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException ex) { return ex.Message; }
        throw new Exception("Asistente IA aceptó " + detalle + ".");
    }

    private sealed class Caso
    {
        internal MYGProyectoDocumento Doc;
        internal MYGCronograma Plan;
        internal MYGOpcionesCronogramaIA Opciones = new()
        { FechaInicio = Lunes, PlazoDiasCalendario = 30, Contexto = "Un frente; no inventar cuadrillas." };
        internal MYGPresupuestoDocumento Presupuesto => Doc.Presupuestos[0];
        internal ItemPresupuestoDelphin Partida(string id) => Presupuesto.Items.Single(i => i.Id == id);
        internal MYGTareaCronograma Tarea(string id) => Plan.Tareas.Single(t => t.PartidaId == id);
        internal MYGPaqueteCronogramaIA Paquete() => MYGAsistenteCronogramaIA.CrearPaquete(Doc, Plan, Opciones);
    }

    private static Caso Crear()
    {
        var doc = MYGProyectoStorage.Nuevo("Obra sintética IA", "ESTRUCTURAS");
        doc.Id = "DOC-IA";
        doc.Datos = new MYGDatosProyecto { FechaInicio = Lunes, FechaFin = Lunes.AddDays(29),
            Duracion = 30, UnidadDuracion = "DIAS" };
        var p = doc.Presupuestos[0]; p.Id = "PRES-IA"; doc.PresupuestoActivoId = p.Id;
        p.Costos.Insumos.Add(new MYGInsumo { Id = "INS-IA", Codigo = "MO-01", Descripcion = "Operario",
            Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 20 });
        for (int n = 1; n <= 3; n++)
        {
            string id = "P" + n;
            p.Items.Add(new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, IdPropuesta = id, TipoPropuesta = "PARTIDA", Origen = "MODELO",
                Estado = "PROPUESTA", Posicion = n, Descripcion = "Actividad " + n, Unidad = "m³",
                Costos = new MYGDatosPartida
                {
                    Cantidad = n == 1 ? 100 : 10, RendimientoDiario = 20, JornadaHoras = 8,
                    Analisis = new List<MYGRecursoACU> { new() { Id = "ACU-" + n, Grupo = MYGGrupoRecurso.ManoObra,
                        InsumoId = "INS-IA", Modo = MYGModoCantidad.Rendimiento, NumeroRecursos = 1 } }
                }
            });
        }
        MYGProyectoStorage.Renumerar(p);
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(doc);
        foreach (var t in plan.Tareas.Where(t => !t.EsResumen)) t.DuracionDias = int.Parse(t.PartidaId[1..]) + 1;
        return new Caso { Doc = doc, Plan = plan };
    }

    private static MYGTareaPropuestaCronogramaIA Fila(string id, string pred = null, string tipo = "FC", int desfase = 0)
    {
        var fila = new MYGTareaPropuestaCronogramaIA { TareaId = id, Justificacion = "Secuencia constructiva revisable." };
        fila.Predecesoras = pred == null ? new() : new() { new MYGPredecesoraPropuestaCronogramaIA
            { PredecesoraId = pred, Tipo = tipo, DesfaseDias = desfase, Unidad = "laborables" } };
        return fila;
    }
    private static string Propuesta(MYGPaqueteCronogramaIA paquete, params MYGTareaPropuestaCronogramaIA[] tareas) =>
        Firma(new MYGPropuestaCronogramaIA { Firma = paquete.Firma, Tareas = tareas.ToList() });
    private static MYGTareaCronogramaIA Exportada(MYGPaqueteCronogramaIA paquete, string id) => paquete.Tareas.Single(t => t.TareaId == id);
    private static MYGResultadoTarea Resultado(MYGVistaPreviaCronogramaIA vista, string id) => vista.Resultado.Filas.Single(t => t.Tarea.Id == id);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        FlujoCompleto(carpeta, pasa);
        Duraciones(pasa);
        DatosIncompletos(pasa);
        Protecciones(pasa);
        ProteccionIndirecta(pasa);
        Relaciones(pasa);
        ValidacionEstructural(pasa);
        JsonEstricto(pasa);
        CambiosDeOrigen(pasa);
        Seleccion(pasa);
        ReplanteamientoTotal(pasa);
        ReplanteamientoTotalConProtecciones(pasa);
        Plazos(pasa);
        CuadrillasProductivas(carpeta, pasa);
        DuracionesEstimadas(pasa);
        AplicacionConFechasExactas(pasa);
        CalendarioYPlazoObligatorio(pasa);
        AjustesInvalidos(pasa);
        ProduccionFueraDeRango(pasa);
        FichaCompletaYPromptConservador(pasa);
        JornadasDisponiblesYUmbral(pasa);
        DesfasesConJustificacionTecnica(pasa);
        LimiteDePredecesoras(pasa);
        SeiscientasTareasEnFrentesIndependientes(pasa);
        RedConstructivaCronogramaIACheck.Ejecutar(pasa);
        PaqueteReabierto(pasa);
        ReaperturaSinCambios(carpeta, pasa);
        SinTareasEditables(carpeta, pasa);
        DiagnosticosDeContrato(pasa);
    }

    private static void FlujoCompleto(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        c.Doc.FuenteCatalogo = new MYGFuenteDelphin { Id = "FUENTE", RutaSQLite = "/privado/SENTINELA_RUTA_IA.sqlite" };
        c.Presupuesto.Costos.Insumos[0].FichaTecnicaRuta = "/privado/SENTINELA_RUTA_IA.pdf";
        c.Partida("P1").FuenteCatalogoRuta = "/privado/SENTINELA_RUTA_IA.sqlite";
        string docAntes = Firma(c.Doc), planAntes = Firma(c.Plan);
        var paquete = c.Paquete();
        string exportacion = MYGAsistenteCronogramaIA.SerializarPaquete(paquete);
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(paquete);
        Exige(!exportacion.Contains("SENTINELA_RUTA_IA") && exportacion.Contains("Operario") && paquete.Acus.Count > 0,
            "exportar debe contener ACU legible y excluir rutas privadas del documento.");
        Exige(prompt.Contains(paquete.Firma) && prompt.Contains("MYG_CRONOGRAMA_IA_PROPUESTA") && prompt.Contains("PredecesoraId"),
            "el prompt debe ligar la respuesta al paquete y explicar identidades estables.");
        var abierta = MYGAsistenteCronogramaIA.LeerPaquete(exportacion);
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, abierta,
            Propuesta(abierta, Fila(a), Fila(b, a, "FC", 1)));
        Exige(vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 5 &&
            vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a,
            "la importación debe usar cinco jornadas calculadas por MYG y conectar los IDs recibidos.");
        Exige(Resultado(vista, b).Inicio == new DateTime(2026, 10, 13),
            "FC+1 debe saltar fin de semana y comenzar el martes 13 tras cinco jornadas del lunes 5 al viernes 9.");
        Exige(vista.Cambios.Count == 2 && !vista.CumplePlazo && Firma(c.Doc) == docAntes && Firma(c.Plan) == planAntes,
            "previsualizar no debe modificar el origen y terminar antes de la fecha del proyecto no debe certificar cumplimiento exacto.");
        var aplicado = MYGProyectoStorage.Copia(c.Doc); aplicado.Cronograma = vista.Plan;
        string ruta = Path.Combine(carpeta, "asistente_ia.sqlite");
        MYGProyectoStorage.Guardar(ruta, aplicado);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        Exige(reabierto.Cronograma.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a &&
            reabierto.Presupuestos[0].Items.Single(i => i.Id == "P1").Costos.Cantidad == 100,
            "guardar y reabrir debe conservar vínculos sin modificar el presupuesto.");
        pasa("Asistente IA: exportación con ACU sin rutas privadas, prompt vinculado, propuesta, cálculo y persistencia SQLite reales sin mutar origen");
    }

    private static void Duraciones(Action<string> pasa)
    {
        var c = Crear(); string id = c.Tarea("P1").Id;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 5, "100 m³ a 20 m³/jornada debe dar cinco jornadas.");
        c.Partida("P1").Costos.Cantidad = 101;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 6, "las jornadas fraccionarias deben redondearse hacia arriba.");
        c.Tarea("P1").NumeroCuadrillas = 2;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 3, "dos cuadrillas deben duplicar la producción sin alterar el ACU.");
        c.Partida("P1").Costos.Cantidad = 100;
        c.Tarea("P1").NumeroCuadrillas = 1;
        c.Plan.Calendario.HorasPorDia = 4;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 10, "cuatro horas de trabajo frente a ocho de ACU deben requerir diez jornadas.");
        c.Plan.Calendario.HorasPorDia = 8;
        c.Partida("P1").Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        c.Partida("P1").Costos.Metrados.Add(new MYGLineaMetrado { Elementos = 2, CantidadPorElemento = 60 });
        Exige(Exportada(c.Paquete(), id).Metrado == 120 && Exportada(c.Paquete(), id).DuracionPropuesta == 6,
            "debe usar el metrado efectivo del motor en lugar de la cantidad directa almacenada.");
        c.Opciones.RecalcularDuraciones = false;
        var paquete = c.Paquete();
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(id)));
        Exige(vista.Plan.Tareas.Single(t => t.Id == id).DuracionDias == c.Tarea("P1").DuracionDias,
            "desactivar el recálculo debe conservar la duración existente.");
        pasa("Asistente IA: duraciones por metrado efectivo, rendimiento, cuadrillas, jornada y redondeo superior; opción de conservar duración");
    }

    private static void DatosIncompletos(Action<string> pasa)
    {
        var c = Crear(); string id = c.Tarea("P1").Id;
        c.Partida("P1").Costos.Analisis.Clear();
        var paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "sin ACU no debe inventar una duración productiva.");
        c = Crear(); id = c.Tarea("P1").Id; c.Partida("P1").Costos.Cantidad = 0;
        paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "metrado cero debe requerir revisión en lugar de convertirse en un hito.");
        c = Crear(); id = c.Tarea("P1").Id;
        c.Plan.Calendario.HorariosSemanales = new List<MYGHorarioDiaTrabajo>
        {
            new() { Dia = DayOfWeek.Monday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } },
            new() { Dia = DayOfWeek.Tuesday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 960 } } }
        };
        paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "un calendario de cuatro y ocho horas no debe fingir una jornada uniforme.");
        c = Crear(); id = c.Tarea("P1").Id;
        c.Plan.Calendario.HorasPorDia = 8;
        c.Plan.Calendario.HorariosSemanales = new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
            DayOfWeek.Thursday, DayOfWeek.Friday }.Select(dia => new MYGHorarioDiaTrabajo
            { Dia = dia, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } }).ToList();
        c.Plan.Calendario.Excepciones.Add(new MYGExcepcionCalendario
        { Inicio = Lunes.AddDays(5), Fin = Lunes.AddDays(5), Laborable = true });
        Exige(c.Plan.Calendario.HorasDelDia(Lunes) == 4 && c.Plan.Calendario.HorasDelDia(Lunes.AddDays(5)) == 8,
            "la excepción laborable de sábado sin tramos debe heredar ocho horas del calendario, frente a cuatro semanales.");
        paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "debe detectar la jornada de ocho horas heredada por una excepción laborable sin tramos y preservar la duración.");
        c = Crear(); c.Partida("P1").Costos.RendimientoDiario = 0;
        string antes = Firma(c.Doc), antesPlan = Firma(c.Plan);
        try
        {
            paquete = c.Paquete();
            Exige(Exportada(paquete, c.Tarea("P1").Id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
                "un rendimiento inválido no debe producir duración.");
        }
        catch (InvalidDataException) { }
        Exige(Firma(c.Doc) == antes && Firma(c.Plan) == antesPlan, "rechazar datos incompletos debe conservar el documento.");
        c = Crear(); c.Doc.Datos.PorRendimientoCuadrilla = false; c.Doc.Datos.PorAsignacionRecursos = true;
        id = c.Tarea("P1").Id; paquete = c.Paquete();
        Exige(paquete.MetodoAnalisis.Contains("Asignación") && Exportada(paquete, id).DuracionPropuesta == null &&
            paquete.Advertencias.Any(a => a.Contains("asignación", StringComparison.OrdinalIgnoreCase)),
            "el modo por asignación de recursos debe identificarse y no usar rendimiento por cuadrilla para inventar duración.");
        var asignacion = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
            Propuesta(paquete, Fila(id, c.Tarea("P2").Id)));
        Exige(asignacion.Plan.Tareas.Single(t => t.Id == id).DuracionDias == c.Tarea("P1").DuracionDias &&
            asignacion.Plan.Tareas.Single(t => t.Id == id).Predecesoras.Count == 1,
            "el modo por asignación permite proponer vínculos conservando la duración revisada.");
        pasa("Asistente IA: ACU ausente, metrado cero, rendimiento inválido y jornadas variables conservan datos y requieren revisión");
    }

    private static void Protecciones(Action<string> pasa)
    {
        var c = Crear(); string id = c.Tarea("P1").Id;
        c.Tarea("P1").Modo = MYGModoTarea.Manual; c.Tarea("P1").InicioManual = Lunes;
        Exige(!Exportada(c.Paquete(), id).Editable, "la tarea manual debe estar protegida por defecto.");
        c.Opciones.ReprogramarManualesEImportadas = true;
        var paquete = c.Paquete();
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(id)));
        var tarea = vista.Plan.Tareas.Single(t => t.Id == id);
        Exige(tarea.Modo == MYGModoTarea.Automatica && tarea.FechasImportadasDelphin == null && c.Tarea("P1").Modo == MYGModoTarea.Manual,
            "la autorización debe reprogramar sólo la copia y retirar su instantánea manual.");
        c = Crear(); var importada = c.Tarea("P1"); id = importada.Id;
        importada.Modo = MYGModoTarea.Manual; importada.InicioManual = Lunes;
        importada.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        { Inicio = Lunes, Fin = Lunes.AddDays(1), DuracionDias = 2 };
        importada.InicioBase = Lunes; importada.FinBase = Lunes.AddDays(1); importada.DuracionBase = 2;
        importada.Notas = "Conservar control técnico";
        Exige(!Exportada(c.Paquete(), id).Editable, "las fechas importadas de Delphin deben protegerse por defecto.");
        c.Opciones.ReprogramarManualesEImportadas = true; paquete = c.Paquete();
        string presupuestoAntes = Firma(c.Presupuesto);
        vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(id)));
        tarea = vista.Plan.Tareas.Single(t => t.Id == id);
        Exige(tarea.Modo == MYGModoTarea.Automatica && tarea.FechasImportadasDelphin == null && tarea.DuracionDias == 5 &&
            tarea.InicioBase == Lunes && tarea.FinBase == Lunes.AddDays(1) && tarea.DuracionBase == 2 &&
            tarea.Notas == "Conservar control técnico" && c.Tarea("P1").FechasImportadasDelphin != null &&
            Firma(c.Presupuesto) == presupuestoAntes,
            "reprogramar Delphin debe retirar sólo la instantánea necesaria y conservar línea base, notas y presupuesto.");
        foreach (string caso in new[] { "avance", "hito", "restricción", "partes" })
        {
            c = Crear(); c.Opciones.ReprogramarManualesEImportadas = true; var protegida = c.Tarea("P1");
            if (caso == "avance") protegida.Avance = 10;
            if (caso == "hito") protegida.DuracionDias = 0;
            if (caso == "restricción") { protegida.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; protegida.FechaRestriccion = Lunes; }
            if (caso == "partes") MYGInformacionTarea.Dividir(protegida, 2, 1, 100);
            paquete = c.Paquete();
            Exige(!Exportada(paquete, protegida.Id).Editable, "no debe permitir reprogramar " + caso + ".");
            string antes = Firma(c.Plan);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
                Propuesta(paquete, Fila(protegida.Id))), "cambios en tarea protegida por " + caso);
            Exige(Firma(c.Plan) == antes, "un rechazo debe ser atómico para " + caso + ".");
        }
        pasa("Asistente IA: manuales requieren permiso explícito; hitos, avance, restricciones y tareas divididas permanecen protegidos");
    }

    private static void Relaciones(Action<string> pasa)
    {
        foreach (string tipo in new[] { "FC", "CC", "FF", "CF" })
        {
            var c = Crear(); c.Opciones.RecalcularDuraciones = false; var paquete = c.Paquete();
            string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
            var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
                Propuesta(paquete, Fila(b, a, tipo, 1)));
            var vinculo = vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single();
            Exige(vinculo.PredecesoraId == a && vinculo.Tipo.ToString() == tipo && vinculo.DesfaseDias == 1 &&
                vista.Cambios.Single().PredecesorasDespues.Contains(tipo), "se perdió el vínculo " + tipo + "+1.");
        }
        var negativa = Crear(); negativa.Opciones.RecalcularDuraciones = false;
        var paqueteNegativo = negativa.Paquete();
        string aNegativo = negativa.Tarea("P1").Id, bNegativo = negativa.Tarea("P2").Id;
        var vistaNegativa = MYGAsistenteCronogramaIA.PrepararPropuesta(negativa.Doc, negativa.Plan, paqueteNegativo,
            Propuesta(paqueteNegativo, Fila(bNegativo, aNegativo, "FC", -1)));
        Exige(Resultado(vistaNegativa, bNegativo).Inicio == Lunes.AddDays(1) &&
            vistaNegativa.Plan.Tareas.Single(t => t.Id == bNegativo).Predecesoras.Single().DesfaseDias == -1,
            "FC-1 debe permitir un adelanto laborable y empezar el martes cuando la predecesora termina ese martes.");
        foreach (int desfase in new[] { -36501, 36501 })
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(negativa.Doc, negativa.Plan, paqueteNegativo,
                Propuesta(paqueteNegativo, Fila(bNegativo, aNegativo, "FC", desfase))), "desfase fuera de rango");
        var orden = Crear(); orden.Plan.Tareas.Reverse();
        var exportado = orden.Paquete();
        string origen = orden.Tarea("P1").Id, destino = orden.Tarea("P3").Id;
        var vistaOrden = MYGAsistenteCronogramaIA.PrepararPropuesta(orden.Doc, orden.Plan, exportado,
            Propuesta(exportado, Fila(destino, origen)));
        Exige(vistaOrden.Plan.Tareas.Single(t => t.Id == destino).Predecesoras.Single().PredecesoraId == origen,
            "reordenar filas no debe sustituir IDs por números de fila.");
        pasa("Asistente IA: FC, CC, FF, CF y desfases laborables conservan su tipo y enlazan por ID estable al reordenar filas");
    }

    private static void ProteccionIndirecta(Action<string> pasa)
    {
        foreach (string tipo in new[] { "avance", "partes", "restricción", "hito" })
        {
            var c = Crear(); var protegida = c.Tarea("P2"); string a = c.Tarea("P1").Id;
            protegida.Predecesoras.Add(new() { PredecesoraId = a });
            if (tipo == "avance") protegida.Avance = 50;
            if (tipo == "partes") MYGInformacionTarea.Dividir(protegida, 2, 1, 10);
            if (tipo == "restricción") { protegida.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; protegida.FechaRestriccion = Lunes; }
            if (tipo == "hito") protegida.DuracionDias = 0;
            var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
            string antes = Firma(c.Plan), antesDoc = Firma(c.Doc), antesPaquete = Firma(paquete);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json),
                "desplazamiento indirecto de tarea protegida por " + tipo + " al aumentar la duración de su predecesora");
            var vacia = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, Array.Empty<string>());
            Exige(Firma(c.Plan) == antes && Firma(c.Doc) == antesDoc && Firma(paquete) == antesPaquete &&
                Firma(vacia.Plan) == antes && vacia.Cambios.Count == 0,
                "rechazar un desplazamiento protegido o elegir cero cambios debe conservar todas las instantáneas.");
        }
        var importacion = Crear(); var importada = importacion.Tarea("P2");
        importada.Modo = MYGModoTarea.Automatica; importada.InicioManual = Lunes;
        importada.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        { Inicio = Lunes, Fin = Lunes.AddDays(2), DuracionDias = 3, ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = Lunes };
        importacion.Opciones.FechaInicio = Lunes.AddDays(7);
        var paqueteImportado = importacion.Paquete();
        string antesImportado = Firma(importacion.Plan);
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(importacion.Doc, importacion.Plan, paqueteImportado,
            Propuesta(paqueteImportado, Fila(importacion.Tarea("P1").Id))),
            "cambio del inicio global que desplaza fechas automáticas importadas sin autorización");
        Exige(Firma(importacion.Plan) == antesImportado && importada.FechasImportadasDelphin != null,
            "un inicio global incompatible no debe modificar las fechas importadas originales.");
        var normal = Crear(); string origen = normal.Tarea("P1").Id, destino = normal.Tarea("P2").Id;
        normal.Tarea("P2").Predecesoras.Add(new() { PredecesoraId = origen });
        var normalPaquete = normal.Paquete();
        var permitida = MYGAsistenteCronogramaIA.PrepararPropuesta(normal.Doc, normal.Plan, normalPaquete,
            Propuesta(normalPaquete, Fila(origen)));
        Exige(Resultado(permitida, destino).Inicio == Lunes.AddDays(7),
            "una sucesora automática editable puede recalcular sus fechas al cambiar la predecesora sin recibir cambios directos.");
        pasa("Asistente IA: protege fechas excluidas ante cambios indirectos de predecesoras o inicio global, sin bloquear sucesoras automáticas editables");
    }

    private static void ValidacionEstructural(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete();
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id, resumen = c.Plan.Tareas.Single(t => t.EsResumen).Id;
        var invalidas = new List<string>
        {
            Propuesta(paquete, Fila(a, a)), Propuesta(paquete, Fila(a, "NO-EXISTE")),
            Propuesta(paquete, Fila("NO-EXISTE")), Propuesta(paquete, Fila(resumen)),
            Propuesta(paquete, Fila(a, resumen)), Propuesta(paquete, Fila(a), Fila(a)),
            Propuesta(paquete, Fila(a, b), Fila(b, a))
        };
        var repetida = Fila(b, a); repetida.Predecesoras.Add(new() { PredecesoraId = a, Tipo = "CC", DesfaseDias = 0, Unidad = "laborables" });
        invalidas.Add(Propuesta(paquete, repetida));
        foreach (string json in invalidas)
        {
            string antes = Firma(c.Plan), antesDoc = Firma(c.Doc), antesPaquete = Firma(paquete);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json),
                "dependencias inexistentes, repetidas, de resumen o cíclicas");
            Exige(Firma(c.Plan) == antes && Firma(c.Doc) == antesDoc && Firma(paquete) == antesPaquete,
                "rechazar identidades o vínculos debe preservar el documento, el plan y el paquete de la vista anterior.");
        }
        pasa("Asistente IA: rechaza ciclos, autorreferencias, tareas desconocidas, resúmenes y tareas o predecesoras repetidas sin mutación");
    }

    private static void JsonEstricto(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        string valido = Propuesta(paquete, Fila(b, a));
        var invalidos = new List<string> { "null", "[]", "{}", "{", valido + " texto", "```json\n" + valido + "\n```" };
        foreach (string campo in new[] { "Formato", "Version", "Firma", "Tareas" })
        { var nodo = JsonNode.Parse(valido).AsObject(); nodo.Remove(campo); invalidos.Add(nodo.ToJsonString()); }
        foreach (string campo in new[] { "TareaId", "Predecesoras" })
        { var nodo = JsonNode.Parse(valido); nodo["Tareas"][0].AsObject().Remove(campo); invalidos.Add(nodo.ToJsonString()); }
        foreach (string campo in new[] { "PredecesoraId", "Tipo", "DesfaseDias", "Unidad" })
        { var nodo = JsonNode.Parse(valido); nodo["Tareas"][0]["Predecesoras"][0].AsObject().Remove(campo); invalidos.Add(nodo.ToJsonString()); }
        foreach (string campo in new[] { "Tareas", "Firma" })
        { var nodo = JsonNode.Parse(valido); nodo[campo] = null; invalidos.Add(nodo.ToJsonString()); }
        foreach (string tipo in new[] { "fc", "FIN-COMIENZO", "99" })
        { var nodo = JsonNode.Parse(valido); nodo["Tareas"][0]["Predecesoras"][0]["Tipo"] = tipo; invalidos.Add(nodo.ToJsonString()); }
        var extra = JsonNode.Parse(valido); extra["Tareas"][0]["RendimientoDiario"] = 999; invalidos.Add(extra.ToJsonString());
        extra = JsonNode.Parse(valido); extra["Sorpresa"] = true; invalidos.Add(extra.ToJsonString());
        extra = JsonNode.Parse(valido); extra["Tareas"][0]["Predecesoras"][0]["Unidad"] = "calendario"; invalidos.Add(extra.ToJsonString());
        invalidos.Add(valido.Insert(1, "\"Version\":1,"));
        invalidos.Add(valido.Replace("\"Tipo\":\"FC\"", "\"Tipo\":\"FC\",\"Tipo\":\"CC\""));
        foreach (string json in invalidos)
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json), "JSON ambiguo o fuera del contrato estricto");
        pasa("Asistente IA: contrato JSON estricto rechaza campos ausentes, nulos, desconocidos o duplicados; no acepta rendimientos alterados ni desfases calendario");
    }

    private static void CambiosDeOrigen(Action<string> pasa)
    {
        foreach (string tipo in new[] { "cantidad", "rendimiento", "acu", "calendario", "tarea", "opciones" })
        {
            var c = Crear(); var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(c.Tarea("P1").Id));
            switch (tipo)
            {
                case "cantidad": c.Partida("P1").Costos.Cantidad++; break;
                case "rendimiento": c.Partida("P1").Costos.RendimientoDiario++; break;
                case "acu": c.Presupuesto.Costos.Insumos[0].Precio++; break;
                case "calendario": c.Plan.Calendario.Feriados.Add(Lunes); break;
                case "tarea": c.Tarea("P1").DuracionDias++; break;
                case "opciones": paquete.Opciones.PlazoDiasCalendario++; break;
            }
            string antes = Firma(c.Doc), planAntes = Firma(c.Plan);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json), "propuesta obsoleta o alterada por " + tipo);
            Exige(Firma(c.Doc) == antes && Firma(c.Plan) == planAntes, "rechazar desactualización debe conservar cambios actuales.");
        }
        pasa("Asistente IA: detecta cambios desde la exportación en metrado, rendimiento, ACU, calendario, tarea y opciones sin pisar avances");
    }

    private static void Seleccion(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        string json = Propuesta(paquete, Fila(a), Fila(b, a));
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, new[] { b });
        Exige(vista.Cambios.Count == 1 && vista.Cambios[0].TareaId == b &&
            vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == c.Tarea("P1").DuracionDias,
            "la selección debe aplicar únicamente la tarea elegida con su duración propuesta.");
        var vacia = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, Array.Empty<string>());
        Exige(Firma(vacia.Plan) == Firma(c.Plan) && vacia.Cambios.Count == 0,
            "selección vacía no debe cambiar siquiera la fecha del plan.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, new[] { "NO-EXISTE" }),
            "selección que no pertenece a la propuesta");
        c = Crear(); a = c.Tarea("P1").Id; b = c.Tarea("P2").Id;
        c.Tarea("P1").Predecesoras.Add(new() { PredecesoraId = b });
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(a), Fila(b, a));
        // Toda la propuesta elimina B->A y añade A->B: válida. Seleccionar sólo B conserva B->A y forma un ciclo.
        var completa = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(completa.Plan.Tareas.Single(t => t.Id == a).Predecesoras.Count == 0, "la propuesta completa debe retirar la relación anterior.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, new[] { b }),
            "ciclo que surge al combinar cambios seleccionados con vínculos originales");
        pasa("Asistente IA: selección parcial o vacía conserva lo no elegido y valida ciclos contra el grafo original combinado");
    }

    private static Caso CrearParaReplanteamientoTotal()
    {
        var c = Crear(); FijarPlazo(c, 5); c.Opciones.RecalcularDuraciones = false;
        c.Plan.Tareas = new() { new() { Id = "TOTAL-RESUMEN", Nombre = "Frentes de replanteamiento", EsResumen = true } };
        c.Plan.Tareas.AddRange(Enumerable.Range(1, 3).Select(n => new MYGTareaCronograma
        { Id = "TOTAL-" + n, Nombre = "Actividad total " + n, PadreId = "TOTAL-RESUMEN", DuracionDias = 5 }));
        c.Doc.Cronograma = c.Plan;
        return c;
    }

    private static void ReplanteamientoTotal(Action<string> pasa)
    {
        var c = CrearParaReplanteamientoTotal();
        var parcial = c.Paquete();
        string exportadoParcial = MYGAsistenteCronogramaIA.SerializarPaquete(parcial);
        using (var jsonParcial = JsonDocument.Parse(exportadoParcial))
            Exige(!c.Opciones.ReplantearTodasLasTareas &&
                !jsonParcial.RootElement.GetProperty("Opciones").TryGetProperty("ReplantearTodasLasTareas", out _),
                "el modo parcial debe conservarse por defecto y omitir la opción false para mantener compatibles los paquetes anteriores.");
        var anterior = MYGAsistenteCronogramaIA.LeerPaquete(c.Doc, c.Plan, exportadoParcial);
        string jsonUna = Propuesta(anterior, Fila("TOTAL-1"));
        Exige(!anterior.Opciones.ReplantearTodasLasTareas &&
            MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, anterior, jsonUna).Tareas.Count == 4 &&
            MYGAsistenteCronogramaIA.CrearPrompt(anterior).Contains("MODO PARCIAL", StringComparison.Ordinal),
            "un paquete sin la opción nueva debe reabrirse y seguir admitiendo una respuesta parcial válida.");
        c.Opciones.ReplantearTodasLasTareas = true;
        var paquete = c.Paquete();
        string exportadoTotal = MYGAsistenteCronogramaIA.SerializarPaquete(paquete);
        var reabierto = MYGAsistenteCronogramaIA.LeerPaquete(c.Doc, c.Plan, exportadoTotal);
        Exige(paquete.Firma != parcial.Firma && reabierto.Opciones.ReplantearTodasLasTareas &&
            MYGAsistenteCronogramaIA.SerializarPaquete(reabierto) == exportadoTotal,
            "el alcance total debe cambiar la firma y conservarse al guardar y reabrir el paquete.");
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(paquete);
        Exige(prompt.Contains("REPLANTEAMIENTO TOTAL OBLIGATORIO", StringComparison.Ordinal) &&
            prompt.Contains("exactamente 3 tareas distintas", StringComparison.Ordinal) &&
            prompt.Contains("sin diferencias", StringComparison.Ordinal),
            "el prompt total debe exigir todas las tareas elegibles, incluidas las que se conserven sin cambios.");
        pasa("Asistente IA: alcance total firmado y persistente; paquetes anteriores sin la opción conservan el modo parcial");

        string original = Firma(c.Doc) + Firma(c.Plan) + Firma(paquete);
        var tareas = paquete.Tareas.Where(t => t.Editable).Select(t => Fila(t.TareaId)).ToArray();
        Exige(tareas.Length == 3 && paquete.Tareas.Single(t => t.EsResumen).TareaId == "TOTAL-RESUMEN" &&
            MYGMotorCronograma.Calcular(c.Plan).Fin == c.Doc.Datos.FechaFin,
            "la red guardada debe cubrir ya las fechas exactas y contener tres actividades elegibles más un resumen protegido.");
        string incompleta = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
            Propuesta(paquete, tareas[0])), "una sola tarea en un replanteamiento de tres aunque las fechas ya coincidan");
        Exige(incompleta.Contains("propuesta incompleta", StringComparison.OrdinalIgnoreCase) &&
            incompleta.Contains("1 de 3", StringComparison.Ordinal) &&
            incompleta.Contains("Actividad total 2", StringComparison.Ordinal) &&
            incompleta.Contains("TOTAL-2", StringComparison.Ordinal),
            "el rechazo por cobertura debe informar cuántas tareas llegaron y los nombres e identidades faltantes.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete,
            Propuesta(paquete, tareas[0], tareas[1])), "omitir una fila elegible que no tiene diferencias respecto al origen");
        string completa = Propuesta(paquete, tareas);
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, completa);
        var aplicable = MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, completa,
            tareas.Select(t => t.TareaId).Reverse());
        Exige(vista.CumplePlazo && vista.Cambios.Count == 3 &&
            vista.Cambios.All(t => t.PredecesorasAntes == t.PredecesorasDespues) &&
            aplicable.Tareas.Where(t => !t.EsResumen).All(t => t.Predecesoras.Count == 0),
            "una respuesta total debe incluir las filas sin diferencias y los inicios sin predecesoras, sin exigir el resumen como destino.");
        foreach (string[] seleccion in new[] { new[] { "TOTAL-1" }, Array.Empty<string>() })
        {
            var previa = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, completa, seleccion);
            Exige(previa.CumplePlazo && previa.Cambios.Count == seleccion.Length,
                "la selección parcial o vacía puede previsualizarse incluso si conserva ambas fechas exactas.");
            string rechazo = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete,
                completa, seleccion), "aplicar sólo una parte de un replanteamiento total con fechas válidas");
            Exige(rechazo.Contains("seleccionar todas", StringComparison.Ordinal) &&
                rechazo.Contains(seleccion.Length + " de 3", StringComparison.Ordinal),
                "la aplicación total debe exigir la selección completa además de comprobar el plazo.");
        }
        Exige(Firma(c.Doc) + Firma(c.Plan) + Firma(paquete) == original,
            "validar cobertura y seleccionar vistas no debe modificar el documento, el cronograma ni el paquete.");
        pasa("Asistente IA: replanteamiento total rechaza respuestas y aplicaciones parciales aunque el plazo coincida; incluye filas sin cambios");
    }

    private static void ReplanteamientoTotalConProtecciones(Action<string> pasa)
    {
        var c = CrearParaReplanteamientoTotal(); c.Opciones.ReplantearTodasLasTareas = true;
        var manual = c.Plan.Tareas.Single(t => t.Id == "TOTAL-2");
        var importada = c.Plan.Tareas.Single(t => t.Id == "TOTAL-3");
        manual.Modo = MYGModoTarea.Manual; manual.InicioManual = Lunes;
        importada.Modo = MYGModoTarea.Manual; importada.InicioManual = Lunes;
        importada.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        { Inicio = Lunes, Fin = Lunes.AddDays(4), DuracionDias = 5, ModoOriginal = MYGModoTarea.Manual };
        var protegida = new MYGTareaCronograma
        { Id = "TOTAL-PROTEGIDA", Nombre = "Trabajo con avance conservado", PadreId = "TOTAL-RESUMEN", DuracionDias = 5, Avance = 10 };
        c.Plan.Tareas.Add(protegida);
        string origen = Firma(c.Doc) + Firma(c.Plan);
        var sinPermiso = c.Paquete();
        Exige(sinPermiso.Tareas.Count(t => t.Editable) == 1 &&
            !Exportada(sinPermiso, manual.Id).Editable && !Exportada(sinPermiso, importada.Id).Editable,
            "el alcance total no debe conceder por sí solo permiso para reprogramar tareas manuales o importadas.");
        var conservado = MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, sinPermiso,
            Propuesta(sinPermiso, Fila("TOTAL-1")));
        Exige(Firma(conservado.Tareas.Single(t => t.Id == manual.Id)) == Firma(manual) &&
            Firma(conservado.Tareas.Single(t => t.Id == importada.Id)) == Firma(importada) &&
            Firma(conservado.Tareas.Single(t => t.Id == protegida.Id)) == Firma(protegida),
            "una propuesta completa para las tareas elegibles debe conservar manuales, importadas y tareas con avance no autorizadas.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, sinPermiso,
            Propuesta(sinPermiso, Fila("TOTAL-1"), Fila(manual.Id))), "incluir una manual sin autorizarla en alcance total");
        c.Opciones.ReprogramarManualesEImportadas = true;
        var conPermiso = c.Paquete();
        Exige(conPermiso.Tareas.Count(t => t.Editable) == 3 &&
            Exportada(conPermiso, manual.Id).Editable && Exportada(conPermiso, importada.Id).Editable &&
            !Exportada(conPermiso, protegida.Id).Editable && !Exportada(conPermiso, "TOTAL-RESUMEN").Editable,
            "el permiso explícito debe incluir todas las manuales e importadas elegibles, manteniendo protegidos resúmenes y tareas con avance.");
        foreach (var omitida in new[] { manual, importada })
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, conPermiso,
                Propuesta(conPermiso, conPermiso.Tareas.Where(t => t.Editable && t.TareaId != omitida.Id)
                    .Select(t => Fila(t.TareaId)).ToArray())), "omitir una tarea autorizada del replanteamiento total: " + omitida.Nombre);
        var todas = conPermiso.Tareas.Where(t => t.Editable).Select(t => Fila(t.TareaId)).ToArray();
        var aplicable = MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, conPermiso, Propuesta(conPermiso, todas));
        Exige(aplicable.Tareas.Where(t => t.Id == manual.Id || t.Id == importada.Id)
                .All(t => t.Modo == MYGModoTarea.Automatica && t.FechasImportadasDelphin == null) &&
            Firma(aplicable.Tareas.Single(t => t.Id == protegida.Id)) == Firma(protegida) &&
            Firma(c.Doc) + Firma(c.Plan) == origen,
            "el replanteamiento completo autorizado debe reprogramar las copias manuales/importadas y conservar las protegidas y el origen.");
        pasa("Asistente IA: replanteamiento total respeta protecciones y exige todas las manuales/importadas sólo tras autorización explícita");
    }

    private static void Plazos(Action<string> pasa)
    {
        var c = Crear(); c.Opciones.PlazoDiasCalendario = 5;
        c.Plan.Calendario.Feriados.Add(Lunes.AddDays(2));
        var paquete = c.Paquete();
        Exige(paquete.FinObjetivo == Lunes.AddDays(4), "cinco días calendario desde lunes deben terminar viernes, contando el inicio.");
        string a = c.Tarea("P1").Id;
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(a)));
        Exige(Resultado(vista, a).Fin == Lunes.AddDays(7) && !vista.CumplePlazo && vista.Advertencias.Count > 0,
            "el feriado debe desplazar la quinta jornada al lunes siguiente y advertir el exceso del plazo calendario.");
        Exige(vista.Plan.Tareas.Single(t => t.Id == a).NumeroCuadrillas == 1 && Resultado(vista, a).DuracionDias == 5,
            "un plazo insuficiente no debe comprimir duraciones ni inventar cuadrillas.");
        c.Opciones.PlazoDiasCalendario = 0;
        Rechaza(() => c.Paquete(), "plazo cero");
        pasa("Asistente IA: plazo calendario inclusivo, feriados y fines de semana; informa incumplimiento sin comprimir producción");
    }

    private static void FijarPlazo(Caso c, int dias)
    {
        c.Opciones.PlazoDiasCalendario = dias;
        c.Doc.Datos.FechaInicio = c.Opciones.FechaInicio;
        c.Doc.Datos.FechaFin = c.Opciones.FechaInicio.AddDays(dias - 1);
        c.Doc.Datos.Duracion = dias;
        c.Doc.Datos.UnidadDuracion = "DIAS";
    }

    private static void CuadrillasProductivas(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        c.Partida("P1").Costos.Cantidad = 20840;
        c.Tarea("P1").DuracionDias = 1042;
        FijarPlazo(c, 145); // 105 jornadas de lunes a viernes: 05/10/2026–26/02/2027.
        string a = c.Tarea("P1").Id;
        string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan), presupuesto = Firma(c.Presupuesto);
        var paquete = c.Paquete();
        Exige(Exportada(paquete, a).DuracionPropuesta == 1042,
            "la regresión debe partir de 1.042 jornadas con una cuadrilla, como la excavación del caso informado.");
        var propuesta = Fila(a);
        propuesta.NumeroCuadrillas = 10;
        propuesta.Justificacion = "Diez frentes de excavación independientes; confirmar equipos y disponibilidad antes de ejecutar.";
        string json = Propuesta(paquete, propuesta);
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        var tarea = vista.Plan.Tareas.Single(t => t.Id == a);
        Exige(tarea.NumeroCuadrillas == 10 && tarea.DuracionDias == 105 &&
            Resultado(vista, a).Inicio == Lunes && Resultado(vista, a).Fin == new DateTime(2027, 2, 26) && vista.CumplePlazo,
            "diez cuadrillas deben reducir 1.042 jornadas a 105 y respetar las dos fechas exactas del proyecto con el calendario real.");
        Exige(vista.Cambios.Single().CuadrillasAntes == 1 && vista.Cambios.Single().CuadrillasDespues == 10,
            "la revisión debe exponer el aumento de cuadrillas, además de la reducción de duración.");
        var aplicable = MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json);
        Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && Firma(c.Presupuesto) == presupuesto,
            "calcular y preparar la aplicación deben conservar metrado, rendimiento, precios, ACU y cronograma de origen.");
        var copia = MYGProyectoStorage.Copia(c.Doc); copia.Cronograma = aplicable;
        string ruta = Path.Combine(carpeta, "asistente_ia_diez_cuadrillas.sqlite");
        MYGProyectoStorage.Guardar(ruta, copia);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        var conservada = reabierto.Cronograma.Tareas.Single(t => t.Id == a);
        var recalculado = MYGMotorCronograma.Calcular(reabierto.Cronograma);
        Exige(conservada.NumeroCuadrillas == 10 && conservada.DuracionDias == 105 &&
            recalculado.Inicio == Lunes && recalculado.Fin == new DateTime(2027, 2, 26) &&
            reabierto.Presupuestos.Single().Items.Single(i => i.Id == "P1").Costos.Cantidad == 20840,
            "guardar y reabrir SQLite debe conservar las cuadrillas, las fechas y el metrado completo de la excavación.");
        pasa("Asistente IA: reduce 1.042 jornadas mediante diez cuadrillas explícitas, cumple inicio/fin y persiste en SQLite sin cambiar el ACU");
    }

    private static void DuracionesEstimadas(Action<string> pasa)
    {
        foreach (string caso in new[] { "rendimiento predeterminado", "sin ACU", "asignación", "jornada variable" })
        {
            var c = Crear(); string a = c.Tarea("P1").Id;
            if (caso == "rendimiento predeterminado")
            {
                c.Partida("P1").Descripcion = c.Tarea("P1").Nombre = "Equipos de protección colectiva y control ambiental";
                c.Partida("P1").Costos.Cantidad = 720;
                c.Partida("P1").Costos.RendimientoDiario = 1;
                c.Tarea("P1").DuracionDias = 720;
            }
            if (caso == "sin ACU") c.Partida("P1").Costos.Analisis.Clear();
            if (caso == "asignación") { c.Doc.Datos.PorAsignacionRecursos = true; c.Doc.Datos.PorRendimientoCuadrilla = false; }
            if (caso == "jornada variable")
                c.Plan.Calendario.HorariosSemanales = new()
                {
                    new() { Dia = DayOfWeek.Monday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } },
                    new() { Dia = DayOfWeek.Tuesday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 960 } } }
                };
            var paquete = c.Paquete();
            Exige(Exportada(paquete, a).DuracionPropuesta == null,
                "no debe convertir " + caso + " en una duración productiva aparentemente verificada.");
            string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan);
            var estimacion = Fila(a);
            estimacion.DuracionDias = 4;
            estimacion.Justificacion = "Cuatro jornadas para instalar protecciones; el metrado no representa una producción diaria confirmada. Revisar el mantenimiento transversal por separado.";
            var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, estimacion));
            Exige(vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 4 &&
                vista.Plan.Tareas.Single(t => t.Id == a).NumeroCuadrillas == 1 &&
                Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
                "una estimación de duración justificada debe poder revisarse para " + caso + " sin inventar productividad ni cambiar el origen.");
            var soloCuadrillas = Fila(a); soloCuadrillas.NumeroCuadrillas = 2;
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
                Propuesta(paquete, soloCuadrillas)), "cuadrillas sin duración/productividad verificable para " + caso);
        }
        pasa("Asistente IA: rendimiento 1, partidas globales, ACU ausente, asignación y jornada variable admiten estimaciones justificadas sin generar cientos de jornadas");
    }

    private static void AplicacionConFechasExactas(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 5);
        string a = c.Tarea("P1").Id;
        var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
        var exacta = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(exacta.CumplePlazo && MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json) != null,
            "una propuesta que empieza lunes y termina exactamente el viernes objetivo debe ser aplicable.");
        foreach (int dias in new[] { 4, 12 })
        {
            c = Crear(); FijarPlazo(c, dias); a = c.Tarea("P1").Id;
            paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
            var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
            string antes = Firma(c.Plan), antesDoc = Firma(c.Doc);
            Exige(!vista.CumplePlazo, "terminar antes o después de la fecha exacta debe marcar incumplimiento.");
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
                "aplicación con fin " + (dias == 4 ? "posterior" : "anterior") + " al plazo obligatorio");
            Exige(Firma(c.Plan) == antes && Firma(c.Doc) == antesDoc,
                "rechazar el plazo debe preservar el cronograma y los datos del proyecto.");
        }
        c = Crear(); FijarPlazo(c, 12); a = c.Tarea("P1").Id;
        string b = c.Tarea("P2").Id;
        var sucesora = Fila(b, a); sucesora.DuracionDias = 5;
        sucesora.Justificacion = "Cinco jornadas para ejecutar el segundo frente después del primero, con controles y esperas técnicas incluidos.";
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(a), sucesora);
        Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo &&
            MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json) != null,
            "las diez jornadas consecutivas deben cerrar el viernes 16 de octubre.");
        foreach (string[] seleccion in new[] { new[] { a }, new[] { b }, Array.Empty<string>() })
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json, seleccion),
                "selección parcial o vacía que pierde el cumplimiento exacto de la propuesta completa");
        c = Crear(); c.Opciones.PlazoDiasCalendario = 5; a = c.Tarea("P1").Id;
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
        Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo,
            "el análisis puede revisar otro objetivo sin cambiar la ficha del proyecto.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
            "objetivo simulado que no coincide con el fin registrado en la ficha del proyecto");
        c = Crear(); c.Opciones.FechaInicio = Lunes.AddDays(7); c.Opciones.PlazoDiasCalendario = 5;
        c.Doc.Datos.FechaFin = Lunes.AddDays(11);
        a = c.Tarea("P1").Id; paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
        Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo,
            "el objetivo de simulación posterior debe ser calculable sin modificar la fecha inicial de la ficha.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
            "inicio simulado que no coincide con el inicio registrado aunque sí coincida el fin");
        pasa("Asistente IA: aplicación exige inicio y fin exactos de la ficha; bloquea fin temprano, tardío y selección parcial o vacía");
    }

    private static void CalendarioYPlazoObligatorio(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 8);
        c.Plan.Calendario.Feriados.Add(Lunes.AddDays(2));
        string a = c.Tarea("P1").Id;
        var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(vista.CumplePlazo && Resultado(vista, a).Fin == new DateTime(2026, 10, 12) &&
            MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json) != null,
            "cinco jornadas con un feriado deben cerrar el lunes 12 contando el fin de semana sin alterarlo.");
        foreach (bool inicioNoLaborable in new[] { false, true })
        {
            c = Crear();
            if (inicioNoLaborable)
            {
                c.Opciones.FechaInicio = Lunes.AddDays(-1);
                c.Plan.FechaInicio = c.Opciones.FechaInicio;
            }
            FijarPlazo(c, 6);
            a = c.Tarea("P1").Id; paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
            string calendario = Firma(c.Plan.Calendario);
            vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
            Exige(!vista.CumplePlazo && Firma(vista.Plan.Calendario) == calendario,
                "un extremo no laborable debe impedir el cumplimiento exacto, sin habilitar trabajo silenciosamente.");
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
                inicioNoLaborable ? "inicio obligatorio en domingo con calendario lunes a viernes" : "fin obligatorio en sábado con calendario lunes a viernes");
            Exige(Firma(c.Plan.Calendario) == calendario, "rechazar un extremo no laborable debe conservar el calendario original.");
        }
        c = Crear(); FijarPlazo(c, 9);
        var fija = c.Tarea("P1");
        fija.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe;
        fija.FechaRestriccion = Lunes.AddDays(1);
        foreach (var tarea in c.Plan.Tareas.Where(t => !t.EsResumen && t.Id != fija.Id))
            tarea.Predecesoras.Add(new() { PredecesoraId = fija.Id });
        c.Plan.Tareas.Add(new MYGTareaCronograma { Id = "RESUMEN-VACIO-IA", Nombre = "Capítulo sin actividades", EsResumen = true });
        string b = c.Tarea("P2").Id;
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(b, fija.Id));
        vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(vista.Resultado.Inicio == Lunes && vista.Resultado.Fin == Lunes.AddDays(8) && !vista.CumplePlazo &&
            vista.Resultado.Filas.Where(f => !f.Tarea.EsResumen).Min(f => f.Inicio) == Lunes.AddDays(1),
            "un capítulo vacío fechado al inicio no debe simular que la obra comenzó cuando todas las actividades empiezan después.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
            "inicio aparente aportado únicamente por un resumen vacío");
        pasa("Asistente IA: cumple fechas reales con feriados y fines de semana; bloquea extremos no laborables sin cambiar el calendario");
    }

    private static void AjustesInvalidos(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string a = c.Tarea("P1").Id;
        var invalidas = new List<MYGTareaPropuestaCronogramaIA>();
        foreach (decimal cuadrillas in new[] { 0m, -1m, 10001m, decimal.MaxValue })
        { var fila = Fila(a); fila.NumeroCuadrillas = cuadrillas; invalidas.Add(fila); }
        foreach (int duracion in new[] { 0, -1, 36501, int.MaxValue })
        { var fila = Fila(a); fila.DuracionDias = duracion; invalidas.Add(fila); }
        var sinMotivo = Fila(a); sinMotivo.NumeroCuadrillas = 2; sinMotivo.Justificacion = " "; invalidas.Add(sinMotivo);
        sinMotivo = Fila(a); sinMotivo.DuracionDias = 5; sinMotivo.Justificacion = null; invalidas.Add(sinMotivo);
        var produccionImposible = Fila(a); produccionImposible.NumeroCuadrillas = 2; produccionImposible.DuracionDias = 2;
        invalidas.Add(produccionImposible); // 100 m³ / 20 / 2 = 2,5: son como mínimo tres jornadas.
        foreach (var fila in invalidas)
        {
            string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan), antesPaquete = Firma(paquete);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, fila)),
                "ajustes de recursos/duración inválidos, sin justificación o inferiores a la producción mínima");
            Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && Firma(paquete) == antesPaquete,
                "validar recursos o producción debe ser atómico y no alterar ninguna instantánea.");
        }
        c.Opciones.RecalcularDuraciones = false; paquete = c.Paquete();
        foreach (bool recursos in new[] { false, true })
        {
            var fila = Fila(a);
            if (recursos) fila.NumeroCuadrillas = 2; else fila.DuracionDias = 5;
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, fila)),
                "ajuste de duración o cuadrillas con recálculo expresamente desactivado");
        }
        pasa("Asistente IA: rechaza recursos y duraciones fuera de rango, cambios sin justificación y producción insuficiente sin mutar datos");
    }

    private static void ProduccionFueraDeRango(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 1);
        c.Partida("P1").Costos.Cantidad = 730020;
        foreach (var tarea in c.Plan.Tareas.Where(t => !t.EsResumen)) tarea.DuracionDias = 1;
        string a = c.Tarea("P1").Id;
        var paquete = c.Paquete();
        Exige(Exportada(paquete, a).DuracionPropuesta == null && Exportada(paquete, a).DuracionActual == 1,
            "36.501 jornadas productivas exceden el rango y deben distinguirse de la duración actual de una jornada.");
        string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan), antesPaquete = Firma(paquete);
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(a))),
            "conservar una jornada cuando 730.020 m³ a rendimiento 20 requieren 36.501 jornadas productivas");
        Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && Firma(paquete) == antesPaquete,
            "rechazar producción fuera del rango debe conservar todas las instantáneas y no fingir cumplimiento de un día.");
        var ajuste = Fila(a); ajuste.NumeroCuadrillas = 2;
        ajuste.Justificacion = "Dos frentes independientes duplican la producción; el plazo contractual todavía requiere revisión.";
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, ajuste));
        var corregida = vista.Plan.Tareas.Single(t => t.Id == a);
        Exige(corregida.NumeroCuadrillas == 2 && corregida.DuracionDias == 18251 && !vista.CumplePlazo,
            "una cuadrilla adicional debe recuperar el cálculo válido de 18.251 jornadas, sin conservar la jornada original ni certificar el plazo de un día.");
        pasa("Asistente IA: producción superior a 36.500 jornadas nunca conserva una duración ficticia; cuadrillas explícitas recuperan el cálculo verificable");
    }

    private static void FichaCompletaYPromptConservador(Action<string> pasa)
    {
        foreach (bool faltaInicio in new[] { true, false })
        {
            var c = Crear(); FijarPlazo(c, 5);
            if (faltaInicio) c.Doc.Datos.FechaInicio = null; else c.Doc.Datos.FechaFin = null;
            string a = c.Tarea("P1").Id;
            var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
            Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo,
                "los objetivos de simulación pueden coincidir aunque falte una fecha contractual en la ficha.");
            string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
                "aplicación sin " + (faltaInicio ? "inicio" : "fin") + " registrado en los datos del proyecto");
            Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
                "la aplicación debe exigir las dos fechas de la ficha sin inventar una fecha faltante ni modificar datos.");
        }
        var conservador = Crear(); conservador.Opciones.RecalcularDuraciones = false;
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(conservador.Paquete());
        int marcador = prompt.IndexOf("Ejemplo de estructura", StringComparison.Ordinal);
        Exige(marcador >= 0, "el prompt debe proporcionar un ejemplo de respuesta utilizable por la IA.");
        int comienzo = prompt.IndexOf('{', marcador);
        int fin = prompt.IndexOf("Ejemplo de un vínculo", comienzo, StringComparison.Ordinal);
        Exige(comienzo >= 0 && fin > comienzo, "debe poder distinguirse el ejemplo completo de propuesta del ejemplo de vínculo.");
        using var ejemplo = JsonDocument.Parse(prompt.Substring(comienzo, fin - comienzo).Trim());
        var filas = ejemplo.RootElement.GetProperty("Tareas").EnumerateArray().ToArray();
        Exige(filas.Length > 0 && filas.All(f => !f.TryGetProperty("NumeroCuadrillas", out _) &&
            !f.TryGetProperty("DuracionDias", out _)),
            "conservar duraciones debe producir un ejemplo JSON que omita ajustes de cuadrillas/duración, en lugar de enseñar cambios que el importador rechazaría.");
        pasa("Asistente IA: exige ambas fechas contractuales y el ejemplo JSON conservador omite ajustes de duración y cuadrillas");
    }

    private static void JornadasDisponiblesYUmbral(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 40);
        var paquete = c.Paquete();
        Exige(paquete.FinObjetivo == new DateTime(2026, 11, 13) &&
            paquete.JornadasLaborablesDisponibles == 30 && paquete.UmbralDesfaseLargoDias == 10,
            "cuarenta días calendario del 5 de octubre al 13 de noviembre contienen treinta jornadas de lunes a viernes.");
        c.Plan.Calendario.Feriados.Add(Lunes.AddDays(2));
        paquete = c.Paquete();
        Exige(paquete.JornadasLaborablesDisponibles == 29 && paquete.UmbralDesfaseLargoDias == 10,
            "el feriado debe descontarse de las jornadas disponibles sin convertir el plazo calendario en duración laborable.");
        c.Plan.Calendario.Excepciones.Add(new MYGExcepcionCalendario
        { Inicio = Lunes.AddDays(5), Fin = Lunes.AddDays(5), Laborable = true });
        paquete = c.Paquete();
        Exige(paquete.JornadasLaborablesDisponibles == 30,
            "el sábado habilitado por una excepción debe sumarse a las jornadas disponibles, además de descontar el feriado.");
        c = Crear(); FijarPlazo(c, 145); paquete = c.Paquete();
        Exige(paquete.JornadasLaborablesDisponibles == 105 && paquete.UmbralDesfaseLargoDias == 11,
            "el umbral de desfase debe usar el diez por ciento de 105 jornadas, redondeado hacia arriba, no el plazo de 145 días calendario.");
        using var exportado = JsonDocument.Parse(MYGAsistenteCronogramaIA.SerializarPaquete(paquete));
        Exige(exportado.RootElement.GetProperty("JornadasLaborablesDisponibles").GetInt32() == 105 &&
            exportado.RootElement.GetProperty("UmbralDesfaseLargoDias").GetInt32() == 11,
            "el archivo intercambiado con la IA debe incluir ambos límites laborables como enteros para planificar sus vínculos.");
        pasa("Asistente IA: exporta jornadas laborables y umbral de desfase con feriados, excepciones y redondeo sobre el calendario real");
    }

    private static void DesfasesConJustificacionTecnica(Action<string> pasa)
    {
        var c = Crear(); c.Opciones.RecalcularDuraciones = false;
        var paquete = c.Paquete(); string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        foreach (int desfase in new[] { 218, 398, -398 })
        {
            var fila = Fila(b, a, "CC", desfase);
            fila.Justificacion = "La tarea tiene una justificación general, pero falta explicar esta espera o adelanto específico.";
            foreach (string motivo in new[] { null, " \t\r\n", new string('x', 2001) })
            {
                fila.Predecesoras.Single().Justificacion = motivo;
                string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan), antesPaquete = Firma(paquete);
                Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, fila)),
                    "CC" + desfase + " sin justificación técnica válida de la dependencia, aunque la tarea sí esté explicada");
                Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && Firma(paquete) == antesPaquete,
                    "rechazar un vínculo sin explicación debe preservar proyecto, cronograma y paquete.");
            }
        }
        const string motivoAceptado = "El suministro especializado se libera tras una campaña de fabricación de 218 jornadas; esta condición externa requiere revisar el plazo contractual.";
        var justificada = Fila(b, a, "CC", 218);
        justificada.Predecesoras.Single().Justificacion = motivoAceptado;
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, justificada));
        Exige(!vista.CumplePlazo && Resultado(vista, b).Inicio > paquete.FinObjetivo &&
            vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().DesfaseDias == 218 &&
            vista.Cambios.Single().Justificacion.Contains(motivoAceptado, StringComparison.Ordinal),
            "un desfase largo explicado puede previsualizarse y mostrar su motivo, sin acortarlo artificialmente ni certificar el fin incumplido.");
        var corta = Fila(b, a, "CC", 1); corta.Predecesoras.Single().Justificacion = new string('x', 2001);
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, corta)),
            "justificación de dependencia mayor de 2.000 caracteres aunque su desfase sea corto");
        var amplio = Crear(); FijarPlazo(amplio, 145); amplio.Opciones.RecalcularDuraciones = false;
        var paqueteAmplio = amplio.Paquete(); string inicioAmplio = amplio.Tarea("P1").Id, destinoAmplio = amplio.Tarea("P2").Id;
        Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(amplio.Doc, amplio.Plan, paqueteAmplio,
            Propuesta(paqueteAmplio, Fila(destinoAmplio, inicioAmplio, "CC", 11))).Cambios.Count == 1,
            "once jornadas sin motivo adicional deben admitirse cuando el umbral del plazo amplio es exactamente once.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(amplio.Doc, amplio.Plan, paqueteAmplio,
            Propuesta(paqueteAmplio, Fila(destinoAmplio, inicioAmplio, "CC", 12))),
            "espera sin motivo de doce jornadas que supera el umbral real de once");
        c.Tarea("P2").Predecesoras.Add(new MYGDependenciaCronograma { PredecesoraId = a, Tipo = MYGTipoVinculo.CC, DesfaseDias = 300 });
        var paqueteConProblema = c.Paquete();
        Exige(paqueteConProblema.DiagnosticoRedActual.Count > 0 &&
            !paqueteConProblema.Advertencias.Intersect(paqueteConProblema.DiagnosticoRedActual).Any(),
            "el desfase original de 300 jornadas debe diagnosticarse por separado de los avisos reutilizados al revisar una propuesta.");
        var corregida = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paqueteConProblema,
            Propuesta(paqueteConProblema, Fila(b)));
        Exige(corregida.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Count == 0 &&
            !corregida.Advertencias.Intersect(paqueteConProblema.DiagnosticoRedActual).Any(),
            "quitar el vínculo problemático debe revisar la red corregida y retirar los avisos antiguos de su vista previa.");
        pasa("Asistente IA: CC+218, CC+398 y adelantos largos requieren motivos por vínculo; la revisión conserva la explicación y el incumplimiento real");
    }

    private static void LimiteDePredecesoras(Action<string> pasa)
    {
        for (int cantidad = 0; cantidad <= 2; cantidad++)
        {
            var c = CrearRed(cantidad == 0 ? 1 : 2);
            var paquete = c.Paquete(); var fila = Cierre(cantidad);
            string antes = Firma(c.Doc) + Firma(c.Plan) + Firma(paquete);
            string json = Propuesta(paquete, fila);
            var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
            var aplicable = MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json);
            Exige(vista.CumplePlazo && vista.Resultado.Inicio == c.Doc.Datos.FechaInicio &&
                vista.Resultado.Fin == c.Doc.Datos.FechaFin &&
                aplicable.Tareas.Single(t => t.Id == fila.TareaId).Predecesoras.Count == cantidad &&
                Firma(c.Doc) + Firma(c.Plan) + Firma(paquete) == antes,
                "debe aceptar " + cantidad + " predecesoras inmediatas y cumplir las dos fechas exactas sin cambiar el origen.");
            string prompt = MYGAsistenteCronogramaIA.CrearPrompt(paquete);
            Exige(prompt.Contains("como máximo 2 predecesoras directas", StringComparison.Ordinal) &&
                prompt.Contains("no admite excepciones por justificación", StringComparison.Ordinal) &&
                !prompt.Contains("Se recomiendan de 1 a", StringComparison.Ordinal),
                "el prompt debe comunicar el máximo obligatorio de dos y admitir inicios independientes.");
        }
        pasa("Asistente IA: admite cero, una o dos predecesoras y conserva las fechas contractuales exactas");

        foreach (int cantidad in new[] { 3, 4 })
        foreach (bool justificar in new[] { false, true })
        {
            var c = CrearRed(2); var paquete = c.Paquete(); var fila = Cierre(cantidad);
            if (justificar)
                foreach (var dependencia in fila.Predecesoras)
                    dependencia.Justificacion = "Este frente entrega su área terminada para la recepción conjunta.";
            string json = Propuesta(paquete, fila);
            string antes = Firma(c.Doc) + Firma(c.Plan) + Firma(paquete) + Firma(fila);
            string mensaje = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json),
                "más de dos predecesoras" + (justificar ? " justificadas" : ""));
            Exige(mensaje.Contains("Recepción de frentes", StringComparison.Ordinal) &&
                mensaje.Contains(cantidad + " predecesoras", StringComparison.Ordinal) &&
                mensaje.Contains("máximo permitido por tarea en una propuesta IA es 2", StringComparison.Ordinal),
                "el rechazo debe identificar la tarea, su cantidad de vínculos y el límite de dos.");
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
                "aplicación directa de una propuesta con " + cantidad + " predecesoras");
            // Desmarcar la tarea en la vista previa tampoco convierte una propuesta inválida en válida.
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, Array.Empty<string>()),
                "propuesta con exceso de predecesoras aunque no esté seleccionada");
            Exige(Firma(c.Doc) + Firma(c.Plan) + Firma(paquete) + Firma(fila) == antes,
                "rechazar la propuesta no debe truncar vínculos ni modificar el documento, el plan o el intercambio.");
        }
        pasa("Asistente IA: rechaza tres o cuatro predecesoras incluso justificadas, sin recortar ni aplicar parcialmente");

        var heredado = CrearRed(2);
        heredado.Plan.Tareas[^1].Predecesoras = Enumerable.Range(1, 4).Select(n => new MYGDependenciaCronograma
        { PredecesoraId = "CONVERGENCIA-" + n, Tipo = MYGTipoVinculo.FC }).ToList();
        var previo = heredado.Paquete();
        string original = Firma(heredado.Doc) + Firma(heredado.Plan) + Firma(previo);
        string parcial = Propuesta(previo, Fila("CONVERGENCIA-1"));
        var conservada = MYGAsistenteCronogramaIA.PrepararAplicacion(heredado.Doc, heredado.Plan, previo, parcial);
        Exige(conservada.Tareas[^1].Predecesoras.Count == 4 &&
            Exportada(previo, "CONVERGENCIA-5").Predecesoras.Count == 4 &&
            previo.DiagnosticoRedActual.Any(a => a.Contains("[CONVERGENCIA]", StringComparison.Ordinal)),
            "una tarea guardada omitida en la propuesta debe conservar sus cuatro vínculos y exportar el diagnóstico para revisión.");
        var corregida = MYGAsistenteCronogramaIA.PrepararAplicacion(heredado.Doc, heredado.Plan, previo,
            Propuesta(previo, Cierre(2)));
        Exige(corregida.Tareas[^1].Predecesoras.Count == 2 &&
            Firma(heredado.Doc) + Firma(heredado.Plan) + Firma(previo) == original,
            "sólo una propuesta válida aplicada a la tarea puede sustituir su lista, preservando el origen y las fechas exactas.");
        pasa("Asistente IA: redes guardadas con más de dos predecesoras se conservan al exportar y aplicar cambios a otras tareas");

        static Caso CrearRed(int plazo)
        {
            var c = Crear(); FijarPlazo(c, plazo); c.Opciones.RecalcularDuraciones = false;
            c.Plan.Tareas = Enumerable.Range(1, 5).Select(n => new MYGTareaCronograma
            { Id = "CONVERGENCIA-" + n, Nombre = n == 5 ? "Recepción de frentes" : "Frente " + n, DuracionDias = 1 }).ToList();
            return c;
        }
        static MYGTareaPropuestaCronogramaIA Cierre(int cantidad)
        {
            var fila = Fila("CONVERGENCIA-5");
            fila.Predecesoras = Enumerable.Range(1, cantidad).Select(n => new MYGPredecesoraPropuestaCronogramaIA
            { PredecesoraId = "CONVERGENCIA-" + n, Tipo = "FC", DesfaseDias = 0, Unidad = "laborables" }).ToList();
            return fila;
        }
    }

    private static void SeiscientasTareasEnFrentesIndependientes(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 40); c.Opciones.RecalcularDuraciones = false;
        c.Opciones.ReplantearTodasLasTareas = true;
        c.Opciones.Contexto = "Veinte frentes independientes con cuadrillas y equipos separados; treinta actividades de una jornada por frente, en secuencia física FC sin esperas adicionales.";
        c.Plan.Tareas.Clear();
        var propuestas = new List<MYGTareaPropuestaCronogramaIA>();
        for (int frente = 1; frente <= 20; frente++)
            for (int numero = 1; numero <= 30; numero++)
            {
                string id = $"F{frente:00}-T{numero:00}";
                c.Plan.Tareas.Add(new MYGTareaCronograma { Id = id, Nombre = $"Frente {frente}, actividad {numero}", DuracionDias = 1 });
                var fila = Fila(id, numero == 1 ? null : $"F{frente:00}-T{numero - 1:00}");
                fila.Justificacion = numero == 1
                    ? "El frente dispone de recursos propios y área liberada para comenzar en la fecha contractual."
                    : "La actividad requiere completar el trabajo físico inmediatamente anterior del mismo frente.";
                propuestas.Add(fila);
            }
        c.Doc.Cronograma = c.Plan;
        string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan);
        var paquete = c.Paquete(); string json = Propuesta(paquete, propuestas.ToArray());
        string unaFila = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
            Propuesta(paquete, propuestas[0])), "una respuesta de una sola tarea para un replanteamiento total de seiscientas");
        Exige(unaFila.Contains("propuesta incompleta", StringComparison.OrdinalIgnoreCase) &&
            unaFila.Contains("1 de 600", StringComparison.Ordinal) && unaFila.Length < 5000,
            "el diagnóstico de una respuesta corta para una obra grande debe contar las seiscientas tareas y acotar el detalle de faltantes.");
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(paquete);
        Exige(prompt.Contains("exactamente 600 tareas distintas", StringComparison.Ordinal),
            "el prompt de una obra grande debe indicar la cantidad completa requerida y no sugerir entregar sólo una fila.");
        int marcador = prompt.IndexOf("Ejemplo de estructura", StringComparison.Ordinal);
        int comienzo = prompt.IndexOf('{', marcador);
        int finEjemplo = prompt.IndexOf("Ejemplo de un vínculo", comienzo, StringComparison.Ordinal);
        using (var ejemplo = JsonDocument.Parse(prompt.Substring(comienzo, finEjemplo - comienzo).Trim()))
            Exige(ejemplo.RootElement.GetProperty("Tareas").GetArrayLength() <= 2,
                "el ejemplo del prompt debe seguir siendo breve y no duplicar las seiscientas identidades del paquete.");
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        var aplicable = MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json);
        var filas = vista.Resultado.Filas.Where(f => !f.Tarea.EsResumen).ToArray();
        Exige(paquete.JornadasLaborablesDisponibles == 30 && vista.CumplePlazo &&
            filas.Length == 600 && vista.Cambios.Count == 600 && aplicable.Tareas.Count == 600 &&
            filas.Min(f => f.Inicio) == Lunes && filas.Max(f => f.Fin) == new DateTime(2026, 11, 13),
            "seiscientas tareas en veinte frentes de treinta jornadas deben caber exactamente entre 05/10/2026 y 13/11/2026.");
        Exige(aplicable.Tareas.Sum(t => t.Predecesoras.Count) == 580 &&
            aplicable.Tareas.Count(t => t.Predecesoras.Count == 0) == 20 &&
            aplicable.Tareas.All(t => t.DuracionDias == 1 && t.NumeroCuadrillas == 1 && t.Predecesoras.Count <= 1) &&
            aplicable.Tareas.All(t => t.Predecesoras.All(d => d.Tipo == MYGTipoVinculo.FC && d.DesfaseDias == 0 &&
                d.PredecesoraId[..3] == t.Id[..3])),
            "la red debe conservar 580 vínculos locales y veinte inicios paralelos, sin encadenar todos los frentes ni inflar sus duraciones.");
        for (int frente = 1; frente <= 20; frente++)
        {
            Exige(Resultado(vista, $"F{frente:00}-T01").Inicio == Lunes &&
                Resultado(vista, $"F{frente:00}-T30").Fin == new DateTime(2026, 11, 13),
                "cada frente independiente debe ocupar las treinta jornadas reales sin heredar la cadena de otros frentes.");
        }
        Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && !ReferenceEquals(aplicable, c.Plan),
            "la planificación y preparación de las seiscientas tareas deben trabajar sobre copias y conservar documento y cronograma originales.");
        pasa("Asistente IA: replanteamiento total de 600 tareas rechaza una sola fila, conserva 580 vínculos en veinte frentes y cumple las fechas sin mutar el origen");
    }

    private static void PaqueteReabierto(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete();
        string exportado = MYGAsistenteCronogramaIA.SerializarPaquete(paquete);
        var abierto = MYGAsistenteCronogramaIA.LeerPaquete(exportado);
        Exige(abierto.Firma == paquete.Firma && abierto.Tareas.Count == paquete.Tareas.Count,
            "reabrir el paquete debe conservar identidad para otra sesión.");
        var legado = JsonNode.Parse(exportado);
        foreach (string campo in new[] { "JornadasLaborablesDisponibles", "UmbralDesfaseLargoDias", "DiagnosticoRedActual" })
            legado.AsObject().Remove(campo);
        string mensajeLegado = MensajeRechazo(() => MYGAsistenteCronogramaIA.LeerPaquete(c.Doc, c.Plan, legado.ToJsonString()),
            "paquete anterior sin metadatos constructivos");
        Exige(mensajeLegado.Contains("versión anterior") && mensajeLegado.Contains("paquete nuevo") &&
            !mensajeLegado.Contains("alterado"),
            "actualizar el asistente debe explicar cómo regenerar el intercambio sin atribuir corrupción a un paquete original anterior.");
        var alterado = MYGAsistenteCronogramaIA.LeerPaquete(exportado);
        alterado.Tareas.Single(t => t.TareaId == c.Tarea("P1").Id).DuracionPropuesta = 1;
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, alterado,
            Propuesta(alterado, Fila(c.Tarea("P1").Id))), "paquete con duración calculada adulterada");
        var nodo = JsonNode.Parse(exportado); nodo["Firma"] = "FIRMA-AJENA";
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan,
            MYGAsistenteCronogramaIA.LeerPaquete(nodo.ToJsonString()), Propuesta(paquete, Fila(c.Tarea("P1").Id))),
            "paquete ajeno");
        Rechaza(() => MYGAsistenteCronogramaIA.LeerPaquete("{}"), "paquete sin contrato");
        pasa("Asistente IA: reabre el paquete original entre sesiones y rechaza firmas ajenas o duraciones adulteradas");
    }

    private static void ReaperturaSinCambios(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        // Una obra abierta en la aplicación ya tiene identidades y valores heredados normalizados.
        MYGProyectoStorage.Validar(c.Doc);
        var paquete = c.Paquete();
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        string json = Propuesta(paquete, Fila(a), Fila(b, a));
        string exportado = MYGAsistenteCronogramaIA.SerializarPaquete(paquete);
        c.Doc.ModificadoUtc = new DateTime(2026, 10, 28, 18, 15, 0, DateTimeKind.Utc);
        c.Doc.Cronograma = MYGProyectoStorage.Copia(c.Plan);
        c.Plan.OpcionesVista["mostrar_linea_base"] = "true";
        DateTime nuevoEstado = c.Plan.FechaEstado.AddDays(1);
        c.Plan.FechaEstado = nuevoEstado;
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a,
            "guardar fecha de modificación, persistir cronograma temporal y cambiar su vista no deben invalidar la propuesta.");
        Exige(vista.Plan.FechaEstado == nuevoEstado,
            "reabrir un cronograma temporal al día siguiente debe conservar la fecha de estado actual sin invalidar el paquete original.");
        c.Doc.Cronograma = MYGProyectoStorage.Copia(c.Plan);
        string ruta = Path.Combine(carpeta, "asistente_ia_reapertura.sqlite");
        MYGProyectoStorage.Guardar(ruta, c.Doc);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        var original = MYGAsistenteCronogramaIA.LeerPaquete(reabierto, reabierto.Cronograma, exportado);
        var importada = MYGAsistenteCronogramaIA.PrepararPropuesta(reabierto, reabierto.Cronograma, original, json);
        Exige(original.Firma == paquete.Firma && importada.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 5 &&
            importada.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a,
            "cerrar y reabrir la misma obra SQLite debe admitir el paquete y la respuesta originales sin cambios de planificación.");
        pasa("Asistente IA: guardar, cerrar y reabrir SQLite conserva el intercambio; fecha de guardado y opciones de vista no invalidan la propuesta");
    }

    private static void SinTareasEditables(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        foreach (var tarea in c.Plan.Tareas.Where(t => !t.EsResumen))
        {
            tarea.Modo = MYGModoTarea.Manual; tarea.InicioManual = Lunes;
            tarea.FechasImportadasDelphin = new MYGFechasImportadasDelphin
            {
                Inicio = Lunes, Fin = Lunes.AddDays(tarea.DuracionDias - 1), DuracionDias = tarea.DuracionDias,
                ModoOriginal = MYGModoTarea.Manual, InicioProyecto = Lunes
            };
        }
        string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan);
        var original = c.Paquete();
        Exige(original.Tareas.Any(t => t.EsResumen) && original.Tareas.All(t => !t.Editable),
            "el caso sintético debe representar resúmenes y actividades manuales/importadas sin destinos editables.");
        string promptBloqueado = MensajeRechazo(() => MYGAsistenteCronogramaIA.CrearPrompt(original),
            "copiar un prompt que sólo podría devolver una lista vacía por falta de tareas editables");
        Exige(promptBloqueado.Contains("no tiene tareas editables", StringComparison.OrdinalIgnoreCase) &&
            promptBloqueado.Contains("manuales o importadas", StringComparison.OrdinalIgnoreCase) &&
            promptBloqueado.Contains("exporte un paquete nuevo", StringComparison.OrdinalIgnoreCase) &&
            promptBloqueado.Contains("prompt", StringComparison.OrdinalIgnoreCase),
            "sin tareas editables debe explicar activar la reprogramación explícita, revisar, exportar otra vez y copiar el nuevo prompt.");
        string vacia = Propuesta(original);
        string diagnostico = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, original, vacia),
            "propuesta vacía con encabezados y firma correctos");
        Exige(diagnostico.Contains("Tareas: []", StringComparison.Ordinal) &&
            diagnostico.Contains("no tiene tareas editables", StringComparison.OrdinalIgnoreCase) &&
            !diagnostico.Contains("Firma", StringComparison.Ordinal),
            "Tareas vacía con firma y versión correctas debe identificar la causa real sin culpar a la Firma.");
        c.Opciones.ReprogramarManualesEImportadas = true;
        var renovado = c.Paquete();
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(renovado);
        Exige(renovado.Tareas.Count(t => t.Editable) == 3 && renovado.Firma != original.Firma &&
            prompt.Contains(renovado.Firma) && prompt.Contains("PredecesoraId"),
            "activar la opción debe producir un paquete y un prompt nuevos con las actividades ahora editables.");
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id, d = c.Tarea("P3").Id;
        string respuestaAnterior = Propuesta(original, Fila(a));
        string firmaAnterior = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, renovado, respuestaAnterior),
            "respuesta del paquete previo a autorizar reprogramación");
        Exige(firmaAnterior.Contains("Firma", StringComparison.Ordinal) && firmaAnterior.Contains("no coincide", StringComparison.OrdinalIgnoreCase),
            "el cambio de autorización requiere una respuesta nueva y debe detectar la firma del paquete anterior.");
        string respuesta = Propuesta(renovado, Fila(a), Fila(b, a), Fila(d, b));
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, renovado, respuesta);
        Exige(vista.Plan.Tareas.Where(t => !t.EsResumen).All(t => t.Modo == MYGModoTarea.Automatica && t.FechasImportadasDelphin == null) &&
            vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 5 &&
            vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a &&
            Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
            "la propuesta nueva puede previsualizarse, pero no debe modificar las actividades originales antes de aplicar.");
        var aplicado = MYGProyectoStorage.Copia(c.Doc); aplicado.Cronograma = vista.Plan;
        string ruta = Path.Combine(carpeta, "asistente_ia_manuales_sinteticas.sqlite");
        MYGProyectoStorage.Guardar(ruta, aplicado);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        Exige(reabierto.Cronograma.Tareas.Single(t => t.Id == d).Predecesoras.Single().PredecesoraId == b &&
            Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
            "guardar una copia aplicada debe conservar el encadenamiento sin tocar el origen sintético.");
        pasa("Asistente IA: detecta cero tareas editables y respuesta vacía con firma correcta; reprogramación explícita exige nuevo paquete y permite previsualizar y guardar la propuesta");
    }

    private static void DiagnosticosDeContrato(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string valido = Propuesta(paquete, Fila(c.Tarea("P1").Id));
        var nodo = JsonNode.Parse(valido); nodo["Formato"] = "MYG_CRONOGRAMA_IA_DATOS";
        string tipo = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "el paquete de exportación usado como respuesta");
        Exige(tipo.Contains("Abrir paquete exportado", StringComparison.OrdinalIgnoreCase),
            "usar un paquete de datos como propuesta debe indicar el botón correcto.");
        nodo = JsonNode.Parse(valido); nodo["Version"] = 2;
        string version = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "versión de respuesta no admitida");
        Exige(version.Contains("versión", StringComparison.OrdinalIgnoreCase) && !version.Contains("Firma", StringComparison.Ordinal),
            "el error de versión debe distinguirse del error de firma.");
        nodo = JsonNode.Parse(valido); nodo.AsObject().Remove("Firma");
        string sinFirma = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "respuesta que omitió Firma");
        Exige(sinFirma.Contains("no contiene la Firma", StringComparison.OrdinalIgnoreCase),
            "una firma ausente debe explicarse en español, sin ocultarse tras un fallo de deserialización genérico.");
        nodo = JsonNode.Parse(valido); nodo["Firma"] = "FIRMA-DE-OTRO-PAQUETE";
        string otraFirma = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "respuesta con firma distinta");
        Exige(otraFirma.Contains("no coincide", StringComparison.OrdinalIgnoreCase) && otraFirma != sinFirma,
            "una firma distinta debe distinguirse de una firma ausente.");
        string vacia = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete)),
            "respuesta vacía pese a haber actividades editables");
        Exige(vacia.Contains("Tareas: []", StringComparison.Ordinal) && !vacia.Contains("Firma", StringComparison.Ordinal),
            "una respuesta vacía debe diagnosticar su lista de tareas aunque haya destinos editables.");
        foreach (bool omitir in new[] { false, true })
        {
            nodo = JsonNode.Parse(valido);
            if (omitir) nodo.AsObject().Remove("Tareas"); else nodo["Tareas"] = null;
            string sinLista = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
                "lista Tareas ausente o nula");
            Exige(sinLista.Contains("no contiene la lista Tareas", StringComparison.OrdinalIgnoreCase) &&
                !sinLista.Contains("Firma", StringComparison.Ordinal),
                "la lista ausente o nula debe distinguirse de la firma y de una lista válida pero vacía.");
        }
        var excesivas = Enumerable.Range(0, paquete.Tareas.Count + 1).Select(_ => Fila(c.Tarea("P1").Id)).ToArray();
        string demasiadas = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
            Propuesta(paquete, excesivas)), "respuesta con más tareas que el paquete");
        Exige(demasiadas.Contains("más tareas que el paquete", StringComparison.OrdinalIgnoreCase) &&
            !demasiadas.Contains("Firma", StringComparison.Ordinal),
            "un exceso de tareas debe explicar su cantidad antes de revisar las identidades repetidas.");
        pasa("Asistente IA: distingue paquete equivocado, versión, firma ausente o distinta, lista ausente, vacía y excesiva con mensajes específicos");
    }
}
