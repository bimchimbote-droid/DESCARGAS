# Corrección de precios y totales al abrir el presupuesto

Síntoma comunicado: al abrir el proyecto, Cantidad, Precio, Total y el pie
de presupuesto aparecían vacíos. Pulsar Actualizar metrado en Excel volvía
a mostrar los importes. Los recursos e importes del ACU seguían disponibles.

La tabla reconstruía sus filas sin valores numéricos y dependía de un
refresco diferido para completar esos datos. El refresco completo ahora
publica también los cálculos cuando no hay una edición activa. Las solicitudes
anteriores a la creación de la ventana se conservan y se reintentan al cargar
o mostrar el panel. Al vaciar el editor se limpia su estado de fórmula pendiente.
El detalle evita solicitar un segundo cálculo durante ese refresco completo.

Se mantienen los trece botones superiores, las referencias cortas y la
exportación Excel de las entregas anteriores. No se cambian el motor de
precios, las dependencias ni el esquema de las bases de datos.

## Archivos de esta corrección

| Ruta | Acción |
| --- | --- |
| MYG.Desktop/PresupuestosPanel.cs | REEMPLAZAR |
| MYG.Desktop/PresupuestosEstructuraPanel.cs | REEMPLAZAR |
| MYG.PruebasUI/Program.cs | REEMPLAZAR |
| MYG.PruebasUI/PreciosInicioCheck.cs | CREAR |
| CORRECCION_PRECIOS_INICIO.md | CREAR |

## Instalación

Esta corrección se aplica sobre las entregas anteriores de referencias y
barra de trece botones, incluida `entrega-20261014-104745-correccion-barra`.
Respalde o confirme sus modificaciones locales, extraiga el ZIP fuera del
checkout y copie sus archivos conservando las rutas relativas. Compare
los archivos completos antes de sustituirlos si tiene cambios posteriores.

Abra MYG.Presupuestos.sln en Visual Studio con SDK .NET 10. Desde la raíz:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true --no-restore -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

Compile y ejecute la aplicación nueva; una ventana del ejecutable anterior
debe cerrarse antes de iniciar la versión corregida. Abra una copia de su
proyecto y compruebe que precios, totales y pie aparecen sin pulsar Actualizar
metrado Excel. Revise también los importes después de cambiar de partida o pestaña.

En Windows, ejecute las comprobaciones de interfaz:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

## Validación y límites

Validación en Linux x64 con SDK .NET 10.0.100: solución completa compilada
sin errores ni advertencias; 302 comprobaciones de la suite de datos completadas.
Named Pipes de Windows se omite en Linux. No se usan datos privados del usuario.

La nueva prueba PreciosInicioCheck se compiló, pero no se ejecutó porque
requiere Windows Desktop. Comprueba la apertura de EditorForm con ACU real
sintético (precio unitario 62, cantidad 2, costo directo 124), el pie de
siete conceptos, la incidencia, la selección y ocultar/mostrar la ventana.
No invoca el cálculo privado ni pulsa Actualizar Excel para llenar las celdas.
La ejecución visual, Microsoft Excel y Revit siguen requiriendo Windows.

La publicación de este ZIP en bimchimbote-droid/DESCARGAS no aplica cambios
ni hace Push en bimchimbote-droid/MYG.Presupuestos. Después de validar, revise
Cambios de Git en Visual Studio, realice Commit y Push a main si desea publicar
el código. La base remota comprobada sigue siendo main, commit
fc865f24a564dfed3730b7517c31f8567e46892a, más las dos entregas anteriores aplicadas.
