using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace MYG_2027;

// Es una preferencia de lectura de este equipo. El DPI y el formato de los
// documentos siguen perteneciendo a Windows y a cada editor, respectivamente.
internal static class MYGTamanoTextoUI
{
    private readonly record struct DescripcionFuente(string Nombre, float Tamano, FontStyle Estilo,
        GraphicsUnit Unidad, byte Caracteres, bool Vertical);
    private readonly record struct ClaveFuente(DescripcionFuente Fuente, int Porcentaje);
    private sealed class OriginalFuente { internal DescripcionFuente Descripcion; }
    private sealed class EstadoFuente
    {
        internal bool Aplicando, CambiandoDpi;
        internal DescripcionFuente UltimaBase;
        internal float UltimoTamanoAplicado;
        internal readonly Dictionary<ClaveFuente, Font> Fuentes = new();
    }
    private sealed record Opcion(int Porcentaje, string Texto)
    {
        public override string ToString() => Texto;
    }

    private static readonly Opcion[] opciones =
    {
        new(85, "Compacto (85 %)"), new(100, "Normal (100 %)"), new(115, "Grande (115 %)")
    };
    private static readonly ConditionalWeakTable<Control, EstadoFuente> controles = new();
    private static readonly ConditionalWeakTable<ToolStripItem, EstadoFuente> items = new();
    private static readonly ConditionalWeakTable<Font, OriginalFuente> originales = new();
    private static readonly Dictionary<ClaveFuente, Font> fuentesDibujo = new();
    private static bool inicializado;
    private static int porcentaje = 100;
    internal static int Porcentaje { get { Inicializar(); return porcentaje; } }
    internal static event EventHandler CambioTamano;

    private static string RutaPreferencia => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "Presupuestos", "tamano-texto.txt");

    internal static void Inicializar()
    {
        if (inicializado) return;
        inicializado = true;
        try
        {
            if (File.Exists(RutaPreferencia) && int.TryParse(File.ReadAllText(RutaPreferencia).Trim(),
                NumberStyles.Integer, CultureInfo.InvariantCulture, out int guardado)
                && opciones.Any(o => o.Porcentaje == guardado)) porcentaje = guardado;
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or System.Security.SecurityException) { }
        Application.ApplicationExit += (_, _) => Liberar(fuentesDibujo);
    }

    internal static void Cambiar(int nuevoPorcentaje, bool guardarPreferencia = true)
    {
        if (!opciones.Any(o => o.Porcentaje == nuevoPorcentaje))
            throw new ArgumentOutOfRangeException(nameof(nuevoPorcentaje), "Elija 85, 100 o 115 por ciento.");
        Inicializar();
        if (guardarPreferencia)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(RutaPreferencia));
                File.WriteAllText(RutaPreferencia, nuevoPorcentaje.ToString(CultureInfo.InvariantCulture));
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException or System.Security.SecurityException) { }
        }
        if (porcentaje == nuevoPorcentaje) return;
        porcentaje = nuevoPorcentaje;
        // Las tablas débiles también incluyen diálogos ocultos y menús que no
        // pertenecen a OpenForms. No se vuelve a cargar ni a editar un documento.
        foreach (var entrada in controles.ToArray()) Actualizar(entrada.Key, entrada.Value);
        foreach (var entrada in items.ToArray()) Actualizar(entrada.Key, entrada.Value);
        CambioTamano?.Invoke(null, EventArgs.Empty);
    }

    internal static ComboBox CrearSelector()
    {
        var selector = new ComboBox
        {
            Name = "tamano_texto_selector", DropDownStyle = ComboBoxStyle.DropDownList,
            Width = 170, AccessibleName = "Tamaño del texto",
            AccessibleDescription = "Tamaño del texto de la interfaz. Se guarda para este usuario en este equipo; los documentos y la impresión conservan su formato.",
            Font = new Font("Segoe UI", 9), Margin = new Padding(7, 5, 7, 5)
        };
        selector.Items.AddRange(opciones.Cast<object>().ToArray());
        bool sincronizando = false;
        void Sincronizar(object sender, EventArgs e)
        {
            sincronizando = true;
            try { selector.SelectedItem = opciones.Single(o => o.Porcentaje == Porcentaje); }
            finally { sincronizando = false; }
        }
        selector.SelectedIndexChanged += (_, _) =>
        {
            if (!sincronizando && selector.SelectedItem is Opcion opcion) Cambiar(opcion.Porcentaje);
        };
        CambioTamano += Sincronizar;
        selector.Disposed += (_, _) => CambioTamano -= Sincronizar;
        Sincronizar(null, EventArgs.Empty);
        return selector;
    }

    internal static Button CrearBoton()
    {
        var boton = new MYG2027_BotonComercial
        {
            Name = "tamano_texto_button", Width = 116, Height = 65,
            AccessibleName = "Tamaño del texto", Font = new Font("Segoe UI", 9),
            AccessibleDescription = "Elige texto compacto, normal o grande para este equipo. Los documentos y la impresión conservan su formato.",
            Margin = new Padding(2)
        };
        ContextMenuStrip menu = null;
        void Sincronizar(object sender, EventArgs e) => boton.Text = $"Texto {Porcentaje} % ▾";
        CambioTamano += Sincronizar;
        boton.Disposed += (_, _) =>
        {
            CambioTamano -= Sincronizar;
            menu?.Dispose();
        };
        boton.Click += (_, _) =>
        {
            // WinForms termina de procesar el cierre antes de invocar el Click
            // de la opción. Liberar el menú en Closed destruye su ventana en
            // mitad de esa secuencia. El botón conserva y libera su menú.
            menu ??= CrearMenu();
            MYG2027_TemaComercial.Aplicar(menu);
            menu.Show(boton, new Point(0, boton.Height));
        };
        Sincronizar(null, EventArgs.Empty);
        MYG2027_TemaComercial.EstilizarBoton(boton, 3);
        return boton;
    }

    internal static ContextMenuStrip CrearMenu()
    {
        var menu = new ContextMenuStrip { Name = "menu_tamano_texto" };
        foreach (var opcion in opciones)
        {
            var item = new ToolStripMenuItem(opcion.Texto, null, (_, _) => Cambiar(opcion.Porcentaje))
            { Name = "tamano_texto_" + opcion.Porcentaje, Checked = opcion.Porcentaje == Porcentaje };
            menu.Items.Add(item);
            menu.Opening += (_, _) => item.Checked = opcion.Porcentaje == Porcentaje;
        }
        MYG2027_TemaComercial.Aplicar(menu);
        return menu;
    }

    // Fuente compartida sólo para dibujo/medición: el llamador no debe liberarla.
    // Nunca se asigna a un contenedor que pueda transmitir WM_SETFONT al RTF.
    internal static Font Fuente(Font original) => Escalar(fuentesDibujo, original);

    internal static Font FuenteOriginal(Font original) => Escalar(fuentesDibujo, original, 100);

    internal static bool EsFuenteInterfaz(Font fuente, float tamano, FontStyle estilo)
    {
        if (fuente == null) return false;
        var descripcion = Describir(fuente);
        return descripcion.Nombre == "Segoe UI" && Math.Abs(descripcion.Tamano - tamano) < .01f
            && descripcion.Estilo == estilo && descripcion.Unidad == GraphicsUnit.Point;
    }

    internal static void Aplicar(Control control)
    {
        if (control == null || control.IsDisposed || control.Disposing || Protegido(control)) return;
        if (control is not (Label or ButtonBase or TextBox or ComboBox or UpDownBase
            or ListBox or ListView or TreeView or DataGridView)) return;
        var estado = controles.GetValue(control, Registrar);
        Actualizar(control, estado);
    }

    internal static void Aplicar(ToolStripItem item)
    {
        if (item == null || item.IsDisposed || Protegido(item.Owner)) return;
        var estado = items.GetValue(item, actual =>
        {
            var nuevo = new EstadoFuente();
            actual.Disposed += (_, _) => Liberar(nuevo.Fuentes);
            return nuevo;
        });
        Actualizar(item, estado);
    }

    private static EstadoFuente Registrar(Control control)
    {
        var estado = new EstadoFuente();
        control.FontChanged += (_, _) =>
        {
            // WinForms puede crear una fuente nueva a partir de la que ya
            // estaba reducida. Durante la notificación de DPI se conserva el
            // factor nativo, sin volver a aplicar el porcentaje a esa copia.
            if (!estado.Aplicando && estado.CambiandoDpi && estado.UltimoTamanoAplicado > 0
                && !originales.TryGetValue(control.Font, out _))
            {
                var nativa = Describir(control.Font);
                var original = nativa with { Tamano = estado.UltimaBase.Tamano * nativa.Tamano / estado.UltimoTamanoAplicado };
                originales.Add(control.Font, new OriginalFuente { Descripcion = original });
            }
            Actualizar(control, estado);
        };
        control.DpiChangedBeforeParent += (_, _) => estado.CambiandoDpi = true;
        control.DpiChangedAfterParent += (_, _) =>
        {
            estado.CambiandoDpi = false;
            Actualizar(control, estado);
        };
        control.Disposed += (_, _) => Liberar(estado.Fuentes);
        if (control is DataGridView tabla)
        {
            tabla.DefaultCellStyleChanged += (_, _) => Actualizar(tabla, estado);
            tabla.ColumnHeadersDefaultCellStyleChanged += (_, _) => Actualizar(tabla, estado);
            tabla.RowHeadersDefaultCellStyleChanged += (_, _) => Actualizar(tabla, estado);
            tabla.CellFormatting += (_, e) =>
            {
                if (!Protegido(tabla) && e.CellStyle.Font != null)
                    e.CellStyle.Font = Escalar(estado.Fuentes, e.CellStyle.Font);
            };
            tabla.EditingControlShowing += (_, e) =>
            {
                if (Protegido(tabla)) return;
                if (e.CellStyle.Font != null) e.CellStyle.Font = Escalar(estado.Fuentes, e.CellStyle.Font);
                if (e.CellStyle.Font != null) e.Control.Font = e.CellStyle.Font;
            };
        }
        return estado;
    }

    private static void Actualizar(Control control, EstadoFuente estado)
    {
        if (estado.Aplicando || control.IsDisposed || control.Disposing || Protegido(control)) return;
        estado.Aplicando = true;
        try
        {
            control.Font = Escalar(estado.Fuentes, control.Font);
            estado.UltimaBase = Describir(control.Font);
            estado.UltimoTamanoAplicado = control.Font.Size;
            if (control is DataGridView tabla)
            {
                Adaptar(tabla.DefaultCellStyle, estado);
                Adaptar(tabla.ColumnHeadersDefaultCellStyle, estado);
                Adaptar(tabla.RowHeadersDefaultCellStyle, estado);
                // Los estilos particulares de filas se escalan al formatear la
                // celda. Así funciona también después de regenerar los datos.
                if (tabla.EditingControl != null && !tabla.EditingControl.IsDisposed)
                    tabla.EditingControl.Font = Escalar(estado.Fuentes, tabla.EditingControl.Font);
            }
            control.Invalidate();
        }
        finally { estado.Aplicando = false; }
    }

    private static void Actualizar(ToolStripItem item, EstadoFuente estado)
    {
        if (estado.Aplicando || item.IsDisposed || Protegido(item.Owner)) return;
        estado.Aplicando = true;
        try { item.Font = Escalar(estado.Fuentes, item.Font); item.Invalidate(); }
        finally { estado.Aplicando = false; }
    }

    private static void Adaptar(DataGridViewCellStyle estilo, EstadoFuente estado)
    {
        if (estilo.Font != null) estilo.Font = Escalar(estado.Fuentes, estilo.Font);
    }

    private static bool Protegido(Control control)
    {
        var visitados = new HashSet<Control>();
        for (var actual = control; actual != null && visitados.Add(actual);)
        {
            if (actual is RichTextBox or MYGEspecificacionesEditor or MYGVistaPreliminarReportesForm
                or MYGVistaMetradosExcelForm || actual.Name is "metrado_hoja" or "vista_metrados_excel_hoja") return true;
            Control propietario = actual is ToolStripDropDown desplegable ? desplegable.OwnerItem?.Owner : null;
            if (propietario == null && actual is ContextMenuStrip contexto) propietario = contexto.SourceControl;
            actual = propietario ?? actual.Parent;
        }
        return false;
    }

    private static DescripcionFuente Describir(Font fuente) => originales.TryGetValue(fuente, out var original)
        ? original.Descripcion : new DescripcionFuente(fuente.Name, fuente.Size, fuente.Style,
            fuente.Unit, fuente.GdiCharSet, fuente.GdiVerticalFont);

    private static Font Escalar(Dictionary<ClaveFuente, Font> cache, Font fuente, int? destino = null)
    {
        Inicializar();
        var descripcion = Describir(fuente);
        int valor = destino ?? porcentaje;
        var clave = new ClaveFuente(descripcion, valor);
        if (cache.TryGetValue(clave, out var existente)) return existente;
        var nueva = new Font(descripcion.Nombre, descripcion.Tamano * valor / 100f, descripcion.Estilo,
            descripcion.Unidad, descripcion.Caracteres, descripcion.Vertical);
        originales.Add(nueva, new OriginalFuente { Descripcion = descripcion });
        cache.Add(clave, nueva);
        return nueva;
    }

    private static void Liberar(Dictionary<ClaveFuente, Font> fuentes)
    {
        foreach (var fuente in fuentes.Values) fuente.Dispose();
        fuentes.Clear();
    }
}
