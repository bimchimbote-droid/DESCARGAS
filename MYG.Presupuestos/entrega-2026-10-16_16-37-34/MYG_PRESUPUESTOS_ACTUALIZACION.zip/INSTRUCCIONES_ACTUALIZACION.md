# Actualización: resumen sin Total automático y lista contextual de insumos

Código: bimchimbote-droid/MYG.Presupuestos. Base Git main: 48765e07163a63217f87048fb4a6a1a76b5b504d, conservando la actualización anterior entregada de costo directo/identificadores/fuente.
Esta entrega incremental se aplica sobre la actualización anterior del ZIP publicado en DESCARGAS, commit 19d3eee6cd7eee8fb2f953df1c9f1832ddc369fb. Contiene únicamente los archivos modificados ahora y las clases nuevas. No contiene ejecutables, dependencias, bases de datos ni el repositorio Git.

## Comportamiento corregido

- Al limpiar el resumen queda Costo directo. Añadir una o varias filas ya no crea otra fila Total. Los informes respetan las mismas filas. Se conservan los TOTAL que el usuario cree, sus valores y fórmulas. El resumen predeterminado conserva su Total.
- Al seleccionar un presupuesto o un título se oculta el detalle ACU y aparece la lista de insumos, con las pestañas superiores Lista de insumos del presupuesto y Lista de insumos del proyecto.
- La primera pestaña muestra el presupuesto seleccionado o las partidas descendientes del título elegido. La segunda reúne todos los presupuestos del proyecto. Incluye los recursos referenciados con cantidad cero y separa diferencias de proveedor, unidad y precio.
- Columnas: Cod., Descripción, Proveedor, Cantidad con unidad, Precio Unit. y Total. Los recursos se agrupan por tipo, con grupos expandibles y total al pie. La fila superior permite filtrar columnas. Clic derecho permite quitar filtros y expandir/contraer grupos.
- Iconos: información, copiar, Excel, impresión y mostrar/ocultar cabecera. Copiar/exportar/imprimir usan la lista mostrada. Volver a una partida recupera la pestaña de detalle elegida.
- Las listas son de consulta. Navegar, filtrar y cambiar de tema no modifica el proyecto ni su historial.

## Archivos

| Ruta | Acción |
|---|---|
| INSTRUCCIONES_ACTUALIZACION.md | REEMPLAZAR |
| MYG.Core/InsumosContextoMYG.cs | CREAR |
| MYG.Core/ReportesProyectoMYG.cs | REEMPLAZAR |
| MYG.Desktop/PresupuestosInsumosContexto.cs | CREAR |
| MYG.Desktop/PresupuestosPanel.cs | REEMPLAZAR |
| MYG.Desktop/PresupuestosPiePanel.cs | REEMPLAZAR |
| MYG.Pruebas/InsumosContextoCheck.cs | CREAR |
| MYG.Pruebas/PiePersonalizadoCheck.cs | REEMPLAZAR |
| MYG.Pruebas/Program.cs | REEMPLAZAR |
| MYG.PruebasUI/CostoDirectoDialogoCheck.cs | REEMPLAZAR |
| MYG.PruebasUI/InsumosContextoUICheck.cs | CREAR |
| MYG.PruebasUI/Program.cs | REEMPLAZAR |
| MYG.PruebasUI/ResumenPersonalizadoUICheck.cs | REEMPLAZAR |

## Aplicación manual

1. Confirme o respalde sus cambios locales en Visual Studio > Cambios de Git y cierre MYG.
2. Verifique que ya aplicó la entrega anterior de costo directo/identificadores/fuente. Si tiene cambios posteriores en los archivos de esta lista, compare y fusione antes de sustituirlos.
3. Extraiga MYG_PRESUPUESTOS_ACTUALIZACION.zip fuera del proyecto y copie su contenido a la raíz de MYG.Presupuestos, conservando las rutas relativas. Reemplace únicamente los archivos indicados.
4. No elimine archivos ni bases de datos. No hay parches pendientes. Los proyectos SDK incluyen automáticamente las clases nuevas.
5. Abra MYG.Presupuestos.sln en Visual Studio 2026 y compile Release. SDK utilizado: .NET 10.0.100. Desde la raíz:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

Las referencias NuGet de Revit permiten compilar sin Revit instalado. Ejecutar su integración real requiere Windows y Revit 2027.

## Validación y comprobaciones manuales

- Compilación completa Release: 0 errores y 0 advertencias.
- Suite funcional: 402 comprobaciones aprobadas, incluidas SQLite, resumen personalizado sin Total fabricado, subtotales propios, alcance por título/proyecto, cantidades cero, IGV y redondeos nativos.
- Las nuevas comprobaciones UI compilaron. No se ejecutaron en Linux porque necesitan Windows Desktop. Named Pipes fue omitida por el runner; las muestras externas opcionales y Revit no se ejecutaron.
- En Windows: limpiar resumen y añadir varias filas, incluidas dos con etiqueta TOTAL y fórmulas distintas; verificar que no aparece otro Total, también al exportar.
- Elegir presupuesto/título/subtítulo y comprobar pestañas, cabecera, recursos y sumas. Cambiar a proyecto, probar filtros, contraer grupos, copiar, exportar a Excel, vista previa e icono de cabecera.
- Escribir un filtro, refrescar y alternar tema: debe conservar el texto. Volver a una partida debe recuperar el ACU o la pestaña de detalle anterior sin perder datos.

## GitHub

Únicamente el ZIP se publica en el repositorio independiente bimchimbote-droid/DESCARGAS. No se hizo push al repositorio del código.
Tras aplicar y validar: en Visual Studio > Cambios de Git revise las diferencias, haga Commit y Push a su rama de trabajo y compruebe el commit en GitHub. La publicación del ZIP no aplica los cambios a su copia local.

No se añadieron paquetes, migraciones ni credenciales. Para listas del proyecto con monedas distintas se muestra un mensaje y se permite consultar cada presupuesto por separado, evitando sumar monedas incompatibles.
