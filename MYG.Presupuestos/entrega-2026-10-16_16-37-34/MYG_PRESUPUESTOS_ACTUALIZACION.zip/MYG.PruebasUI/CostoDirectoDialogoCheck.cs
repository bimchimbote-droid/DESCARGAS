using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class CostoDirectoDialogoCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private static readonly string[] Grupos = { "igvManoObra", "igvMateriales", "igvEquipo", "igvSubcontratos" };

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarDialogo(exige);
        VerificarMenuYFormato(exige);
        VerificarPegadoConIgv(exige);
    }

    private static void VerificarPegadoConIgv(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Pegar resumen con costo directo gravado");
        var origen = proyecto.Presupuestos.Single();
        var destino = MYGEstructuraPresupuestos.AgregarPresupuesto(proyecto);
        foreach (var p in proyecto.Presupuestos)
        {
            var material = new MYGInsumo { Descripcion = "Material gravado", Grupo = MYGGrupoRecurso.Materiales, Precio = 100m, IGVPorcentaje = 18m };
            p.Costos.Insumos.Add(material);
            var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false);
            partida.Costos.Cantidad = 1m;
            partida.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 1m });
        }
        origen.Costos.ConfiguracionCostoDirecto = new MYGConfiguracionCostoDirecto { Nombre = "Directo gravado", IncluirIgvMateriales = true };
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { origen }, new()
        {
            new MYGFilaPiePersonalizada { Nombre = "Fórmula dependiente del CD", Identificador = "user_formula",
                Modo = MYGModoFilaResumen.Formula, Formula = "1 / (CD - 100)" }
        });
        var activo = origen;
        int cambios = 0;
        using var panel = new MYGPanelPresupuesto(() => activo, () => { }, () => cambios++,
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarCatalogos(() => "", () => true, () => { });
        using var formulario = new Form { ClientSize = new Size(1500, 900) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); Application.DoEvents();
        typeof(MYGPanelPresupuesto).GetMethod("CopiarResumenPie", Privados).Invoke(panel, null);
        activo = destino; panel.Refrescar(); Application.DoEvents();
        typeof(MYGPanelPresupuesto).GetMethod("PegarResumenPie", Privados).Invoke(panel, null);
        exige(destino.Costos.ConfiguracionCostoDirecto?.IncluirIgvMateriales == true &&
                destino.Costos.ConfiguracionCostoDirecto.Nombre == "Directo gravado" &&
                destino.Costos.PiePersonalizado?.Single().Formula == "1 / (CD - 100)" &&
                MYGMotorPresupuestos.Resumen(destino).Total == MYGMotorPresupuestos.Resumen(origen).Total && cambios == 1,
            "Pegar debe validar las fórmulas con la configuración de IGV copiada y aplicar una sola edición, aunque fueran inválidas sobre el costo directo anterior.");
        formulario.Close();
    }

    private static void VerificarDialogo(Action<bool, string> exige)
    {
        var original = new MYGConfiguracionCostoDirecto { Nombre = "Directo de obra",
            IncluirIgvManoObra = true, IncluirIgvEquipo = true };
        using (var dialogo = new MYGConfigurarCostoDirectoForm(original))
        {
            dialogo.Show();
            Application.DoEvents();
            exige(dialogo.Text == "Configurar tipo de costo" &&
                    Control<TextBox>(dialogo, "nombreCostoDirecto").Text == original.Nombre &&
                    Grupos.Select(n => Control<CheckBox>(dialogo, n).Checked).SequenceEqual(new[] { true, false, true, false }) &&
                    Grupos.Select(n => Control<CheckBox>(dialogo, n).Text).SequenceEqual(
                        new[] { "MANO DE OBRA", "MATERIALES", "EQUIPO", "SUB CONTRATOS" }),
                "Configurar costo directo debe recuperar el nombre y las cuatro elecciones de IGV de los insumos.");
            Control<TextBox>(dialogo, "nombreCostoDirecto").Text = "Cambios descartados";
            foreach (string nombre in Grupos) Control<CheckBox>(dialogo, nombre).Checked = !Control<CheckBox>(dialogo, nombre).Checked;
            Control<Button>(dialogo, "cerrarCostoDirecto").PerformClick();
            exige(dialogo.DialogResult == DialogResult.Cancel && dialogo.Valor == null &&
                    original.Nombre == "Directo de obra" && original.IncluirIgvManoObra &&
                    !original.IncluirIgvMateriales && original.IncluirIgvEquipo && !original.IncluirIgvSubcontratos,
                "Cerrar debe descartar el nombre y las elecciones de IGV sin modificar la configuración original.");
        }
        using (var dialogo = new MYGConfigurarCostoDirectoForm(original))
        {
            dialogo.Show();
            Application.DoEvents();
            var nombre = Control<TextBox>(dialogo, "nombreCostoDirecto");
            var aceptar = Control<Button>(dialogo, "aceptarCostoDirecto");
            nombre.Text = "   ";
            exige(!aceptar.Enabled, "Costo directo debe impedir aceptar un nombre vacío o compuesto sólo por espacios.");
            nombre.Text = "  Costo directo revisado  ";
            for (int indice = 0; indice < Grupos.Length; indice++) Control<CheckBox>(dialogo, Grupos[indice]).Checked = indice % 2 == 1;
            aceptar.PerformClick();
            exige(dialogo.DialogResult == DialogResult.OK && dialogo.Valor != null &&
                    !ReferenceEquals(dialogo.Valor, original) && dialogo.Valor.Nombre == "Costo directo revisado" &&
                    !dialogo.Valor.IncluirIgvManoObra && dialogo.Valor.IncluirIgvMateriales &&
                    !dialogo.Valor.IncluirIgvEquipo && dialogo.Valor.IncluirIgvSubcontratos &&
                    original.Nombre == "Directo de obra" && original.IncluirIgvManoObra && !original.IncluirIgvMateriales,
                "Aceptar debe devolver una configuración independiente con el nombre sin espacios externos y los cuatro grupos elegidos.");
        }
    }

    private static void VerificarMenuYFormato(Action<bool, string> exige)
    {
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Edición y formato del costo directo");
            var primero = proyecto.Presupuestos.Single();
            var segundo = MYGEstructuraPresupuestos.AgregarPresupuesto(proyecto);
            foreach (var presupuesto in proyecto.Presupuestos)
            {
                var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
                partida.Costos.Cantidad = 1m; partida.Costos.PrecioDirecto = 100m;
                presupuesto.Costos.GastosGeneralesPorcentaje = 10m;
            }
            var activo = primero;
            int antes = 0, despues = 0;
            using var panel = new MYGPanelPresupuesto(() => activo, () => antes++, () => despues++,
                _ => { }, () => Task.CompletedTask, _ => { });
            panel.InicializarCatalogos(() => "", () => true, () => { });
            panel.InicializarEstructura(() => proyecto, id => activo = proyecto.Presupuestos.Single(p => p.Id == id),
                _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1500, 900) };
            formulario.Controls.Add(panel);
            formulario.Show();
            panel.Refrescar();
            Application.DoEvents();
            var tabla = Campo<DataGridView>(panel, "tablaPie");
            var alcance = Campo<ComboBox>(panel, "alcancePie");
            foreach (DataGridViewRow fila in tabla.Rows)
            {
                string id = fila.HeaderCell.Tag as string;
                VerificarEditable(id, id == MYGPiePresupuesto.IdCostoDirecto || fila.Tag is MYGConceptoPie,
                    "El pie predeterminado debe permitir Editar fila en Costo directo y en los cuatro porcentajes, conservando Parcial y Total protegidos.");
            }
            exige(Formato(Fila(MYGPiePresupuesto.IdTotal).Cells["IMPORTE"]).Font.Bold,
                "El pie predeterminado debe conservar su Total en negrita.");
            var adicional = new MYGFilaPiePersonalizada { Nombre = "Cargo adicional", Identificador = "CARGO", Porcentaje = 5m };
            MYGPiePresupuesto.EstablecerPersonalizado(new[] { primero }, new() { adicional });
            panel.Refrescar();
            Application.DoEvents();
            VerificarEditable(MYGPiePresupuesto.IdCostoDirecto, true, "Costo directo debe ofrecer Editar fila también en un pie personalizado.");
            VerificarEditable(adicional.Id, true, "Las filas personalizadas deben conservar su opción Editar fila.");
            exige(tabla.Rows.Count == 2 && tabla.Rows.Cast<DataGridViewRow>()
                    .All(f => f.HeaderCell.Tag as string != MYGPiePresupuesto.IdTotal),
                "Un pie personalizado debe mostrar sólo costo directo y la fila añadida, sin fabricar un Total.");
            alcance.SelectedIndex = 1;
            Application.DoEvents();
            VerificarEditable(MYGPiePresupuesto.IdCostoDirecto, true, "Costo directo debe permitir Editar fila en un alcance con pies distintos.");
            VerificarEditable(adicional.Id, false, "Un alcance con pies distintos debe conservar la protección de sus filas personalizadas.");
            VerificarEditable("gastos-generales", false, "Un alcance con pies distintos debe conservar la protección de sus porcentajes predeterminados.");

            alcance.SelectedIndex = 0;
            primero.Costos.EstilosFilasResumen = new()
            {
                [MYGPiePresupuesto.IdCostoDirecto] = new MYGEstiloFilaResumen
                {
                    Fuente = "Tahoma", Tamano = 14m, Negrita = true, Cursiva = true, Tachado = true, Subrayado = true,
                    ColorTexto = "#234567", ColorFondo = "#F1DDBB"
                }
            };
            panel.Refrescar();
            tabla.CurrentCell = Fila(MYGPiePresupuesto.IdCostoDirecto).Cells["CONCEPTO"];
            string firma = MYGProyectoStorage.Firma(proyecto);
            decimal total = MYGMotorPresupuestos.Resumen(primero).Total;
            foreach (bool oscuro in new[] { false, true, false })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                MYG2027_TemaComercial.Aplicar(formulario);
                panel.AplicarTemaPresupuestos();
                panel.Refrescar();
                Application.DoEvents();
                VerificarFormato();
                exige(tabla.CurrentRow?.HeaderCell.Tag as string == MYGPiePresupuesto.IdCostoDirecto &&
                        MYGProyectoStorage.Firma(proyecto) == firma && MYGMotorPresupuestos.Resumen(primero).Total == total &&
                        antes == 0 && despues == 0,
                    "Refrescar y cambiar el tema debe conservar la fila seleccionada, el formato guardado y el total calculado sin crear historial.");
            }
            activo = segundo;
            panel.Refrescar();
            Application.DoEvents();
            exige(Formato(Fila(MYGPiePresupuesto.IdCostoDirecto).Cells["CONCEPTO"]).BackColor.ToArgb() != ColorTranslator.FromHtml("#F1DDBB").ToArgb() &&
                    segundo.Costos.EstilosFilasResumen == null,
                "Cambiar de presupuesto debe mostrar su propio formato sin transferirle el color del costo directo del presupuesto anterior.");
            activo = primero;
            panel.Refrescar();
            Application.DoEvents();
            VerificarFormato();
            exige(MYGProyectoStorage.Firma(proyecto) == firma && antes == 0 && despues == 0,
                "Regresar al presupuesto debe recuperar el formato de su fila sin modificar los documentos ni el historial.");
            formulario.Close();

            DataGridViewRow Fila(string id) => tabla.Rows.Cast<DataGridViewRow>().Single(f => f.HeaderCell.Tag as string == id);
            void VerificarEditable(string id, bool esperado, string mensaje)
            {
                tabla.CurrentCell = Fila(id).Cells["CONCEPTO"];
                typeof(MYGPanelPresupuesto).GetMethod("ActualizarMenuResumen", Privados).Invoke(panel, null);
                exige(tabla.ContextMenuStrip.Items["editarFilaResumen"].Enabled == esperado, mensaje);
            }
            void VerificarFormato()
            {
                foreach (DataGridViewCell celda in Fila(MYGPiePresupuesto.IdCostoDirecto).Cells)
                {
                    var formato = Formato(celda);
                    exige(formato.ForeColor.ToArgb() == ColorTranslator.FromHtml("#234567").ToArgb() &&
                            formato.BackColor.ToArgb() == ColorTranslator.FromHtml("#F1DDBB").ToArgb() &&
                            formato.Font.Name == "Tahoma" && Math.Abs(formato.Font.SizeInPoints - 14f) < .01f &&
                            formato.Font.Bold && formato.Font.Italic && formato.Font.Strikeout && formato.Font.Underline,
                        "La fuente, tamaño, efectos y colores del costo directo deben conservarse en todas sus columnas tras refrescar y cambiar el tema.");
                }
                exige(Fila(adicional.Id).Cells.Cast<DataGridViewCell>()
                        .All(c => Formato(c).BackColor.ToArgb() != ColorTranslator.FromHtml("#F1DDBB").ToArgb()) &&
                        tabla.Rows.Cast<DataGridViewRow>().All(f => f.HeaderCell.Tag as string != MYGPiePresupuesto.IdTotal),
                    "El formato del costo directo debe afectar sólo su fila y conservar los conceptos personalizados sin generar un Total.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static DataGridViewCellStyle Formato(DataGridViewCell celda)
    {
        var evento = new DataGridViewCellFormattingEventArgs(celda.ColumnIndex, celda.RowIndex, celda.Value,
            typeof(string), celda.InheritedStyle.Clone());
        typeof(DataGridView).GetMethod("OnCellFormatting", Privados).Invoke(celda.DataGridView, new object[] { evento });
        return evento.CellStyle;
    }

    private static T Control<T>(Form dialogo, string nombre) where T : Control =>
        (T)dialogo.Controls.Find(nombre, true).Single();
    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
}
