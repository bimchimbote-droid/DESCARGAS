using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Panel panelInsumosContexto, cabeceraInsumosContexto;
    private TabControl pestanasInsumosContexto;
    private DataGridView tablaInsumosContexto;
    private Label presupuestoInsumosContexto, seleccionInsumosContexto, totalInsumosContexto;
    private IReadOnlyList<MYGInsumoContexto> datosInsumosContexto = Array.Empty<MYGInsumoContexto>();
    private readonly HashSet<MYGGrupoRecurso> gruposInsumosContextoContraidos = new();
    private readonly string[] filtrosInsumosContexto = new string[6];
    private bool reconstruyendoInsumosContexto;
    private string alcanceInsumosContexto, errorInsumosContexto;
    private decimal importeInsumosContexto;
    private bool cabeceraInsumosContextoExpandida = true;

    // Este panel ocupa el mismo lado derecho que el ACU. Ocultarlo conserva
    // la pestaña de detalle elegida para regresar a ella al elegir una partida.
    private Control PrepararInsumosContexto()
    {
        panelInsumosContexto = new Panel { Name = "presupuesto_insumos_contexto", Dock = DockStyle.Fill, Visible = false };
        tablaInsumosContexto = Tabla();
        tablaInsumosContexto.Name = "insumos_contexto_tabla";
        tablaInsumosContexto.AccessibleName = "Lista agrupada de insumos de la selección";
        tablaInsumosContexto.ReadOnly = false;
        tablaInsumosContexto.RowHeadersVisible = true;
        tablaInsumosContexto.RowHeadersWidth = 29;
        tablaInsumosContexto.AllowUserToResizeRows = false;
        tablaInsumosContexto.EditMode = DataGridViewEditMode.EditOnEnter;
        Columna(tablaInsumosContexto, "COD", "Cod.", 100);
        Columna(tablaInsumosContexto, "DESC", "Descripción", 235);
        Columna(tablaInsumosContexto, "PROVEEDOR", "Proveedor", 135);
        Columna(tablaInsumosContexto, "CANT", "Cantidad", 115);
        Columna(tablaInsumosContexto, "PRECIO", "Precio Unit.", 100);
        Columna(tablaInsumosContexto, "TOTAL", "Total", 110);
        tablaInsumosContexto.Columns["DESC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        tablaInsumosContexto.Columns["DESC"].MinimumWidth = 170;
        foreach (DataGridViewColumn c in tablaInsumosContexto.Columns) c.ReadOnly = false;
        tablaInsumosContexto.Columns["CANT"].DefaultCellStyle.Format = "";
        MYG2027_TemaComercial.DesactivarFilasAlternas(tablaInsumosContexto);
        tablaInsumosContexto.CellValueChanged += (_, e) =>
        {
            if (!reconstruyendoInsumosContexto && e.RowIndex == 0 && e.ColumnIndex >= 0)
                filtrosInsumosContexto[e.ColumnIndex] = Convert.ToString(tablaInsumosContexto.Rows[0].Cells[e.ColumnIndex].Value) ?? "";
        };
        tablaInsumosContexto.CellEndEdit += (_, e) =>
        {
            if (e.RowIndex != 0 || reconstruyendoInsumosContexto) return;
            // DataGridView debe terminar primero de retirar su editor.
            if (IsHandleCreated) BeginInvoke((Action)(() => { if (!IsDisposed) ActualizarInsumosContexto(); }));
        };
        tablaInsumosContexto.CellClick += (_, e) =>
        {
            if (e.RowIndex > 0 && tablaInsumosContexto.Rows[e.RowIndex].Tag is MYGGrupoRecurso grupo)
                AlternarGrupoInsumosContexto(grupo);
        };
        tablaInsumosContexto.KeyDown += (_, e) =>
        {
            if (e.KeyCode is Keys.Enter or Keys.Space && tablaInsumosContexto.CurrentRow?.Tag is MYGGrupoRecurso grupo)
            { AlternarGrupoInsumosContexto(grupo); e.Handled = e.SuppressKeyPress = true; }
        };
        tablaInsumosContexto.CellPainting += DibujarCeldaInsumosContexto;
        tablaInsumosContexto.RowPostPaint += DibujarGrupoInsumosContexto;
        totalInsumosContexto = new Label { Name = "insumos_contexto_total", Dock = DockStyle.Bottom, Height = 28,
            TextAlign = ContentAlignment.MiddleRight, Padding = new(4), Font = negrita };
        cabeceraInsumosContexto = new Panel { Dock = DockStyle.Top, Height = 110, Padding = new(0, 0, 0, 4) };
        var herramientas = new TableLayoutPanel { Dock = DockStyle.Right, Width = 100, RowCount = 2, ColumnCount = 3,
            Padding = new(3), Margin = new(0) };
        herramientas.ColumnStyles.Add(new(SizeType.Percent, 33.33F));
        herramientas.ColumnStyles.Add(new(SizeType.Percent, 33.33F));
        herramientas.ColumnStyles.Add(new(SizeType.Percent, 33.34F));
        herramientas.RowStyles.Add(new(SizeType.Percent, 50)); herramientas.RowStyles.Add(new(SizeType.Percent, 50));
        Button Icono(string nombre, string icono, string ayuda, Action accion)
        {
            var imagen = MYGIconos.Obtener(icono); iconosHerramientas.Add(imagen);
            var boton = new Button { Name = "insumos_contexto_" + nombre, Image = imagen, ImageAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill, Margin = new(0), FlatStyle = FlatStyle.Flat, AccessibleName = ayuda };
            boton.FlatAppearance.BorderSize = 0;
            var ayudaBoton = new ToolTip(); ayudaBoton.SetToolTip(boton, ayuda);
            boton.Disposed += (_, _) => ayudaBoton.Dispose();
            boton.Click += (_, _) => Intentar(accion);
            return boton;
        }
        herramientas.Controls.Add(Icono("informacion", "insumos", "Información de la lista de insumos", MostrarInformacionInsumosContexto), 1, 0);
        herramientas.Controls.Add(Icono("copiar", "catalogo", "Copiar la lista visible", CopiarInsumosContexto), 0, 1);
        herramientas.Controls.Add(Icono("excel", "excel", "Exportar la lista visible a Excel", ExportarInsumosContexto), 1, 1);
        herramientas.Controls.Add(Icono("imprimir", "imprimir", "Vista previa e impresión de la lista visible", ImprimirInsumosContexto), 2, 1);
        var datosCabecera = new Panel { Dock = DockStyle.Fill };
        pestanasInsumosContexto = new TabControl { Name = "insumos_contexto_pestanas", Dock = DockStyle.Top, Height = 35,
            Alignment = TabAlignment.Top, Padding = new(10, 5) };
        pestanasInsumosContexto.TabPages.Add(new TabPage("Lista de insumos del presupuesto"));
        pestanasInsumosContexto.TabPages.Add(new TabPage("Lista de insumos del proyecto"));
        MYGTemaPestanas.Preparar(pestanasInsumosContexto);
        pestanasInsumosContexto.SelectedIndexChanged += (_, _) => { if (!cargando) ActualizarInsumosContexto(); };
        presupuestoInsumosContexto = new Label { Name = "insumos_contexto_presupuesto", Dock = DockStyle.Top, Height = 29,
            TextAlign = ContentAlignment.MiddleLeft, Padding = new(10, 0, 4, 0), AutoEllipsis = true };
        seleccionInsumosContexto = new Label { Name = "insumos_contexto_seleccion", Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.TopLeft, Padding = new(10, 0, 4, 0), AutoEllipsis = true };
        datosCabecera.Controls.Add(seleccionInsumosContexto);
        datosCabecera.Controls.Add(presupuestoInsumosContexto);
        var filaPestanas = new Panel { Dock = DockStyle.Top, Height = 40 };
        pestanasInsumosContexto.Dock = DockStyle.Fill;
        var ojo = CrearIconoCabeceraInsumosContexto(false); var ojoCerrado = CrearIconoCabeceraInsumosContexto(true);
        iconosHerramientas.Add(ojo); iconosHerramientas.Add(ojoCerrado);
        var mostrarCabecera = new Button { Name = "insumos_contexto_cabecera", Image = ojo, Dock = DockStyle.Right, Width = 26,
            FlatStyle = FlatStyle.Flat, AccessibleName = "Ocultar o mostrar datos de la lista de insumos" };
        mostrarCabecera.FlatAppearance.BorderSize = 0;
        mostrarCabecera.Click += (_, _) =>
        {
            cabeceraInsumosContextoExpandida = !cabeceraInsumosContextoExpandida;
            presupuestoInsumosContexto.Visible = seleccionInsumosContexto.Visible = cabeceraInsumosContextoExpandida;
            cabeceraInsumosContexto.Height = (int)Math.Round((cabeceraInsumosContextoExpandida ? 110 : 72) * DeviceDpi / 96F);
            mostrarCabecera.Image = cabeceraInsumosContextoExpandida ? ojo : ojoCerrado;
        };
        filaPestanas.Controls.Add(pestanasInsumosContexto); filaPestanas.Controls.Add(mostrarCabecera);
        datosCabecera.Controls.Add(filaPestanas);
        cabeceraInsumosContexto.Controls.Add(datosCabecera); cabeceraInsumosContexto.Controls.Add(herramientas);
        panelInsumosContexto.Controls.Add(tablaInsumosContexto);
        panelInsumosContexto.Controls.Add(totalInsumosContexto);
        panelInsumosContexto.Controls.Add(cabeceraInsumosContexto);
        var menu = new ContextMenuStrip();
        menu.Items.Add("Quitar filtros", null, (_, _) =>
        { tablaInsumosContexto.EndEdit(); Array.Clear(filtrosInsumosContexto); ReconstruirTablaInsumosContexto(); });
        menu.Items.Add("Expandir grupos", null, (_, _) => { gruposInsumosContextoContraidos.Clear(); ReconstruirTablaInsumosContexto(); });
        menu.Items.Add("Contraer grupos", null, (_, _) =>
        { foreach (var g in datosInsumosContexto.Select(i => i.Grupo)) gruposInsumosContextoContraidos.Add(g); ReconstruirTablaInsumosContexto(); });
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Copiar lista", null, (_, _) => Intentar(CopiarInsumosContexto));
        menu.Items.Add("Exportar a Excel", null, (_, _) => Intentar(ExportarInsumosContexto));
        menu.Items.Add("Vista previa e impresión", null, (_, _) => Intentar(ImprimirInsumosContexto));
        tablaInsumosContexto.ContextMenuStrip = menu;
        Disposed += (_, _) => menu.Dispose();
        AplicarTemaInsumosContexto();
        return panelInsumosContexto;
    }

    private bool EsSeleccionInsumosContexto => nodoEstructura is MYGPresupuestoDocumento ||
        nodoEstructura is ItemPresupuestoDelphin titulo && MYGProyectoStorage.EsTitulo(titulo);

    private void MostrarInsumosContexto()
    {
        if (panelInsumosContexto == null) return;
        bool mostrar = EsSeleccionInsumosContexto;
        panelInsumosContexto.Visible = mostrar;
        detalle.Visible = !mostrar; pie.Visible = !mostrar;
        if (mostrar) { panelInsumosContexto.BringToFront(); ActualizarInsumosContexto(); }
    }

    private void ActualizarInsumosContexto()
    {
        if (panelInsumosContexto == null || !EsSeleccionInsumosContexto || IsDisposed || tablaInsumosContexto.IsCurrentCellInEditMode) return;
        var presupuesto = PropietarioEstructura(nodoEstructura) ?? P;
        var titulo = NodoEstructuraVigente(nodoEstructura) as ItemPresupuestoDelphin;
        bool proyecto = pestanasInsumosContexto.SelectedIndex == 1;
        string alcance = proyecto ? "proyecto" : presupuesto?.Id + ":" + titulo?.Id;
        if (alcanceInsumosContexto != alcance)
        { Array.Clear(filtrosInsumosContexto); gruposInsumosContextoContraidos.Clear(); alcanceInsumosContexto = alcance; }
        presupuestoInsumosContexto.Text = proyecto
            ? "Proyecto:     " + (obtenerProyectoEstructura?.Invoke()?.Nombre ?? "Proyecto")
            : "Presupuesto:     " + (presupuesto?.Nombre ?? "");
        seleccionInsumosContexto.Text = proyecto ? "Todos los presupuestos del proyecto" : titulo == null ? ""
            : CodigoEstructura(presupuesto, titulo) + "     " + titulo.Descripcion;
        errorInsumosContexto = null;
        try
        {
            datosInsumosContexto = MYGListaInsumosContexto.Crear(PresupuestosEstructura, proyecto ? null : presupuesto, proyecto ? null : titulo);
        }
        catch (Exception ex)
        {
            datosInsumosContexto = Array.Empty<MYGInsumoContexto>();
            errorInsumosContexto = ex.Message;
        }
        ReconstruirTablaInsumosContexto();
    }

    private static string[] TextosInsumoContexto(MYGInsumoContexto i) => new[]
    {
        i.Codigo ?? "", i.Descripcion ?? "", i.Proveedor ?? "", CantidadInsumoContexto(i),
        i.Precio.ToString("N2", CultureInfo.InvariantCulture), i.Total.ToString("N2", CultureInfo.InvariantCulture)
    };
    private static string CantidadInsumoContexto(MYGInsumoContexto i) =>
        i.Cantidad.ToString("N4", CultureInfo.InvariantCulture) + "  " + i.Unidad;
    private IEnumerable<MYGInsumoContexto> InsumosContextoFiltrados() => datosInsumosContexto.Where(i =>
    {
        var valores = TextosInsumoContexto(i);
        for (int c = 0; c < valores.Length; c++)
            if (!string.IsNullOrWhiteSpace(filtrosInsumosContexto[c]) &&
                !valores[c].Contains(filtrosInsumosContexto[c].Trim(), StringComparison.OrdinalIgnoreCase)) return false;
        return true;
    });

    private void ReconstruirTablaInsumosContexto()
    {
        if (tablaInsumosContexto == null || reconstruyendoInsumosContexto || IsDisposed || tablaInsumosContexto.IsCurrentCellInEditMode) return;
        reconstruyendoInsumosContexto = true; tablaInsumosContexto.SuspendLayout();
        try
        {
            tablaInsumosContexto.Rows.Clear();
            var filtro = tablaInsumosContexto.Rows[tablaInsumosContexto.Rows.Add(filtrosInsumosContexto.Cast<object>().ToArray())];
            filtro.Tag = "filtros"; filtro.Frozen = true;
            filtro.DefaultCellStyle.BackColor = MYG2027_TemaComercial.SuperficieAlterna;
            foreach (DataGridViewCell c in filtro.Cells)
            { c.ReadOnly = false; c.ToolTipText = "Escriba un filtro y pulse Enter. Clic derecho: Quitar filtros."; }
            var visibles = InsumosContextoFiltrados().ToArray();
            importeInsumosContexto = visibles.Sum(i => i.Total);
            int numero = 0;
            foreach (var grupo in visibles.GroupBy(i => i.Grupo).OrderBy(g => g.Key))
            {
                var filaGrupo = tablaInsumosContexto.Rows[tablaInsumosContexto.Rows.Add(MYGMotorPresupuestos.Grupo(grupo.Key).ToUpperInvariant(), null, null, null, null, grupo.Sum(i => i.Total))];
                filaGrupo.Tag = grupo.Key; filaGrupo.ReadOnly = true;
                filaGrupo.DefaultCellStyle.Font = negrita;
                filaGrupo.DefaultCellStyle.BackColor = AzulClaro;
                filaGrupo.Cells[0].ToolTipText = "Clic para expandir o contraer " + MYGMotorPresupuestos.Grupo(grupo.Key);
                if (gruposInsumosContextoContraidos.Contains(grupo.Key)) continue;
                foreach (var i in grupo.OrderBy(i => i.Codigo, StringComparer.OrdinalIgnoreCase).ThenBy(i => i.Descripcion, StringComparer.OrdinalIgnoreCase))
                {
                    var fila = tablaInsumosContexto.Rows[tablaInsumosContexto.Rows.Add(i.Codigo, i.Descripcion, i.Proveedor, CantidadInsumoContexto(i), i.Precio, i.Total)];
                    fila.Tag = i; fila.ReadOnly = true;
                    fila.HeaderCell.Value = (++numero).ToString(CultureInfo.InvariantCulture);
                    fila.Cells["CANT"].ToolTipText = i.Unidad;
                }
            }
            totalInsumosContexto.Text = errorInsumosContexto ?? "Total:     " + importeInsumosContexto.ToString("N2", CultureInfo.InvariantCulture);
            totalInsumosContexto.AccessibleDescription = errorInsumosContexto ?? "Importe total de los insumos filtrados";
            tablaInsumosContexto.ClearSelection(); tablaInsumosContexto.CurrentCell = null;
        }
        finally { tablaInsumosContexto.ResumeLayout(); reconstruyendoInsumosContexto = false; }
    }

    private void AlternarGrupoInsumosContexto(MYGGrupoRecurso grupo)
    {
        if (!gruposInsumosContextoContraidos.Add(grupo)) gruposInsumosContextoContraidos.Remove(grupo);
        ReconstruirTablaInsumosContexto();
        var fila = tablaInsumosContexto.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is MYGGrupoRecurso g && g == grupo);
        if (fila != null) { tablaInsumosContexto.CurrentCell = fila.Cells[0]; fila.Selected = true; }
    }

    private void DibujarCeldaInsumosContexto(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
        if (e.RowIndex == 0 && string.IsNullOrEmpty(Convert.ToString(e.Value)))
        {
            e.Paint(e.ClipBounds, DataGridViewPaintParts.All); e.Handled = true;
            TextRenderer.DrawText(e.Graphics, e.ColumnIndex is 3 or 4 or 5 ? "=" : "abc", tablaInsumosContexto.Font,
                Rectangle.Inflate(e.CellBounds, -6, 0), MYG2027_TemaComercial.Secundario,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPrefix);
            return;
        }
        if (tablaInsumosContexto.Rows[e.RowIndex].Tag is not MYGGrupoRecurso grupo || e.ColumnIndex == tablaInsumosContexto.Columns["TOTAL"].Index) return;
        e.Paint(e.ClipBounds, DataGridViewPaintParts.Background | DataGridViewPaintParts.SelectionBackground); e.Handled = true;
    }

    private void DibujarGrupoInsumosContexto(object sender, DataGridViewRowPostPaintEventArgs e)
    {
        if (tablaInsumosContexto.Rows[e.RowIndex].Tag is not MYGGrupoRecurso grupo) return;
        var primera = tablaInsumosContexto.GetCellDisplayRectangle(0, e.RowIndex, false);
        var total = tablaInsumosContexto.GetCellDisplayRectangle(tablaInsumosContexto.Columns["TOTAL"].Index, e.RowIndex, false);
        var area = new Rectangle(Math.Max(tablaInsumosContexto.RowHeadersWidth + 5, primera.X + 5), primera.Y,
            Math.Max(0, Math.Min(total.Left, tablaInsumosContexto.ClientSize.Width) - Math.Max(tablaInsumosContexto.RowHeadersWidth + 5, primera.X + 5) - 5), primera.Height);
        string texto = (gruposInsumosContextoContraidos.Contains(grupo) ? "▸  " : "▾  ") + MYGMotorPresupuestos.Grupo(grupo).ToUpperInvariant();
        TextRenderer.DrawText(e.Graphics, texto, negrita, area,
            e.State.HasFlag(DataGridViewElementStates.Selected) ? tablaInsumosContexto.DefaultCellStyle.SelectionForeColor : MYG2027_TemaComercial.Texto,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPrefix);
    }

    private void ConfirmarFiltrosInsumosContexto()
    {
        if (!tablaInsumosContexto.EndEdit()) throw new InvalidOperationException("Confirme el filtro antes de continuar.");
        ReconstruirTablaInsumosContexto();
        if (errorInsumosContexto != null) throw new InvalidOperationException(errorInsumosContexto);
    }

    private MYGHojaReporteProyecto CrearReporteInsumosContexto()
    {
        ConfirmarFiltrosInsumosContexto();
        string[] columnas = { "Cod.", "Descripción", "Proveedor", "Cantidad", "Precio Unit.", "Total" };
        var filas = new List<object[]>(); var grupos = new HashSet<int>();
        foreach (DataGridViewRow fila in tablaInsumosContexto.Rows)
        {
            if (fila.Tag is MYGGrupoRecurso grupo)
            { grupos.Add(filas.Count + 2); filas.Add(new object[] { MYGMotorPresupuestos.Grupo(grupo).ToUpperInvariant(), "", "", "", "", fila.Cells["TOTAL"].Value }); }
            else if (fila.Tag is MYGInsumoContexto)
                filas.Add(fila.Cells.Cast<DataGridViewCell>().Select(c => c.Value).ToArray());
        }
        filas.Add(new object[] { "Total:", "", "", "", "", importeInsumosContexto });
        var hojaLista = MYGExcelPresupuestos.Tabla("Lista de insumos", columnas, filas);
        hojaLista.Filas = filas.Count + 1; hojaLista.CeldaTotal = "F" + hojaLista.Filas;
        hojaLista.AreaImpresion = "A1:F" + hojaLista.Filas;
        hojaLista.OrientacionPagina = "Horizontal"; hojaLista.RepetirTitulos = true; hojaLista.FilasInmovilizadas = 1;
        hojaLista.AnchosColumnas = new() { [1] = 110, [2] = 280, [3] = 150, [4] = 120, [5] = 100, [6] = 110 };
        foreach (var celda in hojaLista.Celdas)
        {
            var coordenadas = MYGHojaCalculo.Coordenadas(celda.Key);
            celda.Value.Bordes = true;
            if (coordenadas.Columna >= 5 && coordenadas.Fila > 1)
            { celda.Value.FormatoNumero = "#,##0.00"; celda.Value.AlineacionHorizontal = "Derecha"; }
            if (grupos.Contains(coordenadas.Fila) || coordenadas.Fila == hojaLista.Filas)
            { celda.Value.Negrita = true; celda.Value.ColorFondo = "E6EFF7"; }
        }
        var metadatos = new[] { new KeyValuePair<string, string>("Alcance", presupuestoInsumosContexto.Text),
            new KeyValuePair<string, string>("Selección", seleccionInsumosContexto.Text) };
        return new MYGHojaReporteProyecto(pestanasInsumosContexto.SelectedTab.Text, hojaLista, metadatos);
    }

    private void ExportarInsumosContexto()
    {
        var reporte = CrearReporteInsumosContexto();
        using var dialogo = new SaveFileDialog { Filter = "Lista de insumos Excel (*.xlsx)|*.xlsx", DefaultExt = "xlsx",
            AddExtension = true, FileName = "Lista de insumos.xlsx" };
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            MYGExcelPresupuestos.Guardar(dialogo.FileName, MYGReportesExcel.CrearHojas(new[] { reporte }));
    }
    private void ImprimirInsumosContexto()
    {
        var reporte = CrearReporteInsumosContexto();
        MYGReportesImpresion.Imprimir(this, reporte.Titulo, new[] { reporte });
    }
    private void CopiarInsumosContexto()
    {
        var reporte = CrearReporteInsumosContexto();
        var texto = new StringBuilder(reporte.Titulo).AppendLine().AppendLine(presupuestoInsumosContexto.Text).AppendLine(seleccionInsumosContexto.Text);
        for (int f = 1; f <= reporte.Hoja.Filas; f++)
            texto.AppendLine(string.Join("\t", Enumerable.Range(1, 6).Select(c =>
                reporte.Hoja.Celdas.GetValueOrDefault(MYGHojaCalculo.Columna(c) + f)?.Contenido ?? "")));
        Clipboard.SetText(texto.ToString());
    }
    private void MostrarInformacionInsumosContexto()
    {
        ConfirmarFiltrosInsumosContexto();
        var visibles = InsumosContextoFiltrados().ToArray();
        MessageBox.Show(this, presupuestoInsumosContexto.Text + "\n" + seleccionInsumosContexto.Text + "\n\n" +
            string.Join("\n", visibles.GroupBy(i => i.Grupo).Select(g => MYGMotorPresupuestos.Grupo(g.Key) + ": " + g.Count() + " insumo(s)   " + g.Sum(i => i.Total).ToString("N2", CultureInfo.InvariantCulture))) +
            "\n\n" + totalInsumosContexto.Text, "Lista de insumos", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    private void AplicarTemaInsumosContexto()
    {
        if (panelInsumosContexto == null) return;
        panelInsumosContexto.BackColor = MYG2027_TemaComercial.Superficie;
        cabeceraInsumosContexto.BackColor = totalInsumosContexto.BackColor = AzulClaro;
        panelInsumosContexto.ForeColor = totalInsumosContexto.ForeColor = MYG2027_TemaComercial.Texto;
        AplicarTemaTablaPresupuesto(tablaInsumosContexto);
        foreach (TabPage pagina in pestanasInsumosContexto.TabPages) pagina.BackColor = AzulClaro;
        MYGTemaPestanas.Aplicar(pestanasInsumosContexto);
        void Colores(Control control)
        {
            foreach (Control hijo in control.Controls)
            {
                if (hijo is Button) { hijo.BackColor = AzulClaro; hijo.ForeColor = MYG2027_TemaComercial.Texto; }
                Colores(hijo);
            }
        }
        Colores(cabeceraInsumosContexto);
        foreach (DataGridViewRow fila in tablaInsumosContexto.Rows)
        {
            if (fila.Tag is MYGGrupoRecurso) fila.DefaultCellStyle.BackColor = AzulClaro;
            else if (Equals(fila.Tag, "filtros"))
            { fila.DefaultCellStyle.BackColor = MYG2027_TemaComercial.SuperficieAlterna; fila.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto; }
        }
    }

    private static Bitmap CrearIconoCabeceraInsumosContexto(bool oculto)
    {
        var imagen = new Bitmap(22, 22);
        using var g = Graphics.FromImage(imagen);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        using var lapiz = new Pen(Color.FromArgb(73, 117, 162), 1.7F);
        using var tinta = new SolidBrush(Color.FromArgb(73, 117, 162));
        using var contorno = new System.Drawing.Drawing2D.GraphicsPath();
        contorno.AddBezier(2, 11, 7, 4, 15, 4, 20, 11);
        contorno.AddBezier(20, 11, 15, 18, 7, 18, 2, 11);
        g.DrawPath(lapiz, contorno); g.FillEllipse(tinta, 8, 8, 6, 6);
        if (oculto) g.DrawLine(lapiz, 3, 3, 19, 19);
        return imagen;
    }
}
