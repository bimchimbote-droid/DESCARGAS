# Corrección de importación y guardado Delphin

Base de código: `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`,
commit `9a2cc85af20ced83e908f60bc68f5d01a4dc9c37`.

## Causa y comportamiento corregido

Delphin puede conservar filas de partidas antiguas cuyo padre ya no existe.
MYG las mostraba creando grupos «TÍTULO ORIGINAL AUSENTE». La importación ahora
excluye esas ramas del árbol visible sin inventar títulos, reasignar partidas por
su numeración ni borrar las filas originales. Los nombres editados y las partidas
vigentes se mantienen. Las referencias cruzadas inválidas y los ciclos siguen
siendo errores de validación.

Los documentos guardados por versiones anteriores se leen con compatibilidad:
se retiran sólo agrupaciones automáticas identificadas con certeza. Un grupo
renombrado expresamente se conserva. El guardado protege también los recursos y
análisis auxiliares de las ramas nativas que dejaron de mostrarse.

La misma compatibilidad se aplica al cronograma: una tarea o predecesora
automática de esas ramas no se vuelve a introducir al reabrir. Esto evita que
un segundo guardado sin editar se interprete como un cambio de vínculos. Las
relaciones originales siguen en SQLite; las ediciones reales mantienen las
validaciones de seguridad del cronograma.

El primer guardado copiaba todo el catálogo Delphin a tablas MYG, incluidos JSON
de insumos, plantillas e índices de sus nodos. Ahora el catálogo consulta las
tablas nativas y guarda extensiones individuales sólo cuando hacen falta. Conserva
las comprobaciones de revisión, códigos, registro automático y protección de
entradas utilizadas. Al copiar el catálogo a otra hoja incluye la parte nativa.

En bases previamente guardadas se retiran copias de catálogo sólo si tienen
revisión 1, no fueron registradas como ediciones propias y sus columnas, JSON
completo e índices coinciden con los datos nativos. Cualquier diferencia conserva
la entrada. La compactación posterior recupera páginas libres sin eliminar datos
nativos. No se promete que un archivo MYG mida exactamente lo mismo que Delphin:
MYG necesita sus índices de presupuesto, registro de sincronización y extensiones.

## Comparación de los archivos recibidos

| Archivo | Tamaño descomprimido |
| --- | ---: |
| Base Delphin | 47.216.640 bytes |
| Base guardada en MYG | 67.767.296 bytes |
| Diferencia | 20.550.656 bytes (19,60 MiB) |

La tabla nativa `producto` contiene los mismos 9.874 registros y valores en ambas
bases. El aumento principal procede de las copias adicionales de catálogo:
`catalogo_insumo` ocupa aproximadamente 10,20 MB; `catalogo_partida`, 2,70 MB; sus
nodos, 2,04 MB, además de índices. No se encontró una duplicación de productos
nativos. Las muestras sí contienen otras diferencias de edición: no son dos
archivos idénticos salvo su formato y no se han eliminado esas diferencias.

Los originales se mantuvieron intactos. Las comprobaciones de guardado usan
copias independientes. Ninguna base privada forma parte de esta entrega.

Resultados reales después de guardar y reabrir dos veces los dos proyectos
(ocho presupuestos) de cada copia:

| Copia probada | Tamaño final |
| --- | ---: |
| Delphin guardada con la corrección | 56.271.872 bytes |
| MYG anterior guardada con la corrección | 56.344.576 bytes |

La copia MYG se redujo 11.422.720 bytes (10,89 MiB), aun habiendo guardado ambos
proyectos en la prueba. La base Delphin adquiere índices y extensiones necesarios
de MYG: esta corrección no elimina toda diferencia de tamaño entre los programas.
En ambas copias las tablas adicionales `catalogo_insumo`, `catalogo_partida` y
`catalogo_partida_nodo` quedaron sin copias automáticas; la API siguió mostrando
9.874 insumos y 116 entradas de catálogo desde su origen nativo.

`integrity_check` devuelve `ok`; los 9.874 productos nativos conservan exactamente
sus valores. Se compararon también filas de ramas físicamente ausentes y sus
subtotales/composiciones, que permanecen intactos. `foreign_key_check` devuelve las
mismas 39 incidencias que ya tenían los originales, sin añadir otras. Las
huellas SHA-256 de los archivos originales no cambiaron. No reaparecieron títulos
automáticos ni falló el segundo guardado de ninguna de las dos copias.

## Instalación manual

1. Respalde la carpeta del proyecto y las bases SQLite. Confirme o guarde sus
   cambios locales antes de sustituir código.
2. Extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip` y copie su contenido a la raíz
   de `MYG.Presupuestos`, conservando las rutas relativas. Los archivos existentes
   se entregan completos para reemplazarlos; los nuevos se deben crear. No hay
   archivos que eliminar.
3. Si modificó estos mismos archivos después del commit base, compare y combine
   los cambios: reemplazarlos directamente puede perder su trabajo posterior.
4. Restaure y compile con .NET 10. La aplicación Desktop requiere Windows; el
   conector requiere Revit 2027 o sus paquetes de referencias para compilar.
5. Abra primero una copia de su base. Revise los nombres, numeración, cantidades,
   ACU y totales; guarde, cierre y vuelva a abrir dos veces. Compruebe que los
   grupos automáticos ya no aparecen y que siguen disponibles sus catálogos.

No hay que ejecutar SQL manual, cambiar dependencias ni volver a importar las
bases. La adaptación segura se ejecuta durante la lectura/guardado habituales.

## Compilación y pruebas reproducibles

Desde la raíz del repositorio, con SDK .NET 10.0.100:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --catalogo-nativo-ligero
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --recuperacion-jerarquia-delphin
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --titulos-nativos
```

En Windows con Revit instalado puede omitir `UseRevitReferencePackages=true` para
utilizar las DLL locales, según `LEEME.md`. La ejecución visual de Windows Forms,
el programa Delphin y Revit no se verifican mediante una compilación en Linux.

Resultados de esta entrega:

- Solución completa Release, SDK .NET 10.0.100: 0 errores y 0 advertencias.
- Suite principal ejecutada: 842 comprobaciones aprobadas. Incluye regresiones
  de catálogo ligero, compatibilidad de jerarquía y repetición del guardado del
  cronograma. Los casos que necesitan otras muestras externas y Named Pipes de
  Windows se informan como omitidos, no como aprobados.
- Títulos nativos y transporte nube: 26 comprobaciones aprobadas.
- La suite completa de nube se ejecutó y mantiene un fallo que ya existía en el
  commit base: `PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`, línea
  399, sobre la fase del diagnóstico de renovación de sesión. No se modificó esa
  funcionalidad. Los grupos posteriores a la excepción no se ejecutaron.
- Pendiente comprobación visual de la aplicación en Windows, apertura con el
  programa Delphin y funcionamiento dentro de Revit 2027.

## Publicación del código por el usuario

La publicación del ZIP en `bimchimbote-droid/DESCARGAS` no aplica los cambios a su
repositorio de código. Después de instalar y validar, use **Cambios de Git** en
Visual Studio para revisar el diff, hacer Commit y después Push a su rama de
trabajo. Compruebe el commit y la rama en GitHub. Esta entrega no hace Push ni
modifica ramas de `MYG.Presupuestos`.
