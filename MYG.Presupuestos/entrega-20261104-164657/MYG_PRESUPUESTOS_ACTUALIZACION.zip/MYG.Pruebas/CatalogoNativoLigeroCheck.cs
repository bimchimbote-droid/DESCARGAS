using System;
using System.IO;
using System.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class CatalogoNativoLigeroCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "catalogo-delphin-ligero.sqlite");
        CrearNativa(ruta);
        var insumosAntes = MYGCatalogos.Listar(ruta, false);
        var partidasAntes = MYGCatalogos.Listar(ruta, true);
        Exige(insumosAntes.Count == 2 && partidasAntes.Count == 1, "La muestra nativa no tiene sus entradas.");
        using (var c = MYGBaseDatos.Abrir(ruta, true))
            Exige(Valor(c, "SELECT count(*) FROM catalogo_insumo") == 0 &&
                Valor(c, "SELECT count(*) FROM catalogo_partida") == 0, "La escritura duplicó el catálogo nativo.");
        Exige(MYGCatalogos.Listar(ruta, false).Count == 2 && MYGCatalogos.Listar(ruta, true).Count == 1,
            "El catálogo dejó de estar disponible después de crear extensiones.");
        var insumo = MYGCatalogos.LeerInsumo(ruta, insumosAntes[0].Id, 1);
        var plantilla = MYGCatalogos.LeerPartida(ruta, partidasAntes[0].Id, 1);
        Exige(plantilla.Partidas.Count == 1 && insumo.Precio == 12.34m, "La lectura diferida perdió datos.");
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, new[] { MYGProyectoStorage.Copia(insumo) });
        using (var c = MYGBaseDatos.Abrir(ruta, false))
            Exige(Valor(c, "SELECT count(*) FROM catalogo_insumo") == 0, "El registro duplicó un producto nativo existente.");
        bool colision = false;
        try { MYGCatalogos.GuardarInsumo(ruta, insumo); }
        catch (InvalidOperationException) { colision = true; }
        Exige(colision, "Se permitió un código que ya pertenece a un producto nativo.");
        insumo.Marca = "Extensión propia";
        var editado = MYGCatalogos.GuardarInsumo(ruta, insumo, insumo.Id, 1);
        Exige(editado.Revision == 2 && MYGCatalogos.Listar(ruta, false).Count == 2 &&
            MYGCatalogos.LeerInsumo(ruta, insumo.Id, 2).Marca == "Extensión propia", "La edición diferida perdió identidad, revisión o extensión.");
        bool obsoleta = false;
        try { MYGCatalogos.GuardarInsumo(ruta, insumo, insumo.Id, 1); }
        catch (InvalidOperationException) { obsoleta = true; }
        Exige(obsoleta, "Una revisión obsoleta sobrescribió la edición.");
        var originalNativo = MYGCatalogos.Listar(ruta, false).Single(x => x.Id == "PR0000000002");
        bool protegido = false;
        try { MYGCatalogos.Eliminar(ruta, false, originalNativo); }
        catch (InvalidOperationException) { protegido = true; }
        using (var c = MYGBaseDatos.Abrir(ruta, false))
            Exige(protegido && Valor(c, "SELECT count(*) FROM catalogo_insumo") == 1 &&
                Valor(c, "SELECT count(*) FROM producto") == 2, "Eliminar un nativo dejó copias o retiró el original sin autorización.");
        var nuevo = MYGProyectoStorage.Copia(insumo); nuevo.Codigo = "NUEVO-001";
        var alta = MYGCatalogos.GuardarInsumo(ruta, nuevo);
        Exige(MYGCatalogos.Listar(ruta, false).Count == 3 &&
            MYGCatalogos.Listar(ruta, false).Count(x => x.Codigo == nuevo.Codigo) == 1, "El espejo nativo duplicó un alta MYG en el listado.");
        MYGCatalogos.Eliminar(ruta, false, alta);
        Exige(MYGCatalogos.Listar(ruta, false).Count == 2, "Eliminar un alta propia alteró el catálogo nativo o la reintrodujo por su espejo.");
        pasa("Catálogo Delphin permanece nativo al escribir, permite lectura y registro sin copias, y conserva ediciones, códigos y revisión");

        string legado = Path.Combine(carpeta, "catalogo-delphin-copias-legadas.sqlite");
        CrearNativa(legado);
        using (var c = MYGBaseDatos.Abrir(legado, true))
        using (var t = c.BeginTransaction())
        {
            DelphinImportacionMYG.PrepararCatalogosMYG(c, t);
            MYGBaseDatos.Ejecutar(c, t, "DROP TABLE myg_catalogo_nativo");
            // Una extensión propia con revisión 1 tampoco se debe descartar.
            var propio = DelphinImportacionMYG.LeerInsumo(c, "PR0000000002", t);
            propio.Marca = "Conservar";
            MYGBaseDatos.Ejecutar(c, t, "UPDATE catalogo_insumo SET json_datos=$p0 WHERE id='PR0000000002'", MYGBaseDatos.Json(propio));
            Exige(MYGCatalogos.RetirarCopiasNativas(c, t), "No se retiraron las copias nativas comprobadas.");
            Exige(Valor(c, "SELECT count(*) FROM catalogo_insumo", t) == 1 &&
                Valor(c, "SELECT count(*) FROM catalogo_partida", t) == 0 &&
                Valor(c, "SELECT count(*) FROM catalogo_partida_nodo", t) == 0, "La migración dejó copias o borró una extensión propia.");
            t.Commit();
        }
        Exige(MYGCatalogos.Listar(legado, false).Count == 2 && MYGCatalogos.Listar(legado, true).Count == 1 &&
            MYGCatalogos.LeerInsumo(legado, "PR0000000002").Marca == "Conservar", "La limpieza perdió catálogo o metadatos privados.");
        pasa("Copias antiguas idénticas se retiran junto con sus índices, preservando extensiones propias incluso con revisión 1");

        string copia = Path.Combine(carpeta, "catalogo-delphin-externo.sqlite");
        var documento = MYGProyectoStorage.Nuevo("Proyecto nuevo", "Presupuesto nuevo");
        MYGBaseDatos.GuardarProyecto(copia, documento, ruta);
        Exige(MYGCatalogos.Listar(copia, false).Count == 2 && MYGCatalogos.Listar(copia, true).Count == 1 &&
            MYGCatalogos.LeerInsumo(copia, insumo.Id).Marca == "Extensión propia",
            "Usar una hoja ligera como catálogo externo perdió entradas nativas u overrides.");
        pasa("Guardar con catálogo externo copia las entradas nativas y sus overrides desde una hoja Delphin ligera");
    }

    private static void CrearNativa(string ruta)
    {
        MYGBaseDatos.CrearBaseVacia(ruta);
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, ForeignKeys = false, Pooling = false }.ToString());
        c.Open();
        var tablas = new[] { "recurso_presupuesto", "partida_presupuesto", "insumo_presupuesto", "myg_presupuesto", "myg_proyecto", "catalogo_partida_recurso", "catalogo_partida_nodo", "catalogo_partida_insumo", "catalogo_partida", "catalogo_insumo", "catalogo_unidad", "myg_info" };
        foreach (string tabla in tablas) MYGBaseDatos.Ejecutar(c, null, "DROP TABLE " + tabla);
        string unidad;
        using (var cmd = c.CreateCommand()) { cmd.CommandText = "SELECT id_unidad FROM unidad WHERE abreviatura_unidad='und' LIMIT 1"; unidad = (string)cmd.ExecuteScalar(); }
        for (int i = 1; i <= 2; i++)
            MYGBaseDatos.Ejecutar(c, null, "INSERT INTO producto(id_producto,descripcion_producto,id_unidad,costo_unitariolista,codigo_producto,id_tipocosto) VALUES($p0,$p1,$p2,12.34,$p3,'TC0000000002')",
                "PR000000000" + i, "Producto " + i, unidad, "000" + i);
        MYGBaseDatos.Ejecutar(c, null, "INSERT INTO analisis_costo(id_analisiscosto,descripcion_costo,id_unidad,costo_unitario,codigo_listaprecio) VALUES('AC0000000001','Partida nativa',$p0,0,'001')", unidad);
    }
    private static long Valor(SqliteConnection c, string sql, SqliteTransaction t = null)
    { using var cmd = MYGBaseDatos.Comando(c, t, sql); return Convert.ToInt64(cmd.ExecuteScalar()); }
    private static void Exige(bool ok, string mensaje) { if (!ok) throw new InvalidOperationException(mensaje); }
}

