using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

// Sólo datos inventados. Las bases privadas no forman parte de estas pruebas.
internal static class RecuperacionJerarquiaDelphinCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "lectura_guardado");
        string huella = Huella(ruta), nativo = InstantaneaNativa(ruta), otra = InstantaneaOtraObra(ruta);
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        ComprobarVista(doc);
        Exige(Huella(ruta) == huella, "Abrir las ramas ausentes modificó SQLite.");
        pasa("Apertura omite la rama ausente completa sin crear títulos ni reasignar por numeración reutilizada");
        for (int n = 0; n < 2; n++)
        {
            MYGProyectoStorage.Guardar(ruta, doc);
            Exige(InstantaneaNativa(ruta) == nativo && InstantaneaOtraObra(ruta) == otra,
                "Guardar alteró las filas nativas ocultas o la otra obra.");
            doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A"); ComprobarVista(doc);
        }
        doc.Presupuestos.Single().Items.Single(i => i.Id == "CU-RX-PX").Costos.Cantidad = 5;
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(MYGBaseDatos.LeerProyecto(ruta, doc.Id).Presupuestos.Single().Items.Single(i => i.Id == "CU-RX-PX").Costos.Cantidad == 5 &&
            CuentaNativo(ruta, "CU-RX-P1") == 1 && CuentaNativo(ruta, "CU-RX-P2") == 1 && CuentaNativo(ruta, "CU-RX-P3") == 1,
            "La edición visible perdió el metrado o eliminó las filas ocultas.");
        pasa("Guardar repetidamente y editar una partida vigente conserva las filas ocultas sin materializar títulos");
        foreach (bool overlay in new[] { false, true })
            foreach (bool renombrado in new[] { false, true }) Legado(carpeta, overlay, renombrado, pasa);
        ConservarRecursosOcultos(carpeta, pasa);
        ruta = CrearArbol(carpeta, "padre_ajeno");
        SQL(ruta, "UPDATE costo_unitario SET id_costopadre='CU-RX-B1' WHERE id_costounitario='CU-RX-P2'");
        RechazaSinEscritura(ruta, "Falta el padre", "Se ocultó una referencia a otra obra.");
        ruta = CrearArbol(carpeta, "ciclo");
        SQL(ruta, "UPDATE costo_unitario SET id_costopadre='CU-RX-P1' WHERE id_costounitario='CU-RX-H1'");
        RechazaSinEscritura(ruta, "Jerarquía circular", "Se ocultó un ciclo existente.");
        doc = MYGProyectoStorage.Nuevo("VALIDACIÓN JSON");
        doc.Presupuestos.Single().Items.Add(new() { Id = "HUERFANO", IdLocalMYG = "HUERFANO", ParentId = "FALTA", TipoPropuesta = "PARTIDA", Unidad = "m" });
        bool rechazado = false;
        try { MYGProyectoStorage.Validar(doc); } catch (InvalidDataException) { rechazado = true; }
        Exige(rechazado, "La omisión nativa relajó la validación JSON.");
        pasa("Los padres ajenos, ciclos existentes y documentos JSON huérfanos conservan su validación estricta");
    }

    private static void Legado(string carpeta, bool overlay, bool renombrado, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, $"legado_{overlay}_{renombrado}");
        SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,posicion_costo)
            VALUES('CU-RX-M1','TEMPORAL','PP-RX-A',7),('CU-RX-M2','TEMPORAL','PP-RX-A',8);
            """);
        var legado = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        SQL(ruta, "DELETE FROM costo_unitario WHERE id_costounitario IN ('CU-RX-M1','CU-RX-M2')");
        var p = legado.Presupuestos.Single();
        foreach (string id in new[] { "CU-RX-M1", "CU-RX-M2" })
        {
            var grupo = p.Items.Single(i => i.Id == id);
            grupo.IdTituloAusenteDelphin = id; grupo.Descripcion = MYGRecuperacionJerarquiaDelphin.DescripcionTitulo(id);
        }
        if (renombrado) p.Items.Single(i => i.Id == "CU-RX-M1").Descripcion = "GRUPO CONFIRMADO POR EL USUARIO";
        string json = MYGJsonAlmacenamiento.Serializar(legado);
        if (overlay)
        {
            var miembros = new JsonArray(p.Items.Select(i => JsonValue.Create(i.Id)).Cast<JsonNode>().ToArray());
            var patrones = new JsonArray(); var entradas = new JsonArray();
            for (int n = 0; n < p.Items.Count; n++)
                if (renombrado && p.Items[n].Id == "CU-RX-M1")
                {
                    patrones.Add(new JsonArray("o", new JsonObject { ["Descripcion"] = new JsonArray("v", p.Items[n].Descripcion) }, new JsonArray()));
                    entradas.Add(new JsonArray(n, 0));
                }
                else entradas.Add(n);
            var cambios = new JsonArray("o", new JsonObject { ["Items"] = new JsonArray("g", miembros, patrones, entradas) }, new JsonArray());
            json = new JsonObject {
                ["FormatoAlmacenamiento"] = "MYG_DELPHIN_EXTENSIONES", ["VersionAlmacenamiento"] = 2, ["Id"] = legado.Id,
                ["Cambios"] = new JsonArray("o", new JsonObject { ["Presupuestos"] = new JsonArray("g", new JsonArray(p.Id),
                    new JsonArray(cambios), new JsonArray(new JsonArray(0, 0))) }, new JsonArray()) }.ToJsonString();
        }
        SQL(ruta, "INSERT INTO myg_proyecto(id,nombre,json_documento,modificado_utc) VALUES($p0,$p1,$p2,$p3)", legado.Id, legado.Nombre, json, DateTime.UtcNow.ToString("O"));
        SQL(ruta, """
            CREATE TABLE IF NOT EXISTS myg_delphin_fila(propietario TEXT NOT NULL,tabla TEXT NOT NULL,id_nativo TEXT NOT NULL,PRIMARY KEY(tabla,id_nativo));
            INSERT INTO myg_delphin_fila(propietario,tabla,id_nativo)
            SELECT 'proyecto:PR-RX-A','costo_unitario',id_costounitario FROM costo_unitario WHERE id_presupuesto='PP-RX-A';
            """);
        string nativo = InstantaneaNativa(ruta), huella = Huella(ruta);
        var abierto = MYGBaseDatos.LeerProyecto(ruta, legado.Id);
        Exige(Huella(ruta) == huella, "La migración de lectura modificó el archivo.");
        if (!renombrado) ComprobarVista(abierto);
        else Exige(abierto.Presupuestos.Single().Items.Any(i => i.Id == "CU-RX-M1" && i.Descripcion == "GRUPO CONFIRMADO POR EL USUARIO") &&
            abierto.Presupuestos.Single().Items.Any(i => i.Id == "CU-RX-P1") && abierto.Presupuestos.Single().Items.All(i => i.Id != "CU-RX-P3"),
            "La limpieza perdió el grupo confirmado o conservó la otra rama automática.");
        MYGProyectoStorage.Guardar(ruta, abierto);
        if (!renombrado) Exige(InstantaneaNativa(ruta) == nativo, "Guardar eliminó o reescribió filas nativas antes registradas por MYG.");
        abierto = MYGBaseDatos.LeerProyecto(ruta, legado.Id);
        if (!renombrado) ComprobarVista(abierto);
        else Exige(abierto.Presupuestos.Single().Items.Single(i => i.Id == "CU-RX-M1").Descripcion == "GRUPO CONFIRMADO POR EL USUARIO", "Se perdió el título confirmado al reabrir.");
        Exige(!Texto(ruta, "SELECT json_documento FROM myg_proyecto WHERE id='PR-RX-A'").Contains("TÍTULO ORIGINAL AUSENTE", StringComparison.Ordinal),
            "Se persistió de nuevo el título automático.");
        pasa($"Migración {(overlay ? "de patch agrupado" : "de documento completo")} {(renombrado ? "conserva nombres confirmados" : "omite ramas sin borrar nativos registrados")} y no persiste títulos automáticos");
    }

    private static void ComprobarVista(MYGProyectoDocumento doc)
    {
        var p = doc.Presupuestos.Single();
        Exige(MYGRecuperacionJerarquiaDelphin.Contar(doc) == 0 && p.Items.Count == 2 && p.Items.Any(i => i.Id == "CU-RX-H0") && p.Items.Any(i => i.Id == "CU-RX-PX"), "Reapareció una rama ausente o desapareció una vigente.");
        var i = p.Items.Single(i => i.Id == "CU-RX-PX");
        Exige(i.Costos.Cantidad == 4 && i.Costos.PrecioDirecto == 2 && i.Item == "09.01" && MYGMotorPresupuestos.TotalPartida(p, i) == 8 &&
            i.Costos.EspecificacionTexto == "ESPECIFICACIÓN SINTÉTICA PX", "Se alteró la economía, numeración o especificación de la partida vigente.");
    }

    private static void ConservarRecursosOcultos(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "recursos_ocultos");
        SQL(ruta, """
            INSERT INTO analisis_costo(id_analisiscosto,descripcion_costo) VALUES('AC-RX-AUX','AUXILIAR PRIVADO DE LA RAMA OCULTA');
            INSERT INTO subtotal_costounitario(id_subtotal,id_costounitario) VALUES('ST-RX-H','CU-RX-P1');
            INSERT INTO composicion_costounitario(id_composicion,id_subtotal,id_costoauxiliar,descripcion_composicion)
            VALUES('CO-RX-H','ST-RX-H','AC-RX-AUX','RECURSO OCULTO');
            INSERT INTO subtotal_analisiscosto(id_subtotal,id_analisiscosto) VALUES('ST-RX-AUX','AC-RX-AUX');
            INSERT INTO composicion_analisiscosto(id_composicion,id_subtotal,descripcion_composicion,cantidad_composicion,costo_composicion)
            VALUES('CO-RX-AUX','ST-RX-AUX','RECURSO AUXILIAR OCULTO',2.5,7.25);
            CREATE TABLE IF NOT EXISTS myg_delphin_fila(propietario TEXT NOT NULL,tabla TEXT NOT NULL,id_nativo TEXT NOT NULL,PRIMARY KEY(tabla,id_nativo));
            INSERT INTO myg_delphin_fila(propietario,tabla,id_nativo) VALUES
                ('proyecto:PR-RX-A','costo_unitario','CU-RX-P1'),
                ('proyecto:PR-RX-A','subtotal_costounitario','ST-RX-H'),
                ('proyecto:PR-RX-A','composicion_costounitario','CO-RX-H'),
                ('proyecto:PR-RX-A','analisis_costo','AC-RX-AUX'),
                ('proyecto:PR-RX-A','subtotal_analisiscosto','ST-RX-AUX'),
                ('proyecto:PR-RX-A','composicion_analisiscosto','CO-RX-AUX');
            """);
        string[] tablas = { "costo_unitario", "analisis_costo", "subtotal_costounitario", "composicion_costounitario", "subtotal_analisiscosto", "composicion_analisiscosto" };
        var antes = tablas.ToDictionary(t => t, t => Filas(ruta, "SELECT * FROM " + t + " ORDER BY 1"));
        for (int n = 0; n < 2; n++)
        {
            var documento = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A"); ComprobarVista(documento);
            MYGProyectoStorage.Guardar(ruta, documento);
            foreach (string tabla in tablas)
                Exige(Filas(ruta, "SELECT * FROM " + tabla + " ORDER BY 1") == antes[tabla],
                    "RetirarAusentes eliminó o cambió un recurso nativo de la rama oculta: " + tabla);
        }
        pasa("Las ramas ocultas antes registradas conservan costos, subtotales, composiciones y auxiliares transitivos al guardar repetidamente");
    }
    private static string CrearArbol(string carpeta, string nombre)
    {
        string ruta = Path.Combine(carpeta, "Recuperacion_" + nombre + ".sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        SQL(ruta, """
            INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,decimales_costo,decimales_cantidad)
            VALUES('PR-RX-A','QA-USUARIO','QA-TIPO','PE','OBRA SINTÉTICA DE RECUPERACIÓN',2,4),
                  ('PR-RX-B','QA-USUARIO','QA-TIPO','PE','OTRA OBRA SINTÉTICA',2,4);
            INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto)
            VALUES('PP-RX-A','PR-RX-A','PRESUPUESTO A',1,'01'),('PP-RX-B','PR-RX-B','PRESUPUESTO B',1,'01');
            INSERT INTO unidad(id_unidad,descripcion_unidad,abreviatura_unidad)
            VALUES('UN-RX','METRO CUADRADO DE PRUEBA','m²');
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,numeracion_costo,posicion_costo)
            VALUES('CU-RX-H0','TÍTULO VIGENTE','PP-RX-A','01',1),
                  ('CU-RX-H1','SUBTÍTULO CON PADRE AUSENTE','PP-RX-A','09.01.01',2);
            UPDATE costo_unitario SET id_costopadre='CU-RX-M1' WHERE id_costounitario='CU-RX-H1';
            """);
        Partida(ruta, "CU-RX-P1", "CU-RX-H1", "09.01.01.01", 3, 2.5m, 7.34m, "P1");
        Partida(ruta, "CU-RX-P2", "CU-RX-M1", "09.01.02", 4, 3m, 11.25m, "P2");
        Partida(ruta, "CU-RX-P3", "CU-RX-M2", "10.01", 5, 1m, 5.50m, "P3");
        Partida(ruta, "CU-RX-PX", null, "09.01", 6, 4m, 2m, "PX");
        SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,numeracion_costo,posicion_costo)
            VALUES('CU-RX-B1','TÍTULO DE OTRA OBRA','PP-RX-B','01',1);
            """);
        return ruta;
    }

    private static void Partida(string ruta, string id, string padre, string item, int posicion,
        decimal cantidad, decimal precio, string sufijo)
        => SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,id_costopadre,id_unidad,
                numeracion_costo,posicion_costo,cantidad,cantidad_metrado,costo_unitario,parcial_costo,
                especificaciones,especificaciones_texto,productividad,magnitud_unidadtiempo)
            VALUES($p0,$p1,'PP-RX-A',$p2,'UN-RX',$p3,$p4,$p5,$p5,$p6,$p7,$p8,'S',1,8)
            """, id, "PARTIDA SINTÉTICA " + sufijo, padre, item, posicion, cantidad, precio,
            decimal.Round(cantidad * precio, 2, MidpointRounding.AwayFromZero), "ESPECIFICACIÓN SINTÉTICA " + sufijo);

    private static void SQL(string ruta, string sql, params object[] valores)
    {
        using var c = Conexion(ruta, true);
        using var q = c.CreateCommand(); q.CommandText = sql;
        for (int n = 0; n < valores.Length; n++) q.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        q.ExecuteNonQuery();
    }

    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly,
            Pooling = false, ForeignKeys = false
        }.ToString());
        c.Open(); return c;
    }

    private static string Texto(string ruta, string sql)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = sql;
        return Convert.ToString(q.ExecuteScalar(), CultureInfo.InvariantCulture) ?? "";
    }

    private static long CuentaNativo(string ruta, string id)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand();
        q.CommandText = "SELECT (SELECT COUNT(*) FROM costo_unitario WHERE id_costounitario=$id)+(SELECT COUNT(*) FROM titulo WHERE id_titulo=$id)";
        q.Parameters.AddWithValue("$id", id);
        return Convert.ToInt64(q.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    private static string RelacionesCostos(string ruta, string excluir = null)
        => Filas(ruta, "SELECT id_costounitario,id_presupuesto,id_costopadre,id_titulo FROM costo_unitario " +
            "WHERE id_costounitario<>$id ORDER BY id_costounitario", excluir ?? "");

    private static string InstantaneaNativa(string ruta)
        => Filas(ruta, "SELECT * FROM costo_unitario ORDER BY id_costounitario") + "\nTÍTULOS\n" +
            Filas(ruta, "SELECT * FROM titulo ORDER BY id_titulo");

    private static string InstantaneaOtraObra(string ruta)
        => Filas(ruta, "SELECT * FROM proyecto WHERE id_proyecto='PR-RX-B'") +
            Filas(ruta, "SELECT * FROM presupuesto WHERE id_presupuesto='PP-RX-B'") +
            Filas(ruta, "SELECT * FROM costo_unitario WHERE id_presupuesto='PP-RX-B' ORDER BY id_costounitario");

    private static string Filas(string ruta, string sql, string id = null)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = sql;
        if (id != null) q.Parameters.AddWithValue("$id", id);
        using var r = q.ExecuteReader(); var filas = new List<string>();
        while (r.Read())
            filas.Add(string.Join("|", Enumerable.Range(0, r.FieldCount).Select(n => r.IsDBNull(n) ? "<NULL>" :
                r.GetValue(n) is byte[] b ? Convert.ToBase64String(b) : Convert.ToString(r.GetValue(n), CultureInfo.InvariantCulture))));
        return string.Join("\n", filas);
    }

    private static void RechazaSinEscritura(string ruta, string mensaje, string detalle)
    {
        string huella = Huella(ruta); bool rechazado = false;
        try { MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A"); }
        catch (InvalidDataException e) when (e.Message.Contains(mensaje, StringComparison.Ordinal)) { rechazado = true; }
        Exige(rechazado && Huella(ruta) == huella, detalle);
    }

    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new InvalidOperationException(detalle); }
}
