using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

// Fixture inventada: una dependencia nativa sobre una rama ya invisible en
// Delphin no se convierte en una edición de predecesoras al reabrir MYG.
internal static class CronogramaRamasAusentesCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Cronograma_rama_ausente.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        SQL(ruta, """
            INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,decimales_costo,decimales_cantidad,fecha_inicio)
            VALUES('PR-QA-CR','QA-USUARIO','QA-TIPO','PE','CRONOGRAMA SINTÉTICO',2,4,'2026-10-05');
            INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto)
            VALUES('PP-QA-CR','PR-QA-CR','PRESUPUESTO SINTÉTICO',1,'01');
            INSERT INTO unidad(id_unidad,descripcion_unidad,abreviatura_unidad)
            VALUES('UN-QA-CR','METRO DE PRUEBA','m');
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,id_costopadre,id_unidad,numeracion_costo,posicion_costo,
                cantidad,cantidad_metrado,costo_unitario,parcial_costo,task_mode,duracion,duracion_new,fecha_inicio,fecha_fin)
            VALUES('CU-QA-H','PARTIDA ANTIGUA','PP-QA-CR','CU-QA-FALTA','UN-QA-CR','01.01',1,1,1,2,2,1,2,2,'2026-10-05 08:00:00','2026-10-06 17:00:00'),
                  ('CU-QA-A','PARTIDA VIGENTE A','PP-QA-CR',NULL,'UN-QA-CR','02',2,1,1,2,2,1,2,2,'2026-10-05 08:00:00','2026-10-06 17:00:00'),
                  ('CU-QA-B','PARTIDA VIGENTE B','PP-QA-CR',NULL,'UN-QA-CR','03',3,1,1,2,2,1,2,2,'2026-10-07 08:00:00','2026-10-08 17:00:00');
            INSERT INTO dependencia_tarea(id_dependencia,id_costounitarioorigen,id_costounitariodestino,id_proyecto,tipo,lag_size)
            VALUES('DP-QA-CR','CU-QA-H','CU-QA-B','PR-QA-CR',0,0);
            """);
        string vinculos = Vinculos(ruta), fechas = Fechas(ruta);
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-QA-CR");
        for (int n = 0; n < 3; n++)
        {
            Exige(doc.Presupuestos.Single().Items.All(i => i.Id != "CU-QA-H") &&
                doc.Cronograma.Tareas.All(t => t.PartidaId != "CU-QA-H"), "Reapareció una tarea de la rama ausente.");
            var visible = doc.Cronograma.Tareas.Single(t => t.PartidaId == "CU-QA-B");
            Exige(visible.Predecesoras.Count == 0, "La reconstrucción legacy añadió una predecesora oculta al Gantt visible.");
            MYGBaseDatos.GuardarProyecto(ruta, doc);
            Exige(Vinculos(ruta) == vinculos && Fechas(ruta) == fechas, "Guardar sin editar cambió el vínculo o las fechas nativas.");
            doc = MYGBaseDatos.LeerProyecto(ruta, doc.Id);
        }
        pasa("Guardar y reabrir tres veces conserva vínculos nativos de ramas ausentes sin reintroducir tareas ni predecesoras ocultas");

        var a = doc.Cronograma.Tareas.Single(t => t.PartidaId == "CU-QA-A");
        var b = doc.Cronograma.Tareas.Single(t => t.PartidaId == "CU-QA-B");
        b.Predecesoras.Add(new() { PredecesoraId = a.Id, Tipo = MYGTipoVinculo.FC });
        bool rechazado = false;
        try { MYGBaseDatos.GuardarProyecto(ruta, doc); }
        catch (InvalidDataException ex) when (ex.Message.Contains("vínculos nativos Delphin", StringComparison.Ordinal)) { rechazado = true; }
        Exige(rechazado && Vinculos(ruta) == vinculos,
            "La omisión de predecesoras ocultas permitió sustituir una red nativa no representable.");
        pasa("La edición real de predecesoras sigue rechazándose de forma transaccional cuando existe un vínculo nativo no representable");
    }

    private static void Exige(bool condicion, string texto) { if (!condicion) throw new InvalidOperationException(texto); }
    private static string Vinculos(string ruta) => Instantanea(ruta, "SELECT * FROM dependencia_tarea ORDER BY id_dependencia");
    private static string Fechas(string ruta) => Instantanea(ruta, "SELECT id_costounitario,fecha_inicio,fecha_fin,duracion,duracion_new,task_mode FROM costo_unitario ORDER BY id_costounitario");
    private static string Instantanea(string ruta, string sql)
    {
        using var c = Conexion(ruta);
        using var q = c.CreateCommand(); q.CommandText = sql;
        using var r = q.ExecuteReader(); var filas = new System.Collections.Generic.List<object[]>();
        while (r.Read()) { var fila = new object[r.FieldCount]; r.GetValues(fila); filas.Add(fila); }
        return JsonSerializer.Serialize(filas);
    }
    private static void SQL(string ruta, string sql)
    { using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = sql; q.ExecuteNonQuery(); }
    private static SqliteConnection Conexion(string ruta)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); return c;
    }
}
