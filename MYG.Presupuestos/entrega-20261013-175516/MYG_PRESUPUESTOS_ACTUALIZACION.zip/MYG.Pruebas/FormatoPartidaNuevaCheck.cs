using System;
using System.Globalization;
using System.IO;
using System.Linq;
using MYG_2027;

internal static class FormatoPartidaNuevaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("FORMATO DE PARTIDAS NUEVAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var primera = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        var hoja = primera.Costos.Hoja;
        VerificarFormato(hoja);
        Exige(!MYGMotorPresupuestos.TieneDatosPropios(primera.Costos),
            "La presentación estándar de una partida nueva no debe crear datos propios.");

        MYGEdicionHoja.Celda(hoja, "B3").Contenido = "1";
        MYGEdicionHoja.Celda(hoja, "C3").Contenido = "3";
        var calculo = new MYGHojaCalculo(hoja);
        Exige(calculo.Mostrar("B3") == 1m.ToString("0.0000", CultureInfo.CurrentCulture) &&
            calculo.Mostrar("C3") == 3m.ToString("0.0000", CultureInfo.CurrentCulture) &&
            calculo.Mostrar("G3") == "3" && calculo.Mostrar("G4") == "-" && calculo.Mostrar("G16") == "3",
            "La partida nueva debe mostrar cuatro decimales en las entradas y resultados compactos, con guion para parciales vacíos.");

        // A second insertion validates the same creation path without sharing
        // the first sheet's values or later user formatting.
        hoja.Celdas["A2"].ColorFondo = "ABCDEF";
        var segunda = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        VerificarFormato(segunda.Costos.Hoja);
        Exige(new MYGHojaCalculo(segunda.Costos.Hoja).Numero("G16") == 0,
            "Una segunda partida debe recibir una hoja estándar independiente.");
        primera = presupuesto.Items.Single(i => i.Id == primera.Id);
        hoja = primera.Costos.Hoja;
        Exige(hoja.Celdas["A2"].ColorFondo == "ABCDEF",
            "Crear otra partida debe conservar el formato personalizado de la partida existente.");
        hoja.Celdas["A2"].ColorFondo = "";

        string ruta = Path.Combine(carpeta, "Partidas nuevas con formato.myg");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        var guardada = MYGProyectoStorage.Leer(ruta).Presupuestos.Single().Items.Single(i => i.Id == primera.Id).Costos.Hoja;
        VerificarFormato(guardada);
        Exige(new MYGHojaCalculo(guardada).Mostrar("G16") == "3",
            "Guardar y reabrir una partida debe conservar el formato visual del total.");

        string excel = Path.Combine(carpeta, "Partida nueva con formato.xlsx");
        MYGExcelPresupuestos.Guardar(excel, new[] { guardada });
        var importada = MYGExcelPresupuestos.Importar(excel, guardada.Nombre, guardada.CeldaTotal);
        VerificarFormato(importada);
        Exige(new MYGHojaCalculo(importada).Mostrar("G3") == "3" &&
            new MYGHojaCalculo(importada).Mostrar("G4") == "-",
            "El intercambio XLSX debe conservar los resultados compactos y los guiones para ceros.");
        pasa("Partidas nuevas conservan grupos celestes, títulos sin relleno, entradas de cuatro decimales, parciales compactos y Total a la derecha en proyecto y XLSX");
    }

    private static void VerificarFormato(MYGHojaMetrado hoja)
    {
        Exige(new[] { "A1:C1", "D1:F1", "G1:H1" }.All(hoja.RangosCombinados.Contains) &&
            MYGEdicionHoja.Direcciones(hoja, "A1:H1").All(d => hoja.Celdas[d].ColorFondo == "EFF9FC") &&
            MYGEdicionHoja.Direcciones(hoja, "A2:H2").All(d => string.IsNullOrEmpty(hoja.Celdas[d].ColorFondo)),
            "La plantilla nueva debe tener los grupos combinados en celeste y los títulos de columna sin relleno.");
        Exige(hoja.Celdas.Values.All(c => c.Fuente == "Arial Narrow" && c.TamanoFuente == 9) &&
            Enumerable.Range(3, 14).All(f => hoja.Celdas["G" + f].FormatoNumero == "0.####;-0.####;-") &&
            hoja.Celdas["A16"].Negrita && hoja.Celdas["G16"].Negrita &&
            MYGEdicionHoja.AlineacionCelda(hoja.Celdas["A16"], "A16") == "Derecha",
            "La plantilla nueva debe conservar fuente, resultados sin ceros finales y etiqueta Total en negrita a la derecha.");
    }
}
