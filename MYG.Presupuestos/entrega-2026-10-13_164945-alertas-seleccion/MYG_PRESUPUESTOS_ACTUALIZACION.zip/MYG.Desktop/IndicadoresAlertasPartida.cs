using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MYG_2027;

internal enum MYGTipoIndicadorPartida { Catalogo, Analisis, Advertencia, Completa }

internal static class MYGIndicadoresPartida
{
    internal static Color ColorIndicador(MYGTipoIndicadorPartida tipo)
    {
        if (SystemInformation.HighContrast) return SystemColors.WindowText;
        bool oscuro = MYG2027_TemaComercial.Oscuro;
        return tipo switch
        {
            MYGTipoIndicadorPartida.Catalogo or MYGTipoIndicadorPartida.Completa =>
                oscuro ? Color.FromArgb(130, 214, 160) : Color.FromArgb(32, 119, 45),
            MYGTipoIndicadorPartida.Analisis =>
                oscuro ? Color.FromArgb(138, 194, 255) : Color.FromArgb(29, 104, 193),
            _ => Color.FromArgb(255, 202, 57)
        };
    }

    internal static Color ColorTitulo(MYGTipoIndicadorPartida tipo)
    {
        if (SystemInformation.HighContrast) return SystemColors.InfoText;
        bool oscuro = MYG2027_TemaComercial.Oscuro;
        return tipo switch
        {
            MYGTipoIndicadorPartida.Advertencia =>
                oscuro ? Color.FromArgb(255, 151, 159) : Color.FromArgb(204, 0, 0),
            MYGTipoIndicadorPartida.Analisis =>
                oscuro ? Color.FromArgb(246, 190, 120) : Color.FromArgb(190, 103, 32),
            _ => oscuro ? Color.FromArgb(130, 214, 160) : Color.FromArgb(0, 100, 0)
        };
    }

    internal static void Pintar(Graphics g, Rectangle bounds, MYGTipoIndicadorPartida tipo, bool seleccionado = false)
    {
        if (g == null || bounds.Width < 4 || bounds.Height < 4) return;
        var estado = g.Save();
        try
        {
            g.SetClip(bounds, CombineMode.Intersect);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float lado = Math.Min(bounds.Width, bounds.Height);
            float izquierda = bounds.Left + (bounds.Width - lado) / 2F;
            float arriba = bounds.Top + (bounds.Height - lado) / 2F;
            var area = new RectangleF(izquierda, arriba, lado, lado);
            Color color = SystemInformation.HighContrast && seleccionado ? SystemColors.HighlightText : ColorIndicador(tipo);
            if (tipo == MYGTipoIndicadorPartida.Advertencia)
            {
                bool contraste = SystemInformation.HighContrast;
                using var relleno = new SolidBrush(contraste ? seleccionado ? SystemColors.Window : SystemColors.Highlight : color);
                using var borde = new Pen(contraste ? color : Color.FromArgb(209, 161, 33),
                    Math.Max(1F, lado / 16F));
                PointF[] triangulo =
                {
                    new(area.Left + lado / 2F, area.Top + lado * .06F),
                    new(area.Right - lado * .06F, area.Bottom - lado * .08F),
                    new(area.Left + lado * .06F, area.Bottom - lado * .08F)
                };
                g.FillPolygon(relleno, triangulo);
                g.DrawPolygon(borde, triangulo);
                using var exclamacion = new Pen(contraste ? seleccionado ? SystemColors.WindowText : SystemColors.HighlightText : Color.FromArgb(52, 43, 21),
                    Math.Max(1F, lado * .105F)) { StartCap = LineCap.Round, EndCap = LineCap.Round };
                float centro = area.Left + lado / 2F;
                g.DrawLine(exclamacion, centro, area.Top + lado * .34F, centro, area.Top + lado * .59F);
                using var punto = new SolidBrush(exclamacion.Color);
                float diametro = Math.Max(1F, lado * .115F);
                g.FillEllipse(punto, centro - diametro / 2F, area.Top + lado * .71F - diametro / 2F,
                    diametro, diametro);
            }
            else if (tipo == MYGTipoIndicadorPartida.Completa)
            {
                using var marca = new Pen(color, Math.Max(1.5F, lado * .13F))
                { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
                g.DrawLines(marca, new[]
                {
                    new PointF(area.Left + lado * .16F, area.Top + lado * .52F),
                    new PointF(area.Left + lado * .40F, area.Top + lado * .76F),
                    new PointF(area.Left + lado * .85F, area.Top + lado * .25F)
                });
            }
            else
            {
                using var fuente = new Font("Segoe UI", lado * .78F, FontStyle.Bold, GraphicsUnit.Pixel);
                using var texto = new SolidBrush(color);
                using var formato = new StringFormat(StringFormat.GenericTypographic)
                { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                g.DrawString("?", fuente, texto, area, formato);
            }
        }
        finally { g.Restore(estado); }
    }
}

// Ventana nativa de ayuda: no activa otro control ni interrumpe la edición.
internal sealed class MYGTooltipPartida : IDisposable
{
    private readonly ToolTip ayuda = new()
    {
        OwnerDraw = true, IsBalloon = false, ShowAlways = true,
        UseAnimation = false, UseFading = false
    };
    private Control propietario;
    private Font fuente, fuenteTitulo;
    private string titulo = "", mensaje = "";
    private MYGTipoIndicadorPartida tipo;
    private Size tamano;
    private int margen, espacio, altoTitulo;
    private bool eliminado;
    private const TextFormatFlags FormatoTexto = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix
        | TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl;

    internal MYGTooltipPartida()
    {
        ayuda.Popup += AjustarVentana;
        ayuda.Draw += Dibujar;
        MYG2027_TemaComercial.CambioTema += OcultarPorCambioTema;
    }

    internal void Mostrar(Control owner, Point location, string titulo, string mensaje,
        MYGTipoIndicadorPartida tipo)
    {
        if (eliminado || owner == null || owner.IsDisposed || owner.Disposing || !owner.IsHandleCreated) return;
        Ocultar(propietario);
        LiberarFuentes();
        propietario = owner;
        this.titulo = titulo ?? "";
        this.mensaje = mensaje ?? "";
        this.tipo = tipo;
        fuente = (Font)owner.Font.Clone();
        fuenteTitulo = new Font(fuente, fuente.Style | FontStyle.Bold);
        float escala = owner.DeviceDpi / 96F;
        margen = Math.Max(4, (int)Math.Round(7F * escala));
        espacio = Math.Max(2, (int)Math.Round(3F * escala));
        var pantalla = Screen.FromPoint(owner.PointToScreen(location)).WorkingArea;
        int anchoMaximo = Math.Max(32, Math.Min((int)Math.Round(420F * escala), pantalla.Width - margen * 2));
        int anchoTexto = Math.Max(1, anchoMaximo - margen * 2);
        using var medidas = owner.CreateGraphics();
        Size Medir(string texto, Font tipografia, int limite) => TextRenderer.MeasureText(medidas,
            texto, tipografia, new Size(limite, int.MaxValue), FormatoTexto);
        Size medidaTitulo = Medir(this.titulo, fuenteTitulo, anchoTexto);
        Size medidaMensaje = Medir(this.mensaje, fuente, anchoTexto);
        int ancho = Math.Min(anchoMaximo,
            Math.Max(medidaTitulo.Width, medidaMensaje.Width) + margen * 2);
        ancho = Math.Max(margen * 2 + 1, ancho);
        // Medir de nuevo con el ancho definitivo conserva los saltos de línea al dibujar.
        anchoTexto = Math.Max(1, ancho - margen * 2);
        altoTitulo = this.titulo.Length == 0 ? 0 : Medir(this.titulo, fuenteTitulo, anchoTexto).Height;
        int altoMensaje = this.mensaje.Length == 0 ? 0 : Medir(this.mensaje, fuente, anchoTexto).Height;
        int separacion = altoTitulo > 0 && altoMensaje > 0 ? espacio : 0;
        tamano = new Size(ancho, Math.Min(Math.Max(margen * 2 + 1,
            altoTitulo + altoMensaje + separacion + margen * 2), Math.Max(1, pantalla.Height - margen * 2)));
        var posicion = owner.PointToScreen(location);
        posicion.X = Math.Max(pantalla.Left + margen,
            Math.Min(posicion.X, pantalla.Right - tamano.Width - margen));
        posicion.Y = Math.Max(pantalla.Top + margen,
            Math.Min(posicion.Y, pantalla.Bottom - tamano.Height - margen));
        string textoAccesible = this.titulo.Length > 0 && this.mensaje.Length > 0
            ? this.titulo + "\n" + this.mensaje : this.titulo + this.mensaje;
        if (textoAccesible.Length == 0) { Ocultar(owner); return; }
        ayuda.Show(textoAccesible, owner, owner.PointToClient(posicion));
    }

    internal void Ocultar(Control owner)
    {
        if (eliminado) return;
        var control = owner ?? propietario;
        if (control != null && !control.IsDisposed && control.IsHandleCreated) ayuda.Hide(control);
        if (control == propietario || owner == null) propietario = null;
    }

    private void AjustarVentana(object sender, PopupEventArgs e) => e.ToolTipSize = tamano;

    private void Dibujar(object sender, DrawToolTipEventArgs e)
    {
        if (fuente == null || fuenteTitulo == null || eliminado) return;
        bool contraste = SystemInformation.HighContrast;
        var fondo = contraste ? SystemColors.Info
            : MYG2027_TemaComercial.Oscuro ? MYG2027_TemaComercial.Superficie : Color.FromArgb(250, 250, 250);
        var texto = contraste ? SystemColors.InfoText : MYG2027_TemaComercial.Texto;
        using var relleno = new SolidBrush(fondo);
        using var borde = new Pen(contraste ? SystemColors.WindowFrame : MYG2027_TemaComercial.Borde);
        e.Graphics.FillRectangle(relleno, e.Bounds);
        e.Graphics.DrawRectangle(borde, e.Bounds.X, e.Bounds.Y,
            Math.Max(0, e.Bounds.Width - 1), Math.Max(0, e.Bounds.Height - 1));
        int ancho = Math.Max(1, e.Bounds.Width - margen * 2);
        if (altoTitulo > 0)
            TextRenderer.DrawText(e.Graphics, titulo, fuenteTitulo,
                new Rectangle(e.Bounds.Left + margen, e.Bounds.Top + margen, ancho, altoTitulo),
                MYGIndicadoresPartida.ColorTitulo(tipo), FormatoTexto | TextFormatFlags.EndEllipsis);
        int arriba = e.Bounds.Top + margen + altoTitulo + (altoTitulo > 0 && mensaje.Length > 0 ? espacio : 0);
        if (mensaje.Length > 0)
            TextRenderer.DrawText(e.Graphics, mensaje, fuente,
                new Rectangle(e.Bounds.Left + margen, arriba, ancho, Math.Max(1, e.Bounds.Bottom - margen - arriba)),
                texto, FormatoTexto | TextFormatFlags.EndEllipsis);
    }

    private void OcultarPorCambioTema(object sender, EventArgs e) => Ocultar(propietario);

    private void LiberarFuentes()
    {
        fuenteTitulo?.Dispose(); fuenteTitulo = null;
        fuente?.Dispose(); fuente = null;
    }

    public void Dispose()
    {
        if (eliminado) return;
        Ocultar(propietario);
        eliminado = true;
        MYG2027_TemaComercial.CambioTema -= OcultarPorCambioTema;
        ayuda.Popup -= AjustarVentana;
        ayuda.Draw -= Dibujar;
        ayuda.Dispose();
        LiberarFuentes();
    }
}
