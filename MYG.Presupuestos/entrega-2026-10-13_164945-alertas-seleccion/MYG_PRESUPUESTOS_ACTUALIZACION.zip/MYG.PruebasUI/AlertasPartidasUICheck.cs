using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class AlertasPartidasUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private sealed record Aviso(string Titulo, string Mensaje, MYGTipoIndicadorPartida Tipo);
    private delegate bool EnumerarVentana(IntPtr ventana, IntPtr datos);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")]
    private static extern bool EnumThreadWindows(uint hilo, EnumerarVentana enumerar, IntPtr datos);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr ventana, StringBuilder nombre, int capacidad);
    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr ventana);
    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr ventana, out RectanguloNativo rectangulo);
    [StructLayout(LayoutKind.Sequential)]
    private struct RectanguloNativo { internal int Izquierda, Arriba, Derecha, Abajo; }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-Alertas-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        Point cursorOriginal = Cursor.Position;
        try
        {
            string ruta = Path.Combine(carpeta, "Catálogo de alertas.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var proyecto = MYGProyectoStorage.Nuevo("PRUEBAS DE ALERTAS");
            var presupuesto = proyecto.Presupuestos.Single();
            var titulo = Nodo("ESTRUCTURAS", titulo: true);
            var completa = Nodo("PARTIDA COMPLETA", titulo.Id, 1);
            var vacia = Nodo("hhh", titulo.Id, 2);
            var formula = Nodo("METRADO CON ERROR", titulo.Id, 3);
            var insumoAusente = Nodo("ACU CON ERROR", titulo.Id, 4);
            presupuesto.Items.AddRange([titulo, completa, vacia, formula, insumoAusente]);
            var material = new MYGInsumo { Codigo = "MAT-01", Descripcion = "MATERIAL", Unidad = "kg", Precio = 10m };
            presupuesto.Costos.Insumos.Add(material);
            foreach (var partida in new[] { completa, formula, insumoAusente })
            {
                partida.Costos.Cantidad = 2m;
                partida.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = material.Id, Cantidad = 3m });
                var entrada = MYGCatalogos.GuardarPartida(ruta, presupuesto, partida,
                    "P-" + partida.Posicion, partida.Descripcion, partida.Unidad);
                partida.Costos.CatalogoMYGId = entrada.Id; partida.Costos.CatalogoMYGRuta = ruta;
            }
            MYGProyectoStorage.Renumerar(presupuesto);
            int anteriores = 0, cambios = 0, guardados = 0, rutasEscritura = 0, lecturas = 0, permisos = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            panel.InicializarCatalogos(() => { rutasEscritura++; return ruta; },
                () => { permisos++; return true; }, () => { }, () => { lecturas++; return ruta; });
            using var formulario = new Form { ClientSize = new Size(1800, 900), StartPosition = FormStartPosition.Manual,
                Location = Screen.PrimaryScreen.WorkingArea.Location };
            formulario.Controls.Add(panel);
            MYG2027_TemaComercial.Aplicar(formulario);
            string estado = Estado(proyecto), hash = Huella(ruta);
            formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(completa);
            Application.DoEvents();
            var tabla = Campo<DataGridView>(panel, "estructura");
            Invocar(panel, "ActualizarCalculos");
            exige(Estado(proyecto) == estado && Huella(ruta) == hash && lecturas > 0 &&
                anteriores == 0 && cambios == 0 && guardados == 0 && rutasEscritura == 0 && permisos == 0,
                "Calcular las alertas debe leer SQLite sin guardar el proyecto, pedir permiso, registrar historial ni modificar datos.");

            var filaVacia = Fila(tabla, vacia);
            var catalogo = LeerAviso(panel, filaVacia.Cells["DESC"]);
            var analisis = LeerAviso(panel, filaVacia.Cells["PU"]);
            var total = LeerAviso(panel, filaVacia.Cells["TOTAL"]);
            exige(catalogo is { Titulo: "Mensaje", Tipo: MYGTipoIndicadorPartida.Catalogo } &&
                catalogo.Mensaje == "ACU no registrado en base de datos :\nhhh",
                "El signo verde de descripción debe mostrar el mensaje de ACU no registrado exactamente como la captura.");
            exige(analisis is { Titulo: "Mensaje", Tipo: MYGTipoIndicadorPartida.Analisis } &&
                analisis.Mensaje == "El costo unitario no tiene análisis",
                "El signo azul de precio debe mostrar sólo el mensaje de falta de análisis de la captura.");
            exige(total is { Titulo: "Alerta", Tipo: MYGTipoIndicadorPartida.Advertencia } &&
                total.Mensaje == "El total de la partida es cero" &&
                panel.DiagnosticoAlertasPartida(vacia).Alertas.Any(a => a.Tipo == MYGTipoAlertaPartida.CantidadCero),
                "El triángulo amarillo debe mostrar sólo el total cero de la captura y conservar el diagnóstico de cantidad pendiente.");
            var diagnostico = panel.DiagnosticoAlertasPartida(completa);
            var filaCompleta = Fila(tabla, completa);
            exige(diagnostico.Completa && diagnostico.Total == 60m &&
                LeerAviso(panel, filaCompleta.Cells["DESC"]) == null && LeerAviso(panel, filaCompleta.Cells["PU"]) == null &&
                LeerAviso(panel, filaCompleta.Cells["TOTAL"]) is { Tipo: MYGTipoIndicadorPartida.Completa, Titulo: "Mensaje" } terminado &&
                terminado.Mensaje.StartsWith("Partida completa", StringComparison.Ordinal),
                "Una partida registrada con metrado y ACU válidos debe tener sólo la marca verde de partida completa.");
            foreach (var fila in tabla.Rows.Cast<DataGridViewRow>().Where(r => r.Tag is MYGPresupuestoDocumento || ReferenceEquals(r.Tag, titulo)))
                exige(new[] { "DESC", "PU", "TOTAL" }.All(c => LeerAviso(panel, fila.Cells[c]) == null &&
                    panel.LimitesIndicadorAlerta(fila.Cells[c]).IsEmpty),
                    "Los presupuestos y títulos no deben recibir indicadores de partida.");

            int lecturasAntesHover = lecturas;
            VerificarHover(panel, tabla, filaVacia, exige);
            exige(Estado(proyecto) == estado && Huella(ruta) == hash && anteriores == 0 && cambios == 0 &&
                guardados == 0 && rutasEscritura == 0 && permisos == 0 && lecturas == lecturasAntesHover,
                "Pasar el cursor por las alertas debe conservar el modelo, SQLite, los permisos y el historial.");
            VerificarHoverDuranteEdicion(panel, tabla, filaVacia, proyecto, exige);

            completa.Costos.Cantidad = 0;
            Invocar(panel, "ActualizarCalculos");
            exige(!panel.DiagnosticoAlertasPartida(completa).Completa &&
                LeerAviso(panel, filaCompleta.Cells["TOTAL"]) is { Tipo: MYGTipoIndicadorPartida.Advertencia } cantidad &&
                cantidad.Mensaje == "El total de la partida es cero" &&
                panel.DiagnosticoAlertasPartida(completa).Alertas.Any(a => a.Tipo == MYGTipoAlertaPartida.CantidadCero),
                "Al borrar la cantidad debe desaparecer la marca completa y actualizarse la explicación pendiente.");
            completa.Costos.Cantidad = 2; material.Precio = 0;
            Invocar(panel, "ActualizarCalculos");
            exige(!panel.DiagnosticoAlertasPartida(completa).Completa &&
                LeerAviso(panel, filaCompleta.Cells["PU"]) is { Tipo: MYGTipoIndicadorPartida.Advertencia } precio &&
                precio.Mensaje.Contains("no tiene precio", StringComparison.Ordinal),
                "Un insumo sin precio debe reemplazar la marca completa por una advertencia que identifica el recurso pendiente.");
            material.Precio = 10;
            Invocar(panel, "ActualizarCalculos");
            exige(panel.DiagnosticoAlertasPartida(completa).Completa && LeerAviso(panel, filaCompleta.Cells["PU"]) == null &&
                LeerAviso(panel, filaCompleta.Cells["TOTAL"])?.Tipo == MYGTipoIndicadorPartida.Completa,
                "Corregir la cantidad y el precio debe eliminar las alertas anteriores sin reconstruir el presupuesto.");

            estado = Estado(proyecto);
            tabla.CurrentCell = filaCompleta.Cells["DESC"];
            tabla.Focus();
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos();
                Application.DoEvents();
                exige(ReferenceEquals(tabla.CurrentCell, filaCompleta.Cells["DESC"]) && filaCompleta.Selected &&
                    Convert.ToDecimal(filaCompleta.Cells["TOTAL"].Value) == 60m && Estado(proyecto) == estado,
                    "Cambiar de tema debe conservar la selección, los importes y las alertas sin alterar los datos.");
                using var imagen = new Bitmap(tabla.Width, tabla.Height);
                tabla.DrawToBitmap(imagen, tabla.ClientRectangle);
                foreach (var (celda, tipo) in new[]
                {
                    (filaVacia.Cells["DESC"], MYGTipoIndicadorPartida.Catalogo),
                    (filaVacia.Cells["PU"], MYGTipoIndicadorPartida.Analisis),
                    (filaVacia.Cells["TOTAL"], MYGTipoIndicadorPartida.Advertencia),
                    (filaCompleta.Cells["TOTAL"], MYGTipoIndicadorPartida.Completa)
                })
                {
                    var limites = panel.LimitesIndicadorAlerta(celda);
                    var celdaVisible = tabla.GetCellDisplayRectangle(celda.ColumnIndex, celda.RowIndex, false);
                    Color esperado = SystemInformation.HighContrast && celda.Selected
                        ? SystemColors.HighlightText : MYGIndicadoresPartida.ColorIndicador(tipo);
                    exige(!limites.IsEmpty && celdaVisible.Contains(limites) &&
                        ContieneColor(imagen, limites, esperado),
                        "Los indicadores deben dibujarse dentro de su celda y permanecer visibles en ambos temas.");
                }
                if (!SystemInformation.HighContrast)
                {
                    var verde = MYGIndicadoresPartida.ColorIndicador(MYGTipoIndicadorPartida.Catalogo);
                    var azul = MYGIndicadoresPartida.ColorIndicador(MYGTipoIndicadorPartida.Analisis);
                    var amarillo = MYGIndicadoresPartida.ColorIndicador(MYGTipoIndicadorPartida.Advertencia);
                    exige(verde.G > verde.R && verde.G > verde.B && azul.B > azul.R && azul.B > azul.G &&
                        amarillo.R > amarillo.G && amarillo.G > amarillo.B,
                        "Las alertas deben mantener los signos verde y azul y el triángulo amarillo de las capturas.");
                }
                VerificarColoresSeleccion(tabla, presupuesto, titulo, exige);
                exige(ReferenceEquals(tabla.CurrentCell, filaCompleta.Cells["DESC"]) && Estado(proyecto) == estado,
                    "Comprobar los colores de los títulos debe conservar la selección previa y los datos.");
            }
            formula.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
            formula.Unidad = "";
            formula.Costos.Hoja.Poner("G16", "=1/0");
            insumoAusente.Costos.Analisis[0].InsumoId = "INSUMO-ELIMINADO";
            Invocar(panel, "ActualizarCalculos");
            foreach (var partida in new[] { formula, insumoAusente })
            {
                var d = panel.DiagnosticoAlertasPartida(partida);
                var fila = Fila(tabla, partida);
                var aviso = LeerAviso(panel, fila.Cells["TOTAL"]);
                exige(!d.Completa && d.Total == null && Convert.ToString(fila.Cells["TOTAL"].Value) == "#ERROR" &&
                    !d.Alertas.Any(a => a.Tipo == MYGTipoAlertaPartida.TotalCero) &&
                    aviso is { Titulo: "Alerta", Tipo: MYGTipoIndicadorPartida.Advertencia } &&
                    !aviso.Mensaje.Contains("El total de la partida es cero", StringComparison.Ordinal),
                    "Una fórmula o insumo inválido debe alertar de su error sin inventar un total cero.");
            }
            exige(panel.DiagnosticoAlertasPartida(formula).Cantidad == null &&
                Convert.ToString(Fila(tabla, formula).Cells["CANT"].Value) == "#ERROR" &&
                LeerAviso(panel, Fila(tabla, formula).Cells["TOTAL"]).Mensaje.Contains("metrado", StringComparison.OrdinalIgnoreCase) &&
                panel.DiagnosticoAlertasPartida(formula).Alertas.Any(a => a.Tipo == MYGTipoAlertaPartida.UnidadVacia) &&
                panel.DiagnosticoAlertasPartida(insumoAusente).PrecioUnitario == null &&
                Convert.ToString(Fila(tabla, insumoAusente).Cells["PU"].Value) == "#ERROR" &&
                LeerAviso(panel, Fila(tabla, insumoAusente).Cells["PU"]).Mensaje.Contains("No existe el insumo", StringComparison.Ordinal) &&
                panel.DiagnosticoAlertasPartida(completa).Completa,
                "Las alertas deben identificar el origen del error y continuar revisando las otras partidas.");
            exige(Huella(ruta) == hash && anteriores == 0 && cambios == 0 && guardados == 0 &&
                rutasEscritura == 0 && permisos == 0,
                "Actualizar avisos tras cambios externos o de tema no debe escribir en SQLite ni registrar ediciones.");
            formulario.Close();
        }
        finally
        {
            Cursor.Position = cursorOriginal;
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
            SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void VerificarHover(MYGPanelPresupuesto panel, DataGridView tabla,
        DataGridViewRow vacia, Action<bool, string> exige)
    {
        var buscar = Campo<TextBox>(panel, "buscar");
        buscar.Focus();
        var seleccion = tabla.CurrentCell;
        foreach (var (columna, tipo) in new[] { ("DESC", MYGTipoIndicadorPartida.Catalogo),
            ("PU", MYGTipoIndicadorPartida.Analisis), ("TOTAL", MYGTipoIndicadorPartida.Advertencia) })
        {
            var limites = panel.LimitesIndicadorAlerta(vacia.Cells[columna]);
            Point centro = new(limites.Left + limites.Width / 2, limites.Top + limites.Height / 2);
            Cursor.Position = tabla.PointToScreen(centro);
            Invocar(panel, "RatonAlertaPartida", tabla, new MouseEventArgs(MouseButtons.None, 0, centro.X, centro.Y, 0));
            Invocar(panel, "MostrarAvisoPartidaPendiente");
            Application.DoEvents();
            var tooltip = Campo<MYGTooltipPartida>(panel, "tooltipAlertasPartidas");
            var tamano = Campo<Size>(tooltip, "tamano");
            exige(Campo<bool>(panel, "avisoPartidaVisible") && Campo<MYGTipoIndicadorPartida>(tooltip, "tipo") == tipo &&
                Campo<string>(tooltip, "titulo") == (tipo == MYGTipoIndicadorPartida.Advertencia ? "Alerta" : "Mensaje") &&
                !string.IsNullOrWhiteSpace(Campo<string>(tooltip, "mensaje")) && TooltipVisible(tooltip, tabla) &&
                Campo<Font>(tooltip, "fuenteTitulo").Bold && tamano.Width > 0 && tamano.Height > 0 &&
                buscar.Focused && ReferenceEquals(tabla.CurrentCell, seleccion) && !tabla.IsCurrentCellInEditMode,
                "La ayuda al pasar de un indicador a otro debe actualizar el texto sin tomar foco, seleccionar otra fila ni abrir edición.");
        }
        Invocar(tabla, "OnMouseLeave", EventArgs.Empty);
        exige(!Campo<bool>(panel, "avisoPartidaVisible") &&
            !Campo<System.Windows.Forms.Timer>(panel, "esperaAlertasPartidas").Enabled,
            "Salir de la tabla debe cerrar el mensaje y detener el temporizador de ayuda.");
        Invocar(panel, "RatonAlertaPartida", tabla, new MouseEventArgs(MouseButtons.Left, 0, 10, 10, 0));
        exige(!Campo<bool>(panel, "avisoPartidaVisible") && ReferenceEquals(tabla.CurrentCell, seleccion) && buscar.Focused,
            "El arrastre del ratón debe ocultar la ayuda sin cambiar la selección ni el foco.");
    }

    private static void VerificarHoverDuranteEdicion(MYGPanelPresupuesto panel, DataGridView tabla,
        DataGridViewRow vacia, MYGProyectoDocumento proyecto, Action<bool, string> exige)
    {
        var seleccion = tabla.CurrentCell;
        string estado = Estado(proyecto);
        tabla.CurrentCell = vacia.Cells["CANT"];
        tabla.Focus();
        exige(tabla.BeginEdit(true) && tabla.EditingControl is DataGridViewTextBoxEditingControl,
            "Debe poder abrirse la cantidad para comprobar las alertas durante la edición.");
        var editor = (DataGridViewTextBoxEditingControl)tabla.EditingControl;
        try
        {
            editor.Text = "5.75";
            editor.Focus();
            editor.Select(1, 2);
            Application.DoEvents();
            object valor = vacia.Cells["CANT"].Value;
            int inicio = editor.SelectionStart, longitud = editor.SelectionLength;
            bool sucia = tabla.IsCurrentCellDirty;
            foreach (var (columna, tipo) in new[] { ("DESC", MYGTipoIndicadorPartida.Catalogo),
                ("PU", MYGTipoIndicadorPartida.Analisis), ("TOTAL", MYGTipoIndicadorPartida.Advertencia) })
            {
                var limites = panel.LimitesIndicadorAlerta(vacia.Cells[columna]);
                // Dos píxeles escalados fuera del dibujo, dentro de la misma celda.
                Point borde = new(limites.Left - Math.Max(1, (int)Math.Round(2F * tabla.DeviceDpi / 96F)),
                    limites.Top + limites.Height / 2);
                var celda = tabla.GetCellDisplayRectangle(vacia.Cells[columna].ColumnIndex, vacia.Index, false);
                exige(!limites.Contains(borde) && celda.Contains(borde),
                    "La comprobación del margen debe usar un punto fuera del icono y dentro de su celda.");
                Cursor.Position = tabla.PointToScreen(borde);
                Invocar(panel, "RatonAlertaPartida", tabla, new MouseEventArgs(MouseButtons.None, 0, borde.X, borde.Y, 0));
                Invocar(panel, "MostrarAvisoPartidaPendiente");
                Application.DoEvents();
                var tooltip = Campo<MYGTooltipPartida>(panel, "tooltipAlertasPartidas");
                exige(Campo<bool>(panel, "avisoPartidaVisible") &&
                    Campo<MYGTipoIndicadorPartida>(tooltip, "tipo") == tipo && TooltipVisible(tooltip, tabla) &&
                    tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.EditingControl, editor) &&
                    ReferenceEquals(tabla.CurrentCell, vacia.Cells["CANT"]) && vacia.Selected && editor.Focused &&
                    editor.Text == "5.75" && editor.SelectionStart == inicio && editor.SelectionLength == longitud &&
                    tabla.IsCurrentCellDirty == sucia && Equals(vacia.Cells["CANT"].Value, valor) && Estado(proyecto) == estado,
                    "El aviso debe aparecer junto al icono durante la edición sin confirmar la cantidad, perder foco ni cambiar el texto o su selección.");
            }
        }
        finally
        {
            Invocar(panel, "OcultarAvisoPartida");
            tabla.CancelEdit();
            tabla.CurrentCell = seleccion;
            Application.DoEvents();
        }
        exige(Estado(proyecto) == estado,
            "Cancelar la cantidad usada en la prueba debe conservar los datos del proyecto.");
    }

    private static void VerificarColoresSeleccion(DataGridView tabla, MYGPresupuestoDocumento presupuesto,
        ItemPresupuestoDelphin titulo, Action<bool, string> exige)
    {
        var seleccion = tabla.CurrentCell;
        try
        {
            foreach (var (nodo, nivel) in new[] { ((object)presupuesto, 0), ((object)titulo, 1) })
            {
                var fila = Fila(tabla, nodo);
                object importe = fila.Cells["TOTAL"].Value;
                tabla.CurrentCell = fila.Cells["TOTAL"];
                tabla.Focus();
                Application.DoEvents();
                Color colorTitulo = MYG2027_TemaComercial.ColorTitulo(nivel);
                Color seleccionado = SystemInformation.HighContrast ? SystemColors.HighlightText : colorTitulo;
                exige(fila.Selected && ReferenceEquals(tabla.CurrentCell, fila.Cells["TOTAL"]) &&
                    Equals(fila.Cells["TOTAL"].Value, importe) && importe is decimal &&
                    fila.DefaultCellStyle.ForeColor == colorTitulo && fila.DefaultCellStyle.SelectionForeColor == seleccionado,
                    "Seleccionar el importe debe conservar el color del título y del presupuesto en ambos temas.");
                using var imagen = new Bitmap(tabla.Width, tabla.Height);
                tabla.DrawToBitmap(imagen, tabla.ClientRectangle);
                foreach (string columna in new[] { "ITEM", "DESC", "TOTAL" })
                {
                    var celda = fila.Cells[columna];
                    var estilo = celda.InheritedStyle.Clone();
                    var formato = new DataGridViewCellFormattingEventArgs(celda.ColumnIndex, celda.RowIndex,
                        celda.Value, typeof(string), estilo);
                    Invocar(tabla, "OnCellFormatting", formato);
                    var limites = tabla.GetCellDisplayRectangle(celda.ColumnIndex, celda.RowIndex, false);
                    exige(formato.CellStyle.ForeColor == colorTitulo &&
                        formato.CellStyle.SelectionForeColor == seleccionado &&
                        ContieneColor(imagen, limites, seleccionado),
                        "El formato global y el dibujo del ítem, título e importe seleccionado deben mantener su color semántico.");
                }
            }
        }
        finally { tabla.CurrentCell = seleccion; }
    }

    private static bool TooltipVisible(MYGTooltipPartida tooltip, Control propietario)
    {
        var tamano = Campo<Size>(tooltip, "tamano");
        int tolerancia = Math.Max(4, (int)Math.Ceiling(4F * propietario.DeviceDpi / 96F));
        bool visible = false;
        EnumThreadWindows(GetCurrentThreadId(), (ventana, _) =>
        {
            if (!IsWindowVisible(ventana)) return true;
            var clase = new StringBuilder(64);
            GetClassName(ventana, clase, clase.Capacity);
            if (clase.ToString() != "tooltips_class32" || !GetWindowRect(ventana, out var limites)) return true;
            visible = Math.Abs(limites.Derecha - limites.Izquierda - tamano.Width) <= tolerancia &&
                Math.Abs(limites.Abajo - limites.Arriba - tamano.Height) <= tolerancia;
            return !visible;
        }, IntPtr.Zero);
        return visible;
    }

    private static ItemPresupuestoDelphin Nodo(string descripcion, string padre = null, int posicion = 1, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new() { Id = id, IdLocalMYG = id, IdPropuesta = id, ParentId = padre, Descripcion = descripcion,
            Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Posicion = posicion,
            Origen = "MODELO", Estado = "PROPUESTA" };
    }
    private static DataGridViewRow Fila(DataGridView tabla, object nodo) =>
        tabla.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, nodo));
    private static Aviso LeerAviso(MYGPanelPresupuesto panel, DataGridViewCell celda)
    {
        object valor = Invocar(panel, "AvisoAlertaCelda", celda);
        return valor == null ? null : new((string)valor.GetType().GetProperty("Titulo").GetValue(valor),
            (string)valor.GetType().GetProperty("Mensaje").GetValue(valor),
            (MYGTipoIndicadorPartida)valor.GetType().GetProperty("Tipo").GetValue(valor));
    }
    private static bool ContieneColor(Bitmap imagen, Rectangle area, Color esperado)
    {
        area.Intersect(new Rectangle(Point.Empty, imagen.Size));
        for (int y = area.Top; y < area.Bottom; y++)
            for (int x = area.Left; x < area.Right; x++)
            {
                Color pixel = imagen.GetPixel(x, y);
                if (Math.Abs(pixel.R - esperado.R) < 35 && Math.Abs(pixel.G - esperado.G) < 35 && Math.Abs(pixel.B - esperado.B) < 35)
                    return true;
            }
        return false;
    }
    private static string Estado(object valor) => JsonSerializer.Serialize(valor);
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
