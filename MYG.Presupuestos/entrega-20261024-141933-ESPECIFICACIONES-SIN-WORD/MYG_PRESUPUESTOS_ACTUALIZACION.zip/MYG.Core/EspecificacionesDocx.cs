using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using HtmlToOpenXml;
using HtmlToOpenXml.IO;

namespace MYG_2027;

/// <summary>Exporta RTF a contenido DOCX editable sin iniciar Office ni ejecutar conversiones externas.</summary>
public static class MYGEspecificacionesDocx
{
    public static void Guardar(string ruta, string rtf, MYGPaginaEspecificacion pagina)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(ruta);
        MYGEspecificacionesPagina.Validar(pagina);
        // Reutiliza el analizador RTF estructural, que conoce escapes y bloques binarios.
        // No basta comprobar el prefijo: un RTF truncado no debe sustituir una entrega.
        _ = MYGEspecificacionesPagina.Guardar(rtf, pagina);
        string destino = Path.GetFullPath(ruta);
        if (!string.Equals(Path.GetExtension(destino), ".docx", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("El documento debe guardarse con extensión .docx.", nameof(ruta));
        string carpeta = Path.GetDirectoryName(destino);
        if (!Directory.Exists(carpeta)) throw new DirectoryNotFoundException("La carpeta de destino no existe.");
        string temporal = Path.Combine(carpeta, ".MYG-Especificaciones-" + Guid.NewGuid().ToString("N") + ".docx");
        try
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var imagenes = new ImagenesIncluidas();
            var ajustesRtf = new RtfPipe.RtfHtmlSettings { ImageUriGetter = imagenes.Agregar };
            // Los destinos header/footer no forman parte del cuerpo HTML en la
            // configuración predeterminada. Se crean partes DOCX propias abajo.
            string html = RtfPipe.Rtf.ToHtml(MYGEspecificacionesPagina.QuitarMetadatos(rtf), ajustesRtf);
            using (var paquete = WordprocessingDocument.Create(temporal, WordprocessingDocumentType.Document))
            {
                var principal = paquete.AddMainDocumentPart();
                principal.Document = new Document(new Body());
                var conversor = new HtmlConverter(principal, imagenes)
                {
                    ImageProcessing = ImageProcessingMode.Embed
                };
                // El resolutor sólo devuelve imágenes RTF en memoria. No usa
                // HttpClient, abre rutas locales ni permite recursos remotos.
                conversor.ParseBody(html).GetAwaiter().GetResult();
                if (principal.ImageParts.Count() != imagenes.Cantidad)
                    throw new InvalidDataException("No se pudieron incluir todas las imágenes de la especificación en el DOCX.");
                ConfigurarPagina(principal, pagina);
                principal.Document.Save();
            }
            using (var comprobacion = WordprocessingDocument.Open(temporal, false))
            {
                if (comprobacion.MainDocumentPart?.Document?.Body == null ||
                    comprobacion.MainDocumentPart.Document.Descendants<AltChunk>().Any())
                    throw new InvalidDataException("No se generó un documento DOCX autónomo válido.");
            }
            // Copia validada y cerrada antes de reemplazar el destino existente.
            if (File.Exists(destino)) File.Replace(temporal, destino, null);
            else File.Move(temporal, destino);
        }
        finally
        {
            try { File.Delete(temporal); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    private static void ConfigurarPagina(MainDocumentPart principal, MYGPaginaEspecificacion pagina)
    {
        const decimal reservaMm = 8.636m; // La misma reserva de 34 centésimas usada al imprimir RTF.
        bool cabecera = !string.IsNullOrEmpty(pagina.Encabezado);
        bool pie = !string.IsNullOrEmpty(pagina.Pie) || pagina.NumerarPaginas;
        decimal ancho = pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm;
        decimal alto = pagina.Horizontal ? pagina.AnchoMm : pagina.AltoMm;
        decimal superior = pagina.MargenSuperiorMm + (cabecera ? reservaMm : 0);
        decimal inferior = pagina.MargenInferiorMm + (pie ? reservaMm : 0);
        if (superior + inferior >= alto)
            throw new ArgumentException("El encabezado, el pie y los márgenes no dejan espacio para el contenido.", nameof(pagina));
        static uint Twips(decimal mm) => checked((uint)decimal.Round(mm * 1440m / 25.4m));
        var seccion = new SectionProperties();
        if (cabecera)
        {
            var parte = principal.AddNewPart<HeaderPart>();
            parte.Header = new Header(ParrafoEncabezadoPie(pagina.Encabezado, false, false));
            parte.Header.Save();
            seccion.Append(new HeaderReference { Type = HeaderFooterValues.Default, Id = principal.GetIdOfPart(parte) });
        }
        if (pie)
        {
            var parte = principal.AddNewPart<FooterPart>();
            parte.Footer = new Footer(ParrafoEncabezadoPie(pagina.Pie ?? "", true, pagina.NumerarPaginas));
            parte.Footer.Save();
            seccion.Append(new FooterReference { Type = HeaderFooterValues.Default, Id = principal.GetIdOfPart(parte) });
        }
        seccion.Append(new PageSize
        {
            Width = Twips(ancho), Height = Twips(alto),
            Orient = pagina.Horizontal ? PageOrientationValues.Landscape : PageOrientationValues.Portrait
        });
        seccion.Append(new PageMargin
        {
            Top = checked((int)Twips(superior)), Bottom = checked((int)Twips(inferior)),
            Left = Twips(pagina.MargenIzquierdoMm), Right = Twips(pagina.MargenDerechoMm),
            Header = Twips(pagina.MargenSuperiorMm), Footer = Twips(pagina.MargenInferiorMm), Gutter = 0
        });
        principal.Document.Body.Append(seccion);
        var configuracion = principal.AddNewPart<DocumentSettingsPart>();
        configuracion.Settings = new Settings(new UpdateFieldsOnOpen { Val = true });
        configuracion.Settings.Save();
    }

    private static Paragraph ParrafoEncabezadoPie(string texto, bool derecha, bool numero)
    {
        static RunProperties Fuente() => new(new RunFonts { Ascii = "Arial", HighAnsi = "Arial" }, new FontSize { Val = "18" });
        var parrafo = new Paragraph(new ParagraphProperties(new Justification
        { Val = derecha ? JustificationValues.Right : JustificationValues.Left }));
        string contenido = texto + (numero ? (texto.Length == 0 ? "Página " : "   ·   Página ") : "");
        parrafo.Append(new Run(Fuente(), new Text(contenido) { Space = SpaceProcessingModeValues.Preserve }));
        if (numero)
            parrafo.Append(new SimpleField(new Run(Fuente(), new Text("1"))) { Instruction = " PAGE " });
        return parrafo;
    }

    private sealed class ImagenesIncluidas : IWebRequest
    {
        private readonly Dictionary<string, (byte[] Bytes, string Mime)> datos = new(StringComparer.Ordinal);
        internal int Cantidad => datos.Count;

        internal string Agregar(RtfPipe.Picture imagen)
        {
            string mime = imagen.MimeType();
            string extension = mime switch
            {
                "image/png" => ".png", "image/jpeg" => ".jpg", "image/bmp" => ".bmp",
                "image/x-emf" => ".emf", "windows/metafile" => ".wmf",
                _ => throw new NotSupportedException("La imagen de tipo " + mime + " no se puede incluir en el DOCX.")
            };
            if (imagen.Bytes == null || imagen.Bytes.Length == 0)
                throw new InvalidDataException("La especificación contiene una imagen sin datos.");
            string uri = "myg-imagen:///" + datos.Count.ToString(CultureInfo.InvariantCulture) + extension;
            datos.Add(uri, (imagen.Bytes, mime));
            return uri;
        }

        public bool SupportsProtocol(string protocolo) => string.Equals(protocolo, "myg-imagen", StringComparison.OrdinalIgnoreCase);

        public Task<Resource> FetchAsync(Uri uri, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!uri.IsAbsoluteUri || !SupportsProtocol(uri.Scheme) || !datos.TryGetValue(uri.AbsoluteUri, out var imagen))
                throw new InvalidDataException("El documento intenta cargar una imagen que no está incluida en la especificación.");
            var recurso = new Resource { Content = new MemoryStream(imagen.Bytes, writable: false), StatusCode = HttpStatusCode.OK };
            // WMF se reconoce por su extensión, conservando el formato vectorial.
            if (imagen.Mime != "windows/metafile") recurso.Headers.Add("Content-Type", imagen.Mime);
            return Task.FromResult(recurso);
        }
    }
}
