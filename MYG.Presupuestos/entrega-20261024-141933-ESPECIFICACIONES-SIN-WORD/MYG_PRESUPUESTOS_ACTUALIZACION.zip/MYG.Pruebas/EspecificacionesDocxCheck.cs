using System;
using System.IO;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Validation;
using DocumentFormat.OpenXml.Wordprocessing;
using MYG_2027;

internal static class EspecificacionesDocxCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "especificaciones-sin-word.docx");
        string png = "89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000B49444154789C636000020000050001A5F645400000000049454E44AE426082";
        byte[] wmf = MetarchivoPrueba();
        string rtf = @"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}{\colortbl;\red18\green52\blue86;}" +
            @"{\header CABECERA RTF QUE NO DEBE REPETIRSE}{\footer PIE RTF QUE NO DEBE REPETIRSE}" +
            @"\f0\fs22\b Materiales\b0\par Espa\u241?a y construcci\u243?n \cf1 color\cf0\par " +
            @"{\field{\*\fldinst HYPERLINK ""https://example.com/documento""}{\fldrslt Enlace de referencia}}\par " +
            @"\trowd\cellx2000\cellx4000\pard\intbl Insumo\cell Unidad\cell\row\pard\par " +
            @"{\pict\pngblip\picw1\pich1\picwgoal1440\pichgoal1440 " + png + @"}\par " +
            @"{\pict\wmetafile8\picw2540\pich2540\picwgoal1440\pichgoal1440 " + Convert.ToHexString(wmf) + @"}\par " +
            @"\pard\pagebb Segunda p\u225?gina\par}";
        var pagina = new MYGPaginaEspecificacion
        {
            AnchoMm = 210, AltoMm = 297, Horizontal = true,
            MargenIzquierdoMm = 20, MargenDerechoMm = 21, MargenSuperiorMm = 22, MargenInferiorMm = 23,
            Encabezado = "CABECERA DOCX", Pie = "PIE DOCX", NumerarPaginas = true
        };
        MYGEspecificacionesDocx.Guardar(ruta, rtf, pagina);
        using (var docx = WordprocessingDocument.Open(ruta, false))
        {
            var errores = new OpenXmlValidator().Validate(docx).ToArray();
            Exige(errores.Length == 0, "El DOCX generado no cumple OpenXML: " + string.Join("; ", errores.Select(e => e.Description).Take(3)));
            var principal = docx.MainDocumentPart;
            var documento = principal.Document;
            string texto = documento.InnerText;
            Exige(texto.Contains("España") && texto.Contains("construcción") && texto.Contains("Segunda página") &&
                documento.Descendants<Bold>().Any() && documento.Descendants<Color>().Any(c => c.Val == "123456") &&
                documento.Descendants<Table>().Count() == 1 && documento.Descendants<TableCell>().Count() == 2 &&
                documento.Descendants<Break>().Any(b => b.Type?.Value == BreakValues.Page),
                "El DOCX perdió Unicode, negrita, color, tabla o salto explícito de página.");
            Exige(!documento.Descendants<AltChunk>().Any() && !principal.AlternativeFormatImportParts.Any() &&
                principal.HyperlinkRelationships.Single().Uri == new Uri("https://example.com/documento"),
                "El DOCX debe contener contenido editable nativo y conservar los enlaces, sin altChunk.");
            pasa("DOCX sin Office: OpenXML válido con texto Unicode editable, negrita, colores, tablas, enlaces y saltos de página");

            var configuracion = documento.Body.Elements<SectionProperties>().Single();
            var hoja = configuracion.GetFirstChild<PageSize>();
            var margenes = configuracion.GetFirstChild<PageMargin>();
            Exige(hoja.Orient.Value == PageOrientationValues.Landscape && hoja.Width > hoja.Height &&
                hoja.Width.Value == Twips(297) && hoja.Height.Value == Twips(210) &&
                margenes.Left.Value == Twips(20) && margenes.Right.Value == Twips(21) &&
                margenes.Top.Value == Twips(22 + 8.636m) && margenes.Bottom.Value == Twips(23 + 8.636m),
                "El DOCX debe conservar orientación, tamaño y márgenes con reserva para encabezado y pie.");
            Exige(principal.HeaderParts.Single().Header.InnerText == "CABECERA DOCX" &&
                principal.FooterParts.Single().Footer.InnerText.Contains("PIE DOCX") &&
                principal.FooterParts.Single().Footer.Descendants<SimpleField>().Single().Instruction.Value.Trim() == "PAGE" &&
                !texto.Contains("CABECERA") && !texto.Contains("PIE RTF"),
                "El encabezado y pie deben estar en partes propias, con campo PAGE nativo y sin duplicarse en el cuerpo.");
            pasa("DOCX sin Office: papel horizontal, márgenes, encabezado, pie y campo PAGE nativos sin duplicar los destinos RTF");

            Exige(principal.ImageParts.Count() == 2 &&
                principal.ImageParts.Any(p => p.ContentType == "image/png" && Bytes(p).SequenceEqual(Convert.FromHexString(png))) &&
                principal.ImageParts.Any(p => p.ContentType.Contains("wmf", StringComparison.OrdinalIgnoreCase) && Bytes(p).SequenceEqual(wmf)) &&
                !principal.ExternalRelationships.Any(r => r.RelationshipType.EndsWith("/image", StringComparison.Ordinal)),
                "El DOCX debe incluir PNG y WMF originales, sin archivos ni imágenes externos.");
            pasa("DOCX sin Office: imágenes PNG y WMF vectoriales embebidas con sus bytes originales y sin descargas externas");
        }

        byte[] anterior = File.ReadAllBytes(ruta);
        bool rechazado = false;
        try { MYGEspecificacionesDocx.Guardar(ruta, @"{\rtf1 RTF truncado", pagina); }
        catch (ArgumentException) { rechazado = true; }
        Exige(rechazado && File.ReadAllBytes(ruta).SequenceEqual(anterior),
            "Un RTF inválido debe rechazarse antes de reemplazar la entrega anterior.");
        rechazado = false;
        try { MYGEspecificacionesDocx.Guardar(ruta, @"{\rtf1\ansi{\pict\macpict\picw1\pich1 0000}}", pagina); }
        catch (NotSupportedException) { rechazado = true; }
        Exige(rechazado && File.ReadAllBytes(ruta).SequenceEqual(anterior) &&
            !Directory.GetFiles(carpeta, ".MYG-Especificaciones-*.docx").Any(),
            "Un formato de imagen no soportado debe conservar el archivo anterior y retirar los temporales.");
        pasa("DOCX sin Office: errores de RTF o imágenes conservan la entrega anterior y limpian archivos temporales");

        MYGEspecificacionesDocx.Guardar(ruta, @"{\rtf1\ansi Entrega actualizada\par}", new MYGPaginaEspecificacion());
        using (var actualizado = WordprocessingDocument.Open(ruta, false))
            Exige(actualizado.MainDocumentPart.Document.InnerText.Contains("Entrega actualizada") &&
                !actualizado.MainDocumentPart.HeaderParts.Any() && !actualizado.MainDocumentPart.FooterParts.Any(),
                "Repetir el guardado debe reemplazar la entrega y no heredar cabeceras ni pies anteriores.");
        pasa("DOCX sin Office: guardado repetible con reemplazo validado y sin conservar configuración de otra entrega");
    }

    private static uint Twips(decimal mm) => checked((uint)decimal.Round(mm * 1440m / 25.4m));

    private static byte[] Bytes(ImagePart imagen)
    {
        using var fuente = imagen.GetStream();
        using var salida = new MemoryStream();
        fuente.CopyTo(salida);
        return salida.ToArray();
    }

    private static byte[] MetarchivoPrueba()
    {
        // WMF placeable de una línea diagonal. No requiere System.Drawing ni Windows.
        using var memoria = new MemoryStream();
        using var escritor = new BinaryWriter(memoria, Encoding.ASCII, leaveOpen: true);
        escritor.Write(0x9AC6CDD7u); escritor.Write((ushort)0);
        escritor.Write((short)0); escritor.Write((short)0); escritor.Write((short)1440); escritor.Write((short)1440);
        escritor.Write((ushort)1440); escritor.Write(0u); escritor.Write((ushort)0);
        byte[] cabecera = memoria.ToArray();
        ushort suma = 0;
        for (int i = 0; i < 20; i += 2) suma ^= BitConverter.ToUInt16(cabecera, i);
        memoria.Position = 20; escritor.Write(suma);
        escritor.Write((ushort)1); escritor.Write((ushort)9); escritor.Write((ushort)0x0300);
        escritor.Write(36u); escritor.Write((ushort)0); escritor.Write(5u); escritor.Write((ushort)0);
        escritor.Write(4u); escritor.Write((ushort)0x0103); escritor.Write((ushort)8);
        foreach (var registro in new[] { (0x020B, 0), (0x020C, 1440), (0x0214, 0), (0x0213, 1440) })
        {
            escritor.Write(5u); escritor.Write((ushort)registro.Item1);
            escritor.Write((short)registro.Item2); escritor.Write((short)registro.Item2);
        }
        escritor.Write(3u); escritor.Write((ushort)0);
        return memoria.ToArray();
    }
}
