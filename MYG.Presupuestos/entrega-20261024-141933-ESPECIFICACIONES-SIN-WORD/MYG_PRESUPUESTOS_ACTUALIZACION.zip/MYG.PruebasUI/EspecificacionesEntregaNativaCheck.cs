using System;
using System.Drawing.Printing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesEntregaNativaCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var editor = new RichTextBox { Rtf = @"{\rtf1\ansi\deff0{\fonttbl{\f0 Georgia;}}\f0\fs22\b ESPECIFICACIONES\b0\par Texto editable \u241? y tabla.\par\trowd\cellx2000\cellx4000\intbl Material\cell Cantidad\cell\row\pard\par\pagebb Segunda hoja.}" };
        editor.Select(2, 4);
        editor.Modified = false;
        string original = editor.Rtf;
        var pagina = new PageSettings(new PrinterSettings { PrinterName = "MYG-SIN-IMPRESORA" })
        {
            PaperSize = new PaperSize("A4", 827, 1169), Margins = new Margins(75, 75, 75, 75)
        };
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Entrega-Nativa-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            foreach (string extension in new[] { ".docx", ".rtf" })
            {
                var entrega = MYGEspecificacionesDocumento.CrearEntregaNativa(editor, extension, pagina,
                    "CABECERA", "PIE", numeroPagina: true);
                string temporal = entrega.RutaArchivo;
                try
                {
                    exige(entrega.Paginas.Length >= 2 && entrega.Paginas.All(p => p.Image != null),
                        "La entrega " + extension + " debe mostrar texto y saltos sin Word ni impresora válida.");
                    string destino = Path.Combine(carpeta, "entrega" + extension);
                    entrega.Guardar(destino);
                    byte[] primera = File.ReadAllBytes(destino);
                    entrega.Guardar(destino);
                    MYGEspecificacionesEntregaPaginada.ValidarArchivo(destino, extension);
                    if (extension == ".docx")
                    {
                        using var paquete = ZipFile.OpenRead(destino);
                        using var lector = new StreamReader(paquete.GetEntry("word/document.xml").Open());
                        exige(lector.ReadToEnd().Contains("Georgia", StringComparison.Ordinal),
                            "La entrega nativa debe conservar la fuente elegida sin forzar Arial Narrow.");
                    }
                    exige(File.ReadAllBytes(destino).AsSpan().SequenceEqual(primera) &&
                            File.ReadAllBytes(temporal).AsSpan().SequenceEqual(primera),
                        "Guardar repetidamente " + extension + " debe copiar la misma instantánea válida, sin reconversión.");
                    string ajeno = Path.Combine(carpeta, "conservar.txt");
                    File.WriteAllText(ajeno, "Contenido previo");
                    bool rechazado = false;
                    try { entrega.Guardar(ajeno); }
                    catch (InvalidOperationException) { rechazado = true; }
                    exige(rechazado && File.ReadAllText(ajeno) == "Contenido previo",
                        "Rechazar una extensión diferente debe conservar íntegro el archivo anterior.");
                }
                finally { entrega.Dispose(); }
                exige(!File.Exists(temporal) && editor.Rtf == original && editor.SelectionStart == 2 &&
                        editor.SelectionLength == 4 && !editor.Modified,
                    "Liberar " + extension + " debe retirar su temporal sin modificar la especificación ni su selección.");
            }
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }
}
