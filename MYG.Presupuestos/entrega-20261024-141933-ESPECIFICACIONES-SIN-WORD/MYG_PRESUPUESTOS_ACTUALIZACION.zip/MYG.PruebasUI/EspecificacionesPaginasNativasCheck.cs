using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesPaginasNativasCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var original = new RichTextBox { Rtf = DocumentoTresPaginas() };
        original.ClearUndo();
        string antesEdicion = original.Text;
        original.Select(original.TextLength, 0);
        original.SelectedText = "Nota reversible de la especificación.";
        original.Select(4, 7);
        original.Modified = false;
        string rtf = original.Rtf;
        bool deshacer = original.CanUndo, rehacer = original.CanRedo;
        // Una impresora deliberadamente inexistente demuestra que el renderer
        // sólo necesita el papel/márgenes explícitos, no un dispositivo instalado.
        var configuracion = new PageSettings(new PrinterSettings { PrinterName = "MYG-IMPRESORA-INEXISTENTE-PRUEBA" })
        {
            PaperSize = new PaperSize("A4", 827, 1169), Landscape = false,
            Margins = new Margins(75, 75, 75, 75)
        };
        var generadas = MYGEspecificacionesDocumento.CrearPaginasNativas(original, configuracion,
            "CABECERA NATIVA", "PIE NATIVO", numeroPagina: true);
        try
        {
            exige(generadas.Paginas.Length == 3 && generadas.Flujos.Length == 3,
                "RichEdit debe producir tres páginas respetando los saltos explícitos, sin Word y con una impresora inexistente.");
            exige(generadas.Paginas.All(p => p.PhysicalSize == new Size(827, 1169) &&
                    p.Image is Metafile emf && emf.GetMetafileHeader().IsEmfOrEmfPlus()),
                "Las páginas deben ser metaficheros vectoriales con el tamaño físico A4 solicitado.");
            exige(generadas.Flujos.All(f => f.CanRead && f.Length > 0),
                "Los flujos de los metaficheros deben permanecer vivos mientras se muestran las páginas.");
            foreach (var pagina in generadas.Paginas)
            {
                using var imagen = new Bitmap(414, 585);
                using (var grafico = Graphics.FromImage(imagen))
                { grafico.Clear(Color.White); grafico.DrawImage(pagina.Image, new Rectangle(0, 0, imagen.Width, imagen.Height)); }
                int pixelesTexto = 0;
                // Buscar tinta dentro del cuerpo, no sólo el encabezado o borde.
                for (int y = 70; y < 180; y++)
                    for (int x = 40; x < 370; x++)
                        if (imagen.GetPixel(x, y).GetBrightness() < .7f) pixelesTexto++;
                exige(pixelesTexto > 20,
                    "Cada página nativa debe contener el texto del cuerpo; una página blanca o sólo con encabezado no valida la composición.");
            }
            exige(original.Rtf == rtf && original.SelectionStart == 4 && original.SelectionLength == 7 &&
                    !original.Modified && original.CanUndo == deshacer && original.CanRedo == rehacer,
                "Preparar páginas nativas no debe cambiar texto, formato, selección, estado ni historial del documento original.");
        }
        finally { Disponer(generadas); }
        exige(generadas.Flujos.All(f => !f.CanRead),
            "Al liberar la entrega deben cerrarse todos los flujos de sus páginas.");

        configuracion.Landscape = true;
        var horizontal = MYGEspecificacionesDocumento.CrearPaginasNativas(original, configuracion, "", "", false);
        try
        {
            exige(horizontal.Paginas.Length >= 3 && horizontal.Paginas.All(p => p.PhysicalSize == new Size(1169, 827)),
                "La orientación horizontal debe intercambiar el papel conservando los saltos y sin consultar una impresora.");
        }
        finally { Disponer(horizontal); }

        configuracion.Margins = new Margins(1000, 1000, 1000, 1000);
        bool rechazado = false;
        try { Disponer(MYGEspecificacionesDocumento.CrearPaginasNativas(original, configuracion, "", "", false)); }
        catch (InvalidOperationException) { rechazado = true; }
        exige(rechazado && original.Rtf == rtf,
            "Los márgenes sin espacio deben rechazarse antes de producir páginas y dejar intacto el documento.");
        original.Undo();
        exige(original.Text == antesEdicion,
            "El historial original debe seguir deshaciendo exactamente la edición previa a las vistas nativas.");
    }

    private static void Disponer((PreviewPageInfo[] Paginas, MemoryStream[] Flujos) paginas)
    {
        try { foreach (var pagina in paginas.Paginas) pagina.Image?.Dispose(); }
        finally { foreach (var flujo in paginas.Flujos) flujo.Dispose(); }
    }

    private static string DocumentoTresPaginas()
    {
        var rtf = new StringBuilder(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}\f0\fs22 ");
        for (int seccion = 1; seccion <= 3; seccion++)
        {
            rtf.Append(seccion == 1 ? @"\pard " : @"\pard\pagebb ");
            rtf.Append(@"\b SECCION ").Append(seccion).Append(@"\b0\par\pard ");
            for (int linea = 1; linea <= 8; linea++)
                rtf.Append("Contenido sintetico ").Append(seccion).Append('.').Append(linea).Append(@"\par ");
        }
        return rtf.Append('}').ToString();
    }
}
