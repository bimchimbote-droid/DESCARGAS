# Dependencias de la distribución

| Componente | Versión | Licencia declarada por el paquete |
| --- | --- | --- |
| Microsoft.Data.Sqlite / Microsoft.Data.Sqlite.Core | 10.0.0 | MIT; © Microsoft Corporation. |
| SQLitePCLRaw.bundle_e_sqlite3 / batteries_v2 / core / provider.e_sqlite3 | 2.1.11 | Apache-2.0; Copyright 2014–2024 SourceGear, LLC. |
| SQLitePCLRaw.lib.e_sqlite3 | 2.1.12 | Apache-2.0; Copyright 2014–2024 SourceGear, LLC. |
| Lanzador .NET para Windows x64 | 10.0.0 | MIT; Microsoft y colaboradores .NET. |

Se fija expresamente la biblioteca nativa `SQLitePCLRaw.lib.e_sqlite3` en **2.1.12**. Esa es la versión incluida en la distribución, aunque los componentes administrados SQLitePCLRaw declaren otra versión.

Los textos de licencia y los avisos del lanzador .NET se incluyen en `licencias`.

Paquetes y repositorios:

- <https://www.nuget.org/packages/Microsoft.Data.Sqlite/10.0.0>
- <https://github.com/dotnet/efcore>
- <https://www.nuget.org/packages/SQLitePCLRaw.lib.e_sqlite3/2.1.12>
- <https://github.com/ericsink/SQLitePCL.raw>
- <https://github.com/dotnet/runtime>

Las referencias `RevitAPI.dll` y `RevitAPIUI.dll` las suministra la instalación de Autodesk Revit 2027. No se redistribuyen en este paquete. Para la comprobación de compilación fuera de Windows se emplearon los paquetes de referencia Nice3point.Revit.Api 2027.0.0; no se necesitan para compilar normalmente con Revit instalado.

## Exportación de especificaciones sin Office

La generación de DOCX utiliza las siguientes bibliotecas administradas. `dotnet restore` las restaura desde NuGet y la publicación de la aplicación incluye los ensamblados necesarios; los usuarios no necesitan instalar Microsoft Office para preparar la vista, imprimir o guardar DOCX/RTF.

| Componente | Versión resuelta | Licencia |
| --- | --- | --- |
| RtfPipe | 2.0.7677.4303 | MIT; Eric Domke. |
| HtmlToOpenXml.dll | 3.5.0 | MIT; Olivier Nizet. |
| DocumentFormat.OpenXml / DocumentFormat.OpenXml.Framework | 3.5.1 | MIT; Microsoft. |
| AngleSharp | 1.5.0 | MIT; AngleSharp. |
| Microsoft.Extensions.Logging.Abstractions | 6.0.0 | MIT; Microsoft. |
| System.IO.Packaging | 10.0.2 | MIT; Microsoft. |

Las dos primeras son referencias directas del exportador y las restantes son dependencias transitivas resueltas. El paquete `RtfPipe` antiguo no declara la licencia en su `.nuspec`; su [repositorio oficial](https://github.com/erdomke/RtfPipe/blob/master/LICENSE) declara MIT. `HtmlToOpenXml.dll` y las dependencias transitivas declaran MIT en sus paquetes NuGet.

El DOCX contiene texto, estilos, tablas, imágenes y campos OpenXML editables, sin `altChunk`, automatización COM ni conversiones externas. Las imágenes se incluyen en el archivo desde los datos RTF en memoria; el exportador no descarga recursos remotos. Los saltos de página explícitos se conservan. La vista y la impresión utilizan el motor nativo de Windows; un lector DOCX puede distribuir líneas, tablas largas y páginas de forma diferente. No se garantiza la misma paginación que Microsoft Word para RTF complejo. El formato binario `.doc` antiguo queda fuera de este exportador; cualquier operación heredada que lo use continúa siendo opcional y puede requerir Word.
