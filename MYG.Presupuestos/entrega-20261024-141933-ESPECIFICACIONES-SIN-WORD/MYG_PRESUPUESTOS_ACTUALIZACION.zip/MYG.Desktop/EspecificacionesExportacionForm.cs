using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace MYG_2027;

// La salida se edita en una copia; nunca escribe especificaciones en la base de origen.
internal sealed class MYGEspecificacionesExportacionForm : Form
{
    private readonly MYGEspecificacionesEditor editor;
    private readonly TabControl documentos = new() { Dock = DockStyle.Fill, Alignment = TabAlignment.Bottom };
    private readonly string nombreArchivo;
    private string ultimoGuardado;

    internal RichTextBox Documento => editor.Documento;
    internal string DocumentoRtf => editor.DocumentoRtf;
    internal bool HayCambiosPendientes => editor.DocumentoRtf != ultimoGuardado;

    internal MYGEspecificacionesExportacionForm(MYGProyectoDocumento proyecto, MYGAlcanceEspecificaciones alcance,
        string presupuestoId = null, string rutaOrigen = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        Name = "espec_exportacion_form";
        Text = "[" + (string.IsNullOrWhiteSpace(rutaOrigen) ? proyecto.Nombre ?? "Especificaciones técnicas" : rutaOrigen) + "]";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new(1180, 820); MinimumSize = new(800, 600);
        WindowState = FormWindowState.Maximized;
        BackColor = MYG2027_TemaComercial.Fondo;
        nombreArchivo = MYGEspecificacionesExportacion.NombreArchivo(proyecto, alcance, presupuestoId);
        string rtf = MYGEspecificacionesComposicion.Crear(proyecto, alcance, presupuestoId);
        var documento = new MYGEspecificacionesRichTextBox { DetectUrls = false, HideSelection = false, AcceptsTab = true };
        editor = new MYGEspecificacionesEditor(documento, () => { }, () => { },
            () => "ESPECIFICACIONES TECNICAS", () => "", () => "", () => proyecto.Nombre ?? "")
        { Name = "espec_exportacion_editor" };
        var pagina = new TabPage(proyecto.Nombre ?? "Proyecto") { Name = "espec_exportacion_documento", Padding = Padding.Empty };
        pagina.Controls.Add(editor); documentos.TabPages.Add(pagina); Controls.Add(documentos);
        editor.Cargar("exportacion-" + Guid.NewGuid().ToString("N"), rtf, "");
        editor.PrepararExportacion(Close, () => GuardarComo());
        MYGTemaPestanas.Preparar(documentos);
        ultimoGuardado = editor.DocumentoRtf;
        FormClosing += ConfirmarSalida;
        Shown += (_, _) => editor.MostrarVistaPreviaExportacionDirecta();
    }

    private bool GuardarComo()
    {
        using var dialogo = new SaveFileDialog
        {
            Title = "Guardar especificaciones técnicas", Filter = "Documento Word (*.docx)|*.docx|Documento RTF (*.rtf)|*.rtf|Word 97-2003 (requiere Word) (*.doc)|*.doc",
            DefaultExt = editor.ExtensionEntrega.TrimStart('.'),
            FilterIndex = editor.ExtensionEntrega switch { ".rtf" => 2, ".doc" => 3, _ => 1 },
            FileName = Path.ChangeExtension(nombreArchivo, editor.ExtensionEntrega), AddExtension = true, OverwritePrompt = true
        };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return false;
        editor.GuardarEntregaExportacion(dialogo.FileName);
        ultimoGuardado = editor.DocumentoRtf;
        return true;
    }

    private void ConfirmarSalida(object sender, FormClosingEventArgs e)
    {
        // RichEdit también permite cambios de formato que no emiten TextChanged.
        if (!HayCambiosPendientes) return;
        var respuesta = MessageBox.Show(this, "Hay cambios en el documento de exportación. ¿Desea guardarlos antes de volver al proyecto?",
            "Especificaciones técnicas", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
        if (respuesta == DialogResult.Cancel) { e.Cancel = true; return; }
        if (respuesta != DialogResult.Yes) return;
        try { e.Cancel = !GuardarComo(); }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        { e.Cancel = true; MessageBox.Show(this, ex.Message, "Guardar especificaciones", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
}
