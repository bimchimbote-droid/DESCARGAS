using System;
using System.Drawing.Printing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace MYG_2027;

internal static partial class MYGEspecificacionesDocumento
{
    // Instantánea editable para guardar y páginas nativas para ver/imprimir.
    // No inicia aplicaciones externas ni consulta una impresora para paginar.
    internal static MYGEspecificacionesEntregaPaginada CrearEntregaNativa(RichTextBox editor, string extension,
        PageSettings pagina, string encabezado = "", string pie = "", bool numeroPagina = false,
        string rtfParaArchivo = null)
    {
        ArgumentNullException.ThrowIfNull(editor);
        ArgumentNullException.ThrowIfNull(pagina);
        extension = (extension ?? "").Trim().ToLowerInvariant();
        if (!extension.StartsWith('.')) extension = "." + extension;
        if (extension is not (".docx" or ".rtf"))
            throw new ArgumentException("La entrega sin Word admite .docx y .rtf.", nameof(extension));

        string carpeta = CrearCarpetaTemporal();
        System.Drawing.Printing.PreviewPageInfo[] paginas = Array.Empty<PreviewPageInfo>();
        MemoryStream[] flujos = Array.Empty<MemoryStream>();
        try
        {
            string archivo = Path.Combine(carpeta, "Especificaciones" + extension);
            using var copia = new RichTextBox { Font = editor.Font, DetectUrls = false, Rtf = editor.Rtf };
            if (extension == ".rtf")
                File.WriteAllText(archivo, rtfParaArchivo ?? RtfConPagina(copia, pagina, encabezado, pie, numeroPagina), Encoding.ASCII);
            else GuardarDocxSinWord(copia, archivo, pagina, encabezado, pie, numeroPagina);
            MYGEspecificacionesEntregaPaginada.ValidarArchivo(archivo, extension);
            (paginas, flujos) = CrearPaginasNativas(copia, pagina, encabezado, pie, numeroPagina);
            return new MYGEspecificacionesEntregaPaginada(carpeta, archivo, extension, paginas, flujos);
        }
        catch
        {
            try { foreach (var hoja in paginas) hoja.Image?.Dispose(); }
            finally
            {
                foreach (var flujo in flujos) flujo.Dispose();
                EliminarCarpetaTemporal(carpeta);
            }
            throw;
        }
    }

    private static void GuardarDocxSinWord(RichTextBox editor, string ruta, PageSettings pagina,
        string encabezado, string pie, bool numeroPagina)
    {
        pagina ??= new PageSettings { PaperSize = new PaperSize("A4", 827, 1169) };
        MYGEspecificacionesDocx.Guardar(ruta, editor.Rtf, new MYGPaginaEspecificacion
        {
            AnchoMm = pagina.PaperSize.Width * .254m,
            AltoMm = pagina.PaperSize.Height * .254m,
            Horizontal = pagina.Landscape,
            MargenIzquierdoMm = pagina.Margins.Left * .254m,
            MargenDerechoMm = pagina.Margins.Right * .254m,
            MargenSuperiorMm = pagina.Margins.Top * .254m,
            MargenInferiorMm = pagina.Margins.Bottom * .254m,
            Encabezado = encabezado ?? "", Pie = pie ?? "", NumerarPaginas = numeroPagina
        });
    }
}
