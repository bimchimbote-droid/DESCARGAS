using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace MYG_2027;

// Dibujos propios, escalables y sin dependencia de una instalación de Microsoft Office.
internal static class MYGEspecificacionesCinta
{
    private static bool Oscuro => MYG2027_TemaComercial.Oscuro;
    private static bool AltoContraste => SystemInformation.HighContrast;
    internal static Color AzulFondo => AltoContraste ? SystemColors.Control : MYG2027_TemaComercial.Superficie;
    internal static Color AzulTab => AltoContraste ? SystemColors.Control : MYG2027_TemaComercial.SuperficieAlterna;
    internal static Color AzulBorde => MYG2027_TemaComercial.Borde;
    internal static Color Texto => AltoContraste ? SystemColors.ControlText : MYG2027_TemaComercial.Texto;
    private static Color TextoDeshabilitado => MYG2027_TemaComercial.Secundario;
    private static Color FondoEntrada => MYG2027_TemaComercial.Superficie;
    private static Color TextoEntrada => AltoContraste ? SystemColors.WindowText : Texto;
    private static Color AzulIcono => AltoContraste ? SystemColors.ControlText : MYG2027_TemaComercial.Secundario;
    private static Color FondoSeleccion => AltoContraste ? SystemColors.Highlight : MYG2027_TemaComercial.Seleccion;
    private static Color FondoHover => AltoContraste ? SystemColors.Highlight : MYG2027_TemaComercial.AzulSuave;
    private static Color BordeSeleccion => AltoContraste ? SystemColors.HighlightText : MYG2027_TemaComercial.Azul;
    private static readonly Color Amarillo = Color.FromArgb(204, 170, 96);
    private static readonly ConditionalWeakTable<ToolStripItem, RecursosIcono> recursos = new();
    private static readonly ConditionalWeakTable<ToolStrip, AnimacionHover> animaciones = new();
    private static readonly ToolStripRenderer renderer = new RendererCinta();

    internal static void Preparar(TabControl cinta)
    {
        MYGTemaPestanas.Preparar(cinta);
        cinta.SizeMode = TabSizeMode.Normal;
        cinta.ItemSize = new Size(0, 31);
        cinta.Padding = new Point(14, 4);
        cinta.Multiline = false;
        AplicarTema(cinta);
    }

    internal static void AplicarTema(TabControl cinta)
    {
        MYGTemaPestanas.Aplicar(cinta);
        cinta.BackColor = AzulTab;
        cinta.ForeColor = Texto;
        foreach (TabPage pagina in cinta.TabPages)
        {
            pagina.UseVisualStyleBackColor = false;
            pagina.BackColor = AzulFondo;
            pagina.ForeColor = Texto;
            foreach (Control hijo in pagina.Controls) AplicarTemaHijos(hijo);
        }
        cinta.Invalidate(true);
    }

    // Los accesos rápidos pueden vivir fuera del TabControl, pero usan la misma paleta.
    internal static void AplicarTema(Control control) => AplicarTemaHijos(control);

    private static void AplicarTemaHijos(Control control)
    {
        MYGTemaNativo.Aplicar(control);
        control.ForeColor = control is Label && control.Name.StartsWith("espec_etiqueta_", StringComparison.Ordinal)
            ? TextoDeshabilitado : Texto;
        control.BackColor = control is ToolStrip or Label ? Color.Transparent
            : control is TextBoxBase or ComboBox or UpDownBase ? FondoEntrada : AzulFondo;
        if (control is TextBoxBase or ComboBox or UpDownBase) control.ForeColor = TextoEntrada;
        if (control is CheckBox check) check.UseVisualStyleBackColor = false;
        if (control is RadioButton radio) radio.UseVisualStyleBackColor = false;
        if (control is ToolStrip strip)
        {
            strip.Renderer = renderer;
            foreach (ToolStripItem item in strip.Items) AplicarTemaItem(item);
            strip.OverflowButton.DropDown.Renderer = renderer;
            strip.Invalidate(true);
            return;
        }
        foreach (Control hijo in control.Controls) AplicarTemaHijos(hijo);
        control.Invalidate();
    }

    private static void AplicarTemaItem(ToolStripItem item)
    {
        item.ForeColor = Texto;
        if (recursos.TryGetValue(item, out var icono) && ReferenceEquals(item.Image, icono.Imagen))
            ActualizarIcono(item, icono);
        if (item is ToolStripControlHost alojado) AplicarTemaHijos(alojado.Control);
        if (item is ToolStripDropDownItem menu)
        {
            menu.DropDown.Renderer = renderer;
            menu.DropDown.BackColor = AzulFondo;
            menu.DropDown.ForeColor = Texto;
            foreach (ToolStripItem hijo in menu.DropDownItems) AplicarTemaItem(hijo);
            menu.DropDown.Invalidate(true);
        }
    }

    internal static FlowLayoutPanel Pagina(TabControl cinta, string titulo)
    {
        var pagina = new TabPage(titulo)
        {
            Name = "espec_pestana_" + titulo,
            Padding = Padding.Empty,
            UseVisualStyleBackColor = false,
            BackColor = AzulFondo,
            ForeColor = Texto
        };
        var grupos = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Margin = Padding.Empty,
            Padding = Padding.Empty,
            AutoScroll = true,
            WrapContents = false,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = AzulFondo,
            ForeColor = Texto
        };
        pagina.Controls.Add(grupos);
        cinta.TabPages.Add(pagina);
        return grupos;
    }

    internal static Panel Grupo(FlowLayoutPanel padre, string titulo, int ancho)
    {
        var grupo = new GrupoCinta
        {
            Name = "espec_grupo_" + titulo,
            Size = new Size(ancho, 106),
            Margin = Padding.Empty,
            Padding = Padding.Empty,
            BackColor = AzulFondo,
            ForeColor = Texto
        };
        var fuente = new Font("Segoe UI", 9f);
        grupo.Disposed += (_, _) => fuente.Dispose();
        var etiqueta = new Label
        {
            Name = "espec_etiqueta_" + titulo,
            Text = titulo,
            Dock = DockStyle.Bottom,
            Height = 20,
            Font = fuente,
            TextAlign = ContentAlignment.MiddleCenter,
            BackColor = Color.Transparent,
            ForeColor = TextoDeshabilitado,
            AutoEllipsis = true
        };
        grupo.Controls.Add(etiqueta);
        if (titulo is "Fuente" or "Párrafo")
        {
            etiqueta.Paint += (_, e) =>
            {
                using var pen = new Pen(TextoDeshabilitado);
                int x = etiqueta.Width - 10, y = etiqueta.Height - 10;
                e.Graphics.DrawLines(pen, new[] { new Point(x + 5, y), new Point(x, y), new Point(x, y + 5) });
                e.Graphics.DrawLine(pen, x + 2, y + 2, x + 7, y + 7);
                e.Graphics.DrawLine(pen, x + 7, y + 7, x + 7, y + 3);
                e.Graphics.DrawLine(pen, x + 7, y + 7, x + 3, y + 7);
            };
        }
        padre.Controls.Add(grupo);
        return grupo;
    }

    internal static ToolStrip Fila(Panel grupo, int y, params ToolStripItem[] items)
    {
        var strip = new ToolStrip
        {
            Location = new Point(3, y),
            Width = Math.Max(1, grupo.ClientSize.Width - 7),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Dock = DockStyle.None,
            GripStyle = ToolStripGripStyle.Hidden,
            CanOverflow = false,
            AutoSize = false,
            Height = 28,
            Padding = new Padding(1, 1, 1, 1),
            Margin = Padding.Empty,
            BackColor = Color.Transparent,
            ForeColor = Texto,
            Renderer = renderer,
            ImageScalingSize = new Size(18, 18),
            LayoutStyle = ToolStripLayoutStyle.HorizontalStackWithOverflow
        };
        strip.Items.AddRange(items);
        int preferido = 24;
        foreach (ToolStripItem item in items) preferido = Math.Max(preferido, item.GetPreferredSize(Size.Empty).Height);
        strip.Height = preferido + 4;
        grupo.Controls.Add(strip);
        strip.BringToFront();
        return strip;
    }

    internal static void Icono(ToolStripItem item, string id, int tamano = 18, bool mostrarTexto = false)
    {
        var propiedad = recursos.GetValue(item, objeto =>
        {
            var nueva = new RecursosIcono();
            objeto.Disposed += (_, _) => nueva.Dispose();
            return nueva;
        });
        propiedad.Id = id;
        propiedad.Tamano = tamano;
        ActualizarIcono(item, propiedad);
        item.ImageScaling = ToolStripItemImageScaling.None;
        item.ForeColor = Texto;
        item.DisplayStyle = mostrarTexto ? ToolStripItemDisplayStyle.ImageAndText : ToolStripItemDisplayStyle.Image;
        item.TextImageRelation = mostrarTexto ? TextImageRelation.ImageAboveText : TextImageRelation.ImageBeforeText;
        item.ImageAlign = ContentAlignment.TopCenter;
        item.TextAlign = ContentAlignment.BottomCenter;
        item.Margin = new Padding(1, 0, 1, 0);
    }

    private static void ActualizarIcono(ToolStripItem item, RecursosIcono propiedad)
    {
        var anterior = propiedad.Imagen;
        propiedad.Imagen = DibujarIcono(propiedad.Id, propiedad.Tamano);
        item.Image = propiedad.Imagen;
        anterior?.Dispose();
    }

    internal static Bitmap DibujarIcono(string id, int size, bool seleccionado = false)
    {
        var bitmap = new Bitmap(Math.Max(8, size), Math.Max(8, size), System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bitmap);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.ScaleTransform(bitmap.Width / 24f, bitmap.Height / 24f);
        Color tinta = AltoContraste && seleccionado ? SystemColors.HighlightText : AzulIcono;
        using var azul = new Pen(tinta, 1.45f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
        using var gris = new Pen(AltoContraste ? tinta : TextoDeshabilitado, 1.2f);
        using var blanco = new SolidBrush(AltoContraste ? seleccionado ? SystemColors.Highlight : SystemColors.Control : MYG2027_TemaComercial.Superficie);
        using var azulRelleno = new SolidBrush(tinta);
        using var amarillo = new SolidBrush(AltoContraste ? tinta : Amarillo);
        using var rojo = new Pen(AltoContraste ? tinta : Oscuro ? Color.FromArgb(255, 151, 159) : Color.FromArgb(198, 86, 94), 1.5f);
        using var verde = new Pen(AltoContraste ? tinta : Oscuro ? Color.FromArgb(130, 214, 160) : Color.FromArgb(73, 136, 107), 1.4f);

        void Rect(float x, float y, float w, float h, Brush relleno = null, Pen borde = null)
        {
            if (relleno != null) g.FillRectangle(relleno, x, y, w, h);
            if (borde != null) g.DrawRectangle(borde, x, y, w, h);
        }
        void Linea(float x1, float y1, float x2, float y2, Pen p = null) => g.DrawLine(p ?? azul, x1, y1, x2, y2);
        void RectColor(float x, float y, float w, float h, Color color, Color? colorBorde = null)
        {
            using var b = new SolidBrush(color);
            using var p = colorBorde.HasValue ? new Pen(colorBorde.Value, 1) : null;
            Rect(x, y, w, h, b, p);
        }
        void LineaColor(float x1, float y1, float x2, float y2, Color color, float ancho = 1)
        {
            using var p = new Pen(color, ancho);
            Linea(x1, y1, x2, y2, p);
        }
        void TextoIcono(string texto, float x, float y, float ancho, float alto, float puntos = 11f,
            FontStyle estilo = FontStyle.Regular, Color? color = null)
        {
            using var f = new Font("Arial", puntos, estilo, GraphicsUnit.Pixel);
            using var b = new SolidBrush(AltoContraste ? tinta : color ?? tinta);
            using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            g.DrawString(texto, f, b, new RectangleF(x, y, ancho, alto), sf);
        }
        void Hoja(float x = 6, float y = 3, float w = 13, float h = 18)
        {
            Rect(x, y, w, h, blanco, gris);
            Linea(x + 3, y + 5, x + w - 3, y + 5);
            Linea(x + 3, y + 9, x + w - 3, y + 9);
            Linea(x + 3, y + 13, x + w - 3, y + 13);
        }
        void Flecha(float x, float y, bool derecha = true, Brush b = null)
        {
            g.FillPolygon(b ?? azulRelleno, derecha
                ? new[] { new PointF(x, y), new PointF(x - 5, y - 4), new PointF(x - 5, y + 4) }
                : new[] { new PointF(x, y), new PointF(x + 5, y - 4), new PointF(x + 5, y + 4) });
        }
        void LineasParrafo(string alineacion)
        {
            for (int i = 0; i < 5; i++)
            {
                float ancho = alineacion == "justificar" || i % 2 == 0 ? 18 : 12;
                float x = alineacion == "centro" ? (24 - ancho) / 2 : alineacion == "derecha" ? 21 - ancho : 3;
                Linea(x, 5 + i * 3.2f, x + ancho, 5 + i * 3.2f);
            }
        }

        switch ((id ?? "").ToLowerInvariant())
        {
            case "pegar":
                Rect(3, 3, 13, 17, amarillo); Rect(5, 4, 11, 15, blanco, azul);
                Rect(7, 1.5f, 7, 4, azulRelleno); Rect(11, 10, 10, 12, blanco, azul);
                Linea(14, 14, 18, 14); Linea(14, 17, 18, 17); break;
            case "cortar":
                g.DrawEllipse(gris, 3, 15, 6, 6); g.DrawEllipse(gris, 13, 15, 6, 6);
                Linea(7, 16, 17, 3, gris); Linea(16, 16, 6, 3, gris); break;
            case "copiar":
                Hoja(3, 2, 12, 16); Hoja(9, 7, 12, 15); break;
            case "deshacer":
            case "rehacer":
                bool derecha = id == "rehacer";
                g.DrawArc(azul, 5, 6, 15, 14, derecha ? 190 : 210, derecha ? 230 : -230);
                Flecha(derecha ? 21 : 3, 8, derecha); break;
            case "guardar":
            case "guardar_como":
                Rect(3, 2, 18, 20, azulRelleno, azul); Rect(7, 3, 11, 7, blanco);
                Rect(14, 3, 3, 6, azulRelleno); Rect(6, 13, 13, 8, blanco); Linea(8, 16, 16, 16, gris);
                if (id == "guardar_como") { g.FillPolygon(amarillo, new[] { new PointF(17, 10), new PointF(23, 10), new PointF(23, 19), new PointF(17, 22) }); }
                break;
            case "abrir":
                RectColor(2, 6, 19, 14, Amarillo, Color.FromArgb(218, 154, 39));
                Rect(3, 3, 8, 4, amarillo); g.FillPolygon(amarillo, new[] { new PointF(4, 10), new PointF(23, 10), new PointF(19, 21), new PointF(1, 21) }); break;
            case "nuevo": Hoja(5, 2, 15, 20); break;
            case "imprimir":
                Rect(6, 1, 12, 9, blanco, gris); Rect(2, 8, 20, 11, azulRelleno, azul);
                Rect(6, 13, 12, 9, blanco, gris); Linea(9, 16, 15, 16, gris); Linea(9, 19, 15, 19, gris);
                Rect(18, 10, 2, 2, amarillo); break;
            case "ortografia":
                TextoIcono("ABC", 1, 0, 21, 11, 9, FontStyle.Bold); Linea(4, 16, 9, 21, verde); Linea(9, 21, 20, 10, verde); break;
            case "izquierda": case "centro": case "derecha": case "justificar": LineasParrafo(id); break;
            case "vinyetas": case "numeracion": case "multinivel":
                for (int i = 0; i < 3; i++)
                {
                    float desplazamiento = id == "multinivel" ? i * 3 : 0;
                    if (id == "vinyetas") g.FillEllipse(azulRelleno, 2, 4 + i * 7, 3, 3);
                    else TextoIcono((i + 1).ToString(), 0 + desplazamiento, 1 + i * 7, 6, 7, 8, FontStyle.Regular, Color.FromArgb(224, 73, 96));
                    Linea(8 + desplazamiento, 5 + i * 7, 22, 5 + i * 7);
                    Linea(8 + desplazamiento, 8 + i * 7, 20, 8 + i * 7);
                }
                break;
            case "sangria_menos": case "sangria_mas":
                Linea(2, 3, 22, 3); Linea(2, 21, 22, 21);
                Linea(12, 7, 22, 7); Linea(12, 11, 22, 11); Linea(12, 15, 22, 15);
                Flecha(id == "sangria_mas" ? 9 : 2, 12, id == "sangria_mas"); break;
            case "parrafo": TextoIcono("¶", 1, 0, 22, 23, 23, FontStyle.Bold); break;
            case "fuente": TextoIcono("A", 1, 0, 22, 23, 21, FontStyle.Regular); break;
            case "marcador":
                Hoja(5, 2, 15, 20);
                using (var rellenoMarcador = new SolidBrush(rojo.Color))
                    g.FillPolygon(rellenoMarcador, new[] { new PointF(10, 3), new PointF(16, 3), new PointF(16, 14), new PointF(13, 11), new PointF(10, 14) });
                break;
            case "enlace":
                g.DrawEllipse(azul, 1, 9, 13, 8); g.DrawEllipse(azul, 10, 4, 13, 8);
                Linea(8, 14, 16, 9, azul); break;
            case "comentario":
                Rect(2, 3, 20, 14, amarillo, gris);
                g.FillPolygon(amarillo, new[] { new PointF(5, 16), new PointF(11, 16), new PointF(5, 22) });
                Linea(6, 7, 18, 7, gris); Linea(6, 11, 15, 11, gris); break;
            case "interlineado":
                Linea(5, 5, 5, 19); g.FillPolygon(azulRelleno, new[] { new PointF(5, 2), new PointF(2, 6), new PointF(8, 6) });
                g.FillPolygon(azulRelleno, new[] { new PointF(5, 22), new PointF(2, 18), new PointF(8, 18) });
                Linea(11, 5, 22, 5); Linea(11, 10, 22, 10); Linea(11, 15, 22, 15); Linea(11, 20, 22, 20); break;
            case "color_fondo":
                g.FillPolygon(azulRelleno, new[] { new PointF(3, 10), new PointF(10, 3), new PointF(17, 10), new PointF(10, 17) });
                LineaColor(10, 4, 5, 9, Color.White, 1.2f); RectColor(2, 20, 19, 3, Color.FromArgb(196, 210, 230));
                g.FillEllipse(azulRelleno, 18, 13, 4, 6); break;
            case "estilos":
                Rect(1.5f, 1.5f, 21, 21, blanco, gris); TextoIcono("A", 2, 3, 14, 18, 16, FontStyle.Regular);
                Linea(12, 19, 20, 9, rojo); Linea(12, 19, 15, 18, rojo); break;
            case "buscar":
                g.DrawEllipse(azul, 3, 3, 12, 12); Linea(13, 13, 21, 21, azul); break;
            case "reemplazar":
                TextoIcono("A", 0, 0, 10, 13, 12, FontStyle.Bold); TextoIcono("B", 13, 10, 10, 13, 12, FontStyle.Bold, Color.FromArgb(35, 169, 86));
                Linea(6, 18, 14, 18); Flecha(15, 18); break;
            case "tabla":
                Rect(2, 3, 20, 18, blanco, azul); RectColor(2, 3, 20, 4, MYG2027_TemaComercial.AzulSuave);
                for (int x = 7; x < 22; x += 5) Linea(x, 3, x, 21);
                for (int y = 7; y < 21; y += 5) Linea(2, y, 22, y); break;
            case "imagen":
                Rect(2, 3, 20, 18, blanco, azul); g.FillEllipse(amarillo, 15, 6, 4, 4);
                using (var montanas = new SolidBrush(Color.FromArgb(76, 153, 109)))
                    g.FillPolygon(montanas, new[] { new PointF(3, 19), new PointF(9, 10), new PointF(14, 16), new PointF(18, 12), new PointF(21, 19) });
                break;
            case "salto":
                Rect(7, 1, 14, 9, blanco, gris); Rect(7, 15, 14, 8, blanco, gris);
                using (var punteado = new Pen(AzulIcono, 1) { DashStyle = DashStyle.Dot }) Linea(2, 12, 23, 12, punteado);
                Linea(3, 3, 3, 9); g.FillPolygon(azulRelleno, new[] { new PointF(3, 11), new PointF(0, 7), new PointF(6, 7) }); break;
            case "encabezado": case "pie":
                Hoja(5, 2, 14, 20); RectColor(6, id == "encabezado" ? 3 : 17, 12, 4, Color.FromArgb(250, 214, 100));
                Linea(7, 12, 17, 12, gris); break;
            case "simbolo": TextoIcono("Ω", 0, 0, 24, 24, 24); break;
            case "word": case "pdf":
                using (var sombra = new SolidBrush(MYG2027_TemaComercial.Borde))
                    g.FillPolygon(sombra, new[] { new PointF(7, 3), new PointF(20, 1), new PointF(20, 21), new PointF(7, 23) });
                Rect(11, 5, 13, 17, blanco);
                for (int y = 8; y < 22; y += 3) Linea(13, y, 22, y, gris);
                using (var bloque = new SolidBrush(id == "word" ? MYG2027_TemaComercial.Azul : MYG2027_TemaComercial.Secundario))
                    g.FillPolygon(bloque, new[] { new PointF(2, 6), new PointF(15, 4), new PointF(15, 22), new PointF(2, 20) });
                TextoIcono(id == "word" ? "W" : "PDF", 2, 7, 13, 12, id == "word" ? 10 : 6.7f, FontStyle.Bold, Color.White); break;
            case "regla":
                RectColor(1, 8, 22, 9, Amarillo, MYG2027_TemaComercial.Secundario);
                for (int x = 4; x < 23; x += 3) LineaColor(x, 8, x, x % 2 == 0 ? 14 : 12, MYG2027_TemaComercial.Texto);
                break;
            case "pagina": Hoja(6, 2, 14, 20); break;
            case "zoom_menos": case "zoom_mas":
                g.DrawEllipse(azul, 2, 2, 14, 14); Linea(14, 14, 22, 22); Linea(5, 9, 13, 9);
                if (id == "zoom_mas") Linea(9, 5, 9, 13); break;
            case "margenes":
                Hoja(4, 1, 16, 22);
                using (var p = new Pen(Color.FromArgb(221, 74, 100), 1) { DashStyle = DashStyle.Dot }) Rect(7, 5, 10, 14, null, p);
                break;
            case "orientacion":
                Rect(2, 2, 12, 16, blanco, azul); Rect(9, 11, 14, 10, blanco, azul);
                g.DrawArc(azul, 13, 1, 8, 8, 250, 180); Flecha(22, 7); break;
            case "tamano":
                Hoja(7, 2, 14, 20); Linea(3, 4, 3, 20); Linea(1, 4, 5, 4); Linea(1, 20, 5, 20); break;
            case "columnas":
                Rect(2, 2, 20, 20, blanco, azul); Linea(12, 4, 12, 20, gris);
                for (int y = 6; y < 20; y += 3) { Linea(5, y, 10, y); Linea(14, y, 19, y); } break;
            case "lineas":
                Hoja(8, 2, 14, 20);
                for (int i = 0; i < 3; i++) TextoIcono((i + 1).ToString(), 0, 4 + i * 5, 7, 6, 7, FontStyle.Regular, Color.FromArgb(230, 84, 111));
                break;
            case "color_pagina":
                RectColor(5, 2, 15, 20, Color.FromArgb(222, 246, 208), AzulIcono);
                g.FillEllipse(amarillo, 11, 9, 9, 9); Linea(9, 16, 17, 7, verde); break;
            case "aumentar_fuente": case "reducir_fuente":
                TextoIcono("A", 0, 4, 18, 20, id == "aumentar_fuente" ? 20 : 16);
                g.FillPolygon(azulRelleno, id == "aumentar_fuente"
                    ? new[] { new PointF(19, 3), new PointF(16, 7), new PointF(22, 7) }
                    : new[] { new PointF(19, 8), new PointF(16, 4), new PointF(22, 4) }); break;
            case "color_fuente":
                TextoIcono("A", 1, 0, 22, 20, 20); Rect(3, 21, 18, 3, azulRelleno); break;
            case "resaltar":
                RectColor(2, 20, 18, 4, Color.FromArgb(230, 232, 121));
                g.FillPolygon(azulRelleno, new[] { new PointF(7, 17), new PointF(17, 3), new PointF(22, 7), new PointF(12, 21) });
                LineaColor(10, 15, 14, 18, Color.White, 1.5f); break;
            case "borrar_formato":
                TextoIcono("abc", 0, 0, 24, 15, 10, FontStyle.Bold);
                using (var goma = new SolidBrush(Color.FromArgb(235, 84, 124)))
                    g.FillPolygon(goma, new[] { new PointF(12, 17), new PointF(18, 11), new PointF(23, 16), new PointF(17, 22) });
                Linea(13, 19, 16, 22, gris); break;
            default:
                TextoIcono(id?.Length > 0 ? id[..1].ToUpperInvariant() : "•", 1, 1, 22, 22, 18, FontStyle.Bold); break;
        }
        return bitmap;
    }

    private sealed class RecursosIcono : IDisposable
    {
        internal Image Imagen;
        internal string Id;
        internal int Tamano;
        public void Dispose() { Imagen?.Dispose(); Imagen = null; }
    }
    private sealed class GrupoCinta : Panel
    {
        internal GrupoCinta() => SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            if (ClientSize.Width == 0 || ClientSize.Height == 0) return;
            using var fondo = new SolidBrush(AzulFondo);
            e.Graphics.FillRectangle(fondo, ClientRectangle);
            using var borde = new Pen(AzulBorde);
            e.Graphics.DrawLine(borde, Width - 1, 9, Width - 1, Height - 9);
        }
    }

    // Un temporizador por fila, sólo durante los 120 ms del cambio. No anima el
    // documento, los estados marcados ni las sesiones con animación desactivada.
    private sealed class AnimacionHover : IDisposable
    {
        private readonly ToolStrip propietario;
        private readonly System.Windows.Forms.Timer reloj = new() { Interval = 16 };
        private readonly Dictionary<ToolStripItem, Transicion> estados = new();
        private readonly List<ToolStripItem> terminados = new();
        private bool liberada;

        internal AnimacionHover(ToolStrip propietario)
        {
            this.propietario = propietario;
            propietario.Disposed += Liberar;
            reloj.Tick += Avanzar;
        }

        internal float Valor(ToolStripItem item, bool seleccionado)
        {
            if (liberada) return seleccionado ? 1f : 0f;
            if (!estados.TryGetValue(item, out var estado))
            {
                if (!seleccionado) return 0f;
                estados.Add(item, estado = new Transicion());
            }
            long ahora = Environment.TickCount64;
            float actual = estado.Valor(ahora), objetivo = seleccionado ? 1f : 0f;
            if (estado.Objetivo != objetivo)
            {
                estado.Desde = actual;
                estado.Objetivo = objetivo;
                estado.Inicio = ahora;
                reloj.Start();
            }
            return actual;
        }

        private void Avanzar(object sender, EventArgs e)
        {
            if (liberada) return;
            if (!propietario.Visible)
            {
                reloj.Stop(); estados.Clear(); return;
            }
            long ahora = Environment.TickCount64;
            bool pendiente = false;
            terminados.Clear();
            foreach (var par in estados)
            {
                if (par.Key.IsDisposed || !ReferenceEquals(par.Key.Owner, propietario))
                {
                    terminados.Add(par.Key); continue;
                }
                propietario.Invalidate(par.Key.Bounds);
                if (ahora - par.Value.Inicio < 120) pendiente = true;
                else if (par.Value.Objetivo == 0) terminados.Add(par.Key);
            }
            foreach (var item in terminados) estados.Remove(item);
            terminados.Clear();
            if (!pendiente) reloj.Stop();
        }

        private void Liberar(object sender, EventArgs e) => Dispose();
        public void Dispose()
        {
            if (liberada) return;
            liberada = true;
            propietario.Disposed -= Liberar;
            reloj.Stop(); reloj.Dispose(); estados.Clear(); terminados.Clear();
        }

        private sealed class Transicion
        {
            internal float Desde, Objetivo;
            internal long Inicio;
            internal float Valor(long ahora)
            {
                float t = Math.Clamp((ahora - Inicio) / 120f, 0f, 1f);
                float suavizado = 1f - (1f - t) * (1f - t) * (1f - t);
                return Desde + (Objetivo - Desde) * suavizado;
            }
        }
    }

    private sealed class RendererCinta : ToolStripProfessionalRenderer
    {
        internal RendererCinta() : base(new ColoresCinta()) => RoundedEdges = false;
        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {
            if (e.ToolStrip is not ToolStripDropDown) return;
            using var fondo = new SolidBrush(AzulFondo);
            e.Graphics.FillRectangle(fondo, e.AffectedBounds);
        }
        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
        {
            if (e.ToolStrip is not ToolStripDropDown || e.ToolStrip.Width < 2 || e.ToolStrip.Height < 2) return;
            using var borde = new Pen(AzulBorde);
            e.Graphics.DrawRectangle(borde, 0, 0, e.ToolStrip.Width - 1, e.ToolStrip.Height - 1);
        }
        protected override void OnRenderImageMargin(ToolStripRenderEventArgs e)
        {
            using var fondo = new SolidBrush(AzulFondo);
            e.Graphics.FillRectangle(fondo, e.AffectedBounds);
        }
        protected override void OnRenderSeparator(ToolStripSeparatorRenderEventArgs e)
        {
            using var borde = new Pen(AzulBorde);
            if (e.Vertical) e.Graphics.DrawLine(borde, e.Item.Width / 2, 5, e.Item.Width / 2, e.Item.Height - 5);
            else e.Graphics.DrawLine(borde, 8, e.Item.Height / 2, e.Item.Width - 8, e.Item.Height / 2);
        }
        protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e)
        {
            var boton = (ToolStripButton)e.Item;
            DibujarEstado(e, boton.Checked || boton.Pressed, boton.Selected);
        }
        protected override void OnRenderDropDownButtonBackground(ToolStripItemRenderEventArgs e) => DibujarEstado(e, e.Item.Pressed, e.Item.Selected);
        protected override void OnRenderSplitButtonBackground(ToolStripItemRenderEventArgs e) => DibujarEstado(e, e.Item.Pressed, e.Item.Selected);
        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e) => DibujarEstado(e, e.Item.Pressed, e.Item.Selected);
        private static void DibujarEstado(ToolStripItemRenderEventArgs e, bool activo, bool seleccionado)
        {
            if (!e.Item.Enabled) seleccionado = activo = false;
            float hover = seleccionado ? 1f : 0f;
            if (e.ToolStrip is { IsDisposed: false } fila && fila is not ToolStripDropDown &&
                !AltoContraste && SystemInformation.IsMenuAnimationEnabled && !SystemInformation.TerminalServerSession)
                hover = animaciones.GetValue(fila, propietario => new AnimacionHover(propietario)).Valor(e.Item, seleccionado);
            if (!activo && hover <= 0f) return;
            Rectangle r = new(1, 1, e.Item.Width - 3, e.Item.Height - 3);
            if (r.Width <= 0 || r.Height <= 0) return;
            using var fondo = new SolidBrush(activo ? FondoSeleccion : Color.FromArgb((int)(hover * 255), FondoHover));
            using var borde = new Pen(BordeSeleccion);
            if (AltoContraste)
            {
                e.Graphics.FillRectangle(fondo, r); e.Graphics.DrawRectangle(borde, r);
                return;
            }
            var guardado = e.Graphics.Save();
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var contorno = MYG2027_TemaComercial.Contorno(r, 4f * e.ToolStrip.DeviceDpi / 96f);
            e.Graphics.FillPath(fondo, contorno);
            if (activo) e.Graphics.DrawPath(borde, contorno);
            e.Graphics.Restore(guardado);
        }
        protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
        {
            e.ArrowColor = ColorTextoItem(e.Item);
            base.OnRenderArrow(e);
        }
        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            e.TextColor = ColorTextoItem(e.Item);
            base.OnRenderItemText(e);
        }

        protected override void OnRenderItemImage(ToolStripItemImageRenderEventArgs e)
        {
            bool activo = e.Item.Selected || e.Item.Pressed || e.Item is ToolStripButton boton && boton.Checked;
            if (AltoContraste && activo && e.Item.Enabled && recursos.TryGetValue(e.Item, out var icono) &&
                ReferenceEquals(e.Item.Image, icono.Imagen) && e.ImageRectangle.Width > 0)
            {
                using var imagen = DibujarIcono(icono.Id, e.ImageRectangle.Width, true);
                e.Graphics.DrawImage(imagen, e.ImageRectangle);
                return;
            }
            base.OnRenderItemImage(e);
        }

        protected override void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e)
        {
            Rectangle r = e.ImageRectangle;
            if (r.Width <= 0 || r.Height <= 0) return;
            using var fondo = new SolidBrush(FondoSeleccion);
            using var borde = new Pen(BordeSeleccion);
            var guardado = e.Graphics.Save();
            if (AltoContraste)
            {
                e.Graphics.FillRectangle(fondo, r);
                e.Graphics.DrawRectangle(borde, r.Left, r.Top, r.Width - 1, r.Height - 1);
            }
            else
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var contorno = MYG2027_TemaComercial.Contorno(new Rectangle(r.Left, r.Top, r.Width - 1, r.Height - 1), 3);
                e.Graphics.FillPath(fondo, contorno);
                e.Graphics.DrawPath(borde, contorno);
            }
            using var marca = new Pen(ColorTextoItem(e.Item), Math.Max(1.5f, r.Height / 9f))
                { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
            e.Graphics.DrawLines(marca, new[] { new PointF(r.Left + r.Width * .22f, r.Top + r.Height * .5f),
                new PointF(r.Left + r.Width * .43f, r.Top + r.Height * .7f),
                new PointF(r.Left + r.Width * .8f, r.Top + r.Height * .28f) });
            e.Graphics.Restore(guardado);
        }

        private static Color ColorTextoItem(ToolStripItem item)
        {
            if (!item.Enabled) return TextoDeshabilitado;
            bool activo = item.Selected || item.Pressed || item is ToolStripButton boton && boton.Checked;
            return AltoContraste && activo ? SystemColors.HighlightText : Texto;
        }
    }
    private sealed class ColoresCinta : ProfessionalColorTable
    {
        public override Color ToolStripDropDownBackground => AzulFondo;
        public override Color MenuBorder => AzulBorde;
        public override Color MenuItemBorder => BordeSeleccion;
        public override Color MenuItemSelected => FondoHover;
        public override Color MenuItemSelectedGradientBegin => FondoHover;
        public override Color MenuItemSelectedGradientEnd => FondoHover;
        public override Color MenuItemPressedGradientBegin => FondoSeleccion;
        public override Color MenuItemPressedGradientMiddle => FondoSeleccion;
        public override Color MenuItemPressedGradientEnd => FondoSeleccion;
        public override Color CheckBackground => FondoSeleccion;
        public override Color CheckSelectedBackground => FondoSeleccion;
        public override Color CheckPressedBackground => FondoSeleccion;
        public override Color ImageMarginGradientBegin => AzulFondo;
        public override Color ImageMarginGradientMiddle => AzulFondo;
        public override Color ImageMarginGradientEnd => AzulFondo;
        public override Color SeparatorDark => AzulBorde;
        public override Color SeparatorLight => AzulFondo;
    }
}
