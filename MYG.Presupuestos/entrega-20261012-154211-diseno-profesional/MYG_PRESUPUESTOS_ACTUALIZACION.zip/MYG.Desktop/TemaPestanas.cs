using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace MYG_2027;

// La barra conserva navegación nativa; su indicador se mueve sin animar el contenido.
internal sealed class MYGTemaPestanas : NativeWindow, IDisposable
{
    private static readonly ConditionalWeakTable<TabControl, MYGTemaPestanas> ventanas = new();
    private readonly TabControl pestanas;
    private readonly System.Windows.Forms.Timer reloj = new() { Interval = 16 };
    private readonly Stopwatch tiempo = new();
    private RectangleF indicador, desde, hasta;
    private int sobre = -1;
    private bool preparado, liberado;

    internal static void Aplicar(TabControl pestanas)
    {
        if (pestanas == null || pestanas.IsDisposed) return;
        ventanas.GetValue(pestanas, p => new MYGTemaPestanas(p)).Actualizar();
    }
    internal static void Preparar(TabControl pestanas)
    {
        if (pestanas == null || pestanas.IsDisposed) return;
        ventanas.GetValue(pestanas, p => new MYGTemaPestanas(p)).Preparar();
    }
    private MYGTemaPestanas(TabControl pestanas)
    {
        this.pestanas = pestanas;
        pestanas.HandleCreated += CrearHandle; pestanas.HandleDestroyed += DestruirHandle;
        pestanas.Disposed += Liberar; pestanas.SelectedIndexChanged += CambiarSeleccion;
        pestanas.MouseMove += MoverRaton; pestanas.MouseLeave += SalirRaton;
        pestanas.VisibleChanged += CambiarGeometria; pestanas.SizeChanged += CambiarGeometria;
        pestanas.DpiChangedAfterParent += CambiarDpi; reloj.Tick += Animar;
        if (pestanas.IsHandleCreated) AssignHandle(pestanas.Handle);
    }
    private void Preparar()
    {
        if (pestanas.Alignment is TabAlignment.Left or TabAlignment.Right) return;
        if (!preparado)
        {
            preparado = true;
            pestanas.DrawMode = TabDrawMode.OwnerDrawFixed;
            pestanas.DrawItem += DibujarPestana;
            AjustarMedidas();
        }
        Actualizar();
    }
    private void AjustarMedidas()
    {
        float escala = pestanas.DeviceDpi / 96f;
        int alto = Math.Max((int)Math.Round(34 * escala), pestanas.Font.Height + (int)Math.Round(12 * escala));
        pestanas.ItemSize = new Size(pestanas.ItemSize.Width, alto);
        pestanas.Padding = new Point((int)Math.Round(12 * escala), (int)Math.Round(5 * escala));
    }
    private void Actualizar()
    {
        if (liberado) return;
        reloj.Stop(); indicador = IndicadorActual(); pestanas.Invalidate();
    }
    private RectangleF IndicadorActual()
    {
        if (!preparado || !pestanas.IsHandleCreated || pestanas.SelectedIndex < 0 ||
            pestanas.SelectedIndex >= pestanas.TabCount) return RectangleF.Empty;
        Rectangle r = pestanas.GetTabRect(pestanas.SelectedIndex);
        float escala = pestanas.DeviceDpi / 96f, margen = Math.Min(12 * escala, r.Width / 4f);
        float alto = Math.Max(2, 2 * escala);
        return new RectangleF(r.Left + margen,
            pestanas.Alignment == TabAlignment.Bottom ? r.Top + 1 : r.Bottom - alto - 1,
            Math.Max(1, r.Width - 2 * margen), alto);
    }
    private void CambiarSeleccion(object sender, EventArgs e)
    {
        RectangleF destino = IndicadorActual();
        if (!preparado || !pestanas.Visible || destino.IsEmpty || indicador.IsEmpty ||
            !SystemInformation.IsMenuAnimationEnabled || SystemInformation.HighContrast || SystemInformation.TerminalServerSession)
        { Actualizar(); return; }
        desde = indicador; hasta = destino; tiempo.Restart(); reloj.Start(); pestanas.Invalidate();
    }
    private void Animar(object sender, EventArgs e)
    {
        if (liberado || !pestanas.Visible || !pestanas.IsHandleCreated ||
            !SystemInformation.IsMenuAnimationEnabled || SystemInformation.HighContrast || SystemInformation.TerminalServerSession)
        { Actualizar(); return; }
        double t = Math.Min(1, tiempo.Elapsed.TotalMilliseconds / 150d);
        float suave = (float)(t * t * (3 - 2 * t));
        indicador = new RectangleF(desde.X + (hasta.X - desde.X) * suave, desde.Y + (hasta.Y - desde.Y) * suave,
            desde.Width + (hasta.Width - desde.Width) * suave, hasta.Height);
        pestanas.Invalidate();
        if (t >= 1) reloj.Stop();
    }
    private void MoverRaton(object sender, MouseEventArgs e)
    {
        if (!preparado) return;
        int nuevo = -1;
        for (int i = 0; i < pestanas.TabCount; i++)
            if (pestanas.GetTabRect(i).Contains(e.Location)) { nuevo = i; break; }
        if (nuevo == sobre) return;
        sobre = nuevo; pestanas.Invalidate();
    }
    private void SalirRaton(object sender, EventArgs e) { sobre = -1; pestanas.Invalidate(); }
    private void CambiarGeometria(object sender, EventArgs e) => Actualizar();
    private void CambiarDpi(object sender, EventArgs e) { if (preparado) AjustarMedidas(); Actualizar(); }
    private void CrearHandle(object sender, EventArgs e) { AssignHandle(pestanas.Handle); Actualizar(); }
    private void DestruirHandle(object sender, EventArgs e) { reloj.Stop(); ReleaseHandle(); }
    private void Liberar(object sender, EventArgs e) => Dispose();

    private void DibujarPestana(object sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= pestanas.TabCount || e.Bounds.Width <= 0 || e.Bounds.Height <= 0) return;
        bool seleccionada = e.Index == pestanas.SelectedIndex, contraste = SystemInformation.HighContrast;
        Color fondo = contraste ? SystemColors.Control : MYG2027_TemaComercial.Fondo;
        Color activo = contraste ? SystemColors.Highlight : MYG2027_TemaComercial.Superficie;
        Color texto = !pestanas.TabPages[e.Index].Enabled ? MYG2027_TemaComercial.Secundario :
            contraste ? seleccionada ? SystemColors.HighlightText : SystemColors.ControlText
            : seleccionada ? MYG2027_TemaComercial.Texto : MYG2027_TemaComercial.Secundario;
        using (var brocha = new SolidBrush(fondo)) e.Graphics.FillRectangle(brocha, e.Bounds);
        var interior = e.Bounds; interior.Inflate(-2, -2);
        if (seleccionada || !contraste && sobre == e.Index)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var forma = MYG2027_TemaComercial.Contorno(interior, 6f * pestanas.DeviceDpi / 96f);
            using var brocha = new SolidBrush(seleccionada ? activo : MYG2027_TemaComercial.SuperficieAlterna);
            e.Graphics.FillPath(brocha, forma);
        }
        Rectangle etiqueta = interior; etiqueta.Inflate(-8, -3);
        TabPage pagina = pestanas.TabPages[e.Index];
        if (pestanas.ImageList != null)
        {
            int indice = !string.IsNullOrEmpty(pagina.ImageKey) ? pestanas.ImageList.Images.IndexOfKey(pagina.ImageKey) : pagina.ImageIndex;
            if (indice >= 0 && indice < pestanas.ImageList.Images.Count)
            {
                int tamano = (int)Math.Round(16 * pestanas.DeviceDpi / 96f);
                e.Graphics.DrawImage(pestanas.ImageList.Images[indice], etiqueta.Left,
                    etiqueta.Top + (etiqueta.Height - tamano) / 2, tamano, tamano);
                etiqueta.X += tamano + 6; etiqueta.Width -= tamano + 6;
            }
        }
        TextRenderer.DrawText(e.Graphics, pagina.Text, pestanas.Font, etiqueta, texto,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        if (seleccionada && pestanas.Focused && (e.State & DrawItemState.NoFocusRect) == 0)
        {
            var foco = interior; foco.Inflate(-3, -3);
            ControlPaint.DrawFocusRectangle(e.Graphics, foco, texto, activo);
        }
    }

    protected override void WndProc(ref Message mensaje)
    {
        base.WndProc(ref mensaje);
        if (mensaje.Msg != 0x000F || pestanas.IsDisposed || !pestanas.Visible ||
            (!preparado && !MYG2027_TemaComercial.Oscuro)) return;
        using var espacio = new Region(pestanas.ClientRectangle);
        if (pestanas.SelectedTab != null) espacio.Exclude(pestanas.SelectedTab.Bounds);
        for (int i = 0; i < pestanas.TabCount; i++) espacio.Exclude(pestanas.GetTabRect(i));
        using var grafico = pestanas.CreateGraphics();
        using var fondo = new SolidBrush(SystemInformation.HighContrast ? SystemColors.Control : MYG2027_TemaComercial.Fondo);
        grafico.FillRegion(fondo, espacio);
        if (!preparado || indicador.IsEmpty) return;
        using var barra = new Region(pestanas.ClientRectangle);
        if (pestanas.SelectedTab != null) barra.Exclude(pestanas.SelectedTab.Bounds);
        grafico.SetClip(barra, CombineMode.Replace);
        using var acento = new SolidBrush(MYG2027_TemaComercial.Azul);
        grafico.FillRectangle(acento, indicador);
    }
    public void Dispose()
    {
        if (liberado) return;
        liberado = true; reloj.Stop(); reloj.Dispose();
        pestanas.HandleCreated -= CrearHandle; pestanas.HandleDestroyed -= DestruirHandle;
        pestanas.Disposed -= Liberar; pestanas.SelectedIndexChanged -= CambiarSeleccion;
        pestanas.MouseMove -= MoverRaton; pestanas.MouseLeave -= SalirRaton;
        pestanas.VisibleChanged -= CambiarGeometria; pestanas.SizeChanged -= CambiarGeometria;
        pestanas.DpiChangedAfterParent -= CambiarDpi;
        if (preparado) pestanas.DrawItem -= DibujarPestana;
        ReleaseHandle(); ventanas.Remove(pestanas);
    }
}
