using System;
using System.Drawing;
using System.Windows.Forms;
using MYG_2027;

internal static class DisenoProfesionalCheck
{
    private sealed class PestanasPrueba : TabControl
    {
        internal bool Navegar(Keys tecla)
        {
            var mensaje = Message.Create(Handle, 0x0100, new IntPtr((int)(tecla & Keys.KeyCode)), IntPtr.Zero);
            return ProcessCmdKey(ref mensaje, tecla);
        }
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            foreach (TabAlignment alineacion in new[] { TabAlignment.Top, TabAlignment.Bottom })
            {
                using var formulario = new Form { ClientSize = new Size(700, 450) };
                using var pestanas = new PestanasPrueba { Dock = DockStyle.Fill, Alignment = alineacion };
                using var primera = new TabPage("Presupuesto");
                using var segunda = new TabPage("Especificaciones");
                using var texto = new TextBox { Text = "PARTIDA12145", Dock = DockStyle.Top };
                using var documento = new RichTextBox { Dock = DockStyle.Fill,
                    Rtf = @"{\rtf1\ansi{\colortbl;\red22\green90\blue52;}\b TITULO\b0\par\cf1 Texto de autor conservado.}" };
                primera.Controls.Add(texto); segunda.Controls.Add(documento);
                pestanas.TabPages.AddRange(new[] { primera, segunda });
                formulario.Controls.Add(pestanas); formulario.Show();
                MYG2027_TemaComercial.Aplicar(formulario);
                string rtf = documento.Rtf;
                int cambios = 0;
                pestanas.SelectedIndexChanged += (_, _) => cambios++;
                for (int modo = 0; modo < 2; modo++)
                {
                    int seleccion = pestanas.SelectedIndex;
                    MYGTemaPestanas.Preparar(pestanas);
                    MYGTemaPestanas.Preparar(pestanas);
                    Application.DoEvents();
                    exige(pestanas.SelectedIndex == seleccion && texto.Text == "PARTIDA12145" && documento.Rtf == rtf,
                        "Reaplicar el diseño debe conservar selección, nombre y formato de autor.");
                    pestanas.SelectedIndex = 0;
                    int antes = cambios;
                    pestanas.Focus();
                    exige(pestanas.Navegar(Keys.Control | Keys.Tab) && pestanas.SelectedIndex == 1 && cambios == antes + 1,
                        "Las pestañas modernas deben conservar Ctrl+Tab y emitir un solo cambio de selección.");
                    Application.DoEvents();
                    exige(documento.Visible && documento.Rtf == rtf,
                        "La transición debe mostrar el documento inmediatamente sin transformar su RTF.");
                    exige(pestanas.Navegar(Keys.Control | Keys.Shift | Keys.Tab) && pestanas.SelectedIndex == 0,
                        "Ctrl+Shift+Tab debe conservar la navegación inversa.");
                    texto.Focus(); texto.Select(3, 4);
                    MYG2027_TemaComercial.Alternar(false);
                    Application.DoEvents();
                    exige(texto.Text == "PARTIDA12145" && texto.SelectionStart == 3 && texto.SelectionLength == 4 &&
                        documento.Rtf == rtf,
                        "Cambiar de tema debe preservar el texto, la selección de edición y los colores de autor.");
                }
                // Cerrar durante una transición ejercita la liberación de su timer y ventana nativa.
                pestanas.SelectedIndex = 1;
                formulario.Close();
                Application.DoEvents();
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != original) MYG2027_TemaComercial.Alternar(false);
        }
    }

    internal static double Contraste(Color a, Color b)
    {
        static double Canal(byte valor)
        {
            double v = valor / 255d;
            return v <= .04045 ? v / 12.92 : Math.Pow((v + .055) / 1.055, 2.4);
        }
        static double Luz(Color c) => .2126 * Canal(c.R) + .7152 * Canal(c.G) + .0722 * Canal(c.B);
        double x = Luz(a), y = Luz(b);
        return (Math.Max(x, y) + .05) / (Math.Min(x, y) + .05);
    }
}
