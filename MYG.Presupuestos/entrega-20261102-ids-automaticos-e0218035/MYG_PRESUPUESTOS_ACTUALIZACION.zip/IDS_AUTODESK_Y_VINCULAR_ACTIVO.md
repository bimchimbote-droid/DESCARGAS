# Activos Revit: IDs automáticos y Vincular junto al documento

Actualización incremental sobre la entrega anterior de IDs/vinculación publicada en DESCARGAS, commit `23eb2790f19e61c4539e009c5d07ee87c1dbb495`. Se comprobó main en `a3130eca22fb423fbe7aae665a02dccdb379522c`. Se entregan únicamente los archivos cambiados respecto de esa entrega, completos y conservando las rutas.

## Cambios solicitados
- **Vincular** está a la derecha de **Documento Revit · ID**, junto al texto Pendiente de vincular. Se retiró de la barra superior.
- Se eliminaron ambos botones **Copiar** y las instrucciones de copiar/pegar IDs.
- **Traer del modelo abierto** rellena automáticamente origen, ambos IDs Autodesk y la referencia correspondiente. Para un RVT local no se necesitan IDs Autodesk.
- Si sólo hay un modelo se consulta automáticamente. Con dos o más aparece el selector, también para varios archivos abiertos dentro de una misma instancia con el conector actualizado. Se distingue cada modelo por nombre/ruta/identidad.
- Cancelar o recibir un error conserva los campos y el borrador. Los cambios se confirman con Aplicar a la obra y después Guardar.

## Corrección del error de objeto inválido
El conector guardaba documentos Revit como claves de un Dictionary. Al retirar documentos cerrados podía invocar GetHashCode sobre un objeto nativo inválido. Ahora mantiene un registro por apertura que se limpia por índice, sin volver a utilizar esas claves cerradas; sólo compara documentos válidos.

Traer IDs utiliza además **INFO SoloIdentidad**: lee los identificadores directamente sin cargar plantillas ni recorrer sus tablas. La búsqueda ligera no depende de una ventana activa que esté cerrándose, y la consulta posterior usa exclusivamente el documento elegido. No se activa otro archivo ni se realizan transacciones para leer los IDs. Las operaciones que modifican Revit conservan sus controles de identidad del modelo activo.

## Instalación obligatoria
**No basta actualizar el escritorio: hay que reinstalar el conector y reiniciar todas las instancias de Revit.** De otro modo seguirá ejecutándose la DLL anterior que puede producir el error de la captura.

1. Cierre MYG y todas las ventanas de Revit. Respalde o confirme sus cambios locales. Compare los archivos si tiene modificaciones posteriores a la entrega anterior.
2. Extraiga el ZIP en una carpeta temporal y copie los archivos a la raíz del repositorio conservando sus rutas. No sobrescriba bases SQLite, datos de obras ni sidecars de nube.
3. Desde esa raíz en Windows, con .NET 10 y Revit 2027 instalado:

```powershell
dotnet restore MYG.Presupuestos.sln
dotnet build MYG.Presupuestos.sln -c Release
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Actualizar-Conector.ps1
```

Si Revit está en otra ubicación, indique `-RevitInstallDir` al script existente. El script recompila e instala el conector y su MYG.Core.dll actual. No reinstale una carpeta dist antigua. Abra Revit de nuevo y ejecute la aplicación recompilada.

No hay SQL, paquetes nuevos ni credenciales adicionales. Se conservan la configuración de MYG Nube y los permisos existentes; la consulta no amplía el permiso de edición.

## Uso
1. Abra el RVT en Revit con el conector actualizado.
2. En Activos Revit de la obra, escriba el nombre del activo y pulse **Traer del modelo abierto**.
3. Si aparece el selector, elija el archivo deseado. Los campos se rellenan automáticamente.
4. Guarde el activo si tiene cambios pendientes y pulse **Vincular**, ahora junto al campo Documento Revit · ID. La vinculación vuelve a verificar el modelo y no sustituye una referencia incompatible silenciosamente.
5. Pulse **Aplicar a la obra** y **Guardar** para conservarlo en SQLite; sincronice cuando corresponda. Cancelar el diálogo descarta sus cambios.

## Validación
SDK .NET 10.0.100; solución completa Release con referencias Revit 2027 NuGet: **0 errores y 0 advertencias**. Pruebas focalizadas de núcleo y protocolo aprobadas; ver resultados al final. Se actualizaron las pruebas de interfaz para comprobar ubicación de Vincular, ausencia de Copiar, relleno de ambos IDs y conservación de datos ante cancelación, error y revocación.

```text
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --modeladores-bim
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --activos-revit
```

Las pruebas UI compilan; su ejecución y Revit real requieren Windows y no se ejecutaron en Linux. En Windows puede ejecutar `dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --activos-revit`. Compruebe también abrir dos modelos, elegir uno, cerrar/reabrir otro y volver a traer sus IDs; cancelar la selección debe conservar lo ya ingresado.

## GitHub del código
Esta entrega sólo publica el ZIP en DESCARGAS. Después de aplicar y probar, use Cambios de Git de Visual Studio para revisar, hacer Commit y Push a su rama de trabajo. No se hizo Push ni se mezclaron cambios del repositorio del código.

## Archivos de la actualización

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `IDS_AUTODESK_Y_VINCULAR_ACTIVO.md` | REEMPLAZAR | Actualizar instrucciones y reinstalación obligatoria del conector |
| 2 | `MYG.Core/Protocolo.cs` | REEMPLAZAR | Consulta de sólo identidad con compatibilidad anterior |
| 3 | `MYG.Desktop/ActivosRevitForm.cs` | REEMPLAZAR | Vincular junto al documento y retirada de Copiar |
| 4 | `MYG.Desktop/EditorForm.cs` | REEMPLAZAR | Enviar la consulta de identidad del modelo elegido |
| 5 | `MYG.Desktop/PresupuestosActivosRevit.cs` | REEMPLAZAR | Leer IDs sin solicitar plantillas |
| 6 | `MYG.Pruebas/ModeladoresBimCoreCheck.cs` | REEMPLAZAR | Pruebas del protocolo de identidad |
| 7 | `MYG.PruebasUI/ActivosRevitUICheck.cs` | REEMPLAZAR | Pruebas de ubicación, ausencia de Copiar y relleno automático |
| 8 | `MYG.Revit2027/Aplicacion.cs` | REEMPLAZAR | Evitar referencias inválidas y consultar sólo el documento elegido |
| 9 | `MYG.Revit2027/PlantillasRevit.cs` | REEMPLAZAR | Descartar tablas de planificación ya inválidas |

Resultados ejecutados: **7 grupos del núcleo/protocolo y 10 grupos de activos aprobados**; solución completa compilada con **0 errores y 0 advertencias**. Pruebas visuales compiladas, sin ejecución de Windows/Revit real en este entorno.
