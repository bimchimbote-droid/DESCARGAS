using System;using System.Text;using System.Collections.Generic;using System.Linq;using System.Globalization;using RevitDB=Autodesk.Revit.DB;
namespace MYG_2027 {
public static class PlantillaParametrosRevitCache
    {
        private static readonly object _lock =
            new object();

        private static Dictionary<string, List<string>>
            _parametrosPorPlantilla =
                new Dictionary<string, List<string>>(
                    StringComparer.OrdinalIgnoreCase);

        // Reglas que Revit admite realmente para cada campo:
        // PLANTILLA -> PARÁMETRO -> REGLAS VÁLIDAS.
        private static Dictionary<string, Dictionary<string, List<string>>>
            _reglasPorPlantillaParametro =
                new Dictionary<string, Dictionary<string, List<string>>>(
                    StringComparer.OrdinalIgnoreCase);

        // Valores reales encontrados en cada tabla de planificación:
        // PLANTILLA -> PARÁMETRO -> VALORES DISPONIBLES.
        // Se cargan bajo demanda porque recorrer el contenido de todas
        // las tablas al abrir la ventana sería innecesariamente costoso.
        private static Dictionary<string, Dictionary<string, List<string>>>
            _valoresPorPlantillaParametro =
                new Dictionary<string, Dictionary<string, List<string>>>(
                    StringComparer.OrdinalIgnoreCase);

        public static void Cargar(
            RevitDB.Document doc)
        {
            var nuevo =
                new Dictionary<string, List<string>>(
                    StringComparer.OrdinalIgnoreCase);

            var nuevasReglas =
                new Dictionary<
                    string,
                    Dictionary<string, List<string>>>(
                        StringComparer.OrdinalIgnoreCase);

            if (doc != null)
            {
                IEnumerable<RevitDB.ViewSchedule> schedules =
                    new RevitDB.FilteredElementCollector(doc)
                        .OfClass(
                            typeof(RevitDB.ViewSchedule))
                        .Cast<RevitDB.ViewSchedule>()
                        .Where(
                            x =>
                                !ReferenceEquals(x, null) && x.IsValidObject && !x.IsTemplate &&
                                !string.IsNullOrWhiteSpace(
                                    x.Name) &&
                                x.Name.StartsWith(
                                    "PLANTILLA",
                                    StringComparison.OrdinalIgnoreCase));

                foreach (
                    RevitDB.ViewSchedule schedule
                    in schedules)
                {
                    var nombres =
                        new List<string>();

                    var reglasPlantilla =
                        new Dictionary<string, List<string>>(
                            StringComparer.OrdinalIgnoreCase);

                    try
                    {
                        RevitDB.ScheduleDefinition definition =
                            schedule.Definition;

                        int cantidad =
                            definition.GetFieldCount();

                        for (
                            int i = 0;
                            i < cantidad;
                            i++)
                        {
                            RevitDB.ScheduleField field =
                                definition.GetField(
                                    i);

                            if (field == null)
                                continue;

                            string nombre =
                                field.GetName();

                            if (!string.IsNullOrWhiteSpace(
                                nombre))
                            {
                                string nombreLimpio =
                                    nombre.Trim();

                                nombres.Add(
                                    nombreLimpio);

                                reglasPlantilla[
                                    nombreLimpio] =
                                        ObtenerReglasValidasCampo(
                                            definition,
                                            field);
                            }
                        }
                    }
                    catch
                    {
                        // Una tabla concreta no debe impedir
                        // cargar las demás plantillas.
                    }

                    nuevo[schedule.Name] =
                        nombres
                            .Distinct(
                                StringComparer.OrdinalIgnoreCase)
                            .OrderBy(
                                x => x,
                                StringComparer.OrdinalIgnoreCase)
                            .ToList();

                    nuevasReglas[
                        schedule.Name] =
                            reglasPlantilla;
                }
            }

            lock (_lock)
            {
                _parametrosPorPlantilla =
                    nuevo;

                _reglasPorPlantillaParametro =
                    nuevasReglas;

                // El documento o el contenido de las tablas pudo cambiar.
                // Los valores se volverán a leer al solicitarlos.
                _valoresPorPlantillaParametro =
                    new Dictionary<string, Dictionary<string, List<string>>>(
                        StringComparer.OrdinalIgnoreCase);
            }
        }

        // =======================================
        // REGLAS VÁLIDAS SEGÚN LA API DE REVIT
        //
        // Esta es la misma lógica de disponibilidad que usa
        // la ventana Propiedades de tabla de planificación:
        // - texto: contiene / comienza / termina
        // - número: mayor / menor
        // - presencia: tiene / no tiene valor
        // - existencia: parámetro existe
        // =======================================
        private static List<string> ObtenerReglasValidasCampo(
            RevitDB.ScheduleDefinition definition,
            RevitDB.ScheduleField field)
        {
            var reglas =
                new List<string>();

            if (definition == null ||
                field == null)
            {
                return reglas;
            }

            RevitDB.ScheduleFieldId fieldId =
                field.FieldId;

            bool admiteValor = false;
            bool admiteTexto = false;
            bool admitePresenciaValor = false;
            bool admiteExistenciaParametro = false;

            try
            {
                admiteValor =
                    definition.CanFilterByValue(
                        fieldId);
            }
            catch
            {
            }

            try
            {
                admiteTexto =
                    definition.CanFilterBySubstring(
                        fieldId);
            }
            catch
            {
            }

            try
            {
                admitePresenciaValor =
                    definition.CanFilterByValuePresence(
                        fieldId);
            }
            catch
            {
            }

            try
            {
                admiteExistenciaParametro =
                    definition.CanFilterByParameterExistence(
                        fieldId);
            }
            catch
            {
            }

            if (admiteExistenciaParametro)
            {
                reglas.Add(
                    "parámetro existe");
            }

            if (admiteValor)
            {
                reglas.Add(
                    "es igual a");

                reglas.Add(
                    "no es igual a");
            }

            if (admiteTexto)
            {
                reglas.Add(
                    "contiene");

                reglas.Add(
                    "no contiene");

                reglas.Add(
                    "comienza por");

                reglas.Add(
                    "no comienza por");

                reglas.Add(
                    "termina en");

                reglas.Add(
                    "no termina en");
            }
            else if (admiteValor)
            {
                // Campo comparable no textual:
                // número, longitud, diámetro, etc.
                reglas.Add(
                    "es mayor que");

                reglas.Add(
                    "es mayor o igual que");

                reglas.Add(
                    "es menor que");

                reglas.Add(
                    "es menor o igual que");
            }

            if (admitePresenciaValor)
            {
                reglas.Add(
                    "tiene valor");

                reglas.Add(
                    "no tiene valor");
            }

            return reglas
                .Distinct(
                    StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        public static List<string> ObtenerReglas(
            string plantilla,
            string parametro)
        {
            if (string.IsNullOrWhiteSpace(
                    plantilla) ||
                string.IsNullOrWhiteSpace(
                    parametro))
            {
                return
                    new List<string>();
            }

            lock (_lock)
            {
                if (_reglasPorPlantillaParametro.TryGetValue(
                        plantilla.Trim(),
                        out Dictionary<string, List<string>> porParametro) &&
                    porParametro != null &&
                    porParametro.TryGetValue(
                        parametro.Trim(),
                        out List<string> reglas))
                {
                    return
                        new List<string>(
                            reglas ??
                            new List<string>());
                }
            }

            return
                new List<string>();
        }

        public static bool TieneValoresCargados(
            string plantilla,
            string parametro)
        {
            if (string.IsNullOrWhiteSpace(
                    plantilla) ||
                string.IsNullOrWhiteSpace(
                    parametro))
            {
                return false;
            }

            lock (_lock)
            {
                return
                    _valoresPorPlantillaParametro.TryGetValue(
                        plantilla.Trim(),
                        out Dictionary<string, List<string>> porParametro) &&
                    porParametro != null &&
                    porParametro.ContainsKey(
                        parametro.Trim());
            }
        }

        public static List<string> ObtenerValores(
            string plantilla,
            string parametro)
        {
            if (string.IsNullOrWhiteSpace(
                    plantilla) ||
                string.IsNullOrWhiteSpace(
                    parametro))
            {
                return
                    new List<string>();
            }

            lock (_lock)
            {
                if (_valoresPorPlantillaParametro.TryGetValue(
                        plantilla.Trim(),
                        out Dictionary<string, List<string>> porParametro) &&
                    porParametro != null &&
                    porParametro.TryGetValue(
                        parametro.Trim(),
                        out List<string> valores))
                {
                    return
                        new List<string>(
                            valores ??
                            new List<string>());
                }
            }

            return
                new List<string>();
        }

        // =======================================
        // VALORES DISPONIBLES SEGÚN LA PLANTILLA
        //
        // La propia ViewSchedule define la categoría y el ámbito.
        // Primero se leen los textos exactamente como Revit los muestra.
        // Si el campo está oculto, se consultan los elementos que pertenecen
        // a esa tabla y se usa el parámetro de ejemplar o de tipo.
        // =======================================
        public static void CargarValores(
            RevitDB.Document doc,
            string plantilla,
            string parametro)
        {
            if (doc == null ||
                string.IsNullOrWhiteSpace(
                    plantilla) ||
                string.IsNullOrWhiteSpace(
                    parametro))
            {
                return;
            }

            plantilla =
                plantilla.Trim();

            parametro =
                parametro.Trim();

            if (TieneValoresCargados(
                    plantilla,
                    parametro))
            {
                return;
            }

            var valores =
                new List<string>();

            try
            {
                RevitDB.ViewSchedule schedule =
                    new RevitDB.FilteredElementCollector(
                        doc)
                        .OfClass(
                            typeof(RevitDB.ViewSchedule))
                        .Cast<RevitDB.ViewSchedule>()
                        .FirstOrDefault(
                            x =>
                                !x.IsTemplate &&
                                string.Equals(
                                    x.Name,
                                    plantilla,
                                    StringComparison.OrdinalIgnoreCase));

                if (schedule != null)
                {
                    RevitDB.ScheduleDefinition definition =
                        schedule.Definition;

                    RevitDB.ScheduleField campoObjetivo =
                        null;

                    int indiceCampoObjetivo =
                        -1;

                    int indiceVisible =
                        -1;

                    int contadorVisible =
                        0;

                    for (
                        int i = 0;
                        i < definition.GetFieldCount();
                        i++)
                    {
                        RevitDB.ScheduleField field =
                            definition.GetField(
                                i);

                        if (field == null)
                            continue;

                        if (string.Equals(
                                field.GetName(),
                                parametro,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            campoObjetivo =
                                field;

                            indiceCampoObjetivo =
                                i;

                            if (!field.IsHidden)
                            {
                                indiceVisible =
                                    contadorVisible;
                            }
                        }

                        if (!field.IsHidden)
                        {
                            contadorVisible++;
                        }
                    }

                    bool lecturaSinFiltrosCompleta =
                        false;

                    // RUTA PRINCIPAL:
                    // Revit construye el desplegable de VALOR con los valores
                    // que puede ofrecer la tabla por su categoría, no solamente
                    // con los elementos que sobreviven a los filtros que ya
                    // tenga guardados la PLANTILLA.
                    //
                    // Por eso se crea una copia temporal, se QUITAN TODOS LOS
                    // FILTROS heredados y se itemiza. Esta lógica es genérica:
                    // funciona para cualquier categoría de tabla de planificación
                    // sin codificar Luminarias, Uniones, Tubos, Muros, etc.
                    if (campoObjetivo != null &&
                        indiceCampoObjetivo >= 0)
                    {
                        lecturaSinFiltrosCompleta =
                            AgregarValoresDesdeCopiaItemizada(
                                doc,
                                schedule,
                                indiceCampoObjetivo,
                                parametro,
                                valores);
                    }

                    bool lecturaDirectaCompleta =
                        false;

                    // Respaldo rápido si el documento no permitió generar la
                    // copia temporal. Puede devolver menos valores si la
                    // plantilla ya estaba filtrada, por eso NO es la ruta
                    // principal.
                    if (!lecturaSinFiltrosCompleta &&
                        campoObjetivo != null)
                    {
                        lecturaDirectaCompleta =
                            AgregarValoresDesdeElementosTabla(
                                doc,
                                schedule,
                                campoObjetivo,
                                parametro,
                                valores);
                    }

                    // Último respaldo: leer la columna visible original.
                    if (!lecturaSinFiltrosCompleta &&
                        !lecturaDirectaCompleta &&
                        indiceVisible >= 0)
                    {
                        AgregarValoresDesdeCeldasTabla(
                            schedule,
                            indiceVisible,
                            parametro,
                            valores);
                    }
                }
            }
            catch
            {
                // Una plantilla concreta no debe bloquear la ventana.
            }

            valores =
                valores
                    .Where(
                        x =>
                            EsValorDisponibleReal(
                                x,
                                parametro))
                    .Select(
                        x => x.Trim())
                    .Distinct(
                        StringComparer.OrdinalIgnoreCase)
                    .OrderBy(
                        x => x,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();

            lock (_lock)
            {
                if (!_valoresPorPlantillaParametro.TryGetValue(
                        plantilla,
                        out Dictionary<string, List<string>> porParametro) ||
                    porParametro == null)
                {
                    porParametro =
                        new Dictionary<string, List<string>>(
                            StringComparer.OrdinalIgnoreCase);

                    _valoresPorPlantillaParametro[
                        plantilla] =
                            porParametro;
                }

                // Incluso una lista vacía queda marcada como cargada para
                // no repetir la consulta en cada clic.
                porParametro[
                    parametro] =
                        valores;
            }
        }

        private static void AgregarValoresDesdeCeldasTabla(
            RevitDB.ViewSchedule schedule,
            int indiceVisible,
            string nombreParametro,
            List<string> valores)
        {
            if (schedule == null ||
                indiceVisible < 0 ||
                valores == null)
            {
                return;
            }

            try
            {
                RevitDB.TableSectionData body =
                    schedule
                        .GetTableData()
                        .GetSectionData(
                            RevitDB.SectionType.Body);

                if (body == null)
                    return;

                int columna =
                    body.FirstColumnNumber +
                    indiceVisible;

                for (
                    int fila = body.FirstRowNumber;
                    fila <= body.LastRowNumber;
                    fila++)
                {
                    try
                    {
                        string texto =
                            schedule.GetCellText(
                                RevitDB.SectionType.Body,
                                fila,
                                columna);

                        if (EsValorDisponibleReal(
                                texto,
                                nombreParametro))
                        {
                            valores.Add(
                                texto.Trim());
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        private static bool AgregarValoresDesdeCopiaItemizada(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            int indiceCampoObjetivo,
            string nombreParametro,
            List<string> valores)
        {
            if (doc == null ||
                schedule == null ||
                indiceCampoObjetivo < 0 ||
                valores == null ||
                doc.IsReadOnly ||
                doc.IsModifiable)
            {
                return false;
            }

            using (
                RevitDB.Transaction transaction =
                    new RevitDB.Transaction(
                        doc,
                        "MYG - Leer valores de filtro"))
            {
                try
                {
                    if (transaction.Start() !=
                        RevitDB.TransactionStatus.Started)
                    {
                        return false;
                    }

                    RevitDB.ElementId idCopia =
                        schedule.Duplicate(
                            RevitDB.ViewDuplicateOption.Duplicate);

                    RevitDB.ViewSchedule copia =
                        doc.GetElement(
                            idCopia)
                        as RevitDB.ViewSchedule;

                    if (copia == null)
                    {
                        transaction.RollBack();
                        return false;
                    }

                    RevitDB.ScheduleDefinition definition =
                        copia.Definition;

                    if (definition == null ||
                        indiceCampoObjetivo >=
                            definition.GetFieldCount())
                    {
                        transaction.RollBack();
                        return false;
                    }

                    // IMPORTANTE:
                    // La copia hereda los filtros de la PLANTILLA. Si no se
                    // eliminan, el ComboBox del add-in termina viendo solamente
                    // los valores que ya pasan esos filtros (por ejemplo un solo
                    // valor de Descripción), aunque Revit ofrezca varios en su
                    // cuadro nativo de filtros.
                    for (
                        int i =
                            definition.GetFilterCount() - 1;
                        i >= 0;
                        i--)
                    {
                        try
                        {
                            definition.RemoveFilter(
                                i);
                        }
                        catch
                        {
                        }
                    }

                    // Sin agrupación ni total general: una fila por elemento.
                    try
                    {
                        definition.ClearSortGroupFields();
                    }
                    catch
                    {
                    }

                    try
                    {
                        definition.IsItemized =
                            true;
                    }
                    catch
                    {
                    }

                    try
                    {
                        definition.ShowGrandTotal =
                            false;
                    }
                    catch
                    {
                    }

                    RevitDB.ScheduleField campo =
                        definition.GetField(
                            indiceCampoObjetivo);

                    if (campo == null)
                    {
                        transaction.RollBack();
                        return false;
                    }

                    // Solo se deja visible el campo solicitado. Esto reduce
                    // drásticamente el trabajo de reconstrucción de la tabla.
                    for (
                        int i = 0;
                        i < definition.GetFieldCount();
                        i++)
                    {
                        try
                        {
                            RevitDB.ScheduleField field =
                                definition.GetField(
                                    i);

                            if (field != null)
                            {
                                field.IsHidden =
                                    i != indiceCampoObjetivo;
                            }
                        }
                        catch
                        {
                        }
                    }

                    try
                    {
                        definition.ShowHeaders =
                            false;

                        definition.ShowTitle =
                            false;
                    }
                    catch
                    {
                    }

                    doc.Regenerate();

                    try
                    {
                        copia.RefreshData();
                    }
                    catch
                    {
                    }

                    int indiceVisible =
                        ObtenerIndiceVisibleCampo(
                            definition,
                            indiceCampoObjetivo);

                    if (indiceVisible >= 0)
                    {
                        AgregarValoresDesdeCeldasTabla(
                            copia,
                            indiceVisible,
                            nombreParametro,
                            valores);
                    }

                    // La copia solo existió para la lectura. RollBack elimina
                    // todo cambio temporal y no agrega una acción al historial
                    // de deshacer del usuario.
                    transaction.RollBack();

                    return
                        indiceVisible >= 0;
                }
                catch
                {
                    try
                    {
                        if (transaction.GetStatus() ==
                            RevitDB.TransactionStatus.Started)
                        {
                            transaction.RollBack();
                        }
                    }
                    catch
                    {
                    }
                }
            }

            return false;
        }

        private static int ObtenerIndiceVisibleCampo(
            RevitDB.ScheduleDefinition definition,
            int indiceCampoObjetivo)
        {
            if (definition == null ||
                indiceCampoObjetivo < 0)
            {
                return -1;
            }

            int indiceVisible =
                0;

            for (
                int i = 0;
                i < definition.GetFieldCount();
                i++)
            {
                RevitDB.ScheduleField field =
                    definition.GetField(
                        i);

                if (field == null ||
                    field.IsHidden)
                {
                    continue;
                }

                if (i == indiceCampoObjetivo)
                {
                    return indiceVisible;
                }

                indiceVisible++;
            }

            return -1;
        }

        private static bool EsValorDisponibleReal(
            string texto,
            string nombreParametro)
        {
            if (string.IsNullOrWhiteSpace(
                    texto))
            {
                return false;
            }

            string valorNormal =
                NormalizarValorDisponible(
                    texto);

            string parametroNormal =
                NormalizarValorDisponible(
                    nombreParametro);

            // Excluir el encabezado del campo cuando Revit lo devuelve
            // dentro del cuerpo de determinadas tablas.
            if (!string.IsNullOrWhiteSpace(
                    parametroNormal) &&
                string.Equals(
                    valorNormal,
                    parametroNormal,
                    StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            string marcador =
                valorNormal
                    .Trim(
                        '<',
                        '>',
                        '(',
                        ')',
                        '[',
                        ']')
                    .Trim();

            return
                marcador != "VARIA" &&
                marcador != "VARIAS" &&
                marcador != "VARIO" &&
                marcador != "VARIOS" &&
                marcador != "VARIES" &&
                marcador != "MULTIPLE VALUES" &&
                marcador != "MULTIPLES VALORES" &&
                marcador != "VALORES MULTIPLES" &&
                marcador != "VARIOS VALORES";
        }

        private static string NormalizarValorDisponible(
            string texto)
        {
            if (string.IsNullOrWhiteSpace(
                    texto))
            {
                return "";
            }

            string separado =
                texto.Trim()
                    .Normalize(
                        NormalizationForm.FormD);

            var sb =
                new StringBuilder();

            foreach (
                char caracter
                in separado)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(
                        caracter) !=
                    UnicodeCategory.NonSpacingMark)
                {
                    sb.Append(
                        caracter);
                }
            }

            return
                sb.ToString()
                    .Normalize(
                        NormalizationForm.FormC)
                    .Trim()
                    .ToUpperInvariant();
        }

        private static bool AgregarValoresDesdeElementosTabla(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            RevitDB.ScheduleField campo,
            string nombreParametro,
            List<string> valores)
        {
            if (doc == null ||
                schedule == null ||
                campo == null ||
                valores == null)
            {
                return false;
            }

            bool incluyeVinculos =
                false;

            try
            {
                incluyeVinculos =
                    schedule.Definition
                        .IncludeLinkedFiles;
            }
            catch
            {
            }

            // Un campo directo siempre tiene ParameterId. Los campos de
            // fórmula, porcentaje o combinación se leen por la ruta itemizada.
            bool campoDirecto =
                false;

            try
            {
                RevitDB.ElementId parameterId =
                    campo.ParameterId;

                campoDirecto =
                    parameterId != null &&
                    parameterId !=
                        RevitDB.ElementId.InvalidElementId;
            }
            catch
            {
            }

            if (incluyeVinculos ||
                !campoDirecto)
            {
                return false;
            }

            try
            {
                int elementosLeidos =
                    0;

                int parametrosEncontrados =
                    0;

                IEnumerable<RevitDB.Element> elementos =
                    new RevitDB.FilteredElementCollector(
                        doc,
                        schedule.Id)
                        .WhereElementIsNotElementType()
                        .Cast<RevitDB.Element>();

                foreach (
                    RevitDB.Element elemento
                    in elementos)
                {
                    elementosLeidos++;

                    RevitDB.Parameter parameter =
                        ObtenerParametroCampo(
                            doc,
                            elemento,
                            campo,
                            nombreParametro);

                    if (parameter == null)
                    {
                        continue;
                    }

                    parametrosEncontrados++;

                    string texto =
                        ObtenerTextoParametro(
                            doc,
                            parameter);

                    if (EsValorDisponibleReal(
                            texto,
                            nombreParametro))
                    {
                        valores.Add(
                            texto.Trim());
                    }
                }

                // Si no hay elementos, la lista vacía también es un resultado
                // completo. Si existen, basta con resolver el parámetro en
                // alguno; los restantes pueden tenerlo legítimamente vacío.
                return
                    elementosLeidos == 0 ||
                    parametrosEncontrados > 0;
            }
            catch
            {
                return false;
            }
        }

        private static RevitDB.Parameter ObtenerParametroCampo(
            RevitDB.Document doc,
            RevitDB.Element elemento,
            RevitDB.ScheduleField campo,
            string nombreParametro)
        {
            if (elemento == null)
                return null;

            RevitDB.Parameter parameter =
                null;

            try
            {
                RevitDB.ElementId parameterId =
                    campo.ParameterId;

                if (parameterId != null &&
                    parameterId != RevitDB.ElementId.InvalidElementId)
                {
                    parameter =
                        elemento.Parameters
                            .Cast<RevitDB.Parameter>()
                            .FirstOrDefault(
                                x =>
                                    x != null &&
                                    x.Id != null &&
                                    x.Id.Value == parameterId.Value);

                    if (parameter == null &&
                        parameterId.Value < 0)
                    {
                        parameter =
                            elemento.get_Parameter(
                                (RevitDB.BuiltInParameter)
                                    (int)parameterId.Value);
                    }
                }
            }
            catch
            {
            }

            if (parameter == null &&
                !string.IsNullOrWhiteSpace(
                    nombreParametro))
            {
                try
                {
                    parameter =
                        elemento.LookupParameter(
                            nombreParametro);
                }
                catch
                {
                }
            }

            if (parameter != null ||
                doc == null)
            {
                return parameter;
            }

            try
            {
                RevitDB.Element tipo =
                    doc.GetElement(
                        elemento.GetTypeId());

                if (tipo != null)
                {
                    RevitDB.ElementId parameterId =
                        campo.ParameterId;

                    if (parameterId != null &&
                        parameterId != RevitDB.ElementId.InvalidElementId)
                    {
                        parameter =
                            tipo.Parameters
                                .Cast<RevitDB.Parameter>()
                                .FirstOrDefault(
                                    x =>
                                        x != null &&
                                        x.Id != null &&
                                        x.Id.Value == parameterId.Value);

                        if (parameter == null &&
                            parameterId.Value < 0)
                        {
                            parameter =
                                tipo.get_Parameter(
                                    (RevitDB.BuiltInParameter)
                                        (int)parameterId.Value);
                        }
                    }

                    if (parameter == null &&
                        !string.IsNullOrWhiteSpace(
                            nombreParametro))
                    {
                        parameter =
                            tipo.LookupParameter(
                                nombreParametro);
                    }
                }
            }
            catch
            {
            }

            return parameter;
        }

        private static string ObtenerTextoParametro(
            RevitDB.Document doc,
            RevitDB.Parameter parameter)
        {
            if (parameter == null)
                return "";

            try
            {
                string mostrado =
                    parameter.AsValueString();

                if (!string.IsNullOrWhiteSpace(
                        mostrado))
                {
                    return mostrado.Trim();
                }
            }
            catch
            {
            }

            try
            {
                switch (parameter.StorageType)
                {
                    case RevitDB.StorageType.String:
                        return
                            (parameter.AsString() ?? "")
                                .Trim();

                    case RevitDB.StorageType.Integer:
                        return
                            parameter.AsInteger()
                                .ToString(
                                    CultureInfo.InvariantCulture);

                    case RevitDB.StorageType.Double:
                        return
                            parameter.AsDouble()
                                .ToString(
                                    "G17",
                                    CultureInfo.InvariantCulture);

                    case RevitDB.StorageType.ElementId:
                        RevitDB.ElementId id =
                            parameter.AsElementId();

                        RevitDB.Element referenciado =
                            doc?.GetElement(
                                id);

                        if (referenciado != null &&
                            !string.IsNullOrWhiteSpace(
                                referenciado.Name))
                        {
                            return
                                referenciado.Name.Trim();
                        }

                        return
                            id == null
                            ? ""
                            : id.Value.ToString(
                                CultureInfo.InvariantCulture);

                    default:
                        return "";
                }
            }
            catch
            {
                return "";
            }
        }

        public static Dictionary<string, List<string>>
            ObtenerCopia()
        {
            lock (_lock)
            {
                return
                    _parametrosPorPlantilla
                        .ToDictionary(
                            kvp => kvp.Key,
                            kvp => new List<string>(
                                kvp.Value),
                            StringComparer.OrdinalIgnoreCase);
            }
        }
    }
}
