using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class EditorNubeProgresoCheck
{
    private const string Servidor = "https://progreso-ui.supabase.co";
    private static readonly Guid ProyectoId = Guid.Parse("11111111-aaaa-4111-8111-111111111111");
    private static readonly Guid UsuarioId = Guid.Parse("22222222-bbbb-4222-8222-222222222222");

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Nube-Progreso-UI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        var indice = typeof(MYGIndiceLocal).GetProperty("RutaAlternativaPruebas", BindingFlags.Static | BindingFlags.NonPublic);
        string anterior = (string)indice.GetValue(null);
        try
        {
            indice.SetValue(null, Path.Combine(carpeta, "indice.json"));
            MYGIndiceLocal.RecordarBiblioteca(Path.Combine(carpeta, "biblioteca.json"));
            Verificar(carpeta, soloLeer: false, falloRemoto: false, exige);
            Verificar(carpeta, soloLeer: true, falloRemoto: false, exige);
            Verificar(carpeta, soloLeer: false, falloRemoto: true, exige);
        }
        finally
        {
            indice.SetValue(null, anterior);
            SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void Verificar(string carpeta, bool soloLeer, bool falloRemoto, Action<bool, string> exige)
    {
        string ruta = Path.Combine(carpeta, Guid.NewGuid().ToString("N") + ".sqlite");
        var documento = MYGProyectoStorage.Nuevo("Proyecto inicial de progreso", "Presupuesto");
        MYGProyectoStorage.Guardar(ruta, documento);
        var paquete = PaqueteNube.CrearContenido(documento, ruta, "obra");
        MYGColaboracionLocal.Vincular(ruta, documento, new MYGVinculoNube
        {
            ProyectoId = ProyectoId, Servidor = Servidor, UsuarioId = UsuarioId.ToString("D"),
            Rol = "editor", Revision = 1, JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento),
            JsonPaqueteConfirmado = paquete.GetRawText()
        });
        using var http = new Transporte(paquete, falloRemoto);
        using var cliente = new ClienteSupabase(Servidor, "sb_publishable_pruebas_progreso_ui", http);
        Task.Run(() => cliente.IniciarSesionAsync("progreso@myg.example", "clave_sintetica")).GetAwaiter().GetResult();
        using var sesion = new SesionDesktop();
        // Esta prueba no contacta al servicio de licencias ni guarda una sesión real.
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial)).SetValue(sesion,
            new CredencialMYG { Usuario = "Prueba de progreso" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
        using var editor = new EditorForm(documento, ruta, sesion);
        editor.ConfigurarNube(() => cliente, () => { });
        documento.Nombre = "Edición local que debe conservarse";
        ExceptionDispatchInfo fallo = null;
        editor.Shown += async (_, _) =>
        {
            try { await VerificarOperacion(editor, ruta, documento, http, soloLeer, falloRemoto, exige); }
            catch (Exception ex) { fallo = ExceptionDispatchInfo.Capture(ex); }
            finally { editor.CerrarConfirmado(); }
        };
        editor.ShowDialog();
        fallo?.Throw();
    }

    private static async Task VerificarOperacion(EditorForm editor, string ruta, MYGProyectoDocumento original, Transporte http,
        bool soloLeer, bool falloRemoto, Action<bool, string> exige)
    {
        int hiloUi = Environment.CurrentManagedThreadId, pulsosGuardado = 0, pulsosRed = 0, guardados = 0;
        bool guardadoVisible = false, redVisible = false, reentradaRechazada = false;
        MYGDialogoCarga carga = null;
        ExceptionDispatchInfo falloReloj = null;
        using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        conexion.Open();
        // El bloqueo de escritura hace que la comprobación falle si SQLite vuelve
        // al hilo UI: el reloj no puede liberar la transacción ni mostrar etapas.
        SqliteTransaction bloqueo = conexion.BeginTransaction();
        using (var comando = conexion.CreateCommand())
        {
            comando.Transaction = bloqueo;
            comando.CommandText = "UPDATE myg_proyecto SET id=id";
            comando.ExecuteNonQuery();
        }
        var limite = Stopwatch.StartNew();
        using var reloj = new System.Windows.Forms.Timer { Interval = 20 };
        void LiberarGuardado()
        {
            bloqueo?.Dispose();
            bloqueo = null;
        }
        editor.ProyectoGuardado += _ =>
        {
            guardados++;
            var dialogo = editor.OwnedForms.OfType<MYGDialogoCarga>().Single();
            exige(Environment.CurrentManagedThreadId == hiloUi && dialogo.Visible && !editor.Enabled,
                "La notificación de guardado debe volver al hilo UI con la carga todavía visible.");
        };
        reloj.Tick += (_, _) =>
        {
            try
            {
                carga = editor.OwnedForms.OfType<MYGDialogoCarga>().FirstOrDefault() ?? carga;
                if (carga?.EtapaActual == "Guardando la copia de trabajo local…" && bloqueo != null)
                {
                    guardadoVisible |= carga.Visible && !editor.Enabled && guardados == 0;
                    if (++pulsosGuardado >= 3) LiberarGuardado();
                }
                if (http.Esperando && !http.Continuar.Task.IsCompleted)
                {
                    redVisible |= carga?.Visible == true && !editor.Enabled &&
                        carga.EtapaActual == "Descargando el proyecto y sus permisos actuales";
                    if (++pulsosRed >= 3)
                    {
                        Task repetida = editor.ActualizarNubeAsync(!soloLeer);
                        reentradaRechazada = repetida.IsCompletedSuccessfully &&
                            editor.OwnedForms.OfType<MYGDialogoCarga>().Count() == 1 && guardados == 1;
                        http.Continuar.TrySetResult(true);
                    }
                }
                if (limite.Elapsed > TimeSpan.FromSeconds(10))
                    throw new TimeoutException("La operación de nube no informó las etapas esperadas.");
            }
            catch (Exception ex)
            {
                falloReloj ??= ExceptionDispatchInfo.Capture(ex);
                LiberarGuardado(); http.Continuar.TrySetResult(true); reloj.Stop();
            }
        };
        reloj.Start();
        bool errorRecibido = false;
        try
        {
            try { await editor.ActualizarNubeAsync(soloLeer); }
            catch (NubeException ex) when (falloRemoto && ex.AccesoDenegado) { errorRecibido = true; }
        }
        finally { reloj.Stop(); LiberarGuardado(); http.Continuar.TrySetResult(true); }
        falloReloj?.Throw();
        exige(guardadoVisible && pulsosGuardado >= 3 && guardados == 1,
            "Sincronizar y Recargar deben mostrar la carga antes de escribir SQLite y mantener activo el reloj UI mientras se guarda.");
        exige(redVisible && pulsosRed >= 3 && reentradaRechazada,
            "La carga debe mostrar la consulta real, procesar mensajes durante la red y rechazar una segunda actualización.");
        exige(carga?.IsDisposed == true && editor.Enabled && !editor.UseWaitCursor &&
            !editor.OwnedForms.OfType<MYGDialogoCarga>().Any(),
            "Terminar o fallar debe cerrar la carga, restaurar el cursor y habilitar el editor.");
        exige(errorRecibido == falloRemoto, "El error remoto debe propagarse después de retirar la ventana de progreso.");
        var vinculo = MYGColaboracionLocal.Leer(ruta, original.Id);
        exige(MYGBaseDatos.LeerProyecto(ruta, original.Id).Nombre == "Edición local que debe conservarse",
            "La operación debe guardar la edición local antes de consultar el servidor, también si la red falla.");
        if (soloLeer || falloRemoto)
        {
            exige(vinculo.Pendiente != null && http.Escrituras == 0,
                "Recargar y el fallo de consulta deben conservar el pendiente local sin enviar una escritura remota.");
        }
        else
        {
            exige(vinculo.Pendiente == null && vinculo.Revision == 2 && http.Escrituras == 1,
                "Sincronizar debe confirmar la edición guardada una sola vez.");
        }
        if (falloRemoto)
            exige(ReferenceEquals(original, typeof(EditorForm).GetField("documento",
                BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor)),
                "Un error de red debe mantener el documento original al que siguen ligados los controles y sus filas.");
        if (!falloRemoto)
            exige(carga.EtapaActual == "Actualizando la pantalla del proyecto…",
                "La misma carga debe permanecer hasta la actualización final de la pantalla.");
    }

    private sealed class Transporte(JsonElement paquete, bool fallar) : HttpMessageHandler
    {
        private JsonElement contenido = paquete.Clone();
        private int lecturas, escrituras;
        private long revision = 1;
        internal bool Esperando => Volatile.Read(ref lecturas) > 0;
        internal int Escrituras => Volatile.Read(ref escrituras);
        internal TaskCompletionSource<bool> Continuar { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri.AbsolutePath;
            if (ruta == "/auth/v1/token") return Json(new
            { access_token = "token_ui", refresh_token = "refresh_ui", expires_in = 3600, user = new { id = UsuarioId } });
            if (ruta == "/rest/v1/rpc/myg_nube_abrir")
            {
                Interlocked.Increment(ref lecturas);
                await Continuar.Task.WaitAsync(TimeSpan.FromSeconds(10), ct);
                if (fallar) return Json(new { code = "42501", message = "Acceso retirado simulado" }, HttpStatusCode.Forbidden);
                return Json(new { id = ProyectoId, codigo = "MYG-UI-001", nombre = "Proyecto de progreso",
                    rol = "editor", revision, alcance = "obra", contenido });
            }
            if (ruta == "/rest/v1/rpc/myg_nube_guardar")
            {
                Interlocked.Increment(ref escrituras);
                using var cuerpo = JsonDocument.Parse(await solicitud.Content.ReadAsByteArrayAsync(ct));
                contenido = cuerpo.RootElement.GetProperty("p_contenido").Clone();
                revision++;
                return Json(new { estado = "aplicada", revision, contenido,
                    operacion_id = cuerpo.RootElement.GetProperty("p_operacion").GetGuid() });
            }
            throw new InvalidOperationException("La prueba de progreso recibió una solicitud inesperada: " + ruta);
        }

        private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
