#nullable enable
using System.IO;
using System.Text.Json;
using MYG_2027;

namespace MYG.Colaboracion;

public sealed record ResultadoSincronizacion(MYGProyectoDocumento Documento, MYGVinculoNube Vinculo);

/// <summary>Sincronización manual; ningún fallo HTTP descarta la cola durable.</summary>
public static class SincronizadorProyectoNube
{
    public static async Task<ResultadoSincronizacion> EjecutarAsync(ClienteSupabase cliente, string ruta,
        MYGProyectoDocumento documento, bool soloLeer = false, CancellationToken ct = default,
        IProgress<string>? progreso = null)
    {
        progreso?.Report("Leyendo la copia de trabajo y sus cambios pendientes");
        var vinculo = MYGColaboracionLocal.Leer(ruta, documento.Id)
            ?? throw new InvalidOperationException("La copia no está vinculada a un proyecto de nube.");
        ValidarIdentidad(cliente, vinculo);
        bool incorporarDependencias = false;
        try
        {
            bool compacto = false;
            if (!string.IsNullOrWhiteSpace(vinculo.JsonPaqueteConfirmado))
            {
                using var baseLocal = JsonDocument.Parse(vinculo.JsonPaqueteConfirmado);
                compacto = FormatoPaqueteNube.EsCompacto(baseLocal.RootElement);
            }
            if (compacto) progreso?.Report("Consultando las capacidades de sincronización del servidor");
            bool incremental = compacto && (await cliente.ObtenerCapacidadesNubeAsync(ct)).Cambios >= 1;
            async Task<ProyectoNube> LeerRemotoAsync()
            {
                if (incremental)
                {
                    // Los permisos pueden cambiar sin incrementar la revisión de datos.
                    progreso?.Report("Consultando la revisión y los permisos del proyecto");
                    var metadatos = await cliente.ConsultarRevisionProyectoAsync(vinculo.ProyectoId, ct);
                    if (metadatos.Revision == vinculo.Revision && !string.IsNullOrWhiteSpace(vinculo.JsonPaqueteConfirmado))
                    {
                        using var confirmado = JsonDocument.Parse(vinculo.JsonPaqueteConfirmado);
                        return metadatos with { Contenido = confirmado.RootElement.Clone() };
                    }
                }
                progreso?.Report("Descargando el proyecto y sus permisos actuales");
                return await cliente.AbrirProyectoAsync(vinculo.ProyectoId, ct);
            }
            // Se revalida el permiso incluso para reenviar una operación ya confirmada.
            ProyectoNube remoto = await LeerRemotoAsync();
            progreso?.Report("Comprobando y descargando los archivos del proyecto");
            remoto = remoto with { Contenido = await cliente.CargarArchivosAsync(remoto.Contenido, ct) };
            ActualizarPermisos(vinculo, remoto);
            vinculo.EstadoConexion = null;
            if (vinculo.Pendiente is null && PuedeEditar(remoto.Rol)
                && string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto)
                && !string.IsNullOrWhiteSpace(vinculo.JsonPaqueteConfirmado))
            {
                using var anterior = JsonDocument.Parse(vinculo.JsonPaqueteConfirmado);
                // Los catálogos y datos nativos también pueden cambiar sin modificar el documento.
                if (anterior.RootElement.TryGetProperty("tablas", out _))
                {
                    progreso?.Report("Comparando los datos locales con la revisión confirmada");
                    var local = PaqueteNube.CrearContenido(documento, ruta, remoto.Alcance, compacto: compacto);
                    if (PaqueteNube.FirmaDatosCompartidos(local) != PaqueteNube.FirmaDatosCompartidos(anterior.RootElement))
                        MYGColaboracionLocal.PrepararCambioContenido(ruta, documento, vinculo,
                            local.GetRawText());
                }
            }
            if (!soloLeer && vinculo.Pendiente is not null && PuedeEditar(remoto.Rol))
            {
                if (!string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto))
                {
                    progreso?.Report("Conservando los cambios locales y el conflicto pendiente");
                    MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
                    return new(documento, vinculo);
                }
                var operacion = vinculo.Pendiente;
                using var pendienteComprobado = JsonDocument.Parse(operacion.JsonContenido);
                if (vinculo.PermisosModulos != null && !string.IsNullOrWhiteSpace(vinculo.JsonConfirmado))
                {
                    try
                    {
                        MYGCambiosModulosNube.ExigirPermitidos(
                            MYGColaboracionLocal.ImportarDocumento(vinculo.JsonConfirmado),
                            PaqueteNube.LeerDocumento(pendienteComprobado.RootElement), vinculo.PermisosModulos);
                    }
                    catch (InvalidOperationException ex)
                    {
                        throw new NubeException(ex.Message + " Se conserva la operación pendiente sin publicarla.");
                    }
                }
                if (!operacion.Enviada)
                {
                    progreso?.Report("Preparando los cambios locales para sincronizar");
                    using var cuerpo = JsonDocument.Parse(operacion.JsonContenido);
                    var congelado = PaqueteNube.LeerDocumento(cuerpo.RootElement);
                    using var previo = JsonDocument.Parse(vinculo.JsonPaqueteConfirmado ?? operacion.JsonContenido);
                    string alcance = previo.RootElement.TryGetProperty("alcance", out var a) ? a.GetString() ?? "obra" : "obra";
                    var paquete = cuerpo.RootElement.TryGetProperty("tablas", out _)
                        ? cuerpo.RootElement.Clone() : PaqueteNube.CrearContenido(congelado, ruta, alcance, compacto: compacto);
                    if (compacto && !FormatoPaqueteNube.EsCompacto(paquete)) paquete = FormatoPaqueteNube.Compactar(paquete);
                    if (incremental)
                    {
                        progreso?.Report("Preparando los archivos y los cambios incrementales");
                        var red = await cliente.PrepararArchivosProyectoAsync(paquete, vinculo.ProyectoId, operacion.Id, ct);
                        var baseRed = ClienteSupabase.SoloReferenciasArchivos(previo.RootElement);
                        var cambios = CambiosPaqueteNube.Crear(baseRed, red);
                        operacion = MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo,
                            red.GetRawText(), cambios.GetRawText());
                    }
                    else operacion = MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, paquete.GetRawText());
                }
                using var contenido = JsonDocument.Parse(operacion.JsonContenido);
                RespuestaGuardarNube respuesta;
                if (operacion.JsonCambios is not null)
                {
                    using var cambios = JsonDocument.Parse(operacion.JsonCambios);
                    progreso?.Report("Enviando los cambios incrementales y esperando confirmación");
                    respuesta = await cliente.GuardarCambiosCongeladosAsync(vinculo.ProyectoId, operacion.Id,
                        operacion.RevisionBase, cambios.RootElement, contenido.RootElement, ct);
                }
                else
                {
                    progreso?.Report("Preparando los archivos de los cambios pendientes");
                    var contenidoRed = await cliente.PrepararArchivosProyectoAsync(contenido.RootElement,
                        vinculo.ProyectoId, operacion.Id, ct);
                    progreso?.Report("Enviando los cambios y esperando confirmación del servidor");
                    respuesta = await cliente.GuardarProyectoAsync(vinculo.ProyectoId, operacion.Id,
                        operacion.RevisionBase, contenidoRed, ct);
                }
                progreso?.Report("Comprobando los archivos y la respuesta del servidor");
                respuesta = respuesta with { Contenido = await cliente.CargarArchivosAsync(respuesta.Contenido, ct) };
                var confirmado = PaqueteNube.LeerDocumento(respuesta.Contenido);
                ValidarDocumento(documento, confirmado);
                if (respuesta.Estado == "conflicto")
                {
                    progreso?.Report("Conservando el conflicto sin descartar los cambios locales");
                    vinculo.JsonPaqueteConflicto = respuesta.Contenido.GetRawText();
                    MYGColaboracionLocal.RegistrarConflicto(ruta, documento, vinculo, respuesta.Revision,
                        MYGColaboracionLocal.ExportarDocumento(PaqueteNube.MaterializarDocumento(respuesta.Contenido, ruta)));
                    return new(documento, vinculo);
                }
                progreso?.Report("Guardando la confirmación de los cambios enviados");
                vinculo.JsonPaqueteConfirmado = respuesta.Contenido.GetRawText();
                MYGColaboracionLocal.Confirmar(ruta, documento, vinculo, respuesta.OperacionId,
                    respuesta.Revision, MYGColaboracionLocal.ExportarDocumento(confirmado));
                // Un ACK idempotente puede describir una revisión antigua. Leer el estado actual.
                remoto = await LeerRemotoAsync();
                progreso?.Report("Comprobando los archivos de la última revisión");
                remoto = remoto with { Contenido = await cliente.CargarArchivosAsync(remoto.Contenido, ct) };
                ActualizarPermisos(vinculo, remoto);
            }
            if (remoto.Revision < vinculo.Revision)
                throw new NubeException("El servidor devolvió una revisión anterior. Se conserva la copia y sus pendientes.");
            var actual = PaqueteNube.LeerDocumento(remoto.Contenido);
            ValidarDocumento(documento, actual);
            if (remoto.Revision > vinculo.Revision)
            {
                if (vinculo.Pendiente is not null)
                {
                    progreso?.Report("Conservando la revisión remota y los cambios locales en conflicto");
                    vinculo.JsonPaqueteConflicto = remoto.Contenido.GetRawText();
                    MYGColaboracionLocal.RegistrarConflicto(ruta, documento, vinculo, remoto.Revision,
                        MYGColaboracionLocal.ExportarDocumento(PaqueteNube.MaterializarDocumento(remoto.Contenido, ruta)));
                    return new(documento, vinculo);
                }
                if (remoto.Alcance == "base")
                {
                    progreso?.Report("Incorporando la base completa y conservando una copia de respaldo");
                    var resultado = IncorporarBaseConfirmada(ruta, documento, vinculo, remoto.Revision, remoto.Contenido);
                    progreso?.Report("Base actualizada y guardada en la copia de trabajo");
                    return resultado;
                }
                progreso?.Report("Incorporando la revisión remota a la copia de trabajo");
                documento = PaqueteNube.MaterializarDocumento(remoto.Contenido, ruta);
                vinculo.Revision = remoto.Revision;
                vinculo.JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento);
                vinculo.JsonPaqueteConfirmado = remoto.Contenido.GetRawText();
                vinculo.JsonRemotoConflicto = null;
                vinculo.JsonPaqueteConflicto = null;
                incorporarDependencias = true;
            }
            vinculo.Estado = !PuedeEditar(vinculo.Rol) ? "solo lectura" : vinculo.Pendiente is null ? "sincronizado" : "pendiente";
            progreso?.Report("Guardando la copia de trabajo y su estado de sincronización");
            MYGColaboracionLocal.Guardar(ruta, documento, vinculo, incorporarDependencias
                ? (conexion, transaccion) => PaqueteNube.AplicarDependencias(remoto.Contenido, conexion, transaccion) : null);
            progreso?.Report(vinculo.Pendiente is null ? "Copia actualizada y guardada" : "Copia guardada; se conservan los cambios pendientes");
            return new(documento, vinculo);
        }
        catch (NubeException ex)
        {
            vinculo.EstadoConexion = ex.AccesoDenegado ? "acceso retirado" : ex.EsErrorDeConexion ? "sin conexión" : null;
            MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
            throw;
        }
    }

    public static void ActualizarPermisos(MYGVinculoNube vinculo, ProyectoNube remoto)
    {
        // No degradar silenciosamente un vínculo con permisos a un servidor legado.
        if (vinculo.PermisosModulos != null && remoto.PermisosModulos == null)
            throw new NubeException("El servidor no devolvió los permisos por módulo. Actualice el backend antes de sincronizar esta copia.");
        vinculo.Rol = remoto.Rol;
        vinculo.PermisosModulos = remoto.PermisosModulos?.Copiar();
    }

    public static bool PuedeEditar(string? rol) => rol is "propietario" or "administrador" or "editor";

    // Una base completa no puede avanzar de revisión aplicando sólo su obra principal.
    // Se prepara toda la nueva hoja y el vínculo antes del reemplazo atómico; el
    // archivo anterior permanece como respaldo, incluidos sus borradores originales.
    public static ResultadoSincronizacion IncorporarBaseConfirmada(string ruta, MYGProyectoDocumento documento,
        MYGVinculoNube vinculo, long revision, JsonElement contenido)
    {
        if (revision <= vinculo.Revision || !contenido.TryGetProperty("alcance", out var alcance)
            || alcance.GetString() != "base")
            throw new InvalidDataException("La base confirmada necesita una revisión posterior y el alcance correcto.");
        ValidarDocumento(documento, PaqueteNube.LeerDocumento(contenido));
        ruta = Path.GetFullPath(ruta);
        if (File.Exists(ruta + "-wal") && new FileInfo(ruta + "-wal").Length > 0)
            throw new IOException("Cierre las otras aplicaciones que usan esta copia antes de incorporar la base completa. Se conservan sus cambios.");
        string estadoInicial = JsonSerializer.Serialize(MYGColaboracionLocal.Leer(ruta, documento.Id));
        string firmaInicial = PaqueteNube.FirmaDatosCompartidos(PaqueteNube.CrearContenido(documento, ruta, "base"));
        string temporal = Path.Combine(Path.GetDirectoryName(ruta)!, "revision-" + Guid.NewGuid().ToString("N") + ".sqlite");
        try
        {
            PaqueteNube.Descargar(contenido, temporal);
            var descargado = MYGBaseDatos.LeerProyecto(temporal, documento.Id);
            var nuevoVinculo = new MYGVinculoNube
            {
                ProyectoId = vinculo.ProyectoId, Servidor = vinculo.Servidor, UsuarioId = vinculo.UsuarioId,
                Rol = vinculo.Rol, PermisosModulos = vinculo.PermisosModulos?.Copiar(), Revision = revision, JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(descargado),
                JsonPaqueteConfirmado = contenido.GetRawText(), EstadoConexion = null
            };
            MYGColaboracionLocal.Vincular(temporal, descargado, nuevoVinculo);
            string firmaActual = PaqueteNube.FirmaDatosCompartidos(PaqueteNube.CrearContenido(documento, ruta, "base"));
            string estadoActual = JsonSerializer.Serialize(MYGColaboracionLocal.Leer(ruta, documento.Id));
            if (firmaActual != firmaInicial || estadoActual != estadoInicial)
                throw new IOException("La copia cambió durante la descarga. No se reemplazó; guarde sus cambios y vuelva a actualizar.");
            string respaldo = ruta + ".antes-r" + revision + "-" + Guid.NewGuid().ToString("N") + ".sqlite";
            File.Replace(temporal, ruta, respaldo);
            return new(descargado, MYGColaboracionLocal.Leer(ruta, descargado.Id));
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    public static void ValidarIdentidad(ClienteSupabase cliente, MYGVinculoNube vinculo)
    {
        if (!cliente.SesionIniciada || cliente.UsuarioId != vinculo.UsuarioId
            || !string.Equals(cliente.UrlServidor.TrimEnd('/'), vinculo.Servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            throw new NubeException("Inicie sesión en el mismo servidor y con la cuenta de esta copia de trabajo.", necesitaIniciarSesion: true);
    }

    private static void ValidarDocumento(MYGProyectoDocumento local, MYGProyectoDocumento remoto)
    {
        if (local.Id != remoto.Id)
            throw new NubeException("La respuesta corresponde a otro documento. Se conserva el trabajo local.");
    }
}
