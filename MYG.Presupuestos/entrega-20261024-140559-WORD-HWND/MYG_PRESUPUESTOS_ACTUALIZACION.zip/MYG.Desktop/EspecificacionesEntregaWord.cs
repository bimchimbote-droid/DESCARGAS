using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace MYG_2027;

// Las páginas y el archivo entregado proceden de una única instantánea. Guardar
// copia ese archivo: no vuelve a abrir Word ni realiza otra conversión.
internal sealed class MYGEspecificacionesEntregaPaginada : IDisposable
{
    private readonly string carpeta;
    private readonly MemoryStream[] flujos;
    private bool dispuesto;

    internal PreviewPageInfo[] Paginas { get; private set; }
    internal string Extension { get; }
    internal string RutaArchivo { get; }

    internal MYGEspecificacionesEntregaPaginada(string carpeta, string archivo, string extension,
        PreviewPageInfo[] paginas, MemoryStream[] flujos)
    {
        this.carpeta = carpeta;
        RutaArchivo = archivo;
        Extension = extension;
        Paginas = paginas;
        this.flujos = flujos;
    }

    internal void Guardar(string destino)
    {
        ObjectDisposedException.ThrowIf(dispuesto, this);
        ArgumentException.ThrowIfNullOrWhiteSpace(destino);
        string ruta = Path.GetFullPath(destino);
        if (!string.Equals(Path.GetExtension(ruta), Extension, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("La vista corresponde a un archivo " + Extension +
                ". Elija esa misma extensión para guardar exactamente el documento mostrado.");
        if (string.Equals(ruta, RutaArchivo, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Elija una ubicación de entrega fuera del archivo temporal de la vista.");
        string directorio = Path.GetDirectoryName(ruta);
        if (!Directory.Exists(directorio))
            throw new DirectoryNotFoundException("La carpeta de destino no existe.");

        ValidarArchivo(RutaArchivo, Extension);
        string temporal = Path.Combine(directorio, ".MYG-Especificaciones-" + Guid.NewGuid().ToString("N") + Extension);
        try
        {
            File.Copy(RutaArchivo, temporal, overwrite: false);
            ValidarArchivo(temporal, Extension);
            // El temporal está en el mismo volumen. Un fallo de copia o de
            // validación conserva íntegro cualquier archivo anterior del usuario.
            if (File.Exists(ruta)) File.Replace(temporal, ruta, null);
            else File.Move(temporal, ruta);
        }
        finally { EliminarArchivo(temporal); }
    }

    internal static void ValidarArchivo(string ruta, string extension)
    {
        if (extension is ".doc" or ".docx")
        {
            if (!MYGEspecificacionesDocumento.EsDocumentoWordValido(ruta))
                throw new InvalidDataException("El archivo de entrega no contiene un documento Word válido para " + extension + ".");
            return;
        }
        if (extension != ".rtf") throw new ArgumentOutOfRangeException(nameof(extension));
        using var archivo = File.OpenRead(ruta);
        Span<byte> firma = stackalloc byte[6];
        if (archivo.Length < firma.Length || archivo.Read(firma) != firma.Length ||
            !firma.SequenceEqual("{\\rtf1"u8))
            throw new InvalidDataException("El archivo de entrega no contiene un documento RTF válido.");
    }

    public void Dispose()
    {
        if (dispuesto) return;
        dispuesto = true;
        try
        {
            foreach (var pagina in Paginas) pagina.Image?.Dispose();
        }
        finally
        {
            Paginas = Array.Empty<PreviewPageInfo>();
            try
            {
                foreach (var flujo in flujos) flujo.Dispose();
            }
            finally
            {
                try { Directory.Delete(carpeta, recursive: true); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }

    private static void EliminarArchivo(string ruta)
    {
        try { File.Delete(ruta); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }
}

internal static partial class MYGEspecificacionesDocumento
{
    private const string RequisitoVistaWord = "Para mostrar las mismas páginas del documento de entrega se necesita Microsoft Word instalado en Windows.";

    internal static MYGEspecificacionesEntregaPaginada CrearEntregaWord(RichTextBox editor, string extension,
        PageSettings pagina, string encabezado = "", string pie = "", bool numeroPagina = false,
        string rtfParaArchivo = null)
    {
        ArgumentNullException.ThrowIfNull(editor);
        extension = (extension ?? "").Trim().ToLowerInvariant();
        if (!extension.StartsWith('.')) extension = "." + extension;
        if (extension is not (".doc" or ".docx" or ".rtf"))
            throw new ArgumentException("La vista de entrega admite documentos .doc, .docx o .rtf.", nameof(extension));
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException(RequisitoVistaWord);
        if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
            throw new InvalidOperationException("La vista del documento Word debe prepararse en un hilo STA de Windows.");
        var tipo = Type.GetTypeFromProgID("Word.Application");
        if (tipo == null) throw new InvalidOperationException(RequisitoVistaWord);

        string carpeta = CrearCarpetaTemporal();
        var paginas = new List<PreviewPageInfo>();
        var flujos = new List<MemoryStream>();
        try
        {
            string archivo = Path.Combine(carpeta, "Especificaciones" + extension);
            if (extension == ".rtf")
            {
                // El texto aportado puede contener los destinos MYG ignorables
                // que RichEdit no conserva al volver a leer su propiedad Rtf.
                string rtf = rtfParaArchivo ?? RtfConPagina(editor, pagina, encabezado, pie, numeroPagina);
                File.WriteAllText(archivo, rtf, Encoding.ASCII);
            }
            else GuardarWord(editor, editor, archivo, pagina, encabezado, pie, numeroPagina);
            MYGEspecificacionesEntregaPaginada.ValidarArchivo(archivo, extension);
            PaginarEntregaConWord(tipo, archivo, paginas, flujos);
            return new MYGEspecificacionesEntregaPaginada(carpeta, archivo, extension, paginas.ToArray(), flujos.ToArray());
        }
        catch
        {
            try
            {
                foreach (var hoja in paginas) hoja.Image?.Dispose();
            }
            finally
            {
                foreach (var flujo in flujos) flujo.Dispose();
                EliminarCarpetaTemporal(carpeta);
            }
            throw;
        }
    }

    private static void PaginarEntregaConWord(Type tipo, string archivo,
        List<PreviewPageInfo> resultado, List<MemoryStream> flujos)
    {
        try
        {
            var preparadas = MYGEspecificacionesWordRecuperacion.Ejecutar(() =>
            {
                var hojasIntento = new List<PreviewPageInfo>();
                var flujosIntento = new List<MemoryStream>();
                try
                {
                    PaginarEntregaConWordIntento(tipo, archivo, hojasIntento, flujosIntento);
                    return (Hojas: hojasIntento, Flujos: flujosIntento);
                }
                catch
                {
                    // Nunca mezclar páginas de una instancia desconectada con
                    // las del reintento. El archivo final no se vuelve a convertir.
                    try { foreach (var hoja in hojasIntento) hoja.Image?.Dispose(); }
                    finally { foreach (var flujo in flujosIntento) flujo.Dispose(); }
                    throw;
                }
            });
            resultado.AddRange(preparadas.Hojas);
            flujos.AddRange(preparadas.Flujos);
        }
        catch (Exception ex) when (MYGEspecificacionesWordRecuperacion.EsDesconexion(ex))
        {
            throw new InvalidOperationException(Mensaje(ex) +
                " Se volvió a intentar con otra instancia de Word, pero la comunicación sigue fallando." +
                " Guarde sus documentos abiertos y compruebe que Word puede abrir e imprimir un documento por separado." +
                " Si también falla, repare Microsoft Office y vuelva a intentar la exportación.", ex);
        }
    }

    private static void PaginarEntregaConWordIntento(Type tipo, string archivo,
        List<PreviewPageInfo> resultado, List<MemoryStream> flujos)
    {
        object aplicacion = null, documentos = null, documento = null;
        object ventana = null, vista = null, panel = null, paginas = null, configuracion = null;
        IntPtr ventanaWord = IntPtr.Zero;
        IntPtr focoAnterior = GetForegroundWindowEntrega();
        string etapa = "iniciar Word";
        try
        {
            aplicacion = Activator.CreateInstance(tipo);
            dynamic word = aplicacion;
            word.Visible = false;
            word.DisplayAlerts = 0;
            word.AutomationSecurity = 3; // msoAutomationSecurityForceDisable.
            etapa = "abrir el archivo de especificaciones";
            documentos = word.Documents;
            documento = ((dynamic)documentos).Open(FileName: archivo, ConfirmConversions: false, ReadOnly: true,
                AddToRecentFiles: false, Visible: true, NoEncodingDialog: true);
            ventana = ((dynamic)documento).ActiveWindow;
            etapa = "inicializar la ventana de impresión";
            // Pages/EnhMetaFileBits requieren una ventana de distribución real.
            // Mantenerla oculta o minimizada puede dejar la composición pendiente.
            // Sólo se mueve la instancia creada aquí, nunca el Word del usuario.
            ((dynamic)ventana).WindowState = 0; // wdWindowStateNormal.
            ventanaWord = new IntPtr(Convert.ToInt64(((dynamic)ventana).Hwnd, CultureInfo.InvariantCulture));
            ColocarVentanaEntrega(ventanaWord);
            word.Visible = true;
            ((dynamic)documento).Activate();
            ColocarVentanaEntrega(ventanaWord);
            RestaurarFocoEntrega(ventanaWord, focoAnterior);
            vista = ((dynamic)ventana).View;
            ((dynamic)vista).Type = 3; // wdPrintView: distribución real de impresión de Word.
            etapa = "paginar las especificaciones";
            ((dynamic)documento).Repaginate();
            configuracion = ((dynamic)documento).PageSetup;
            double ancho = Convert.ToDouble(((dynamic)configuracion).PageWidth, CultureInfo.InvariantCulture);
            double alto = Convert.ToDouble(((dynamic)configuracion).PageHeight, CultureInfo.InvariantCulture);
            panel = ((dynamic)ventana).ActivePane;
            paginas = ((dynamic)panel).Pages;
            int cantidad = (int)((dynamic)paginas).Count;
            if (cantidad <= 0)
                throw new InvalidOperationException("Microsoft Word no proporcionó páginas para el documento de entrega.");
            for (int i = 1; i <= cantidad; i++)
            {
                etapa = "obtener la página " + i.ToString(CultureInfo.CurrentCulture);
                object hoja = null;
                MemoryStream flujo = null;
                Metafile imagen = null;
                try
                {
                    hoja = ((dynamic)paginas).Item(i);
                    byte[] bits = LeerMetarchivoWord(((dynamic)hoja).EnhMetaFileBits);
                    // PageSetup conserva las fracciones de punto del papel. Si
                    // hay secciones con medidas distintas, Word devuelve el
                    // valor wdUndefined y se consulta cada página concreta.
                    double anchoHoja = MedidaWordValida(ancho) ? ancho : Convert.ToDouble(((dynamic)hoja).Width, CultureInfo.InvariantCulture);
                    double altoHoja = MedidaWordValida(alto) ? alto : Convert.ToDouble(((dynamic)hoja).Height, CultureInfo.InvariantCulture);
                    if (!MedidaWordValida(anchoHoja) || !MedidaWordValida(altoHoja))
                        throw new InvalidOperationException("Microsoft Word no proporcionó un tamaño de papel válido para la página " + i + ".");
                    var tamano = new Size(checked((int)Math.Round(anchoHoja / .72d)), checked((int)Math.Round(altoHoja / .72d)));
                    flujo = new MemoryStream(bits, writable: false);
                    imagen = new Metafile(flujo);
                    if (!imagen.GetMetafileHeader().IsEmfOrEmfPlus())
                        throw new InvalidDataException("Microsoft Word no proporcionó un metafichero EMF de la página " + i + ".");
                    resultado.Add(new PreviewPageInfo(imagen, tamano));
                    flujos.Add(flujo);
                    imagen = null;
                    flujo = null;
                }
                finally
                {
                    imagen?.Dispose();
                    flujo?.Dispose();
                    LiberarComEntrega(hoja);
                }
            }
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            throw new InvalidOperationException("Microsoft Word no pudo preparar las páginas de la entrega al " + etapa +
                " (0x" + CodigoErrorEntrega(ex).ToString("X8", CultureInfo.InvariantCulture) + "). " + Mensaje(ex), ex);
        }
        finally
        {
            RestaurarFocoEntrega(ventanaWord, focoAnterior);
            LiberarComEntrega(paginas); LiberarComEntrega(panel); LiberarComEntrega(vista);
            LiberarComEntrega(ventana); LiberarComEntrega(configuracion);
            if (documento != null)
            {
                try { ((dynamic)documento).Close(SaveChanges: 0); } catch (Exception) { }
                LiberarComEntrega(documento);
            }
            LiberarComEntrega(documentos);
            if (aplicacion != null)
            {
                try { ((dynamic)aplicacion).Quit(SaveChanges: 0); } catch (Exception) { }
                LiberarComEntrega(aplicacion);
            }
        }
    }

    private static int CodigoErrorEntrega(Exception error)
    {
        for (Exception causa = error; causa != null; causa = causa.InnerException)
            if (causa is COMException) return causa.HResult;
        return error.HResult;
    }

    private static void ColocarVentanaEntrega(IntPtr ventana)
    {
        if (!SetWindowPosEntrega(ventana, IntPtr.Zero, -32000, -32000, 1000, 800, 0x0014)) // NOZORDER | NOACTIVATE.
            throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(),
                "No se pudo inicializar la ventana de impresión de Word.");
    }

    private static void RestaurarFocoEntrega(IntPtr ventanaWord, IntPtr anterior)
    {
        // No quitar el foco si el usuario cambió a otra aplicación mientras Word trabajaba.
        if (ventanaWord != IntPtr.Zero && anterior != IntPtr.Zero && GetForegroundWindowEntrega() == ventanaWord)
            SetForegroundWindowEntrega(anterior);
    }

    [DllImport("user32.dll", EntryPoint = "SetWindowPos", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetWindowPosEntrega(IntPtr ventana, IntPtr despues, int x, int y,
        int ancho, int alto, uint opciones);

    [DllImport("user32.dll", EntryPoint = "GetForegroundWindow")]
    private static extern IntPtr GetForegroundWindowEntrega();

    [DllImport("user32.dll", EntryPoint = "SetForegroundWindow")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindowEntrega(IntPtr ventana);

    private static bool MedidaWordValida(double puntos) => double.IsFinite(puntos) && puntos > 0 && puntos < 9999999d;

    private static byte[] LeerMetarchivoWord(object valor)
    {
        if (valor is byte[] bytes && bytes.Length > 0) return bytes;
        if (valor is Array { Rank: 1, Length: > 0 } datos)
        {
            var copia = new byte[datos.Length];
            int inicio = datos.GetLowerBound(0);
            for (int i = 0; i < copia.Length; i++) copia[i] = Convert.ToByte(datos.GetValue(inicio + i), CultureInfo.InvariantCulture);
            return copia;
        }
        throw new InvalidOperationException("Microsoft Word no permite obtener la representación EMF de las páginas de este documento.");
    }

    private static void LiberarComEntrega(object valor)
    {
        try { LiberarCom(valor); }
        catch (InvalidComObjectException) { }
        catch (COMException) { }
    }
}
