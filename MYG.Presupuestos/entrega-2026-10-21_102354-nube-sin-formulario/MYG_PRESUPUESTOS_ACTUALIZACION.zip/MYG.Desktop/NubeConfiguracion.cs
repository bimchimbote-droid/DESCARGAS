#nullable enable
using System;
using System.IO;
using MYG.Colaboracion;

namespace MYG_2027;

/// <summary>La configuración contiene solo el destino y una clave pública; nunca una sesión.</summary>
public sealed record ConfiguracionNube(string Nombre, string Url, string ClavePublicable)
{
    public ClienteSupabase CrearCliente() => new(Url, ClavePublicable);
}

public static class NubeConfiguracion
{
    public static string Ruta => Path.Combine(Environment.GetFolderPath(
        Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "config.json");
    public static string RutaDistribuida => Path.Combine(AppContext.BaseDirectory, "nube-myg.json");

    public static ConfiguracionNube? Cargar()
    {
        var configuracion = ConfiguracionServicioNube.Cargar(Ruta, RutaDistribuida);
        return configuracion is null ? null : new ConfiguracionNube(
            configuracion.Nombre, configuracion.Url, configuracion.ClavePublicable);
    }

    public static void Guardar(ConfiguracionNube configuracion)
    {
        ArgumentNullException.ThrowIfNull(configuracion);
        ConfiguracionServicioNube.Guardar(Ruta, new ConfiguracionServicioNube(
            configuracion.Nombre, configuracion.Url, configuracion.ClavePublicable));
    }

}
