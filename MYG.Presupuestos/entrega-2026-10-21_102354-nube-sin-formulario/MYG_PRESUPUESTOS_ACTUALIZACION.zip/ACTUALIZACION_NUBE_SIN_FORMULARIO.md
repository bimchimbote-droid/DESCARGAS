# Nube MYG sin formulario de conexión — 21/10/2026

La conexión necesita su configuración interna, pero el usuario no necesita
verla ni introducirla. Esta actualización retira por completo el botón
**Opciones avanzadas** y el formulario de nombre, URL y clave publicable.
La cabecera utiliza el espacio restante para el estado de conexión.

Se conserva la conexión automática con la cuenta MYG, la configuración local
existente y el archivo público incluido en el instalador. No se crean atajos
ni accesos ocultos para volver a mostrar el formulario. Los errores remiten a
soporte, sin solicitar datos técnicos al usuario.

## Archivos del ZIP

Las rutas parten de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.
Los archivos REEMPLAZAR se entregan completos.

| N.º | Archivo | Acción | Qué hacer |
|---|---|---|---|
| 1 | `MYG.Desktop/NubeForm.cs` | REEMPLAZAR | Sustituir el existente; retira botón, columna y evento de configuración. |
| 2 | `MYG.Desktop/InicioNube.cs` | REEMPLAZAR | Sustituir el existente; elimina la apertura del formulario y ajusta mensajes. |
| 3 | `MYG.Desktop/NubeConfiguracion.cs` | REEMPLAZAR | Sustituir el existente; conserva carga/guardado internos y elimina el diálogo. |
| 4 | `scripts/Preparar-Nube/Program.cs` | REEMPLAZAR | Sustituir sólo este Program.cs; ajusta el mensaje de la herramienta de publicación. |
| 5 | `scripts/Publicar.ps1` | REEMPLAZAR | Sustituir el existente; orienta al autor hacia el archivo de distribución. |
| 6 | `ACTUALIZACION_NUBE_SIN_FORMULARIO.md` | CREAR | Copiar junto a la solución; instrucciones, no se ejecuta. |

El ZIP complementa la entrega anterior de conexión automática. Incluye sólo
los archivos que cambian ahora. No hay archivos que eliminar manualmente,
migraciones SQL ni cambios de datos reales.

## Instalación

1. Cierre MYG y respalde o confirme sus cambios locales.
2. Extraiga el ZIP y copie su contenido dentro de
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, combinando las carpetas existentes.
3. Reemplace los cinco archivos indicados y copie este documento en la raíz.
4. Abra `MYG.Presupuestos.sln` en Visual Studio, restaure NuGet y compile en Release.
   Ejecute la versión recién compilada. Un ejecutable anterior seguirá mostrando
   su interfaz anterior aunque haya copiado el código actualizado.
5. Para distribuir el cambio, genere un instalador nuevo desde PowerShell:

```powershell
.\scripts\Generar-Instalador.ps1 -Version 1.0.2
```

Use el número que corresponda a su siguiente versión. Se conservan los requisitos
anteriores: Windows, .NET SDK 10, Inno Setup y referencias de Revit para publicar.

No borre `%LOCALAPPDATA%\MYG\Nube\config.json` ni el `nube-myg.json` de la
instalación: la conexión automática sigue utilizándolos. No necesita ejecutar SQL
ni volver a escribir su conexión actual para aplicar esta mejora.

## Mantenimiento de la conexión, sólo para soporte

El proceso de publicación continúa utilizando la configuración guardada del
autor y genera `dist\MYG\nube-myg.json`, con los tres campos públicos.
Si está en otra ubicación, indique su archivo existente:

```powershell
.\scripts\Generar-Instalador.ps1 -Version 1.0.2 -ConfiguracionNube "D:\ConfiguracionMYG\config.json"
```

Un cambio futuro corresponde a soporte mediante el archivo de configuración y
reinicio de MYG. Se respeta la prioridad de la configuración local existente;
no se cambia automáticamente el servidor de obras vinculadas. La autenticación,
licencias, roles y permisos siguen verificándose en el servidor.

## Validación

Base: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`5eff104c9b208c40857bdbecf42298605e9e1d93`, conservando las entregas anteriores.
Rama local de preparación: `work`. C#, .NET SDK 10.0.100, WinForms/WPF.

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet build scripts/Preparar-Nube/Preparar-Nube.csproj -c Release
python scripts/pruebas/Probar-PrepararNube.py --no-build
```

Resultados: solución y herramienta compiladas con 0 errores y 0 advertencias;
21 comprobaciones de preparación aprobadas; `git diff --check` aprobado.
La revisión de referencias confirma que ya no se construyen el botón ni los
campos técnicos y no quedan llamadas al formulario eliminado.

No se ejecutaron la interfaz, PowerShell, Inno Setup ni Revit en este entorno
Linux. En Windows, compruebe que Nube MYG abre directamente sus proyectos,
conserva su conexión y ya no muestra el botón ni el formulario técnico.

## GitHub y precauciones

En Visual Studio: Cambios de Git, revisar el diff, comprobar rama `main`, crear
Commit y hacer Push. Esta entrega publica sólo su ZIP en una ruta nueva de
`DESCARGAS`; no hace Push del repositorio del código.

Compare sus personalizaciones antes de reemplazar archivos completos. Las
obras, vinculaciones, configuración y correcciones anteriores se conservan.
