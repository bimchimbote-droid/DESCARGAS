-- SOLO para una base PostgreSQL desechable. El ejecutor crea y elimina su propio
-- contenedor; este archivo crea un fixture reducido, nunca debe usarse en Supabase.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Use scripts/Probar-Supabase-Roles.sh; requiere una base desechable.'; end $$;
\endif

create role anon nologin;
create role authenticated nologin;
create role service_role nologin;
create schema auth;
create schema myg_nube_privado;
create schema qa;

-- Solo se simula auth.uid(), sin crear ni consultar auth.users.
create function auth.uid() returns uuid language sql stable as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;
grant usage on schema auth to authenticated, anon;

-- Columnas y unicidad usadas por las funciones exportadas; sin datos reales.
create table myg_nube_privado.identidades_verificadas (
  auth_usuario_id uuid primary key, usuario_myg text unique not null, activo boolean not null default true
);
create table public.myg_nube_proyectos (
  id uuid primary key, propietario uuid not null, codigo text not null default 'MYG-PRUEBA',
  nombre text not null, revision bigint not null default 1, contenido jsonb not null,
  alcance text not null default 'obra', creado_en timestamptz not null default now(),
  actualizado_en timestamptz not null default now()
);
create table public.myg_nube_miembros (
  proyecto_id uuid references public.myg_nube_proyectos(id), usuario_id uuid not null,
  rol text not null check (rol in ('propietario', 'administrador', 'editor', 'lector')),
  primary key (proyecto_id, usuario_id)
);
create table public.myg_nube_historial (
  proyecto_id uuid not null, revision bigint not null, usuario_id uuid, operacion_id uuid,
  contenido jsonb not null, creado_en timestamptz not null default now(), primary key(proyecto_id,revision)
);

create table public.myg_nube_operaciones (
  usuario_id uuid, operacion_id uuid, proyecto_id uuid not null, solicitud jsonb not null,
  respuesta jsonb not null, creado_en timestamptz not null default now(), primary key(usuario_id,operacion_id)
);

-- Helpers necesarios del contrato exportado, con las mismas reglas de sesión,
-- jerarquía, validación de destinatario y bloqueo por proyecto.
create function myg_nube_privado.identidad() returns uuid
language plpgsql stable security definer set search_path to pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := auth.uid();
begin
  if v_usuario is null then
    raise exception using errcode='42501', message='MYG_SESION_REQUERIDA';
  end if;
  if not exists (select 1 from myg_nube_privado.identidades_verificadas
                 where auth_usuario_id=v_usuario and activo) then
    raise exception using errcode='42501', message='MYG_VINCULO_NO_VERIFICADO';
  end if;
  return v_usuario;
end $$;
create function myg_nube_privado.cambiar_rol(p_id uuid, p_actor uuid, p_usuario uuid, p_rol text)
returns void language plpgsql security definer set search_path to pg_catalog, myg_nube_privado as $$
declare v_actor text; v_actual text; v_propietario uuid;
begin
  select propietario into v_propietario from public.myg_nube_proyectos where id=p_id for update;
  select rol into v_actor from public.myg_nube_miembros where proyecto_id=p_id and usuario_id=p_actor;
  select rol into v_actual from public.myg_nube_miembros where proyecto_id=p_id and usuario_id=p_usuario;
  if v_propietario is null or v_actor is null or v_actor not in ('propietario', 'administrador') then
    raise exception using errcode='42501', message='MYG_ACCESO_DENEGADO';
  end if;
  if p_usuario is null or p_usuario='00000000-0000-0000-0000-000000000000'::uuid
     or (p_rol is not null and p_rol not in ('administrador', 'editor', 'lector')) then
    raise exception using errcode='22023', message='MYG_ROL_INVALIDO';
  end if;
  if p_usuario=v_propietario or v_actual='propietario'
     or (v_actor='administrador' and (v_actual='administrador' or p_rol='administrador')) then
    raise exception using errcode='42501', message='MYG_JERARQUIA_PROTEGIDA';
  end if;
  if p_rol is null then
    delete from public.myg_nube_miembros where proyecto_id=p_id and usuario_id=p_usuario;
  else
    if not exists (select 1 from myg_nube_privado.identidades_verificadas
                   where auth_usuario_id=p_usuario and activo) then
      raise exception using errcode='22023', message='MYG_DESTINATARIO_NO_VERIFICADO';
    end if;
    insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values(p_id,p_usuario,p_rol)
    on conflict(proyecto_id,usuario_id) do update set rol=excluded.rol;
  end if;
end $$;
revoke all on function myg_nube_privado.identidad() from public;
revoke all on function myg_nube_privado.cambiar_rol(uuid,uuid,uuid,text) from public;

-- Firmas previas para probar CREATE OR REPLACE y endurecimiento de grants.
create function public.myg_nube_miembros(p_id uuid) returns jsonb language sql
security definer as $$ select '[]'::jsonb $$;
create function public.myg_nube_rol(p_id uuid,p_usuario uuid,p_rol text) returns boolean language sql
security definer as $$ select false $$;
grant execute on function public.myg_nube_miembros(uuid) to anon;
grant execute on function public.myg_nube_rol(uuid,uuid,text) to anon;

insert into myg_nube_privado.identidades_verificadas values
('00000000-0000-0000-0000-000000000001',' DueÑO ',true),
('00000000-0000-0000-0000-000000000002','ADMINISTRADOR',true),
('00000000-0000-0000-0000-000000000003','Editor',true),
('00000000-0000-0000-0000-000000000004','lector',true),
('00000000-0000-0000-0000-000000000005','inactivo',false),
('00000000-0000-0000-0000-000000000007','ajeno',true),
('00000000-0000-0000-0000-000000000008','admin2',true);
insert into public.myg_nube_proyectos(id,propietario,nombre,contenido) values
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','Obra sintética','{"no_tocar":"obra"}');
insert into public.myg_nube_miembros values
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','propietario'),
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','administrador'),
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','editor'),
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','lector'),
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000005','editor'),
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000006','editor'),
('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000008','administrador');
insert into public.myg_nube_historial(proyecto_id,revision,contenido) values
('10000000-0000-0000-0000-000000000001',7,'{"no_tocar":"historial"}');
create table qa.antes as select
  (select jsonb_agg(to_jsonb(p)) from public.myg_nube_proyectos p) proyectos,
  (select jsonb_agg(to_jsonb(h)) from public.myg_nube_historial h) historial,
  (select jsonb_agg(to_jsonb(m) order by usuario_id) from public.myg_nube_miembros m) miembros,
  (select jsonb_agg(to_jsonb(i) order by auth_usuario_id) from myg_nube_privado.identidades_verificadas i) identidades;

-- Baseline ejecutable del contrato exportado; datos exclusivamente sintéticos.
CREATE OR REPLACE FUNCTION myg_nube_privado.snapshot(p_id uuid, p_usuario uuid)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'myg_nube_privado'
AS $function$
    select jsonb_build_object('id', p.id, 'codigo', p.codigo, 'nombre', p.nombre,
        'rol', m.rol, 'revision', p.revision, 'alcance', p.alcance, 'contenido', p.contenido)
    from public.myg_nube_proyectos p join public.myg_nube_miembros m
      on m.proyecto_id = p.id and m.usuario_id = p_usuario where p.id = p_id;
$function$;

CREATE OR REPLACE FUNCTION myg_nube_privado.validar_contenido(p_contenido jsonb)
 RETURNS void
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog'
AS $function$
begin
    if p_contenido is null or jsonb_typeof(p_contenido) <> 'object'
       or octet_length(p_contenido::text) > 33554432 then
        raise exception using errcode = '22023', message = 'MYG_CONTENIDO_INVALIDO_MAX_32_MIB';
    end if;
end;
$function$;

CREATE OR REPLACE FUNCTION public.myg_nube_abrir(p_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'myg_nube_privado'
AS $function$
declare v_usuario uuid := myg_nube_privado.identidad(); v_resultado jsonb;
begin
    v_resultado := myg_nube_privado.snapshot(p_id, v_usuario);
    if v_resultado is null then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    return v_resultado;
end;
$function$;

CREATE OR REPLACE FUNCTION public.myg_nube_crear(p_id uuid, p_nombre text, p_contenido jsonb, p_alcance text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'myg_nube_privado'
AS $function$
declare v_usuario uuid := myg_nube_privado.identidad(); v_propietario uuid;
begin
    if p_id is null or p_id = '00000000-0000-0000-0000-000000000000'::uuid
       or p_nombre is null or length(btrim(p_nombre)) not between 1 and 200
       or p_alcance is null or p_alcance not in ('obra', 'base') then
        raise exception using errcode = '22023', message = 'MYG_PROYECTO_INVALIDO';
    end if;
    perform myg_nube_privado.validar_contenido(p_contenido);
    -- Serializa reintentos de creación del mismo UUID, incluso antes de existir fila.
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-crear:' || p_id::text, 0));
    select propietario into v_propietario from public.myg_nube_proyectos where id = p_id for update;
    if found then
        if v_propietario <> v_usuario then
            raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
        end if;
        if not exists (select 1 from public.myg_nube_proyectos p
            join public.myg_nube_historial h on h.proyecto_id = p.id and h.revision = 1
            where p.id = p_id and p.nombre = btrim(p_nombre) and p.alcance = p_alcance
                and h.contenido = p_contenido) then
            raise exception using errcode = '22023', message = 'MYG_ID_REUTILIZADO_CON_OTRA_CREACION';
        end if;
        -- Un reintento recupera el proyecto; nunca sobrescribe contenido posterior.
        return myg_nube_privado.snapshot(p_id, v_usuario);
    end if;
    insert into public.myg_nube_proyectos(id, codigo, nombre, propietario, contenido, alcance)
    values (p_id, 'MYG-' || upper(replace(p_id::text, '-', '')), btrim(p_nombre), v_usuario, p_contenido, p_alcance);
    insert into public.myg_nube_miembros(proyecto_id, usuario_id, rol) values (p_id, v_usuario, 'propietario');
    insert into public.myg_nube_historial(proyecto_id, revision, usuario_id, contenido)
    values (p_id, 1, v_usuario, p_contenido);
    return myg_nube_privado.snapshot(p_id, v_usuario);
end;
$function$;

CREATE OR REPLACE FUNCTION public.myg_nube_guardar(p_id uuid, p_operacion uuid, p_revision bigint, p_contenido jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'myg_nube_privado'
AS $function$
declare
    v_usuario uuid := myg_nube_privado.identidad(); v_proyecto public.myg_nube_proyectos%rowtype;
    v_rol text; v_anterior public.myg_nube_operaciones%rowtype; v_solicitud jsonb; v_respuesta jsonb;
begin
    if p_operacion is null or p_operacion = '00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision < 1 then
        raise exception using errcode = '22023', message = 'MYG_OPERACION_INVALIDA';
    end if;
    perform myg_nube_privado.validar_contenido(p_contenido);
    select * into v_proyecto from public.myg_nube_proyectos where id = p_id for update;
    select rol into v_rol from public.myg_nube_miembros where proyecto_id = p_id and usuario_id = v_usuario;
    -- Revisar permiso actual ANTES de devolver una respuesta histórica/idempotente.
    if v_proyecto.id is null or v_rol is null or v_rol not in ('propietario', 'administrador', 'editor') then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-op:' || v_usuario::text || ':' || p_operacion::text, 0));
    v_solicitud := jsonb_build_object('revision', p_revision, 'contenido', p_contenido);
    select * into v_anterior from public.myg_nube_operaciones where usuario_id = v_usuario and operacion_id = p_operacion;
    if found then
        if v_anterior.proyecto_id <> p_id or v_anterior.solicitud <> v_solicitud then
            raise exception using errcode = '22023', message = 'MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        return v_anterior.respuesta;
    end if;
    if v_proyecto.revision <> p_revision then
        v_respuesta := jsonb_build_object('estado', 'conflicto', 'revision', v_proyecto.revision,
            'contenido', v_proyecto.contenido, 'operacion_id', p_operacion);
    else
        update public.myg_nube_proyectos set contenido = p_contenido, revision = revision + 1,
            actualizado_en = clock_timestamp() where id = p_id returning * into v_proyecto;
        insert into public.myg_nube_historial(proyecto_id, revision, usuario_id, operacion_id, contenido)
        values (p_id, v_proyecto.revision, v_usuario, p_operacion, p_contenido);
        v_respuesta := jsonb_build_object('estado', 'aplicada', 'revision', v_proyecto.revision,
            'contenido', v_proyecto.contenido, 'operacion_id', p_operacion);
    end if;
    insert into public.myg_nube_operaciones(usuario_id, operacion_id, proyecto_id, solicitud, respuesta)
    values (v_usuario, p_operacion, p_id, v_solicitud, v_respuesta);
    return v_respuesta;
end;
$function$;

CREATE OR REPLACE FUNCTION public.myg_nube_listar()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'myg_nube_privado'
AS $function$
declare v_usuario uuid := myg_nube_privado.identidad(); v_resultado jsonb;
begin
    select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'codigo', p.codigo,
        'nombre', p.nombre, 'rol', m.rol, 'revision', p.revision, 'alcance', p.alcance)
        order by p.actualizado_en desc, p.id), '[]'::jsonb) into v_resultado
    from public.myg_nube_proyectos p join public.myg_nube_miembros m
      on m.proyecto_id = p.id where m.usuario_id = v_usuario;
    return v_resultado;
end;
$function$;
grant insert,update,delete on public.myg_nube_miembros,public.myg_nube_proyectos,
  public.myg_nube_operaciones,public.myg_nube_historial to authenticated,anon;
grant truncate on public.myg_nube_miembros,public.myg_nube_proyectos,public.myg_nube_operaciones,public.myg_nube_historial to authenticated,anon;
grant update(rol),insert(rol) on public.myg_nube_miembros to authenticated,anon;
grant update(contenido),insert(contenido) on public.myg_nube_proyectos to authenticated,anon;
\ir ../migraciones/20261020_usuarios_myg_roles.sql
-- Una segunda ejecución debe conservar firmas, ACL y todos los datos.
-- Incluye ACL de columna que podrían existir en una instalación anterior.
grant update(permisos_modulos),insert(permisos_modulos) on public.myg_nube_miembros to authenticated,anon;
\ir ../migraciones/20261020_usuarios_myg_roles.sql

create table qa.resultados(descripcion text primary key);
create function qa.exige(p_condicion boolean,p_descripcion text) returns void language plpgsql
security definer set search_path to pg_catalog, qa as $$
begin
  if p_condicion is distinct from true then raise exception 'FALLO: %',p_descripcion; end if;
  insert into qa.resultados values(p_descripcion);
  raise notice 'OK: %',p_descripcion;
end $$;
create function qa.rechaza(p_sql text,p_estado text,p_descripcion text) returns void language plpgsql as $$
declare v_estado text;
begin
  begin
    execute p_sql;
  exception when others then
    get stacked diagnostics v_estado=returned_sqlstate;
  end;
  if v_estado is distinct from p_estado then
    raise exception 'FALLO %: SQLSTATE esperado %, recibido %',p_descripcion,p_estado,coalesce(v_estado,'sin rechazo');
  end if;
  perform qa.exige(true,p_descripcion);
end $$;
grant usage on schema qa to authenticated,anon;
grant execute on function qa.exige(boolean,text),qa.rechaza(text,text,text) to authenticated,anon;

select qa.exige((select proyectos=(select jsonb_agg(to_jsonb(p)) from public.myg_nube_proyectos p)
  and historial=(select jsonb_agg(to_jsonb(h)) from public.myg_nube_historial h)
  and miembros=(select jsonb_agg(to_jsonb(m)-'permisos_modulos' order by usuario_id) from public.myg_nube_miembros m)
  and identidades=(select jsonb_agg(to_jsonb(i) order by auth_usuario_id) from myg_nube_privado.identidades_verificadas i)
  from qa.antes),'Reejecución conserva obras, historial, miembros e identidades');
select qa.exige(not has_function_privilege('anon','public.myg_nube_miembros(uuid)','execute')
  and not has_function_privilege('anon','public.myg_nube_rol(uuid,uuid,text)','execute'), 'Anon no tiene EXECUTE');
select qa.exige(not exists(select 1 from pg_proc p cross join lateral aclexplode(p.proacl) a
  where p.oid in ('public.myg_nube_miembros(uuid)'::regprocedure,'public.myg_nube_rol(uuid,uuid,text)'::regprocedure)
  and a.grantee=0 and a.privilege_type='EXECUTE'),'PUBLIC no tiene EXECUTE');
select qa.exige(has_function_privilege('authenticated','public.myg_nube_miembros(uuid)','execute')
  and has_function_privilege('authenticated','public.myg_nube_rol(uuid,uuid,text)','execute')
  and has_function_privilege('service_role','public.myg_nube_miembros(uuid)','execute')
  and has_function_privilege('service_role','public.myg_nube_rol(uuid,uuid,text)','execute'), 'Authenticated y service_role conservan RPC');
select qa.exige(to_regclass('auth.users') is null,'Listado funciona sin tabla auth.users');

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(jsonb_array_length(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001'))=7,
  'Propietario lista todos los miembros');
select qa.exige((select m->>'usuario_myg'='dueño' from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id'='00000000-0000-0000-0000-000000000001'),'Nombre MYG activo se normaliza');
select qa.exige((select bool_and(m->'usuario_myg'='null'::jsonb) from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id' in ('00000000-0000-0000-0000-000000000005','00000000-0000-0000-0000-000000000006')),
  'Vínculos inactivos o ausentes no inventan nombres');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','lector'), 'Propietario cambia editor a lector');
select qa.exige((select m->>'rol'='lector' from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id'='00000000-0000-0000-0000-000000000003'),'Nuevo rol se persiste');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','editor'), 'Propietario restituye editor');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001',null)$$,'42501','Propietario no puede retirarse');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','lector')$$,'42501','Propietario no puede degradarse');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','inventado')$$,'22023','Rol inválido se rechaza');
select qa.exige((select m->>'rol'='editor' from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id'='00000000-0000-0000-0000-000000000003'),'Rol inválido conserva miembro anterior');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000005',null), 'Propietario retira miembro inactivo');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000006',null), 'Propietario retira miembro sin vínculo');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004',null), 'Propietario retira miembro activo');
select qa.exige(not exists(select 1 from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id' in ('00000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000005','00000000-0000-0000-0000-000000000006')), 'Miembros retirados desaparecen');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','lector'), 'Propietario puede restaurar lector verificado');

set request.jwt.claim.sub='00000000-0000-0000-0000-000000000002';
select qa.exige(jsonb_array_length(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001'))=5,'Administrador lista miembros');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','lector'),'Administrador cambia editor a lector');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','editor'),'Administrador restituye editor');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000008','editor')$$,'42501','Administrador no cambia otro administrador');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000008',null)$$,'42501','Administrador no retira otro administrador');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','administrador')$$,'42501','Administrador no promueve a administrador');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001',null)$$,'42501','Administrador no retira propietario');

set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')$$,'42501','Editor no enumera miembros');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004',null)$$,'42501','Editor no administra roles');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.rechaza($$select public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')$$,'42501','Lector no enumera miembros');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',null)$$,'42501','Lector no administra roles');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')$$,'42501','No miembro no enumera miembros');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',null)$$,'42501','No miembro no administra roles');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000005';
select qa.rechaza($$select public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')$$,'42501','Vínculo inactivo no consulta miembros');
set request.jwt.claim.sub='';
select qa.rechaza($$select public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')$$,'42501','Sin sesión no consulta miembros');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',null)$$,'42501','Sin sesión no administra roles');
set role anon;
select qa.rechaza($$select public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')$$,'42501','Anon no ejecuta listado');
select qa.rechaza($$select public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',null)$$,'42501','Anon no ejecuta cambios de rol');
reset role;
select qa.exige((select proyectos=(select jsonb_agg(to_jsonb(p)) from public.myg_nube_proyectos p)
  and historial=(select jsonb_agg(to_jsonb(h)) from public.myg_nube_historial h)
  from qa.antes),'Administración nunca altera obras ni historial');


set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$update public.myg_nube_miembros set permisos_modulos='{"acu":true,"especificaciones":true,"metrados_excel":true}'
  where usuario_id='00000000-0000-0000-0000-000000000003'$$, '42501','DML directo no amplía permisos de módulo');
select qa.rechaza($$update public.myg_nube_proyectos set contenido='{}'$$,'42501','DML directo no reemplaza contenido');
select qa.rechaza($$insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values
  ('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000007','administrador')$$,
  '42501','DML directo no crea administradores');
select qa.rechaza($$delete from public.myg_nube_miembros$$,'42501','DML directo no elimina miembros');
select qa.rechaza($$truncate public.myg_nube_miembros$$,'42501','DML directo no trunca miembros');
set role anon;
select qa.rechaza($$update public.myg_nube_miembros set rol='propietario'$$,'42501','Anon no altera roles directamente');
reset role;
-- Compartir por usuario MYG y permisos de módulos; la administración existente
-- de roles no debe borrar las máscaras ni conceder acceso mediante nombres ajenos.
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',' AJENO ','editor',
  '{"acu":false,"especificaciones":true,"metrados_excel":false}')='{"estado":"actualizada"}'::jsonb,
  'Propietario comparte con nombre MYG normalizado');
select qa.exige((select m->>'usuario_myg'='ajeno' and m->>'rol'='editor'
  and m->'permisos_modulos'='{"acu":false,"especificaciones":true,"metrados_excel":false}'::jsonb
  from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id'='00000000-0000-0000-0000-000000000007'), 'Compartir confirma identidad y máscara exacta');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000007','lector'),
  'Cambio de rol sigue disponible para nuevo colaborador');
select qa.exige((select m->'permisos_modulos'='{"acu":false,"especificaciones":true,"metrados_excel":false}'::jsonb
  from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id'='00000000-0000-0000-0000-000000000007'), 'Cambio de rol conserva permisos de módulo');
select qa.exige(public.myg_nube_rol('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000007','editor'),
  'Propietario restaura editor con misma máscara');
select qa.exige(public.myg_nube_permisos('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',
  '{"acu":false,"especificaciones":false,"metrados_excel":false}')='{"estado":"actualizada"}'::jsonb,
  'Propietario cambia permisos sin cambiar el rol');
select qa.rechaza($$select public.myg_nube_permisos('10000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000001','{"acu":false,"especificaciones":false,"metrados_excel":false}')$$,
  '22023','Permisos no alteran propietario protegido');
select qa.rechaza($$select public.myg_nube_permisos('10000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000006','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '22023','Cambiar permisos no crea miembro ausente');
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'inactivo','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '22023','Compartir rechaza vínculo inactivo');
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'no-existe','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '22023','Compartir rechaza usuario inexistente');
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'ajeno','propietario','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '22023','Compartir no permite conceder propietario');
do $casos$
declare v jsonb; n integer:=0;
begin
  foreach v in array array[null::jsonb,'null','true','[]','{}','{"acu":true}',
    '{"acu":true,"especificaciones":true,"metrados_excel":null}',
    '{"acu":"true","especificaciones":true,"metrados_excel":true}',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"otro":true}']::jsonb[]
  loop
    n:=n+1;
    perform qa.rechaza(format('select public.myg_nube_permisos(%L,%L,%L::jsonb)',
      '10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',v),
      '22023','Permisos inválidos rechazados caso '||n);
    perform qa.rechaza(format('select public.myg_nube_compartir_usuario(%L,%L,%L,%L::jsonb)',
      '10000000-0000-0000-0000-000000000001','ajeno','editor',v),
      '22023','Compartir no amplía permisos inválidos caso '||n);
  end loop;
end $casos$;
select qa.exige((select m->'permisos_modulos'='{"acu":false,"especificaciones":false,"metrados_excel":false}'::jsonb
  from jsonb_array_elements(public.myg_nube_miembros('10000000-0000-0000-0000-000000000001')) m
  where m->>'usuario_id'='00000000-0000-0000-0000-000000000003'), 'Permisos inválidos revierten sin ampliar máscara anterior');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000002';
select qa.exige(public.myg_nube_permisos('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',
  '{"acu":false,"especificaciones":true,"metrados_excel":false}')='{"estado":"actualizada"}'::jsonb,
  'Administrador cambia permisos de editor');
select qa.rechaza($$select public.myg_nube_permisos('10000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000008','{"acu":false,"especificaciones":false,"metrados_excel":false}')$$,
  '42501','Administrador no cambia permisos de otro administrador');
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'ajeno','administrador','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Compartir como administrador no eleva a otro administrador');
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'admin2','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Compartir como administrador no degrada a otro administrador');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.exige((public.myg_nube_listar()->0->'permisos_modulos')=
  '{"acu":false,"especificaciones":true,"metrados_excel":false}'::jsonb, 'Listado devuelve permisos de la identidad autenticada');
select qa.exige(public.myg_nube_abrir('10000000-0000-0000-0000-000000000001')->'permisos_modulos'=
  '{"acu":false,"especificaciones":true,"metrados_excel":false}'::jsonb, 'Snapshot devuelve permisos sin ocultar contenido');
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'ajeno','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Editor no comparte ni enumera por nombre');
select qa.rechaza($$select public.myg_nube_permisos('10000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000003','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Editor no amplía sus propios permisos');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'ajeno','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Lector no comparte por nombre');
select qa.rechaza($$select public.myg_nube_permisos('10000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000004','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Lector no modifica permisos');
set request.jwt.claim.sub='';
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'ajeno','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Sin sesión no comparte por nombre');
set role anon;
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'ajeno','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Anon no ejecuta compartir');
select qa.rechaza($$select public.myg_nube_permisos('10000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000003','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '42501','Anon no ejecuta permisos');
reset role;
select qa.exige(not has_function_privilege('anon','public.myg_nube_compartir_usuario(uuid,text,text,jsonb)','execute')
  and not has_function_privilege('anon','public.myg_nube_permisos(uuid,uuid,jsonb)','execute'), 'RPC nuevas no conceden EXECUTE a anon');
insert into myg_nube_privado.identidades_verificadas values
('00000000-0000-0000-0000-000000000010','AJENO',true);
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$select public.myg_nube_compartir_usuario('10000000-0000-0000-0000-000000000001',
  'ajeno','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,
  '22023','Nombres normalizados ambiguos no asignan cuenta arbitraria');
reset role;
create table qa.antes_repetir as select jsonb_agg(to_jsonb(m) order by usuario_id) miembros from public.myg_nube_miembros m;
\ir ../migraciones/20261020_usuarios_myg_roles.sql
select qa.exige((select miembros=(select jsonb_agg(to_jsonb(m) order by usuario_id) from public.myg_nube_miembros m)
  from qa.antes_repetir),'Reejecución preserva roles y máscaras personalizadas');


-- Paquetes generados por el código real de MYG, con datos exclusivamente
-- sintéticos y archivos dentro del contenedor desechable del ejecutor.
create table qa.paquetes(nombre text primary key, contenido jsonb not null);
insert into qa.paquetes select f, pg_read_file('/pruebas/paquetes/'||f||'.json')::jsonb
from unnest(array['baseline','baseline_excel','nombre','descripcion','cantidad','acu_insumo','acu_precio','acu_recurso',
  'especificacion','hoja_excel','zoom_excel','fuente_excel','cantidad_excel',
  'ataque_tabla_acu','ataque_tabla_especificacion','ataque_tabla_excel','ataque_tipo_celda_acu','ataque_mayusculas_acu','ataque_documentos','ataque_recursos']) f;
grant select on qa.paquetes to authenticated;
-- Validar la estructura incluso cuando ambas versiones de una tabla son
-- idénticas y la optimización omite comparar su contenido protegido.
select qa.rechaza($$select myg_nube_privado.exigir_modulos(p,p,
  '{"acu":false,"especificaciones":false,"metrados_excel":false}')
  from (select jsonb_set(contenido,'{tablas}',
    (contenido->'tablas')||jsonb_build_array(contenido->'tablas'->0)) p
    from qa.paquetes where nombre='baseline') caso$$,
  '22023','Guard valida tabla duplicada aunque sea idéntica en ambas versiones');
select qa.rechaza($$select myg_nube_privado.exigir_modulos(p,p,
  '{"acu":false,"especificaciones":false,"metrados_excel":false}')
  from (select jsonb_set(contenido,'{tablas,0,Columnas}',
    (contenido#>'{tablas,0,Columnas}')||jsonb_build_array(upper(contenido#>>'{tablas,0,Columnas,0}'))) p
    from qa.paquetes where nombre='baseline') caso$$,
  '22023','Guard valida columna duplicada por casing aunque tabla no cambie');
-- Cambiar únicamente nombres visibles no permite ocultar cambios de tablas
-- nativas ni alteraciones por otro casing dentro de un módulo restringido.
select qa.rechaza($$select myg_nube_privado.exigir_modulos(a.contenido,
  jsonb_set(jsonb_set(b.contenido,'{documento,Nombre}','"RENOMBRE METADATA QA"'),'{documentos}',
    (select coalesce(jsonb_agg(jsonb_set(d,'{Nombre}','"RENOMBRE METADATA QA"')),'[]'::jsonb)
     from jsonb_array_elements(b.contenido->'documentos') d)),
  '{"acu":false,"especificaciones":false,"metrados_excel":false}')
  from qa.paquetes a,qa.paquetes b
  where a.nombre='baseline' and b.nombre='ataque_tabla_acu'$$,
  '42501','Renombrar metadatos no omite validar cambios de tabla ACU');
select qa.rechaza($$select myg_nube_privado.exigir_modulos(a.contenido,
  jsonb_set(jsonb_set(b.contenido,'{documento,Nombre}','"RENOMBRE METADATA QA"'),'{documentos}',
    (select coalesce(jsonb_agg(jsonb_set(d,'{Nombre}','"RENOMBRE METADATA QA"')),'[]'::jsonb)
     from jsonb_array_elements(b.contenido->'documentos') d)),
  '{"acu":false,"especificaciones":false,"metrados_excel":false}')
  from qa.paquetes a,qa.paquetes b
  where a.nombre='baseline' and b.nombre='ataque_mayusculas_acu'$$,
  '42501','Renombrar metadatos no omite validar cambios ACU por casing');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Guard SQL',
  (select contenido from qa.paquetes where nombre='baseline'),'obra')->>'rol'='propietario',
  'Crear proyecto nuevo conserva contrato y permisos por defecto');
select qa.exige(public.myg_nube_compartir_usuario('20000000-0000-0000-0000-000000000001','editor','editor',
  '{"acu":false,"especificaciones":false,"metrados_excel":false}')='{"estado":"actualizada"}'::jsonb,
  'Editor restringido comparte proyecto sintético de guardado');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
do $guard$
declare v text;
begin
  foreach v in array array['acu_insumo','acu_precio','acu_recurso','especificacion','hoja_excel','fuente_excel',
    'ataque_tabla_acu','ataque_tabla_especificacion','ataque_tabla_excel','ataque_tipo_celda_acu','ataque_documentos','ataque_recursos']
  loop
    perform qa.rechaza(format('select public.myg_nube_guardar(%L,gen_random_uuid(),1,(select contenido from qa.paquetes where nombre=%L))',
      '20000000-0000-0000-0000-000000000001',v),'42501','Guardar impide cambio protegido: '||v);
  end loop;
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select contenido from qa.paquetes where nombre='ataque_mayusculas_acu'))$$,'42501','Guardar normaliza mayúsculas sin permitir cambios protegidos');
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select contenido||'{"Formato":"MYG_COLABORACION"}'::jsonb from qa.paquetes where nombre='baseline'))$$,
    '22023','Guardar rechaza JSON con claves ambiguas');
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select jsonb_set(contenido,'{alcance}','"base"') from qa.paquetes where nombre='baseline'))$$,
    '42501','Guardar no remapea alcance con módulos protegidos');
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select jsonb_set(contenido,'{documento,Presupuestos,0,Items,0,IdLocalMYG}','"OTRA-PARTIDA"')
     from qa.paquetes where nombre='baseline'))$$,
    '42501','Guardar no remapea IdLocalMYG con módulos protegidos');
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select jsonb_set(contenido,'{documento,Presupuestos,0,Items,0,IdPropuesta}','"OTRA-PROPUESTA"')
     from qa.paquetes where nombre='baseline'))$$,
    '42501','Guardar no remapea IdPropuesta con módulos protegidos');
  -- En el fixture real la tabla 1 es costo_unitario y la columna 7 es
  -- archivo_especificaciones. Cambiar BLOB a texto con idénticos bytes Base64
  -- altera el contenido restaurado y debe estar protegido por especificaciones.
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select jsonb_set(contenido,'{tablas,1,Filas,0,7,Tipo}','"texto"') from qa.paquetes where nombre='baseline'))$$,
    '42501','Guardar protege tipo de archivo de especificaciones aunque Valor no cambie');
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select (contenido-'documento')||jsonb_build_object('Documento',contenido->'documento')
     from qa.paquetes where nombre='baseline'))$$,
    '22023','Guardar rechaza Documento con casing incompatible del envoltorio');
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,
    (select (contenido-'recursos')||jsonb_build_object('Recursos',contenido->'recursos')
     from qa.paquetes where nombre='baseline'))$$,
    '22023','Guardar rechaza Recursos con casing incompatible del envoltorio');
  perform qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',gen_random_uuid(),1,'{}')$$,
    '22023','Guardar restringido rechaza paquete desconocido');
end $guard$;
reset role;
select qa.exige((select revision=1 and contenido=(select contenido from qa.paquetes where nombre='baseline')
  from public.myg_nube_proyectos where id='20000000-0000-0000-0000-000000000001')
  and not exists(select 1 from public.myg_nube_operaciones where proyecto_id='20000000-0000-0000-0000-000000000001')
  and (select count(*)=1 from public.myg_nube_historial where proyecto_id='20000000-0000-0000-0000-000000000001'),
  'Rechazos revierten contenido, revisión, historial y operaciones');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.exige(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,
  (select contenido from qa.paquetes where nombre='nombre'))->>'estado'='aplicada',
  'Guardar permite nombre fuera de módulos restringidos');
select qa.exige(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,
  (select contenido from qa.paquetes where nombre='nombre'))->>'revision'='2',
  'Repetir UUID y contenido recupera confirmación idempotente');
select qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',
  '30000000-0000-0000-0000-000000000001',1,(select contenido from qa.paquetes where nombre='descripcion'))$$,
  '22023','Mismo UUID con otro cuerpo no pisa confirmación');
select qa.exige(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000002',1,
  (select contenido from qa.paquetes where nombre='descripcion'))->>'estado'='conflicto',
  'Revisión antigua conserva protocolo de conflicto');
select qa.exige(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000003',2,
  (select contenido from qa.paquetes where nombre='descripcion'))->>'revision'='3',
  'Guardar permite descripción fuera de módulos restringidos');
select qa.exige(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000004',3,
  (select contenido from qa.paquetes where nombre='cantidad'))->>'revision'='4',
  'Guardar permite cantidad de metrado manual');
select qa.exige(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000005',4,
  (select contenido from qa.paquetes where nombre='zoom_excel'))->>'revision'='5',
  'Guardar permite preferencia de zoom sin editar Excel');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_permisos('20000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',
  '{"acu":false,"especificaciones":true,"metrados_excel":false}')='{"estado":"actualizada"}'::jsonb,
  'Propietario habilita solo especificaciones');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.exige(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000006',5,
  (select contenido from qa.paquetes where nombre='especificacion'))->>'revision'='6',
  'Máscara independiente permite módulo habilitado');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_rol('20000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',null),
  'Propietario revoca acceso tras operación confirmada');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001',
  '30000000-0000-0000-0000-000000000001',1,(select contenido from qa.paquetes where nombre='nombre'))$$,
  '42501','Revocación se comprueba antes de respuesta histórica');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_crear('20000000-0000-0000-0000-000000000002','Excel SQL',
  (select contenido from qa.paquetes where nombre='baseline_excel'),'obra')->>'rol'='propietario',
  'Crea proyecto de prueba con fuente Excel activa');
select qa.exige(public.myg_nube_compartir_usuario('20000000-0000-0000-0000-000000000002','editor','editor',
  '{"acu":true,"especificaciones":true,"metrados_excel":false}')='{"estado":"actualizada"}'::jsonb,
  'Limita únicamente metrado Excel');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000002',gen_random_uuid(),1,
  (select contenido from qa.paquetes where nombre='cantidad_excel'))$$,
  '42501','Metrado Excel activo protege cantidad calculada');
reset role;
select qa.exige(not has_table_privilege('authenticated','public.myg_nube_proyectos','UPDATE')
  and not has_table_privilege('authenticated','public.myg_nube_miembros','UPDATE'), 'No existe bypass DML del guardado');

select format('PRUEBAS SQL COMPLETADAS: %s',count(*)) from qa.resultados;
