using System.Text.Json;
using System.Text.Json.Nodes;
using MYG_2027;
using MYG.Colaboracion;

if (args.Length > 1) throw new ArgumentException("Uso: PaquetesPrueba [directorio-vacio]");
string target = args.Length == 1
    ? Path.GetFullPath(args[0])
    : Path.Combine(Path.GetTempPath(), "myg-paquetes-prueba-" + Guid.NewGuid().ToString("N"));
if (Directory.Exists(target) && Directory.EnumerateFileSystemEntries(target).Any())
    throw new IOException("El directorio de pruebas debe estar vacío; no se sobrescribe contenido existente.");
Directory.CreateDirectory(target);
string originalPath = Path.Combine(target, "baseline.sqlite");
var doc = MYGProyectoStorage.Nuevo("OBRA SINTETICA QA", "PRESUPUESTO QA");
doc.Id = "QA-DOCUMENTO";
var presupuesto = doc.Presupuestos[0];
presupuesto.Id = "QA-PRESUPUESTO";
doc.PresupuestoActivoId = presupuesto.Id;
var insumo = new MYGInsumo { Id = "QA-INSUMO", Codigo = "MAT-01", Descripcion = "Insumo sintetico", Unidad = "und", Precio = 10m, Grupo = MYGGrupoRecurso.Materiales };
presupuesto.Costos.Insumos.Add(insumo);
var partida = new ItemPresupuestoDelphin
{
 Id = "QA-PARTIDA", IdLocalMYG = "QA-PARTIDA", IdPropuesta = "QA-PARTIDA",
 TipoPropuesta = "PARTIDA", Descripcion = "Partida sintetica QA", Unidad = "und", Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1
};
partida.Costos.Cantidad = 5m;
partida.Costos.PrecioDirecto = 25m;
partida.Costos.Analisis.Add(new MYGRecursoACU { Id="QA-RECURSO", InsumoId=insumo.Id, Cantidad=2m, Grupo=MYGGrupoRecurso.Materiales });
partida.Costos.EspecificacionTexto = "Especificacion sintetica original";
partida.Costos.EspecificacionRtf = "{\\rtf1 Especificacion sintetica original}";
partida.Costos.Hoja.Poner("G16", "5");
presupuesto.Items.Add(partida);
MYGProyectoStorage.Guardar(originalPath, doc);
// Persisted state must be shared across all variants; each variant starts from the same DB.
var baseline = MYGProyectoStorage.Leer(originalPath);
Save("baseline", baseline, originalPath);
var cases = new Dictionary<string,Action<MYGProyectoDocumento>>
{
 ["nombre"] = d => d.Nombre = "OBRA RENOMBRADA QA",
 ["descripcion"] = d => d.Presupuestos[0].Items[0].Descripcion = "Descripcion modificada QA",
 ["cantidad"] = d => d.Presupuestos[0].Items[0].Costos.Cantidad = 8m,
 ["acu_precio"] = d => d.Presupuestos[0].Items[0].Costos.PrecioDirecto = 35m,
 ["acu_recurso"] = d => d.Presupuestos[0].Items[0].Costos.Analisis[0].Cantidad = 3m,
 ["acu_insumo"] = d => d.Presupuestos[0].Costos.Insumos[0].Precio = 15m,
 ["especificacion"] = d => { d.Presupuestos[0].Items[0].Costos.EspecificacionTexto = "Especificacion modificada QA"; d.Presupuestos[0].Items[0].Costos.EspecificacionRtf = "{\\rtf1 Especificacion modificada QA}"; },
 ["hoja_excel"] = d => d.Presupuestos[0].Items[0].Costos.Hoja.Poner("G16", "12"),
 ["zoom_excel"] = d => d.Presupuestos[0].Items[0].Costos.Hoja.Zoom = 150,
 ["fuente_excel"] = d => d.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.Excel,
};
foreach (var (name, action) in cases)
{
 string path = Path.Combine(target, name+".sqlite");
 File.Copy(originalPath,path);
 var copy = MYGProyectoStorage.Copia(baseline);
 action(copy);
 MYGProyectoStorage.Guardar(path,copy);
 Save(name,copy,path);
}
var excelBase = MYGProyectoStorage.Copia(baseline);
excelBase.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
string excelPath=Path.Combine(target,"baseline_excel.sqlite");
File.Copy(originalPath,excelPath);MYGProyectoStorage.Guardar(excelPath,excelBase);Save("baseline_excel",excelBase,excelPath);
excelBase.Presupuestos[0].Items[0].Costos.Cantidad = 9m;
MYGProyectoStorage.Guardar(excelPath,excelBase);Save("cantidad_excel",excelBase,excelPath);
// Simulan clientes modificados: el documento principal queda intacto mientras
// se intenta alterar datos nativos, otra copia del documento o el transporte.
NativeAttack("ataque_tabla_acu", "composicion_costounitario", "costo_composicion", "999");
NativeAttack("ataque_tabla_especificacion", "costo_unitario", "especificaciones", "Texto modificado solo en tabla");
NativeAttack("ataque_tabla_excel", "costo_unitario", "archivo_metrado", Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("METRADO SINTETICO NO PERMITIDO")), "blob");
var typeAttack = BaselineNode();
var nativeAcu = typeAttack["tablas"]!.AsArray().Single(t => t!["Nombre"]!.GetValue<string>() == "composicion_costounitario")!;
int costColumn = nativeAcu["Columnas"]!.AsArray().Select((c, i) => (Name: c!.GetValue<string>(), Index: i)).Single(c => c.Name == "costo_composicion").Index;
// El mismo Valor numérico se transporta ahora como texto: el tipo también
// forma parte del dato protegido y no debe desaparecer en la comparación.
nativeAcu["Filas"]![0]![costColumn]!["Tipo"] = "texto";
SaveAttack("ataque_tipo_celda_acu", typeAttack);
var attack = BaselineNode();
var costs = attack["documento"]!["Presupuestos"]![0]!["Items"]![0]!["Costos"]!.AsObject();
var analysis = costs["Analisis"];
costs.Remove("Analisis"); costs["analisis"] = analysis;
costs["analisis"]![0]!["Cantidad"] = 999;
SaveAttack("ataque_mayusculas_acu", attack);
attack = BaselineNode();
attack["documentos"]![0]!["Presupuestos"]![0]!["Items"]![0]!["Costos"]!["EspecificacionTexto"] = "Ataque copia secundaria";
SaveAttack("ataque_documentos", attack);
attack = BaselineNode();
attack["recursos"] = new JsonArray(new JsonObject
{
    ["Referencia"] = "sintetico", ["Nombre"] = "doc.txt", ["Sha256"] = new string('0', 64),
    ["Base64"] = "", ["Almacen"] = "qa/sintetico"
});
SaveAttack("ataque_recursos", attack);
Console.WriteLine($"Generados {Directory.GetFiles(target, "*.json").Length} paquetes sintéticos en {target}");
JsonNode BaselineNode() => JsonNode.Parse(File.ReadAllText(Path.Combine(target, "baseline.json")))!;
void SaveAttack(string name, JsonNode node) => File.WriteAllText(Path.Combine(target, name + ".json"), node.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
void NativeAttack(string name, string tableName, string column, string value, string? type = null)
{
    var node = BaselineNode();
    var table = node["tablas"]!.AsArray().Single(t => t!["Nombre"]!.GetValue<string>() == tableName)!;
    int index = table["Columnas"]!.AsArray().Select((c, i) => (Name: c!.GetValue<string>(), Index: i)).Single(c => c.Name == column).Index;
    table["Filas"]![0]![index]!["Valor"] = value;
    if (type is not null) table["Filas"]![0]![index]!["Tipo"] = type;
    SaveAttack(name, node);
}
void Save(string name,MYGProyectoDocumento d,string path)
{
 var package = PaqueteNube.CrearContenido(d,path,"obra");
 File.WriteAllText(Path.Combine(target,name+".json"),JsonSerializer.Serialize(package,new JsonSerializerOptions { WriteIndented=true }));
}
