# Actualización de usuarios, roles y permisos de Nube MYG

Base del código: `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`, commit
`5eff104c9b208c40857bdbecf42298605e9e1d93`. Preparado sobre los dos CSV de estructura
facilitados por el usuario. El segundo termina en la fila 100; los campos privados
necesarios se identificaron en las definiciones de las funciones, sin solicitar
filas de obras ni credenciales.

## Qué corrige

El listado de miembros recibe el nombre MYG desde una vinculación activa verificada.
Se conservan los UUID para administrar cuentas cuyo vínculo haya dejado de estar activo.
No se crean usuarios, licencias ni vinculaciones automáticamente. Una cuenta sin ese
vínculo seguirá sin nombre hasta que el administrador resuelva su vinculación real.

Se mantienen `myg_nube_rol(p_id,p_usuario,p_rol)` y sus respuestas booleanas; `NULL`
retira el acceso. Se agregan `myg_nube_compartir_usuario` y `myg_nube_permisos`, con
el contrato JSON que ya usa la aplicación. El propietario sigue protegido y un
administrador no puede asignar ni modificar administradores.

Los permisos `acu`, `especificaciones` y `metrados_excel` llegan al listado y a la
apertura de proyectos y se comprueban también al guardar en el servidor. Un rol
lector sigue sin poder guardar, aunque su máscara contenga valores `true`. Los
miembros existentes conservan sus permisos anteriores al instalar la columna.

El aviso de la captura corresponde a las nuevas funciones de compartir/permisos.
La función de cambiar/retirar roles ya figura en los CSV. No se puede concluir de
esa captura que la función de roles estuviera ausente; esta entrega comprueba su
contrato y recarga las firmas de PostgREST.

## Alcance de las restricciones

La protección compara el documento principal, los documentos secundarios, las
columnas nativas protegidas y el manifiesto completo de adjuntos. Respeta el
control de revisión y las operaciones idempotentes: un rechazo no agrega historial
ni confirma una operación. Las escrituras de los clientes pasan por los RPC; se
revocan sus permisos de escritura directa sobre las cuatro tablas Nube usadas para
miembros, proyectos, operaciones e historial, sin cambiar sus políticas RLS.

Con algún módulo bloqueado, añadir o retirar filas/presupuestos, cambiar identidades
o modificar tablas y catálogos sin un mapeo seguro puede rechazarse. Añadir, retirar
o sustituir adjuntos también exige permisos completos mientras haya algún módulo
bloqueado. Esos cambios estructurales requieren una cuenta con los tres módulos habilitados. Se mantienen
permitidos los cambios independientes comprobados: nombre, descripción, cantidades
manuales y zoom, además de la edición de un módulo cuando ese módulo está habilitado.
Este control es más conservador que la protección local del cliente. Los paquetes
anteriores que no contengan la estructura completa `MYG_COLABORACION`, versión 1,
con `documento`, `documentos`, `tablas` y `recursos`, deben regenerarse con el cliente
actual usando una cuenta con permisos completos antes de aplicar restricciones.
El servidor rechaza formatos que no puede verificar; no los transforma silenciosamente.

## Tiempo de guardado de obras grandes

La migración configura `statement_timeout = 60s` únicamente en
`public.myg_nube_guardar`. No modifica el tiempo general del servidor ni el del rol
`authenticated`. Supabase documenta este ajuste por función para sus RPC REST:
<https://supabase.com/docs/guides/database/postgres/timeouts#function-level>.

Los paquetes siguen limitados a 32 MiB. La revisión de permisos de un paquete
sintético de aproximadamente 25 MiB con 400 partidas y 4.800 insumos midió unos
5 segundos al renombrar, y entre 14 y 18 segundos en cambios de cantidad o de un
módulo habilitado, en esta máquina. Son mediciones locales, no una garantía de
latencia en otra instancia. Los guardados concurrentes siguen serializados por
proyecto y conservan el control de revisión; un guardado pesado puede hacer esperar
a otro del mismo proyecto. El cliente conserva su límite actual de 40 segundos,
que incluye la espera y la transferencia. Si se agota, debe reintentarse la misma
operación pendiente; el UUID idempotente evita aplicar el guardado dos veces.

## Aplicación manual

1. Respalde la base Supabase según sus procedimientos y guarde los cambios locales
   del proyecto mediante una copia o un commit. No publique credenciales.
2. Extraiga el ZIP y copie sus archivos nuevos en la raíz del proyecto, conservando
   las rutas. No borre ni reemplace bases SQLite ni carpetas `.git`.
3. En el proyecto Supabase correcto abra **SQL Editor → New query**. Ejecute completo
   **solo** `supabase/migraciones/20261020_usuarios_myg_roles.sql`. Incluye una única
   transacción y comprueba los requisitos antes de cambiar funciones. Si aparece un
   error, conserve el mensaje completo; no ejecute fragmentos para omitir controles.
4. Espere unos segundos a que PostgREST recargue sus funciones. Cierre y vuelva a
   abrir Nube MYG y pulse Actualizar/Cargar colaboración.
5. Con el propietario compruebe los nombres, cambiar editor a lector y viceversa,
   compartir con una cuenta MYG verificada y retirar ese acceso. Utilice una obra
   de prueba y una cuenta colaboradora; el propietario no debe poder retirarse.
6. Pruebe cada permiso por módulo: consulta permitida, edición denegada en el módulo
   bloqueado y edición/guardado en los módulos habilitados. Actualice o reabra el
   proyecto del colaborador después de cambiar permisos para renovar la información
   visible. El servidor controla el siguiente guardado aunque el cliente esté antiguo.

**No ejecute `supabase/pruebas/usuarios_myg_roles.sql` en Supabase.** Es un fixture
exclusivo de la base temporal creada por el ejecutor de pruebas.

## Repetición de pruebas

Se necesitan .NET SDK 10 (probado con 10.0.100), Docker y Bash para las pruebas SQL.
Desde la raíz del repositorio:

```bash
bash scripts/Probar-Supabase-Roles.sh
```

El ejecutor crea un contenedor PostgreSQL 17 temporal, sin puertos publicados,
genera paquetes sintéticos con el código real y elimina su contenedor al terminar.
No se conecta a Supabase ni necesita claves reales.

Para compilar y probar la aplicación desde Linux:

```bash
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
```

No se modificaron proyectos, dependencias ni código de la aplicación. En una
instalación que ya contenga el cliente de este commit basta aplicar la migración
para actualizar el servidor. Si el ejecutable pertenece a otra versión, compile
su proyecto actualizado antes de validar la interfaz. Windows, Revit y la
conexión real a su instancia Supabase requieren comprobación manual.

## Resultados verificados de esta entrega

- PostgreSQL 17: **134 comprobaciones aprobadas**, incluidos roles, nombres,
  compartir, máscaras independientes, jerarquía, revocación y guardados.
- Paquetes generados con .NET real: ataques por alias JSON, envoltorios con casing
  incompatible, tipos de celdas, tablas nativas, documentos secundarios y adjuntos
  rechazados; sin añadir historial ni confirmar operaciones rechazadas.
- PostgREST 16.5 y PostgreSQL 17, aislados de Supabase real: un guardado por REST de
  25 MiB terminó con HTTP 200 en 22,2 s; su reintento devolvió la misma revisión en
  2,9 s; una edición de especificaciones bloqueada devolvió HTTP 403 y dejó intacto
  el estado. El rol mantuvo su límite de 8 s y el RPC tuvo el suyo de 60 s.
- Solución completa .NET SDK 10.0.100: **cero errores y cero advertencias**.
- Suite de datos: **582 pruebas completadas**. Nube: **26 grupos y 787 comprobaciones
  HTTP**, además de los grupos de integración SQLite/HTTP simulado, aprobados.
- Omitidos: Named Pipes de Windows y la muestra privada opcional LLACUSBAMBA no
  suministrada. No se ejecutaron la interfaz de Windows ni Revit ni la migración
  sobre la instancia real del usuario.

## Guardar el código en GitHub

Revise los archivos en **Visual Studio → Cambios de Git**, confirme la rama local
de trabajo, haga Commit y luego Push a `main` cuando haya revisado y aplicado la
actualización. Compruebe después el commit en GitHub. Publicar el ZIP en
`bimchimbote-droid/DESCARGAS` no publica estos cambios en el repositorio del código
ni ejecuta SQL en Supabase.
