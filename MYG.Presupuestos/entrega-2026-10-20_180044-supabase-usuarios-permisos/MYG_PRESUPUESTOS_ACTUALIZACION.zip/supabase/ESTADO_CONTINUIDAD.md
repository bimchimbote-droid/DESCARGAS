# Continuidad de la integración Supabase MYG

Estado de implementación: completada y validada el 20 de octubre de 2026 (America/Lima).
Base: main remoto, commit `5eff104c9b208c40857bdbecf42298605e9e1d93`.

## Archivos y alcance

La migración única es `supabase/migraciones/20261020_usuarios_myg_roles.sql`.
Incluye nombres MYG desde vinculaciones activas, cambio/retiro de roles, compartir,
permisos por módulo, protección de propietarios/administradores y validación de
escrituras. Se conservaron los archivos y avances anteriores. No se cambió código
de la aplicación, dependencias ni bases reales de Supabase.

## Validaciones completadas

- Compilación .NET SDK 10.0.100: cero errores y cero advertencias.
- Datos: 582 pruebas completadas; Nube: 26 grupos y 787 comprobaciones HTTP más integración.
- PostgreSQL 17: 134 comprobaciones finales aprobadas; se verificó también la
  repetición de la migración, conservando datos y máscaras existentes.
- Intentos mediante alias JSON, tipos de celdas, tablas nativas, documentos y
  adjuntos rechazados; rechazos sin cambios de revisión, historial ni operaciones.
- Paquete sintético de 400 partidas y 4.800 insumos, unos 25 MiB: comprobación de
  renombrado ~5 s; cambios de contenido habilitado ~14–18 s en esta máquina.
- REST real aislado con PostgREST 16.5: guardado de 25 MiB HTTP 200 en 22,2 s;
  replay sin duplicar revisión en 2,9 s; edición bloqueada HTTP 403 sin mutaciones.
- El límite del rol permaneció en 8 s; solo el RPC de guardado se configuró a 60 s,
  siguiendo la documentación oficial de Supabase. El cliente conserva sus 40 s.

## Optimizaciones conservadas

Normalización superficial, agregación de arrays sin accesos repetidos, reutilización
exacta del documento principal, selección de celdas protegidas, cálculo de IDs Excel
solo cuando se necesita y exclusión de tablas idénticas tras validar TODOS sus
encabezados. Para cambios exclusivos de metadatos canónicos de navegación se evita
reconstruir los módulos; cualquier cambio en datos obliga a comprobarlos.

Con algún módulo bloqueado, ciertos cambios estructurales, catálogos sin mapeo y
modificaciones de adjuntos requieren los tres módulos habilitados. No se amplían
permisos ni se transforma contenido silenciosamente.

## Entrega y recuperación si vuelve a interrumpirse

Los resultados de la publicación se registran DESPUÉS de crear el ZIP, sin modificar
los archivos empaquetados. En esta máquina consultar:

- `/workspace/.cloud-setup/delivery.json`: manifiesto, ruta y SHA-256 del ZIP.
- `/workspace/.cloud-setup/delivery-publication.json`: commit, URL y verificación de descarga.
- `/workspace/.cloud-setup/final-sql-134-timeout.log`: SQL final aprobado.
- `/workspace/.cloud-setup/final-app-validation.log`: compilación y suites de aplicación.
- `/workspace/.cloud-setup/benchmark-final-variants.log`: medidas del guard de 25 MiB.
- `/workspace/.cloud-setup/rest-large-validation-final.log`: prueba REST completa.

Si falta `delivery-publication.json` o no confirma `download_verified: true`, el
próximo paso es terminar la publicación y descarga en una ruta nueva del repositorio
existente `bimchimbote-droid/DESCARGAS`, sin sobrescribir entregas ni publicar el código.
Si la descarga ya está verificada, comunicar el enlace y los pasos de aplicación.
No reiniciar investigaciones ni repetir suites aprobadas sin un cambio relevante.

La aplicación manual de la migración en Supabase real y las comprobaciones visuales
en Windows/Revit corresponden al usuario; no se han ejecutado desde este entorno.
