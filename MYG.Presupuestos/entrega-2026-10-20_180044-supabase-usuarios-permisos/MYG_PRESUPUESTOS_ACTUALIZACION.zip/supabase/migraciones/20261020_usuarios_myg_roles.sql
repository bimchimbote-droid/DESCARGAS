-- Usuarios MYG, roles y permisos para el esquema exportado el 20/10/2026.
-- Ejecutar completo en SQL Editor, con el rol administrador del proyecto.
-- Es repetible: conserva obras, vínculos, miembros y roles existentes.
-- Agrega una máscara de edición a cada miembro; los valores iniciales true
-- conservan el acceso previo. El rol lector sigue siendo de solo lectura.
-- Las cuentas sin vínculo MYG activo seguirán sin nombre disponible; su acceso
-- puede retirarse igualmente porque el destinatario se identifica por UUID.

begin;

-- Si el servidor tiene otro esquema, abortar antes de reemplazar funciones.
do $preflight$
declare
    v record;
    v_funcion oid;
begin
    for v in
        select * from (values
            ('public.myg_nube_miembros', 'proyecto_id', 'uuid'),
            ('public.myg_nube_miembros', 'usuario_id', 'uuid'),
            ('public.myg_nube_miembros', 'rol', 'text'),
            ('public.myg_nube_proyectos', 'id', 'uuid'),
            ('public.myg_nube_proyectos', 'propietario', 'uuid'),
            ('public.myg_nube_proyectos', 'codigo', 'text'),
            ('public.myg_nube_proyectos', 'nombre', 'text'),
            ('public.myg_nube_proyectos', 'revision', 'bigint'),
            ('public.myg_nube_proyectos', 'alcance', 'text'),
            ('public.myg_nube_proyectos', 'contenido', 'jsonb'),
            ('public.myg_nube_proyectos', 'actualizado_en', 'timestamp with time zone'),
            ('myg_nube_privado.identidades_verificadas', 'auth_usuario_id', 'uuid'),
            ('myg_nube_privado.identidades_verificadas', 'usuario_myg', 'text'),
            ('myg_nube_privado.identidades_verificadas', 'activo', 'boolean')
        ) as requisitos(relacion, columna, tipo)
    loop
        if not exists (
            select 1
            from pg_catalog.pg_attribute a
            join pg_catalog.pg_class c on c.oid = a.attrelid
            where a.attrelid = pg_catalog.to_regclass(v.relacion)
              and c.relkind in ('r', 'p')
              and a.attname = v.columna
              and a.atttypid = pg_catalog.to_regtype(v.tipo)
              and a.attnum > 0 and not a.attisdropped
        ) then
            raise exception 'Migración cancelada: falta la columna %.% de tipo %.',
                v.relacion, v.columna, v.tipo;
        end if;
    end loop;

    for v in
        select * from (values
            ('myg_nube_privado.identidad()', 'uuid'),
            ('myg_nube_privado.cambiar_rol(uuid,uuid,uuid,text)', 'void'),
            ('myg_nube_privado.snapshot(uuid,uuid)', 'jsonb'),
            ('public.myg_nube_listar()', 'jsonb'),
            ('public.myg_nube_miembros(uuid)', 'jsonb'),
            ('public.myg_nube_rol(uuid,uuid,text)', 'boolean')
        ) as requisitos(firma, resultado)
    loop
        v_funcion := pg_catalog.to_regprocedure(v.firma);
        if not exists (
            select 1 from pg_catalog.pg_proc p
            where p.oid = v_funcion and p.prokind = 'f'
              and p.prorettype = pg_catalog.to_regtype(v.resultado)
              and not p.proretset and p.prosecdef
        ) then
            raise exception 'Migración cancelada: falta la función SECURITY DEFINER % con resultado %.',
                v.firma, v.resultado;
        end if;
    end loop;

    if not exists (select 1 from pg_catalog.pg_roles where rolname = 'anon')
       or not exists (select 1 from pg_catalog.pg_roles where rolname = 'authenticated')
       or not exists (select 1 from pg_catalog.pg_roles where rolname = 'service_role') then
        raise exception 'Migración cancelada: faltan los roles estándar de Supabase.';
    end if;
end;
$preflight$;

-- Función de comprobación total: los objetos incompletos o con claves extra
-- nunca se interpretan como permisos abiertos por omisión.
create or replace function myg_nube_privado.permisos_modulos_validos(p_permisos jsonb)
returns boolean
language sql
immutable
set search_path to pg_catalog
as $function$
    select case when jsonb_typeof(p_permisos) = 'object' then
        p_permisos ?& array['acu', 'especificaciones', 'metrados_excel']
        and p_permisos - array['acu', 'especificaciones', 'metrados_excel'] = '{}'::jsonb
        and jsonb_typeof(p_permisos->'acu') = 'boolean'
        and jsonb_typeof(p_permisos->'especificaciones') = 'boolean'
        and jsonb_typeof(p_permisos->'metrados_excel') = 'boolean'
    else false end;
$function$;

revoke execute on function myg_nube_privado.permisos_modulos_validos(jsonb)
    from public, anon, authenticated, service_role;

alter table public.myg_nube_miembros
    add column if not exists permisos_modulos jsonb
    not null default '{"acu":true,"especificaciones":true,"metrados_excel":true}'::jsonb;

do $permisos$
begin
    if not exists (
        select 1 from pg_catalog.pg_attribute
        where attrelid = 'public.myg_nube_miembros'::regclass
          and attname = 'permisos_modulos' and atttypid = 'jsonb'::regtype
          and attnum > 0 and not attisdropped
    ) then
        raise exception 'Migración cancelada: permisos_modulos existente no es jsonb.';
    end if;
    if exists (
        select 1 from public.myg_nube_miembros
        where not myg_nube_privado.permisos_modulos_validos(permisos_modulos)
    ) then
        raise exception 'Migración cancelada: existen permisos por módulo inválidos; no se reemplazaron.';
    end if;
    if not exists (
        select 1 from pg_catalog.pg_constraint
        where conrelid = 'public.myg_nube_miembros'::regclass
          and conname = 'myg_nube_miembros_permisos_modulos_validos'
    ) then
        alter table public.myg_nube_miembros
            add constraint myg_nube_miembros_permisos_modulos_validos
            check (myg_nube_privado.permisos_modulos_validos(permisos_modulos));
    end if;
end;
$permisos$;

alter table public.myg_nube_miembros
    alter column permisos_modulos set not null;
-- ADD COLUMN define el valor inicial solamente si la columna es nueva.
-- Si ya existía, conservar tanto sus máscaras como su valor por defecto.

create or replace function myg_nube_privado.snapshot(p_id uuid, p_usuario uuid)
returns jsonb
language sql
stable
security definer
set search_path to pg_catalog, myg_nube_privado
as $function$
    select jsonb_build_object('id', p.id, 'codigo', p.codigo, 'nombre', p.nombre,
        'rol', m.rol, 'revision', p.revision, 'alcance', p.alcance,
        'contenido', p.contenido, 'permisos_modulos', m.permisos_modulos)
    from public.myg_nube_proyectos p
    join public.myg_nube_miembros m
      on m.proyecto_id = p.id and m.usuario_id = p_usuario
    where p.id = p_id;
$function$;

create or replace function public.myg_nube_listar()
returns jsonb
language plpgsql
stable
security definer
set search_path to pg_catalog, myg_nube_privado
as $function$
declare
    v_usuario uuid := myg_nube_privado.identidad();
    v_resultado jsonb;
begin
    select coalesce(jsonb_agg(jsonb_build_object(
        'id', p.id, 'codigo', p.codigo, 'nombre', p.nombre, 'rol', m.rol,
        'revision', p.revision, 'alcance', p.alcance,
        'permisos_modulos', m.permisos_modulos
    ) order by p.actualizado_en desc, p.id), '[]'::jsonb)
    into v_resultado
    from public.myg_nube_proyectos p
    join public.myg_nube_miembros m on m.proyecto_id = p.id
    where m.usuario_id = v_usuario;
    return v_resultado;
end;
$function$;

create or replace function public.myg_nube_miembros(p_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path to pg_catalog, myg_nube_privado
as $function$
declare
    v_usuario uuid := myg_nube_privado.identidad();
    v_resultado jsonb;
begin
    -- Mantener la autorización del servidor antes de consultar los nombres.
    if not exists (
        select 1 from public.myg_nube_miembros m
        where m.proyecto_id = p_id and m.usuario_id = v_usuario
          and m.rol in ('propietario', 'administrador')
    ) then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;

    select coalesce(jsonb_agg(jsonb_build_object(
        'usuario_id', m.usuario_id,
        'rol', m.rol,
        'usuario_myg', lower(btrim(i.usuario_myg)),
        'permisos_modulos', m.permisos_modulos
    ) order by m.usuario_id), '[]'::jsonb)
    into v_resultado
    from public.myg_nube_miembros m
    left join myg_nube_privado.identidades_verificadas i
      on i.auth_usuario_id = m.usuario_id and i.activo
    where m.proyecto_id = p_id;

    return v_resultado;
end;
$function$;

create or replace function public.myg_nube_rol(p_id uuid, p_usuario uuid, p_rol text)
returns boolean
language plpgsql
security definer
set search_path to pg_catalog, myg_nube_privado
as $function$
declare
    -- El actor procede exclusivamente de la sesión MYG verificada del servidor.
    -- p_usuario es el destinatario, nunca el actor que autoriza la operación.
    v_usuario uuid := myg_nube_privado.identidad();
begin
    -- Conservar las reglas y el bloqueo transaccional del helper instalado:
    -- propietario protegido; administrador no puede gestionar administradores;
    -- roles asignables administrador/editor/lector; NULL retira el acceso.
    perform myg_nube_privado.cambiar_rol(p_id, v_usuario, p_usuario, p_rol);
    return true;
end;
$function$;

create or replace function public.myg_nube_compartir_usuario(
    p_id uuid, p_usuario_myg text, p_rol text, p_permisos_modulos jsonb)
returns jsonb
language plpgsql
security definer
set search_path to pg_catalog, myg_nube_privado
as $function$
declare
    v_actor uuid := myg_nube_privado.identidad();
    v_rol_actor text;
    v_nombre text := lower(btrim(p_usuario_myg));
    v_usuario uuid;
    v_destino record;
    v_coincidencias integer := 0;
begin
    -- Autorizar antes de buscar una cuenta: no convertir este RPC en un
    -- directorio de usuarios para lectores o personas ajenas al proyecto.
    perform 1 from public.myg_nube_proyectos where id = p_id for update;
    select rol into v_rol_actor from public.myg_nube_miembros
      where proyecto_id = p_id and usuario_id = v_actor;
    if v_rol_actor is null or v_rol_actor not in ('propietario', 'administrador') then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    if v_nombre is null or length(v_nombre) not between 1 and 256
       or v_nombre ~ '[[:cntrl:]]'
       or p_rol is null or p_rol not in ('administrador', 'editor', 'lector')
       or not myg_nube_privado.permisos_modulos_validos(p_permisos_modulos) then
        raise exception using errcode = '22023', message = 'MYG_COLABORADOR_INVALIDO';
    end if;

    for v_destino in
        select i.auth_usuario_id
        from myg_nube_privado.identidades_verificadas i
        where lower(btrim(i.usuario_myg)) = v_nombre and i.activo
        for share of i
    loop
        v_usuario := v_destino.auth_usuario_id;
        v_coincidencias := v_coincidencias + 1;
    end loop;
    if v_coincidencias <> 1 then
        raise exception using errcode = '22023', message = 'MYG_DESTINATARIO_NO_VERIFICADO';
    end if;

    perform myg_nube_privado.cambiar_rol(p_id, v_actor, v_usuario, p_rol);
    update public.myg_nube_miembros set permisos_modulos = p_permisos_modulos
      where proyecto_id = p_id and usuario_id = v_usuario;
    return jsonb_build_object('estado', 'actualizada');
end;
$function$;

create or replace function public.myg_nube_permisos(
    p_id uuid, p_usuario uuid, p_permisos_modulos jsonb)
returns jsonb
language plpgsql
security definer
set search_path to pg_catalog, myg_nube_privado
as $function$
declare
    v_actor uuid := myg_nube_privado.identidad();
    v_rol_actor text;
    v_rol_destino text;
begin
    perform 1 from public.myg_nube_proyectos where id = p_id for update;
    select rol into v_rol_actor from public.myg_nube_miembros
      where proyecto_id = p_id and usuario_id = v_actor;
    if v_rol_actor is null or v_rol_actor not in ('propietario', 'administrador') then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    if p_usuario is null or p_usuario = '00000000-0000-0000-0000-000000000000'::uuid
       or not myg_nube_privado.permisos_modulos_validos(p_permisos_modulos) then
        raise exception using errcode = '22023', message = 'MYG_PERMISOS_INVALIDOS';
    end if;
    select rol into v_rol_destino from public.myg_nube_miembros
      where proyecto_id = p_id and usuario_id = p_usuario;
    if v_rol_destino is null then
        raise exception using errcode = '22023', message = 'MYG_MIEMBRO_NO_EXISTE';
    end if;

    -- El helper conserva la jerarquía incluso cuando no cambia el rol.
    -- No se permite añadir un miembro mediante este RPC de permisos.
    perform myg_nube_privado.cambiar_rol(p_id, v_actor, p_usuario, v_rol_destino);
    update public.myg_nube_miembros set permisos_modulos = p_permisos_modulos
      where proyecto_id = p_id and usuario_id = p_usuario;
    return jsonb_build_object('estado', 'actualizada');
end;
$function$;

-- Identidad y jerarquía conservan sus implementaciones y permisos privados.
-- No se concede acceso directo a tablas privadas, Auth ni al helper de roles.
revoke execute on function public.myg_nube_miembros(uuid) from public, anon;
revoke execute on function public.myg_nube_rol(uuid, uuid, text) from public, anon;
grant execute on function public.myg_nube_miembros(uuid) to authenticated, service_role;
grant execute on function public.myg_nube_rol(uuid, uuid, text) to authenticated, service_role;
revoke execute on function public.myg_nube_listar() from public, anon;
grant execute on function public.myg_nube_listar() to authenticated, service_role;
revoke execute on function public.myg_nube_compartir_usuario(uuid, text, text, jsonb) from public, anon;
revoke execute on function public.myg_nube_permisos(uuid, uuid, jsonb) from public, anon;
grant execute on function public.myg_nube_compartir_usuario(uuid, text, text, jsonb) to authenticated, service_role;
grant execute on function public.myg_nube_permisos(uuid, uuid, jsonb) to authenticated, service_role;

-- El cliente Nube escribe mediante RPC. Impedir que un cliente REST cambie
-- miembros, permisos, contenido o confirmaciones por DML directo, incluso si
-- una instalación anterior concedió UPDATE/INSERT por columna. No se alteran
-- las políticas RLS, los permisos de lectura ni el rol administrativo service_role.
do $solo_rpc$
declare
    v_tabla text;
    v_columnas text;
    v_rol text;
begin
    foreach v_tabla in array array[
        'public.myg_nube_miembros',
        'public.myg_nube_proyectos',
        'public.myg_nube_operaciones',
        'public.myg_nube_historial'
    ] loop
        if not exists (
            select 1 from pg_catalog.pg_class
            where oid = pg_catalog.to_regclass(v_tabla) and relkind in ('r', 'p')
        ) then
            raise exception 'Migración cancelada: falta la tabla Nube %.', v_tabla;
        end if;

        execute format('revoke insert, update, delete, truncate, trigger, references on table %s from public, anon, authenticated',
            pg_catalog.to_regclass(v_tabla));
        select string_agg(quote_ident(attname), ', ' order by attnum)
          into v_columnas
          from pg_catalog.pg_attribute
          where attrelid = pg_catalog.to_regclass(v_tabla)
            and attnum > 0 and not attisdropped;
        execute format('revoke insert (%s), update (%s), references (%s) on table %s from public, anon, authenticated',
            v_columnas, v_columnas, v_columnas, pg_catalog.to_regclass(v_tabla));

        -- La revocación anterior no debe ocultar permisos heredados de un rol
        -- personalizado. En ese caso cancelar sin cambiar sus concesiones.
        foreach v_rol in array array['anon', 'authenticated'] loop
            if pg_catalog.has_table_privilege(v_rol, v_tabla, 'INSERT')
               or pg_catalog.has_table_privilege(v_rol, v_tabla, 'UPDATE')
               or pg_catalog.has_table_privilege(v_rol, v_tabla, 'DELETE')
               or pg_catalog.has_table_privilege(v_rol, v_tabla, 'TRUNCATE')
               or pg_catalog.has_table_privilege(v_rol, v_tabla, 'TRIGGER')
               or pg_catalog.has_table_privilege(v_rol, v_tabla, 'REFERENCES')
               or pg_catalog.has_any_column_privilege(v_rol, v_tabla, 'INSERT')
               or pg_catalog.has_any_column_privilege(v_rol, v_tabla, 'UPDATE')
               or pg_catalog.has_any_column_privilege(v_rol, v_tabla, 'REFERENCES') then
                raise exception 'Migración cancelada: % conserva escritura heredada en %; revise sus roles administrativos.',
                    v_rol, v_tabla;
            end if;
        end loop;
    end loop;
end;
$solo_rpc$;

-- Parte de la misma transacción que 20261020_usuarios_myg_roles.sql.
-- El servidor evalúa su propia máscara, nunca una máscara enviada al guardar.
-- Las tablas nativas desconocidas se comparan completas: fallar cerrado es
-- preferible a permitir una escritura cuyo efecto sobre un módulo se desconoce.
CREATE OR REPLACE FUNCTION myg_nube_privado.json_minusculas(p_valor jsonb)
RETURNS jsonb LANGUAGE plpgsql IMMUTABLE SET search_path = pg_catalog AS $func$
DECLARE v_resultado jsonb; v_total bigint; v_unicos bigint;
BEGIN
    IF jsonb_typeof(p_valor)='object'
       AND NOT EXISTS(SELECT 1 FROM jsonb_object_keys(p_valor) AS claves(k) WHERE k<>lower(k)) THEN
        RETURN p_valor;
    END IF;
    -- Las celdas SQLite constituyen la mayor parte de un paquete grande. La
    -- forma canónica de dos campos permite evitar una consulta por cada celda.
    IF jsonb_typeof(p_valor)='object' AND p_valor ?& ARRAY['Tipo','Valor']
       AND p_valor-ARRAY['Tipo','Valor']='{}'::jsonb THEN
        RETURN jsonb_build_object('tipo',p_valor->'Tipo','valor',p_valor->'Valor');
    END IF;
    IF jsonb_typeof(p_valor) = 'object' THEN
        -- Sólo normaliza el nodo de navegación. Los subárboles protegidos se
        -- comparan completos: variar una clave interior nunca amplía permisos.
        SELECT count(*),count(DISTINCT lower(key)),coalesce(jsonb_object_agg(lower(key),value),'{}'::jsonb)
        INTO v_total,v_unicos,v_resultado FROM jsonb_each(p_valor);
        IF v_total<>v_unicos THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_JSON_CLAVES_AMBIGUAS';
        END IF;
        RETURN v_resultado;
    END IF;
    RETURN p_valor;
END $func$;

CREATE OR REPLACE FUNCTION myg_nube_privado.datos_modulo(p_costos jsonb,p_modulo text)
RETURNS jsonb LANGUAGE plpgsql IMMUTABLE SET search_path = pg_catalog AS $func$
DECLARE c jsonb := coalesce(nullif(myg_nube_privado.json_minusculas(p_costos),'null'::jsonb),'{}'::jsonb); h jsonb;
BEGIN
    IF p_modulo = 'acu' THEN
        RETURN jsonb_build_object('catalogomygid',coalesce(c->>'catalogomygid',''),
            'preciodirecto',coalesce(c->'preciodirecto','0'::jsonb),
            'precioimportadodelphin',coalesce(c->'precioimportadodelphin','null'::jsonb),
            'firmaanalisisimportadodelphin',coalesce(c->>'firmaanalisisimportadodelphin',''),
            'rendimientodiario',coalesce(c->'rendimientodiario','1'::jsonb),
            'jornadahoras',coalesce(c->'jornadahoras','8'::jsonb),
            'ordengruposacu',coalesce(c->'ordengruposacu','["ManoObra","Materiales","Equipo","Subcontratos","Subpartidas"]'::jsonb),
            'analisis',coalesce(c->'analisis','[]'::jsonb));
    ELSIF p_modulo = 'especificaciones' THEN
        RETURN jsonb_build_object('especificacionrtf',coalesce(c->>'especificacionrtf',''),
            'especificaciontexto',coalesce(c->>'especificaciontexto',''),
            'especificacionesborrador',coalesce(c->'especificacionesborrador','false'::jsonb));
    ELSIF p_modulo = 'metrados_excel' THEN
        h := myg_nube_privado.json_minusculas(c->'hoja');
        RETURN jsonb_build_object('hoja',CASE WHEN jsonb_typeof(h)='object' THEN h-'zoom' ELSE h END,
            'fuenteexcel',lower(coalesce(c->>'fuentemetrado','')) IN ('excel','3'),
            'cantidadexcel',CASE WHEN lower(coalesce(c->>'fuentemetrado','')) IN ('excel','3')
                                THEN coalesce(c->'cantidad','0'::jsonb) ELSE '0'::jsonb END);
    END IF;
    RAISE EXCEPTION USING errcode='22023',message='MYG_MODULO_INVALIDO';
END $func$;

CREATE OR REPLACE FUNCTION myg_nube_privado.documento_modulo(p_documento jsonb,p_modulo text)
RETURNS jsonb LANGUAGE plpgsql IMMUTABLE SET search_path = pg_catalog AS $func$
DECLARE d jsonb := myg_nube_privado.json_minusculas(p_documento); p jsonb; i jsonb; c jsonb; v_id text; v_pid text;
    v_items jsonb; v_lista_items jsonb[]; v_presupuestos jsonb := '{}'::jsonb; v_valor jsonb;
    v_ids text[]; v_recursos jsonb; v_resultado jsonb;
BEGIN
    IF jsonb_typeof(d) IS DISTINCT FROM 'object' OR jsonb_typeof(d->'presupuestos') IS DISTINCT FROM 'array'
       OR nullif(btrim(d->>'id'),'') IS NULL THEN
        RAISE EXCEPTION USING errcode='22023',message='MYG_DOCUMENTO_INVALIDO_PARA_PERMISOS';
    END IF;
    FOR p IN SELECT value FROM jsonb_array_elements(d->'presupuestos') LOOP
        p:=myg_nube_privado.json_minusculas(p);
        v_pid := upper(p->>'id');
        IF nullif(btrim(v_pid),'') IS NULL OR v_presupuestos ? v_pid OR jsonb_typeof(p->'items') IS DISTINCT FROM 'array' THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_DOCUMENTO_IDENTIDADES_INVALIDAS';
        END IF;
        v_items := '{}'::jsonb; v_lista_items := ARRAY[]::jsonb[]; v_ids := ARRAY[]::text[];
        FOR i IN SELECT value FROM jsonb_array_elements(p->'items') LOOP
            i:=myg_nube_privado.json_minusculas(i);
            v_id := upper(i->>'id');
            IF nullif(btrim(v_id),'') IS NULL OR v_id=ANY(v_ids) OR jsonb_typeof(i) IS DISTINCT FROM 'object' THEN
                RAISE EXCEPTION USING errcode='22023',message='MYG_DOCUMENTO_IDENTIDADES_INVALIDAS';
            END IF;
            v_ids := array_append(v_ids,v_id);
            v_valor := myg_nube_privado.datos_modulo(i->'costos',p_modulo);
            IF p_modulo='acu' THEN
                v_valor := jsonb_build_object('datos',v_valor,'unidad',coalesce(i->>'unidad',''),
                    'unidadpropuesta',coalesce(i->>'unidadpropuesta',''),
                    'idanalisisdelphin',coalesce(i->>'idanalisisdelphin',''),
                    'idcatalogodelphin',coalesce(i->>'idcatalogodelphin',''),
                    'fuentecatalogoid',coalesce(i->>'fuentecatalogoid',''),
                    'codigocatalogodelphin',coalesce(i->>'codigocatalogodelphin',''));
            END IF;
            -- Conservar identidades también protege borrados y sustituciones. Una
            -- edición estructural que añada o retire filas exige todos los módulos.
            v_valor := v_valor || jsonb_build_object('idinternodelphin',coalesce(i->>'idinternodelphin',''),
                'idlocalmyg',coalesce(i->>'idlocalmyg',''),'idpropuesta',coalesce(i->>'idpropuesta',''),
                'parentid',coalesce(i->>'parentid',''),'tipopropuesta',coalesce(i->>'tipopropuesta',''));
            v_lista_items := array_append(v_lista_items,v_valor);
        END LOOP;
        SELECT coalesce(jsonb_object_agg(k,v),'{}'::jsonb)
        INTO v_items FROM unnest(v_ids,v_lista_items) AS datos(k,v);
        c := coalesce(nullif(myg_nube_privado.json_minusculas(p->'costos'),'null'::jsonb),'{}'::jsonb);
        v_recursos := CASE WHEN p_modulo='acu' THEN jsonb_build_object(
            'insumos',coalesce(c->'insumos','[]'::jsonb),
            'decimalesprecio',coalesce(c->'decimalesprecio','2'::jsonb),
            'decimalescantidad',coalesce(c->'decimalescantidad','4'::jsonb),
            'configuracioncostodirecto',coalesce(c->'configuracioncostodirecto','null'::jsonb)) ELSE '{}'::jsonb END;
        v_presupuestos := v_presupuestos || jsonb_build_object(v_pid,jsonb_build_object('items',v_items,'recursos',v_recursos));
    END LOOP;
    v_resultado := jsonb_build_object('id',upper(d->>'id'),'presupuestos',v_presupuestos);
    IF p_modulo='acu' THEN
        v_resultado := v_resultado || jsonb_build_object('forma',jsonb_build_object(
            'porrendimientocuadrilla',coalesce(myg_nube_privado.json_minusculas(d->'datos')->'porrendimientocuadrilla','true'::jsonb),
            'porasignacionrecursos',coalesce(myg_nube_privado.json_minusculas(d->'datos')->'porasignacionrecursos','false'::jsonb)));
    END IF;
    RETURN v_resultado;
END $func$;

CREATE OR REPLACE FUNCTION myg_nube_privado.fila_portable(p_tabla jsonb,p_fila jsonb)
RETURNS jsonb LANGUAGE plpgsql IMMUTABLE SET search_path = pg_catalog AS $func$
DECLARE v_resultado jsonb; v_columna text; v_pos integer := 0; v_celda jsonb;
    v_claves text[]:=ARRAY[]::text[]; v_valores jsonb[]:=ARRAY[]::jsonb[];
BEGIN
    IF jsonb_typeof(p_tabla->'columnas') IS DISTINCT FROM 'array' OR jsonb_typeof(p_fila) IS DISTINCT FROM 'array'
       OR coalesce((p_tabla->>'total_columnas')::integer,jsonb_array_length(p_tabla->'columnas'))<>jsonb_array_length(p_fila) THEN
        RAISE EXCEPTION USING errcode='22023',message='MYG_TABLA_PORTABLE_INVALIDA';
    END IF;
    FOR v_columna IN SELECT lower(value#>>'{}') FROM jsonb_array_elements(p_tabla->'columnas') LOOP
        IF v_columna IS NULL OR v_columna=ANY(v_claves) THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_TABLA_COLUMNAS_AMBIGUAS';
        END IF;
        v_celda := myg_nube_privado.json_minusculas(p_fila->coalesce((p_tabla->'indices'->>v_pos)::integer,v_pos)); v_pos := v_pos+1;
        IF jsonb_typeof(v_celda) IS DISTINCT FROM 'object' OR v_celda->>'tipo' IS NULL OR v_celda->>'tipo' NOT IN ('nulo','texto','entero','real','blob') THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_CELDA_PORTABLE_INVALIDA';
        END IF;
        IF v_celda->>'tipo'='nulo' AND coalesce(v_celda->'valor','null'::jsonb)<>'null'::jsonb THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_CELDA_NULA_CON_VALOR';
        END IF;
        IF v_celda->>'tipo'<>'nulo' AND jsonb_typeof(v_celda->'valor') IS DISTINCT FROM 'string' THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_CELDA_VALOR_INVALIDO';
        END IF;
        v_claves:=array_append(v_claves,v_columna);
        v_valores:=array_append(v_valores,jsonb_build_object(
            'tipo',v_celda->>'tipo','valor',CASE WHEN v_celda->>'tipo'='nulo' THEN 'null'::jsonb ELSE v_celda->'valor' END));
    END LOOP;
    SELECT coalesce(jsonb_object_agg(k,v),'{}'::jsonb)
    INTO v_resultado FROM unnest(v_claves,v_valores) AS datos(k,v);
    RETURN v_resultado;
END $func$;

CREATE OR REPLACE FUNCTION myg_nube_privado.elegir_campos(p_fila jsonb,p_campos text[])
RETURNS jsonb LANGUAGE sql IMMUTABLE SET search_path = pg_catalog AS $func$
    SELECT coalesce(jsonb_object_agg(key,value),'{}'::jsonb) FROM jsonb_each(p_fila) WHERE key=ANY(p_campos);
$func$;

CREATE OR REPLACE FUNCTION myg_nube_privado.tablas_modulo(p_paquete jsonb,p_modulo text)
RETURNS jsonb LANGUAGE plpgsql IMMUTABLE SET search_path = pg_catalog AS $func$
DECLARE t jsonb; f jsonb; r jsonb; v_nombre text; v_filas jsonb; v_proyeccion jsonb; v_lista_filas jsonb[];
    v_resultado jsonb := '{}'::jsonb; v_vistos text[] := ARRAY[]::text[];
    v_ids_excel text[] := ARRAY[]::text[]; d jsonb; p jsonb; i jsonb; v_id text; v_json jsonb; v_esquema jsonb; v_campos text[];
BEGIN
    -- Identidades nativas de las partidas que utilizan cantidad Excel. No se
    -- congela la cantidad de las partidas manuales por bloquear la hoja Excel.
    IF p_modulo='metrados_excel' AND EXISTS(
        SELECT 1 FROM jsonb_array_elements(p_paquete->'tablas') x
        WHERE lower(myg_nube_privado.json_minusculas(x)->>'nombre') IN
            ('costo_unitario','analisis_costo','metrado','metrado_bim')
    ) THEN
    FOR d IN SELECT p_paquete->'documento' UNION ALL SELECT value FROM jsonb_array_elements(coalesce(p_paquete->'documentos','[]'::jsonb)) LOOP
        d:=myg_nube_privado.json_minusculas(d);
        FOR p IN SELECT value FROM jsonb_array_elements(d->'presupuestos') LOOP
            p:=myg_nube_privado.json_minusculas(p);
            FOR i IN SELECT value FROM jsonb_array_elements(p->'items') LOOP
                i:=myg_nube_privado.json_minusculas(i);
                v_json:=myg_nube_privado.json_minusculas(i->'costos');
                IF lower(coalesce(v_json->>'fuentemetrado','')) IN ('excel','3') THEN
                    v_id := coalesce(nullif(i->>'idinternodelphin',''),i->>'id');
                    IF length(v_id)>12 OR upper(v_id) LIKE 'MYG-%' THEN
                        v_id := upper(substr(encode(sha256(convert_to(v_id,'UTF8')),'hex'),1,12));
                    END IF;
                    v_ids_excel := array_append(v_ids_excel,v_id);
                END IF;
            END LOOP;
        END LOOP;
    END LOOP;
    END IF;
    IF jsonb_typeof(p_paquete->'tablas') IS DISTINCT FROM 'array' THEN
        RAISE EXCEPTION USING errcode='22023',message='MYG_TABLAS_REQUERIDAS_PARA_PERMISOS';
    END IF;
    FOR t IN SELECT value FROM jsonb_array_elements(p_paquete->'tablas') LOOP
        t:=myg_nube_privado.json_minusculas(t);
        v_nombre := lower(t->>'nombre');
        IF nullif(btrim(v_nombre),'') IS NULL OR v_nombre=ANY(v_vistos) OR jsonb_typeof(t->'filas') IS DISTINCT FROM 'array' THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_TABLAS_AMBIGUAS';
        END IF;
        v_vistos := array_append(v_vistos,v_nombre); v_lista_filas := ARRAY[]::jsonb[];
        IF jsonb_typeof(t->'columnas') IS DISTINCT FROM 'array'
           OR EXISTS(SELECT 1 FROM jsonb_array_elements(t->'columnas') WHERE jsonb_typeof(value)<>'string')
           OR (SELECT count(*)<>count(DISTINCT lower(value#>>'{}')) FROM jsonb_array_elements(t->'columnas')) THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_TABLA_COLUMNAS_AMBIGUAS';
        END IF;
        v_campos:=NULL; -- NULL conserva todas las columnas de una tabla desconocida.
        IF v_nombre='myg_proyecto' THEN v_campos:=ARRAY['id','json_documento'];
        ELSIF v_nombre='partida_presupuesto' THEN
            v_campos:=ARRAY['presupuesto_id','id','id_local','padre_id','unidad','precio_directo','cantidad','json_datos'];
        ELSIF v_nombre='myg_presupuesto' THEN
            v_campos:=CASE WHEN p_modulo='acu' THEN ARRAY['id','proyecto_id','json_datos'] ELSE ARRAY['id','proyecto_id'] END;
        ELSIF v_nombre IN ('costo_unitario','analisis_costo') THEN
            v_campos:=CASE p_modulo
                WHEN 'acu' THEN ARRAY['id_costounitario','id_analisiscosto','id_presupuesto','id_costopadre','id_titulo','id_unidad','costo_unitario','productividad','tiempo_productividad','id_unidadtiempo','magnitud_unidadtiempo','tiene_composicion','tipo_rendimiento','valor_asignacion','tipo_calculo_acu','editor_costo']
                WHEN 'especificaciones' THEN ARRAY['id_costounitario','id_analisiscosto','id_presupuesto','id_costopadre','id_titulo','especificaciones','especificaciones_texto','archivo_especificaciones','nombre_archivoespecificaciones']
                ELSE ARRAY['id_costounitario','id_analisiscosto','id_presupuesto','id_costopadre','id_titulo','archivo_metrado','campo_metrado','editor_metrado','cantidad','cantidad_metrado'] END;
        ELSIF v_nombre='proyecto' THEN
            v_campos:=CASE WHEN p_modulo='acu' THEN ARRAY['id_proyecto','acu_mode','decimales_cantidad','decimales_costo','exclude_igv_tipocosto'] ELSE ARRAY[]::text[] END;
        ELSIF v_nombre IN ('composicion_costounitario','composicion_analisiscosto') THEN
            IF p_modulo='especificaciones' THEN
                v_campos:=ARRAY['id_composicion','id_subtotal','id_costoauxiliar','id_listaprecio','especificaciones','especificaciones_texto','archivo_especificaciones','nombre_archivoespecificaciones'];
            ELSIF p_modulo='metrados_excel' THEN v_campos:=ARRAY[]::text[]; END IF;
        ELSIF v_nombre IN ('subtotal_costounitario','subtotal_analisiscosto','insumo_presupuesto','recurso_presupuesto','producto','lista_precio','tipo_costo','unidad') THEN
            IF p_modulo<>'acu' THEN v_campos:=ARRAY[]::text[]; END IF;
        ELSIF v_nombre IN ('metrado','metrado_bim') THEN
            IF p_modulo<>'metrados_excel' OR cardinality(v_ids_excel)=0 THEN v_campos:=ARRAY[]::text[]; END IF;
        ELSIF v_nombre IN ('infraestructura','moneda','pais_info','presupuesto','titulo','titulo_bim',
            'programacion_costo','programacion_metrado','dependencia','dependencianew','dependencia_costo','dependencia_metrado',
            'dependencia_tarea','linea_base','calendario','responsable_obra','presupuesto_val','propietario','portafolio',
            'departamento','provincia','distrito','localidad','clase','subclase','marca','indice','indice_precio','region_precio','responsable') THEN
            v_campos:=ARRAY[]::text[];
        END IF;
        IF cardinality(v_campos)=0 THEN CONTINUE; END IF;
        SELECT jsonb_build_object('columnas',coalesce(jsonb_agg(lower(value#>>'{}') ORDER BY ord),'[]'::jsonb),
            'indices',coalesce(jsonb_agg(ord-1 ORDER BY ord),'[]'::jsonb),'total_columnas',jsonb_array_length(t->'columnas'))
        INTO v_esquema FROM jsonb_array_elements(t->'columnas') WITH ORDINALITY x(value,ord)
        WHERE v_campos IS NULL OR lower(value#>>'{}')=ANY(v_campos);
        FOR f IN SELECT value FROM jsonb_array_elements(t->'filas') LOOP
            r := myg_nube_privado.fila_portable(v_esquema,f); v_proyeccion := NULL;
            IF v_nombre='myg_proyecto' THEN
                IF r#>>'{json_documento,tipo}' IS DISTINCT FROM 'texto' THEN
                    RAISE EXCEPTION USING errcode='22023',message='MYG_JSON_EMBEBIDO_INVALIDO';
                END IF;
                v_json := myg_nube_privado.json_minusculas((r#>>'{json_documento,valor}')::jsonb);
                v_proyeccion := jsonb_build_object('id_fila',r->'id','documento',myg_nube_privado.documento_modulo(v_json,p_modulo));
            ELSIF v_nombre='partida_presupuesto' THEN
                IF r#>>'{json_datos,tipo}' IS DISTINCT FROM 'texto' THEN
                    RAISE EXCEPTION USING errcode='22023',message='MYG_JSON_EMBEBIDO_INVALIDO';
                END IF;
                v_json := myg_nube_privado.json_minusculas((r#>>'{json_datos,valor}')::jsonb);
                v_json := jsonb_set(v_json,'{costos}',coalesce(myg_nube_privado.json_minusculas(v_json->'costos'),'{}'::jsonb));
                v_proyeccion := jsonb_build_object('presupuesto',r->'presupuesto_id','id',r->'id',
                    'identidad',myg_nube_privado.elegir_campos(v_json,ARRAY['id','idlocalmyg','idpropuesta','idinternodelphin','parentid','tipopropuesta']),
                    'id_local_fila',r->'id_local','padre_fila',r->'padre_id',
                    'datos',myg_nube_privado.datos_modulo(v_json->'costos',p_modulo));
                IF p_modulo='acu' THEN
                    v_proyeccion := v_proyeccion || myg_nube_privado.elegir_campos(r,ARRAY['unidad','precio_directo']);
                ELSIF p_modulo='metrados_excel' AND lower(coalesce(v_json#>>'{costos,fuentemetrado}','')) IN ('excel','3') THEN
                    v_proyeccion := v_proyeccion || myg_nube_privado.elegir_campos(r,ARRAY['cantidad']);
                END IF;
            ELSIF v_nombre='myg_presupuesto' THEN
                v_proyeccion := jsonb_build_object('id',r->'id','proyecto',r->'proyecto_id');
                IF p_modulo='acu' THEN
                    IF r#>>'{json_datos,tipo}' IS DISTINCT FROM 'texto' THEN
                        RAISE EXCEPTION USING errcode='22023',message='MYG_JSON_EMBEBIDO_INVALIDO';
                    END IF;
                    v_json := myg_nube_privado.json_minusculas((r#>>'{json_datos,valor}')::jsonb);
                    v_proyeccion := jsonb_build_object('id',r->'id','proyecto',r->'proyecto_id',
                        'recursos',myg_nube_privado.elegir_campos(v_json,ARRAY['insumos','decimalesprecio','decimalescantidad','configuracioncostodirecto']));
                END IF;
            ELSIF v_nombre IN ('costo_unitario','analisis_costo') THEN
                IF p_modulo='acu' THEN
                    v_proyeccion := myg_nube_privado.elegir_campos(r,ARRAY[
                        'id_costounitario','id_analisiscosto','id_presupuesto','id_costopadre','id_titulo','id_unidad','costo_unitario','productividad',
                        'tiempo_productividad','id_unidadtiempo','magnitud_unidadtiempo','tiene_composicion',
                        'tipo_rendimiento','valor_asignacion','tipo_calculo_acu','editor_costo']);
                ELSIF p_modulo='especificaciones' THEN
                    v_proyeccion := myg_nube_privado.elegir_campos(r,ARRAY['id_costounitario','id_analisiscosto','id_presupuesto','id_costopadre','id_titulo',
                        'especificaciones','especificaciones_texto','archivo_especificaciones','nombre_archivoespecificaciones']);
                ELSE
                    v_proyeccion := myg_nube_privado.elegir_campos(r,ARRAY['id_costounitario','id_analisiscosto','id_presupuesto','id_costopadre','id_titulo',
                        'archivo_metrado','campo_metrado','editor_metrado']);
                    IF r#>>'{id_costounitario,valor}'=ANY(v_ids_excel) THEN
                        v_proyeccion := v_proyeccion || myg_nube_privado.elegir_campos(r,ARRAY['cantidad','cantidad_metrado']);
                    END IF;
                END IF;
            ELSIF v_nombre='proyecto' THEN
                IF p_modulo='acu' THEN
                    v_proyeccion := myg_nube_privado.elegir_campos(r,ARRAY['id_proyecto','acu_mode',
                        'decimales_cantidad','decimales_costo','exclude_igv_tipocosto']);
                END IF;
            ELSIF v_nombre IN ('composicion_costounitario','composicion_analisiscosto') THEN
                IF p_modulo='acu' THEN
                    v_proyeccion := r-ARRAY['especificaciones','especificaciones_texto','archivo_especificaciones','nombre_archivoespecificaciones'];
                ELSIF p_modulo='especificaciones' THEN
                    v_proyeccion := myg_nube_privado.elegir_campos(r,ARRAY['id_composicion','id_subtotal','id_costoauxiliar','id_listaprecio','especificaciones',
                        'especificaciones_texto','archivo_especificaciones','nombre_archivoespecificaciones']);
                END IF;
            ELSIF v_nombre IN ('subtotal_costounitario','subtotal_analisiscosto','insumo_presupuesto','recurso_presupuesto','producto','lista_precio','tipo_costo','unidad') THEN
                IF p_modulo='acu' THEN v_proyeccion := r; END IF;
            ELSIF v_nombre IN ('metrado','metrado_bim') THEN
                IF p_modulo='metrados_excel' AND r#>>'{id_costounitario,valor}'=ANY(v_ids_excel) THEN v_proyeccion:=r; END IF;
            ELSIF v_nombre IN ('infraestructura','moneda','pais_info','presupuesto','titulo','titulo_bim',
                'programacion_costo','programacion_metrado','dependencia','dependencianew','dependencia_costo','dependencia_metrado',
                'dependencia_tarea','linea_base','calendario','responsable_obra','presupuesto_val','infraestructura','propietario','portafolio',
                'departamento','provincia','distrito','localidad','clase','subclase','marca','indice','indice_precio','region_precio','responsable') THEN
                NULL; -- Datos fuera de los tres módulos; totales derivados del documento.
            ELSE
                -- Catálogos compuestos y tablas sin una proyección demostrada:
                -- requieren máscara completa para modificarse.
                v_proyeccion := r;
            END IF;
            IF v_proyeccion IS NOT NULL THEN v_lista_filas := array_append(v_lista_filas,v_proyeccion); END IF;
        END LOOP;
        IF cardinality(v_lista_filas)>0 THEN
            SELECT jsonb_agg(value ORDER BY value::text) INTO v_filas FROM unnest(v_lista_filas) x(value);
            v_resultado := v_resultado || jsonb_build_object(v_nombre,v_filas);
        END IF;
    END LOOP;
    RETURN v_resultado;
END $func$;

CREATE OR REPLACE FUNCTION myg_nube_privado.paquete_modulo(p_paquete jsonb,p_modulo text)
RETURNS jsonb LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $func$
DECLARE v_documentos jsonb := '{}'::jsonb; d jsonb; v_id text; v_resultado jsonb;
    v_principal jsonb; v_doc jsonb;
BEGIN
    IF p_paquete->>'formato' IS DISTINCT FROM 'MYG_COLABORACION' OR p_paquete->'version' IS DISTINCT FROM '1'::jsonb
       OR p_paquete->>'alcance' IS NULL OR p_paquete->>'alcance' NOT IN ('obra','base') OR jsonb_typeof(p_paquete->'documentos') IS DISTINCT FROM 'array'
       OR jsonb_typeof(p_paquete->'recursos') IS DISTINCT FROM 'array' THEN
        RAISE EXCEPTION USING errcode='22023',message='MYG_PAQUETE_NO_COMPATIBLE_CON_PERMISOS';
    END IF;
    v_principal:=myg_nube_privado.documento_modulo(p_paquete->'documento',p_modulo);
    FOR d IN SELECT value FROM jsonb_array_elements(p_paquete->'documentos') LOOP
        IF d IS NOT DISTINCT FROM p_paquete->'documento' THEN
            v_doc:=v_principal;
        ELSE
            v_doc:=myg_nube_privado.documento_modulo(d,p_modulo);
        END IF;
        v_id:=v_doc->>'id';
        IF nullif(v_id,'') IS NULL OR v_documentos ? v_id THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_DOCUMENTOS_AMBIGUOS';
        END IF;
        v_documentos:=v_documentos || jsonb_build_object(v_id,v_doc);
    END LOOP;
    v_resultado:=jsonb_build_object('alcance',p_paquete->>'alcance','documento',v_principal,
        'documentos',v_documentos,'tablas',myg_nube_privado.tablas_modulo(p_paquete,p_modulo));
    -- Los adjuntos pueden aparecer también dentro de JSON nativo o RTF. Sin
    -- interpretar todos esos formatos, comparar el manifiesto completo evita
    -- que una referencia Unicode/escapada eluda la restricción. Su edición,
    -- incluso añadir o retirar archivos, requiere los tres módulos habilitados.
    RETURN v_resultado || jsonb_build_object('recursos',p_paquete->'recursos');
END $func$;

CREATE OR REPLACE FUNCTION myg_nube_privado.exigir_modulos(p_anterior jsonb,p_nuevo jsonb,p_permisos jsonb)
RETURNS void LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $func$
DECLARE v_modulo text; v_antes jsonb; v_despues jsonb;
    v_lado integer; v_tablas jsonb; v_tabla jsonb; v_meta jsonb; v_nombre text;
    v_mapa jsonb; v_mapa_antes jsonb; v_mapa_despues jsonb;
    v_tablas_antes jsonb; v_tablas_despues jsonb;
    v_documentos_antes jsonb; v_documentos_despues jsonb; v_documentos_iguales boolean;
BEGIN
    IF p_permisos='{"acu":true,"especificaciones":true,"metrados_excel":true}'::jsonb THEN RETURN; END IF;
    IF jsonb_typeof(p_permisos) IS DISTINCT FROM 'object' OR (SELECT count(*) FROM jsonb_object_keys(p_permisos))<>3
       OR NOT p_permisos ?& ARRAY['acu','especificaciones','metrados_excel']
       OR EXISTS(SELECT 1 FROM jsonb_each(p_permisos) WHERE jsonb_typeof(value)<>'boolean') THEN
        RAISE EXCEPTION USING errcode='42501',message='MYG_PERMISOS_MODULOS_INVALIDOS';
    END IF;
    IF NOT coalesce(p_anterior ?& ARRAY['formato','version','alcance','documento','documentos','tablas','recursos'],false)
       OR NOT coalesce(p_nuevo ?& ARRAY['formato','version','alcance','documento','documentos','tablas','recursos'],false) THEN
        RAISE EXCEPTION USING errcode='22023',message='MYG_ENVOLTORIO_NO_CANONICO';
    END IF;
    v_antes:=myg_nube_privado.json_minusculas(p_anterior);
    v_despues:=myg_nube_privado.json_minusculas(p_nuevo);
    FOR v_lado IN 0..1 LOOP
        v_meta:=CASE WHEN v_lado=0 THEN v_antes ELSE v_despues END;
        IF v_meta->>'formato' IS DISTINCT FROM 'MYG_COLABORACION' OR v_meta->'version' IS DISTINCT FROM '1'::jsonb
           OR v_meta->>'alcance' IS NULL OR v_meta->>'alcance' NOT IN ('obra','base')
           OR jsonb_typeof(v_meta->'documento') IS DISTINCT FROM 'object'
           OR jsonb_typeof(v_meta->'documentos') IS DISTINCT FROM 'array'
           OR jsonb_typeof(v_meta->'recursos') IS DISTINCT FROM 'array' THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_PAQUETE_NO_COMPATIBLE_CON_PERMISOS';
        END IF;
    END LOOP;
    IF v_antes->'alcance' IS DISTINCT FROM v_despues->'alcance'
       OR v_antes->'recursos' IS DISTINCT FROM v_despues->'recursos' THEN
        RAISE EXCEPTION USING errcode='42501',message='MYG_ADJUNTOS_O_ALCANCE_PROTEGIDOS';
    END IF;
    -- Nombre, fecha de edición y selección de presupuesto son metadatos de
    -- navegación. Si todo lo demás es idéntico, no es necesario reconstruir
    -- tres veces las hojas y los análisis completos de una obra grande.
    SELECT coalesce(jsonb_agg(value-ARRAY['Nombre','ModificadoUtc','PresupuestoActivoId'] ORDER BY ord),'[]'::jsonb)
    INTO v_documentos_antes FROM jsonb_array_elements(v_antes->'documentos') WITH ORDINALITY d(value,ord);
    SELECT coalesce(jsonb_agg(value-ARRAY['Nombre','ModificadoUtc','PresupuestoActivoId'] ORDER BY ord),'[]'::jsonb)
    INTO v_documentos_despues FROM jsonb_array_elements(v_despues->'documentos') WITH ORDINALITY d(value,ord);
    v_documentos_iguales :=
        ((v_antes->'documento')-ARRAY['Nombre','ModificadoUtc','PresupuestoActivoId']) IS NOT DISTINCT FROM
        ((v_despues->'documento')-ARRAY['Nombre','ModificadoUtc','PresupuestoActivoId'])
        AND v_documentos_antes IS NOT DISTINCT FROM v_documentos_despues;
    -- Una tabla idéntica no puede introducir cambios en un módulo. Validar los
    -- encabezados de TODAS las tablas antes de omitir las que no cambiaron evita
    -- tanto las copias repetidas de catálogos grandes como el sombreado por nombres
    -- duplicados. Las tablas añadidas, retiradas o modificadas sí se proyectan.
    FOR v_lado IN 0..1 LOOP
        v_tablas := CASE WHEN v_lado=0 THEN v_antes->'tablas' ELSE v_despues->'tablas' END;
        IF jsonb_typeof(v_tablas) IS DISTINCT FROM 'array' THEN
            RAISE EXCEPTION USING errcode='22023',message='MYG_TABLAS_REQUERIDAS_PARA_PERMISOS';
        END IF;
        v_mapa := '{}'::jsonb;
        FOR v_tabla IN SELECT value FROM jsonb_array_elements(v_tablas) LOOP
            v_meta := myg_nube_privado.json_minusculas(v_tabla);
            v_nombre := lower(v_meta->>'nombre');
            IF nullif(btrim(v_nombre),'') IS NULL OR v_mapa ? v_nombre
               OR jsonb_typeof(v_meta->'filas') IS DISTINCT FROM 'array'
               OR jsonb_typeof(v_meta->'columnas') IS DISTINCT FROM 'array' THEN
                RAISE EXCEPTION USING errcode='22023',message='MYG_TABLAS_AMBIGUAS';
            END IF;
            IF EXISTS(SELECT 1 FROM jsonb_array_elements(v_meta->'columnas') WHERE jsonb_typeof(value)<>'string')
               OR (SELECT count(*)<>count(DISTINCT lower(value#>>'{}')) FROM jsonb_array_elements(v_meta->'columnas')) THEN
                RAISE EXCEPTION USING errcode='22023',message='MYG_TABLA_COLUMNAS_AMBIGUAS';
            END IF;
            v_mapa := v_mapa || jsonb_build_object(v_nombre,v_tabla);
        END LOOP;
        IF v_lado=0 THEN v_mapa_antes:=v_mapa; ELSE v_mapa_despues:=v_mapa; END IF;
    END LOOP;
    SELECT coalesce(jsonb_agg(a.value ORDER BY a.key) FILTER(WHERE a.key IS NOT NULL),'[]'::jsonb),
           coalesce(jsonb_agg(d.value ORDER BY d.key) FILTER(WHERE d.key IS NOT NULL),'[]'::jsonb)
    INTO v_tablas_antes,v_tablas_despues
    FROM jsonb_each(v_mapa_antes) a FULL JOIN jsonb_each(v_mapa_despues) d ON a.key=d.key
    WHERE a.value IS DISTINCT FROM d.value;
    v_antes := jsonb_set(v_antes,'{tablas}',v_tablas_antes);
    v_despues := jsonb_set(v_despues,'{tablas}',v_tablas_despues);
    FOREACH v_modulo IN ARRAY ARRAY['acu','especificaciones','metrados_excel'] LOOP
        IF NOT (p_permisos->>v_modulo)::boolean THEN
            IF v_documentos_iguales THEN
                IF myg_nube_privado.tablas_modulo(v_antes,v_modulo) IS DISTINCT FROM myg_nube_privado.tablas_modulo(v_despues,v_modulo) THEN
                    RAISE EXCEPTION USING errcode='42501',message='MYG_MODULO_SOLO_LECTURA_'||upper(v_modulo);
                END IF;
            ELSIF myg_nube_privado.paquete_modulo(v_antes,v_modulo) IS DISTINCT FROM myg_nube_privado.paquete_modulo(v_despues,v_modulo) THEN
                RAISE EXCEPTION USING errcode='42501',message='MYG_MODULO_SOLO_LECTURA_'||upper(v_modulo);
            END IF;
        END IF;
    END LOOP;
END $func$;

-- Aislar todos los auxiliares del acceso RPC y de la ejecución directa.
REVOKE ALL ON FUNCTION myg_nube_privado.json_minusculas(jsonb) FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION myg_nube_privado.datos_modulo(jsonb,text) FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION myg_nube_privado.documento_modulo(jsonb,text) FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION myg_nube_privado.fila_portable(jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION myg_nube_privado.elegir_campos(jsonb,text[]) FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION myg_nube_privado.tablas_modulo(jsonb,text) FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION myg_nube_privado.paquete_modulo(jsonb,text) FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;

-- Conserva el contrato, el control de revisión y la idempotencia existentes.
CREATE OR REPLACE FUNCTION public.myg_nube_guardar(p_id uuid, p_operacion uuid, p_revision bigint, p_contenido jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'myg_nube_privado'
 -- PostgREST aplica este límite al RPC, sin ampliar el de authenticated ni el
 -- del resto del servidor. Los paquetes grandes ya tienen un máximo de 32 MiB.
 SET statement_timeout TO '60s'
AS $function$
declare
    v_usuario uuid := myg_nube_privado.identidad(); v_proyecto public.myg_nube_proyectos%rowtype;
    v_rol text; v_permisos jsonb; v_anterior public.myg_nube_operaciones%rowtype; v_solicitud jsonb; v_respuesta jsonb;
begin
    if p_operacion is null or p_operacion = '00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision < 1 then
        raise exception using errcode = '22023', message = 'MYG_OPERACION_INVALIDA';
    end if;
    perform myg_nube_privado.validar_contenido(p_contenido);
    select * into v_proyecto from public.myg_nube_proyectos where id = p_id for update;
    select rol, permisos_modulos into v_rol, v_permisos from public.myg_nube_miembros where proyecto_id = p_id and usuario_id = v_usuario;
    -- Revisar permiso actual ANTES de devolver una respuesta histórica/idempotente.
    if v_proyecto.id is null or v_rol is null or v_rol not in ('propietario', 'administrador', 'editor') then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-op:' || v_usuario::text || ':' || p_operacion::text, 0));
    v_solicitud := jsonb_build_object('revision', p_revision, 'contenido', p_contenido);
    select * into v_anterior from public.myg_nube_operaciones where usuario_id = v_usuario and operacion_id = p_operacion;
    if found then
        if v_anterior.proyecto_id <> p_id or v_anterior.solicitud <> v_solicitud then
            raise exception using errcode = '22023', message = 'MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        return v_anterior.respuesta;
    end if;
    if v_proyecto.revision <> p_revision then
        v_respuesta := jsonb_build_object('estado', 'conflicto', 'revision', v_proyecto.revision,
            'contenido', v_proyecto.contenido, 'operacion_id', p_operacion);
    else
        perform myg_nube_privado.exigir_modulos(v_proyecto.contenido,p_contenido,v_permisos);
        update public.myg_nube_proyectos set contenido = p_contenido, revision = revision + 1,
            actualizado_en = clock_timestamp() where id = p_id returning * into v_proyecto;
        insert into public.myg_nube_historial(proyecto_id, revision, usuario_id, operacion_id, contenido)
        values (p_id, v_proyecto.revision, v_usuario, p_operacion, p_contenido);
        v_respuesta := jsonb_build_object('estado', 'aplicada', 'revision', v_proyecto.revision,
            'contenido', v_proyecto.contenido, 'operacion_id', p_operacion);
    end if;
    insert into public.myg_nube_operaciones(usuario_id, operacion_id, proyecto_id, solicitud, respuesta)
    values (v_usuario, p_operacion, p_id, v_solicitud, v_respuesta);
    return v_respuesta;
end;
$function$
;
REVOKE ALL ON FUNCTION public.myg_nube_guardar(uuid,uuid,bigint,jsonb) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.myg_nube_guardar(uuid,uuid,bigint,jsonb) TO authenticated,service_role;


-- La notificación se entrega al confirmar la transacción. PostgREST recarga
-- sus firmas sin necesidad de reiniciar el proyecto ni recrear sus tablas.
notify pgrst, 'reload schema';

commit;
