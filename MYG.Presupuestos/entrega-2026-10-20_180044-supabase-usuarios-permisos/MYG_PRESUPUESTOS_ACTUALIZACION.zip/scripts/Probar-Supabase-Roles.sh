#!/usr/bin/env bash
# Ejecuta las pruebas exclusivamente en un PostgreSQL Docker desechable.
set -euo pipefail
repo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
command -v docker >/dev/null || { echo 'Se requiere Docker.' >&2; exit 1; }
container_name="myg-roles-pruebas-$(date +%s)-$$"
container_id=''
fixtures_dir=$(mktemp -d /tmp/myg-paquetes-pruebas-XXXXXX)
command -v dotnet >/dev/null || { echo 'Se requiere .NET SDK 10 en PATH.' >&2; rm -rf -- "$fixtures_dir"; exit 1; }
cleanup() {
  if [[ -n "$container_id" ]]; then docker rm -f "$container_id" >/dev/null || true; fi
  rm -rf -- "$fixtures_dir"
}
trap cleanup EXIT
dotnet run --project "$repo_dir/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" -c Release -- "$fixtures_dir"
# Sin puertos publicados ni red: trust se limita a esta base temporal aislada.
container_id=$(docker run --detach --network none --name "$container_name" \
  -e POSTGRES_HOST_AUTH_METHOD=trust postgres:17-alpine)
ready=0
for ((attempt=0;attempt<60;attempt++)); do
  if docker exec "$container_id" pg_isready -U postgres >/dev/null 2>&1; then ready=1; break; fi
  sleep 1
done
if [[ "$ready" != 1 ]]; then
  docker logs "$container_id" >&2
  echo 'PostgreSQL no inició dentro del límite.' >&2
  exit 1
fi
docker exec "$container_id" mkdir -p /pruebas/migraciones /pruebas/pruebas /pruebas/paquetes
docker cp "$repo_dir/supabase/migraciones/20261020_usuarios_myg_roles.sql" "$container_id:/pruebas/migraciones/"
docker cp "$repo_dir/supabase/pruebas/usuarios_myg_roles.sql" "$container_id:/pruebas/pruebas/"
for fixture_file in "$fixtures_dir"/*.json; do
  docker cp "$fixture_file" "$container_id:/pruebas/paquetes/"
done
docker exec "$container_id" chmod -R a+rX /pruebas
docker exec "$container_id" psql --no-psqlrc -U postgres -v ON_ERROR_STOP=1 \
  -v MYG_PRUEBAS_DESECHABLES=1 -f /pruebas/pruebas/usuarios_myg_roles.sql
