# Conexión automática de Nube MYG — 21/10/2026

## Resultado para sus usuarios

El instalador incluye la conexión pública de su nube. El usuario instala MYG,
ingresa con su cuenta MYG y abre Nube MYG. La aplicación se conecta y muestra
sus proyectos sin pedirle nombre de conexión, URL o clave publicable.
Se conservan la verificación de licencia, la vinculación y los permisos del servidor.

La opción técnica pasa a llamarse **Opciones avanzadas**, para soporte. No es un
nuevo permiso de administrador ni sustituye los controles del servidor.

## Cómo se elige la conexión

1. Si el perfil de Windows ya tiene `%LOCALAPPDATA%\MYG\Nube\config.json`, se
   respeta esa conexión. No se cambia el destino de obras existentes.
2. Si no tiene configuración local, utiliza `nube-myg.json` junto al ejecutable.
3. Si no existe ninguna, informa que necesita el instalador actualizado o revisar
   Opciones avanzadas. Una configuración dañada permite abrir esas opciones,
   pero no provoca un cambio automático a otro servidor.

La carga no reescribe archivos. Guardar explícitamente en Opciones avanzadas
continúa actualizando sólo la configuración local. Se mantienen archivos con
BOM de UTF-8, UTF-16 y UTF-32, además del formato anterior sin BOM.

## Archivos de esta entrega

Las rutas parten de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.
Cada REEMPLAZAR contiene el archivo completo.

| N.º | Ruta | Acción | Función |
|---|---|---|---|
| 1 | `MYG.Colaboracion/ConfiguracionServicioNube.cs` | CREAR | Carga, validación y guardado de configuración local/distribuida. |
| 2 | `MYG.Desktop/NubeConfiguracion.cs` | REEMPLAZAR | Utiliza la conexión incluida y conserva las opciones avanzadas. |
| 3 | `MYG.Desktop/InicioNube.cs` | REEMPLAZAR | Mantiene el ingreso MYG y permite recuperar configuración dañada. |
| 4 | `MYG.Desktop/NubeForm.cs` | REEMPLAZAR | Presentación de Opciones avanzadas y mensajes de conexión. |
| 5 | `MYG.PruebasNube/ConfiguracionNubeCheck.cs` | CREAR | 65 comprobaciones de configuración y privacidad. |
| 6 | `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Incorpora el grupo de pruebas nuevo. |
| 7 | `scripts/Publicar.ps1` | REEMPLAZAR | Incluye automáticamente la conexión guardada del autor. |
| 8 | `scripts/Generar-Instalador.ps1` | REEMPLAZAR | Verifica que el instalador incluya una conexión válida. |
| 9 | `scripts/Preparar-Nube/Preparar-Nube.csproj` | CREAR | Proyecto auxiliar de preparación; no se añade a la solución. |
| 10 | `scripts/Preparar-Nube/Program.cs` | CREAR | Exporta únicamente los tres campos públicos. |
| 11 | `scripts/pruebas/Probar-PrepararNube.py` | CREAR | 21 pruebas de la herramienta de exportación. |
| 12 | `ACTUALIZACION_NUBE_AUTOMATICA.md` | CREAR | Estas instrucciones y explicación de capacidad. |

Se incluyen sólo los archivos nuevos o cambiados en esta entrega. No hay
eliminaciones, migraciones SQL ni modificaciones de datos reales de Supabase.
Se conservan las mejoras anteriores de permisos, gris, puntero y bloqueo de clics.

## Instalación en su proyecto

1. Cierre MYG y respalde o confirme sus modificaciones locales.
2. Extraiga el ZIP en una carpeta temporal y copie su contenido dentro de
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, combinando carpetas y reemplazando
   únicamente los archivos de la tabla.
3. Abra la solución en Visual Studio compatible con .NET 10 y compile en Release.
   Los archivos nuevos de Colaboración y pruebas se incluyen automáticamente.
4. Para distribuir a otros usuarios, genere el instalador nuevo siguiendo el
   apartado siguiente. Compilar el código solamente no cambia instaladores viejos.

## Generar el instalador con su conexión actual

En SU equipo ya debe estar guardada la conexión que funciona en Nube MYG.
No necesita enviarla por chat ni escribirla en el código.

Desde la carpeta del proyecto, en PowerShell de Windows:

```powershell
.\scripts\Generar-Instalador.ps1 -Version 1.0.1
```

Use el número de versión que corresponda a su siguiente entrega. Se necesitan
el SDK de .NET 10, Inno Setup y las referencias de Revit 2027 que ya requería
el proceso de publicación. Si Revit está en otra carpeta, indique `-RevitInstallDir`.

El script lee `%LOCALAPPDATA%\MYG\Nube\config.json`, valida la configuración
y genera `dist\MYG\nube-myg.json`. Ese archivo entra en el instalador mediante
la receta existente; no hay que cambiar manualmente el archivo `.iss`.
Sólo exporta `Nombre`, `Url` y `ClavePublicable`; no copia usuarios, contraseñas,
sesiones, tokens ni campos adicionales del archivo original.

Si el archivo del autor está en otra ruta:

```powershell
.\scripts\Generar-Instalador.ps1 -Version 1.0.1 -ConfiguracionNube "D:\ConfiguracionMYG\config.json"
```

La preparación rechaza claves `sb_secret_` o `service_role`. Si falta el archivo
o es inválido, la generación se detiene y explica cómo corregirlo. No distribuya
una publicación que haya terminado con error. La opción `-OmitirPublicacion`
también verifica y normaliza la conexión ya preparada antes de empaquetarla.

El ZIP de actualización no lleva una conexión real ni claves del autor. El
instalador que genere en su equipo incorporará la URL y la clave pública correctas.

## Compilación y validación

Base: `bimchimbote-droid/MYG.Presupuestos`, rama `main`, commit
`5eff104c9b208c40857bdbecf42298605e9e1d93`, conservando las entregas anteriores.
Preparación en rama local `work`. Tecnologías: C#, .NET SDK 10.0.100, WinForms/WPF,
PowerShell e Inno Setup para publicación Windows. Python 3 sólo es necesario
si desea repetir las pruebas auxiliares de exportación.

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet build scripts/Preparar-Nube/Preparar-Nube.csproj -c Release
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
python scripts/pruebas/Probar-PrepararNube.py --no-build
```

Resultados obtenidos en Linux:

- Solución completa y herramienta de preparación: 0 errores y 0 advertencias.
- Suite Nube: 27 grupos, 787 comprobaciones de contrato HTTP y 65 comprobaciones
  de configuración aprobadas, además de las integraciones indicadas por la suite.
- Herramienta de preparación: 21 comprobaciones aprobadas de exportación, BOM,
  privacidad, errores y actualización del mismo archivo; sin red.
- `git diff --check`: aprobado.
- No se ejecutaron el instalador de Windows, PowerShell, la interfaz ni Revit.
  Tampoco se conectaron estas pruebas al Supabase real ni se cambiaron planes.

Verificación manual antes de distribuir:

1. Genere el instalador y compruebe que `dist\MYG\nube-myg.json` contiene sólo
   los tres campos públicos de su conexión actual.
2. Instale en un perfil nuevo de Windows y abra Nube MYG después de iniciar
   sesión: debe conectar sin pedir los tres campos técnicos.
3. Pruebe dos cuentas MYG: cada una debe ver únicamente sus proyectos y los
   compartidos con ella, conservando sus permisos.
4. En un perfil que ya tenga configuración, compruebe que conserva la conexión
   y puede abrir sus obras previas.
5. Con un archivo sintético inválido en un perfil de prueba, compruebe que se
   puede abrir Opciones avanzadas y que no cambia de servidor por sí solo.

## Plan de pago y capacidad de almacenamiento

Actualizar el plan de la organización conservando el mismo proyecto Supabase
mantiene los datos y la conexión. No necesita crear otra base de datos ni volver
a configurar a sus usuarios. Mudarse a otro proyecto o proveedor sí requiere
planificar migración y actualización de conexión por separado.

Un proyecto Supabase compartido por múltiples usuarios es una arquitectura
habitual. Comparten capacidad y recursos, pero los permisos separan qué obras
puede ver o modificar cada uno. No es necesario tener un servidor por usuario.

Hay que medir por separado:

- Base de datos PostgreSQL: obras, miembros, permisos, revisiones y metadatos.
- Storage: adjuntos del bucket privado `myg-nube-archivos`.
- Tráfico de descarga, CPU/RAM y cantidad de usuarios trabajando simultáneamente.

En esta implementación el historial guarda JSON completo en cada guardado;
las confirmaciones de operaciones también conservan solicitud y respuesta.
Por eso el consumo puede crecer aunque el tamaño visible de las obras no cambie.
Conviene medirlo y definir una política de conservación y cuotas antes de crecer
mucho. Esta entrega no elimina historial ni cambia su retención.

Los límites de MYG de 20 MiB por adjunto y 31 MiB de contenido JSON por proyecto
son límites de la aplicación; pagar otro plan no los modifica automáticamente.
El plan de pago tampoco significa capacidad ilimitada ni ajusta automáticamente
todos los recursos de cómputo. No se puede estimar cuántas obras/usuarios caben
sin revisar tamaños reales, Usage y concurrencia.

Fuentes oficiales consultadas para esta explicación:

- https://supabase.com/docs/guides/platform/billing-on-supabase
- https://supabase.com/docs/guides/storage/schema/design
- https://supabase.com/docs/guides/platform/manage-your-usage/egress
- https://supabase.com/docs/guides/platform/compute-and-disk

## GitHub y precauciones

En Visual Studio, revise Cambios de Git, confirme su rama `main`, cree el Commit
y pulse Push; compruebe después los archivos en GitHub. Esta entrega publica
sólo el ZIP en una ruta nueva de `DESCARGAS`, sin hacer Push del código.

Compare personalizaciones posteriores antes de reemplazar archivos completos.
Las pruebas con el instalador, usuarios reales y autenticación en Windows quedan
pendientes de ese entorno. Las vinculaciones y los datos existentes se conservan.
