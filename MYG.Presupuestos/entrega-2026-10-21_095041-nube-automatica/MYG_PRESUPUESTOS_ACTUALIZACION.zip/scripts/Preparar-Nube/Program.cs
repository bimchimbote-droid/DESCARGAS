using System.Text.Json;
using MYG.Colaboracion;

if (args.Length != 2)
{
    Console.Error.WriteLine("Uso: Preparar-Nube <configuración guardada> <nube-myg.json de distribución>");
    return 2;
}

try
{
    // Se exige una fuente explícita: no hay lectura de otras cuentas ni red.
    string origen = Path.GetFullPath(args[0]);
    if (!File.Exists(origen)) throw new FileNotFoundException();
    var conexion = ConfiguracionServicioNube.Cargar(origen, origen)
        ?? throw new InvalidDataException();
    // Exportar únicamente las tres propiedades públicas del modelo. No copiar
    // el JSON original, que podría contener otros campos o datos de sesión.
    ConfiguracionServicioNube.Guardar(args[1], conexion);
    Console.WriteLine("Conexión pública de Nube MYG preparada para la distribución.");
    return 0;
}
catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or NubeException or ArgumentException)
{
    // No imprimir el JSON, la clave recibida ni excepciones de parseo.
    Console.Error.WriteLine("No se pudo preparar Nube MYG. Guarde una conexión válida en Opciones avanzadas o indique su archivo de configuración. Use únicamente la clave publicable o anon.");
    return 1;
}
