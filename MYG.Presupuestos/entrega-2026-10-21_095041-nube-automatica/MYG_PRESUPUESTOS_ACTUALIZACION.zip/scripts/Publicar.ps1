param(
    [string]$RevitInstallDir = 'C:\Program Files\Autodesk\Revit 2027',
    [string]$ConfiguracionNube = ''
)
$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot
if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Instale el SDK de .NET 10.' }
if ([string]::IsNullOrWhiteSpace($ConfiguracionNube)) {
    $ConfiguracionNube = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MYG\Nube\config.json'
}
if (!(Test-Path -LiteralPath $ConfiguracionNube -PathType Leaf)) {
    throw 'Guarde una vez la conexión de Nube MYG en su equipo o indique -ConfiguracionNube con su archivo config.json antes de generar la distribución.'
}
foreach ($api in @('RevitAPI.dll', 'RevitAPIUI.dll')) {
    if (!(Test-Path (Join-Path $RevitInstallDir $api))) { throw "No se encontró $api en $RevitInstallDir." }
}
$escritorio = Join-Path $raiz 'dist\MYG'
$conector = Join-Path $raiz 'dist\Conector'
& dotnet publish (Join-Path $raiz 'MYG.Desktop\MYG.Desktop.csproj') -c Release -r win-x64 --self-contained true `
    '-p:PublishSingleFile=false' '-p:UseRevitReferencePackages=false' -o $escritorio
if ($LASTEXITCODE -ne 0) { throw 'Falló la publicación de MYG.Desktop.' }
& dotnet run --project (Join-Path $PSScriptRoot 'Preparar-Nube\Preparar-Nube.csproj') -c Release -- `
    $ConfiguracionNube (Join-Path $escritorio 'nube-myg.json')
if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar la conexión pública de Nube MYG. No distribuya esta publicación.' }
& dotnet build (Join-Path $raiz 'MYG.Revit2027\MYG.Revit2027.csproj') -c Release `
    "-p:RevitInstallDir=$RevitInstallDir" '-p:UseRevitReferencePackages=false' -o $conector
if ($LASTEXITCODE -ne 0) { throw 'Falló la compilación del conector.' }
$scripts = Join-Path $raiz 'dist\scripts'
New-Item -ItemType Directory -Force -Path $scripts | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'Instalar-Conector.ps1') $scripts -Force
Copy-Item (Join-Path $PSScriptRoot 'Desinstalar-Conector.ps1') $scripts -Force
Copy-Item (Join-Path $raiz 'LEEME.md') (Join-Path $raiz 'dist\LEEME.md') -Force
Write-Host "Publicación terminada: $escritorio"
Write-Host 'La distribución incluye la conexión de Nube MYG; cada usuario ingresa con su propia cuenta MYG.'
Write-Host 'Distribuya la carpeta dist completa. MYG.Presupuestos.exe requiere los demás archivos de su carpeta.'
