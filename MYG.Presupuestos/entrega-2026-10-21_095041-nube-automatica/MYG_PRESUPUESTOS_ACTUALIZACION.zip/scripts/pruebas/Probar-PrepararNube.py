from pathlib import Path
import argparse,json,os,shutil,subprocess,tempfile
root=Path(__file__).resolve().parents[2]
dll=root/'scripts/Preparar-Nube/bin/Release/net10.0/Preparar-Nube.dll'
parser=argparse.ArgumentParser(description='Prueba la preparación pública de Nube MYG con archivos sintéticos y sin red.')
parser.add_argument('--no-build',action='store_true')
args=parser.parse_args()
exe=shutil.which('dotnet')
if not exe:
 candidate=Path(os.environ.get('DOTNET_ROOT',''))/('dotnet.exe' if os.name=='nt' else 'dotnet')
 if candidate.is_file():exe=str(candidate.resolve())
if not exe:raise RuntimeError('Instale .NET SDK 10 y añada dotnet al PATH.')
if not args.no_build:
 subprocess.run([exe,'build',str(root/'scripts/Preparar-Nube/Preparar-Nube.csproj'),'-c','Release','-m:1','-nr:false'],check=True)
if not dll.is_file():raise RuntimeError('Compile primero scripts/Preparar-Nube/Preparar-Nube.csproj en Release.')
checks=0
with tempfile.TemporaryDirectory(prefix='myg-nube-cli-') as folder:
 base=Path(folder)
 source=base/'config.json'; target=base/'publicacion'/'nube-myg.json'
 def run(args):
  p=subprocess.run([exe,str(dll),*map(str,args)],capture_output=True,text=True)
  assert 'SENTINELA_NO_DISTRIBUIR' not in p.stdout+p.stderr
  return p
 official={'Nombre':'Nube MYG Áncash','Url':'https://oficial.supabase.co','ClavePublicable':'sb_publishable_prueba_sintetica'}
 source.write_text(json.dumps({**official,'Acceso':'SENTINELA_NO_DISTRIBUIR','Refresco':'SENTINELA_NO_DISTRIBUIR'}))
 original=source.read_bytes()
 p=run([source,target]); assert p.returncode==0,p.stderr
 assert json.loads(target.read_bytes())==official
 assert source.read_bytes()==original
 checks+=3
 for encoding in ['utf-8-sig','utf-16']:
  source.write_bytes(json.dumps(official,ensure_ascii=False).encode(encoding))
  p=run([source,target]); assert p.returncode==0,p.stderr
  assert json.loads(target.read_bytes())==official
  checks+=2
 before=target.read_bytes()
 for invalid in [
  {**official,'ClavePublicable':'sb_secret_SENTINELA_NO_DISTRIBUIR'},
  {**official,'Url':'http://oficial.supabase.co'},
  {**official,'Url':'https://externo.example'},
  {**official,'Nombre':''}]:
  source.write_text(json.dumps(invalid))
  p=run([source,target]); assert p.returncode==1
  assert target.read_bytes()==before
  checks+=2
 source.write_text('{')
 p=run([source,target]); assert p.returncode==1 and target.read_bytes()==before
 checks+=1
 source.write_bytes(b'{"Nombre":"'+bytes([255])+b'"}')
 p=run([source,target]); assert p.returncode==1 and target.read_bytes()==before
 checks+=1
 p=run([base/'no-existe.json',target]); assert p.returncode==1 and target.read_bytes()==before
 checks+=1
 p=run([]); assert p.returncode==2
 checks+=1
 target.write_text(json.dumps({**official,'Acceso':'SENTINELA_NO_DISTRIBUIR'}))
 p=run([target,target]); assert p.returncode==0 and json.loads(target.read_bytes())==official
 checks+=1
 assert not list(base.rglob('*.tmp'))
 checks+=1
 print(f'OK Preparar-Nube: {checks} comprobaciones de exportación pública, privacidad, errores y actualización en el mismo archivo; sin red.')
