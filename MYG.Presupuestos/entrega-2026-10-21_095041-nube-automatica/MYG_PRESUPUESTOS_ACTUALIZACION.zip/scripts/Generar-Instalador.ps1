param(
    [string]$RevitInstallDir = 'C:\Program Files\Autodesk\Revit 2027',
    [ValidatePattern('^\d+\.\d+\.\d+(\.\d+)?$')]
    [string]$Version = '1.0.0',
    [string]$IsccPath = '',
    [switch]$OmitirPublicacion,
    [string]$ConfiguracionNube = ''
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'El instalador debe generarse en Windows.' }
$raiz = Split-Path -Parent $PSScriptRoot

if ([string]::IsNullOrWhiteSpace($IsccPath)) {
    $comando = Get-Command ISCC.exe -ErrorAction SilentlyContinue
    if ($comando) { $IsccPath = $comando.Source }
    if ([string]::IsNullOrWhiteSpace($IsccPath)) {
        foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
            if ([string]::IsNullOrWhiteSpace($base)) { continue }
            foreach ($sub in @('Inno Setup 7', 'Inno Setup 6', 'Programs\Inno Setup 7', 'Programs\Inno Setup 6')) {
                $candidato = Join-Path (Join-Path $base $sub) 'ISCC.exe'
                if (Test-Path -LiteralPath $candidato -PathType Leaf) { $IsccPath = $candidato; break }
            }
            if (-not [string]::IsNullOrWhiteSpace($IsccPath)) { break }
        }
    }
}
if ([string]::IsNullOrWhiteSpace($IsccPath) -or -not (Test-Path -LiteralPath $IsccPath -PathType Leaf)) {
    throw 'Instale Inno Setup desde https://jrsoftware.org/isdl.php o indique -IsccPath con la ruta de ISCC.exe.'
}
$IsccPath = (Resolve-Path -LiteralPath $IsccPath).Path

if (-not $OmitirPublicacion) {
    & (Join-Path $PSScriptRoot 'Publicar.ps1') -RevitInstallDir $RevitInstallDir -ConfiguracionNube $ConfiguracionNube
}

foreach ($rel in @('dist\MYG\MYG.Presupuestos.exe', 'dist\MYG\MYG.Presupuestos.dll',
    'dist\MYG\MYG.Core.dll', 'dist\MYG\coreclr.dll', 'dist\MYG\System.Windows.Forms.dll', 'dist\MYG\nube-myg.json',
    'dist\Conector\MYG.Revit2027.dll', 'dist\Conector\MYG.Core.dll')) {
    if (-not (Test-Path -LiteralPath (Join-Path $raiz $rel) -PathType Leaf)) {
        throw "Falta $rel. Genere una publicación con .NET incluido mediante scripts\Publicar.ps1."
    }
}
if ($OmitirPublicacion) {
    $conexionDistribuida = Join-Path $raiz 'dist\MYG\nube-myg.json'
    & dotnet run --project (Join-Path $PSScriptRoot 'Preparar-Nube\Preparar-Nube.csproj') -c Release -- `
        $conexionDistribuida $conexionDistribuida
    if ($LASTEXITCODE -ne 0) { throw 'La publicación no tiene una conexión pública válida de Nube MYG.' }
}
# Las API pertenecen a la instalación de Revit, no a la distribución MYG.
foreach ($api in @('RevitAPI.dll', 'RevitAPIUI.dll')) {
    if (Test-Path -LiteralPath (Join-Path (Join-Path $raiz 'dist\Conector') $api)) {
        throw "La carpeta del conector contiene $api. Corrija la publicación antes de distribuirla."
    }
}

$receta = Join-Path $raiz 'instalador\MYG.Presupuestos.iss'
& $IsccPath "/DMyAppVersion=$Version" $receta
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup no pudo generar el instalador. Revise el error mostrado.' }
$salida = Join-Path (Join-Path $raiz 'dist\Instalador') "MYG_Presupuestos_Setup_$Version.exe"
if (-not (Test-Path -LiteralPath $salida -PathType Leaf)) { throw 'No se encontró el instalador en la carpeta de salida.' }
Write-Host "Instalador generado: $salida"
Write-Host 'Este es el archivo que puede compartir con sus usuarios.'
