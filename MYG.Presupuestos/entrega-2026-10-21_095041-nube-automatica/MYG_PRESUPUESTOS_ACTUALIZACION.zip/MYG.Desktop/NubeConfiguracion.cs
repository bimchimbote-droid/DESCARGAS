#nullable enable
using System;
using System.IO;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

/// <summary>La configuración contiene solo el destino y una clave pública; nunca una sesión.</summary>
public sealed record ConfiguracionNube(string Nombre, string Url, string ClavePublicable)
{
    public ClienteSupabase CrearCliente() => new(Url, ClavePublicable);
}

public static class NubeConfiguracion
{
    public static string Ruta => Path.Combine(Environment.GetFolderPath(
        Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "config.json");
    public static string RutaDistribuida => Path.Combine(AppContext.BaseDirectory, "nube-myg.json");

    public static ConfiguracionNube? Cargar()
    {
        var configuracion = ConfiguracionServicioNube.Cargar(Ruta, RutaDistribuida);
        return configuracion is null ? null : new ConfiguracionNube(
            configuracion.Nombre, configuracion.Url, configuracion.ClavePublicable);
    }

    public static void Guardar(ConfiguracionNube configuracion)
    {
        ArgumentNullException.ThrowIfNull(configuracion);
        ConfiguracionServicioNube.Guardar(Ruta, new ConfiguracionServicioNube(
            configuracion.Nombre, configuracion.Url, configuracion.ClavePublicable));
    }

    public static ConfiguracionNube? Editar(WinForms.IWin32Window propietario)
    {
        ConfiguracionNube? anterior = null;
        try { anterior = Cargar(); }
        catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or NubeException)
        { MYGProyectoUI.Error(propietario, ex); }

        using var dialogo = new WinForms.Form();
        MYGProyectoUI.Preparar(dialogo, "Opciones avanzadas de Nube MYG", 610, 390);
        dialogo.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
        dialogo.MaximizeBox = false;
        dialogo.MinimizeBox = false;
        var raiz = new WinForms.TableLayoutPanel
        {
            Dock = WinForms.DockStyle.Fill, Padding = new(22), ColumnCount = 1, RowCount = 8
        };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 26, 36, 26, 36, 26, 36, 70, 54 })
            raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, alto));
        var nombre = new WinForms.TextBox { Name = "nombreConexionNube", Dock = WinForms.DockStyle.Fill,
            Text = anterior?.Nombre ?? "Nube MYG", MaxLength = 100 };
        var url = new WinForms.TextBox { Name = "urlConexionNube", Dock = WinForms.DockStyle.Fill,
            Text = anterior?.Url ?? "", PlaceholderText = "https://proyecto.supabase.co", MaxLength = 2048 };
        var clave = new WinForms.TextBox { Name = "clavePublicableNube", Dock = WinForms.DockStyle.Fill,
            Text = anterior?.ClavePublicable ?? "", PlaceholderText = "sb_publishable_… o clave anon", MaxLength = 32768 };
        raiz.Controls.Add(new WinForms.Label { Text = "Nombre de conexión", AutoSize = true }, 0, 0);
        raiz.Controls.Add(nombre, 0, 1);
        raiz.Controls.Add(new WinForms.Label { Text = "URL del proyecto Supabase", AutoSize = true }, 0, 2);
        raiz.Controls.Add(url, 0, 3);
        raiz.Controls.Add(new WinForms.Label { Text = "Clave publicable", AutoSize = true }, 0, 4);
        raiz.Controls.Add(clave, 0, 5);
        raiz.Controls.Add(new WinForms.Label
        {
            Text = "La instalación incluye la conexión de Nube MYG. Cambie estos datos sólo por indicación del administrador. El ingreso usa su cuenta MYG y conserva los permisos de cada proyecto.",
            Dock = WinForms.DockStyle.Fill, Padding = new(0, 6, 0, 0)
        }, 0, 6);
        var pie = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill,
            FlowDirection = WinForms.FlowDirection.RightToLeft, WrapContents = false };
        var cancelar = MYGProyectoUI.Boton("Cancelar");
        cancelar.DialogResult = WinForms.DialogResult.Cancel;
        var guardar = MYGProyectoUI.Boton("Guardar", 1);
        ConfiguracionNube? resultado = null;
        guardar.Click += (_, _) =>
        {
            try
            {
                var candidata = new ConfiguracionNube(nombre.Text.Trim(), url.Text.Trim(), clave.Text.Trim());
                Guardar(candidata);
                resultado = candidata;
                dialogo.DialogResult = WinForms.DialogResult.OK;
            }
            catch (Exception ex) { MYGProyectoUI.Error(dialogo, ex); }
        };
        pie.Controls.Add(cancelar); pie.Controls.Add(guardar);
        raiz.Controls.Add(pie, 0, 7); dialogo.Controls.Add(raiz);
        dialogo.AcceptButton = guardar; dialogo.CancelButton = cancelar;
        return dialogo.ShowDialog(propietario) == WinForms.DialogResult.OK ? resultado : null;
    }
}
