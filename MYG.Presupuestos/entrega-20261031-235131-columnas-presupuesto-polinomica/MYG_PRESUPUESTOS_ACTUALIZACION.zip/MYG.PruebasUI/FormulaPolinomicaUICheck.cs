using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class FormulaPolinomicaUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        AlcancePresupuestoSeleccionado(exige);
        var presupuesto = Crear();
        string original = JsonSerializer.Serialize(presupuesto);
        using (var consulta = new MYGFormulaPolinomicaForm(presupuesto, false))
        {
            consulta.ClientSize = new Size(1200, 760); consulta.Show(); Application.DoEvents();
            var controles = Descendientes(consulta).ToArray();
            var detalle = controles.OfType<DataGridView>().Single(x => x.Name == "polinomica_detalle");
            var monomios = controles.OfType<DataGridView>().Single(x => x.Name == "polinomica_monomios");
            var division = controles.OfType<SplitContainer>().Single(x => x.Name == "polinomica_division");
            exige(consulta.Name == "formula_polinomica_form" && division.Orientation == Orientation.Horizontal &&
                division.Panel1.Controls.Contains(detalle) && division.Panel2.Controls.Contains(monomios) &&
                detalle.Visible && monomios.Visible && detalle.Height > 100 && monomios.Height > 100,
                "La fórmula debe mostrar la matriz arriba y los monomios abajo en una ventana redimensionable.");
            exige(detalle.ReadOnly && monomios.ReadOnly && !monomios.AllowDrop &&
                !controles.OfType<Button>().Single(x => x.Name == "polinomica_aplicar").Enabled &&
                controles.OfType<Button>().Where(x => x.Name is "polinomica_imprimir_detalle" or "polinomica_imprimir_formula" or "polinomica_excel").All(x => x.Enabled),
                "La consulta sin licencia debe permitir impresión y exportación, bloqueando la edición y el arrastre.");
            var grupos = consulta.Configuracion.Grupos;
            exige(!consulta.Agrupar(grupos[0].Id, grupos[1].Id, confirmar: false) &&
                !consulta.Mover(grupos[0].Id, 1) && !consulta.Separar(grupos[0].Id) && !consulta.Deshacer() && !consulta.Cambiado,
                "Las acciones internas también deben respetar el modo de solo lectura.");
            exige(detalle.Columns.Count == 8 && monomios.Columns.Count == 5 && consulta.Resultado.Monomios.Count == 3 &&
                consulta.Resultado.TotalCalculado == 1 && consulta.CantidadPreparaciones == 1,
                "La matriz debe tener las columnas base e índices reales y la fórmula sus cinco columnas de cálculo.");
            ComprobarColumnasFijas(detalle, exige);
            controles.OfType<Button>().Single(x => x.Name == "polinomica_actualizar").PerformClick();
            Application.DoEvents();
            ComprobarColumnasFijas(detalle, exige);
            exige(consulta.CantidadPreparaciones == 2 && consulta.Resultado.TotalCalculado == 1,
                "Actualizar debe conservar el bloque fijo hasta Total y todos los aportes del presupuesto.");
            consulta.Close(); Application.DoEvents();
        }

        using (var editor = new MYGFormulaPolinomicaForm(presupuesto, true))
        {
            var grupos = editor.Configuracion.Grupos;
            string inicial = JsonSerializer.Serialize(editor.Configuracion);
            string origen = grupos[0].Id, destino = grupos[1].Id;
            exige(!editor.Agrupar(origen, origen, confirmar: false) && !editor.Deshacer(),
                "Arrastrar un monomio sobre sí mismo no debe editar ni añadir historial.");
            exige(editor.Agrupar(origen, destino, confirmar: false) && editor.Cambiado &&
                editor.Resultado.Monomios.Count == 2 && editor.Resultado.Monomios.Sum(x => x.Importe) == 100 &&
                editor.Resultado.TotalCalculado == 1 && editor.CantidadPreparaciones == 1,
                "Agrupar debe mover el aporte una sola vez y recalcular coeficientes usando la matriz existente.");
            exige(editor.Resultado.Monomios.Single(x => x.Id == destino).Porcentajes.Values.Sum() == 100 &&
                JsonSerializer.Serialize(presupuesto) == original,
                "Los porcentajes deben sumar cien dentro del monomio sin modificar aún el presupuesto.");
            exige(editor.Deshacer() && JsonSerializer.Serialize(editor.Configuracion) == inicial && !editor.Cambiado &&
                editor.CantidadPreparaciones == 1,
                "Deshacer debe restaurar exactamente la configuración previa sin volver a preparar los ACU.");
            exige(editor.Mover(origen, 1) && editor.Configuracion.Grupos[1].Id == origen && editor.Deshacer() &&
                JsonSerializer.Serialize(editor.Configuracion) == inicial,
                "El orden de monomios debe poder cambiarse y deshacerse conservando sus identidades.");
            exige(editor.Agrupar(origen, destino, confirmar: false) && editor.Separar(destino) &&
                editor.Configuracion.Grupos.Count == 3 && editor.Resultado.TotalCalculado == 1 &&
                editor.Resultado.Monomios.Sum(x => x.Importe) == 100 && editor.CantidadPreparaciones == 1,
                "Desagrupar debe recuperar los índices separados sin duplicar aportes ni reconstruir la matriz.");
            var copia = editor.Configuracion;
            copia.Grupos[0].Indices.Clear();
            exige(editor.Configuracion.Grupos[0].Indices.Count > 0,
                "La configuración que entrega el diálogo debe ser una copia aislada.");
            // Descartar el formulario directamente evita aceptar cambios y no abre un diálogo de confirmación.
        }
        exige(JsonSerializer.Serialize(presupuesto) == original && presupuesto.FormulaPolinomica == null,
            "Cerrar una edición sin aplicar no debe modificar el documento, los costos ni sus monomios persistentes.");

        using (var editor = new MYGFormulaPolinomicaForm(presupuesto, true))
        {
            editor.Show(); Application.DoEvents();
            var monomios = Descendientes(editor).OfType<DataGridView>().Single(x => x.Name == "polinomica_monomios");
            monomios.CurrentCell = monomios.Rows[0].Cells["DESCRIPCION"];
            exige(monomios.BeginEdit(true), "Debe ser posible editar la descripción de un monomio.");
            ((TextBox)monomios.EditingControl).Text = "Descripción editada";
            exige(monomios.EndEdit(), "Debe confirmarse la edición de la descripción.");
            Application.DoEvents();
            exige(editor.Configuracion.Grupos[0].Descripcion == "Descripción editada" &&
                !editor.Configuracion.Grupos[0].Descripcion.Contains('▾'),
                "El indicador de expandir no debe incorporarse a la descripción almacenada.");
            monomios.CurrentCell = monomios.Rows[0].Cells["DEFINIDO"];
            exige(monomios.BeginEdit(true), "Debe ser posible editar el coeficiente definido.");
            ((TextBox)monomios.EditingControl).Text = 0.333m.ToString(System.Globalization.CultureInfo.CurrentCulture);
            var finalizar = typeof(MYGFormulaPolinomicaForm).GetMethod("FinalizarEdicion", BindingFlags.Instance | BindingFlags.NonPublic);
            exige((bool)finalizar.Invoke(editor, null) && editor.Resultado.Monomios[0].CoeficienteDefinido == 0.333m,
                "Finalizar una edición antes de imprimir o aplicar debe actualizar el resultado sin depender de un callback pendiente.");
            Application.DoEvents();
            var grupos = editor.Configuracion.Grupos;
            exige(editor.Agrupar(grupos[0].Id, grupos[1].Id, confirmar: false),
                "La agrupación de prueba debe preparar un cambio antes de aplicar.");
            Descendientes(editor).OfType<Button>().Single(x => x.Name == "polinomica_aplicar").PerformClick();
            Application.DoEvents();
            exige(editor.DialogResult == DialogResult.OK && editor.Cambiado &&
                JsonSerializer.Serialize(presupuesto) == original,
                "Aplicar debe devolver la configuración al editor sin escribir directamente ni guardar la base.");
        }
    }

    private static void ComprobarColumnasFijas(DataGridView detalle, Action<bool, string> exige)
    {
        string[] fijas = { "DESCRIPCION", "UNIDAD", "METRADO", "PRECIO", "TOTAL" };
        exige(fijas.All(nombre => detalle.Columns[nombre].Frozen) &&
            detalle.Columns.Cast<DataGridViewColumn>().Where(c => c.Name.StartsWith("IU_", StringComparison.Ordinal)).All(c => !c.Frozen) &&
            !detalle.AllowUserToOrderColumns,
            "Descripción, unidad, metrado, precio y Total deben quedar fijos, dejando solo los índices como columnas desplazables.");
    }

    private static void AlcancePresupuestoSeleccionado(Action<bool, string> exige)
    {
        var activo = Crear(); activo.Nombre = "Presupuesto activo A";
        var elegido = Crear(); elegido.Nombre = "Presupuesto seleccionado B";
        var partida = elegido.Items.Single();
        partida.Costos.Cantidad = 2;
        var titulo = new ItemPresupuestoDelphin
        {
            Id = "TITULO-B", IdLocalMYG = "TITULO-B", Item = "01", Descripcion = "Título del presupuesto B",
            TipoPropuesta = "TITULO", Unidad = ""
        };
        partida.ParentId = titulo.Id;
        elegido.Items.Insert(0, titulo);
        var hermana = new ItemPresupuestoDelphin
        {
            Id = "HERMANA-B", IdLocalMYG = "HERMANA-B", ParentId = titulo.Id,
            Item = "01.02", Descripcion = "Otra partida del mismo presupuesto B",
            TipoPropuesta = "PARTIDA", Unidad = "und", Costos = new() { Cantidad = 1, PrecioDirecto = 50 }
        };
        elegido.Items.Add(hermana);
        var proyecto = new MYGProyectoDocumento
        {
            Nombre = "Alcance de fórmula", PresupuestoActivoId = activo.Id,
            Presupuestos = new() { activo, elegido }
        };
        string original = JsonSerializer.Serialize(proyecto);
        foreach (object seleccion in new object[] { elegido, titulo, partida })
        {
            var presupuesto = EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, seleccion);
            exige(ReferenceEquals(presupuesto, elegido) && presupuesto.Items.Contains(hermana) &&
                presupuesto.Items.Count == 3,
                "Seleccionar el presupuesto B, uno de sus títulos o una partida debe resolver B entero, aunque A siga activo y tenga una partida con el mismo Id.");
            using var ventana = new MYGFormulaPolinomicaForm(presupuesto, false);
            var detalle = Descendientes(ventana).OfType<DataGridView>().Single(x => x.Name == "polinomica_detalle");
            var filas = detalle.Rows.Cast<DataGridViewRow>().Select(x => x.Tag).OfType<MYGFilaFormulaPolinomica>().ToArray();
            exige(filas.Length == 3 && filas.Count(x => !x.EsTitulo) == 2 && filas.Any(x => x.Id == hermana.Id) &&
                ventana.Resultado.Monomios.Sum(x => x.Importe) == 250,
                "La ventana debe incluir todas las partidas de B, también la hermana no seleccionada, y excluir los cien del presupuesto A.");
        }
        exige(ReferenceEquals(EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, MYGProyectoStorage.Copia(elegido)), elegido) &&
            ReferenceEquals(EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, MYGProyectoStorage.Copia(hermana)), elegido),
            "Una selección copiada debe recuperar el presupuesto vigente cuando su identidad o la de su partida identifican un único propietario.");
        bool RechazaSeleccion(object seleccion)
        {
            try { EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, seleccion); return false; }
            catch (InvalidOperationException) { return true; }
        }
        exige(RechazaSeleccion(MYGProyectoStorage.Copia(partida)) &&
            RechazaSeleccion(new MYGPresupuestoDocumento { Nombre = "Presupuesto retirado" }) &&
            RechazaSeleccion(new ItemPresupuestoDelphin { Id = "PARTIDA-RETIRADA" }),
            "Una selección ambigua o retirada debe rechazarse, en lugar de abrir silenciosamente la fórmula del presupuesto activo.");
        exige(ReferenceEquals(EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, null), activo) &&
            JsonSerializer.Serialize(proyecto) == original,
            "Sin selección debe usarse el presupuesto activo y consultar otra selección no debe cambiar el documento ni su presupuesto activo.");
    }

    private static MYGPresupuestoDocumento Crear()
    {
        var p = new MYGPresupuestoDocumento { Nombre = "Fórmula UI" };
        var partida = new ItemPresupuestoDelphin
        {
            Id = "PARTIDA", IdLocalMYG = "PARTIDA", Item = "01", Descripcion = "Partida de prueba",
            TipoPropuesta = "PARTIDA", Unidad = "und", Costos = new() { Cantidad = 1 }
        };
        for (int n = 0; n < 3; n++)
        {
            var insumo = new MYGInsumo { Id = "I" + n, Codigo = "R" + n, Precio = new[] { 40m, 10m, 50m }[n],
                Descripcion = "Insumo " + n, GrupoGenerico = new[] { "21 · Cemento", "37 · Herramientas", "47 · Mano de obra" }[n] };
            p.Costos.Insumos.Add(insumo);
            partida.Costos.Analisis.Add(new() { InsumoId = insumo.Id, Cantidad = 1 });
        }
        p.Items.Add(partida); return p;
    }

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var nieto in Descendientes(hijo)) yield return nieto;
        }
    }
}
