using System;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    internal static MYGPresupuestoDocumento ResolverPresupuestoFormulaPolinomica(
        MYGProyectoDocumento proyecto, object seleccion)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        // La selección identifica al propietario; la fórmula siempre recibe
        // todas sus partidas, incluidos los hermanos del título o partida elegidos.
        if (seleccion is MYGPresupuestoDocumento presupuesto)
            return proyecto.Presupuestos.FirstOrDefault(p => p.Id == presupuesto.Id)
                ?? throw new InvalidOperationException("El presupuesto seleccionado ya no está en el proyecto.");
        if (seleccion is ItemPresupuestoDelphin partida)
        {
            var propietario = proyecto.Presupuestos.FirstOrDefault(p => p.Items.Any(i => ReferenceEquals(i, partida)));
            if (propietario != null) return propietario;
            var propietarios = proyecto.Presupuestos.Where(p => p.Items.Any(i => i.Id == partida.Id)).Take(2).ToList();
            if (propietarios.Count == 1) return propietarios[0];
            if (propietarios.Count > 1)
                throw new InvalidOperationException("El elemento seleccionado coincide con varios presupuestos. Seleccione una fila del presupuesto.");
            throw new InvalidOperationException("El elemento seleccionado ya no está en el proyecto.");
        }
        return proyecto.Presupuestos.FirstOrDefault(p => p.Id == proyecto.PresupuestoActivoId);
    }

    private void AbrirFormulaPolinomica()
    {
        object seleccion = espacioPresupuestos.SelectedIndex == 0
            ? panelPresupuesto.SeleccionEstructura : Seleccionadas.FirstOrDefault();
        var presupuestoActual = ResolverPresupuestoFormulaPolinomica(documento, seleccion)
            ?? throw new InvalidOperationException("Seleccione un presupuesto o una de sus partidas.");
        string presupuestoId = presupuestoActual.Id;
        using var ventana = new MYGFormulaPolinomicaForm(presupuestoActual, PuedeModificarProyecto);
        if (ventana.ShowDialog(this) != DialogResult.OK || !ventana.Cambiado) return;
        ExigirPermisoEdicionProyecto();
        presupuestoActual = documento.Presupuestos.FirstOrDefault(p => p.Id == presupuestoId)
            ?? throw new InvalidOperationException("El presupuesto seleccionado ya no está en el proyecto.");
        var candidato = MYGProyectoStorage.Copia(documento);
        candidato.Presupuestos.Single(p => p.Id == presupuestoId).FormulaPolinomica = ventana.Configuracion;
        if (vinculoNube?.PermisosModulos != null)
            MYGCambiosModulosNube.ExigirPermitidos(documento, candidato, vinculoNube.PermisosModulos);
        Recordar();
        presupuestoActual.FormulaPolinomica = ventana.Configuracion;
        Refrescar();
        estado.Text = "Fórmula polinómica actualizada. Guarde el proyecto para conservar la configuración.";
    }
}
