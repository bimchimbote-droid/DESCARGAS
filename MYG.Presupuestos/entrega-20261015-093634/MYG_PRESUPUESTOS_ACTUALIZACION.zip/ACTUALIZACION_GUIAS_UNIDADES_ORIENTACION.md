# Guías de márgenes, unidades y orientación

Esta actualización se aplica después de la entrega anterior de presupuesto de obra, escala y márgenes (`DESCARGAS`, commit `037ed0c608690a4217a52f10dc3e3dc997c4325b`). Base del código: `main`, commit `b1c830b479ecfff794f743bfd84b9ec9b707f65e`, más esa entrega. El ZIP contiene únicamente los archivos nuevos o reemplazados por esta actualización; no contiene ejecutables ni bases de datos.

## Qué cambia

- Todas las vistas preliminares de informes y la vista de especificaciones muestran las cuatro guías punteadas de los márgenes. En los informes siguen el papel al cambiar zoom, navegar, desplazar o ver varias páginas. Son ayudas de pantalla: no se imprimen ni aparecen en PDF.
- Configurar página ofrece las unidades **Inch**, **Millimeter** y **Pixel**. Se convierten las dimensiones del papel y los cuatro márgenes; cambiar de unidad conserva las medidas físicas sin acumular redondeos. Pixel usa **96 px por pulgada**, independientemente del monitor. Aceptar aplica los valores; Cancelar conserva los anteriores.
- Orientación muestra **Retrato** y **Apaisado**, con iconos distintos y la opción actual marcada. El diálogo de página también usa estos iconos.

## Instalar

1. Respalde o confirme los cambios de su carpeta del código. Aplique primero la entrega anterior si todavía no lo hizo.
2. Extraiga el ZIP en la raíz donde está `MYG.Presupuestos.sln`, conservando las carpetas y reemplazando los archivos completos incluidos. Los archivos nuevos se incorporan automáticamente por el SDK; no hay eliminaciones ni migraciones.
3. En Visual Studio 2026 con SDK .NET 10.0.100, restaure y compile:

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

El parámetro UseRevitReferencePackages permite compilar sin instalar Revit. La ejecución del conector requiere Revit 2027 en Windows. Microsoft Print to PDF debe estar activado para exportar los informes a PDF.

## Validación y comprobación manual

La solución se compiló en Linux x64 con .NET SDK 10.0.100 sin errores ni advertencias. La suite de datos ejecutó **329 comprobaciones correctas**, incluidas las equivalencias de unidades y precisión de conversión. Named Pipes de Windows se omite por plataforma; las muestras externas opcionales no se usaron.

Las pruebas gráficas se compilaron; su ejecución y la comprobación visual de impresora/PDF quedan pendientes en Windows:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Compruebe las guías en presupuesto, proyecto completo, resumen, ACU, consolidado, metrados, acero y especificaciones; ajuste márgenes y orientación, navegue y cambie de zoom. Cambie varias veces entre las tres unidades y acepte sin editar para comprobar que el tamaño físico se conserva. Pruebe Retrato y Apaisado y revise los controles con DPI 100 %, 150 % y 200 %. Exporte un PDF e imprima una página: las guías no deben aparecer en el resultado.

## GitHub

La publicación del ZIP en el repositorio independiente público `bimchimbote-droid/DESCARGAS` no actualiza `MYG.Presupuestos`. Después de aplicar y revisar la entrega, use Cambios de Git de Visual Studio para revisar la rama `main`, hacer Commit y Push, y verificar el commit en GitHub. Si tiene modificaciones posteriores, compare o fusione los archivos antes de reemplazarlos completos para conservar sus avances.
