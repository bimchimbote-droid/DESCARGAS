using System;

namespace MYG_2027;

/// <summary>Unidades de edición de papel y márgenes de la vista preliminar.</summary>
public enum MYGUnidadPaginaReporte
{
    Inch,
    Millimeter,
    Pixel
}

/// <summary>Convierte medidas físicas sin depender de la resolución de pantalla.
/// Los píxeles de página equivalen siempre a 96 píxeles por pulgada.</summary>
public static class MYGUnidadesPaginaReporte
{
    public const decimal MilimetrosPorPulgada = 25.4m;
    public const decimal PixelesPorPulgada = 96m;

    public static decimal DesdeMilimetros(decimal milimetros, MYGUnidadPaginaReporte unidad) => unidad switch
    {
        MYGUnidadPaginaReporte.Inch => milimetros / MilimetrosPorPulgada,
        MYGUnidadPaginaReporte.Millimeter => milimetros,
        MYGUnidadPaginaReporte.Pixel => milimetros / MilimetrosPorPulgada * PixelesPorPulgada,
        _ => throw new ArgumentOutOfRangeException(nameof(unidad))
    };

    public static decimal AMilimetros(decimal medida, MYGUnidadPaginaReporte unidad) => unidad switch
    {
        MYGUnidadPaginaReporte.Inch => medida * MilimetrosPorPulgada,
        MYGUnidadPaginaReporte.Millimeter => medida,
        MYGUnidadPaginaReporte.Pixel => medida * MilimetrosPorPulgada / PixelesPorPulgada,
        _ => throw new ArgumentOutOfRangeException(nameof(unidad))
    };

    public static string Simbolo(MYGUnidadPaginaReporte unidad) => unidad switch
    {
        MYGUnidadPaginaReporte.Inch => "in",
        MYGUnidadPaginaReporte.Millimeter => "mm",
        MYGUnidadPaginaReporte.Pixel => "px",
        _ => throw new ArgumentOutOfRangeException(nameof(unidad))
    };
}
