using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace MYG_2027;

/// <summary>Ayudas de pantalla; los informes impresos y PDF no contienen estas guías.</summary>
internal static class MYGGuiasMargenesVista
{
    // Papel, área y grosor utilizan las unidades actuales de Graphics.
    internal static void Dibujar(Graphics dibujo, RectangleF papel, RectangleF area, float grosor = 1f)
    {
        if (papel.Width <= 0 || papel.Height <= 0) return;
        var estado = dibujo.Save();
        try
        {
            dibujo.SetClip(papel, CombineMode.Intersect);
            using var guia = new Pen(Color.FromArgb(150, 150, 150), grosor) { DashStyle = DashStyle.Dot };
            float izquierda = Math.Clamp(area.Left, papel.Left, papel.Right);
            float derecha = Math.Clamp(area.Right, papel.Left, papel.Right);
            float superior = Math.Clamp(area.Top, papel.Top, papel.Bottom);
            float inferior = Math.Clamp(area.Bottom, papel.Top, papel.Bottom);
            dibujo.DrawLine(guia, izquierda, papel.Top, izquierda, papel.Bottom);
            dibujo.DrawLine(guia, derecha, papel.Top, derecha, papel.Bottom);
            dibujo.DrawLine(guia, papel.Left, superior, papel.Right, superior);
            dibujo.DrawLine(guia, papel.Left, inferior, papel.Right, inferior);
        }
        finally { dibujo.Restore(estado); }
    }
}
