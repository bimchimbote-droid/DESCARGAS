using System;
using MYG_2027;

internal static class UnidadesPaginaReporteCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(Action<string> pasa)
    {
        Exige(MYGUnidadesPaginaReporte.DesdeMilimetros(25.4m, MYGUnidadPaginaReporte.Inch) == 1m &&
            MYGUnidadesPaginaReporte.DesdeMilimetros(25.4m, MYGUnidadPaginaReporte.Pixel) == 96m &&
            MYGUnidadesPaginaReporte.AMilimetros(96m, MYGUnidadPaginaReporte.Pixel) == 25.4m,
            "Una pulgada debe equivaler a 25,4 mm y 96 píxeles físicos, independientemente del DPI de pantalla.");
        Exige(MYGUnidadesPaginaReporte.DesdeMilimetros(76.2m, MYGUnidadPaginaReporte.Inch) == 3m &&
            MYGUnidadesPaginaReporte.DesdeMilimetros(76.2m, MYGUnidadPaginaReporte.Pixel) == 288m &&
            MYGUnidadesPaginaReporte.AMilimetros(0, MYGUnidadPaginaReporte.Inch) == 0m,
            "El límite físico de los márgenes debe representar tres pulgadas en cualquier unidad.");
        foreach (var unidad in Enum.GetValues<MYGUnidadPaginaReporte>())
        {
            foreach (decimal mm in new[] { 0m, .254m, 18m, 18.034m, 25.4m, 76.2m, 210m, 297m, 420m })
            {
                decimal convertido = MYGUnidadesPaginaReporte.DesdeMilimetros(mm, unidad);
                Exige(Math.Abs(MYGUnidadesPaginaReporte.AMilimetros(convertido, unidad) - mm) < .000000000000000000001m,
                    "La conversión perdió precisión física para " + unidad + ".");
            }
        }
        Exige(MYGUnidadesPaginaReporte.AMilimetros(.71m, MYGUnidadPaginaReporte.Inch) == 18.034m &&
            MYGUnidadesPaginaReporte.AMilimetros(96.96m, MYGUnidadPaginaReporte.Pixel) == 25.654m &&
            MYGUnidadesPaginaReporte.DesdeMilimetros(210m, MYGUnidadPaginaReporte.Millimeter) == 210m &&
            MYGUnidadesPaginaReporte.DesdeMilimetros(297m, MYGUnidadPaginaReporte.Millimeter) == 297m,
            "Editar pulgadas o píxeles debe guardar su medida física sin redondear a milímetros enteros.");
        Exige(MYGUnidadesPaginaReporte.Simbolo(MYGUnidadPaginaReporte.Inch) == "in" &&
            MYGUnidadesPaginaReporte.Simbolo(MYGUnidadPaginaReporte.Millimeter) == "mm" &&
            MYGUnidadesPaginaReporte.Simbolo(MYGUnidadPaginaReporte.Pixel) == "px",
            "Las tres unidades deben identificarse en sus valores de página.");
        foreach (Action invalida in new Action[] {
            () => MYGUnidadesPaginaReporte.DesdeMilimetros(1, (MYGUnidadPaginaReporte)99),
            () => MYGUnidadesPaginaReporte.AMilimetros(1, (MYGUnidadPaginaReporte)(-1)),
            () => MYGUnidadesPaginaReporte.Simbolo((MYGUnidadPaginaReporte)99) })
        {
            bool rechazada = false;
            try { invalida(); } catch (ArgumentOutOfRangeException) { rechazada = true; }
            Exige(rechazada, "Una unidad desconocida debe rechazarse explícitamente.");
        }
        pasa("Unidades de página conservan medidas físicas: Inch, Millimeter y Pixel a 96 px por pulgada");
    }
}
