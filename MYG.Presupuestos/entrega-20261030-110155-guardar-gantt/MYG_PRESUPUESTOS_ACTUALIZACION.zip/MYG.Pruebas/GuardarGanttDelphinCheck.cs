using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class GuardarGanttDelphinCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Gantt con ficha Delphin sin columnas opcionales.sqlite");
        var semilla = MYGProyectoStorage.Nuevo("Gantt sintético", "Presupuesto sintético");
        semilla.Id = "PR-GANTT01";
        var presupuesto = semilla.Presupuestos.Single();
        presupuesto.Id = "PS-GANTT01";
        semilla.PresupuestoActivoId = presupuesto.Id;
        semilla.Datos = MYGDatosProyecto.Crear();
        semilla.Datos.FechaElaboracion = new DateTime(2026, 6, 1);
        semilla.Datos.FechaInicio = new DateTime(2026, 6, 8);
        semilla.Datos.Duracion = 10;
        semilla.Datos.UnidadDuracion = "DIAS";
        semilla.Datos.Portafolio = null;
        semilla.Datos.PortafolioId = null;
        semilla.Datos.CalcularFin();
        presupuesto.Items.Add(new ItemPresupuestoDelphin
        {
            Id = "CU-GANTT01", IdLocalMYG = "LOCAL-GANTT01", IdPropuesta = "CU-GANTT01",
            Descripcion = "Partida sintética de cronograma", Unidad = "m³", TipoPropuesta = "PARTIDA",
            Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 3.125m, PrecioDirecto = 15.25m }
        });
        MYGProyectoStorage.Guardar(ruta, semilla);
        // Sólo la fixture sintética se adapta al esquema de la exportación.
        // La corrección de producción no debe añadir, quitar ni migrar columnas.
        using (var c = Conexion(ruta, true))
        using (var q = c.CreateCommand())
        {
            q.CommandText = "ALTER TABLE proyecto DROP COLUMN id_portafolio; " +
                "ALTER TABLE proyecto DROP COLUMN duracion_new; DROP TABLE portafolio;";
            q.ExecuteNonQuery();
        }
        MYGProyectoDocumento documento;
        using (var c = Conexion(ruta))
            documento = MYGDocumentoDelphinAlmacenamiento.Leer(c,
                "{\"FormatoAlmacenamiento\":\"MYG_DELPHIN_EXTENSIONES\",\"VersionAlmacenamiento\":1," +
                "\"Id\":\"PR-GANTT01\",\"Cambios\":null}");
        documento.Cronograma ??= MYGMotorCronograma.CrearDesdePresupuestos(documento);
        var esquema = Esquema(ruta);
        string costos = Instantanea(ruta, "SELECT * FROM costo_unitario");

        EditarTarea(ruta, documento);
        ConservarEsquema(ruta, esquema, exacto: true);
        Exige(Instantanea(ruta, "SELECT * FROM costo_unitario") == costos,
            "Editar sólo el Gantt modificó cantidades o precios de las partidas nativas.");
        pasa("Guardar una tarea del Gantt conserva duración, notas y avance sin cambiar la ficha ni el esquema Delphin sin portafolio/duración decimal");

        documento = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        CambiarFechasDesdeGantt(ruta, documento);
        ConservarEsquema(ruta, esquema, exacto: true);
        Exige(Instantanea(ruta, "SELECT * FROM costo_unitario") == costos,
            "Cambiar fechas desde Gantt modificó datos económicos de las partidas nativas.");
        pasa("Cambiar inicio y fecha de estado desde Gantt permite guardar y reabrir tres veces sin exigir columnas opcionales ausentes");

        documento = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        documento.Datos.Duracion = 2.5m;
        documento.Datos.UnidadDuracion = "DIAS";
        documento.Datos.PortafolioId = "PO-MYG-ONLY";
        documento.Datos.Portafolio = "Portafolio adicional MYG";
        documento.Datos.CalcularFin();
        string plan = Json(documento.Cronograma);
        MYGProyectoStorage.Guardar(ruta, documento);
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        Exige(reabierto.Datos.Duracion == 2.5m && reabierto.Datos.PortafolioId == "PO-MYG-ONLY" &&
            reabierto.Datos.Portafolio == "Portafolio adicional MYG" && Json(reabierto.Cronograma) == plan,
            "Los datos de ficha sin destino nativo se perdieron o alteraron el cronograma al reabrir.");
        Exige(Convert.ToDecimal(Scalar(ruta, "SELECT duracion FROM proyecto WHERE id_proyecto=$p0", documento.Id),
            CultureInfo.InvariantCulture) == 2m, "La duración entera existente no recibió su parte compatible.");
        ConservarEsquema(ruta, esquema, exacto: true);
        Exige(Instantanea(ruta, "SELECT * FROM costo_unitario") == costos,
            "Los campos adicionales de ficha modificaron datos económicos nativos.");
        Integridad(ruta);
        pasa("Duración decimal y portafolio sin columna nativa permanecen en MYG sin crear columnas ni catálogos y conservan el cronograma");

        using (var c = Conexion(ruta, true))
        using (var q = c.CreateCommand())
        {
            q.CommandText = "CREATE TRIGGER gantt_rechazo BEFORE UPDATE OF fecha_inicio ON proyecto " +
                "BEGIN SELECT RAISE(ABORT,'gantt_rechazo_prueba'); END;";
            q.ExecuteNonQuery();
        }
        string antes = Huella(ruta);
        reabierto.Datos.FechaInicio = reabierto.Datos.FechaInicio.Value.AddDays(7);
        reabierto.Datos.CalcularFin();
        bool rechazo = false;
        try { MYGProyectoStorage.Guardar(ruta, reabierto); }
        catch (SqliteException ex) when (ex.SqliteErrorCode == 19 && ex.Message.Contains("gantt_rechazo_prueba"))
        { rechazo = true; }
        Exige(rechazo && Huella(ruta) == antes,
            "El guardado silenció un error SQL real o no revirtió todos sus cambios.");
        pasa("Guardar Gantt sigue propagando errores SQL reales y revierte el documento completo cuando una escritura falla");

        string muestra = Environment.GetEnvironmentVariable("MYG_QA_DELPHIN_SQLITE");
        if (string.IsNullOrWhiteSpace(muestra))
            Console.WriteLine("OMITIDA: guardado Gantt en muestra Delphin externa (MYG_QA_DELPHIN_SQLITE no definido).");
        else Muestra(Path.GetFullPath(muestra), carpeta, pasa);
    }

    private static void EditarTarea(string ruta, MYGProyectoDocumento documento)
    {
        string ficha = Instantanea(ruta, "SELECT * FROM proyecto WHERE id_proyecto=$p0", documento.Id);
        string datos = Json(documento.Datos);
        var tarea = documento.Cronograma.Tareas.First(t => !t.EsResumen && t.DuracionDias is > 0 and < 36500);
        MYGInformacionTarea.Reprogramar(tarea, tarea.DuracionDias + 1);
        tarea.Notas = "Edición sintética de Gantt; conservar al guardar.";
        tarea.Avance = 12.5m;
        string plan = Json(documento.Cronograma);
        MYGProyectoStorage.Guardar(ruta, documento);
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        Exige(Json(reabierto.Cronograma) == plan && Json(reabierto.Datos) == datos &&
            Instantanea(ruta, "SELECT * FROM proyecto WHERE id_proyecto=$p0", documento.Id) == ficha,
            "Editar una tarea perdió su cronograma o cambió la ficha nativa que no se editó.");
    }

    private static void CambiarFechasDesdeGantt(string ruta, MYGProyectoDocumento documento)
    {
        // Mismo recorrido de Fechas del proyecto en el panel Gantt: copia la
        // ficha, cambia inicio y recalcula fin; el plan conserva la fecha de estado.
        var datos = MYGProyectoStorage.Copia(documento.Datos);
        datos.FechaInicio = (datos.FechaInicio ?? documento.Cronograma.FechaInicio).AddDays(7);
        datos.CalcularFin();
        documento.Datos = datos;
        documento.Cronograma.FechaInicio = datos.FechaInicio.Value;
        documento.Cronograma.FechaEstado = datos.FechaInicio.Value.AddDays(2);
        string plan = Json(documento.Cronograma), ficha = Json(documento.Datos);
        for (int n = 0; n < 3; n++)
        {
            MYGProyectoStorage.Guardar(ruta, documento);
            documento = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
            Exige(Json(documento.Cronograma) == plan && Json(documento.Datos) == ficha,
                "Guardar y reabrir las fechas del Gantt perdió datos del cronograma o de la ficha.");
        }
    }

    private static void Muestra(string original, string carpeta, Action<string> pasa)
    {
        Exige(File.Exists(original), "No existe la muestra indicada para comprobar el guardado Gantt.");
        string huella = Huella(original);
        string copia = Path.Combine(carpeta, "Copia de muestra para guardar Gantt.sqlite");
        File.Copy(original, copia, false);
        try
        {
            var esquema = Esquema(copia);
            string costos = Instantanea(copia, "SELECT * FROM costo_unitario");
            string relaciones = Instantanea(copia, "PRAGMA foreign_key_check");
            var resumen = MYGBaseDatos.ListarProyectos(copia).First(p => p.CantidadPresupuestos > 0);
            var documento = MYGBaseDatos.LeerProyecto(copia, resumen.Id);
            documento.Cronograma ??= MYGMotorCronograma.CrearDesdePresupuestos(documento);
            EditarTarea(copia, documento);
            ConservarEsquema(copia, esquema, exacto: false);
            pasa("Muestra Delphin permite editar y guardar una tarea del Gantt manteniendo su ficha nativa y el archivo original intactos");

            documento = MYGBaseDatos.LeerProyecto(copia, documento.Id);
            CambiarFechasDesdeGantt(copia, documento);
            ConservarEsquema(copia, esquema, exacto: false);
            Exige(Instantanea(copia, "SELECT * FROM costo_unitario") == costos &&
                Instantanea(copia, "PRAGMA foreign_key_check") == relaciones,
                "El guardado Gantt modificó los datos económicos o las referencias nativas de la muestra.");
            Exige((string)Scalar(copia, "PRAGMA integrity_check") == "ok", "La muestra guardada no supera integrity_check.");
            pasa("Muestra Delphin guarda cambios de fechas del Gantt tres veces, reabre íntegra y conserva costos, esquema nativo y anomalías FK originales");
        }
        finally { Exige(Huella(original) == huella, "La regresión de guardado Gantt alteró el archivo original del usuario."); }
    }

    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly,
            Pooling = false, ForeignKeys = true }.ToString());
        c.Open(); return c;
    }

    private static object Scalar(string ruta, string sql, params object[] valores)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = sql;
        for (int n = 0; n < valores.Length; n++) q.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        return q.ExecuteScalar();
    }

    private static Dictionary<string, string> Esquema(string ruta)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand();
        q.CommandText = "SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name";
        using var r = q.ExecuteReader(); var resultado = new Dictionary<string, string>(StringComparer.Ordinal);
        while (r.Read()) resultado.Add(r.GetString(0) + ":" + r.GetString(1),
            r.GetString(2) + ":" + (r.IsDBNull(3) ? "" : r.GetString(3)));
        return resultado;
    }

    private static void ConservarEsquema(string ruta, Dictionary<string, string> esperado, bool exacto)
    {
        var actual = Esquema(ruta);
        Exige((!exacto || actual.Count == esperado.Count) && esperado.All(x => actual.TryGetValue(x.Key, out var v) && v == x.Value),
            "Guardar el Gantt alteró el esquema de tablas, índices o triggers existentes.");
    }

    private static string Instantanea(string ruta, string sql, params object[] valores)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = sql;
        for (int n = 0; n < valores.Length; n++) q.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        using var r = q.ExecuteReader(); var filas = new List<string>();
        while (r.Read())
        {
            var valoresFila = new string[r.FieldCount];
            for (int n = 0; n < valoresFila.Length; n++) valoresFila[n] = r.GetValue(n) switch
            {
                DBNull => "null", long v => "integer:" + v.ToString(CultureInfo.InvariantCulture),
                double v => "real:" + BitConverter.DoubleToInt64Bits(v).ToString("X16", CultureInfo.InvariantCulture),
                byte[] v => "blob:" + Convert.ToBase64String(v), string v => "text:" + v,
                _ => throw new InvalidDataException("Tipo SQLite no reconocido en la regresión Gantt.")
            };
            filas.Add(JsonSerializer.Serialize(valoresFila));
        }
        filas.Sort(StringComparer.Ordinal);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("\n", filas))));
    }

    private static void Integridad(string ruta)
    {
        Exige((string)Scalar(ruta, "PRAGMA integrity_check") == "ok", "La fixture Gantt no supera integrity_check.");
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = "PRAGMA foreign_key_check";
        using var r = q.ExecuteReader(); Exige(!r.Read(), "La fixture Gantt contiene referencias SQL inválidas.");
    }

    private static string Json<T>(T valor) => MYGJsonAlmacenamiento.Serializar(valor);
    private static string Huella(string ruta)
    { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
}
