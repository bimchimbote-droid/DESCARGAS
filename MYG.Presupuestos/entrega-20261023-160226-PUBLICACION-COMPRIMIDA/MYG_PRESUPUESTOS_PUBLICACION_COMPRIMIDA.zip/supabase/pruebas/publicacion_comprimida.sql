-- SOLO PostgreSQL DESECHABLE con fixture usuarios_myg_roles, parches 26/27
-- y tablas Storage simuladas. No ejecutar en el proyecto Supabase real.
-- Estas pruebas verifican el protocolo SQL; los cuerpos GZip se prueban en C#.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren una base desechable.'; end $$;
\endif

reset role;
create table qa.antes_comprimir as select
    (select jsonb_agg(to_jsonb(p)-'es_comprimido' order by id) from public.myg_nube_proyectos p) proyectos,
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h) historial,
    (select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m) miembros,
    (select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from public.myg_nube_operaciones o) operaciones;
\ir ../migraciones/20261028_publicacion_comprimida.sql
select qa.exige((select proyectos is not distinct from
    (select jsonb_agg(to_jsonb(p)-'es_comprimido' order by id) from public.myg_nube_proyectos p)
    and historial is not distinct from
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h)
    and miembros is not distinct from
    (select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m)
    and operaciones is not distinct from
    (select jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id) from public.myg_nube_operaciones o)
    from qa.antes_comprimir),'GZip: instalar conserva proyectos, historial, miembros y operaciones');

create table qa.primera_compresion as select
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'propietario',p.proowner,'acl',p.proacl,
        'config',p.proconfig,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
     from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace)) funciones,
    (select jsonb_agg(jsonb_build_object('nombre',tgname,'definicion',pg_get_triggerdef(oid),'habilitado',tgenabled)
        order by tgname) from pg_trigger where tgrelid='public.myg_nube_proyectos'::regclass and not tgisinternal) triggers;
\ir ../migraciones/20261028_publicacion_comprimida.sql
select qa.exige((select funciones=(select jsonb_agg(jsonb_build_object('oid',p.oid,'propietario',p.proowner,'acl',p.proacl,
        'config',p.proconfig,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
     from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace))
    and triggers=(select jsonb_agg(jsonb_build_object('nombre',tgname,'definicion',pg_get_triggerdef(oid),'habilitado',tgenabled)
        order by tgname) from pg_trigger where tgrelid='public.myg_nube_proyectos'::regclass and not tgisinternal)
    from qa.primera_compresion),'GZip: reinstalar conserva funciones, OID, ACL, configuración y triggers');

create function qa.gzip_manifest(p_id uuid,p_texto text,p_salt text) returns jsonb
language sql immutable as $$
select jsonb_build_object('formato','MYG_ARCHIVO_GZIP','version',1,
    'sha256_json',encode(sha256(convert_to(p_texto,'UTF8')),'hex'),'bytes_json',octet_length(p_texto),
    'sha256_gzip',encode(sha256(convert_to(p_salt,'UTF8')),'hex'),'bytes_gzip',100,
    'partes',jsonb_build_array(jsonb_build_object(
        'ruta','00000000-0000-0000-0000-000000000001/'||replace(p_id::text,'-','')||'/'||encode(sha256(convert_to(p_salt,'UTF8')),'hex'),
        'sha256',encode(sha256(convert_to(p_salt,'UTF8')),'hex'),'bytes',100)));
$$;
create table qa.gzip_casos as select 'inicial'::text nombre,
    'd8000000-0000-0000-0000-000000000001'::uuid id,
    '{"formato":"MYG_COLABORACION","version":1,"alcance":"obra","documento":{"Nombre":"A"},"documentos":[],"tablas":[],"recursos":[]}'::text contenido;
insert into qa.gzip_casos select 'nuevo',id,replace(contenido,'"A"','"B"') from qa.gzip_casos where nombre='inicial';
insert into qa.gzip_casos select 'tercero',id,replace(contenido,'"A"','"C"') from qa.gzip_casos where nombre='inicial';
alter table qa.gzip_casos add column manifest jsonb;
update qa.gzip_casos set manifest=qa.gzip_manifest(id,contenido,nombre);
insert into storage.objects(bucket_id,name,metadata)
select 'myg-nube-paquetes',manifest#>>'{partes,0,ruta}','{"size":100}'::jsonb from qa.gzip_casos;
grant select on qa.gzip_casos to authenticated;

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_capacidades()->>'publicacion_comprimida'='1'
    and public.myg_nube_capacidades()->>'publicacion_ligera'='1','GZip: anuncia capacidad y conserva capacidades previas');
select qa.exige((select not public.myg_nube_crear_comprimido(id,'COMPRIMIDA QA',manifest,'obra')?'contenido'
    from qa.gzip_casos where nombre='inicial'),'GZip: creación confirma sin devolver cuerpo');
select qa.exige(public.myg_nube_paquete_tipo('d8000000-0000-0000-0000-000000000001')='{"almacenamiento":"gzip"}',
    'GZip: consulta de tipo autorizada');
select qa.exige(public.myg_nube_paquete_tipo('10000000-0000-0000-0000-000000000001')='{"almacenamiento":"json"}',
    'GZip: proyectos legados conservan modo JSON');
select qa.exige((select public.myg_nube_abrir_comprimido(id)->'contenido'=manifest
    from qa.gzip_casos where nombre='inicial'),'GZip: apertura recupera manifiesto inicial completo');
select qa.rechaza($$select public.myg_nube_abrir('d8000000-0000-0000-0000-000000000001')$$,'MGC01',
    'GZip: cliente legado recibe señal explícita y no obra vacía');
select qa.rechaza($$select public.myg_nube_guardar('d8000000-0000-0000-0000-000000000001',
    'd8100000-0000-0000-0000-000000000001',1,'{}')$$,'MGC01','GZip: guardado legado no altera formato comprimido');
select qa.rechaza($$select public.myg_nube_guardar_cambios('d8000000-0000-0000-0000-000000000001',
    'd8100000-0000-0000-0000-000000000002',1,'{"version":1,"campos":{}}')$$,'MGC01',
    'GZip: guardado incremental legado no opera sobre manifiesto');

select qa.exige((select public.myg_nube_crear_comprimido(id,'COMPRIMIDA QA',qa.gzip_manifest(id,contenido,'gzip-distinto'),'obra')->>'revision'='1'
    from qa.gzip_casos where nombre='inicial'),'GZip: replay de creación usa identidad JSON, no detalles GZip');
select qa.exige((select public.myg_nube_guardar_comprimido(id,'d8100000-0000-0000-0000-000000000003',1,manifest)
    ='{"estado":"aplicada","revision":2,"operacion_id":"d8100000-0000-0000-0000-000000000003"}'::jsonb
    from qa.gzip_casos where nombre='nuevo'),'GZip: guardar usa CAS y ACK pequeño');
select qa.exige((select public.myg_nube_guardar_comprimido(id,'d8100000-0000-0000-0000-000000000003',1,
    qa.gzip_manifest(id,contenido,'recomprimido'))->>'revision'='2' from qa.gzip_casos where nombre='nuevo'),
    'GZip: replay aplicado conserva revisión original aunque se recomprima');
select qa.rechaza($$select public.myg_nube_guardar_comprimido(id,'d8100000-0000-0000-0000-000000000003',1,manifest)
    from qa.gzip_casos where nombre='tercero'$$,'22023','GZip: mismo UUID no acepta otro contenido lógico');
select qa.exige((select public.myg_nube_guardar_comprimido(id,'d8100000-0000-0000-0000-000000000004',1,manifest)->>'estado'='conflicto'
    from qa.gzip_casos where nombre='tercero'),'GZip: revisión atrasada produce conflicto duradero');
select qa.exige((select public.myg_nube_guardar_comprimido(id,'d8100000-0000-0000-0000-000000000005',2,manifest)->>'revision'='3'
    from qa.gzip_casos where nombre='tercero'),'GZip: siguiente edición progresa sin duplicación');
select qa.exige((select public.myg_nube_guardar_comprimido(id,'d8100000-0000-0000-0000-000000000004',1,manifest)->'contenido'
    =(select manifest from qa.gzip_casos where nombre='nuevo') from qa.gzip_casos where nombre='tercero'),
    'GZip: conflicto repetido devuelve el manifiesto congelado, no el actual');
select qa.exige((select public.myg_nube_abrir_comprimido(id,1)->'contenido'=manifest from qa.gzip_casos where nombre='inicial'),
    'GZip: historial conserva revisión inicial tras varias ediciones');

reset role;
insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values
('d8000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','lector');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.exige((select count(*)=3 from storage.objects where bucket_id='myg-nube-paquetes'),
    'GZip: lector puede descargar partes de todas las revisiones');
select qa.rechaza($$select public.myg_nube_guardar_comprimido(id,'d8100000-0000-0000-0000-000000000006',3,manifest)
    from qa.gzip_casos where nombre='tercero'$$,'42501','GZip: lector no guarda');
reset role;
delete from public.myg_nube_miembros where proyecto_id='d8000000-0000-0000-0000-000000000001'
    and usuario_id='00000000-0000-0000-0000-000000000004';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.exige((select count(*)=0 from storage.objects where bucket_id='myg-nube-paquetes'),
    'GZip: retirar miembro revoca también acceso histórico a Storage');
select qa.rechaza($$select public.myg_nube_abrir_comprimido('d8000000-0000-0000-0000-000000000001',1)$$,'42501',
    'GZip: historial no recupera permisos revocados');
reset role;
select qa.exige((select count(*)=3 from public.myg_nube_historial where proyecto_id='d8000000-0000-0000-0000-000000000001')
    and (select count(*)=3 from myg_nube_privado.paquetes_objetos where proyecto_id='d8000000-0000-0000-0000-000000000001'),
    'GZip: replays y conflictos no duplican revisiones ni referencias');
select 'PUBLICACION_COMPRIMIDA_SQL_APROBADA' resultado;
