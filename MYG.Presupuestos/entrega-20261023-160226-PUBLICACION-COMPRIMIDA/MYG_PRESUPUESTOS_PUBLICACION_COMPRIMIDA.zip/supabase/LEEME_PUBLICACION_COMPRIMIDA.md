# Publicación comprimida: instalación y prueba

23/10/2026, America/Lima. Esta entrega contiene código fuente y un parche SQL; no contiene ejecutables, bases de usuario, credenciales ni archivos privados del proyecto.

## A. Resultado

Las publicaciones nuevas pueden almacenar el proyecto y sus adjuntos dentro de un Gzip privado, dividido en partes inmutables de hasta 8 MiB. PostgreSQL recibe un manifiesto pequeño en creación y en guardados con los tres módulos habilitados. Al abrir, la aplicación descarga, comprueba tamaño y SHA-256 de partes/Gzip/JSON y reconstruye el contenido. La cola local, el UUID, los reintentos y los conflictos se conservan.

El reporte aportado por el usuario indicó **200,1 → 28,5 MiB**. El tamaño de esta implementación puede variar por contenido y versión del compresor; la ventana muestra el tamaño real de cada envío. El archivo JSON del pendiente local puede seguir pesando 200,1 MiB: es la copia de recuperación. No necesita comprimirlo, editarlo ni sustituirlo manualmente.

Los proyectos anteriores siguen usando su formato JSON. No se convierten silenciosamente al reintentar una creación ya confirmada. Un cliente antiguo no puede abrir ni sobrescribir un proyecto comprimido; los equipos que lo compartan necesitan esta actualización.

## B. Qué hacer con cada archivo

Copie las rutas de esta tabla en la carpeta donde está `MYG.Presupuestos.sln`. **Conserve la estructura de carpetas**. «Reemplazar» significa sustituir el código de esa ruta, conservando antes su copia actual. «Crear» significa añadirlo; el proyecto SDK incluye automáticamente los `.cs`, sin editar el `.csproj`.

| Ruta exacta | Acción requerida | Descripción |
|---|---|---|
| `MYG.Colaboracion/ClienteNubeComprimida.cs` | Crear | Subida, apertura, guardado, adjuntos autocontenidos y verificación del protocolo nuevo. |
| `MYG.Colaboracion/PaqueteComprimidoNube.cs` | Crear | Gzip por archivos temporales, partes, límites y SHA-256. |
| `MYG.Colaboracion/ClienteNubePublicacion.cs` | Reemplazar | Selección de publicación comprimida y confirmación pequeña con el mismo UUID. |
| `MYG.Colaboracion/ClienteNubeProyectos.cs` | Reemplazar | Apertura/guardado compatibles, negociación previa a solicitudes grandes y diagnóstico. |
| `MYG.Colaboracion/ClienteNubeCambios.cs` | Reemplazar | Usa el contenido congelado de la cola para el guardado comprimido. |
| `MYG.Colaboracion/ClienteNubeCapacidades.cs` | Reemplazar | Detecta la capacidad `publicacion_comprimida`. |
| `MYG.Colaboracion/ClienteNubeDiagnostico.cs` | Reemplazar | Identifica la fase de las RPC nuevas sin mostrar datos privados. |
| `MYG.Colaboracion/SincronizadorProyectoNube.cs` | Reemplazar | Conserva sincronización, pendientes, permisos y conflictos con adjuntos dentro del Gzip. |
| `MYG.Desktop/InicioNube.cs` | Reemplazar | Integra preparación, aviso y progreso con el tamaño comprimido real. |
| `MYG.PruebasNube/Program.cs` | Reemplazar | Incluye el selector `--publicacion-comprimida` y la suite nueva. |
| `MYG.PruebasNube/PublicacionComprimidaCheck.cs` | Crear | Pruebas de integridad, SQLite, reintentos, conflictos, adjuntos y compatibilidad. |
| `MYG.PruebasNube/PublicacionSinEsperaClienteCheck.cs` | Crear si falta; reemplazar con esta versión si ya existe | Dependencia conservada de la prueba del parche 27 que utiliza `Program.cs`. |
| `MYG.PruebasNube/CapacidadesNubeCheck.cs` | Reemplazar | Conserva las verificaciones previas de capacidades. |
| `MYG.PruebasNube/DiagnosticoRecursosNubeCheck.cs` | Reemplazar | Conserva las verificaciones previas de diagnóstico. |
| `MYG.PruebasNube/PublicacionLigeraCheck.cs` | Reemplazar | Conserva las verificaciones previas de publicación y recuperación. |
| `supabase/migraciones/20261028_publicacion_comprimida.sql` | Crear y ejecutar **completo** en Supabase SQL Editor | Instala bucket privado, RPC, permisos, historial y protección de clientes antiguos. |
| `supabase/pruebas/publicacion_comprimida.sql` | Crear; solo conservar para desarrollo | Prueba SQL para PostgreSQL desechable. **No ejecutar en Supabase real.** |
| `scripts/pruebas/Probar-PublicacionComprimidaHTTP.py` | Crear; ejecución opcional de desarrollo | Runner Docker de RPC/RLS. No necesita ejecutarlo para usar MYG. |
| `supabase/diagnosticos/RESULTADOS_PUBLICACION_COMPRIMIDA.json` | Crear; consultar si necesita evidencia | Resumen verificable de las pruebas; no es un parche ni se ejecuta. |
| `supabase/CONTINUIDAD_PUBLICACION_COMPRIMIDA.md` | Crear; conservar | Decisiones, resultados y siguiente paso para retomar el trabajo. |
| `supabase/LEEME_PUBLICACION_COMPRIMIDA.md` | Crear; leer | Este instructivo. |

Los demás cambios anteriores del repositorio se conservan. Esta entrega no sustituye las bases SQLite ni el contenido de `%LOCALAPPDATA%\MYG\Nube\trabajo\publicaciones`.

## C. Descarga

El enlace público del ZIP y su SHA-256 se entregan en el mensaje final después de descargar y verificar el archivo publicado. El ZIP conserva las rutas de la tabla. No requiere instalar Python para publicar desde MYG.

## D. Instalación manual, en este orden

1. Cierre MYG.Presupuestos. Copie el contenido del ZIP sobre la carpeta del código, manteniendo las rutas de la tabla.
2. En Supabase → SQL Editor, abra una consulta nueva, copie **todo** `supabase/migraciones/20261028_publicacion_comprimida.sql` y pulse **Run**. Su parche 27 ya está instalado: **no vuelva a ejecutar 26 ni 27**. El resultado esperado es `PUBLICACION_COMPRIMIDA_INSTALADA`, `bucket_privado = true` y `partes_inmutables = true`. Si aparece un error, conserve el texto exacto: la transacción revierte la instalación incompleta.
3. Compile e inicie la aplicación actualizada. Desde PowerShell situado donde está la solución:

   ```powershell
   dotnet build .\MYG.Desktop\MYG.Desktop.csproj -c Release
   dotnet run --project .\MYG.Desktop\MYG.Desktop.csproj -c Release --no-build
   ```

   También puede abrir la solución en Visual Studio, seleccionar `MYG.Desktop` como proyecto de inicio, compilar en Release e iniciar. Utilice la versión recién compilada.
4. En Nube MYG, conecte su cuenta y abra **Publicaciones pendientes → Reintentar** sobre el intento existente. No retire el pendiente ni cambie su identificador. La aplicación mostrará el tamaño comprimido y las partes enviadas. Si ese UUID ya corresponde a un proyecto JSON confirmado, conserva su formato anterior.
5. Tras la confirmación, pulse Actualizar y abra el proyecto. Compruebe sus obras, partidas, importes, adjuntos y tablas. Descargue una copia y ábrala localmente. Pruebe un cambio pequeño y guárdelo. En un proyecto compartido, pruebe también apertura desde otro equipo actualizado y un editor con módulos restringidos.

## E. Configuración adicional

El parche crea el bucket privado `myg-nube-paquetes` con límite de 8 MiB por objeto. No necesita crearlo manualmente ni hacerlo público, modificar el límite global de Storage, habilitar Gzip HTTP, cambiar la instancia ni proporcionar claves administrativas a MYG. Se utiliza la configuración y sesión actuales de la aplicación. Se conserva el límite de 300 MiB para el JSON autocontenido y 320 MiB para Gzip.

## F. Verificaciones reales

- Compilación completa de la solución y aplicación de escritorio con .NET 10; resultados exactos en el JSON adjunto.
- Suite de nube completa y selector comprimido: HTTP simulado, Gzip/SHA, SQLite y cola durable reales. Incluye pérdida de ACK después del commit, cliente/almacén nuevos, conflictos congelados tras avanzar la revisión, cambios de identidad, revocación de rol/módulo, Storage Duplicate 400/409, clientes antiguos, adjuntos entre colaboradores y guardado grande desde sesión nueva.
- PostgreSQL 17/PostgREST 16.5 reales en Docker desechable: 120 combinaciones de permisos, replay, historial, RLS, partes inmutables, textos de validación falsificados y NOWAIT. Storage se representa con archivos locales y tabla/RLS real: **no es una ejecución del servicio Supabase Storage desplegado**.
- La prueba sintética de 209.835.827 bytes recuperó los bytes exactos; creación mediante RPC de 4.899 bytes y ACK de 273 bytes. Su Gzip fue 158.953.409 bytes, con 19 partes: es un contenido de alta entropía y **no corresponde al proyecto privado** cuyo reporte indicó 28,5 MiB.
- No se repitieron los benchmarks antiguos de JSONB grande. Las repeticiones de pruebas nuevas se limitaron a cambios o fallos concretos y se conservaron los artefactos previos.

## G. Commit y Push del código

Esta entrega no publica cambios en `MYG.Presupuestos`. Después de aplicar los archivos y revisar `git diff`, seleccione las rutas de esta tabla en Visual Studio/Git, haga Commit con una descripción como `Agregar publicación comprimida con recuperación e integridad`, y use Push siguiendo su flujo habitual. Evite añadir bases privadas, archivos del pendiente, credenciales o salidas `bin/obj`.

## H. Límites y siguiente comprobación

- **Pendiente:** instalación y prueba visual en su Supabase/Windows/Revit reales. Desde este entorno no se modificó su servidor.
- Los editores con algún módulo restringido conservan la validación completa en PostgreSQL mediante los textos anterior/nuevo ligados a los manifiestos por SHA-256. Sus guardados todavía pueden consumir memoria/CPU y tiempo significativos en Nano; la ruta de publicación y del propietario con todos los módulos evita el gran JSONB.
- El servidor valida permisos, manifiestos y referencias inmutables; la comprobación de que el Gzip corresponde al JSON declarado se realiza al descargar en el cliente. Los datos compactos se validan también en el cliente. No se atribuye a PostgreSQL una descompresión o validación semántica del blob opaco.
- Historial y subidas incompletas conservan sus partes; no hay eliminación automática que ponga en riesgo la recuperación. Consumen la cuota de Storage. Los proyectos JSON existentes no se migran con este parche.
- Los fallos HTTP 502/520, los cierres no limpios y el archivado WAL históricos siguen sin causa demostrada. La prueba nueva no permite afirmar agotamiento de memoria en su servidor ni una relación causal con WAL.
- Si falla la nueva ruta, conserve el pendiente y comparta fase/RPC, HTTP, referencia y hora/zona de ese intento, junto con los eventos coincidentes de API/Storage/PostgreSQL e infraestructura y métricas de memoria/CPU. Eso permite distinguir subida de partes, confirmación y apertura sin repetir las preguntas anteriores. No comparta claves ni datos de sus obras.
