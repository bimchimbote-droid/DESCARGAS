# Continuidad: publicación comprimida

Actualización: 23/10/2026, zona America/Lima. Implementación y validaciones terminadas. No instalada en Supabase real desde este entorno.

## Decisiones resueltas

- La prueba aportada por el usuario indica 209.835.827 bytes JSON → 29.868.974 bytes Gzip (200,1 → 28,5 MiB), con SHA-256 de ida y vuelta idéntico. No se dispone aquí de su proyecto privado para repetirla.
- Bucket privado nuevo `myg-nube-paquetes`; Gzip dividido en partes inmutables de hasta 8 MiB. PostgreSQL conserva un manifiesto pequeño. No enviar Gzip directamente a una RPC JSON.
- Creación y guardado con los tres módulos habilitados usan manifiestos pequeños. Un editor con módulos restringidos envía además los textos anterior/nuevo: el servidor verifica sus hashes y conserva `validar_contenido` y `exigir_modulos`. Esta ruta conserva un coste JSONB significativo; no se relajan permisos para ocultarlo.
- Modo de almacenamiento inmutable por proyecto. Los proyectos JSON existentes continúan en JSON. Las RPC antiguas rechazan proyectos comprimidos con `MGC01`.
- La cola durable y el pendiente local conservan JSON, UUID y revisión. Reintentar no requiere retirar ni recrear la publicación. El transporte no modifica el SQLite original.
- La idempotencia identifica el JSON por SHA-256/longitud; no exige que dos versiones del compresor generen el mismo Gzip. Se conserva siempre el primer snapshot confirmado.
- Los adjuntos se hidratan mediante acceso autorizado y SHA, y quedan dentro del Gzip con `Almacen` vacío. La nueva ruta no depende de vincular referencias ocultas al bucket anterior; no se inventó ni reemplazó el validador productivo ausente del repositorio.
- Las entradas directas de creación/guardado de más de 127 MiB negocian capacidades antes de construir una RPC grande. La apertura desde sesión nueva descubre el formato mediante el rechazo seguro `MGC01`; los clientes anteriores permanecen compatibles con sus proyectos JSON.
- Límite lógico 300 MiB; comprimido 320 MiB; máximo 40 partes. Apertura verifica rutas, tamaño, hashes de cada parte, Gzip y JSON antes de materializar.
- El parche 27 ya está instalado y confirmado por el usuario. No volver a ejecutar 26 encima de 27. Los HTTP 502/520 y las interrupciones reales siguen sin causa demostrada; esta implementación evita el gran JSONB en la ruta de publicación y no demuestra su causa histórica.

## Avance recuperado

Código nuevo existente: `MYG.Colaboracion/PaqueteComprimidoNube.cs`, `ClienteNubeComprimida.cs`, `MYG.PruebasNube/PublicacionComprimidaCheck.cs`; migración y regresión SQL `20261028_publicacion_comprimida.sql`, `publicacion_comprimida.sql`; runner `scripts/pruebas/Probar-PublicacionComprimidaHTTP.py`.

Intercepciones ya escritas en cliente de publicación/apertura/guardado/cambios/capacidades/diagnóstico, `MYG.Desktop/InicioNube.cs` y selector de pruebas. Se conservan los demás cambios previos de `git status`; no restaurarlos ni borrarlos.

## Validaciones de esta implementación

- `build-solucion-final.log`: solución completa Release .NET 10.0.100, incluidos Desktop/Revit y pruebas; cero errores y advertencias.
- `pruebas-nube-final.log`: 39 grupos principales, 982 comprobaciones del contrato principal y las suites de integración detalladas en el log. La suite comprimida final aprobó 13 grupos/839 comprobaciones; no sumar los contadores internos como si fueran el contador principal.
- `http/validacion4/results.json`: 904 comprobaciones, 23 SQL, 514 RPC; 120 combinaciones (15 mutaciones × ocho máscaras). Carga sintética 209.835.827 bytes → 158.953.409 Gzip, 19 partes, roundtrip exacto. RPC crear 4.899 bytes, ACK 273; abrir 47 bytes, manifiesto 5.197. Esta tasa sintética no corresponde al reporte privado 200,1 → 28,5 MiB.
- `http/adicionales5/results.json`: 119 comprobaciones adicionales, 45 RPC; no se repitieron ni la carga grande ni la matriz. NOWAIT real crear 3,4 ms/guardar 1,7 ms, código 55006. Textos SHA falsos, manifiesto ajeno, revocación, preservación de trigger/COMMENT y cuerpos CRLF comprobados. Los 23 checks SQL se revalidaron al cambiar el instalador; siguen siendo 23 casos.
- PostgreSQL y PostgREST reales, con 512 MiB independientes; sin OOM registrado en PostgreSQL y sin terminación/reinicio observado en PostgREST durante la prueba. Storage de blobs emulado; tabla de metadatos y RLS reales. No equivale a probar la infraestructura Nano gestionada.
- Fallos iniciales de preparación/instrumentación conservados: permisos de copia del fixture, MD5 inicial del instalador y lectura cgroup distroless. No se trataron como defectos ni como pruebas aprobadas del servicio real.
- Defectos corregidos: manejo de Duplicate Storage 400/409 sin doble lectura de stream, revocación del uploader, replay tras cambiar máscaras, ACK inicial/historial, retorno autocontenido de la API genérica y negociación previa al guardado grande desde sesión nueva.
- De 31 archivos de entregas anteriores, 27 mantienen su SHA; cuatro fuentes se ampliaron intencionalmente para la integración. Los demás cambios del usuario no se restauraron ni eliminaron.

Resultados y logs se guardan fuera del repositorio en `/workspace/.cloud-setup/myg/implementacion-compresion/`. El estado inicial de los archivos está en `estado-inicial-integracion.json`. Los ensayos antiguos siguen en `investigacion-nano`; no repetir sus benchmarks de JSON grande.

## Próximo paso concreto

Las instrucciones y la tabla exacta de los 21 archivos están en `supabase/LEEME_PUBLICACION_COMPRIMIDA.md`. El resumen transportable está en `supabase/diagnosticos/RESULTADOS_PUBLICACION_COMPRIMIDA.json`.

La publicación del ZIP se registra después de crearlo en `/workspace/.cloud-setup/myg/implementacion-compresion/entrega/manifest.json` y `publication.json`. Si este último confirma `download_verified: true`, no volver a publicar ni repetir las suites: comunicar el enlace y proceder a la comprobación manual. Si falta, completar solamente publicación/descarga/verificación de esa entrega. No publicar código en `MYG.Presupuestos` automáticamente.

El siguiente paso funcional corresponde a Supabase real: ejecutar **solo 28**, compilar la aplicación actualizada y reintentar el pendiente existente sin retirarlo ni cambiar su UUID. Comprobar apertura, copia descargada, guardado y colaboración. Windows/Revit visual y Storage real siguen pendientes del usuario. Los HTTP 502/520, cierres no limpios y WAL históricos no tienen causa demostrada; si persisten, correlacionar fase/RPC/HTTP/referencia/hora con los logs y métricas del nuevo intento, sin repetir las preguntas anteriores ni atribuir OOM sin evidencia.
