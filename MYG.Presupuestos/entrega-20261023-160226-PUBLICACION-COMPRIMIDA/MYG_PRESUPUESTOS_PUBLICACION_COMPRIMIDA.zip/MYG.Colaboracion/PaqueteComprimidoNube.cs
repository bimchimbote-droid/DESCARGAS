using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace MYG.Colaboracion;

/// <summary>
/// Transporte sin pérdida de un documento de proyecto. El JSON durable del cliente
/// se conserva; este formato se usa exclusivamente al transferirlo a la nube.
/// </summary>
public static class PaqueteComprimidoNube
{
    public const long MaxBytesJson = 300L * 1024 * 1024;
    public const long MaxBytesGzip = 320L * 1024 * 1024;
    public const int BytesParte = 8 * 1024 * 1024;
    public const int MaxPartes = 40;
    public const int MaxProfundidad = 128;
    private const int BytesBuffer = 128 * 1024;
    private static readonly UTF8Encoding Utf8Estricto = new(false, true);

    /// <summary>
    /// Serializa una sola vez y comprime mediante archivos temporales privados.
    /// El llamador debe disponer el resultado después de terminar las subidas.
    /// </summary>
    public static async Task<PaqueteComprimidoPreparado> CrearAsync(JsonElement contenido,
        Guid actor, Guid proyecto, CancellationToken ct = default)
    {
        if (contenido.ValueKind != JsonValueKind.Object)
            throw Invalido("El contenido del proyecto debe ser un objeto JSON.");
        if (actor == Guid.Empty || proyecto == Guid.Empty)
            throw Invalido("El actor y el proyecto deben tener identificadores válidos.");
        ct.ThrowIfCancellationRequested();
        string directorio = CrearDirectorioTemporal();
        string json = Path.Combine(directorio, "contenido.json");
        string gzip = Path.Combine(directorio, "contenido.gz");
        try
        {
            await using (FileStream archivo = NuevoArchivo(json))
            using (var limitado = new EscrituraLimitada(archivo, MaxBytesJson, ct))
            using (var writer = new Utf8JsonWriter(limitado, new JsonWriterOptions
            {
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                MaxDepth = MaxProfundidad
            }))
            {
                contenido.WriteTo(writer);
                await writer.FlushAsync(ct).ConfigureAwait(false);
            }

            long bytesJson = new FileInfo(json).Length;
            string shaJson;
            using (IncrementalHash hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256))
            await using (FileStream entrada = AbrirArchivo(json))
            await using (FileStream salida = NuevoArchivo(gzip))
            using (var limitado = new EscrituraLimitada(salida, MaxBytesGzip, ct))
            {
                await using (var compresor = new GZipStream(limitado, CompressionLevel.SmallestSize, leaveOpen: true))
                {
                    byte[] buffer = new byte[BytesBuffer];
                    int leidos;
                    while ((leidos = await entrada.ReadAsync(buffer, ct).ConfigureAwait(false)) != 0)
                    {
                        hash.AppendData(buffer, 0, leidos);
                        await compresor.WriteAsync(buffer.AsMemory(0, leidos), ct).ConfigureAwait(false);
                    }
                }
                shaJson = Convert.ToHexStringLower(hash.GetHashAndReset());
            }

            long bytesGzip = new FileInfo(gzip).Length;
            if (bytesGzip < 1 || bytesGzip > MaxBytesGzip)
                throw Invalido("El paquete comprimido supera el límite permitido.");
            var partes = new List<DatosParte>();
            string prefijo = actor.ToString("D") + "/" + proyecto.ToString("N") + "/";
            string shaGzip;
            using (IncrementalHash hashTotal = IncrementalHash.CreateHash(HashAlgorithmName.SHA256))
            await using (FileStream entrada = AbrirArchivo(gzip))
            {
                byte[] buffer = new byte[BytesBuffer];
                long posicion = 0;
                while (posicion < bytesGzip)
                {
                    using IncrementalHash hashParte = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                    int bytesParte = (int)Math.Min(BytesParte, bytesGzip - posicion);
                    int restantes = bytesParte;
                    while (restantes > 0)
                    {
                        int leidos = await entrada.ReadAsync(buffer.AsMemory(0, Math.Min(buffer.Length, restantes)), ct)
                            .ConfigureAwait(false);
                        if (leidos == 0) throw Invalido("El archivo comprimido temporal está incompleto.");
                        hashParte.AppendData(buffer, 0, leidos);
                        hashTotal.AppendData(buffer, 0, leidos);
                        restantes -= leidos;
                    }
                    string sha = Convert.ToHexStringLower(hashParte.GetHashAndReset());
                    partes.Add(new DatosParte(prefijo + sha, sha, bytesParte, posicion));
                    posicion += bytesParte;
                }
                shaGzip = Convert.ToHexStringLower(hashTotal.GetHashAndReset());
            }
            if (partes.Count > MaxPartes) throw Invalido("El paquete tiene demasiadas partes.");
            JsonElement manifiesto = JsonSerializer.SerializeToElement(new
            {
                formato = "MYG_ARCHIVO_GZIP",
                version = 1,
                sha256_json = shaJson,
                bytes_json = bytesJson,
                sha256_gzip = shaGzip,
                bytes_gzip = bytesGzip,
                partes = partes.Select(parte => new { ruta = parte.Ruta, sha256 = parte.Sha256, bytes = parte.Bytes })
            });
            return new PaqueteComprimidoPreparado(directorio, json, gzip, manifiesto,
                partes, bytesJson, bytesGzip, shaJson);
        }
        catch
        {
            BorrarDirectorioTemporal(directorio);
            throw;
        }
    }

    /// <summary>
    /// Valida el manifiesto antes de descargar y los tamaños y SHA-256 antes de
    /// analizar el JSON. Cada stream devuelto por descargar pertenece al codec.
    /// </summary>
    public static async Task<JsonElement> LeerAsync(JsonElement manifiesto, Guid proyecto,
        Func<string, CancellationToken, Task<Stream>> descargar, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(descargar);
        ct.ThrowIfCancellationRequested();
        DatosManifiesto datos = LeerManifiesto(manifiesto, proyecto);
        string directorio = CrearDirectorioTemporal();
        string gzip = Path.Combine(directorio, "contenido.gz");
        string json = Path.Combine(directorio, "contenido.json");
        try
        {
            using (IncrementalHash hashTotal = IncrementalHash.CreateHash(HashAlgorithmName.SHA256))
            await using (FileStream salida = NuevoArchivo(gzip))
            {
                byte[] buffer = new byte[BytesBuffer];
                foreach (DatosParte parte in datos.Partes)
                {
                    ct.ThrowIfCancellationRequested();
                    using IncrementalHash hashParte = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                    await using Stream entrada = await descargar(parte.Ruta, ct).ConfigureAwait(false)
                        ?? throw Invalido("No se recibió una parte del proyecto.");
                    if (!entrada.CanRead) throw Invalido("La parte descargada no se puede leer.");
                    int restantes = parte.Bytes;
                    while (restantes > 0)
                    {
                        int leidos = await entrada.ReadAsync(buffer.AsMemory(0, Math.Min(buffer.Length, restantes)), ct)
                            .ConfigureAwait(false);
                        if (leidos == 0) throw Invalido("Una parte descargada está incompleta.");
                        hashParte.AppendData(buffer, 0, leidos);
                        hashTotal.AppendData(buffer, 0, leidos);
                        await salida.WriteAsync(buffer.AsMemory(0, leidos), ct).ConfigureAwait(false);
                        restantes -= leidos;
                    }
                    if (await entrada.ReadAsync(buffer.AsMemory(0, 1), ct).ConfigureAwait(false) != 0)
                        throw Invalido("Una parte descargada supera el tamaño declarado.");
                    if (!CoincideHash(hashParte, parte.Sha256))
                        throw Invalido("Una parte descargada no supera la comprobación SHA-256.");
                }
                if (salida.Length != datos.BytesGzip || !CoincideHash(hashTotal, datos.ShaGzip))
                    throw Invalido("El paquete comprimido no coincide con el manifiesto.");
            }

            using (IncrementalHash hashJson = IncrementalHash.CreateHash(HashAlgorithmName.SHA256))
            await using (FileStream entrada = AbrirArchivo(gzip))
            await using (var descompresor = new GZipStream(entrada, CompressionMode.Decompress, leaveOpen: false))
            await using (FileStream salida = NuevoArchivo(json))
            {
                byte[] buffer = new byte[BytesBuffer];
                long escritos = 0;
                while (true)
                {
                    // Se permite leer un byte adicional para detectar una expansión que
                    // exceda el tamaño declarado antes de escribirla en disco o analizarla.
                    int maxLectura = (int)Math.Min(buffer.Length, datos.BytesJson - escritos + 1);
                    int leidos = await descompresor.ReadAsync(buffer.AsMemory(0, maxLectura), ct).ConfigureAwait(false);
                    if (leidos == 0) break;
                    if (escritos + leidos > datos.BytesJson)
                        throw Invalido("El JSON descomprimido supera el tamaño declarado.");
                    hashJson.AppendData(buffer, 0, leidos);
                    await salida.WriteAsync(buffer.AsMemory(0, leidos), ct).ConfigureAwait(false);
                    escritos += leidos;
                }
                if (escritos != datos.BytesJson || !CoincideHash(hashJson, datos.ShaJson))
                    throw Invalido("El JSON descomprimido no coincide con el manifiesto.");
            }

            await using FileStream archivoJson = AbrirArchivo(json);
            using JsonDocument documento = await JsonDocument.ParseAsync(archivoJson, new JsonDocumentOptions
            {
                MaxDepth = MaxProfundidad,
                CommentHandling = JsonCommentHandling.Disallow,
                AllowTrailingCommas = false
            }, ct).ConfigureAwait(false);
            if (documento.RootElement.ValueKind != JsonValueKind.Object)
                throw Invalido("El contenido descomprimido debe ser un objeto JSON.");
            ct.ThrowIfCancellationRequested();
            return documento.RootElement.Clone();
        }
        catch (JsonException ex)
        {
            throw new InvalidDataException("El paquete no contiene un objeto JSON válido dentro de los límites permitidos.", ex);
        }
        finally
        {
            BorrarDirectorioTemporal(directorio);
        }
    }

    private static DatosManifiesto LeerManifiesto(JsonElement manifiesto, Guid proyecto)
    {
        if (proyecto == Guid.Empty) throw Invalido("El identificador del proyecto no es válido.");
        Dictionary<string, JsonElement> campos = CamposExactos(manifiesto,
            "formato", "version", "sha256_json", "bytes_json", "sha256_gzip", "bytes_gzip", "partes");
        if (Texto(campos["formato"]) != "MYG_ARCHIVO_GZIP" || Entero(campos["version"]) != 1)
            throw Invalido("El formato comprimido del proyecto no está soportado.");
        string shaJson = Hash(campos["sha256_json"]);
        string shaGzip = Hash(campos["sha256_gzip"]);
        long bytesJson = Entero(campos["bytes_json"]);
        long bytesGzip = Entero(campos["bytes_gzip"]);
        if (bytesJson < 1 || bytesJson > MaxBytesJson || bytesGzip < 1 || bytesGzip > MaxBytesGzip)
            throw Invalido("El manifiesto declara tamaños fuera de los límites permitidos.");
        JsonElement lista = campos["partes"];
        if (lista.ValueKind != JsonValueKind.Array || lista.GetArrayLength() < 1 || lista.GetArrayLength() > MaxPartes)
            throw Invalido("El manifiesto debe contener una lista válida de partes.");
        int cantidad = lista.GetArrayLength();
        if (cantidad != (bytesGzip + BytesParte - 1) / BytesParte)
            throw Invalido("La cantidad de partes no coincide con el tamaño del paquete.");
        var partes = new List<DatosParte>(cantidad);
        var repetidas = new Dictionary<string, (string Sha, int Bytes)>(StringComparer.Ordinal);
        string? actorEsperado = null;
        long posicion = 0;
        foreach (JsonElement elemento in lista.EnumerateArray())
        {
            Dictionary<string, JsonElement> parte = CamposExactos(elemento, "ruta", "sha256", "bytes");
            string ruta = Texto(parte["ruta"]);
            string sha = Hash(parte["sha256"]);
            long bytes = Entero(parte["bytes"]);
            int esperados = (int)Math.Min(BytesParte, bytesGzip - posicion);
            if (bytes != esperados || bytes < 1 || bytes > BytesParte)
                throw Invalido("El tamaño de una parte no coincide con su posición en el paquete.");
            string[] segmentos = ruta.Split('/');
            if (segmentos.Length != 3
                || !Guid.TryParseExact(segmentos[0], "D", out Guid actor) || actor == Guid.Empty
                || segmentos[0] != actor.ToString("D")
                || segmentos[1] != proyecto.ToString("N")
                || segmentos[2] != sha)
                throw Invalido("La ruta de una parte no es canónica o pertenece a otro proyecto.");
            actorEsperado ??= segmentos[0];
            if (segmentos[0] != actorEsperado)
                throw Invalido("Las partes del proyecto deben tener el mismo actor de origen.");
            if (repetidas.TryGetValue(ruta, out var anterior)
                && (anterior.Sha != sha || anterior.Bytes != bytes))
                throw Invalido("Una ruta se repite con descripciones incompatibles.");
            repetidas[ruta] = (sha, (int)bytes);
            partes.Add(new DatosParte(ruta, sha, (int)bytes, posicion));
            posicion += bytes;
        }
        if (posicion != bytesGzip) throw Invalido("La suma de las partes no coincide con el tamaño del paquete.");
        return new DatosManifiesto(shaJson, bytesJson, shaGzip, bytesGzip, partes);
    }

    private static Dictionary<string, JsonElement> CamposExactos(JsonElement objeto, params string[] nombres)
    {
        if (objeto.ValueKind != JsonValueKind.Object) throw Invalido("El manifiesto contiene un objeto no válido.");
        var campos = new Dictionary<string, JsonElement>(StringComparer.Ordinal);
        foreach (JsonProperty propiedad in objeto.EnumerateObject())
            if (!nombres.Contains(propiedad.Name, StringComparer.Ordinal) || !campos.TryAdd(propiedad.Name, propiedad.Value))
                throw Invalido("El manifiesto contiene campos desconocidos o duplicados.");
        if (campos.Count != nombres.Length) throw Invalido("El manifiesto está incompleto.");
        return campos;
    }

    private static string Texto(JsonElement valor) => valor.ValueKind == JsonValueKind.String
        ? valor.GetString()! : throw Invalido("Un campo de texto del manifiesto no es válido.");

    private static long Entero(JsonElement valor) => valor.ValueKind == JsonValueKind.Number && valor.TryGetInt64(out long numero)
        ? numero : throw Invalido("Un tamaño o versión del manifiesto no es un entero válido.");

    private static string Hash(JsonElement valor)
    {
        string texto = Texto(valor);
        if (texto.Length != 64 || texto.Any(c => !(c is >= '0' and <= '9' or >= 'a' and <= 'f')))
            throw Invalido("Un SHA-256 del manifiesto no es válido.");
        return texto;
    }

    private static bool CoincideHash(IncrementalHash hash, string esperado) =>
        string.Equals(Convert.ToHexStringLower(hash.GetHashAndReset()), esperado, StringComparison.Ordinal);

    internal static FileStream AbrirArchivo(string ruta) => new(ruta, FileMode.Open, FileAccess.Read,
        FileShare.Read, BytesBuffer, FileOptions.Asynchronous | FileOptions.SequentialScan);

    private static FileStream NuevoArchivo(string ruta) => new(ruta, FileMode.CreateNew, FileAccess.Write,
        FileShare.None, BytesBuffer, FileOptions.Asynchronous | FileOptions.SequentialScan);

    private static string CrearDirectorioTemporal()
    {
        string ruta = Path.Combine(Path.GetTempPath(), "myg-paquete-comprimido-" + Guid.NewGuid().ToString("N"));
        if (OperatingSystem.IsWindows()) Directory.CreateDirectory(ruta);
        else Directory.CreateDirectory(ruta, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        return ruta;
    }

    internal static void BorrarDirectorioTemporal(string ruta)
    {
        try { Directory.Delete(ruta, recursive: true); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private static InvalidDataException Invalido(string mensaje) => new(mensaje);

    internal sealed record DatosParte(string Ruta, string Sha256, int Bytes, long Posicion);
    private sealed record DatosManifiesto(string ShaJson, long BytesJson, string ShaGzip,
        long BytesGzip, IReadOnlyList<DatosParte> Partes);

    /// <summary>Cuenta las escrituras antes de que lleguen al disco y conserva el stream subyacente.</summary>
    private sealed class EscrituraLimitada(Stream archivo, long maximo, CancellationToken cancelacion) : Stream
    {
        private long escritos;
        public override bool CanRead => false;
        public override bool CanSeek => false;
        public override bool CanWrite => true;
        public override long Length => escritos;
        public override long Position { get => escritos; set => throw new NotSupportedException(); }
        public override void Flush() { cancelacion.ThrowIfCancellationRequested(); archivo.Flush(); }
        public override Task FlushAsync(CancellationToken cancellationToken) => archivo.FlushAsync(cancellationToken);
        public override void Write(byte[] buffer, int offset, int count) => Write(buffer.AsSpan(offset, count));
        public override void Write(ReadOnlySpan<byte> buffer)
        {
            Comprobar(buffer.Length);
            archivo.Write(buffer);
            escritos += buffer.Length;
        }
        public override async ValueTask WriteAsync(ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Comprobar(buffer.Length);
            await archivo.WriteAsync(buffer, cancellationToken).ConfigureAwait(false);
            escritos += buffer.Length;
        }
        public override Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken) =>
            WriteAsync(buffer.AsMemory(offset, count), cancellationToken).AsTask();
        private void Comprobar(int bytes)
        {
            cancelacion.ThrowIfCancellationRequested();
            if (bytes > maximo - escritos) throw Invalido("El contenido supera el límite de tamaño permitido.");
        }
        public override int Read(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
    }

    internal static Encoding CodificacionJson => Utf8Estricto;
}

/// <summary>Recursos temporales de un envío; Dispose no altera la publicación durable local.</summary>
public sealed class PaqueteComprimidoPreparado : IDisposable
{
    private readonly string directorio;
    private readonly string json;
    private readonly string gzip;
    private bool dispuesto;
    public JsonElement Manifiesto { get; }
    public IReadOnlyList<ParteComprimidaNube> Partes { get; }
    public long BytesJson { get; }
    public long BytesGzip { get; }
    public string ShaJson { get; }

    internal PaqueteComprimidoPreparado(string directorio, string json, string gzip, JsonElement manifiesto,
        IReadOnlyList<PaqueteComprimidoNube.DatosParte> partes, long bytesJson, long bytesGzip, string shaJson)
    {
        this.directorio = directorio;
        this.json = json;
        this.gzip = gzip;
        Manifiesto = manifiesto;
        BytesJson = bytesJson;
        BytesGzip = bytesGzip;
        ShaJson = shaJson;
        Partes = partes.Select(parte => new ParteComprimidaNube(this,
            parte.Ruta, parte.Sha256, parte.Bytes, parte.Posicion)).ToList().AsReadOnly();
    }

    /// <summary>Obtiene el mismo texto UTF-8 que se comprimió, solo cuando una RPC restringida lo necesita.</summary>
    public async Task<string> LeerTextoJsonAsync(CancellationToken ct = default)
    {
        ComprobarDisponible();
        return await File.ReadAllTextAsync(json, PaqueteComprimidoNube.CodificacionJson, ct).ConfigureAwait(false);
    }

    internal Stream AbrirParte(long posicion, int bytes)
    {
        ComprobarDisponible();
        return new LecturaDeParte(PaqueteComprimidoNube.AbrirArchivo(gzip), posicion, bytes);
    }

    private void ComprobarDisponible() => ObjectDisposedException.ThrowIf(dispuesto, this);

    public void Dispose()
    {
        if (dispuesto) return;
        dispuesto = true;
        PaqueteComprimidoNube.BorrarDirectorioTemporal(directorio);
    }

    private sealed class LecturaDeParte : Stream
    {
        private readonly FileStream archivo;
        private readonly int bytes;
        private int leidos;
        private bool dispuesto;
        internal LecturaDeParte(FileStream archivo, long posicion, int bytes)
        {
            this.archivo = archivo;
            this.bytes = bytes;
            archivo.Position = posicion;
        }
        public override bool CanRead => !dispuesto;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length { get { ComprobarDisponible(); return bytes; } }
        public override long Position { get { ComprobarDisponible(); return leidos; } set => throw new NotSupportedException(); }
        public override int Read(byte[] buffer, int offset, int count) => Read(buffer.AsSpan(offset, count));
        public override int Read(Span<byte> buffer)
        {
            ComprobarDisponible();
            int resultado = archivo.Read(buffer[..Math.Min(buffer.Length, bytes - leidos)]);
            leidos += resultado;
            return resultado;
        }
        public override async ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
        {
            ComprobarDisponible();
            int resultado = await archivo.ReadAsync(buffer[..Math.Min(buffer.Length, bytes - leidos)], cancellationToken)
                .ConfigureAwait(false);
            leidos += resultado;
            return resultado;
        }
        public override Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken) =>
            ReadAsync(buffer.AsMemory(offset, count), cancellationToken).AsTask();
        private void ComprobarDisponible() => ObjectDisposedException.ThrowIf(dispuesto, this);
        protected override void Dispose(bool disposing)
        {
            if (disposing && !dispuesto) archivo.Dispose();
            dispuesto = true;
            base.Dispose(disposing);
        }
        public override async ValueTask DisposeAsync()
        {
            if (!dispuesto) await archivo.DisposeAsync().ConfigureAwait(false);
            dispuesto = true;
            GC.SuppressFinalize(this);
        }
        public override void Flush() { ComprobarDisponible(); }
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
    }
}

/// <summary>Parte inmutable de hasta 8 MiB del Gzip preparado.</summary>
public sealed class ParteComprimidaNube
{
    private readonly PaqueteComprimidoPreparado propietario;
    private readonly long posicion;
    public string Ruta { get; }
    public string Sha256 { get; }
    public int Bytes { get; }
    internal ParteComprimidaNube(PaqueteComprimidoPreparado propietario, string ruta, string sha256, int bytes, long posicion)
    {
        this.propietario = propietario;
        this.posicion = posicion;
        Ruta = ruta;
        Sha256 = sha256;
        Bytes = bytes;
    }
    public Stream AbrirLectura() => propietario.AbrirParte(posicion, Bytes);
}
