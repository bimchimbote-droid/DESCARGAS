#nullable enable
using System.Text;
using System.Text.Json;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    /// <summary>Consulta permisos y revisión sin descargar el contenido de la base.</summary>
    public Task<ProyectoNube> ConsultarRevisionProyectoAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return EjecutarRpcNubeAsync("myg_nube_revision", new { p_id = id },
            raiz => LeerProyectoNube(raiz, requiereContenido: false, esperado: id), ct);
    }

    /// <summary>
    /// Envía solo los componentes modificados. El servidor aplica el cambio de forma
    /// atómica contra la revisión indicada y vuelve a comprobar los permisos actuales.
    /// </summary>
    public Task<RespuestaGuardarNube> GuardarCambiosProyectoAsync(Guid id, Guid operacion, long revision,
        JsonElement anterior, JsonElement nuevo, CancellationToken ct = default)
    {
        JsonElement congelado = FormatoPaqueteNube.Compactar(nuevo);
        JsonElement cambios = CambiosPaqueteNube.Crear(FormatoPaqueteNube.Compactar(anterior), congelado);
        return GuardarCambiosCongeladosAsync(id, operacion, revision, cambios, congelado, ct);
    }

    /// <summary>Reenvía exactamente la diferencia que ya se conservó en la cola durable.</summary>
    public async Task<RespuestaGuardarNube> GuardarCambiosCongeladosAsync(Guid id, Guid operacion, long revision,
        JsonElement cambios, JsonElement final, CancellationToken ct = default)
    {
        ValidarIdNube(id); ValidarIdNube(operacion);
        if (revision < 1 || revision == long.MaxValue) throw new NubeException("La operación necesita una revisión de nube válida.");
        // Congelar el paquete y su diferencia antes de cualquier renovación de sesión.
        long bytesContenido = 0;
        JsonElement congelado = ValidarContenidoNube(final, ct, bytes => bytesContenido = bytes);
        if (capacidadesNube is null && bytesContenido > MaxContenidoNubeAnteriorBytes)
            await ObtenerCapacidadesNubeAsync(ct);
        cambios = cambios.Clone();
        if (Encoding.UTF8.GetByteCount(cambios.GetRawText()) > MaxContenidoNubeBytes)
            throw new NubeException("Los cambios preparados superan el tamaño admitido para la nube.");
        if (await EsProyectoComprimidoAsync(id, ct))
            return await GuardarProyectoComprimidoAsync(id, operacion, revision, congelado, ct);
        try
        {
            return await EjecutarRpcNubeAsync("myg_nube_guardar_cambios", new
            {
                p_id = id, p_operacion = operacion, p_revision = revision, p_cambios = cambios
            }, raiz =>
            {
                string estado = TextoNube(raiz, "estado", 32);
                if (estado is not ("aplicada" or "conflicto")) throw RespuestaNubeInvalida();
                Guid confirmado = GuidNube(raiz, "operacion_id");
                long recibida = RevisionNube(raiz);
                if (confirmado != operacion || (estado == "aplicada" && recibida != revision + 1))
                    throw RespuestaNubeInvalida();
                // Un ACK idempotente se refiere siempre a nuestro mismo contenido congelado,
                // incluso si otros usuarios ya publicaron una revisión posterior.
                JsonElement contenido = estado == "aplicada" ? congelado.Clone() : ContenidoNube(raiz);
                return new RespuestaGuardarNube(estado, recibida, contenido, confirmado);
            }, ct);
        }
        catch (NubeException ex) when (ex.Codigo == "MGC01")
        {
            if (!await EsProyectoComprimidoAsync(id, ct, forzar: true)) throw;
            return await GuardarProyectoComprimidoAsync(id, operacion, revision, congelado, ct);
        }
    }
}
