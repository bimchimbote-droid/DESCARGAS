#!/usr/bin/env python3
"""Regresión NUEVA del protocolo Gzip, solo en Docker desechable.

PostgreSQL y PostgREST son reales. Storage se representa mediante archivos locales
y su tabla de metadatos con RLS real; no se ejecuta el servicio Supabase Storage.
No se conecta a una base remota ni se vuelven a ejecutar los benchmarks JSONB.
"""
import argparse
import base64
import gzip
import hashlib
import hmac
import io
import json
from pathlib import Path
import random
import signal
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid

REPO = Path(__file__).resolve().parents[2]
POSTGRES = 'postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
POSTGREST = 'postgrest/postgrest:v16.5@sha256:1347d7552b88f17832912c06afbf7c43209af6eeeb60834b04aae12c9bd9d5cc'
SECRET = b'myg_gzip_synthetic_test_secret_not_a_real_credential'
OWNER = '00000000-0000-0000-0000-000000000001'
EDITOR = '00000000-0000-0000-0000-000000000003'
READER = '00000000-0000-0000-0000-000000000004'
OTHER = '00000000-0000-0000-0000-000000000007'
CHUNK = 8 * 1024 * 1024


def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def literal(value):
    return "'" + value.replace("'", "''") + "'"


def token(user):
    def b64(value):
        return base64.urlsafe_b64encode(value).rstrip(b'=')
    prefix = b64(b'{"alg":"HS256","typ":"JWT"}') + b'.' + b64(encode({
        'role': 'authenticated', 'sub': user, 'exp': int(time.time()) + 3600}))
    return (prefix + b'.' + b64(hmac.new(SECRET, prefix, hashlib.sha256).digest())).decode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--paquetes', type=Path, required=True,
                        help='Fixtures existentes; este runner no vuelve a compilarlos')
    parser.add_argument('--resultados', type=Path, required=True)
    parser.add_argument('--sin-carga-grande', action='store_true',
                        help='Solo para depurar el runner antes del ensayo final de 200 MiB')
    parser.add_argument('--solo-adicionales', action='store_true',
                        help='Omitir matrices y carga grande ya aprobadas; comprobar bloqueo, textos y adaptación del trigger')
    args = parser.parse_args()
    args.resultados.mkdir(parents=True, exist_ok=True)
    prefix = 'myg-gzip-' + uuid.uuid4().hex[:10]
    network, database, api = [prefix + '-' + name for name in ('red', 'pg', 'api')]
    containers = []
    created_network = False
    checks, requests, blob_operations = [], [], []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    result = {'status': 'interrupted'}
    log = (args.resultados / 'preparacion.log').open('w')

    def interrupted(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)

    def require(condition, detail):
        if not condition:
            raise AssertionError(detail)
        checks.append(detail)

    def run(*command, check=True, input_text=None):
        completed = subprocess.run(command, input=input_text, text=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log.write(completed.stdout)
        log.flush()
        if check and completed.returncode:
            raise RuntimeError(f'{command[0]} terminó con {completed.returncode}: {completed.stdout[-2400:]}')
        return completed

    def sql(query, check=True):
        return run('docker', 'exec', '-i', '-u', 'postgres', database, 'psql', '-X', '-qAt',
                   '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose',
                   '-v', 'MYG_PRUEBAS_DESECHABLES=1', input_text=query, check=check).stdout.strip()

    def sql_file(path, check=True):
        return run('docker', 'exec', '-u', 'postgres', database, 'psql', '-X', '-qAt',
                   '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose',
                   '-v', 'MYG_PRUEBAS_DESECHABLES=1', '-f', path, check=check)

    def sql_as(user, query, check=True):
        return sql('SET ROLE authenticated; SET request.jwt.claims=' + literal(encode({'sub': user}).decode())
                   + '; SET request.jwt.claim.sub=' + literal(user) + '; ' + query, check=check)

    with tempfile.TemporaryDirectory(prefix='myg-gzip-blobs-') as temporary:
        local = Path(temporary)
        objects = local / 'objetos'
        objects.mkdir()

        def upload_chunk(project, data, user):
            sha = hashlib.sha256(data).hexdigest()
            path = user + '/' + project.replace('-', '') + '/' + sha
            stored = objects / hashlib.sha256(path.encode()).hexdigest()
            if not stored.exists():
                sql_as(user, 'INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('
                       + "'myg-nube-paquetes'," + literal(path) + ','
                       + literal(encode({'size': len(data)}).decode()) + '::jsonb);')
                stored.write_bytes(data)
                blob_operations.append({'operation': 'upload_emulado', 'bytes': len(data)})
            else:
                require(stored.read_bytes() == data, 'Repetir la parte conserva sus bytes inmutables')
            return {'ruta': path, 'sha256': sha, 'bytes': len(data)}

        def manifest_bytes(project, raw, user=OWNER, mtime=0):
            compressed = gzip.compress(raw, compresslevel=9, mtime=mtime)
            return {'formato': 'MYG_ARCHIVO_GZIP', 'version': 1,
                    'sha256_json': hashlib.sha256(raw).hexdigest(), 'bytes_json': len(raw),
                    'sha256_gzip': hashlib.sha256(compressed).hexdigest(), 'bytes_gzip': len(compressed),
                    'partes': [upload_chunk(project, compressed[n:n + CHUNK], user)
                               for n in range(0, len(compressed), CHUNK)]}

        def read_manifest(project, manifest, user=OWNER):
            compressed = io.BytesIO()
            for part in manifest['partes']:
                allowed = sql_as(user, "SELECT count(*) FROM storage.objects WHERE bucket_id='myg-nube-paquetes' AND name="
                                 + literal(part['ruta']) + ';')
                require(allowed == '1', 'RLS autoriza leer la parte referenciada para el miembro actual')
                data = (objects / hashlib.sha256(part['ruta'].encode()).hexdigest()).read_bytes()
                require(len(data) == part['bytes'] and hashlib.sha256(data).hexdigest() == part['sha256'],
                        'La lectura emulada verifica longitud y SHA-256 de cada parte')
                compressed.write(data)
                blob_operations.append({'operation': 'download_emulado', 'bytes': len(data)})
            zipped = compressed.getvalue()
            require(len(zipped) == manifest['bytes_gzip'] and hashlib.sha256(zipped).hexdigest() == manifest['sha256_gzip'],
                    'Las partes reconstruyen los bytes y SHA-256 Gzip originales')
            raw = gzip.decompress(zipped)
            require(len(raw) == manifest['bytes_json'] and hashlib.sha256(raw).hexdigest() == manifest['sha256_json'],
                    'Descomprimir reconstruye exactamente longitud y SHA-256 del JSON')
            return raw

        try:
            for image in (POSTGRES, POSTGREST):
                require(run('docker', 'image', 'inspect', image, check=False).returncode == 0,
                        'Se reutiliza la imagen fijada ya disponible: ' + image.split('@')[0])
            require((args.paquetes / 'compacto_cliente.json').is_file(), 'Se reutilizan los fixtures sintéticos existentes')
            run('docker', 'network', 'create', '--internal', network)
            created_network = True
            run('docker', 'run', '--detach', '--rm', '--name', database, '--network', network,
                '--memory=512m', '--memory-swap=512m', '--cpus=1',
                '--tmpfs', '/var/lib/postgresql/data:rw,size=256m',
                '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', POSTGRES,
                '-c', 'shared_buffers=32MB', '-c', 'work_mem=1MB', '-c', 'max_connections=20')
            containers.append(database)
            for attempt in range(60):
                if run('docker', 'exec', database, 'pg_isready', '-U', 'postgres', check=False).returncode == 0:
                    break
                if attempt == 59:
                    raise RuntimeError('PostgreSQL desechable no inició')
                time.sleep(0.5)
            run('docker', 'exec', '-u', 'root', database, 'mkdir', '-p', '/pruebas')
            run('docker', 'cp', str(REPO / 'supabase'), database + ':/pruebas/supabase')
            run('docker', 'cp', str(args.paquetes), database + ':/pruebas/paquetes')
            run('docker', 'exec', '-u', 'root', database, 'chmod', '-R', 'a+rX', '/pruebas')
            # Solo preparación del fixture original; no se repiten sus pruebas.
            baseline = (REPO / 'supabase/pruebas/usuarios_myg_roles.sql').read_text()
            sql(baseline.split('grant insert,update,delete on public.myg_nube_miembros', 1)[0])
            # Reutilizar los helpers de aserción, sin ejecutar los casos antiguos.
            helpers = 'create table qa.resultados' + baseline.split('create table qa.resultados', 1)[1].split('select qa.exige', 1)[0]
            sql(helpers)
            sql_file('/pruebas/supabase/migraciones/20261020_usuarios_myg_roles.sql')
            sql_file('/pruebas/supabase/migraciones/20261026_publicacion_ligera.sql')
            sql_file('/pruebas/supabase/migraciones/20261027_publicacion_sin_espera.sql')
            sql('''
                CREATE SCHEMA storage;
                CREATE TABLE storage.buckets(id text PRIMARY KEY,name text,public boolean,file_size_limit bigint);
                CREATE TABLE storage.objects(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),bucket_id text,name text,
                    metadata jsonb,UNIQUE(bucket_id,name));
                ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
                GRANT USAGE ON SCHEMA storage TO authenticated,anon;
                GRANT SELECT,INSERT,UPDATE,DELETE ON storage.objects TO authenticated,anon;
                -- Una política permisiva global pone a prueba las guardas RESTRICTIVE nuevas.
                CREATE POLICY qa_permisiva_global ON storage.objects FOR ALL TO authenticated USING(true) WITH CHECK(true);
                CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
                    SELECT coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub',
                        nullif(current_setting('request.jwt.claim.sub',true),''))::uuid;
                $$;
                CREATE ROLE myg_gzip_http_login LOGIN NOINHERIT;
                GRANT anon,authenticated TO myg_gzip_http_login;
                CREATE FUNCTION qa.guard_estado(p_anterior text,p_nuevo text,p_permisos jsonb)
                RETURNS text LANGUAGE plpgsql AS $$
                BEGIN
                    PERFORM myg_nube_privado.validar_contenido(p_anterior::jsonb);
                    PERFORM myg_nube_privado.validar_contenido(p_nuevo::jsonb);
                    PERFORM myg_nube_privado.exigir_modulos(p_anterior::jsonb,p_nuevo::jsonb,p_permisos);
                    RETURN '00000';
                EXCEPTION WHEN OTHERS THEN RETURN SQLSTATE;
                END $$;
            ''')
            before = sql("SELECT md5(coalesce(jsonb_agg(to_jsonb(p) ORDER BY id),'[]')::text) FROM public.myg_nube_proyectos p;")
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(before == sql("SELECT md5(coalesce(jsonb_agg(to_jsonb(p)-'es_comprimido' ORDER BY id),'[]')::text) FROM public.myg_nube_proyectos p;"),
                    'Instalar28 conserva contenido y metadatos existentes salvo nueva marca false')
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT count(*)=1 FROM storage.buckets WHERE id='myg-nube-paquetes' AND public=false AND file_size_limit=8388608;") == 't',
                    'Reinstalar28 conserva el bucket privado y límite8MiB')
            sql_file('/pruebas/supabase/pruebas/publicacion_comprimida.sql')
            sql_checks = int(sql('SELECT count(*) FROM qa.resultados;'))
            require(sql_checks > 0, 'Las pruebas SQL nuevas de compresión completan sus aserciones')
            run('docker', 'run', '--detach', '--rm', '--name', api, '--network', network,
                '--memory=512m', '--memory-swap=512m', '--cpus=1',
                '-e', f'PGRST_DB_URI=postgres://myg_gzip_http_login@{database}:5432/postgres',
                '-e', 'PGRST_DB_SCHEMAS=public', '-e', 'PGRST_DB_ANON_ROLE=anon',
                '-e', 'PGRST_JWT_SECRET=' + SECRET.decode(), POSTGREST)
            containers.append(api)
            address = run('docker', 'inspect', api, '--format', '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}').stdout.strip()
            url = f'http://{address}:3000/'
            for attempt in range(60):
                try:
                    with opener.open(url, timeout=2) as response:
                        if response.status == 200:
                            break
                except (urllib.error.URLError, TimeoutError):
                    pass
                if attempt == 59:
                    raise RuntimeError('PostgREST desechable no inició')
                time.sleep(0.5)

            def rpc(name, body, user=OWNER, expected=200, code=None):
                headers = {'Content-Type': 'application/json'}
                if user:
                    headers['Authorization'] = 'Bearer ' + token(user)
                encoded = encode(body)
                started = time.monotonic()
                request = urllib.request.Request(url + 'rpc/' + name, data=encoded, headers=headers, method='POST')
                try:
                    with opener.open(request, timeout=30) as response:
                        status, content = response.status, response.read()
                except urllib.error.HTTPError as error:
                    status, content = error.code, error.read()
                elapsed = time.monotonic() - started
                value = json.loads(content)
                require(status == expected, f'{name}: HTTP{status}, esperado{expected}; código={value.get("code") if isinstance(value,dict) else "array"}')
                if code:
                    require(value.get('code') == code, f'{name} preserva SQLSTATE{code}')
                requests.append({'rpc': name, 'status': status, 'seconds': round(elapsed, 4),
                                 'request_bytes': len(encoded), 'response_bytes': len(content),
                                 'sqlstate': value.get('code') if isinstance(value, dict) else None})
                return value

            caps = rpc('myg_nube_capacidades', {})
            require(caps.get('publicacion_comprimida') == 1 and caps.get('publicacion_ligera') == 1
                    and caps.get('cambios') == 1, 'Capacidades conserva los protocolos existentes y anuncia compresión')
            project = '99000000-0000-0000-0000-000000000001'
            raw = (args.paquetes / 'compacto_cliente.json').read_bytes()
            manifest = manifest_bytes(project, raw)
            create = {'p_id': project, 'p_nombre': 'COMPRIMIDO QA', 'p_manifest': manifest, 'p_alcance': 'base'}
            ack = rpc('myg_nube_crear_comprimido', create)
            require(ack['id'] == project and ack['revision'] == 1 and 'contenido' not in ack,
                    'Crear confirma proyecto y revisión sin devolver el contenido')
            require(rpc('myg_nube_crear_comprimido', create) == ack, 'Repetir creación confirma sin duplicar historia')
            alternative = manifest_bytes(project, raw, mtime=1)
            require(rpc('myg_nube_crear_comprimido', dict(create, p_manifest=alternative)) == ack,
                    'Recomprimir el mismo JSON mantiene idempotencia del UUID sin cambiar historia inicial')
            opened = rpc('myg_nube_abrir_comprimido', {'p_id': project})
            require(opened['contenido'] == manifest and read_manifest(project, opened['contenido']) == raw,
                    'Apertura recupera el primer manifiesto y los bytes exactos del JSON')
            require(rpc('myg_nube_paquete_tipo', {'p_id': project}) == {'almacenamiento': 'gzip'},
                    'La sonda autorizada identifica almacenamiento Gzip')
            rpc('myg_nube_abrir_comprimido', {'p_id': project}, user=OTHER, expected=403, code='42501')
            rpc('myg_nube_abrir_comprimido', {'p_id': project}, user=None, expected=401, code='42501')
            rpc('myg_nube_crear_comprimido', create, user=EDITOR, expected=403, code='42501')
            rpc('myg_nube_abrir', {'p_id': project}, expected=400, code='MGC01')
            rpc('myg_nube_guardar', {'p_id': project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1,
                                  'p_contenido': json.loads(raw)}, expected=400, code='MGC01')

            second_raw = (args.paquetes / 'compacto_cliente_nombre.json').read_bytes()
            second_manifest = manifest_bytes(project, second_raw)
            op = str(uuid.uuid4())
            save = {'p_id': project, 'p_operacion': op, 'p_revision': 1, 'p_manifest': second_manifest}
            saved = rpc('myg_nube_guardar_comprimido', save)
            require(saved == {'estado': 'aplicada', 'revision': 2, 'operacion_id': op},
                    'Guardar utiliza CAS y confirma solo metadatos pequeños')
            conflict_op = str(uuid.uuid4())
            conflict_save = dict(save, p_operacion=conflict_op, p_manifest=manifest)
            conflict = rpc('myg_nube_guardar_comprimido', conflict_save)
            require(conflict['estado'] == 'conflicto' and conflict['revision'] == 2 and conflict['contenido'] == second_manifest,
                    'El conflicto congela el manifiesto de la revisión vigente sin sobrescribir')
            third_op = str(uuid.uuid4())
            rpc('myg_nube_guardar_comprimido', dict(save, p_operacion=third_op, p_revision=2, p_manifest=manifest))
            require(rpc('myg_nube_guardar_comprimido', save) == saved,
                    'Un ACK perdido conserva la revisión aplicada aunque el proyecto haya avanzado')
            require(rpc('myg_nube_guardar_comprimido', conflict_save) == conflict,
                    'Repetir el conflicto entrega el snapshot original, no uno posterior')
            alternative_second = manifest_bytes(project, second_raw, mtime=1)
            require(rpc('myg_nube_guardar_comprimido', dict(save, p_manifest=alternative_second)) == saved,
                    'Recomprimir el mismo JSON final conserva replay del UUID de operación')
            require(rpc('myg_nube_crear_comprimido', create)['revision'] == 1,
                    'Reintentar creación tras ediciones confirma la revisión inicial y no cambia el contenido vigente')
            historical = rpc('myg_nube_abrir_comprimido', {'p_id': project, 'p_revision': 2})
            require(historical['revision'] == 2 and historical['contenido'] == second_manifest
                    and read_manifest(project, historical['contenido']) == second_raw,
                    'Abrir una revisión histórica recupera exactamente sus bytes')
            rpc('myg_nube_guardar_comprimido', dict(save, p_manifest=manifest), expected=400, code='22023')
            rpc('myg_nube_compartir_usuario', {'p_id': project, 'p_usuario_myg': 'lector', 'p_rol': 'lector',
                                              'p_permisos_modulos': {'acu': False, 'especificaciones': False, 'metrados_excel': False}})
            require(read_manifest(project, manifest, user=READER) == raw, 'El lector puede recuperar una revisión autorizada')
            first_path = manifest['partes'][0]['ruta']
            require(sql_as(OTHER, "SELECT count(*) FROM storage.objects WHERE name=" + literal(first_path) + ';') == '0',
                    'La política global permisiva no abre las partes de otro proyecto')
            require(sql_as(OWNER, "WITH cambio AS(UPDATE storage.objects SET metadata='{}' WHERE name=" + literal(first_path)
                           + ' RETURNING 1) SELECT count(*) FROM cambio;') == '0',
                    'Ni el propietario puede modificar objetos referenciados')
            require(sql_as(OWNER, 'WITH cambio AS(DELETE FROM storage.objects WHERE name=' + literal(first_path)
                           + ' RETURNING 1) SELECT count(*) FROM cambio;') == '0',
                    'Ni el propietario puede borrar objetos de revisiones históricas')
            rpc('myg_nube_rol', {'p_id': project, 'p_usuario': READER, 'p_rol': None})
            require(sql_as(READER, 'SELECT count(*) FROM storage.objects WHERE name=' + literal(first_path) + ';') == '0',
                    'Retirar acceso revoca inmediatamente la lectura de las partes históricas')

            # Paridad con el guard autoritativo anterior: casos pequeños existentes,
            # ocho máscaras y todos los tipos de representación sensibles.
            baseline_raw = (args.paquetes / 'baseline.json').read_bytes()
            mutations = ['acu_precio', 'acu_recurso', 'acu_insumo', 'especificacion',
                         'hoja_excel', 'zoom_excel', 'fuente_excel', 'cantidad_excel',
                         'ataque_tabla_acu', 'ataque_tipo_celda_acu', 'ataque_mayusculas_acu',
                         'ataque_tabla_especificacion', 'ataque_tabla_excel',
                         'ataque_documentos', 'ataque_recursos']
            partial_cases = []
            for mask_number in (() if args.solo_adicionales else range(8)):
                permissions = {name: bool(mask_number & (1 << bit)) for bit, name in enumerate(
                    ['acu', 'especificaciones', 'metrados_excel'])}
                for mutation in mutations:
                    mutated = (args.paquetes / (mutation + '.json')).read_bytes()
                    expected_code = sql('SELECT qa.guard_estado(' + literal(baseline_raw.decode()) + ','
                                        + literal(mutated.decode()) + ',' + literal(encode(permissions).decode()) + '::jsonb);')
                    # Full permission path deliberately does not parse JSONB. These
                    # fixtures are valid exports; malformed-format parity is tested elsewhere.
                    if mask_number == 7 and expected_code != '00000':
                        raise AssertionError('Fixture no válido para el fastpath: ' + mutation + '/' + expected_code)
                    case_project = str(uuid.uuid4())
                    initial = manifest_bytes(case_project, baseline_raw)
                    rpc('myg_nube_crear_comprimido', {'p_id': case_project, 'p_nombre': 'MÁSCARA QA', 'p_alcance': 'obra', 'p_manifest': initial})
                    rpc('myg_nube_compartir_usuario', {'p_id': case_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                                     'p_permisos_modulos': permissions})
                    updated = manifest_bytes(case_project, mutated, user=EDITOR)
                    body = {'p_id': case_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1, 'p_manifest': updated}
                    if mask_number != 7:
                        body.update(p_anterior=baseline_raw.decode(), p_nuevo=mutated.decode())
                    permitted = expected_code == '00000'
                    actual = rpc('myg_nube_guardar_comprimido', body, user=EDITOR,
                                 expected=200 if permitted else (403 if expected_code == '42501' else 400),
                                 code=None if permitted else expected_code)
                    require((actual.get('estado') == 'aplicada') == permitted,
                            f'Máscara{mask_number}, {mutation}: paridad con validar_contenido+exigir_modulos')
                    current = rpc('myg_nube_revision', {'p_id': case_project})
                    require(current['revision'] == (2 if permitted else 1),
                            f'Máscara{mask_number}, {mutation}: rechazo conserva la revisión y el contenido')
                    partial_cases.append({'mask': mask_number, 'mutation': mutation, 'permitted': permitted,
                                          'expected_sqlstate': expected_code})

            # El JSON de la operación es durable; la máscara puede cambiar después
            # de perderse el ACK. Los textos auxiliares no cambian su identidad.
            retry_project = str(uuid.uuid4())
            retry_initial = manifest_bytes(retry_project, baseline_raw)
            rpc('myg_nube_crear_comprimido', {'p_id': retry_project, 'p_nombre': 'REPLAY PERMISOS QA',
                                            'p_alcance': 'obra', 'p_manifest': retry_initial})
            rpc('myg_nube_compartir_usuario', {'p_id': retry_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=True, especificaciones=True, metrados_excel=True)})
            retry_raw = (args.paquetes / 'acu_precio.json').read_bytes()
            retry_manifest = manifest_bytes(retry_project, retry_raw, user=EDITOR)
            retry_save = {'p_id': retry_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1,
                          'p_manifest': retry_manifest}
            first_retry_ack = rpc('myg_nube_guardar_comprimido', retry_save, user=EDITOR)
            rpc('myg_nube_compartir_usuario', {'p_id': retry_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=True, especificaciones=False, metrados_excel=False)})
            require(rpc('myg_nube_guardar_comprimido', dict(retry_save, p_anterior=baseline_raw.decode(),
                        p_nuevo=retry_raw.decode()), user=EDITOR) == first_retry_ack,
                    'ACK perdido se recupera al pasar de permisos completos a restringidos')
            retry_back = {'p_id': retry_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 2,
                          'p_manifest': manifest_bytes(retry_project, baseline_raw, user=EDITOR),
                          'p_anterior': retry_raw.decode(), 'p_nuevo': baseline_raw.decode()}
            second_retry_ack = rpc('myg_nube_guardar_comprimido', retry_back, user=EDITOR)
            rpc('myg_nube_compartir_usuario', {'p_id': retry_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=True, especificaciones=True, metrados_excel=True)})
            require(rpc('myg_nube_guardar_comprimido', {k: v for k, v in retry_back.items()
                        if k not in ('p_anterior', 'p_nuevo')}, user=EDITOR) == second_retry_ack,
                    'ACK perdido se recupera al pasar de permisos restringidos a completos')
            uploader_path = retry_manifest['partes'][0]['ruta']
            rpc('myg_nube_rol', {'p_id': retry_project, 'p_usuario': EDITOR, 'p_rol': None})
            require(sql_as(EDITOR, 'SELECT count(*) FROM storage.objects WHERE name=' + literal(uploader_path) + ';') == '0',
                    'La revocación impide al antiguo uploader leer partes históricas de su propio prefijo')
            rpc('myg_nube_guardar_comprimido', retry_save, user=EDITOR, expected=403, code='42501')
            denied_upload = sql_as(EDITOR, "INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('myg-nube-paquetes',"
                + literal(EDITOR + '/' + retry_project.replace('-', '') + '/' + 'f' * 64) + ",'{}');", check=False)
            require('42501' in denied_upload,
                    'El antiguo uploader tampoco puede subir partes nuevas al proyecto revocado')

            # Pruebas añadidas después de la matriz aprobada: se pueden ejecutar
            # con --solo-adicionales, sin repetir la carga grande ni los 120 casos.
            forged_project = str(uuid.uuid4())
            forged_manifest = manifest_bytes(forged_project, baseline_raw)
            rpc('myg_nube_crear_comprimido', {'p_id': forged_project, 'p_nombre': 'TEXTOS QA',
                                            'p_alcance': 'obra', 'p_manifest': forged_manifest})
            rpc('myg_nube_compartir_usuario', {'p_id': forged_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=False, especificaciones=False, metrados_excel=False)})
            forged_save = {'p_id': forged_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1,
                           'p_manifest': forged_manifest, 'p_anterior': baseline_raw.decode(), 'p_nuevo': baseline_raw.decode()}
            rpc('myg_nube_guardar_comprimido', dict(forged_save, p_anterior=baseline_raw.decode() + ' '),
                user=EDITOR, expected=400, code='22023')
            rpc('myg_nube_guardar_comprimido', dict(forged_save, p_nuevo=baseline_raw.decode() + ' '),
                user=EDITOR, expected=400, code='22023')
            require(rpc('myg_nube_revision', {'p_id': forged_project})['revision'] == 1,
                    'Textos anteriores o nuevos con SHA distinto no alteran revisión ni proyecto')
            alien_manifest = dict(forged_manifest, partes=manifest['partes'])
            rpc('myg_nube_guardar_comprimido', dict(forged_save, p_manifest=alien_manifest),
                expected=400, code='22023')
            require(rpc('myg_nube_guardar_comprimido', forged_save, user=EDITOR)['revision'] == 2,
                    'El rechazo no consume el UUID: se recupera enviando los textos exactos autorizados')

            fingerprint_query = """SELECT md5(jsonb_build_object(
                'proyecto',(SELECT to_jsonb(p) FROM public.myg_nube_proyectos p WHERE id=%s),
                'historial',(SELECT jsonb_agg(to_jsonb(h) ORDER BY revision) FROM public.myg_nube_historial h WHERE proyecto_id=%s),
                'operaciones',(SELECT jsonb_agg(to_jsonb(o) ORDER BY usuario_id,operacion_id) FROM public.myg_nube_operaciones o WHERE proyecto_id=%s)
            )::text);""" % (literal(project), literal(project), literal(project))
            fingerprint = sql(fingerprint_query)
            holder_name = 'myg-gzip-fila-ocupada'
            with (args.resultados / 'fila-ocupada.log').open('w') as holder_log:
                holder = subprocess.Popen(['docker', 'exec', '-e', 'PGAPPNAME=' + holder_name,
                    '-u', 'postgres', database, 'psql', '-X', '-qAt', '-v', 'ON_ERROR_STOP=1', '-c',
                    'BEGIN; SELECT id FROM public.myg_nube_proyectos WHERE id=' + literal(project)
                    + ' FOR UPDATE; SELECT pg_sleep(30); ROLLBACK;'], stdout=holder_log, stderr=subprocess.STDOUT)
                try:
                    for attempt in range(40):
                        if sql("SELECT exists(SELECT 1 FROM pg_stat_activity WHERE application_name="
                               + literal(holder_name) + " AND wait_event='PgSleep');") == 't':
                            break
                        if attempt == 39:
                            raise RuntimeError('No se confirmó el bloqueo sintético de fila')
                        time.sleep(0.05)
                    rpc('myg_nube_crear_comprimido', create, expected=500, code='55006')
                    require(requests[-1]['seconds'] < 2, 'Crear Gzip rechaza la fila ocupada mediante NOWAIT en menos de2s')
                    rpc('myg_nube_guardar_comprimido', dict(save, p_operacion=str(uuid.uuid4()), p_revision=3),
                        expected=500, code='55006')
                    require(requests[-1]['seconds'] < 2, 'Guardar Gzip rechaza la fila ocupada mediante NOWAIT en menos de2s')
                    rpc('myg_nube_guardar_comprimido', dict(save, p_operacion=str(uuid.uuid4()), p_revision=3),
                        user=OTHER, expected=403, code='42501')
                    require(sql(fingerprint_query) == fingerprint,
                            'Los rechazos por fila ocupada y permisos conservan proyecto, historial y operaciones')
                finally:
                    sql('SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE application_name=' + literal(holder_name) + ';')
                    holder.wait(timeout=10)
            require(rpc('myg_nube_crear_comprimido', create)['revision'] == 1,
                    'Liberar la fila permite recuperar el mismo intento de creación sin modificar revisiones')

            # Este trigger es EXCLUSIVAMENTE un stub de laboratorio. No reproduce
            # el cuerpo productivo ausente del repositorio ni valida sus adjuntos.
            sql("""
                CREATE FUNCTION myg_nube_privado.validar_paquete_archivos() RETURNS trigger
                LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$ BEGIN RETURN NEW; END $$;
                REVOKE ALL ON FUNCTION myg_nube_privado.validar_paquete_archivos() FROM PUBLIC;
                GRANT EXECUTE ON FUNCTION myg_nube_privado.validar_paquete_archivos() TO anon;
                COMMENT ON FUNCTION myg_nube_privado.validar_paquete_archivos() IS 'STUB SINTÉTICO: no es el validador productivo';
                CREATE TRIGGER myg_nube_validar_adjuntos BEFORE INSERT OR UPDATE ON public.myg_nube_proyectos
                FOR EACH ROW EXECUTE FUNCTION myg_nube_privado.validar_paquete_archivos();
                COMMENT ON TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos IS 'Comentario sintético que debe conservarse';
                ALTER TABLE public.myg_nube_proyectos ENABLE ALWAYS TRIGGER myg_nube_validar_adjuntos;
            """)
            trigger_function_before = sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;")
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;") == trigger_function_before,
                    'Adaptar el trigger sintético conserva OID, cuerpo, ACL y atributos de su función')
            require(sql("SELECT tgenabled='A' AND tgqual IS NOT NULL AND obj_description(oid,'pg_trigger')="
                        + "'Comentario sintético que debe conservarse' FROM pg_trigger WHERE tgrelid='public.myg_nube_proyectos'::regclass AND tgname='myg_nube_validar_adjuntos';") == 't',
                    'El trigger sintético conserva ENABLE ALWAYS y COMMENT al añadir su condición')
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;") == trigger_function_before,
                    'Reinstalar el adaptador conserva nuevamente la función sintética sin reemplazarla')
            sql("""
                DROP TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos;
                CREATE TRIGGER myg_nube_validar_adjuntos BEFORE INSERT OR UPDATE ON public.myg_nube_proyectos
                FOR EACH ROW WHEN (NEW.nombre<>'') EXECUTE FUNCTION myg_nube_privado.validar_paquete_archivos();
            """)
            unknown_trigger = sql("SELECT pg_get_triggerdef(oid) FROM pg_trigger WHERE tgrelid='public.myg_nube_proyectos'::regclass AND tgname='myg_nube_validar_adjuntos';")
            rejected_install = sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql', check=False)
            require(rejected_install.returncode != 0 and 'condición personalizada' in rejected_install.stdout,
                    'Un trigger con condición desconocida aborta la instalación completa')
            require(sql("SELECT pg_get_triggerdef(oid) FROM pg_trigger WHERE tgrelid='public.myg_nube_proyectos'::regclass AND tgname='myg_nube_validar_adjuntos';") == unknown_trigger
                    and sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;") == trigger_function_before,
                    'El rechazo de instalación preserva la condición y la función desconocidas')
            sql('DROP TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos;')
            sql("ALTER TABLE public.myg_nube_proyectos ALTER es_comprimido SET DEFAULT true;")
            rejected_default = sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql', check=False)
            require(rejected_default.returncode != 0 and 'definición incompatible' in rejected_default.stdout,
                    'Una marca preexistente con DEFAULT true no cambia el formato de los proyectos legados')
            sql("ALTER TABLE public.myg_nube_proyectos ALTER es_comprimido SET DEFAULT false;")

            # Restaurar únicamente los cuerpos oficiales previos del fixture y
            # convertirlos a CRLF verifica la misma instalación en archivos Windows.
            sql("""
                DO $qa$ DECLARE v text; d text; BEGIN
                    FOREACH v IN ARRAY ARRAY['myg_nube_privado.snapshot(uuid,uuid)','public.myg_nube_capacidades()',
                        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)',
                        'public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)',
                        'myg_nube_privado.reconstruir_revision(uuid,bigint)'] LOOP
                        d:=pg_get_functiondef(v::regprocedure);
                        d:=replace(d,E'    perform myg_nube_privado.exigir_paquete_json(p_id);\\n','');
                        d:=replace(d,' and myg_nube_privado.exigir_paquete_json(p.id)','');
                        d:=replace(d,',''publicacion_comprimida'',1','');
                        EXECUTE replace(d,E'\\n',E'\\r\\n');
                    END LOOP;
                END $qa$;
            """)
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT bool_and(position(E'\\r\\n' in prosrc)>0) FROM pg_proc WHERE oid=ANY(ARRAY["
                        + "'myg_nube_privado.snapshot(uuid,uuid)'::regprocedure,'public.myg_nube_capacidades()'::regprocedure,"
                        + "'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure,"
                        + "'public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)'::regprocedure,"
                        + "'myg_nube_privado.reconstruir_revision(uuid,bigint)'::regprocedure]);") == 't',
                    'Instalar28 sobre los cuerpos oficiales CRLF conserva sus finales de línea Windows')
            rpc('myg_nube_abrir', {'p_id': project}, expected=400, code='MGC01')
            require(read_manifest(project, rpc('myg_nube_abrir_comprimido', {'p_id': project})['contenido']) == raw,
                    'La adaptación CRLF mantiene la apertura comprimida y el rechazo del cliente legado')

            large_result = None
            if not args.sin_carga_grande and not args.solo_adicionales:
                # Nuevo protocolo, no repetición del benchmark JSONB antiguo. La
                # carga lógica se procesa localmente y nunca se envía como RPC.
                large_project = str(uuid.uuid4())
                logical_bytes = 209835827
                prefix_json, suffix_json = b'{"prueba_sintetica":"', b'"}'
                random_block = base64.b64encode(random.Random(20261028).randbytes(192 * 1024))
                remaining = logical_bytes - len(prefix_json) - len(suffix_json)
                large_json = local / 'sintetico-200mib.json'
                with large_json.open('wb') as stream:
                    stream.write(prefix_json)
                    while remaining:
                        piece = random_block[:min(remaining, len(random_block))]
                        stream.write(piece)
                        remaining -= len(piece)
                    stream.write(suffix_json)
                large_raw = large_json.read_bytes()
                started = time.monotonic()
                large_manifest = manifest_bytes(large_project, large_raw)
                ack_large = rpc('myg_nube_crear_comprimido', {'p_id': large_project, 'p_nombre': '200 MiB SINTÉTICOS QA',
                                                            'p_manifest': large_manifest, 'p_alcance': 'base'})
                open_large = rpc('myg_nube_abrir_comprimido', {'p_id': large_project})
                require(ack_large['revision'] == 1 and read_manifest(large_project, open_large['contenido']) == large_raw,
                        'El nuevo protocolo publica y recupera200MiB lógicos sin enviar JSON grande a PostgreSQL')
                require(all(row['request_bytes'] < 65536 for row in requests[-2:]),
                        'Crear y abrir200MiB utilizan solicitudesRPC inferiores a64KiB')
                large_result = {'logical_bytes': len(large_raw), 'gzip_bytes': large_manifest['bytes_gzip'],
                                'chunks': len(large_manifest['partes']), 'sha256_json': large_manifest['sha256_json'],
                                'seconds_total_local_compression_emulated_storage_rpc_roundtrip': round(time.monotonic() - started, 4),
                                'rpc': requests[-2:]}
                del large_raw
            events = {}
            for name in containers:
                if name == database:
                    lines = run('docker', 'exec', name, 'cat', '/sys/fs/cgroup/memory.events').stdout.splitlines()
                    events['pg'] = dict(line.split() for line in lines)
                    require(events['pg'].get('oom_kill') == '0',
                            'PostgreSQL512MiB no registra OOMkill durante este protocolo')
                else:
                    # La imagen API es distroless; no contiene cat. Docker conserva
                    # el estado del proceso sin depender de rutas cgroup del host.
                    state = json.loads(run('docker', 'inspect', name).stdout)[0]
                    events['api'] = {'oom_killed': state['State']['OOMKilled'],
                                     'running': state['State']['Running'],
                                     'restart_count': state['RestartCount']}
                    require(not events['api']['oom_killed'] and events['api']['running']
                            and events['api']['restart_count'] == 0,
                            'PostgREST512MiB continúa ejecutándose sin OOMKilled ni reinicios registrados por Docker')
            result = {'status': 'passed', 'checks_count': len(checks), 'sql_checks_count': sql_checks,
                      'http_requests_count': len(requests),
                      'storage_emulated_operations': len(blob_operations), 'partial_cases': partial_cases,
                      'large_protocol': large_result, 'memory_events': events,
                      'scope': 'RPC PostgreSQL17/PostgREST16.5 reales; blobStorage emulado local y RLS real. '
                               'No prueba Supabase Storage desplegado ni demuestra causa de502/520 de producción.'}
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except BaseException as error:
            result = {'status': 'failed', 'error': str(error), 'checks_count': len(checks),
                      'http_requests_count': len(requests)}
            raise
        finally:
            result.update(requests=requests, checks=checks, blob_operations=blob_operations)
            (args.resultados / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
            for name in reversed(containers):
                (args.resultados / (name.rsplit('-', 1)[-1] + '.log')).write_text(run('docker', 'logs', name, check=False).stdout)
                run('docker', 'rm', '-f', name, check=False)
            if created_network:
                run('docker', 'network', 'rm', network, check=False)
            log.close()


if __name__ == '__main__':
    main()
