using System.IO.Compression;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Contrato del transporte comprimido: archivos temporales reales y HTTP simulado.
/// No sustituye las pruebas de autorización, transacciones e historial en PostgreSQL/Storage.</summary>
internal static class PublicacionComprimidaCheck
{
    private const string Servidor = "https://comprimido.supabase.co";
    private const string Bucket = "/storage/v1/object/myg-nube-paquetes/";
    private const string BucketAnterior = "/storage/v1/object/myg-nube-archivos/";
    private const string Nombre = "Obra Áncash 漢字 \"exacta\"";
    private const int MiB = 1024 * 1024;
    private static readonly Guid Actor = Guid.Parse("6bd9236b-e727-4588-9ad4-b11c9cf543eb");
    private static readonly Guid OtroActor = Guid.Parse("19470163-daa0-437c-b0e2-990ef137fc60");
    private static readonly Guid Proyecto = Guid.Parse("bdb52eb4-a721-4005-9056-5d8be24a079f");
    private static readonly JsonSerializerOptions Opciones = new() { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping, MaxDepth = 256 };
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        await CodecIdaYVuelta();
        await CodecFragmentado();
        await CodecEntradasHostiles();
        await RestauracionSQLite();
        await PublicarAbrirGuardar();
        await AdjuntosAutocontenidos();
        await RecuperacionDurable();
        await ConflictoYReintento();
        await EdicionRestringida();
        await RenovacionEIdentidad();
        await ConfirmacionesInvalidas();
        await CompatibilidadYCancelacion();
        await GuardadoGrandeConSesionNueva();
        Console.WriteLine($"OK Publicación comprimida: 13 grupos y {comprobaciones} comprobaciones; Gzip/chunks/SHA y SQLite reales, cola en disco y HTTP simulado; sin red.");
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Publicación comprimida: " + detalle);
    }

    private static JsonElement Parse(string json)
    {
        using var doc = JsonDocument.Parse(json, new JsonDocumentOptions { MaxDepth = 256 });
        return doc.RootElement.Clone();
    }

    // Reutiliza los mismos tipos de la regresión de publicación/JSONB: decimal exacto,
    // entero superior a 2^53, blob, nulo, Unicode, tabla nativa y recurso privado.
    private static JsonElement Paquete(string nombre = Nombre, string? carga = null) => JsonSerializer.SerializeToElement(new
    {
        formato = "MYG_COLABORACION", version = 2, alcance = "base",
        documento = new { Id = "QA-DOCUMENTO", Nombre = nombre,
            Importe = 9007199254740993.123456789012m, OtraEscala = 1.0000m, Carga = carga },
        documentos = Array.Empty<object>(),
        tablas = new[] { new { Nombre = "datos_sinteticos", Columnas = new[] { "texto", "entero", "real", "blob", "nulo" },
            Filas = new object?[][] { [new object[] { "s", 0 }, new object[] { "i", "9007199254740993" },
                new object[] { "r", "12.12345678901234567890123456" }, new object[] { "b", "AAECA/8=" }, null] } } },
        textos = new[] { "Áncash 漢字 \"comillas\" C:\\obra\\archivo\r\nsegunda línea" },
        recursos = Array.Empty<object>(), avisos = Array.Empty<string>()
    }, Opciones);

    private static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
    private static async Task<Dictionary<string, byte[]>> Partes(PaqueteComprimidoPreparado paquete)
    {
        var resultado = new Dictionary<string, byte[]>(StringComparer.Ordinal);
        foreach (var parte in paquete.Partes)
        {
            using Stream flujo = parte.AbrirLectura();
            using var copia = new MemoryStream();
            await flujo.CopyToAsync(copia);
            byte[] bytes = copia.ToArray();
            Exige(bytes.Length == parte.Bytes && Hash(bytes) == parte.Sha256, "el segmento no coincide con su longitud o SHA.");
            Exige(parte.Ruta == Actor.ToString("D") + "/" + Proyecto.ToString("N") + "/" + parte.Sha256,
                "el segmento no tiene una ruta canónica de cuenta/proyecto/SHA.");
            if (resultado.TryGetValue(parte.Ruta, out var anterior)) Exige(bytes.SequenceEqual(anterior), "una ruta repetida contiene bytes distintos.");
            else resultado.Add(parte.Ruta, bytes);
        }
        return resultado;
    }

    private static Task<JsonElement> Leer(JsonElement manifest, Dictionary<string, byte[]> partes,
        CancellationToken ct = default) => PaqueteComprimidoNube.LeerAsync(manifest, Proyecto, (ruta, token) =>
    {
        token.ThrowIfCancellationRequested();
        if (!partes.TryGetValue(ruta, out byte[]? bytes)) throw new FileNotFoundException("Segmento sintético ausente.");
        return Task.FromResult<Stream>(new MemoryStream(bytes, writable: false));
    }, ct);

    private static async Task CodecIdaYVuelta()
    {
        JsonElement original = Paquete();
        FormatoPaqueteNube.ValidarSinExpandir(original);
        using var preparado = await PaqueteComprimidoNube.CrearAsync(original, Actor, Proyecto);
        var partes = await Partes(preparado);
        JsonElement manifest = preparado.Manifiesto;
        FormatoManifiesto = manifest.GetProperty("formato").GetString();
        Exige(manifest.EnumerateObject().Count() == 7 && manifest.GetProperty("partes").GetArrayLength() == 1,
            "el manifiesto pequeño tiene propiedades o segmentos imprevistos.");
        Exige(preparado.BytesJson > preparado.BytesGzip && preparado.ShaJson == manifest.GetProperty("sha256_json").GetString(),
            "no se informa el tamaño/SHA real o no se comprimió el caso repetitivo.");
        JsonElement recibido = await Leer(manifest, partes);
        Exige(JsonElement.DeepEquals(original, recibido), "Gzip cambió el contenido, Unicode o los tipos de las celdas.");
        Exige(recibido.GetProperty("documento").GetProperty("Importe").GetDecimal() == 9007199254740993.123456789012m,
            "se perdió precisión decimal al materializar el contenido.");
        Exige(recibido.GetProperty("tablas")[0].GetProperty("Filas")[0][1][1].GetString() == "9007199254740993"
            && recibido.GetProperty("tablas")[0].GetProperty("Filas")[0][4].ValueKind == JsonValueKind.Null,
            "el entero exacto o el nulo SQLite cambió de representación.");
        byte[] gzip = partes.Values.Single();
        using var descompresor = new GZipStream(new MemoryStream(gzip), CompressionMode.Decompress);
        using var json = new MemoryStream();
        await descompresor.CopyToAsync(json);
        Exige(json.Length == preparado.BytesJson && Hash(json.ToArray()) == preparado.ShaJson,
            "un lector Gzip independiente no obtiene los mismos bytes JSON.");
        Exige(JsonElement.DeepEquals(Parse(Encoding.UTF8.GetString(json.ToArray())), original), "el archivo no contiene un JSON interoperable.");
        using var repetido = await PaqueteComprimidoNube.CrearAsync(original, Actor, Proyecto);
        Exige(JsonElement.DeepEquals(manifest, repetido.Manifiesto), "reintentar el mismo contenido cambió las referencias inmutables.");
        Exige(JsonElement.DeepEquals(original, Paquete()), "la preparación modificó el paquete de entrada.");
    }

    private static async Task CodecFragmentado()
    {
        byte[] aleatorio = new byte[9 * MiB];
        new Random(20261028).NextBytes(aleatorio);
        JsonElement original = Paquete(carga: Convert.ToBase64String(aleatorio));
        using var preparado = await PaqueteComprimidoNube.CrearAsync(original, Actor, Proyecto);
        Exige(preparado.Partes.Count >= 2, "el caso no atraviesa el límite de 8 MiB por segmento.");
        long suma = 0;
        for (int i = 0; i < preparado.Partes.Count; i++)
        {
            int bytes = preparado.Partes[i].Bytes;
            Exige(bytes > 0 && bytes <= 8 * MiB && (i == preparado.Partes.Count - 1 || bytes == 8 * MiB),
                "la división no respeta los segmentos de 8 MiB.");
            suma += bytes;
        }
        Exige(suma == preparado.BytesGzip, "la suma de segmentos no coincide con el flujo Gzip.");
        var partes = await Partes(preparado);
        Exige(JsonElement.DeepEquals(await Leer(preparado.Manifiesto, partes), original), "el ensamblado multisegmento cambió el JSON.");
        string primera = preparado.Partes[0].Ruta;
        partes.Remove(primera);
        await RechazaCodec(() => Leer(preparado.Manifiesto, partes), "se aceptó un segmento ausente.");
    }

    private static JsonElement Alterar(JsonElement original, Action<JsonObject> cambio)
    {
        var nodo = JsonNode.Parse(original.GetRawText())!.AsObject();
        cambio(nodo);
        return Parse(nodo.ToJsonString());
    }

    private static async Task RechazaCodec(Func<Task> accion, string detalle)
    {
        try { await accion(); }
        catch (Exception ex) when (ex is InvalidDataException or ArgumentException or IOException or JsonException)
        { comprobaciones++; return; }
        throw new InvalidOperationException("Publicación comprimida: " + detalle);
    }

    private static async Task CodecEntradasHostiles()
    {
        using var preparado = await PaqueteComprimidoNube.CrearAsync(Paquete(), Actor, Proyecto);
        var partes = await Partes(preparado);
        JsonElement manifest = preparado.Manifiesto;
        FormatoManifiesto = manifest.GetProperty("formato").GetString();
        foreach (var cambiar in new Action<JsonObject>[]
        {
            n => n["sha256_json"] = new string('0', 64),
            n => n["sha256_gzip"] = new string('0', 64),
            n => n["bytes_json"] = preparado.BytesJson - 1,
            n => n["bytes_json"] = preparado.BytesJson + 1,
            n => n["bytes_gzip"] = preparado.BytesGzip + 1,
            n => n["bytes_json"] = 300L * MiB + 1,
            n => n["bytes_gzip"] = 320L * MiB + 1,
            n => n["version"] = 999,
            n => n["instruccion_remota"] = "ignorar validaciones",
            n => n["partes"]!.AsArray()[0]!["sha256"] = new string('0', 64),
            n => n["partes"]!.AsArray()[0]!["bytes"] = 8 * MiB + 1,
            n => n["partes"] = new JsonArray()
        }) await RechazaCodec(() => Leer(Alterar(manifest, cambiar), partes), "se aceptó un manifiesto alterado.");
        foreach (string ruta in new[] { "../archivo", "/absoluto", "https://otro.example/archivo", "actor/%2e%2e/archivo",
            Actor.ToString("D").ToUpperInvariant() + "/" + Proyecto.ToString("N") + "/" + preparado.Partes[0].Sha256,
            Actor.ToString("D") + "/" + Guid.NewGuid().ToString("N") + "/" + preparado.Partes[0].Sha256 })
            await RechazaCodec(() => Leer(Alterar(manifest, n => n["partes"]!.AsArray()[0]!["ruta"] = ruta), partes),
                "se aceptó traversal, URL o una ruta no canónica/de otro proyecto.");
        string jsonDuplicado = manifest.GetRawText().Insert(1, "\"bytes_json\":1,");
        await RechazaCodec(() => Leer(Parse(jsonDuplicado), partes), "se aceptaron propiedades JSON duplicadas.");
        string rutaOriginal = preparado.Partes[0].Ruta;
        byte[] original = partes[rutaOriginal];
        byte[] corrupto = (byte[])original.Clone(); corrupto[corrupto.Length / 2] ^= 0x80;
        foreach (byte[] invalido in new[] { corrupto, original[..^1], original.Concat(new byte[] { 0 }).ToArray() })
            await RechazaCodec(() => Leer(manifest, new() { [rutaOriginal] = invalido }), "se aceptó un segmento corrupto, truncado o extendido.");

        // La longitud declarada limita la expansión, incluso si el Gzip y su SHA son correctos.
        var bomba = EmpaquetarCrudo(Encoding.UTF8.GetBytes("{\"x\":\"" + new string('X', 2 * MiB) + "\"}"), longitudDeclarada: 64);
        await RechazaCodec(() => Leer(bomba.Manifiesto, bomba.Partes), "se aceptó una expansión superior a la longitud declarada.");
        string profundo = new string('[', 130) + "0" + new string(']', 130);
        var profundidad = EmpaquetarCrudo(Encoding.UTF8.GetBytes("{\"x\":" + profundo + "}"));
        await RechazaCodec(() => Leer(profundidad.Manifiesto, profundidad.Partes), "se aceptó JSON con profundidad superior a 128.");
        var array = EmpaquetarCrudo(Encoding.UTF8.GetBytes("[1,2,3]"));
        await RechazaCodec(() => Leer(array.Manifiesto, array.Partes), "se aceptó JSON raíz de tipo array.");
        using var cancelacion = new CancellationTokenSource(); cancelacion.Cancel();
        await Cancelada(() => PaqueteComprimidoNube.CrearAsync(Paquete(), Actor, Proyecto, cancelacion.Token));
        await Cancelada(() => Leer(manifest, partes, cancelacion.Token));
    }

    private static async Task RestauracionSQLite()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-comprimido-sqlite-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            var documento = MYGProyectoStorage.Nuevo("Gzip Áncash 漢字");
            var secundario = MYGProyectoStorage.Nuevo("Segunda obra íntegra");
            const decimal precio = 12.12345678901234567890123456m;
            byte[] adjunto = Encoding.UTF8.GetBytes("Adjunto Gzip sin pérdida: á漢字\n");
            string rutaAdjunto = Path.Combine(carpeta, "adjunto.txt");
            File.WriteAllBytes(rutaAdjunto, adjunto);
            documento.Presupuestos[0].Costos.Insumos.Add(new MYGInsumo
                { Descripcion = "Insumo de precisión", Precio = precio, ImagenRuta = rutaAdjunto });
            string origen = Path.Combine(carpeta, "origen.sqlite");
            MYGProyectoStorage.Guardar(origen, documento);
            MYGProyectoStorage.Guardar(origen, secundario);
            byte[] fuenteAntes = SHA256.HashData(File.ReadAllBytes(origen));
            foreach (bool compacto in new[] { false, true })
            {
                JsonElement exportado = PaqueteNube.CrearContenido(documento, origen, "base", compacto);
                using var preparado = await PaqueteComprimidoNube.CrearAsync(exportado, Actor, Proyecto);
                JsonElement recibido = await Leer(preparado.Manifiesto, await Partes(preparado));
                Exige(JsonElement.DeepEquals(recibido, exportado), "el transporte alteró el paquete SQLite v" + (compacto ? 2 : 1) + ".");
                string destino = Path.Combine(carpeta, compacto ? "compacto.sqlite" : "legado.sqlite");
                PaqueteNube.Descargar(recibido, destino);
                var restaurado = MYGBaseDatos.LeerProyecto(destino, documento.Id);
                Exige(MYGBaseDatos.ListarProyectos(destino).Count == 2 && restaurado.Nombre == documento.Nombre,
                    "la descarga comprimida perdió una obra o su identidad.");
                Exige(restaurado.Presupuestos[0].Costos.Insumos[0].Precio == precio,
                    "restaurar la descarga comprimida cambió la precisión decimal.");
                Exige(File.ReadAllBytes(restaurado.Presupuestos[0].Costos.Insumos[0].ImagenRuta).SequenceEqual(adjunto),
                    "restaurar la descarga comprimida cambió el adjunto.");
                using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
                    { DataSource = destino, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
                conexion.Open();
                using var comando = conexion.CreateCommand(); comando.CommandText = "PRAGMA integrity_check";
                Exige((string?)comando.ExecuteScalar() == "ok", "SQLite reconstruido no supera integrity_check.");
            }
            Exige(SHA256.HashData(File.ReadAllBytes(origen)).SequenceEqual(fuenteAntes),
                "publicar o restaurar comprimido modificó el SQLite de origen.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static (JsonElement Manifiesto, Dictionary<string, byte[]> Partes) EmpaquetarCrudo(byte[] json, int? longitudDeclarada = null)
    {
        byte[] gzip;
        using (var archivo = new MemoryStream())
        {
            using (var compresor = new GZipStream(archivo, CompressionLevel.SmallestSize, leaveOpen: true)) compresor.Write(json);
            gzip = archivo.ToArray();
        }
        string sha = Hash(gzip), ruta = Actor.ToString("D") + "/" + Proyecto.ToString("N") + "/" + sha;
        // Se toma el discriminador del codec para no mantener un segundo formato de manifiesto.
        string formato = FormatoManifiesto ?? throw new InvalidOperationException("Inicialice el manifiesto del codec.");
        return (JsonSerializer.SerializeToElement(new { formato, version = 1, sha256_json = Hash(json), bytes_json = longitudDeclarada ?? json.Length,
            sha256_gzip = sha, bytes_gzip = gzip.Length, partes = new[] { new { ruta, sha256 = sha, bytes = gzip.Length } } }), new() { [ruta] = gzip });
    }

    private static string? FormatoManifiesto;

    private static async Task Cancelada(Func<Task> accion)
    {
        try { await accion(); }
        catch (OperationCanceledException) { comprobaciones++; return; }
        throw new InvalidOperationException("Publicación comprimida: se ignoró la cancelación.");
    }

    private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    { Content = new StringContent(JsonSerializer.Serialize(valor, Opciones), Encoding.UTF8, "application/json") };

    private static async Task<(ClienteSupabase Cliente, ServidorSimulado Servidor)> Conectar(bool comprimido = true)
    {
        var servidor = new ServidorSimulado { Comprimido = comprimido };
        var cliente = new ClienteSupabase(Servidor, "sb_publishable_comprimido_sintetico", servidor);
        await cliente.IniciarSesionAsync("cuenta@example.test", "clave_sintetica");
        return (cliente, servidor);
    }

    private static async Task<NubeException> RechazaNube(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException ex) { comprobaciones++; return ex; }
        throw new InvalidOperationException("Publicación comprimida: se aceptó un error o ACK inválido.");
    }

    private static async Task PublicarAbrirGuardar()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-comprimido-cola-" + Guid.NewGuid().ToString("N"));
        try
        {
            JsonElement paquete = Paquete();
            var cola = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Actor.ToString("D"));
            cola.Guardar(new PublicacionPendienteNube(Proyecto, Nombre, "base", paquete));
            byte[] durables = File.ReadAllBytes(cola.RutaActiva);
            var (cliente, servidor) = await Conectar();
            using (cliente)
            {
                var creado = await cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, paquete, "base");
                Exige(creado.Id == Proyecto && creado.Revision == 1 && creado.Contenido.ValueKind == JsonValueKind.Undefined,
                    "la confirmación de creación comprimida no es un ACK de metadatos.");
                Exige(servidor.Subidas > 0 && servidor.CreacionesComprimidas == 1 && servidor.CreacionesLegadas == 0,
                    "la publicación negociada no separó Storage de la RPC pequeña.");
                Exige(File.ReadAllBytes(cola.RutaActiva).SequenceEqual(durables)
                    && JsonElement.DeepEquals(cola.Leer(cola.Consultar()!).Contenido, paquete),
                    "comprimir modificó el JSON congelado, su identidad o la cola durable.");
                var abierto = await cliente.AbrirProyectoAsync(Proyecto);
                Exige(JsonElement.DeepEquals(abierto.Contenido, paquete) && abierto.Revision == 1,
                    "abrir no descargó y verificó el paquete comprimido completo.");
                JsonElement editado = Paquete("Nombre posterior"); Guid operacion = Guid.NewGuid();
                var guardado = await cliente.GuardarProyectoAsync(Proyecto, operacion, 1, editado);
                Exige(guardado.Estado == "aplicada" && guardado.OperacionId == operacion && guardado.Revision == 2
                    && JsonElement.DeepEquals(guardado.Contenido, editado), "guardar perdió la confirmación o el contenido congelado.");
                Exige(servidor.GuardadosComprimidos == 1 && servidor.TextosValidacion == 0,
                    "guardar con todos los permisos volvió a enviar el contenido JSON a PostgreSQL.");
                Exige(JsonElement.DeepEquals((await cliente.AbrirProyectoAsync(Proyecto)).Contenido, editado),
                    "la nueva revisión comprimida no se puede abrir.");
                Exige(servidor.MaxRpcPequena < 16 * 1024, "la RPC transportó un paquete grande en lugar del manifiesto.");
                cola.Confirmar(cola.Consultar()!);
                Exige(cola.Consultar() is null, "la cola no puede cerrarse tras validar el ACK.");
            }
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, recursive: true); }
    }

    private static async Task ConflictoYReintento()
    {
        var (cliente, servidor) = await Conectar();
        using (cliente)
        {
            await cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
            Guid primera = Guid.NewGuid(); JsonElement nuevo = Paquete("Primera edición");
            await cliente.GuardarProyectoAsync(Proyecto, primera, 1, nuevo);
            int objetos = servidor.Objetos.Count;
            var repetido = await cliente.GuardarProyectoAsync(Proyecto, primera, 1, nuevo);
            Exige(repetido.Estado == "aplicada" && repetido.Revision == 2 && JsonElement.DeepEquals(repetido.Contenido, nuevo),
                "repetir el mismo UUID no recuperó el ACK de la operación original.");
            Exige(servidor.Objetos.Count == objetos && servidor.Duplicados > 0 && servidor.DescargasDuplicados > 0,
                "un reintento reemplazó objetos o no verificó el 409 con una descarga exacta.");
            servidor.DuplicadosComo400 = true;
            int descargasAntes = servidor.DescargasDuplicados;
            var repetido400 = await cliente.GuardarProyectoAsync(Proyecto, primera, 1, nuevo);
            Exige(repetido400.Estado == "aplicada" && repetido400.Revision == 2
                && servidor.DescargasDuplicados > descargasAntes && servidor.Objetos.Count == objetos,
                "el duplicado Storage HTTP400 no verificó los bytes del objeto inmutable.");
            servidor.Rechazo400NoDuplicado = true;
            descargasAntes = servidor.DescargasDuplicados;
            await RechazaNube(() => cliente.GuardarProyectoAsync(Proyecto, primera, 1, nuevo));
            Exige(servidor.DescargasDuplicados == descargasAntes,
                "un rechazo Storage400 ajeno a duplicado se trató como éxito o descargó un objeto existente.");
            servidor.Rechazo400NoDuplicado = false;
            Guid operacionConflicto = Guid.NewGuid(); JsonElement borrador = Paquete("Edición obsoleta");
            var conflicto = await cliente.GuardarProyectoAsync(Proyecto, operacionConflicto, 1, borrador);
            Exige(conflicto.Estado == "conflicto" && conflicto.Revision == 2 && JsonElement.DeepEquals(conflicto.Contenido, nuevo),
                "el conflicto CAS devolvió el borrador local en lugar de descargar la revisión vigente.");
            Exige(servidor.Revision == 2, "el conflicto o replay incrementó la revisión remota.");
            await cliente.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 2, Paquete("Tercera revisión"));
            var conflictoRepetido = await cliente.GuardarProyectoAsync(Proyecto, operacionConflicto, 1, borrador);
            Exige(conflictoRepetido.Estado == "conflicto" && conflictoRepetido.Revision == 2
                && JsonElement.DeepEquals(conflictoRepetido.Contenido, nuevo) && servidor.Revision == 3,
                "repetir un conflicto descargó una revisión posterior al snapshot congelado de esa operación.");
            servidor.FallarCommit = true;
            NubeException error = await RechazaNube(() => cliente.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 3, Paquete("Pasarela antes del commit")));
            Exige(error.EsErrorDeConexion && cliente.SesionIniciada && servidor.Revision == 3,
                "el error de pasarela cerró sesión o se convirtió en una confirmación falsa.");
        }
    }

    private static async Task AdjuntosAutocontenidos()
    {
        byte[] archivo = Encoding.UTF8.GetBytes("Plano y memoria Áncash 漢字 íntegros\n");
        string referenciaAnterior = Actor.ToString("D") + "/" + Guid.NewGuid().ToString("N") + "/" + Hash(archivo);
        JsonElement ConAdjunto(string nombre) => Alterar(Paquete(nombre), n => n["recursos"] = JsonSerializer.SerializeToNode(new[]
        {
            new { Referencia = "C:/obra/plano.txt", Nombre = "plano.txt", Sha256 = Hash(archivo),
                Base64 = Convert.ToBase64String(archivo), Almacen = referenciaAnterior }
        }));
        void ExigeAutocontenido(JsonElement contenido)
        {
            JsonElement recurso = contenido.GetProperty("recursos")[0];
            Exige(recurso.GetProperty("Almacen").GetString() == ""
                && Convert.FromBase64String(recurso.GetProperty("Base64").GetString()!).SequenceEqual(archivo),
                "el snapshot comprimido perdió los bytes del adjunto o conserva una dependencia del bucket anterior.");
        }

        var (propietario, nube) = await Conectar();
        using (propietario)
        {
            JsonElement original = ConAdjunto(Nombre); string originalAntes = original.GetRawText();
            JsonElement preparado = await propietario.PrepararArchivosPublicacionAsync(original, Proyecto);
            ExigeAutocontenido(preparado);
            Exige(original.GetRawText() == originalAntes && nube.PeticionesBucketAnterior == 0 && nube.Subidas == 0,
                "preparar la publicación mutó el pendiente o inició una transferencia de adjuntos por separado.");
            await propietario.CrearProyectoConfirmacionAsync(Proyecto, Nombre, preparado, "base");
            ExigeAutocontenido((await propietario.CrearProyectoAsync(Proyecto, Nombre, original, "base")).Contenido);
            JsonElement guardado = await propietario.PrepararArchivosProyectoAsync(ConAdjunto("Adjunto conservado al guardar"),
                Proyecto, Guid.NewGuid());
            ExigeAutocontenido(guardado);
            var respuesta = await propietario.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 1, guardado);
            ExigeAutocontenido(respuesta.Contenido);
            ExigeAutocontenido((await propietario.AbrirProyectoAsync(Proyecto)).Contenido);
            Exige(nube.Revision == 2 && nube.PeticionesBucketAnterior == 0,
                "publicar, abrir o guardar el comprimido requiere el bucket anterior.");
        }

        // El colaborador dispone del bucket nuevo y de la membresía del proyecto;
        // el servidor simulado rechaza cualquier acceso al bucket anterior.
        nube.Cuenta = OtroActor; nube.Rol = "editor";
        using (var colaborador = new ClienteSupabase(Servidor, "sb_publishable_comprimido_sintetico", nube))
        {
            await colaborador.IniciarSesionAsync("colaborador@example.test", "clave_sintetica");
            var abierto = await colaborador.AbrirProyectoAsync(Proyecto);
            ExigeAutocontenido(abierto.Contenido);
            ExigeAutocontenido(await colaborador.CargarArchivosAsync(abierto.Contenido));
            var nuevo = await colaborador.PrepararArchivosProyectoAsync(ConAdjunto("Edición del colaborador"), Proyecto, Guid.NewGuid());
            var aplicado = await colaborador.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 2, nuevo);
            ExigeAutocontenido(aplicado.Contenido);
            Exige(nube.DescargasOtroActor > 0 && nube.Revision == 3 && nube.PeticionesBucketAnterior == 0
                && nube.Objetos.Keys.Any(ruta => ruta.StartsWith(OtroActor.ToString("D") + "/", StringComparison.Ordinal)),
                "el colaborador no abrió y guardó íntegramente mediante los objetos privados nuevos.");
        }
    }

    private static async Task GuardadoGrandeConSesionNueva()
    {
        // Comprobación funcional de selección del protocolo, sin cronómetro ni
        // nuevo benchmark del servidor: el umbral anterior era 127 MiB.
        var (creador, nube) = await Conectar();
        using (creador) await creador.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
        string modelo = Paquete().GetRawText();
        const string campo = "\"Carga\":null";
        int inicio = modelo.IndexOf(campo, StringComparison.Ordinal);
        Exige(inicio >= 0, "el fixture grande no contiene el campo de carga esperado.");
        byte[] prefijo = Encoding.UTF8.GetBytes(modelo[..inicio] + "\"Carga\":\"");
        byte[] sufijo = Encoding.UTF8.GetBytes("\"" + modelo[(inicio + campo.Length)..]);
        const int carga = 127 * MiB + 1;
        byte[] cuerpo = new byte[prefijo.Length + carga + sufijo.Length];
        prefijo.CopyTo(cuerpo, 0); cuerpo.AsSpan(prefijo.Length, carga).Fill((byte)'x');
        sufijo.CopyTo(cuerpo, prefijo.Length + carga);
        nube.ShaJsonEsperado = Hash(cuerpo); nube.BytesJsonEsperados = cuerpo.Length;
        nube.ProhibirGuardadoLegado = true;
        using var documento = JsonDocument.Parse(cuerpo);
        using var nuevoCliente = new ClienteSupabase(Servidor, "sb_publishable_comprimido_sintetico", nube);
        await nuevoCliente.IniciarSesionAsync("cuenta@example.test", "clave_sintetica");
        // No consultar capacidades aquí: esa negociación debe ocurrir dentro de
        // GuardarProyectoAsync antes de construir/enviar una RPC JSON grande.
        var resultado = await nuevoCliente.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 1, documento.RootElement);
        Exige(resultado.Estado == "aplicada" && resultado.Revision == 2 && nube.Revision == 2,
            "el cliente recién iniciado no confirmó el guardado grande por el protocolo comprimido.");
        Exige(nube.GuardadosComprimidos == 1 && nube.GuardadosLegados == 0 && nube.MaxRpcPequena < 16 * 1024,
            "una sesión nueva envió JSON grande a una RPC legada antes de negociar compresión.");
        Exige(nube.BytesGzipGrandes is > 0 and < MiB,
            "la carga repetitiva grande no se transfirió como un archivo comprimido pequeño.");
    }

    private static async Task RecuperacionDurable()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-comprimido-recuperacion-" + Guid.NewGuid().ToString("N"));
        try
        {
            JsonElement paquete = Paquete();
            var cola = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Actor.ToString("D"));
            cola.Guardar(new PublicacionPendienteNube(Proyecto, Nombre, "base", paquete));
            byte[] original = File.ReadAllBytes(cola.RutaActiva);
            var servidor = new ServidorSimulado { PerderAckCreacion = true };
            using (var primero = new ClienteSupabase(Servidor, "sb_publishable_comprimido_sintetico", servidor))
            {
                await primero.IniciarSesionAsync("cuenta@example.test", "clave_sintetica");
                var error = await RechazaNube(() => primero.CrearProyectoConfirmacionAsync(Proyecto, Nombre, paquete, "base"));
                Exige(error.EsErrorDeConexion && servidor.Revision == 1 && primero.SesionIniciada,
                    "la pérdida del ACK de creación no conserva el resultado remoto incierto y la sesión.");
                Exige(File.ReadAllBytes(cola.RutaActiva).SequenceEqual(original),
                    "perder la confirmación borró o modificó el pendiente local.");
            }
            servidor.PerderAckCreacion = false;
            var recuperada = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Actor.ToString("D"));
            var resumen = recuperada.Consultar()!;
            var pendiente = recuperada.Leer(resumen);
            Exige(pendiente.Id == Proyecto && JsonElement.DeepEquals(pendiente.Contenido, paquete),
                "abrir de nuevo el almacén no recuperó el UUID o los datos originales.");
            using (var segundo = new ClienteSupabase(Servidor, "sb_publishable_comprimido_sintetico", servidor))
            {
                await segundo.IniciarSesionAsync("cuenta@example.test", "clave_sintetica");
                var confirmado = await segundo.CrearProyectoConfirmacionAsync(pendiente.Id, pendiente.Nombre,
                    pendiente.Contenido, pendiente.Alcance);
                Exige(confirmado.Revision == 1 && servidor.Revision == 1 && servidor.CreacionesComprimidas == 2,
                    "reintentar el pendiente recuperado creó otra revisión/proyecto.");
                recuperada.Confirmar(resumen);
                Exige(recuperada.Consultar() is null, "el pendiente recuperado no se cierra después del ACK verificado.");
                Guid operacion = Guid.NewGuid(); JsonElement nuevo = Paquete("Guardado cuyo ACK se pierde");
                servidor.PerderAckGuardado = true;
                var error = await RechazaNube(() => segundo.GuardarProyectoAsync(Proyecto, operacion, 1, nuevo));
                Exige(error.EsErrorDeConexion && servidor.Revision == 2,
                    "la prueba de ACK perdido de guardado no aplicó la revisión antes de perder la respuesta.");
                servidor.PerderAckGuardado = false;
                var replay = await segundo.GuardarProyectoAsync(Proyecto, operacion, 1, nuevo);
                Exige(replay.Estado == "aplicada" && replay.Revision == 2 && servidor.Revision == 2
                    && JsonElement.DeepEquals(replay.Contenido, nuevo), "recuperar el ACK de guardado duplicó la revisión o confirmó otros datos.");
            }
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, recursive: true); }
    }

    private static async Task EdicionRestringida()
    {
        var (cliente, servidor) = await Conectar();
        using (cliente)
        {
            await cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
            servidor.PermisosCompletos = false; servidor.Rol = "editor";
            var aplicado = await cliente.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 1, Paquete("Cambio general autorizado"));
            Exige(aplicado.Estado == "aplicada" && servidor.TextosValidacion == 1 && servidor.LecturasRevisionExacta > 0,
                "la edición restringida no envió el anterior/nuevo exacto que permite validar los módulos en SQL.");
            servidor.Rol = "lector";
            int subidas = servidor.Subidas, commits = servidor.GuardadosComprimidos;
            await RechazaNube(() => cliente.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 2, Paquete("No autorizado")));
            Exige(servidor.Subidas == subidas && servidor.GuardadosComprimidos == commits,
                "un lector inició una subida o un commit de escritura.");
        }
        foreach (bool revocarRol in new[] { false, true })
        {
            var (editor, nube) = await Conectar();
            using (editor)
            {
                await editor.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
                nube.Rol = "editor";
                nube.RevocarRolTrasSubida = revocarRol;
                nube.RevocarModuloTrasSubida = !revocarRol;
                JsonElement borrador = Paquete("Borrador con permiso revocado durante la transferencia");
                var error = await RechazaNube(() => editor.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 1, borrador));
                Exige(error.Codigo == "42501" && editor.SesionIniciada && nube.Revision == 1,
                    "revocar el rol o un módulo durante la subida permitió confirmar o cerró la sesión.");
                Exige(JsonElement.DeepEquals((await editor.AbrirProyectoAsync(Proyecto)).Contenido, Paquete())
                    && borrador.GetProperty("documento").GetProperty("Nombre").GetString()!
                        .Contains("Borrador", StringComparison.Ordinal),
                    "rechazar por permisos reemplazó el proyecto remoto o el borrador del cliente.");
            }
        }
    }

    private static async Task RenovacionEIdentidad()
    {
        foreach (bool cambiarIdentidad in new[] { false, true })
        {
            var (cliente, servidor) = await Conectar();
            using (cliente)
            {
                servidor.RechazarPrimeraSubida = true; servidor.CambiarIdentidad = cambiarIdentidad;
                if (cambiarIdentidad)
                {
                    await RechazaNube(() => cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base"));
                    Exige(!cliente.SesionIniciada && servidor.CreacionesComprimidas == 0 && servidor.Objetos.Count == 0,
                        "renovar con otra cuenta permitió confirmar o subir bajo la identidad equivocada.");
                }
                else
                {
                    await cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
                    Exige(servidor.Renovaciones == 1 && servidor.CreacionesComprimidas == 1
                        && servidor.Intento401 is not null && servidor.Reintento401 is not null
                        && servidor.Intento401.SequenceEqual(servidor.Reintento401),
                        "renovar 401 cambió los bytes Gzip o no confirmó con la misma identidad.");
                }
            }
        }
    }

    private static async Task ConfirmacionesInvalidas()
    {
        var (cliente, servidor) = await Conectar();
        using (cliente)
        {
            servidor.AckCreacionInvalido = true;
            await RechazaNube(() => cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base"));
            Exige(cliente.SesionIniciada, "un ACK inválido cerró la sesión.");
            servidor.AckCreacionInvalido = false;
            await cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
            servidor.AckOperacionInvalido = true;
            await RechazaNube(() => cliente.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 1, Paquete("ACK operación inválido")));
            Exige(cliente.SesionIniciada, "un ACK de otra operación cerró la sesión.");
            servidor.AckOperacionInvalido = false;
            servidor.CorromperDescarga = true;
            await RechazaNube(() => cliente.AbrirProyectoAsync(Proyecto));
            Exige(cliente.SesionIniciada, "una descarga corrupta cerró la sesión.");
        }
    }

    private static async Task CompatibilidadYCancelacion()
    {
        var (cliente, servidor) = await Conectar(comprimido: false);
        using (cliente)
        {
            await cliente.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
            Exige(servidor.CreacionesLegadas == 1 && servidor.CreacionesComprimidas == 0 && servidor.Subidas == 0,
                "un servidor sin la capacidad nueva recibió tráfico del protocolo comprimido.");
            Exige(JsonElement.DeepEquals((await cliente.AbrirProyectoAsync(Proyecto)).Contenido, Paquete()),
                "el cliente actualizado no puede abrir un proyecto legado en un servidor anterior.");
        }
        var (creador, nube) = await Conectar();
        using (creador) await creador.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
        using (var nuevoCliente = new ClienteSupabase(Servidor, "sb_publishable_comprimido_sintetico", nube))
        {
            await nuevoCliente.IniciarSesionAsync("cuenta@example.test", "clave_sintetica");
            Exige(JsonElement.DeepEquals((await nuevoCliente.AbrirProyectoAsync(Proyecto)).Contenido, Paquete())
                && nube.RechazosLegados == 1, "un cliente nuevo no descubre MGC01 y abre correctamente un proyecto comprimido existente.");
        }
        var (actualizado, legado) = await Conectar();
        using (actualizado)
        {
            legado.AlmacenamientoJson = true;
            await actualizado.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base");
            Exige(legado.CreacionesLegadas == 1 && legado.CreacionesComprimidas == 0 && legado.Subidas == 0,
                "reintentar un UUID legado en un servidor actualizado lo convirtió a comprimido.");
            Exige(JsonElement.DeepEquals((await actualizado.AbrirProyectoAsync(Proyecto)).Contenido, Paquete()),
                "el servidor con compresión dejó de abrir un proyecto JSON existente.");
            var guardado = await actualizado.GuardarProyectoAsync(Proyecto, Guid.NewGuid(), 1, Paquete("JSON anterior editado"));
            Exige(guardado.Estado == "aplicada" && legado.GuardadosComprimidos == 0 && legado.Subidas == 0,
                "editar un proyecto JSON existente cambió su almacenamiento.");
        }
        var (cancelado, remoto) = await Conectar();
        using (cancelado)
        {
            int peticiones = remoto.Peticiones;
            using var ct = new CancellationTokenSource(); ct.Cancel();
            await Cancelada(() => cancelado.CrearProyectoConfirmacionAsync(Proyecto, Nombre, Paquete(), "base", ct.Token));
            Exige(remoto.Peticiones == peticiones && remoto.Objetos.Count == 0,
                "cancelar antes de publicar inició red o creó objetos.");
        }
    }

    private sealed class ServidorSimulado : HttpMessageHandler
    {
        internal readonly Dictionary<string, byte[]> Objetos = new(StringComparer.Ordinal);
        private readonly Dictionary<long, JsonElement> historial = new();
        private readonly Dictionary<Guid, (string Estado, long Revision, JsonElement Manifest, long Base, string Sha)> operaciones = new();
        internal bool Comprimido = true, PermisosCompletos = true, FallarCommit, RechazarPrimeraSubida,
            CambiarIdentidad, AckCreacionInvalido, AckOperacionInvalido, CorromperDescarga,
            DuplicadosComo400, Rechazo400NoDuplicado, PerderAckCreacion, PerderAckGuardado, AlmacenamientoJson,
            RevocarRolTrasSubida, RevocarModuloTrasSubida, ProhibirGuardadoLegado;
        internal string Rol = "propietario";
        internal Guid Cuenta = Actor;
        internal int Peticiones, Subidas, CreacionesComprimidas, CreacionesLegadas, GuardadosComprimidos,
            TextosValidacion, Duplicados, DescargasDuplicados, Renovaciones, LecturasRevisionExacta, MaxRpcPequena, RechazosLegados,
            PeticionesBucketAnterior, DescargasOtroActor, GuardadosLegados;
        internal long Revision;
        internal string? ShaJsonEsperado;
        internal long BytesJsonEsperados, BytesGzipGrandes;
        internal byte[]? Intento401, Reintento401;
        private string? duplicadoPendiente;
        private JsonElement actual;

        // La nube simulada sobrevive a los clientes desechados para verificar
        // recuperación después de cerrar/reabrir la aplicación. No posee sockets.
        protected override void Dispose(bool disposing) { }

        private object Metadata(JsonElement? contenido = null, long? revision = null, Guid? id = null) => contenido is null
            ? new { id = id ?? Proyecto, codigo = "MYG-COMPRIMIDO", nombre = Nombre, rol = Rol, revision = revision ?? Revision,
                alcance = "base", permisos_modulos = new { acu = true, especificaciones = PermisosCompletos, metrados_excel = true } }
            : new { id = id ?? Proyecto, codigo = "MYG-COMPRIMIDO", nombre = Nombre, rol = Rol, revision = revision ?? Revision,
                alcance = "base", permisos_modulos = new { acu = true, especificaciones = PermisosCompletos, metrados_excel = true }, contenido = contenido.Value };

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested(); Peticiones++;
            Exige(solicitud.RequestUri?.Host == "comprimido.supabase.co", "se envió una petición fuera del servidor configurado.");
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token")
            {
                bool refresco = solicitud.RequestUri.Query == "?grant_type=refresh_token";
                if (refresco) Renovaciones++;
                return Json(new { access_token = refresco ? "acceso_renovado" : "acceso_original", refresh_token = "refresco_sintetico",
                    expires_in = 3600, user = new { id = refresco && CambiarIdentidad ? OtroActor : Cuenta } });
            }
            Exige(solicitud.Headers.Authorization?.Scheme == "Bearer" && solicitud.Headers.Contains("apikey"),
                "una operación privada perdió la sesión o la clave pública.");
            if (ruta.StartsWith(BucketAnterior, StringComparison.Ordinal))
            {
                PeticionesBucketAnterior++;
                throw new InvalidOperationException("El snapshot comprimido depende del bucket de adjuntos anterior.");
            }
            if (ruta.StartsWith(Bucket, StringComparison.Ordinal))
            {
                string clave = ruta[Bucket.Length..];
                if (solicitud.Method == HttpMethod.Post)
                {
                    Subidas++;
                    Exige(!solicitud.Headers.Contains("x-upsert") && solicitud.Content?.Headers.ContentType?.MediaType == "application/octet-stream",
                        "una subida permitió reemplazar objetos o codificó el Gzip como texto.");
                    byte[] bytes = await solicitud.Content!.ReadAsByteArrayAsync(ct);
                    Exige(bytes.Length > 0 && bytes.Length <= 8 * MiB && clave == Cuenta.ToString("D") + "/" + Proyecto.ToString("N") + "/" + Hash(bytes),
                        "Storage recibió un segmento demasiado grande o cuya ruta no coincide con los bytes.");
                    if (RechazarPrimeraSubida)
                    {
                        RechazarPrimeraSubida = false; Intento401 = bytes;
                        return Json(new { code = "PGRST301" }, HttpStatusCode.Unauthorized);
                    }
                    if (Intento401 is not null && Reintento401 is null) Reintento401 = bytes;
                    if (Rechazo400NoDuplicado)
                        return Json(new { statusCode = "400", error = "InvalidRequest", message = "detalle remoto privado" }, HttpStatusCode.BadRequest);
                    if (Objetos.ContainsKey(clave))
                    {
                        Duplicados++; duplicadoPendiente = clave;
                        return DuplicadosComo400
                            ? Json(new { statusCode = "409", error = "Duplicate", message = "The resource already exists" }, HttpStatusCode.BadRequest)
                            : Json(new { error = "Duplicate" }, HttpStatusCode.Conflict);
                    }
                    Objetos.Add(clave, bytes);
                    if (RevocarRolTrasSubida) { Rol = "lector"; RevocarRolTrasSubida = false; }
                    if (RevocarModuloTrasSubida) { PermisosCompletos = false; RevocarModuloTrasSubida = false; }
                    return Json(new { Key = clave });
                }
                Exige(solicitud.Method == HttpMethod.Get, "Storage recibió una operación mutable distinta de la subida.");
                if (Cuenta == OtroActor) DescargasOtroActor++;
                if (duplicadoPendiente == clave) { DescargasDuplicados++; duplicadoPendiente = null; }
                if (!Objetos.TryGetValue(clave, out byte[]? existente)) return Json(new { error = "NotFound" }, HttpStatusCode.NotFound);
                byte[] copia = (byte[])existente.Clone();
                if (CorromperDescarga) copia[copia.Length / 2] ^= 0x40;
                return new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(copia) };
            }
            Exige(solicitud.Method == HttpMethod.Post && ruta.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal),
                "se cambió la ruta o método de una RPC.");
            string rpc = ruta["/rest/v1/rpc/".Length..];
            if (rpc == "myg_nube_guardar")
            {
                GuardadosLegados++;
                Exige(!ProhibirGuardadoLegado, "se intentó enviar el paquete grande por myg_nube_guardar legado.");
            }
            byte[] cuerpo = await solicitud.Content!.ReadAsByteArrayAsync(ct);
            using var doc = JsonDocument.Parse(cuerpo); JsonElement args = doc.RootElement;
            if (rpc != "myg_nube_crear_confirmacion" && rpc != "myg_nube_guardar_comprimido") MaxRpcPequena = Math.Max(MaxRpcPequena, cuerpo.Length);
            switch (rpc)
            {
                case "myg_nube_capacidades":
                    return Json(Comprimido
                        ? new Dictionary<string, int> { ["paquete_compacto"] = 2, ["cambios"] = 1, ["max_contenido_mib"] = 300,
                            ["publicacion_ligera"] = 1, ["publicacion_comprimida"] = 1 }
                        : new Dictionary<string, int> { ["paquete_compacto"] = 2, ["cambios"] = 1, ["max_contenido_mib"] = 300, ["publicacion_ligera"] = 1 });
                case "myg_nube_estado_publicacion":
                    if (AlmacenamientoJson && Revision == 0) { Revision = 1; actual = Paquete(); historial[1] = actual; }
                    return Json(new { estado = Revision > 0 ? "existente" : "disponible" });
                case "myg_nube_paquete_tipo": return Json(new { almacenamiento = AlmacenamientoJson ? "json" : "gzip" });
                case "myg_nube_revision": return Json(Metadata());
                case "myg_nube_crear_confirmacion":
                    CreacionesLegadas++; Revision = 1;
                    Exige(JsonElement.DeepEquals(args.GetProperty("p_contenido"), Paquete()), "el fallback alteró el paquete legado.");
                    actual = args.GetProperty("p_contenido").Clone(); historial[1] = actual;
                    return Json(Metadata());
                case "myg_nube_crear_comprimido":
                    CreacionesComprimidas++;
                    Exige(args.GetProperty("p_id").GetGuid() == Proyecto && args.GetProperty("p_nombre").GetString() == Nombre
                        && args.GetProperty("p_alcance").GetString() == "base" && !args.TryGetProperty("p_contenido", out _),
                        "crear cambió identidad o volvió a enviar el JSON completo.");
                    MaxRpcPequena = Math.Max(MaxRpcPequena, cuerpo.Length);
                    JsonElement inicial = args.GetProperty("p_manifest").Clone();
                    await VerificarManifest(inicial, ct);
                    if (Revision == 0) { actual = inicial; Revision = 1; historial[1] = inicial; }
                    else Exige(inicial.GetProperty("sha256_json").GetString() == historial[1].GetProperty("sha256_json").GetString(),
                        "reutilizar el UUID cambió el contenido inicial de la publicación.");
                    if (PerderAckCreacion) return Json(new { error = "cuerpo_remoto_privado" }, HttpStatusCode.BadGateway);
                    return Json(Metadata(revision: 1, id: AckCreacionInvalido ? OtroActor : Proyecto));
                case "myg_nube_abrir_comprimido":
                    long lectura = Revision;
                    if (args.TryGetProperty("p_revision", out var rev) && rev.ValueKind != JsonValueKind.Null)
                    { lectura = rev.GetInt64(); LecturasRevisionExacta++; }
                    Exige(historial.ContainsKey(lectura), "se solicitó una revisión inexistente del historial.");
                    return Json(Metadata(historial[lectura], lectura));
                case "myg_nube_abrir":
                    if (!Comprimido || AlmacenamientoJson) return Json(Metadata(actual));
                    RechazosLegados++;
                    return Json(new { code = "MGC01", message = "MYG_PAQUETE_COMPRIMIDO" }, HttpStatusCode.BadRequest);
                case "myg_nube_guardar":
                    Exige(AlmacenamientoJson || !Comprimido, "el cliente envió el protocolo legado a un proyecto comprimido.");
                    actual = args.GetProperty("p_contenido").Clone(); Revision++;
                    return Json(new { estado = "aplicada", revision = Revision, contenido = actual,
                        operacion_id = args.GetProperty("p_operacion").GetGuid() });
                case "myg_nube_guardar_comprimido":
                    GuardadosComprimidos++;
                    if (FallarCommit) return Json(new { error = "cuerpo_remoto_privado" }, HttpStatusCode.BadGateway);
                    Guid operacion = args.GetProperty("p_operacion").GetGuid(); long revisionBase = args.GetProperty("p_revision").GetInt64();
                    JsonElement manifest = args.GetProperty("p_manifest").Clone();
                    await VerificarManifest(manifest, ct);
                    bool conAnterior = args.GetProperty("p_anterior").ValueKind == JsonValueKind.String;
                    bool conNuevo = args.GetProperty("p_nuevo").ValueKind == JsonValueKind.String;
                    Exige(conAnterior == conNuevo, "se envió sólo uno de los textos de validación.");
                    if (Rol == "lector" || (!PermisosCompletos && !conAnterior))
                        return Json(new { code = "42501", message = "MYG_MODULO_NO_PERMITIDO" }, HttpStatusCode.Forbidden);
                    if (conAnterior)
                    {
                        TextosValidacion++;
                        Exige(!PermisosCompletos && Hash(Encoding.UTF8.GetBytes(args.GetProperty("p_anterior").GetString()!))
                            == historial[revisionBase].GetProperty("sha256_json").GetString()
                            && Hash(Encoding.UTF8.GetBytes(args.GetProperty("p_nuevo").GetString()!)) == manifest.GetProperty("sha256_json").GetString(),
                            "la validación de módulos recibió texto ajeno a la revisión o al nuevo manifiesto.");
                    }
                    else MaxRpcPequena = Math.Max(MaxRpcPequena, cuerpo.Length);
                    string sha = manifest.GetProperty("sha256_json").GetString()!;
                    if (operaciones.TryGetValue(operacion, out var confirmada))
                    {
                        Exige(confirmada.Base == revisionBase && confirmada.Sha == sha, "un replay cambió los datos de la operación congelada.");
                        return confirmada.Estado == "aplicada"
                            ? Json(new { estado = "aplicada", revision = confirmada.Revision, operacion_id = operacion })
                            : Json(new { estado = "conflicto", revision = confirmada.Revision, operacion_id = operacion, contenido = confirmada.Manifest });
                    }
                    if (revisionBase != Revision)
                    {
                        operaciones[operacion] = ("conflicto", Revision, actual, revisionBase, sha);
                        return Json(new { estado = "conflicto", revision = Revision, operacion_id = operacion, contenido = actual });
                    }
                    Revision++; actual = manifest; historial[Revision] = actual;
                    operaciones[operacion] = ("aplicada", Revision, manifest, revisionBase, sha);
                    if (PerderAckGuardado) return Json(new { error = "cuerpo_remoto_privado" }, HttpStatusCode.BadGateway);
                    return Json(new { estado = "aplicada", revision = Revision, operacion_id = AckOperacionInvalido ? OtroActor : operacion });
                default: throw new InvalidOperationException("RPC no prevista en prueba comprimida: " + rpc);
            }
        }

        private async Task VerificarManifest(JsonElement manifest, CancellationToken ct)
        {
            FormatoManifiesto = manifest.GetProperty("formato").GetString();
            if (ShaJsonEsperado is not null)
            {
                // Este caso verifica selección del protocolo y bytes realmente
                // subidos; el codec ya tiene pruebas independientes de expansión.
                Exige(manifest.GetProperty("sha256_json").GetString() == ShaJsonEsperado
                    && manifest.GetProperty("bytes_json").GetInt64() == BytesJsonEsperados,
                    "el manifiesto grande no representa el JSON UTF8 preparado.");
                using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                long total = 0;
                foreach (JsonElement parte in manifest.GetProperty("partes").EnumerateArray())
                {
                    ct.ThrowIfCancellationRequested();
                    byte[] bytes = Objetos[parte.GetProperty("ruta").GetString()!];
                    Exige(bytes.Length == parte.GetProperty("bytes").GetInt32()
                        && Hash(bytes) == parte.GetProperty("sha256").GetString(),
                        "una parte grande no coincide con sus bytes o su SHA.");
                    hash.AppendData(bytes); total += bytes.Length;
                }
                Exige(total == manifest.GetProperty("bytes_gzip").GetInt64()
                    && Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant() == manifest.GetProperty("sha256_gzip").GetString(),
                    "el Gzip grande subido no coincide con la longitud o el SHA del manifiesto.");
                BytesGzipGrandes = total;
                return;
            }
            JsonElement leido = await Leer(manifest, Objetos, ct);
            Exige(leido.GetProperty("formato").GetString() == "MYG_COLABORACION", "el manifiesto no referencia el paquete completo.");
        }
    }
}
