using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGCronogramaGanttControl : ScrollableControl
{
    private IReadOnlyList<MYGResultadoTarea> filas = Array.Empty<MYGResultadoTarea>();
    private MYGCalendarioTrabajo calendario = new();
    private readonly Dictionary<string, RectangleF> barras = new();
    private readonly HashSet<string> seleccion = new();
    private DateTime origen = DateTime.Today, limite = DateTime.Today.AddMonths(1), estado = DateTime.Today;
    private float pixelesDia = 24;
    private int altoFila = 26, altoCabecera = 48;
    private bool sincronizando, critica, lineaBase = true;
    private IReadOnlySet<string> criticasVista;
    private string arrastre;
    private Point puntoArrastre;
    private DateTime inicioArrastre;
    private MYGOpcionesVistaCronograma presentacion = new();
    private readonly CabeceraFija cabecera;
    // La escala es una ventana hermana: ScrollWindowEx sólo puede copiar
    // píxeles del cuerpo y nunca una cabecera que después haya que borrar.
    internal Control Cabecera => cabecera;
    internal void ConfigurarPresentacion(MYGOpcionesVistaCronograma opciones, MYGProyectoDocumento proyecto, bool actualizarImportes = false)
    {
        presentacion = opciones ?? new();
        // Las etiquetas guardadas siguen siendo compatibles con los reportes,
        // pero el diagrama en pantalla muestra exclusivamente barras y vínculos.
        Invalidate();
        cabecera.Invalidate();
    }
    internal event Action<string> TareaSeleccionada, TareaDobleClick;
    internal event Action<string, DateTime> InicioCambiado;
    internal event Action<int> PrimeraFilaCambiada;
    internal event Action ZoomCambiado;

    internal MYGCronogramaGanttControl()
    {
        cabecera = new CabeceraFija(this) { Dock = DockStyle.Top, Height = altoCabecera };
        Name = "cronograma_gantt"; Dock = DockStyle.Fill; AutoScroll = true;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        AccessibleName = "Diagrama de Gantt del cronograma";
        AccessibleDescription = "Seleccione una barra para ver su tarea. Arrástrela para establecer un inicio manual. Ctrl y rueda cambian el zoom.";
        BackColor = MYG2027_TemaComercial.Superficie;
        Disposed += (_, _) => cabecera.Dispose();
    }
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal int AltoFila { get => altoFila; set { altoFila = Math.Max(18, value); ActualizarTamano(); } }
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal int AltoCabecera
    {
        get => altoCabecera;
        set { altoCabecera = Math.Max(30, value); cabecera.Height = altoCabecera; cabecera.Invalidate(); ActualizarTamano(); }
    }
    internal int PrimeraFilaVisible => Math.Max(0, -AutoScrollPosition.Y / altoFila);
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal bool MostrarCritica { get => critica; set { critica = value; Invalidate(); } }
    internal void DefinirCriticas(IReadOnlySet<string> ids) { criticasVista = ids; Invalidate(); }
    internal bool EsCritica(MYGResultadoTarea fila) => critica && (criticasVista?.Contains(fila.Tarea.Id) ?? fila.EsCritica);
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal bool MostrarLineaBase { get => lineaBase; set { lineaBase = value; Invalidate(); } }
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal float PixelesPorDia
    {
        get => pixelesDia;
        set
        {
            float nuevo = Math.Clamp(value, .25f, 80f);
            if (Math.Abs(nuevo - pixelesDia) < .001f) return;
            DateTime centro = FechaEnX(ClientSize.Width / 2);
            pixelesDia = nuevo; ActualizarTamano(); IrFecha(centro, true); ZoomCambiado?.Invoke();
        }
    }
    internal void Cargar(IReadOnlyList<MYGResultadoTarea> visibles, MYGCalendarioTrabajo dias, DateTime fechaEstado)
    {
        filas = visibles ?? Array.Empty<MYGResultadoTarea>(); calendario = dias ?? new(); estado = fechaEstado.Date;
        var fechas = filas.SelectMany(f => new[] { f.Inicio, f.Fin, f.Tarea.InicioBase ?? f.Inicio, f.Tarea.FinBase ?? f.Fin }).ToArray();
        DateTime primera = fechas.Length == 0 ? estado : fechas.Min();
        DateTime ultima = fechas.Length == 0 ? estado.AddDays(30) : fechas.Max();
        origen = primera > DateTime.MinValue.AddDays(3) ? primera.AddDays(-3).Date : primera.Date;
        limite = ultima < DateTime.MaxValue.AddDays(-14) ? ultima.AddDays(14).Date : ultima.Date;
        ActualizarTamano();
    }
    internal void Seleccionar(IEnumerable<string> ids)
    { seleccion.Clear(); foreach (string id in ids) seleccion.Add(id); Invalidate(); }
    internal void MostrarFila(int indice)
    {
        if (sincronizando) return;
        sincronizando = true;
        try { AutoScrollPosition = new Point(-AutoScrollPosition.X, Math.Max(0, indice) * altoFila); }
        finally { sincronizando = false; }
        RepintarDesplazamiento();
    }
    internal void IrFecha(DateTime fecha, bool centrar = false)
    {
        int x = Math.Max(0, (int)((fecha.Date - origen).TotalDays * pixelesDia) - (centrar ? ClientSize.Width / 2 : 0));
        AutoScrollPosition = new Point(x, -AutoScrollPosition.Y); RepintarDesplazamiento();
    }
    internal void AjustarProyecto()
    { PixelesPorDia = Math.Max(.25f, (ClientSize.Width - 60) / (float)Math.Max(1, (limite - origen).TotalDays)); IrFecha(origen); }
    private void ActualizarTamano()
    {
        AutoScrollMinSize = new Size(Math.Max(ClientSize.Width - 1, (int)Math.Ceiling((limite - origen).TotalDays * pixelesDia)),
            filas.Count * altoFila);
        VerticalScroll.SmallChange = altoFila; HorizontalScroll.SmallChange = Math.Max(1, (int)pixelesDia);
        Invalidate();
        cabecera.Invalidate();
    }
    protected override void OnClientSizeChanged(EventArgs e)
    {
        base.OnClientSizeChanged(e);
        // El ancho útil cambia también al aparecer una barra nativa.
        cabecera?.Invalidate();
    }
    protected override void OnFontChanged(EventArgs e)
    {
        base.OnFontChanged(e);
        cabecera?.Invalidate();
    }
    protected override void OnScroll(ScrollEventArgs se)
    {
        base.OnScroll(se);
        if (!sincronizando && se.ScrollOrientation == ScrollOrientation.VerticalScroll)
            PrimeraFilaCambiada?.Invoke(Math.Max(0, -AutoScrollPosition.Y / altoFila));
        RepintarDesplazamiento();
    }
    protected override void OnMouseWheel(MouseEventArgs e)
    {
        if ((ModifierKeys & Keys.Control) != 0) PixelesPorDia *= e.Delta > 0 ? 1.25f : .8f;
        else
        {
            int anterior = AutoScrollPosition.Y;
            base.OnMouseWheel(e);
            // La rueda nativa no emite Scroll; sincronizar la fila de la tabla.
            // La cabecera está fuera de esta ventana y no se desplaza ni copia.
            if (!sincronizando && anterior != AutoScrollPosition.Y)
                PrimeraFilaCambiada?.Invoke(PrimeraFilaVisible);
            RepintarDesplazamiento();
        }
    }
    private void RepintarDesplazamiento()
    {
        if (IsDisposed || Disposing) return;
        Invalidate();
        if (IsHandleCreated) Update();
        if (!cabecera.IsDisposed)
        {
            cabecera.Invalidate();
            if (cabecera.IsHandleCreated) cabecera.Update();
        }
    }
    private float X(DateTime fecha) => (float)(fecha.Date - origen).TotalDays * pixelesDia + AutoScrollPosition.X;
    private DateTime FechaEnX(int x)
    {
        double dias = Math.Floor((x - AutoScrollPosition.X) / pixelesDia);
        return origen.AddDays(Math.Clamp(dias, 0, Math.Max(0, (DateTime.MaxValue.Date - origen).TotalDays)));
    }
    private RectangleF Rectangulo(MYGResultadoTarea f, int i)
    {
        float x = X(f.Inicio), ancho = Math.Max(3, ((float)(f.Fin.Date - f.Inicio.Date).TotalDays + 1) * pixelesDia);
        return new RectangleF(x, i * altoFila + AutoScrollPosition.Y + 6, ancho, Math.Max(8, altoFila - 13));
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics; g.Clear(MYG2027_TemaComercial.Superficie);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        barras.Clear();
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        using var fondoLibre = new SolidBrush(MYG2027_TemaComercial.SuperficieAlterna);
        using var fondoSeleccion = new SolidBrush(MYG2027_TemaComercial.Seleccion);
        DateTime desde = FechaEnX(0), hasta = FechaEnX(ClientSize.Width);
        if (hasta < DateTime.MaxValue.Date) hasta = hasta.AddDays(1);
        if (pixelesDia >= 3)
            for (DateTime d = desde; d <= hasta; d = d.AddDays(1))
            {
                if (!calendario.DiasLaborables.Contains(d.DayOfWeek) || calendario.Feriados.Any(f => f.Date == d.Date))
                    g.FillRectangle(fondoLibre, X(d), 0, pixelesDia, ClientSize.Height);
                if (pixelesDia >= 12 || d.DayOfWeek == DayOfWeek.Monday)
                    g.DrawLine(borde, X(d), 0, X(d), ClientSize.Height);
                if (d == DateTime.MaxValue.Date) break;
            }
        int primero = Math.Max(0, -AutoScrollPosition.Y / altoFila);
        int ultimo = Math.Min(filas.Count, primero + Math.Max(1, ClientSize.Height / altoFila) + 2);
        for (int i = primero; i < ultimo; i++)
        {
            var f = filas[i]; float y = i * altoFila + AutoScrollPosition.Y;
            if (seleccion.Contains(f.Tarea.Id)) g.FillRectangle(fondoSeleccion, 0, y, ClientSize.Width, altoFila);
            g.DrawLine(borde, 0, y + altoFila, ClientSize.Width, y + altoFila);
            var r = Rectangulo(f, i); barras[f.Tarea.Id] = r;
        }
        DibujarVinculos(g, primero, ultimo);
        for (int i = primero; i < ultimo; i++) DibujarBarra(g, filas[i], barras[filas[i].Tarea.Id]);
        if (estado >= origen && estado <= limite)
        {
            using var rojo = new Pen(Color.FromArgb(210, 55, 58), 1.5f) { DashStyle = DashStyle.Dash };
            g.DrawLine(rojo, X(estado) + pixelesDia / 2, 0, X(estado) + pixelesDia / 2, ClientSize.Height);
        }
    }
    private void DibujarCabecera(Graphics g, DateTime desde, DateTime hasta)
    {
        using var fondo = new SolidBrush(MYG2027_TemaComercial.CabeceraTabla);
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        g.FillRectangle(fondo, 0, 0, ClientSize.Width, altoCabecera);
        DateTime mes = new(desde.Year, desde.Month, 1);
        while (mes <= hasta)
        {
            bool ultimoMes = mes.Year == 9999 && mes.Month == 12;
            DateTime siguiente = ultimoMes ? DateTime.MaxValue.Date : mes.AddMonths(1);
            var r = Rectangle.Round(new RectangleF(X(mes), 0, X(siguiente) - X(mes), altoCabecera / 2));
            TextRenderer.DrawText(g, mes.ToString("MMMM yyyy", CultureInfo.GetCultureInfo("es-PE")), Font, r,
                MYG2027_TemaComercial.Texto, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            g.DrawLine(borde, X(mes), 0, X(mes), altoCabecera);
            if (ultimoMes) break;
            mes = siguiente;
        }
        const TextFormatFlags formatoDia = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
            TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
        int anchoDia = TextRenderer.MeasureText(g, "31", Font, Size.Empty, formatoDia).Width + 4;
        int salto = pixelesDia >= anchoDia ? 1 : pixelesDia >= 3 ? 7 : 30;
        DateTime dia = desde;
        if (salto == 7)
        {
            int retroceso = (7 + (int)dia.DayOfWeek - (int)DayOfWeek.Monday) % 7;
            if (dia >= DateTime.MinValue.AddDays(retroceso)) dia = dia.AddDays(-retroceso);
        }
        for (; dia <= hasta;)
        {
            var r = Rectangle.Round(new RectangleF(X(dia), altoCabecera / 2, pixelesDia * salto, altoCabecera / 2));
            string texto = salto == 1 ? dia.Day.ToString(CultureInfo.InvariantCulture) : dia.ToString("dd/MM", CultureInfo.InvariantCulture);
            // Evitar que los días de dos cifras se conviertan en «1…» o «2…».
            // En escalas estrechas se reduce la densidad, no se trunca la fecha.
            if (r.Width >= TextRenderer.MeasureText(g, texto, Font, Size.Empty, formatoDia).Width + 2)
                TextRenderer.DrawText(g, texto, Font, r, MYG2027_TemaComercial.Secundario, formatoDia);
            g.DrawLine(borde, X(dia), altoCabecera / 2, X(dia), altoCabecera);
            if ((DateTime.MaxValue.Date - dia).TotalDays < salto) break;
            dia = dia.AddDays(salto);
        }
        g.DrawLine(borde, 0, altoCabecera / 2, ClientSize.Width, altoCabecera / 2);
        g.DrawLine(borde, 0, altoCabecera - 1, ClientSize.Width, altoCabecera - 1);
    }
    private void DibujarBarra(Graphics g, MYGResultadoTarea f, RectangleF r)
    {
        var tarea = f.Tarea;
        Color color = EsCritica(f) ? Color.FromArgb(presentacion.ColorCriticaArgb) : tarea.Modo == MYGModoTarea.Manual ? Color.FromArgb(64, 149, 128) : Color.FromArgb(58, 119, 181);
        if (lineaBase && tarea.InicioBase.HasValue && tarea.FinBase.HasValue)
        {
            using var gris = new SolidBrush(Color.FromArgb(145, 145, 145));
            g.FillRectangle(gris, X(tarea.InicioBase.Value), r.Bottom + 2,
                Math.Max(3, ((float)(tarea.FinBase.Value.Date - tarea.InicioBase.Value.Date).TotalDays + 1) * pixelesDia), 3);
        }
        using var brocha = new SolidBrush(tarea.EsResumen ? MYG2027_TemaComercial.Texto : color);
        using var lapiz = new Pen(color, seleccion.Contains(tarea.Id) ? 2 : 1);
        if (tarea.EsResumen)
        {
            g.FillRectangle(brocha, r.X, r.Y + 1, r.Width, 4);
            g.FillPolygon(brocha, new[] { new PointF(r.Left, r.Top + 1), new PointF(r.Left + 5, r.Top + 1), new PointF(r.Left, r.Top + 9) });
            g.FillPolygon(brocha, new[] { new PointF(r.Right, r.Top + 1), new PointF(r.Right - 5, r.Top + 1), new PointF(r.Right, r.Top + 9) });
        }
        else if (tarea.Partes.Count > 0 || MYGMotorCronograma.ConservaFechasDelphin(tarea) && tarea.FechasImportadasDelphin.Tramos.Count > 1)
        {
            using var claro = new SolidBrush(Color.FromArgb(65, color));
            using var union = new Pen(color) { DashStyle = DashStyle.Dash };
            g.DrawLine(union, r.Left, r.Top + r.Height / 2, r.Right, r.Top + r.Height / 2);
            var tramos = tarea.Partes.Count > 0
                ? tarea.Partes.Select(p => (Inicio: calendario.SumarDiasLaborables(f.Inicio, p.DesfaseInicioDias),
                    Fin: calendario.SumarDiasLaborables(f.Inicio, p.DesfaseInicioDias + p.DuracionDias - 1), Trabajo: (decimal)p.DuracionDias))
                : tarea.FechasImportadasDelphin.Tramos.OrderBy(p => p.Inicio).Select(p => (p.Inicio, p.Fin,
                    Trabajo: p.Duracion > 0 ? p.Duracion : Math.Max(1, calendario.ContarDiasLaborables(p.Inicio, p.Fin))));
            var bloques = tramos.ToArray();
            decimal trabajoCompletado = bloques.Sum(p => p.Trabajo) * tarea.Avance / 100m;
            foreach (var tramo in bloques)
            {
                var parte = new RectangleF(X(tramo.Inicio), r.Y, Math.Max(3, (float)((tramo.Fin - tramo.Inicio).TotalDays + 1) * pixelesDia), r.Height);
                decimal avanceParte = tramo.Trabajo <= 0 ? 0 : Math.Clamp(trabajoCompletado / tramo.Trabajo, 0, 1) * 100m;
                DibujarParte(g, parte, lapiz, claro, avanceParte);
                trabajoCompletado -= tramo.Trabajo;
            }
        }
        else if (f.DuracionDias == 0)
        {
            float x = r.X + Math.Min(pixelesDia / 2, 8), y = r.Y + r.Height / 2, lado = Math.Min(7, r.Height / 2 + 1);
            g.FillPolygon(brocha, new[] { new PointF(x, y - lado), new PointF(x + lado, y), new PointF(x, y + lado), new PointF(x - lado, y) });
        }
        else
        {
            using var claro = new SolidBrush(Color.FromArgb(65, color));
            DibujarParte(g, r, lapiz, claro, tarea.Avance);
        }
    }
    private void DibujarParte(Graphics g, RectangleF r, Pen borde, Brush fondo, decimal avance)
    {
        if (presentacion.AparienciaBarra != "Contorno") g.FillRectangle(fondo, r);
        g.DrawRectangle(borde, r.X, r.Y, r.Width, r.Height);
        if (!presentacion.OcultarAvance)
        {
            using var colorAvance = new SolidBrush(Color.FromArgb(presentacion.ColorAvanceArgb));
            g.FillRectangle(colorAvance, r.X, r.Y + 3, r.Width * (float)Math.Clamp(avance / 100m, 0, 1), Math.Max(2, r.Height - 6));
        }
    }
    private void DibujarVinculos(Graphics g, int primero, int ultimo)
    {
        var indices = filas.Select((f, i) => (f.Tarea.Id, Indice: i)).ToDictionary(x => x.Id, x => x.Indice);
        using var flecha = new AdjustableArrowCap(3, 3);
        using var lapiz = new Pen(MYG2027_TemaComercial.Secundario, 1) { CustomEndCap = flecha };
        for (int i = primero; i < ultimo; i++)
            foreach (var vinculo in filas[i].Tarea.Predecesoras)
            {
                if (!indices.TryGetValue(vinculo.PredecesoraId, out int anterior)) continue;
                lapiz.Color = EsCritica(filas[i]) && EsCritica(filas[anterior])
                    ? Color.FromArgb(presentacion.ColorDependenciasCriticasArgb) : MYG2027_TemaComercial.Secundario;
                var a = Rectangulo(filas[anterior], anterior); var b = Rectangulo(filas[i], i);
                float x1 = vinculo.Tipo is MYGTipoVinculo.CC or MYGTipoVinculo.CF ? a.Left : a.Right;
                float x2 = vinculo.Tipo is MYGTipoVinculo.FF or MYGTipoVinculo.CF ? b.Right : b.Left;
                float y1 = a.Top + a.Height / 2, y2 = b.Top + b.Height / 2, codo = x1 + (x2 >= x1 ? 8 : 14);
                g.DrawLines(lapiz, new[] { new PointF(x1, y1), new PointF(codo, y1), new PointF(codo, y2), new PointF(x2, y2) });
            }
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e); Focus();
        if (e.Button != MouseButtons.Left || e.Y < 0) return;
        int i = (e.Y - AutoScrollPosition.Y) / altoFila;
        if (i < 0 || i >= filas.Count) return;
        var f = filas[i]; TareaSeleccionada?.Invoke(f.Tarea.Id);
        if (!f.Tarea.EsResumen && Rectangulo(f, i).Contains(e.Location))
        { arrastre = f.Tarea.Id; puntoArrastre = e.Location; inicioArrastre = f.Inicio; Capture = true; }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (arrastre != null) Cursor = Cursors.SizeWE;
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e); string id = arrastre; arrastre = null; Capture = false; Cursor = Cursors.Default;
        if (id == null || Math.Abs(e.X - puntoArrastre.X) < 5) return;
        int dias = (int)Math.Round((e.X - puntoArrastre.X) / pixelesDia);
        if (dias != 0)
        {
            dias = (int)Math.Clamp(dias, (DateTime.MinValue.Date - inicioArrastre.Date).TotalDays, (DateTime.MaxValue.Date - inicioArrastre.Date).TotalDays);
            InicioCambiado?.Invoke(id, inicioArrastre.AddDays(dias));
        }
    }
    protected override void OnMouseDoubleClick(MouseEventArgs e)
    {
        base.OnMouseDoubleClick(e);
        int i = (e.Y - AutoScrollPosition.Y) / altoFila;
        if (e.Y >= 0 && i >= 0 && i < filas.Count) TareaDobleClick?.Invoke(filas[i].Tarea.Id);
    }

    private sealed class CabeceraFija : Control
    {
        private readonly MYGCronogramaGanttControl gantt;
        internal CabeceraFija(MYGCronogramaGanttControl gantt)
        {
            this.gantt = gantt;
            Name = "cronograma_gantt_cabecera";
            AccessibleName = "Escala de fechas fija del cronograma";
            TabStop = false;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (gantt.IsDisposed) return;
            e.Graphics.Clear(MYG2027_TemaComercial.CabeceraTabla);
            var desde = gantt.FechaEnX(0);
            var hasta = gantt.FechaEnX(gantt.ClientSize.Width);
            if (hasta < DateTime.MaxValue.Date) hasta = hasta.AddDays(1);
            gantt.DibujarCabecera(e.Graphics, desde, hasta);
        }
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            // Mantener navegación y zoom al usar la rueda sobre los días.
            if (!gantt.IsDisposed) gantt.OnMouseWheel(e);
            if (e is HandledMouseEventArgs procesado) procesado.Handled = true;
        }
    }
}
