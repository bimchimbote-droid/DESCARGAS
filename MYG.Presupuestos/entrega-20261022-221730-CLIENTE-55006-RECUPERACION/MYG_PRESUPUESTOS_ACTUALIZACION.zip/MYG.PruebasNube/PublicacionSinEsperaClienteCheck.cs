using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

/// <summary>
/// Regresión focal del cliente ante los dos rechazos 55006 de publicación.
/// Usa pendientes reales en disco y transporte HTTP simulado; no ejecuta la GUI
/// ni sustituye las pruebas previas de bloqueo e integridad en PostgreSQL.
/// </summary>
internal static class PublicacionSinEsperaClienteCheck
{
    private const string Servidor = "https://publicacion-ocupada.supabase.co";
    private const string Clave = "sb_publishable_ocupada_sintetica";
    private const string Secreto = "detalle_privado_remoto_no_mostrar";
    private const string Nombre = "Base Áncash 漢字 \"exacta\"";
    private const decimal Importe = 12.12345678901234567890123456m;
    private const string Referencia = "5e4d0cf1-4349-48ee-8097-00695a19da12";
    private static readonly Guid Usuario = Guid.Parse("d3937e35-7784-4a2a-b247-99b5ca0e0e37");
    private static readonly Guid Proyecto = Guid.Parse("02924b18-a644-47bb-a1f4-161f1eb186c2");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-cliente-ocupado-" + Guid.NewGuid().ToString("N"));
        try
        {
            foreach (string marcador in new[] { "MYG_RECURSO_OCUPADO", "MYG_PUBLICACION_EN_CURSO" })
                await RechazoYRecuperacion(Path.Combine(carpeta, marcador), marcador);
            Console.WriteLine($"OK Cliente de publicación sin espera: 2 casos, {comprobaciones} comprobaciones; "
                + "HTTP 500/55006 simulado, pendiente en disco, recuperación, ACK y bytes exactos; sin red ni GUI.");
        }
        finally { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, recursive: true); }
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Cliente de publicación sin espera: " + detalle);
    }

    private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };

    private static JsonElement Contenido() => JsonSerializer.SerializeToElement(new
    {
        formato = "MYG_COLABORACION", version = 2, alcance = "base",
        documento = new { Id = "DOCUMENTO-OCUPADO", Nombre, Importe },
        documentos = Array.Empty<object>(),
        tablas = new[] { new {
            Nombre = "datos_sinteticos", Columnas = new[] { "texto", "importe", "entero", "nulo" },
            Filas = new object?[][] { new object?[] { new object[] { "s", 0 },
                new object[] { "r", "12.12345678901234567890123456" },
                new object[] { "i", "9007199254740993" }, null } }
        } },
        textos = new[] { "Unicode Áncash 漢字, comillas \" y ruta C:\\obra\\archivo" },
        recursos = Array.Empty<object>(), avisos = Array.Empty<string>()
    });

    private static async Task<(ClienteSupabase Cliente, Transporte Transporte)> Conectar()
    {
        var transporte = new Transporte();
        transporte.Paso("/auth/v1/token?grant_type=password", _ => Task.FromResult(Json(new
        {
            access_token = "acceso_ocupado_sintetico", refresh_token = "refresco_ocupado_sintetico",
            expires_in = 3600, user = new { id = Usuario }
        })));
        var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        await cliente.IniciarSesionAsync("cuenta@example.test", "clave_sintetica");
        return (cliente, transporte);
    }

    private static void Capacidad(Transporte transporte) => transporte.Paso("/rest/v1/rpc/myg_nube_capacidades",
        _ => Task.FromResult(Json(new { paquete_compacto = 2, cambios = 1, max_contenido_mib = 300, publicacion_ligera = 1 })));

    private static void Estado(Transporte transporte, string estado) => transporte.Paso("/rest/v1/rpc/myg_nube_estado_publicacion",
        async solicitud =>
        {
            using var json = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync());
            Exige(json.RootElement.EnumerateObject().Count() == 1
                && json.RootElement.GetProperty("p_id").GetGuid() == Proyecto,
                "la consulta previa transmitió el paquete o cambió el identificador.");
            return Json(new { estado });
        });

    private static object Ack(Guid? id = null) => new
    {
        id = id ?? Proyecto, codigo = "MYG-OCUPADO", nombre = Nombre, rol = "propietario", revision = 3,
        alcance = "base", permisos_modulos = new { acu = true, especificaciones = false, metrados_excel = true }
    };

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error) { comprobaciones++; return error; }
        throw new InvalidOperationException("Se aceptó un rechazo o ACK inválido como éxito.");
    }

    private static async Task RechazoYRecuperacion(string carpeta, string marcador)
    {
        var almacen = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Usuario.ToString("D"));
        JsonElement contenido = Contenido();
        FormatoPaqueteNube.ValidarSinExpandir(contenido);
        var pendiente = new PublicacionPendienteNube(Proyecto, Nombre, "base", contenido);
        almacen.Guardar(pendiente);
        byte[] original = File.ReadAllBytes(almacen.RutaActiva);
        byte[] hashOriginal = SHA256.HashData(original);
        byte[]? cuerpoOriginal = null;

        async Task ComprobarEnvio(HttpRequestMessage solicitud)
        {
            byte[] cuerpo = await solicitud.Content!.ReadAsByteArrayAsync();
            using var json = JsonDocument.Parse(cuerpo);
            JsonElement raiz = json.RootElement;
            Exige(raiz.EnumerateObject().Count() == 4
                && raiz.GetProperty("p_id").GetGuid() == Proyecto
                && raiz.GetProperty("p_nombre").GetString() == Nombre
                && raiz.GetProperty("p_alcance").GetString() == "base"
                && JsonElement.DeepEquals(raiz.GetProperty("p_contenido"), contenido),
                "la publicación cambió identidad, nombre, alcance o contenido completo.");
            Exige(FormatoPaqueteNube.EsCompacto(raiz.GetProperty("p_contenido"))
                && raiz.GetProperty("p_contenido").GetProperty("documento").GetProperty("Importe").GetDecimal() == Importe,
                "el envío expandió el paquete compacto o alteró la precisión decimal.");
            if (cuerpoOriginal is null) cuerpoOriginal = cuerpo;
            else Exige(cuerpo.SequenceEqual(cuerpoOriginal), "el reintento cambió los bytes originales del POST.");
        }

        void PendienteIntacto(ArchivoPublicacionPendienteNube archivo)
        {
            byte[] actual = File.ReadAllBytes(archivo.RutaActiva);
            Exige(actual.SequenceEqual(original) && SHA256.HashData(actual).SequenceEqual(hashOriginal),
                "se alteraron o retiraron los bytes del pendiente sin una confirmación válida.");
            var leido = archivo.Leer(archivo.Consultar()!);
            Exige(leido.Id == Proyecto && leido.Nombre == Nombre && leido.Alcance == "base"
                && JsonElement.DeepEquals(leido.Contenido, contenido),
                "recuperar el pendiente cambió su identidad, precisión, Unicode o representación compacta.");
        }

        var (cliente, transporte) = await Conectar();
        using (cliente)
        {
            Capacidad(transporte);
            Estado(transporte, marcador == "MYG_RECURSO_OCUPADO" ? "existente" : "disponible");
            transporte.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", async solicitud =>
            {
                await ComprobarEnvio(solicitud);
                var respuesta = Json(new { code = "55006", message = marcador, details = Secreto, hint = Secreto },
                    HttpStatusCode.InternalServerError);
                respuesta.Headers.TryAddWithoutValidation("sb-request-id", Referencia);
                return respuesta;
            });
            var error = await Rechaza(() => cliente.CrearProyectoConfirmacionAsync(
                pendiente.Id, pendiente.Nombre, pendiente.Contenido, pendiente.Alcance));
            Exige(error.Codigo == "55006" && error.EsErrorDeConexion && !error.NecesitaIniciarSesion
                && !error.AccesoDenegado && !error.VinculoNoVerificado,
                "el rechazo de fila o publicación ocupada cambió código o clasificación.");
            Exige(error.Message.Contains("HTTP 500", StringComparison.Ordinal)
                && error.Message.Contains("55006", StringComparison.Ordinal)
                && error.Message.Contains(Referencia, StringComparison.Ordinal)
                && error.Message.Contains("RPC prevista myg_nube_crear_confirmacion", StringComparison.Ordinal)
                && error.Message.Contains("misma operación pendiente", StringComparison.Ordinal),
                "el rechazo perdió el diagnóstico seguro o la instrucción de conservar el pendiente.");
            Exige(error.Message.Contains("publicación en curso", StringComparison.Ordinal)
                    == (marcador == "MYG_PUBLICACION_EN_CURSO"),
                "se confundió una fila ocupada con otra creación en curso.");
            Exige(error.Message.Contains(marcador == "MYG_RECURSO_OCUPADO"
                    ? "Un recurso necesario sigue ocupado" : "Ya hay una publicación en curso", StringComparison.Ordinal),
                "el rechazo específico se sustituyó por un mensaje genérico de pasarela.");
            foreach (string privado in new[] { Secreto, Nombre, Servidor, Clave, "acceso_ocupado_sintetico", "refresco_ocupado_sintetico" })
                Exige(!error.Message.Contains(privado, StringComparison.Ordinal), "el rechazo reveló datos privados o credenciales.");
            Exige(cliente.SesionIniciada && cliente.UsuarioId == Usuario.ToString("D") && transporte.Peticiones == 4,
                "el rechazo cerró la sesión, cambió la identidad o reenvió automáticamente la publicación.");
            PendienteIntacto(almacen);
            transporte.Completo();
        }

        // Reabrir desde disco y autenticar otro cliente simula reiniciar el programa.
        // La GUI gestiona el cierre del pendiente; no se ejecuta en este arnés Linux.
        var recuperado = new ArchivoPublicacionPendienteNube(carpeta, Servidor, Usuario.ToString("D"));
        PendienteIntacto(recuperado);
        var resumen = recuperado.Consultar()!;
        var lectura = recuperado.Leer(resumen);
        var (nuevoCliente, nuevoTransporte) = await Conectar();
        using (nuevoCliente)
        {
            Capacidad(nuevoTransporte); Estado(nuevoTransporte, "existente");
            nuevoTransporte.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", async solicitud =>
            {
                await ComprobarEnvio(solicitud);
                return Json(Ack(Guid.Parse("968aa021-67ef-481d-9ec1-6baeb24d9b41")));
            });
            await Rechaza(() => nuevoCliente.CrearProyectoConfirmacionAsync(lectura.Id, lectura.Nombre, lectura.Contenido, lectura.Alcance));
            PendienteIntacto(recuperado);
            Exige(nuevoCliente.SesionIniciada && nuevoCliente.UsuarioId == Usuario.ToString("D") && nuevoTransporte.Peticiones == 4,
                "un ACK inválido cerró la sesión o se trató como publicación confirmada.");

            Estado(nuevoTransporte, "existente");
            nuevoTransporte.Paso("/rest/v1/rpc/myg_nube_crear_confirmacion", async solicitud =>
            {
                await ComprobarEnvio(solicitud);
                return Json(Ack());
            });
            var confirmado = await nuevoCliente.CrearProyectoConfirmacionAsync(lectura.Id, lectura.Nombre, lectura.Contenido, lectura.Alcance);
            Exige(confirmado.Id == Proyecto && confirmado.Revision == 3 && confirmado.Nombre == Nombre
                && confirmado.Rol == "propietario" && confirmado.Alcance == "base"
                && confirmado.Contenido.ValueKind == JsonValueKind.Undefined
                && confirmado.PermisosModulos?.Acu == true && confirmado.PermisosModulos.Especificaciones == false,
                "el ACK válido perdió identidad, revisión vigente, permisos o inventó contenido.");
            PendienteIntacto(recuperado);
            Exige(nuevoCliente.SesionIniciada && nuevoCliente.UsuarioId == Usuario.ToString("D") && nuevoTransporte.Peticiones == 6,
                "la recuperación cambió la sesión o abrió, listó o reenvió operaciones adicionales.");
            nuevoTransporte.Completo();

            // Igual que el llamador de Desktop: retirar únicamente después del ACK validado.
            recuperado.Confirmar(resumen);
            Exige(recuperado.Consultar() is null && !File.Exists(recuperado.RutaActiva),
                "no se cerró el pendiente después de recibir su confirmación válida.");
        }
    }

    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<(string Ruta, Func<HttpRequestMessage, Task<HttpResponseMessage>> Ejecutar)> pasos = new();
        internal int Peticiones { get; private set; }
        internal void Paso(string ruta, Func<HttpRequestMessage, Task<HttpResponseMessage>> ejecutar) => pasos.Enqueue((ruta, ejecutar));
        internal void Completo() => Exige(pasos.Count == 0, "faltaron solicitudes previstas.");
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Peticiones++;
            Exige(pasos.Count > 0, "se envió una solicitud no prevista o un reintento automático.");
            var paso = pasos.Dequeue();
            Exige(request.Method == HttpMethod.Post && request.RequestUri?.Host == "publicacion-ocupada.supabase.co"
                && request.RequestUri.PathAndQuery == paso.Ruta, "se envió una operación distinta de la publicación prevista.");
            return paso.Ejecutar(request);
        }
    }
}
