using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

// Este adaptador sólo consulta las tablas nativas. La conservación del precio
// importado permite ver un ACU sin alterar sus redondeos al abrir el documento.
internal static partial class DelphinImportacionMYG
{
    internal static bool EsBase(SqliteConnection c, SqliteTransaction t = null)
    {
        var proyecto = Columnas(c, "proyecto", t);
        var presupuesto = Columnas(c, "presupuesto", t);
        return proyecto.Contains("id_proyecto") && proyecto.Contains("nombre_proyecto") &&
            presupuesto.Contains("id_presupuesto") && presupuesto.Contains("id_proyecto") &&
            Columnas(c, "costo_unitario", t).Contains("id_costounitario") && Columnas(c, "unidad", t).Contains("id_unidad");
    }

    internal static List<MYGProyectoResumen> ListarProyectos(SqliteConnection c, SqliteTransaction t = null)
    {
        var lectura = new Lectura(c, t);
        var presupuestos = lectura.Filas("presupuesto", new[] { "id_presupuesto", "id_proyecto" });
        var propietarios = lectura.Filas("propietario", new[] { "id_propietario", "nombre_propietario" })
            .ToDictionary(x => x.Texto("id_propietario"), x => x.Texto("nombre_propietario"), StringComparer.OrdinalIgnoreCase);
        var tipos = lectura.Filas("infraestructura", new[] { "id_infraestructura", "nombre_infraestructura" })
            .ToDictionary(x => x.Texto("id_infraestructura"), x => x.Texto("nombre_infraestructura"), StringComparer.OrdinalIgnoreCase);
        return lectura.Filas("proyecto", new[] { "id_proyecto", "nombre_proyecto", "fecha_proyecto", "id_propietario", "id_infraestructura" })
            .Where(x => !string.IsNullOrWhiteSpace(x.Texto("id_proyecto")))
            .Select(x => new MYGProyectoResumen
            {
                Id = x.Texto("id_proyecto"),
                Nombre = Nombre(x.Texto("nombre_proyecto"), "Proyecto sin nombre"),
                ModificadoUtc = Fecha(x.Texto("fecha_proyecto")),
                CantidadPresupuestos = presupuestos.Count(p => Igual(p.Texto("id_proyecto"), x.Texto("id_proyecto"))),
                Propietario = propietarios.GetValueOrDefault(x.Texto("id_propietario"), ""),
                TipoObra = tipos.GetValueOrDefault(x.Texto("id_infraestructura"), "")
            }).OrderBy(x => x.Nombre, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    internal static MYGProyectoDocumento LeerProyecto(SqliteConnection c, string id, SqliteTransaction t = null,
        Action<string> informar = null)
    {
        informar?.Invoke("Leyendo la ficha del proyecto Delphin…");
        var lectura = new Lectura(c, t);
        var proyectos = lectura.Filas("proyecto", new[] { "id_proyecto", "nombre_proyecto", "fecha_proyecto",
            "selected_presupuesto", "decimales_costo", "decimales_cantidad", "id_propietario", "id_portafolio", "id_infraestructura",
            "id_ubicacion", "id_departamento", "id_provincia", "id_distrito", "id_localidad", "fecha_inicio", "fecha_fin",
            "duracion", "duracion_new", "id_unidadtiempo", "id_calendario", "modalidad_ejecucion", "acu_mode", "fin_periodo" },
            id == null ? null : "id_proyecto", id);
        if (proyectos.Count == 0) throw new InvalidDataException("El proyecto seleccionado no existe en esta hoja.");
        if (proyectos.Count != 1) throw new InvalidDataException("Esta hoja contiene varios proyectos. Seleccione uno desde la ventana principal.");
        var origen = proyectos[0];
        var d = new MYGProyectoDocumento
        {
            Id = origen.Texto("id_proyecto"),
            Nombre = Nombre(origen.Texto("nombre_proyecto"), "Proyecto sin nombre"),
            ModificadoUtc = Fecha(origen.Texto("fecha_proyecto")),
            IdProyectoRevit = origen.Texto("id_proyecto"),
            PresupuestoActivoId = origen.Texto("selected_presupuesto")
        };
        d.Datos = LeerDatosProyecto(lectura, origen);
        var presupuestos = lectura.Filas("presupuesto", new[] { "id_presupuesto", "id_proyecto", "nombre_presupuesto",
            "numeracion_presupuesto", "posicion_presupuesto", "porcentaje_gasto", "porcentaje_utilidad", "porcentaje_igv", "porcentaje_impuestootro" },
            "id_proyecto", d.Id).OrderBy(x => x.Entero("posicion_presupuesto")).ThenBy(x => x.Texto("numeracion_presupuesto")).ToList();
        int numero = 0;
        foreach (var fila in presupuestos)
        {
            informar?.Invoke("Leyendo partidas y costos del presupuesto " + (++numero) + " de " + presupuestos.Count + "…");
            var p = new MYGPresupuestoDocumento
            {
                Id = fila.Texto("id_presupuesto"),
                IdPresupuestoRevit = fila.Texto("id_presupuesto"),
                Nombre = Nombre(fila.Texto("nombre_presupuesto"), "Presupuesto sin nombre"),
                Item = fila.Texto("numeracion_presupuesto"),
                Posicion = fila.Entero("posicion_presupuesto"),
                CantidadFiltros = 1,
                Costos = new MYGCostosPresupuesto
                {
                    DecimalesPrecio = Precision(origen, "decimales_costo", 2, 6),
                    DecimalesCantidad = Precision(origen, "decimales_cantidad", 4, 8),
                    GastosGeneralesPorcentaje = fila.Numero("porcentaje_gasto"),
                    UtilidadPorcentaje = fila.Numero("porcentaje_utilidad"),
                    ImpuestoPorcentaje = fila.Numero("porcentaje_igv"),
                    OtrosImpuestosPorcentaje = fila.Numero("porcentaje_impuestootro")
                }
            };
            LeerItems(lectura, p);
            LeerPieDelphin(lectura, d.Id, p);
            LeerFormulaPolinomica(lectura, p);
            foreach (var i in p.Items) MYGMotorPresupuestos.CapturarDatosDelphin(p, i);
            MYGMotorPresupuestos.CapturarPresupuestoDelphin(p);
            d.Presupuestos.Add(p);
        }
        if (!d.Presupuestos.Any(p => Igual(p.Id, d.PresupuestoActivoId)))
            d.PresupuestoActivoId = d.Presupuestos.FirstOrDefault()?.Id;
        informar?.Invoke("Leyendo calendarios y programación Delphin…");
        d.Cronograma = DelphinCronogramaMYG.Leer(c, d, t);
        AdvertirDatosHeredados(d, origen, informar);
        informar?.Invoke("Validando presupuestos, partidas y referencias…");
        MYGProyectoStorage.Validar(d);
        return d;
    }

    private static void AdvertirDatosHeredados(MYGProyectoDocumento documento, Fila origen, Action<string> informar)
    {
        void Advertir(string texto)
        {
            informar?.Invoke(texto);
            // No inventar un cronograma cuando la hoja no contiene programación.
            // Cuando existe, el panel de cronograma presenta la advertencia.
            documento.Cronograma?.AdvertenciasImportacion.Add(texto);
        }
        if (documento.Datos.FechaInicio.HasValue && documento.Datos.FechaFin.HasValue &&
            documento.Datos.FechaFin < documento.Datos.FechaInicio)
            Advertir("La ficha Delphin contiene una fecha final anterior al inicio. Se conservan ambas fechas originales; " +
                "para editar la ficha del proyecto debe corregirlas expresamente.");
        if (origen.Numero("duracion_new") <= 0 && origen.Numero("duracion") <= 0)
            Advertir("La duración nativa Delphin no es positiva. MYG muestra 1 como valor de presentación; " +
                "la duración original se conserva en el archivo mientras no se cambie expresamente.");
    }

    private static MYGDatosProyecto LeerDatosProyecto(Lectura lectura, Fila fila)
    {
        string NombreReferencia(string tabla, string columnaId, string columnaNombre, string id) =>
            string.IsNullOrWhiteSpace(id) ? "" : lectura.Filas(tabla, new[] { columnaNombre }, columnaId, id).FirstOrDefault()?.Texto(columnaNombre) ?? "";
        string Id(string nombre) => string.IsNullOrWhiteSpace(fila.Texto(nombre)) ? null : fila.Texto(nombre);
        string unidad = lectura.Unidad(fila.Texto("id_unidadtiempo"), "MESES");
        string unidadDuracion;
        try { unidadDuracion = MYGDatosProyecto.UnidadCanonica(unidad); }
        catch (InvalidDataException) { unidadDuracion = "MESES"; }
        int? calendarioId = fila.Valor("id_calendario") == null || fila.Entero("id_calendario") <= 0
            ? null : fila.Entero("id_calendario");
        var datos = new MYGDatosProyecto
        {
            PropietarioId = Id("id_propietario"),
            PortafolioId = Id("id_portafolio"),
            TipoObraId = Id("id_infraestructura"),
            DepartamentoId = Id("id_departamento"),
            ProvinciaId = Id("id_provincia"),
            DistritoId = Id("id_distrito"),
            LocalidadId = Id("id_localidad"),
            UsarUbicacion = Igual(fila.Texto("id_ubicacion"), "Si") || Igual(fila.Texto("id_ubicacion"), "S"),
            FechaElaboracion = FechaNullable(fila.Texto("fecha_proyecto")),
            FechaInicio = FechaNullable(fila.Texto("fecha_inicio")),
            FechaFin = FechaNullable(fila.Texto("fecha_fin")),
            Duracion = Positivo(fila.Numero("duracion_new"), Positivo(fila.Numero("duracion"), 1)),
            UnidadDuracion = unidadDuracion,
            CalendarioId = calendarioId,
            ModalidadEjecucion = Nombre(fila.Texto("modalidad_ejecucion"), "C"),
            PorAsignacionRecursos = Igual(fila.Texto("acu_mode"), "S"),
            PorRendimientoCuadrilla = !Igual(fila.Texto("acu_mode"), "S"),
            Periodos = fila.Valor("fin_periodo") == null || fila.Entero("fin_periodo") == -1
                ? "Estándar" : "Fin de período: " + fila.Entero("fin_periodo").ToString(CultureInfo.InvariantCulture)
        };
        datos.Propietario = NombreReferencia("propietario", "id_propietario", "nombre_propietario", datos.PropietarioId);
        datos.Portafolio = NombreReferencia("portafolio", "id_portafolio", "nombre_portafolio", datos.PortafolioId);
        datos.TipoObra = NombreReferencia("infraestructura", "id_infraestructura", "nombre_infraestructura", datos.TipoObraId);
        datos.Departamento = NombreReferencia("departamento", "id_departamento", "nombre_departamento", datos.DepartamentoId);
        datos.Provincia = NombreReferencia("provincia", "id_provincia", "nombre_provincia", datos.ProvinciaId);
        datos.Distrito = NombreReferencia("distrito", "id_distrito", "nombre_distrito", datos.DistritoId);
        datos.Localidad = NombreReferencia("localidad", "id_localidad", "nombre_localidad", datos.LocalidadId);
        datos.Calendario = calendarioId.HasValue ? Nombre(NombreReferencia("calendario", "id_calendario", "nombre_calendario",
            calendarioId.Value.ToString(CultureInfo.InvariantCulture)), "Predeterminado") : "Predeterminado";
        // La firma captura sólo los datos del formulario. No consulta usuarios ni
        // copia claves de acceso, y permite conservar las columnas nativas intactas.
        datos.FirmaImportada = datos.Firma();
        return datos;
    }

    private static DateTime? FechaNullable(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto)) return null;
        if (DateTime.TryParseExact(texto, new[] { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "O" },
            CultureInfo.InvariantCulture, DateTimeStyles.None, out var fecha)) return fecha.Date;
        return DateTime.TryParse(texto, CultureInfo.GetCultureInfo("es-PE"), DateTimeStyles.None, out fecha) ? fecha.Date : null;
    }

    internal static List<MYGUnidadCatalogo> ListarUnidades(SqliteConnection c, SqliteTransaction t = null) => new Lectura(c, t).Unidades.Values
        .OrderBy(x => x.Simbolo, StringComparer.CurrentCultureIgnoreCase).ToList();

    internal static List<MYGInsumo> ListarInsumos(SqliteConnection c, SqliteTransaction t = null)
    {
        var lectura = new Lectura(c, t);
        return lectura.Productos.Values.Where(x => !string.IsNullOrWhiteSpace(x.Descripcion))
            .OrderBy(x => x.Codigo, StringComparer.OrdinalIgnoreCase).ToList();
    }

    internal static List<MYGPartidaCatalogo> ListarPartidas(SqliteConnection c, SqliteTransaction t = null)
    {
        return ListarEntradas(c, true, t).Select(x => new MYGPartidaCatalogo
        {
            Id = x.Id,
            Codigo = x.Codigo,
            Descripcion = x.Descripcion,
            Unidad = x.Unidad,
            RutaSQLite = c.DataSource
        }).ToList();
    }

    internal static MYGPlantillaPartidaCosto LeerPlantillaPartida(SqliteConnection c, string id, SqliteTransaction t = null)
    {
        var lectura = new Lectura(c, t);
        var filas = lectura.Filas("analisis_costo", CamposCostoCatalogo, "id_analisiscosto", id);
        if (filas.Count != 1) throw new InvalidDataException("La partida del catálogo Delphin no existe.");
        var fila = filas[0];
        var p = new MYGPresupuestoDocumento { Nombre = "Catálogo Delphin" };
        var i = Item(lectura, fila, id, null, true); p.Items.Add(i);
        LeerRecursos(lectura, p, "subtotal_analisiscosto", "composicion_analisiscosto", "id_analisiscosto", id);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, i, fila.Numero("costo_unitario"), 0);
        return new MYGPlantillaPartidaCosto { RaizLocalId = i.IdLocalMYG, Partidas = p.Items, Insumos = p.Costos.Insumos };
    }

    internal static MYGInsumo LeerInsumo(SqliteConnection c, string id, SqliteTransaction t = null)
    {
        var lectura = new Lectura(c, t);
        if (!lectura.Productos.TryGetValue(id, out var insumo)) throw new InvalidDataException("El insumo del catálogo Delphin no existe.");
        return insumo;
    }

    internal static List<MYGEntradaCatalogo> ListarEntradas(SqliteConnection c, bool partidas, SqliteTransaction t = null)
    {
        var lectura = new Lectura(c, t);
        if (!partidas) return lectura.Productos.Values.Where(x => !string.IsNullOrWhiteSpace(x.Descripcion)).Select(x => new MYGEntradaCatalogo
        {
            Id = x.Id,
            Codigo = Nombre(x.Codigo, x.Id),
            Descripcion = x.Descripcion,
            Unidad = x.Unidad,
            Grupo = x.Grupo.ToString(),
            Precio = x.Precio,
            Revision = 1
        }).OrderBy(x => x.Codigo, StringComparer.OrdinalIgnoreCase).ToList();
        var entradas = lectura.Filas("analisis_costo", new[] { "id_analisiscosto", "descripcion_costo", "id_unidad",
            "codigo_clase", "codigo_subclase", "codigo_listaprecio", "costo_unitario" })
            .Where(x => !string.IsNullOrWhiteSpace(x.Texto("id_analisiscosto"))).Select(x => new MYGEntradaCatalogo
            {
                Id = x.Texto("id_analisiscosto"),
                Codigo = Nombre(Codigo(x, "codigo_listaprecio"), x.Texto("id_analisiscosto")),
                Descripcion = Nombre(x.Texto("descripcion_costo"), "Partida sin nombre"),
                Unidad = lectura.Unidad(x.Texto("id_unidad")),
                Grupo = "",
                Precio = x.Numero("costo_unitario"),
                Revision = 1
            }).OrderBy(x => x.Codigo, StringComparer.OrdinalIgnoreCase).ToList();
        CodigosUnicos(entradas, x => x.Id, x => x.Codigo, (x, codigo) => x.Codigo = codigo);
        return entradas;
    }

    // Sólo materializa los catálogos complementarios de MYG durante una escritura
    // solicitada por el usuario. Nunca actualiza tablas nativas ni otras entradas.
    internal static void PrepararCatalogosMYG(SqliteConnection destino, SqliteTransaction t, SqliteConnection fuente = null)
    {
        fuente ??= destino;
        var transaccionLectura = ReferenceEquals(destino, fuente) ? t : null;
        string fecha = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture);
        foreach (var u in ListarUnidades(fuente, transaccionLectura).Where(x => !string.IsNullOrWhiteSpace(x.Simbolo)))
            MYGBaseDatos.Ejecutar(destino, t, "INSERT OR IGNORE INTO catalogo_unidad(id,simbolo,descripcion) VALUES($p0,$p1,$p2)",
                u.Id, u.Simbolo, Nombre(u.Descripcion, u.Simbolo));
        var lectura = new Lectura(fuente, transaccionLectura);
        foreach (var i in lectura.Productos.Values.Where(x => !string.IsNullOrWhiteSpace(x.Descripcion)))
            MYGBaseDatos.Ejecutar(destino, t, "INSERT OR IGNORE INTO catalogo_insumo(id,codigo,descripcion,unidad,grupo,precio,json_datos,revision,modificado_utc) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,1,$p7)",
                i.Id, Nombre(i.Codigo, i.Id), i.Descripcion, i.Unidad, i.Grupo.ToString(), i.Precio, MYGBaseDatos.Json(i), fecha);
        foreach (var e in ListarEntradas(fuente, true, transaccionLectura))
        {
            using (var existe = MYGBaseDatos.Comando(destino, t, "SELECT id FROM catalogo_partida WHERE id=$p0 OR codigo=$p1", e.Id, e.Codigo))
                if (existe.ExecuteScalar() != null) continue;
            var plantilla = LeerPlantillaPartida(fuente, e.Id, transaccionLectura);
            var p = new MYGPresupuestoDocumento { Nombre = e.Descripcion, Items = plantilla.Partidas, Costos = new MYGCostosPresupuesto { Insumos = plantilla.Insumos } };
            MYGProyectoStorage.ValidarPresupuesto(p);
            MYGBaseDatos.Ejecutar(destino, t, "INSERT INTO catalogo_partida(id,codigo,descripcion,unidad,precio,json_plantilla,revision,modificado_utc) VALUES($p0,$p1,$p2,$p3,$p4,$p5,1,$p6)",
                e.Id, e.Codigo, e.Descripcion, e.Unidad, e.Precio, MYGBaseDatos.Json(plantilla), fecha);
            foreach (var i in plantilla.Partidas)
            {
                MYGBaseDatos.Ejecutar(destino, t, "INSERT INTO catalogo_partida_nodo(catalogo_id,id_local,descripcion,unidad,es_raiz,rendimiento,jornada,precio_directo,json_datos) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8)",
                    e.Id, i.IdLocalMYG, i.Descripcion, i.Unidad, i.IdLocalMYG == plantilla.RaizLocalId ? 1 : 0,
                    i.Costos.RendimientoDiario, i.Costos.JornadaHoras, i.Costos.PrecioDirecto, MYGBaseDatos.Json(i.Costos));
                foreach (var r in i.Costos.Analisis)
                    MYGBaseDatos.Ejecutar(destino, t, "INSERT INTO catalogo_partida_recurso(catalogo_id,nodo_local,id,grupo,insumo_id,subpartida_local,modo,numero_recursos,cantidad,desperdicio) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9)",
                        e.Id, i.IdLocalMYG, r.Id, r.Grupo.ToString(), r.InsumoId, r.SubpartidaIdLocal,
                        r.Modo.ToString(), r.NumeroRecursos, r.Cantidad, r.DesperdicioPorcentaje);
            }
            foreach (var i in plantilla.Insumos)
                MYGBaseDatos.Ejecutar(destino, t, "INSERT INTO catalogo_partida_insumo(catalogo_id,id,codigo,descripcion,unidad,grupo,precio) VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6)",
                    e.Id, i.Id, i.Codigo, i.Descripcion, i.Unidad, i.Grupo.ToString(), i.Precio);
        }
    }

    private static readonly string[] CamposCosto =
    {
        "id_costounitario", "descripcion_costo", "id_costopadre", "id_titulo", "id_presupuesto", "id_unidad",
        "costo_unitario", "cantidad", "cantidad_metrado", "parcial_costo", "productividad", "magnitud_unidadtiempo",
        "tiempo_productividad", "id_analisiscosto", "numeracion_costo", "posicion_costo", "especificaciones",
        "archivo_especificaciones", "especificaciones_texto"
    };
    private static readonly string[] CamposCostoCatalogo =
    {
        "id_analisiscosto", "descripcion_costo", "id_unidad", "costo_unitario", "productividad", "magnitud_unidadtiempo",
        "tiempo_productividad", "especificaciones", "archivo_especificaciones", "especificaciones_texto"
    };
    private static readonly string[] CamposRecurso =
    {
        "id_composicion", "descripcion_composicion", "id_subtotal", "personal_base", "id_unidad",
        "magnitud_unidadcomposicion", "cantidad_composicion", "costo_composicion", "parcial_composicion",
        "id_costoauxiliar", "id_listaprecio", "codigo_clase", "codigo_subclase", "codigo_listaprecio",
        "es_composiciondependiente", "es_subcomposicion", "posicion_composicion", "porcentaje_desperdicio", "nombre_subcontratista"
    };

    private static void LeerItems(Lectura lectura, MYGPresupuestoDocumento p)
    {
        var filas = lectura.Filas("costo_unitario", CamposCosto, "id_presupuesto", p.Id);
        var ids = filas.Select(x => x.Texto("id_costounitario")).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var titulos = lectura.Filas("titulo", new[] { "id_titulo", "descripcion_titulo", "id_titulopadre",
            "numeracion_titulo", "posicion_titulo" }, "id_presupuesto", p.Id);
        // Las hojas heredadas pueden conservar id_costopadre obsoleto y un
        // id_titulo válido. Resolver sólo contra este presupuesto evita perder
        // ese vínculo explícito o incorporar títulos de otra obra.
        var padresDisponibles = new HashSet<string>(ids, StringComparer.OrdinalIgnoreCase);
        padresDisponibles.UnionWith(titulos.Select(x => x.Texto("id_titulo")));
        var necesarios = filas.Select(x => Padre(x, padresDisponibles)).Where(x => x != null && !ids.Contains(x)).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (filas.Count == 0) necesarios.UnionWith(titulos.Select(x => x.Texto("id_titulo")));
        bool cambio;
        do
        {
            cambio = false;
            foreach (var t in titulos.Where(x => necesarios.Contains(x.Texto("id_titulo"))))
            {
                string padre = Raiz(t.Texto("id_titulopadre"));
                if (padre != null && !ids.Contains(padre) && necesarios.Add(padre)) cambio = true;
            }
        } while (cambio);
        foreach (var t in titulos.Where(x => necesarios.Contains(x.Texto("id_titulo")) && !ids.Contains(x.Texto("id_titulo"))))
            p.Items.Add(new ItemPresupuestoDelphin
            {
                Id = t.Texto("id_titulo"),
                IdLocalMYG = "DELPHIN-LOCAL-" + t.Texto("id_titulo"),
                IdInternoDelphin = t.Texto("id_titulo"),
                ParentId = Raiz(t.Texto("id_titulopadre")),
                Descripcion = Nombre(t.Texto("descripcion_titulo"), "Título sin nombre"),
                Item = t.Texto("numeracion_titulo"),
                Posicion = t.Entero("posicion_titulo"),
                TipoPropuesta = "TITULO",
                Origen = "DELPHIN",
                Estado = "OFICIAL",
                Unidad = ""
            });
        foreach (var fila in filas)
            p.Items.Add(Item(lectura, fila, fila.Texto("id_costounitario"), Padre(fila, padresDisponibles), false));
        var padres = p.Items.Select(i => i.ParentId).Where(x => x != null).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var i in p.Items)
            if (padres.Contains(i.Id) || (string.IsNullOrWhiteSpace(i.Unidad) && i.Costos.PrecioDirecto == 0)) i.TipoPropuesta = "TITULO";
        p.Items = p.Items.OrderBy(x => x.Posicion).ThenBy(x => x.Item, StringComparer.OrdinalIgnoreCase).ToList();
        LeerRecursos(lectura, p, "subtotal_costounitario", "composicion_costounitario", "id_costounitario", null);
        var mapa = p.Items.ToDictionary(x => x.Id, StringComparer.OrdinalIgnoreCase);
        foreach (var fila in filas)
            if (mapa.TryGetValue(fila.Texto("id_costounitario"), out var i) && !MYGProyectoStorage.EsTitulo(i))
                MYGMotorPresupuestos.CapturarPrecioDelphin(p, i, fila.Numero("costo_unitario"), fila.Numero("parcial_costo"));
    }

    private static ItemPresupuestoDelphin Item(Lectura lectura, Fila fila, string id, string padre, bool catalogo)
    {
        var i = new ItemPresupuestoDelphin
        {
            Id = id,
            IdLocalMYG = "DELPHIN-LOCAL-" + id,
            IdInternoDelphin = catalogo ? null : id,
            IdAnalisisDelphin = catalogo ? id : fila.Texto("id_analisiscosto"),
            ParentId = padre,
            Item = fila.Texto("numeracion_costo"),
            Descripcion = Nombre(fila.Texto("descripcion_costo"), "Partida sin nombre"),
            Unidad = lectura.Unidad(fila.Texto("id_unidad"), ""),
            Posicion = fila.Entero("posicion_costo"),
            TipoPropuesta = "PARTIDA",
            Origen = "DELPHIN",
            Estado = "OFICIAL",
            Filtros = new List<FiltroPlanificacion> { new() },
            Costos = new MYGDatosPartida
            {
                Cantidad = catalogo ? 0 : fila.Numero("cantidad"),
                PrecioDirecto = fila.Numero("costo_unitario"),
                RendimientoDiario = Positivo(fila.Numero("productividad"), 1),
                JornadaHoras = Positivo(fila.Numero("magnitud_unidadtiempo"), 8)
            }
        };
        string especificacion = fila.Texto("especificaciones");
        string archivo = TextoArchivo(fila.Valor("archivo_especificaciones"));
        if (especificacion.TrimStart().StartsWith(@"{\rtf", StringComparison.OrdinalIgnoreCase)) i.Costos.EspecificacionRtf = especificacion;
        else i.Costos.EspecificacionTexto = especificacion;
        if (archivo.TrimStart().StartsWith(@"{\rtf", StringComparison.OrdinalIgnoreCase)) i.Costos.EspecificacionRtf = archivo;
        return i;
    }

    private static void LeerRecursos(Lectura lectura, MYGPresupuestoDocumento p, string tablaSubtotal,
        string tablaComposicion, string columnaDueno, string dueno)
    {
        var items = p.Items.ToDictionary(x => x.Id, StringComparer.OrdinalIgnoreCase);
        var subtotales = lectura.Filas(tablaSubtotal, new[] { "id_subtotal", columnaDueno, "id_tipocosto",
            "id_composicionpadre", "factor_cantidad" }, dueno == null ? null : columnaDueno, dueno)
            .Where(x => items.ContainsKey(x.Texto(columnaDueno))).ToDictionary(x => x.Texto("id_subtotal"), StringComparer.OrdinalIgnoreCase);
        if (subtotales.Count == 0) return;
        var recursos = lectura.Filas(tablaComposicion, CamposRecurso)
            .Where(x => subtotales.ContainsKey(x.Texto("id_subtotal"))).OrderBy(x => x.Entero("posicion_composicion")).ToList();
        var hijos = recursos.GroupBy(x => Raiz(subtotales[x.Texto("id_subtotal")].Texto("id_composicionpadre")) ?? "",
            StringComparer.OrdinalIgnoreCase).ToDictionary(x => x.Key, x => x.ToList(), StringComparer.OrdinalIgnoreCase);
        var insumos = new Dictionary<string, MYGInsumo>(StringComparer.OrdinalIgnoreCase);
        foreach (var fila in recursos.Where(x => Raiz(subtotales[x.Texto("id_subtotal")].Texto("id_composicionpadre")) == null))
        {
            var subtotal = subtotales[fila.Texto("id_subtotal")];
            var item = items[subtotal.Texto(columnaDueno)];
            if (!MYGProyectoStorage.EsTitulo(item)) Agregar(fila, item, 1, "", new HashSet<string>(StringComparer.OrdinalIgnoreCase));
        }
        p.Costos.Insumos = insumos.Values.ToList();

        void Agregar(Fila fila, ItemPresupuestoDelphin item, decimal factor, string prefijo, HashSet<string> camino)
        {
            string id = fila.Texto("id_composicion");
            if (camino.Count > 64 || !camino.Add(id)) throw new InvalidDataException("El análisis de Delphin contiene una composición circular.");
            try
            {
                var subtotal = subtotales[fila.Texto("id_subtotal")];
                var grupo = lectura.Grupo(subtotal.Texto("id_tipocosto"));
                decimal cantidad = fila.Numero("cantidad_composicion");
                if (grupo == MYGGrupoRecurso.Subpartidas && hijos.TryGetValue(id, out var nested) && nested.Count > 0)
                {
                    foreach (var hijo in nested)
                    {
                        var subtotalHijo = subtotales[hijo.Texto("id_subtotal")];
                        // Delphin conserva aquí el factor acumulado sin el
                        // redondeo de cantidad_composicion de la subpartida.
                        decimal factorHijo = subtotalHijo.Valor("factor_cantidad") == null
                            ? factor * cantidad : subtotalHijo.Numero("factor_cantidad");
                        Agregar(hijo, item, factorHijo, prefijo + id + "-", camino);
                    }
                    return;
                }
                string auxiliar = fila.Texto("id_costoauxiliar");
                if (grupo == MYGGrupoRecurso.Subpartidas && items.TryGetValue(auxiliar, out var sub) && !MYGProyectoStorage.EsTitulo(sub))
                {
                    item.Costos.Analisis.Add(new MYGRecursoACU
                    {
                        Id = prefijo + id,
                        Grupo = grupo,
                        SubpartidaIdLocal = sub.IdLocalMYG,
                        Cantidad = factor * cantidad,
                        NumeroRecursos = fila.Numero("personal_base"),
                        Modo = MYGModoCantidad.Directa
                    });
                    return;
                }
                // Una subpartida externa sin desglose conserva su precio como recurso contratado.
                if (grupo == MYGGrupoRecurso.Subpartidas) grupo = MYGGrupoRecurso.Subcontratos;
                bool porcentaje = grupo == MYGGrupoRecurso.Equipo && fila.Texto("es_composiciondependiente").Equals("S", StringComparison.OrdinalIgnoreCase);
                // En un subanálisis expandido, %mo usa la mano de obra de ese
                // subanálisis, cuyo precio base viene en costo_composicion.
                // Conservarlo como coeficiente directo evita aplicar por error
                // el porcentaje a toda la mano de obra de la partida principal.
                bool porcentajeLocal = porcentaje && !string.IsNullOrEmpty(prefijo);
                if (porcentajeLocal) cantidad *= Positivo(fila.Numero("magnitud_unidadcomposicion"), 0.01m);
                string unidad = lectura.Unidad(fila.Texto("id_unidad"));
                decimal precio = fila.Numero("costo_composicion");
                string productoId = fila.Texto("id_listaprecio");
                lectura.Productos.TryGetValue(productoId, out var producto);
                string descripcion = Nombre(fila.Texto("descripcion_composicion"), producto?.Descripcion ?? "Recurso Delphin");
                string proveedor = Nombre(fila.Texto("nombre_subcontratista"), producto?.Proveedor ?? "SIN CLASIFICAR");
                string codigo = producto?.Codigo;
                if (string.IsNullOrWhiteSpace(codigo)) codigo = Codigo(fila, "codigo_listaprecio");
                if (string.IsNullOrWhiteSpace(codigo)) codigo = string.IsNullOrWhiteSpace(productoId) ? id : productoId;
                string baseId = string.IsNullOrWhiteSpace(productoId) ? "DELPHIN-RECURSO-" + id : productoId;
                // Un producto puede tener precios históricos distintos entre partidas.
                string variante = grupo + "|" + unidad + "|" + precio.ToString(CultureInfo.InvariantCulture) + "|" + descripcion + "|" + proveedor;
                string insumoId = baseId;
                if (insumos.TryGetValue(insumoId, out var existente) &&
                    (existente.Precio != precio || existente.Grupo != grupo || existente.Unidad != unidad || existente.Descripcion != descripcion || existente.Proveedor != proveedor))
                    insumoId += "-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(variante)))[..12];
                if (!insumos.ContainsKey(insumoId)) insumos.Add(insumoId, new MYGInsumo
                { Id = insumoId, Codigo = codigo, Descripcion = descripcion, Unidad = unidad, Grupo = grupo, Precio = precio,
                    Proveedor = proveedor, GrupoGenerico = Nombre(producto?.GrupoGenerico, lectura.GrupoGenerico(fila.Texto("codigo_clase"))) });
                item.Costos.Analisis.Add(new MYGRecursoACU
                {
                    Id = prefijo + id,
                    Grupo = grupo,
                    InsumoId = insumoId,
                    Cantidad = factor * cantidad,
                    ParcialImportadoDelphin = fila.Valor("parcial_composicion") == null ? null : factor * fila.Numero("parcial_composicion"),
                    NumeroRecursos = fila.Numero("personal_base"),
                    DesperdicioPorcentaje = fila.Numero("porcentaje_desperdicio"),
                    Modo = porcentaje && !porcentajeLocal ? MYGModoCantidad.PorcentajeManoObra : MYGModoCantidad.Directa
                });
            }
            finally { camino.Remove(id); }
        }
    }

    private static HashSet<string> Columnas(SqliteConnection c, string tabla, SqliteTransaction t = null)
    {
        using var cmd = c.CreateCommand(); cmd.Transaction = t; cmd.CommandText = "PRAGMA table_info(\"" + tabla.Replace("\"", "\"\"") + "\")";
        using var r = cmd.ExecuteReader(); var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        while (r.Read()) columnas.Add(r.GetString(1));
        return columnas;
    }
    private sealed class Lectura
    {
        private readonly SqliteConnection conexion;
        private readonly SqliteTransaction transaccion;
        private readonly Dictionary<string, HashSet<string>> columnas = new(StringComparer.OrdinalIgnoreCase);
        private Dictionary<string, MYGUnidadCatalogo> unidades;
        private Dictionary<string, MYGInsumo> productos;
        private Dictionary<string, MYGGrupoRecurso> grupos;
        private Dictionary<string, string> clases;
        internal Lectura(SqliteConnection c, SqliteTransaction t = null) { conexion = c; transaccion = t; }
        internal Dictionary<string, MYGUnidadCatalogo> Unidades => unidades ??= LeerUnidades();
        private Dictionary<string, MYGUnidadCatalogo> LeerUnidades()
        {
            var antiguas = Filas("unidad_tipocosto", new[] { "id_unidad", "id_tipocosto" });
            var actuales = Filas("unidad_tipocostonew", new[] { "id_unidad", "id_tipocosto" });
            return Filas("unidad", new[] {
            "id_unidad", "abreviatura_unidad", "descripcion_unidad", "descripcion_singular", "informacion_unidad",
            "tipo_unidad", "es_unidadcosto", "es_unidadgasto" })
            .Where(x => !string.IsNullOrWhiteSpace(x.Texto("id_unidad"))).ToDictionary(x => x.Texto("id_unidad"), x =>
            {
                string id = x.Texto("id_unidad");
                var enlaces = actuales.Where(f => Igual(f.Texto("id_unidad"), id)).ToList();
                if (enlaces.Count == 0) enlaces = antiguas.Where(f => Igual(f.Texto("id_unidad"), id)).ToList();
                return new MYGUnidadCatalogo
                {
                    Id = id,
                    Simbolo = Nombre(x.Texto("abreviatura_unidad"), x.Texto("descripcion_unidad")),
                    Descripcion = Nombre(x.Texto("informacion_unidad"), Nombre(x.Texto("descripcion_singular"), x.Texto("descripcion_unidad"))),
                    Tipo = Nombre(x.Texto("tipo_unidad"), "N"),
                    EsCostoUnitario = x.Valor("es_unidadcosto") == null || Igual(x.Texto("es_unidadcosto"), "S"),
                    EsGastoGeneral = x.Valor("es_unidadgasto") == null || Igual(x.Texto("es_unidadgasto"), "S"),
                    TiposCosto = enlaces.Select(f => Grupo(f.Texto("id_tipocosto"))).Distinct().OrderBy(g => (int)g).ToList()
                };
            }, StringComparer.OrdinalIgnoreCase);
        }
        internal string Unidad(string id, string ausente = "und") => Unidades.TryGetValue(id ?? "", out var u) && !string.IsNullOrWhiteSpace(u.Simbolo) ? u.Simbolo : ausente;
        internal string GrupoGenerico(string codigo)
        {
            if (string.IsNullOrWhiteSpace(codigo)) return "";
            clases ??= Filas("clase", new[] { "codigo_clase", "descripcion_clase" })
                .GroupBy(f => f.Texto("codigo_clase"), StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First().Texto("descripcion_clase"), StringComparer.OrdinalIgnoreCase);
            // La clase histórica es información de la propia base; no se
            // reclasifica al abrirla con un catálogo de otro año.
            return codigo + (clases.TryGetValue(codigo, out var nombre) && nombre.Length > 0 ? " · " + nombre : "");
        }
        internal MYGGrupoRecurso Grupo(string id)
        {
            grupos ??= Filas("tipo_costo", new[] { "id_tipocosto", "descripcion_tipocosto" })
                .ToDictionary(x => x.Texto("id_tipocosto"), x => GrupoTexto(x.Texto("descripcion_tipocosto")), StringComparer.OrdinalIgnoreCase);
            if (grupos.TryGetValue(id ?? "", out var g)) return g;
            return id switch
            {
                "TC0000000001" => MYGGrupoRecurso.ManoObra,
                "TC0000000003" => MYGGrupoRecurso.Equipo,
                "TC0000000004" => MYGGrupoRecurso.Subcontratos,
                "TC0000000005" => MYGGrupoRecurso.Subpartidas,
                _ => MYGGrupoRecurso.Materiales
            };
        }
        internal Dictionary<string, MYGInsumo> Productos
        {
            get
            {
                if (productos != null) return productos;
                productos = Filas("producto", new[] {
            "id_producto", "descripcion_producto", "id_unidad", "id_tipocosto", "costo_unitariolista", "costo_unitario",
            "codigo_clase", "codigo_subclase", "codigo_producto", "id_categoria", "descripcion_proveedor", "especificaciones", "estado_producto" }).Where(x => !string.IsNullOrWhiteSpace(x.Texto("id_producto")))
            .ToDictionary(x => x.Texto("id_producto"), x => new MYGInsumo
            {
                Id = x.Texto("id_producto"),
                Codigo = Codigo(x, "codigo_producto"),
                GrupoGenerico = GrupoGenerico(x.Texto("codigo_clase")),
                Descripcion = x.Texto("descripcion_producto"),
                Unidad = Unidad(x.Texto("id_unidad")),
                Grupo = Grupo(Nombre(x.Texto("id_tipocosto"), x.Texto("id_categoria"))) == MYGGrupoRecurso.Subpartidas
                    ? MYGGrupoRecurso.Subcontratos : Grupo(Nombre(x.Texto("id_tipocosto"), x.Texto("id_categoria"))),
                Proveedor = Nombre(x.Texto("descripcion_proveedor"), "SIN CLASIFICAR"),
                Especificaciones = x.Texto("especificaciones"),
                Habilitado = !Igual(x.Texto("estado_producto"), "N"),
                Precio = x.Valor("costo_unitariolista") == null ? x.Numero("costo_unitario") : x.Numero("costo_unitariolista")
            }, StringComparer.OrdinalIgnoreCase);
                CodigosUnicos(productos.Values, x => x.Id, x => x.Codigo, (x, codigo) => x.Codigo = codigo);
                return productos;
            }
        }
        internal List<Fila> Filas(string tabla, string[] campos, string filtro = null, string valor = null)
        {
            if (!columnas.TryGetValue(tabla, out var cols)) columnas.Add(tabla, cols = Columnas(conexion, tabla, transaccion));
            if (cols.Count == 0 || (filtro != null && !cols.Contains(filtro))) return new();
            using var cmd = conexion.CreateCommand();
            cmd.Transaction = transaccion;
            cmd.CommandText = "SELECT " + string.Join(",", campos.Select(x => (cols.Contains(x) ? "\"" + x + "\"" : "NULL") + " AS \"" + x + "\"")) + " FROM \"" + tabla + "\"";
            if (filtro != null) { cmd.CommandText += " WHERE \"" + filtro + "\"=$id"; cmd.Parameters.AddWithValue("$id", valor ?? (object)DBNull.Value); }
            using var r = cmd.ExecuteReader(); var filas = new List<Fila>();
            while (r.Read())
            {
                var fila = new Fila();
                for (int n = 0; n < campos.Length; n++) fila.Valores[campos[n]] = r.IsDBNull(n) ? null : r.GetValue(n);
                filas.Add(fila);
            }
            return filas;
        }
    }
    private sealed class Fila
    {
        internal Dictionary<string, object> Valores { get; } = new(StringComparer.OrdinalIgnoreCase);
        internal object Valor(string nombre) => Valores.TryGetValue(nombre, out var v) ? v : null;
        internal string Texto(string nombre) => Convert.ToString(Valor(nombre), CultureInfo.InvariantCulture)?.Trim() ?? "";
        internal decimal Numero(string nombre)
        {
            var v = Valor(nombre); if (v == null) return 0;
            if (decimal.TryParse(Convert.ToString(v, CultureInfo.InvariantCulture), NumberStyles.Float, CultureInfo.InvariantCulture, out var n)) return n;
            throw new InvalidDataException("La base Delphin contiene un valor numérico no válido en " + nombre + ".");
        }
        internal int Entero(string nombre) => Convert.ToInt32(Numero(nombre));
    }
    private static MYGGrupoRecurso GrupoTexto(string texto)
    {
        string t = (texto ?? "").ToUpperInvariant().Replace("-", "").Replace(" ", "");
        if (t.Contains("MANO") || t.Contains("OBRA")) return MYGGrupoRecurso.ManoObra;
        if (t.Contains("EQUIPO") || t.Contains("HERRAMIENTA")) return MYGGrupoRecurso.Equipo;
        if (t.Contains("SUBCONTRATO")) return MYGGrupoRecurso.Subcontratos;
        if (t.Contains("SUBPARTIDA")) return MYGGrupoRecurso.Subpartidas;
        return MYGGrupoRecurso.Materiales;
    }
    private static string Codigo(Fila fila, string ultimo) => string.Concat(new[] {
        fila.Texto("codigo_clase"), fila.Texto("codigo_subclase"), fila.Texto(ultimo) }.Where(x => !string.IsNullOrWhiteSpace(x)));
    private static void CodigosUnicos<T>(IEnumerable<T> elementos, Func<T, string> id, Func<T, string> codigo, Action<T, string> asignar)
    {
        var lista = elementos.OrderBy(id, StringComparer.OrdinalIgnoreCase).ToList();
        var reservados = lista.Select(x => Nombre(codigo(x), id(x))).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var usados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var x in lista)
        {
            string original = Nombre(codigo(x), id(x));
            if (usados.Add(original)) { asignar(x, original); continue; }
            string distintivo = original + " [" + id(x) + "]";
            while (reservados.Contains(distintivo) || !usados.Add(distintivo)) distintivo += "_";
            asignar(x, distintivo);
        }
    }
    private static string Padre(Fila fila, HashSet<string> disponibles)
    {
        string costo = Raiz(fila.Texto("id_costopadre")), titulo = Raiz(fila.Texto("id_titulo"));
        if (costo != null && disponibles.Contains(costo)) return costo;
        if (titulo != null && disponibles.Contains(titulo)) return titulo;
        // Mantener la referencia no resuelta: el validador debe seguir
        // rechazando padres ausentes, sin convertir sus hijos en raíces.
        return costo ?? titulo;
    }
    private static string Raiz(string id) => string.IsNullOrWhiteSpace(id) || id == "__ROOT__" ? null : id;
    private static string Nombre(string nombre, string ausente) => string.IsNullOrWhiteSpace(nombre) ? ausente : nombre;
    private static bool Igual(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    private static decimal Positivo(decimal n, decimal predeterminado) => n > 0 ? n : predeterminado;
    private static int Precision(Fila fila, string campo, int predeterminado, int maximo) =>
        // Cero en proyectos nativos antiguos significa usar la precisión
        // estándar; no convierte precios y coeficientes en números enteros.
        fila.Valor(campo) == null || fila.Entero(campo) == 0 ? predeterminado : Math.Clamp(fila.Entero(campo), 0, maximo);
    private static DateTime Fecha(string texto) => DateTime.TryParse(texto, CultureInfo.GetCultureInfo("es-PE"), DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var f) ? f : default;
    private static string TextoArchivo(object archivo)
    {
        if (archivo is string texto) return texto;
        if (archivo is not byte[] b || b.Length == 0) return "";
        if (b.Length >= 5 && b[0] == '{' && b[1] == '\\' && b[2] == 'r' && b[3] == 't' && b[4] == 'f') return Encoding.Latin1.GetString(b);
        if (b.Length >= 2 && b[0] == 255 && b[1] == 254) return Encoding.Unicode.GetString(b, 2, b.Length - 2);
        if (b.Length >= 3 && b[0] == 239 && b[1] == 187 && b[2] == 191) return Encoding.UTF8.GetString(b, 3, b.Length - 3);
        return "";
    }
}
