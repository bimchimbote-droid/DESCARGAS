# Corrección al abrir obras: referencia al padre en bases Delphin

## A. Resumen de la implementación

El mensaje «Falta el padre de …» procede de la validación de la estructura del
presupuesto. Cuando una partida tiene padre, ese elemento debe existir dentro
del mismo presupuesto.
La captura no permite conocer los identificadores guardados en la base del usuario.

Se identificó un defecto reproducible en el adaptador de bases Delphin: seleccionaba
siempre id_costopadre cuando tenía contenido, aunque ese identificador ya no
existiera dentro del presupuesto. Así podía omitir id_titulo, una referencia
alternativa explícita y válida del mismo presupuesto.

La corrección conserva el padre prioritario cuando existe y utiliza el título
alternativo cuando está comprobado dentro del presupuesto. También incorpora la
cadena de títulos necesaria para esa referencia. Se conserva el rechazo de padres
realmente ausentes y jerarquías circulares. No incorpora padres de otros
presupuestos.
El identificador 0 sigue siendo válido si existe; no se interpreta como raíz.

La apertura consulta SQLite en modo de solo lectura. No se eliminan partidas, no
se cambian identificadores, no se renumera ni se inventan títulos para completar
datos ausentes. El guardado posterior sigue el funcionamiento habitual de MYG.

## B. Archivos completos y acciones

Aplicar sobre la entrega anterior de corrección de compilación, publicada en
DESCARGAS, commit 9b4f2a94fd67851cd47d76c1a8c95439bbbcd866, conservando las
actualizaciones anteriores de colaboración y publicación.

| N.º | Ruta exacta | Acción | Descripción |
| --- | --- | --- | --- |
| 1 | MYG.Core/DelphinImportacionMYG.cs | REEMPLAZAR | Adaptador completo: selecciona un padre comprobado dentro del presupuesto. |
| 2 | MYG.Pruebas/JerarquiaDelphinCheck.cs | CREAR | Pruebas sobre bases nativas sintéticas y conservación de datos. |
| 3 | MYG.Pruebas/Program.cs | REEMPLAZAR | Integra las comprobaciones y el selector --jerarquia-delphin. |
| 4 | CORRECCION_ABRIR_OBRA.md | CREAR | Estas instrucciones y los límites de la corrección. |

## C. Descarga

La respuesta de entrega incluye el ZIP público MYG_PRESUPUESTOS_ACTUALIZACION.zip,
ubicado en una carpeta nueva de bimchimbote-droid/DESCARGAS y fijado al commit de
publicación. La descarga se compara con el ZIP local por bytes y SHA-256; se
comprueban integridad, rutas y contenido de sus cuatro archivos.

## D. Instrucciones para instalar los cambios

1. Cierre MYG, Revit y Visual Studio. Respalde sus cambios locales antes de
   reemplazar archivos. Conserve también su archivo SQLite original.
2. Descargue y extraiga el ZIP dentro de la carpeta que contiene
   MYG.Presupuestos.sln, por ejemplo D:\ADDIN\repos\MYG.Presupuestos_GITHUB.
   Mantenga las subcarpetas del ZIP y acepte reemplazar los archivos de la tabla.
3. El Program.cs de esta entrega va exclusivamente dentro de MYG.Pruebas.
   El archivo de arranque MYG.Desktop/Program.cs de la entrega anterior se conserva.
4. Abra la solución de esa carpeta. Seleccione Release y x64. Restaure los
   paquetes NuGet; después use Compilar > Limpiar solución y Recompilar solución.
5. Ejecute la versión recién compilada. Abra su base habitual y vuelva a abrir
   la obra que mostraba el mensaje. Compruebe sus títulos, partidas, metrados,
   precios y presupuestos antes de guardar modificaciones.

El único archivo que no es .cs en esta entrega es CORRECCION_ABRIR_OBRA.md:
es una guía de lectura que se guarda junto a la solución. No se ejecuta ni se
copia dentro de SQLite o Supabase. No se entregan proyectos .csproj modificados.

## E. Configuraciones adicionales

No hay SQL que ejecutar, migraciones, JSON que editar ni cambios de permisos o
servicios de Supabase. El proyecto de pruebas incluye automáticamente el nuevo
archivo C# mediante el SDK de .NET. Se mantienen las dependencias anteriores.

## F. Compilación y validación

Tecnologías: C#, SDK .NET 10.0.100, Microsoft.Data.Sqlite 10 y SQLite real.
La solución también incluye Desktop net10.0-windows y el conector Revit 2027.

Desde la carpeta de la solución, comandos de comprobación equivalentes:

```powershell
dotnet restore MYG.Presupuestos.sln -p:Platform=x64 -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:Platform=x64 -p:UseRevitReferencePackages=true --no-restore -m:1
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release -- --jerarquia-delphin
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build
```

UseRevitReferencePackages=true permite comprobar la compilación con las referencias
NuGet oficiales sin Revit instalado. Visual Studio puede seguir utilizando las
DLL de su instalación habitual de Revit 2027.

Las pruebas nuevas cubren referencias alternativas, precedencia del padre válido,
títulos anidados, identidad y economía de las partidas, lectura sin modificar el
archivo, aislamiento entre presupuestos y el rechazo de relaciones inválidas.
Resultados ejecutados:

- Antes de la corrección, la base sintética reproduce exactamente
  InvalidDataException: Falta el padre de PARTIDA SINTÉTICA.
- Con la corrección, las 14 comprobaciones nuevas pasan, incluido guardar sin
  editar y reabrir conservando las relaciones originales.
- La suite general MYG.Pruebas completa aprueba 824 comprobaciones, incluidas
  las 14 nuevas. Omite seis comprobaciones que necesitan muestras externas o
  el canal Named Pipes de Windows; no se consideran ejecutadas.
- La solución completa Release/x64 compila con cero errores y cero advertencias.

La respuesta final confirma además la compilación del ZIP aplicado sobre las
entregas anteriores y su descarga pública. No se ejecutaron la interfaz Windows,
Revit ni la apertura del archivo privado mostrado en la captura.

## G. Publicación del código en GitHub

La entrega se publica como ZIP en el repositorio independiente DESCARGAS.
Después de comprobarla en su PC, abra Cambios de Git en Visual Studio, verifique
la rama main, revise los cuatro archivos, haga Commit y luego Push cuando decida
publicar los cambios en bimchimbote-droid/MYG.Presupuestos. Esta sesión no hace
Push al repositorio del código ni sustituye entregas anteriores de DESCARGAS.

## H. Advertencias y cambios pendientes

No se dispone del archivo COLEGIO Y.sqlite mostrado en la captura: no se puede
afirmar que su relación concreta corresponde al defecto reproducido. Si, después
de aplicar la corrección y ejecutar la versión recién compilada, continúa el
mensaje, será necesario revisar una copia de esa base para determinar el padre
ausente. No elimine la partida ni ejecute SQL para quitarle el padre a ciegas.

Los títulos sin presupuesto asignado o pertenecientes a otro presupuesto no se
incorporan automáticamente; su pertenencia requiere comprobar los datos reales.
La interfaz de apertura y el conector Revit requieren una comprobación manual en
Windows. Las pruebas automatizadas usan archivos de prueba sintéticos; ninguna
base privada del usuario se incluye en la descarga pública.

Base utilizada: main del repositorio del código, commit
df8392a5d2910216a097349add3d20ba6103bdf5, más las entregas anteriores conservadas
en esta sesión. Compare antes de reemplazar si tiene modificaciones locales
posteriores en los archivos afectados.
