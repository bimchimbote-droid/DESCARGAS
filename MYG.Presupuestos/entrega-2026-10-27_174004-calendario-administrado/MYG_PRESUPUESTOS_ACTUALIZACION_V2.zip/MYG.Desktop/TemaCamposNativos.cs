using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace MYG_2027;

// ComboBox y DateTimePicker pueden ignorar BackColor con los estilos de
// Windows. La adaptación es común a las ventanas actuales y las creadas luego.
internal static class MYGTemaCamposNativos
{
    [DllImport("uxtheme.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
    private static extern int SetWindowTheme(IntPtr ventana, string aplicacion, string clases);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    private static bool Oscuro => MYG2027_TemaComercial.Oscuro && !SystemInformation.HighContrast;
    private static readonly ConditionalWeakTable<ComboBox, ComboOscuro> combos = new();
    private static readonly ConditionalWeakTable<DateTimePicker, FechaOscura> fechas = new();

    internal static void Aplicar(Control control)
    {
        if (!OperatingSystem.IsWindows() || control.IsDisposed || control.Disposing) return;
        if (control is ComboBox combo) combos.GetValue(combo, c => new ComboOscuro(c)).Actualizar();
        else if (control is DateTimePicker fecha) fechas.GetValue(fecha, f => new FechaOscura(f)).Actualizar();
    }

    private sealed class ComboOscuro
    {
        private readonly ComboBox combo;
        private bool dibujoPropio, actualizando;
        private IntPtr ventana;
        private bool temaOscuro;

        internal ComboOscuro(ComboBox combo)
        {
            this.combo = combo;
            combo.DrawItem += Dibujar;
            combo.HandleCreated += Crear;
            combo.HandleDestroyed += Destruir;
            combo.Disposed += Liberar;
        }

        internal void Actualizar()
        {
            if (actualizando || combo.IsDisposed || combo.Disposing) return;
            // Durante la construcción aún pueden configurarse OwnerDraw y sus
            // eventos después de añadir el control a un contenedor ya tematizado.
            if (!combo.IsHandleCreated) return;
            actualizando = true;
            try
            {
                // Los selectores de colores, fuentes y otros OwnerDraw
                // conservan sus propios eventos y muestras del documento.
                if (Oscuro && combo.DrawMode == DrawMode.Normal)
                {
                    dibujoPropio = true;
                    combo.DrawMode = DrawMode.OwnerDrawFixed;
                }
                else if (!Oscuro && dibujoPropio)
                {
                    dibujoPropio = false;
                    if (combo.DrawMode == DrawMode.OwnerDrawFixed) combo.DrawMode = DrawMode.Normal;
                }
                if (!combo.IsHandleCreated || (ventana == combo.Handle && temaOscuro == Oscuro)) return;
                ventana = combo.Handle; temaOscuro = Oscuro;
                // Desactivar sólo en oscuro el relleno claro de los estilos
                // nativos. En modo normal/alto contraste Windows vuelve a dibujar.
                SetWindowTheme(ventana, Oscuro ? "" : null, Oscuro ? "" : null);
                combo.Invalidate();
            }
            finally { actualizando = false; }
        }

        private void Dibujar(object sender, DrawItemEventArgs e)
        {
            if (!Oscuro || !dibujoPropio) return;
            bool seleccion = (e.State & DrawItemState.Selected) != 0;
            Color fondo = !combo.Enabled ? MYG2027_TemaComercial.SuperficieAlterna
                : seleccion ? MYG2027_TemaComercial.Seleccion : combo.BackColor;
            Color texto = !combo.Enabled ? MYG2027_TemaComercial.Secundario
                : seleccion ? MYG2027_TemaComercial.TextoSeleccion : combo.ForeColor;
            using (var pincel = new SolidBrush(fondo)) e.Graphics.FillRectangle(pincel, e.Bounds);
            string valor = e.Index >= 0 && e.Index < combo.Items.Count
                ? combo.GetItemText(combo.Items[e.Index]) : combo.Text;
            var rectangulo = Rectangle.Inflate(e.Bounds, -2, 0);
            var flags = TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
                TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
            flags |= combo.RightToLeft == RightToLeft.Yes ? TextFormatFlags.RightToLeft | TextFormatFlags.Right : TextFormatFlags.Left;
            TextRenderer.DrawText(e.Graphics, valor, e.Font ?? combo.Font, rectangulo, texto, fondo, flags);
            if ((e.State & DrawItemState.Focus) != 0)
                ControlPaint.DrawFocusRectangle(e.Graphics, e.Bounds, texto, fondo);
        }

        private void Crear(object sender, EventArgs e)
        {
            if (combo.IsDisposed || combo.Disposing) return;
            // Dar primero a Windows el fondo nativo adecuado. La adopción de
            // OwnerDraw se difiere hasta terminar la construcción del control.
            SetWindowTheme(combo.Handle, Oscuro ? "" : null, Oscuro ? "" : null);
            combo.BeginInvoke(new Action(Actualizar));
        }
        private void Destruir(object sender, EventArgs e) => ventana = IntPtr.Zero;
        private void Liberar(object sender, EventArgs e)
        {
            combo.DrawItem -= Dibujar; combo.HandleCreated -= Crear;
            combo.HandleDestroyed -= Destruir; combo.Disposed -= Liberar;
            combos.Remove(combo);
        }
    }

    // Conserva el control nativo: Windows sigue procesando los segmentos de
    // fecha, los dígitos aún en edición, la casilla opcional y las teclas.
    // Se recolorea su dibujo real, en lugar de sustituirlo por fecha.Text.
    private sealed class FechaOscura : NativeWindow, IDisposable
    {
        private const int WmPaint = 0x000F, WmEraseBkgnd = 0x0014, WmPrintClient = 0x0318;
        private const int DtmGetMonthCal = 0x1008, DtmCloseMonthCal = 0x100D;
        [DllImport("user32.dll")] private static extern IntPtr BeginPaint(IntPtr ventana, out Pintura pintura);
        [DllImport("user32.dll")] private static extern bool EndPaint(IntPtr ventana, ref Pintura pintura);
        private delegate bool EnumerarVentana(IntPtr ventana, IntPtr parametro);
        [DllImport("user32.dll")] private static extern bool EnumChildWindows(IntPtr ventana, EnumerarVentana enumerar, IntPtr parametro);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetClassName(IntPtr ventana, StringBuilder nombre, int capacidad);
        [DllImport("user32.dll")] private static extern bool IsChild(IntPtr padre, IntPtr hija);
        [DllImport("user32.dll")] private static extern bool GetClientRect(IntPtr ventana, out Rectangulo rectangulo);
        [DllImport("user32.dll")]
        private static extern int MapWindowPoints(IntPtr origen, IntPtr destino, ref Punto punto, uint cantidad);
        [DllImport("user32.dll", EntryPoint = "SendMessageW")]
        private static extern IntPtr ConsultarFecha(IntPtr ventana, int mensaje, IntPtr parametro, ref InformacionFecha informacion);
        [DllImport("user32.dll")] private static extern bool InvalidateRect(IntPtr ventana, IntPtr rectangulo, bool borrar);
        [DllImport("user32.dll")] private static extern IntPtr GetSysColorBrush(int indice);
        [DllImport("gdi32.dll")] private static extern int SetTextColor(IntPtr dc, int color);
        [DllImport("gdi32.dll")] private static extern int SetBkColor(IntPtr dc, int color);
        [StructLayout(LayoutKind.Sequential)]
        private struct Rectangulo { internal int izquierda, arriba, derecha, abajo; }
        [StructLayout(LayoutKind.Sequential)]
        private struct Punto { internal int x, y; }
        [StructLayout(LayoutKind.Sequential)]
        private struct InformacionFecha
        {
            internal int tamano;
            internal Rectangulo casilla;
            internal uint estadoCasilla;
            internal Rectangulo boton;
            internal uint estadoBoton;
            internal IntPtr edicion, incremento, calendario;
        }
        [StructLayout(LayoutKind.Sequential)]
        private struct Pintura
        {
            internal IntPtr dc;
            internal int borrar, izquierda, arriba, derecha, abajo, restaurar, actualizar;
            internal int reservado1, reservado2, reservado3, reservado4, reservado5, reservado6, reservado7, reservado8;
        }

        private readonly DateTimePicker fecha;
        private readonly Color[] coloresCalendario;
        private readonly List<HijaFecha> hijas = new();
        private Bitmap imagen;
        private byte[] pixeles;
        private bool dibujando, actualizando, liberado, temaOscuro;
        private IntPtr ventana, dcCaptura;
        private MYGCalendarioFechaPopup calendario;
        private bool pulsandoBoton;
        private int generacionCalendario;

        internal FechaOscura(DateTimePicker fecha)
        {
            this.fecha = fecha;
            coloresCalendario = new[] { fecha.CalendarMonthBackground, fecha.CalendarForeColor,
                fecha.CalendarTitleBackColor, fecha.CalendarTitleForeColor, fecha.CalendarTrailingForeColor };
            fecha.HandleCreated += Crear; fecha.HandleDestroyed += Destruir;
            fecha.DropDown += AbrirCalendarioNativo; fecha.Disposed += Liberar;
            fecha.FontChanged += CambiarMetricas; fecha.DpiChangedAfterParent += CambiarMetricas;
            fecha.EnabledChanged += CerrarCalendario; fecha.VisibleChanged += CerrarCalendario;
            if (fecha.IsHandleCreated) AssignHandle(fecha.Handle);
        }

        internal void Actualizar()
        {
            if (actualizando || liberado || fecha.IsDisposed || fecha.Disposing) return;
            actualizando = true;
            try
            {
                // El calendario claro/alto contraste sigue siendo de Windows.
                // En oscuro el desplegable administrado dibuja su propia grilla;
                // no se altera el tema ni la pintura de SysMonthCal32.
                var nuevos = SystemInformation.HighContrast
                        ? new[] { SystemColors.Window, SystemColors.WindowText, SystemColors.Highlight,
                            SystemColors.HighlightText, SystemColors.GrayText } : coloresCalendario;
                fecha.CalendarMonthBackground = nuevos[0]; fecha.CalendarForeColor = nuevos[1];
                fecha.CalendarTitleBackColor = nuevos[2]; fecha.CalendarTitleForeColor = nuevos[3];
                fecha.CalendarTrailingForeColor = nuevos[4];
                if (!fecha.IsHandleCreated) return;
                if (ventana != fecha.Handle || temaOscuro != Oscuro)
                {
                    ventana = fecha.Handle; temaOscuro = Oscuro;
                    // El dibujo clásico tiene superficies neutras conocidas;
                    // no depende de variantes oscuras privadas de uxtheme.
                    SetWindowTheme(ventana, Oscuro ? "" : null, Oscuro ? "" : null);
                }
                PrepararHijas();
                if (!Oscuro) CerrarCalendario(fecha, EventArgs.Empty);
                fecha.Invalidate();
            }
            finally { actualizando = false; }
        }

        private void Crear(object sender, EventArgs e)
        {
            AssignHandle(fecha.Handle);
            Actualizar();
        }
        private void Destruir(object sender, EventArgs e)
        {
            CerrarCalendario(sender, e);
            calendario?.Dispose(); calendario = null;
            foreach (var hija in hijas) hija.ReleaseHandle();
            hijas.Clear();
            ReleaseHandle(); ventana = IntPtr.Zero;
            imagen?.Dispose(); imagen = null; pixeles = null;
        }

        private void PrepararHijas()
        {
            if (!fecha.IsHandleCreated || liberado) return;
            for (int i = hijas.Count - 1; i >= 0; i--)
            {
                if (hijas[i].Handle != IntPtr.Zero && EsCampoNativo(hijas[i].Handle)) continue;
                hijas[i].ReleaseHandle(); hijas.RemoveAt(i);
            }
            EnumChildWindows(fecha.Handle, (h, _) =>
            {
                if (EsCampoNativo(h) && !hijas.Exists(actual => actual.Handle == h)) hijas.Add(new HijaFecha(this, h));
                return true;
            }, IntPtr.Zero);
        }

        private bool EsCampoNativo(IntPtr ventana)
        {
            IntPtr calendario = Enviar(fecha.Handle, DtmGetMonthCal, IntPtr.Zero, IntPtr.Zero);
            if (calendario != IntPtr.Zero && (ventana == calendario || IsChild(calendario, ventana))) return false;
            var nombre = new StringBuilder(64);
            if (GetClassName(ventana, nombre, nombre.Capacity) == 0) return false;
            // El calendario desplegable debe conservar su pintura nativa.
            // WM_PRINTCLIENT no dibuja el mes en todas las versiones de Windows.
            string clase = nombre.ToString();
            return clase.Equals("Edit", StringComparison.OrdinalIgnoreCase)
                || clase.Equals("Button", StringComparison.OrdinalIgnoreCase)
                || clase.Equals("msctls_updown32", StringComparison.OrdinalIgnoreCase);
        }

        // La casilla o el incremento pueden ser HWND independientes según la
        // versión de comctl32. También deben adaptar sus repintados propios.
        private sealed class HijaFecha : NativeWindow
        {
            private readonly FechaOscura propietario;
            internal HijaFecha(FechaOscura propietario, IntPtr ventana)
            { this.propietario = propietario; AssignHandle(ventana); }
            protected override void WndProc(ref Message mensaje)
            {
                if (propietario.ProcesarCalendario(ref mensaje)) return;
                if (propietario.dibujando && mensaje.Msg == WmPaint &&
                    (propietario.dcCaptura == IntPtr.Zero || mensaje.WParam != propietario.dcCaptura))
                { mensaje.Result = IntPtr.Zero; return; }
                if (propietario.dibujando && mensaje.Msg == WmEraseBkgnd &&
                    (propietario.dcCaptura == IntPtr.Zero || mensaje.WParam != propietario.dcCaptura))
                { mensaje.Result = new IntPtr(1); return; }
                if (Oscuro && !propietario.liberado && !propietario.dibujando)
                {
                    if (mensaje.Msg == WmEraseBkgnd) { mensaje.Result = new IntPtr(1); return; }
                    if (mensaje.Msg == WmPaint || (mensaje.Msg == WmPrintClient && mensaje.WParam != IntPtr.Zero))
                    {
                        propietario.Pintar(Handle, mensaje.WParam);
                        mensaje.Result = IntPtr.Zero; return;
                    }
                }
                base.WndProc(ref mensaje);
                if (Oscuro && !propietario.liberado && !propietario.dibujando && EsInteraccion(mensaje.Msg) && Handle != IntPtr.Zero)
                    InvalidateRect(Handle, IntPtr.Zero, false);
            }
        }

        private static bool EsInteraccion(int mensaje) => mensaje is
            0x0007 or 0x0008 or 0x000A or 0x0100 or 0x0101 or 0x0102 or
            0x0201 or 0x0202 or 0x0203 or 0x020A or 0x0111 or 0x004E;
        private void CambiarMetricas(object sender, EventArgs e)
        {
            CerrarCalendario(sender, e);
            Actualizar();
        }
        private void CerrarCalendario(object sender, EventArgs e)
        {
            generacionCalendario++;
            if (pulsandoBoton && fecha.IsHandleCreated) fecha.Capture = false;
            pulsandoBoton = false;
            calendario?.Close(ToolStripDropDownCloseReason.CloseCalled);
        }

        private void AbrirCalendarioPropio()
        {
            if (liberado || !Oscuro || fecha.ShowUpDown || !fecha.Enabled ||
                !fecha.IsHandleCreated || fecha.IsDisposed || fecha.Disposing) return;
            generacionCalendario++;
            if (calendario == null)
            {
                calendario = new MYGCalendarioFechaPopup(fecha);
                calendario.FechaElegida += ElegirFecha;
                calendario.Closed += (_, e) =>
                {
                    if (e.CloseReason == ToolStripDropDownCloseReason.Keyboard &&
                        !liberado && !fecha.IsDisposed && !fecha.Disposing && fecha.CanFocus)
                        fecha.Focus();
                };
            }
            if (calendario.Visible) calendario.Close(ToolStripDropDownCloseReason.Keyboard);
            else calendario.Abrir();
        }

        private void ElegirFecha(DateTime dia)
        {
            if (liberado || fecha.IsDisposed || fecha.Disposing || !fecha.Enabled) return;
            DateTime valor = dia.Date.Add(fecha.Value.TimeOfDay);
            if (valor < fecha.MinDate) valor = fecha.MinDate;
            if (valor > fecha.MaxDate) valor = fecha.MaxDate;
            fecha.Value = valor;
            if (fecha.IsDisposed || fecha.Disposing) return;
            fecha.Checked = true;
            if (fecha.CanFocus) fecha.Focus();
        }

        private void AbrirCalendarioNativo(object sender, EventArgs e)
        {
            if (!Oscuro || liberado) return;
            IntPtr nativo = Enviar(fecha.Handle, DtmGetMonthCal, IntPtr.Zero, IntPtr.Zero);
            if (nativo == IntPtr.Zero) return;
            int generacion = ++generacionCalendario;
            // Respaldo para aperturas solicitadas por accesibilidad u otro código
            // que no pase por nuestros mensajes de mouse/teclado.
            fecha.BeginInvoke(new Action(() =>
            {
                if (liberado || generacion != generacionCalendario || !Oscuro ||
                    !fecha.IsHandleCreated || fecha.IsDisposed || fecha.Disposing) return;
                if (Enviar(fecha.Handle, DtmGetMonthCal, IntPtr.Zero, IntPtr.Zero) != nativo) return;
                Enviar(fecha.Handle, DtmCloseMonthCal, IntPtr.Zero, IntPtr.Zero);
                if (calendario?.Visible != true) AbrirCalendarioPropio();
            }));
        }

        private bool EnBoton(IntPtr coordenadas, IntPtr origen)
        {
            var info = new InformacionFecha { tamano = Marshal.SizeOf<InformacionFecha>() };
            ConsultarFecha(fecha.Handle, 0x100E, IntPtr.Zero, ref info); // DTM_GETDATETIMEPICKERINFO.
            var punto = new Punto
            {
                x = unchecked((short)(coordenadas.ToInt64() & 0xffff)),
                y = unchecked((short)((coordenadas.ToInt64() >> 16) & 0xffff))
            };
            if (origen != fecha.Handle) MapWindowPoints(origen, fecha.Handle, ref punto, 1);
            return punto.x >= info.boton.izquierda && punto.x < info.boton.derecha &&
                punto.y >= info.boton.arriba && punto.y < info.boton.abajo;
        }

        private bool ProcesarCalendario(ref Message mensaje)
        {
            if (mensaje.Msg == 0x0215) pulsandoBoton = false; // WM_CAPTURECHANGED.
            if (!Oscuro || liberado || !fecha.Enabled || fecha.ShowUpDown) return false;
            if (mensaje.Msg is 0x0201 or 0x0203 && EnBoton(mensaje.LParam, mensaje.HWnd))
            {
                pulsandoBoton = true; fecha.Focus(); fecha.Capture = true;
                mensaje.Result = IntPtr.Zero; return true;
            }
            if (mensaje.Msg == 0x0202 && pulsandoBoton)
            {
                pulsandoBoton = false; fecha.Capture = false;
                if (EnBoton(mensaje.LParam, mensaje.HWnd)) AbrirCalendarioPropio();
                mensaje.Result = IntPtr.Zero; return true;
            }
            if (mensaje.Msg is 0x0100 or 0x0104)
            {
                var tecla = (Keys)mensaje.WParam.ToInt32();
                bool alt = (mensaje.LParam.ToInt64() & 0x20000000) != 0 || (Control.ModifierKeys & Keys.Alt) != 0;
                if ((tecla == Keys.F4 && !alt) || (tecla == Keys.Down && alt))
                {
                    // Ignorar repeticiones de una tecla mantenida evita abrir y
                    // cerrar el desplegable varias veces en la misma pulsación.
                    if ((mensaje.LParam.ToInt64() & 0x40000000) == 0) AbrirCalendarioPropio();
                    mensaje.Result = IntPtr.Zero; return true;
                }
            }
            return false;
        }

        protected override void WndProc(ref Message mensaje)
        {
            if (ProcesarCalendario(ref mensaje)) return;
            if (dibujando && mensaje.Msg == WmPaint && (dcCaptura == IntPtr.Zero || mensaje.WParam != dcCaptura))
            { mensaje.Result = IntPtr.Zero; return; }
            if (dibujando && mensaje.Msg == WmEraseBkgnd && (dcCaptura == IntPtr.Zero || mensaje.WParam != dcCaptura))
            { mensaje.Result = new IntPtr(1); return; }
            if (dibujando && mensaje.WParam == dcCaptura && dcCaptura != IntPtr.Zero)
            {
                // BackColor/ForeColor administrados permanecen oscuros. Sólo
                // la captura necesita la paleta nativa clara antes de traducirla.
                if (mensaje.Msg is 0x0133 or 0x0135 or 0x0138 or 0x2133 or 0x2135 or 0x2138)
                {
                    SetBkColor(mensaje.WParam, ColorTranslator.ToWin32(SystemColors.Window));
                    SetTextColor(mensaje.WParam, ColorTranslator.ToWin32(SystemColors.WindowText));
                    mensaje.Result = GetSysColorBrush(5); return;
                }
                if (mensaje.Msg == WmEraseBkgnd)
                {
                    using var grafico = Graphics.FromHdc(mensaje.WParam);
                    grafico.Clear(SystemColors.Window);
                    mensaje.Result = new IntPtr(1); return;
                }
            }
            if (Oscuro && !liberado && !dibujando)
            {
                if (mensaje.Msg == WmEraseBkgnd) { mensaje.Result = new IntPtr(1); return; }
                if (mensaje.Msg == WmPaint)
                {
                    Pintar(Handle, mensaje.WParam); mensaje.Result = IntPtr.Zero; return;
                }
                if (mensaje.Msg == WmPrintClient && mensaje.WParam != IntPtr.Zero)
                {
                    Pintar(Handle, mensaje.WParam); mensaje.Result = IntPtr.Zero; return;
                }
            }
            base.WndProc(ref mensaje);
            if (mensaje.Msg == 0x0210 && !liberado) PrepararHijas(); // WM_PARENTNOTIFY.
            // Algunos controles comunes también dibujan al cambiar el foco o
            // editar. Invalidar vuelve a aplicar la misma paleta a ese cuadro.
            if (Oscuro && !liberado && !dibujando && EsInteraccion(mensaje.Msg))
                fecha.Invalidate();
        }

        private void Pintar(IntPtr objetivo, IntPtr destino)
        {
            if (!GetClientRect(objetivo, out var rectangulo)) return;
            var tamano = new Size(rectangulo.derecha - rectangulo.izquierda, rectangulo.abajo - rectangulo.arriba);
            if (tamano.Width < 1 || tamano.Height < 1)
            {
                if (destino == IntPtr.Zero)
                {
                    BeginPaint(objetivo, out var vacia);
                    EndPaint(objetivo, ref vacia);
                }
                return;
            }
            dibujando = true;
            try
            {
                if (imagen == null || imagen.Size != tamano)
                {
                    imagen?.Dispose();
                    imagen = new Bitmap(tamano.Width, tamano.Height, PixelFormat.Format32bppRgb);
                    imagen.SetResolution(fecha.DeviceDpi, fecha.DeviceDpi);
                    pixeles = new byte[checked(imagen.Width * imagen.Height * 4)];
                }
                else if (Math.Abs(imagen.HorizontalResolution - fecha.DeviceDpi) > .1F)
                    imagen.SetResolution(fecha.DeviceDpi, fecha.DeviceDpi);
                using (var grafico = Graphics.FromImage(imagen))
                {
                    grafico.Clear(SystemColors.Window);
                    IntPtr dc = grafico.GetHdc();
                    try
                    {
                        dcCaptura = dc;
                        // La captura directa evita que WM_PRINT despache borrados
                        // o repintados intermedios sobre el DC de pantalla.
                        // Los HWND hijos conservan sus propios hooks de pintura.
                        Enviar(objetivo, WmPrintClient, dc, new IntPtr(0x0004 | 0x0008));
                    }
                    finally { dcCaptura = IntPtr.Zero; grafico.ReleaseHdc(dc); }
                }
                Recolorear();
                if (destino != IntPtr.Zero)
                {
                    using var grafico = Graphics.FromHdc(destino);
                    grafico.DrawImageUnscaled(imagen, Point.Empty);
                }
                else
                {
                    IntPtr dc = BeginPaint(objetivo, out var pintura);
                    try
                    {
                        if (dc != IntPtr.Zero)
                        {
                            using var grafico = Graphics.FromHdc(dc);
                            grafico.DrawImageUnscaled(imagen, Point.Empty);
                        }
                    }
                    finally { EndPaint(objetivo, ref pintura); }
                }
            }
            finally { dibujando = false; }
        }

        private void Recolorear()
        {
            var datos = imagen.LockBits(new Rectangle(Point.Empty, imagen.Size), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            try
            {
                Marshal.Copy(datos.Scan0, pixeles, 0, pixeles.Length);
                MYGFechaPaletaOscura.Aplicar(pixeles, imagen.Width, imagen.Height,
                    MYG2027_TemaComercial.Superficie, MYG2027_TemaComercial.Texto,
                    MYG2027_TemaComercial.Azul, MYG2027_TemaComercial.TextoSobreAzul,
                    new[] { SystemColors.Highlight, SystemColors.ActiveCaption, SystemColors.HotTrack }, SystemColors.HighlightText);
                Marshal.Copy(pixeles, 0, datos.Scan0, pixeles.Length);
            }
            finally { imagen.UnlockBits(datos); }
        }

        private void Liberar(object sender, EventArgs e) => Dispose();
        public void Dispose()
        {
            if (liberado) return;
            liberado = true;
            generacionCalendario++;
            fecha.HandleCreated -= Crear; fecha.HandleDestroyed -= Destruir;
            fecha.DropDown -= AbrirCalendarioNativo; fecha.Disposed -= Liberar;
            fecha.FontChanged -= CambiarMetricas; fecha.DpiChangedAfterParent -= CambiarMetricas;
            fecha.EnabledChanged -= CerrarCalendario; fecha.VisibleChanged -= CerrarCalendario;
            calendario?.Dispose(); calendario = null;
            foreach (var hija in hijas) hija.ReleaseHandle();
            hijas.Clear();
            ReleaseHandle(); imagen?.Dispose(); imagen = null; pixeles = null;
            fechas.Remove(fecha);
        }
    }
}
