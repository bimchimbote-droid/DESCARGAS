using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

// El mes se compone de controles administrados. No depende de la pintura de
// SysMonthCal32 ni de capturar una ventana nativa para mostrar sus días.
internal sealed class MYGCalendarioFechaPopup : ToolStripDropDown
{
    private readonly DateTimePicker fecha;
    private readonly ContenidoCalendario contenido;
    private readonly TableLayoutPanel tabla;
    private readonly Label mes;
    private readonly Label[] semanas = new Label[7];
    private readonly BotonCalendario anterior, siguiente, hoy;
    private readonly BotonCalendario[] dias = new BotonCalendario[42];
    private readonly ToolStripControlHost alojamiento;
    private Font fuentePropia;
    private CultureInfo cultura;
    private DateTime activa, mostrada, minimo, maximo;
    private bool confirmada;

    internal event Action<DateTime> FechaElegida;

    internal MYGCalendarioFechaPopup(DateTimePicker fecha)
    {
        this.fecha = fecha ?? throw new ArgumentNullException(nameof(fecha));
        Name = "calendarioFechaPopup";
        AccessibleName = "Seleccionar fecha";
        AutoSize = false; AutoClose = true; DropShadowEnabled = true;
        Margin = System.Windows.Forms.Padding.Empty;
        contenido = new ContenidoCalendario(this)
        {
            Name = "calendarioFechaContenido", AutoScaleMode = AutoScaleMode.None,
            Margin = System.Windows.Forms.Padding.Empty, TabStop = true
        };
        tabla = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 7, RowCount = 9,
            Margin = System.Windows.Forms.Padding.Empty
        };
        for (int i = 0; i < 7; i++) tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 7));
        tabla.RowStyles.Add(new RowStyle(SizeType.Absolute));
        tabla.RowStyles.Add(new RowStyle(SizeType.Absolute));
        for (int i = 0; i < 6; i++) tabla.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / 6));
        tabla.RowStyles.Add(new RowStyle(SizeType.Absolute));
        anterior = Boton("calendarioFechaAnterior", "‹", "Mes anterior");
        siguiente = Boton("calendarioFechaSiguiente", "›", "Mes siguiente");
        mes = new Label
        {
            Name = "calendarioFechaMes", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter,
            Margin = System.Windows.Forms.Padding.Empty, AutoEllipsis = true
        };
        tabla.Controls.Add(anterior, 0, 0); tabla.Controls.Add(mes, 1, 0); tabla.SetColumnSpan(mes, 5);
        tabla.Controls.Add(siguiente, 6, 0);
        anterior.Click += (_, _) => MoverMes(-1);
        siguiente.Click += (_, _) => MoverMes(1);
        for (int i = 0; i < semanas.Length; i++)
        {
            semanas[i] = new Label
            {
                Name = "calendarioFechaSemana" + i, Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter, Margin = System.Windows.Forms.Padding.Empty
            };
            tabla.Controls.Add(semanas[i], i, 1);
        }
        for (int i = 0; i < dias.Length; i++)
        {
            var boton = dias[i] = Boton("calendarioFechaDia" + i, "", "Fecha");
            boton.Click += (_, _) => { if (boton.Tag is DateTime dia) Elegir(dia); };
            tabla.Controls.Add(boton, i % 7, 2 + i / 7);
        }
        hoy = Boton("calendarioFechaHoy", "", "Hoy");
        hoy.Click += (_, _) => Elegir(DateTime.Today);
        tabla.Controls.Add(hoy, 0, 8); tabla.SetColumnSpan(hoy, 7);
        contenido.Controls.Add(tabla);
        alojamiento = new ToolStripControlHost(contenido)
        {
            AutoSize = false, Margin = System.Windows.Forms.Padding.Empty,
            Padding = System.Windows.Forms.Padding.Empty
        };
        Items.Add(alojamiento);
        MYG2027_TemaComercial.CambioTema += CambiarTema;
    }

    private BotonCalendario Boton(string nombre, string texto, string accesible)
    {
        var boton = new BotonCalendario
        {
            Name = nombre, Text = texto, AccessibleName = accesible,
            Dock = DockStyle.Fill, Margin = System.Windows.Forms.Padding.Empty,
            FlatStyle = FlatStyle.Flat, UseVisualStyleBackColor = false, TabStop = false
        };
        boton.KeyDown += (_, e) =>
        {
            if (ProcesarTecla(e.KeyData)) e.Handled = e.SuppressKeyPress = true;
        };
        return boton;
    }

    internal void Abrir()
    {
        if (IsDisposed || fecha.IsDisposed || fecha.Disposing || !fecha.IsHandleCreated || !fecha.Enabled) return;
        cultura = CultureInfo.CurrentCulture;
        minimo = fecha.MinDate.Date; maximo = fecha.MaxDate.Date;
        activa = MYGCalendarioFechaModelo.Limitar(fecha.Value, minimo, maximo);
        mostrada = MYGCalendarioFechaModelo.InicioMes(activa);
        confirmada = false;
        RightToLeft = contenido.RightToLeft = fecha.RightToLeft;
        // El desplegable se reutiliza y puede permanecer oculto mientras el
        // propietario sustituye y libera CalendarFont. Conservar una copia
        // propia evita usar después una fuente ajena ya liberada.
        var anteriorFuente = fuentePropia;
        fuentePropia = (Font)fecha.CalendarFont.Clone();
        Font = contenido.Font = tabla.Font = alojamiento.Font = fuentePropia;
        foreach (Control control in tabla.Controls) control.Font = fuentePropia;
        anteriorFuente?.Dispose();
        ActualizarDias();
        var ancla = fecha.RectangleToScreen(fecha.ClientRectangle);
        var area = Screen.FromControl(fecha).WorkingArea;
        Medir(area);
        int x = Math.Clamp(ancla.Left, area.Left, Math.Max(area.Left, area.Right - Width));
        int y = ancla.Bottom;
        if (y + Height > area.Bottom) y = ancla.Top - Height;
        y = Math.Clamp(y, area.Top, Math.Max(area.Top, area.Bottom - Height));
        Show(fecha, fecha.PointToClient(new Point(x, y)));
        EnfocarDia();
    }

    protected override void OnOpened(EventArgs e)
    {
        base.OnOpened(e);
        // La aplicación tematiza los menús al mostrarlos. Reponer después los
        // colores de selección propios, además del dibujo independiente de los días.
        AplicarColores();
        EnfocarDia();
    }

    private void Medir(Rectangle area)
    {
        int P(int valor) => Math.Max(1, (int)Math.Ceiling(valor * fecha.DeviceDpi / 96D));
        using var dibujo = fecha.CreateGraphics();
        int altoTexto = (int)Math.Ceiling(Font.GetHeight(dibujo));
        int MedirTexto(string texto) => TextRenderer.MeasureText(dibujo, texto, Font,
            Size.Empty, TextFormatFlags.NoPadding | TextFormatFlags.SingleLine).Width;
        int margen = P(6), marco = P(1);
        int altoDia = Math.Max(P(26), altoTexto + P(10));
        int altoCabecera = Math.Max(P(30), altoTexto + P(12));
        int altoSemana = altoTexto + P(6);
        int anchoDia = Math.Max(P(32), semanas.Max(dia => MedirTexto(dia.Text)) + P(10));
        int ancho = Math.Max(anchoDia * 7 + margen * 2 + marco * 2,
            Math.Max(MedirTexto(mes.Text) + altoCabecera * 2 + margen * 4, MedirTexto(hoy.Text) + margen * 4));
        int alto = altoCabecera * 2 + altoSemana + altoDia * 6 + margen * 2 + marco * 2;
        Padding = new Padding(marco);
        tabla.Padding = new Padding(margen);
        tabla.RowStyles[0].Height = tabla.RowStyles[8].Height = altoCabecera;
        tabla.RowStyles[1].Height = altoSemana;
        Size = new Size(Math.Min(ancho, area.Width), Math.Min(alto, area.Height));
        alojamiento.Size = contenido.Size = new Size(Math.Max(1, Width - marco * 2), Math.Max(1, Height - marco * 2));
    }

    private void ActualizarDias()
    {
        mes.Text = mostrada.ToString("MMMM yyyy", cultura);
        mes.AccessibleName = mes.Text;
        int primero = (int)cultura.DateTimeFormat.FirstDayOfWeek;
        for (int i = 0; i < semanas.Length; i++)
        {
            var diaSemana = (DayOfWeek)((primero + i) % 7);
            semanas[i].Text = cultura.DateTimeFormat.GetAbbreviatedDayName(diaSemana);
            semanas[i].AccessibleName = cultura.DateTimeFormat.GetDayName(diaSemana);
        }
        DateTime?[] celdas = MYGCalendarioFechaModelo.Dias(mostrada, cultura.DateTimeFormat.FirstDayOfWeek);
        for (int i = 0; i < dias.Length; i++)
        {
            var boton = dias[i];
            boton.Tag = celdas[i];
            boton.Text = celdas[i]?.Day.ToString(cultura) ?? "";
            boton.Enabled = celdas[i] is DateTime dia && MYGCalendarioFechaModelo.Permitida(dia, minimo, maximo);
            boton.Activo = celdas[i] == activa;
            boton.OtroMes = celdas[i] is DateTime fechaDia && fechaDia.Month != mostrada.Month;
            boton.EsHoy = celdas[i] == DateTime.Today;
            boton.TabStop = boton.Activo && boton.Enabled;
            boton.AccessibleName = celdas[i]?.ToString("D", cultura) ?? "Fuera del calendario";
            boton.AccessibleDescription = boton.Activo ? "Fecha activa. Intro para elegir."
                : boton.Enabled ? "Elegir esta fecha." : "Fecha no disponible.";
        }
        anterior.Enabled = mostrada > MYGCalendarioFechaModelo.InicioMes(minimo);
        siguiente.Enabled = mostrada < MYGCalendarioFechaModelo.InicioMes(maximo);
        hoy.Text = "Hoy: " + DateTime.Today.ToString("D", cultura);
        hoy.AccessibleName = hoy.Text;
        hoy.Enabled = MYGCalendarioFechaModelo.Permitida(DateTime.Today, minimo, maximo);
        AplicarColores();
    }

    private void AplicarColores()
    {
        BackColor = MYG2027_TemaComercial.Borde;
        ForeColor = contenido.ForeColor = tabla.ForeColor = MYG2027_TemaComercial.Texto;
        contenido.BackColor = tabla.BackColor = mes.BackColor = MYG2027_TemaComercial.Superficie;
        mes.ForeColor = MYG2027_TemaComercial.Texto;
        foreach (var semana in semanas)
        {
            semana.BackColor = MYG2027_TemaComercial.Superficie;
            semana.ForeColor = MYG2027_TemaComercial.Secundario;
        }
        foreach (var boton in dias.Concat(new[] { anterior, siguiente, hoy }))
        {
            boton.BackColor = boton.Activo ? MYG2027_TemaComercial.Azul : MYG2027_TemaComercial.Superficie;
            boton.ForeColor = boton.Activo ? MYG2027_TemaComercial.TextoSobreAzul
                : boton.OtroMes || !boton.Enabled ? MYG2027_TemaComercial.Secundario : MYG2027_TemaComercial.Texto;
            boton.FlatAppearance.BorderSize = 0;
            boton.Invalidate();
        }
    }

    private void MoverMes(int cantidad)
    {
        activa = MYGCalendarioFechaModelo.MoverMes(activa, cantidad, minimo, maximo);
        mostrada = MYGCalendarioFechaModelo.InicioMes(activa);
        ActualizarDias(); EnfocarDia();
    }

    private void MoverDias(int cantidad)
    {
        activa = MYGCalendarioFechaModelo.MoverDias(activa, cantidad, minimo, maximo);
        mostrada = MYGCalendarioFechaModelo.InicioMes(activa);
        ActualizarDias(); EnfocarDia();
    }

    private void EnfocarDia()
    {
        if (!Visible) return;
        dias.FirstOrDefault(dia => dia.Enabled && dia.Activo)?.Focus();
    }

    private void Elegir(DateTime dia)
    {
        if (confirmada || !MYGCalendarioFechaModelo.Permitida(dia, minimo, maximo)) return;
        confirmada = true;
        var elegir = FechaElegida;
        Close(ToolStripDropDownCloseReason.ItemClicked);
        elegir?.Invoke(dia.Date);
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) =>
        ProcesarTecla(keyData) || base.ProcessCmdKey(ref msg, keyData);

    private bool ProcesarTecla(Keys teclas)
    {
        Keys tecla = teclas & Keys.KeyCode;
        if (tecla is Keys.Escape or Keys.F4 || tecla == Keys.Down && teclas.HasFlag(Keys.Alt))
        {
            Close(ToolStripDropDownCloseReason.Keyboard); return true;
        }
        if (tecla == Keys.Tab)
        {
            bool avanzar = !teclas.HasFlag(Keys.Shift);
            Close(ToolStripDropDownCloseReason.Keyboard);
            if (!fecha.IsDisposed && fecha.IsHandleCreated)
                fecha.BeginInvoke(new Action(() =>
                {
                    if (!fecha.IsDisposed && fecha.IsHandleCreated)
                        fecha.FindForm()?.SelectNextControl(fecha, avanzar, true, true, true);
                }));
            return true;
        }
        if (teclas.HasFlag(Keys.Alt)) return false;
        switch (tecla)
        {
            case Keys.Left: MoverDias(RightToLeft == RightToLeft.Yes ? 1 : -1); break;
            case Keys.Right: MoverDias(RightToLeft == RightToLeft.Yes ? -1 : 1); break;
            case Keys.Up: MoverDias(-7); break;
            case Keys.Down: MoverDias(7); break;
            case Keys.PageUp: MoverMes(teclas.HasFlag(Keys.Control) ? -12 : -1); break;
            case Keys.PageDown: MoverMes(teclas.HasFlag(Keys.Control) ? 12 : 1); break;
            case Keys.Home:
                MoverDias(-((7 + (int)activa.DayOfWeek - (int)cultura.DateTimeFormat.FirstDayOfWeek) % 7)); break;
            case Keys.End:
                MoverDias(6 - (7 + (int)activa.DayOfWeek - (int)cultura.DateTimeFormat.FirstDayOfWeek) % 7); break;
            case Keys.Enter:
            case Keys.Space: Elegir(activa); break;
            default: return false;
        }
        return true;
    }

    private void CambiarTema(object sender, EventArgs e)
    {
        if (!IsDisposed) AplicarColores();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) MYG2027_TemaComercial.CambioTema -= CambiarTema;
        try { base.Dispose(disposing); }
        finally
        {
            if (disposing) { fuentePropia?.Dispose(); fuentePropia = null; }
        }
    }

    private sealed class ContenidoCalendario : UserControl
    {
        private readonly MYGCalendarioFechaPopup propietario;
        internal ContenidoCalendario(MYGCalendarioFechaPopup propietario) => this.propietario = propietario;
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData) =>
            propietario.ProcesarTecla(keyData) || base.ProcessCmdKey(ref msg, keyData);
    }

    private sealed class BotonCalendario : Button
    {
        internal bool Activo, OtroMes, EsHoy;
        protected override void OnPaint(PaintEventArgs e)
        {
            // La selección usa siempre la paleta actual, aunque el adaptador
            // genérico de botones haya actualizado BackColor o FlatAppearance.
            Color fondo = Activo ? MYG2027_TemaComercial.Azul : MYG2027_TemaComercial.Superficie;
            Color texto = Activo ? MYG2027_TemaComercial.TextoSobreAzul
                : OtroMes || !Enabled ? MYG2027_TemaComercial.Secundario : MYG2027_TemaComercial.Texto;
            using (var pincel = new SolidBrush(fondo)) e.Graphics.FillRectangle(pincel, ClientRectangle);
            TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle, texto, fondo,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
                TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
            if (EsHoy && Width > 1 && Height > 1)
            {
                using var borde = new Pen(Activo ? MYG2027_TemaComercial.TextoSobreAzul : MYG2027_TemaComercial.Azul);
                e.Graphics.DrawRectangle(borde, 1, 1, Math.Max(0, Width - 3), Math.Max(0, Height - 3));
            }
            if (Focused && ShowFocusCues)
                ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -3, -3), texto, fondo);
        }
    }
}
