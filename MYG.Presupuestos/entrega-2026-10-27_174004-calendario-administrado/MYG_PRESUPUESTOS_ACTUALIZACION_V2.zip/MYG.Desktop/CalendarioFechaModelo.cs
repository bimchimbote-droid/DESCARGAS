using System;

namespace MYG_2027;

// Geometría y navegación por fechas gregorianas, independiente de WinForms.
// Los resultados contienen sólo la fecha (00:00) y conservan el Kind de entrada.
internal static class MYGCalendarioFechaModelo
{
    internal static DateTime InicioMes(DateTime fecha) => fecha.Date.AddDays(1 - fecha.Day);

    // Seis semanas completas. En los extremos de DateTime hay casillas sin
    // fecha representable; se dejan vacías en vez de desbordar o repetir días.
    internal static DateTime?[] Dias(DateTime mes, DayOfWeek primerDia)
    {
        if ((uint)primerDia > 6) throw new ArgumentOutOfRangeException(nameof(primerDia));
        DateTime inicio = InicioMes(mes);
        int anteriores = ((int)inicio.DayOfWeek - (int)primerDia + 7) % 7;
        var dias = new DateTime?[42];
        for (int i = 0; i < dias.Length; i++)
        {
            long ticks = inicio.Ticks + (i - anteriores) * TimeSpan.TicksPerDay;
            if (ticks >= DateTime.MinValue.Ticks && ticks <= DateTime.MaxValue.Date.Ticks)
                dias[i] = new DateTime(ticks, mes.Kind);
        }
        return dias;
    }

    internal static bool Permitida(DateTime dia, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        return dia.Date >= minimo.Date && dia.Date <= maximo.Date;
    }

    internal static DateTime Limitar(DateTime dia, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        DateTime fecha = dia.Date;
        if (fecha < minimo.Date) fecha = minimo.Date;
        if (fecha > maximo.Date) fecha = maximo.Date;
        return DateTime.SpecifyKind(fecha, dia.Kind);
    }

    // Saturar el índice mensual evita AddMonths fuera de 1..9999 y conserva
    // el día de mes cuando existe; por ejemplo 31/01 pasa a 28 o 29/02.
    internal static DateTime MoverMes(DateTime dia, int meses, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        long indice = Math.Clamp((dia.Year - 1L) * 12 + dia.Month - 1 + meses, 0, 9999L * 12 - 1);
        int ano = (int)(indice / 12) + 1, mes = (int)(indice % 12) + 1;
        var fecha = new DateTime(ano, mes, Math.Min(dia.Day, DateTime.DaysInMonth(ano, mes)),
            0, 0, 0, dia.Kind);
        return Limitar(fecha, minimo, maximo);
    }

    internal static DateTime MoverDias(DateTime dia, int dias, DateTime minimo, DateTime maximo)
    {
        ValidarRango(minimo, maximo);
        // Calcular en días, no en ticks: incluso int.Min/MaxValue caben en long.
        long destino = Math.Clamp(dia.Date.Ticks / TimeSpan.TicksPerDay + dias,
            minimo.Date.Ticks / TimeSpan.TicksPerDay, maximo.Date.Ticks / TimeSpan.TicksPerDay);
        return new DateTime(destino * TimeSpan.TicksPerDay, dia.Kind);
    }

    private static void ValidarRango(DateTime minimo, DateTime maximo)
    {
        if (minimo.Date > maximo.Date)
            throw new ArgumentException("La fecha mínima no puede ser posterior a la máxima.", nameof(minimo));
    }
}
