using System;
using System.Linq;
using MYG_2027;

internal static class CalendarioFechaModeloCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        DateTime minimo = DateTime.MinValue, maximo = DateTime.MaxValue;
        var octubre = MYGCalendarioFechaModelo.Dias(new DateTime(2026, 10, 27), DayOfWeek.Monday);
        Exige(octubre.Length == 42 && octubre[0] == new DateTime(2026, 9, 28) &&
            octubre[^1] == new DateTime(2026, 11, 8), "La grilla de octubre debe comenzar en lunes y cubrir seis semanas.");
        var domingo = MYGCalendarioFechaModelo.Dias(new DateTime(2026, 10, 1), DayOfWeek.Sunday);
        Exige(domingo[0] == new DateTime(2026, 9, 27) && domingo[^1] == new DateTime(2026, 11, 7),
            "Cambiar el primer día de semana debe desplazar la grilla, no sus fechas.");
        pasa("Calendario de fecha alinea seis semanas con lunes o domingo y muestra días de meses vecinos");

        foreach (int ano in new[] { 1900, 2000, 2024, 2026, 2100 })
            for (int mes = 1; mes <= 12; mes++)
                foreach (DayOfWeek primero in Enum.GetValues<DayOfWeek>())
                {
                    var dias = MYGCalendarioFechaModelo.Dias(new DateTime(ano, mes, 15), primero);
                    Exige(dias[0]?.DayOfWeek == primero &&
                        dias.Count(d => d?.Year == ano && d?.Month == mes) == DateTime.DaysInMonth(ano, mes),
                        "El calendario debe contener todos los días del mes una sola vez, incluidos los años bisiestos y siglos.");
                    for (int i = 1; i < dias.Length; i++)
                        Exige(dias[i] == dias[i - 1]?.AddDays(1), "Los días de la grilla deben ser consecutivos sin duplicados.");
                }
        pasa("Meses de 28, 29, 30 y 31 días respetan años bisiestos y las siete alineaciones semanales");

        Exige(MYGCalendarioFechaModelo.MoverMes(new DateTime(2024, 1, 31), 1, minimo, maximo) == new DateTime(2024, 2, 29) &&
            MYGCalendarioFechaModelo.MoverMes(new DateTime(2026, 3, 31), -1, minimo, maximo) == new DateTime(2026, 2, 28) &&
            MYGCalendarioFechaModelo.MoverMes(new DateTime(2026, 12, 27), 1, minimo, maximo) == new DateTime(2027, 1, 27) &&
            MYGCalendarioFechaModelo.MoverMes(new DateTime(2026, 1, 27), -1, minimo, maximo) == new DateTime(2025, 12, 27),
            "La navegación mensual debe ajustar el último día y cruzar correctamente el cambio de año.");
        pasa("Navegación mensual ajusta finales de mes y cruza diciembre y enero en ambos sentidos");

        var desde = new DateTime(2026, 10, 10, 20, 30, 0);
        var hasta = new DateTime(2026, 11, 3, 1, 15, 0);
        Exige(MYGCalendarioFechaModelo.Permitida(desde.Date, desde, hasta) &&
            MYGCalendarioFechaModelo.Permitida(hasta.Date.AddHours(23), desde, hasta) &&
            !MYGCalendarioFechaModelo.Permitida(desde.Date.AddDays(-1), desde, hasta) &&
            !MYGCalendarioFechaModelo.Permitida(hasta.Date.AddDays(1), desde, hasta),
            "Los extremos son inclusivos por día y la hora no debe deshabilitar una fecha permitida.");
        Exige(MYGCalendarioFechaModelo.Limitar(desde.AddDays(-1), desde, hasta) == desde.Date &&
            MYGCalendarioFechaModelo.Limitar(hasta.AddDays(1), desde, hasta) == hasta.Date &&
            MYGCalendarioFechaModelo.Limitar(desde.AddDays(1), desde, hasta).TimeOfDay == TimeSpan.Zero,
            "Limitar debe devolver sólo la fecha y respetar ambos extremos.");
        pasa("Rangos de fecha incluyen ambos extremos sin que sus horas excluyan un día válido");

        var actual = new DateTime(2026, 10, 27);
        Exige(MYGCalendarioFechaModelo.MoverMes(actual, 1, desde, hasta) == hasta.Date &&
            MYGCalendarioFechaModelo.MoverMes(actual, -1, desde, hasta) == desde.Date &&
            MYGCalendarioFechaModelo.MoverDias(actual, 7, desde, hasta) == hasta.Date &&
            MYGCalendarioFechaModelo.MoverDias(actual, -20, desde, hasta) == desde.Date &&
            MYGCalendarioFechaModelo.MoverDias(actual, -7, desde, hasta) == new DateTime(2026, 10, 20),
            "Flechas semanales y cambios de mes deben detenerse en los límites sin perder su paso interior.");
        Exige(MYGCalendarioFechaModelo.MoverMes(actual, 1, actual, actual) == actual &&
            MYGCalendarioFechaModelo.MoverDias(actual, -1, actual, actual) == actual,
            "Un rango de un solo día debe conservar esa fecha al navegar.");
        pasa("Navegación de días, semanas y meses se detiene en límites parciales y rangos de un día");

        var primera = MYGCalendarioFechaModelo.Dias(minimo, DayOfWeek.Sunday);
        var ultima = MYGCalendarioFechaModelo.Dias(maximo, DayOfWeek.Monday);
        Exige(primera[0] == null && primera[1] == DateTime.MinValue.Date &&
            ultima.Any(d => d == DateTime.MaxValue.Date) && ultima[^1] == null,
            "Las casillas fuera de los años 1..9999 deben permanecer vacías sin repetir fechas.");
        Exige(MYGCalendarioFechaModelo.MoverMes(actual, int.MaxValue, minimo, maximo) == new DateTime(9999, 12, 27) &&
            MYGCalendarioFechaModelo.MoverMes(actual, int.MinValue, minimo, maximo) == new DateTime(1, 1, 27) &&
            MYGCalendarioFechaModelo.MoverDias(actual, int.MaxValue, minimo, maximo) == maximo.Date &&
            MYGCalendarioFechaModelo.MoverDias(actual, int.MinValue, minimo, maximo) == minimo.Date,
            "La navegación extrema debe saturar sin desbordamientos ni excepciones.");
        pasa("Extremos de DateTime y desplazamientos int extremos no desbordan ni generan fechas inválidas");

        var utc = new DateTime(2026, 10, 27, 14, 45, 0, DateTimeKind.Utc);
        Exige(MYGCalendarioFechaModelo.InicioMes(utc) == new DateTime(2026, 10, 1) &&
            MYGCalendarioFechaModelo.InicioMes(utc).Kind == DateTimeKind.Utc &&
            MYGCalendarioFechaModelo.Dias(utc, DayOfWeek.Monday).All(d => d?.Kind == DateTimeKind.Utc) &&
            MYGCalendarioFechaModelo.Limitar(utc, utc.AddDays(1), utc.AddDays(2)).Kind == DateTimeKind.Utc &&
            MYGCalendarioFechaModelo.MoverMes(utc, 1, minimo, maximo).Kind == DateTimeKind.Utc &&
            MYGCalendarioFechaModelo.MoverDias(utc, 1, minimo, maximo).Kind == DateTimeKind.Utc,
            "El cálculo de fechas debe conservar Kind sin convertir zonas horarias ni la hora a otro día.");
        pasa("Modelo de calendario devuelve fechas sin hora y conserva Kind sin conversiones de zona horaria");

        Rechaza(() => MYGCalendarioFechaModelo.Dias(actual, (DayOfWeek)7));
        Rechaza(() => MYGCalendarioFechaModelo.Permitida(actual, hasta, desde));
        Rechaza(() => MYGCalendarioFechaModelo.Limitar(actual, hasta, desde));
        Rechaza(() => MYGCalendarioFechaModelo.MoverMes(actual, 1, hasta, desde));
        Rechaza(() => MYGCalendarioFechaModelo.MoverDias(actual, 1, hasta, desde));
        pasa("Modelo rechaza rangos invertidos y días de semana inválidos antes de calcular la grilla");
    }

    private static void Exige(bool condicion, string detalle)
    {
        if (!condicion) throw new Exception(detalle);
    }

    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (ArgumentException) { return; }
        throw new Exception("El modelo de calendario debe rechazar una entrada inválida.");
    }
}
