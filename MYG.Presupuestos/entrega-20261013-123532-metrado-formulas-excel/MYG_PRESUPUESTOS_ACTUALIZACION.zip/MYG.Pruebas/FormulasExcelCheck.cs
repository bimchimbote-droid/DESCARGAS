using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using MYG_2027;

static class FormulasExcelCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static MYGHojaMetrado Nueva() => new()
    { Nombre = "Fórmulas Excel", Filas = 20, Columnas = 12, CeldaTotal = "H20", FilasInmovilizadas = 0 };

    private static void Numero(MYGHojaMetrado hoja, string formula, decimal esperado, decimal tolerancia = 0)
    {
        hoja.Poner("L20", formula);
        decimal obtenido = new MYGHojaCalculo(hoja).Numero("L20");
        Exige(Math.Abs(obtenido - esperado) <= tolerancia,
            $"La fórmula {formula} produjo {obtenido} en lugar de {esperado}.");
    }

    public static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var sugerencias = MYGFuncionesExcel.Sugerir("s");
        Exige(sugerencias.Any(f => f.Nombre == "SEC") && sugerencias.Any(f => f.Nombre == "SI") &&
            sugerencias.Any(f => f.Nombre == "SI.ERROR") && sugerencias.Any(f => f.Nombre == "SUMA") &&
            sugerencias.All(f => (f.Nombre.StartsWith("S", StringComparison.OrdinalIgnoreCase) ||
                    f.NombreExcel.StartsWith("S", StringComparison.OrdinalIgnoreCase)) &&
                !string.IsNullOrWhiteSpace(f.NombreExcel) && !string.IsNullOrWhiteSpace(f.Descripcion) &&
                !string.IsNullOrWhiteSpace(f.Sintaxis)) &&
            MYGFuncionesExcel.Sugerir("funcion_inexistente").Count == 0,
            "El catálogo predictivo debe filtrar por prefijo sin distinguir mayúsculas e incluir nombre, descripción y sintaxis.");
        Exige(MYGFuncionesExcel.Sugerir("SI.").Any(f => f.Nombre == "SI.ND"),
            "La predicción debe reconocer nombres de función que contienen un punto.");
        pasa("Catálogo de fórmulas ofrece predicción por prefijo con funciones españolas, sintaxis y descripción");

        string literal = "=SI(CONTAR.SI(A1:A5;\"SUMA(\"\"x;y\"\";1,5)\")>0;REDONDEAR(1,25;1);0)";
        string esperadoLiteral = "=IF(COUNTIF(A1:A5,\"SUMA(\"\"x;y\"\";1,5)\")>0,ROUND(1.25,1),0)";
        Exige(MYGFuncionesExcel.AExcel(literal) == esperadoLiteral &&
            MYGFuncionesExcel.AExcel("=SUMA(1,5;2;3,25)") == "=SUM(1.5,2,3.25)" &&
            MYGFuncionesExcel.AExcel("=SUMA(A1,2)") == "=SUM(A1,2)" &&
            MYGFuncionesExcel.AExcel("=1,5+2") == "=1.5+2" &&
            MYGFuncionesExcel.AExcel("=SUM(1.5,2,3.25)") == "=SUM(1.5,2,3.25)",
            "La normalización para Excel debe traducir funciones y separadores sin modificar nombres, comas, puntos y comillas dentro de literales.");
        Exige(MYGFuncionesExcel.AExcel("=SI.ND(#N/D;10)") == "=IFNA(#N/A,10)" &&
            MYGFuncionesExcel.AExcel("=_xlfn.IFNA(#N/A,10)") == "=IFNA(#N/A,10)" &&
            MYGFuncionesExcel.AOpenXml("=SI.ND(#N/D;10)+SEC(0)") == "=_xlfn.IFNA(#N/A,10)+_xlfn.SEC(0)" &&
            MYGFuncionesExcel.AOpenXml("=SI.CONJUNTO(1;2;0;3)") == "=_xlfn.IFS(1,2,0,3)",
            "Las funciones modernas deben reconocer prefijos importados y exportar los prefijos OOXML que requiere Excel.");
        pasa("Normalización XLSX convierte nombres españoles y decimales con coma sin alterar literales ni fórmulas inglesas");

        var h = Nueva();
        Numero(h, "=SUMA(1,5;2;3,25)", 6.75m);
        Numero(h, "=SUMA(1,2,3)", 6m);
        Numero(h, "=SUMA(1.5,2,3.25)", 6.75m);
        Numero(h, "=SUM(1.5,2,3.25)", 6.75m);
        Numero(h, "=1,5+2", 3.5m);
        Numero(h, "=REDONDEAR(2,35;1)", 2.4m);
        Numero(h, "=REDONDEAR(-2,35;1)", -2.4m);
        Numero(h, "=REDONDEAR.MAS(-2,31;1)", -2.4m);
        Numero(h, "=REDONDEAR.MENOS(-2,39;1)", -2.3m);
        Numero(h, "=ENTERO(-2,1)", -3m);
        Numero(h, "=TRUNCAR(-2,987;2)", -2.98m);
        Numero(h, "=RESIDUO(-5;2)", 1m);
        Numero(h, "=COCIENTE(-7;3)", -2m);
        Numero(h, "=RAIZ(16)", 4m);
        Numero(h, "=POTENCIA(9;0,5)", 3m, 0.000000000001m);
        Numero(h, "=9^0,5", 3m, 0.000000000001m);
        Numero(h, "=-2^2", 4m);
        Numero(h, "=2^3^2", 64m);
        Numero(h, "=ABS(-4)+SIGNO(-7)", 3m);
        Numero(h, "=SENO(PI()/2)", 1m, 0.000000000001m);
        Numero(h, "=COS(0)+TAN(0)+SEC(0)+SECH(0)+SENOH(0)", 3m, 0.000000000001m);
        pasa("Fórmulas matemáticas admiten decimales españoles, redondeos de Excel, residuos y exponentes fraccionarios");

        Numero(h, "=SI(1;5;1/0)", 5m);
        Numero(h, "=SI(0;1/0;7)", 7m);
        Numero(h, "=SI.ERROR(6;1/0)", 6m);
        Numero(h, "=SI.ERROR(1/0;8)", 8m);
        Numero(h, "=SI.ND(6;1/0)", 6m);
        Numero(h, "=SI.ND(#N/A;9)", 9m);
        Numero(h, "=SI.ND(#N/D;10)", 10m);
        Numero(h, "=SI.ND(NOD();11)", 11m);
        Numero(h, "=SI.ERROR(ABS(1;2);9)", 9m);
        Numero(h, "=SI(1;2;Z1)", 2m);
        Numero(h, "=SI.ERROR(Z1;9)", 9m);
        Numero(h, "=_xlfn.IFNA(#N/A,12)", 12m);
        Numero(h, "=_xlfn.IFS(0,1,1,13)", 13m);
        Numero(h, "=_xlfn.SEC(0)", 1m);
        h.Poner("L20", "=SI.ND(1/0;6)");
        Exige(new MYGHojaCalculo(h).Mostrar("L20") == "#ERROR",
            "SI.ND debe conservar errores distintos de #N/A en vez de ocultar una división por cero.");
        Numero(h, "=Y(2>1;1=1)", 1m);
        Numero(h, "=O(2<1;1=1)", 1m);
        Numero(h, "=NO(1)", 0m);
        h.Poner("L20", "=SI(1;\"Sí; SUMA(1,5)\";1/0)");
        Exige(new MYGHojaCalculo(h).Mostrar("L20") == "Sí; SUMA(1,5)",
            "SI debe devolver texto literal y omitir la rama con error.");
        pasa("SI y manejo de errores evalúan solo la rama elegida; SI.ND conserva otros errores y SI puede devolver texto");

        h.Poner("A1", "2"); h.Poner("A2", "4"); h.Poner("A4", "texto"); h.Poner("A5", "0");
        h.Poner("B1", "A"); h.Poner("B2", "B"); h.Poner("B3", "Azul"); h.Poner("B4", "C"); h.Poner("B5", "A*");
        h.Poner("C1", "3"); h.Poner("C2", "5"); h.Poner("C3", "7"); h.Poner("C4", "texto"); h.Poner("C5", "11");
        Numero(h, "=ABS(A3)", 0m);
        Numero(h, "=REDONDEAR(A3;2)", 0m);
        Numero(h, "=SI(A3=\"\";5;6)", 5m);
        Numero(h, "=SI(VERDADERO=1;5;6)", 6m);
        Numero(h, "=SUMA(A1:A5)", 6m);
        Numero(h, "=PRODUCTO(A1:A4)", 8m);
        Numero(h, "=PRODUCTO(A1:A5)", 0m);
        Numero(h, "=CONTAR(A1:A5)", 3m);
        Numero(h, "=CONTARA(A1:A5)", 4m);
        Numero(h, "=PROMEDIO(A1:A5)", 2m);
        Numero(h, "=MIN(A1:A5)+MAX(A1:A5)", 4m);
        Numero(h, "=SUMAPRODUCTO(A1:A5;C1:C5)", 26m);
        Numero(h, "=SUMAR.SI(B1:B5;\"A*\";C1:C5)", 21m);
        Numero(h, "=CONTAR.SI(B1:B5;\"A*\")", 3m);
        Numero(h, "=CONTAR.SI(B1:B5;\"A~*\")", 1m);
        Numero(h, "=CONTAR.SI(C1:C3;\"<=5\")", 2m);
        Numero(h, "=SUMAR.SI(C1:C3;\"<=5\";A1:A3)", 6m);
        Numero(h, "=PROMEDIO.SI(C1:C3;\"<=5\";A1:A3)", 3m);
        Numero(h, "=SUMAR.SI.CONJUNTO(C1:C5;B1:B5;\"A*\";A1:A5;\">0\")", 3m);
        Numero(h, "=CONTAR.SI.CONJUNTO(B1:B5;\"A*\";C1:C5;\">=7\")", 2m);
        h.Poner("A6", "=1/0");
        Numero(h, "=SI.ERROR(A6;7)", 7m);
        h.Poner("A8", "=NOD()");
        Numero(h, "=SI.ND(A8;7)", 7m);
        Numero(h, "=CONTAR(A6:A7)", 0m);
        Numero(h, "=CONTARA(A6:A7)", 1m);
        h.Poner("L20", "=SUMA(A6:A7)");
        Exige(new MYGHojaCalculo(h).Mostrar("L20") == "#ERROR",
            "Los errores en rangos deben propagarse a la suma aunque las funciones de conteo puedan omitirlos o contarlos.");
        var circular = Nueva();
        circular.Poner("G16", "=CONTAR(G16)");
        Exige(new MYGHojaCalculo(circular).Mostrar("G16") == "#ERROR",
            "El conteo no debe ocultar una referencia circular como si fuera un error ordinario en un rango.");
        circular.Poner("G16", "=SI.ERROR(G16;7)");
        Exige(new MYGHojaCalculo(circular).Mostrar("G16") == "#ERROR",
            "SI.ERROR no debe ocultar una referencia circular devolviendo su valor alternativo.");
        pasa("Rangos ignoran texto y vacíos según la función; criterios numéricos, comodines y criterios conjuntos conservan semántica Excel");

        VerificarIntercambio(carpeta, h, pasa);
    }

    private static void VerificarIntercambio(string carpeta, MYGHojaMetrado h, Action<string> pasa)
    {
        h.Poner("G1", "=SUMA(A1:A5)");
        h.Poner("G2", "=REDONDEAR.MAS(1,25;1)");
        h.Poner("G3", "=SUMAR.SI(B1:B5;\"A*\";C1:C5)");
        h.Poner("G4", "=SI.ERROR(1/0;9)");
        h.Poner("G5", "=SI(A1>0;\"Sí; SUMA(1,5)\";\"No\")");
        h.Poner("G6", "=FUNCION_NO_SOPORTADA(A1)");
        h.Poner("G7", "=Y(A1>0;A2>0)");
        h.Poner("G8", "=SI.ND(#N/D;12)");
        h.Poner("G9", "=SEC(0)");
        h.Poner("G10", "=SI.CONJUNTO(0;1;1;13)");
        h.Poner("H20", "=SUMA(G1:G4)");
        h.Poner("L20", "");
        string original = h.Celdas["G2"].Contenido;
        string ruta = Path.Combine(carpeta, "Metrado formulas Excel.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { h });
        Exige(h.Celdas["G2"].Contenido == original,
            "Exportar no debe sustituir las fórmulas originales de la hoja en memoria.");

        using (var z = ZipFile.OpenRead(ruta))
        {
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            using var flujo = z.GetEntry("xl/worksheets/sheet1.xml").Open();
            var xml = XDocument.Load(flujo);
            XElement Celda(string direccion) => xml.Descendants(s + "c").Single(c => (string)c.Attribute("r") == direccion);
            void Formula(string direccion, string esperada, decimal valor)
            {
                var c = Celda(direccion);
                Exige(c.Element(s + "f")?.Value == esperada &&
                    decimal.Parse(c.Element(s + "v").Value, CultureInfo.InvariantCulture) == valor &&
                    (string)c.Attribute("t") != "e",
                    "XLSX debe conservar en " + direccion + " la fórmula inglesa y su valor calculado.");
            }
            Formula("G1", "SUM(A1:A5)", 6m);
            Formula("G2", "ROUNDUP(1.25,1)", 1.3m);
            Formula("G3", "SUMIF(B1:B5,\"A*\",C1:C5)", 21m);
            Formula("G4", "IFERROR(1/0,9)", 9m);
            Formula("G8", "_xlfn.IFNA(#N/A,12)", 12m);
            Formula("G9", "_xlfn.SEC(0)", 1m);
            Formula("G10", "_xlfn.IFS(0,1,1,13)", 13m);
            Formula("H20", "SUM(G1:G4)", 37.3m);
            Exige(Celda("G5").Element(s + "f")?.Value == "IF(A1>0,\"Sí; SUMA(1,5)\",\"No\")" &&
                (string)Celda("G5").Attribute("t") == "str" && Celda("G5").Element(s + "v")?.Value == "Sí; SUMA(1,5)",
                "La fórmula que devuelve texto debe usar caché de tipo str y conservar sus literales intactos.");
            Exige(Celda("G6").Element(s + "f")?.Value == "FUNCION_NO_SOPORTADA(A1)" &&
                (string)Celda("G6").Attribute("t") == "e",
                "Una fórmula no soportada debe conservarse como fórmula con error, sin reemplazarla por un número fijo.");
            Exige(Celda("G7").Element(s + "f")?.Value == "AND(A1>0,A2>0)" &&
                (string)Celda("G7").Attribute("t") == "b" && Celda("G7").Element(s + "v")?.Value == "1",
                "Una fórmula lógica debe conservar una caché booleana compatible con Excel.");
        }

        var importada = MYGExcelPresupuestos.Importar(ruta, h.Nombre, h.CeldaTotal);
        var motor = new MYGHojaCalculo(importada);
        Exige(importada.Celdas["G2"].Contenido == "=ROUNDUP(1.25,1)" &&
            importada.Celdas["G3"].Contenido == "=SUMIF(B1:B5,\"A*\",C1:C5)" &&
            motor.Numero("H20") == 37.3m && motor.Mostrar("G5") == "Sí; SUMA(1,5)" &&
            motor.Mostrar("G6") == "#ERROR" && motor.Numero("G7") == 1m &&
            motor.Numero("G8") == 12m && motor.Numero("G9") == 1m && motor.Numero("G10") == 13m,
            "La reimportación debe conservar fórmulas ejecutables, textos calculados y errores sin usar cachés como valores fijos.");
        importada.Poner("A1", "3");
        Exige(new MYGHojaCalculo(importada).Numero("H20") == 38.3m,
            "Editar una entrada después de importar debe recalcular el total a partir de fórmulas, sin reutilizar el valor en caché XLSX.");
        pasa("XLSX conserva fórmulas Excel, cachés numéricas y de texto, errores y recálculo tras reimportar y editar datos");
    }
}
