using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private TextBox editorAutocompletadoHoja;
    private MYGListaFuncionesHoja listaFuncionesHoja;
    private MYGFiltroFuncionesHoja filtroFuncionesHoja;
    private int inicioFuncionHoja, finFuncionHoja;
    private bool insertandoFuncionHoja;
    private string sugerenciaDescartadaHoja;
    private Form propietarioFuncionesHoja;

    internal IReadOnlyList<MYGFuncionExcel> EstadoAutocompletadoHoja =>
        listaFuncionesHoja?.Visible == true ? listaFuncionesHoja.Funciones : Array.Empty<MYGFuncionExcel>();

    private void PrepararAutocompletadoHoja()
    {
        hoja.EditingControlShowing += MostrarEditorAutocompletadoHoja;
        hoja.CellEndEdit += TerminarAutocompletadoHoja;
        hoja.Scroll += ReubicarAutocompletadoHoja;
        formula.Enter += EntrarAutocompletadoBarraHoja;
        formula.TextChanged += CambiarTextoAutocompletadoHoja;
        formula.KeyUp += MoverCursorAutocompletadoHoja;
        formula.MouseUp += MoverCursorAutocompletadoHoja;
        formula.Leave += SalirAutocompletadoHoja;
        paginaExcel.VisibleChanged += CambiarVisibilidadAutocompletadoHoja;
        detalle.SelectedIndexChanged += CambiarVisibilidadAutocompletadoHoja;
        LocationChanged += ReubicarAutocompletadoHoja;
        SizeChanged += ReubicarAutocompletadoHoja;
        filtroFuncionesHoja = new MYGFiltroFuncionesHoja(this);
        Application.AddMessageFilter(filtroFuncionesHoja);
        Disposed += LiberarAutocompletadoHoja;
    }

    private void MostrarEditorAutocompletadoHoja(object sender, DataGridViewEditingControlShowingEventArgs e)
    {
        DesvincularEditorAutocompletadoHoja();
        CerrarAutocompletadoHoja();
        if (cargando || !HayPartida || e.Control is not TextBox editor) return;
        editorAutocompletadoHoja = editor;
        editor.TextChanged += CambiarTextoAutocompletadoHoja;
        editor.KeyDown += TeclaEditorAutocompletadoHoja;
        editor.KeyUp += MoverCursorAutocompletadoHoja;
        editor.MouseUp += MoverCursorAutocompletadoHoja;
        editor.Leave += SalirAutocompletadoHoja;
        ActualizarAutocompletadoHoja(editor);
    }

    private void EntrarAutocompletadoBarraHoja(object sender, EventArgs e)
    {
        CerrarAutocompletadoHoja();
        ActualizarAutocompletadoHoja(formula);
    }

    private void CambiarTextoAutocompletadoHoja(object sender, EventArgs e)
    {
        if (!insertandoFuncionHoja && sender is TextBox editor) ActualizarAutocompletadoHoja(editor);
    }

    private void MoverCursorAutocompletadoHoja(object sender, EventArgs e)
    {
        if (sender is TextBox editor) ActualizarAutocompletadoHoja(editor);
    }

    private void TeclaEditorAutocompletadoHoja(object sender, KeyEventArgs e)
    {
        if (!ProcesarTeclaAutocompletadoHoja(e.KeyData)) return;
        e.Handled = e.SuppressKeyPress = true;
    }

    private void SalirAutocompletadoHoja(object sender, EventArgs e) => CerrarAutocompletadoHoja();

    private void TerminarAutocompletadoHoja(object sender, DataGridViewCellEventArgs e)
    {
        CerrarAutocompletadoHoja();
        DesvincularEditorAutocompletadoHoja();
    }

    private void CambiarVisibilidadAutocompletadoHoja(object sender, EventArgs e)
    {
        if (!paginaExcel.Visible || detalle.SelectedTab != paginaExcel) CerrarAutocompletadoHoja();
    }

    private TextBox EditorActivoAutocompletadoHoja() => formula.Focused ? formula :
        editorAutocompletadoHoja?.Focused == true && hoja.IsCurrentCellInEditMode ? editorAutocompletadoHoja : null;

    private void ActualizarAutocompletadoHoja(TextBox editor)
    {
        if (cargando || actualizandoFormulaHoja || !HayPartida || editor != EditorActivoAutocompletadoHoja() ||
            !paginaExcel.Visible || !BuscarTokenFuncionHoja(editor.Text, editor.SelectionStart, out int inicio, out int fin, out string prefijo) ||
            editor.SelectionLength != 0)
        { CerrarAutocompletadoHoja(false); return; }
        string estado = editor.Text + "\n" + editor.SelectionStart;
        if (estado == sugerenciaDescartadaHoja) return;
        sugerenciaDescartadaHoja = null;
        var funciones = MYGFuncionesExcel.Sugerir(prefijo);
        if (funciones.Count == 0) { CerrarAutocompletadoHoja(false); return; }
        inicioFuncionHoja = inicio; finFuncionHoja = fin;
        if (listaFuncionesHoja == null)
        {
            listaFuncionesHoja = new MYGListaFuncionesHoja();
            listaFuncionesHoja.Aceptar += InsertarFuncionAutocompletadoHoja;
        }
        listaFuncionesHoja.Actualizar(funciones);
        PosicionarAutocompletadoHoja(editor);
        if (!listaFuncionesHoja.Visible)
        {
            var propietario = FindForm();
            if (propietario == null || !propietario.Visible) return;
            if (propietarioFuncionesHoja != propietario)
            {
                DesvincularPropietarioAutocompletadoHoja();
                propietarioFuncionesHoja = propietario;
                propietario.Deactivate += SalirAutocompletadoHoja;
                propietario.LocationChanged += ReubicarAutocompletadoHoja;
                propietario.SizeChanged += ReubicarAutocompletadoHoja;
            }
            listaFuncionesHoja.Show(propietario);
        }
    }

    // Sólo los identificadores de una fórmula fuera de literales pueden ser
    // funciones. El token completo permite sustituir también con el cursor en medio.
    internal static bool BuscarTokenFuncionHoja(string texto, int cursor, out int inicio, out int fin, out string prefijo)
    {
        inicio = fin = Math.Clamp(cursor, 0, texto?.Length ?? 0); prefijo = "";
        if (string.IsNullOrEmpty(texto) || !texto.TrimStart().StartsWith('=')) return false;
        bool literal = false, nombreHoja = false;
        for (int i = 0; i < inicio; i++)
        {
            if (texto[i] == '"' && !nombreHoja)
            {
                if (literal && i + 1 < inicio && texto[i + 1] == '"') { i++; continue; }
                literal = !literal;
            }
            else if (texto[i] == '\'' && !literal)
            {
                if (nombreHoja && i + 1 < inicio && texto[i + 1] == '\'') { i++; continue; }
                nombreHoja = !nombreHoja;
            }
        }
        if (literal || nombreHoja) return false;
        int posicion = inicio;
        while (inicio > 0 && EsCaracterFuncionHoja(texto[inicio - 1])) inicio--;
        if (inicio == posicion || !char.IsLetter(texto[inicio]) ||
            inicio > 0 && (texto[inicio - 1] == '$' || texto[inicio - 1] == '!' || texto[inicio - 1] == ':')) return false;
        while (fin < texto.Length && EsCaracterFuncionHoja(texto[fin])) fin++;
        prefijo = texto[inicio..posicion];
        return true;
    }

    private static bool EsCaracterFuncionHoja(char c) => char.IsLetterOrDigit(c) || c is '.' or '_';

    private bool ProcesarTeclaAutocompletadoHoja(Keys tecla)
    {
        if (listaFuncionesHoja?.Visible != true || EditorActivoAutocompletadoHoja() == null ||
            (tecla & (Keys.Control | Keys.Alt)) != 0) return false;
        switch (tecla & Keys.KeyCode)
        {
            case Keys.Down: listaFuncionesHoja.Mover(1); return true;
            case Keys.Up: listaFuncionesHoja.Mover(-1); return true;
            case Keys.Tab:
            case Keys.Enter: InsertarFuncionAutocompletadoHoja(); return true;
            case Keys.Escape:
                var editor = EditorActivoAutocompletadoHoja();
                sugerenciaDescartadaHoja = editor.Text + "\n" + editor.SelectionStart;
                CerrarAutocompletadoHoja(false); return true;
            default: return false;
        }
    }

    private void InsertarFuncionAutocompletadoHoja()
    {
        var editor = EditorActivoAutocompletadoHoja();
        var funcion = listaFuncionesHoja?.Seleccionada;
        if (editor == null || funcion == null || !BuscarTokenFuncionHoja(editor.Text, editor.SelectionStart,
            out int inicio, out int fin, out _) || inicio != inicioFuncionHoja || fin != finFuncionHoja) return;
        int siguiente = fin;
        while (siguiente < editor.TextLength && char.IsWhiteSpace(editor.Text[siguiente])) siguiente++;
        bool parentesisExistente = siguiente < editor.TextLength && editor.Text[siguiente] == '(';
        string insertar = funcion.Nombre + (parentesisExistente ? "" : "(");
        insertandoFuncionHoja = true;
        try
        {
            editor.Select(inicio, fin - inicio);
            editor.SelectedText = insertar;
            editor.SelectionStart = parentesisExistente ? inicio + insertar.Length + siguiente - fin + 1 : inicio + insertar.Length;
            editor.SelectionLength = 0;
        }
        finally { insertandoFuncionHoja = false; }
        CerrarAutocompletadoHoja();
        editor.Focus();
    }

    private void CerrarAutocompletadoHoja(bool reiniciar = true)
    {
        if (listaFuncionesHoja?.Visible == true) listaFuncionesHoja.Hide();
        if (reiniciar) sugerenciaDescartadaHoja = null;
    }

    private void ReubicarAutocompletadoHoja(object sender, EventArgs e)
    {
        if (listaFuncionesHoja?.Visible != true) return;
        var editor = EditorActivoAutocompletadoHoja();
        if (editor == null) CerrarAutocompletadoHoja();
        else PosicionarAutocompletadoHoja(editor);
    }

    private void PosicionarAutocompletadoHoja(TextBox editor)
    {
        Point cursor = editor.GetPositionFromCharIndex(inicioFuncionHoja);
        Point punto = editor.PointToScreen(new Point(cursor.X, editor.ClientSize.Height + 2));
        var area = Screen.FromControl(editor).WorkingArea;
        int x = Math.Max(area.Left, Math.Min(punto.X, area.Right - listaFuncionesHoja.Width));
        int y = punto.Y + listaFuncionesHoja.Height <= area.Bottom ? punto.Y :
            editor.PointToScreen(Point.Empty).Y - listaFuncionesHoja.Height - 2;
        listaFuncionesHoja.Location = new Point(x, Math.Max(area.Top, y));
    }

    private void DesvincularEditorAutocompletadoHoja()
    {
        if (editorAutocompletadoHoja == null) return;
        editorAutocompletadoHoja.TextChanged -= CambiarTextoAutocompletadoHoja;
        editorAutocompletadoHoja.KeyDown -= TeclaEditorAutocompletadoHoja;
        editorAutocompletadoHoja.KeyUp -= MoverCursorAutocompletadoHoja;
        editorAutocompletadoHoja.MouseUp -= MoverCursorAutocompletadoHoja;
        editorAutocompletadoHoja.Leave -= SalirAutocompletadoHoja;
        editorAutocompletadoHoja = null;
    }

    private void LiberarAutocompletadoHoja(object sender, EventArgs e)
    {
        DesvincularEditorAutocompletadoHoja();
        Application.RemoveMessageFilter(filtroFuncionesHoja);
        DesvincularPropietarioAutocompletadoHoja();
        listaFuncionesHoja?.Dispose();
    }

    private void DesvincularPropietarioAutocompletadoHoja()
    {
        if (propietarioFuncionesHoja == null) return;
        propietarioFuncionesHoja.Deactivate -= SalirAutocompletadoHoja;
        propietarioFuncionesHoja.LocationChanged -= ReubicarAutocompletadoHoja;
        propietarioFuncionesHoja.SizeChanged -= ReubicarAutocompletadoHoja;
        propietarioFuncionesHoja = null;
    }

    // DataGridView procesa Tab, Enter y flechas antes de KeyDown. El filtro
    // consume esas teclas sólo mientras la lista y el editor están activos.
    private sealed class MYGFiltroFuncionesHoja(MYGPanelPresupuesto panel) : IMessageFilter
    {
        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg != 0x100 || panel.IsDisposed) return false;
            var editor = panel.EditorActivoAutocompletadoHoja();
            return editor != null && m.HWnd == editor.Handle &&
                panel.ProcesarTeclaAutocompletadoHoja((Keys)m.WParam.ToInt32() | ModifierKeys);
        }
    }
}

// Ventana sin activación: elegir una función no confirma la celda ni roba el
// foco del editor, como la lista de funciones de Excel.
internal sealed class MYGListaFuncionesHoja : Form
{
    private readonly MYGListaFuncionesSinFoco lista = new();
    private readonly Label descripcion = new() { Dock = DockStyle.Fill, Padding = new(9, 7, 7, 7) };
    internal event Action Aceptar;
    internal IReadOnlyList<MYGFuncionExcel> Funciones { get; private set; } = Array.Empty<MYGFuncionExcel>();
    internal MYGFuncionExcel Seleccionada => lista.SelectedIndex >= 0 ? Funciones[lista.SelectedIndex] : null;
    protected override bool ShowWithoutActivation => true;
    protected override CreateParams CreateParams
    {
        get { var p = base.CreateParams; p.ExStyle |= 0x08000000 | 0x00000080; return p; }
    }

    internal MYGListaFuncionesHoja()
    {
        Name = "metrado_lista_funciones"; ShowInTaskbar = false; FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual; AutoScaleMode = AutoScaleMode.Dpi; Padding = new(1);
        Font = new Font("Segoe UI", 9f); BackColor = SystemColors.WindowFrame;
        var contenido = new Panel { Dock = DockStyle.Fill };
        lista.Dock = DockStyle.Left; lista.Width = 215; lista.BorderStyle = BorderStyle.None;
        lista.DrawMode = DrawMode.OwnerDrawFixed; lista.IntegralHeight = false; lista.TabStop = false;
        lista.Name = "metrado_funciones"; descripcion.Name = "metrado_descripcion_funcion";
        lista.DrawItem += DibujarFuncion;
        lista.SelectedIndexChanged += (_, _) => ActualizarDescripcion();
        lista.MouseUp += (_, e) => { if (e.Button == MouseButtons.Left && lista.IndexFromPoint(e.Location) >= 0) Aceptar?.Invoke(); };
        contenido.Controls.Add(descripcion); contenido.Controls.Add(lista); Controls.Add(contenido);
    }

    internal void Actualizar(IReadOnlyList<MYGFuncionExcel> funciones)
    {
        string seleccionada = Seleccionada?.Nombre;
        bool mismas = Funciones.Select(x => x.Nombre).SequenceEqual(funciones.Select(x => x.Nombre));
        Funciones = funciones;
        Color fondo = MYG2027_TemaComercial.Superficie, texto = MYG2027_TemaComercial.Texto;
        lista.BackColor = descripcion.BackColor = fondo; lista.ForeColor = descripcion.ForeColor = texto;
        lista.ItemHeight = Math.Max(20, Font.Height + 5);
        if (!mismas)
        {
            lista.BeginUpdate();
            try
            {
                lista.Items.Clear(); lista.Items.AddRange(funciones.Select(x => (object)x.Nombre).ToArray());
                int indice = funciones.ToList().FindIndex(x => x.Nombre == seleccionada);
                lista.SelectedIndex = indice < 0 ? 0 : indice;
            }
            finally { lista.EndUpdate(); }
        }
        ClientSize = new Size((int)Math.Round(535 * DeviceDpi / 96d), Math.Max(88, Math.Min(8, funciones.Count) * lista.ItemHeight + 2));
        lista.Width = (int)Math.Round(215 * DeviceDpi / 96d);
        ActualizarDescripcion(); lista.Invalidate();
    }

    internal void Mover(int salto)
    {
        if (Funciones.Count == 0) return;
        lista.SelectedIndex = Math.Clamp(lista.SelectedIndex + salto, 0, Funciones.Count - 1);
    }

    private void ActualizarDescripcion()
    {
        var funcion = Seleccionada;
        descripcion.Text = funcion == null ? "" : funcion.Descripcion + "\n\n" + funcion.Sintaxis;
    }

    private void DibujarFuncion(object sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= Funciones.Count) return;
        bool seleccionada = (e.State & DrawItemState.Selected) != 0;
        Color fondo = seleccionada ? Color.FromArgb(0, 112, 192) : lista.BackColor;
        Color texto = seleccionada ? Color.White : lista.ForeColor;
        using var pincel = new SolidBrush(fondo);
        e.Graphics.FillRectangle(pincel, e.Bounds);
        var icono = new Rectangle(e.Bounds.Left + 3, e.Bounds.Top, 29, e.Bounds.Height);
        TextRenderer.DrawText(e.Graphics, "ƒx", Font, icono, texto, TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        var nombre = new Rectangle(e.Bounds.Left + 33, e.Bounds.Top, e.Bounds.Width - 35, e.Bounds.Height);
        TextRenderer.DrawText(e.Graphics, Funciones[e.Index].Nombre, Font, nombre, texto,
            TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x21) { m.Result = new IntPtr(3); return; }
        base.WndProc(ref m);
    }

    private sealed class MYGListaFuncionesSinFoco : ListBox
    {
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x21) { m.Result = new IntPtr(3); return; }
            // El ListBox nativo toma el foco al recibir un clic aunque su
            // ventana no se active. Seleccionamos sin reenviar ese mensaje.
            if (m.Msg is 0x201 or 0x203 or 0x202)
            {
                int datos = m.LParam.ToInt32();
                var punto = new Point((short)(datos & 0xffff), (short)(datos >> 16));
                int indice = IndexFromPoint(punto);
                if (indice >= 0) SelectedIndex = indice;
                if (m.Msg == 0x202) OnMouseUp(new MouseEventArgs(MouseButtons.Left, 1, punto.X, punto.Y, 0));
                return;
            }
            base.WndProc(ref m);
        }
    }
}
