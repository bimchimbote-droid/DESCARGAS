using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MYG_2027
{
    public sealed class MYGFuncionExcel
    {
        public string Nombre { get; }
        public string NombreExcel { get; }
        public string Descripcion { get; }
        public string Sintaxis { get; }
        internal MYGFuncionExcel(string nombre, string excel, string descripcion, string argumentos)
        { Nombre = nombre; NombreExcel = excel; Descripcion = descripcion; Sintaxis = nombre + "(" + argumentos + ")"; }
    }

    /// <summary>Funciones que calcula el editor. Los nombres ingleses también se aceptan al escribir.</summary>
    public static class MYGFuncionesExcel
    {
        private static MYGFuncionExcel F(string nombre, string excel, string descripcion, string argumentos) => new(nombre, excel, descripcion, argumentos);
        public static IReadOnlyList<MYGFuncionExcel> Funciones { get; } = Array.AsReadOnly(new[]
        {
            F("ABS", "ABS", "Devuelve el valor absoluto de un número.", "número"),
            F("ACOS", "ACOS", "Devuelve el arco coseno, en radianes.", "número"),
            F("ASENO", "ASIN", "Devuelve el arco seno, en radianes.", "número"),
            F("ATAN", "ATAN", "Devuelve el arco tangente, en radianes.", "número"),
            F("COCIENTE", "QUOTIENT", "Devuelve la parte entera de una división.", "numerador; denominador"),
            F("CONTAR", "COUNT", "Cuenta los números de un rango o lista de valores.", "valor1; [valor2]; ..."),
            F("CONTARA", "COUNTA", "Cuenta las celdas y valores que no están vacíos.", "valor1; [valor2]; ..."),
            F("CONTAR.BLANCO", "COUNTBLANK", "Cuenta las celdas vacías de un rango.", "rango"),
            F("CONTAR.SI", "COUNTIF", "Cuenta las celdas que cumplen un criterio.", "rango; criterio"),
            F("CONTAR.SI.CONJUNTO", "COUNTIFS", "Cuenta las celdas que cumplen todos los criterios.", "rango1; criterio1; [rango2; criterio2]; ..."),
            F("COS", "COS", "Devuelve el coseno de un ángulo en radianes.", "número"),
            F("COSH", "COSH", "Devuelve el coseno hiperbólico de un número.", "número"),
            F("ENTERO", "INT", "Redondea un número hacia el entero inferior.", "número"),
            F("EXP", "EXP", "Devuelve e elevado a la potencia indicada.", "número"),
            F("FALSO", "FALSE", "Devuelve el valor lógico falso.", ""),
            F("GRADOS", "DEGREES", "Convierte radianes en grados.", "ángulo"),
            F("LN", "LN", "Devuelve el logaritmo natural de un número.", "número"),
            F("LOG", "LOG", "Devuelve el logaritmo en la base indicada (10 por defecto).", "número; [base]"),
            F("LOG10", "LOG10", "Devuelve el logaritmo en base 10.", "número"),
            F("MAX", "MAX", "Devuelve el mayor número de una lista o rango.", "número1; [número2]; ..."),
            F("MIN", "MIN", "Devuelve el menor número de una lista o rango.", "número1; [número2]; ..."),
            F("NO", "NOT", "Invierte un valor lógico.", "valor_lógico"),
            F("NOD", "NA", "Devuelve el error de valor no disponible (#N/A).", ""),
            F("O", "OR", "Devuelve verdadero si algún argumento es verdadero.", "valor_lógico1; [valor_lógico2]; ..."),
            F("PI", "PI", "Devuelve el número pi.", ""),
            F("POTENCIA", "POWER", "Eleva un número a una potencia.", "número; potencia"),
            F("PRODUCTO", "PRODUCT", "Multiplica los números de una lista o rango.", "número1; [número2]; ..."),
            F("PROMEDIO", "AVERAGE", "Devuelve la media aritmética de los números.", "número1; [número2]; ..."),
            F("PROMEDIO.SI", "AVERAGEIF", "Promedia las celdas que cumplen un criterio.", "rango; criterio; [rango_promedio]"),
            F("PROMEDIO.SI.CONJUNTO", "AVERAGEIFS", "Promedia las celdas que cumplen todos los criterios.", "rango_promedio; rango1; criterio1; ..."),
            F("RADIANES", "RADIANS", "Convierte grados en radianes.", "ángulo"),
            F("RAIZ", "SQRT", "Devuelve la raíz cuadrada de un número.", "número"),
            F("REDONDEAR", "ROUND", "Redondea un número a los decimales indicados.", "número; núm_decimales"),
            F("REDONDEAR.MAS", "ROUNDUP", "Redondea alejándose de cero.", "número; núm_decimales"),
            F("REDONDEAR.MENOS", "ROUNDDOWN", "Redondea acercándose a cero.", "número; núm_decimales"),
            F("RESIDUO", "MOD", "Devuelve el resto de una división con el signo del divisor.", "número; divisor"),
            F("SEC", "SEC", "Devuelve la secante de un ángulo en radianes.", "número"),
            F("SECH", "SECH", "Devuelve la secante hiperbólica de un número.", "número"),
            F("SEGUNDO", "SECOND", "Devuelve los segundos (0–59) de una hora de Excel.", "núm_de_serie"),
            F("SENO", "SIN", "Devuelve el seno de un ángulo en radianes.", "número"),
            F("SENOH", "SINH", "Devuelve el seno hiperbólico de un número.", "número"),
            F("SI", "IF", "Devuelve un valor según se cumpla o no una condición.", "prueba_lógica; valor_si_verdadero; [valor_si_falso]"),
            F("SI.CONJUNTO", "IFS", "Devuelve el valor asociado a la primera condición verdadera.", "prueba_lógica1; valor1; [prueba_lógica2; valor2]; ..."),
            F("SI.ERROR", "IFERROR", "Devuelve un valor alternativo si la fórmula produce un error.", "valor; valor_si_error"),
            F("SI.ND", "IFNA", "Devuelve un valor alternativo para el error #N/A.", "valor; valor_si_nd"),
            F("SIGNO", "SIGN", "Devuelve -1, 0 o 1 según el signo del número.", "número"),
            F("SUMA", "SUM", "Suma los números de una lista o rango.", "número1; [número2]; ..."),
            F("SUMAPRODUCTO", "SUMPRODUCT", "Suma los productos de rangos de igual tamaño.", "rango1; [rango2]; ..."),
            F("SUMAR.SI", "SUMIF", "Suma las celdas que cumplen un criterio.", "rango; criterio; [rango_suma]"),
            F("SUMAR.SI.CONJUNTO", "SUMIFS", "Suma las celdas que cumplen todos los criterios.", "rango_suma; rango1; criterio1; ..."),
            F("TAN", "TAN", "Devuelve la tangente de un ángulo en radianes.", "número"),
            F("TANH", "TANH", "Devuelve la tangente hiperbólica de un número.", "número"),
            F("TRUNCAR", "TRUNC", "Elimina decimales de un número sin redondearlo.", "número; [núm_decimales]"),
            F("VERDADERO", "TRUE", "Devuelve el valor lógico verdadero.", ""),
            F("Y", "AND", "Devuelve verdadero si todos los argumentos son verdaderos.", "valor_lógico1; [valor_lógico2]; ...")
        }.OrderBy(f => f.Nombre, StringComparer.OrdinalIgnoreCase).ToArray());
        private static readonly Dictionary<string, string> Nombres = Funciones.SelectMany(f => new[] { (f.Nombre, f.NombreExcel), (f.NombreExcel, f.NombreExcel) })
            .GroupBy(x => x.Item1, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.First().Item2, StringComparer.OrdinalIgnoreCase);

        /// <summary>Predicción por prefijo español o inglés; no incluye funciones que el editor no calcula.</summary>
        public static IReadOnlyList<MYGFuncionExcel> Sugerir(string prefijo)
        {
            prefijo = (prefijo ?? "").Trim().TrimStart('=');
            return Funciones.Where(f => f.Nombre.StartsWith(prefijo, StringComparison.OrdinalIgnoreCase) ||
                f.NombreExcel.StartsWith(prefijo, StringComparison.OrdinalIgnoreCase)).ToArray();
        }

        /// <summary>Convierte a la sintaxis invariante de XLSX conservando referencias, texto literal y el signo =.</summary>
        public static string AExcel(string formula) => Convertir(formula, false);

        /// <summary>Sintaxis XLSX, incluidos los prefijos exigidos por funciones posteriores a Excel 2007.</summary>
        public static string AOpenXml(string formula) => Convertir(formula, true);

        private static string Convertir(string formula, bool openXml)
        {
            formula ??= "";
            string fuera = FueraDeTexto(formula);
            // Los nombres locales usan ; para argumentos y coma decimal. Los nombres
            // ingleses conservan la coma de argumentos; en funciones unarias, 1,5
            // se interpreta como un decimal porque dos argumentos nunca serían válidos.
            var nombresLocales = Funciones.Where(f => f.Nombre != f.NombreExcel).Select(f => f.Nombre).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var unarias = new HashSet<string>(new[] { "ABS", "INT", "SIGN", "SQRT", "SIN", "COS", "TAN", "SEC", "SECH", "SINH", "COSH", "TANH", "ASIN", "ACOS", "ATAN", "LN", "LOG10", "EXP", "RADIANS", "DEGREES", "SECOND" }, StringComparer.OrdinalIgnoreCase);
            bool decimalesConComa = fuera.Contains(';');
            var contextos = new Stack<bool>(); string funcionPendiente = null;
            var salida = new StringBuilder();
            for (int i = 0; i < formula.Length;)
            {
                char c = formula[i];
                if (c == '#' && formula[i..].StartsWith("#N/D", StringComparison.OrdinalIgnoreCase))
                { salida.Append("#N/A"); i += 4; continue; }
                if (c is '"' or '\'')
                {
                    char comilla = c; salida.Append(c); i++;
                    while (i < formula.Length)
                    {
                        c = formula[i++]; salida.Append(c);
                        if (c != comilla) continue;
                        if (i < formula.Length && formula[i] == comilla) { salida.Append(formula[i++]); continue; }
                        break;
                    }
                    continue;
                }
                if (char.IsLetter(c) || c == '_')
                {
                    int inicio = i++;
                    while (i < formula.Length && (char.IsLetterOrDigit(formula[i]) || formula[i] is '_' or '.')) i++;
                    string palabra = formula[inicio..i]; int siguiente = i;
                    while (siguiente < formula.Length && char.IsWhiteSpace(formula[siguiente])) siguiente++;
                    string nombre = palabra.StartsWith("_xlfn.", StringComparison.OrdinalIgnoreCase) ? palabra[6..] : palabra;
                    if (siguiente < formula.Length && formula[siguiente] == '(') funcionPendiente = nombre;
                    if ((siguiente < formula.Length && formula[siguiente] == '(' || nombre.ToUpperInvariant() is "VERDADERO" or "FALSO") &&
                        Nombres.TryGetValue(nombre, out string ingles))
                        salida.Append(openXml && ingles is "IFS" or "IFNA" or "SEC" or "SECH" ? "_xlfn." + ingles : ingles);
                    else salida.Append(palabra);
                    continue;
                }
                if (c == '(')
                {
                    contextos.Push(decimalesConComa || funcionPendiente != null && (nombresLocales.Contains(funcionPendiente) || unarias.Contains(funcionPendiente)) ||
                        funcionPendiente == null && (contextos.Count == 0 || contextos.Peek()));
                    funcionPendiente = null;
                }
                else if (c == ')' && contextos.Count != 0) contextos.Pop();
                if (c == ';') salida.Append(',');
                else if (c == ',' && (decimalesConComa || contextos.Count == 0 || contextos.Peek()) && EsComaDecimal(formula, i)) salida.Append('.');
                else salida.Append(c);
                i++;
            }
            return salida.ToString();
        }
        private static bool EsComaDecimal(string formula, int indice)
        {
            if (indice == 0 || indice + 1 >= formula.Length || !char.IsDigit(formula[indice - 1]) || !char.IsDigit(formula[indice + 1])) return false;
            int inicio = indice, fin = indice;
            while (inicio > 0 && (char.IsDigit(formula[inicio - 1]) || formula[inicio - 1] is '.' or ',')) inicio--;
            while (fin + 1 < formula.Length && (char.IsDigit(formula[fin + 1]) || formula[fin + 1] is '.' or ',')) fin++;
            if (inicio > 0 && (char.IsLetter(formula[inicio - 1]) || formula[inicio - 1] is '$' or '_')) return false;
            string grupo = formula[inicio..(fin + 1)];
            // Conserva listas heredadas con varias comas y listas inglesas con punto decimal.
            return !grupo.Contains('.') && grupo.Count(c => c == ',') == 1;
        }
        private static string FueraDeTexto(string texto)
        {
            var salida = new StringBuilder(); char comilla = '\0';
            for (int i = 0; i < texto.Length; i++)
            {
                char c = texto[i];
                if (comilla != '\0') { if (c == comilla) { if (i + 1 < texto.Length && texto[i + 1] == c) i++; else comilla = '\0'; } }
                else if (c is '"' or '\'') comilla = c;
                else salida.Append(c);
            }
            return salida.ToString();
        }
    }
}
