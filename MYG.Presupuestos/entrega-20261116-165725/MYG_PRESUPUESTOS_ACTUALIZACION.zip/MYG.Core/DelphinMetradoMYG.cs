using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization.Metadata;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

// La hoja nativa y la hoja del editor comparten las mismas celdas. El BLOB
// original se conserva íntegro cuando no hay una edición que podamos escribir
// sin perder partes del libro. No se infieren códigos de editor de Delphin.
internal static class DelphinMetradoMYG
{
    private static readonly JsonSerializerOptions OpcionesFirma = CrearOpcionesFirma(normalizarMetadatos: true);
    private static readonly JsonSerializerOptions OpcionesFirmaPlantilla = CrearOpcionesFirma(normalizarMetadatos: false);
    private const string NoCompatible = "La partida contiene un archivo de metrado Delphin cuyo formato o celda total MYG todavía no puede representar. El archivo original se conserva; no se ha sustituido por una hoja vacía. Abra el metrado en Delphin y facilite una copia de prueba para ampliar la compatibilidad.";
    private const string HojaPropia = "La partida conserva una hoja editada en MYG y un archivo de metrado Delphin independiente. Se mantienen ambos sin reemplazarlos. Para unificarlos se necesita revisar el archivo original y sus celdas.";
    private const string CambioConcurrente = "El metrado nativo cambió desde que se abrió esta obra. Se conservaron las celdas locales y no se sobrescribió el archivo Delphin. Cierre y vuelva a abrir una copia actualizada antes de aplicar los cambios.";

    internal static void Leer(SqliteConnection c, MYGProyectoDocumento documento,
        SqliteTransaction t = null, Action<string> informar = null) =>
        ActualizarLectura(c, documento, t, informar, nuevaImportacion: true);

    // Repara las importaciones anteriores solo si su plantilla sigue intacta.
    // No escribe SQLite al abrir ni reemplaza una hoja propia de MYG.
    internal static void ActualizarLectura(SqliteConnection c, MYGProyectoDocumento documento,
        SqliteTransaction t = null, Action<string> informar = null, bool nuevaImportacion = false)
    {
        var filas = LeerNativos(c, t, documento);
        foreach (var p in documento.Presupuestos)
        foreach (var i in p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i)))
        {
            if (i.Costos == null) continue;
            var datos = i.Costos;
            var origen = datos.MetradoDelphin;
            if (origen != null && !IdentidadSolicitada(origen, p, i))
            {
                datos.MetradoDelphin = null;
                origen = null;
            }
            if (!IntentarFila(filas, p, i, out var nativo)) continue;
            if (origen != null && !MismaIdentidad(origen, nativo))
            {
                // Una copia/pegado de una partida no adquiere la identidad del
                // archivo nativo de la partida de origen.
                datos.MetradoDelphin = null;
                origen = null;
            }
            string firmaActual = Firma(datos.Hoja);
            if (origen != null)
            {
                if (MismaRevision(origen, nativo)) continue;
                if (origen.FirmaHoja != firmaActual)
                {
                    datos.MetradoDelphin = Estado(nativo, datos.Hoja, false, CambioConcurrente);
                    // Retener la revisión esperada permite que el guardado
                    // detecte el conflicto aunque se cierre el aviso visual.
                    datos.MetradoDelphin.Sha256Archivo = origen.Sha256Archivo;
                    datos.MetradoDelphin.CampoMetrado = origen.CampoMetrado;
                    datos.MetradoDelphin.FirmaFilas = origen.FirmaFilas;
                    informar?.Invoke(CambioConcurrente);
                    continue;
                }
            }
            else if (!nuevaImportacion && !EsPlantillaInicial(datos.Hoja))
            {
                datos.MetradoDelphin = Estado(nativo, datos.Hoja, false, HojaPropia);
                informar?.Invoke(HojaPropia);
                continue;
            }
            try
            {
                if (nativo.Archivo == null) throw new InvalidDataException();
                var hoja = DelphinLibroMetrado.Leer(nativo.Archivo, nativo.Campo);
                datos.Hoja = hoja;
                string aviso = null;
                if (IntentarTotal(p, hoja, out decimal total))
                {
                    // No convertir una diferencia preexistente en un cambio
                    // de presupuesto al abrir. Los modos manual y BIM siguen
                    // siendo elecciones expresas del usuario.
                    if (datos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
                        MYGMotorPresupuestos.Coeficiente(p, datos.Cantidad) == total)
                        datos.FuenteMetrado = MYGFuenteMetrado.Excel;
                    else if (datos.FuenteMetrado == MYGFuenteMetrado.Cantidad)
                        aviso = "La hoja Delphin se leyó, pero su total difiere de la cantidad guardada en el presupuesto. Se conserva la cantidad original hasta que el usuario actualice el metrado desde la hoja.";
                }
                else aviso = "La hoja Delphin se leyó, pero MYG no puede calcular un total numérico válido. Se conserva la cantidad original; no se utiliza un resultado en caché como sustituto de la fórmula.";
                datos.MetradoDelphin = Estado(nativo, hoja, true, aviso);
                if (aviso != null) informar?.Invoke(aviso);
            }
            catch (Exception error) when (ErrorDeFormato(error))
            {
                datos.MetradoDelphin = Estado(nativo, datos.Hoja, false, NoCompatible);
                informar?.Invoke(NoCompatible);
            }
        }
    }

    internal static void Sincronizar(SqliteConnection c, SqliteTransaction t, MYGProyectoDocumento documento)
    {
        var filas = LeerNativos(c, t, documento);
        foreach (var p in documento.Presupuestos)
        foreach (var i in p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i)))
        {
            var datos = i.Costos;
            var origen = datos?.MetradoDelphin;
            if (origen == null) continue;
            if (!IdentidadSolicitada(origen, p, i))
            {
                datos.MetradoDelphin = null;
                continue;
            }
            if (!IntentarFila(filas, p, i, out var nativo))
                throw new InvalidOperationException(CambioConcurrente);
            if (!MismaIdentidad(origen, nativo))
            {
                datos.MetradoDelphin = null;
                continue;
            }
            if (!MismaRevision(origen, nativo))
                throw new InvalidOperationException(CambioConcurrente);
            string firmaActual = Firma(datos.Hoja);
            if (origen.FirmaHoja == firmaActual) continue;
            if (!origen.Compatible || nativo.Archivo == null)
                throw new InvalidDataException(NoCompatible);
            if (!string.Equals(MYGHojaCalculo.Normalizar(datos.Hoja.CeldaTotal), origen.CeldaTotal, StringComparison.Ordinal))
                throw new InvalidDataException("No se puede cambiar la celda total del metrado nativo sin conocer el contrato de campo_metrado de Delphin. Conserve la celda original o revise el metrado en Delphin.");
            if (!IntentarTotal(p, datos.Hoja, out decimal total))
                throw new InvalidDataException("El metrado Delphin editado no tiene un total numérico válido. No se modificó el archivo original.");
            byte[] archivo = DelphinLibroMetrado.Guardar(nativo.Archivo, datos.Hoja);
            DelphinFilasMetradoMYG.Sincronizar(c, t, nativo.Presupuesto, nativo.Partida, nativo.Archivo, datos.Hoja);
            MYGBaseDatos.Ejecutar(c, t, "UPDATE costo_unitario SET archivo_metrado=$p2,cantidad_metrado=$p3 " +
                "WHERE id_costounitario=$p0 AND id_presupuesto=$p1", nativo.Partida, nativo.Presupuesto, archivo, total);
            datos.MetradoDelphin = Estado(nativo with { Archivo = archivo, Hash = Hash(archivo),
                FirmaFilas = DelphinFilasMetradoMYG.Firma(c, t, nativo.Partida) }, datos.Hoja, true, null);
        }
    }

    // Antes de abrir una base Delphin pura para escritura, rechazar revisiones
    // obsoletas en modo de solo lectura. Abrir(escritura:true) puede crear las
    // extensiones MYG antes de iniciar la transacción del documento. Esta
    // comprobación no reemplaza la repetición bajo el bloqueo de escritura.
    internal static void ComprobarRevision(SqliteConnection c, MYGProyectoDocumento documento)
    {
        var propios = documento.Presupuestos.SelectMany(p => p.Items.Select(i => (Presupuesto: p, Item: i)))
            .Where(x => x.Item.Costos?.MetradoDelphin != null && !MYGProyectoStorage.EsTitulo(x.Item) &&
                IdentidadSolicitada(x.Item.Costos.MetradoDelphin, x.Presupuesto, x.Item)).ToList();
        if (propios.Count == 0) return;
        var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var cmd = MYGBaseDatos.Comando(c, null, "SELECT name FROM pragma_table_info('costo_unitario')"))
        using (var r = cmd.ExecuteReader()) while (r.Read()) columnas.Add(r.GetString(0));
        if (!columnas.Contains("archivo_metrado")) throw new InvalidOperationException(CambioConcurrente);
        string campo = columnas.Contains("campo_metrado") ? "cu.campo_metrado" : "NULL";
        foreach (var x in propios)
        {
            var origen = x.Item.Costos.MetradoDelphin;
            string hash, campoActual;
            using (var cmd = MYGBaseDatos.Comando(c, null,
                "SELECT cu.archivo_metrado," + campo +
                " FROM costo_unitario cu JOIN presupuesto p ON p.id_presupuesto=cu.id_presupuesto " +
                "WHERE cu.id_costounitario=$p0 AND cu.id_presupuesto=$p1 AND (p.id_proyecto=$p2 OR p.id_proyecto=$p3)",
                origen.PartidaId, origen.PresupuestoId, documento.Id, MYGDelphinFormato.IdNativo(documento.Id)))
            using (var r = cmd.ExecuteReader())
            {
                if (!r.Read() || r.IsDBNull(0)) throw new InvalidOperationException(CambioConcurrente);
                // Se consulta únicamente cada archivo vinculado, se calcula su
                // huella y se libera; no se importa ni se retienen todos los
                // libros una vez más para este preflight.
                hash = HashArchivo(r.GetValue(0));
                campoActual = r.IsDBNull(1) ? null : Convert.ToString(r.GetValue(1), CultureInfo.InvariantCulture);
            }
            if (hash != origen.Sha256Archivo || campoActual != origen.CampoMetrado ||
                origen.FirmaFilas != null && origen.FirmaFilas != DelphinFilasMetradoMYG.Firma(c, null, origen.PartidaId))
                throw new InvalidOperationException(CambioConcurrente);
        }
    }

    // El guardado actualiza las revisiones en memoria solo si confirma la
    // transacción. Un fallo posterior no debe dejar un hash de una escritura
    // que SQLite haya revertido.
    internal static Action PrepararRestauracion(MYGProyectoDocumento documento)
    {
        var anteriores = documento.Presupuestos.SelectMany(p => p.Items)
            .Where(i => i.Costos != null).Select(i => (Datos: i.Costos, Estado: i.Costos.MetradoDelphin)).ToList();
        return () => { foreach (var x in anteriores) x.Datos.MetradoDelphin = x.Estado; };
    }

    private static bool IntentarTotal(MYGPresupuestoDocumento p, MYGHojaMetrado hoja, out decimal total)
    {
        total = 0;
        try
        {
            var valor = new MYGHojaCalculo(hoja).Resultado(hoja.CeldaTotal);
            if (!valor.EsNumero) return false;
            decimal numero = valor.Numero();
            if (numero < 0 || numero > MYGEdicionPartida.CantidadMaxima) return false;
            total = MYGMotorPresupuestos.Coeficiente(p, numero);
            return true;
        }
        catch (Exception error) when (ErrorDeFormato(error) || error is DivideByZeroException) { return false; }
    }

    private static string Firma(MYGHojaMetrado hoja)
    {
        if (hoja == null) return "";
        // Serializar una sola vez evita copiar y deserializar todas las celdas
        // en cada guardado. La firma conserva el JSON de la importación nativa:
        // navegar o completar metadatos del editor no modifica el libro OOXML.
        return Hash(JsonSerializer.SerializeToUtf8Bytes(hoja, OpcionesFirma));
    }

    private static JsonSerializerOptions CrearOpcionesFirma(bool normalizarMetadatos)
    {
        var tipos = new DefaultJsonTypeInfoResolver();
        tipos.Modifiers.Add(tipo =>
        {
            if (tipo.Type != typeof(MYGHojaMetrado)) return;
            foreach (var propiedad in tipo.Properties)
                switch (propiedad.Name)
                {
                    case nameof(MYGHojaMetrado.Zoom): propiedad.Get = _ => 100; break;
                    case nameof(MYGHojaMetrado.RangoCuerpoPlantilla) when normalizarMetadatos: propiedad.Get = _ => null; break;
                    case nameof(MYGHojaMetrado.RellenoCabeceraEstandarAplicado) when normalizarMetadatos: propiedad.Get = _ => false; break;
                }
        });
        return new JsonSerializerOptions { TypeInfoResolver = tipos };
    }

    private static bool EsPlantillaInicial(MYGHojaMetrado hoja)
    {
        if (hoja == null) return false;
        var copia = MYGProyectoStorage.Copia(hoja);
        if (string.IsNullOrEmpty(copia.IdPlantilla)) copia.IdPlantilla = MYGPlantillasMetrado.Estandar;
        if (copia.RangoCuerpoPlantilla == null) copia.RangoCuerpoPlantilla = MYGBordesPlantillaMetrado.ObtenerRango(copia);
        // Aquí sí distinguen una plantilla personalizada. Ignorarlos como en
        // el libro nativo podría reemplazar una hoja propia durante la lectura.
        string FirmaPlantilla(MYGHojaMetrado valor) => Hash(JsonSerializer.SerializeToUtf8Bytes(valor, OpcionesFirmaPlantilla));
        return FirmaPlantilla(copia) == FirmaPlantilla(MYGHojaMetrado.Crear());
    }

    private static MYGOrigenMetradoDelphin Estado(Nativo n, MYGHojaMetrado hoja, bool compatible, string aviso) => new()
    {
        PresupuestoId = n.Presupuesto, PartidaId = n.Partida, Sha256Archivo = n.Hash, FirmaFilas = n.FirmaFilas,
        CampoMetrado = n.Campo, CeldaTotal = compatible ? MYGHojaCalculo.Normalizar(hoja.CeldaTotal) : null,
        FirmaHoja = Firma(hoja), Compatible = compatible, Advertencia = aviso
    };

    private static bool MismaIdentidad(MYGOrigenMetradoDelphin origen, Nativo fila) =>
        string.Equals(origen.PartidaId, fila.Partida, StringComparison.OrdinalIgnoreCase) &&
        string.Equals(origen.PresupuestoId, fila.Presupuesto, StringComparison.OrdinalIgnoreCase);

    private static bool IdentidadSolicitada(MYGOrigenMetradoDelphin origen,
        MYGPresupuestoDocumento p, ItemPresupuestoDelphin i)
    {
        string partida = string.IsNullOrWhiteSpace(i.IdInternoDelphin) ? i.Id : i.IdInternoDelphin;
        bool Partida(string id) => string.Equals(origen.PartidaId, id, StringComparison.OrdinalIgnoreCase);
        bool Presupuesto(string id) => string.Equals(origen.PresupuestoId, id, StringComparison.OrdinalIgnoreCase);
        return (Partida(partida) || Partida(MYGDelphinFormato.IdNativo(partida))) &&
            (Presupuesto(p.Id) || Presupuesto(MYGDelphinFormato.IdNativo(p.Id)));
    }

    private static bool MismaRevision(MYGOrigenMetradoDelphin origen, Nativo fila) =>
        origen.Sha256Archivo == fila.Hash && origen.CampoMetrado == fila.Campo &&
        (origen.FirmaFilas == null || origen.FirmaFilas == fila.FirmaFilas);

    private static bool IntentarFila(Dictionary<(string, string), Nativo> filas,
        MYGPresupuestoDocumento p, ItemPresupuestoDelphin i, out Nativo fila)
    {
        string partida = string.IsNullOrWhiteSpace(i.IdInternoDelphin) ? i.Id : i.IdInternoDelphin;
        return filas.TryGetValue((p.Id.ToUpperInvariant(), partida.ToUpperInvariant()), out fila) ||
            filas.TryGetValue((MYGDelphinFormato.IdNativo(p.Id).ToUpperInvariant(), MYGDelphinFormato.IdNativo(partida).ToUpperInvariant()), out fila);
    }

    private static Dictionary<(string, string), Nativo> LeerNativos(SqliteConnection c, SqliteTransaction t, MYGProyectoDocumento documento)
    {
        var filas = new Dictionary<(string, string), Nativo>();
        var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var cmd = MYGBaseDatos.Comando(c, t, "SELECT name FROM pragma_table_info('costo_unitario')"))
        using (var r = cmd.ExecuteReader()) while (r.Read()) columnas.Add(r.GetString(0));
        if (!columnas.Contains("archivo_metrado") || !columnas.Contains("id_presupuesto")) return filas;
        string campo = columnas.Contains("campo_metrado") ? "cu.campo_metrado" : "NULL";
        using (var cmd = MYGBaseDatos.Comando(c, t,
            "SELECT cu.id_costounitario,cu.id_presupuesto,cu.archivo_metrado," + campo +
            " FROM costo_unitario cu JOIN presupuesto p ON p.id_presupuesto=cu.id_presupuesto " +
            "WHERE (p.id_proyecto=$p0 OR p.id_proyecto=$p1) AND cu.archivo_metrado IS NOT NULL AND length(cu.archivo_metrado)>0",
            documento.Id, MYGDelphinFormato.IdNativo(documento.Id)))
        using (var r = cmd.ExecuteReader()) while (r.Read())
        {
            string id = r.GetString(0), presupuesto = r.GetString(1);
            object valor = r.GetValue(2);
            byte[] archivo = valor as byte[];
            string hash = HashArchivo(valor);
            var fila = new Nativo(presupuesto, id, archivo, hash, r.IsDBNull(3) ? null : Convert.ToString(r.GetValue(3), CultureInfo.InvariantCulture),
                DelphinFilasMetradoMYG.Firma(c, t, id));
            filas[(presupuesto.ToUpperInvariant(), id.ToUpperInvariant())] = fila;
        }
        return filas;
    }

    private sealed record Nativo(string Presupuesto, string Partida, byte[] Archivo, string Hash, string Campo, string FirmaFilas);
    private static string HashArchivo(object valor) => valor is byte[] archivo ? Hash(archivo) :
        "NO_BLOB:" + Hash(Encoding.UTF8.GetBytes(Convert.ToString(valor, CultureInfo.InvariantCulture) ?? ""));
    private static string Hash(byte[] contenido) => Convert.ToHexString(SHA256.HashData(contenido));
    private static bool ErrorDeFormato(Exception error) => error is InvalidDataException or NotSupportedException or
        FormatException or ArgumentException or OverflowException or System.Xml.XmlException;
}
