using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG_2027;

internal static class FirmaMetradoDelphinCheck
{
    private static readonly MethodInfo MetodoFirma = typeof(MYGHojaMetrado).Assembly
        .GetType("MYG_2027.DelphinMetradoMYG", true)
        .GetMethod("Firma", BindingFlags.Static | BindingFlags.NonPublic);
    private static readonly MethodInfo MetodoPlantilla = typeof(MYGHojaMetrado).Assembly
        .GetType("MYG_2027.DelphinMetradoMYG", true)
        .GetMethod("EsPlantillaInicial", BindingFlags.Static | BindingFlags.NonPublic);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var hoja = MYGHojaMetrado.Crear();
        hoja.Poner("A3", "Metrado de Áncash · 漢字 \"original\"\nsegunda línea");
        hoja.Poner("B3", "2"); hoja.Poner("C3", "12.3450");
        hoja.Celdas["A3"].Cursiva = true;
        hoja.Celdas["C3"].FormatoNumero = "0.0000";
        string archivo = Path.Combine(carpeta, "Firma de metrado nativo.xlsx");
        MYGExcelPresupuestos.Guardar(archivo, new[] { hoja });
        var importada = MYGExcelPresupuestos.Importar(archivo, hoja.Nombre, hoja.CeldaTotal);
        string firmaOriginal = FirmaAnterior(importada);
        Exige(Firma(importada) == firmaOriginal,
            "La firma optimizada cambió el hash que ya guardaban los metrados nativos importados.");
        Exige(Firma(null) == "", "La hoja ausente debe conservar su firma vacía.");

        string antes = JsonSerializer.Serialize(importada);
        foreach (int zoom in new[] { 25, 100, 150, 300 })
        {
            var editor = MYGProyectoStorage.Copia(importada);
            editor.Zoom = zoom;
            editor.RangoCuerpoPlantilla = zoom == 25 ? "" : "A3:H15";
            editor.RellenoCabeceraEstandarAplicado = true;
            string estadoEditor = JsonSerializer.Serialize(editor);
            Exige(Firma(editor) == firmaOriginal && JsonSerializer.Serialize(editor) == estadoEditor,
                "Navegar o completar metadatos del editor cambió la firma nativa o mutó la hoja.");
        }
        Exige(JsonSerializer.Serialize(importada) == antes,
            "Calcular la firma modificó la hoja original.");
        pasa("Firma nativa conserva el SHA-256 anterior y omite zoom/metadatos MYG sin copiar ni modificar la hoja");

        void Detecta(Action<MYGHojaMetrado> cambiar, string tipo)
        {
            var editada = MYGProyectoStorage.Copia(importada);
            cambiar(editada);
            Exige(Firma(editada) != firmaOriginal,
                "La firma dejó de detectar cambios de " + tipo + ".");
            Exige(Firma(editada) == FirmaAnterior(editada),
                "La firma cambió la representación anterior de " + tipo + ".");
        }
        Detecta(h => h.Celdas["C3"].Contenido = "15.4321", "contenido");
        Detecta(h => h.Celdas["C3"].Fuente = "Calibri", "fuente");
        Detecta(h => h.Celdas["A3"].Negrita = !h.Celdas["A3"].Negrita, "estilo");
        Detecta(h => h.Columnas++, "estructura");
        Detecta(h => h.CeldaTotal = "G15", "celda total");
        Detecta(h => h.AreaImpresion = "A1:H15", "configuración de impresión");

        bool EsPlantilla(MYGHojaMetrado valor) => (bool)MetodoPlantilla.Invoke(null, new object[] { valor });
        var plantilla = MYGHojaMetrado.Crear();
        Exige(EsPlantilla(plantilla), "La plantilla intacta dejó de reconocerse.");
        plantilla.Zoom = 250;
        Exige(EsPlantilla(plantilla), "Cambiar sólo el zoom convirtió una plantilla intacta en hoja personalizada.");
        plantilla.RangoCuerpoPlantilla = "A4:H15";
        string personalizada = JsonSerializer.Serialize(plantilla);
        Exige(!EsPlantilla(plantilla) && JsonSerializer.Serialize(plantilla) == personalizada,
            "Una plantilla con cuerpo personalizado se trataría como intacta y podría reemplazarse por el metrado nativo.");
        plantilla = MYGHojaMetrado.Crear();
        plantilla.RellenoCabeceraEstandarAplicado = false;
        Exige(!EsPlantilla(plantilla), "La detección de plantilla perdió el marcador de cabecera original.");
        pasa("Firma detecta cambios reales y la identificación de plantilla sigue distinguiendo sus metadatos personalizados");
    }

    private static string Firma(MYGHojaMetrado hoja) => (string)MetodoFirma.Invoke(null, new object[] { hoja });

    private static string FirmaAnterior(MYGHojaMetrado hoja)
    {
        var copia = MYGProyectoStorage.Copia(hoja);
        copia.Zoom = 100;
        copia.RangoCuerpoPlantilla = null;
        copia.RellenoCabeceraEstandarAplicado = false;
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(copia))));
    }

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
}
