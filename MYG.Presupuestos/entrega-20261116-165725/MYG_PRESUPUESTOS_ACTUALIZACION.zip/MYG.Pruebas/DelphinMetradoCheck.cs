using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Xml.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinMetradoCheck
{
    private static void Exige(bool valor, string mensaje)
    { if (!valor) throw new Exception(mensaje); }

    private static object Sql(string ruta, string sql, params object[] valores)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = sql;
        for (int n = 0; n < valores.Length; n++) cmd.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        return cmd.ExecuteScalar();
    }

    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));

    private static byte[] Libro(string carpeta)
    {
        var h = MYGHojaMetrado.Crear();
        h.Nombre = "Metrado"; h.Poner("A1", "Datos - preliminar", true);
        h.Poner("A3", "Frente de obra"); h.Poner("B3", "1"); h.Poner("C3", "60");
        h.Celdas["A3"].Fuente = "Calibri"; h.Celdas["A3"].TamanoFuente = 10;
        string ruta = Path.Combine(carpeta, "metrado-nativo-sintetico.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { h });
        return File.ReadAllBytes(ruta);
    }

    private static string Base(string carpeta, string nombre, byte[] blob, bool nativa)
    {
        string ruta = Path.Combine(carpeta, nombre + ".sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        var d = MYGProyectoStorage.Nuevo("METRADO SINTÉTICO");
        d.Id = "PRMETRADO"; var p = d.Presupuestos.Single(); p.Id = "PPMETRADO";
        d.PresupuestoActivoId = p.Id;
        p.Items.Add(new ItemPresupuestoDelphin
        {
            Id = "CUMETRADO", IdLocalMYG = "DELPHIN-LOCAL-CUMETRADO", IdInternoDelphin = "CUMETRADO",
            Origen = "DELPHIN", Estado = "OFICIAL", Descripcion = "CERCO PROVISIONAL", Unidad = "m",
            TipoPropuesta = "PARTIDA", Item = "01", Posicion = 1,
            Costos = new MYGDatosPartida { Cantidad = 60, PrecioDirecto = 0.2m }
        });
        MYGProyectoStorage.Guardar(ruta, d);
        Sql(ruta, "UPDATE costo_unitario SET archivo_metrado=$p0,campo_metrado='G16',editor_metrado='X',tiene_metrado='S',cantidad_metrado=60,Notas1='CONSERVAR' WHERE id_costounitario='CUMETRADO'", blob);
        if (nativa) Sql(ruta, "DELETE FROM myg_presupuesto; DELETE FROM myg_proyecto;");
        return ruta;
    }

    private static MYGHojaMetrado LeerLibro(string carpeta, byte[] blob)
    {
        string ruta = Path.Combine(carpeta, "metrado-nativo-verificacion.xlsx");
        File.WriteAllBytes(ruta, blob);
        return MYGExcelPresupuestos.Importar(ruta, "Metrado", "G16");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        byte[] libro = Libro(carpeta);
        string ruta = Base(carpeta, "Metrado Delphin nativo", libro, true);
        string original = Huella(ruta);
        var d = MYGBaseDatos.LeerProyecto(ruta, "PRMETRADO");
        var p = d.Presupuestos.Single(); var i = p.Items.Single();
        Exige(Huella(ruta) == original, "Abrir el metrado Delphin modificó la base original.");
        Exige(i.Costos.Hoja.Celdas["A3"].Contenido == "Frente de obra" &&
            i.Costos.Hoja.Celdas["B3"].Contenido == "1" && i.Costos.Hoja.Celdas["C3"].Contenido == "60" &&
            new MYGHojaCalculo(i.Costos.Hoja).Numero("G16") == 60 &&
            i.Costos.Hoja.Celdas["G3"].Contenido.StartsWith("=PRODUCT(", StringComparison.Ordinal) &&
            i.Costos.Hoja.Celdas["A3"].Fuente == "Calibri" &&
            MYGMotorPresupuestos.Cantidad(p, i) == 60,
            "El XLSX nativo perdió celdas, fórmulas, formato o metrado de la partida.");
        pasa("Metrado Delphin XLSX carga Frente de obra, 1 × 60, fórmulas y estilos sin escribir al abrir");

        MYGProyectoStorage.Guardar(ruta, d);
        Exige(((byte[])Sql(ruta, "SELECT archivo_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'")).SequenceEqual(libro),
            "Guardar sin editar reescribió el archivo nativo de metrado.");
        var totalAlterado = MYGProyectoStorage.Copia(d);
        var hojaConTotalAlterado = totalAlterado.Presupuestos.Single().Items.Single().Costos.Hoja;
        hojaConTotalAlterado.Zoom = 150;
        hojaConTotalAlterado.RangoCuerpoPlantilla = "";
        hojaConTotalAlterado.RellenoCabeceraEstandarAplicado = true;
        hojaConTotalAlterado.CeldaTotal = "C3";
        bool rechazoTotal = false;
        try { MYGProyectoStorage.Guardar(ruta, totalAlterado); }
        catch (InvalidDataException error) when (error.Message.Contains("celda total", StringComparison.Ordinal))
        { rechazoTotal = true; }
        Exige(rechazoTotal &&
            ((byte[])Sql(ruta, "SELECT archivo_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'")).SequenceEqual(libro) &&
            Convert.ToDecimal(Sql(ruta, "SELECT cantidad_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'"), CultureInfo.InvariantCulture) == 60 &&
            (string)Sql(ruta, "SELECT campo_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'") == "G16",
            "Omitir marcadores del editor permitió cambiar el contrato de celda total o modificar datos nativos tras el rechazo.");
        pasa("Los metadatos del editor no permiten cambiar la celda total Delphin y un rechazo conserva el libro y su contrato nativos");
        i = d.Presupuestos.Single().Items.Single();
        i.Costos.Hoja.Celdas["A3"].Contenido = "Frente de obra editado";
        MYGProyectoStorage.Guardar(ruta, d);
        var nativa = LeerLibro(carpeta, (byte[])Sql(ruta, "SELECT archivo_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'"));
        Exige(nativa.Celdas["A3"].Contenido == "Frente de obra editado" && new MYGHojaCalculo(nativa).Numero("G16") == 60,
            "Una edición de celda con el mismo total se perdió en el archivo nativo.");
        Exige((string)Sql(ruta, "SELECT editor_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'") == "X" &&
            (string)Sql(ruta, "SELECT Notas1 FROM costo_unitario WHERE id_costounitario='CUMETRADO'") == "CONSERVAR",
            "Guardar la hoja inventó un tipo de editor o cambió metadatos nativos ajenos.");
        pasa("Guardar metrado conserva bytes intactos y sincroniza una descripción editada aunque el total siga en 60");

        d = MYGBaseDatos.LeerProyecto(ruta, "PRMETRADO"); p = d.Presupuestos.Single(); i = p.Items.Single();
        i.Costos.Hoja.Celdas["C3"].Contenido = "75";
        MYGProyectoStorage.Guardar(ruta, d);
        nativa = LeerLibro(carpeta, (byte[])Sql(ruta, "SELECT archivo_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'"));
        Exige(new MYGHojaCalculo(nativa).Numero("G16") == 75 &&
            Convert.ToDecimal(Sql(ruta, "SELECT cantidad_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'"), CultureInfo.InvariantCulture) == 75,
            "El archivo y la cantidad_metrado nativa quedaron independientes tras editar.");
        Sql(ruta, "DELETE FROM myg_presupuesto; DELETE FROM myg_proyecto;");
        var sinOverlay = MYGBaseDatos.LeerProyecto(ruta, "PRMETRADO");
        Exige(new MYGHojaCalculo(sinOverlay.Presupuestos.Single().Items.Single().Costos.Hoja).Numero("G16") == 75,
            "El metrado editado solo se podía leer desde el documento adicional MYG.");
        pasa("Metrado editado actualiza archivo y cantidad nativa y se reabre sin depender del documento adicional MYG");

        string antigua = Base(carpeta, "Metrado Delphin legado", libro, false);
        original = Huella(antigua);
        var recuperada = MYGBaseDatos.LeerProyecto(antigua, "PRMETRADO");
        Exige(recuperada.Presupuestos.Single().Items.Single().Costos.Hoja.Celdas["A3"].Contenido == "Frente de obra" && Huella(antigua) == original,
            "La importación antigua conservó la plantilla vacía o escribió al recuperar el metrado.");
        pasa("Importaciones antiguas recuperan el metrado nativo sobre la plantilla intacta sin modificar SQLite al leer");

        string concurrencia = Base(carpeta, "Metrado Delphin concurrencia", libro, true);
        var pendiente = MYGBaseDatos.LeerProyecto(concurrencia, "PRMETRADO");
        pendiente.Presupuestos.Single().Items.Single().Costos.Hoja.Celdas["A3"].Contenido = "Cambio pendiente";
        var externo = LeerLibro(carpeta, libro); externo.Celdas["A3"].Contenido = "Cambio desde Delphin";
        string archivoExterno = Path.Combine(carpeta, "metrado-edicion-externa.xlsx");
        MYGExcelPresupuestos.Guardar(archivoExterno, new[] { externo });
        Sql(concurrencia, "UPDATE costo_unitario SET archivo_metrado=$p0 WHERE id_costounitario='CUMETRADO'", File.ReadAllBytes(archivoExterno));
        original = Huella(concurrencia); bool rechazo = false;
        try { MYGProyectoStorage.Guardar(concurrencia, pendiente); }
        catch (InvalidOperationException) { rechazo = true; }
        Exige(rechazo && Huella(concurrencia) == original,
            "Guardar una hoja obsoleta sobrescribió la modificación nativa concurrente o dejó una transacción parcial.");
        pasa("Una edición nativa concurrente impide sobrescribir el metrado con una copia obsoleta");

        string desconocida = Base(carpeta, "Metrado Delphin desconocido", new byte[] { 1, 2, 3, 4, 5 }, true);
        var sinSoporte = MYGBaseDatos.LeerProyecto(desconocida, "PRMETRADO");
        var datos = sinSoporte.Presupuestos.Single().Items.Single().Costos;
        Exige(datos.MetradoDelphin is { Compatible: false } && !string.IsNullOrWhiteSpace(datos.MetradoDelphin.Advertencia),
            "Un formato desconocido se presentó silenciosamente como hoja compatible vacía.");
        MYGProyectoStorage.Guardar(desconocida, sinSoporte);
        Exige(((byte[])Sql(desconocida, "SELECT archivo_metrado FROM costo_unitario WHERE id_costounitario='CUMETRADO'")).SequenceEqual(new byte[] { 1, 2, 3, 4, 5 }),
            "Guardar otra información reemplazó un metrado desconocido.");
        pasa("Formatos nativos desconocidos muestran advertencia y conservan el archivo original al guardar otros datos");
        EjecutarMuestra(carpeta, pasa);
    }

    private static void EjecutarMuestra(string carpeta, Action<string> pasa)
    {
        string fuente = Environment.GetEnvironmentVariable("MYG_QA_METRADO_DELPHIN_SQLITE");
        if (string.IsNullOrWhiteSpace(fuente))
        { Console.WriteLine("OMITIDA: muestra externa de metrado Delphin (MYG_QA_METRADO_DELPHIN_SQLITE no definido)."); return; }
        string huella = Huella(fuente);
        string copia = Path.Combine(carpeta, "copia-metrado-delphin-real.sqlite");
        File.Copy(fuente, copia);
        var proyectos = MYGBaseDatos.ListarProyectos(copia);
        MYGProyectoDocumento objetivo = null;
        foreach (var proyecto in proyectos)
        {
            var d = MYGBaseDatos.LeerProyecto(copia, proyecto.Id);
            if (d.Presupuestos.SelectMany(p => p.Items).Any(i => i.Id == "CU0000022254")) objetivo = d;
            var hojas = d.Presupuestos.SelectMany(p => p.Items).Where(i => i.Costos?.MetradoDelphin != null).ToArray();
            Exige(hojas.All(i => i.Costos.MetradoDelphin.Compatible), "La muestra contiene una hoja nativa que aún no se pudo leer.");
            VerificarFormulasNativas(copia, hojas);
            Console.WriteLine("Muestra externa: " + hojas.Length + " hojas nativas compatibles en proyecto leído.");
        }
        Exige(objetivo != null, "La muestra no contiene la partida de referencia de la captura.");
        var partida = objetivo.Presupuestos.SelectMany(p => p.Items).Single(i => i.Id == "CU0000022254");
        Exige(partida.Costos.Hoja.Celdas["A3"].Contenido == "Frente de obra" &&
            partida.Costos.Hoja.Celdas["C3"].Contenido == "60" &&
            new MYGHojaCalculo(partida.Costos.Hoja).Numero("G16") == 60,
            "La muestra real no recuperó las celdas y total visibles en Delphin.");
        string consulta = "SELECT archivo_metrado FROM costo_unitario WHERE id_costounitario='CU0000022254'";
        byte[] antes = (byte[])Sql(copia, consulta);
        string nota = Convert.ToString(Sql(copia, "SELECT observaciones FROM metrado WHERE id_costounitario='CU0000022254' AND posicion=0"));
        string idFila = Convert.ToString(Sql(copia, "SELECT id_metrado FROM metrado WHERE id_costounitario='CU0000022254' AND posicion=0"));
        MYGProyectoStorage.Guardar(copia, objetivo);
        Exige(((byte[])Sql(copia, consulta)).SequenceEqual(antes), "Guardar la muestra intacta reescribió su XLSX original.");
        objetivo = MYGBaseDatos.LeerProyecto(copia, objetivo.Id);
        partida = objetivo.Presupuestos.SelectMany(p => p.Items).Single(i => i.Id == "CU0000022254");
        partida.Costos.Hoja.Celdas["C3"].Contenido = "75";
        MYGProyectoStorage.Guardar(copia, objetivo);
        var libroNativo = LeerLibro(carpeta, (byte[])Sql(copia, consulta));
        Exige(new MYGHojaCalculo(libroNativo).Numero("G16") == 75 &&
            Convert.ToDecimal(Sql(copia, "SELECT cantidadxunidad FROM metrado WHERE id_costounitario='CU0000022254' AND posicion=0"), CultureInfo.InvariantCulture) == 75 &&
            Convert.ToDecimal(Sql(copia, "SELECT parcial_metrado FROM metrado WHERE id_costounitario='CU0000022254' AND posicion=0"), CultureInfo.InvariantCulture) == 75,
            "Editar la muestra no sincronizó celdas, filas nativas y parcial de Delphin.");
        Exige(Convert.ToString(Sql(copia, "SELECT observaciones FROM metrado WHERE id_costounitario='CU0000022254' AND posicion=0")) == nota &&
            Convert.ToString(Sql(copia, "SELECT id_metrado FROM metrado WHERE id_costounitario='CU0000022254' AND posicion=0")) == idFila && Huella(fuente) == huella,
            "La prueba alteró el original, la identidad de fila o una nota nativa que no se editó.");
        pasa("Muestra Delphin real: lectura de todas las hojas, cerco 60→75 en copia, filas/identidades/notas preservadas y SHA-256 original intacto");
    }

    private static void VerificarFormulasNativas(string ruta, ItemPresupuestoDelphin[] partidas)
    {
        XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        int formulas = 0;
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open();
        foreach (var partida in partidas)
        {
            using var cmd = c.CreateCommand();
            cmd.CommandText = "SELECT archivo_metrado FROM costo_unitario WHERE id_costounitario=$id";
            cmd.Parameters.AddWithValue("$id", partida.Costos.MetradoDelphin.PartidaId);
            using var zip = new ZipArchive(new MemoryStream((byte[])cmd.ExecuteScalar(), false), ZipArchiveMode.Read);
            using var flujo = zip.GetEntry("xl/worksheets/sheet1.xml").Open();
            var xml = XDocument.Load(flujo); var calculo = new MYGHojaCalculo(partida.Costos.Hoja);
            foreach (var celda in xml.Descendants(s + "c").Where(x => x.Element(s + "f") != null))
            {
                if (!decimal.TryParse(celda.Element(s + "v")?.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out decimal esperado)) continue;
                decimal obtenido = calculo.Numero((string)celda.Attribute("r"));
                Exige(Math.Abs(obtenido - esperado) <= 0.000001m,
                    "El cálculo de una fórmula nativa difiere del resultado guardado por Delphin.");
                formulas++;
            }
        }
        Exige(partidas.Length == 0 || formulas > 0, "No se ejecutó ninguna fórmula de las hojas externas.");
        Console.WriteLine("Muestra externa: " + formulas + " fórmulas recalculadas y comparadas con los resultados nativos.");
    }
}
