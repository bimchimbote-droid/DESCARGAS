using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class DelphinLibroMetradoCheck
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static readonly Type Codec = typeof(MYGHojaMetrado).Assembly.GetType("MYG_2027.DelphinLibroMetrado", true);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var hoja = MYGHojaMetrado.Crear();
        hoja.Poner("A3", "Frente de obra"); hoja.Poner("B3", "1"); hoja.Poner("C3", "60");
        string ruta = Path.Combine(carpeta, "Metrado nativo sintético.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { hoja });
        byte[] original = File.ReadAllBytes(ruta);
        var importada = Leer(original, "$G$16");
        Exige(importada.Celdas["A3"].Contenido == "Frente de obra" && new MYGHojaCalculo(importada).Numero(importada.CeldaTotal) == 60,
            "El lector nativo perdió las celdas y el total 1 x 60 de la hoja OOXML.");
        Exige(Guardar(original, importada).SequenceEqual(original), "Guardar una hoja sin edición alteró el BLOB nativo.");
        Exige(Leer(original, "").CeldaTotal == "G16", "La etiqueta Total con una suma unívoca no identificó el total.");
        pasa("Libro nativo Delphin OOXML lee celdas y total 60, detecta la suma unívoca y conserva el BLOB sin ediciones byte a byte");

        var consultada = Leer(original, "G16");
        Exige(consultada.RangoCuerpoPlantilla == null && !consultada.RellenoCabeceraEstandarAplicado,
            "El libro sintético debe reproducir los marcadores MYG ausentes de una importación nativa.");
        // Reproducir una hoja ya consultada por versiones anteriores del editor:
        // completar null como cadena vacía no cambia ninguna parte del XLSX.
        consultada.RangoCuerpoPlantilla ??= MYGBordesPlantillaMetrado.ObtenerRango(consultada);
        consultada.RellenoCabeceraEstandarAplicado = true;
        consultada.Zoom = 150;
        string antesConsulta = JsonSerializer.Serialize(consultada);
        Exige(Guardar(original, consultada).SequenceEqual(original) && JsonSerializer.Serialize(consultada) == antesConsulta,
            "Completar metadatos del editor o cambiar zoom no debe rechazar el guardado, reescribir el BLOB ni alterar la hoja del usuario.");
        consultada.Celdas["C3"].Contenido = "65";
        byte[] editadaTrasConsulta = Guardar(original, consultada);
        Exige(new MYGHojaCalculo(Leer(editadaTrasConsulta, "G16")).Numero("G16") == 65 &&
            Guardar(editadaTrasConsulta, consultada).SequenceEqual(editadaTrasConsulta) &&
            consultada.Zoom == 150 && consultada.RellenoCabeceraEstandarAplicado && consultada.RangoCuerpoPlantilla != null,
            "Una hoja con marcadores MYG debe guardar y reabrir el contenido editado, preservar sus metadatos y permitir un segundo guardado sin cambios.");
        using (var antes = new ZipArchive(new MemoryStream(original)))
        using (var despues = new ZipArchive(new MemoryStream(editadaTrasConsulta)))
            Exige(Parte(antes, "xl/styles.xml").SequenceEqual(Parte(despues, "xl/styles.xml")),
                "Admitir metadatos MYG no debe sustituir los estilos originales del libro nativo.");
        pasa("Guardar una hoja nativa consultada ignora sólo marcadores MYG y zoom, conserva bytes sin edición y guarda cambios reales de celdas");

        var nativa = Modificar(original, zip =>
        {
            XNamespace ct = "http://schemas.openxmlformats.org/package/2006/content-types";
            var tipos = LeerXml(zip, "[Content_Types].xml");
            tipos.Descendants(ct + "Override").Where(e => (string)e.Attribute("PartName") == "/xl/workbook.xml").Remove();
            tipos.Descendants(ct + "Default").Single(e => (string)e.Attribute("Extension") == "xml").SetAttributeValue("ContentType",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml");
            EscribirXml(zip, "[Content_Types].xml", tipos);
            var libro = LeerXml(zip, "xl/workbook.xml");
            string[] variables = { "descripcion_metrado", "unidades", "cantidadxunidad", "largo", "ancho", "alto", "parcial_metrado", "observaciones", "imagen" };
            var nombres = new XElement(S + "definedNames");
            for (int i = 0; i < variables.Length; i++)
                nombres.Add(new XElement(S + "definedName", new XAttribute("name", variables[i]), "Metrado!$" + (char)('A' + i) + ":$" + (char)('A' + i)));
            nombres.Add(new XElement(S + "definedName", new XAttribute("name", "init_row"), "Metrado!$3:$3"),
                new XElement(S + "definedName", new XAttribute("name", "new_row"), "Metrado!$4:$4"),
                new XElement(S + "definedName", new XAttribute("name", "total_metrado"), "Metrado!$G$16"));
            libro.Root.Add(nombres); EscribirXml(zip, "xl/workbook.xml", libro);
            var xml = LeerXml(zip, "xl/worksheets/sheet1.xml");
            xml.Descendants(S + "c").Single(c => (string)c.Attribute("r") == "G3").Element(S + "f").Value =
                "ROUND(B3*C3*IF(ISBLANK(D3),1,D3)*IF(ISBLANK(E3),1,E3)*IF(ISBLANK(F3),1,F3),2)";
            xml.Descendants(S + "c").Single(c => (string)c.Attribute("r") == "G16").Element(S + "f").Value = "ROUND(SUM(G3:G15),2)";
            EscribirXml(zip, "xl/worksheets/sheet1.xml", xml);
        });
        var fiel = Leer(nativa, null);
        Exige(fiel.CeldaTotal == "G16" && new MYGHojaCalculo(fiel).Numero("G16") == 60,
            "El nombre total_metrado nativo y sus fórmulas ROUND/IF/ISBLANK/SUM no dieron 60.");
        fiel.Celdas["C3"].Contenido = "65";
        byte[] fielGuardada = Guardar(nativa, fiel);
        using (var zip = new ZipArchive(new MemoryStream(fielGuardada)))
            Exige(LeerXml(zip, "xl/workbook.xml").Descendants(S + "definedName").Count() == 12,
                "El guardado retiró nombres nativos de columnas, filas o total.");
        Exige(new MYGHojaCalculo(Leer(fielGuardada, null)).Numero("G16") == 65, "El intercambio nativo no conservó el cálculo tras editar una dimensión.");
        pasa("Libro Delphin conserva sus nombres nativos de columnas/filas, resuelve total_metrado sin campo y recalcula ROUND/IF/ISBLANK/SUM tras editar");

        var otra = new MYGHojaMetrado { Nombre = "Otra hoja", CeldaTotal = "A1" };
        otra.Poner("A1", "=1+2"); otra.Poner("B1", "Dato ajeno");
        MYGExcelPresupuestos.Guardar(ruta, new[] { hoja, otra });
        byte[] complejo = Modificar(File.ReadAllBytes(ruta), zip =>
        {
            var libro = LeerXml(zip, "xl/workbook.xml");
            libro.Root.Add(new XElement(S + "definedNames", new XElement(S + "definedName", new XAttribute("name", "Total"), "'Metrado'!$G$16")));
            EscribirXml(zip, "xl/workbook.xml", libro);
            using var flujo = zip.CreateEntry("customXml/datos-delphin.xml").Open();
            flujo.Write(Encoding.UTF8.GetBytes("<delphin conservar=\"si\">Dato ajeno sintético</delphin>"));
            var xml = LeerXml(zip, "xl/worksheets/sheet1.xml");
            xml.Root.Add(new XElement(S + "extLst", new XElement(S + "ext", new XAttribute("uri", "prueba-preservacion"),
                new XElement("dato-propio", "No retirar"))));
            EscribirXml(zip, "xl/worksheets/sheet1.xml", xml);
        });
        var lectura = Leer(complejo, "Total");
        Exige(lectura.Nombre == "Metrado" && lectura.CeldaTotal == "G16", "El nombre definido de total perdió la hoja o la celda.");
        Exige(Leer(complejo, "'Metrado'!$G$16").CeldaTotal == "G16", "No se admitió la dirección explícita de una hoja del libro.");
        lectura.Celdas["C3"].Contenido = "75";
        byte[] actualizado = Guardar(complejo, lectura);
        Exige(new MYGHojaCalculo(Leer(actualizado, "Total")).Numero("G16") == 75, "La edición nativa no recalculó 1 x 75.");
        using (var antes = new ZipArchive(new MemoryStream(complejo)))
        using (var despues = new ZipArchive(new MemoryStream(actualizado)))
        {
            Exige(Parte(antes, "customXml/datos-delphin.xml").SequenceEqual(Parte(despues, "customXml/datos-delphin.xml")) &&
                Parte(antes, "xl/styles.xml").SequenceEqual(Parte(despues, "xl/styles.xml")), "La edición sustituyó metadatos ajenos o estilos nativos.");
            var xml = LeerXml(despues, "xl/worksheets/sheet1.xml");
            Exige(xml.Descendants("dato-propio").Single().Value == "No retirar", "La edición retiró extensiones desconocidas de la hoja.");
            Exige(xml.Descendants(S + "c").Single(c => (string)c.Attribute("r") == "G16").Element(S + "v")?.Value == "75",
                "La salida conservó el valor anterior en la caché del total.");
            var ajena = LeerXml(despues, "xl/worksheets/sheet2.xml");
            Exige(ajena.Descendants(S + "c").Single(c => (string)c.Attribute("r") == "A1").Element(S + "f")?.Value == "1+2" &&
                ajena.Descendants(S + "c").Single(c => (string)c.Attribute("r") == "A1").Element(S + "v") == null &&
                ajena.Descendants(S + "t").Single().Value == "Dato ajeno", "Se perdió contenido de otra hoja o se conservó su caché potencialmente obsoleta.");
        }
        pasa("Editar el libro nativo recalcula la caché, preserva otras hojas, estilos, extensiones y metadatos ajenos, e invalida cachés dependientes");

        byte[] textoNumerico = Modificar(original, zip =>
        {
            var xml = LeerXml(zip, "xl/worksheets/sheet1.xml");
            xml.Descendants(S + "c").Single(c => (string)c.Attribute("r") == "A3").Descendants(S + "t").Single().Value = "001";
            EscribirXml(zip, "xl/worksheets/sheet1.xml", xml);
        });
        var textoLeido = Leer(textoNumerico, "G16"); textoLeido.Celdas["A3"].Contenido = "002";
        using (var zip = new ZipArchive(new MemoryStream(Guardar(textoNumerico, textoLeido))))
        {
            var celda = LeerXml(zip, "xl/worksheets/sheet1.xml").Descendants(S + "c").Single(c => (string)c.Attribute("r") == "A3");
            Exige((string)celda.Attribute("t") == "inlineStr" && celda.Descendants(S + "t").Single().Value == "002" && celda.Element(S + "v") == null,
                "Una edición convirtió el texto nativo con ceros iniciales a un número.");
        }
        pasa("Editar una celda nativa de texto conserva su tipo y los ceros iniciales aunque su contenido parezca numérico");

        Rechaza(() => Leer(complejo, "G16"), "Un campo sin hoja identificó ambiguamente un total entre varias hojas.");
        Rechaza(() => Leer(original, "cantidad_metrado"), "Se interpretó un campo desconocido como una dirección o un total supuesto.");
        Rechaza(() => Leer(Encoding.UTF8.GetBytes("Formato binario no OOXML"), "G16"), "El lector convirtió un formato desconocido a XLSX.");
        var formato = MYGProyectoStorage.Copia(consultada); formato.Celdas["A3"].Negrita = !formato.Celdas["A3"].Negrita;
        Rechaza(() => Guardar(original, formato), "Se guardó un cambio de estilo sin garantizar su conservación.");
        foreach (Action<MYGHojaMetrado> cambiar in new Action<MYGHojaMetrado>[]
        {
            h => h.Columnas++, h => h.Filas++,
            h => h.RangosCombinados.Clear(), h => h.OrientacionPagina = "Horizontal",
            h => h.MargenIzquierdo += .1m, h => h.AnchosColumnas[1]++, h => h.AltosFilas[1]++
        })
        {
            var estructura = MYGProyectoStorage.Copia(consultada); cambiar(estructura);
            Rechaza(() => Guardar(original, estructura),
                "Ignorar marcadores MYG permitió un cambio estructural o de configuración real que no se puede conservar.");
        }
        Exige(File.ReadAllBytes(ruta).Length > 0 && original.SequenceEqual(Guardar(original, Leer(original, "G16"))),
            "Un rechazo modificó el BLOB original.");
        pasa("El intercambio nativo rechaza totales ambiguos, campos y formatos desconocidos y cambios no conservables sin modificar el original");
    }

    private static MYGHojaMetrado Leer(byte[] bytes, string total) => Invocar<MYGHojaMetrado>("Leer", bytes, total);
    private static byte[] Guardar(byte[] bytes, MYGHojaMetrado hoja) => Invocar<byte[]>("Guardar", bytes, hoja);
    private static T Invocar<T>(string nombre, params object[] argumentos)
    {
        try { return (T)Codec.GetMethod(nombre, BindingFlags.NonPublic | BindingFlags.Static).Invoke(null, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
    private static void Rechaza(Action accion, string mensaje)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new Exception(mensaje);
    }
    private static byte[] Modificar(byte[] bytes, Action<ZipArchive> accion)
    {
        using var flujo = new MemoryStream(); flujo.Write(bytes); flujo.Position = 0;
        using (var zip = new ZipArchive(flujo, ZipArchiveMode.Update, true)) accion(zip);
        return flujo.ToArray();
    }
    private static byte[] Parte(ZipArchive zip, string nombre)
    { using var flujo = zip.GetEntry(nombre).Open(); using var salida = new MemoryStream(); flujo.CopyTo(salida); return salida.ToArray(); }
    private static XDocument LeerXml(ZipArchive zip, string nombre)
    { using var flujo = zip.GetEntry(nombre).Open(); return XDocument.Load(flujo); }
    private static void EscribirXml(ZipArchive zip, string nombre, XDocument xml)
    { zip.GetEntry(nombre)?.Delete(); using var flujo = zip.CreateEntry(nombre).Open(); xml.Save(flujo); }
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
}
