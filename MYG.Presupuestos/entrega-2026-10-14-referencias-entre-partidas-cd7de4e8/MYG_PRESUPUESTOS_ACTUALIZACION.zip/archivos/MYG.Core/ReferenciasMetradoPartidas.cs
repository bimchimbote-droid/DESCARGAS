using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace MYG_2027;

/// <summary>El nombre visible de la fórmula se guarda separado de la identidad de la partida.</summary>
public sealed class MYGReferenciaMetradoPartida
{
    public string Alias { get; set; } = "";
    public string DireccionFormula { get; set; } = "";
    public string PresupuestoId { get; set; } = "";
    public string PartidaLocalId { get; set; } = "";
    public string AnclaId { get; set; } = "";
    // Una selección pendiente vive únicamente en la copia del editor. Confirmarla
    // registra el ancla en la hoja original; cancelarla no cambia ninguna hoja.
    [JsonIgnore] internal bool Pendiente { get; set; }
}

/// <summary>Una celda origen mantiene su identidad al insertar o mover filas y columnas.</summary>
public sealed class MYGAnclaMetrado
{
    public string Id { get; set; } = "";
    // Vacía significa que se eliminó la celda. No se reutiliza su antigua posición.
    public string Direccion { get; set; } = "";
}

internal sealed class MYGErrorReferenciaMetrado : FormatException
{
    internal MYGErrorReferenciaMetrado(string mensaje) : base("#REF! " + mensaje) { }
}

/// <summary>Referencias dentro del proyecto, sin libros externos, macros ni registro global.</summary>
public static class MYGReferenciasMetrado
{
    private static readonly Regex Llamada = new(
        @"(?<![A-Za-z0-9_.])METRADO\s*\(\s*""(?<alias>(?:[^""]|"""")*)""\s*[;,]\s*""(?<dir>(?:[^""]|"""")*)""\s*\)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>Vincula las hojas al proyecto actual. Debe repetirse al agregar o sustituir presupuestos.</summary>
    public static void Vincular(IEnumerable<MYGPresupuestoDocumento> presupuestos)
    {
        var contexto = new MYGContextoReferenciasMetrado(presupuestos);
        foreach (var p in contexto.Presupuestos) contexto.Asociar(p);
    }

    /// <summary>Actualiza las fórmulas destino después de publicar una hoja editada por copia.
    /// Primero sustituya la hoja de la partida y vincule nuevamente los presupuestos.</summary>
    public static void SincronizarOrigen(MYGHojaMetrado origen)
    {
        if (origen == null) throw new ArgumentNullException(nameof(origen));
        if (origen.EsCopiaReferencias) MYGReferenciasMetrado.ActualizarDirecciones(origen, origen);
        else origen.ContextoReferencias?.ActualizarDirecciones(origen);
    }

    /// <summary>Fragmento para la barra de fórmulas, sin signo = y con nombres legibles.</summary>
    public static string CrearReferencia(MYGHojaMetrado destino, MYGPresupuestoDocumento origenPresupuesto,
        ItemPresupuestoDelphin origenPartida, string direccion)
    {
        if (destino == null || origenPresupuesto == null || origenPartida == null ||
            MYGProyectoStorage.EsTitulo(origenPartida) || !origenPresupuesto.Items.Contains(origenPartida))
            throw new InvalidDataException("Seleccione una partida y una celda de su metrado.");
        if (string.IsNullOrWhiteSpace(origenPartida.IdLocalMYG)) origenPartida.IdLocalMYG = MYGProyectoStorage.NuevoId();
        var contexto = destino.ContextoReferencias ?? origenPresupuesto.ContextoReferencias ??
            new MYGContextoReferenciasMetrado(new[] { origenPresupuesto });
        destino.ContextoReferencias ??= contexto;
        var origen = contexto.Hoja(origenPresupuesto.Id, origenPartida.IdLocalMYG) ?? origenPartida.Costos?.Hoja;
        if (origen == null) throw new InvalidDataException("La partida seleccionada no tiene hoja de metrado.");
        direccion = MYGHojaCalculo.Normalizar(direccion);
        var pos = MYGHojaCalculo.Coordenadas(direccion);
        if (pos.Fila > origen.Filas || pos.Columna > origen.Columnas)
            throw new InvalidDataException("La celda seleccionada está fuera del metrado de origen.");
        destino.ReferenciasPartidas ??= new(); origen.AnclasReferencias ??= new();
        // Una copia del editor puede haberse creado antes de publicar un cambio
        // estructural en el origen. Resolver por el ancla actual evita reutilizar
        // la referencia antigua para una celda nueva en la misma dirección.
        ActualizarDirecciones(destino, origen);
        var existente = destino.ReferenciasPartidas.FirstOrDefault(r => Igual(r.PresupuestoId, origenPresupuesto.Id) &&
            Igual(r.PartidaLocalId, origenPartida.IdLocalMYG) && Igual(r.DireccionFormula, direccion) &&
            origen.AnclasReferencias.Any(a => Igual(a.Id, r.AnclaId) && Igual(a.Direccion, direccion)));
        existente ??= destino.ReferenciasPartidas.FirstOrDefault(r => r.Pendiente && Igual(r.PresupuestoId, origenPresupuesto.Id) &&
            Igual(r.PartidaLocalId, origenPartida.IdLocalMYG) && Igual(r.DireccionFormula, direccion));
        if (existente != null) return Fragmento(existente.Alias, existente.DireccionFormula);
        string aliasBase = Etiqueta(origenPresupuesto, origenPartida);
        string alias = destino.ReferenciasPartidas.FirstOrDefault(r => Igual(r.PresupuestoId, origenPresupuesto.Id) &&
            Igual(r.PartidaLocalId, origenPartida.IdLocalMYG))?.Alias ?? aliasBase;
        int numero = 2;
        while (destino.ReferenciasPartidas.Any(r => Igual(r.Alias, alias) &&
            (!Igual(r.PresupuestoId, origenPresupuesto.Id) || !Igual(r.PartidaLocalId, origenPartida.IdLocalMYG) || Igual(r.DireccionFormula, direccion))))
            alias = aliasBase + " (" + numero++ + ")";
        var ancla = origen.AnclasReferencias.FirstOrDefault(a => Igual(a.Direccion, direccion));
        bool pendiente = destino.EsCopiaReferencias;
        string anclaId = ancla?.Id ?? MYGProyectoStorage.NuevoId();
        if (ancla == null && !pendiente) origen.AnclasReferencias.Add(new() { Id = anclaId, Direccion = direccion });
        var referencia = new MYGReferenciaMetradoPartida { Alias = alias, DireccionFormula = direccion,
            PresupuestoId = origenPresupuesto.Id, PartidaLocalId = origenPartida.IdLocalMYG,
            AnclaId = anclaId, Pendiente = pendiente };
        destino.ReferenciasPartidas.Add(referencia);
        return Fragmento(alias, direccion);
    }

    /// <summary>Confirma los vínculos seleccionados en una copia del editor, sin copiar celdas ni formatos.</summary>
    public static void AplicarReferenciasPendientes(MYGHojaMetrado destino, MYGHojaMetrado borrador)
        => AplicarReferenciasPendientes(destino, borrador, null);

    /// <summary>Confirma únicamente los vínculos pendientes que permanecen en la fórmula escrita.</summary>
    public static void AplicarReferenciasPendientes(MYGHojaMetrado destino, MYGHojaMetrado borrador, string formulaFinal)
    {
        if (destino == null || borrador == null) throw new ArgumentNullException(nameof(destino));
        var contexto = destino.ContextoReferencias ?? borrador.ContextoReferencias;
        var nuevos = new List<MYGReferenciaMetradoPartida>();
        var anclas = new List<(MYGHojaMetrado Hoja, MYGAnclaMetrado Ancla)>();
        foreach (var r in borrador.ReferenciasPartidas ?? new())
        {
            if (r.Pendiente && formulaFinal != null && !UsaReferencia(formulaFinal, r)) continue;
            var copia = CopiarReferencia(r);
            if (r.Pendiente)
            {
                var origen = contexto?.Hoja(r.PresupuestoId, r.PartidaLocalId) ??
                    throw new MYGErrorReferenciaMetrado("La partida seleccionada ya no existe. Seleccione otra celda.");
                var pos = MYGHojaCalculo.Coordenadas(r.DireccionFormula);
                if (pos.Fila > origen.Filas || pos.Columna > origen.Columnas)
                    throw new MYGErrorReferenciaMetrado("La celda seleccionada ya no existe. Seleccione otra celda.");
                origen.AnclasReferencias ??= new();
                var existente = origen.AnclasReferencias.FirstOrDefault(a => Igual(a.Direccion, r.DireccionFormula));
                if (existente != null) copia.AnclaId = existente.Id;
                else anclas.Add((origen, new() { Id = copia.AnclaId, Direccion = r.DireccionFormula }));
            }
            copia.Pendiente = false; nuevos.Add(copia);
        }
        // La comprobación anterior es íntegra: ningún ancla se publica a medias.
        foreach (var a in anclas)
            if (!a.Hoja.AnclasReferencias.Any(x => Igual(x.Id, a.Ancla.Id))) a.Hoja.AnclasReferencias.Add(a.Ancla);
        destino.ReferenciasPartidas = nuevos;
        destino.ContextoReferencias ??= contexto;
    }

    private static bool UsaReferencia(string formula, MYGReferenciaMetradoPartida referencia)
    {
        bool literal = false;
        for (int i = 0; i < formula.Length; i++)
        {
            if (!literal)
            {
                Match llamada = Llamada.Match(formula, i);
                if (llamada.Success && llamada.Index == i)
                {
                    string alias = llamada.Groups["alias"].Value.Replace("\"\"", "\"");
                    string dir = llamada.Groups["dir"].Value.Replace("\"\"", "\"");
                    if (Igual(alias, referencia.Alias) && Igual(MYGHojaCalculo.Normalizar(dir), referencia.DireccionFormula)) return true;
                    i += llamada.Length - 1; continue;
                }
            }
            if (formula[i] != '"') continue;
            if (literal && i + 1 < formula.Length && formula[i + 1] == '"') i++;
            else literal = !literal;
        }
        return false;
    }

    private static MYGReferenciaMetradoPartida CopiarReferencia(MYGReferenciaMetradoPartida r) => new()
    { Alias = r.Alias, DireccionFormula = r.DireccionFormula, PresupuestoId = r.PresupuestoId,
        PartidaLocalId = r.PartidaLocalId, AnclaId = r.AnclaId, Pendiente = r.Pendiente };
    internal static bool Igual(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    private static string Etiqueta(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i)
    {
        string nombre = ((p.Item ?? "").Trim() + " " + (p.Nombre ?? "").Trim()).Trim();
        string partida = ((i.Item ?? "").Trim() + " - " + (i.Descripcion ?? "").Trim()).Trim(' ', '-');
        string texto = (nombre.Length == 0 ? "" : nombre + " / ") + partida;
        texto = string.Join(" ", texto.Split((char[])null, StringSplitOptions.RemoveEmptyEntries));
        return texto.Length <= 200 ? texto : texto[..197] + "…";
    }
    private static string Literal(string s) => "\"" + s.Replace("\"", "\"\"") + "\"";
    private static string Fragmento(string alias, string direccion) => "METRADO(" + Literal(alias) + ";" + Literal(direccion) + ")";

    internal static void Validar(MYGHojaMetrado h)
    {
        h.ReferenciasPartidas ??= new(); h.AnclasReferencias ??= new();
        if (h.ReferenciasPartidas.Count > 200000 || h.AnclasReferencias.Count > 200000)
            throw new InvalidDataException("La hoja contiene demasiadas referencias a partidas.");
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var a in h.AnclasReferencias)
        {
            if (a == null || string.IsNullOrWhiteSpace(a.Id) || a.Id.Length > 128 || !ids.Add(a.Id) || a.Direccion == null)
                throw new InvalidDataException("Ancla de metrado no válida o duplicada.");
            if (a.Direccion.Length == 0) continue;
            a.Direccion = MYGHojaCalculo.Normalizar(a.Direccion);
            var pos = MYGHojaCalculo.Coordenadas(a.Direccion);
            if (pos.Fila > h.Filas || pos.Columna > h.Columnas) throw new InvalidDataException("Ancla fuera de la hoja de metrado.");
        }
        var claves = new HashSet<(string, string)>();
        foreach (var r in h.ReferenciasPartidas)
        {
            if (r == null || string.IsNullOrWhiteSpace(r.Alias) || r.Alias.Length > 240 ||
                string.IsNullOrWhiteSpace(r.PresupuestoId) || r.PresupuestoId.Length > 128 ||
                string.IsNullOrWhiteSpace(r.PartidaLocalId) || r.PartidaLocalId.Length > 128 ||
                string.IsNullOrWhiteSpace(r.AnclaId) || r.AnclaId.Length > 128)
                throw new InvalidDataException("Referencia a partida incompleta.");
            r.DireccionFormula = MYGHojaCalculo.Normalizar(r.DireccionFormula);
            if (r.DireccionFormula != "#REF!") MYGHojaCalculo.Coordenadas(r.DireccionFormula);
            if (!claves.Add((r.Alias.ToUpperInvariant(), r.DireccionFormula)))
                throw new InvalidDataException("Referencia a partida duplicada.");
        }
    }

    internal static void ReubicarAnclas(MYGHojaMetrado hoja, Func<string, string> reubicar)
    {
        foreach (var ancla in hoja.AnclasReferencias ?? new())
            if (!string.IsNullOrEmpty(ancla.Direccion))
            {
                string nueva = reubicar(ancla.Direccion);
                ancla.Direccion = nueva == "#REF!" ? "" : MYGHojaCalculo.Normalizar(nueva);
            }
    }

    /// <summary>Detecta una llamada real; la palabra METRADO dentro de un texto no es una referencia.</summary>
    public static bool ContieneReferencia(string formula)
    {
        if (!(formula ?? "").TrimStart().StartsWith('=')) return false;
        bool literal = false;
        for (int i = 0; i < formula.Length; i++)
        {
            if (formula[i] == '"')
            {
                if (literal && i + 1 < formula.Length && formula[i + 1] == '"') i++;
                else literal = !literal;
            }
            else if (!literal && (i == 0 || !char.IsLetterOrDigit(formula[i - 1]) && formula[i - 1] is not '_' and not '.') &&
                formula.AsSpan(i).StartsWith("METRADO", StringComparison.OrdinalIgnoreCase))
            {
                int fin = i + 7; while (fin < formula.Length && char.IsWhiteSpace(formula[fin])) fin++;
                if (fin < formula.Length && formula[fin] == '(') return true;
            }
        }
        return false;
    }

    internal static void ActualizarDirecciones(MYGHojaMetrado destino, MYGHojaMetrado origen)
    {
        var cambios = new Dictionary<(string Alias, string Direccion), string>();
        foreach (var r in destino.ReferenciasPartidas ?? new())
        {
            if (!Igual(r.PresupuestoId, origen.PresupuestoReferenciasId) || !Igual(r.PartidaLocalId, origen.PartidaReferenciasId)) continue;
            var ancla = origen.AnclasReferencias.FirstOrDefault(a => Igual(a.Id, r.AnclaId));
            if (ancla == null) continue;
            string nueva = string.IsNullOrEmpty(ancla.Direccion) ? "#REF!" : ancla.Direccion;
            if (Igual(nueva, r.DireccionFormula)) continue;
            cambios[(r.Alias.ToUpperInvariant(), r.DireccionFormula)] = nueva;
            r.DireccionFormula = nueva;
        }
        if (cambios.Count == 0) return;
        // Varias celdas eliminadas de la misma partida convergen al mismo
        // #REF! visible. Ese error comparte un único registro, nunca una celda viva.
        destino.ReferenciasPartidas = destino.ReferenciasPartidas
            .GroupBy(r => (r.Alias.ToUpperInvariant(), r.DireccionFormula))
            .Select(g => g.First()).ToList();
        foreach (var celda in destino.Celdas.Values)
        {
            string formula = celda.Contenido;
            if (!(formula ?? "").TrimStart().StartsWith('=')) continue;
            var texto = new StringBuilder(); bool literal = false;
            for (int i = 0; i < formula.Length; i++)
            {
                if (!literal)
                {
                    Match llamada = Llamada.Match(formula, i);
                    if (llamada.Success && llamada.Index == i)
                    {
                        string alias = llamada.Groups["alias"].Value.Replace("\"\"", "\""), dir = MYGHojaCalculo.Normalizar(llamada.Groups["dir"].Value.Replace("\"\"", "\""));
                        texto.Append(cambios.TryGetValue((alias.ToUpperInvariant(), dir), out string nueva) ? Fragmento(alias, nueva) : llamada.Value);
                        i += llamada.Length - 1; continue;
                    }
                }
                char c = formula[i]; texto.Append(c);
                if (c == '"')
                {
                    if (literal && i + 1 < formula.Length && formula[i + 1] == '"') texto.Append(formula[++i]);
                    else literal = !literal;
                }
            }
            celda.Contenido = texto.ToString();
        }
    }

    internal static void PrepararPresupuesto(MYGPresupuestoDocumento p)
    {
        foreach (var i in p.Items ?? new())
        {
            if (i == null) continue;
            i.Costos ??= new MYGDatosPartida(); i.Costos.Hoja ??= MYGHojaMetrado.Crear();
        }
        var contexto = p.ContextoReferencias?.ConPresupuesto(p) ?? new MYGContextoReferenciasMetrado(new[] { p });
        contexto.Asociar(p);
    }

    internal static void PrepararPlantilla(MYGPresupuestoDocumento original, MYGPresupuestoDocumento copia)
    {
        var presupuestos = original.ContextoReferencias?.Presupuestos ?? new[] { original };
        var contexto = new MYGContextoReferenciasMetrado(presupuestos.Concat(new[] { copia }), aislado: true);
        contexto.Asociar(copia);
    }

    internal static void ConservarContexto(object original, object copia)
    {
        if (original is MYGProyectoDocumento && copia is MYGProyectoDocumento proyecto)
            Vincular(proyecto.Presupuestos);
        else if (original is MYGPresupuestoDocumento p && copia is MYGPresupuestoDocumento cp)
        {
            var contexto = p.ContextoReferencias?.ConPresupuesto(cp) ?? new MYGContextoReferenciasMetrado(new[] { cp });
            contexto.Asociar(cp);
        }
        else if (original is MYGHojaMetrado h && copia is MYGHojaMetrado ch)
        {
            ch.PresupuestoReferenciasId = h.PresupuestoReferenciasId; ch.PartidaReferenciasId = h.PartidaReferenciasId;
            ch.ContextoReferencias = h.ContextoReferencias?.ConHoja(ch);
            ch.EsCopiaReferencias = true;
            for (int i = 0; i < Math.Min(h.ReferenciasPartidas?.Count ?? 0, ch.ReferenciasPartidas?.Count ?? 0); i++)
                ch.ReferenciasPartidas[i].Pendiente = h.ReferenciasPartidas[i].Pendiente;
        }
    }
}

internal sealed class MYGContextoReferenciasMetrado
{
    internal IReadOnlyList<MYGPresupuestoDocumento> Presupuestos { get; }
    private readonly Dictionary<(string Presupuesto, string Partida), MYGHojaMetrado> sustituciones;
    private readonly bool aislado;
    private static (string, string) Clave(string presupuesto, string partida) => ((presupuesto ?? "").ToUpperInvariant(), (partida ?? "").ToUpperInvariant());
    internal MYGContextoReferenciasMetrado(IEnumerable<MYGPresupuestoDocumento> presupuestos,
        Dictionary<(string, string), MYGHojaMetrado> sustituciones = null, bool aislado = false)
    {
        Presupuestos = (presupuestos ?? Enumerable.Empty<MYGPresupuestoDocumento>()).Where(p => p != null).ToArray();
        this.sustituciones = sustituciones ?? new();
        this.aislado = aislado;
    }
    internal void Asociar(MYGPresupuestoDocumento p)
    {
        p.ContextoReferencias = this;
        foreach (var i in p.Items ?? new())
        {
            if (i == null) continue;
            var h = i.Costos?.Hoja; if (h == null) continue;
            h.ContextoReferencias = this; h.PresupuestoReferenciasId = p.Id; h.PartidaReferenciasId = i.IdLocalMYG ?? i.Id;
            h.EsCopiaReferencias = false;
        }
    }
    internal MYGContextoReferenciasMetrado ConPresupuesto(MYGPresupuestoDocumento presupuesto)
    {
        var lista = Presupuestos.Select(p => MYGReferenciasMetrado.Igual(p.Id, presupuesto.Id) ? presupuesto : p).ToList();
        if (!lista.Contains(presupuesto)) lista.Add(presupuesto);
        var reemplazos = sustituciones.Where(x => !MYGReferenciasMetrado.Igual(x.Key.Presupuesto, presupuesto.Id)).ToDictionary(x => x.Key, x => x.Value);
        bool reemplazo = Presupuestos.Any(p => MYGReferenciasMetrado.Igual(p.Id, presupuesto.Id) && !ReferenceEquals(p, presupuesto));
        return new(lista, reemplazos, aislado || reemplazo);
    }
    internal MYGContextoReferenciasMetrado ConHoja(MYGHojaMetrado hoja)
    {
        var nuevos = new Dictionary<(string, string), MYGHojaMetrado>(sustituciones);
        if (!string.IsNullOrEmpty(hoja.PresupuestoReferenciasId) && !string.IsNullOrEmpty(hoja.PartidaReferenciasId))
            nuevos[Clave(hoja.PresupuestoReferenciasId, hoja.PartidaReferenciasId)] = hoja;
        return new(Presupuestos, nuevos, true);
    }
    internal MYGHojaMetrado Hoja(string presupuestoId, string partidaId)
    {
        var p = Presupuestos.FirstOrDefault(p => MYGReferenciasMetrado.Igual(p.Id, presupuestoId));
        var i = p?.Items?.FirstOrDefault(i => i != null && !MYGProyectoStorage.EsTitulo(i) && MYGReferenciasMetrado.Igual(i.IdLocalMYG ?? i.Id, partidaId));
        if (i == null) return null;
        return sustituciones.TryGetValue(Clave(presupuestoId, partidaId), out var reemplazo) ? reemplazo : i.Costos?.Hoja;
    }
    internal (MYGHojaMetrado Hoja, string Direccion) Resolver(MYGHojaMetrado destino, string alias, string direccion)
    {
        direccion = MYGHojaCalculo.Normalizar(direccion);
        var r = destino.ReferenciasPartidas?.FirstOrDefault(r => MYGReferenciasMetrado.Igual(r.Alias, alias) && MYGReferenciasMetrado.Igual(r.DireccionFormula, direccion)) ??
            throw new MYGErrorReferenciaMetrado("El vínculo «" + alias + "», celda " + direccion + ", no está registrado. Use Referenciar otra partida.");
        var origen = Hoja(r.PresupuestoId, r.PartidaLocalId) ??
            throw new MYGErrorReferenciaMetrado("La partida de origen «" + alias + "» fue eliminada o no pertenece a este proyecto.");
        var ancla = origen.AnclasReferencias?.FirstOrDefault(a => MYGReferenciasMetrado.Igual(a.Id, r.AnclaId));
        if (ancla == null && r.Pendiente) return (origen, direccion);
        if (ancla == null || string.IsNullOrEmpty(ancla.Direccion))
            throw new MYGErrorReferenciaMetrado("La celda de origen «" + alias + "», " + direccion + ", fue eliminada o su hoja fue sustituida.");
        return (origen, ancla.Direccion);
    }
    internal void ActualizarDirecciones(MYGHojaMetrado origen)
    {
        foreach (var p in Presupuestos)
            foreach (var i in p.Items ?? new())
            {
                var h = i == null ? null : Hoja(p.Id, i.IdLocalMYG ?? i.Id);
                if (h != null && (!aislado || ReferenceEquals(h.ContextoReferencias, this)))
                    MYGReferenciasMetrado.ActualizarDirecciones(h, origen);
            }
    }
}

// Una sesión comparte caché y pila entre todas las hojas. Se crea al construir
// MYGHojaCalculo: nunca sobrevive en el proyecto ni reutiliza valores guardados.
internal sealed class MYGSesionHojaCalculo
{
    private readonly MYGContextoReferenciasMetrado contexto;
    private readonly Dictionary<(MYGHojaMetrado Hoja, string Celda), MYGValorExcel> cache = new();
    private readonly HashSet<(MYGHojaMetrado Hoja, string Celda)> camino = new();
    internal MYGSesionHojaCalculo(MYGContextoReferenciasMetrado contexto) { this.contexto = contexto; }
    internal MYGValorExcel Resultado(MYGHojaMetrado hoja, string direccion)
    {
        direccion = MYGHojaCalculo.Normalizar(direccion); var pos = MYGHojaCalculo.Coordenadas(direccion);
        if (pos.Fila > hoja.Filas || pos.Columna > hoja.Columnas) throw new InvalidDataException("Referencia fuera de la hoja: " + direccion);
        var clave = (hoja, direccion);
        if (cache.TryGetValue(clave, out var valor)) return valor;
        if (camino.Count >= 128 || !camino.Add(clave))
            throw new InvalidDataException("Fórmula circular o demasiado profunda entre hojas de metrado: " + direccion);
        try
        {
            string texto = hoja.Celdas.TryGetValue(direccion, out var c) ? c.Contenido ?? "" : "", recortado = texto.Trim();
            if (texto.Length == 0) valor = default;
            else if (recortado.StartsWith('=')) valor = new MYGMotorFormulaExcel(recortado, hoja,
                d => Resultado(hoja, d), (alias, d) =>
                {
                    var origen = (contexto ?? throw new MYGErrorReferenciaMetrado("Abra el proyecto completo para resolver el vínculo a otra partida."))
                        .Resolver(hoja, alias, d);
                    return Resultado(origen.Hoja, origen.Direccion);
                }).Calcular();
            else if (MYGHojaCalculo.IntentarNumero(recortado, out decimal numero)) valor = new MYGValorExcel(numero);
            else valor = new MYGValorExcel(texto);
            cache[clave] = valor; return valor;
        }
        finally { camino.Remove(clave); }
    }
}
