using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace MYG_2027;

/// <summary>Operaciones de hoja sin automatización de Office. Los cambios estructurales se validan antes de aplicarse.</summary>
public static class MYGEdicionHoja
{
    private static readonly Regex Referencias = new(@"(?<![A-Za-z0-9_.$!])(?<a>\$?[A-Za-z]{1,3}\$?[1-9][0-9]{0,6})(?:\s*:\s*(?<b>\$?[A-Za-z]{1,3}\$?[1-9][0-9]{0,6}))?(?![A-Za-z0-9_.!]|\s*\()", RegexOptions.Compiled);
    private static readonly Regex PartesReferencia = new(@"^(?<ca>\$?)(?<c>[A-Za-z]{1,3})(?<fa>\$?)(?<f>[1-9][0-9]{0,6})$", RegexOptions.Compiled);
    public static MYGCeldaHoja Celda(MYGHojaMetrado h, string direccion)
    {
        direccion = MYGHojaCalculo.Normalizar(direccion); Dentro(h, direccion);
        if (!h.Celdas.TryGetValue(direccion, out var celda)) h.Celdas[direccion] = celda = new()
        { AlineacionHorizontal = MYGHojaCalculo.Coordenadas(direccion).Columna == 1 ? "Izquierda" : "Centro", FormatoNumero = h.FormatoNumeroPredeterminado };
        return celda;
    }
    public static string AlineacionCelda(MYGCeldaHoja celda, string direccion)
    {
        if (celda != null && (celda.AlineacionPersonalizada || celda.AlineacionHorizontal != "Izquierda")) return celda.AlineacionHorizontal;
        return MYGHojaCalculo.Coordenadas(direccion).Columna == 1 ? "Izquierda" : "Centro";
    }
    public static MYGCeldaHoja CopiarCelda(MYGCeldaHoja celda) => MYGProyectoStorage.Copia(celda ?? new MYGCeldaHoja());
    public static bool RepararCabeceraMetrado(MYGHojaMetrado h)
    {
        if (h == null || h.Filas < 2 || h.Columnas < 8) return false;
        bool Etiqueta(string dir, string texto) => h.Celdas != null && h.Celdas.TryGetValue(dir, out var celda) &&
            string.Equals(celda?.Contenido?.Trim(), texto, StringComparison.OrdinalIgnoreCase);
        if (!Etiqueta("A1", "Datos") || !Etiqueta("D1", "Dimensiones") || !Etiqueta("G1", "Total") ||
            !Etiqueta("A2", "Descripción") || !Etiqueta("B2", "Elementos") || !Etiqueta("G2", "Parcial")) return false;
        string[] grupos = ["A1:C1", "D1:F1", "G1:H1"];
        if (h.RangosCombinados != null && grupos.All(g => h.RangosCombinados.Contains(g, StringComparer.OrdinalIgnoreCase))) return false;
        var copia = MYGProyectoStorage.Copia(h);
        MYGHojaCalculo.Validar(copia);
        var gruposCeldas = grupos.Select(g => Direcciones(copia, g).ToHashSet(StringComparer.OrdinalIgnoreCase)).ToArray();
        foreach (string grupo in grupos)
            if (Direcciones(copia, grupo).Skip(1).Any(d => copia.Celdas.TryGetValue(d, out var c) && !string.IsNullOrEmpty(c.Contenido)))
                return false; // Combining must not conceal user data.
        foreach (string existente in copia.RangosCombinados)
        {
            var celdas = Direcciones(copia, existente).ToArray();
            foreach (var grupo in gruposCeldas)
                if (celdas.Any(grupo.Contains) && !celdas.All(grupo.Contains)) return false;
        }
        // A smaller combination contained in one title can safely expand.
        copia.RangosCombinados.RemoveAll(r => gruposCeldas.Any(g => Direcciones(copia, r).All(g.Contains)));
        copia.RangosCombinados.AddRange(grupos);
        MYGHojaCalculo.Validar(copia);
        h.RangosCombinados = copia.RangosCombinados;
        return true;
    }
    /// <summary>Completa el relleno omitido en la cabecera estándar guardada, conservando los fondos explícitos.</summary>
    public static bool RepararRellenoCabeceraMetrado(MYGHojaMetrado h)
    {
        // La identidad explícita diferencia las hojas propias de las importadas.
        // Las posiciones y etiquetas evitan aplicar el formato a una estructura
        // que el usuario haya desplazado o convertido en otra hoja.
        if (h == null || h.RellenoCabeceraEstandarAplicado || h.IdPlantilla != MYGPlantillasMetrado.Estandar ||
            h.Filas < 2 || h.Columnas < 8 || h.Celdas == null || h.RangosCombinados == null) return false;
        bool Etiqueta(string dir, string texto) => h.Celdas.TryGetValue(dir, out var c) &&
            string.Equals(c?.Contenido?.Trim(), texto, StringComparison.OrdinalIgnoreCase);
        string[] titulos = ["Descripción", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Parcial", "Plano / Referencia"];
        string[] grupos = ["A1:C1", "D1:F1", "G1:H1"];
        if (!Etiqueta("A1", "Datos") || !Etiqueta("D1", "Dimensiones") || !Etiqueta("G1", "Total") ||
            !titulos.Select((texto, indice) => Etiqueta(MYGHojaCalculo.Columna(indice + 1) + "2", texto)).All(x => x) ||
            !grupos.All(g => h.RangosCombinados.Contains(g, StringComparer.OrdinalIgnoreCase)) ||
            grupos.SelectMany(g => Direcciones(h, g).Skip(1)).Any(d => h.Celdas.TryGetValue(d, out var c) && !string.IsNullOrEmpty(c.Contenido))) return false;
        foreach (string dir in Direcciones(h, "A1:H2"))
        {
            var c = Celda(h, dir);
            if (string.IsNullOrEmpty(c.ColorFondo)) c.ColorFondo = "EFF9FC";
        }
        h.RellenoCabeceraEstandarAplicado = true;
        return true;
    }
    /// <summary>El total estándar conserva su cero visible aunque los parciales vacíos usen guiones.</summary>
    public static bool RepararFormatoTotalMetrado(MYGHojaMetrado h)
    {
        if (h?.IdPlantilla != MYGPlantillasMetrado.Estandar || h.Celdas == null ||
            !h.Celdas.TryGetValue(MYGHojaCalculo.Normalizar(h.CeldaTotal), out var total) ||
            total == null || total.FormatoNumero != "0.00;-0.00;-") return false;
        total.FormatoNumero = "0.00";
        return true;
    }
    public static string NormalizarRango(string rango)
    {
        var partes = (rango ?? "").Split(':');
        if (partes.Length is < 1 or > 2) throw new InvalidDataException("Indique un rango como A1:H16.");
        try
        {
            var a = MYGHojaCalculo.Coordenadas(partes[0]); var b = MYGHojaCalculo.Coordenadas(partes[^1]);
            string primero = MYGHojaCalculo.Columna(Math.Min(a.Columna, b.Columna)) + Math.Min(a.Fila, b.Fila);
            string ultimo = MYGHojaCalculo.Columna(Math.Max(a.Columna, b.Columna)) + Math.Max(a.Fila, b.Fila);
            return primero == ultimo ? primero : primero + ":" + ultimo;
        }
        catch (FormatException ex) { throw new InvalidDataException("Rango no válido: " + rango, ex); }
    }
    public static IEnumerable<string> Direcciones(MYGHojaMetrado h, string rango)
    {
        var (f1, c1, f2, c2) = Limites(h, rango);
        for (int f = f1; f <= f2; f++) for (int c = c1; c <= c2; c++) yield return MYGHojaCalculo.Columna(c) + f;
    }
    internal static void ValidarFormato(MYGCeldaHoja c)
    {
        if (string.IsNullOrWhiteSpace(c.Fuente) || c.Fuente.Length > 128 || c.TamanoFuente < 1 || c.TamanoFuente > 409 ||
            !ColorValido(c.ColorTexto) || !ColorValido(c.ColorFondo) || c.FormatoNumero == null || c.FormatoNumero.Length > 255 ||
            c.AlineacionHorizontal is not ("Izquierda" or "Centro" or "Derecha") || c.AlineacionVertical is not ("Arriba" or "Centro" or "Abajo"))
            throw new InvalidDataException("Formato de celda no válido.");
        c.ListaValores ??= new();
        if (c.TipoValidacion is not ("Ninguna" or "Numero" or "Entero" or "Lista") ||
            (c.Minimo.HasValue && c.Maximo.HasValue && c.Minimo > c.Maximo) || c.ListaValores.Count > 100 ||
            c.ListaValores.Any(x => string.IsNullOrEmpty(x) || x.Length > 255 || x.Contains(',') || x.Contains('"') || x.Contains('\r') || x.Contains('\n')) ||
            string.Join(',', c.ListaValores).Length > 253 || (c.TipoValidacion == "Lista" && c.ListaValores.Count == 0))
            throw new InvalidDataException("Regla de validación no válida. Las listas admiten hasta 253 caracteres, sin comas ni comillas.");
    }
    private static bool ColorValido(string color) => string.IsNullOrEmpty(color) || Regex.IsMatch(color, @"^#?[0-9a-fA-F]{6}$");
    internal static void ValidarConfiguracion(MYGHojaMetrado h)
    {
        if (h.FormatoNumeroPredeterminado == null || h.FormatoNumeroPredeterminado.Length > 255)
            throw new InvalidDataException("Formato numérico predeterminado no válido.");
        if (h.Zoom < 10 || h.Zoom > 400 || h.FilasInmovilizadas < 0 || h.FilasInmovilizadas > h.Filas ||
            h.ColumnasInmovilizadas < 0 || h.ColumnasInmovilizadas > h.Columnas || h.OrientacionPagina is not ("Vertical" or "Horizontal") ||
            h.TamanoPapel is not ("A4" or "A3" or "Carta" or "Oficio")) throw new InvalidDataException("Configuración de vista o página no válida.");
        h.AnchosColumnas ??= new(); h.AltosFilas ??= new(); h.FilasOcultas ??= new();
        if (h.AnchosColumnas.Any(x => x.Key < 1 || x.Key > h.Columnas || x.Value < 8 || x.Value > 2000) ||
            h.AltosFilas.Any(x => x.Key < 1 || x.Key > h.Filas || x.Value < 8 || x.Value > 1000) ||
            h.FilasOcultas.Any(x => x < 1 || x > h.Filas) || h.FilasOcultas.Distinct().Count() != h.FilasOcultas.Count ||
            new[] { h.MargenIzquierdo, h.MargenDerecho, h.MargenSuperior, h.MargenInferior }.Any(x => x < 0 || x > 10))
            throw new InvalidDataException("Dimensiones de filas/columnas o márgenes no válidos.");
        h.RangosCombinados ??= new();
        if (h.RangosCombinados.Count > 10000) throw new InvalidDataException("Demasiadas celdas combinadas.");
        var ocupadas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < h.RangosCombinados.Count; i++)
        {
            string rango = NormalizarRango(h.RangosCombinados[i]); Limites(h, rango);
            if (!rango.Contains(':')) throw new InvalidDataException("Una combinación debe contener al menos dos celdas.");
            foreach (string dir in Direcciones(h, rango)) if (!ocupadas.Add(dir)) throw new InvalidDataException("Los rangos combinados se superponen.");
            h.RangosCombinados[i] = rango;
        }
        if (!string.IsNullOrWhiteSpace(h.AreaImpresion)) { h.AreaImpresion = NormalizarRango(h.AreaImpresion); Limites(h, h.AreaImpresion); }
        if (h.RangoCuerpoPlantilla != null && h.RangoCuerpoPlantilla != "")
        { h.RangoCuerpoPlantilla = NormalizarRango(h.RangoCuerpoPlantilla); Limites(h, h.RangoCuerpoPlantilla); }
    }
    /// <summary>Completa los paréntesis finales al confirmar una fórmula, sin modificar texto entre comillas.</summary>
    public static string CompletarCierreFormula(string contenido)
    {
        if (string.IsNullOrEmpty(contenido)) return contenido ?? "";
        int inicio = 0;
        while (inicio < contenido.Length && char.IsWhiteSpace(contenido[inicio])) inicio++;
        if (inicio == contenido.Length || contenido[inicio] != '=') return contenido;
        int abiertos = 0; char comilla = '\0';
        for (int i = inicio + 1; i < contenido.Length; i++)
        {
            char c = contenido[i];
            if (comilla != '\0')
            {
                if (c != comilla) continue;
                if (i + 1 < contenido.Length && contenido[i + 1] == comilla) i++;
                else comilla = '\0';
            }
            else if (c is '"' or '\'') comilla = c;
            else if (c == '(') abiertos++;
            else if (c == ')' && --abiertos < 0) return contenido;
        }
        // Un literal incompleto o un cierre sobrante requiere corregir la fórmula.
        if (comilla != '\0' || abiertos == 0) return contenido;
        int fin = contenido.Length;
        while (fin > inicio && char.IsWhiteSpace(contenido[fin - 1])) fin--;
        return contenido[..fin] + new string(')', abiertos) + contenido[fin..];
    }
    public static void ValidarEntrada(MYGHojaMetrado h, string direccion, string contenido)
    {
        Dentro(h, direccion);
        if ((contenido?.Length ?? 0) > 32767) throw new InvalidDataException("La celda admite hasta 32.767 caracteres.");
        if (!h.Celdas.TryGetValue(MYGHojaCalculo.Normalizar(direccion), out var c) || c.TipoValidacion == "Ninguna" || string.IsNullOrWhiteSpace(contenido)) return;
        ValidarFormato(c);
        if (c.TipoValidacion == "Lista")
        {
            if (!c.ListaValores.Contains(contenido, StringComparer.OrdinalIgnoreCase)) throw new InvalidDataException("El valor debe pertenecer a la lista de la celda.");
            return;
        }
        decimal numero;
        if ((contenido ?? "").StartsWith('='))
        {
            var copia = MYGProyectoStorage.Copia(h); Celda(copia, direccion).Contenido = contenido;
            try { numero = new MYGHojaCalculo(copia).Numero(direccion); }
            catch (Exception ex) when (ex is FormatException or InvalidDataException or DivideByZeroException or OverflowException)
            { throw new InvalidDataException("La validación numérica necesita una fórmula calculable.", ex); }
        }
        else if (!MYGHojaCalculo.IntentarNumero(contenido, out numero)) throw new InvalidDataException("La celda requiere un número.");
        if ((c.TipoValidacion == "Entero" && numero != decimal.Truncate(numero)) || (c.Minimo.HasValue && numero < c.Minimo) || (c.Maximo.HasValue && numero > c.Maximo))
            throw new InvalidDataException("El número no cumple los límites de validación de la celda.");
    }
    public static string TrasladarFormula(string formula, int deltaFilas, int deltaColumnas) => Transformar(formula, m =>
    {
        string Mover(string referencia)
        {
            var partes = PartesReferencia.Match(referencia); var p = MYGHojaCalculo.Coordenadas(referencia);
            int f = p.Fila + (partes.Groups["fa"].Length == 0 ? deltaFilas : 0), c = p.Columna + (partes.Groups["ca"].Length == 0 ? deltaColumnas : 0);
            return f < 1 || f > 10000 || c < 1 || c > 200 ? "#REF!" : partes.Groups["ca"].Value + MYGHojaCalculo.Columna(c) + partes.Groups["fa"].Value + f;
        }
        string a = Mover(m.Groups["a"].Value); return m.Groups["b"].Success ? a + ":" + Mover(m.Groups["b"].Value) : a;
    });
    private static string Transformar(string formula, MatchEvaluator cambiar)
    {
        if (!(formula ?? "").StartsWith('=')) return formula ?? "";
        // No confundir literales de texto o nombres de funciones con referencias.
        return Regex.Replace(formula, "\"(?:[^\"]|\"\")*\"|[^\"]+", m => m.Value.StartsWith('"') ? m.Value : Referencias.Replace(m.Value, cambiar));
    }
    public static void InsertarFilas(MYGHojaMetrado h, int desde, int cantidad = 1) => Estructura(h, desde, cantidad, true, false);
    public static void EliminarFilas(MYGHojaMetrado h, int desde, int cantidad = 1) => Estructura(h, desde, cantidad, true, true);
    public static void InsertarColumnas(MYGHojaMetrado h, int desde, int cantidad = 1) => Estructura(h, desde, cantidad, false, false);
    public static void EliminarColumnas(MYGHojaMetrado h, int desde, int cantidad = 1) => Estructura(h, desde, cantidad, false, true);
    private static void Estructura(MYGHojaMetrado h, int desde, int cantidad, bool filas, bool eliminar)
    {
        var copia = MYGProyectoStorage.Copia(h); MYGHojaCalculo.Validar(copia);
        string cuerpo = MYGBordesPlantillaMetrado.ObtenerRango(copia);
        int dimension = filas ? copia.Filas : copia.Columnas, limite = filas ? 10000 : 200;
        if (cantidad < 1 || desde < 1 || desde > dimension + (eliminar ? 0 : 1) ||
            (eliminar && ((long)desde + cantidad - 1 > dimension || cantidad >= dimension)) ||
            (!eliminar && ((long)dimension + cantidad > limite || (long)(dimension + cantidad) * (filas ? copia.Columnas : copia.Filas) > 200000)))
            throw new InvalidDataException("La operación excede los límites de la hoja.");
        int final = desde + cantidad - 1;
        int? Mapear(int indice) => !eliminar ? indice >= desde ? indice + cantidad : indice : indice < desde ? indice : indice <= final ? null : indice - cantidad;
        string Referencia(string referencia, int indice)
        {
            var partes = PartesReferencia.Match(referencia); var p = MYGHojaCalculo.Coordenadas(referencia);
            return partes.Groups["ca"].Value + MYGHojaCalculo.Columna(filas ? p.Columna : indice) + partes.Groups["fa"].Value + (filas ? indice : p.Fila);
        }
        string Reubicar(string referencia)
        {
            var p = MYGHojaCalculo.Coordenadas(referencia); int? indice = Mapear(filas ? p.Fila : p.Columna);
            return indice.HasValue ? Referencia(referencia, indice.Value) : "#REF!";
        }
        string Rango(string rango)
        {
            string[] extremos = rango.Split(':'); if (extremos.Length == 1) return Reubicar(rango);
            var p = MYGHojaCalculo.Coordenadas(extremos[0]); var q = MYGHojaCalculo.Coordenadas(extremos[1]);
            int a = filas ? p.Fila : p.Columna, b = filas ? q.Fila : q.Columna;
            if (eliminar)
            {
                int bajo = Math.Min(a, b), alto = Math.Max(a, b);
                if (bajo >= desde && alto <= final) return "#REF!";
                int nuevoBajo = bajo >= desde && bajo <= final ? desde : Mapear(bajo).Value;
                int nuevoAlto = alto >= desde && alto <= final ? desde - 1 : Mapear(alto).Value;
                bool ascendente = a <= b; a = ascendente ? nuevoBajo : nuevoAlto; b = ascendente ? nuevoAlto : nuevoBajo;
            }
            else { a = Mapear(a).Value; b = Mapear(b).Value; }
            return Referencia(extremos[0], a) + ":" + Referencia(extremos[1], b);
        }
        string total = Reubicar(copia.CeldaTotal);
        if (total == "#REF!") throw new InvalidDataException("La operación eliminaría la celda que contiene el metrado total. Seleccione otra celda total antes de eliminarla.");
        copia.Celdas = copia.Celdas.Select(x => (Dir: Reubicar(x.Key), Celda: x.Value)).Where(x => x.Dir != "#REF!").ToDictionary(x => MYGHojaCalculo.Normalizar(x.Dir), x => x.Celda, StringComparer.OrdinalIgnoreCase);
        MYGReferenciasMetrado.ReubicarAnclas(copia, Reubicar);
        foreach (var c in copia.Celdas.Values) c.Contenido = Transformar(c.Contenido, m => Rango(m.Groups["a"].Value + (m.Groups["b"].Success ? ":" + m.Groups["b"].Value : "")));
        copia.CeldaTotal = MYGHojaCalculo.Normalizar(total);
        string cuerpoReubicado = string.IsNullOrEmpty(cuerpo) ? "" : Rango(cuerpo);
        copia.RangoCuerpoPlantilla = cuerpoReubicado == "#REF!" ? "" : cuerpoReubicado;
        copia.RangosCombinados = copia.RangosCombinados.Select(Rango).Where(x => x != "#REF!").Select(NormalizarRango).Where(x => x.Contains(':')).ToList();
        if (!string.IsNullOrWhiteSpace(copia.AreaImpresion)) { string area = Rango(copia.AreaImpresion); copia.AreaImpresion = area == "#REF!" ? "" : NormalizarRango(area); }
        if (filas) { copia.Filas += eliminar ? -cantidad : cantidad; copia.FilasInmovilizadas = Math.Min(copia.Filas, Math.Max(0, Mapear(copia.FilasInmovilizadas) ?? desde - 1)); }
        else { copia.Columnas += eliminar ? -cantidad : cantidad; copia.ColumnasInmovilizadas = Math.Min(copia.Columnas, Math.Max(0, Mapear(copia.ColumnasInmovilizadas) ?? desde - 1)); }
        if (filas)
        {
            copia.AltosFilas = copia.AltosFilas.Where(x => Mapear(x.Key).HasValue).ToDictionary(x => Mapear(x.Key).Value, x => x.Value);
            copia.FilasOcultas = copia.FilasOcultas.Where(x => Mapear(x).HasValue).Select(x => Mapear(x).Value).ToList();
        }
        else copia.AnchosColumnas = copia.AnchosColumnas.Where(x => Mapear(x.Key).HasValue).ToDictionary(x => Mapear(x.Key).Value, x => x.Value);
        Aplicar(h, copia);
    }
    /// <summary>Consulta los contenidos no vacíos que se combinarán, en orden de filas y columnas, sin modificar la hoja.</summary>
    public static IReadOnlyList<(string Direccion, string Contenido)> ContenidosAlCombinar(MYGHojaMetrado h, string rango)
    {
        var copia = MYGProyectoStorage.Copia(h); MYGHojaCalculo.Validar(copia);
        return Contenidos(copia, ValidarCombinacion(copia, NormalizarRango(rango)));
    }
    private static (string Direccion, string Contenido)[] Contenidos(MYGHojaMetrado h, IEnumerable<string> direcciones) =>
        direcciones.Where(d => h.Celdas.TryGetValue(d, out var c) && !string.IsNullOrEmpty(c.Contenido))
            .Select(d => (Direccion: d, Contenido: h.Celdas[d].Contenido)).ToArray();
    private static string[] ValidarCombinacion(MYGHojaMetrado h, string rango)
    {
        var dirs = Direcciones(h, rango).ToArray();
        if (dirs.Length < 2 || h.RangosCombinados.Contains(rango, StringComparer.OrdinalIgnoreCase)) return dirs;
        var ocupadas = new HashSet<string>(h.RangosCombinados.SelectMany(x => Direcciones(h, x)), StringComparer.OrdinalIgnoreCase);
        if (dirs.Any(ocupadas.Contains)) throw new InvalidDataException("La selección se superpone a otra combinación.");
        return dirs;
    }
    /// <summary>Conserva el primer contenido no vacío en la celda superior izquierda y vacía los demás contenidos del rango.</summary>
    public static void Combinar(MYGHojaMetrado h, string rango)
    {
        var copia = MYGProyectoStorage.Copia(h); MYGHojaCalculo.Validar(copia); rango = NormalizarRango(rango);
        var dirs = ValidarCombinacion(copia, rango);
        if (dirs.Length < 2 || copia.RangosCombinados.Contains(rango, StringComparer.OrdinalIgnoreCase)) return;
        var contenidos = Contenidos(copia, dirs);
        string total = MYGHojaCalculo.Normalizar(copia.CeldaTotal);
        if (dirs.Contains(total) && dirs[0] != total)
        {
            if (contenidos.Length != 0 && contenidos[0].Direccion != total)
                throw new InvalidDataException("La combinación sustituiría el metrado total por otro contenido. Seleccione otra celda total antes de combinar.");
            // Combinar lleva el valor al ancla; el vínculo sigue ese resultado.
            copia.CeldaTotal = dirs[0];
        }
        if (contenidos.Length != 0)
            // Move the expression intact: combining cells does not copy or translate formula references.
            Celda(copia, dirs[0]).Contenido = contenidos[0].Contenido;
        foreach (string dir in dirs.Skip(1))
            if (copia.Celdas.TryGetValue(dir, out var c)) c.Contenido = "";
        copia.RangosCombinados.Add(rango); Aplicar(h, copia);
    }
    public static void Separar(MYGHojaMetrado h, string rango)
    {
        var copia = MYGProyectoStorage.Copia(h); var seleccion = new HashSet<string>(Direcciones(copia, rango), StringComparer.OrdinalIgnoreCase);
        copia.RangosCombinados.RemoveAll(x => Direcciones(copia, x).Any(seleccion.Contains)); Aplicar(h, copia);
    }
    /// <summary>Extiende un bloque en una sola dirección sin sobrescribir datos existentes.</summary>
    public static void RellenarRango(MYGHojaMetrado h, string origen, string destino)
    {
        var copia = MYGProyectoStorage.Copia(h); MYGHojaCalculo.Validar(copia);
        var a = Limites(copia, origen); var b = Limites(copia, destino);
        bool vertical = a.C1 == b.C1 && a.C2 == b.C2;
        bool horizontal = a.F1 == b.F1 && a.F2 == b.F2;
        if ((!vertical && !horizontal) || b.F1 > a.F1 || b.F2 < a.F2 || b.C1 > a.C1 || b.C2 < a.C2 ||
            (vertical && b.F1 < a.F1 && b.F2 > a.F2) || (horizontal && b.C1 < a.C1 && b.C2 > a.C2))
            throw new InvalidDataException("Extienda el rango en una sola dirección.");
        ValidarRangoArrastre(copia, destino);
        var fuentes = Direcciones(copia, origen).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var nuevas = Direcciones(copia, destino).Where(d => !fuentes.Contains(d)).ToArray();
        if (nuevas.Length == 0) return;
        RechazarDestinoOcupado(copia, nuevas);
        string Dir(int f, int c) => MYGHojaCalculo.Columna(c) + f;
        int Mod(int n, int longitud) => (n % longitud + longitud) % longitud;
        foreach (string direccion in nuevas)
        {
            var p = MYGHojaCalculo.Coordenadas(direccion);
            int f = a.F1 + Mod(p.Fila - a.F1, a.F2 - a.F1 + 1), c = a.C1 + Mod(p.Columna - a.C1, a.C2 - a.C1 + 1);
            var celda = CopiarCelda(copia.Celdas.GetValueOrDefault(Dir(f, c)));
            celda.Contenido = TrasladarFormula(celda.Contenido, p.Fila - f, p.Columna - c);
            int longitud = vertical ? a.F2 - a.F1 + 1 : a.C2 - a.C1 + 1;
            if (longitud > 1)
            {
                var numeros = Enumerable.Range(0, longitud).Select(i => copia.Celdas.GetValueOrDefault(
                    Dir(vertical ? a.F1 + i : p.Fila, vertical ? p.Columna : a.C1 + i))?.Contenido ?? "").ToArray();
                if (numeros.All(t => MYGHojaCalculo.IntentarNumero(t, out _)))
                {
                    MYGHojaCalculo.IntentarNumero(numeros[0], out decimal inicial);
                    MYGHojaCalculo.IntentarNumero(numeros[1], out decimal siguiente);
                    decimal paso = siguiente - inicial;
                    bool serie = numeros.Select((t, i) => { MYGHojaCalculo.IntentarNumero(t, out decimal n); return n == inicial + paso * i; }).All(x => x);
                    if (serie) celda.Contenido = (inicial + paso * (vertical ? p.Fila - a.F1 : p.Columna - a.C1)).ToString(CultureInfo.InvariantCulture);
                }
            }
            copia.Celdas[direccion] = celda;
        }
        ValidarReglasDestinoArrastre(h, copia, nuevas);
        ValidarResultadoArrastre(copia);
        Aplicar(h, copia);
    }

    /// <summary>Mueve celdas y las referencias al bloque; conserva referencias externas y absolutas.</summary>
    public static void MoverRango(MYGHojaMetrado h, string origen, string destinoSuperiorIzquierdo)
    {
        var copia = MYGProyectoStorage.Copia(h); MYGHojaCalculo.Validar(copia);
        var a = Limites(copia, origen); Dentro(copia, destinoSuperiorIzquierdo);
        var inicio = MYGHojaCalculo.Coordenadas(destinoSuperiorIzquierdo);
        int df = inicio.Fila - a.F1, dc = inicio.Columna - a.C1;
        if (df == 0 && dc == 0) return;
        string Dir(int f, int c) => MYGHojaCalculo.Columna(c) + f;
        string destino = Dir(a.F1 + df, a.C1 + dc) + ":" + Dir(a.F2 + df, a.C2 + dc);
        Limites(copia, destino); ValidarRangoArrastre(copia, origen); ValidarRangoArrastre(copia, destino);
        var fuentes = Direcciones(copia, origen).ToHashSet(StringComparer.OrdinalIgnoreCase);
        RechazarDestinoOcupado(copia, Direcciones(copia, destino).Where(d => !fuentes.Contains(d)));
        // Un rango de fórmula parcialmente afectado podría cambiar su forma
        // e incluir celdas ajenas al bloque. Se rechaza antes de tocar datos.
        foreach (var celda in copia.Celdas.Values)
            Transformar(celda.Contenido, m =>
            {
                if (m.Groups["b"].Success)
                {
                    var x = MYGHojaCalculo.Coordenadas(m.Groups["a"].Value); var y = MYGHojaCalculo.Coordenadas(m.Groups["b"].Value);
                    int f1 = Math.Min(x.Fila, y.Fila), f2 = Math.Max(x.Fila, y.Fila), c1 = Math.Min(x.Columna, y.Columna), c2 = Math.Max(x.Columna, y.Columna);
                    bool toca = f1 <= a.F2 && f2 >= a.F1 && c1 <= a.C2 && c2 >= a.C1;
                    bool contenido = f1 >= a.F1 && f2 <= a.F2 && c1 >= a.C1 && c2 <= a.C2;
                    if (toca && !contenido) throw new InvalidDataException("Una fórmula usa un rango parcialmente incluido en el bloque. Mueva el rango completo o ajuste la fórmula antes de arrastrar.");
                }
                return m.Value;
            });
        var datos = fuentes.ToDictionary(d => d, d => copia.Celdas.GetValueOrDefault(d), StringComparer.OrdinalIgnoreCase);
        foreach (string dir in fuentes) copia.Celdas.Remove(dir);
        foreach (var dato in datos)
        {
            var p = MYGHojaCalculo.Coordenadas(dato.Key); string dir = Dir(p.Fila + df, p.Columna + dc);
            if (dato.Value != null) copia.Celdas[dir] = CopiarCelda(dato.Value); else copia.Celdas.Remove(dir);
        }
        string MoverReferencia(string referencia)
        {
            var p = MYGHojaCalculo.Coordenadas(referencia);
            if (p.Fila < a.F1 || p.Fila > a.F2 || p.Columna < a.C1 || p.Columna > a.C2) return referencia;
            var partes = PartesReferencia.Match(referencia);
            return partes.Groups["ca"].Value + MYGHojaCalculo.Columna(p.Columna + dc) + partes.Groups["fa"].Value + (p.Fila + df);
        }
        foreach (var celda in copia.Celdas.Values)
            celda.Contenido = Transformar(celda.Contenido, m => MoverReferencia(m.Groups["a"].Value) +
                (m.Groups["b"].Success ? ":" + MoverReferencia(m.Groups["b"].Value) : ""));
        copia.CeldaTotal = MYGHojaCalculo.Normalizar(MoverReferencia(copia.CeldaTotal));
        MYGReferenciasMetrado.ReubicarAnclas(copia, MoverReferencia);
        ValidarReglasDestinoArrastre(h, copia, Direcciones(copia, destino));
        ValidarResultadoArrastre(copia);
        Aplicar(h, copia);
    }

    private static void ValidarReglasDestinoArrastre(MYGHojaMetrado original, MYGHojaMetrado resultado, IEnumerable<string> direcciones)
    {
        var destinos = direcciones.Where(d => original.Celdas.TryGetValue(d, out var c) && c.TipoValidacion != "Ninguna").ToArray();
        if (destinos.Length == 0) return;
        // Evaluar las reglas originales con todas las fórmulas y referencias ya
        // trasladadas, antes de aplicar el bloque. El formato copiado no puede
        // ocultar un valor que incumpla la validación previa de su destino.
        var validacion = MYGProyectoStorage.Copia(resultado);
        foreach (string dir in destinos)
        {
            var regla = CopiarCelda(original.Celdas[dir]);
            regla.Contenido = resultado.Celdas.GetValueOrDefault(dir)?.Contenido ?? "";
            validacion.Celdas[dir] = regla;
        }
        foreach (string dir in destinos) ValidarEntrada(validacion, dir, validacion.Celdas[dir].Contenido);
    }

    private static void RechazarDestinoOcupado(MYGHojaMetrado h, IEnumerable<string> direcciones)
    {
        if (direcciones.Any(d => h.Celdas.TryGetValue(d, out var c) && !string.IsNullOrEmpty(c.Contenido)))
            throw new InvalidDataException("El destino contiene datos. Vacíelo o elija otro rango antes de arrastrar.");
    }
    private static void ValidarRangoArrastre(MYGHojaMetrado h, string rango)
    {
        var r = Limites(h, rango);
        if (h.FilasOcultas.Any(f => f >= r.F1 && f <= r.F2))
            throw new InvalidDataException("Muestre las filas ocultas antes de arrastrar el rango.");
        foreach (string combinado in h.RangosCombinados)
        {
            var c = Limites(h, combinado);
            if (r.F1 <= c.F2 && r.F2 >= c.F1 && r.C1 <= c.C2 && r.C2 >= c.C1)
                throw new InvalidDataException("Separe las celdas combinadas antes de arrastrar el rango.");
        }
    }
    private static void ValidarResultadoArrastre(MYGHojaMetrado h)
    {
        MYGHojaCalculo.Validar(h);
        foreach (var dato in h.Celdas) ValidarEntrada(h, dato.Key, dato.Value.Contenido);
        if (new MYGHojaCalculo(h).Numero(h.CeldaTotal) < 0)
            throw new InvalidDataException("El total del metrado debe ser positivo o cero.");
    }
    public static void Ordenar(MYGHojaMetrado h, string rango, int columna, bool descendente = false)
    {
        var copia = MYGProyectoStorage.Copia(h); MYGHojaCalculo.Validar(copia); var (f1, c1, f2, c2) = Limites(copia, rango);
        if (columna < c1 || columna > c2) throw new InvalidDataException("La columna de orden debe pertenecer a la selección.");
        var seleccion = new HashSet<string>(Direcciones(copia, rango), StringComparer.OrdinalIgnoreCase);
        if (seleccion.Contains(copia.CeldaTotal) || copia.RangosCombinados.SelectMany(x => Direcciones(copia, x)).Any(seleccion.Contains))
            throw new InvalidDataException("Ordene las filas de datos sin incluir el total ni celdas combinadas.");
        var motor = new MYGHojaCalculo(copia);
        (int Tipo, decimal Numero, string Texto) Clave(int fila)
        {
            string dir = MYGHojaCalculo.Columna(columna) + fila, t = motor.Contenido(dir);
            if (string.IsNullOrEmpty(t)) return (2, 0, "");
            if (t.StartsWith('=')) return (0, motor.Numero(dir), "");
            return MYGHojaCalculo.IntentarNumero(t, out var n) ? (0, n, "") : (1, 0, t);
        }
        int Comparar((int Tipo, decimal Numero, string Texto) a, (int Tipo, decimal Numero, string Texto) b)
        { int tipo = a.Tipo.CompareTo(b.Tipo); if (tipo != 0) return tipo; int valor = a.Tipo == 0 ? a.Numero.CompareTo(b.Numero) : StringComparer.CurrentCultureIgnoreCase.Compare(a.Texto, b.Texto); return descendente ? -valor : valor; }
        var filas = Enumerable.Range(f1, f2 - f1 + 1).Select(f => (Fila: f, Clave: Clave(f))).OrderBy(x => x.Clave, Comparer<(int, decimal, string)>.Create(Comparar)).Select(x => x.Fila).ToArray();
        var origen = copia.Celdas.ToDictionary(x => x.Key, x => x.Value, StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < filas.Length; i++) for (int c = c1; c <= c2; c++)
        {
            string destino = MYGHojaCalculo.Columna(c) + (f1 + i), fuente = MYGHojaCalculo.Columna(c) + filas[i];
            if (!origen.TryGetValue(fuente, out var celda)) copia.Celdas.Remove(destino);
            else { var nueva = CopiarCelda(celda); nueva.Contenido = TrasladarFormula(nueva.Contenido, f1 + i - filas[i], 0); copia.Celdas[destino] = nueva; }
        }
        Aplicar(h, copia);
    }
    private static (int F1, int C1, int F2, int C2) Limites(MYGHojaMetrado h, string rango)
    { var partes = NormalizarRango(rango).Split(':'); Dentro(h, partes[0]); Dentro(h, partes[^1]); var a = MYGHojaCalculo.Coordenadas(partes[0]); var b = MYGHojaCalculo.Coordenadas(partes[^1]); return (a.Fila, a.Columna, b.Fila, b.Columna); }
    private static void Dentro(MYGHojaMetrado h, string direccion)
    {
        try { var p = MYGHojaCalculo.Coordenadas(direccion); if (p.Fila > h.Filas || p.Columna > h.Columnas) throw new InvalidDataException("La celda está fuera de la hoja."); }
        catch (FormatException ex) { throw new InvalidDataException("Referencia de celda no válida.", ex); }
    }
    private static void Aplicar(MYGHojaMetrado destino, MYGHojaMetrado copia)
    {
        MYGHojaCalculo.Validar(copia);
        destino.Nombre = copia.Nombre; destino.Filas = copia.Filas; destino.Columnas = copia.Columnas; destino.CeldaTotal = copia.CeldaTotal; destino.Celdas = copia.Celdas;
        destino.FormatoNumeroPredeterminado = copia.FormatoNumeroPredeterminado;
        destino.RangoCuerpoPlantilla = copia.RangoCuerpoPlantilla;
        destino.RellenoCabeceraEstandarAplicado = copia.RellenoCabeceraEstandarAplicado;
        destino.ReferenciasPartidas = copia.ReferenciasPartidas;
        destino.AnclasReferencias = copia.AnclasReferencias;
        destino.RangosCombinados = copia.RangosCombinados; destino.LineasDivision = copia.LineasDivision; destino.Encabezados = copia.Encabezados; destino.Zoom = copia.Zoom;
        destino.FilasInmovilizadas = copia.FilasInmovilizadas; destino.ColumnasInmovilizadas = copia.ColumnasInmovilizadas; destino.OrientacionPagina = copia.OrientacionPagina;
        destino.TamanoPapel = copia.TamanoPapel; destino.AreaImpresion = copia.AreaImpresion; destino.ImprimirLineasDivision = copia.ImprimirLineasDivision; destino.ImprimirEncabezados = copia.ImprimirEncabezados;
        destino.AnchosColumnas = copia.AnchosColumnas; destino.AltosFilas = copia.AltosFilas; destino.FilasOcultas = copia.FilasOcultas;
        destino.MargenIzquierdo = copia.MargenIzquierdo; destino.MargenDerecho = copia.MargenDerecho; destino.MargenSuperior = copia.MargenSuperior; destino.MargenInferior = copia.MargenInferior; destino.RepetirTitulos = copia.RepetirTitulos;
        if (destino.EsCopiaReferencias) MYGReferenciasMetrado.ActualizarDirecciones(destino, destino);
        else destino.ContextoReferencias?.ActualizarDirecciones(destino);
    }
}
