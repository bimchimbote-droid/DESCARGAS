# Publicaciones compactas y sincronización incremental

Esta actualización reduce la representación de la base compartida y el tamaño de
las ediciones enviadas. SQLite sigue siendo la copia de trabajo local; la nube
conserva datos editables, revisiones y permisos. No se sustituye la colaboración
por un archivo ZIP que todos tengan que sobrescribir.

## Actualizar una instalación existente

1. Conserve una copia de su SQLite y de la carpeta de la aplicación. En Supabase,
   use los mecanismos de respaldo habituales antes de actualizar funciones.
2. En el editor SQL de **su proyecto Supabase**, ejecute, en este orden:
   - `migraciones/20261022_paquete_compacto.sql`.
   - `migraciones/20261023_sincronizacion_incremental.sql`.
   Estas migraciones requieren las actualizaciones de usuarios/permisos y
   `20261021_contenido_grande.sql` anteriores. Las comprobaciones iniciales cancelan
   la instalación si falta el contrato esperado. Cada archivo es transaccional y
   admite repetición; no convierte ni elimina obras, miembros o intentos anteriores.
3. Cierre MYG y actualice la aplicación completa y sus dependencias. El código se
   compila con .NET 10; para compilar el conector fuera de Revit se utiliza
   `UseRevitReferencePackages=true`. Conserve `nube-myg.json`, si su distribución
   lo utiliza, y su configuración local existente. Esta entrega no incluye claves
   ni modifica la conexión a Supabase.
4. Para el intento antiguo que excedía el límite: revise primero **Mis proyectos**.
   Si no fue publicado, en **Publicaciones pendientes** elija **Retirar y conservar
   copia** y cree una publicación nueva desde el SQLite. Reintentar un intento
   anterior conserva sus bytes y su identificador; no lo transforma a escondidas.
5. Las publicaciones nuevas usan el formato compacto. Todos los colaboradores
   que abran esas publicaciones deben utilizar la aplicación actualizada. Las
   publicaciones anteriores conservan su protocolo hasta que se cree una nueva
   publicación compacta; no se altera su historial automáticamente.

La instalación de funciones en el Supabase real y la ejecución visual en Windows
son pasos separados de las pruebas Linux. No se han ejecutado contra la cuenta
del usuario desde este entorno.

## Qué cambia

- **Paquete v2:** celdas compactas con tipo exacto, un solo documento principal,
  diccionario de textos repetidos y referencias a documentos conocidos en
  `myg_proyecto.json_documento`. Los datos nativos no se eliminan por parecer
  redundantes. La reconstrucción admite tanto v1 como v2.
- **Menor memoria al preparar:** se puede escribir el paquete compacto directamente
  desde las tablas leídas, sin construir antes el JSON v1 completo.
- **Ediciones incrementales:** consulta de revisión y permisos sin descargar toda
  la base cuando no ha cambiado. Se elige la diferencia más pequeña entre bloques
  modificados y rutas a propiedades o celdas concretas. Un renombrado no envía el
  documento completo; las listas que cambian de longitud pueden requerir un bloque
  completo. Los cambios se aplican en una transacción y
  conservan el control de revisión global: dos ediciones incompatibles producen
  un conflicto, nunca una combinación silenciosa.
- **Reintentos duraderos:** SQLite conserva el cuerpo incremental exacto antes
  de enviarlo. Una respuesta perdida no duplica la operación ni reemplaza un
  borrador posterior. Los intentos antiguos ya enviados no cambian de protocolo.
- **Historial:** diferencias entre revisiones y una instantánea cada 20 revisiones,
  con una base inicial para reconstruirlas. Se preservan los registros antiguos.
- **Adjuntos:** los archivos externos continúan en almacenamiento privado con
  SHA-256; una copia local ya verificada evita una descarga repetida. Los BLOB
  nativos permanecen tipados en el paquete para conservar su reconstrucción.
- **Tamaños visibles:** la lista de pendientes distingue SQLite original y paquete
  guardado. Los adjuntos preparados pueden reducir posteriormente el envío.

El límite de entrada compacta sigue siendo 127 MiB. La expansión de referencias
está acotada a 512 MiB para impedir que un paquete pequeño genere datos sin límite.
La compresión del transporte no sustituye estas comprobaciones.

## Comprobar la actualización

Desde la raíz del repositorio con el SDK fijado en `global.json`:

```bash
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
bash scripts/pruebas/Probar-ContenidoGrande.sh
```

El último comando requiere Docker y crea únicamente PostgreSQL desechable sin
puertos publicados. Genera paquetes sintéticos con el código C#, prueba las
migraciones y elimina el contenedor al terminar; no conecta a Supabase real.

Las pruebas incluyen tipos SQLite, Int64 y decimales, bases con varias obras,
adjuntos, privacidad, permisos de módulos, conflictos entre dos usuarios,
recuperación tras perder una respuesta y conservación de intentos anteriores.
El benchmark informa bytes antes y después sobre datos sintéticos; no estima ni
garantiza el tamaño de una base privada que no se haya medido.

En una prueba sintética de 400 partidas y 4.800 insumos, el SQLite ocupó
42.876.928 bytes: el paquete anterior ocupó 78.529.437 bytes y el compacto
39.810.772 bytes, un 49,3 % menos. El guardado de un renombrado real como editor
con los tres módulos bloqueados terminó en unos 3,1 segundos en PostgreSQL 17.
La aplicación se publicó para Windows x64 con su runtime; la comprobación visual
de esa publicación sigue pendiente de ejecución en Windows.
