using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ProjectTitulosConfiguracionCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza<T>(Action accion, string mensaje) where T : Exception
    {
        try { accion(); }
        catch (T) { return; }
        throw new Exception(mensaje);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        var paleta = new Dictionary<int, int> { [0] = 0xFF0000, [2] = 0x0000FF, [3] = 0x000000 };
        var opciones = new MYGOpcionesTitulosProject(true, paleta);
        paleta[0] = 0xFFFFFF; paleta[12] = 0x123456;
        Exige(opciones.ColorearTitulos && opciones.ColoresPorNivel[0] == 0xFF0000 &&
            !opciones.ColoresPorNivel.ContainsKey(12), "Project debe congelar la paleta anterior al hilo de exportación.");
        Rechaza<NotSupportedException>(() => ((IDictionary<int, int>)opciones.ColoresPorNivel)[0] = 0xFFFFFF,
            "La captura de colores de Project permite cambiar su diccionario publicado.");
        foreach (var invalida in new[]
        {
            new Dictionary<int, int> { [-1] = 0x123456 },
            new Dictionary<int, int> { [0] = -1 },
            new Dictionary<int, int> { [0] = 0x1000000 }
        })
            Rechaza<ArgumentException>(() => _ = new MYGOpcionesTitulosProject(true, invalida),
                "Una paleta inválida debe rechazarse antes de automatizar Project.");
        pasa("Opciones de títulos Project congelan la paleta, impiden mutaciones y rechazan niveles/RGB inválidos antes de iniciar Office");

        Exige(MYGConfiguracionTitulosProject.ColorRef(0) == 0 &&
            MYGConfiguracionTitulosProject.ColorRef(0xFF0000) == 0x0000FF &&
            MYGConfiguracionTitulosProject.ColorRef(0x0000FF) == 0xFF0000 &&
            MYGConfiguracionTitulosProject.ColorRef(0x00FF00) == 0x00FF00 &&
            MYGConfiguracionTitulosProject.ColorRef(0x123456) == 0x563412 &&
            MYGConfiguracionTitulosProject.ColorRef(0xFFFFFF) == 0xFFFFFF,
            "Project necesita COLORREF BGR de 24 bits; rojo, azul o negro se exportaron intercambiados.");
        Rechaza<ArgumentOutOfRangeException>(() => MYGConfiguracionTitulosProject.ColorRef(-1), "Se aceptó un RGB negativo.");
        Rechaza<ArgumentOutOfRangeException>(() => MYGConfiguracionTitulosProject.ColorRef(0x1000000), "Se aceptó un color mayor de 24 bits.");
        pasa("Font32Ex recibe COLORREF BGR exacto para rojo, azul, verde, negro y colores personalizados sin bits ARGB");

        var modelo = Modelo();
        // La ruta desactivada no debe preparar ni cambiar la vista, seleccionar
        // filas o escribir formato aunque haya títulos en el modelo.
        MYGConfiguracionTitulosProject.Aplicar(modelo, new MYGOpcionesTitulosProject(), null, null, null, null, null);
        MYGConfiguracionTitulosProject.Aplicar(modelo with { Tareas = new[] { modelo.Tareas[0] } }, opciones,
            null, null, null, null, null);
        pasa("Exportar sin colores o sin resúmenes no invoca ninguna API de vista, selección ni fuente de Microsoft Project");

        string antes = JsonSerializer.Serialize(modelo);
        var llamadas = new List<string>();
        var seleccionadas = new List<int>();
        var colores = new List<(int Id, int Color)>();
        int seleccionActual = 0;
        (int Id, int UniqueId) Real(int uid) => (uid / 5 + 3, uid + 1000);
        MYGConfiguracionTitulosProject.Aplicar(modelo, opciones,
            () => llamadas.Add("preparar"),
            uid => { llamadas.Add("leer:" + uid); return Real(uid); },
            id => { seleccionActual = id; seleccionadas.Add(id); llamadas.Add("seleccionar:" + id); },
            () => modelo.Tareas.Single(t => Real(t.Uid).Id == seleccionActual).Uid + 1000,
            color => colores.Add((seleccionActual, color)));
        Exige(llamadas[0] == "preparar" && llamadas.Count(l => l == "preparar") == 1 &&
            seleccionadas.SequenceEqual(new[] { Real(20).Id, Real(40).Id, Real(50).Id, Real(60).Id, Real(10).Id }) &&
            colores.SequenceEqual(new[]
            {
                (Real(20).Id, 0x0000FF), (Real(40).Id, 0xFF0000),
                (Real(50).Id, 0x000000), (Real(60).Id, 0x463426)
            }) && JsonSerializer.Serialize(modelo) == antes,
            "Project debe colorear sólo resúmenes por su metadata o nivel de respaldo, usar el ID real y restaurar la primera tarea sin modificar el modelo.");
        pasa("Colores Project afectan sólo títulos por nivel real o de respaldo, conservan negro y paleta capturada, usan ID/UniqueID reales y restauran la primera tarea");

        foreach (string fallo in new[] { "id", "uid", "seleccionar", "identidad", "fuente" })
        {
            llamadas.Clear();
            int fuentes = 0;
            Rechaza<InvalidOperationException>(() => MYGConfiguracionTitulosProject.Aplicar(modelo, opciones,
                () => llamadas.Add("preparar"),
                uid =>
                {
                    llamadas.Add("leer:" + uid);
                    return fallo == "id" ? (0, 1020) : fallo == "uid" ? (7, 0) : Real(uid);
                },
                id =>
                {
                    llamadas.Add("seleccionar:" + id);
                    if (fallo == "seleccionar") throw new InvalidOperationException("SelectRow devolvió false.");
                },
                () => fallo == "identidad" ? 9999 : 1020,
                color =>
                {
                    fuentes++;
                    llamadas.Add("fuente");
                    if (fallo == "fuente") throw new InvalidOperationException("Font32Ex devolvió false.");
                }), "Project aceptó el fallo de formato " + fallo);
            Exige(!llamadas.Contains("leer:40") && !llamadas.Contains("leer:10") &&
                fuentes == (fallo == "fuente" ? 1 : 0) &&
                (fallo is not ("id" or "uid") || !llamadas.Any(l => l.StartsWith("seleccionar:", StringComparison.Ordinal))),
                "Un ID inválido, selección incorrecta o fallo de formato debe detener el recorrido antes de otra tarea: " + fallo);
        }
        pasa("IDs inválidos, SelectRow rechazado, identidad seleccionada distinta y Font32Ex rechazado detienen los colores antes de tocar otra tarea");

        var adaptador = new AdaptadorFormatoFallido(modelo, opciones);
        Rechaza<InvalidOperationException>(() => MYGFlujoExportacionProject.Ejecutar(modelo, false, "no-publicar.mpp", adaptador),
            "El flujo publicó un MPP después de que Project rechazara el formato de títulos.");
        Exige(adaptador.Liberado && !adaptador.Guardado && !adaptador.Mostrado && !adaptador.Confirmado,
            "Un fallo del formato debe liberar el adaptador sin guardar, mostrar ni confirmar un MPP parcial.");
        pasa("Fallar el formato de títulos durante la finalización impide guardar o publicar el MPP y libera el adaptador de Project");
    }

    private static MYGModeloExportacionProject Modelo()
    {
        var fecha = new DateTime(2026, 11, 2, 8, 0, 0);
        MYGTareaExportacionProject Tarea(int uid, bool resumen, int nivel, int? nivelTitulo) => new(
            uid, "MYG-" + uid, 0, nivel, uid.ToString(), uid.ToString(), "Tarea " + uid,
            false, resumen, false, false, fecha, fecha.AddHours(8), 480, 0, null, null, null, "")
            { NivelTitulo = nivelTitulo };
        return new("Formato Project QA", fecha, fecha.AddHours(8), fecha.Date, 480, 2400, null,
            new("Calendario QA", Array.Empty<MYGDiaExportacionProject>(), Array.Empty<MYGExcepcionExportacionProject>()),
            new[]
            {
                Tarea(10, false, 3, null), Tarea(20, true, 8, 0), Tarea(30, false, 8, null),
                Tarea(40, true, 9, 2), Tarea(50, true, 4, null), Tarea(60, true, 15, 12)
            }, Array.Empty<MYGRecursoExportacionProject>(), Array.Empty<MYGAsignacionExportacionProject>(),
            Array.Empty<MYGDependenciaExportacionProject>(), Array.Empty<string>());
    }

    private sealed class AdaptadorFormatoFallido(MYGModeloExportacionProject modelo, MYGOpcionesTitulosProject opciones) : IMYGAdaptadorProject
    {
        internal bool Liberado, Guardado, Mostrado, Confirmado;
        public IReadOnlyList<string> Advertencias => Array.Empty<string>();
        public void Iniciar(MYGModeloExportacionProject datos) { }
        public void CrearRecurso(MYGRecursoExportacionProject recurso) { }
        public void CrearTarea(MYGTareaExportacionProject tarea) { }
        public void AsignarRecurso(MYGAsignacionExportacionProject asignacion) { }
        public void CrearDependencia(MYGDependenciaExportacionProject dependencia) { }
        public void FinalizarDatos(MYGModeloExportacionProject datos) =>
            MYGConfiguracionTitulosProject.Aplicar(modelo, opciones, () => { }, uid => (7, uid + 1000),
                id => { }, () => 1020, color => throw new InvalidOperationException("Font32Ex rechazó el formato."));
        public void GuardarResultado(string destino) => Guardado = true;
        public void MostrarResultado() => Mostrado = true;
        public void ConfirmarResultado() => Confirmado = true;
        public void Dispose() => Liberado = true;
    }
}
