using System;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ProjectNivelesTitulosCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);

    internal static void Ejecutar(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("NIVELES PROJECT QA", "ESTRUCTURAS QA");
        var presupuesto = documento.Presupuestos.Single();
        ItemPresupuestoDelphin Item(string id, string padre, bool titulo, int posicion) => new()
        {
            Id = id, IdLocalMYG = id, ParentId = padre, Posicion = posicion,
            Item = titulo ? "999.888.777" : "01", Descripcion = id,
            TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Unidad = titulo ? "" : "und"
        };
        var capitulo = Item("CAPITULO", null, true, 0);
        var subcapitulo = Item("SUBCAPITULO", capitulo.Id, true, 1);
        var partida = Item("PARTIDA", subcapitulo.Id, false, 2);
        partida.Costos.Cantidad = 2;
        var material = new MYGInsumo { Id = "MAT", Codigo = "MAT", Descripcion = "Material de niveles QA",
            Grupo = MYGGrupoRecurso.Materiales, Unidad = "und", Precio = 3 };
        presupuesto.Costos.Insumos.Add(material);
        partida.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = material.Grupo, Cantidad = 1 });
        presupuesto.Items.AddRange(new[] { capitulo, subcapitulo, partida });
        MYGProyectoStorage.ValidarPresupuesto(presupuesto);

        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 11, 2), FechaEstado = new DateTime(2026, 11, 2) };
        void Resumen(string id, string padre, string presupuestoId = null, string partidaId = null) =>
            plan.Tareas.Add(new() { Id = id, PadreId = padre, Nombre = id, EsResumen = true, DuracionDias = 0,
                PresupuestoId = presupuestoId, PartidaId = partidaId, Codigo = "123.456.789.000" });
        Resumen("ENVOLTORIO", null);
        Resumen("PRESUPUESTO", "ENVOLTORIO", presupuesto.Id);
        Resumen("TITULO", "PRESUPUESTO", presupuesto.Id, capitulo.Id);
        Resumen("SUBTITULO", "TITULO", presupuesto.Id, subcapitulo.Id);
        plan.Tareas.Add(new() { Id = "ACTIVIDAD", PadreId = "SUBTITULO", Nombre = "Partida programada",
            PresupuestoId = presupuesto.Id, PartidaId = partida.Id, DuracionDias = 2 });
        Resumen("PERSONALIZADO", "PRESUPUESTO");
        plan.Tareas.Add(new() { Id = "LIBRE", PadreId = "PERSONALIZADO", Nombre = "Actividad sin vínculo", DuracionDias = 1 });
        Resumen("SIN_PRESUPUESTO", "ENVOLTORIO", "NO_EXISTE", capitulo.Id);
        Resumen("SIN_PARTIDA_VIGENTE", "PRESUPUESTO", presupuesto.Id, "NO_EXISTE");
        Resumen("SIN_ID_PRESUPUESTO", "TITULO", "", subcapitulo.Id);

        string antesDocumento = Firma(documento), antesPlan = Firma(plan);
        var filas = MYGMotorCronograma.Calcular(plan).Filas.ToDictionary(f => f.Tarea.Id);
        var solo = MYGExportacionCronograma.PrepararProject(documento, plan, false);
        var completo = MYGExportacionCronograma.PrepararProject(documento, plan, true);
        var tareas = solo.Tareas.ToDictionary(t => t.IdMYG);
        Exige(tareas["PRESUPUESTO"].NivelTitulo == 0 && tareas["TITULO"].NivelTitulo == 1 &&
            tareas["SUBTITULO"].NivelTitulo == 2 && tareas["PRESUPUESTO"].Nivel - 1 != tareas["PRESUPUESTO"].NivelTitulo &&
            tareas["ACTIVIDAD"].NivelTitulo == null && tareas["LIBRE"].NivelTitulo == null,
            "Project debe conservar los niveles de color reales del presupuesto, independientes del esquema, sin convertir partidas en títulos.");
        foreach (string id in new[] { "ENVOLTORIO", "PERSONALIZADO", "SIN_PRESUPUESTO", "SIN_PARTIDA_VIGENTE", "SIN_ID_PRESUPUESTO" })
            Exige(tareas[id].NivelTitulo == filas[id].Nivel,
                "Un resumen personalizado o con vínculo incompleto debe usar su nivel del cronograma: " + id);
        Exige(solo.Tareas.Select(t => (t.IdMYG, t.NivelTitulo)).SequenceEqual(completo.Tareas.Select(t => (t.IdMYG, t.NivelTitulo))) &&
            solo.Tareas.Select(t => (t.Uid, t.PadreUid, t.Nivel, t.Inicio, t.Fin, t.DuracionMinutos))
                .SequenceEqual(completo.Tareas.Select(t => (t.Uid, t.PadreUid, t.Nivel, t.Inicio, t.Fin, t.DuracionMinutos))) &&
            completo.Asignaciones.Count == 1 && completo.Asignaciones.Single().Costo == 6 &&
            Firma(documento) == antesDocumento && Firma(plan) == antesPlan,
            "La metadata de títulos debe ser igual con/sin recursos y conservar orden, fechas, asignaciones y documentos de origen.");
        pasa("Project conserva niveles de color 0/1/2 del presupuesto aunque exista un envoltorio, deja partidas sin formato de título y mantiene recursos/fechas/origen");

        // Sólo tareas no necesita un presupuesto válido para exportar. Los
        // vínculos incompletos no introducen una validación nueva del ACU.
        documento.Presupuestos.Clear();
        string sinPresupuesto = Firma(documento);
        var sinOrigen = MYGExportacionCronograma.PrepararProject(documento, plan, false);
        Exige(sinOrigen.Tareas.Where(t => t.Resumen).All(t => t.NivelTitulo == filas[t.IdMYG].Nivel) &&
            sinOrigen.Tareas.Where(t => !t.Resumen).All(t => t.NivelTitulo == null) &&
            sinOrigen.Tareas.Count == plan.Tareas.Count && Firma(documento) == sinPresupuesto && Firma(plan) == antesPlan,
            "Sólo tareas debe conservar el nivel del cronograma cuando faltan los presupuestos de origen sin cambiar datos ni omitir tareas.");
        pasa("Metadata de colores en Project tolera vínculos presupuestales omitidos o inexistentes en sólo tareas y conserva el nivel de los resúmenes personalizados");
    }
}
