using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class ExportarProjectFormCheck
{
    private const string Prefijo = "cronograma_project_";

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-ProjectDialogo-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            VerificarOpcionesYValidacion(carpeta, exige);
            VerificarExportacionEnSegundoPlano(carpeta, exige);
            VerificarAvisosDeFechas(carpeta, exige);
            VerificarErrorYReintento(carpeta, exige);
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static void VerificarOpcionesYValidacion(string carpeta, Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Exportación Project", "Presupuesto");
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(proyecto);
        int llamadas = 0;
        string origen = Path.Combine(carpeta, "hoja-abierta.sqlite");
        byte[] contenido = { 12, 24, 36, 48 };
        File.WriteAllBytes(origen, contenido);
        using (var ventana = new MYGExportarProjectForm(proyecto, plan, true, origen,
            (_, _, _, _, _, _) => Interlocked.Increment(ref llamadas)))
        {
            ventana.Show(); Application.DoEvents();
            exige(ventana.Name == Prefijo + "dialogo" && !Campo<CheckBox>(ventana, "solo_tareas").Checked &&
                Campo<CheckBox>(ventana, "colores_titulos").Checked && Campo<CheckBox>(ventana, "colores_titulos").Enabled &&
                llamadas == 0 && string.IsNullOrEmpty(ventana.RutaExportada),
                "Abrir Exportar tareas con recursos debe preparar títulos coloreados y esperar sin ejecutar Microsoft Project ni crear archivos.");
            Campo<Button>(ventana, "exportar").PerformClick(); Application.DoEvents();
            exige(llamadas == 0 && !string.IsNullOrWhiteSpace(Campo<Label>(ventana, "error").Text) && ventana.Visible,
                "Un destino vacío debe mostrar un error corregible antes de iniciar el exportador.");
            foreach (string ruta in new[] { Path.Combine(carpeta, "no-es-project.xml"), origen })
            {
                Campo<TextBox>(ventana, "destino").Text = ruta;
                Campo<Button>(ventana, "exportar").PerformClick(); Application.DoEvents();
                exige(llamadas == 0 && !string.IsNullOrWhiteSpace(Campo<Label>(ventana, "error").Text) &&
                    Campo<Button>(ventana, "exportar").Enabled && !File.Exists(Path.Combine(carpeta, "no-es-project.xml")) &&
                    File.ReadAllBytes(origen).SequenceEqual(contenido),
                    "Un destino que no sea MPP, incluida la hoja SQLite abierta, debe rechazarse sin ejecutar el exportador ni tocar archivos.");
            }
            Campo<Button>(ventana, "cerrar").PerformClick(); Application.DoEvents();
            exige(!ventana.Visible && llamadas == 0, "Cerrar la preparación debe terminar sin iniciar una exportación.");
        }
        using (var ventana = new MYGExportarProjectForm(proyecto, plan, false, origen,
            (_, _, _, _, _, _) => Interlocked.Increment(ref llamadas)))
        {
            ventana.Show(); Application.DoEvents();
            exige(Campo<CheckBox>(ventana, "solo_tareas").Checked && Campo<CheckBox>(ventana, "colores_titulos").Checked &&
                Campo<CheckBox>(ventana, "colores_titulos").Enabled && llamadas == 0,
                "Exportar sólo tareas debe conservar disponible la opción independiente de colores y esperar al botón Exportar.");
            Campo<CheckBox>(ventana, "colores_titulos").Checked = false;
            Campo<CheckBox>(ventana, "solo_tareas").Checked = false;
            exige(!Campo<CheckBox>(ventana, "colores_titulos").Checked && Campo<CheckBox>(ventana, "colores_titulos").Enabled,
                "Cambiar entre tareas y recursos no debe reactivar ni deshabilitar los colores elegidos.");
            ventana.Close(); Application.DoEvents();
        }
    }

    private static void VerificarExportacionEnSegundoPlano(string carpeta, Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Recursos Project", "Presupuesto");
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(proyecto);
        MYGMotorCronograma.AgregarTarea(plan, null, "Tarea del documento");
        string antesProyecto = JsonSerializer.Serialize(proyecto), antesPlan = JsonSerializer.Serialize(plan);
        string destino = Path.Combine(carpeta, "con-recursos.mpp");
        using var inicio = new ManualResetEventSlim();
        using var continuar = new ManualResetEventSlim();
        using var dependencias = new ManualResetEventSlim();
        using var terminar = new ManualResetEventSlim();
        Thread hilo = null;
        int llamadas = 0;
        bool recursos = false;
        MYGOpcionesTitulosProject coloresRecibidos = null;
        var paletaEsperada = Enumerable.Range(0, 10).ToDictionary(n => n,
            n => MYG2027_TemaComercial.ColorTituloImpresion(n).ToArgb() & 0xFFFFFF);
        string rutaRecibida = null;
        // Si un cambio ejecutase el trabajo en el hilo UI, este rescate impide que la prueba quede colgada.
        using var rescate = new System.Threading.Timer(_ => { continuar.Set(); terminar.Set(); }, null, 10000, Timeout.Infinite);
        using var ventana = new MYGExportarProjectForm(proyecto, plan, true, null,
            (ruta, copiaProyecto, copiaPlan, incluirRecursos, opcionesTitulos, notificar) =>
            {
                hilo = Thread.CurrentThread;
                Interlocked.Increment(ref llamadas);
                recursos = incluirRecursos;
                coloresRecibidos = opcionesTitulos;
                rutaRecibida = ruta;
                copiaProyecto.Nombre = "Sólo la copia de exportación";
                copiaPlan.Tareas.Last().Nombre = "Sólo la tarea copiada";
                notificar(new(MYGEtapaExportacionProject.Recursos, 1, 3, "Creando recurso PEÓN"));
                inicio.Set();
                continuar.Wait();
                notificar(new(MYGEtapaExportacionProject.Dependencias, 2, 4, "Creando dependencias de Cimentación"));
                dependencias.Set();
                terminar.Wait();
                notificar(new(MYGEtapaExportacionProject.Completado, 1, 1, "Proyecto abierto"));
            });
        try
        {
            ventana.Show(); Application.DoEvents();
            Campo<TextBox>(ventana, "destino").Text = destino;
            var duracionClick = Stopwatch.StartNew();
            Campo<Button>(ventana, "exportar").PerformClick();
            exige(duracionClick.ElapsedMilliseconds < 2000,
                "El botón Exportar debe devolver el control al hilo UI antes de que termine la automatización.");
            Esperar(() => inicio.IsSet && Campo<Label>(ventana, "detalle").Text.Contains("PEÓN", StringComparison.Ordinal),
                "No se recibió el progreso real del recurso en la ventana.");
            exige(llamadas == 1 && recursos && rutaRecibida == destino && hilo != Thread.CurrentThread &&
                hilo.GetApartmentState() == ApartmentState.STA && hilo.IsBackground,
                "La exportación con recursos debe ejecutarse una sola vez en un hilo STA separado y recibir el destino elegido.");
            exige(coloresRecibidos?.ColorearTitulos == true && coloresRecibidos.ColoresPorNivel.Count == 10 &&
                paletaEsperada.All(c => coloresRecibidos.ColoresPorNivel.TryGetValue(c.Key, out int recibido) && recibido == c.Value),
                "El trabajador debe recibir la opción activada y la paleta de impresión del presupuesto capturadas antes de iniciar el STA.");
            bool respuestaUI = false;
            ventana.BeginInvoke(new Action(() => respuestaUI = true));
            Esperar(() => respuestaUI, "El formulario dejó de procesar mensajes mientras se creaba un recurso.");
            exige(ventana.Visible && !Campo<Button>(ventana, "exportar").Enabled &&
                !Campo<TextBox>(ventana, "destino").Enabled && !Campo<CheckBox>(ventana, "solo_tareas").Enabled &&
                !Campo<CheckBox>(ventana, "colores_titulos").Enabled &&
                !Campo<Button>(ventana, "cerrar").Enabled &&
                Campo<ProgressBar>(ventana, "progreso").Value == Campo<ProgressBar>(ventana, "progreso").Maximum / 3 &&
                Campo<Label>(ventana, "etapa").Text == "LISTA DE RECURSOS" &&
                Campo<Label>(ventana, "contador").Text == "Recurso: 1 de 3",
                "Durante el trabajo la ventana debe seguir respondiendo, bloquear cambios de destino y mostrar el recurso y su contador real.");
            Campo<CheckBox>(ventana, "colores_titulos").Checked = false;
            exige(coloresRecibidos.ColorearTitulos && paletaEsperada.All(c => coloresRecibidos.ColoresPorNivel[c.Key] == c.Value),
                "Un cambio programático posterior del control no debe alterar la opción ni paleta congeladas para la exportación en curso.");
            ventana.Close(); Application.DoEvents();
            exige(ventana.Visible && !ventana.IsDisposed && hilo.IsAlive,
                "Cerrar una exportación activa debe mantener su ventana hasta que termine el trabajo, sin abandonar el hilo STA.");
            continuar.Set();
            Esperar(() => dependencias.IsSet && Campo<Label>(ventana, "detalle").Text.Contains("Cimentación", StringComparison.Ordinal),
                "No se actualizó la fase de dependencias reportada por el exportador.");
            exige(Campo<Label>(ventana, "etapa").Text == "CREANDO DEPENDENCIAS" &&
                Campo<Label>(ventana, "contador").Text == "Dependencia: 2 de 4" &&
                Campo<ProgressBar>(ventana, "progreso").Value == Campo<ProgressBar>(ventana, "progreso").Maximum / 2,
                "El contador debe cambiar con la fase y sus totales reales, sin un progreso simulado por tiempo.");
            terminar.Set();
            Esperar(() => !ventana.Visible && !hilo.IsAlive, "La exportación terminada dejó abierta la ventana o su hilo de trabajo.");
            exige(ventana.DialogResult == DialogResult.OK && ventana.RutaExportada == destino &&
                JsonSerializer.Serialize(proyecto) == antesProyecto && JsonSerializer.Serialize(plan) == antesPlan,
                "El éxito debe devolver la ruta MPP y cerrar la ventana conservando intactos el proyecto y cronograma originales.");
        }
        finally
        {
            continuar.Set(); terminar.Set();
            if (hilo != null) Esperar(() => !hilo.IsAlive, "No terminó el hilo simulado durante la limpieza de la prueba.");
            if (!ventana.IsDisposed) { ventana.Close(); Application.DoEvents(); }
        }
    }

    private static void VerificarAvisosDeFechas(string carpeta, Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Project sin restricciones", "Presupuesto");
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(proyecto);
        string destino = Path.Combine(carpeta, "fechas-recalculadas.mpp");
        string[] advertencias =
        {
            "Project recalculó MOVILIZACIÓN: inicio 05/01/2026 → 06/01/2026.",
            "Project recalculó ENTREGA: fin 01/10/2026 → 02/10/2026."
        };
        using var notificados = new ManualResetEventSlim();
        using var continuar = new ManualResetEventSlim();
        using var rescate = new System.Threading.Timer(_ => continuar.Set(), null, 10000, Timeout.Infinite);
        Thread hilo = null;
        int llamadas = 0;
        using var ventana = new MYGExportarProjectForm(proyecto, plan, true, null,
            (_, _, _, _, _, notificar) =>
            {
                hilo = Thread.CurrentThread;
                Interlocked.Increment(ref llamadas);
                notificar(new(MYGEtapaExportacionProject.Tareas, 1, 2, "Creando MOVILIZACIÓN"));
                string[] emitidas = advertencias.ToArray();
                notificar(new(MYGEtapaExportacionProject.Completado, 1, 1, "Proyecto abierto") { Advertencias = emitidas });
                emitidas[0] = "Este cambio posterior no debe reemplazar el aviso entregado.";
                // La UI todavía no ha procesado la ráfaga: el último progreso
                // reemplaza el texto pendiente, pero debe conservar los avisos.
                notificar(new(MYGEtapaExportacionProject.Abriendo, 1, 1, "Proyecto confirmado"));
                notificados.Set();
                continuar.Wait();
            });
        try
        {
            ventana.Show(); Application.DoEvents();
            Campo<TextBox>(ventana, "destino").Text = destino;
            Campo<Button>(ventana, "exportar").PerformClick();
            bool rafagaEnCola = notificados.Wait(5000);
            continuar.Set();
            exige(rafagaEnCola, "El hilo de exportación debe entregar los avisos sin necesitar mensajes del hilo UI.");
            Esperar(() => Campo<TextBox>(ventana, "avisos").Visible && hilo != null && !hilo.IsAlive,
                "La exportación con fechas recalculadas no dejó visibles sus avisos al terminar.");
            var avisos = Campo<TextBox>(ventana, "avisos");
            exige(llamadas == 1 && ventana.Visible && ventana.DialogResult != DialogResult.OK &&
                ventana.RutaExportada == destino && avisos.ReadOnly && avisos.Multiline &&
                avisos.ScrollBars == ScrollBars.Vertical &&
                avisos.Text == string.Join(Environment.NewLine + Environment.NewLine, advertencias) &&
                Campo<Label>(ventana, "etapa").Text == "EXPORTACIÓN COMPLETADA CON AVISOS" &&
                Campo<Label>(ventana, "contador").Text == "2 aviso(s)" &&
                Campo<ProgressBar>(ventana, "progreso").Value == Campo<ProgressBar>(ventana, "progreso").Maximum &&
                Campo<Button>(ventana, "cerrar").Enabled,
                "El éxito con avisos debe mantener la ruta y todos los cambios de fechas visibles y copiables, aunque se agrupen eventos de progreso, hasta que el usuario cierre.");
            bool siguienteCiclo = false;
            ventana.BeginInvoke(new Action(() => siguienteCiclo = true));
            Esperar(() => siguienteCiclo, "La ventana con avisos dejó de responder después de la exportación.");
            exige(ventana.Visible && avisos.Text.Contains("06/01/2026", StringComparison.Ordinal),
                "Los avisos de fechas deben permanecer visibles después de procesar los mensajes de finalización.");
            Campo<Button>(ventana, "cerrar").PerformClick(); Application.DoEvents();
            exige(!ventana.Visible && ventana.DialogResult == DialogResult.OK && ventana.RutaExportada == destino && llamadas == 1,
                "Cerrar los avisos debe devolver la exportación correcta al editor sin ejecutar otra exportación.");
        }
        finally
        {
            continuar.Set();
            if (hilo != null) Esperar(() => !hilo.IsAlive, "No terminó el hilo de exportación con avisos durante la limpieza.");
            if (!ventana.IsDisposed) { ventana.Close(); Application.DoEvents(); }
        }
    }

    private static void VerificarErrorYReintento(string carpeta, Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Sólo tareas Project", "Presupuesto");
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(proyecto);
        string destino = Path.Combine(carpeta, "solo-tareas.mpp");
        int llamadas = 0;
        bool algunaConRecursos = false;
        MYGOpcionesTitulosProject primerIntento = null, segundoIntento = null;
        using var ventana = new MYGExportarProjectForm(proyecto, plan, true, null,
            (_, _, _, incluirRecursos, opcionesTitulos, notificar) =>
            {
                algunaConRecursos |= incluirRecursos;
                int llamada = Interlocked.Increment(ref llamadas);
                if (llamada == 1) primerIntento = opcionesTitulos;
                else segundoIntento = opcionesTitulos;
                notificar(new(MYGEtapaExportacionProject.Tareas, 1, 2, "Creando tarea Excavación"));
                if (llamada == 1) throw new InvalidOperationException("QA: Microsoft Project rechazó la tarea Excavación.");
                notificar(new(MYGEtapaExportacionProject.Completado, 1, 1, "Proyecto abierto"));
            });
        ventana.Show(); Application.DoEvents();
        Campo<TextBox>(ventana, "destino").Text = destino;
        Campo<CheckBox>(ventana, "solo_tareas").Checked = true;
        Campo<Button>(ventana, "exportar").PerformClick();
        Esperar(() => Campo<Label>(ventana, "error").Text.Contains("QA:", StringComparison.Ordinal),
            "La ventana no conservó el error concreto de Microsoft Project para poder corregirlo.");
        exige(ventana.Visible && ventana.DialogResult != DialogResult.OK && llamadas == 1 && !algunaConRecursos &&
            string.IsNullOrEmpty(ventana.RutaExportada) && Campo<Button>(ventana, "exportar").Enabled &&
            Campo<TextBox>(ventana, "destino").Enabled && Campo<TextBox>(ventana, "destino").Text == destino &&
            Campo<CheckBox>(ventana, "solo_tareas").Checked && Campo<CheckBox>(ventana, "solo_tareas").Enabled &&
            Campo<CheckBox>(ventana, "colores_titulos").Checked && Campo<CheckBox>(ventana, "colores_titulos").Enabled &&
            primerIntento?.ColorearTitulos == true,
            "Un fallo al exportar sólo tareas debe conservar el destino y la opción, mostrar el error y permitir reintentar sin crear recursos.");
        Campo<CheckBox>(ventana, "colores_titulos").Checked = false;
        Campo<Button>(ventana, "exportar").PerformClick();
        Esperar(() => !ventana.Visible, "Un reintento correcto no terminó la ventana de exportación.");
        exige(llamadas == 2 && !algunaConRecursos && ventana.DialogResult == DialogResult.OK && ventana.RutaExportada == destino &&
            segundoIntento?.ColorearTitulos == false && segundoIntento.ColoresPorNivel.Count == 0 && primerIntento.ColorearTitulos,
            "Reintentar sin colores debe lanzar un único trabajo con sólo tareas y la nueva opción, sin alterar la captura anterior.");
    }

    private static T Campo<T>(Control raiz, string nombre) where T : Control =>
        raiz.Controls.Find(Prefijo + nombre, true).OfType<T>().Single();

    private static void Esperar(Func<bool> condicion, string error)
    {
        var reloj = Stopwatch.StartNew();
        while (!condicion() && reloj.ElapsedMilliseconds < 5000)
        {
            Application.DoEvents();
            Thread.Sleep(5);
        }
        if (!condicion()) throw new InvalidOperationException(error);
    }
}
