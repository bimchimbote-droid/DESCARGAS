using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace MYG_2027;

/// <summary>Elección y paleta capturadas antes de iniciar el hilo de Project.</summary>
internal sealed class MYGOpcionesTitulosProject
{
    internal bool ColorearTitulos { get; }
    internal IReadOnlyDictionary<int, int> ColoresPorNivel { get; }

    internal MYGOpcionesTitulosProject(bool colorearTitulos = false,
        IReadOnlyDictionary<int, int> coloresPorNivel = null)
    {
        var colores = new Dictionary<int, int>(coloresPorNivel ?? new Dictionary<int, int>());
        if (colores.Any(c => c.Key < 0 || c.Value < 0 || c.Value > 0xFFFFFF))
            throw new ArgumentException("Indique niveles positivos o cero y colores RGB de 24 bits.", nameof(coloresPorNivel));
        ColorearTitulos = colorearTitulos;
        ColoresPorNivel = new ReadOnlyDictionary<int, int>(colores);
    }
}

/// <summary>Formato por tarea con comprobación de la selección real de Project.
/// Los delegados permiten validar el contrato sin automatizar Office.</summary>
internal static class MYGConfiguracionTitulosProject
{
    // Font32Ex utiliza COLORREF de Windows (0x00BBGGRR), no ARGB ni PjColor.
    internal static int ColorRef(int rgb)
    {
        if (rgb < 0 || rgb > 0xFFFFFF) throw new ArgumentOutOfRangeException(nameof(rgb));
        return ((rgb & 0xFF) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 0xFF);
    }

    internal static void Aplicar(MYGModeloExportacionProject modelo, MYGOpcionesTitulosProject opciones,
        Action prepararVista, Func<int, (int Id, int UniqueId)> leerTarea,
        Action<int> seleccionarFila, Func<int> leerUidSeleccionado, Action<int> aplicarColor)
    {
        ArgumentNullException.ThrowIfNull(modelo);
        ArgumentNullException.ThrowIfNull(opciones);
        if (!opciones.ColorearTitulos || !modelo.Tareas.Any(t => t.Resumen)) return;
        ArgumentNullException.ThrowIfNull(prepararVista);
        ArgumentNullException.ThrowIfNull(leerTarea);
        ArgumentNullException.ThrowIfNull(seleccionarFila);
        ArgumentNullException.ThrowIfNull(leerUidSeleccionado);
        ArgumentNullException.ThrowIfNull(aplicarColor);
        prepararVista();

        void Seleccionar(MYGTareaExportacionProject tarea)
        {
            var real = leerTarea(tarea.Uid);
            if (real.Id <= 0 || real.UniqueId <= 0)
                throw new InvalidOperationException("Microsoft Project no identifica la tarea «" + tarea.Nombre + "» para aplicar su formato.");
            seleccionarFila(real.Id);
            if (leerUidSeleccionado() != real.UniqueId)
                throw new InvalidOperationException("Microsoft Project seleccionó otra tarea al colorear «" + tarea.Nombre +
                    "». No se guardó el archivo; revise los filtros y la vista de Project.");
        }

        foreach (var tarea in modelo.Tareas.Where(t => t.Resumen))
        {
            Seleccionar(tarea);
            int nivel = tarea.NivelTitulo ?? Math.Max(0, tarea.Nivel - 1);
            int rgb = opciones.ColoresPorNivel.GetValueOrDefault(nivel, 0x263446);
            aplicarColor(ColorRef(rgb));
        }
        // El archivo se abre en la primera tarea, no en el último título.
        Seleccionar(modelo.Tareas[0]);
    }
}
