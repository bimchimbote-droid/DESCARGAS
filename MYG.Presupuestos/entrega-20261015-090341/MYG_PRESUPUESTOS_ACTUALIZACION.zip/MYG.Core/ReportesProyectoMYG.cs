using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGTipoReporteProyecto
{
    PresupuestoSeleccionado, TodosPresupuestos, HojaResumen, AnalisisCostosUnitarios,
    ConsolidadoCostosUnitarios, Metrados, MetradosAceros
}

public sealed class MYGHojaReporteProyecto
{
    public string Titulo { get; }
    public MYGHojaMetrado Hoja { get; }
    /// <summary>Información de cabecera congelada al crear el informe. No contiene
    /// vínculos a los datos editables del proyecto ni modifica la hoja de metrado.</summary>
    public IReadOnlyList<KeyValuePair<string, string>> DatosProyecto { get; }
    /// <summary>Activa la presentación de presupuesto de obra sin afectar los
    /// formatos de análisis, resumen ni las hojas originales de metrados.</summary>
    public bool EsPresupuestoObra { get; }
    /// <summary>Filas visibles de la cabecera. Los demás metadatos del proyecto
    /// se conservan en DatosProyecto para los informes que los necesitan.</summary>
    public IReadOnlyList<KeyValuePair<string, string>> CabeceraImpresion
    {
        get
        {
            if (!EsPresupuestoObra) return DatosProyecto;
            string Dato(string clave) => DatosProyecto.FirstOrDefault(d => d.Key == clave).Value ?? "No registrado";
            return Array.AsReadOnly(new KeyValuePair<string, string>[]
            {
                new("PROYECTO", Dato("Proyecto")), new("PRESUPUESTO", Dato("Presupuesto")),
                new("PROPIETARIO", Dato("Propietario")),
                new("UBICACIÓN", "DPTO: " + Dato("Departamento") + "  PROV: " + Dato("Provincia") + "  DIST: " + Dato("Distrito")),
                new("FECHA DE PROY.", Dato("Fecha de elaboración"))
            });
        }
    }

    public MYGHojaReporteProyecto(string titulo, MYGHojaMetrado hoja,
        IEnumerable<KeyValuePair<string, string>> datosProyecto = null, bool presupuestoObra = false)
    {
        Titulo = titulo ?? "";
        Hoja = hoja ?? throw new ArgumentNullException(nameof(hoja));
        DatosProyecto = Array.AsReadOnly((datosProyecto ?? Array.Empty<KeyValuePair<string, string>>())
            .Select(d => new KeyValuePair<string, string>(d.Key ?? "", d.Value ?? "")).ToArray());
        EsPresupuestoObra = presupuestoObra;
    }
}

/// <summary>Instantáneas de impresión. Los cálculos, la validación y los vínculos
/// de metrados viven en una copia completa y nunca cambian el editor abierto.</summary>
public static class MYGReportesProyecto
{
    public static IReadOnlyList<MYGHojaReporteProyecto> Crear(MYGProyectoDocumento documento,
        string presupuestoId, MYGTipoReporteProyecto tipo)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (!Enum.IsDefined(tipo)) throw new ArgumentOutOfRangeException(nameof(tipo));
        var trabajo = Preparar(documento);
        if (tipo == MYGTipoReporteProyecto.TodosPresupuestos)
            return trabajo.Presupuestos.OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.OrdinalIgnoreCase)
                .SelectMany(p => Presupuesto(trabajo, p, proyectoCompleto: true)).ToArray();
        var p = Elegir(trabajo, presupuestoId);
        var calculo = MYGMotorPresupuestos.CrearCalculo(p);
        return tipo switch
        {
            MYGTipoReporteProyecto.PresupuestoSeleccionado => Presupuesto(trabajo, p),
            MYGTipoReporteProyecto.HojaResumen => new[] { Resumen(trabajo, p, calculo) },
            MYGTipoReporteProyecto.AnalisisCostosUnitarios => Partidas(p).Select(i => Analisis(trabajo, p, i, calculo)).ToArray(),
            MYGTipoReporteProyecto.ConsolidadoCostosUnitarios => new[] { Consolidado(trabajo, p, calculo) },
            MYGTipoReporteProyecto.Metrados => Partidas(p).Select(i => Metrado(trabajo, p, i, calculo)).ToArray(),
            MYGTipoReporteProyecto.MetradosAceros => Partidas(p).Where(i => i.Costos.FuenteMetrado == MYGFuenteMetrado.Excel &&
                MYGPlantillasMetrado.Identificar(i.Costos.Hoja) == MYGPlantillasMetrado.Aceros)
                .Select(i => Metrado(trabajo, p, i, calculo)).ToArray(),
            _ => throw new ArgumentOutOfRangeException(nameof(tipo))
        };
    }

    /// <summary>Exporta hojas activas y sus dependencias. null incluye todas las
    /// plantillas; vacío selecciona las hojas importadas o de otras plantillas.
    /// Las hojas estándar antiguas se reconocen con el clasificador integrado.</summary>
    public static IReadOnlyList<MYGHojaMetrado> CrearMetradosExcel(MYGProyectoDocumento documento,
        string presupuestoId, string plantilla = null)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var trabajo = Preparar(documento);
        var p = Elegir(trabajo, presupuestoId);
        return MYGExcelPresupuestos.CrearHojasMetradoParaExportar(p, trabajo.Presupuestos, plantilla);
    }

    /// <summary>Prepara únicamente la partida activa, con la misma cabecera,
    /// formato y aislamiento de los informes completos de metrados.</summary>
    public static MYGHojaReporteProyecto CrearMetrado(MYGProyectoDocumento documento,
        string presupuestoId, string partidaId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var trabajo = Preparar(documento);
        var presupuesto = Elegir(trabajo, presupuestoId);
        var partida = presupuesto.Items.FirstOrDefault(i => string.Equals(i.Id, partidaId, StringComparison.OrdinalIgnoreCase));
        if (partida == null || MYGProyectoStorage.EsTitulo(partida))
            throw new InvalidOperationException("Seleccione una partida del presupuesto para generar su informe de metrados.");
        return Metrado(trabajo, presupuesto, partida, MYGMotorPresupuestos.CrearCalculo(presupuesto));
    }

    private static MYGProyectoDocumento Preparar(MYGProyectoDocumento documento)
    {
        var copia = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(copia);
        return copia;
    }

    private static MYGPresupuestoDocumento Elegir(MYGProyectoDocumento documento, string presupuestoId)
    {
        string id = string.IsNullOrWhiteSpace(presupuestoId) ? documento.PresupuestoActivoId : presupuestoId;
        return documento.Presupuestos.FirstOrDefault(p => string.Equals(p.Id, id, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("Seleccione un presupuesto del proyecto para generar este reporte.");
    }

    private static IEnumerable<ItemPresupuestoDelphin> Partidas(MYGPresupuestoDocumento p) =>
        MYGOrdenPresupuestos.FilasOrdenadas(p).Where(i => !MYGProyectoStorage.EsTitulo(i));
    private static string Num(decimal n) => n.ToString(CultureInfo.InvariantCulture);
    private const string FormatoNumeroInforme = "0.00";
    // La estructura y las especificaciones muestran el presupuesto seguido del
    // código íntegro de la partida. Item ya contiene todos sus capítulos: no se
    // vuelve a reconstruir ni a prefijar la jerarquía a partir de ParentId.
    private static string Codigo(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
        string.IsNullOrWhiteSpace(p.Item) ? i.Item ?? ""
            : string.IsNullOrWhiteSpace(i.Item) ? p.Item : p.Item + "." + i.Item;
    private static string Titulo(string tipo, MYGPresupuestoDocumento p) => tipo + " · " + p;
    private static string PartidaTitulo(string tipo, MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
        Titulo(tipo, p) + " · " + Codigo(p, i) + " " + i.Descripcion + " (" + i.Unidad + ")";

    private static IReadOnlyList<KeyValuePair<string, string>> DatosProyecto(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        bool proyectoCompleto = false)
    {
        var d = doc.Datos;
        static string Texto(string valor) => string.IsNullOrWhiteSpace(valor) ? "No registrado" : valor.Trim();
        static string Fecha(DateTime? valor) => valor.HasValue ? valor.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) : "No registrado";
        return Array.AsReadOnly(new KeyValuePair<string, string>[]
        {
            new("Proyecto", Texto(doc.Nombre)), new("Presupuesto", proyectoCompleto ? "" : Texto(p.ToString())),
            new("Propietario", Texto(d?.Propietario)), new("Portafolio", Texto(d?.Portafolio)),
            new("Tipo de obra", Texto(d?.TipoObra)), new("Departamento", Texto(d?.Departamento)),
            new("Provincia", Texto(d?.Provincia)), new("Distrito", Texto(d?.Distrito)),
            new("Localidad", Texto(d?.Localidad)), new("Fecha de elaboración", Fecha(d?.FechaElaboracion)),
            new("Fecha de inicio", Fecha(d?.FechaInicio)), new("Fecha de término", Fecha(d?.FechaFin)),
            new("Duración", d == null ? "No registrado" : d.Duracion.ToString(FormatoNumeroInforme, CultureInfo.CurrentCulture) + " " + Texto(d.UnidadDuracion)),
            new("Calendario", Texto(d?.Calendario)), new("Periodos", Texto(d?.Periodos)),
            new("Modalidad", d?.ModalidadEjecucion switch { "A" => "Administración directa", "C" => "Contrata", _ => "No registrado" }),
            new("Análisis", d == null ? "No registrado" : d.PorRendimientoCuadrilla ? "Rendimiento de cuadrilla" : "Asignación de recursos"),
            new("Elaborado por", Texto(d?.HechoPor)), new("Moneda", Texto(p.Costos.Moneda))
        });
    }

    private static MYGHojaMetrado Tabla(MYGProyectoDocumento doc, MYGPresupuestoDocumento p, string titulo,
        string[] encabezados, int[] anchos)
    {
        var h = new MYGHojaMetrado
        {
            Nombre = titulo, Filas = 100, Columnas = encabezados.Length, CeldaTotal = "A1",
            LineasDivision = false, Encabezados = false, ImprimirLineasDivision = false,
            ImprimirEncabezados = false, RepetirTitulos = true, FormatoNumeroPredeterminado = FormatoNumeroInforme,
            OrientacionPagina = encabezados.Length > 6 ? "Horizontal" : "Vertical", TamanoPapel = "A4",
            MargenIzquierdo = 0.4m, MargenDerecho = 0.4m, MargenSuperior = 0.5m, MargenInferior = 0.5m,
            AltosFilas = new() { [1] = 30, [2] = 32 }
        };
        h.RangosCombinados.Add("A1:" + MYGHojaCalculo.Columna(h.Columnas) + "1");
        Poner(h, 1, 1, titulo.Split(" · ")[0].ToUpperInvariant(), true);
        h.Celdas["A1"].TamanoFuente = 12;
        h.Celdas["A1"].ColorTexto = "18354F";
        h.Celdas["A1"].AlineacionHorizontal = "Centro";
        for (int c = 1; c <= encabezados.Length; c++)
        {
            h.AnchosColumnas[c] = anchos[c - 1];
            Poner(h, 2, c, encabezados[c - 1], true);
            var celda = h.Celdas[MYGHojaCalculo.Columna(c) + "2"];
            celda.ColorFondo = "18354F"; celda.ColorTexto = "FFFFFF";
            celda.Bordes = true; celda.AjustarTexto = true;
            celda.AlineacionHorizontal = encabezados[c - 1] is "Ítem" or "Código" or "Descripción" or "Concepto"
                or "Recurso" or "Insumo" or "Partida" or "Descripción / referencia" or "Activo BIM" or "Documento" or "Tabla"
                ? "Izquierda" : "Centro";
        }
        return h;
    }

    private static void Poner(MYGHojaMetrado h, int fila, int columna, string valor, bool negrita = false,
        string formato = null, bool centrar = false)
    {
        if (fila > 10000) throw new InvalidDataException("El reporte supera 10.000 filas. Divida el contenido en presupuestos más pequeños.");
        string dir = MYGHojaCalculo.Columna(columna) + fila;
        // Los literales numéricos y los que empiezan por '=' se guardan como
        // fórmulas de texto, para que el mismo motor conserve el código visible
        // y no interprete una descripción como una operación de la hoja.
        bool numero = MYGHojaCalculo.IntentarNumero(valor, out _);
        string contenido = formato == null && (numero || (valor ?? "").StartsWith('='))
            ? "=\"" + (valor ?? "").Replace("\"", "\"\"") + "\"" : valor;
        h.Poner(dir, contenido, negrita);
        var c = h.Celdas[dir];
        c.AlineacionPersonalizada = true; c.AjustarTexto = true;
        c.Fuente = "Arial"; c.TamanoFuente = 10; c.ColorTexto = "243746";
        c.AlineacionHorizontal = formato != null && numero || centrar ? "Centro" : "Izquierda";
        c.FormatoNumero = formato ?? h.FormatoNumeroPredeterminado;
        h.Filas = Math.Max(h.Filas, fila);
    }

    private static void Numero(MYGHojaMetrado h, int f, int c, decimal valor, bool negrita = false) =>
        Poner(h, f, c, Num(valor), negrita, FormatoNumeroInforme);
    private static void Banda(MYGHojaMetrado h, int fila, string titulo)
    {
        Poner(h, fila, 1, titulo, true);
        h.RangosCombinados.Add("A" + fila + ":" + MYGHojaCalculo.Columna(h.Columnas) + fila);
        h.Celdas["A" + fila].ColorFondo = "E7EDF2";
        h.Celdas["A" + fila].ColorTexto = "18354F";
        h.AltosFilas[fila] = 24;
    }
    private static void Terminar(MYGHojaMetrado h, int ultimaFila, int columnaTotal, int filaTotal)
    {
        h.Filas = Math.Max(ultimaFila, 2);
        h.CeldaTotal = MYGHojaCalculo.Columna(columnaTotal) + filaTotal;
        h.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(h.Columnas) + ultimaFila;
        MYGHojaCalculo.Validar(h);
    }

    private static IReadOnlyList<MYGHojaReporteProyecto> Presupuesto(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        bool proyectoCompleto = false)
    {
        var calculo = MYGMotorPresupuestos.CrearCalculo(p);
        var filas = MYGOrdenPresupuestos.FilasOrdenadas(p).ToArray();
        // Un presupuesto grande se reparte en hojas compatibles con el modelo de
        // impresión; sólo la última incluye el pie completo del presupuesto.
        const int maximo = 9988;
        int cantidad = Math.Max(1, (filas.Length + maximo - 1) / maximo);
        var resultado = new List<MYGHojaReporteProyecto>();
        for (int parte = 0; parte < cantidad; parte++)
        {
            string titulo = Titulo("Presupuesto", p) + (cantidad == 1 ? "" : " · Parte " + (parte + 1));
            var h = Tabla(doc, p, titulo, ["Ítem", "Descripción", "Unid.", "Cant.", "Precio", "Total"], [90, 320, 45, 65, 75, 115]);
            h.Celdas["A1"].Contenido = "PRESUPUESTO DE OBRA";
            Poner(h, 3, 1, p.Item, true); Poner(h, 3, 2, p.Nombre, true);
            Numero(h, 3, 6, calculo.Resumen().CostoDirecto, true);
            foreach (string direccion in new[] { "A3", "B3", "F3" }) h.Celdas[direccion].Subrayado = true;
            h.AltosFilas[3] = 25;
            int f = 4;
            foreach (var i in filas.Skip(parte * maximo).Take(maximo))
            {
                bool esTitulo = MYGProyectoStorage.EsTitulo(i);
                Poner(h, f, 1, Codigo(p, i), esTitulo); Poner(h, f, 2, i.Descripcion, esTitulo);
                if (!esTitulo)
                {
                    Poner(h, f, 3, i.Unidad, centrar: true);
                    Numero(h, f, 4, calculo.Cantidad(i));
                    Numero(h, f, 5, calculo.Analizar(i).PrecioUnitario);
                }
                Numero(h, f, 6, calculo.TotalPartida(i), esTitulo);
                if (esTitulo) h.AltosFilas[f] = 25;
                f++;
            }
            int filaTotal;
            if (parte == cantidad - 1) filaTotal = Pie(h, p, calculo.Resumen(), f + 1, 2, 5, 6);
            else { Poner(h, f + 1, 2, "Continúa en la siguiente hoja", true); filaTotal = f + 1; }
            FormatoPresupuesto(h);
            Terminar(h, filaTotal, 6, filaTotal);
            resultado.Add(new(titulo, h, DatosProyecto(doc, p, proyectoCompleto), presupuestoObra: true));
        }
        return resultado;
    }

    private static void FormatoPresupuesto(MYGHojaMetrado h)
    {
        h.FormatoNumeroPredeterminado = "#,##0.00";
        var calculo = new MYGHojaCalculo(h);
        foreach (var entrada in h.Celdas)
        {
            var c = entrada.Value;
            int fila = MYGHojaCalculo.Coordenadas(entrada.Key).Fila;
            c.ColorTexto = "000000";
            c.ColorFondo = fila == 2 ? "ECEEF1" : "";
            if (!calculo.Resultado(entrada.Key).EsNumero) continue;
            c.AlineacionHorizontal = "Derecha";
            c.FormatoNumero = "#,##0.00" + (c.FormatoNumero.EndsWith("\" %\"", StringComparison.Ordinal) ? "\" %\"" : "");
        }
    }

    private static int Pie(MYGHojaMetrado h, MYGPresupuestoDocumento p, MYGResumenCostos r,
        int f, int conceptoColumna, int porcentajeColumna, int importeColumna)
    {
        (string Texto, decimal? Porcentaje, decimal Importe)[] conceptos =
        [
            ("Costo directo", null, r.CostoDirecto),
            ("Gastos generales", p.Costos.GastosGeneralesPorcentaje, r.GastosGenerales),
            ("Utilidad", p.Costos.UtilidadPorcentaje, r.Utilidad),
            ("Parcial", null, r.Subtotal),
            ("I.G.V.", p.Costos.ImpuestoPorcentaje, r.Impuesto),
            ("Otros impuestos", p.Costos.OtrosImpuestosPorcentaje, r.OtrosImpuestos),
            ("Total", null, r.Total)
        ];
        foreach (var concepto in conceptos)
        {
            bool fuerte = concepto.Texto is "Costo directo" or "Parcial" or "Total";
            Poner(h, f, conceptoColumna, concepto.Texto, fuerte);
            if (concepto.Porcentaje.HasValue)
                Poner(h, f, porcentajeColumna, Num(concepto.Porcentaje.Value), formato: FormatoNumeroInforme + "\" %\"");
            Numero(h, f, importeColumna, concepto.Importe, fuerte);
            if (fuerte)
                foreach (var celda in h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == f).Select(c => c.Value))
                {
                    celda.ColorFondo = concepto.Texto == "Total" ? "18354F" : "E7EDF2";
                    celda.ColorTexto = concepto.Texto == "Total" ? "FFFFFF" : "18354F";
                }
            f++;
        }
        return f - 1;
    }

    private static MYGHojaReporteProyecto Resumen(MYGProyectoDocumento doc, MYGPresupuestoDocumento p, MYGCalculoPresupuesto calculo)
    {
        string titulo = Titulo("Hoja de resumen", p);
        var h = Tabla(doc, p, titulo, ["Concepto", "Porcentaje", "Importe (" + p.Costos.Moneda + ")"], [360, 120, 180]);
        int f = Pie(h, p, calculo.Resumen(), 3, 1, 2, 3);
        Terminar(h, f, 3, f);
        return new(titulo, h, DatosProyecto(doc, p));
    }

    private static MYGHojaReporteProyecto Analisis(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        ItemPresupuestoDelphin i, MYGCalculoPresupuesto calculo)
    {
        string titulo = PartidaTitulo("Análisis de costos unitarios", p, i);
        var h = Tabla(doc, p, titulo, ["Código", "Recurso", "Unidad", "Cuadrilla", "Cantidad", "% Desp.", "Precio", "Parcial"],
            [85, 290, 62, 75, 90, 70, 95, 95]);
        Banda(h, 3, Codigo(p, i) + " · " + i.Descripcion + " · Unidad: " + i.Unidad);
        Poner(h, 4, 1, "Rendimiento diario:"); Numero(h, 4, 3, i.Costos.RendimientoDiario);
        Poner(h, 4, 4, "Jornada (h):"); Numero(h, 4, 5, i.Costos.JornadaHoras);
        var a = calculo.Analizar(i); int f = 6;
        if (a.Recursos.Count == 0) { Banda(h, f++, "Precio directo: partida sin desglose de recursos."); }
        else
        {
            foreach (var grupo in MYGOrdenPresupuestos.GruposACU(i))
            {
                var recursos = a.Recursos.Where(r => r.Recurso.Grupo == grupo).ToArray();
                if (recursos.Length == 0) continue;
                Banda(h, f++, MYGMotorPresupuestos.Grupo(grupo));
                foreach (var r in recursos)
                {
                    Poner(h, f, 1, r.Codigo); Poner(h, f, 2, r.Descripcion); Poner(h, f, 3, r.Unidad, centrar: true);
                    if (r.Recurso.Modo == MYGModoCantidad.Rendimiento) Numero(h, f, 4, r.Recurso.NumeroRecursos);
                    Numero(h, f, 5, r.Cantidad);
                    Numero(h, f, 6, r.Recurso.DesperdicioPorcentaje);
                    Numero(h, f, 7, r.Precio);
                    Numero(h, f, 8, r.Total); f++;
                }
            }
            decimal diferencia = a.PrecioUnitario - a.Recursos.Sum(r => r.Total);
            if (diferencia != 0)
            {
                Poner(h, f, 2, "Ajuste del precio unitario importado de Delphin");
                Numero(h, f++, 8, diferencia);
            }
        }
        Poner(h, f, 2, "Precio unitario (" + p.Costos.Moneda + ")", true);
        Numero(h, f, 8, a.PrecioUnitario, true);
        Terminar(h, f, 8, f);
        return new(titulo, h, DatosProyecto(doc, p));
    }

    private static MYGHojaReporteProyecto Consolidado(MYGProyectoDocumento doc, MYGPresupuestoDocumento p, MYGCalculoPresupuesto calculo)
    {
        string titulo = Titulo("Consolidado de costos unitarios", p);
        var h = Tabla(doc, p, titulo, ["Código", "Insumo", "Unidad", "Cantidad", "Precio", "Total"], [90, 340, 70, 110, 100, 115]);
        var recursos = calculo.Consolidar(); int f = 3;
        foreach (var grupo in Enum.GetValues<MYGGrupoRecurso>())
        {
            var lineas = recursos.Where(r => r.Grupo == grupo).ToArray();
            if (lineas.Length == 0) continue;
            Banda(h, f++, MYGMotorPresupuestos.Grupo(grupo));
            foreach (var r in lineas)
            {
                Poner(h, f, 1, r.Codigo); Poner(h, f, 2, r.Descripcion); Poner(h, f, 3, r.Unidad, centrar: true);
                Numero(h, f, 4, r.Cantidad);
                Numero(h, f, 5, r.Precio);
                Numero(h, f, 6, r.Total); f++;
            }
        }
        decimal suma = recursos.Sum(r => r.Total), directo = calculo.Resumen().CostoDirecto;
        Poner(h, f, 2, "Total de insumos consolidados", true); Numero(h, f++, 6, suma, true);
        if (directo != suma)
        {
            Poner(h, f, 2, "Diferencia por parciales nativos / redondeo"); Numero(h, f++, 6, directo - suma);
        }
        Poner(h, f, 2, "Costo directo del presupuesto", true); Numero(h, f, 6, directo, true);
        Terminar(h, f, 6, f);
        return new(titulo, h, DatosProyecto(doc, p));
    }

    private static MYGHojaReporteProyecto Metrado(MYGProyectoDocumento doc, MYGPresupuestoDocumento p,
        ItemPresupuestoDelphin i, MYGCalculoPresupuesto calculo)
    {
        string titulo = PartidaTitulo("Metrados", p, i);
        if (i.Costos.FuenteMetrado == MYGFuenteMetrado.Excel)
        {
            var copia = MYGProyectoStorage.Copia(i.Costos.Hoja);
            PrepararImpresionMetrado(copia);
            return new(titulo, copia, DatosProyecto(doc, p));
        }
        MYGHojaMetrado h;
        int f = 3;
        if (i.Costos.FuenteMetrado == MYGFuenteMetrado.Manual)
        {
            h = Tabla(doc, p, titulo, ["Descripción / referencia", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Descuento", "Parcial"],
                [320, 80, 90, 80, 80, 80, 80, 100]);
            foreach (var m in i.Costos.Metrados)
            {
                Poner(h, f, 1, m.Descripcion + (string.IsNullOrWhiteSpace(m.Referencia) ? "" : " · " + m.Referencia));
                Numero(h, f, 2, m.Elementos);
                Numero(h, f, 3, m.CantidadPorElemento);
                if (m.Largo.HasValue) Numero(h, f, 4, m.Largo.Value);
                if (m.Ancho.HasValue) Numero(h, f, 5, m.Ancho.Value);
                if (m.Alto.HasValue) Numero(h, f, 6, m.Alto.Value);
                Poner(h, f, 7, m.Descuento ? "Sí" : "No", centrar: true);
                Numero(h, f++, 8, MYGMotorPresupuestos.Parcial(m));
            }
        }
        else if (i.Costos.FuenteMetrado == MYGFuenteMetrado.BIM)
        {
            h = Tabla(doc, p, titulo, ["Activo BIM", "Documento", "Tabla", "Unidad", "Fecha UTC", "Cantidad"], [200, 180, 180, 70, 150, 110]);
            h.OrientacionPagina = "Horizontal";
            foreach (var m in i.Costos.MetradosBIM)
            {
                Poner(h, f, 1, m.ActivoId); Poner(h, f, 2, m.DocumentoId); Poner(h, f, 3, m.Tabla); Poner(h, f, 4, m.Unidad, centrar: true);
                Poner(h, f, 5, m.FechaUtc == default ? "" : m.FechaUtc.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture), centrar: true);
                Numero(h, f++, 6, m.Cantidad);
            }
        }
        else
        {
            h = Tabla(doc, p, titulo, ["Ítem", "Partida", "Unidad", "Fuente", "Cantidad"], [100, 360, 75, 100, 120]);
            Poner(h, f, 1, Codigo(p, i)); Poner(h, f, 2, i.Descripcion); Poner(h, f, 3, i.Unidad, centrar: true); Poner(h, f, 4, "Cantidad", centrar: true);
            Numero(h, f++, 5, i.Costos.Cantidad);
        }
        Poner(h, f, 1, "Metrado total (" + i.Unidad + ")", true);
        Numero(h, f, h.Columnas, calculo.Cantidad(i), true);
        Terminar(h, f, h.Columnas, f);
        return new(titulo, h, DatosProyecto(doc, p));
    }

    private static void PrepararImpresionMetrado(MYGHojaMetrado h)
    {
        if (string.IsNullOrWhiteSpace(h.AreaImpresion))
        {
            var posiciones = h.Celdas.Keys.Select(MYGHojaCalculo.Coordenadas)
                .Concat(h.RangosCombinados.SelectMany(r => r.Split(':')).Select(MYGHojaCalculo.Coordenadas))
                .Append(MYGHojaCalculo.Coordenadas(h.CeldaTotal)).ToArray();
            int fila = Math.Max(2, posiciones.Max(c => c.Fila)), columna = posiciones.Max(c => c.Columna);
            h.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(columna) + fila;
        }
        var fin = MYGHojaCalculo.Coordenadas(h.AreaImpresion.Split(':')[^1]);
        for (int c = 1; c <= fin.Columna; c++)
            h.AnchosColumnas.TryAdd(c, c == 1 ? 280 : 85);
        // Las hojas existentes conservan papel, orientación, márgenes y títulos
        // que el usuario eligió. El formato de cifras se aplica a la copia de
        // impresión; el contenido, las fórmulas y la exportación Excel directa
        // conservan sus valores y su precisión original.
        h.FormatoNumeroPredeterminado = FormatoNumeroInforme;
        var calculo = new MYGHojaCalculo(h);
        foreach (var entrada in h.Celdas)
        {
            bool numero;
            try { numero = calculo.Resultado(entrada.Key).EsNumero; }
            catch (Exception ex) when (ex is FormatException or InvalidDataException or DivideByZeroException or OverflowException)
            { continue; }
            if (!numero) continue;
            var celda = entrada.Value;
            celda.FormatoNumero = FormatoNumeroInforme;
            celda.AlineacionHorizontal = "Centro";
            celda.AlineacionPersonalizada = true;
        }
        MYGHojaCalculo.Validar(h);
    }
}

public static partial class MYGExcelPresupuestos
{
    /// <summary>Selección por identidad de plantilla con cierre transitivo de
    /// dependencias. Las hojas de soporte no se descartan aunque su plantilla,
    /// presupuesto o fuente de metrado no coincidan con el filtro.</summary>
    public static IReadOnlyList<MYGHojaMetrado> CrearHojasMetradoParaExportar(
        MYGPresupuestoDocumento presupuesto, IEnumerable<MYGPresupuestoDocumento> presupuestos, string plantilla)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        var disponibles = (presupuestos ?? presupuesto.ContextoReferencias?.Presupuestos ?? new[] { presupuesto }).ToArray();
        var seleccion = new MYGPresupuestoDocumento
        {
            Id = presupuesto.Id, Item = presupuesto.Item, Nombre = presupuesto.Nombre,
            Items = MYGOrdenPresupuestos.FilasOrdenadas(presupuesto).Where(i => !MYGProyectoStorage.EsTitulo(i) &&
                i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel &&
                (plantilla == null || string.Equals(MYGPlantillasMetrado.Identificar(i.Costos.Hoja), plantilla, StringComparison.OrdinalIgnoreCase))).ToList()
        };
        var hojas = CrearHojasMetradoParaExportar(new[] { seleccion }, disponibles);
        var primarias = seleccion.Items.Select(i => MYGExportacionReferenciasExcel.Clave(presupuesto.Id, i.IdLocalMYG ?? i.Id)).ToHashSet();
        foreach (var h in hojas)
            if (!primarias.Contains(MYGExportacionReferenciasExcel.Clave(h.PresupuestoReferenciasId, h.PartidaReferenciasId)))
                h.Nombre = "Soporte " + h.Nombre;
        return hojas;
    }
}
