# Actualización: presupuesto de obra, escala y márgenes

Base: `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`, commit `b1c830b479ecfff794f743bfd84b9ec9b707f65e`.
Entrega de código fuente C# para Visual Studio 2026 y .NET SDK 10.0.100. No contiene ejecutables ni bases de datos.

## Cambios

- En **Imprimir proyecto → Presupuesto seleccionado**, la cabecera muestra proyecto, presupuesto seleccionado, propietario, ubicación y fecha de elaboración. En **Todos los presupuestos**, el campo Presupuesto queda vacío; las hojas conservan el nombre/código de cada presupuesto en su primera fila y sus importes independientes.
- Título **PRESUPUESTO DE OBRA**, cabecera gris, seis columnas, códigos completos, raíz subrayada, cifras con separadores de miles y dos decimales alineadas a la derecha. La precisión de cálculo no cambia.
- El menú **Escala** abre un editor con porcentaje (25–200 %) o máximo de páginas de ancho (1–10), Aceptar y Cancelar. Ajustar a una página incluye todas las columnas, aunque deba reducirlas por debajo del porcentaje mínimo manual. La ampliación de pantalla sigue siendo independiente.
- **Márgenes** ofrece Normal (25 mm en todos los lados), Estrecho (13 mm), Moderado (25 mm superior/inferior y 19 mm laterales) y Ancho (25 mm superior/inferior y 51 mm laterales).
- **Márgenes personalizados…** abre Configurar página, con papel A4/A3/Carta/Oficio, dimensiones en milímetros, orientación, cuatro márgenes y muestra gráfica. Cancelar conserva la configuración anterior; Aceptar actualiza todas las hojas de la vista.

Este formato se aplica a la vista preliminar, impresión y PDF de los informes de presupuesto. El libro de datos de la opción independiente Exportar presupuesto a Excel conserva su estructura existente.

## Instalación manual

1. Cierre la aplicación. Respalde la carpeta del código o confirme sus cambios locales antes de sustituir archivos.
2. Descargue y extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip`.
3. Copie su contenido sobre la raíz del código, junto a `MYG.Presupuestos.sln`, conservando las rutas relativas. Cree los dos archivos nuevos `MYG.Desktop/VistaPreliminarEscalaControl.cs` y `MYG.Desktop/VistaPreliminarPaginaDialog.cs`. Los demás archivos de código del ZIP reemplazan sus versiones completas; no hay eliminaciones.
4. Abra la solución en Visual Studio. No agregue manualmente los archivos C#: el SDK los incluye automáticamente.
5. Restaure dependencias y compile desde la raíz:

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

Las referencias NuGet permiten compilar el conector sin instalar Revit. Para usar las DLL de Revit instalado en Windows, omita `-p:UseRevitReferencePackages=true` y tenga Revit 2027 en la ruta configurada.

## Validación

En Linux x64: solución completa compilada con SDK 10.0.100, 0 errores y 0 advertencias; suite ejecutable de datos: **328 comprobaciones correctas**. Incluye aislamiento del documento, conservación de precisión, cabeceras según alcance, restauración de configuración y partición de columnas a una o varias páginas de ancho.

Las pruebas gráficas nuevas están compiladas, pero no se ejecutaron en Linux. Named Pipes de Windows se omite por plataforma; las muestras externas opcionales no se usaron. No se probó el servicio real de licencias ni la ejecución en Revit.

En Windows ejecute:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Compruebe manualmente:

1. Presupuesto seleccionado y Todos los presupuestos: datos de proyecto reales, Presupuesto visible/vacío según alcance, jerarquía y totales, incluyendo nombres largos e importes grandes.
2. Escala: porcentajes, una y dos páginas de ancho, Aceptar, Cancelar y Escape; compare la vista con el PDF.
3. Los cuatro preajustes y márgenes personalizados; papel A4/A3/Carta/Oficio, retrato/apaisado y conservación al cancelar. Revise la ventana con DPI 100 %, 150 % y 200 %.
4. PDF con **Microsoft Print to PDF** activado; si cambia de impresora al pulsar Exportar PDF, revise la vista actualizada y pulse de nuevo para guardar.

No hacen falta migraciones, secretos ni cambios de referencias del proyecto. Los ajustes de vista son temporales y no modifican la base SQLite ni el historial del documento.

## Actualizar GitHub después de aplicar el ZIP

En Visual Studio, abra **Cambios de Git**, compruebe la rama `main`, revise las diferencias, prepare los archivos y haga Commit. Después haga Push y verifique el nuevo commit en `bimchimbote-droid/MYG.Presupuestos`. La entrega del ZIP en el repositorio independiente DESCARGAS no publica cambios en la rama del código.

Si su carpeta local tiene cambios o commits posteriores a la base indicada, compare o fusione los archivos antes de reemplazarlos: la copia directa de un archivo completo puede sobrescribir esos avances.
