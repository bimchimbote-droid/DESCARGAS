using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MYG_2027;

internal readonly record struct MYGAjustesPaginaReporte(string Papel, string Orientacion,
    decimal IzquierdaMm, decimal DerechaMm, decimal SuperiorMm, decimal InferiorMm)
{
    internal static MYGAjustesPaginaReporte Desde(MYGHojaMetrado hoja) => new(hoja.TamanoPapel, hoja.OrientacionPagina,
        hoja.MargenIzquierdo * 25.4m, hoja.MargenDerecho * 25.4m, hoja.MargenSuperior * 25.4m, hoja.MargenInferior * 25.4m);

    internal (decimal Ancho, decimal Alto) DimensionesMm
    {
        get
        {
            var medidas = Papel switch
            {
                "A3" => (297m, 420m), "Carta" => (215.9m, 279.4m), "Oficio" => (215.9m, 355.6m),
                _ => (210m, 297m)
            };
            return Orientacion == "Horizontal" ? (medidas.Item2, medidas.Item1) : medidas;
        }
    }

    internal bool MargenesValidos
    {
        get
        {
            // Coincide con el área mínima admitida por ConfigurarPagina, cuyas medidas están en pulgadas.
            var medidas = Papel switch
            {
                "A4" => (8.27m, 11.69m), "A3" => (11.69m, 16.54m),
                "Carta" => (8.5m, 11m), "Oficio" => (8.5m, 14m), _ => (0m, 0m)
            };
            if (Orientacion == "Horizontal") medidas = (medidas.Item2, medidas.Item1);
            return Orientacion is "Vertical" or "Horizontal" &&
                IzquierdaMm is >= 0 and <= 76.2m && DerechaMm is >= 0 and <= 76.2m &&
                SuperiorMm is >= 0 and <= 76.2m && InferiorMm is >= 0 and <= 76.2m &&
                medidas.Item1 - (IzquierdaMm + DerechaMm) / 25.4m > .4m &&
                medidas.Item2 - (SuperiorMm + InferiorMm) / 25.4m > .5m;
        }
    }
}

/// <summary>Edición local de papel y márgenes: cancelar no modifica la vista preliminar.</summary>
internal sealed class MYGConfigurarPaginaReporteDialog : Form
{
    private readonly ComboBox papel = new() { Name = "vista_pagina_papel", DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
    private readonly RadioButton vertical = new() { Name = "vista_pagina_vertical", Text = "▯\r\nRetrato", Appearance = Appearance.Button, TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill };
    private readonly RadioButton horizontal = new() { Name = "vista_pagina_horizontal", Text = "▭\r\nApaisado", Appearance = Appearance.Button, TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill };
    private readonly TextBox ancho = new() { Name = "vista_pagina_ancho", ReadOnly = true, Dock = DockStyle.Fill };
    private readonly TextBox alto = new() { Name = "vista_pagina_alto", ReadOnly = true, Dock = DockStyle.Fill };
    private readonly NumericUpDown izquierda = Margen("vista_pagina_izquierda"), derecha = Margen("vista_pagina_derecha");
    private readonly NumericUpDown superior = Margen("vista_pagina_superior"), inferior = Margen("vista_pagina_inferior");
    private readonly MYGMargenesPaginaControl muestra = new() { Name = "vista_pagina_muestra", Dock = DockStyle.Fill, Margin = new Padding(0, 0, 20, 0) };
    private readonly Label error = new() { Name = "vista_pagina_error", AutoSize = false, Dock = DockStyle.Fill, ForeColor = Color.Maroon };

    internal MYGAjustesPaginaReporte Ajustes => new(papel.Text, horizontal.Checked ? "Horizontal" : "Vertical",
        izquierda.Value, derecha.Value, superior.Value, inferior.Value);

    internal MYGConfigurarPaginaReporteDialog(MYGAjustesPaginaReporte ajustes)
    {
        Name = "vista_configurar_pagina"; Text = "Configurar página";
        Font = new Font("Segoe UI", 9);
        AutoScaleDimensions = new SizeF(96, 96); AutoScaleMode = AutoScaleMode.Dpi;
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = MinimizeBox = false;
        ShowInTaskbar = false; ClientSize = new Size(820, 440);
        BackColor = Color.FromArgb(224, 235, 247); Padding = new Padding(20);
        var contenido = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2 };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 39));
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 61));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        contenido.Controls.Add(muestra, 0, 0);
        var opciones = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
        opciones.RowStyles.Add(new RowStyle(SizeType.Absolute, 210));
        opciones.RowStyles.Add(new RowStyle(SizeType.Absolute, 110));
        opciones.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var grupoPapel = new GroupBox { Text = "Papel", Dock = DockStyle.Fill, Padding = new Padding(12, 20, 12, 8) };
        var datosPapel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 4 };
        datosPapel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70));
        datosPapel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40));
        datosPapel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        datosPapel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        for (int i = 0; i < 4; i++) datosPapel.RowStyles.Add(new RowStyle(SizeType.Percent, 25));
        void Etiqueta(TableLayoutPanel tabla, string texto, int columna, int fila) => tabla.Controls.Add(
            new Label { Text = texto, AutoSize = true, Anchor = AnchorStyles.Left }, columna, fila);
        Etiqueta(datosPapel, "Tamaño:", 0, 0); datosPapel.Controls.Add(papel, 1, 0); datosPapel.SetColumnSpan(papel, 3);
        var unidad = new ComboBox { Name = "vista_pagina_unidad", DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
        unidad.Items.Add("Milímetros (mm)"); unidad.SelectedIndex = 0;
        Etiqueta(datosPapel, "Unidad:", 0, 1); datosPapel.Controls.Add(unidad, 1, 1);
        Etiqueta(datosPapel, "Anchura:", 0, 2); datosPapel.Controls.Add(ancho, 1, 2);
        Etiqueta(datosPapel, "Altura:", 0, 3); datosPapel.Controls.Add(alto, 1, 3);
        datosPapel.Controls.Add(vertical, 2, 1); datosPapel.SetRowSpan(vertical, 3);
        datosPapel.Controls.Add(horizontal, 3, 1); datosPapel.SetRowSpan(horizontal, 3);
        grupoPapel.Controls.Add(datosPapel); opciones.Controls.Add(grupoPapel, 0, 0);
        var grupoMargenes = new GroupBox { Text = "Márgenes de página (mm)", Dock = DockStyle.Fill, Padding = new Padding(12, 20, 12, 8) };
        var datosMargenes = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 2 };
        datosMargenes.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70));
        datosMargenes.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        datosMargenes.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70));
        datosMargenes.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        datosMargenes.RowStyles.Add(new RowStyle(SizeType.Percent, 50)); datosMargenes.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        Etiqueta(datosMargenes, "Izquierda:", 0, 0); datosMargenes.Controls.Add(izquierda, 1, 0);
        Etiqueta(datosMargenes, "Derecha:", 2, 0); datosMargenes.Controls.Add(derecha, 3, 0);
        Etiqueta(datosMargenes, "Superior:", 0, 1); datosMargenes.Controls.Add(superior, 1, 1);
        Etiqueta(datosMargenes, "Inferior:", 2, 1); datosMargenes.Controls.Add(inferior, 3, 1);
        grupoMargenes.Controls.Add(datosMargenes); opciones.Controls.Add(grupoMargenes, 0, 1);
        opciones.Controls.Add(error, 0, 2); contenido.Controls.Add(opciones, 1, 0);
        var botones = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        var cancelar = new Button { Name = "vista_pagina_cancelar", Text = "Cancelar", DialogResult = DialogResult.Cancel, Size = new Size(94, 30) };
        var aceptar = new Button { Name = "vista_pagina_aceptar", Text = "Aceptar", Size = new Size(94, 30) };
        aceptar.Click += (_, _) => IntentarAceptar();
        botones.Controls.Add(cancelar); botones.Controls.Add(aceptar);
        contenido.Controls.Add(botones, 0, 1); contenido.SetColumnSpan(botones, 2);
        Controls.Add(contenido); AcceptButton = aceptar; CancelButton = cancelar;
        papel.Items.AddRange(new object[] { "A4", "A3", "Carta", "Oficio" }); papel.SelectedItem = ajustes.Papel;
        vertical.Checked = ajustes.Orientacion != "Horizontal"; horizontal.Checked = ajustes.Orientacion == "Horizontal";
        izquierda.Value = Math.Clamp(ajustes.IzquierdaMm, 0, 76.2m); derecha.Value = Math.Clamp(ajustes.DerechaMm, 0, 76.2m);
        superior.Value = Math.Clamp(ajustes.SuperiorMm, 0, 76.2m); inferior.Value = Math.Clamp(ajustes.InferiorMm, 0, 76.2m);
        papel.SelectedIndexChanged += (_, _) => ActualizarMuestra();
        vertical.CheckedChanged += (_, _) => ActualizarMuestra(); horizontal.CheckedChanged += (_, _) => ActualizarMuestra();
        foreach (var margen in new[] { izquierda, derecha, superior, inferior }) margen.ValueChanged += (_, _) => ActualizarMuestra();
        ActualizarMuestra();
    }

    internal bool IntentarAceptar()
    {
        if (!Ajustes.MargenesValidos)
        {
            error.Text = "Los márgenes dejan un área de impresión demasiado pequeña.";
            return false;
        }
        DialogResult = DialogResult.OK;
        return true;
    }

    private void ActualizarMuestra()
    {
        var ajustes = Ajustes;
        var medida = ajustes.DimensionesMm;
        ancho.Text = medida.Ancho.ToString("0.##") + " mm"; alto.Text = medida.Alto.ToString("0.##") + " mm";
        muestra.Ajustes = ajustes; muestra.Invalidate(); error.Text = "";
    }

    private static NumericUpDown Margen(string nombre) => new() { Name = nombre, Minimum = 0, Maximum = 76.2m,
        DecimalPlaces = 2, Increment = 1, Dock = DockStyle.Fill, Margin = new Padding(3, 3, 8, 3) };
}

internal sealed class MYGMargenesPaginaControl : Control
{
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal MYGAjustesPaginaReporte Ajustes { get; set; } = new("A4", "Vertical", 25, 25, 25, 25);
    internal RectangleF PapelVisible { get; private set; }
    internal RectangleF AreaVisible { get; private set; }

    internal MYGMargenesPaginaControl()
    {
        DoubleBuffered = true;
        BackColor = Color.FromArgb(192, 207, 222);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var medida = Ajustes.DimensionesMm;
        float factor = Math.Min(Math.Max(1, ClientSize.Width - 64) / (float)medida.Ancho,
            Math.Max(1, ClientSize.Height - 54) / (float)medida.Alto);
        float ancho = (float)medida.Ancho * factor, alto = (float)medida.Alto * factor;
        PapelVisible = new RectangleF((ClientSize.Width - ancho) / 2, (ClientSize.Height - alto) / 2, ancho, alto);
        AreaVisible = new RectangleF(PapelVisible.Left + (float)Ajustes.IzquierdaMm * factor,
            PapelVisible.Top + (float)Ajustes.SuperiorMm * factor,
            Math.Max(0, ancho - (float)(Ajustes.IzquierdaMm + Ajustes.DerechaMm) * factor),
            Math.Max(0, alto - (float)(Ajustes.SuperiorMm + Ajustes.InferiorMm) * factor));
        using var sombra = new SolidBrush(Color.FromArgb(161, 177, 194));
        e.Graphics.FillRectangle(sombra, PapelVisible.X + 3, PapelVisible.Y + 3, ancho, alto);
        e.Graphics.FillRectangle(Brushes.White, PapelVisible);
        using var borde = new Pen(Color.FromArgb(158, 170, 184));
        e.Graphics.DrawRectangle(borde, PapelVisible.X, PapelVisible.Y, ancho, alto);
        using var guia = new Pen(Ajustes.MargenesValidos ? Color.Gray : Color.Firebrick) { DashStyle = DashStyle.Dash };
        e.Graphics.DrawLine(guia, AreaVisible.Left, PapelVisible.Top, AreaVisible.Left, PapelVisible.Bottom);
        e.Graphics.DrawLine(guia, AreaVisible.Right, PapelVisible.Top, AreaVisible.Right, PapelVisible.Bottom);
        e.Graphics.DrawLine(guia, PapelVisible.Left, AreaVisible.Top, PapelVisible.Right, AreaVisible.Top);
        e.Graphics.DrawLine(guia, PapelVisible.Left, AreaVisible.Bottom, PapelVisible.Right, AreaVisible.Bottom);
    }
}
