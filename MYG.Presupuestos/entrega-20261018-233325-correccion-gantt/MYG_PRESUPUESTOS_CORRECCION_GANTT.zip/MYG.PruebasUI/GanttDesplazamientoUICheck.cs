using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class GanttDesplazamientoUICheck
{
    private const uint WmMouseWheel = 0x020A, WmMouseMove = 0x0200;
    private const uint WmVScroll = 0x0115, WmHScroll = 0x0114, WmClose = 0x0010;
    private const uint SmtoAbortIfHung = 0x0002;
    private delegate bool EnumerarVentana(IntPtr ventana, IntPtr parametro);

    [DllImport("user32.dll", EntryPoint = "SendMessageTimeoutW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, uint mensaje, IntPtr wParam,
        IntPtr lParam, uint flags, uint timeout, out UIntPtr resultado);
    [DllImport("user32.dll", EntryPoint = "PostMessageW")]
    private static extern bool PublicarMensaje(IntPtr ventana, uint mensaje, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumerarVentana accion, IntPtr parametro);
    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr ventana);
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr ventana, out uint proceso);
    [DllImport("user32.dll", EntryPoint = "GetClassNameW", CharSet = CharSet.Unicode)]
    private static extern int ObtenerClase(IntPtr ventana, StringBuilder clase, int capacidad);
    [DllImport("user32.dll")]
    private static extern bool GetKeyboardState(byte[] estado);
    [DllImport("user32.dll")]
    private static extern bool SetKeyboardState(byte[] estado);
    [DllImport("gdi32.dll")]
    private static extern bool GdiFlush();
    [DllImport("dwmapi.dll")]
    private static extern int DwmFlush();

    internal static void Ejecutar(Action<bool, string> exige)
    {
        if (!OperatingSystem.IsWindows()) return;
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        Point cursorOriginal = Cursor.Position;
        try
        {
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                VerificarPanel(oscuro ? "oscuro" : "claro", exige);
            }
        }
        finally
        {
            Cursor.Position = cursorOriginal;
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarPanel(string tema, Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Regresión de desplazamiento del Gantt");
        var inicio = new DateTime(2026, 1, 5);
        var plan = new MYGCronograma { FechaInicio = inicio, FechaEstado = inicio.AddDays(6) };
        for (int i = 0; i < 300; i++)
            plan.Tareas.Add(new MYGTareaCronograma
            {
                Id = "GANTT-" + i, Codigo = (i + 1).ToString("000"), Nombre = "Actividad de control " + (i + 1),
                Modo = MYGModoTarea.Manual, InicioManual = inicio.AddDays(i % 150), DuracionDias = 2 + i % 6
            });
        int aplicaciones = 0, otrosCambios = 0;
        using var panel = new MYGPanelCronograma(() => plan, nuevo => { plan = nuevo; aplicaciones++; },
            () => true, () => otrosCambios++, () => otrosCambios++, () => otrosCambios++, () => documento);
        Rectangle escritorio = Screen.PrimaryScreen.WorkingArea;
        using var ventana = new Form
        {
            Text = "Regresión Gantt: " + tema, StartPosition = FormStartPosition.Manual,
            Location = new Point(escritorio.Left + 12, escritorio.Top + 12),
            ClientSize = new Size(Math.Min(1440, escritorio.Width - 40), Math.Min(800, escritorio.Height - 80))
        };
        ventana.Controls.Add(panel);

        // Un error de una acción del panel puede abrir MessageBox en un bucle
        // modal. Cerrarlo y registrar el fallo evita dejar la suite bloqueada.
        var dialogosPrevios = Ventanas("#32770").ToHashSet();
        var dialogosInesperados = new HashSet<IntPtr>();
        using var guardian = new System.Windows.Forms.Timer { Interval = 40 };
        guardian.Tick += (_, _) =>
        {
            foreach (IntPtr dialogo in Ventanas("#32770").Where(v => !dialogosPrevios.Contains(v)))
            {
                dialogosInesperados.Add(dialogo);
                PublicarMensaje(dialogo, WmClose, IntPtr.Zero, IntPtr.Zero);
            }
        };
        guardian.Start();
        ventana.Show();
        ventana.BringToFront();
        ventana.Activate();
        panel.Refrescar();
        ProcesarMensajes(80);
        var tabla = panel.Controls.Find("cronograma_tareas", true).OfType<DataGridView>().Single();
        var gantt = panel.Controls.Find("cronograma_gantt", true).OfType<MYGCronogramaGanttControl>().Single();
        Cursor.Position = new Point(ventana.Left + 30, ventana.Top + 8);
        ProcesarMensajes(30);
        exige(gantt.ClientSize.Width > 150 && gantt.ClientSize.Height > 180 &&
            gantt.VerticalScroll.Visible && gantt.HorizontalScroll.Visible,
            "La regresión necesita un Gantt visible con desplazamiento real en ambos ejes (" + tema + ").");
        Rectangle visible = gantt.RectangleToScreen(gantt.ClientRectangle);
        exige(escritorio.Contains(visible), "La captura debe incluir todo el cliente visible del Gantt (" + tema + ").");
        exige(tabla.ColumnHeadersHeight == gantt.AltoCabecera && tabla.Rows.Cast<DataGridViewRow>().All(f => f.Height == gantt.AltoFila),
            "Cabecera y filas deben compartir su altura al DPI real " + gantt.DeviceDpi + " (" + tema + ").");

        tabla.FirstDisplayedScrollingRowIndex = 35;
        gantt.IrFecha(inicio.AddDays(30));
        ProcesarMensajes(30);
        string planOriginal = JsonSerializer.Serialize(plan), documentoOriginal = JsonSerializer.Serialize(documento);
        string[] seleccionOriginal = Seleccion(tabla);
        string actualOriginal = (tabla.CurrentRow?.Tag as MYGResultadoTarea)?.Tarea.Id;
        int xOriginal = gantt.AutoScrollPosition.X;
        exige(xOriginal < 0 && gantt.AutoScrollPosition.Y < 0,
            "La prueba debe empezar desplazada en ambos ejes, lejos del origen (" + tema + ").");
        Comprobar("posición inicial");

        int yAnterior = gantt.AutoScrollPosition.Y;
        for (int i = 0; i < 5; i++) Rueda(gantt, -120);
        exige(gantt.AutoScrollPosition.Y < yAnterior && gantt.AutoScrollPosition.X == xOriginal,
            "La ráfaga nativa hacia abajo debe mover filas conservando el eje horizontal (" + tema + ").");
        Comprobar("ráfaga de rueda hacia abajo");
        yAnterior = gantt.AutoScrollPosition.Y;
        for (int i = 0; i < 3; i++) Rueda(gantt, 120);
        exige(gantt.AutoScrollPosition.Y > yAnterior && gantt.AutoScrollPosition.X == xOriginal,
            "La ráfaga nativa hacia arriba debe mover filas conservando el eje horizontal (" + tema + ").");
        Comprobar("ráfaga de rueda hacia arriba");
        for (int serie = 0; serie < 3; serie++)
        {
            Rueda(gantt, -120); Rueda(gantt, -120); Rueda(gantt, 120);
        }
        Comprobar("rueda alternada sin procesar WM_PAINT entre mensajes");

        yAnterior = gantt.AutoScrollPosition.Y;
        Enviar(gantt, WmVScroll, new IntPtr((128 * gantt.AltoFila << 16) | 4), IntPtr.Zero); // SB_THUMBPOSITION
        Enviar(gantt, WmVScroll, new IntPtr(8), IntPtr.Zero); // SB_ENDSCROLL
        exige(gantt.AutoScrollPosition.Y != yAnterior && gantt.AutoScrollPosition.X == xOriginal,
            "El mensaje nativo del deslizador debe mover el Gantt sin cambiar X (" + tema + ").");
        Comprobar("deslizador vertical y fin de arrastre");
        yAnterior = gantt.AutoScrollPosition.Y;
        Enviar(gantt, WmVScroll, new IntPtr(7), IntPtr.Zero); // SB_BOTTOM
        exige(gantt.AutoScrollPosition.Y < yAnterior,
            "La barra debe alcanzar realmente el extremo inferior de las 300 actividades (" + tema + ").");
        Comprobar("extremo inferior de la barra");
        Enviar(gantt, WmVScroll, new IntPtr(6), IntPtr.Zero); // SB_TOP
        exige(gantt.AutoScrollPosition.Y == 0, "La barra debe volver al inicio (" + tema + ").");
        Comprobar("regreso al inicio de la barra");

        tabla.FirstDisplayedScrollingRowIndex = 63;
        gantt.MostrarFila(63);
        exige(gantt.PrimeraFilaVisible == 63 && gantt.AutoScrollPosition.X == xOriginal,
            "MostrarFila debe situar la misma fila que la tabla manteniendo la fecha visible (" + tema + ").");
        Comprobar("desplazamiento programático de la tabla y MostrarFila");
        yAnterior = gantt.AutoScrollPosition.Y;
        gantt.IrFecha(inicio.AddDays(80));
        exige(gantt.AutoScrollPosition.X != xOriginal && gantt.AutoScrollPosition.Y == yAnterior,
            "IrFecha debe desplazar la escala sin mover las filas (" + tema + ").");
        Comprobar("desplazamiento programático IrFecha");
        int xAntesBarra = gantt.AutoScrollPosition.X;
        Enviar(gantt, WmHScroll, new IntPtr(3), IntPtr.Zero); // SB_PAGEDOWN
        exige(gantt.AutoScrollPosition.X < xAntesBarra && gantt.AutoScrollPosition.Y == yAnterior,
            "La barra horizontal debe mover fechas conservando el desplazamiento vertical (" + tema + ").");
        Comprobar("barra horizontal");

        float zoomOriginal = gantt.PixelesPorDia;
        RuedaConControl(gantt);
        exige(gantt.PixelesPorDia > zoomOriginal && gantt.AutoScrollPosition.Y == yAnterior,
            "Ctrl y rueda deben conservar el zoom del cronograma y sus filas (" + tema + ").");
        Comprobar("Ctrl y rueda");

        VerificarAusenciaAyudas(gantt, documento, ventana, tema, exige);
        Comprobar("posiciones antiguas de los mensajes emergentes");
        guardian.Stop();

        void Comprobar(string paso)
        {
            // Capturar ANTES de Invalidate/Update y sin DoEvents entre la
            // ráfaga y esta captura. DrawToBitmap repintaría y ocultaría justo
            // el defecto de ScrollWindowEx que se quiere detectar.
            using var inmediata = Capturar(gantt);
            ComprobarCabeceraUnica(inmediata, gantt.AltoCabecera, tema + ": " + paso, exige);
            gantt.Invalidate();
            gantt.Update();
            using var repintada = Capturar(gantt);
            double diferencia = Diferencia(inmediata, repintada);
            exige(diferencia <= .002,
                "La pantalla inmediata debe coincidir con un repintado completo, sin cabeceras pegadas (" + tema + ": " + paso +
                "; píxeles distintos " + diferencia.ToString("P3") + ").");
            exige(tabla.FirstDisplayedScrollingRowIndex == gantt.PrimeraFilaVisible,
                "Tabla y Gantt deben conservar la misma primera fila (" + tema + ": " + paso + ").");
            exige(Seleccion(tabla).SequenceEqual(seleccionOriginal) &&
                (tabla.CurrentRow?.Tag as MYGResultadoTarea)?.Tarea.Id == actualOriginal &&
                aplicaciones == 0 && otrosCambios == 0 && JsonSerializer.Serialize(plan) == planOriginal &&
                JsonSerializer.Serialize(documento) == documentoOriginal,
                "Navegar debe conservar selección, proyecto, programación e historial (" + tema + ": " + paso + ").");
            exige(dialogosInesperados.Count == 0,
                "El desplazamiento no debe abrir mensajes de error ni diálogos (" + tema + ": " + paso + ").");
        }
    }

    private static void VerificarAusenciaAyudas(MYGCronogramaGanttControl gantt, MYGProyectoDocumento documento,
        Form ventana, string tema, Action<bool, string> exige)
    {
        var ventanasIniciales = Application.OpenForms.Cast<Form>().ToArray();
        foreach (string posicion in new[] { "Defecto", "Parte superior derecha", "Parte superior izquierda",
            "Parte inferior derecha", "Parte inferior izquierda", "Ninguno" })
        {
            gantt.ConfigurarPresentacion(new MYGOpcionesVistaCronograma { PosicionMensaje = posicion }, documento);
            Cursor.Position = new Point(ventana.Left + 30, ventana.Top + 8);
            ProcesarMensajes(30);
            var ayudasPrevias = Ventanas("tooltips_class32").ToHashSet();
            var punto = new Point(Math.Min(180, gantt.ClientSize.Width / 2), gantt.AltoCabecera + gantt.AltoFila / 2);
            Cursor.Position = gantt.PointToScreen(punto);
            Enviar(gantt, WmMouseMove, IntPtr.Zero, new IntPtr((punto.Y << 16) | (punto.X & 0xffff)));
            ProcesarMensajes(800); // Incluye InitialDelay de la ayuda predeterminada.
            exige(!Ventanas("tooltips_class32").Any(v => !ayudasPrevias.Contains(v)) &&
                Application.OpenForms.Cast<Form>().SequenceEqual(ventanasIniciales),
                "Pasar el cursor no debe abrir ayudas ni diálogos aunque el proyecto guarde '" + posicion + "' (" + tema + ").");
            Cursor.Position = new Point(ventana.Left + 30, ventana.Top + 8);
            ProcesarMensajes(30);
        }
    }

    private static void ComprobarCabeceraUnica(Bitmap captura, int altoCabecera, string paso, Action<bool, string> exige)
    {
        if (SystemInformation.HighContrast) return;
        byte[] pixeles = Pixeles(captura);
        int color = MYG2027_TemaComercial.CabeceraTabla.ToArgb(), cabecera = 0, duplicadas = 0;
        for (int y = 1; y < captura.Height - 1; y++)
        {
            int coincidentes = 0, muestras = 0;
            for (int x = 3; x < captura.Width - 3; x += 3)
            {
                int i = (y * captura.Width + x) * 4;
                int rgb = unchecked((int)0xff000000) | pixeles[i + 2] << 16 | pixeles[i + 1] << 8 | pixeles[i];
                if (rgb == color) coincidentes++;
                muestras++;
            }
            if (coincidentes < muestras * .8) continue;
            if (y < altoCabecera - 1) cabecera++;
            else if (y > altoCabecera + 1) duplicadas++;
        }
        exige(cabecera >= altoCabecera / 4 && duplicadas == 0,
            "Debe haber una única cabecera fija y ninguna franja de meses/días copiada dentro de las filas (" + paso + ").");
    }

    private static string[] Seleccion(DataGridView tabla) => tabla.SelectedRows.Cast<DataGridViewRow>()
        .Select(f => ((MYGResultadoTarea)f.Tag).Tarea.Id).OrderBy(id => id, StringComparer.Ordinal).ToArray();

    private static void Rueda(Control destino, int delta, bool control = false)
    {
        Point punto = destino.PointToScreen(new Point(30, Math.Min(100, destino.ClientSize.Height / 2)));
        Enviar(destino, WmMouseWheel, new IntPtr(unchecked((delta << 16) | (control ? 8 : 0))),
            new IntPtr(unchecked((punto.Y << 16) | (punto.X & 0xffff))));
    }

    private static void RuedaConControl(Control destino)
    {
        // ModifierKeys lee el estado de teclado del hilo, no sólo MK_CONTROL
        // de wParam. Restaurarlo no envía teclas ni cambia el estado global.
        var original = new byte[256];
        if (!GetKeyboardState(original)) throw new InvalidOperationException("No se pudo leer el teclado para probar Ctrl y rueda.");
        var control = (byte[])original.Clone();
        control[0x11] |= 0x80; control[0xa2] |= 0x80;
        try
        {
            if (!SetKeyboardState(control)) throw new InvalidOperationException("No se pudo activar Ctrl para la prueba nativa.");
            Rueda(destino, 120, control: true);
        }
        finally
        {
            if (!SetKeyboardState(original)) throw new InvalidOperationException("No se pudo restaurar el estado del teclado de la prueba.");
        }
    }

    private static void Enviar(Control destino, uint mensaje, IntPtr wParam, IntPtr lParam)
    {
        var plazo = Stopwatch.StartNew();
        if (EnviarMensaje(destino.Handle, mensaje, wParam, lParam, SmtoAbortIfHung, 2000, out _) == IntPtr.Zero ||
            plazo.ElapsedMilliseconds > 2000)
            throw new InvalidOperationException($"El mensaje de Gantt 0x{mensaje:X} excedió el límite de dos segundos.");
    }

    private static IntPtr[] Ventanas(string clase)
    {
        var ventanas = new List<IntPtr>();
        EnumWindows((ventana, _) =>
        {
            GetWindowThreadProcessId(ventana, out uint proceso);
            if (proceso != (uint)Environment.ProcessId || !IsWindowVisible(ventana)) return true;
            var nombre = new StringBuilder(80);
            ObtenerClase(ventana, nombre, nombre.Capacity);
            if (nombre.ToString() == clase) ventanas.Add(ventana);
            return true;
        }, IntPtr.Zero);
        return ventanas.ToArray();
    }

    private static void ProcesarMensajes(int milisegundos)
    {
        var plazo = Stopwatch.StartNew();
        do { Application.DoEvents(); Thread.Sleep(5); } while (plazo.ElapsedMilliseconds < milisegundos);
    }

    private static Bitmap Capturar(Control control)
    {
        GdiFlush();
        DwmFlush(); // Sin procesar mensajes WinForms ni provocar WM_PAINT.
        var captura = new Bitmap(control.ClientSize.Width, control.ClientSize.Height, PixelFormat.Format32bppRgb);
        using var grafico = Graphics.FromImage(captura);
        grafico.CopyFromScreen(control.PointToScreen(Point.Empty), Point.Empty, captura.Size);
        return captura;
    }

    private static byte[] Pixeles(Bitmap captura)
    {
        var bloqueo = captura.LockBits(new Rectangle(Point.Empty, captura.Size), ImageLockMode.ReadOnly, PixelFormat.Format32bppRgb);
        try
        {
            var datos = new byte[checked(captura.Width * captura.Height * 4)];
            for (int y = 0; y < captura.Height; y++)
                Marshal.Copy(IntPtr.Add(bloqueo.Scan0, y * bloqueo.Stride), datos, y * captura.Width * 4, captura.Width * 4);
            return datos;
        }
        finally { captura.UnlockBits(bloqueo); }
    }

    private static double Diferencia(Bitmap primera, Bitmap segunda)
    {
        byte[] a = Pixeles(primera), b = Pixeles(segunda);
        int distintos = 0;
        for (int i = 0; i < a.Length; i += 4)
            if (Math.Abs(a[i] - b[i]) > 8 || Math.Abs(a[i + 1] - b[i + 1]) > 8 || Math.Abs(a[i + 2] - b[i + 2]) > 8) distintos++;
        return distintos / (double)(primera.Width * primera.Height);
    }
}
