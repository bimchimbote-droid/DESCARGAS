using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace MYG_2027;

// Sólo identifica detalle automático vacío. No elimina filas del documento
// editable ni considera que un cero calculado sea por sí solo una fila vacía.
internal static class MYGFilasVaciasMetradoExportacion
{
    internal static HashSet<int> Obtener(MYGHojaMetrado hoja)
    {
        var vacias = MYGContenidoPartida.FilasVaciasPlantilla(hoja).ToHashSet();
        var cabeceras = new[] { "DESCRIPCION", "ELEMENTOS", "CANTXELEM", "LARGO", "ANCHO", "ALTO", "PARCIAL" };
        var candidatas = hoja.Celdas.Select(c => (Posicion: MYGHojaCalculo.Coordenadas(c.Key), Texto: Etiqueta(c.Value.Contenido)))
            .Where(c => cabeceras.Contains(c.Texto)).GroupBy(c => c.Posicion.Fila)
            .Where(g => cabeceras.All(t => g.Count(c => c.Texto == t) == 1)).ToArray();
        var total = MYGHojaCalculo.Coordenadas(hoja.CeldaTotal);
        if (candidatas.Length == 1)
        {
            var cabecera = candidatas[0];
            int[] columnas = cabeceras.Select(t => cabecera.Single(c => c.Texto == t).Posicion.Columna).ToArray();
            bool ordenadas = columnas.SequenceEqual(columnas.OrderBy(c => c));
            bool etiquetaTotal = hoja.Celdas.Any(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == total.Fila && Etiqueta(c.Value.Contenido) == "TOTAL");
            if (ordenadas && total.Columna == columnas[^1] && total.Fila > cabecera.Key + 1 && etiquetaTotal)
            {
                var calculo = new MYGHojaCalculo(hoja);
                var contenidos = hoja.Celdas.Where(c => !string.IsNullOrWhiteSpace(c.Value.Contenido))
                    .GroupBy(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).ToDictionary(g => g.Key, g => g.ToArray());
                for (int fila = cabecera.Key + 1; fila < total.Fila; fila++)
                {
                    string direccion = MYGHojaCalculo.Columna(total.Columna) + fila;
                    if (contenidos.TryGetValue(fila, out var entradas) && entradas.Any(c => !string.Equals(c.Key, direccion, StringComparison.OrdinalIgnoreCase))) continue;
                    string parcial = hoja.Celdas.TryGetValue(direccion, out var celda) ? celda.Contenido : "";
                    if (!string.IsNullOrWhiteSpace(parcial))
                    {
                        string Ref(int indice) => MYGHojaCalculo.Columna(columnas[indice]) + fila.ToString(CultureInfo.InvariantCulture);
                        string esperado = "=ROUND(" + Ref(1) + "*" + Ref(2) +
                            string.Concat(Enumerable.Range(3, 3).Select(n => "*IF(ISBLANK(" + Ref(n) + "),1," + Ref(n) + ")")) + ",2)";
                        if (Formula(parcial) != esperado) continue;
                        try
                        {
                            var valor = calculo.Resultado(direccion);
                            if (!valor.EsNumero || valor.Numero() != 0) continue;
                        }
                        catch (Exception e) when (e is FormatException or System.IO.InvalidDataException or DivideByZeroException or OverflowException) { continue; }
                    }
                    vacias.Add(fila);
                }
            }
        }
        vacias.Remove(total.Fila);
        // Todas las filas de una celda combinada vertical pertenecen a su
        // contenido, aunque únicamente la esquina superior tenga texto.
        foreach (string rango in hoja.RangosCombinados)
        {
            string[] extremos = rango.Split(':');
            int primera = MYGHojaCalculo.Coordenadas(extremos[0]).Fila;
            int ultima = MYGHojaCalculo.Coordenadas(extremos[^1]).Fila;
            if (primera == ultima) continue;
            for (int fila = primera; fila <= ultima; fila++) vacias.Remove(fila);
        }
        return vacias;
    }

    private static string Formula(string texto) => string.Concat(MYGFuncionesExcel.AExcel(texto).Where(c => !char.IsWhiteSpace(c) && c != '$')).ToUpperInvariant();
    private static string Etiqueta(string texto)
    {
        var salida = new StringBuilder();
        foreach (char c in (texto ?? "").Normalize(NormalizationForm.FormD))
            if (char.IsLetterOrDigit(c)) salida.Append(char.ToUpperInvariant(c));
        return salida.ToString();
    }
}
