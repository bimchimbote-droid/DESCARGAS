# Vista preliminar y exportación de metrados corregida

Aplicar esta actualización sobre la última entrega de exportación de metrados (`DESCARGAS`, commit `fb32fd4234a5b859e4bdd086ccad88c26d41bcd5`), que ya incluye la corrección de lectura nativa de Delphin. Se conserva esa corrección; no regresar a una versión anterior. La base original del código es `main/e48bb43720f204ad310ecbae18afa784e4b4063d`, más las entregas anteriores aplicadas.

## Uso

En **Imprimir / PDF → Metrados (Formato DE Excel)** se mantienen **Presupuesto seleccionado** y **Proyecto completo**. Ambas opciones abren primero la vista preliminar de consulta. Desde **Archivo → Guardar como** se elige el archivo y la ubicación. Abrir o cerrar la vista no guarda automáticamente ni modifica el proyecto.

La exportación completa desde el panel de metrados usa la misma vista. El visor acepta los informes grandes mediante el perfil de exportación, sin ampliar los límites de las hojas editables. Para XLSX se utiliza el escritor ampliado; XLS 97-2003 conserva sus límites de 65.536 filas y 256 columnas.

## Corrección de #¡VALOR!

El escritor anterior convertía las celdas vacías con formato en cadenas `inlineStr` vacías. Excel podía considerarlas texto al recalcular `IF(ISBLANK(...),1,...)`, por lo que las multiplicaciones devolvían `#¡VALOR!` aunque la caché calculada por MYG fuera correcta.

Ahora esas celdas se escriben como celdas realmente vacías, conservando su estilo. El cero, los espacios introducidos y las fórmulas que producen texto vacío siguen siendo valores distintos: no se convierten indiscriminadamente en blancos.

## Eliminación real de filas sin información

El consolidado de vista preliminar/exportación elimina las filas de detalle que solo contienen el parcial automático vacío de una plantilla reconocida, incluidas las hojas nativas Delphin de esta incidencia. No se limita a ocultarlas. Conserva encabezados, totales, ceros introducidos, descripciones, observaciones, fórmulas propias y combinaciones verticales con información.

La copia consolidada remapea las direcciones, rangos y vínculos entre partidas. Cuando una fórmula apunta exclusivamente a una fila automática eliminada, conserva su resultado original; la comprobación de equivalencia confirma que no cambian los resultados. Las hojas libres que no puedan reconocerse con seguridad conservan su distribución. La hoja editable y las filas SQLite originales no se eliminan ni se reescriben por preparar el informe.

## Instalación

1. Respaldar o confirmar los cambios locales de Visual Studio y cerrar MYG.
2. Extraer el ZIP sobre la carpeta que ya contiene la última entrega, conservando las rutas. Los archivos REEMPLAZAR se entregan completos; comparar antes si se han modificado después.
3. Restaurar y compilar con SDK .NET 10.0.100 o el roll-forward permitido en `global.json`:

   ```powershell
   dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true
   dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --exportacion-metrados
   ```

4. Abrir una copia de la base, elegir presupuesto/proyecto, revisar la vista preliminar y guardar desde ella. Abrir el XLSX en Microsoft Excel y comprobar cantidades, totales y ausencia de filas automáticas vacías.
5. Revisar **Cambios de Git**, hacer Commit y Push a la rama elegida y verificar el resultado en GitHub. Publicar el ZIP no publica el código del proyecto automáticamente.

No hay paquetes nuevos, migraciones SQL, secretos ni cambios de conexión. No se incluye la base de datos del usuario. La comprobación visual de la interfaz y Microsoft Excel requiere Windows; las pruebas de estructura XLSX, cálculo y conservación se ejecutan también en Linux.

El formato XLSX admite hasta 1.048.576 filas y 16.384 columnas. El perfil mantiene una protección de memoria de 2.000.000 de celdas almacenadas y límites de combinaciones; no trunca partidas cuando se exceden. La edición de hojas conserva sus límites anteriores.

## Validación de esta corrección

La compilación completa se validó con .NET SDK 10.0.100 sin errores ni advertencias. La suite específica ejecutó 22 grupos, con inspección del XML de los blancos, eliminación real de filas, conservación de ceros/notas/fórmulas propias, combinaciones verticales, referencias a filas retiradas y preparación/exportación de una vista de más de 10.000 filas.

En los dos proyectos de la muestra se eliminaron 6.473 filas automáticas vacías. Los consolidados pasaron de 762/10.430 filas a 340/4.379 filas. La base original conservó su SHA-256. Los XLSX se recalcularon independientemente con LibreOffice 26.8: 0 errores, 2.910 fórmulas conservadas, 2.878 resultados idénticos y 32 equivalentes por redondeo numérico; ningún resultado distinto o ausente. Esto verifica LibreOffice y la estructura OOXML, no implica que se haya ejecutado Microsoft Excel.

Las pruebas visuales de Windows están compiladas; quedan pendientes la apertura visual de la ventana, el recorrido del menú y la comprobación del archivo en Microsoft Excel. No se ejecutó Revit en Linux.

## Archivos de esta entrega

Todos los archivos REEMPLAZAR se entregan completos. No hay eliminaciones ni parches que aplicar.

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `EXPORTACION_METRADOS_PRESUPUESTO_PROYECTO.md` | REEMPLAZAR | Instrucciones y validación |
| 2 | `MYG.Core/ConfiguracionVistaReporte.cs` | REEMPLAZAR | Preparación de informes amplios |
| 3 | `MYG.Core/FilasVaciasMetradoExportacion.cs` | CREAR | Detección de detalle automático vacío |
| 4 | `MYG.Core/HojaMetradoExcelEscritura.cs` | REEMPLAZAR | Blancos reales en XLSX |
| 5 | `MYG.Core/MYGReporteMetradosExcel.cs` | REEMPLAZAR | Compactación y remapeo de fórmulas |
| 6 | `MYG.Core/ReportesExportacion.cs` | REEMPLAZAR | Exportación desde la vista de impresión |
| 7 | `MYG.Desktop/EditorHerramientas.cs` | REEMPLAZAR | Vista previa para ambos alcances |
| 8 | `MYG.Desktop/PresupuestosExcelPanel.cs` | REEMPLAZAR | Vista previa desde el panel |
| 9 | `MYG.Desktop/ReportesExportacionWindows.cs` | REEMPLAZAR | Guardado desde informes amplios |
| 10 | `MYG.Desktop/VistaMetradosExcelForm.cs` | REEMPLAZAR | Consulta virtual y Guardar como |
| 11 | `MYG.Pruebas/CompactacionMetradosDelphinCheck.cs` | CREAR | Pruebas de regresión |
| 12 | `MYG.Pruebas/ExportacionBlancosExcelCheck.cs` | CREAR | Pruebas de regresión |
| 13 | `MYG.Pruebas/ExportacionMetradosGrandeCheck.cs` | REEMPLAZAR | Pruebas de regresión |
| 14 | `MYG.Pruebas/Program.cs` | REEMPLAZAR | Pruebas de regresión |
| 15 | `MYG.PruebasUI/ImprimirProyectoCheck.cs` | REEMPLAZAR | Pruebas de regresión |
| 16 | `MYG.PruebasUI/VistaMetradosExcelCheck.cs` | REEMPLAZAR | Pruebas de regresión |
