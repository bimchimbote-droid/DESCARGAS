using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using MYG_2027;

internal static class ExportacionBlancosExcelCheck
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    public static void Ejecutar(string carpeta, Action<string> pasa)
    {
        // La fórmula y la fila corresponden al caso de Delphin: una dimensión
        // visualmente vacía debe hacer que ISBLANK tome el factor neutro 1.
        var hoja = new MYGHojaMetrado { Nombre = "Metrado", Filas = 30, Columnas = 8, CeldaTotal = "G18" };
        hoja.Poner("A18", "Frente de obra"); hoja.Poner("B18", "1"); hoja.Poner("C18", "60");
        foreach (string direccion in new[] { "D18", "E18", "F18", "F2" })
        {
            hoja.Poner(direccion, ""); hoja.Celdas[direccion].Bordes = true;
            hoja.Celdas[direccion].ColorFondo = "E9F4FA";
        }
        hoja.Poner("A2", ""); hoja.Celdas["A2"].Contenido = null;
        hoja.Poner("C2", "0"); hoja.Poner("D2", " "); hoja.Poner("E2", "=\"\"");
        hoja.Poner("G18", "=ROUND(B18*C18*IF(ISBLANK(D18),1,D18)*IF(ISBLANK(E18),1,E18)*IF(ISBLANK(F18),1,F18),2)");
        hoja.Poner("H18", "=ISBLANK(E18)");
        hoja.Poner("C5", "=ISBLANK(C2)"); hoja.Poner("D5", "=ISBLANK(D2)");
        hoja.Poner("E5", "=ISBLANK(E2)"); hoja.Poner("F5", "=ISBLANK(F2)");
        Exige(new MYGHojaCalculo(hoja).Numero("G18") == 60, "La prueba no reproduce el cálculo nativo de Delphin.");
        string antes = JsonSerializer.Serialize(hoja);

        foreach (bool informe in new[] { false, true })
        {
            string ruta = Path.Combine(carpeta, informe ? "Blancos informe XLSX.xlsx" : "Blancos hoja XLSX.xlsx");
            if (informe) MYGExcelPresupuestos.GuardarParaExportacion(ruta, new[] { hoja });
            else MYGExcelPresupuestos.Guardar(ruta, new[] { hoja });
            var xml = Leer(ruta);
            foreach (string direccion in new[] { "D18", "E18", "F18", "F2", "A2" })
                Vacia(Celda(xml, direccion));
            var espacio = Celda(xml, "D2");
            Exige((string)espacio.Attribute("t") == "inlineStr" && espacio.Descendants(S + "t").Single().Value == " " &&
                (string)espacio.Descendants(S + "t").Single().Attribute(XNamespace.Xml + "space") == "preserve",
                "La exportación confundió un espacio con una celda vacía.");
            var cero = Celda(xml, "C2");
            Exige(cero.Attribute("t") == null && cero.Element(S + "v")?.Value == "0", "El cero se convirtió en un blanco.");
            var textoVacio = Celda(xml, "E2");
            Exige((string)textoVacio.Attribute("t") == "str" && textoVacio.Element(S + "f")?.Value == "\"\"" &&
                textoVacio.Element(S + "v") != null && textoVacio.Element(S + "v").Value.Length == 0,
                "La fórmula de texto vacío se convirtió en una celda sin contenido.");
            foreach (string direccion in new[] { "C5", "D5", "E5" })
                Exige(Celda(xml, direccion).Element(S + "v")?.Value == "0", "ISBLANK confundió cero, espacios o texto calculado con un blanco.");
            Exige(Celda(xml, "F5").Element(S + "v")?.Value == "1" && Celda(xml, "H18").Element(S + "v")?.Value == "1",
                "ISBLANK perdió el resultado verdadero para las celdas vacías.");
            Exige(Celda(xml, "G18").Element(S + "f")?.Value.Contains("IF(ISBLANK(E18),1,E18)", StringComparison.Ordinal) == true &&
                Celda(xml, "G18").Element(S + "v")?.Value == "60", "Se perdió la fórmula nativa o su resultado inicial.");
        }
        Exige(JsonSerializer.Serialize(hoja) == antes, "Exportar una hoja alteró su contenido o sus formatos.");
        pasa("XLSX escribe blancos con estilo sin t/is/v, preserva cero/espacios/fórmula de texto vacío y permite recalcular ISBLANK de Delphin");

        var documento = MYGProyectoStorage.Nuevo("PROYECTO DE BLANCOS XLSX", "PRESUPUESTO");
        var presupuesto = documento.Presupuestos.Single();
        string id = MYGProyectoStorage.NuevoId();
        presupuesto.Items.Add(new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, Item = "01", Posicion = 1, TipoPropuesta = "PARTIDA",
            Descripcion = "Metrado Delphin con dimensiones vacías", Unidad = "m",
            Costos = new MYGDatosPartida { FuenteMetrado = MYGFuenteMetrado.Excel, Hoja = hoja }
        });
        string proyectoAntes = JsonSerializer.Serialize(documento);
        var consolidado = MYGReporteMetradosExcel.CrearParaExportar(documento, presupuesto.Id).Hoja;
        string salida = Path.Combine(carpeta, "Blancos consolidado presupuesto.xlsx");
        MYGExcelPresupuestos.GuardarParaExportacion(salida, new[] { consolidado });
        var consolidadoXml = Leer(salida);
        var formulaDelphin = consolidadoXml.Descendants(S + "c").Single(c =>
            c.Element(S + "f")?.Value.StartsWith("ROUND(", StringComparison.Ordinal) == true);
        var referencias = Regex.Matches(formulaDelphin.Element(S + "f").Value, @"ISBLANK\((\$?[A-Z]{1,3}\$?[1-9][0-9]*)\)");
        Exige(referencias.Count == 3, "El consolidado sustituyó la fórmula por su caché en lugar de conservar las dimensiones editables.");
        foreach (Match referencia in referencias)
            Vacia(Celda(consolidadoXml, MYGHojaCalculo.Normalizar(referencia.Groups[1].Value)));
        Exige(decimal.Parse(formulaDelphin.Element(S + "v").Value, CultureInfo.InvariantCulture) == 60 &&
            JsonSerializer.Serialize(documento) == proyectoAntes,
            "La consolidación alteró el proyecto o perdió el metrado de 60.");
        pasa("El consolidado XLSX mantiene celdas realmente vacías en las referencias trasladadas de la fórmula Delphin, además de su caché de 60");
    }

    private static XDocument Leer(string ruta)
    { using var zip = ZipFile.OpenRead(ruta); using var flujo = zip.GetEntry("xl/worksheets/sheet1.xml").Open(); return XDocument.Load(flujo); }
    private static XElement Celda(XDocument xml, string direccion) => xml.Descendants(S + "c").Single(c => (string)c.Attribute("r") == direccion);
    private static void Vacia(XElement celda) => Exige(celda.Attribute("s") != null && celda.Attribute("t") == null &&
        !celda.HasElements && celda.Value.Length == 0, "Un blanco con formato se exportó como texto vacío; Excel ISBLANK lo trataría como un valor.");
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
}
