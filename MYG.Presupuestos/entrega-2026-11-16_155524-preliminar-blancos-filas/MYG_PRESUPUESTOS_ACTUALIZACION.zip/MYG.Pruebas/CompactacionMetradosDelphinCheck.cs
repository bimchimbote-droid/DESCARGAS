using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class CompactacionMetradosDelphinCheck
{
    private static void Exige(bool valor, string mensaje)
    { if (!valor) throw new Exception(mensaje); }

    private static MYGHojaMetrado HojaDelphin()
    {
        var h = new MYGHojaMetrado { Filas = 16, Columnas = 8, CeldaTotal = "G16", IdPlantilla = "" };
        h.Poner("A1", "Datos - preliminar"); h.Poner("D1", "Dimensiones"); h.Poner("G1", "Total");
        h.RangosCombinados.AddRange(new[] { "A1:C1", "D1:F1", "G1:H1" });
        string[] etiquetas = { "Descripción", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Parcial", "Plano - Referencia" };
        for (int c = 1; c <= etiquetas.Length; c++) h.Poner(MYGHojaCalculo.Columna(c) + "2", etiquetas[c - 1]);
        for (int f = 3; f <= 15; f++)
            h.Poner("G" + f, "=ROUND(B" + f + "*C" + f + "*IF(ISBLANK(D" + f + "),1,D" + f +
                ")*IF(ISBLANK(E" + f + "),1,E" + f + ")*IF(ISBLANK(F" + f + "),1,F" + f + "),2)");
        h.Poner("A3", "Frente sintético"); h.Poner("B3", "1"); h.Poner("C3", "60");
        h.Poner("A16", "Total:"); h.Poner("G16", "=ROUND(SUM(G3:G15),2)");
        return h;
    }

    private static ItemPresupuestoDelphin Partida(MYGHojaMetrado hoja, int posicion, string nombre)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, TipoPropuesta = "PARTIDA", Descripcion = nombre, Unidad = "m",
            Item = posicion.ToString("D2", CultureInfo.InvariantCulture), Posicion = posicion,
            Costos = new MYGDatosPartida { Hoja = hoja, FuenteMetrado = MYGFuenteMetrado.Excel }
        };
    }

    private static int Fila(MYGHojaMetrado h, string texto)
    {
        var calculo = new MYGHojaCalculo(h);
        return h.Celdas.Where(c => calculo.Mostrar(c.Key) == texto)
            .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Distinct().Single();
    }

    private static string Columna(MYGHojaMetrado consolidada, MYGHojaMetrado origen, int columna)
    {
        int ancho = 0;
        for (int c = 1; c < columna; c++)
            ancho += origen.AnchosColumnas.GetValueOrDefault(c, c == 1 ? 288 : c == 8 ? 110 : c is 2 or 3 ? 60 : c == 7 ? 95 : 68);
        int limite = Math.Max(0, (int)Math.Round(ancho / 8d, MidpointRounding.AwayFromZero) * 8);
        int actual = 0;
        for (int c = 1; c <= consolidada.Columnas; c++)
        {
            if (actual == limite) return MYGHojaCalculo.Columna(c);
            actual += consolidada.AnchosColumnas[c];
        }
        throw new Exception("No se encontró la columna original en el consolidado compacto.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("COMPACTACIÓN DE METRADOS SINTÉTICOS");
        var p = d.Presupuestos.Single();
        var a = Partida(HojaDelphin(), 1, "DELPHIN COMPACTO"); p.Items.Add(a);
        string antes = JsonSerializer.Serialize(d);
        var vista = MYGReporteMetradosExcel.Crear(d).Hoja;
        var h = MYGReporteMetradosExcel.CrearParaExportar(d).Hoja;
        int detalle = Fila(h, "Frente sintético"), total = Fila(h, "Total:");
        string parcial = Columna(h, a.Costos.Hoja, 7);
        Exige(vista.Filas - h.Filas == 12 && total == detalle + 1 && h.FilasOcultas.Count == 0 &&
            new MYGHojaCalculo(h).Numero(parcial + total) == 60 && JsonSerializer.Serialize(d) == antes,
            "El consolidado ocultó filas vacías en vez de quitarlas, perdió el total o modificó el origen.");
        string ruta = Path.Combine(carpeta, "Metrados Delphin compactos.xlsx");
        MYGReporteMetradosExcel.Exportar(ruta, d);
        using (var z = ZipFile.OpenRead(ruta))
        using (var flujo = z.GetEntry("xl/worksheets/sheet1.xml").Open())
        {
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            var x = XDocument.Load(flujo);
            Exige(!x.Descendants(s + "row").Any(r => (string)r.Attribute("hidden") == "1") &&
                x.Descendants(s + "row").Max(r => (int)r.Attribute("r")) <= h.Filas,
                "El archivo XLSX conserva filas automáticas ocultas o filas posteriores al consolidado compacto.");
        }
        pasa("El XLSX elimina doce filas automáticas vacías Delphin, contrae SUM y conserva total 60 sin ocultar ni cambiar el origen");

        a.Costos.Hoja.Poner("C4", "0");
        a.Costos.Hoja.Poner("G5", "=0");
        a.Costos.Hoja.Poner("H6", "Observación sin cantidades");
        a.Costos.Hoja.RangosCombinados.Add("A7:A8");
        a.Costos.Hoja.Poner("H16", "=IF(ISBLANK(A9),17,99)");
        antes = JsonSerializer.Serialize(d);
        h = MYGReporteMetradosExcel.CrearParaExportar(d).Hoja;
        detalle = Fila(h, "Frente sintético"); total = Fila(h, "Total:");
        parcial = Columna(h, a.Costos.Hoja, 7);
        string cantidad = Columna(h, a.Costos.Hoja, 3), observaciones = Columna(h, a.Costos.Hoja, 8);
        Exige(total - detalle == 6 && h.Celdas[cantidad + (detalle + 1)].Contenido == "0" &&
            h.Celdas[parcial + (detalle + 2)].Contenido == "=0" &&
            Fila(h, "Observación sin cantidades") == detalle + 3 &&
            h.RangosCombinados.Any(r => r.StartsWith("A" + (detalle + 4) + ":", StringComparison.Ordinal) && r.EndsWith((detalle + 5).ToString(CultureInfo.InvariantCulture), StringComparison.Ordinal)) &&
            new MYGHojaCalculo(h).Numero(observaciones + total) == 17 &&
            JsonSerializer.Serialize(d) == antes,
            "La compactación borró una entrada cero, fórmula propia, observación o combinación vertical, o rompió la referencia a una celda vacía eliminada.");
        pasa("Compactar conserva ceros introducidos, fórmulas propias, observaciones y combinaciones verticales y materializa referencias a filas eliminadas");

        var otra = Partida(HojaDelphin(), 2, "REFERENCIA A OTRA PARTIDA");
        otra.Costos.Hoja.Celdas["A3"].Contenido = "Detalle dependiente";
        otra.Costos.Hoja.Poner("H16", "=" + MYGReferenciasMetrado.CrearReferencia(otra.Costos.Hoja, p, a, "G16") + "+1");
        otra.Costos.Hoja.Poner("H15", "=" + MYGReferenciasMetrado.CrearReferencia(otra.Costos.Hoja, p, a, "G12") + "+3");
        p.Items.Add(otra);
        MYGReferenciasMetrado.Vincular(d.Presupuestos);
        antes = JsonSerializer.Serialize(d);
        h = MYGReporteMetradosExcel.CrearParaExportar(d).Hoja;
        int filaDetalle = Fila(h, "Detalle dependiente");
        // La fila15 con una fórmula propia se conserva y queda inmediatamente
        // antes del total; todas las filas automáticas intermedias se quitan.
        int totalOtra = filaDetalle + 2;
        observaciones = Columna(h, otra.Costos.Hoja, 8);
        var calculoFinal = new MYGHojaCalculo(h);
        Exige(calculoFinal.Numero(observaciones + totalOtra) == 61 &&
            calculoFinal.Numero(observaciones + (totalOtra - 1)) == 3 &&
            !h.Celdas.Values.Any(c => c.Contenido.Contains("METRADO(", StringComparison.OrdinalIgnoreCase)) &&
            JsonSerializer.Serialize(d) == antes,
            "La compactación perdió referencias entre partidas o creó vínculos a filas eliminadas.");
        pasa("Referencias entre partidas siguen el total reubicado y conservan el valor de una fila automática eliminada");

        var estandar = MYGProyectoStorage.Nuevo("PLANTILLA ESTÁNDAR COMPACTA");
        var e = Partida(MYGHojaMetrado.Crear(), 1, "ESTÁNDAR");
        e.Costos.Hoja.Poner("A3", "Entrada estándar"); e.Costos.Hoja.Poner("B3", "1"); e.Costos.Hoja.Poner("C3", "5");
        estandar.Presupuestos.Single().Items.Add(e);
        var original = MYGReporteMetradosExcel.Crear(estandar).Hoja;
        var compacta = MYGReporteMetradosExcel.CrearParaExportar(estandar).Hoja;
        Exige(original.Filas - compacta.Filas == 12 && compacta.FilasOcultas.Count == 0,
            "La exportación estándar sigue dependiendo de filas automáticas ocultas.");
        pasa("La exportación compacta también elimina físicamente las filas vacías de la plantilla estándar y conserva el comportamiento de la vista anterior");
    }
}
