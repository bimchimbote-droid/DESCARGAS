using System;
using System.Linq;

namespace MYG_2027;

// Actualizar la numeración no debe regenerar tareas ni alterar programación,
// avances o vínculos de un cronograma que el usuario ya ha editado.
public static class MYGCodigosCronogramaPresupuesto
{
    public static void Actualizar(MYGProyectoDocumento documento)
    {
        if (documento?.Cronograma?.Tareas == null) return;
        var presupuestos = documento.Presupuestos.Where(p => p.NumeracionCorrelativa)
            .ToDictionary(p => p.Id, StringComparer.OrdinalIgnoreCase);
        var items = presupuestos.ToDictionary(p => p.Key,
            p => p.Value.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase);
        foreach (var tarea in documento.Cronograma.Tareas)
        {
            if (string.IsNullOrWhiteSpace(tarea.PresupuestoId) ||
                !presupuestos.TryGetValue(tarea.PresupuestoId, out var presupuesto)) continue;
            if (string.IsNullOrWhiteSpace(tarea.PartidaId)) tarea.Codigo = presupuesto.Item;
            else if (items[presupuesto.Id].TryGetValue(tarea.PartidaId, out var item)) tarea.Codigo = item.Item;
        }
    }
}
