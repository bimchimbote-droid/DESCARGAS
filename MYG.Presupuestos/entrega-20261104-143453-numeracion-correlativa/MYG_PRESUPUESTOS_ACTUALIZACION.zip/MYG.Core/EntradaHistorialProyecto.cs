using System;
using System.Linq;
using System.Collections.Generic;

namespace MYG_2027;

/// <summary>Las ediciones locales conservan sólo los datos afectados; las restantes usan una instantánea completa.</summary>
public sealed class MYGEntradaHistorialProyecto
{
    private readonly MYGProyectoDocumento instantanea;
    private readonly string presupuestoId, partidaId;
    private readonly decimal cantidad;
    private readonly MYGFuenteMetrado fuente;
    private readonly ConfiguracionRevitAnterior configuracionRevit;
    private readonly EstructuraAnterior estructura;
    private readonly TextoAnterior descripcion;

    /// <summary>Presupuesto que requiere refresco estructural, sin reconstruir las demás vistas.</summary>
    public string PresupuestoEstructuraId => estructura == null ? null : presupuestoId;
    public string PresupuestoAfectadoId => instantanea == null ? presupuestoId : null;

    private sealed class TextoAnterior
    {
        internal string Descripcion, Estado, Mensaje;
    }

    private sealed class FilaAnterior
    {
        internal ItemPresupuestoDelphin Fila;
        internal string Id, Padre, Item, TipoPropuesta, IdLocalMYG;
        internal int Posicion;
    }

    private sealed class EstructuraAnterior
    {
        internal string ProyectoId, ActivoId, IdPresupuestoRevit, PrefijoNumeracionCorrelativa;
        internal bool NumeracionCorrelativa;
        internal FilaAnterior[] Filas;
        internal MYGAsignacionActivoRevit[] Asignaciones;
        internal Dictionary<string, string> CodigosCronograma;
    }

    private sealed class ConfiguracionRevitAnterior
    {
        internal string Plantilla, Parametro, Regla, Valor, Estado, Mensaje;
        internal System.Collections.Generic.List<FiltroPlanificacion> Filtros;
        internal int CantidadFiltros;
    }

    private MYGEntradaHistorialProyecto(MYGProyectoDocumento instantanea) => this.instantanea = instantanea;

    private MYGEntradaHistorialProyecto(string presupuestoId, string partidaId, decimal cantidad, MYGFuenteMetrado fuente)
    {
        this.presupuestoId = presupuestoId; this.partidaId = partidaId;
        this.cantidad = cantidad; this.fuente = fuente;
    }

    private MYGEntradaHistorialProyecto(string presupuestoId, string partidaId, ConfiguracionRevitAnterior configuracion)
    { this.presupuestoId = presupuestoId; this.partidaId = partidaId; configuracionRevit = configuracion; }

    private MYGEntradaHistorialProyecto(string presupuestoId, EstructuraAnterior estructura)
    { this.presupuestoId = presupuestoId; this.estructura = estructura; }

    private MYGEntradaHistorialProyecto(string presupuestoId, string partidaId, TextoAnterior descripcion)
    { this.presupuestoId = presupuestoId; this.partidaId = partidaId; this.descripcion = descripcion; }

    public static MYGEntradaHistorialProyecto CapturarDescripcion(MYGProyectoDocumento documento,
        MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin fila)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(fila);
        var original = ResolverFila(documento, presupuesto.Id, fila.Id);
        return new(presupuesto.Id, original.Id, new TextoAnterior
        { Descripcion = original.Descripcion, Estado = original.EstadoRevit, Mensaje = original.MensajeRevit });
    }

    /// <summary>Captura orden y numeración sin copiar ACU, especificaciones ni hojas de metrado.</summary>
    public static MYGEntradaHistorialProyecto CapturarEstructura(MYGProyectoDocumento documento,
        MYGPresupuestoDocumento presupuesto)
    {
        ArgumentNullException.ThrowIfNull(documento);
        ArgumentNullException.ThrowIfNull(presupuesto);
        var actual = ResolverPresupuesto(documento, presupuesto.Id);
        return new(actual.Id, new EstructuraAnterior
        {
            ProyectoId = documento.Id, ActivoId = documento.PresupuestoActivoId, IdPresupuestoRevit = actual.IdPresupuestoRevit,
            NumeracionCorrelativa = actual.NumeracionCorrelativa, PrefijoNumeracionCorrelativa = actual.PrefijoNumeracionCorrelativa,
            Filas = actual.Items.Select(i => new FilaAnterior
            { Fila = i, Id = i.Id, Padre = i.ParentId, Item = i.Item, Posicion = i.Posicion,
                TipoPropuesta = i.TipoPropuesta, IdLocalMYG = i.IdLocalMYG }).ToArray(),
            CodigosCronograma = documento.Cronograma?.Tareas?.Where(t => t != null && string.Equals(t.PresupuestoId, actual.Id, StringComparison.OrdinalIgnoreCase))
                .ToDictionary(t => t.Id, t => t.Codigo, StringComparer.OrdinalIgnoreCase)
                ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase),
            Asignaciones = documento.ActivosRevit?.Asignaciones
                .Where(a => string.Equals(a.PresupuestoId, actual.Id, StringComparison.OrdinalIgnoreCase))
                .Select(CopiarAsignacion).ToArray() ?? Array.Empty<MYGAsignacionActivoRevit>()
        });
    }

    private static MYGAsignacionActivoRevit CopiarAsignacion(MYGAsignacionActivoRevit a) => new()
    { PresupuestoId = a.PresupuestoId, PartidaId = a.PartidaId, ActivoId = a.ActivoId, IncluirEnTotal = a.IncluirEnTotal };

    public static MYGEntradaHistorialProyecto Capturar(MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(documento);
        return new(MYGProyectoStorage.Copia(documento));
    }

    public static MYGEntradaHistorialProyecto CapturarCantidad(MYGProyectoDocumento documento,
        MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(partida);
        var original = Resolver(documento, presupuesto.Id, partida.Id);
        return new(presupuesto.Id, original.Id, original.Costos.Cantidad, original.Costos.FuenteMetrado);
    }

    public static MYGEntradaHistorialProyecto CapturarConfiguracionRevit(MYGProyectoDocumento documento,
        MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(partida);
        var original = Resolver(documento, presupuesto.Id, partida.Id);
        var actual = documento.Presupuestos.First(p => string.Equals(p.Id, presupuesto.Id, StringComparison.OrdinalIgnoreCase));
        return new(presupuesto.Id, original.Id, new ConfiguracionRevitAnterior
        {
            Plantilla = original.Plantilla, Filtros = MYGProyectoStorage.Copia(original.Filtros),
            Parametro = original.Parametro, Regla = original.Regla, Valor = original.Valor,
            Estado = original.EstadoRevit, Mensaje = original.MensajeRevit, CantidadFiltros = actual.CantidadFiltros
        });
    }

    /// <summary>Debe capturarse antes de aplicar para conservar el orden de deshacer/rehacer.</summary>
    public MYGEntradaHistorialProyecto CapturarInversa(MYGProyectoDocumento documento)
    {
        if (instantanea != null) return Capturar(documento);
        if (estructura != null) return CapturarEstructura(documento, ResolverPresupuesto(documento, presupuestoId));
        if (descripcion != null) return CapturarDescripcion(documento, ResolverPresupuesto(documento, presupuestoId),
            ResolverFila(documento, presupuestoId, partidaId));
        var original = Resolver(documento, presupuestoId, partidaId);
        if (configuracionRevit != null)
            return CapturarConfiguracionRevit(documento,
                documento.Presupuestos.First(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)), original);
        return new(presupuestoId, partidaId, original.Costos.Cantidad, original.Costos.FuenteMetrado);
    }

    /// <summary>Vista aislada para comprobar permisos antes de aplicar. No se necesita para una edición local.</summary>
    public MYGProyectoDocumento CrearCandidato(MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (instantanea != null) return MYGProyectoStorage.Copia(instantanea);
        var candidato = MYGProyectoStorage.Copia(documento);
        return estructura == null ? Aplicar(candidato) : AplicarEstructura(candidato, aislarRestauradas: true);
    }

    public MYGProyectoDocumento Aplicar(MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (instantanea != null) return instantanea;
        if (estructura != null) return AplicarEstructura(documento, aislarRestauradas: false);
        if (descripcion != null)
        {
            var fila = ResolverFila(documento, presupuestoId, partidaId);
            fila.Descripcion = descripcion.Descripcion;
            fila.EstadoRevit = descripcion.Estado; fila.MensajeRevit = descripcion.Mensaje;
            return documento;
        }
        // Resolver ambos IDs antes de modificar: una fila eliminada o una
        // entrada ajena al proyecto no debe dejar un cambio parcial.
        var original = Resolver(documento, presupuestoId, partidaId);
        if (configuracionRevit != null)
        {
            original.Plantilla = configuracionRevit.Plantilla;
            original.Filtros = MYGProyectoStorage.Copia(configuracionRevit.Filtros);
            original.Parametro = configuracionRevit.Parametro; original.Regla = configuracionRevit.Regla; original.Valor = configuracionRevit.Valor;
            original.EstadoRevit = configuracionRevit.Estado; original.MensajeRevit = configuracionRevit.Mensaje;
            documento.Presupuestos.First(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)).CantidadFiltros = configuracionRevit.CantidadFiltros;
            return documento;
        }
        original.Costos.Cantidad = cantidad;
        original.Costos.FuenteMetrado = fuente;
        return documento;
    }

    private MYGProyectoDocumento AplicarEstructura(MYGProyectoDocumento documento, bool aislarRestauradas)
    {
        if (!string.Equals(documento.Id, estructura.ProyectoId, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("La estructura del historial pertenece a otro proyecto.");
        var presupuesto = ResolverPresupuesto(documento, presupuestoId);
        var actuales = presupuesto.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
        if (estructura.Asignaciones.Length > 0 && documento.ActivosRevit == null)
            throw new InvalidOperationException("El registro Revit del historial ya no existe.");
        // Las instantáneas completas intercaladas reemplazan los objetos. Siempre
        // preferir la fila actual por ID: conserva las ediciones deshechas antes
        // que ésta. Sólo las filas eliminadas se recuperan de la referencia guardada.
        var restauradas = new List<ItemPresupuestoDelphin>(estructura.Filas.Length);
        foreach (var anterior in estructura.Filas)
            restauradas.Add(actuales.TryGetValue(anterior.Id, out var actual) ? actual :
                aislarRestauradas ? MYGProyectoStorage.Copia(anterior.Fila) : anterior.Fila);
        for (int n = 0; n < restauradas.Count; n++)
        {
            var fila = restauradas[n]; var anterior = estructura.Filas[n];
            fila.ParentId = anterior.Padre; fila.Item = anterior.Item; fila.Posicion = anterior.Posicion;
            fila.TipoPropuesta = anterior.TipoPropuesta; fila.IdLocalMYG = anterior.IdLocalMYG;
        }
        presupuesto.Items = restauradas;
        presupuesto.IdPresupuestoRevit = estructura.IdPresupuestoRevit;
        presupuesto.NumeracionCorrelativa = estructura.NumeracionCorrelativa;
        presupuesto.PrefijoNumeracionCorrelativa = estructura.PrefijoNumeracionCorrelativa;
        documento.PresupuestoActivoId = estructura.ActivoId;
        if (documento.ActivosRevit != null)
        {
            documento.ActivosRevit.Asignaciones.RemoveAll(a =>
                string.Equals(a.PresupuestoId, presupuestoId, StringComparison.OrdinalIgnoreCase));
            documento.ActivosRevit.Asignaciones.AddRange(estructura.Asignaciones.Select(CopiarAsignacion));
        }
        // Activar la numeración también actualiza los códigos de tareas. La
        // primera captura puede proceder de un plan con códigos manuales y sin
        // marcador: restaurar sus valores, sin recalcular fechas ni vínculos.
        if (documento.Cronograma?.Tareas != null)
            foreach (var tarea in documento.Cronograma.Tareas)
                if (tarea != null && string.Equals(tarea.PresupuestoId, presupuestoId, StringComparison.OrdinalIgnoreCase) &&
                    estructura.CodigosCronograma.TryGetValue(tarea.Id, out var codigo)) tarea.Codigo = codigo;
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        return documento;
    }

    private static MYGPresupuestoDocumento ResolverPresupuesto(MYGProyectoDocumento documento, string presupuestoId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        return documento.Presupuestos?.FirstOrDefault(p => p != null &&
            string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("El presupuesto del historial ya no pertenece a este proyecto.");
    }

    private static ItemPresupuestoDelphin ResolverFila(MYGProyectoDocumento documento, string presupuestoId, string partidaId)
    {
        var presupuesto = ResolverPresupuesto(documento, presupuestoId);
        return presupuesto.Items?.FirstOrDefault(i => i != null &&
            string.Equals(i.Id, partidaId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("La fila del historial ya no pertenece a este proyecto.");
    }

    private static ItemPresupuestoDelphin Resolver(MYGProyectoDocumento documento, string presupuestoId, string partidaId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var presupuesto = documento.Presupuestos?.FirstOrDefault(p => p != null &&
            string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase));
        var partida = presupuesto?.Items?.FirstOrDefault(i => i != null &&
            string.Equals(i.Id, partidaId, StringComparison.OrdinalIgnoreCase));
        if (partida?.Costos == null || MYGProyectoStorage.EsTitulo(partida))
            throw new InvalidOperationException("La partida del historial ya no pertenece a este proyecto.");
        return partida;
    }
}
