using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

/// <summary>Numeración jerárquica por ubicación; las identidades de las filas permanecen intactas.</summary>
public static class MYGNumeracionCorrelativaPresupuesto
{
    private static readonly StringComparer Comparador = StringComparer.OrdinalIgnoreCase;

    public static void Aplicar(MYGPresupuestoDocumento presupuesto) =>
        MYGEstructuraPresupuestos.AplicarNumeracionCorrelativa(presupuesto);

    internal readonly record struct Fila(string Id, string ParentId, string Item, int Posicion);
    internal sealed class Plan
    {
        internal string Prefijo;
        internal Dictionary<string, (string Item, int Posicion)> Filas = new(Comparador);
    }

    // La inferencia se hace sobre el presupuesto anterior a insertar/eliminar.
    // El plan completo se prepara sin modificar filas ni activar el marcador.
    internal static Plan Preparar(MYGPresupuestoDocumento presupuesto, IEnumerable<Fila> filas)
    {
        string prefijo = presupuesto.NumeracionCorrelativa && presupuesto.PrefijoNumeracionCorrelativa != null
            ? presupuesto.PrefijoNumeracionCorrelativa : InferirPrefijo(presupuesto);
        if (prefijo.Length > 256 || prefijo.Length > 0 &&
            (!prefijo.EndsWith('.') || !EsCodigo(prefijo[..^1])))
            throw new InvalidDataException("El prefijo de numeración correlativa no es válido.");
        var todas = filas.ToList();
        var grupos = todas.GroupBy(x => Padre(x.ParentId), Comparador)
            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList(), Comparador);
        var plan = new Plan { Prefijo = prefijo };
        void Visitar(string padre, string codigoPadre, int nivel)
        {
            if (!grupos.TryGetValue(padre, out var hijos)) return;
            if (nivel > 64) throw new InvalidDataException("Jerarquía circular o demasiado profunda.");
            string primero = hijos.FirstOrDefault(x => EsCodigo(x.Item)).Item;
            int ancho = Math.Max(2, primero == null ? 2 : primero[(primero.LastIndexOf('.') + 1)..].Length);
            for (int n = 0; n < hijos.Count; n++)
            {
                string codigo = codigoPadre + (n + 1).ToString("D" + ancho, CultureInfo.InvariantCulture);
                if (!plan.Filas.TryAdd(hijos[n].Id, (codigo, n + 1)))
                    throw new InvalidDataException("Ítem duplicado o jerarquía circular.");
                Visitar(hijos[n].Id, codigo + ".", nivel + 1);
            }
        }
        Visitar("", prefijo, 0);
        if (plan.Filas.Count != todas.Count) throw new InvalidDataException("La jerarquía contiene ítems sin raíz.");
        return plan;
    }

    private static string Padre(string id) => string.IsNullOrWhiteSpace(id) || id == "__ROOT__" ? "" : id;
    private static bool EsCodigo(string codigo) => !string.IsNullOrWhiteSpace(codigo) &&
        codigo.Split('.').All(s => s.Length is > 0 and <= 16 && s.All(c => c is >= '0' and <= '9'));

    private static string InferirPrefijo(MYGPresupuestoDocumento presupuesto)
    {
        var items = presupuesto.Items ?? new();
        var hijos = items.Where(x => x != null).ToLookup(x => Padre(x.ParentId), Comparador);
        foreach (var raiz in hijos[""].OrderBy(x => x.Posicion).ThenBy(x => x.Item))
        {
            string codigo = raiz.Item;
            if (!EsCodigo(codigo))
            {
                // Un título recuperado puede carecer de número: sólo aceptar
                // la inferencia cuando sus hijos numéricos coinciden en padre.
                var candidatos = hijos[raiz.Id].Where(x => EsCodigo(x.Item) && x.Item.Contains('.'))
                    .Select(x => x.Item[..x.Item.LastIndexOf('.')]).Distinct(StringComparer.Ordinal).Take(2).ToList();
                if (candidatos.Count != 1) continue;
                codigo = candidatos[0];
            }
            int punto = codigo.LastIndexOf('.');
            return punto < 0 ? "" : codigo[..(punto + 1)];
        }
        return "";
    }
}
