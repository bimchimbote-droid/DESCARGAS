using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

// Las identidades, padres y fuentes se conservan. La numeración correlativa
// optativa acompaña el nuevo orden; los códigos manuales permanecen intactos.
// Las listas y sus objetos mantienen las instancias que utiliza el editor.
public static class MYGOrdenPresupuestos
{
    private static readonly StringComparer Comparador = StringComparer.OrdinalIgnoreCase;
    private static bool Igual(string a, string b) => Comparador.Equals(a ?? "", b ?? "");
    private static string Padre(string id) => string.IsNullOrWhiteSpace(id) || id == "__ROOT__" ? "" : id;
    private static void Direccion(int sentido)
    {
        if (sentido != -1 && sentido != 1)
            throw new InvalidOperationException("Seleccione subir o bajar una fila.");
    }

    public static bool PuedeMover(MYGProyectoDocumento documento, object nodo, int sentido)
    {
        if (documento?.Presupuestos == null || nodo == null || sentido != -1 && sentido != 1) return false;
        try
        {
            if (nodo is MYGPresupuestoDocumento presupuesto)
            {
                var orden = OrdenPresupuestos(documento);
                int n = orden.FindIndex(x => Igual(x.Id, presupuesto.Id));
                return n >= 0 && n + sentido >= 0 && n + sentido < orden.Count;
            }
            if (nodo is ItemPresupuestoDelphin item)
            {
                var p = PresupuestoDe(documento, item);
                var seleccionado = p.Items.Single(x => Igual(x.Id, item.Id));
                var orden = Hermanos(p, seleccionado);
                int n = orden.FindIndex(x => Igual(x.Id, seleccionado.Id));
                if (n + sentido < 0 || n + sentido >= orden.Count) return false;
                if (Protegida(p, seleccionado) || Protegida(p, orden[n + sentido])) return false;
                PosicionesEditables(p, orden, n, sentido);
                return true;
            }
            return false;
        }
        catch (InvalidOperationException) { return false; }
        catch (InvalidDataException) { return false; }
    }

    public static bool Mover(MYGProyectoDocumento documento, object nodo, int sentido)
    {
        ArgumentNullException.ThrowIfNull(documento);
        ArgumentNullException.ThrowIfNull(nodo);
        Direccion(sentido);
        var trabajo = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(trabajo);
        if (nodo is MYGPresupuestoDocumento presupuesto)
        {
            var orden = OrdenPresupuestos(trabajo);
            int n = orden.FindIndex(x => Igual(x.Id, presupuesto.Id));
            if (n < 0) throw new InvalidOperationException("El presupuesto seleccionado no pertenece al proyecto.");
            if (n + sentido < 0 || n + sentido >= orden.Count) return false;
            (orden[n], orden[n + sentido]) = (orden[n + sentido], orden[n]);
            for (int k = 0; k < orden.Count; k++) orden[k].Posicion = k + 1;
            trabajo.Presupuestos = orden;
            MYGProyectoStorage.Validar(trabajo);
            var originales = documento.Presupuestos.ToDictionary(x => x.Id, Comparador);
            var resultado = orden.Select(x => originales[x.Id]).ToList();
            foreach (var p in orden) originales[p.Id].Posicion = p.Posicion;
            documento.Presupuestos.Clear(); documento.Presupuestos.AddRange(resultado);
            return true;
        }
        if (nodo is not ItemPresupuestoDelphin item)
            throw new InvalidOperationException("Seleccione un presupuesto, título o partida.");
        var original = PresupuestoDe(documento, item);
        var copia = trabajo.Presupuestos.Single(x => Igual(x.Id, original.Id));
        var elegido = copia.Items.Single(x => Igual(x.Id, item.Id));
        var hermanos = Hermanos(copia, elegido);
        int indice = hermanos.FindIndex(x => Igual(x.Id, elegido.Id));
        if (Protegida(copia, elegido))
            throw new InvalidOperationException("Las filas oficiales se ordenan desde Delphin. Mueva únicamente propuestas MYG.");
        if (indice + sentido < 0 || indice + sentido >= hermanos.Count) return false;
        if (Protegida(copia, hermanos[indice + sentido]))
            throw new InvalidOperationException("Una propuesta no puede atravesar una rama oficial de Delphin.");
        var posiciones = PosicionesEditables(copia, hermanos, indice, sentido);
        foreach (var par in posiciones) copia.Items.Single(x => Igual(x.Id, par.Key)).Posicion = par.Value;
        copia.Items = OrdenJerarquico(copia);
        if (copia.NumeracionCorrelativa) MYGNumeracionCorrelativaPresupuesto.Aplicar(copia);
        MYGProyectoStorage.Validar(trabajo);
        var mapa = original.Items.ToDictionary(x => x.Id, Comparador);
        var ordenFinal = copia.Items.Select(x => mapa[x.Id]).ToList();
        foreach (var fila in copia.Items)
        {
            mapa[fila.Id].Posicion = fila.Posicion;
            if (copia.NumeracionCorrelativa) mapa[fila.Id].Item = fila.Item;
        }
        original.PrefijoNumeracionCorrelativa = copia.PrefijoNumeracionCorrelativa;
        original.Items.Clear(); original.Items.AddRange(ordenFinal);
        return true;
    }

    public static bool PuedeMoverRecurso(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida,
        MYGRecursoACU recurso, int sentido)
    {
        if (presupuesto?.Items == null || partida == null || recurso == null || sentido != -1 && sentido != 1) return false;
        var original = presupuesto.Items.FirstOrDefault(x => x != null && Igual(x.Id, partida.Id));
        if (original?.Costos?.Analisis == null || MYGProyectoStorage.EsTitulo(original)) return false;
        var actual = original.Costos.Analisis.FirstOrDefault(x => x != null && Igual(x.Id, recurso.Id));
        if (actual == null) return false;
        var grupo = original.Costos.Analisis.Where(x => x != null && x.Grupo == actual.Grupo).ToList();
        int n = grupo.IndexOf(actual);
        return n + sentido >= 0 && n + sentido < grupo.Count;
    }

    public static IReadOnlyList<MYGGrupoRecurso> GruposACU(ItemPresupuestoDelphin partida)
    {
        ArgumentNullException.ThrowIfNull(partida);
        return OrdenGruposACU(partida.Costos);
    }

    internal static IReadOnlyList<MYGGrupoRecurso> OrdenGruposACU(MYGDatosPartida datos)
    {
        var grupos = datos?.OrdenGruposACU;
        var predeterminados = Enum.GetValues<MYGGrupoRecurso>();
        // Los documentos anteriores pueden omitir la propiedad o guardarla nula.
        // Consultar el orden nunca normaliza ni modifica sus objetos originales.
        if (grupos == null || grupos.Count == 0) return Array.AsReadOnly(predeterminados);
        if (grupos.Count != predeterminados.Length || grupos.Distinct().Count() != predeterminados.Length ||
            grupos.Any(x => !Enum.IsDefined(x)))
            throw new InvalidDataException("El orden de los títulos del ACU debe incluir cada tipo de insumo una sola vez.");
        return Array.AsReadOnly(grupos.ToArray());
    }

    public static bool PuedeMoverGrupo(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida,
        MYGGrupoRecurso grupo, int sentido)
    {
        if (presupuesto?.Items == null || partida == null || !Enum.IsDefined(grupo) || sentido != -1 && sentido != 1) return false;
        var original = presupuesto.Items.FirstOrDefault(x => x != null && Igual(x.Id, partida.Id));
        if (original?.Costos == null || MYGProyectoStorage.EsTitulo(original)) return false;
        try
        {
            var orden = GruposACU(original).ToList();
            int n = orden.IndexOf(grupo);
            return n >= 0 && n + sentido >= 0 && n + sentido < orden.Count;
        }
        catch (InvalidDataException) { return false; }
    }

    public static void ReordenarGrupoACU(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida,
        MYGGrupoRecurso grupo, int sentido)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(partida);
        Direccion(sentido);
        if (!Enum.IsDefined(grupo)) throw new InvalidOperationException("Seleccione un título válido del ACU.");
        var original = presupuesto.Items?.FirstOrDefault(x => x != null && Igual(x.Id, partida.Id))
            ?? throw new InvalidOperationException("La partida no pertenece al presupuesto.");
        var trabajo = MYGProyectoStorage.Copia(presupuesto);
        MYGProyectoStorage.ValidarPresupuesto(trabajo);
        var copia = trabajo.Items.Single(x => Igual(x.Id, partida.Id));
        if (MYGProyectoStorage.EsTitulo(copia)) throw new InvalidOperationException("Seleccione una partida con análisis.");
        var orden = GruposACU(copia).ToList();
        int n = orden.IndexOf(grupo);
        if (n + sentido < 0 || n + sentido >= orden.Count) return;
        (orden[n], orden[n + sentido]) = (orden[n + sentido], orden[n]);
        copia.Costos.OrdenGruposACU = orden;
        MYGProyectoStorage.ValidarPresupuesto(trabajo);
        // Sólo se publica esta propiedad. Conserva la instancia de los datos de
        // costo, el análisis y todos los recursos que usa el editor.
        if (original.Costos == null) throw new InvalidDataException("La partida no tiene datos de costo.");
        original.Costos.OrdenGruposACU = orden;
    }

    public static bool ReordenarRecursoACU(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida,
        MYGRecursoACU recurso, int sentido)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(partida);
        ArgumentNullException.ThrowIfNull(recurso);
        Direccion(sentido);
        var trabajo = MYGProyectoStorage.Copia(presupuesto);
        MYGProyectoStorage.ValidarPresupuesto(trabajo);
        var original = presupuesto.Items.FirstOrDefault(x => Igual(x.Id, partida.Id))
            ?? throw new InvalidOperationException("La partida no pertenece al presupuesto.");
        var copia = trabajo.Items.Single(x => Igual(x.Id, partida.Id));
        if (MYGProyectoStorage.EsTitulo(copia)) throw new InvalidOperationException("Seleccione una partida con análisis.");
        var linea = copia.Costos.Analisis.FirstOrDefault(x => Igual(x.Id, recurso.Id))
            ?? throw new InvalidOperationException("El recurso no pertenece al análisis seleccionado.");
        var grupo = copia.Costos.Analisis.Where(x => x.Grupo == linea.Grupo).ToList();
        int n = grupo.IndexOf(linea);
        if (n + sentido < 0 || n + sentido >= grupo.Count) return false;
        bool conservaPrecio = MYGMotorPresupuestos.ConservaAnalisisDelphin(trabajo, copia);
        var antes = MYGMotorPresupuestos.Analizar(trabajo, copia).PrecioUnitario;
        var parcial = MYGMotorPresupuestos.TotalPartida(trabajo, copia);
        int a = copia.Costos.Analisis.IndexOf(linea), b = copia.Costos.Analisis.IndexOf(grupo[n + sentido]);
        (copia.Costos.Analisis[a], copia.Costos.Analisis[b]) = (copia.Costos.Analisis[b], copia.Costos.Analisis[a]);
        if (conservaPrecio) copia.Costos.FirmaAnalisisImportadoDelphin = MYGMotorPresupuestos.FirmaAnalisis(trabajo, copia);
        MYGProyectoStorage.ValidarPresupuesto(trabajo);
        if (MYGMotorPresupuestos.Analizar(trabajo, copia).PrecioUnitario != antes ||
            MYGMotorPresupuestos.TotalPartida(trabajo, copia) != parcial)
            throw new InvalidOperationException("Reordenar recursos no debe cambiar el precio ni el total de la partida.");
        var lista = original.Costos.Analisis;
        var recursos = lista.ToDictionary(x => x.Id, Comparador);
        var orden = copia.Costos.Analisis.Select(x => recursos[x.Id]).ToList();
        lista.Clear(); lista.AddRange(orden);
        if (conservaPrecio) original.Costos.FirmaAnalisisImportadoDelphin = copia.Costos.FirmaAnalisisImportadoDelphin;
        return true;
    }

    private static List<MYGPresupuestoDocumento> OrdenPresupuestos(MYGProyectoDocumento d) =>
        d.Presupuestos.OrderBy(x => x.Posicion).ThenBy(x => x.Item, Comparador).ToList();

    public static IReadOnlyList<ItemPresupuestoDelphin> FilasOrdenadas(MYGPresupuestoDocumento presupuesto)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        return OrdenJerarquico(presupuesto);
    }

    private static MYGPresupuestoDocumento PresupuestoDe(MYGProyectoDocumento d, ItemPresupuestoDelphin item)
    {
        var porReferencia = d.Presupuestos.FirstOrDefault(x => x.Items?.Any(i => ReferenceEquals(i, item)) == true);
        if (porReferencia != null) return porReferencia;
        var candidatos = d.Presupuestos.Where(x => x.Items?.Any(i => i != null && Igual(i.Id, item.Id)) == true).ToList();
        if (candidatos.Count != 1) throw new InvalidOperationException("El ítem seleccionado no pertenece inequívocamente al proyecto.");
        return candidatos[0];
    }

    private static List<ItemPresupuestoDelphin> Hermanos(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
        p.Items.Where(x => Igual(Padre(x.ParentId), Padre(i.ParentId)))
            .OrderBy(x => x.Posicion).ThenBy(x => x.Item, Comparador).ToList();

    private static bool Protegida(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
        MYGEstructuraPresupuestos.Rama(p, i).Any(x => !string.IsNullOrWhiteSpace(x.IdInternoDelphin));

    private static Dictionary<string, int> PosicionesEditables(MYGPresupuestoDocumento p,
        List<ItemPresupuestoDelphin> hermanos, int indice, int sentido)
    {
        int primero = indice, ultimo = indice;
        while (primero > 0 && !Protegida(p, hermanos[primero - 1])) primero--;
        while (ultimo + 1 < hermanos.Count && !Protegida(p, hermanos[ultimo + 1])) ultimo++;
        var segmento = hermanos.GetRange(primero, ultimo - primero + 1);
        var posiciones = segmento.Select(x => x.Posicion).ToArray();
        long inferior = primero == 0 ? 0 : hermanos[primero - 1].Posicion;
        long superior = ultimo == hermanos.Count - 1 ? (long)int.MaxValue + 1 : hermanos[ultimo + 1].Posicion;
        bool validas = posiciones.Distinct().Count() == posiciones.Length && posiciones[0] > inferior && posiciones[^1] < superior;
        if (primero == 0 && ultimo == hermanos.Count - 1 || !validas)
        {
            if (superior - inferior <= segmento.Count)
                throw new InvalidOperationException("No hay posiciones disponibles entre las ramas oficiales. Actualice su orden desde Delphin.");
            for (int k = 0; k < posiciones.Length; k++) posiciones[k] = checked((int)(inferior + k + 1));
        }
        int actual = indice - primero;
        (segmento[actual], segmento[actual + sentido]) = (segmento[actual + sentido], segmento[actual]);
        var resultado = new Dictionary<string, int>(Comparador);
        for (int k = 0; k < segmento.Count; k++) resultado.Add(segmento[k].Id, posiciones[k]);
        return resultado;
    }

    private static List<ItemPresupuestoDelphin> OrdenJerarquico(MYGPresupuestoDocumento p)
    {
        var grupos = p.Items.GroupBy(x => Padre(x.ParentId), Comparador).ToDictionary(x => x.Key,
            x => x.OrderBy(i => i.Posicion).ThenBy(i => i.Item, Comparador).ToList(), Comparador);
        var resultado = new List<ItemPresupuestoDelphin>();
        void Visitar(string padre)
        {
            if (!grupos.TryGetValue(padre, out var hijos)) return;
            foreach (var i in hijos) { resultado.Add(i); Visitar(i.Id); }
        }
        Visitar("");
        return resultado;
    }
}
