using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGDestinoArrastre { Antes, Dentro, Despues }

// Los IDs del presupuesto y de las filas viajan por separado: nunca se decide
// el propietario por el ID de una partida que puede repetirse en otro presupuesto.
public static class MYGArrastrePresupuestos
{
    private static readonly StringComparer Comparador = StringComparer.OrdinalIgnoreCase;
    private static bool Igual(string a, string b) => Comparador.Equals(a ?? "", b ?? "");
    private static string Padre(string id) => string.IsNullOrWhiteSpace(id) || id == "__ROOT__" ? null : id;
    private sealed record Plan(string PadreId, Dictionary<string, int> Posiciones);

    public static bool PuedeMover(MYGProyectoDocumento documento, string presupuestoId, string itemId,
        string presupuestoDestinoId, string destinoId, MYGDestinoArrastre modo) =>
        PuedeMover(documento, presupuestoId, itemId, presupuestoDestinoId, destinoId, modo, out _);

    public static bool PuedeMover(MYGProyectoDocumento documento, string presupuestoId, string itemId,
        string presupuestoDestinoId, string destinoId, MYGDestinoArrastre modo, out string motivo)
    {
        try
        {
            var p = Presupuesto(documento, presupuestoId, presupuestoDestinoId);
            bool cambia = Planificar(p, itemId, destinoId, modo) != null;
            motivo = cambia ? "" : "La fila ya ocupa esa posición.";
            return cambia;
        }
        catch (Exception ex) when (ex is InvalidOperationException or InvalidDataException or ArgumentException)
        { motivo = ex.Message; return false; }
    }

    public static bool Mover(MYGProyectoDocumento documento, string presupuestoId, string itemId,
        string presupuestoDestinoId, string destinoId, MYGDestinoArrastre modo)
    {
        var original = Presupuesto(documento, presupuestoId, presupuestoDestinoId);
        var trabajo = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(trabajo);
        var copia = Presupuesto(trabajo, presupuestoId, presupuestoDestinoId);
        var plan = Planificar(copia, itemId, destinoId, modo);
        if (plan == null) return false;
        copia.Items.Single(x => Igual(x.Id, itemId)).ParentId = plan.PadreId;
        foreach (var i in copia.Items)
            if (plan.Posiciones.TryGetValue(i.Id, out int posicion)) i.Posicion = posicion;
        // La opción correlativa también acompaña el arrastre en una estructura
        // importada. Sin ella se conservan los códigos oficiales/manuales.
        if (copia.NumeracionCorrelativa) MYGNumeracionCorrelativaPresupuesto.Aplicar(copia);
        else if (copia.Conexion == null && !copia.Items.Any(EsOficial)) MYGProyectoStorage.Renumerar(copia);
        copia.Items = MYGOrdenPresupuestos.FilasOrdenadas(copia).ToList();
        MYGProyectoStorage.Validar(trabajo);

        // Validar todo antes de aplicar. Mantener las instancias que usa el editor
        // y sus costos, ACU, filtros y fuentes de metrado, incluso al mover un título.
        var mapa = original.Items.ToDictionary(x => x.Id, Comparador);
        var orden = copia.Items.Select(x => mapa[x.Id]).ToList();
        foreach (var i in copia.Items)
        {
            var existente = mapa[i.Id];
            existente.ParentId = i.ParentId; existente.Posicion = i.Posicion; existente.Item = i.Item;
        }
        original.Items.Clear(); original.Items.AddRange(orden);
        original.PrefijoNumeracionCorrelativa = copia.PrefijoNumeracionCorrelativa;
        return true;
    }

    private static MYGPresupuestoDocumento Presupuesto(MYGProyectoDocumento documento, string origen, string destino)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (string.IsNullOrWhiteSpace(origen) || !Igual(origen, destino))
            throw new InvalidOperationException("El arrastre debe permanecer dentro del mismo presupuesto. Use copiar y pegar para otro presupuesto.");
        return documento.Presupuestos?.SingleOrDefault(x => x != null && Igual(x.Id, origen))
            ?? throw new InvalidOperationException("El presupuesto del arrastre ya no existe.");
    }

    private static Plan Planificar(MYGPresupuestoDocumento p, string itemId, string destinoId, MYGDestinoArrastre modo)
    {
        if (!Enum.IsDefined(modo)) throw new InvalidOperationException("Seleccione insertar antes, dentro o después.");
        var elegido = p.Items?.SingleOrDefault(x => x != null && Igual(x.Id, itemId))
            ?? throw new InvalidOperationException("La fila arrastrada ya no existe.");
        var mapa = p.Items.ToDictionary(x => x.Id, Comparador);
        var hijos = p.Items.ToLookup(x => Padre(x.ParentId) ?? "", Comparador);
        var rama = new List<ItemPresupuestoDelphin>(); var visitados = new HashSet<string>(Comparador);
        void Visitar(ItemPresupuestoDelphin nodo, int profundidad)
        {
            if (profundidad >= 64 || !visitados.Add(nodo.Id)) throw new InvalidDataException("Jerarquía circular o demasiado profunda.");
            rama.Add(nodo);
            foreach (var hijo in hijos[nodo.Id]) Visitar(hijo, profundidad + 1);
        }
        Visitar(elegido, 0);
        if (rama.Any(EsOficial)) throw new InvalidOperationException("Las ramas con filas oficiales se mantienen en Delphin. Arrastre únicamente propuestas MYG.");
        ItemPresupuestoDelphin destino = null;
        if (!string.IsNullOrWhiteSpace(destinoId))
        {
            destino = p.Items.SingleOrDefault(x => x != null && Igual(x.Id, destinoId))
                ?? throw new InvalidOperationException("La fila de destino ya no existe.");
            if (rama.Any(x => Igual(x.Id, destino.Id)))
                throw new InvalidOperationException("Una fila no puede moverse sobre sí misma ni dentro de sus descendientes.");
        }
        else if (modo != MYGDestinoArrastre.Dentro)
            throw new InvalidOperationException("Suelte sobre el presupuesto para mover al nivel principal.");
        if (modo == MYGDestinoArrastre.Dentro && destino != null && !MYGProyectoStorage.EsTitulo(destino))
            throw new InvalidOperationException("Solo un título o presupuesto puede contener otras filas.");

        string padreAnterior = Padre(elegido.ParentId);
        string padreNuevo = modo == MYGDestinoArrastre.Dentro ? destino?.Id : Padre(destino.ParentId);
        foreach (var miembro in rama)
        {
            var actual = miembro; int profundidad = 0;
            while (Padre(Igual(actual.Id, elegido.Id) ? padreNuevo : actual.ParentId) is string padre)
            {
                if (++profundidad > 64) throw new InvalidDataException("El destino supera los 64 niveles permitidos en la jerarquía.");
                if (!mapa.TryGetValue(padre, out actual)) throw new InvalidDataException("Falta un título padre de la jerarquía.");
            }
        }
        var anteriores = Hermanos(p, padreAnterior);
        var nuevos = Igual(padreAnterior, padreNuevo) ? anteriores.ToList() : Hermanos(p, padreNuevo);
        nuevos.RemoveAll(x => Igual(x.Id, elegido.Id));
        int indice = modo == MYGDestinoArrastre.Dentro ? nuevos.Count : nuevos.FindIndex(x => Igual(x.Id, destino.Id));
        if (indice < 0) throw new InvalidOperationException("El destino no pertenece al nivel indicado.");
        if (modo == MYGDestinoArrastre.Despues) indice++;
        nuevos.Insert(indice, elegido);
        if (Igual(padreAnterior, padreNuevo) && anteriores.Select(x => x.Id).SequenceEqual(nuevos.Select(x => x.Id), Comparador)) return null;

        var protegidos = RamasProtegidas(p, mapa);
        if (Igual(padreAnterior, padreNuevo))
        {
            int antes = anteriores.TakeWhile(x => !Igual(x.Id, elegido.Id)).Count(x => protegidos.Contains(x.Id));
            int despues = nuevos.Take(indice).Count(x => protegidos.Contains(x.Id));
            if (antes != despues) throw new InvalidOperationException("Una propuesta no puede atravesar una rama oficial de Delphin.");
        }
        var posiciones = new Dictionary<string, int>(Comparador);
        if (!Igual(padreAnterior, padreNuevo))
        {
            anteriores.RemoveAll(x => Igual(x.Id, elegido.Id));
            AsignarPosiciones(anteriores, protegidos, posiciones);
        }
        AsignarPosiciones(nuevos, protegidos, posiciones);
        return new Plan(padreNuevo, posiciones);
    }

    private static bool EsOficial(ItemPresupuestoDelphin i) => !string.IsNullOrWhiteSpace(i.IdInternoDelphin);
    private static List<ItemPresupuestoDelphin> Hermanos(MYGPresupuestoDocumento p, string padre) =>
        p.Items.Where(x => Igual(Padre(x.ParentId), padre)).OrderBy(x => x.Posicion).ThenBy(x => x.Item, Comparador).ToList();

    private static HashSet<string> RamasProtegidas(MYGPresupuestoDocumento p, Dictionary<string, ItemPresupuestoDelphin> mapa)
    {
        var resultado = new HashSet<string>(Comparador);
        foreach (var oficial in p.Items.Where(EsOficial))
        {
            var nodo = oficial; var visitados = new HashSet<string>(Comparador);
            while (nodo != null)
            {
                if (!visitados.Add(nodo.Id)) throw new InvalidDataException("Jerarquía circular.");
                resultado.Add(nodo.Id);
                nodo = mapa.GetValueOrDefault(Padre(nodo.ParentId) ?? "");
            }
        }
        return resultado;
    }

    private static void AsignarPosiciones(List<ItemPresupuestoDelphin> hermanos, HashSet<string> protegidos,
        Dictionary<string, int> resultado)
    {
        // Cada rama oficial mantiene su posición y delimita un segmento editable.
        // Nunca se desplaza un ancla para fabricar espacio entre filas oficiales.
        long inferior = 0; int primero = 0;
        for (int n = 0; n <= hermanos.Count; n++)
        {
            if (n < hermanos.Count && !protegidos.Contains(hermanos[n].Id)) continue;
            long superior = n == hermanos.Count ? (long)int.MaxValue + 1 : hermanos[n].Posicion;
            if (superior <= inferior || superior - inferior <= n - primero)
                throw new InvalidOperationException("No hay posiciones disponibles entre las ramas oficiales. Actualice su orden desde Delphin.");
            for (int k = primero; k < n; k++) resultado[hermanos[k].Id] = checked((int)(inferior + k - primero + 1));
            if (n < hermanos.Count) { inferior = superior; primero = n + 1; }
        }
    }
}
