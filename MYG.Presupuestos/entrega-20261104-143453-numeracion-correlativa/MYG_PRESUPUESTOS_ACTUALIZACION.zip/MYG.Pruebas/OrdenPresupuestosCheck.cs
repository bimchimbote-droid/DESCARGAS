using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class OrdenPresupuestosCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidOperationException) { return; }
        catch (InvalidDataException) { return; }
        throw new Exception("Se permitió un cambio de orden inválido.");
    }
    private static object Sql(string ruta, string sql, params object[] datos)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = sql;
        for (int n = 0; n < datos.Length; n++) q.Parameters.AddWithValue("$p" + n, datos[n] ?? DBNull.Value);
        return q.ExecuteScalar();
    }
    private static ItemPresupuestoDelphin Nodo(string nombre, int posicion, bool titulo = false, string padre = null)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = nombre, Item = "CÓDIGO-" + nombre,
            Posicion = posicion, ParentId = padre, TipoPropuesta = titulo ? "TITULO" : "PARTIDA",
            Unidad = titulo ? "" : "und", Origen = "MODELO", Estado = "PROPUESTA"
        };
    }
    private static MYGProyectoDocumento Crear(out MYGPresupuestoDocumento p,
        out ItemPresupuestoDelphin a, out ItemPresupuestoDelphin a1, out ItemPresupuestoDelphin a2,
        out ItemPresupuestoDelphin b, out ItemPresupuestoDelphin b1, out ItemPresupuestoDelphin c)
    {
        var d = MYGProyectoStorage.Nuevo("ORDEN DE FILAS");
        d.Datos = new MYGDatosProyecto { UsarUbicacion = false }; p = d.Presupuestos.Single();
        a = Nodo("TÍTULO A", 1, true); a1 = Nodo("PARTIDA A1", 1, padre: a.Id); a2 = Nodo("PARTIDA A2", 2, padre: a.Id);
        b = Nodo("TÍTULO B", 2, true); b1 = Nodo("PARTIDA B1", 1, padre: b.Id); c = Nodo("PARTIDA C", 3);
        p.Items.AddRange(new[] { a, a1, a2, b, b1, c });
        a1.Costos.PrecioDirecto = 7; a1.Costos.Cantidad = 2;
        a2.Costos.Metrados.Add(new() { Descripcion = "CONSERVADO", Elementos = 1, CantidadPorElemento = 3 });
        a2.Costos.MetradosBIM.Add(new() { ActivoId = "BIM-ORDEN", DocumentoId = "MODELO", Unidad = "und", Cantidad = 4 });
        a2.Costos.Hoja.Poner("G16", "5");
        a2.Filtros.Add(new() { Parametro = "Nivel", Regla = "Igual", Valor = "1" });
        c.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = a1.IdLocalMYG, Cantidad = 1 });
        c.Costos.Cantidad = 1;
        MYGProyectoStorage.Validar(d); return d;
    }
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var d = Crear(out var p, out var a, out var a1, out var a2, out var b, out var b1, out var c);
        var lista = p.Items; var costos = a2.Costos; var recursos = c.Costos.Analisis;
        string contenido = Firma(new { CostosA2 = a2.Costos, a2.Filtros, CostosC = c.Costos, Items = new[] { a.Item, b.Item, a1.Item, a2.Item } });
        decimal total = MYGMotorPresupuestos.Resumen(p).Total;
        var instantanea = MYGProyectoStorage.Copia(d);
        Exige(MYGOrdenPresupuestos.PuedeMover(d, b, -1) && MYGOrdenPresupuestos.Mover(d, b, -1), "No se pudo subir el título.");
        Exige(p.Items.SequenceEqual(new[] { b, b1, a, a1, a2, c }) && b.Posicion == 1 && a.Posicion == 2 &&
            b1.ParentId == b.Id && a2.ParentId == a.Id && ReferenceEquals(lista, p.Items) &&
            ReferenceEquals(costos, a2.Costos) && ReferenceEquals(recursos, c.Costos.Analisis) &&
            Firma(new { CostosA2 = a2.Costos, a2.Filtros, CostosC = c.Costos, Items = new[] { a.Item, b.Item, a1.Item, a2.Item } }) == contenido &&
            MYGMotorPresupuestos.Resumen(p).Total == total,
            "Mover el título perdió la rama, códigos, filtros, fuentes, instancias o costos.");
        Exige(MYGOrdenPresupuestos.Mover(d, a2, -1) && p.Items.SequenceEqual(new[] { b, b1, a, a2, a1, c }) &&
            a2.Posicion == 1 && a1.Posicion == 2 && a2.ParentId == a.Id &&
            instantanea.Presupuestos.Single().Items.Single(x => x.Id == a.Id).Posicion == 1,
            "Mover una partida cambió de nivel o alteró la instantánea para deshacer.");
        pasa("Subir y bajar títulos mueve la rama completa; partidas mantienen padre, código, filtros, fuentes y referencias del editor");

        string antes = Firma(d);
        Exige(!MYGOrdenPresupuestos.PuedeMover(d, b, -1) && !MYGOrdenPresupuestos.Mover(d, b, -1) &&
            !MYGOrdenPresupuestos.PuedeMover(d, a1, 1) && !MYGOrdenPresupuestos.Mover(d, a1, 1),
            "Se atravesó un extremo o se movió una partida al nivel siguiente.");
        Rechaza(() => MYGOrdenPresupuestos.Mover(d, c, 0));
        Rechaza(() => MYGOrdenPresupuestos.Mover(d, Nodo("AJENA", 1), 1));
        Rechaza(() => MYGOrdenPresupuestos.Mover(d, new object(), 1));
        Exige(Firma(d) == antes, "Un límite o selección inválida dejó cambios parciales.");
        a1.Costos.Cantidad = -1; antes = Firma(d);
        Rechaza(() => MYGOrdenPresupuestos.Mover(d, a2, 1));
        Exige(Firma(d) == antes, "Mover sobre datos inválidos mutó el proyecto antes de validar."); a1.Costos.Cantidad = 2;
        pasa("Orden respeta límites entre hermanos y rechaza selección, dirección o datos inválidos sin cambios parciales");

        b1.IdInternoDelphin = "OFICIAL-B1"; antes = Firma(d);
        Exige(!MYGOrdenPresupuestos.PuedeMover(d, b, 1) && !MYGOrdenPresupuestos.PuedeMover(d, a, -1),
            "Se habilitó mover o atravesar una rama con descendientes oficiales.");
        Rechaza(() => MYGOrdenPresupuestos.Mover(d, b, 1));
        Rechaza(() => MYGOrdenPresupuestos.Mover(d, a, -1));
        Exige(Firma(d) == antes, "Una rama oficial rechazada cambió posiciones.");
        p.Conexion = new() { FuenteId = "FUENTE", RutaSQLite = "externa.sqlite", ProyectoId = "OBRA", PresupuestoId = "PRESUPUESTO" };
        int posicionOficial = b.Posicion;
        Exige(MYGOrdenPresupuestos.Mover(d, a, 1) && b.Posicion == posicionOficial && b1.IdInternoDelphin == "OFICIAL-B1",
            "No se pudo mover propuestas conectadas o se cambió la posición oficial.");
        var segundo = new MYGPresupuestoDocumento { Nombre = "SEGUNDO", Item = "CÓDIGO PROPIO", Posicion = 2 };
        d.Presupuestos.Add(segundo); var presupuestos = d.Presupuestos; string codigo = p.Item;
        foreach (var i in p.Items) MYGMotorPresupuestos.CapturarDatosDelphin(p, i);
        MYGMotorPresupuestos.CapturarPresupuestoDelphin(p);
        Exige(MYGOrdenPresupuestos.Mover(d, p, 1) && d.Presupuestos.SequenceEqual(new[] { segundo, p }) &&
            ReferenceEquals(presupuestos, d.Presupuestos) && p.Posicion == 2 && segundo.Posicion == 1 &&
            p.Item == codigo && segundo.Item == "CÓDIGO PROPIO" && d.PresupuestoActivoId == p.Id &&
            p.Items.All(x => MYGMotorPresupuestos.ConservaDatosDelphin(p, x)) && !MYGMotorPresupuestos.ConservaPresupuestoDelphin(p),
            "Mover el presupuesto conectado perdió código, identidad o selección activa.");
        antes = Firma(d);
        Exige(!MYGOrdenPresupuestos.Mover(d, p, 1) && !MYGOrdenPresupuestos.Mover(d, segundo, -1) && Firma(d) == antes,
            "Un presupuesto atravesó un extremo o la operación cambió sus datos.");
        pasa("Ramas oficiales permanecen protegidas; propuestas conectadas y presupuestos completos se ordenan conservando identidad y códigos");

        string ruta = Path.Combine(carpeta, "Orden de presupuesto.sqlite");
        MYGProyectoStorage.Guardar(ruta, d);
        var leido = MYGBaseDatos.LeerProyecto(ruta, d.Id); var persistido = leido.Presupuestos.Single(x => x.Id == p.Id);
        Exige(leido.Presupuestos.Select(x => x.Id).SequenceEqual(d.Presupuestos.Select(x => x.Id)) &&
            persistido.Items.Select(x => x.Id).SequenceEqual(p.Items.Select(x => x.Id)) &&
            persistido.Items.Single(x => x.Id == a2.Id).Costos.MetradosBIM.Single().Cantidad == 4 &&
            persistido.Items.Single(x => x.Id == a2.Id).Costos.Hoja.Celdas["G16"].Contenido == "5" &&
            persistido.Items.Single(x => x.Id == c.Id).Costos.Analisis.Single().SubpartidaIdLocal == a1.IdLocalMYG &&
            Convert.ToInt32(Sql(ruta, "SELECT posicion_presupuesto FROM presupuesto WHERE nombre_presupuesto=$p0", p.Nombre)) == 2 &&
            Convert.ToInt32(Sql(ruta, "SELECT posicion_costo FROM costo_unitario WHERE descripcion_costo=$p0", a2.Descripcion)) == a2.Posicion &&
            MYGMotorPresupuestos.Resumen(persistido).Total == total,
            "SQLite MYG o las posiciones nativas perdieron el orden, las fuentes o el subanálisis.");
        pasa("Orden de presupuestos y ramas persiste en SQLite MYG y posiciones Delphin sin perder fuentes ni referencias a subanálisis");

        var acu = MYGProyectoStorage.Nuevo("ORDEN ACU"); acu.Datos = new MYGDatosProyecto { UsarUbicacion = false };
        var pa = acu.Presupuestos.Single(); var partida = Nodo("PARTIDA ACU", 1);
        partida.Id = "CU-ORDEN"; partida.IdLocalMYG = "LOCAL-CU-ORDEN"; partida.IdInternoDelphin = "CU-ORDEN";
        partida.Costos.Cantidad = 2; pa.Items.Add(partida);
        var mo1 = new MYGInsumo { Id = "LP-ORDEN1", Codigo = "MO-1", Descripcion = "OPERARIO", Grupo = MYGGrupoRecurso.ManoObra, Precio = 2 };
        var mo2 = new MYGInsumo { Id = "LP-ORDEN2", Codigo = "MO-2", Descripcion = "AYUDANTE", Grupo = MYGGrupoRecurso.ManoObra, Precio = 3 };
        var equipo = new MYGInsumo { Id = "LP-ORDEN3", Codigo = "EQ-1", Descripcion = "HERRAMIENTAS", Grupo = MYGGrupoRecurso.Equipo };
        pa.Costos.Insumos.AddRange(new[] { mo1, mo2, equipo });
        var r1 = new MYGRecursoACU { Id = "CO-ORDEN1", Grupo = MYGGrupoRecurso.ManoObra, InsumoId = mo1.Id };
        var r2 = new MYGRecursoACU { Id = "CO-ORDEN2", Grupo = MYGGrupoRecurso.ManoObra, InsumoId = mo2.Id };
        var r3 = new MYGRecursoACU { Id = "CO-ORDEN3", Grupo = MYGGrupoRecurso.Equipo, InsumoId = equipo.Id, Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 10 };
        partida.Costos.Analisis.AddRange(new[] { r1, r3, r2 }); MYGProyectoStorage.Validar(acu);
        MYGMotorPresupuestos.CapturarPrecioDelphin(pa, partida, 5.51m, 11.02m);
        ruta = Path.Combine(carpeta, "Orden recursos ACU.sqlite"); MYGProyectoStorage.Guardar(ruta, acu);
        Sql(ruta, "UPDATE costo_unitario SET Notas1='CONSERVAR';");
        MYGMotorPresupuestos.CapturarDatosDelphin(pa, partida); MYGMotorPresupuestos.CapturarPresupuestoDelphin(pa);
        var analisis = partida.Costos.Analisis; string datosRecurso = Firma(r1); string firmaAnterior = partida.Costos.FirmaAnalisisImportadoDelphin;
        Exige(MYGOrdenPresupuestos.PuedeMoverRecurso(pa, partida, r2, -1) &&
            MYGOrdenPresupuestos.ReordenarRecursoACU(pa, partida, r2, -1) &&
            analisis.SequenceEqual(new[] { r2, r3, r1 }) && ReferenceEquals(analisis, partida.Costos.Analisis) && Firma(r1) == datosRecurso &&
            MYGMotorPresupuestos.Analizar(pa, partida).PrecioUnitario == 5.51m && MYGMotorPresupuestos.TotalPartida(pa, partida) == 11.02m &&
            MYGMotorPresupuestos.Analizar(pa, partida).Recursos.Single(x => x.Recurso.Id == r3.Id).Total == 0.50m &&
            MYGMotorPresupuestos.ConservaAnalisisDelphin(pa, partida) && partida.Costos.FirmaAnalisisImportadoDelphin != firmaAnterior,
            "Ordenar recursos cruzó grupos, perdió instancias o cambió los importes/ajuste nativo.");
        antes = Firma(pa);
        Exige(!MYGOrdenPresupuestos.PuedeMoverRecurso(pa, partida, r2, -1) && !MYGOrdenPresupuestos.ReordenarRecursoACU(pa, partida, r2, -1) &&
            !MYGOrdenPresupuestos.PuedeMoverRecurso(pa, partida, r3, 1) && !MYGOrdenPresupuestos.ReordenarRecursoACU(pa, partida, r3, 1),
            "Se dejó mover un recurso fuera de su grupo.");
        Rechaza(() => MYGOrdenPresupuestos.ReordenarRecursoACU(pa, partida, new MYGRecursoACU(), 1));
        Exige(Firma(pa) == antes, "Ordenar un recurso inválido dejó cambios parciales.");
        MYGProyectoStorage.Guardar(ruta, acu);
        var recargado = MYGBaseDatos.LeerProyecto(ruta, acu.Id).Presupuestos.Single(); var lineaRecargada = recargado.Items.Single();
        Exige(lineaRecargada.Costos.Analisis.Select(x => x.Id).SequenceEqual(new[] { r2.Id, r3.Id, r1.Id }) &&
            MYGMotorPresupuestos.Analizar(recargado, lineaRecargada).PrecioUnitario == 5.51m &&
            MYGMotorPresupuestos.TotalPartida(recargado, lineaRecargada) == 11.02m &&
            (string)Sql(ruta, "SELECT Notas1 FROM costo_unitario WHERE id_costounitario='CU-ORDEN'") == "CONSERVAR" &&
            Convert.ToInt32(Sql(ruta, "SELECT posicion_composicion FROM composicion_costounitario WHERE id_composicion='CO-ORDEN2'")) <
                Convert.ToInt32(Sql(ruta, "SELECT posicion_composicion FROM composicion_costounitario WHERE id_composicion='CO-ORDEN1'")),
            "Guardar el orden ACU perdió precios, metadata nativa u orden de composiciones planas.");
        pasa("Orden ACU solo dentro del grupo conserva importes nativos y porcentajes de mano de obra; SQLite persiste las posiciones planas");
        OrdenTitulosACU(acu, carpeta, pasa);
    }

    private static string DatosSinOrden(MYGDatosPartida datos)
    {
        var json = JsonNode.Parse(Firma(datos)).AsObject(); json.Remove(nameof(MYGDatosPartida.OrdenGruposACU));
        return json.ToJsonString();
    }

    private static void OrdenTitulosACU(MYGProyectoDocumento fuente, string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Copia(fuente); var p = documento.Presupuestos.Single();
        var partida = p.Items.Single(); var otra = Nodo("OTRO ACU", 2); p.Items.Add(otra);
        MYGProyectoStorage.Validar(documento);
        foreach (var i in p.Items) MYGMotorPresupuestos.CapturarDatosDelphin(p, i);
        MYGMotorPresupuestos.CapturarPresupuestoDelphin(p);
        string antes = Firma(p), otraAntes = Firma(otra), datosAntes = DatosSinOrden(partida.Costos);
        var recursos = partida.Costos.Analisis; var costos = partida.Costos; var instancias = recursos.ToArray();
        var instantanea = MYGProyectoStorage.Copia(documento);
        string firmaACU = MYGMotorPresupuestos.FirmaAnalisis(p, partida), firmaImportada = partida.Costos.FirmaAnalisisImportadoDelphin;
        decimal precio = MYGMotorPresupuestos.Analizar(p, partida).PrecioUnitario, total = MYGMotorPresupuestos.TotalPartida(p, partida);
        Exige(!MYGOrdenPresupuestos.PuedeMoverGrupo(p, partida, MYGGrupoRecurso.ManoObra, -1) &&
            MYGOrdenPresupuestos.PuedeMoverGrupo(p, partida, MYGGrupoRecurso.ManoObra, 1) &&
            MYGOrdenPresupuestos.PuedeMoverGrupo(p, partida, MYGGrupoRecurso.Equipo, -1) &&
            MYGOrdenPresupuestos.PuedeMoverGrupo(p, partida, MYGGrupoRecurso.Equipo, 1) &&
            MYGOrdenPresupuestos.PuedeMoverGrupo(p, partida, MYGGrupoRecurso.Subpartidas, -1) &&
            !MYGOrdenPresupuestos.PuedeMoverGrupo(p, partida, MYGGrupoRecurso.Subpartidas, 1) && Firma(p) == antes,
            "Los títulos primero, intermedio y último no respetan los límites o la consulta modificó datos.");
        MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.ManoObra, -1);
        MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Subpartidas, 1);
        Exige(Firma(p) == antes, "Mover un título en el extremo normalizó o modificó datos.");
        var ordenConsultado = MYGOrdenPresupuestos.GruposACU(partida);
        bool protegida = false;
        try { ((System.Collections.Generic.IList<MYGGrupoRecurso>)ordenConsultado)[0] = MYGGrupoRecurso.Equipo; }
        catch (NotSupportedException) { protegida = true; }
        Exige(protegida && Firma(p) == antes, "El orden consultado permite mutar los metadatos de la partida.");
        pasa("Títulos del ACU muestran límites primero/intermedio/último y consultar su orden nunca modifica el presupuesto");

        MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Materiales, -1);
        MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Equipo, -1);
        var orden = new[] { MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo, MYGGrupoRecurso.ManoObra,
            MYGGrupoRecurso.Subcontratos, MYGGrupoRecurso.Subpartidas };
        Exige(MYGOrdenPresupuestos.GruposACU(partida).SequenceEqual(orden) && ReferenceEquals(costos, partida.Costos) &&
            ReferenceEquals(recursos, partida.Costos.Analisis) && recursos.SequenceEqual(instancias) &&
            DatosSinOrden(partida.Costos) == datosAntes && Firma(otra) == otraAntes &&
            MYGOrdenPresupuestos.GruposACU(instantanea.Presupuestos.Single().Items.Single(x => x.Id == partida.Id))
                .SequenceEqual(Enum.GetValues<MYGGrupoRecurso>()) &&
            MYGMotorPresupuestos.FirmaAnalisis(p, partida) == firmaACU && partida.Costos.FirmaAnalisisImportadoDelphin == firmaImportada &&
            MYGMotorPresupuestos.ConservaAnalisisDelphin(p, partida) && MYGMotorPresupuestos.ConservaDatosDelphin(p, partida) &&
            MYGMotorPresupuestos.ConservaPresupuestoDelphin(p) && MYGMotorPresupuestos.Analizar(p, partida).PrecioUnitario == precio &&
            MYGMotorPresupuestos.TotalPartida(p, partida) == total,
            "Mover títulos alteró el análisis, firmas, precios, objetos, otro ACU o su instantánea de historial.");
        var bloques = MYGOrdenPresupuestos.GruposACU(partida).SelectMany(grupo => recursos.Where(x => x.Grupo == grupo)).ToArray();
        Exige(bloques.Select(x => x.Grupo).SequenceEqual(new[] { MYGGrupoRecurso.Equipo, MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.ManoObra }) &&
            bloques.Where(x => x.Grupo == MYGGrupoRecurso.ManoObra).SequenceEqual(instancias.Where(x => x.Grupo == MYGGrupoRecurso.ManoObra)),
            "El orden visual no mueve bloques completos o cambia el orden de los insumos dentro del título.");
        MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Materiales, 1);
        MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Materiales, -1);
        Exige(MYGOrdenPresupuestos.GruposACU(partida).SequenceEqual(orden), "Repetir subir/bajar no restablece el orden visual del ACU.");
        pasa("Mover títulos reorganiza bloques con sus insumos sin tocar recursos, precios nativos, firmas, otros ACUs ni historial");

        var legado = JsonSerializer.Deserialize<MYGDatosPartida>("{}", MYGProyectoStorage.Opciones);
        Exige(legado.OrdenGruposACU.SequenceEqual(Enum.GetValues<MYGGrupoRecurso>()), "El JSON anterior sin propiedad de orden perdió sus títulos.");
        foreach (var valor in new System.Collections.Generic.List<MYGGrupoRecurso>[] { null, new() })
        {
            otra.Costos.OrdenGruposACU = valor; string original = Firma(otra);
            Exige(MYGOrdenPresupuestos.GruposACU(otra).SequenceEqual(Enum.GetValues<MYGGrupoRecurso>()) &&
                MYGOrdenPresupuestos.PuedeMoverGrupo(p, otra, MYGGrupoRecurso.Materiales, -1) && Firma(otra) == original,
                "Consultar un orden nulo o vacío anterior normalizó datos de la UI.");
            MYGOrdenPresupuestos.ReordenarGrupoACU(p, otra, MYGGrupoRecurso.Materiales, -1);
            Exige(otra.Costos.OrdenGruposACU[0] == MYGGrupoRecurso.Materiales && MYGMotorPresupuestos.TieneDatosPropios(otra.Costos),
                "Un ACU vacío con orden personalizado no se reconoce como datos propios.");
        }
        otra.Costos.OrdenGruposACU = new(Enum.GetValues<MYGGrupoRecurso>());
        Exige(!MYGMotorPresupuestos.TieneDatosPropios(otra.Costos), "Un orden predeterminado convirtió un ACU vacío en datos propios.");
        pasa("JSON anterior y órdenes nulos/vacíos usan todos los títulos; un orden personalizado se conserva incluso en ACUs vacíos");

        antes = Firma(p);
        Rechaza(() => MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Materiales, 0));
        Rechaza(() => MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, (MYGGrupoRecurso)99, 1));
        Rechaza(() => MYGOrdenPresupuestos.ReordenarGrupoACU(p, Nodo("AJENA", 1), MYGGrupoRecurso.Materiales, 1));
        var titulo = Nodo("TÍTULO ITEMIZADO", 3, true); p.Items.Add(titulo); string conTitulo = Firma(p);
        Exige(!MYGOrdenPresupuestos.PuedeMoverGrupo(p, titulo, MYGGrupoRecurso.Materiales, 1), "Un título itemizado se trató como un ACU.");
        Rechaza(() => MYGOrdenPresupuestos.ReordenarGrupoACU(p, titulo, MYGGrupoRecurso.Materiales, 1));
        Exige(Firma(p) == conTitulo, "Una selección de título inválida dejó cambios parciales."); p.Items.Remove(titulo);
        Exige(Firma(p) == antes, "Una dirección, tipo de grupo o partida inválida cambió el presupuesto.");
        foreach (var invalido in new[]
        {
            new[] { MYGGrupoRecurso.Materiales },
            new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos, MYGGrupoRecurso.Subpartidas },
            new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos, (MYGGrupoRecurso)99 }
        })
        {
            partida.Costos.OrdenGruposACU = invalido.ToList(); string rechazado = Firma(p);
            Exige(!MYGOrdenPresupuestos.PuedeMoverGrupo(p, partida, MYGGrupoRecurso.Materiales, 1), "Se habilitó mover con una permutación inválida.");
            Rechaza(() => MYGOrdenPresupuestos.GruposACU(partida));
            Rechaza(() => MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Materiales, 1));
            Exige(Firma(p) == rechazado, "Un orden incompleto, repetido o desconocido dejó modificaciones parciales.");
        }
        partida.Costos.OrdenGruposACU = orden.ToList();
        otra.Costos.Cantidad = -1; antes = Firma(p);
        Rechaza(() => MYGOrdenPresupuestos.ReordenarGrupoACU(p, partida, MYGGrupoRecurso.Equipo, 1));
        Exige(Firma(p) == antes, "La validación de datos inválidos normalizó la obra antes de rechazar el movimiento."); otra.Costos.Cantidad = 0;
        pasa("Orden de títulos rechaza datos inválidos, títulos itemizados, grupos desconocidos y permutaciones incompletas o repetidas sin cambios parciales");

        string ruta = Path.Combine(carpeta, "Orden títulos ACU.sqlite");
        MYGProyectoStorage.Guardar(ruta, documento);
        var reabierto = MYGProyectoStorage.Leer(ruta).Presupuestos.Single(); var raiz = reabierto.Items.Single(x => x.Id == partida.Id);
        Exige(MYGOrdenPresupuestos.GruposACU(raiz).SequenceEqual(orden) && DatosSinOrden(raiz.Costos) == DatosSinOrden(partida.Costos) &&
            MYGMotorPresupuestos.Analizar(reabierto, raiz).PrecioUnitario == precio && MYGMotorPresupuestos.TotalPartida(reabierto, raiz) == total &&
            MYGProyectoStorage.Copia(partida).Costos.OrdenGruposACU.SequenceEqual(orden),
            "El guardado SQLite o la copia JSON perdió el orden o modificó los datos numéricos.");
        var entrada = MYGCatalogos.GuardarPartida(ruta, p, partida, "P-ORDEN-TITULOS", partida.Descripcion, partida.Unidad);
        var plantilla = MYGCatalogos.LeerPartida(ruta, entrada.Id);
        Exige(MYGOrdenPresupuestos.GruposACU(plantilla.Partidas.Single(x => x.IdLocalMYG == plantilla.RaizLocalId)).SequenceEqual(orden),
            "Guardar el ACU como plantilla descartó el orden de los títulos.");
        var destino = MYGProyectoStorage.Nuevo("OTRA OBRA CON ORDEN").Presupuestos.Single();
        var insertada = MYGCatalogos.InsertarPartida(destino, ruta, entrada, null);
        Exige(MYGOrdenPresupuestos.GruposACU(insertada).SequenceEqual(orden) && MYGMotorPresupuestos.Analizar(destino, insertada).PrecioUnitario == precio,
            "Reutilizar el catálogo perdió el orden visual o el precio importado del ACU.");
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(destino, insertada) && insertada.Costos.ParcialImportadoDelphin == null &&
            insertada.Costos.CantidadImportadaDelphin == null && insertada.Costos.Cantidad == 0,
            "La firma del precio reutilizado no corresponde a sus identidades nuevas o conserva el parcial de la obra.");
        var distintaPrecision = MYGProyectoStorage.Nuevo("OTRA PRECISIÓN").Presupuestos.Single();
        distintaPrecision.Costos.DecimalesPrecio = 3;
        var otraPrecision = MYGCatalogos.InsertarPartida(distintaPrecision, ruta, entrada, null);
        Exige(!MYGMotorPresupuestos.ConservaAnalisisDelphin(distintaPrecision, otraPrecision) &&
            MYGMotorPresupuestos.Analizar(distintaPrecision, otraPrecision).PrecioUnitario == 5.50m,
            "La reutilización impuso un precio nativo correspondiente a otra precisión del ACU.");
        destino.Costos.Insumos[0].Precio += 1m;
        Exige(!MYGMotorPresupuestos.ConservaAnalisisDelphin(destino, insertada) &&
            MYGMotorPresupuestos.Analizar(destino, insertada).PrecioUnitario == 6.60m,
            "Editar un insumo reutilizado no invalidó el precio histórico ni recalculó su costo.");
        // Una entrada editada fuera de la API mantiene una firma antigua: no
        // debe revalidarse por el mero hecho de insertarla con identidades nuevas.
        plantilla.Insumos[0].Precio += 1m;
        Sql(ruta, "UPDATE catalogo_partida SET json_plantilla=$p1 WHERE id=$p0", entrada.Id, Firma(plantilla));
        var firmaCaduca = MYGProyectoStorage.Nuevo("PLANTILLA EDITADA").Presupuestos.Single();
        var caduca = MYGCatalogos.InsertarPartida(firmaCaduca, ruta, entrada, null);
        Exige(!MYGMotorPresupuestos.ConservaAnalisisDelphin(firmaCaduca, caduca) &&
            MYGMotorPresupuestos.Analizar(firmaCaduca, caduca).PrecioUnitario == 6.60m,
            "Insertar una plantilla con firma caduca reactivó su precio histórico.");
        pasa("Orden de títulos persiste en SQLite, copias JSON y plantillas reutilizables del catálogo sin migraciones ni cambios de costo");
        NumeracionIntegracionesCheck.Ejecutar(pasa);
    }
}
