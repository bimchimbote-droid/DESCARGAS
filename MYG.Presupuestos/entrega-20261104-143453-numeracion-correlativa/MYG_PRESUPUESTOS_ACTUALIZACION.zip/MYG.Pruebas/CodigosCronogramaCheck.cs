using System;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class CodigosCronogramaCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("CÓDIGOS CORRELATIVOS");
        var p = doc.Presupuestos.Single();
        var titulo = MYGEstructuraPresupuestos.InsertarNodo(p, true);
        var a = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        var b = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        doc.Cronograma = MYGMotorCronograma.CrearDesdePresupuestos(doc);
        var tarea = doc.Cronograma.Tareas.Single(t => t.PartidaId == b.Id);
        tarea.InicioManual = new DateTime(2026, 11, 4);
        tarea.Notas = "Programación privada conservada";
        tarea.DuracionDias = 7;
        tarea.Avance = 0.25m;
        tarea.Predecesoras.Add(new() { PredecesoraId = doc.Cronograma.Tareas.Single(t => t.PartidaId == a.Id).Id });
        string FirmaSinCodigo() => JsonSerializer.Serialize(doc.Cronograma.Tareas.Select(t => new
        { t.Id, t.PadreId, t.PresupuestoId, t.PartidaId, t.Nombre, t.InicioManual, t.DuracionDias, t.Avance, t.Notas, t.Predecesoras }));
        string antes = FirmaSinCodigo();
        var nueva = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id, a.Id);
        MYGCodigosCronogramaPresupuesto.Actualizar(doc);
        if (tarea.Codigo != b.Item || tarea.Codigo == nueva.Item || FirmaSinCodigo() != antes)
            throw new Exception("Sincronizar numeración del cronograma alteró sus fechas, vínculos o códigos.");
        var captura = MYGEntradaHistorialProyecto.CapturarEstructura(doc, p);
        MYGEstructuraPresupuestos.EliminarNodo(p, nueva);
        MYGCodigosCronogramaPresupuesto.Actualizar(doc);
        if (tarea.Codigo != b.Item) throw new Exception("Eliminar dejó el código anterior en el cronograma.");
        captura.Aplicar(doc);
        MYGCodigosCronogramaPresupuesto.Actualizar(doc);
        if (tarea.Codigo != b.Item || FirmaSinCodigo() != antes)
            throw new Exception("Deshacer numeración modificó la programación del cronograma.");
        pasa("Numeración del cronograma sigue inserción, eliminación y deshacer por identidad sin cambiar fechas, avances ni vínculos");
    }
}
