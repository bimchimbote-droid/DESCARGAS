using System;
using System.IO;
using System.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class NumeracionCorrelativaCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new InvalidOperationException(detalle); }

    private static ItemPresupuestoDelphin Fila(string id, string item, string padre, int posicion, bool titulo = false) => new()
    {
        Id = id, IdLocalMYG = id, IdInternoDelphin = id, Item = item, ParentId = padre, Posicion = posicion,
        TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Descripcion = id, Unidad = titulo ? "" : "und", Estado = "OFICIAL", Origen = "DELPHIN"
    };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var documento = new MYGProyectoDocumento { Id = "PR-NC", Nombre = "NUMERACIÓN CORRELATIVA" };
        var p = new MYGPresupuestoDocumento { Id = "PP-NC", Nombre = "PRESUPUESTO", Item = "1" };
        documento.Presupuestos.Add(p); documento.PresupuestoActivoId = p.Id;
        var raiz = Fila("TI-NC-1", "01.01", null, 1, true);
        var titulo = Fila("TI-NC-2", "01.01.01", raiz.Id, 1, true);
        p.Items.AddRange(new[] { raiz, titulo });
        for (int n = 1; n <= 9; n++)
        {
            var fila = Fila("CU-NC-" + n, "01.01.01." + n.ToString("D2"), titulo.Id, n);
            fila.Costos.Cantidad = 3; fila.Costos.PrecioDirecto = 2;
            p.Items.Add(fila);
        }
        MYGProyectoStorage.Validar(documento);
        var originales = p.Items.ToArray();
        var costos = originales.Select(x => x.Costos).ToArray();
        decimal total = MYGMotorPresupuestos.Resumen(p).CostoDirecto;
        var ultimo = p.Items.Last();
        var nueva = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id, ultimo.Id);
        Exige(nueva.Item == "01.01.01.09" && ultimo.Item == "01.01.01.10" &&
            p.NumeracionCorrelativa && p.PrefijoNumeracionCorrelativa == "01." && p.Item == "1",
            "Insertar antes del noveno ítem no continuó 09→10 conservando el prefijo nativo.");
        Exige(originales.All(x => p.Items.Contains(x) && x.Id == x.IdLocalMYG && x.Id == x.IdInternoDelphin) &&
            originales.Select(x => x.Costos).SequenceEqual(costos) && MYGMotorPresupuestos.Resumen(p).CostoDirecto == total,
            "Renumerar modificó identidades, objetos ACU o importes existentes.");
        Exige(p.Item + "." + nueva.Item == "1.01.01.01.09", "El código almacenado no coincide con la numeración visible.");
        var nuevoTitulo = MYGEstructuraPresupuestos.InsertarNodo(p, true, titulo.Id, nueva.Id);
        Exige(nuevoTitulo.Item == "01.01.01.09" && nueva.Item == "01.01.01.10" && ultimo.Item == "01.01.01.11",
            "Títulos y partidas no compartieron la secuencia del mismo nivel.");
        MYGEstructuraPresupuestos.EliminarNodo(p, nuevoTitulo);
        Exige(nueva.Item == "01.01.01.09" && ultimo.Item == "01.01.01.10", "Eliminar no cerró el hueco de numeración.");
        string antes = MYGProyectoStorage.Firma(documento);
        bool rechazado = false;
        try { MYGEstructuraPresupuestos.EliminarNodo(p, ultimo); }
        catch (InvalidOperationException) { rechazado = true; }
        Exige(rechazado && MYGProyectoStorage.Firma(documento) == antes, "La numeración debilitó la protección contra eliminar filas oficiales.");
        pasa("Títulos y partidas siguen ubicación 09→10 y cierran huecos conservando identidades oficiales, ACU e importes");

        string ruta = Path.Combine(carpeta, "Numeración correlativa nativa.sqlite");
        MYGProyectoStorage.Guardar(ruta, documento);
        var leido = MYGBaseDatos.LeerProyecto(ruta, documento.Id).Presupuestos.Single();
        Exige(leido.NumeracionCorrelativa && leido.PrefijoNumeracionCorrelativa == "01." &&
            leido.Items.Single(x => x.Id == ultimo.Id).Item == "01.01.01.10" &&
            leido.Items.Single(x => x.IdLocalMYG == nueva.IdLocalMYG).Item == "01.01.01.09" &&
            MYGMotorPresupuestos.Resumen(leido).CostoDirecto == total,
            "Guardar/reabrir perdió el marcador, prefijo, numeración o importes.");
        using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly }.ToString()))
        {
            conexion.Open(); using var comando = conexion.CreateCommand();
            comando.CommandText = "SELECT numeracion_costo FROM costo_unitario WHERE id_costounitario=$id";
            comando.Parameters.AddWithValue("$id", ultimo.IdInternoDelphin);
            Exige((string)comando.ExecuteScalar() == "01.01.01.10", "La columna nativa conservó un código anterior o P-xxx.");
        }
        MYGEstructuraPresupuestos.EliminarNodo(leido, leido.Items.Single(x => x.IdLocalMYG == nueva.IdLocalMYG));
        Exige(leido.Items.Single(x => x.Id == ultimo.Id).Item == "01.01.01.09", "Reabrir y eliminar cambió el prefijo persistido.");
        pasa("SQLite conserva numeración en documento y columnas nativas; reabrir mantiene prefijo al eliminar una propuesta");

        var recuperado = new MYGPresupuestoDocumento { Nombre = "RAÍZ RECUPERADA" };
        var sinNumero = Fila("TI-REC", null, null, 1, true);
        recuperado.Items.AddRange(new[] { sinNumero, Fila("CU-REC1", "04.03.01", sinNumero.Id, 1), Fila("CU-REC2", "04.03.02", sinNumero.Id, 2) });
        MYGNumeracionCorrelativaPresupuesto.Aplicar(recuperado);
        Exige(recuperado.PrefijoNumeracionCorrelativa == "04." && sinNumero.Item == "04.01" &&
            recuperado.Items[1].Item == "04.01.01", "La raíz recuperada no infirió su prefijo por consenso de hijos directos.");
        var ambiguo = new MYGPresupuestoDocumento { Nombre = "PREFIJO AMBIGUO" };
        var root = Fila("TI-AMB", null, null, 1, true);
        ambiguo.Items.AddRange(new[] { root, Fila("CU-AMB1", "04.03.01", root.Id, 1), Fila("CU-AMB2", "05.03.02", root.Id, 2) });
        MYGNumeracionCorrelativaPresupuesto.Aplicar(ambiguo);
        Exige(ambiguo.PrefijoNumeracionCorrelativa == "" && root.Item == "01", "El prefijo ambiguo se dedujo de un ID o de un único hijo arbitrario.");
        var vacio = new MYGPresupuestoDocumento { Nombre = "VACÍO" };
        var primera = MYGEstructuraPresupuestos.InsertarNodo(vacio, false);
        Exige(primera.Item == "01" && vacio.PrefijoNumeracionCorrelativa == "", "Un presupuesto vacío conservó un código P-xxx.");
        pasa("Prefijos de raíces recuperadas requieren consenso; entradas ambiguas o vacías reciben numeración segura");

        var cien = new MYGPresupuestoDocumento { Nombre = "CIEN Y MÁS" };
        for (int n = 1; n <= 100; n++) cien.Items.Add(Fila("CIEN-" + n, n.ToString("D2"), null, n));
        var cientoUno = MYGEstructuraPresupuestos.InsertarNodo(cien, false);
        var cientoDos = MYGEstructuraPresupuestos.InsertarNodo(cien, false);
        Exige(cien.Items[0].Item == "01" && cien.Items[98].Item == "99" && cien.Items[99].Item == "100" &&
            cientoUno.Item == "101" && cientoDos.Item == "102", "Pasar de 99 a 100 amplió los ceros de toda la numeración.");
        var tresDigitos = new MYGPresupuestoDocumento { Nombre = "FORMATO EXPLÍCITO" };
        tresDigitos.Items.Add(Fila("TRES-1", "001", null, 1));
        Exige(MYGEstructuraPresupuestos.InsertarNodo(tresDigitos, false).Item == "002" && tresDigitos.Items[0].Item == "001",
            "La numeración perdió un ancho de tres dígitos definido desde la primera fila.");
        pasa("Pasar 99→100→101 conserva códigos 01 y admite ancho explícito de tres dígitos sin expansión retroactiva");
    }
}
