using MYG_2027;

internal static class HistorialEstructuraCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }

    internal static void Ejecutar(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Historial de estructura", "Presupuesto");
        var p = documento.Presupuestos.Single();
        var titulo = MYGEstructuraPresupuestos.InsertarNodo(p, true);
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        partida.Descripcion = "Nombre anterior";
        partida.Costos.Cantidad = 7;
        partida.Costos.Hoja.Poner("G16", "11.5");
        string original = MYGProyectoStorage.Firma(documento);
        var insertar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        var nueva = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        var editar = MYGEntradaHistorialProyecto.Capturar(documento);
        p.Items.Single(i => i.Id == partida.Id).Descripcion = "Nombre editado";
        var rehacerEdicion = editar.CapturarInversa(documento);
        documento = editar.Aplicar(documento); // Sustituye todas las referencias.
        p = documento.Presupuestos.Single();
        var filaVigente = p.Items.Single(i => i.Id == partida.Id);
        var rehacerInsercion = insertar.CapturarInversa(documento);
        documento = insertar.Aplicar(documento);
        Exige(MYGProyectoStorage.Firma(documento) == original &&
            ReferenceEquals(filaVigente, p.Items.Single(i => i.Id == partida.Id)),
            "Deshacer estructura tras una instantánea reintrodujo objetos o valores antiguos.");
        rehacerInsercion.Aplicar(documento);
        Exige(p.Items.Any(i => i.Id == nueva.Id) && p.Items.Single(i => i.Id == partida.Id).Descripcion == "Nombre anterior",
            "Rehacer inserción perdió la identidad de la fila o alteró una descripción.");
        documento = rehacerEdicion.Aplicar(documento);
        Exige(documento.Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Descripcion == "Nombre editado",
            "Rehacer edición tras rehacer estructura perdió el orden del historial.");
        pasa("Deshacer y rehacer estructura intercalados con instantáneas completas conservan identidad, orden, numeración y ediciones");

        p = documento.Presupuestos.Single();
        documento.ActivosRevit = new()
        {
            Activos = new() { new() { Id = "ACTIVO", Nombre = "Modelo", RutaLocal = "C:/Modelo.rvt" } },
            Asignaciones = new() { new() { PresupuestoId = p.Id, PartidaId = partida.Id, ActivoId = "ACTIVO", IncluirEnTotal = false } }
        };
        var eliminar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        MYGEstructuraPresupuestos.EliminarNodo(p, p.Items.Single(i => i.Id == titulo.Id));
        MYGActivosRevit.LimpiarAsignacionesHuerfanas(documento);
        Exige(p.Items.Count == 0 && documento.ActivosRevit.Asignaciones.Count == 0,
            "La eliminación no quitó la rama completa o dejó asignaciones huérfanas.");
        var candidato = eliminar.CrearCandidato(documento);
        bool bloqueado = false;
        try { MYGCambiosModulosNube.ExigirPermitidos(documento, candidato, new MYGPermisosModulos { MetradosRevit = false }); }
        catch (InvalidOperationException) { bloqueado = true; }
        Exige(bloqueado, "El candidato de historial omitió la comprobación de permisos BIM.");
        candidato.Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Costos.Cantidad = 999;
        candidato.ActivosRevit.Asignaciones.Single().IncluirEnTotal = true;
        var rehacerEliminacion = eliminar.CapturarInversa(documento);
        eliminar.Aplicar(documento);
        Exige(p.Items.Count == 3 && p.Items.Single(i => i.Id == partida.Id).Costos.Cantidad == 7 &&
            !documento.ActivosRevit.Asignaciones.Single().IncluirEnTotal,
            "Comprobar el candidato mutó la captura, o deshacer no restauró la rama y sus asignaciones.");
        rehacerEliminacion.Aplicar(documento);
        Exige(p.Items.Count == 0 && documento.ActivosRevit.Asignaciones.Count == 0,
            "Rehacer eliminación dejó filas o asignaciones restauradas.");
        eliminar.Aplicar(documento);
        pasa("Historial de eliminación restaura ramas y asignaciones Revit; sus candidatos están aislados y conservan la guardia de permisos");

        var ajeno = new MYGPresupuestoDocumento { Nombre = "Ajeno", Item = "02" };
        documento.Presupuestos.Add(ajeno);
        var pesada = MYGEstructuraPresupuestos.InsertarNodo(ajeno, false);
        pesada.Costos.EspecificacionRtf = new string('X', 4 * 1024 * 1024);
        _ = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        long inicio = GC.GetAllocatedBytesForCurrentThread();
        for (int n = 0; n < 100; n++)
            _ = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        long asignados = GC.GetAllocatedBytesForCurrentThread() - inicio;
        Exige(asignados < 1024 * 1024, "Capturar estructura volvió a copiar cargas de ACU o especificaciones de otras obras.");
        foreach (var fila in p.Items.Take(2)) // Título y partida.
        {
            string nombre = fila.Descripcion;
            fila.EstadoRevit = "OK"; fila.MensajeRevit = "Estado previo";
            var texto = MYGEntradaHistorialProyecto.CapturarDescripcion(documento, p, fila);
            MYGEdicionPartida.CambiarDescripcion(p, fila, "Nuevo nombre");
            fila.EstadoRevit = fila.MensajeRevit = null;
            var rehacerTexto = texto.CapturarInversa(documento);
            var hojaConservada = fila.Costos.Hoja;
            texto.Aplicar(documento);
            Exige(fila.Descripcion == nombre && fila.EstadoRevit == "OK" && fila.MensajeRevit == "Estado previo" &&
                ReferenceEquals(hojaConservada, fila.Costos.Hoja), "Deshacer nombre perdió texto, estado o referencias del metrado.");
            rehacerTexto.Aplicar(documento);
            Exige(fila.Descripcion == "Nuevo nombre" && fila.EstadoRevit == null && fila.MensajeRevit == null,
                "Rehacer nombre no restauró la edición.");
            var candidatoTexto = texto.CrearCandidato(documento);
            Exige(candidatoTexto.Presupuestos.Single(x => x.Id == p.Id).Items.Single(x => x.Id == fila.Id).Descripcion == nombre &&
                fila.Descripcion == "Nuevo nombre", "El candidato de texto cambió el original.");
        }
        inicio = GC.GetAllocatedBytesForCurrentThread();
        for (int n = 0; n < 100; n++)
            _ = MYGEntradaHistorialProyecto.CapturarDescripcion(documento, p, p.Items.First());
        Exige(GC.GetAllocatedBytesForCurrentThread() - inicio < 1024 * 1024,
            "Capturar el nombre de una fila copió cargas ajenas.");
        pasa("Historial de nombre para títulos y partidas conserva estado BIM, referencias y candidato aislado sin copiar cargas del proyecto");
        pesada.Costos.Hoja.Poner("B3", "13");
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        var destino = p.Items.First(i => !MYGProyectoStorage.EsTitulo(i));
        string referencia = MYGReferenciasMetrado.CrearReferencia(destino.Costos.Hoja, ajeno, pesada, "B3");
        destino.Costos.Hoja.Poner("B3", "=" + referencia);
        var antesDeAgregar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        MYGEstructuraPresupuestos.InsertarNodo(p, false);
        antesDeAgregar.Aplicar(documento);
        MYGEstructuraPresupuestos.InsertarNodo(p, false);
        Exige(new MYGHojaCalculo(destino.Costos.Hoja).Numero("B3") == 13,
            "Deshacer estructura y volver a insertar perdió la referencia al metrado de otro presupuesto.");
        pasa("Deshacer estructura y volver a insertar mantiene el contexto de metrados entre presupuestos");
        var captura = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        documento.Presupuestos.Remove(p);
        string sinPresupuesto = MYGProyectoStorage.Firma(documento);
        bool rechazado = false;
        try { captura.Aplicar(documento); }
        catch (InvalidOperationException) { rechazado = true; }
        Exige(rechazado && MYGProyectoStorage.Firma(documento) == sinPresupuesto,
            "El historial de un presupuesto ausente dejó cambios parciales.");
        pasa("Cien capturas estructurales con 4 MiB ajenos usan menos de 1 MiB y rechazan presupuestos ausentes sin modificar datos");
        NumeracionCorrelativa(pasa);
        CronogramaPrimeraActivacion(pasa);
    }
    private static void NumeracionCorrelativa(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Historial numerado", "Presupuesto importado");
        var p = documento.Presupuestos.Single();
        p.Item = "1";
        var titulo = new ItemPresupuestoDelphin
        {
            Id = "TITULO", IdLocalMYG = "TITULO", IdInternoDelphin = "TITULO-NATIVO", TipoPropuesta = "TITULO",
            Descripcion = "Instalaciones", Item = "1.01.01.02", Posicion = 1
        };
        var oficial = new ItemPresupuestoDelphin
        {
            Id = "OFICIAL", IdLocalMYG = "OFICIAL", IdInternoDelphin = "PARTIDA-NATIVA", TipoPropuesta = "PARTIDA",
            Descripcion = "Agua", Item = "1.01.01.02.01", ParentId = titulo.Id, Posicion = 1
        };
        var propuesta = new ItemPresupuestoDelphin
        {
            Id = "PROPUESTA", IdLocalMYG = "PROPUESTA", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA",
            Descripcion = "Partida nueva", Item = "P-001", ParentId = titulo.Id, Posicion = 2
        };
        p.Items.AddRange(new[] { titulo, oficial, propuesta });
        var antesDeMigrar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        MYGNumeracionCorrelativaPresupuesto.Aplicar(p);
        Exige(p.NumeracionCorrelativa && !propuesta.Item.Contains("P-", StringComparison.Ordinal) &&
            oficial.Item == titulo.Item + ".01" && propuesta.Item == titulo.Item + ".02",
            "La migración no dejó la rama mixta en orden correlativo.");
        string prefijo = p.PrefijoNumeracionCorrelativa;
        var despuesDeMigrar = antesDeMigrar.CapturarInversa(documento);
        antesDeMigrar.Aplicar(documento);
        Exige(!p.NumeracionCorrelativa && p.PrefijoNumeracionCorrelativa == null &&
            propuesta.Item == "P-001" && oficial.Item == "1.01.01.02.01",
            "Deshacer antes de activar la numeración perdió los códigos o el marcador original.");
        despuesDeMigrar.Aplicar(documento);
        Exige(p.NumeracionCorrelativa && p.PrefijoNumeracionCorrelativa == prefijo && propuesta.Item == titulo.Item + ".02",
            "Rehacer la activación perdió el prefijo o la numeración correlativa.");

        string migrado = MYGProyectoStorage.Firma(documento);
        var insertar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        var nueva = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id, oficial.Id);
        Exige(nueva.Item == titulo.Item + ".01" && oficial.Item == titulo.Item + ".02" &&
            propuesta.Item == titulo.Item + ".03", "Insertar sobre una partida no actualizó los correlativos de toda la rama.");
        var editar = MYGEntradaHistorialProyecto.Capturar(documento);
        oficial.Descripcion = "Nombre editado después";
        documento = editar.Aplicar(documento); // Fuerza nuevas referencias a objetos.
        p = documento.Presupuestos.Single();
        var rehacerInsercion = insertar.CapturarInversa(documento);
        insertar.Aplicar(documento);
        Exige(MYGProyectoStorage.Firma(documento) == migrado && p.NumeracionCorrelativa &&
            p.PrefijoNumeracionCorrelativa == prefijo,
            "Deshacer inserción tras una instantánea perdió el prefijo o reintrodujo códigos P-.");
        rehacerInsercion.Aplicar(documento);
        nueva = p.Items.Single(i => i.Id == nueva.Id);
        var eliminar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        MYGEstructuraPresupuestos.EliminarNodo(p, nueva);
        Exige(p.Items.Single(i => i.Id == oficial.Id).Item == p.Items.Single(i => i.Id == titulo.Id).Item + ".01",
            "Eliminar una propuesta no cerró el hueco de numeración.");
        var rehacerEliminacion = eliminar.CapturarInversa(documento);
        eliminar.Aplicar(documento);
        Exige(p.NumeracionCorrelativa && p.PrefijoNumeracionCorrelativa == prefijo &&
            p.Items.Single(i => i.Id == nueva.Id).Item == p.Items.Single(i => i.Id == titulo.Id).Item + ".01" &&
            p.Items.Single(i => i.Id == oficial.Id).Item == p.Items.Single(i => i.Id == titulo.Id).Item + ".02",
            "Deshacer eliminación no recuperó los correlativos y el marcador de la rama.");
        rehacerEliminacion.Aplicar(documento);
        Exige(p.NumeracionCorrelativa && p.PrefijoNumeracionCorrelativa == prefijo &&
            !p.Items.Any(i => i.Id == nueva.Id || i.Item.Contains("P-", StringComparison.Ordinal)),
            "Rehacer eliminación perdió el marcador o dejó códigos provisionales.");
        pasa("Historial mixto conserva marcador, prefijo y correlativos al activar, insertar, eliminar, deshacer y rehacer");
    }

    private static void CronogramaPrimeraActivacion(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Primera activación", "Presupuesto original");
        var p = documento.Presupuestos.Single();
        p.Item = "05";
        var primera = new ItemPresupuestoDelphin
        {
            Id = "PARTIDA-A", IdLocalMYG = "PARTIDA-A", IdInternoDelphin = "NATIVA-A", TipoPropuesta = "PARTIDA",
            Descripcion = "Primera", Item = "05.09", Posicion = 1
        };
        var segunda = new ItemPresupuestoDelphin
        {
            Id = "PARTIDA-B", IdLocalMYG = "PARTIDA-B", IdInternoDelphin = "NATIVA-B", TipoPropuesta = "PARTIDA",
            Descripcion = "Segunda", Item = "05.10", Posicion = 2
        };
        p.Items.AddRange(new[] { primera, segunda });
        documento.Cronograma = new()
        {
            FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 8),
            Tareas = new()
            {
                new() { Id = "TAREA-A", PresupuestoId = p.Id, PartidaId = primera.Id, Codigo = "CODIGO-MANUAL-A",
                    Nombre = "Tarea planificada", Modo = MYGModoTarea.Manual, InicioManual = new DateTime(2026, 1, 6),
                    DuracionDias = 7, Avance = 37.5m },
                new() { Id = "TAREA-B", PresupuestoId = p.Id, PartidaId = segunda.Id, Codigo = "CODIGO-MANUAL-B",
                    Nombre = "Sucesora", DuracionDias = 3,
                    Predecesoras = new() { new() { PredecesoraId = "TAREA-A", Tipo = MYGTipoVinculo.FC, DesfaseDias = 2 } } },
                new() { Id = "OTRA-TAREA", PresupuestoId = "OTRO-PRESUPUESTO", Codigo = "CODIGO-AJENO", Nombre = "Ajena" }
            }
        };
        var fechas = documento.Cronograma.Tareas[0].InicioManual;
        var vinculos = documento.Cronograma.Tareas[1].Predecesoras;
        string original = MYGProyectoStorage.Firma(documento);
        var insertar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        var nueva = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        MYGCodigosCronogramaPresupuesto.Actualizar(documento);
        Exige(p.NumeracionCorrelativa && documento.Cronograma.Tareas[0].Codigo == primera.Item &&
            documento.Cronograma.Tareas[1].Codigo == segunda.Item && primera.Item == "05.01" && segunda.Item == "05.02",
            "La primera inserción no activó los correlativos de filas y tareas.");
        string insertado = MYGProyectoStorage.Firma(documento);
        var rehacerInsercion = insertar.CapturarInversa(documento);
        var candidato = insertar.CrearCandidato(documento);
        Exige(MYGProyectoStorage.Firma(candidato) == original && MYGProyectoStorage.Firma(documento) == insertado,
            "El candidato no restauró códigos manuales aislados o modificó el cronograma original.");
        insertar.Aplicar(documento);
        MYGCodigosCronogramaPresupuesto.Actualizar(documento); // Igual que el refresco del editor.
        Exige(!p.NumeracionCorrelativa && p.PrefijoNumeracionCorrelativa == null &&
            MYGProyectoStorage.Firma(documento) == original && !p.Items.Any(i => i.Id == nueva.Id),
            "Deshacer primera activación dejó códigos correlativos en las tareas o perdió el estado original.");
        rehacerInsercion.Aplicar(documento);
        MYGCodigosCronogramaPresupuesto.Actualizar(documento);
        Exige(MYGProyectoStorage.Firma(documento) == insertado && p.NumeracionCorrelativa &&
            documento.Cronograma.Tareas[2].Codigo == "CODIGO-AJENO" &&
            documento.Cronograma.Tareas[0].InicioManual == fechas &&
            ReferenceEquals(vinculos, documento.Cronograma.Tareas[1].Predecesoras),
            "Rehacer activación alteró fechas, vínculos o códigos ajenos al presupuesto.");
        pasa("Primera activación y Ctrl+Z/rehacer restauran códigos manuales de tareas y firma exacta sin cambiar programación ni vínculos");
    }

}
