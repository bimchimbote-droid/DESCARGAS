using System;
using System.Linq;
using MYG_2027;

internal static class NumeracionIntegracionesCheck
{
    private static void Exige(bool valor, string mensaje)
    { if (!valor) throw new InvalidOperationException(mensaje); }

    private static ItemPresupuestoDelphin Nodo(string nombre, int posicion, bool oficial = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new() { Id = id, IdLocalMYG = id, IdPropuesta = oficial ? null : id,
            IdInternoDelphin = oficial ? id : null, Descripcion = nombre, Posicion = posicion,
            Item = "01." + posicion.ToString("D2"), TipoPropuesta = "PARTIDA", Unidad = "und",
            Origen = oficial ? "DELPHIN" : "MODELO", Estado = oficial ? "OFICIAL" : "PROPUESTA" };
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("Numeración persistente", "Presupuesto");
        var p = d.Presupuestos.Single(); p.Item = "1";
        p.Conexion = new() { FuenteId = "FUENTE", ProyectoId = "OBRA", PresupuestoId = p.Id, RutaSQLite = "fuente.sqlite" };
        var a = Nodo("Oficial A", 1, true); var b = Nodo("Oficial B", 2, true);
        var fuenteA = MYGProyectoStorage.Copia(a); var fuenteB = MYGProyectoStorage.Copia(b);
        var propuesta = Nodo("Propuesta intercalada", 2); b.Posicion = 3;
        p.Items.AddRange(new[] { a, propuesta, b });
        MYGNumeracionCorrelativaPresupuesto.Aplicar(p);
        string local = propuesta.IdLocalMYG;
        MYGProyectoStorage.ActualizarDesdeDelphin(p, new() { fuenteA, fuenteB });
        Exige(MYGOrdenPresupuestos.FilasOrdenadas(p).Select(i => i.Id).SequenceEqual(new[] { a.Id, propuesta.Id, b.Id }) &&
            p.Items.Single(i => i.Id == propuesta.Id).IdLocalMYG == local &&
            MYGOrdenPresupuestos.FilasOrdenadas(p).Select(i => i.Item).SequenceEqual(new[] { "01.01", "01.02", "01.03" }),
            "Actualizar desde Delphin cambió la posición de la propuesta o reintrodujo códigos sin correlación.");
        var c = Nodo("Alta remota C", 2, true); fuenteB.Posicion = 3;
        MYGProyectoStorage.ActualizarDesdeDelphin(p, new() { fuenteA, c, fuenteB });
        Exige(MYGOrdenPresupuestos.FilasOrdenadas(p).Select(i => i.Id).SequenceEqual(new[] { a.Id, c.Id, propuesta.Id, b.Id }) &&
            MYGOrdenPresupuestos.FilasOrdenadas(p).Select(i => i.Item).SequenceEqual(new[] { "01.01", "01.02", "01.03", "01.04" }) &&
            p.NumeracionCorrelativa && p.PrefijoNumeracionCorrelativa == "01.",
            "Una fila nueva de la fuente perdió su ubicación o alteró el orden relativo de las propuestas locales.");
        var oficial = p.Items.Single(i => i.Id == a.Id);
        MYGMotorPresupuestos.CapturarDatosDelphin(p, oficial);
        var informe = MYGReportesProyecto.Crear(d, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado).Single().Hoja;
        var calculo = new MYGHojaCalculo(informe);
        Exige(informe.Celdas.Keys.Any(dir => calculo.Mostrar(dir) == "1.01.01") &&
            informe.Celdas.Keys.Any(dir => calculo.Mostrar(dir) == "1.01.03"),
            "El reporte prefijó de forma distinta las filas oficiales y las propuestas con numeración correlativa.");
        pasa("Numeración correlativa conserva posiciones de propuestas al actualizar Delphin, integra altas remotas y unifica códigos de reportes");

        var movible = MYGProyectoStorage.Nuevo("Orden correlativo"); var presupuesto = movible.Presupuestos.Single();
        var primera = Nodo("Primera", 1); var segunda = Nodo("Segunda", 2); var tercera = Nodo("Tercera", 3);
        presupuesto.Items.AddRange(new[] { primera, segunda, tercera });
        MYGNumeracionCorrelativaPresupuesto.Aplicar(presupuesto);
        Exige(MYGOrdenPresupuestos.Mover(movible, segunda, -1) && segunda.Item == "01.01" && primera.Item == "01.02" &&
            tercera.Item == "01.03", "Subir una fila mantuvo un código que ya no corresponde a su posición.");
        Exige(MYGArrastrePresupuestos.Mover(movible, presupuesto.Id, tercera.Id, presupuesto.Id, segunda.Id, MYGDestinoArrastre.Antes) &&
            tercera.Item == "01.01" && segunda.Item == "01.02" && primera.Item == "01.03" &&
            ReferenceEquals(presupuesto.Items.Single(i => i.Id == primera.Id), primera),
            "Arrastrar una fila no actualizó el correlativo o sustituyó las identidades del editor.");
        pasa("Subir, bajar y arrastrar mantienen el correlativo activado sin sustituir identidades ni instancias");
    }
}
