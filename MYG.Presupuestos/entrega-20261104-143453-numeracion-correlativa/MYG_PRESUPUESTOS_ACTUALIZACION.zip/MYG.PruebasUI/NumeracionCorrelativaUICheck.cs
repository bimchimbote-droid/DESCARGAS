using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class NumeracionCorrelativaUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        AperturaYEdicion(legado: true, exige);
        AperturaYEdicion(legado: false, exige);
        AperturaYEdicion(legado: true, exige, propuestaGuardadaComoNativa: true);
    }

    private static void AperturaYEdicion(bool legado, Action<bool, string> exige, bool propuestaGuardadaComoNativa = false)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Numeración correlativa sintética", "Presupuesto");
        var presupuesto = proyecto.Presupuestos.Single(); presupuesto.Item = "1";
        var titulo = Nodo("INSTALACIONES", "01.01", 1, null, oficial: true, titulo: true);
        presupuesto.Items.Add(titulo);
        var oficiales = new List<ItemPresupuestoDelphin>();
        for (int n = 1; n <= 9; n++)
        {
            var fila = Nodo("PARTIDA OFICIAL " + n, "01.01." + n.ToString("D2"), n < 5 ? n : n + 1,
                titulo.Id, oficial: true);
            presupuesto.Items.Add(fila); oficiales.Add(fila);
        }
        var propuesta = Nodo("PARTIDA INTERCALADA", legado ? "P-005" : "01.01.90", 5, titulo.Id);
        if (propuestaGuardadaComoNativa) propuesta.IdInternoDelphin = "NATIVA-" + propuesta.Id;
        presupuesto.Items.Add(propuesta);
        presupuesto.NumeracionCorrelativa = !legado;
        presupuesto.PrefijoNumeracionCorrelativa = legado ? null : "01.";
        MYGProyectoStorage.Validar(proyecto);
        string firmaAnterior = MYGProyectoStorage.Firma(proyecto);
        var identidades = presupuesto.Items.ToDictionary(i => i.Id,
            i => (i.IdLocalMYG, i.IdInternoDelphin, i.IdAnalisisDelphin, i.IdPropuesta));

        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial))!.SetValue(sesion,
            new CredencialMYG { Usuario = "Prueba sintética de numeración" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado))!.SetValue(sesion, true);
        using var editor = new EditorForm(proyecto, null, sesion, firmaAnterior) { ClientSize = new Size(1500, 900) };
        try
        {
            editor.Show(); Application.DoEvents();
            var panel = Campo<MYGPanelPresupuesto>(editor, "panelPresupuesto");
            var tabla = Campo<DataGridView>(panel, "estructura");
            var undo = Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "undo");
            var redo = Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "redo");
            exige(presupuesto.NumeracionCorrelativa && presupuesto.PrefijoNumeracionCorrelativa == "01." &&
                propuesta.Item == "01.01.05" && oficiales[4].Item == "01.01.06" &&
                oficiales[8].Item == "01.01.10" && titulo.Item == "01.01",
                "Abrir una propuesta heredada o un presupuesto marcado debe mostrar correlativos jerárquicos conservando el prefijo.");
            exige(editor.CambiosPendientes && firmaAnterior != MYGProyectoStorage.Firma(Documento()),
                "La migración de códigos al abrir debe quedar pendiente de guardar sin cambiar la firma guardada.");
            exige(Convert.ToString(Fila(propuesta).Cells["ITEM"].Value) == "1.01.01.05" &&
                tabla.Rows.Cast<DataGridViewRow>().All(f => !Convert.ToString(f.Cells["ITEM"].Value)!.Contains("P-", StringComparison.OrdinalIgnoreCase)),
                "La columna visible debe incluir el código del presupuesto y retirar los códigos provisionales P-.");
            VerificarIdentidades();
            var filaOficial = Fila(oficiales[4]);
            undo.Push(MYGEntradaHistorialProyecto.CapturarEstructura(Documento(), presupuesto)); redo.Clear();
            var nueva = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false, titulo.Id, oficiales[4].Id);
            Invocar(editor, "RefrescarEstructuraRapida", presupuesto, nueva, true, true);
            exige(nueva.Item == "01.01.06" && oficiales[4].Item == "01.01.07" &&
                ReferenceEquals(Fila(oficiales[4]), filaOficial) && ReferenceEquals(tabla.CurrentRow!.Tag, nueva) &&
                tabla.IsCurrentCellInEditMode && tabla.CurrentCell!.OwningColumn.Name == "DESC",
                "Insertar entre filas oficiales debe publicar inmediatamente su correlativo y editar el nombre sin reconstruir las filas existentes.");
            string nuevaId = nueva.Id, nuevaLocal = nueva.IdLocalMYG;
            tabla.CancelEdit();
            Invocar(editor, "Historial", false); Application.DoEvents();
            exige(!Presupuesto().Items.Any(i => i.Id == nuevaId) && propuesta.Item == "01.01.05" &&
                oficiales[4].Item == "01.01.06" && Presupuesto().NumeracionCorrelativa &&
                ReferenceEquals(Fila(oficiales[4]), filaOficial),
                "Deshacer la inserción debe cerrar el hueco correlativo conservando el marcador y las filas originales.");
            VerificarIdentidades();
            Invocar(editor, "Historial", true); Application.DoEvents();
            var restaurada = Presupuesto().Items.Single(i => i.Id == nuevaId);
            exige(restaurada.IdLocalMYG == nuevaLocal && restaurada.Item == "01.01.06" &&
                oficiales[4].Item == "01.01.07" && Presupuesto().NumeracionCorrelativa &&
                Presupuesto().Items.All(i => !i.Item.StartsWith("P-", StringComparison.OrdinalIgnoreCase)),
                "Rehacer debe recuperar la misma identidad local y su ubicación correlativa, sin reintroducir códigos provisionales.");
            VerificarIdentidades();

            // Restablecer también debe funcionar sobre un presupuesto oficial.
            Presupuesto().Items.Single(i => i.Id == oficiales[4].Id).Item = "01.01.99";
            Invocar(editor, "RestablecerNumeracion", titulo); Application.DoEvents();
            exige(Presupuesto().Items.Single(i => i.Id == oficiales[4].Id).Item == "01.01.07" &&
                editor.CambiosPendientes, "Restablecer numeración debe corregir los códigos de presentación oficiales y marcar el cambio pendiente.");
            VerificarIdentidades();

            MYGProyectoDocumento Documento() => Campo<MYGProyectoDocumento>(editor, "documento");
            MYGPresupuestoDocumento Presupuesto() => Documento().Presupuestos.Single();
            DataGridViewRow Fila(ItemPresupuestoDelphin item) => tabla.Rows.Cast<DataGridViewRow>()
                .Single(f => f.Tag is ItemPresupuestoDelphin i && i.Id == item.Id);
            void VerificarIdentidades() => exige(Presupuesto().Items.Where(i => identidades.ContainsKey(i.Id))
                .All(i => identidades[i.Id] == (i.IdLocalMYG, i.IdInternoDelphin, i.IdAnalisisDelphin, i.IdPropuesta)),
                "Cambiar los códigos visibles debe conservar todas las identidades locales, oficiales y de análisis.");
        }
        finally { editor.CerrarConfirmado(); }
    }

    private static ItemPresupuestoDelphin Nodo(string descripcion, string codigo, int posicion,
        string padre, bool oficial = false, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = MYGProyectoStorage.NuevoId(), IdPropuesta = oficial ? null : id,
            IdInternoDelphin = oficial ? "OFICIAL-" + id : null,
            IdAnalisisDelphin = oficial && !titulo ? "ANALISIS-" + id : null,
            Item = codigo, ParentId = padre, Posicion = posicion, Descripcion = descripcion,
            Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA",
            Origen = oficial ? "DELPHIN" : "MODELO", Estado = oficial ? "OFICIAL" : "PROPUESTA",
            Costos = new MYGDatosPartida { Cantidad = titulo ? 0 : 1, PrecioDirecto = titulo ? 0 : 10 }
        };
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados)!.GetValue(objeto)!;

    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados)!.Invoke(objeto, argumentos)!; }
        catch (TargetInvocationException error) when (error.InnerException != null)
        { ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
    }
}
