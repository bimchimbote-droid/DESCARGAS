using System.Linq;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private bool tablaBimEstructuraPendiente;

    private void PrepararNumeracionCorrelativa()
    {
        // Compatibilidad con propuestas creadas por versiones anteriores. Sólo
        // se modifica el documento en memoria; Guardar conserva el cambio.
        foreach (var p in documento.Presupuestos)
            if (p.NumeracionCorrelativa || p.Items.Any(i =>
                i.Item?.StartsWith("P-", System.StringComparison.OrdinalIgnoreCase) == true &&
                i.Item.Length > 2 && i.Item.Skip(2).All(c => c >= '0' && c <= '9')))
                MYGNumeracionCorrelativaPresupuesto.Aplicar(p);
        MYGCodigosCronogramaPresupuesto.Actualizar(documento);
    }

    // La tabla BIM es una herramienta modal. Mientras está cerrada no debe
    // reconstruir miles de celdas por cada inserción, eliminación o Ctrl+Z.
    private void RefrescarEstructuraRapida(MYGPresupuestoDocumento presupuestoEditado,
        object seleccion = null, bool editarNombre = false, bool pendiente = true)
    {
        MYGActivosRevit.LimpiarAsignacionesHuerfanas(documento);
        MYGCodigosCronogramaPresupuesto.Actualizar(documento);
        pendienteEstructuraRapidaConfirmado = ocupado ? pendiente : null;
        if (HerramientasBimVisibles)
        {
            Refrescar();
            if (seleccion != null) panelPresupuesto?.SeleccionarEstructura(seleccion, editarNombre);
            return;
        }

        tablaBimEstructuraPendiente = true;
        // Evitar que una fila antigua de la herramienta modal quede seleccionada
        // y se interprete como la partida activa después de borrar/deshacer.
        grid.ClearSelection();
        grid.CurrentCell = null;
        bool anterior = cargando;
        cargando = true;
        try
        {
            presupuesto.DataSource = documento.Presupuestos.ToList();
            presupuesto.SelectedItem = P;
        }
        finally { cargando = anterior; }
        panelPresupuesto?.RefrescarEstructuraEditada(presupuestoEditado, seleccion, editarNombre);
        ActualizarResumenConPendiente(pendiente);
        RefrescarCronogramaEditor();
    }
}
