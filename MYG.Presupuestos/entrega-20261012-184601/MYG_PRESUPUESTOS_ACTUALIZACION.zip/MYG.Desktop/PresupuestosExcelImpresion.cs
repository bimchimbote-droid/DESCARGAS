using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private void MargenesHoja()
    {
        var h = actual.Costos.Hoja;
        using var d = new MYGCamposProyectoForm("Márgenes", new[] { "Izquierdo (pulgadas)", "Derecho (pulgadas)", "Superior (pulgadas)", "Inferior (pulgadas)" },
            new[] { h.MargenIzquierdo.ToString(CultureInfo.InvariantCulture), h.MargenDerecho.ToString(CultureInfo.InvariantCulture), h.MargenSuperior.ToString(CultureInfo.InvariantCulture), h.MargenInferior.ToString(CultureInfo.InvariantCulture) });
        if (d.ShowDialog(this) != DialogResult.OK) return;
        var valores = d.Valores.Select(x => MYGHojaCalculo.IntentarNumero(x, out var n) && n >= 0 && n <= 3 ? n : throw new InvalidOperationException("Indique márgenes entre 0 y 3 pulgadas.")).ToArray();
        EditarVistaHoja(x => { x.MargenIzquierdo = valores[0]; x.MargenDerecho = valores[1]; x.MargenSuperior = valores[2]; x.MargenInferior = valores[3]; });
    }
    private void ImprimirHoja(bool vistaPrevia, bool rapida = false)
    {
        RequerirPartida(); FinalizarEdicion();
        var h = MYGProyectoStorage.Copia(actual.Costos.Hoja);
        var motor = new MYGHojaCalculo(h);
        var limites = string.IsNullOrWhiteSpace(h.AreaImpresion)
            ? (f1: 0, c1: 0, f2: Math.Max(15, h.Celdas.Keys.Select(x => MYGHojaCalculo.Coordenadas(x).Fila - 1).DefaultIfEmpty(15).Max()), c2: Math.Max(7, h.Celdas.Keys.Select(x => MYGHojaCalculo.Coordenadas(x).Columna - 1).DefaultIfEmpty(7).Max()))
            : RangoHoja(h.AreaImpresion);
        limites.f2 = Math.Min(limites.f2, h.Filas - 1); limites.c2 = Math.Min(limites.c2, h.Columnas - 1);
        using var documento = new PrintDocument { DocumentName = "Metrado " + actual.Item };
        var pagina = documento.DefaultPageSettings;
        pagina.Landscape = h.OrientacionPagina == "Horizontal";
        pagina.PaperSize = h.TamanoPapel switch
        {
            "A3" => new PaperSize("A3", 1169, 1654),
            "Carta" => new PaperSize("Carta", 850, 1100),
            "Oficio" => new PaperSize("Oficio", 850, 1400),
            _ => new PaperSize("A4", 827, 1169)
        };
        pagina.Margins = new((int)(h.MargenIzquierdo * 100), (int)(h.MargenDerecho * 100), (int)(h.MargenSuperior * 100), (int)(h.MargenInferior * 100));
        int filaSiguiente = limites.f1, numeroPagina = 0;
        string identificacion = (P?.Nombre ?? "") + "   " + actual.Item + "  " + actual.Descripcion;
        documento.BeginPrint += (_, _) => { filaSiguiente = limites.f1; numeroPagina = 0; };
        documento.PrintPage += (_, e) =>
        {
            numeroPagina++;
            using var titulo = new Font("Segoe UI", 11, FontStyle.Bold);
            using var datos = new Font("Segoe UI", 8);
            e.Graphics.DrawString("Metrado · " + identificacion, titulo, Brushes.Black, e.MarginBounds.Left, e.MarginBounds.Top);
            float y = e.MarginBounds.Top + 38;
            float anchoBase = Enumerable.Range(limites.c1, limites.c2 - limites.c1 + 1).Sum(c => h.AnchosColumnas.GetValueOrDefault(c + 1, c == 0 ? 288 : c == 7 ? 110 : 68));
            float escala = Math.Min(1f, (e.MarginBounds.Width - (h.ImprimirEncabezados ? 25 : 0)) / anchoBase);
            float altoMinimo = 28 * escala;
            if (e.MarginBounds.Height <= 70 + altoMinimo) throw new InvalidOperationException("El área de impresión es demasiado pequeña.");
            void Fila(int f)
            {
                float alto = Math.Max(14, h.AltosFilas.GetValueOrDefault(f + 1, f == 1 ? 28 : 20) * escala);
                float x = e.MarginBounds.Left;
                if (h.ImprimirEncabezados) { e.Graphics.DrawString((f + 1).ToString(), datos, Brushes.Black, x, y); x += 25; }
                for (int c = limites.c1; c <= limites.c2; c++)
                {
                    float ancho = h.AnchosColumnas.GetValueOrDefault(c + 1, c == 0 ? 288 : c == 7 ? 110 : 68) * escala;
                    string dir = DireccionCelda(f, c);
                    var estilo = h.Celdas.GetValueOrDefault(dir) ?? new MYGCeldaHoja();
                    using var fuente = new Font(estilo.Fuente, Math.Max(5, (float)estilo.TamanoFuente * escala),
                        (estilo.Negrita ? FontStyle.Bold : 0) | (estilo.Cursiva ? FontStyle.Italic : 0) | (estilo.Subrayado ? FontStyle.Underline : 0) | (estilo.Tachado ? FontStyle.Strikeout : 0));
                    using var tinta = new SolidBrush(string.IsNullOrEmpty(estilo.ColorTexto) ? Color.Black : ColorHoja(estilo.ColorTexto));
                    var rect = new RectangleF(x, y, ancho, alto);
                    if (!string.IsNullOrEmpty(estilo.ColorFondo)) { using var fondo = new SolidBrush(ColorHoja(estilo.ColorFondo)); e.Graphics.FillRectangle(fondo, rect); }
                    if (h.ImprimirLineasDivision || estilo.Bordes || f < 16) e.Graphics.DrawRectangle(Pens.Gray, x, y, ancho, alto);
                    using var formato = new StringFormat { Alignment = MYGEdicionHoja.AlineacionCelda(estilo, dir) switch { "Centro" => StringAlignment.Center, "Derecha" => StringAlignment.Far, _ => StringAlignment.Near }, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter };
                    e.Graphics.DrawString(motor.Mostrar(dir), fuente, tinta, new RectangleF(x + 2, y + 1, Math.Max(1, ancho - 4), alto - 2), formato);
                    x += ancho;
                }
                y += alto;
            }
            if (h.ImprimirEncabezados)
            {
                float x = e.MarginBounds.Left + 25;
                for (int c = limites.c1; c <= limites.c2; c++) { float ancho = h.AnchosColumnas.GetValueOrDefault(c + 1, c == 0 ? 288 : c == 7 ? 110 : 68) * escala; e.Graphics.DrawString(MYGHojaCalculo.Columna(c + 1), datos, Brushes.Black, x + 3, y); x += ancho; }
                y += 18;
            }
            if (numeroPagina > 1 && h.RepetirTitulos && limites.f1 == 0) { Fila(0); if (h.Filas > 1) Fila(1); }
            int antesFila = filaSiguiente;
            while (filaSiguiente <= limites.f2)
            {
                if (h.FilasOcultas.Contains(filaSiguiente + 1)) { filaSiguiente++; continue; }
                float alto = Math.Max(14, h.AltosFilas.GetValueOrDefault(filaSiguiente + 1, 20) * escala);
                if (y + alto > e.MarginBounds.Bottom - 20) break;
                Fila(filaSiguiente++);
            }
            if (filaSiguiente == antesFila) throw new InvalidOperationException("No cabe una fila en el área de impresión.");
            e.Graphics.DrawString("Página " + numeroPagina, datos, Brushes.Gray, e.MarginBounds.Left, e.MarginBounds.Bottom - 14);
            e.HasMorePages = filaSiguiente <= limites.f2;
        };
        if (vistaPrevia) { using var d = new PrintPreviewDialog { Document = documento, Width = 1100, Height = 800 }; d.ShowDialog(this); }
        else if (rapida) documento.Print();
        else { using var d = new PrintDialog { Document = documento, UseEXDialog = true }; if (d.ShowDialog(this) == DialogResult.OK) documento.Print(); }
    }
}
