using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

// Sólo datos inventados. La muestra privada que motivó la corrección no se
// incluye en estas pruebas ni es necesaria para ejecutarlas.
internal static class RecuperacionJerarquiaDelphinCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        AperturaYGuardado(carpeta, pasa);
        RenombrarTitulo(carpeta, pasa);
        GuardadoDePartida(carpeta, pasa);
        IdentidadAusenteLarga(carpeta, pasa);
        ReferenciaAusenteCompartida(carpeta, pasa);
        DefinicionExplicita(carpeta, pasa);
        Aislamiento(carpeta, pasa);
        ValidacionEstricta(carpeta, pasa);
    }

    private static void AperturaYGuardado(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "lectura_guardado");
        string huella = Huella(ruta), nativo = InstantaneaNativa(ruta);
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var p = doc.Presupuestos.Single();
        var grupos = p.Items.Where(MYGRecuperacionJerarquiaDelphin.EsProvisional).ToList();
        Exige(MYGRecuperacionJerarquiaDelphin.Contar(doc) == 2 && grupos.Count == 2 && p.Items.Count == 8,
            "La lectura duplicó grupos del mismo padre o perdió nodos de las ramas afectadas.");
        foreach (string id in new[] { "CU-RX-M1", "CU-RX-M2" })
        {
            var grupo = grupos.Single(x => x.Id == id);
            Exige(grupo.ParentId == null && grupo.IdInternoDelphin == id &&
                grupo.IdLocalMYG == "DELPHIN-LOCAL-" + id && grupo.IdTituloAusenteDelphin == id &&
                grupo.Descripcion == MYGRecuperacionJerarquiaDelphin.DescripcionTitulo(id) &&
                string.IsNullOrWhiteSpace(grupo.Item) && string.IsNullOrWhiteSpace(grupo.Unidad),
                "El grupo provisional inventó una posición original, cambió identidad o carece de identificación explícita.");
        }
        Exige(p.Items.Single(x => x.Id == "CU-RX-H1").ParentId == "CU-RX-M1" &&
            p.Items.Single(x => x.Id == "CU-RX-P2").ParentId == "CU-RX-M1" &&
            p.Items.Single(x => x.Id == "CU-RX-P1").ParentId == "CU-RX-H1" &&
            p.Items.Single(x => x.Id == "CU-RX-P3").ParentId == "CU-RX-M2",
            "La recuperación aplanó descendientes o cambió las referencias de las partidas.");
        Exige(p.Items.Single(x => x.Id == "CU-RX-PX").Item == "09.01" &&
            p.Items.Single(x => x.Id == "CU-RX-P2").Item == "09.01.02" &&
            p.Items.Single(x => x.Id == "CU-RX-P2").ParentId != "CU-RX-PX",
            "La numeración reutilizada de otra partida se utilizó para inferir un padre.");
        pasa("Recuperación crea un solo grupo por padre ausente, conserva descendientes y no reasigna por numeración reutilizada");

        ComprobarEconomia(p);
        Exige(Huella(ruta) == huella && InstantaneaNativa(ruta) == nativo,
            "Abrir una obra con grupos provisionales modificó la base nativa.");
        pasa("Lectura de ramas recuperadas conserva SHA-256, identidades, cantidades, precios, parciales y especificaciones");

        var copia = MYGProyectoStorage.Copia(doc);
        Exige(MYGRecuperacionJerarquiaDelphin.Contar(copia) == 2 &&
            copia.Presupuestos.Single().Items.Single(x => x.Id == "CU-RX-M1").IdTituloAusenteDelphin == "CU-RX-M1",
            "Copiar o serializar el documento perdió el marcador que identifica los grupos provisionales.");
        MYGProyectoStorage.Validar(copia);
        pasa("El marcador de título ausente sobrevive a la copia JSON del documento sin relajar la validación general");

        string otraObra = InstantaneaOtraObra(ruta);
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(InstantaneaNativa(ruta) == nativo && InstantaneaOtraObra(ruta) == otraObra &&
            CuentaNativo(ruta, "CU-RX-M1") == 0 && CuentaNativo(ruta, "CU-RX-M2") == 0,
            "Guardar sin editar creó títulos nativos, alteró relaciones o cambió otra obra.");
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        Exige(MYGRecuperacionJerarquiaDelphin.Contar(reabierto) == 2 &&
            reabierto.Presupuestos.Single().Items.Count == p.Items.Count,
            "Guardar extensiones MYG y reabrir duplicó o perdió las agrupaciones provisionales.");
        ComprobarEconomia(reabierto.Presupuestos.Single());
        MYGProyectoStorage.Guardar(ruta, reabierto);
        Exige(InstantaneaNativa(ruta) == nativo &&
            MYGRecuperacionJerarquiaDelphin.Contar(MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A")) == 2,
            "Un segundo guardado o lectura modificó el árbol nativo o duplicó la recuperación.");
        pasa("Guardar sin editar repetidamente conserva las tablas y relaciones nativas, la otra obra y la recuperación al reabrir");
    }

    private static void RenombrarTitulo(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "renombrar");
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var grupo = doc.Presupuestos.Single().Items.Single(x => x.Id == "CU-RX-M1");
        grupo.Descripcion = "AGRUPACIÓN DEFINIDA POR EL USUARIO";
        Exige(!MYGRecuperacionJerarquiaDelphin.EsProvisional(grupo) &&
            MYGRecuperacionJerarquiaDelphin.Contar(doc) == 1,
            "Renombrar explícitamente el grupo no actualizó el aviso de recuperación.");
        string relaciones = RelacionesCostos(ruta), otraObra = InstantaneaOtraObra(ruta);
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(CuentaNativo(ruta, "CU-RX-M1") == 1 && CuentaNativo(ruta, "CU-RX-M2") == 0 &&
            Texto(ruta, "SELECT descripcion_costo FROM costo_unitario WHERE id_costounitario='CU-RX-M1'") == grupo.Descripcion &&
            Texto(ruta, "SELECT id_presupuesto FROM costo_unitario WHERE id_costounitario='CU-RX-M1'") == "PP-RX-A",
            "El nombre confirmado no materializó el título correcto o materializó otros títulos pendientes.");
        // Sólo se añadió la fila confirmada; las relaciones de los nodos previos
        // se comparan excluyendo esa nueva fila, no mediante su numeración.
        Exige(RelacionesCostos(ruta, "CU-RX-M1") == relaciones && InstantaneaOtraObra(ruta) == otraObra,
            "Confirmar el nombre de un grupo reescribió las referencias existentes o la otra obra.");
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        Exige(MYGRecuperacionJerarquiaDelphin.Contar(reabierto) == 1 &&
            reabierto.Presupuestos.Single().Items.Single(x => x.Id == "CU-RX-M1").Descripcion == grupo.Descripcion,
            "El título confirmado no se conservó al reabrir.");
        ComprobarEconomia(reabierto.Presupuestos.Single());
        pasa("Renombrar y guardar materializa únicamente el título confirmado con su identidad original sin cambiar relaciones ni importes");
    }

    private static void GuardadoDePartida(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "edicion_partida");
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var p = doc.Presupuestos.Single();
        var partida = p.Items.Single(x => x.Id == "CU-RX-P2");
        partida.Costos.Cantidad = 4m;
        string relaciones = RelacionesCostos(ruta), otraObra = InstantaneaOtraObra(ruta);
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(RelacionesCostos(ruta) == relaciones && CuentaNativo(ruta, "CU-RX-M1") == 0 &&
            CuentaNativo(ruta, "CU-RX-M2") == 0 && InstantaneaOtraObra(ruta) == otraObra,
            "Editar una partida materializó títulos no confirmados o alteró relaciones originales.");
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var nueva = reabierto.Presupuestos.Single().Items.Single(x => x.Id == "CU-RX-P2");
        Exige(nueva.Costos.Cantidad == 4m && nueva.ParentId == "CU-RX-M1" &&
            MYGRecuperacionJerarquiaDelphin.Contar(reabierto) == 2 &&
            MYGMotorPresupuestos.TotalPartida(reabierto.Presupuestos.Single(), nueva) == 45m,
            "La edición legítima de una partida bajo grupo provisional no se conservó correctamente.");
        pasa("Editar y guardar una partida bajo un grupo provisional conserva el metrado editado sin inventar títulos nativos");
    }

    private static void Aislamiento(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "padre_ajeno");
        SQL(ruta, "UPDATE costo_unitario SET id_costopadre='CU-RX-B1' WHERE id_costounitario='CU-RX-P2'");
        RechazaSinEscritura(ruta, "Falta el padre", "Se usó una fila de otra obra o se ocultó su referencia como un grupo ausente.");
        pasa("Un padre existente en otra obra continúa rechazado y no se representa como una ausencia global");

        ruta = CrearArbol(carpeta, "titulo_ajeno");
        SQL(ruta, """
            INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto)
            VALUES('PP-RX-A2','PR-RX-A','PRESUPUESTO ADICIONAL',2);
            INSERT INTO titulo(id_titulo,descripcion_titulo,id_presupuesto)
            VALUES('TI-RX-A2','TÍTULO DE OTRO PRESUPUESTO','PP-RX-A2');
            UPDATE costo_unitario SET id_costopadre='TI-RX-A2' WHERE id_costounitario='CU-RX-P2';
            """);
        RechazaSinEscritura(ruta, "Falta el padre", "Se recuperó como ausente un título que pertenece a otro presupuesto.");
        pasa("Los títulos de otro presupuesto de la misma obra conservan su aislamiento durante la recuperación");
    }

    private static void IdentidadAusenteLarga(string carpeta, Action<string> pasa)
    {
        const string ausente = "PADRE-ANTIGUO-LARGO";
        string ruta = CrearArbol(carpeta, "identidad_larga");
        SQL(ruta, "UPDATE costo_unitario SET id_costopadre=$p0 WHERE id_costopadre='CU-RX-M1'", ausente);
        string huella = Huella(ruta), nativo = InstantaneaNativa(ruta), relaciones = RelacionesCostos(ruta);
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var p = doc.Presupuestos.Single();
        Exige(p.Items.Single(x => x.Id == "CU-RX-P2").ParentId == ausente &&
            MYGRecuperacionJerarquiaDelphin.EsProvisional(p.Items.Single(x => x.Id == ausente)) &&
            Huella(ruta) == huella,
            "La lectura sustituyó una identidad ausente larga por otra o modificó SQLite.");
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(InstantaneaNativa(ruta) == nativo && CuentaNativo(ruta, ausente) == 0,
            "Guardar un título provisional con identidad larga creó una fila nativa o reescribió las relaciones mediante un hash.");
        doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        p = doc.Presupuestos.Single();
        p.Items.Single(x => x.Id == "CU-RX-P2").Costos.Cantidad = 4m;
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(RelacionesCostos(ruta) == relaciones && CuentaNativo(ruta, ausente) == 0 &&
            Texto(ruta, "SELECT id_costopadre FROM costo_unitario WHERE id_costounitario='CU-RX-P2'") == ausente,
            "Editar una partida reemplazó el padre ausente largo por una identidad calculada.");
        doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        p = doc.Presupuestos.Single();
        Exige(p.Items.Single(x => x.Id == "CU-RX-P2").Costos.Cantidad == 4m &&
            p.Items.Single(x => x.Id == "CU-RX-P2").ParentId == ausente,
            "La edición bajo una identidad larga no se conservó al reabrir.");
        p.Items.Single(x => x.Id == ausente).Descripcion = "TÍTULO LARGO CONFIRMADO POR EL USUARIO";
        long filasAntes = Convert.ToInt64(Texto(ruta, "SELECT COUNT(*) FROM costo_unitario"), CultureInfo.InvariantCulture);
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(CuentaNativo(ruta, ausente) == 1 && RelacionesCostos(ruta, ausente) == relaciones &&
            Convert.ToInt64(Texto(ruta, "SELECT COUNT(*) FROM costo_unitario"), CultureInfo.InvariantCulture) == filasAntes + 1,
            "Confirmar el grupo largo no creó exactamente la identidad original o alteró sus hijos.");
        doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        Exige(doc.Presupuestos.Single().Items.Single(x => x.Id == ausente).Descripcion == "TÍTULO LARGO CONFIRMADO POR EL USUARIO" &&
            MYGRecuperacionJerarquiaDelphin.Contar(doc) == 1,
            "El título largo confirmado reapareció provisional o perdió su nombre.");
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(CuentaNativo(ruta, ausente) == 1 && RelacionesCostos(ruta, ausente) == relaciones &&
            Convert.ToInt64(Texto(ruta, "SELECT COUNT(*) FROM costo_unitario"), CultureInfo.InvariantCulture) == filasAntes + 1,
            "Reabrir y volver a guardar duplicó o transformó la identidad larga confirmada.");
        pasa("Identidades ausentes largas conservan el padre literal al leer, guardar, editar y confirmar sin crear hashes ni filas duplicadas");
    }

    private static void ReferenciaAusenteCompartida(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "ausente_compartido");
        SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,id_costopadre,
                id_unidad,numeracion_costo,posicion_costo,cantidad,cantidad_metrado,costo_unitario,parcial_costo)
            VALUES('CU-RX-B2','PARTIDA DE LA OTRA OBRA CON REFERENCIA AUSENTE','PP-RX-B','CU-RX-M1',
                'UN-RX','02.01',2,2,2,9,18);
            """);
        ComprobarRechazoCompartido(ruta);
        string nativaPura = Path.Combine(carpeta, "Recuperacion_ausente_compartido_nativa_pura.sqlite");
        CopiarSoloTablasNativas(ruta, nativaPura);
        Exige(Texto(nativaPura, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='myg_info'") == "0",
            "La variante nativa pura contiene extensiones MYG y no verifica el preflight anterior a la inicialización.");
        ComprobarRechazoCompartido(nativaPura);
        pasa("Una identidad ausente compartida por obras distintas se visualiza aislada y su confirmación unilateral se rechaza sin modificar SQLite, con o sin extensiones MYG");
    }

    private static void ComprobarRechazoCompartido(string ruta)
    {
        string huella = Huella(ruta), nativo = InstantaneaNativa(ruta);
        var docA = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var docB = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-B");
        Exige(MYGRecuperacionJerarquiaDelphin.Contar(docA) == 2 &&
            MYGRecuperacionJerarquiaDelphin.Contar(docB) == 1 &&
            docA.Presupuestos.Single().Items.Single(x => x.Id == "CU-RX-P2").ParentId == "CU-RX-M1" &&
            docB.Presupuestos.Single().Items.Single(x => x.Id == "CU-RX-B2").ParentId == "CU-RX-M1" &&
            Huella(ruta) == huella,
            "La lectura no mantuvo aisladas las referencias a una misma identidad globalmente ausente.");
        docA.Presupuestos.Single().Items.Single(x => x.Id == "CU-RX-M1").Descripcion = "NOMBRE PROPUESTO SÓLO PARA LA PRIMERA OBRA";
        bool rechazado = false;
        try { MYGProyectoStorage.Guardar(ruta, docA); }
        catch (InvalidOperationException e) when (e.Message.Contains("presupuesto", StringComparison.OrdinalIgnoreCase))
        { rechazado = true; }
        Exige(rechazado && Huella(ruta) == huella && InstantaneaNativa(ruta) == nativo &&
            CuentaNativo(ruta, "CU-RX-M1") == 0,
            "Confirmar una identidad ausente compartida entre presupuestos no se rechazó atómicamente o dejó modificaciones.");
        Exige(MYGRecuperacionJerarquiaDelphin.Contar(MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A")) == 2 &&
            MYGRecuperacionJerarquiaDelphin.Contar(MYGBaseDatos.LeerProyecto(ruta, "PR-RX-B")) == 1,
            "Un intento rechazado impidió volver a abrir las obras con sus agrupaciones provisionales.");
    }

    private static void CopiarSoloTablasNativas(string origen, string destino)
    {
        using var salida = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = destino, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false, ForeignKeys = false }.ToString());
        salida.Open(); using var q = salida.CreateCommand();
        q.CommandText = "ATTACH DATABASE $ruta AS fuente"; q.Parameters.AddWithValue("$ruta", origen);
        q.ExecuteNonQuery(); q.Parameters.Clear();
        foreach (string tabla in new[] { "proyecto", "presupuesto", "costo_unitario", "titulo", "unidad" })
        {
            q.CommandText = "SELECT sql FROM fuente.sqlite_master WHERE type='table' AND name=$tabla";
            q.Parameters.AddWithValue("$tabla", tabla);
            string definicion = q.ExecuteScalar() as string ?? throw new InvalidOperationException("Falta la tabla de prueba " + tabla + ".");
            q.Parameters.Clear(); q.CommandText = definicion; q.ExecuteNonQuery();
            q.CommandText = "INSERT INTO main.\"" + tabla + "\" SELECT * FROM fuente.\"" + tabla + "\"";
            q.ExecuteNonQuery();
        }
        q.CommandText = "DETACH DATABASE fuente"; q.ExecuteNonQuery();
    }

    private static void DefinicionExplicita(string carpeta, Action<string> pasa)
    {
        string ruta = CrearArbol(carpeta, "definicion_explicita");
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var p = doc.Presupuestos.Single();
        var grupo = p.Items.Single(x => x.Id == "CU-RX-M1");
        var identidades = new { grupo.Id, grupo.IdLocalMYG, grupo.IdInternoDelphin, grupo.Item, grupo.Posicion, grupo.IdTituloAusenteDelphin };
        string otros = System.Text.Json.JsonSerializer.Serialize(p.Items.Where(x => x.Id != grupo.Id).ToList());
        string huella = Huella(ruta);
        MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, grupo.Id, "  GRUPO DEFINIDO Y UBICADO POR EL USUARIO  ", "CU-RX-H0");
        Exige(grupo.Descripcion == "GRUPO DEFINIDO Y UBICADO POR EL USUARIO" && grupo.ParentId == "CU-RX-H0" &&
            !MYGRecuperacionJerarquiaDelphin.EsProvisional(grupo) &&
            grupo.Id == identidades.Id && grupo.IdLocalMYG == identidades.IdLocalMYG &&
            grupo.IdInternoDelphin == identidades.IdInternoDelphin && grupo.Item == identidades.Item &&
            grupo.Posicion == identidades.Posicion && grupo.IdTituloAusenteDelphin == identidades.IdTituloAusenteDelphin &&
            System.Text.Json.JsonSerializer.Serialize(p.Items.Where(x => x.Id != grupo.Id).ToList()) == otros &&
            Huella(ruta) == huella,
            "Definir un título no conservó identidades, posiciones e hijos, no recortó su nombre o aplicó cambios no solicitados.");
        ComprobarEconomia(p);
        MYGProyectoStorage.Guardar(ruta, doc);
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A");
        var persistido = reabierto.Presupuestos.Single().Items.Single(x => x.Id == grupo.Id);
        Exige(persistido.Descripcion == grupo.Descripcion && persistido.ParentId == "CU-RX-H0" &&
            Texto(ruta, "SELECT id_costopadre FROM costo_unitario WHERE id_costounitario='CU-RX-M1'") == "CU-RX-H0" &&
            MYGRecuperacionJerarquiaDelphin.Contar(reabierto) == 1,
            "La definición explícita no se guardó con su nombre y ubicación o confirmó otros grupos.");
        ComprobarEconomia(reabierto.Presupuestos.Single());
        pasa("Definir título aplica nombre y ubicación elegidos conservando identidades, posiciones, hijos e importes y persiste la decisión explícita");

        ruta = CrearArbol(carpeta, "definicion_rechazada");
        doc = MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A"); p = doc.Presupuestos.Single();
        RechazaDefinicionSinCambios(doc, () => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, "CU-RX-M1", "   "));
        RechazaDefinicionSinCambios(doc, () => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, "CU-RX-M1",
            MYGRecuperacionJerarquiaDelphin.DescripcionTitulo("CU-RX-M1")));
        RechazaDefinicionSinCambios(doc, () => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, "CU-RX-M1", "NOMBRE VÁLIDO", "NO-EXISTE"));
        RechazaDefinicionSinCambios(doc, () => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, "CU-RX-M1", "NOMBRE VÁLIDO", "CU-RX-P1"));
        RechazaDefinicionSinCambios(doc, () => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, "CU-RX-H0", "NO ES UN GRUPO RECUPERADO"));
        pasa("Definir título rechaza nombres vacíos o provisionales, destinos inexistentes o partidas y nodos sin marcador sin cambios parciales");

        RechazaDefinicionSinCambios(doc, () => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, "CU-RX-M1", "NOMBRE VÁLIDO", "CU-RX-H1"));
        RechazaDefinicionSinCambios(doc, () => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(p, "CU-RX-M1", "NOMBRE VÁLIDO", "CU-RX-M1"));
        pasa("Definir título rechaza ciclos hacia un descendiente o hacia sí mismo manteniendo intacto el documento");
    }

    private static void RechazaDefinicionSinCambios(MYGProyectoDocumento doc, Action accion)
    {
        string antes = MYGProyectoStorage.Firma(doc);
        bool rechazado = false;
        try { accion(); }
        catch (InvalidOperationException) { rechazado = true; }
        catch (InvalidDataException) { rechazado = true; }
        catch (ArgumentException) { rechazado = true; }
        Exige(rechazado && MYGProyectoStorage.Firma(doc) == antes,
            "Una definición inválida no fue rechazada o dejó cambios parciales en el documento.");
    }

    private static void ValidacionEstricta(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("DOCUMENTO SINTÉTICO CON RELACIÓN INVÁLIDA");
        doc.Presupuestos.Single().Items.Add(new()
        {
            Id = "CU-RX-J", IdLocalMYG = "CU-RX-J", Descripcion = "PARTIDA JSON HUÉRFANA",
            TipoPropuesta = "PARTIDA", ParentId = "CU-RX-FALTA", Unidad = "m"
        });
        bool rechazado = false;
        try { MYGProyectoStorage.Validar(doc); }
        catch (InvalidDataException e) when (e.Message.Contains("Falta el padre", StringComparison.Ordinal)) { rechazado = true; }
        Exige(rechazado, "La recuperación exclusiva del adaptador Delphin relajó el validador general de documentos JSON.");
        pasa("Los documentos JSON con padres ausentes siguen rechazados por el validador general");

        string ruta = CrearArbol(carpeta, "ciclo");
        SQL(ruta, "UPDATE costo_unitario SET id_costopadre='CU-RX-P1' WHERE id_costounitario='CU-RX-H1'");
        RechazaSinEscritura(ruta, "Jerarquía circular", "La recuperación permitió un ciclo entre nodos nativos existentes.");
        pasa("Los ciclos entre nodos existentes siguen rechazados aunque existan otras ramas recuperables");
    }

    private static void ComprobarEconomia(MYGPresupuestoDocumento p)
    {
        var p1 = p.Items.Single(x => x.Id == "CU-RX-P1");
        var p2 = p.Items.Single(x => x.Id == "CU-RX-P2");
        Exige(p1.IdInternoDelphin == "CU-RX-P1" && p1.IdLocalMYG == "DELPHIN-LOCAL-CU-RX-P1" &&
            p1.Costos.Cantidad == 2.5m && p1.Costos.PrecioDirecto == 7.34m &&
            p1.Costos.PrecioImportadoDelphin == 7.34m && p1.Unidad == "m²" && p1.Item == "09.01.01.01" &&
            p1.Costos.EspecificacionTexto == "ESPECIFICACIÓN SINTÉTICA P1" &&
            MYGMotorPresupuestos.TotalPartida(p, p1) == 18.35m &&
            p2.Costos.Cantidad == 3m && p2.Costos.PrecioDirecto == 11.25m &&
            MYGMotorPresupuestos.TotalPartida(p, p2) == 33.75m &&
            MYGMotorPresupuestos.Resumen(p).CostoDirecto == 65.60m,
            "La recuperación o el guardado cambió identidades, numeración, especificaciones, cantidades o importes originales.");
    }

    private static string CrearArbol(string carpeta, string nombre)
    {
        string ruta = Path.Combine(carpeta, "Recuperacion_" + nombre + ".sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        SQL(ruta, """
            INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,decimales_costo,decimales_cantidad)
            VALUES('PR-RX-A','QA-USUARIO','QA-TIPO','PE','OBRA SINTÉTICA DE RECUPERACIÓN',2,4),
                  ('PR-RX-B','QA-USUARIO','QA-TIPO','PE','OTRA OBRA SINTÉTICA',2,4);
            INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto)
            VALUES('PP-RX-A','PR-RX-A','PRESUPUESTO A',1,'01'),('PP-RX-B','PR-RX-B','PRESUPUESTO B',1,'01');
            INSERT INTO unidad(id_unidad,descripcion_unidad,abreviatura_unidad)
            VALUES('UN-RX','METRO CUADRADO DE PRUEBA','m²');
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,numeracion_costo,posicion_costo)
            VALUES('CU-RX-H0','TÍTULO VIGENTE','PP-RX-A','01',1),
                  ('CU-RX-H1','SUBTÍTULO CON PADRE AUSENTE','PP-RX-A','09.01.01',2);
            UPDATE costo_unitario SET id_costopadre='CU-RX-M1' WHERE id_costounitario='CU-RX-H1';
            """);
        Partida(ruta, "CU-RX-P1", "CU-RX-H1", "09.01.01.01", 3, 2.5m, 7.34m, "P1");
        Partida(ruta, "CU-RX-P2", "CU-RX-M1", "09.01.02", 4, 3m, 11.25m, "P2");
        Partida(ruta, "CU-RX-P3", "CU-RX-M2", "10.01", 5, 1m, 5.50m, "P3");
        Partida(ruta, "CU-RX-PX", null, "09.01", 6, 4m, 2m, "PX");
        SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,numeracion_costo,posicion_costo)
            VALUES('CU-RX-B1','TÍTULO DE OTRA OBRA','PP-RX-B','01',1);
            """);
        return ruta;
    }

    private static void Partida(string ruta, string id, string padre, string item, int posicion,
        decimal cantidad, decimal precio, string sufijo)
        => SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,id_costopadre,id_unidad,
                numeracion_costo,posicion_costo,cantidad,cantidad_metrado,costo_unitario,parcial_costo,
                especificaciones,especificaciones_texto,productividad,magnitud_unidadtiempo)
            VALUES($p0,$p1,'PP-RX-A',$p2,'UN-RX',$p3,$p4,$p5,$p5,$p6,$p7,$p8,'S',1,8)
            """, id, "PARTIDA SINTÉTICA " + sufijo, padre, item, posicion, cantidad, precio,
            decimal.Round(cantidad * precio, 2, MidpointRounding.AwayFromZero), "ESPECIFICACIÓN SINTÉTICA " + sufijo);

    private static void SQL(string ruta, string sql, params object[] valores)
    {
        using var c = Conexion(ruta, true);
        using var q = c.CreateCommand(); q.CommandText = sql;
        for (int n = 0; n < valores.Length; n++) q.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        q.ExecuteNonQuery();
    }

    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly,
            Pooling = false, ForeignKeys = false
        }.ToString());
        c.Open(); return c;
    }

    private static string Texto(string ruta, string sql)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = sql;
        return Convert.ToString(q.ExecuteScalar(), CultureInfo.InvariantCulture) ?? "";
    }

    private static long CuentaNativo(string ruta, string id)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand();
        q.CommandText = "SELECT (SELECT COUNT(*) FROM costo_unitario WHERE id_costounitario=$id)+(SELECT COUNT(*) FROM titulo WHERE id_titulo=$id)";
        q.Parameters.AddWithValue("$id", id);
        return Convert.ToInt64(q.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    private static string RelacionesCostos(string ruta, string excluir = null)
        => Filas(ruta, "SELECT id_costounitario,id_presupuesto,id_costopadre,id_titulo FROM costo_unitario " +
            "WHERE id_costounitario<>$id ORDER BY id_costounitario", excluir ?? "");

    private static string InstantaneaNativa(string ruta)
        => Filas(ruta, "SELECT * FROM costo_unitario ORDER BY id_costounitario") + "\nTÍTULOS\n" +
            Filas(ruta, "SELECT * FROM titulo ORDER BY id_titulo");

    private static string InstantaneaOtraObra(string ruta)
        => Filas(ruta, "SELECT * FROM proyecto WHERE id_proyecto='PR-RX-B'") +
            Filas(ruta, "SELECT * FROM presupuesto WHERE id_presupuesto='PP-RX-B'") +
            Filas(ruta, "SELECT * FROM costo_unitario WHERE id_presupuesto='PP-RX-B' ORDER BY id_costounitario");

    private static string Filas(string ruta, string sql, string id = null)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = sql;
        if (id != null) q.Parameters.AddWithValue("$id", id);
        using var r = q.ExecuteReader(); var filas = new List<string>();
        while (r.Read())
            filas.Add(string.Join("|", Enumerable.Range(0, r.FieldCount).Select(n => r.IsDBNull(n) ? "<NULL>" :
                r.GetValue(n) is byte[] b ? Convert.ToBase64String(b) : Convert.ToString(r.GetValue(n), CultureInfo.InvariantCulture))));
        return string.Join("\n", filas);
    }

    private static void RechazaSinEscritura(string ruta, string mensaje, string detalle)
    {
        string huella = Huella(ruta); bool rechazado = false;
        try { MYGBaseDatos.LeerProyecto(ruta, "PR-RX-A"); }
        catch (InvalidDataException e) when (e.Message.Contains(mensaje, StringComparison.Ordinal)) { rechazado = true; }
        Exige(rechazado && Huella(ruta) == huella, detalle);
    }

    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new InvalidOperationException(detalle); }
}
