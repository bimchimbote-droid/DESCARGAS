using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class JerarquiaDelphinCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        AlternativaExplicita(carpeta, pasa);
        Precedencia(carpeta, pasa);
        TituloComoCostoPadre(carpeta, pasa);
        CeroEsIdentidad(carpeta, pasa);
        MarcadoresRaiz(carpeta, pasa);
        Aislamiento(carpeta, pasa);
        RelacionesInvalidas(carpeta, pasa);
    }

    private static void AlternativaExplicita(string carpeta, Action<string> pasa)
    {
        string ruta = Crear(carpeta, "alternativa");
        Titulo(ruta, "TI-HIJO", "TI-RAIZ", "PP-JA", "01.01", 80);
        Titulo(ruta, "TI-RAIZ", null, "PP-JA", "01", 90);
        Partida(ruta, "CU-JA", "CU-ELIMINADO", "TI-HIJO");
        string huella = Huella(ruta);
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-JA");
        var p = doc.Presupuestos.Single();
        var i = p.Items.Single(x => x.Id == "CU-JA");
        Exige(p.Items.Count == 3 && i.ParentId == "TI-HIJO" &&
            p.Items.Single(x => x.Id == "TI-HIJO").ParentId == "TI-RAIZ" &&
            MYGProyectoStorage.EsTitulo(p.Items.Single(x => x.Id == "TI-RAIZ")),
            "Una referencia costo obsoleta impidió usar el título explícito y su cadena de ancestros locales.");
        Exige(i.IdInternoDelphin == "CU-JA" && i.IdLocalMYG == "DELPHIN-LOCAL-CU-JA" &&
            i.IdAnalisisDelphin == "AC-JA" && i.Item == "01.01.03" && i.Posicion == 1,
            "Resolver el padre cambió identidades, análisis, numeración u orden de la partida.");
        Exige(i.Unidad == "m²" && i.Costos.Cantidad == 2.75m && i.Costos.PrecioDirecto == 13.37m &&
            i.Costos.PrecioImportadoDelphin == 13.37m && MYGMotorPresupuestos.TotalPartida(p, i) == 36.77m &&
            i.Costos.EspecificacionTexto == "ESPECIFICACIÓN SINTÉTICA CONSERVADA",
            "Resolver el padre alteró unidad, metrado, precio, parcial o especificación.");
        Exige(Huella(ruta) == huella, "Abrir una jerarquía heredada modificó el archivo SQLite.");
        pasa("Jerarquía Delphin usa el título explícito válido ante un costo padre ausente y recupera ancestros sin depender del orden");
        pasa("Apertura conserva identidades, numeración, unidad, cantidad, precio, parcial y especificación sin escribir la base");

        string relaciones = Relaciones(ruta);
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(Relaciones(ruta) == relaciones, "Guardar sin editar reescribió las relaciones nativas heredadas.");
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, doc.Id).Presupuestos.Single();
        var releida = reabierto.Items.Single(x => x.Id == "CU-JA");
        Exige(releida.ParentId == "TI-HIJO" && releida.Costos.Cantidad == 2.75m &&
            MYGMotorPresupuestos.TotalPartida(reabierto, releida) == 36.77m,
            "Guardar y reabrir perdió el padre resuelto o la economía de la partida.");
        pasa("Guardar sin editar y reabrir conserva las relaciones originales y el contenido económico de la partida");
    }

    private static void Precedencia(string carpeta, Action<string> pasa)
    {
        string ruta = Crear(carpeta, "precedencia");
        Titulo(ruta, "TI-ALTERNO", null);
        SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,posicion_costo,numeracion_costo)
            VALUES('CU-TITULO','TÍTULO EN COSTOS','PP-JA',20,'01');
            """);
        Partida(ruta, "CU-JA", "CU-TITULO", "TI-ALTERNO");
        string huella = Huella(ruta);
        var p = MYGBaseDatos.LeerProyecto(ruta, "PR-JA").Presupuestos.Single();
        Exige(p.Items.Single(x => x.Id == "CU-JA").ParentId == "CU-TITULO" &&
            MYGProyectoStorage.EsTitulo(p.Items.Single(x => x.Id == "CU-TITULO")),
            "Se reemplazó un costo padre válido por su título alternativo o se perdió el título en costo_unitario.");
        Exige(Huella(ruta) == huella, "Consultar un padre vigente modificó la hoja.");
        pasa("Costo padre vigente conserva precedencia y los títulos recientes en costo_unitario siguen reconocidos");
    }

    private static void TituloComoCostoPadre(string carpeta, Action<string> pasa)
    {
        string ruta = Crear(carpeta, "titulo_en_costo_padre");
        Titulo(ruta, "TI-DIRECTO", null);
        Titulo(ruta, "TI-ALTERNO", null);
        Partida(ruta, "CU-JA", "TI-DIRECTO", "TI-ALTERNO");
        var p = MYGBaseDatos.LeerProyecto(ruta, "PR-JA").Presupuestos.Single();
        Exige(p.Items.Single(x => x.Id == "CU-JA").ParentId == "TI-DIRECTO" &&
            MYGProyectoStorage.EsTitulo(p.Items.Single(x => x.Id == "TI-DIRECTO")),
            "Se perdió compatibilidad con id_costopadre que referencia un título local.");
        pasa("Una referencia id_costopadre a titulo local sigue siendo válida y conserva su precedencia");
    }

    private static void CeroEsIdentidad(string carpeta, Action<string> pasa)
    {
        string ruta = Crear(carpeta, "cero_valido");
        Titulo(ruta, "0", null);
        Titulo(ruta, "TI-ALTERNO", null);
        Partida(ruta, "CU-JA", "0", "TI-ALTERNO");
        var p = MYGBaseDatos.LeerProyecto(ruta, "PR-JA").Presupuestos.Single();
        Exige(p.Items.Single(x => x.Id == "CU-JA").ParentId == "0" && p.Items.Any(x => x.Id == "0"),
            "Se trató la identidad válida 0 como una raíz universal.");
        pasa("La identidad nativa 0 no se trata como raíz si existe como padre local válido");

        ruta = Crear(carpeta, "cero_ausente");
        Titulo(ruta, "TI-LOCAL", null);
        Partida(ruta, "CU-JA", "0", "TI-LOCAL");
        Exige(MYGBaseDatos.LeerProyecto(ruta, "PR-JA").Presupuestos.Single().Items.Single(x => x.Id == "CU-JA").ParentId == "TI-LOCAL",
            "Un 0 inexistente bloqueó el título alternativo válido.");
        pasa("Una referencia 0 inexistente permite resolver el título alternativo explícito");
    }

    private static void Aislamiento(string carpeta, Action<string> pasa)
    {
        string ruta = Crear(carpeta, "ajeno_sin_alternativa");
        Titulo(ruta, "TI-AJENO", null, "PP-JB");
        Partida(ruta, "CU-JA", "TI-AJENO", null);
        RechazaSinEscritura(ruta, "Falta el padre", "Se incorporó un título de otra obra para completar la jerarquía.");
        pasa("Una relación hacia un título de otra obra se rechaza sin importar su información ni modificar SQLite");

        ruta = Crear(carpeta, "ajeno_con_alternativa");
        Titulo(ruta, "TI-AJENO", null, "PP-JB");
        Titulo(ruta, "TI-LOCAL", null);
        Partida(ruta, "CU-JA", "TI-AJENO", "TI-LOCAL");
        string huella = Huella(ruta);
        var p = MYGBaseDatos.LeerProyecto(ruta, "PR-JA").Presupuestos.Single();
        Exige(p.Items.Single(x => x.Id == "CU-JA").ParentId == "TI-LOCAL" &&
            p.Items.All(x => x.Id != "TI-AJENO") && Huella(ruta) == huella,
            "La alternativa local mezcló el título o modificó la obra ajena.");
        Exige(MYGBaseDatos.LeerProyecto(ruta, "PR-JB").Presupuestos.Single().Items.Single().Id == "TI-AJENO",
            "La apertura del proyecto A alteró la jerarquía del proyecto B.");
        pasa("El título alternativo se resuelve dentro del presupuesto y la otra obra conserva su jerarquía");

        ruta = Crear(carpeta, "otro_presupuesto_misma_obra");
        SQL(ruta, "INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto) VALUES('PP-JA2','PR-JA','OTRO PRESUPUESTO',2)");
        Titulo(ruta, "TI-OTRO", null, "PP-JA2");
        Partida(ruta, "CU-JA", null, "TI-OTRO");
        RechazaSinEscritura(ruta, "Falta el padre", "Se mezclaron títulos de presupuestos distintos de la misma obra.");
        pasa("Los títulos de otro presupuesto de la misma obra tampoco completan una jerarquía ajena");
    }

    private static void MarcadoresRaiz(string carpeta, Action<string> pasa)
    {
        foreach (string marcador in new[] { "__ROOT__", "" })
        {
            string ruta = Crear(carpeta, marcador.Length == 0 ? "raiz_vacia" : "raiz_explicita");
            Titulo(ruta, "TI-LOCAL", null);
            Partida(ruta, "CU-JA", marcador, "TI-LOCAL");
            Exige(MYGBaseDatos.LeerProyecto(ruta, "PR-JA").Presupuestos.Single().Items.Single(x => x.Id == "CU-JA").ParentId == "TI-LOCAL",
                "Un marcador de raíz bloqueó el vínculo alternativo de título.");

            SQL(ruta, "UPDATE costo_unitario SET id_titulo=NULL WHERE id_costounitario='CU-JA'");
            Exige(MYGBaseDatos.LeerProyecto(ruta, "PR-JA").Presupuestos.Single().Items.Single(x => x.Id == "CU-JA").ParentId == null,
                "Una partida raíz legítima recibió un padre inventado.");
        }
        pasa("Vacío y __ROOT__ conservan la semántica nativa con título alternativo o como raíces legítimas");
    }

    private static void RelacionesInvalidas(string carpeta, Action<string> pasa)
    {
        string ruta = Crear(carpeta, "huerfano_real");
        Partida(ruta, "CU-JA", "CU-FALTA", "TI-FALTA");
        string huella = Huella(ruta);
        var doc = MYGBaseDatos.LeerProyecto(ruta, "PR-JA");
        var p = doc.Presupuestos.Single();
        var recuperado = p.Items.Single(x => x.Id == "CU-FALTA");
        Exige(p.Items.Single(x => x.Id == "CU-JA").ParentId == "CU-FALTA" &&
            MYGRecuperacionJerarquiaDelphin.EsProvisional(recuperado) &&
            recuperado.ParentId == null && recuperado.IdTituloAusenteDelphin == "CU-FALTA" &&
            Huella(ruta) == huella,
            "La recuperación nativa perdió la referencia original, no se identificó como provisional o escribió SQLite.");
        pasa("Un padre físicamente ausente se representa explícitamente como grupo provisional sin cambiar sus referencias ni escribir SQLite");

        ruta = Crear(carpeta, "ciclo_real");
        Titulo(ruta, "TI-A", "TI-B");
        Titulo(ruta, "TI-B", "TI-A");
        Partida(ruta, "CU-JA", null, "TI-A");
        RechazaSinEscritura(ruta, "Jerarquía circular", "Una cadena de títulos circular se aceptó.");
        pasa("Los ciclos reales en los títulos continúan rechazados");

        ruta = Crear(carpeta, "autopadre_con_alternativa");
        Titulo(ruta, "TI-LOCAL", null);
        Partida(ruta, "CU-JA", "CU-JA", "TI-LOCAL");
        RechazaSinEscritura(ruta, "Jerarquía circular", "El título alternativo ocultó un autopadre existente.");
        pasa("La alternativa no oculta un autopadre existente ni desactiva la validación de ciclos");
    }

    private static string Crear(string carpeta, string nombre)
    {
        string ruta = Path.Combine(carpeta, "Jerarquia_" + nombre + ".sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        SQL(ruta, """
            INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,decimales_costo,decimales_cantidad)
            VALUES('PR-JA','QA-USUARIO','QA-TIPO','PE','OBRA SINTÉTICA A',2,4),
                  ('PR-JB','QA-USUARIO','QA-TIPO','PE','OBRA SINTÉTICA B',2,4);
            INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto)
            VALUES('PP-JA','PR-JA','PRESUPUESTO SINTÉTICO A',1,'01'),
                  ('PP-JB','PR-JB','PRESUPUESTO SINTÉTICO B',1,'01');
            INSERT INTO unidad(id_unidad,descripcion_unidad,abreviatura_unidad)
            VALUES('UN-JA','METRO CUADRADO SINTÉTICO','m²');
            """);
        return ruta;
    }

    private static void Titulo(string ruta, string id, string padre, string presupuesto = "PP-JA", string item = "01", int posicion = 10)
        => SQL(ruta, "INSERT INTO titulo(id_titulo,descripcion_titulo,id_titulopadre,id_presupuesto,numeracion_titulo,posicion_titulo) VALUES($p0,$p1,$p2,$p3,$p4,$p5)",
            id, "TÍTULO SINTÉTICO " + id, padre, presupuesto, item, posicion);

    private static void Partida(string ruta, string id, string padreCosto, string titulo)
        => SQL(ruta, """
            INSERT INTO costo_unitario(id_costounitario,descripcion_costo,id_presupuesto,id_costopadre,id_titulo,
                id_unidad,id_analisiscosto,numeracion_costo,posicion_costo,cantidad,cantidad_metrado,costo_unitario,
                parcial_costo,especificaciones,especificaciones_texto,productividad,magnitud_unidadtiempo)
            VALUES($p0,'PARTIDA SINTÉTICA','PP-JA',$p1,$p2,'UN-JA','AC-JA','01.01.03',1,2.75,2.75,13.37,
                36.77,'ESPECIFICACIÓN SINTÉTICA CONSERVADA','S',1,8)
            """, id, padreCosto, titulo);

    private static void SQL(string ruta, string texto, params object[] valores)
    {
        SQLiteDependencyBootstrapper.Initialize();
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false, ForeignKeys = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = texto;
        for (int n = 0; n < valores.Length; n++) q.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        q.ExecuteNonQuery();
    }

    private static string Relaciones(string ruta)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand();
        q.CommandText = """
            SELECT 'costo:'||id_costounitario,ifnull(id_costopadre,''),ifnull(id_titulo,'') FROM costo_unitario
            UNION ALL SELECT 'titulo:'||id_titulo,ifnull(id_titulopadre,''),ifnull(id_presupuesto,'') FROM titulo
            ORDER BY 1
            """;
        using var r = q.ExecuteReader();
        var valores = new System.Collections.Generic.List<string>();
        while (r.Read()) valores.Add(r.GetString(0) + "|" + r.GetString(1) + "|" + r.GetString(2));
        return string.Join("\n", valores);
    }

    private static void RechazaSinEscritura(string ruta, string mensaje, string detalle)
    {
        string huella = Huella(ruta);
        bool rechazo = false;
        try { MYGBaseDatos.LeerProyecto(ruta, "PR-JA"); }
        catch (InvalidDataException e) when (e.Message.Contains(mensaje, StringComparison.Ordinal)) { rechazo = true; }
        Exige(rechazo && Huella(ruta) == huella, detalle);
    }

    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new InvalidOperationException(detalle); }
}
