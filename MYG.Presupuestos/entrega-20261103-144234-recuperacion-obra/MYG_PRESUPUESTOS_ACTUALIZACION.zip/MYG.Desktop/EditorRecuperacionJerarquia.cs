using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private TableLayoutPanel avisoRecuperacionJerarquia;
    private Label textoRecuperacionJerarquia;
    private Button verGruposRecuperados;
    private TableLayoutPanel contenedorAvisoRecuperacion;
    private bool actualizandoAvisoRecuperacion;
    private sealed record SeleccionTituloRecuperado(string PresupuestoId, string GrupoId);

    private void InicializarAvisoRecuperacionJerarquia(TableLayoutPanel exterior)
    {
        contenedorAvisoRecuperacion = exterior;
        avisoRecuperacionJerarquia = new TableLayoutPanel
        {
            Name = "aviso_recuperacion_jerarquia", Dock = DockStyle.Fill,
            ColumnCount = 2, RowCount = 1, Margin = new(0), Padding = new(8, 4, 8, 4),
            BackColor = MYG2027_TemaComercial.AzulSuave, Visible = false,
            AccessibleName = "Grupos sin título original"
        };
        avisoRecuperacionJerarquia.ColumnStyles.Add(new(SizeType.Percent, 100));
        avisoRecuperacionJerarquia.ColumnStyles.Add(new(SizeType.Absolute, 126));
        avisoRecuperacionJerarquia.RowStyles.Add(new(SizeType.Percent, 100));
        textoRecuperacionJerarquia = new Label
        {
            Name = "detalle_recuperacion_jerarquia", Dock = DockStyle.Fill, Margin = new(0, 0, 8, 0),
            TextAlign = ContentAlignment.MiddleLeft, Font = new("Segoe UI", 9F),
            ForeColor = MYG2027_TemaComercial.Texto, BackColor = Color.Transparent
        };
        verGruposRecuperados = MYGProyectoUI.Boton("Ver grupos");
        verGruposRecuperados.Name = "ver_grupos_recuperados_button";
        verGruposRecuperados.AccessibleName = "Ver grupos sin título original";
        verGruposRecuperados.AccessibleDescription = "Consultar los grupos que necesitan revisar su nombre y ubicación.";
        verGruposRecuperados.Dock = DockStyle.Fill;
        verGruposRecuperados.Margin = new(4, 0, 0, 0);
        verGruposRecuperados.Click += (_, _) =>
        {
            if (!ocupado && !IsDisposed) MostrarGruposRecuperados();
        };
        avisoRecuperacionJerarquia.Controls.Add(textoRecuperacionJerarquia, 0, 0);
        avisoRecuperacionJerarquia.Controls.Add(verGruposRecuperados, 1, 0);
        exterior.Controls.Add(avisoRecuperacionJerarquia, 0, 2);
        exterior.SizeChanged += (_, _) => ActualizarAvisoRecuperacionJerarquia();
        exterior.DpiChangedAfterParent += (_, _) => ActualizarAvisoRecuperacionJerarquia();
    }

    private void ActualizarAvisoRecuperacionJerarquia()
    {
        if (actualizandoAvisoRecuperacion || IsDisposed || avisoRecuperacionJerarquia == null ||
            contenedorAvisoRecuperacion == null || textoRecuperacionJerarquia == null) return;
        actualizandoAvisoRecuperacion = true;
        try
        {
            int cantidad = MYGRecuperacionJerarquiaDelphin.Contar(documento);
            bool visible = cantidad > 0;
            if (!visible)
            {
                if (contenedorAvisoRecuperacion.RowStyles[2].Height != 0)
                    contenedorAvisoRecuperacion.RowStyles[2].Height = 0;
                avisoRecuperacionJerarquia.Visible = false;
                verGruposRecuperados.Enabled = false;
                return;
            }
            textoRecuperacionJerarquia.Text = cantidad == 1
                ? "Hay 1 grupo sin título original. Revise su nombre y ubicación; los totales incluyen sus partidas."
                : $"Hay {cantidad} grupos sin título original. Revise sus nombres y ubicación; los totales incluyen sus partidas.";
            textoRecuperacionJerarquia.AccessibleName = textoRecuperacionJerarquia.Text;
            avisoRecuperacionJerarquia.BackColor = MYG2027_TemaComercial.AzulSuave;
            textoRecuperacionJerarquia.ForeColor = MYG2027_TemaComercial.Texto;
            float escala = contenedorAvisoRecuperacion.DeviceDpi / 96F;
            avisoRecuperacionJerarquia.ColumnStyles[1].Width = (float)Math.Ceiling(126F * escala);
            int anchoTexto = Math.Max(220, contenedorAvisoRecuperacion.ClientSize.Width - (int)Math.Ceiling(160F * escala));
            int altoTexto = TextRenderer.MeasureText(textoRecuperacionJerarquia.Text, textoRecuperacionJerarquia.Font,
                new Size(anchoTexto, int.MaxValue), TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix).Height;
            float alto = Math.Max((float)Math.Ceiling(52F * escala), altoTexto + (float)Math.Ceiling(12F * escala));
            if (contenedorAvisoRecuperacion.RowStyles[2].Height != alto)
                contenedorAvisoRecuperacion.RowStyles[2].Height = alto;
            avisoRecuperacionJerarquia.Visible = visible;
            verGruposRecuperados.Enabled = visible && !ocupado;
        }
        finally { actualizandoAvisoRecuperacion = false; }
    }

    private void MostrarGruposRecuperados()
    {
        if (!documento.Presupuestos.Any(p => p.Items.Any(i => !string.IsNullOrWhiteSpace(i.IdTituloAusenteDelphin))))
        { ActualizarAvisoRecuperacionJerarquia(); return; }
        using var ventana = new Form();
        MYGProyectoUI.Preparar(ventana, "Revisar grupos recuperados", 1060, 570);
        ventana.Name = "grupos_recuperados_dialog";
        var contenido = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3,
            Padding = new(16), Margin = new(0)
        };
        contenido.ColumnStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Absolute, 116));
        contenido.RowStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Absolute, 54));
        contenido.Controls.Add(new Label
        {
            Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = false,
            Text = "La base conserva estas partidas, pero sus títulos originales ya no existen. Se muestran agrupadas para que pueda revisarlas; los totales incluyen sus partidas.\n\n" +
                "Seleccione un grupo y use Definir título para indicar su nombre y ubicación. Después revise los importes y use Guardar en el proyecto. Los nombres originales no se pueden recuperar de esta base.",
            ForeColor = MYG2027_TemaComercial.Texto
        }, 0, 0);
        var tabla = MYGBibliotecaUI.Tabla();
        tabla.Name = "grupos_recuperados_tabla";
        tabla.ReadOnly = true;
        tabla.MultiSelect = false;
        tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        foreach (var columna in new[]
        {
            new DataGridViewTextBoxColumn { Name = "presupuesto", HeaderText = "Presupuesto", FillWeight = 22 },
            new DataGridViewTextBoxColumn { Name = "referencia", HeaderText = "Referencia del grupo", FillWeight = 17 },
            new DataGridViewTextBoxColumn { Name = "grupo", HeaderText = "Nombre del grupo", FillWeight = 30 },
            new DataGridViewTextBoxColumn { Name = "ubicacion", HeaderText = "Ubicación actual", FillWeight = 20 },
            new DataGridViewTextBoxColumn { Name = "estado", HeaderText = "Estado", FillWeight = 11 }
        }) tabla.Columns.Add(columna);
        contenido.Controls.Add(tabla, 0, 1);
        var pieDialogo = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft,
            Padding = new(0, 6, 0, 0), Margin = new(0)
        };
        var cerrar = MYGProyectoUI.Boton("Cerrar");
        cerrar.DialogResult = DialogResult.Cancel;
        cerrar.Width = 112;
        pieDialogo.Controls.Add(cerrar);
        var definir = MYGProyectoUI.Boton("Definir título");
        definir.Name = "definir_titulo_recuperado_button";
        definir.AccessibleName = "Definir nombre y ubicación del título recuperado";
        pieDialogo.Controls.Add(definir);
        void EstadoDefinir()
        {
            definir.Enabled = !ocupado && PuedeModificarProyecto && tabla.CurrentRow?.Tag is SeleccionTituloRecuperado;
        }
        void RecargarLista(SeleccionTituloRecuperado seleccion = null)
        {
            seleccion ??= tabla.CurrentRow?.Tag as SeleccionTituloRecuperado;
            tabla.Rows.Clear();
            foreach (var p in documento.Presupuestos)
                foreach (var grupo in p.Items.Where(i => !string.IsNullOrWhiteSpace(i.IdTituloAusenteDelphin)))
                {
                    var padre = p.Items.FirstOrDefault(i => string.Equals(i.Id, grupo.ParentId, StringComparison.OrdinalIgnoreCase));
                    int indice = tabla.Rows.Add(p.ToString(), grupo.IdTituloAusenteDelphin, grupo.Descripcion,
                        padre?.Descripcion ?? "Nivel principal", MYGRecuperacionJerarquiaDelphin.EsProvisional(grupo) ? "Por definir" : "Definido");
                    var fila = tabla.Rows[indice];
                    fila.Tag = new SeleccionTituloRecuperado(p.Id, grupo.Id);
                    if (seleccion != null && string.Equals(p.Id, seleccion.PresupuestoId, StringComparison.OrdinalIgnoreCase) &&
                        string.Equals(grupo.Id, seleccion.GrupoId, StringComparison.OrdinalIgnoreCase))
                        tabla.CurrentCell = fila.Cells["grupo"];
                }
            EstadoDefinir();
        }
        tabla.SelectionChanged += (_, _) => EstadoDefinir();
        definir.Click += (_, _) =>
        {
            if (tabla.CurrentRow?.Tag is not SeleccionTituloRecuperado seleccion) return;
            try
            {
                if (DefinirTituloRecuperado(ventana, seleccion)) RecargarLista(seleccion);
            }
            catch (Exception error) { MYGProyectoUI.Error(ventana, error); }
        };
        void PermisosActualizados(object sender, EventArgs e) => EstadoDefinir();
        ventana.Activated += PermisosActualizados;
        RecargarLista();
        contenido.Controls.Add(pieDialogo, 0, 2);
        ventana.Controls.Add(contenido);
        ventana.AcceptButton = cerrar;
        ventana.CancelButton = cerrar;
        MYG2027_TemaComercial.Aplicar(ventana);
        Action cambioSesion = () => PermisosActualizados(this, EventArgs.Empty);
        sesion.Cambio += cambioSesion;
        try { ventana.ShowDialog(this); }
        finally { sesion.Cambio -= cambioSesion; }
    }

    private bool DefinirTituloRecuperado(Form propietario, SeleccionTituloRecuperado seleccion)
    {
        ExigirPermisoEdicionProyecto();
        Sincronizar();
        var presupuestoGrupo = documento.Presupuestos.FirstOrDefault(p =>
            string.Equals(p.Id, seleccion.PresupuestoId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("El presupuesto seleccionado ya no existe.");
        var grupo = presupuestoGrupo.Items.FirstOrDefault(i => string.Equals(i.Id, seleccion.GrupoId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("El grupo seleccionado ya no existe.");
        if (string.IsNullOrWhiteSpace(grupo.IdTituloAusenteDelphin))
            throw new InvalidOperationException("Seleccione un grupo recuperado.");
        var noAdmitidos = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { grupo.Id };
        bool cambio;
        do
        {
            cambio = false;
            foreach (var item in presupuestoGrupo.Items)
                if (!string.IsNullOrWhiteSpace(item.ParentId) && noAdmitidos.Contains(item.ParentId) && noAdmitidos.Add(item.Id))
                    cambio = true;
        } while (cambio);
        var opciones = new List<MYGConfiguracionOpcion> { new() { Id = "", Texto = "Nivel principal" } };
        opciones.AddRange(presupuestoGrupo.Items.Where(i => MYGProyectoStorage.EsTitulo(i) && !noAdmitidos.Contains(i.Id))
            .Select(i => new MYGConfiguracionOpcion { Id = i.Id, Texto = i.ToString() }));
        using var ventana = new Form();
        MYGProyectoUI.Preparar(ventana, "Definir título recuperado", 760, 330);
        ventana.Name = "definir_titulo_recuperado_dialog";
        var contenido = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, Padding = new(16)
        };
        contenido.ColumnStyles.Add(new(SizeType.Absolute, 112));
        contenido.ColumnStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Absolute, 78));
        contenido.RowStyles.Add(new(SizeType.Absolute, 48));
        contenido.RowStyles.Add(new(SizeType.Percent, 100));
        contenido.RowStyles.Add(new(SizeType.Absolute, 56));
        var detalle = new Label
        {
            Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft,
            Text = $"Presupuesto: {presupuestoGrupo}\nReferencia: {grupo.IdTituloAusenteDelphin}\n" +
                "Indique el nombre y la ubicación de este grupo. El cambio conserva sus partidas y queda pendiente hasta Guardar."
        };
        contenido.Controls.Add(detalle, 0, 0); contenido.SetColumnSpan(detalle, 2);
        contenido.Controls.Add(new Label { Text = "Nombre", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);
        var nombre = new TextBox
        {
            Name = "titulo_recuperado_nombre", Dock = DockStyle.Fill,
            Text = MYGRecuperacionJerarquiaDelphin.EsProvisional(grupo) ? "" : grupo.Descripcion,
            MaxLength = 255, Margin = new(3, 8, 3, 8)
        };
        contenido.Controls.Add(nombre, 1, 1);
        contenido.Controls.Add(new Label { Text = "Ubicación", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 2);
        var ubicacion = new ComboBox
        {
            Name = "titulo_recuperado_ubicacion", Dock = DockStyle.Top,
            DropDownStyle = ComboBoxStyle.DropDownList, DisplayMember = "Texto", ValueMember = "Id",
            DataSource = opciones, Margin = new(3, 8, 3, 8)
        };
        ubicacion.SelectedValue = grupo.ParentId ?? "";
        if (ubicacion.SelectedIndex < 0) ubicacion.SelectedIndex = 0;
        contenido.Controls.Add(ubicacion, 1, 2);
        var pie = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, Margin = new(0), Padding = new(0, 4, 0, 0)
        };
        var cancelar = MYGProyectoUI.Boton("Cancelar");
        cancelar.DialogResult = DialogResult.Cancel;
        var aplicar = MYGProyectoUI.Boton("Aplicar", 1);
        aplicar.Name = "aplicar_titulo_recuperado_button";
        pie.Controls.Add(cancelar); pie.Controls.Add(aplicar);
        contenido.Controls.Add(pie, 0, 3); contenido.SetColumnSpan(pie, 2);
        ventana.Controls.Add(contenido);
        ventana.AcceptButton = aplicar; ventana.CancelButton = cancelar;
        bool aplicado = false;
        aplicar.Click += (_, _) =>
        {
            try
            {
                ExigirPermisoEdicionProyecto();
                if (ocupado) throw new InvalidOperationException("Espere a que finalice la operación actual.");
                Sincronizar();
                var actual = documento.Presupuestos.Single(p => string.Equals(p.Id, seleccion.PresupuestoId, StringComparison.OrdinalIgnoreCase));
                string descripcion = nombre.Text.Trim();
                string padreId = (ubicacion.SelectedItem as MYGConfiguracionOpcion)?.Id;
                if (string.IsNullOrWhiteSpace(padreId)) padreId = null;
                var prueba = MYGProyectoStorage.Copia(actual);
                MYGRecuperacionJerarquiaDelphin.DefinirTitulo(prueba, seleccion.GrupoId, descripcion, padreId);
                ExigirCambioModulosNube(candidato => MYGRecuperacionJerarquiaDelphin.DefinirTitulo(
                    candidato.Presupuestos.Single(p => string.Equals(p.Id, seleccion.PresupuestoId, StringComparison.OrdinalIgnoreCase)),
                    seleccion.GrupoId, descripcion, padreId));
                var anterior = actual.Items.Single(i => string.Equals(i.Id, seleccion.GrupoId, StringComparison.OrdinalIgnoreCase));
                if (!string.Equals(anterior.Descripcion, descripcion, StringComparison.Ordinal) ||
                    !string.Equals(anterior.ParentId, padreId, StringComparison.OrdinalIgnoreCase))
                {
                    Recordar();
                    MYGRecuperacionJerarquiaDelphin.DefinirTitulo(actual, seleccion.GrupoId, descripcion, padreId);
                    Refrescar();
                    estado.Text = "Título definido. Revise sus partidas e importes y use Guardar para conservar el cambio.";
                    aplicado = true;
                }
                ventana.DialogResult = DialogResult.OK;
            }
            catch (Exception error) { MYGProyectoUI.Error(ventana, error); }
        };
        void PermisosAplicarActualizados(object sender, EventArgs e)
            => aplicar.Enabled = !ocupado && PuedeModificarProyecto;
        ventana.Activated += PermisosAplicarActualizados;
        PermisosAplicarActualizados(this, EventArgs.Empty);
        ventana.Shown += (_, _) => nombre.Focus();
        MYG2027_TemaComercial.Aplicar(ventana);
        Action cambioSesion = () => PermisosAplicarActualizados(this, EventArgs.Empty);
        sesion.Cambio += cambioSesion;
        try { ventana.ShowDialog(propietario); }
        finally { sesion.Cambio -= cambioSesion; }
        return aplicado;
    }
}
