# Guía vigente para el error al abrir una obra

La corrección inicial del lector resolvía referencias alternativas de padre, pero
la base facilitada posteriormente contiene títulos que fueron eliminados y no
tienen ninguna referencia alternativa válida.

La implementación vigente se describe en **CORRECCION_RECUPERACION_OBRA.md**.
Incluye agrupaciones provisionales explícitas, revisión desde MYG y conservación
de las relaciones nativas mientras no se defina un título.

Aplique los archivos completos de esa entrega conservando las actualizaciones
anteriores. No hay SQL que ejecutar ni archivos JSON que editar. La base privada
facilitada para el diagnóstico no forma parte de la descarga pública.
