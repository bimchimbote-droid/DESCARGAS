using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

// Base SQLite con tablas nativas de Delphin y datos BIM complementarios de MYG.
// Las extensiones JSON conservan filtros, metrados y datos BIM. Los proyectos
// Delphin reutilizan sus tablas nativas; las columnas relacionadas son índices.
public static class MYGBaseDatos
{
    private const int VersionEsquema = 4;
    // Revisión observada en la base nativa aportada. Es independiente de MYG v3.
    private const int RevisionDelphinHojaNueva = 20250529;
    public static bool EsRutaSQLite(string ruta) =>
        string.Equals(Path.GetExtension(ruta), ".sqlite", StringComparison.OrdinalIgnoreCase);

    public static string RutaDeProyecto(string ruta) => string.IsNullOrWhiteSpace(ruta)
        ? throw new InvalidOperationException("Guarde primero el proyecto para crear su base de datos.")
        : Path.GetFullPath(EsRutaSQLite(ruta) ? ruta : Path.ChangeExtension(ruta, ".sqlite"));

    internal static SqliteConnection Abrir(string ruta, bool escritura)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("Indique la ruta de la base MYG.");
        ruta = Path.GetFullPath(ruta);
        bool nueva = !File.Exists(ruta) || new FileInfo(ruta).Length == 0;
        if (!escritura && nueva) throw new FileNotFoundException("No existe la base de datos MYG.", ruta);
        if (escritura) Directory.CreateDirectory(Path.GetDirectoryName(ruta));
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = ruta,
            Mode = escritura ? SqliteOpenMode.ReadWriteCreate : SqliteOpenMode.ReadOnly,
            Pooling = false, ForeignKeys = true, DefaultTimeout = 15
        }.ToString());
        try
        {
            c.Open();
            if (nueva && escritura)
            {
                using var t = c.BeginTransaction();
                MYGDelphinFormato.CrearEsquema(c, t);
                // Solo las hojas nuevas registran la revisión Delphin observada para
                // reconocer el esquema inicializado. Sin este marcador, Delphin reintenta migraciones antiguas
                // y encuentra columnas/tablas ya existentes. No se cambia el historial
                // de bases abiertas, importadas ni convertidas desde versiones MYG previas.
                Ejecutar(c, t, """
                    INSERT INTO parametro(id_parametro,valor_parametro,valor_texto)
                    VALUES('last_updated',$p0,'20121102')
                    """, RevisionDelphinHojaNueva);
                MYGDelphinFormato.InicializarAccesoHojaNueva(c, t);
                MYGDelphinFormato.InicializarUnidadesHojaNueva(c, t);
                Ejecutar(c, t, Esquema);
                Ejecutar(c, t, "INSERT INTO myg_info(formato,version) VALUES('MYG_SQLITE',$p0)", VersionEsquema);
                MYGCatalogoUnidades.InicializarHojaNueva(c, t);
                t.Commit();
            }
            if (!TieneTabla(c, null, "myg_info"))
            {
                if (!DelphinImportacionMYG.EsBase(c)) throw new InvalidDataException("No es una base MYG o Delphin compatible.");
                if (!escritura) return c;
                var unidades = DelphinImportacionMYG.ListarUnidades(c);
                using var t = c.BeginTransaction();
                // Las tablas nativas quedan intactas; los datos BIM se añaden en tablas propias.
                Ejecutar(c, t, Esquema);
                Ejecutar(c, t, "INSERT INTO myg_info(formato,version) VALUES('MYG_SQLITE',$p0)", VersionEsquema);
                foreach (var u in unidades)
                    Ejecutar(c, t, "INSERT OR IGNORE INTO catalogo_unidad(id,simbolo,descripcion) VALUES($p0,$p1,$p2)", u.Id, u.Simbolo, u.Descripcion);
                DelphinImportacionMYG.PrepararCatalogosMYG(c, t);
                t.Commit();
                return c;
            }
            int version;
            using (var cmd = c.CreateCommand())
            {
                cmd.CommandText = "SELECT formato,version FROM myg_info";
                using var r = cmd.ExecuteReader();
                if (!r.Read() || r.GetString(0) != "MYG_SQLITE")
                    throw new InvalidDataException("Formato o versión de base MYG no compatible.");
                version = r.GetInt32(1);
                if ((version < 1 || version > VersionEsquema) || r.Read())
                    throw new InvalidDataException("Formato o versión de base MYG no compatible.");
            }
            // La lectura nunca migra ni modifica archivos. La primera escritura
            // renombra las dos tablas anteriores para coexistir con el esquema nativo.
            if (version < 3 && escritura)
            {
                using var t = c.BeginTransaction();
                if (version == 1)
                {
                    Ejecutar(c, t, MYGCatalogoUnidades.Esquema);
                    MYGCatalogoUnidades.Inicializar(c, t);
                }
                Ejecutar(c, t, "ALTER TABLE proyecto RENAME TO myg_proyecto");
                Ejecutar(c, t, "ALTER TABLE presupuesto RENAME TO myg_presupuesto");
                Ejecutar(c, t, "CREATE INDEX IF NOT EXISTS ix_presupuesto_proyecto ON myg_presupuesto(proyecto_id)");
                MYGDelphinFormato.CrearEsquema(c, t);
                Ejecutar(c, t, "UPDATE myg_info SET version=$p0", VersionEsquema);
                MYGDelphinFormato.SincronizarCatalogos(c, t);
                var documentos = new List<MYGProyectoDocumento>();
                using (var cmd = Comando(c, t, "SELECT json_documento FROM myg_proyecto"))
                using (var r = cmd.ExecuteReader())
                    while (r.Read()) documentos.Add(JsonSerializer.Deserialize<MYGProyectoDocumento>(r.GetString(0), MYGProyectoStorage.Opciones));
                foreach (var d in documentos) { MYGProyectoStorage.Validar(d); MYGDelphinFormato.SincronizarProyecto(c, t, d); }
                t.Commit();
            }
            return c;
        }
        catch (SqliteException ex)
        {
            c.Dispose();
            throw new InvalidDataException("No se pudo leer o actualizar esta base SQLite. " +
                "Verifique que sea una base MYG o Delphin 2024 compatible y que no esté dañada.", ex);
        }
        catch { c.Dispose(); throw; }
    }

    internal static SqliteCommand Comando(SqliteConnection c, SqliteTransaction t, string sql, params object[] datos)
    {
        var cmd = c.CreateCommand(); cmd.Transaction = t; cmd.CommandText = sql;
        for (int n = 0; n < datos.Length; n++)
        {
            object valor = datos[n];
            // Decimal se conserva como texto invariante: no se convierte a double.
            if (valor is decimal d) valor = d.ToString(CultureInfo.InvariantCulture);
            cmd.Parameters.AddWithValue("$p" + n, valor ?? DBNull.Value);
        }
        return cmd;
    }
    internal static int Ejecutar(SqliteConnection c, SqliteTransaction t, string sql, params object[] datos)
    { using var cmd = Comando(c, t, sql, datos); return cmd.ExecuteNonQuery(); }
    internal static string Json<T>(T valor) => MYGJsonAlmacenamiento.Serializar(valor);

    public static void CrearBaseVacia(string ruta)
    {
        if (!EsRutaSQLite(ruta)) throw new ArgumentException("La hoja debe guardarse con extensión .sqlite.", nameof(ruta));
        ruta = Path.GetFullPath(ruta);
        Directory.CreateDirectory(Path.GetDirectoryName(ruta));
        // CreateNew protege tanto bases existentes como otros archivos del usuario.
        using (var archivo = new FileStream(ruta, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { }
        try { using var c = Abrir(ruta, true); }
        catch { File.Delete(ruta); throw; }
    }

    internal static bool TieneTabla(SqliteConnection c, SqliteTransaction t, string tabla)
    {
        using var cmd = Comando(c, t, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=$p0", tabla);
        return Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) != 0;
    }
    private static string TablaProyectos(SqliteConnection c) => TieneTabla(c, null, "myg_proyecto") ? "myg_proyecto" : "proyecto";
    private static string TablaPresupuestos(SqliteConnection c) => TieneTabla(c, null, "myg_presupuesto") ? "myg_presupuesto" : "presupuesto";

    public static List<MYGProyectoResumen> ListarProyectos(string ruta)
    {
        using var c = Abrir(ruta, false);
        if (!TieneTabla(c, null, "myg_info")) return DelphinImportacionMYG.ListarProyectos(c);
        using var cmd = Comando(c, null, "SELECT p.id,p.nombre,p.modificado_utc,COUNT(b.id)," +
            "json_extract(p.json_documento,'$.Datos.Propietario'),json_extract(p.json_documento,'$.Datos.TipoObra') FROM " + TablaProyectos(c) +
            " p LEFT JOIN " + TablaPresupuestos(c) + " b ON b.proyecto_id=p.id " +
            "GROUP BY p.id,p.nombre,p.modificado_utc ORDER BY p.modificado_utc DESC,p.nombre COLLATE NOCASE");
        var proyectos = new List<MYGProyectoResumen>();
        using (var r = cmd.ExecuteReader())
            while (r.Read()) proyectos.Add(new MYGProyectoResumen
            {
                Id = r.GetString(0), Nombre = r.GetString(1),
                ModificadoUtc = DateTime.Parse(r.GetString(2), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind),
                CantidadPresupuestos = r.GetInt32(3),
                Propietario = r.IsDBNull(4) ? null : r.GetString(4), TipoObra = r.IsDBNull(5) ? null : r.GetString(5)
            });
        if (TieneTabla(c, null, "myg_proyecto") && DelphinImportacionMYG.EsBase(c))
        {
            var nativosGestionados = proyectos.Select(p => MYGDelphinFormato.IdNativo(p.Id)).ToHashSet(StringComparer.OrdinalIgnoreCase);
            proyectos.AddRange(DelphinImportacionMYG.ListarProyectos(c).Where(p => !nativosGestionados.Contains(p.Id)));
        }
        return proyectos;
    }
    public static MYGProyectoDocumento LeerProyecto(string ruta) => LeerProyecto(ruta, null);
    public static MYGProyectoDocumento LeerProyecto(string ruta, string proyectoId) => LeerProyecto(ruta, proyectoId, null);
    public static MYGProyectoDocumento LeerProyecto(string ruta, string proyectoId, Action<string> informar)
    {
        informar?.Invoke("Localizando el proyecto en la base de datos…");
        if (proyectoId == null)
        {
            var lista = ListarProyectos(ruta);
            if (lista.Count != 1) throw new InvalidDataException(lista.Count == 0
                ? "Esta hoja aún no contiene proyectos. Cree uno desde la ventana principal."
                : "Esta hoja contiene varios proyectos. Seleccione uno desde la ventana principal.");
            proyectoId = lista[0].Id;
        }
        informar?.Invoke("Abriendo la base SQLite y comprobando su formato…");
        using var c = Abrir(ruta, false);
        if (!TieneTabla(c, null, "myg_info")) return DelphinImportacionMYG.LeerProyecto(c, proyectoId, informar: informar);
        informar?.Invoke("Leyendo el proyecto, presupuestos y especificaciones…");
        MYGProyectoDocumento d = null;
        using (var cmd = Comando(c, null, "SELECT id,json_documento FROM " + TablaProyectos(c) + " WHERE id=$p0", proyectoId))
        using (var r = cmd.ExecuteReader())
            if (r.Read())
            {
                d = MYGDocumentoDelphinAlmacenamiento.Leer(c, r.GetString(1));
                if (!string.Equals(r.GetString(0), d?.Id, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("El documento de la base MYG está dañado.");
            }
        if (d == null && TieneTabla(c, null, "myg_proyecto") && DelphinImportacionMYG.EsBase(c))
            return DelphinImportacionMYG.LeerProyecto(c, proyectoId, informar: informar);
        if (d == null) throw new InvalidDataException("El proyecto seleccionado no existe en esta hoja.");
        informar?.Invoke("Recuperando la programación y el cronograma del proyecto…");
        DelphinCronogramaMigracionMYG.ActualizarLectura(c, d);
        informar?.Invoke("Validando presupuestos, partidas y referencias…");
        MYGProyectoStorage.Validar(d); return d;
    }

    public static void GuardarProyecto(string ruta, MYGProyectoDocumento documento, string origenCatalogos = null)
        => GuardarProyectoConMetadatos(ruta, documento, null, origenCatalogos);

    public static void GuardarProyectoSiNoCambio(string ruta, MYGProyectoDocumento documento, string firmaEsperada)
    {
        if (string.IsNullOrWhiteSpace(firmaEsperada)) throw new ArgumentException("Indique la firma de la revisión local.", nameof(firmaEsperada));
        GuardarProyectoConMetadatos(ruta, documento, null, prepararDependencias: (c, t) =>
        {
            // La transacción ya posee el bloqueo de escritura. Otra ventana no
            // puede confirmar cambios entre la comparación y el reemplazo.
            var actual = LeerProyecto(ruta, documento.Id);
            if (!string.Equals(MYGProyectoStorage.Firma(actual), firmaEsperada, StringComparison.Ordinal))
                throw new IOException("La obra cambió localmente durante la sincronización BIM. Se conservó la edición local; vuelva a sincronizar.");
        });
    }

    // El documento y su cola de colaboración comparten conexión y transacción:
    // un error al guardar cualquiera de ellos revierte el guardado completo.
    internal static void GuardarProyectoConMetadatos(string ruta, MYGProyectoDocumento documento,
        Action<SqliteConnection, SqliteTransaction> guardarMetadatos, string origenCatalogos = null,
        Action<SqliteConnection, SqliteTransaction> prepararDependencias = null)
    {
        MYGProyectoStorage.Validar(documento);
        // En hojas Delphin puras, abrir para escritura inicializa extensiones
        // MYG. Rechazar una restauración conflictiva antes de ese primer cambio;
        // la comprobación se repite dentro de la transacción de sincronización.
        if (File.Exists(ruta) && new FileInfo(ruta).Length > 0 &&
            documento.Presupuestos.Any(p => p.Items.Any(i =>
                !string.IsNullOrWhiteSpace(i.IdTituloAusenteDelphin) &&
                !MYGRecuperacionJerarquiaDelphin.EsProvisional(i))))
        {
            using var lectura = Abrir(ruta, false);
            MYGDelphinFormato.ValidarRestauracionTitulos(lectura, null, documento);
        }
        // Guardar como una hoja existente conserva el archivo completo, incluso
        // tablas, adjuntos y relaciones Delphin que aún no representa el editor.
        // Un origen usado sólo como catálogo mantiene la copia de catálogos habitual.
        if (CopiarHojaDeOrigen(ruta, documento, origenCatalogos)) return;
        bool destinoNuevo = !File.Exists(ruta) || new FileInfo(ruta).Length == 0;
        using var c = Abrir(ruta, true);
        bool reduccionImportante = false;
        using (var t = c.BeginTransaction())
        {
            long bytesAnteriores;
            using (var anterior = Comando(c, t, "SELECT length(CAST(json_documento AS BLOB)) FROM myg_proyecto WHERE id=$p0", documento.Id))
                bytesAnteriores = Convert.ToInt64(anterior.ExecuteScalar() ?? 0, CultureInfo.InvariantCulture);
            // v3 ya usa los nombres nativos. Sólo elevar la versión junto al
            // guardado que adopta v4; un fallo conserva también el marcador v3.
            Ejecutar(c, t, "UPDATE myg_info SET version=$p0", VersionEsquema);
            prepararDependencias?.Invoke(c, t);
            // Los identificadores de presupuesto son globales en la hoja. Un documento
            // copiado con identidades ajenas debe guardarse como proyecto independiente.
            foreach (var p in documento.Presupuestos)
            {
                using var cmd = Comando(c, t, "SELECT proyecto_id FROM myg_presupuesto WHERE id=$p0", p.Id);
                string anterior = cmd.ExecuteScalar() as string;
                if (anterior != null && !string.Equals(anterior, documento.Id, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Un presupuesto de este documento pertenece a otro proyecto de la hoja.");
            }
            if (!string.IsNullOrWhiteSpace(origenCatalogos) &&
                !string.Equals(Path.GetFullPath(origenCatalogos), Path.GetFullPath(ruta), StringComparison.OrdinalIgnoreCase))
            {
                CopiarCatalogos(c, t, origenCatalogos, destinoNuevo);
                MYGDelphinFormato.SincronizarCatalogos(c, t);
            }
            // Se reemplazan únicamente los presupuestos del proyecto guardado.
            Ejecutar(c, t, "DELETE FROM myg_presupuesto WHERE proyecto_id=$p0", documento.Id);
            Ejecutar(c, t, "INSERT INTO myg_proyecto(id,nombre,json_documento,modificado_utc) VALUES($p0,$p1,$p2,$p3) " +
                "ON CONFLICT(id) DO UPDATE SET nombre=excluded.nombre,json_documento=excluded.json_documento,modificado_utc=excluded.modificado_utc",
                documento.Id, documento.Nombre, "{}", documento.ModificadoUtc.ToString("O"));
            foreach (var p in documento.Presupuestos)
            {
                Ejecutar(c, t, "INSERT INTO myg_presupuesto(id,proyecto_id,codigo,nombre,posicion,json_datos) VALUES($p0,$p1,$p2,$p3,$p4,$p5)",
                    p.Id, documento.Id, p.Item, p.Nombre, p.Posicion, "{}");
                foreach (var i in p.Costos.Insumos)
                    Ejecutar(c, t, "INSERT INTO insumo_presupuesto(presupuesto_id,id,codigo,descripcion,unidad,grupo,precio,json_datos) " +
                        "VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7)", p.Id, i.Id, i.Codigo, i.Descripcion, i.Unidad, i.Grupo.ToString(), i.Precio, "{}");
                foreach (var i in p.Items)
                    Ejecutar(c, t, "INSERT INTO partida_presupuesto(presupuesto_id,id,id_local,padre_id,item,descripcion,unidad,tipo,posicion,cantidad,precio_directo,json_datos) " +
                        "VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11)",
                        p.Id, i.Id, i.IdLocalMYG, i.ParentId, i.Item, i.Descripcion, i.Unidad, i.TipoPropuesta, i.Posicion, i.Costos.Cantidad, i.Costos.PrecioDirecto, "{}");
                foreach (var i in p.Items)
                    foreach (var r in i.Costos.Analisis)
                        Ejecutar(c, t, "INSERT INTO recurso_presupuesto(presupuesto_id,partida_id,id,grupo,insumo_id,subpartida_local,modo,numero_recursos,cantidad,desperdicio) " +
                            "VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9)", p.Id, i.Id, r.Id, r.Grupo.ToString(),
                            r.Grupo == MYGGrupoRecurso.Subpartidas ? null : r.InsumoId,
                            r.Grupo == MYGGrupoRecurso.Subpartidas ? r.SubpartidaIdLocal : null,
                            r.Modo.ToString(), r.NumeroRecursos, r.Cantidad, r.DesperdicioPorcentaje);
            }
            MYGCatalogoUnidades.RegistrarUsadas(c, t);
            MYGDelphinFormato.SincronizarProyecto(c, t, documento);
            // Calcular las extensiones contra los datos nativos YA sincronizados,
            // siempre en la misma transacción. Los índices no repiten el documento.
            string extensiones = MYGDocumentoDelphinAlmacenamiento.Serializar(c, t, documento);
            reduccionImportante = bytesAnteriores - Encoding.UTF8.GetByteCount(extensiones) >= 256L * 1024;
            Ejecutar(c, t, "UPDATE myg_proyecto SET json_documento=$p1 WHERE id=$p0", documento.Id, extensiones);
            if (guardarMetadatos != null) guardarMetadatos(c, t);
            else MYGColaboracionLocal.GuardarDocumentoVinculado(c, t, documento);
            t.Commit();
        }
        // La recuperación no participa en la transacción de documento/cola.
        // Un bloqueo al compactar no invalida el guardado ya confirmado.
        MYGRecuperacionTamanoSQLite.Intentar(c, reduccionImportante);
    }

    private static bool CopiarHojaDeOrigen(string ruta, MYGProyectoDocumento documento, string origen)
    {
        if (string.IsNullOrWhiteSpace(origen)) return false;
        ruta = Path.GetFullPath(ruta); origen = Path.GetFullPath(origen);
        if (string.Equals(ruta, origen, StringComparison.OrdinalIgnoreCase) ||
            (File.Exists(ruta) && new FileInfo(ruta).Length != 0)) return false;
        using var fuente = Abrir(origen, false);
        bool pertenece = false;
        if (TieneTabla(fuente, null, "myg_proyecto"))
        {
            using var cmd = Comando(fuente, null, "SELECT 1 FROM myg_proyecto WHERE id=$p0", documento.Id);
            pertenece = cmd.ExecuteScalar() != null;
        }
        else if (TieneTabla(fuente, null, "myg_info"))
        {
            using var cmd = Comando(fuente, null, "SELECT 1 FROM proyecto WHERE id=$p0", documento.Id);
            pertenece = cmd.ExecuteScalar() != null;
        }
        if (!pertenece && DelphinImportacionMYG.EsBase(fuente))
        {
            using var cmd = Comando(fuente, null, "SELECT 1 FROM proyecto WHERE id_proyecto=$p0", MYGDelphinFormato.IdNativo(documento.Id));
            pertenece = cmd.ExecuteScalar() != null;
        }
        if (!pertenece) return false;

        Directory.CreateDirectory(Path.GetDirectoryName(ruta));
        string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            // SQLite Backup incluye cambios confirmados en WAL y ofrece una
            // instantánea consistente, sin escribir ni migrar la hoja original.
            using (var salida = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = temporal, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false }.ToString()))
            {
                salida.Open();
                fuente.BackupDatabase(salida);
            }
            // Una hoja guardada como copia independiente conserva los datos de
            // obra y catálogos, pero nunca hereda identidades ni colas de nube.
            GuardarProyectoConMetadatos(temporal, documento, (c, t) =>
                Ejecutar(c, t, "DROP TABLE IF EXISTS myg_colaboracion_local"));
            bool destinoExiste = File.Exists(ruta);
            if (destinoExiste && new FileInfo(ruta).Length != 0)
                throw new IOException("El destino ya contiene datos. Elija un archivo SQLite nuevo para Guardar como.");
            File.Move(temporal, ruta, destinoExiste);
            return true;
        }
        finally
        {
            if (File.Exists(temporal)) File.Delete(temporal);
            foreach (string sufijo in new[] { "-wal", "-shm", "-journal" })
                if (File.Exists(temporal + sufijo)) File.Delete(temporal + sufijo);
        }
    }

    // Abrir un JSON antiguo crea la base auxiliar una sola vez. Abrir una SQLite
    // existente sólo la valida; no guarda los cambios pendientes del editor.
    public static string AsegurarParaProyecto(string archivo, MYGProyectoDocumento d)
    {
        string ruta = RutaDeProyecto(archivo);
        if (!File.Exists(ruta) || new FileInfo(ruta).Length == 0) GuardarProyecto(ruta, d);
        else
        {
            var proyectos = ListarProyectos(ruta);
            if (proyectos.Count != 0 && !proyectos.Any(p => string.Equals(p.Id, d.Id, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException("El proyecto seleccionado no pertenece a esta base SQLite.");
        }
        return ruta;
    }

    private static void CopiarCatalogos(SqliteConnection salida, SqliteTransaction t, string origen, bool destinoNuevo)
    {
        using var fuente = Abrir(origen, false);
        using var lectura = fuente.BeginTransaction(deferred: true);
        MYGCatalogoUnidades.Copiar(fuente, lectura, salida, t, destinoNuevo);
        if (!TieneTabla(fuente, lectura, "catalogo_partida"))
        { DelphinImportacionMYG.PrepararCatalogosMYG(salida, t, fuente); return; }
        // Guardar como conserva los catálogos, incluso entradas no usadas por el presupuesto.
        foreach (string tabla in new[] { "catalogo_partida", "catalogo_insumo", "catalogo_partida_nodo", "catalogo_partida_insumo", "catalogo_partida_recurso" })
        {
            using var leer = Comando(fuente, lectura, "SELECT * FROM " + tabla);
            using var r = leer.ExecuteReader();
            while (r.Read())
            {
                var valores = new object[r.FieldCount]; r.GetValues(valores);
                var parametros = new string[r.FieldCount];
                for (int n = 0; n < parametros.Length; n++) parametros[n] = "$p" + n;
                Ejecutar(salida, t, "INSERT INTO " + tabla + " VALUES(" + string.Join(",", parametros) + ")", valores);
            }
        }
    }

    internal const string Esquema = """
        CREATE TABLE myg_info(formato TEXT NOT NULL,version INTEGER NOT NULL);
        CREATE TABLE myg_proyecto(id TEXT PRIMARY KEY COLLATE NOCASE,nombre TEXT NOT NULL,json_documento TEXT NOT NULL,modificado_utc TEXT NOT NULL);
        CREATE TABLE myg_presupuesto(id TEXT PRIMARY KEY COLLATE NOCASE,proyecto_id TEXT NOT NULL REFERENCES myg_proyecto(id),codigo TEXT,nombre TEXT NOT NULL,posicion INTEGER NOT NULL,json_datos TEXT NOT NULL);
        CREATE TABLE partida_presupuesto(
            presupuesto_id TEXT NOT NULL REFERENCES myg_presupuesto(id) ON DELETE CASCADE,id TEXT NOT NULL COLLATE NOCASE,id_local TEXT NOT NULL COLLATE NOCASE,
            padre_id TEXT COLLATE NOCASE,item TEXT,descripcion TEXT,unidad TEXT,tipo TEXT NOT NULL,posicion INTEGER NOT NULL,cantidad TEXT NOT NULL,precio_directo TEXT NOT NULL,json_datos TEXT NOT NULL,
            PRIMARY KEY(presupuesto_id,id),UNIQUE(presupuesto_id,id_local),
            FOREIGN KEY(presupuesto_id,padre_id) REFERENCES partida_presupuesto(presupuesto_id,id) DEFERRABLE INITIALLY DEFERRED);
        CREATE TABLE insumo_presupuesto(presupuesto_id TEXT NOT NULL REFERENCES myg_presupuesto(id) ON DELETE CASCADE,id TEXT NOT NULL COLLATE NOCASE,codigo TEXT,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,grupo TEXT NOT NULL,precio TEXT NOT NULL,json_datos TEXT NOT NULL,PRIMARY KEY(presupuesto_id,id));
        CREATE TABLE recurso_presupuesto(
            presupuesto_id TEXT NOT NULL,partida_id TEXT NOT NULL,id TEXT NOT NULL,grupo TEXT NOT NULL,insumo_id TEXT,subpartida_local TEXT,
            modo TEXT NOT NULL,numero_recursos TEXT NOT NULL,cantidad TEXT NOT NULL,desperdicio TEXT NOT NULL,PRIMARY KEY(presupuesto_id,partida_id,id),
            FOREIGN KEY(presupuesto_id,partida_id) REFERENCES partida_presupuesto(presupuesto_id,id) ON DELETE CASCADE,
            FOREIGN KEY(presupuesto_id,insumo_id) REFERENCES insumo_presupuesto(presupuesto_id,id) DEFERRABLE INITIALLY DEFERRED,
            FOREIGN KEY(presupuesto_id,subpartida_local) REFERENCES partida_presupuesto(presupuesto_id,id_local) DEFERRABLE INITIALLY DEFERRED);
        CREATE TABLE catalogo_partida(id TEXT PRIMARY KEY COLLATE NOCASE,codigo TEXT NOT NULL COLLATE NOCASE UNIQUE,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,precio TEXT NOT NULL,json_plantilla TEXT NOT NULL,revision INTEGER NOT NULL,modificado_utc TEXT NOT NULL);
        CREATE TABLE catalogo_insumo(id TEXT PRIMARY KEY COLLATE NOCASE,codigo TEXT NOT NULL COLLATE NOCASE UNIQUE,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,grupo TEXT NOT NULL,precio TEXT NOT NULL,json_datos TEXT NOT NULL,revision INTEGER NOT NULL,modificado_utc TEXT NOT NULL);
        CREATE TABLE catalogo_partida_nodo(catalogo_id TEXT NOT NULL REFERENCES catalogo_partida(id) ON DELETE CASCADE,id_local TEXT NOT NULL,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,es_raiz INTEGER NOT NULL,rendimiento TEXT NOT NULL,jornada TEXT NOT NULL,precio_directo TEXT NOT NULL,json_datos TEXT NOT NULL,PRIMARY KEY(catalogo_id,id_local));
        CREATE TABLE catalogo_partida_insumo(catalogo_id TEXT NOT NULL REFERENCES catalogo_partida(id) ON DELETE CASCADE,id TEXT NOT NULL,codigo TEXT,descripcion TEXT NOT NULL,unidad TEXT NOT NULL,grupo TEXT NOT NULL,precio TEXT NOT NULL,PRIMARY KEY(catalogo_id,id));
        CREATE TABLE catalogo_partida_recurso(catalogo_id TEXT NOT NULL,nodo_local TEXT NOT NULL,id TEXT NOT NULL,grupo TEXT NOT NULL,insumo_id TEXT,subpartida_local TEXT,modo TEXT NOT NULL,numero_recursos TEXT NOT NULL,cantidad TEXT NOT NULL,desperdicio TEXT NOT NULL,PRIMARY KEY(catalogo_id,nodo_local,id),
            FOREIGN KEY(catalogo_id,nodo_local) REFERENCES catalogo_partida_nodo(catalogo_id,id_local) ON DELETE CASCADE,
            FOREIGN KEY(catalogo_id,insumo_id) REFERENCES catalogo_partida_insumo(catalogo_id,id) DEFERRABLE INITIALLY DEFERRED,
            FOREIGN KEY(catalogo_id,subpartida_local) REFERENCES catalogo_partida_nodo(catalogo_id,id_local) DEFERRABLE INITIALLY DEFERRED);
        CREATE TABLE catalogo_unidad(id TEXT PRIMARY KEY COLLATE NOCASE,simbolo TEXT NOT NULL COLLATE NOCASE,descripcion TEXT NOT NULL);
        CREATE INDEX ix_presupuesto_proyecto ON myg_presupuesto(proyecto_id);
        CREATE INDEX ix_partida_padre ON partida_presupuesto(presupuesto_id,padre_id);
        CREATE INDEX ix_catalogo_partida_descripcion ON catalogo_partida(descripcion);
        CREATE INDEX ix_catalogo_insumo_descripcion ON catalogo_insumo(descripcion);
        """;
}

public sealed class MYGProyectoResumen
{
    public string Id { get; set; }
    public string Nombre { get; set; }
    public string Propietario { get; set; }
    public string TipoObra { get; set; }
    public DateTime ModificadoUtc { get; set; }
    public int CantidadPresupuestos { get; set; }
    public override string ToString() => Nombre;
}
