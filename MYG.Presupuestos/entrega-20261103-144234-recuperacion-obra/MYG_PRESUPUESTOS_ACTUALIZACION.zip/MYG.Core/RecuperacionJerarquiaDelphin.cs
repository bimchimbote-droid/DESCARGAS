using System;
using System.Linq;

namespace MYG_2027;

// Representación explícita de una relación nativa cuyo título ya no existe.
// Conserva las identidades y los hijos; no deduce nombres ni ubicación a partir
// de la numeración, y no cambia las reglas de validación de los documentos MYG.
public static class MYGRecuperacionJerarquiaDelphin
{
    public static string DescripcionTitulo(string id) => "TÍTULO ORIGINAL AUSENTE [" + id + "]";

    // Al asignar expresamente otro nombre al grupo se deja de presentar como
    // provisional. El identificador se conserva como historial de su origen.
    public static bool EsProvisional(ItemPresupuestoDelphin item) =>
        MYGProyectoStorage.EsTitulo(item) && !string.IsNullOrWhiteSpace(item.IdTituloAusenteDelphin) &&
        string.Equals(item.Descripcion?.Trim(), DescripcionTitulo(item.IdTituloAusenteDelphin), StringComparison.Ordinal);

    public static int Contar(MYGProyectoDocumento documento) =>
        documento?.Presupuestos?.Sum(p => p?.Items?.Count(EsProvisional) ?? 0) ?? 0;

    public static void DefinirTitulo(MYGPresupuestoDocumento presupuesto, string grupoId,
        string descripcion, string padreId = null)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        var original = presupuesto.Items?.FirstOrDefault(i => i != null &&
            string.Equals(i.Id, grupoId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("El grupo ya no pertenece a este presupuesto.");
        if (!MYGProyectoStorage.EsTitulo(original) || string.IsNullOrWhiteSpace(original.IdTituloAusenteDelphin))
            throw new InvalidOperationException("Seleccione un título recuperado de este presupuesto.");
        descripcion = descripcion?.Trim();
        if (string.IsNullOrWhiteSpace(descripcion) || string.Equals(descripcion,
            DescripcionTitulo(original.IdTituloAusenteDelphin), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Escriba el nombre que desea asignar al título recuperado.");

        var copia = MYGProyectoStorage.Copia(presupuesto);
        var grupo = copia.Items.Single(i => string.Equals(i.Id, original.Id, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(padreId))
        {
            var padre = copia.Items.FirstOrDefault(i =>
                string.Equals(i.Id, padreId, StringComparison.OrdinalIgnoreCase));
            if (!MYGProyectoStorage.EsTitulo(padre))
                throw new InvalidOperationException("La ubicación debe ser un título del mismo presupuesto.");
            padreId = padre.Id;
        }
        else padreId = null;
        grupo.Descripcion = descripcion;
        grupo.ParentId = padreId;
        // Toda la propuesta se valida sobre la copia. Una ubicación circular
        // u otro problema no deja cambios parciales en el documento original.
        MYGProyectoStorage.ValidarPresupuesto(copia);
        original.Descripcion = descripcion;
        original.ParentId = padreId;
    }

    internal static ItemPresupuestoDelphin CrearTitulo(string id, int posicion) => new()
    {
        Id = id,
        IdInternoDelphin = id,
        IdLocalMYG = "DELPHIN-LOCAL-" + id,
        IdTituloAusenteDelphin = id,
        ParentId = null,
        Item = null,
        Descripcion = DescripcionTitulo(id),
        Unidad = "",
        Posicion = posicion,
        TipoPropuesta = "TITULO",
        Origen = "DELPHIN",
        Estado = "OFICIAL"
    };
}
