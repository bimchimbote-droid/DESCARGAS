# Abrir obras con títulos originales ausentes

## A. Resumen de la implementación

La muestra facilitada permitió reproducir el mensaje «Falta el padre de …» con
el código real de MYG. Una obra abre normalmente; la otra conserva referencias
a diez títulos que ya no existen en las tablas nativas. No hay un título
alternativo que el lector pueda utilizar. Sus ramas reúnen 227 elementos,
incluidas partidas y subtítulos. La integridad física de SQLite es correcta.

Sin un respaldo anterior no se pueden recuperar los nombres ni la ubicación
originales de esos títulos. MYG presenta cada referencia ausente como un grupo
provisional llamado TÍTULO ORIGINAL AUSENTE [referencia]. Conserva su identidad
y los vínculos de sus hijos. Los grupos se muestran en el nivel principal;
no se deduce su ubicación a partir de códigos o de otras obras.

Los 541 registros nativos del presupuesto afectado permanecen disponibles y se
añaden diez agrupaciones provisionales. Las partidas de estas ramas participan
en los totales mostrados: revise la estructura y los importes antes de emitir
un presupuesto. Un aviso visible y el botón Ver grupos explican la situación.

La lectura no modifica el archivo. Guardar mientras un grupo sigue provisional
conserva su ausencia y sus relaciones nativas; los índices y extensiones MYG
registran la representación que permite reabrirlo. Al definir expresamente su
nombre y ubicación y guardar, se reconstruye ese título nativo con su identidad.

## B. Archivos completos y acciones

Aplicar sobre las entregas anteriores, incluida la corrección del lector
publicada en DESCARGAS, commit 8f8cd825f00712212d3abbba8959ecbb5f0ccb13.

| N.º | Ruta exacta | Acción | Descripción |
| --- | --- | --- | --- |
| 1 | MYG.Core/Modelos.cs | REEMPLAZAR | Identifica los grupos cuyo título original estaba ausente. |
| 2 | MYG.Core/RecuperacionJerarquiaDelphin.cs | CREAR | Describe, cuenta y permite definir los títulos recuperados. |
| 3 | MYG.Core/DelphinImportacionMYG.cs | REEMPLAZAR | Abre las ramas afectadas en grupos explícitos, conservando sus referencias. |
| 4 | MYG.Core/DelphinFormatoMYG.cs | REEMPLAZAR | Conserva las relaciones nativas y distingue grupos provisionales de títulos definidos. |
| 5 | MYG.Core/BaseDatosMYG.cs | REEMPLAZAR | Comprueba la restauración antes de modificar una base nativa existente. |
| 6 | MYG.Desktop/EditorForm.cs | REEMPLAZAR | Actualiza el aviso al editar o recargar el documento. |
| 7 | MYG.Desktop/EditorPresupuestos.cs | REEMPLAZAR | Incorpora el espacio del aviso en la interfaz. |
| 8 | MYG.Desktop/EditorRecuperacionJerarquia.cs | CREAR | Lista los grupos y ofrece Definir título con nombre y ubicación. |
| 9 | MYG.Pruebas/JerarquiaDelphinCheck.cs | REEMPLAZAR | Mantiene las comprobaciones de referencias alternativas y aislamiento. |
| 10 | MYG.Pruebas/RecuperacionJerarquiaDelphinCheck.cs | CREAR | Prueba recuperación, guardado, definición y conservación sobre SQLite sintética. |
| 11 | MYG.Pruebas/Program.cs | REEMPLAZAR | Integra las pruebas y su selector. |
| 12 | MYG.PruebasNube/TitulosNativosCheck.cs | REEMPLAZAR | Comprueba que la nube conserva los grupos provisionales y sus datos. |
| 13 | CORRECCION_ABRIR_OBRA.md | REEMPLAZAR | Remite a esta guía vigente tras revisar la muestra real. |
| 14 | CORRECCION_RECUPERACION_OBRA.md | CREAR | Esta guía de aplicación y validación. |

## C. Descarga

La respuesta de entrega incluye MYG_PRESUPUESTOS_ACTUALIZACION.zip en una carpeta
nueva del repositorio público independiente bimchimbote-droid/DESCARGAS, con
enlace fijado al commit de publicación. Se verifica el ZIP por descarga, igualdad
de bytes, SHA-256, integridad y contenido exacto. La base privada y sus datos no
se incluyen en el ZIP.

## D. Instrucciones para instalar y utilizar los cambios

1. Cierre MYG, Revit y Visual Studio. Respalde sus cambios locales antes de
   sustituir archivos. Conserve una copia del SQLite original.
2. Extraiga el ZIP dentro de la carpeta que contiene MYG.Presupuestos.sln, por
   ejemplo D:\ADDIN\repos\MYG.Presupuestos_GITHUB. Mantenga las subcarpetas y
   acepte reemplazar los archivos de la tabla.
3. Program.cs en esta entrega pertenece a MYG.Pruebas; no lo copie en Desktop.
4. Abra la solución, restaure NuGet y seleccione Release / x64. Ejecute
   Compilar > Limpiar solución y Compilar > Recompilar solución.
5. Ejecute la versión recién compilada y abra su base habitual. La obra afectada
   debe presentar sus partidas bajo grupos TÍTULO ORIGINAL AUSENTE y mostrar
   el aviso de revisión.
6. Pulse Ver grupos. Para restaurar una agrupación, selecciónela y pulse
   Definir título. Escriba un nombre elegido por usted y seleccione el título
   padre del mismo presupuesto o Nivel principal. Se comprueban los ciclos y
   los destinos inválidos antes de aplicar el cambio.
7. Revise la ubicación, las partidas y los importes. Use Guardar cuando decida
   conservar sus cambios. Definir título necesita el permiso de edición habitual;
   consultar la lista no concede permisos adicionales.

El nombre definido es una decisión del usuario: no significa que el software
haya recuperado el nombre borrado. Puede seguir revisando una obra conservando
los grupos provisionales; guardar así no crea sus títulos en las tablas nativas.

## E. Configuraciones adicionales

No hay SQL que ejecutar, migraciones ni JSON que editar. No necesita reemplazar
su base por otra ni cambiar Supabase, dominio o alojamiento. Los proyectos SDK
incluyen automáticamente los nuevos archivos .cs.

Los únicos archivos que no son .cs en esta entrega son las dos guías .md.
Guárdelas junto a la solución y léalas; no se ejecutan ni se cargan en una base.

Mientras un título continúe provisional, sus referencias originales seguirán
ausentes para un lector Delphin externo que no utilice las extensiones de MYG.
La corrección permite trabajar en MYG conservando los datos; para reconstruir
ese título nativo debe definirlo expresamente y guardar.

## F. Compilación y validación

Tecnologías: SDK .NET 10.0.100, C#, Microsoft.Data.Sqlite 10, SQLite real,
Desktop net10.0-windows y referencias de Revit 2027.

```powershell
dotnet restore MYG.Presupuestos.sln -p:Platform=x64 -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:Platform=x64 -p:UseRevitReferencePackages=true --no-restore -m:1
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release -- --recuperacion-jerarquia-delphin
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release -- --jerarquia-delphin
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build
```

UseRevitReferencePackages=true comprueba la compilación con las referencias
NuGet oficiales sin necesitar Revit instalado. Visual Studio puede seguir usando
su instalación habitual de Revit 2027.

Resultados ejecutados:

- Solución completa Release/x64: cero errores y cero advertencias.
- Suite general de Core: 839 comprobaciones aprobadas, incluidas las 15 nuevas
  de recuperación y las 14 anteriores de jerarquía. Seis comprobaciones requieren
  muestras externas adicionales o Named Pipes de Windows y se omitieron.
- Títulos y paquetes de nube: 24 comprobaciones aprobadas, incluidas siete nuevas
  sobre grupos provisionales, formato compacto, firmas, descarga y reapertura.
- Muestra real: abren las dos obras y sus ocho presupuestos; se conservan las
  3.304 filas activas, con sus identidades, referencias, numeración, posición,
  unidad, cantidad, precios, parciales importados y especificaciones.
- La huella SHA-256 del archivo original no cambia después de la lectura.
- Guardar sin editar, exclusivamente en una copia local de diagnóstico, mantiene
  idénticas las 199 tablas nativas originales, incluidos los BLOB: siguen existiendo
  5.463 costos y 335 títulos nativos, sin crear los diez grupos provisionales.
- En otra copia, definir un grupo y guardar añade exactamente un título nativo
  con el mismo identificador; quedan nueve grupos provisionales. Se conservan las
  filas antiguas de costos, los títulos y las tablas de ACU. Los totales nativos de
  presupuesto/proyecto se recalculan como corresponde a una edición explícita.
- La otra obra conserva sus métricas en la lectura y en ambas pruebas de guardado.

Las pruebas de escritura se realizaron sobre copias privadas de diagnóstico.
La respuesta final confirma además la compilación del ZIP aplicado y su descarga.

No se ejecuta la interfaz Windows ni Revit en este entorno. Compruebe en su PC
el aviso, la lista y la definición de títulos tras instalar la actualización.

## G. Publicación del código en GitHub

La sesión publica únicamente el ZIP autorizado en DESCARGAS, conservando las
entregas anteriores. No hace Push al repositorio del código. Después de comprobar
la actualización, revise Cambios de Git en Visual Studio, verifique la rama main,
haga Commit y luego Push cuando decida publicarla.

## H. Límites y comprobaciones pendientes

La recuperación conserva la información que existe; no puede reproducir nombres
o ubicaciones que fueron borrados y no tienen respaldo. Los grupos provisionales
deben revisarse antes de utilizar el presupuesto como documento definitivo.

Una referencia a un padre existente en otra obra o presupuesto sigue siendo
inválida: no se incorporan sus datos para completar esta obra. También siguen
rechazándose ciclos y documentos MYG con jerarquía inválida ajenos al adaptador.

Esta actualización conserva las correcciones anteriores de colaboración,
publicación y compilación. Base del código: main, commit
df8392a5d2910216a097349add3d20ba6103bdf5, más las entregas anteriores de la sesión.
Compare antes de reemplazar si modificó después alguno de los archivos afectados.
