using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGGraficoIncidencia : UserControl
{
    // Conserva los datos calculados y el contrato de las comprobaciones de apertura.
    private List<MYGIncidenciaCosto> datos = new();
    private string moneda = "S/", error;
    private MYGConfiguracionGraficoIncidencia configuracion = new();
    private readonly ToolTip ayuda = new();
    private readonly List<(Region Area, MYGIncidenciaCosto Valor)> regiones = new();
    private Point? arrastre;
    private int anguloInicial, inclinacionInicial;
    private string errorPreferencias;
    private static string RutaPreferencias => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "grafico-incidencia.json");

    internal MYGGraficoIncidencia()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = MYG2027_TemaComercial.Superficie; ForeColor = MYG2027_TemaComercial.Texto;
        Font = new Font("Segoe UI", 8); MinimumSize = new Size(120, 100);
        AccessibleName = "Gráfico de incidencia de costos";
        try { if (File.Exists(RutaPreferencias)) configuracion = MYGConfiguracionGraficoIncidencia.DesdeJson(File.ReadAllText(RutaPreferencias)); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Text.Json.JsonException or InvalidDataException)
        { errorPreferencias = "No se pudo leer la configuración guardada: " + ex.Message; }
        PrepararHerramientas(); ActualizarHerramientas();
        MYGTamanoTextoUI.CambioTamano += CambiarTamanoTexto;
        DpiChangedAfterParent += CambiarTamanoTexto;
    }

    internal MYGConfiguracionGraficoIncidencia Configuracion => configuracion.Copia();
    internal void Configurar(MYGConfiguracionGraficoIncidencia valor)
    {
        ArgumentNullException.ThrowIfNull(valor);
        var copia = valor.Copia(); configuracion = copia;
        LimpiarResaltado(); LimpiarRegiones(); columnasInteractivas.Clear();
        ActualizarHerramientas(); GuardarPreferencias(); Invalidate();
    }
    private void GuardarPreferencias()
    {
        string temporal = RutaPreferencias + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(RutaPreferencias));
            File.WriteAllText(temporal, configuracion.AJson()); File.Move(temporal, RutaPreferencias, true);
            errorPreferencias = null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        { errorPreferencias = "No se pudo guardar la configuración del gráfico: " + ex.Message; }
        finally { try { if (File.Exists(temporal)) File.Delete(temporal); } catch (IOException) { } }
    }
    internal void Actualizar(List<MYGIncidenciaCosto> valores, string simbolo, string problema = null)
    {
        datos = valores?.Select(d => new MYGIncidenciaCosto { Nombre = d.Nombre, Importe = d.Importe, Porcentaje = d.Porcentaje }).ToList() ?? new();
        moneda = simbolo ?? ""; error = problema;
        LimpiarResaltado(); LimpiarRegiones(); columnasInteractivas.Clear(); Invalidate();
    }
    private int AnchoBarra => barraGrafico?.Visible == true ? barraGrafico.Width : 0;
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e); LimpiarRegiones();
        Dibujar(e.Graphics, new Rectangle(AnchoBarra, 0, Math.Max(1, Width - AnchoBarra), Height), DeviceDpi / 96F, true);
    }
    internal Bitmap CrearImagen(int ancho = 1200, int alto = 800)
    {
        if (ancho < 120 || alto < 100 || ancho > 6000 || alto > 6000) throw new ArgumentOutOfRangeException(nameof(ancho));
        var bitmap = new Bitmap(ancho, alto);
        try
        {
            bitmap.SetResolution(96, 96);
            using var g = Graphics.FromImage(bitmap); Dibujar(g, new Rectangle(0, 0, ancho, alto), 1F, false); return bitmap;
        }
        catch { bitmap.Dispose(); throw; }
    }
    private Color ColorSerie(int n)
    {
        var colores = MYGCatalogoGraficosIncidencia.Paletas[configuracion.Paleta];
        return SystemInformation.HighContrast ? SystemColors.Highlight : ColorTranslator.FromHtml(colores[n % colores.Length]);
    }
    private static Color Tono(Color c, float factor) => Color.FromArgb(c.A,
        Math.Clamp((int)(c.R * factor), 0, 255), Math.Clamp((int)(c.G * factor), 0, 255), Math.Clamp((int)(c.B * factor), 0, 255));
    private void Dibujar(Graphics grafico, Rectangle destino, float escala, bool registrar)
    {
        if (destino.Width <= 0 || destino.Height <= 0) return;
        var estado = grafico.Save();
        try
        {
            grafico.SetClip(destino); grafico.TranslateTransform(destino.X, destino.Y); grafico.ScaleTransform(escala, escala);
            grafico.SmoothingMode = SmoothingMode.AntiAlias; grafico.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            float w = destino.Width / escala, h = destino.Height / escala;
            bool oscuro = configuracion.Apariencia is 2 or 3;
            Color fondo = SystemInformation.HighContrast ? SystemColors.Window : oscuro ? configuracion.Apariencia == 2 ? Color.Black : Color.FromArgb(18, 20, 24) : BackColor;
            Color tinta = SystemInformation.HighContrast ? SystemColors.WindowText : oscuro ? Color.White : ForeColor;
            using var relleno = new SolidBrush(fondo); grafico.FillRectangle(relleno, 0, 0, w, h);
            if (!SystemInformation.HighContrast && configuracion.Apariencia is 1 or 4)
            {
                Color extremo = configuracion.Apariencia == 1 ? Color.FromArgb(232, 237, 244) : Color.FromArgb(245, 249, 255);
                using var gradiente = new LinearGradientBrush(new RectangleF(0, 0, w, h), fondo, extremo, 90);
                grafico.FillRectangle(gradiente, 0, 0, w, h);
            }
            if (registrar)
            {
                destinoPantalla = destino; escalaPantalla = escala;
                columnasInteractivas.Clear();
                areaColumnasPantalla = RectangleF.Empty;
            }
            float lectura = registrar ? EscalaTextoPantalla : 1f;
            // Las coordenadas ya están escaladas al DPI del control; usar píxeles
            // evita que Graphics convierta de nuevo los puntos físicos de la fuente.
            bool columnasClasicas = configuracion.Tipo == "columnas-0" && !configuracion.Horizontal;
            if (columnasClasicas && !SystemInformation.HighContrast && fondo.GetBrightness() > .6f) tinta = Color.Black;
            using var fuente = new Font("Tahoma", configuracion.TamanoFuente * lectura * 96 / 72, FontStyle.Regular, GraphicsUnit.Pixel);
            using var titulo = new Font(columnasClasicas ? "Times New Roman" : "Segoe UI",
                (configuracion.TamanoFuente + (columnasClasicas ? 3 : 1)) * lectura * 96 / 72, FontStyle.Bold, GraphicsUnit.Pixel);
            float y = 4;
            if (configuracion.MostrarTitulo)
            {
                float altoTitulo = Math.Max(25, titulo.GetHeight(grafico) + 7);
                float altoLinea = Math.Max(22, fuente.GetHeight(grafico) + 6);
                Texto(grafico, configuracion.Titulo, titulo, tinta, new RectangleF(3, y, w - 6, altoTitulo)); y += altoTitulo;
                if (!string.IsNullOrWhiteSpace(configuracion.Subtitulo)) { Texto(grafico, configuracion.Subtitulo, fuente, tinta, new RectangleF(5, y, w - 10, altoLinea)); y += altoLinea; }
                foreach (string t in configuracion.Titulos) { Texto(grafico, t, fuente, tinta, new RectangleF(5, y, w - 10, altoLinea)); y += altoLinea; }
            }
            var lienzo = new RectangleF(5, y + 3, Math.Max(1, w - 10), Math.Max(1, h - y - 8));
            var tipo = MYGCatalogoGraficosIncidencia.Tipos.First(t => t.Id == configuracion.Tipo);
            string problema = error;
            if (problema == null && (datos.Count == 0 || datos.All(d => d.Importe == 0))) problema = "Sin costos en el alcance seleccionado";
            if (problema == null && (tipo.Familia is "circular" or "radar") && datos.Any(d => d.Importe < 0))
                problema = "Este tipo requiere importes no negativos. Seleccione columnas o líneas para ver los costos con signo.";
            if (problema == null && tipo.Familia == "radar" && datos.Count < 3)
                problema = "El radar requiere al menos tres conceptos. Seleccione columnas o líneas para este alcance.";
            if (problema != null) { Texto(grafico, problema, fuente, tinta, lienzo); return; }
            if (lienzo.Width < 65 || lienzo.Height < 40) return;
            if (configuracion.MostrarLeyenda)
            {
                float altoFila = Math.Max(18, grafico.MeasureString("Ag", fuente).Height + 2);
                float anchoCelda = datos.Max(d => grafico.MeasureString(TextoLeyenda(d), fuente).Width) + 30;
                int porAncho = Math.Max(1, (int)(lienzo.Width / Math.Min(420, anchoCelda)));
                int filasDisponibles = Math.Max(1, (int)((lienzo.Height / 3 - 4) / altoFila));
                int porAltura = (datos.Count + filasDisponibles - 1) / filasDisponibles;
                int columnas = Math.Min(datos.Count, Math.Max(porAncho, porAltura));
                int filas = (datos.Count + columnas - 1) / columnas;
                float altura = Math.Min(lienzo.Height * .4F, filas * altoFila + 4);
                DibujarLeyenda(grafico, new RectangleF(lienzo.Left, lienzo.Bottom - altura, lienzo.Width, altura), fuente, tinta, columnas);
                lienzo.Height -= altura;
            }
            if (tipo.Familia == "circular") DibujarCircular(grafico, lienzo, tipo, fuente, tinta, fondo, registrar);
            else if (tipo.Familia == "radar") DibujarRadar(grafico, lienzo, tipo, fuente, tinta, fondo, registrar);
            else if (columnasClasicas) DibujarColumnasReferencia(grafico, lienzo, tipo, fuente, tinta, fondo, registrar);
            else DibujarCartesiano(grafico, lienzo, tipo, fuente, tinta, fondo, registrar);
            foreach (var a in configuracion.Anotaciones)
            {
                var cuadro = new RectangleF(lienzo.Left + (lienzo.Width - 110) * a.X / 100F, lienzo.Top + (lienzo.Height - 36) * a.Y / 100F, 110, 36);
                using var b = new SolidBrush(Color.FromArgb(225, fondo)); using var p = new Pen(tinta);
                grafico.FillRectangle(b, cuadro); grafico.DrawRectangle(p, cuadro.X, cuadro.Y, cuadro.Width, cuadro.Height);
                Texto(grafico, a.Texto, fuente, tinta, cuadro);
            }
        }
        finally { grafico.Restore(estado); }
    }
    private static void Texto(Graphics g, string valor, Font fuente, Color color, RectangleF area, StringAlignment alineacion = StringAlignment.Center)
    {
        if (area.Width <= 0 || area.Height <= 0) return;
        using var tinta = new SolidBrush(color); using var formato = new StringFormat { Alignment = alineacion, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter };
        g.DrawString(valor ?? "", fuente, tinta, area, formato);
    }
    private string Etiqueta(MYGIncidenciaCosto d, bool circular = false)
    {
        var partes = new List<string>();
        if (configuracion.EtiquetaNombre) partes.Add(d.Nombre.Replace("SUBCONTRATOS", "SUB-CONTRATOS"));
        if (configuracion.EtiquetaPorcentaje) partes.Add(d.Porcentaje.ToString("0.00", CultureInfo.InvariantCulture) + " %");
        if (configuracion.EtiquetaImporte) partes.Add(moneda + " " + MYGFormatoPresupuesto.Dinero(d.Importe));
        return string.Join(circular ? "\n" : " · ", partes);
    }
    private void Rotulo(Graphics g, MYGIncidenciaCosto d, int n, PointF punto, Font fuente, Color fondo)
    {
        if (!configuracion.MostrarEtiquetas) return;
        string valor = Etiqueta(d); if (valor.Length == 0) return;
        var medida = g.MeasureString(valor, fuente, 150); var r = new RectangleF(punto.X - medida.Width / 2 - 2, punto.Y - medida.Height - 3, medida.Width + 4, medida.Height + 2);
        using var b = new SolidBrush(fondo); using var p = new Pen(ColorSerie(n));
        g.FillRectangle(b, r); g.DrawRectangle(p, r.X, r.Y, r.Width, r.Height); Texto(g, valor, fuente, ColorSerie(n), r);
    }
    private string TextoLeyenda(MYGIncidenciaCosto dato) => dato.Nombre + " · " + moneda + " " + MYGFormatoPresupuesto.Dinero(dato.Importe);
    private void DibujarLeyenda(Graphics g, RectangleF r, Font f, Color tinta, int columnas)
    {
        int filas = (datos.Count + columnas - 1) / columnas;
        float anchoCelda = r.Width / columnas, altoFila = Math.Max(1, (r.Height - 4) / filas);
        for (int n = 0; n < datos.Count; n++)
        {
            using var b = new SolidBrush(ColorSerie(n));
            float x = r.Left + (n % columnas) * anchoCelda, y = r.Top + 2 + (n / columnas) * altoFila;
            float muestra = Math.Min(10, Math.Max(1, altoFila - 4));
            g.FillRectangle(b, x + 4, y + (altoFila - muestra) / 2, muestra, muestra);
            Texto(g, TextoLeyenda(datos[n]), f, tinta,
                new RectangleF(x + muestra + 9, y, Math.Max(1, anchoCelda - muestra - 13), altoFila), StringAlignment.Near);
        }
    }
    private static string EscalaEje(double v) => Math.Abs(v) >= 1000000 ? (v / 1000000).ToString("0.#") + " M" : Math.Abs(v) >= 1000 ? (v / 1000).ToString("0.#") + " mil" : v.ToString("0.##");
    private void DibujarCartesiano(Graphics g, RectangleF r, MYGTipoGraficoIncidencia tipo, Font f, Color tinta, Color fondo, bool registrar)
    {
        bool horizontal = configuracion.Horizontal && tipo.Familia == "columnas";
        bool cascada = tipo.Id == "columnas-5";
        bool apilado = tipo.Familia == "columnas" && !cascada && tipo.Variante is 1 or 2 or 4 or 5;
        bool porcentaje = tipo.Familia == "columnas" && !cascada && tipo.Variante is 2 or 5
            || tipo.Familia == "area" && tipo.Variante == 2 || tipo.Id is "linea-4" or "linea3d-3";
        var valores = datos.Select(d => porcentaje ? (double)d.Porcentaje : (double)d.Importe).ToArray();
        bool acumulado = tipo.Familia == "area" && tipo.Variante is 1 or 2
            || tipo.Familia == "lineas" && (tipo.Variante == 1 || tipo.TresDimensiones && tipo.Variante == 3 || !tipo.TresDimensiones && tipo.Variante == 4);
        if (acumulado) for (int n = 1; n < valores.Length; n++) valores[n] += valores[n - 1];
        double minimoAutomatico = Math.Min(0, valores.Min()), maximoAutomatico = Math.Max(0, valores.Max());
        if (apilado) { minimoAutomatico = valores.Where(v => v < 0).Sum(); maximoAutomatico = valores.Where(v => v > 0).Sum(); }
        if (cascada)
        {
            double suma = 0; minimoAutomatico = maximoAutomatico = 0;
            foreach (double valor in valores)
            { suma += valor; minimoAutomatico = Math.Min(minimoAutomatico, suma); maximoAutomatico = Math.Max(maximoAutomatico, suma); }
        }
        double minimo = configuracion.MinimoEje != 0 ? (double)configuracion.MinimoEje : minimoAutomatico;
        double maximo = maximoAutomatico;
        if (porcentaje) maximo = Math.Max(100, maximo);
        if (configuracion.MaximoEje != 0) maximo = (double)configuracion.MaximoEje;
        else if (maximo > 0) { double potencia = Math.Pow(10, Math.Floor(Math.Log10(maximo))); maximo = Math.Ceiling(maximo / potencia / .5) * potencia * .5; }
        if (maximo <= minimo) maximo = minimo + 1;
        float profundidad = tipo.TresDimensiones ? 8 + configuracion.Inclinacion * .25F : 0;
        var a = new RectangleF(r.Left + (horizontal ? 101 : 48), r.Top + 18 + profundidad, r.Width - (horizontal ? 116 : 64) - profundidad,
            r.Height - 61 - profundidad);
        if (a.Width < 20 || a.Height < 15) return;
        float Pos(double v) => horizontal ? a.Left + (float)((v - minimo) / (maximo - minimo)) * a.Width : a.Bottom - (float)((v - minimo) / (maximo - minimo)) * a.Height;
        using var eje = new Pen(Color.FromArgb(100, tinta)); using var cuadricula = new Pen(Color.FromArgb(45, tinta));
        for (int n = 0; n <= 4; n++)
        {
            double v = minimo + (maximo - minimo) * n / 4; float pos = Pos(v);
            if (configuracion.MostrarCuadricula)
            {
                if (horizontal) g.DrawLine(cuadricula, pos, a.Top, pos, a.Bottom);
                else { g.DrawLine(cuadricula, a.Left, pos, a.Right, pos); if (profundidad > 0) g.DrawLine(cuadricula, a.Right, pos, a.Right + profundidad, pos - profundidad); }
            }
            if (configuracion.MostrarEjes)
                Texto(g, EscalaEje(v) + (porcentaje ? "%" : ""), f, tinta, horizontal ? new RectangleF(pos - 26, a.Bottom, 52, 20) : new RectangleF(r.Left, pos - 9, 44, 18), horizontal ? StringAlignment.Center : StringAlignment.Far);
        }
        if (configuracion.MostrarEjes)
        {
            g.DrawLine(eje, a.Left, a.Bottom, a.Right, a.Bottom); g.DrawLine(eje, a.Left, a.Top, a.Left, a.Bottom);
            Texto(g, porcentaje ? "%" : moneda, f, tinta, new RectangleF(r.Left, r.Top, 55, 18), StringAlignment.Near);
        }
        float paso = (horizontal ? a.Height : a.Width) / datos.Count;
        if (tipo.Familia == "columnas")
        {
            double positivo = 0, negativo = 0, suma = 0;
            for (int n = 0; n < datos.Count; n++)
            {
                double desde = apilado ? valores[n] < 0 ? negativo : positivo : cascada ? suma : 0;
                double hasta = desde + valores[n];
                if (apilado) { if (valores[n] < 0) negativo = hasta; else positivo = hasta; }
                if (cascada) suma = hasta;
                float p1 = Math.Clamp(Pos(desde), horizontal ? a.Left : a.Top, horizontal ? a.Right : a.Bottom);
                float p2 = Math.Clamp(Pos(hasta), horizontal ? a.Left : a.Top, horizontal ? a.Right : a.Bottom);
                float centro = apilado ? horizontal ? a.Top + a.Height / 2 : a.Left + a.Width / 2 : horizontal ? a.Top + (n + .5F) * paso : a.Left + (n + .5F) * paso;
                float ancho = apilado ? (horizontal ? a.Height : a.Width) * .36F : paso * .62F;
                var bar = horizontal ? new RectangleF(Math.Min(p1, p2), centro - ancho / 2, Math.Max(1, Math.Abs(p2 - p1)), ancho) : new RectangleF(centro - ancho / 2, Math.Min(p1, p2), ancho, Math.Max(1, Math.Abs(p2 - p1)));
                PintarBarra(g, bar, tipo, ColorSerie(n), horizontal, profundidad, registrar ? datos[n] : null);
                PointF etiqueta = horizontal ? new PointF(Math.Min(a.Right - 23, p2 + 24), centro + 8) : new PointF(centro, bar.Top - 1);
                if (apilado) etiqueta = horizontal ? new PointF(bar.Left + bar.Width / 2, centro + 8) : new PointF(centro, bar.Top + bar.Height / 2 + 8);
                Rotulo(g, datos[n], n, etiqueta, f, fondo);
                if (configuracion.MostrarEjes && !apilado)
                    Texto(g, datos[n].Nombre.Replace("SUBCONTRATOS", "SUB-CONTRATOS"), f, tinta, horizontal ? new RectangleF(r.Left, centro - paso / 2, 98, paso) : new RectangleF(a.Left + n * paso - 2, a.Bottom + 3, paso + 4, 37));
            }
            if (apilado && configuracion.MostrarEjes) Texto(g, "COSTO DIRECTO", f, tinta, new RectangleF(a.Left, a.Bottom + 3, a.Width, 28));
        }
        else
        {
            var puntos = valores.Select((v, n) => new PointF(a.Left + (n + .5F) * paso, Math.Clamp(Pos(v), a.Top, a.Bottom))).ToArray();
            if (tipo.Familia == "area")
            {
                float baseArea = Math.Clamp(Pos(0), a.Top, a.Bottom);
                var poligono = new List<PointF> { new(puntos[0].X, baseArea) }; poligono.AddRange(puntos); poligono.Add(new(puntos[^1].X, baseArea));
                using var b = new SolidBrush(Color.FromArgb(150, ColorSerie(0))); g.FillPolygon(b, poligono.ToArray());
            }
            using var linea = new Pen(ColorSerie(0), tipo.TresDimensiones ? 6 : 2);
            if (puntos.Length > 1 && !(tipo.Variante == 2 && !tipo.TresDimensiones))
            {
                if (tipo.Forma == "curva" && puntos.Length > 2) g.DrawCurve(linea, puntos, .45F);
                else if (tipo.Forma == "escalon")
                    for (int n = 1; n < puntos.Length; n++) { g.DrawLine(linea, puntos[n-1], new PointF(puntos[n].X, puntos[n-1].Y)); g.DrawLine(linea, new PointF(puntos[n].X, puntos[n-1].Y), puntos[n]); }
                else g.DrawLines(linea, puntos);
            }
            if (tipo.TresDimensiones)
            {
                using var sombra = new Pen(Color.FromArgb(80, ColorSerie(0)), 2);
                for (int n = 1; n < puntos.Length; n++) g.DrawLine(sombra, new PointF(puntos[n-1].X + profundidad, puntos[n-1].Y - profundidad), new PointF(puntos[n].X + profundidad, puntos[n].Y - profundidad));
            }
            for (int n = 0; n < puntos.Length; n++)
            {
                using var b = new SolidBrush(ColorSerie(n)); g.FillEllipse(b, puntos[n].X - 3, puntos[n].Y - 3, 6, 6);
                if (registrar) { using var path = new GraphicsPath(); path.AddEllipse(puntos[n].X - 9, puntos[n].Y - 9, 18, 18); regiones.Add((new Region(path), datos[n])); }
                Rotulo(g, datos[n], n, puntos[n], f, fondo);
                if (configuracion.MostrarEjes) Texto(g, datos[n].Nombre, f, tinta, new RectangleF(a.Left + n * paso, a.Bottom + 3, paso, 37));
            }
        }
    }
    private void PintarBarra(Graphics g, RectangleF r, MYGTipoGraficoIncidencia tipo, Color color, bool horizontal, float profundidad, MYGIncidenciaCosto dato)
    {
        using var path = new GraphicsPath();
        if (tipo.Forma is "cono" or "piramide")
        {
            if (horizontal) path.AddPolygon(new[] { new PointF(r.Right, r.Top + r.Height / 2), new PointF(r.Left, r.Top), new PointF(r.Left, r.Bottom) });
            else path.AddPolygon(new[] { new PointF(r.Left + r.Width / 2, r.Top), new PointF(r.Right, r.Bottom), new PointF(r.Left, r.Bottom) });
        }
        else path.AddRectangle(r);
        using var b = new SolidBrush(color);
        if (configuracion.Apariencia is 1 or 4)
        {
            using var gradiente = new LinearGradientBrush(new RectangleF(r.X, r.Y, Math.Max(1, r.Width), Math.Max(1, r.Height)),
                Tono(color, configuracion.Apariencia == 4 ? 1.15F : 1.3F), Tono(color, configuracion.Apariencia == 4 ? .92F : .8F), horizontal ? 90 : 0);
            g.FillPath(gradiente, path);
        }
        else g.FillPath(b, path);
        using var borde = new Pen(configuracion.Apariencia == 3 ? Color.White : configuracion.Apariencia == 4 ? Color.FromArgb(110, Tono(color, .85F)) : Tono(color, .7F)); g.DrawPath(borde, path);
        if (profundidad > 0 && tipo.Forma == "rectangulo")
        {
            float dx = profundidad * (float)Math.Cos(configuracion.Angulo * Math.PI / 180);
            using var lateral = new SolidBrush(Tono(color, .65F)); using var superior = new SolidBrush(Tono(color, 1.2F));
            g.FillPolygon(lateral, new[] { new PointF(r.Right, r.Top), new PointF(r.Right + dx, r.Top - profundidad), new PointF(r.Right + dx, r.Bottom - profundidad), new PointF(r.Right, r.Bottom) });
            g.FillPolygon(superior, new[] { new PointF(r.Left, r.Top), new PointF(r.Left + dx, r.Top - profundidad), new PointF(r.Right + dx, r.Top - profundidad), new PointF(r.Right, r.Top) });
        }
        else if (tipo.Forma is "cilindro" or "cono")
        {
            var elipse = horizontal ? new RectangleF(r.Left - 4, r.Top, 8, r.Height) : new RectangleF(r.Left, r.Bottom - 4, r.Width, 8);
            g.FillEllipse(b, elipse); g.DrawEllipse(borde, elipse);
            if (tipo.Forma == "cilindro")
            { var superior = horizontal ? new RectangleF(r.Right - 4, r.Top, 8, r.Height) : new RectangleF(r.Left, r.Top - 4, r.Width, 8); using var claro = new SolidBrush(Tono(color, 1.3F)); g.FillEllipse(claro, superior); g.DrawEllipse(borde, superior); }
        }
        else if (tipo.Forma == "piramide")
        { using var p = new Pen(Tono(color, .65F), 2); if (!horizontal) g.DrawLine(p, r.Left + r.Width / 2, r.Top, r.Left + r.Width * .65F, r.Bottom); }
        if (dato != null) regiones.Add((new Region(path), dato));
    }
    private void DibujarCircular(Graphics g, RectangleF r, MYGTipoGraficoIncidencia tipo, Font f, Color tinta, Color fondo, bool registrar)
    {
        double total = datos.Sum(d => (double)d.Importe); if (total <= 0) return;
        if (tipo.Forma == "dona-anidada") { DibujarDonaAnidada(g, r, f, tinta, fondo, registrar, total); return; }
        float anchoEtiqueta = Math.Min(112, r.Width * .27F);
        float diametro = Math.Min(r.Width - 2 * anchoEtiqueta - 12, r.Height - 24);
        if (diametro < 25) diametro = Math.Min(r.Width * .5F, r.Height - 18);
        float alto = tipo.TresDimensiones ? diametro * (.45F + configuracion.Inclinacion / 180F) : diametro;
        var centro = new PointF(r.Left + r.Width / 2, r.Top + r.Height / 2);
        var basePie = new RectangleF(centro.X - diametro / 2, centro.Y - alto / 2, diametro, alto);
        float inicio = configuracion.Angulo - 90;
        var etiquetas = new List<(int N, PointF Origen, bool Derecha, float IdealY)>();
        for (int n = 0; n < datos.Count; n++)
        {
            float arco = (float)((double)datos[n].Importe / total * 360); if (arco <= 0) continue;
            float medio = (inicio + arco / 2) * (float)Math.PI / 180;
            float desplazamiento = tipo.Forma == "explosionada" ? configuracion.Separacion : 0;
            var pie = basePie; pie.Offset((float)Math.Cos(medio) * desplazamiento, (float)Math.Sin(medio) * desplazamiento);
            using var b = new SolidBrush(ColorSerie(n)); using var p = new Pen(configuracion.Apariencia == 3 ? Color.White : Tono(ColorSerie(n), .75F), .7F);
            using var path = new GraphicsPath(); path.AddPie(pie.X, pie.Y, pie.Width, pie.Height, inicio, arco);
            if (tipo.TresDimensiones)
            {
                using var lado = new SolidBrush(Tono(ColorSerie(n), .65F));
                for (int h = 9; h > 0; h--) g.FillPie(lado, pie.X, pie.Y + h, pie.Width, pie.Height, inicio, arco);
            }
            if (!SystemInformation.HighContrast && configuracion.Apariencia is 1 or 4)
            {
                using var gradiente = new LinearGradientBrush(pie, Tono(ColorSerie(n), configuracion.Apariencia == 1 ? 1.4F : 1.2F), Tono(ColorSerie(n), .8F), 45);
                g.FillPath(gradiente, path);
            }
            else g.FillPath(b, path);
            g.DrawArc(p, pie, inicio, arco);
            if (registrar)
            {
                var region = new Region(path);
                if (tipo.Forma == "dona")
                { using var hueco = new GraphicsPath(); hueco.AddEllipse(pie.X + pie.Width * .29F, pie.Y + pie.Height * .29F, pie.Width * .42F, pie.Height * .42F); region.Exclude(hueco); }
                regiones.Add((region, datos[n]));
            }
            var origen = new PointF(pie.X + pie.Width / 2 + (float)Math.Cos(medio) * pie.Width * .48F, pie.Y + pie.Height / 2 + (float)Math.Sin(medio) * pie.Height * .48F);
            etiquetas.Add((n, origen, Math.Cos(medio) >= 0, origen.Y)); inicio += arco;
        }
        if (tipo.Forma == "dona")
        {
            using var b = new SolidBrush(fondo); g.FillEllipse(b, basePie.X + basePie.Width * .29F, basePie.Y + basePie.Height * .29F, basePie.Width * .42F, basePie.Height * .42F);
            Texto(g, "100 %", f, tinta, new RectangleF(centro.X - 30, centro.Y - 15, 60, 30));
        }
        if (!configuracion.MostrarEtiquetas) return;
        foreach (bool derecha in new[] { false, true })
        {
            var lado = etiquetas.Where(e => e.Derecha == derecha).OrderBy(e => e.IdealY).ToArray();
            float altura = Math.Min(44, r.Height / Math.Max(1, lado.Length)); float ultima = r.Top - altura;
            for (int i = 0; i < lado.Length; i++)
            {
                var e = lado[i]; float yy = Math.Clamp(e.IdealY - altura / 2, Math.Max(r.Top, ultima + altura), Math.Max(r.Top, r.Bottom - (lado.Length - i) * altura)); ultima = yy;
                float x = derecha ? r.Right - anchoEtiqueta : r.Left;
                var caja = new RectangleF(x, yy, anchoEtiqueta, altura - 2);
                using var p = new Pen(ColorSerie(e.N)); using var b = new SolidBrush(fondo);
                g.DrawLine(p, e.Origen, new PointF(derecha ? caja.Left : caja.Right, caja.Top + caja.Height / 2));
                g.FillRectangle(b, caja); g.DrawRectangle(p, caja.X, caja.Y, caja.Width, caja.Height);
                Texto(g, Etiqueta(datos[e.N], true), f, ColorSerie(e.N), caja);
            }
        }
    }
    private void DibujarDonaAnidada(Graphics g, RectangleF r, Font f, Color tinta, Color fondo, bool registrar, double total)
    {
        float diametro = Math.Max(24, Math.Min(r.Width * .65F, r.Height - 18));
        float espacio = diametro * .4F / datos.Count;
        var centro = new PointF(r.Left + r.Width / 2, r.Top + r.Height / 2);
        for (int n = 0; n < datos.Count; n++)
        {
            float radio = diametro / 2 - n * espacio;
            var exterior = new RectangleF(centro.X - radio, centro.Y - radio, 2 * radio, 2 * radio);
            var interior = RectangleF.Inflate(exterior, -espacio * .78F, -espacio * .78F);
            using var anillo = new GraphicsPath(FillMode.Alternate); anillo.AddEllipse(exterior); anillo.AddEllipse(interior);
            using var tenue = new SolidBrush(Color.FromArgb(30, tinta)); g.FillPath(tenue, anillo);
            using var sector = new GraphicsPath();
            float arco = (float)((double)datos[n].Importe / total * 360);
            if (arco > 0)
            {
                sector.AddPie(exterior.X, exterior.Y, exterior.Width, exterior.Height, configuracion.Angulo - 90, arco);
                using var recorte = new Region(anillo); recorte.Intersect(sector);
                using var color = new SolidBrush(ColorSerie(n)); g.FillRegion(color, recorte);
                if (registrar) regiones.Add((recorte.Clone(), datos[n]));
            }
        }
        if (configuracion.MostrarEtiquetas)
        {
            // Cada anillo conserva el mismo denominador: costo directo total.
            for (int n = 0; n < datos.Count; n++)
            {
                var posicion = new RectangleF(r.Left + 3, r.Top + n * Math.Min(28, r.Height / datos.Count), Math.Min(130, r.Width * .4F), Math.Min(28, r.Height / datos.Count));
                using var b = new SolidBrush(fondo); g.FillRectangle(b, posicion);
                Texto(g, Etiqueta(datos[n], true), f, ColorSerie(n), posicion, StringAlignment.Near);
            }
        }
        Texto(g, "100 %", f, tinta, new RectangleF(centro.X - 24, centro.Y - 12, 48, 24));
    }
    private void DibujarRadar(Graphics g, RectangleF r, MYGTipoGraficoIncidencia tipo, Font f, Color tinta, Color fondo, bool registrar)
    {
        var centro = new PointF(r.Left + r.Width / 2, r.Top + r.Height / 2);
        float radio = Math.Max(10, Math.Min(r.Width - 130, r.Height - 55) / 2);
        double maximo = Math.Max(1, datos.Max(d => (double)d.Importe));
        PointF Polar(float longitud, int n) { double a = -Math.PI / 2 + n * Math.PI * 2 / datos.Count; return new(centro.X + (float)Math.Cos(a) * longitud, centro.Y + (float)Math.Sin(a) * longitud); }
        using var eje = new Pen(Color.FromArgb(80, tinta));
        if (configuracion.MostrarCuadricula)
            for (int nivel = 1; nivel <= 4; nivel++)
            {
                if (tipo.Forma == "polar") g.DrawEllipse(eje, centro.X - radio * nivel / 4, centro.Y - radio * nivel / 4, radio * nivel / 2, radio * nivel / 2);
                else g.DrawPolygon(eje, Enumerable.Range(0, datos.Count).Select(n => Polar(radio * nivel / 4, n)).ToArray());
            }
        var puntos = datos.Select((d, n) => Polar((float)((double)d.Importe / maximo) * radio, n)).ToArray();
        using var color = new Pen(ColorSerie(0), 2);
        if (tipo.Forma == "area") { using var b = new SolidBrush(Color.FromArgb(110, ColorSerie(0))); g.FillPolygon(b, puntos); }
        if (puntos.Length >= 3) g.DrawPolygon(color, puntos);
        for (int n = 0; n < datos.Count; n++)
        {
            var borde = Polar(radio, n); if (configuracion.MostrarEjes) g.DrawLine(eje, centro, borde);
            var nombre = Polar(radio + 20, n); Texto(g, datos[n].Nombre, f, tinta, new RectangleF(nombre.X - 56, nombre.Y - 15, 112, 30));
            using var b = new SolidBrush(ColorSerie(n)); g.FillEllipse(b, puntos[n].X - 3, puntos[n].Y - 3, 6, 6);
            Rotulo(g, datos[n], n, puntos[n], f, fondo);
            if (registrar) { using var path = new GraphicsPath(); path.AddEllipse(puntos[n].X - 9, puntos[n].Y - 9, 18, 18); regiones.Add((new Region(path), datos[n])); }
        }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (arrastre.HasValue && e.Button == MouseButtons.Left)
        {
            configuracion.Angulo = ((anguloInicial + e.X - arrastre.Value.X) % 360 + 360) % 360;
            configuracion.Inclinacion = Math.Clamp(inclinacionInicial + (e.Y - arrastre.Value.Y) / 2, 0, 75); Invalidate(); return;
        }
        float escala = escalaPantalla > 0 ? escalaPantalla : DeviceDpi / 96F;
        var punto = new PointF((e.X - destinoPantalla.X) / escala, (e.Y - destinoPantalla.Y) / escala);
        var valor = regiones.LastOrDefault(r => r.Area.IsVisible(punto)).Valor;
        if (configuracion.MostrarAyudas && areaColumnasPantalla.Contains(punto) && columnasInteractivas.Count > 0)
            valor = columnasInteractivas.OrderBy(c => Math.Abs(c.Area.Left + c.Area.Width / 2 - punto.X)).First().Valor;
        bool seguimiento = configuracion.MostrarAyudas && columnasInteractivas.Any(c => ReferenceEquals(c.Valor, valor));
        var resaltado = seguimiento ? valor : null;
        if (!ReferenceEquals(datoResaltado, resaltado) || resaltado != null && puntoResaltado != punto)
        {
            datoResaltado = resaltado; puntoResaltado = resaltado == null ? null : punto;
            Invalidate();
        }
        string texto = seguimiento ? "" : configuracion.MostrarAyudas ? valor == null ? errorPreferencias ?? "" : valor.Nombre + ": " + moneda + " " + MYGFormatoPresupuesto.Dinero(valor.Importe) + " · " + valor.Porcentaje.ToString("0.00") + " %" : "";
        if (ayuda.GetToolTip(this) != texto) ayuda.SetToolTip(this, texto);
    }
    protected override void OnMouseLeave(EventArgs e)
    { base.OnMouseLeave(e); LimpiarResaltado(); ayuda.SetToolTip(this, ""); Invalidate(); }
    protected override void OnSizeChanged(EventArgs e)
    {
        LimpiarResaltado();
        if (regiones != null) LimpiarRegiones();
        columnasInteractivas?.Clear();
        base.OnSizeChanged(e);
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button == MouseButtons.Left && MYGCatalogoGraficosIncidencia.Tipos.First(t => t.Id == configuracion.Tipo).TresDimensiones)
        { arrastre = e.Location; anguloInicial = configuracion.Angulo; inclinacionInicial = configuracion.Inclinacion; Capture = true; Cursor = Cursors.SizeAll; }
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e); if (!arrastre.HasValue) return;
        arrastre = null; Capture = false; Cursor = Cursors.Default; GuardarPreferencias();
    }
    private void LimpiarRegiones() { foreach (var r in regiones) r.Area.Dispose(); regiones.Clear(); }
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            MYGTamanoTextoUI.CambioTamano -= CambiarTamanoTexto;
            DpiChangedAfterParent -= CambiarTamanoTexto;
            LimpiarRegiones(); columnasInteractivas.Clear(); ayuda.Dispose(); LiberarHerramientas();
        }
        base.Dispose(disposing);
    }
}
