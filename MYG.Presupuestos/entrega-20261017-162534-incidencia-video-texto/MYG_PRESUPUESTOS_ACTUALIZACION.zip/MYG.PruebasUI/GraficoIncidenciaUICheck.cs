using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;
using System.Xml.Linq;
using MYG_2027;

internal static class GraficoIncidenciaUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string preferencias = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "grafico-incidencia.json");
        bool existia = File.Exists(preferencias);
        byte[] contenidoAnterior = existia ? File.ReadAllBytes(preferencias) : null;
        DateTime fechaAnterior = existia ? File.GetLastWriteTimeUtc(preferencias) : default;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Grafico-UI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            var proyecto = Proyecto();
            string firma = MYGProyectoStorage.Firma(proyecto), documento = JsonSerializer.Serialize(proyecto);
            var valores = MYGPiePresupuesto.Incidencia(proyecto.Presupuestos);
            string incidencia = JsonSerializer.Serialize(valores);
            exige(valores.Select(d => d.Importe).SequenceEqual(new[] { 36.50m, 53m, 15.50m, 23m, 9.75m }),
                "El escenario del gráfico debe usar los cuatro grupos reales del ACU y un precio sin desglose.");
            using var grafico = new MYGGraficoIncidencia { Size = new Size(1000, 1100) };
            grafico.Actualizar(valores, "S/");
            exige(!ReferenceEquals(valores, Datos(grafico)) && !ReferenceEquals(valores[0], Datos(grafico)[0]),
                "El gráfico debe capturar sus datos sin conservar referencias editables a la lista de entrada.");
            valores[0].Importe = 999999m;
            exige(JsonSerializer.Serialize(Datos(grafico)) == incidencia,
                "Modificar la lista de entrada después de Actualizar no debe cambiar la captura del gráfico.");
            VerificarPlantillaYBarra(grafico, exige);
            VerificarDibujo(grafico, exige);
            VerificarEscalaEInteraccion(grafico, exige);
            VerificarExportaciones(grafico, carpeta, exige);
            exige(JsonSerializer.Serialize(Datos(grafico)) == incidencia &&
                MYGProyectoStorage.Firma(proyecto) == firma && JsonSerializer.Serialize(proyecto) == documento &&
                JsonSerializer.Serialize(MYGPiePresupuesto.Incidencia(proyecto.Presupuestos)) == incidencia,
                "Configurar, renderizar y exportar deben conservar todos los importes, porcentajes y datos del proyecto.");
        }
        finally
        {
            // Configurar ejercita la persistencia real una vez. Se repone el archivo del usuario,
            // incluso si una comprobación falla; el resto del barrido no escribe preferencias.
            try
            {
                if (existia)
                {
                    File.WriteAllBytes(preferencias, contenidoAnterior);
                    File.SetLastWriteTimeUtc(preferencias, fechaAnterior);
                }
                else if (File.Exists(preferencias)) File.Delete(preferencias);
            }
            finally { Directory.Delete(carpeta, recursive: true); }
        }
    }

    private static MYGProyectoDocumento Proyecto()
    {
        var proyecto = MYGProyectoStorage.Nuevo("GRÁFICO UI · OBRA Ñ");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        partida.Costos.Cantidad = 2;
        var grupos = new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos };
        decimal[] precios = { 18.25m, 26.50m, 7.75m, 11.50m };
        for (int n = 0; n < grupos.Length; n++)
        {
            var insumo = new MYGInsumo { Codigo = "UI-GRAF-" + n, Descripcion = "Recurso " + grupos[n], Grupo = grupos[n], Precio = precios[n] };
            presupuesto.Costos.Insumos.Add(insumo);
            partida.Costos.Analisis.Add(new MYGRecursoACU { Grupo = grupos[n], InsumoId = insumo.Id, Cantidad = 1 });
        }
        var directo = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        directo.Costos.Cantidad = 1; directo.Costos.PrecioDirecto = 9.75m;
        MYGProyectoStorage.Validar(proyecto);
        return proyecto;
    }

    private static void VerificarPlantillaYBarra(MYGGraficoIncidencia grafico, Action<bool, string> exige)
    {
        AplicarSinGuardar(grafico, new());
        var barra = Campo<ToolStrip>(grafico, "barraGrafico");
        string[] nombres = { "restaurar", "cargar", "guardar", "exportar", "asistente", "columnas", "lineas", "circular", "otros", "paleta", "previsualizar", "imprimir", "apariencia", "personalizar" };
        exige(barra.Name == "barraTipoGrafico" && barra.Items.Cast<ToolStripItem>().Select(i => i.Name).SequenceEqual(nombres) &&
            barra.Items.Cast<ToolStripItem>().All(i => i.Available && i.Image != null && !string.IsNullOrWhiteSpace(i.AccessibleName)),
            "La barra debe ofrecer sus trece herramientas con icono y nombre accesible, más Agregar o quitar botones.");
        var exportar = (ToolStripDropDownButton)barra.Items["exportar"];
        string[] documentos = { "Exportar a PDF", "Exportar a HTML", "Exportar a MHT", "Exportar a XLS", "Exportar a XLSX", "Exportar a RTF" };
        exige(exportar.DropDownItems.Cast<ToolStripItem>().Take(6).Select(i => i.Text).SequenceEqual(documentos) &&
            exportar.DropDownItems.OfType<ToolStripMenuItem>().Single(i => i.Text == "Exportar a Imagen").DropDownItems.Cast<ToolStripItem>()
                .Select(i => i.Text).SequenceEqual(new[] { "BMP", "GIF", "JPEG", "PNG", "TIFF" }),
            "Exportar debe presentar los seis formatos de documento y los cinco formatos de imagen.");
        var apariencia = (ToolStripDropDownButton)barra.Items["apariencia"];
        var muestras = apariencia.DropDown.Items.OfType<ToolStripControlHost>().SelectMany(h => h.Control.Controls.OfType<Button>()).ToArray();
        exige(muestras.Length == 35 && muestras.All(b => b.Image != null && !string.IsNullOrWhiteSpace(b.AccessibleName)),
            "La galería Apariencia debe ofrecer 35 muestras identificables, cada una con su miniatura.");

        var plantilla = MYGConfiguracionGraficoIncidencia.DesdeJson(new MYGConfiguracionGraficoIncidencia
        {
            Tipo = "tarta3d", Titulo = "Incidencia Ñ <obra & costos>", Subtitulo = "Presupuesto real",
            Paleta = "Turquesa", Apariencia = 3, MostrarLeyenda = true, EtiquetaNombre = true,
            EtiquetaImporte = true, BotonesOcultos = new[] { "exportar", "paleta" }, IconosGrandes = true,
            MostrarTextos = true, MostrarAyudas = false, Titulos = new[] { "Costos directos" },
            Anotaciones = new() { new() { Texto = "Datos del presupuesto", X = 25, Y = 75 } }
        }.AJson());
        string esperada = plantilla.AJson();
        grafico.Configurar(plantilla);
        exige(grafico.Configuracion.AJson() == esperada && !barra.Items["exportar"].Available && !barra.Items["paleta"].Available &&
            barra.Items["columnas"].Available && barra.Items["personalizar"].Available &&
            barra.ImageScalingSize.Width > 24 && !barra.ShowItemToolTips &&
            barra.Items["columnas"].DisplayStyle == ToolStripItemDisplayStyle.ImageAndText,
            "Cargar una plantilla debe aplicar tipo, presentación y visibilidad de herramientas sin ocultar la personalización.");
        using var opciones = new ContextMenuStrip();
        Invocar(grafico, "RellenarMenuBarra", opciones.Items);
        var tipo = opciones.Items.OfType<ToolStripMenuItem>().Single(i => i.Text == "Tipo de gráfico");
        exige(tipo.DropDownItems.OfType<ToolStripMenuItem>().Count(i => i.Text != "Restablecer barra") == 13 &&
            !tipo.DropDownItems.OfType<ToolStripMenuItem>().Single(i => i.Text == "Exportar").Checked &&
            !tipo.DropDownItems.OfType<ToolStripMenuItem>().Single(i => i.Text == "Paleta").Checked &&
            tipo.DropDownItems.OfType<ToolStripMenuItem>().Single(i => i.Text == "Columna").Checked &&
            opciones.Items.OfType<ToolStripMenuItem>().Any(i => i.Text == "Personalizar ..."),
            "Agregar o quitar botones debe reflejar las herramientas ocultas y ofrecer Personalizar y Restablecer barra.");
        plantilla.Titulos[0] = "Cambio externo"; plantilla.Anotaciones[0].Texto = "Cambio externo";
        plantilla.BotonesOcultos[0] = "columnas";
        var copia = grafico.Configuracion;
        copia.Titulos[0] = "Cambio de copia"; copia.Anotaciones.Clear(); copia.BotonesOcultos[0] = "imprimir";
        exige(grafico.Configuracion.AJson() == esperada,
            "La configuración aplicada y la copia devuelta deben aislar títulos, anotaciones y botones del control.");
        copia = grafico.Configuracion; copia.BarraVisible = false; AplicarSinGuardar(grafico, copia);
        exige(!barra.Visible, "La opción de ocultar la barra debe retirar todas sus herramientas de la vista.");
        AplicarSinGuardar(grafico, new());
        exige(barra.Visible && barra.Items.Cast<ToolStripItem>().All(i => i.Available),
            "Volver a la configuración predeterminada debe mostrar la barra y sus trece herramientas.");
    }

    private static void VerificarDibujo(MYGGraficoIncidencia grafico, Action<bool, string> exige)
    {
        foreach (var tipo in MYGCatalogoGraficosIncidencia.Tipos)
            for (int estilo = 0; estilo < 5; estilo++)
            {
                AplicarSinGuardar(grafico, new() { Tipo = tipo.Id, Apariencia = estilo, MostrarLeyenda = true, EtiquetaImporte = true });
                using var pequena = grafico.CrearImagen(120, 100);
                using var grande = grafico.CrearImagen(1200, 800);
                exige(pequena.Size == new Size(120, 100) && grande.Size == new Size(1200, 800),
                    "El gráfico debe renderizar sin excepción en tamaño mínimo y grande: " + tipo.Id + ", apariencia " + estilo + ".");
            }
        var estilos = new HashSet<string>();
        for (int estilo = 0; estilo < 5; estilo++)
        {
            AplicarSinGuardar(grafico, new() { Tipo = "columnas-0", Apariencia = estilo });
            using var imagen = grafico.CrearImagen(900, 600); estilos.Add(Huella(imagen));
        }
        // Alto contraste puede unificar a propósito los fondos claro y oscuro.
        exige(SystemInformation.HighContrast || estilos.Count == 5,
            "Las cinco apariencias de columnas deben producir imágenes distintas fuera del modo de alto contraste.");
        string[] representantes = { "columnas-0", "columnas-1", "columnas-2", "columnas-5", "columnas3d-0", "cilindro-0", "cono-0", "piramide-0", "linea-0", "linea-3", "linea-5", "area-0", "tarta", "dona", "explosionada", "radar", "radar-area", "polar" };
        var tipos = new HashSet<string>();
        foreach (string tipo in representantes)
        {
            AplicarSinGuardar(grafico, new() { Tipo = tipo });
            using var imagen = grafico.CrearImagen(900, 600); tipos.Add(Huella(imagen));
        }
        exige(tipos.Count == representantes.Length,
            "Los tipos representativos deben cambiar la geometría dibujada, incluida la cascada, las formas 3D, líneas, tartas y radar.");
        AplicarSinGuardar(grafico, new() { Horizontal = true, MostrarLeyenda = true });
        using var horizontal = grafico.CrearImagen(900, 600);
        AplicarSinGuardar(grafico, new() { MostrarLeyenda = true });
        using var vertical = grafico.CrearImagen(900, 600);
        exige(Huella(horizontal) != Huella(vertical), "Barras horizontales debe cambiar la orientación real del gráfico.");
    }

    private static void VerificarEscalaEInteraccion(MYGGraficoIncidencia grafico, Action<bool, string> exige)
    {
        int porcentajeAnterior = MYGTamanoTextoUI.Porcentaje;
        var configuracionAnterior = grafico.Configuracion;
        var tamanoAnterior = grafico.Size;
        string datosAntes = JsonSerializer.Serialize(Datos(grafico));
        try
        {
            MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
            AplicarSinGuardar(grafico, new() { Tipo = "columnas-0" });
            grafico.Size = new Size(860, 540);
            grafico.PerformLayout();
            string configuracion = grafico.Configuracion.AJson();
            using var imagenExportada = grafico.CrearImagen(900, 600);
            string exportacionEsperada = Huella(imagenExportada);
            using var pantallaInicial = Pantalla(grafico);
            string pantallaNormal = Huella(pantallaInicial);
            var barra = Campo<ToolStrip>(grafico, "barraGrafico");
            int iconoNormal = barra.ImageScalingSize.Width;
            float fuenteNormal = barra.Items["columnas"].Font.SizeInPoints;
            var muestras = ((ToolStripDropDownButton)barra.Items["apariencia"]).DropDown.Items
                .OfType<ToolStripControlHost>().SelectMany(h => h.Control.Controls.OfType<Button>()).ToArray();
            var medidasNormales = muestras.Select(b => (b.Size, Imagen: b.Image.Size, Fuente: b.Font.SizeInPoints)).ToArray();
            var pantallas = new Dictionary<int, string> { [100] = pantallaNormal };
            foreach (int porcentaje in new[] { 85, 115, 100, 85, 100 })
            {
                MYGTamanoTextoUI.Cambiar(porcentaje, guardarPreferencia: false);
                grafico.PerformLayout();
                using var pantalla = Pantalla(grafico);
                string huella = Huella(pantalla);
                float factor = porcentaje / 100f;
                exige(Math.Abs(barra.ImageScalingSize.Width - iconoNormal * factor) <= 1 &&
                    Math.Abs(barra.Items["columnas"].Font.SizeInPoints - fuenteNormal * factor) < .03f,
                    "La barra del gráfico debe obedecer 85 %, 115 % y 100 % sin acumular el tamaño del texto ni de sus iconos.");
                exige(muestras.Length == 35 && muestras.Select((b, n) =>
                    Math.Abs(b.Width - medidasNormales[n].Size.Width * factor) <= 1 &&
                    Math.Abs(b.Height - medidasNormales[n].Size.Height * factor) <= 1 &&
                    Math.Abs(b.Image.Width - medidasNormales[n].Imagen.Width * factor) <= 1 &&
                    Math.Abs(b.Image.Height - medidasNormales[n].Imagen.Height * factor) <= 1 &&
                    Math.Abs(b.Font.SizeInPoints - medidasNormales[n].Fuente * factor) < .03f).All(v => v),
                    "Las muestras de Apariencia deben escalar sus botones, miniaturas y texto conservando las 35 opciones.");
                exige(!pantallas.TryGetValue(porcentaje, out string anterior) || anterior == huella,
                    "Volver a un tamaño del texto debe recuperar exactamente la presentación del gráfico sin acumular escala.");
                pantallas[porcentaje] = huella;
                if (porcentaje == 85)
                {
                    var herramienta = barra.Items["columnas"];
                    using var copiaFuente = (Font)herramienta.Font.Clone();
                    herramienta.Font = copiaFuente;
                    Invocar(grafico, "ActualizarEscalaTextoHerramientas");
                    exige(Math.Abs(herramienta.Font.SizeInPoints - fuenteNormal * .85f) < .03f,
                        "Renovar una copia de fuente de WinForms debe conservar el 85 % sin aplicar otra reducción sobre el tamaño ya reducido.");
                }
                using var exportacion = grafico.CrearImagen(900, 600);
                exige(Huella(exportacion) == exportacionEsperada,
                    "La escala de lectura del gráfico debe conservar la imagen de exportación y su tamaño de fuente de autor.");
            }
            exige(pantallas.Values.Distinct().Count() == 3,
                "El título, ejes y etiquetas del gráfico deben cambiar realmente al elegir 85 %, 100 % o 115 %.");

            foreach (var caso in new[] { (Porcentaje: 85, Ancho: 500), (Porcentaje: 115, Ancho: 860), (Porcentaje: 100, Ancho: 650) })
            {
                MYGTamanoTextoUI.Cambiar(caso.Porcentaje, guardarPreferencia: false);
                grafico.Size = new Size(caso.Ancho, 540); grafico.PerformLayout();
                Invocar(grafico, "OnMouseLeave", EventArgs.Empty);
                using var reposo = Pantalla(grafico);
                string imagenEnReposo = Huella(reposo);
                var regiones = Campo<List<(Region Area, MYGIncidenciaCosto Valor)>>(grafico, "regiones");
                exige(regiones.Count == Datos(grafico).Count,
                    "Cada barra de incidencia debe mantener una región activa para su dato real después de cambiar texto o ancho.");
                // Las regiones usan coordenadas lógicas del lienzo. El ratón se
                // entrega en píxeles del control, incluido el ancho de la barra.
                var objetivos = regiones.Select(r => (Centro: PuntoInterior(r.Area, reposo), r.Valor)).ToArray();
                foreach (var objetivo in objetivos)
                {
                    PointF centro = objetivo.Centro;
                    float dpi = grafico.DeviceDpi / 96f;
                    Point punto = new((int)Math.Round(barra.Width + centro.X * dpi), (int)Math.Round(centro.Y * dpi));
                    Invocar(grafico, "OnMouseMove", new MouseEventArgs(MouseButtons.None, 0, punto.X, punto.Y, 0));
                    using var resaltado = Pantalla(grafico);
                    exige(Huella(resaltado) != imagenEnReposo,
                        "Pasar el puntero por " + objetivo.Valor.Nombre + " debe mostrar el resaltado y la guía con texto al " + caso.Porcentaje + " %.");
                    using var exportacion = grafico.CrearImagen(900, 600);
                    exige(Huella(exportacion) == exportacionEsperada,
                        "La guía, etiqueta flotante y resaltado del puntero deben quedar fuera de la exportación del gráfico.");
                    Invocar(grafico, "OnMouseLeave", EventArgs.Empty);
                    using var alSalir = Pantalla(grafico);
                    exige(Huella(alSalir) == imagenEnReposo,
                        "Salir del gráfico debe retirar la guía y el resaltado sin dejar marcas en el lienzo.");
                }
                var area = Campo<RectangleF>(grafico, "areaColumnasPantalla");
                var entreBarras = new PointF(area.Left + area.Width / Datos(grafico).Count, area.Top + area.Height / 2);
                exige(area.Contains(entreBarras) && !regiones.Any(r => r.Area.IsVisible(entreBarras)),
                    "El escenario de seguimiento debe incluir un punto libre entre dos barras dentro del área de datos.");
                float escalaDpi = grafico.DeviceDpi / 96f;
                Invocar(grafico, "OnMouseMove", new MouseEventArgs(MouseButtons.None, 0,
                    (int)Math.Round(barra.Width + entreBarras.X * escalaDpi), (int)Math.Round(entreBarras.Y * escalaDpi), 0));
                using var entreColumnas = Pantalla(grafico);
                exige(Huella(entreColumnas) != imagenEnReposo,
                    "Mover el puntero entre las barras debe mantener la guía y mostrar la columna más cercana.");
                Invocar(grafico, "OnMouseLeave", EventArgs.Empty);
                using var sinSeguimiento = Pantalla(grafico);
                exige(Huella(sinSeguimiento) == imagenEnReposo,
                    "Salir del área de datos debe limpiar también el seguimiento iniciado entre las barras.");
                Invocar(grafico, "OnMouseMove", new MouseEventArgs(MouseButtons.None, 0, 0, 1, 0));
                using var sobreBarra = Pantalla(grafico);
                exige(Huella(sobreBarra) == imagenEnReposo,
                    "Mover el puntero sobre la barra de herramientas no debe activar una barra de incidencia por una coordenada desplazada.");
            }
            exige(grafico.Configuracion.AJson() == configuracion && JsonSerializer.Serialize(Datos(grafico)) == datosAntes,
                "Escalar, redimensionar y recorrer las barras con el puntero deben conservar la configuración guardada y los importes reales.");

            using var descartable = new MYGGraficoIncidencia { Size = new Size(650, 540) };
            AplicarSinGuardar(descartable, new() { Tipo = "columnas-0" });
            descartable.Actualizar(Datos(grafico), "S/");
            using (var pantalla = Pantalla(descartable)) { }
            var regionesDescartables = Campo<List<(Region Area, MYGIncidenciaCosto Valor)>>(descartable, "regiones");
            var barraDescartable = Campo<ToolStrip>(descartable, "barraGrafico");
            exige(regionesDescartables.Count > 0, "El escenario de liberación debe incluir regiones interactivas reales.");
            descartable.Dispose();
            MYGTamanoTextoUI.Cambiar(85, guardarPreferencia: false);
            MYGTamanoTextoUI.Cambiar(115, guardarPreferencia: false);
            exige(descartable.IsDisposed && barraDescartable.IsDisposed && regionesDescartables.Count == 0,
                "Cerrar el gráfico debe liberar la barra y sus regiones, y permitir cambios posteriores del tamaño de texto sin reutilizar controles liberados.");
        }
        finally
        {
            Invocar(grafico, "OnMouseLeave", EventArgs.Empty);
            grafico.Size = tamanoAnterior;
            AplicarSinGuardar(grafico, configuracionAnterior);
            MYGTamanoTextoUI.Cambiar(porcentajeAnterior, guardarPreferencia: false);
        }
    }

    private static Bitmap Pantalla(MYGGraficoIncidencia grafico)
    {
        var imagen = new Bitmap(grafico.Width, grafico.Height);
        try
        {
            using var dibujo = Graphics.FromImage(imagen);
            Invocar(grafico, "OnPaint", new PaintEventArgs(dibujo, grafico.ClientRectangle));
            return imagen;
        }
        catch { imagen.Dispose(); throw; }
    }

    private static PointF PuntoInterior(Region region, Bitmap imagen)
    {
        using var dibujo = Graphics.FromImage(imagen);
        var limites = region.GetBounds(dibujo);
        var centro = new PointF(limites.Left + limites.Width / 2, limites.Top + limites.Height / 2);
        if (region.IsVisible(centro)) return centro;
        for (float y = limites.Top + .5f; y < limites.Bottom; y++)
            for (float x = limites.Left + .5f; x < limites.Right; x++)
                if (region.IsVisible(x, y)) return new PointF(x, y);
        throw new InvalidOperationException("Una barra del gráfico no contiene ningún punto interactivo visible.");
    }

    private static void VerificarExportaciones(MYGGraficoIncidencia grafico, string carpeta, Action<bool, string> exige)
    {
        const string titulo = "Incidencia Ñ <obra & costos>";
        AplicarSinGuardar(grafico, new() { Tipo = "tarta3d", Titulo = titulo, MostrarLeyenda = true, EtiquetaNombre = true, EtiquetaImporte = true });
        using var captura = grafico.CrearImagen(900, 600);
        var datos = Datos(grafico);
        foreach (string extension in new[] { "bmp", "gif", "jpeg", "png", "tiff" })
        {
            string ruta = Path.Combine(carpeta, "Incidencia." + extension);
            MYGGraficoIncidenciaExportacion.Guardar(ruta, datos, "S/", titulo, captura);
            byte[] bytes = File.ReadAllBytes(ruta);
            bool firma = extension switch
            {
                "bmp" => bytes.AsSpan().StartsWith(new byte[] { 0x42, 0x4D }),
                "gif" => Encoding.ASCII.GetString(bytes, 0, 6) is "GIF87a" or "GIF89a",
                "jpeg" => bytes.AsSpan().StartsWith(new byte[] { 0xFF, 0xD8, 0xFF }),
                "png" => bytes.AsSpan().StartsWith(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }),
                "tiff" => bytes.AsSpan().StartsWith(new byte[] { 0x49, 0x49, 0x2A, 0 }) || bytes.AsSpan().StartsWith(new byte[] { 0x4D, 0x4D, 0, 0x2A }),
                _ => false
            };
            using var reabierta = Image.FromFile(ruta);
            exige(firma && reabierta.Size == captura.Size,
                "La exportación " + extension.ToUpperInvariant() + " debe tener su firma real y conservar el tamaño completo de la captura.");
            if (extension == "png") exige(bytes.SequenceEqual(Imagen(captura, ImageFormat.Png)),
                "La imagen PNG exportada debe corresponder exactamente al gráfico actual.");
        }
        string pdf = Path.Combine(carpeta, "Incidencia.pdf");
        MYGGraficoIncidenciaExportacion.Guardar(pdf, datos, "S/", titulo, captura);
        byte[] contenidoPdf = File.ReadAllBytes(pdf), jpeg = Imagen(captura, ImageFormat.Jpeg);
        string textoPdf = Encoding.Latin1.GetString(contenidoPdf);
        int inicioImagen = textoPdf.IndexOf("stream\n", StringComparison.Ordinal) + "stream\n".Length;
        exige(textoPdf.StartsWith("%PDF-1.4", StringComparison.Ordinal) && textoPdf.Contains("/Width 900 /Height 600", StringComparison.Ordinal) &&
            inicioImagen >= "stream\n".Length && contenidoPdf.AsSpan(inicioImagen, jpeg.Length).SequenceEqual(jpeg) &&
            textoPdf.Contains("/Title <FEFF" + Convert.ToHexString(Encoding.BigEndianUnicode.GetBytes(titulo)) + ">", StringComparison.Ordinal) &&
            textoPdf.EndsWith("%%EOF\n", StringComparison.Ordinal),
            "El PDF debe incrustar la captura actual completa y conservar su título Unicode.");

        string xlsx = Path.Combine(carpeta, "Incidencia.xlsx");
        MYGGraficoIncidenciaExportacion.Guardar(xlsx, datos, "S/", titulo, captura);
        using var libro = ZipFile.OpenRead(xlsx);
        using var hojaXml = libro.GetEntry("xl/worksheets/sheet1.xml").Open();
        var hoja = XDocument.Load(hojaXml); XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        XElement Celda(string referencia) => hoja.Descendants(ns + "c").Single(c => (string)c.Attribute("r") == referencia);
        string Texto(string referencia) => string.Concat(Celda(referencia).Descendants(ns + "t").Select(t => t.Value));
        decimal Numero(string referencia) => decimal.Parse(Celda(referencia).Element(ns + "v").Value, CultureInfo.InvariantCulture);
        exige(Texto("A1") == titulo && hoja.Descendants(ns + "row").Count() == datos.Count + 2,
            "El XLSX debe conservar el título y todas las filas reales del desglose sin datos de ejemplo.");
        for (int n = 0; n < datos.Count; n++)
        {
            string fila = (n + 4).ToString(CultureInfo.InvariantCulture);
            exige(Texto("A" + fila) == datos[n].Nombre && Numero("B" + fila) == datos[n].Importe &&
                Numero("C" + fila) == datos[n].Porcentaje / 100m && Texto("D" + fila) == "S/",
                "El XLSX debe conservar nombre, importe decimal, porcentaje numérico y moneda del grupo " + datos[n].Nombre + ".");
        }
        using var png = libro.GetEntry("xl/media/incidencia.png").Open();
        using var bytesPng = new MemoryStream(); png.CopyTo(bytesPng);
        exige(bytesPng.ToArray().SequenceEqual(Imagen(captura, ImageFormat.Png)) &&
            libro.GetEntry("xl/drawings/drawing1.xml") != null && libro.GetEntry("xl/drawings/_rels/drawing1.xml.rels") != null,
            "El XLSX debe incluir el snapshot PNG exacto de la presentación exportada y su dibujo asociado.");
    }

    private static List<MYGIncidenciaCosto> Datos(MYGGraficoIncidencia grafico) => Campo<List<MYGIncidenciaCosto>>(grafico, "datos");
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static void Invocar(object objeto, string nombre, params object[] argumentos) => objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);
    private static void AplicarSinGuardar(MYGGraficoIncidencia grafico, MYGConfiguracionGraficoIncidencia valor)
    {
        typeof(MYGGraficoIncidencia).GetField("configuracion", Privados).SetValue(grafico, valor.Copia());
        Invocar(grafico, "ActualizarHerramientas");
    }
    private static byte[] Imagen(Bitmap imagen, ImageFormat formato)
    {
        using var memoria = new MemoryStream(); imagen.Save(memoria, formato); return memoria.ToArray();
    }
    private static string Huella(Bitmap imagen) => Convert.ToHexString(SHA256.HashData(Imagen(imagen, ImageFormat.Png)));
}
