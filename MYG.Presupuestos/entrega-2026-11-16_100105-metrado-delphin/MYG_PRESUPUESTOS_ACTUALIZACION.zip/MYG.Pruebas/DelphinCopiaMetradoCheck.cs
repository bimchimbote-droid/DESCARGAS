using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class DelphinCopiaMetradoCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var origen = new MYGPresupuestoDocumento { Id = "PPORIGEN", Nombre = "ORIGEN" };
        var i = new ItemPresupuestoDelphin
        {
            Id = "CUORIGEN", IdLocalMYG = "DELPHIN-LOCAL-CUORIGEN", IdInternoDelphin = "CUORIGEN",
            TipoPropuesta = "PARTIDA", Descripcion = "FRENTE SINTÉTICO", Unidad = "m", Item = "01", Posicion = 1,
            Origen = "DELPHIN", Estado = "OFICIAL"
        };
        i.Costos.Cantidad = 60; i.Costos.PrecioDirecto = 0.2m;
        i.Costos.Hoja.Poner("A3", "Frente de obra");
        i.Costos.Hoja.Poner("B3", "1"); i.Costos.Hoja.Poner("C3", "60");
        i.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        i.Costos.MetradoDelphin = new MYGOrigenMetradoDelphin
        {
            PresupuestoId = origen.Id, PartidaId = i.Id,
            Sha256Archivo = new string('A', 64), FirmaHoja = new string('B', 64), CeldaTotal = "G16",
            Compatible = false, Advertencia = "AVISO DE LA IDENTIDAD ORIGINAL"
        };
        origen.Items.Add(i);
        string antes = JsonSerializer.Serialize(origen);
        var fragmento = MYGEstructuraPresupuestos.CopiarRama(origen, i);
        var destino = MYGProyectoStorage.Nuevo("COPIA INDEPENDIENTE");
        var presupuesto = destino.Presupuestos.Single();
        var copiada = MYGEstructuraPresupuestos.PegarRama(presupuesto, fragmento).Single();
        Exige(copiada.Id != i.Id && copiada.IdInternoDelphin == null && copiada.Costos.MetradoDelphin == null &&
            copiada.Costos.Hoja.Celdas["A3"].Contenido == "Frente de obra" &&
            MYGMotorPresupuestos.Cantidad(presupuesto, copiada) == 60 &&
            JsonSerializer.Serialize(origen) == antes,
            "Pegar una partida conservó la revisión/advertencia nativa ajena, perdió contenido o modificó el origen.");
        string ruta = Path.Combine(carpeta, "Metrado copiado independiente.sqlite");
        MYGProyectoStorage.Guardar(ruta, destino);
        var reabierta = MYGBaseDatos.LeerProyecto(ruta, destino.Id).Presupuestos.Single().Items.Single();
        Exige(reabierta.Costos.MetradoDelphin == null && reabierta.Costos.Hoja.Celdas["A3"].Contenido == "Frente de obra",
            "Guardar una partida copiada intentó escribir el archivo de otra identidad nativa.");
        pasa("Copiar una partida nativa conserva sus celdas con identidad nueva y sin revisión o bloqueo de la obra original");

        var limpia = new MYGPresupuestoDocumento { Nombre = "SIN METRADOS" };
        var sinMetrado = MYGEstructuraPresupuestos.PegarRama(limpia, fragmento, conMetrados: false).Single();
        Exige(sinMetrado.Costos.MetradoDelphin == null &&
            MYGMotorPresupuestos.Cantidad(limpia, sinMetrado) == 0 &&
            !MYGContenidoPartida.TieneMetradoExcel(sinMetrado.Costos),
            "Pegar sin metrados mantuvo la identidad del archivo de origen o una hoja oculta.");
        pasa("Pegar sin metrados elimina contenido y metadatos de origen únicamente en la copia");

        var plantilla = MYGCatalogos.CrearPlantilla(origen, i);
        Exige(plantilla.Partidas.All(p => p.Costos.MetradoDelphin == null &&
            !MYGContenidoPartida.TieneMetradoExcel(p.Costos)) && JsonSerializer.Serialize(origen) == antes,
            "El catálogo reutilizable conservó el vínculo de metrado de una obra o cambió su origen.");
        string catalogo = Path.Combine(carpeta, "Catalogo sin origen de metrado.sqlite");
        var entrada = MYGCatalogos.GuardarPartida(catalogo, origen, i, "METRADO-COPIA", "FRENTE REUTILIZABLE", "m");
        var insertada = MYGCatalogos.InsertarPartida(new MYGPresupuestoDocumento { Nombre = "DESTINO CATÁLOGO" },
            catalogo, entrada, null);
        Exige(insertada.Costos.MetradoDelphin == null,
            "Insertar un costo desde catálogo trasladó el bloqueo o la revisión nativa de otra obra.");
        pasa("Las plantillas y los costos de catálogo omiten el vínculo de metrado específico de la obra original");
    }
}
