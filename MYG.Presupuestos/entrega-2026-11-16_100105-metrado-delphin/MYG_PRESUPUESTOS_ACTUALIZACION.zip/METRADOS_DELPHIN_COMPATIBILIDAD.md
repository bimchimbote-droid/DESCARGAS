# Intercambio de metrados Excel de Delphin

La importación anterior conservaba la cantidad del presupuesto, pero no leía `costo_unitario.archivo_metrado`: MYG mostraba su plantilla inicial. Las ediciones de esa plantilla se guardaban en el documento adicional de MYG, sin actualizar el libro nativo.

## Comportamiento corregido

- Lee el XLSX almacenado en `archivo_metrado`, sus celdas, fórmulas, formatos y total definido por Delphin. No necesita que `campo_metrado` contenga una dirección: reconoce `total_metrado` en el libro.
- Respeta los nombres nativos `descripcion_metrado`, `unidades`, `cantidadxunidad`, `largo`, `ancho`, `alto`, `parcial_metrado`, `observaciones`, `imagen`, `init_row`, `new_row` y `total_metrado`. No los sustituye por variables independientes de MYG.
- Calcula `ISBLANK` / `ESBLANCO`, necesaria en las fórmulas de dimensiones vacías de Delphin, además de `ROUND`, `IF` y `SUM`.
- Si el total de la hoja coincide con la cantidad original, vincula la cantidad a Excel sin cambiar el importe al abrir. Si difiere, conserva la cantidad del presupuesto y avisa; el usuario decide cuándo actualizarla desde la hoja.
- Al editar valores o fórmulas de filas existentes, actualiza el XLSX, `cantidad_metrado` y los campos correspondientes de la tabla `metrado` en la misma transacción. Mantiene IDs, códigos de editor, otras obras y columnas que no se editaron. Una dimensión vacía mantiene su significado de factor neutro, no se convierte automáticamente en cero.
- Conserva byte por byte un XLSX que no cambió. Al modificar celdas mantiene nombres definidos, estilos, relaciones, objetos y partes ajenas del libro; recalcula sus resultados en caché.
- Recupera hojas nativas de importaciones anteriores únicamente cuando la hoja MYG sigue siendo la plantilla inicial intacta. Una hoja MYG ya editada no se descarta ni se fusiona automáticamente con la original.
- Detecta cambios concurrentes en el archivo y las filas nativas. Una copia/plantilla de catálogo con identidad nueva no conserva el vínculo a la obra de origen.

## Instalación manual

1. En Visual Studio, respaldar o confirmar los cambios locales. La base de esta entrega es `main`, commit `9a2cc85af20ced83e908f60bc68f5d01a4dc9c37`. Comparar antes de reemplazar si existen cambios locales o posteriores.
2. Cerrar MYG y Delphin. Extraer el ZIP de actualización y copiar sus archivos sobre el repositorio conservando las rutas relativas. Los archivos existentes se entregan completos. No hay eliminaciones ni parches que aplicar.
3. Restaurar y compilar con el SDK .NET 10.0.100 o el roll-forward permitido por `global.json`:

   ```powershell
   dotnet restore .\MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build .\MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
   dotnet run --project .\MYG.Pruebas\MYG.Pruebas.csproj -c Release --no-build --no-restore -- --metrado-delphin
   ```

   Con Revit 2027 instalado puede usarse la compilación habitual del repositorio con sus DLL locales. La bandera anterior usa paquetes de referencia para compilar sin esa instalación.
4. Abrir una copia de la base en MYG y elegir la partida del cerco. Deben aparecer «Frente de obra», 1 elemento, cantidad 60, observación y total 60, con la fórmula original.
5. Sobre otra copia, editar la cantidad de esa fila, guardar y volver a abrir el archivo en Delphin. Confirmar los valores y el total en ambos programas. No sobrescribir la base de trabajo hasta completar esta comprobación visual.

No hay paquetes nuevos, migraciones SQL manuales, secretos ni cambios de conexión. No se incluye ninguna base de usuario en la entrega.

## Validación y límites

Las pruebas sintéticas cubren conservación binaria, fórmulas/formatos/nombres, texto numérico, rechazo de formatos no admitidos, recuperación de hojas antiguas, edición con el mismo total, concurrencia y copias/catálogos. La muestra externa se valida solo si se indica su ruta:

```powershell
$env:MYG_QA_METRADO_DELPHIN_SQLITE = 'C:\Pruebas\SuCopia.sqlite'
dotnet run --project .\MYG.Pruebas\MYG.Pruebas.csproj -c Release --no-build --no-restore -- --metrado-delphin
Remove-Item Env:\MYG_QA_METRADO_DELPHIN_SQLITE
```

La comprobación específica de la muestra de esta incidencia busca la partida `CU0000022254` de la captura. Solo modifica una copia temporal. El archivo original se verifica con SHA-256.

El soporte nativo conserva la estructura del libro original: agregar/eliminar/reordenar filas nativas, cambiar formato/estructura, reemplazar imágenes o cambiar la celda total puede rechazarse cuando no se puede garantizar una correspondencia fiel. Para esos cambios, usar Delphin y volver a abrir la base en MYG. Las hojas nuevas o copiadas sin archivo nativo siguen el flujo MYG existente; esta corrección sincroniza los libros nativos ya presentes. Un XLS binario, libro con macros o archivo desconocido no se transforma silenciosamente: se conserva y muestra un aviso.

En Linux se pueden compilar los proyectos Windows y ejecutar las pruebas de SQLite; la interfaz de MYG, Delphin y Revit requiere Windows. La comprobación estructural del archivo no sustituye abrirlo en Delphin.

Los dos fallos previos de la suite de nube (expectativa de fase de renovación y fixture antiguo de permisos de publicación comprimida) son independientes de estos metrados y no se modifican aquí.

## Actualizar el código en GitHub

Esta entrega no hace push a `MYG.Presupuestos`. Después de aplicar y probar: revisar la tabla de archivos y los cambios en **Cambios de Git** de Visual Studio, hacer Commit, comprobar que la rama elegida sea `main`, hacer Push y verificar el commit en GitHub. Publicar el ZIP en `DESCARGAS` no aplica automáticamente el cambio a su repositorio local ni al repositorio del código.
