-- Ejecutar después de 20261030_archivos_sqlite.sql y sus prerrequisitos.
-- No interpreta SQLite ni confía en una máscara enviada por el cliente.
-- Las ediciones BIM se guardan como datos permitidos separados del snapshot.
begin;

do $preflight$
begin
    if to_regprocedure('myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb)') is null
       or to_regprocedure('myg_nube_privado.sqlite_puede_escribir(uuid,uuid)') is null
       or to_regprocedure('myg_nube_privado.expandir_paquete(jsonb)') is null then
        raise exception 'Aplique primero las migraciones de permisos, paquete compacto y archivos SQLite.';
    end if;
end $preflight$;

create or replace function myg_nube_privado.permisos_modulos_validos(p_permisos jsonb)
returns boolean language sql immutable set search_path=pg_catalog as $fn$
    select coalesce(jsonb_typeof(p_permisos)='object'
        and p_permisos ?& array['acu','especificaciones','metrados_excel']
        and p_permisos-array['acu','especificaciones','metrados_excel','metrados_revit']='{}'::jsonb
        and jsonb_typeof(p_permisos->'acu')='boolean'
        and jsonb_typeof(p_permisos->'especificaciones')='boolean'
        and jsonb_typeof(p_permisos->'metrados_excel')='boolean'
        and (not p_permisos ? 'metrados_revit' or jsonb_typeof(p_permisos->'metrados_revit')='boolean'),false);
$fn$;
-- Una máscara de un cliente anterior no concede el nuevo permiso por omisión.
-- Solo el propietario conserva acceso completo; los demás miembros requieren
-- una asignación explícita. No sobrescribir permisos Revit ya configurados.
update public.myg_nube_miembros
set permisos_modulos=permisos_modulos||jsonb_build_object('metrados_revit',rol='propietario')
where not permisos_modulos ? 'metrados_revit';
alter table public.myg_nube_miembros alter column permisos_modulos
    set default '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":false}'::jsonb;

create or replace function myg_nube_privado.bim_permiso_propietario()
returns trigger language plpgsql set search_path=pg_catalog as $fn$
begin
    if new.rol='propietario' then
        new.permisos_modulos:=new.permisos_modulos||'{"metrados_revit":true}'::jsonb;
    end if;
    return new;
end $fn$;
drop trigger if exists myg_bim_permiso_propietario on public.myg_nube_miembros;
create trigger myg_bim_permiso_propietario before insert on public.myg_nube_miembros
    for each row execute function myg_nube_privado.bim_permiso_propietario();

create or replace function myg_nube_privado.sqlite_puede_escribir(p_id uuid,p_usuario uuid)
returns boolean language sql stable security definer set search_path=pg_catalog as $fn$
    select exists(select 1 from public.myg_nube_miembros m where m.proyecto_id=p_id and m.usuario_id=p_usuario
        and m.rol in ('propietario','administrador','editor')
        and myg_nube_privado.permisos_modulos_validos(m.permisos_modulos)
        and m.permisos_modulos @> '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}'::jsonb);
$fn$;

-- Proyección recursiva: conserva solo datos BIM y el contexto de identidad.
-- También se aplica a los JSON embebidos de tablas portables; no basta ocultar
-- el campo en documento y enviarlo dentro de json_documento/json_datos.
create or replace function myg_nube_privado.bim_proyeccion(p_json jsonb)
returns jsonb language plpgsql immutable set search_path=pg_catalog as $fn$
declare j jsonb; r jsonb:='{}'::jsonb; v jsonb; par record; a jsonb;
begin
    if jsonb_typeof(p_json)='array' then
        select coalesce(jsonb_agg(x order by x::text),'[]'::jsonb) into a
        from (select myg_nube_privado.bim_proyeccion(value) x from jsonb_array_elements(p_json)) s
        where x<>'{}'::jsonb and x<>'[]'::jsonb;
        return case when a='[]'::jsonb then '{}'::jsonb else a end;
    elsif jsonb_typeof(p_json)<>'object' or p_json is null then return '{}'::jsonb;
    end if;
    j:=myg_nube_privado.json_minusculas(p_json);
    for par in select * from jsonb_each(j) loop
        if par.key=any(array['plantilla','filtros','idconfiguracionbibliotecamyg','catalogobim','activosrevit']) then
            if par.value not in ('null'::jsonb,'""'::jsonb,'[]'::jsonb,'{}'::jsonb) then
                r:=r||jsonb_build_object(par.key,par.value);
            end if;
        elsif par.key='creadaparabim' and par.value='true'::jsonb then
            r:=r||jsonb_build_object(par.key,par.value,'descripcion',j->'descripcion','unidad',j->'unidad','parentid',j->'parentid');
        elsif par.key='cantidadfiltros' and par.value<>'1'::jsonb then r:=r||jsonb_build_object(par.key,par.value);
        elsif par.key=any(array['parametro','regla','valor']) and j ? 'id' then
            if par.value not in ('null'::jsonb,'""'::jsonb) then r:=r||jsonb_build_object(par.key,par.value); end if;
        elsif par.key='metradosbim' and par.value not in ('null'::jsonb,'[]'::jsonb) then
            r:=r||jsonb_build_object(par.key,par.value);
        elsif par.key='fuentemetrado' and lower(par.value#>>'{}') in ('bim','2') then
            r:=r||jsonb_build_object(par.key,par.value,'cantidad',j->'cantidad');
        elsif jsonb_typeof(par.value) in ('array','object') then
            v:=myg_nube_privado.bim_proyeccion(par.value);
            if v<>'{}'::jsonb then r:=r||jsonb_build_object(par.key,v); end if;
        end if;
    end loop;
    if r<>'{}'::jsonb and j ? 'id' then
        r:=r||jsonb_build_object('id',upper(j->>'id'))
            ||myg_nube_privado.elegir_campos(j,array['idlocalmyg','idpropuesta','idinternodelphin','parentid',
                'idpresupuestorevit','idproyectorevit','origen','estado','tipopropuesta']);
    end if;
    return r;
end $fn$;

create or replace function myg_nube_privado.bim_paquete(p_paquete jsonb)
returns jsonb language plpgsql immutable set search_path=pg_catalog as $fn$
declare p jsonb:=myg_nube_privado.expandir_paquete(p_paquete); t jsonb; f jsonb; r jsonb;
    n text; k record; proyectado jsonb; salida jsonb; filas jsonb; tablas jsonb:='{}'::jsonb;
begin
    salida:=myg_nube_privado.bim_proyeccion(p-'tablas');
    for t in select value from jsonb_array_elements(p->'tablas') loop
        t:=myg_nube_privado.json_minusculas(t); n:=lower(t->>'nombre'); filas:='[]'::jsonb;
        if tablas ? n then raise exception using errcode='22023',message='MYG_TABLAS_AMBIGUAS'; end if;
        for f in select value from jsonb_array_elements(t->'filas') loop
            r:=myg_nube_privado.fila_portable(t,f); proyectado:='{}'::jsonb;
            for k in select * from jsonb_each(r) loop
                if k.key in ('json_documento','json_datos','json_plantilla') and k.value->>'tipo'='texto' then
                    proyectado:=proyectado||jsonb_build_object(k.key,myg_nube_privado.bim_proyeccion((k.value->>'valor')::jsonb));
                elsif n like '%bim%' then proyectado:=r;
                end if;
            end loop;
            -- Conservar la identidad nativa si hay BIM en una fila JSON.
            if exists(select 1 from jsonb_each(proyectado) where value<>'{}'::jsonb) then
                proyectado:=proyectado||myg_nube_privado.elegir_campos(r,array['id','presupuesto_id','proyecto_id']);
                filas:=filas||jsonb_build_array(proyectado);
            end if;
        end loop;
        if filas<>'[]'::jsonb then
            select jsonb_agg(value order by value::text) into filas from jsonb_array_elements(filas);
            tablas:=tablas||jsonb_build_object(n,filas);
        end if;
    end loop;
    return salida||jsonb_build_object('tablas',tablas);
end $fn$;

-- Copiar la implementación instalada una sola vez; conservar los guards de
-- ACU, especificaciones y Excel en todos los formatos JSON anteriores.
do $copiar$
begin
    if to_regprocedure('myg_nube_privado.exigir_modulos_sin_bim(jsonb,jsonb,jsonb)') is null then
        execute replace(pg_get_functiondef('myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb)'::regprocedure),
            'FUNCTION myg_nube_privado.exigir_modulos(', 'FUNCTION myg_nube_privado.exigir_modulos_sin_bim(');
    end if;
end $copiar$;
create or replace function myg_nube_privado.exigir_modulos(p_anterior jsonb,p_nuevo jsonb,p_permisos jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
begin
    if not myg_nube_privado.permisos_modulos_validos(p_permisos) then
        raise exception using errcode='42501',message='MYG_PERMISOS_MODULOS_INVALIDOS';
    end if;
    perform myg_nube_privado.exigir_modulos_sin_bim(p_anterior,p_nuevo,p_permisos-'metrados_revit');
    if not coalesce((p_permisos->>'metrados_revit')::boolean,false)
        and myg_nube_privado.bim_paquete(p_anterior) is distinct from myg_nube_privado.bim_paquete(p_nuevo) then
        raise exception using errcode='42501',message='MYG_MODULO_SOLO_LECTURA_METRADOS_REVIT';
    end if;
end $fn$;

-- El formato Gzip solo puede omitir la inspección de textos con los CUATRO
-- permisos. No cambiar firmas públicas ni el contrato de idempotencia.
do $comprimido$
declare d text;
begin
    if to_regprocedure('public.myg_nube_guardar_comprimido(uuid,uuid,bigint,jsonb,text,text)') is not null then
        d:=pg_get_functiondef('public.myg_nube_guardar_comprimido(uuid,uuid,bigint,jsonb,text,text)'::regprocedure);
        d:=replace(d,'v_permisos<>''{"acu":true,"especificaciones":true,"metrados_excel":true}''::jsonb',
            'not (v_permisos @> ''{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}''::jsonb)');
        execute d;
    end if;
end $comprimido$;

create table if not exists myg_nube_privado.bim_documentos(
    proyecto_id uuid not null references public.myg_nube_proyectos(id) on delete cascade,
    documento_id text not null, revision bigint not null check(revision>=1),
    contenido jsonb not null, actualizado_en timestamptz not null default clock_timestamp(),
    primary key(proyecto_id,documento_id)
);
create table if not exists myg_nube_privado.bim_operaciones(
    usuario_id uuid not null, operacion_id uuid not null, proyecto_id uuid not null,
    solicitud jsonb not null,respuesta jsonb not null,
    creado_en timestamptz not null default clock_timestamp(),primary key(usuario_id,operacion_id)
);
alter table myg_nube_privado.bim_documentos enable row level security;
alter table myg_nube_privado.bim_operaciones enable row level security;
revoke all on myg_nube_privado.bim_documentos,myg_nube_privado.bim_operaciones from public,anon,authenticated,service_role;

create or replace function myg_nube_privado.bim_validar(p_documento_id text,p_contenido jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
declare p jsonb; i jsonb; f jsonb; c jsonb; presupuestos text[]:=array[]::text[]; partidas text[]; s text;
begin
    if p_documento_id is null or length(btrim(p_documento_id)) not between 1 and 200
       or p_contenido is null or jsonb_typeof(p_contenido)<>'object'
       or p_contenido-array['presupuestos']<>'{}'::jsonb
       or jsonb_typeof(p_contenido->'presupuestos') is distinct from 'array'
       or octet_length(p_contenido::text)>33554432 then
        raise exception using errcode='22023',message='MYG_BIM_CONTENIDO_INVALIDO';
    end if;
    for p in select value from jsonb_array_elements(p_contenido->'presupuestos') loop
        if jsonb_typeof(p)<>'object' or p-array['id','cantidad_filtros','partidas']<>'{}'::jsonb
           or jsonb_typeof(p->'id') is distinct from 'string' or length(btrim(p->>'id')) not between 1 and 200
           or upper(p->>'id')=any(presupuestos)
           or jsonb_typeof(p->'cantidad_filtros') is distinct from 'number'
           or coalesce(p->>'cantidad_filtros','') !~ '^[1-8]$'
           or jsonb_typeof(p->'partidas') is distinct from 'array' then
            raise exception using errcode='22023',message='MYG_BIM_PRESUPUESTO_INVALIDO';
        end if;
        presupuestos:=array_append(presupuestos,upper(p->>'id')); partidas:=array[]::text[];
        for i in select value from jsonb_array_elements(p->'partidas') loop
            if jsonb_typeof(i)<>'object'
               or i-array['id','creada_para_bim','descripcion','unidad','parent_id','catalogo_bim','plantilla','filtros',
                   'id_configuracion_biblioteca_myg','parametro','regla','valor']<>'{}'::jsonb
               or jsonb_typeof(i->'id') is distinct from 'string' or length(btrim(i->>'id')) not between 1 and 200
               or upper(i->>'id')=any(partidas) or jsonb_typeof(i->'creada_para_bim') is distinct from 'boolean'
               or jsonb_typeof(i->'filtros') is distinct from 'array' then
                raise exception using errcode='22023',message='MYG_BIM_PARTIDA_INVALIDA';
            end if;
            partidas:=array_append(partidas,upper(i->>'id'));
            if jsonb_array_length(i->'filtros')>8 then raise exception using errcode='22023',message='MYG_BIM_MAXIMO_OCHO_FILTROS'; end if;
            if i->'creada_para_bim'='true'::jsonb then
                if jsonb_typeof(i->'descripcion') is distinct from 'string' or length(btrim(i->>'descripcion')) not between 1 and 4000
                   or jsonb_typeof(i->'unidad') is distinct from 'string' or length(i->>'unidad')>100 then
                    raise exception using errcode='22023',message='MYG_BIM_ALTA_INVALIDA';
                end if;
            elsif i ?| array['descripcion','unidad','parent_id','catalogo_bim'] then
                raise exception using errcode='42501',message='MYG_BIM_FILA_ORIGINAL_PROTEGIDA';
            end if;
            foreach s in array array['plantilla','id_configuracion_biblioteca_myg','parametro','regla','valor','parent_id'] loop
                if i ? s and (jsonb_typeof(i->s) not in ('string','null') or length(i->>s)>4000) then
                    raise exception using errcode='22023',message='MYG_BIM_TEXTO_INVALIDO';
                end if;
            end loop;
            for f in select value from jsonb_array_elements(i->'filtros') loop
                if jsonb_typeof(f)<>'object' or f-array['parametro','regla','valor']<>'{}'::jsonb then
                    raise exception using errcode='22023',message='MYG_BIM_FILTRO_INVALIDO';
                end if;
                foreach s in array array['parametro','regla','valor'] loop
                    if not f ? s or jsonb_typeof(f->s) not in ('string','null') or length(f->>s)>4000 then
                        raise exception using errcode='22023',message='MYG_BIM_FILTRO_INVALIDO';
                    end if;
                end loop;
            end loop;
            c:=i->'catalogo_bim';
            if c is not null and c<>'null'::jsonb then
                if jsonb_typeof(c)<>'object' or c-array['id','codigo','ruta_sqlite','revision']<>'{}'::jsonb
                   or jsonb_typeof(c->'id') is distinct from 'string' or length(btrim(c->>'id')) not between 1 and 200
                   or jsonb_typeof(c->'codigo') is distinct from 'string' or length(c->>'codigo')>200
                   or jsonb_typeof(c->'ruta_sqlite') is distinct from 'string' or length(c->>'ruta_sqlite')>4000
                   or coalesce(c->>'revision','') !~ '^[0-9]{1,9}$' then
                    raise exception using errcode='22023',message='MYG_BIM_CATALOGO_INVALIDO';
                end if;
            end if;
        end loop;
    end loop;
end $fn$;

create or replace function public.myg_nube_bim_abrir(p_id uuid,p_documento_id text)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); r bigint; b myg_nube_privado.bim_documentos%rowtype;
begin
    select p.revision into r from public.myg_nube_proyectos p join public.myg_nube_miembros m
        on m.proyecto_id=p.id and m.usuario_id=u where p.id=p_id;
    if r is null then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    if p_documento_id is null or length(btrim(p_documento_id)) not between 1 and 200 then
        raise exception using errcode='22023',message='MYG_BIM_DOCUMENTO_INVALIDO';
    end if;
    select * into b from myg_nube_privado.bim_documentos where proyecto_id=p_id and documento_id=upper(p_documento_id);
    return jsonb_build_object('revision_base',r,'revision_bim',coalesce(b.revision,0),
        'contenido',coalesce(b.contenido,'{"presupuestos":[]}'::jsonb));
end $fn$;

create or replace function public.myg_nube_bim_guardar(p_id uuid,p_documento_id text,p_operacion uuid,
    p_revision_base bigint,p_revision_bim bigint,p_contenido jsonb)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); r bigint; b myg_nube_privado.bim_documentos%rowtype;
    rol text; permisos jsonb; solicitud jsonb; respuesta jsonb; previa myg_nube_privado.bim_operaciones%rowtype;
begin
    if p_operacion is null or p_operacion='00000000-0000-0000-0000-000000000000'::uuid
       or p_revision_base is null or p_revision_base<1 or p_revision_bim is null or p_revision_bim<0
       or p_revision_bim>=9223372036854775807 then
        raise exception using errcode='22023',message='MYG_BIM_OPERACION_INVALIDA';
    end if;
    begin
        select revision into r from public.myg_nube_proyectos where id=p_id for update nowait;
    exception when lock_not_available then raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO'; end;
    select m.rol,m.permisos_modulos into rol,permisos from public.myg_nube_miembros m where proyecto_id=p_id and usuario_id=u;
    if r is null or rol is null or rol not in ('propietario','administrador','editor')
       or not myg_nube_privado.permisos_modulos_validos(permisos)
       or not coalesce((permisos->>'metrados_revit')::boolean,false) then
        raise exception using errcode='42501',message='MYG_MODULO_SOLO_LECTURA_METRADOS_REVIT';
    end if;
    perform myg_nube_privado.bim_validar(p_documento_id,p_contenido);
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-bim:'||u::text||':'||p_operacion::text,0)) then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end if;
    solicitud:=jsonb_build_object('documento_id',upper(p_documento_id),'revision_base',p_revision_base,
        'revision_bim',p_revision_bim,'contenido',p_contenido);
    select * into previa from myg_nube_privado.bim_operaciones where usuario_id=u and operacion_id=p_operacion;
    if found then
        if previa.proyecto_id<>p_id or previa.solicitud<>solicitud then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        return previa.respuesta;
    end if;
    select * into b from myg_nube_privado.bim_documentos where proyecto_id=p_id and documento_id=upper(p_documento_id);
    if r<>p_revision_base or coalesce(b.revision,0)<>p_revision_bim then
        respuesta:=jsonb_build_object('estado','conflicto','revision_base',r,'revision_bim',coalesce(b.revision,0),
            'contenido',coalesce(b.contenido,'{"presupuestos":[]}'::jsonb),'operacion_id',p_operacion);
    else
        insert into myg_nube_privado.bim_documentos(proyecto_id,documento_id,revision,contenido)
            values(p_id,upper(p_documento_id),p_revision_bim+1,p_contenido)
            on conflict(proyecto_id,documento_id) do update set revision=excluded.revision,
                contenido=excluded.contenido,actualizado_en=clock_timestamp();
        respuesta:=jsonb_build_object('estado','aplicada','revision_base',r,'revision_bim',p_revision_bim+1,
            'contenido',p_contenido,'operacion_id',p_operacion);
    end if;
    insert into myg_nube_privado.bim_operaciones(usuario_id,operacion_id,proyecto_id,solicitud,respuesta)
        values(u,p_operacion,p_id,solicitud,respuesta);
    return respuesta;
end $fn$;

-- Solo un escritor del snapshot completo puede declarar su integración. Un
-- cambio BIM concurrente conserva su revisión y no puede ser borrado por ACK viejo.
create or replace function public.myg_nube_bim_confirmar_sqlite(p_id uuid,p_revision_base bigint,
    p_documento_id text,p_revision_bim bigint)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare u uuid:=myg_nube_privado.identidad(); r bigint; b bigint;
begin
    select revision into r from public.myg_nube_proyectos where id=p_id for update;
    if not myg_nube_privado.sqlite_puede_escribir(p_id,u) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    select revision into b from myg_nube_privado.bim_documentos where proyecto_id=p_id and documento_id=upper(p_documento_id);
    if r is distinct from p_revision_base or b is distinct from p_revision_bim then
        return jsonb_build_object('estado','conflicto','revision_base',r,'revision_bim',coalesce(b,0));
    end if;
    update myg_nube_privado.bim_documentos set contenido='{"presupuestos":[]}'::jsonb,
        revision=revision+1,actualizado_en=clock_timestamp() where proyecto_id=p_id and documento_id=upper(p_documento_id);
    return jsonb_build_object('estado','aplicada','revision_base',r,'revision_bim',b+1);
end $fn$;

revoke all on function myg_nube_privado.bim_permiso_propietario(),myg_nube_privado.bim_proyeccion(jsonb),
    myg_nube_privado.bim_paquete(jsonb),myg_nube_privado.bim_validar(text,jsonb),
    myg_nube_privado.exigir_modulos_sin_bim(jsonb,jsonb,jsonb),myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb),
    myg_nube_privado.permisos_modulos_validos(jsonb),myg_nube_privado.sqlite_puede_escribir(uuid,uuid)
    from public,anon,authenticated,service_role;
revoke all on function public.myg_nube_bim_abrir(uuid,text),
    public.myg_nube_bim_guardar(uuid,text,uuid,bigint,bigint,jsonb),
    public.myg_nube_bim_confirmar_sqlite(uuid,bigint,text,bigint) from public,anon;
grant execute on function public.myg_nube_bim_abrir(uuid,text),
    public.myg_nube_bim_guardar(uuid,text,uuid,bigint,bigint,jsonb),
    public.myg_nube_bim_confirmar_sqlite(uuid,bigint,text,bigint) to authenticated,service_role;
notify pgrst,'reload schema';
commit;
