-- Ejecutar completo en SQL Editor del proyecto Supabase que usa MYG, como
-- administrador. Solo consulta funciones; no cambia permisos ni datos de obras.
begin transaction read only;

select firma as funcion_requerida, to_regprocedure(firma) is not null as instalada
from (values
    ('myg_nube_privado.permisos_modulos_validos(jsonb)'),
    ('myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb)'),
    ('myg_nube_privado.expandir_paquete(jsonb)'),
    ('myg_nube_privado.sqlite_puede_escribir(uuid,uuid)'),
    ('public.myg_nube_permisos(uuid,uuid,jsonb)'),
    ('public.myg_nube_bim_abrir(uuid,text)'),
    ('public.myg_nube_bim_guardar(uuid,text,uuid,bigint,bigint,jsonb)'),
    ('public.myg_nube_bim_confirmar_sqlite(uuid,bigint,text,bigint)')
) as funciones(firma);

do $diagnostico$
declare acepta_revit boolean;
begin
    if to_regprocedure('myg_nube_privado.permisos_modulos_validos(jsonb)') is null then
        raise notice 'FALTA_BASE: no existe el validador de permisos. Revise las migraciones anteriores antes de instalar BIM.';
        return;
    end if;
    execute 'select myg_nube_privado.permisos_modulos_validos($1)'
        into acepta_revit
        using '{"acu":false,"especificaciones":false,"metrados_excel":false,"metrados_revit":true}'::jsonb;
    if acepta_revit is true then
        raise notice 'ACEPTA_METRADOS_REVIT: el validador reconoce los cuatro permisos. Compruebe también las funciones de la tabla de resultados.';
    else
        raise notice 'FALTA_ACTUALIZACION_BIM: el validador rechaza metrados_revit; es compatible con el error 22023 de la captura. Ejecute completa la migración 20261104_modeladores_bim.sql después de sus prerrequisitos.';
    end if;
end $diagnostico$;

rollback;
