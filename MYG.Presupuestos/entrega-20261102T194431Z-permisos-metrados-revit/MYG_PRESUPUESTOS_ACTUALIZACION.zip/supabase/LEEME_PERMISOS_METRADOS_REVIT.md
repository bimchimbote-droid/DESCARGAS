# Error 400 / 22023 al conceder Metrados Revit

## A. Resumen de la implementación

La captura muestra un rechazo de `myg_nube_permisos`. El validador de la
migración de roles anterior admite solo ACU, especificaciones y metrados Excel;
rechaza la cuarta clave `metrados_revit` con `22023`. Es compatible con que falte
la actualización BIM en el proyecto Supabase usado por la aplicación. Sin acceso
al servidor real, no se afirma que esa sea su única causa posible.

El diagnóstico incluido comprueba la instalación sin leer datos de obras. La
migración BIM reconoce el cuarto permiso. Se corrigió su conversión de máscaras
antiguas: solo el propietario obtiene Revit automáticamente; administradores,
editores y lectores reciben `false` hasta una asignación explícita. Los permisos
Revit ya configurados se conservan, incluso al repetir la instalación, junto con
los otros tres permisos y los roles.

No se modificaron C#, proyectos .NET, dependencias, ventanas ni integración Revit.
La migración instala funciones/tablas BIM en PostgreSQL y actualiza máscaras de
permisos; no hay que reinstalar Revit para corregir este rechazo del servidor.

## B. Archivos de la entrega

| Ruta relativa | Acción | Descripción |
| --- | --- | --- |
| `supabase/migraciones/20261104_modeladores_bim.sql` | REEMPLAZAR | Migración completa con asignación inicial explícita del permiso BIM. |
| `supabase/pruebas/modeladores_bim.sql` | REEMPLAZAR | Regresión de máscaras legadas, permisos explícitos y diagnóstico. Solo pruebas desechables. |
| `supabase/diagnosticos/20261104_permisos_metrados_revit_solo_lectura.sql` | CREAR | Consulta firmas instaladas y comprueba una máscara sintética. |
| `supabase/LEEME_PERMISOS_METRADOS_REVIT.md` | CREAR | Estas instrucciones y resultados reales. |

Base comprobada: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`e0b4f9ebf26ce3e8ba337dbea774f22159052c14`. La rama local del entorno es `work`,
basada en ese mismo commit. Se comprobó que coincidía con `main` remoto antes
del cambio.

## C. Descarga

Nombre de la entrega: `MYG_PRESUPUESTOS_ACTUALIZACION.zip`, solo los cuatro
archivos de la tabla, completos y con sus rutas relativas. La publicación se
gestiona por separado en `bimchimbote-droid/DESCARGAS`, en una ruta nueva por
entrega. No confundir preparar el ZIP con subirlo o verificar su descarga.

## D. Instalación manual

1. Respaldar o confirmar los cambios locales en Visual Studio. Hacer también
   un respaldo del proyecto Supabase antes de aplicar la migración.
2. Extraer el ZIP y copiar sus cuatro archivos conservando las carpetas, por
   ejemplo dentro de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`. Comparar antes de
   reemplazar si se modificaron estos archivos después del commit base.
3. Abrir el proyecto Supabase que realmente usa MYG y entrar en **SQL Editor**.
   Como administrador, ejecutar completo el archivo de diagnóstico. En sus
   mensajes, `FALTA_ACTUALIZACION_BIM` confirma que ese validador rechaza el
   permiso Revit. `FALTA_BASE` indica que faltan migraciones anteriores.
4. Confirmar que ya se aplicó `20261030_archivos_sqlite.sql` y sus prerrequisitos.
   Si faltan, seguir su orden de instalación existente; no reinstalar toda la
   base a ciegas. El preflight BIM aborta la transacción si faltan sus funciones
   básicas.
5. Ejecutar **TODO** `supabase/migraciones/20261104_modeladores_bim.sql` en
   SQL Editor, incluido `BEGIN` hasta `COMMIT`. No ejecutar solo el UPDATE.
   Corregir cualquier error antes de seguir. Si una ejecución fallida deja la
   sesión en transacción abortada, ejecutar `ROLLBACK;` antes del reintento.
6. Repetir el diagnóstico: debe informar `ACEPTA_METRADOS_REVIT` y todas las
   funciones de su tabla deben estar instaladas. La migración también solicita
   la recarga del esquema PostgREST.
7. En MYG, cerrar el mensaje, pulsar **Actualizar**, seleccionar al colaborador
   de rol **editor** o **administrador**, abrir **Permisos por módulo**, marcar
   **Editar Metrados Revit (partidas y filtros BIM)** y confirmar con una cuenta
   que pueda administrar esa obra. No cambiar los otros permisos para resolverlo.
   El rol lector sigue sin poder editar ningún módulo.
8. Actualizar/reabrir la obra en la sesión del colaborador. Verificar que puede
   editar partidas/filtros BIM y que los módulos no autorizados siguen en solo
   lectura. No hace falta recompilar el ejecutable para aplicar este SQL.

Si el diagnóstico ya acepta Revit y el error continúa, comprobar que se usó el
mismo proyecto Supabase, que el destinatario sigue siendo miembro y que el actor
puede administrar ese rol. `22023` también cubre otros parámetros inválidos.
Conservar la nueva referencia del error para correlacionarla con los registros
del servidor; no enviar contraseñas ni tokens.

## E. Configuración adicional

Se requieren permisos administrativos en SQL Editor y las migraciones anteriores
de roles, paquete compacto y archivos SQLite. No añadir claves administrativas
a MYG, hacer públicos los buckets ni desactivar RLS para solucionar este error.
La fecha del nombre `20261104_modeladores_bim.sql` es un identificador de archivo;
no es necesario esperar a esa fecha para ejecutarlo.

## F. Compilación y validación

Entorno usado: Linux x64, SDK .NET **10.0.100**, SQLite real en las pruebas C#,
PostgreSQL **17** desechable en Docker. No se accedió al Supabase del usuario.

Desde la raíz del repositorio, con .NET 10 activo:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --modeladores-bim
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --modeladores-bim
```

La compilación ejecutada incluyó restauración: **0 errores y 0 advertencias**.
El selector principal terminó con **8 comprobaciones correctas**. El selector de
nube completó los dos grupos existentes: plantilla/filtros nativos y edición BIM
compartida con HTTP simulado y SQLite. No son pruebas contra Revit o Supabase real.

En Linux con Docker local y .NET activo:

```bash
bash scripts/pruebas/Probar-ModeladoresBim.sh
```

La versión final terminó con exit 0 y `MODELADORES_BIM_SQL_APROBADOS`:
**196 comprobaciones SQL aprobadas**, incluidos los prerrequisitos y tres casos
nuevos agrupados de migración/reinstalación/validador. Se comprobó el diagnóstico
en los tres estados: sin base, validador anterior y BIM instalado. La migración
se aplicó dos veces, y se probaron concesión y revocación mediante la RPC real
en el PostgreSQL desechable. Nunca ejecutar `supabase/pruebas/*.sql` en producción.

La suite completa de nube no se repitió para este ajuste SQL. En la configuración
previa del entorno presentó un fallo de diagnóstico de renovación de sesión en
`PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`, ajeno a esta entrega;
no se ha corregido ni se declara esa suite completa aprobada.

Pendiente: aplicar/diagnosticar el proyecto Supabase real y validar visualmente
Windows, la sesión del colaborador y Revit 2027 en el equipo del usuario.

## G. Publicación del código en GitHub

No se ha hecho commit ni push al repositorio del código. Después de aplicar y
validar la entrega, abrir **Cambios de Git** en Visual Studio, revisar los cuatro
archivos y su diff, confirmar con un mensaje como `Corregir instalación de permisos
Metrados Revit`, hacer Push y comprobar la rama elegida en GitHub (`main` si esa
es la rama de trabajo local). La subida del ZIP a DESCARGAS no sustituye estos pasos.

## H. Advertencias y pendientes

- La migración completa instala la funcionalidad BIM; no debe aplicarse sobre
  una base sin los prerrequisitos indicados. No se han tocado bases privadas.
- Si se ejecutó anteriormente la versión que concedía Revit a todos, esta
  corrección no revoca decisiones existentes porque no puede distinguirlas de
  permisos explícitos. Revisar esos permisos manualmente por obra.
- En una instalación anterior con tres permisos, un editor/administrador deberá
  recibir Revit explícitamente si necesita escritura completa del snapshot SQLite.
- Reemplazar archivos completos puede perder cambios locales o posteriores;
  revisar diferencias y respaldar antes de copiar. La entrega no se aplica sola.
