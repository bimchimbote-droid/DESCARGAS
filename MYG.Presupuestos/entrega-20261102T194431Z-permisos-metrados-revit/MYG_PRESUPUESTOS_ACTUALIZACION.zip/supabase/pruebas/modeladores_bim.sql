-- PostgreSQL desechable. Sin Supabase ni datos privados.
\set ON_ERROR_STOP on
\ir ../diagnosticos/20261104_permisos_metrados_revit_solo_lectura.sql
\ir archivos_sqlite.sql
reset role;
\ir ../diagnosticos/20261104_permisos_metrados_revit_solo_lectura.sql

-- Cuatro miembros legados sin la nueva clave. Variar las otras máscaras para
-- detectar tanto concesiones implícitas como pérdida de permisos anteriores.
insert into public.myg_nube_proyectos(id,propietario,nombre,contenido) values
 ('bf100000-0000-0000-0000-000000000001','bf200000-0000-0000-0000-000000000001',
  'Migración de permisos BIM QA','{}');
insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol,permisos_modulos) values
 ('bf100000-0000-0000-0000-000000000001','bf200000-0000-0000-0000-000000000001','propietario',
  '{"acu":true,"especificaciones":false,"metrados_excel":true}'),
 ('bf100000-0000-0000-0000-000000000001','bf200000-0000-0000-0000-000000000002','administrador',
  '{"acu":false,"especificaciones":true,"metrados_excel":false}'),
 ('bf100000-0000-0000-0000-000000000001','bf200000-0000-0000-0000-000000000003','editor',
  '{"acu":true,"especificaciones":true,"metrados_excel":false}'),
 ('bf100000-0000-0000-0000-000000000001','bf200000-0000-0000-0000-000000000004','lector',
  '{"acu":false,"especificaciones":false,"metrados_excel":true}');
create table qa.bim_miembros_antes as select * from public.myg_nube_miembros;
\ir ../migraciones/20261104_modeladores_bim.sql
select qa.exige((select count(*) from public.myg_nube_miembros)=(select count(*) from qa.bim_miembros_antes)
    and not exists(select 1 from qa.bim_miembros_antes a
        left join public.myg_nube_miembros m using(proyecto_id,usuario_id)
        where m.usuario_id is null or m.rol is distinct from a.rol
            or (m.permisos_modulos-'metrados_revit') is distinct from a.permisos_modulos
            or m.permisos_modulos->'metrados_revit' is distinct from to_jsonb(a.rol='propietario')),
    'BIM: migrar máscaras legadas conserva miembros, roles y tres permisos; solo propietario obtiene Revit');

-- Simular permisos explícitos de una instalación que ya fue actualizada. La
-- reinstalación debe respetar true y false, también en un propietario existente.
update public.myg_nube_miembros
set permisos_modulos=permisos_modulos||jsonb_build_object('metrados_revit',rol in ('administrador','editor'))
where proyecto_id='bf100000-0000-0000-0000-000000000001';
create table qa.bim_miembros_reinstalacion as select * from public.myg_nube_miembros;
\ir ../migraciones/20261104_modeladores_bim.sql
\ir ../diagnosticos/20261104_permisos_metrados_revit_solo_lectura.sql
select qa.exige(not exists(
    (select * from public.myg_nube_miembros except select * from qa.bim_miembros_reinstalacion)
    union all
    (select * from qa.bim_miembros_reinstalacion except select * from public.myg_nube_miembros)),
    'BIM: reinstalar conserva exactamente roles, máscaras y permisos Revit explícitos true y false');
select qa.exige(not exists(select 1 from public.myg_nube_miembros where not permisos_modulos ? 'metrados_revit'),
    'BIM: migración repetible preserva permisos existentes');
select qa.exige(myg_nube_privado.permisos_modulos_validos(
        '{"acu":false,"especificaciones":true,"metrados_excel":false}')
    and myg_nube_privado.permisos_modulos_validos(
        '{"acu":false,"especificaciones":false,"metrados_excel":false,"metrados_revit":true}')
    and myg_nube_privado.permisos_modulos_validos(
        '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":false}')
    and not myg_nube_privado.permisos_modulos_validos(
        '{"acu":true,"especificaciones":true,"metrados_excel":true,"otro_modulo":true}')
    and not myg_nube_privado.permisos_modulos_validos(
        '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true,"otro_modulo":false}')
    and not myg_nube_privado.permisos_modulos_validos(
        '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":"true"}'),
    'BIM: validador admite tres o cuatro booleanos conocidos y rechaza claves extra o tipos inválidos');
select qa.exige(not has_function_privilege('anon','public.myg_nube_bim_guardar(uuid,text,uuid,bigint,bigint,jsonb)','execute')
    and not has_table_privilege('authenticated','myg_nube_privado.bim_documentos','select'),
    'BIM: auxiliares, tablas y escritura anónima cerrados');
create table qa.bim_payload(nombre text primary key,contenido jsonb);
insert into qa.bim_payload values('uno',
 '{"presupuestos":[{"id":"QA-PRESUPUESTO","cantidad_filtros":1,"partidas":[{"id":"QA-PARTIDA","creada_para_bim":false,"plantilla":"PLANTILLA QA","filtros":[{"parametro":"Nivel","regla":"igual","valor":"01"}]}]}]}'::jsonb);
insert into qa.bim_payload select 'muchos',jsonb_build_object('presupuestos',jsonb_build_array(
    jsonb_build_object('id','QA-PRESUPUESTO','cantidad_filtros',8,'partidas',jsonb_agg(jsonb_build_object(
        'id','MYG-ALTA-'||n,'creada_para_bim',true,'descripcion','Alta BIM '||n,'unidad','m²',
        'parent_id',null,'catalogo_bim',jsonb_build_object('id','CAT-1','codigo','CAT-001','ruta_sqlite','catalogo.sqlite','revision',1),
        'plantilla','PLANTILLA QA','filtros',jsonb_build_array(jsonb_build_object('parametro','Nivel','regla','igual','valor','01')))))))
    from generate_series(1,1200) n;
grant select on qa.bim_payload to authenticated;
insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values
 ('d9000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000007','editor'),
 ('d9000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','lector');
select qa.exige((select permisos_modulos->'metrados_revit'='false'::jsonb from public.myg_nube_miembros
    where proyecto_id='d9000000-0000-0000-0000-000000000001' and usuario_id='00000000-0000-0000-0000-000000000007'),
    'BIM: nuevas altas requieren permiso explícito');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige(public.myg_nube_bim_abrir('d9000000-0000-0000-0000-000000000001','doc-qa')->>'revision_bim'='0',
    'BIM: lectura inicial no escribe');
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,0,contenido)
    from qa.bim_payload where nombre='uno'$$,'42501','BIM: llamada directa sin permiso denegada');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_nube_permisos('d9000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000007',
    '{"acu":false,"especificaciones":false,"metrados_excel":false,"metrados_revit":true}');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige((select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',
    'bf000000-0000-0000-0000-000000000001',3,0,contenido)->>'estado'='aplicada' from qa.bim_payload where nombre='uno'),
    'BIM: solo permiso Revit permite editar sin los otros tres');
select qa.exige((select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',
    'bf000000-0000-0000-0000-000000000001',3,0,contenido)->>'revision_bim'='1' from qa.bim_payload where nombre='uno'),
    'BIM: ACK perdido reintenta UUID sin duplicar revisión');
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',
    'bf000000-0000-0000-0000-000000000001',3,0,contenido) from qa.bim_payload where nombre='muchos'$$,
    '22023','BIM: UUID no admite cuerpo distinto');
select qa.exige((select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,0,contenido)->>'estado'='conflicto'
    from qa.bim_payload where nombre='muchos'),'BIM: revisión BIM atrasada conserva el remoto');
select qa.exige((select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),2,1,contenido)->>'estado'='conflicto'
    from qa.bim_payload where nombre='muchos'),'BIM: revisión SQLite atrasada conserva el remoto');
select qa.exige((select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,1,contenido)->>'revision_bim'='2'
    from qa.bim_payload where nombre='muchos'),'BIM: 1200 altas con referencia catálogo, sin límite artificial');
select qa.exige(jsonb_array_length(public.myg_nube_bim_abrir('d9000000-0000-0000-0000-000000000001','DOC-QA')
    #>'{contenido,presupuestos,0,partidas}')=1200,'BIM: recuperar por identidad conserva altas y filtros');
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,2,
    jsonb_set(contenido,'{presupuestos,0,partidas,0,Costos}','{"PrecioDirecto":999}')) from qa.bim_payload where nombre='uno'$$,
    '22023','BIM: servidor rechaza campos ACU ajenos a su whitelist');
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,2,
    jsonb_set(contenido,'{presupuestos,0,partidas,0,descripcion}','"Renombrar original"')) from qa.bim_payload where nombre='uno'$$,
    '42501','BIM: no cambia descripción de fila original');
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,2,
    jsonb_set(contenido,'{presupuestos,0,cantidad_filtros}','null')) from qa.bim_payload where nombre='uno'$$,
    '22023','BIM: cantidad nula no elude validación');
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,2,
    jsonb_set(contenido,'{presupuestos,0,cantidad_filtros}','"1"')) from qa.bim_payload where nombre='uno'$$,
    '22023','BIM: cantidad string no suplanta entero');
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,2,
    jsonb_set(contenido,'{presupuestos,0,partidas,0,filtros}',(select jsonb_agg(jsonb_build_object('parametro','Nivel','regla','igual','valor','1'))
        from generate_series(1,9)))) from qa.bim_payload where nombre='uno'$$,'22023','BIM: noveno filtro rechazado');
select qa.rechaza($$select public.myg_nube_bim_confirmar_sqlite('d9000000-0000-0000-0000-000000000001',3,'doc-qa',2)$$,
    '42501','BIM: modelador restringido no retira la capa');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',gen_random_uuid(),3,2,contenido)
    from qa.bim_payload where nombre='uno'$$,'42501','BIM: lector no escribe');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_bim_confirmar_sqlite('d9000000-0000-0000-0000-000000000001',3,'doc-qa',1)->>'estado'='conflicto',
    'BIM: ACK anterior no retira cambios concurrentes');
select qa.exige(public.myg_nube_bim_confirmar_sqlite('d9000000-0000-0000-0000-000000000001',3,'doc-qa',2)->>'revision_bim'='3',
    'BIM: integración confirmada avanza revisión y retira solo la capa integrada');
select public.myg_nube_permisos('d9000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000007',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":false}');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_nube_bim_guardar('d9000000-0000-0000-0000-000000000001','doc-qa',
    'bf000000-0000-0000-0000-000000000001',3,0,contenido) from qa.bim_payload where nombre='uno'$$,
    '42501','BIM: revocación también impide replay autorizado anteriormente');
select qa.rechaza($$select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',gen_random_uuid(),3,
    ruta,sha256,bytes) from qa.sqlite_casos where nombre='tercero'$$,'42501','BIM: snapshot opaco no elude permiso Revit');
reset role;
select myg_nube_privado.exigir_modulos(a.contenido,b.contenido,
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":false}')
    from qa.paquetes a,qa.paquetes b where a.nombre='baseline' and b.nombre in ('acu_precio','especificacion','hoja_excel');
select qa.exige(true,'BIM: ACU, especificaciones y Excel JSON siguen independientes del permiso Revit');
select qa.rechaza($$select myg_nube_privado.exigir_modulos(contenido,
    jsonb_set(contenido,'{documento,Presupuestos,0,Items,0,Plantilla}','"PLANTILLA NO AUTORIZADA"'),
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":false}') from qa.paquetes where nombre='baseline'$$,
    '42501','BIM: guard de guardar/guardar_cambios bloquea plantilla con otros tres permisos abiertos');
select qa.rechaza($$select myg_nube_privado.exigir_modulos(contenido,
    jsonb_set(contenido,'{documentos,0,Presupuestos,0,Items,0,Filtros}','[{"Parametro":"Nivel","Regla":"igual","Valor":"1"}]'),
    '{"acu":true,"especificaciones":true,"metrados_excel":true}') from qa.paquetes where nombre='baseline'$$,
    '42501','BIM: documentos secundarios y máscaras legadas no eluden permiso');
select qa.rechaza($$select myg_nube_privado.exigir_modulos(contenido,
    jsonb_set(contenido,'{tablas}',(contenido->'tablas')||jsonb_build_array(jsonb_build_object(
        'Nombre','metrado_bim','Columnas',jsonb_build_array('id','cantidad'),'Filas',jsonb_build_array(jsonb_build_array(
            jsonb_build_object('Tipo','texto','Valor','BIM-1'),jsonb_build_object('Tipo','texto','Valor','999')))))),
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":false}') from qa.paquetes where nombre='baseline'$$,
    '42501','BIM: tabla nativa no elude el guard');
select 'MODELADORES_BIM_SQL_APROBADOS' resultado;
