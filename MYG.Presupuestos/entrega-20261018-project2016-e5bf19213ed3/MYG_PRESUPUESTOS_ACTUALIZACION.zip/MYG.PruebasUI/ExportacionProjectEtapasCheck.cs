using System;
using System.Collections.Generic;
using System.Linq;
using MYG_2027;

internal static class ExportacionProjectEtapasCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var modelo = Modelo(true);
        var adaptador = new Simulado();
        var progreso = new List<MYGProgresoExportacionProject>();
        MYGFlujoExportacionProject.Ejecutar(modelo, true, "resultado.mpp", adaptador, progreso.Add);
        exige(adaptador.Operaciones.Take(2).SequenceEqual(new[] { "iniciar", "recurso:10" }) &&
            adaptador.Operaciones.IndexOf("recurso:20") < adaptador.Operaciones.IndexOf("tarea:1"),
            "Exportar con recursos debe crear todos los recursos antes de la primera tarea.");
        exige(adaptador.Operaciones.IndexOf("tarea:2") < adaptador.Operaciones.IndexOf("asignacion:2:10") &&
            adaptador.Operaciones.IndexOf("asignacion:2:10") < adaptador.Operaciones.IndexOf("tarea:3") &&
            adaptador.Operaciones.IndexOf("tarea:3") < adaptador.Operaciones.IndexOf("asignacion:3:20"),
            "Cada tarea debe existir antes de recibir sus recursos durante el recorrido de tareas.");
        exige(adaptador.Operaciones.IndexOf("asignacion:3:20") < adaptador.Operaciones.FindIndex(x => x.StartsWith("dependencia:", StringComparison.Ordinal)) &&
            adaptador.Operaciones.Count(x => x.StartsWith("dependencia:", StringComparison.Ordinal)) == 1,
            "Las dependencias deben crearse después de todas las tareas y asignaciones.");
        exige(adaptador.Operaciones.TakeLast(5).SequenceEqual(new[] { "finalizar", "guardar:resultado.mpp", "mostrar", "confirmar", "dispose" }),
            "El flujo debe finalizar los datos, guardar, mostrar el MPP, confirmar y liberar sus referencias en ese orden.");
        exige(progreso.First().Etapa == MYGEtapaExportacionProject.Preparando &&
            progreso.Last().Etapa == MYGEtapaExportacionProject.Completado &&
            progreso.All(p => p.Actual >= 0 && p.Total >= p.Actual) &&
            progreso.Any(p => p.Etapa == MYGEtapaExportacionProject.Asignaciones && p.Detalle.Contains("PEÓN", StringComparison.Ordinal)) &&
            progreso.FindLastIndex(p => p.Etapa == MYGEtapaExportacionProject.Tareas) < progreso.FindIndex(p => p.Etapa == MYGEtapaExportacionProject.Dependencias),
            "El progreso debe identificar las operaciones reales, sus contadores y la fase posterior de dependencias.");
        var finalizacion = progreso.Single(p => p.Etapa == MYGEtapaExportacionProject.Finalizando);
        exige(finalizacion.Actual == 0 && finalizacion.Total == 0 &&
            finalizacion.Detalle.Contains("validando", StringComparison.Ordinal) &&
            progreso.FindLastIndex(p => p.Etapa == MYGEtapaExportacionProject.Dependencias) < progreso.IndexOf(finalizacion) &&
            progreso.IndexOf(finalizacion) < progreso.FindIndex(p => p.Etapa == MYGEtapaExportacionProject.Guardando),
            "La finalización y validación deben mostrar una etapa indeterminada después de las dependencias y antes del guardado.");
        exige(ReferenceEquals(adaptador.Modelo, modelo) && adaptador.DatosTareas[1].Manual &&
            adaptador.DatosTareas[1].Fin - adaptador.DatosTareas[1].Inicio > TimeSpan.FromDays(100) &&
            adaptador.DatosTareas[1].DuracionMinutos == 960 && adaptador.DatosTareas[2].Hito,
            "El adaptador debe recibir las fechas manuales independientes de la duración y los hitos sin convertirlos.");

        var soloTareas = new Simulado();
        var progresoSimple = new List<MYGProgresoExportacionProject>();
        MYGFlujoExportacionProject.Ejecutar(Modelo(false), false, "tareas.mpp", soloTareas, progresoSimple.Add);
        exige(!soloTareas.Operaciones.Any(o => o.StartsWith("recurso:", StringComparison.Ordinal) || o.StartsWith("asignacion:", StringComparison.Ordinal)) &&
            !progresoSimple.Any(p => p.Etapa is MYGEtapaExportacionProject.Recursos or MYGEtapaExportacionProject.Asignaciones) &&
            soloTareas.Operaciones.Contains("dependencia:3:2"),
            "Sólo tareas debe omitir recursos y asignaciones, conservando las dependencias y la apertura final.");

        foreach (string fallo in new[] { "iniciar", "recurso:10", "tarea:2", "asignacion:2:10", "dependencia:3:2", "finalizar" })
        {
            var fallido = new Simulado(fallo);
            var avisos = new List<MYGProgresoExportacionProject>();
            bool rechazo = false;
            try { MYGFlujoExportacionProject.Ejecutar(modelo, true, "sin-tocar.mpp", fallido, avisos.Add); }
            catch (InvalidOperationException) { rechazo = true; }
            exige(rechazo && fallido.Operaciones.Last() == "dispose" &&
                !fallido.Operaciones.Any(o => o.StartsWith("guardar:", StringComparison.Ordinal) || o is "mostrar" or "confirmar") &&
                !avisos.Any(p => p.Etapa == MYGEtapaExportacionProject.Completado),
                "Un fallo en " + fallo + " debe liberar el adaptador sin guardar, abrir ni anunciar éxito.");
            if (fallo == "finalizar")
                exige(avisos.Last().Etapa == MYGEtapaExportacionProject.Finalizando &&
                    !avisos.Any(p => p.Etapa == MYGEtapaExportacionProject.Guardando),
                    "Un fallo durante la validación debe identificarse en la etapa de finalización, sin quedar en la última dependencia.");
        }
        foreach (string fallo in new[] { "guardar:sin-tocar.mpp", "mostrar" })
        {
            var fallido = new Simulado(fallo);
            bool rechazo = false;
            try { MYGFlujoExportacionProject.Ejecutar(modelo, true, "sin-tocar.mpp", fallido); }
            catch (InvalidOperationException) { rechazo = true; }
            exige(rechazo && fallido.Operaciones.Last() == "dispose" && !fallido.Operaciones.Contains("confirmar") &&
                (fallo == "mostrar" || !fallido.Operaciones.Contains("mostrar")),
                "Un fallo al guardar o mostrar debe impedir confirmar el resultado y ejecutar su limpieza.");
        }
        var invalido = new Simulado();
        bool rechazado = false;
        try { MYGFlujoExportacionProject.Ejecutar(modelo, false, "invalido.mpp", invalido); }
        catch (InvalidOperationException) { rechazado = true; }
        exige(rechazado && invalido.Operaciones.Count == 0,
            "El indicador sólo tareas debe rechazar recursos accidentales antes de activar Project.");
        var roto = modelo with { Dependencias = new[] { new MYGDependenciaExportacionProject(3, 999, MYGTipoVinculo.FC, 0) } };
        invalido = new Simulado(); rechazado = false;
        try { MYGFlujoExportacionProject.Ejecutar(roto, true, "invalido.mpp", invalido); }
        catch (InvalidOperationException) { rechazado = true; }
        exige(rechazado && invalido.Operaciones.Count == 0,
            "Un vínculo sin predecesora real debe rechazarse antes de crear archivos o activar Project.");
    }

    private static MYGModeloExportacionProject Modelo(bool recursos)
    {
        DateTime inicio = new(2026, 1, 5, 8, 0, 0), fin = new(2026, 10, 1, 17, 0, 0);
        var tareas = new[]
        {
            new MYGTareaExportacionProject(1, "r", 0, 1, "1", "01", "OBRA", false, true, false, false,
                inicio, fin, 960, 0, null, null, null, ""),
            new MYGTareaExportacionProject(2, "a", 1, 2, "1.1", "01.01", "MOVILIZACIÓN", true, false, false, false,
                inicio, fin, 960, 25, inicio, fin, 960, "Fechas originales"),
            new MYGTareaExportacionProject(3, "b", 1, 2, "1.2", "01.02", "ENTREGA", false, false, true, false,
                fin, fin, 0, 0, null, null, null, "")
        };
        return new MYGModeloExportacionProject("OBRA", inicio, fin, inicio.Date, 480, 2400, "S/",
            new MYGCalendarioExportacionProject("Obra", Array.Empty<MYGDiaExportacionProject>(), Array.Empty<MYGExcepcionExportacionProject>()), tareas,
            recursos ? new[] { new MYGRecursoExportacionProject(10, 1, "PEÓN", "P", "Mano de obra", "hh", 20),
                new MYGRecursoExportacionProject(20, 0, "CEMENTO", "C", "Materiales", "bol", 25) } : Array.Empty<MYGRecursoExportacionProject>(),
            recursos ? new[] { new MYGAsignacionExportacionProject(2, 10, 8, 8, 0.5m, 160, inicio, fin),
                new MYGAsignacionExportacionProject(3, 20, 2, null, 2, 50, fin, fin) } : Array.Empty<MYGAsignacionExportacionProject>(),
            new[] { new MYGDependenciaExportacionProject(3, 2, MYGTipoVinculo.FC, -480) }, Array.Empty<string>());
    }

    private sealed class Simulado(string fallo = null) : IMYGAdaptadorProject
    {
        internal readonly List<string> Operaciones = new();
        internal readonly List<MYGTareaExportacionProject> DatosTareas = new();
        internal MYGModeloExportacionProject Modelo;
        public void Iniciar(MYGModeloExportacionProject modelo) { Modelo = modelo; Anotar("iniciar"); }
        public void CrearRecurso(MYGRecursoExportacionProject recurso) => Anotar("recurso:" + recurso.Uid);
        public void CrearTarea(MYGTareaExportacionProject tarea) { DatosTareas.Add(tarea); Anotar("tarea:" + tarea.Uid); }
        public void AsignarRecurso(MYGAsignacionExportacionProject asignacion) => Anotar("asignacion:" + asignacion.TareaUid + ":" + asignacion.RecursoUid);
        public void CrearDependencia(MYGDependenciaExportacionProject dependencia) => Anotar("dependencia:" + dependencia.TareaUid + ":" + dependencia.PredecesoraUid);
        public void FinalizarDatos(MYGModeloExportacionProject modelo) => Anotar("finalizar");
        public void GuardarResultado(string destino) => Anotar("guardar:" + destino);
        public void MostrarResultado() => Anotar("mostrar");
        public void ConfirmarResultado() => Anotar("confirmar");
        public void Dispose() => Anotar("dispose");
        private void Anotar(string operacion)
        {
            Operaciones.Add(operacion);
            if (operacion == fallo) throw new InvalidOperationException("Fallo simulado en " + operacion);
        }
    }
}
