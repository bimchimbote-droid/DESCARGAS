using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGExportarProjectForm : Form
{
    private readonly MYGProyectoDocumento proyecto;
    private readonly MYGCronograma plan;
    private readonly string origenSQLite;
    private readonly Action<string, MYGProyectoDocumento, MYGCronograma, bool, Action<MYGProgresoExportacionProject>> exportador;
    private readonly TextBox destino = new() { Name = "cronograma_project_destino", Dock = DockStyle.Fill };
    private readonly Button examinar = new() { Name = "cronograma_project_examinar", Text = "Examinar…", Dock = DockStyle.Fill };
    private readonly CheckBox soloTareas = new() { Name = "cronograma_project_solo_tareas", Text = "Exportar sólo tareas", AutoSize = true, Anchor = AnchorStyles.Left };
    private readonly Label etapa = new() { Name = "cronograma_project_etapa", Dock = DockStyle.Fill, TextAlign = ContentAlignment.BottomLeft };
    private readonly Label detalle = new() { Name = "cronograma_project_detalle", Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly ProgressBar progreso = new() { Name = "cronograma_project_progreso", Dock = DockStyle.Fill, Minimum = 0, Maximum = 1000, MarqueeAnimationSpeed = 30 };
    private readonly Label contador = new() { Name = "cronograma_project_contador", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter };
    private readonly Label error = new() { Name = "cronograma_project_error", Dock = DockStyle.Fill, AutoEllipsis = true, AccessibleName = "Resultado de la exportación" };
    private readonly Button exportar = new() { Name = "cronograma_project_exportar", Text = "Exportar", AutoSize = true, MinimumSize = new Size(104, 30) };
    private readonly Button cerrar = new() { Name = "cronograma_project_cerrar", Text = "Cerrar", AutoSize = true, MinimumSize = new Size(104, 30) };
    private readonly object sincronizacion = new();
    private MYGProgresoExportacionProject ultimoProgreso;
    private bool actualizacionPendiente, exportando;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal string RutaExportada { get; private set; }

    internal MYGExportarProjectForm(MYGProyectoDocumento proyecto, MYGCronograma plan, bool incluirRecursos,
        string origenSQLite = null,
        Action<string, MYGProyectoDocumento, MYGCronograma, bool, Action<MYGProgresoExportacionProject>> exportador = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        ArgumentNullException.ThrowIfNull(plan);
        // El hilo de exportación trabaja con documentos independientes del editor.
        this.proyecto = MYGProyectoStorage.Copia(proyecto);
        this.plan = MYGProyectoStorage.Copia(plan);
        this.origenSQLite = origenSQLite;
        this.exportador = exportador ?? MYGExportacionCronogramaWindows.GuardarProject;
        MYGCronogramaDialogoUI.Preparar(this, "cronograma_project_dialogo", "Exportar a Microsoft Project", new Size(860, 350), redimensionable: true);
        MinimumSize = new Size(680, 360);
        MaximizeBox = false;
        soloTareas.Checked = !incluirRecursos;

        var contenido = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 8,
            Padding = new Padding(18, 14, 18, 8)
        };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        foreach (int alto in new[] { 42, 32, 28, 42, 26, 30 })
            contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, alto));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        var archivo = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1, Margin = new Padding(0) };
        archivo.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 114));
        archivo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        archivo.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112));
        archivo.Controls.Add(new Label { Text = "Archivo de destino", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
        destino.Margin = new Padding(0, 7, 8, 7);
        destino.AccessibleName = "Archivo MPP de destino";
        examinar.Margin = new Padding(0, 5, 0, 5);
        archivo.Controls.Add(destino, 1, 0);
        archivo.Controls.Add(examinar, 2, 0);
        contenido.Controls.Add(archivo, 0, 0);
        contenido.Controls.Add(soloTareas, 0, 1);
        contenido.Controls.Add(etapa, 0, 2);
        contenido.Controls.Add(detalle, 0, 3);
        progreso.Margin = new Padding(0, 3, 0, 3);
        contenido.Controls.Add(progreso, 0, 4);
        contenido.Controls.Add(contador, 0, 5);
        contenido.Controls.Add(error, 0, 6);
        var botones = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false, Margin = new Padding(0), Padding = new Padding(0, 8, 0, 0)
        };
        botones.Controls.Add(cerrar);
        botones.Controls.Add(exportar);
        contenido.Controls.Add(botones, 0, 7);
        Controls.Add(contenido);
        AcceptButton = exportar;
        CancelButton = cerrar;
        etapa.Text = "MICROSOFT PROJECT";
        detalle.Text = "Seleccione el destino y pulse Exportar.";
        examinar.Click += (_, _) => Examinar();
        exportar.Click += (_, _) => Exportar();
        cerrar.Click += (_, _) => Close();
        FormClosing += (_, e) =>
        {
            // No se interrumpe una llamada COM ni se cierra Project por la fuerza.
            if (exportando)
            {
                e.Cancel = true;
                error.Text = "La exportación está en curso. Espere a que termine para cerrar esta ventana.";
            }
        };
        MYGCronogramaDialogoUI.Tema(this);
    }

    private void Examinar()
    {
        if (exportando) return;
        using var dialogo = new SaveFileDialog
        {
            Title = "Exportar a Microsoft Project", AddExtension = true, DefaultExt = "mpp",
            Filter = "Archivo de Microsoft Project (*.mpp)|*.mpp", OverwritePrompt = false,
            FileName = string.IsNullOrWhiteSpace(destino.Text) ? NombreArchivo(proyecto.Nombre) : destino.Text.Trim()
        };
        if (dialogo.ShowDialog(this) == DialogResult.OK) destino.Text = dialogo.FileName;
    }

    private static string NombreArchivo(string nombre)
    {
        var invalidos = Path.GetInvalidFileNameChars();
        string limpio = new string((nombre ?? "").Select(c => invalidos.Contains(c) ? '_' : c).ToArray()).Trim().TrimEnd('.');
        if (limpio.Length == 0) limpio = "Cronograma";
        if (limpio.Length > 120) limpio = limpio[..120];
        return limpio + ".mpp";
    }

    private void Exportar()
    {
        if (exportando) return;
        error.Text = "";
        try
        {
            string ruta = destino.Text.Trim();
            MYGExportacionCronogramaWindows.ValidarDestino(ruta, "mpp", origenSQLite);
            ruta = Path.GetFullPath(ruta);
            if (File.Exists(ruta) && MessageBox.Show(this,
                    "El archivo de destino ya existe. ¿Desea reemplazarlo cuando termine la exportación?",
                    "Exportar a Microsoft Project", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            bool incluirRecursos = !soloTareas.Checked;
            destino.Text = ruta;
            var hilo = new Thread(() =>
            {
                Exception fallo = null;
                try { exportador(ruta, proyecto, plan, incluirRecursos, NotificarProgreso); }
                catch (Exception ex) { fallo = ex; }
                Encolar(() => Finalizar(ruta, fallo));
            }) { IsBackground = true, Name = "MYG Exportación Microsoft Project" };
            hilo.SetApartmentState(ApartmentState.STA);
            CambiarOcupado(true);
            MostrarProgreso(new MYGProgresoExportacionProject(MYGEtapaExportacionProject.Preparando, 0, 0, "Preparando Microsoft Project…"));
            try { hilo.Start(); }
            catch { CambiarOcupado(false); throw; }
        }
        catch (Exception ex)
        {
            error.ForeColor = Color.Firebrick;
            error.Text = ex.Message;
        }
    }

    private void CambiarOcupado(bool valor)
    {
        exportando = valor;
        destino.Enabled = examinar.Enabled = soloTareas.Enabled = exportar.Enabled = cerrar.Enabled = !valor;
        ControlBox = !valor;
        UseWaitCursor = valor;
    }

    private void NotificarProgreso(MYGProgresoExportacionProject avance)
    {
        if (avance == null) return;
        lock (sincronizacion)
        {
            ultimoProgreso = avance;
            // Las listas grandes no deben llenar la cola de mensajes de Windows.
            if (actualizacionPendiente) return;
            actualizacionPendiente = true;
        }
        if (!Encolar(() =>
        {
            MYGProgresoExportacionProject actual;
            lock (sincronizacion)
            {
                actual = ultimoProgreso;
                actualizacionPendiente = false;
            }
            MostrarProgreso(actual);
        }))
        {
            lock (sincronizacion) actualizacionPendiente = false;
        }
    }

    private bool Encolar(Action accion)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return false;
        try
        {
            BeginInvoke((Action)(() => { if (!IsDisposed && !Disposing) accion(); }));
            return true;
        }
        catch (InvalidOperationException) { return false; }
    }

    private void MostrarProgreso(MYGProgresoExportacionProject avance)
    {
        etapa.Text = avance.Etapa switch
        {
            MYGEtapaExportacionProject.Preparando => "PREPARANDO EXPORTACIÓN",
            MYGEtapaExportacionProject.Recursos => "LISTA DE RECURSOS",
            MYGEtapaExportacionProject.Tareas => "CREANDO TAREAS",
            MYGEtapaExportacionProject.Asignaciones => "ASIGNANDO RECURSOS",
            MYGEtapaExportacionProject.Dependencias => "CREANDO DEPENDENCIAS",
            MYGEtapaExportacionProject.Finalizando => "FINALIZANDO Y VALIDANDO",
            MYGEtapaExportacionProject.Guardando => "GUARDANDO PROYECTO",
            MYGEtapaExportacionProject.Abriendo => "ABRIENDO MICROSOFT PROJECT",
            _ => "EXPORTACIÓN COMPLETADA"
        };
        detalle.Text = avance.Detalle ?? "";
        bool indeterminado = avance.Total <= 0 && avance.Etapa != MYGEtapaExportacionProject.Completado;
        progreso.Style = indeterminado ? ProgressBarStyle.Marquee : ProgressBarStyle.Continuous;
        if (!indeterminado)
            progreso.Value = avance.Total <= 0 ? progreso.Maximum :
                (int)Math.Clamp((long)avance.Actual * progreso.Maximum / avance.Total, 0, progreso.Maximum);
        string elemento = avance.Etapa switch
        {
            MYGEtapaExportacionProject.Recursos => "Recurso",
            MYGEtapaExportacionProject.Tareas => "Tarea",
            MYGEtapaExportacionProject.Asignaciones => "Tarea",
            MYGEtapaExportacionProject.Dependencias => "Dependencia",
            _ => ""
        };
        contador.Text = avance.Total > 0 ? (elemento.Length == 0 ? "" : elemento + ": ") +
            avance.Actual.ToString("N0") + " de " + avance.Total.ToString("N0") : "";
    }

    private void Finalizar(string ruta, Exception fallo)
    {
        CambiarOcupado(false);
        progreso.Style = ProgressBarStyle.Continuous;
        if (fallo != null)
        {
            error.ForeColor = Color.Firebrick;
            error.Text = "No se completó la exportación: " + fallo.Message;
            // Se conservan la etapa, el nombre y el contador del elemento que
            // falló para que el usuario pueda localizarlo antes de reintentar.
            return;
        }
        RutaExportada = ruta;
        DialogResult = DialogResult.OK;
        Close();
    }
}
