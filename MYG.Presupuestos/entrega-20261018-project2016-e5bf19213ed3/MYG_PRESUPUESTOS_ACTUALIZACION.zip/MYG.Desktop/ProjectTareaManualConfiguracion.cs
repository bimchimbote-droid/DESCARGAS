using System;
using System.Globalization;

namespace MYG_2027;

// Project ofrece los campos *Text para introducir valores de tareas manuales.
// Comprobar lo introducido; no sustituirlo por una duración inferida del intervalo.
internal sealed record MYGTextoTareaManualProject(string Inicio, string Fin, string Duracion);

internal static class MYGConfiguracionTareaManualProject
{
    internal static void Restaurar(MYGTextoTareaManualProject texto,
        Func<string, object> leer, Action<string, object> escribir)
    {
        if (!Convert.ToBoolean(leer("Manual"), CultureInfo.InvariantCulture)) escribir("Manual", true);
        // El avance, las asignaciones y los vínculos se aplican antes de esta
        // restauración. No convertir la tarea a automática para fijar sus fechas.
        Fijar("StartText", texto.Inicio);
        Fijar("FinishText", texto.Fin);
        Fijar("DurationText", texto.Duracion);

        void Fijar(string campo, string valor)
        {
            if (!TextoIgual(leer(campo), valor)) escribir(campo, valor);
        }
    }

    internal static void Verificar(MYGTareaExportacionProject datos, MYGTextoTareaManualProject texto,
        Func<string, object> leer)
    {
        if (!Convert.ToBoolean(leer("Manual"), CultureInfo.InvariantCulture))
            Fallo("modo", "manual", "automático");
        Fecha("StartText", "Start", texto.Inicio, datos.Inicio);
        Fecha("FinishText", "Finish", texto.Fin, datos.Fin);
        // Si Project representa el campo como valor tipado sin texto, comprobar
        // el número. Un texto distinto no puede validarse con un número interno
        // anterior: eso ocultaría cambios en lo que el usuario ve en Project.
        object duracion = leer("DurationText");
        if (!TextoIgual(duracion, texto.Duracion) &&
            (!TextoVacio(duracion) || !NumeroIgual(leer("Duration"), datos.DuracionMinutos)))
            Fallo("duración", texto.Duracion, duracion);

        void Fecha(string campoTexto, string campoFecha, string esperadoTexto, DateTime esperado)
        {
            object actual = leer(campoTexto);
            if (!TextoIgual(actual, esperadoTexto) &&
                (!TextoVacio(actual) || !FechaIgual(leer(campoFecha), esperado)))
                Fallo(campoFecha == "Start" ? "inicio" : "fin", esperadoTexto, actual);
        }
        void Fallo(string campo, object esperado, object actual) =>
            throw new InvalidOperationException("Microsoft Project cambió el " + campo + " de la tarea manual «" + datos.Nombre +
                "». Esperado: " + esperado + "; recibido: " + actual + ". No se reemplazó el archivo de destino.");
    }

    private static bool TextoIgual(object valor, string esperado) =>
        string.Equals(Convert.ToString(valor, CultureInfo.InvariantCulture)?.Trim(), esperado?.Trim(), StringComparison.OrdinalIgnoreCase);

    private static bool TextoVacio(object valor) => string.IsNullOrWhiteSpace(Convert.ToString(valor, CultureInfo.InvariantCulture));

    private static bool FechaIgual(object valor, DateTime esperado) => valor is DateTime fecha &&
        Math.Abs((fecha - esperado).TotalSeconds) < 1;

    private static bool NumeroIgual(object valor, decimal esperado)
    {
        if (valor == null || valor is string) return false;
        try { return Math.Abs(Convert.ToDecimal(valor, CultureInfo.InvariantCulture) - esperado) <= 0.01m; }
        catch (FormatException) { return false; }
        catch (InvalidCastException) { return false; }
        catch (OverflowException) { return false; }
    }
}
