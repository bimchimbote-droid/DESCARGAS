# Actualización: desplegables de exportación y presupuesto sin franjas

## Base y alcance

Repositorio: `bimchimbote-droid/MYG.Presupuestos`, rama de origen `main`.
Commit base: `13c43d52c2ea227a0d773eaa417f3195ae98f93e`, comprobado contra GitHub antes de editar.
El entorno trabaja en la rama local `work`. No se ha hecho commit ni push al repositorio del código.
Tecnologías: C#, SDK .NET 10.0.100, WinForms/WPF y SQLite; conector Revit 2027.

## Cambios

- La cinta de vista preliminar muestra **Exportar como** y **E-Mail Como** como desplegables, con icono por extensión, título en negrita, descripción y resaltado amarillo. Los iconos de correo llevan sobre.
- Exportar ofrece PDF, HTML, MHT, RTF, XLS, XLSX, CSV, Texto e Imagen, en ese orden. E-Mail ofrece los mismos formatos excepto HTML, como en las capturas.
- HTML/MHT/RTF/CSV/TXT exportan los valores del informe; XLSX conserva el libro. Se exportan copias, sin editar el presupuesto original.
- XLS se convierte con Excel a un libro binario Excel 97-2003 real. No se cambia la extensión de otro formato para simularlo.
- Imagen ofrece BMP, GIF, JPEG, PNG, TIFF, EMF y WMF. Una página genera una imagen; varias páginas generan un ZIP de imágenes numeradas, con aviso de destino y sobrescritura. Los mapas de bits usan 150 DPI.
- E-Mail guarda el archivo y abre el editor del cliente compatible con Simple MAPI con el informe adjunto. El usuario decide si lo envía o cancela.
- Las filas normales del presupuesto y del pie tienen fondo blanco uniforme en modo normal. Se mantiene el gris de **Costo directo**, **Parcial** y **Total**, la selección, la edición de porcentajes y la paleta del modo oscuro. Las otras tablas conservan sus estilos.

El rango de páginas se aplica a PDF e imágenes. Los formatos de datos exportan los informes completos; no reproducen todos los cortes ni los efectos visuales de una página impresa.

## Archivos

Se entregan archivos completos, conservando sus rutas. Cree los nuevos y reemplace únicamente los existentes indicados en la tabla de la entrega. No se eliminan archivos. El ZIP no incluye el proyecto completo, bin/obj, paquetes, bases de datos ni credenciales.

## Aplicación manual

1. Cierre MYG y respalde o confirme sus cambios locales. En Visual Studio revise **Cambios de Git** y confirme la rama `main` antes de aplicar la entrega.
2. Descargue y extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip` en una carpeta temporal.
3. Copie su contenido a la raíz de su checkout de MYG.Presupuestos, conservando las carpetas MYG.Core, MYG.Desktop, MYG.Pruebas y MYG.PruebasUI. Use la ruta real de su proyecto; las instrucciones originales citan `D:\ADDIN\repos\MYG.Presupuestos_GITHUB` como ejemplo.
4. Los archivos existentes son reemplazos completos: compare y combine primero cualquier cambio local o posterior al commit base para no perderlo. Los nuevos archivos .cs se incluyen automáticamente por los proyectos SDK; no hay que modificar el .csproj.
5. Restaure, compile y ejecute las pruebas desde la raíz del proyecto:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

`UseRevitReferencePackages=true` permite compilar sin Revit instalado usando las referencias ya admitidas por el repositorio. En Windows con Revit instalado puede usar sus DLL locales según LEEME.md.

Para las pruebas de interfaz, en Windows:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

## Requisitos adicionales

No se añaden paquetes NuGet ni migraciones de base de datos.

- PDF: función **Microsoft Print to PDF** habilitada en Windows. Si la vista cambia al controlador PDF, revise la nueva paginación y vuelva a elegir PDF para guardar, igual que el comportamiento anterior.
- XLS: Microsoft Excel instalado. Si no está disponible, utilice XLSX, que no requiere Excel. XLS limita cada hoja a 65 536 filas y 256 columnas.
- E-Mail: cliente predeterminado compatible con Simple MAPI y con la arquitectura x64 de MYG, por ejemplo Outlook clásico de 64 bits. Los clientes sin Simple MAPI requieren adjuntar manualmente el archivo exportado.
- Interfaz y renderizado de imágenes: Windows Desktop Runtime .NET 10. El SDK de Linux permite compilar estas funciones, pero no ejecutarlas.

## Validación

Validación final realizada en Linux con SDK .NET 10.0.100: los cinco proyectos compilaron en Release con 0 errores y 0 advertencias. MYG.Pruebas completó 336 pruebas aprobadas, incluidas las seis nuevas comprobaciones de exportación. La prueba de Named Pipes de Windows se omitió explícitamente. Las pruebas UI nuevas y ampliadas se compilaron, pero no se ejecutaron; su ejecución y la comparación visual con las capturas requieren Windows. PDF con su controlador, XLS con Excel, correo MAPI e imágenes GDI requieren validación funcional en Windows.

Comprobaciones manuales pendientes: abrir ambos desplegables, recorrerlos con teclado, revisar iconos a 100/150/200 % de escala y en ambos temas; verificar las filas blancas y los tres resúmenes grises; guardar/abrir cada formato, PDF con su impresora, XLS con Excel, imágenes con una y varias páginas, y abrir/cancelar el borrador de correo con su adjunto. La integración real con Revit y el servicio de licencia no se ejecuta en Linux.

## Actualización de GitHub por el usuario

En Visual Studio abra **Cambios de Git**, revise los archivos, escriba el mensaje del commit y confirme. Luego haga Push a `main` y compruebe el commit en GitHub. La publicación del ZIP en el repositorio independiente `bimchimbote-droid/DESCARGAS` no aplica cambios al proyecto ni hace Push al repositorio del código.
