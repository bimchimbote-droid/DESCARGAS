using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class PiePresupuestoSombreadoCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Sombreado del pie", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            presupuesto.Costos.GastosGeneralesPorcentaje = 10m;
            presupuesto.Costos.UtilidadPorcentaje = 7m;
            presupuesto.Costos.ImpuestoPorcentaje = 18m;
            for (int numero = 1; numero <= 3; numero++)
            {
                string id = MYGProyectoStorage.NuevoId();
                presupuesto.Items.Add(new ItemPresupuestoDelphin
                {
                    Id = id, IdLocalMYG = id, IdPropuesta = id, Item = numero.ToString("00"), Posicion = numero,
                    TipoPropuesta = "PARTIDA", Descripcion = "PARTIDA PARA EL PIE " + numero, Unidad = "m²",
                    Costos = new MYGDatosPartida { Cantidad = 2m, FuenteMetrado = MYGFuenteMetrado.Cantidad, PrecioDirecto = 100m }
                });
            }
            int anteriores = 0, cambios = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { });
            panel.InicializarCatalogos(() => "", () => true, () => { });
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1500, 900) };
            formulario.Controls.Add(panel);
            formulario.Show();
            panel.Refrescar();
            Application.DoEvents();
            var tabla = (DataGridView)typeof(MYGPanelPresupuesto)
                .GetField("tablaPie", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(panel);
            var estructura = (DataGridView)typeof(MYGPanelPresupuesto)
                .GetField("estructura", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(panel);
            string firma = MYGProyectoStorage.Firma(proyecto);

            foreach (bool oscuro in new[] { false, true, false })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                MYG2027_TemaComercial.Aplicar(formulario);
                VerificarFondosUniformes(estructura, tabla, exige);
                panel.AplicarTemaPresupuestos();
                Application.DoEvents();
                tabla.CurrentCell = null;
                tabla.ClearSelection();
                VerificarSombreado(tabla, exige);
                VerificarFondosUniformes(estructura, tabla, exige);
                VerificarImportes(tabla, presupuesto, exige);
                exige(MYGProyectoStorage.Firma(proyecto) == firma && anteriores == 0 && cambios == 0,
                    "Aplicar el sombreado y alternar temas no debe cambiar el presupuesto ni registrar ediciones.");
            }

            var porcentaje = tabla.Rows[1].Cells["PORC"];
            tabla.CurrentCell = porcentaje;
            tabla.Focus();
            exige(tabla.BeginEdit(true) && tabla.EditingControl is DataGridViewTextBoxEditingControl,
                "El porcentaje de gastos generales debe seguir siendo editable después de sombrear el resumen.");
            var editor = (DataGridViewTextBoxEditingControl)tabla.EditingControl;
            editor.Text = "15";
            editor.Focus();
            editor.Select(0, 1);
            MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos();
            Application.DoEvents();
            exige(tabla.IsCurrentCellInEditMode && ReferenceEquals(tabla.EditingControl, editor) &&
                    ReferenceEquals(tabla.CurrentCell, porcentaje) && editor.Text == "15" &&
                    editor.SelectionStart == 0 && editor.SelectionLength == 1 && presupuesto.Costos.GastosGeneralesPorcentaje == 10m &&
                    anteriores == 0 && cambios == 0,
                "Cambiar de tema debe conservar el borrador del porcentaje sin confirmarlo ni recrear las filas del pie.");
            panel.FinalizarEdicion();
            panel.Refrescar();
            Application.DoEvents();
            exige(presupuesto.Costos.GastosGeneralesPorcentaje == 15m && anteriores == 1 && cambios == 1,
                "Confirmar el porcentaje debe aplicar el cálculo una sola vez y conservar el historial de edición.");
            tabla.CurrentCell = null;
            tabla.ClearSelection();
            VerificarImportes(tabla, presupuesto, exige);
            VerificarSombreado(tabla, exige);
            VerificarFondosUniformes(estructura, tabla, exige);
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarFondosUniformes(DataGridView estructura, DataGridView pie, Action<bool, string> exige)
    {
        Color fondo = MYG2027_TemaComercial.Superficie;
        foreach (var (tabla, filas) in new[]
        {
            (estructura, Enumerable.Range(0, estructura.Rows.Count).ToArray()),
            (pie, new[] { 1, 2, 4, 5 })
        })
        {
            tabla.CurrentCell = null;
            tabla.ClearSelection();
            using var imagen = new Bitmap(tabla.Width, tabla.Height);
            tabla.DrawToBitmap(imagen, tabla.ClientRectangle);
            foreach (int fila in filas)
                foreach (DataGridViewCell celda in tabla.Rows[fila].Cells)
                {
                    var formato = new DataGridViewCellFormattingEventArgs(celda.ColumnIndex, fila, celda.Value,
                        typeof(string), celda.InheritedStyle.Clone());
                    typeof(DataGridView).GetMethod("OnCellFormatting", BindingFlags.Instance | BindingFlags.NonPublic)
                        .Invoke(tabla, new object[] { formato });
                    var area = tabla.GetCellDisplayRectangle(celda.ColumnIndex, fila, true);
                    bool visible = celda.Visible && area.Width > 5 && area.Height > 5;
                    exige(formato.CellStyle.BackColor == fondo && (!visible ||
                            imagen.GetPixel(area.Left + 4, area.Top + 2).ToArgb() == fondo.ToArgb()),
                        "Las filas pares e impares del presupuesto y los porcentajes del pie deben tener el mismo fondo blanco en modo normal y la misma superficie en modo oscuro, incluso después de reaplicar el tema.");
                }
        }
    }

    private static void VerificarSombreado(DataGridView tabla, Action<bool, string> exige)
    {
        Color fondo = SystemInformation.HighContrast ? SystemColors.Control : MYG2027_TemaComercial.Oscuro
            ? Color.FromArgb(52, 61, 73) : Color.FromArgb(236, 238, 240);
        Color texto = SystemInformation.HighContrast ? SystemColors.ControlText : MYG2027_TemaComercial.Texto;
        using var imagen = new Bitmap(tabla.Width, tabla.Height);
        tabla.DrawToBitmap(imagen, tabla.ClientRectangle);
        foreach (int fila in new[] { 0, 3, 6 })
            foreach (DataGridViewCell celda in tabla.Rows[fila].Cells)
            {
                var formato = new DataGridViewCellFormattingEventArgs(celda.ColumnIndex, fila, celda.Value,
                    typeof(string), celda.InheritedStyle.Clone());
                typeof(DataGridView).GetMethod("OnCellFormatting", BindingFlags.Instance | BindingFlags.NonPublic)
                    .Invoke(tabla, new object[] { formato });
                var area = tabla.GetCellDisplayRectangle(celda.ColumnIndex, fila, false);
                exige(formato.CellStyle.BackColor == fondo && formato.CellStyle.ForeColor == texto &&
                        area.Width > 5 && area.Height > 5 &&
                        imagen.GetPixel(area.Right - 4, area.Top + 2).ToArgb() == fondo.ToArgb(),
                    "Costo directo, Parcial y Total deben sombrear todas las columnas, incluida una fila alterna, con contraste en ambos temas.");
            }
        exige(tabla.Rows[6].Cells["IMPORTE"].InheritedStyle.Font.Bold &&
                new[] { 0, 3, 6 }.All(f => tabla.Rows[f].Cells["PORC"].ReadOnly) &&
                new[] { 1, 2, 4, 5 }.All(f => !tabla.Rows[f].Cells["PORC"].ReadOnly),
            "El sombreado debe conservar el Total en negrita y permitir editar únicamente los cuatro porcentajes del pie.");
    }

    private static void VerificarImportes(DataGridView tabla, MYGPresupuestoDocumento presupuesto, Action<bool, string> exige)
    {
        var resumen = MYGMotorPresupuestos.Resumen(presupuesto);
        decimal[] importes = { resumen.CostoDirecto, resumen.GastosGenerales, resumen.Utilidad, resumen.Subtotal,
            resumen.Impuesto, resumen.OtrosImpuestos, resumen.Total };
        exige(tabla.Rows.Cast<DataGridViewRow>().Select(f => Convert.ToString(f.Cells["IMPORTE"].Value))
                .SequenceEqual(importes.Select(MYGFormatoPresupuesto.Dinero)),
            "El pie sombreado debe mostrar los importes actuales del motor, incluido el porcentaje recién confirmado.");
    }
}
