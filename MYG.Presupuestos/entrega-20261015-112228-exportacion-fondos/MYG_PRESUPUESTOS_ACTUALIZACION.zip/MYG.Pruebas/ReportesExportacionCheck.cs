using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ReportesExportacionCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var h = new MYGHojaMetrado { Nombre = "Informe QA", Filas = 8, Columnas = 4,
            AreaImpresion = "A1:C6", CeldaTotal = "C6", FilasOcultas = new() { 5 },
            RangosCombinados = new() { "A1:C1", "A3:A4" }, FormatoNumeroPredeterminado = "0.00" };
        h.Poner("A1", "Título único", true);
        h.Poner("A2", "Texto <script>, & \"comillas\"\nsegunda línea");
        h.Poner("B2", "2"); h.Poner("C2", "=B2*3");
        h.Poner("A3", "Descripción combinada"); h.Poner("B3", "=\"=2+2\""); h.Poner("C3", "-7");
        h.Poner("B4", "Texto {con llaves} y \\ruta"); h.Poner("C4", "=1/0");
        h.Poner("A5", "OCULTO_QA"); h.Poner("D2", "FUERA_AREA_QA");
        h.Poner("A6", "Total"); h.Poner("C6", "=C2+C3"); h.Poner("A8", "FUERA_FILAS_QA");
        h.Celdas["B2"].ColorFondo = "ABCDEF"; h.Celdas["B2"].ColorTexto = "102030";
        h.Celdas["B2"].Cursiva = true; h.Celdas["B2"].Subrayado = true; h.Celdas["B2"].Bordes = true;
        h.Celdas["B2"].AlineacionVertical = "Arriba";
        var segundo = new MYGHojaMetrado { Nombre = "Otro", Filas = 1, Columnas = 1, CeldaTotal = "A1", FilasInmovilizadas = 0,
            TamanoPapel = "A3", OrientacionPagina = "Horizontal", MargenIzquierdo = .3m };
        segundo.Poner("A1", "Segundo informe");
        var reportes = new[]
        {
            new MYGHojaReporteProyecto("Título de exportación", h, new[] { new KeyValuePair<string, string>("Proyecto", "Obra ñ & <QA>") }),
            new MYGHojaReporteProyecto("Segundo", segundo)
        };
        string antes = JsonSerializer.Serialize(reportes);
        string dos = 2m.ToString("0.00", CultureInfo.CurrentCulture), seis = 6m.ToString("0.00", CultureInfo.CurrentCulture),
            menosSiete = (-7m).ToString("0.00", CultureInfo.CurrentCulture);
        var rutas = new Dictionary<MYGFormatoExportacionReporte, string>();
        foreach (var formato in Enum.GetValues<MYGFormatoExportacionReporte>())
        {
            string ruta = Path.Combine(carpeta, "informe_" + formato + "." + formato.ToString().ToLowerInvariant());
            MYGReportesExportacion.Guardar(ruta, formato, reportes);
            Exige(File.Exists(ruta) && new FileInfo(ruta).Length > 0, "No se generó el formato " + formato);
            Exige(JsonSerializer.Serialize(reportes) == antes, "Exportar " + formato + " modificó los informes originales.");
            rutas.Add(formato, ruta);
        }

        var html = XDocument.Load(rutas[MYGFormatoExportacionReporte.Html]);
        Exige(html.Descendants("section").Count() == 2 && html.Descendants("dd").Single().Value == "Obra ñ & <QA>" &&
            html.Descendants("td").Any(e => e.Value.Contains("Texto <script>, & \"comillas\"")) && !html.Descendants("script").Any(),
            "HTML perdió un informe, metadatos, Unicode o escapado seguro del texto.");
        Exige(html.Descendants("td").Any(e => (string)e.Attribute("colspan") == "3" && e.Value == "Título único") &&
            html.Descendants("td").Any(e => (string)e.Attribute("rowspan") == "2" && e.Value == "Descripción combinada") &&
            html.Descendants("td").Any(e => e.Value == seis && ((string)e.Attribute("style")).Contains("font-size:")),
            "HTML perdió combinaciones o los valores calculados/formateados.");
        string estilo = (string)html.Descendants("td").First(e => e.Value == dos).Attribute("style");
        Exige(estilo.Contains("background-color:#ABCDEF") && estilo.Contains("color:#102030") && estilo.Contains("font-style:italic") &&
            estilo.Contains("text-decoration:underline") && estilo.Contains("vertical-align:top") && estilo.Contains("border:"),
            "HTML perdió estilos del informe.");
        Exige(!html.ToString().Contains("OCULTO_QA") && !html.ToString().Contains("FUERA_AREA_QA") && !html.ToString().Contains("FUERA_FILAS_QA"),
            "HTML incluyó filas ocultas o contenido fuera del área de impresión.");
        pasa("HTML conserva los informes, metadatos, Unicode, estilos, combinaciones y valores calculados, respetando filas ocultas y área de impresión");

        string mht = File.ReadAllText(rutas[MYGFormatoExportacionReporte.Mht]);
        int inicio = mht.IndexOf("Content-Location: informe.html\r\n\r\n", StringComparison.Ordinal) + "Content-Location: informe.html\r\n\r\n".Length;
        int fin = mht.IndexOf("\r\n------MYG_", inicio, StringComparison.Ordinal);
        string htmlMht = Encoding.UTF8.GetString(Convert.FromBase64String(mht[inicio..fin]));
        Exige(mht.StartsWith("MIME-Version: 1.0\r\nContent-Type: multipart/related;", StringComparison.Ordinal) &&
            XDocument.Parse(htmlMht).ToString() == html.ToString(), "MHT no contiene un documento MIME completo con el HTML UTF-8 del informe.");
        pasa("MHT empaqueta el mismo informe HTML completo en MIME con UTF-8 y contenido base64");

        string rtf = File.ReadAllText(rutas[MYGFormatoExportacionReporte.Rtf]);
        Exige(rtf.StartsWith("{\\rtf1", StringComparison.Ordinal) && rtf.EndsWith('}') && rtf.Contains("\\trowd") &&
            rtf.Contains("\\clmgf") && rtf.Contains("\\clmrg") && rtf.Contains("\\clvmgf") && rtf.Contains("\\clvmrg") &&
            rtf.Contains("\\u241?") && rtf.Contains("\\{con llaves\\}") && rtf.Contains("\\\\ruta") && rtf.Contains("\\clcbpat") &&
            rtf.Contains("\\sect ") && rtf.Contains("\\pgwsxn11908\\pghsxn16833") && rtf.Contains("\\marglsxn720") &&
            rtf.Contains("\\pgwsxn23817\\pghsxn16833\\marglsxn432") && rtf.Contains("\\lndscpsxn") && rtf.Contains("\\clvertalt") &&
            !rtf.Contains("OCULTO_QA") && !rtf.Contains("FUERA_AREA_QA"),
            "RTF perdió tablas, combinaciones, estilo, salto entre informes, Unicode o escapado del contenido.");
        pasa("RTF exporta tablas con estilos y combinaciones, Unicode, escapado de llaves y barras y separación de los informes");

        string csv = File.ReadAllText(rutas[MYGFormatoExportacionReporte.Csv]);
        var filas = LeerCsv(csv);
        Exige(filas.Any(f => f.Length == 3 && f[0] == "Texto <script>, & \"comillas\"\nsegunda línea" && f[1] == dos && f[2] == seis) &&
            filas.Any(f => f.Length == 3 && f[1] == "'=2+2" && f[2] == menosSiete) &&
            filas.Any(f => f.Contains("#ERROR")) && filas.Any(f => f.Contains("Segundo informe")) &&
            !csv.Contains("OCULTO_QA") && !csv.Contains("FUERA_AREA_QA") && !csv.Contains("FUERA_FILAS_QA"),
            "CSV no conserva campos con comas/comillas/saltos, valores calculados, prevención de fórmulas o selección de impresión.");
        Exige(File.ReadAllBytes(rutas[MYGFormatoExportacionReporte.Csv]).Take(3).SequenceEqual(Encoding.UTF8.GetPreamble()),
            "CSV debe identificar UTF-8 para abrir correctamente acentos en Excel.");
        string txt = File.ReadAllText(rutas[MYGFormatoExportacionReporte.Texto]);
        Exige(txt.Contains("Texto <script>, & \"comillas\" segunda línea\t" + dos + "\t" + seis) && txt.Contains("\t=2+2\t" + menosSiete) && txt.Contains("Segundo informe"),
            "TXT debe conservar texto y números en columnas separadas por tabulaciones.");
        pasa("CSV y TXT contienen todos los informes y resultados; CSV conserva campos multilínea y evita fórmulas en datos textuales");

        using (var zip = ZipFile.OpenRead(rutas[MYGFormatoExportacionReporte.Xlsx]))
        {
            Exige(zip.GetEntry("xl/workbook.xml") != null && zip.GetEntry("xl/worksheets/sheet2.xml") != null,
                "XLSX no contiene el libro real con todos los informes.");
            using var flujo = zip.GetEntry("xl/worksheets/sheet1.xml").Open();
            var xml = XDocument.Load(flujo); XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            var celda = xml.Descendants(ns + "c").Single(c => (string)c.Attribute("r") == "C2");
            Exige(celda.Element(ns + "f")?.Value == "B2*3" && celda.Element(ns + "v")?.Value == "6", "XLSX perdió la fórmula o su valor calculado.");
        }
        pasa("XLSX usa un libro Open XML real con todas las hojas, fórmulas y caché calculada sin modificar el origen");

        string protegido = Path.Combine(carpeta, "informe_protegido.html");
        File.WriteAllText(protegido, "archivo anterior");
        foreach (Action accion in new Action[]
        {
            () => MYGReportesExportacion.Guardar(protegido, (MYGFormatoExportacionReporte)999, reportes),
            () => MYGReportesExportacion.Guardar(protegido, MYGFormatoExportacionReporte.Html, Array.Empty<MYGHojaReporteProyecto>())
        })
        {
            bool fallo = false; try { accion(); } catch (ArgumentException) { fallo = true; }
            Exige(fallo && File.ReadAllText(protegido) == "archivo anterior", "Una exportación inválida sustituyó el archivo existente.");
        }
        Exige(!Directory.EnumerateFiles(carpeta, "informe_*.tmp").Any(), "La exportación dejó archivos temporales.");
        pasa("Exportación rechaza formatos y selecciones inválidos antes de sustituir el destino y no deja temporales");
    }

    private static List<string[]> LeerCsv(string contenido)
    {
        var filas = new List<string[]>(); var fila = new List<string>(); var campo = new StringBuilder(); bool comillas = false;
        for (int i = 0; i < contenido.Length; i++)
        {
            char c = contenido[i];
            if (c == '"')
            {
                if (comillas && i + 1 < contenido.Length && contenido[i + 1] == '"') { campo.Append('"'); i++; }
                else comillas = !comillas;
            }
            else if (c == ',' && !comillas) { fila.Add(campo.ToString()); campo.Clear(); }
            else if (c == '\r' && !comillas && i + 1 < contenido.Length && contenido[i + 1] == '\n')
            { fila.Add(campo.ToString()); campo.Clear(); filas.Add(fila.ToArray()); fila.Clear(); i++; }
            else campo.Append(c);
        }
        Exige(!comillas && campo.Length == 0 && fila.Count == 0, "CSV mal formado.");
        return filas;
    }
}
