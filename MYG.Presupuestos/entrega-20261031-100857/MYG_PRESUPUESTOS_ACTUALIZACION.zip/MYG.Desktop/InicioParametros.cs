using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private Button CrearOpcionParametrosInicio()
    {
        var boton = new Button
        {
            Name = "parametrosPredeterminadosInicio", Text = "Parámetros predeterminados",
            Width = 250, Height = 72, FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 11, FontStyle.Bold), Margin = new Padding(0, 0, 0, 10),
            AccessibleName = "Configurar parámetros predeterminados",
            AccessibleDescription = "Configura presupuestos, costos, ubicación, aceros, colores y empresa."
        };
        MYG2027_TemaComercial.EstilizarBoton(boton, 2);
        MYGAnimacionUI.PrepararBoton(boton);
        boton.Click += (_, _) =>
        {
            if (ocupado || IsDisposed) return;
            try
            {
                ExigirBaseLocalEditable();
                using var ventana = new MYGParametrosPredeterminadosForm(rutaBase);
                if (ventana.ShowDialog(this) == DialogResult.OK) MYGParametrosAplicacionUI.Actualizar();
            }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        };
        return boton;
    }
}
