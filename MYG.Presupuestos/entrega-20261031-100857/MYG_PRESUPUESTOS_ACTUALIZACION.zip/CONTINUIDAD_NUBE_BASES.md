# Continuidad y aplicación de la actualización de Nube MYG

## Contexto conservado

Esta entrega continúa las dos sesiones interrumpidas que el usuario adjuntó.
Decisiones confirmadas: mostrar tamaño en la lista de nube; importar la base
SQLite completa y abrir todas sus obras; ofrecer menú ⋮ por obra para asignar
colaboradores, roles y restricciones por módulo. El respaldo completo permanece
privado del propietario. Las obras compartidas usan el protocolo JSON existente,
que permite comprobar las restricciones también en el servidor.

Las sesiones anteriores describían cambios que no estaban presentes en este
checkout. Esta entrega parte de main, commit
`7fd5212bba829b93b4d9e0ea8728cab677fe3370`, y reúne los archivos necesarios.
La rama local de trabajo es `work`; no se publica el código automáticamente.
La entrega solicitada es pública, en el repositorio independiente
`bimchimbote-droid/DESCARGAS`, en una ruta nueva. No sobrescribir entregas previas.

## Aplicación manual

1. Respaldar o confirmar los cambios locales de
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.
2. Comparar su versión con el commit base indicado. El ZIP contiene archivos
   completos: reemplazarlos sin comparar puede perder modificaciones posteriores.
3. Extraer el ZIP y copiar sus rutas relativas sobre el repositorio local.
   Los archivos nuevos se agregan; los existentes se reemplazan completos.
   No hay archivos que eliminar ni dependencias NuGet nuevas.
4. Respaldar Supabase. En el editor SQL del proyecto correcto, aplicar
   `supabase/migraciones/20261101_bases_obras.sql`, después de las migraciones
   existentes de usuarios/permisos, paquetes, archivos SQLite 20261030 y la
   corrección 20261031. No ejecutar los archivos de `supabase/pruebas` en producción.
5. Si la migración encuentra bases SQLite que ya tienen otros miembros, se
   detiene sin revocar accesos. Separar y revisar esas obras y sus permisos antes
   de retirar el acceso al respaldo completo y reintentar la migración.
   La nueva interfaz no administra miembros del respaldo; esa revisión debe
   hacerse antes de actualizar o desde la administración del servidor.
6. Restaurar y compilar con SDK .NET 10.0.100 o compatible con global.json:

   ```powershell
   dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
   dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
   dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
   dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore -- --nube-bases
   ```

   En Windows con Revit 2027 instalado puede compilar sin
   `UseRevitReferencePackages=true` para usar sus API locales.

## Uso y límites concretos

- En Nube MYG elegir Crear/publicar y Base completa. La base queda privada;
  cada obra se publica de forma independiente. También puede iniciar este
  proceso desde ⋮ en una obra de la base local.
- Abrir la base desde Nube muestra todas las obras de su instantánea.
  Cada ⋮ permite abrir la obra o seleccionar directamente sus colaboradores
  y permisos. Para varias obras, repetir en cada una con los mismos usuarios
  y las restricciones que correspondan.
- Los colaboradores ven únicamente sus obras autorizadas en Compartidos.
  La autorización real sigue aplicándose en Supabase; ocultar filas no sustituye
  los permisos. Los archivos SQLite completos no se comparten con ellos.
- Cada editor usa su propia copia de trabajo y revisión remota. El índice y el
  respaldo completo conservan el estado importado; no se reconstruyen con las
  ediciones posteriores de las obras. La columna Nube al abrir informa los
  metadatos consultados al abrir el índice. Para una revisión actual, abrir la
  obra y sincronizar. La base original local tampoco se modifica automáticamente.
- Para agregar obras o cambiar catálogos globales, usar el original local e
  importar otra base. Esa nueva importación crea otro conjunto de obras;
  no traslada automáticamente colaboradores ni sobrescribe el conjunto anterior.
- Ante interrupciones, usar Publicaciones pendientes. Se conservan UUID,
  paquetes, confirmaciones y copias para continuar sin duplicar las obras del
  mismo intento. Retirar un intento conserva los archivos y no elimina las
  obras que ya llegaron al servidor.
- Tamaño en nube muestra bytes SQLite reales; para paquetes gzip, bytes
  comprimidos; para JSON, su tamaño lógico UTF-8 en el servidor. El tooltip
  distingue los formatos. Un servidor antiguo muestra No disponible.
- La importación utiliza las comprobaciones existentes de portabilidad y el
  límite de 300 MiB por archivo SQLite. Si existen extensiones no reconocidas
  o recursos externos que no se pueden incorporar, se detiene y conserva el
  original; no descarta esos datos para forzar la publicación.

## Validación y pendientes

Compilación Linux con .NET SDK 10.0.100 y referencias Revit: sin errores ni
advertencias. Suite Nube completa aprobada: incluye 49 comprobaciones nuevas
de protocolo, 23 de preparación, tres escenarios HTTP de recuperación y los
43 grupos principales/982 comprobaciones HTTP existentes y sus integraciones.
Suite general: 750 pruebas completadas; se omitieron las muestras externas
no proporcionadas y el canal Named Pipes de Windows, según informa el runner.
PostgreSQL 17 desechable: 23 comprobaciones nuevas aprobadas, con aislamiento,
privacidad del respaldo, restricciones, tamaños y migración repetible.
Las pruebas UI nuevas están compiladas; requieren Windows para ejecutarlas.
No se han aplicado migraciones ni usado cuentas o bases reales de Supabase.
No se ha ejecutado Revit ni certificado la interfaz visual desde Linux.

Antes de usar datos reales, comprobar en Windows la importación de una copia
con dos obras, sus tamaños, la apertura de ambas, el menú ⋮ y dos colaboradores
con permisos distintos. Confirmar que cada cuenta sólo recibe lo autorizado y
que ACU/especificaciones/metrados Excel restringidos no se pueden modificar.

## Publicación del código

En Visual Studio, revisar Cambios de Git y las diferencias, ejecutar las
comprobaciones, crear Commit y hacer Push a main únicamente cuando el usuario
decida aplicarlo. Verificar después la rama y el commit en GitHub.
Publicar el ZIP en DESCARGAS no aplica los cambios al proyecto ni a Supabase.
