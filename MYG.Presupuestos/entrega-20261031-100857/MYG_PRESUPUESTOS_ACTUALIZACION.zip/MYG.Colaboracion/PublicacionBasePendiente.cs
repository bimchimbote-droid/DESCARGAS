using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG_2027;

namespace MYG.Colaboracion;

public sealed record PublicacionBasePendiente(Guid Id, string Nombre, string DocumentoPrincipalId,
    int Obras, string RutaSQLite, DateTime FechaUtc);

/// <summary>Importación recuperable: una copia privada de la base y una publicación
/// independiente por obra. Los UUID y los paquetes se congelan antes de enviar datos.</summary>
public sealed class ArchivoPublicacionBasePendiente
{
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };
    private readonly string carpeta, ambito, rutaActiva, servidor, usuario;
    private sealed record Obra(Guid Id, string DocumentoId, string Nombre, string Archivo, string Sha256, long Bytes);
    private sealed record Intento(string Grupo, PublicacionSqlitePendiente Base, List<Obra> Obras, List<Guid> Confirmadas);

    public ArchivoPublicacionBasePendiente(string carpetaPublicaciones, string servidor, string usuarioId)
    {
        // Reutiliza las mismas validaciones de identidad y servidor del almacén SQLite.
        _ = new ArchivoPublicacionSqlitePendiente(carpetaPublicaciones, servidor, usuarioId);
        carpeta = Path.GetFullPath(carpetaPublicaciones);
        this.servidor = servidor; usuario = usuarioId;
        ambito = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(servidor.TrimEnd('/') + "\n" + Guid.Parse(usuarioId).ToString("D"))));
        rutaActiva = Path.Combine(carpeta, ambito + ".base.json");
    }

    public PublicacionBasePendiente? Consultar()
    {
        if (!File.Exists(rutaActiva)) return null;
        using var bloqueo = Bloquear();
        return Resumen(Leer());
    }

    public PublicacionBasePendiente Crear(string nombre, MYGProyectoDocumento principal, string rutaSQLite,
        CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        ArgumentNullException.ThrowIfNull(principal);
        ct.ThrowIfCancellationRequested();
        using var bloqueo = Bloquear();
        if (File.Exists(rutaActiva)) throw new IOException("Hay una importación de base pendiente. Reinténtela o retírela conservando sus copias.");
        string grupo = ambito + "-" + Guid.NewGuid().ToString("N");
        string directorio = Path.Combine(carpeta, grupo);
        Directory.CreateDirectory(directorio);
        bool durable = false;
        try
        {
            var almacen = AlmacenSqlite(directorio);
            var copia = almacen.Crear(nombre, "base", principal, rutaSQLite, ct, progreso);
            var obras = new List<Obra>();
            foreach (var resumen in MYGBaseDatos.ListarProyectos(copia.RutaSQLite))
            {
                ct.ThrowIfCancellationRequested();
                progreso?.Report("Preparando obra: " + resumen.Nombre);
                var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(copia.RutaSQLite, resumen.Id);
                // Alcance obra selecciona las filas nativas de esta obra; nunca envía
                // el archivo completo ni los documentos de las otras obras al miembro.
                var contenido = PaqueteNube.CrearContenido(documento, copia.RutaSQLite, "obra", compacto: true);
                Guid id = Guid.NewGuid(); string archivo = "obra-" + id.ToString("N") + ".json";
                string ruta = Path.Combine(directorio, archivo);
                using (var salida = new FileStream(ruta, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { JsonSerializer.Serialize(salida, contenido, Json); salida.Flush(true); }
                obras.Add(new(id, documento.Id, documento.Nombre, archivo, Hash(ruta), new FileInfo(ruta).Length));
            }
            if (obras.Count == 0) throw new InvalidDataException("La base no contiene obras para importar.");
            ct.ThrowIfCancellationRequested();
            var intento = new Intento(grupo, copia, obras, new());
            Guardar(intento); durable = true;
            return Resumen(intento);
        }
        finally
        {
            // Sólo limpia una preparación que nunca quedó visible para enviar.
            // Una importación durable siempre conserva todos sus archivos.
            if (!durable && Directory.Exists(directorio)) Directory.Delete(directorio, true);
        }
    }

    public async Task<ProyectoSqliteNube> EnviarAsync(ClienteSupabase cliente, CancellationToken ct = default,
        IProgress<string>? progreso = null)
    {
        ArgumentNullException.ThrowIfNull(cliente);
        ValidarCuenta(cliente);
        using var bloqueo = Bloquear();
        var intento = Leer();
        if (!await cliente.AdmiteBasesAsync(ct))
            throw new NubeException("Instale 20261101_bases_obras.sql en Supabase antes de importar bases con permisos por obra. Las copias locales se conservan.");
        ValidarCuenta(cliente);
        string directorio = Path.Combine(carpeta, intento.Grupo);
        var copia = AlmacenSqlite(directorio).Leer(intento.Base);
        progreso?.Report("Publicando la copia privada de la base completa…");
        var remoto = await cliente.CrearSqliteAsync(copia.Id, copia.Nombre, copia.RutaSQLite, "base", copia.DocumentoId, ct, progreso);
        ValidarCuenta(cliente);
        var vinculadas = await cliente.ListarObrasBaseAsync(copia.Id, ct);
        ValidarCuenta(cliente);
        foreach (var obra in intento.Obras)
        {
            ct.ThrowIfCancellationRequested();
            ValidarCuenta(cliente);
            if (intento.Confirmadas.Contains(obra.Id)) continue;
            // Si se perdió el ACK después del vínculo, no se vuelve a crear una
            // obra que ya puede haber recibido ediciones de sus colaboradores.
            if (!vinculadas.Any(o => o.Proyecto.Id == obra.Id && o.DocumentoId == obra.DocumentoId))
            {
                progreso?.Report("Publicando obra: " + obra.Nombre);
                string ruta = Path.Combine(directorio, obra.Archivo);
                if (!File.Exists(ruta) || new FileInfo(ruta).Length != obra.Bytes || Hash(ruta) != obra.Sha256)
                    throw new InvalidDataException("Un paquete de obra pendiente falta o cambió. Se conserva el intento; no se enviarán otros bytes con el mismo identificador.");
                using var contenido = JsonDocument.Parse(File.ReadAllBytes(ruta), new JsonDocumentOptions { MaxDepth = 128 });
                ValidarCuenta(cliente);
                var confirmado = await cliente.CrearProyectoConfirmacionAsync(obra.Id, obra.Nombre, contenido.RootElement, "obra", ct, progreso);
                ValidarCuenta(cliente);
                if (confirmado.Id != obra.Id || confirmado.Alcance != "obra") throw new NubeException("La confirmación no corresponde a la obra pendiente.");
                await cliente.VincularObraBaseAsync(copia.Id, obra.Id, obra.DocumentoId, ct);
                ValidarCuenta(cliente);
            }
            intento.Confirmadas.Add(obra.Id); Guardar(intento);
        }
        // Las copias permanecen disponibles para recuperación. Sólo se retira
        // el indicador activo cuando todas las obras tienen ACK de asociación.
        File.Move(rutaActiva, Path.Combine(directorio, "importacion-confirmada.json"));
        return remoto;
    }

    public string Retirar(PublicacionBasePendiente esperado)
    {
        using var bloqueo = Bloquear();
        var intento = Leer();
        if (Resumen(intento) != esperado) throw new InvalidOperationException("La importación pendiente cambió. Actualice la selección.");
        string directorio = Path.Combine(carpeta, intento.Grupo);
        File.Move(rutaActiva, Path.Combine(directorio, "importacion-retirada.json"));
        return directorio;
    }

    private ArchivoPublicacionSqlitePendiente AlmacenSqlite(string directorio) => new(directorio, servidor, usuario);
    private void ValidarCuenta(ClienteSupabase cliente)
    {
        if (!cliente.SesionIniciada || !string.Equals(cliente.UrlServidor.TrimEnd('/'), servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase)
            || cliente.UsuarioId != usuario)
            throw new NubeException("Inicie la misma cuenta de nube que preparó esta base.", necesitaIniciarSesion: true);
    }
    private static PublicacionBasePendiente Resumen(Intento i) => new(i.Base.Id, i.Base.Nombre, i.Base.DocumentoId,
        i.Obras.Count, i.Base.RutaSQLite, i.Base.FechaUtc);
    private Intento Leer()
    {
        if (!File.Exists(rutaActiva)) throw new FileNotFoundException("No existe una importación de base pendiente.");
        Intento i;
        try { i = JsonSerializer.Deserialize<Intento>(File.ReadAllBytes(rutaActiva), Json) ?? throw new InvalidDataException("El intento de base no es legible."); }
        catch (JsonException ex) { throw new InvalidDataException("El intento de base no es legible. Conserve sus archivos.", ex); }
        if (i.Grupo is null || Path.GetFileName(i.Grupo) != i.Grupo || !i.Grupo.StartsWith(ambito + "-", StringComparison.Ordinal)
            || i.Base is null || i.Base.Id == Guid.Empty || i.Base.Alcance != "base" || i.Obras is null || i.Obras.Count == 0 || i.Confirmadas is null)
            throw new InvalidDataException("Los metadatos de la base pendiente no son válidos.");
        string directorio = Path.Combine(carpeta, i.Grupo);
        if (!string.Equals(Path.GetDirectoryName(Path.GetFullPath(i.Base.RutaSQLite)), directorio, StringComparison.Ordinal))
            throw new InvalidDataException("La copia pendiente no pertenece a este almacén.");
        foreach (var o in i.Obras)
            if (o.Id == Guid.Empty || string.IsNullOrWhiteSpace(o.DocumentoId) || string.IsNullOrWhiteSpace(o.Nombre)
                || o.Archivo != "obra-" + o.Id.ToString("N") + ".json" || o.Bytes < 2 || o.Sha256.Length != 64 || !o.Sha256.All(Uri.IsHexDigit))
                throw new InvalidDataException("Los metadatos de una obra pendiente no son válidos.");
        if (i.Obras.Select(o => o.Id).Distinct().Count() != i.Obras.Count
            || i.Obras.Select(o => o.DocumentoId).Distinct().Count() != i.Obras.Count
            || i.Confirmadas.Any(id => !i.Obras.Any(o => o.Id == id)))
            throw new InvalidDataException("El intento contiene identidades de obra incompatibles.");
        return i;
    }
    private void Guardar(Intento i)
    {
        string temporal = rutaActiva + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var archivo = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            { JsonSerializer.Serialize(archivo, i, Json); archivo.Flush(true); }
            File.Move(temporal, rutaActiva, true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }
    private FileStream Bloquear()
    {
        Directory.CreateDirectory(carpeta);
        return new FileStream(rutaActiva + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    }
    private static string Hash(string ruta)
    { using var archivo = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(archivo)); }
}
