#nullable enable
using System.Text.Json;

namespace MYG.Colaboracion;

/// <summary>Obra independiente que pertenece a una base privada. Su UUID y sus
/// permisos corresponden a la obra, nunca al archivo de respaldo de la base.</summary>
public sealed record ObraBaseNube(ProyectoNube Proyecto, string DocumentoId);

public sealed partial class ClienteSupabase
{
    private bool capacidadBases;

    /// <summary>No cambia el formato ni comparte una base en servidores antiguos.</summary>
    public async Task<bool> AdmiteBasesAsync(CancellationToken ct = default)
    {
        if (capacidadBases) return true;
        try
        {
            bool admite = await EjecutarRpcNubeAsync("myg_nube_bases_capacidades", new { }, raiz =>
            {
                if (raiz.ValueKind != JsonValueKind.Object
                    || !raiz.TryGetProperty("version", out var version)
                    || version.ValueKind != JsonValueKind.Number
                    || !version.TryGetInt32(out int v) || v != 1)
                    throw RespuestaNubeInvalida();
                return true;
            }, ct);
            capacidadBases = admite;
            return admite;
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883")
        {
            // No memorizar un rechazo: la migración puede instalarse sin cerrar MYG.
            return false;
        }
    }

    private async Task ExigirBasesAsync(CancellationToken ct)
    {
        if (!await AdmiteBasesAsync(ct))
            throw new NubeException("Instale 20261101_bases_obras.sql en Supabase para importar bases privadas y compartir sus obras por separado. La copia local se conserva.");
    }

    /// <summary>El servidor filtra por membresía. Para un colaborador nunca devuelve
    /// obras ajenas, el archivo de la base ni contenido de otras obras.</summary>
    public async Task<IReadOnlyList<ObraBaseNube>> ListarObrasBaseAsync(Guid baseId,
        CancellationToken ct = default)
    {
        ValidarIdNube(baseId);
        await ExigirBasesAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_nube_base_obras_listar", new { p_base = baseId }, raiz =>
        {
            ValidarArrayNube(raiz);
            var obras = new List<ObraBaseNube>();
            var ids = new HashSet<Guid>();
            var documentos = new HashSet<string>(StringComparer.Ordinal);
            foreach (var elemento in raiz.EnumerateArray())
            {
                var obra = LeerObraBaseNube(elemento, baseId);
                if (!ids.Add(obra.Proyecto.Id) || !documentos.Add(obra.DocumentoId))
                    throw RespuestaNubeInvalida();
                obras.Add(obra);
            }
            return (IReadOnlyList<ObraBaseNube>)obras.AsReadOnly();
        }, ct, identidadEsperada: usuario);
    }

    /// <summary>Requiere ser propietario de base y obra. Repetir los mismos UUID
    /// confirma la relación existente; nunca amplía los permisos de un miembro.</summary>
    public async Task<ObraBaseNube> VincularObraBaseAsync(Guid baseId, Guid obraId,
        string documentoId, CancellationToken ct = default)
    {
        ValidarIdNube(baseId); ValidarIdNube(obraId);
        if (baseId == obraId || !TextoEntradaValido(documentoId, 200) || documentoId != documentoId.Trim())
            throw new NubeException("La obra necesita un documento y una identidad propios, distintos de su base.");
        await ExigirBasesAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_nube_base_obra_vincular", new
        {
            p_base = baseId, p_obra = obraId, p_documento = documentoId
        }, raiz =>
        {
            var obra = LeerObraBaseNube(raiz, baseId);
            if (obra.Proyecto.Id != obraId || obra.DocumentoId != documentoId
                || obra.Proyecto.Rol != "propietario") throw RespuestaNubeInvalida();
            return obra;
        }, ct, identidadEsperada: usuario);
    }

    private static ObraBaseNube LeerObraBaseNube(JsonElement raiz, Guid baseId)
    {
        if (raiz.ValueKind != JsonValueKind.Object || GuidNube(raiz, "base_id") != baseId
            || raiz.TryGetProperty("contenido", out _) || raiz.TryGetProperty("archivo_sqlite", out _))
            throw RespuestaNubeInvalida();
        var proyecto = LeerProyectoNube(raiz, requiereContenido: false);
        if (proyecto.Id == baseId || proyecto.Alcance != "obra") throw RespuestaNubeInvalida();
        string documento = TextoNube(raiz, "documento_id", 200);
        if (documento != documento.Trim()) throw RespuestaNubeInvalida();
        return new ObraBaseNube(proyecto, documento);
    }
}
