#nullable enable
using System;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    /// <summary>
    /// Publica con confirmación de metadatos. El UUID existente se verifica con
    /// el mismo contenido en el servidor; una consulta previa nunca confirma por sí sola.
    /// </summary>
    public async Task<ProyectoNube> CrearProyectoConfirmacionAsync(Guid id, string nombre,
        JsonElement contenido, string alcance, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        ValidarIdNube(id);
        nombre = ValidarNombreNube(nombre);
        ValidarAlcanceNube(alcance);
        // Rechazar entradas inválidas antes de consultar la cuenta o el servidor.
        try
        {
            if (contenido.ValueKind != JsonValueKind.Object) _ = ValidarContenidoNube(contenido, ct);
        }
        catch (ObjectDisposedException)
        { throw new NubeException("El contenido del proyecto ya no está disponible."); }
        ct.ThrowIfCancellationRequested();
        string usuario = await IdentidadArchivosAsync(ct);
        await ExigirPublicacionLigeraAsync(ct);
        if (FormatoPaqueteNube.EsCompacto(contenido)) await ExigirPaqueteCompactoAsync(ct);
        await ComprobarIdentidadArchivosAsync(usuario, ct);

        string estado = await EjecutarRpcNubeAsync("myg_nube_estado_publicacion", new { p_id = id }, raiz =>
        {
            string resultado = TextoNube(raiz, "estado", 16);
            if (resultado is not ("disponible" or "procesando" or "existente")) throw RespuestaNubeInvalida();
            return resultado;
        }, ct, identidadEsperada: usuario);
        if (estado == "procesando")
            throw new NubeException("El servidor todavía está procesando la publicación con este identificador. "
                + "No se volvió a enviar el paquete. Espere y reintente la misma publicación pendiente.",
                esErrorDeConexion: true);

        // El almacenamiento se fija al crear el proyecto. Un UUID legado conserva
        // su representación y sus verificaciones anteriores al reintentar.
        if ((await ObtenerCapacidadesNubeAsync(ct)).PublicacionComprimida >= 1
            && (estado == "disponible" || await EsProyectoComprimidoAsync(id, ct)))
            return await CrearProyectoComprimidoAsync(id, nombre, contenido, alcance, ct, progreso, identidadEsperada: usuario);

        ct.ThrowIfCancellationRequested();
        JsonElement copia = ValidarContenidoNube(contenido, ct);
        return await EjecutarRpcNubeAsync("myg_nube_crear_confirmacion", new
        {
            p_id = id, p_nombre = nombre, p_contenido = copia, p_alcance = alcance
        }, raiz =>
        {
            // El contrato nuevo nunca descarga el paquete completo durante la creación.
            if (raiz.ValueKind != JsonValueKind.Object || raiz.TryGetProperty("contenido", out _))
                throw RespuestaNubeInvalida();
            var proyecto = LeerProyectoNube(raiz, requiereContenido: false, esperado: id);
            if (proyecto.Alcance != alcance || proyecto.Rol != "propietario") throw RespuestaNubeInvalida();
            return proyecto;
        }, ct, identidadEsperada: usuario);
    }
}
