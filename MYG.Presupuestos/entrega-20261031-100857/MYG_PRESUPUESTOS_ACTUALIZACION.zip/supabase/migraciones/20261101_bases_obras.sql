-- Base SQLite privada y obras independientes compartidas con el protocolo JSON.
-- Aplicar después de 20261030_archivos_sqlite.sql y su corrección 20261031.
-- No convierte, borra ni revoca accesos existentes. Si una base SQLite ya está
-- compartida, se detiene: el propietario debe separar sus obras y retirar el
-- acceso al respaldo completo antes de instalar esta actualización.
begin;

-- Serializar instalación con altas/cambios de miembros y publicación de bases.
lock table public.myg_nube_proyectos,public.myg_nube_miembros in share row exclusive mode;
do $preflight$
begin
    if to_regprocedure('public.myg_nube_sqlite_capacidades()') is null
       or to_regclass('myg_nube_privado.sqlite_proyectos') is null
       or to_regprocedure('myg_nube_privado.identidad()') is null then
        raise exception 'Aplique primero la actualización de archivos SQLite y permisos MYG.';
    end if;
    if exists(select 1 from public.myg_nube_proyectos p
        join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
        join public.myg_nube_miembros m on m.proyecto_id=p.id
        where p.alcance='base' and (m.usuario_id<>p.propietario or m.rol<>'propietario')) then
        raise exception 'Hay bases SQLite compartidas. Separe las obras y retire los miembros del respaldo antes de instalar; no se modificaron sus accesos.';
    end if;
end $preflight$;

create table if not exists myg_nube_privado.base_obras (
    base_id uuid not null references public.myg_nube_proyectos(id),
    obra_id uuid not null unique references public.myg_nube_proyectos(id),
    documento_id text not null check(length(btrim(documento_id)) between 1 and 200
        and documento_id=btrim(documento_id) and documento_id !~ '[[:cntrl:]]'),
    primary key(base_id,documento_id),
    check(base_id<>obra_id)
);
revoke all on myg_nube_privado.base_obras from public,anon,authenticated,service_role;
alter table myg_nube_privado.base_obras enable row level security;

-- Los RPC anteriores de roles y solicitudes nunca pueden conceder acceso al
-- respaldo binario. La guarda está en la tabla para cubrir también otras rutas.
create or replace function myg_nube_privado.base_proteger_miembro()
returns trigger language plpgsql security definer set search_path=pg_catalog as $fn$
declare v_propietario uuid;
begin
    select p.propietario into v_propietario from public.myg_nube_proyectos p
        join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
        where p.id=new.proyecto_id and p.alcance='base' for update of p;
    if found and (new.usuario_id<>v_propietario or new.rol<>'propietario') then
        raise exception using errcode='42501',message='MYG_BASE_PRIVADA_COMPARTA_LAS_OBRAS';
    end if;
    return new;
end $fn$;
drop trigger if exists myg_base_privada_miembro on public.myg_nube_miembros;
create trigger myg_base_privada_miembro before insert or update on public.myg_nube_miembros
for each row execute function myg_nube_privado.base_proteger_miembro();

-- Evitar convertir una obra ya compartida en respaldo, o modificar el dueño o
-- alcance de una relación después de conceder permisos a obras independientes.
create or replace function myg_nube_privado.base_proteger_proyecto()
returns trigger language plpgsql security definer set search_path=pg_catalog as $fn$
begin
    if exists(select 1 from myg_nube_privado.base_obras b where b.base_id=old.id or b.obra_id=old.id)
       and (new.propietario is distinct from old.propietario or new.alcance is distinct from old.alcance) then
        raise exception using errcode='42501',message='MYG_RELACION_BASE_PROTEGIDA';
    end if;
    if new.alcance='base' and exists(select 1 from myg_nube_privado.sqlite_proyectos where proyecto_id=new.id)
       and exists(select 1 from public.myg_nube_miembros where proyecto_id=new.id
           and (usuario_id<>new.propietario or rol<>'propietario')) then
        raise exception using errcode='42501',message='MYG_BASE_PRIVADA_COMPARTA_LAS_OBRAS';
    end if;
    return new;
end $fn$;
drop trigger if exists myg_base_privada_proyecto on public.myg_nube_proyectos;
create trigger myg_base_privada_proyecto before update on public.myg_nube_proyectos
for each row execute function myg_nube_privado.base_proteger_proyecto();

-- El RPC SQLite actual no convierte proyectos JSON existentes. Mantener esa
-- propiedad también ante una futura ruta que inserte el registro privado del
-- formato después de crear los metadatos públicos.
create or replace function myg_nube_privado.base_proteger_formato_sqlite()
returns trigger language plpgsql security definer set search_path=pg_catalog as $fn$
declare v_propietario uuid; v_alcance text;
begin
    -- Mismo bloqueo que vincular: volver a consultar la relación después de
    -- adquirirlo evita una conversión concurrente con el alta de la obra.
    select propietario,alcance into v_propietario,v_alcance from public.myg_nube_proyectos
        where id=new.proyecto_id for update;
    if exists(select 1 from myg_nube_privado.base_obras where obra_id=new.proyecto_id) then
        raise exception using errcode='42501',message='MYG_OBRA_BASE_REQUIERE_VALIDACION_MODULOS';
    end if;
    if v_alcance='base' and exists(select 1 from public.myg_nube_miembros
        where proyecto_id=new.proyecto_id and (usuario_id<>v_propietario or rol<>'propietario')) then
        raise exception using errcode='42501',message='MYG_BASE_PRIVADA_COMPARTA_LAS_OBRAS';
    end if;
    return new;
end $fn$;
drop trigger if exists myg_base_privada_formato_sqlite on myg_nube_privado.sqlite_proyectos;
create trigger myg_base_privada_formato_sqlite before insert or update on myg_nube_privado.sqlite_proyectos
for each row execute function myg_nube_privado.base_proteger_formato_sqlite();

create or replace function public.myg_nube_bases_capacidades()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    perform myg_nube_privado.identidad();
    return '{"version":1}'::jsonb;
end $fn$;

-- Tamaño de la revisión actual, sin descargar contenido ni consultar por fila.
-- SQLite: bytes del archivo; GZip: bytes transferidos; JSON: bytes del texto
-- JSONB UTF-8 del servidor (no el tamaño físico de PostgreSQL).
create or replace function public.myg_nube_listar()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_resultado jsonb;
begin
    select coalesce(jsonb_agg(jsonb_build_object('id',p.id,'codigo',p.codigo,'nombre',p.nombre,
        'rol',m.rol,'revision',p.revision,'alcance',p.alcance,'permisos_modulos',m.permisos_modulos,
        'tamano_bytes',case when s.proyecto_id is not null then r.bytes
            when p.es_comprimido then (p.contenido->>'bytes_gzip')::bigint
            else octet_length(p.contenido::text)::bigint end,
        'tamano_formato',case when s.proyecto_id is not null then 'sqlite'
            when p.es_comprimido then 'gzip' else 'json' end)
        order by p.actualizado_en desc,p.id),'[]'::jsonb)
    into v_resultado from public.myg_nube_proyectos p
    join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=v_usuario
    left join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
    left join myg_nube_privado.sqlite_revisiones r on r.proyecto_id=p.id and r.revision=p.revision;
    return v_resultado;
end $fn$;

create or replace function public.myg_nube_base_obras_listar(p_base uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_propietario uuid; v_resultado jsonb;
begin
    select p.propietario into v_propietario from public.myg_nube_proyectos p
        join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
        where p.id=p_base and p.alcance='base';
    if v_propietario is null or (v_propietario<>v_usuario and not exists(
        select 1 from myg_nube_privado.base_obras b join public.myg_nube_miembros m on m.proyecto_id=b.obra_id
        where b.base_id=p_base and m.usuario_id=v_usuario)) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('base_id',b.base_id,'documento_id',b.documento_id,
        'id',p.id,'codigo',p.codigo,'nombre',p.nombre,'rol',m.rol,'revision',p.revision,
        'alcance',p.alcance,'permisos_modulos',m.permisos_modulos,
        'tamano_bytes',case when p.es_comprimido then (p.contenido->>'bytes_gzip')::bigint
            else octet_length(p.contenido::text)::bigint end,
        'tamano_formato',case when p.es_comprimido then 'gzip' else 'json' end)
        order by p.nombre,p.id),'[]'::jsonb)
    into v_resultado from myg_nube_privado.base_obras b
    join public.myg_nube_proyectos p on p.id=b.obra_id
    join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=v_usuario
    where b.base_id=p_base;
    return v_resultado;
end $fn$;

create or replace function public.myg_nube_base_obra_vincular(p_base uuid,p_obra uuid,p_documento text)
returns jsonb language plpgsql security definer set search_path=pg_catalog as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_previa myg_nube_privado.base_obras%rowtype;
begin
    if p_base is null or p_obra is null or p_base=p_obra
       or p_documento is null or length(p_documento) not between 1 and 200
       or p_documento<>btrim(p_documento) or p_documento ~ '[[:cntrl:]]' then
        raise exception using errcode='22023',message='MYG_RELACION_BASE_INVALIDA';
    end if;
    -- Orden estable para evitar interbloqueos entre relaciones concurrentes.
    perform 1 from public.myg_nube_proyectos where id in(p_base,p_obra) order by id for update;
    if not exists(select 1 from public.myg_nube_proyectos p
        join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
        join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=v_usuario and m.rol='propietario'
        where p.id=p_base and p.propietario=v_usuario and p.alcance='base')
       or not exists(select 1 from public.myg_nube_proyectos p
        join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=v_usuario and m.rol='propietario'
        where p.id=p_obra and p.propietario=v_usuario and p.alcance='obra'
            and not exists(select 1 from myg_nube_privado.sqlite_proyectos s where s.proyecto_id=p.id)) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    select * into v_previa from myg_nube_privado.base_obras where base_id=p_base and documento_id=p_documento;
    if found then
        if v_previa.obra_id<>p_obra then
            raise exception using errcode='22023',message='MYG_DOCUMENTO_BASE_YA_VINCULADO';
        end if;
    else
        if exists(select 1 from myg_nube_privado.base_obras where obra_id=p_obra) then
            raise exception using errcode='22023',message='MYG_OBRA_BASE_YA_VINCULADA';
        end if;
        insert into myg_nube_privado.base_obras(base_id,obra_id,documento_id) values(p_base,p_obra,p_documento);
    end if;
    return (select jsonb_build_object('base_id',p_base,'documento_id',p_documento,
        'id',p.id,'codigo',p.codigo,'nombre',p.nombre,'rol',m.rol,'revision',p.revision,
        'alcance',p.alcance,'permisos_modulos',m.permisos_modulos,
        'tamano_bytes',case when p.es_comprimido then (p.contenido->>'bytes_gzip')::bigint
            else octet_length(p.contenido::text)::bigint end,
        'tamano_formato',case when p.es_comprimido then 'gzip' else 'json' end)
        from public.myg_nube_proyectos p join public.myg_nube_miembros m on m.proyecto_id=p.id
        where p.id=p_obra and m.usuario_id=v_usuario);
end $fn$;

revoke all on function myg_nube_privado.base_proteger_miembro(),
    myg_nube_privado.base_proteger_proyecto(),myg_nube_privado.base_proteger_formato_sqlite()
    from public,anon,authenticated,service_role;
revoke all on function public.myg_nube_bases_capacidades(),
    public.myg_nube_base_obras_listar(uuid),public.myg_nube_base_obra_vincular(uuid,uuid,text)
    from public,anon;
grant execute on function public.myg_nube_bases_capacidades(),
    public.myg_nube_base_obras_listar(uuid),public.myg_nube_base_obra_vincular(uuid,uuid,text)
    to authenticated,service_role;
notify pgrst,'reload schema';
commit;
