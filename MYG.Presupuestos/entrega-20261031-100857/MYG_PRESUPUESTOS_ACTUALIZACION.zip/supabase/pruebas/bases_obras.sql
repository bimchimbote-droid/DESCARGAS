-- Sólo PostgreSQL desechable, con el Storage sintético del fixture SQLite.
\set ON_ERROR_STOP on
\if :{?MYG_BASES_FIXTURE_PREPARADO}
\else
  \ir archivos_sqlite.sql
\endif
reset role;
-- El fixture anterior prueba bases compartidas del protocolo anterior. Sólo
-- en esta base desechable retiramos sus miembros para instalar el modo privado.
delete from public.myg_nube_miembros m using public.myg_nube_proyectos p
where m.proyecto_id=p.id and p.id='d9000000-0000-0000-0000-000000000001'
  and m.usuario_id<>p.propietario;
\ir ../migraciones/20261101_bases_obras.sql
\ir ../migraciones/20261101_bases_obras.sql
-- Manifiesto y objeto Storage sintéticos: comprobamos metadatos SQL, no bytes
-- GZip reales (la validación binaria corresponde al transporte C# existente).
create table qa.base_gzip_caso as select 'da000000-0000-0000-0000-000000000001'::uuid id,
    jsonb_build_object('formato','MYG_ARCHIVO_GZIP','version',1,
        'sha256_json',repeat('a',64),'bytes_json',4096,
        'sha256_gzip',repeat('b',64),'bytes_gzip',100,
        'partes',jsonb_build_array(jsonb_build_object('ruta',
            '00000000-0000-0000-0000-000000000001/da000000000000000000000000000001/'||repeat('b',64),
            'sha256',repeat('b',64),'bytes',100))) manifest;
insert into storage.objects(bucket_id,name,metadata)
select 'myg-nube-paquetes',manifest#>>'{partes,0,ruta}','{"size":100}'::jsonb from qa.base_gzip_caso;
grant select on qa.base_gzip_caso to authenticated;
select qa.exige(not has_table_privilege('authenticated','myg_nube_privado.base_obras','select')
    and not has_function_privilege('anon','public.myg_nube_base_obras_listar(uuid)','execute'),
    'Bases: relación privada y RPC sin acceso anónimo');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_nube_crear_comprimido(id,'Obra GZip tamaño',manifest,'obra') from qa.base_gzip_caso;
select qa.exige((select (e->>'tamano_bytes')::bigint=100 and e->>'tamano_formato'='gzip'
    from jsonb_array_elements(public.myg_nube_listar()) e
    where e->>'id'='da000000-0000-0000-0000-000000000001'),
    'Bases: tamaño GZip cuenta bytes de archivo comprimido, no JSON expandido');
select qa.exige(public.myg_nube_bases_capacidades()='{"version":1}'::jsonb,
    'Bases: negociación de versión explícita');
select qa.exige(public.myg_nube_base_obras_listar('d9000000-0000-0000-0000-000000000001')='[]'::jsonb,
    'Bases: respaldo nuevo todavía sin obras vinculadas');
select qa.exige((public.myg_nube_base_obra_vincular('d9000000-0000-0000-0000-000000000001',
    '20000000-0000-0000-0000-000000000001','doc-uno')->>'documento_id')='doc-uno',
    'Bases: propietario vincula obra JSON independiente');
select qa.exige((public.myg_nube_base_obra_vincular('d9000000-0000-0000-0000-000000000001',
    '20000000-0000-0000-0000-000000000001','doc-uno')->>'documento_id')='doc-uno',
    'Bases: reintento de vínculo no crea otra obra');
select qa.rechaza($$select public.myg_nube_base_obra_vincular('d9000000-0000-0000-0000-000000000001',
    '20000000-0000-0000-0000-000000000002','doc-uno')$$,'22023',
    'Bases: documento no puede cambiar de UUID remoto');
select qa.rechaza($$select public.myg_nube_base_obra_vincular('d9000000-0000-0000-0000-000000000001',
    '20000000-0000-0000-0000-000000000001','doc-otro')$$,'22023',
    'Bases: obra no puede ocupar dos documentos');
select public.myg_nube_base_obra_vincular('d9000000-0000-0000-0000-000000000001',
    '20000000-0000-0000-0000-000000000002','doc-dos');
select qa.exige(jsonb_array_length(public.myg_nube_base_obras_listar('d9000000-0000-0000-0000-000000000001'))=2,
    'Bases: propietario lista ambas obras y no recibe contenido');
select qa.exige(not exists(select 1 from jsonb_array_elements(public.myg_nube_base_obras_listar(
    'd9000000-0000-0000-0000-000000000001')) e where e ? 'contenido'),
    'Bases: listado no descarga documentos ajenos ni archivos');
select qa.rechaza($$select public.myg_nube_compartir_usuario('d9000000-0000-0000-0000-000000000001',
    'editor','editor','{"acu":true,"especificaciones":true,"metrados_excel":true}')$$,'42501',
    'Bases: compartir usuario no concede acceso al respaldo completo');
select qa.rechaza($$select public.myg_nube_rol('d9000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000003','lector')$$,'42501',
    'Bases: RPC legado de roles tampoco comparte el respaldo');
select public.myg_nube_compartir_usuario('20000000-0000-0000-0000-000000000001','editor','editor',
    '{"acu":false,"especificaciones":true,"metrados_excel":true}');
-- Retirar cualquier acceso del fixture a la segunda obra: queda autorizada una.
select public.myg_nube_rol('20000000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000003',null);
select qa.exige((select (e->>'tamano_bytes')::bigint=12288 and e->>'tamano_formato'='sqlite'
    from jsonb_array_elements(public.myg_nube_listar()) e
    where e->>'id'='d9000000-0000-0000-0000-000000000001'),
    'Bases: tamaño SQLite corresponde a bytes de revisión actual');
select qa.exige((select (e->>'tamano_bytes')::bigint>0 and e->>'tamano_formato'='json'
    from jsonb_array_elements(public.myg_nube_listar()) e
    where e->>'id'='20000000-0000-0000-0000-000000000001'),
    'Bases: tamaño JSON declarado como bytes JSON');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.exige(jsonb_array_length(public.myg_nube_base_obras_listar('d9000000-0000-0000-0000-000000000001'))=1
    and public.myg_nube_base_obras_listar('d9000000-0000-0000-0000-000000000001')->0->>'documento_id'='doc-uno'
    and public.myg_nube_base_obras_listar('d9000000-0000-0000-0000-000000000001')->0#>>'{permisos_modulos,acu}'='false',
    'Bases: colaborador sólo lista su obra y conserva restricciones por módulo');
select qa.exige(not exists(select 1 from jsonb_array_elements(public.myg_nube_listar()) e
    where e->>'id'='d9000000-0000-0000-0000-000000000001'),
    'Bases: colaborador no obtiene respaldo en listado principal');
select qa.exige((select count(*)=0 from storage.objects where bucket_id='myg-nube-sqlite'),
    'Bases: conocer ruta del respaldo no permite descargarlo');
select qa.rechaza($$select public.myg_nube_base_obra_vincular('d9000000-0000-0000-0000-000000000001',
    '20000000-0000-0000-0000-000000000001','doc-uno')$$,'42501',
    'Bases: colaborador no puede crear ni reproducir vínculos');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_nube_base_obras_listar('d9000000-0000-0000-0000-000000000001')$$,'42501',
    'Bases: ajeno no conoce nombres ni cantidad de obras');
reset role;
select qa.rechaza($$insert into myg_nube_privado.sqlite_proyectos(proyecto_id,documento_id)
    values('20000000-0000-0000-0000-000000000001','doc-uno')$$,'42501',
    'Bases: futura conversión SQLite no elude los permisos de una obra relacionada');
select qa.rechaza($attempt$do $do$ begin
    update public.myg_nube_proyectos set alcance='base' where id='10000000-0000-0000-0000-000000000001';
    insert into myg_nube_privado.sqlite_proyectos(proyecto_id,documento_id)
        values('10000000-0000-0000-0000-000000000001','doc-conversion');
end $do$$attempt$,'42501',
    'Bases: futura conversión de JSON compartido no expone respaldo SQLite');
select qa.rechaza($$update public.myg_nube_proyectos set propietario='00000000-0000-0000-0000-000000000007'
    where id='20000000-0000-0000-0000-000000000001'$$,'42501',
    'Bases: propietario de relación no cambia por DML privilegiado accidental');
select 'BASES_OBRAS_SQL_APROBADAS' resultado;
