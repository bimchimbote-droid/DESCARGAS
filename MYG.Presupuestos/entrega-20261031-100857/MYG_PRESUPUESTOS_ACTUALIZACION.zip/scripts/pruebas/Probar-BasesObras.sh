#!/usr/bin/env bash
# Sólo PostgreSQL desechable; sin Supabase ni datos reales.
set -euo pipefail
repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
test_workspace=$(mktemp -d -t myg-bases-obras-XXXXXXXX)
test_container=""
cleanup() {
    result=$?
    trap - EXIT
    if [[ -n "$test_container" ]]; then docker rm -f "$test_container" >/dev/null 2>&1 || true; fi
    rm -rf -- "$test_workspace"
    exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
# Este runner usa exclusivamente el daemon local del entorno cloud. Evitar que
# selectores heredados lo redirijan accidentalmente a un servidor remoto.
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_HOST=unix:///var/run/docker.sock
docker info --format '{{.ServerVersion}}'
postgres_test_image='postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
if ! docker image inspect "$postgres_test_image" >/dev/null 2>&1; then docker pull "$postgres_test_image"; fi
dotnet run --project "$repo_root/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" \
    -c Release -p:UseSharedCompilation=false -- "$test_workspace/paquetes"
test_container=$(docker run --detach --rm --network none --memory=2g --cpus=2 \
    --tmpfs /var/lib/postgresql/data:rw,size=1g \
    -e POSTGRES_HOST_AUTH_METHOD=trust "$postgres_test_image")
for attempt in {1..60}; do
    if docker exec "$test_container" pg_isready -U postgres >/dev/null 2>&1; then break; fi
    if [[ "$attempt" == 60 ]]; then docker logs "$test_container"; exit 1; fi
    sleep 1
done
docker exec -u root "$test_container" mkdir -p /pruebas
docker cp "$repo_root/supabase" "$test_container:/pruebas/supabase"
docker cp "$test_workspace/paquetes" "$test_container:/pruebas/paquetes"
docker exec -u root "$test_container" chmod -R a+rX /pruebas
psql_test() {
    docker exec -u postgres "$test_container" psql -X -d postgres \
        -v MYG_PRUEBAS_DESECHABLES=1 -v ON_ERROR_STOP=1 "$@"
}
psql_test -f /pruebas/supabase/pruebas/archivos_sqlite.sql
# El fixture anterior deja una base compartida: la migración debe abortar sin
# revocar miembros ni instalar una tabla parcialmente.
if psql_test -f /pruebas/supabase/migraciones/20261101_bases_obras.sql \
    > "$test_workspace/preflight-esperado.log" 2>&1; then
    cat "$test_workspace/preflight-esperado.log"
    printf 'FALLO: la migración aceptó un respaldo previamente compartido.\n' >&2
    exit 1
fi
if ! rg -q 'Hay bases SQLite compartidas' "$test_workspace/preflight-esperado.log"; then
    cat "$test_workspace/preflight-esperado.log"
    exit 1
fi
psql_test -c "SELECT qa.exige(to_regclass('myg_nube_privado.base_obras') IS NULL
    AND EXISTS(SELECT 1 FROM public.myg_nube_miembros m JOIN public.myg_nube_proyectos p ON p.id=m.proyecto_id
        WHERE p.id='d9000000-0000-0000-0000-000000000001' AND m.usuario_id<>p.propietario),
    'Bases: preflight rechaza respaldo compartido sin revocar accesos ni dejar instalación parcial');"
psql_test -v MYG_BASES_FIXTURE_PREPARADO=1 -f /pruebas/supabase/pruebas/bases_obras.sql
