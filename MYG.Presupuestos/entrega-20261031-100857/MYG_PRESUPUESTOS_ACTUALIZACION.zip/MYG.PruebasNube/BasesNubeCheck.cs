using System.Net;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

/// <summary>Contrato HTTP sin red: separación entre base privada y obra, tamaños
/// de metadatos y rechazos de respuestas que cruzan identidades de proyectos.</summary>
internal static class BasesNubeCheck
{
    private static readonly Guid Base = Guid.Parse("11111111-1111-4111-8111-111111111110");
    private static readonly Guid Obra = Guid.Parse("22222222-2222-4222-8222-222222222220");
    private const string Documento = "OBRA-UNICA-01";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        using var http = new Transporte();
        using var cliente = new ClienteSupabase("https://bases-qa.supabase.co", "sb_publishable_pruebas_bases", http);
        await cliente.IniciarSesionAsync("qa@myg.example", "prueba_sintetica");
        Exige(await cliente.AdmiteBasesAsync(), "no reconoció el protocolo de bases");
        var vinculada = await cliente.VincularObraBaseAsync(Base, Obra, Documento);
        Exige(vinculada.DocumentoId == Documento && vinculada.Proyecto.Id == Obra, "cambió la relación confirmada");
        Exige(vinculada.Proyecto.TamanoBytes == 8192, "perdió el tamaño confirmado");
        var obras = await cliente.ListarObrasBaseAsync(Base);
        Exige(obras.Count == 1 && obras[0].Proyecto.Contenido.ValueKind == JsonValueKind.Undefined,
            "listó contenidos en vez de metadatos");
        await cliente.VincularObraBaseAsync(Base, Obra, Documento);
        Exige(http.Vinculos.Count == 2 && http.Vinculos[0] == http.Vinculos[1], "el reintento cambió sus UUID o documento");
        int antes = http.Peticiones;
        await Rechaza(() => cliente.VincularObraBaseAsync(Base, Base, Documento));
        await Rechaza(() => cliente.ListarObrasBaseAsync(Guid.Empty));
        await Rechaza(() => cliente.VincularObraBaseAsync(Base, Obra, ""));
        await Rechaza(() => cliente.VincularObraBaseAsync(Base, Obra, " " + Documento));
        Exige(http.Peticiones == antes, "envió entradas inválidas al servidor");

        foreach (string variante in new[] { "otra-base", "misma-identidad", "alcance-base", "duplicada", "documento-duplicado", "contenido", "tamano-negativo", "tamano-texto", "formato-desconocido" })
        {
            http.Variante = variante;
            await Rechaza(() => cliente.ListarObrasBaseAsync(Base));
        }
        http.Variante = "otro-documento";
        await Rechaza(() => cliente.VincularObraBaseAsync(Base, Obra, Documento));
        http.Variante = "rol-editor";
        await Rechaza(() => cliente.VincularObraBaseAsync(Base, Obra, Documento));
        http.Variante = "tamano-ausente";
        Exige((await cliente.ListarProyectosAsync()).Single().TamanoBytes is null, "inventó tamaño para un servidor antiguo");

        using var antiguo = new Transporte { Anterior = true };
        using var clienteAntiguo = new ClienteSupabase("https://bases-qa.supabase.co", "sb_publishable_pruebas_bases", antiguo);
        await clienteAntiguo.IniciarSesionAsync("qa@myg.example", "prueba_sintetica");
        Exige(!await clienteAntiguo.AdmiteBasesAsync(), "aceptó un servidor sin migración");
        await Rechaza(() => clienteAntiguo.ListarObrasBaseAsync(Base));
        Exige(!antiguo.Vinculos.Any(), "envió un vínculo al servidor anterior");
        antiguo.Anterior = false;
        Exige(await clienteAntiguo.AdmiteBasesAsync(), "no permitió reintentar después de instalar la migración");
        Console.WriteLine($"OK Bases de nube: {comprobaciones} comprobaciones de relaciones, UUID, tamaños, metadatos y compatibilidad; HTTP simulado, sin red.");
    }

    private static void Exige(bool ok, string detalle)
    {
        comprobaciones++;
        if (!ok) throw new InvalidOperationException("Bases de nube: " + detalle);
    }

    private static async Task Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException) { comprobaciones++; return; }
        throw new InvalidOperationException("Bases de nube: se esperaba rechazo");
    }

    private sealed class Transporte : HttpMessageHandler
    {
        internal bool Anterior;
        internal int Peticiones;
        internal string Variante = "";
        internal readonly List<string> Vinculos = new();

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            Peticiones++;
            string ruta = request.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token")
                return Json(new { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600,
                    user = new { id = "33333333-3333-4333-8333-333333333330" } });
            Exige(request.Headers.Authorization is not null, "petición sin identidad");
            if (ruta.EndsWith("/myg_nube_bases_capacidades"))
                return Anterior ? Json(new { code = "PGRST202", message = "ausente" }, HttpStatusCode.NotFound)
                    : Json(new { version = 1 });
            var datos = new Dictionary<string, object?>
            {
                ["base_id"] = Variante == "otra-base" ? Guid.NewGuid() : Base,
                ["id"] = Variante == "misma-identidad" ? Base : Obra,
                ["codigo"] = "MYG-OBRA-01", ["nombre"] = "Obra sintética",
                ["rol"] = Variante == "rol-editor" ? "editor" : "propietario", ["revision"] = 1,
                ["alcance"] = Variante == "alcance-base" ? "base" : "obra",
                ["documento_id"] = Variante == "otro-documento" ? "OTRO" : Documento,
                ["tamano_bytes"] = Variante == "tamano-negativo" ? -1 : Variante == "tamano-texto" ? "8192" : 8192,
                ["tamano_formato"] = Variante == "formato-desconocido" ? "otro" : "json"
            };
            if (Variante == "contenido") datos["contenido"] = new { privado = true };
            if (Variante == "tamano-ausente") datos.Remove("tamano_bytes");
            if (ruta.EndsWith("/myg_nube_base_obra_vincular"))
            {
                string cuerpo = await request.Content!.ReadAsStringAsync(ct);
                using var j = JsonDocument.Parse(cuerpo);
                Exige(j.RootElement.GetProperty("p_base").GetGuid() == Base
                    && j.RootElement.GetProperty("p_obra").GetGuid() == Obra
                    && j.RootElement.GetProperty("p_documento").GetString() == Documento,
                    "el vínculo no conservó las identidades");
                Vinculos.Add(cuerpo);
                return Json(datos);
            }
            if (ruta.EndsWith("/myg_nube_base_obras_listar") || ruta.EndsWith("/myg_nube_listar"))
            {
                if (Variante == "duplicada") return Json(new[] { datos, datos });
                if (Variante == "documento-duplicado")
                {
                    var otra = new Dictionary<string, object?>(datos) { ["id"] = Guid.NewGuid() };
                    return Json(new[] { datos, otra });
                }
                return Json(new[] { datos });
            }
            throw new InvalidOperationException("RPC inesperada: " + ruta);
        }

        private static HttpResponseMessage Json(object value, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        {
            Content = new StringContent(JsonSerializer.Serialize(value), Encoding.UTF8, "application/json")
        };
    }
}
