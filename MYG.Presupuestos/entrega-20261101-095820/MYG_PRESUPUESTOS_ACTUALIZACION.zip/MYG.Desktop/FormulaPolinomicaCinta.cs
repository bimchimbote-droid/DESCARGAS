using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGFormulaPolinomicaForm
{
    private FlowLayoutPanel cintaFormula;
    private ToolStrip accionesFormula;
    private bool ajustandoAlturaCinta;

    private Control CrearCinta()
    {
        cintaFormula = new FlowLayoutPanel
        {
            Name = "polinomica_cinta", AccessibleName = "Herramientas de fórmula polinómica",
            Dock = DockStyle.Top, Height = 108, WrapContents = false, AutoScroll = true,
            Padding = new Padding(2), Margin = Padding.Empty
        };

        ToolStripButton Comando(string texto, string nombre, string icono, Action accion)
        {
            var boton = new ToolStripButton(texto)
            {
                Name = nombre, AutoSize = false, Size = new Size(64, 80),
                ToolTipText = texto.Replace('\n', ' '), AccessibleName = texto.Replace('\n', ' ')
            };
            // La retícula de impresión reconoce sus propios iconos por Tag.
            // Actualizar reutiliza otra fábrica; no debe regenerarse como icono de impresión.
            if (icono != "recalcular") boton.Tag = icono;
            MYGEspecificacionesCinta.Icono(boton, icono, DibujarIconoFormula, 32, true);
            boton.Click += (_, _) => Intentar(accion);
            return boton;
        }
        void Grupo(string titulo, params ToolStripItem[] items)
        {
            var grupo = MYGVistaPreliminarCintaDiseno.Grupo(cintaFormula, titulo, 80);
            grupo.Name = "polinomica_grupo_" + titulo;
            var fila = MYGVistaPreliminarCintaDiseno.Fila(grupo, 4, items);
            fila.Name = "polinomica_barra_" + titulo;
            fila.DpiChangedAfterParent += (_, _) =>
            {
                foreach (var item in fila.Items.OfType<ToolStripButton>().Where(i => i.Tag == null))
                    MYGEspecificacionesCinta.Icono(item, "recalcular", DibujarIconoFormula, 32, true);
            };
            grupo.SizeChanged += (_, _) => AjustarAlturaCinta();
        }

        Grupo("Navegar", Comando("Volver", "polinomica_volver", "volver", Close));
        Grupo("Imprimir",
            Comando("Imprimir\ndetallado", "polinomica_imprimir_detalle", "impresion_rapida", () => Imprimir(true)),
            Comando("Imprimir\nfórmula", "polinomica_imprimir_formula", "impresion_rapida", () => Imprimir(false)),
            Comando("Actualizar", "polinomica_actualizar", "recalcular", Actualizar));
        Grupo("Exportar", Comando("Exportar\nExcel", "polinomica_excel", "formato_xlsx", ExportarExcel));
        cintaFormula.Controls.Add(new Label
        {
            Name = "polinomica_ayuda", AutoSize = true, MaximumSize = new Size(360, 0),
            Margin = new Padding(14, 22, 4, 4), Text = puedeEditar
                ? "Arrastre un índice o monomio sobre otro para agrupar.\nAplicar incorpora los cambios al proyecto; después guarde."
                : "Solo lectura. Puede consultar, imprimir y exportar la fórmula."
        });
        cintaFormula.DpiChangedAfterParent += (_, _) => AjustarAlturaCinta();
        cintaFormula.Layout += (_, _) => AjustarAlturaCinta();
        return cintaFormula;
    }

    private ToolStrip CrearAcciones(out ToolStripButton botonAplicar, out ToolStripButton botonDeshacer)
    {
        accionesFormula = new ToolStrip
        {
            Name = "polinomica_acciones", AccessibleName = "Herramientas de monomios",
            Dock = DockStyle.Right, AutoSize = false, Width = 36, Padding = new Padding(3, 5, 3, 0),
            GripStyle = ToolStripGripStyle.Hidden, LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow,
            ShowItemToolTips = true
        };
        ToolStripButton Accion(string texto, string nombre, string icono, Action accion, bool edicion = false)
        {
            var boton = new ToolStripButton(texto)
            {
                Name = nombre, Tag = icono, AutoSize = false, Size = new Size(29, 32),
                ToolTipText = texto, AccessibleName = texto, Enabled = !edicion || puedeEditar
            };
            MYGEspecificacionesCinta.Icono(boton, icono, DibujarIconoFormula, 22);
            boton.Margin = Padding.Empty;
            boton.Click += (_, _) => Intentar(accion);
            accionesFormula.Items.Add(boton);
            if (edicion) botonesEdicion.Add(boton);
            return boton;
        }
        Accion("Actualizar fórmula", "polinomica_actualizar_monomios", "recalcular", Actualizar);
        Accion("Imprimir fórmula", "polinomica_imprimir_monomios", "impresion_rapida", () => Imprimir(false));
        accionesFormula.Items.Add(new ToolStripSeparator());
        Accion("Subir monomio", "polinomica_subir", "arriba", () => Mover(Seleccion()?.GrupoId, -1), true);
        Accion("Bajar monomio", "polinomica_bajar", "abajo", () => Mover(Seleccion()?.GrupoId, 1), true);
        Accion("Agrupar en otro monomio…", "polinomica_agrupar", "xls_agrupar", AgruparSeleccion, true);
        Accion("Desagrupar índices", "polinomica_desagrupar", "xls_desagrupar", () =>
        { var fila = Seleccion(); if (fila != null) Separar(fila.GrupoId, fila.CodigoIndice); }, true);
        accionesFormula.Items.Add(new ToolStripSeparator());
        botonDeshacer = Accion("Deshacer (Ctrl+Z)", "polinomica_deshacer", "deshacer", () => Deshacer(), true);
        botonAplicar = Accion("Aplicar cambios al proyecto; después guarde", "polinomica_aplicar", "grabar", Aplicar, true);
        accionesFormula.HandleCreated += (_, _) => EscalarAcciones();
        accionesFormula.DpiChangedAfterParent += (_, _) => EscalarAcciones();
        return accionesFormula;
    }

    private void AjustarAlturaCinta()
    {
        if (cintaFormula == null || cintaFormula.IsDisposed || ajustandoAlturaCinta) return;
        ajustandoAlturaCinta = true;
        try
        {
            int alto = cintaFormula.Controls.Cast<Control>().Select(c => c.Height + c.Margin.Vertical).DefaultIfEmpty().Max();
            int minimo = (int)Math.Ceiling(104 * cintaFormula.DeviceDpi / 96f);
            int scroll = cintaFormula.HorizontalScroll.Visible ? SystemInformation.HorizontalScrollBarHeight : 0;
            int requerido = Math.Max(minimo, alto) + cintaFormula.Padding.Vertical + scroll;
            if (cintaFormula.Height != requerido) cintaFormula.Height = requerido;
        }
        finally { ajustandoAlturaCinta = false; }
    }

    private void EscalarAcciones()
    {
        int P(int valor) => (int)Math.Ceiling(valor * accionesFormula.DeviceDpi / 96f);
        accionesFormula.Width = P(36);
        accionesFormula.Padding = new Padding(P(3), P(5), P(3), 0);
        foreach (var boton in accionesFormula.Items.OfType<ToolStripButton>())
        {
            MYGEspecificacionesCinta.Icono(boton, (string)boton.Tag, DibujarIconoFormula, 22);
            boton.Margin = Padding.Empty;
            boton.Size = new Size(P(29), P(32));
        }
    }

    private void AplicarTemaHerramientas()
    {
        MYGEspecificacionesCinta.AplicarTema(cintaFormula);
        MYGEspecificacionesCinta.AplicarTema(accionesFormula);
        AjustarAlturaCinta();
    }

    private static Bitmap DibujarIconoFormula(string id, int tamano, bool seleccionado)
    {
        if (id.StartsWith("xls_", StringComparison.Ordinal))
            return MYGExcelCintaIconos.Dibujar(id, tamano, seleccionado);
        if (id is "recalcular" or "arriba" or "abajo" or "grabar")
        {
            using var original = MYGIconosHerramientasPresupuesto.Obtener(id);
            return new Bitmap(original, new Size(tamano, tamano));
        }
        return MYGVistaPreliminarCintaIconos.Dibujar(id, tamano, seleccionado);
    }
}
