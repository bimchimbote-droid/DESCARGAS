using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class FormulaPolinomicaUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        AlcancePresupuestoSeleccionado(exige);
        JerarquiaPresupuesto(exige);
        CoeficientesConGastos(exige);
        ImpresionConContexto(exige);
        var presupuesto = Crear();
        string original = JsonSerializer.Serialize(presupuesto);
        using (var consulta = new MYGFormulaPolinomicaForm(presupuesto, false))
        {
            consulta.ClientSize = new Size(1200, 760); consulta.Show(); Application.DoEvents();
            var controles = Descendientes(consulta).ToArray();
            var detalle = controles.OfType<DataGridView>().Single(x => x.Name == "polinomica_detalle");
            var monomios = controles.OfType<DataGridView>().Single(x => x.Name == "polinomica_monomios");
            var division = controles.OfType<SplitContainer>().Single(x => x.Name == "polinomica_division");
            exige(consulta.Name == "formula_polinomica_form" && division.Orientation == Orientation.Horizontal &&
                division.Panel1.Controls.Contains(detalle) && division.Panel2.Controls.Contains(monomios) &&
                detalle.Visible && monomios.Visible && detalle.Height > 100 && monomios.Height > 100,
                "La fórmula debe mostrar la matriz arriba y los monomios abajo en una ventana redimensionable.");
            exige(detalle.ReadOnly && monomios.ReadOnly && !monomios.AllowDrop &&
                new[] { "polinomica_aplicar", "polinomica_deshacer", "polinomica_subir", "polinomica_bajar",
                    "polinomica_agrupar", "polinomica_desagrupar" }.All(nombre => !Boton(consulta, nombre).Enabled) &&
                new[] { "polinomica_imprimir_detalle", "polinomica_imprimir_formula", "polinomica_excel",
                    "polinomica_actualizar", "polinomica_actualizar_monomios", "polinomica_imprimir_monomios" }
                    .All(nombre => Boton(consulta, nombre).Enabled),
                "La consulta sin licencia debe permitir impresión y exportación, bloqueando la edición y el arrastre.");
            var grupos = consulta.Configuracion.Grupos;
            exige(!consulta.Agrupar(grupos[0].Id, grupos[1].Id, confirmar: false) &&
                !consulta.Mover(grupos[0].Id, 1) && !consulta.Separar(grupos[0].Id) && !consulta.Deshacer() && !consulta.Cambiado,
                "Las acciones internas también deben respetar el modo de solo lectura.");
            exige(detalle.Columns.Count == 8 && monomios.Columns.Count == 5 && consulta.Resultado.Monomios.Count == 3 &&
                consulta.Resultado.TotalCalculado == 1 && consulta.CantidadPreparaciones == 1,
                "La matriz debe tener las columnas base e índices reales y la fórmula sus cinco columnas de cálculo.");
            ComprobarColumnasFijas(detalle, exige);
            Boton(consulta, "polinomica_actualizar").PerformClick();
            Application.DoEvents();
            ComprobarColumnasFijas(detalle, exige);
            exige(consulta.CantidadPreparaciones == 2 && consulta.Resultado.TotalCalculado == 1,
                "Actualizar debe conservar el bloque fijo hasta Total y todos los aportes del presupuesto.");
            consulta.Close(); Application.DoEvents();
        }

        using (var editor = new MYGFormulaPolinomicaForm(presupuesto, true))
        {
            var grupos = editor.Configuracion.Grupos;
            string inicial = JsonSerializer.Serialize(editor.Configuracion);
            string origen = grupos[0].Id, destino = grupos[1].Id;
            exige(!editor.Agrupar(origen, origen, confirmar: false) && !editor.Deshacer(),
                "Arrastrar un monomio sobre sí mismo no debe editar ni añadir historial.");
            exige(editor.Agrupar(origen, destino, confirmar: false) && editor.Cambiado &&
                editor.Resultado.Monomios.Count == 2 && editor.Resultado.Monomios.Sum(x => x.Importe) == 100 &&
                editor.Resultado.TotalCalculado == 1 && editor.CantidadPreparaciones == 1,
                "Agrupar debe mover el aporte una sola vez y recalcular coeficientes usando la matriz existente.");
            exige(editor.Resultado.Monomios.Single(x => x.Id == destino).Porcentajes.Values.Sum() == 100 &&
                JsonSerializer.Serialize(presupuesto) == original,
                "Los porcentajes deben sumar cien dentro del monomio sin modificar aún el presupuesto.");
            exige(editor.Deshacer() && JsonSerializer.Serialize(editor.Configuracion) == inicial && !editor.Cambiado &&
                editor.CantidadPreparaciones == 1,
                "Deshacer debe restaurar exactamente la configuración previa sin volver a preparar los ACU.");
            exige(editor.Mover(origen, 1) && editor.Configuracion.Grupos[1].Id == origen && editor.Deshacer() &&
                JsonSerializer.Serialize(editor.Configuracion) == inicial,
                "El orden de monomios debe poder cambiarse y deshacerse conservando sus identidades.");
            exige(editor.Agrupar(origen, destino, confirmar: false) && editor.Separar(destino) &&
                editor.Configuracion.Grupos.Count == 3 && editor.Resultado.TotalCalculado == 1 &&
                editor.Resultado.Monomios.Sum(x => x.Importe) == 100 && editor.CantidadPreparaciones == 1,
                "Desagrupar debe recuperar los índices separados sin duplicar aportes ni reconstruir la matriz.");
            var copia = editor.Configuracion;
            copia.Grupos[0].Indices.Clear();
            exige(editor.Configuracion.Grupos[0].Indices.Count > 0,
                "La configuración que entrega el diálogo debe ser una copia aislada.");
            // Descartar el formulario directamente evita aceptar cambios y no abre un diálogo de confirmación.
        }
        exige(JsonSerializer.Serialize(presupuesto) == original && presupuesto.FormulaPolinomica == null,
            "Cerrar una edición sin aplicar no debe modificar el documento, los costos ni sus monomios persistentes.");

        using (var editor = new MYGFormulaPolinomicaForm(presupuesto, true))
        {
            editor.Show(); Application.DoEvents();
            var monomios = Descendientes(editor).OfType<DataGridView>().Single(x => x.Name == "polinomica_monomios");
            string inicial = JsonSerializer.Serialize(editor.Configuracion);
            string primerGrupo = editor.Configuracion.Grupos[0].Id;
            monomios.CurrentCell = monomios.Rows[0].Cells["DESCRIPCION"];
            Boton(editor, "polinomica_bajar").PerformClick(); Application.DoEvents();
            exige(editor.Configuracion.Grupos[1].Id == primerGrupo && Boton(editor, "polinomica_deshacer").Enabled,
                "Bajar desde la barra lateral debe mover el monomio seleccionado y habilitar su reversión.");
            Boton(editor, "polinomica_deshacer").PerformClick(); Application.DoEvents();
            exige(JsonSerializer.Serialize(editor.Configuracion) == inicial && !editor.Cambiado &&
                !Boton(editor, "polinomica_deshacer").Enabled && editor.CantidadPreparaciones == 1 &&
                JsonSerializer.Serialize(presupuesto) == original,
                "Deshacer desde la barra lateral debe revertir el movimiento sin recalcular ACU ni cambiar el documento original.");
            monomios.CurrentCell = monomios.Rows[0].Cells["DESCRIPCION"];
            exige(monomios.BeginEdit(true), "Debe ser posible editar la descripción de un monomio.");
            ((TextBox)monomios.EditingControl).Text = "Descripción editada";
            Boton(editor, "polinomica_actualizar_monomios").PerformClick();
            Application.DoEvents();
            exige(editor.Configuracion.Grupos[0].Descripcion == "Descripción editada" &&
                !editor.Configuracion.Grupos[0].Descripcion.Contains('▾') && editor.CantidadPreparaciones == 2 &&
                JsonSerializer.Serialize(presupuesto) == original,
                "Actualizar desde la barra lateral debe confirmar y conservar una descripción pendiente válida sin incorporar la flecha ni modificar el documento original.");
            monomios.CurrentCell = monomios.Rows[0].Cells["DEFINIDO"];
            exige(monomios.BeginEdit(true), "Debe ser posible editar el coeficiente definido.");
            ((TextBox)monomios.EditingControl).Text = 0.333m.ToString(System.Globalization.CultureInfo.CurrentCulture);
            var finalizar = typeof(MYGFormulaPolinomicaForm).GetMethod("FinalizarEdicion", BindingFlags.Instance | BindingFlags.NonPublic);
            exige((bool)finalizar.Invoke(editor, null) && editor.Resultado.Monomios[0].CoeficienteDefinido == 0.333m,
                "Finalizar una edición antes de imprimir o aplicar debe actualizar el resultado sin depender de un callback pendiente.");
            Application.DoEvents();
            var grupos = editor.Configuracion.Grupos;
            exige(editor.Agrupar(grupos[0].Id, grupos[1].Id, confirmar: false),
                "La agrupación de prueba debe preparar un cambio antes de aplicar.");
            Boton(editor, "polinomica_aplicar").PerformClick();
            Application.DoEvents();
            exige(editor.DialogResult == DialogResult.OK && editor.Cambiado &&
                JsonSerializer.Serialize(presupuesto) == original,
                "Aplicar debe devolver la configuración al editor sin escribir directamente ni guardar la base.");
        }
    }

    private static void ImpresionConContexto(Action<bool, string> exige)
    {
        var presupuesto = Crear();
        var proyecto = new MYGProyectoDocumento
        {
            Nombre = "OBRA PARA IMPRESIÓN QA",
            Datos = new() { Propietario = "PROPIETARIO QA", Localidad = "LOCALIDAD QA" },
            Presupuestos = new() { presupuesto }
        };
        using var ventana = new MYGFormulaPolinomicaForm(presupuesto, true, proyecto);
        ventana.Show(); Application.DoEvents();
        string original = JsonSerializer.Serialize(proyecto);
        var detalle = ventana.PrepararReporteImpresion(true);
        var formula = ventana.PrepararReporteImpresion(false);
        exige(detalle.EsFormulaPolinomica && detalle.ColumnasRepetidas == 6 && !detalle.RepetirDatosProyecto
            && detalle.Hoja.OrientacionPagina == "Horizontal" && formula.Hoja.OrientacionPagina == "Vertical"
            && formula.Hoja.Columnas == 4 && formula.TerminosFormula.Count == ventana.Resultado.Monomios.Count
            && formula.CabeceraImpresion.Single(d => d.Key == "PROYECTO").Value == proyecto.Nombre
            && formula.CabeceraImpresion.Single(d => d.Key == "UBICACIÓN").Value.Contains("LOCALIDAD QA")
            && JsonSerializer.Serialize(proyecto) == original,
            "Ambos botones deben preparar las plantillas Delphin con el contexto de obra y las opciones del motor común, sin editar el proyecto.");
        var tabla = Descendientes(ventana).OfType<DataGridView>().Single(t => t.Name == "polinomica_monomios");
        tabla.CurrentCell = tabla.Rows[0].Cells["DEFINIDO"];
        exige(tabla.BeginEdit(true), "Debe poder prepararse una edición pendiente antes de imprimir.");
        ((TextBox)tabla.EditingControl).Text = .333m.ToString(System.Globalization.CultureInfo.CurrentCulture);
        var editada = ventana.PrepararReporteImpresion(false);
        exige(editada.TerminosFormula[0].Coeficiente == .333m && JsonSerializer.Serialize(proyecto) == original,
            "Imprimir debe confirmar la edición pendiente en la copia de trabajo y reflejarla en K1 sin guardar ni aplicar el proyecto.");
        proyecto.Nombre = "CAMBIO EXTERNO";
        proyecto.Datos.Propietario = "OTRO PROPIETARIO";
        var aislada = ventana.PrepararReporteImpresion(false);
        exige(aislada.CabeceraImpresion.Single(d => d.Key == "PROYECTO").Value == "OBRA PARA IMPRESIÓN QA"
            && aislada.CabeceraImpresion.Single(d => d.Key == "PROPIETARIO").Value == "PROPIETARIO QA",
            "La impresión debe usar el contexto congelado al abrir la fórmula, sin retener vínculos editables al proyecto.");
    }

    private static void CoeficientesConGastos(Action<bool, string> exige)
    {
        var p = Crear();
        p.Costos.GastosGeneralesPorcentaje = 12;
        p.Costos.UtilidadPorcentaje = 10;
        p.Costos.ImpuestoPorcentaje = 18;
        string antes = JsonSerializer.Serialize(p);
        using var ventana = new MYGFormulaPolinomicaForm(p, true);
        ventana.Show(); Application.DoEvents();
        var controles = Descendientes(ventana).ToArray();
        var tabla = controles.OfType<DataGridView>().Single(c => c.Name == "polinomica_monomios");
        exige(ventana.Resultado.BaseCoeficientes == 122m
            && ventana.Resultado.Monomios.Single(m => m.Indices.Single().Codigo == "39").Importe == 22m,
            "La fórmula debe incorporar GG y utilidad al IU 39 y usar una base de 122, sin el impuesto.");
        foreach (var grupo in ventana.Resultado.Monomios)
        foreach (var indice in grupo.Indices)
        {
            var fila = tabla.Rows.Cast<DataGridViewRow>().Single(r => Convert.ToString(r.Cells[0].Value)
                .StartsWith("      " + indice.Codigo + "  ", StringComparison.Ordinal));
            exige(Convert.ToDecimal(fila.Cells["CALCULADO"].Value) == indice.Total / 122m
                && Convert.ToDecimal(fila.Cells["DEFINIDO"].Value) == decimal.Round(indice.Total / 122m, 3, MidpointRounding.AwayFromZero),
                "Los coeficientes de los índices hijos deben usar la misma base efectiva que sus monomios.");
        }
        exige(controles.OfType<Label>().Single(c => c.Name == "polinomica_total_formula").Text.Contains("IU 39")
            && JsonSerializer.Serialize(p) == antes,
            "La ventana debe explicar el IU 39 y consultar los coeficientes sin alterar el presupuesto original.");
        var origen = ventana.Configuracion.Grupos.Single(g => g.Indices.Contains("39"));
        var destino = ventana.Configuracion.Grupos.First(g => g.Id != origen.Id);
        exige(ventana.Agrupar(origen.Id, destino.Id, "39", confirmar: false)
            && ventana.Resultado.Monomios.Sum(m => m.Importe) == 122m,
            "El IU 39 creado sólo para la fórmula debe poder agruparse sin buscarlo en las columnas de costo directo.");
    }

    private static void ComprobarColumnasFijas(DataGridView detalle, Action<bool, string> exige)
    {
        string[] fijas = { "DESCRIPCION", "UNIDAD", "METRADO", "PRECIO", "TOTAL" };
        exige(fijas.All(nombre => detalle.Columns[nombre].Frozen) &&
            detalle.Columns.Cast<DataGridViewColumn>().Where(c => c.Name.StartsWith("IU_", StringComparison.Ordinal)).All(c => !c.Frozen) &&
            !detalle.AllowUserToOrderColumns,
            "Descripción, unidad, metrado, precio y Total deben quedar fijos, dejando solo los índices como columnas desplazables.");
    }

    private static void AlcancePresupuestoSeleccionado(Action<bool, string> exige)
    {
        var activo = Crear(); activo.Nombre = "Presupuesto activo A";
        var elegido = Crear(); elegido.Nombre = "Presupuesto seleccionado B";
        var partida = elegido.Items.Single();
        partida.Costos.Cantidad = 2;
        var titulo = new ItemPresupuestoDelphin
        {
            Id = "TITULO-B", IdLocalMYG = "TITULO-B", Item = "01", Descripcion = "Título del presupuesto B",
            TipoPropuesta = "TITULO", Unidad = ""
        };
        partida.ParentId = titulo.Id;
        elegido.Items.Insert(0, titulo);
        var hermana = new ItemPresupuestoDelphin
        {
            Id = "HERMANA-B", IdLocalMYG = "HERMANA-B", ParentId = titulo.Id,
            Item = "01.02", Descripcion = "Otra partida del mismo presupuesto B",
            TipoPropuesta = "PARTIDA", Unidad = "und", Costos = new() { Cantidad = 1, PrecioDirecto = 50 }
        };
        elegido.Items.Add(hermana);
        var proyecto = new MYGProyectoDocumento
        {
            Nombre = "Alcance de fórmula", PresupuestoActivoId = activo.Id,
            Presupuestos = new() { activo, elegido }
        };
        string original = JsonSerializer.Serialize(proyecto);
        foreach (object seleccion in new object[] { elegido, titulo, partida })
        {
            var presupuesto = EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, seleccion);
            exige(ReferenceEquals(presupuesto, elegido) && presupuesto.Items.Contains(hermana) &&
                presupuesto.Items.Count == 3,
                "Seleccionar el presupuesto B, uno de sus títulos o una partida debe resolver B entero, aunque A siga activo y tenga una partida con el mismo Id.");
            using var ventana = new MYGFormulaPolinomicaForm(presupuesto, false);
            var detalle = Descendientes(ventana).OfType<DataGridView>().Single(x => x.Name == "polinomica_detalle");
            var filas = detalle.Rows.Cast<DataGridViewRow>().Select(x => x.Tag).OfType<MYGFilaFormulaPolinomica>().ToArray();
            exige(filas.Length == 3 && filas.Count(x => !x.EsTitulo) == 2 && filas.Any(x => x.Id == hermana.Id) &&
                ventana.Resultado.Monomios.Sum(x => x.Importe) == 250,
                "La ventana debe incluir todas las partidas de B, también la hermana no seleccionada, y excluir los cien del presupuesto A.");
        }
        exige(ReferenceEquals(EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, MYGProyectoStorage.Copia(elegido)), elegido) &&
            ReferenceEquals(EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, MYGProyectoStorage.Copia(hermana)), elegido),
            "Una selección copiada debe recuperar el presupuesto vigente cuando su identidad o la de su partida identifican un único propietario.");
        bool RechazaSeleccion(object seleccion)
        {
            try { EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, seleccion); return false; }
            catch (InvalidOperationException) { return true; }
        }
        exige(RechazaSeleccion(MYGProyectoStorage.Copia(partida)) &&
            RechazaSeleccion(new MYGPresupuestoDocumento { Nombre = "Presupuesto retirado" }) &&
            RechazaSeleccion(new ItemPresupuestoDelphin { Id = "PARTIDA-RETIRADA" }),
            "Una selección ambigua o retirada debe rechazarse, en lugar de abrir silenciosamente la fórmula del presupuesto activo.");
        exige(ReferenceEquals(EditorForm.ResolverPresupuestoFormulaPolinomica(proyecto, null), activo) &&
            JsonSerializer.Serialize(proyecto) == original,
            "Sin selección debe usarse el presupuesto activo y consultar otra selección no debe cambiar el documento ni su presupuesto activo.");
    }

    private static void JerarquiaPresupuesto(Action<bool, string> exige)
    {
        var presupuesto = Crear(); presupuesto.Nombre = "Presupuesto con jerarquía"; presupuesto.Item = "01";
        var partida = presupuesto.Items.Single(); partida.ParentId = "SUB-A"; partida.Posicion = 1;
        var tituloA = new ItemPresupuestoDelphin { Id = "T-A", IdLocalMYG = "T-A", Item = "01", Posicion = 1,
            Descripcion = "Capítulo A", TipoPropuesta = "TITULO", Unidad = "" };
        var subtitulo = new ItemPresupuestoDelphin { Id = "SUB-A", IdLocalMYG = "SUB-A", ParentId = tituloA.Id,
            Item = "01.01", Posicion = 1, Descripcion = "Subcapítulo A", TipoPropuesta = "TITULO", Unidad = "" };
        var tituloB = new ItemPresupuestoDelphin { Id = "T-B", IdLocalMYG = "T-B", Item = "02", Posicion = 2,
            Descripcion = "Capítulo B", TipoPropuesta = "TITULO", Unidad = "" };
        ItemPresupuestoDelphin Hoja(string id, string padre, int posicion, decimal precio) => new()
        {
            Id = id, IdLocalMYG = id, ParentId = padre, Item = id, Posicion = posicion,
            Descripcion = id, TipoPropuesta = "PARTIDA", Unidad = "und", Costos = new() { Cantidad = 1, PrecioDirecto = precio }
        };
        var hermana = Hoja("HOJA-A", tituloA.Id, 2, 20);
        var hojaB = Hoja("HOJA-B", tituloB.Id, 1, 50);
        // El almacenamiento no tiene por qué estar ya ordenado para presentar el árbol.
        presupuesto.Items.Clear(); presupuesto.Items.AddRange(new[] { hojaB, partida, tituloB, hermana, subtitulo, tituloA });
        for (int n = 0; n < 12; n++) presupuesto.Items.Add(Hoja("EXTRA-" + n, tituloA.Id, n + 3, 1));
        string original = JsonSerializer.Serialize(presupuesto);
        using var ventana = new MYGFormulaPolinomicaForm(presupuesto, false);
        ventana.ClientSize = new Size(980, 760); ventana.Show(); Application.DoEvents();
        var detalle = Descendientes(ventana).OfType<DataGridView>().Single(x => x.Name == "polinomica_detalle");
        DataGridViewRow Fila(string id) => detalle.Rows.Cast<DataGridViewRow>()
            .Single(r => r.Tag is MYGFilaFormulaPolinomica f && f.Id == id);
        bool Existe(string id) => detalle.Rows.Cast<DataGridViewRow>()
            .Any(r => r.Tag is MYGFilaFormulaPolinomica f && f.Id == id);
        var raiz = detalle.Rows[0]; var filaA = Fila(tituloA.Id); var filaSub = Fila(subtitulo.Id);
        var filaPartida = Fila(partida.Id); var filaHermana = Fila(hermana.Id); var filaB = Fila(tituloB.Id);
        int cantidadExpandida = detalle.Rows.Count;
        exige(raiz.Tag is MYGPresupuestoDocumento p && p.Id == presupuesto.Id &&
            Convert.ToString(raiz.Cells["DESCRIPCION"].Value).Contains(presupuesto.Nombre) &&
            Convert.ToDecimal(raiz.Cells["TOTAL"].Value) == 182 &&
            filaA.Index == 1 && filaSub.Index == 2 && filaPartida.Index == 3 && filaHermana.Index == 4 &&
            filaB.Index > filaHermana.Index && Fila(hojaB.Id).Index == filaB.Index + 1,
            "El detalle debe comenzar en el presupuesto y ordenar títulos, subtítulos y partidas por la jerarquía existente, aunque los datos estén desordenados.");
        exige(raiz.InheritedStyle.Font.Bold && raiz.InheritedStyle.ForeColor == MYG2027_TemaComercial.ColorTitulo(0) &&
            filaA.InheritedStyle.ForeColor == MYG2027_TemaComercial.ColorTitulo(1) &&
            filaSub.InheritedStyle.ForeColor == MYG2027_TemaComercial.ColorTitulo(2) &&
            filaB.InheritedStyle.ForeColor == MYG2027_TemaComercial.ColorTitulo(1) &&
            filaPartida.InheritedStyle.ForeColor == MYG2027_TemaComercial.Texto,
            "La raíz y cada nivel deben reutilizar los colores del presupuesto, conservando el color de texto de las partidas.");
        ComprobarColumnasFijas(detalle, exige);
        detalle.CurrentCell = filaPartida.Cells["DESCRIPCION"];
        detalle.HorizontalScrollingOffset = 24;
        int horizontal = detalle.HorizontalScrollingOffset;
        exige(ventana.AlternarDetalle(filaSub) && !Existe(partida.Id) && Existe(hermana.Id) && Existe(hojaB.Id) &&
            ReferenceEquals(detalle.CurrentRow, filaSub) && detalle.HorizontalScrollingOffset == horizontal,
            "Contraer un subtítulo debe ocultar solo sus descendientes, preservar las ramas hermanas y situar una selección oculta en el antecesor visible sin mover las columnas.");
        exige(ventana.AlternarDetalle(filaA) && !Existe(subtitulo.Id) && !Existe(hermana.Id) && Existe(hojaB.Id) &&
            ventana.AlternarDetalle(filaA) && Existe(subtitulo.Id) && Existe(hermana.Id) && !Existe(partida.Id),
            "Reabrir un título debe conservar el estado contraído de su subtítulo y no afectar a otros capítulos.");
        exige(ventana.AlternarDetalle(filaSub) && ReferenceEquals(Fila(partida.Id), filaPartida) &&
            !ventana.AlternarDetalle(filaPartida),
            "El plegado debe reutilizar las filas calculadas al reabrir y no permitir contraer una partida sin hijos.");
        detalle.CurrentCell = Fila(hojaB.Id).Cells["DESCRIPCION"];
        exige(ventana.AlternarDetalle(raiz) && detalle.Rows.Count == 2 && ReferenceEquals(detalle.Rows[0], raiz) &&
            ReferenceEquals(detalle.CurrentRow, raiz),
            "Contraer el presupuesto debe dejar visible su fila raíz y el total, conservando una selección válida.");
        ventana.PlegarTodoDetalle(false);
        exige(detalle.Rows.Count == cantidadExpandida && Existe(partida.Id) && Existe(hermana.Id) && Existe(hojaB.Id),
            "Expandir todo debe abrir presupuesto y todos sus títulos sin omitir partidas.");
        ventana.PlegarTodoDetalle(true);
        exige(detalle.Rows.Count == 2 && ReferenceEquals(detalle.Rows[0], raiz),
            "Contraer todo debe incluir la raíz del presupuesto y conservar el total.");
        ventana.PlegarTodoDetalle(false);
        var pulsar = typeof(DataGridView).GetMethod("OnCellMouseClick", BindingFlags.Instance | BindingFlags.NonPublic);
        void PulsarFila(DataGridViewRow fila, int x)
        {
            var raton = new MouseEventArgs(MouseButtons.Left, 1, x, 10, 0);
            pulsar.Invoke(detalle, new object[] { new DataGridViewCellMouseEventArgs(0, fila.Index, x, 10, raton) });
        }
        PulsarFila(filaA, 150);
        exige(detalle.Rows.Count == cantidadExpandida && Existe(partida.Id),
            "Pulsar el texto de un título debe permitir seleccionarlo sin plegarlo accidentalmente.");
        int flecha = MYGJerarquiaTablaPresupuesto.Sangria(1, detalle.DeviceDpi) + 4;
        PulsarFila(filaA, flecha);
        exige(!Existe(partida.Id) && !Existe(hermana.Id) && Existe(hojaB.Id),
            "Solo la zona de la flecha debe contraer la rama indicada, con la sangría y escala de la lista del presupuesto.");
        PulsarFila(filaA, flecha);
        var tecla = typeof(Control).GetMethod("OnKeyDown", BindingFlags.Instance | BindingFlags.NonPublic);
        detalle.CurrentCell = filaA.Cells["DESCRIPCION"];
        var izquierda = new KeyEventArgs(Keys.Left); tecla.Invoke(detalle, new object[] { izquierda });
        exige(izquierda.Handled && !Existe(partida.Id) && Existe(hojaB.Id),
            "La flecha izquierda del teclado debe contraer el título seleccionado sin afectar a capítulos hermanos.");
        var derecha = new KeyEventArgs(Keys.Right); tecla.Invoke(detalle, new object[] { derecha });
        exige(derecha.Handled && Existe(partida.Id) && Existe(hermana.Id) && detalle.Rows.Count == cantidadExpandida,
            "La flecha derecha del teclado debe expandir el título seleccionado conservando el árbol completo.");
        tecla.Invoke(detalle, new object[] { new KeyEventArgs(Keys.Right) });
        exige(detalle.Rows.Count == cantidadExpandida,
            "La flecha derecha sobre un título ya abierto no debe volver a contraerlo.");
        exige(ventana.CantidadPreparaciones == 1 && ventana.Resultado.Monomios.Sum(x => x.Importe) == 182 &&
            JsonSerializer.Serialize(presupuesto) == original && !ventana.Cambiado,
            "Expandir y contraer solo debe cambiar la presentación: sin recalcular ACU, duplicar totales ni modificar el documento o sus monomios.");
        ComprobarColumnasFijas(detalle, exige);
        ventana.Close(); Application.DoEvents();
    }

    private static MYGPresupuestoDocumento Crear()
    {
        var p = new MYGPresupuestoDocumento { Nombre = "Fórmula UI" };
        var partida = new ItemPresupuestoDelphin
        {
            Id = "PARTIDA", IdLocalMYG = "PARTIDA", Item = "01", Descripcion = "Partida de prueba",
            TipoPropuesta = "PARTIDA", Unidad = "und", Costos = new() { Cantidad = 1 }
        };
        for (int n = 0; n < 3; n++)
        {
            var insumo = new MYGInsumo { Id = "I" + n, Codigo = "R" + n, Precio = new[] { 40m, 10m, 50m }[n],
                Descripcion = "Insumo " + n, GrupoGenerico = new[] { "21 · Cemento", "37 · Herramientas", "47 · Mano de obra" }[n] };
            p.Costos.Insumos.Add(insumo);
            partida.Costos.Analisis.Add(new() { InsumoId = insumo.Id, Cantidad = 1 });
        }
        p.Items.Add(partida); return p;
    }

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var nieto in Descendientes(hijo)) yield return nieto;
        }
    }

    private static ToolStripButton Boton(Control formulario, string nombre) => Descendientes(formulario)
        .OfType<ToolStrip>().SelectMany(barra => barra.Items.OfType<ToolStripButton>()).Single(boton => boton.Name == nombre);
}
