# Fórmula polinómica

Implementación basada en la grabación aportada: una ventana con el presupuesto
desglosado por índices unificados y los monomios con sus coeficientes.

## Uso

1. Abra un proyecto y seleccione un presupuesto. Pulse **Fórmula polinómica**.
2. La tabla superior muestra partidas, títulos, metrados, precios, importes y
   aportes por índice unificado. Los índices proceden de la clasificación real
   de los insumos; los precios directos y aportes sin clasificación se muestran
   expresamente como **Sin índice asignado / diferencias de redondeo**.
3. La tabla inferior muestra monomios e índices integrantes. Arrastre un índice
   o monomio a otro y confirme para mover su aporte, sin duplicarlo. También
   puede usar **Agrupar**, **Desagrupar**, **Subir**, **Bajar** y **Deshacer**.
4. Puede editar descripción, nomenclatura y coeficiente definido del monomio.
   Los coeficientes automáticos se redondean a tres decimales; al cambiar los
   integrantes se recalculan. Los porcentajes de los índices corresponden a su
   participación dentro del monomio.
5. **Aplicar** incorpora la configuración al historial del proyecto. Después
   use **Guardar** en el editor para conservarla en la base SQLite. Cerrar sin
   aplicar descarta la copia de trabajo.
6. **Imprimir detallado**, **Imprimir fórmula** y **Exportar Excel** incluyen
   todos los datos, aunque haya grupos contraídos. El Excel contiene dos hojas.

La consulta, impresión y exportación están disponibles en modo de lectura.
Aplicar cambios requiere permiso de edición vigente. Agrupar utiliza la matriz
ya calculada; **Actualizar** vuelve a preparar sus importes.

## Alcance del cálculo

Se desglosa el costo directo con el motor existente: ACU, subpartidas,
porcentajes de mano de obra, IGV configurado, metrados y precisión del presupuesto.
No se añaden gastos generales, utilidad ni impuestos del pie a ese desglose.
Los títulos acumulan sus partidas sin volver a sumarlos al total general.
La aplicación no decide automáticamente la clasificación de un recurso.

Los coeficientes de la fórmula inferior usan otra base: **costo directo +
gastos generales + utilidad**, sin impuestos. Se utilizan los importes efectivos
del motor de costos; GG y utilidad se suman al IU **39**, además de cualquier
aporte directo que ya tenga ese índice. El detalle superior mantiene el costo
directo original. La ventana y el informe de fórmula identifican la base usada.
En pies personalizados arbitrarios, el motor no identifica automáticamente
filas propias como GG/utilidad; se conservan sus importes reconocidos por el motor.

Las diferencias exclusivamente de redondeo que no alcanzan la unidad monetaria
de presentación ni en una fila, ni en un título, ni en el total se conservan
como ajuste de conciliación. No crean una columna «Sin índice» que se vea como
0,00 y no se atribuyen a un IU supuesto. Los recursos realmente sin clasificación,
los precios directos sin desglose y las diferencias visibles mantienen su columna
y su advertencia, aunque otros importes los compensen.

Se advierte cuando hay más de ocho monomios, coeficientes definidos inferiores
a 0,050, aportes sin índice o una suma de coeficientes distinta de 1,000. Los
avisos permiten seguir preparando la agrupación; no certifican su aprobación
normativa ni se ajustan importes silenciosamente para ocultar diferencias.

La configuración se conserva por presupuesto en el documento MYG y sus
extensiones SQLite existentes. Al importar una base Delphin se leen las
agrupaciones disponibles en `titulo_indice`; no se reescriben esas agrupaciones
nativas al consultar la ventana. No hay una migración SQL manual que ejecutar.

Algunas bases Delphin reconstruyen un monomio por índice, pero conservan filas
históricas enlazadas a IDs reutilizados. Se reconoce ese listado individual sólo
si todas sus raíces tienen códigos distintos, porcentaje 100 y un hijo del mismo
IU que conserva el coeficiente completo y el 100 %. En ese caso no se absorben
las filas antiguas ajenas. Si no se cumple el patrón completo, se conserva la
jerarquía de agrupación. Los coeficientes nativos todos a cero se interpretan
como no inicializados únicamente en ese patrón; los coeficientes y agrupaciones
explícitos guardados por el usuario en extensiones MYG se conservan.

Los coeficientes redondeados no se fuerzan a sumar 1,000. Si el exportado de
Delphin suma 1,001, se mantiene esa suma y su advertencia para revisión. Una
lista inicial de más de ocho monomios conserva también el aviso para agruparla.

## Compilación y pruebas

Validación de esta corrección con .NET SDK 10.0.100:

- Solución Release completa: 0 errores y 0 advertencias.
- Fórmula polinómica: 16 comprobaciones aprobadas; suite general: 766 aprobadas.
- Comparación externa con la base y el Excel aportados: 37 de 37 coeficientes
  coinciden, también después de guardar/reabrir una copia; 313 comprobaciones.
  La huella SHA-256 de la base original no cambió. Los datos y el harness privado
  de comparación no se incluyen en esta entrega.
- Pruebas UI: compiladas; su ejecución y la comprobación visual requieren Windows.
- No se reejecutó la suite Nube completa, cuyo fallo previo documentado en
  `PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar` es ajeno a esta corrección.

Desde la raíz del proyecto con SDK .NET 10 (se verificó 10.0.100):

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --formula-polinomica
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

El indicador `UseRevitReferencePackages=true` permite compilar sin una
instalación local de Revit. Para desarrollar con Revit 2027 instalado, use las
instrucciones existentes de `LEEME.md`.

Las pruebas de interfaz requieren Windows:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --formula-polinomica
```

En Windows, compruebe además el arrastre real y su confirmación, la edición
de celdas, cancelar/aplicar/deshacer, guardar y reabrir SQLite, la legibilidad a
distintas escalas de pantalla y la vista previa e impresión/PDF de ambas tablas.
Linux permite compilar la interfaz y ejecutar las pruebas de datos; no permite
validar visualmente Windows Forms, la impresora ni una sesión real de Revit.

## Aplicación manual de la entrega

La base de esta actualización es `main` en
`e1ddbca0e509b84523c33627d9679c9c9add5ddf`.

1. Respalde o confirme sus cambios locales antes de copiar archivos.
2. Descargue el ZIP de actualización y extráigalo fuera de su proyecto.
3. Copie sus archivos conservando las rutas relativas. Los archivos existentes
   se entregan completos: compare antes de reemplazarlos si tiene cambios
   posteriores al commit base. No se elimina ningún archivo ni base de datos.
4. Compile y ejecute las comprobaciones anteriores.
5. Revise los cambios en **Cambios de Git** de Visual Studio, haga commit en la
   rama de trabajo deseada y use Push. Compruebe la rama y el commit en GitHub.

La publicación del ZIP en el repositorio independiente `DESCARGAS` no publica
estos cambios en `MYG.Presupuestos` ni los aplica automáticamente a su equipo.
