#nullable enable
using System.Net;
using System.Security.Cryptography;
using System.Text.Json;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    private const int MaxParteComprimidaBytes = 8 * 1024 * 1024;
    private const string RutaBucketComprimido = "storage/v1/object/myg-nube-paquetes/";

    /// <summary>Prepara una publicación nueva sin subir adjuntos por separado si usará Gzip.</summary>
    public async Task<JsonElement> PrepararArchivosPublicacionAsync(JsonElement contenido, Guid proyecto,
        CancellationToken ct = default)
    {
        ValidarIdNube(proyecto);
        if ((await ObtenerCapacidadesNubeAsync(ct)).PublicacionComprimida == 1)
        {
            string estado = await EjecutarRpcNubeAsync("myg_nube_estado_publicacion", new { p_id = proyecto },
                raiz => TextoNube(raiz, "estado", 16), ct);
            if (estado == "procesando")
                throw new NubeException("El servidor sigue procesando la publicación. Se conserva el pendiente y su identificador.", esErrorDeConexion: true);
            if (estado == "disponible" || (estado == "existente" && await EsProyectoComprimidoAsync(proyecto, ct)))
                return await PrepararContenidoComprimidoAsync(contenido, ct);
            if (estado != "existente") throw RespuestaNubeInvalida();
        }
        return await PrepararArchivosAsync(contenido, proyecto, ct);
    }

    /// <summary>Mantiene los adjuntos dentro del snapshot para proyectos Gzip; preserva los legados.</summary>
    public async Task<JsonElement> PrepararArchivosProyectoAsync(JsonElement contenido, Guid proyecto, Guid lote,
        CancellationToken ct = default)
    {
        ValidarIdNube(proyecto); ValidarIdNube(lote);
        return await EsProyectoComprimidoAsync(proyecto, ct)
            ? await PrepararContenidoComprimidoAsync(contenido, ct)
            : await PrepararArchivosAsync(contenido, lote, ct);
    }

    private async Task<JsonElement> PrepararContenidoComprimidoAsync(JsonElement contenido, CancellationToken ct)
    {
        // El trigger productivo que vincula objetos del bucket antiguo no está
        // disponible aquí. Un snapshot autocontenido conserva la colaboración y
        // la recuperación sin inventar permisos sobre referencias ocultas.
        JsonElement hidratado = await CargarArchivosAsync(contenido, ct);
        FormatoPaqueteNube.ValidarSinExpandir(hidratado);
        if (SinArchivosNube(hidratado)) return hidratado;
        var copia = CopiarContenidoArchivos(hidratado);
        foreach (var archivo in LeerArchivosNube(copia, paraSubir: false))
            archivo.Nodo["Almacen"] = "";
        return JsonSerializer.SerializeToElement(copia, OpcionesNube);
    }

    // No añadir consultas a las rutas de clientes/servidores anteriores. El código
    // MGC01 del servidor permite descubrir la capacidad al abrir una obra nueva.
    private async Task<bool> EsProyectoComprimidoAsync(Guid id, CancellationToken ct, bool forzar = false)
    {
        ValidarIdNube(id);
        if (capacidadesNube?.PublicacionComprimida != 1)
        {
            if (!forzar) return false;
            capacidadesNube = null;
            if ((await ObtenerCapacidadesNubeAsync(ct)).PublicacionComprimida != 1) return false;
        }
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_nube_paquete_tipo", new { p_id = id }, raiz =>
        {
            string tipo = TextoNube(raiz, "almacenamiento", 16);
            if (tipo is not ("json" or "gzip")) throw RespuestaNubeInvalida();
            return tipo == "gzip";
        }, ct, identidadEsperada: usuario);
    }

    private async Task<ProyectoNube> CrearProyectoComprimidoAsync(Guid id, string nombre,
        JsonElement contenido, string alcance, CancellationToken ct, IProgress<string>? progreso = null)
    {
        ValidarIdNube(id);
        nombre = ValidarNombreNube(nombre);
        ValidarAlcanceNube(alcance);
        await ExigirServidorComprimidoAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        progreso?.Report("Comprimiendo el paquete para publicarlo");
        JsonElement autocontenido = await PrepararContenidoComprimidoAsync(contenido, ct);
        using var preparado = await PaqueteComprimidoNube.CrearAsync(autocontenido,
            Guid.ParseExact(usuario, "D"), id, ct);
        progreso?.Report($"Paquete: {preparado.BytesJson / 1048576d:N1} MiB → {preparado.BytesGzip / 1048576d:N1} MiB comprimidos");
        await SubirPartesComprimidasAsync(preparado, usuario, id, ct, progreso);
        progreso?.Report($"Enviados {preparado.BytesGzip / 1048576d:N1} MiB comprimidos; esperando confirmación");
        return await EjecutarRpcNubeAsync("myg_nube_crear_comprimido", new
        {
            p_id = id, p_nombre = nombre, p_manifest = preparado.Manifiesto, p_alcance = alcance
        }, raiz =>
        {
            if (raiz.ValueKind != JsonValueKind.Object || raiz.TryGetProperty("contenido", out _))
                throw RespuestaNubeInvalida();
            ProyectoNube proyecto = LeerProyectoNube(raiz, requiereContenido: false, esperado: id);
            if (proyecto.Rol != "propietario" || proyecto.Alcance != alcance || proyecto.Nombre != nombre)
                throw RespuestaNubeInvalida();
            return proyecto;
        }, ct, identidadEsperada: usuario);
    }

    private async Task<ProyectoNube> AbrirProyectoComprimidoAsync(Guid id, CancellationToken ct,
        long? revision = null)
    {
        ValidarIdNube(id);
        if (revision is < 1) throw new NubeException("La revisión solicitada no es válida.");
        await ExigirServidorComprimidoAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        ProyectoNube proyecto = await EjecutarRpcNubeAsync("myg_nube_abrir_comprimido",
            new { p_id = id, p_revision = revision }, raiz =>
            {
                ProyectoNube recibido = LeerProyectoNube(raiz, requiereContenido: true, esperado: id);
                if (revision.HasValue && recibido.Revision != revision.Value) throw RespuestaNubeInvalida();
                return recibido;
            }, ct, identidadEsperada: usuario);
        JsonElement contenido = await DescargarContenidoComprimidoAsync(proyecto.Contenido, id, usuario, ct);
        return proyecto with { Contenido = contenido };
    }

    private async Task<RespuestaGuardarNube> GuardarProyectoComprimidoAsync(Guid id, Guid operacion,
        long revision, JsonElement contenido, CancellationToken ct)
    {
        ValidarIdNube(id);
        ValidarIdNube(operacion);
        if (revision < 1 || revision == long.MaxValue)
            throw new NubeException("La operación necesita una revisión de nube válida.");
        await ExigirServidorComprimidoAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        // El servidor vuelve a comprobar el rol y sus permisos dentro de la
        // transacción; aquí se evita preparar o subir una obra siendo lector.
        ProyectoNube permisos = await ConsultarRevisionProyectoAsync(id, ct);
        await ComprobarCuentaComprimidaAsync(usuario, ct);
        if (permisos.Rol == "lector")
            throw new NubeException("Su acceso al proyecto es de solo lectura. Se conserva la operación pendiente.", codigo: "42501");

        JsonElement autocontenido = await PrepararContenidoComprimidoAsync(contenido, ct);
        using var preparado = await PaqueteComprimidoNube.CrearAsync(autocontenido,
            Guid.ParseExact(usuario, "D"), id, ct);
        string? anterior = null;
        string? nuevo = null;
        var modulos = permisos.PermisosModulos;
        if (modulos is null || !modulos.Acu || !modulos.Especificaciones || !modulos.MetradosExcel)
        {
            // El GZip es opaco para PostgreSQL. Los editores restringidos conservan
            // el control completo por módulo con ambos textos exactos, ligados a
            // sus manifiestos por SHA-256. Nunca se omite esa comprobación.
            ProyectoNube baseExacta = await AbrirProyectoComprimidoAsync(id, ct, revision);
            await ComprobarCuentaComprimidaAsync(usuario, ct);
            anterior = baseExacta.Contenido.GetRawText();
            nuevo = await preparado.LeerTextoJsonAsync(ct);
        }
        await SubirPartesComprimidasAsync(preparado, usuario, id, ct);
        RespuestaGuardarNube respuesta = await EjecutarRpcNubeAsync("myg_nube_guardar_comprimido", new
        {
            p_id = id, p_operacion = operacion, p_revision = revision, p_manifest = preparado.Manifiesto,
            p_anterior = anterior, p_nuevo = nuevo
        }, raiz =>
        {
            string estado = TextoNube(raiz, "estado", 32);
            if (estado is not ("aplicada" or "conflicto")) throw RespuestaNubeInvalida();
            Guid confirmado = GuidNube(raiz, "operacion_id");
            long recibida = RevisionNube(raiz);
            if (confirmado != operacion || (estado == "aplicada" && recibida != revision + 1))
                throw RespuestaNubeInvalida();
            if (estado == "aplicada" && raiz.TryGetProperty("contenido", out _)) throw RespuestaNubeInvalida();
            JsonElement confirmadoContenido = estado == "aplicada" ? autocontenido.Clone() : ContenidoNube(raiz);
            return new RespuestaGuardarNube(estado, recibida, confirmadoContenido, confirmado);
        }, ct, identidadEsperada: usuario);
        if (respuesta.Estado == "conflicto")
            respuesta = respuesta with
            {
                Contenido = await DescargarContenidoComprimidoAsync(respuesta.Contenido, id, usuario, ct)
            };
        return respuesta;
    }

    private async Task ExigirServidorComprimidoAsync(CancellationToken ct)
    {
        if ((await ObtenerCapacidadesNubeAsync(ct)).PublicacionComprimida != 1)
        {
            capacidadesNube = null;
            throw new NubeException("Actualice Supabase con 20261028_publicacion_comprimida.sql para usar paquetes GZip. Se conserva el intento pendiente.");
        }
    }

    private Task ComprobarCuentaComprimidaAsync(string usuario, CancellationToken ct) =>
        EjecutarAsync(async token =>
        {
            await ComprobarIdentidadArchivosAsync(usuario, token);
            return true;
        }, ct);

    private async Task SubirPartesComprimidasAsync(PaqueteComprimidoPreparado preparado,
        string usuario, Guid proyecto, CancellationToken ct, IProgress<string>? progreso = null)
    {
        // La lista ordenada puede contener el mismo bloque varias veces. El objeto
        // inmutable se sube una vez y el manifiesto conserva todas sus posiciones.
        var unicas = preparado.Partes.DistinctBy(p => p.Ruta).ToArray();
        int numero = 0;
        foreach (var parte in unicas)
        {
            ct.ThrowIfCancellationRequested();
            progreso?.Report($"Enviando paquete comprimido: parte {++numero} de {unicas.Length} ({preparado.BytesGzip / 1048576d:N1} MiB)");
            if (!RutaParteComprimidaValida(parte.Ruta, proyecto) || !parte.Ruta.StartsWith(usuario + "/", StringComparison.Ordinal)
                || parte.Bytes is < 1 or > MaxParteComprimidaBytes)
                throw ErrorPaqueteComprimido("Una parte del paquete no tiene una ruta o un tamaño válido.");
            using Stream flujo = parte.AbrirLectura();
            byte[] bytes = await LeerBytesParteComprimidaAsync(flujo, parte.Sha256, parte.Bytes, ct);
            await EjecutarAsync(async token =>
            {
                using var respuesta = await EnviarParteComprimidaAsync(HttpMethod.Post, parte.Ruta, proyecto,
                    bytes, permitirExistente: true, usuario, token);
                if (respuesta.StatusCode == HttpStatusCode.Conflict)
                {
                    // Nunca se sobreescribe un objeto, tampoco durante un reintento.
                    using var existente = await EnviarParteComprimidaAsync(HttpMethod.Get, parte.Ruta, proyecto,
                        null, permitirExistente: false, usuario, token);
                    byte[] remoto = await LeerRespuestaParteComprimidaAsync(existente, parte.Sha256, parte.Bytes, token);
                    if (!remoto.AsSpan().SequenceEqual(bytes))
                        throw ErrorPaqueteComprimido("Una parte existente no coincide con el paquete que se intentó publicar.");
                }
                await ComprobarIdentidadArchivosAsync(usuario, token);
                return true;
            }, ct);
        }
        await ComprobarCuentaComprimidaAsync(usuario, ct);
    }

    private async Task<JsonElement> DescargarContenidoComprimidoAsync(JsonElement manifiesto, Guid proyecto,
        string usuario, CancellationToken ct)
    {
        JsonElement contenido = await PaqueteComprimidoNube.LeerAsync(manifiesto, proyecto,
            (ruta, token) => DescargarParteComprimidaAsync(ruta, proyecto, usuario, token), ct);
        FormatoPaqueteNube.ValidarSinExpandir(contenido);
        await ComprobarCuentaComprimidaAsync(usuario, ct);
        return contenido;
    }

    private Task<Stream> DescargarParteComprimidaAsync(string ruta, Guid proyecto, string usuario,
        CancellationToken ct) => EjecutarAsync<Stream>(async token =>
        {
            if (!RutaParteComprimidaValida(ruta, proyecto))
                throw ErrorPaqueteComprimido("La referencia privada de una parte no es válida.");
            using var respuesta = await EnviarParteComprimidaAsync(HttpMethod.Get, ruta, proyecto, null,
                permitirExistente: false, usuario, token);
            byte[] bytes = await LeerRespuestaParteComprimidaAsync(respuesta, ruta.Split('/')[2], null, token);
            await ComprobarIdentidadArchivosAsync(usuario, token);
            return new MemoryStream(bytes, writable: false);
        }, ct);

    private async Task<HttpResponseMessage> EnviarParteComprimidaAsync(HttpMethod metodo, string ruta,
        Guid proyecto, byte[]? bytes, bool permitirExistente, string usuario, CancellationToken ct)
    {
        if (!RutaParteComprimidaValida(ruta, proyecto))
            throw ErrorPaqueteComprimido("La referencia privada de una parte no es válida.");
        await ComprobarIdentidadArchivosAsync(usuario, ct);
        Sesion sesion = await AsegurarSesionAsync(forzarRefresco: false, ct, nube: true);
        HttpResponseMessage respuesta = await EnviarAsync(metodo, RutaBucketComprimido + ruta, bytes,
            sesion.Acceso, ct, tipoContenido: "application/octet-stream");
        try
        {
            if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
            {
                respuesta.Dispose();
                sesion = await AsegurarSesionAsync(forzarRefresco: true, ct, nube: true);
                await ComprobarIdentidadArchivosAsync(usuario, ct);
                respuesta = await EnviarAsync(metodo, RutaBucketComprimido + ruta, bytes,
                    sesion.Acceso, ct, tipoContenido: "application/octet-stream");
            }
            await ComprobarIdentidadArchivosAsync(usuario, ct);
            // Storage puede expresar Duplicate como HTTP 400, aunque el código
            // del error sea 409. Solo esa respuesta permite verificar el objeto;
            // nunca se sobreescribe ni se acepta sin comprobar todos sus bytes.
            if (permitirExistente && respuesta.StatusCode == HttpStatusCode.BadRequest)
            {
                if (await EsParteDuplicadaAsync(respuesta, ct)) respuesta.StatusCode = HttpStatusCode.Conflict;
                else throw ErrorPaqueteComprimido("El almacenamiento rechazó la subida del paquete. Se conserva el pendiente."
                    + DiagnosticoHttpNube(respuesta));
            }
            if (respuesta.IsSuccessStatusCode || (permitirExistente && respuesta.StatusCode == HttpStatusCode.Conflict))
                return respuesta;
            if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
            {
                LimpiarSesion();
                throw new NubeException("La sesión ya no es válida. Inicie sesión de nuevo para recuperar el paquete.",
                    necesitaIniciarSesion: true);
            }
            await LanzarErrorAsync(respuesta, autenticacion: false, ct, nube: true);
            throw ErrorPaqueteComprimido("No se pudo confirmar la transferencia del paquete privado.");
        }
        catch (NubeException error)
        {
            respuesta.Dispose();
            throw ContextualizarErrorAlmacenamientoNube(error, metodo, comprimido: true);
        }
        catch
        {
            respuesta.Dispose();
            throw;
        }
    }

    private async Task<bool> EsParteDuplicadaAsync(HttpResponseMessage respuesta, CancellationToken ct)
    {
        try
        {
            using var json = await LeerJsonAsync(respuesta, ct, nube: true);
            var raiz = json.RootElement;
            return raiz.ValueKind == JsonValueKind.Object
                && raiz.TryGetProperty("error", out var error) && error.ValueKind == JsonValueKind.String
                && error.GetString() is "Duplicate" or "ResourceAlreadyExists";
        }
        catch (NubeException) { return false; }
    }

    private static async Task<byte[]> LeerRespuestaParteComprimidaAsync(HttpResponseMessage respuesta,
        string hash, long? bytesEsperados, CancellationToken ct)
    {
        long? declarada = respuesta.Content.Headers.ContentLength;
        if (declarada is < 1 or > MaxParteComprimidaBytes
            || (declarada.HasValue && bytesEsperados.HasValue && declarada != bytesEsperados))
            throw ErrorPaqueteComprimido("El tamaño de una parte remota no coincide con el manifiesto.");
        using Stream flujo = await respuesta.Content.ReadAsStreamAsync(ct);
        byte[] bytes = await LeerBytesParteComprimidaAsync(flujo, hash, bytesEsperados, ct);
        if (declarada.HasValue && declarada != bytes.Length)
            throw ErrorPaqueteComprimido("Una parte remota está incompleta.");
        return bytes;
    }

    private static async Task<byte[]> LeerBytesParteComprimidaAsync(Stream flujo, string hash,
        long? bytesEsperados, CancellationToken ct)
    {
        if (!HashArchivoNubeValido(hash) || bytesEsperados is < 1 or > MaxParteComprimidaBytes)
            throw ErrorPaqueteComprimido("Los metadatos de una parte no son válidos.");
        using var memoria = new MemoryStream();
        byte[] buffer = new byte[81920];
        while (true)
        {
            int leidos = await flujo.ReadAsync(buffer.AsMemory(), ct);
            if (leidos == 0) break;
            if (memoria.Length + leidos > MaxParteComprimidaBytes
                || (bytesEsperados.HasValue && memoria.Length + leidos > bytesEsperados.Value))
                throw ErrorPaqueteComprimido("Una parte del paquete supera el tamaño esperado.");
            memoria.Write(buffer, 0, leidos);
        }
        byte[] bytes = memoria.ToArray();
        if (bytes.Length == 0 || (bytesEsperados.HasValue && bytes.Length != bytesEsperados.Value)
            || Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant() != hash)
            throw ErrorPaqueteComprimido("La integridad SHA-256 o el tamaño de una parte no coincide.");
        return bytes;
    }

    private static bool RutaParteComprimidaValida(string ruta, Guid proyecto)
    {
        string[] partes = ruta.Split('/');
        return partes.Length == 3 && Guid.TryParseExact(partes[0], "D", out Guid actor) && actor != Guid.Empty
            && partes[0] == actor.ToString("D") && partes[1] == proyecto.ToString("N")
            && HashArchivoNubeValido(partes[2]);
    }

    private static NubeException ErrorPaqueteComprimido(string mensaje) => new(mensaje);
}
