#nullable enable
using System;
using System.Globalization;
using System.Linq;
using System.Net.Http;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    private NubeException ContextualizarErrorAlmacenamientoNube(NubeException error,
        HttpMethod metodo, bool comprimido)
    {
        // Constantes locales: no incluir la ruta privada, UUID, SHA, nombres de
        // archivos, URL, parámetros ni el cuerpo recibido de Storage.
        string? accion = metodo == HttpMethod.Post ? "subida"
            : metodo == HttpMethod.Get ? "descarga" : null;
        if (accion is null) return error;
        string objeto = comprimido ? "paquete comprimido" : "adjunto";
        string bucket = comprimido ? "myg-nube-paquetes" : "myg-nube-archivos";
        string contexto = $"\nFase de la operación: {accion} del {objeto}."
            + $" Destino previsto: Storage · método {metodo.Method} · bucket {bucket}."
            + " Hora del error UTC " + _reloj.GetUtcNow().ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) + "."
            + " Se conserva la operación pendiente y su identificador.";
        return new NubeException(error.Message + contexto,
            esErrorDeConexion: error.EsErrorDeConexion, necesitaIniciarSesion: error.NecesitaIniciarSesion,
            accesoDenegado: error.AccesoDenegado, codigo: error.Codigo,
            vinculoNoVerificado: error.VinculoNoVerificado);
    }

    private static NubeException ContextualizarErrorRpcNube(NubeException error, string funcion)
    {
        // La fase y el nombre proceden exclusivamente de esta lista local.
        // Nunca incorporar la URL, los parámetros ni texto devuelto por el servidor.
        string? fase = funcion switch
        {
            "myg_nube_capacidades" => "comprobación de funciones del servidor",
            "myg_nube_estado_publicacion" => "consulta del estado de la publicación",
            "myg_nube_crear_confirmacion" => "publicación y confirmación",
            "myg_nube_crear_comprimido" => "publicación comprimida y confirmación",
            "myg_nube_paquete_tipo" => "consulta del almacenamiento del proyecto",
            "myg_nube_abrir_comprimido" => "apertura del paquete comprimido",
            "myg_nube_guardar_comprimido" => "guardado del paquete comprimido",
            "myg_nube_listar" => "actualización del listado de proyectos",
            "myg_nube_crear" => "creación del proyecto",
            "myg_nube_abrir" => "apertura del proyecto",
            "myg_nube_guardar" or "myg_nube_guardar_cambios" => "guardado del proyecto",
            "myg_nube_revision" => "consulta de revisión",
            "myg_nube_miembros" => "consulta de miembros",
            "myg_nube_solicitudes" => "consulta de solicitudes",
            "myg_nube_solicitar" or "myg_nube_resolver" or "myg_nube_rol"
                or "myg_nube_compartir_usuario" or "myg_nube_permisos" => "gestión de colaboración",
            _ => null
        };
        if (fase is null) return error;
        // La autenticación o la espera del turno pueden fallar antes del envío.
        // Identifica la operación prevista, sin afirmar qué solicitud llegó a salir.
        string contexto = $"\nFase de la operación: {fase} · RPC prevista {funcion}.";
        if (funcion is "myg_nube_capacidades" or "myg_nube_estado_publicacion")
            contexto += " Esta consulta no transmite el paquete de publicación. Se conserva el intento pendiente.";
        else if (funcion is "myg_nube_crear_confirmacion" or "myg_nube_crear_comprimido" && error.EsErrorDeConexion)
            contexto += " No se recibió confirmación de publicación. El paquete puede no haberse enviado, "
                + "continuar procesándose o haberse aplicado; el resultado de la publicación es incierto. "
                + "Conserve el pendiente y su identificador; revise Mis proyectos antes de reintentar.";
        return new NubeException(error.Message + contexto,
            esErrorDeConexion: error.EsErrorDeConexion, necesitaIniciarSesion: error.NecesitaIniciarSesion,
            accesoDenegado: error.AccesoDenegado, codigo: error.Codigo,
            vinculoNoVerificado: error.VinculoNoVerificado);
    }

    // Las respuestas de error pueden contener credenciales o mensajes internos.
    // Solo se publican constantes conocidas y una referencia con formato UUID.
    private static bool CodigoDiagnosticoNubePermitido(string? codigo) => codigo is
        "40001" or "42501" or "22023" or "23505" or "54000" or "MGC01" or
        "57014" or "53200" or "53300" or "53400" or "55006" or "57P01" or "57P02" or "57P03" or
        "PGRST000" or "PGRST001" or "PGRST002" or "PGRST003" or "PGRST202" or "42883" or "42P01" or
        "MYG_IDENTIDAD_REQUIERE_REVISION" or "MYG_LICENCIA_CONFLICTO" or
        "MYG_VINCULO_NO_VERIFICADO" or "MYG_INGRESO_REUTILIZADO" or
        "MYG_INGRESO_INVALIDO" or "MYG_NUBE_NO_DISPONIBLE" or
        "BOOT_ERROR" or "WORKER_ERROR" or "EDGE_FUNCTION_ERROR" or "IDLE_TIMEOUT" or
        "WORKER_RESOURCE_LIMIT" or "WORKER_LIMIT";

    private static string? CabeceraUnicaDiagnosticoNube(HttpResponseMessage respuesta, string nombre)
    {
        if (!respuesta.Headers.TryGetValues(nombre, out var valores)) return null;
        var unicos = valores.Take(2).ToArray();
        return unicos.Length == 1 ? unicos[0] : null;
    }

    private static string? CodigoFuncionNube(HttpResponseMessage respuesta)
    {
        string? codigo = CabeceraUnicaDiagnosticoNube(respuesta, "sb-error-code");
        return CodigoFuncionNubePermitido(codigo) ? codigo : null;
    }

    private static bool CodigoFuncionNubePermitido(string? codigo) => codigo is
        "BOOT_ERROR" or "WORKER_ERROR" or "EDGE_FUNCTION_ERROR" or "IDLE_TIMEOUT" or
        "WORKER_RESOURCE_LIMIT" or "WORKER_LIMIT";

    private static string DiagnosticoHttpNube(HttpResponseMessage respuesta, string? codigo = null)
    {
        string detalle = $"\nDiagnóstico: HTTP {(int)respuesta.StatusCode}";
        if (CodigoDiagnosticoNubePermitido(codigo)) detalle += " · " + codigo;
        string? funcion = CodigoFuncionNube(respuesta);
        if (funcion is not null && funcion != codigo) detalle += " · " + funcion;
        string? referencia = CabeceraUnicaDiagnosticoNube(respuesta, "sb-request-id")
            ?? CabeceraUnicaDiagnosticoNube(respuesta, "x-request-id");
        if (referencia is not null && Guid.TryParseExact(referencia, "D", out Guid id) && id != Guid.Empty)
            detalle += " · Referencia " + id.ToString("D");
        return detalle + ".";
    }

    private static string EsperaLimiteNube(HttpResponseMessage respuesta)
    {
        // Retry-After nunca se incorpora como texto recibido. Evitar intervalos
        // negativos, infinitos o excesivos sugeridos por una pasarela defectuosa.
        string? cabecera = CabeceraUnicaDiagnosticoNube(respuesta, "Retry-After");
        double? segundos = null;
        if (cabecera is { Length: > 0 and <= 64 })
        {
            if (long.TryParse(cabecera, NumberStyles.None, CultureInfo.InvariantCulture, out long intervalo)) segundos = intervalo;
            else if (DateTimeOffset.TryParseExact(cabecera, "r", CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeUniversal, out DateTimeOffset hasta)) segundos = (hasta - DateTimeOffset.UtcNow).TotalSeconds;
        }
        return segundos is double valor && double.IsFinite(valor) && valor > 0
            ? $" Espere {Math.Clamp(Math.Ceiling(valor), 1, 300):0} segundos antes de volver a conectar."
            : " Espere un momento antes de volver a conectar.";
    }
}
