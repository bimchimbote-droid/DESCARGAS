# HTTP 502 nuevo: diagnóstico de transferencia Storage

## A. Resultado

El nuevo mensaje HTTP 502 es distinto del rechazo local de cadena JSON corregido antes. La captura muestra entradas anteriores; no permite confirmar si el nuevo intento de publicación terminó ni qué solicitud falló. La aplicación conserva la lista anterior hasta que obtiene un listado nuevo correctamente.

Se identificó y corrigió una carencia verificable: las transferencias de Storage mostraban el HTTP sin decir si estaban subiendo o descargando un paquete. Ahora el mensaje añade dirección, método POST/GET, bucket y hora del error en UTC. Los errores RPC existentes conservan su propia fase. El helper conserva las marcas de error, la sesión, el pendiente y su identificador. La causa remota del 502 **continúa pendiente**; esta entrega mejora su identificación y no atribuye el fallo al plan gratuito ni a memoria.

Esta es una actualización incremental sobre la publicación comprimida y la corrección anterior de apertura grande. Conserva esa corrección sin cambios; si todavía no la aplicaste y recompilaste, aplica primero su ZIP de nueve archivos. No se incluyen proyectos privados, bases de datos ni ejecutables.

## B. Archivos y acciones

Rutas relativas a la carpeta que contiene `MYG.Presupuestos.sln`. Se entregan los archivos completos:

| Ruta exacta | Acción | Descripción |
|---|---|---|
| `MYG.Colaboracion/ClienteNubeDiagnostico.cs` | REEMPLAZAR | Añade contexto seguro de Storage y hora UTC, manteniendo el diagnóstico RPC. |
| `MYG.Colaboracion/ClienteNubeComprimida.cs` | REEMPLAZAR | Identifica el rechazo de subida/descarga del paquete Gzip. |
| `MYG.Colaboracion/ClienteNubeArchivos.cs` | REEMPLAZAR | Identifica el rechazo de subida/descarga de adjuntos anteriores. |
| `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Añade el selector focal sin ejecutar cargas grandes. |
| `MYG.PruebasNube/PublicacionComprimidaCheck.cs` | REEMPLAZAR | Casos502/520 de Storage Gzip y recuperación de la cola. |
| `MYG.PruebasNube/ArchivosNubeCheck.cs` | REEMPLAZAR | Casos502/520 de adjuntos, privacidad y reintentos. |
| `supabase/CONTINUIDAD_PUBLICACION_COMPRIMIDA.md` | REEMPLAZAR | Estado vigente, evidencias, decisiones y siguiente paso. |
| `supabase/diagnosticos/RESULTADOS_DIAGNOSTICO_STORAGE_502_20261023.json` | CREAR | Resultados de prueba; documento de consulta, no SQL. |
| `supabase/LEEME_DIAGNOSTICO_STORAGE_502_20261023.md` | CREAR | Esta guía de instalación y obtención del error nuevo. |

No hay archivos que eliminar. Los demás archivos previos se conservan.

## C. Descarga

El ZIP `MYG_PRESUPUESTOS_ACTUALIZACION.zip` se publica en una carpeta nueva de `bimchimbote-droid/DESCARGAS`, preservando las entregas anteriores. El enlace exacto y su verificación se comunican al completar publicación y descarga; registro local en `/workspace/.cloud-setup/myg/diagnostico-502-storage/entrega/publication.json`.

Entrega anterior de apertura grande, ya publicada y verificada: `MYG.Presupuestos/entrega-20261023-214551-APERTURA-JSON-GRANDE/MYG_PRESUPUESTOS_ACTUALIZACION.zip`, commit `1d5ab9dd4dbe5aa698f7a49669ffca2217f78d40` de DESCARGAS. No es necesario volver a aplicarla si ya la integraste y ejecutas ese resultado.

## D. Instalación y siguiente comprobación

1. Conserva tus copias habituales y cierra MYG/Revit si tienen cargada la aplicación.
2. Extrae el ZIP y copia sus carpetas dentro de la raíz de tu solución, aceptando reemplazar los archivos indicados. No copies estas fuentes sobre AppData, los SQLite de trabajo ni las bases de Delphin.
3. En Visual Studio abre `MYG.Presupuestos.sln`, selecciona **Release** y **Compilar → Recompilar solución**. Ejecuta el resultado nuevo `MYG.Desktop\bin\Release\net10.0-windows\MYG.Presupuestos.exe`. Si instalas el complemento Revit, usa tu procedimiento habitual e incluye las DLL Core/Colaboracion/Desktop correspondientes; evita mezclar DLL de entregas distintas. Copiar fuentes no actualiza el ejecutable anterior.
4. Identifica el botón que originó el502. Si falló una publicación, usa **Publicaciones pendientes → Reintentar** sobre **ese mismo intento**; conserva su UUID. Si estabas abriendo una obra, usa **Mis proyectos → Abrir proyecto** sobre la obra ya existente. No crees otro proyecto para sustituir una publicación de resultado incierto.
5. Si se repite el error, comparte el texto actualizado completo: HTTP, fase, método/bucket si aparecen, hora UTC y referencia si existe. Estos datos permiten distinguir Storage de RPC. La hora es la del error observado por el cliente, no la duración de la transacción ni un diagnóstico de memoria.
6. Busca **el nuevo intento** en Supabase → Logs → API Gateway. Copia ruta y hora con zona y referencia si existe. Para Storage basta `/storage/v1/object/myg-nube-paquetes/...` o `/storage/v1/object/myg-nube-archivos/...`: omite los segmentos privados de objeto/cuenta/obra, tokens y cuerpos. Si corresponde a Storage, revisa el error del servicio Storage en ese intervalo. Si corresponde a RPC, conserva el nombre exacto para continuar su análisis. No hacen falta otra vez los registros históricos ni la configuración Nano ya aportados.

Si sigue apareciendo un HTTP sin fase con estas mismas operaciones, verifica primero la ruta del ejecutable y las DLL que acabas de compilar. La captura por sí sola no demuestra una versión concreta.

## E. Configuración

Se mantiene .NET10 y las dependencias existentes. No hay paquetes nuevos, claves nuevas ni cambios de plan. **Esta entrega no incluye SQL y no se pega en SQL Editor.** Los parches 27/28 y los proyectos remotos no se cambian desde este entorno.

## F. Validación

- Se preservó la DLL anterior y se ejecutó contra las pruebas nuevas en un directorio aislado: falló exactamente por no informar fase/bucket. El cliente corregido aprobó el mismo selector.
- **12 casos y 548 comprobaciones nuevas**: Gzip: 6 casos/400 y adjuntos: 6 casos/148. HTTP 502/520 en POST, GET y GET de verificación de duplicados; clasificación, referencia, hora UTC, privacidad, sesión, cola durable, UUID y cuerpo, ausencia de ACK falso, ausencia de reenvíos automáticos, objetos inmutables y reintento íntegro.
- Regresiones afectadas: **92 comprobaciones de adjuntos y 77 de diagnóstico general**. Se ejecutó solo la selección ligera; no se repitieron los benchmarks, el ensayo de 200 MiB ni las matrices SQL anteriores.
- Solución completa Release: **cero errores y cero advertencias**.
- SHA comprobado: los cuatro archivos que corrigieron la apertura grande permanecen idénticos a la entrega anterior. Se conservan sus resultados válidos de apertura/reapertura y Core.
- Revisión independiente del helper, disposición HTTP, clasificación y privacidad: sin defectos demostrables.

Comando opcional desde la raíz, con .NET10 instalado:

```powershell
dotnet run --project .\MYG.PruebasNube\MYG.PruebasNube.csproj -c Release -- --diagnostico-storage
```

Las pruebas usan HTTP simulado, Gzip real y pendientes temporales en disco. No conectan con Supabase ni usan tu obra privada. No necesitas repetirlas para instalar.

## G. Código en GitHub

Solo se publica el ZIP en DESCARGAS. No se hace Push al repositorio del código. Después de aplicar y comprobar, revisa **Cambios de Git** en Visual Studio, confirma tu rama y los demás cambios pendientes, y realiza tú Commit y Push. No descartes modificaciones anteriores para aplicar esta actualización.

## H. Pendiente y límites

El502 real no está resuelto ni reproducido en la infraestructura gestionada. Falta el botón y el registro del nuevo intento para identificar la solicitud afectada; la fase Storage es una vía demostrada del cliente, no una atribución confirmada de esta captura. Windows/Revit, Storage real y la obra privada requieren comprobación en tu equipo.

No hay evidencia nueva de agotamiento de memoria, límite del plan Free o causalidad con WAL/reinicios históricos. Conserva el pendiente, su identificador y tus copias; un502 puede dejar un resultado incierto y no justifica borrar o duplicar obras.
