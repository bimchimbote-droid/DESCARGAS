using System;
using System.Globalization;
using System.IO;
using System.Linq;
using MYG_2027;

internal static class FormatoPartidaNuevaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("FORMATO DE PARTIDAS NUEVAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var primera = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        var hoja = primera.Costos.Hoja;
        VerificarFormato(hoja);
        Exige(!MYGMotorPresupuestos.TieneDatosPropios(primera.Costos),
            "La presentación estándar de una partida nueva no debe crear datos propios.");

        MYGEdicionHoja.Celda(hoja, "B3").Contenido = "1";
        MYGEdicionHoja.Celda(hoja, "C3").Contenido = "3";
        var calculo = new MYGHojaCalculo(hoja);
        string Tres() => 3m.ToString("0.00", CultureInfo.CurrentCulture);
        Exige(calculo.Mostrar("B3") == 1m.ToString("0.00", CultureInfo.CurrentCulture) &&
            calculo.Mostrar("C3") == Tres() && calculo.Mostrar("G3") == Tres() &&
            calculo.Mostrar("G4") == "-" && calculo.Mostrar("G16") == Tres(),
            "La partida nueva debe mostrar dos decimales en las entradas y resultados, con guion para parciales vacíos.");

        // A second insertion validates the same creation path without sharing
        // the first sheet's values or later user formatting.
        hoja.Celdas["A2"].ColorFondo = "ABCDEF";
        var segunda = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        VerificarFormato(segunda.Costos.Hoja);
        Exige(new MYGHojaCalculo(segunda.Costos.Hoja).Numero("G16") == 0,
            "Una segunda partida debe recibir una hoja estándar independiente.");
        primera = presupuesto.Items.Single(i => i.Id == primera.Id);
        hoja = primera.Costos.Hoja;
        Exige(hoja.Celdas["A2"].ColorFondo == "ABCDEF",
            "Crear otra partida debe conservar el formato personalizado de la partida existente.");
        hoja.Celdas["A2"].ColorFondo = "EFF9FC";

        string ruta = Path.Combine(carpeta, "Partidas nuevas con formato.myg");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        var guardada = MYGProyectoStorage.Leer(ruta).Presupuestos.Single().Items.Single(i => i.Id == primera.Id).Costos.Hoja;
        VerificarFormato(guardada);
        Exige(new MYGHojaCalculo(guardada).Mostrar("G16") == Tres() && guardada.FormatoNumeroPredeterminado == "0.00",
            "Guardar y reabrir una partida debe conservar el formato visual del total.");

        string excel = Path.Combine(carpeta, "Partida nueva con formato.xlsx");
        MYGExcelPresupuestos.Guardar(excel, new[] { guardada });
        var importada = MYGExcelPresupuestos.Importar(excel, guardada.Nombre, guardada.CeldaTotal);
        VerificarFormato(importada);
        Exige(new MYGHojaCalculo(importada).Mostrar("G3") == Tres() &&
            new MYGHojaCalculo(importada).Mostrar("G4") == "-",
            "El intercambio XLSX debe conservar los dos decimales y los guiones para ceros.");
        pasa("Partidas nuevas conservan ambos encabezados celestes, Datos centrado, dos decimales y Total a la derecha en proyecto y XLSX");
        VerificarDecimalesPredeterminados(guardada, pasa);
    }

    private static void VerificarFormato(MYGHojaMetrado hoja)
    {
        Exige(new[] { "A1:C1", "D1:F1", "G1:H1" }.All(hoja.RangosCombinados.Contains) &&
            MYGEdicionHoja.Direcciones(hoja, "A1:H2").All(d => hoja.Celdas[d].ColorFondo == "EFF9FC") &&
            MYGEdicionHoja.AlineacionCelda(hoja.Celdas["A1"], "A1") == "Centro" &&
            MYGEdicionHoja.AlineacionCelda(hoja.Celdas["A2"], "A2") == "Izquierda",
            "Ambos encabezados deben llevar relleno celeste, con Datos centrado y Descripción a la izquierda.");
        Exige(hoja.Celdas.Values.All(c => c.Fuente == "Arial Narrow" && c.TamanoFuente == 9) &&
            Enumerable.Range(3, 14).All(f => hoja.Celdas["G" + f].FormatoNumero == "0.00;-0.00;-") &&
            hoja.Celdas["A16"].Negrita && hoja.Celdas["G16"].Negrita &&
            MYGEdicionHoja.AlineacionCelda(hoja.Celdas["A16"], "A16") == "Derecha",
            "La plantilla nueva debe conservar fuente, dos decimales y etiqueta Total en negrita a la derecha.");
    }

    private static void VerificarDecimalesPredeterminados(MYGHojaMetrado hoja, Action<string> pasa)
    {
        // Una celda que todavía no existe debe recibir el mismo formato que
        // los factores iniciales; el formato no debe redondear su valor real.
        MYGEdicionHoja.Celda(hoja, "J20").Contenido = "1.23456";
        hoja.Poner("K20", "2.34567");
        var calculo = new MYGHojaCalculo(hoja);
        Exige(calculo.Mostrar("J20") == 1.23m.ToString("0.00", CultureInfo.CurrentCulture) &&
            calculo.Mostrar("K20") == 2.35m.ToString("0.00", CultureInfo.CurrentCulture) &&
            calculo.Numero("J20") == 1.23456m && calculo.Numero("K20") == 2.34567m,
            "Las celdas adicionales de una partida nueva deben usar dos decimales sin perder precisión.");
        MYGEdicionHoja.InsertarFilas(hoja, 20);
        MYGEdicionHoja.Celda(hoja, "J20").Contenido = "4";
        Exige(hoja.FormatoNumeroPredeterminado == "0.00" &&
            new MYGHojaCalculo(hoja).Mostrar("J20") == 4m.ToString("0.00", CultureInfo.CurrentCulture),
            "Insertar filas debe conservar el formato predeterminado de dos decimales.");

        var anterior = System.Text.Json.JsonSerializer.Deserialize<MYGHojaMetrado>("{\"Celdas\":{}}");
        MYGEdicionHoja.Celda(anterior, "B3").Contenido = "1.23456";
        Exige(anterior.FormatoNumeroPredeterminado == "0.0000" &&
            new MYGHojaCalculo(anterior).Mostrar("B3") == 1.2346m.ToString("0.0000", CultureInfo.CurrentCulture),
            "Las hojas anteriores sin nuevo formato predeterminado deben conservar sus cuatro decimales.");
        var personalizada = MYGHojaMetrado.Crear();
        MYGEdicionHoja.Celda(personalizada, "B3").FormatoNumero = "0.000000";
        personalizada.Celdas["A1"].AlineacionHorizontal = "Izquierda";
        personalizada.Celdas["A1"].AlineacionPersonalizada = true;
        var copia = MYGProyectoStorage.Copia(personalizada);
        Exige(copia.Celdas["B3"].FormatoNumero == "0.000000" &&
            MYGEdicionHoja.AlineacionCelda(copia.Celdas["A1"], "A1") == "Izquierda",
            "Los formatos personalizados deben conservarse al copiar o reabrir los datos.");
        pasa("Dos decimales se aplican a celdas nuevas y filas insertadas sin redondear datos ni alterar formatos guardados o heredados");
    }
}
