#nullable enable
using System;
using System.IO;

namespace MYG_2027;

/// <summary>Sugiere el nombre visible sin sustituir una edición del usuario.</summary>
internal sealed class SugerenciaNombrePublicacionNube
{
    private string automatico = "";

    internal string Actualizar(string actual, bool baseCompleta, string? rutaSQLite, string? nombreObra)
    {
        if (!string.IsNullOrWhiteSpace(actual) && !string.Equals(actual, automatico, StringComparison.Ordinal))
            return actual;
        automatico = baseCompleta
            ? Path.GetFileNameWithoutExtension(rutaSQLite ?? "")
            : nombreObra ?? "";
        return automatico;
    }
}
