#nullable enable
using System.Net;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace MYG.Colaboracion;

public sealed record ArchivoSqliteNube(string Ruta, string Sha256, long Bytes);
public sealed record ProyectoSqliteNube(ProyectoNube Proyecto, string DocumentoId, ArchivoSqliteNube Archivo);
public sealed record RespuestaSqliteNube(string Estado, long Revision, Guid OperacionId, ArchivoSqliteNube Archivo);

public sealed partial class ClienteSupabase
{
    public const long MaxSqliteNubeBytes = 300L * 1024 * 1024;
    private const string BucketSqliteNube = "storage/v1/object/myg-nube-sqlite/";
    private int capacidadSqlite;

    /// <summary>El protocolo transporta el archivo SQLite, sin convertir las tablas a JSON ni comprimirlo.</summary>
    public async Task<bool> AdmiteSqliteAsync(CancellationToken ct = default)
    {
        if (capacidadSqlite != 0) return capacidadSqlite > 0;
        try
        {
            bool admite = await EjecutarRpcNubeAsync("myg_nube_sqlite_capacidades", new { }, raiz =>
            {
                ExigirObjetoSqlite(raiz);
                if (!raiz.TryGetProperty("version", out var version) || version.ValueKind != JsonValueKind.Number || !version.TryGetInt32(out int v) || v != 1
                    || !raiz.TryGetProperty("max_bytes", out var bytes) || bytes.ValueKind != JsonValueKind.Number || !bytes.TryGetInt64(out long max)
                    || max != MaxSqliteNubeBytes) throw RespuestaNubeInvalida();
                return true;
            }, ct);
            capacidadSqlite = 1;
            return admite;
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883")
        {
            // No inventar compatibilidad ni cambiar silenciosamente el formato solicitado.
            capacidadSqlite = 0;
            return false;
        }
    }

    private async Task ExigirSqliteAsync(CancellationToken ct)
    {
        if (!await AdmiteSqliteAsync(ct))
        {
            capacidadSqlite = 0; // Permitir reintentar después de instalar la migración.
            throw new NubeException("Instale la migración 20261030_archivos_sqlite.sql en Supabase para guardar archivos SQLite sin compresión. Se conserva la copia local.");
        }
    }

    /// <summary>Solo metadatos; null identifica un UUID nuevo o un proyecto con formato anterior.</summary>
    public async Task<ProyectoSqliteNube?> ConsultarSqliteAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        if (!await AdmiteSqliteAsync(ct)) return null;
        string usuario = await IdentidadArchivosAsync(ct);
        try
        {
            return await EjecutarRpcNubeAsync("myg_nube_sqlite_consultar", new { p_id = id }, raiz =>
                raiz.ValueKind == JsonValueKind.Null ? null : LeerProyectoSqlite(raiz, id), ct, identidadEsperada: usuario);
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883")
        { capacidadSqlite = 0; return null; }
    }

    public async Task<ProyectoSqliteNube> AbrirSqliteAsync(Guid id, long? revision = null, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        if (revision is < 1) throw new NubeException("La revisión SQLite solicitada no es válida.");
        await ExigirSqliteAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        return await EjecutarRpcNubeAsync("myg_nube_sqlite_abrir", new { p_id = id, p_revision = revision }, raiz =>
        {
            var recibido = LeerProyectoSqlite(raiz, id);
            if (revision.HasValue && recibido.Proyecto.Revision != revision.Value) throw RespuestaNubeInvalida();
            return recibido;
        }, ct, identidadEsperada: usuario);
    }

    /// <summary>ruta debe ser una instantánea local congelada; conservarla hasta confirmar la operación.</summary>
    public async Task<ProyectoSqliteNube> CrearSqliteAsync(Guid id, string nombre, string ruta, string alcance,
        string documentoId, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        ValidarIdNube(id); nombre = ValidarNombreNube(nombre); ValidarAlcanceNube(alcance);
        if (!TextoEntradaValido(documentoId, 200)) throw new NubeException("El archivo necesita la identidad del documento SQLite.");
        using var archivo = AbrirSqliteCongelado(ruta);
        progreso?.Report("Verificando el archivo SQLite sin comprimir…");
        string sha = await HashSqliteAsync(archivo, ct);
        await ExigirSqliteAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        var datos = new ArchivoSqliteNube(RutaSqlite(usuario, id, sha), sha, archivo.Length);
        var existente = await ConsultarSqliteAsync(id, ct);
        if (existente is not null)
        {
            // Confirmar la publicación inicial; el UUID y el archivo no se sustituyen al reintentar.
            return await CrearMetadatosSqliteAsync(id, nombre, alcance, documentoId, datos, usuario, ct);
        }
        await SubirSqliteAsync(id, datos, archivo.Name, usuario, ct, progreso);
        progreso?.Report("Confirmando la publicación del archivo SQLite…");
        return await CrearMetadatosSqliteAsync(id, nombre, alcance, documentoId, datos, usuario, ct);
    }

    private Task<ProyectoSqliteNube> CrearMetadatosSqliteAsync(Guid id, string nombre, string alcance,
        string documentoId, ArchivoSqliteNube datos, string usuario, CancellationToken ct) =>
        EjecutarRpcNubeAsync("myg_nube_sqlite_crear", new
        {
            p_id = id, p_nombre = nombre, p_alcance = alcance, p_documento_id = documentoId,
            p_ruta = datos.Ruta, p_sha256 = datos.Sha256, p_bytes = datos.Bytes
        }, raiz =>
        {
            var recibido = LeerProyectoSqlite(raiz, id);
            if (recibido.Proyecto.Rol != "propietario" || recibido.Proyecto.Revision != 1
                || recibido.Proyecto.Nombre != nombre || recibido.Proyecto.Alcance != alcance
                || recibido.DocumentoId != documentoId || recibido.Archivo != datos) throw RespuestaNubeInvalida();
            return recibido;
        }, ct, identidadEsperada: usuario);

    public async Task<RespuestaSqliteNube> GuardarSqliteAsync(Guid id, Guid operacion, long revision,
        string ruta, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        ValidarIdNube(id); ValidarIdNube(operacion);
        if (revision < 1 || revision == long.MaxValue) throw new NubeException("La operación necesita una revisión válida.");
        using var archivo = AbrirSqliteCongelado(ruta);
        progreso?.Report("Verificando los cambios del archivo SQLite…");
        string sha = await HashSqliteAsync(archivo, ct);
        await ExigirSqliteAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        var datos = new ArchivoSqliteNube(RutaSqlite(usuario, id, sha), sha, archivo.Length);
        var actual = await ConsultarSqliteAsync(id, ct)
            ?? throw new NubeException("Este proyecto todavía usa el formato anterior. Publique una copia SQLite nueva; se conserva la copia de trabajo.");
        ExigirEscrituraSqlite(actual.Proyecto);
        // Si la revisión ya avanzó, consultar el ACK con una RPC pequeña. El
        // servidor comprueba UUID, revisión y hash sin volver a transferir la base.
        if (actual.Proyecto.Revision == revision && actual.Archivo != datos)
            await SubirSqliteAsync(id, datos, archivo.Name, usuario, ct, progreso);
        progreso?.Report("Guardando la referencia y la revisión del archivo SQLite…");
        return await EjecutarRpcNubeAsync("myg_nube_sqlite_guardar", new
        {
            p_id = id, p_operacion = operacion, p_revision = revision,
            p_ruta = datos.Ruta, p_sha256 = datos.Sha256, p_bytes = datos.Bytes
        }, raiz =>
        {
            ExigirObjetoSqlite(raiz);
            string estado = TextoNube(raiz, "estado", 32);
            long recibida = RevisionNube(raiz);
            Guid confirmada = GuidNube(raiz, "operacion_id");
            if (!raiz.TryGetProperty("archivo_sqlite", out var archivoJson)) throw RespuestaNubeInvalida();
            var confirmado = LeerArchivoSqlite(archivoJson, id);
            if (estado is not ("aplicada" or "conflicto") || confirmada != operacion
                || estado == "aplicada" && (recibida != revision + 1 || confirmado != datos)) throw RespuestaNubeInvalida();
            return new RespuestaSqliteNube(estado, recibida, confirmada, confirmado);
        }, ct, identidadEsperada: usuario);
    }

    private static void ExigirEscrituraSqlite(ProyectoNube proyecto)
    {
        var modulos = proyecto.PermisosModulos;
        if (!SincronizadorProyectoNube.PuedeEditar(proyecto.Rol)
            || modulos is null || !modulos.Acu || !modulos.Especificaciones || !modulos.MetradosExcel)
            throw new NubeException("La carga de una base SQLite completa requiere permiso de edición de todos los módulos. Se conserva la copia local.", accesoDenegado: true, codigo: "42501");
    }

    /// <summary>Descarga a un temporal verificado. Un fallo nunca sustituye el archivo de destino.</summary>
    public async Task DescargarSqliteAsync(ProyectoSqliteNube proyecto, string destino,
        CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        ValidarArchivoSqlite(proyecto.Archivo, proyecto.Proyecto.Id);
        destino = Path.GetFullPath(destino);
        string temporal = Path.Combine(Path.GetDirectoryName(destino)!, ".myg-descarga-" + Guid.NewGuid().ToString("N") + ".sqlite");
        await ExigirSqliteAsync(ct);
        string usuario = await IdentidadArchivosAsync(ct);
        try
        {
            await EjecutarAsync(async token =>
            {
                using var respuesta = await EnviarSqliteAsync(HttpMethod.Get, proyecto.Archivo.Ruta,
                    proyecto.Proyecto.Id, null, usuario, token);
                await LeerSqliteRespuestaAsync(respuesta, proyecto.Archivo, temporal, token, progreso);
                await ComprobarIdentidadArchivosAsync(usuario, token);
                return true;
            }, ct, plazo: TimeSpan.FromMinutes(10));
            ct.ThrowIfCancellationRequested();
            await Task.Run(() => ValidarIntegridadSqlite(temporal), ct);
            ct.ThrowIfCancellationRequested();
            if (File.Exists(destino))
                File.Replace(temporal, destino, destino + ".antes-descarga-" + Guid.NewGuid().ToString("N") + ".sqlite");
            else File.Move(temporal, destino);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    private async Task SubirSqliteAsync(Guid proyecto, ArchivoSqliteNube datos, string local,
        string usuario, CancellationToken ct, IProgress<string>? progreso)
    {
        await EjecutarAsync(async token =>
        {
            using var respuesta = await EnviarSqliteAsync(HttpMethod.Post, datos.Ruta, proyecto,
                local, usuario, token, progreso);
            if (respuesta.StatusCode == HttpStatusCode.Conflict)
            {
                string temporal = Path.Combine(Path.GetTempPath(), "myg-verificar-sqlite-" + Guid.NewGuid().ToString("N"));
                try
                {
                    using var anterior = await EnviarSqliteAsync(HttpMethod.Get, datos.Ruta, proyecto,
                        null, usuario, token);
                    await LeerSqliteRespuestaAsync(anterior, datos, temporal, token, null);
                }
                finally { if (File.Exists(temporal)) File.Delete(temporal); }
            }
            await ComprobarIdentidadArchivosAsync(usuario, token);
            return true;
        }, ct, plazo: TimeSpan.FromMinutes(10));
    }

    private async Task<HttpResponseMessage> EnviarSqliteAsync(HttpMethod metodo, string ruta, Guid proyecto,
        string? local, string usuario, CancellationToken ct, IProgress<string>? progreso = null)
    {
        if (!RutaSqliteValida(ruta, proyecto)) throw ErrorSqlite("La referencia del archivo SQLite no es válida.");
        for (int intento = 0; intento < 2; intento++)
        {
            await ComprobarIdentidadArchivosAsync(usuario, ct);
            var sesion = await AsegurarSesionAsync(forzarRefresco: intento > 0, ct, nube: true);
            await ComprobarIdentidadArchivosAsync(usuario, ct);
            using var solicitud = new HttpRequestMessage(metodo, BucketSqliteNube + ruta);
            solicitud.Headers.Add("apikey", _clave);
            solicitud.Headers.Authorization = new AuthenticationHeaderValue("Bearer", sesion.Acceso);
            solicitud.Headers.AcceptEncoding.Add(new StringWithQualityHeaderValue("identity"));
            if (local is not null)
            {
                solicitud.Headers.Add("x-upsert", "false");
                solicitud.Content = new ContenidoSqliteStream(local, progreso);
                solicitud.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.sqlite3");
            }
            var respuesta = await _http.SendAsync(solicitud, HttpCompletionOption.ResponseHeadersRead, ct);
            try
            {
                await ComprobarIdentidadArchivosAsync(usuario, ct);
                if (respuesta.StatusCode == HttpStatusCode.Unauthorized && intento == 0)
                { respuesta.Dispose(); continue; }
                if (respuesta.IsSuccessStatusCode || local is not null && respuesta.StatusCode == HttpStatusCode.Conflict)
                    return respuesta;
                if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
                {
                    LimpiarSesion();
                    throw new NubeException("La sesión ya no es válida. Inicie sesión de nuevo; se conserva la base local.", necesitaIniciarSesion: true);
                }
                if (await ClasificarErrorStorageSqliteAsync(respuesta, local is not null, ct))
                {
                    respuesta.StatusCode = HttpStatusCode.Conflict;
                    return respuesta;
                }
                throw ErrorSqlite("No se pudo confirmar la transferencia del archivo SQLite.");
            }
            catch { respuesta.Dispose(); throw; }
        }
        throw ErrorSqlite("No se pudo autenticar la transferencia SQLite.");
    }

    // Storage devuelve códigos y nombres de error distintos de PostgREST. Leer el
    // stream de error una sola vez: puede no admitir Seek y LeerJsonAsync lo cierra.
    // Conservar una copia acotada permite reutilizar la clasificación SQL existente.
    private async Task<bool> ClasificarErrorStorageSqliteAsync(HttpResponseMessage respuesta,
        bool subida, CancellationToken ct)
    {
        string? codigo = await LeerCodigoStorageSqliteAsync(respuesta, ct);
        if (subida && respuesta.StatusCode == HttpStatusCode.BadRequest
            && codigo is "ResourceAlreadyExists" or "KeyAlreadyExists") return true;

        string? mensaje = codigo switch
        {
            "AccessDenied" => "Storage rechazó el permiso para transferir el archivo SQLite. Compruebe las políticas del bucket y la vinculación MYG de la cuenta; se conserva la copia local.",
            "InvalidMimeType" => "El bucket de Storage no admite el tipo de archivo SQLite enviado (application/vnd.sqlite3). Revise los tipos MIME permitidos del bucket; se conserva la copia local.",
            "EntityTooLarge" => "Storage rechazó el tamaño del archivo SQLite. Revise el límite del bucket y el límite global de Storage del plan; el máximo de 300 MiB de MYG no modifica esos límites. Se conserva la copia local.",
            "NoSuchBucket" => "Storage no encontró el bucket de archivos SQLite. Compruebe la instalación de Nube MYG en el servidor; se conserva la copia local.",
            "InvalidKey" => "Storage rechazó la referencia del archivo SQLite. Compruebe la configuración de almacenamiento del servidor; se conserva la copia local.",
            _ => null
        };
        try
        {
            if (mensaje is not null)
                throw new NubeException(mensaje + "\nCódigo Storage: " + codigo + "." + DiagnosticoHttpNube(respuesta),
                    accesoDenegado: codigo == "AccessDenied", codigo: codigo);
            await LanzarErrorAsync(respuesta, autenticacion: false, ct, nube: true);
        }
        catch (NubeException error)
        {
            string fase = subida ? "subida del archivo SQLite" : "descarga del archivo SQLite";
            throw new NubeException(error.Message + "\nFase de la operación: " + fase + ".",
                esErrorDeConexion: error.EsErrorDeConexion, necesitaIniciarSesion: error.NecesitaIniciarSesion,
                accesoDenegado: error.AccesoDenegado, codigo: error.Codigo,
                vinculoNoVerificado: error.VinculoNoVerificado);
        }
        return false;
    }

    private static async Task<string?> LeerCodigoStorageSqliteAsync(HttpResponseMessage respuesta, CancellationToken ct)
    {
        const int maxErrorBytes = 64 * 1024;
        ct.ThrowIfCancellationRequested();
        byte[] contenido = Array.Empty<byte>();
        if (respuesta.Content.Headers.ContentLength is not > maxErrorBytes)
        {
            using var flujo = await respuesta.Content.ReadAsStreamAsync(ct);
            using var buffer = new MemoryStream();
            byte[] bloque = new byte[8192];
            while (buffer.Length <= maxErrorBytes)
            {
                int restantes = maxErrorBytes + 1 - (int)buffer.Length;
                int leidos = await flujo.ReadAsync(bloque.AsMemory(0, Math.Min(bloque.Length, restantes)), ct);
                if (leidos == 0) { contenido = buffer.ToArray(); break; }
                buffer.Write(bloque, 0, leidos);
            }
        }
        ct.ThrowIfCancellationRequested();
        string? codigo = null;
        try
        {
            using var json = JsonDocument.Parse(contenido, new JsonDocumentOptions { MaxDepth = 16 });
            var raiz = json.RootElement;
            if (raiz.ValueKind != JsonValueKind.Object
                || raiz.EnumerateObject().Select(p => p.Name).Distinct(StringComparer.Ordinal).Count() != raiz.EnumerateObject().Count())
                contenido = Array.Empty<byte>();
            else
            {
                // Códigos y alias legacy de supabase/storage, internal/errors/codes.ts.
                // Nunca usar message, nombres de archivos ni texto arbitrario remoto.
                string? valor = null;
                if (raiz.TryGetProperty("code", out var code))
                { if (code.ValueKind == JsonValueKind.String) valor = code.GetString(); }
                else if (raiz.TryGetProperty("error", out var error) && error.ValueKind == JsonValueKind.String)
                    valor = error.GetString();
                codigo = valor switch
                {
                    "ResourceAlreadyExists" or "Duplicate" => "ResourceAlreadyExists",
                    "KeyAlreadyExists" => "KeyAlreadyExists",
                    "AccessDenied" or "Unauthorized" => "AccessDenied",
                    "InvalidMimeType" or "invalid_mime_type" => "InvalidMimeType",
                    "EntityTooLarge" or "Payload too large" => "EntityTooLarge",
                    "NoSuchBucket" or "Bucket not found" => "NoSuchBucket",
                    "InvalidKey" => "InvalidKey",
                    _ => null
                };
            }
        }
        catch (JsonException) { contenido = Array.Empty<byte>(); }
        respuesta.Content.Dispose();
        respuesta.Content = new ByteArrayContent(contenido);
        return codigo;
    }

    private static async Task LeerSqliteRespuestaAsync(HttpResponseMessage respuesta, ArchivoSqliteNube esperado,
        string temporal, CancellationToken ct, IProgress<string>? progreso)
    {
        if (respuesta.Content.Headers.ContentEncoding.Count != 0)
            throw ErrorSqlite("La descarga SQLite debe recibirse sin compresión.");
        if (respuesta.Content.Headers.ContentLength is long largo && largo != esperado.Bytes)
            throw ErrorSqlite("El tamaño remoto del archivo SQLite no coincide con sus metadatos.");
        await using var entrada = await respuesta.Content.ReadAsStreamAsync(ct);
        await using var salida = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, true);
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        byte[] buffer = new byte[81920];
        long total = 0, informado = -1;
        while (true)
        {
            int leidos = await entrada.ReadAsync(buffer, ct);
            if (leidos == 0) break;
            total += leidos;
            if (total > esperado.Bytes || total > MaxSqliteNubeBytes) throw ErrorSqlite("La descarga SQLite excede el tamaño autorizado.");
            hash.AppendData(buffer, 0, leidos);
            await salida.WriteAsync(buffer.AsMemory(0, leidos), ct);
            long mib = total / (1024 * 1024);
            if (mib != informado) { progreso?.Report($"Descargando SQLite sin comprimir: {total / 1048576d:N1} de {esperado.Bytes / 1048576d:N1} MiB…"); informado = mib; }
        }
        if (total != esperado.Bytes || Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant() != esperado.Sha256)
            throw ErrorSqlite("La integridad SHA-256 o el tamaño del archivo SQLite descargado no coincide.");
        await salida.FlushAsync(ct);
        salida.Flush(flushToDisk: true);
    }

    private static FileStream AbrirSqliteCongelado(string ruta)
    {
        var archivo = new FileStream(Path.GetFullPath(ruta), FileMode.Open, FileAccess.Read, FileShare.Read, 81920, true);
        try
        {
            if (archivo.Length is < 512 or > MaxSqliteNubeBytes) throw ErrorSqlite("La base SQLite debe ocupar entre 512 bytes y 300 MiB.");
            Span<byte> cabecera = stackalloc byte[16];
            archivo.ReadExactly(cabecera);
            if (!cabecera.SequenceEqual("SQLite format 3\0"u8)) throw ErrorSqlite("El archivo no tiene una cabecera SQLite válida.");
            archivo.Position = 0;
            return archivo;
        }
        catch { archivo.Dispose(); throw; }
    }

    private static async Task<string> HashSqliteAsync(FileStream archivo, CancellationToken ct)
    {
        byte[] hash = await SHA256.HashDataAsync(archivo, ct);
        archivo.Position = 0;
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static void ValidarIntegridadSqlite(string ruta)
    {
        try
        {
            using var cabecera = AbrirSqliteCongelado(ruta);
            using var c = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
            c.Open();
            using var q = c.CreateCommand(); q.CommandText = "PRAGMA quick_check";
            using var lector = q.ExecuteReader();
            if (!lector.Read() || lector.GetString(0) != "ok" || lector.Read())
                throw ErrorSqlite("La base descargada no superó la comprobación de integridad SQLite.");
        }
        catch (SqliteException) { throw ErrorSqlite("La base descargada no superó la comprobación de integridad SQLite."); }
    }

    private static ProyectoSqliteNube LeerProyectoSqlite(JsonElement raiz, Guid id)
    {
        ExigirObjetoSqlite(raiz);
        if (raiz.TryGetProperty("contenido", out _)) throw RespuestaNubeInvalida();
        var proyecto = LeerProyectoNube(raiz, requiereContenido: false, esperado: id);
        string documento = TextoNube(raiz, "documento_id", 200);
        if (!raiz.TryGetProperty("archivo_sqlite", out var archivoJson)) throw RespuestaNubeInvalida();
        var archivo = LeerArchivoSqlite(archivoJson, id);
        return new(proyecto, documento, archivo);
    }

    private static ArchivoSqliteNube LeerArchivoSqlite(JsonElement raiz, Guid proyecto)
    {
        if (raiz.ValueKind != JsonValueKind.Object) throw RespuestaNubeInvalida();
        var nombres = raiz.EnumerateObject().Select(p => p.Name).ToArray();
        if (nombres.Length != 3 || nombres.Distinct(StringComparer.Ordinal).Count() != 3
            || nombres.Any(n => n is not ("ruta" or "sha256" or "bytes"))) throw RespuestaNubeInvalida();
        string ruta = TextoNube(raiz, "ruta", 160), sha = TextoNube(raiz, "sha256", 64);
        if (!raiz.TryGetProperty("bytes", out var cantidad) || cantidad.ValueKind != JsonValueKind.Number || !cantidad.TryGetInt64(out long bytes)) throw RespuestaNubeInvalida();
        var archivo = new ArchivoSqliteNube(ruta, sha, bytes);
        ValidarArchivoSqlite(archivo, proyecto);
        return archivo;
    }

    private static void ValidarArchivoSqlite(ArchivoSqliteNube archivo, Guid proyecto)
    {
        if (archivo.Bytes is < 512 or > MaxSqliteNubeBytes || archivo.Sha256 is null || archivo.Ruta is null || !HashArchivoNubeValido(archivo.Sha256)
            || !RutaSqliteValida(archivo.Ruta, proyecto) || !archivo.Ruta.EndsWith("/" + archivo.Sha256 + ".sqlite", StringComparison.Ordinal))
            throw ErrorSqlite("Los metadatos del archivo SQLite no son válidos.");
    }

    private static bool RutaSqliteValida(string ruta, Guid proyecto)
    {
        string[] p = ruta.Split('/');
        return proyecto != Guid.Empty && p.Length == 3 && Guid.TryParseExact(p[0], "D", out Guid usuario)
            && usuario != Guid.Empty && p[0] == usuario.ToString("D") && p[1] == proyecto.ToString("N")
            && p[2].Length == 71 && p[2].EndsWith(".sqlite", StringComparison.Ordinal) && HashArchivoNubeValido(p[2][..64]);
    }

    private static string RutaSqlite(string usuario, Guid id, string sha) => usuario + "/" + id.ToString("N") + "/" + sha + ".sqlite";
    private static NubeException ErrorSqlite(string mensaje) => new(mensaje);

    private static void ExigirObjetoSqlite(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Object) throw RespuestaNubeInvalida();
        var nombres = new HashSet<string>(StringComparer.Ordinal);
        foreach (var propiedad in raiz.EnumerateObject())
            if (!nombres.Add(propiedad.Name)) throw RespuestaNubeInvalida();
    }

    private sealed class ContenidoSqliteStream : HttpContent
    {
        private readonly string ruta;
        private readonly long bytes;
        private readonly IProgress<string>? progreso;
        internal ContenidoSqliteStream(string ruta, IProgress<string>? progreso)
        { this.ruta = ruta; bytes = new FileInfo(ruta).Length; this.progreso = progreso; }
        protected override bool TryComputeLength(out long length) { length = bytes; return true; }
        protected override Task SerializeToStreamAsync(Stream stream, TransportContext? context) =>
            SerializeToStreamAsync(stream, context, CancellationToken.None);
        protected override async Task SerializeToStreamAsync(Stream stream, TransportContext? context, CancellationToken ct)
        {
            await using var entrada = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, true);
            if (entrada.Length != bytes) throw ErrorSqlite("La instantánea local cambió durante el envío.");
            byte[] buffer = new byte[81920]; long total = 0, informado = -1;
            while (true)
            {
                int leidos = await entrada.ReadAsync(buffer, ct);
                if (leidos == 0) break;
                await stream.WriteAsync(buffer.AsMemory(0, leidos), ct);
                total += leidos;
                long mib = total / (1024 * 1024);
                if (mib != informado) { progreso?.Report($"Enviando SQLite sin comprimir: {total / 1048576d:N1} de {bytes / 1048576d:N1} MiB…"); informado = mib; }
            }
            if (total != bytes) throw ErrorSqlite("La instantánea SQLite está incompleta.");
        }
    }
}
