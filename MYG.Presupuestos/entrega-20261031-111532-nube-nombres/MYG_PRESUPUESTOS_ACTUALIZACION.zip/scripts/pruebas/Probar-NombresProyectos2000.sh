#!/usr/bin/env bash
# PostgreSQL local DESECHABLE. No usa Supabase, secretos ni datos reales.
set -euo pipefail
repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
test_container=""
test_workspace=$(mktemp -d -t myg-nombres-2000-XXXXXXXX)
cleanup() {
    result=$?
    trap - EXIT
    if [[ -n "$test_container" ]]; then docker rm -f "$test_container" >/dev/null 2>&1 || true; fi
    rm -rf -- "$test_workspace"
    exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_HOST=unix:///var/run/docker.sock
docker info --format '{{.ServerVersion}}'
postgres_test_image='postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
if ! docker image inspect "$postgres_test_image" >/dev/null 2>&1; then docker pull "$postgres_test_image"; fi
command -v dotnet >/dev/null
dotnet run --project "$repo_root/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" \
    -c Release -p:UseSharedCompilation=false -- "$test_workspace/paquetes"
test_container=$(docker run --detach --rm --network none --memory=2g --cpus=2 \
    --tmpfs /var/lib/postgresql/data:rw,size=1g \
    -e POSTGRES_HOST_AUTH_METHOD=trust "$postgres_test_image")
for attempt in {1..60}; do
    if docker exec "$test_container" pg_isready -U postgres >/dev/null 2>&1; then break; fi
    if [[ "$attempt" == 60 ]]; then docker logs "$test_container"; exit 1; fi
    sleep 1
done
docker exec -u root "$test_container" mkdir -p /pruebas
docker cp "$repo_root/supabase" "$test_container:/pruebas/supabase"
docker cp "$test_workspace/paquetes" "$test_container:/pruebas/paquetes"
docker exec -u root "$test_container" chmod -R a+rX /pruebas
docker exec -u postgres "$test_container" createdb qa_nombres_base
if docker exec -u postgres "$test_container" psql -X -d qa_nombres_base \
    -v MYG_PRUEBAS_DESECHABLES=1 -v ON_ERROR_STOP=1 \
    -f /pruebas/supabase/pruebas/archivos_sqlite.sql > "$test_workspace/fixture.log" 2>&1; then
    tail -5 "$test_workspace/fixture.log"
else
    result=$?; cat "$test_workspace/fixture.log"; exit "$result"
fi

# Firma del estado relevante: permite demostrar que un aborto no dejó parches
# parciales, cambios de permisos, CHECK nuevos ni modificaciones de datos.
docker exec -i -u postgres "$test_container" psql -X -d qa_nombres_base -v ON_ERROR_STOP=1 <<'SQL'
create function qa.firma_estado_nombres() returns text language sql stable as $$
select md5(jsonb_build_object(
    'funciones',(select jsonb_agg(to_jsonb(p) order by p.oid) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('public','myg_nube_privado')),
    'tabla',(select to_jsonb(c) from pg_class c where c.oid='public.myg_nube_proyectos'::regclass),
    'columnas',(select jsonb_agg(to_jsonb(a) order by a.attnum) from pg_attribute a where a.attrelid='public.myg_nube_proyectos'::regclass),
    'checks',(select jsonb_agg(to_jsonb(c) order by c.oid) from pg_constraint c where c.conrelid='public.myg_nube_proyectos'::regclass),
    'triggers',(select jsonb_agg(to_jsonb(t) order by t.oid) from pg_trigger t where t.tgrelid='public.myg_nube_proyectos'::regclass),
    'politicas',(select jsonb_agg(to_jsonb(p) order by p.schemaname,p.tablename,p.policyname) from pg_policies p where p.schemaname in ('public','storage')),
    'proyectos',(select jsonb_agg(to_jsonb(p) order by p.id) from public.myg_nube_proyectos p),
    'miembros',(select jsonb_agg(to_jsonb(m) order by m.proyecto_id,m.usuario_id) from public.myg_nube_miembros m),
    'historial',(select jsonb_agg(to_jsonb(h) order by h.proyecto_id,h.revision) from public.myg_nube_historial h)
)::text);
$$;
SQL

for scenario in custom_body custom_check varchar invalid_existing_name; do
    test_database="qa_nombres_$scenario"
    docker exec -u postgres "$test_container" createdb -T qa_nombres_base "$test_database"
    case "$scenario" in
        custom_body)
            expected_failure='es desconocido'
            docker exec -i -u postgres "$test_container" psql -X -d "$test_database" -v ON_ERROR_STOP=1 <<'SQL'
do $$ declare v text; begin
    v:=pg_get_functiondef('public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure);
    execute replace(v,'MYG_PROYECTO_INVALIDO','QA_PERSONALIZACION_NO_REEMPLAZAR');
end $$;
SQL
            ;;
        custom_check)
            expected_failure='CHECK qa_nombre_personalizado de nombre es desconocido'
            docker exec -u postgres "$test_container" psql -X -d "$test_database" -v ON_ERROR_STOP=1 \
                -c 'alter table public.myg_nube_proyectos add constraint qa_nombre_personalizado check(length(nombre)<=123);'
            ;;
        varchar)
            expected_failure='no es text NOT NULL'
            docker exec -u postgres "$test_container" psql -X -d "$test_database" -v ON_ERROR_STOP=1 \
                -c 'alter table public.myg_nube_proyectos alter column nombre type varchar(200);'
            ;;
        invalid_existing_name)
            expected_failure='myg_nube_proyectos_nombre_2000_check'
            # El contrato antiguo no tiene CHECK en este fixture. La nueva
            # restricción fallará DESPUÉS de reemplazar los cuatro RPC: debe
            # revertirlos también, sin borrar o corregir el nombre existente.
            docker exec -u postgres "$test_container" psql -X -d "$test_database" -v ON_ERROR_STOP=1 \
                -c "insert into public.myg_nube_proyectos(id,propietario,nombre,contenido) values('fa000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','','{}');"
            ;;
    esac
    before_state=$(docker exec -u postgres "$test_container" psql -X -At -d "$test_database" -v ON_ERROR_STOP=1 -c 'select qa.firma_estado_nombres()')
    if docker exec -u postgres "$test_container" psql -X -d "$test_database" -v ON_ERROR_STOP=1 \
        -f /pruebas/supabase/migraciones/20261102_nombres_proyectos_2000.sql > "$test_workspace/$scenario.log" 2>&1; then
        cat "$test_workspace/$scenario.log"; printf 'FALLO: debía rechazar %s\n' "$scenario" >&2; exit 1
    fi
    failure_message=$(< "$test_workspace/$scenario.log")
    if [[ "$failure_message" != *"$expected_failure"* ]]; then
        cat "$test_workspace/$scenario.log"; printf 'FALLO: causa inesperada al rechazar %s\n' "$scenario" >&2; exit 1
    fi
    after_state=$(docker exec -u postgres "$test_container" psql -X -At -d "$test_database" -v ON_ERROR_STOP=1 -c 'select qa.firma_estado_nombres()')
    if [[ "$before_state" != "$after_state" ]]; then
        printf 'FALLO: estado alterado tras abortar %s\n' "$scenario" >&2; exit 1
    fi
    printf 'PASS: rechazo transaccional de %s; catálogo y datos intactos\n' "$scenario"
done

# CRLF y atributos de despliegue personalizados permitidos por el contrato.
# Solo cambian los finales de línea del cuerpo y metadatos, nunca su lógica.
docker exec -u postgres "$test_container" createdb -T qa_nombres_base qa_nombres_crlf
docker exec -i -u postgres "$test_container" psql -X -d qa_nombres_crlf -v ON_ERROR_STOP=1 <<'SQL'
do $$ declare v record; begin
    for v in select p.oid,p.prosrc,pg_get_functiondef(p.oid) definicion from pg_proc p where p.oid in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_crear_comprimido(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint)'::regprocedure)
    loop
        execute replace(v.definicion,v.prosrc,replace(v.prosrc,E'\n',E'\r\n'));
        execute format('alter function %s set statement_timeout to %L',v.oid::regprocedure,'73s');
        execute format('grant execute on function %s to anon',v.oid::regprocedure);
    end loop;
end $$;
create table qa.nombres_crlf_antes as select p.oid,to_jsonb(p)-'prosrc' atributos
from pg_proc p where p.oid in (
    'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
    'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure,
    'public.myg_nube_crear_comprimido(uuid,text,jsonb,text)'::regprocedure,
    'public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint)'::regprocedure);
SQL
for attempt in 1 2; do
    docker exec -u postgres "$test_container" psql -X -d qa_nombres_crlf -v ON_ERROR_STOP=1 \
        -f /pruebas/supabase/migraciones/20261102_nombres_proyectos_2000.sql
done
docker exec -i -u postgres "$test_container" psql -X -d qa_nombres_crlf -v ON_ERROR_STOP=1 <<'SQL'
select qa.exige((select count(*)=4 and bool_and(to_jsonb(p)-'prosrc'=a.atributos
    and strpos(p.prosrc,E'\r\n')>0 and strpos(replace(p.prosrc,E'\r\n',''),E'\n')=0
    and regexp_replace(p.prosrc,'[[:space:]]','','g') like '%length(btrim(p_nombre))notbetween1and2000%')
    from qa.nombres_crlf_antes a join pg_proc p on p.oid=a.oid),
    'Nombres2000: acepta CRLF, conserva sus EOL y metadatos ACL/config tras dos instalaciones');
select qa.exige((select regexp_replace(prosrc,'[[:space:]]','','g') like
    '%length(btrim(p_documento_id))notbetween1and200then%'
    from pg_proc where oid='public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint)'::regprocedure),
    'Nombres2000: CRLF conserva el guard independiente documento_id200');
SQL

# NOT VALID no elimina la validación para filas nuevas. NO INHERIT y comentario
# son parte del CHECK instalado y deben mantenerse al cambiar solo el límite.
docker exec -u postgres "$test_container" createdb -T qa_nombres_base qa_nombres_check_notvalid
docker exec -i -u postgres "$test_container" psql -X -d qa_nombres_check_notvalid -v ON_ERROR_STOP=1 <<'SQL'
alter table public.myg_nube_proyectos add constraint qa_nombre_noinherit_check
    check(length(nombre)<=200) no inherit not valid;
comment on constraint qa_nombre_noinherit_check on public.myg_nube_proyectos
    is 'QA: CHECK no inherit not valid';
SQL
docker exec -u postgres "$test_container" psql -X -d qa_nombres_check_notvalid -v ON_ERROR_STOP=1 \
    -f /pruebas/supabase/migraciones/20261102_nombres_proyectos_2000.sql
docker exec -i -u postgres "$test_container" psql -X -d qa_nombres_check_notvalid -v ON_ERROR_STOP=1 <<'SQL'
select qa.exige((select not convalidated and connoinherit
    and obj_description(oid,'pg_constraint')='QA: CHECK no inherit not valid'
    and pg_get_constraintdef(oid) like '%2000%'
    from pg_constraint where conrelid='public.myg_nube_proyectos'::regclass
    and conname='qa_nombre_noinherit_check'),
    'Nombres2000: conserva NOT VALID, NO INHERIT y comentario de CHECK upper-only');
select qa.rechaza($$insert into public.myg_nube_proyectos(id,propietario,nombre,contenido)
    values(gen_random_uuid(),'00000000-0000-0000-0000-000000000001',repeat('a',2001),'{}')$$,'23514',
    'Nombres2000: CHECK NOT VALID mantiene protección de nuevas filas');
SQL

# Si no había CHECK de nombre, se añade uno nuevo sin omitir el límite de tabla.
docker exec -u postgres "$test_container" createdb -T qa_nombres_base qa_nombres_sin_check
docker exec -u postgres "$test_container" psql -X -d qa_nombres_sin_check -v ON_ERROR_STOP=1 \
    -f /pruebas/supabase/migraciones/20261102_nombres_proyectos_2000.sql
docker exec -i -u postgres "$test_container" psql -X -d qa_nombres_sin_check -v ON_ERROR_STOP=1 <<'SQL'
select qa.exige(exists(select 1 from pg_constraint where conrelid='public.myg_nube_proyectos'::regclass
    and conname='myg_nube_proyectos_nombre_2000_check' and pg_get_constraintdef(oid) like '%2000%'),
    'Nombres2000: añade CHECK de 2000 si la tabla no tenía validación de nombre');
select qa.rechaza($$insert into public.myg_nube_proyectos(id,propietario,nombre,contenido)
    values(gen_random_uuid(),'00000000-0000-0000-0000-000000000001',repeat('a',2001),'{}')$$,'23514',
    'Nombres2000: CHECK nuevo rechaza 2001 caracteres directamente en tabla');
SQL

docker exec -u postgres "$test_container" createdb -T qa_nombres_base qa_nombres_ok
docker exec -u postgres "$test_container" psql -X -d qa_nombres_ok \
    -v MYG_PRUEBAS_DESECHABLES=1 -v MYG_NOMBRES_FIXTURE_PREPARADO=1 -v ON_ERROR_STOP=1 \
    -f /pruebas/supabase/pruebas/nombres_proyectos_2000.sql
printf 'NOMBRES_PROYECTOS_2000_RUNNER_APROBADO\n'
