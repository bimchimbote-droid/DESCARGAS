-- SOLO LECTURA. Ejecutar completo en SQL Editor del mismo proyecto Supabase.
-- Diagnostica el POST a Storage, antes de la confirmación mediante RPC.
-- No modifica buckets, políticas, objetos, permisos ni obras. No muestra
-- archivos, cuerpos de funciones, tokens, sesiones o filas de proyectos.
-- Plantilla sin identificadores ni tamaños de archivos de usuarios.
-- Completar LOCALMENTE ruta con el nombre del objeto dentro del bucket y
-- bytes_envio con el Content-Length del POST que se desea diagnosticar.
-- No pegar tokens, claves ni cabeceras Authorization en esta consulta.
begin read only;

with entrada as (
    select 'myg-nube-sqlite'::text bucket,
        NULL::text ruta,
        'application/vnd.sqlite3'::text mime_cliente,
        NULL::bigint bytes_envio
)
select e.bucket, e.ruta,
    e.ruta ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{32}/[0-9a-f]{64}\.sqlite$' ruta_formato_valido,
    b.id is not null bucket_existe,
    b.public is false bucket_privado,
    b.file_size_limit limite_bucket_bytes,
    e.bytes_envio, round(e.bytes_envio / 1048576.0,2) envio_mib,
    case when b.id is null then null
        else b.file_size_limit is null or e.bytes_envio<=b.file_size_limit
    end limite_bucket_permite_envio,
    b.allowed_mime_types tipos_mime_permitidos,
    e.mime_cliente,
    case when b.id is null then null
        when b.allowed_mime_types is null or cardinality(b.allowed_mime_types)=0 then true
        else exists(select 1 from unnest(b.allowed_mime_types) m(tipo)
            where lower(btrim(split_part(m.tipo,';',1))) in (e.mime_cliente, 'application/*'))
    end configuracion_mime_permite_tipo_cliente,
    o.id is not null objeto_exacto_existe,
    o.metadata->>'size' objeto_bytes_registrados,
    o.metadata->>'mimetype' objeto_mime_registrado
from entrada e
left join storage.buckets b on b.id=e.bucket
left join storage.objects o on o.bucket_id=e.bucket and o.name=e.ruta;

-- Storage solo aplica la restricción MIME si la lista tiene elementos; NULL
-- y '{}' no restringen. Se admite el comodín de subtipo application/*, no */*.
-- Fuente: github.com/supabase/storage, src/storage/uploader.ts y
-- src/storage/validators/mime-type.ts (consultados el 31 de octubre de 2026).

-- No filtrar por nombre de política ni por bucket: una política RESTRICTIVE
-- creada para otro bucket también puede impedir esta subida. Las expresiones
-- son configuración de acceso; no se consultan archivos ni filas de obras.
select policyname, permissive, roles, cmd, qual condicion_lectura,
    with_check condicion_escritura
from pg_policies
where schemaname='storage' and tablename='objects'
order by permissive, cmd, policyname;

-- Existencia y RLS; las tablas privadas faltantes se informan sin consultarlas.
with requeridas(nombre) as (values
    ('storage.buckets'), ('storage.objects'),
    ('public.myg_nube_proyectos'), ('public.myg_nube_miembros'),
    ('myg_nube_privado.identidades_verificadas'),
    ('myg_nube_privado.sqlite_proyectos'), ('myg_nube_privado.sqlite_revisiones')
)
select r.nombre, c.oid is not null existe,
    c.relrowsecurity rls_habilitado, c.relforcerowsecurity rls_forzado
from requeridas r left join pg_class c on c.oid=to_regclass(r.nombre)
order by r.nombre;

-- Permisos de tabla/esquema del rol que usa el JWT de la aplicación.
-- Un permiso concedido no demuestra que una fila supere RLS.
with objetivos(nombre) as (values ('storage.buckets'), ('storage.objects')),
    roles_requeridos(nombre) as (values ('authenticated'), ('anon'))
select o.nombre objeto, r.nombre rol, pr.oid is not null rol_existe,
    case when pr.oid is not null and n.oid is not null
        then has_schema_privilege(pr.oid,n.oid,'USAGE') end uso_esquema,
    case when pr.oid is not null and c.oid is not null
        then has_table_privilege(pr.oid,c.oid,'SELECT') end puede_select,
    case when pr.oid is not null and c.oid is not null
        then has_table_privilege(pr.oid,c.oid,'INSERT') end puede_insert
from objetivos o cross join roles_requeridos r
left join pg_roles pr on pr.rolname=r.nombre
left join pg_class c on c.oid=to_regclass(o.nombre)
left join pg_namespace n on n.oid=c.relnamespace
order by o.nombre,r.nombre;

-- Solo firmas, atributos y permisos; nunca el cuerpo de las funciones.
with funciones(firma) as (values
    ('auth.uid()'),
    ('myg_nube_privado.sqlite_objeto_acceso(text,boolean)'),
    ('myg_nube_privado.sqlite_puede_escribir(uuid,uuid)'),
    ('myg_nube_privado.identidad()'),
    ('public.myg_nube_sqlite_capacidades()'),
    ('public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint)')
), roles_requeridos(nombre) as (values ('authenticated'), ('anon'))
select f.firma, p.oid is not null existe, p.prosecdef security_definer,
    r.nombre rol, pr.oid is not null rol_existe,
    case when pr.oid is not null and n.oid is not null
        then has_schema_privilege(pr.oid,n.oid,'USAGE') end uso_esquema,
    case when pr.oid is not null and p.oid is not null
        then has_function_privilege(pr.oid,p.oid,'EXECUTE') end puede_ejecutar
from funciones f cross join roles_requeridos r
left join pg_proc p on p.oid=to_regprocedure(f.firma)
left join pg_namespace n on n.oid=p.pronamespace
left join pg_roles pr on pr.rolname=r.nombre
order by f.firma,r.nombre;

-- Triggers de Storage: nombres y estado, sin argumentos ni cuerpos.
select c.relname tabla, t.tgname nombre_trigger, t.tgenabled estado,
    n.nspname esquema_funcion, p.proname funcion, p.prosecdef security_definer
from pg_trigger t
join pg_class c on c.oid=t.tgrelid
join pg_namespace tn on tn.oid=c.relnamespace
join pg_proc p on p.oid=t.tgfoid
join pg_namespace n on n.oid=p.pronamespace
where tn.nspname='storage' and c.relname in ('objects','buckets')
    and not t.tgisinternal
order by c.relname,t.tgname;

-- Este informe no verifica el límite GLOBAL del servicio Storage, la sesión
-- del cliente ni el cuerpo HTTP rechazado. SQL Editor suele ejecutarse como
-- administrador, sin el JWT de MYG: no usar auth.uid() aquí para deducir que
-- la cuenta de la aplicación carece de identidad o de permisos.
rollback;
