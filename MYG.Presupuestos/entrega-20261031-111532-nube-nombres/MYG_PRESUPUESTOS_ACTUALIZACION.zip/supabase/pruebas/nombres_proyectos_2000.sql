-- SOLO PostgreSQL DESECHABLE: no ejecutar en Supabase real.
-- Usa los RPC reales de las migraciones y el baseline legado exportado del
-- fixture. No sustituye validadores productivos ausentes por implementaciones
-- inventadas: los límites de compatibilidad de la migración siguen activos.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren PostgreSQL desechable.'; end $$;
\endif
\if :{?MYG_NOMBRES_FIXTURE_PREPARADO}
\else
  \ir archivos_sqlite.sql
\endif
reset role;

alter table public.myg_nube_proyectos add constraint qa_nombre_largo_check
    check(length(btrim(nombre)) between 1 and 200);
comment on constraint qa_nombre_largo_check on public.myg_nube_proyectos
    is 'QA: comentario del CHECK que debe conservarse';

create table qa.nombres_antes as select
    (select jsonb_agg(to_jsonb(p) order by p.oid) from pg_proc p
        join pg_namespace n on n.oid=p.pronamespace
        where n.nspname in ('public','myg_nube_privado')) funciones,
    (select to_jsonb(c) from pg_class c where c.oid='public.myg_nube_proyectos'::regclass) tabla,
    (select jsonb_agg(to_jsonb(t) order by t.oid) from pg_trigger t
        where t.tgrelid='public.myg_nube_proyectos'::regclass) triggers,
    (select jsonb_agg(to_jsonb(p) order by p.schemaname,p.tablename,p.policyname)
        from pg_policies p where p.schemaname in ('public','storage')) politicas,
    (select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p) proyectos,
    (select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m) miembros,
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h) historial;

\ir ../migraciones/20261102_nombres_proyectos_2000.sql

select qa.exige(not exists(
    select 1 from qa.nombres_antes a cross join jsonb_array_elements(a.funciones) antes
    left join pg_proc p on p.oid=(antes->>'oid')::oid
    where p.oid is null or to_jsonb(p)-'prosrc' is distinct from antes-'prosrc'),
    'Nombres2000: conserva OID, propietario, ACL, configuración y atributos de todas las funciones');
select qa.exige(not exists(
    select 1 from qa.nombres_antes a cross join jsonb_array_elements(a.funciones) antes
    join pg_proc p on p.oid=(antes->>'oid')::oid
    where p.oid not in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_crear_comprimido(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint)'::regprocedure)
    and p.prosrc is distinct from antes->>'prosrc'),
    'Nombres2000: no modifica cuerpos de funciones ajenas');
select qa.exige((select tabla=(select to_jsonb(c) from pg_class c
    where c.oid='public.myg_nube_proyectos'::regclass) from qa.nombres_antes),
    'Nombres2000: conserva tabla, propietario, privilegios y RLS');
select qa.exige((select triggers is not distinct from (select jsonb_agg(to_jsonb(t) order by t.oid)
    from pg_trigger t where t.tgrelid='public.myg_nube_proyectos'::regclass)
    and politicas is not distinct from (select jsonb_agg(to_jsonb(p) order by p.schemaname,p.tablename,p.policyname)
    from pg_policies p where p.schemaname in ('public','storage')) from qa.nombres_antes),
    'Nombres2000: conserva todos los triggers y políticas');
select qa.exige((select proyectos=(select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p)
    and miembros=(select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m)
    and historial=(select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h)
    from qa.nombres_antes),
    'Nombres2000: no modifica obras, nombres existentes, miembros ni historial');
select qa.exige((select obj_description(c.oid,'pg_constraint')='QA: comentario del CHECK que debe conservarse'
    and pg_get_constraintdef(c.oid) like '%2000%'
    from pg_constraint c where c.conrelid='public.myg_nube_proyectos'::regclass
    and c.conname='qa_nombre_largo_check'),
    'Nombres2000: amplía el CHECK conocido conservando su nombre y comentario');

create table qa.nombres_despues_primera as select
    (select jsonb_agg(to_jsonb(p) order by p.oid) from pg_proc p
        join pg_namespace n on n.oid=p.pronamespace
        where n.nspname in ('public','myg_nube_privado')) funciones,
    (select jsonb_agg(to_jsonb(c) order by c.oid) from pg_constraint c
        where c.conrelid='public.myg_nube_proyectos'::regclass) restricciones;
\ir ../migraciones/20261102_nombres_proyectos_2000.sql
select qa.exige((select funciones=(select jsonb_agg(to_jsonb(p) order by p.oid) from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('public','myg_nube_privado'))
    and restricciones=(select jsonb_agg(to_jsonb(c) order by c.oid) from pg_constraint c
        where c.conrelid='public.myg_nube_proyectos'::regclass) from qa.nombres_despues_primera),
    'Nombres2000: repetir la migración no cambia funciones ni recrea CHECK instalados');

create function qa.crear_nombre(p_tipo text,p_id uuid,p_nombre text,p_documento text default 'doc-nombre')
returns jsonb language plpgsql as $$
declare v_ruta text; v_manifest jsonb;
begin
    if p_tipo='json' then
        return public.myg_nube_crear(p_id,p_nombre,
            (select contenido from qa.paquetes where nombre='baseline'),'obra');
    elsif p_tipo='ligera' then
        return public.myg_nube_crear_confirmacion(p_id,p_nombre,
            (select contenido from qa.paquetes where nombre='baseline'),'obra');
    elsif p_tipo='gzip' then
        v_ruta:=auth.uid()::text||'/'||replace(p_id::text,'-','')||'/'||repeat('b',64);
        insert into storage.objects(bucket_id,name,metadata)
            values('myg-nube-paquetes',v_ruta,'{"size":100}') on conflict do nothing;
        v_manifest:=jsonb_build_object('formato','MYG_ARCHIVO_GZIP','version',1,
            'sha256_json',repeat('a',64),'bytes_json',4096,
            'sha256_gzip',repeat('b',64),'bytes_gzip',100,
            'partes',jsonb_build_array(jsonb_build_object('ruta',v_ruta,'sha256',repeat('b',64),'bytes',100)));
        return public.myg_nube_crear_comprimido(p_id,p_nombre,v_manifest,'obra');
    elsif p_tipo='sqlite' then
        v_ruta:=auth.uid()::text||'/'||replace(p_id::text,'-','')||'/'||repeat('a',64)||'.sqlite';
        insert into storage.objects(bucket_id,name,metadata)
            values('myg-nube-sqlite',v_ruta,'{"size":4096}') on conflict do nothing;
        return public.myg_nube_sqlite_crear(p_id,p_nombre,'obra',p_documento,v_ruta,repeat('a',64),4096);
    end if;
    raise exception 'Tipo QA desconocido';
end $$;
grant execute on function qa.crear_nombre(text,uuid,text,text) to authenticated;

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
do $limites$
declare v_tipo text; v_tamano integer; v_id uuid; v_nombre text; v_resultado jsonb;
begin
    foreach v_tipo in array array['json','ligera','gzip','sqlite'] loop
        foreach v_tamano in array array[1,200,201,2000] loop
            v_id:=md5('nombres2000/'||v_tipo||'/'||v_tamano)::uuid;
            v_nombre:=repeat('Ñ',v_tamano);
            v_resultado:=qa.crear_nombre(v_tipo,v_id,v_nombre);
            perform qa.exige(v_resultado->>'nombre'=v_nombre and v_resultado->>'rol'='propietario'
                and v_resultado->>'revision'='1',
                format('Nombres2000: %s conserva %s caracteres Unicode, propietario y revisión',v_tipo,v_tamano));
            perform qa.exige(qa.crear_nombre(v_tipo,v_id,v_nombre)->>'id'=v_id::text,
                format('Nombres2000: %s reintenta %s caracteres sin duplicar proyecto',v_tipo,v_tamano));
        end loop;
        perform qa.rechaza(format('select qa.crear_nombre(%L,%L,repeat(''Ñ'',2001))',
            v_tipo,md5('nombres2000/'||v_tipo||'/2001')::uuid),'22023',
            format('Nombres2000: %s rechaza 2001 caracteres',v_tipo));
        perform qa.rechaza(format('select qa.crear_nombre(%L,%L,''   '')',
            v_tipo,md5('nombres2000/'||v_tipo||'/vacio')::uuid),'22023',
            format('Nombres2000: %s rechaza nombre vacío tras trim',v_tipo));
        perform qa.rechaza(format('select qa.crear_nombre(%L,%L,null)',
            v_tipo,md5('nombres2000/'||v_tipo||'/null')::uuid),'22023',
            format('Nombres2000: %s rechaza nombre nulo',v_tipo));
        perform qa.rechaza(format('select qa.crear_nombre(%L,%L,''otro nombre'')',
            v_tipo,md5('nombres2000/'||v_tipo||'/2000')::uuid),'22023',
            format('Nombres2000: %s mantiene rechazo de UUID con nombre distinto',v_tipo));
    end loop;
    perform qa.exige(qa.crear_nombre('sqlite',md5('nombres2000/documento200')::uuid,
        repeat('Á',2000),repeat('d',200))->>'documento_id'=repeat('d',200),
        'Nombres2000: SQLite conserva documento_id de 200 caracteres');
    perform qa.rechaza(format('select qa.crear_nombre(''sqlite'',%L,''nombre'',repeat(''d'',201))',
        md5('nombres2000/documento201')::uuid),'22023',
        'Nombres2000: SQLite sigue rechazando documento_id de 201 caracteres');
end $limites$;

set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
do $propietario$
declare v_tipo text;
begin
    foreach v_tipo in array array['json','ligera','gzip','sqlite'] loop
        perform qa.rechaza(format('select qa.crear_nombre(%L,%L,repeat(''Ñ'',2000))',
            v_tipo,md5('nombres2000/'||v_tipo||'/2000')::uuid),'42501',
            format('Nombres2000: %s no concede acceso a otro propietario',v_tipo));
    end loop;
end $propietario$;
reset role;

select qa.rechaza($$insert into public.myg_nube_proyectos(id,propietario,nombre,contenido)
    values(gen_random_uuid(),'00000000-0000-0000-0000-000000000001',repeat('a',2001),'{}')$$,'23514',
    'Nombres2000: CHECK de tabla sigue rechazando 2001 caracteres');
select qa.exige((select count(*)=16 from public.myg_nube_proyectos
    where id in(select md5('nombres2000/'||t||'/'||n)::uuid
        from unnest(array['json','ligera','gzip','sqlite']) t
        cross join unnest(array[1,200,201,2000]) n)),
    'Nombres2000: 16 publicaciones válidas y replays mantienen un solo proyecto cada una');
select count(*) comprobaciones_nombres_2000 from qa.resultados where descripcion like 'Nombres2000:%';
select 'NOMBRES_PROYECTOS_2000_SQL_APROBADOS' resultado;
