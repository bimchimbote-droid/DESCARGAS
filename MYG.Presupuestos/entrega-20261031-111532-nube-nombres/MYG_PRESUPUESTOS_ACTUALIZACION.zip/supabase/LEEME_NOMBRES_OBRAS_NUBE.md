# Nombres de proyectos y obras de hasta 2.000 caracteres

La nube pasa de admitir 200 a **2.000 caracteres** por nombre de proyecto u obra, para coincidir con la edición local de MYG. El cambio comprende el cliente, la lectura de respuestas, los formularios, las publicaciones pendientes y las validaciones de Supabase. Los nombres se conservan completos; no se modifica el contenido de los SQLite ni sus identificadores.

El límite corresponde al nombre de cada obra, además del nombre del respaldo privado. Siguen rechazándose los nombres vacíos y los caracteres de control, como saltos de línea o tabulaciones, según las validaciones existentes del cliente. Los nombres de más de 2.000 caracteres requieren corregirse antes de publicar.

## Aplicar la ampliación

1. Conservar la base local y el intento pendiente. Si el único problema es un nombre de 201 a 2.000 caracteres, **no es necesario retirar ni recrear el intento**.
2. En el SQL Editor del proyecto Supabase correcto, ejecutar completo `supabase/migraciones/20261102_nombres_proyectos_2000.sql`. Es una migración nueva para una instalación existente; no volver a ejecutar todas las migraciones anteriores. Si la transacción se detiene por una definición que no reconoce, conservar el error exacto y revisar esa definición antes de continuar.
3. Compilar y actualizar la aplicación con los cambios C# de esta entrega. Actualizar también los demás clientes que deban consultar proyectos de nombre largo: las versiones anteriores pueden rechazar respuestas con nombres mayores de 200 caracteres.
4. Volver a **Nube MYG → Publicaciones pendientes** y reintentar el intento existente. La ampliación no reescribe sus UUID, sus paquetes congelados ni las confirmaciones anteriores.

La migración no carga ni borra obras y no amplía permisos de usuarios. No modifica los límites de tamaño de archivos, cuotas ni plan de Storage. El error por nombre es distinto del rechazo del archivo de 58,51 MiB frente al límite global de 50 MB.

El SQL y el código se preparan y verifican localmente. Aplicarlos al Supabase remoto y actualizar el equipo Windows son pasos necesarios; no se han ejecutado desde esta sesión.

## Nombre predeterminado de la base importada

Al elegir **Importar base completa privada**, se propone el nombre del archivo SQLite sin su extensión. Por ejemplo, `Presupuesto municipal.sqlite` propone **Presupuesto municipal**. La obra seleccionada dentro de esa base no sustituye ese nombre.

Los intentos ya congelados conservan su nombre para reintentar la misma publicación; esta sugerencia se aplica al preparar una importación nueva.

El campo de nombre permanece editable, con selección de texto y los atajos habituales **Ctrl+A**, **Ctrl+C** y **Ctrl+V**. Si se elige otro archivo mientras el nombre sigue siendo el sugerido automáticamente, se actualiza la sugerencia. Si el usuario ya escribió un nombre propio, se conserva. Los modos para publicar una sola obra siguen proponiendo el nombre de esa obra.

## Archivos de la ampliación

- `MYG.Colaboracion/ClienteNubeProyectos.cs`: límite compartido de 2.000 caracteres para validar entradas y leer respuestas de proyectos.
- `MYG.Colaboracion/ArchivoPublicacionPendienteNube.cs`, `PublicacionSqlitePendiente.cs` y `PublicacionBasePendiente.cs`: preparación, lectura y reintento de publicaciones de nombre largo.
- `MYG.Desktop/NubePublicarForm.cs`: entrada y validación del nombre en el formulario y sugerencia basada en el archivo importado.
- `supabase/migraciones/20261102_nombres_proyectos_2000.sql`: ampliación de las validaciones de nombres en Supabase.
- Pruebas focalizadas de cliente y SQL indicadas por los comandos de validación.

Los límites de identidades de documentos, códigos y otros campos siguen siendo los suyos; no son nombres de proyectos.

## Validación de desarrollo

Desde la raíz del repositorio, con SDK .NET 10:

```text
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --nombres-proyectos
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --bases-obras
```

Las pruebas C# usan SQLite real y transporte HTTP simulado. La interfaz requiere Windows y no se ejecuta en Linux. Las pruebas SQL usan PostgreSQL desechable, separado del Supabase real. El runner es `bash scripts/pruebas/Probar-NombresProyectos2000.sh`, con Docker disponible y el SDK activado; nunca se ejecuta contra el proyecto remoto del usuario.

Resultados locales: 57 comprobaciones del selector de nombres (incluidas las sugerencias del formulario), 105 de bases/obras y 73 verificaciones SQL aprobadas en PostgreSQL 17. Las pruebas comprueban nombres de 201 y 2.000 caracteres, reintentos, conservación de copias, permisos, límites y migración repetible. La interacción visual y el portapapeles de Windows no se ejecutaron en Linux; se habilitan los comportamientos nativos del TextBox.

## Aplicación manual de esta entrega y GitHub

Base de código utilizada: `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`, commit `c19d6c589b196e41bd4ca300186f37da0a3d6bb4`. El checkout de la tarea usa la rama local aislada `work`; no se ha hecho push del código fuente.

En su PC, cierre MYG y abra `D:\ADDIN\repos\MYG.Presupuestos_GITHUB` en Visual Studio. Revise primero **Cambios de Git** y haga una copia de seguridad o un commit de sus avances. Compare cualquier modificación local o posterior: los archivos REEMPLAZAR de la entrega son versiones completas y copiarlos encima puede sustituir esos cambios. Extraiga el ZIP en una carpeta temporal y copie solo sus archivos respetando sus rutas relativas. No sustituya la carpeta completa del repositorio ni `.git`; no hay archivos que eliminar.

Conserve las bases y los pendientes locales. Ejecute completo el SQL nuevo de ampliación en Supabase, actualice todos los clientes que deban leer nombres largos, restaure dependencias y compile:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --nombres-proyectos
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --bases-obras
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --sqlite-nativo
```

No se añaden paquetes NuGet ni se cambian versiones; la referencia de compilación del helper de nombres en el proyecto de pruebas forma parte de la entrega. En Windows con Revit instalado puede compilar el conector contra sus DLL sin `UseRevitReferencePackages=true`, siguiendo la configuración original.

Prueba manual en Windows: elegir **Importar base completa privada**, seleccionar un SQLite, comprobar el nombre del archivo sin extensión, probar Ctrl+A/C/V y una edición propia, cambiar de obra y confirmar que el nombre de la base no se reemplaza. Comprobar después la importación de nombres largos y reintentar el pendiente existente. Si la migración informa bloqueo, esperar a que terminen las operaciones activas y volver a ejecutar el archivo completo; si informa una definición desconocida, conservar el error y revisar esa variante.

La suite Nube completa tenía un fallo previo diagnosticado en `PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`: su expectativa de fase RPC difiere de la fase de renovación de sesión de la implementación. Las suites focales aprobadas no convierten la suite completa en aprobada ni certifican Supabase real. La interfaz Windows, el portapapeles, el instalador y Revit necesitan validación en su equipo.

Después de validar, revise en **Cambios de Git** la lista de archivos, confirme la rama `main` (o su rama habitual), haga Commit y luego Push desde Visual Studio. Compruebe el commit y los archivos en GitHub. Publicar el ZIP en DESCARGAS no hace estos pasos ni significa que los cambios ya estén instalados en su PC o en Supabase.
