-- Nombres de proyectos y bases: de 200 a 2000 caracteres, sin truncarlos.
-- Ejecutar COMPLETO después de las migraciones SQLite y bases/obras existentes.
-- No volver a ejecutar migraciones históricas después de esta actualización:
-- algunas restauran el límite anterior. Actualizar también todos los clientes.
-- No cambia documento_id, UUID, rutas, archivos, contenido, miembros ni roles.
-- Una transacción; requiere administrador. ACCESS EXCLUSIVE bloquea lecturas
-- y escrituras de myg_nube_proyectos mientras comprueba/recrea sus CHECK.
-- Si no obtiene el bloqueo en 5 segundos, aborta sin dejar cambios; reintentar
-- el archivo completo cuando no haya operaciones activas sobre esa tabla.
-- Se conservan OID de tabla/funciones, propietarios, ACL, proconfig, triggers y
-- RLS. PostgreSQL recrea el OID de los CHECK modificados; preservamos sus otros
-- atributos, nombre y comentario. Una definición desconocida aborta TODO.
begin;
set local lock_timeout='5s';

do $nombres_proyectos_2000$
declare
    v_tabla oid:=to_regclass('public.myg_nube_proyectos');
    v_columna smallint;
    v_rpc record;
    v_funcion record;
    v_constraint record;
    v_huella text;
    v_fuente_nueva text;
    v_def_nueva text;
    v_expr text;
    v_plan_funciones jsonb:='[]'::jsonb;
    v_plan_checks jsonb:='[]'::jsonb;
    v_cambio jsonb;
    v_checks integer:=0;
    v_tabla_antes jsonb;
    v_triggers_antes jsonb;
    v_politicas_antes jsonb;
    v_guard_200 constant text:='length\(btrim\(p_nombre\)\) not between 1 and 200([^0-9]|$)';
    v_guard_2000 constant text:='length\(btrim\(p_nombre\)\) not between 1 and 2000([^0-9]|$)';
begin
    if v_tabla is null then
        raise exception using errcode='55000',message='Falta public.myg_nube_proyectos. No se cambió ningún límite.';
    end if;
    lock table public.myg_nube_proyectos in access exclusive mode;
    select a.attnum into v_columna from pg_attribute a
    where a.attrelid=v_tabla and a.attname='nombre' and not a.attisdropped
        and a.atttypid='text'::regtype and a.atttypmod=-1 and a.attnotnull and a.attgenerated='';
    if v_columna is null or exists(select 1 from pg_inherits where inhrelid=v_tabla or inhparent=v_tabla) then
        raise exception using errcode='55000',message='La columna nombre no es text NOT NULL sin herencia como en el contrato conocido. Se conserva intacta; revise su tipo/constraints antes de adaptar el límite.';
    end if;
    select jsonb_build_object('oid',c.oid,'propietario',c.relowner,'acl',c.relacl,
        'rls',c.relrowsecurity,'forzar_rls',c.relforcerowsecurity,'opciones',c.reloptions)
      into v_tabla_antes from pg_class c where c.oid=v_tabla;
    select coalesce(jsonb_agg(to_jsonb(t) order by t.oid),'[]'::jsonb)
      into v_triggers_antes from pg_trigger t where t.tgrelid=v_tabla;
    select coalesce(jsonb_agg(to_jsonb(p) order by p.oid),'[]'::jsonb)
      into v_politicas_antes from pg_policy p where p.polrelid=v_tabla;

    -- Cuerpos oficiales, normalizando SOLO CRLF a LF. La función JSON antigua
    -- procede del baseline exportado incluido en pruebas/usuarios_myg_roles.sql;
    -- el DDL inicial productivo no está en el repositorio. Si difiere, se exige
    -- revisar esa diferencia: no se sustituye una implementación desconocida.
    -- En cada fila: firma, huella 200, huella 2000. Ligera admite versiones26/27.
    for v_rpc in select * from (values
        ('public.myg_nube_crear(uuid,text,jsonb,text)',
            array['186740108ea1eebc5570ae24b36e3806']::text[],
            array['04063f54c4605800cf9e8e759e3afe62']::text[]),
        ('public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)',
            array['d00c2b6242abf449ada0eeb1a081451b','0e4fc248646351ac672e015931e721e9']::text[],
            array['ab4089a26335353b4451ddcb75da7334','4496103d75f3bd998507dadf0147261f']::text[]),
        ('public.myg_nube_crear_comprimido(uuid,text,jsonb,text)',
            array['efc782f664f7837b9936f7115f5a9b99']::text[],
            array['15c9bbf2cf5a1e12e9d3b0a3ce91e179']::text[]),
        ('public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint)',
            array['1096e3e07bc39bd631d4da7c0afaba05']::text[],
            array['e9302b4b05ac869ac6300f3093cd48e4']::text[])
    ) r(firma,huellas_200,huellas_2000) loop
        select p.*,l.lanname into v_funcion from pg_proc p
        join pg_language l on l.oid=p.prolang where p.oid=to_regprocedure(v_rpc.firma);
        if not found or v_funcion.prokind<>'f' or not v_funcion.prosecdef
            or v_funcion.prorettype<>'jsonb'::regtype or v_funcion.lanname<>'plpgsql' then
            raise exception using errcode='55000',message=format('Falta el RPC compatible %s. No se modificó ninguna función.',v_rpc.firma);
        end if;
        v_huella:=md5(replace(v_funcion.prosrc,E'\r\n',E'\n'));
        if v_huella=any(v_rpc.huellas_2000) then
            if (select count(*) from regexp_matches(v_funcion.prosrc,v_guard_2000,'g'))<>1 then
                raise exception 'El guard de nombre2000 no es único en %.',v_rpc.firma;
            end if;
            continue; -- Idempotente: no recrear funciones ya actualizadas.
        end if;
        if not v_huella=any(v_rpc.huellas_200)
            or (select count(*) from regexp_matches(v_funcion.prosrc,v_guard_200,'g'))<>1 then
            raise exception using errcode='55000',message=format('El cuerpo de %s es desconocido. Se conserva intacto; revise su definición y validación de nombre antes de ampliar el límite.',v_rpc.firma);
        end if;
        -- Solo el número del guard de p_nombre, con frontera numérica:
        -- nunca tocar p_documento_id ni convertir 2000 en 20000 al reinstalar.
        v_fuente_nueva:=regexp_replace(v_funcion.prosrc,v_guard_200,
            'length(btrim(p_nombre)) not between 1 and 2000\1');
        if not md5(replace(v_fuente_nueva,E'\r\n',E'\n'))=any(v_rpc.huellas_2000) then
            raise exception 'La sustitución de nombre2000 no coincide con el cuerpo esperado en %.',v_rpc.firma;
        end if;
        v_def_nueva:=replace(pg_get_functiondef(v_funcion.oid),v_funcion.prosrc,v_fuente_nueva);
        v_plan_funciones:=v_plan_funciones||jsonb_build_array(jsonb_build_object(
            'oid',v_funcion.oid,'definicion',v_def_nueva,'fuente',v_fuente_nueva,
            'atributos',(select to_jsonb(p)-'prosrc' from pg_proc p where p.oid=v_funcion.oid)));
    end loop;

    -- No se conocen los CHECK iniciales de producción. Aceptar solo límites
    -- simples sobre esta columna; cualquier combinación personalizada aborta.
    -- Se conserva exactamente el resto de cada expresión, sin bajar mínimos ni
    -- retirar restricciones adicionales. También se preserva NOT VALID/NO INHERIT.
    for v_constraint in select c.*,pg_get_expr(c.conbin,c.conrelid) expresion,
        pg_get_constraintdef(c.oid) definicion,obj_description(c.oid,'pg_constraint') comentario
      from pg_constraint c where c.conrelid=v_tabla and c.contype='c' and v_columna=any(c.conkey)
    loop
        v_checks:=v_checks+1;
        v_expr:=lower(regexp_replace(v_constraint.expresion,'[[:space:]()]','','g'));
        if v_constraint.conkey<>array[v_columna]::smallint[] or not v_constraint.conislocal
            or v_constraint.coninhcount<>0 or v_constraint.conparentid<>0
            or v_expr !~ '^(length|char_length)(btrim)?nombre>=1and(length|char_length)(btrim)?nombre<=200(0)?$'
                and v_expr !~ '^(length|char_length)(btrim)?nombre<=200(0)?$' then
            raise exception using errcode='55000',message=format('El CHECK %s de nombre es desconocido; se conserva intacto. Revise su expresión antes de adaptar el límite.',v_constraint.conname);
        end if;
        -- Los dos lados deben medir de la misma manera; no adaptar mezclas.
        if position('and' in v_expr)>0 and split_part(v_expr,'>=1and',1)
            <>regexp_replace(split_part(v_expr,'>=1and',2),'<=200(0)?$','') then
            raise exception 'El CHECK % combina medidas diferentes de nombre; se conserva intacto.',v_constraint.conname;
        end if;
        if v_expr ~ '<=2000$' then continue; end if;
        v_def_nueva:=regexp_replace(v_constraint.definicion,'<=[[:space:]]*200([^0-9]|$)','<= 2000\1');
        if v_def_nueva=v_constraint.definicion then raise exception 'No se pudo ampliar el CHECK %.',v_constraint.conname; end if;
        v_plan_checks:=v_plan_checks||jsonb_build_array(jsonb_build_object(
            'nombre',v_constraint.conname,'definicion',v_def_nueva,'comentario',v_constraint.comentario,
            'atributos',(select to_jsonb(c)-array['oid','conbin'] from pg_constraint c where c.oid=v_constraint.oid)));
    end loop;
    if v_checks=0 and exists(select 1 from pg_constraint where conrelid=v_tabla
        and conname='myg_nube_proyectos_nombre_2000_check') then
        raise exception 'El nombre del CHECK nuevo ya está ocupado por otra restricción; no se cambió nada.';
    end if;

    -- Ejecutar solo después de completar TODO el preflight. Cualquier fallo en
    -- un CHECK o postcondición revierte también las funciones anteriores.
    for v_cambio in select value from jsonb_array_elements(v_plan_funciones) loop
        execute v_cambio->>'definicion';
        if not exists(select 1 from pg_proc p where p.oid=(v_cambio->>'oid')::oid
            and p.prosrc=v_cambio->>'fuente' and to_jsonb(p)-'prosrc'=v_cambio->'atributos') then
            raise exception 'Cambió un atributo protegido de un RPC; se revierte toda la migración.';
        end if;
    end loop;
    for v_cambio in select value from jsonb_array_elements(v_plan_checks) loop
        execute format('alter table public.myg_nube_proyectos drop constraint %I',v_cambio->>'nombre');
        execute format('alter table public.myg_nube_proyectos add constraint %I %s',v_cambio->>'nombre',v_cambio->>'definicion');
        if v_cambio->>'comentario' is not null then
            execute format('comment on constraint %I on public.myg_nube_proyectos is %L',v_cambio->>'nombre',v_cambio->>'comentario');
        end if;
        if not exists(select 1 from pg_constraint c where c.conrelid=v_tabla
            and c.conname=v_cambio->>'nombre' and to_jsonb(c)-array['oid','conbin']=v_cambio->'atributos'
            and obj_description(c.oid,'pg_constraint') is not distinct from v_cambio->>'comentario') then
            raise exception 'Cambió un atributo protegido del CHECK; se revierte toda la migración.';
        end if;
    end loop;
    if v_checks=0 then
        alter table public.myg_nube_proyectos add constraint myg_nube_proyectos_nombre_2000_check
            check(length(btrim(nombre)) between 1 and 2000);
    end if;
    if v_tabla_antes is distinct from (select jsonb_build_object('oid',c.oid,'propietario',c.relowner,'acl',c.relacl,
            'rls',c.relrowsecurity,'forzar_rls',c.relforcerowsecurity,'opciones',c.reloptions) from pg_class c where c.oid=v_tabla)
        or v_triggers_antes is distinct from (select coalesce(jsonb_agg(to_jsonb(t) order by t.oid),'[]'::jsonb) from pg_trigger t where t.tgrelid=v_tabla)
        or v_politicas_antes is distinct from (select coalesce(jsonb_agg(to_jsonb(p) order by p.oid),'[]'::jsonb) from pg_policy p where p.polrelid=v_tabla) then
        raise exception 'Cambió un atributo, trigger o política protegido; se revierte toda la migración.';
    end if;
end $nombres_proyectos_2000$;

notify pgrst,'reload schema';
commit;
select 'NOMBRES_PROYECTOS_2000_INSTALADOS' resultado;
