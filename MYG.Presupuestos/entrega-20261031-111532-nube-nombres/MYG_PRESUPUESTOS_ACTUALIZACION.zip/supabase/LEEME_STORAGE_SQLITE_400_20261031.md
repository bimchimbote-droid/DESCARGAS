# Diagnóstico de errores HTTP al transferir SQLite

Un rechazo en `POST /storage/v1/object/myg-nube-sqlite/...sqlite` ocurre durante la transferencia del archivo, antes de la RPC que confirma sus metadatos. El estado HTTP 400 por sí solo no identifica la causa: hay que consultar el código de Storage y los límites efectivos, tipos MIME y permisos.

## Tamaño por archivo y espacio total

[La documentación oficial de Supabase](https://supabase.com/docs/guides/storage/uploads/file-limits) establece un máximo de **50 MB por archivo en el plan Free**. En Pro y superiores el límite global es configurable hasta 500 GB. El máximo del bucket no puede superar el límite global efectivo.

La migración SQLite de MYG configura su bucket para admitir hasta 300 MiB, pero no cambia el límite global ni el plan de Supabase. Un archivo de más de 50 MB no cabe en Free aunque quede espacio total en la cuenta. En un plan que lo permita, revisar **Storage → Settings → Global file size limit** y el límite del bucket antes de reintentar el mismo pendiente. SQL no eleva el máximo del plan Free.

Un archivo menor de 50 MB también puede ser rechazado por MIME, permisos u otra restricción. No atribuir todos los HTTP 400 al tamaño. La ampliación de nombres a 2.000 caracteres es independiente de estas cuotas.

## Corrección del diagnóstico del cliente

El cliente anterior leía la respuesta HTTP 400 para identificar duplicados y, si no lo era, intentaba leerla de nuevo. Con un stream de red la primera lectura consumía y cerraba el cuerpo. La segunda lectura perdía el código o fallaba por stream cerrado.

La corrección lee el cuerpo una sola vez y con límite de tamaño. Reconoce códigos conocidos de Storage y usa mensajes locales para distinguir permisos, MIME, tamaño, bucket y referencia inválida. No muestra mensajes arbitrarios del servidor, URL, credenciales ni contenido de la base. Conserva la referencia HTTP disponible y la fase de subida o descarga.

Un duplicado sigue exigiendo descargar y verificar tamaño y SHA-256 antes de confirmar. No se sobrescriben objetos ni se vuelve a publicar con otro identificador automáticamente.

## Diagnóstico de solo lectura

Si persiste el rechazo:

1. Conservar la base local y el intento pendiente.
2. Abrir `supabase/diagnosticos/20261031_storage_sqlite_solo_lectura.sql` en el SQL Editor del proyecto correcto. Completar sus entradas `ruta` y `bytes_envio` con los datos del POST investigado; se entregan vacías para no distribuir identificadores de usuarios. No introducir tokens ni claves.
3. Ejecutar todo el diagnóstico. Consultar existencia y privacidad del bucket, límite por objeto, tipos MIME admitidos, objeto exacto y políticas permisivas/restrictivas. El cliente envía `application/vnd.sqlite3`.
4. Comparar con el cuerpo de la respuesta HTTP si está disponible (`code`, `error`, `message`), omitiendo credenciales y cabeceras de autenticación.

El diagnóstico usa `BEGIN READ ONLY` y termina con `ROLLBACK`. No modifica buckets, políticas, archivos, funciones ni filas de obras. El SQL Editor no reproduce el JWT de la aplicación ni consulta el límite global del servicio: un grant visible no demuestra que una petición concreta supere RLS.

El SQL de bases y obras (`20261101_bases_obras.sql`) administra relaciones y permisos de obras. La corrección anterior de validación SQLite modifica un trigger de confirmación. No volver a ejecutar esas migraciones únicamente por un rechazo de Storage ni sustituir las políticas con una política abierta.

## Validación local

La solución completa compiló en Release con 0 errores y 0 advertencias usando SDK .NET 10.0.100. El selector `--sqlite-nativo` aprobó 506 comprobaciones de transporte, 21 de publicación pendiente y 29 del motor SQLite: **556 en total**, con SQLite real y HTTP simulado. Incluye errores en streams sin reposicionamiento, lectura acotada, cancelación, fallos transitorios y duplicados con verificación SHA-256.

El diagnóstico se validó en PostgreSQL 17 desechable, separado de Supabase real, con entradas sintéticas. Se comprobaron bucket ausente, MIME NULL/vacío, restricciones de tamaño/MIME y wildcard. No se verificaron el proyecto remoto ni la interfaz Windows del usuario.
