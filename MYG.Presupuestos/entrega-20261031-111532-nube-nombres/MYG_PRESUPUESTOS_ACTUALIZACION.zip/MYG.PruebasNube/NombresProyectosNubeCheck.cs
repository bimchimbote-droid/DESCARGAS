using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class NombresProyectosNubeCheck
{
    private const string Servidor = "https://nombres.supabase.co";
    private const string Usuario = "11111111-1111-4111-8111-111111111111";

    internal static async Task RunAsync()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-nombres-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        int comprobaciones = 0;
        void Exige(bool valor, string mensaje)
        { comprobaciones++; if (!valor) throw new InvalidOperationException(mensaje); }
        async Task Rechaza(Func<Task> accion)
        {
            bool rechazo = false;
            try { await accion(); }
            catch (Exception ex) when (ex is NubeException or InvalidDataException or ArgumentException) { rechazo = true; }
            Exige(rechazo, "Un nombre de proyecto inválido se aceptó.");
        }
        try
        {
            SugerenciasDeNombre(Exige);
            foreach (int longitud in new[] { 201, ClienteSupabase.MaxNombreProyectoNube })
            {
                string nombre = "Obra " + new string('漢', longitud - 5);
                string subcarpeta = Path.Combine(carpeta, longitud.ToString());
                Directory.CreateDirectory(subcarpeta);
                using var contenido = JsonDocument.Parse("{\"version\":2,\"presupuestos\":[]}");
                using var http = new Transporte();
                using var cliente = new ClienteSupabase(Servidor, "sb_publishable_prueba_nombres", http);
                await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
                Guid id = Guid.NewGuid();
                var creado = await cliente.CrearProyectoAsync(id, nombre, contenido.RootElement, "obra");
                var repetido = await cliente.CrearProyectoAsync(id, nombre, contenido.RootElement, "obra");
                var abierto = await cliente.AbrirProyectoAsync(id);
                var listado = await cliente.ListarProyectosAsync();
                Exige(creado.Nombre == nombre && repetido.Nombre == nombre && abierto.Nombre == nombre
                    && listado.Single().Nombre == nombre && http.NombresEnviados.All(n => n == nombre),
                    "Crear, reintentar, abrir y listar JSON deben conservar el nombre completo.");

                var colaJson = new ArchivoPublicacionPendienteNube(Path.Combine(subcarpeta, "json"), Servidor, Usuario);
                colaJson.Guardar(new(id, nombre, "obra", contenido.RootElement));
                var resumen = colaJson.Consultar()!;
                Exige(resumen.DatosLegibles && resumen.Nombre == nombre
                    && new ArchivoPublicacionPendienteNube(Path.Combine(subcarpeta, "json"), Servidor, Usuario).Leer(resumen).Nombre == nombre,
                    "La cabecera y el cuerpo del pendiente JSON deben admitir 2000 caracteres Unicode sin truncar.");
                colaJson.Confirmar(resumen);

                var documento = MYGProyectoStorage.Nuevo(nombre);
                string origen = Path.Combine(subcarpeta, "origen.sqlite");
                MYGProyectoStorage.Guardar(origen, documento);
                byte[] original = File.ReadAllBytes(origen);
                var colaSqlite = new ArchivoPublicacionSqlitePendiente(Path.Combine(subcarpeta, "sqlite"), Servidor, Usuario);
                var pendiente = colaSqlite.Crear(nombre, "obra", documento, origen);
                var reabierta = new ArchivoPublicacionSqlitePendiente(Path.Combine(subcarpeta, "sqlite"), Servidor, Usuario);
                Exige(reabierta.Consultar() == pendiente && reabierta.Leer(pendiente).Nombre == nombre,
                    "Reabrir el pendiente SQLite debe conservar nombre, UUID y copia congelada.");
                var sqlite = await cliente.CrearSqliteAsync(pendiente.Id, nombre, pendiente.RutaSQLite, "obra", documento.Id);
                var replay = await cliente.CrearSqliteAsync(pendiente.Id, nombre, pendiente.RutaSQLite, "obra", documento.Id);
                var abiertoSqlite = await cliente.AbrirSqliteAsync(pendiente.Id);
                Exige(sqlite.Proyecto.Nombre == nombre && replay.Proyecto.Nombre == nombre
                    && abiertoSqlite.Proyecto.Nombre == nombre && (await cliente.ListarProyectosAsync()).Single().Nombre == nombre
                    && http.Subidas == 1 && File.ReadAllBytes(origen).SequenceEqual(original),
                    "SQLite debe confirmar, reintentar, abrir y listar nombres largos sin reenviar ni cambiar el origen.");
                reabierta.Confirmar(pendiente);

                // El máximo solo cambia para nombres: no amplía documento_id ni acepta controles.
                foreach (string invalido in new[] { new string('N', ClienteSupabase.MaxNombreProyectoNube + 1), "", "Obra\tcontrol" })
                {
                    int peticiones = http.Peticiones;
                    await Rechaza(() => cliente.CrearProyectoAsync(Guid.NewGuid(), invalido, contenido.RootElement, "obra"));
                    await Rechaza(() => cliente.CrearSqliteAsync(Guid.NewGuid(), invalido, pendiente.RutaSQLite, "obra", documento.Id));
                    await Rechaza(() => Task.Run(() => colaJson.Guardar(new(Guid.NewGuid(), invalido, "obra", contenido.RootElement))));
                    await Rechaza(() => Task.Run(() => colaSqlite.Crear(invalido, "obra", documento, origen)));
                    Exige(http.Peticiones == peticiones && colaJson.Consultar() is null && colaSqlite.Consultar() is null,
                        "Un nombre inválido debe rechazarse sin red ni nuevos intentos durables.");
                }
                int anteriores = http.Peticiones;
                await Rechaza(() => cliente.CrearSqliteAsync(Guid.NewGuid(), nombre, pendiente.RutaSQLite, "obra", new string('D', 201)));
                Exige(http.Peticiones == anteriores, "documento_id debe conservar su límite de 200 caracteres.");
                http.NombreRespuesta = new string('N', ClienteSupabase.MaxNombreProyectoNube + 1);
                await Rechaza(() => cliente.ListarProyectosAsync());
                await Rechaza(() => cliente.AbrirSqliteAsync(pendiente.Id));
            }
            Console.WriteLine($"OK Nombres de proyectos: {comprobaciones} comprobaciones de 201/2000 caracteres, Unicode, JSON/SQLite, colas y límites; HTTP simulado, sin red.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static void SugerenciasDeNombre(Action<bool, string> exige)
    {
        var sugerencia = new SugerenciaNombrePublicacionNube();
        string archivoA = Path.Combine(Path.GetTempPath(), "Base completa Áncash.v2.sqlite");
        string archivoB = Path.Combine(Path.GetTempPath(), "Otra base.sqlite");
        string nombre = sugerencia.Actualizar("", false, null, "Obra principal");
        exige(nombre == "Obra principal", "Publicar una obra debe mantener su nombre como sugerencia inicial.");
        nombre = sugerencia.Actualizar(nombre, true, null, "Obra principal");
        exige(nombre == "", "Importar una base sin archivo no debe proponer el nombre de una obra interna.");
        nombre = sugerencia.Actualizar(nombre, true, archivoA, "Primera obra interna");
        exige(nombre == "Base completa Áncash.v2", "La base debe tomar el nombre del archivo sin quitar puntos intermedios.");
        nombre = sugerencia.Actualizar(nombre, true, archivoA, "Segunda obra interna");
        exige(nombre == "Base completa Áncash.v2", "Seleccionar otra obra no debe renombrar la base completa.");
        nombre = sugerencia.Actualizar(nombre, true, archivoB, "Segunda obra interna");
        exige(nombre == "Otra base", "Elegir otro archivo debe actualizar un nombre que sigue siendo automático.");
        nombre = "Nombre pegado y editado por el usuario";
        nombre = sugerencia.Actualizar(nombre, true, archivoA, "Primera obra interna");
        exige(nombre == "Nombre pegado y editado por el usuario", "Cargar un archivo no debe sustituir un nombre editado.");
        nombre = sugerencia.Actualizar(nombre, true, archivoA, "Segunda obra interna");
        exige(nombre == "Nombre pegado y editado por el usuario", "Cambiar la obra principal debe conservar la edición manual.");
        nombre = sugerencia.Actualizar("", true, archivoA, "Segunda obra interna");
        exige(nombre == "Base completa Áncash.v2", "Vaciar el campo debe permitir recuperar la sugerencia del archivo.");
        nombre = sugerencia.Actualizar(nombre, false, archivoA, "Segunda obra interna");
        exige(nombre == "Segunda obra interna", "Al volver a publicar una obra, la sugerencia debe corresponder a esa obra.");
        nombre = sugerencia.Actualizar(nombre, false, archivoA, "Otra obra");
        exige(nombre == "Otra obra", "Cambiar una obra debe actualizar su sugerencia si no hay edición manual.");
        string largo = new('N', ClienteSupabase.MaxNombreProyectoNube);
        exige(sugerencia.Actualizar(largo, true, archivoB, "Otra obra") == largo,
            "La edición manual de hasta 2000 caracteres debe conservarse completa.");
    }

    private sealed class Transporte : HttpMessageHandler
    {
        internal int Peticiones, Subidas;
        internal readonly List<string> NombresEnviados = new();
        internal string? NombreRespuesta;
        private Guid id;
        private string nombre = "", documento = "";
        private object? archivo;
        private static HttpResponseMessage Json(object? valor) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
        private object Descriptor(bool contenido = false)
        {
            var valor = new Dictionary<string, object?>
            {
                ["id"] = id, ["codigo"] = "MYG-NOMBRES", ["nombre"] = NombreRespuesta ?? nombre,
                ["rol"] = "propietario", ["revision"] = 1, ["alcance"] = "obra"
            };
            if (archivo is not null) { valor["documento_id"] = documento; valor["archivo_sqlite"] = archivo; }
            if (contenido) valor["contenido"] = new { version = 2, presupuestos = Array.Empty<object>() };
            return valor;
        }
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            Peticiones++;
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token") return Json(new
            { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600, user = new { id = Usuario } });
            if (ruta.StartsWith("/storage/v1/object/myg-nube-sqlite/", StringComparison.Ordinal))
            { Subidas++; _ = await solicitud.Content!.ReadAsByteArrayAsync(ct); return Json(new { }); }
            using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(ct));
            var p = cuerpo.RootElement;
            switch (ruta.Split('/').Last())
            {
                case "myg_nube_sqlite_capacidades": return Json(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
                case "myg_nube_crear":
                    id = p.GetProperty("p_id").GetGuid(); nombre = p.GetProperty("p_nombre").GetString()!;
                    NombresEnviados.Add(nombre); return Json(Descriptor(contenido: true));
                case "myg_nube_abrir": return Json(Descriptor(contenido: true));
                case "myg_nube_listar": return Json(new[] { Descriptor() });
                case "myg_nube_sqlite_consultar": return Json(archivo is null ? null : Descriptor());
                case "myg_nube_sqlite_crear":
                    id = p.GetProperty("p_id").GetGuid(); nombre = p.GetProperty("p_nombre").GetString()!;
                    documento = p.GetProperty("p_documento_id").GetString()!;
                    archivo = new { ruta = p.GetProperty("p_ruta").GetString(), sha256 = p.GetProperty("p_sha256").GetString(), bytes = p.GetProperty("p_bytes").GetInt64() };
                    NombresEnviados.Add(nombre); return Json(Descriptor());
                case "myg_nube_sqlite_abrir": return Json(Descriptor());
                default: throw new InvalidOperationException("RPC inesperada en pruebas de nombres: " + ruta);
            }
        }
    }
}
