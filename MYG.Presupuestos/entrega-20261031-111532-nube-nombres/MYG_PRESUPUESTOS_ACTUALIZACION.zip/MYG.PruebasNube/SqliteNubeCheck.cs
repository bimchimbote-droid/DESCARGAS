using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;

/// <summary>SQLite real y transporte HTTP simulado. No contacta con Supabase.</summary>
internal static class SqliteNubeCheck
{
    private static readonly Guid Actor = Guid.Parse("bcf5a542-4126-48ec-9ec5-90864f0523f7");
    private static readonly Guid Otro = Guid.Parse("341cc2c1-977f-42d0-a269-d85b8a09cb7b");
    private static readonly Guid Proyecto = Guid.Parse("021e9582-af8a-4fd2-bca5-8979046c3601");
    private const string Documento = "QA-SQLITE-BINARIO";
    private const string Nombre = "Base original sin compresión";
    private const string Bucket = "/storage/v1/object/myg-nube-sqlite/";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-SQLite-Transporte-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            await PublicarGuardarDescargar(carpeta);
            await AckPerdidoYConflicto(carpeta);
            await RenovacionIdentidad(carpeta);
            await DescargasHostiles(carpeta);
            await PermisosYServidorAnterior(carpeta);
            await ErroresStorage(carpeta);
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
        Console.WriteLine($"OK SQLite nativo: 6 grupos y {comprobaciones} comprobaciones de bytes exactos, SHA-256, streams, permisos, renovación, ACK y descargas atómicas; sin red.");
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("SQLite nativo: " + detalle);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException ex) { comprobaciones++; return ex; }
        throw new InvalidOperationException("Se esperaba un rechazo del transporte SQLite.");
    }

    private static string CrearBase(string carpeta, string texto)
    {
        string ruta = Path.Combine(carpeta, Guid.NewGuid().ToString("N") + ".sqlite");
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open();
        using var q = c.CreateCommand();
        q.CommandText = "CREATE TABLE datos(id INTEGER PRIMARY KEY, texto TEXT, binario BLOB); INSERT INTO datos VALUES(1,$texto,$bytes)";
        q.Parameters.AddWithValue("$texto", texto);
        q.Parameters.AddWithValue("$bytes", new byte[] { 0, 1, 2, 255 });
        q.ExecuteNonQuery();
        return ruta;
    }

    private static async Task<ClienteSupabase> Cliente(Transporte http)
    {
        var cliente = new ClienteSupabase("https://sqlite-nativo.supabase.co", "sb_publishable_sqlite_sintetico", http);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        return cliente;
    }

    private static string Hash(byte[] datos) => Convert.ToHexString(SHA256.HashData(datos)).ToLowerInvariant();

    private static async Task PublicarGuardarDescargar(string carpeta)
    {
        string origen = CrearBase(carpeta, "Unicode Áncash 漢字 y contenido exacto");
        byte[] inicial = File.ReadAllBytes(origen);
        using var http = new Transporte(); using var cliente = await Cliente(http);
        var etapas = new List<string>();
        var publicado = await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento,
            progreso: new Progreso(etapas.Add));
        Exige(http.Subidas == 1 && http.CuerposSubidos.Single().SequenceEqual(inicial), "la publicación cambió los bytes originales.");
        Exige(publicado.Archivo.Sha256 == Hash(inicial) && publicado.Archivo.Bytes == inicial.Length
            && publicado.Proyecto.Contenido.ValueKind == JsonValueKind.Undefined, "la respuesta debe contener solo metadatos exactos.");
        Exige(etapas.Any(e => e.StartsWith("Enviando SQLite sin comprimir")) && !etapas.Any(e => e.Contains("Comprimiendo")),
            "el progreso no refleja el stream sin compresión.");
        Exige(http.Metadatos.All(cuerpo => cuerpo.Length < 2048 && !cuerpo.Contains("p_contenido")
            && !cuerpo.Contains("Base64")), "una RPC transportó datos de tablas o Base64 en lugar de metadatos.");
        await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento);
        Exige(http.Subidas == 1, "reintentar publicación confirmada volvió a subir el archivo.");
        string destino = Path.Combine(carpeta, Guid.NewGuid().ToString("N") + ".sqlite");
        await cliente.DescargarSqliteAsync(publicado, destino);
        Exige(File.ReadAllBytes(destino).SequenceEqual(inicial), "la descarga no conserva el archivo SQLite original.");
        string nuevo = CrearBase(carpeta, "Revisión siguiente");
        Guid op = Guid.NewGuid();
        var respuesta = await cliente.GuardarSqliteAsync(Proyecto, op, 1, nuevo);
        Exige(respuesta.Estado == "aplicada" && respuesta.Revision == 2 && respuesta.OperacionId == op
            && http.Subidas == 2 && respuesta.Archivo.Sha256 == Hash(File.ReadAllBytes(nuevo)), "guardar no confirmó la revisión correcta.");
        await cliente.GuardarSqliteAsync(Proyecto, op, 1, nuevo);
        Exige(http.Subidas == 2 && http.GuardadosAplicados == 1, "el replay cambió el UUID o repitió la transferencia.");
        Exige(File.ReadAllBytes(origen).SequenceEqual(inicial), "el transporte modificó el archivo de origen.");
    }

    private static async Task AckPerdidoYConflicto(string carpeta)
    {
        using var http = new Transporte(); using var cliente = await Cliente(http);
        string origen = CrearBase(carpeta, "Revisión inicial ACK");
        await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento);
        string cambio = CrearBase(carpeta, "Revisión aplicada sin respuesta");
        Guid op = Guid.NewGuid(); http.PerderAck = true;
        var error = await Rechaza(() => cliente.GuardarSqliteAsync(Proyecto, op, 1, cambio));
        Exige(error.EsErrorDeConexion && http.Revision == 2, "el escenario no perdió el ACK después de aplicar.");
        int subidas = http.Subidas;
        var replay = await cliente.GuardarSqliteAsync(Proyecto, op, 1, cambio);
        Exige(replay.Estado == "aplicada" && replay.Revision == 2 && http.Subidas == subidas
            && http.GuardadosAplicados == 1, "la recuperación de ACK volvió a subir o aplicar el archivo.");
        string otro = CrearBase(carpeta, "Edición local concurrente");
        var conflicto = await cliente.GuardarSqliteAsync(Proyecto, Guid.NewGuid(), 1, otro);
        Exige(conflicto.Estado == "conflicto" && conflicto.Revision == 2 && http.Subidas == subidas,
            "un conflicto conocido debe resolverse con metadatos sin subir una base inútil.");
    }

    private static async Task RenovacionIdentidad(string carpeta)
    {
        string origen = CrearBase(carpeta, "Renovación exacta");
        using (var http = new Transporte { RenovarSubida = true })
        using (var cliente = await Cliente(http))
        {
            await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento);
            Exige(http.Refrescos == 1 && http.CuerposSubidos.Count == 2
                && http.CuerposSubidos[0].SequenceEqual(http.CuerposSubidos[1]), "renovar401 no reabrió el mismo stream inmutable.");
        }
        using (var http = new Transporte { RenovarSubida = true, CambiarIdentidad = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento));
            Exige(error.NecesitaIniciarSesion && http.CuerposSubidos.Count == 1 && http.Actual is null,
                "el cambio de cuenta reenvió o confirmó datos con otra identidad.");
        }
    }

    private static async Task DescargasHostiles(string carpeta)
    {
        using var http = new Transporte(); using var cliente = await Cliente(http);
        string origen = CrearBase(carpeta, "Descarga íntegra");
        var publicado = await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento);
        string destino = CrearBase(carpeta, "Destino que debe sobrevivir");
        byte[] previo = File.ReadAllBytes(destino);
        http.CorromperDescarga = true;
        await Rechaza(() => cliente.DescargarSqliteAsync(publicado, destino));
        Exige(File.ReadAllBytes(destino).SequenceEqual(previo) && !Directory.EnumerateFiles(carpeta, ".myg-descarga-*").Any(),
            "una descarga corrupta reemplazó destino o dejó un temporal.");
        http.CorromperDescarga = false; http.ComprimirDescarga = true;
        await Rechaza(() => cliente.DescargarSqliteAsync(publicado, destino));
        Exige(File.ReadAllBytes(destino).SequenceEqual(previo), "una respuesta codificada como gzip se aceptó como SQLite original.");
        http.ComprimirDescarga = false;
        foreach (string ruta in new[] { "../otra.sqlite", Actor + "/" + Guid.NewGuid().ToString("N") + "/" + publicado.Archivo.Sha256 + ".sqlite" })
        {
            int descargas = http.Descargas;
            await Rechaza(() => cliente.DescargarSqliteAsync(publicado with { Archivo = publicado.Archivo with { Ruta = ruta } }, destino));
            Exige(http.Descargas == descargas, "la ruta hostil se envió al servidor.");
        }
        string invalido = Path.Combine(carpeta, "cabecera-no-sqlite.bin");
        File.WriteAllText(invalido, new string('x', 200));
        int llamadas = http.Metadatos.Count;
        await Rechaza(() => cliente.CrearSqliteAsync(Guid.NewGuid(), Nombre, invalido, "obra", Documento));
        Exige(http.Metadatos.Count == llamadas, "un archivo sin cabecera SQLite llegó a las RPC.");
    }

    private static async Task PermisosYServidorAnterior(string carpeta)
    {
        string origen = CrearBase(carpeta, "Permisos");
        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        {
            await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento);
            http.Restringido = true;
            int subidas = http.Subidas;
            var error = await Rechaza(() => cliente.GuardarSqliteAsync(Proyecto, Guid.NewGuid(), 1, origen));
            Exige(error.AccesoDenegado && http.Subidas == subidas && http.GuardadosAplicados == 0,
                "un editor restringido pudo reemplazar una base opaca completa.");
        }
        using (var http = new Transporte { ServidorAnterior = true })
        using (var cliente = await Cliente(http))
        {
            Exige(await cliente.ConsultarSqliteAsync(Proyecto) is null, "el servidor anterior debe conservar lectura legada.");
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento));
            Exige(error.Message.Contains("20261030_archivos_sqlite.sql") && http.Subidas == 0,
                "publicar recurrió a compresión/JSON en vez de exigir la migración.");
        }
    }

    private static async Task ErroresStorage(string carpeta)
    {
        const string privado = "archivo_token_url_privados_no_mostrar";
        const string referencia = "e16529aa-08d8-4c83-8d88-58309d977594";
        string origen = CrearBase(carpeta, "Errores Storage sin perder la copia local");
        byte[] original = File.ReadAllBytes(origen);
        foreach (var caso in new[]
        {
            (Campo: "code", Valor: "AccessDenied", Codigo: "AccessDenied", Texto: "políticas del bucket"),
            (Campo: "error", Valor: "Unauthorized", Codigo: "AccessDenied", Texto: "políticas del bucket"),
            (Campo: "code", Valor: "42501", Codigo: "42501", Texto: "permiso"),
            (Campo: "code", Valor: "InvalidMimeType", Codigo: "InvalidMimeType", Texto: "tipos MIME"),
            (Campo: "error", Valor: "invalid_mime_type", Codigo: "InvalidMimeType", Texto: "tipos MIME"),
            (Campo: "code", Valor: "EntityTooLarge", Codigo: "EntityTooLarge", Texto: "límite global"),
            (Campo: "error", Valor: "Payload too large", Codigo: "EntityTooLarge", Texto: "límite global"),
            (Campo: "code", Valor: "NoSuchBucket", Codigo: "NoSuchBucket", Texto: "no encontró el bucket"),
            (Campo: "error", Valor: "Bucket not found", Codigo: "NoSuchBucket", Texto: "no encontró el bucket"),
            (Campo: "code", Valor: "InvalidKey", Codigo: "InvalidKey", Texto: "referencia del archivo")
        })
        {
            using var http = new Transporte(); using var cliente = await Cliente(http);
            string cuerpo = JsonSerializer.Serialize(new Dictionary<string, string>
            {
                [caso.Campo] = caso.Valor, ["message"] = privado, ["access_token"] = privado,
                ["url"] = "https://" + privado, ["filename"] = origen
            });
            var flujo = new FlujoErrorStorage(Encoding.UTF8.GetBytes(cuerpo));
            http.RespuestaSubida = () => ErrorStorage(flujo, referencia);
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento));
            Exige(error.Codigo == caso.Codigo && error.Message.Contains(caso.Texto, StringComparison.Ordinal)
                && error.AccesoDenegado == (caso.Codigo is "AccessDenied" or "42501")
                && !error.EsErrorDeConexion && !error.NecesitaIniciarSesion,
                "el error Storage perdió su código, diagnóstico o flags: " + caso.Valor);
            Exige(error.Message.Contains("HTTP 400") && error.Message.Contains(referencia)
                && error.Message.Contains("subida del archivo SQLite")
                && !error.Message.Contains(privado) && !error.Message.Contains(origen)
                && !error.Message.Contains("https://"), "el diagnóstico filtró datos o perdió fase/referencia.");
            Exige(flujo.BytesLeidos == Encoding.UTF8.GetByteCount(cuerpo) && http.Actual is null
                && http.CuerposSubidos.Count == 1 && cliente.SesionIniciada
                && File.ReadAllBytes(origen).SequenceEqual(original),
                "el error se releyó, confirmó datos, reintentó o modificó la copia local.");
        }

        // JSON inválido, campos repetidos, códigos desconocidos y cuerpos excesivos
        // nunca se confunden con un duplicado ni publican contenido remoto.
        foreach (string cuerpo in new[]
        {
            "<html>" + privado + "</html>", "{\"code\":", "[]",
            JsonSerializer.Serialize(new { code = privado, error = "Duplicate", message = privado }),
            "{\"code\":\"AccessDenied\",\"code\":\"Duplicate\"}",
            JsonSerializer.Serialize(new { code = "InvalidMimeType", message = new string('x', 70 * 1024) + privado })
        })
        {
            using var http = new Transporte(); using var cliente = await Cliente(http);
            var flujo = new FlujoErrorStorage(Encoding.UTF8.GetBytes(cuerpo));
            http.RespuestaSubida = () => ErrorStorage(flujo, referencia);
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento));
            Exige(error.Codigo is null && !error.AccesoDenegado && !error.NecesitaIniciarSesion
                && error.Message.Contains("HTTP 400") && error.Message.Contains("subida del archivo SQLite")
                && error.Message.Contains(referencia) && !error.Message.Contains(privado)
                && !error.Message.Contains("tipos MIME") && !error.Message.Contains("políticas del bucket"),
                "un error desconocido/excesivo no quedó genérico y seguro.");
            Exige(flujo.BytesLeidos <= 64 * 1024 + 1 && http.Descargas == 0
                && http.Actual is null && http.CuerposSubidos.Count == 1,
                "se leyó un error sin límite o se confirmó/descargó como duplicado.");
        }

        foreach (int estado in new[] { 503, 520 })
        {
            using var http = new Transporte(); using var cliente = await Cliente(http);
            http.RespuestaSubida = () =>
            {
                var respuesta = ErrorStorage(new FlujoErrorStorage(Encoding.UTF8.GetBytes(
                    JsonSerializer.Serialize(new { code = privado, message = privado }))), referencia);
                respuesta.StatusCode = (HttpStatusCode)estado;
                return respuesta;
            };
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento));
            Exige(error.EsErrorDeConexion && error.Codigo is null && !error.AccesoDenegado
                && !error.NecesitaIniciarSesion && error.Message.Contains("HTTP " + estado)
                && error.Message.Contains(referencia) && error.Message.Contains("subida del archivo SQLite")
                && !error.Message.Contains(privado) && cliente.SesionIniciada && http.Actual is null,
                "la copia acotada perdió el estado transitorio, la referencia o la sesión.");
        }
        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        {
            var flujo = new FlujoErrorStorage("{\"code\":\"InvalidMimeType\"}"u8.ToArray());
            http.RespuestaSubida = () =>
            {
                var respuesta = ErrorStorage(flujo, referencia);
                respuesta.Content.Headers.ContentLength = 64 * 1024 + 1;
                return respuesta;
            };
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento));
            Exige(flujo.BytesLeidos == 0 && error.Codigo is null && error.Message.Contains("HTTP 400")
                && error.Message.Contains(referencia) && !error.Message.Contains("tipos MIME") && http.Actual is null,
                "se leyó/clasificó un cuerpo con longitud declarada excesiva.");
        }

        foreach (var duplicado in new[] { (Campo: "error", Valor: "Duplicate"),
            (Campo: "code", Valor: "ResourceAlreadyExists"), (Campo: "code", Valor: "KeyAlreadyExists") })
        {
            using var http = new Transporte(); using var cliente = await Cliente(http);
            string ruta = Actor + "/" + Proyecto.ToString("N") + "/" + Hash(original) + ".sqlite";
            http.Objetos[ruta] = original;
            var flujo = new FlujoErrorStorage(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(
                new Dictionary<string, string> { [duplicado.Campo] = duplicado.Valor, ["message"] = privado })));
            http.RespuestaSubida = () => ErrorStorage(flujo, referencia);
            await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento);
            Exige(http.Descargas == 1 && http.Actual is not null,
                "el duplicado HTTP400 no verificó bytes/SHA antes de confirmar.");
            http.Actual = null; http.CorromperDescarga = true;
            // Reabrir el stream para el segundo POST, sin habilitar Seek.
            http.RespuestaSubida = () => ErrorStorage(new FlujoErrorStorage(Encoding.UTF8.GetBytes(
                JsonSerializer.Serialize(new { code = "ResourceAlreadyExists" }))), referencia);
            await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento));
            Exige(http.Actual is null && http.Descargas == 2,
                "un duplicado con bytes distintos se confirmó sin comprobar integridad.");
        }

        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        {
            var publicado = await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento);
            http.RespuestaDescarga = () => ErrorStorage(new FlujoErrorStorage(Encoding.UTF8.GetBytes(
                "{\"code\":\"NoSuchBucket\",\"message\":\"" + privado + "\"}")), referencia);
            string destino = Path.Combine(carpeta, "descarga-error.sqlite");
            var error = await Rechaza(() => cliente.DescargarSqliteAsync(publicado, destino));
            Exige(error.Codigo == "NoSuchBucket" && error.Message.Contains("descarga del archivo SQLite")
                && !File.Exists(destino), "el error de descarga perdió su fase o creó un destino sin verificar.");
        }

        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        using (var cancelacion = new CancellationTokenSource())
        {
            var flujo = new FlujoErrorStorage("{\"code\":\"EntityTooLarge\"}"u8.ToArray(), cancelacion.Cancel);
            http.RespuestaSubida = () => ErrorStorage(flujo, referencia);
            bool cancelado = false;
            try { await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento, cancelacion.Token); }
            catch (OperationCanceledException) when (cancelacion.IsCancellationRequested) { cancelado = true; }
            Exige(cancelado && http.Actual is null && http.Descargas == 0,
                "la cancelación leyendo un error fue ocultada o permitió confirmar.");
        }
    }

    private static HttpResponseMessage ErrorStorage(FlujoErrorStorage flujo, string referencia)
    {
        var respuesta = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StreamContent(flujo) };
        respuesta.Headers.TryAddWithoutValidation("sb-request-id", referencia);
        return respuesta;
    }

    private sealed class FlujoErrorStorage(byte[] datos, Action? antesLeer = null) : Stream
    {
        private readonly MemoryStream entrada = new(datos);
        internal int BytesLeidos { get; private set; }
        public override bool CanRead => entrada.CanRead;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
        public override int Read(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken ct = default)
        {
            antesLeer?.Invoke(); ct.ThrowIfCancellationRequested();
            int leidos = entrada.Read(buffer.Span); BytesLeidos += leidos;
            return ValueTask.FromResult(leidos);
        }
        public override void Flush() => throw new NotSupportedException();
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        protected override void Dispose(bool disposing) { if (disposing) entrada.Dispose(); base.Dispose(disposing); }
    }

    private sealed class Progreso(Action<string> informar) : IProgress<string>
    { public void Report(string value) => informar(value); }

    private sealed class Transporte : HttpMessageHandler
    {
        internal readonly Dictionary<string, byte[]> Objetos = new(StringComparer.Ordinal);
        internal readonly List<string> Metadatos = new();
        internal readonly List<byte[]> CuerposSubidos = new();
        private readonly Dictionary<Guid, (long Base, ArchivoSqliteNube Archivo)> operaciones = new();
        internal ArchivoSqliteNube? Actual;
        private ArchivoSqliteNube? inicial;
        internal long Revision = 1;
        internal int Subidas, Descargas, GuardadosAplicados, Refrescos;
        internal bool PerderAck, RenovarSubida, CambiarIdentidad, Restringido, ServidorAnterior, CorromperDescarga, ComprimirDescarga;
        private string alcance = "obra";
        internal Func<HttpResponseMessage>? RespuestaSubida, RespuestaDescarga;

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token")
            {
                bool refresco = solicitud.RequestUri.Query.Contains("refresh_token");
                if (refresco) Refrescos++;
                return Json(new { access_token = refresco ? "acceso_renovado" : "acceso_original", refresh_token = "refresco_sintetico",
                    expires_in = 3600, user = new { id = refresco && CambiarIdentidad ? Otro : Actor } });
            }
            Exige(solicitud.Headers.Authorization is not null, "una transferencia no llevaba la sesión autenticada.");
            Exige(solicitud.Headers.Contains("apikey"), "faltó la clave publicable del proyecto.");
            if (ruta.StartsWith(Bucket, StringComparison.Ordinal))
            {
                string objeto = ruta[Bucket.Length..];
                if (solicitud.Method == HttpMethod.Post)
                {
                    Exige(solicitud.Content!.Headers.ContentType?.MediaType == "application/vnd.sqlite3"
                        && solicitud.Content.Headers.ContentEncoding.Count == 0
                        && solicitud.Headers.GetValues("x-upsert").Single() == "false", "el stream se comprimió o permitió sobrescribir.");
                    using var memoria = new MemoryStream(); await solicitud.Content.CopyToAsync(memoria, ct);
                    byte[] bytes = memoria.ToArray(); CuerposSubidos.Add(bytes);
                    Exige(bytes.AsSpan(0, 16).SequenceEqual("SQLite format 3\0"u8), "el cuerpo de Storage no es SQLite binario.");
                    Exige(objeto == Actor + "/" + Proyecto.ToString("N") + "/" + Hash(bytes) + ".sqlite", "la ruta no está aislada por cuenta/proyecto/hash.");
                    if (RenovarSubida) { RenovarSubida = false; return Json(new { }, HttpStatusCode.Unauthorized); }
                    if (RespuestaSubida is not null) return RespuestaSubida();
                    if (!Objetos.TryAdd(objeto, bytes)) return Json(new { }, HttpStatusCode.Conflict);
                    Subidas++; return Json(new { Key = objeto });
                }
                Descargas++;
                if (RespuestaDescarga is not null) return RespuestaDescarga();
                byte[] contenido = Objetos[objeto].ToArray();
                if (CorromperDescarga) contenido[^1] ^= 0xff;
                var respuesta = new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(contenido) };
                if (ComprimirDescarga) respuesta.Content.Headers.ContentEncoding.Add("gzip");
                return respuesta;
            }
            if (!ruta.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal)) throw new InvalidOperationException("Solicitud inesperada: " + ruta);
            string cuerpo = await solicitud.Content!.ReadAsStringAsync(ct); Metadatos.Add(cuerpo);
            using var parametros = JsonDocument.Parse(cuerpo); var p = parametros.RootElement;
            if (ruta.EndsWith("myg_nube_sqlite_capacidades"))
                return ServidorAnterior ? Json(new { code = "PGRST202" }, HttpStatusCode.NotFound)
                    : Json(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
            if (ruta.EndsWith("myg_nube_sqlite_consultar")) return Actual is null ? Json<object?>(null) : Descriptor(Actual, Revision);
            if (ruta.EndsWith("myg_nube_sqlite_crear"))
            {
                var archivo = DeParametros(p); alcance = p.GetProperty("p_alcance").GetString()!;
                Exige(p.GetProperty("p_documento_id").GetString() == Documento && p.GetProperty("p_nombre").GetString() == Nombre,
                    "la publicación alteró la identidad del documento.");
                Exige(Objetos.ContainsKey(archivo.Ruta), "se confirmó un objeto sin subir.");
                if (inicial is not null) Exige(inicial == archivo, "reintentar creación cambió el archivo inmutable.");
                inicial ??= archivo; Actual ??= archivo;
                return Descriptor(inicial, 1);
            }
            if (ruta.EndsWith("myg_nube_sqlite_abrir")) return Descriptor(Actual!, Revision);
            if (ruta.EndsWith("myg_nube_sqlite_guardar"))
            {
                Guid operacion = p.GetProperty("p_operacion").GetGuid();
                long revision = p.GetProperty("p_revision").GetInt64();
                var archivo = DeParametros(p);
                if (operaciones.TryGetValue(operacion, out var anterior))
                {
                    Exige(anterior.Base == revision && anterior.Archivo == archivo, "el replay cambió el UUID/cuerpo congelado.");
                    return Guardado("aplicada", revision + 1, operacion, archivo);
                }
                if (revision != Revision) return Guardado("conflicto", Revision, operacion, Actual!);
                Exige(Objetos.ContainsKey(archivo.Ruta), "se guardó un objeto que no existe en Storage.");
                operaciones.Add(operacion, (revision, archivo)); Actual = archivo; Revision++; GuardadosAplicados++;
                if (PerderAck) { PerderAck = false; throw new HttpRequestException("ACK perdido sintético"); }
                return Guardado("aplicada", Revision, operacion, archivo);
            }
            throw new InvalidOperationException("RPC inesperada: " + ruta);
        }

        private static ArchivoSqliteNube DeParametros(JsonElement p) =>
            new(p.GetProperty("p_ruta").GetString()!, p.GetProperty("p_sha256").GetString()!, p.GetProperty("p_bytes").GetInt64());
        private HttpResponseMessage Descriptor(ArchivoSqliteNube archivo, long revision) => Json(new
        {
            id = Proyecto, codigo = "MYG-SQLITE-001", nombre = Nombre, rol = Restringido ? "editor" : "propietario", revision, alcance,
            documento_id = Documento,
            permisos_modulos = new { acu = !Restringido, especificaciones = true, metrados_excel = true },
            archivo_sqlite = new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes }
        });
        private static HttpResponseMessage Guardado(string estado, long revision, Guid operacion, ArchivoSqliteNube archivo) => Json(new
        { estado, revision, operacion_id = operacion, archivo_sqlite = new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes } });
        private static HttpResponseMessage Json<T>(T valor, HttpStatusCode estado = HttpStatusCode.OK) =>
            new(estado) { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
