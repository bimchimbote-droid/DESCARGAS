#!/usr/bin/env python3
"""Regresión NUEVA del protocolo Gzip, solo en Docker desechable.

PostgreSQL y PostgREST son reales. Storage se representa mediante archivos locales
y su tabla de metadatos con RLS real; no se ejecuta el servicio Supabase Storage.
No se conecta a una base remota ni se vuelven a ejecutar los benchmarks JSONB.
"""
import argparse
import base64
import gzip
import hashlib
import hmac
import io
import json
from pathlib import Path
import random
import re
import signal
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid

REPO = Path(__file__).resolve().parents[2]
POSTGRES = 'postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
POSTGREST = 'postgrest/postgrest:v16.5@sha256:1347d7552b88f17832912c06afbf7c43209af6eeeb60834b04aae12c9bd9d5cc'
SECRET = b'myg_gzip_synthetic_test_secret_not_a_real_credential'
OWNER = '00000000-0000-0000-0000-000000000001'
EDITOR = '00000000-0000-0000-0000-000000000003'
READER = '00000000-0000-0000-0000-000000000004'
OTHER = '00000000-0000-0000-0000-000000000007'
CHUNK = 8 * 1024 * 1024


def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def literal(value):
    return "'" + value.replace("'", "''") + "'"


def token(user):
    def b64(value):
        return base64.urlsafe_b64encode(value).rstrip(b'=')
    prefix = b64(b'{"alg":"HS256","typ":"JWT"}') + b'.' + b64(encode({
        'role': 'authenticated', 'sub': user, 'exp': int(time.time()) + 3600}))
    return (prefix + b'.' + b64(hmac.new(SECRET, prefix, hashlib.sha256).digest())).decode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--paquetes', type=Path, required=True,
                        help='Fixtures existentes; este runner no vuelve a compilarlos')
    parser.add_argument('--resultados', type=Path, required=True)
    parser.add_argument('--sin-carga-grande', action='store_true',
                        help='Solo para depurar el runner antes del ensayo final de 200 MiB')
    parser.add_argument('--solo-adicionales', action='store_true',
                        help='Omitir matrices y carga grande ya aprobadas; comprobar bloqueo, textos y adaptación del trigger')
    parser.add_argument('--solo-trigger', action='store_true',
                        help='Solo compatibilidad UPDATE OF del trigger real observado; sin API, matriz ni carga grande')
    parser.add_argument('--solo-instalador-saltos', action='store_true',
                        help='Solo instalación LF/CRLF y conservación de cinco funciones; sin API ni cargas grandes')
    parser.add_argument('--definiciones-servidor', type=Path,
                        help='JSON local opcional con las cinco definiciones exportadas; no se publica su contenido')
    parser.add_argument('--instalador-anterior', type=Path,
                        help='SQL anterior local para reproducir el rechazo CRLF antes de comprobar la corrección')
    args = parser.parse_args()
    if args.solo_instalador_saltos and not args.instalador_anterior:
        parser.error('--solo-instalador-saltos requiere --instalador-anterior')
    args.resultados.mkdir(parents=True, exist_ok=True)
    prefix = 'myg-gzip-' + uuid.uuid4().hex[:10]
    network, database, api = [prefix + '-' + name for name in ('red', 'pg', 'api')]
    containers = []
    created_network = False
    checks, requests, blob_operations = [], [], []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    result = {'status': 'interrupted'}
    log = (args.resultados / 'preparacion.log').open('w')

    def interrupted(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)

    def require(condition, detail):
        if not condition:
            raise AssertionError(detail)
        checks.append(detail)

    def run(*command, check=True, input_text=None):
        completed = subprocess.run(command, input=input_text, text=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log.write(completed.stdout)
        log.flush()
        if check and completed.returncode:
            raise RuntimeError(f'{command[0]} terminó con {completed.returncode}: {completed.stdout[-2400:]}')
        return completed

    def sql(query, check=True):
        return run('docker', 'exec', '-i', '-u', 'postgres', database, 'psql', '-X', '-qAt',
                   '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose',
                   '-v', 'MYG_PRUEBAS_DESECHABLES=1', input_text=query, check=check).stdout.strip()

    def sql_file(path, check=True):
        return run('docker', 'exec', '-u', 'postgres', database, 'psql', '-X', '-qAt',
                   '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose',
                   '-v', 'MYG_PRUEBAS_DESECHABLES=1', '-f', path, check=check)

    def sql_as(user, query, check=True):
        return sql('SET ROLE authenticated; SET request.jwt.claims=' + literal(encode({'sub': user}).decode())
                   + '; SET request.jwt.claim.sub=' + literal(user) + '; ' + query, check=check)

    def probar_instalador_saltos():
        signatures = [
            'myg_nube_privado.snapshot(uuid,uuid)',
            'public.myg_nube_capacidades()',
            'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)',
            'public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)',
            'myg_nube_privado.reconstruir_revision(uuid,bigint)']
        def canonical_signature(value):
            value = value.replace(' ', '')
            return value if '.' in value.split('(', 1)[0] else 'public.' + value

        if args.definiciones_servidor:
            exported = json.loads(args.definiciones_servidor.read_text())
            definitions = {row['firma']: row['definicion'] for row in exported}
            require(set(definitions) == set(signatures),
                    'El JSON local aporta exactamente las cinco definiciones necesarias')
        else:
            exported = json.loads(sql("SELECT jsonb_agg(jsonb_build_object('firma',p.oid::regprocedure::text,"
                "'definicion',pg_get_functiondef(p.oid))) FROM pg_proc p WHERE p.oid IN ("
                + ','.join(literal(s) + '::regprocedure' for s in signatures) + ');'))
            # regprocedure puede añadir espacios; usar las firmas canónicas del runner.
            definitions = {signature: next(row['definicion'] for row in exported
                if canonical_signature(row['firma']) == signature) for signature in signatures}

        def source_body(definition):
            found = re.search(r'AS (\$[A-Za-z_0-9]*\$)([\s\S]*)\1', definition)
            if not found:
                raise AssertionError('La definición no usa el formato pg_get_functiondef esperado')
            return found.group(2)

        def db_sql(dbname, query, check=True):
            # -c envía la cadena completa tal como la recibe SQL Editor. No deja
            # que un lector de líneas de psql modifique el CRLF del archivo.
            return run('docker', 'exec', '-u', 'postgres', database, 'psql', '-X', '-qAt',
                       '-d', dbname, '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose',
                       '-c', query, check=check)

        def db_value(dbname, query):
            return db_sql(dbname, query).stdout.strip()

        def clone(label, body_ending):
            dbname = 'qa_saltos_' + label
            run('docker', 'exec', '-u', 'postgres', database, 'createdb',
                '--template=postgres', dbname)
            for signature in signatures:
                definition = definitions[signature].replace('\r\n', '\n')
                if body_ending == 'CRLF':
                    definition = definition.replace('\n', '\r\n')
                db_sql(dbname, definition + ';')
            db_sql(dbname, """
                CREATE FUNCTION myg_nube_privado.validar_paquete_archivos() RETURNS trigger
                LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$ BEGIN RETURN NEW; END $$;
                COMMENT ON FUNCTION myg_nube_privado.validar_paquete_archivos()
                    IS 'STUB SINTETICO para compatibilidad de saltos; no es el validador productivo';
                CREATE TRIGGER myg_nube_validar_adjuntos BEFORE INSERT OR UPDATE OF contenido,alcance
                    ON public.myg_nube_proyectos FOR EACH ROW
                    EXECUTE FUNCTION myg_nube_privado.validar_paquete_archivos();
                COMMENT ON TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos
                    IS 'UPDATE OF sintetico con columnas6/7';
            """)
            return dbname

        selected = ','.join(literal(s) + '::regprocedure' for s in signatures)
        functions_query = ("SELECT jsonb_agg(jsonb_build_object('firma',p.oid::regprocedure::text,"
            "'atributos',to_jsonb(p)-'prosrc','cuerpo',p.prosrc,"
            "'comentario',obj_description(p.oid,'pg_proc')) ORDER BY p.oid) FROM pg_proc p WHERE p.oid IN ("
            + selected + ');')
        fingerprint_query = """
            SELECT md5(jsonb_build_object(
                'funciones',(SELECT jsonb_agg(to_jsonb(p) ORDER BY p.oid) FROM pg_proc p
                    WHERE p.pronamespace IN ('public'::regnamespace,'myg_nube_privado'::regnamespace)),
                'triggers',(SELECT jsonb_agg(to_jsonb(t) ORDER BY t.oid) FROM pg_trigger t
                    WHERE t.tgrelid='public.myg_nube_proyectos'::regclass),
                'columnas',(SELECT jsonb_agg(to_jsonb(a) ORDER BY attnum) FROM pg_attribute a
                    WHERE a.attrelid='public.myg_nube_proyectos'::regclass AND a.attnum>0),
                'proyectos',(SELECT jsonb_agg(to_jsonb(p) ORDER BY id) FROM public.myg_nube_proyectos p),
                'historial',(SELECT jsonb_agg(to_jsonb(h) ORDER BY proyecto_id,revision) FROM public.myg_nube_historial h),
                'objetos',(SELECT jsonb_agg(to_jsonb(o) ORDER BY id) FROM storage.objects o),
                'buckets',(SELECT jsonb_agg(to_jsonb(b) ORDER BY id) FROM storage.buckets b)
            )::text);
        """

        old_bytes = args.instalador_anterior.read_bytes()
        old_lf = old_bytes.decode('utf-8-sig').replace('\r\n', '\n')
        corrected_bytes = (REPO / 'supabase/migraciones/20261028_publicacion_comprimida.sql').read_bytes()
        corrected_lf = corrected_bytes.decode('utf-8-sig').replace('\r\n', '\n')
        reproduction = clone('repro_anterior', 'CRLF')
        before = db_value(reproduction, fingerprint_query)
        rejected = db_sql(reproduction, old_lf.replace('\n', '\r\n'), check=False)
        require(rejected.returncode != 0 and 'snapshot(uuid,uuid)' in rejected.stdout
                and 'personalización desconocida' in rejected.stdout,
                'El instalador anterior CRLF reproduce exactamente el rechazo de snapshot observado')
        require(db_value(reproduction, fingerprint_query) == before,
                'El rechazo anterior revierte íntegramente funciones, trigger, columnas, proyectos y Storage')
        accepted_lf = db_sql(reproduction, old_lf)
        require('PUBLICACION_COMPRIMIDA_INSTALADA' in accepted_lf.stdout,
                'Control: el mismo instalador anterior en LF acepta los mismos cuerpos CRLF')

        matrix = []
        expected_hashes = {}
        for body_ending in ('LF', 'CRLF'):
            for script_ending in ('LF', 'CRLF'):
                label = body_ending.lower() + '_' + script_ending.lower()
                dbname = clone(label, body_ending)
                before_functions = json.loads(db_value(dbname, functions_query))
                expected_bodies = {}
                for signature in signatures:
                    original = source_body(definitions[signature]).replace('\r\n', '\n')
                    if signature.startswith('myg_nube_privado.snapshot('):
                        patched = original.replace('where p.id = p_id;',
                            'where p.id = p_id and myg_nube_privado.exigir_paquete_json(p.id);')
                    elif signature == 'public.myg_nube_capacidades()':
                        patched = original.replace("'publicacion_ligera',1)",
                            "'publicacion_ligera',1,'publicacion_comprimida',1)")
                    else:
                        patched = original.replace('begin\n',
                            'begin\n    perform myg_nube_privado.exigir_paquete_json(p_id);\n', 1)
                    require(patched != original, 'El cuerpo esperado añade exclusivamente la guarda/capacidad: '
                            + signature + ' (' + label + ')')
                    expected_bodies[signature.replace(' ', '')] = patched
                    expected_hashes[signature] = hashlib.md5(original.encode()).hexdigest()
                script = corrected_lf if script_ending == 'LF' else corrected_lf.replace('\n', '\r\n')
                applied = db_sql(dbname, script)
                require('PUBLICACION_COMPRIMIDA_INSTALADA' in applied.stdout,
                        'Instalación nueva correcta: script' + script_ending + '/funciones' + body_ending)
                after_functions = json.loads(db_value(dbname, functions_query))
                require(len(before_functions) == len(after_functions) == 5,
                        'Las cinco funciones conservan identidad en ' + label)
                for old, new in zip(before_functions, after_functions):
                    signature = canonical_signature(new['firma'])
                    require(old['atributos'] == new['atributos'] and old['comentario'] == new['comentario'],
                            'OID, propietario, ACL, seguridad, timeout y atributos intactos: ' + signature + ' (' + label + ')')
                    require(new['cuerpo'].replace('\r\n', '\n') == expected_bodies[signature],
                            'Cuerpo íntegro más cambio previsto únicamente: ' + signature + ' (' + label + ')')
                    require(('\r\n' in new['cuerpo']) == (body_ending == 'CRLF'),
                            'Se conservan los finales originales: ' + signature + ' (' + label + ')')
                require(db_value(dbname, "SELECT tgattr='6 7'::int2vector AND tgtype=23 AND tgnargs=0 "
                    "AND tgenabled='O' AND tgqual IS NOT NULL FROM pg_trigger WHERE "
                    "tgrelid='public.myg_nube_proyectos'::regclass AND tgname='myg_nube_validar_adjuntos';") == 't',
                    'UPDATE OF6/7 permanece protegido y conservado en ' + label)
                repeat_before = db_value(dbname, functions_query)
                # Repetir también con el otro tipo de archivo cubre el despliegue
                # desde Windows sobre una instalación realizada desde Linux y viceversa.
                for repeat_script in (corrected_lf, corrected_lf.replace('\n', '\r\n')):
                    db_sql(dbname, repeat_script)
                    require(db_value(dbname, functions_query) == repeat_before,
                            'Reinstalación idempotente sin cambiar OID/cuerpos/atributos en ' + label)
                matrix.append({'script': script_ending, 'funciones': body_ending, 'resultado': 'aprobado'})

        changes = {
            signatures[0]: ('where p.id = p_id;', 'where p.id = p_id and false;'),
            signatures[1]: ("'max_contenido_mib',300", "'max_contenido_mib',299"),
            signatures[2]: ('p_revision < 1', 'p_revision < 2'),
            signatures[3]: ('p_revision<1', 'p_revision<2'),
            signatures[4]: ('return v_contenido;', "return '{}'::jsonb;")}
        for index, signature in enumerate(signatures):
            dbname = clone('rechazo_' + str(index), 'CRLF')
            definition = definitions[signature].replace('\r\n', '\n')
            old, new = changes[signature]
            require(old in definition, 'La mutación negativa encuentra su expresión: ' + signature)
            changed = definition.replace(old, new, 1).replace('\n', '\r\n')
            db_sql(dbname, changed + ';')
            before = db_value(dbname, fingerprint_query)
            rejected = db_sql(dbname, corrected_lf.replace('\n', '\r\n'), check=False)
            require(rejected.returncode != 0 and 'personalización desconocida' in rejected.stdout,
                    'Un cambio real de lógica sigue rechazándose: ' + signature)
            require(db_value(dbname, fingerprint_query) == before,
                    'El rechazo de lógica desconocida conserva la transacción completa: ' + signature)

        return {'status': 'passed', 'checks_count': len(checks), 'http_requests_count': 0,
                'old_crlf_failure_reproduced': True, 'old_lf_control_passed': True,
                'line_ending_matrix': matrix, 'original_body_md5_lf': expected_hashes,
                'unknown_logic_rejections': len(signatures), 'large_repeated': False,
                'permission_matrix_repeated': False, 'csharp_builds_repeated': False,
                'previous_installer_sha256': hashlib.sha256(old_bytes).hexdigest(),
                'corrected_installer_sha256': hashlib.sha256(corrected_bytes).hexdigest(),
                'scope': 'PostgreSQL17 real. Cinco definiciones SQL de entrada local, sin datos de proyectos. '
                         'Trigger de adjuntos sintético UPDATE OF6/7. No ejecuta API/Storage ni benchmarks grandes.'}

    def probar_trigger_update_of():
        # El cuerpo es un contador de laboratorio, NO el validador de producción.
        # Se reproduce únicamente su identidad/estructura observada: tipo23,
        # UPDATE OF columnas6/7, cero argumentos, sin WHEN, habilitadoO.
        sql("""
            CREATE TABLE qa.llamadas_trigger(id bigint GENERATED ALWAYS AS IDENTITY,
                proyecto_id uuid NOT NULL, operacion text NOT NULL);
            CREATE FUNCTION myg_nube_privado.validar_paquete_archivos() RETURNS trigger
            LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
            BEGIN INSERT INTO qa.llamadas_trigger(proyecto_id,operacion) VALUES(NEW.id,TG_OP); RETURN NEW; END $$;
            REVOKE ALL ON FUNCTION myg_nube_privado.validar_paquete_archivos() FROM PUBLIC;
            GRANT EXECUTE ON FUNCTION myg_nube_privado.validar_paquete_archivos() TO anon;
            COMMENT ON FUNCTION myg_nube_privado.validar_paquete_archivos()
                IS 'STUB SINTÉTICO: contador; no valida adjuntos productivos';
            CREATE FUNCTION qa.trigger_ajeno() RETURNS trigger LANGUAGE plpgsql
                AS $$ BEGIN RETURN NEW; END $$;
            CREATE TRIGGER myg_nube_validar_adjuntos BEFORE INSERT OR UPDATE OF contenido,alcance
                ON public.myg_nube_proyectos FOR EACH ROW
                EXECUTE FUNCTION myg_nube_privado.validar_paquete_archivos();
            COMMENT ON TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos
                IS 'Comentario sintético UPDATE OF que debe conservarse';
        """)
        trigger_where = ("FROM pg_trigger t WHERE tgrelid='public.myg_nube_proyectos'::regclass "
                         "AND tgname='myg_nube_validar_adjuntos'")
        require(sql("SELECT tgtype=23 AND tgnargs=0 AND tgattr='6 7'::int2vector "
                    "AND tgqual IS NULL AND tgenabled='O' " + trigger_where) == 't',
                'El fixture reproduce exactamente tipo23, columnas6/7, cero argumentos, sin WHEN y habilitadoO observados')
        function_query = ("SELECT to_jsonb(p)::text FROM pg_proc p "
                          "WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;")
        function_before = sql(function_query)
        metadata_before = sql("SELECT (to_jsonb(t)-'oid'-'tgqual')::text " + trigger_where)
        sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
        require(sql(function_query) == function_before,
                'Instalar con UPDATE OF conserva OID, cuerpo, propietario, ACL y atributos de la función de adjuntos')
        require(sql("SELECT (to_jsonb(t)-'oid'-'tgqual')::text " + trigger_where) == metadata_before,
                'El adaptador conserva íntegramente eventos, columnas UPDATE OF, argumentos y habilitación del trigger')
        require(sql("SELECT tgqual IS NOT NULL AND obj_description(oid,'pg_trigger')="
                    "'Comentario sintético UPDATE OF que debe conservarse' " + trigger_where) == 't',
                'Solo se añade WHEN y se conserva el comentario del trigger con columnas filtradas')
        definition = sql("SELECT pg_get_triggerdef(oid) " + trigger_where)
        require('UPDATE OF contenido, alcance' in definition and 'WHEN ((NOT new.es_comprimido))' in definition,
                'La definición adaptada mantiene UPDATE OF contenido,alcance y restringe el validador legado a JSON')

        legacy = '10000000-0000-0000-0000-000000000001'
        count_legacy = lambda: int(sql("SELECT count(*) FROM qa.llamadas_trigger WHERE proyecto_id=" + literal(legacy) + ';'))
        require(count_legacy() == 0, 'El fixture inicia el contador legado vacío')
        sql('UPDATE public.myg_nube_proyectos SET nombre=nombre WHERE id=' + literal(legacy) + ';')
        require(count_legacy() == 0, 'Actualizar una columna no filtrada sigue sin ejecutar el trigger legado')
        sql('UPDATE public.myg_nube_proyectos SET contenido=contenido WHERE id=' + literal(legacy) + ';')
        require(count_legacy() == 1, 'UPDATE OF contenido sigue ejecutando una vez el validador legado')
        sql('UPDATE public.myg_nube_proyectos SET alcance=alcance WHERE id=' + literal(legacy) + ';')
        require(count_legacy() == 2, 'UPDATE OF alcance sigue ejecutando una vez el validador legado')
        sql('UPDATE public.myg_nube_proyectos SET contenido=contenido,alcance=alcance WHERE id=' + literal(legacy) + ';')
        require(count_legacy() == 3, 'Actualizar ambas columnas ejecuta el trigger una sola vez por fila')
        new_legacy = str(uuid.uuid4())
        sql("INSERT INTO public.myg_nube_proyectos(id,propietario,nombre,contenido,alcance) VALUES("
            + literal(new_legacy) + ',' + literal(OWNER) + ",'Legado sintético','{}','obra');")
        require(sql("SELECT count(*)=1 FROM qa.llamadas_trigger WHERE proyecto_id=" + literal(new_legacy) + ';') == 't',
                'INSERT legado continúa ejecutando el trigger de adjuntos')

        project = str(uuid.uuid4())
        sha = hashlib.sha256(b'parte-sintetica-de-metadata').hexdigest()
        route = OWNER + '/' + project.replace('-', '') + '/' + sha
        manifest = {'formato': 'MYG_ARCHIVO_GZIP', 'version': 1,
                    'sha256_json': hashlib.sha256(b'{}').hexdigest(), 'bytes_json': 2,
                    'sha256_gzip': sha, 'bytes_gzip': 100,
                    'partes': [{'ruta': route, 'sha256': sha, 'bytes': 100}]}
        # Solo metadatos para probar disparo del trigger. El Gzip real y sus SHA
        # ya se verificaron en las suites anteriores y no se repiten aquí.
        sql("INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('myg-nube-paquetes',"
            + literal(route) + ",'{\"size\":100}');")
        ack = json.loads(sql_as(OWNER, 'SELECT public.myg_nube_crear_comprimido('
                              + literal(project) + ",'Comprimido sintético UPDATE OF',"
                              + literal(encode(manifest).decode()) + "::jsonb,'obra');"))
        require(ack['revision'] == 1, 'La creación comprimida funciona con el trigger UPDATE OF instalado')
        applied = json.loads(sql_as(OWNER, 'SELECT public.myg_nube_guardar_comprimido('
                                  + literal(project) + ',' + literal(str(uuid.uuid4())) + ',1,'
                                  + literal(encode(manifest).decode()) + '::jsonb);'))
        require(applied['estado'] == 'aplicada' and applied['revision'] == 2,
                'El guardado comprimido progresa con CAS y conserva el trigger filtrado')
        require(sql("SELECT count(*)=0 FROM qa.llamadas_trigger WHERE proyecto_id=" + literal(project) + ';') == 't',
                'La condición añadida evita enviar manifiestos comprimidos al validador legado')
        sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
        require(sql("SELECT pg_get_triggerdef(oid) " + trigger_where) == definition
                and sql(function_query) == function_before,
                'Reinstalar con UPDATE OF conserva definición adaptada y función sin duplicar condiciones')

        variants = [
            ('otra_funcion', 'BEFORE INSERT OR UPDATE OF contenido,alcance', '', 'qa.trigger_ajeno()', 'Trigger de adjuntos desconocido'),
            ('otro_tipo', 'AFTER INSERT OR UPDATE OF contenido,alcance', '', 'myg_nube_privado.validar_paquete_archivos()', 'Trigger de adjuntos desconocido'),
            ('argumentos', 'BEFORE INSERT OR UPDATE OF contenido,alcance', '', "myg_nube_privado.validar_paquete_archivos('sintetico')", 'Trigger de adjuntos desconocido'),
            ('when_desconocido', 'BEFORE INSERT OR UPDATE OF contenido,alcance', "WHEN (NEW.nombre<>'')", 'myg_nube_privado.validar_paquete_archivos()', 'condición personalizada')]
        fingerprint = sql("SELECT md5(jsonb_build_object('proyectos',(SELECT jsonb_agg(to_jsonb(p) ORDER BY id) FROM public.myg_nube_proyectos p),"
                          "'historial',(SELECT jsonb_agg(to_jsonb(h) ORDER BY proyecto_id,revision) FROM public.myg_nube_historial h),"
                          "'operaciones',(SELECT jsonb_agg(to_jsonb(o) ORDER BY usuario_id,operacion_id) FROM public.myg_nube_operaciones o))::text);")
        for label, events, condition, function, expected in variants:
            sql('DROP TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos; CREATE TRIGGER myg_nube_validar_adjuntos '
                + events + ' ON public.myg_nube_proyectos FOR EACH ROW ' + condition + ' EXECUTE FUNCTION ' + function + ';')
            before_reject = sql('SELECT pg_get_triggerdef(oid) ' + trigger_where)
            rejected = sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql', check=False)
            require(rejected.returncode != 0 and expected in rejected.stdout,
                    'La variante desconocida sigue rechazándose: ' + label)
            require(sql('SELECT pg_get_triggerdef(oid) ' + trigger_where) == before_reject
                    and sql(function_query) == function_before,
                    'El rechazo preserva trigger y función existentes: ' + label)
        require(sql("SELECT md5(jsonb_build_object('proyectos',(SELECT jsonb_agg(to_jsonb(p) ORDER BY id) FROM public.myg_nube_proyectos p),"
                    "'historial',(SELECT jsonb_agg(to_jsonb(h) ORDER BY proyecto_id,revision) FROM public.myg_nube_historial h),"
                    "'operaciones',(SELECT jsonb_agg(to_jsonb(o) ORDER BY usuario_id,operacion_id) FROM public.myg_nube_operaciones o))::text);") == fingerprint,
                'Los rechazos de variantes desconocidas no cambian proyectos, historial ni operaciones')
        return {'status': 'passed', 'checks_count': len(checks), 'http_requests_count': 0,
                'large_repeated': False, 'permission_matrix_repeated': False,
                'observed_variant': {'tgtype': 23, 'tgattr': '6 7', 'tgnargs': 0, 'tgenabled': 'O'},
                'scope': 'PostgreSQL17 real; contador trigger explícitamente sintético. No valida cuerpo productivo ni ejecuta API/Storage o benchmarks grandes.'}

    with tempfile.TemporaryDirectory(prefix='myg-gzip-blobs-') as temporary:
        local = Path(temporary)
        objects = local / 'objetos'
        objects.mkdir()

        def upload_chunk(project, data, user):
            sha = hashlib.sha256(data).hexdigest()
            path = user + '/' + project.replace('-', '') + '/' + sha
            stored = objects / hashlib.sha256(path.encode()).hexdigest()
            if not stored.exists():
                sql_as(user, 'INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('
                       + "'myg-nube-paquetes'," + literal(path) + ','
                       + literal(encode({'size': len(data)}).decode()) + '::jsonb);')
                stored.write_bytes(data)
                blob_operations.append({'operation': 'upload_emulado', 'bytes': len(data)})
            else:
                require(stored.read_bytes() == data, 'Repetir la parte conserva sus bytes inmutables')
            return {'ruta': path, 'sha256': sha, 'bytes': len(data)}

        def manifest_bytes(project, raw, user=OWNER, mtime=0):
            compressed = gzip.compress(raw, compresslevel=9, mtime=mtime)
            return {'formato': 'MYG_ARCHIVO_GZIP', 'version': 1,
                    'sha256_json': hashlib.sha256(raw).hexdigest(), 'bytes_json': len(raw),
                    'sha256_gzip': hashlib.sha256(compressed).hexdigest(), 'bytes_gzip': len(compressed),
                    'partes': [upload_chunk(project, compressed[n:n + CHUNK], user)
                               for n in range(0, len(compressed), CHUNK)]}

        def read_manifest(project, manifest, user=OWNER):
            compressed = io.BytesIO()
            for part in manifest['partes']:
                allowed = sql_as(user, "SELECT count(*) FROM storage.objects WHERE bucket_id='myg-nube-paquetes' AND name="
                                 + literal(part['ruta']) + ';')
                require(allowed == '1', 'RLS autoriza leer la parte referenciada para el miembro actual')
                data = (objects / hashlib.sha256(part['ruta'].encode()).hexdigest()).read_bytes()
                require(len(data) == part['bytes'] and hashlib.sha256(data).hexdigest() == part['sha256'],
                        'La lectura emulada verifica longitud y SHA-256 de cada parte')
                compressed.write(data)
                blob_operations.append({'operation': 'download_emulado', 'bytes': len(data)})
            zipped = compressed.getvalue()
            require(len(zipped) == manifest['bytes_gzip'] and hashlib.sha256(zipped).hexdigest() == manifest['sha256_gzip'],
                    'Las partes reconstruyen los bytes y SHA-256 Gzip originales')
            raw = gzip.decompress(zipped)
            require(len(raw) == manifest['bytes_json'] and hashlib.sha256(raw).hexdigest() == manifest['sha256_json'],
                    'Descomprimir reconstruye exactamente longitud y SHA-256 del JSON')
            return raw

        try:
            for image in (POSTGRES, POSTGREST):
                require(run('docker', 'image', 'inspect', image, check=False).returncode == 0,
                        'Se reutiliza la imagen fijada ya disponible: ' + image.split('@')[0])
            require((args.paquetes / 'compacto_cliente.json').is_file(), 'Se reutilizan los fixtures sintéticos existentes')
            run('docker', 'network', 'create', '--internal', network)
            created_network = True
            run('docker', 'run', '--detach', '--rm', '--name', database, '--network', network,
                '--memory=512m', '--memory-swap=512m', '--cpus=1',
                '--tmpfs', '/var/lib/postgresql/data:rw,size=256m',
                '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', POSTGRES,
                '-c', 'shared_buffers=32MB', '-c', 'work_mem=1MB', '-c', 'max_connections=20')
            containers.append(database)
            for attempt in range(60):
                if run('docker', 'exec', database, 'pg_isready', '-U', 'postgres', check=False).returncode == 0:
                    break
                if attempt == 59:
                    raise RuntimeError('PostgreSQL desechable no inició')
                time.sleep(0.5)
            run('docker', 'exec', '-u', 'root', database, 'mkdir', '-p', '/pruebas')
            run('docker', 'cp', str(REPO / 'supabase'), database + ':/pruebas/supabase')
            run('docker', 'cp', str(args.paquetes), database + ':/pruebas/paquetes')
            run('docker', 'exec', '-u', 'root', database, 'chmod', '-R', 'a+rX', '/pruebas')
            # Solo preparación del fixture original; no se repiten sus pruebas.
            baseline = (REPO / 'supabase/pruebas/usuarios_myg_roles.sql').read_text()
            sql(baseline.split('grant insert,update,delete on public.myg_nube_miembros', 1)[0])
            # Reutilizar los helpers de aserción, sin ejecutar los casos antiguos.
            helpers = 'create table qa.resultados' + baseline.split('create table qa.resultados', 1)[1].split('select qa.exige', 1)[0]
            sql(helpers)
            sql_file('/pruebas/supabase/migraciones/20261020_usuarios_myg_roles.sql')
            sql_file('/pruebas/supabase/migraciones/20261026_publicacion_ligera.sql')
            sql_file('/pruebas/supabase/migraciones/20261027_publicacion_sin_espera.sql')
            sql('''
                CREATE SCHEMA storage;
                CREATE TABLE storage.buckets(id text PRIMARY KEY,name text,public boolean,file_size_limit bigint);
                CREATE TABLE storage.objects(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),bucket_id text,name text,
                    metadata jsonb,UNIQUE(bucket_id,name));
                ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
                GRANT USAGE ON SCHEMA storage TO authenticated,anon;
                GRANT SELECT,INSERT,UPDATE,DELETE ON storage.objects TO authenticated,anon;
                -- Una política permisiva global pone a prueba las guardas RESTRICTIVE nuevas.
                CREATE POLICY qa_permisiva_global ON storage.objects FOR ALL TO authenticated USING(true) WITH CHECK(true);
                CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
                    SELECT coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub',
                        nullif(current_setting('request.jwt.claim.sub',true),''))::uuid;
                $$;
                CREATE ROLE myg_gzip_http_login LOGIN NOINHERIT;
                GRANT anon,authenticated TO myg_gzip_http_login;
                CREATE FUNCTION qa.guard_estado(p_anterior text,p_nuevo text,p_permisos jsonb)
                RETURNS text LANGUAGE plpgsql AS $$
                BEGIN
                    PERFORM myg_nube_privado.validar_contenido(p_anterior::jsonb);
                    PERFORM myg_nube_privado.validar_contenido(p_nuevo::jsonb);
                    PERFORM myg_nube_privado.exigir_modulos(p_anterior::jsonb,p_nuevo::jsonb,p_permisos);
                    RETURN '00000';
                EXCEPTION WHEN OTHERS THEN RETURN SQLSTATE;
                END $$;
            ''')
            if args.solo_instalador_saltos:
                result = probar_instalador_saltos()
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return
            if args.solo_trigger:
                result = probar_trigger_update_of()
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return
            before = sql("SELECT md5(coalesce(jsonb_agg(to_jsonb(p) ORDER BY id),'[]')::text) FROM public.myg_nube_proyectos p;")
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(before == sql("SELECT md5(coalesce(jsonb_agg(to_jsonb(p)-'es_comprimido' ORDER BY id),'[]')::text) FROM public.myg_nube_proyectos p;"),
                    'Instalar28 conserva contenido y metadatos existentes salvo nueva marca false')
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT count(*)=1 FROM storage.buckets WHERE id='myg-nube-paquetes' AND public=false AND file_size_limit=8388608;") == 't',
                    'Reinstalar28 conserva el bucket privado y límite8MiB')
            sql_file('/pruebas/supabase/pruebas/publicacion_comprimida.sql')
            sql_checks = int(sql('SELECT count(*) FROM qa.resultados;'))
            require(sql_checks > 0, 'Las pruebas SQL nuevas de compresión completan sus aserciones')
            run('docker', 'run', '--detach', '--rm', '--name', api, '--network', network,
                '--memory=512m', '--memory-swap=512m', '--cpus=1',
                '-e', f'PGRST_DB_URI=postgres://myg_gzip_http_login@{database}:5432/postgres',
                '-e', 'PGRST_DB_SCHEMAS=public', '-e', 'PGRST_DB_ANON_ROLE=anon',
                '-e', 'PGRST_JWT_SECRET=' + SECRET.decode(), POSTGREST)
            containers.append(api)
            address = run('docker', 'inspect', api, '--format', '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}').stdout.strip()
            url = f'http://{address}:3000/'
            for attempt in range(60):
                try:
                    with opener.open(url, timeout=2) as response:
                        if response.status == 200:
                            break
                except (urllib.error.URLError, TimeoutError):
                    pass
                if attempt == 59:
                    raise RuntimeError('PostgREST desechable no inició')
                time.sleep(0.5)

            def rpc(name, body, user=OWNER, expected=200, code=None):
                headers = {'Content-Type': 'application/json'}
                if user:
                    headers['Authorization'] = 'Bearer ' + token(user)
                encoded = encode(body)
                started = time.monotonic()
                request = urllib.request.Request(url + 'rpc/' + name, data=encoded, headers=headers, method='POST')
                try:
                    with opener.open(request, timeout=30) as response:
                        status, content = response.status, response.read()
                except urllib.error.HTTPError as error:
                    status, content = error.code, error.read()
                elapsed = time.monotonic() - started
                value = json.loads(content)
                require(status == expected, f'{name}: HTTP{status}, esperado{expected}; código={value.get("code") if isinstance(value,dict) else "array"}')
                if code:
                    require(value.get('code') == code, f'{name} preserva SQLSTATE{code}')
                requests.append({'rpc': name, 'status': status, 'seconds': round(elapsed, 4),
                                 'request_bytes': len(encoded), 'response_bytes': len(content),
                                 'sqlstate': value.get('code') if isinstance(value, dict) else None})
                return value

            caps = rpc('myg_nube_capacidades', {})
            require(caps.get('publicacion_comprimida') == 1 and caps.get('publicacion_ligera') == 1
                    and caps.get('cambios') == 1, 'Capacidades conserva los protocolos existentes y anuncia compresión')
            project = '99000000-0000-0000-0000-000000000001'
            raw = (args.paquetes / 'compacto_cliente.json').read_bytes()
            manifest = manifest_bytes(project, raw)
            create = {'p_id': project, 'p_nombre': 'COMPRIMIDO QA', 'p_manifest': manifest, 'p_alcance': 'base'}
            ack = rpc('myg_nube_crear_comprimido', create)
            require(ack['id'] == project and ack['revision'] == 1 and 'contenido' not in ack,
                    'Crear confirma proyecto y revisión sin devolver el contenido')
            require(rpc('myg_nube_crear_comprimido', create) == ack, 'Repetir creación confirma sin duplicar historia')
            alternative = manifest_bytes(project, raw, mtime=1)
            require(rpc('myg_nube_crear_comprimido', dict(create, p_manifest=alternative)) == ack,
                    'Recomprimir el mismo JSON mantiene idempotencia del UUID sin cambiar historia inicial')
            opened = rpc('myg_nube_abrir_comprimido', {'p_id': project})
            require(opened['contenido'] == manifest and read_manifest(project, opened['contenido']) == raw,
                    'Apertura recupera el primer manifiesto y los bytes exactos del JSON')
            require(rpc('myg_nube_paquete_tipo', {'p_id': project}) == {'almacenamiento': 'gzip'},
                    'La sonda autorizada identifica almacenamiento Gzip')
            rpc('myg_nube_abrir_comprimido', {'p_id': project}, user=OTHER, expected=403, code='42501')
            rpc('myg_nube_abrir_comprimido', {'p_id': project}, user=None, expected=401, code='42501')
            rpc('myg_nube_crear_comprimido', create, user=EDITOR, expected=403, code='42501')
            rpc('myg_nube_abrir', {'p_id': project}, expected=400, code='MGC01')
            rpc('myg_nube_guardar', {'p_id': project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1,
                                  'p_contenido': json.loads(raw)}, expected=400, code='MGC01')

            second_raw = (args.paquetes / 'compacto_cliente_nombre.json').read_bytes()
            second_manifest = manifest_bytes(project, second_raw)
            op = str(uuid.uuid4())
            save = {'p_id': project, 'p_operacion': op, 'p_revision': 1, 'p_manifest': second_manifest}
            saved = rpc('myg_nube_guardar_comprimido', save)
            require(saved == {'estado': 'aplicada', 'revision': 2, 'operacion_id': op},
                    'Guardar utiliza CAS y confirma solo metadatos pequeños')
            conflict_op = str(uuid.uuid4())
            conflict_save = dict(save, p_operacion=conflict_op, p_manifest=manifest)
            conflict = rpc('myg_nube_guardar_comprimido', conflict_save)
            require(conflict['estado'] == 'conflicto' and conflict['revision'] == 2 and conflict['contenido'] == second_manifest,
                    'El conflicto congela el manifiesto de la revisión vigente sin sobrescribir')
            third_op = str(uuid.uuid4())
            rpc('myg_nube_guardar_comprimido', dict(save, p_operacion=third_op, p_revision=2, p_manifest=manifest))
            require(rpc('myg_nube_guardar_comprimido', save) == saved,
                    'Un ACK perdido conserva la revisión aplicada aunque el proyecto haya avanzado')
            require(rpc('myg_nube_guardar_comprimido', conflict_save) == conflict,
                    'Repetir el conflicto entrega el snapshot original, no uno posterior')
            alternative_second = manifest_bytes(project, second_raw, mtime=1)
            require(rpc('myg_nube_guardar_comprimido', dict(save, p_manifest=alternative_second)) == saved,
                    'Recomprimir el mismo JSON final conserva replay del UUID de operación')
            require(rpc('myg_nube_crear_comprimido', create)['revision'] == 1,
                    'Reintentar creación tras ediciones confirma la revisión inicial y no cambia el contenido vigente')
            historical = rpc('myg_nube_abrir_comprimido', {'p_id': project, 'p_revision': 2})
            require(historical['revision'] == 2 and historical['contenido'] == second_manifest
                    and read_manifest(project, historical['contenido']) == second_raw,
                    'Abrir una revisión histórica recupera exactamente sus bytes')
            rpc('myg_nube_guardar_comprimido', dict(save, p_manifest=manifest), expected=400, code='22023')
            rpc('myg_nube_compartir_usuario', {'p_id': project, 'p_usuario_myg': 'lector', 'p_rol': 'lector',
                                              'p_permisos_modulos': {'acu': False, 'especificaciones': False, 'metrados_excel': False}})
            require(read_manifest(project, manifest, user=READER) == raw, 'El lector puede recuperar una revisión autorizada')
            first_path = manifest['partes'][0]['ruta']
            require(sql_as(OTHER, "SELECT count(*) FROM storage.objects WHERE name=" + literal(first_path) + ';') == '0',
                    'La política global permisiva no abre las partes de otro proyecto')
            require(sql_as(OWNER, "WITH cambio AS(UPDATE storage.objects SET metadata='{}' WHERE name=" + literal(first_path)
                           + ' RETURNING 1) SELECT count(*) FROM cambio;') == '0',
                    'Ni el propietario puede modificar objetos referenciados')
            require(sql_as(OWNER, 'WITH cambio AS(DELETE FROM storage.objects WHERE name=' + literal(first_path)
                           + ' RETURNING 1) SELECT count(*) FROM cambio;') == '0',
                    'Ni el propietario puede borrar objetos de revisiones históricas')
            rpc('myg_nube_rol', {'p_id': project, 'p_usuario': READER, 'p_rol': None})
            require(sql_as(READER, 'SELECT count(*) FROM storage.objects WHERE name=' + literal(first_path) + ';') == '0',
                    'Retirar acceso revoca inmediatamente la lectura de las partes históricas')

            # Paridad con el guard autoritativo anterior: casos pequeños existentes,
            # ocho máscaras y todos los tipos de representación sensibles.
            baseline_raw = (args.paquetes / 'baseline.json').read_bytes()
            mutations = ['acu_precio', 'acu_recurso', 'acu_insumo', 'especificacion',
                         'hoja_excel', 'zoom_excel', 'fuente_excel', 'cantidad_excel',
                         'ataque_tabla_acu', 'ataque_tipo_celda_acu', 'ataque_mayusculas_acu',
                         'ataque_tabla_especificacion', 'ataque_tabla_excel',
                         'ataque_documentos', 'ataque_recursos']
            partial_cases = []
            for mask_number in (() if args.solo_adicionales else range(8)):
                permissions = {name: bool(mask_number & (1 << bit)) for bit, name in enumerate(
                    ['acu', 'especificaciones', 'metrados_excel'])}
                for mutation in mutations:
                    mutated = (args.paquetes / (mutation + '.json')).read_bytes()
                    expected_code = sql('SELECT qa.guard_estado(' + literal(baseline_raw.decode()) + ','
                                        + literal(mutated.decode()) + ',' + literal(encode(permissions).decode()) + '::jsonb);')
                    # Full permission path deliberately does not parse JSONB. These
                    # fixtures are valid exports; malformed-format parity is tested elsewhere.
                    if mask_number == 7 and expected_code != '00000':
                        raise AssertionError('Fixture no válido para el fastpath: ' + mutation + '/' + expected_code)
                    case_project = str(uuid.uuid4())
                    initial = manifest_bytes(case_project, baseline_raw)
                    rpc('myg_nube_crear_comprimido', {'p_id': case_project, 'p_nombre': 'MÁSCARA QA', 'p_alcance': 'obra', 'p_manifest': initial})
                    rpc('myg_nube_compartir_usuario', {'p_id': case_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                                     'p_permisos_modulos': permissions})
                    updated = manifest_bytes(case_project, mutated, user=EDITOR)
                    body = {'p_id': case_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1, 'p_manifest': updated}
                    if mask_number != 7:
                        body.update(p_anterior=baseline_raw.decode(), p_nuevo=mutated.decode())
                    permitted = expected_code == '00000'
                    actual = rpc('myg_nube_guardar_comprimido', body, user=EDITOR,
                                 expected=200 if permitted else (403 if expected_code == '42501' else 400),
                                 code=None if permitted else expected_code)
                    require((actual.get('estado') == 'aplicada') == permitted,
                            f'Máscara{mask_number}, {mutation}: paridad con validar_contenido+exigir_modulos')
                    current = rpc('myg_nube_revision', {'p_id': case_project})
                    require(current['revision'] == (2 if permitted else 1),
                            f'Máscara{mask_number}, {mutation}: rechazo conserva la revisión y el contenido')
                    partial_cases.append({'mask': mask_number, 'mutation': mutation, 'permitted': permitted,
                                          'expected_sqlstate': expected_code})

            # El JSON de la operación es durable; la máscara puede cambiar después
            # de perderse el ACK. Los textos auxiliares no cambian su identidad.
            retry_project = str(uuid.uuid4())
            retry_initial = manifest_bytes(retry_project, baseline_raw)
            rpc('myg_nube_crear_comprimido', {'p_id': retry_project, 'p_nombre': 'REPLAY PERMISOS QA',
                                            'p_alcance': 'obra', 'p_manifest': retry_initial})
            rpc('myg_nube_compartir_usuario', {'p_id': retry_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=True, especificaciones=True, metrados_excel=True)})
            retry_raw = (args.paquetes / 'acu_precio.json').read_bytes()
            retry_manifest = manifest_bytes(retry_project, retry_raw, user=EDITOR)
            retry_save = {'p_id': retry_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1,
                          'p_manifest': retry_manifest}
            first_retry_ack = rpc('myg_nube_guardar_comprimido', retry_save, user=EDITOR)
            rpc('myg_nube_compartir_usuario', {'p_id': retry_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=True, especificaciones=False, metrados_excel=False)})
            require(rpc('myg_nube_guardar_comprimido', dict(retry_save, p_anterior=baseline_raw.decode(),
                        p_nuevo=retry_raw.decode()), user=EDITOR) == first_retry_ack,
                    'ACK perdido se recupera al pasar de permisos completos a restringidos')
            retry_back = {'p_id': retry_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 2,
                          'p_manifest': manifest_bytes(retry_project, baseline_raw, user=EDITOR),
                          'p_anterior': retry_raw.decode(), 'p_nuevo': baseline_raw.decode()}
            second_retry_ack = rpc('myg_nube_guardar_comprimido', retry_back, user=EDITOR)
            rpc('myg_nube_compartir_usuario', {'p_id': retry_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=True, especificaciones=True, metrados_excel=True)})
            require(rpc('myg_nube_guardar_comprimido', {k: v for k, v in retry_back.items()
                        if k not in ('p_anterior', 'p_nuevo')}, user=EDITOR) == second_retry_ack,
                    'ACK perdido se recupera al pasar de permisos restringidos a completos')
            uploader_path = retry_manifest['partes'][0]['ruta']
            rpc('myg_nube_rol', {'p_id': retry_project, 'p_usuario': EDITOR, 'p_rol': None})
            require(sql_as(EDITOR, 'SELECT count(*) FROM storage.objects WHERE name=' + literal(uploader_path) + ';') == '0',
                    'La revocación impide al antiguo uploader leer partes históricas de su propio prefijo')
            rpc('myg_nube_guardar_comprimido', retry_save, user=EDITOR, expected=403, code='42501')
            denied_upload = sql_as(EDITOR, "INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('myg-nube-paquetes',"
                + literal(EDITOR + '/' + retry_project.replace('-', '') + '/' + 'f' * 64) + ",'{}');", check=False)
            require('42501' in denied_upload,
                    'El antiguo uploader tampoco puede subir partes nuevas al proyecto revocado')

            # Pruebas añadidas después de la matriz aprobada: se pueden ejecutar
            # con --solo-adicionales, sin repetir la carga grande ni los 120 casos.
            forged_project = str(uuid.uuid4())
            forged_manifest = manifest_bytes(forged_project, baseline_raw)
            rpc('myg_nube_crear_comprimido', {'p_id': forged_project, 'p_nombre': 'TEXTOS QA',
                                            'p_alcance': 'obra', 'p_manifest': forged_manifest})
            rpc('myg_nube_compartir_usuario', {'p_id': forged_project, 'p_usuario_myg': 'editor', 'p_rol': 'editor',
                                             'p_permisos_modulos': dict(acu=False, especificaciones=False, metrados_excel=False)})
            forged_save = {'p_id': forged_project, 'p_operacion': str(uuid.uuid4()), 'p_revision': 1,
                           'p_manifest': forged_manifest, 'p_anterior': baseline_raw.decode(), 'p_nuevo': baseline_raw.decode()}
            rpc('myg_nube_guardar_comprimido', dict(forged_save, p_anterior=baseline_raw.decode() + ' '),
                user=EDITOR, expected=400, code='22023')
            rpc('myg_nube_guardar_comprimido', dict(forged_save, p_nuevo=baseline_raw.decode() + ' '),
                user=EDITOR, expected=400, code='22023')
            require(rpc('myg_nube_revision', {'p_id': forged_project})['revision'] == 1,
                    'Textos anteriores o nuevos con SHA distinto no alteran revisión ni proyecto')
            alien_manifest = dict(forged_manifest, partes=manifest['partes'])
            rpc('myg_nube_guardar_comprimido', dict(forged_save, p_manifest=alien_manifest),
                expected=400, code='22023')
            require(rpc('myg_nube_guardar_comprimido', forged_save, user=EDITOR)['revision'] == 2,
                    'El rechazo no consume el UUID: se recupera enviando los textos exactos autorizados')

            fingerprint_query = """SELECT md5(jsonb_build_object(
                'proyecto',(SELECT to_jsonb(p) FROM public.myg_nube_proyectos p WHERE id=%s),
                'historial',(SELECT jsonb_agg(to_jsonb(h) ORDER BY revision) FROM public.myg_nube_historial h WHERE proyecto_id=%s),
                'operaciones',(SELECT jsonb_agg(to_jsonb(o) ORDER BY usuario_id,operacion_id) FROM public.myg_nube_operaciones o WHERE proyecto_id=%s)
            )::text);""" % (literal(project), literal(project), literal(project))
            fingerprint = sql(fingerprint_query)
            holder_name = 'myg-gzip-fila-ocupada'
            with (args.resultados / 'fila-ocupada.log').open('w') as holder_log:
                holder = subprocess.Popen(['docker', 'exec', '-e', 'PGAPPNAME=' + holder_name,
                    '-u', 'postgres', database, 'psql', '-X', '-qAt', '-v', 'ON_ERROR_STOP=1', '-c',
                    'BEGIN; SELECT id FROM public.myg_nube_proyectos WHERE id=' + literal(project)
                    + ' FOR UPDATE; SELECT pg_sleep(30); ROLLBACK;'], stdout=holder_log, stderr=subprocess.STDOUT)
                try:
                    for attempt in range(40):
                        if sql("SELECT exists(SELECT 1 FROM pg_stat_activity WHERE application_name="
                               + literal(holder_name) + " AND wait_event='PgSleep');") == 't':
                            break
                        if attempt == 39:
                            raise RuntimeError('No se confirmó el bloqueo sintético de fila')
                        time.sleep(0.05)
                    rpc('myg_nube_crear_comprimido', create, expected=500, code='55006')
                    require(requests[-1]['seconds'] < 2, 'Crear Gzip rechaza la fila ocupada mediante NOWAIT en menos de2s')
                    rpc('myg_nube_guardar_comprimido', dict(save, p_operacion=str(uuid.uuid4()), p_revision=3),
                        expected=500, code='55006')
                    require(requests[-1]['seconds'] < 2, 'Guardar Gzip rechaza la fila ocupada mediante NOWAIT en menos de2s')
                    rpc('myg_nube_guardar_comprimido', dict(save, p_operacion=str(uuid.uuid4()), p_revision=3),
                        user=OTHER, expected=403, code='42501')
                    require(sql(fingerprint_query) == fingerprint,
                            'Los rechazos por fila ocupada y permisos conservan proyecto, historial y operaciones')
                finally:
                    sql('SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE application_name=' + literal(holder_name) + ';')
                    holder.wait(timeout=10)
            require(rpc('myg_nube_crear_comprimido', create)['revision'] == 1,
                    'Liberar la fila permite recuperar el mismo intento de creación sin modificar revisiones')

            # Este trigger es EXCLUSIVAMENTE un stub de laboratorio. No reproduce
            # el cuerpo productivo ausente del repositorio ni valida sus adjuntos.
            sql("""
                CREATE FUNCTION myg_nube_privado.validar_paquete_archivos() RETURNS trigger
                LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$ BEGIN RETURN NEW; END $$;
                REVOKE ALL ON FUNCTION myg_nube_privado.validar_paquete_archivos() FROM PUBLIC;
                GRANT EXECUTE ON FUNCTION myg_nube_privado.validar_paquete_archivos() TO anon;
                COMMENT ON FUNCTION myg_nube_privado.validar_paquete_archivos() IS 'STUB SINTÉTICO: no es el validador productivo';
                CREATE TRIGGER myg_nube_validar_adjuntos BEFORE INSERT OR UPDATE ON public.myg_nube_proyectos
                FOR EACH ROW EXECUTE FUNCTION myg_nube_privado.validar_paquete_archivos();
                COMMENT ON TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos IS 'Comentario sintético que debe conservarse';
                ALTER TABLE public.myg_nube_proyectos ENABLE ALWAYS TRIGGER myg_nube_validar_adjuntos;
            """)
            trigger_function_before = sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;")
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;") == trigger_function_before,
                    'Adaptar el trigger sintético conserva OID, cuerpo, ACL y atributos de su función')
            require(sql("SELECT tgenabled='A' AND tgqual IS NOT NULL AND obj_description(oid,'pg_trigger')="
                        + "'Comentario sintético que debe conservarse' FROM pg_trigger WHERE tgrelid='public.myg_nube_proyectos'::regclass AND tgname='myg_nube_validar_adjuntos';") == 't',
                    'El trigger sintético conserva ENABLE ALWAYS y COMMENT al añadir su condición')
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;") == trigger_function_before,
                    'Reinstalar el adaptador conserva nuevamente la función sintética sin reemplazarla')
            sql("""
                DROP TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos;
                CREATE TRIGGER myg_nube_validar_adjuntos BEFORE INSERT OR UPDATE ON public.myg_nube_proyectos
                FOR EACH ROW WHEN (NEW.nombre<>'') EXECUTE FUNCTION myg_nube_privado.validar_paquete_archivos();
            """)
            unknown_trigger = sql("SELECT pg_get_triggerdef(oid) FROM pg_trigger WHERE tgrelid='public.myg_nube_proyectos'::regclass AND tgname='myg_nube_validar_adjuntos';")
            rejected_install = sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql', check=False)
            require(rejected_install.returncode != 0 and 'condición personalizada' in rejected_install.stdout,
                    'Un trigger con condición desconocida aborta la instalación completa')
            require(sql("SELECT pg_get_triggerdef(oid) FROM pg_trigger WHERE tgrelid='public.myg_nube_proyectos'::regclass AND tgname='myg_nube_validar_adjuntos';") == unknown_trigger
                    and sql("SELECT to_jsonb(p)::text FROM pg_proc p WHERE oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure;") == trigger_function_before,
                    'El rechazo de instalación preserva la condición y la función desconocidas')
            sql('DROP TRIGGER myg_nube_validar_adjuntos ON public.myg_nube_proyectos;')
            sql("ALTER TABLE public.myg_nube_proyectos ALTER es_comprimido SET DEFAULT true;")
            rejected_default = sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql', check=False)
            require(rejected_default.returncode != 0 and 'definición incompatible' in rejected_default.stdout,
                    'Una marca preexistente con DEFAULT true no cambia el formato de los proyectos legados')
            sql("ALTER TABLE public.myg_nube_proyectos ALTER es_comprimido SET DEFAULT false;")

            # Restaurar únicamente los cuerpos oficiales previos del fixture y
            # convertirlos a CRLF verifica la misma instalación en archivos Windows.
            sql("""
                DO $qa$ DECLARE v text; d text; BEGIN
                    FOREACH v IN ARRAY ARRAY['myg_nube_privado.snapshot(uuid,uuid)','public.myg_nube_capacidades()',
                        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)',
                        'public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)',
                        'myg_nube_privado.reconstruir_revision(uuid,bigint)'] LOOP
                        d:=pg_get_functiondef(v::regprocedure);
                        d:=replace(d,E'    perform myg_nube_privado.exigir_paquete_json(p_id);\\n','');
                        d:=replace(d,' and myg_nube_privado.exigir_paquete_json(p.id)','');
                        d:=replace(d,',''publicacion_comprimida'',1','');
                        EXECUTE replace(d,E'\\n',E'\\r\\n');
                    END LOOP;
                END $qa$;
            """)
            sql_file('/pruebas/supabase/migraciones/20261028_publicacion_comprimida.sql')
            require(sql("SELECT bool_and(position(E'\\r\\n' in prosrc)>0) FROM pg_proc WHERE oid=ANY(ARRAY["
                        + "'myg_nube_privado.snapshot(uuid,uuid)'::regprocedure,'public.myg_nube_capacidades()'::regprocedure,"
                        + "'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure,"
                        + "'public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)'::regprocedure,"
                        + "'myg_nube_privado.reconstruir_revision(uuid,bigint)'::regprocedure]);") == 't',
                    'Instalar28 sobre los cuerpos oficiales CRLF conserva sus finales de línea Windows')
            rpc('myg_nube_abrir', {'p_id': project}, expected=400, code='MGC01')
            require(read_manifest(project, rpc('myg_nube_abrir_comprimido', {'p_id': project})['contenido']) == raw,
                    'La adaptación CRLF mantiene la apertura comprimida y el rechazo del cliente legado')

            large_result = None
            if not args.sin_carga_grande and not args.solo_adicionales:
                # Nuevo protocolo, no repetición del benchmark JSONB antiguo. La
                # carga lógica se procesa localmente y nunca se envía como RPC.
                large_project = str(uuid.uuid4())
                logical_bytes = 209835827
                prefix_json, suffix_json = b'{"prueba_sintetica":"', b'"}'
                random_block = base64.b64encode(random.Random(20261028).randbytes(192 * 1024))
                remaining = logical_bytes - len(prefix_json) - len(suffix_json)
                large_json = local / 'sintetico-200mib.json'
                with large_json.open('wb') as stream:
                    stream.write(prefix_json)
                    while remaining:
                        piece = random_block[:min(remaining, len(random_block))]
                        stream.write(piece)
                        remaining -= len(piece)
                    stream.write(suffix_json)
                large_raw = large_json.read_bytes()
                started = time.monotonic()
                large_manifest = manifest_bytes(large_project, large_raw)
                ack_large = rpc('myg_nube_crear_comprimido', {'p_id': large_project, 'p_nombre': '200 MiB SINTÉTICOS QA',
                                                            'p_manifest': large_manifest, 'p_alcance': 'base'})
                open_large = rpc('myg_nube_abrir_comprimido', {'p_id': large_project})
                require(ack_large['revision'] == 1 and read_manifest(large_project, open_large['contenido']) == large_raw,
                        'El nuevo protocolo publica y recupera200MiB lógicos sin enviar JSON grande a PostgreSQL')
                require(all(row['request_bytes'] < 65536 for row in requests[-2:]),
                        'Crear y abrir200MiB utilizan solicitudesRPC inferiores a64KiB')
                large_result = {'logical_bytes': len(large_raw), 'gzip_bytes': large_manifest['bytes_gzip'],
                                'chunks': len(large_manifest['partes']), 'sha256_json': large_manifest['sha256_json'],
                                'seconds_total_local_compression_emulated_storage_rpc_roundtrip': round(time.monotonic() - started, 4),
                                'rpc': requests[-2:]}
                del large_raw
            events = {}
            for name in containers:
                if name == database:
                    lines = run('docker', 'exec', name, 'cat', '/sys/fs/cgroup/memory.events').stdout.splitlines()
                    events['pg'] = dict(line.split() for line in lines)
                    require(events['pg'].get('oom_kill') == '0',
                            'PostgreSQL512MiB no registra OOMkill durante este protocolo')
                else:
                    # La imagen API es distroless; no contiene cat. Docker conserva
                    # el estado del proceso sin depender de rutas cgroup del host.
                    state = json.loads(run('docker', 'inspect', name).stdout)[0]
                    events['api'] = {'oom_killed': state['State']['OOMKilled'],
                                     'running': state['State']['Running'],
                                     'restart_count': state['RestartCount']}
                    require(not events['api']['oom_killed'] and events['api']['running']
                            and events['api']['restart_count'] == 0,
                            'PostgREST512MiB continúa ejecutándose sin OOMKilled ni reinicios registrados por Docker')
            result = {'status': 'passed', 'checks_count': len(checks), 'sql_checks_count': sql_checks,
                      'http_requests_count': len(requests),
                      'storage_emulated_operations': len(blob_operations), 'partial_cases': partial_cases,
                      'large_protocol': large_result, 'memory_events': events,
                      'scope': 'RPC PostgreSQL17/PostgREST16.5 reales; blobStorage emulado local y RLS real. '
                               'No prueba Supabase Storage desplegado ni demuestra causa de502/520 de producción.'}
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except BaseException as error:
            result = {'status': 'failed', 'error': str(error), 'checks_count': len(checks),
                      'http_requests_count': len(requests)}
            raise
        finally:
            result.update(requests=requests, checks=checks, blob_operations=blob_operations)
            (args.resultados / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
            for name in reversed(containers):
                (args.resultados / (name.rsplit('-', 1)[-1] + '.log')).write_text(run('docker', 'logs', name, check=False).stdout)
                run('docker', 'rm', '-f', name, check=False)
            if created_network:
                run('docker', 'network', 'rm', network, check=False)
            log.close()


if __name__ == '__main__':
    main()
