# Corrección del instalador 28: finales de línea Windows

Entrega de 23/10/2026 (America/Lima). Incluye también la corrección anterior de UPDATE OF; se aplica ejecutando una sola vez el SQL28 más reciente.

## A. Resultado

El usuario aportó las cinco definiciones SQL solicitadas. Sus cuerpos coinciden exactamente con los esperados tras convertir CRLF a LF. El mensaje «snapshot contiene una personalización desconocida» era un falso rechazo del instalador, no evidencia de cambios de lógica del usuario.

La comparación normalizaba la función del servidor, pero dejaba sin normalizar los textos multilínea del propio instalador cuando se copiaba con finales Windows. La corrección normaliza ambos lados para comparar y conserva después el formato original al actualizar la función. Mantiene las verificaciones estrictas contra cambios de lógica, las propiedades y permisos existentes, y la corrección UPDATE OF de las columnas originales.

## B. Qué hacer con cada archivo

Copie los archivos sobre la carpeta donde está `MYG.Presupuestos.sln`, conservando las rutas. El único archivo que se ejecuta en Supabase es el SQL28.

| Ruta exacta | Acción requerida | Descripción |
|---|---|---|
| `supabase/migraciones/20261028_publicacion_comprimida.sql` | Reemplazar y ejecutar completo en SQL Editor | Instalador compatible con LF/CRLF y UPDATE OF. |
| `scripts/pruebas/Probar-PublicacionComprimidaHTTP.py` | Reemplazar; ejecución opcional de desarrollo | Añade la regresión de finales del instalador; no necesita Python para instalar o usar MYG. |
| `supabase/diagnosticos/RESULTADOS_CORRECCION_SALTOS_SQL_20261028.json` | Crear; solo consultar | Resultados reales y huellas de los archivos comprobados. |
| `supabase/CONTINUIDAD_PUBLICACION_COMPRIMIDA.md` | Reemplazar; conservar | Estado y siguiente paso para retomar. |
| `supabase/LEEME_CORRECCION_SALTOS_SQL_20261028.md` | Crear; leer | Estas instrucciones. |

El archivo exportado por el usuario no se incluye en el ZIP. Los 15 archivos C# de la entrega inicial permanecen sin cambios.

## C. Descarga

El mensaje final proporciona un ZIP en una ruta nueva de `bimchimbote-droid/DESCARGAS`. Se verifican la descarga pública, tamaño, SHA-256, integridad ZIP y coincidencia de sus cinco archivos antes de entregarlo. Las entregas anteriores permanecen disponibles.

## D. Instalación manual

1. Cierre MYG y copie los cinco archivos sobre sus rutas.
2. En Supabase → SQL Editor, abra una consulta nueva y copie **todo el SQL28 de esta descarga**, desde `begin;` hasta `commit;`. Ejecútelo una vez. No ejecute los SQL28 anteriores ni los parches 26/27.
3. Espere a que termine: el resultado previsto es `PUBLICACION_COMPRIMIDA_INSTALADA`. Después, desde otra consulta, repita la comprobación de instalación que ya utilizó. `rpc_crear`, `rpc_abrir`, `rpc_guardar`, `capacidad_compresion` y `bucket_privado` deben ser `true`.
4. Abra la aplicación actualizada de la primera entrega para renovar su caché de capacidades. Si todavía no compiló esos archivos, desde la carpeta de la solución:

   ```powershell
   dotnet run --project .\MYG.Desktop\MYG.Desktop.csproj -c Release
   ```

5. Reintente el mismo intento desde Publicaciones pendientes. Conserve su identificador y su copia local. El tamaño comprimido se mostrará durante el envío. Tras confirmar, compruebe apertura, descarga de copia y un guardado pequeño.

## E. Configuración

Esta corrección conserva los plazos y permisos de las funciones reales: guardado completo 120 s y guardado incremental 60 s. No necesita cambiar manualmente esos parámetros, deshabilitar triggers, hacer públicos los buckets, modificar la instancia ni instalar Python. Se conservan las condiciones adicionales de validación para editores con módulos restringidos.

## F. Verificación

Se aprobaron **122 comprobaciones nuevas en PostgreSQL17**. Reprodujeron el fallo con el instalador anterior convertido a CRLF y verificaron el control LF con las mismas funciones. El corregido pasó las cuatro combinaciones del archivo SQL LF/CRLF con las funciones almacenadas LF/CRLF: instalación y repetición, formato conservado, OID/propiedades/permisos y UPDATE OF. Cinco modificaciones reales de lógica siguieron rechazándose con rollback completo. El resumen JSON adjunto registra los resultados obtenidos.

Se reutilizan los resultados anteriores de compresión, recuperación, conflictos y permisos: no se repiten sus benchmarks, la matriz de 120 casos ni compilaciones del cliente, porque esta corrección cambia únicamente la comparación del instalador. Los cuerpos exportados se usan como entrada local del laboratorio; no se adjuntan a la entrega.

## G. Commit y Push

Revise `git diff`, añada las cinco rutas de esta corrección a su commit junto con los cambios anteriores que decida conservar y haga Push según su flujo habitual. La publicación de esta entrega guarda únicamente el ZIP en DESCARGAS; el repositorio del software no recibe Push automático.

## H. Estado pendiente

Falta confirmar la instalación en Supabase real y publicar la obra privada con la aplicación actualizada. Esta corrección resuelve el falso rechazo por finales de línea; no demuestra la causa del timeout de conexión, los HTTP502/520 históricos ni los eventos WAL.

El JSON local del pendiente puede conservar sus 200,1 MiB. El Gzip se utiliza para el transporte y almacenamiento remoto. No elimine el pendiente ni sustituya manualmente su contenido por un archivo `.gz`.
