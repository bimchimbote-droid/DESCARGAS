using System.Text.Json;
using MYG.Externo;
using MYG_2027;

internal static class VinculacionAutomaticaRevitCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }

    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new InvalidOperationException("Se aceptó una referencia automática ambigua o contradictoria.");
    }

    private static MYGProyectoDocumento Obra() => MYGProyectoStorage.Nuevo("Vinculación automática", "Estructuras");
    private static MYGActivoRevit Local(MYGProyectoDocumento proyecto, string nombre, string ruta, string identidad = null) =>
        MYGActivosRevit.GuardarActivo(proyecto, new() { Nombre = nombre, RutaLocal = ruta, DocumentoRevitId = identidad });
    private static DocumentoRevitInfo Modelo(string ruta) => new()
    {
        Id = "apertura-prueba", DocumentoRevitId = "local:identidad-prueba", Nombre = "Nombre irrelevante", Ruta = ruta
    };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var proyecto = Obra();
        var activo = Local(proyecto, "Bloque 01", @"C:\Obras\Estructuras\Modelo.rvt");
        Local(proyecto, "Mismo nombre de archivo", @"D:\Otras\Modelo.rvt");
        var info = Modelo("c:/obras/Estructuras/Temporal/.././MODELO.rvt");
        string firma = MYGProyectoStorage.Firma(proyecto);
        Exige(MYGTablasActivosRevit.ResolverActivo(proyecto, info) == null &&
            MYGTablasActivosRevit.BuscarActivoPorReferencia(proyecto, info)?.Id == activo.Id,
            "No se reconoció la ruta absoluta normalizada o se confundió con otro archivo de igual nombre.");
        Exige(MYGProyectoStorage.Firma(proyecto) == firma && string.IsNullOrWhiteSpace(activo.DocumentoRevitId),
            "Buscar por referencia guardó el vínculo antes de validar la operación.");
        info.Ruta = @"\\?\C:\Obras\Estructuras\Modelo.rvt";
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(proyecto, info)?.Id == activo.Id,
            "Una ruta extendida de Windows al mismo RVT no coincidió.");
        info.Ruta = @"E:\Obras\Modelo.rvt"; info.Nombre = activo.Nombre;
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(proyecto, info) == null,
            "El nombre del activo o del archivo bastó para vincular otro modelo.");
        pasa("La ruta local completa reconoce un único activo, normaliza Windows y no vincula por nombre ni modifica la obra al buscar");

        var relativas = Obra();
        Local(relativas, "Relativo", @"Carpeta\Modelo.rvt");
        foreach (string ruta in new[] { @"Carpeta\Modelo.rvt", @"C:Modelo.rvt", @"\Modelo.rvt", @"C:\..\Modelo.rvt", "https://ejemplo.invalid/Modelo.rvt" })
            Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(relativas, Modelo(ruta)) == null,
                "Se completó o aceptó una ruta relativa, inválida o web para vincular un activo local.");
        pasa("Las referencias relativas, rutas incompletas y URL web no se convierten en una vinculación local automática");

        var colaboracion = Obra();
        var central = Local(colaboracion, "Central", @"\\Servidor\Compartida\Obra\Central.rvt");
        Local(colaboracion, "Copia local distinta", @"C:\Usuarios\Local.rvt");
        var colaborativo = Modelo(@"C:\Usuarios\Local.rvt");
        colaborativo.EsColaborativo = true;
        colaborativo.RutaCentral = "//servidor/compartida/Obra/Temporal/../CENTRAL.rvt";
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(colaboracion, colaborativo)?.Id == central.Id,
            "La copia local ganó a la identidad de ruta central del colaborativo.");
        colaborativo.RutaCentral = @"\\?\UNC\Servidor\Compartida\Obra\Central.rvt";
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(colaboracion, colaborativo)?.Id == central.Id,
            "La ruta UNC extendida no conserva su referencia central.");
        colaborativo.RutaCentral = null;
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(colaboracion, colaborativo) == null,
            "Faltar la ruta central hizo usar una copia local como sustituto del modelo colaborativo.");
        var servidor = Local(colaboracion, "Revit Server", "RSN://Servidor/Proyecto/Modelo.rvt");
        colaborativo.RutaCentral = "rsn://servidor/Proyecto/Sub/../MODELO.rvt";
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(colaboracion, colaborativo)?.Id == servidor.Id,
            "Una referencia central de Revit Server no se reconoció.");
        colaborativo.EsModeloSeparado = true;
        firma = MYGProyectoStorage.Firma(colaboracion);
        Rechaza(() => MYGTablasActivosRevit.BuscarActivoPorReferencia(colaboracion, colaborativo));
        Rechaza(() => MYGTablasActivosRevit.ResolverActivo(colaboracion, colaborativo));
        Exige(MYGProyectoStorage.Firma(colaboracion) == firma, "Rechazar un modelo separado modificó los activos.");
        pasa("Los colaborativos usan la ruta central UNC o Revit Server; una central ausente o un modelo separado no se asignan a la copia local");

        const string proyectoId = "11111111-2222-4333-8444-555555555555";
        const string modeloId = "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee";
        var nube = Obra();
        var activoNube = MYGActivosRevit.GuardarActivo(nube, new()
        {
            Nombre = "Modelo Autodesk", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "b." + Guid.Parse(proyectoId).ToString("N"), ModeloAutodeskId = "{" + modeloId.ToUpperInvariant() + "}"
        });
        Local(nube, "Caché", @"C:\Cache\Modelo.rvt");
        var cloud = Modelo(@"C:\Cache\Modelo.rvt"); cloud.Origen = MYGOrigenActivoRevit.Autodesk;
        cloud.DocumentoRevitId = "autodesk:" + proyectoId + ":" + modeloId;
        cloud.ProyectoAutodeskId = proyectoId; cloud.ModeloAutodeskId = modeloId;
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(nube, cloud)?.Id == activoNube.Id,
            "La normalización de los dos GUID Autodesk falló o se eligió la ruta de caché.");
        MYGTablasActivosRevit.VincularDocumento(nube, activoNube.Id, cloud);
        Exige(MYGTablasActivosRevit.ResolverActivo(nube, cloud)?.Id == activoNube.Id,
            "El vínculo Autodesk normalizado dejó de ser válido en la siguiente consulta.");
        var otroCloud = MYGProyectoStorage.Copia(cloud); otroCloud.DocumentoRevitId = "autodesk:otro";
        otroCloud.ProyectoAutodeskId = Guid.NewGuid().ToString("D");
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(nube, otroCloud) == null,
            "Coincidir sólo el GUID de modelo eligió un proyecto Autodesk distinto.");
        var urn = MYGProyectoStorage.Copia(cloud); urn.DocumentoRevitId = "autodesk:urn";
        urn.ModeloAutodeskId = "urn:adsk.wipprod:dm.lineage:modelo";
        Exige(MYGTablasActivosRevit.BuscarActivoPorReferencia(nube, urn) == null,
            "Se interpretó un URN de archivo o versión como GUID de modelo Revit.");
        pasa("Autodesk exige los dos GUID del proyecto/modelo, acepta formatos equivalentes y nunca elige el activo por la caché o un URN");

        var ambiguo = Obra();
        Local(ambiguo, "Ruta 1", @"C:\Obra\Parte\..\Modelo.rvt");
        Local(ambiguo, "Ruta 2", @"C:\Obra\Modelo.rvt");
        firma = MYGProyectoStorage.Firma(ambiguo);
        Rechaza(() => MYGTablasActivosRevit.BuscarActivoPorReferencia(ambiguo, Modelo(@"C:\Obra\Modelo.rvt")));
        Exige(MYGProyectoStorage.Firma(ambiguo) == firma, "Una ruta ambigua cambió el registro.");
        var dobleNube = Obra();
        MYGActivosRevit.GuardarActivo(dobleNube, new() { Nombre = "Nube 1", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = proyectoId, ModeloAutodeskId = modeloId });
        MYGActivosRevit.GuardarActivo(dobleNube, new() { Nombre = "Nube 2", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "b." + proyectoId, ModeloAutodeskId = Guid.Parse(modeloId).ToString("N") });
        firma = MYGProyectoStorage.Firma(dobleNube);
        Rechaza(() => MYGTablasActivosRevit.BuscarActivoPorReferencia(dobleNube, cloud));
        Exige(MYGProyectoStorage.Firma(dobleNube) == firma, "Un par Autodesk ambiguo cambió el registro.");
        pasa("Los alias equivalentes de rutas y GUID que apuntan a varios activos bloquean la operación sin escoger el primero");

        var sustituido = Obra();
        var anterior = Local(sustituido, "Archivo sustituido", @"C:\Obra\Modelo.rvt", "local:otra-identidad");
        firma = MYGProyectoStorage.Firma(sustituido);
        Rechaza(() => MYGTablasActivosRevit.BuscarActivoPorReferencia(sustituido, Modelo(@"C:\Obra\Modelo.rvt")));
        Exige(MYGProyectoStorage.Firma(sustituido) == firma && anterior.DocumentoRevitId == "local:otra-identidad",
            "Coincidir la ruta sobrescribió una identidad previamente vinculada.");
        var compartido = Obra();
        Local(compartido, "Activo A", @"\\S\Compartida\A.rvt", "local:identidad-prueba");
        Local(compartido, "Activo B", @"\\S\Compartida\B.rvt");
        var contradiccion = Modelo(@"C:\Cache\A-local.rvt"); contradiccion.EsColaborativo = true;
        contradiccion.RutaCentral = @"\\S\Compartida\B.rvt";
        firma = MYGProyectoStorage.Firma(compartido);
        Rechaza(() => MYGTablasActivosRevit.ResolverActivo(compartido, contradiccion));
        Rechaza(() => MYGTablasActivosRevit.BuscarActivoPorReferencia(compartido, contradiccion));
        Exige(MYGProyectoStorage.Firma(compartido) == firma, "Un conflicto entre identidad y central modificó los activos.");
        var seleccionErronea = Obra();
        var seleccionA = Local(seleccionErronea, "Selección A", @"C:\Obra\A.rvt");
        var referenciaB = Local(seleccionErronea, "Referencia B", @"C:\Obra\B.rvt");
        firma = MYGProyectoStorage.Firma(seleccionErronea);
        Rechaza(() => MYGTablasActivosRevit.VincularDocumento(seleccionErronea, seleccionA.Id, Modelo(referenciaB.RutaLocal)));
        Exige(MYGProyectoStorage.Firma(seleccionErronea) == firma &&
            seleccionErronea.ActivosRevit.Activos.All(a => string.IsNullOrWhiteSpace(a.DocumentoRevitId)),
            "Una selección manual distinta de la referencia registrada dejó un vínculo contradictorio.");
        pasa("Una ruta reutilizada o una identidad que contradice la referencia central no cambia automáticamente vínculos anteriores");

        var persistente = Obra();
        var registrado = Local(persistente, "Persistente", @"C:\Obras\Persistente.rvt");
        var documento = Modelo(@"C:\Obras\Persistente.rvt");
        var encontrado = MYGTablasActivosRevit.BuscarActivoPorReferencia(persistente, documento);
        MYGTablasActivosRevit.VincularDocumento(persistente, encontrado.Id, documento);
        string archivo = Path.Combine(carpeta, "vinculacion-automatica.myg.json");
        MYGProyectoStorage.Guardar(archivo, persistente);
        documento.Id = "apertura-nueva"; documento.Ruta = @"E:\ArchivoRenombrado.rvt";
        foreach (string guardado in new[] { archivo, MYGBaseDatos.RutaDeProyecto(archivo) })
            Exige(MYGTablasActivosRevit.ResolverActivo(MYGProyectoStorage.Leer(guardado), documento)?.Id == registrado.Id,
                "La vinculación automática guardada no sobrevivió JSON/SQLite o un cambio de ubicación posterior.");
        documento.EsColaborativo = true; documento.RutaCentral = @"\\S\Compartida\Persistente.rvt";
        var recibido = JsonSerializer.Deserialize<DocumentoRevitInfo>(JsonSerializer.Serialize(documento, ProtocoloMYG.Json), ProtocoloMYG.Json);
        Exige(recibido.EsColaborativo && recibido.RutaCentral == documento.RutaCentral && !recibido.EsModeloSeparado,
            "El protocolo perdió los datos del modelo colaborativo necesarios para el reconocimiento.");
        pasa("El vínculo elegido por referencia se guarda en JSON/SQLite y reconoce la identidad al reabrir o mover el modelo");
    }
}
