# Vinculación automática del modelo abierto

Actualización sobre las entregas anteriores de tablas por activo y corrección
de edición/conector. Repositorio del código: `bimchimbote-droid/MYG.Presupuestos`,
rama remota `main`, base `14cc8c2cf78d7a60901c3cd175adbcfc761eac39` más las
entregas `3b96e030919c1d2bd55e939b66bd43b57477fae0` y
`8a1a2b31553503caf42ff45787d9ec6ca5ebb42d` del repositorio `DESCARGAS`.

## Uso

1. Registre el activo de la obra con la ruta completa o los identificadores
   Autodesk correctos y asigne sus partidas con plantillas y filtros.
2. Abra el modelo en Revit y pulse **Tablas del modelo abierto**.
3. Si hay una sola coincidencia válida, MYG guarda automáticamente el vínculo y
   continúa con las partidas asignadas. No aparece el selector de activo.

La coincidencia se determina así:

| Modelo abierto | Referencia del activo |
|---|---|
| RVT local independiente | Ruta completa del archivo, incluida su carpeta. |
| Modelo colaborativo local | Ruta del modelo central, no la copia local de cada usuario. |
| Revit Server | Ruta central RSN completa. |
| Modelo Autodesk en la nube | Par GUID de proyecto y GUID de modelo comunicado por Revit. |

Se normalizan barras y mayúsculas de rutas Windows, componentes `.`/`..` y
formatos equivalentes de GUID. El prefijo `b.` de proyecto APS se admite cuando
contiene el mismo GUID. No se identifica un modelo únicamente por su nombre.
Una unidad mapeada y una ruta UNC distintas no se convierten automáticamente
entre sí; registre la ruta que comunica Revit.

## Casos que necesitan intervención

- Si no hay coincidencia, se conserva la vinculación manual de una sola vez.
  También puede corregir la referencia del activo y volver a pulsar el botón.
- Si varios registros equivalen a la misma ruta o par de GUID, o la identidad
  guardada contradice otro activo, la operación se detiene antes de modificar.
- Si la ruta coincide pero el activo ya está vinculado a otra identidad Revit,
  MYG no sobrescribe ese vínculo automáticamente. Compruebe si sustituyó el RVT.
- Un documento separado del central (`Detach from Central`) debe guardarse como
  modelo independiente antes de aplicar las tablas. Su referencia al central
  anterior no acredita que siga perteneciendo a ese activo.
- Una copia física puede conservar la identidad del documento original. Los
  conflictos con otro activo registrado se bloquean; las copias no registradas
  con identidad compartida no se pueden distinguir automáticamente.

Los ID o enlaces de Autodesk Forma/APS no siempre son los GUID del modelo Revit:
un URN de archivo o versión no equivale al GUID de modelo. En ese caso, registre
el par de GUID que identifica ese proyecto/modelo en Revit; esta actualización no
inicia sesiones ni consulta un servicio adicional de Autodesk para convertirlos.

## Instalar

1. Respalde o confirme cambios locales y cierre MYG y todas las sesiones de Revit.
2. Copie los archivos del ZIP sobre las entregas anteriores, conservando carpetas.
   Los archivos se entregan completos. Compare antes de reemplazar si tiene
   modificaciones propias posteriores. No hay eliminaciones ni migraciones SQL.
3. Desde PowerShell, en la raíz del código actualizado, con SDK .NET 10 y Revit
   2027 instalado:

   ```powershell
   dotnet build .\MYG.Presupuestos.sln -c Release -m:1 -nr:false
   if ($LASTEXITCODE -ne 0) { throw 'La compilación falló; no continúe.' }
   powershell -NoProfile -File .\scripts\Actualizar-Conector.ps1
   ```

4. El instalador debe indicar **1.2.0.0**. Abra MYG recién compilado y reinicie
   Revit. El conector 1.2 informa la ruta central y el estado colaborativo.
   Un conector anterior conserva la vinculación manual, porque no proporciona
   todos los datos necesarios para automatizarla con seguridad.

No necesita volver a registrar ni asignar las partidas existentes. Se guarda la
identidad persistente antes de solicitar las tablas y se vuelve a comprobar el
documento activo en el conector. Si falla la validación de las partidas, no se
publica una nueva vinculación parcial ni se crean tablas.

## Validación y límites

Las pruebas automáticas cubren rutas locales/UNC/centrales, formatos equivalentes,
GUID Autodesk, duplicados, referencias cambiadas, documentos separados del
central y conservación de la obra ante fallos. La prueba de interfaz comprueba
que una ruta única selecciona el activo sin mostrar el diálogo.

Las pruebas de datos se ejecutan en Linux; la interfaz se compila pero necesita
Windows para ejecutarse. La prueba real dentro de Revit con sus modelos locales,
centrales y cloud queda pendiente. No se reemplazan las asignaciones técnicas
que usted configuró ni se deducen partidas a partir del nombre del modelo.

Resultados de esta actualización con SDK .NET 10.0.100: compilación completa
Release con cero errores y cero advertencias; siete grupos focales de vinculación
automática y 800 comprobaciones del núcleo aprobados. Las pruebas UI se
compilaron, pero no se ejecutaron en Linux. Se omitieron las muestras externas
no suministradas y Named Pipes de Windows. El fallo de nube ya conocido no forma
parte de esta actualización y no se presenta como resuelto.

El instalador pasó 14 comprobaciones controladas en PowerShell, incluido el
rechazo de conectores 1.0/1.1 y la instalación temporal de la DLL real 1.2.0.0
con 38 archivos verificados por SHA-256. Las pruebas usan carpetas y procesos
simulados; no equivalen a ejecutar Revit en Windows.

El ZIP se entrega en el repositorio independiente `DESCARGAS`. No hace Commit
ni Push del código del proyecto. Tras validar, revise **Cambios de Git** en Visual
Studio, haga Commit y Push a su rama y compruebe el resultado en GitHub.
