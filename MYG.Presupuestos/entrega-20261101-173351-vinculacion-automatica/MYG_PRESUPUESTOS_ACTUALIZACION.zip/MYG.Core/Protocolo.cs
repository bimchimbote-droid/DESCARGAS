using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.IO.Pipes;
using System.Text.Json;
using MYG_2027;

namespace MYG.Externo;

public sealed class SolicitudRevit
{
    public int Version { get; set; } = 1;
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Accion { get; set; }
    public CredencialMYG Credencial { get; set; }
    public string DocumentoId { get; set; }
    public string DocumentoRevitId { get; set; }
    public string ProyectoId { get; set; }
    public string ProyectoNombre { get; set; }
    public string PresupuestoId { get; set; }
    public string Plantilla { get; set; }
    public string Parametro { get; set; }
    public string ActivoId { get; set; }
    public List<ConfiguracionTablaPlanificacion> Configuraciones { get; set; } = new();
    public List<LoteTablasRevit> LotesTablas { get; set; } = new();
}
public sealed class LoteTablasRevit
{
    public string PresupuestoId { get; set; }
    public List<ConfiguracionTablaPlanificacion> Configuraciones { get; set; } = new();
}
public sealed class DocumentoRevitInfo
{
    public string Id { get; set; }
    // Id identifica la apertura actual; DocumentoRevitId identifica el modelo
    // entre sesiones y permite reconocer su activo sin depender de la ruta.
    public string DocumentoRevitId { get; set; }
    public MYGOrigenActivoRevit Origen { get; set; }
    public int CapacidadTablasActivos { get; set; }
    public string VersionConector { get; set; }
    public string RutaConector { get; set; }
    public string ProyectoAutodeskId { get; set; }
    public string ModeloAutodeskId { get; set; }
    public string Nombre { get; set; }
    public string Ruta { get; set; }
    public string RutaCentral { get; set; }
    public bool EsColaborativo { get; set; }
    public bool EsModeloSeparado { get; set; }
    public int CapacidadVinculacionAutomatica { get; set; }
    public List<string> Plantillas { get; set; } = new();
    private Dictionary<string, List<string>> parametros = new(StringComparer.OrdinalIgnoreCase);
    private Dictionary<string, Dictionary<string, List<string>>> reglas = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, List<string>> Parametros
    { get => parametros; set => parametros = new(value ?? new(), StringComparer.OrdinalIgnoreCase); }
    public Dictionary<string, Dictionary<string, List<string>>> Reglas
    {
        get => reglas;
        set => reglas = (value ?? new()).ToDictionary(x => x.Key, x => new Dictionary<string, List<string>>(x.Value ?? new(), StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase);
    }
}
public sealed class RespuestaRevit
{
    public string Id { get; set; }
    public bool Ok { get; set; }
    public string Mensaje { get; set; }
    public DocumentoRevitInfo Documento { get; set; }
    public string MetradoJson { get; set; }
    public List<string> Valores { get; set; } = new();
    public List<ResultadoValidacionRevitPartida> Resultados { get; set; } = new();
    public static RespuestaRevit Error(string id, string mensaje) => new() { Id = id, Mensaje = mensaje };
}
public static class ProtocoloMYG
{
    public const int MaxBytes = 32 * 1024 * 1024;
    public static string Pipe(int pid) => "MYG.Tablas.Externo." + pid;
    public static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true, MaxDepth = 128 };
    public static async Task EscribirAsync<T>(Stream s, T valor, CancellationToken ct)
    {
        byte[] datos = JsonSerializer.SerializeToUtf8Bytes(valor, Json);
        if (datos.Length > MaxBytes) throw new InvalidDataException("La solicitud supera el tamaño permitido.");
        byte[] cabecera = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(cabecera, datos.Length);
        await s.WriteAsync(cabecera, ct); await s.WriteAsync(datos, ct); await s.FlushAsync(ct);
    }
    public static async Task<T> LeerAsync<T>(Stream s, CancellationToken ct)
    {
        byte[] cabecera = new byte[4]; await s.ReadExactlyAsync(cabecera, ct);
        int size = BinaryPrimitives.ReadInt32LittleEndian(cabecera);
        if (size <= 0 || size > MaxBytes) throw new InvalidDataException("Tamaño de mensaje inválido.");
        byte[] datos = new byte[size]; await s.ReadExactlyAsync(datos, ct);
        return JsonSerializer.Deserialize<T>(datos, Json) ?? throw new InvalidDataException("Mensaje vacío.");
    }
    public static void Validar(SolicitudRevit s)
    {
        if (s == null || s.Version != 1 || !Guid.TryParseExact(s.Id, "N", out _)) throw new InvalidDataException("Solicitud incompatible.");
        if (!new[] { "INFO", "VALORES", "REVISAR", "CREAR", "ACTUALIZAR", "METRADO", "APLICAR_ACTIVO" }.Contains(s.Accion)) throw new InvalidDataException("Acción no disponible.");
        if (s.Accion == "METRADO" && (string.IsNullOrWhiteSpace(s.ActivoId) || s.ActivoId.Length > 128)) throw new InvalidDataException("Indique un nombre de activo válido (máximo 128 caracteres).");
        if (s.Accion != "INFO" && string.IsNullOrWhiteSpace(s.DocumentoId)) throw new InvalidDataException("Seleccione un modelo Revit.");
        if (s.Accion == "APLICAR_ACTIVO")
        {
            if (string.IsNullOrWhiteSpace(s.ProyectoId) || string.IsNullOrWhiteSpace(s.ActivoId) ||
                string.IsNullOrWhiteSpace(s.DocumentoRevitId))
                throw new InvalidDataException("Falta la identidad del modelo o del activo vinculado.");
            if (s.LotesTablas == null || s.LotesTablas.Count == 0 || s.LotesTablas.Count > 20000 ||
                s.LotesTablas.Any(l => l == null || string.IsNullOrWhiteSpace(l.PresupuestoId) ||
                    l.Configuraciones == null || l.Configuraciones.Count == 0) ||
                s.LotesTablas.Select(l => l.PresupuestoId).Distinct(StringComparer.OrdinalIgnoreCase).Count() != s.LotesTablas.Count ||
                s.LotesTablas.Sum(l => (long)l.Configuraciones.Count) > 20000)
                throw new InvalidDataException("Los presupuestos de las tablas del activo no son válidos.");
            foreach (var lote in s.LotesTablas)
            {
                var claves = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var c in lote.Configuraciones)
                {
                    if (c == null || string.IsNullOrWhiteSpace(c.IdInterno) || !claves.Add(c.IdInterno) ||
                        string.IsNullOrWhiteSpace(c.Plantilla) || c.ObtenerFiltros().Count > 8 ||
                        c.ObtenerFiltros().Any(f => f == null || (!f.EstaVacio() &&
                            (string.IsNullOrWhiteSpace(f.Parametro) || string.IsNullOrWhiteSpace(f.Regla)))))
                        throw new InvalidDataException("Una partida del activo tiene identidad, plantilla o filtros inválidos.");
                }
            }
        }
        if (s.Accion is "CREAR" or "ACTUALIZAR" or "REVISAR" or "METRADO")
        {
            if (string.IsNullOrWhiteSpace(s.ProyectoId) || string.IsNullOrWhiteSpace(s.PresupuestoId)) throw new InvalidDataException("Falta el ámbito del presupuesto.");
            if (s.Configuraciones == null || s.Configuraciones.Count == 0 || s.Configuraciones.Count > 20000) throw new InvalidDataException("No se recibieron partidas válidas.");
            foreach (var c in s.Configuraciones)
                if (c == null || c.ObtenerFiltros().Count > 8 || c.ObtenerFiltros().Any(f => f == null)) throw new InvalidDataException("Configuración de filtros inválida.");
        }
    }
    public static void ValidarRespuesta(SolicitudRevit solicitud, RespuestaRevit respuesta)
    {
        if (respuesta == null || respuesta.Id != solicitud.Id)
            throw new InvalidDataException("La respuesta no corresponde a esta operación.");
    }
}
public sealed class ClienteRevit
{
    public async Task<RespuestaRevit> EnviarAsync(int pid, SolicitudRevit solicitud, CancellationToken ct = default)
    {
        ProtocoloMYG.Validar(solicitud);
        using var tiempo = CancellationTokenSource.CreateLinkedTokenSource(ct);
        tiempo.CancelAfter(TimeSpan.FromMinutes(10));
        using var pipe = new NamedPipeClientStream(".", ProtocoloMYG.Pipe(pid), PipeDirection.InOut, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
        await pipe.ConnectAsync(5000, tiempo.Token);
        await ProtocoloMYG.EscribirAsync(pipe, solicitud, tiempo.Token);
        var r = await ProtocoloMYG.LeerAsync<RespuestaRevit>(pipe, tiempo.Token);
        ProtocoloMYG.ValidarRespuesta(solicitud, r);
        return r;
    }
}
public sealed class OperacionPendiente
{
    private int estado;
    public SolicitudRevit Solicitud { get; }
    public DateTime AutorizadoUtc { get; } = DateTime.UtcNow;
    public TaskCompletionSource<RespuestaRevit> Fin { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
    public OperacionPendiente(SolicitudRevit s) { Solicitud = s; }
    public bool Iniciar() => Interlocked.CompareExchange(ref estado, 1, 0) == 0;
    public bool CancelarAntesDeIniciar()
    {
        if (Interlocked.CompareExchange(ref estado, 3, 0) != 0) return false;
        Fin.TrySetResult(RespuestaRevit.Error(Solicitud.Id, "La operación pendiente se canceló antes de ejecutarse.")); return true;
    }
    public void Completar(RespuestaRevit r) { Interlocked.Exchange(ref estado, 2); Fin.TrySetResult(r); }
}
