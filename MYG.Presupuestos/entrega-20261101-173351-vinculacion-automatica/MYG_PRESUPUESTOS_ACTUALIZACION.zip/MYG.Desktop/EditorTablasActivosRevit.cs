using System.Diagnostics;
using System.IO;
using MYG.Externo;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private void AgregarBotonTablasModeloAbierto()
    {
        var boton = CrearBotonCintaProyecto("bim", "Tablas del\nmodelo abierto", true);
        boton.Name = "tablas_modelo_abierto_button";
        boton.Width = 124;
        boton.AccessibleName = "Crear / actualizar tablas del modelo abierto";
        ayudas.SetToolTip(boton, "Reconoce el activo del modelo abierto en Revit y crea o actualiza las tablas de sus partidas asignadas en toda la obra.");
        boton.Click += async (_, _) => await Ejecutar(AplicarTablasModeloAbierto);
        cintaPresupuestos.Controls.Add(boton);
    }

    private async Task AplicarTablasModeloAbierto()
    {
        ExigirPermisosModulosEstructura(acu: false, especificaciones: false, metrados: true);
        MYGProyectoStorage.Validar(documento);
        var conexion = await ConsultarModeloActivoParaTablas();
        if (conexion == null) return;
        var info = conexion.Documento;
        var activo = MYGTablasActivosRevit.ResolverActivo(documento, info);
        // Preparar sobre una copia: ni una configuración inválida ni cancelar
        // el vínculo deben dejar cambios parciales en la obra.
        var candidato = documento;
        if (activo == null)
        {
            string activoId = ElegirActivoParaVincular(info);
            if (activoId == null) return;
            candidato = MYGProyectoStorage.Copia(documento);
            activo = MYGTablasActivosRevit.VincularDocumento(candidato, activoId, info);
        }
        var lotes = MYGTablasActivosRevit.PrepararLotes(candidato, info);
        ExigirPermisosModulosEstructura(acu: false, especificaciones: false, metrados: true);
        if (!ReferenceEquals(candidato, documento))
        {
            Recordar();
            documento.ActivosRevit = candidato.ActivosRevit;
            Refrescar();
        }
        // Guardar el vínculo y las asignaciones antes de modificar Revit.
        if (!Guardar(false)) return;
        estado.Text = "Creando / actualizando tablas de «" + activo.Nombre + "» en Revit…";
        RespuestaRevit respuesta;
        try
        {
            respuesta = await cliente.EnviarAsync(conexion.Pid, new SolicitudRevit
            {
                Accion = "APLICAR_ACTIVO", Credencial = sesion.Credencial,
                DocumentoId = info.Id, DocumentoRevitId = info.DocumentoRevitId,
                ProyectoId = documento.IdProyectoRevit, ProyectoNombre = documento.Nombre,
                ActivoId = activo.Id, LotesTablas = lotes
            });
        }
        catch (IOException)
        {
            throw new IOException("Se interrumpió la conexión. Compruebe las tablas en Revit antes de repetir la operación.");
        }
        catch (OperationCanceledException)
        {
            throw new TimeoutException("Revit no respondió a tiempo. Compruebe las tablas en Revit antes de repetir la operación.");
        }
        if (!respuesta.Ok && respuesta.Resultados?.Count is not > 0)
            throw new InvalidOperationException(respuesta.Mensaje);
        // El preflight de Revit puede descubrir errores de tipo/valor que no
        // figuran en INFO. Mostrar la partida y su motivo también al rechazar.
        using var resultados = new ResultadosForm(respuesta);
        resultados.ShowDialog(this);
        estado.Text = respuesta.Mensaje;
    }

    private async Task<ModeloActivoParaTablas> ConsultarModeloActivoParaTablas()
    {
        async Task<ModeloActivoParaTablas> Consultar(int pid)
        {
            var respuesta = await cliente.EnviarAsync(pid, new SolicitudRevit { Accion = "INFO", Credencial = sesion.Credencial });
            if (!respuesta.Ok) throw new InvalidOperationException(respuesta.Mensaje);
            MYGCompatibilidadConectorRevit.ExigirTablasActivos(respuesta.Documento, pid);
            return new ModeloActivoParaTablas(pid, respuesta.Documento);
        }

        ModeloActivoParaTablas elegido;
        if (revit.SelectedItem is RevitOpcion sesionElegida)
        {
            // INFO se consulta en cada clic: no reutilizar el documento anterior
            // si el usuario activó otro RVT dentro de la misma sesión de Revit.
            elegido = await Consultar(sesionElegida.Pid);
        }
        else
        {
            var disponibles = new List<ModeloActivoParaTablas>();
            var errores = new List<string>();
            var conectoresAnteriores = new List<string>();
            foreach (var proceso in Process.GetProcessesByName("Revit"))
            {
                using (proceso)
                {
                    try { disponibles.Add(await Consultar(proceso.Id)); }
                    catch (ConectorRevitDesactualizadoException error) { conectoresAnteriores.Add(error.Message); }
                    catch (Exception error) when (error is IOException or TimeoutException or OperationCanceledException or InvalidOperationException)
                    { errores.Add("PID " + proceso.Id + ": " + error.Message); }
                }
            }
            if (disponibles.Count == 0)
            {
                if (conectoresAnteriores.Count > 0)
                    throw new ConectorRevitDesactualizadoException(string.Join("\n\n", conectoresAnteriores));
                throw new InvalidOperationException("Abra un proyecto en Revit 2027 con el conector MYG actualizado. " + string.Join("\n", errores));
            }
            if (disponibles.Count == 1) elegido = disponibles[0];
            else
            {
                using var dialogo = new WinForms.Form();
                MYGProyectoUI.Preparar(dialogo, "Elegir sesión de Revit", 680, 230);
                var detalle = new WinForms.Label { Dock = WinForms.DockStyle.Top, Height = 50,
                    Text = "Hay varias sesiones de Revit. Elija en cuál aplicar las tablas; se utilizará su documento activo." };
                var lista = new WinForms.ComboBox { Dock = WinForms.DockStyle.Top, DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
                foreach (var disponible in disponibles) lista.Items.Add(disponible);
                var aceptar = MYGProyectoUI.Boton("Continuar"); aceptar.DialogResult = WinForms.DialogResult.OK;
                aceptar.Enabled = false;
                lista.SelectedIndexChanged += (_, _) => aceptar.Enabled = lista.SelectedItem != null;
                var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
                var pie = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Bottom, Height = 46 };
                pie.Controls.AddRange(new WinForms.Control[] { aceptar, cancelar });
                dialogo.Controls.Add(lista); dialogo.Controls.Add(detalle); dialogo.Controls.Add(pie);
                dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
                MYG2027_TemaComercial.Aplicar(dialogo);
                if (dialogo.ShowDialog(this) != WinForms.DialogResult.OK) return null;
                if (lista.SelectedItem is not ModeloActivoParaTablas opcion) throw new InvalidOperationException("Elija una sesión de Revit.");
                elegido = await Consultar(opcion.Pid);
            }
        }
        revit.Items.Clear();
        revit.Items.Add(new RevitOpcion(elegido.Pid, elegido.Documento.Nombre));
        revit.SelectedIndex = 0;
        modelo = elegido.Documento;
        estadoRevit.Text = "Revit: " + modelo.Nombre;
        ActualizarEstadoConexion();
        return elegido;
    }

    private string ElegirActivoParaVincular(DocumentoRevitInfo info)
    {
        // Un conector anterior no informa si la ruta corresponde a una copia
        // local de trabajo. Sólo automatizar con la metadata nueva completa.
        var coincidencia = info.CapacidadVinculacionAutomatica >= 1
            ? MYGTablasActivosRevit.BuscarActivoPorReferencia(documento, info) : null;
        return coincidencia?.Id ?? ElegirVinculoModeloAbierto(info, null);
    }

    private string ElegirVinculoModeloAbierto(DocumentoRevitInfo info, string sugeridoId)
    {
        var disponibles = documento.ActivosRevit?.Activos.Where(a => a.Origen == info.Origen
            && string.IsNullOrWhiteSpace(a.DocumentoRevitId)).ToList() ?? new List<MYGActivoRevit>();
        if (info.Origen == MYGOrigenActivoRevit.Autodesk)
            disponibles = disponibles.Where(a => string.Equals(a.ProyectoAutodeskId?.Trim(), info.ProyectoAutodeskId, StringComparison.OrdinalIgnoreCase)
                && string.Equals(a.ModeloAutodeskId?.Trim(), info.ModeloAutodeskId, StringComparison.OrdinalIgnoreCase)).ToList();
        if (disponibles.Count == 0)
            throw new InvalidOperationException("El modelo abierto no está vinculado a un activo disponible. Regístrelo en «Activos de la obra», asigne sus partidas y vuelva a pulsar este botón.");
        using var dialogo = new WinForms.Form();
        MYGProyectoUI.Preparar(dialogo, "Vincular modelo abierto con un activo", 720, 330);
        var detalle = new WinForms.Label { Dock = WinForms.DockStyle.Top, Height = 125,
            Text = "Modelo abierto: " + info.Nombre + "\n" + info.Ruta
                + (info.CapacidadVinculacionAutomatica >= 1
                    ? "\n\nNo se encontró un activo por la ruta completa o los identificadores Autodesk. Selecciónelo una sola vez o corrija su registro."
                    : "\n\nSu conector admite vinculación manual. Para reconocer automáticamente la ruta o Autodesk, actualícelo con scripts/Actualizar-Conector.ps1.")
                + " Las próximas ejecuciones reconocerán la identidad guardada." };
        var lista = new WinForms.ComboBox { Dock = WinForms.DockStyle.Top, DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            DisplayMember = nameof(MYGActivoRevit.Nombre) };
        foreach (var disponible in disponibles) lista.Items.Add(disponible);
        lista.SelectedItem = disponibles.FirstOrDefault(a => a.Id == sugeridoId);
        var aceptar = MYGProyectoUI.Boton("Vincular y continuar"); aceptar.Width = 180; aceptar.DialogResult = WinForms.DialogResult.OK;
        aceptar.Enabled = lista.SelectedItem != null;
        lista.SelectedIndexChanged += (_, _) => aceptar.Enabled = lista.SelectedItem != null;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        var pie = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Bottom, Height = 46 };
        pie.Controls.AddRange(new WinForms.Control[] { aceptar, cancelar });
        dialogo.Controls.Add(lista); dialogo.Controls.Add(detalle); dialogo.Controls.Add(pie);
        dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
        MYG2027_TemaComercial.Aplicar(dialogo);
        return dialogo.ShowDialog(this) == WinForms.DialogResult.OK ? (lista.SelectedItem as MYGActivoRevit)?.Id : null;
    }

    private sealed record ModeloActivoParaTablas(int Pid, DocumentoRevitInfo Documento)
    {
        public override string ToString() => Documento.Nombre + " · PID " + Pid;
    }
}
