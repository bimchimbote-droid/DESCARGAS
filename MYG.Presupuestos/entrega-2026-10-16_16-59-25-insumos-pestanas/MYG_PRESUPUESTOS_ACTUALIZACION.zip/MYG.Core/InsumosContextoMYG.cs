using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

// Resultado de lectura; nunca contiene referencias mutables al catálogo ni al ACU.
public sealed class MYGInsumoContexto
{
    public MYGGrupoRecurso Grupo { get; internal set; }
    public string Codigo { get; internal set; }
    public string Descripcion { get; internal set; }
    public string Proveedor { get; internal set; }
    public string Unidad { get; internal set; }
    public decimal Cantidad { get; internal set; }
    public decimal Precio { get; internal set; }
    public decimal Total { get; internal set; }
}

public static class MYGListaInsumosContexto
{
    // La identidad local de un insumo sólo sirve dentro de su presupuesto.
    // Entre presupuestos se agrupan únicamente condiciones económicas iguales.
    private readonly record struct Clave(string Tipo, MYGGrupoRecurso Grupo, string Codigo,
        string Descripcion, string Proveedor, string Unidad, decimal Precio);

    private static string Normalizar(string texto) => (texto ?? "").Trim().ToUpperInvariant();
    private static string Proveedor(MYGInsumo insumo) =>
        string.IsNullOrWhiteSpace(insumo?.Proveedor) ? "SIN CLASIFICAR" : insumo.Proveedor.Trim();

    /// <summary>
    /// Sin presupuesto agrega todo el proyecto. Con presupuesto y título sólo
    /// incluye las partidas descendientes del título; sin título incluye el presupuesto.
    /// Las cantidades y los importes se obtienen del mismo motor que calcula el ACU.
    /// </summary>
    public static IReadOnlyList<MYGInsumoContexto> Crear(IEnumerable<MYGPresupuestoDocumento> presupuestos,
        MYGPresupuestoDocumento presupuesto = null, ItemPresupuestoDelphin titulo = null)
    {
        var seleccionados = presupuesto != null ? new[] { presupuesto } :
            (presupuestos ?? Enumerable.Empty<MYGPresupuestoDocumento>()).Where(p => p != null).Distinct().ToArray();
        if (seleccionados.Select(p => Normalizar(p.Costos.Moneda)).Distinct().Skip(1).Any())
            throw new InvalidDataException("La lista del proyecto contiene presupuestos con monedas distintas. " +
                "Seleccione un presupuesto para consultar sus insumos sin sumar monedas diferentes.");

        var resultado = new Dictionary<Clave, MYGInsumoContexto>();
        void Agregar(string tipo, MYGGrupoRecurso grupo, string codigo, string descripcion,
            string proveedor, string unidad, decimal cantidad, decimal precio, decimal total)
        {
            var clave = new Clave(tipo, grupo, Normalizar(codigo), Normalizar(descripcion),
                Normalizar(proveedor), Normalizar(unidad), precio);
            if (!resultado.TryGetValue(clave, out var fila))
                resultado.Add(clave, fila = new MYGInsumoContexto { Grupo = grupo, Codigo = codigo ?? "",
                    Descripcion = descripcion ?? "", Proveedor = proveedor, Unidad = unidad ?? "", Precio = precio });
            fila.Cantidad += cantidad;
            fila.Total += total;
        }

        foreach (var p in seleccionados)
        {
            var partidas = Partidas(p, presupuesto == null ? null : titulo);
            var calculo = MYGMotorPresupuestos.CrearCalculo(p);
            var insumos = p.Costos.Insumos.ToDictionary(i => i.Id, StringComparer.Ordinal);
            var revisadas = new Dictionary<ItemPresupuestoDelphin, bool>();
            void AgregarConsolidado(MYGInsumoConsolidado fila)
            {
                string tipo = "INSUMO", id = fila.Clave;
                if (id.StartsWith("PORCENTAJE:", StringComparison.Ordinal))
                { tipo = "PORCENTAJE"; id = id.Substring("PORCENTAJE:".Length); }
                // Un precio de partida sin ACU no identifica un insumo ni un
                // subcontrato. Sólo se conserva en el cálculo contable original.
                else if (id.StartsWith("DIRECTO:", StringComparison.Ordinal) && !insumos.ContainsKey(id)) return;
                else if (id == "REDONDEO") tipo = "REDONDEO";
                insumos.TryGetValue(id, out var insumo);
                Agregar(tipo, fila.Grupo, fila.Codigo, fila.Descripcion, Proveedor(insumo),
                    fila.Unidad, fila.Cantidad, fila.Precio, fila.Total);
            }

            // Consolidar omite líneas cuyos dos importes son cero. La vista de
            // insumos sí conserva los recursos referenciados, incluso con metrado
            // o coeficiente cero, sin incluir entradas del catálogo sin uso.
            bool IncluirReferencias(ItemPresupuestoDelphin partida)
            {
                if (revisadas.TryGetValue(partida, out bool tieneInsumos)) return tieneInsumos;
                tieneInsumos = false;
                foreach (var r in calculo.Analizar(partida).Recursos)
                {
                    if (r.Recurso.Grupo == MYGGrupoRecurso.Subpartidas)
                    { tieneInsumos |= IncluirReferencias(calculo.Subpartida(r.Recurso.SubpartidaIdLocal)); continue; }
                    var insumo = calculo.Insumo(r.Recurso.InsumoId);
                    tieneInsumos = true;
                    bool porcentaje = r.Recurso.Modo == MYGModoCantidad.PorcentajeManoObra;
                    Agregar(porcentaje ? "PORCENTAJE" : "INSUMO", porcentaje ? MYGGrupoRecurso.Equipo : r.Recurso.Grupo,
                        r.Codigo, r.Descripcion + (porcentaje ? " (% mano de obra)" : ""), Proveedor(insumo),
                        porcentaje ? p.Costos.Moneda : r.Unidad, 0, porcentaje ? 1m : r.Precio, 0);
                }
                revisadas.Add(partida, tieneInsumos);
                return tieneInsumos;
            }

            foreach (var partida in partidas)
            {
                // Tampoco se fabrica un ajuste como sustituto de una partida
                // sin recursos, aunque tenga precio o parcial nativo importado.
                if (!IncluirReferencias(partida)) continue;
                var filas = calculo.Consolidar(partida);
                foreach (var fila in filas) AgregarConsolidado(fila);
                // Un parcial importado puede conservar un redondeo propio que
                // no resulta de multiplicar el metrado por el precio importado.
                // La conciliación usa el consolidado contable completo para no
                // convertir los precios directos omitidos en ajustes ficticios.
                decimal diferencia = calculo.TotalPartida(partida) - filas.Sum(f => f.Total);
                if (diferencia != 0)
                    Agregar("PARCIAL_IMPORTADO", MYGGrupoRecurso.Equipo, "", "Ajuste por redondeo importado",
                        "SIN CLASIFICAR", p.Costos.Moneda, diferencia, 1m, diferencia);
            }
        }
        return resultado.Values.OrderBy(f => f.Grupo).ThenBy(f => f.Codigo, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(f => f.Descripcion, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(f => f.Proveedor, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(f => f.Unidad, StringComparer.CurrentCultureIgnoreCase).ThenBy(f => f.Precio).ToArray();
    }

    private static List<ItemPresupuestoDelphin> Partidas(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin titulo)
    {
        if (titulo == null) return presupuesto.Items.Where(i => !MYGProyectoStorage.EsTitulo(i)).ToList();
        var raiz = presupuesto.Items.FirstOrDefault(i => ReferenceEquals(i, titulo));
        if (raiz == null || !MYGProyectoStorage.EsTitulo(raiz))
            throw new InvalidDataException("Seleccione un título perteneciente al presupuesto para consultar sus insumos.");
        var hijos = presupuesto.Items.Where(i => i.ParentId != null).GroupBy(i => i.ParentId, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => g.ToArray(), StringComparer.Ordinal);
        var pendientes = new Stack<ItemPresupuestoDelphin>();
        var visitados = new HashSet<ItemPresupuestoDelphin>();
        var partidas = new List<ItemPresupuestoDelphin>();
        pendientes.Push(raiz);
        while (pendientes.TryPop(out var actual))
        {
            if (!visitados.Add(actual)) throw new InvalidDataException("La estructura del título contiene una referencia circular.");
            if (!MYGProyectoStorage.EsTitulo(actual)) { partidas.Add(actual); continue; }
            if (actual.Id != null && hijos.TryGetValue(actual.Id, out var descendientes))
                for (int n = descendientes.Length - 1; n >= 0; n--) pendientes.Push(descendientes[n]);
        }
        return partidas;
    }
}
