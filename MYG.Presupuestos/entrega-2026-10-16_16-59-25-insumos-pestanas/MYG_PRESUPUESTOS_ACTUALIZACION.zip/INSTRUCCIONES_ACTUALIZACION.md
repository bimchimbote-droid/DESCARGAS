# Actualización: insumos reales y eliminación de pestañas inferiores

## A. Resumen de la implementación

- La lista contextual de insumos de un título, presupuesto o proyecto ya no convierte las partidas sin ACU en subcontratos. Esto incluye partidas vacías con metrado, precios directos, parciales nativos importados y cadenas de subpartidas que no contienen insumos.
- Los subcontratos registrados expresamente y los insumos reales de subpartidas siguen apareciendo. Se conservan recursos referenciados con cantidad cero, IGV, herramientas por porcentaje, proveedores y ajustes reales.
- Los precios directos permanecen en el costo del presupuesto y en SIN DESGLOSE del gráfico. El total de insumos puede ser menor que el costo directo cuando existen partidas sin desglose; esa diferencia no es un insumo ni un subcontrato.
- Se eliminan las pestañas inferiores Proyecto / Presupuesto, Lista de Insumos y Lista de Costos, junto con el espacio que ocupaban. Se conservan las dos pestañas superiores de insumos del presupuesto/proyecto y las pestañas de detalle de cada partida. La navegación confirma la edición pendiente antes de cambiar de vista.

## Base y compatibilidad

Código: bimchimbote-droid/MYG.Presupuestos, rama main, commit 48765e07163a63217f87048fb4a6a1a76b5b504d.
Esta entrega incremental conserva las actualizaciones posteriores del repositorio independiente bimchimbote-droid/DESCARGAS:
1. entrega-2026-10-16_15-54-28 (costo directo, identificadores y fuente).
2. entrega-2026-10-16_16-37-34 (resumen sin Total automático y lista contextual de insumos), publicada en commit 6dab670c375217a06b5bb4256e43675f518e9181.

La captura corresponde a esa segunda actualización. Aplique este ZIP sobre esa versión. Si parte solamente de main, necesita aplicar primero ambas entregas anteriores en ese orden; no mezcle archivos de versiones distintas.

## B. Archivos que debo reemplazar

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | INSTRUCCIONES_ACTUALIZACION.md | REEMPLAZAR | Instrucciones de esta entrega. |
| 2 | MYG.Core/InsumosContextoMYG.cs | REEMPLAZAR | Excluye partidas sin recursos y evita ajustes que las sustituyan. |
| 3 | MYG.Desktop/PresupuestosPanel.cs | REEMPLAZAR | Retira la barra inferior y conserva las vistas internas sin pestañas. |
| 4 | MYG.Desktop/PresupuestosEstructuraPanel.cs | REEMPLAZAR | Recupera la vista principal al seleccionar un nodo. |
| 5 | MYG.Desktop/PresupuestosHerramientasPanel.cs | REEMPLAZAR | Mantiene las herramientas ACU ligadas a la vista activa. |
| 6 | MYG.Pruebas/InsumosContextoCheck.cs | REEMPLAZAR | Regresiones de partidas vacías, directos, subpartidas, ajustes y subcontratos reales. |
| 7 | MYG.PruebasUI/InsumosContextoUICheck.cs | REEMPLAZAR | Comprueba ausencia de pestañas, uso del espacio y navegación/filtros. |
| 8 | MYG.PruebasUI/Program.cs | REEMPLAZAR | Adapta navegación de las comprobaciones de herramientas ACU. |

Todos los archivos se entregan completos. No hay archivos que eliminar ni parches pendientes. El ZIP no contiene el proyecto completo, ejecutables, bases de datos, dependencias ni metadatos Git.

## C. Descarga

El archivo MYG_PRESUPUESTOS_ACTUALIZACION.zip se publica en una ruta nueva de bimchimbote-droid/DESCARGAS. La respuesta de entrega contiene el enlace HTTPS fijado al commit y el resultado de su comprobación mediante descarga, SHA-256 e integridad ZIP. No se sobrescriben entregas anteriores.

## D. Instalación manual

1. En Visual Studio > Cambios de Git confirme o respalde sus cambios locales. Cierre la aplicación MYG.
2. Descargue el ZIP y extráigalo fuera del proyecto.
3. Copie sus ocho archivos a la raíz de su proyecto, conservando las rutas relativas. Ejemplo de carpeta: D:\ADDIN\repos\MYG.Presupuestos_GITHUB.
4. Reemplace únicamente los archivos de la tabla. Si alguno tiene cambios locales o posteriores a la base indicada, compare y fusione antes de sustituirlo.
5. Abra MYG.Presupuestos.sln, restaure dependencias y compile Release; ejecute las pruebas siguientes.
6. Abra MYG y seleccione un título o presupuesto: sólo deben mostrarse insumos utilizados. Una partida sin ACU con cantidad positiva o precio directo no debe generar una fila SUB-CONTRATOS.
7. Compruebe que no aparece la barra inferior indicada, que la lista conserva las dos pestañas superiores y que volver a una partida recupera su detalle. Pruebe filtros, cambio de tema, copiar, Excel y vista previa; guardar/reabrir debe conservar todos los importes.

## E. Configuraciones adicionales

C#, SDK .NET 10.0.100 y SQLite. No se agregan paquetes, migraciones, credenciales ni cambios de solución/proyectos. Los proyectos SDK incluyen automáticamente los archivos C#.

## F. Compilación y validación

Desde la raíz del proyecto:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

Para ejecutar las pruebas de interfaz en Windows:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

Resultado de esta entrega:
- Compilación completa Release: 0 errores y 0 advertencias, incluidos escritorio, pruebas UI y conector Revit.
- Suite funcional: 405 comprobaciones aprobadas; incluye SQLite real, firmas históricas, incidencia, precios directos, subcontratos explícitos y ajustes nativos.
- Las comprobaciones UI se compilaron, pero no se ejecutaron en Linux: necesitan Windows Desktop.
- Named Pipes de Windows fue omitida por el runner. Las muestras externas opcionales MYG_QA_LEGACY_JSON y MYG_QA_DELPHIN_SQLITE no se ejecutaron.
- El parámetro UseRevitReferencePackages permite compilar el conector sin Revit instalado. No demuestra ejecución de Revit, del instalador ni de licencias reales.
- El ZIP se comprueba por integridad, rutas y coincidencia de bytes con los ocho archivos finales antes de publicarlo.

## G. Publicación del código en GitHub

Sólo se publica el ZIP en el repositorio independiente DESCARGAS. No se hace Commit ni Push al repositorio del código y no se modifica su rama main.

Después de aplicar y validar, en Visual Studio > Cambios de Git:
1. Compruebe que está en main o en su rama de trabajo elegida.
2. Revise las diferencias y confirme únicamente los cambios deseados.
3. Haga Commit y después Push.
4. Abra bimchimbote-droid/MYG.Presupuestos en GitHub y verifique el commit en la rama correcta.

## H. Advertencias y pendientes

- Reemplazar archivos completos puede perder modificaciones locales/posteriores: respalde y compare.
- Este ZIP supone instaladas las dos entregas anteriores indicadas en Base y compatibilidad.
- La interfaz y la navegación visual deben comprobarse en Windows; no se presentan como ejecutadas en este entorno.
- No se modifican bases de datos ni se elimina información. Publicar el ZIP no aplica los cambios automáticamente en su PC.

