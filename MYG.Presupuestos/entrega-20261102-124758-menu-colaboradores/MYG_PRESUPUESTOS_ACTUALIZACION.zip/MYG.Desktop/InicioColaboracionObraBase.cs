#nullable enable
using System.IO;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private bool abriendoColaboradores;

    private Task ColaboracionObraBaseAsync(string ruta, string documentoId, bool agregar) =>
        GestionarColaboradoresAsync(agregar, async cliente =>
        {
            var vinculo = VinculoColaboracionObra(ruta, documentoId)
                ?? throw new InvalidOperationException("La obra no tiene vínculo de nube. Vuelva a abrirla desde Nube MYG.");
            SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
            if (CopiaSqliteNube.EsBase(ruta))
                return await PrepararColaboracionObraAsync(cliente, vinculo.ProyectoId, ruta, documentoId);
            var lista = await cliente.ListarProyectosAsync();
            ComprobarClienteActual(cliente);
            return lista.SingleOrDefault(p => p.Id == vinculo.ProyectoId && p.Alcance == "obra" && !p.EliminacionPendiente)
                ?? throw new InvalidOperationException("La obra ya no está disponible para su cuenta. Actualice sus permisos.");
        });

    // El editor conserva su acceso a la misma gestión independiente; no abre
    // el explorador general ni vuelve a elegir otra obra.
    private Task MostrarColaboracionObraAsync(Guid id) => GestionarColaboradoresAsync(false, async cliente =>
    {
        var lista = await cliente.ListarProyectosAsync();
        ComprobarClienteActual(cliente);
        return lista.SingleOrDefault(p => p.Id == id && p.Alcance == "obra" && !p.EliminacionPendiente)
            ?? throw new InvalidOperationException("La obra no está disponible para su cuenta.");
    });

    private async Task GestionarColaboradoresAsync(bool agregar,
        Func<ClienteSupabase, Task<ProyectoNube?>> preparar)
    {
        if (abriendoColaboradores)
            throw new InvalidOperationException("Espere a que termine la gestión de colaboradores actual.");
        abriendoColaboradores = true;
        try
        {
            RequerirSesion();
            PrepararConfiguracionNube();
            ActualizarSesionNube();
            if (clienteNube is null)
                throw new InvalidOperationException(errorConfiguracionNube
                    ?? "No se encontró la conexión de Nube MYG. Solicite a soporte que revise la instalación.");
            await MYGCargaAnimada.EjecutarAsync(this, "Conectando con su cuenta MYG…", ConectarNubeConMygAsync);
            var cliente = RequerirNube();
            var obra = await preparar(cliente);
            ComprobarClienteActual(cliente);
            if (obra is null) return;
            using var dialogo = new ColaboradoresObraForm(sesion, cliente, obra, agregar);
            await MYGCargaAnimada.EjecutarAsync(this, "Consultando colaboradores de la obra…", dialogo.CargarAsync);
            ComprobarClienteActual(cliente);
            dialogo.ShowDialog(this);
        }
        finally { abriendoColaboradores = false; }
    }

    private async Task<ProyectoNube?> PrepararColaboracionObraAsync(ClienteSupabase cliente,
        Guid baseId, string ruta, string documentoId)
    {
        var consulta = await MYGCargaAnimada.EjecutarAsync(this, "Consultando la colaboración de la obra…", async () =>
        {
            var proyectos = await cliente.ListarProyectosAsync();
            ComprobarClienteActual(cliente);
            if (!proyectos.Any(p => p.Id == baseId && p.Alcance == "base"
                && p.Rol == "propietario" && !p.EliminacionPendiente))
                throw new InvalidOperationException("Solo el propietario de una base disponible puede preparar sus obras para colaboración.");
            var publicadas = await cliente.ListarObrasBaseAsync(baseId);
            ComprobarClienteActual(cliente);
            return publicadas.SingleOrDefault(o => o.DocumentoId == documentoId);
        });
        ComprobarClienteActual(cliente);
        if (consulta is not null) return consulta.Proyecto;
        var resumen = await Task.Run(() => MYGBaseDatos.ListarProyectos(ruta)
            .SingleOrDefault(p => p.Id == documentoId));
        ComprobarClienteActual(cliente);
        if (resumen is null) throw new InvalidOperationException("La obra elegida ya no está en esta base.");
        if (WinForms.MessageBox.Show(this,
            "Se preparará una copia colaborativa de la obra «" + resumen.Nombre + "».\n\n"
            + "La base completa y las demás obras seguirán privadas. La copia tendrá su propia revisión: "
            + "sus cambios no se incorporan automáticamente a la base original. Para trabajar juntos, "
            + "abra la entrada Obra desde Nube MYG.\n\n¿Continuar con esta obra?",
            "Colaboración de esta obra", WinForms.MessageBoxButtons.OKCancel,
            WinForms.MessageBoxIcon.Information) != WinForms.DialogResult.OK) return null;
        ComprobarClienteActual(cliente);
        var almacen = new PublicacionObraBasePendiente(Path.Combine(CarpetaNube, "colaboracion-obras"),
            cliente.UrlServidor, cliente.UsuarioId!);
        var obra = await MYGCargaAnimada.EjecutarAsync(this, "Preparando la colaboración de esta obra…", async () =>
        {
            await PrepararPublicacionBaseAsync(ruta);
            ComprobarClienteActual(cliente);
            return await Task.Run(() => almacen.PrepararYEnviarAsync(cliente, baseId, ruta, documentoId));
        });
        ComprobarClienteActual(cliente);
        return obra.Proyecto;
    }
}
