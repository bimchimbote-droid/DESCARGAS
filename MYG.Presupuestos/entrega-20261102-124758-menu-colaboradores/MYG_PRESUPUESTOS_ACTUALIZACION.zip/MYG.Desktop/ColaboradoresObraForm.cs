#nullable enable
using MYG.Colaboracion;
using MYG.Externo;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

/// <summary>Administra exclusivamente la obra elegida desde Inicio. El cliente pertenece al llamador.</summary>
internal sealed class ColaboradoresObraForm : WinForms.Form
{
    private readonly SesionDesktop sesion;
    private readonly ClienteSupabase cliente;
    private readonly Guid proyectoId;
    private readonly string usuarioMygInicial, usuarioIdInicial;
    private readonly bool enfocarAgregar;
    private readonly CancellationTokenSource vida = new();
    private readonly CancellationToken tokenVida;
    private ProyectoNube proyecto;
    private bool ocupado, cargado, identidadRevocada;
    private readonly List<WinForms.Button> acciones = new();
    private readonly WinForms.Label titulo = new() { Name = "obraColaboradores", Dock = WinForms.DockStyle.Fill,
        AutoEllipsis = true, TextAlign = Drawing.ContentAlignment.MiddleLeft };
    private readonly WinForms.Label estado = new() { Name = "estadoColaboradoresObra", Dock = WinForms.DockStyle.Fill,
        AutoEllipsis = true };
    private readonly WinForms.TextBox usuarioColaborador = new() { Name = "usuarioColaboradorMyg",
        Dock = WinForms.DockStyle.Fill, PlaceholderText = "Usuario MYG del colaborador", MaxLength = 256 };
    private readonly WinForms.DataGridView miembros = Tabla("miembrosNube");
    private readonly WinForms.DataGridView solicitudes = Tabla("solicitudesNube");
    private readonly WinForms.ComboBox rol = new() { Name = "rolColaboracionNube", Width = 155,
        DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly WinForms.Button actualizar, compartirUsuario, aceptar, rechazar,
        cambiarRol, retirar, permisosMiembro, cerrar;

    internal ColaboradoresObraForm(SesionDesktop sesion, ClienteSupabase cliente,
        ProyectoNube proyecto, bool agregar = false)
    {
        this.sesion = sesion ?? throw new ArgumentNullException(nameof(sesion));
        this.cliente = cliente ?? throw new ArgumentNullException(nameof(cliente));
        this.proyecto = proyecto ?? throw new ArgumentNullException(nameof(proyecto));
        if (proyecto.Id == Guid.Empty || proyecto.Alcance != "obra")
            throw new InvalidOperationException("La colaboración requiere una obra concreta. La base completa no se puede compartir.");
        proyectoId = proyecto.Id;
        usuarioMygInicial = UsuarioMygActual;
        usuarioIdInicial = cliente.UsuarioId ?? "";
        enfocarAgregar = agregar;
        tokenVida = vida.Token;
        Name = "ventanaColaboradoresObra";
        MYGProyectoUI.Preparar(this, agregar ? "Agregar colaborador a la obra" : "Configurar colaboradores de la obra", 900, 680);
        MinimumSize = new(740, 580);

        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill,
            ColumnCount = 1, RowCount = 7, Padding = new(18) };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 42, 48, 0, 44, 86, 74, 44 })
            raiz.RowStyles.Add(alto == 0 ? new(WinForms.SizeType.Percent, 100) : new(WinForms.SizeType.Absolute, alto));
        titulo.Font = new("Segoe UI", 12, Drawing.FontStyle.Bold);
        titulo.Text = "Obra: " + proyecto.Nombre;
        raiz.Controls.Add(titulo, 0, 0);
        raiz.Controls.Add(new WinForms.Label { Name = "alcanceColaboradoresObra", Dock = WinForms.DockStyle.Fill,
            Text = "Los permisos se aplican únicamente a esta obra. La base completa y las otras obras conservan su privacidad." }, 0, 1);

        miembros.Columns.Add("UsuarioMyg", "Usuario MYG"); miembros.Columns.Add("Rol", "Rol");
        miembros.Columns.Add("Modulos", "Módulos en solo lectura");
        solicitudes.Columns.Add("UsuarioId", "Solicitante"); solicitudes.Columns.Add("Estado", "Estado");
        var paginas = new WinForms.TabControl { Dock = WinForms.DockStyle.Fill };
        var paginaMiembros = new WinForms.TabPage("Colaboradores"); paginaMiembros.Controls.Add(miembros);
        var paginaSolicitudes = new WinForms.TabPage("Solicitudes anteriores"); paginaSolicitudes.Controls.Add(solicitudes);
        paginas.TabPages.Add(paginaMiembros); paginas.TabPages.Add(paginaSolicitudes);
        raiz.Controls.Add(paginas, 0, 2);

        rol.Items.AddRange(new object[] { "lector", "editor", "administrador" }); rol.SelectedIndex = 0;
        var filaRol = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, WrapContents = false };
        filaRol.Controls.Add(new WinForms.Label { Text = "Rol a asignar", AutoSize = true, Margin = new(0, 8, 12, 0) });
        filaRol.Controls.Add(rol); raiz.Controls.Add(filaRol, 0, 3);
        var opciones = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, AutoScroll = true };
        aceptar = CrearBoton("Aceptar solicitud", "aceptarSolicitudNube", () => ResolverAsync(true));
        rechazar = CrearBoton("Rechazar solicitud", "rechazarSolicitudNube", () => ResolverAsync(false));
        cambiarRol = CrearBoton("Cambiar rol", "cambiarRolNube", () => CambiarRolAsync(false));
        retirar = CrearBoton("Retirar acceso", "retirarAccesoNube", () => CambiarRolAsync(true));
        permisosMiembro = CrearBoton("Permisos por módulo", "permisosModulosNube", CambiarPermisosAsync);
        foreach (var boton in new[] { aceptar, rechazar, cambiarRol, retirar, permisosMiembro }) opciones.Controls.Add(boton);
        raiz.Controls.Add(opciones, 0, 4);

        var acceso = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 2 };
        acceso.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        acceso.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 190));
        acceso.RowStyles.Add(new(WinForms.SizeType.Absolute, 27));
        acceso.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        var etiqueta = new WinForms.Label { Text = "Agregar por usuario MYG (solo propietario o administrador)", AutoSize = true };
        acceso.Controls.Add(etiqueta, 0, 0); acceso.SetColumnSpan(etiqueta, 2);
        acceso.Controls.Add(usuarioColaborador, 0, 1);
        compartirUsuario = CrearBoton("Agregar colaborador", "compartirUsuarioMyg", CompartirUsuarioAsync);
        compartirUsuario.Dock = WinForms.DockStyle.Fill;
        acceso.Controls.Add(compartirUsuario, 1, 1); raiz.Controls.Add(acceso, 0, 5);

        var pie = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 3 };
        pie.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        pie.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 125));
        pie.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 100));
        pie.Controls.Add(estado, 0, 0);
        actualizar = CrearBoton("Actualizar", "actualizarColaboradoresObra", CargarInternoAsync);
        pie.Controls.Add(actualizar, 1, 0);
        cerrar = MYGProyectoUI.Boton("Cerrar"); cerrar.Name = "cerrarColaboradoresObra";
        cerrar.DialogResult = WinForms.DialogResult.Cancel; pie.Controls.Add(cerrar, 2, 0);
        raiz.Controls.Add(pie, 0, 6); Controls.Add(raiz);
        CancelButton = cerrar;
        miembros.SelectionChanged += (_, _) => ActualizarAcciones();
        solicitudes.SelectionChanged += (_, _) => ActualizarAcciones();
        sesion.Cambio += CambioSesion;
        FormClosing += (_, e) => { if (ocupado) e.Cancel = true; };
        Disposed += (_, _) =>
        {
            sesion.Cambio -= CambioSesion;
            vida.Cancel(); vida.Dispose();
        };
        ActualizarAcciones();
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        if (enfocarAgregar && usuarioColaborador.Enabled) usuarioColaborador.Focus();
    }

    internal async Task CargarAsync()
    {
        if (ocupado) throw new InvalidOperationException("Espere a que termine la operación de colaboradores.");
        RevalidarIdentidad();
        ocupado = true; ActualizarAcciones();
        try { await CargarInternoAsync(); }
        finally { ocupado = false; ActualizarAcciones(); }
    }

    private string UsuarioMygActual => (sesion.Credencial?.Usuario ?? "").Trim().ToLowerInvariant();
    private bool IdentidadValida => !identidadRevocada && sesion.Autorizado && usuarioMygInicial.Length > 0
        && usuarioIdInicial.Length > 0 && UsuarioMygActual == usuarioMygInicial
        && cliente.SesionIniciada && cliente.UsuarioMygSesion == usuarioMygInicial
        && cliente.UsuarioId == usuarioIdInicial;
    private bool PuedeAdministrar => proyecto.Alcance == "obra" && !proyecto.EliminacionPendiente
        && proyecto.Rol is "propietario" or "administrador";

    private void RevalidarIdentidad()
    {
        if (IsDisposed || Disposing || tokenVida.IsCancellationRequested)
            throw new OperationCanceledException(tokenVida);
        if (!IdentidadValida)
            throw new InvalidOperationException("La cuenta MYG cambió o ya no está autorizada. Cierre esta ventana y vuelva a abrir la colaboración con su cuenta actual.");
    }

    private async Task ActualizarProyectoAsync()
    {
        RevalidarIdentidad();
        var proyectos = await cliente.ListarProyectosAsync(tokenVida);
        RevalidarIdentidad();
        var actual = proyectos.SingleOrDefault(p => p.Id == proyectoId);
        if (actual is null || actual.Alcance != "obra" || actual.EliminacionPendiente)
        {
            cargado = false; miembros.Rows.Clear(); solicitudes.Rows.Clear();
            throw new InvalidOperationException("La obra ya no está disponible para su cuenta o tiene una eliminación pendiente. No se cambiaron sus colaboradores.");
        }
        proyecto = actual;
        titulo.Text = "Obra: " + actual.Nombre;
    }

    private async Task CargarInternoAsync()
    {
        cargado = false;
        miembros.Rows.Clear(); solicitudes.Rows.Clear();
        await ActualizarProyectoAsync();
        var listaMiembros = await cliente.ListarMiembrosAsync(proyectoId, tokenVida);
        RevalidarIdentidad();
        var listaSolicitudes = PuedeAdministrar ? await cliente.ListarSolicitudesAsync(proyectoId, tokenVida) : null;
        RevalidarIdentidad();
        miembros.Rows.Clear(); solicitudes.Rows.Clear();
        int nombresPendientes = 0;
        foreach (var miembro in listaMiembros)
        {
            string? nombre = miembro.ObtenerUsuarioMyg(usuarioIdInicial, usuarioMygInicial);
            if (nombre is null) nombresPendientes++;
            int indice = miembros.Rows.Add(nombre ?? "Usuario MYG no disponible", miembro.Rol, ResumenPermisos(miembro));
            miembros.Rows[indice].Tag = miembro;
            miembros.Rows[indice].Cells["UsuarioMyg"].ToolTipText = nombre is null
                ? "Vinculación MYG pendiente. Identificador interno: " + miembro.UsuarioId
                : "Usuario MYG: " + nombre;
        }
        if (listaSolicitudes is not null)
            foreach (var solicitud in listaSolicitudes)
            {
                int indice = solicitudes.Rows.Add(solicitud.UsuarioId, solicitud.Estado);
                solicitudes.Rows[indice].Tag = solicitud;
            }
        cargado = true;
        estado.Text = PuedeAdministrar
            ? "Agregue un usuario MYG o seleccione un colaborador para configurar sus permisos."
            : "Solo el propietario o administrador puede configurar los colaboradores.";
        if (nombresPendientes > 0)
            estado.Text = "Falta recibir el usuario MYG de " + nombresPendientes + " miembro(s). Revise su vinculación en el servidor.";
    }

    private async Task ExigirAdministracionActualAsync()
    {
        if (!cargado) throw new InvalidOperationException("Actualice la lista de colaboradores antes de continuar.");
        await ActualizarProyectoAsync();
        if (!PuedeAdministrar)
            throw new InvalidOperationException("Solo el propietario o administrador de esta obra puede configurar sus colaboradores.");
    }

    private async Task CompartirUsuarioAsync()
    {
        await ExigirAdministracionActualAsync();
        string usuario = usuarioColaborador.Text.Trim().ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(usuario)) throw new InvalidOperationException("Introduzca el usuario MYG del colaborador.");
        using var elegir = new PermisosModulosNubeForm(usuario, null, permitirRol: true);
        if (elegir.ShowDialog(this) != WinForms.DialogResult.OK) return;
        await ExigirAdministracionActualAsync();
        await cliente.CompartirConUsuarioMygAsync(proyectoId, usuario, elegir.Rol, elegir.Permisos, tokenVida);
        RevalidarIdentidad(); usuarioColaborador.Clear();
        await CargarInternoAsync();
        estado.Text = "Acceso confirmado para esta obra. El colaborador puede actualizar Compartidos conmigo en Nube MYG.";
    }

    private async Task ResolverAsync(bool permitir)
    {
        if (solicitudes.CurrentRow?.Tag is not SolicitudNube solicitud || solicitud.Estado != "pendiente")
            throw new InvalidOperationException("Seleccione una solicitud pendiente de esta obra.");
        string nuevoRol = rol.SelectedItem as string ?? "lector";
        await ExigirAdministracionActualAsync();
        await cliente.ResolverSolicitudAsync(proyectoId, solicitud.UsuarioId, nuevoRol, permitir, tokenVida);
        RevalidarIdentidad(); await CargarInternoAsync();
    }

    private async Task CambiarRolAsync(bool eliminar)
    {
        var miembro = RequerirMiembroEditable();
        await ExigirAdministracionActualAsync();
        if (eliminar && WinForms.MessageBox.Show(this, "¿Retirar el acceso de este colaborador a la obra?",
            "Colaboradores de la obra", WinForms.MessageBoxButtons.YesNo,
            WinForms.MessageBoxIcon.Question) != WinForms.DialogResult.Yes) return;
        if (eliminar) await ExigirAdministracionActualAsync();
        else RevalidarIdentidad();
        await cliente.CambiarRolAsync(proyectoId, miembro.UsuarioId,
            eliminar ? null : rol.SelectedItem as string ?? "lector", tokenVida);
        RevalidarIdentidad(); await CargarInternoAsync();
    }

    private async Task CambiarPermisosAsync()
    {
        var miembro = RequerirMiembroEditable();
        await ExigirAdministracionActualAsync();
        using var elegir = new PermisosModulosNubeForm(
            miembro.ObtenerUsuarioMyg(usuarioIdInicial, usuarioMygInicial) ?? "no disponible (vinculación pendiente)",
            miembro.PermisosModulos, permitirRol: false, miembro.Rol);
        if (elegir.ShowDialog(this) != WinForms.DialogResult.OK) return;
        await ExigirAdministracionActualAsync();
        await cliente.CambiarPermisosMiembroAsync(proyectoId, miembro.UsuarioId, elegir.Permisos, tokenVida);
        RevalidarIdentidad(); await CargarInternoAsync();
        estado.Text = "Permisos confirmados. Los módulos bloqueados permanecen visibles en solo lectura.";
    }

    private MiembroNube RequerirMiembroEditable() => miembros.CurrentRow?.Tag is MiembroNube m && m.Rol != "propietario"
        ? m : throw new InvalidOperationException("Seleccione un colaborador editable de esta obra; el propietario conserva su acceso.");

    private void ActualizarAcciones()
    {
        if (IsDisposed || Disposing) return;
        bool disponible = !ocupado && IdentidadValida;
        foreach (var accion in acciones) accion.Enabled = disponible;
        bool administra = disponible && cargado && PuedeAdministrar;
        compartirUsuario.Enabled = usuarioColaborador.Enabled = administra;
        bool miembroEditable = miembros.CurrentRow?.Tag is MiembroNube m && m.Rol != "propietario";
        cambiarRol.Enabled = retirar.Enabled = permisosMiembro.Enabled = administra && miembroEditable;
        aceptar.Enabled = rechazar.Enabled = administra
            && solicitudes.CurrentRow?.Tag is SolicitudNube s && s.Estado == "pendiente";
        rol.Enabled = administra;
        cerrar.Enabled = !ocupado;
        if (!IdentidadValida) estado.Text = "Se requiere la misma sesión MYG autorizada para esta obra.";
        else if (ocupado) estado.Text = "Consultando o actualizando colaboradores…";
    }

    private void CambioSesion()
    {
        if (IsDisposed || Disposing) return;
        if (InvokeRequired) { BeginInvoke((Action)CambioSesion); return; }
        if (!IdentidadValida)
        {
            identidadRevocada = true; cargado = false;
            vida.Cancel(); miembros.Rows.Clear(); solicitudes.Rows.Clear();
        }
        ActualizarAcciones();
    }

    private async Task EjecutarAsync(Func<Task> accion)
    {
        if (ocupado || IsDisposed || Disposing) return;
        ocupado = true; ActualizarAcciones();
        Exception? error = null;
        try { RevalidarIdentidad(); await accion(); }
        catch (OperationCanceledException) when (tokenVida.IsCancellationRequested) { }
        catch (Exception ex) { error = ex; }
        finally { ocupado = false; ActualizarAcciones(); }
        if (error is not null && !IsDisposed && !Disposing)
        { estado.Text = error.Message; MYGProyectoUI.Error(this, error); }
    }

    private WinForms.Button CrearBoton(string texto, string nombre, Func<Task> accion)
    {
        var boton = MYGProyectoUI.Boton(texto);
        boton.Name = nombre; boton.AutoSize = true; boton.Height = 34; boton.Margin = new(3);
        MYGAnimacionUI.PrepararBoton(boton);
        boton.Click += async (_, _) => await EjecutarAsync(accion);
        acciones.Add(boton); return boton;
    }

    private static WinForms.DataGridView Tabla(string nombre)
    {
        var tabla = MYGBibliotecaUI.Tabla();
        tabla.Name = nombre; tabla.ReadOnly = true; tabla.MultiSelect = false;
        tabla.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect;
        tabla.AutoSizeColumnsMode = WinForms.DataGridViewAutoSizeColumnsMode.Fill;
        return tabla;
    }

    private static string ResumenPermisos(MiembroNube miembro)
    {
        if (miembro.Rol == "lector") return "Todos";
        if (miembro.PermisosModulos is not { } permisos) return "Sin restricciones por módulo (servidor anterior)";
        var lectura = new List<string>();
        if (!permisos.Acu) lectura.Add("ACU");
        if (!permisos.Especificaciones) lectura.Add("Especificaciones");
        if (!permisos.MetradosExcel) lectura.Add("Metrados Excel");
        if (!permisos.MetradosRevitDisponible || !permisos.MetradosRevit) lectura.Add("Metrados Revit");
        return lectura.Count == 0 ? "Ninguno" : string.Join(", ", lectura);
    }
}
