# Colaboradores desde el menú de cada obra

Esta actualización se aplica sobre la entrega anterior de colaboradores por obra
(publicada en DESCARGAS, commit `287137acbbddb31be09d6e1afee023eee357a469`).
El código base sigue siendo `bimchimbote-droid/MYG.Presupuestos`, rama `main`,
commit `83974008e17cf37a292a75d5e18db7a49523ee46`.

## Comportamiento

La ventana Nube MYG queda como explorador: conserva listas, conexión, publicación,
apertura, descarga y eliminación. Se retiran sus controles de miembros,
solicitudes, roles, permisos y alta de colaboradores. El listado ocupa el espacio
que antes tenía ese panel.

En Inicio, el menú ⋮ de una obra vinculada a nube muestra:

- Abrir obra
- Agregar colaborador…
- Configurar colaboradores…

Las dos opciones de colaboradores abren una ventana independiente para la obra
exacta de esa fila, sin abrir el explorador Nube MYG ni seleccionar otra obra.
Agregar colaborador enfoca el campo Usuario MYG; Configurar colaboradores permite
consultar miembros, cambiar roles, configurar permisos por módulo y retirar acceso.
Se conservan también las solicitudes anteriores y su resolución.

Solo propietario o administrador pueden modificar accesos. El estado vigente del
servidor se consulta antes de habilitar la gestión y antes de las operaciones.
La base completa y las demás obras siguen privadas. Para una base sin vínculo,
el menú conserva Publicar base completa… antes de poder compartir sus obras.
El botón Colaboración del editor abre la misma gestión independiente.

La primera vez se confirma la preparación de una copia colaborativa de la obra
elegida. Su revisión es independiente: los cambios no se incorporan automáticamente
al respaldo SQLite original. Propietario y colaboradores deben abrir la entrada
Obra en Nube MYG para trabajar juntos. Si ya existe una obra publicada, se
conservan sus ediciones remotas. Los reintentos siguen conservando paquete,
hash y UUID de la entrega anterior.

## Instalación manual

1. Cierre MYG. Respalde o confirme sus cambios locales.
2. Verifique que tiene aplicada la entrega anterior indicada arriba; este ZIP
   contiene únicamente los archivos nuevos o modificados desde esa entrega.
3. Extraiga el ZIP fuera de su copia de trabajo y copie sus archivos a la raíz
   de MYG.Presupuestos conservando las rutas relativas.
4. Compare los archivos existentes antes de reemplazar si tiene modificaciones
   locales o posteriores. No se elimina ningún archivo ni se modifica ninguna
   base de datos.
5. Desde la raíz, con SDK .NET 10:

   ```powershell
   dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -p:UseSharedCompilation=false -m:1 -nr:false
   dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --colaboracion-obra
   ```

6. En Windows, ejecute las pruebas de interfaz:

   ```powershell
   dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
   ```

## Comprobación manual en Windows

- Nube MYG no debe mostrar campos ni botones de colaboradores; la lista ocupa
  el ancho disponible.
- En una base de prueba con dos obras, abra ⋮ de la segunda y compruebe que el
  título de la gestión identifica esa segunda obra.
- Agregar colaborador debe enfocar Usuario MYG y permitir escoger rol y módulos.
- Configurar colaboradores debe mostrar los miembros de esa obra, permitir
  cambiar permisos y retirar acceso, y proteger siempre al propietario.
- Cancelar la preparación inicial no debe publicar otra copia.
- Con otra cuenta, confirme que Compartidos conmigo muestra únicamente la obra
  autorizada, sin la base privada ni su obra vecina.
- Compruebe también lector, sesión cambiada y retirada de permisos.

## Dependencias y validación

No hay paquetes, referencias, proyectos, lockfiles ni migraciones nuevos. Se
utiliza el soporte de bases/obras ya instalado con la entrega anterior. No se
realizan cambios SQL ni se consulta producción para las pruebas.

Validación actual: SDK .NET 10.0.100, Linux x64; solución Release con 0 errores y
0 advertencias; 206 comprobaciones de colaboración por obra aprobadas, con SQLite
real y HTTP simulado. Las pruebas UI nuevas compilaron; no se ejecutaron en Linux.
Cubren ausencia de controles en el explorador, menú por obra, identidad fija,
rol vigente, protección del propietario, cambio de cuenta, lectura y escritura
sobre el UUID correcto y obras no disponibles.

La suite completa de Nube mantiene un fallo previo en
PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar (expectativa de RPC
posterior frente a expiración durante consulta de estado), ajeno a este cambio.
No se modificó esa prueba ni se presenta la suite completa como aprobada.
Windows Forms, licencia real y Revit no se ejecutaron en este entorno Linux.

## Revisión y publicación del código

En Visual Studio, abra Cambios de Git, revise los archivos y valide la interfaz
en Windows. Después haga Commit y Push en su rama de trabajo y compruebe la rama
y el commit en GitHub. Publicar el ZIP en DESCARGAS no actualiza main del código
ni aplica los cambios a su equipo. Las entregas anteriores se conservan.
