using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class NubeBaseUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var sesion = new SesionDesktop();
        using var nube = new NubeForm(sesion, null);
        var tabla = Campo<DataGridView>(nube, "propios");
        exige(tabla.Columns.Contains("Tamano") && tabla.Columns["Tamano"].HeaderText == "Tamaño en nube",
            "La lista debe mostrar el tamaño junto a cada proyecto.");
        exige(tabla.Columns.Contains("Tipo") && tabla.Columns["Tipo"].HeaderText == "Tipo"
            && tabla.Columns["Tipo"].DisplayIndex == 1,
            "La lista debe distinguir el tipo de entrada junto al nombre del proyecto.");
        var basePrivada = new ProyectoNube(Guid.NewGuid(), "MYG-BASE", "Base privada", "propietario", 1,
            "base", default) { TamanoBytes = 1536 * 1024 };
        int fila = tabla.Rows.Add(basePrivada.Nombre, basePrivada.Codigo, basePrivada.Rol, 1, "1,50 MiB");
        tabla.Rows[fila].Tag = basePrivada;
        tabla.CurrentCell = tabla.Rows[fila].Cells[0];
        Llamar(nube, "CambioSeleccion");
        exige(Campo<Label>(nube, "detalle").Text.Contains("1", StringComparison.Ordinal)
            && Campo<Label>(nube, "detalle").Text.Contains("MiB", StringComparison.Ordinal)
            && Campo<Label>(nube, "detalle").Text.Contains("mismo archivo SQLite", StringComparison.Ordinal),
            "Seleccionar la base debe informar que todas sus obras usan el mismo archivo SQLite.");
        foreach (string alcance in new[] { "base", "obra" })
        {
            tabla.Rows[fila].Tag = basePrivada with { Alcance = alcance };
            Llamar(nube, "CambioSeleccion");
            VerificarExploradorSinColaboracion(nube, exige);
        }
        ColaboradoresObraUICheck.Ejecutar(exige);

        using var publicar = new NubePublicarForm(null, null);
        var modo = Campo<ComboBox>(publicar, "modo");
        modo.SelectedIndex = 2;
        exige(publicar.Alcance == "base" && modo.Items.Count == 3,
            "Todos los modos deben publicar una sola base completa, sin ofrecer obras aisladas.");
        exige(Campo<ListBox>(publicar, "proyectos").SelectionMode == SelectionMode.None,
            "La lista de obras debe ser informativa y no recortar el alcance del archivo.");
        exige(Campo<CheckBox>(publicar, "confirmarBase").Text.Contains("una sola base SQLite", StringComparison.Ordinal),
            "La confirmación debe explicar que se publica un único archivo con todas sus obras.");
        exige(Campo<Label>(publicar, "explicacion").Text.Contains("original se conserva", StringComparison.Ordinal),
            "La publicación debe indicar que conserva el archivo original.");
        VerificarInicio(sesion, exige);
    }

    private static void VerificarExploradorSinColaboracion(NubeForm nube, Action<bool, string> exige)
    {
        var controles = Controles(nube).ToArray();
        string[] retirados = { "miembrosNube", "solicitudesNube", "rolColaboracionNube", "usuarioColaboradorMyg",
            "compartirUsuarioMyg", "cargarColaboracionNube", "aceptarSolicitudNube", "rechazarSolicitudNube",
            "cambiarRolNube", "retirarAccesoNube", "permisosModulosNube" };
        exige(!controles.Any(c => retirados.Contains(c.Name, StringComparer.Ordinal)),
            "Nube MYG debe retirar sus controles de colaboración, también para una obra propia: no basta con ocultarlos o deshabilitarlos.");
        exige(!controles.OfType<Button>().Any(b => b.Text.Contains("colaborador", StringComparison.OrdinalIgnoreCase)
            || b.Text.Contains("colaboración", StringComparison.OrdinalIgnoreCase)
            || b.Text.Contains("solicitud", StringComparison.OrdinalIgnoreCase)
            || b.Text is "Elegir obra…" or "Cambiar rol" or "Retirar acceso" or "Permisos por módulo"),
            "El explorador debe concentrarse en listar, publicar, abrir, descargar y eliminar; los colaboradores se administran desde cada obra.");
        exige(Campo<TabControl>(nube, "paginas").Dock == DockStyle.Fill,
            "Al retirar el panel de colaboración, el listado debe ocupar el espacio disponible del explorador.");
    }

    private static void VerificarInicio(SesionDesktop sesion, Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Indice-Nube-UI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "trabajo.sqlite");
            var norte = MYGProyectoStorage.Nuevo("Obra Norte");
            var sur = MYGProyectoStorage.Nuevo("Obra Sur");
            MYGProyectoStorage.Guardar(ruta, norte); MYGProyectoStorage.Guardar(ruta, sur);
            byte[] original = File.ReadAllBytes(ruta);
            using var cliente = new ClienteSupabase("https://bases-ui.supabase.co", "sb_publishable_ui_sintetica", new AccesoSintetico());
            cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica").GetAwaiter().GetResult();
            var proyecto = new ProyectoNube(Guid.NewGuid(), "MYG-BASE", "Base de dos obras", "propietario", 3, "base", default);
            var remoto = new ProyectoSqliteNube(proyecto, norte.Id,
                new ArchivoSqliteNube("archivo-sintetico.sqlite", Convert.ToHexString(SHA256.HashData(original)), original.Length));
            CopiaSqliteNube.Vincular(ruta, remoto, cliente);
            using var inicio = new InicioForm(sesion);
            var lista = MYGBaseDatos.ListarProyectos(ruta);
            Poner(inicio, "rutaBase", ruta);
            Poner(inicio, "datos", lista);
            Llamar(inicio, "MostrarProyectos");
            var tabla = Campo<DataGridView>(inicio, "proyectos");
            exige(tabla.Columns["NUBE_OBRA"] is DataGridViewButtonColumn boton
                && boton.Text == "⋮" && boton.UseColumnTextForButtonValue,
                "Cada obra de Inicio debe conservar su botón de apertura.");
            exige(tabla.Rows.Count == 2 && tabla.Rows.Cast<DataGridViewRow>()
                .Select(r => ((MYGProyectoResumen)r.Tag).Id).ToHashSet().SetEquals(new[] { norte.Id, sur.Id }),
                "La lista local de la base descargada debe mostrar todas sus obras originales.");
            exige(tabla.Rows.Cast<DataGridViewRow>().All(r => r.Cells["NUBE_ESTADO"].Value.ToString().Contains("r3", StringComparison.Ordinal)),
                "Todas las obras deben mostrar la misma revisión de la base SQLite.");
            Llamar(inicio, "ExigirBaseLocalEditable");
            exige(File.ReadAllBytes(ruta).SequenceEqual(original),
                "Vincular y mostrar la lista no debe reescribir el archivo SQLite descargado.");
            VerificarMenuObra(inicio, sesion, tabla, exige);
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static void VerificarMenuObra(InicioForm inicio, SesionDesktop sesion,
        DataGridView tabla, Action<bool, string> exige)
    {
        bool autorizado = sesion.Autorizado;
        try
        {
            // Mostrar con la sesión sin autorizar evita una recarga de la base
            // sintética. Las acciones de esta prueba son locales y no usan red.
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, false);
            inicio.Show(); Application.DoEvents();
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
            Campo<Panel>(inicio, "contenido").Enabled = true;
            var componentes = Campo<Container>(inicio, "componentesMenusInicio");

            ContextMenuStrip AbrirMenuReal()
            {
                Llamar(inicio, "MenuObraNube", tabla,
                    new DataGridViewCellEventArgs(tabla.Columns["NUBE_OBRA"].Index, 0));
                return componentes.Components.OfType<ContextMenuStrip>().Single();
            }

            var menu = AbrirMenuReal();
            exige(menu.Visible && menu.Items[0].Text == "Abrir obra",
                "El botón de la obra debe mostrar el menú real registrado en Inicio.");
            var opciones = menu.Items.Cast<ToolStripItem>().ToArray();
            exige(opciones.Single(i => i.Name == "agregarColaboradorObra").Text == "Agregar colaborador…"
                && opciones.Single(i => i.Name == "configurarColaboradoresObra").Text == "Configurar colaboradores…",
                "El desplegable de cada obra debe ofrecer directamente agregar y configurar colaboradores.");
            exige(!opciones.Any(i => i.Text == "Colaboradores de esta obra…" || i.Text == "Información de la base en nube…"),
                "El menú no debe conservar el acceso anterior que regresaba al explorador general.");
            ToolStripDropDownClosingEventHandler cancelar = (_, e) => e.Cancel = true;
            menu.Closing += cancelar;
            menu.Close(ToolStripDropDownCloseReason.CloseCalled);
            Application.DoEvents();
            exige(menu.Visible && !menu.IsDisposed && componentes.Components.Cast<IComponent>().Contains(menu),
                "Cancelar Closing debe conservar el menú visible y registrado, sin programar su liberación.");
            menu.Closing -= cancelar;
            bool vivoDuranteClosed = false;
            int cierres = 0;
            menu.Closed += (_, _) => { cierres++; vivoDuranteClosed = !menu.IsDisposed; };
            menu.Close(ToolStripDropDownCloseReason.CloseCalled);
            exige(vivoDuranteClosed && cierres == 1 && !menu.IsDisposed,
                "El menú debe seguir vivo durante Closed y al volver de Close: WinForms aún está terminando su cierre.");
            Application.DoEvents();
            exige(menu.IsDisposed && !componentes.Components.Cast<IComponent>().Contains(menu),
                "El siguiente ciclo de Inicio debe liberar y desregistrar el menú cerrado.");

            Llamar(inicio, "MenuObraNube", tabla,
                new DataGridViewCellEventArgs(tabla.Columns["NUBE_OBRA"].Index, 1));
            var menuSegunda = componentes.Components.OfType<ContextMenuStrip>().Single();
            exige(tabla.CurrentRow.Index == 1
                && menuSegunda.Items.Cast<ToolStripItem>().Any(i => i.Name == "agregarColaboradorObra")
                && menuSegunda.Items.Cast<ToolStripItem>().Any(i => i.Name == "configurarColaboradoresObra"),
                "Abrir el desplegable de otra fila debe seleccionar esa obra y conservar ambas acciones, sin depender de la selección anterior.");
            menuSegunda.Close(); Application.DoEvents();
            exige(menuSegunda.IsDisposed,
                "El menú de otra obra también debe liberarse después del cierre.");

            int ejecuciones = 0;
            bool dentroDelClick = false, ejecutoDentroDelClick = false;
            var menuAccion = new ContextMenuStrip();
            var opcion = menuAccion.Items.Add("Acción local de apertura");
            opcion.Click += (_, _) =>
            {
                dentroDelClick = true;
                Llamar(inicio, "EjecutarDesdeMenuObraNube", (Func<Task>)(() =>
                {
                    ejecuciones++; ejecutoDentroDelClick |= dentroDelClick;
                    return Task.CompletedTask;
                }));
                dentroDelClick = false;
            };
            Llamar(inicio, "MostrarMenuObraNube", menuAccion);
            opcion.PerformClick();
            menuAccion.Close(ToolStripDropDownCloseReason.ItemClicked);
            exige(ejecuciones == 0,
                "Seleccionar una acción debe volver del clic y cerrar el desplegable antes de comenzar la operación.");
            Application.DoEvents(); Application.DoEvents();
            exige(ejecuciones == 1 && !ejecutoDentroDelClick && menuAccion.IsDisposed,
                "La operación debe ejecutarse exactamente una vez en el siguiente ciclo y el menú debe quedar liberado.");

            string rutaOriginal = Campo<string>(inicio, "rutaBase");
            string rutaLocal = Path.Combine(Path.GetDirectoryName(rutaOriginal), "copia-local.sqlite");
            File.Copy(rutaOriginal, rutaLocal);
            Poner(inicio, "rutaBase", rutaLocal);
            var menuLocal = AbrirMenuReal();
            exige(menuLocal.Items.Cast<ToolStripItem>().Any(i => i.Text == "Publicar base completa…")
                && !menuLocal.Items.Cast<ToolStripItem>().Any(i => i.Name is "agregarColaboradorObra" or "configurarColaboradoresObra"),
                "Una base local sin vínculo debe conservar su ruta de publicación y no administrar permisos remotos inexistentes.");
            menuLocal.Close(); Application.DoEvents();
            Poner(inicio, "rutaBase", rutaOriginal);

            var abiertoAlCerrar = AbrirMenuReal();
            int accionesTrasCerrar = 0;
            Llamar(inicio, "EjecutarDesdeMenuObraNube", (Func<Task>)(() =>
            { accionesTrasCerrar++; return Task.CompletedTask; }));
            inicio.Close();
            exige(inicio.IsDisposed && abiertoAlCerrar.IsDisposed,
                "Cerrar Inicio con un desplegable abierto debe liberar también el menú que todavía no emitió Closed.");
            Application.DoEvents();
            exige(accionesTrasCerrar == 0,
                "Una acción pendiente no debe abrir una obra ni procesar controles después de cerrar Inicio.");
        }
        finally
        {
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, autorizado);
        }
    }

    private sealed class AccesoSintetico : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            if (solicitud.RequestUri!.AbsolutePath != "/auth/v1/token")
                throw new InvalidOperationException("La prueba de lista local no debe consultar obras en la red.");
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonSerializer.Serialize(new { access_token = "acceso_ui",
                    refresh_token = "refresco_ui", expires_in = 3600,
                    user = new { id = "11111111-1111-4111-8111-111111111111" } }), Encoding.UTF8, "application/json")
            });
        }
    }

    private static IEnumerable<Control> Controles(Control raiz)
    {
        foreach (Control control in raiz.Controls)
        {
            yield return control;
            foreach (var descendiente in Controles(control)) yield return descendiente;
        }
    }

    private static void RechazaIndice(Func<object> accion, Action<bool, string> exige, string operacion)
    {
        try
        {
            object resultado = accion();
            if (resultado is Task tarea) tarea.GetAwaiter().GetResult();
            exige(false, operacion + " no debe editar el índice privado.");
        }
        catch (TargetInvocationException ex) when (ex.InnerException is InvalidOperationException)
        {
            exige(ex.InnerException.Message.Contains("índice privado", StringComparison.Ordinal),
                operacion + " debe informar la restricción del índice privado.");
        }
        catch (InvalidOperationException ex)
        {
            exige(ex.Message.Contains("índice privado", StringComparison.Ordinal),
                operacion + " debe informar la restricción del índice privado.");
        }
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static T Propiedad<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetProperty(nombre, Privados).GetValue(objeto);
    private static void Poner(object objeto, string nombre, object valor) =>
        objeto.GetType().GetField(nombre, Privados).SetValue(objeto, valor);
    private static object Llamar(object objeto, string nombre, params object[] argumentos) =>
        objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);
}
