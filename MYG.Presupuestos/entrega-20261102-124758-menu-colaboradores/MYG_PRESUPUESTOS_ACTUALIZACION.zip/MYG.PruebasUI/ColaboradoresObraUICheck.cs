using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

/// <summary>Gestión desde una obra fija, sin reutilizar el explorador ni consultar la base privada.</summary>
internal static class ColaboradoresObraUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private const string Servidor = "https://colaboradores-obra-ui.supabase.co";
    private const string Usuario = "propietario_ui";
    private static readonly Guid UsuarioId = Guid.Parse("11111111-1111-4111-8111-111111111111");
    private static readonly Guid ColaboradorId = Guid.Parse("22222222-2222-4222-8222-222222222222");

    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarCargaYAcciones(exige);
        VerificarRolActualizado(exige);
        VerificarCambioSesion(exige);
        VerificarObraNoDisponible(exige);
    }

    private static void VerificarCargaYAcciones(Action<bool, string> exige)
    {
        using var sesion = Sesion();
        var obra = Obra();
        using var http = new Transporte(obra);
        using var cliente = Conectar(http);
        bool rechazoBase = false;
        try { using var invalida = new ColaboradoresObraForm(sesion, cliente, obra with { Alcance = "base" }); }
        catch (Exception error) when (error is ArgumentException or InvalidOperationException) { rechazoBase = true; }
        exige(rechazoBase && http.Rpc.Count == 0,
            "El diálogo de colaboradores debe rechazar una base completa al construirse y antes de consultar la red.");
        using var form = new ColaboradoresObraForm(sesion, cliente, obra, agregar: true);
        exige(form.Name == "ventanaColaboradoresObra" && Campo<Label>(form, "titulo").Text.Contains(obra.Nombre, StringComparison.Ordinal),
            "La gestión debe abrir una ventana propia e identificar la obra concreta.");
        exige(!Controles(form).Any(c => c.Name is "proyectosNube" or "proyectosPropiosNube" or "proyectosCompartidosNube"),
            "El diálogo no debe volver a incrustar el explorador ni permitir cambiar la obra al administrar miembros.");
        form.CargarAsync().GetAwaiter().GetResult();
        exige(http.Rpc.SequenceEqual(new[] { "myg_nube_listar", "myg_nube_miembros", "myg_nube_solicitudes" }),
            "La gestión debe consultar primero el rol vigente y luego los miembros y solicitudes de esa obra.");
        var miembros = Campo<DataGridView>(form, "miembros");
        var solicitudes = Campo<DataGridView>(form, "solicitudes");
        exige(miembros.Rows.Count == 2 && solicitudes.Rows.Count == 1
            && miembros.Rows.Cast<DataGridViewRow>().Select(r => ((MiembroNube)r.Tag).UsuarioId)
                .ToHashSet().SetEquals(new[] { UsuarioId.ToString("D"), ColaboradorId.ToString("D") }),
            "Deben mostrarse los miembros y las solicitudes recibidos, conservando sus identidades.");
        exige(Campo<Button>(form, "compartirUsuario").Enabled && Campo<TextBox>(form, "usuarioColaborador").Enabled,
            "Un propietario puede agregar usuarios MYG después de cargar el estado confirmado.");
        miembros.CurrentCell = miembros.Rows.Cast<DataGridViewRow>()
            .Single(r => ((MiembroNube)r.Tag).Rol == "propietario").Cells[0];
        Llamar(form, "ActualizarAcciones");
        exige(!Campo<Button>(form, "cambiarRol").Enabled && !Campo<Button>(form, "retirar").Enabled
            && !Campo<Button>(form, "permisosMiembro").Enabled,
            "La ventana propia debe conservar la protección del miembro propietario.");
        miembros.CurrentCell = miembros.Rows.Cast<DataGridViewRow>()
            .Single(r => ((MiembroNube)r.Tag).UsuarioId == ColaboradorId.ToString("D")).Cells[0];
        Llamar(form, "ActualizarAcciones");
        exige(Campo<Button>(form, "cambiarRol").Enabled && Campo<Button>(form, "retirar").Enabled
            && Campo<Button>(form, "permisosMiembro").Enabled,
            "Seleccionar un colaborador editable debe habilitar rol, retirada y permisos de módulo.");
        Campo<ComboBox>(form, "rol").SelectedItem = "lector";
        ((Task)Llamar(form, "CambiarRolAsync", false)).GetAwaiter().GetResult();
        exige(http.Mutaciones.SequenceEqual(new[] { "myg_nube_rol" }) && http.RolAsignado == "lector"
            && http.UsuarioModificado == ColaboradorId,
            "Cambiar el rol debe apuntar al colaborador seleccionado dentro de la obra, con confirmación del servidor.");
        solicitudes.CurrentCell = solicitudes.Rows[0].Cells[0];
        ((Task)Llamar(form, "ResolverAsync", true)).GetAwaiter().GetResult();
        exige(http.Mutaciones.SequenceEqual(new[] { "myg_nube_rol", "myg_nube_resolver" }) && http.SolicitudAprobada,
            "La ruta independiente debe conservar la resolución de solicitudes de la obra.");
        exige(http.IdsConsultados.All(id => id == obra.Id),
            "Todas las lecturas y mutaciones deben usar el UUID fijo de la obra y jamás el de la base o de una obra vecina.");
    }

    private static void VerificarRolActualizado(Action<bool, string> exige)
    {
        using var sesion = Sesion();
        var obra = Obra();
        using var http = new Transporte(obra) { RolActual = "lector" };
        using var cliente = Conectar(http);
        using var form = new ColaboradoresObraForm(sesion, cliente, obra);
        form.CargarAsync().GetAwaiter().GetResult();
        exige(http.Rpc.SequenceEqual(new[] { "myg_nube_listar", "myg_nube_miembros" })
            && !Campo<Button>(form, "compartirUsuario").Enabled
            && !Campo<Button>(form, "aceptar").Enabled
            && !Campo<Button>(form, "cambiarRol").Enabled,
            "Un rol lector recibido al cargar debe impedir administrar, aunque la fila anterior lo anunciara como propietario.");
        var miembros = Campo<DataGridView>(form, "miembros");
        miembros.CurrentCell = miembros.Rows.Cast<DataGridViewRow>()
            .Single(r => ((MiembroNube)r.Tag).UsuarioId == ColaboradorId.ToString("D")).Cells[0];
        var solicitudes = Campo<DataGridView>(form, "solicitudes");
        int pendiente = solicitudes.Rows.Add(ColaboradorId.ToString("D"), "pendiente");
        solicitudes.Rows[pendiente].Tag = new SolicitudNube(ColaboradorId.ToString("D"), "pendiente");
        solicitudes.CurrentCell = solicitudes.Rows[pendiente].Cells[0];
        foreach (string metodo in new[] { "CompartirUsuarioAsync", "CambiarPermisosAsync" })
            Rechaza(() => (Task)Llamar(form, metodo), exige,
                "Invocar " + metodo + " directamente sin administrar no debe abrir diálogos ni enviar permisos.");
        Rechaza(() => (Task)Llamar(form, "CambiarRolAsync", false), exige,
            "Un lector no debe cambiar roles al invocarse la acción directamente.");
        Rechaza(() => (Task)Llamar(form, "ResolverAsync", true), exige,
            "Un lector no debe resolver solicitudes al invocarse la acción directamente.");
        exige(http.Mutaciones.Count == 0 && http.IdsConsultados.All(id => id == obra.Id),
            "La metadata antigua no debe elevar permisos ni dirigir operaciones a otra obra.");
    }

    private static void VerificarCambioSesion(Action<bool, string> exige)
    {
        using var sesion = Sesion();
        var obra = Obra();
        using var http = new Transporte(obra);
        using var cliente = Conectar(http);
        using var form = new ColaboradoresObraForm(sesion, cliente, obra);
        http.DuranteListado = () => typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial))
            .SetValue(sesion, new CredencialMYG { Usuario = "otra_cuenta_ui" });
        Rechaza(() => form.CargarAsync(), exige,
            "Si cambia la cuenta durante la carga, deben rechazarse los resultados antes de consultar o mostrar miembros.");
        exige(http.Rpc.SequenceEqual(new[] { "myg_nube_listar" })
            && Campo<DataGridView>(form, "miembros").Rows.Count == 0
            && !Campo<Button>(form, "compartirUsuario").Enabled,
            "Una respuesta de la cuenta anterior no debe poblar ni habilitar la administración.");
        int antes = http.Rpc.Count;
        Rechaza(() => form.CargarAsync(), exige,
            "Una cuenta MYG distinta del cliente conectado debe rechazarse antes de enviar otra solicitud.");
        exige(http.Rpc.Count == antes && http.Mutaciones.Count == 0,
            "La identidad incorrecta no debe generar operaciones remotas.");
    }

    private static void VerificarObraNoDisponible(Action<bool, string> exige)
    {
        foreach (bool eliminada in new[] { false, true })
        {
            using var sesion = Sesion();
            var obra = Obra();
            using var http = new Transporte(obra) { EliminacionPendiente = eliminada, OmitirObra = !eliminada };
            using var cliente = Conectar(http);
            using var form = new ColaboradoresObraForm(sesion, cliente, obra);
            Rechaza(() => form.CargarAsync(), exige,
                "Una obra eliminándose o retirada del listado autorizado no debe consultarse ni administrarse.");
            exige(http.Rpc.SequenceEqual(new[] { "myg_nube_listar" }) && http.Mutaciones.Count == 0,
                "La comprobación de disponibilidad debe detener la carga antes de miembros, solicitudes o permisos.");
        }
    }

    private static SesionDesktop Sesion()
    {
        var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial)).SetValue(sesion, new CredencialMYG { Usuario = Usuario });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
        return sesion;
    }

    private static ProyectoNube Obra() => new(Guid.NewGuid(), "MYG-OBRA-UI", "Obra elegida para colaboradores", "propietario", 3, "obra", default);

    private static ClienteSupabase Conectar(Transporte http)
    {
        var cliente = new ClienteSupabase(Servidor, "sb_publishable_ui_sintetica", http);
        cliente.IniciarSesionMygAsync(new TicketNubeMYG(
            "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJwcm9waWV0YXJpb191aSJ9.firma_solo_pruebas",
            Usuario, Servidor, DateTimeOffset.UtcNow.AddMinutes(1))).GetAwaiter().GetResult();
        return cliente;
    }

    private sealed class Transporte(ProyectoNube obra) : HttpMessageHandler
    {
        internal readonly List<string> Rpc = new(), Mutaciones = new();
        internal readonly List<Guid> IdsConsultados = new();
        internal string RolActual = "propietario", RolAsignado;
        internal Guid UsuarioModificado;
        internal bool SolicitudAprobada, EliminacionPendiente, OmitirObra;
        internal Action DuranteListado;

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri.AbsolutePath;
            if (ruta == "/functions/v1/myg-login")
                return Json(new { access_token = "acceso_ui", refresh_token = "refresco_ui", expires_in = 3600,
                    user = new { id = UsuarioId }, usuario_myg = Usuario });
            string rpc = ruta.Split('/').Last();
            Rpc.Add(rpc);
            if (rpc == "myg_nube_listar")
            {
                DuranteListado?.Invoke();
                var lista = new List<object>
                {
                    new { id = Guid.Parse("33333333-3333-4333-8333-333333333333"), codigo = "BASE-PRIVADA",
                        nombre = obra.Nombre, rol = "propietario", revision = 1, alcance = "base", eliminacion_pendiente = false },
                    new { id = Guid.Parse("44444444-4444-4444-8444-444444444444"), codigo = "OBRA-VECINA",
                        nombre = obra.Nombre, rol = "propietario", revision = 1, alcance = "obra", eliminacion_pendiente = false }
                };
                if (!OmitirObra) lista.Add(new { id = obra.Id, codigo = obra.Codigo, nombre = obra.Nombre,
                    rol = RolActual, revision = obra.Revision, alcance = "obra", eliminacion_pendiente = EliminacionPendiente });
                return Json(lista);
            }
            using var cuerpo = JsonDocument.Parse(await solicitud.Content.ReadAsStringAsync(ct));
            Guid id = cuerpo.RootElement.GetProperty("p_id").GetGuid();
            IdsConsultados.Add(id);
            if (id != obra.Id) throw new InvalidOperationException("La gestión de colaboradores consultó la base completa u otra obra.");
            if (rpc == "myg_nube_miembros")
                return Json(new[] { new { usuario_id = UsuarioId, rol = "propietario", usuario_myg = Usuario },
                    new { usuario_id = ColaboradorId, rol = "editor", usuario_myg = "colaborador_ui" } });
            if (rpc == "myg_nube_solicitudes") return Json(new[] { new { usuario_id = ColaboradorId, estado = "pendiente" } });
            if (rpc == "myg_nube_rol")
            {
                Mutaciones.Add(rpc);
                RolAsignado = cuerpo.RootElement.GetProperty("p_rol").GetString();
                UsuarioModificado = cuerpo.RootElement.GetProperty("p_usuario").GetGuid();
                return Json(true);
            }
            if (rpc == "myg_nube_resolver")
            {
                Mutaciones.Add(rpc);
                if (cuerpo.RootElement.GetProperty("p_usuario").GetGuid() != ColaboradorId)
                    throw new InvalidOperationException("La resolución apuntó a otra solicitud.");
                SolicitudAprobada = cuerpo.RootElement.GetProperty("p_aprobar").GetBoolean();
                return Json(true);
            }
            throw new InvalidOperationException("RPC inesperada en gestión independiente de colaboradores: " + rpc);
        }

        private static HttpResponseMessage Json(object valor) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }

    private static void Rechaza(Func<Task> accion, Action<bool, string> exige, string mensaje)
    {
        bool rechazada = false;
        try { accion().GetAwaiter().GetResult(); }
        catch (InvalidOperationException) { rechazada = true; }
        exige(rechazada, mensaje);
    }

    private static object Llamar(object objeto, string nombre, params object[] args)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, args); }
        catch (TargetInvocationException error) when (error.InnerException is not null)
        { ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
    }
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static IEnumerable<Control> Controles(Control raiz)
    {
        foreach (Control control in raiz.Controls)
        {
            yield return control;
            foreach (Control hijo in Controles(control)) yield return hijo;
        }
    }
}
