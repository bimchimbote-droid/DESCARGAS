using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelCronograma : UserControl
{
    private readonly Func<MYGCronograma> obtener;
    private readonly Action<MYGCronograma> aplicar;
    private readonly Func<bool> puedeEditar;
    private readonly Action guardar, deshacer, rehacer;
    private readonly Func<MYGProyectoDocumento> obtenerProyecto;
    private readonly Func<string> obtenerRuta;
    private readonly List<Button> botones = new();
    private readonly List<ContextMenuStrip> menus = new();
    private readonly HashSet<string> plegados = new();
    private readonly TextBox buscar = new() { Name = "cronograma_buscar", Dock = DockStyle.Fill, PlaceholderText = "Buscar tarea o código…" };
    private readonly DataGridView tabla = new MYG2027_TablaPresupuesto();
    private readonly MYGCronogramaGanttControl gantt = new();
    private readonly Panel lineaTiempo = new() { Name = "cronograma_linea_tiempo", Dock = DockStyle.Top, Height = 70, Visible = false };
    private readonly Label estado = new() { Name = "cronograma_estado", Dock = DockStyle.Bottom, Height = 27, Padding = new(8, 3, 6, 0) };
    private readonly Font negrita = new("Segoe UI", 9, FontStyle.Bold);
    private readonly SplitContainer division = new() { Name = "cronograma_divisor", Dock = DockStyle.Fill, Size = new(1500, 700), SplitterDistance = 820, Panel1MinSize = 350, Panel2MinSize = 220, SplitterWidth = 5 };
    private MYGResultadoCronograma resultado;
    private MYGCronograma edicionPendiente;
    private bool cargando, aplicando, finalizando, sincronizando;
    private Button botonCritica, botonLineaTiempo, botonInformacion;
    internal IReadOnlyList<Button> BotonesCinta => botones;
    internal bool EditandoTexto => buscar.ContainsFocus || tabla.IsCurrentCellInEditMode || tiempoTrabajo?.ContainsFocus == true || detallesTarea?.ContainsFocus == true;

    internal MYGPanelCronograma(Func<MYGCronograma> obtener, Action<MYGCronograma> aplicar, Func<bool> puedeEditar,
        Action guardar, Action deshacer, Action rehacer, Func<MYGProyectoDocumento> obtenerProyecto, Func<string> obtenerRuta = null)
    {
        this.obtener = obtener; this.aplicar = aplicar; this.puedeEditar = puedeEditar;
        this.guardar = guardar; this.deshacer = deshacer; this.rehacer = rehacer; this.obtenerProyecto = obtenerProyecto;
        this.obtenerRuta = obtenerRuta;
        Name = "cronograma_panel"; Dock = DockStyle.Fill; Font = new("Segoe UI", 9);
        var busqueda = new Panel { Dock = DockStyle.Top, Height = 34, Padding = new(6, 5, 6, 3) };
        var unidad = new Label { Dock = DockStyle.Right, Width = 235, Text = "Duración en días laborables enteros", TextAlign = ContentAlignment.MiddleRight };
        busqueda.Controls.Add(buscar); busqueda.Controls.Add(unidad);
        PrepararTabla(); division.Panel1.Controls.Add(tabla);
        division.Panel2.Controls.Add(gantt); division.Panel2.Controls.Add(gantt.Cabecera);
        Controls.Add(division); Controls.Add(lineaTiempo); Controls.Add(busqueda); Controls.Add(estado);
        InicializarFuncionesVideo();
        buscar.TextChanged += (_, _) => { if (!cargando) Intentar(Refrescar); };
        gantt.TareaSeleccionada += id => Intentar(() => Seleccionar(id));
        gantt.TareaDobleClick += id => Intentar(() => { Seleccionar(id); InformacionTarea(); });
        gantt.InicioCambiado += (id, fecha) => Intentar(() => AplicarCambio(plan =>
        {
            var tarea = plan.Tareas.Single(t => t.Id == id);
            tarea.Modo = MYGModoTarea.Manual; tarea.InicioManual = fecha.Date;
        }));
        gantt.PrimeraFilaCambiada += indice =>
        {
            if (sincronizando || tabla.RowCount == 0) return;
            sincronizando = true;
            try { tabla.FirstDisplayedScrollingRowIndex = Math.Clamp(indice, 0, tabla.RowCount - 1); }
            finally { sincronizando = false; }
        };
        gantt.ZoomCambiado += () => ActualizarEstado();
        lineaTiempo.Paint += DibujarLineaTiempo;
        lineaTiempo.MouseClick += (_, e) =>
        {
            if (resultado == null || lineaTiempo.ClientSize.Width < 40) return;
            double proporcion = Math.Clamp((e.X - 15d) / (lineaTiempo.ClientSize.Width - 30), 0, 1);
            gantt.IrFecha(resultado.Inicio.AddDays(Math.Round((resultado.Fin - resultado.Inicio).TotalDays * proporcion)), true);
        };
        PrepararBotones(); AplicarTema();
        Load += (_, _) => Intentar(() => { Refrescar(); if (division.Width > 900) division.SplitterDistance = (int)(division.Width * .58); });
        DpiChangedAfterParent += (_, _) => DimensionarFilas();
        Disposed += (_, _) =>
        {
            negrita.Dispose(); Font.Dispose();
            foreach (var menu in menus) menu.Dispose();
            // La fábrica compartida libera la imagen al disponer cada botón.
            foreach (var boton in botones) boton.Dispose();
        };
    }
    private void PrepararTabla()
    {
        tabla.Name = "cronograma_tareas"; tabla.AccessibleName = "Tareas del cronograma"; tabla.Dock = DockStyle.Fill;
        tabla.AutoGenerateColumns = false; tabla.AllowUserToAddRows = false; tabla.AllowUserToDeleteRows = false;
        tabla.AllowUserToResizeRows = false; tabla.RowHeadersVisible = false;
        tabla.MultiSelect = true; tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        tabla.EditMode = DataGridViewEditMode.EditOnF2; tabla.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        tabla.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        void Columna(string nombre, string titulo, int ancho, bool lectura = false)
        { tabla.Columns.Add(new DataGridViewTextBoxColumn { Name = nombre, HeaderText = titulo, Width = ancho, ReadOnly = lectura, SortMode = DataGridViewColumnSortMode.NotSortable }); }
        Columna("ID", "ID", 45, true);
        var modo = new DataGridViewComboBoxColumn { Name = "MODO", HeaderText = "Modo", Width = 82, SortMode = DataGridViewColumnSortMode.NotSortable, DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing };
        modo.Items.AddRange("Automática", "Manual"); tabla.Columns.Add(modo);
        Columna("NOMBRE", "Descripción", 290); Columna("DIASCAL", "Días Cal.", 75, true);
        Columna("DURACION", "Duración", 70); Columna("INICIO", "Inicio", 100);
        Columna("FIN", "Fin", 100); Columna("PREDECESORAS", "Predecesoras", 130); Columna("AVANCE", "% Avance", 80);
        tabla.Columns["DURACION"].ToolTipText = "Cambiar la duración recalcula cuadrillas y restablece partes; puede volver a dividir desde Información de tarea.";
        tabla.Columns["INICIO"].DefaultCellStyle.Format = tabla.Columns["FIN"].DefaultCellStyle.Format = "dd/MM/yyyy";
        tabla.Columns["INICIO"].ToolTipText = tabla.Columns["FIN"].ToolTipText = "Editar Inicio o Fin fija la tarea en programación Manual.";
        tabla.Columns["AVANCE"].DefaultCellStyle.Format = "0.##' %'";
        tabla.CellPainting += DibujarNombre;
        tabla.CellMouseClick += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex != tabla.Columns["NOMBRE"].Index || tabla.Rows[e.RowIndex].Tag is not MYGResultadoTarea f || !f.Tarea.EsResumen) return;
            if (e.X <= 26 + f.Nivel * 14) Intentar(() => AlternarPlegado(f.Tarea.Id));
        };
        tabla.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) Intentar(InformacionTarea); };
        tabla.SelectionChanged += (_, _) => { if (!cargando) ActualizarSeleccion(); };
        tabla.CurrentCellChanged += (_, _) => ProgramarDetalleTarea();
        tabla.Scroll += (_, e) =>
        {
            if (sincronizando || e.ScrollOrientation != ScrollOrientation.VerticalScroll || tabla.RowCount == 0) return;
            sincronizando = true;
            try { gantt.MostrarFila(Math.Max(0, tabla.FirstDisplayedScrollingRowIndex)); }
            finally { sincronizando = false; }
        };
        tabla.CellBeginEdit += (_, e) =>
        {
            edicionPendiente = null;
            e.Cancel = cargando || !Editable || tabla.Rows[e.RowIndex].Tag is not MYGResultadoTarea f || f.Tarea.EsResumen;
        };
        tabla.CellValidating += ValidarCelda;
        tabla.CellEndEdit += (_, _) =>
        {
            if (cargando || edicionPendiente == null) return;
            var plan = edicionPendiente; edicionPendiente = null;
            Intentar(() => AplicarCopia(plan, true));
        };
        tabla.DataError += (_, e) => { e.ThrowException = false; e.Cancel = true; if (e.RowIndex >= 0) tabla.Rows[e.RowIndex].ErrorText = "Seleccione un modo de tarea válido."; };
        tabla.KeyDown += (_, e) =>
        {
            if (tabla.IsCurrentCellInEditMode) return;
            if (e.KeyCode == Keys.Delete) { e.Handled = true; Intentar(EliminarTareas); }
            else if (e.KeyCode == Keys.Insert) { e.Handled = true; Intentar(() => NuevaTarea(false)); }
            else if ((e.KeyCode is Keys.Left or Keys.Right) && Actual?.Tarea.EsResumen == true)
            { e.Handled = true; Intentar(() => AlternarPlegado(Actual.Tarea.Id, e.KeyCode == Keys.Left)); }
        };
        var menu = Menu();
        Opcion(menu, "Información de la tarea", "cronograma_menu_informacion", InformacionTarea);
        Opcion(menu, "Editar campos generales…", "cronograma_menu_campos_generales", EditarInformacionTarea);
        Opcion(menu, "Nueva tarea", "cronograma_menu_nueva", () => NuevaTarea(false), true);
        Opcion(menu, "Insertar hito", "cronograma_menu_hito", () => NuevaTarea(true), true);
        Opcion(menu, "Eliminar selección", "cronograma_menu_eliminar", EliminarTareas, true);
        menu.Items.Add(new ToolStripSeparator());
        Opcion(menu, "Vincular selección (FC)", "cronograma_menu_vincular", Vincular, true);
        Opcion(menu, "Desvincular selección", "cronograma_menu_desvincular", Desvincular, true);
        tabla.ContextMenuStrip = menu;
    }
    private bool Editable => puedeEditar?.Invoke() == true;
    private MYGResultadoTarea Actual => tabla.CurrentRow?.Tag as MYGResultadoTarea;
    private List<string> SeleccionIds(bool soloTareas = false) => tabla.SelectedRows.Cast<DataGridViewRow>()
        .Select(r => r.Tag).OfType<MYGResultadoTarea>().Where(f => !soloTareas || !f.Tarea.EsResumen)
        .OrderBy(f => f.Numero).Select(f => f.Tarea.Id).ToList();
    internal void FinalizarEdicion()
    {
        if (finalizando || aplicando || cargando) return;
        finalizando = true;
        try
        {
            if (tiempoTrabajo.Visible) tiempoTrabajo.FinalizarEdicion();
            if (detallesTarea?.Visible == true)
            {
                detallesTarea.FinalizarEdicion();
                if (detallesTarea.TieneCambios && !detallesTarea.ConfirmarSalida())
                    throw new InvalidOperationException("Complete o descarte la edición de Información de tarea antes de continuar.");
            }
            if (!tabla.EndEdit()) throw new InvalidOperationException("Corrija la celda del cronograma que está editando antes de continuar.");
            if (edicionPendiente != null) { var plan = edicionPendiente; edicionPendiente = null; AplicarCopia(plan); }
        }
        finally { finalizando = false; }
    }
    internal void Refrescar()
    {
        if (cargando || aplicando || IsDisposed || tabla.IsCurrentCellInEditMode) return;
        string elegido = Actual?.Tarea.Id; var seleccion = SeleccionIds();
        int scroll = Math.Max(0, tabla.FirstDisplayedScrollingRowIndex);
        var plan = obtener() ?? throw new InvalidOperationException("No hay un cronograma disponible.");
        var nuevo = MYGMotorCronograma.Calcular(plan);
        string filtro = buscar.Text.Trim();
        var incluir = new HashSet<string>();
        if (filtro.Length != 0)
        {
            var porId = nuevo.Filas.ToDictionary(f => f.Tarea.Id);
            foreach (var f in nuevo.Filas.Where(f => f.Tarea.Nombre.Contains(filtro, StringComparison.OrdinalIgnoreCase) || (f.Tarea.Codigo ?? "").Contains(filtro, StringComparison.OrdinalIgnoreCase)))
            {
                var actual = f;
                while (actual != null && incluir.Add(actual.Tarea.Id))
                    actual = actual.Tarea.PadreId != null && porId.TryGetValue(actual.Tarea.PadreId, out var padre) ? padre : null;
            }
            // La búsqueda no oculta el borrador activo ni impide volver a él
            // si el usuario cancela el cambio de tarea.
            if (detallesTarea?.TieneCambios == true && detalleSeleccionado != null &&
                porId.TryGetValue(detalleSeleccionado, out var editada))
            {
                var actual = editada;
                while (actual != null && incluir.Add(actual.Tarea.Id))
                    actual = actual.Tarea.PadreId != null && porId.TryGetValue(actual.Tarea.PadreId, out var padre) ? padre : null;
            }
        }
        var ocultos = new HashSet<string>(); var visibles = new List<MYGResultadoTarea>();
        foreach (var f in nuevo.Filas)
        {
            bool oculto = filtro.Length != 0 ? !incluir.Contains(f.Tarea.Id) : f.Tarea.PadreId != null && (plegados.Contains(f.Tarea.PadreId) || ocultos.Contains(f.Tarea.PadreId));
            if (oculto) { ocultos.Add(f.Tarea.Id); continue; }
            visibles.Add(f);
        }
        resultado = nuevo; cargando = true; tabla.SuspendLayout();
        try
        {
            tabla.ReadOnly = !Editable;
            tabla.Rows.Clear();
            foreach (var f in visibles)
            {
                int n = tabla.Rows.Add(f.Numero, f.Tarea.Modo == MYGModoTarea.Manual ? "Manual" : "Automática", f.Tarea.Nombre,
                    f.DiasCalendario, f.DuracionDias, f.Inicio, f.Fin, MYGMotorCronograma.FormatoPredecesoras(f.Tarea, nuevo.Filas), f.Tarea.Avance);
                var fila = tabla.Rows[n]; fila.Tag = f; fila.ReadOnly = f.Tarea.EsResumen || !Editable;
                fila.Height = gantt.AltoFila;
                fila.DefaultCellStyle.Font = f.Tarea.EsResumen ? negrita : tabla.Font;
                if (f.Tarea.EsResumen) fila.DefaultCellStyle.BackColor = MYG2027_TemaComercial.AzulSuave;
                fila.Cells["NOMBRE"].ToolTipText = f.Tarea.Codigo + " " + f.Tarea.Nombre + "\nHolgura: " + f.HolguraDias + " días" +
                    (f.Advertencias.Count == 0 ? "" : "\n" + string.Join("\n", f.Advertencias));
            }
            tabla.ClearSelection();
            var filaActual = tabla.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => ((MYGResultadoTarea)r.Tag).Tarea.Id == elegido);
            if (filaActual != null) tabla.CurrentCell = filaActual.Cells["NOMBRE"];
            foreach (DataGridViewRow r in tabla.Rows) r.Selected = seleccion.Contains(((MYGResultadoTarea)r.Tag).Tarea.Id);
            if (tabla.SelectedRows.Count == 0 && tabla.RowCount > 0) { tabla.CurrentCell = tabla.Rows[0].Cells["NOMBRE"]; tabla.Rows[0].Selected = true; }
            var datosProyecto = obtenerProyecto()?.Datos;
            gantt.Cargar(visibles, plan.Calendario, plan.FechaEstado, datosProyecto?.FechaInicio, datosProyecto?.FechaFin);
            ActualizarRutaCritica(plan);
            if (tabla.RowCount > 0) { tabla.FirstDisplayedScrollingRowIndex = Math.Min(scroll, tabla.RowCount - 1); gantt.MostrarFila(tabla.FirstDisplayedScrollingRowIndex); }
        }
        finally { tabla.ResumeLayout(); cargando = false; }
        ActualizarSeleccion(); ActualizarDetalleTarea(); lineaTiempo.Invalidate(); ActualizarEstado();
        gantt.ConfigurarPresentacion(detallesTarea.Opciones, obtenerProyecto(), true);
        if (tiempoTrabajo.Visible) tiempoTrabajo.Refrescar();
        foreach (var boton in botones.Where(b => b.Tag is true)) boton.Enabled = Editable;
    }
    private void ValidarCelda(object sender, DataGridViewCellValidatingEventArgs e)
    {
        if (cargando || e.RowIndex < 0 || tabla.Columns[e.ColumnIndex].ReadOnly || tabla.Rows[e.RowIndex].Tag is not MYGResultadoTarea f || f.Tarea.EsResumen) return;
        try
        {
            if (!Editable) throw new InvalidOperationException("Inicie una sesión autorizada para modificar el cronograma.");
            var copia = MYGProyectoStorage.Copia(obtener());
            var tarea = copia.Tareas.Single(t => t.Id == f.Tarea.Id);
            if (EditarCelda(tarea, tabla.Columns[e.ColumnIndex].Name, Convert.ToString(e.FormattedValue, CultureInfo.CurrentCulture) ?? ""))
            { MYGMotorCronograma.Calcular(copia); edicionPendiente = copia; }
            tabla.Rows[e.RowIndex].ErrorText = "";
        }
        catch (Exception ex) { e.Cancel = true; edicionPendiente = null; tabla.Rows[e.RowIndex].ErrorText = ex.Message; estado.Text = ex.Message; }
    }
    private bool EditarCelda(MYGTareaCronograma tarea, string columna, string texto)
    {
        texto = texto.Trim();
        switch (columna)
        {
            case "NOMBRE":
                if (string.IsNullOrWhiteSpace(texto)) throw new InvalidOperationException("Escriba el nombre de la tarea.");
                if (tarea.Nombre == texto) return false; tarea.Nombre = texto; return true;
            case "MODO":
                var modo = texto.Equals("Manual", StringComparison.OrdinalIgnoreCase) ? MYGModoTarea.Manual
                    : texto.Equals("Auto", StringComparison.OrdinalIgnoreCase) || texto.Equals("Automatica", StringComparison.OrdinalIgnoreCase) || texto.Equals("Automática", StringComparison.OrdinalIgnoreCase)
                        ? MYGModoTarea.Automatica : throw new InvalidOperationException("Seleccione Automática o Manual.");
                if (modo == tarea.Modo) return false;
                tarea.Modo = modo;
                if (modo == MYGModoTarea.Manual && !tarea.InicioManual.HasValue) tarea.InicioManual = resultado.Filas.Single(f => f.Tarea.Id == tarea.Id).Inicio;
                return true;
            case "DURACION":
                if (!int.TryParse(texto, out int dias) || dias < 0 || dias > 36500) throw new InvalidOperationException("La duración admite de 0 a 36 500 días laborables enteros; cero crea un hito.");
                if (tarea.DuracionDias == dias) return false;
                MYGInformacionTarea.Reprogramar(tarea, dias); return true;
            case "INICIO":
                if (!DateTime.TryParse(texto, CultureInfo.GetCultureInfo("es-PE"), DateTimeStyles.None, out var fecha)) throw new InvalidOperationException("Escriba una fecha válida en formato día/mes/año.");
                if (resultado.Filas.Single(f => f.Tarea.Id == tarea.Id).Inicio.Date == fecha.Date) return false;
                if (tarea.Modo == MYGModoTarea.Manual && tarea.InicioManual?.Date == fecha.Date) return false;
                tarea.Modo = MYGModoTarea.Manual; tarea.InicioManual = fecha.Date; return true;
            case "FIN":
                if (!DateTime.TryParse(texto, CultureInfo.GetCultureInfo("es-PE"), DateTimeStyles.None, out var fin)) throw new InvalidOperationException("Escriba una fecha válida en formato día/mes/año.");
                var vigente = resultado.Filas.Single(f => f.Tarea.Id == tarea.Id);
                if (vigente.Fin.Date == fin.Date) return false;
                if (fin.Date < vigente.Inicio.Date) throw new InvalidOperationException("El fin no puede ser anterior al inicio de la tarea.");
                var calendario = obtener().Calendario;
                bool hito = tarea.DuracionDias == 0 && fin.Date == vigente.Inicio.Date;
                if (!hito && !calendario.EsLaborable(fin)) throw new InvalidOperationException("El fin debe ser un día laborable del calendario de trabajo.");
                int duracion = hito ? 0 : calendario.ContarDiasLaborables(vigente.Inicio, fin);
                if (!hito && duracion < 1) throw new InvalidOperationException("El intervalo debe contener al menos un día laborable.");
                MYGInformacionTarea.Reprogramar(tarea, duracion);
                tarea.Modo = MYGModoTarea.Manual; tarea.InicioManual = vigente.Inicio.Date; return true;
            case "PREDECESORAS":
                var nuevas = MYGMotorCronograma.LeerPredecesoras(texto, resultado.Filas, tarea.Id);
                if (nuevas.Select(d => (d.PredecesoraId, d.Tipo, d.DesfaseDias)).SequenceEqual(tarea.Predecesoras.Select(d => (d.PredecesoraId, d.Tipo, d.DesfaseDias)))) return false;
                tarea.Predecesoras = nuevas; return true;
            case "AVANCE":
                string porcentaje = texto.TrimEnd('%').Trim();
                if (!decimal.TryParse(porcentaje, NumberStyles.Number, CultureInfo.CurrentCulture, out decimal avance) &&
                    !decimal.TryParse(porcentaje, NumberStyles.Number, CultureInfo.InvariantCulture, out avance) || avance < 0 || avance > 100)
                    throw new InvalidOperationException("El avance debe estar entre 0 y 100 por ciento.");
                if (tarea.Avance == avance) return false; tarea.Avance = avance; return true;
            default: return false;
        }
    }
    private void AplicarCambio(Action<MYGCronograma> cambiar)
    {
        FinalizarEdicion(); RequerirEdicion();
        var copia = MYGProyectoStorage.Copia(obtener()); cambiar(copia); AplicarCopia(copia);
    }
    private void AplicarCopia(MYGCronograma copia, bool diferirRefresco = false)
    {
        RequerirEdicion(); MYGMotorCronograma.Calcular(copia);
        aplicando = true;
        try { aplicar(copia); }
        finally { aplicando = false; }
        // La aplicación del modelo es síncrona: Guardar y cambiar de vista
        // deben incluir la última celda. Sólo se difiere reconstruir las filas
        // para salir del evento CellEndEdit antes de cambiar el DataGridView.
        if (diferirRefresco && IsHandleCreated)
            BeginInvoke((Action)(() => { if (!IsDisposed) Intentar(Refrescar); }));
        else Refrescar();
    }
    private void RequerirEdicion()
    { if (!Editable) throw new InvalidOperationException("Inicie una sesión autorizada para modificar el cronograma."); }
    private void ActualizarSeleccion()
    { gantt.Seleccionar(SeleccionIds()); tabla.Invalidate(); }
    private void Seleccionar(string id)
    {
        FinalizarEdicion();
        var fila = tabla.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => ((MYGResultadoTarea)r.Tag).Tarea.Id == id);
        if (fila == null) return;
        tabla.ClearSelection(); tabla.CurrentCell = fila.Cells["NOMBRE"]; fila.Selected = true; ActualizarSeleccion(); ProgramarDetalleTarea();
    }
    private void AlternarPlegado(string id, bool? plegar = null)
    {
        FinalizarEdicion();
        if (plegar ?? !plegados.Contains(id)) plegados.Add(id); else plegados.Remove(id);
        Refrescar();
    }
    private void DibujarNombre(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex != tabla.Columns["NOMBRE"].Index || tabla.Rows[e.RowIndex].Tag is not MYGResultadoTarea f) return;
        e.Paint(e.ClipBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.ContentForeground);
        int x = e.CellBounds.Left + 6 + f.Nivel * 14;
        Color color = e.State.HasFlag(DataGridViewElementStates.Selected) ? MYG2027_TemaComercial.TextoSeleccion
            : gantt.EsCritica(f) && !f.Tarea.EsResumen ? Color.FromArgb(204, 54, 54) : MYG2027_TemaComercial.Texto;
        if (f.Tarea.EsResumen)
            TextRenderer.DrawText(e.Graphics, plegados.Contains(f.Tarea.Id) ? "▸" : "▾", negrita, new Rectangle(x, e.CellBounds.Top, 17, e.CellBounds.Height), color, TextFormatFlags.VerticalCenter);
        string texto = string.IsNullOrWhiteSpace(f.Tarea.Codigo) ? f.Tarea.Nombre : f.Tarea.Codigo + "  " + f.Tarea.Nombre;
        TextRenderer.DrawText(e.Graphics, texto, f.Tarea.EsResumen ? negrita : tabla.Font,
            new Rectangle(x + 18, e.CellBounds.Top, Math.Max(0, e.CellBounds.Right - x - 21), e.CellBounds.Height), color,
            TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
        e.Handled = true;
    }
    private void PrepararBotones()
    {
        Button Boton(string texto, string nombre, string icono, Action accion, bool edita = false)
        {
            var boton = EditorForm.CrearBotonCintaProyecto(icono, texto, edita);
            boton.Name = "cronograma_" + nombre;
            // Medir sólo al cambiar fuente, texto o DPI evita recalcular la
            // distribución durante la pintura. Las líneas explícitas conservan
            // sus palabras completas, también con texto de interfaz al 115 %.
            void AjustarAncho(object sender, EventArgs e) => AjustarAnchoBotonCinta(boton);
            boton.HandleCreated += AjustarAncho;
            boton.FontChanged += AjustarAncho;
            boton.TextChanged += AjustarAncho;
            boton.DpiChangedAfterParent += AjustarAncho;
            boton.Click += (_, _) => Intentar(accion); botones.Add(boton); return boton;
        }
        botonTiempoTrabajo = Boton("Tiempo de\ntrabajo", "tiempo_trabajo", "unidades", Calendario);
        botonInformacion = Boton("Información\nde tarea", "informacion", "editar", InformacionTarea);
        Boton("Insertar\nhito", "insertar_hito", "marca", () => NuevaTarea(true), true);
        botonCritica = Boton("Ruta\ncrítica ▾", "ruta_critica", "proyecto", () => { });
        PrepararMenuRutaCritica();
        Boton("Diagrama\nde red", "diagrama_red", "bim", () => { FinalizarEdicion(); using var d = new MYGRedCronogramaDialog(MYGMotorCronograma.Calcular(obtener())); d.ShowDialog(this); });
        var baseMenu = Menu();
        Opcion(baseMenu, "Establecer línea base", "cronograma_establecer_base", () => AplicarCambio(MYGMotorCronograma.EstablecerLineaBase), true);
        Opcion(baseMenu, "Quitar línea base", "cronograma_quitar_base", () => AplicarCambio(MYGMotorCronograma.QuitarLineaBase), true);
        Opcion(baseMenu, "Mostrar u ocultar línea base", "cronograma_ver_base", () => { gantt.MostrarLineaBase = !gantt.MostrarLineaBase; lineaTiempo.Invalidate(); });
        var botonBase = Boton("Línea\nbase ▾", "linea_base", "acu", () => { }); AsociarMenu(botonBase, baseMenu);
        botonLineaTiempo = Boton("Línea de\ntiempo", "linea_tiempo", "expandir", () => { lineaTiempo.Visible = !lineaTiempo.Visible; AplicarTema(); });
        Boton("Programar\nautomáticamente", "programar_automatico", "recalcular", () => CambiarModo(MYGModoTarea.Automatica), true);
        Boton("Programar\nmanualmente", "programar_manual", "marca", () => CambiarModo(MYGModoTarea.Manual), true);
        Boton("Calendario de\nadquisiciones", "adquisiciones", "insumos", () => MostrarCalendarioFinanciero(true));
        Boton("Calendario\nvalorizado", "valorizado", "resumen", () => MostrarCalendarioFinanciero(false));
        Boton("Responsables", "responsables", "sesion", Responsables, true);
        var otros = Menu();
        Opcion(otros, "Nueva tarea", "cronograma_nueva_tarea", () => NuevaTarea(false), true);
        Opcion(otros, "Eliminar selección", "cronograma_eliminar", EliminarTareas, true);
        Opcion(otros, "Vincular selección (FC)", "cronograma_vincular", Vincular, true);
        Opcion(otros, "Desvincular selección", "cronograma_desvincular", Desvincular, true);
        Opcion(otros, "Sincronizar con el presupuesto", "cronograma_sincronizar", () => AplicarCambio(p => MYGMotorCronograma.SincronizarPresupuestos(obtenerProyecto(), p)), true);
        Opcion(otros, "Fechas del proyecto…", "cronograma_fechas_proyecto", FechasProyecto, true);
        otros.Items.Add(new ToolStripSeparator());
        Opcion(otros, "Acercar", "cronograma_zoom_mas", () => gantt.PixelesPorDia *= 1.25f);
        Opcion(otros, "Alejar", "cronograma_zoom_menos", () => gantt.PixelesPorDia *= .8f);
        Opcion(otros, "Ajustar a todo el proyecto", "cronograma_zoom_ajustar", gantt.AjustarProyecto);
        Opcion(otros, "Expandir todos los títulos", "cronograma_expandir", () => { FinalizarEdicion(); plegados.Clear(); Refrescar(); });
        Opcion(otros, "Contraer todos los títulos", "cronograma_contraer", () => { FinalizarEdicion(); foreach (var f in resultado.Filas.Where(f => f.Tarea.EsResumen)) plegados.Add(f.Tarea.Id); Refrescar(); });
        otros.Items.Add(new ToolStripSeparator());
        Opcion(otros, "Calendario valorizado", "cronograma_calendario_valorizado", () => MostrarCalendarioFinanciero(false));
        Opcion(otros, "Calendario de adquisiciones", "cronograma_calendario_adquisiciones", () => MostrarCalendarioFinanciero(true));
        otros.Items.Add(new ToolStripSeparator());
        Opcion(otros, "Guardar proyecto", "cronograma_guardar", () => { FinalizarEdicion(); guardar(); });
        Opcion(otros, "Deshacer", "cronograma_deshacer", () => { FinalizarEdicion(); RequerirEdicion(); deshacer(); Refrescar(); }, true);
        Opcion(otros, "Rehacer", "cronograma_rehacer", () => { FinalizarEdicion(); RequerirEdicion(); rehacer(); Refrescar(); }, true);
        var botonOtros = Boton("Otros ▾", "otros", "resumen", () => { }); AsociarMenu(botonOtros, otros);
    }
    private static void AjustarAnchoBotonCinta(Button boton)
    {
        if (boton.IsDisposed || boton.Disposing || !boton.IsHandleCreated) return;
        using var grafico = boton.CreateGraphics();
        int anchoTexto = boton.Text.Replace("\r", "").Split('\n').Max(linea => TextRenderer.MeasureText(
            grafico, linea, boton.Font, Size.Empty, TextFormatFlags.SingleLine | TextFormatFlags.NoPadding).Width);
        float escala = boton.DeviceDpi / 96F;
        boton.Width = Math.Max((int)Math.Round(91F * escala), anchoTexto + (int)Math.Ceiling(10F * escala));
    }
    private ContextMenuStrip Menu()
    {
        var menu = new ContextMenuStrip(); menus.Add(menu);
        menu.Opening += (_, _) => { foreach (ToolStripItem i in menu.Items) if (i.Tag is true) i.Enabled = Editable; };
        return menu;
    }
    private void Opcion(ContextMenuStrip menu, string texto, string nombre, Action accion, bool edita = false)
    {
        var item = new ToolStripMenuItem(texto) { Name = nombre, Tag = edita };
        item.Click += (_, _) => Intentar(accion); menu.Items.Add(item);
    }
    private static void AsociarMenu(Button boton, ContextMenuStrip menu)
    { boton.ContextMenuStrip = menu; boton.Click += (_, _) => menu.Show(boton, new Point(0, boton.Height)); }
    private void Calendario()
        => AlternarTiempoTrabajo();
    private void EditarInformacionTarea()
    {
        FinalizarEdicion(); var fila = Actual ?? throw new InvalidOperationException("Seleccione una tarea.");
        if (fila.Tarea.EsResumen)
        {
            MessageBox.Show(this, fila.Tarea.Nombre + "\n\nInicio: " + fila.Inicio.ToString("dd/MM/yyyy") + "\nFin: " + fila.Fin.ToString("dd/MM/yyyy") +
                "\nDuración: " + fila.DuracionDias + " días laborables\nAvance: " + fila.Tarea.Avance.ToString("0.##") + "%\n\nEl resumen se calcula a partir de sus tareas.",
                "Información del resumen", MessageBoxButtons.OK, MessageBoxIcon.Information); return;
        }
        var plan = MYGProyectoStorage.Copia(obtener()); var tarea = plan.Tareas.Single(t => t.Id == fila.Tarea.Id);
        using var d = new MYGTareaCronogramaDialog(tarea, resultado.Filas, plan.Tareas.SelectMany(t => t.Responsables).Distinct().ToArray(), plan.Calendario);
        if (!Editable && d.AcceptButton is Button aceptar) aceptar.Enabled = false;
        if (d.ShowDialog(this) != DialogResult.OK) return;
        int posicion = plan.Tareas.FindIndex(t => t.Id == tarea.Id); plan.Tareas[posicion] = d.Valor; AplicarCopia(plan);
    }
    private void NuevaTarea(bool hito)
    {
        FinalizarEdicion(); RequerirEdicion(); var plan = MYGProyectoStorage.Copia(obtener());
        string padre = Actual?.Tarea.EsResumen == true ? Actual.Tarea.Id : Actual?.Tarea.PadreId;
        var tarea = MYGMotorCronograma.AgregarTarea(plan, padre, hito ? "Nuevo hito" : "Nueva tarea", hito);
        using var d = new MYGTareaCronogramaDialog(tarea, MYGMotorCronograma.Calcular(plan).Filas,
            plan.Tareas.SelectMany(t => t.Responsables).Distinct().ToArray(), plan.Calendario);
        if (d.ShowDialog(this) != DialogResult.OK) return;
        plan.Tareas[plan.Tareas.FindIndex(t => t.Id == tarea.Id)] = d.Valor;
        if (padre != null) plegados.Remove(padre);
        AplicarCopia(plan); Seleccionar(tarea.Id);
    }
    private void EliminarTareas()
    {
        FinalizarEdicion(); RequerirEdicion(); var ids = SeleccionIds();
        if (ids.Count == 0) throw new InvalidOperationException("Seleccione las tareas que desea eliminar.");
        if (MessageBox.Show(this, "¿Eliminar " + ids.Count + " tarea(s) y sus descendientes del cronograma? Las partidas del presupuesto se conservan.",
            "Eliminar tareas", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
        AplicarCambio(p => { foreach (string id in ids) if (p.Tareas.Any(t => t.Id == id)) MYGMotorCronograma.EliminarTarea(p, id); });
    }
    private void CambiarModo(MYGModoTarea modo)
    {
        var ids = SeleccionIds(true); if (ids.Count == 0) throw new InvalidOperationException("Seleccione una o más tareas, fuera de los resúmenes.");
        AplicarCambio(p => { foreach (var tarea in p.Tareas.Where(t => ids.Contains(t.Id)))
        {
            tarea.Modo = modo;
            // Una orden explícita de programación automática solicita recalcular
            // la tarea, incluso si se abrió con el mismo modo desde Delphin.
            if (modo == MYGModoTarea.Automatica) tarea.FechasImportadasDelphin = null;
            if (modo == MYGModoTarea.Manual && !tarea.InicioManual.HasValue)
                tarea.InicioManual = resultado.Filas.Single(f => f.Tarea.Id == tarea.Id).Inicio;
        } });
    }
    private void Vincular()
    {
        var ids = SeleccionIds(true); if (ids.Count < 2) throw new InvalidOperationException("Seleccione al menos dos tareas para vincularlas de fin a comienzo.");
        AplicarCambio(p => MYGMotorCronograma.Vincular(p, ids));
    }
    private void Desvincular()
    {
        var ids = SeleccionIds(true); if (ids.Count == 0) throw new InvalidOperationException("Seleccione las tareas que desea desvincular.");
        AplicarCambio(p => MYGMotorCronograma.Desvincular(p, ids));
    }
    private void Responsables()
    {
        FinalizarEdicion(); RequerirEdicion(); var ids = SeleccionIds(true);
        if (ids.Count == 0) throw new InvalidOperationException("Seleccione una o más tareas para asignar responsables.");
        using var d = new MYGResponsablesCronogramaDialog(obtener().Tareas.Where(t => ids.Contains(t.Id)).SelectMany(t => t.Responsables).Distinct());
        if (d.ShowDialog(this) == DialogResult.OK) AplicarCambio(p => { foreach (var t in p.Tareas.Where(t => ids.Contains(t.Id))) t.Responsables = d.Valor.ToList(); });
    }
    internal void Imprimir()
    {
        if (!ConfirmarSalidaTiempoTrabajo()) return;
        FinalizarEdicion(); var reportes = MYGReportesCronograma.Crear(obtenerProyecto(), obtener(), modoRutaCritica);
        MYGReportesImpresion.Imprimir(this, "Programación Gantt", reportes,
            validarDestino: (ruta, extension) => MYGExportacionCronogramaWindows.ValidarDestino(ruta, extension, obtenerRuta?.Invoke()));
    }
    internal void Exportar()
    {
        FinalizarEdicion();
        using var dialogo = new SaveFileDialog { Filter = "Libro Excel (*.xlsx)|*.xlsx|Lista de tareas CSV (*.csv)|*.csv", FileName = "Cronograma.xlsx", AddExtension = true };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        if (dialogo.FilterIndex == 2) MYGReportesCronograma.GuardarCsv(dialogo.FileName, obtener());
        else MYGReportesCronograma.GuardarExcel(dialogo.FileName, obtenerProyecto(), obtener());
    }
    private void MostrarCalendarioFinanciero(bool adquisiciones)
    {
        FinalizarEdicion(); var proyecto = obtenerProyecto(); var plan = obtener();
        var reportes = adquisiciones ? MYGReportesCronograma.CrearAdquisiciones(proyecto, plan) : MYGReportesCronograma.CrearValorizado(proyecto, plan);
        MYGReportesImpresion.Imprimir(this, adquisiciones ? "Calendario de adquisiciones" : "Calendario valorizado", reportes);
    }
    private void DibujarLineaTiempo(object sender, PaintEventArgs e)
    {
        if (resultado == null) return;
        var g = e.Graphics; int ancho = Math.Max(1, lineaTiempo.Width - 30); double dias = Math.Max(1, (resultado.Fin - resultado.Inicio).TotalDays + 1);
        using var azul = new SolidBrush(MYG2027_TemaComercial.Azul);
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        g.DrawLine(borde, 15, 40, lineaTiempo.Width - 15, 40);
        foreach (var f in resultado.Filas.Where(f => f.Nivel == 0))
        {
            float x = 15 + (float)((f.Inicio - resultado.Inicio).TotalDays / dias * ancho);
            float largo = Math.Max(4, (float)(((f.Fin - f.Inicio).TotalDays + 1) / dias * ancho));
            g.FillRectangle(azul, x, 32, largo, 12);
            TextRenderer.DrawText(g, f.Tarea.Nombre, Font, new Rectangle((int)x, 8, (int)largo, 23), MYG2027_TemaComercial.Texto, TextFormatFlags.EndEllipsis);
        }
        TextRenderer.DrawText(g, resultado.Inicio.ToString("dd/MM/yyyy"), Font, new Point(15, 49), MYG2027_TemaComercial.Secundario);
        TextRenderer.DrawText(g, resultado.Fin.ToString("dd/MM/yyyy"), Font, new Rectangle(15, 49, ancho, 19), MYG2027_TemaComercial.Secundario, TextFormatFlags.Right);
    }
    private void ActualizarEstado()
    {
        if (resultado == null) return;
        var datos = obtenerProyecto()?.Datos;
        string plazo = datos?.FechaInicio != null || datos?.FechaFin != null
            ? "Proyecto: " + (datos.FechaInicio?.ToString("dd/MM/yyyy") ?? "—") + " — " +
                (datos.FechaFin?.ToString("dd/MM/yyyy") ?? "—") + " (límites azules)    |    " : "";
        string fechaEstado = "Estado: " + obtener().FechaEstado.ToString("dd/MM/yyyy") + " (rojo)";
        estado.Text = plazo + fechaEstado + "    |    Tareas: " + resultado.Inicio.ToString("dd/MM/yyyy") + " — " + resultado.Fin.ToString("dd/MM/yyyy") + "    |    " +
            resultado.Filas.Count(f => !f.Tarea.EsResumen) + " tareas    |    " + resultado.Filas.Count(f => gantt.EsCritica(f) && !f.Tarea.EsResumen) +
            " críticas    |    Zoom: " + (gantt.PixelesPorDia / 24 * 100).ToString("0") + "%" +
            (resultado.Advertencias.Count == 0 ? "" : "    |    Advertencia: " + resultado.Advertencias[0]);
        estado.AccessibleDescription = plazo + fechaEstado + "\n" + string.Join("\n", resultado.Advertencias);
    }
    private void DimensionarFilas()
    {
        gantt.AltoFila = (int)Math.Round(26 * DeviceDpi / 96f); gantt.AltoCabecera = (int)Math.Round(48 * DeviceDpi / 96f);
        tabla.RowTemplate.Height = gantt.AltoFila; tabla.ColumnHeadersHeight = gantt.AltoCabecera;
        foreach (DataGridViewRow fila in tabla.Rows) fila.Height = gantt.AltoFila;
    }
    internal void AplicarTema()
    {
        BackColor = division.BackColor = MYG2027_TemaComercial.Borde;
        ForeColor = estado.ForeColor = MYG2027_TemaComercial.Texto;
        estado.BackColor = lineaTiempo.BackColor = MYG2027_TemaComercial.AzulSuave;
        buscar.BackColor = MYG2027_TemaComercial.Superficie; buscar.ForeColor = MYG2027_TemaComercial.Texto;
        MYG2027_TemaComercial.EstilizarTabla(tabla, 48); DimensionarFilas();
        foreach (DataGridViewRow r in tabla.Rows) r.DefaultCellStyle.BackColor = ((MYGResultadoTarea)r.Tag).Tarea.EsResumen ? MYG2027_TemaComercial.AzulSuave : MYG2027_TemaComercial.Superficie;
        foreach (var boton in botones)
        {
            bool activo = boton == botonCritica && gantt.MostrarCritica || boton == botonLineaTiempo && lineaTiempo.Visible ||
                boton == botonTiempoTrabajo && tiempoTrabajo.Visible || boton == botonInformacion && detallesTarea?.Visible == true;
            MYG2027_TemaComercial.EstilizarBoton(boton, activo ? 2 : 0);
        }
        gantt.BackColor = MYG2027_TemaComercial.Superficie; gantt.Invalidate(); lineaTiempo.Invalidate();
    }
    private void Intentar(Action accion)
    { try { accion(); } catch (Exception ex) { MessageBox.Show(this, ex.Message, "Cronograma", MessageBoxButtons.OK, MessageBoxIcon.Warning); } }
}
