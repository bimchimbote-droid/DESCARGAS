/*
MYG — LICENCIAS + COMPRAS Y RENOVACIONES — 30/09/2026

COPIAR TODO ESTE ARCHIVO EN Codigo.gs. Estas instrucciones son comentarios.
Es una integración preparada para validar; no ha cobrado en tu cuenta real.

INSTALACIÓN, EN ESTE ORDEN
1. Guarda una copia de tu hoja REAL y del código Apps Script actual.|
2. Desde tu hoja REAL de licencias: Extensiones > Apps Script.
   Sustituye el contenido del archivo que contiene doGet/doPost por TODO este
   TXT. No lo pegues en MYG_PAGOS_PRUEBAS. No dejes otras funciones doGet/doPost
   duplicadas en archivos del mismo proyecto.
3. Configuración del proyecto: zona horaria America/Lima.
   Configura también la hoja de cálculo con zona horaria Lima (GMT-05:00).
4. Guarda. En el selector de funciones elige PREPARAR_INTEGRACION y Ejecutar.
   Autoriza con la cuenta propietaria. NO ejecutes doGet ni doPost desde el editor.
   Se conservan A:I; se añade J=PAGOS_APLICADOS si está libre y se crea
   PEDIDOS_MYG en ESTE MISMO archivo. No se importan los pedidos de prueba.
5. Configuración del proyecto > Propiedades del script: agrega
   MP_ACCESS_TOKEN_PRODUCCION = Access Token REAL del vendedor (no Public Key).
   MP_VENDEDOR_ID_PRODUCCION = ID numérico del vendedor REAL.
   MYG_URL_WEB = URL /exec ACTUAL que usan tus DLL.
   MYG_PAGOS_HABILITADOS = NO
   MYG_HOJA_ID se guarda automáticamente en el paso 4. No copies el ID de prueba.
   Nunca compartas el Access Token ni lo pegues en el código del complemento.
6. Ejecuta VERIFICAR_CONFIGURACION. Rechaza cuentas de vendedor de prueba.
7. Implementar > Gestionar implementaciones > selecciona la implementación
   ACTUAL > lápiz > Versión: Nueva versión > Implementar.
   Ejecutar como: tú. Acceso: Cualquier usuario. Conserva la misma URL /exec.
   No necesitas crear otra implementación ni cambiar la URL de las DLL.
8. Abre esa URL sin parámetros: debe aparecer la página con ventas desactivadas.
   Prueba en Revit tu login manual y automático actuales antes de habilitar ventas.
9. Cuando estés listo para cobros REALES, cambia MYG_PAGOS_HABILITADOS a SI.
   Las propiedades no requieren publicar otra versión. Recarga la página.
   Una compra aquí es REAL. Las tarjetas y cuentas del piloto no sirven para
   validar el cobro real. Primero valida una compra controlada de extremo a extremo.
10. Comprueba PEDIDOS_MYG=APLICADO y LICENCIAS: usuario, vencimiento, E=SI.
    Nuevo cliente: C/I vacías hasta su primer login en Revit. Inicia sesión con
    el usuario/clave MYG elegidos en la página. Después prueba ambos add-ins.
    Una renovación debe conservar C, H e I y sumar el plazo una sola vez.

PRECIOS PROPUESTOS: S/20 por 1 mes calendario; S/200 por 12 meses calendario.
Se configuran en PLANES_MYG_ debajo. Cada compra incluye la licencia compartida
por ambos add-ins. No es una suscripción con cargos recurrentes automáticos.
El cliente vuelve a pagar para renovar. No se pide contraseña de Mercado Pago
en la página MYG: solo su clave MYG. Los datos de tarjeta se introducen en MP.

COLUMNAS LICENCIAS (se aceptan tus encabezados actuales en G/H):
A USUARIO | B CLAVE | C MACHINE_ID | D EXPIRA | E ACTIVO | F NOMBRE
G ULTIMO LOGIN | H ING. AUTOM. | I TOKEN_HASH | J PAGOS_APLICADOS
No edites J: es el registro que impide aplicar dos veces el mismo pago.
No renombres PEDIDOS_MYG ni cambies sus columnas ni borres pedidos.
E=PENDIENTE_PAGO identifica un usuario nuevo aún sin compra confirmada.
E=NO sigue bloqueado incluso si paga. H=NO se conserva en renovaciones.
Para un nuevo cliente H=SI; el primer login con contraseña registra su PC/token.
La página solo muestra mensajes al cliente, no instrucciones sobre tus columnas.

OPERACIÓN Y LÍMITES DE ESTA ENTREGA
- El activador revisa hasta 10 pedidos por ejecución, aproximadamente cada minuto.
  La activación puede tardar más por cola, cuotas, servicios o permisos de Google.
  Consultar activación lee el resultado; no sobrecarga MP en cada clic.
- Al poner MYG_PAGOS_HABILITADOS=NO se detienen las compras nuevas, pero se
  siguen conciliando pedidos existentes. No detiene el login de tus clientes.
- REVISION_MANUAL exige que revises el pedido en MP; nunca cambies el estado a
  APLICADO para forzar acceso. Tras resolver la causa, puedes cambiarlo a
  PENDIENTE para volver a consultar. No borres J ni el ID del pedido.
- No hay webhooks, envío de correo, recuperación de contraseña, comprobantes
  tributarios, ni reversión automática de licencias por reembolso/contracargo.
  Revisa esos casos en MP y ajusta la licencia manualmente. Un doble cobro
  detectado antes de activar se envía a revisión; uno posterior requiere revisión.
- Se conserva el almacenamiento de claves en B y el login GET de tu sistema
  actual para compatibilidad. La hoja contiene datos sensibles: acceso privado,
  contraseña exclusiva MYG. Esto no sustituye una migración de autenticación.
- Ambos add-ins deben consultar esta misma hoja/URL. El login manual conserva
  la rotación de token original: si cada DLL guarda un token independiente,
  iniciar sesión en una puede invalidar el token de la otra. Esta entrega no
  modifica ni verifica el almacenamiento C# de tus dos complementos.
- Google Sheets no es una base de datos transaccional. El bloqueo coordina este
  proyecto, no cambios manuales ni otros scripts: evita editar filas mientras
  se procesan pagos y no escribas licencias desde dos proyectos de pagos.
- Los medios disponibles los determina tu Checkout de MP. No verifica yapes
  directos a un número personal ni transferencias hechas fuera del checkout.

FUENTES DE REFERENCIA
https://developers.google.com/apps-script/concepts/deployments
https://developers.google.com/apps-script/guides/html/communication
https://www.mercadopago.com.pe/developers/es/reference/online-payments/checkout-pro-preferences/create-preference/post
https://www.mercadopago.com.pe/developers/es/reference/online-payments/checkout-pro-preferences/get-payment/get
*/

var PLANES_MYG_ = {
  mensual: {precio: 23, meses: 1, titulo: 'MYG: ambos add-ins — 1 mes'},
  anual: {precio: 210, meses: 12, titulo: 'MYG: ambos add-ins — 12 meses'}
};
var CAB_PEDIDOS_MYG_ = ['REFERENCIA','CREADO','USUARIO','PLAN','IMPORTE',
  'MESES','ESTADO','PAGO_ID','CHECKOUT_URL','ULTIMA_REVISION','DETALLE'];

function respuesta(texto) { return ContentService.createTextOutput(texto); }
function hashToken(token) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    String(token), Utilities.Charset.UTF_8).map(function(b) {
      return ('0' + ((b + 256) % 256).toString(16)).slice(-2);
    }).join('').toUpperCase();
}
function propiedades_() { return PropertiesService.getScriptProperties(); }
function texto_(v) { return v == null ? '' : String(v).trim(); }
function usuario_(v) { return texto_(v).toLowerCase(); }
function conLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try { return fn(); } finally { lock.releaseLock(); }
}
function libro_() {
  var id = propiedades_().getProperty('MYG_HOJA_ID');
  var ss = id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Falta preparar el archivo de licencias.');
  return ss;
}
function buscarUsuario_(sh, usuario) {
  var filas = sh.getDataRange().getValues(), encontrado = null;
  for (var i = 1; i < filas.length; i++) {
    if (usuario_(filas[i][0]) !== usuario) continue;
    if (encontrado) throw new Error('Usuario duplicado en LICENCIAS.');
    encontrado = {n: i + 1, fila: filas[i]};
  }
  return encontrado;
}
function finDia_(fecha) {
  var d = new Date(fecha);
  if (isNaN(d.getTime())) throw new Error('Fecha inválida.');
  d.setHours(23, 59, 59, 0);
  return d;
}
function licenciaVigente(fila) {
  if (texto_(fila[4]).toUpperCase() !== 'SI') return 'BLOQUEADO';
  if (!fila[3] || isNaN(new Date(fila[3]).getTime())) return 'FECHA_INVALIDA';
  // Comparar con la medianoche siguiente evita redondeos de milisegundos.
  var limite = new Date(fila[3]);
  limite.setHours(0, 0, 0, 0);
  limite.setDate(limite.getDate() + 1);
  return new Date() >= limite ? 'EXPIRADO' : 'OK';
}

// LOGIN ORIGINAL. No necesita credenciales de Mercado Pago.
function doGet(e) {
  var p = e && e.parameter ? e.parameter : {};
  if (!('usuario' in p) && !('clave' in p) && !('pc' in p)) return pagina_();
  var user = usuario_(p.usuario), clave = texto_(p.clave), pc = texto_(p.pc);
  if (!user || !clave || !pc) return respuesta('DATOS_INCOMPLETOS');
  try {
    return conLock_(function() {
      var sh = libro_().getSheetByName('LICENCIAS');
      if (!sh) return respuesta('SIN_HOJA');
      var u = buscarUsuario_(sh, user);
      if (!u) return respuesta('NO_EXISTE');
      if (texto_(u.fila[1]) !== clave) return respuesta('CLAVE_ERROR');
      var estado = licenciaVigente(u.fila);
      if (estado !== 'OK') return respuesta(estado);
      var vinculado = texto_(u.fila[2]);
      if (vinculado && vinculado !== pc) return respuesta('OTRA_PC');
      if (!vinculado) sh.getRange(u.n, 3).setValue(pc);
      sh.getRange(u.n, 7).setValue(new Date());
      if (texto_(u.fila[7]).toUpperCase() === 'SI') {
        var token = Utilities.getUuid().replace(/-/g, '') +
                    Utilities.getUuid().replace(/-/g, '');
        sh.getRange(u.n, 9).setValue(hashToken(token));
        return respuesta('OK|' + token);
      }
      sh.getRange(u.n, 9).clearContent();
      return respuesta('OK');
    });
  } catch (err) { return respuesta('ERROR'); }
}
function doPost(e) {
  var p = e && e.parameter ? e.parameter : {};
  var accionNube = texto_(p.accion).toLowerCase();
  if (accionNube === 'validar_sesion' || accionNube === 'nube_ticket') {
    return despachoNubeMYG_(p, accionNube);
  }
  var user = usuario_(p.usuario), pc = texto_(p.pc), token = texto_(p.token);
  if (!user || !pc || !token) return respuesta('DATOS_INCOMPLETOS');
  try {
    return conLock_(function() {
      var sh = libro_().getSheetByName('LICENCIAS');
      if (!sh) return respuesta('SIN_HOJA');
      var u = buscarUsuario_(sh, user);
      if (!u) return respuesta('NO_EXISTE');
      var estado = licenciaVigente(u.fila);
      if (estado !== 'OK') return respuesta(estado);
      if (texto_(u.fila[7]).toUpperCase() !== 'SI') return respuesta('AUTO_DESACTIVADO');
      if (texto_(u.fila[2]) !== pc) return respuesta('OTRA_PC');
      if (!texto_(u.fila[8]) || texto_(u.fila[8]).toUpperCase() !== hashToken(token)) {
        return respuesta('TOKEN_INVALIDO');
      }
      sh.getRange(u.n, 7).setValue(new Date());
      return respuesta('OK');
    });
  } catch (err) { return respuesta('ERROR'); }
}

// CONFIGURACIÓN ADMINISTRATIVA: requiere identidad de la cuenta ejecutora.
// Nunca permitir estas operaciones solo porque la web ejecuta como propietario.
function soloAdministrador_() {
  var activo = Session.getActiveUser().getEmail();
  var ejecutor = Session.getEffectiveUser().getEmail();
  if (!activo || !ejecutor || activo.toLowerCase() !== ejecutor.toLowerCase()) {
    throw new Error('Ejecuta esta función desde el editor con la cuenta propietaria.');
  }
}
function comprobarZonas_(ss) {
  if (Session.getScriptTimeZone() !== 'America/Lima' ||
      ss.getSpreadsheetTimeZone() !== 'America/Lima') {
    throw new Error('Configura America/Lima en el proyecto y la hoja antes de continuar.');
  }
}
function PREPARAR_INTEGRACION() {
  soloAdministrador_();
  conLock_(function() {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss || ss.getName() === 'MYG_PAGOS_PRUEBAS') {
      throw new Error('Abre Apps Script desde tu hoja REAL de licencias.');
    }
    comprobarZonas_(ss);
    var sh = ss.getSheetByName('LICENCIAS');
    if (!sh) throw new Error('No existe LICENCIAS.');
    var cab = sh.getRange(1, 1, 1, 9).getValues()[0].map(function(x) {
      return texto_(x).toUpperCase();
    });
    var primeros = ['USUARIO','CLAVE','MACHINE_ID','EXPIRA','ACTIVO','NOMBRE'];
    if (cab.slice(0, 6).join('|') !== primeros.join('|') || cab[8] !== 'TOKEN_HASH' ||
        ['ULTIMO LOGIN','ULTIMO_LOGIN'].indexOf(cab[6]) < 0 ||
        ['ING. AUTOM.','INGRESAR AUTOMATICAMENTE'].indexOf(cab[7]) < 0) {
      throw new Error('Los encabezados A:I no coinciden. No se modificó la hoja.');
    }
    if (sh.getMaxColumns() < 10) sh.insertColumnsAfter(sh.getMaxColumns(), 10-sh.getMaxColumns());
    var columnaJ = sh.getRange(1, 10, Math.max(1, sh.getLastRow()), 1).getValues();
    if (texto_(columnaJ[0][0]) !== 'PAGOS_APLICADOS' && columnaJ.some(function(r) {
      return texto_(r[0]) !== '';
    })) throw new Error('La columna J está ocupada. No la borres: revisa la integración.');
    var ped = ss.getSheetByName('PEDIDOS_MYG');
    if (ped && ped.getLastRow() &&
        ped.getRange(1, 1, 1, 11).getValues()[0].join('|') !== CAB_PEDIDOS_MYG_.join('|')) {
      throw new Error('PEDIDOS_MYG tiene otra estructura. No se sobrescribió.');
    }
    sh.getRange(1, 10).setValue('PAGOS_APLICADOS');
    if (!ped) ped = ss.insertSheet('PEDIDOS_MYG');
    ped.getRange(1, 1, 1, 11).setValues([CAB_PEDIDOS_MYG_]);
    ped.setFrozenRows(1);
    ped.getRange('H:H').setNumberFormat('@');
    propiedades_().setProperty('MYG_HOJA_ID', ss.getId());
    if (!propiedades_().getProperty('MYG_PAGOS_HABILITADOS')) {
      propiedades_().setProperty('MYG_PAGOS_HABILITADOS', 'NO');
    }
    var existe = ScriptApp.getProjectTriggers().some(function(t) {
      return t.getHandlerFunction() === 'revisarPagosMYG_';
    });
    if (!existe) ScriptApp.newTrigger('revisarPagosMYG_').timeBased().everyMinutes(1).create();
    console.log('Preparado. Tus licencias se conservaron. Configura las propiedades y verifica.');
  });
}
function VERIFICAR_CONFIGURACION() {
  soloAdministrador_();
  comprobarZonas_(libro_());
  urlWeb_();
  vendedor_();
  if (!libro_().getSheetByName('PEDIDOS_MYG')) throw new Error('Ejecuta PREPARAR_INTEGRACION.');
  console.log('Configuración válida. Compras nuevas: ' + (ventas_() ? 'HABILITADAS' : 'DESACTIVADAS') +
    '. Esto no realiza ningún cobro.');
}
function ventas_() { return propiedades_().getProperty('MYG_PAGOS_HABILITADOS') === 'SI'; }
function urlWeb_() {
  var url = texto_(propiedades_().getProperty('MYG_URL_WEB'));
  if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(url)) {
    throw new Error('Configura MYG_URL_WEB con la URL /exec actual.');
  }
  return url;
}
function mp_(ruta, datos) {
  var token = texto_(propiedades_().getProperty('MP_ACCESS_TOKEN_PRODUCCION'));
  if (!token || token.indexOf('TEST-') === 0) throw new Error('Faltan credenciales reales.');
  var opciones = {method: datos ? 'post' : 'get', muteHttpExceptions: true,
    headers: {Authorization: 'Bearer ' + token}};
  if (datos) { opciones.contentType = 'application/json'; opciones.payload = JSON.stringify(datos); }
  var res = UrlFetchApp.fetch('https://api.mercadopago.com' + ruta, opciones);
  if (res.getResponseCode() < 200 || res.getResponseCode() >= 300) {
    throw new Error('MP_HTTP_' + res.getResponseCode());
  }
  return JSON.parse(res.getContentText());
}
function vendedor_() {
  var p = propiedades_(), id = texto_(p.getProperty('MP_VENDEDOR_ID_PRODUCCION'));
  if (!/^\d+$/.test(id)) throw new Error('Falta el ID del vendedor real.');
  var cache = CacheService.getScriptCache();
  var k = 'myg-vendedor-' + hashToken(id + '|' + p.getProperty('MP_ACCESS_TOKEN_PRODUCCION'));
  if (cache.get(k) !== id) {
    var me = mp_('/users/me');
    if (String(me.id) !== id || me.site_id !== 'MPE' || !Array.isArray(me.tags) ||
        me.tags.indexOf('test_user') >= 0) {
      throw new Error('Las credenciales no corresponden al vendedor real de Perú configurado.');
    }
    cache.put(k, id, 300);
  }
  return id;
}
function buscarPedido_(sh, ref) {
  var filas = sh.getDataRange().getValues();
  for (var i = 1; i < filas.length; i++) {
    if (filas[i][0] === ref) return {n: i+1, fila: filas[i]};
  }
  return null;
}
function detalle_(ref, estado, mensaje, pago) {
  conLock_(function() {
    var sh = libro_().getSheetByName('PEDIDOS_MYG'), o = buscarPedido_(sh, ref);
    if (!o || o.fila[6] === 'APLICADO') return;
    var f = o.fila.slice(6, 11);
    if (estado) f[0] = estado;
    if (pago) f[1] = String(pago);
    f[3] = new Date(); f[4] = mensaje;
    sh.getRange(o.n, 7, 1, 5).setValues([f]);
  });
}
function limitarIntentos_(user) {
  // Límite básico por usuario; no sustituye un servicio antiabuso público.
  var c = CacheService.getScriptCache(), k = 'myg-intentos-' + hashToken(user);
  var n = Number(c.get(k) || 0);
  if (n >= 15) throw new Error('Demasiados intentos. Espera unos minutos.');
  c.put(k, String(n+1), 600);
}

// Únicas operaciones públicas de compra: crear y consultar resultado.
function crearCompra(datos) {
  datos = datos || {};
  if (!ventas_()) throw new Error('Las compras están temporalmente desactivadas.');
  var user = usuario_(datos.usuario), clave = texto_(datos.clave);
  var plan = Object.prototype.hasOwnProperty.call(PLANES_MYG_, datos.plan) ? PLANES_MYG_[datos.plan] : null;
  if (!user || user.length > 100 || !clave || clave.length > 128 || !plan) {
    throw new Error('Revisa el usuario, la clave MYG y el plan.');
  }
  limitarIntentos_(user);
  try { comprobarZonas_(libro_()); vendedor_(); urlWeb_(); }
  catch (err) { console.error('Configuración de compra: ' + err.message); throw new Error('Compras no disponibles. Contacta con soporte.'); }
  var reserva = conLock_(function() {
    var ss = libro_(), lic = ss.getSheetByName('LICENCIAS'), ped = ss.getSheetByName('PEDIDOS_MYG');
    var u = buscarUsuario_(lic, user);
    if (u && texto_(u.fila[1]) !== clave) throw new Error('Usuario existente: revisa tu clave MYG.');
    if (u && ['SI','PENDIENTE_PAGO'].indexOf(texto_(u.fila[4]).toUpperCase()) < 0) {
      throw new Error('Esta cuenta requiere atención de soporte antes de comprar.');
    }
    if (u && texto_(u.fila[4]).toUpperCase() === 'SI' &&
        (!u.fila[3] || isNaN(new Date(u.fila[3]).getTime()))) {
      throw new Error('Esta cuenta requiere atención de soporte antes de renovar.');
    }
    if (!u && (!/^[a-z][a-z0-9_.-]{3,39}$/.test(user) ||
        !/^[A-Za-z0-9!@#_.*-]{10,64}$/.test(clave))) {
      throw new Error('Nuevo usuario: 4–40 caracteres, empezando por letra. Clave: 10–64 caracteres; letras, números o ! @ # _ . * -');
    }
    var filas = ped.getDataRange().getValues(), recientes = 0;
    for (var i = filas.length-1; i >= 1; i--) {
      var f = filas[i], edad = Date.now() - new Date(f[1]).getTime();
      if (edad < 86400000) recientes++;
      if (f[2] !== user || ['PENDIENTE','CREANDO'].indexOf(f[6]) < 0 || edad >= 86400000) continue;
      if (f[3] !== datos.plan) throw new Error('Ya tienes un pedido pendiente con otro plan. Contacta con soporte.');
      if (f[8]) return {referencia: f[0], url: f[8], existente: true};
      throw new Error('Tu pedido se está preparando. Espera un momento o contacta con soporte.');
    }
    if (recientes >= 200) throw new Error('Compras temporalmente no disponibles. Contacta con soporte.');
    if (!u) {
      var n = lic.getLastRow()+1;
      lic.getRange(n, 2, 1, 2).setNumberFormat('@');
      lic.getRange(n, 1, 1, 10).setValues([[user,clave,'','','PENDIENTE_PAGO',user,'','SI','','[]']]);
    }
    var ref = 'MYG_' + Utilities.getUuid().replace(/-/g, '');
    ped.appendRow([ref,new Date(),user,datos.plan,plan.precio,plan.meses,'CREANDO','','','','']);
    return {referencia: ref};
  });
  if (reserva.existente) return reserva;
  try {
    var base = urlWeb_() + '?referencia=' + encodeURIComponent(reserva.referencia);
    var pref = mp_('/checkout/preferences', {
      items: [{id: datos.plan, title: plan.titulo, quantity: 1, currency_id: 'PEN', unit_price: plan.precio}],
      external_reference: reserva.referencia,
      back_urls: {success: base, pending: base, failure: base},
      expires: true, expiration_date_to: new Date(Date.now()+86400000).toISOString()
    });
    var url = texto_(pref.init_point);
    if (String(pref.collector_id) !== propiedades_().getProperty('MP_VENDEDOR_ID_PRODUCCION') ||
        !/^https:\/\/([a-z0-9-]+\.)*mercadopago\.(com|com\.pe)\//i.test(url)) {
      throw new Error('Preferencia o URL de checkout no válida.');
    }
    conLock_(function() {
      var sh = libro_().getSheetByName('PEDIDOS_MYG'), o = buscarPedido_(sh, reserva.referencia);
      if (!o || o.fila[6] !== 'CREANDO') throw new Error('Pedido alterado durante su creación.');
      sh.getRange(o.n, 7, 1, 5).setValues([['PENDIENTE','',url,'','']]);
    });
    return {referencia: reserva.referencia, url: url};
  } catch (err) {
    detalle_(reserva.referencia, 'REVISION_MANUAL', 'Creación incompleta: ' + err.message);
    throw new Error('No se pudo preparar el pago. Contacta con soporte. Referencia: ' + reserva.referencia);
  }
}
function consultarCompra(ref) {
  ref = texto_(ref);
  if (!/^MYG_[a-f0-9]{32}$/.test(ref)) throw new Error('Referencia de pedido no válida.');
  var sh = libro_().getSheetByName('PEDIDOS_MYG'), o = sh && buscarPedido_(sh, ref);
  if (!o) throw new Error('No encontramos ese pedido.');
  var estado = o.fila[6];
  if (estado === 'APLICADO') return 'Compra aplicada. Abre Revit e inicia sesión con tu usuario y clave MYG.';
  if (estado === 'REVISION_MANUAL') return 'Tu pedido requiere revisión. Contacta con soporte e indica esta referencia.';
  return 'Aún no se ha confirmado la activación. Si ya pagaste, espera unos minutos y vuelve a consultar.';
}

// CONFIRMACIÓN: siempre mediante API autenticada, nunca por parámetros del navegador.
function motivoPagoInvalido_(p, f, vendedor) {
  if (!p || !/^\d+$/.test(String(p.id))) return 'ID de pago no válido';
  if (p.status !== 'approved') return 'Pago no aprobado';
  if (p.live_mode !== true) return 'Pago no real';
  if (String(p.collector_id) !== String(vendedor)) return 'Vendedor distinto';
  if (p.external_reference !== f[0]) return 'Referencia distinta';
  if (p.currency_id !== 'PEN') return 'Moneda distinta';
  if (!Number.isFinite(Number(p.transaction_amount)) ||
      Math.round(Number(p.transaction_amount)*100) !== Math.round(Number(f[4])*100)) return 'Importe distinto';
  if (p.transaction_amount_refunded == null || Number(p.transaction_amount_refunded) !== 0 ||
      (Array.isArray(p.refunds) && p.refunds.length)) return 'Reembolso o dato de reembolso no válido';
  if (!p.payer || !p.payer.id || String(p.payer.id) === String(vendedor)) return 'Comprador no válido';
  return '';
}
function sumarMeses_(base, meses) {
  var d = new Date(base), dia = d.getDate();
  d.setDate(1);
  d.setMonth(d.getMonth()+meses);
  var ultimo = new Date(d.getFullYear(), d.getMonth()+1, 0).getDate();
  d.setDate(Math.min(dia, ultimo));
  return finDia_(d);
}
function revisionManual_(mensaje) {
  var err = new Error(mensaje);
  err.requiereRevision = true;
  throw err;
}
function aplicarPago_(ref, pago, vendedor) {
  conLock_(function() {
    var ss = libro_(), ped = ss.getSheetByName('PEDIDOS_MYG'), lic = ss.getSheetByName('LICENCIAS');
    var o = buscarPedido_(ped, ref);
    if (!o || o.fila[6] === 'APLICADO') return;
    if (['PENDIENTE','CREANDO'].indexOf(o.fila[6]) < 0) return;
    var motivo = motivoPagoInvalido_(pago, o.fila, vendedor);
    if (motivo) revisionManual_(motivo);
    var u = buscarUsuario_(lic, o.fila[2]);
    if (!u) revisionManual_('No existe la cuenta reservada.');
    var historial;
    try { historial = JSON.parse(texto_(u.fila[9]) || '[]'); }
    catch (err) { revisionManual_('Registro de pagos inválido.'); }
    if (!Array.isArray(historial) || historial.some(function(x) {return !/^\d+$/.test(String(x));})) {
      revisionManual_('Registro de pagos inválido.');
    }
    var pid = String(pago.id), aplicado = historial.map(String).indexOf(pid) >= 0;
    if (!aplicado) {
      var estado = texto_(u.fila[4]).toUpperCase();
      if (['SI','PENDIENTE_PAGO'].indexOf(estado) < 0) revisionManual_('Cuenta bloqueada por el administrador.');
      var meses = Number(o.fila[5]);
      if (meses !== 1 && meses !== 12) revisionManual_('Plazo inválido en el pedido.');
      var ahora = new Date(), base = ahora;
      if (estado === 'SI') {
        if (!u.fila[3] || isNaN(new Date(u.fila[3]).getTime())) revisionManual_('La licencia tiene una fecha inválida.');
        var anterior = finDia_(u.fila[3]);
        if (anterior > base) base = anterior;
      }
      historial.push(pid);
      var registro = JSON.stringify(historial);
      if (registro.length > 45000) revisionManual_('Registro de pagos lleno; requiere revisión.');
      var fila = u.fila.slice(0, 10);
      while (fila.length < 10) fila.push('');
      fila[3] = sumarMeses_(base, meses); fila[4] = 'SI'; fila[9] = registro;
      // Una sola escritura actualiza vencimiento Y marca el pago aplicado.
      // C, H, I se conservan. No se reactiva H si el administrador puso NO.
      lic.getRange(u.n, 1, 1, 10).setValues([fila]);
      SpreadsheetApp.flush();
    }
    // Si hubo un corte después de escribir LICENCIAS, el reintento solo repara
    // el estado del pedido; nunca vuelve a sumar meses.
    ped.getRange(o.n, 7, 1, 5).setValues([['APLICADO',pid,o.fila[8],new Date(),'Pago verificado y registrado.']]);
  });
}
function revisarUno_(ref, vendedor) {
  var sh = libro_().getSheetByName('PEDIDOS_MYG'), o = buscarPedido_(sh, ref);
  if (!o || ['PENDIENTE','CREANDO'].indexOf(o.fila[6]) < 0) return;
  var res = mp_('/v1/payments/search?external_reference=' + encodeURIComponent(ref) + '&limit=100');
  if (!Array.isArray(res.results) || !res.paging || Number(res.paging.total) > 100 ||
      Number(res.paging.total) !== res.results.length) {
    detalle_(ref, 'REVISION_MANUAL', 'Respuesta incompleta o demasiados pagos.'); return;
  }
  var aprobados = res.results.filter(function(p) { return p.status === 'approved'; });
  if (aprobados.length > 1) {
    detalle_(ref, 'REVISION_MANUAL', 'Más de un pago aprobado. Revisar cobros duplicados en Mercado Pago.'); return;
  }
  if (!aprobados.length) {
    var antigua = Date.now()-new Date(o.fila[1]).getTime() > 7*86400000;
    detalle_(ref, antigua ? 'REVISION_MANUAL' : '', antigua ? 'Sin aprobación en 7 días; revisar en MP.' : 'Aún sin pago aprobado.');
    return;
  }
  var id = String(aprobados[0].id);
  if (!/^\d+$/.test(id)) throw new Error('ID de pago inválido.');
  var pago = mp_('/v1/payments/' + id);
  var motivo = motivoPagoInvalido_(pago, o.fila, vendedor);
  if (String(pago.id) !== id) motivo = 'ID devuelto distinto';
  if (motivo) { detalle_(ref, 'REVISION_MANUAL', motivo, id); return; }
  try { aplicarPago_(ref, pago, vendedor); }
  catch (err) {
    detalle_(ref, err.requiereRevision ? 'REVISION_MANUAL' : '',
      (err.requiereRevision ? 'No aplicado: ' : 'Reintento pendiente: ') + err.message, id);
  }
}
function revisarPagosMYG_() {
  var ss = libro_(), ped = ss.getSheetByName('PEDIDOS_MYG');
  if (!ped) return;
  var filas = ped.getDataRange().getValues().slice(1).filter(function(f) {
    return ['PENDIENTE','CREANDO'].indexOf(f[6]) >= 0 && Date.now()-new Date(f[1]).getTime() > 60000;
  });
  if (!filas.length) return;
  comprobarZonas_(ss);
  var vendedor = vendedor_();
  filas.sort(function(a,b) { return (new Date(a[9]).getTime() || 0)-(new Date(b[9]).getTime() || 0); });
  var inicio = Date.now();
  for (var i = 0; i < Math.min(10, filas.length) && Date.now()-inicio < 210000; i++) {
    try { revisarUno_(filas[i][0], vendedor); }
    catch (err) { detalle_(filas[i][0], '', 'Reintento pendiente: ' + err.message); }
  }
}

// Reemplaza SOLO la función pagina_() anterior por todo este archivo.
// Conserva PLANES_MYG_ y todas las funciones de licencias y pagos.
function pagina_() {
  function escapar(v) { return String(v).replace(/[&<>"']/g, function(c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function dinero(v) { return 'S/ ' + Number(v).toFixed(2).replace('.', ','); }
  var disponible = ventas_();
  var planes = Object.keys(PLANES_MYG_).map(function(k, i) {
    var p = PLANES_MYG_[k], anual = p.meses === 12;
    return '<label class="plan"><input type="radio" name="plan" value="'+escapar(k)+'" '+(i===0?'checked':'')+'><span class="plan-body"><span class="plan-top">'+(anual?'Anual':'Mensual')+'<span class="radio"></span></span><strong>'+dinero(p.precio)+'</strong><span class="periodo">Pago único · '+p.meses+' '+(p.meses===1?'mes':'meses')+'</span><span class="plan-note">'+(anual?'Un año para tus proyectos':'Empieza a tu ritmo')+'</span></span></label>';
  }).join('');
  var html = `<!doctype html><html lang="es"><head><base target="_top"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--ink:#142c32;--muted:#607277;--green:#125f51;--line:#dce5e2;--cream:#f5f7f3}*{box-sizing:border-box}body{margin:0;background:var(--cream);color:var(--ink);font:16px/1.6 'Segoe UI',Arial,sans-serif}button,input{font:inherit}button,a,input{ -webkit-tap-highlight-color:transparent}a{color:inherit}button,a.btn{cursor:pointer}button:disabled{opacity:.55;cursor:wait}[hidden]{display:none!important}:focus-visible{outline:3px solid #da9b37;outline-offset:4px}header{max-width:1180px;margin:auto;display:flex;justify-content:space-between;align-items:center;padding:24px 28px}.brand{display:flex;align-items:center;gap:12px;text-decoration:none}.logo{display:grid;place-items:center;width:52px;height:46px;background:var(--green);color:#fff;font-size:18px;font-weight:800;letter-spacing:-1px;border-radius:12px}.brand small{display:block;font-size:11px;letter-spacing:1.8px;color:var(--muted);line-height:1.3}.brand b{font-size:16px}.nav{font-size:13px;text-decoration:none;border-bottom:1px solid #a5bbb3}main{max-width:1180px;margin:auto;padding:24px 28px 48px}.layout{display:grid;grid-template-columns:1fr 480px;gap:64px;align-items:start}.hero{padding-top:18px}.eyebrow{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--green)}h1{font-size:clamp(38px,4.8vw,62px);line-height:1.08;letter-spacing:-2.7px;font-weight:650;margin:20px 0}h1 em{font-style:normal;color:var(--green)}.intro{max-width:440px;font-size:17px;color:var(--muted);margin-bottom:26px}.pills{display:flex;flex-wrap:wrap;gap:8px}.pill{border:1px solid #d4dfd8;background:#fff9;border-radius:30px;font-size:12px;padding:5px 12px}.visual{height:205px;margin:32px 0 24px;border:1px solid #cdded5;border-radius:18px;background:#e8efdf;position:relative;overflow:hidden}.visual svg{width:100%;height:100%}.visual-label{position:absolute;left:18px;bottom:14px;font-size:10px;letter-spacing:1.8px;color:#49634f}.benefits{display:grid;grid-template-columns:1fr 1fr;gap:20px}.benefit b{font-size:14px}.benefit p{font-size:13px;color:var(--muted);margin:5px 0}.check{color:var(--green);margin-right:5px}.card{background:white;border:1px solid var(--line);border-radius:22px;padding:28px;box-shadow:0 16px 50px #143a2810}h2{font-size:24px;line-height:1.25;letter-spacing:-.6px;margin:7px 0}.subtitle{font-size:13px;color:var(--muted);margin:8px 0 20px}.plans{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:18px 0 12px}.plan{position:relative;cursor:pointer}.plan input{position:absolute;opacity:0;width:1px;height:1px}.plan-body{display:block;border:1px solid var(--line);border-radius:13px;padding:16px 14px;transition:background .15s,border-color .15s}.plan input:checked+.plan-body{background:#edf5ef;border:2px solid var(--green);padding:15px 13px}.plan input:focus-visible+.plan-body{outline:3px solid #da9b37;outline-offset:3px}.plan-top{display:flex;justify-content:space-between;align-items:center;font-size:13px;font-weight:650}.radio{width:16px;height:16px;border:1px solid #a9bbb4;border-radius:50%}.plan input:checked+.plan-body .radio{border:5px solid var(--green)}.plan strong{display:block;font-size:28px;letter-spacing:-1px;margin:9px 0 0;white-space:nowrap}.periodo,.plan-note{display:block;font-size:11px;color:var(--muted)}.plan-note{margin-top:13px;padding-top:9px;border-top:1px solid #dce5e2}.included{font-size:12px;color:var(--green);margin:0 0 22px}.fields{border-top:1px solid var(--line);padding-top:20px}.field-label{display:block;font-size:13px;font-weight:600;margin:14px 0 6px}input.text{width:100%;border:1px solid #cbd8d3;border-radius:9px;padding:11px 12px;background:#fcfdfb;min-width:0;color:var(--ink)}input.text:focus{border-color:var(--green);outline:2px solid #125f5120}.password{position:relative}.password input{padding-right:78px}.show{position:absolute;right:7px;top:7px;background:transparent;border:0;padding:6px;color:var(--green);font-size:12px}.hint{font-size:12px;color:var(--muted);margin:8px 0 0}.btn{display:block;width:100%;padding:13px 16px;border:0;border-radius:10px;background:var(--green);color:#fff;text-align:center;text-decoration:none;font-weight:600;font-size:14px}.btn:hover{background:#0d4d41}.primary{margin-top:22px}.payment-note{text-align:center;font-size:11px;color:var(--muted);margin:10px 0 0}.checkout{margin-top:16px;padding:16px;border-radius:12px;background:#eef6f1;border:1px solid #c4ddce}.checkout p{margin:0 0 12px;font-size:13px}.status{padding:12px 14px;border-radius:10px;background:#edf3f8;font-size:13px;white-space:pre-wrap;margin-top:14px;overflow-wrap:anywhere}.status:empty{display:none}.status.error{background:#fff0ee;color:#942e23}.tracking{margin-top:20px;border-top:1px solid var(--line);padding-top:18px}.tracking summary{font-size:13px;font-weight:600;cursor:pointer}.secondary{background:#eff3f0;color:var(--green);margin-top:12px}.secondary:hover{background:#e2ebe5}.disabled-note{padding:12px;background:#fff5db;border-radius:9px;font-size:13px}.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:32px;border-top:1px solid #d6e1da;margin-top:48px;padding-top:28px}.step-num{font-size:11px;color:var(--green);font-weight:700;letter-spacing:1px}.steps h3{font-size:15px;margin:6px 0}.steps p{font-size:13px;color:var(--muted);margin:0}footer{max-width:1124px;margin:auto;padding:0 28px 28px;display:flex;justify-content:space-between;gap:16px;color:var(--muted);font-size:11px}.save{font-size:12px;color:var(--green);margin:0 0 18px}.new-info{margin-top:10px;font-size:12px;color:var(--muted)}.new-info summary{cursor:pointer} .new-info p{margin:8px 0}
@media(max-width:950px){.layout{grid-template-columns:1fr 430px;gap:30px}h1{font-size:46px}.card{padding:22px}}@media(max-width:760px){header{padding:18px 20px}main{padding:6px 20px 32px}.layout{grid-template-columns:1fr;gap:26px}.hero{padding-top:0}h1{font-size:43px;letter-spacing:-1.8px;margin:16px 0}.intro{font-size:15px;max-width:none;margin-bottom:18px}.visual{display:none}.benefits{margin-top:22px}.card{padding:22px}.steps{gap:22px;grid-template-columns:1fr;margin-top:28px}.nav{font-size:11px}footer{padding:0 20px 24px}.plan strong{font-size:27px}}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;transition:none!important}}
</style></head><body>
<header><a class="brand" href="#"><span class="logo">MYG</span><span><b>Herramientas BIM</b><small>COMPLEMENTOS PARA REVIT</small></span></a><a class="nav" href="#seguimiento" id="ver-pedido">Consultar mi compra ↗</a></header>
<main><div class="layout"><section class="hero"><span class="eyebrow">Tu próximo proyecto, con MYG</span><h1>Menos tareas repetitivas.<br><em>Más tiempo para diseñar.</em></h1><p class="intro">Lleva tus proyectos un paso más allá con los dos complementos MYG para Revit, incluidos en una sola licencia.</p><div class="pills"><span class="pill">2 complementos incluidos</span><span class="pill">Pago único por período</span></div>
<div class="visual" aria-hidden="true"><svg viewBox="0 0 500 210" fill="none"><defs><pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M24 0H0V24" stroke="#cddac3" stroke-width=".6"/></pattern></defs><rect width="500" height="210" fill="url(#grid)"/><g stroke="#47715b" stroke-width="1.4" stroke-linejoin="round"><path d="M133 134L272 190L400 118L260 62Z" fill="#d9e6d0"/><path d="M133 97L272 153L400 81L260 25Z" fill="#f8faee"/><path d="M133 97V134M272 153V190M400 81V118M260 25V62M179 116V153M226 135V172M315 129V166M357 105V142"/><path d="M133 60L272 116L400 44L260 -12Z" fill="#f8faee"/><path d="M133 60V97M272 116V153M400 44V81M179 79V116M226 98V135M315 92V129M357 68V105"/><path d="M150 59L272 108L382 46M151 96L272 145L382 83M150 133L272 182L382 120" stroke="#abc29e"/></g><circle cx="98" cy="111" r="5" fill="#125f51"/><path d="M98 106V50H50" stroke="#125f51"/><rect x="29" y="31" width="65" height="25" rx="5" fill="#fff"/><text x="42" y="48" fill="#125f51" font-size="10" font-family="Arial">BIM / MYG</text></svg><span class="visual-label">DISEÑA · MODELA · CONSTRUYE</span></div>
<div class="benefits"><div class="benefit"><b><span class="check">✓</span>Una licencia, ambos add-ins</b><p>Accede a los dos complementos con tu cuenta MYG.</p></div><div class="benefit"><b><span class="check">✓</span>Activación tras el pago</b><p>Consulta tu estado y empieza desde Revit.</p></div></div></section>
<section class="card" aria-label="Comprar licencia"><span class="eyebrow">Elige tu siguiente paso</span><h2>Tu licencia MYG</h2><p class="subtitle">Compra por primera vez o renueva tu acceso.</p>
${disponible?'':'<p class="disabled-note">Las compras están temporalmente desactivadas. Puedes consultar un pedido existente más abajo.</p>'}
<form id="compra"><div class="plans" role="group" aria-label="Planes disponibles">${planes}</div><p class="included">✓ Ambos complementos incluidos en cada plan.</p><div class="fields"><b style="font-size:14px">Tus datos de acceso</b><p class="hint">Si ya usas MYG, ingresa tu usuario y contraseña actuales.</p><label class="field-label" for="usuario">Usuario MYG</label><input class="text" id="usuario" autocomplete="username" maxlength="100" placeholder="Tu usuario" required><label class="field-label" for="clave">Contraseña MYG</label><div class="password"><input class="text" id="clave" type="password" autocomplete="current-password" maxlength="128" placeholder="Tu contraseña MYG" required><button class="show" type="button" id="mostrar" aria-label="Mostrar contraseña" aria-pressed="false">Mostrar</button></div><details class="new-info"><summary>¿Es tu primera compra?</summary><p>Elige un usuario de 4 a 40 caracteres: empieza con una letra y utiliza letras sin tildes, números, punto, guion o guion bajo. Crea una contraseña de 10 a 64 caracteres con letras, números o estos símbolos: ! @ # _ . * -</p><p>Guarda estos datos: los usarás para iniciar sesión en Revit.</p></details></div><button class="btn primary" id="crear" ${disponible?'':'disabled'}>Continuar con mi compra →</button><p class="payment-note">Paga con Yape o tarjeta a través de Mercado Pago.<br>Sin renovación ni cargos recurrentes automáticos.</p></form>
<div class="checkout" id="checkout" hidden><p><b>Tu pedido está listo.</b><br>Continúa para revisar el importe y completar tu pago.</p><a class="btn" id="pagar" target="_blank" rel="noopener noreferrer">Ir a Mercado Pago ↗</a><p class="hint" style="margin-top:10px;margin-bottom:0">Se abre en otra pestaña. Después regresa y consulta tu activación.</p></div><div id="mensaje" class="status" role="status" aria-live="polite"></div>
<details class="tracking" id="seguimiento"><summary>¿Ya pagaste? Consulta tu activación</summary><label class="field-label" for="referencia">Referencia del pedido</label><input class="text" id="referencia" maxlength="36" placeholder="MYG_…" spellcheck="false"><p class="hint">La completamos al crear tu pedido en este navegador. Consérvala para futuras consultas.</p><button class="btn secondary" id="consultar" type="button">Consultar activación</button><div id="estado" class="status" role="status" aria-live="polite"></div></details></section></div>
<section class="steps" aria-label="Cómo empezar"><div><span class="step-num">01 / ELIGE</span><h3>El plan que va contigo</h3><p>Un mes para empezar o doce meses para dar continuidad a tus proyectos.</p></div><div><span class="step-num">02 / COMPLETA</span><h3>Paga en Mercado Pago</h3><p>Selecciona el medio de pago disponible que prefieras y confirma tu compra.</p></div><div><span class="step-num">03 / EMPIEZA</span><h3>Abre MYG en Revit</h3><p>Una vez activada tu licencia, inicia sesión. El primer ingreso vincula tu computadora.</p></div></section></main><footer><span>MYG · Herramientas para tus proyectos BIM</span><span>Precios en soles peruanos.</span></footer>
<script>
var el=function(id){return document.getElementById(id);};
var disponible=${disponible?'true':'false'};
function mensaje(id,texto,fallo){el(id).textContent=texto;el(id).className='status'+(fallo?' error':'');}
function guardarRef(r){el('referencia').value=r;try{localStorage.setItem('myg-ultimo-pedido',r);}catch(e){}}
function fallo(id,e){mensaje(id,e&&e.message?e.message:'No pudimos completar la solicitud. Inténtalo nuevamente.',true);}
el('mostrar').addEventListener('click',function(){var visible=el('clave').type==='password';el('clave').type=visible?'text':'password';this.textContent=visible?'Ocultar':'Mostrar';this.setAttribute('aria-pressed',String(visible));this.setAttribute('aria-label',visible?'Ocultar contraseña':'Mostrar contraseña');});
el('ver-pedido').addEventListener('click',function(){el('seguimiento').open=true;});
el('compra').addEventListener('submit',function(ev){ev.preventDefault();if(!disponible)return;el('crear').disabled=true;el('crear').textContent='Preparando tu pedido…';el('checkout').hidden=true;mensaje('mensaje','Estamos preparando tu compra. Espera un momento.');
google.script.run.withSuccessHandler(function(r){guardarRef(r.referencia);el('pagar').href=r.url;el('checkout').hidden=false;el('crear').disabled=false;el('crear').textContent='Preparar otro pedido';mensaje('mensaje','');el('checkout').scrollIntoView({block:'nearest'});el('pagar').focus();}).withFailureHandler(function(e){el('crear').disabled=false;el('crear').textContent='Continuar con mi compra →';fallo('mensaje',e);}).crearCompra({usuario:el('usuario').value,clave:el('clave').value,plan:document.querySelector('input[name="plan"]:checked').value});});
el('consultar').addEventListener('click',function(){var r=el('referencia').value.trim();if(!/^MYG_[a-f0-9]{32}$/.test(r)){mensaje('estado','Ingresa la referencia completa de tu pedido, que empieza por MYG_.',true);el('referencia').focus();return;}el('consultar').disabled=true;el('consultar').textContent='Consultando…';mensaje('estado','Comprobando el estado de tu licencia…');google.script.run.withSuccessHandler(function(s){mensaje('estado',s);el('consultar').disabled=false;el('consultar').textContent='Consultar activación';}).withFailureHandler(function(e){fallo('estado',e);el('consultar').disabled=false;el('consultar').textContent='Consultar activación';}).consultarCompra(r);});
google.script.url.getLocation(function(loc){var r=(loc.parameter||{}).referencia||'';var retorno=!!r;if(!r){try{r=localStorage.getItem('myg-ultimo-pedido')||'';}catch(e){}}if(/^MYG_[a-f0-9]{32}$/.test(r)){guardarRef(r);el('seguimiento').open=true;if(retorno)el('consultar').click();}});
</script></body></html>`;
  return HtmlService.createHtmlOutput(html).setTitle('MYG | Licencias para Revit');
}


function MOSTRAR_ID_VENDEDOR() {
  soloAdministrador_();

  var cuenta = mp_('/users/me');

  if (!cuenta.id || !Array.isArray(cuenta.tags)) {
    throw new Error('No se pudo verificar la cuenta.');
  }

  if (cuenta.tags.indexOf('test_user') >= 0) {
    throw new Error('El token pertenece a una cuenta de prueba.');
  }

  console.log('ID DEL VENDEDOR REAL: ' + cuenta.id);
}
// NUBE MYG: revalidación sin rotar el token del inicio de sesión original.
// Estas acciones son POST; no escriben C, G, H, I ni pedidos.
// Sólo nube_ticket puede añadir/guardar el identificador estable ID_MYG_NUBE.
function despachoNubeMYG_(p, accion) {
  try {
    return conLock_(function() {
      var validacion = validarSesionNubeMYG_(p);
      if (validacion.codigo !== 'OK') {
        return accion === 'nube_ticket' ? respuestaJsonNubeMYG_({ok: false,
          codigo: validacion.codigo}) : respuesta(validacion.codigo);
      }
      if (accion === 'validar_sesion') return respuesta('OK');
      var configuracion = configuracionNubeMYG_();
      if (!configuracion) return respuestaJsonNubeMYG_({ok: false, codigo: 'NUBE_NO_CONFIGURADA'});
      if ('audiencia' in p && urlNubeMYG_(p.audiencia) !== configuracion.url) {
        return respuestaJsonNubeMYG_({ok: false, codigo: 'AUDIENCIA_INVALIDA'});
      }
      var identidad = identidadLicenciaNubeMYG_(validacion.hoja, validacion.fila);
      if (identidad.codigo !== 'OK') {
        return respuestaJsonNubeMYG_({ok: false, codigo: identidad.codigo});
      }
      var ahora = Math.floor(new Date().getTime() / 1000);
      var carga = {iss: 'MYG_LICENCIAS', aud: configuracion.url, sub: validacion.usuario,
        pc: hashToken(texto_(p.pc)), jti: Utilities.getUuid().toLowerCase(),
        iat: ahora, exp: ahora + 60, licencia_id: identidad.id};
      var cabecera = base64UrlNubeMYG_(JSON.stringify({alg: 'HS256', typ: 'JWT'}));
      var cuerpo = base64UrlNubeMYG_(JSON.stringify(carga));
      var entrada = cabecera + '.' + cuerpo;
      // El secreto se usa como texto UTF-8 literal, nunca se decodifica como hexadecimal.
      var firma = Utilities.computeHmacSha256Signature(entrada, configuracion.secreto,
        Utilities.Charset.UTF_8);
      return respuestaJsonNubeMYG_({ok: true,
        ticket: entrada + '.' + base64UrlNubeMYG_(firma), usuario: validacion.usuario,
        expira_en: carga.exp, audiencia: configuracion.url});
    });
  } catch (err) {
    // No devolver excepciones de Sheets, propiedades ni datos de la credencial.
    return accion === 'nube_ticket' ? respuestaJsonNubeMYG_({ok: false, codigo: 'ERROR'}) :
      respuesta('ERROR');
  }
}
function validarSesionNubeMYG_(p) {
  var user = usuario_(p.usuario), pc = texto_(p.pc);
  var clave = texto_(p.clave), token = texto_(p.token);
  if (!usuarioValidoNubeMYG_(user) || !pc || (!clave && !token) || (clave && token)) {
    return {codigo: 'DATOS_INCOMPLETOS'};
  }
  var sh = libro_().getSheetByName('LICENCIAS');
  if (!sh) return {codigo: 'SIN_HOJA'};
  var u = buscarUsuario_(sh, user);
  if (!u) return {codigo: 'NO_EXISTE'};
  if (clave && texto_(u.fila[1]) !== clave) return {codigo: 'CLAVE_ERROR'};
  var estado = licenciaVigente(u.fila);
  if (estado !== 'OK') return {codigo: estado};
  if (token && texto_(u.fila[7]).toUpperCase() !== 'SI') {
    return {codigo: 'AUTO_DESACTIVADO'};
  }
  // Sólo el login manual original puede registrar por primera vez MACHINE_ID.
  if (texto_(u.fila[2]) !== pc) return {codigo: 'OTRA_PC'};
  if (token && (!texto_(u.fila[8]) || texto_(u.fila[8]).toUpperCase() !== hashToken(token))) {
    return {codigo: 'TOKEN_INVALIDO'};
  }
  return {codigo: 'OK', usuario: user, hoja: sh, fila: u.n};
}
function uuidLicenciaNubeMYG_(valor) {
  var id = texto_(valor).toLowerCase();
  return /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(id) &&
    id !== '00000000-0000-0000-0000-000000000000' ? id : '';
}
function columnaIdentidadNubeMYG_(sh) {
  var ultimaColumna = sh.getLastColumn();
  var cabecera = sh.getRange(1, 1, 1, Math.max(1, ultimaColumna)).getValues()[0];
  var columna = 0;
  for (var c = 0; c < cabecera.length; c++) {
    if (texto_(cabecera[c]).toUpperCase() !== 'ID_MYG_NUBE') continue;
    if (columna) return {codigo: 'LICENCIA_ID_CABECERA_DUPLICADA'};
    columna = c + 1;
  }
  if (columna && columna <= 10) return {codigo: 'LICENCIA_ID_INVALIDO'};
  var usados = Object.create(null), porFila = Object.create(null);
  if (columna) {
    var filas = sh.getDataRange().getValues();
    for (var f = 1; f < filas.length; f++) {
      var valor = texto_(filas[f][columna - 1]);
      if (!valor) continue;
      var id = uuidLicenciaNubeMYG_(valor);
      if (!id) return {codigo: 'LICENCIA_ID_INVALIDO'};
      if (usados[id]) return {codigo: 'LICENCIA_ID_DUPLICADO'};
      usados[id] = true;
      porFila[f + 1] = id;
    }
  } else {
    // A:J pertenece a las licencias/pagos originales, aunque J esté aún vacía.
    // Se añade al final de los datos: nunca se reutiliza una columna ocupada.
    columna = Math.max(10, ultimaColumna) + 1;
    var capacidad = sh.getMaxColumns();
    if (columna > capacidad) sh.insertColumnsAfter(capacidad, columna - capacidad);
    sh.getRange(1, columna).setValue('ID_MYG_NUBE');
  }
  return {codigo: 'OK', columna: columna, usados: usados, porFila: porFila};
}
function identidadLicenciaNubeMYG_(sh, fila) {
  // El bloqueo de despacho ya está tomado. La fila sólo localiza la celda:
  // la identidad persistente y firmada es siempre su UUID, nunca el número de fila.
  var columna = columnaIdentidadNubeMYG_(sh);
  if (columna.codigo !== 'OK') return columna;
  var id = columna.porFila[fila];
  if (!id) {
    id = uuidLicenciaNubeMYG_(Utilities.getUuid());
    if (!id) return {codigo: 'LICENCIA_ID_INVALIDO'};
    if (columna.usados[id]) return {codigo: 'LICENCIA_ID_DUPLICADO'};
    sh.getRange(fila, columna.columna).setValue(id);
    SpreadsheetApp.flush();
  }
  return {codigo: 'OK', id: id};
}
function usuarioValidoNubeMYG_(user) {
  return user.length > 0 && user.length <= 256 && !/[\u0000-\u001f\u007f]/.test(user) &&
    !/[\ud800-\udfff]/.test(user.replace(/[\ud800-\udbff][\udc00-\udfff]/g, ''));
}
function urlNubeMYG_(valor) {
  var url = texto_(valor).toLowerCase();
  if (!/^https:\/\/[a-z0-9]+(?:-[a-z0-9]+)*\.supabase\.co\/?$/.test(url)) return '';
  return url.replace(/\/$/, '');
}
function configuracionNubeMYG_() {
  var propiedades = propiedades_();
  var url = urlNubeMYG_(propiedades.getProperty('MYG_NUBE_URL'));
  var secreto = propiedades.getProperty('MYG_NUBE_HMAC');
  if (!url || !secreto || !/^[a-fA-F0-9]{64}$/.test(secreto)) return null;
  return {url: url, secreto: secreto};
}
function base64UrlNubeMYG_(valor) {
  var codificado = typeof valor === 'string' ?
    Utilities.base64EncodeWebSafe(valor, Utilities.Charset.UTF_8) :
    Utilities.base64EncodeWebSafe(valor);
  return codificado.replace(/=+$/, '');
}
function respuestaJsonNubeMYG_(valor) {
  return respuesta(JSON.stringify(valor)).setMimeType(ContentService.MimeType.JSON);
}

// Ejecutar exclusivamente desde el editor con la cuenta propietaria.
// No habilita pagos ni instala activadores; puede añadir la columna ID_MYG_NUBE.
function PREPARAR_NUBE_MYG() {
  soloAdministrador_();
  conLock_(function() {
    comprobarZonas_(libro_());
    var sh = libro_().getSheetByName('LICENCIAS');
    if (!sh) throw new Error('No existe LICENCIAS.');
    var propiedades = propiedades_();
    if (!urlNubeMYG_(propiedades.getProperty('MYG_NUBE_URL'))) {
      throw new Error('Configura MYG_NUBE_URL como https://referencia.supabase.co en las propiedades del script.');
    }
    var secreto = propiedades.getProperty('MYG_NUBE_HMAC');
    if (secreto && !/^[a-fA-F0-9]{64}$/.test(secreto)) {
      throw new Error('MYG_NUBE_HMAC no tiene el formato esperado. Revisa su configuración sin compartirlo.');
    }
    var columna = columnaIdentidadNubeMYG_(sh);
    if (columna.codigo !== 'OK') throw new Error('Revisa ID_MYG_NUBE: ' + columna.codigo);
    SpreadsheetApp.flush();
    if (!secreto) {
      // Dos UUID aleatorios, sin guiones: 64 caracteres hexadecimales.
      secreto = (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '').toLowerCase();
      propiedades.setProperty('MYG_NUBE_HMAC', secreto);
    }
    console.log('Nube MYG preparada. Copia el secreto desde las propiedades al entorno seguro de la función de Supabase.');
  });
}
function VERIFICAR_NUBE_MYG() {
  soloAdministrador_();
  comprobarZonas_(libro_());
  if (!libro_().getSheetByName('LICENCIAS')) throw new Error('No existe LICENCIAS.');
  if (!configuracionNubeMYG_()) {
    throw new Error('Nube MYG sin configurar: revisa MYG_NUBE_URL y MYG_NUBE_HMAC en las propiedades del script.');
  }
  console.log('Nube MYG configurada: URL válida, secreto presente y tickets de 60 segundos.');
}
