import assert from 'node:assert/strict';
import { createHash, createHmac, randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const source = readFileSync(new URL('../Codigo.gs', import.meta.url), 'utf8').replace(/\r\n/g, '\n');
const legacy = JSON.parse(readFileSync(new URL('./legacy.sha256.json', import.meta.url), 'utf8'));
const dispatcher = "  var accionNube = texto_(p.accion).toLowerCase();\n" +
  "  if (accionNube === 'validar_sesion' || accionNube === 'nube_ticket') {\n" +
  "    return despachoNubeMYG_(p, accionNube);\n  }\n";
const secret = 'a1'.repeat(32); // Sólo fixture local, no es una credencial real.
const audience = 'https://testproject.supabase.co';
const sha = value => createHash('sha256').update(value).digest('hex').toUpperCase();
const json = value => JSON.parse(JSON.stringify(value));
const today = new Date();
const future = new Date(today.getFullYear() + 1, today.getMonth(), today.getDate());
const expired = new Date(today.getFullYear() - 1, today.getMonth(), today.getDate());
const header = ['USUARIO', 'CLAVE', 'MACHINE_ID', 'EXPIRA', 'ACTIVO', 'NOMBRE',
  'ULTIMO LOGIN', 'ING. AUTOM.', 'TOKEN_HASH', 'PAGOS_APLICADOS'];
function fixtures() {
  return [header.slice(), ['ana', 'clave-ana', 'PC-A', future, 'SI', 'Ana', '', 'SI', sha('token-ana'), '[]'],
    ['beto', 'clave-beto', 'PC-B', future, 'SI', 'Beto', '', 'SI', sha('token-beto'), '[]']];
}

function environment(options = {}) {
  const rows = structuredClone(options.rows ?? fixtures());
  const writes = [], logs = [];
  const properties = { MYG_NUBE_URL: audience, MYG_NUBE_HMAC: secret,
    MYG_PAGOS_HABILITADOS: 'NO', ...options.properties };
  let networkCalls = 0, sheetsCreated = 0, scriptTriggers = 0;
  let maxColumns = options.maxColumns ?? 26;
  const columnChanges = [];
  const lastColumn = () => Math.max(0, ...rows.map(row => row.reduce((last, value, index) =>
    value !== '' && value !== null && value !== undefined ? index + 1 : last, 0)));
  const sheet = {
    getDataRange: () => ({ getValues: () => rows.map(row =>
      Array.from({ length: lastColumn() }, (_, index) => structuredClone(row[index] ?? ''))) }),
    getLastColumn: lastColumn,
    getMaxColumns: () => maxColumns,
    insertColumnsAfter: (position, count) => {
      assert.equal(position, maxColumns, 'sólo ampliar después de la capacidad existente');
      maxColumns += count;
      columnChanges.push([position, count]);
    },
    getRange: (row, column, height = 1, width = 1) => ({
      getValues: () => Array.from({ length: height }, (_, i) =>
        Array.from({ length: width }, (_, j) => rows[row - 1 + i]?.[column - 1 + j] ?? '')),
      setValue(value) { rows[row - 1][column - 1] = value; writes.push([row, column]); return this; },
      setValues(values) {
        values.forEach((line, i) => line.forEach((value, j) => {
          rows[row - 1 + i][column - 1 + j] = value; writes.push([row + i, column + j]);
        }));
        return this;
      },
      clearContent() { rows[row - 1][column - 1] = ''; writes.push([row, column]); return this; }
    })
  };
  const book = {
    getSheetByName: name => name === 'LICENCIAS' && !options.missingSheet ? sheet : null,
    getSpreadsheetTimeZone: () => 'America/Lima',
    insertSheet() { sheetsCreated++; throw new Error('No se permiten hojas nuevas en SSO.'); }
  };
  const ctx = vm.createContext({
    console: { log: (...values) => logs.push(values.join(' ')) },
    ContentService: {
      MimeType: { JSON: 'application/json' },
      createTextOutput: content => ({
        content, mimeType: 'text/plain', getContent() { return this.content; },
        setMimeType(value) { this.mimeType = value; return this; }
      })
    },
    PropertiesService: { getScriptProperties: () => ({
      getProperty: name => properties[name] ?? null,
      setProperty: (name, value) => { properties[name] = value; }
    }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    SpreadsheetApp: { getActiveSpreadsheet: () => book, openById: () => book,
      flush() {} },
    Utilities: {
      DigestAlgorithm: { SHA_256: 'sha256' }, Charset: { UTF_8: 'utf8' },
      computeDigest: (_algorithm, value) => [...createHash('sha256').update(value).digest()]
        .map(value => value > 127 ? value - 256 : value),
      computeHmacSha256Signature: (value, key) => [...createHmac('sha256', key).update(value).digest()]
        .map(value => value > 127 ? value - 256 : value),
      base64EncodeWebSafe: (value, charset) => {
        if (typeof value === 'string') assert.equal(charset, 'utf8');
        else assert.equal(charset, undefined, 'la sobrecarga Byte[] no recibe Charset');
        return (typeof value === 'string' ? Buffer.from(value, 'utf8') :
          Buffer.from(value.map(value => (value + 256) % 256))).toString('base64url');
      },
      getUuid: randomUUID
    },
    Session: {
      getActiveUser: () => ({ getEmail: () => options.nonAdmin ? '' : 'owner@example.test' }),
      getEffectiveUser: () => ({ getEmail: () => 'owner@example.test' }),
      getScriptTimeZone: () => 'America/Lima'
    },
    UrlFetchApp: { fetch() { networkCalls++; throw new Error('Prueba sin acceso a la red.'); } },
    ScriptApp: {
      newTrigger() { scriptTriggers++; throw new Error('No se permiten activadores en SSO.'); }
    },
    HtmlService: { createHtmlOutput: value => ({
      content: value, setTitle() { return this; }, addMetaTag() { return this; }
    }) }
  });
  vm.runInContext(source, ctx, { filename: 'Codigo.gs' });
  return { ctx, rows, writes, columnChanges, properties, logs, sheet,
    counters: () => ({ networkCalls, sheetsCreated, scriptTriggers }),
    post: parameters => ctx.doPost({ parameter: parameters }),
    get: parameters => ctx.doGet({ parameter: parameters }) };
}
function request(extra = {}) {
  return { accion: 'validar_sesion', usuario: 'ana', pc: 'PC-A', token: 'token-ana', ...extra };
}
function ticket(env, extra = {}) {
  const output = env.post(request({ accion: 'nube_ticket', ...extra }));
  assert.equal(output.mimeType, 'application/json');
  return JSON.parse(output.content);
}
function payload(result) {
  assert.equal(result.ok, true);
  return JSON.parse(Buffer.from(result.ticket.split('.')[1], 'base64url'));
}
function fixturesWithIds() {
  const rows = fixtures();
  rows[0][10] = 'ID_MYG_NUBE';
  rows[1][10] = '12345678-1234-1234-1234-123456789abc';
  rows[2][10] = '87654321-4321-4321-4321-cba987654321';
  return rows;
}

test('el original completo se conserva salvo el dispatcher añadido a doPost', () => {
  const marker = '\n// NUBE MYG: revalidación sin rotar';
  const at = source.indexOf(marker);
  assert.ok(at > 0);
  const prefix = source.slice(0, at);
  assert.equal(prefix.split(dispatcher).length, 2, 'debe existir exactamente un dispatcher');
  const restored = prefix.replace(dispatcher, '');
  assert.equal(createHash('sha256').update(restored).digest('hex'), legacy.sha256Lf);
  const { ctx } = environment();
  for (const [name, hash] of Object.entries(legacy.funciones)) {
    if (name === 'doPost') continue;
    assert.equal(createHash('sha256').update(ctx[name].toString()).digest('hex'), hash, name);
  }
  assert.equal(ctx.PLANES_MYG_.mensual.precio, 23);
  assert.equal(ctx.PLANES_MYG_.anual.precio, 210);
});

test('dos usuarios y sus PC conservan licencias/tokens y sólo reciben UUID propios al pedir ticket', () => {
  const env = environment();
  const before = structuredClone(env.rows);
  for (let i = 0; i < 4; i++) {
    assert.equal(env.post(request()).content, 'OK');
    assert.equal(env.post(request({ usuario: 'beto', pc: 'PC-B', token: 'token-beto' })).content, 'OK');
    assert.equal(env.post(request({ token: '', clave: 'clave-ana' })).content, 'OK');
    assert.equal(ticket(env).ok, true);
    assert.equal(ticket(env, { usuario: 'beto', pc: 'PC-B', token: 'token-beto' }).ok, true);
  }
  assert.deepEqual(env.rows.map(row => row.slice(0, 10)), before);
  assert.equal(env.rows[0][10], 'ID_MYG_NUBE');
  assert.match(env.rows[1][10], /^[a-f0-9-]{36}$/);
  assert.match(env.rows[2][10], /^[a-f0-9-]{36}$/);
  assert.notEqual(env.rows[1][10], env.rows[2][10]);
  assert.deepEqual(env.writes, [[1, 11], [2, 11], [3, 11]]);
  assert.deepEqual(env.counters(), { networkCalls: 0, sheetsCreated: 0, scriptTriggers: 0 });
});

test('validar_sesion nunca crea cabecera ni UUID incluso si faltan', () => {
  const env = environment();
  const before = structuredClone(env.rows);
  assert.equal(env.post(request()).content, 'OK');
  assert.equal(env.post(request({ clave: 'clave-ana', token: '' })).content, 'OK');
  assert.deepEqual(env.rows, before);
  assert.deepEqual(env.writes, []);
  assert.deepEqual(env.columnChanges, []);
});

test('primera alta añade ID tras toda columna ocupada sin reutilizar huecos ni perder datos', () => {
  const rows = fixtures();
  rows[0][10] = 'NOTAS';
  rows[1][10] = 'Dato de licencia';
  rows[2][14] = 'Dato sin cabecera';
  const env = environment({ rows, maxColumns: 15 });
  const before = structuredClone(env.rows);
  const result = payload(ticket(env));
  assert.equal(env.rows[0][15], 'ID_MYG_NUBE');
  assert.equal(env.rows[1][15], result.licencia_id);
  for (let row = 0; row < before.length; row++) {
    assert.deepEqual(env.rows[row].slice(0, before[row].length), before[row]);
  }
  assert.deepEqual(env.writes, [[1, 16], [2, 16]]);
  assert.deepEqual(env.columnChanges, [[15, 1]]);
});

test('reserva J para pagos originales aunque una hoja antigua sólo tenga A:I', () => {
  const rows = fixtures().map(row => row.slice(0, 9));
  const env = environment({ rows });
  payload(ticket(env));
  assert.equal(env.rows[0][10], 'ID_MYG_NUBE');
  assert.equal(env.rows[0][9], undefined);
  assert.equal(env.rows[1][9], undefined);
  assert.deepEqual(env.writes, [[1, 11], [2, 11]]);
});

test('ID existente se conserva al renombrar usuario y mover/reordenar su fila', () => {
  const env = environment({ rows: fixturesWithIds() });
  const id = payload(ticket(env)).licencia_id;
  env.rows[1][0] = 'ana nueva';
  [env.rows[1], env.rows[2]] = [env.rows[2], env.rows[1]];
  assert.equal(payload(ticket(env, { usuario: 'ana nueva' })).licencia_id, id);
  assert.equal(env.rows[2][10], id);
  assert.deepEqual(env.writes, []);
});

test('borrar y recrear un usuario genera otro UUID, aunque nombre y credenciales coincidan', () => {
  const env = environment({ rows: fixturesWithIds() });
  const previous = payload(ticket(env)).licencia_id;
  const recreated = env.rows[1].slice(0, 10);
  env.rows.splice(1, 1);
  env.rows.push(recreated);
  const current = payload(ticket(env)).licencia_id;
  assert.notEqual(current, previous);
  assert.equal(env.rows[2][10], current);
  assert.deepEqual(env.writes, [[3, 11]]);
});

test('UUID existente en mayúsculas se firma canónico sin reescribir la celda', () => {
  const rows = fixturesWithIds();
  rows[1][10] = rows[1][10].toUpperCase();
  const env = environment({ rows });
  assert.equal(payload(ticket(env)).licencia_id, rows[1][10].toLowerCase());
  assert.equal(env.rows[1][10], rows[1][10]);
  assert.deepEqual(env.writes, []);
});

for (const invalid of ['no-es-uuid', '00000000-0000-0000-0000-000000000000',
  '12345678123412341234123456789abc']) {
  test(`ID inválido se bloquea en toda la columna sin reasignar: ${invalid}`, () => {
    const rows = fixturesWithIds(); rows[2][10] = invalid; rows[2][4] = 'NO';
    const env = environment({ rows });
    assert.deepEqual(ticket(env), { ok: false, codigo: 'LICENCIA_ID_INVALIDO' });
    assert.deepEqual(env.rows, rows);
    assert.deepEqual(env.writes, []);
    assert.equal(env.post(request()).content, 'OK', 'revalidar no altera ni depende de los ID nube');
  });
}

test('UUID duplicados, incluyendo variantes mayúsculas, impiden emitir tickets', () => {
  const rows = fixturesWithIds(); rows[2][10] = rows[1][10].toUpperCase();
  const env = environment({ rows });
  assert.deepEqual(ticket(env), { ok: false, codigo: 'LICENCIA_ID_DUPLICADO' });
  assert.throws(() => env.ctx.PREPARAR_NUBE_MYG(), /LICENCIA_ID_DUPLICADO/);
  assert.deepEqual(env.rows, rows);
  assert.deepEqual(env.writes, []);
});

test('cabecera ID_MYG_NUBE duplicada se rechaza en vez de elegir arbitrariamente', () => {
  const rows = fixturesWithIds(); rows[0][13] = ' id_myg_nube ';
  const env = environment({ rows });
  assert.deepEqual(ticket(env), { ok: false, codigo: 'LICENCIA_ID_CABECERA_DUPLICADA' });
  assert.throws(() => env.ctx.PREPARAR_NUBE_MYG(), /LICENCIA_ID_CABECERA_DUPLICADA/);
  assert.deepEqual(env.rows, rows);
  assert.deepEqual(env.writes, []);
});

test('cabecera situada en A:J se rechaza para proteger la estructura original', () => {
  const rows = fixtures(); rows[0][5] = 'ID_MYG_NUBE'; rows[1][5] = ''; rows[2][5] = '';
  const env = environment({ rows });
  assert.deepEqual(ticket(env), { ok: false, codigo: 'LICENCIA_ID_INVALIDO' });
  assert.deepEqual(env.rows, rows);
  assert.deepEqual(env.writes, []);
});

test('ticket HS256: firma UTF-8 literal, payload exacto, UUID y duración de 60 segundos', () => {
  const env = environment();
  const result = ticket(env, { usuario: '  ANA  ', audiencia: 'https://TESTPROJECT.supabase.co/' });
  assert.deepEqual(Object.keys(result).sort(), ['audiencia', 'expira_en', 'ok', 'ticket', 'usuario']);
  assert.equal(result.usuario, 'ana');
  assert.equal(result.audiencia, audience);
  const [head, body, signature, excess] = result.ticket.split('.');
  assert.equal(excess, undefined);
  assert.match(result.ticket, /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/);
  assert.equal(createHmac('sha256', secret).update(`${head}.${body}`).digest('base64url'), signature);
  assert.deepEqual(JSON.parse(Buffer.from(head, 'base64url')), { alg: 'HS256', typ: 'JWT' });
  const payload = JSON.parse(Buffer.from(body, 'base64url'));
  assert.deepEqual(Object.keys(payload).sort(), ['aud', 'exp', 'iat', 'iss', 'jti', 'licencia_id', 'pc', 'sub']);
  assert.equal(payload.iss, 'MYG_LICENCIAS');
  assert.equal(payload.sub, 'ana');
  assert.equal(payload.aud, audience);
  assert.equal(payload.pc, sha('PC-A'));
  assert.equal(payload.licencia_id, env.rows[1][10]);
  assert.match(payload.licencia_id, /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);
  assert.match(payload.jti, /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);
  assert.equal(payload.exp - payload.iat, 60);
  assert.equal(result.expira_en, payload.exp);
  assert.ok(Math.abs(payload.iat - Math.floor(Date.now() / 1000)) <= 2);
  assert.notEqual(JSON.parse(Buffer.from(ticket(env).ticket.split('.')[1], 'base64url')).jti, payload.jti);
});

test('el flujo manual respeta H=NO sin rotar ni borrar el token existente', () => {
  const rows = fixtures(); rows[1][7] = 'NO';
  const env = environment({ rows });
  assert.equal(env.post(request({ clave: 'clave-ana', token: '' })).content, 'OK');
  assert.equal(ticket(env, { clave: 'clave-ana', token: '' }).ok, true);
  assert.equal(env.rows[1][8], sha('token-ana'));
  assert.deepEqual(env.writes, [[1, 11], [2, 11]]);
});

for (const [label, change, extra, code] of [
  ['bloqueado', rows => { rows[1][4] = 'NO'; }, {}, 'BLOQUEADO'],
  ['expirado', rows => { rows[1][3] = expired; }, {}, 'EXPIRADO'],
  ['fecha inválida', rows => { rows[1][3] = 'no-fecha'; }, {}, 'FECHA_INVALIDA'],
  ['PC distinto', () => {}, { pc: 'PC-B' }, 'OTRA_PC'],
  ['sin PC vinculado', rows => { rows[1][2] = ''; }, {}, 'OTRA_PC'],
  ['token inválido', () => {}, { token: 'incorrecto' }, 'TOKEN_INVALIDO'],
  ['automático desactivado', rows => { rows[1][7] = 'NO'; }, {}, 'AUTO_DESACTIVADO'],
  ['clave incorrecta', () => {}, { token: '', clave: 'incorrecta' }, 'CLAVE_ERROR'],
  ['sin credencial', () => {}, { token: '' }, 'DATOS_INCOMPLETOS'],
  ['credencial ambigua', () => {}, { clave: 'clave-ana' }, 'DATOS_INCOMPLETOS'],
  ['usuario inexistente', () => {}, { usuario: 'nadie' }, 'NO_EXISTE'],
  ['usuario con control', () => {}, { usuario: 'an\na' }, 'DATOS_INCOMPLETOS'],
  ['usuario largo', () => {}, { usuario: 'a'.repeat(257) }, 'DATOS_INCOMPLETOS'],
  ['surrogate inválido', () => {}, { usuario: 'ana\ud800' }, 'DATOS_INCOMPLETOS']
]) {
  test(`revalidación y ticket rechazan ${label}, sin mutaciones`, () => {
    const rows = fixtures(); change(rows);
    const env = environment({ rows }), before = structuredClone(env.rows);
    assert.equal(env.post(request(extra)).content, code);
    assert.deepEqual(ticket(env, extra), { ok: false, codigo: code });
    assert.deepEqual(env.rows, before);
    assert.deepEqual(env.writes, []);
    assert.deepEqual(env.columnChanges, []);
  });
}

test('normaliza usuarios con acentos, espacios internos y Unicode válido', () => {
  const rows = fixtures(); rows[1][0] = 'área técnica 🏗';
  const env = environment({ rows });
  const result = ticket(env, { usuario: ' ÁREA TÉCNICA 🏗  ' });
  assert.equal(result.ok, true);
  assert.equal(result.usuario, 'área técnica 🏗');
  assert.equal(JSON.parse(Buffer.from(result.ticket.split('.')[1], 'base64url')).sub, result.usuario);
});

test('errores de hoja y duplicados no revelan la excepción', () => {
  const absent = environment({ missingSheet: true });
  assert.equal(absent.post(request()).content, 'SIN_HOJA');
  assert.deepEqual(ticket(absent), { ok: false, codigo: 'SIN_HOJA' });
  const rows = fixtures(); rows.push(structuredClone(rows[1]));
  const duplicate = environment({ rows });
  assert.equal(duplicate.post(request()).content, 'ERROR');
  assert.deepEqual(ticket(duplicate), { ok: false, codigo: 'ERROR' });
  assert.deepEqual(duplicate.logs, []);
});

test('rechaza audiencia distinta y configuración ausente o mal formada', () => {
  const env = environment();
  for (const value of ['https://other.supabase.co', 'https://testproject.supabase.co.evil.test',
    'http://testproject.supabase.co', 'https://testproject.supabase.co/path',
    'https://user@testproject.supabase.co', 'https://testproject.supabase.co:443', '']) {
    assert.deepEqual(ticket(env, { audiencia: value }), { ok: false, codigo: 'AUDIENCIA_INVALIDA' });
  }
  assert.deepEqual(env.writes, []);
  assert.deepEqual(env.columnChanges, []);
  for (const properties of [{ MYG_NUBE_URL: '' }, { MYG_NUBE_HMAC: '' },
    { MYG_NUBE_URL: 'https://evil.test' }, { MYG_NUBE_HMAC: 'no-válido' }]) {
    const misconfigured = environment({ properties });
    assert.deepEqual(ticket(misconfigured), { ok: false, codigo: 'NUBE_NO_CONFIGURADA' });
    assert.equal(misconfigured.post(request()).content, 'OK');
    assert.deepEqual(misconfigured.writes, []);
  }
});

test('preparación/estado sólo para administrador, añade sólo cabecera sin cambiar pagos/licencias', () => {
  const env = environment({ properties: { MYG_NUBE_HMAC: '', MYG_PAGOS_HABILITADOS: 'SI' } });
  const before = structuredClone(env.rows);
  env.ctx.PREPARAR_NUBE_MYG();
  const generated = env.properties.MYG_NUBE_HMAC;
  assert.match(generated, /^[a-f0-9]{64}$/);
  env.ctx.PREPARAR_NUBE_MYG();
  env.ctx.VERIFICAR_NUBE_MYG();
  assert.equal(env.properties.MYG_NUBE_HMAC, generated);
  assert.ok(!env.logs.join('\n').includes(generated));
  assert.equal(env.properties.MYG_PAGOS_HABILITADOS, 'SI');
  assert.deepEqual(env.rows.map(row => row.slice(0, 10)), before);
  assert.deepEqual(env.writes, [[1, 11]]);
  assert.deepEqual(env.counters(), { networkCalls: 0, sheetsCreated: 0, scriptTriggers: 0 });
  const denied = environment({ nonAdmin: true, properties: { MYG_NUBE_HMAC: '' } });
  for (const name of ['PREPARAR_NUBE_MYG', 'VERIFICAR_NUBE_MYG']) {
    assert.throws(() => denied.ctx[name](), /cuenta propietaria/);
  }
  assert.equal(denied.properties.MYG_NUBE_HMAC, '');
});

test('configuración inválida no se sobrescribe ni genera claves antes de corregir la URL', () => {
  const wrongUrl = environment({ properties: { MYG_NUBE_URL: '', MYG_NUBE_HMAC: '' } });
  assert.throws(() => wrongUrl.ctx.PREPARAR_NUBE_MYG(), /MYG_NUBE_URL/);
  assert.equal(wrongUrl.properties.MYG_NUBE_HMAC, '');
  const wrongKey = environment({ properties: { MYG_NUBE_HMAC: 'incorrecto' } });
  assert.throws(() => wrongKey.ctx.PREPARAR_NUBE_MYG(), /MYG_NUBE_HMAC/);
  assert.equal(wrongKey.properties.MYG_NUBE_HMAC, 'incorrecto');
  assert.throws(() => wrongKey.ctx.VERIFICAR_NUBE_MYG(), /sin configurar/);
});

test('GET manual original mantiene vinculación y rotación; POST legacy conserva el token', () => {
  const rows = fixturesWithIds(); rows[1][2] = '';
  const env = environment({ rows });
  const answer = env.get({ usuario: 'ANA', clave: 'clave-ana', pc: 'PC-A' }).content;
  assert.match(answer, /^OK\|[a-f0-9]{64}$/);
  const token = answer.split('|')[1];
  assert.equal(env.rows[1][2], 'PC-A');
  assert.equal(env.rows[1][8], sha(token));
  assert.equal(env.rows[2][8], sha('token-beto'));
  assert.equal(env.rows[1][10], rows[1][10]);
  assert.equal(env.rows[2][10], rows[2][10]);
  assert.equal(env.post({ usuario: 'ana', pc: 'PC-A', token }).content, 'OK');
  assert.equal(env.rows[1][8], sha(token));
  assert.equal(env.post({ usuario: 'ana', pc: 'PC-A', token: 'token-ana' }).content, 'TOKEN_INVALIDO');
  assert.equal(env.post({ usuario: 'beto', pc: 'PC-B', token: 'token-beto' }).content, 'OK');
});

test('GET original H=NO conserva su respuesta OK y borrado legacy, sin afectar otro usuario', () => {
  const rows = fixtures(); rows[1][7] = 'NO';
  const env = environment({ rows });
  assert.equal(env.get({ usuario: 'ana', clave: 'clave-ana', pc: 'PC-A' }).content, 'OK');
  assert.equal(env.rows[1][8], '');
  assert.equal(env.rows[2][8], sha('token-beto'));
  assert.equal(env.post({ usuario: 'ana', pc: 'PC-A', token: 'token-ana' }).content, 'AUTO_DESACTIVADO');
});

test('la página de compras original mantiene precios y no habilita ventas al pedir tickets', () => {
  const env = environment();
  assert.equal(env.get({}).content.includes('23'), true);
  assert.equal(env.get({}).content.includes('210'), true);
  ticket(env);
  assert.equal(env.properties.MYG_PAGOS_HABILITADOS, 'NO');
  assert.equal(env.ctx.ventas_(), false);
});

test('suma de meses y validación de pagos originales conservan importes y renovación calendario', () => {
  const { ctx } = environment();
  const month = ctx.sumarMeses_(new Date(2028, 0, 31), 1);
  assert.equal(month.getFullYear(), 2028);
  assert.equal(month.getMonth(), 1);
  assert.equal(month.getDate(), 29);
  const order = ['referencia', today, 'ana', 'mensual', 23, 1];
  const payment = { id: '123', status: 'approved', live_mode: true,
    collector_id: '555', external_reference: 'referencia', currency_id: 'PEN',
    transaction_amount: 23, transaction_amount_refunded: 0, refunds: [], payer: { id: '777' } };
  assert.equal(ctx.motivoPagoInvalido_(payment, order, '555'), '');
  assert.equal(ctx.motivoPagoInvalido_({ ...payment, transaction_amount: 20 }, order, '555'), 'Importe distinto');
  assert.equal(ctx.motivoPagoInvalido_({ ...payment, collector_id: '999' }, order, '555'), 'Vendedor distinto');
  assert.equal(ctx.motivoPagoInvalido_({ ...payment, live_mode: false }, order, '555'), 'Pago no real');
});

test('renovación original aplica una sola vez y conserva C, H e I de ambos usuarios', () => {
  const rows = fixturesWithIds(); rows[1][7] = 'NO';
  const env = environment({ rows });
  const before = structuredClone(env.rows);
  const orders = [json(env.ctx.CAB_PEDIDOS_MYG_),
    ['ref-renovacion', today, 'ana', 'mensual', 23, 1, 'PENDIENTE', '', 'checkout', '', '']];
  const pending = {
    getDataRange: () => ({ getValues: () => structuredClone(orders) }),
    getRange: (row, col) => ({ setValues(values) {
      values.forEach((line, i) => line.forEach((value, j) => { orders[row - 1 + i][col - 1 + j] = value; }));
    } })
  };
  env.ctx.libro_ = () => ({ getSheetByName: name => name === 'LICENCIAS' ? env.sheet : pending });
  const payment = { id: '123', status: 'approved', live_mode: true, collector_id: '555',
    external_reference: 'ref-renovacion', currency_id: 'PEN', transaction_amount: 23,
    transaction_amount_refunded: 0, refunds: [], payer: { id: '777' } };
  env.ctx.aplicarPago_('ref-renovacion', payment, '555');
  const expiry = env.rows[1][3].getTime();
  assert.ok(expiry > before[1][3].getTime());
  assert.equal(env.rows[1][9], '["123"]');
  assert.equal(orders[1][6], 'APLICADO');
  for (const column of [2, 7, 8]) assert.equal(env.rows[1][column], before[1][column]);
  assert.equal(env.rows[1][10], before[1][10], 'renovación original conserva UUID estable');
  assert.deepEqual(env.rows[2], before[2]);
  // Reintento normal, y recuperación si la escritura del pedido se interrumpió.
  env.ctx.aplicarPago_('ref-renovacion', payment, '555');
  orders[1][6] = 'PENDIENTE';
  env.ctx.aplicarPago_('ref-renovacion', payment, '555');
  assert.equal(env.rows[1][3].getTime(), expiry);
  assert.equal(env.rows[1][9], '["123"]');
  assert.equal(orders[1][6], 'APLICADO');
  assert.deepEqual(env.counters(), { networkCalls: 0, sheetsCreated: 0, scriptTriggers: 0 });
});
