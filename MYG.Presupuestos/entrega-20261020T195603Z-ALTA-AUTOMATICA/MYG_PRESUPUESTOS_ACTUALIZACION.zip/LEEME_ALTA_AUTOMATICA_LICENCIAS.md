# Alta automática de Nube MYG desde la hoja de licencias

## A. Resultado

Los usuarios nuevos ya no requieren una invitación por correo ni un INSERT SQL por persona. Después de iniciar sesión MYG, Apps Script comprueba usuario, credencial, licencia vigente y equipo; firma un identificador estable de licencia y el servidor crea la identidad de nube automáticamente. La hoja no necesita una columna de correo.

El acceso a cada presupuesto mantiene sus permisos: el propietario comparte el código y aprueba al colaborador como lector o editor. Tener licencia no concede acceso a los presupuestos de otros usuarios.

## B. Archivos

El ZIP contiene únicamente archivos nuevos o modificados respecto a la entrega de ingreso único anterior. `MANIFIESTO_ALTA_AUTOMATICA_MYG.json` enumera rutas, acciones y SHA256. No se elimina ningún archivo. Los archivos marcados REEMPLAZAR se entregan completos; revisa cambios locales posteriores antes de copiarlos.

## C. Entrega

Se publica un ZIP separado en DESCARGAS. La respuesta de entrega proporciona el enlace directo comprobado. No contiene datos reales de licencias, presupuestos, cuentas, secretos ni compilaciones. Los datos de pruebas son sintéticos.

## D. Aplicación manual

1. Respalda el proyecto, el Apps Script vigente y la hoja LICENCIAS completa. Conserva también tus bases SQLite y las vinculaciones de Supabase.
2. Copia el ZIP en la raíz del proyecto, manteniendo carpetas. Esta actualización requiere la entrega anterior de ingreso único MYG y las migraciones 001/002/003 ya instaladas.
3. Revisa los vínculos antiguos antes de activar autoalta. Si un registro conserva un nombre de ejemplo como `USUARIO_EXACTO_DE_MYG`, corrige únicamente ese registro con su usuario MYG real, conservando su UUID. La migración 004 se detiene ante esos nombres para impedir duplicar una cuenta propietaria. Esa reparación de datos antiguos es una sola vez; no se repite por cada usuario nuevo.
4. Ejecuta una sola vez `supabase/migrations/202610200004_alta_automatica_licencias.sql`, completa, en SQL Editor del mismo proyecto. No repitas 001/002/003 ni borres tablas si la migración se detiene.
5. En Edge Functions abre la función existente cuya URL termina exactamente en `/functions/v1/myg-login`. Reemplaza su archivo **handler.ts** por `supabase/functions/myg-login/handler.ts` y despliega la nueva versión. Conserva el `index.ts` existente, la opción Verify JWT desactivada exclusivamente para esta función y el secreto MYG_NUBE_HMAC actual.
6. En el Apps Script de esa misma hoja reemplaza el código completo con `integraciones/apps-script/Codigo.gs`, guarda y actualiza la versión de la implementación existente. Conserva su URL `/exec`, MYG_NUBE_URL, MYG_NUBE_HMAC y las propiedades de pagos.
7. Ejecuta PREPARAR_NUBE_MYG como propietario. Conserva el secreto si ya existe y prepara la columna ID_MYG_NUBE al final de las columnas ocupadas. Los identificadores de las filas se asignan cuando cada usuario válido abre Nube MYG.
8. En Visual Studio restaura dependencias y compila la solución Release con .NET 10. Los cambios C# validan el identificador firmado y muestran los errores administrativos nuevos; no introducen otro formulario ni otra contraseña.
9. Distribuye la salida completa del escritorio, con sus dependencias, y prueba dos equipos/usuarios distintos. El alta no se ejecuta por copiar archivos al proyecto: requiere los pasos de servidor anteriores.

El orden servidor es **004 → handler actualizado → Apps Script actualizado**. El handler anterior no reconoce el nuevo claim de licencia. Si la migración 004 no terminó, el handler nuevo falla antes de crear cuentas.

## E. Funcionamiento y configuración

### Columna ID_MYG_NUBE

Se añade después de la última columna con datos, siempre fuera de A:J. No modifica usuario, contraseña, equipo, vencimiento, estado, nombre, token ni registro de pagos. Cada fila obtiene un UUID aleatorio una sola vez tras validar licencia, PC y configuración. Ordenar/mover la fila completa o cambiar el nombre conservando ese UUID mantiene su identidad. Una fila nueva sin UUID recibe uno nuevo.

No copies un UUID al dar de alta otra persona. No borres la columna ni la regeneres cuando cambies de equipo o renueves una licencia. Respalda la hoja con sus IDs: duplicados, IDs mal formados o cabeceras repetidas bloquean la emisión de tickets para que el administrador revise los datos.

La renovación de una persona conserva su fila y su ID. Eliminar una fila y volver a crearla sin su ID identifica una licencia nueva; la aplicación no le transfiere los presupuestos de la licencia anterior. No reutilices una fila/ID para entregar la identidad de otra persona.

### Cuentas de Supabase

Un vínculo existente válido conserva su UUID Auth y sus permisos. Se asocia a su ID de licencia una sola vez; cambiar el nombre de la licencia después no crea una cuenta nueva. Una licencia distinta no puede reclamar ese mismo vínculo.

Para usuarios nuevos se crea una cuenta técnica con un alias interno de forma `licencia<UUID>@myg.invalid`. Ese alias no es un correo de la persona, no recibe invitaciones y no requiere que el usuario gestione otra contraseña. El acceso sigue siendo por MYG. La API administrativa fija una contraseña interna aleatoria; el cliente nunca la recibe.

La creación usa un UUID reservado de forma durable. Si hay un corte de red o dos ingresos simultáneos, el siguiente ticket continúa con esa misma reserva. No se reclama una cuenta ajena por coincidencia de alias ni por user_metadata; el servidor comprueba los marcadores administrativos de la licencia.

No se reactivan vínculos con activo=false ni cuentas retiradas, bloqueadas o eliminadas. Una reserva ya confirmada cuyo vínculo desaparece requiere revisión, en lugar de crear otro. Para bloquear un alta todavía pendiente se utiliza la reserva administrativa bloqueada=true; para retirar acceso de una cuenta confirmada se conserva el control activo de su vínculo.

No hay secretos nuevos. MYG_NUBE_HMAC debe seguir idéntico en Apps Script y Edge Functions. service_role permanece únicamente en Supabase. El escritorio envía el ticket firmado, nunca una solicitud administrativa de alta.

## F. Comprobaciones

Se ejecutan las suites C# de licencias y nube, el Apps Script en VM Node, el handler con HTTP simulado y SQL real en PGlite. La prueba integrada usa **el Apps Script real para firmar → el handler real para verificar → PostgreSQL real para reservar y vincular**, con Auth HTTP simulado. Comprueba propietario y presupuesto anteriores, alta única del editor sin membresías, reingreso, replay, aprobación explícita y rechazo de revocación.

Resultados: solución Release **0 errores y 0 advertencias**; suite general **573 comprobaciones**; nube **25 grupos**, con **9 casos/169 comprobaciones de ingreso** además de 787 comprobaciones HTTP previas; Apps Script **40/40**; Edge **46/46** y TypeScript estricto correcto. PostgreSQL confirma protección ante nombres de ejemplo sin cambiar datos y reversión correcta de los fixtures. La integración completa confirma una sola alta técnica y tres sesiones, conservando propietario y roles.

Comandos desde la raíz:

```sh
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release
node --test integraciones/apps-script/tests/nube-sso.test.mjs
node --test supabase/functions/myg-login/handler.test.mjs
```

El parámetro de referencias Revit corresponde al entorno de compilación en nube; en Windows conserva tus referencias habituales. Los ejecutores PostgreSQL se copian a una carpeta temporal junto a @electric-sql/pglite@0.3.14; consulta la documentación del backend. Node 24 permite importar el handler TypeScript sin dependencias remotas.

Para la integración completa, copia `supabase/tests/ejecutar-flujo-licencias.mjs` junto a esa instalación de PGlite y ejecútalo con la ruta absoluta del repositorio como argumento. No ejecutes fixtures de pruebas contra producción.

Prueba real pendiente después de desplegar: iniciar MYG con un usuario nuevo y licencia vigente, abrir Nube sin invitación Supabase, comprobar que existe una sola cuenta, solicitar acceso al presupuesto, aprobar como editor y sincronizar. Repite con vínculo desactivado, licencia bloqueada y dos equipos. La cuenta propietaria anterior debe conservar su presupuesto y su UUID.

## G. Código fuente y GitHub

La entrega publica únicamente el ZIP en DESCARGAS. El repositorio fuente permanece sin commit/push. En Visual Studio, revisa Cambios de Git y la rama; después de validar en tus equipos, tú decides Commit y Push. Excluye bases, secretos y salidas bin/obj.

## H. Límites

Esta sesión no modifica tu hoja real, Supabase ni Apps Script publicados. El propietario debe aplicar los pasos de D. La verificación local no ejecuta Windows/Revit ni los servicios alojados reales.

La licencia se comprueba al emitir el ticket y mediante la revalidación periódica MYG. Una sesión Supabase ya emitida mantiene su duración normal; bloquear una licencia en la hoja no sustituye revocar el vínculo si se necesita denegar inmediatamente las RPC y archivos del servidor. Las reglas de una computadora por licencia y los permisos de presupuesto permanecen.

Se conservan las limitaciones documentadas del canje Auth recovery (códigos de un solo uso pendientes de esa cuenta) y de algunas normalizaciones Unicode especiales. La corrección de nombres de ejemplo antiguos requiere identificar al usuario real; el servidor no adivina ni reasigna al propietario de un presupuesto.

Tras verificar el despliegue nuevo, retira los despliegues antiguos de Edge que aún usen el puente anterior, por ejemplo una función de pruebas llamada smooth-action. Los tickets sin ID de licencia sólo se admiten para vínculos antiguos que todavía no se hayan asociado a un ID; después de asociarlos, se exige ese ID. No mantengas varias implementaciones de licencias con la misma clave y códigos distintos.
