using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MYG.Externo;

public sealed class CredencialMYG
{
    public string Usuario { get; set; }
    public string Clave { get; set; }
    public string Token { get; set; }
    public bool Automatico { get; set; }
    public bool RecordarIngreso { get; set; }
    public string Identidad() => Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(new[]
        { (Usuario ?? "").Trim(), Automatico ? "AUTOMATICO" : "MANUAL", Automatico ? Token : Clave?.Trim() })));
}
public sealed record ResultadoAcceso(bool Ok, string Mensaje, string Token = null);

public sealed class LicenciaServicio
{
    private const int MaxRespuesta = 1024 * 1024;
    private const int MaxTicket = 8 * 1024;
    private readonly HttpClient cliente;
    private readonly string pc;
    private readonly string url;
    public LicenciaServicio(HttpClient cliente, string pc, string url = ServidorLicencias.Url)
    { this.cliente = cliente; this.pc = pc; this.url = url; }

    public async Task<ResultadoAcceso> ValidarAsync(CredencialMYG c, CancellationToken cancelacion = default)
    {
        if (c == null || string.IsNullOrWhiteSpace(c.Usuario)) return new(false, "Ingrese el usuario.");
        if (c.Automatico && (c.Token == null || c.Token.Length < 32)) return new(false, "Inicie sesión con usuario y contraseña.");
        if (!c.Automatico && string.IsNullOrWhiteSpace(c.Clave)) return new(false, "Ingrese la contraseña.");
        try
        {
            using var tiempo = CancellationTokenSource.CreateLinkedTokenSource(cancelacion);
            tiempo.CancelAfter(TimeSpan.FromSeconds(15));
            using var solicitud = c.Automatico ? new HttpRequestMessage(HttpMethod.Post, url) :
                new HttpRequestMessage(HttpMethod.Get, url + "?usuario=" + Uri.EscapeDataString(c.Usuario.Trim()) +
                    "&clave=" + Uri.EscapeDataString(c.Clave.Trim()) + "&pc=" + Uri.EscapeDataString(pc));
            if (c.Automatico) solicitud.Content = new FormUrlEncodedContent(new Dictionary<string, string>
                { ["usuario"] = c.Usuario.Trim(), ["token"] = c.Token, ["pc"] = pc });
            solicitud.Headers.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue { NoCache = true };
            using var respuesta = await cliente.SendAsync(solicitud, tiempo.Token).ConfigureAwait(false);
            if (!respuesta.IsSuccessStatusCode) return new(false, "No se pudo consultar la licencia MYG.");
            string texto = (await respuesta.Content.ReadAsStringAsync(tiempo.Token).ConfigureAwait(false)).Trim();
            return Interpretar(texto, c.Automatico);
        }
        catch (OperationCanceledException) { return new(false, "La validación de licencia no respondió. Compruebe su conexión."); }
        catch (HttpRequestException) { return new(false, "No se pudo conectar con el servicio de licencias MYG."); }
    }

    /// <summary>Comprueba la sesión existente sin ejecutar el ingreso que renueva el token.</summary>
    public async Task<ResultadoAcceso> RevalidarAsync(CredencialMYG c, CancellationToken cancelacion = default)
    {
        cancelacion.ThrowIfCancellationRequested();
        if (!CrearFormulario(c, "validar_sesion", out var formulario, out _, out string error)) return new(false, error);
        try
        {
            string texto = await EnviarFormularioAsync(formulario, cancelacion).ConfigureAwait(false);
            if (texto == "OK") return new(true, "Licencia validada.");
            if (EsErrorLicencia(texto)) return Interpretar(texto, true);
            return new(false, "Actualice el servicio Apps Script de MYG para validar la sesión sin reiniciar el ingreso.");
        }
        catch (OperationCanceledException) when (!cancelacion.IsCancellationRequested)
        { return new(false, "La validación de licencia no respondió. Compruebe su conexión."); }
        catch (HttpRequestException) { return new(false, "No se pudo conectar con el servicio de licencias MYG."); }
        catch (InvalidDataException) { return new(false, "El servicio de licencias MYG devolvió una respuesta inválida."); }
        catch (IOException) { return new(false, "No se pudo recibir la respuesta del servicio de licencias MYG."); }
    }

    /// <summary>Solicita un ticket de un solo uso para la cuenta MYG ya autenticada.</summary>
    public async Task<ResultadoTicketNube> ObtenerTicketNubeAsync(CredencialMYG c, string audiencia, CancellationToken cancelacion = default)
    {
        cancelacion.ThrowIfCancellationRequested();
        if (!AudienciaValida(audiencia, out string destino)) return new(false, "Configure una dirección HTTPS válida del proyecto Supabase.");
        if (!CrearFormulario(c, "nube_ticket", out var formulario, out string usuario, out string error)) return new(false, error);
        formulario["audiencia"] = destino;
        try
        {
            string texto = await EnviarFormularioAsync(formulario, cancelacion).ConfigureAwait(false);
            if (EsErrorLicencia(texto)) return new(false, Interpretar(texto, true).Mensaje, LicenciaDenegada: true);
            // Los despliegues anteriores responden texto y no conocen la operación nube_ticket.
            if (!texto.StartsWith('{')) return new(false, "Actualice el servicio Apps Script de MYG para habilitar el ingreso único a Nube MYG.");
            using var json = JsonDocument.Parse(texto, new JsonDocumentOptions { MaxDepth = 16 });
            var raiz = json.RootElement;
            if (raiz.ValueKind != JsonValueKind.Object || !SinDuplicados(raiz) || !raiz.TryGetProperty("ok", out var ok))
                return TicketInvalido();
            if (ok.ValueKind == JsonValueKind.False)
            {
                string codigo = Cadena(raiz, "codigo");
                if (EsErrorLicencia(codigo)) return new(false, Interpretar(codigo, true).Mensaje, LicenciaDenegada: true);
                return new(false, codigo switch {
                    "NUBE_NO_CONFIGURADA" => "El administrador debe configurar el ingreso único a Nube MYG en Apps Script.",
                    "AUDIENCIA_INVALIDA" or "AUDIENCIA_NO_AUTORIZADA" => "El proyecto Supabase no coincide con la configuración de Nube MYG.",
                    "LICENCIA_ID_INVALIDO" => "La identificación de la licencia en la hoja MYG no es válida. El administrador debe corregirla.",
                    "LICENCIA_ID_DUPLICADO" => "Hay licencias con la misma identificación en la hoja MYG. El administrador debe corregir la duplicación.",
                    "LICENCIA_ID_CABECERA_DUPLICADA" => "La hoja MYG tiene una cabecera de identificación duplicada. El administrador debe corregirla.",
                    _ => "No se pudo autorizar Nube MYG. Compruebe la configuración del servicio y vuelva a intentarlo." });
            }
            if (ok.ValueKind != JsonValueKind.True) return TicketInvalido();
            string ticket = Cadena(raiz, "ticket");
            if (Cadena(raiz, "usuario") != usuario || Cadena(raiz, "audiencia") != destino ||
                !Entero(raiz, "expira_en", out long segundos) ||
                !ValidarTicket(ticket, usuario, destino, segundos, out DateTimeOffset fecha)) return TicketInvalido();
            return new(true, "Ingreso a Nube MYG autorizado.", new TicketNubeMYG(ticket, usuario, destino, fecha));
        }
        catch (OperationCanceledException) when (!cancelacion.IsCancellationRequested)
        { return new(false, "El servicio de ingreso a Nube MYG no respondió. Compruebe su conexión."); }
        catch (HttpRequestException) { return new(false, "No se pudo conectar con el servicio de ingreso a Nube MYG."); }
        catch (InvalidDataException) { return TicketInvalido(); }
        catch (IOException) { return new(false, "No se pudo recibir la respuesta del servicio de ingreso a Nube MYG."); }
        catch (JsonException) { return TicketInvalido(); }
    }

    private bool CrearFormulario(CredencialMYG c, string accion, out Dictionary<string, string> formulario, out string usuario, out string error)
    {
        formulario = null; usuario = null; error = null;
        string nombre = c?.Usuario?.Trim();
        bool automatico = c?.Automatico ?? false;
        string secreto = automatico ? c?.Token : c?.Clave?.Trim();
        if (string.IsNullOrWhiteSpace(nombre)) error = "Ingrese el usuario.";
        else if (automatico && (secreto == null || secreto.Length < 32)) error = "Inicie sesión con usuario y contraseña.";
        else if (!automatico && string.IsNullOrWhiteSpace(secreto)) error = "Ingrese la contraseña.";
        else if (nombre.Length > 256 || nombre.Any(char.IsControl) || secreto.Length > 4096 || string.IsNullOrWhiteSpace(pc) || pc.Length > 1024)
            error = "Los datos de la sesión MYG no son válidos. Inicie sesión nuevamente.";
        if (error != null) return false;
        usuario = nombre.ToLowerInvariant();
        formulario = new() { ["accion"] = accion, ["usuario"] = nombre, ["pc"] = pc, [automatico ? "token" : "clave"] = secreto };
        return true;
    }

    private async Task<string> EnviarFormularioAsync(Dictionary<string, string> formulario, CancellationToken cancelacion)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var direccion) || direccion.Scheme != Uri.UriSchemeHttps || !string.IsNullOrEmpty(direccion.UserInfo))
            throw new InvalidDataException("Dirección del servicio inválida.");
        using var tiempo = CancellationTokenSource.CreateLinkedTokenSource(cancelacion);
        tiempo.CancelAfter(TimeSpan.FromSeconds(15));
        using var solicitud = new HttpRequestMessage(HttpMethod.Post, direccion) { Content = new FormUrlEncodedContent(formulario) };
        solicitud.Headers.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue { NoCache = true };
        using var respuesta = await cliente.SendAsync(solicitud, HttpCompletionOption.ResponseHeadersRead, tiempo.Token).ConfigureAwait(false);
        respuesta.EnsureSuccessStatusCode();
        if (respuesta.Content.Headers.ContentLength > MaxRespuesta) throw new InvalidDataException("Respuesta excesiva.");
        using var flujo = await respuesta.Content.ReadAsStreamAsync(tiempo.Token).ConfigureAwait(false);
        using var memoria = new MemoryStream();
        byte[] buffer = new byte[8192];
        int leidos;
        while ((leidos = await flujo.ReadAsync(buffer, tiempo.Token).ConfigureAwait(false)) != 0)
        {
            if (memoria.Length + leidos > MaxRespuesta) throw new InvalidDataException("Respuesta excesiva.");
            memoria.Write(buffer, 0, leidos);
        }
        try { return new UTF8Encoding(false, true).GetString(memoria.GetBuffer(), 0, (int)memoria.Length).Trim(); }
        catch (DecoderFallbackException) { throw new InvalidDataException("Respuesta inválida."); }
    }

    private static bool AudienciaValida(string valor, out string canonica)
    {
        canonica = null;
        if (!Uri.TryCreate(valor?.Trim(), UriKind.Absolute, out var uri) || uri.Scheme != Uri.UriSchemeHttps || !uri.IsDefaultPort ||
            !string.IsNullOrEmpty(uri.UserInfo) || !string.IsNullOrEmpty(uri.Query) || !string.IsNullOrEmpty(uri.Fragment) ||
            uri.AbsolutePath != "/" || !uri.Host.EndsWith(".supabase.co", StringComparison.OrdinalIgnoreCase)) return false;
        string proyecto = uri.Host[..^".supabase.co".Length];
        if (proyecto.Length == 0 || proyecto.Length > 63 || proyecto.Any(c => !(char.IsAsciiLetterOrDigit(c) || c == '-')) || proyecto[0] == '-' || proyecto[^1] == '-') return false;
        canonica = "https://" + uri.Host.ToLowerInvariant();
        return true;
    }

    private bool ValidarTicket(string ticket, string usuario, string audiencia, long expira, out DateTimeOffset fecha)
    {
        fecha = default;
        if (string.IsNullOrEmpty(ticket) || ticket.Length > MaxTicket) return false;
        string[] partes = ticket.Split('.');
        if (partes.Length != 3 || partes[0].Length > 2048 || partes[1].Length > 6144 || partes[2].Length != 43) return false;
        try
        {
            byte[] firma = Base64Url(partes[2]);
            if (firma.Length != 32) return false;
            using var cabecera = JsonDocument.Parse(Base64Url(partes[0]), new JsonDocumentOptions { MaxDepth = 8 });
            using var contenido = JsonDocument.Parse(Base64Url(partes[1]), new JsonDocumentOptions { MaxDepth = 8 });
            var h = cabecera.RootElement; var p = contenido.RootElement;
            if (!SinDuplicados(h) || !SinDuplicados(p) || Cadena(h, "alg") != "HS256" || Cadena(h, "typ") != "JWT" ||
                Cadena(p, "iss") != "MYG_LICENCIAS" || Cadena(p, "sub") != usuario || Cadena(p, "aud") != audiencia ||
                Cadena(p, "pc") != Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(pc))) ||
                !Guid.TryParseExact(Cadena(p, "jti"), "D", out var nonce) || nonce == Guid.Empty || Cadena(p, "jti") != nonce.ToString("D") ||
                !Entero(p, "exp", out long expClaim) || expClaim != expira || !Entero(p, "iat", out long emitido)) return false;
            if (p.TryGetProperty("licencia_id", out var licenciaId) &&
                (licenciaId.ValueKind != JsonValueKind.String || !Guid.TryParseExact(licenciaId.GetString(), "D", out var identificador) ||
                 identificador == Guid.Empty || licenciaId.GetString() != identificador.ToString("D"))) return false;
            long ahora = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            if (emitido < ahora - 90 || emitido > ahora + 30 || expira <= ahora || expira > ahora + 120 || expira <= emitido || expira - emitido > 90) return false;
            fecha = DateTimeOffset.FromUnixTimeSeconds(expira);
            // La firma se verifica exclusivamente en el servidor de Nube MYG; el cliente no posee su secreto.
            return true;
        }
        catch (FormatException) { return false; }
        catch (JsonException) { return false; }
        catch (ArgumentOutOfRangeException) { return false; }
    }

    private static byte[] Base64Url(string valor)
    {
        if (valor.Length == 0 || valor.Any(c => !(char.IsAsciiLetterOrDigit(c) || c is '-' or '_')) || valor.Length % 4 == 1)
            throw new FormatException();
        byte[] datos = Convert.FromBase64String(valor.Replace('-', '+').Replace('_', '/') + new string('=', (4 - valor.Length % 4) % 4));
        if (Convert.ToBase64String(datos).TrimEnd('=').Replace('+', '-').Replace('/', '_') != valor) throw new FormatException();
        return datos;
    }

    private static bool SinDuplicados(JsonElement elemento)
    {
        if (elemento.ValueKind != JsonValueKind.Object) return false;
        var nombres = new HashSet<string>(StringComparer.Ordinal);
        foreach (var propiedad in elemento.EnumerateObject()) if (!nombres.Add(propiedad.Name)) return false;
        return true;
    }
    private static string Cadena(JsonElement objeto, string nombre) => objeto.ValueKind == JsonValueKind.Object && objeto.TryGetProperty(nombre, out var valor) && valor.ValueKind == JsonValueKind.String ? valor.GetString() : null;
    private static bool Entero(JsonElement objeto, string nombre, out long numero)
    {
        numero = 0;
        return objeto.ValueKind == JsonValueKind.Object && objeto.TryGetProperty(nombre, out var valor) && valor.ValueKind == JsonValueKind.Number && valor.TryGetInt64(out numero);
    }
    private static ResultadoTicketNube TicketInvalido() => new(false, "El servicio devolvió una autorización de Nube MYG inválida. Vuelva a iniciar la operación.");
    private static bool EsErrorLicencia(string codigo) => codigo is "BLOQUEADO" or "EXPIRADO" or "OTRA_PC" or "CLAVE_ERROR" or "TOKEN_INVALIDO" or "NO_EXISTE" or "AUTO_DESACTIVADO" or "FECHA_INVALIDA" or "INGRESO_AUTOMATICO_NO" or "AUTO_NO" or "NO_AUTOMATICO";
    public static ResultadoAcceso Interpretar(string texto, bool automatico)
    {
        if (texto == "OK") return new(true, "Licencia validada.");
        if (!automatico && texto.StartsWith("OK|", StringComparison.Ordinal))
        {
            string token = texto[3..].Trim();
            return token.Length >= 32 ? new(true, "Licencia validada.", token) : new(false, "El servicio devolvió una sesión inválida.");
        }
        return new(false, texto switch {
            "EXPIRADO" => "Licencia expirada.", "BLOQUEADO" => "Licencia bloqueada.",
            "OTRA_PC" => "La licencia está registrada en otra computadora.", "CLAVE_ERROR" => "Contraseña incorrecta.",
            "NO_EXISTE" => "Usuario no registrado.", "TOKEN_INVALIDO" => "Inicie sesión nuevamente.",
            "INGRESO_AUTOMATICO_NO" or "AUTO_NO" or "NO_AUTOMATICO" or "AUTO_DESACTIVADO" => "Ingrese su usuario y contraseña.",
            "FECHA_INVALIDA" => "La fecha de la licencia MYG no es válida. Consulte al administrador.",
            _ => "No se pudo autorizar el acceso. Inicie sesión o consulte al administrador de MYG." });
    }
}
