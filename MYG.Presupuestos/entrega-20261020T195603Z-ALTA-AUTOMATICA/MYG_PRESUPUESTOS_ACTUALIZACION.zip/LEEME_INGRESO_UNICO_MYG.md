# Ingreso único a Nube MYG — entrega del 20/10/2026

**Actualización posterior:** `LEEME_ALTA_AUTOMATICA_LICENCIAS.md` añade altas de nube desde la hoja LICENCIAS, sin correos ni registro SQL por usuario nuevo. Requiere la migración 004 y el servidor actualizado; conserva este ingreso único y los vínculos válidos existentes.

## A. Resumen

Nube MYG utiliza el usuario que ya inició sesión en MYG. La ventana deja de pedir correo y contraseña de Supabase. El servidor de licencias emite una autorización firmada de 60 segundos y Supabase la canjea por una sesión normal de la cuenta previamente vinculada. Se mantienen proyectos, revisiones, permisos y archivos existentes.

La revalidación cada minuto utiliza una acción que no rota el token automático. Cambiar de usuario MYG elimina la sesión local anterior y cancela sus solicitudes. No se cierra la sesión de otra computadora. Se conserva la corrección previa de confirmación de documentos PostgreSQL JSONB.

## B. Archivos

`MANIFIESTO_INGRESO_UNICO_MYG.json`, incluido en esta entrega, enumera cada ruta relativa, acción y SHA256. Copiar los archivos completos conservando sus carpetas; no hay archivos que eliminar. Esta es una actualización sobre las entregas previas de Nube MYG y confirmación JSONB, no un proyecto nuevo.

## C. Descarga y alcance

El ZIP se entrega en el repositorio público `bimchimbote-droid/DESCARGAS`. La respuesta de entrega contiene su enlace directo comprobado. No contiene DLL, ejecutables, bases de presupuestos, configuraciones personales, credenciales ni secretos reales. Los valores de las pruebas son sintéticos y no sirven para producción.

## D. Instalación en orden

1. Cierra MYG y Visual Studio. Conserva una copia de tu carpeta `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, tus SQLite, el Apps Script activo y la hoja de licencias. Revisa tus cambios locales antes de reemplazar archivos.
2. Extrae este ZIP en una carpeta temporal. Copia las rutas del manifiesto a la raíz del proyecto, manteniendo la estructura. Si ya tienes un `supabase/config.toml` con otras opciones, incorpora solamente el bloque `[functions.myg-login]`; conserva las demás opciones.
3. **Prepara primero los servidores** siguiendo el apartado E. No distribuyas el escritorio nuevo mientras el `/exec` siga con el código anterior: el nuevo escritorio requiere `validar_sesion` y `nube_ticket`.
4. En Visual Studio abre `MYG.Presupuestos.sln`, restaura dependencias y compila Release. En Windows conserva tus referencias habituales de Revit; el parámetro de referencias usado en la nube sólo sirve para la compilación de este entorno.
5. Distribuye la salida completa de escritorio desde `MYG.Desktop\bin\Release\net10.0-windows`, con sus dependencias, a las dos laptops. No copies sólo un ejecutable ni reemplaces tus bases con archivos de prueba.
6. En cada laptop inicia sesión con su propio usuario MYG. Abre **Nube MYG**. En **Configurar conexión**, conserva la misma URL del proyecto Supabase y su clave publicable/anon. La conexión se realiza con la identidad MYG; no se introduce el correo ni una contraseña Supabase.

## E. Configuración del propietario

### Supabase

- Mantén las migraciones 001 y 002 que ya están instaladas. **No vuelvas a ejecutarlas** para esta entrega. Ejecuta una sola vez, como administrador, `supabase/migrations/202610200003_ingreso_myg.sql`. La migración aborta si ya existe o encuentra usuarios MYG duplicados al normalizar; no borres tablas para forzarla.
- Conserva las vinculaciones verificadas de `myg_nube_privado.identidades_verificadas`. Cada usuario MYG debe corresponder a su UUID de Authentication existente y estar activo. Invitar una cuenta a Supabase no concede permisos de proyecto. Este cambio no crea usuarios, vínculos ni roles automáticamente.
- Despliega la función **myg-login**, compuesta por `index.ts` y `handler.ts`. Sigue [la guía de Supabase](supabase/README-INGRESO-MYG.md). `verify_jwt=false` se aplica exclusivamente a esta función porque recibe el ticket MYG antes de tener una sesión Supabase. La función comprueba la firma, emisor, destino, caducidad y uso único del ticket.
- Las variables `SUPABASE_URL`, `SUPABASE_ANON_KEY` y `SUPABASE_SERVICE_ROLE_KEY` pertenecen sólo al entorno de la función. Añade allí el secreto **MYG_NUBE_HMAC** que generarás en Apps Script. No copies service_role ni HMAC al escritorio, al repositorio ni a mensajes.

### Apps Script de licencias

Sigue [la guía del Apps Script](integraciones/apps-script/README-SSO.md). Sustituye su código por `integraciones/apps-script/Codigo.gs` completo, sin duplicar `doGet`/`doPost`. Se han conservado las funciones originales de compras y renovaciones y los importes efectivos S/23 mensual y S/210 anual.

1. Conserva las propiedades existentes y el proyecto de la misma hoja. Añade `MYG_NUBE_URL` con la URL de ese proyecto Supabase.
2. Como propietario ejecuta `PREPARAR_NUBE_MYG`. Genera `MYG_NUBE_HMAC` si no existe; no habilita pagos ni modifica licencias.
3. Copia ese valor directamente desde las propiedades del script a **Edge Functions → Secrets** de Supabase, como `MYG_NUBE_HMAC`. Debe coincidir exactamente; se usa como texto literal. No lo compartas por chat.
4. Ejecuta `VERIFICAR_NUBE_MYG` y actualiza la **versión de la implementación existente** de Apps Script. Conserva su URL `/exec` y permisos. Guardar el editor no publica la nueva versión.
5. Con Supabase y Apps Script desplegados, instala y prueba el escritorio nuevo.

La función usa internamente las operaciones Auth `generate_link` y `verify` de tipo `recovery` para obtener una sesión de una cuenta existente. No envía un correo ni cambia su contraseña; este tipo evita crear cuentas si el usuario desaparece durante el canje. Consume los códigos de un solo uso pendientes de esa cuenta y puede confirmar su correo invitado. Consulta los detalles en la guía del backend.

## F. Compilación y validación

Se prueban el código C# real con .NET 10, SQLite real, respuestas HTTP simuladas, el Apps Script en un entorno VM de Node y las migraciones en PostgreSQL PGlite aislado. El resultado exacto y los conteos de la ejecución final figuran en la respuesta de entrega.

Resultados de esta entrega: solución Release con **0 errores y 0 advertencias**; **572 comprobaciones generales**; suite de nube con **25 grupos**, 787 comprobaciones HTTP previas y **8 casos/113 comprobaciones nuevas de SSO**; Apps Script **28/28**; función Edge **38/38**. La regresión de la migración 003 en PGlite confirma rechazo no destructivo de duplicados y `ROLLBACK` correcto. TypeScript estricto del handler también pasa. Las pruebas previas de archivos, rutas recibidas, catálogos, retirada de permisos y confirmación JSONB permanecen aprobadas dentro de las suites.

Comandos desde la raíz, después de restaurar:

```sh
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release
node --test integraciones/apps-script/tests/nube-sso.test.mjs
node --test supabase/functions/myg-login/handler.test.mjs
```

Los ensayos de SQL y TypeScript se describen en la guía del backend. No ejecutes fixtures de prueba contra producción. Ninguna validación local conecta con tus cuentas reales ni reemplaza una prueba visual de Windows/Revit.

### Prueba con las dos laptops

1. Inicia MYG con propietario en A y editor en B. Abre Nube MYG en ambas, sin ingresar credenciales Supabase. Comprueba que aparece el nombre MYG de cada persona.
2. Comparte el código del presupuesto. B solicita acceso; A carga las solicitudes y lo acepta como **editor**. B actualiza, abre desde **Compartidos conmigo**, modifica, guarda y sincroniza. A recarga y comprueba el cambio.
3. Espera más de un minuto: ambas sesiones deben seguir válidas. Para comprobar renovación de la sesión Supabase, repite después de su tiempo de expiración configurado.
4. Prueba dos cambios concurrentes. Se debe conservar el borrador y mostrar el conflicto si corresponde; no deben aceptarse silenciosamente versiones distintas. Conserva copias antes de resolver.
5. A cambia B a lector o retira su acceso. B recarga/sincroniza: debe quedar en solo lectura y conservar sus cambios locales pendientes. Cambiar de usuario en A debe vaciar sus listas anteriores y bloquear los editores de otra identidad.

## G. GitHub del código fuente

Esta entrega publica únicamente el ZIP en DESCARGAS. No se hizo commit ni push de `MYG.Presupuestos`.

En Visual Studio abre **Cambios de Git**, revisa la rama y compara los archivos antes de prepararlos. Excluye bases, bin/obj, secretos y datos de licencias. Cuando tú decidas, realiza **Commit** y después **Push** a la rama elegida. Comprueba en GitHub esa rama y su commit; el repositorio DESCARGAS es sólo la entrega, no sustituye ese paso.

## H. Límites pendientes reales

- Debes desplegar Apps Script, migración 003, función y secretos en tus cuentas. No se ha publicado ni probado producción desde esta sesión.
- La regla de una computadora por licencia se mantiene. Otros complementos que aún ejecuten el login manual original pueden rotar el token de **esa misma cuenta**; dos usuarios distintos tienen filas y tokens independientes. No se ha demostrado que ese mecanismo explique la desconexión previa entre tus dos usuarios distintos.
- El canje no sustituye los roles del presupuesto ni el vínculo verificado. Una URL/código permite solicitar acceso; el propietario debe aprobarlo.
- JavaScript, C# y PostgreSQL tienen diferencias de minúsculas para algunos nombres Unicode, como `İ` y la sigma griega final. Los usuarios ASCII probados no presentan ese problema; no se afirma compatibilidad universal de esos casos especiales. No renombres ni borres usuarios existentes para forzar el acceso.
- Mantén sincronizado el reloj de Windows. Los tickets duran 60 segundos y no se almacenan en disco. Si caducan o ya se consumieron, **Reintentar conexión** solicita una autorización nueva.

Para volver a la versión anterior, restaura el escritorio anterior y conserva sus bases. Las adiciones del servidor pueden permanecer mientras revisas el problema; no elimines tablas, cuentas ni archivos de presupuesto.
