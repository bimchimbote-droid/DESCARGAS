using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Externo;

internal static class LicenciaNubeCheck
{
    private const string Pc = "PC-PRUEBA-MYG";
    private const string Audiencia = "https://pruebas-myg.supabase.co";
    private const string Url = "https://licencias.example.invalid/exec";
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static HttpResponseMessage Respuesta(string texto, HttpStatusCode codigo = HttpStatusCode.OK) => new(codigo) { Content = new StringContent(texto) };
    private static CredencialMYG Manual(string usuario = "editor") => new() { Usuario = usuario, Clave = "clave-de-prueba" };
    private static string Base64(byte[] datos) => Convert.ToBase64String(datos).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    private static Dictionary<string, object> Claims(string usuario = "editor")
    {
        long ahora = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        return new() { ["iss"] = "MYG_LICENCIAS", ["sub"] = usuario, ["aud"] = Audiencia,
            ["pc"] = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Pc))), ["jti"] = Guid.NewGuid().ToString("D"), ["iat"] = ahora, ["exp"] = ahora + 60 };
    }
    private static string Jwt(Dictionary<string, object> claims, object cabecera = null) =>
        Base64(JsonSerializer.SerializeToUtf8Bytes(cabecera ?? new { alg = "HS256", typ = "JWT" })) + "." + Base64(JsonSerializer.SerializeToUtf8Bytes(claims)) + "." + Base64(new byte[32]);
    private static string Paquete(Dictionary<string, object> claims = null, string usuario = "editor", string audiencia = Audiencia, object expira = null, string ticket = null)
    {
        claims ??= Claims(usuario);
        return JsonSerializer.Serialize(new { ok = true, ticket = ticket ?? Jwt(claims), usuario, audiencia, expira_en = expira ?? claims["exp"] });
    }
    private static async Task<Dictionary<string, string>> Formulario(HttpRequestMessage solicitud, CancellationToken ct)
    {
        Exige(solicitud.Method == HttpMethod.Post && solicitud.RequestUri.Query == "" && solicitud.RequestUri.Scheme == "https", "La operación nueva expuso credenciales en la URL o no usó POST HTTPS.");
        string formulario = await solicitud.Content.ReadAsStringAsync(ct);
        return formulario.Split('&').Select(x => x.Split('=', 2)).ToDictionary(x => Uri.UnescapeDataString(x[0].Replace('+', ' ')), x => Uri.UnescapeDataString(x[1].Replace('+', ' ')));
    }
    private static async Task<ResultadoTicketNube> Solicitar(string texto, HttpStatusCode codigo = HttpStatusCode.OK)
    {
        using var http = new HttpClient(new HttpSimulado((_, _) => Task.FromResult(Respuesta(texto, codigo))));
        return await new LicenciaServicio(http, Pc, Url).ObtenerTicketNubeAsync(Manual(), Audiencia);
    }

    internal static async Task EjecutarAsync(Action<string> pasa)
    {
        var formularios = new List<Dictionary<string, string>>();
        using (var http = new HttpClient(new HttpSimulado(async (solicitud, ct) => { formularios.Add(await Formulario(solicitud, ct)); return Respuesta("OK"); })))
        {
            var servicio = new LicenciaServicio(http, Pc, Url);
            Exige((await servicio.RevalidarAsync(new() { Usuario = " Usuario&Uno ", Clave = " clave +/? " })).Ok, "La revalidación manual falló.");
            var resultado = await servicio.RevalidarAsync(new() { Usuario = "otro", Automatico = true, Token = new string('T', 64), Clave = "no-enviar" });
            Exige(resultado.Ok && resultado.Token == null, "La revalidación automática renovó el token.");
            Exige(formularios.Count == 2 && formularios[0].Count == 4 && formularios[0]["accion"] == "validar_sesion" && formularios[0]["usuario"] == "Usuario&Uno" && formularios[0]["clave"] == "clave +/?" && formularios[0]["pc"] == Pc && !formularios[0].ContainsKey("token"), "Se alteraron los datos del POST manual de revalidación.");
            Exige(formularios[1].Count == 4 && formularios[1]["usuario"] == "otro" && formularios[1]["token"] == new string('T', 64) && !formularios[1].ContainsKey("clave"), "La revalidación mezcló credenciales de usuarios o modos distintos.");
        }
        foreach (string texto in new[] { "OK|" + new string('A', 64), "DATOS_INCOMPLETOS", "<html>OK</html>" })
        {
            using var http = new HttpClient(new HttpSimulado((_, _) => Task.FromResult(Respuesta(texto))));
            var resultado = await new LicenciaServicio(http, Pc, Url).RevalidarAsync(Manual());
            Exige(!resultado.Ok && resultado.Token == null && resultado.Mensaje.Contains("Actualice"), "La revalidación aceptó un ingreso que rota la sesión o no explica la actualización necesaria.");
        }
        pasa("Licencia: revalida con POST manual/automático, conserva el token y detecta Apps Script anterior");

        formularios.Clear();
        using (var http = new HttpClient(new HttpSimulado(async (solicitud, ct) =>
        {
            var datos = await Formulario(solicitud, ct);
            lock (formularios) formularios.Add(datos);
            await Task.Yield();
            return Respuesta(Paquete(usuario: datos["usuario"].Trim().ToLowerInvariant()));
        })))
        {
            var servicio = new LicenciaServicio(http, Pc, Url);
            var resultados = await Task.WhenAll(servicio.ObtenerTicketNubeAsync(Manual(" Editor "), "https://PRUEBAS-MYG.supabase.co/"),
                servicio.ObtenerTicketNubeAsync(new() { Usuario = "otro", Token = new string('B', 64), Automatico = true, Clave = "no-enviar" }, Audiencia));
            Exige(resultados.All(x => x.Ok && !x.LicenciaDenegada && x.Ticket != null && x.Ticket.Expira > DateTimeOffset.UtcNow && x.Ticket.Audiencia == Audiencia), "No acepta los tickets válidos del ingreso MYG.");
            Exige(resultados[0].Ticket.Usuario == "editor" && resultados[1].Ticket.Usuario == "otro" && resultados[0].Ticket.Ticket != resultados[1].Ticket.Ticket, "Los accesos simultáneos reutilizan la identidad de otro usuario.");
            var manual = formularios.Single(x => x.ContainsKey("clave")); var automatico = formularios.Single(x => x.ContainsKey("token"));
            Exige(manual.Count == 5 && manual["accion"] == "nube_ticket" && manual["audiencia"] == Audiencia && !manual.ContainsKey("token") && automatico.Count == 5 && !automatico.ContainsKey("clave") && automatico["token"] == new string('B', 64), "El ticket se solicitó con campos incorrectos o credenciales cruzadas.");
            Exige(!resultados[0].Ticket.ToString().Contains(resultados[0].Ticket.Ticket) && !resultados[0].ToString().Contains(resultados[0].Ticket.Ticket), "Un ToString expone el ticket sensible.");
        }
        pasa("Nube MYG: tickets por POST, audiencia canónica, identidad normalizada y dos usuarios independientes");

        const string licenciaId = "b2f11d1a-711a-477a-9ff8-055fcfdd9a34";
        var claimsLicencia = Claims(); claimsLicencia["licencia_id"] = licenciaId;
        string ticketLicencia = Jwt(claimsLicencia);
        var resultadoLicencia = await Solicitar(Paquete(claimsLicencia, ticket: ticketLicencia));
        Exige(resultadoLicencia.Ok && resultadoLicencia.Ticket.Ticket == ticketLicencia && !resultadoLicencia.LicenciaDenegada, "No conserva íntegro el ticket de ocho claims con identificación de licencia válida.");
        foreach (object identificador in new object[] { "", "malformado", Guid.Empty.ToString("D"), licenciaId.ToUpperInvariant(), licenciaId.Replace("-", ""), " " + licenciaId, licenciaId + " ", null, 17, true })
        {
            var claims = Claims(); claims["licencia_id"] = identificador;
            var resultado = await Solicitar(Paquete(claims));
            Exige(!resultado.Ok && resultado.Ticket == null && !resultado.LicenciaDenegada, "Se aceptó un licencia_id inválido o se invalidó la licencia local por el formato del ticket.");
        }
        Exige((await Solicitar(Paquete())).Ok, "El claim opcional licencia_id rompió la compatibilidad con tickets de siete claims.");
        pasa("Nube MYG: conserva tickets con licencia_id válido, rechaza identificadores inválidos y admite siete claims anteriores");

        var invalidos = new List<string> {
            Paquete(usuario: "EDITOR"), Paquete(audiencia: Audiencia + "/"), Paquete(expira: DateTimeOffset.UtcNow.ToUnixTimeSeconds() + 45),
            Paquete(expira: "no-es-numero"), Paquete(ticket: "no-es-un-jwt"), Paquete(ticket: "a..b"), Paquete(ticket: new string('x', 8193)),
            "{\"ok\":true,\"ok\":false}", "{\"ok\":\"true\"}", "{\"ok\":true,\"expira_en\":null}", "{malformado"
        };
        foreach (var cambio in new (string Campo, object Valor)[] {
            ("iss", "OTRO_SERVIDOR"), ("sub", "propietario"), ("sub", "EDITOR"), ("aud", "https://otro.supabase.co"),
            ("pc", "OTRA-PC"), ("jti", "sin-nonce"), ("jti", Guid.Empty.ToString("D")), ("jti", Guid.NewGuid().ToString("D").ToUpperInvariant()),
            ("iat", DateTimeOffset.UtcNow.ToUnixTimeSeconds() + 60), ("iat", DateTimeOffset.UtcNow.ToUnixTimeSeconds() - 500),
            ("exp", DateTimeOffset.UtcNow.ToUnixTimeSeconds() - 1), ("exp", DateTimeOffset.UtcNow.ToUnixTimeSeconds() + 300),
            ("exp", "no-es-numero"), ("iat", null), ("exp", long.MaxValue) })
        {
            var claims = Claims(); claims[cambio.Campo] = cambio.Valor; invalidos.Add(Paquete(claims));
        }
        invalidos.Add(Paquete(ticket: Jwt(Claims(), new { alg = "none", typ = "JWT" })));
        invalidos.Add(Paquete(ticket: Jwt(Claims(), new { alg = "HS256", typ = "OTRO" })));
        var fechaDistinta = Claims(); invalidos.Add(Paquete(fechaDistinta, expira: (long)fechaDistinta["exp"] + 1));
        var jwtBueno = Jwt(Claims()); invalidos.Add(Paquete(ticket: jwtBueno + "="));
        foreach (string texto in invalidos)
        {
            var resultado = await Solicitar(texto);
            Exige(!resultado.Ok && resultado.Ticket == null && !resultado.LicenciaDenegada, "Se aceptó un ticket inválido o se confundió con una revocación de licencia.");
            Exige(!resultado.Mensaje.Contains(texto), "Se reprodujo la respuesta del servidor en un mensaje.");
        }
        pasa("Nube MYG: rechaza metadatos, JWT, emisor, usuario, audiencia, PC, nonce y tiempos inconsistentes");

        foreach (string codigo in new[] { "BLOQUEADO", "EXPIRADO", "OTRA_PC", "CLAVE_ERROR", "TOKEN_INVALIDO", "NO_EXISTE", "AUTO_DESACTIVADO", "FECHA_INVALIDA" })
        {
            var resultado = await Solicitar(JsonSerializer.Serialize(new { ok = false, codigo }));
            Exige(!resultado.Ok && resultado.LicenciaDenegada && resultado.Ticket == null, "No reconoce la denegación de licencia: " + codigo);
            Exige((await Solicitar(codigo)).LicenciaDenegada, "No reconoce el error de licencia de un despliegue anterior: " + codigo);
            using var http = new HttpClient(new HttpSimulado((_, _) => Task.FromResult(Respuesta(codigo))));
            Exige(!(await new LicenciaServicio(http, Pc, Url).RevalidarAsync(Manual())).Ok, "La sesión sigue válida tras un error de licencia.");
        }
        foreach (string codigo in new[] { "NUBE_NO_CONFIGURADA", "AUDIENCIA_INVALIDA", "ERROR", "DESCONOCIDO" })
        {
            var resultado = await Solicitar(JsonSerializer.Serialize(new { ok = false, codigo }));
            Exige(!resultado.Ok && !resultado.LicenciaDenegada, "Un fallo de configuración de nube desautorizó MYG.");
        }
        foreach (var error in new[] { ("LICENCIA_ID_INVALIDO", "no es válida"), ("LICENCIA_ID_DUPLICADO", "misma identificación"), ("LICENCIA_ID_CABECERA_DUPLICADA", "cabecera") })
        {
            var resultado = await Solicitar(JsonSerializer.Serialize(new { ok = false, codigo = error.Item1 }));
            Exige(!resultado.Ok && !resultado.LicenciaDenegada && resultado.Ticket == null && resultado.Mensaje.Contains(error.Item2) && resultado.Mensaje.Contains("administrador"), "El error de configuración de la hoja no tiene un mensaje específico o invalida la licencia MYG.");
        }
        Exige(!(await Solicitar("OK", HttpStatusCode.ServiceUnavailable)).LicenciaDenegada && !(await Solicitar("OK")).Ok && (await Solicitar("DATOS_INCOMPLETOS")).Mensaje.Contains("Actualice"), "Un Apps Script anterior o un HTTP 503 se trató como ticket o licencia revocada.");
        Exige(LicenciaServicio.Interpretar("AUTO_DESACTIVADO", true).Mensaje == "Ingrese su usuario y contraseña." && LicenciaServicio.Interpretar("FECHA_INVALIDA", false).Mensaje.Contains("fecha"), "Faltan los errores actuales del servidor de licencias.");
        pasa("Nube MYG: distingue licencia revocada de configuración, Apps Script anterior y fallo temporal");

        int peticiones = 0;
        using (var http = new HttpClient(new HttpSimulado((_, _) => { peticiones++; return Task.FromResult(Respuesta(Paquete())); })))
        {
            var servicio = new LicenciaServicio(http, Pc, Url);
            foreach (string audiencia in new[] { "http://pruebas-myg.supabase.co", "https://pruebas-myg.supabase.co/ruta", "https://otro.example.com", "https://pruebas-myg.supabase.co?token=secreto", "https://usuario:clave@pruebas-myg.supabase.co", "https://pruebas-myg.supabase.co:444", "https://.supabase.co" })
                Exige(!(await servicio.ObtenerTicketNubeAsync(Manual(), audiencia)).Ok, "Se aceptó una audiencia insegura o incorrecta.");
            foreach (var credencial in new CredencialMYG[] { null, new(), new() { Usuario = "x" }, new() { Usuario = "x", Automatico = true, Token = "corto" }, new() { Usuario = new string('a', 257), Clave = "x" }, new() { Usuario = "x\npropietario", Clave = "x" } })
                Exige(!(await servicio.ObtenerTicketNubeAsync(credencial, Audiencia)).Ok && !(await servicio.RevalidarAsync(credencial)).Ok, "Se enviaron credenciales incompletas o inválidas.");
            Exige(!(await new LicenciaServicio(http, Pc, "http://licencias.example.invalid/exec").ObtenerTicketNubeAsync(Manual(), Audiencia)).Ok && peticiones == 0, "La validación local dejó enviar datos a una URL insegura.");
            using var cancelada = new CancellationTokenSource(); cancelada.Cancel();
            await ExigeCancelacion(async () => { await servicio.ObtenerTicketNubeAsync(Manual(), Audiencia, cancelada.Token); });
            await ExigeCancelacion(async () => { await servicio.RevalidarAsync(Manual(), cancelada.Token); });
            Exige(peticiones == 0, "Se hizo una petición después de cancelar.");
        }
        pasa("Nube MYG: valida entradas y HTTPS antes de enviar; la cancelación previa no envía credenciales");

        foreach (bool longitudConocida in new[] { true, false })
        {
            using var http = new HttpClient(new HttpSimulado((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) {
                Content = longitudConocida ? new ByteArrayContent(new byte[1024 * 1024 + 1]) : new ContenidoSinLongitud(new byte[1024 * 1024 + 1]) })));
            var servicio = new LicenciaServicio(http, Pc, Url);
            Exige(!(await servicio.ObtenerTicketNubeAsync(Manual(), Audiencia)).Ok && !(await servicio.RevalidarAsync(Manual())).Ok, "No limitó la respuesta del servidor a 1 MiB.");
        }
        using (var http = new HttpClient(new HttpSimulado((_, _) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(new byte[] { 255 }) }))))
            Exige(!(await new LicenciaServicio(http, Pc, Url).ObtenerTicketNubeAsync(Manual(), Audiencia)).Ok, "Se aceptó UTF-8 inválido.");
        using (var http = new HttpClient(new HttpSimulado((_, _) => throw new OperationCanceledException())))
            Exige(!(await new LicenciaServicio(http, Pc, Url).ObtenerTicketNubeAsync(Manual(), Audiencia)).Ok, "Un timeout se convirtió en autorización.");
        using (var http = new HttpClient(new HttpSimulado((_, _) => throw new IOException("Corte de conexión simulado"))))
        {
            var servicio = new LicenciaServicio(http, Pc, Url);
            Exige(!(await servicio.ObtenerTicketNubeAsync(Manual(), Audiencia)).Ok && !(await servicio.RevalidarAsync(Manual())).Ok, "Un corte de recepción no se convirtió en un resultado controlado.");
        }
        using (var cancelacion = new CancellationTokenSource(TimeSpan.FromMilliseconds(20)))
        using (var http = new HttpClient(new HttpSimulado(async (_, ct) => { await Task.Delay(Timeout.InfiniteTimeSpan, ct); return Respuesta("OK"); })))
            await ExigeCancelacion(async () => { await new LicenciaServicio(http, Pc, Url).ObtenerTicketNubeAsync(Manual(), Audiencia, cancelacion.Token); });
        pasa("Nube MYG: limita respuestas conocidas y transmitidas, rechaza UTF-8 inválido y respeta cancelación en curso");
    }

    private static async Task ExigeCancelacion(Func<Task> operacion)
    { try { await operacion(); } catch (OperationCanceledException) { return; } throw new Exception("La operación no respetó la cancelación explícita."); }
    private sealed class HttpSimulado(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> responder) : HttpMessageHandler
    { protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct) => responder(solicitud, ct); }
    private sealed class ContenidoSinLongitud(byte[] datos) : HttpContent
    {
        protected override Task SerializeToStreamAsync(Stream flujo, TransportContext contexto) => flujo.WriteAsync(datos).AsTask();
        protected override bool TryComputeLength(out long longitud) { longitud = 0; return false; }
        protected override Task<Stream> CreateContentReadStreamAsync() => Task.FromResult<Stream>(new MemoryStream(datos, false));
    }
}
