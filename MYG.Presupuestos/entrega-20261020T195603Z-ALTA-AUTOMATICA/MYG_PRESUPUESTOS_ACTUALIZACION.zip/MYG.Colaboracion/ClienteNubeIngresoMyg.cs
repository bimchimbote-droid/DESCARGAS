#nullable enable
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using MYG.Externo;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    /// <summary>Canjea una autorización breve del servidor MYG; no recibe la clave de MYG ni la de Supabase.</summary>
    public Task IniciarSesionMygAsync(TicketNubeMYG ticket, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(ticket);
        string usuario = ticket.Usuario ?? "";
        string[] partes = (ticket.Ticket ?? "").Split('.');
        DateTimeOffset ahora = _reloj.GetUtcNow();
        if (!UsuarioMygValido(usuario)
            || !string.Equals(ticket.Audiencia?.TrimEnd('/'), UrlServidor, StringComparison.OrdinalIgnoreCase)
            || ticket.Expira <= ahora || ticket.Expira > ahora.AddSeconds(90)
            || ticket.Ticket?.Length > 8192 || partes.Length != 3
            || partes.Any(p => p.Length == 0 || !p.All(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_')))
            throw new NubeException("La autorización MYG no es válida para esta conexión. Solicite un nuevo ingreso a la nube.", necesitaIniciarSesion: true);

        return EjecutarAsync(async token =>
        {
            // Nunca conservar una cuenta previa durante el canje para otro usuario.
            LimpiarSesion();
            if (ticket.Expira <= _reloj.GetUtcNow())
                throw new NubeException("La autorización MYG caducó. Vuelva a conectar con su usuario MYG.", necesitaIniciarSesion: true);
            byte[] cuerpo = JsonSerializer.SerializeToUtf8Bytes(new { ticket = ticket.Ticket });
            using var respuesta = await EnviarAsync(HttpMethod.Post, "functions/v1/myg-login", cuerpo, acceso: null, token);
            if (!respuesta.IsSuccessStatusCode) await LanzarErrorIngresoMygAsync(respuesta, token);
            PublicarSesion(await LeerSesionAsync(respuesta, token, usuario));
            return true;
        }, ct);
    }

    private static bool UsuarioMygValido(string usuario)
    {
        if (usuario.Length is < 1 or > 256 || usuario != usuario.Trim().ToLowerInvariant() || usuario.Any(char.IsControl)) return false;
        for (int i = 0; i < usuario.Length; i++)
        {
            if (!char.IsSurrogate(usuario[i])) continue;
            if (!char.IsHighSurrogate(usuario[i]) || i + 1 >= usuario.Length || !char.IsLowSurrogate(usuario[++i])) return false;
        }
        return true;
    }

    private static async Task LanzarErrorIngresoMygAsync(HttpResponseMessage respuesta, CancellationToken ct)
    {
        string? codigo = null;
        try
        {
            using var json = await LeerJsonAsync(respuesta, ct);
            if (json.RootElement.ValueKind == JsonValueKind.Object
                && json.RootElement.TryGetProperty("error", out var error) && error.ValueKind == JsonValueKind.String)
                codigo = error.GetString();
        }
        catch (NubeException) { }
        // No mostrar cuerpos remotos, enlaces de acceso ni credenciales recibidas por error.
        if (respuesta.StatusCode == HttpStatusCode.NotFound)
            throw new NubeException("Instale la función myg-login y la migración de ingreso MYG en este proyecto Supabase.");
        if (codigo == "MYG_IDENTIDAD_REQUIERE_REVISION")
            throw new NubeException("El administrador debe revisar la identidad de nube de este usuario MYG antes de permitir el ingreso.",
                accesoDenegado: true, codigo: "MYG_IDENTIDAD_REQUIERE_REVISION");
        if (codigo == "MYG_LICENCIA_CONFLICTO")
            throw new NubeException("Existe un conflicto entre la licencia MYG y la identidad de nube. Solicite al administrador que revise la vinculación existente.",
                accesoDenegado: true, codigo: "MYG_LICENCIA_CONFLICTO");
        if (codigo == "MYG_VINCULO_NO_VERIFICADO")
            throw new NubeException("El administrador debe verificar el vínculo entre este usuario MYG y su cuenta de nube.",
                accesoDenegado: true, vinculoNoVerificado: true, codigo: "MYG_VINCULO_NO_VERIFICADO");
        if (codigo == "MYG_INGRESO_REUTILIZADO")
            throw new NubeException("La autorización MYG ya se utilizó. Vuelva a conectar para solicitar una nueva.",
                necesitaIniciarSesion: true, codigo: "MYG_INGRESO_REUTILIZADO");
        if (respuesta.StatusCode == HttpStatusCode.Forbidden)
            throw new NubeException("El servidor no permite el ingreso de este usuario MYG a la nube. Solicite al administrador que revise el acceso.",
                accesoDenegado: true);
        if (respuesta.StatusCode == HttpStatusCode.Conflict)
            throw new NubeException("El servidor no pudo completar el ingreso MYG por un conflicto. Reintente; si persiste, solicite revisión al administrador.",
                esErrorDeConexion: true);
        if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
            throw new NubeException("La autorización MYG fue rechazada o caducó. Vuelva a conectar con su usuario MYG.", necesitaIniciarSesion: true);
        if ((int)respuesta.StatusCode >= 500 || respuesta.StatusCode is HttpStatusCode.RequestTimeout or HttpStatusCode.TooManyRequests)
            throw new NubeException("El ingreso MYG a la nube no está disponible. Reintente; si persiste, revise la instalación y configuración de myg-login en el servidor.", esErrorDeConexion: true);
        throw new NubeException("El servidor rechazó el ingreso MYG a la nube. Revise la configuración de myg-login.");
    }
}
