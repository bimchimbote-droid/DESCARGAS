# Nube MYG v2

El escritorio actualizado usa ingreso único con la sesión MYG. Para añadir ese acceso a una instalación existente, sigue [README-INGRESO-MYG.md](README-INGRESO-MYG.md); instala únicamente la migración 003 y su función, sin repetir 001/002. Esta guía conserva el contrato de proyectos, archivos y permisos.

La actualización de alta automática se describe en `../LEEME_ALTA_AUTOMATICA_LICENCIAS.md`: añade la migración 004 y usa el ID estable firmado por la autoridad de licencias. No requiere correos para usuarios nuevos ni concede roles de presupuesto automáticamente.

La migración `migrations/202610190001_nube_myg.sql` prepara las RPC de Nube MYG; `migrations/202610190002_archivos_nube.sql` agrega el almacenamiento privado de adjuntos. Sus tablas `myg_nube_*` y su esquema `myg_nube_privado` son independientes del piloto `myg_proyectos`/`myg_cambiar_cantidad`; no importan ni modifican el DEMO. La revisión remota pertenece al paquete completo de una obra o base. Un cambio concurrente produce conflicto del paquete y requiere conciliación explícita; no hay mezcla automática por celda.

## Instalación administrativa

1. Revisar y ejecutar **en este orden** las migraciones `202610190001_nube_myg.sql` y `202610190002_archivos_nube.sql`, completas y una sola vez como administrador PostgreSQL, primero en un proyecto Supabase de pruebas con Auth y Storage disponibles. La primera transacción falla si ya existen sus tablas o funciones: no sustituir por `DROP` ni sobrescribir una instalación existente. El control de migraciones de Supabase evita ejecutarlas dos veces. La segunda requiere el catálogo `storage.objects`/`storage.buckets` gestionado por Supabase; no crear en producción el fixture simplificado del ejecutor local.
2. Mantener `myg_nube_privado` **fuera de Exposed schemas** en Data API. Solo las RPC públicas deben exponerse. No conceder acceso directo a sus tablas ni políticas adicionales de escritura a `authenticated` o `anon`.
3. Usar en MYG la URL HTTPS del proyecto y su clave publicable/anon. El ingreso único obtiene una sesión con la identidad MYG ya autenticada; las sesiones permanecen en memoria. La clave `service_role` y la conexión de administrador nunca deben distribuirse con el programa, incluirse en repositorio ni enviarse por chat.
4. Confirmar que el bucket `myg-nube-archivos` sea privado. La migración no convierte un bucket público existente ni lo hace público: en ese caso falla para que el administrador resuelva la configuración existente. El cliente admite archivos de hasta 20 MiB; los datos estructurados usan PostgreSQL y los bytes de los adjuntos usan Storage. La migración agrega políticas limitadas a este bucket y conserva las de otros buckets.
5. Proveer las vinculaciones verificadas antes de permitir el uso de la nube. Sin ellas, todas las RPC rechazan con `42501 / MYG_VINCULO_NO_VERIFICADO`, aunque Supabase Auth haya autenticado correctamente a la cuenta.

Esta entrega no instala cambios en un servicio remoto ni afirma que el proyecto Supabase del usuario tenga estas RPC o vinculaciones.

## Vinculación de identidad pendiente de provisión

`myg_nube_privado.identidades_verificadas` relaciona `auth_usuario_id` (UUID real de Supabase Auth) con `usuario_myg` (identidad textual del sistema MYG), estado activo y referencia de evidencia. Solo un administrador o un servicio de confianza con `service_role` puede administrarla. RLS está habilitado y los clientes no tienen permisos sobre la tabla. La migración de archivos concede a `authenticated` únicamente `USAGE` del esquema y `EXECUTE` de los dos predicados booleanos que necesitan las políticas de Storage; no permite leer identidades, ejecutar las demás funciones privadas ni exponer el esquema en Data API.

La autoridad de identidad verifica la licencia y el equipo desde Apps Script y firma un ID estable. Con la actualización 004, el servidor puede crear la identidad técnica de nube y su vínculo usando esa autorización; los vínculos antiguos válidos conservan su UUID. La evidencia almacenada describe esa verificación del servidor y nunca contiene contraseñas ni tokens. Coincidencia de correo, `user_metadata`, posesión de un código de proyecto o una licencia declarada por el cliente no acreditan la vinculación. Las RPC administrativas de alta sólo admiten service_role después de verificar el ticket; el cliente no puede autoaprobarse.

Una vez realizada esa verificación fuera del cliente, la provisión administrativa usa parámetros de una conexión segura; ejemplo conceptual (los `$n` son parámetros, no valores para pegar):

```sql
insert into myg_nube_privado.identidades_verificadas
  (auth_usuario_id, usuario_myg, evidencia_verificacion)
values ($1::uuid, $2::text, $3::text);
```

Desactivar `activo` revoca el acceso a todas las RPC de la cuenta. Las membresías y el historial se conservan para auditoría. Los permisos de proyecto usan exclusivamente el UUID derivado de `auth.uid()`, no el nombre MYG enviado por un cliente. La licencia de uso continúa siendo una comprobación independiente.

## Contrato y seguridad

Todas las RPC requieren sesión y vinculación activa. Las funciones con privilegios elevados fijan `search_path`, califican las tablas por esquema y no ejecutan SQL suministrado por el cliente. Todas las tablas tienen RLS y los roles de cliente carecen de lectura/escritura directa; `anon` tampoco puede ejecutar las RPC.

| RPC | Parámetros | Respuesta |
| --- | --- | --- |
| `myg_nube_listar` | ninguno | Array de `id,codigo,nombre,rol,revision,alcance`, sin contenido |
| `myg_nube_crear` | `p_id,p_nombre,p_contenido,p_alcance` | Snapshot con los campos anteriores y `contenido` |
| `myg_nube_abrir` | `p_id` | Snapshot autorizado |
| `myg_nube_guardar` | `p_id,p_operacion,p_revision,p_contenido` | `estado,revision,contenido,operacion_id` |
| `myg_nube_solicitar` | `p_codigo` | Siempre `{"estado":"recibida"}` para un código sintácticamente válido |
| `myg_nube_miembros` | `p_id` | Array de `usuario_id,rol`, solo propietario/administrador |
| `myg_nube_solicitudes` | `p_id` | Solicitudes pendientes `usuario_id,estado`, solo propietario/administrador |
| `myg_nube_resolver` | `p_id,p_usuario,p_rol,p_aprobar` | `true`; exige solicitud pendiente |
| `myg_nube_rol` | `p_id,p_usuario,p_rol` | `true`; `p_rol=null` retira acceso |

`alcance` es `obra` o `base`. Los roles son `propietario`, `administrador`, `editor` y `lector`. Propietario, administrador y editor pueden guardar; lector solo abre. El propietario inicial es fijo: estas RPC no lo transfieren ni lo retiran. Solo el propietario concede o modifica administradores. Un administrador gestiona editores y lectores sin modificar administradores ni al propietario. Los destinatarios deben tener una vinculación activa.

El código se genera como `MYG-` seguido del UUID remoto sin guiones. Identifica el proyecto y sirve para solicitar acceso; no permite leerlo. La solicitud devuelve la misma respuesta para un código desconocido, un miembro existente y una solicitud nueva; no devuelve nombre, identificador ni contenido de un proyecto sin permiso.

Los UUID tipados inválidos se rechazan en PostgreSQL; crear y guardar también rechazan UUID vacíos. Nombre: 1–200 caracteres después de recortar extremos. Código recibido: 1–64 caracteres. Contenido: objeto JSON, máximo SQL de 32 MiB medidos como UTF-8 de `jsonb::text`; el cliente puede aplicar una cota menor de 31 MiB para reservar espacio a la respuesta y sus metadatos. Es un límite del paquete transportado, no del tamaño de un archivo SQLite descomprimido.

Crear conserva el UUID generado antes del primer envío. Un reintento del mismo propietario debe coincidir con nombre, alcance y contenido de la creación original (historial de revisión 1); devuelve el snapshot actual y nunca sustituye datos posteriores. El mismo UUID con otro cuerpo se rechaza.

Guardar bloquea la fila de proyecto y comprueba el permiso actual **antes** de consultar operaciones anteriores. El identificador idempotente se compone de usuario y UUID; el proyecto, revisión base y contenido deben coincidir en un reintento. La misma intención mantiene su UUID incluso tras perder una respuesta. Una nueva decisión tras resolver un conflicto usa UUID nuevo y revisión vigente. Los reintentos devuelven la respuesta histórica, por lo que después puede ser necesaria una nueva apertura. Los conflictos no cambian contenido ni historial; las aplicaciones actualizan proyecto, revisión, operación e historial en una transacción. Los cambios de roles usan el mismo bloqueo de proyecto.

Los snapshots incluyen el contenido proporcionado por la capa de paquetes de MYG; el SQL no interpreta entidades de presupuesto ni busca rutas de archivos. La segunda migración comprueba que el alcance del paquete coincida con el del proyecto, que cada referencia de adjunto exista en el bucket privado y que su ruta termine en el SHA-256 declarado. No admite bytes Base64 dentro del snapshot remoto. La lectura de bytes y su comprobación SHA-256 se realizan también en el cliente; el SQL sólo valida las referencias del catálogo Storage, no calcula el hash del archivo. Una ruta externa por sí sola no sube un archivo.

Cada objeto usa la ruta canónica `UUID_CUENTA/UUID_LOTE_SIN_GUIONES/SHA256_HEXADECIMAL`. Una cuenta vinculada activa puede subir y leer sus propios objetos; los miembros vigentes de un proyecto pueden leer los objetos referidos por ese proyecto. Un lector no puede modificar el snapshot. La retirada de membresía impide leer los adjuntos de otros usuarios a través de ese proyecto; no elimina archivos propios de la cuenta ni copias ya descargadas. Desactivar la vinculación impide incluso leer los objetos propios a través del cliente.

Los objetos son inmutables: el cliente no tiene permiso para reemplazarlos ni eliminarlos. Las políticas restrictivas cierran este bucket incluso si otra aplicación había creado políticas permisivas amplias para Storage. Una subida correcta seguida de un fallo al publicar puede dejar objetos sin referencia. Su limpieza y el crecimiento de snapshots, operaciones e historial requieren una política administrativa de capacidad y retención acordada antes de usar bases grandes en producción. No eliminar objetos aún referidos por proyectos sin comprobar sus dependencias.

## Validación reproducible sin servicio remoto

`tests/nube_myg_regresion.sql` crea cuatro identidades ficticias en una transacción y simula Auth mediante claims. Comprueba RLS/privilegios, las nueve RPC sin vinculación, creación y reintentos, límites de datos, aislamiento de usuarios, solicitud sin fuga de contenido, roles/jerarquía, permisos retirados antes de reintento, conflicto optimista, idempotencia, historial y reversión. Termina con `PRUEBA_NUBE_MYG_CORRECTA` y `ROLLBACK`. El ejecutor la corre **antes** de instalar la segunda migración porque verifica las condiciones de la primera instalación por separado.

Después, `tests/archivos_nube_regresion.sql` verifica las políticas de Storage: inserción sólo en la ruta propia, rechazo de cuentas sin vinculación, lectura por membresía, retirada de acceso, desactivación de identidad, anonimato, inmutabilidad y conservación de políticas de otro bucket. También comprueba que publicación y guardado rechacen alcance distinto, bytes inline, referencias inexistentes, hash de ruta distinto y recursos mal formados, sin dejar proyectos o revisiones parciales. Termina con `PRUEBA_ARCHIVOS_NUBE_CORRECTA` y `ROLLBACK`. Ejecutar las regresiones sólo en una base desechable/local como administrador; no equivalen a iniciar sesión en Supabase.

El ejecutor PGlite instala y ejecuta PostgreSQL en memoria, sin credenciales ni conexión remota. Desde la raíz del repositorio, con Node.js y npm disponibles:

```bash
ruta_pruebas=$(mktemp -d)
npm install --prefix "$ruta_pruebas" --cache /tmp/myg-npm-cache --no-audit --no-fund @electric-sql/pglite@0.3.14
cp supabase/tests/ejecutar-pglite.mjs "$ruta_pruebas/ejecutar.mjs"
node "$ruta_pruebas/ejecutar.mjs" "$PWD"
```

Ambas migraciones y ambas regresiones se ejecutaron correctamente con PGlite 0.3.14 durante esta implementación; las comprobaciones posteriores confirmaron cero proyectos y cero objetos de prueba después del `ROLLBACK`. El fixture de Storage contiene únicamente un catálogo simplificado, sin bytes: no prueba la carga HTTP, el límite real del gateway ni el servicio Storage de Supabase. Es una validación de PostgreSQL con Auth y roles simulados, no de PostgREST, red, JWT reales ni sesiones simultáneas en un servidor.

Antes de dar por validada la colaboración real, quedan estas comprobaciones en un Supabase de pruebas con dos cuentas auténticas y sus vinculaciones verificadas:

1. Publicar desde Windows con la cuenta propietaria, solicitar acceso con la segunda cuenta, aprobar y abrir desde otro equipo, comprobando contenido y relaciones.
2. Editar desde ambos equipos partiendo de una misma revisión: uno confirma y el otro conserva el borrador al recibir conflicto. Resolver explícitamente con UUID y revisión nuevos.
3. Interrumpir la respuesta de guardado, cerrar/reabrir MYG y reintentar: una sola revisión e historial; retirar permisos antes del reintento y comprobar el rechazo.
4. Probar lector, administrador, retiro de acceso y desactivación del vínculo sin publicar contenido por código; verificar que un JWT inválido/expirado y una petición anónima se rechazan en Data API.
5. Subir adjuntos al bucket privado y descargarlos desde otro equipo con membresía vigente; retirar la membresía y repetir la lectura de un objeto de la primera cuenta con el token de la segunda. Comprobar rechazo anónimo y que las rutas no sean públicas.
6. Descargar desde un estado confirmado, abrir la copia independiente y comparar cálculos, relaciones, documentos y adjuntos; comprobar SHA-256, límites del gateway y tamaños reales.

La UI Windows, Revit, la licencia real, el inicio de sesión remoto y la ejecución concurrente con dos conexiones requieren esas pruebas adicionales. No se declaran realizadas por las pruebas locales.
