// node --test supabase/functions/myg-login/handler.test.mjs (Node 24; sin red ni secretos reales).
import test from 'node:test';
import assert from 'node:assert/strict';
import { crearHandler } from './handler.ts';

const AHORA = 1_800_000_000;
const URL_BASE = 'https://prueba-myg.supabase.co';
const SECRETO = 'a1'.repeat(32); // Dato sintético público, NO usar para desplegar.
const ID_A = '11111111-1111-4111-8111-111111111111';
const ID_B = '22222222-2222-4222-8222-222222222222';
const NONCE = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const PC = 'A'.repeat(64);
const ENV = { SUPABASE_URL: URL_BASE, SUPABASE_ANON_KEY: 'anon-ficticia',
  SUPABASE_SERVICE_ROLE_KEY: 'servicio-ficticio', MYG_NUBE_HMAC: SECRETO };
const base64 = (valor) => Buffer.from(typeof valor === 'string' ? valor : JSON.stringify(valor)).toString('base64url');
async function ticket(cambios = {}, cabecera = { alg: 'HS256', typ: 'JWT' }, secreto = SECRETO) {
  const datos = `${base64(cabecera)}.${base64({ iss: 'MYG_LICENCIAS', aud: URL_BASE,
    sub: 'persona-a', pc: PC, jti: NONCE, iat: AHORA, exp: AHORA + 60, ...cambios })}`;
  const clave = await crypto.subtle.importKey('raw', new TextEncoder().encode(secreto),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return `${datos}.${Buffer.from(await crypto.subtle.sign('HMAC', clave, new TextEncoder().encode(datos))).toString('base64url')}`;
}
function fixture(opciones = {}) {
  const llamadas = [];
  const nonces = new Set();
  const sesiones = [];
  const respuesta = (estado, datos) => new Response(JSON.stringify(datos), { status: estado,
    headers: { 'content-type': 'application/json' } });
  let actual;
  const enviar = async (url, init) => {
    assert.equal(new URL(url).origin, URL_BASE, 'Toda llamada mantiene el destino fijo');
    assert.equal(init.redirect, 'error');
    const ruta = new URL(url).pathname;
    const cuerpo = init.body ? JSON.parse(init.body) : undefined;
    llamadas.push({ ruta, cuerpo, init });
    if (ruta === '/rest/v1/rpc/myg_nube_preparar_ingreso') {
      assert.equal(init.headers.apikey, ENV.SUPABASE_SERVICE_ROLE_KEY);
      if (opciones.rpc) return respuesta(opciones.rpc[0], opciones.rpc[1]);
      if (nonces.has(cuerpo.p_nonce)) return respuesta(409, { message: 'MYG_INGRESO_REUTILIZADO' });
      nonces.add(cuerpo.p_nonce);
      actual = cuerpo.p_usuario === 'persona-b' ? ID_B : ID_A;
      return respuesta(200, { usuario_id: actual, usuario_myg: cuerpo.p_usuario, licencia_id: cuerpo.p_licencia_id,
        crear_usuario: opciones.tecnica || false, origen: opciones.tecnica ? 'tecnica' : 'existente',
        alias: opciones.tecnica ? `licencia${cuerpo.p_licencia_id}@myg.invalid` : null });
    }
    if (ruta === '/auth/v1/admin/users') {
      assert.equal(init.method, 'POST');
      assert.equal(cuerpo.id, actual); assert.equal(cuerpo.email_confirm, true);
      assert.deepEqual(Object.keys(cuerpo).sort(), ['app_metadata','email','email_confirm','id']);
      assert.deepEqual(cuerpo.app_metadata, { myg_nube_licencia_id: opciones.licencia, myg_nube_origen: 'licencias_v1' });
      return respuesta(opciones.estadoAlta || (opciones.conflictoAlta ? 422 : 201), opciones.conflictoAlta || opciones.estadoAlta ? { message: 'Email exists' } :
        { id: opciones.idAlta || actual, email: cuerpo.email, app_metadata: cuerpo.app_metadata });
    }
    if (ruta === '/rest/v1/rpc/myg_nube_confirmar_ingreso') {
      if (opciones.confirmacion) return respuesta(opciones.confirmacion[0], opciones.confirmacion[1]);
      return respuesta(200, { usuario_id: actual, usuario_myg: opciones.tecnica ? 'persona-nueva' : actual === ID_A ? 'persona-a' : 'persona-b' });
    }
    if (ruta.startsWith('/auth/v1/admin/users/')) {
      assert.equal(init.method, 'GET');
      assert.equal(ruta, `/auth/v1/admin/users/${actual}`);
      if (opciones.eliminado) return respuesta(404, { message: 'no user' });
      return respuesta(200, { id: opciones.idGet || actual,
        email: opciones.tecnica ? `licencia${opciones.licencia}@myg.invalid` : `${actual}@prueba.example`,
        ...(opciones.tecnica ? { app_metadata: { myg_nube_licencia_id: opciones.licencia, myg_nube_origen: 'licencias_v1' } } : {}), ...opciones.perfil });
    }
    if (ruta === '/auth/v1/admin/generate_link') {
      assert.deepEqual(cuerpo, { type: 'recovery', email: opciones.tecnica ? `licencia${opciones.licencia}@myg.invalid` : `${actual}@prueba.example` });
      if (opciones.eliminadoDuranteCanje) return respuesta(404, { message: 'no user' });
      return respuesta(200, { id: opciones.idGenerado || actual, hashed_token: 'hash-interno',
        verification_type: opciones.tipoGenerado || 'recovery', action_link: 'https://no-visitar.example', email_otp: '123456' });
    }
    if (ruta === '/auth/v1/verify') {
      assert.equal(init.headers.apikey, ENV.SUPABASE_ANON_KEY);
      assert.deepEqual(cuerpo, { token_hash: 'hash-interno', type: 'recovery' });
      const sesion = { access_token: `sesion-${actual}`, refresh_token: `renovacion-${actual}`,
        expires_in: 3600, user: { id: opciones.idVerificado || actual }, ...opciones.sesion };
      sesiones.push(sesion);
      return respuesta(200, sesion);
    }
    throw new Error('Destino inesperado');
  };
  const handler = crearHandler({ env: k => ({ ...ENV, ...opciones.env })[k],
    now: () => AHORA * 1000, fetch: opciones.fetch || enviar });
  const conectar = async (jwt, body) => {
    const r = await handler(new Request(`${URL_BASE}/functions/v1/myg-login`, { method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: ENV.SUPABASE_ANON_KEY },
      body: body === undefined ? JSON.stringify({ ticket: jwt }) : body }));
    return { estado: r.status, datos: await r.json(), headers: r.headers };
  };
  return { handler, conectar, llamadas, sesiones };
}

test('Canje válido usa Auth existente, OTP interno y solo devuelve sesión mínima', async () => {
  const f = fixture(); const r = await f.conectar(await ticket());
  assert.equal(r.estado, 200);
  assert.deepEqual(r.datos, { access_token: `sesion-${ID_A}`, refresh_token: `renovacion-${ID_A}`,
    expires_in: 3600, user: { id: ID_A }, usuario_myg: 'persona-a' });
  assert.equal(f.llamadas.length, 5);
  assert.equal(r.headers.get('cache-control'), 'no-store');
  assert.ok(!JSON.stringify(r.datos).includes('hash-interno'));
  assert.ok(!JSON.stringify(r.datos).includes('123456'));
  assert.ok(!JSON.stringify(r.datos).includes(ENV.SUPABASE_SERVICE_ROLE_KEY));
});
test('Dos usuarios obtienen sesiones distintas sin cerrar la sesión del otro', async () => {
  const f = fixture();
  const a = await f.conectar(await ticket());
  const b = await f.conectar(await ticket({ sub: 'persona-b', jti: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb' }));
  assert.equal(a.estado, 200); assert.equal(b.estado, 200);
  assert.equal(a.datos.user.id, ID_A); assert.equal(b.datos.user.id, ID_B);
  assert.notEqual(a.datos.access_token, b.datos.access_token);
  assert.ok(f.llamadas.every(x => !x.ruta.includes('logout')));
});
test('El mismo nonce no crea una segunda sesión', async () => {
  const f = fixture(); const jwt = await ticket();
  assert.equal((await f.conectar(jwt)).estado, 200);
  assert.deepEqual((await f.conectar(jwt)).datos, { error: 'MYG_INGRESO_REUTILIZADO' });
  assert.equal(f.sesiones.length, 1);
});
for (const [nombre, cambios] of [
  ['emisor ajeno', { iss: 'falso' }], ['audiencia ajena', { aud: 'https://atacante.example' }],
  ['usuario no normalizado', { sub: ' Persona-A ' }], ['usuario con control', { sub: 'persona\na' }],
  ['usuario vacío', { sub: '' }], ['usuario largo', { sub: 'x'.repeat(257) }],
  ['PC incorrecta', { pc: 'a'.repeat(64) }], ['nonce inválido', { jti: 'no-uuid' }],
  ['nonce cero', { jti: '00000000-0000-0000-0000-000000000000' }],
  ['iat fraccional', { iat: AHORA + 0.5 }], ['exp fraccional', { exp: AHORA + 60.5 }],
  ['iat futuro', { iat: AHORA + 31, exp: AHORA + 91 }], ['TTL largo', { exp: AHORA + 91 }],
  ['exp no posterior', { exp: AHORA }], ['atributo inesperado URL', { url: 'https://atacante.example' }],
]) {
  test(`Rechaza ${nombre} antes de tocar el servidor`, async () => {
    const f = fixture(); const r = await f.conectar(await ticket(cambios));
    assert.equal(r.estado, 401); assert.equal(f.llamadas.length, 0);
  });
}
test('Rechaza ticket vencido después de la tolerancia', async () => {
  const f = fixture(); const r = await f.conectar(await ticket({ iat: AHORA - 92, exp: AHORA - 32 }));
  assert.equal(r.estado, 401); assert.equal(r.datos.error, 'MYG_INGRESO_EXPIRADO');
});
for (const cabecera of [{ alg: 'none', typ: 'JWT' }, { alg: 'HS512', typ: 'JWT' },
  { alg: 'HS256', typ: 'JWT', jku: 'https://atacante.example' }]) {
  test(`Rechaza algoritmo/cabecera ${JSON.stringify(cabecera)}`, async () => {
    const f = fixture(); assert.equal((await f.conectar(await ticket({}, cabecera))).estado, 401);
    assert.equal(f.llamadas.length, 0);
  });
}
test('Firma alterada, clave equivocada y hex decodificado fallan', async () => {
  const f = fixture(); const original = await ticket();
  const piezas = original.split('.'); piezas[1] = base64({ sub: 'persona-b' });
  assert.equal((await f.conectar(piezas.join('.'))).estado, 401);
  assert.equal((await f.conectar(await ticket({}, undefined, 'b2'.repeat(32)))).estado, 401);
  const crudo = `${base64({ alg: 'HS256', typ: 'JWT' })}.${original.split('.')[1]}`;
  const clave = await crypto.subtle.importKey('raw', Buffer.from(SECRETO, 'hex'), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const firma = Buffer.from(await crypto.subtle.sign('HMAC', clave, new TextEncoder().encode(crudo))).toString('base64url');
  assert.equal((await f.conectar(`${crudo}.${firma}`)).estado, 401);
  assert.equal(f.llamadas.length, 0);
});
test('Límites de JWT/cuerpo y JSON inválido no llaman a Auth', async () => {
  const f = fixture();
  assert.equal((await f.conectar('x'.repeat(8193))).estado, 401);
  assert.equal((await f.conectar(null, 'x'.repeat(16385))).estado, 413);
  assert.equal((await f.conectar(null, '{')).estado, 400);
  assert.equal((await f.conectar(null, JSON.stringify({ ticket: await ticket(), url: 'https://atacante.example' }))).estado, 400);
  assert.equal(f.llamadas.length, 0);
});
test('También limita cuerpo sin content-length durante lectura del stream', async () => {
  const f = fixture();
  const req = new Request(`${URL_BASE}/functions/v1/myg-login`, { method: 'POST', duplex: 'half',
    headers: { 'Content-Type': 'application/json' }, body: new ReadableStream({ start(c) {
      c.enqueue(new TextEncoder().encode(' '.repeat(16385))); c.close();
    } }) });
  assert.equal((await f.handler(req)).status, 413); assert.equal(f.llamadas.length, 0);
});
for (const caso of [
  { rpc: [403, { message: 'MYG_VINCULO_NO_VERIFICADO' }], esperado: 403 },
  { eliminado: true, esperado: 403 }, { perfil: { banned_until: '2099-01-01T00:00:00Z' }, esperado: 403 },
  { idGet: ID_B, esperado: 403 }, { idGenerado: ID_B, esperado: 503 },
  { tipoGenerado: 'signup', esperado: 503 }, { idVerificado: ID_B, esperado: 503 },
  { eliminadoDuranteCanje: true, esperado: 503 }, { sesion: { refresh_token: '' }, esperado: 503 },
  { rpc: [500, { message: 'SECRETO interno de prueba' }], esperado: 503 },
]) {
  test(`Rechaza vínculo/Auth incoherente ${JSON.stringify(caso)}`, async () => {
    const f = fixture(caso); const r = await f.conectar(await ticket());
    assert.equal(r.estado, caso.esperado);
    assert.deepEqual(Object.keys(r.datos), ['error']);
    assert.ok(!JSON.stringify(r.datos).includes('SECRETO'));
    if (caso.idGet || caso.eliminado || caso.rpc) assert.ok(f.llamadas.length <= 2);
    if (caso.idGenerado || caso.tipoGenerado || caso.eliminadoDuranteCanje) assert.ok(f.llamadas.length <= 4);
  });
}
test('Fallos de red/redirección no filtran contenido interno', async () => {
  const f = fixture({ fetch: async (_url, init) => { assert.equal(init.redirect, 'error'); throw Error('secreto'); } });
  assert.deepEqual((await f.conectar(await ticket())).datos, { error: 'MYG_NUBE_NO_DISPONIBLE' });
});
test('Configuración requiere HTTPS fijo y secreto literal 64hex', async () => {
  for (const env of [{ SUPABASE_URL: 'https://prueba.example/ruta' }, { SUPABASE_URL: 'http://prueba.example' },
    { MYG_NUBE_HMAC: '' }, { MYG_NUBE_HMAC: 'corto' }]) {
    const f = fixture({ env }); assert.equal((await f.conectar(await ticket())).estado, 503);
    assert.equal(f.llamadas.length, 0);
  }
});
test('Métodos y tipo de contenido inesperados', async () => {
  const f = fixture();
  assert.equal((await f.handler(new Request(URL_BASE))).status, 405);
  assert.equal((await f.handler(new Request(URL_BASE, { method: 'POST', body: '{}' }))).status, 400);
});

const LICENCIA = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';
test('Octavo claim crea únicamente cuenta técnica UUID reservado y app_metadata del servidor', async () => {
  const f = fixture({ tecnica: true, licencia: LICENCIA });
  const r = await f.conectar(await ticket({ sub: 'persona-nueva', licencia_id: LICENCIA }));
  assert.equal(r.estado, 200); assert.equal(r.datos.user.id, ID_A);
  assert.equal(f.llamadas.filter(x => x.ruta === '/auth/v1/admin/users').length, 1);
  assert.equal(f.llamadas.filter(x => x.ruta === '/rest/v1/rpc/myg_nube_confirmar_ingreso').length, 1);
  assert.ok(!JSON.stringify(r.datos).includes('@myg.invalid'));
});
test('Carrera alta duplicada recupera solo UUID reservado con marca exacta', async () => {
  const f = fixture({ tecnica: true, licencia: LICENCIA, conflictoAlta: true });
  assert.equal((await f.conectar(await ticket({ sub: 'persona-nueva', licencia_id: LICENCIA }))).estado, 200);
  assert.ok(f.llamadas.every(x => x.ruta !== '/auth/v1/admin/users' || x.init.method === 'POST'));
});
test('Cuenta ajena/metadata usuario no permite apropiarse del alias reservado', async () => {
  const f = fixture({ tecnica: true, licencia: LICENCIA, conflictoAlta: true,
    perfil: { app_metadata: {}, user_metadata: { myg_nube_licencia_id: LICENCIA, myg_nube_origen: 'licencias_v1' } } });
  const r = await f.conectar(await ticket({ sub: 'persona-nueva', licencia_id: LICENCIA }));
  assert.equal(r.estado, 403); assert.equal(r.datos.error, 'MYG_IDENTIDAD_REQUIERE_REVISION');
  assert.equal(f.sesiones.length, 0);
});
test('Auth alta con otro UUID y revocación entre preparar/confirmar impiden sesión', async () => {
  for (const opciones of [{ idAlta: ID_B },
    { confirmacion: [403, { message: 'MYG_VINCULO_NO_VERIFICADO' }] },
    { confirmacion: [409, { message: 'MYG_LICENCIA_CONFLICTO' }] }]) {
    const f = fixture({ tecnica: true, licencia: LICENCIA, ...opciones });
    const r = await f.conectar(await ticket({ sub: 'persona-nueva', licencia_id: LICENCIA }));
    assert.ok([403,409].includes(r.estado)); assert.equal(f.sesiones.length, 0);
  }
});
test('Ticket licencia inválida y noveno claim no llaman al backend', async () => {
  for (const cambios of [{ licencia_id: 'no-uuid' }, { licencia_id: null },
    { licencia_id: LICENCIA.toUpperCase() }, { licencia_id: LICENCIA, correo: 'ajeno@example.com' }]) {
    const f = fixture(); assert.equal((await f.conectar(await ticket(cambios))).estado, 401);
    assert.equal(f.llamadas.length, 0);
  }
});
test('Falta migración004 bloquea también ticket antiguo antes de Auth', async () => {
  const f = fixture({ rpc: [404, { message: 'function missing' }] });
  assert.equal((await f.conectar(await ticket())).estado, 503);
  assert.equal(f.llamadas.length, 1); assert.equal(f.sesiones.length, 0);
});

test('Alta transitoria429/503 con UUID aún ausente conserva error temporal503', async () => {
  for (const estadoAlta of [429, 503]) {
    const f = fixture({ tecnica: true, licencia: LICENCIA, estadoAlta, eliminado: true });
    const r = await f.conectar(await ticket({ sub: 'persona-nueva', licencia_id: LICENCIA }));
    assert.equal(r.estado, 503); assert.equal(r.datos.error, 'MYG_NUBE_NO_DISPONIBLE');
    assert.equal(f.sesiones.length, 0);
  }
});
test('Conflicto alta400/409/422 con UUID ausente exige revisión de identidad', async () => {
  for (const estadoAlta of [400, 409, 422]) {
    const f = fixture({ tecnica: true, licencia: LICENCIA, estadoAlta, eliminado: true });
    const r = await f.conectar(await ticket({ sub: 'persona-nueva', licencia_id: LICENCIA }));
    assert.equal(r.estado, 403); assert.equal(r.datos.error, 'MYG_IDENTIDAD_REQUIERE_REVISION');
    assert.equal(f.sesiones.length, 0);
  }
});
