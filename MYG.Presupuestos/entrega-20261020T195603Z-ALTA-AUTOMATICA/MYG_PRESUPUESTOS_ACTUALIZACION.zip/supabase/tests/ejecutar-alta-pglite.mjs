// Base PostgreSQL en memoria, sin red/credenciales reales. PGlite 0.3.14.
import { PGlite } from '@electric-sql/pglite';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const raiz = resolve(process.argv[2] || process.cwd());
const db = new PGlite();
try {
  await db.exec(`create role anon;create role authenticated;create role service_role bypassrls;
    create schema auth;create table auth.users(id uuid primary key,email text,
    raw_app_meta_data jsonb not null default '{}',banned_until timestamptz,deleted_at timestamptz);
    create function auth.uid() returns uuid language sql stable as $$
      select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
    grant usage on schema auth to anon,authenticated,service_role;
    grant execute on function auth.uid() to anon,authenticated,service_role;`);
  for (const archivo of ['202610190001_nube_myg.sql','202610200003_ingreso_myg.sql']) {
    await db.exec(await readFile(resolve(raiz, 'supabase/migrations', archivo), 'utf8'));
  }
  await db.exec(`insert into auth.users(id,email) values('11111111-1111-4111-8111-111111111111','existente@example.invalid');
    insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion)
      values('11111111-1111-4111-8111-111111111111','USUARIO_EXACTO_EN_MYG','Fixture existente comprobado');
    select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);
    select public.myg_nube_crear('99999999-9999-4999-8999-999999999999','Presupuesto previo','{"alcance":"obra"}','obra');`);
  const migracion = await readFile(resolve(raiz, 'supabase/migrations/202610200004_alta_automatica_licencias.sql'), 'utf8');
  let bloqueo = false;
  try { await db.exec(migracion); }
  catch (e) { bloqueo = e.message.includes('MYG_IDENTIDAD_REQUIERE_REVISION'); await db.exec('rollback'); }
  if (!bloqueo) throw new Error('No se bloqueó placeholder previo.');
  const previo = await db.query(`select (select count(*) from public.myg_nube_proyectos)::int as proyectos,
    to_regclass('myg_nube_privado.licencias_nube') as nueva,
    (select usuario_myg from myg_nube_privado.identidades_verificadas limit 1) as usuario`);
  if (previo.rows[0].proyectos !== 1 || previo.rows[0].nueva !== null || previo.rows[0].usuario !== 'USUARIO_EXACTO_EN_MYG') {
    throw new Error('El preflight fallido modificó datos existentes.');
  }
  // Corrección explícita solo de esta fixture; conserva UUID y presupuesto previos.
  await db.exec("update myg_nube_privado.identidades_verificadas set usuario_myg='c'");
  await db.exec(migracion);
  const resultados = await db.exec(await readFile(resolve(raiz, 'supabase/tests/alta_licencias_regresion.sql'), 'utf8'));
  if (!resultados.some(r => r.rows?.some(f => f.resultado === 'PRUEBA_ALTA_LICENCIAS_CORRECTA'))) throw new Error('Falta confirmación de autoalta.');
  const final = await db.query(`select (select count(*) from public.myg_nube_proyectos)::int as proyectos,
    (select count(*) from public.myg_nube_miembros)::int as miembros,
    (select count(*) from auth.users)::int as usuarios,
    (select count(*) from myg_nube_privado.licencias_nube)::int as licencias,
    (select count(*) from myg_nube_privado.ingresos_consumidos)::int as nonces`);
  if (JSON.stringify(final.rows[0]) !== JSON.stringify({ proyectos: 1, miembros: 1, usuarios: 1, licencias: 0, nonces: 0 })) {
    throw new Error('La regresión no restauró el estado previo.');
  }
  console.log('PRUEBA_ALTA_LICENCIAS_CORRECTA; PLACEHOLDER_BLOQUEADO_SIN_CAMBIOS; ROLLBACK_CORRECTO');
} catch (e) { console.error(e.message,e.code || '',e.where || '');process.exitCode=1; }
finally { await db.close(); }
