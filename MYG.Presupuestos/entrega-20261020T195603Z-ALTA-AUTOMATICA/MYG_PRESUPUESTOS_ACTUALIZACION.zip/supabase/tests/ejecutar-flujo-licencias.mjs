// Integración local: Apps Script real -> ticket HMAC -> Edge real -> PostgreSQL real.
// Auth HTTP y Sheets son simulados. No acepta claves ni conexiones de producción.
// Copiar junto a @electric-sql/pglite@0.3.14; requiere Node 24 y recibe raíz del repo.
import assert from 'node:assert/strict';
import { createHash, createHmac, randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import vm from 'node:vm';
import { PGlite } from '@electric-sql/pglite';

const raiz = resolve(process.argv[2] || process.cwd());
const { crearHandler } = await import(pathToFileURL(resolve(raiz, 'supabase/functions/myg-login/handler.ts')));
const url = 'https://integracion-myg.supabase.co';
const secreto = 'e7'.repeat(32); // Fixture sintético público; nunca desplegar este valor.
const propietario = '11111111-1111-4111-8111-111111111111';
const proyecto = '22222222-2222-4222-8222-222222222222';
const filas = [
  ['USUARIO','CLAVE','MACHINE_ID','EXPIRA','ACTIVO','NOMBRE','ULTIMO LOGIN','ING. AUTOM.','TOKEN_HASH','PAGOS_APLICADOS'],
  ['propietario','clave-a','PC-A',new Date(Date.now()+86400000),'SI','Propietario','','NO','','[]'],
  ['editor','clave-b','PC-B',new Date(Date.now()+86400000),'SI','Editor','','NO','','[]'],
];
const originales = structuredClone(filas);
let capacidad = 26;
const hoja = {
  getLastColumn: () => Math.max(...filas.map(f => f.length)),
  getMaxColumns: () => capacidad,
  insertColumnsAfter: (_, cantidad) => { capacidad += cantidad; },
  getDataRange: () => ({ getValues: () => structuredClone(filas) }),
  getRange: (fila, columna, alto = 1, ancho = 1) => ({
    getValues: () => Array.from({length:alto}, (_, i) => Array.from({length:ancho}, (_, j) => filas[fila-1+i]?.[columna-1+j] ?? '')),
    setValue: valor => { filas[fila-1][columna-1] = valor; },
  }),
};
const propiedades = { MYG_NUBE_URL:url, MYG_NUBE_HMAC:secreto };
const contexto = vm.createContext({
  console: { log() {} },
  ContentService: { MimeType:{JSON:'application/json'}, createTextOutput: content => ({
    content, setMimeType() { return this; },
  }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: nombre => propiedades[nombre] ?? null }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  SpreadsheetApp: { getActiveSpreadsheet: () => ({ getSheetByName: nombre => nombre === 'LICENCIAS' ? hoja : null }), flush() {} },
  Utilities: {
    DigestAlgorithm:{SHA_256:'sha256'}, Charset:{UTF_8:'utf8'}, getUuid:randomUUID,
    computeDigest: (_, valor) => [...createHash('sha256').update(valor).digest()],
    computeHmacSha256Signature: (valor, clave) => [...createHmac('sha256', clave).update(valor).digest()],
    base64EncodeWebSafe: valor => (typeof valor === 'string' ? Buffer.from(valor) : Buffer.from(valor.map(n => (n+256)%256))).toString('base64url'),
  },
});
vm.runInContext(await readFile(resolve(raiz, 'integraciones/apps-script/Codigo.gs'), 'utf8'), contexto);
function ticket(usuario, clave, pc) {
  const salida = JSON.parse(contexto.doPost({parameter:{accion:'nube_ticket',usuario,clave,pc,audiencia:url}}).content);
  assert.equal(salida.ok, true, `Apps Script rechazó fixture: ${salida.codigo}`);
  return salida.ticket;
}
const db = new PGlite();
let altas = 0, sesiones = 0;
const perfiles = new Map();
const hashes = new Map();
const respuesta = (status, datos) => new Response(JSON.stringify(datos), {status,headers:{'content-type':'application/json'}});
async function enviar(destino, solicitud) {
  assert.equal(new URL(destino).origin, url);
  assert.equal(solicitud.redirect, 'error');
  const ruta = new URL(destino).pathname;
  const cuerpo = solicitud.body ? JSON.parse(solicitud.body) : undefined;
  if (ruta.startsWith('/rest/v1/rpc/')) {
    const nombre = ruta.split('/').at(-1);
    const parametros = {
      myg_nube_preparar_ingreso:['p_usuario','p_licencia_id','p_nonce','p_emitido','p_expira','p_pc'],
      myg_nube_confirmar_ingreso:['p_nonce'],
    }[nombre];
    assert.ok(parametros, `RPC inesperada: ${nombre}`);
    await db.exec('set role service_role');
    try {
      const sql = `select public.${nombre}(${parametros.map((_,i) => '$'+(i+1)).join(',')}) as salida`;
      const resultado = await db.query(sql, parametros.map(p => cuerpo[p] ?? null));
      return respuesta(200, resultado.rows[0].salida);
    } catch (error) { return respuesta(400, {message:error.message,code:error.code}); }
    finally { await db.exec('reset role'); }
  }
  if (ruta === '/auth/v1/admin/users' && solicitud.method === 'POST') {
    assert.ok(cuerpo.id && cuerpo.email_confirm && cuerpo.app_metadata?.myg_nube_licencia_id);
    assert.ok(!('password' in cuerpo), 'No distribuir otra contraseña');
    if (perfiles.has(cuerpo.id)) return respuesta(422,{message:'User already exists'});
    const perfil = {id:cuerpo.id,email:cuerpo.email,app_metadata:cuerpo.app_metadata};
    await db.query('insert into auth.users(id,email,raw_app_meta_data) values($1,$2,$3)', [perfil.id,perfil.email,perfil.app_metadata]);
    perfiles.set(perfil.id, perfil); altas++;
    return respuesta(200, perfil);
  }
  if (ruta.startsWith('/auth/v1/admin/users/')) {
    const perfil = perfiles.get(ruta.split('/').at(-1));
    return perfil ? respuesta(200,perfil) : respuesta(404,{message:'No user'});
  }
  if (ruta === '/auth/v1/admin/generate_link') {
    assert.equal(cuerpo.type,'recovery');
    const perfil = [...perfiles.values()].find(p => p.email === cuerpo.email);
    assert.ok(perfil, 'No debe generarse enlace para cuenta inexistente');
    const hash = randomUUID(); hashes.set(hash,perfil.id);
    return respuesta(200,{...perfil,hashed_token:hash,verification_type:'recovery'});
  }
  if (ruta === '/auth/v1/verify') {
    assert.equal(cuerpo.type,'recovery');
    const id = hashes.get(cuerpo.token_hash); assert.ok(id); hashes.delete(cuerpo.token_hash); sesiones++;
    return respuesta(200,{access_token:'acceso-'+id,refresh_token:'refresco-'+id,expires_in:3600,user:{id}});
  }
  throw new Error(`HTTP inesperado: ${ruta}`);
}
async function comoUsuario(id, sql, valores = []) {
  await db.exec('set role authenticated');
  try { await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]); return await db.query(sql,valores); }
  finally { await db.exec('reset role'); }
}
try {
  await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
    create schema auth;
    create table auth.users(id uuid primary key,email text,raw_app_meta_data jsonb not null default '{}',banned_until timestamptz,deleted_at timestamptz);
    create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
    grant usage on schema auth to anon,authenticated,service_role;
    grant execute on function auth.uid() to anon,authenticated,service_role;`);
  for (const nombre of ['202610190001_nube_myg.sql','202610200003_ingreso_myg.sql','202610200004_alta_automatica_licencias.sql']) {
    await db.exec(await readFile(resolve(raiz,'supabase/migrations',nombre),'utf8'));
  }
  const perfil = {id:propietario,email:'propietario@fixture.example',app_metadata:{}};
  perfiles.set(propietario,perfil);
  await db.query('insert into auth.users(id,email) values($1,$2)',[propietario,perfil.email]);
  await db.query(`insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion) values($1,'propietario','Fixture administrativo')`,[propietario]);
  await comoUsuario(propietario,'select public.myg_nube_crear($1,$2,$3,$4)',[proyecto,'Presupuesto existente',{prueba:1},'obra']);
  const handler = crearHandler({env:nombre => ({SUPABASE_URL:url,SUPABASE_ANON_KEY:'anon-ficticia',SUPABASE_SERVICE_ROLE_KEY:'servicio-ficticio',MYG_NUBE_HMAC:secreto})[nombre],fetch:enviar});
  const canjear = credencial => handler(new Request(url+'/functions/v1/myg-login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({ticket:credencial})}));
  let respuestaIngreso = await canjear(ticket('propietario','clave-a','PC-A'));
  assert.equal(respuestaIngreso.status,200,await respuestaIngreso.clone().text());
  assert.equal((await respuestaIngreso.json()).user.id,propietario);
  assert.equal(altas,0,'No duplicar propietario existente');
  const credencialEditor = ticket('editor','clave-b','PC-B');
  respuestaIngreso = await canjear(credencialEditor);
  assert.equal(respuestaIngreso.status,200,await respuestaIngreso.clone().text());
  const editor = (await respuestaIngreso.json()).user.id;
  assert.notEqual(editor,propietario); assert.equal(altas,1);
  assert.equal((await db.query('select count(*)::int as n from public.myg_nube_miembros where usuario_id=$1',[editor])).rows[0].n,0,'Alta no concede presupuestos');
  assert.equal((await canjear(credencialEditor)).status,409,'No aceptar replay');
  respuestaIngreso = await canjear(ticket('editor','clave-b','PC-B'));
  assert.equal(respuestaIngreso.status,200,await respuestaIngreso.clone().text());
  assert.equal((await respuestaIngreso.json()).user.id,editor); assert.equal(altas,1,'Reingreso no duplica cuentas');
  await comoUsuario(editor,"select public.myg_nube_solicitar($1)",['MYG-'+proyecto.replaceAll('-','').toUpperCase()]);
  await comoUsuario(propietario,'select public.myg_nube_resolver($1,$2,$3,$4)',[proyecto,editor,'editor',true]);
  const roles = await db.query('select usuario_id,rol from public.myg_nube_miembros where proyecto_id=$1 order by rol',[proyecto]);
  assert.equal(roles.rows.length,2); assert.ok(roles.rows.some(f => f.usuario_id===propietario && f.rol==='propietario'));
  assert.ok(roles.rows.some(f => f.usuario_id===editor && f.rol==='editor'));
  await db.query('update myg_nube_privado.identidades_verificadas set activo=false where auth_usuario_id=$1',[editor]);
  respuestaIngreso = await canjear(ticket('editor','clave-b','PC-B'));
  assert.equal(respuestaIngreso.status,403); assert.equal(altas,1,'No recrear cuenta revocada');
  assert.equal((await db.query('select activo from myg_nube_privado.identidades_verificadas where auth_usuario_id=$1',[editor])).rows[0].activo,false);
  filas[2][4]='NO';
  assert.equal(JSON.parse(contexto.doPost({parameter:{accion:'nube_ticket',usuario:'editor',clave:'clave-b',pc:'PC-B',audiencia:url}}).content).ok,false,'Licencia bloqueada no emite ticket');
  for (let i=0;i<filas.length;i++) {
    const esperada=structuredClone(originales[i]); if(i===2) esperada[4]='NO';
    assert.deepEqual(filas[i].slice(0,10),esperada,'Preservar columnas originales A:J');
  }
  assert.equal(filas[0][10],'ID_MYG_NUBE'); assert.notEqual(filas[1][10],filas[2][10]);
  console.log(`FLUJO_LICENCIAS_INTEGRADO_CORRECTO; ${altas} alta técnica, ${sesiones} sesiones; propietario/roles conservados, replay y revocación rechazados`);
} catch (error) { console.error(error.message,error.code||''); process.exitCode=1; }
finally { await db.close(); }
