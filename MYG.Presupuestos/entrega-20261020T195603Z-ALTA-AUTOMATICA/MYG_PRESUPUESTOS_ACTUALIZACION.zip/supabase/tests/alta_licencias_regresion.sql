-- Fixture local. Conserva la cuenta y presupuesto previos del ejecutor; ROLLBACK final.
begin;
do $$
declare
    v_now bigint:=floor(extract(epoch from clock_timestamp()))::bigint;
    v_c uuid:='cccccccc-cccc-4ccc-8ccc-cccccccccccc';
    v_e uuid:='eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
    v_otro uuid:='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
    v_owner uuid:='11111111-1111-4111-8111-111111111111';
    v_pre jsonb; v_pre2 jsonb; v_id uuid; v_nonce uuid; v_res jsonb;
    v_n integer:=100;
begin
    if has_function_privilege('anon','public.myg_nube_preparar_ingreso(text,uuid,uuid,bigint,bigint,text)','execute')
       or has_function_privilege('authenticated','public.myg_nube_confirmar_ingreso(uuid)','execute')
       or has_table_privilege('service_role','myg_nube_privado.licencias_nube','insert') then
        raise exception 'Privilegios de autoalta incorrectos.';
    end if;
    -- Legacy sin ID solo funciona antes de asociar la identidad a una licencia.
    v_pre:=public.myg_nube_preparar_ingreso('c',null,'00000000-0000-4000-8000-000000000030',v_now,v_now+60,repeat('A',64));
    if v_pre->>'usuario_id'<>v_owner::text or (v_pre->>'crear_usuario')::boolean then raise exception 'Legacy cambió identidad.'; end if;
    perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000030');
    perform public.myg_nube_preparar_ingreso('c',null,'00000000-0000-4000-8000-000000000031',v_now,v_now+60,repeat('A',64));
    -- Adopta un vínculo previo comprobado, preservando su UUID y presupuesto.
    v_pre:=public.myg_nube_preparar_ingreso('c',v_c,'00000000-0000-4000-8000-000000000001',v_now,v_now+60,repeat('A',64));
    if v_pre->>'usuario_id'<>v_owner::text or (v_pre->>'crear_usuario')::boolean
       or v_pre->>'origen'<>'existente' then raise exception 'Se sustituyó el propietario previo.'; end if;
    perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000001');
    if not exists(select 1 from public.myg_nube_miembros where usuario_id=v_owner and rol='propietario') then
        raise exception 'Se perdieron roles del propietario.';
    end if;
    -- Una licencia nueva reserva exactamente un UUID aunque dos tickets lleguen juntos.
    v_pre:=public.myg_nube_preparar_ingreso('editor',v_e,'00000000-0000-4000-8000-000000000002',v_now,v_now+60,repeat('B',64));
    v_pre2:=public.myg_nube_preparar_ingreso('editor',v_e,'00000000-0000-4000-8000-000000000003',v_now,v_now+60,repeat('B',64));
    v_id:=(v_pre->>'usuario_id')::uuid;
    if v_pre->>'usuario_id'<>v_pre2->>'usuario_id' or not(v_pre->>'crear_usuario')::boolean
       or v_pre->>'alias'<>'licencia'||v_e::text||'@myg.invalid' then raise exception 'Reserva no idempotente.'; end if;
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000002');
        raise exception 'Se confirmó sin cuenta Auth.';
    exception when insufficient_privilege then
        if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
    end;
    -- Simula creación Auth administrativa; user_metadata no acredita esta identidad.
    insert into auth.users(id,email,raw_app_meta_data) values(v_id,v_pre->>'alias','{}');
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000002');
        raise exception 'Se adoptó cuenta sin marca administrativa.';
    exception when insufficient_privilege then
        if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
    end;
    update auth.users set raw_app_meta_data=jsonb_build_object('myg_nube_licencia_id',v_e,'myg_nube_origen','licencias_v1') where id=v_id;
    v_res:=public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000002');
    perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000003');
    perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000002');
    if v_res->>'usuario_id'<>v_id::text or not exists(select 1 from myg_nube_privado.identidades_verificadas where auth_usuario_id=v_id and activo)
       or exists(select 1 from public.myg_nube_miembros where usuario_id=v_id) then
        raise exception 'Autoalta incorrecta o concedió roles.';
    end if;
    -- Un nonce consumido por 003 tampoco puede pasar por 004.
    perform public.myg_nube_canjear_ingreso('editor','00000000-0000-4000-8000-000000000004',v_now,v_now+60,repeat('B',64));
    begin
        perform public.myg_nube_preparar_ingreso('editor',v_e,'00000000-0000-4000-8000-000000000004',v_now,v_now+60,repeat('B',64));
        raise exception 'Replay cruzó 003/004.';
    exception when unique_violation then if sqlerrm<>'MYG_INGRESO_REUTILIZADO' then raise; end if;
    end;
    -- Un segundo ID no se apropia del mismo usuario ni del vínculo previo.
    begin
        perform public.myg_nube_preparar_ingreso('editor',v_otro,'00000000-0000-4000-8000-000000000005',v_now,v_now+60,repeat('B',64));
        raise exception 'Otra licencia adoptó el usuario.';
    exception when unique_violation then if sqlerrm<>'MYG_LICENCIA_CONFLICTO' then raise; end if;
    end;
    -- Renombrar conserva UUID; una confirmación previa a otro renombre no es válida.
    v_pre:=public.myg_nube_preparar_ingreso('editor-nuevo',v_e,'00000000-0000-4000-8000-000000000006',v_now+1,v_now+61,repeat('B',64));
    perform public.myg_nube_preparar_ingreso('editor-final',v_e,'00000000-0000-4000-8000-000000000007',v_now+2,v_now+62,repeat('B',64));
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000006');
        raise exception 'Se confirmó nombre ya sustituido.';
    exception when unique_violation then if sqlerrm<>'MYG_LICENCIA_CONFLICTO' then raise; end if;
    end;
    perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000007');
    if v_pre->>'usuario_id'<>v_id::text or not exists(select 1 from myg_nube_privado.identidades_verificadas where auth_usuario_id=v_id and usuario_myg='editor-final') then
        raise exception 'El renombre cambió UUID.';
    end if;
    begin
        perform public.myg_nube_preparar_ingreso('editor',v_e,'00000000-0000-4000-8000-000000000008',v_now,v_now+60,repeat('B',64));
        raise exception 'Ticket viejo revirtió renombre.';
    exception when unique_violation then if sqlerrm<>'MYG_LICENCIA_CONFLICTO' then raise; end if;
    end;
    begin
        perform public.myg_nube_preparar_ingreso('c',v_e,'00000000-0000-4000-8000-000000000009',v_now+3,v_now+63,repeat('B',64));
        raise exception 'Renombre apropió usuario del propietario.';
    exception when unique_violation then if sqlerrm<>'MYG_LICENCIA_CONFLICTO' then raise; end if;
    end;
    -- Revocar entre preparar y confirmar nunca reactiva una identidad.
    perform public.myg_nube_preparar_ingreso('editor-final',v_e,'00000000-0000-4000-8000-000000000010',v_now+2,v_now+62,repeat('B',64));
    update myg_nube_privado.identidades_verificadas set activo=false where auth_usuario_id=v_id;
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000010');
        raise exception 'Confirmación reactivó vínculo.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_VINCULO_NO_VERIFICADO' then raise; end if;
    end;
    begin
        perform public.myg_nube_preparar_ingreso('editor-final',v_e,'00000000-0000-4000-8000-000000000011',v_now+2,v_now+62,repeat('B',64));
        raise exception 'Preparar reactivó vínculo.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_VINCULO_NO_VERIFICADO' then raise; end if;
    end;
    -- Borrar el vínculo confirmado tampoco autoriza recrearlo.
    delete from myg_nube_privado.identidades_verificadas where auth_usuario_id=v_id;
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000010');
        raise exception 'Confirmar recreó vínculo borrado.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
    end;
    begin
        perform public.myg_nube_preparar_ingreso('editor-final',v_e,'00000000-0000-4000-8000-000000000012',v_now+2,v_now+62,repeat('B',64));
        raise exception 'Preparar recreó vínculo borrado.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
    end;
    if exists(select 1 from myg_nube_privado.identidades_verificadas where auth_usuario_id=v_id) then raise exception 'Se recreó identidad.'; end if;
    -- Reserva pendiente bloqueada durante llamada Auth no se confirma ni crea vínculo.
    v_pre:=public.myg_nube_preparar_ingreso('pendiente',v_otro,'00000000-0000-4000-8000-000000000013',v_now,v_now+60,repeat('C',64));
    update myg_nube_privado.licencias_nube set bloqueada=true where licencia_id=v_otro;
    insert into auth.users(id,email,raw_app_meta_data) values((v_pre->>'usuario_id')::uuid,v_pre->>'alias',
        jsonb_build_object('myg_nube_licencia_id',v_otro,'myg_nube_origen','licencias_v1'));
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000013');
        raise exception 'Se confirmó reserva bloqueada.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_VINCULO_NO_VERIFICADO' then raise; end if;
    end;
    if exists(select 1 from myg_nube_privado.identidades_verificadas where usuario_myg='pendiente') then raise exception 'Se creó vínculo bloqueado.'; end if;
    -- Cuenta Auth pendiente borrada/borrada lógicamente no puede recrearse.
    for v_n in 20..21 loop
        v_otro:=case when v_n=20 then 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1'::uuid else 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2'::uuid end;
        v_nonce:=case when v_n=20 then '00000000-0000-4000-8000-000000000020'::uuid else '00000000-0000-4000-8000-000000000021'::uuid end;
        v_pre:=public.myg_nube_preparar_ingreso('eliminado-'||v_n,v_otro,v_nonce,v_now,v_now+60,repeat('D',64));
        insert into auth.users(id,email,raw_app_meta_data) values((v_pre->>'usuario_id')::uuid,v_pre->>'alias',
            jsonb_build_object('myg_nube_licencia_id',v_otro,'myg_nube_origen','licencias_v1'));
        update auth.users set banned_until=clock_timestamp()+interval '1 day' where id=(v_pre->>'usuario_id')::uuid;
        begin
            perform public.myg_nube_confirmar_ingreso(v_nonce);
            raise exception 'Se confirmó Auth suspendido.';
        exception when insufficient_privilege then if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
        end;
        if v_n=20 then
            delete from auth.users where id=(v_pre->>'usuario_id')::uuid;
        else
            update auth.users set deleted_at=clock_timestamp() where id=(v_pre->>'usuario_id')::uuid;
        end if;
        if not exists(select 1 from myg_nube_privado.licencias_nube where licencia_id=v_otro and bloqueada)
           or not exists(select 1 from myg_nube_privado.ingresos_consumidos where nonce=v_nonce) then
            raise exception 'Auth eliminado no bloqueó reserva o borró nonce.';
        end if;
        begin
            perform public.myg_nube_confirmar_ingreso(v_nonce);
            raise exception 'Se confirmó Auth eliminado.';
        exception when insufficient_privilege then if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
        end;
        begin
            perform public.myg_nube_preparar_ingreso('eliminado-'||v_n,v_otro,
                case when v_n=20 then '00000000-0000-4000-8000-000000000022'::uuid else '00000000-0000-4000-8000-000000000023'::uuid end,
                v_now,v_now+60,repeat('D',64));
            raise exception 'Se autorizó recrear Auth eliminado.';
        exception when insufficient_privilege then if sqlerrm<>'MYG_VINCULO_NO_VERIFICADO' then raise; end if;
        end;
    end loop;
    if has_function_privilege('anon','myg_nube_privado.bloquear_auth_eliminado()','execute')
       or has_function_privilege('authenticated','myg_nube_privado.bloquear_auth_eliminado()','execute')
       or has_function_privilege('service_role','myg_nube_privado.bloquear_auth_eliminado()','execute') then
        raise exception 'Se expuso el trigger privado.';
    end if;
    -- Después de adoptar ID estable, siete claims no pueden eludir esa identidad.
    begin
        perform public.myg_nube_preparar_ingreso('c',null,'00000000-0000-4000-8000-000000000014',v_now,v_now+60,repeat('A',64));
        raise exception 'Legacy ignoró ID de licencia ya asociado.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
    end;
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000031');
        raise exception 'Legacy preparado antes de adopción eludió licencia.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_IDENTIDAD_REQUIERE_REVISION' then raise; end if;
    end;
    begin
        perform public.myg_nube_preparar_ingreso('sin-licencia',null,'00000000-0000-4000-8000-000000000015',v_now,v_now+60,repeat('A',64));
        raise exception 'Legacy autorizó autoalta.';
    exception when insufficient_privilege then if sqlerrm<>'MYG_VINCULO_NO_VERIFICADO' then raise; end if;
    end;
    if (select count(*) from public.myg_nube_proyectos)<>1
       or (select count(*) from public.myg_nube_miembros)<>1
       or not exists(select 1 from public.myg_nube_miembros where usuario_id=v_owner and rol='propietario') then
        raise exception 'La autoalta cambió proyectos/roles.';
    end if;
end;
$$;
-- Privilegios efectivos fuera del rol administrador de la fixture.
set local role anon;
do $$
begin
    begin
        perform public.myg_nube_preparar_ingreso('c',null,'00000000-0000-4000-8000-000000000016',1,61,repeat('A',64));
        raise exception 'anon invocó autoalta.';
    exception when insufficient_privilege then null; end;
end;
$$;
set local role authenticated;
do $$
begin
    begin
        perform public.myg_nube_confirmar_ingreso('00000000-0000-4000-8000-000000000001');
        raise exception 'authenticated confirmó autoalta.';
    exception when insufficient_privilege then null; end;
end;
$$;
reset role;
select 'PRUEBA_ALTA_LICENCIAS_CORRECTA' as resultado;
rollback;
