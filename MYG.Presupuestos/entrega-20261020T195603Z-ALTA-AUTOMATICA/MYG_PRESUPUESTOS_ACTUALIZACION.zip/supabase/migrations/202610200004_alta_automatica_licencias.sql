-- Autoalta administrativa desde una licencia MYG firmada con ID estable.
-- Requiere 001 y 003. No modifica sus archivos ni roles/datos de proyectos.
begin;
set local lock_timeout = '5s';
do $$
begin
    if to_regclass('myg_nube_privado.ingresos_consumidos') is null
       or to_regprocedure('public.myg_nube_canjear_ingreso(text,uuid,bigint,bigint,text)') is null then
        raise exception 'Falta ingreso MYG 003; no se cambió ningún dato.';
    end if;
    if exists(select 1 from myg_nube_privado.identidades_verificadas
        where lower(btrim(usuario_myg)) ~ '^(usuario_exacto|usuario_myg_real|tu_usuario_myg|reemplazar_usuario)') then
        raise exception 'MYG_IDENTIDAD_REQUIERE_REVISION: hay nombres de ejemplo en identidades_verificadas. Corrija su usuario real conservando auth_usuario_id y roles antes de instalar 004.';
    end if;
    if to_regclass('myg_nube_privado.licencias_nube') is not null
       or to_regclass('myg_nube_privado.canjes_licencia') is not null then
        raise exception 'La autoalta MYG 004 ya existe; revise el historial de migraciones.';
    end if;
end;
$$;
create table myg_nube_privado.licencias_nube (
    licencia_id uuid primary key check(licencia_id <> '00000000-0000-0000-0000-000000000000'::uuid),
    auth_usuario_id uuid not null unique,
    usuario_myg text not null unique check(length(usuario_myg) between 1 and 256 and usuario_myg=lower(btrim(usuario_myg))),
    origen text not null check(origen in ('existente','tecnica')),
    confirmado boolean not null default false,
    bloqueada boolean not null default false,
    version bigint not null default 1 check(version > 0),
    ultimo_emitido bigint not null,
    creado_en timestamptz not null default clock_timestamp()
);
-- Sin FK a auth.users: conserva la reserva si se borra/revoca una cuenta y evita recrearla.
create table myg_nube_privado.canjes_licencia (
    nonce uuid primary key,
    licencia_id uuid references myg_nube_privado.licencias_nube(licencia_id),
    auth_usuario_id uuid not null,
    usuario_myg text not null,
    version bigint,
    expira bigint not null,
    confirmado boolean not null default false
);
create index canjes_licencia_expira on myg_nube_privado.canjes_licencia(expira);
alter table myg_nube_privado.licencias_nube enable row level security;
alter table myg_nube_privado.canjes_licencia enable row level security;
revoke all on myg_nube_privado.licencias_nube,myg_nube_privado.canjes_licencia from public,anon,authenticated,service_role;

-- Si Auth desaparece antes de confirmar una primera alta, no autorizar recrearla.
-- El trigger afecta únicamente la reserva de ese UUID; no toma el bloqueo global.
create function myg_nube_privado.bloquear_auth_eliminado() returns trigger
language plpgsql security definer set search_path=pg_catalog,myg_nube_privado as $$
begin
    if tg_op='DELETE' then
        update myg_nube_privado.licencias_nube set bloqueada=true where auth_usuario_id=old.id;
        return old;
    end if;
    if new.deleted_at is not null then
        update myg_nube_privado.licencias_nube set bloqueada=true where auth_usuario_id=new.id;
    end if;
    return new;
end;
$$;
revoke all on function myg_nube_privado.bloquear_auth_eliminado() from public,anon,authenticated,service_role;
create trigger myg_nube_auth_eliminado after delete on auth.users
    for each row execute function myg_nube_privado.bloquear_auth_eliminado();
create trigger myg_nube_auth_borrado_logico after update of deleted_at on auth.users
    for each row execute function myg_nube_privado.bloquear_auth_eliminado();

create function public.myg_nube_preparar_ingreso(
    p_usuario text,p_licencia_id uuid,p_nonce uuid,p_emitido bigint,p_expira bigint,p_pc text
) returns jsonb
language plpgsql security definer set search_path=pg_catalog,myg_nube_privado as $$
declare
    v_ahora bigint := floor(extract(epoch from clock_timestamp()))::bigint;
    v_l myg_nube_privado.licencias_nube%rowtype;
    v_i myg_nube_privado.identidades_verificadas%rowtype;
    v_id uuid; v_origen text := 'existente'; v_crear boolean := false; v_version bigint;
    v_lock_id uuid; v_habia_reserva boolean:=false; v_exige_auth boolean:=false;
begin
    if p_usuario is null or length(p_usuario) not between 1 and 256
       or p_usuario<>lower(btrim(p_usuario)) or p_usuario~'[[:cntrl:]]'
       or p_nonce is null or p_nonce='00000000-0000-0000-0000-000000000000'::uuid
       or p_licencia_id='00000000-0000-0000-0000-000000000000'::uuid
       or p_pc is null or p_pc!~'^[0-9A-F]{64}$'
       or p_emitido is null or p_expira is null or p_emitido<1 or p_expira<=p_emitido
       or p_expira::numeric-p_emitido::numeric>90 or p_emitido>v_ahora+30 then
        raise exception using errcode='22023',message='MYG_INGRESO_INVALIDO';
    end if;
    if p_expira<v_ahora-30 then
        raise exception using errcode='28000',message='MYG_INGRESO_EXPIRADO';
    end if;
    -- Serializa únicamente operaciones administrativas cortas; ninguna llamada HTTP
    -- ocurre mientras está tomado este bloqueo.
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-alta-licencias',0));
    -- Orden U -> L -> I, igual que DELETE Auth y su cascade/trigger. Esta lectura
    -- inicial no bloquea filas; luego las ramas revalidan los UUID bajo sus locks.
    if p_licencia_id is not null then
        select auth_usuario_id,confirmado into v_lock_id,v_exige_auth
          from myg_nube_privado.licencias_nube where licencia_id=p_licencia_id;
        v_habia_reserva:=found;
    end if;
    if not v_habia_reserva then
        select auth_usuario_id into v_lock_id from myg_nube_privado.identidades_verificadas
          where lower(btrim(usuario_myg))=p_usuario;
        v_exige_auth:=found;
    end if;
    if v_lock_id is not null then
        perform id from auth.users where id=v_lock_id for share;
        if not found and v_exige_auth then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
    end if;
    if p_licencia_id is null then
        -- Compatibilidad: siete claims no autorizan crear ni asociar una licencia.
        select * into v_i from myg_nube_privado.identidades_verificadas
          where lower(btrim(usuario_myg))=p_usuario for update;
        if v_i.auth_usuario_id is null or not v_i.activo
           or not exists(select 1 from auth.users where id=v_i.auth_usuario_id) then
            raise exception using errcode='42501',message='MYG_VINCULO_NO_VERIFICADO';
        end if;
        if v_i.auth_usuario_id is distinct from v_lock_id then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
        if exists(select 1 from myg_nube_privado.licencias_nube where auth_usuario_id=v_i.auth_usuario_id) then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
        v_id:=v_i.auth_usuario_id;
    else
        select * into v_l from myg_nube_privado.licencias_nube where licencia_id=p_licencia_id for update;
        if not found then
            if v_habia_reserva then
                raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
            end if;
            select * into v_i from myg_nube_privado.identidades_verificadas
              where lower(btrim(usuario_myg))=p_usuario for update;
            if found then
                if v_i.auth_usuario_id is distinct from v_lock_id then
                    raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
                end if;
                if not v_i.activo then
                    raise exception using errcode='42501',message='MYG_VINCULO_NO_VERIFICADO';
                end if;
                if exists(select 1 from myg_nube_privado.licencias_nube where auth_usuario_id=v_i.auth_usuario_id) then
                    raise exception using errcode='23505',message='MYG_LICENCIA_CONFLICTO';
                end if;
                v_id:=v_i.auth_usuario_id;
                insert into myg_nube_privado.licencias_nube(licencia_id,auth_usuario_id,usuario_myg,origen,confirmado,ultimo_emitido)
                  values(p_licencia_id,v_id,p_usuario,'existente',true,p_emitido) returning * into v_l;
            else
                if exists(select 1 from myg_nube_privado.licencias_nube where usuario_myg=p_usuario) then
                    raise exception using errcode='23505',message='MYG_LICENCIA_CONFLICTO';
                end if;
                v_id:=gen_random_uuid();
                insert into myg_nube_privado.licencias_nube(licencia_id,auth_usuario_id,usuario_myg,origen,ultimo_emitido)
                  values(p_licencia_id,v_id,p_usuario,'tecnica',p_emitido) returning * into v_l;
            end if;
        end if;
        if v_habia_reserva and v_l.auth_usuario_id is distinct from v_lock_id then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
        if v_l.bloqueada then
            raise exception using errcode='42501',message='MYG_VINCULO_NO_VERIFICADO';
        end if;
        if v_l.confirmado then
            select * into v_i from myg_nube_privado.identidades_verificadas
              where auth_usuario_id=v_l.auth_usuario_id for update;
            if not found or lower(btrim(v_i.usuario_myg))<>v_l.usuario_myg then
                raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
            end if;
            if not v_i.activo then
                raise exception using errcode='42501',message='MYG_VINCULO_NO_VERIFICADO';
            end if;
        elsif exists(select 1 from myg_nube_privado.identidades_verificadas
                     where auth_usuario_id=v_l.auth_usuario_id) then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
        if v_l.usuario_myg<>p_usuario then
            -- Un ticket anterior no puede deshacer un cambio de nombre posterior.
            if p_emitido<=v_l.ultimo_emitido
               or exists(select 1 from myg_nube_privado.licencias_nube where usuario_myg=p_usuario and licencia_id<>p_licencia_id)
               or exists(select 1 from myg_nube_privado.identidades_verificadas
                         where lower(btrim(usuario_myg))=p_usuario and auth_usuario_id<>v_l.auth_usuario_id) then
                raise exception using errcode='23505',message='MYG_LICENCIA_CONFLICTO';
            end if;
            if v_l.confirmado then
                update myg_nube_privado.identidades_verificadas set usuario_myg=p_usuario where auth_usuario_id=v_l.auth_usuario_id;
            end if;
            update myg_nube_privado.licencias_nube set usuario_myg=p_usuario,version=version+1,
                ultimo_emitido=p_emitido where licencia_id=p_licencia_id returning * into v_l;
        else
            update myg_nube_privado.licencias_nube set ultimo_emitido=greatest(ultimo_emitido,p_emitido)
              where licencia_id=p_licencia_id returning * into v_l;
        end if;
        v_id:=v_l.auth_usuario_id; v_origen:=v_l.origen;
        v_crear:=not v_l.confirmado; v_version:=v_l.version;
    end if;
    delete from myg_nube_privado.canjes_licencia where expira<v_ahora-30;
    delete from myg_nube_privado.ingresos_consumidos where expira<v_ahora-30;
    begin
        insert into myg_nube_privado.ingresos_consumidos(nonce,auth_usuario_id,emitido,expira)
          values(p_nonce,v_id,p_emitido,p_expira);
    exception when unique_violation then
        raise exception using errcode='23505',message='MYG_INGRESO_REUTILIZADO';
    end;
    insert into myg_nube_privado.canjes_licencia(nonce,licencia_id,auth_usuario_id,usuario_myg,version,expira)
      values(p_nonce,p_licencia_id,v_id,p_usuario,v_version,p_expira);
    return jsonb_build_object('usuario_id',v_id,'usuario_myg',p_usuario,'licencia_id',p_licencia_id,
      'crear_usuario',v_crear,'origen',v_origen,'alias',case when v_origen='tecnica' then 'licencia'||p_licencia_id::text||'@myg.invalid' else null end);
end;
$$;

create function public.myg_nube_confirmar_ingreso(p_nonce uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog,myg_nube_privado as $$
declare
    v_ahora bigint:=floor(extract(epoch from clock_timestamp()))::bigint;
    v_c myg_nube_privado.canjes_licencia%rowtype;
    v_l myg_nube_privado.licencias_nube%rowtype;
    v_i myg_nube_privado.identidades_verificadas%rowtype;
    v_u auth.users%rowtype;
begin
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-alta-licencias',0));
    select * into v_c from myg_nube_privado.canjes_licencia where nonce=p_nonce for update;
    if not found then raise exception using errcode='22023',message='MYG_INGRESO_INVALIDO'; end if;
    if v_c.expira<v_ahora-30 then raise exception using errcode='28000',message='MYG_INGRESO_EXPIRADO'; end if;
    -- Orden Auth -> reserva: DELETE/soft-delete toma la fila Auth y su trigger
    -- actualiza la reserva. Mantener el mismo orden evita un ciclo de bloqueo.
    select * into v_u from auth.users where id=v_c.auth_usuario_id for share;
    if not found or v_u.deleted_at is not null or v_u.banned_until>clock_timestamp() then
        raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
    end if;
    if v_c.licencia_id is null and exists(select 1 from myg_nube_privado.licencias_nube where auth_usuario_id=v_c.auth_usuario_id) then
        raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
    end if;
    if v_c.licencia_id is not null then
        select * into v_l from myg_nube_privado.licencias_nube where licencia_id=v_c.licencia_id for update;
        if not found or v_l.auth_usuario_id<>v_c.auth_usuario_id or v_l.usuario_myg<>v_c.usuario_myg or v_l.version<>v_c.version then
            raise exception using errcode='23505',message='MYG_LICENCIA_CONFLICTO';
        end if;
        if v_l.bloqueada then raise exception using errcode='42501',message='MYG_VINCULO_NO_VERIFICADO'; end if;
    end if;
    if exists(select 1 from myg_nube_privado.licencias_nube where auth_usuario_id=v_c.auth_usuario_id and bloqueada) then
        raise exception using errcode='42501',message='MYG_VINCULO_NO_VERIFICADO';
    end if;
    if v_l.origen='tecnica' then
        if v_u.email is distinct from 'licencia'||v_l.licencia_id::text||'@myg.invalid'
           or v_u.raw_app_meta_data->>'myg_nube_licencia_id' is distinct from v_l.licencia_id::text
           or v_u.raw_app_meta_data->>'myg_nube_origen' is distinct from 'licencias_v1' then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
    end if;
    select * into v_i from myg_nube_privado.identidades_verificadas where auth_usuario_id=v_c.auth_usuario_id for update;
    if found then
        if not v_i.activo then raise exception using errcode='42501',message='MYG_VINCULO_NO_VERIFICADO'; end if;
        if lower(btrim(v_i.usuario_myg))<>v_c.usuario_myg then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
    else
        if v_c.licencia_id is null or v_l.confirmado or v_l.origen<>'tecnica' then
            raise exception using errcode='42501',message='MYG_IDENTIDAD_REQUIERE_REVISION';
        end if;
        if exists(select 1 from myg_nube_privado.identidades_verificadas where lower(btrim(usuario_myg))=v_c.usuario_myg) then
            raise exception using errcode='23505',message='MYG_LICENCIA_CONFLICTO';
        end if;
        insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion)
          values(v_c.auth_usuario_id,v_c.usuario_myg,'Alta servidor: licencia MYG firmada '||v_c.licencia_id::text);
    end if;
    if v_c.licencia_id is not null then
        update myg_nube_privado.licencias_nube set confirmado=true where licencia_id=v_c.licencia_id;
    end if;
    update myg_nube_privado.canjes_licencia set confirmado=true where nonce=p_nonce;
    return jsonb_build_object('usuario_id',v_c.auth_usuario_id,'usuario_myg',v_c.usuario_myg);
end;
$$;
revoke all on function public.myg_nube_preparar_ingreso(text,uuid,uuid,bigint,bigint,text),
    public.myg_nube_confirmar_ingreso(uuid) from public,anon,authenticated;
grant execute on function public.myg_nube_preparar_ingreso(text,uuid,uuid,bigint,bigint,text),
    public.myg_nube_confirmar_ingreso(uuid) to service_role;
comment on table myg_nube_privado.licencias_nube is 'Reservas de identidad; bloquear pendiente con bloqueada=true. No borrar para reutilizar IDs ni reactivar vínculos revocados.';
notify pgrst,'reload schema';
commit;
