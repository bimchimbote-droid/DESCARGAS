# Acceso a Nube MYG con la sesión MYG

Este puente permite entrar en Nube MYG después del ingreso MYG, sin escribir correo ni contraseña Supabase. El servidor de licencias acredita al usuario y al ID estable de su fila `LICENCIAS` mediante un ticket firmado de un solo uso. La función `myg-login` conserva la cuenta Supabase ya vinculada o, para una licencia nueva, crea automáticamente una cuenta técnica y su vinculación. No requiere correo real, invitación ni contraseña nube. No concede solicitudes ni roles de proyecto: el propietario continúa aprobando a sus colaboradores. Cada operación de proyecto vuelve a comprobar la vinculación y la membresía vigentes.

El código y las pruebas locales no despliegan Apps Script, SQL ni Edge Functions sobre un servicio remoto. Los pasos administrativos siguientes requieren acceso del propietario a su proyecto de pruebas antes de instalar en producción. No vuelva a ejecutar las migraciones 001/002 en una instalación que ya las tenga.

## Instalación del servidor

1. Aplique una sola vez `migrations/202610200003_ingreso_myg.sql` y después `migrations/202610200004_alta_automatica_licencias.sql`, completas, en el SQL Editor del **mismo proyecto Supabase que usa MYG**. Si 003 ya está instalada, ejecute solo 004. Requieren la migración 001 previa y conservan cuentas, presupuestos y permisos existentes. Si hay usuarios repetidos al normalizar, 003 aborta; si detecta nombres de ejemplo como `USUARIO_EXACTO_EN_MYG`, 004 aborta sin modificar datos. El administrador debe corregir el texto de esa vinculación al usuario MYG real **conservando `auth_usuario_id` y sus roles**, después de comprobar a quién corresponde. No borre la cuenta propietaria, el vínculo ni el presupuesto para resolverlo. Sin 004 instalada, la función actual rechaza todo ingreso antes de crear cuentas Auth.
2. Mantenga `myg_nube_privado` fuera de **Exposed schemas**. Las RPC de ingreso, preparación y confirmación conceden ejecución exclusivamente a `service_role`. Los usuarios `anon` y `authenticated` no pueden consultar ni consumir vinculaciones/nonces directamente.
3. Instale el script completo incluido en `integraciones/apps-script/Codigo.gs`, conservando las propiedades existentes y su implementación web. Configure la propiedad `MYG_NUBE_URL` con la URL del proyecto y ejecute `PREPARAR_NUBE_MYG` como propietario: genera una sola vez `MYG_NUBE_HMAC`, de **64 caracteres hexadecimales**, si falta. Ese texto completo es la clave HMAC en UTF-8: no se decodifica como bytes hexadecimales. No use el dato sintético de las pruebas.
4. En **Apps Script → Configuración del proyecto → Propiedades de la secuencia de comandos**, copie exactamente el valor de `MYG_NUBE_HMAC` al servidor Supabase indicado abajo. Ejecute `VERIFICAR_NUBE_MYG` y actualice la versión de la implementación web existente, conservando su URL `/exec`. El público no debe tener acceso al editor ni a sus propiedades. Consulte el instructivo del script para conservar sus opciones actuales de licencias/compras.
5. En **Supabase → Edge Functions → Secrets**, añada `MYG_NUBE_HMAC` con el mismo secreto. Los valores `SUPABASE_URL`, `SUPABASE_ANON_KEY` y `SUPABASE_SERVICE_ROLE_KEY` son las variables estándar del servidor Supabase; no los copie al escritorio ni a Apps Script. Solo la URL y la clave publicable/anon son configuración pública del programa.
6. Desde la raíz del proyecto con la CLI oficial Supabase autenticada y el proyecto de pruebas vinculado, despliegue: `supabase functions deploy myg-login --project-ref REFERENCIA`. El archivo `supabase/config.toml` contiene `[functions.myg-login] verify_jwt = false`: el primer ticket todavía no es un JWT Supabase y se autentica con su propia firma HMAC. Si crea la función desde el panel, copie `index.ts` y `handler.ts`, y desactive **Verify JWT** únicamente para `myg-login`. Conserve los ajustes de cualquier otra función; este repositorio solo declara esta función nueva.
7. Configure MYG con la URL y la clave pública del mismo proyecto. Inicie sesión MYG y abra Nube MYG. El cliente solicita un ticket nuevo a la autoridad MYG y lo consume inmediatamente. Un ticket nuevo con `licencia_id` válido autoriza el alta técnica; un ticket antiguo sin ese claim solo puede usar una vinculación activa existente que todavía no esté asociada a un ID de licencia. Después de la primera asociación se exige siempre `licencia_id`, incluso para una confirmación preparada antes de asociarlo. Un vínculo desactivado nunca se reactiva automáticamente.

No guarde el secreto HMAC, `service_role`, tickets ni sesiones en archivos de la entrega, repositorios, capturas, comandos de historial, logs ni chats. Introduzca el secreto desde las pantallas administrativas anteriores. Si se expone, sustituya la propiedad en ambos servidores y vuelva a desplegar la función; los tickets duran un minuto y los anteriores dejan de validar al cambiar la clave. Una sesión Supabase ya emitida debe revocarse por los medios administrativos de Auth si también se necesita invalidarla; desactivar la vinculación ya impide usar las RPC y los archivos de MYG.

## Contrato exacto

`POST https://REFERENCIA.supabase.co/functions/v1/myg-login`, tipo `application/json`, clave pública en el encabezado `apikey`, cuerpo `{"ticket":"JWT_FIRMADO_POR_MYG"}` (el texto de ejemplo no es válido). El endpoint no confía en correo, nombre, UUID, PC ni URL aportados como otros campos del cliente.

Cabecera del ticket: `{"alg":"HS256","typ":"JWT"}`. El nuevo ticket contiene exactamente estos ocho claims:

| Campo | Valor |
| --- | --- |
| `iss` | `MYG_LICENCIAS` |
| `aud` | URL canónica HTTPS de `SUPABASE_URL`, sin `/` final |
| `sub` | Usuario MYG recortado y en minúsculas; 1–256 caracteres, sin caracteres de control |
| `pc` | SHA-256 UTF-8 del identificador de equipo MYG, 64 hexadecimales en mayúsculas |
| `jti` | UUID no nulo, formato con guiones en minúsculas |
| `licencia_id` | UUID estable de `ID_MYG_NUBE` en la fila `LICENCIAS`; no deriva del usuario ni del número de fila |
| `iat` | Segundo Unix entero de emisión |
| `exp` | `iat+60` |

Solo HS256 y base64url canónico sin padding; máximo 8 KiB por ticket y 16 KiB por solicitud. Edge y PostgreSQL comprueban vigencia con tolerancia de reloj de 30 segundos y duración máxima de 90 segundos. Los servidores deben mantener relojes sincronizados. La tabla privada de nonces tiene clave única y limpieza por expiración; borrar/revocar una cuenta no elimina un nonce todavía vigente. La huella del equipo no concede acceso por sí misma: está cubierta por la firma emitida tras validar la licencia/PC.

Normalización: Apps Script/Edge usan `trim().toLowerCase()` y el índice PostgreSQL usa `lower(btrim())`. Los usuarios ASCII habituales coinciden. Ciertas letras Unicode y espacios especiales pueden normalizarse de forma distinta entre .NET, JavaScript y la intercalación PostgreSQL; antes de habilitar un usuario con esos caracteres, confirme que su nombre canónico coincida en los tres sistemas. No se modifica automáticamente una vinculación para resolver esa diferencia.

Éxito HTTP 200:

```json
{"access_token":"SESION_AUTH","refresh_token":"RENOVACION_AUTH","expires_in":3600,"user":{"id":"UUID_EXISTENTE"},"usuario_myg":"usuario"}
```

Los errores solo incluyen `{"error":"CODIGO"}`. Códigos principales: 401 `MYG_INGRESO_INVALIDO`/`MYG_INGRESO_EXPIRADO`, 403 `MYG_VINCULO_NO_VERIFICADO`, 409 `MYG_INGRESO_REUTILIZADO`, 503 `MYG_NUBE_NO_CONFIGURADA`/`MYG_NUBE_NO_DISPONIBLE`, 400 `MYG_SOLICITUD_INVALIDA`, 413 `MYG_SOLICITUD_DEMASIADO_GRANDE` y 405 `MYG_METODO_NO_PERMITIDO`. También se devuelven 403 `MYG_IDENTIDAD_REQUIERE_REVISION` ante una cuenta/reserva que necesita revisión administrativa y 409 `MYG_LICENCIA_CONFLICTO` ante otro ID ya asociado o un renombre que colisiona; este último no significa replay. Un ticket consumido no se reintenta: solicite otro a MYG. No se devuelven detalles internos, correos, enlaces, OTP, hashes OTP ni claves administrativas.

## Cómo se obtiene la sesión Auth

Después de comprobar la firma, Edge llama a `myg_nube_preparar_ingreso(p_usuario,p_licencia_id,p_nonce,p_emitido,p_expira,p_pc)`. PostgreSQL reserva un UUID aleatorio estable para la licencia nueva, o captura el UUID del vínculo activo existente con ese usuario. El nonce se consume en la misma tabla de 003: tampoco se puede reutilizar un ticket antiguo tras actualizar a 004. Las reservas son privadas, únicas por licencia/usuario/UUID y persisten después de confirmar; su limpieza solo elimina canjes/nonces vencidos, nunca identidades de licencias.

Para una licencia nueva, Edge llama administrativamente a `POST /auth/v1/admin/users` con el UUID reservado, `email_confirm=true`, alias técnico `licenciaUUID@myg.invalid` y `app_metadata` de servidor `{myg_nube_licencia_id:UUID,myg_nube_origen:"licencias_v1"}`. El dominio `.invalid` no recibe correo. No se envía ninguna invitación; se omite la contraseña y Auth genera una aleatoria interna que no se conoce ni se devuelve. La API oficial admite un UUID administrativo explícito, así que no se recorren/listan usuarios por correo. Ante un alta concurrente, se recupera **solo** el UUID reservado y se exige que coincidan alias y marcadores de `app_metadata`; una cuenta ajena o `user_metadata` editada por el usuario nunca se adoptan. Una interrupción puede dejar una cuenta técnica pendiente sin permisos: un ticket nuevo reanuda su misma reserva, sin duplicarla.

Después se consulta `/auth/v1/admin/users/UUID` y se llama a `myg_nube_confirmar_ingreso(p_nonce)`. SQL vuelve a comprobar la reserva, versión/nombre actuales, existencia y estado de Auth, marcadores administrativos cuando sea cuenta técnica y estado activo del vínculo. Solo una reserva técnica inicial pendiente puede insertar la vinculación; una vinculación confirmada que fue borrada/desactivada no se recrea ni se reactiva. El administrador puede impedir una alta pendiente mediante `licencias_nube.bloqueada=true`. No borre reservas confirmadas para reutilizar IDs. Dos triggers privados, limitados a reservas ya existentes del mismo UUID, marcan la reserva como bloqueada si Auth elimina la cuenta o marca `deleted_at`; esto también impide recrearla cuando la primera alta todavía estaba pendiente. No modifican otras cuentas ni toman el bloqueo global de preparación. Una cuenta suspendida por Auth también se rechaza, sin quitarle la suspensión.

Para emitir la sesión, Edge genera internamente `/auth/v1/admin/generate_link` con `type=recovery` y consume inmediatamente el `hashed_token` en `/auth/v1/verify` con el mismo tipo y la clave anon. Todos los UUID deben coincidir. Las rutas se construyen bajo `SUPABASE_URL` fijo y `fetch` rechaza redirecciones. Se usa `recovery` porque `magiclink` puede auto-crear fuera de la reserva si una cuenta desaparece; `recovery` rechaza la ausencia. **Este paso no envía correo ni cambia la contraseña**. Los tokens devueltos son normales de Supabase y se renuevan mediante `refresh_token`; no se fabrica un JWT Supabase ni se distribuye `service_role` al cliente.

Renombrar al usuario en la misma fila de `LICENCIAS` conserva `ID_MYG_NUBE`, su UUID Auth, proyectos y roles. El nuevo nombre no debe estar ocupado por otra licencia/identidad. Una confirmación preparada con un nombre anterior se rechaza, y un ticket emitido antes del renombre no puede revertirlo. Si el cambio y el ticket anterior coinciden en el mismo segundo, espere un segundo y solicite un ticket nuevo. Borrar/recrear la fila produce una licencia distinta y no da derecho a adoptar el UUID o permisos anteriores; una colisión requiere revisión del administrador.

Efectos de Auth que debe conocer el administrador: el canje genera y consume el token de recuperación de esa cuenta, invalida sus OTP de un solo uso pendientes y puede confirmar el correo de una cuenta invitada existente si todavía no estaba confirmado. No combine simultáneamente este ingreso con un enlace de recuperación/invitación/OTP pendiente de la misma cuenta; solicite uno nuevo si lo necesita después. La autoridad MYG acredita el alta con licencia/PC y su ID estable firmados; no se vincula a una persona por mera coincidencia de correo. Las vinculaciones manuales previas se conservan y sus desactivaciones prevalecen.

Este flujo no llama a `logout`, no modifica la contraseña, no obliga a cambiarla ni elimina sesiones existentes. La opción de Supabase **Single session per user** puede invalidar la renovación de otra sesión del mismo UUID; cuentas con UUID distintos mantienen sus sesiones independientes. Las pruebas sin red comprueban que el puente no envía llamadas de cierre de sesión, pero no pueden reproducir configuraciones reales de Auth. En MYG, cada persona debe tener su usuario MYG y fila `LICENCIAS` propios; el backend conserva o crea un UUID Supabase independiente.

Las decisiones anteriores se verificaron en la API y el código oficial de Supabase Auth: [OpenAPI](https://github.com/supabase/auth/blob/master/openapi.yaml), [creación administrativa con UUID explícito](https://github.com/supabase/auth/blob/master/internal/api/admin.go), [generación administrativa de enlaces](https://github.com/supabase/auth/blob/master/internal/api/mail.go), [verificación de OTP](https://github.com/supabase/auth/blob/master/internal/api/verify.go), [limpieza del token de recuperación](https://github.com/supabase/auth/blob/master/internal/models/user.go) y [creación/renovación de sesiones](https://github.com/supabase/auth/blob/master/internal/tokens/service.go). No se descargan estas fuentes al ejecutar la función.

## Validación local y prueba administrativa pendiente

Con Node 24, desde la raíz del repositorio, las pruebas Edge usan HMAC y Web Crypto reales, y dobles HTTP sin red:

```bash
node --test supabase/functions/myg-login/handler.test.mjs
```

El handler no necesita SDK, importaciones remotas ni dependencias para producción. La comprobación de tipos usa TypeScript 5.9.3 con `--strict --noEmit --target ES2022 --module ESNext --lib ES2023,DOM --moduleResolution Bundler --allowImportingTsExtensions`. El adaptador `index.ts` usa las APIs estándar `Deno.serve`/`Deno.env` de Supabase Edge; el runtime Deno alojado no se ejecutó en estas pruebas locales.

La regresión PostgreSQL instala 001 y 003 en memoria; no modifica el ejecutor previo de 001/002. Comprueba permisos, RLS, dos identidades distintas, binding revocado, replay incluso después de borrar/reasignar cuenta, ventanas de tiempo, limpieza de nonces, preservación de usuarios/roles y aborto no destructivo por duplicados normalizados:

```bash
ruta_pruebas_sso=$(mktemp -d)
npm install --prefix "$ruta_pruebas_sso" --cache /tmp/myg-npm-cache --no-audit --no-fund @electric-sql/pglite@0.3.14
cp supabase/tests/ejecutar-sso-pglite.mjs "$ruta_pruebas_sso/ejecutar-sso.mjs"
node "$ruta_pruebas_sso/ejecutar-sso.mjs" "$PWD"
```

Se obtuvieron 46 pruebas Edge correctas y `PRUEBA_INGRESO_MYG_CORRECTA; ROLLBACK_CORRECTO` en PGlite 0.3.14. No equivale a probar Supabase Auth/PostgREST/gateway reales. Para 004 hay un ejecutor separado que aplica 001/003/004 en memoria y conserva un presupuesto previo de fixture. Incluye aborto no destructivo de placeholders, cuenta existente, reserva estable, metadatos administrativos, carreras de preparación/confirmación, renombres, replay cruzado de 003 y revocación por desactivación/borrado:

```bash
cp supabase/tests/ejecutar-alta-pglite.mjs "$ruta_pruebas_sso/ejecutar-alta.mjs"
node "$ruta_pruebas_sso/ejecutar-alta.mjs" "$PWD"
```

Resultado: `PRUEBA_ALTA_LICENCIAS_CORRECTA; PLACEHOLDER_BLOQUEADO_SIN_CAMBIOS; ROLLBACK_CORRECTO`. El flujo integrado adicional `tests/ejecutar-flujo-licencias.mjs` utiliza el script Apps Script real en una VM, firma HMAC real, handler y PostgreSQL reales locales y Auth HTTP simulado; comprueba propietario previo conservado, autoalta sin roles, solicitud/aprobación y rechazo tras revocar. No ejecuta servicios remotos.

Después del despliegue administrativo en pruebas, valide desde dos equipos y dos usuarios distintos: ingreso MYG, apertura Nube sin segunda contraseña, usuario Supabase correcto, renovación de sesión tras expirar el access token, rechazo de vínculo desactivado y permisos editor/lector sin cerrar la sesión del otro equipo. Vuelva a probar el conflicto de sincronización y la conservación del borrador. Revocar la membresía o la vinculación debe denegar las siguientes operaciones; el puente no restaura permisos retirados.
