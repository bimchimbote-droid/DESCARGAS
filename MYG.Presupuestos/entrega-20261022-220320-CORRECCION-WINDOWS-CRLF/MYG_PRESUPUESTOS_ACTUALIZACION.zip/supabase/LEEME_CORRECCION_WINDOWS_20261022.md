# Diagnóstico recibido y corrección del instalador para Windows

## Qué confirma el diagnóstico real

La captura se tomó el 22/10/2026 a las **16:57:36 de Perú** (21:57:36 UTC).
PostgreSQL 17.11 informa un inicio del postmaster a las **16:42:15 de Perú**,
aproximadamente quince minutos antes. Ese arranque es posterior al HTTP 502 de
las 11:24:27; su motivo todavía no está identificado.

| Observación | Interpretación y límite |
|---|---|
| Archivado: cuatro éxitos, cero fallos desde las 16:42:15; cero archivos `.ready` pendientes. | El archivado estaba funcionando al tomar la captura. El reinicio de estadísticas impide usar estos ceros para descartar los fallos de las 11:24–11:26. |
| Visibilidad completa de actividad y ninguna otra sesión cliente de esta base distinta de `idle`. | No hay evidencia de un bloqueo o transacción prolongada en ese instante. No reconstruye esperas históricas. |
| Índices primarios esperados presentes y válidos. | No aparece un índice ausente o inválido que explique el incidente. No mide los planes ejecutados durante el error. |
| `shared_buffers` configurado en 224 MiB; `work_mem` de 2184 kB. | Son ajustes, no una medición de RAM consumida. `work_mem` no limita toda la memoria usada para convertir JSONB. |
| Seis archivos temporales y unos 47,67 MiB acumulados. | No pueden atribuirse a una RPC concreta ni constituyen una prueba de agotamiento de memoria. |
| Roles API con `statement_timeout=8s`; función de publicación con `120s`. | No prueba cuál fue el plazo efectivo de la petición real. Los 8 s/500 ms de la sesión de diagnóstico fueron establecidos localmente por el propio script. |

Los tiempos de I/O iguales a cero no demuestran ausencia de esperas: el seguimiento
de I/O está desactivado. Los contadores WAL acumulados tampoco son una duración,
una tasa de saturación ni una medida de espacio libre.

El paquete pendiente mostrado como **200,1 MiB** supera el aviso de 127 MiB,
no el máximo lógico de 300 MiB. Ese tamaño no permite distinguir por sí solo un
paquete antiguo de uno compacto, ni equivale necesariamente al POST final después
de preparar los adjuntos. Reintentar conserva el contenido y el identificador.

## Defecto verificable del instalador anterior

La huella recibida de `myg_nube_crear_confirmacion` es
`da43c6f3c9c158e025aa649f6c7630fe`: corresponde al cuerpo oficial de la migración
26 con saltos de línea **CRLF**, habituales en Windows. Las huellas de expansión,
validación, capacidades y estado también coinciden con sus versiones CRLF.

El instalador 27 anterior solo reconocía el cuerpo LF y rechazaba este cuerpo
oficial CRLF como versión desconocida. La función observada todavía no tiene
aplicada la modificación `FOR UPDATE NOWAIT`.

El instalador corregido reconoce únicamente las cuatro huellas exactas de los
cuerpos oficiales: versión 26 y versión 27, cada una con LF o CRLF. Mantiene el
estilo de saltos de línea del cuerpo instalado, sus atributos, propietario,
permisos, OID y configuración. Una personalización desconocida o un cuerpo con
saltos mezclados siguen rechazándose sin sobrescribirlos. El propio instalador
puede ejecutarse con LF o CRLF.

La modificación de comportamiento sigue limitada al bloqueo de fila: devolver
`55006 / MYG_RECURSO_OCUPADO` si otra transacción ocupa esa fila. No elimina
validaciones, contenido, historial, miembros ni comprobaciones de creación.

**Esta corrección de instalación no identifica la causa del HTTP 502/520 ni
soluciona el consumo de memoria anterior a la RPC.** Los ensayos sintéticos ya
realizados con cargas de unos 200 MiB mostraron que PostgREST o PostgreSQL pueden
agotarse antes de entrar en la función; no prueban que eso ocurriera en el
servidor real. No se repitieron esos ensayos para este cambio.

## Qué hacer con cada archivo de esta entrega

Copiar desde la raíz del ZIP a la carpeta donde está la solución `.sln`,
conservando las carpetas relativas. Si un archivo ya existe, respaldar antes los
cambios locales que se hayan hecho sobre él.

| Archivo | Acción en el repositorio | Acción posterior |
|---|---|---|
| `supabase/migraciones/20261027_publicacion_sin_espera.sql` | Reemplazar el archivo de la entrega anterior. | Ejecutar completo en SQL Editor de Supabase, siguiendo los pasos siguientes. |
| `supabase/pruebas/publicacion_sin_espera.sql` | Reemplazar el archivo de la entrega anterior. | Solo pruebas en PostgreSQL desechable; no ejecutar en Supabase real. |
| `scripts/pruebas/Probar-PublicacionSinEsperaSaltos.py` | Crear este archivo nuevo. | Comprobación opcional de desarrollo con Python 3 y Docker; no publica en Supabase. |
| `supabase/LEEME_CORRECCION_WINDOWS_20261022.md` | Crear este archivo nuevo. | Leer estas instrucciones y conservar las conclusiones. |

### Instalación manual en tu Supabase

1. Conservar el SQLite original y el intento pendiente. No hace falta provocar
   otra publicación grande para aplicar o verificar este instalador.
2. Abrir **el archivo corregido**
   `supabase/migraciones/20261027_publicacion_sin_espera.sql` y copiar todo su texto.
3. En el proyecto Supabase correspondiente, abrir **SQL Editor → nueva consulta**,
   pegar ese texto y pulsar **Run**. La función observada ya corresponde al
   requisito 26; no es necesario reinstalarlo.
4. Debe aparecer `PUBLICACION_SIN_ESPERA_INSTALADA`. El instalador se puede repetir.
   Si aparece un rechazo por versión desconocida, conservar el error y revisar
   diferencias: no forzar la instalación reemplazando funciones con SQL antiguos.
5. Opcionalmente, ejecutar esta consulta pequeña de metadatos para verificarlo:

```sql
SELECT
    md5(p.prosrc) AS huella_cuerpo,
    md5(p.prosrc) IN (
        '0e4fc248646351ac672e015931e721e9',
        '172b23f1cb9f9652caece14e4bb359b7'
    ) AS parche_27_aplicado
FROM pg_catalog.pg_proc AS p
WHERE p.oid = pg_catalog.to_regprocedure(
    'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'
);
```

El resultado esperado es `parche_27_aplicado = true`. No se necesitan cambios
de claves, configuración global, ejecutables ni recompilación de MYG. No ejecutar
la migración 26 después de la 27: podría sustituir la corrección de bloqueo.

## Validación y trabajo pendiente

Se ejecutó únicamente la regresión nueva del instalador en PostgreSQL 17.11
desechable: **62 verificaciones superadas**. Cubrió las ocho combinaciones de
cuerpo oficial 26/27 LF/CRLF con instalador LF/CRLF; repetición idempotente en
todas; conservación exacta del cuerpo y saltos, OID, propietario, ACL,
configuración, demás atributos, funciones ajenas, ajustes de roles y filas de
control. Rechazó ocho combinaciones de cuerpos personalizados/mixtos y dos sin
el requisito, sin sobrescribirlas. No hubo terminaciones por memoria y se eliminó
el contenedor al terminar.

```bash
python3 scripts/pruebas/Probar-PublicacionSinEsperaSaltos.py
```

Los cuerpos finales coinciden exactamente con las huellas del cambio de bloqueo
validado anteriormente. Se reutilizan esas pruebas funcionales SQL/HTTP; no se
presentan como nuevas. La suite completa, las compilaciones .NET y los benchmarks
grandes no se repitieron porque el cambio adicional solo afecta al reconocimiento
y sustitución del texto durante la instalación. La aserción añadida a la suite
SQL completa queda incluida para futuras ejecuciones de esa suite.

Faltan la causa del arranque de las 16:42:15 y evidencia de recursos, duración o
SQLSTATE del HTTP fallido. El usuario no sabe si hubo una acción manual que
explique ese arranque. Revisar los registros de PostgreSQL e infraestructura de
**16:41 a 16:44 de Perú**
(21:41–21:44 UTC), sin reenviar paquetes grandes. No confundir ese intervalo
nuevo con el del fallo original de las 11:24.

Conservar las observaciones anteriores: `false / false` en la consulta del UUID
solo describe las filas visibles en aquel instante; `GRANDE` es el proyecto de
2 MB diferente, y el aviso sobre `detalle_insumo_salida` es una exclusión de tabla
distinta del fallo HTTP. No se añade soporte a una tabla desconocida sin conocer
su esquema y verificar su conservación.

Para guardar los cambios de código en `bimchimbote-droid/MYG.Presupuestos`, revisar
en Git los archivos copiados junto con los cambios previos que se deseen conservar,
hacer Commit y después Push a la rama elegida. La descarga en `DESCARGAS` no hace
Commit ni Push automáticamente en el repositorio de código.
