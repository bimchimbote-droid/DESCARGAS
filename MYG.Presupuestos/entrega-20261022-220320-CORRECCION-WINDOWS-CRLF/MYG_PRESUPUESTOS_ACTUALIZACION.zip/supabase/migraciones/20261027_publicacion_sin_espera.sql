-- Estabilidad de reintentos: no esperar por una fila que otra operación modifica.
-- Requiere 20261026_publicacion_ligera.sql. No cambia contenido, permisos ni datos.
-- Conserva OID, propietario, ACL y configuración real de la función instalada.
-- NOWAIT acota la espera de fila, no el parseo JSON previo ni bloqueos de DDL.
-- Reconoce los cuerpos oficiales LF y CRLF; conserva sus saltos de línea.
begin;

do $instalar_sin_espera$
declare
    v_oid oid:=to_regprocedure('public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)');
    v_fuente text;
    v_definicion text;
    v_atributos jsonb;
    v_huella text;
    v_huella_esperada text;
    v_antes_aplicado text;
    v_despues_aplicado text;
    -- Normalizar solo estas constantes del instalador: pegar el SQL desde
    -- Windows no debe alterar el bloque buscado ni el estilo del cuerpo remoto.
    v_antes constant text:=replace($antes$    select propietario into v_propietario from public.myg_nube_proyectos
      where id=p_id for update;$antes$,E'\r\n',E'\n');
    v_despues constant text:=replace($despues$    -- MYG_PUBLICACION_SIN_ESPERA_V1: comprobar permisos antes de probar la fila.
    -- La lectura previa no reemplaza la comprobación bajo el bloqueo.
    select propietario into v_propietario from public.myg_nube_proyectos
      where id=p_id;
    if found and v_propietario<>v_usuario then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    begin
        select propietario into v_propietario from public.myg_nube_proyectos
          where id=p_id for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;$despues$,E'\r\n',E'\n');
begin
    if v_oid is null then
        raise exception using errcode='55000',
            message='Instale primero 20261026_publicacion_ligera.sql completo. No se modificó ninguna función.';
    end if;
    select p.prosrc,pg_get_functiondef(p.oid),to_jsonb(p)-'prosrc'
      into v_fuente,v_definicion,v_atributos
      from pg_proc p where p.oid=v_oid;

    -- Huellas de los cuerpos oficiales 26 y 27, cada uno en LF y CRLF.
    -- Rechazar una personalización desconocida evita reemplazar avances ajenos.
    -- No normalizar v_fuente: una mezcla de saltos desconocida sigue rechazándose.
    v_huella:=md5(v_fuente);
    if v_huella in ('0e4fc248646351ac672e015931e721e9',
                    '172b23f1cb9f9652caece14e4bb359b7') then
        v_huella_esperada:=v_huella;
        null; -- Ya aplicada: no recrear ni cambiar configuración.
    elsif v_huella in ('d00c2b6242abf449ada0eeb1a081451b',
                      'da43c6f3c9c158e025aa649f6c7630fe') then
        if v_huella='da43c6f3c9c158e025aa649f6c7630fe' then
            v_antes_aplicado:=replace(v_antes,E'\n',E'\r\n');
            v_despues_aplicado:=replace(v_despues,E'\n',E'\r\n');
            v_huella_esperada:='172b23f1cb9f9652caece14e4bb359b7';
        else
            v_antes_aplicado:=v_antes;
            v_despues_aplicado:=v_despues;
            v_huella_esperada:='0e4fc248646351ac672e015931e721e9';
        end if;
        if strpos(v_fuente,v_antes_aplicado)=0 then
            raise exception using errcode='55000',
                message='No se encontró el bloque oficial de publicación. Se conserva la función intacta.';
        end if;
        execute replace(v_definicion,v_antes_aplicado,v_despues_aplicado);
    else
        raise exception using errcode='55000',
            message='La función de publicación tiene una versión o personalización no reconocida. Se conserva intacta; revise sus diferencias antes de aplicar este cambio.';
    end if;

    if not exists(select 1 from pg_proc p where p.oid=v_oid
        and md5(p.prosrc)=v_huella_esperada
        and to_jsonb(p)-'prosrc'=v_atributos) then
        raise exception using errcode='55000',
            message='Verificación de publicación sin espera fallida. Se revierte toda la instalación.';
    end if;
end $instalar_sin_espera$;

notify pgrst,'reload schema';
select 'PUBLICACION_SIN_ESPERA_INSTALADA' as resultado,
       true as rechazo_inmediato_de_fila_ocupada,
       '55006' as codigo_recurso_ocupado;
commit;
