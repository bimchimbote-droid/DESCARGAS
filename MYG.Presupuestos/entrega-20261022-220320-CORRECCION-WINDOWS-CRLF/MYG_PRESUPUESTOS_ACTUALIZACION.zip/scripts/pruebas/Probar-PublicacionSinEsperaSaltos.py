#!/usr/bin/env python3
"""Comprueba solo la instalación LF/CRLF del parche 27 en PostgreSQL desechable.

Sin Supabase, PostgREST, compilaciones, benchmarks ni contenido de proyectos.
No reemplaza las pruebas funcionales SQL/HTTP del bloqueo ya existentes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import tempfile
import time
import uuid

REPO = Path(__file__).resolve().parents[2]
POSTGRES = 'postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
SIGNATURE = 'public.myg_nube_crear_confirmacion(uuid,text,jsonb,text)'
KNOWN = {
    '26_LF': 'd00c2b6242abf449ada0eeb1a081451b',
    '26_CRLF': 'da43c6f3c9c158e025aa649f6c7630fe',
    '27_LF': '0e4fc248646351ac672e015931e721e9',
    '27_CRLF': '172b23f1cb9f9652caece14e4bb359b7',
}
BEFORE = '''    select propietario into v_propietario from public.myg_nube_proyectos
      where id=p_id for update;'''
AFTER = '''    -- MYG_PUBLICACION_SIN_ESPERA_V1: comprobar permisos antes de probar la fila.
    -- La lectura previa no reemplaza la comprobación bajo el bloqueo.
    select propietario into v_propietario from public.myg_nube_proyectos
      where id=p_id;
    if found and v_propietario<>v_usuario then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    begin
        select propietario into v_propietario from public.myg_nube_proyectos
          where id=p_id for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resultados', type=Path, help='Directorio de resultados y logs que se conservará')
    args = parser.parse_args()
    output = args.resultados or Path(tempfile.mkdtemp(prefix='myg-saltos-resultados-'))
    output.mkdir(parents=True, exist_ok=True)
    container = 'myg-saltos-' + uuid.uuid4().hex[:12]
    record = {'status': 'running', 'checks': [], 'accepted_cases': [], 'rejected_cases': []}
    created = False

    def stop(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)

    def require(ok, detail):
        if not ok:
            raise AssertionError(detail)
        record['checks'].append(detail)

    with (output / 'ejecucion.log').open('w') as log:
        def run(*command, check=True):
            result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(result.stdout)
            log.flush()
            if check and result.returncode:
                raise RuntimeError(f'{command[0]} terminó con {result.returncode}: {result.stdout[-1800:]}')
            return result

        def sql(query=None, path=None, db='postgres', check=True):
            command = ['docker', 'exec', '-u', 'postgres', container, 'psql', '-X', '-qAt',
                       '-d', db, '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose']
            command.extend(['-c', query] if query is not None else ['-f', path])
            return run(*command, check=check)

        def state():
            return json.loads(sql(f"""
              SELECT jsonb_build_object(
                'attributes',(SELECT to_jsonb(p)-'prosrc' FROM pg_proc p WHERE oid='{SIGNATURE}'::regprocedure),
                'body',(SELECT prosrc FROM pg_proc WHERE oid='{SIGNATURE}'::regprocedure),
                'other_functions',(SELECT jsonb_agg(to_jsonb(p) ORDER BY p.oid) FROM pg_proc p
                    WHERE p.pronamespace IN ('public'::regnamespace,'myg_nube_privado'::regnamespace)
                    AND p.oid<>'{SIGNATURE}'::regprocedure),
                'rows',(SELECT jsonb_agg(to_jsonb(r) ORDER BY id) FROM public.filas_conservadas r),
                'role_settings',(SELECT jsonb_agg(to_jsonb(s) ORDER BY setdatabase,setrole) FROM pg_db_role_setting s));
            """).stdout)

        try:
            source26 = (REPO / 'supabase/migraciones/20261026_publicacion_ligera.sql').read_text()
            start = source26.index('create or replace function public.myg_nube_crear_confirmacion(')
            head, body, _tail = source26[start:].split('$publicacion_ligera$', 2)
            require(body.count(BEFORE) == 1, 'El fixture 26 contiene un único bloque oficial a sustituir')
            patched = body.replace(BEFORE, AFTER)
            variants = {'26_LF': body, '26_CRLF': body.replace('\n', '\r\n'),
                        '27_LF': patched, '27_CRLF': patched.replace('\n', '\r\n')}
            for name, content in variants.items():
                require(hashlib.md5(content.encode()).hexdigest() == KNOWN[name],
                        'El fixture ' + name + ' coincide con su huella oficial independiente')
            installer = (REPO / 'supabase/migraciones/20261027_publicacion_sin_espera.sql').read_text()
            record['migration_sha256'] = hashlib.sha256(
                (REPO / 'supabase/migraciones/20261027_publicacion_sin_espera.sql').read_bytes()).hexdigest()
            record['runner_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
            with tempfile.TemporaryDirectory(prefix='myg-saltos-instaladores-') as temporary:
                temporary = Path(temporary)
                for ending in ('LF', 'CRLF'):
                    content = installer if ending == 'LF' else installer.replace('\n', '\r\n')
                    (temporary / ('instalador-' + ending + '.sql')).write_bytes(content.encode())
                if run('docker', 'image', 'inspect', POSTGRES, check=False).returncode:
                    run('docker', 'pull', POSTGRES)
                run('docker', 'run', '--detach', '--rm', '--name', container, '--network', 'none',
                    '--memory=512m', '--memory-swap=512m', '--cpus=1',
                    '--tmpfs', '/var/lib/postgresql/data:rw,size=128m',
                    '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', POSTGRES,
                    '-c', 'shared_buffers=32MB', '-c', 'work_mem=1MB', '-c', 'max_connections=20')
                created = True
                for _attempt in range(60):
                    if run('docker', 'exec', container, 'pg_isready', '-U', 'postgres', check=False).returncode == 0:
                        break
                    time.sleep(0.2)
                else:
                    raise RuntimeError('PostgreSQL desechable no inició')
                run('docker', 'cp', str(temporary), container + ':/instaladores')
                run('docker', 'exec', '-u', 'root', container, 'chmod', '-R', 'a+rX', '/instaladores')
                sql("""
                  CREATE SCHEMA myg_nube_privado;
                  CREATE ROLE anon;
                  CREATE ROLE authenticated;
                  CREATE ROLE propietario_saltos;
                  CREATE ROLE auditor_saltos;
                  ALTER ROLE authenticated SET statement_timeout='8s';
                  CREATE TABLE public.filas_conservadas(id integer PRIMARY KEY, dato text NOT NULL);
                  INSERT INTO public.filas_conservadas VALUES (1,'fixture sintético conservado');
                  CREATE FUNCTION public.funcion_conservada() RETURNS integer LANGUAGE sql AS 'select 17';
                """)

                def seed(content):
                    sql(head + '$publicacion_ligera$' + content + '$publicacion_ligera$;')
                    sql(f"""
                      ALTER FUNCTION {SIGNATURE} OWNER TO propietario_saltos;
                      ALTER FUNCTION {SIGNATURE} SET statement_timeout='65s';
                      ALTER FUNCTION {SIGNATURE} SET lock_timeout='750ms';
                      ALTER FUNCTION {SIGNATURE} SET myg.prueba_conservada='valor_sintetico';
                      REVOKE ALL ON FUNCTION {SIGNATURE} FROM PUBLIC,anon;
                      GRANT EXECUTE ON FUNCTION {SIGNATURE} TO authenticated,auditor_saltos;
                    """)

                for initial, content in variants.items():
                    for ending in ('LF', 'CRLF'):
                        label = initial + '/instalador_' + ending
                        seed(content)
                        before = state()
                        installed = sql(path='/instaladores/instalador-' + ending + '.sql')
                        require('PUBLICACION_SIN_ESPERA_INSTALADA' in installed.stdout, label + ': instalación confirmada')
                        after = state()
                        expected = variants['27_CRLF' if initial.endswith('_CRLF') else '27_LF']
                        require(after['body'] == expected, label + ': cuerpo oficial y estilo de saltos exactos')
                        require({k: v for k, v in before.items() if k != 'body'} ==
                                {k: v for k, v in after.items() if k != 'body'},
                                label + ': OID, propietario, ACL, configuración, demás funciones y datos intactos')
                        sql(path='/instaladores/instalador-' + ending + '.sql')
                        require(state() == after, label + ': repetición deja todos los atributos y el cuerpo intactos')
                        record['accepted_cases'].append(label)

                unknown = {
                    '26_personalizado_LF': body + '\n-- Personalización sintética\n',
                    '27_personalizado_CRLF': variants['27_CRLF'] + '\r\n-- Personalización sintética\r\n',
                    '26_mixto': body.replace('\n', '\r\n', 1),
                    '27_mixto': variants['27_CRLF'].replace('\r\n', '\n', 1),
                }
                for name, content in unknown.items():
                    require(hashlib.md5(content.encode()).hexdigest() not in KNOWN.values(),
                            name + ': fixture desconocido distinto de las cuatro huellas oficiales')
                    for ending in ('LF', 'CRLF'):
                        label = name + '/instalador_' + ending
                        seed(content)
                        before = state()
                        rejected = sql(path='/instaladores/instalador-' + ending + '.sql', check=False)
                        require(rejected.returncode != 0 and '55000' in rejected.stdout,
                                label + ': versión desconocida rechazada de forma controlada')
                        require(state() == before, label + ': rechazo no modifica ningún atributo ni dato')
                        record['rejected_cases'].append(label)

                sql('CREATE DATABASE sin_requisito TEMPLATE template0;')
                for ending in ('LF', 'CRLF'):
                    label = 'sin_requisito/instalador_' + ending
                    rejected = sql(path='/instaladores/instalador-' + ending + '.sql', db='sin_requisito', check=False)
                    require(rejected.returncode != 0 and '55000' in rejected.stdout,
                            label + ': requisito ausente rechazado de forma controlada')
                    require(sql("SELECT to_regprocedure('" + SIGNATURE + "') IS NULL;", db='sin_requisito').stdout.strip() == 't',
                            label + ': no crea la función ausente')
                    record['rejected_cases'].append(label)
                events = run('docker', 'exec', container, 'cat', '/sys/fs/cgroup/memory.events').stdout
                require(dict(line.split() for line in events.splitlines()).get('oom_kill') == '0',
                        'Las verificaciones del instalador no registran terminaciones por memoria')
                record['postgresql_version'] = sql('SHOW server_version;').stdout.strip()
                record['status'] = 'passed'
                record['scope'] = 'Compatibilidad de instalación LF/CRLF; reutiliza validaciones funcionales previas, sin repetirlas.'
        except BaseException as error:
            record['status'] = 'failed'
            record['error'] = str(error)
            raise
        finally:
            if created:
                (output / 'postgres.log').write_text(run('docker', 'logs', container, check=False).stdout)
                run('docker', 'rm', '-f', container, check=False)
            record['check_count'] = len(record['checks'])
            (output / 'results.json').write_text(json.dumps(record, ensure_ascii=False, indent=2))
            print(json.dumps({k: v for k, v in record.items() if k != 'checks'}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
