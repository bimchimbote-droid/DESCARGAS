using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class ResumenPersonalizadoUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Alcances y limpieza del resumen", "ESTRUCTURAS");
        var primero = proyecto.Presupuestos.Single();
        var segundo = MYGEstructuraPresupuestos.AgregarPresupuesto(proyecto);
        primero.Nombre = "ESTRUCTURAS"; segundo.Nombre = "ARQUITECTURA";
        Preparar(primero, 100m, 10m, 7m, 18m, 2m);
        Preparar(segundo, 200m, 20m, 5m, 16m, 3m);
        MYGProyectoStorage.Validar(proyecto);
        var activo = primero;
        var firmasAntes = new List<string>();
        var firmasDespues = new List<string>();
        using var panel = new MYGPanelPresupuesto(() => activo,
            () => firmasAntes.Add(MYGProyectoStorage.Firma(proyecto)),
            () => firmasDespues.Add(MYGProyectoStorage.Firma(proyecto)),
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarCatalogos(() => "", () => true, () => { });
        panel.InicializarEstructura(() => proyecto,
            id => activo = proyecto.Presupuestos.Single(p => p.Id == id),
            _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1500, 900) };
        formulario.Controls.Add(panel);
        formulario.Show();
        panel.Refrescar();
        Application.DoEvents();

        var tabla = Campo<DataGridView>(panel, "tablaPie");
        var selector = Campo<ComboBox>(panel, "alcancePie");
        var boton = Controles(panel).OfType<ToolStrip>().SelectMany(t => t.Items.OfType<ToolStripDropDownButton>())
            .Single(i => i.Name == "resumenOpciones");
        var menu = tabla.ContextMenuStrip;
        exige(boton.Text == "Resumen" && boton.Image != null && menu != null,
            "El pie debe ofrecer el botón Resumen con su icono y un menú contextual propio.");
        string[] accionesAlcance = { "piePorPresupuesto", "piePorProyecto", "limpiarResumen" };
        exige(boton.DropDownItems.OfType<ToolStripMenuItem>().Select(i => i.Name).SequenceEqual(accionesAlcance) &&
                boton.DropDownItems.OfType<ToolStripMenuItem>().All(i => i.Image != null),
            "El desplegable Resumen debe ofrecer ambos alcances y Limpiar resumen, con sus iconos.");
        string[] accionesContexto =
        {
            "agregarFilaResumen", "editarFilaResumen", "eliminarFilaResumen", "subirFilaResumen", "bajarFilaResumen",
            "copiarResumen", "pegarResumen", "limpiarResumenContextual", "restaurarResumen", "fuenteResumen"
        };
        exige(menu.Items.OfType<ToolStripMenuItem>().Select(i => i.Name).SequenceEqual(accionesContexto) &&
                menu.Items.OfType<ToolStripMenuItem>().All(i => i.Image != null),
            "El anticlic del resumen debe conservar las acciones solicitadas y todos sus iconos, incluso deshabilitados.");
        SeleccionarFila(1);
        VerificarMenu(limpiado: false);
        exige(Opcion("editarFilaResumen").Enabled,
            "El anticlic de Gastos generales debe permitir editar la fila predeterminada.");

        // El anticlic debe operar sobre la celda pulsada, aunque antes estuviera
        // seleccionado otro concepto del resumen.
        var celdaDerecha = tabla.Rows[2].Cells["IMPORTE"];
        var area = tabla.GetCellDisplayRectangle(celdaDerecha.ColumnIndex, celdaDerecha.RowIndex, false);
        exige(area.Width > 4 && area.Height > 4,
            "La celda utilizada para comprobar el anticlic debe estar visible.");
        typeof(DataGridView).GetMethod("OnMouseDown", Privados).Invoke(tabla,
            new object[] { new MouseEventArgs(MouseButtons.Right, 1, area.Left + 3, area.Top + 3, 0) });
        Application.DoEvents();
        exige(tabla.CurrentCell == celdaDerecha && tabla.Rows[2].Selected,
            "El clic derecho debe seleccionar la fila y la celda pulsadas antes de ejecutar sus comandos.");
        menu.Close();

        string firmaInicial = MYGProyectoStorage.Firma(proyecto);
        CambiarAlcance(proyectoCompleto: true);
        exige(Convert.ToString(tabla.Rows[1].Cells["PORC"].Value) == "Varios",
            "El resumen por proyecto debe indicar Varios cuando sus presupuestos tienen tasas diferentes.");
        VerificarImportesPredeterminados(proyecto.Presupuestos);
        CambiarAlcance(proyectoCompleto: false);
        Activar(segundo);
        exige(Convert.ToString(tabla.Rows[1].Cells["PORC"].Value) == "20",
            "El resumen por presupuesto debe mostrar la tasa del presupuesto activo.");
        VerificarImportesPredeterminados(new[] { segundo });
        Activar(primero);
        exige(MYGProyectoStorage.Firma(proyecto) == firmaInicial && firmasAntes.Count == 0 && firmasDespues.Count == 0,
            "Cambiar el alcance o seleccionar otro presupuesto no debe uniformar tasas ni registrar ediciones.");

        CambiarAlcance(proyectoCompleto: true);
        VerificarCambio(() => EditarPorcentaje(12m));
        exige(primero.Costos.GastosGeneralesPorcentaje == 12m && segundo.Costos.GastosGeneralesPorcentaje == 12m &&
                primero.Costos.UtilidadPorcentaje == 7m && segundo.Costos.UtilidadPorcentaje == 5m,
            "Editar una tasa en el alcance del proyecto debe aplicarla a ambos presupuestos y conservar los otros conceptos.");
        CambiarAlcance(proyectoCompleto: false);
        VerificarCambio(() => EditarPorcentaje(13m));
        exige(primero.Costos.GastosGeneralesPorcentaje == 13m && segundo.Costos.GastosGeneralesPorcentaje == 12m,
            "Editar una tasa por presupuesto debe afectar únicamente al presupuesto activo.");
        var tasasPrimero = Tasas(primero);
        var tasasSegundo = Tasas(segundo);

        VerificarCambio(() => OpcionAlcance("limpiarResumen").PerformClick());
        exige(primero.Costos.PiePersonalizado?.Count == 0 && segundo.Costos.PiePersonalizado == null &&
                tabla.Rows.Count == 1 && Convert.ToString(tabla.Rows[0].Cells["CONCEPTO"].Value) == "Costo directo" &&
                Convert.ToString(tabla.Rows[0].Cells["IMPORTE"].Value) == MYGFormatoPresupuesto.Dinero(100m),
            "Limpiar por presupuesto debe conservar sólo el costo directo y respetar el pie del otro presupuesto.");
        exige(Tasas(primero) == tasasPrimero && Tasas(segundo) == tasasSegundo &&
                MYGMotorPresupuestos.Resumen(primero).Total == 100m,
            "Limpiar el resumen debe excluir los conceptos del cálculo sin borrar sus tasas guardadas.");
        SeleccionarFila(0);
        VerificarMenu(limpiado: true);

        CambiarAlcance(proyectoCompleto: true);
        string firmaMixta = MYGProyectoStorage.Firma(proyecto);
        int antesNavegar = firmasAntes.Count, despuesNavegar = firmasDespues.Count;
        var porcentajesMixtos = tabla.Rows.Cast<DataGridViewRow>()
            .Where(f => f.Tag is MYGConceptoPie).Select(f => f.Cells["PORC"]).ToArray();
        exige(porcentajesMixtos.Length == 4 && porcentajesMixtos.All(c => c.ReadOnly) &&
                Convert.ToString(tabla.Rows[1].Cells["IMPORTE"].Value) == MYGFormatoPresupuesto.Dinero(24m) &&
                Convert.ToString(tabla.Rows[tabla.Rows.Count - 1].Cells["IMPORTE"].Value) == MYGFormatoPresupuesto.Dinero(378.46m),
            "El alcance mixto debe mostrar los gastos del segundo presupuesto y sumar su total al costo directo del primero limpiado.");
        foreach (var celda in porcentajesMixtos)
        {
            tabla.CurrentCell = celda;
            // WinForms valida también celdas de sólo lectura al navegar. Un
            // porcentaje 'Varios' sin una edición previa debe aceptarse tal cual.
            var validacion = (DataGridViewCellValidatingEventArgs)Activator.CreateInstance(
                typeof(DataGridViewCellValidatingEventArgs), Privados, null,
                new object[] { celda.ColumnIndex, celda.RowIndex, celda.FormattedValue }, null);
            typeof(DataGridView).GetMethod("OnCellValidating", Privados).Invoke(tabla, new object[] { validacion });
            exige(!validacion.Cancel && string.IsNullOrEmpty(celda.OwningRow.ErrorText),
                "Navegar por un porcentaje de sólo lectura del resumen mixto no debe intentar editarlo ni bloquear la selección.");
            tabla.CurrentCell = tabla.Rows[0].Cells["CONCEPTO"];
            panel.FinalizarEdicion();
            exige(tabla.CurrentCell.RowIndex == 0 && tabla.CurrentCell.OwningColumn.Name == "CONCEPTO",
                "Se debe poder abandonar el porcentaje de sólo lectura y seleccionar otra celda del resumen.");
        }
        exige(MYGProyectoStorage.Firma(proyecto) == firmaMixta && firmasAntes.Count == antesNavegar &&
                firmasDespues.Count == despuesNavegar,
            "Recorrer porcentajes de un resumen mixto debe conservar sus datos y no crear historial.");
        CambiarAlcance(proyectoCompleto: false);

        VerificarCambio(() => Opcion("restaurarResumen").PerformClick());
        exige(primero.Costos.PiePersonalizado == null && segundo.Costos.PiePersonalizado == null &&
                Tasas(primero) == tasasPrimero && Tasas(segundo) == tasasSegundo,
            "Mostrar Resumen predeterminado debe recuperar los conceptos con sus porcentajes originales.");
        VerificarImportesPredeterminados(new[] { primero });

        CambiarAlcance(proyectoCompleto: true);
        SeleccionarFila(1);
        Invocar(panel, "ActualizarMenuResumen");
        VerificarCambio(() => Opcion("limpiarResumenContextual").PerformClick());
        exige(proyecto.Presupuestos.All(p => p.Costos.PiePersonalizado?.Count == 0) &&
                tabla.Rows.Count == 1 && Convert.ToString(tabla.Rows[0].Cells["IMPORTE"].Value) == MYGFormatoPresupuesto.Dinero(300m),
            "Limpiar desde el anticlic por proyecto debe limpiar todos los presupuestos y sumar sus costos directos.");
        VerificarMenu(limpiado: true, puedeCopiar: false);
        VerificarCambio(() => Opcion("restaurarResumen").PerformClick());
        exige(proyecto.Presupuestos.All(p => p.Costos.PiePersonalizado == null) &&
                Tasas(primero) == tasasPrimero && Tasas(segundo) == tasasSegundo,
            "Restaurar por proyecto debe recuperar los pies y conservar los porcentajes propios de cada presupuesto.");
        VerificarImportesPredeterminados(proyecto.Presupuestos);

        CambiarAlcance(proyectoCompleto: false);
        var seguridad = new MYGFilaPiePersonalizada
            { Nombre = "Seguridad en obra", Porcentaje = 10m, Base = MYGBaseFilaPie.CostoDirecto };
        var administracion = new MYGFilaPiePersonalizada
            { Nombre = "Administración", Porcentaje = 10m, Base = MYGBaseFilaPie.Acumulado };
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { primero }, new() { seguridad, administracion });
        panel.Refrescar();
        Application.DoEvents();
        exige(TotalCalculado(primero) == 121m && ImporteVisible("Administración") == MYGFormatoPresupuesto.Dinero(11m),
            "La segunda fila sobre acumulado debe incluir el concepto anterior en su base de cálculo.");
        SeleccionarFila(1);
        Invocar(panel, "ActualizarMenuResumen");
        exige(Opcion("agregarFilaResumen").Available && Opcion("editarFilaResumen").Enabled &&
                Opcion("eliminarFilaResumen").Enabled && !Opcion("subirFilaResumen").Enabled && Opcion("bajarFilaResumen").Enabled,
            "La primera fila personalizada debe permitir agregar, editar, eliminar y bajar sin permitir subir sobre Costo directo.");
        string antesMoverFuera = MYGProyectoStorage.Firma(proyecto);
        int historialAntesMoverFuera = firmasAntes.Count, historialDespuesMoverFuera = firmasDespues.Count;
        Invocar(panel, "ModificarOrdenResumenPie", (int?)-1);
        exige(MYGProyectoStorage.Firma(proyecto) == antesMoverFuera && firmasAntes.Count == historialAntesMoverFuera &&
                firmasDespues.Count == historialDespuesMoverFuera,
            "Intentar subir la primera fila personalizada debe conservar los datos sin registrar una edición vacía.");
        VerificarCambio(() => Invocar(panel, "ModificarOrdenResumenPie", (int?)1));
        exige(primero.Costos.PiePersonalizado.Select(f => f.Id).SequenceEqual(new[] { administracion.Id, seguridad.Id }) &&
                TotalCalculado(primero) == 120m && ImporteVisible("Administración") == MYGFormatoPresupuesto.Dinero(10m) &&
                tabla.CurrentRow?.Tag is MYGFilaResumenPie elegida && elegida.Id == seguridad.Id,
            "Bajar una fila debe conservar su selección, reordenar sus conceptos y recalcular las bases acumuladas.");
        Invocar(panel, "ActualizarMenuResumen");
        exige(Opcion("subirFilaResumen").Enabled && !Opcion("bajarFilaResumen").Enabled,
            "La última fila personalizada debe permitir subir y deshabilitar Bajar.");

        var portapapelesAnterior = Clipboard.GetDataObject();
        try
        {
            string firmaAntesCopiar = MYGProyectoStorage.Firma(proyecto);
            int antesCopiar = firmasAntes.Count, despuesCopiar = firmasDespues.Count;
            Invocar(panel, "CopiarResumenPie");
            exige(Clipboard.ContainsData("MYG.Presupuestos.Resumen.v1") &&
                    MYGProyectoStorage.Firma(proyecto) == firmaAntesCopiar && firmasAntes.Count == antesCopiar &&
                    firmasDespues.Count == despuesCopiar,
                "Copiar resumen debe colocar un resumen MYG en el portapapeles sin cambiar el proyecto ni registrar historial.");
            Activar(segundo);
            Invocar(panel, "ActualizarMenuResumen");
            exige(Opcion("pegarResumen").Enabled,
                "Pegar resumen debe habilitarse cuando el portapapeles contiene un resumen MYG.");
            VerificarCambio(() => Invocar(panel, "PegarResumenPie"));
            exige(segundo.Costos.PiePersonalizado.Select(f => (f.Id, f.Nombre, f.Porcentaje, f.Base))
                    .SequenceEqual(primero.Costos.PiePersonalizado.Select(f => (f.Id, f.Nombre, f.Porcentaje, f.Base))) &&
                    Tasas(segundo) == tasasPrimero && TotalCalculado(primero) == 120m &&
                    TotalCalculado(segundo) == 240m && ImporteVisible("Total") == MYGFormatoPresupuesto.Dinero(240m),
                "Pegar por presupuesto debe copiar conceptos, orden, bases y tasas, calculando con el costo directo del destino.");
            SeleccionarFila(2);
            VerificarCambio(() => Invocar(panel, "ModificarOrdenResumenPie", new object[] { null }));
            exige(segundo.Costos.PiePersonalizado.Count == 1 && segundo.Costos.PiePersonalizado[0].Id == administracion.Id &&
                    primero.Costos.PiePersonalizado.Count == 2 && TotalCalculado(primero) == 120m &&
                    TotalCalculado(segundo) == 220m && ImporteVisible("Total") == MYGFormatoPresupuesto.Dinero(220m),
                "Eliminar una fila pegada debe afectar sólo al destino y recalcular su total sin modificar el resumen copiado.");
            SeleccionarFila(1);
            Invocar(panel, "ActualizarMenuResumen");
            exige(Opcion("eliminarFilaResumen").Enabled && !Opcion("subirFilaResumen").Enabled && !Opcion("bajarFilaResumen").Enabled,
                "Una única fila personalizada debe poder eliminarse y tener ambos movimientos deshabilitados.");
            CambiarAlcance(proyectoCompleto: true);
            Invocar(panel, "ActualizarMenuResumen");
            exige(!Opcion("copiarResumen").Enabled && Opcion("pegarResumen").Enabled &&
                    ImporteVisible("Total") == MYGFormatoPresupuesto.Dinero(340m),
                "Un proyecto con pies distintos debe sumar sus propios totales, impedir copiar un resumen ambiguo y permitir pegar uno común.");
            VerificarCambio(() => Invocar(panel, "PegarResumenPie"));
            exige(proyecto.Presupuestos.All(p => p.Costos.PiePersonalizado.Count == 2) &&
                    TotalCalculado(primero) == 120m && TotalCalculado(segundo) == 240m &&
                    ImporteVisible("Total") == MYGFormatoPresupuesto.Dinero(360m),
                "Pegar por proyecto debe aplicar el resumen común a todos los presupuestos en una sola transacción y recalcular la suma.");
        }
        finally
        {
            if (portapapelesAnterior == null) Clipboard.Clear();
            else Clipboard.SetDataObject(portapapelesAnterior, true);
        }
        formulario.Close();

        ToolStripMenuItem Opcion(string nombre) => menu.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == nombre);
        ToolStripMenuItem OpcionAlcance(string nombre) => boton.DropDownItems.OfType<ToolStripMenuItem>().Single(i => i.Name == nombre);

        void SeleccionarFila(int indice)
        {
            tabla.ClearSelection();
            tabla.CurrentCell = tabla.Rows[indice].Cells["CONCEPTO"];
            tabla.Rows[indice].Selected = true;
        }

        string ImporteVisible(string concepto) => Convert.ToString(tabla.Rows.Cast<DataGridViewRow>()
            .Single(f => Convert.ToString(f.Cells["CONCEPTO"].Value) == concepto).Cells["IMPORTE"].Value);

        void VerificarMenu(bool limpiado, bool puedeCopiar = true)
        {
            Invocar(panel, "ActualizarMenuResumen");
            menu.Show(tabla, new Point(8, 8));
            Application.DoEvents();
            exige(menu.Visible && Opcion("agregarFilaResumen").Visible == limpiado &&
                    Opcion("limpiarResumenContextual").Visible == !limpiado &&
                    Opcion("restaurarResumen").Visible == limpiado &&
                    !Opcion("eliminarFilaResumen").Enabled && !Opcion("subirFilaResumen").Enabled &&
                    !Opcion("bajarFilaResumen").Enabled && Opcion("copiarResumen").Enabled == puedeCopiar &&
                    Opcion("fuenteResumen").Enabled,
                "El anticlic debe cambiar entre limpiar y restaurar, permitir agregar tras limpiar y proteger las filas fijas.");
            menu.Close();
        }

        void CambiarAlcance(bool proyectoCompleto)
        {
            string firma = MYGProyectoStorage.Firma(proyecto);
            int cantidadAntes = firmasAntes.Count, cantidadDespues = firmasDespues.Count;
            OpcionAlcance(proyectoCompleto ? "piePorProyecto" : "piePorPresupuesto").PerformClick();
            Application.DoEvents();
            exige(selector.SelectedIndex == (proyectoCompleto ? 1 : 0) &&
                    OpcionAlcance("piePorProyecto").Checked == proyectoCompleto &&
                    OpcionAlcance("piePorPresupuesto").Checked == !proyectoCompleto &&
                    MYGProyectoStorage.Firma(proyecto) == firma && firmasAntes.Count == cantidadAntes &&
                    firmasDespues.Count == cantidadDespues,
                "El desplegable debe marcar un único alcance y cambiar la vista sin modificar el proyecto ni su historial.");
        }

        void Activar(MYGPresupuestoDocumento presupuesto)
        {
            panel.SeleccionarEstructura(presupuesto);
            Application.DoEvents();
            exige(ReferenceEquals(activo, presupuesto),
                "Seleccionar un presupuesto del árbol debe actualizar el presupuesto activo del resumen.");
        }

        void EditarPorcentaje(decimal porcentaje)
        {
            tabla.CurrentCell = tabla.Rows[1].Cells["PORC"];
            tabla.Focus();
            exige(tabla.IsCurrentCellInEditMode || tabla.BeginEdit(true),
                "El porcentaje del resumen debe poder entrar en edición.");
            exige(tabla.EditingControl is DataGridViewTextBoxEditingControl,
                "El resumen debe ofrecer un editor numérico para el porcentaje.");
            ((DataGridViewTextBoxEditingControl)tabla.EditingControl).Text = porcentaje.ToString("0.####");
            panel.FinalizarEdicion();
            panel.Refrescar();
        }

        void VerificarCambio(Action accion)
        {
            string firma = MYGProyectoStorage.Firma(proyecto);
            int cantidadAntes = firmasAntes.Count, cantidadDespues = firmasDespues.Count;
            accion();
            Application.DoEvents();
            exige(firmasAntes.Count == cantidadAntes + 1 && firmasDespues.Count == cantidadDespues + 1 &&
                    firmasAntes.Last() == firma && firmasDespues.Last() == MYGProyectoStorage.Firma(proyecto) &&
                    firmasAntes.Last() != firmasDespues.Last(),
                "Cada edición del resumen debe registrar una sola transacción con el estado anterior y el estado final correctos.");
        }

        void VerificarImportesPredeterminados(IEnumerable<MYGPresupuestoDocumento> presupuestos)
        {
            var resumen = MYGPiePresupuesto.Resumen(presupuestos);
            decimal[] importes = { resumen.CostoDirecto, resumen.GastosGenerales, resumen.Utilidad, resumen.Subtotal,
                resumen.Impuesto, resumen.OtrosImpuestos, resumen.Total };
            exige(tabla.Rows.Count == importes.Length && tabla.Rows.Cast<DataGridViewRow>()
                    .Select(f => Convert.ToString(f.Cells["IMPORTE"].Value)).SequenceEqual(importes.Select(MYGFormatoPresupuesto.Dinero)),
                "El pie predeterminado debe mostrar los importes del motor para el alcance seleccionado, conservando cada tasa.");
        }
    }

    private static void Preparar(MYGPresupuestoDocumento presupuesto, decimal directo, decimal gastos,
        decimal utilidad, decimal impuesto, decimal otros)
    {
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        partida.Descripcion = "PARTIDA " + presupuesto.Nombre;
        partida.Costos.Cantidad = 1m;
        partida.Costos.PrecioDirecto = directo;
        presupuesto.Costos.GastosGeneralesPorcentaje = gastos;
        presupuesto.Costos.UtilidadPorcentaje = utilidad;
        presupuesto.Costos.ImpuestoPorcentaje = impuesto;
        presupuesto.Costos.OtrosImpuestosPorcentaje = otros;
    }

    private static (decimal Gastos, decimal Utilidad, decimal Impuesto, decimal Otros) Tasas(MYGPresupuestoDocumento p) =>
        (p.Costos.GastosGeneralesPorcentaje, p.Costos.UtilidadPorcentaje, p.Costos.ImpuestoPorcentaje, p.Costos.OtrosImpuestosPorcentaje);

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static decimal TotalCalculado(MYGPresupuestoDocumento presupuesto) => MYGMotorPresupuestos.Resumen(presupuesto).Total;

    private static void Invocar(object objeto, string nombre, params object[] argumentos) =>
        objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
