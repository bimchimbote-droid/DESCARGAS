using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class PiePersonalizadoCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (InvalidOperationException) { return; }
        throw new Exception("Se aceptó una modificación inválida del pie de presupuesto.");
    }

    private static MYGPresupuestoDocumento Directo(string nombre, decimal importe)
    {
        var p = new MYGPresupuestoDocumento { Nombre = nombre };
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        partida.Descripcion = "PARTIDA " + nombre;
        partida.Costos.Cantidad = 1;
        partida.Costos.PrecioDirecto = importe;
        return p;
    }

    private static MYGProyectoDocumento Proyecto(params MYGPresupuestoDocumento[] presupuestos)
    {
        for (int n = 0; n < presupuestos.Length; n++)
        {
            presupuestos[n].Item = (n + 1).ToString("00");
            presupuestos[n].Posicion = n + 1;
        }
        var doc = new MYGProyectoDocumento
        {
            Nombre = "PROYECTO PIES PERSONALIZADOS QA",
            Datos = new MYGDatosProyecto { UsarUbicacion = false },
            Presupuestos = presupuestos.ToList(),
            PresupuestoActivoId = presupuestos[0].Id
        };
        MYGProyectoStorage.Validar(doc);
        return doc;
    }

    private static MYGFilaPiePersonalizada Concepto(string id, string nombre, decimal porcentaje,
        MYGBaseFilaPie baseCalculo = MYGBaseFilaPie.CostoDirecto) =>
        new() { Id = id, Nombre = nombre, Porcentaje = porcentaje, Base = baseCalculo };

    private static decimal Total(MYGPresupuestoDocumento p) => MYGMotorPresupuestos.Resumen(p).Total;

    private static int Fila(MYGHojaMetrado hoja, string nombre)
    {
        var calculo = new MYGHojaCalculo(hoja);
        return hoja.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == 2 &&
                string.Equals(calculo.Mostrar(c.Key), nombre, StringComparison.OrdinalIgnoreCase))
            .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).DefaultIfEmpty(-1).First();
    }

    private static decimal Importe(MYGHojaMetrado hoja, string nombre) =>
        new MYGHojaCalculo(hoja).Numero("F" + Fila(hoja, nombre));

    private static decimal TotalSQLite(string ruta, string nombre)
    {
        using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString());
        conexion.Open();
        using var comando = conexion.CreateCommand();
        comando.CommandText = "SELECT total_presupuesto FROM presupuesto WHERE nombre_presupuesto = $nombre";
        comando.Parameters.AddWithValue("$nombre", nombre);
        return Convert.ToDecimal(comando.ExecuteScalar());
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        LimpiarYRestaurar(pasa);
        FormulasYRedondeo(pasa);
        AlcancesConPiesDistintos(pasa);
        ValidacionAtomica(pasa);
        Persistencia(carpeta, pasa);
        Informes(pasa);
    }

    private static void LimpiarYRestaurar(Action<string> pasa)
    {
        var a = Directo("LIMPIAR A", 1000);
        var b = Directo("LIMPIAR B", 2000);
        a.Costos.GastosGeneralesPorcentaje = 10;
        a.Costos.UtilidadPorcentaje = 5;
        a.Costos.ImpuestoPorcentaje = 18;
        a.Costos.OtrosImpuestosPorcentaje = 2;
        b.Costos.UtilidadPorcentaje = 20;
        var doc = Proyecto(a, b);
        decimal totalA = Total(a), totalB = Total(b);
        string firmaB = JsonSerializer.Serialize(b);
        Exige(MYGPiePresupuesto.Filas(new[] { a }).Count == 7,
            "Un presupuesto anterior debe conservar las siete filas de su resumen predeterminado.");

        MYGPiePresupuesto.Limpiar(new[] { a });
        var filas = MYGPiePresupuesto.Filas(new[] { a });
        var resumen = MYGMotorPresupuestos.Resumen(a);
        Exige(a.Costos.PiePersonalizado is { Count: 0 } && filas.Count == 1 &&
            filas[0].Id == MYGPiePresupuesto.IdCostoDirecto && filas[0].Importe == 1000 &&
            resumen.Total == 1000 && resumen.Subtotal == 1000 && resumen.GastosGenerales == 0 &&
            resumen.Utilidad == 0 && resumen.Impuesto == 0 && resumen.OtrosImpuestos == 0,
            "Limpiar debe dejar sólo costo directo e inactivar todos los conceptos eliminados.");
        Exige(a.Costos.GastosGeneralesPorcentaje == 10 && a.Costos.UtilidadPorcentaje == 5 &&
            a.Costos.ImpuestoPorcentaje == 18 && a.Costos.OtrosImpuestosPorcentaje == 2 &&
            JsonSerializer.Serialize(b) == firmaB && Total(b) == totalB,
            "Limpiar un presupuesto perdió las tasas restaurables o modificó otro presupuesto.");
        string limpioAntes = MYGProyectoStorage.Firma(doc);
        Rechaza(() => MYGPiePresupuesto.AplicarPorcentaje(new[] { a }, MYGConceptoPie.IGV, 99));
        Exige(MYGProyectoStorage.Firma(doc) == limpioAntes,
            "Editar un porcentaje estándar inactivo no debe modificar el pie limpiado ni sus tasas restaurables.");
        MYGPiePresupuesto.RestaurarPredeterminado(new[] { a });
        Exige(a.Costos.PiePersonalizado == null && Total(a) == totalA &&
            MYGPiePresupuesto.Filas(new[] { a }).Count == 7,
            "Restaurar el resumen predeterminado no recuperó sus conceptos y tasas originales.");

        MYGPiePresupuesto.Limpiar(doc.Presupuestos);
        Exige(doc.Presupuestos.All(p => p.Costos.PiePersonalizado is { Count: 0 }) &&
            MYGPiePresupuesto.Filas(doc.Presupuestos).Count == 1 && MYGPiePresupuesto.Resumen(doc.Presupuestos).Total == 3000,
            "Limpiar todo el proyecto debe eliminar los conceptos de todos sus presupuestos.");
        MYGPiePresupuesto.RestaurarPredeterminado(doc.Presupuestos);
        Exige(Total(a) == totalA && Total(b) == totalB,
            "Restaurar el proyecto homogeneizó los porcentajes distintos de sus presupuestos.");
        pasa("Limpiar respeta el alcance individual o del proyecto, deja sólo costo directo y permite restaurar las tasas originales");
    }

    private static void FormulasYRedondeo(Action<string> pasa)
    {
        var p = Directo("FORMULAS PIE", 1000);
        p.Costos.ImpuestoPorcentaje = 18;
        Proyecto(p);
        var filas = new List<MYGFilaPiePersonalizada>
        {
            Concepto("administracion", "Administración propia", 10),
            Concepto("tributo", "Tributo propio", 18, MYGBaseFilaPie.Acumulado),
            Concepto("seguro", "Seguro propio", 2)
        };
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, filas);
        Exige(MYGPiePresupuesto.Filas(new[] { p }).Select(f => f.Importe).SequenceEqual(new[] { 1000m, 100m, 198m, 20m }) &&
            Total(p) == 1318 && MYGMotorPresupuestos.Resumen(p).Impuesto == 0,
            "El pie personalizado no aplicó cada porcentaje sobre costo directo o acumulado en su orden.");
        filas[0].Porcentaje = 99;
        Exige(p.Costos.PiePersonalizado[0].Porcentaje == 10,
            "El pie guardado comparte referencias con las filas proporcionadas por el editor o portapapeles.");
        var reordenadas = MYGProyectoStorage.Copia(p.Costos.PiePersonalizado);
        reordenadas.Reverse();
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { p }, reordenadas);
        Exige(Total(p) == 1303.6m,
            "Reordenar una fila de base acumulada debe recalcularla sobre los conceptos que la preceden.");

        var redondeo = Directo("REDONDEO PIE", 0.05m);
        Proyecto(redondeo);
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { redondeo }, new()
        {
            Concepto("primer-centavo", "Primer centavo", 10),
            Concepto("segundo-centavo", "Segundo centavo", 10, MYGBaseFilaPie.Acumulado)
        });
        Exige(MYGPiePresupuesto.Filas(new[] { redondeo }).Select(f => f.Importe)
            .SequenceEqual(new[] { 0.05m, 0.01m, 0.01m }) && Total(redondeo) == 0.07m,
            "Cada concepto debe respetar el redondeo monetario antes de calcular la siguiente base acumulada.");
        pasa("Pie personalizado calcula bases directas y acumuladas según el orden, conserva copias y redondea cada concepto");
    }

    private static void AlcancesConPiesDistintos(Action<string> pasa)
    {
        var a = Directo("DIFERENTES A", 1000);
        var b = Directo("DIFERENTES B", 2000);
        Proyecto(a, b);
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { a }, new() { Concepto("gestion", "Gestión propia", 10) });
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { b }, new()
        {
            Concepto("gestion", "Gestión propia", 20),
            Concepto("seguro", "Seguro particular", 5, MYGBaseFilaPie.Acumulado)
        });
        var filas = MYGPiePresupuesto.Filas(new[] { a, b });
        Exige(filas.Count == 3 && filas.Single(f => f.Id == MYGPiePresupuesto.IdCostoDirecto).Importe == 3000 &&
            filas.Single(f => f.Id == "gestion").Importe == 500 && filas.Single(f => f.Id == "gestion").Porcentaje == null &&
            filas.Single(f => f.Id == "seguro").Importe == 120 && filas.Single(f => f.Id == "seguro").Porcentaje == null &&
            !filas.Single(f => f.Id == "seguro").Editable && MYGPiePresupuesto.Resumen(new[] { a, b }).Total == 3620,
            "El resumen del proyecto debe sumar los pies distintos sin inventar una tasa común ni recalcular una base global.");
        Exige(MYGPiePresupuesto.Filas(new[] { a }).Single(f => f.Id == "gestion").Porcentaje == 10 &&
            MYGPiePresupuesto.Filas(new[] { b }).Single(f => f.Id == "gestion").Porcentaje == 20,
            "Cambiar de alcance perdió los porcentajes propios de cada presupuesto.");
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { a, b }, new() { Concepto("comun", "Concepto común", 7) });
        a.Costos.PiePersonalizado[0].Porcentaje = 9;
        Exige(b.Costos.PiePersonalizado[0].Porcentaje == 7 && Total(a) == 1090 && Total(b) == 2140,
            "Aplicar un mismo pie al proyecto debe mantener copias independientes para futuras ediciones individuales.");
        Exige(MYGPiePresupuesto.Filas(Array.Empty<MYGPresupuestoDocumento>()).Count == 0 &&
            MYGPiePresupuesto.Resumen(Array.Empty<MYGPresupuestoDocumento>()).Total == 0,
            "El alcance vacío debe producir un resumen vacío.");
        pasa("Alcance de proyecto suma pies y tasas diferentes sin homogeneizarlos y cada presupuesto mantiene su propia copia");
    }

    private static void ValidacionAtomica(Action<string> pasa)
    {
        var a = Directo("ATOMICO A", 100);
        var b = Directo("ATOMICO B", 200);
        var doc = Proyecto(a, b);
        var invalidas = new List<MYGFilaPiePersonalizada>[]
        {
            new() { Concepto("", "Sin identificador", 1) },
            new() { Concepto("sin-nombre", " ", 1) },
            new() { Concepto(MYGPiePresupuesto.IdCostoDirecto, "Reservado", 1) },
            new() { Concepto(MYGPiePresupuesto.IdTotal, "Reservado total", 1) },
            new() { Concepto("duplicada", "Primera", 1), Concepto("DUPLICADA", "Segunda", 2) },
            new() { Concepto("negativo", "Negativo", -1) },
            new() { Concepto("excesivo", "Excesivo", 10001) },
            new() { Concepto("precision", "Precisión", 0.12345m) },
            new() { Concepto("base", "Base desconocida", 1, (MYGBaseFilaPie)999) },
            new() { null }
        };
        string antes = MYGProyectoStorage.Firma(doc);
        foreach (var filas in invalidas)
        {
            Rechaza(() => MYGPiePresupuesto.EstablecerPersonalizado(doc.Presupuestos, filas));
            Exige(MYGProyectoStorage.Firma(doc) == antes,
                "Una definición inválida modificó parcialmente los presupuestos del proyecto.");
        }
        b.Costos.Moneda = "USD";
        antes = MYGProyectoStorage.Firma(doc);
        Rechaza(() => MYGPiePresupuesto.Limpiar(doc.Presupuestos));
        Rechaza(() => MYGPiePresupuesto.RestaurarPredeterminado(doc.Presupuestos));
        Rechaza(() => MYGPiePresupuesto.EstablecerPersonalizado(doc.Presupuestos,
            new() { Concepto("valida", "Fila válida", 5) }));
        Rechaza(() => MYGPiePresupuesto.Filas(doc.Presupuestos));
        Exige(MYGProyectoStorage.Firma(doc) == antes,
            "Una operación con monedas mezcladas dejó cambios parciales en el proyecto.");
        b.Costos.Moneda = "S/";
        b.Items[0].Costos.PrecioDirecto = -1;
        antes = MYGProyectoStorage.Firma(doc);
        Rechaza(() => MYGPiePresupuesto.Limpiar(doc.Presupuestos));
        Rechaza(() => MYGPiePresupuesto.EstablecerPersonalizado(doc.Presupuestos,
            new() { Concepto("valida", "Fila válida", 5) }));
        Exige(MYGProyectoStorage.Firma(doc) == antes,
            "Un presupuesto inválido al final del alcance no debe dejar modificado el primer presupuesto.");
        pasa("Filas incompletas, duplicadas, tasas o bases inválidas y monedas distintas se rechazan sin modificaciones parciales");
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var predeterminado = Directo("PERSISTIR PREDETERMINADO", 100);
        var limpio = Directo("PERSISTIR LIMPIO", 200);
        var personalizado = Directo("PERSISTIR PERSONALIZADO", 300);
        predeterminado.Costos.ImpuestoPorcentaje = 18;
        limpio.Costos.GastosGeneralesPorcentaje = 11;
        limpio.Costos.ImpuestoPorcentaje = 18;
        personalizado.Costos.UtilidadPorcentaje = 25;
        var doc = Proyecto(predeterminado, limpio, personalizado);
        MYGPiePresupuesto.Limpiar(new[] { limpio });
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { personalizado }, new()
        {
            Concepto("gestion-persistida", "Gestión persistida", 10),
            Concepto("tributo-persistido", "Tributo persistido", 5, MYGBaseFilaPie.Acumulado)
        });
        string ruta = Path.Combine(carpeta, "Pies personalizados.myg.json");
        MYGProyectoStorage.Guardar(ruta, doc);
        using (var json = JsonDocument.Parse(File.ReadAllText(ruta)))
        {
            var presupuestos = json.RootElement.GetProperty("Presupuestos");
            Exige(!presupuestos[0].GetProperty("Costos").TryGetProperty("PiePersonalizado", out _) &&
                presupuestos[1].GetProperty("Costos").GetProperty("PiePersonalizado").GetArrayLength() == 0 &&
                presupuestos[2].GetProperty("Costos").GetProperty("PiePersonalizado").GetArrayLength() == 2,
                "El archivo JSON debe distinguir el pie predeterminado ausente de un pie limpio o personalizado.");
        }
        foreach (var reabierto in new[] { MYGProyectoStorage.Leer(ruta), MYGBaseDatos.LeerProyecto(MYGBaseDatos.RutaDeProyecto(ruta), doc.Id) })
        {
            var estandar = reabierto.Presupuestos.Single(p => p.Id == predeterminado.Id);
            var vacio = reabierto.Presupuestos.Single(p => p.Id == limpio.Id);
            var propio = reabierto.Presupuestos.Single(p => p.Id == personalizado.Id);
            Exige(estandar.Costos.PiePersonalizado == null && Total(estandar) == 118 &&
                vacio.Costos.PiePersonalizado is { Count: 0 } && Total(vacio) == 200 &&
                propio.Costos.PiePersonalizado is { Count: 2 } && Total(propio) == 346.5m &&
                propio.Costos.PiePersonalizado[1].Base == MYGBaseFilaPie.Acumulado &&
                propio.Costos.PiePersonalizado[0].Id == "gestion-persistida",
                "Reabrir JSON o SQLite perdió el estado, orden, identificador o fórmula del pie.");
            MYGPiePresupuesto.RestaurarPredeterminado(new[] { vacio, propio });
            Exige(Total(vacio) == 261.96m && Total(propio) == 375,
                "La persistencia perdió las tasas originales necesarias para restaurar el resumen.");
        }
        Exige(TotalSQLite(MYGBaseDatos.RutaDeProyecto(ruta), limpio.Nombre) == 200 &&
            TotalSQLite(MYGBaseDatos.RutaDeProyecto(ruta), personalizado.Nombre) == 346.5m,
            "Las columnas de total nativas de SQLite deben coincidir con los conceptos activos del pie.");
        pasa("JSON y SQLite conservan pies predeterminados, limpios y personalizados, tasas restaurables y totales nativos coherentes");
    }

    private static void Informes(Action<string> pasa)
    {
        var a = Directo("INFORME PIE PROPIO", 1000);
        var b = Directo("INFORME PIE ESTANDAR", 2000);
        a.Costos.GastosGeneralesPorcentaje = 99;
        a.Costos.ImpuestoPorcentaje = 18;
        b.Costos.UtilidadPorcentaje = 5;
        var doc = Proyecto(a, b);
        MYGPiePresupuesto.EstablecerPersonalizado(new[] { a }, new()
        {
            Concepto("gestion-informe", "Gestión especial impresa", 10),
            Concepto("tributo-informe", "Tributo especial impreso", 18, MYGBaseFilaPie.Acumulado)
        });
        string antes = MYGProyectoStorage.Firma(doc);
        foreach (var hoja in new[]
        {
            MYGReportesProyecto.Crear(doc, a.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado).Single().Hoja,
            MYGReportesProyecto.CrearResumenPresupuesto(doc, a.Id).Hoja
        })
            Exige(Importe(hoja, "Gestión especial impresa") == 100 && Importe(hoja, "Tributo especial impreso") == 198 &&
                Fila(hoja, "Gastos generales") == -1 && Fila(hoja, "I.G.V.") == -1 &&
                new MYGHojaCalculo(hoja).Numero(hoja.CeldaTotal) == 1298 && Importe(hoja, "Total") == 1298,
                "El reporte individual debe imprimir sólo conceptos activos y conservar un total matemático correcto.");
        var global = MYGReportesProyecto.Crear(doc, a.Id, MYGTipoReporteProyecto.HojaResumen).Single().Hoja;
        Exige(Importe(global, "Costo directo") == 3000 && Importe(global, "Gestión especial impresa") == 100 &&
            Importe(global, "Utilidad") == 100 && new MYGHojaCalculo(global).Numero(global.CeldaTotal) == 3398,
            "La hoja global debe combinar los pies estándar y personalizados sin perder el total del proyecto.");
        Exige(MYGProyectoStorage.Firma(doc) == antes,
            "Generar informes cambió el pie o los porcentajes editables del proyecto.");

        MYGPiePresupuesto.Limpiar(doc.Presupuestos);
        foreach (var hoja in new[]
        {
            MYGReportesProyecto.Crear(doc, a.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado).Single().Hoja,
            MYGReportesProyecto.CrearResumenPresupuesto(doc, a.Id).Hoja,
            MYGReportesProyecto.Crear(doc, a.Id, MYGTipoReporteProyecto.HojaResumen).Single().Hoja
        })
            Exige(Fila(hoja, "Costo directo") > 0 && Fila(hoja, "Total") == -1 &&
                Fila(hoja, "Gastos generales") == -1 && Fila(hoja, "I.G.V.") == -1 &&
                Fila(hoja, "Gestión especial impresa") == -1 &&
                new MYGHojaCalculo(hoja).Numero(hoja.CeldaTotal) == (Importe(hoja, "Costo directo")),
                "El informe de un pie limpio debe mostrar sólo costo directo, sin conceptos o porcentajes obsoletos.");
        pasa("Informes individuales y globales reflejan conceptos personalizados o limpios y conservan totales sin modificar el proyecto");
    }
}
