# Resumen por presupuesto o proyecto y pie personalizado

Entrega preparada sobre `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`, commit base `e2c5b771f127f5773d499325c7799a7a08653e85`.

## Uso

- El botón **Resumen** permite elegir **Pie resumen por presupuesto** o **Pie resumen único por proyecto**.
- Cambiar de vista no cambia porcentajes ni conceptos. Por presupuesto se edita sólo el presupuesto activo; por proyecto la edición se aplica a todos los presupuestos del proyecto.
- Si hay porcentajes distintos aparece **Varios**. Escribir una tasa en el alcance del proyecto aplica esa tasa a todos, conservando las de los otros conceptos.
- **Limpiar resumen** elimina los conceptos activos del alcance elegido y deja sólo **Costo directo**. Su total pasa a ser el costo directo; no borra partidas, insumos ni metrados.
- Las tasas del resumen predeterminado quedan guardadas, pero no se aplican mientras el pie esté limpio o personalizado. **Mostrar Resumen predeterminado** recupera esas tasas.
- El clic derecho del resumen predeterminado incluye editar, eliminar, subir, bajar, copiar, pegar, limpiar y fuente, con iconos. Las filas calculadas están protegidas; eliminar y mover se habilitan para los conceptos personalizados.
- Después de limpiar, el clic derecho ofrece **Agregar fila bajo la selección** y **Mostrar Resumen predeterminado**. Cada concepto nuevo tiene nombre, porcentaje y base: **Costo directo** o **Acumulado de las filas anteriores**. Su importe se suma al total. El orden importa para la base acumulada.
- Se puede editar, eliminar y ordenar los conceptos personalizados. Seleccionar Costo directo e insertar agrega al inicio; seleccionar Total agrega al final. Con conceptos personalizados se muestra también el total calculado.
- **Copiar resumen / Pegar resumen** copia conceptos y tasas, sin copiar moneda, partidas ni insumos. Pegar actúa sobre el alcance seleccionado. Cuando el proyecto tiene pies o tasas distintos, copie desde un presupuesto concreto para elegir cuál usar.
- Los pies con estructuras distintas se pueden consultar juntos, pero sus filas se editan por presupuesto. Limpiar o pegar un resumen común permite uniformarlos. Los informes conservan los totales de cada presupuesto y su redondeo.
- **Fuente** cambia la presentación del panel durante la sesión; no modifica los importes ni se guarda en el proyecto.

## Archivos de esta entrega

| Archivo | Acción | Función |
|---|---|---|
| MYG.Core/PresupuestosModelos.cs | REEMPLAZAR | Modelo de conceptos personalizados. |
| MYG.Core/PiePresupuestoMYG.cs | REEMPLAZAR | Limpiar, restaurar, validar y agregar pies por alcance. |
| MYG.Core/CalculoPresupuestoMYG.cs | REEMPLAZAR | Cálculo de los conceptos activos. |
| MYG.Core/MotorPresupuestos.cs | REEMPLAZAR | Validación, plantillas y compatibilidad de firmas. |
| MYG.Core/ReportesProyectoMYG.cs | REEMPLAZAR | Informes con pie personalizado y total coherente. |
| MYG.Desktop/PresupuestosPiePanel.cs | REEMPLAZAR | Selector, edición y visualización del resumen. |
| MYG.Desktop/PresupuestosExcelPanel.cs | REEMPLAZAR | Consulta e impresión coherentes con el pie personalizado. |
| MYG.Desktop/PresupuestosResumenMenu.cs | CREAR | Menús, portapapeles y operaciones con historial. |
| MYG.Desktop/EditarFilaResumenForm.cs | CREAR | Edición de nombre, porcentaje y base del concepto. |
| MYG.Desktop/ResumenPieIconos.cs | CREAR | Iconos del resumen y sus acciones. |
| MYG.Pruebas/Program.cs | REEMPLAZAR | Registra las pruebas funcionales nuevas. |
| MYG.Pruebas/PiePersonalizadoCheck.cs | CREAR | Pruebas de cálculo, alcance, persistencia e informes. |
| MYG.PruebasUI/Program.cs | REEMPLAZAR | Registra las pruebas de interfaz nuevas. |
| MYG.PruebasUI/ResumenPersonalizadoUICheck.cs | CREAR | Pruebas de menús, edición, selección y alcance. |
| ACTUALIZACION_RESUMEN_PERSONALIZADO.md | CREAR | Estas instrucciones. |

## Instalación manual

1. Cierre MYG. Respalde el proyecto, sus bases y sus cambios locales, o haga un commit desde **Cambios de Git** en Visual Studio.
2. Verifique que su código corresponde al commit base indicado. Si contiene cambios posteriores o locales en alguno de estos archivos, compare y combine las diferencias antes de reemplazarlos.
3. Descargue el ZIP de esta entrega y extráigalo en una carpeta temporal.
4. Copie los archivos a la raíz de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, conservando las subcarpetas. Sustituya sólo los archivos marcados REEMPLAZAR y agregue los marcados CREAR. No hay eliminaciones ni parches que aplicar.
5. Los proyectos SDK incluyen los nuevos `.cs` automáticamente: no cambie `.csproj`, la solución ni las dependencias.
6. Restaure, compile y ejecute las comprobaciones indicadas abajo.

## Compilación y validación

Tecnologías: C#, SDK .NET **10.0.100**, WinForms/WPF, Microsoft.Data.Sqlite **10.0.0**, SQLitePCLRaw.lib.e_sqlite3 **2.1.12** y referencias Revit **2027.0.0**. No se agregaron paquetes, servicios, variables ni migraciones SQL.

Desde la raíz del repositorio, estos comandos usan las referencias de Revit previstas para compilar sin una instalación local de Autodesk:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

En Windows, ejecute además las pruebas de interfaz:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

En la máquina Linux de preparación: compilación completa aprobada y **386 comprobaciones funcionales aprobadas**. Se validaron limpieza individual/global, recuperación de tasas, bases de cálculo, redondeo, validación atómica, JSON/SQLite e informes. Las pruebas UI se compilaron, pero **no se ejecutaron**. La prueba de Named Pipes de Windows se omite explícitamente en Linux. Las muestras externas opcionales de obras y Delphin no forman parte de esta entrega.

Comprobación manual pendiente en Windows: abra un proyecto de prueba con dos presupuestos y tasas diferentes; cambie ambos alcances; edite una tasa en cada uno; limpie y restaure; agregue y ordene conceptos; pruebe copiar/pegar, fuente, deshacer/rehacer; guarde y reabra el proyecto y revise sus informes. Confirme la presentación de los iconos y ambos menús con su escala de pantalla y tema.

## GitHub y límites

Esta entrega se publica únicamente como ZIP en el repositorio independiente `bimchimbote-droid/DESCARGAS`. No se hace commit, push ni fusión en el repositorio del código.

Después de aplicar y validar: abra **Cambios de Git** en Visual Studio, revise los archivos, confirme que la rama elegida es `main` (o su rama de trabajo), haga Commit y luego Push cuando corresponda. Verifique el commit y los archivos en la misma rama de GitHub.

La personalización se conserva en los formatos JSON/SQLite **MYG**, incluyendo sus metadatos. Delphin externo y una importación que elimine los metadatos `myg_*` no pueden reconstruir los conceptos personalizados; Delphin puede recalcular las tasas predeterminadas retenidas. Valide esa interoperabilidad por separado y conserve el archivo MYG original. No se validaron la ejecución visual en Windows, una licencia real, el instalador ni una sesión real de Revit.
