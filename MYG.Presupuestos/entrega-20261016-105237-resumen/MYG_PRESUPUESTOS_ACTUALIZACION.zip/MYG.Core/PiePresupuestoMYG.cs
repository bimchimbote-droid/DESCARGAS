using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGConceptoPie { GastosGenerales, Utilidad, IGV, OtrosImpuestos }

public sealed class MYGFilaResumenPie
{
    public string Id { get; set; }
    public string Nombre { get; set; }
    public decimal? Porcentaje { get; set; }
    public decimal Importe { get; set; }
    public bool Editable { get; set; }
    public MYGConceptoPie? Concepto { get; set; }
}

public sealed class MYGIncidenciaCosto
{
    public string Nombre { get; set; }
    public decimal Importe { get; set; }
    public decimal Porcentaje { get; set; }
}

public static class MYGPiePresupuesto
{
    public const string IdCostoDirecto = "costo-directo";
    public const string IdTotal = "total";
    private static readonly HashSet<string> idsPredeterminados = new(StringComparer.OrdinalIgnoreCase)
    { IdCostoDirecto, "gastos-generales", "utilidad", "parcial", "igv", "otros-impuestos", IdTotal };

    private static void ValidarPorcentaje(decimal valor)
    {
        if (valor < 0 || valor > 10000 || decimal.Round(valor, 4) != valor)
            throw new InvalidDataException("El porcentaje debe estar entre 0 y 10000 y tener como máximo cuatro decimales.");
    }

    internal static void ValidarFilas(List<MYGFilaPiePersonalizada> filas)
    {
        if (filas == null) return;
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var fila in filas)
        {
            if (fila == null || string.IsNullOrWhiteSpace(fila.Id) || !ids.Add(fila.Id) || idsPredeterminados.Contains(fila.Id))
                throw new InvalidDataException("El pie contiene una fila sin identidad, duplicada o reservada.");
            if (string.IsNullOrWhiteSpace(fila.Nombre) || !Enum.IsDefined(fila.Base))
                throw new InvalidDataException("Indique el nombre y una base válida para cada fila del pie.");
            ValidarPorcentaje(fila.Porcentaje);
        }
    }

    private static List<MYGFilaPiePersonalizada> CopiarFilas(List<MYGFilaPiePersonalizada> filas) =>
        filas?.Select(f => new MYGFilaPiePersonalizada
        { Id = f.Id, Nombre = f.Nombre, Porcentaje = f.Porcentaje, Base = f.Base }).ToList();

    public static string Moneda(IEnumerable<MYGPresupuestoDocumento> presupuestos)
    {
        var monedas = presupuestos.Select(p => p.Costos.Moneda.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (monedas.Count > 1) throw new InvalidOperationException("El proyecto contiene monedas distintas. Seleccione un presupuesto para ver su resumen.");
        return monedas.FirstOrDefault() ?? "S/";
    }

    public static decimal Porcentaje(MYGPresupuestoDocumento p, MYGConceptoPie concepto) => concepto switch
    {
        MYGConceptoPie.GastosGenerales => p.Costos.GastosGeneralesPorcentaje,
        MYGConceptoPie.Utilidad => p.Costos.UtilidadPorcentaje,
        MYGConceptoPie.IGV => p.Costos.ImpuestoPorcentaje,
        MYGConceptoPie.OtrosImpuestos => p.Costos.OtrosImpuestosPorcentaje,
        _ => throw new ArgumentOutOfRangeException(nameof(concepto))
    };

    private static void Asignar(MYGPresupuestoDocumento p, MYGConceptoPie concepto, decimal valor)
    {
        switch (concepto)
        {
            case MYGConceptoPie.GastosGenerales: p.Costos.GastosGeneralesPorcentaje = valor; break;
            case MYGConceptoPie.Utilidad: p.Costos.UtilidadPorcentaje = valor; break;
            case MYGConceptoPie.IGV: p.Costos.ImpuestoPorcentaje = valor; break;
            case MYGConceptoPie.OtrosImpuestos: p.Costos.OtrosImpuestosPorcentaje = valor; break;
            default: throw new ArgumentOutOfRangeException(nameof(concepto));
        }
    }

    // Se comprueban todos los presupuestos antes de modificar el primero.
    public static void AplicarPorcentaje(IEnumerable<MYGPresupuestoDocumento> presupuestos, MYGConceptoPie concepto, decimal valor)
    {
        ValidarPorcentaje(valor);
        var originales = presupuestos.ToList(); Moneda(originales);
        if (originales.Any(p => p.Costos.PiePersonalizado != null))
            throw new InvalidOperationException("Restaure el resumen predeterminado para editar sus porcentajes.");
        foreach (var original in originales)
        {
            var trabajo = MYGProyectoStorage.Copia(original); Asignar(trabajo, concepto, valor);
            MYGProyectoStorage.ValidarPresupuesto(trabajo); MYGMotorPresupuestos.Resumen(trabajo);
        }
        foreach (var p in originales) Asignar(p, concepto, valor);
    }

    // Las cuatro tasas del pie predeterminado se conservan, aunque no se
    // aplican mientras exista PiePersonalizado. Restaurar recupera esas tasas.
    public static void Limpiar(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        EstablecerPersonalizado(presupuestos, new List<MYGFilaPiePersonalizada>());

    public static void RestaurarPredeterminado(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        EstablecerPersonalizado(presupuestos, null);

    public static void EstablecerPersonalizado(IEnumerable<MYGPresupuestoDocumento> presupuestos, List<MYGFilaPiePersonalizada> filas)
    {
        ValidarFilas(filas);
        var originales = presupuestos.ToList(); Moneda(originales);
        var plantilla = CopiarFilas(filas);
        foreach (var original in originales)
        {
            var trabajo = MYGProyectoStorage.Copia(original);
            trabajo.Costos.PiePersonalizado = CopiarFilas(plantilla);
            MYGProyectoStorage.ValidarPresupuesto(trabajo); MYGMotorPresupuestos.Resumen(trabajo);
        }
        foreach (var original in originales) original.Costos.PiePersonalizado = CopiarFilas(plantilla);
    }

    internal static List<MYGFilaResumenPie> CalcularPersonalizado(MYGPresupuestoDocumento p, decimal costoDirecto)
    {
        ValidarFilas(p.Costos.PiePersonalizado);
        var filas = new List<MYGFilaResumenPie>
        { new() { Id = IdCostoDirecto, Nombre = "Costo directo", Importe = costoDirecto } };
        decimal acumulado = costoDirecto;
        foreach (var fila in p.Costos.PiePersonalizado)
        {
            decimal baseCalculo = fila.Base == MYGBaseFilaPie.CostoDirecto ? costoDirecto : acumulado;
            decimal importe = MYGMotorPresupuestos.Dinero(p, baseCalculo * fila.Porcentaje / 100m);
            filas.Add(new() { Id = fila.Id, Nombre = fila.Nombre, Porcentaje = fila.Porcentaje, Importe = importe, Editable = true });
            acumulado += importe;
        }
        return filas;
    }

    private static List<MYGFilaResumenPie> FilasPresupuesto(MYGCalculoPresupuesto calculo)
    {
        var p = calculo.Presupuesto; var r = calculo.Resumen();
        if (p.Costos.PiePersonalizado != null) return CalcularPersonalizado(p, r.CostoDirecto);
        return new()
        {
            new() { Id = IdCostoDirecto, Nombre = "Costo directo", Importe = r.CostoDirecto },
            new() { Id = "gastos-generales", Nombre = "Gastos generales", Porcentaje = p.Costos.GastosGeneralesPorcentaje,
                Importe = r.GastosGenerales, Editable = true, Concepto = MYGConceptoPie.GastosGenerales },
            new() { Id = "utilidad", Nombre = "Utilidad", Porcentaje = p.Costos.UtilidadPorcentaje,
                Importe = r.Utilidad, Editable = true, Concepto = MYGConceptoPie.Utilidad },
            new() { Id = "parcial", Nombre = "Parcial", Importe = r.Subtotal },
            new() { Id = "igv", Nombre = "I.G.V.", Porcentaje = p.Costos.ImpuestoPorcentaje,
                Importe = r.Impuesto, Editable = true, Concepto = MYGConceptoPie.IGV },
            new() { Id = "otros-impuestos", Nombre = "Otros impuestos", Porcentaje = p.Costos.OtrosImpuestosPorcentaje,
                Importe = r.OtrosImpuestos, Editable = true, Concepto = MYGConceptoPie.OtrosImpuestos },
            new() { Id = IdTotal, Nombre = "Total", Importe = r.Total }
        };
    }

    public static List<MYGFilaResumenPie> Filas(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        Filas(presupuestos.Select(MYGMotorPresupuestos.CrearCalculo));

    public static List<MYGFilaResumenPie> Filas(IEnumerable<MYGCalculoPresupuesto> calculos)
    {
        var valores = calculos.ToList(); Moneda(valores.Select(c => c.Presupuesto));
        var resultado = new List<MYGFilaResumenPie>();
        var porId = new Dictionary<string, MYGFilaResumenPie>(StringComparer.OrdinalIgnoreCase);
        var apariciones = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var bases = new Dictionary<string, MYGBaseFilaPie?>(StringComparer.OrdinalIgnoreCase);
        foreach (var calculo in valores)
        {
            var filas = FilasPresupuesto(calculo);
            var basesPresupuesto = calculo.Presupuesto.Costos.PiePersonalizado?.ToDictionary(
                f => f.Id, f => (MYGBaseFilaPie?)f.Base, StringComparer.OrdinalIgnoreCase);
            foreach (var fila in filas)
            {
                var baseFila = basesPresupuesto?.GetValueOrDefault(fila.Id);
                if (!porId.TryGetValue(fila.Id, out var agregado))
                {
                    agregado = new MYGFilaResumenPie { Id = fila.Id, Nombre = fila.Nombre, Porcentaje = fila.Porcentaje,
                        Editable = fila.Editable, Concepto = fila.Concepto };
                    porId.Add(fila.Id, agregado); resultado.Add(agregado); apariciones.Add(fila.Id, 0);
                    bases.Add(fila.Id, baseFila);
                }
                apariciones[fila.Id]++;
                agregado.Importe += fila.Importe;
                if (agregado.Porcentaje != fila.Porcentaje) agregado.Porcentaje = null;
                if (agregado.Nombre != fila.Nombre) agregado.Editable = false;
                if (bases[fila.Id] != baseFila) { agregado.Editable = false; agregado.Porcentaje = null; }
            }
        }
        foreach (var fila in resultado)
            if (apariciones[fila.Id] != valores.Count) { fila.Porcentaje = null; fila.Editable = false; }
        // En un alcance mixto, el Total visible incluye también los pies
        // personalizados que no contienen por sí mismos una fila Total.
        if (porId.TryGetValue(IdTotal, out var total))
        {
            total.Importe = valores.Sum(c => c.Resumen().Total);
            resultado.Remove(total); resultado.Add(total);
        }
        if (porId.TryGetValue("parcial", out var parcial)) parcial.Importe = valores.Sum(c => c.Resumen().Subtotal);
        return resultado;
    }

    public static MYGResumenCostos Resumen(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        Resumen(presupuestos.Select(MYGMotorPresupuestos.CrearCalculo));

    public static MYGResumenCostos Resumen(IEnumerable<MYGCalculoPresupuesto> calculos)
    {
        var valores = calculos.ToList(); Moneda(valores.Select(c => c.Presupuesto)); var total = new MYGResumenCostos();
        foreach (var calculo in valores)
        {
            var r = calculo.Resumen();
            total.CostoDirecto += r.CostoDirecto; total.GastosGenerales += r.GastosGenerales;
            total.Utilidad += r.Utilidad; total.Subtotal += r.Subtotal;
            total.Impuesto += r.Impuesto; total.OtrosImpuestos += r.OtrosImpuestos; total.Total += r.Total;
        }
        return total;
    }

    public static List<MYGIncidenciaCosto> Incidencia(IEnumerable<MYGPresupuestoDocumento> presupuestos) =>
        Incidencia(presupuestos.Select(MYGMotorPresupuestos.CrearCalculo));

    public static List<MYGIncidenciaCosto> Incidencia(IEnumerable<MYGCalculoPresupuesto> calculos)
    {
        var valores = calculos.ToList(); Moneda(valores.Select(c => c.Presupuesto));
        var importes = new decimal[5];
        foreach (var calculo in valores)
        {
            var p = calculo.Presupuesto;
            var bruto = new decimal[5]; var directo = calculo.Resumen().CostoDirecto;
            foreach (var i in calculo.Consolidar())
            {
                if (i.Clave == "REDONDEO") continue;
                int grupo = i.Clave.StartsWith("DIRECTO:", StringComparison.Ordinal) ? 4 : i.Grupo switch
                { MYGGrupoRecurso.ManoObra => 0, MYGGrupoRecurso.Materiales => 1, MYGGrupoRecurso.Equipo => 2, _ => 3 };
                bruto[grupo] += i.Total;
            }
            // El consolidado puede diferir del parcial nativo por redondeos. Se
            // conserva la proporción del desglose y se concilia al costo directo real.
            decimal suma = bruto.Sum();
            if (suma <= 0) { importes[4] += directo; continue; }
            decimal escala = 1; for (int n = 0; n < p.Costos.DecimalesPrecio; n++) escala *= 10;
            var ideal = bruto.Select(v => v * directo / suma).ToArray();
            var repartido = ideal.Select(v => decimal.Truncate(v * escala) / escala).ToArray();
            var orden = Enumerable.Range(0, bruto.Length).OrderByDescending(n => ideal[n] - repartido[n]).ToArray();
            decimal pendiente = directo - repartido.Sum(); int siguiente = 0;
            while (pendiente > 0)
            { decimal unidad = Math.Min(pendiente, 1m / escala); repartido[orden[siguiente++ % orden.Length]] += unidad; pendiente -= unidad; }
            for (int n = 0; n < importes.Length; n++) importes[n] += repartido[n];
        }
        string[] nombres = { "MANO DE OBRA", "MATERIALES", "EQUIPO", "SUBCONTRATOS", "SIN DESGLOSE" };
        decimal costo = importes.Sum();
        return importes.Select((v, n) => new MYGIncidenciaCosto
        { Nombre = nombres[n], Importe = v, Porcentaje = costo == 0 ? 0 : decimal.Round(v * 100m / costo, 4, MidpointRounding.AwayFromZero) })
            .Where((v, n) => n < 4 || v.Importe != 0).ToList();
    }
}
