using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed class MYGEditarFilaResumenForm : Form
{
    internal MYGFilaPiePersonalizada Valor { get; private set; }

    internal MYGEditarFilaResumenForm(MYGFilaPiePersonalizada fila, bool predeterminada = false, bool varios = false)
    {
        Text = "MYG | Editar fila del resumen";
        StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
        ClientSize = new(490, 270); Font = new("Segoe UI", 10);
        var nombre = new TextBox { Dock = DockStyle.Fill, Text = fila.Nombre, ReadOnly = predeterminada, MaxLength = 120 };
        var porcentaje = new NumericUpDown { Dock = DockStyle.Fill, Minimum = 0, Maximum = 10000, DecimalPlaces = 4,
            Value = Math.Clamp(fila.Porcentaje, 0, 10000), ThousandsSeparator = true };
        var baseCalculo = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList, Enabled = !predeterminada };
        baseCalculo.Items.AddRange(new object[] { "Costo directo", "Acumulado de las filas anteriores" });
        baseCalculo.SelectedIndex = fila.Base == MYGBaseFilaPie.Acumulado ? 1 : 0;
        var tabla = new TableLayoutPanel { Dock = DockStyle.Top, Height = predeterminada ? 94 : 132, ColumnCount = 2, Padding = new(12) };
        tabla.ColumnStyles.Add(new(SizeType.Absolute, 120)); tabla.ColumnStyles.Add(new(SizeType.Percent, 100));
        void Campo(string texto, Control control, int indice)
        {
            tabla.RowStyles.Add(new(SizeType.Absolute, 36));
            tabla.Controls.Add(new Label { Text = texto, AutoSize = true, Anchor = AnchorStyles.Left }, 0, indice);
            tabla.Controls.Add(control, 1, indice);
        }
        Campo("Concepto", nombre, 0); Campo("Porcentaje (%)", porcentaje, 1);
        if (!predeterminada) Campo("Aplicar sobre", baseCalculo, 2);
        var nota = new Label { Dock = DockStyle.Fill, Padding = new(12), Text =
            (varios ? "Hay porcentajes diferentes. Aplicar usará el valor indicado en todos los presupuestos del alcance.\n" : "") +
            (predeterminada ? "Gastos generales y utilidad usan el costo directo. Los impuestos usan el parcial." :
                "El importe se suma al total. Acumulado usa el costo directo más los conceptos que estén antes de esta fila.") };
        var botones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45, FlowDirection = FlowDirection.RightToLeft, Padding = new(5) };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, AutoSize = true };
        var aceptar = new Button { Text = "Aplicar", AutoSize = true };
        aceptar.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(nombre.Text))
            { MessageBox.Show(this, "Indique el nombre del concepto.", "Resumen", MessageBoxButtons.OK, MessageBoxIcon.Warning); nombre.Focus(); return; }
            Valor = new MYGFilaPiePersonalizada { Id = fila.Id, Nombre = nombre.Text.Trim(), Porcentaje = porcentaje.Value,
                Base = baseCalculo.SelectedIndex == 1 ? MYGBaseFilaPie.Acumulado : MYGBaseFilaPie.CostoDirecto };
            DialogResult = DialogResult.OK;
        };
        botones.Controls.Add(cancelar); botones.Controls.Add(aceptar);
        Controls.Add(nota); Controls.Add(tabla); Controls.Add(botones);
        AcceptButton = aceptar; CancelButton = cancelar;
        MYG2027_TemaComercial.Aplicar(this);
    }
}
