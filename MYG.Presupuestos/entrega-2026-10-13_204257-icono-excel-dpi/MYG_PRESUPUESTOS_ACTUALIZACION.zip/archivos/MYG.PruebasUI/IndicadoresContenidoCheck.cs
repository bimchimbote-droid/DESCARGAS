using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class IndicadoresContenidoCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-Contenido-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            string ruta = Path.Combine(carpeta, "Catalogo.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var proyecto = MYGProyectoStorage.Nuevo("Indicadores de contenido", "PRESUPUESTO");
            var presupuesto = proyecto.Presupuestos.Single();
            var titulo = Nodo("ESTRUCTURAS", 1, titulo: true);
            var completa = Nodo("PARTIDA CON AMBOS DOCUMENTOS " + new string('X', 180), 1, titulo.Id);
            var especificacion = Nodo("SÓLO ESPECIFICACIÓN", 2, titulo.Id);
            var excel = Nodo("SÓLO METRADO EN EXCEL", 3, titulo.Id);
            var borrador = Nodo("ESPECIFICACIÓN SIN GUARDAR", 4, titulo.Id);
            var vacia = Nodo("PARTIDA NUEVA", 5, titulo.Id);
            var acerosVacia = Nodo("PLANTILLA DE ACEROS VACÍA", 6, titulo.Id);
            foreach (var partida in new[] { titulo, completa, especificacion })
                partida.Costos.EspecificacionTexto = "DESCRIPCIÓN:\nEjecutar de acuerdo con los planos.";
            foreach (var partida in new[] { titulo, completa, excel })
                partida.Costos.Hoja.Poner("A3", "Metrado registrado");
            borrador.Costos.EspecificacionTexto = "01.04  ESPECIFICACIÓN SIN GUARDAR\nDESCRIPCIÓN:\nTexto provisional";
            borrador.Costos.EspecificacionEsBorrador = true;
            acerosVacia.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
            // Elegir Excel como fuente no convierte las fórmulas y títulos de
            // una plantilla recién creada en un metrado ingresado por el usuario.
            acerosVacia.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
            presupuesto.Items.AddRange([titulo, completa, especificacion, excel, borrador, vacia, acerosVacia]);
            MYGProyectoStorage.Renumerar(presupuesto);

            int anteriores = 0, cambios = 0, guardados = 0, escriturasCatalogo = 0, permisos = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            panel.InicializarCatalogos(() => { escriturasCatalogo++; return ruta; },
                () => { permisos++; return true; }, () => { }, () => ruta);
            using var formulario = new Form { ClientSize = new Size(1800, 1000) };
            formulario.Controls.Add(panel);
            MYG2027_TemaComercial.Aplicar(formulario);
            string estadoInicial = Estado(proyecto);
            formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(completa);
            Application.DoEvents();
            var tabla = Campo<DataGridView>(panel, "estructura");
            Invocar(panel, "ActualizarCalculos");
            exige(Estado(proyecto) == estadoInicial && anteriores == 0 && cambios == 0 && guardados == 0 &&
                escriturasCatalogo == 0 && permisos == 0,
                "Cargar y calcular los indicadores de contenido debe conservar el modelo, el historial y los permisos.");

            var columnaExcel = tabla.Columns["METRADO_EXCEL"];
            exige(columnaExcel.Visible && columnaExcel.HeaderText == "" && columnaExcel.ReadOnly &&
                columnaExcel.DisplayIndex == tabla.Columns["UND"].DisplayIndex + 1 &&
                tabla.Columns["PU"].DisplayIndex == columnaExcel.DisplayIndex + 1,
                "El icono de Excel debe tener una columna de consulta entre la unidad y el precio, a la derecha de la especificación.");
            var filaCompleta = Fila(tabla, completa);
            exige(Convert.ToDecimal(filaCompleta.Cells["CANT"].Value) == 2m &&
                Convert.ToString(filaCompleta.Cells["UND"].Value) == "und" &&
                Convert.ToDecimal(filaCompleta.Cells["PU"].Value) == 10m &&
                Convert.ToDecimal(filaCompleta.Cells["TOTAL"].Value) == 20m &&
                string.IsNullOrEmpty(Convert.ToString(filaCompleta.Cells["METRADO_EXCEL"].Value)),
                "Agregar la columna de Excel no debe desplazar los valores de cantidad, unidad, precio o total.");
            VerificarPresencia(panel, Fila(tabla, completa), true, true, exige);
            VerificarPresencia(panel, Fila(tabla, especificacion), true, false, exige);
            VerificarPresencia(panel, Fila(tabla, excel), false, true, exige);
            foreach (var nodo in new object[] { presupuesto, titulo, borrador, vacia, acerosVacia })
                VerificarPresencia(panel, Fila(tabla, nodo), false, false, exige);
            exige(Fila(tabla, completa).Cells["METRADO_EXCEL"].ToolTipText == "La partida tiene metrado en Excel." &&
                string.IsNullOrEmpty(Fila(tabla, acerosVacia).Cells["METRADO_EXCEL"].ToolTipText),
                "La ayuda de Excel debe identificar sólo hojas con contenido y permanecer vacía para las plantillas nuevas.");

            var filas = tabla.Rows.Cast<DataGridViewRow>().ToArray();
            var seleccion = tabla.CurrentCell;
            var filaVacia = Fila(tabla, vacia);
            // El cálculo visual debe reflejar guardar/borrar contenido en la
            // misma fila; recrear Rows escondería una regresión de selección.
            vacia.Costos.EspecificacionTexto = "Especificación guardada";
            vacia.Costos.EspecificacionEsBorrador = false;
            vacia.Costos.Hoja.Poner("B3", "2");
            string estadoTrasGuardar = Estado(proyecto);
            Invocar(panel, "ActualizarCalculos"); Application.DoEvents();
            VerificarPresencia(panel, filaVacia, true, true, exige);
            exige(tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas) &&
                ReferenceEquals(tabla.CurrentCell, seleccion) && Estado(proyecto) == estadoTrasGuardar,
                "Actualizar contenido guardado debe activar los dos iconos sin reconstruir las filas, cambiar la selección ni modificar datos.");
            vacia.Costos.EspecificacionEsBorrador = true;
            vacia.Costos.Hoja = MYGHojaMetrado.Crear();
            string estadoTrasBorrar = Estado(proyecto);
            Invocar(panel, "ActualizarCalculos"); Application.DoEvents();
            VerificarPresencia(panel, filaVacia, false, false, exige);
            exige(tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas) &&
                ReferenceEquals(tabla.CurrentCell, seleccion) && Estado(proyecto) == estadoTrasBorrar &&
                string.IsNullOrEmpty(filaVacia.Cells["METRADO_EXCEL"].ToolTipText),
                "Al volver a borrador y quitar el metrado deben desaparecer los iconos y la ayuda sin reconstruir ni guardar datos.");

            foreach (bool oscuro in new[] { false, true })
            {
                string estado = Estado(proyecto);
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos();
                Invocar(panel, "ActualizarCalculos");
                Application.DoEvents();
                var celdaDescripcion = filaCompleta.Cells["DESC"];
                var celdaExcel = filaCompleta.Cells["METRADO_EXCEL"];
                var iconoEspecificacion = panel.LimitesIndicadorContenido(celdaDescripcion);
                var iconoExcel = panel.LimitesIndicadorContenido(celdaExcel);
                var alerta = panel.LimitesIndicadorAlerta(celdaDescripcion);
                var limitesDescripcion = tabla.GetCellDisplayRectangle(celdaDescripcion.ColumnIndex, filaCompleta.Index, false);
                var limitesExcel = tabla.GetCellDisplayRectangle(celdaExcel.ColumnIndex, filaCompleta.Index, false);
                exige(!iconoEspecificacion.IsEmpty && !iconoExcel.IsEmpty && !alerta.IsEmpty &&
                    limitesDescripcion.Contains(iconoEspecificacion) && limitesDescripcion.Contains(alerta) &&
                    limitesExcel.Contains(iconoExcel) && alerta.Right <= iconoEspecificacion.Left &&
                    iconoEspecificacion.Right < iconoExcel.Left,
                    "La especificación debe quedar al final de la descripción con el aviso verde a su izquierda, y Excel después de la unidad, sin superposiciones.");
                var texto = limitesDescripcion;
                texto.X += celdaDescripcion.InheritedStyle.Padding.Left;
                texto.Width -= celdaDescripcion.InheritedStyle.Padding.Horizontal;
                exige(texto.Right <= alerta.Left && !texto.IntersectsWith(iconoEspecificacion),
                    "El margen de una descripción larga debe reservar espacio para ambos símbolos sin cubrir el texto.");
                using var imagen = new Bitmap(tabla.Width, tabla.Height);
                tabla.DrawToBitmap(imagen, tabla.ClientRectangle);
                Color verde = SystemInformation.HighContrast && celdaDescripcion.Selected
                    ? SystemColors.HighlightText : MYGIndicadoresPartida.ColorIndicador(MYGTipoIndicadorPartida.Catalogo);
                exige(TieneDetalle(imagen, iconoEspecificacion) && TieneDetalle(imagen, iconoExcel) &&
                    ContieneColor(imagen, alerta, verde),
                    "Los dos iconos y el aviso verde deben pintarse simultáneamente en los temas claro y oscuro.");
                exige(Estado(proyecto) == estado && tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas) &&
                    ReferenceEquals(tabla.CurrentCell, seleccion) && anteriores == 0 && cambios == 0 && guardados == 0 &&
                    escriturasCatalogo == 0 && permisos == 0,
                    "Pintar, cambiar el tema y consultar los límites de los iconos debe ser una operación visual sin mutaciones ni guardados.");
            }
            formulario.Close();
            VerificarInicioEscalado(ruta, exige);
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
            SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void VerificarInicioEscalado(string rutaCatalogo, Action<bool, string> exige)
    {
        var dpiInterno = typeof(Control).GetProperty("DeviceDpiInternal", Privados)
            ?? throw new InvalidOperationException("No se puede simular el DPI del control en esta versión de WinForms.");
        var cargar = typeof(UserControl).GetMethod("OnLoad", Privados);
        foreach (int dpi in new[] { 96, 120, 144, 192, 240 })
        {
            var proyecto = MYGProyectoStorage.Nuevo("Excel al iniciar con escala alta", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            var partida = Nodo("METRADO ACTUALIZADO DESDE EXCEL", 1);
            partida.Costos.Metrados.Add(new MYGLineaMetrado { Descripcion = "Manual conservado", Elementos = 2m, CantidadPorElemento = 3m });
            partida.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = "bim-conservado", Unidad = "und", Cantidad = 9m });
            presupuesto.Items.Add(partida);
            MYGProyectoStorage.Renumerar(presupuesto);
            int anteriores = 0, cambios = 0, guardados = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            panel.InicializarCatalogos(() => rutaCatalogo, () => true, () => { }, () => rutaCatalogo);
            var tabla = Campo<DataGridView>(panel, "estructura");
            var columna = tabla.Columns["METRADO_EXCEL"];
            bool anchoAlCrearCorrecto = tabla.IsHandleCreated &&
                columna.Width == (int)Math.Ceiling(26 * tabla.DeviceDpi / 96d);
            tabla.HandleCreated += (_, _) => anchoAlCrearCorrecto =
                columna.Width == (int)Math.Ceiling(26 * tabla.DeviceDpi / 96d);
            using var formulario = new Form { ClientSize = new Size(1800, 1000) };
            formulario.Controls.Add(panel);
            // Simular el DPI definitivo antes de la carga permite comprobar un
            // arranque al 125/150/200/250 % sin mover ventanas entre monitores.
            // El ancho de 26 reproduce el valor sin escalar de la regresión.
            dpiInterno.SetValue(tabla, dpi);
            columna.MinimumWidth = 5; columna.Width = 26;
            string estadoInicial = Estado(proyecto);
            cargar.Invoke(panel, [EventArgs.Empty]);
            exige(tabla.DeviceDpi == dpi && columna.Width == (int)Math.Ceiling(26 * dpi / 96d) &&
                Estado(proyecto) == estadoInicial && anteriores == 0 && cambios == 0 && guardados == 0,
                $"La carga inicial a {dpi} DPI debe dimensionar Excel sin esperar un cambio de monitor ni modificar datos.");
            formulario.Show();
            exige(anchoAlCrearCorrecto,
                "Crear el control debe aplicar el DPI real de la ventana al ancho del indicador Excel.");
            // La ventana real usa el DPI del escritorio de pruebas. Restituir
            // el simulado y emitir sólo Load mantiene este caso independiente
            // de DpiChangedAfterParent y del monitor donde se ejecuta la suite.
            dpiInterno.SetValue(tabla, dpi);
            columna.MinimumWidth = 5; columna.Width = 26;
            cargar.Invoke(panel, [EventArgs.Empty]);
            panel.Refrescar(); panel.SeleccionarEstructura(partida);
            var pagina = Campo<TabPage>(panel, "paginaExcel");
            ((TabControl)pagina.Parent).SelectedTab = pagina;
            Application.DoEvents();
            // Imitar la altura disponible cuando Windows escala las fuentes;
            // esta regresión comprueba el ancho de columna, no las fuentes.
            foreach (DataGridViewRow fila in tabla.Rows)
                fila.MinimumHeight = (int)Math.Ceiling(29 * dpi / 96d);
            var filaPartida = Fila(tabla, partida);
            VerificarPresencia(panel, filaPartida, false, false, exige);
            var filas = tabla.Rows.Cast<DataGridViewRow>().ToArray();
            var seleccion = tabla.CurrentCell;
            var costosOriginales = partida.Costos;
            var hojaOriginal = partida.Costos.Hoja;
            partida.Costos.Hoja.Poner("B3", "1");
            Invocar(panel, "RecalcularHoja"); Application.DoEvents();
            var cabecera = Campo<MYGMetradoCabecera>(panel, "cabeceraExcel");
            var actualizar = (Button)cabecera.Controls.Find("metrado_actualizar", true).Single();
            exige(actualizar.Visible && actualizar.Enabled,
                $"Ingresar B3=1 debe habilitar el botón Actualizar también a {dpi} DPI.");
            var esperado = MYGProyectoStorage.Copia(proyecto);
            var costosEsperados = esperado.Presupuestos.Single().Items.Single().Costos;
            costosEsperados.Cantidad = 1m; costosEsperados.FuenteMetrado = MYGFuenteMetrado.Excel;
            actualizar.PerformClick(); Application.DoEvents();
            VerificarPresencia(panel, filaPartida, false, true, exige);
            var limites = panel.LimitesIndicadorContenido(filaPartida.Cells["METRADO_EXCEL"]);
            var celda = tabla.GetCellDisplayRectangle(columna.Index, filaPartida.Index, false);
            exige(!limites.IsEmpty && celda.Contains(limites) &&
                columna.MinimumWidth >= limites.Width + 2 * (int)Math.Ceiling(4 * dpi / 96d),
                $"El icono Excel debe caber completo después de Actualizar a {dpi} DPI.");
            using var imagen = new Bitmap(tabla.Width, tabla.Height);
            tabla.DrawToBitmap(imagen, tabla.ClientRectangle);
            exige(TieneDetalle(imagen, limites),
                $"Actualizar debe pintar el icono Excel a {dpi} DPI sin reconstruir la tabla.");
            exige(Estado(proyecto) == Estado(esperado) &&
                ReferenceEquals(partida.Costos, costosOriginales) && ReferenceEquals(partida.Costos.Hoja, hojaOriginal) &&
                tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas) && ReferenceEquals(tabla.CurrentCell, seleccion) &&
                anteriores == 1 && cambios == 1 && guardados == 0,
                $"Actualizar y pintar Excel a {dpi} DPI debe conservar la hoja, otros metrados y la selección, con un solo cambio y sin guardados.");
            formulario.Close();
        }
    }

    private static void VerificarPresencia(MYGPanelPresupuesto panel, DataGridViewRow fila,
        bool especificacion, bool excel, Action<bool, string> exige)
    {
        exige(!panel.LimitesIndicadorContenido(fila.Cells["DESC"]).IsEmpty == especificacion &&
            !panel.LimitesIndicadorContenido(fila.Cells["METRADO_EXCEL"]).IsEmpty == excel &&
            new[] { "ITEM", "CANT", "UND", "PU", "TOTAL" }.All(c => panel.LimitesIndicadorContenido(fila.Cells[c]).IsEmpty),
            "Cada partida debe mostrar sólo los iconos de su contenido guardado; los títulos, raíces y borradores no deben recibirlos.");
    }

    private static ItemPresupuestoDelphin Nodo(string descripcion, int posicion, string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new() { Id = id, IdLocalMYG = id, IdPropuesta = id, ParentId = padre, Descripcion = descripcion,
            Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Posicion = posicion,
            Origen = "MODELO", Estado = "PROPUESTA", Costos = new MYGDatosPartida { Cantidad = 2m, PrecioDirecto = 10m } };
    }

    private static bool TieneDetalle(Bitmap imagen, Rectangle area)
    {
        area.Intersect(new Rectangle(Point.Empty, imagen.Size));
        if (area.IsEmpty) return false;
        Color fondo = imagen.GetPixel(area.Left, area.Top);
        int distintos = 0;
        for (int y = area.Top; y < area.Bottom; y++)
            for (int x = area.Left; x < area.Right; x++)
            {
                Color pixel = imagen.GetPixel(x, y);
                if (Math.Abs(pixel.R - fondo.R) + Math.Abs(pixel.G - fondo.G) + Math.Abs(pixel.B - fondo.B) > 80)
                    distintos++;
            }
        return distintos >= 8;
    }

    private static bool ContieneColor(Bitmap imagen, Rectangle area, Color esperado)
    {
        area.Intersect(new Rectangle(Point.Empty, imagen.Size));
        for (int y = area.Top; y < area.Bottom; y++)
            for (int x = area.Left; x < area.Right; x++)
            {
                Color pixel = imagen.GetPixel(x, y);
                if (Math.Abs(pixel.R - esperado.R) < 35 && Math.Abs(pixel.G - esperado.G) < 35 && Math.Abs(pixel.B - esperado.B) < 35)
                    return true;
            }
        return false;
    }

    private static string Estado(object valor) => JsonSerializer.Serialize(valor);
    private static DataGridViewRow Fila(DataGridView tabla, object nodo) =>
        tabla.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, nodo));
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
