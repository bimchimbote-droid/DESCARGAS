using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoExcelCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            VerificarPartidaNuevaRenderizada(exige);
            var proyecto = MYGProyectoStorage.Nuevo("Proyecto de metrados", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            presupuesto.Item = "01";
            var primera = Partida("01", "CONCRETO EN COLUMNAS", 1);
            var segunda = Partida("02", "ACERO EN COLUMNAS", 2);
            // Exercise a stored sheet from before the grouped headers existed.
            primera.Costos.Hoja.RangosCombinados.Clear();
            primera.Costos.Hoja.RellenoCabeceraEstandarAplicado = false;
            foreach (string dir in MYGEdicionHoja.Direcciones(primera.Costos.Hoja, "A2:H2"))
                primera.Costos.Hoja.Celdas[dir].ColorFondo = "";
            primera.Costos.Hoja.Poner("A3", "Columna C-01");
            primera.Costos.Hoja.Celdas["A3"].ColorFondo = "C6EFCE";
            primera.Costos.Hoja.Celdas["A3"].ColorTexto = "006100";
            primera.Costos.Hoja.Poner("B3", "2");
            primera.Costos.Hoja.Poner("C3", "3");
            primera.Costos.Hoja.Poner("D3", "4");
            primera.Costos.Hoja.Poner("A4", "Texto de la celda activa");
            segunda.Costos.Hoja.Poner("A3", "Metrado de acero conservado");
            presupuesto.Items.AddRange(new[] { primera, segunda });
            string carpetaAnterior = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-Cabecera-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(carpetaAnterior);
            try
            {
                string rutaAnterior = Path.Combine(carpetaAnterior, "Metrado anterior.myg");
                MYGProyectoStorage.Guardar(rutaAnterior, proyecto);
                proyecto = MYGProyectoStorage.Leer(rutaAnterior);
                presupuesto = proyecto.Presupuestos.Single();
                primera = presupuesto.Items.Single(i => i.Id == primera.Id);
                segunda = presupuesto.Items.Single(i => i.Id == segunda.Id);
            }
            finally { Directory.Delete(carpetaAnterior, true); }
            int anteriores = 0, cambios = 0, guardados = 0, deshacer = 0, rehacer = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++, () => deshacer++, () => rehacer++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1800, 1000) };
            formulario.Controls.Add(panel);
            formulario.Show();
            panel.Refrescar();
            panel.SeleccionarEstructura(primera);
            var pagina = Campo<TabPage>(panel, "paginaExcel");
            var detalle = (TabControl)pagina.Parent;
            detalle.SelectedTab = pagina;
            Application.DoEvents();

            var hoja = Campo<DataGridView>(panel, "hoja");
            var cinta = Campo<TabControl>(panel, "cintaHoja");
            var cabecera = Campo<Control>(panel, "cabeceraExcel");
            var formula = Campo<TextBoxBase>(panel, "formula");
            var direccion = Campo<TextBox>(panel, "direccion");
            var barraFormula = Controles(pagina).Single(c => c.Name == "metrado_barra_formula");
            var pestanas = Controles(pagina).OfType<TabControl>().Single(c => c.Name == "metrado_hojas");
            string[] titulos = { "Archivo", "Inicio", "Celdas", "Diseño de Página", "Fórmulas", "Insertar", "Datos", "Revisar", "Vista" };
            exige(cinta.Name == "metrado_cinta" && cinta.TabPages.Cast<TabPage>().Select(p => p.Text).SequenceEqual(titulos),
                "La cinta Excel debe ofrecer las nueve pestañas de las imágenes en el orden indicado.");
            VerificarPestanasCompletas(cinta, exige);
            exige(hoja.Name == "metrado_hoja" && pagina.Controls.Contains(hoja) && hoja.Columns.Contains("G") && hoja.Rows.Count >= 16,
                "La hoja debe conservar su integración directa con la página y cargar los datos antes de editar.");
            VerificarNumeracionFilas(hoja, 100, exige);
            VerificarPresentacionDatos(hoja, exige);
            VerificarEncabezadosCentrados(hoja, exige);
            VerificarCabeceraCombinada(hoja, primera.Costos.Hoja, exige);
            // La paleta global instala CellFormatting y puede cambiar el color
            // efectivo sin cambiar el Style guardado. Ejercitar ambos pasos.
            MYG2027_TemaComercial.Aplicar(hoja);
            panel.AplicarTemaPresupuestos();
            Application.DoEvents();
            VerificarLimiteSombreado(hoja, exige);
            exige(primera.Costos.Hoja.RellenoCabeceraEstandarAplicado && anteriores == 0 && cambios == 0 && guardados == 0,
                "Cargar una cabecera estándar guardada sin relleno debe completar sus títulos antes de dibujarlos, sin registrar comandos ni guardar automáticamente.");
            exige(Convert.ToString(hoja[1, 2].Value) == 2m.ToString("0.00") &&
                Convert.ToString(hoja[2, 2].Value) == 3m.ToString("0.00") &&
                Convert.ToString(hoja[3, 2].Value) == 4m.ToString("0.00") &&
                Convert.ToString(hoja[6, 2].Value) == 24m.ToString("0.00") && Convert.ToString(hoja[6, 3].Value) == "-" &&
                Convert.ToString(hoja[6, 15].Value) == 24m.ToString("0.00") &&
                hoja[0, 15].InheritedStyle.Alignment == DataGridViewContentAlignment.MiddleRight &&
                hoja[0, 15].InheritedStyle.Font.Bold && hoja[6, 15].InheritedStyle.Font.Bold,
                "La hoja estándar debe mostrar entradas, parciales y total con dos decimales, guiones en filas vacías y la etiqueta Total en negrita a la derecha.");
            exige(hoja.Rows[2].Cells[0].Style.BackColor.ToArgb() == Color.FromArgb(198, 239, 206).ToArgb() &&
                hoja.Rows[2].Cells[0].Style.ForeColor.ToArgb() == Color.FromArgb(0, 97, 0).ToArgb(),
                "La hoja debe mostrar colores RGB de seis dígitos sin prefijo, como los importados de Excel.");
            exige(!direccion.ReadOnly && Controles(barraFormula).Contains(formula) && Controles(barraFormula).Contains(direccion),
                "La barra de fórmulas debe mostrar una dirección editable y el contenido de la celda.");
            exige(pestanas.TabPages.Count >= 1 && pestanas.TabPages[0].Text == primera.Costos.Hoja.Nombre,
                "La pestaña inferior debe identificar la hoja de metrado de la partida.");
            VerificarCabecera(cabecera, presupuesto.Nombre, "01.01", primera.Descripcion, exige);
            exige(cabecera.Top == 0 && cinta.PointToScreen(Point.Empty).Y >= cabecera.PointToScreen(new Point(0, cabecera.Height)).Y &&
                barraFormula.PointToScreen(Point.Empty).Y >= cinta.PointToScreen(new Point(0, cinta.Height)).Y &&
                hoja.PointToScreen(Point.Empty).Y >= barraFormula.PointToScreen(new Point(0, barraFormula.Height)).Y,
                "La cabecera, cinta, barra de fórmulas y hoja deben disponerse sin superposiciones.");

            // Cambiar la cinta es una acción de presentación y no debe tocar datos.
            var sinCambios = (anteriores, cambios, guardados);
            Seleccionar(hoja, "I3");
            var selectorFormato = Controles(cinta).OfType<ToolStrip>()
                .SelectMany(strip => strip.Items.Cast<ToolStripItem>()).OfType<ToolStripComboBox>()
                .Single(combo => combo.Name == "metrado_formato_numero");
            exige(!primera.Costos.Hoja.Celdas.ContainsKey("I3") &&
                Convert.ToString(selectorFormato.SelectedItem) == "Número" &&
                selectorFormato.ToolTipText == "Formato actual: 0.00",
                "Seleccionar una celda vacía de una hoja nueva debe mostrar el formato predeterminado de dos decimales sin crearla.");
            VerificarSeleccionEncabezados(panel, hoja, formula, direccion, primera.Costos.Hoja,
                () => (anteriores, cambios, guardados), exige);
            Seleccionar(hoja, "D7");
            foreach (TabPage pestana in cinta.TabPages)
            {
                cinta.SelectedTab = pestana;
                Application.DoEvents();
                exige(hoja.Visible && DireccionActual(hoja) == "D7",
                    $"La pestaña {pestana.Text} debe mantener visible la hoja y conservar la celda seleccionada.");
            }
            exige((anteriores, cambios, guardados) == sinCambios,
                "Recorrer la cinta no debe crear historial, modificar el metrado ni guardar el proyecto.");

            direccion.Text = "A4:C6";
            Invocar(panel, "IrDireccionHoja");
            Application.DoEvents();
            exige(hoja.SelectedCells.Count == 9 && DireccionActual(hoja) == "A4" &&
                hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.RowIndex >= 3 && c.RowIndex <= 5 && c.ColumnIndex <= 2),
                "La dirección debe seleccionar el rango completo indicado sin cambiar su contenido.");
            exige(direccion.Text == "A4:C6" && formula.Text == "Texto de la celda activa",
                "Seleccionar un rango debe mostrar sus extremos en la dirección y conservar el contenido de la celda activa en la barra de fórmulas.");
            var selectorFuente = Controles(cinta).OfType<ToolStrip>()
                .SelectMany(strip => strip.Items.Cast<ToolStripItem>()).OfType<ToolStripComboBox>()
                .Single(combo => combo.Name == "metrado_fuente");
            exige(selectorFuente.Text == "Arial Narrow" && primera.Costos.Hoja.Celdas["A4"].Fuente == "Arial Narrow" &&
                (!FontFamily.Families.Any(f => f.Name.Equals("Arial Narrow", StringComparison.OrdinalIgnoreCase)) ||
                    hoja.Rows[3].Cells[0].InheritedStyle.Font?.FontFamily.Name == "Arial Narrow"),
                "La celda nueva debe usar Arial Narrow y la cinta debe mostrar esa fuente, renderizándola cuando está instalada.");
            var seleccionAntes = hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex)).ToHashSet();
            direccion.Text = "A0:C6";
            bool direccionRechazada = false;
            try { Invocar(panel, "IrDireccionHoja"); }
            catch (Exception ex) when (ex is FormatException or InvalidOperationException or System.IO.InvalidDataException)
            { direccionRechazada = true; }
            exige(direccionRechazada && DireccionActual(hoja) == "A4" &&
                seleccionAntes.SetEquals(hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex))),
                "Una dirección inválida debe conservar el rango seleccionado y rechazar la navegación sin modificar datos.");
            exige((anteriores, cambios, guardados) == sinCambios,
                "Seleccionar un rango o rechazar una dirección no debe modificar el presupuesto.");
            Seleccionar(hoja, "A4");
            hoja.Rows[3].Cells[1].Selected = true;
            hoja.Rows[5].Cells[0].Selected = true;
            hoja.Rows[7].Cells[2].Selected = true;
            Application.DoEvents();
            exige(direccion.Text == "A4:B4,A6,C8" && formula.Text == "Texto de la celda activa",
                "Una selección discontinua debe mostrar sólo sus tramos seleccionados y mantener el contenido de la celda activa.");
            Comando(panel, "deshacer");
            Comando(panel, "rehacer");
            exige(deshacer == 1 && rehacer == 1 && (anteriores, cambios, guardados) == sinCambios,
                "Deshacer y rehacer de la cinta deben invocar el historial del proyecto sin crear otro historial independiente.");

            EditarCelda(panel, hoja, "B3", "5", exige);
            exige(primera.Costos.Hoja.Celdas["B3"].Contenido == "5" &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("G3") == 60m &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("G16") == 60m,
                "Editar una dimensión en la tabla debe actualizar el modelo, el parcial y el total de metrado.");
            exige(anteriores == sinCambios.anteriores + 1 && cambios == sinCambios.cambios + 1 && guardados == 0,
                "Confirmar una celda debe registrar una modificación sin guardar automáticamente el proyecto.");

            Seleccionar(hoja, "I5");
            exige(direccion.Text == "I5", "Seleccionar una celda debe actualizar la dirección de la barra de fórmulas.");
            formula.Text = "=SUM(B3:C3)";
            Invocar(panel, "AplicarFormula");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["I5"].Contenido == "=SUM(B3:C3)" &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("I5") == 8m && formula.Text == "=SUM(B3:C3)",
                "La barra debe guardar la fórmula original y mostrar su resultado calculado en la hoja.");

            Seleccionar(hoja, "A3");
            Comando(panel, "negrita");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["A3"].Negrita && hoja.Rows[2].Cells[0].Style.Font?.Bold == true,
                "Negrita debe actualizar el estilo guardado y la celda visible de la selección.");
            Comando(panel, "cursiva");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["A3"].Negrita && primera.Costos.Hoja.Celdas["A3"].Cursiva &&
                hoja.Rows[2].Cells[0].Style.Font is Font fuenteMixta && fuenteMixta.Bold && fuenteMixta.Italic,
                "Combinar negrita y cursiva debe conservar ambos estilos en el modelo y en la celda visible.");
            sinCambios = (anteriores, cambios, guardados);
            var hojaAntesDeRechazo = primera.Costos.Hoja;
            bool formatoRechazado = false;
            try { Invocar(panel, "EditarFormatoHoja", (Action<MYGCeldaHoja>)(c => c.ColorFondo = "Red")); }
            catch (System.IO.InvalidDataException) { formatoRechazado = true; }
            exige(formatoRechazado && ReferenceEquals(primera.Costos.Hoja, hojaAntesDeRechazo) &&
                (anteriores, cambios, guardados) == sinCambios,
                "Un color inválido debe rechazarse antes de sustituir la hoja o crear historial.");
            bool validacionRechazada = false;
            try
            {
                Invocar(panel, "EditarFormatoHoja", (Action<MYGCeldaHoja>)(c =>
                { c.TipoValidacion = "Lista"; c.ListaValores = new() { new string('X', 254) }; }));
            }
            catch (System.IO.InvalidDataException) { validacionRechazada = true; }
            exige(validacionRechazada && ReferenceEquals(primera.Costos.Hoja, hojaAntesDeRechazo) &&
                (anteriores, cambios, guardados) == sinCambios,
                "Una regla de validación demasiado larga debe rechazarse sin dejar datos o estilos parcialmente modificados.");

            string formulaGuardada = primera.Costos.Hoja.Celdas["I5"].Contenido;
            Seleccionar(hoja, "J8");
            formula.Text = "=SUM(B3:C3)";
            // Cambiar de partida también debe confirmar el borrador de la barra.
            panel.SeleccionarEstructura(segunda);
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas.TryGetValue("J8", out var borrador) && borrador.Contenido == "=SUM(B3:C3)" &&
                !segunda.Costos.Hoja.Celdas.ContainsKey("J8"),
                "Cambiar de partida debe confirmar la fórmula pendiente en la partida de origen sin escribirla en la siguiente.");
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();
            sinCambios = (anteriores, cambios, guardados);
            panel.SeleccionarEstructura(segunda);
            Application.DoEvents();
            exige(Convert.ToString(hoja.Rows[2].Cells[0].Value) == "Metrado de acero conservado",
                "Cambiar de partida debe cargar su propia hoja sin heredar contenido de la anterior.");
            VerificarCabecera(cabecera, presupuesto.Nombre, "01.02", segunda.Descripcion, exige);
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();
            exige(primera.Costos.Hoja.Celdas["I5"].Contenido == formulaGuardada &&
                primera.Costos.Hoja.Celdas["A3"].Negrita && primera.Costos.Hoja.Celdas["A3"].Cursiva &&
                new MYGHojaCalculo(primera.Costos.Hoja).Numero("I5") == 8m,
                "Volver a una partida debe conservar fórmulas, contenido y estilo sin convertir fórmulas en resultados.");
            exige((anteriores, cambios, guardados) == sinCambios,
                "Cambiar de partida y volver no debe crear modificaciones ni guardar el proyecto.");

            VerificarReferenciasFormula(panel, hoja, formula, primera, segunda,
                () => (anteriores, cambios, guardados), exige);
            VerificarEdicionCombinadas(panel, hoja, formula, direccion, primera,
                () => (anteriores, cambios, guardados), exige);

            Seleccionar(hoja, "A4");
            int filasAntes = primera.Costos.Hoja.Filas;
            Comando(panel, "insertar_filas");
            Application.DoEvents();
            exige(primera.Costos.Hoja.Filas == filasAntes + 1 && hoja.Rows.Count == primera.Costos.Hoja.Filas &&
                primera.Costos.Hoja.CeldaTotal == "G17" && new MYGHojaCalculo(primera.Costos.Hoja).Numero("G17") == 60m &&
                primera.Costos.Hoja.Celdas["I6"].Contenido == formulaGuardada,
                "Insertar una fila debe desplazar contenido y celda total, conservando el cálculo y las referencias.");

            // La restauración del historial reemplaza instancias conservando los Id.
            presupuesto = MYGProyectoStorage.Copia(presupuesto);
            proyecto.Presupuestos[0] = presupuesto;
            var vigente = presupuesto.Items.Single(i => i.Id == primera.Id);
            vigente.Descripcion = "CONCRETO RESTAURADO";
            vigente.Costos.Hoja.Celdas["A3"].Contenido = "Contenido restaurado desde historial";
            vigente.Costos.Hoja.Celdas["A3"].Negrita = true;
            panel.Refrescar();
            Application.DoEvents();
            exige(Convert.ToString(hoja.Rows[2].Cells[0].Value) == "Contenido restaurado desde historial",
                "Refrescar una partida con el mismo Id debe cargar el modelo vigente tras una restauración de historial.");
            VerificarCabecera(cabecera, presupuesto.Nombre, "01.01", vigente.Descripcion, exige);

            Seleccionar(hoja, "D7");
            Comando(panel, "zoom_mas");
            Application.DoEvents();
            exige(vigente.Costos.Hoja.Zoom == 110 && DireccionActual(hoja) == "D7",
                "Cambiar el zoom debe redimensionar la hoja conservando la celda seleccionada.");
            VerificarFuenteEncabezados(hoja, exige);
            Comando(panel, "zoom_100");
            Application.DoEvents();
            exige(vigente.Costos.Hoja.Zoom == 100 && DireccionActual(hoja) == "D7",
                "Restablecer el zoom debe mantener la selección y la dirección de edición.");
            bool lineasAntes = vigente.Costos.Hoja.LineasDivision;
            Comando(panel, "lineas_division");
            Application.DoEvents();
            exige(vigente.Costos.Hoja.LineasDivision != lineasAntes && DireccionActual(hoja) == "D7",
                "Alternar las líneas de división debe conservar la celda seleccionada.");
            Comando(panel, "lineas_division");
            Application.DoEvents();
            sinCambios = (anteriores, cambios, guardados);
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos();
                Application.DoEvents();
                VerificarLimiteSombreado(hoja, exige);
                exige(DireccionActual(hoja) == "D7" && vigente.Costos.Hoja.Celdas["A3"].Contenido == "Contenido restaurado desde historial",
                    "Cambiar el tema debe preservar selección, datos y fórmulas de la hoja.");
                exige(hoja.CellBorderStyle == (vigente.Costos.Hoja.LineasDivision ? DataGridViewCellBorderStyle.Single : DataGridViewCellBorderStyle.None) &&
                    hoja.Rows[2].Cells[0].Style.BackColor.ToArgb() == Color.FromArgb(198, 239, 206).ToArgb() &&
                    hoja.Rows[2].Cells[0].Style.ForeColor.ToArgb() == Color.FromArgb(0, 97, 0).ToArgb(),
                    "El tema debe conservar la cuadrícula elegida y los colores de documento importados de Excel.");
                VerificarNumeracionFilas(hoja, vigente.Costos.Hoja.Filas, exige);
                VerificarFuenteEncabezados(hoja, exige);
                VerificarEncabezadosCentrados(hoja, exige);
                VerificarCabeceraCombinada(hoja, vigente.Costos.Hoja, exige);
                VerificarIconosNitidos(cinta, exige);
                VerificarPestanasCompletas(cinta, exige);
                VerificarCabecera(cabecera, presupuesto.Nombre, "01.01", vigente.Descripcion, exige);
            }
            exige((anteriores, cambios, guardados) == sinCambios,
                "Aplicar la paleta no debe registrar modificaciones ni guardar el metrado.");

            VerificarZoomRueda(panel, hoja, formula, vigente, exige);
            sinCambios = (anteriores, cambios, guardados);

            typeof(MYGPanelPresupuesto).GetField("filtroTextoHoja", Privados).SetValue(panel, "restaurado");
            Comando(panel, "reaplicar_filtro");
            Application.DoEvents();
            exige(hoja.Rows[2].Visible && !hoja.Rows[3].Visible && hoja.CurrentCell != null && hoja.CurrentCell.OwningRow.Visible,
                "El filtro debe usar el contenido del modelo y trasladar la selección a una fila visible.");
            Invocar(panel, "CargarHoja");
            Application.DoEvents();
            exige(hoja.Rows[2].Visible && !hoja.Rows[3].Visible && hoja.CurrentCell?.RowIndex == 2,
                "Recargar una hoja filtrada debe calcular sus datos antes de filtrar y mantener una celda visible.");
            panel.SeleccionarEstructura(presupuesto.Items.Single(i => i.Id == segunda.Id));
            Application.DoEvents();
            exige(hoja.Rows[3].Visible && Convert.ToString(hoja.Rows[2].Cells[0].Value) == "Metrado de acero conservado",
                "Cambiar de partida debe limpiar el filtro local para evitar ocultar datos de la siguiente hoja.");
            panel.SeleccionarEstructura(vigente);
            Application.DoEvents();
            exige((anteriores, cambios, guardados) == sinCambios,
                "Filtrar, recargar y cambiar de partida deben conservar los datos sin crear historial de contenido.");

            VerificarCintaEstrecha(panel, cinta, exige);

            // Cinco dígitos también deben caber en el encabezado después de aplicar el tema.
            int filasOriginales = vigente.Costos.Hoja.Filas;
            string direccionAntesDeAmpliar = DireccionActual(hoja);
            vigente.Costos.Hoja.Filas = 10000;
            Invocar(panel, "CargarHoja");
            panel.AplicarTemaPresupuestos();
            Application.DoEvents();
            VerificarNumeracionFilas(hoja, 10000, exige);
            exige(DireccionActual(hoja) == direccionAntesDeAmpliar && (anteriores, cambios, guardados) == sinCambios,
                "Cargar filas de cinco dígitos y aplicar su presentación debe conservar la selección sin generar historial ni guardar.");
            vigente.Costos.Hoja.Filas = filasOriginales;
            Invocar(panel, "CargarHoja");
            Application.DoEvents();

            panel.SeleccionarEstructura(presupuesto);
            Application.DoEvents();
            exige(!pagina.Enabled && hoja.Rows.Count == 0 && formula.Text == "" && direccion.Text == "",
                "Sin una partida editable, la página debe deshabilitarse y vaciar el contenido de la selección anterior.");
            exige(Etiqueta(cabecera, "item").Text == "" && Etiqueta(cabecera, "partida").Text != vigente.Descripcion,
                "Seleccionar el presupuesto debe limpiar el contexto de la partida en la cabecera de metrado.");
            exige(guardados == 0, "Las comprobaciones de metrado no deben guardar archivos ni bases de datos.");
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static ItemPresupuestoDelphin Partida(string item, string descripcion, int posicion) => new()
    {
        Id = MYGProyectoStorage.NuevoId(), Item = item, Descripcion = descripcion,
        Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = posicion,
        Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
    };

    private static void EditarCelda(MYGPanelPresupuesto panel, DataGridView hoja, string direccion, string texto, Action<bool, string> exige)
    {
        Seleccionar(hoja, direccion);
        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is TextBoxBase,
            "La comprobación debe editar la celda real de la hoja.");
        ((TextBoxBase)hoja.EditingControl).Text = texto;
        panel.FinalizarEdicion();
        Application.DoEvents();
    }

    private static void Seleccionar(DataGridView hoja, string direccion)
    {
        var posicion = MYGHojaCalculo.Coordenadas(direccion);
        hoja.ClearSelection();
        hoja.CurrentCell = hoja.Rows[posicion.Fila - 1].Cells[posicion.Columna - 1];
        hoja.CurrentCell.Selected = true;
    }

    private static string DireccionActual(DataGridView hoja) => hoja.CurrentCell == null ? "" :
        MYGHojaCalculo.Columna(hoja.CurrentCell.ColumnIndex + 1) + (hoja.CurrentCell.RowIndex + 1);

    private static void VerificarFuenteEncabezados(DataGridView hoja, Action<bool, string> exige)
    {
        var filas = hoja.RowHeadersDefaultCellStyle.Font ?? hoja.Font;
        var columnas = hoja.ColumnHeadersDefaultCellStyle.Font ?? hoja.Font;
        exige(filas.FontFamily.Name == "Segoe UI" && columnas.FontFamily.Name == "Segoe UI" &&
            Math.Abs(filas.SizeInPoints - 9f) < .01f && Math.Abs(columnas.SizeInPoints - 9f) < .01f,
            "Las letras de columnas y los números de filas deben conservar Segoe UI de 9 puntos al cambiar el zoom o el tema.");
        exige(hoja.RowHeadersDefaultCellStyle.Alignment == DataGridViewContentAlignment.MiddleCenter &&
            hoja.ColumnHeadersDefaultCellStyle.Alignment == DataGridViewContentAlignment.MiddleCenter,
            "Las letras de columnas y los números de filas deben mantener alineación central horizontal y vertical al cambiar zoom o tema.");
    }

    private static void VerificarSeleccionEncabezados(MYGPanelPresupuesto panel, DataGridView hoja, TextBoxBase formula,
        TextBox direccion, MYGHojaMetrado modelo, Func<(int Antes, int Cambios, int Guardados)> historial,
        Action<bool, string> exige)
    {
        var sinCambios = historial();
        string contenido = System.Text.Json.JsonSerializer.Serialize(modelo);
        Seleccionar(hoja, "G16");
        PulsarEncabezado(hoja, -1, 2);
        exige(hoja.SelectedCells.Count == modelo.Filas &&
            hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.ColumnIndex == 2) &&
            DireccionActual(hoja) == "C1" && direccion.Text == $"C1:C{modelo.Filas}" && formula.Text == "",
            "Pulsar la letra C debe seleccionar su columna completa y mostrar el rango y el contenido de C1 en la barra de fórmulas.");
        PulsarEncabezado(hoja, 1, -1);
        exige(hoja.SelectedCells.Count == modelo.Columnas &&
            hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.RowIndex == 1) &&
            DireccionActual(hoja) == "A2" && direccion.Text == $"A2:{MYGHojaCalculo.Columna(modelo.Columnas)}2" &&
            formula.Text == "Descripción",
            "Pulsar el número 2 debe seleccionar toda su fila y mostrar el rango y la descripción de A2 en la barra de fórmulas.");
        exige(historial() == sinCambios && System.Text.Json.JsonSerializer.Serialize(modelo) == contenido,
            "Seleccionar filas o columnas desde sus encabezados no debe alterar contenido, fórmulas, estilos, historial ni guardado.");

        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 2, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", -1, 4, false, true);
        Application.DoEvents();
        exige(hoja.SelectedCells.Count == 3 * modelo.Filas &&
            hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.ColumnIndex >= 2 && c.ColumnIndex <= 4) &&
            direccion.Text == $"C1:E{modelo.Filas}",
            "Mayús más un encabezado de columna debe extender la selección hasta incluir todas las columnas del intervalo.");
        Invocar(panel, "SeleccionarEncabezadoHoja", 1, -1, false, false);
        Invocar(panel, "SeleccionarEncabezadoHoja", 3, -1, false, true);
        Application.DoEvents();
        exige(hoja.SelectedCells.Count == 3 * modelo.Columnas &&
            hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.RowIndex >= 1 && c.RowIndex <= 3) &&
            direccion.Text == $"A2:{MYGHojaCalculo.Columna(modelo.Columnas)}4",
            "Mayús más un número de fila debe extender la selección hasta incluir todas las filas del intervalo.");
        exige(historial() == sinCambios && System.Text.Json.JsonSerializer.Serialize(modelo) == contenido,
            "Ampliar la selección de encabezados tampoco debe modificar el metrado.");
    }

    private static void PulsarEncabezado(DataGridView hoja, int fila, int columna)
    {
        var mouse = new MouseEventArgs(MouseButtons.Left, 1, 2, 2, 0);
        var evento = new DataGridViewCellMouseEventArgs(columna, fila, 2, 2, mouse);
        string metodo = fila < 0 ? "OnColumnHeaderMouseClick" : "OnRowHeaderMouseClick";
        typeof(DataGridView).GetMethod(metodo, Privados).Invoke(hoja, new object[] { evento });
        Application.DoEvents();
    }

    private static void VerificarCabeceraCombinada(DataGridView hoja, MYGHojaMetrado modelo, Action<bool, string> exige)
    {
        exige(new[] { "A1:C1", "D1:F1", "G1:H1" }.All(modelo.RangosCombinados.Contains),
            "Cargar y restaurar una hoja antigua debe combinar Datos en A1:C1, Dimensiones en D1:F1 y Total en G1:H1.");
        using var captura = new Bitmap(hoja.ClientSize.Width, hoja.ClientSize.Height);
        hoja.DrawToBitmap(captura, hoja.ClientRectangle);
        exige(hoja[0, 0].InheritedStyle.Alignment == DataGridViewContentAlignment.MiddleCenter,
            "El título Datos debe conservar la alineación centrada del documento.");
        var limitesDatos = Rectangle.Union(hoja.GetCellDisplayRectangle(0, 0, false),
            hoja.GetCellDisplayRectangle(2, 0, false));
        VerificarTextoCentrado(captura, limitesDatos, hoja[0, 0].InheritedStyle.ForeColor,
            hoja.DeviceDpi, "Datos en A1:C1", exige);
        foreach (var grupo in new[] { (Inicio: 0, Interior: 1), (Inicio: 3, Interior: 4), (Inicio: 6, Interior: 7) })
        {
            var limiteInterior = hoja.GetCellDisplayRectangle(grupo.Interior, 0, false);
            var muestra = new Point(limiteInterior.Left - 1, limiteInterior.Top + 3);
            if (!hoja.ClientRectangle.Contains(muestra)) continue;
            exige(captura.GetPixel(muestra.X, muestra.Y).ToArgb() == hoja[grupo.Inicio, 0].InheritedStyle.BackColor.ToArgb(),
                "La fila de grupos debe dibujarse como celdas combinadas, sin líneas internas entre los miembros del grupo.");
        }
    }

    private static void VerificarEncabezadosCentrados(DataGridView hoja, Action<bool, string> exige)
    {
        using var captura = new Bitmap(hoja.ClientSize.Width, hoja.ClientSize.Height);
        hoja.DrawToBitmap(captura, hoja.ClientRectangle);
        foreach (int columna in new[] { 0, 2 })
            VerificarTextoCentrado(captura, hoja.GetCellDisplayRectangle(columna, -1, false),
                hoja.ColumnHeadersDefaultCellStyle.ForeColor, hoja.DeviceDpi, "letra " + MYGHojaCalculo.Columna(columna + 1), exige);
        foreach (int fila in new[] { 0, 9 })
        {
            var rectangulo = hoja.GetCellDisplayRectangle(-1, fila, false);
            if (rectangulo.Height > 0 && hoja.ClientRectangle.Contains(rectangulo))
                VerificarTextoCentrado(captura, rectangulo, MYG2027_TemaComercial.Texto, hoja.DeviceDpi,
                    "número " + (fila + 1), exige);
        }
    }

    private static void VerificarTextoCentrado(Bitmap captura, Rectangle rectangulo, Color color, int dpi,
        string nombre, Action<bool, string> exige)
    {
        var interior = Rectangle.Intersect(new Rectangle(Point.Empty, captura.Size), Rectangle.Inflate(rectangulo, -3, -2));
        int x1 = interior.Right, x2 = -1, y1 = interior.Bottom, y2 = -1;
        for (int y = interior.Top; y < interior.Bottom; y++)
            for (int x = interior.Left; x < interior.Right; x++)
            {
                var pixel = captura.GetPixel(x, y);
                if (Math.Abs(pixel.R - color.R) > 75 || Math.Abs(pixel.G - color.G) > 75 || Math.Abs(pixel.B - color.B) > 75) continue;
                x1 = Math.Min(x1, x); x2 = Math.Max(x2, x); y1 = Math.Min(y1, y); y2 = Math.Max(y2, y);
            }
        double margen = Math.Ceiling(3d * dpi / 96d);
        exige(x2 >= x1 && y2 >= y1 && Math.Abs((x1 + x2) / 2d - (rectangulo.Left + (rectangulo.Width - 1) / 2d)) <= margen &&
            Math.Abs((y1 + y2) / 2d - (rectangulo.Top + (rectangulo.Height - 1) / 2d)) <= margen,
            $"El encabezado renderizado de {nombre} debe aparecer centrado horizontal y verticalmente a {dpi} DPI.");
    }

    private static void VerificarIconosNitidos(TabControl cinta, Action<bool, string> exige)
    {
        var botones = Controles(cinta).OfType<ToolStrip>().SelectMany(strip => strip.Items.Cast<ToolStripItem>()).ToArray();
        foreach (string nombre in new[] { "metrado_aumentar_fuente", "metrado_formato_numero_0%" })
        {
            var boton = botones.Single(b => b.Name == nombre);
            int tamano = Math.Max(8, (int)Math.Ceiling(18 * boton.Owner.DeviceDpi / 96f));
            exige(boton.Image is Bitmap imagen && imagen.Width == tamano && imagen.Height == tamano &&
                boton.ImageScaling == ToolStripItemImageScaling.None,
                $"El icono {nombre} debe regenerarse al tamaño real de {tamano} píxeles y evitar ampliar una imagen raster al aplicar el tema.");
            var bitmap = (Bitmap)boton.Image;
            bool transparencia = false, suavizado = false;
            for (int y = 0; y < bitmap.Height; y++)
                for (int x = 0; x < bitmap.Width; x++)
                {
                    byte alpha = bitmap.GetPixel(x, y).A;
                    transparencia |= alpha == 0;
                    suavizado |= alpha > 0 && alpha < 255;
                }
            exige(transparencia && suavizado,
                $"El icono {nombre} debe conservar fondo transparente y bordes suavizados tanto en modo normal como oscuro.");
        }
    }

    private static void VerificarLimiteSombreado(DataGridView hoja, Action<bool, string> exige)
    {
        exige(Enumerable.Range(0, 2).All(f => Enumerable.Range(8, hoja.ColumnCount - 8).All(c =>
            hoja[c, f].Style.BackColor.ToArgb() == MYG2027_TemaComercial.Superficie.ToArgb())),
            "El sombreado automático de la cabecera debe terminar en H y dejar I en adelante con el fondo de la hoja.");
        exige(Enumerable.Range(0, 2).All(f => Enumerable.Range(0, 8).All(c =>
                hoja[c, f].Style.BackColor.ToArgb() == Color.FromArgb(239, 249, 252).ToArgb())),
            "Los grupos y todos los títulos de columnas de A1:H2 deben conservar el relleno celeste en ambos temas.");
        VerificarRellenoEfectivo(hoja, exige);
        var personalizado = EstiloEfectivo(hoja, 0, 2);
        exige(personalizado.BackColor.ToArgb() == Color.FromArgb(198, 239, 206).ToArgb() &&
            personalizado.ForeColor.ToArgb() == Color.FromArgb(0, 97, 0).ToArgb(),
            "El formato efectivo debe conservar también el fondo y el texto de las celdas personalizadas del documento.");
    }

    private static void VerificarRellenoEfectivo(DataGridView hoja, Action<bool, string> exige)
    {
        exige(Enumerable.Range(0, 8).All(c =>
                EstiloEfectivo(hoja, c, 1).BackColor.ToArgb() == Color.FromArgb(239, 249, 252).ToArgb()),
            "CellFormatting debe conservar el relleno celeste efectivo de A2:H2, sin convertirlo en blanco por la paleta general.");
        exige(Enumerable.Range(0, 8).All(c =>
        {
            var estilo = EstiloEfectivo(hoja, c, 1);
            Color seleccion = SystemInformation.HighContrast ? SystemColors.HighlightText : MYG2027_TemaComercial.TextoSeleccion;
            return estilo.ForeColor.ToArgb() == Color.FromArgb(38, 52, 70).ToArgb() &&
                estilo.SelectionForeColor.ToArgb() == seleccion.ToArgb();
        }), "Los títulos celestes deben conservar texto oscuro legible y usar el texto de selección de la paleta, incluso en modo oscuro.");
        using var imagen = new Bitmap(hoja.Width, hoja.Height);
        hoja.DrawToBitmap(imagen, hoja.ClientRectangle);
        var visibles = Enumerable.Range(0, 8).Select(c => hoja.GetCellDisplayRectangle(c, 1, true))
            .Where(r => r.Width > 8 && r.Height > 8 && r.Left >= 0 && r.Right <= imagen.Width && r.Top >= 0 && r.Bottom <= imagen.Height).ToArray();
        exige(visibles.Length > 0 && visibles.All(r =>
                imagen.GetPixel(r.Right - 4, r.Bottom - 4).ToArgb() == Color.FromArgb(239, 249, 252).ToArgb()),
            "El relleno de la fila 2 debe verse en la captura renderizada, además de estar guardado en el modelo.");
    }

    private static void VerificarPartidaNuevaRenderizada(Action<bool, string> exige)
    {
        var documento = MYGProyectoStorage.Nuevo("Partida nueva y paleta");
        var presupuesto = documento.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false);
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => { }, () => { },
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => documento, _ => { }, _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1800, 1000) };
        formulario.Controls.Add(panel); formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        ((TabControl)pagina.Parent).SelectedTab = pagina;
        var hoja = Campo<DataGridView>(panel, "hoja");
        foreach (bool oscuro in new[] { false, true })
        {
            if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
            MYG2027_TemaComercial.Aplicar(formulario);
            panel.AplicarTemaPresupuestos(); Application.DoEvents();
            VerificarRellenoEfectivo(hoja, exige);
            exige(Convert.ToString(hoja[6, 15].FormattedValue) == 0m.ToString("0.00"),
                "Una partida nueva debe mostrar el total cero con dos decimales después de aplicar la paleta global.");
        }
        formulario.Close();
    }

    private static DataGridViewCellStyle EstiloEfectivo(DataGridView hoja, int columna, int fila)
    {
        var celda = hoja[columna, fila];
        var e = new DataGridViewCellFormattingEventArgs(columna, fila, celda.Value, typeof(string), celda.InheritedStyle.Clone());
        typeof(DataGridView).GetMethod("OnCellFormatting", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(hoja, new object[] { e });
        return e.CellStyle;
    }

    private static void VerificarPresentacionDatos(DataGridView hoja, Action<bool, string> exige)
    {
        VerificarFuenteEncabezados(hoja, exige);
        exige(hoja.Rows[2].Cells[0].InheritedStyle.Alignment == DataGridViewContentAlignment.MiddleLeft &&
            hoja.Rows[3].Cells[0].InheritedStyle.Alignment == DataGridViewContentAlignment.MiddleLeft &&
            new[] { 1, 2, 3, 4, 5, 6, 7, 8 }.All(c =>
                hoja.Rows[2].Cells[c].InheritedStyle.Alignment == DataGridViewContentAlignment.MiddleCenter),
            "Los datos de Descripción deben alinearse a la izquierda y los demás datos, incluidos parciales y celdas vacías, deben centrarse.");
        if (FontFamily.Families.Any(f => f.Name.Equals("Arial Narrow", StringComparison.OrdinalIgnoreCase)))
            exige(hoja.Rows[2].Cells[0].InheritedStyle.Font?.FontFamily.Name == "Arial Narrow" &&
                hoja.Rows[2].Cells[6].InheritedStyle.Font?.FontFamily.Name == "Arial Narrow",
                "Arial Narrow debe aplicarse a los datos y los resultados de las fórmulas cuando la fuente está instalada.");
    }

    private static void VerificarZoomRueda(MYGPanelPresupuesto panel, DataGridView hoja, TextBoxBase formula,
        ItemPresupuestoDelphin partida, Action<bool, string> exige)
    {
        var modelo = partida.Costos.Hoja;
        Comando(panel, "zoom_100");
        Seleccionar(hoja, "D7");
        hoja.Rows[6].Cells[4].Selected = true;
        hoja.Rows[7].Cells[3].Selected = true;
        hoja.FirstDisplayedScrollingRowIndex = 3;
        var seleccion = hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex)).ToHashSet();
        int primeraFila = hoja.FirstDisplayedScrollingRowIndex;
        var punto = hoja.PointToScreen(new Point(10, 10));
        exige(!InvocarConResultado<bool>(panel, "ZoomRuedaHoja", 120, false, punto) && modelo.Zoom == 100,
            "La rueda sin Control debe conservar el zoom y permitir el desplazamiento habitual de la hoja.");
        Rueda(hoja, 120, true, punto);
        exige(modelo.Zoom == 110 && DireccionActual(hoja) == "D7" &&
            seleccion.SetEquals(hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex))) &&
            hoja.FirstDisplayedScrollingRowIndex == primeraFila,
            "Control más rueda sobre la hoja debe acercar diez puntos y conservar la selección múltiple y la posición de desplazamiento.");
        VerificarFuenteEncabezados(hoja, exige);

        Seleccionar(hoja, "J10");
        string anterior = new MYGHojaCalculo(modelo).Contenido("J10");
        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is TextBoxBase,
            "El zoom con Control debe poder comprobarse mientras se escribe en la celda real.");
        var editor = (TextBoxBase)hoja.EditingControl;
        editor.Text = "=SUM(B3:C3)";
        editor.Select(5, 2);
        punto = editor.PointToScreen(new Point(2, 2));
        Rueda(editor, -120, true, punto);
        exige(modelo.Zoom == 100 && hoja.IsCurrentCellInEditMode && hoja.EditingControl is TextBoxBase editorVigente &&
            editorVigente.Text == "=SUM(B3:C3)" && editorVigente.SelectionStart == 5 && editorVigente.SelectionLength == 2 &&
            new MYGHojaCalculo(modelo).Contenido("J10") == anterior,
            "Control más rueda sobre el editor de celda debe alejar sin confirmar el borrador ni perder el texto o la selección de escritura.");
        EscapeCelda(hoja);
        Application.DoEvents();

        Seleccionar(hoja, "J11");
        string antesBarra = new MYGHojaCalculo(modelo).Contenido("J11");
        formula.Focus();
        formula.Text = "=SUM(B3:C3)";
        formula.Select(3, 2);
        Rueda(hoja, 120, true, hoja.PointToScreen(new Point(10, 10)));
        exige(modelo.Zoom == 110 && formula.Text == "=SUM(B3:C3)" && formula.SelectionStart == 3 &&
            formula.SelectionLength == 2 && new MYGHojaCalculo(modelo).Contenido("J11") == antesBarra,
            "Acercar con la rueda debe conservar el borrador y la selección de texto de la barra de fórmulas sin confirmar su contenido.");
        Tecla(formula, Keys.Escape);
        Application.DoEvents();
        exige(new MYGHojaCalculo(modelo).Contenido("J11") == antesBarra,
            "Escape debe descartar la fórmula pendiente después del zoom sin escribirla en el metrado.");

        Rueda(hoja, 12000, true, hoja.PointToScreen(new Point(10, 10)));
        exige(modelo.Zoom == 300, "El acercamiento con Control más rueda debe limitarse al 300 por ciento.");
        Rueda(hoja, -12000, true, hoja.PointToScreen(new Point(10, 10)));
        exige(modelo.Zoom == 25, "El alejamiento con Control más rueda debe limitarse al 25 por ciento.");
        Comando(panel, "zoom_100");
        Application.DoEvents();
        VerificarFuenteEncabezados(hoja, exige);
        VerificarPresentacionDatos(hoja, exige);
    }

    private static void EscapeCelda(DataGridView hoja)
    {
        // CancelEdit() restores text but keeps the native editor open.
        // Exercise the user's Escape path, which also ends editing.
        typeof(DataGridView).GetMethod("ProcessEscapeKey", BindingFlags.Instance | BindingFlags.NonPublic)
            .Invoke(hoja, new object[] { Keys.Escape });
    }

    private static void VerificarEdicionCombinadas(MYGPanelPresupuesto panel, DataGridView hoja, TextBoxBase formula,
        TextBox direccion, ItemPresupuestoDelphin partida,
        Func<(int Antes, int Cambios, int Guardados)> historial, Action<bool, string> exige)
    {
        var modelo = partida.Costos.Hoja;
        modelo.Poner("A9", "Valor & único");
        var estilo = MYGEdicionHoja.Celda(modelo, "A8");
        estilo.TamanoFuente = 15; estilo.ColorTexto = "9C0006";
        Invocar(panel, "RecalcularHoja");
        direccion.Text = "A8:C9";
        Invocar(panel, "IrDireccionHoja");
        Comando(panel, "combinar");
        modelo = partida.Costos.Hoja;
        exige(modelo.Celdas["A8"].Contenido == "Valor & único" && modelo.Celdas["A9"].Contenido == "" &&
            modelo.RangosCombinados.Contains("A8:C9"),
            "Combinar con el ancla vacía debe trasladar el único valor de otra celda y crear una sola celda lógica.");

        foreach (string miembro in new[] { "A8", "B8", "C8", "A9", "B9", "C9" })
        {
            Seleccionar(hoja, miembro);
            Application.DoEvents();
            exige(formula.Text == "Valor & único" && direccion.Text == "A8",
                $"Seleccionar {miembro} debe mostrar en la barra el contenido y la dirección del ancla de la combinación.");
            var antesDeCancelar = historial();
            hoja.Focus();
            typeof(DataGridView).GetMethod("OnCellDoubleClick", Privados).Invoke(hoja,
                new object[] { new DataGridViewCellEventArgs(hoja.CurrentCell.ColumnIndex, hoja.CurrentCell.RowIndex) });
            Application.DoEvents();
            exige(hoja.IsCurrentCellInEditMode && hoja.EditingControl is TextBoxBase,
                $"El doble clic en {miembro} debe abrir el editor real de toda la combinación.");
            var editor = (TextBoxBase)hoja.EditingControl;
            exige(editor.Text == "Valor & único" && editor.Font.Equals(hoja[0, 7].InheritedStyle.Font) &&
                editor.ForeColor.ToArgb() == hoja[0, 7].InheritedStyle.ForeColor.ToArgb(),
                "El editor abierto desde cualquier miembro debe cargar el contenido, la fuente y el color del ancla.");
            var area = hoja.RectangleToClient(editor.Parent.RectangleToScreen(editor.Parent.ClientRectangle));
            var inicio = hoja.GetCellDisplayRectangle(0, 7, true);
            var fin = hoja.GetCellDisplayRectangle(2, 8, true);
            exige(area.Left <= inicio.Left + 2 && area.Right >= fin.Right - 2 &&
                area.Top <= inicio.Top + 2 && area.Bottom >= fin.Bottom - 2,
                "El panel del editor debe abarcar el ancho y alto de la combinación completa, sin limitarse a la celda pulsada.");
            editor.Text = "Borrador descartado";
            EscapeCelda(hoja);
            Application.DoEvents();
            exige(!hoja.IsCurrentCellInEditMode && modelo.Celdas["A8"].Contenido == "Valor & único" &&
                new[] { "B8", "C8", "A9", "B9", "C9" }.All(d => string.IsNullOrEmpty(new MYGHojaCalculo(modelo).Contenido(d))) &&
                historial() == antesDeCancelar,
                "Escape desde un miembro debe restaurar el único contenido sin borrar el ancla, crear datos ocultos ni registrar historial.");
        }

        Seleccionar(hoja, "C9");
        hoja.Focus();
        typeof(DataGridView).GetMethod("ProcessF2Key", Privados).Invoke(hoja, new object[] { Keys.F2 });
        exige(hoja.IsCurrentCellInEditMode && hoja.EditingControl is TextBoxBase,
            "F2 desde el interior debe abrir la misma celda combinada sin exigir seleccionar primero su ancla.");
        var editorFormula = (TextBoxBase)hoja.EditingControl;
        editorFormula.Text = "=SUM(B3:C3)";
        editorFormula.Select(5, 2);
        Application.DoEvents();
        exige(panel.EstadoReferenciasHoja.Count == 1 && panel.EstadoReferenciasHoja[0].Rango == "B3:C3",
            "La edición desde un miembro combinado debe conservar el resaltado nativo de referencias de fórmulas.");
        Rueda(editorFormula, 120, true, editorFormula.PointToScreen(new Point(2, 2)));
        exige(hoja.IsCurrentCellInEditMode && editorFormula.Text == "=SUM(B3:C3)" &&
            editorFormula.SelectionStart == 5 && editorFormula.SelectionLength == 2 &&
            editorFormula.Font.Equals(hoja[0, 7].InheritedStyle.Font),
            "El zoom durante la edición combinada debe conservar el borrador, la selección escrita y la fuente del ancla.");
        Rueda(editorFormula, -120, true, editorFormula.PointToScreen(new Point(2, 2)));
        EscapeCelda(hoja);
        Application.DoEvents();

        EditarCelda(panel, hoja, "C9", "Texto final", exige);
        exige(modelo.Celdas["A8"].Contenido == "Texto final" && string.IsNullOrEmpty(new MYGHojaCalculo(modelo).Contenido("C9")),
            "Confirmar el texto desde el interior debe guardar exclusivamente en el ancla y vaciar el miembro visual.");
        formula.Text = "Texto desde barra";
        Invocar(panel, "AplicarFormula");
        exige(modelo.Celdas["A8"].Contenido == "Texto desde barra" && string.IsNullOrEmpty(new MYGHojaCalculo(modelo).Contenido("C9")),
            "La barra de fórmulas debe editar la celda combinada al seleccionar un miembro interior.");
        Comando(panel, "limpiar");
        exige(modelo.Celdas["A8"].Contenido == "", "Borrar desde el interior debe limpiar el contenido visible de la combinación.");
        Clipboard.SetText("Pegado combinado");
        Comando(panel, "pegar");
        modelo = partida.Costos.Hoja;
        exige(modelo.Celdas["A8"].Contenido == "Pegado combinado" && string.IsNullOrEmpty(new MYGHojaCalculo(modelo).Contenido("C9")),
            "Pegar una sola celda desde un miembro debe reemplazar el único contenido combinado.");
        Comando(panel, "copiar");
        exige(Clipboard.GetText() == "Pegado combinado", "Copiar un miembro debe tomar el contenido visible del ancla.");

        modelo.Poner("A11", "Primero conservado");
        modelo.Poner("A12", "Segundo descartado");
        Invocar(panel, "RecalcularHoja");
        direccion.Text = "A11:C12";
        Invocar(panel, "IrDireccionHoja");
        var antesDelAviso = historial();
        VerificarAvisoCombinacion(panel, false, exige);
        exige(ReferenceEquals(modelo, partida.Costos.Hoja) && modelo.Celdas["A11"].Contenido == "Primero conservado" &&
            modelo.Celdas["A12"].Contenido == "Segundo descartado" && !modelo.RangosCombinados.Contains("A11:C12") &&
            historial() == antesDelAviso,
            "Cancelar el aviso de varios valores debe conservar todas las celdas y no registrar modificación alguna.");
        VerificarAvisoCombinacion(panel, true, exige);
        modelo = partida.Costos.Hoja;
        exige(modelo.RangosCombinados.Contains("A11:C12") && modelo.Celdas["A11"].Contenido == "Primero conservado" &&
            modelo.Celdas["A12"].Contenido == "" && historial().Antes == antesDelAviso.Antes + 1 &&
            historial().Cambios == antesDelAviso.Cambios + 1,
            "Aceptar el aviso debe combinar, conservar el primer valor anunciado y registrar una sola modificación.");
        VerificarRecortePinturaCombinada(panel, hoja, exige);

        // Retirar los datos de esta comprobación para conservar las dimensiones
        // y cálculos que comprueba el resto del escenario de metrado.
        MYGEdicionHoja.Separar(modelo, "A8:C9");
        MYGEdicionHoja.Separar(modelo, "A11:C12");
        modelo.Poner("A8", ""); modelo.Poner("A11", "");
        Invocar(panel, "RecalcularHoja");
    }

    private static void VerificarAvisoCombinacion(MYGPanelPresupuesto panel, bool aceptar, Action<bool, string> exige)
    {
        bool mostrado = false, valorCorrecto = false, cancelarPredeterminado = false;
        string error = null;
        var plazo = System.Diagnostics.Stopwatch.StartNew();
        using var temporizador = new System.Windows.Forms.Timer { Interval = 50 };
        temporizador.Tick += (_, _) =>
        {
            if (plazo.Elapsed > TimeSpan.FromSeconds(10))
            {
                Console.Error.WriteLine("La prueba de combinación quedó bloqueada en un diálogo inesperado.");
                Environment.Exit(1); return;
            }
            var aviso = Application.OpenForms.Cast<Form>().FirstOrDefault(f => f.Name == "combinar_aviso");
            if (aviso == null) return;
            temporizador.Stop(); mostrado = true;
            try
            {
                var valor = Controles(aviso).OfType<TextBox>().Single(t => t.Name == "combinar_valor");
                var cancelar = Controles(aviso).OfType<Button>().Single(b => b.Name == "combinar_cancelar");
                valorCorrecto = valor.ReadOnly && valor.Text == "Primero conservado";
                cancelarPredeterminado = ReferenceEquals(aviso.AcceptButton, cancelar) && ReferenceEquals(aviso.CancelButton, cancelar);
                Controles(aviso).OfType<Button>().Single(b => b.Name == (aceptar ? "combinar_aceptar" : "combinar_cancelar")).PerformClick();
            }
            catch (Exception ex) { error = ex.ToString(); aviso.Close(); }
        };
        temporizador.Start();
        Comando(panel, "combinar");
        exige(error == null, "No se pudo operar el aviso de combinación: " + error);
        exige(mostrado && valorCorrecto && cancelarPredeterminado,
            "El aviso previo a descartar varios contenidos debe mostrar exactamente el valor conservado y permitir cancelar mediante Enter o Escape.");
    }

    private static void VerificarRecortePinturaCombinada(MYGPanelPresupuesto panel, DataGridView hoja, Action<bool, string> exige)
    {
        // Una celda debe pintar solamente su sección de la unión. Sin el flag
        // PreserveGraphicsClipping, TextRenderer escribe sobre otros miembros.
        var celda = hoja[3, 0];
        var limites = hoja.GetCellDisplayRectangle(3, 0, false);
        using var captura = new Bitmap(hoja.ClientSize.Width, hoja.ClientSize.Height);
        using var grafico = Graphics.FromImage(captura);
        grafico.Clear(Color.Magenta);
        var evento = new DataGridViewCellPaintingEventArgs(hoja, grafico, limites, limites, 0, 3,
            celda.State, celda.Value, celda.FormattedValue, "", celda.InheritedStyle,
            hoja.AdvancedCellBorderStyle, DataGridViewPaintParts.All);
        Invocar(panel, "PintarCeldaHoja", hoja, evento);
        bool desbordado = false;
        for (int y = 0; y < captura.Height && !desbordado; y++)
            for (int x = 0; x < captura.Width && !desbordado; x++)
                if (!limites.Contains(x, y) && captura.GetPixel(x, y).ToArgb() != Color.Magenta.ToArgb()) desbordado = true;
        exige(evento.Handled && !desbordado,
            "El pintado de cada miembro combinado debe respetar su recorte y evitar texto duplicado o superpuesto fuera de su celda.");
    }

    private static void VerificarReferenciasFormula(MYGPanelPresupuesto panel, DataGridView hoja, TextBoxBase formula,
        ItemPresupuestoDelphin partida, ItemPresupuestoDelphin otra,
        Func<(int Antes, int Cambios, int Guardados)> historial, Action<bool, string> exige)
    {
        var sinCambios = historial();
        var modelo = partida.Costos.Hoja;
        string total = new MYGHojaCalculo(modelo).Contenido("G16");
        Seleccionar(hoja, "G16");
        hoja.FirstDisplayedScrollingRowIndex = hoja.Rows.Cast<DataGridViewRow>().First(f => !f.Frozen && f.Visible).Index;
        hoja.HorizontalScrollingOffset = 0;
        var estiloAntes = hoja.Rows[2].Cells[6].InheritedStyle.Clone();
        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is TextBoxBase,
            "La fórmula de total debe abrirse en el editor real de la celda.");
        var editor = (TextBoxBase)hoja.EditingControl;
        Application.DoEvents();
        var referencias = panel.EstadoReferenciasHoja;
        exige(editor.Text == total && referencias.Count == 1 && referencias[0].Rango == "G3:G15" &&
            referencias[0].FilaInicial == 3 && referencias[0].FilaFinal == 15 &&
            referencias[0].ColumnaInicial == 7 && referencias[0].ColumnaFinal == 7,
            "Abrir una celda con SUM debe resaltar el rango referenciado completo, incluso antes de escribir en la fórmula.");
        Color color = InvocarConResultado<Color>(panel, "ColorReferenciaHoja", referencias[0].IndiceColor);
        VerificarBordeReferencia(hoja, 6, 2, color, exige);
        exige(hoja.Rows[2].Cells[6].InheritedStyle.BackColor == estiloAntes.BackColor &&
            hoja.Rows[2].Cells[6].InheritedStyle.ForeColor == estiloAntes.ForeColor &&
            hoja.Rows[2].Cells[6].InheritedStyle.Alignment == estiloAntes.Alignment,
            "El color temporal de referencias debe dibujarse sin reemplazar el formato ni la alineación guardados de la celda.");

        editor.Text = "=B3*C3/B3";
        Application.DoEvents();
        referencias = panel.EstadoReferenciasHoja;
        exige(referencias.Count == 3 && referencias[0].Rango == "B3" && referencias[1].Rango == "C3" &&
            referencias[2].Rango == "B3" && referencias[0].IndiceColor == referencias[2].IndiceColor &&
            referencias[0].IndiceColor != referencias[1].IndiceColor,
            "Escribir varias referencias debe asignar distintos colores y repetir el mismo color cuando aparece de nuevo la misma celda.");
        editor.Text = "=SUM($D$3:$F$5)";
        Application.DoEvents();
        exige(panel.EstadoReferenciasHoja.Count == 1 && panel.EstadoReferenciasHoja[0].Rango == "D3:F5",
            "Cambiar la fórmula durante la edición debe reemplazar el resaltado y reconocer referencias absolutas de rango.");
        EscapeCelda(hoja);
        Application.DoEvents();
        exige(panel.EstadoReferenciasHoja.Count == 0 && new MYGHojaCalculo(modelo).Contenido("G16") == total &&
            historial() == sinCambios,
            "Cancelar la edición de la celda debe quitar los colores temporales sin modificar la fórmula, guardar ni crear historial.");

        formula.Focus();
        formula.Text = "=SUM(B3:C3)";
        Application.DoEvents();
        exige(panel.EstadoReferenciasHoja.Count == 1 && panel.EstadoReferenciasHoja[0].Rango == "B3:C3",
            "Escribir en la barra de fórmulas debe mostrar también los colores del rango referenciado.");
        Tecla(formula, Keys.Escape);
        Application.DoEvents();
        exige(panel.EstadoReferenciasHoja.Count == 0 && formula.Text == total &&
            new MYGHojaCalculo(modelo).Contenido("G16") == total && historial() == sinCambios,
            "Escape en la barra debe recuperar la fórmula original y limpiar las referencias sin confirmar el borrador.");

        formula.Focus();
        Application.DoEvents();
        exige(panel.EstadoReferenciasHoja.Count == 1,
            "Enfocar la barra de una fórmula existente debe mostrar sus referencias sin cambiar su texto.");
        panel.SeleccionarEstructura(otra);
        Application.DoEvents();
        exige(panel.EstadoReferenciasHoja.Count == 0,
            "Cambiar de partida debe retirar los bordes de las referencias de la hoja anterior.");
        panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        exige(historial() == sinCambios && new MYGHojaCalculo(modelo).Contenido("G16") == total,
            "Enfocar una fórmula existente y cambiar de partida no debe crear historial ni modificar el metrado.");
    }

    private static void VerificarBordeReferencia(DataGridView hoja, int columna, int fila, Color color,
        Action<bool, string> exige)
    {
        var celda = hoja.GetCellDisplayRectangle(columna, fila, false);
        using var captura = new Bitmap(hoja.ClientSize.Width, hoja.ClientSize.Height);
        hoja.DrawToBitmap(captura, hoja.ClientRectangle);
        var borde = Rectangle.Intersect(new Rectangle(Point.Empty, captura.Size),
            new Rectangle(celda.Left, celda.Top, celda.Width, 4));
        bool encontrado = false;
        for (int y = borde.Top; y < borde.Bottom && !encontrado; y++)
            for (int x = borde.Left; x < borde.Right && !encontrado; x++)
            {
                var pixel = captura.GetPixel(x, y);
                encontrado = Math.Abs(pixel.R - color.R) <= 3 && Math.Abs(pixel.G - color.G) <= 3 &&
                    Math.Abs(pixel.B - color.B) <= 3;
            }
        exige(encontrado, "El rango incluido en la fórmula debe mostrar su borde de color en la hoja renderizada, además de registrarse como referencia.");
    }

    private static void Rueda(Control destino, int delta, bool control, Point punto)
    {
        int teclas = control ? 0x0008 : 0;
        EnviarMensaje(destino.Handle, 0x020A, new IntPtr(unchecked((delta << 16) | teclas)),
            new IntPtr(unchecked((punto.Y << 16) | (punto.X & 0xffff))));
        Application.DoEvents();
    }

    private static void Tecla(Control destino, Keys tecla) =>
        typeof(Control).GetMethod("OnKeyDown", Privados).Invoke(destino, new object[] { new KeyEventArgs(tecla) });

    private static void VerificarPestanasCompletas(TabControl cinta, Action<bool, string> exige)
    {
        exige(cinta.Multiline && cinta.SizeMode == TabSizeMode.Normal,
            "La cinta debe medir las pestañas por texto y permitir varias filas en anchos reducidos.");
        for (int i = 0; i < cinta.TabPages.Count; i++)
        {
            string titulo = cinta.TabPages[i].Text;
            var rectangulo = cinta.GetTabRect(i);
            int anchoTexto = TextRenderer.MeasureText(titulo, cinta.Font, Size.Empty, TextFormatFlags.SingleLine).Width;
            exige(rectangulo.Width >= anchoTexto + 20 && cinta.ClientRectangle.Contains(rectangulo),
                $"La pestaña {titulo} debe caber completa y estar visible en la cinta de {cinta.ClientSize.Width} píxeles a {cinta.DeviceDpi} DPI.");
        }
    }

    private static void VerificarCintaEstrecha(MYGPanelPresupuesto panel, TabControl cinta, Action<bool, string> exige)
    {
        // Aislar la cinta evita que los anchos mínimos de los otros paneles limiten esta comprobación.
        var contenedor = cinta.Parent;
        var padre = contenedor.Parent;
        int posicion = padre.Controls.GetChildIndex(contenedor);
        using var formulario = new Form { ClientSize = new Size(800, 300), ShowInTaskbar = false };
        try
        {
            formulario.Controls.Add(contenedor);
            formulario.Show();
            foreach (int ancho in new[] { 800, 420 })
            {
                formulario.ClientSize = new Size(ancho, 300);
                Application.DoEvents();
                foreach (bool oscuro in new[] { false, true })
                {
                    if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                    panel.AplicarTemaPresupuestos();
                    Application.DoEvents();
                    VerificarPestanasCompletas(cinta, exige);
                }
            }
        }
        finally
        {
            padre.Controls.Add(contenedor);
            padre.Controls.SetChildIndex(contenedor, posicion);
            Application.DoEvents();
            formulario.Close();
        }
    }

    private static void VerificarNumeracionFilas(DataGridView hoja, int ultimaFila, Action<bool, string> exige)
    {
        var fuente = hoja.RowHeadersDefaultCellStyle.Font ?? hoja.Font;
        string numero = ultimaFila.ToString();
        int anchoTexto = TextRenderer.MeasureText(numero, fuente, Size.Empty,
            TextFormatFlags.NoPadding | TextFormatFlags.SingleLine).Width;
        int margen = 2 * (int)Math.Ceiling(4f * hoja.DeviceDpi / 96f) + 1;
        exige(hoja.RowHeadersVisible && hoja.ColumnHeadersVisible &&
            Convert.ToString(hoja.Rows[0].HeaderCell.Value) == "1" &&
            Convert.ToString(hoja.Rows[ultimaFila - 1].HeaderCell.Value) == numero &&
            hoja.RowHeadersWidth >= anchoTexto + margen,
            $"La numeración de filas debe permanecer visible y disponer de ancho para {numero} a {hoja.DeviceDpi} DPI.");
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)(objeto.GetType().GetField(nombre, Privados)?.GetValue(objeto)
            ?? throw new InvalidOperationException("No se encontró el campo de integración de metrado: " + nombre));

    private static void Comando(MYGPanelPresupuesto panel, string comando) => Invocar(panel, "EjecutarComandoHoja", comando);

    private static void Invocar(object objeto, string nombre, params object[] argumentos)
        => InvocarConResultado<object>(objeto, nombre, argumentos);

    private static T InvocarConResultado<T>(object objeto, string nombre, params object[] argumentos)
    {
        var metodo = objeto.GetType().GetMethod(nombre, Privados)
            ?? throw new InvalidOperationException("No se encontró el método de metrado: " + nombre);
        try { return (T)metodo.Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        {
            ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
            throw;
        }
    }

    private static void VerificarCabecera(Control cabecera, string presupuesto, string item, string descripcion, Action<bool, string> exige)
    {
        exige(Etiqueta(cabecera, "titulo").Text == "Metrado" && Etiqueta(cabecera, "presupuesto").Text == presupuesto &&
            Etiqueta(cabecera, "item").Text == item && Etiqueta(cabecera, "partida").Text == descripcion,
            "La cabecera de metrado debe compartir el contexto de especificaciones con los datos de la partida vigente.");
        var titulo = Etiqueta(cabecera, "titulo");
        exige(titulo.Font.Bold && titulo.Font.FontFamily.Name == "Segoe UI" && Math.Abs(titulo.Font.SizeInPoints - 14f) < 0.01f,
            "El título Metrado debe usar Segoe UI de 14 puntos en negrita, como Especificaciones técnicas y Análisis de costos unitarios.");
    }

    private static Label Etiqueta(Control cabecera, string dato) =>
        Controles(cabecera).OfType<Label>().Single(e => e.Name == cabecera.Name + "_" + dato);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
