using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MYG_2027;

public sealed class MYGDatosProyecto
{
    public string PropietarioId { get; set; }
    public string Propietario { get; set; }
    public string PortafolioId { get; set; }
    public string Portafolio { get; set; }
    public string TipoObraId { get; set; }
    public string TipoObra { get; set; }
    public string DepartamentoId { get; set; }
    public string Departamento { get; set; }
    public string ProvinciaId { get; set; }
    public string Provincia { get; set; }
    public string DistritoId { get; set; }
    public string Distrito { get; set; }
    public string LocalidadId { get; set; }
    public string Localidad { get; set; }
    public bool UsarUbicacion { get; set; }
    public DateTime? FechaElaboracion { get; set; }
    public DateTime? FechaInicio { get; set; }
    public DateTime? FechaFin { get; set; }
    public decimal Duracion { get; set; } = 1;
    public string UnidadDuracion { get; set; } = "MESES";
    public int? CalendarioId { get; set; }
    public string Calendario { get; set; } = "Predeterminado";
    public string Periodos { get; set; } = "Estándar";
    public string ModalidadEjecucion { get; set; } = "C";
    public bool PorRendimientoCuadrilla { get; set; } = true;
    public bool PorAsignacionRecursos { get; set; }
    public string HechoPor { get; set; }
    public string FirmaImportada { get; set; }

    public static MYGDatosProyecto Crear()
    {
        var datos = new MYGDatosProyecto
        {
            FechaElaboracion = DateTime.Today, FechaInicio = DateTime.Today,
            TipoObra = "Edificaciones", Portafolio = "Construcción"
        };
        datos.CalcularFin();
        return datos;
    }

    public void Validar()
    {
        // Una ficha Delphin puede contener fechas heredadas incoherentes. Leerla
        // o editar sus partidas no autoriza corregirlas: conservarlas únicamente
        // mientras la ficha importada permanezca intacta. Una edición de la
        // ficha vuelve a exigir fechas válidas, igual que un proyecto nuevo.
        bool conservarDatosImportados = !string.IsNullOrWhiteSpace(FirmaImportada) && FirmaImportada == Firma();
        if (Duracion <= 0 || Duracion > 100000)
            throw new InvalidDataException("La duración debe ser mayor que cero y no superar 100 000 unidades.");
        UnidadCanonica(UnidadDuracion);
        if (ModalidadEjecucion != "C" && ModalidadEjecucion != "A")
            throw new InvalidDataException("Seleccione una modalidad de ejecución válida.");
        if (PorRendimientoCuadrilla == PorAsignacionRecursos)
            throw new InvalidDataException("Seleccione una sola forma de análisis: rendimiento de cuadrilla o asignación de recursos.");
        if (FechaInicio.HasValue && FechaFin.HasValue && FechaFin.Value.Date < FechaInicio.Value.Date && !conservarDatosImportados)
            throw new InvalidDataException("La fecha final no puede ser anterior a la fecha de inicio.");
        if (CalendarioId.HasValue && CalendarioId.Value <= 0)
            throw new InvalidDataException("El calendario seleccionado no es válido.");
        // Una obra nativa puede activar la ubicación sin completar su jerarquía.
        // Se conserva al leer o compartir; editar sus datos vuelve a exigirla válida.
        if (UsarUbicacion && !conservarDatosImportados)
        {
            if (string.IsNullOrWhiteSpace(DepartamentoId))
                throw new InvalidDataException("Seleccione un departamento para usar la ubicación del proyecto.");
            if (!string.IsNullOrWhiteSpace(DistritoId) && string.IsNullOrWhiteSpace(ProvinciaId))
                throw new InvalidDataException("Seleccione la provincia antes del distrito.");
            if (!string.IsNullOrWhiteSpace(LocalidadId) && string.IsNullOrWhiteSpace(DistritoId))
                throw new InvalidDataException("Seleccione el distrito antes de la localidad.");
        }
        foreach (string valor in new[] { Propietario, Portafolio, TipoObra, Departamento, Provincia, Distrito,
            Localidad, Calendario, Periodos, HechoPor })
            if (valor != null && (valor.Length > 2000 || valor.Any(char.IsControl)))
                throw new InvalidDataException("Los datos del proyecto contienen un texto no válido.");
    }

    public DateTime? CalcularFin()
    {
        FechaFin = FechaInicio.HasValue ? CalcularFin(FechaInicio.Value, Duracion, UnidadDuracion) : null;
        return FechaFin;
    }

    public static DateTime CalcularFin(DateTime inicio, decimal duracion, string unidadDuracion)
    {
        int dias = ConvertirADiasCalendario(duracion, unidadDuracion);
        return AgregarDiasLimitados(inicio.Date, dias - 1);
    }

    /// <summary>Cuantifica el plazo: mes de 30 días y semana de 7, sin cambiar el calendario de trabajo.</summary>
    public static int ConvertirADiasCalendario(decimal duracion, string unidadDuracion)
    {
        if (duracion <= 0 || duracion > 100000)
            throw new InvalidDataException("La duración debe ser mayor que cero y no superar 100 000 unidades.");
        int factor = UnidadCanonica(unidadDuracion) switch
        {
            "MESES" => 30, "SEMANAS" => 7, _ => 1
        };
        return (int)decimal.Ceiling(duracion * factor);
    }

    private static DateTime AgregarDiasLimitados(DateTime inicio, decimal dias)
    {
        decimal disponibles = (DateTime.MaxValue.Date - inicio).Days;
        return dias >= disponibles ? DateTime.MaxValue.Date : inicio.AddDays((double)dias);
    }

    internal static string UnidadCanonica(string unidad)
    {
        string valor = (unidad ?? "").Trim().ToUpperInvariant().Replace("Í", "I");
        return valor switch
        {
            "DIA" or "DIAS" => "DIAS", "SEMANA" or "SEMANAS" => "SEMANAS", "MES" or "MESES" => "MESES",
            _ => throw new InvalidDataException("La duración debe expresarse en días, semanas o meses.")
        };
    }

    internal string Firma()
    {
        var copia = MYGProyectoStorage.Copia(this);
        copia.FirmaImportada = null;
        // FirmaImportada forma parte de las bases anteriores: su formato debe
        // seguir siendo el JSON histórico aunque el almacenamiento se compacte.
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(
            JsonSerializer.Serialize(copia, MYGProyectoStorage.Opciones))));
    }
}
