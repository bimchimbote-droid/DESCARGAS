using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

/// <summary>Recupera páginas libres importantes después del guardado; no elimina
/// registros ni sustituye la corrección de datos duplicados.</summary>
public static class MYGRecuperacionTamanoSQLite
{
    private const long MinimoBytesLibres = 8L * 1024 * 1024;

    /// <summary>Compacta una base existente cuando tiene al menos 8 MiB libres
    /// y el 25 % de sus páginas está libre. No crea archivos ni confirma
    /// transacciones del llamador. Devuelve false si no corresponde o está ocupada.</summary>
    public static bool Recuperar(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("Indique una base SQLite existente.", nameof(ruta));
        ruta = Path.GetFullPath(ruta);
        if (!File.Exists(ruta)) throw new FileNotFoundException("No existe la base SQLite que se desea compactar.", ruta);
        SQLiteDependencyBootstrapper.Initialize();
        using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false,
            ForeignKeys = true, DefaultTimeout = 1
        }.ToString());
        try
        {
            conexion.Open();
            return Recuperar(conexion);
        }
        catch (SqliteException ex) when (ex.SqliteErrorCode is 5 or 6) { return false; }
    }

    // Sólo se llama DESPUÉS de Commit y de disponer su transacción. Una
    // compactación es mantenimiento opcional: su error no revierte el guardado
    // confirmado ni debe presentarlo al usuario como un guardado fallido.
    // Los errores distintos de bloqueo se registran sin rutas ni datos privados;
    // la API pública explícita sí los propaga para permitir su diagnóstico.
    internal static bool Intentar(SqliteConnection conexion)
    {
        try { return Recuperar(conexion); }
        catch (SqliteException ex)
        {
            if (ex.SqliteErrorCode is not (5 or 6))
                Trace.TraceWarning("No se recuperó espacio libre SQLite (código {0}); el guardado anterior ya está confirmado.", ex.SqliteErrorCode);
            return false;
        }
    }

    private static bool Recuperar(SqliteConnection conexion)
    {
        long paginas = Pragma(conexion, "page_count");
        long libres = Pragma(conexion, "freelist_count");
        long tamanoPagina = Pragma(conexion, "page_size");
        if (paginas <= 0 || libres < 0 || libres > paginas || tamanoPagina <= 0)
            throw new InvalidDataException("La información de páginas SQLite no es válida.");
        if (libres < (MinimoBytesLibres + tamanoPagina - 1) / tamanoPagina || libres < (paginas + 3) / 4)
            return false;
        // VACUUM funciona fuera de transacciones y preserva claves declaradas,
        // valores y relaciones. SQLite puede renumerar rowid implícitos en tablas
        // sin INTEGER PRIMARY KEY; no se usan como identidad persistente de MYG.
        using var comando = conexion.CreateCommand();
        // Se acota cada operación sin alterar DefaultTimeout de la conexión del
        // guardado. Una conexión ajena ocupada no debe retrasar 15 s esta mejora.
        comando.CommandTimeout = 1;
        comando.CommandText = "VACUUM";
        comando.ExecuteNonQuery();
        return true;
    }

    private static long Pragma(SqliteConnection conexion, string nombre)
    {
        using var comando = conexion.CreateCommand(); comando.CommandTimeout = 1;
        comando.CommandText = "PRAGMA " + nombre;
        return Convert.ToInt64(comando.ExecuteScalar(), CultureInfo.InvariantCulture);
    }
}
