using System.Text.Json;
using System.Text.Json.Serialization.Metadata;

namespace MYG_2027;

/// <summary>JSON de almacenamiento sin sangría y sin copias de la hoja inicial
/// integrada. Las opciones de intercambio, copia y firmas permanecen intactas.</summary>
public static class MYGJsonAlmacenamiento
{
    private static readonly JsonSerializerOptions Comparacion = new(MYGProyectoStorage.Opciones)
    { WriteIndented = false };
    private static readonly JsonElement HojaInicial = JsonSerializer.SerializeToElement(MYGHojaMetrado.Crear(), Comparacion);
    internal static readonly JsonSerializerOptions Opciones = CrearOpciones();

    private static JsonSerializerOptions CrearOpciones()
    {
        var resolver = new DefaultJsonTypeInfoResolver();
        resolver.Modifiers.Add(tipo =>
        {
            if (tipo.Type != typeof(MYGDatosPartida)) return;
            foreach (var propiedad in tipo.Properties)
                if (propiedad.Name == nameof(MYGDatosPartida.Hoja))
                    propiedad.ShouldSerialize = (_, valor) => valor == null ||
                        !JsonElement.DeepEquals(JsonSerializer.SerializeToElement((MYGHojaMetrado)valor, Comparacion), HojaInicial);
        });
        return new JsonSerializerOptions(MYGProyectoStorage.Opciones)
        { WriteIndented = false, TypeInfoResolver = resolver };
    }

    // Omitir Hoja sólo es seguro si coincide en TODAS sus propiedades con el
    // inicializador MYGDatosPartida.Hoja = MYGHojaMetrado.Crear(). La comparación
    // incluye formatos, fórmulas, referencias, parámetros y opciones de impresión.
    // null explícito y una hoja vaciada se conservan; no equivalen a la inicial.
    public static string Serializar<T>(T valor) => JsonSerializer.Serialize(valor, Opciones);

    public static T Deserializar<T>(string json) => JsonSerializer.Deserialize<T>(json, Opciones);
}
