using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

/// <summary>Las tablas Delphin son la fuente de los datos nativos; el documento
/// adicional conserva únicamente diferencias y extensiones de MYG. El formato
/// de intercambio y las bases anteriores siguen conteniendo documentos completos.</summary>
public static class MYGDocumentoDelphinAlmacenamiento
{
    private const string Formato = "MYG_DELPHIN_EXTENSIONES";
    private const int Version = 1;
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };
    private static readonly JsonDocumentOptions LecturaJson = new() { MaxDepth = 128 };

    // Invocar después de sincronizar las tablas nativas, en la MISMA transacción.
    // Los proyectos creados por MYG usan identidades distintas de las nativas y
    // conservan su documento compacto completo, sin intentar inferir equivalencias.
    public static string Serializar(SqliteConnection conexion, SqliteTransaction transaccion,
        MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(conexion);
        ArgumentNullException.ThrowIfNull(documento);
        if (!string.Equals(documento.Id, MYGDelphinFormato.IdNativo(documento.Id), StringComparison.Ordinal))
            return MYGJsonAlmacenamiento.Serializar(documento);

        var nativo = DelphinImportacionMYG.LeerProyecto(conexion, documento.Id, transaccion);
        var actual = Nodo(documento);
        var baseNativa = Nodo(nativo);
        var cambios = Diferencia(baseNativa, actual);
        // Sin fechas de proyecto el importador inicializa el cronograma con el
        // día de apertura. Ese valor es una instantánea de MYG, no un dato nativo
        // reproducible: debe conservarse incluso si hoy coincide con la lectura.
        if (documento.Cronograma != null && documento.Datos?.FechaInicio == null &&
            documento.Datos?.FechaElaboracion == null)
        {
            cambios ??= new JsonArray("o", new JsonObject(), new JsonArray());
            cambios[1]["Cronograma"] = Valor(actual["Cronograma"]);
        }
        var salida = new JsonObject
        {
            ["FormatoAlmacenamiento"] = Formato,
            ["VersionAlmacenamiento"] = Version,
            ["Id"] = documento.Id,
            // ListarProyectos consulta estos dos campos sin materializar documentos.
            ["Datos"] = actual["Datos"]?.DeepClone(),
            ["Cambios"] = cambios
        };
        return salida.ToJsonString(Json);
    }

    public static MYGProyectoDocumento Leer(SqliteConnection conexion, string json)
    {
        ArgumentNullException.ThrowIfNull(conexion);
        using var estructura = JsonDocument.Parse(json, LecturaJson);
        if (estructura.RootElement.ValueKind != JsonValueKind.Object)
            throw Invalido("El documento de almacenamiento no es un objeto JSON.");
        if (!estructura.RootElement.TryGetProperty("FormatoAlmacenamiento", out var formato))
            return MYGJsonAlmacenamiento.Deserializar<MYGProyectoDocumento>(json);
        if (formato.ValueKind != JsonValueKind.String || formato.GetString() != Formato ||
            !estructura.RootElement.TryGetProperty("VersionAlmacenamiento", out var version) || version.ValueKind != JsonValueKind.Number ||
            !version.TryGetInt32(out int numero) || numero != Version ||
            !estructura.RootElement.TryGetProperty("Id", out var identidad) || identidad.ValueKind != JsonValueKind.String ||
            string.IsNullOrWhiteSpace(identidad.GetString()) ||
            !estructura.RootElement.TryGetProperty("Cambios", out _))
            throw Invalido("Formato o versión de extensiones Delphin no compatible.");
        string id = identidad.GetString();
        var nativo = DelphinImportacionMYG.LeerProyecto(conexion, id);
        var raiz = JsonNode.Parse(json, documentOptions: LecturaJson);
        var restaurado = Aplicar(Nodo(nativo), raiz["Cambios"]);
        if (restaurado is not JsonObject) throw Invalido("Las extensiones no contienen un proyecto válido.");
        var documento = MYGJsonAlmacenamiento.Deserializar<MYGProyectoDocumento>(restaurado.ToJsonString(Json));
        if (!string.Equals(id, documento?.Id, StringComparison.Ordinal))
            throw Invalido("La identidad de las extensiones no coincide con el proyecto nativo.");
        return documento;
    }

    private static JsonObject Nodo(MYGProyectoDocumento documento) =>
        JsonNode.Parse(MYGJsonAlmacenamiento.Serializar(documento), documentOptions: LecturaJson).AsObject();

    // El patch tiene un vocabulario propio; nunca interpreta propiedades del
    // documento del usuario como instrucciones. null significa sin diferencias;
    // un null explícito se representa ['v',null], y una lista vacía ['v',[]].
    private static JsonNode Diferencia(JsonNode anterior, JsonNode actual)
    {
        if (JsonNode.DeepEquals(anterior, actual)) return null;
        if (anterior is JsonObject objetoAnterior && actual is JsonObject objetoActual)
        {
            var campos = new JsonObject();
            var borrados = new JsonArray();
            foreach (var campo in objetoAnterior)
                if (!objetoActual.ContainsKey(campo.Key)) borrados.Add(campo.Key);
            foreach (var campo in objetoActual)
            {
                if (!objetoAnterior.TryGetPropertyValue(campo.Key, out var valorAnterior))
                    campos[campo.Key] = Valor(campo.Value);
                else
                {
                    var diferencia = Diferencia(valorAnterior, campo.Value);
                    if (diferencia != null) campos[campo.Key] = diferencia;
                }
            }
            return new JsonArray("o", campos, borrados);
        }
        if (anterior is JsonArray listaAnterior && actual is JsonArray listaActual &&
            Identidades(listaAnterior, out var indice) && Identidades(listaActual, out _))
        {
            var elementos = new JsonArray();
            foreach (var elemento in listaActual)
            {
                string id = elemento["Id"].GetValue<string>();
                elementos.Add(indice.TryGetValue(id, out var original)
                    ? new JsonArray("r", id, Diferencia(original, elemento)) : Valor(elemento));
            }
            // La membresía original permite distinguir las bajas expresas de
            // MYG de las filas añadidas después por Delphin. Estas últimas no
            // deben desaparecer al aplicar una extensión de otra partida.
            var membresia = new JsonArray();
            foreach (string id in indice.Keys) membresia.Add(id);
            // No sustituir este patch por la lista completa aunque ocupe menos:
            // también una lista pequeña o vaciada debe reconocer altas nativas
            // posteriores en vez de ocultarlas bajo una instantánea completa.
            return new JsonArray("a", elementos, membresia);
        }
        return Valor(actual);
    }

    private static bool Identidades(JsonArray lista, out Dictionary<string, JsonNode> indice)
    {
        indice = new Dictionary<string, JsonNode>(StringComparer.Ordinal);
        foreach (var elemento in lista)
        {
            if (elemento is not JsonObject objeto || objeto["Id"] is not JsonValue valor ||
                !valor.TryGetValue<string>(out string id) || string.IsNullOrEmpty(id) ||
                !indice.TryAdd(id, elemento)) return false;
        }
        return true;
    }

    private static JsonArray Valor(JsonNode valor) => new("v", valor?.DeepClone());

    private static JsonNode Aplicar(JsonNode anterior, JsonNode patch)
    {
        if (patch == null) return anterior?.DeepClone();
        if (patch is not JsonArray instrucciones || instrucciones.Count == 0 ||
            instrucciones[0] is not JsonValue etiqueta || !etiqueta.TryGetValue<string>(out string tipo))
            throw Invalido("Las extensiones del documento están dañadas.");
        if (tipo == "v" && instrucciones.Count == 2) return instrucciones[1]?.DeepClone();
        if (tipo == "o" && instrucciones.Count == 3 && anterior is JsonObject objetoAnterior &&
            instrucciones[1] is JsonObject campos && instrucciones[2] is JsonArray borrados)
        {
            var resultado = (JsonObject)objetoAnterior.DeepClone();
            foreach (var borrado in borrados)
            {
                if (borrado is not JsonValue nombre || !nombre.TryGetValue<string>(out string campo) ||
                    !resultado.Remove(campo)) throw Invalido("Una propiedad nativa requerida ya no existe.");
            }
            foreach (var campo in campos)
            {
                resultado.TryGetPropertyValue(campo.Key, out var original);
                resultado[campo.Key] = Aplicar(original, campo.Value);
            }
            return resultado;
        }
        if (tipo == "a" && instrucciones.Count == 3 && anterior is JsonArray listaAnterior &&
            instrucciones[1] is JsonArray elementos && instrucciones[2] is JsonArray membresia &&
            Identidades(listaAnterior, out var indice))
        {
            var resultado = new JsonArray();
            var referencias = new HashSet<string>(StringComparer.Ordinal);
            var originales = new HashSet<string>(StringComparer.Ordinal);
            foreach (var identidadOriginal in membresia)
                if (identidadOriginal is not JsonValue valorOriginal || !valorOriginal.TryGetValue<string>(out string idOriginal) ||
                    string.IsNullOrEmpty(idOriginal) || !originales.Add(idOriginal))
                    throw Invalido("La membresía original de una lista está dañada.");
            foreach (var entrada in elementos)
            {
                if (entrada is not JsonArray elemento || elemento.Count == 0 || elemento[0] is not JsonValue marca ||
                    !marca.TryGetValue<string>(out string operacion)) throw Invalido("Una referencia de la lista está dañada.");
                if (operacion == "v" && elemento.Count == 2) resultado.Add(elemento[1]?.DeepClone());
                else if (operacion == "r" && elemento.Count == 3 && elemento[1] is JsonValue identidad &&
                    identidad.TryGetValue<string>(out string id) && originales.Contains(id) &&
                    referencias.Add(id) && indice.TryGetValue(id, out var original))
                    resultado.Add(Aplicar(original, elemento[2]));
                else throw Invalido("Falta una fila nativa requerida por las extensiones Delphin.");
            }
            if (!Identidades(resultado, out var presentes)) throw Invalido("Las extensiones contienen identidades de lista inválidas.");
            foreach (var nueva in listaAnterior)
            {
                string id = nueva["Id"].GetValue<string>();
                if (!originales.Contains(id) && !presentes.ContainsKey(id)) resultado.Add(nueva.DeepClone());
            }
            return resultado;
        }
        throw Invalido("La operación de extensiones Delphin no es compatible con sus datos nativos.");
    }

    private static InvalidDataException Invalido(string mensaje) => new(mensaje);
}
