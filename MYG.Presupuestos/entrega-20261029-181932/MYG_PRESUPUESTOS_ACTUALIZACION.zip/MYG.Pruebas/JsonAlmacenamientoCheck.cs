using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class JsonAlmacenamientoCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        var inicial = new MYGDatosPartida();
        string original = JsonSerializer.Serialize(inicial);
        string compacto = MYGJsonAlmacenamiento.Serializar(inicial);
        using (var json = JsonDocument.Parse(compacto))
            Exige(!json.RootElement.TryGetProperty("Hoja", out _), "La hoja inicial completa sigue duplicada en el JSON.");
        Exige(compacto.Length < original.Length / 4, "La omisión de la plantilla inicial no redujo el almacenamiento.");
        Iguales(inicial, MYGJsonAlmacenamiento.Deserializar<MYGDatosPartida>(compacto));
        Iguales(inicial, JsonSerializer.Deserialize<MYGDatosPartida>(compacto));
        Exige(JsonSerializer.Serialize(inicial) == original, "Serializar alteró la hoja en memoria.");
        pasa("JSON de almacenamiento omite sólo la hoja inicial exacta y los lectores anteriores reconstruyen sus fórmulas y formatos completos");

        Action<MYGHojaMetrado>[] cambios =
        {
            h => h.Poner("B3", "3.1415926535897932384626433832"),
            h => h.Celdas["G3"].Contenido += " ",
            h => h.Celdas["A1"].ColorFondo = "ABCDEF",
            h => h.Celdas["A1"].TamanoFuente = 11.25m,
            h => h.Celdas["A1"].ListaValores.Add("Opción nueva"),
            h => h.Celdas.Remove("G3"),
            h => h.Celdas["A1"] = null,
            h => h.CeldaTotal = "G17",
            h => h.AnchosColumnas[1]++,
            h => h.AltosFilas[3] = 37,
            h => h.FilasOcultas.Add(4),
            h => h.RangosCombinados.RemoveAt(0),
            h => h.Zoom = 175,
            h => h.MargenIzquierdo = 0.75m,
            h => h.ContenidoInicialPlantilla = new() { ["A1"] = "Cabecera personalizada" },
            h => h.IdPlantilla = "",
            h => h.RangoCuerpoPlantilla = "",
            h => h.AreaImpresion = "A1:H20",
            h => h.RepetirTitulos = true
        };
        foreach (var cambiar in cambios)
        {
            var datos = new MYGDatosPartida(); cambiar(datos.Hoja);
            string json = MYGJsonAlmacenamiento.Serializar(datos);
            using (var documento = JsonDocument.Parse(json))
                Exige(documento.RootElement.TryGetProperty("Hoja", out _), "Una hoja editada fue sustituida por la plantilla inicial.");
            Iguales(datos, MYGJsonAlmacenamiento.Deserializar<MYGDatosPartida>(json));
        }
        pasa("JSON conserva metrados, fórmulas, formatos, validaciones, parámetros, borrados de celdas y configuración de impresión distintos de la plantilla");

        foreach (var datos in new[] { new MYGDatosPartida { Hoja = null }, new MYGDatosPartida { Hoja = new() } })
        {
            string json = MYGJsonAlmacenamiento.Serializar(datos);
            using (var documento = JsonDocument.Parse(json))
                Exige(documento.RootElement.TryGetProperty("Hoja", out _), "Se confundió una hoja nula o vacía con la plantilla inicial.");
            Iguales(datos, MYGJsonAlmacenamiento.Deserializar<MYGDatosPartida>(json));
        }
        var vaciada = new MYGDatosPartida(); vaciada.Hoja.Celdas.Clear();
        Iguales(vaciada, MYGJsonAlmacenamiento.Deserializar<MYGDatosPartida>(MYGJsonAlmacenamiento.Serializar(vaciada)));
        pasa("JSON distingue una hoja nula, vacía o borrada de la plantilla inicial sin regenerar contenido eliminado");

        var reordenada = new MYGDatosPartida();
        reordenada.Hoja.Celdas = reordenada.Hoja.Celdas.Reverse().ToDictionary(x => x.Key, x => x.Value);
        using (var json = JsonDocument.Parse(MYGJsonAlmacenamiento.Serializar(reordenada)))
            Exige(!json.RootElement.TryGetProperty("Hoja", out _), "El orden de inserción del diccionario impide reconocer la misma plantilla.");
        Iguales(inicial, MYGJsonAlmacenamiento.Deserializar<MYGDatosPartida>(original));
        pasa("JSON de almacenamiento lee el formato anterior y reconoce la misma hoja aunque cambie el orden de sus celdas");

        var proyecto = MYGProyectoStorage.Nuevo("Proyecto con Unicode: ñ, m³ y 漢字");
        proyecto.Presupuestos[0].Items.Add(new()
        {
            Id = "PARTIDA-JSON", IdLocalMYG = "LOCAL-JSON", TipoPropuesta = "PARTIDA", Unidad = "m³",
            Costos = new() { Cantidad = 0.1234567890123456789012345678m,
                PrecioDirecto = 9876543210.123456789012345678m, EspecificacionTexto = "\"Cita\"\n\\ruta\\archivo", Hoja = MYGHojaMetrado.Crear() }
        });
        string proyectoOriginal = JsonSerializer.Serialize(proyecto);
        Iguales(proyecto, MYGJsonAlmacenamiento.Deserializar<MYGProyectoDocumento>(MYGJsonAlmacenamiento.Serializar(proyecto)));
        Exige(JsonSerializer.Serialize(proyecto) == proyectoOriginal, "El almacenamiento cambió el documento o su precisión en memoria.");
        pasa("JSON compacto conserva documentos anidados, identidades, Unicode, escapes y precisión decimal sin mutar el original");
    }

    private static void Iguales<T>(T esperado, T obtenido) => Exige(
        JsonElement.DeepEquals(JsonSerializer.SerializeToElement(esperado), JsonSerializer.SerializeToElement(obtenido)),
        "El recorrido JSON de almacenamiento perdió o cambió información.");
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
}
