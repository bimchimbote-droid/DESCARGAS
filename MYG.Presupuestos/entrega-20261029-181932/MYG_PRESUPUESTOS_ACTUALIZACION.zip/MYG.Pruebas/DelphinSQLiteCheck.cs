using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinSQLiteCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static string Huella(string ruta)
    {
        using var archivo = File.OpenRead(ruta);
        return Convert.ToHexString(SHA256.HashData(archivo));
    }

    private static SqliteConnection Conexion(string ruta)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open(); return c;
    }

    private static object Valor(string ruta, string consulta, params object[] valores)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = consulta;
        for (int n = 0; n < valores.Length; n++) cmd.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        return cmd.ExecuteScalar();
    }

    private static long Cuenta(string ruta, string tabla) =>
        Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM " + tabla), CultureInfo.InvariantCulture);

    private static decimal Numero(string ruta, string consulta, params object[] valores) =>
        Convert.ToDecimal(Valor(ruta, consulta, valores), CultureInfo.InvariantCulture);

    private static void Integridad(string ruta, string relacionesOriginales = null)
    {
        Exige((string)Valor(ruta, "PRAGMA integrity_check") == "ok", "La base Delphin no supera integrity_check.");
        if (relacionesOriginales != null)
        {
            Exige(Instantanea(ruta, "PRAGMA foreign_key_check") == relacionesOriginales,
                "La escritura cambió las anomalías de relaciones que ya existían en la muestra Delphin.");
            return;
        }
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "PRAGMA foreign_key_check";
        using var r = cmd.ExecuteReader();
        Exige(!r.Read(), "La base Delphin contiene relaciones SQL inválidas.");
    }

    private static ItemPresupuestoDelphin Nodo(string nombre, string unidad, string padre = null)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = nombre, Unidad = unidad,
            ParentId = padre, TipoPropuesta = string.IsNullOrEmpty(unidad) ? "TITULO" : "PARTIDA",
            Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1
        };
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Formato nativo Delphin 2024.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        Exige(Convert.ToInt64(Valor(ruta, "SELECT valor_parametro FROM parametro WHERE id_parametro='last_updated'")) == 20250529 &&
            (string)Valor(ruta, "SELECT valor_texto FROM parametro WHERE id_parametro='last_updated'") == "20121102",
            "La hoja nueva no registra la revisión del esquema nativo y Delphin intentará repetir sus migraciones.");
        Exige(Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM pragma_table_info('composicion_costounitario')
            WHERE name IN ('cantidad_ejecutada','metrado_ejecutado','parcial_ejecutado','cantidad_ordenada','parcial_ordenado')
            """)) == 5 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM pragma_table_info('presupuesto') WHERE name='id_responsable'")) == 1,
            "La revisión declarada no corresponde a las columnas nativas de seguimiento ya inicializadas.");
        Exige(Encoding.ASCII.GetString(File.ReadAllBytes(ruta), 0, 16) == "SQLite format 3\0",
            "La hoja nueva no es un archivo SQLite real.");
        Exige(Convert.ToInt64(Valor(ruta, "SELECT version FROM myg_info")) == 4 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")) >= 198,
            "La hoja nueva no contiene el esquema nativo Delphin y sus extensiones MYG v4.");
        foreach (string tabla in new[] { "proyecto", "presupuesto", "titulo", "costo_unitario", "producto",
            "unidad", "tipo_costo", "analisis_costo", "subtotal_costounitario", "composicion_costounitario",
            "subtotal_analisiscosto", "composicion_analisiscosto", "responsable", "myg_proyecto", "myg_presupuesto" })
            Exige(Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=$p0", tabla)) == 1,
                "Falta una tabla del formato nativo: " + tabla + ".");
        Exige(Cuenta(ruta, "proyecto") == 0 && Cuenta(ruta, "presupuesto") == 0 && Cuenta(ruta, "producto") == 0 &&
            Cuenta(ruta, "analisis_costo") == 0 && Cuenta(ruta, "unidad") == 62,
            "La hoja nueva debe tener el catálogo nativo de unidades sin obras, recursos ni partidas de la muestra.");
        Exige(Cuenta(ruta, "tipo_costo") == 5 && Cuenta(ruta, "unidad_tipocosto") == 53 &&
            Cuenta(ruta, "unidad_tipocostonew") == 97,
            "El catálogo de unidades no conserva las dos relaciones nativas con los tipos de costo Delphin.");
        UnidadesDelphinCheck.Ejecutar(ruta, carpeta, pasa);
        var unidadesIniciales = UnidadesDelphinCheck.Capturar(ruta);
        ComprobarAccesoInicial(ruta, pasa);
        var accesoInicial = CapturarAcceso(ruta);
        string antesLeer = Huella(ruta);
        Exige(LectorDelphin.LeerProyectosSQLite(ruta).Count == 0 && LectorDelphin.LeerCatalogoPartidasSQLite(ruta).Count == 0,
            "El lector Delphin no puede consultar una hoja nueva.");
        Exige(Huella(ruta) == antesLeer, "Consultar una hoja nueva modificó el archivo SQLite.");
        pasa("Hoja .sqlite nueva incluye esquema Delphin 2024, MYG v4 y su catálogo completo de unidades sin copiar obras de la muestra");
        pasa("Hoja nueva declara la revisión Delphin del esquema creado, evitando un historial ausente o en cero");
        ComprobarRevisionExistente(carpeta, pasa);
        ComprobarAccesoExistente(carpeta, pasa);

        var primera = MYGProyectoStorage.Nuevo("OBRA NATIVA A", "PRESUPUESTO A");
        var p = primera.Presupuestos[0];
        p.Costos.DecimalesPrecio = 4; p.Costos.DecimalesCantidad = 6;
        var titulo = Nodo("ESTRUCTURAS NATIVAS", "");
        var partida = Nodo("PARTIDA CON LOS CINCO GRUPOS", "m²", titulo.Id);
        partida.Costos.Cantidad = 2.5m; partida.Costos.RendimientoDiario = 10m;
        partida.Costos.EspecificacionTexto = "Especificación sintética de prueba.";
        var auxiliar = Nodo("SUBPARTIDA DE PRUEBA", "m²", titulo.Id);
        auxiliar.Costos.PrecioDirecto = 3.25m;
        foreach (var grupo in new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales,
            MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos })
        {
            var insumo = new MYGInsumo
            {
                Codigo = "NAT-" + (int)grupo, Descripcion = "RECURSO NATIVO " + grupo,
                Grupo = grupo, Unidad = grupo == MYGGrupoRecurso.ManoObra ? "hh" : grupo == MYGGrupoRecurso.Equipo ? "hm" : "kg",
                Precio = 2.3456m + (int)grupo
            };
            p.Costos.Insumos.Add(insumo);
            partida.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Grupo = grupo, Cantidad = 0.25m + (int)grupo });
        }
        partida.Costos.Analisis.Add(new MYGRecursoACU
        { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = auxiliar.IdLocalMYG, Cantidad = 1.5m });
        p.Items.AddRange(new[] { titulo, partida, auxiliar });
        MYGProyectoStorage.Renumerar(p);
        primera.Presupuestos.Add(new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA NATIVA", Item = "02", Posicion = 2 });
        var segunda = MYGProyectoStorage.Nuevo("OBRA NATIVA B", "PRESUPUESTO B");
        var otra = Nodo("PARTIDA DE OTRA OBRA", "und"); otra.Costos.Cantidad = 3; otra.Costos.PrecioDirecto = 7.5m;
        segunda.Presupuestos[0].Items.Add(otra); MYGProyectoStorage.Renumerar(segunda.Presupuestos[0]);
        MYGProyectoStorage.Guardar(ruta, primera); MYGProyectoStorage.Guardar(ruta, segunda);
        Exige(Cuenta(ruta, "proyecto") == 2 && Cuenta(ruta, "presupuesto") == 3 && Cuenta(ruta, "costo_unitario") == 4 &&
            Cuenta(ruta, "producto") == 4 && Cuenta(ruta, "subtotal_costounitario") == 5 && Cuenta(ruta, "composicion_costounitario") == 5,
            "Las tablas nativas no representan las obras, presupuestos y cinco grupos del ACU.");
        Exige(Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM proyecto p JOIN usuario u ON u.id_usuario=p.id_usuario
            WHERE u.login_usuario=$p0
            """, "Administrador")) == 2,
            "Los proyectos nuevos no quedan relacionados con el administrador de la hoja Delphin.");
        ConservarAcceso(ruta, accesoInicial);
        UnidadesDelphinCheck.Conservar(ruta, unidadesIniciales);
        pasa("Las obras nuevas pertenecen al administrador sin reinicializar su cuenta, permisos ni sucursal");
        Exige(Numero(ruta, "SELECT costo_unitario FROM costo_unitario WHERE descripcion_costo=$p0", partida.Descripcion) ==
            MYGMotorPresupuestos.Analizar(p, partida).PrecioUnitario &&
            Numero(ruta, "SELECT parcial_costo FROM costo_unitario WHERE descripcion_costo=$p0", partida.Descripcion) ==
            MYGMotorPresupuestos.TotalPartida(p, partida), "El precio o parcial nativo difiere del ACU MYG.");
        antesLeer = Huella(ruta);
        var obrasNativas = LectorDelphin.LeerProyectosSQLite(ruta);
        var obraNativa = obrasNativas.Single(x => x.Nombre == primera.Nombre);
        var presupuestosNativos = LectorDelphin.LeerPresupuestosSQLite(ruta, obraNativa.Id);
        var presupuestoNativo = presupuestosNativos.Single(x => x.Nombre == p.Nombre);
        var itemsNativos = LectorDelphin.LeerItemsPresupuestoSQLite(ruta, presupuestoNativo.Id);
        var partidaNativa = itemsNativos.Single(x => x.Descripcion == partida.Descripcion);
        Exige(obrasNativas.Count == 2 && presupuestosNativos.Count == 2 && itemsNativos.Count == 3,
            "El lector Delphin perdió proyectos, presupuestos o partidas de la hoja creada por MYG.");
        Exige(partidaNativa.Unidad == "m²", "El lector Delphin no conservó el superíndice de la unidad de la partida MYG.");
        Exige(partidaNativa.ParentId == itemsNativos.Single(x => x.Descripcion == titulo.Descripcion).Id,
            "El lector Delphin no conservó el título padre de la partida MYG.");
        Exige(string.IsNullOrWhiteSpace(itemsNativos.Single(x => x.Descripcion == titulo.Descripcion).Unidad),
            "El lector Delphin asignó una unidad a un título MYG.");
        Exige(Huella(ruta) == antesLeer, "El lector Delphin modificó la hoja creada por MYG.");
        Integridad(ruta);
        pasa("Lectura Delphin de hoja MYG reconoce dos obras, tres presupuestos, jerarquía y ACU nativo con cinco grupos");

        var unidadPropia = MYGCatalogoUnidades.Guardar(ruta,
            new MYGUnidadCatalogo { Simbolo = "SYN_JGO", Descripcion = "Juego sintético de prueba" });
        Exige((string)Valor(ruta, "SELECT informacion_unidad FROM unidad WHERE abreviatura_unidad='SYN_JGO'") == unidadPropia.Descripcion,
            "La unidad propia no se reflejó en el catálogo nativo Delphin.");
        var entradaInsumo = MYGCatalogos.GuardarInsumo(ruta, p.Costos.Insumos[1]);
        var entradaPartida = MYGCatalogos.GuardarPartida(ruta, p, partida, "NAT-P-01", partida.Descripcion, partida.Unidad);
        // Un recurso del presupuesto y su copia de catálogo pueden compartir código;
        // se verifica la entrada de catálogo por identidad, sin confundir ambas copias.
        Exige(Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM producto p JOIN myg_delphin_fila f " +
            "ON f.tabla='producto' AND f.id_nativo=p.id_producto WHERE p.codigo_producto=$p0 AND f.propietario=$p1",
            entradaInsumo.Codigo, "catalogo_insumo:" + entradaInsumo.Id)) == 1 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM analisis_costo a JOIN myg_delphin_fila f " +
            "ON f.tabla='analisis_costo' AND f.id_nativo=a.id_analisiscosto WHERE a.codigo_listaprecio=$p0 AND f.propietario=$p1",
            entradaPartida.Codigo, "catalogo_partida:" + entradaPartida.Id)) == 1,
            "Los catálogos MYG no se reflejaron en las tablas nativas de insumos y partidas.");
        var catalogoNativo = LectorDelphin.LeerCatalogoPartidasSQLite(ruta).Single(x => x.Codigo == entradaPartida.Codigo);
        Exige(catalogoNativo.Descripcion == entradaPartida.Descripcion && catalogoNativo.Unidad == entradaPartida.Unidad &&
            Cuenta(ruta, "composicion_analisiscosto") == 5,
            "El catálogo nativo perdió la partida, su unidad o el análisis guardado.");
        MYGCatalogoUnidades.Eliminar(ruta, unidadPropia.Id);
        Exige(Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad='SYN_JGO'")) == 0,
            "Eliminar una unidad propia sin uso no actualizó el catálogo nativo.");
        ConservarAcceso(ruta, accesoInicial);
        UnidadesDelphinCheck.Conservar(ruta, unidadesIniciales);
        Integridad(ruta);
        pasa("Catálogos de partidas, insumos y unidades se guardan también en tablas Delphin consultables por su lector");

        ComprobarPrecioImportado(pasa);
        string muestra = Environment.GetEnvironmentVariable("MYG_QA_DELPHIN_SQLITE");
        if (!string.IsNullOrWhiteSpace(muestra)) ComprobarMuestra(Path.GetFullPath(muestra), carpeta, pasa);
        else Console.WriteLine("OMITIDA: muestra externa Delphin (MYG_QA_DELPHIN_SQLITE no definido).");
    }

    private static void ComprobarAccesoInicial(string ruta, Action<string> pasa)
    {
        // Estos son los datos de acceso predeterminados indicados por el usuario;
        // no se importan otras cuentas, contraseñas ni datos de una base externa.
        Exige(Cuenta(ruta, "usuario") == 1 && Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM usuario
            WHERE login_usuario=$p0 AND clave_usuario=$p1 AND tipo_encripta='NON'
                AND estado_usuario='S' AND es_principal='S'
            """, "Administrador", "1234")) == 1,
            "La hoja nueva no contiene la cuenta predeterminada activa que Delphin puede consultar.");
        Exige(Convert.ToInt64(Valor(ruta, "SELECT ultimo_numero FROM secuencia WHERE nombre_secuencia='id_usuario'")) == 1,
            "El contador de usuarios no reconoce la cuenta inicial y puede repetir su identificador.");
        Exige(Cuenta(ruta, "perfil") == 1 && Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM usuario u JOIN perfil p ON p.id_perfil=u.id_perfil
            WHERE u.login_usuario=$p0 AND p.requiere_sucursal='S'
                AND p.requiere_caja='N' AND p.cambiar_sucursal='S'
            """, "Administrador")) == 1,
            "El administrador no tiene un perfil Delphin válido con selección de sucursal sin exigir una caja.");
        Exige(Cuenta(ruta, "perfil_map") == 256 && Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM usuario u JOIN perfil_map m ON m.id_perfil=u.id_perfil
            WHERE u.login_usuario=$p0 AND TRIM(m.id_acceso)<>'' AND TRIM(m.nombre_acceso)<>''
            """, "Administrador")) == 256 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM perfil_map WHERE permitido='S'")) == 172 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM perfil_map WHERE permitido='N'")) == 68 &&
            Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM perfil_map WHERE permitido='X'")) == 16,
            "El perfil de la hoja nueva no conserva los accesos y estados técnicos del administrador nativo.");
        // La sucursal obligatoria se genera con referencias propias y datos neutros,
        // sin copiar una empresa, sus documentos de identidad ni sus contactos.
        Exige(Cuenta(ruta, "sucursal") == 1 && Cuenta(ruta, "persona") == 1 && Cuenta(ruta, "tipo_persona") == 1 &&
            Convert.ToInt64(Valor(ruta, """
                SELECT COUNT(*) FROM usuario u
                JOIN sucursal s ON s.id_sucursal=u.id_sucursalasignada
                JOIN persona e ON e.id_persona=s.id_persona
                JOIN tipo_persona tp ON tp.id_tipopersona=e.id_tipopersona
                WHERE u.login_usuario=$p0 AND s.estado_sucursal='S' AND s.es_oficinacentral='S'
                    AND s.es_domiciliofiscal='S' AND s.nombre_sucursal='Principal'
                    AND e.estado_persona='S' AND e.clase_persona='JURIDICA' AND e.nombre_persona='Empresa'
                    AND UPPER(tp.descripcion_tipopersona)='EMPRESA' AND tp.clase_persona='JURIDICA'
                """, "Administrador")) == 1,
            "La sucursal asignada al administrador no tiene una empresa y un tipo de persona válidos.");
        // parametro no declara FK a persona: integrity_check por sí solo no
        // detecta la ausencia del enlace que Delphin exige al iniciar sesión.
        Exige(Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM parametro p
            JOIN persona e ON e.id_persona=p.valor_parametro
            JOIN sucursal s ON s.id_persona=e.id_persona
            JOIN usuario u ON u.id_sucursalasignada=s.id_sucursal
            WHERE p.id_parametro IN ('EMP_ID','emp_id') AND p.descripcion_parametro='Empresa Actual'
                AND typeof(p.valor_parametro)='integer' AND e.estado_persona='S'
                AND e.clase_persona='JURIDICA' AND e.id_institucion=e.id_persona
                AND u.login_usuario=$p0
            """, "Administrador")) == 2 &&
            (string)Valor(ruta, "SELECT valor_texto FROM parametro WHERE id_parametro='EMP_ID'") == "" &&
            Valor(ruta, "SELECT valor_texto FROM parametro WHERE id_parametro='emp_id'") == DBNull.Value,
            "EMP_ID y emp_id no identifican la empresa registrada y asignada a la sucursal del administrador.");
        pasa("EMP_ID y emp_id identifican una empresa activa registrada, coherente con la sucursal del administrador");
        Exige(Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM persona
            WHERE COALESCE(dni,'')<>'' OR COALESCE(ruc,'')<>'' OR COALESCE(direccion,'')<>''
                OR COALESCE(telefono,'')<>'' OR COALESCE(movil,'')<>'' OR COALESCE(email,'')<>''
                OR COALESCE(email_alternativo,'')<>'' OR COALESCE(sitio_web,'')<>'' OR id_distrito IS NOT NULL
            """)) == 0 && Convert.ToInt64(Valor(ruta, """
            SELECT COUNT(*) FROM sucursal
            WHERE COALESCE(direccion_sucursal,'')<>'' OR COALESCE(telefono_sucursal,'')<>''
                OR COALESCE(telefono_alternativo,'')<>'' OR COALESCE(codigo_sunat,'')<>'' OR id_distrito IS NOT NULL
            """)) == 0,
            "La hoja nueva contiene información de identificación o contacto ajena a su configuración neutra.");
        Integridad(ruta);
        pasa("Hoja nueva incluye Administrador, perfil nativo y sucursal neutra con relaciones válidas para iniciar sesión en Delphin");
    }

    private static Dictionary<string, string> CapturarAcceso(string ruta) =>
        new[] { "usuario", "usuario_map", "perfil", "perfil_map", "sucursal", "persona", "tipo_persona", "secuencia", "parametro" }
            .ToDictionary(tabla => tabla, tabla => Instantanea(ruta, "SELECT * FROM " + Identificador(tabla)));

    private static void ConservarAcceso(string ruta, Dictionary<string, string> antes)
    {
        foreach (var tabla in antes)
            Exige(Instantanea(ruta, "SELECT * FROM " + Identificador(tabla.Key)) == tabla.Value,
                "Guardar una hoja existente reinicializó sus cuentas, permisos o configuración organizativa: " + tabla.Key + ".");
    }

    private static void ComprobarAccesoExistente(string carpeta, Action<string> pasa)
    {
        // Sólo se generan hojas sintéticas para cubrir acceso personalizado o ausente,
        // tanto con metadatos MYG como al abrir una hoja reconocida como nativa.
        foreach (bool nativa in new[] { false, true })
        foreach (bool sinAcceso in new[] { false, true })
        {
            string ruta = Path.Combine(carpeta, "Acceso existente " + (nativa ? "nativo " : "MYG ") +
                (sinAcceso ? "ausente" : "personalizado") + ".sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            UnidadesDelphinCheck.RetirarUnidadSintetica(ruta);
            using (var c = new SqliteConnection(new SqliteConnectionStringBuilder
                { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false, ForeignKeys = true }.ToString()))
            {
                c.Open(); using var cmd = c.CreateCommand();
                cmd.CommandText = sinAcceso ? """
                    DELETE FROM parametro WHERE id_parametro IN ('EMP_ID','emp_id');
                    DELETE FROM usuario_map;
                    DELETE FROM usuario;
                    DELETE FROM perfil_map;
                    DELETE FROM perfil;
                    DELETE FROM sucursal;
                    DELETE FROM persona;
                    DELETE FROM tipo_persona;
                    """ : """
                    UPDATE usuario SET login_usuario='Operador sintético',clave_usuario='clave sintética local'
                        WHERE login_usuario='Administrador';
                    INSERT INTO usuario(id_usuario,login_usuario,clave_usuario,estado_usuario,es_principal,tipo_encripta,id_perfil)
                        SELECT lower(hex(randomblob(6))),'Invitado sintético','otra clave sintética','N','N','NON',id_perfil
                        FROM usuario WHERE login_usuario='Operador sintético';
                    UPDATE perfil SET requiere_sucursal='N',cambiar_sucursal='N';
                    UPDATE perfil_map SET permitido='N';
                    INSERT INTO perfil_map(id_acceso,nombre_acceso,id_perfil,permitido)
                        SELECT 'acceso_sintetico_desconocido','Permiso sintético desconocido',id_perfil,'X' FROM perfil;
                    UPDATE sucursal SET nombre_sucursal='Sucursal sintética';
                    UPDATE persona SET nombre_persona='Empresa sintética';
                    INSERT INTO persona(id_persona,clase_persona,nombre_persona,id_tipopersona,id_institucion,estado_persona)
                        SELECT 2,clase_persona,'Otra empresa sintética',id_tipopersona,2,estado_persona FROM persona WHERE id_persona=1;
                    UPDATE sucursal SET id_persona=2;
                    UPDATE parametro SET valor_parametro=2,valor_texto='Configuración sintética'
                        WHERE id_parametro IN ('EMP_ID','emp_id');
                    """;
                cmd.ExecuteNonQuery();
                if (nativa)
                {
                    // Dejar sólo las tablas nativas: quitar únicamente myg_info
                    // produciría una hoja híbrida inválida para esta regresión.
                    // Se eliminan primero las tablas hijas, con FK habilitadas.
                    cmd.CommandText = """
                        DROP TABLE catalogo_partida_recurso;
                        DROP TABLE catalogo_partida_nodo;
                        DROP TABLE catalogo_partida_insumo;
                        DROP TABLE catalogo_partida;
                        DROP TABLE catalogo_insumo;
                        DROP TABLE recurso_presupuesto;
                        DROP TABLE partida_presupuesto;
                        DROP TABLE insumo_presupuesto;
                        DROP TABLE myg_presupuesto;
                        DROP TABLE myg_proyecto;
                        DROP TABLE catalogo_unidad;
                        DROP TABLE myg_delphin_fila;
                        DROP TABLE IF EXISTS myg_indice_unificado;
                        DROP TABLE myg_info;
                        """;
                    cmd.ExecuteNonQuery();
                }
            }
            if (nativa)
                Exige(Convert.ToInt64(Valor(ruta, """
                    SELECT COUNT(*) FROM sqlite_master WHERE type='table'
                        AND (name LIKE 'myg_%' OR name LIKE 'catalogo_%'
                            OR name IN ('partida_presupuesto','insumo_presupuesto','recurso_presupuesto'))
                    """)) == 0, "La hoja sintética nativa aún contiene extensiones MYG antes de su apertura.");
            var antes = CapturarAcceso(ruta);
            var unidades = UnidadesDelphinCheck.Capturar(ruta);
            string huellaAntes = Huella(ruta);
            Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 0 && MYGCatalogoUnidades.Listar(ruta).Count == 61 &&
                Huella(ruta) == huellaAntes, "Leer una hoja existente alteró sus cuentas o su configuración.");
            var documento = MYGProyectoStorage.Nuevo("OBRA SINTÉTICA DE ACCESO");
            MYGBaseDatos.GuardarProyecto(ruta, documento);
            var unidad = MYGCatalogoUnidades.Guardar(ruta,
                new MYGUnidadCatalogo { Simbolo = "sint", Descripcion = "Unidad sintética" });
            documento.Nombre += " RENOMBRADA";
            MYGBaseDatos.GuardarProyecto(ruta, documento);
            MYGCatalogoUnidades.Eliminar(ruta, unidad.Id);
            ConservarAcceso(ruta, antes);
            UnidadesDelphinCheck.Conservar(ruta, unidades);
            Exige(Convert.ToInt64(Valor(ruta, "SELECT COUNT(*) FROM usuario WHERE login_usuario='Administrador'")) == 0,
                "Guardar una hoja existente recreó el administrador predeterminado sin autorización.");
            if (!sinAcceso)
                Exige(Convert.ToInt64(Valor(ruta, """
                    SELECT COUNT(*) FROM proyecto p JOIN usuario u ON u.id_usuario=p.id_usuario
                    WHERE u.login_usuario='Operador sintético'
                    """)) == 1, "Guardar una obra en una hoja existente perdió su propietario principal personalizado.");
            Integridad(ruta);
        }
        pasa("Abrir y guardar hojas existentes conservan cuentas personalizadas, claves, permisos desconocidos y ausencia de usuarios");
    }

    private static void ComprobarPrecioImportado(Action<string> pasa)
    {
        var p = MYGProyectoStorage.Nuevo("REDONDEO IMPORTADO").Presupuestos[0];
        var i = Nodo("PRECIO NATIVO CONSERVADO", "m2"); i.Costos.Cantidad = 3;
        var insumo = new MYGInsumo { Codigo = "RED-01", Descripcion = "Recurso para redondeo", Unidad = "kg", Precio = 1.23m };
        p.Costos.Insumos.Add(insumo); p.Items.Add(i);
        i.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Cantidad = 0.5m });
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, i, 0.63m, 1.88m);
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i) && MYGMotorPresupuestos.Analizar(p, i).PrecioUnitario == 0.63m &&
            MYGMotorPresupuestos.TotalPartida(p, i) == 1.88m, "Abrir el ACU recalculó el precio o parcial importado de Delphin.");
        i.Descripcion = "DESCRIPCIÓN CORREGIDA"; i.Costos.EspecificacionTexto = "Texto de prueba";
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i), "Una edición de texto invalidó el precio importado sin editar el análisis.");
        i.Costos.Cantidad = 4;
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i) && MYGMotorPresupuestos.TotalPartida(p, i) == 2.52m,
            "Cambiar el metrado debe usar el precio importado y recalcular únicamente el parcial.");
        insumo.Precio = 2;
        Exige(!MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i) && MYGMotorPresupuestos.Analizar(p, i).PrecioUnitario == 1 &&
            MYGMotorPresupuestos.TotalPartida(p, i) == 4, "Editar el precio de un recurso no recalculó el análisis importado.");
        pasa("Precio y parcial importados mantienen redondeos nativos; editar metrado recalcula parcial y editar recurso recalcula ACU");
    }

    private static void ComprobarRevisionExistente(string carpeta, Action<string> pasa)
    {
        // Son hojas sintéticas, no copias de bases del usuario. La apertura para
        // lectura y la escritura posterior deben conservar cualquier historial previo.
        foreach (long? revision in new long?[] { null, 0, 20250529, 20260101 })
        {
            string ruta = Path.Combine(carpeta, "Revision existente " + (revision?.ToString() ?? "ausente") + ".sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            using (var c = new SqliteConnection(new SqliteConnectionStringBuilder
                { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false }.ToString()))
            {
                c.Open(); using var cmd = c.CreateCommand();
                cmd.CommandText = revision.HasValue
                    ? "UPDATE parametro SET valor_parametro=$p0,valor_texto='historial existente' WHERE id_parametro='last_updated'"
                    : "DELETE FROM parametro WHERE id_parametro='last_updated'";
                if (revision.HasValue) cmd.Parameters.AddWithValue("$p0", revision.Value);
                cmd.ExecuteNonQuery();
            }
            string parametroAntes = Instantanea(ruta, "SELECT * FROM parametro ORDER BY id_parametro");
            string huellaAntes = Huella(ruta);
            Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 0 && Huella(ruta) == huellaAntes,
                "Leer una hoja existente alteró su historial Delphin.");
            MYGBaseDatos.GuardarProyecto(ruta, MYGProyectoStorage.Nuevo("OBRA SINTÉTICA"));
            Exige(Instantanea(ruta, "SELECT * FROM parametro ORDER BY id_parametro") == parametroAntes,
                "Guardar una hoja existente cambió su historial Delphin.");
            Integridad(ruta);
        }
        pasa("Lectura y guardado de hojas existentes conservan revisiones ausentes, cero, actuales y posteriores");
    }

    // Opt-in: únicamente usa el archivo externo señalado por la variable y
    // escribe una copia en la carpeta temporal de las pruebas. No incorpora datos al repositorio.
    private static void ComprobarMuestra(string ruta, string carpeta, Action<string> pasa)
    {
        Exige(File.Exists(ruta), "No existe el archivo indicado por MYG_QA_DELPHIN_SQLITE.");
        string original = Huella(ruta);
        string informe = Path.Combine(AppContext.BaseDirectory, "resultado_qa_delphin.json");
        if (File.Exists(informe)) File.Delete(informe);
        // Las referencias pendientes preexistentes no se reparan silenciosamente.
        string relacionesOriginales = Instantanea(ruta, "PRAGMA foreign_key_check");
        var mediciones = new List<MedicionSQLite> { MedirMuestra(ruta, "Original") };
        try
        {
            // Referencia independiente: filas e identidades de las tablas del
            // archivo aportado, sin fijar cantidades de otra muestra histórica.
            var idsProyectos = Textos(ruta, "SELECT id_proyecto FROM proyecto");
            var idsPresupuestos = Textos(ruta, "SELECT id_presupuesto FROM presupuesto");
            Exige(idsProyectos.Count > 0 && idsPresupuestos.Count > 0,
                "La muestra necesita proyectos y presupuestos para comprobar su edición.");
            var proyectos = MYGBaseDatos.ListarProyectos(ruta);
            var nativos = LectorDelphin.LeerProyectosSQLite(ruta);
            Exige(MismosIds(proyectos.Select(x => x.Id), idsProyectos) &&
                MismosIds(nativos.Select(x => x.Id), idsProyectos) &&
                proyectos.Sum(x => x.CantidadPresupuestos) == idsPresupuestos.Count &&
                MismosIds(nativos.SelectMany(x => LectorDelphin.LeerPresupuestosSQLite(ruta, x.Id)).Select(x => x.Id), idsPresupuestos),
                "Los lectores no reconocieron todos los proyectos y presupuestos nativos de la muestra.");
            var documentos = proyectos.Select(x => MYGBaseDatos.LeerProyecto(ruta, x.Id)).ToList();
            Exige(MismosIds(documentos.SelectMany(x => x.Presupuestos).Select(x => x.Id), idsPresupuestos),
                "La muestra no importó todos los identificadores de sus presupuestos.");
            foreach (var d in documentos)
                Exige(MismosIds(d.Presupuestos.Select(x => x.Id),
                    Textos(ruta, "SELECT id_presupuesto FROM presupuesto WHERE id_proyecto=$p0", d.Id)),
                    "La importación cambió la relación nativa entre proyecto y presupuesto.");
            if (Cuenta(ruta, "composicion_costounitario") > 0)
                Exige(documentos.SelectMany(x => x.Presupuestos).SelectMany(x => x.Items).Any(x => x.Costos.Analisis.Count > 0),
                    "La muestra contiene recursos nativos, pero la importación no recuperó ningún ACU.");
            foreach (var p in documentos.SelectMany(x => x.Presupuestos))
                foreach (var i in p.Items.Where(x => !MYGProyectoStorage.EsTitulo(x)))
                    Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(p, i), "Una partida importada perdió la firma de su ACU nativo.");
            Exige((Cuenta(ruta, "unidad") == 0 || MYGCatalogoUnidades.Listar(ruta).Count > 0) &&
                (Cuenta(ruta, "producto") == 0 || MYGCatalogos.Listar(ruta, false).Count > 0) &&
                (Cuenta(ruta, "analisis_costo") == 0 || MYGCatalogos.Listar(ruta, true).Count > 0),
                "La muestra no expuso sus catálogos nativos de unidades, insumos y partidas.");
            Exige(Huella(ruta) == original, "Leer proyectos y catálogos de la muestra modificó el original.");
            pasa("Muestra Delphin se abre con sus " + idsProyectos.Count + " proyectos y " + idsPresupuestos.Count +
                " presupuestos, conserva sus identidades y permite consultar catálogos sin modificar el original");

            var documento = documentos.OrderByDescending(x => x.Presupuestos.Count).First();
            string firmaDocumento = FirmaDocumento(documento);
            string copia = Path.Combine(carpeta, "Copia temporal de muestra Delphin.sqlite");
            File.Copy(ruta, copia, false);
            // Descubrir tablas, índices y triggers originales antes de añadir
            // extensiones MYG. Sólo se conservan huellas, nunca datos del usuario.
            var tablasNativas = Tablas(copia);
            var antes = tablasNativas.ToDictionary(x => x,
                x => Instantanea(copia, "SELECT * FROM " + Identificador(x)));
            var objetosOriginales = Textos(copia, "SELECT name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'");
            string seleccionObjetos = string.Join(",", objetosOriginales.Select(x => "'" + x.Replace("'", "''") + "'"));
            string consultaEsquema = "SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name IN (" + seleccionObjetos + ")";
            string esquemaAntes = Instantanea(copia, consultaEsquema);
            MYGProyectoStorage.Guardar(copia, documento);
            mediciones.Add(MedirMuestra(copia, "Guardado 1 sin cambios"));
            Exige(MYGBaseDatos.ListarProyectos(copia).Count == idsProyectos.Count &&
                Cuenta(copia, "presupuesto") == idsPresupuestos.Count,
                "Guardar la copia perdió proyectos o presupuestos nativos.");
            ConservarTablasMuestra(copia, tablasNativas, antes);
            Exige(Instantanea(copia, consultaEsquema) == esquemaAntes,
                "Guardar sin cambios modificó tablas, índices o triggers nativos.");
            var reabierto = MYGBaseDatos.LeerProyecto(copia, documento.Id);
            Exige(FirmaDocumento(reabierto) == firmaDocumento &&
                LectorDelphin.LeerProyectosSQLite(copia).Count == idsProyectos.Count,
                "Reabrir la copia perdió datos del documento o la lectura nativa Delphin.");
            Integridad(copia, relacionesOriginales);
            pasa("Guardar copia real sin cambios conserva esquema y valores de las " + tablasNativas.Count + " tablas nativas Delphin");

            long tolerancia = Math.Max(mediciones[1].TamanoPagina * 32, mediciones[1].BytesArchivo / 20);
            for (int guardado = 2; guardado <= 4; guardado++)
            {
                MYGProyectoStorage.Guardar(copia, reabierto);
                var medicion = MedirMuestra(copia, "Guardado " + guardado + " sin cambios");
                mediciones.Add(medicion);
                Exige(medicion.BytesArchivo <= mediciones[1].BytesArchivo + tolerancia,
                    "Los guardados sucesivos sin cambios acumulan crecimiento superior al 5 % o 32 páginas de tolerancia.");
                reabierto = MYGBaseDatos.LeerProyecto(copia, documento.Id);
                Exige(FirmaDocumento(reabierto) == firmaDocumento,
                    "Un guardado sucesivo alteró el contenido del documento.");
                ConservarTablasMuestra(copia, tablasNativas, antes);
                Exige(Instantanea(copia, consultaEsquema) == esquemaAntes,
                    "Un guardado sucesivo modificó el esquema nativo.");
                Integridad(copia, relacionesOriginales);
            }
            pasa("Cuatro guardados consecutivos de la muestra conservan datos nativos, integridad y contenido sin crecimiento acumulativo injustificado");

            string proyectosAntes = Instantanea(copia, "SELECT * FROM proyecto WHERE id_proyecto<>$p0", documento.Id);
            string columnasProyecto = ColumnasExcepto(copia, "proyecto", "nombre_proyecto");
            string metadatosAntes = Instantanea(copia, "SELECT " + columnasProyecto + " FROM proyecto");
            documento = reabierto;
            documento.Nombre += " (prueba temporal)";
            MYGProyectoStorage.Guardar(copia, documento);
            mediciones.Add(MedirMuestra(copia, "Renombrado y guardado"));
            ConservarTablasMuestra(copia, tablasNativas.Where(x => !string.Equals(x, "proyecto", StringComparison.OrdinalIgnoreCase)), antes);
            Exige(Instantanea(copia, "SELECT * FROM proyecto WHERE id_proyecto<>$p0", documento.Id) == proyectosAntes &&
                Instantanea(copia, "SELECT " + columnasProyecto + " FROM proyecto") == metadatosAntes &&
                (string)Valor(copia, "SELECT nombre_proyecto FROM proyecto WHERE id_proyecto=$p0", documento.Id) == documento.Nombre,
                "Cambiar el nombre de la obra alteró otros metadatos del proyecto o las otras obras.");
            Exige(FirmaDocumento(MYGBaseDatos.LeerProyecto(copia, documento.Id)) == FirmaDocumento(documento),
                "La modificación no se conserva exactamente al reabrir la obra.");
            Integridad(copia, relacionesOriginales);
            pasa("Renombrar una obra real conserva precios, parciales, recursos, especificaciones y todos los datos de las otras obras");
            File.WriteAllText(informe, JsonSerializer.Serialize(new
            {
                EjecucionUtc = DateTime.UtcNow,
                Sha256Original = original,
                Proyectos = idsProyectos.Count,
                Presupuestos = idsPresupuestos.Count,
                TablasNativas = tablasNativas.Count,
                Condiciones = "Copia temporal; conexiones cerradas antes de medir; cuatro guardados sin cambios y un renombrado; sin compactación manual.",
                Mediciones = mediciones,
                Resultado = "Correcto: original intacto; esquema, datos y anomalías FK originales conservados; edición y reapertura verificadas."
            }, new JsonSerializerOptions { WriteIndented = true }));
            foreach (var medicion in mediciones)
                Console.WriteLine("MEDICIÓN DELPHIN: " + medicion.Etapa + "; archivo=" + medicion.BytesArchivo +
                    " bytes; páginas libres=" + medicion.PaginasLibres + "; espacio libre=" + medicion.BytesLibres + " bytes.");
        }
        finally
        {
            Exige(Huella(ruta) == original, "La comprobación de Delphin alteró el archivo original del usuario.");
        }
    }

    private static void ConservarTablasMuestra(string ruta, IEnumerable<string> tablas, Dictionary<string, string> antes)
    {
        foreach (string tabla in tablas)
            Exige(Instantanea(ruta, "SELECT * FROM " + Identificador(tabla)) == antes[tabla],
                "El guardado modificó datos de una tabla nativa: " + tabla + ".");
    }

    private static bool MismosIds(IEnumerable<string> actuales, IEnumerable<string> esperados) =>
        actuales.OrderBy(x => x, StringComparer.Ordinal).SequenceEqual(esperados.OrderBy(x => x, StringComparer.Ordinal));

    private static List<string> Textos(string ruta, string consulta, params object[] valores)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand(); cmd.CommandText = consulta;
        for (int n = 0; n < valores.Length; n++) cmd.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        using var r = cmd.ExecuteReader(); var textos = new List<string>();
        while (r.Read()) textos.Add(r.GetString(0));
        return textos;
    }

    private static string FirmaDocumento(MYGProyectoDocumento documento) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(MYGProyectoStorage.Firma(documento))));

    private sealed class MedicionSQLite
    {
        public string Etapa { get; set; }
        public long BytesArchivo { get; set; }
        public long TamanoPagina { get; set; }
        public long Paginas { get; set; }
        public long PaginasLibres { get; set; }
        public long BytesLibres => TamanoPagina * PaginasLibres;
    }

    private static MedicionSQLite MedirMuestra(string ruta, string etapa) => new()
    {
        Etapa = etapa,
        BytesArchivo = new FileInfo(ruta).Length,
        TamanoPagina = Convert.ToInt64(Valor(ruta, "PRAGMA page_size"), CultureInfo.InvariantCulture),
        Paginas = Convert.ToInt64(Valor(ruta, "PRAGMA page_count"), CultureInfo.InvariantCulture),
        PaginasLibres = Convert.ToInt64(Valor(ruta, "PRAGMA freelist_count"), CultureInfo.InvariantCulture)
    };

    private static string Identificador(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";

    private static List<string> Tablas(string ruta)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name";
        using var r = cmd.ExecuteReader(); var tablas = new List<string>();
        while (r.Read()) tablas.Add(r.GetString(0));
        return tablas;
    }

    private static string ColumnasExcepto(string ruta, string tabla, string excluida)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand();
        cmd.CommandText = "PRAGMA table_info(" + Identificador(tabla) + ")";
        using var r = cmd.ExecuteReader(); var columnas = new List<string>();
        while (r.Read())
            if (!string.Equals(r.GetString(1), excluida, StringComparison.OrdinalIgnoreCase)) columnas.Add(Identificador(r.GetString(1)));
        return string.Join(",", columnas);
    }

    private static string Instantanea(string ruta, string consulta, params object[] valores)
    {
        using var c = Conexion(ruta); using var cmd = c.CreateCommand(); cmd.CommandText = consulta;
        for (int n = 0; n < valores.Length; n++) cmd.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        using var r = cmd.ExecuteReader(); var filas = new List<string>();
        while (r.Read())
        {
            var fila = new object[r.FieldCount];
            for (int n = 0; n < fila.Length; n++) fila[n] = r.IsDBNull(n) ? null : r.GetValue(n);
            filas.Add(JsonSerializer.Serialize(fila));
        }
        filas.Sort(StringComparer.Ordinal);
        // Sólo retorna una huella, nunca los datos externos de la muestra.
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("\n", filas))));
    }
}
