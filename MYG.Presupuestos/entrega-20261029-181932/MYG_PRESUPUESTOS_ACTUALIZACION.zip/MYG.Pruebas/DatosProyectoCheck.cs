using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DatosProyectoCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }

    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (InvalidOperationException) { return; }
        catch (ArgumentException) { return; }
        throw new Exception(detalle);
    }

    private static string Huella(string ruta)
    {
        using var f = File.OpenRead(ruta);
        return Convert.ToHexString(SHA256.HashData(f));
    }

    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly,
            Pooling = false, ForeignKeys = true }.ToString());
        c.Open(); return c;
    }

    private static object Sql(string ruta, string consulta, params object[] valores)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = consulta;
        for (int n = 0; n < valores.Length; n++) q.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        return q.ExecuteScalar();
    }

    private static string Texto(string ruta, string consulta, params object[] valores) =>
        Convert.ToString(Sql(ruta, consulta, valores), CultureInfo.InvariantCulture);

    private static decimal Numero(string ruta, string consulta, params object[] valores) =>
        Convert.ToDecimal(Sql(ruta, consulta, valores), CultureInfo.InvariantCulture);

    private static string Instantanea(string ruta, string consulta, params object[] valores)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand(); q.CommandText = consulta;
        for (int n = 0; n < valores.Length; n++) q.Parameters.AddWithValue("$p" + n, valores[n] ?? DBNull.Value);
        using var r = q.ExecuteReader(); var filas = new List<string>();
        while (r.Read())
        {
            var fila = new object[r.FieldCount];
            for (int n = 0; n < fila.Length; n++) fila[n] = r.IsDBNull(n) ? null : r.GetValue(n);
            filas.Add(JsonSerializer.Serialize(fila));
        }
        filas.Sort(StringComparer.Ordinal);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("\n", filas))));
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Fechas(pasa);
        string ruta = Path.Combine(carpeta, "Datos de dos proyectos.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        var catalogos = Catalogos(ruta, pasa);
        Proyectos(ruta, catalogos, pasa);
        CalendariosPorProyecto(carpeta, pasa);
        UnidadMesCostoAnterior(carpeta, pasa);
        DatosNativosIncompletos(carpeta, pasa);
        UbicacionNativaIncompleta(carpeta, pasa);
        FechasNativasIncoherentes(carpeta, pasa);
        string muestra = Environment.GetEnvironmentVariable("MYG_QA_DELPHIN_SQLITE");
        if (!string.IsNullOrWhiteSpace(muestra)) Muestra(Path.GetFullPath(muestra), pasa);
    }

    private static void CalendariosPorProyecto(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Calendarios de proyectos nuevos.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        string mesesCostoAntes = Instantanea(ruta, "SELECT * FROM unidad WHERE abreviatura_unidad='mes'");
        var primera = MYGProyectoStorage.Nuevo("CALENDARIO PRIVADO QA A"); primera.Datos = MYGDatosProyecto.Crear();
        MYGProyectoStorage.Guardar(ruta, primera);
        string nativaA = Texto(ruta, "SELECT id_proyecto FROM proyecto WHERE nombre_proyecto=$p0", primera.Nombre);
        string calendarioA = Texto(ruta, "SELECT id_calendario FROM proyecto WHERE id_proyecto=$p0", nativaA);
        Exige(!string.IsNullOrWhiteSpace(calendarioA) &&
            Texto(ruta, "SELECT id_proyecto FROM calendario WHERE id_calendario=$p0", calendarioA) == nativaA &&
            MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Calendarios).Count == 0,
            "Crear otra obra ofrece el calendario privado del primer proyecto.");
        var segunda = MYGProyectoStorage.Nuevo("CALENDARIO PRIVADO QA B"); segunda.Datos = MYGDatosProyecto.Crear();
        MYGProyectoStorage.Guardar(ruta, segunda);
        string nativaB = Texto(ruta, "SELECT id_proyecto FROM proyecto WHERE nombre_proyecto=$p0", segunda.Nombre);
        string calendarioB = Texto(ruta, "SELECT id_calendario FROM proyecto WHERE id_proyecto=$p0", nativaB);
        Exige(calendarioA != calendarioB &&
            Texto(ruta, "SELECT id_proyecto FROM calendario WHERE id_calendario=$p0", calendarioB) == nativaB,
            "Dos proyectos nuevos compartieron un calendario privado o el segundo proyecto no se pudo guardar.");
        var compartido = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Calendarios, "CALENDARIO GLOBAL QA");
        string antesLeer = Huella(ruta);
        Exige(MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Calendarios).Single().Id == compartido.Id,
            "La lista sin proyecto debe ofrecer sólo calendarios globales.");
        foreach (var caso in new[] { (Id: primera.Id, Nativo: nativaA, Calendario: calendarioA),
            (Id: nativaA, Nativo: nativaA, Calendario: calendarioA),
            (Id: segunda.Id, Nativo: nativaB, Calendario: calendarioB),
            (Id: nativaB, Nativo: nativaB, Calendario: calendarioB) })
        {
            var opciones = MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Calendarios, caso.Id);
            Exige(opciones.Count == 2 && opciones.Any(x => x.Id == compartido.Id && string.IsNullOrWhiteSpace(x.PadreId)) &&
                opciones.Single(x => x.Id == caso.Calendario).PadreId == caso.Nativo,
                "La lista de calendarios no incluye sólo el calendario de la obra y los calendarios globales.");
        }
        Exige(Huella(ruta) == antesLeer, "Filtrar calendarios por proyecto modificó la base SQLite.");
        var invalida = MYGProyectoStorage.Copia(segunda);
        invalida.Datos.CalendarioId = int.Parse(calendarioA, CultureInfo.InvariantCulture);
        Rechaza(() => MYGProyectoStorage.Guardar(ruta, invalida), "Se guardó el calendario privado de otra obra.");
        Exige(Huella(ruta) == antesLeer, "El rechazo de un calendario de otra obra dejó una escritura parcial.");
        pasa("Dos obras nuevas conservan calendarios privados distintos; listas globales y por ámbito MYG o nativo excluyen calendarios ajenos");

        Exige(Numero(ruta, """
            SELECT COUNT(*) FROM unidad u JOIN proyecto p ON p.id_unidadtiempo=u.id_unidad
            WHERE p.id_proyecto=$p0 AND u.id_unidad='UN0000000012' AND u.abreviatura_unidad='meses'
                AND u.es_unidadtiempo='S' AND u.en_cronograma='S' AND u.es_unidadcosto='N'
            """, nativaA) == 1 && Numero(ruta, "SELECT COUNT(*) FROM unidad WHERE abreviatura_unidad='mes'") == 2 &&
            Instantanea(ruta, "SELECT * FROM unidad WHERE abreviatura_unidad='mes'") == mesesCostoAntes,
            "La duración de una hoja nueva no usa la unidad temporal meses o modificó las variantes de costo mes.");
        pasa("La duración de hojas nuevas usa meses temporal y conserva las dos variantes de costo mes sin cambios");

        string nullable = Path.Combine(carpeta, "Calendarios con nombres nulos.sqlite");
        SQLiteDependencyBootstrapper.Initialize();
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = nullable, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false }.ToString()))
        {
            c.Open(); using var q = c.CreateCommand(); q.CommandText = """
                CREATE TABLE proyecto(id_proyecto TEXT PRIMARY KEY,nombre_proyecto TEXT);
                CREATE TABLE presupuesto(id_presupuesto TEXT PRIMARY KEY,id_proyecto TEXT);
                CREATE TABLE costo_unitario(id_costounitario TEXT PRIMARY KEY);
                CREATE TABLE unidad(id_unidad TEXT PRIMARY KEY);
                CREATE TABLE calendario(id_calendario INTEGER PRIMARY KEY,nombre_calendario TEXT,id_proyecto TEXT);
                INSERT INTO calendario VALUES(1,NULL,NULL),(2,'   ',NULL),(3,'CALENDARIO LEGIBLE QA',NULL),
                    (4,'PRIVADO LEGIBLE QA','PR-QA-A'),(5,'AJENO LEGIBLE QA','PR-QA-B');
                """;
            q.ExecuteNonQuery();
        }
        string nulosAntes = Huella(nullable);
        Exige(MYGCatalogosProyecto.Listar(nullable, MYGCatalogoProyecto.Calendarios).Single().Id == "3" &&
            MYGCatalogosProyecto.Listar(nullable, MYGCatalogoProyecto.Calendarios, "PR-QA-A").Count == 2,
            "Un calendario nativo sin nombre ocasionó un error o se ofreció como opción seleccionable.");
        Exige(Huella(nullable) == nulosAntes, "Consultar calendarios con nombres nulos cambió el archivo nativo.");
        pasa("Listar calendarios nativos omite nombres nulos o vacíos y conserva el archivo en modo de lectura");
    }

    private static void UnidadMesCostoAnterior(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Unidad anterior mes de costo y duración.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        string nativo = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("unidad:mes")))[..12];
        string catalogo = "MYG-UNIDAD-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("MES")))[..16];
        using (var c = Conexion(ruta, true))
        using (var t = c.BeginTransaction())
        using (var q = c.CreateCommand())
        {
            q.Transaction = t;
            // Base sintética con una unidad anterior; no se copia una base del usuario.
            q.CommandText = "DELETE FROM unidad_map; DELETE FROM unidad_tipocosto; DELETE FROM unidad_tipocostonew; " +
                "DELETE FROM unidad; DELETE FROM catalogo_unidad; DELETE FROM myg_delphin_fila WHERE tabla='unidad'; " +
                "INSERT INTO catalogo_unidad(id,simbolo,descripcion) VALUES($catalogo,'mes','Mes'); " +
                "INSERT INTO unidad(id_unidad,descripcion_unidad,abreviatura_unidad,informacion_unidad," +
                "magnitud_unidad,id_unidadbase,es_unidadcosto,es_unidadtiempo,es_unidadgasto,en_cronograma," +
                "es_dependiente,tipo_unidad,divisible) " +
                "VALUES($nativo,'mes','mes','Mes',1,$nativo,'S','N','S','N','N','N','S'); " +
                "INSERT INTO myg_delphin_fila VALUES('catalogo_unidad','unidad',$nativo);";
            q.Parameters.AddWithValue("$nativo", nativo); q.Parameters.AddWithValue("$catalogo", catalogo);
            q.ExecuteNonQuery();
            foreach (var grupo in Enum.GetValues<MYGGrupoRecurso>())
            {
                q.CommandText = "INSERT INTO unidad_tipocosto(id_unidad,id_tipocosto) VALUES($nativo,$grupo)";
                q.Parameters.AddWithValue("$grupo", "TC" + ((int)grupo + 1).ToString("D10", CultureInfo.InvariantCulture));
                q.ExecuteNonQuery(); q.Parameters.RemoveAt("$grupo");
            }
            t.Commit();
        }
        const string metadatosCosto = "SELECT id_unidad,descripcion_unidad,abreviatura_unidad,informacion_unidad," +
            "magnitud_unidad,id_unidadbase,es_unidadcosto,es_unidadgasto,es_dependiente,tipo_unidad,divisible FROM unidad";
        string costoAntes = Instantanea(ruta, metadatosCosto);
        Exige(Texto(ruta, "SELECT es_unidadtiempo FROM unidad") == "N" && Texto(ruta, "SELECT en_cronograma FROM unidad") == "N",
            "La unidad sintética anterior ya estaba habilitada para tiempo o cronograma.");
        var documento = MYGProyectoStorage.Nuevo("DURACIÓN CON MES ANTERIOR"); documento.Datos = MYGDatosProyecto.Crear();
        Exige(documento.Datos.UnidadDuracion == "MESES", "La prueba anterior no usa la duración predeterminada MESES.");
        MYGProyectoStorage.Guardar(ruta, documento);
        Exige(Numero(ruta, "SELECT COUNT(*) FROM unidad") == 1 && Numero(ruta, "SELECT COUNT(*) FROM catalogo_unidad") == 1 &&
            Texto(ruta, "SELECT id_unidadtiempo FROM proyecto WHERE nombre_proyecto=$p0", documento.Nombre) == nativo &&
            Texto(ruta, "SELECT es_unidadtiempo FROM unidad WHERE id_unidad=$p0", nativo) == "S" &&
            Texto(ruta, "SELECT en_cronograma FROM unidad WHERE id_unidad=$p0", nativo) == "S" &&
            Instantanea(ruta, metadatosCosto) == costoAntes,
            "Usar mes anterior para duración no activó tiempo/cronograma, cambió su uso como costo o agregó unidades iniciales.");
        pasa("Una base anterior reutiliza su mes de costo para duración y cronograma conservando identidad, costo y metadatos sin recibir unidades nuevas");
    }

    private static void DatosNativosIncompletos(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Datos heredados sin calendario.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        using (var c = Conexion(ruta, true))
        using (var q = c.CreateCommand())
        {
            q.CommandText = """
                INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,duracion)
                    VALUES('PR-HEREDADO','','IN0000000001','No','PROYECTO HEREDADO QA',0);
                INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto)
                    VALUES('PP-HEREDADO','PR-HEREDADO','PRESUPUESTO HEREDADO QA');
                INSERT INTO calendario(id_calendario,nombre_calendario) VALUES(80,'Predeterminado');
                """;
            q.ExecuteNonQuery();
        }
        var propietario = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Propietarios, "PROPIETARIO HEREDADO QA");
        var documento = MYGBaseDatos.LeerProyecto(ruta, "PR-HEREDADO");
        Exige(documento.Datos.CalendarioId == null && documento.Datos.Duracion == 1 && documento.Datos.UnidadDuracion == "MESES",
            "La lectura de metadatos nativos incompletos no conserva un calendario ausente y sus valores de presentación.");
        string datosAntes = Instantanea(ruta, """
            SELECT id_portafolio,id_infraestructura,id_ubicacion,id_departamento,id_provincia,id_distrito,id_localidad,
                fecha_proyecto,fecha_inicio,fecha_fin,duracion,duracion_new,id_unidadtiempo,id_calendario,
                modalidad_ejecucion,acu_mode,fin_periodo FROM proyecto WHERE id_proyecto='PR-HEREDADO'
            """);
        string unidadesAntes = Instantanea(ruta, "SELECT * FROM unidad");
        string calendariosAntes = Instantanea(ruta, "SELECT * FROM calendario");
        documento.Nombre = "PROYECTO HEREDADO QA RENOMBRADO";
        documento.Datos.PropietarioId = propietario.Id; documento.Datos.Propietario = propietario.Nombre;
        MYGProyectoStorage.Guardar(ruta, documento);
        Exige(Instantanea(ruta, """
            SELECT id_portafolio,id_infraestructura,id_ubicacion,id_departamento,id_provincia,id_distrito,id_localidad,
                fecha_proyecto,fecha_inicio,fecha_fin,duracion,duracion_new,id_unidadtiempo,id_calendario,
                modalidad_ejecucion,acu_mode,fin_periodo FROM proyecto WHERE id_proyecto='PR-HEREDADO'
            """) == datosAntes && Instantanea(ruta, "SELECT * FROM unidad") == unidadesAntes &&
            Instantanea(ruta, "SELECT * FROM calendario") == calendariosAntes &&
            Texto(ruta, "SELECT id_propietario FROM proyecto WHERE id_proyecto='PR-HEREDADO'") == propietario.Id &&
            Texto(ruta, "SELECT nombre_proyecto FROM proyecto WHERE id_proyecto='PR-HEREDADO'") == documento.Nombre,
            "Editar propietario o nombre sustituyó valores nativos ausentes por los valores de presentación del formulario.");
        pasa("Editar propietario y nombre de una obra heredada conserva calendario NULL, duración nativa y otros metadatos ausentes");
    }

    private static void UbicacionNativaIncompleta(string carpeta, Action<string> pasa)
    {
        foreach (string bandera in new[] { "Si", "S" })
        {
            string ruta = Path.Combine(carpeta, "Ubicación heredada " + bandera + ".sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            using (var c = Conexion(ruta, true))
            using (var q = c.CreateCommand())
            {
                q.CommandText = """
                    INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,duracion)
                        VALUES('PR-UBICACION','','IN0000000001',$bandera,'OBRA CON UBICACIÓN INCOMPLETA',0);
                    INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto)
                        VALUES('PP-UBICACION','PR-UBICACION','PRESUPUESTO HEREDADO');
                    """;
                q.Parameters.AddWithValue("$bandera", bandera); q.ExecuteNonQuery();
            }
            string consulta = """
                SELECT id_ubicacion,id_departamento,id_provincia,id_distrito,id_localidad,fecha_proyecto,
                    fecha_inicio,fecha_fin,duracion,duracion_new,id_unidadtiempo,id_calendario,
                    modalidad_ejecucion,acu_mode,fin_periodo FROM proyecto WHERE id_proyecto='PR-UBICACION'
                """;
            string nativosAntes = Instantanea(ruta, consulta);
            string bytesAntes = Huella(ruta);
            var documento = MYGBaseDatos.LeerProyecto(ruta, "PR-UBICACION");
            Exige(documento.Datos.UsarUbicacion && documento.Datos.DepartamentoId == null &&
                documento.Datos.ProvinciaId == null && documento.Datos.DistritoId == null &&
                documento.Datos.LocalidadId == null && !string.IsNullOrWhiteSpace(documento.Datos.FirmaImportada),
                "Leer la ubicación heredada " + bandera + " inventó referencias o desactivó su bandera nativa.");
            Exige(Huella(ruta) == bytesAntes, "Leer una ubicación heredada incompleta modificó la base original.");
            documento.Nombre += " RENOMBRADA";
            MYGProyectoStorage.Guardar(ruta, documento);
            var reabierto = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
            Exige(Instantanea(ruta, consulta) == nativosAntes && reabierto.Nombre == documento.Nombre &&
                reabierto.Datos.UsarUbicacion && reabierto.Datos.DepartamentoId == null,
                "Renombrar o reabrir una obra corrigió silenciosamente su ubicación o sus metadatos nativos.");
            string guardadoAntes = Huella(ruta);
            var editado = MYGProyectoStorage.Copia(reabierto);
            editado.Datos.HechoPor = "RESPONSABLE EDITADO";
            Rechaza(() => MYGProyectoStorage.Guardar(ruta, editado),
                "Editar datos generales de una obra heredada admitió una ubicación activa sin departamento.");
            Exige(Huella(ruta) == guardadoAntes,
                "La validación de datos heredados editados dejó escrituras parciales.");
            editado.Datos.UsarUbicacion = false;
            MYGProyectoStorage.Guardar(ruta, editado);
            Exige(!MYGBaseDatos.LeerProyecto(ruta, documento.Id).Datos.UsarUbicacion &&
                Texto(ruta, "SELECT id_ubicacion FROM proyecto WHERE id_proyecto='PR-UBICACION'") == "No",
                "Desactivar explícitamente la ubicación incompleta no permitió guardar los datos editados.");
        }
        pasa("Ubicación nativa Si/S sin departamento se lee y conserva al renombrar; editar datos exige corregirla explícitamente");

        var nuevo = MYGProyectoStorage.Nuevo("UBICACIÓN NUEVA INVÁLIDA");
        nuevo.Datos = MYGDatosProyecto.Crear(); nuevo.Datos.UsarUbicacion = true;
        Rechaza(() => MYGProyectoStorage.Validar(nuevo),
            "Un proyecto nuevo admitió una ubicación activa sin departamento.");
        string invalida = Path.Combine(carpeta, "Modalidad nativa inválida.sqlite");
        MYGBaseDatos.CrearBaseVacia(invalida);
        using (var c = Conexion(invalida, true))
        using (var q = c.CreateCommand())
        {
            q.CommandText = """
                INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,modalidad_ejecucion)
                    VALUES('PR-INVALIDO','','IN0000000001','Si','OBRA CON MODALIDAD INVÁLIDA','X');
                INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto)
                    VALUES('PP-INVALIDO','PR-INVALIDO','PRESUPUESTO HEREDADO');
                """;
            q.ExecuteNonQuery();
        }
        string invalidaAntes = Huella(invalida);
        Rechaza(() => MYGBaseDatos.LeerProyecto(invalida, "PR-INVALIDO"),
            "La firma heredada omitió la validación de una modalidad de ejecución inválida.");
        Exige(Huella(invalida) == invalidaAntes, "Rechazar otros metadatos nativos inválidos modificó la base original.");
        pasa("La compatibilidad geográfica heredada mantiene las validaciones de proyectos nuevos y de otros datos nativos");
    }

    private static void FechasNativasIncoherentes(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Fechas heredadas Delphin.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        using (var c = Conexion(ruta, true))
        using (var q = c.CreateCommand())
        {
            q.CommandText = """
                INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,
                    fecha_inicio,fecha_fin,duracion)
                    VALUES('PR-FECHAS','','IN0000000001','No','FECHAS HEREDADAS',
                        '08/06/2026','07/06/2026',0);
                INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto)
                    VALUES('PP-FECHAS','PR-FECHAS','PRESUPUESTO HEREDADO');
                """;
            q.ExecuteNonQuery();
        }
        string consulta = """
            SELECT fecha_inicio,fecha_fin,duracion,duracion_new,id_unidadtiempo,id_calendario
            FROM proyecto WHERE id_proyecto='PR-FECHAS'
            """;
        string nativosAntes = Instantanea(ruta, consulta);
        string bytesAntes = Huella(ruta);
        var avisos = new List<string>();
        var documento = MYGBaseDatos.LeerProyecto(ruta, "PR-FECHAS", avisos.Add);
        Exige(documento.Datos.FechaInicio == new DateTime(2026, 6, 8) &&
            documento.Datos.FechaFin == new DateTime(2026, 6, 7) && documento.Datos.Duracion == 1 &&
            documento.Cronograma == null && avisos.Any(x => x.Contains("fecha final anterior")) &&
            avisos.Any(x => x.Contains("duración original se conserva")) && Huella(ruta) == bytesAntes,
            "La lectura no explicó las fechas heredadas o el valor de presentación de duración, inventó un cronograma o alteró la base.");
        pasa("Fechas Delphin invertidas y duración cero se consultan con advertencias explícitas, sin corregir datos nativos ni crear programación ficticia");

        documento.Nombre = "FECHAS HEREDADAS RENOMBRADA";
        for (int intento = 0; intento < 2; intento++)
        {
            MYGProyectoStorage.Guardar(ruta, documento);
            documento = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
            Exige(documento.Nombre == "FECHAS HEREDADAS RENOMBRADA" &&
                documento.Datos.FechaInicio == new DateTime(2026, 6, 8) &&
                documento.Datos.FechaFin == new DateTime(2026, 6, 7) &&
                Instantanea(ruta, consulta) == nativosAntes,
                "Guardar o reabrir corrigió silenciosamente las fechas o la duración cero del proyecto Delphin.");
        }
        pasa("Renombrar y guardar repetidamente conserva las fechas invertidas, la duración nativa cero y las referencias originales de la ficha intacta");

        var opcionesHistoricas = new JsonSerializerOptions
        { WriteIndented = true, PropertyNameCaseInsensitive = true, MaxDepth = 128 };
        var datosSinFirma = MYGProyectoStorage.Copia(documento.Datos);
        datosSinFirma.FirmaImportada = null;
        string firmaHistorica = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(
            JsonSerializer.Serialize(datosSinFirma, opcionesHistoricas))));
        Exige(documento.Datos.FirmaImportada == firmaHistorica,
            "La firma de la ficha nativa cambió al compactar el almacenamiento y dejó de reconocer firmas históricas.");
        documento.Datos.FirmaImportada = firmaHistorica;
        using (var c = Conexion(ruta, true))
        using (var q = c.CreateCommand())
        {
            q.CommandText = "UPDATE myg_info SET version=3; UPDATE myg_proyecto SET json_documento=$json WHERE id=$id";
            q.Parameters.AddWithValue("$id", documento.Id);
            q.Parameters.AddWithValue("$json", JsonSerializer.Serialize(documento, opcionesHistoricas));
            q.ExecuteNonQuery();
        }
        string versionTresAntes = Huella(ruta);
        documento = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        Exige(documento.Datos.FirmaImportada == firmaHistorica &&
            documento.Datos.FechaFin == new DateTime(2026, 6, 7) && Huella(ruta) == versionTresAntes,
            "Una ficha v3 con hash histórico intacto rechazó o corrigió sus fechas Delphin al abrirse.");
        MYGProyectoStorage.Guardar(ruta, documento);
        documento = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
        Exige(documento.Datos.FirmaImportada == firmaHistorica && Instantanea(ruta, consulta) == nativosAntes,
            "Migrar una ficha v3 con firma histórica modificó sus fechas o duración nativas.");
        pasa("Hash histórico con JSON indentado reconoce fichas v3 intactas y permite migrarlas conservando fechas incoherentes y duración nativa cero");

        string guardadoAntes = Huella(ruta);
        var editado = MYGProyectoStorage.Copia(documento);
        editado.Datos.HechoPor = "RESPONSABLE EDITADO";
        Rechaza(() => MYGProyectoStorage.Guardar(ruta, editado),
            "Editar una ficha importada admitió fechas invertidas sin una corrección expresa.");
        Exige(Huella(ruta) == guardadoAntes, "Rechazar una ficha editada con fechas invertidas dejó escrituras parciales.");
        editado.Datos.Duracion = 2;
        editado.Datos.CalcularFin();
        MYGProyectoStorage.Guardar(ruta, editado);
        var corregido = MYGBaseDatos.LeerProyecto(ruta, editado.Id);
        Exige(corregido.Datos.FechaFin == editado.Datos.FechaFin && corregido.Datos.Duracion == 2 &&
            Numero(ruta, "SELECT duracion FROM proyecto WHERE id_proyecto='PR-FECHAS'") == 2 &&
            Texto(ruta, "SELECT fecha_fin FROM proyecto WHERE id_proyecto='PR-FECHAS'") ==
                editado.Datos.FechaFin.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
            "La corrección explícita de la ficha no se conservó en el documento y los campos nativos.");
        pasa("Editar la ficha exige fechas válidas, revierte los rechazos y guarda una corrección expresa en las columnas nativas Delphin");
    }

    private static void Fechas(Action<string> pasa)
    {
        var d = MYGDatosProyecto.Crear(); d.Validar();
        Exige(d.FechaInicio.HasValue && d.FechaFin.HasValue && d.FechaElaboracion.HasValue &&
            d.Duracion == 1m && d.UnidadDuracion == "MESES" && d.CalcularFin() == d.FechaFin &&
            d.PorRendimientoCuadrilla && !d.PorAsignacionRecursos,
            "Los datos nuevos no inician con un mes de duración y modo de rendimiento válido.");
        var casos = new[]
        {
            (Inicio: new DateTime(2024, 2, 1), Duracion: 1m, Unidad: "MESES", Fin: new DateTime(2024, 3, 1)),
            (Inicio: new DateTime(2023, 2, 1), Duracion: 1m, Unidad: "MES", Fin: new DateTime(2023, 3, 2)),
            (Inicio: new DateTime(2024, 1, 31), Duracion: 1m, Unidad: "MESES", Fin: new DateTime(2024, 2, 29)),
            (Inicio: new DateTime(2024, 2, 29), Duracion: 12m, Unidad: "MESES", Fin: new DateTime(2025, 2, 22)),
            (Inicio: new DateTime(2024, 1, 1), Duracion: 1.5m, Unidad: "MESES", Fin: new DateTime(2024, 2, 14)),
            (Inicio: new DateTime(2026, 9, 1), Duracion: 24m, Unidad: "MESES", Fin: new DateTime(2028, 8, 20)),
            (Inicio: new DateTime(2024, 2, 1), Duracion: 0.5m, Unidad: "MESES", Fin: new DateTime(2024, 2, 15)),
            (Inicio: new DateTime(2024, 2, 1), Duracion: 0.01m, Unidad: "MESES", Fin: new DateTime(2024, 2, 1)),
            (Inicio: new DateTime(2026, 12, 31), Duracion: 2m, Unidad: "DÍAS", Fin: new DateTime(2027, 1, 1)),
            (Inicio: new DateTime(2026, 1, 1), Duracion: 0.1m, Unidad: "DIA", Fin: new DateTime(2026, 1, 1)),
            (Inicio: new DateTime(2026, 1, 1), Duracion: 1.5m, Unidad: "DIAS", Fin: new DateTime(2026, 1, 2)),
            (Inicio: new DateTime(2026, 1, 1), Duracion: 0.5m, Unidad: "SEMANA", Fin: new DateTime(2026, 1, 4))
        };
        foreach (var caso in casos)
            Exige(MYGDatosProyecto.CalcularFin(caso.Inicio, caso.Duracion, caso.Unidad) == caso.Fin,
                "La fecha final inclusiva no respeta los meses de 30 días, las fracciones o las fechas reales del calendario.");
        pasa("Fecha final inclusiva usa meses de 30 días y conserva semanas, días y fechas reales en meses cortos y años bisiestos");

        foreach (var caso in new[]
        {
            (Duracion: 24m, Unidad: "MESES", Dias: 720),
            (Duracion: 12m, Unidad: "mes", Dias: 360),
            (Duracion: 1.5m, Unidad: "MESES", Dias: 45),
            (Duracion: 0.01m, Unidad: "MESES", Dias: 1),
            (Duracion: 1.25m, Unidad: "SEMANAS", Dias: 9),
            (Duracion: 1.5m, Unidad: "DÍAS", Dias: 2),
            (Duracion: 100000m, Unidad: "MESES", Dias: 3000000)
        })
            Exige(MYGDatosProyecto.ConvertirADiasCalendario(caso.Duracion, caso.Unidad) == caso.Dias,
                "La conversión del plazo debe usar mes de 30 días, semana de 7 y redondeo hacia arriba a días enteros.");
        foreach (int anio in new[] { 2023, 2024 })
        for (int mes = 1; mes <= 12; mes++)
        {
            var inicio = new DateTime(anio, mes, DateTime.DaysInMonth(anio, mes));
            var fin = MYGDatosProyecto.CalcularFin(inicio, 1m, "MESES");
            Exige((fin - inicio).Days + 1 == 30,
                "Un mes de plazo debe cuantificarse en 30 días incluso al comenzar en el último día de cada mes.");
        }
        Exige(MYGDatosProyecto.CalcularFin(DateTime.MaxValue, 1m, "MESES") == DateTime.MaxValue.Date &&
            MYGDatosProyecto.CalcularFin(new DateTime(9999, 1, 1), 12m, "MESES") == new DateTime(9999, 12, 26) &&
            MYGDatosProyecto.CalcularFin(DateTime.MinValue, 0.01m, "MESES") == DateTime.MinValue.Date,
            "La conversión debe respetar el rango de fechas sin desbordar ni requerir meses posteriores al año 9999.");
        pasa("Conversión del plazo: 24 meses son 720 días, fracciones redondean hacia arriba y el factor no depende del mes de inicio");

        foreach (decimal invalida in new[] { 0m, -1m, 100000.01m })
        {
            Rechaza(() => MYGDatosProyecto.CalcularFin(new DateTime(2026, 1, 1), invalida, "DÍAS"),
                "Se aceptó una duración no positiva o fuera de rango.");
            Rechaza(() => MYGDatosProyecto.ConvertirADiasCalendario(invalida, "MESES"),
                "La conversión directa aceptó una duración no positiva o fuera de rango.");
        }
        Rechaza(() => MYGDatosProyecto.CalcularFin(new DateTime(2026, 1, 1), 1, "AÑOS"),
            "Se aceptó una unidad de duración que el editor no soporta.");
        Rechaza(() => MYGDatosProyecto.ConvertirADiasCalendario(1, "AÑOS"),
            "La conversión directa aceptó una unidad de duración desconocida.");
        var invalido = MYGDatosProyecto.Crear(); invalido.PorRendimientoCuadrilla = false;
        Rechaza(invalido.Validar, "Se aceptó un proyecto sin modo de cálculo de ACU.");
        invalido.PorRendimientoCuadrilla = true; invalido.PorAsignacionRecursos = true;
        Rechaza(invalido.Validar, "Se aceptó activar simultáneamente los dos modos de cálculo del ACU.");
        invalido.PorAsignacionRecursos = false; invalido.FechaInicio = new DateTime(2026, 1, 10);
        invalido.FechaFin = new DateTime(2026, 1, 9);
        Rechaza(invalido.Validar, "Se aceptó una fecha final anterior al inicio.");
        invalido.FechaFin = new DateTime(2026, 1, 31); invalido.ModalidadEjecucion = "INVÁLIDA";
        Rechaza(invalido.Validar, "Se aceptó una modalidad de ejecución no admitida.");
        pasa("Datos del proyecto rechazan duración inválida, fechas invertidas y modos de ACU incompatibles");
    }

    private sealed class Selecciones
    {
        public MYGOpcionProyecto PropietarioA, PropietarioB, PortafolioA, PortafolioB, TipoA, TipoB;
        public MYGOpcionProyecto DepartamentoA, DepartamentoB, ProvinciaA, ProvinciaB, DistritoA, DistritoB, LocalidadA, LocalidadB;
        public MYGOpcionProyecto CalendarioA, CalendarioB;
    }

    private static Selecciones Catalogos(string ruta, Action<string> pasa)
    {
        string lecturaAntes = Huella(ruta);
        foreach (var tipo in Enum.GetValues<MYGCatalogoProyecto>()) MYGCatalogosProyecto.Listar(ruta, tipo);
        Exige(Huella(ruta) == lecturaAntes, "Consultar los catálogos generales modificó la hoja SQLite.");
        Exige(MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Departamentos).Count >= 25 &&
            MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Provincias).Count >= 100 &&
            MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Distritos).Count >= 1000,
            "La hoja nueva no incluye las opciones geográficas básicas de Perú.");
        var s = new Selecciones
        {
            PropietarioA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Propietarios, "PROPIETARIO QA A"),
            PropietarioB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Propietarios, "PROPIETARIO QA B"),
            PortafolioA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Portafolios, "PORTAFOLIO QA A"),
            PortafolioB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Portafolios, "PORTAFOLIO QA B"),
            TipoA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.TiposObra, "TIPO QA A"),
            TipoB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.TiposObra, "TIPO QA B"),
            DepartamentoA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Departamentos, "DEPARTAMENTO QA A"),
            DepartamentoB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Departamentos, "DEPARTAMENTO QA B")
        };
        s.ProvinciaA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Provincias, "PROVINCIA COMPARTIDA QA", s.DepartamentoA.Id);
        s.ProvinciaB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Provincias, "PROVINCIA COMPARTIDA QA", s.DepartamentoB.Id);
        s.DistritoA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Distritos, "DISTRITO QA", s.ProvinciaA.Id);
        s.DistritoB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Distritos, "DISTRITO QA", s.ProvinciaB.Id);
        s.LocalidadA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Localidades, "LOCALIDAD QA", s.DistritoA.Id);
        s.LocalidadB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Localidades, "LOCALIDAD QA", s.DistritoB.Id);
        Exige(s.ProvinciaA.Id != s.ProvinciaB.Id && s.DistritoA.Id != s.DistritoB.Id && s.LocalidadA.Id != s.LocalidadB.Id,
            "Los catálogos mezclaron ubicaciones homónimas de padres distintos.");
        Exige(MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Provincias, s.DepartamentoA.Id).Single().Id == s.ProvinciaA.Id &&
            MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Distritos, s.ProvinciaB.Id).Single().Id == s.DistritoB.Id &&
            MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Localidades, s.DistritoA.Id).Single().Id == s.LocalidadA.Id,
            "Los catálogos de ubicación no filtran por su departamento, provincia o distrito.");
        string duplicadoAntes = Huella(ruta);
        Exige(MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Propietarios, " propietario qa a ").Id == s.PropietarioA.Id &&
            MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Provincias, "provincia compartida qa", s.DepartamentoA.Id).Id == s.ProvinciaA.Id,
            "El mismo nombre con otras mayúsculas o espacios creó otra entrada de catálogo.");
        Exige(Huella(ruta) == duplicadoAntes, "Reutilizar una opción duplicada alteró la hoja.");
        pasa("Catálogos permiten añadir opciones y filtran ubicaciones en cascada sin duplicar nombres bajo el mismo padre");

        string invalidoAntes = Huella(ruta);
        Rechaza(() => MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Propietarios, " "),
            "Se aceptó un nombre de catálogo vacío.");
        Rechaza(() => MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Provincias, "SIN PADRE QA"),
            "Se creó una provincia sin departamento.");
        Rechaza(() => MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Distritos, "PADRE INEXISTENTE QA", "NO-EXISTE"),
            "Se creó un distrito cuyo padre no existe.");
        Rechaza(() => MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Localidades, "PADRE EQUIVOCADO QA", s.DepartamentoA.Id),
            "Se creó una localidad cuyo padre no es un distrito.");
        Exige(Huella(ruta) == invalidoAntes, "Rechazar una entrada de catálogo dejó datos parciales en la hoja.");
        pasa("Altas incompletas y padres inexistentes o de otro catálogo se rechazan sin modificar SQLite");

        using (var c = Conexion(ruta, true))
        using (var q = c.CreateCommand())
        {
            q.CommandText = "INSERT INTO calendario(id_calendario,nombre_calendario) VALUES(75,'CALENDARIO NATIVO QA')";
            q.ExecuteNonQuery();
        }
        s.CalendarioA = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Calendarios, "CALENDARIO QA A");
        s.CalendarioB = MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Calendarios, "CALENDARIO QA B");
        Exige(s.CalendarioA.Id == "76" && s.CalendarioB.Id == "77" &&
            MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Calendarios, "calendario qa a").Id == "76",
            "Crear calendarios no respetó los identificadores enteros existentes o duplicó un nombre.");
        Exige(Numero(ruta, "SELECT COUNT(*) FROM calendario WHERE id_calendario=75 AND nombre_calendario='CALENDARIO NATIVO QA'") == 1,
            "Crear calendarios sobrescribió el calendario nativo existente.");
        pasa("Calendarios nuevos usan IDs enteros consecutivos y conservan los calendarios nativos existentes");
        return s;
    }

    private static MYGDatosProyecto Datos(Selecciones s, bool segunda)
    {
        var d = MYGDatosProyecto.Crear();
        d.PropietarioId = (segunda ? s.PropietarioB : s.PropietarioA).Id;
        d.Propietario = (segunda ? s.PropietarioB : s.PropietarioA).Nombre;
        d.PortafolioId = (segunda ? s.PortafolioB : s.PortafolioA).Id;
        d.Portafolio = (segunda ? s.PortafolioB : s.PortafolioA).Nombre;
        d.TipoObraId = (segunda ? s.TipoB : s.TipoA).Id; d.TipoObra = (segunda ? s.TipoB : s.TipoA).Nombre;
        d.UsarUbicacion = true;
        d.DepartamentoId = (segunda ? s.DepartamentoB : s.DepartamentoA).Id;
        d.Departamento = (segunda ? s.DepartamentoB : s.DepartamentoA).Nombre;
        d.ProvinciaId = (segunda ? s.ProvinciaB : s.ProvinciaA).Id;
        d.Provincia = (segunda ? s.ProvinciaB : s.ProvinciaA).Nombre;
        d.DistritoId = (segunda ? s.DistritoB : s.DistritoA).Id; d.Distrito = (segunda ? s.DistritoB : s.DistritoA).Nombre;
        d.LocalidadId = (segunda ? s.LocalidadB : s.LocalidadA).Id; d.Localidad = (segunda ? s.LocalidadB : s.LocalidadA).Nombre;
        d.FechaElaboracion = new DateTime(2026, 10, 7);
        d.FechaInicio = new DateTime(2026, 10, segunda ? 11 : 10);
        d.Duracion = segunda ? 1.25m : 2m; d.UnidadDuracion = segunda ? "SEMANAS" : "MESES";
        d.FechaFin = d.CalcularFin();
        d.CalendarioId = int.Parse((segunda ? s.CalendarioB : s.CalendarioA).Id, CultureInfo.InvariantCulture);
        d.Calendario = (segunda ? s.CalendarioB : s.CalendarioA).Nombre;
        d.ModalidadEjecucion = segunda ? "A" : "C";
        d.PorRendimientoCuadrilla = !segunda; d.PorAsignacionRecursos = segunda;
        d.HechoPor = segunda ? "RESPONSABLE SINTÉTICO B" : "RESPONSABLE SINTÉTICO A";
        d.Periodos = "Estándar";
        return d;
    }

    private static void Proyectos(string ruta, Selecciones s, Action<string> pasa)
    {
        var primera = MYGProyectoStorage.Nuevo("DATOS OBRA A", "ESTRUCTURAS");
        primera.Id = "DATOS-OBRA-A"; primera.Datos = Datos(s, false);
        primera.Presupuestos.Add(new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 });
        var segunda = MYGProyectoStorage.Nuevo("DATOS OBRA B");
        segunda.Id = "DATOS-OBRA-B"; segunda.Datos = Datos(s, true);
        MYGProyectoStorage.Guardar(ruta, primera); MYGProyectoStorage.Guardar(ruta, segunda);
        foreach (var documento in new[] { primera, segunda })
        {
            var leido = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
            Exige(JsonSerializer.Serialize(leido.Datos) == JsonSerializer.Serialize(documento.Datos) &&
                leido.Presupuestos.Count == documento.Presupuestos.Count,
                "Guardar y reabrir perdió datos del proyecto o sus presupuestos.");
            Nativo(ruta, documento);
        }
        pasa("Guardar y reabrir dos obras conserva todos sus datos y presupuestos junto a sus columnas nativas Delphin");

        string segundaAntes = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id));
        string segundaNativaAntes = Instantanea(ruta, "SELECT * FROM proyecto WHERE id_proyecto=$p0", segunda.Id);
        string presupuestosAntes = Instantanea(ruta, "SELECT * FROM presupuesto");
        primera.Datos.Duracion = 3m; primera.Datos.FechaFin = primera.Datos.CalcularFin();
        primera.Datos.HechoPor = "RESPONSABLE CORREGIDO A";
        primera.Datos.PropietarioId = s.PropietarioB.Id; primera.Datos.Propietario = s.PropietarioB.Nombre;
        MYGProyectoStorage.Guardar(ruta, primera);
        Nativo(ruta, primera);
        Exige(MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id)) == segundaAntes &&
            Instantanea(ruta, "SELECT * FROM proyecto WHERE id_proyecto=$p0", segunda.Id) == segundaNativaAntes &&
            Instantanea(ruta, "SELECT * FROM presupuesto") == presupuestosAntes,
            "Editar los datos de una obra alteró otra obra o modificó sus presupuestos.");
        pasa("Editar datos generales de una obra conserva los datos y presupuestos de las demás obras");

        string validaAntes = Huella(ruta);
        var invalida = MYGProyectoStorage.Copia(primera); invalida.Datos.Duracion = 0;
        Rechaza(() => MYGProyectoStorage.Guardar(ruta, invalida), "Se guardó una obra con duración cero.");
        invalida = MYGProyectoStorage.Copia(primera);
        invalida.Datos.ProvinciaId = s.ProvinciaB.Id; invalida.Datos.Provincia = s.ProvinciaB.Nombre;
        Rechaza(() => MYGProyectoStorage.Guardar(ruta, invalida), "Se guardó una provincia que pertenece a otro departamento.");
        invalida = MYGProyectoStorage.Copia(primera); invalida.Datos.CalendarioId = 987654321;
        Rechaza(() => MYGProyectoStorage.Guardar(ruta, invalida), "Se guardó una referencia a un calendario inexistente.");
        Exige(Huella(ruta) == validaAntes && MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id)) == segundaAntes,
            "Una validación fallida de los datos generales dejó una escritura parcial.");
        Exige(Texto(ruta, "PRAGMA integrity_check") == "ok", "Los datos generales dañaron la integridad de SQLite.");
        pasa("Duración, calendario y ubicación incompatibles revierten el guardado completo sin alterar las obras existentes");
    }

    private static void Nativo(string ruta, MYGProyectoDocumento documento)
    {
        var d = documento.Datos;
        var referencias = new[]
        {
            (Columna: "id_propietario", Valor: d.PropietarioId), (Columna: "id_portafolio", Valor: d.PortafolioId),
            (Columna: "id_infraestructura", Valor: d.TipoObraId), (Columna: "id_departamento", Valor: d.DepartamentoId),
            (Columna: "id_provincia", Valor: d.ProvinciaId), (Columna: "id_distrito", Valor: d.DistritoId),
            (Columna: "id_localidad", Valor: d.LocalidadId)
        };
        foreach (var referencia in referencias)
            Exige(Texto(ruta, "SELECT " + referencia.Columna + " FROM proyecto WHERE id_proyecto=$p0", documento.Id) == referencia.Valor,
                "Los datos generales no guardaron la referencia nativa " + referencia.Columna + ".");
        Exige(Texto(ruta, "SELECT fecha_proyecto FROM proyecto WHERE id_proyecto=$p0", documento.Id) == d.FechaElaboracion.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) &&
            Texto(ruta, "SELECT fecha_inicio FROM proyecto WHERE id_proyecto=$p0", documento.Id) == d.FechaInicio.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) &&
            Texto(ruta, "SELECT fecha_fin FROM proyecto WHERE id_proyecto=$p0", documento.Id) == d.FechaFin.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
            "Las fechas del proyecto no se reflejan en el formato nativo Delphin.");
        Exige(Numero(ruta, "SELECT duracion_new FROM proyecto WHERE id_proyecto=$p0", documento.Id) == d.Duracion &&
            Numero(ruta, "SELECT duracion FROM proyecto WHERE id_proyecto=$p0", documento.Id) == decimal.Truncate(d.Duracion) &&
            Numero(ruta, "SELECT id_calendario FROM proyecto WHERE id_proyecto=$p0", documento.Id) == d.CalendarioId &&
            Numero(ruta, "SELECT fin_periodo FROM proyecto WHERE id_proyecto=$p0", documento.Id) == -1,
            "Se perdió la duración decimal, el calendario o el período estándar en las columnas nativas.");
        Exige(Texto(ruta, "SELECT modalidad_ejecucion FROM proyecto WHERE id_proyecto=$p0", documento.Id) == d.ModalidadEjecucion &&
            Texto(ruta, "SELECT acu_mode FROM proyecto WHERE id_proyecto=$p0", documento.Id) == (d.PorRendimientoCuadrilla ? "N" : "S") &&
            Texto(ruta, "SELECT id_ubicacion FROM proyecto WHERE id_proyecto=$p0", documento.Id).Equals("Si", StringComparison.OrdinalIgnoreCase),
            "Modalidad de ejecución, modo de ACU o uso de ubicación no se reflejan en Delphin.");
        Exige(!string.IsNullOrWhiteSpace(Texto(ruta,
            "SELECT id_unidadtiempo FROM proyecto WHERE id_proyecto=$p0", documento.Id)), "Falta la unidad nativa de duración.");
    }

    private static void Muestra(string ruta, Action<string> pasa)
    {
        Exige(File.Exists(ruta), "No existe la muestra indicada por MYG_QA_DELPHIN_SQLITE.");
        string antes = Huella(ruta);
        try
        {
            var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var c = Conexion(ruta))
            using (var q = c.CreateCommand())
            {
                // Las exportaciones Delphin anteriores no tienen todas las
                // columnas de la muestra usada originalmente por esta prueba.
                q.CommandText = "PRAGMA table_info(proyecto)";
                using var lector = q.ExecuteReader();
                while (lector.Read()) columnas.Add(lector.GetString(1));
            }
            foreach (var resumen in MYGBaseDatos.ListarProyectos(ruta))
            {
                var documento = MYGBaseDatos.LeerProyecto(ruta, resumen.Id);
                Exige(documento.Datos != null, "La lectura Delphin no importó los datos generales de la obra.");
                var d = documento.Datos;
                var referencias = new[]
                {
                    (Columna: "id_propietario", Valor: d.PropietarioId), (Columna: "id_portafolio", Valor: d.PortafolioId),
                    (Columna: "id_infraestructura", Valor: d.TipoObraId), (Columna: "id_departamento", Valor: d.DepartamentoId),
                    (Columna: "id_provincia", Valor: d.ProvinciaId), (Columna: "id_distrito", Valor: d.DistritoId),
                    (Columna: "id_localidad", Valor: d.LocalidadId)
                };
                foreach (var referencia in referencias)
                {
                    if (!columnas.Contains(referencia.Columna))
                    {
                        Exige(string.IsNullOrWhiteSpace(referencia.Valor),
                            "La importación inventó una referencia cuya columna nativa no existe: " + referencia.Columna + ".");
                        continue;
                    }
                    Exige(Texto(ruta, "SELECT " + referencia.Columna + " FROM proyecto WHERE id_proyecto=$p0", resumen.Id) == (referencia.Valor ?? ""),
                        "Los datos generales importados perdieron una referencia nativa: " + referencia.Columna + ".");
                }
                foreach (var fecha in new[] { (Columna: "fecha_proyecto", Valor: d.FechaElaboracion),
                    (Columna: "fecha_inicio", Valor: d.FechaInicio), (Columna: "fecha_fin", Valor: d.FechaFin) })
                {
                    if (!columnas.Contains(fecha.Columna))
                    {
                        Exige(fecha.Valor == null,
                            "La importación inventó una fecha cuya columna nativa no existe: " + fecha.Columna + ".");
                        continue;
                    }
                    string texto = Texto(ruta, "SELECT " + fecha.Columna + " FROM proyecto WHERE id_proyecto=$p0", resumen.Id);
                    if (string.IsNullOrWhiteSpace(texto)) Exige(fecha.Valor == null, "La importación inventó una fecha ausente en Delphin.");
                    else if (DateTime.TryParseExact(texto, new[] { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd" },
                        CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsed))
                        Exige(fecha.Valor?.Date == parsed.Date, "La importación cambió una fecha del proyecto nativo.");
                }
                Exige(!string.IsNullOrWhiteSpace(d.FirmaImportada), "La importación no capturó la firma de los datos nativos para conservarlos al guardar.");
            }
            pasa("Muestra nativa importa datos generales, ubicaciones y fechas en modo de lectura sin cambiar el archivo original");
        }
        finally { Exige(Huella(ruta) == antes, "Leer los datos generales modificó el archivo Delphin original del usuario."); }
    }
}
