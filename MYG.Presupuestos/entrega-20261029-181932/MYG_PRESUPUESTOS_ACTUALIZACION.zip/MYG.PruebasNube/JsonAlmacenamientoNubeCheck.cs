using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class JsonAlmacenamientoNubeCheck
{
    internal static Task RunAsync()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-json-almacenamiento-nube-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        int comprobaciones = 0;
        void Exige(bool condicion, string mensaje)
        {
            comprobaciones++;
            if (!condicion) throw new InvalidOperationException("Almacenamiento y nube: " + mensaje);
        }
        try
        {
            string origen = Path.Combine(carpeta, "origen.sqlite");
            string adjunto = Path.Combine(carpeta, "ficha-sintetica.txt");
            byte[] bytesAdjunto = Encoding.UTF8.GetBytes("Ficha sintética: ñ, m³ y 漢字\nSin datos privados.");
            File.WriteAllBytes(adjunto, bytesAdjunto);
            var documento = MYGProyectoStorage.Nuevo("Documento nativo sintético", "Presupuesto con extensiones MYG");
            // Las identidades nativas cortas activan el overlay, a diferencia de los IDs MYG- habituales.
            documento.Id = "PR-JSON";
            var presupuesto = documento.Presupuestos.Single();
            presupuesto.Id = "PP-JSON";
            documento.PresupuestoActivoId = presupuesto.Id;
            presupuesto.Costos.Insumos.Add(new MYGInsumo
            {
                Id = "INS-JSON", Codigo = "MAT-JSON", Descripcion = "Material sintético",
                Unidad = "und", Precio = 12.12345678901234567890123456m,
                ImagenRuta = adjunto
            });
            var partida = new ItemPresupuestoDelphin
            {
                Id = "CU-JSON", IdLocalMYG = "LOCAL-JSON", IdPropuesta = "CU-JSON",
                TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA",
                Descripcion = "Partida con metrado editado", Unidad = "m³", Posicion = 1,
                Costos = new()
                {
                    Cantidad = 0.1234567890123456789012345678m,
                    PrecioDirecto = 9876543210.123456789012345678m,
                    EspecificacionTexto = "Extensión MYG con Unicode: ñ y 漢字"
                }
            };
            partida.Costos.Hoja.Poner("B3", "3.1415926535897932384626433832");
            partida.Costos.Hoja.Poner("G16", "=B3*2");
            partida.Costos.Hoja.Celdas["B3"].ColorFondo = "A1B2C3";
            partida.Costos.Hoja.Zoom = 135;
            partida.Filtros.Add(new() { Parametro = "Nivel", Regla = "igual", Valor = "Nivel Ñ-漢字" });
            partida.Costos.Analisis.Add(new()
            {
                Id = "REC-JSON", InsumoId = "INS-JSON", Grupo = MYGGrupoRecurso.Materiales,
                Cantidad = 0.3333333333333333333333333333m
            });
            presupuesto.Items.Add(partida);
            presupuesto.Items.Add(new()
            {
                Id = "CU-BASE", IdLocalMYG = "LOCAL-BASE", IdPropuesta = "CU-BASE",
                TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA",
                Descripcion = "Partida con hoja estándar intacta", Unidad = "und", Posicion = 2
            });
            MYGProyectoStorage.Guardar(origen, documento);
            Exige(EsOverlay(origen), "los IDs cortos no ejercitaron el almacenamiento de extensiones Delphin.");
            Exige((long?)Consultar(origen, "SELECT version FROM myg_info") == 4,
                "el guardado no utilizó el esquema de almacenamiento v4.");
            var reabierto = MYGProyectoStorage.Leer(origen);
            Exige(DocumentosIguales(documento, reabierto), "guardar y reabrir perdió datos del documento antes de exportarlo.");
            Exige(JsonElement.DeepEquals(JsonSerializer.SerializeToElement(reabierto.Presupuestos[0].Items[1].Costos.Hoja),
                JsonSerializer.SerializeToElement(MYGHojaMetrado.Crear())),
                "reabrir no reconstruyó la hoja estándar intacta.");
            Ejecutar(origen, "UPDATE costo_unitario SET Notas1='Metadato nativo sintético',archivo_pdf=X'00017F80FF' WHERE id_costounitario='CU-JSON'");
            byte[] huellaOrigen = SHA256.HashData(File.ReadAllBytes(origen));

            foreach (bool compacto in new[] { false, true })
            {
                string formato = compacto ? "compacto" : "tradicional";
                JsonElement paquete = PaqueteNube.CrearContenido(reabierto, origen, compacto: compacto);
                Exige(FormatoPaqueteNube.EsCompacto(paquete) == compacto, "no se ejercitó el formato " + formato + ".");
                JsonElement expandido = FormatoPaqueteNube.Expandir(paquete);
                Exige(expandido.GetProperty("documento").GetProperty("Presupuestos").GetArrayLength() == 1
                    && !expandido.GetProperty("documento").TryGetProperty("FormatoAlmacenamiento", out _),
                    "la exportación " + formato + " envió el overlay interno en lugar del documento portable.");
                Exige(expandido.GetProperty("recursos").GetArrayLength() == 1,
                    "la exportación " + formato + " perdió o duplicó el adjunto.");
                string destino = Path.Combine(carpeta, formato + ".sqlite");
                PaqueteNube.Descargar(paquete, destino);
                var recuperado = MYGProyectoStorage.Leer(destino);
                Exige(DocumentosIguales(reabierto, recuperado),
                    "la descarga " + formato + " cambió identidades, decimales, filtros, análisis o metrado.");
                string rutaRecuperada = recuperado.Presupuestos[0].Costos.Insumos.Single().ImagenRuta;
                Exige(rutaRecuperada != adjunto && File.Exists(rutaRecuperada)
                    && File.ReadAllBytes(rutaRecuperada).SequenceEqual(bytesAdjunto),
                    "la descarga " + formato + " no materializó los bytes del adjunto en su propia ruta.");
                Exige((string?)Consultar(destino, "SELECT Notas1 FROM costo_unitario WHERE id_costounitario='CU-JSON'") == "Metadato nativo sintético"
                    && ((byte[]?)Consultar(destino, "SELECT archivo_pdf FROM costo_unitario WHERE id_costounitario='CU-JSON'"))?.SequenceEqual(new byte[] { 0, 1, 127, 128, 255 }) == true,
                    "la descarga " + formato + " perdió los metadatos o el blob nativo.");
                Exige((long?)Consultar(destino, "SELECT COUNT(*) FROM proyecto WHERE id_proyecto='PR-JSON'") == 1
                    && (long?)Consultar(destino, "SELECT COUNT(*) FROM presupuesto WHERE id_presupuesto='PP-JSON' AND id_proyecto='PR-JSON'") == 1
                    && (long?)Consultar(destino, "SELECT COUNT(*) FROM costo_unitario WHERE id_presupuesto='PP-JSON'") == 2,
                    "la descarga " + formato + " no conservó la estructura nativa del proyecto.");
                Exige(EsOverlay(destino), "la descarga " + formato + " dejó de guardar las extensiones como overlay.");
                Exige((string?)Consultar(destino, "PRAGMA integrity_check") == "ok",
                    "la descarga " + formato + " produjo una base dañada.");
                JsonElement vuelta = PaqueteNube.CrearContenido(recuperado, destino, compacto: compacto);
                Exige(PaqueteNube.FirmaDatosCompartidos(paquete) == PaqueteNube.FirmaDatosCompartidos(vuelta),
                    "la descarga y reexportación " + formato + " introdujo cambios compartidos ficticios.");
            }
            Exige(SHA256.HashData(File.ReadAllBytes(origen)).SequenceEqual(huellaOrigen),
                "exportar o restaurar los paquetes modificó la base original.");
            Console.WriteLine($"OK Almacenamiento y nube: {comprobaciones} comprobaciones de overlay Delphin, documentos, decimales, metrados, filtros, adjuntos y datos nativos; formatos tradicional y compacto, sin red.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static bool DocumentosIguales(MYGProyectoDocumento esperado, MYGProyectoDocumento obtenido)
    {
        var a = MYGProyectoStorage.Copia(esperado);
        var b = MYGProyectoStorage.Copia(obtenido);
        // Guardar actualiza la fecha y cada descarga materializa su propia ruta del mismo adjunto.
        a.ModificadoUtc = b.ModificadoUtc = default;
        a.Presupuestos[0].Costos.Insumos[0].ImagenRuta = "adjunto-verificado";
        b.Presupuestos[0].Costos.Insumos[0].ImagenRuta = "adjunto-verificado";
        return JsonElement.DeepEquals(JsonSerializer.SerializeToElement(a), JsonSerializer.SerializeToElement(b));
    }

    private static bool EsOverlay(string ruta)
    {
        using var json = JsonDocument.Parse((string)Consultar(ruta, "SELECT json_documento FROM myg_proyecto WHERE id='PR-JSON'")!);
        return json.RootElement.GetProperty("FormatoAlmacenamiento").GetString() == "MYG_DELPHIN_EXTENSIONES"
            && json.RootElement.GetProperty("Cambios").ValueKind != JsonValueKind.Null;
    }

    private static object? Consultar(string ruta, string sql)
    {
        using var conexion = Abrir(ruta, SqliteOpenMode.ReadOnly);
        using var comando = conexion.CreateCommand();
        comando.CommandText = sql;
        return comando.ExecuteScalar();
    }

    private static void Ejecutar(string ruta, string sql)
    {
        using var conexion = Abrir(ruta, SqliteOpenMode.ReadWrite);
        using var comando = conexion.CreateCommand();
        comando.CommandText = sql;
        comando.ExecuteNonQuery();
    }

    private static SqliteConnection Abrir(string ruta, SqliteOpenMode modo)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = modo, Pooling = false }.ToString());
        conexion.Open();
        return conexion;
    }
}
