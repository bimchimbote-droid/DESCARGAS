using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinCronogramaModoCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Modo de cronograma Delphin: " + mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        SQLiteDependencyBootstrapper.Initialize();
        Directory.CreateDirectory(carpeta);
        string ruta = Path.Combine(carpeta, "cronograma-modos-delphin.sqlite");
        using (var escritura = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            escritura.Open();
            using var comando = escritura.CreateCommand();
            comando.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,duracion_new NUMERIC,es_hito TEXT,task_mode INTEGER,
                    fecha_inicio TEXT,fecha_fin TEXT,porcentaje_completado NUMERIC);
                INSERT INTO costo_unitario VALUES
                    ('CU-A',4,NULL,'N',0,'2024-12-04 08:00:00','2024-12-09 17:00:00',25),
                    ('CU-M',1,NULL,'N',1,'2024-12-02 08:00:00','2024-12-02 17:00:00',0),
                    ('CU-S',1,NULL,'N',0,'2024-12-10 08:00:00','2024-12-10 17:00:00',0),
                    ('CU-D',0,1,'N',0,'2024-12-09 08:00:00','2024-12-09 17:00:00',0),
                    ('CU-N',NULL,NULL,'N',NULL,'2024-12-10 08:00:00','2024-12-11 17:00:00',0),
                    ('CU-H',1,1,'S',0,'2024-12-13 08:00:00','2024-12-13 08:00:00',0),
                    ('CU-Z',0,NULL,NULL,0,'2024-12-13 08:00:00','2024-12-13 08:00:00',0),
                    ('CU-I',0,0,'N',0,'2024-12-09 08:00:00','2024-12-10 17:00:00',0),
                    ('CU-U',1,NULL,'N',42,'2024-12-12 08:00:00','2024-12-12 17:00:00',0),
                    ('CU-P',2,NULL,'N',0,'2024-12-04 08:00:00',NULL,0);
                CREATE TABLE programacion_costo(id_programacion TEXT,id_costounitario TEXT,start_date TEXT,end_date TEXT,
                    duracion NUMERIC,duracion_new NUMERIC,cantidad NUMERIC,porcentaje NUMERIC);
                INSERT INTO programacion_costo VALUES
                    ('PG-A','CU-A','2024-12-03','2024-12-06',4,NULL,1,100),
                    ('PG-N','CU-N','2024-12-10','2024-12-11',2,NULL,1,100),
                    ('PG-T1','CU-T','2024-12-03','2024-12-03',1,NULL,.5,50),
                    ('PG-T2','CU-T','2025-08-28','2025-08-28',1,NULL,.5,50),
                    ('PG-P','CU-P','2024-12-05','2024-12-06',2,NULL,1,100);
                CREATE TABLE dependencia_tarea(id_dependencia TEXT,id_costounitarioorigen TEXT,id_costounitariodestino TEXT,
                    id_proyecto TEXT,tipo INTEGER,lag_size INTEGER);
                INSERT INTO dependencia_tarea VALUES
                    ('DP-MA','CU-M','CU-A','PR-MODO',0,0),('DP-AS','CU-A','CU-S','PR-MODO',0,0);
                """;
            comando.ExecuteNonQuery();
        }
        string huella = Huella(ruta);
        var documento = Documento("CU-A", "CU-M", "CU-S", "CU-D", "CU-N", "CU-T", "CU-H", "CU-Z", "CU-I", "CU-U", "CU-P");
        string documentoAntes = JsonSerializer.Serialize(documento);
        MYGCronograma plan;
        using (var lectura = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString()))
        {
            lectura.Open();
            plan = DelphinCronogramaMYG.Leer(lectura, documento);
        }
        Exige(JsonSerializer.Serialize(documento) == documentoAntes, "la lectura modificó el documento de presupuestos de origen.");
        var filas = Filas(plan);
        Exige(filas["CU-A"].Tarea.Modo == MYGModoTarea.Automatica && filas["CU-M"].Tarea.Modo == MYGModoTarea.Manual &&
            filas["CU-N"].Tarea.Modo == MYGModoTarea.Automatica,
            "no se respetaron los modos 0/1 o el modo predeterminado con task_mode NULL.");
        Exige(filas["CU-U"].Tarea.Modo == MYGModoTarea.Automatica && plan.AdvertenciasImportacion.Any(a => a.Contains("task_mode=42")),
            "un modo desconocido no recibió alternativa y advertencia.");
        Exige(filas["CU-A"].Inicio == new DateTime(2024, 12, 4) && filas["CU-A"].Fin == new DateTime(2024, 12, 9) &&
            filas["CU-A"].DiasCalendario == 6 && filas["CU-A"].Tarea.FechasImportadasDelphin.Tramos.Single().Inicio == new DateTime(2024, 12, 3),
            "se reemplazaron las fechas de la tarea con las de su distribución por tramos.");
        Exige(filas["CU-P"].Inicio == new DateTime(2024, 12, 5) && filas["CU-P"].Fin == new DateTime(2024, 12, 6),
            "un par de fechas incompleto no utilizó los tramos como alternativa.");
        Exige(filas["CU-T"].Inicio == new DateTime(2024, 12, 3) && filas["CU-T"].Fin == new DateTime(2025, 8, 28) &&
            filas["CU-T"].DuracionDias == 2 && filas["CU-T"].Tarea.FechasImportadasDelphin.Tramos.Count == 2,
            "la tarea automática sin fila de costo perdió sus tramos separados o su duración.");
        pasa("SQLite Delphin: modos automático/manual, alternativa para modo desconocido y fechas de tarea independientes de los tramos");

        Exige(filas["CU-D"].DuracionDias == 1 && filas["CU-N"].DuracionDias == 2 && filas["CU-I"].DuracionDias == 2,
            "se convirtió en hito una duración moderna positiva, NULL o un trabajo marcado como no hito.");
        Exige(filas["CU-H"].DuracionDias == 0 && filas["CU-Z"].DuracionDias == 0,
            "se perdió el hito explícito o el cero compatible con archivos sin indicador de hito.");
        var copia = MYGProyectoStorage.Copia(plan);
        var json = JsonSerializer.Deserialize<MYGCronograma>(JsonSerializer.Serialize(plan));
        foreach (var conservado in new[] { copia, json })
        {
            var f = Filas(conservado);
            Exige(f["CU-A"].Inicio == filas["CU-A"].Inicio && f["CU-A"].Tarea.FechasImportadasDelphin.ModoOriginal == MYGModoTarea.Automatica &&
                f["CU-M"].Tarea.FechasImportadasDelphin.ModoOriginal == MYGModoTarea.Manual &&
                f["CU-T"].Tarea.FechasImportadasDelphin.Tramos.Count == 2,
                "copiar o serializar cambió los modos, las fechas o los tramos importados.");
        }
        pasa("Duraciones modernas, NULL e hitos Delphin conservados al copiar y serializar el cronograma");

        var project = MYGExportacionCronograma.PrepararProject(documento, plan, incluirRecursos: false);
        var tareaProject = project.Tareas.Single(t => t.IdMYG == filas["CU-T"].Tarea.Id);
        Exige(!tareaProject.Manual && tareaProject.DuracionMinutos == 960 &&
            project.TramosPorTarea[tareaProject.Uid].Count == 2 &&
            project.TramosPorTarea[tareaProject.Uid][0].Inicio.Date == new DateTime(2024, 12, 3) &&
            project.TramosPorTarea[tareaProject.Uid][1].Inicio.Date == new DateTime(2025, 8, 28),
            "el modelo de Project convirtió la tarea automática en manual o perdió la pausa entre sus dos días de trabajo.");
        pasa("El modelo de Project conserva modo automático y los dos tramos de una tarea separada de dos días");

        var cambioDuracion = MYGProyectoStorage.Copia(plan);
        cambioDuracion.Tareas.Single(t => t.PartidaId == "CU-A").DuracionDias = 8;
        var recalculadas = Filas(cambioDuracion);
        Exige(recalculadas["CU-A"].Inicio == new DateTime(2024, 12, 3) && recalculadas["CU-A"].Fin == new DateTime(2024, 12, 12) &&
            recalculadas["CU-S"].Inicio == new DateTime(2024, 12, 13),
            "editar la duración de una predecesora no recalculó su sucesora automática.");
        var cambioCalendario = MYGProyectoStorage.Copia(plan);
        cambioCalendario.Calendario.DiasLaborables.Add(DayOfWeek.Saturday);
        var conSabados = Filas(cambioCalendario);
        Exige(conSabados["CU-A"].Inicio == new DateTime(2024, 12, 3) && conSabados["CU-S"].Inicio == new DateTime(2024, 12, 7),
            "editar el calendario siguió imponiendo las fechas originales a las tareas automáticas.");
        var cambioInicio = MYGProyectoStorage.Copia(plan);
        cambioInicio.FechaInicio = new DateTime(2024, 12, 16);
        Exige(Filas(cambioInicio)["CU-A"].Inicio == new DateTime(2024, 12, 16),
            "editar el inicio del proyecto siguió imponiendo las fechas automáticas importadas.");
        Exige(Huella(ruta) == huella, "consultar, copiar o recalcular modificó el SQLite nativo de origen.");
        pasa("La edición de duración, calendario o inicio libera la instantánea y propaga las dependencias sin modificar el SQLite de origen");
        EsquemaAnterior(pasa);
        AntecesoraSinFechas(pasa);
        CascadaAntecesorasSinFechas(pasa);
        RutaCriticaConTramosSeparados(pasa);
        RechazarTramosFueraDeLaTarea(pasa);
    }

    private static void AntecesoraSinFechas(Action<string> pasa)
    {
        using var c = new SqliteConnection("Data Source=:memory:"); c.Open();
        using (var comando = c.CreateCommand())
        {
            comando.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,task_mode INTEGER,fecha_inicio TEXT,fecha_fin TEXT);
                INSERT INTO costo_unitario VALUES
                    ('CU-SIN-FECHAS',1,0,NULL,NULL),('CU-SUCESORA',2,0,'2024-12-10','2024-12-11');
                CREATE TABLE dependencia_tarea(id_dependencia TEXT,id_costounitarioorigen TEXT,id_costounitariodestino TEXT,
                    id_proyecto TEXT,tipo INTEGER,lag_size INTEGER);
                INSERT INTO dependencia_tarea VALUES('DP-SIN-FECHAS','CU-SIN-FECHAS','CU-SUCESORA','PR-MODO',0,0);
                PRAGMA query_only=ON;
                """;
            comando.ExecuteNonQuery();
        }
        long cambios = CambiosSqlite(c);
        var documento = Documento("CU-SIN-FECHAS", "CU-SUCESORA");
        string documentoAntes = JsonSerializer.Serialize(documento);
        var plan = DelphinCronogramaMYG.Leer(c, documento);
        string planAntes = JsonSerializer.Serialize(plan);
        var filas = Filas(plan);
        Exige(filas["CU-SIN-FECHAS"].Tarea.FechasImportadasDelphin == null &&
            filas["CU-SUCESORA"].Inicio == new DateTime(2024, 12, 10) &&
            filas["CU-SUCESORA"].Fin == new DateTime(2024, 12, 11) &&
            filas["CU-SUCESORA"].Tarea.FechasImportadasDelphin != null,
            "una predecesora originalmente sin fechas desplazó a su sucesora nativa durante la primera apertura.");
        Exige(JsonSerializer.Serialize(plan) == planAntes,
            "calcular la primera apertura modificó el cronograma importado de origen.");

        var editado = MYGProyectoStorage.Copia(plan);
        editado.Tareas.Single(t => t.PartidaId == "CU-SIN-FECHAS").DuracionDias = 8;
        string editadoAntes = JsonSerializer.Serialize(editado);
        var recalculadas = Filas(editado);
        Exige(recalculadas["CU-SIN-FECHAS"].Fin == new DateTime(2024, 12, 11) &&
            recalculadas["CU-SUCESORA"].Inicio == new DateTime(2024, 12, 12) &&
            recalculadas["CU-SUCESORA"].Fin == new DateTime(2024, 12, 13) &&
            recalculadas["CU-SUCESORA"].Tarea.FechasImportadasDelphin == null,
            "editar la duración de una predecesora sin fechas no liberó la instantánea ni propagó el nuevo fin a su sucesora.");
        Exige(JsonSerializer.Serialize(editado) == editadoAntes && JsonSerializer.Serialize(plan) == planAntes &&
            JsonSerializer.Serialize(documento) == documentoAntes && CambiosSqlite(c) == cambios,
            "la importación o el recálculo de una predecesora sin fechas modificó su plan, documento o SQLite de origen.");
        pasa("Una predecesora sin fechas conserva inicialmente la instantánea de su sucesora y propaga después una edición de duración");
    }

    private static void CascadaAntecesorasSinFechas(Action<string> pasa)
    {
        using var c = new SqliteConnection("Data Source=:memory:"); c.Open();
        using (var comando = c.CreateCommand())
        {
            comando.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,task_mode INTEGER,fecha_inicio TEXT,fecha_fin TEXT);
                INSERT INTO costo_unitario VALUES
                    ('CU-CADENA-A',1,0,NULL,NULL),('CU-CADENA-B',1,0,NULL,NULL),
                    ('CU-CADENA-C',2,0,'2024-12-10','2024-12-11');
                CREATE TABLE dependencia_tarea(id_dependencia TEXT,id_costounitarioorigen TEXT,id_costounitariodestino TEXT,
                    id_proyecto TEXT,tipo INTEGER,lag_size INTEGER);
                INSERT INTO dependencia_tarea VALUES
                    ('DP-CADENA-AB','CU-CADENA-A','CU-CADENA-B','PR-MODO',0,0),
                    ('DP-CADENA-BC','CU-CADENA-B','CU-CADENA-C','PR-MODO',0,0);
                PRAGMA query_only=ON;
                """;
            comando.ExecuteNonQuery();
        }
        long cambios = CambiosSqlite(c);
        var documento = Documento("CU-CADENA-A", "CU-CADENA-B", "CU-CADENA-C");
        string documentoAntes = JsonSerializer.Serialize(documento);
        var plan = DelphinCronogramaMYG.Leer(c, documento);
        string planAntes = JsonSerializer.Serialize(plan);
        var iniciales = Filas(plan);
        Exige(iniciales["CU-CADENA-A"].Tarea.FechasImportadasDelphin == null &&
            iniciales["CU-CADENA-B"].Tarea.FechasImportadasDelphin == null &&
            iniciales["CU-CADENA-C"].Inicio == new DateTime(2024, 12, 10) &&
            iniciales["CU-CADENA-C"].Fin == new DateTime(2024, 12, 11),
            "una cadena de dos predecesoras sin fechas desplazó la instantánea de su sucesora durante la primera apertura.");
        var editado = MYGProyectoStorage.Copia(plan);
        var intermedia = editado.Tareas.Single(t => t.PartidaId == "CU-CADENA-B");
        string intermediaAntes = JsonSerializer.Serialize(intermedia);
        editado.Tareas.Single(t => t.PartidaId == "CU-CADENA-A").DuracionDias = 8;
        string editadoAntes = JsonSerializer.Serialize(editado);
        var recalculadas = Filas(editado);
        Exige(recalculadas["CU-CADENA-B"].Inicio == new DateTime(2024, 12, 12) &&
            recalculadas["CU-CADENA-B"].Fin == new DateTime(2024, 12, 12) &&
            recalculadas["CU-CADENA-C"].Inicio == new DateTime(2024, 12, 13) &&
            recalculadas["CU-CADENA-C"].Fin == new DateTime(2024, 12, 16) &&
            recalculadas["CU-CADENA-C"].Tarea.FechasImportadasDelphin == null &&
            JsonSerializer.Serialize(intermedia) == intermediaAntes,
            "la edición de A no propagó las fechas calculadas de B a C cuando A y B carecían de instantánea y B no fue editada.");
        Exige(JsonSerializer.Serialize(editado) == editadoAntes && JsonSerializer.Serialize(plan) == planAntes &&
            JsonSerializer.Serialize(documento) == documentoAntes && CambiosSqlite(c) == cambios,
            "el recálculo de la cadena de predecesoras sin fechas modificó el plan, el documento o el SQLite de origen.");
        pasa("Una edición se propaga por dos predecesoras originalmente sin fechas hasta liberar la instantánea de su sucesora");
    }

    private static void RutaCriticaConTramosSeparados(Action<string> pasa)
    {
        using var c = new SqliteConnection("Data Source=:memory:"); c.Open();
        using (var comando = c.CreateCommand())
        {
            comando.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,task_mode INTEGER,fecha_inicio TEXT,fecha_fin TEXT);
                INSERT INTO costo_unitario VALUES('CU-SEPARADA',2,0,'2026-01-05','2026-10-01');
                CREATE TABLE programacion_costo(id_programacion TEXT,id_costounitario TEXT,start_date TEXT,end_date TEXT,duracion INTEGER);
                INSERT INTO programacion_costo VALUES
                    ('PG-SEPARADA-1','CU-SEPARADA','2026-01-05','2026-01-05',1),
                    ('PG-SEPARADA-2','CU-SEPARADA','2026-10-01','2026-10-01',1);
                PRAGMA query_only=ON;
                """;
            comando.ExecuteNonQuery();
        }
        long cambios = CambiosSqlite(c);
        var documento = Documento("CU-SEPARADA");
        documento.Datos.FechaInicio = new DateTime(2026, 1, 5);
        var plan = DelphinCronogramaMYG.Leer(c, documento);
        string planAntes = JsonSerializer.Serialize(plan);
        var resultado = MYGMotorCronograma.Calcular(plan);
        var tarea = resultado.Filas.Single(f => !f.Tarea.EsResumen);
        Exige(tarea.Tarea.Modo == MYGModoTarea.Automatica && tarea.DuracionDias == 2 &&
            tarea.Inicio == new DateTime(2026, 1, 5) && tarea.Fin == new DateTime(2026, 10, 1) &&
            tarea.Fin == resultado.Fin && tarea.HolguraDias == 0 && tarea.EsCritica,
            "la tarea automática de dos días separados que fija el fin del proyecto recibió holgura artificial o dejó de ser crítica.");
        foreach (var modo in new[] { MYGModoRutaCritica.Simple, MYGModoRutaCritica.Multiple })
            Exige(MYGRutasCriticasCronograma.Calcular(plan, resultado, modo).SetEquals(new[] { tarea.Tarea.Id }) &&
                MYGRutasCriticasCronograma.Calcular(plan, modo).SetEquals(new[] { tarea.Tarea.Id }),
                "la tarea automática con pausa entre enero y octubre dejó de ser crítica en el modo de rutas " + modo + ".");
        Exige(JsonSerializer.Serialize(plan) == planAntes && CambiosSqlite(c) == cambios,
            "consultar la ruta crítica de la tarea separada modificó el cronograma o el SQLite de origen.");
        pasa("Una tarea automática de dos días entre enero y octubre tiene holgura cero y es crítica en el motor y en todas las rutas");
    }

    private static void RechazarTramosFueraDeLaTarea(Action<string> pasa)
    {
        using var c = new SqliteConnection("Data Source=:memory:"); c.Open();
        using (var comando = c.CreateCommand())
        {
            comando.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,task_mode INTEGER,fecha_inicio TEXT,fecha_fin TEXT);
                INSERT INTO costo_unitario VALUES('CU-FUERA',2,0,'2024-12-04','2024-12-09');
                CREATE TABLE programacion_costo(id_programacion TEXT,id_costounitario TEXT,start_date TEXT,end_date TEXT,duracion INTEGER);
                INSERT INTO programacion_costo VALUES
                    ('PG-FUERA-1','CU-FUERA','2024-12-03','2024-12-03',1),
                    ('PG-FUERA-2','CU-FUERA','2024-12-09','2024-12-09',1);
                PRAGMA query_only=ON;
                """;
            comando.ExecuteNonQuery();
        }
        long cambios = CambiosSqlite(c);
        var documento = Documento("CU-FUERA");
        var plan = DelphinCronogramaMYG.Leer(c, documento);
        string documentoAntes = JsonSerializer.Serialize(documento), planAntes = JsonSerializer.Serialize(plan);
        Exception fallo = null;
        try { MYGExportacionCronograma.PrepararProject(documento, plan, incluirRecursos: false); }
        catch (Exception ex) { fallo = ex; }
        Exige(fallo is InvalidDataException && fallo.Message.Contains("CU-FUERA", StringComparison.Ordinal) &&
            fallo.Message.Contains("fuera", StringComparison.OrdinalIgnoreCase) && fallo.Message.Contains("SQLite", StringComparison.Ordinal),
            "preparar el modelo de Project no rechazó con el nombre de la tarea sus múltiples tramos fuera del intervalo nativo.");
        Exige(JsonSerializer.Serialize(documento) == documentoAntes && JsonSerializer.Serialize(plan) == planAntes &&
            CambiosSqlite(c) == cambios,
            "rechazar los tramos fuera de intervalo modificó el documento, el plan o el SQLite de origen.");
        pasa("El modelo de Project rechaza los tramos automáticos fuera de intervalo antes de iniciar la exportación y conserva los datos de origen");
    }

    private static long CambiosSqlite(SqliteConnection c)
    {
        using var comando = c.CreateCommand(); comando.CommandText = "SELECT total_changes()";
        return Convert.ToInt64(comando.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture);
    }

    private static void EsquemaAnterior(Action<string> pasa)
    {
        using var c = new SqliteConnection("Data Source=:memory:"); c.Open();
        using var comando = c.CreateCommand();
        comando.CommandText = """
            CREATE TABLE costo_unitario(id_costounitario TEXT,fecha_inicio TEXT,fecha_fin TEXT);
            INSERT INTO costo_unitario VALUES('CU-ANTERIOR','2024-12-03','2024-12-05');
            CREATE TABLE programacion_costo(id_programacion TEXT,id_costounitario TEXT,start_date TEXT,end_date TEXT,duracion INTEGER);
            INSERT INTO programacion_costo VALUES('PG-ANTERIOR','CU-ANTERIOR','2024-12-03','2024-12-05',3);
            """;
        comando.ExecuteNonQuery();
        var tarea = Filas(DelphinCronogramaMYG.Leer(c, Documento("CU-ANTERIOR")))["CU-ANTERIOR"];
        Exige(tarea.Tarea.Modo == MYGModoTarea.Automatica && tarea.DuracionDias == 3 && tarea.Inicio == new DateTime(2024, 12, 3),
            "la ausencia de columnas modernas sustituyó por cero la duración disponible en los tramos.");
        pasa("Esquemas Delphin sin task_mode, duracion_new, es_hito ni duración en costo conservan la duración de sus tramos");
    }

    private static MYGProyectoDocumento Documento(params string[] ids)
    {
        var p = new MYGPresupuestoDocumento { Id = "PP-MODO", Nombre = "Modos", Item = "1" };
        p.Items = ids.Select(id => new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdInternoDelphin = id, Item = id, Descripcion = id, Unidad = "und", TipoPropuesta = "PARTIDA"
        }).ToList();
        return new MYGProyectoDocumento
        {
            Id = "PR-MODO", Nombre = "Modos Delphin", Presupuestos = new() { p }, PresupuestoActivoId = p.Id,
            Datos = new() { FechaInicio = new DateTime(2024, 12, 2) }
        };
    }

    private static Dictionary<string, MYGResultadoTarea> Filas(MYGCronograma plan) => MYGMotorCronograma.Calcular(plan).Filas
        .Where(f => !f.Tarea.EsResumen).ToDictionary(f => f.Tarea.PartidaId, StringComparer.Ordinal);
    private static string Huella(string ruta)
    { using var archivo = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(archivo)); }
}
