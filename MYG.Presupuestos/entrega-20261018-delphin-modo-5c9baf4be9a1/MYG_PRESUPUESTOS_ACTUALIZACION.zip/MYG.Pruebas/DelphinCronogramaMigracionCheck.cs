using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinCronogramaMigracionCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Migración de cronograma Delphin: " + mensaje); }

    internal static void Ejecutar(Action<string> pasa)
    {
        SQLiteDependencyBootstrapper.Initialize();
        using var c = new SqliteConnection("Data Source=:memory:");
        c.Open();
        using (var comando = c.CreateCommand())
        {
            // Datos sintéticos: la fila de A tiene duración y fechas distintas
            // de sus tramos, como las importaciones anteriores a la corrección.
            comando.CommandText = """
                CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,fecha_inicio TEXT,fecha_fin TEXT,
                    porcentaje_completado NUMERIC,task_mode INTEGER);
                INSERT INTO costo_unitario VALUES
                    ('CU-A',4,'2024-12-04 08:00:00','2024-12-09 17:00:00',5,0),
                    ('CU-B',1,'2024-12-02 08:00:00','2024-12-02 17:00:00',0,0),
                    ('CU-C',1,'2024-12-10 08:00:00','2024-12-10 17:00:00',0,1),
                    ('CU-D',1,'2024-12-11 08:00:00','2024-12-11 17:00:00',0,42),
                    ('CU-E',1,'2024-12-12 08:00:00','2024-12-12 17:00:00',0,NULL);
                CREATE TABLE programacion_costo(id_programacion TEXT,id_costounitario TEXT,start_date TEXT,end_date TEXT,
                    duracion INTEGER,cantidad NUMERIC,porcentaje NUMERIC);
                INSERT INTO programacion_costo VALUES
                    ('PG-A1','CU-A','2024-12-03','2024-12-03',1,.5,50),
                    ('PG-A2','CU-A','2024-12-06','2024-12-06',1,.5,50);
                CREATE TABLE dependencia_tarea(id_dependencia TEXT,id_costounitarioorigen TEXT,id_costounitariodestino TEXT,
                    id_proyecto TEXT,tipo INTEGER,lag_size INTEGER);
                INSERT INTO dependencia_tarea VALUES('DP-1','CU-B','CU-A','PR-MIGRACION',0,0);
                PRAGMA query_only=ON;
                """;
            comando.ExecuteNonQuery();
        }
        long cambiosAntes = Cambios(c);
        var documento = Documento(c);
        var plan = documento.Cronograma;
        var tarea = Legada(documento);
        var original = MYGProyectoStorage.Copia(tarea);
        var otrasAntes = Json(plan.Tareas.Where(t => t.Id != tarea.Id).ToArray());
        var vinculosAntes = Json(plan.VinculosImportadosDelphin);
        plan.AdvertenciasImportacion.Add("Aviso previo del usuario");
        int avisosAntes = plan.AdvertenciasImportacion.Count;

        DelphinCronogramaMigracionMYG.ActualizarLectura(c, documento);
        Exige(ReferenceEquals(documento.Cronograma, plan) && ReferenceEquals(Tarea(documento), tarea) &&
            tarea.Modo == MYGModoTarea.Automatica && tarea.InicioManual == new DateTime(2024, 12, 4) && tarea.DuracionDias == 4 &&
            tarea.FechasImportadasDelphin.ModoOriginal == MYGModoTarea.Automatica &&
            tarea.FechasImportadasDelphin.Inicio == new DateTime(2024, 12, 4) &&
            tarea.FechasImportadasDelphin.Fin == new DateTime(2024, 12, 9) &&
            tarea.FechasImportadasDelphin.DuracionDias == 4,
            "no se corrigió en memoria el modo automático nativo y las fechas/duración de la instantánea legada intacta.");
        pasa("Lectura legada recupera task_mode=0 y las fechas/duración nativas sin sustituir el cronograma ni la tarea");

        Exige(tarea.Notas == original.Notas && tarea.Avance == original.Avance &&
            tarea.Responsables.SequenceEqual(original.Responsables) && tarea.InicioBase == original.InicioBase &&
            tarea.FinBase == original.FinBase && tarea.DuracionBase == original.DuracionBase &&
            Json(tarea.Predecesoras) == Json(original.Predecesoras) &&
            Json(plan.Tareas.Where(t => t.Id != tarea.Id).ToArray()) == otrasAntes &&
            Json(plan.VinculosImportadosDelphin) == vinculosAntes &&
            plan.AdvertenciasImportacion.Count == avisosAntes + 1 && plan.AdvertenciasImportacion.Contains("Aviso previo del usuario"),
            "la corrección sustituyó notas, avance, responsables, línea base, dependencias, tareas ajenas o advertencias existentes.");
        pasa("Migración conserva notas, avance, responsables, línea base, vínculos y tareas ajenas a la corrección");

        string despues = Json(documento);
        DelphinCronogramaMigracionMYG.ActualizarLectura(c, documento);
        Exige(Json(documento) == despues, "una segunda lectura repitió la corrección o añadió otra advertencia.");
        pasa("Una instantánea con ModoOriginal actualizado no vuelve a migrarse ni duplica advertencias");

        foreach (var edicion in new (string Nombre, Action<MYGTareaCronograma> Aplicar)[]
        {
            ("inicio manual", t => t.InicioManual = t.InicioManual.Value.AddDays(1)),
            ("duración manual", t => t.DuracionDias++),
            ("tipo de dependencia", t => t.Predecesoras[0].Tipo = MYGTipoVinculo.CC),
            ("desfase de dependencia", t => t.Predecesoras[0].DesfaseDias = 2),
            ("dependencia eliminada", t => t.Predecesoras.Clear())
        })
        {
            var editado = Documento(c);
            var legada = Legada(editado);
            edicion.Aplicar(legada);
            string antes = Json(editado);
            DelphinCronogramaMigracionMYG.ActualizarLectura(c, editado);
            Exige(Json(editado) == antes, "se sobrescribió una edición del usuario en " + edicion.Nombre + ".");
        }
        pasa("Las ediciones de inicio, duración, tipo y desfase de vínculos, o sus eliminaciones, impiden sobrescribir la planificación guardada");

        foreach (MYGModoTarea modo in Enum.GetValues<MYGModoTarea>())
        {
            var nuevo = Documento(c);
            var registrada = Legada(nuevo);
            registrada.Modo = modo;
            registrada.FechasImportadasDelphin.ModoOriginal = modo;
            string antes = Json(nuevo);
            DelphinCronogramaMigracionMYG.ActualizarLectura(c, nuevo);
            Exige(Json(nuevo) == antes, "se reimportó una tarea con ModoOriginal ya asignado en modo " + modo + ".");
        }
        pasa("Los modos automáticos y manuales con ModoOriginal registrado jamás se sobrescriben desde el SQLite");

        var manual = Documento(c);
        var nativaManual = Legada(manual, "CU-C");
        DelphinCronogramaMigracionMYG.ActualizarLectura(c, manual);
        Exige(nativaManual.Modo == MYGModoTarea.Manual && nativaManual.FechasImportadasDelphin.ModoOriginal == MYGModoTarea.Manual &&
            nativaManual.InicioManual == new DateTime(2024, 12, 10) && nativaManual.DuracionDias == 1,
            "task_mode=1 no conservó el modo manual al actualizar la instantánea legada.");
        pasa("task_mode=1 conserva su modo manual y registra el origen sin convertir todas las tareas en automáticas");

        foreach (string id in new[] { "CU-D", "CU-E" })
        {
            var desconocido = Documento(c);
            Legada(desconocido, id);
            string antes = Json(desconocido);
            DelphinCronogramaMigracionMYG.ActualizarLectura(c, desconocido);
            Exige(Json(desconocido) == antes, "un task_mode nativo inválido o NULL reemplazó el modo guardado del usuario.");
        }
        pasa("Los valores task_mode desconocidos o NULL no justifican sobrescribir una instantánea guardada");

        foreach (bool cambiarCalendario in new[] { false, true })
        {
            var editado = Documento(c);
            Legada(editado);
            if (cambiarCalendario) editado.Cronograma.Calendario.HorasPorDia++;
            else editado.Cronograma.FechaInicio = editado.Cronograma.FechaInicio.AddDays(1);
            string antes = Json(editado);
            DelphinCronogramaMigracionMYG.ActualizarLectura(c, editado);
            Exige(Json(editado) == antes, "se alteró una planificación cuyo calendario o inicio del proyecto fue editado.");
        }
        pasa("Cambiar el calendario o el inicio del proyecto protege la planificación de una migración automática");
        Exige(Cambios(c) == cambiosAntes, "la lectura ejecutó escrituras en la base original.");
        pasa("Toda la migración usa SQLite real en modo query_only sin aumentar total_changes ni modificar los datos nativos");
    }

    private static MYGProyectoDocumento Documento(SqliteConnection c)
    {
        var presupuesto = new MYGPresupuestoDocumento { Id = "PP-MIGRACION", Nombre = "Presupuesto sintético", Item = "01" };
        foreach (string id in new[] { "CU-A", "CU-B", "CU-C", "CU-D", "CU-E" })
            presupuesto.Items.Add(new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdInternoDelphin = id,
                Item = id, Descripcion = "Tarea " + id, Unidad = "und", TipoPropuesta = "PARTIDA", Costos = new() { Cantidad = 1 } });
        var documento = new MYGProyectoDocumento { Id = "PR-MIGRACION", Nombre = "Prueba sintética de migración",
            Presupuestos = new() { presupuesto }, PresupuestoActivoId = presupuesto.Id,
            Datos = new() { FechaInicio = new DateTime(2024, 12, 2) } };
        documento.Cronograma = DelphinCronogramaMYG.Leer(c, documento);
        return documento;
    }

    private static MYGTareaCronograma Tarea(MYGProyectoDocumento documento) =>
        documento.Cronograma.Tareas.Single(t => t.PartidaId == "CU-A");

    private static MYGTareaCronograma Legada(MYGProyectoDocumento documento, string id = "CU-A")
    {
        var tarea = documento.Cronograma.Tareas.Single(t => t.PartidaId == id);
        tarea.Modo = MYGModoTarea.Manual;
        tarea.InicioManual = new DateTime(2024, 12, 3);
        tarea.DuracionDias = 2;
        tarea.FechasImportadasDelphin.ModoOriginal = null;
        tarea.FechasImportadasDelphin.Inicio = tarea.InicioManual.Value;
        tarea.FechasImportadasDelphin.Fin = new DateTime(2024, 12, 6);
        tarea.FechasImportadasDelphin.DuracionDias = tarea.DuracionDias;
        tarea.Notas = "Nota guardada por el usuario";
        tarea.Avance = 37.5m;
        tarea.Responsables.AddRange(new[] { "Residente", "Supervisor" });
        tarea.InicioBase = new DateTime(2024, 12, 2);
        tarea.FinBase = new DateTime(2024, 12, 12);
        tarea.DuracionBase = 9;
        return tarea;
    }

    private static string Json<T>(T valor) => JsonSerializer.Serialize(valor);

    private static long Cambios(SqliteConnection c)
    {
        using var comando = c.CreateCommand();
        comando.CommandText = "SELECT total_changes()";
        return Convert.ToInt64(comando.ExecuteScalar(), CultureInfo.InvariantCulture);
    }
}
