using System;
using System.Linq;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

internal static class DelphinCronogramaMigracionMYG
{
    // Las primeras importaciones guardaban todas las hojas como Manual y no
    // registraban ModoOriginal. Releer sólo instantáneas que siguen intactas;
    // nunca reemplazar el documento completo ni escribir en la base al abrirla.
    internal static void ActualizarLectura(SqliteConnection conexion, MYGProyectoDocumento documento)
    {
        var plan = documento.Cronograma;
        if (plan?.Tareas == null || !plan.Tareas.Any(EsLegadaIntacta)) return;
        using var columna = conexion.CreateCommand();
        columna.CommandText = "SELECT name FROM pragma_table_info('costo_unitario') WHERE name='task_mode' COLLATE NOCASE";
        if (columna.ExecuteScalar() == null) return;
        var nativo = DelphinCronogramaMYG.Leer(conexion, documento);
        if (nativo == null) return;
        if (plan.FechaInicio.Date != nativo.FechaInicio.Date ||
            MYGMotorCronograma.FirmaCalendarioDelphin(plan.Calendario) != MYGMotorCronograma.FirmaCalendarioDelphin(nativo.Calendario)) return;
        var modosConocidos = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var modos = conexion.CreateCommand())
        {
            modos.CommandText = "SELECT id_costounitario FROM costo_unitario WHERE task_mode IN (0,1)";
            using var filas = modos.ExecuteReader();
            while (filas.Read()) modosConocidos.Add(filas.GetString(0));
        }
        var tareasNativas = nativo.Tareas.Where(t => !t.EsResumen && t.FechasImportadasDelphin != null)
            .ToDictionary(t => (t.PresupuestoId, t.PartidaId));
        int actualizadas = 0;
        foreach (var tarea in plan.Tareas.Where(EsLegadaIntacta))
        {
            if (!modosConocidos.Contains(tarea.PartidaId) ||
                !tareasNativas.TryGetValue((tarea.PresupuestoId, tarea.PartidaId), out var origen) ||
                MYGMotorCronograma.FirmaPredecesorasDelphin(tarea) != MYGMotorCronograma.FirmaPredecesorasDelphin(origen)) continue;
            // No sustituir notas, avance, responsables, línea base o vínculos
            // del documento MYG por los de una importación nueva.
            tarea.Modo = origen.Modo;
            tarea.InicioManual = origen.InicioManual;
            tarea.DuracionDias = origen.DuracionDias;
            tarea.FechasImportadasDelphin = MYGProyectoStorage.Copia(origen.FechasImportadasDelphin);
            actualizadas++;
        }
        if (actualizadas > 0)
            (plan.AdvertenciasImportacion ??= new()).Add("Se actualizó la lectura del modo, fechas y duración de " + actualizadas +
                " tareas Delphin importadas con una versión anterior. La base original no se modificó al abrirla.");
    }

    private static bool EsLegadaIntacta(MYGTareaCronograma tarea) => !tarea.EsResumen &&
        tarea.FechasImportadasDelphin is { ModoOriginal: null } &&
        tarea.Modo == MYGModoTarea.Manual && MYGMotorCronograma.ConservaFechasDelphin(tarea);
}
