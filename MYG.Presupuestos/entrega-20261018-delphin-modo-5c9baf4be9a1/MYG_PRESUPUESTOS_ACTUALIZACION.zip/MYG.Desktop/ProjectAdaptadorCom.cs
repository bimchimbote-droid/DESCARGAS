using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

namespace MYG_2027;

/// <summary>Construye un proyecto mediante el modelo de objetos de Project.
/// Ninguna tarea ni recurso se importa desde XML.</summary>
[SupportedOSPlatform("windows")]
internal sealed class MYGAdaptadorProjectCom : IMYGAdaptadorProject
{
    private readonly Type tipoAplicacion;
    private readonly Dictionary<int, object> tareas = new();
    private readonly Dictionary<int, int> idsRecursos = new();
    private readonly Dictionary<int, int> tiposRecursos = new();
    private readonly Dictionary<int, MYGTextoTareaManualProject> textosManuales = new();
    private readonly Dictionary<DateTime, string> fechasFormateadas = new();
    private readonly Dictionary<decimal, string> duracionesFormateadas = new();
    private readonly List<(MYGAsignacionExportacionProject Datos, object Objeto)> asignaciones = new();
    private object aplicacion, proyectoPropio;
    private object listaTareas, listaRecursos, listaAsignaciones;
    private int tareaAsignaciones;
    private bool instanciaPropia, confirmado, publicado;
    private string nombreCalendario, temporal, destino, respaldo;

    internal MYGAdaptadorProjectCom(Type tipoAplicacion) => this.tipoAplicacion = tipoAplicacion;

    public void Iniciar(MYGModeloExportacionProject modelo)
    {
        // Project sólo dispone de Shift1..Shift5. Nunca omitir silenciosamente
        // un turno que el calendario MYG sí admite.
        if (modelo.Calendario.Dias.Any(d => d.Tramos.Count > 5) ||
            modelo.Calendario.Excepciones.Any(e => e.Tramos.Count > 5))
            throw new InvalidOperationException("Microsoft Project admite un máximo de cinco turnos por día. Reduzca los turnos del calendario antes de exportar MPP.");
        if (ProcesosProject().Length != 0)
            throw new InvalidOperationException("Microsoft Project está abierto. Cierre sus ventanas antes de exportar MPP para proteger sus documentos abiertos.");
        aplicacion = Activator.CreateInstance(tipoAplicacion) ??
            throw new InvalidOperationException("Microsoft Project no creó una instancia de automatización.");
        // No se usa GetActiveObject ni se conecta la exportación a una ventana
        // del usuario. Si no se puede acreditar la instancia, no se la cierra.
        instanciaPropia = ProcesosProject().Length == 1 &&
            !Convert.ToBoolean(Leer(aplicacion, "Visible"), CultureInfo.InvariantCulture) && ContarProyectos() == 0;
        if (!instanciaPropia)
            throw new InvalidOperationException("No se pudo aislar una instancia privada de Microsoft Project. No se modificó ni cerró una sesión existente.");

        Escribir(aplicacion, "DisplayAlerts", false);
        Escribir(aplicacion, "ScreenUpdating", false);
        Escribir(aplicacion, "Calculation", 0); // pjManual
        ExigirExito(Llamar(aplicacion, "FileNew", new[] { "SummaryInfo", "FileNewDialog", "FileNewWorkpane" },
            false, false, false), "Microsoft Project no pudo crear un proyecto nuevo.");
        proyectoPropio = Leer(aplicacion, "ActiveProject");
        if (proyectoPropio == null || ContarProyectos() != 1)
            throw new InvalidOperationException("Microsoft Project no creó un proyecto independiente.");

        ExigirExito(Llamar(aplicacion, "OptionsSchedule",
            new[] { "AutoLink", "AutoSplit", "TaskType", "EffortDriven", "ShowEstimated", "NewTasksEstimated", "SetDefaults" },
            false, false, 1, false, false, false, false),
            "Microsoft Project no pudo configurar las opciones del cronograma.");
        // No heredar de Global.MPT reglas de seguimiento que muevan fechas al
        // importar avance. Sólo se cambia este proyecto y esta instancia privada.
        ExigirExito(Llamar(aplicacion, "OptionsCalculation",
            new[] { "Automatic", "AutoTrack", "SpreadPercentToStatusDate", "MoveCompleted", "AndMoveRemaining", "MoveRemaining", "AndMoveCompleted", "SetDefaults" },
            false, false, false, false, false, false, false, false),
            "Microsoft Project no pudo configurar el cálculo de la exportación.");

        Escribir(proyectoPropio, "ManuallyScheduledTasksAutoRespectLinks", false);
        Escribir(proyectoPropio, "HoursPerDay", modelo.MinutosPorDia / 60d);
        Escribir(proyectoPropio, "HoursPerWeek", modelo.MinutosPorSemana / 60d);
        Escribir(proyectoPropio, "NewTasksCreatedAsManual", true);
        var primerHorario = modelo.Calendario.Dias.Select(d => d.Tramos).FirstOrDefault(t => t.Count > 0);
        if (primerHorario != null)
        {
            Escribir(proyectoPropio, "DefaultStartTime", Hora(primerHorario[0].InicioMinuto));
            Escribir(proyectoPropio, "DefaultFinishTime", Hora(primerHorario[^1].FinMinuto));
        }
        if (!string.IsNullOrWhiteSpace(modelo.Moneda)) Escribir(proyectoPropio, "CurrencySymbol", modelo.Moneda);
        // Calendar.Name es de sólo lectura. La API oficial para crear y activar
        // un calendario es BaseCalendarCreate + ProjectSummaryInfo(Calendar).
        nombreCalendario = "MYG - " + (string.IsNullOrWhiteSpace(modelo.Calendario.Nombre) ? "Calendario" : modelo.Calendario.Nombre);
        ExigirExito(Llamar(aplicacion, "BaseCalendarCreate", new[] { "Name" }, nombreCalendario),
            "Microsoft Project no pudo crear el calendario de trabajo.");
        ExigirExito(Llamar(aplicacion, "ProjectSummaryInfo",
            new[] { "Title", "Start", "ScheduleFrom", "Calendar", "StatusDate" },
            modelo.Nombre, modelo.Inicio, 1, nombreCalendario, modelo.FechaEstado),
            "Microsoft Project no pudo configurar el calendario y las fechas del proyecto."); // pjProjectStart=1
        ConfigurarCalendario(modelo.Calendario);
    }

    private void ConfigurarCalendario(MYGCalendarioExportacionProject datos)
    {
        object calendario = null, dias = null, excepciones = null;
        try
        {
            calendario = Leer(proyectoPropio, "Calendar");
            Llamar(calendario, "Reset", Array.Empty<string>());
            dias = Leer(calendario, "WeekDays");
            foreach (var dia in datos.Dias)
            {
                object actual = null;
                try
                {
                    actual = Leer(dias, "Item", (int)dia.Dia + 1); // pjSunday=1 .. pjSaturday=7
                    Escribir(actual, "Working", dia.Tramos.Count > 0);
                    ConfigurarTurnos(actual, dia.Tramos);
                }
                finally { Liberar(actual); }
            }
            excepciones = Leer(calendario, "Exceptions");
            // Global.MPT puede contener fiestas personalizadas. El calendario
            // exportado debe contener exclusivamente las excepciones de MYG.
            for (int i = Convert.ToInt32(Leer(excepciones, "Count"), CultureInfo.InvariantCulture); i > 0; i--)
            {
                object heredada = null;
                try
                {
                    heredada = Leer(excepciones, "Item", i);
                    Llamar(heredada, "Delete", Array.Empty<string>());
                }
                finally { Liberar(heredada); }
            }
            for (int i = 0; i < datos.Excepciones.Count; i++)
            {
                var excepcion = datos.Excepciones[i];
                object actual = null;
                try
                {
                    actual = Llamar(excepciones, "Add", new[] { "Type", "Start", "Finish", "Name", "Period" },
                        1, excepcion.Inicio.Date, excepcion.Fin.Date, "MYG " + (i + 1).ToString(CultureInfo.InvariantCulture), 1); // pjDaily=1
                    // Exception no tiene Working: los cinco turnos vacíos
                    // representan una excepción no laborable.
                    ConfigurarTurnos(actual, excepcion.Tramos);
                }
                finally { Liberar(actual); }
            }
        }
        finally { Liberar(excepciones); Liberar(dias); Liberar(calendario); }
    }

    private static void ConfigurarTurnos(object dia, IReadOnlyList<MYGTramoExportacionProject> tramos)
    {
        for (int i = 0; i < 5; i++)
        {
            object turno = null;
            try
            {
                turno = Leer(dia, "Shift" + (i + 1).ToString(CultureInfo.InvariantCulture));
                if (i >= tramos.Count) Llamar(turno, "Clear", Array.Empty<string>());
                else
                {
                    Escribir(turno, "Start", Hora(tramos[i].InicioMinuto));
                    Escribir(turno, "Finish", Hora(tramos[i].FinMinuto));
                }
            }
            finally { Liberar(turno); }
        }
    }

    // Una fecha OLE y valores numéricos evitan interpretar horas/unidades con
    // sufijos dependientes del idioma de Office o de la configuración regional.
    private static DateTime Hora(int minuto) => new DateTime(1899, 12, 30).AddMinutes(minuto);

    public void CrearRecurso(MYGRecursoExportacionProject datos)
    {
        object recurso = null;
        try
        {
            listaRecursos ??= Leer(proyectoPropio, "Resources");
            recurso = Llamar(listaRecursos, "Add", new[] { "Name" }, datos.Nombre);
            MYGConfiguracionRecursoProject.Configurar(datos, nombreCalendario,
                campo => Leer(recurso, campo), (campo, valor) => Escribir(recurso, campo, valor));
            idsRecursos.Add(datos.Uid, Convert.ToInt32(Leer(recurso, "ID"), CultureInfo.InvariantCulture));
            tiposRecursos.Add(datos.Uid, datos.Tipo);
        }
        finally { Liberar(recurso); }
    }

    public void CrearTarea(MYGTareaExportacionProject datos)
    {
        object tarea = null;
        try
        {
            LiberarListaAsignaciones();
            listaTareas ??= Leer(proyectoPropio, "Tasks");
            tarea = Llamar(listaTareas, "Add", new[] { "Name" }, datos.Nombre);
            // Los padres preceden a sus hijos en la instantánea; OutlineLevel
            // es de lectura/escritura y genera las tareas resumen reales.
            Escribir(tarea, "OutlineLevel", datos.Nivel);
            Escribir(tarea, "Manual", datos.Resumen ? false : datos.Manual);
            if (!string.IsNullOrWhiteSpace(datos.Codigo)) Escribir(tarea, "WBS", datos.Codigo);
            if (!string.IsNullOrWhiteSpace(datos.Notas)) Escribir(tarea, "Notes", datos.Notas);
            if (!datos.Resumen)
            {
                Escribir(tarea, "Type", 1); // pjFixedDuration
                Escribir(tarea, "EffortDriven", false);
                Escribir(tarea, "Estimated", false);
                Escribir(tarea, "Calendar", nombreCalendario);
                Escribir(tarea, "Milestone", datos.Hito);
                if (datos.Manual)
                {
                    var texto = new MYGTextoTareaManualProject(FormatearFecha(datos.Inicio),
                        FormatearFecha(datos.Fin), FormatearDuracion(datos.DuracionMinutos));
                    textosManuales.Add(datos.Uid, texto);
                    MYGConfiguracionTareaManualProject.Restaurar(texto,
                        campo => Leer(tarea, campo), (campo, valor) => Escribir(tarea, campo, valor));
                }
                else
                {
                    Escribir(tarea, "Duration", (double)datos.DuracionMinutos);
                    Escribir(tarea, "Start", datos.Inicio);
                }
            }
            tareas.Add(datos.Uid, tarea);
            tarea = null;
        }
        finally { Liberar(tarea); }
    }

    public void AsignarRecurso(MYGAsignacionExportacionProject datos)
    {
        object asignacion = null;
        try
        {
            if (listaAsignaciones == null || tareaAsignaciones != datos.TareaUid)
            {
                LiberarListaAsignaciones();
                listaAsignaciones = Leer(tareas[datos.TareaUid], "Assignments");
                tareaAsignaciones = datos.TareaUid;
            }
            int idRecurso = idsRecursos[datos.RecursoUid];
            asignacion = datos.Unidades.HasValue
                ? Llamar(listaAsignaciones, "Add", new[] { "ResourceID", "Units" }, idRecurso, (double)datos.Unidades.Value)
                : Llamar(listaAsignaciones, "Add", new[] { "ResourceID" }, idRecurso);
            if (tiposRecursos[datos.RecursoUid] == 1 && datos.TrabajoHoras.HasValue)
                Escribir(asignacion, "Work", (double)(datos.TrabajoHoras.Value * 60m));
            // El coste de trabajo/material lo determina cantidad × tarifa. Los
            // recursos de costo no tienen tarifa y reciben su importe real.
            if (tiposRecursos[datos.RecursoUid] == 2) Escribir(asignacion, "Cost", (double)datos.Costo);
            asignaciones.Add((datos, asignacion));
            asignacion = null;
        }
        finally { Liberar(asignacion); }
    }

    public void CrearDependencia(MYGDependenciaExportacionProject datos)
    {
        object lista = null, dependencia = null;
        try
        {
            lista = Leer(tareas[datos.TareaUid], "TaskDependencies");
            dependencia = MYGConfiguracionDependenciaProject.Ejecutar(datos, tareas[datos.PredecesoraUid], argumentos =>
            {
                // From debe viajar como IDispatch de la tarea, no como un ID
                // ni como VT_UNKNOWN. Los opcionales se enlazan por posición.
                argumentos[0] = new DispatchWrapper(argumentos[0]);
                return LlamarPosicional(lista, "Add", argumentos);
            });
        }
        catch (Exception ex) when (ex is COMException || ex is TargetInvocationException)
        {
            Exception causa = ex.GetBaseException();
            throw new InvalidOperationException("Microsoft Project rechazó el vínculo de la tarea " +
                datos.PredecesoraUid + " a la tarea " + datos.TareaUid + " (" + datos.Tipo +
                ", desfase " + datos.DesfaseMinutos.ToString(CultureInfo.InvariantCulture) + " minutos): " + causa.Message, causa);
        }
        finally { Liberar(dependencia); Liberar(lista); }
    }

    public void FinalizarDatos(MYGModeloExportacionProject modelo)
    {
        ExigirProyectoPropioActivo();
        LiberarListaAsignaciones();
        // Recursos y dependencias ya están creados. Fijar las duraciones evita
        // que las unidades de asignación cambien las fechas importadas.
        foreach (var datos in modelo.Tareas.Where(t => !t.Resumen))
        {
            object tarea = tareas[datos.Uid];
            // El modo, tipo y esfuerzo ya se fijaron al crear la tarea. Volver
            // a escribirlos por fila provoca trabajo innecesario en Project.
            if (datos.Avance != 0)
                Escribir(tarea, "PercentComplete", decimal.ToInt32(decimal.Round(datos.Avance, MidpointRounding.AwayFromZero)));
            // Evitar reescribir un valor ya idéntico: incluso una asignación
            // numéricamente equivalente puede provocar un recálculo de Work.
            if (!datos.Manual && !NumeroIgual(Leer(tarea, "Duration"), datos.DuracionMinutos, 0.01m))
                Escribir(tarea, "Duration", (double)datos.DuracionMinutos);
            if (!datos.Manual && !FechaIgual(Leer(tarea, "Start"), datos.Inicio)) Escribir(tarea, "Start", datos.Inicio);
            if (!datos.Manual && modelo.TramosPorTarea.TryGetValue(datos.Uid, out var tramos) && tramos.Count > 1)
            {
                // Una tarea automática puede contener trabajo separado (por
                // ejemplo movilización y desmovilización). Exportar sus pausas,
                // sin extender dos días de trabajo por todo el intervalo.
                DateTime finTramo = tramos[0].Fin;
                foreach (var tramo in tramos.Skip(1))
                {
                    if (tramo.Inicio > finTramo)
                        Llamar(tarea, "Split", new[] { "StartSplitOn", "EndSplitOn" }, finTramo, tramo.Inicio);
                    if (tramo.Fin > finTramo) finTramo = tramo.Fin;
                }
            }
        }
        // El cálculo se ejecuta una sola vez después de que existan todos los
        // vínculos. Las tareas manuales conservan sus extremos independientes.
        ExigirExito(Llamar(aplicacion, "CalculateProject", Array.Empty<string>()),
            "Microsoft Project no pudo calcular el proyecto exportado.");
        foreach (var datos in modelo.Tareas)
        {
            object tarea = tareas[datos.Uid];
            if (datos.InicioBase.HasValue) Escribir(tarea, "BaselineStart", datos.InicioBase.Value);
            if (datos.FinBase.HasValue) Escribir(tarea, "BaselineFinish", datos.FinBase.Value);
            if (datos.DuracionBaseMinutos.HasValue) Escribir(tarea, "BaselineDuration", (double)datos.DuracionBaseMinutos.Value);
        }
        Escribir(proyectoPropio, "NewTasksCreatedAsManual", false);
        Escribir(aplicacion, "Calculation", -1); // pjAutomatic; sólo la instancia propia
        // El último cálculo y el avance pueden actualizar campos de programación.
        // Restaurar y comprobar los campos manuales que Project muestra al usuario,
        // sin exigir que su duración sea el intervalo calculado entre los extremos.
        foreach (var datos in modelo.Tareas.Where(t => !t.Resumen && t.Manual))
        {
            object tarea = tareas[datos.Uid];
            MYGConfiguracionTareaManualProject.Restaurar(textosManuales[datos.Uid],
                campo => Leer(tarea, campo), (campo, valor) => Escribir(tarea, campo, valor));
        }
        VerificarDatos(modelo);
    }

    private void VerificarDatos(MYGModeloExportacionProject modelo)
    {
        foreach (var datos in modelo.Tareas.Where(t => !t.Resumen && !t.Manual))
        {
            object tarea = tareas[datos.Uid];
            var inicio = Leer(tarea, "Start");
            var fin = Leer(tarea, "Finish");
            var duracion = Leer(tarea, "Duration");
            if (Convert.ToBoolean(Leer(tarea, "Manual"), CultureInfo.InvariantCulture) ||
                !FechaIgual(inicio, datos.Inicio) || !FechaIgual(fin, datos.Fin) ||
                !NumeroIgual(duracion, datos.DuracionMinutos, 0.01m))
                throw new InvalidOperationException("Microsoft Project cambió la programación de la tarea automática «" + datos.Nombre +
                    "». Inicio esperado: " + datos.Inicio.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) +
                    "; recibido: " + inicio + ". Fin esperado: " + datos.Fin.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) +
                    "; recibido: " + fin + ". Duración esperada (min): " + datos.DuracionMinutos +
                    "; recibida: " + duracion + ". No se reemplazó el archivo de destino.");
        }
        foreach (var datos in modelo.Tareas.Where(t => !t.Resumen && t.Manual))
        {
            object tarea = tareas[datos.Uid];
            MYGConfiguracionTareaManualProject.Verificar(datos, textosManuales[datos.Uid], campo => Leer(tarea, campo),
                texto => Llamar(aplicacion, "DurationValue", new[] { "Duration" }, texto));
        }
        foreach (var item in asignaciones)
        {
            int tipo = tiposRecursos[item.Datos.RecursoUid];
            bool correcto = tipo switch
            {
                1 when item.Datos.TrabajoHoras.HasValue => NumeroIgual(Leer(item.Objeto, "Work"), item.Datos.TrabajoHoras.Value * 60m, 0.01m),
                0 when item.Datos.Unidades.HasValue => NumeroIgual(Leer(item.Objeto, "Units"), item.Datos.Unidades.Value, 0.000001m),
                2 => NumeroIgual(Leer(item.Objeto, "Cost"), item.Datos.Costo, 0.02m),
                _ => true
            };
            if (!correcto)
                throw new InvalidOperationException("Microsoft Project cambió el trabajo, cantidad o costo de una asignación en «" +
                    modelo.Tareas.First(t => t.Uid == item.Datos.TareaUid).Nombre + "». No se reemplazó el archivo de destino.");
        }
    }

    private static bool FechaIgual(object valor, DateTime esperado) =>
        Math.Abs((Convert.ToDateTime(valor, CultureInfo.InvariantCulture) - esperado).TotalSeconds) < 1;

    private static bool NumeroIgual(object valor, decimal esperado, decimal tolerancia) =>
        Math.Abs(Convert.ToDecimal(valor, CultureInfo.InvariantCulture) - esperado) <= tolerancia;

    private string FormatearFecha(DateTime fecha)
    {
        if (!fechasFormateadas.TryGetValue(fecha, out string texto))
        {
            // pjDate_mmmm_dd_yyyy_hh_mmAM = 2: año completo y hora; Project
            // proporciona su propio idioma, sin adivinar el de Office desde .NET.
            texto = Convert.ToString(Llamar(aplicacion, "DateFormat", new[] { "Date", "Format" }, fecha, 2), CultureInfo.InvariantCulture);
            if (string.IsNullOrWhiteSpace(texto))
                throw new InvalidOperationException("Microsoft Project no pudo representar una fecha del cronograma.");
            fechasFormateadas.Add(fecha, texto);
        }
        return texto;
    }

    private string FormatearDuracion(decimal minutos)
    {
        if (!duracionesFormateadas.TryGetValue(minutos, out string texto))
        {
            texto = Convert.ToString(Llamar(aplicacion, "DurationFormat", new[] { "Duration", "Units" }, (double)minutos, 3), CultureInfo.InvariantCulture); // pjMinutes
            if (string.IsNullOrWhiteSpace(texto) ||
                !NumeroIgual(Llamar(aplicacion, "DurationValue", new[] { "Duration" }, texto), minutos, 0.01m))
                throw new InvalidOperationException("Microsoft Project no pudo representar la duración del cronograma sin perder precisión.");
            duracionesFormateadas.Add(minutos, texto);
        }
        return texto;
    }

    public void GuardarResultado(string ruta)
    {
        ExigirProyectoPropioActivo();
        destino = Path.GetFullPath(ruta);
        MYGExportacionCronogramaWindows.ComprobarDestinoLibre(destino, sqlite: false);
        Directory.CreateDirectory(Path.GetDirectoryName(destino));
        temporal = MYGExportacionCronogramaWindows.TemporalJuntoA(destino, ".mpp");
        ExigirExito(Llamar(aplicacion, "FileSaveAs",
            new[] { "Name", "Format", "FormatID", "Backup", "ReadOnly" },
            temporal, 0, "MSProject.mpp", false, false), "Microsoft Project no pudo guardar el archivo MPP.");
        LiberarElementos();
        CerrarProyectoPropio();
        MYGExportacionCronogramaWindows.VerificarContenedorMpp(temporal);
        MYGExportacionCronogramaWindows.ComprobarDestinoLibre(destino, sqlite: false);
        if (File.Exists(destino))
        {
            respaldo = MYGExportacionCronogramaWindows.TemporalJuntoA(destino, ".respaldo");
            File.Replace(temporal, destino, respaldo);
        }
        else File.Move(temporal, destino);
        publicado = true;
    }

    public void MostrarResultado()
    {
        if (ContarProyectos() != 0)
            throw new InvalidOperationException("Microsoft Project abrió otra ventana durante la exportación. No se modificó ese documento.");
        // FileOpenEx aquí abre EXCLUSIVAMENTE el MPP binario recién guardado.
        // No se usa como importador, no intervienen XML ni mapas de recursos.
        ExigirExito(Llamar(aplicacion, "FileOpenEx",
            new[] { "Name", "ReadOnly", "Merge", "NoAuto", "FormatID", "DoNotLoadFromEnterprise" },
            destino, false, 0, true, "MSProject.mpp", true), "Microsoft Project no pudo abrir el archivo MPP exportado.");
        proyectoPropio = Leer(aplicacion, "ActiveProject");
        if (proyectoPropio == null || ContarProyectos() != 1)
            throw new InvalidOperationException("Microsoft Project no abrió el archivo MPP exportado como proyecto independiente.");
        Escribir(aplicacion, "ScreenUpdating", true);
        Escribir(aplicacion, "DisplayAlerts", true);
        Escribir(aplicacion, "Visible", true);
        Escribir(aplicacion, "UserControl", true);
    }

    public void ConfirmarResultado()
    {
        confirmado = true;
        Borrar(respaldo);
        respaldo = null;
    }

    public void Dispose()
    {
        // Tras el éxito Project queda bajo el control del usuario, con el MPP
        // final abierto. Sólo se liberan referencias de automatización.
        if (!confirmado && instanciaPropia && aplicacion != null)
        {
            try { CerrarProyectoPropio(); } catch { }
            try
            {
                if (ContarProyectos() == 0) Llamar(aplicacion, "Quit", new[] { "SaveChanges" }, 0);
            }
            catch { }
        }
        LiberarElementos();
        Liberar(proyectoPropio); proyectoPropio = null;
        Liberar(aplicacion); aplicacion = null;
        if (!confirmado && publicado)
        {
            // Si la apertura final falla se conserva el destino anterior. No
            // publicar un resultado incompleto al usuario como si fuera éxito.
            if (respaldo != null && File.Exists(respaldo))
            {
                try { File.Move(respaldo, destino, true); respaldo = null; }
                catch (IOException) { } // conservar el respaldo si sigue bloqueado
                catch (UnauthorizedAccessException) { }
            }
            else Borrar(destino);
        }
        Borrar(temporal);
        if (confirmado) Borrar(respaldo);
    }

    private void LiberarElementos()
    {
        LiberarListaAsignaciones();
        foreach (var asignacion in asignaciones) Liberar(asignacion.Objeto);
        asignaciones.Clear();
        foreach (object tarea in tareas.Values) Liberar(tarea);
        tareas.Clear();
        Liberar(listaTareas); listaTareas = null;
        Liberar(listaRecursos); listaRecursos = null;
        idsRecursos.Clear();
        tiposRecursos.Clear();
        textosManuales.Clear();
        fechasFormateadas.Clear();
        duracionesFormateadas.Clear();
    }

    private void LiberarListaAsignaciones()
    {
        Liberar(listaAsignaciones); listaAsignaciones = null;
        tareaAsignaciones = 0;
    }

    private int ContarProyectos()
    {
        object proyectos = null;
        try
        {
            proyectos = Leer(aplicacion, "Projects");
            return Convert.ToInt32(Leer(proyectos, "Count"), CultureInfo.InvariantCulture);
        }
        finally { Liberar(proyectos); }
    }

    private void ExigirProyectoPropioActivo()
    {
        object activo = null;
        IntPtr identidadPropio = IntPtr.Zero, identidadActivo = IntPtr.Zero;
        try
        {
            if (proyectoPropio == null || ContarProyectos() != 1)
                throw new InvalidOperationException("Cambió la sesión de Microsoft Project durante la exportación. No se modificará ni guardará otro proyecto.");
            activo = Leer(aplicacion, "ActiveProject");
            if (activo == null)
                throw new InvalidOperationException("Microsoft Project ya no tiene activo el proyecto de la exportación.");
            identidadPropio = Marshal.GetIUnknownForObject(proyectoPropio);
            identidadActivo = Marshal.GetIUnknownForObject(activo);
            if (identidadPropio != identidadActivo)
                throw new InvalidOperationException("Microsoft Project cambió el proyecto activo. No se modificará ni guardará otro documento.");
        }
        finally
        {
            if (identidadPropio != IntPtr.Zero) Marshal.Release(identidadPropio);
            if (identidadActivo != IntPtr.Zero) Marshal.Release(identidadActivo);
            Liberar(activo);
        }
    }

    private void CerrarProyectoPropio()
    {
        if (proyectoPropio == null || ContarProyectos() == 0) return;
        object activo = null;
        IntPtr identidadPropio = IntPtr.Zero, identidadActivo = IntPtr.Zero;
        bool cerrado = false;
        try
        {
            activo = Leer(aplicacion, "ActiveProject");
            if (activo == null) return;
            identidadPropio = Marshal.GetIUnknownForObject(proyectoPropio);
            identidadActivo = Marshal.GetIUnknownForObject(activo);
            if (identidadPropio == identidadActivo)
            {
                ExigirExito(Llamar(aplicacion, "FileCloseEx", new[] { "Save", "NoAuto" }, 0, true),
                    "Microsoft Project no pudo cerrar el proyecto temporal de la exportación.");
                cerrado = true;
            }
        }
        finally
        {
            if (identidadPropio != IntPtr.Zero) Marshal.Release(identidadPropio);
            if (identidadActivo != IntPtr.Zero) Marshal.Release(identidadActivo);
            Liberar(activo);
            if (cerrado) { Liberar(proyectoPropio); proyectoPropio = null; }
        }
    }

    private static int[] ProcesosProject()
    {
        var procesos = Process.GetProcessesByName("WINPROJ");
        try { return procesos.Select(p => p.Id).ToArray(); }
        finally { foreach (var proceso in procesos) proceso.Dispose(); }
    }

    private static object Leer(object objeto, string nombre, params object[] indices) => objeto.GetType().InvokeMember(nombre,
        BindingFlags.GetProperty | BindingFlags.Instance | BindingFlags.Public, null, objeto, indices, CultureInfo.InvariantCulture);

    private static void Escribir(object objeto, string nombre, object valor) => objeto.GetType().InvokeMember(nombre,
        BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.Public, null, objeto, new[] { valor }, CultureInfo.InvariantCulture);

    private static object Llamar(object objeto, string nombre, string[] nombres, params object[] valores) =>
        objeto.GetType().InvokeMember(nombre, BindingFlags.InvokeMethod | BindingFlags.Instance | BindingFlags.Public,
            null, objeto, valores, null, CultureInfo.InvariantCulture, nombres);

    private static object LlamarPosicional(object objeto, string nombre, object[] valores) =>
        objeto.GetType().InvokeMember(nombre,
            BindingFlags.InvokeMethod | BindingFlags.OptionalParamBinding | BindingFlags.Instance | BindingFlags.Public,
            null, objeto, valores, CultureInfo.InvariantCulture);

    private static void ExigirExito(object resultado, string mensaje)
    {
        if (resultado is not bool correcto || !correcto) throw new InvalidOperationException(mensaje);
    }

    private static void Liberar(object objeto)
    {
        if (objeto == null || !Marshal.IsComObject(objeto)) return;
        try { Marshal.ReleaseComObject(objeto); } catch (InvalidComObjectException) { }
    }

    private static void Borrar(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta)) return;
        try { if (File.Exists(ruta)) File.Delete(ruta); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }
}
