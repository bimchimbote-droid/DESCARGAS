using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class CursoresMetradoCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Cursores de metrado", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            var partida = new ItemPresupuestoDelphin
            {
                Id = MYGProyectoStorage.NuevoId(), Item = "01", Descripcion = "CONCRETO",
                Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
                Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
            };
            presupuesto.Items.Add(partida);
            PrepararDatos(partida.Costos.Hoja);
            int anteriores = 0, cambios = 0, guardados = 0, deshacer = 0, rehacer = 0;
            var historial = new Stack<MYGHojaMetrado>();
            var futuros = new Stack<MYGHojaMetrado>();
            MYGPanelPresupuesto panel = null;
            using var panelReal = panel = new MYGPanelPresupuesto(() => presupuesto,
                () => { anteriores++; historial.Push(MYGProyectoStorage.Copia(partida.Costos.Hoja)); futuros.Clear(); },
                () => cambios++, _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++,
                () =>
                {
                    deshacer++;
                    futuros.Push(MYGProyectoStorage.Copia(partida.Costos.Hoja));
                    partida.Costos.Hoja = historial.Pop(); panel.Refrescar();
                },
                () =>
                {
                    rehacer++;
                    historial.Push(MYGProyectoStorage.Copia(partida.Costos.Hoja));
                    partida.Costos.Hoja = futuros.Pop(); panel.Refrescar();
                });
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
                () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1800, 1000) };
            formulario.Controls.Add(panel);
            formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
            var pagina = Campo<TabPage>(panel, "paginaExcel");
            ((TabControl)pagina.Parent).SelectedTab = pagina;
            Application.DoEvents();
            var hoja = Campo<DataGridView>(panel, "hoja");
            var formula = Campo<TextBox>(panel, "formula");

            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos(); Application.DoEvents();
                VerificarHover(panel, hoja, formula, partida,
                    () => (anteriores, cambios, guardados), exige);
            }

            VerificarRelleno(panel, hoja, partida, () => (anteriores, cambios, guardados), exige);
            VerificarMovimiento(panel, hoja, partida, () => (anteriores, cambios, guardados), exige);
            VerificarSeries(panel, hoja, partida, () => (anteriores, cambios, guardados), exige);
            VerificarTotalMovido(panel, presupuesto, partida, () => (anteriores, cambios, guardados), exige);
            exige(deshacer >= 2 && rehacer >= 1 && guardados == 0,
                "El arrastre debe utilizar el historial del proyecto y nunca guardar automáticamente el metrado.");
            formulario.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void PrepararDatos(MYGHojaMetrado modelo)
    {
        modelo.Poner("B3", "3"); modelo.Poner("B5", "5"); modelo.Poner("B6", "6"); modelo.Poner("B7", "7");
        modelo.Poner("D5", "=B5+$B$3", true);
        modelo.Celdas["D5"].ColorFondo = "C6EFCE";
        modelo.Celdas["D5"].FormatoNumero = "0.00";
        modelo.Poner("I20", "=SUM(D5:D7)");
        modelo.Poner("F5", "2"); modelo.Poner("F6", "4");
    }

    private static void VerificarHover(MYGPanelPresupuesto panel, DataGridView hoja, TextBox formula,
        ItemPresupuestoDelphin partida, Func<(int Antes, int Cambios, int Guardados)> contadores,
        Action<bool, string> exige)
    {
        Seleccionar(hoja, "D5");
        string original = Estado(partida.Costos.Hoja);
        var contadoresAntes = contadores();
        var seleccion = Seleccion(hoja);
        object proveedor = Campo<object>(panel, "cursoresHoja");
        Cursor cursorSeleccion = Propiedad<Cursor>(proveedor, "Seleccion");
        Cursor cursorRelleno = Propiedad<Cursor>(proveedor, "Relleno");
        Cursor cursorColumna = Propiedad<Cursor>(proveedor, "Columna");
        Cursor cursorFila = Propiedad<Cursor>(proveedor, "Fila");
        Cursor cursorMovimiento = Propiedad<Cursor>(proveedor, "Movimiento");
        exige(new[] { cursorSeleccion, cursorRelleno, cursorColumna, cursorFila, cursorMovimiento }.Select(c => c.Handle).Distinct().Count() == 5,
            "Seleccionar celdas, rellenar, seleccionar columnas, filas y mover deben tener cinco cursores diferentes.");
        exige(CentroCursor(cursorSeleccion).GetBrightness() > .8f && CentroCursor(cursorRelleno).GetBrightness() < .2f,
            "La cruz de selección debe tener centro blanco y la cruz pequeña de relleno debe tener centro negro.");
        VerificarAspectoCursores(cursorSeleccion, cursorColumna, cursorFila, cursorMovimiento, exige);

        VerificarCursor(hoja, Centro(Celda(hoja, "E6")), cursorSeleccion,
            "El interior de las celdas debe mostrar la cruz de selección de Excel.", exige);
        Rectangle columna = hoja.GetCellDisplayRectangle(2, -1, false);
        VerificarCursor(hoja, Centro(columna), cursorColumna,
            "El centro de una letra de columna debe mostrar la flecha que selecciona la columna.", exige);
        Rectangle fila = hoja.GetCellDisplayRectangle(-1, 5, false);
        VerificarCursor(hoja, Centro(fila), cursorFila,
            "El centro de un número de fila debe mostrar la flecha que selecciona la fila.", exige);
        VerificarCursor(hoja, new Point(columna.Right - 1, Centro(columna).Y), Cursors.SizeWE,
            "El separador de las letras de columnas debe mostrar el cursor para ajustar su ancho.", exige);
        VerificarCursor(hoja, new Point(Centro(fila).X, fila.Bottom - 1), Cursors.SizeNS,
            "El separador de los números de filas debe mostrar el cursor para ajustar su altura.", exige);

        Rectangle activa = Celda(hoja, "D5");
        VerificarCursor(hoja, new Point(activa.Left + 1, Centro(activa).Y), cursorMovimiento,
            "El borde de una selección debe mostrar el cursor para mover sus celdas.", exige);
        Rectangle tirador = Invocar<Rectangle>(panel, "TiradorRellenoHoja");
        exige(!tirador.IsEmpty && hoja.ClientRectangle.Contains(tirador),
            "La selección rectangular visible debe ofrecer un tirador de relleno en su esquina inferior derecha.");
        VerificarCursor(hoja, Centro(tirador), cursorRelleno,
            "La esquina inferior derecha de la selección debe mostrar la cruz pequeña de relleno.", exige);
        exige(Estado(partida.Costos.Hoja) == original && contadores() == contadoresAntes && seleccion.SetEquals(Seleccion(hoja)),
            "Recorrer las celdas, cabeceras, separadores y tiradores debe conservar datos, fórmulas, estilos, selección e historial.");

        Pulsar(hoja, Centro(columna));
        exige(hoja.SelectedCells.Count == partida.Costos.Hoja.Filas &&
            hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.ColumnIndex == 2),
            "La flecha de columna debe acompañar un clic real que selecciona toda la columna.");
        Pulsar(hoja, Centro(fila));
        exige(hoja.SelectedCells.Count == partida.Costos.Hoja.Columnas &&
            hoja.SelectedCells.Cast<DataGridViewCell>().All(c => c.RowIndex == 5),
            "La flecha de fila debe acompañar un clic real que selecciona toda la fila.");
        exige(Estado(partida.Costos.Hoja) == original && contadores() == contadoresAntes,
            "Seleccionar una fila o columna mediante el ratón debe conservar la hoja y no crear historial.");
        Seleccionar(hoja, "D5");

        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is TextBox,
            "La comprobación del cursor de escritura debe abrir el editor real de la celda.");
        var editor = (TextBox)hoja.EditingControl;
        Mover(editor, new Point(Math.Min(12, editor.Width - 1), editor.Height / 2));
        exige(editor.Cursor.Handle == Cursors.IBeam.Handle,
            "El texto de una celda en edición debe conservar el cursor de escritura.");
        editor.Text = "Borrador que debe cancelarse";
        typeof(DataGridView).GetMethod("ProcessEscapeKey", Privados).Invoke(hoja, new object[] { Keys.Escape });
        Application.DoEvents();
        Mover(formula, new Point(12, formula.Height / 2));
        exige(formula.Cursor.Handle == Cursors.IBeam.Handle,
            "La barra de fórmulas debe conservar el cursor de escritura.");
        exige(Estado(partida.Costos.Hoja) == original && contadores() == contadoresAntes,
            "Cancelar la escritura después de comprobar los cursores no debe confirmar el borrador ni modificar el metrado.");
    }

    private static void VerificarRelleno(MYGPanelPresupuesto panel, DataGridView hoja,
        ItemPresupuestoDelphin partida, Func<(int Antes, int Cambios, int Guardados)> contadores,
        Action<bool, string> exige)
    {
        Seleccionar(hoja, "D5");
        string original = Estado(partida.Costos.Hoja);
        var antes = contadores();
        Point tirador = Centro(Invocar<Rectangle>(panel, "TiradorRellenoHoja"));
        Arrastrar(hoja, tirador, Centro(Celda(hoja, "D7")));
        var modelo = partida.Costos.Hoja;
        exige(Contenido(modelo, "D5") == "=B5+$B$3" && Contenido(modelo, "D6") == "=B6+$B$3" &&
            Contenido(modelo, "D7") == "=B7+$B$3" && new MYGHojaCalculo(modelo).Numero("D7") == 10m,
            "Arrastrar el tirador hasta D7 debe copiar la fórmula y trasladar sus referencias relativas conservando la referencia absoluta.");
        exige(new[] { "D6", "D7" }.All(d => modelo.Celdas[d].Negrita && modelo.Celdas[d].ColorFondo == "C6EFCE" &&
            modelo.Celdas[d].FormatoNumero == "0.00"),
            "El relleno por arrastre debe conservar el formato de las celdas de origen.");
        exige(contadores() == (antes.Antes + 1, antes.Cambios + 1, antes.Guardados),
            "Un arrastre de relleno debe registrar una sola modificación y un solo punto de historial.");
        string rellenado = Estado(modelo);
        Comando(panel, "deshacer");
        exige(Estado(partida.Costos.Hoja) == original,
            "Deshacer debe restaurar toda la hoja anterior al arrastre, incluidas fórmulas y formatos.");
        Comando(panel, "rehacer");
        exige(Estado(partida.Costos.Hoja) == rellenado,
            "Rehacer debe restaurar exactamente el relleno por arrastre.");

        Seleccionar(hoja, "D5");
        antes = contadores(); original = Estado(partida.Costos.Hoja);
        IniciarArrastre(hoja, Centro(Invocar<Rectangle>(panel, "TiradorRellenoHoja")), Centro(Celda(hoja, "D9")));
        EnviarMensaje(hoja.Handle, 0x0100, new IntPtr((int)Keys.Escape), IntPtr.Zero);
        EnviarMouse(hoja, 0x0202, Centro(Celda(hoja, "D9")), false);
        exige(Estado(partida.Costos.Hoja) == original && contadores() == antes && !hoja.Capture,
            "Escape durante el relleno debe cancelar la operación sin escribir celdas, crear historial ni dejar capturado el ratón.");

        Seleccionar(hoja, "D5");
        IniciarArrastre(hoja, Centro(Invocar<Rectangle>(panel, "TiradorRellenoHoja")), Centro(Celda(hoja, "D9")));
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        var detalle = (TabControl)pagina.Parent;
        detalle.SelectedTab = detalle.TabPages.Cast<TabPage>().First(p => p != pagina);
        Application.DoEvents();
        EnviarMouse(hoja, 0x0202, Centro(Celda(hoja, "D9")), false);
        detalle.SelectedTab = pagina; Application.DoEvents();
        exige(Estado(partida.Costos.Hoja) == original && contadores() == antes && !hoja.Capture,
            "Cambiar de pestaña durante un arrastre debe cancelarlo sin dejar una operación pendiente ni modificar celdas ocultas.");
    }

    private static void VerificarMovimiento(MYGPanelPresupuesto panel, DataGridView hoja,
        ItemPresupuestoDelphin partida, Func<(int Antes, int Cambios, int Guardados)> contadores,
        Action<bool, string> exige)
    {
        Seleccionar(hoja, "D5", "D7");
        string original = Estado(partida.Costos.Hoja);
        var antes = contadores();
        bool rechazado = false;
        try { Invocar<object>(panel, "AplicarArrastreHoja", "D5:D7", "E9:E11", false); }
        catch (System.IO.InvalidDataException) { rechazado = true; }
        exige(rechazado && Estado(partida.Costos.Hoja) == original && contadores() == antes,
            "Mover sólo una parte de las dimensiones de PRODUCT(B5:F5) debe rechazarse antes de crear historial y conservar íntegra la hoja.");

        // Este escenario usa fórmulas propias: retirar sólo las tres fórmulas
        // de la plantilla que contienen parcialmente el bloque de origen.
        foreach (string dir in new[] { "G5", "G6", "G7" }) partida.Costos.Hoja.Celdas.Remove(dir);
        Invocar<object>(panel, "RecalcularHoja");
        Seleccionar(hoja, "D5", "D7");
        original = Estado(partida.Costos.Hoja);
        antes = contadores();
        Rectangle origen = Celda(hoja, "D5");
        Arrastrar(hoja, new Point(origen.Left + 1, Centro(origen).Y), Centro(Celda(hoja, "E9")));
        var modelo = partida.Costos.Hoja;
        exige(new[] { "D5", "D6", "D7" }.All(d => Contenido(modelo, d) == "") &&
            Contenido(modelo, "E9") == "=B5+$B$3" && Contenido(modelo, "E10") == "=B6+$B$3" &&
            Contenido(modelo, "E11") == "=B7+$B$3" && Contenido(modelo, "I20") == "=SUM(E9:E11)" &&
            new MYGHojaCalculo(modelo).Numero("I20") == 27m,
            "Mover D5:D7 debe vaciar el origen, conservar las referencias externas de las fórmulas y reubicar las referencias al bloque movido.");
        exige(modelo.Celdas["E9"].Negrita && modelo.Celdas["E9"].ColorFondo == "C6EFCE" &&
            modelo.Celdas["E9"].FormatoNumero == "0.00" &&
            contadores() == (antes.Antes + 1, antes.Cambios + 1, antes.Guardados),
            "Mover el borde debe trasladar también el formato y registrar una única modificación.");
        Comando(panel, "deshacer");
        exige(Estado(partida.Costos.Hoja) == original,
            "Deshacer el movimiento debe recuperar el origen, limpiar el destino y restaurar las referencias originales sin pérdida de datos.");
        antes = contadores();
        rechazado = false;
        try { Invocar<object>(panel, "AplicarArrastreHoja", "D5:D7", "F5:F7", false); }
        catch (System.IO.InvalidDataException) { rechazado = true; }
        exige(rechazado && Estado(partida.Costos.Hoja) == original && contadores() == antes,
            "Un destino ocupado debe rechazarse antes de crear historial y conservar intactos el origen, el destino, los estilos y las fórmulas.");
    }

    private static void VerificarSeries(MYGPanelPresupuesto panel, DataGridView hoja,
        ItemPresupuestoDelphin partida, Func<(int Antes, int Cambios, int Guardados)> contadores,
        Action<bool, string> exige)
    {
        Seleccionar(hoja, "F5", "F6");
        var antes = contadores();
        Arrastrar(hoja, Centro(Invocar<Rectangle>(panel, "TiradorRellenoHoja")), Centro(Celda(hoja, "F8")));
        exige(Contenido(partida.Costos.Hoja, "F7") == "6" && Contenido(partida.Costos.Hoja, "F8") == "8" &&
            contadores() == (antes.Antes + 1, antes.Cambios + 1, antes.Guardados),
            "El tirador debe continuar una serie numérica de dos valores y registrar el arrastre como una sola modificación.");
    }

    private static void VerificarTotalMovido(MYGPanelPresupuesto panel, MYGPresupuestoDocumento presupuesto,
        ItemPresupuestoDelphin partida, Func<(int Antes, int Cambios, int Guardados)> contadores,
        Action<bool, string> exige)
    {
        partida.Costos.Hoja.CeldaTotal = "I20";
        partida.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        panel.Refrescar(); Application.DoEvents();
        var total = Campo<TextBox>(panel, "celdaTotal");
        total.Text = "I20";
        var antes = contadores();
        Invocar<object>(panel, "AplicarArrastreHoja", "I20", "J20", false);
        Application.DoEvents();
        exige(partida.Costos.Hoja.CeldaTotal == "J20" && total.Text == "J20" &&
            Contenido(partida.Costos.Hoja, "I20") == "" && Contenido(partida.Costos.Hoja, "J20") == "=SUM(D5:D7)" &&
            MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 27m &&
            contadores() == (antes.Antes + 1, antes.Cambios + 1, antes.Guardados),
            "Mover la celda total debe trasladar su fórmula y actualizar tanto el modelo como la dirección visible, conservando el metrado Excel.");
        Invocar<object>(panel, "UsarTotalHoja");
        Application.DoEvents();
        exige(partida.Costos.Hoja.CeldaTotal == "J20" && total.Text == "J20" &&
            partida.Costos.FuenteMetrado == MYGFuenteMetrado.Excel && MYGMotorPresupuestos.Cantidad(presupuesto, partida) == 27m,
            "Usar el total después de moverlo debe conservar su dirección actual y su cantidad, sin volver a la celda vacía de origen.");
    }

    private static string Contenido(MYGHojaMetrado modelo, string direccion) =>
        new MYGHojaCalculo(modelo).Contenido(direccion);
    private static string Estado(MYGHojaMetrado modelo) => JsonSerializer.Serialize(modelo);
    private static HashSet<(int Fila, int Columna)> Seleccion(DataGridView hoja) =>
        hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex)).ToHashSet();
    private static Rectangle Celda(DataGridView hoja, string direccion)
    {
        var p = MYGHojaCalculo.Coordenadas(direccion);
        return hoja.GetCellDisplayRectangle(p.Columna - 1, p.Fila - 1, false);
    }
    private static Point Centro(Rectangle rectangulo) => new(rectangulo.Left + rectangulo.Width / 2,
        rectangulo.Top + rectangulo.Height / 2);
    private static Color CentroCursor(Cursor cursor)
    {
        using var imagen = ImagenCursor(cursor);
        return imagen.GetPixel(imagen.Width / 2, imagen.Height / 2);
    }

    private static Bitmap ImagenCursor(Cursor cursor)
    {
        var imagen = new Bitmap(cursor.Size.Width, cursor.Size.Height);
        using var g = Graphics.FromImage(imagen);
        g.Clear(Color.Magenta); cursor.Draw(g, new Rectangle(Point.Empty, imagen.Size));
        return imagen;
    }

    private static Rectangle LimitesCursor(Bitmap imagen)
    {
        int izquierda = imagen.Width, arriba = imagen.Height, derecha = -1, abajo = -1;
        for (int y = 0; y < imagen.Height; y++) for (int x = 0; x < imagen.Width; x++)
        {
            Color c = imagen.GetPixel(x, y);
            if (c.R == 255 && c.G == 0 && c.B == 255) continue;
            izquierda = Math.Min(izquierda, x); arriba = Math.Min(arriba, y);
            derecha = Math.Max(derecha, x); abajo = Math.Max(abajo, y);
        }
        return derecha < izquierda ? Rectangle.Empty : Rectangle.FromLTRB(izquierda, arriba, derecha + 1, abajo + 1);
    }

    private static void VerificarAspectoCursores(Cursor seleccion, Cursor columna, Cursor fila, Cursor movimiento,
        Action<bool, string> exige)
    {
        using var cruz = ImagenCursor(seleccion);
        int blancos = 0, negros = 0;
        for (int y = 0; y < cruz.Height; y++) for (int x = 0; x < cruz.Width; x++)
        {
            Color c = cruz.GetPixel(x, y);
            if (c.R == 255 && c.G == 255 && c.B == 255) blancos++;
            if (c.R == 0 && c.G == 0 && c.B == 0) negros++;
        }
        var limites = LimitesCursor(cruz);
        exige(blancos > 0 && negros > 0 &&
            limites.Width <= Math.Ceiling(cruz.Width * 17d / 32) && limites.Height <= Math.Ceiling(cruz.Height * 17d / 32),
            "La cruz de selección reducida debe conservar interior blanco, borde negro y dimensiones menores al cursor original.");
        foreach (var (cursor, vertical) in new[] { (columna, true), (fila, false) })
        {
            using var flecha = ImagenCursor(cursor);
            var borde = LimitesCursor(flecha);
            exige(!borde.IsEmpty && (vertical ? borde.Height : borde.Width) <=
                Math.Ceiling((vertical ? flecha.Height : flecha.Width) * 18d / 32),
                "Las flechas de selección de filas y columnas deben conservar su forma al reducirse al 70%.");
        }
        using var anterior = ImagenCursor(Cursors.SizeAll);
        using var nuevo = ImagenCursor(movimiento);
        var antes = LimitesCursor(anterior); var despues = LimitesCursor(nuevo);
        exige(!despues.IsEmpty && Math.Abs(despues.Width / (double)nuevo.Width - antes.Width / (double)anterior.Width * .70) <= 2d / nuevo.Width &&
            Math.Abs(despues.Height / (double)nuevo.Height - antes.Height / (double)anterior.Height * .70) <= 2d / nuevo.Height,
            "El cursor de movimiento debe reducir el dibujo nativo al 70%, con tolerancia de dos píxeles por redondeo.");
    }
    private static void Seleccionar(DataGridView hoja, string primera, string ultima = null)
    {
        var inicio = MYGHojaCalculo.Coordenadas(primera);
        var fin = MYGHojaCalculo.Coordenadas(ultima ?? primera);
        hoja.ClearSelection(); hoja.CurrentCell = hoja[inicio.Columna - 1, inicio.Fila - 1];
        for (int f = inicio.Fila; f <= fin.Fila; f++)
            for (int c = inicio.Columna; c <= fin.Columna; c++) hoja[c - 1, f - 1].Selected = true;
        Application.DoEvents();
    }
    private static void VerificarCursor(Control control, Point punto, Cursor esperado, string mensaje,
        Action<bool, string> exige)
    {
        exige(control.ClientRectangle.Contains(punto), "El punto del cursor debe estar dentro del control visible de la comprobación.");
        Mover(control, punto);
        exige(control.Cursor.Handle == esperado.Handle, mensaje);
    }
    private static void Mover(Control control, Point punto) => EnviarMouse(control, 0x0200, punto, false);
    private static void Pulsar(Control control, Point punto)
    { Mover(control, punto); EnviarMouse(control, 0x0201, punto, true); EnviarMouse(control, 0x0202, punto, false); }
    private static void Arrastrar(Control control, Point inicio, Point fin)
    {
        IniciarArrastre(control, inicio, fin); EnviarMouse(control, 0x0202, fin, false);
    }
    private static void IniciarArrastre(Control control, Point inicio, Point fin)
    {
        Mover(control, inicio); EnviarMouse(control, 0x0201, inicio, true); EnviarMouse(control, 0x0200, fin, true);
    }
    private static void EnviarMouse(Control control, int mensaje, Point punto, bool presionado)
    {
        var posicion = new IntPtr((punto.X & 0xffff) | ((punto.Y & 0xffff) << 16));
        EnviarMensaje(control.Handle, mensaje, new IntPtr(presionado ? 1 : 0), posicion);
        Application.DoEvents();
    }
    private static void Comando(MYGPanelPresupuesto panel, string nombre)
    { Invocar<object>(panel, "EjecutarComandoHoja", nombre); Application.DoEvents(); }
    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static T Propiedad<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetProperty(nombre, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(objeto);
    private static T Invocar<T>(object objeto, string nombre, params object[] argumentos)
    {
        try { return (T)objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
