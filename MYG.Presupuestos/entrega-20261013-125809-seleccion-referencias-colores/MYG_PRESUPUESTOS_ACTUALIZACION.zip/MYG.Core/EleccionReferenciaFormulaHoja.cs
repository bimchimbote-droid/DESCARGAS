using System;

namespace MYG_2027;

/// <summary>Fragmento que se sustituye al señalar una celda durante la edición de una fórmula.</summary>
public sealed record MYGTramoInsercionReferenciaHoja(int Inicio, int Longitud);

/// <summary>
/// Prepara referencias elegidas con el ratón sin confirmar ni evaluar la fórmula.
/// El mismo fragmento se reutiliza durante un arrastre para sustituir la celda por un rango.
/// </summary>
public static class MYGEleccionReferenciaFormulaHoja
{
    private const int FilasExcel = 1048576, ColumnasExcel = 16384;

    public static bool IntentarPreparar(string formula, int inicioSeleccion, int longitudSeleccion,
        out MYGTramoInsercionReferenciaHoja tramo)
    {
        tramo = null;
        if (string.IsNullOrEmpty(formula) || formula.Length > MYGReferenciasFormulaHoja.MaximoCaracteresFormula ||
            inicioSeleccion < 0 || longitudSeleccion < 0 || inicioSeleccion > formula.Length ||
            longitudSeleccion > formula.Length - inicioSeleccion) return false;
        int igual = 0;
        while (igual < formula.Length && char.IsWhiteSpace(formula[igual])) igual++;
        if (igual == formula.Length || formula[igual] != '=' || inicioSeleccion <= igual) return false;
        int finSeleccion = inicioSeleccion + longitudSeleccion;
        if (EnLiteralONombreCalificado(formula, inicioSeleccion) || EnLiteralONombreCalificado(formula, finSeleccion)) return false;

        var referencias = MYGReferenciasFormulaHoja.Extraer(formula, FilasExcel, ColumnasExcel);
        if (longitudSeleccion > 0)
        {
            // Reemplazar una selección es explícito; nunca se inserta en medio
            // de un literal o de un nombre de hoja/libro entrecomillado.
            int inicio = inicioSeleccion, fin = finSeleccion;
            foreach (var referencia in referencias)
                if (inicioSeleccion < referencia.Inicio + referencia.Longitud && finSeleccion > referencia.Inicio)
                {
                    inicio = Math.Min(inicio, referencia.Inicio);
                    fin = Math.Max(fin, referencia.Inicio + referencia.Longitud);
                }
            tramo = new(inicio, fin - inicio);
            return true;
        }

        foreach (var referencia in referencias)
            if (inicioSeleccion >= referencia.Inicio && inicioSeleccion <= referencia.Inicio + referencia.Longitud)
            {
                tramo = new(referencia.Inicio, referencia.Longitud);
                return true;
            }

        int anterior = inicioSeleccion - 1, siguiente = inicioSeleccion;
        while (anterior > igual && char.IsWhiteSpace(formula[anterior])) anterior--;
        while (siguiente < formula.Length && char.IsWhiteSpace(formula[siguiente])) siguiente++;
        bool esperaOperando = anterior == igual || "(,;+-*/^&=<>:".IndexOf(formula[anterior]) >= 0;
        bool finOperando = siguiente == formula.Length || "),;+-*/^&=<>%".IndexOf(formula[siguiente]) >= 0;
        if (!esperaOperando || !finOperando) return false;
        tramo = new(inicioSeleccion, 0);
        return true;
    }

    public static string Aplicar(string formula, MYGTramoInsercionReferenciaHoja tramo, string referencia)
    {
        if (formula == null || tramo == null || tramo.Inicio < 0 || tramo.Longitud < 0 ||
            tramo.Inicio > formula.Length || tramo.Longitud > formula.Length - tramo.Inicio)
            throw new ArgumentException("El fragmento no pertenece a la fórmula.", nameof(tramo));
        var referencias = MYGReferenciasFormulaHoja.Extraer("=" + referencia, FilasExcel, ColumnasExcel);
        if (string.IsNullOrEmpty(referencia) || referencias.Count != 1 || referencias[0].Inicio != 1 || referencias[0].Longitud != referencia.Length)
            throw new ArgumentException("Elija una celda o un rango local válido.", nameof(referencia));
        if (formula.Length - tramo.Longitud + referencia.Length > MYGReferenciasFormulaHoja.MaximoCaracteresFormula)
            throw new InvalidOperationException("La celda supera los 32.767 caracteres.");
        return formula[..tramo.Inicio] + referencia + formula[(tramo.Inicio + tramo.Longitud)..];
    }

    private static bool EnLiteralONombreCalificado(string formula, int limite)
    {
        char comilla = '\0';
        int corchetes = 0;
        for (int p = 0; p < limite; p++)
        {
            char c = formula[p];
            if (comilla != '\0')
            {
                if (c != comilla) continue;
                if (p + 1 < formula.Length && formula[p + 1] == comilla)
                {
                    // La posición intermedia de dos comillas escapadas sigue
                    // dentro del texto, aunque el cursor esté entre ambas.
                    if (p + 1 >= limite) return true;
                    p++;
                }
                else comilla = '\0';
                continue;
            }
            if (c is '"' or '\'') { comilla = c; continue; }
            if (c == '[') corchetes++;
            if (c == ']' && corchetes > 0) corchetes--;
        }
        return comilla != '\0' || corchetes > 0;
    }
}
