using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private MYGFiltroElegirReferenciasHoja filtroElegirReferenciasHoja;
    private System.Windows.Forms.Timer relojElegirReferenciasHoja;
    private TextBoxBase editorElegirReferenciasHoja;
    private MYGHojaMetrado libroElegirReferenciasHoja;
    private MYGTramoInsercionReferenciaHoja tramoElegirReferenciasHoja;
    private string textoOriginalElegirReferenciasHoja, textoEsperadoElegirReferenciasHoja;
    private (int f1, int c1, int f2, int c2) anclaElegirReferenciasHoja;
    private Point inicioRatonElegirReferenciasHoja, puntoRatonElegirReferenciasHoja;
    private bool arrastrandoElegirReferenciasHoja;

    private void PrepararElegirReferenciasHoja()
    {
        // DataGridView confirma la celda antes de CellMouseDown. El filtro
        // consume el mensaje antes de que la cuadrícula cambie foco o selección.
        filtroElegirReferenciasHoja = new(this);
        Application.AddMessageFilter(filtroElegirReferenciasHoja);
        relojElegirReferenciasHoja = new() { Interval = 100 };
        relojElegirReferenciasHoja.Tick += DesplazarElegirReferenciasHoja;
        hoja.CellEndEdit += (_, _) => TerminarEleccionReferenciasHoja();
        hoja.MouseCaptureChanged += (_, _) => { if (!hoja.Capture) TerminarEleccionReferenciasHoja(); };
        formula.Leave += (_, _) => TerminarEleccionReferenciasHoja();
        paginaExcel.VisibleChanged += (_, _) => { if (!paginaExcel.Visible) TerminarEleccionReferenciasHoja(); };
        detalle.SelectedIndexChanged += (_, _) => { if (detalle.SelectedTab != paginaExcel) TerminarEleccionReferenciasHoja(); };
        hoja.DpiChangedAfterParent += (_, _) => TerminarEleccionReferenciasHoja();
        Disposed += (_, _) =>
        {
            TerminarEleccionReferenciasHoja();
            Application.RemoveMessageFilter(filtroElegirReferenciasHoja);
            relojElegirReferenciasHoja.Dispose();
        };
    }

    private TextBoxBase EditorActivoElegirReferenciasHoja() =>
        formula.Focused ? formula : hoja.IsCurrentCellInEditMode && hoja.EditingControl is TextBoxBase editor && editor.Focused ? editor : null;

    internal bool ProcesarRatonElegirReferenciasHoja(int mensaje, Point punto)
    {
        const int Pulsar = 0x0201, DoblePulsar = 0x0203, Mover = 0x0200, Soltar = 0x0202;
        if (mensaje is not (Pulsar or DoblePulsar or Mover or Soltar)) return false;
        if (editorElegirReferenciasHoja != null && (!HayPartida || cargando ||
            !ReferenceEquals(libroElegirReferenciasHoja, actual.Costos.Hoja) || editorElegirReferenciasHoja.IsDisposed ||
            EditorActivoElegirReferenciasHoja() != editorElegirReferenciasHoja || editorElegirReferenciasHoja.Text != textoEsperadoElegirReferenciasHoja))
            TerminarEleccionReferenciasHoja();

        if (mensaje is Pulsar or DoblePulsar)
        {
            if (editorElegirReferenciasHoja != null) TerminarEleccionReferenciasHoja();
            if (cargando || !HayPartida || hoja.ReadOnly || !paginaExcel.Visible || detalle.SelectedTab != paginaExcel ||
                (ModifierKeys & (Keys.Control | Keys.Alt)) != 0 || !AreaCeldasHoja().Contains(punto)) return false;
            var hit = hoja.HitTest(punto.X, punto.Y);
            var editor = EditorActivoElegirReferenciasHoja();
            if (hit.Type != DataGridViewHitTestType.Cell || editor == null || editor.ReadOnly ||
                !MYGEleccionReferenciaFormulaHoja.IntentarPreparar(editor.Text, editor.SelectionStart, editor.SelectionLength, out var tramo)) return false;
            editorElegirReferenciasHoja = editor;
            libroElegirReferenciasHoja = actual.Costos.Hoja;
            tramoElegirReferenciasHoja = tramo;
            textoOriginalElegirReferenciasHoja = textoEsperadoElegirReferenciasHoja = editor.Text;
            anclaElegirReferenciasHoja = LimitesCeldaElegidaHoja(hit.RowIndex, hit.ColumnIndex);
            inicioRatonElegirReferenciasHoja = puntoRatonElegirReferenciasHoja = punto;
            arrastrandoElegirReferenciasHoja = false;
            CerrarAutocompletadoHoja();
            // Capturar el ratón no cambia el foco: el editor y la celda origen
            // permanecen activos, y el modelo sólo cambia al confirmar.
            hoja.Capture = true;
            ActualizarCeldaElegidaHoja(punto);
            if (editorElegirReferenciasHoja != null) relojElegirReferenciasHoja.Start();
            return true;
        }
        if (editorElegirReferenciasHoja == null) return false;
        puntoRatonElegirReferenciasHoja = punto;
        if (mensaje == Mover)
        {
            if (Math.Abs(punto.X - inicioRatonElegirReferenciasHoja.X) >= SystemInformation.DragSize.Width / 2 ||
                Math.Abs(punto.Y - inicioRatonElegirReferenciasHoja.Y) >= SystemInformation.DragSize.Height / 2)
                arrastrandoElegirReferenciasHoja = true;
            ActualizarCeldaElegidaHoja(punto);
            hoja.Cursor = cursoresHoja?.Seleccion ?? Cursors.Cross;
            Cursor.Current = hoja.Cursor;
            return true;
        }
        if (mensaje == Soltar)
        {
            ActualizarCeldaElegidaHoja(punto);
            TerminarEleccionReferenciasHoja();
            return true;
        }
        return false;
    }

    private (int f1, int c1, int f2, int c2) LimitesCeldaElegidaHoja(int fila, int columna) =>
        CombinacionCeldaHoja(fila, columna) ?? (fila, columna, fila, columna);

    private void ActualizarCeldaElegidaHoja(Point punto)
    {
        if (editorElegirReferenciasHoja == null) return;
        var area = AreaCeldasHoja();
        if (area.Width <= 0 || area.Height <= 0) return;
        punto = new(Math.Clamp(punto.X, area.Left, area.Right - 1), Math.Clamp(punto.Y, area.Top, area.Bottom - 1));
        var hit = hoja.HitTest(punto.X, punto.Y);
        if (hit.Type != DataGridViewHitTestType.Cell) return;
        var destino = LimitesCeldaElegidaHoja(hit.RowIndex, hit.ColumnIndex);
        var origen = anclaElegirReferenciasHoja;
        string referencia;
        if (destino == origen) referencia = DireccionCelda(origen.f1, origen.c1);
        else
        {
            string primera = DireccionCelda(Math.Min(origen.f1, destino.f1), Math.Min(origen.c1, destino.c1));
            string ultima = DireccionCelda(Math.Max(origen.f2, destino.f2), Math.Max(origen.c2, destino.c2));
            referencia = primera == ultima ? primera : primera + ":" + ultima;
        }
        string texto;
        try { texto = MYGEleccionReferenciaFormulaHoja.Aplicar(textoOriginalElegirReferenciasHoja, tramoElegirReferenciasHoja, referencia); }
        catch (InvalidOperationException) { TerminarEleccionReferenciasHoja(); return; }
        if (texto == textoEsperadoElegirReferenciasHoja)
        {
            editorElegirReferenciasHoja.Select(tramoElegirReferenciasHoja.Inicio + referencia.Length, 0);
            return;
        }
        int longitudActual = textoEsperadoElegirReferenciasHoja.Length - textoOriginalElegirReferenciasHoja.Length + tramoElegirReferenciasHoja.Longitud;
        textoEsperadoElegirReferenciasHoja = texto;
        editorElegirReferenciasHoja.Select(tramoElegirReferenciasHoja.Inicio, longitudActual);
        editorElegirReferenciasHoja.SelectedText = referencia;
        editorElegirReferenciasHoja.Select(tramoElegirReferenciasHoja.Inicio + referencia.Length, 0);
        // La selección de texto no representa la selección de celdas: mantener
        // CurrentCell evita validaciones y entradas de deshacer prematuras.
    }

    private void DesplazarElegirReferenciasHoja(object sender, EventArgs e)
    {
        if (editorElegirReferenciasHoja == null || !arrastrandoElegirReferenciasHoja) return;
        if (!HayPartida || !ReferenceEquals(libroElegirReferenciasHoja, actual.Costos.Hoja) ||
            !hoja.Capture || EditorActivoElegirReferenciasHoja() != editorElegirReferenciasHoja)
        { TerminarEleccionReferenciasHoja(); return; }
        // DataGridView confirma el valor del editor al cambiar su primera fila
        // o columna visible. El desplazamiento automático sólo se usa desde
        // la barra para que Escape en una celda siga restaurando su contenido.
        if (hoja.IsCurrentCellInEditMode) return;
        var area = AreaCeldasHoja();
        int margen = Math.Max(10, (int)Math.Ceiling(14 * hoja.DeviceDpi / 96d));
        int df = puntoRatonElegirReferenciasHoja.Y < area.Top + margen ? -1 : puntoRatonElegirReferenciasHoja.Y >= area.Bottom - margen ? 1 : 0;
        int dc = puntoRatonElegirReferenciasHoja.X < area.Left + margen ? -1 : puntoRatonElegirReferenciasHoja.X >= area.Right - margen ? 1 : 0;
        if (df == 0 && dc == 0) return;
        if (df != 0)
        {
            int siguiente = hoja.FirstDisplayedScrollingRowIndex + df;
            while (siguiente >= 0 && siguiente < hoja.RowCount && (!hoja.Rows[siguiente].Visible || hoja.Rows[siguiente].Frozen)) siguiente += df;
            if (siguiente >= 0 && siguiente < hoja.RowCount) hoja.FirstDisplayedScrollingRowIndex = siguiente;
        }
        if (dc != 0)
        {
            int siguiente = hoja.FirstDisplayedScrollingColumnIndex + dc;
            while (siguiente >= 0 && siguiente < hoja.ColumnCount && (!hoja.Columns[siguiente].Visible || hoja.Columns[siguiente].Frozen)) siguiente += dc;
            if (siguiente >= 0 && siguiente < hoja.ColumnCount) hoja.FirstDisplayedScrollingColumnIndex = siguiente;
        }
        ActualizarCeldaElegidaHoja(puntoRatonElegirReferenciasHoja);
    }

    private void TerminarEleccionReferenciasHoja()
    {
        bool teniaEleccion = editorElegirReferenciasHoja != null;
        editorElegirReferenciasHoja = null;
        libroElegirReferenciasHoja = null;
        tramoElegirReferenciasHoja = null;
        textoOriginalElegirReferenciasHoja = textoEsperadoElegirReferenciasHoja = null;
        arrastrandoElegirReferenciasHoja = false;
        relojElegirReferenciasHoja?.Stop();
        if (teniaEleccion && !hoja.IsDisposed && hoja.Capture) hoja.Capture = false;
    }

    private sealed class MYGFiltroElegirReferenciasHoja(MYGPanelPresupuesto panel) : IMessageFilter
    {
        public bool PreFilterMessage(ref Message m)
        {
            if (panel.IsDisposed || panel.hoja.IsDisposed || !panel.hoja.IsHandleCreated) return false;
            if (m.Msg is 0x0100 or 0x0104 or 0x001f)
            {
                if (panel.editorElegirReferenciasHoja != null) panel.TerminarEleccionReferenciasHoja();
                return false; // Escape/Enter conservan el ciclo normal del editor.
            }
            if (m.Msg is not (0x0200 or 0x0201 or 0x0202 or 0x0203)) return false;
            var destino = Control.FromChildHandle(m.HWnd);
            if (destino == null || destino != panel.hoja && !panel.hoja.Contains(destino)) return false;
            // Dentro del editor, el ratón sigue colocando el cursor y
            // seleccionando texto; sólo se señalan las otras celdas de la hoja.
            if (panel.editorElegirReferenciasHoja == null && destino is TextBoxBase) return false;
            long posicion = m.LParam.ToInt64();
            var punto = new Point((short)(posicion & 0xffff), (short)((posicion >> 16) & 0xffff));
            if (destino != panel.hoja) punto = panel.hoja.PointToClient(destino.PointToScreen(punto));
            return panel.ProcesarRatonElegirReferenciasHoja(m.Msg, punto);
        }
    }
}
