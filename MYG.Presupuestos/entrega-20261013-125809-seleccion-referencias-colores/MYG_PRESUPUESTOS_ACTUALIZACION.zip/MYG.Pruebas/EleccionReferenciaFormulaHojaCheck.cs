using System;
using MYG_2027;

static class EleccionReferenciaFormulaHojaCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }

    public static void Ejecutar(Action<string> pasa)
    {
        string Elegir(string formula, int inicio, int longitud, string referencia)
        {
            Exige(MYGEleccionReferenciaFormulaHoja.IntentarPreparar(formula, inicio, longitud, out var tramo),
                "Debe poder señalarse una referencia en esta posición: " + formula);
            return MYGEleccionReferenciaFormulaHoja.Aplicar(formula, tramo, referencia);
        }
        string formula = Elegir("=", 1, 0, "C9");
        Exige(formula == "=C9", "El primer clic debe insertar una dirección después de igual.");
        formula = Elegir(formula, formula.Length, 0, "D4");
        Exige(formula == "=D4", "Un clic sucesivo debe reemplazar la referencia elegida, sin concatenar direcciones.");
        formula += "+";
        formula = Elegir(formula, formula.Length, 0, "C7");
        Exige(formula == "=D4+C7", "Escribir un operador debe permitir añadir una segunda referencia.");
        formula = Elegir(formula, formula.Length, 0, "C3:C8");
        Exige(formula == "=D4+C3:C8", "Arrastrar debe sustituir el último operando por un rango.");
        pasa("Señalar celdas desde = inserta y reemplaza referencias hasta escribir otro operador");

        Exige(Elegir("=SUMA()", 6, 0, "B3:D5") == "=SUMA(B3:D5)" &&
            Elegir("=SUMA(;C7)+5", 6, 0, "B3:D5") == "=SUMA(B3:D5;C7)+5" &&
            Elegir("=SI(B3>0;;C7)", 9, 0, "D4") == "=SI(B3>0;D4;C7)" &&
            Elegir(" =SUMA(  )", 9, 0, "C3") == " =SUMA(  C3)",
            "Las referencias elegidas deben respetar espacios, argumentos y el sufijo de la fórmula.");
        Exige(Elegir("=SUMA($A$3:$D$7)+F5", 9, 0, "C3:D8") == "=SUMA(C3:D8)+F5" &&
            Elegir("=SUMA($A$3:$D$7)+F5", 8, 1, "C3") == "=SUMA(C3)+F5" &&
            Elegir("=SUMA(B3;C7)+E9", 6, 5, "B3:C7") == "=SUMA(B3:C7)+E9",
            "El cursor o una selección parcial dentro de una referencia deben sustituir el token completo; una selección de argumentos conserva su contexto.");
        pasa("Señalar rangos respeta argumentos, selección de texto y referencias absolutas completas");

        foreach (var entrada in new[]
        {
            (Texto: "Descripción A1", Cursor: 14), (Texto: "SUMA(A1)", Cursor: 5),
            (Texto: "=SI(A1=\"B2\";C3;D4)", Cursor: 10), (Texto: "=\"A1\"\"B2\"", Cursor: 6),
            (Texto: "='Hoja A1'!B2", Cursor: 5), (Texto: "=Tabla1[B2]", Cursor: 9),
            (Texto: "=Hoja1!B2", Cursor: 9), (Texto: "=123", Cursor: 4),
            (Texto: "=SUMA", Cursor: 5), (Texto: "=", Cursor: 0)
        })
            Exige(!MYGEleccionReferenciaFormulaHoja.IntentarPreparar(entrada.Texto, entrada.Cursor, 0, out _),
                "El ratón no debe insertar una referencia dentro de texto, nombres o operandos incompatibles: " + entrada.Texto);
        Exige(!MYGEleccionReferenciaFormulaHoja.IntentarPreparar("=\"texto\"", 3, 2, out _) &&
            !MYGEleccionReferenciaFormulaHoja.IntentarPreparar("=A1", 0, 2, out _) &&
            !MYGEleccionReferenciaFormulaHoja.IntentarPreparar(null, 0, 0, out _) &&
            !MYGEleccionReferenciaFormulaHoja.IntentarPreparar("=A1", -1, 0, out _) &&
            !MYGEleccionReferenciaFormulaHoja.IntentarPreparar("=A1", 2, int.MaxValue, out _),
            "Una selección inválida o que empieza dentro de un literal no debe modificar la fórmula.");
        pasa("Elegir referencias omite literales, nombres externos y texto sin fórmula, y valida el cursor");

        Exige(MYGEleccionReferenciaFormulaHoja.IntentarPreparar("=SUMA()+C7", 6, 0, out var fijo) &&
            MYGEleccionReferenciaFormulaHoja.Aplicar("=SUMA()+C7", fijo, "B3") == "=SUMA(B3)+C7" &&
            MYGEleccionReferenciaFormulaHoja.Aplicar("=SUMA()+C7", fijo, "B3:D9") == "=SUMA(B3:D9)+C7",
            "Todo el arrastre debe reutilizar el fragmento original sin acumular referencias ni perder el sufijo.");
        foreach (string invalida in new[] { "C3+1", "A0", "XFE1", "A1048577", "Hoja1!B2", "\"B2\"", "", null })
        {
            bool rechazada = false;
            try { MYGEleccionReferenciaFormulaHoja.Aplicar("=", new(1, 0), invalida); }
            catch (ArgumentException) { rechazada = true; }
            Exige(rechazada, "Sólo se deben insertar referencias locales válidas.");
        }
        string maxima = "=" + new string(' ', 32764) + "B1";
        Exige(MYGEleccionReferenciaFormulaHoja.IntentarPreparar(maxima, maxima.Length, 0, out var tramoMaximo),
            "Una fórmula dentro del límite debe seguir permitiendo elegir referencias.");
        bool limiteRespetado = false;
        try { MYGEleccionReferenciaFormulaHoja.Aplicar(maxima, tramoMaximo, "XFD1048576"); }
        catch (InvalidOperationException) { limiteRespetado = true; }
        Exige(limiteRespetado && !MYGEleccionReferenciaFormulaHoja.IntentarPreparar(maxima + " ", maxima.Length, 0, out _),
            "Las sustituciones deben preservar el límite de 32.767 caracteres sin truncar la fórmula.");
        pasa("Arrastrar reutiliza el borrador sin efectos en el modelo y valida las referencias y el límite de Excel");
    }
}
