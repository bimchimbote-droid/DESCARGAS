namespace MYG.Colaboracion;

/// <summary>
/// Punto de compatibilidad del antiguo flujo de copias por obra. Crear una
/// colaboración ya no puede publicar un paquete independiente de la base.
/// Las publicaciones existentes se conservan y siguen disponibles desde Nube.
/// </summary>
public sealed class PublicacionObraBasePendiente
{
    public PublicacionObraBasePendiente(string carpeta, string servidor, string usuario)
    {
        if (string.IsNullOrWhiteSpace(carpeta))
            throw new ArgumentException("Indique la carpeta de publicaciones de obras.", nameof(carpeta));
        if (!Uri.TryCreate(servidor, UriKind.Absolute, out var destino)
            || destino.Scheme != Uri.UriSchemeHttps || destino.UserInfo.Length != 0
            || destino.AbsolutePath != "/" || destino.Query.Length != 0 || destino.Fragment.Length != 0)
            throw new ArgumentException("Indique el servidor HTTPS de nube sin credenciales ni rutas.", nameof(servidor));
        if (!Guid.TryParse(usuario, out var identidad) || identidad == Guid.Empty)
            throw new ArgumentException("Indique la identidad de la cuenta de nube.", nameof(usuario));
        // Validar la ruta no crea la carpeta ni lee intentos de la versión anterior.
        _ = Path.GetFullPath(carpeta);
    }

    public Task<ObraBaseNube> PrepararYEnviarAsync(ClienteSupabase cliente, Guid baseId,
        string rutaSQLite, string documentoId, CancellationToken ct = default,
        IProgress<string>? progreso = null)
    {
        ArgumentNullException.ThrowIfNull(cliente);
        ct.ThrowIfCancellationRequested();
        // Bloqueo antes de leer SQLite, crear archivos, recuperar intentos o hacer
        // solicitudes. Nunca regresar al protocolo de publicación independiente.
        throw ServicioRequerido();
    }

    public static NubeException ServicioRequerido() => new(
        "No se creó ninguna copia ni se cambiaron los permisos. "
        + "Esta versión todavía no dispone del servicio necesario para colaborar "
        + "en una sola obra de la misma base SQLite sin entregar las demás obras. "
        + "La base original y las colaboraciones anteriores se conservan.",
        codigo: "MYG_BASE_REQUIERE_SERVIDOR");
}
