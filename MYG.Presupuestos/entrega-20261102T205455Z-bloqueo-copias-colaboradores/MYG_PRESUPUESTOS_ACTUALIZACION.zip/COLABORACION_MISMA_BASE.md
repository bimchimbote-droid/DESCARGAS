# Colaboración por obra sin crear otra publicación

## A. Resultado de esta entrega

**Es un bloqueo preventivo, no la implementación terminada de colaboración
sobre una misma base.** El botón de colaboradores de una base ya no ofrece ni
prepara una copia independiente de su obra. La API antigua también se detiene
antes de leer SQLite, crear carpetas/paquetes, reintentar publicaciones o hacer
solicitudes. Informa `MYG_BASE_REQUIERE_SERVIDOR` sin cambiar permisos ni datos.

Las publicaciones y pendientes antiguos no se borran, migran ni reenvían. Las
obras ya publicadas se conservan y se pueden abrir desde Nube MYG. Su contenido
sigue siendo independiente; no se presenta esa vía como edición de la base original.

Base comprobada en GitHub: `bimchimbote-droid/MYG.Presupuestos`, rama `main`,
commit `e0b4f9ebf26ce3e8ba337dbea774f22159052c14`. El checkout local usa `work`
basado en ese commit. No se ha hecho commit ni push al repositorio del código.

## B. Archivos

| Ruta | Acción | Descripción |
| --- | --- | --- |
| `MYG.Desktop/InicioColaboracionObraBase.cs` | REEMPLAZAR | Retira aviso y preparación automática de otra publicación desde una base. |
| `MYG.Colaboracion/PublicacionObraBasePendiente.cs` | REEMPLAZAR | Mantiene la firma pública y bloquea el protocolo de copias sin efectos secundarios. |
| `MYG.PruebasNube/ColaboracionObraBaseCheck.cs` | REEMPLAZAR | Comprueba que no se publica ni altera la base de dos obras ni los pendientes antiguos. |
| `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Añade alias `--colaboracion-sin-copia`; el selector anterior usa el mismo requisito nuevo. |
| `COLABORACION_MISMA_BASE.md` | CREAR | Alcance real, instalación y alternativas. |

Los cuatro archivos de la entrega anterior de permisos Metrados Revit se
conservan, pero no se vuelven a incluir en este ZIP porque este ajuste no los cambia.

## C. ZIP

`MYG_PRESUPUESTOS_ACTUALIZACION.zip` contiene únicamente los cinco archivos de
la tabla, completos, con sus rutas relativas. Su ruta de entrega en DESCARGAS
es nueva; no sustituye ZIP anteriores. La publicación y la verificación de
descarga se informan por separado de las comprobaciones locales.

## D. Instalación del bloqueo preventivo

1. Respaldar o confirmar cambios locales del proyecto. Comparar los archivos
   si contienen modificaciones posteriores al commit base antes de sustituirlos.
2. Descargar y extraer el ZIP; copiar los cinco archivos en la raíz del proyecto,
   conservando sus carpetas. No hay archivos que eliminar ni parches adicionales.
3. Restaurar y compilar con .NET 10.0.100; en Windows se puede usar Visual Studio
   2026 o posterior. Usar Revit 2027 instalado o paquetes de referencia al compilar.
4. Abrir MYG compilado. Al intentar preparar colaboradores desde la base, la
   aplicación informa que falta el servicio para esa modalidad, sin crear una copia.
   **El alta nueva en la misma base queda pendiente del backend; este ZIP no la habilita.**

No ejecutar nuevas migraciones SQL ni borrar archivos de Storage por este ajuste.
No se tocó el Supabase real ni se crearon copias de datos del usuario durante las pruebas.

## E. Opciones revisadas para completar la función

El archivo SQLite actual es un objeto binario en Storage. Las funciones de
PostgreSQL conocen su ruta, hash, tamaño y revisión, pero no pueden seleccionar
las obras contenidas en ese archivo. Dar al colaborador membresía sobre la base
le permite descargar el archivo entero; un filtro de interfaz no protege las otras obras.

| Opción | Conserva SQLite en la nube | Necesidad y efecto |
| --- | --- | --- |
| Servicio .NET en un PC o servidor propio | Sí | Equipo encendido y accesible mediante conexión segura mientras se trabaja. No requiere contratar alojamiento si ya existe equipo adecuado. |
| Servicio .NET en un servidor alojado | Sí | Alojamiento con coste y despliegue HTTPS. Puede operar aunque el PC del propietario esté apagado. Hay que dimensionarlo según archivos y concurrencia. |
| Datos autoritativos en PostgreSQL de Supabase | Cambia el formato de nube | No necesita un servicio lector SQLite adicional, pero requiere una migración y sincronización mucho mayores. SQLite puede seguir como formato local. Se deben revisar cuotas del plan. |

**Recomendación para conservar el formato actual: un servicio .NET en Docker.**
Su ubicación debe elegirse antes de desplegarlo. No se ha contratado alojamiento,
desplegado ese servicio ni solicitado claves administrativas en el chat.

No recomiendo basar el flujo general de archivos de hasta 300 MiB en una Edge
Function que cargue SQLite completo en memoria. La documentación oficial revisada
indica 256 MB de memoria y 2 segundos de CPU por petición en la plataforma alojada:
https://supabase.com/docs/guides/functions/limits . Esto no demuestra que toda
solución Edge sea imposible, pero exige otro diseño y pruebas de límites; no es
un reemplazo directo para la lógica C# existente.

El backend recomendado tendría estas obligaciones:

1. Registrar solo permisos por `(base_id, documento_id, usuario)`, sin copiar el
   contenido de la obra ni crear otra publicación con datos.
2. Validar la sesión y membresía en servidor; abrir la revisión original en un
   temporal de procesamiento y devolver únicamente la proyección autorizada.
3. Comprobar los cuatro permisos contra los cambios reales del paquete, no una
   máscara proporcionada por el cliente; proteger también tablas y catálogos.
4. Aplicar las ediciones sobre la misma base y confirmar con comparación de
   revisión, conservando otras obras y rechazando conflictos sin sobrescribirlas.
5. No entregar al colaborador la ruta, credencial ni URL del SQLite completo.

Las versiones de guardado del snapshot que ya mantiene el sistema son distintas
de una publicación independiente por obra. Esta entrega no borra versiones ni
promete que desaparezca todo consumo por historial. Tampoco elimina copias que
ya se hubiesen creado anteriormente.

## F. Validación ejecutada

SDK .NET **10.0.100**, compilación Release en Linux x64, **0 errores y 0 advertencias**.
SQLite real y HTTP simulado, sin servicios ni datos de producción.

```text
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --colaboracion-sin-copia
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --base-sqlite-unica
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --compatibilidad-colaboradores
```

La compilación ejecutada incluyó restauración. Resultados dirigidos:

- **11 comprobaciones** del bloqueo preventivo. Los selectores
  `--colaboracion-obra` y `--colaboracion-sin-copia` ejecutan la misma suite:
  no sumar sus recuentos como pruebas distintas.
- **59 comprobaciones** de base SQLite única con dos obras, lectura, edición,
  sincronización y revisión compartida.
- **154 comprobaciones** de compatibilidad de colaboradores, roles, revocación,
  identidad y diagnósticos.

Las antiguas pruebas que exigían crear una copia fueron sustituidas por el nuevo
requisito de no crearla. No se declara implementado el backend futuro. La suite
completa de nube no se repitió: tiene un fallo previo conocido de diagnóstico de
renovación en `PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`, fuera de
este alcance. Windows, Revit y el Supabase real no se ejecutaron.

## G. Publicación del código

En Visual Studio, revisar los cinco archivos en **Cambios de Git**, confirmar
el bloqueo con un mensaje claro y hacer Push a la rama de trabajo elegida.
Verificar la rama y el commit en GitHub. Publicar el ZIP en DESCARGAS no aplica
los cambios al proyecto ni publica automáticamente su código.

## H. Pendiente necesario

Elegir dónde ejecutar el lector/escritor SQLite seguro o autorizar la alternativa
de PostgreSQL. Después deben implementarse y probarse backend, permisos por
documento y cliente. Retirar el bloqueo antes de completar eso volvería a permitir
duplicados o a exponer la base completa. Esta entrega es únicamente la protección
inmediata solicitada contra las copias automáticas.
