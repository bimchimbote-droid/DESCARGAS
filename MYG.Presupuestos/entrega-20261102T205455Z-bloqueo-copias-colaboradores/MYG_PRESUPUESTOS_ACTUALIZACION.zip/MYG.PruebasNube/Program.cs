using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;

internal static class Program
{
    private const string Clave = "sb_publishable_pruebas_sin_red";
    private static readonly Guid ProyectoId = Guid.Parse("11111111-1111-4111-8111-111111111111");
    private static readonly Guid OperacionId = Guid.Parse("22222222-2222-4222-8222-222222222222");
    private static readonly Guid UsuarioId = Guid.Parse("33333333-3333-4333-8333-333333333333");
    private static readonly Guid OtroUsuarioId = Guid.Parse("44444444-4444-4444-8444-444444444444");
    private static int _comprobaciones;
    private static int _casos;

    public static async Task<int> Main(string[] args)
    {
        try
        {
            if (args.Length == 1 && args[0] == "--plantilla-nativa") { CopiaSqliteNubeCheck.PlantillaNativaCheck(); return 0; }
            if (args.Length == 1 && args[0] == "--modeladores-bim") { await CopiaSqliteNubeCheck.RunBimAsync(); return 0; }
            if (args.Length == 1 && args[0] == "--permisos-modulos")
            {
                await PermisosModulosCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--compatibilidad-colaboradores")
            {
                await CompatibilidadColaboradoresCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--colaboracion-obra")
            {
                await ColaboracionObraBaseCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--colaboracion-sin-copia")
            {
                await ColaboracionObraBaseCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--eliminar-base")
            {
                await EliminacionBaseNubeCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--explorador-nube")
            {
                await ExploradorNubeCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--nombres-proyectos")
            {
                await NombresProyectosNubeCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--bases-obras")
            {
                await BasesNubeCheck.RunAsync();
                await PublicacionBasePendienteCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--sqlite-nativo")
            {
                await SqliteNubeCheck.RunAsync();
                await PublicacionSqlitePendienteCheck.RunAsync();
                await CopiaSqliteNubeCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--base-sqlite-unica")
            {
                await BaseSqliteUnicaCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--apertura-paquete-grande")
            {
                await AperturaPaqueteGrandeCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--publicacion-comprimida")
            {
                await PublicacionComprimidaCheck.RunAsync();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--publicacion-sin-espera")
            {
                await PublicacionSinEsperaClienteCheck.RunAsync();
                return 0;
            }
            await ExploradorNubeCheck.RunAsync();
            await EliminacionBaseNubeCheck.RunAsync();
            await NombresProyectosNubeCheck.RunAsync();
            await BasesNubeCheck.RunAsync();
            await PublicacionBasePendienteCheck.RunAsync();
            await BaseSqliteUnicaCheck.RunAsync();
            await ColaboracionObraBaseCheck.RunAsync();
            await CompatibilidadColaboradoresCheck.RunAsync();
            await Probar("Listado de metadatos y separación de contenido", Listado);
            await Probar("Crear, abrir y guardar con contrato JSON de Nube v2", ProyectoCompleto);
            await Probar("Conflicto conserva revisión y contenido confirmados por servidor", Conflicto);
            await Probar("Solicitud recibida no concede acceso local", SolicitudSinPermiso);
            await Probar("Listas de miembros y solicitudes", MiembrosYSolicitudes);
            await Probar("Resolver solicitudes y administrar roles", Administracion);
            await Probar("Todos los roles autorizados y ambos alcances", RolesYAlcances);
            await Probar("Operaciones requieren identidad autenticada", SinSesion);
            await Probar("Entradas inválidas no envían solicitudes", EntradasInvalidas);
            await Probar("Renovación 401 conserva UUID y bytes originales", Renovacion);
            await Probar("Renovación con otra identidad cancela el reenvío", IdentidadCambiada);
            await Probar("Revocación 42501 conserva sesión y no concede permisos", Revocacion);
            await Probar("Error transitorio no revela cuerpo remoto ni mensajes DEMO", ErrorTransitorio);
            await Probar("Vínculo no verificado mediante código y mensaje reservado", VinculoNoVerificado);
            await Probar("Cancelación explícita en espera y en transporte", Cancelacion);
            await Probar("Contenido grande y profundo válido para Nube v2", DocumentoGrande);
            await Probar("Crear, abrir y guardar contenido de 48 MiB", ProyectoGrande);
            await Probar("Límites de contenido de 300 MiB y respuesta de 320 MiB", LimiteTamano);
            await Probar("Publicación mayor de 127 MiB negocia capacidad y conserva reintentos", ProyectoAmpliado);
            await Probar("Plazos de transferencias grandes y cancelación", PlazosNubeCheck.RunAsync);
            await Probar("Publicaciones pendientes, aislamiento y retiro con copia", PublicacionesPendientesCheck.RunAsync);
            await Probar("Rechazo de respuesta que excede profundidad 128", LimiteProfundidad);
            await Probar("Validación de UUID, revisiones, roles y forma de respuesta", RespuestaInvalida);
            await Probar("DEMO conserva sus límites y endpoints", CompatibilidadDemo);
            await Probar("Sincronización durable entre HTTP y SQLite", SincronizacionCheck.RunAsync);
            await Probar("Diferencias compactas y confirmaciones incrementales", CambiosIncrementalesCheck.RunAsync);
            await Probar("Sincronización incremental, recuperación y conflictos", SincronizacionIncrementalCheck.RunAsync);
            await Probar("Archivos de nube con integridad y autorización", ArchivosNubeCheck.RunAsync);
            await Probar("Paquetes portables, aislamiento y rutas recibidas", PaqueteNubeCheck.RunAsync);
            await Probar("Formato compacto conserva tipos, SQLite y adjuntos", FormatoCompactoCheck.RunAsync);
            await Probar("Capacidades compactas y compatibilidad de servidor", CapacidadesNubeCheck.RunAsync);
            await Probar("Publicación con confirmación de metadatos y reintentos", PublicacionLigeraCheck.RunAsync);
            await Probar("Publicación ocupada conserva intento y recuperación", PublicacionSinEsperaClienteCheck.RunAsync);
            await Probar("Publicación comprimida, integridad y compatibilidad", PublicacionComprimidaCheck.RunAsync);
            await Probar("Diagnóstico seguro de memoria, plazos y servicio", DiagnosticoRecursosNubeCheck.RunAsync);
            await Probar("Confirmación compatible con PostgreSQL JSONB", ConfirmacionJsonbCheck.RunAsync);
            await Probar("Ingreso único MYG con sesiones independientes", IngresoMygChecks.RunAsync);
            await Probar("Usuarios MYG y permisos de edición por módulo", PermisosModulosCheck.RunAsync);
            await Probar("Configuración de nube distribuida y perfiles existentes", ConfiguracionNubeCheck.RunAsync);
            await Probar("Almacenamiento Delphin compacto y paquetes de nube sin pérdida", JsonAlmacenamientoNubeCheck.RunAsync);
            await Probar("Archivo SQLite nativo sin compresión", SqliteNubeCheck.RunAsync);
            await Probar("Publicación SQLite pendiente y portable", PublicacionSqlitePendienteCheck.RunAsync);
            await Probar("Sincronización de archivos SQLite y recuperación local", CopiaSqliteNubeCheck.RunAsync);
            Console.WriteLine($"{_casos} grupos principales y {_comprobaciones} comprobaciones de contrato HTTP correctas; integración indicada arriba. Sin red.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"ERROR Nube: {ex}");
            return 1;
        }
    }

    private static async Task Probar(string nombre, Func<Task> prueba)
    {
        await prueba();
        _casos++;
        Console.WriteLine("OK " + nombre);
    }

    private static void Igual(bool condicion, string detalle)
    {
        _comprobaciones++;
        if (!condicion) throw new InvalidOperationException(detalle);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error) { _comprobaciones++; return error; }
        throw new InvalidOperationException("Se esperaba NubeException.");
    }

    private static JsonElement Contenido(string texto = "{\"presupuestos\":[{\"nombre\":\"Estructuras\"}],\"version\":2}")
    {
        using var documento = JsonDocument.Parse(texto, new JsonDocumentOptions { MaxDepth = 256 });
        return documento.RootElement.Clone();
    }

    private static object Metadatos(string rol = "editor", string alcance = "obra", long revision = 3) => new
    {
        id = ProyectoId, codigo = "MYG-PRUEBA-001", nombre = "Proyecto de prueba", rol, revision, alcance
    };

    private static object Proyecto(JsonElement? contenido = null, string rol = "editor", string alcance = "obra", long revision = 3) => new
    {
        id = ProyectoId, codigo = "MYG-PRUEBA-001", nombre = "Proyecto de prueba", rol, revision, alcance,
        contenido = contenido ?? Contenido()
    };

    private static object Guardado(string estado, long revision = 4, JsonElement? contenido = null) => new
    {
        estado, revision, contenido = contenido ?? Contenido(), operacion_id = OperacionId
    };

    private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    {
        Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json")
    };

    private static async Task<(ClienteSupabase Cliente, Transporte Transporte)> Sesion(Guid? usuario = null)
    {
        var transporte = new Transporte();
        transporte.Responder("/auth/v1/token?grant_type=password", peticion =>
        {
            Igual(peticion.Token is null, "El login no envía una sesión ajena.");
            Igual(peticion.Json.GetProperty("email").GetString() == "pruebas@myg.example", "Correo de login incorrecto.");
            return SesionJson("acceso_original", usuario ?? UsuarioId);
        });
        var cliente = new ClienteSupabase("https://pruebas.supabase.co", Clave, transporte);
        await cliente.IniciarSesionAsync(" pruebas@myg.example ", "contraseña_de_prueba");
        Igual(cliente.SesionIniciada && cliente.UsuarioId == (usuario ?? UsuarioId).ToString("D"), "No se publicó la sesión autenticada.");
        Igual(cliente.UrlServidor == "https://pruebas.supabase.co", "La identidad del servidor incluye rutas o información extra.");
        return (cliente, transporte);
    }

    private static HttpResponseMessage SesionJson(string token, Guid usuario) => Json(new
    {
        access_token = token, refresh_token = "refresco_de_prueba", expires_in = 3600,
        user = new { id = usuario }
    });

    private static void Parametro(Peticion peticion, string nombre, object? esperado)
    {
        Igual(peticion.Json.TryGetProperty(nombre, out var valor), $"Falta el parámetro {nombre}.");
        Igual(JsonElement.DeepEquals(valor, JsonSerializer.SerializeToElement(esperado)), $"Parámetro incorrecto: {nombre}.");
    }

    private static async Task Listado()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            transporte.Rpc("myg_nube_listar", _ => Json(new[] { Metadatos() }));
            var lista = await cliente.ListarProyectosAsync();
            Igual(lista.Count == 1 && lista[0].Id == ProyectoId && lista[0].Codigo == "MYG-PRUEBA-001", "No se interpretaron los metadatos del listado.");
            Igual(lista[0].Rol == "editor" && lista[0].Revision == 3 && lista[0].Alcance == "obra", "Se perdieron permisos o revisión.");
            Igual(lista[0].Contenido.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null, "El listado inventó contenido del proyecto.");
            transporte.Rpc("myg_nube_listar", _ => Json(Array.Empty<object>()));
            Igual((await cliente.ListarProyectosAsync()).Count == 0, "El listado vacío concedió proyectos inexistentes.");
            transporte.Completo();
        }
    }

    private static async Task ProyectoCompleto()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            JsonElement contenido = Contenido();
            transporte.Rpc("myg_nube_crear", peticion =>
            {
                Parametro(peticion, "p_id", ProyectoId);
                Parametro(peticion, "p_nombre", "Proyecto de prueba");
                Parametro(peticion, "p_contenido", contenido);
                Parametro(peticion, "p_alcance", "obra");
                return Json(Proyecto(contenido, "propietario", revision: 1));
            });
            var creado = await cliente.CrearProyectoAsync(ProyectoId, "Proyecto de prueba", contenido, "obra");
            Igual(creado.Id == ProyectoId && creado.Rol == "propietario" && creado.Revision == 1, "Respuesta de creación incorrecta.");
            Igual(JsonElement.DeepEquals(creado.Contenido, contenido), "Contenido creado diferente al confirmado.");
            transporte.Rpc("myg_nube_abrir", peticion =>
            {
                Parametro(peticion, "p_id", ProyectoId);
                return Json(Proyecto(contenido));
            });
            var abierto = await cliente.AbrirProyectoAsync(ProyectoId);
            Igual(abierto.Id == ProyectoId && abierto.Contenido.GetProperty("version").GetInt32() == 2, "El contenido quedó inválido al cerrar JsonDocument.");
            transporte.Rpc("myg_nube_guardar", peticion =>
            {
                Parametro(peticion, "p_id", ProyectoId);
                Parametro(peticion, "p_operacion", OperacionId);
                Parametro(peticion, "p_revision", 3L);
                Parametro(peticion, "p_contenido", contenido);
                return Json(Guardado("aplicada"));
            });
            var guardado = await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, contenido);
            Igual(guardado.Estado == "aplicada" && guardado.Revision == 4 && guardado.OperacionId == OperacionId, "Resultado guardado incorrecto.");
            Igual(JsonElement.DeepEquals(guardado.Contenido, contenido), "Se perdió el contenido confirmado.");
            transporte.Completo();
        }
    }

    private static async Task Conflicto()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            var remoto = Contenido("{\"presupuestos\":[{\"nombre\":\"Cambio de otro usuario\"}]}");
            transporte.Rpc("myg_nube_guardar", _ => Json(Guardado("conflicto", 9, remoto)));
            var resultado = await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, Contenido());
            Igual(resultado.Estado == "conflicto" && resultado.Revision == 9, "No se comunicó el conflicto de revisión.");
            Igual(JsonElement.DeepEquals(resultado.Contenido, remoto), "Se sustituyó el contenido del servidor por la copia local.");
            transporte.Completo();
        }
    }

    private static async Task SolicitudSinPermiso()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            transporte.Rpc("myg_nube_solicitar", peticion =>
            {
                Parametro(peticion, "p_codigo", "MYG-PRUEBA-001");
                return Json(new { estado = "recibida" });
            });
            await cliente.SolicitarAccesoAsync(" myg-prueba-001 ");
            transporte.Rpc("myg_nube_abrir", _ => Json(new { code = "42501", message = "detalle reservado del servidor" }, HttpStatusCode.Forbidden));
            var error = await Rechaza(async () => await cliente.AbrirProyectoAsync(ProyectoId));
            Igual(error.AccesoDenegado && error.Codigo == "42501", "Solicitar acceso concedió acceso antes de la aprobación.");
            Igual(!error.Message.Contains("detalle reservado", StringComparison.Ordinal), "Se mostró el cuerpo privado del servidor.");
            transporte.Completo();
        }
    }

    private static async Task MiembrosYSolicitudes()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            transporte.Rpc("myg_nube_miembros", peticion =>
            {
                Parametro(peticion, "p_id", ProyectoId);
                return Json(new[] { new { usuario_id = UsuarioId, rol = "propietario" }, new { usuario_id = OtroUsuarioId, rol = "lector" } });
            });
            var miembros = await cliente.ListarMiembrosAsync(ProyectoId);
            Igual(miembros.Count == 2 && miembros[0].UsuarioId == UsuarioId.ToString("D") && miembros[1].Rol == "lector", "Miembros incorrectos.");
            transporte.Rpc("myg_nube_solicitudes", peticion =>
            {
                Parametro(peticion, "p_id", ProyectoId);
                return Json(new[] { new { usuario_id = OtroUsuarioId, estado = "pendiente" } });
            });
            var solicitudes = await cliente.ListarSolicitudesAsync(ProyectoId);
            Igual(solicitudes.Count == 1 && solicitudes[0].UsuarioId == OtroUsuarioId.ToString("D") && solicitudes[0].Estado == "pendiente", "Solicitudes incorrectas.");
            transporte.Completo();
        }
    }

    private static async Task Administracion()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            foreach (bool aprobar in new[] { true, false })
            {
                transporte.Rpc("myg_nube_resolver", peticion =>
                {
                    Parametro(peticion, "p_id", ProyectoId);
                    Parametro(peticion, "p_usuario", OtroUsuarioId.ToString("D"));
                    Parametro(peticion, "p_rol", "editor");
                    Parametro(peticion, "p_aprobar", aprobar);
                    return Json(true);
                });
                await cliente.ResolverSolicitudAsync(ProyectoId, OtroUsuarioId.ToString("D"), "editor", aprobar);
            }
            foreach (string? rol in new string?[] { "administrador", "editor", "lector", null })
            {
                transporte.Rpc("myg_nube_rol", peticion =>
                {
                    Parametro(peticion, "p_id", ProyectoId);
                    Parametro(peticion, "p_usuario", OtroUsuarioId.ToString("D"));
                    Parametro(peticion, "p_rol", rol);
                    return Json(true);
                });
                await cliente.CambiarRolAsync(ProyectoId, OtroUsuarioId.ToString("D"), rol);
            }
            transporte.Completo();
        }
    }

    private static async Task RolesYAlcances()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            foreach (string rol in new[] { "propietario", "administrador", "editor", "lector" })
                foreach (string alcance in new[] { "obra", "base" })
                {
                    transporte.Rpc("myg_nube_abrir", _ => Json(Proyecto(rol: rol, alcance: alcance)));
                    var abierto = await cliente.AbrirProyectoAsync(ProyectoId);
                    Igual(abierto.Rol == rol && abierto.Alcance == alcance, "Se cambió el rol o alcance del servidor.");
                }
            transporte.Completo();
        }
    }

    private static async Task SinSesion()
    {
        var transporte = new Transporte();
        using var cliente = new ClienteSupabase("https://pruebas.supabase.co", Clave, transporte);
        var error = await Rechaza(async () => await cliente.ListarProyectosAsync());
        Igual(error.NecesitaIniciarSesion && transporte.Peticiones.Count == 0, "Se efectuó una petición sin sesión.");
        error = await Rechaza(async () => await cliente.AbrirProyectoAsync(ProyectoId));
        Igual(error.NecesitaIniciarSesion, "Abrir requiere sesión autenticada.");
    }

    private static async Task Renovacion()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            byte[]? bytes = null;
            transporte.Rpc("myg_nube_guardar", peticion =>
            {
                Igual(peticion.Token == "acceso_original", "El primer intento no usó la sesión inicial.");
                bytes = peticion.Cuerpo;
                Parametro(peticion, "p_operacion", OperacionId);
                return Json(new { code = "PGRST301" }, HttpStatusCode.Unauthorized);
            });
            transporte.Responder("/auth/v1/token?grant_type=refresh_token", peticion =>
            {
                Igual(peticion.Token is null, "La renovación filtró el token antiguo como Bearer.");
                Parametro(peticion, "refresh_token", "refresco_de_prueba");
                return SesionJson("acceso_renovado", UsuarioId);
            });
            transporte.Rpc("myg_nube_guardar", peticion =>
            {
                Igual(peticion.Token == "acceso_renovado", "El reenvío no usó el token renovado.");
                Igual(bytes is not null && bytes.SequenceEqual(peticion.Cuerpo), "Renovar alteró UUID o bytes de la operación pendiente.");
                return Json(Guardado("aplicada"));
            });
            var resultado = await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, Contenido());
            Igual(resultado.OperacionId == OperacionId && cliente.UsuarioId == UsuarioId.ToString("D"), "Renovar alteró identidad u operación.");
            transporte.Completo();
        }
    }

    private static async Task EntradasInvalidas()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            await Rechaza(async () => await cliente.AbrirProyectoAsync(Guid.Empty));
            await Rechaza(async () => await cliente.CrearProyectoAsync(ProyectoId, " ", Contenido(), "obra"));
            await Rechaza(async () => await cliente.CrearProyectoAsync(ProyectoId, "Proyecto", Contenido(), "desconocido"));
            await Rechaza(async () => await cliente.CrearProyectoAsync(ProyectoId, "Proyecto", Contenido("[]"), "obra"));
            await Rechaza(async () => await cliente.GuardarProyectoAsync(ProyectoId, Guid.Empty, 3, Contenido()));
            await Rechaza(async () => await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 0, Contenido()));
            await Rechaza(async () => await cliente.SolicitarAccesoAsync(" "));
            await Rechaza(async () => await cliente.ResolverSolicitudAsync(ProyectoId, "usuario-invalido", "editor", true));
            await Rechaza(async () => await cliente.CambiarRolAsync(ProyectoId, OtroUsuarioId.ToString("D"), "propietario"));
            Igual(transporte.Peticiones.Count == 1, "Una entrada inválida llegó al servidor.");
            transporte.Completo();
        }
    }

    private static async Task IdentidadCambiada()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            transporte.Rpc("myg_nube_guardar", _ => Json(new { }, HttpStatusCode.Unauthorized));
            transporte.Responder("/auth/v1/token?grant_type=refresh_token", _ => SesionJson("token_de_otra_identidad", OtroUsuarioId));
            var error = await Rechaza(async () => await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, Contenido()));
            Igual(error.NecesitaIniciarSesion && !cliente.SesionIniciada && cliente.UsuarioId is null, "Se aceptó un cambio de identidad durante la renovación.");
            Igual(transporte.Peticiones.Count == 3, "Se reenvió la escritura con otra identidad.");
            transporte.Completo();
        }
    }

    private static async Task Revocacion()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            transporte.Rpc("myg_nube_guardar", _ => Json(new { code = "42501", message = "privado: permiso revocado" }, HttpStatusCode.Forbidden));
            var error = await Rechaza(async () => await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, Contenido()));
            Igual(error.AccesoDenegado && !error.EsErrorDeConexion && error.Codigo == "42501", "La revocación se trató como fallo de red o éxito.");
            Igual(cliente.SesionIniciada && !error.Message.Contains("privado:", StringComparison.Ordinal), "La revocación borró la sesión o filtró detalles.");
            transporte.Completo();
        }
    }

    private static async Task VinculoNoVerificado()
    {
        foreach (bool codigoReservado in new[] { true, false })
        {
            var (cliente, transporte) = await Sesion();
            using (cliente)
            {
                transporte.Rpc("myg_nube_abrir", _ => Json(new
                {
                    code = codigoReservado ? "42501" : "P0001",
                    message = "MYG_VINCULO_NO_VERIFICADO"
                }, HttpStatusCode.BadRequest));
                var error = await Rechaza(async () => await cliente.AbrirProyectoAsync(ProyectoId));
                Igual(error.VinculoNoVerificado == codigoReservado, "El vínculo requiere la pareja de código y mensaje reservados.");
                Igual(!error.Message.Contains("detalle privado", StringComparison.Ordinal), "Se filtró el mensaje remoto.");
                transporte.Completo();
            }
        }
    }

    private static async Task ErrorTransitorio()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            foreach (var estado in new[] { HttpStatusCode.ServiceUnavailable, HttpStatusCode.InternalServerError, HttpStatusCode.TooManyRequests })
            {
                transporte.Rpc("myg_nube_guardar", _ => Json(new { code = "XX000", message = "contenido reservado del servidor" }, estado));
                var error = await Rechaza(async () => await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, Contenido()));
                Igual(error.EsErrorDeConexion && !error.AccesoDenegado && !error.NecesitaIniciarSesion,
                    $"Un HTTP {(int)estado} no se trató como error transitorio.");
                Igual(!error.Message.Contains("reservado", StringComparison.Ordinal) && !error.Message.Contains("DEMO", StringComparison.Ordinal),
                    "El mensaje Nube revela detalles remotos o instrucciones DEMO.");
                Igual(cliente.SesionIniciada && cliente.UsuarioId == UsuarioId.ToString("D"),
                    $"Un HTTP {(int)estado} cambió la identidad autenticada.");
            }
            transporte.Completo();
        }
    }

    private static async Task Cancelacion()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            using var cancelada = new CancellationTokenSource();
            cancelada.Cancel();
            await EsperarCancelacion(async () => await cliente.ListarProyectosAsync(cancelada.Token));
            Igual(transporte.Peticiones.Count == 1, "Una cancelación previa llegó al transporte.");
            var recibida = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            transporte.ResponderAsync("/rest/v1/rpc/myg_nube_listar", async (_, token) =>
            {
                recibida.SetResult();
                await Task.Delay(Timeout.Infinite, token);
                throw new InvalidOperationException("No debe finalizar sin cancelación.");
            });
            using var durante = new CancellationTokenSource();
            Task pendiente = cliente.ListarProyectosAsync(durante.Token);
            await recibida.Task.WaitAsync(TimeSpan.FromSeconds(5));
            using var enEspera = new CancellationTokenSource();
            Task esperando = cliente.ListarProyectosAsync(enEspera.Token);
            enEspera.Cancel();
            await EsperarCancelacion(() => esperando);
            Igual(transporte.Peticiones.Count == 2, "Cancelar la solicitud en espera dejó que llegara al transporte.");
            durante.Cancel();
            await EsperarCancelacion(() => pendiente);
            Igual(cliente.SesionIniciada, "Cancelar una consulta eliminó la sesión.");
            transporte.Rpc("myg_nube_listar", _ => Json(Array.Empty<object>()));
            Igual((await cliente.ListarProyectosAsync()).Count == 0, "La cancelación dejó bloqueado el cliente.");
            transporte.Completo();
        }
    }

    private static async Task EsperarCancelacion(Func<Task> accion)
    {
        try { await accion(); }
        catch (OperationCanceledException) { _comprobaciones++; return; }
        throw new InvalidOperationException("No se propagó la cancelación explícita.");
    }

    private static async Task DocumentoGrande()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            string grande = new('x', 300 * 1024);
            var contenidoGrande = Contenido(JsonSerializer.Serialize(new { texto = grande }));
            transporte.Rpc("myg_nube_abrir", _ => Json(Proyecto(contenidoGrande)));
            var abierto = await cliente.AbrirProyectoAsync(ProyectoId);
            Igual(abierto.Contenido.GetProperty("texto").GetString()?.Length == grande.Length, "Nube v2 heredó el límite DEMO de 256 KiB.");
            var profundo = Contenido("{\"nodo\":" + new string('[', 70) + "0" + new string(']', 70) + "}");
            transporte.Rpc("myg_nube_abrir", _ => JsonProfundo(Proyecto(profundo)));
            abierto = await cliente.AbrirProyectoAsync(ProyectoId);
            Igual(abierto.Contenido.GetProperty("nodo").ValueKind == JsonValueKind.Array, "Nube v2 heredó la profundidad DEMO de 32.");
            transporte.Completo();
        }
    }

    private static HttpResponseMessage JsonProfundo(object valor) => new(HttpStatusCode.OK)
    {
        Content = new StringContent(JsonSerializer.Serialize(valor, new JsonSerializerOptions { MaxDepth = 256 }), Encoding.UTF8, "application/json")
    };

    private static async Task ProyectoGrande()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            var contenido = Contenido("{\"texto\":\"INICIO" + new string('x', 48 * 1024 * 1024) + "FIN\"}");
            void Verificar(JsonElement copia)
            {
                Igual(JsonElement.DeepEquals(copia, contenido), "El contenido de 48 MiB se truncó o alteró.");
            }
            transporte.Rpc("myg_nube_crear", p =>
            {
                Verificar(p.Json.GetProperty("p_contenido"));
                return Json(Proyecto(contenido, "propietario", "base", 1));
            });
            var creado = await cliente.CrearProyectoAsync(ProyectoId, "Base grande", contenido, "base");
            Verificar(creado.Contenido);
            Igual(creado.Alcance == "base" && creado.Revision == 1, "La base grande perdió su alcance o revisión.");
            transporte.Rpc("myg_nube_abrir", _ => Json(Proyecto(contenido, alcance: "base")));
            Verificar((await cliente.AbrirProyectoAsync(ProyectoId)).Contenido);
            transporte.Rpc("myg_nube_guardar", p =>
            {
                Verificar(p.Json.GetProperty("p_contenido"));
                Parametro(p, "p_operacion", OperacionId);
                return Json(Guardado("aplicada", contenido: contenido));
            });
            var guardado = await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, contenido);
            Verificar(guardado.Contenido);
            Igual(guardado.Revision == 4 && guardado.OperacionId == OperacionId, "El guardado grande perdió su confirmación.");
            transporte.Rpc("myg_nube_crear", _ => Json(new { code = "22023", message = "MYG_CONTENIDO_INVALIDO_MAX_32_MIB" }, HttpStatusCode.BadRequest));
            var antiguo = await Rechaza(async () => await cliente.CrearProyectoAsync(ProyectoId, "Base grande", contenido, "base"));
            Igual(antiguo.Codigo == "22023" && antiguo.Message.Contains("Supabase", StringComparison.Ordinal)
                && antiguo.Message.Contains("pendiente", StringComparison.Ordinal), "El servidor antiguo no indica cómo actualizar y recuperar el intento.");
            transporte.Rpc("myg_nube_guardar", _ => Json(new { code = "22023", message = "MYG_CONTENIDO_INVALIDO_MAX_127_MIB" }, HttpStatusCode.BadRequest));
            var exceso = await Rechaza(async () => await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, Contenido()));
            Igual(exceso.Message.Contains("127 MiB", StringComparison.Ordinal) && cliente.SesionIniciada,
                "El rechazo de tamaño del servidor ocultó su límite o cerró la sesión.");
            transporte.Completo();
        }
    }

    private static async Task LimiteTamano()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            int peticiones = transporte.Peticiones.Count;
            using var excedido = DocumentoTextoGrande(300 * 1024 * 1024 + 1, out _);
            var errorTamano = await Rechaza(async () => await cliente.CrearProyectoAsync(ProyectoId, "Exceso", excedido.RootElement, "base"));
            Igual(errorTamano.Message.Contains("300 MiB", StringComparison.Ordinal)
                && errorTamano.Message.Contains("ocupa", StringComparison.Ordinal)
                && errorTamano.Message.Contains("Publicaciones pendientes", StringComparison.Ordinal),
                "El exceso de tamaño no indica el tamaño preparado y dónde retirar el intento.");
            Igual(transporte.Peticiones.Count == peticiones, "El contenido que excede el límite llegó al transporte.");
            transporte.Rpc("myg_nube_abrir", _ => new HttpResponseMessage(HttpStatusCode.OK) { Content = new ContenidoLimitado(320L * 1024 * 1024 + 1, longitudConocida: true) });
            Igual((await Rechaza(async () => await cliente.AbrirProyectoAsync(ProyectoId))).EsErrorDeConexion, "No se rechazó una respuesta que anuncia más de 320 MiB.");
            transporte.Rpc("myg_nube_abrir", _ => new HttpResponseMessage(HttpStatusCode.OK) { Content = new ContenidoLimitado(320L * 1024 * 1024 + 1, longitudConocida: false) });
            Igual((await Rechaza(async () => await cliente.AbrirProyectoAsync(ProyectoId))).EsErrorDeConexion, "No se limitó la respuesta sin Content-Length.");
            transporte.Completo();
        }
    }

    private static async Task ProyectoAmpliado()
    {
        const int longitudTexto = 130 * 1024 * 1024;
        using var documento = DocumentoTextoGrande(longitudTexto, out var bytesContenido);
        var contenido = documento.RootElement;
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            transporte.Rpc("myg_nube_capacidades", _ => Json(new { paquete_compacto = 2, cambios = 1 }));
            var previo = await Rechaza(() => cliente.CrearProyectoAsync(ProyectoId, "Base ampliada", contenido, "base"));
            Igual(previo.Message.Contains("127 MiB", StringComparison.Ordinal)
                && previo.Message.Contains("20261026_publicacion_ligera.sql", StringComparison.Ordinal)
                && previo.Message.Contains("pendiente", StringComparison.Ordinal)
                && cliente.SesionIniciada && transporte.Peticiones.Count == 2,
                "el servidor anterior recibió una publicación grande o el rechazo perdió su recuperación.");
            // El primer rechazo no fija para siempre las capacidades anteriores.
            transporte.Rpc("myg_nube_capacidades", _ => Json(new { paquete_compacto = 2, cambios = 1, max_contenido_mib = 300 }));
            byte[]? original = null;
            transporte.Rpc("myg_nube_crear", p =>
            {
                original = p.Cuerpo;
                using var solicitud = JsonDocument.Parse(p.Cuerpo);
                Igual(p.Cuerpo.Length > 127 * 1024 * 1024
                    && solicitud.RootElement.GetProperty("p_id").GetGuid() == ProyectoId
                    && JsonElement.DeepEquals(solicitud.RootElement.GetProperty("p_contenido"), contenido),
                    "el nuevo límite truncó o cambió la solicitud de 130 MiB.");
                return new HttpResponseMessage(HttpStatusCode.Unauthorized);
            });
            transporte.Responder("/auth/v1/token?grant_type=refresh_token", _ => SesionJson("acceso_renovado", UsuarioId));
            transporte.Rpc("myg_nube_crear", p =>
            {
                Igual(original is not null && p.Cuerpo.AsSpan().SequenceEqual(original),
                    "renovar la sesión cambió el UUID o los bytes de la publicación grande.");
                return ProyectoGrandeUtf8(bytesContenido);
            });
            var creado = await cliente.CrearProyectoAsync(ProyectoId, "Base ampliada", contenido, "base");
            Igual(creado.Id == ProyectoId && creado.Revision == 1 && creado.Alcance == "base"
                && JsonElement.DeepEquals(creado.Contenido, contenido),
                "la respuesta de más de 127 MiB no conservó la base completa.");
            foreach (var rechazo in new[]
            {
                (Codigo: "22023", Mensaje: "MYG_CONTENIDO_INVALIDO_MAX_300_MIB", Esperado: "300 MiB"),
                (Codigo: "54000", Mensaje: "total size of jsonb array elements exceeds maximum: detalle_remoto_privado", Esperado: "JSONB")
            })
            {
                transporte.Rpc("myg_nube_guardar", _ => Json(new { code = rechazo.Codigo, message = rechazo.Mensaje },
                    rechazo.Codigo == "54000" ? HttpStatusCode.InternalServerError : HttpStatusCode.BadRequest));
                var error = await Rechaza(() => cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 1, Contenido()));
                Igual(error.Codigo == rechazo.Codigo && error.Message.Contains(rechazo.Esperado, StringComparison.Ordinal)
                    && error.Message.Contains("pendiente", StringComparison.Ordinal)
                    && !error.Message.Contains("detalle_remoto_privado", StringComparison.Ordinal)
                    && !error.EsErrorDeConexion && !error.NecesitaIniciarSesion && cliente.SesionIniciada,
                    "el rechazo de tamaño interno ocultó su causa o cambió el estado de sesión.");
            }
            foreach (var rechazo in new[]
            {
                (Estado: HttpStatusCode.RequestEntityTooLarge, Esperado: "límite HTTP", Conexion: false),
                (Estado: HttpStatusCode.RequestTimeout, Esperado: "tiempo de espera", Conexion: true),
                (Estado: HttpStatusCode.GatewayTimeout, Esperado: "tiempo de espera", Conexion: true)
            })
            {
                transporte.Rpc("myg_nube_guardar", _ => new HttpResponseMessage(rechazo.Estado)
                { Content = new StringContent("detalle_remoto_privado", Encoding.UTF8, "text/html") });
                var error = await Rechaza(() => cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 1, Contenido()));
                Igual(error.Message.Contains(rechazo.Esperado, StringComparison.Ordinal)
                    && error.Message.Contains("pendiente", StringComparison.Ordinal)
                    && !error.Message.Contains("detalle_remoto_privado", StringComparison.Ordinal)
                    && error.EsErrorDeConexion == rechazo.Conexion && !error.NecesitaIniciarSesion
                    && cliente.SesionIniciada && cliente.UsuarioId == UsuarioId.ToString("D"),
                    "el rechazo HTTP de tamaño o plazo cambió la identidad o no explicó su recuperación.");
            }
            transporte.Completo();
        }
    }

    private static JsonDocument DocumentoTextoGrande(int longitudTexto, out byte[] cuerpo)
    {
        ReadOnlySpan<byte> prefijo = "{\"texto\":\""u8;
        ReadOnlySpan<byte> sufijo = "\"}"u8;
        cuerpo = new byte[checked(prefijo.Length + longitudTexto + sufijo.Length)];
        prefijo.CopyTo(cuerpo);
        cuerpo.AsSpan(prefijo.Length, longitudTexto).Fill((byte)'x');
        sufijo.CopyTo(cuerpo.AsSpan(prefijo.Length + longitudTexto));
        return JsonDocument.Parse(cuerpo);
    }

    private static HttpResponseMessage ProyectoGrandeUtf8(ReadOnlySpan<byte> contenido)
    {
        byte[] prefijo = Encoding.UTF8.GetBytes($"{{\"id\":\"{ProyectoId:D}\",\"codigo\":\"MYG-GRANDE\",\"nombre\":\"Base ampliada\",\"rol\":\"propietario\",\"revision\":1,\"alcance\":\"base\",\"contenido\":");
        byte[] cuerpo = new byte[checked(prefijo.Length + contenido.Length + 1)];
        prefijo.CopyTo(cuerpo, 0);
        contenido.CopyTo(cuerpo.AsSpan(prefijo.Length));
        cuerpo[^1] = (byte)'}';
        var respuesta = new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(cuerpo) };
        respuesta.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        return respuesta;
    }

    private static async Task LimiteProfundidad()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            transporte.Rpc("myg_nube_abrir", _ => new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"nodo\":" + new string('[', 129) + "0" + new string(']', 129) + "}", Encoding.UTF8, "application/json")
            });
            Igual((await Rechaza(async () => await cliente.AbrirProyectoAsync(ProyectoId))).EsErrorDeConexion, "Se admitió una respuesta más profunda que 128.");
            transporte.Completo();
        }
    }

    private static async Task RespuestaInvalida()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            foreach (object respuesta in new object[]
            {
                new { id = "no-es-uuid", codigo = "MYG-PRUEBA-001", nombre = "Proyecto", rol = "editor", revision = 1, alcance = "obra", contenido = Contenido() },
                new { id = ProyectoId, codigo = "MYG-PRUEBA-001", nombre = "Proyecto", rol = "superusuario", revision = 1, alcance = "obra", contenido = Contenido() },
                new { id = ProyectoId, codigo = "MYG-PRUEBA-001", nombre = "Proyecto", rol = "editor", revision = 0, alcance = "obra", contenido = Contenido() },
                new { id = ProyectoId, codigo = "MYG-PRUEBA-001", nombre = "Proyecto", rol = "editor", revision = 1, alcance = "desconocido", contenido = Contenido() },
                new { id = OtroUsuarioId, codigo = "MYG-PRUEBA-001", nombre = "Proyecto", rol = "editor", revision = 1, alcance = "obra", contenido = Contenido() }
            })
            {
                transporte.Rpc("myg_nube_abrir", _ => Json(respuesta));
                await Rechaza(async () => await cliente.AbrirProyectoAsync(ProyectoId));
            }
            transporte.Rpc("myg_nube_guardar", _ => Json(new { estado = "aplicada", revision = 4, contenido = Contenido(), operacion_id = OtroUsuarioId }));
            await Rechaza(async () => await cliente.GuardarProyectoAsync(ProyectoId, OperacionId, 3, Contenido()));
            transporte.Rpc("myg_nube_miembros", _ => Json(new[] { new { usuario_id = UsuarioId, rol = "editor" }, new { usuario_id = UsuarioId, rol = "lector" } }));
            await Rechaza(async () => await cliente.ListarMiembrosAsync(ProyectoId));
            transporte.Rpc("myg_nube_solicitudes", _ => Json(new[] { new { usuario_id = UsuarioId, estado = "concedido-localmente" } }));
            await Rechaza(async () => await cliente.ListarSolicitudesAsync(ProyectoId));
            transporte.Completo();
        }
    }

    private static async Task CompatibilidadDemo()
    {
        var (cliente, transporte) = await Sesion();
        using (cliente)
        {
            const string ruta = "/rest/v1/myg_partidas?select=descripcion,unidad,cantidad,revision_nube&proyecto_id=eq.MYG-DEMO-COLABORACION&presupuesto_id=eq.MYG-DEMO-PRESUPUESTO&id=eq.MYG-DEMO-PARTIDA&eliminado=eq.false";
            transporte.Responder(ruta, _ => Json(new[] { new { descripcion = "Partida DEMO", unidad = "m3", cantidad = 2.5m, revision_nube = 2 } }));
            var partida = await cliente.LeerPartidaAsync();
            Igual(partida.Cantidad == 2.5m && partida.Revision == 2, "Cambió el contrato de lectura DEMO.");
            transporte.Rpc("myg_cambiar_cantidad", peticion =>
            {
                Parametro(peticion, "p_operacion_id", OperacionId);
                Parametro(peticion, "p_cantidad", 3.75m);
                return Json(new { estado = "aplicada", cantidad = 3.75m, revision_nube = 3, operacion_id = OperacionId });
            });
            var guardado = await cliente.GuardarCantidadAsync(new OperacionCantidad(OperacionId, 3.75m, 2));
            Igual(!guardado.Conflicto && guardado.RevisionConfirmada == 3, "Cambió el guardado DEMO.");
            transporte.Responder(ruta, _ => Json(new[] { new { descripcion = new string('x', 300 * 1024), unidad = "m", cantidad = 1m, revision_nube = 1 } }));
            await Rechaza(async () => await cliente.LeerPartidaAsync());
            transporte.Responder(ruta, _ => new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("[" + new string('[', 40) + "0" + new string(']', 40) + "]", Encoding.UTF8, "application/json")
            });
            await Rechaza(async () => await cliente.LeerPartidaAsync());
            transporte.Completo();
        }
    }

    private sealed record Peticion(string Ruta, string Metodo, string? Token, byte[] Cuerpo)
    {
        public JsonElement Json => Cuerpo.Length == 0 ? Contenido("{}") : Contenido(Encoding.UTF8.GetString(Cuerpo));
    }

    /// <summary>El handler intercepta todas las solicitudes; las pruebas nunca abren conexiones de red.</summary>
    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<(string Ruta, Func<Peticion, CancellationToken, Task<HttpResponseMessage>> Respuesta)> _respuestas = new();
        public List<Peticion> Peticiones { get; } = new();

        public void Responder(string ruta, Func<Peticion, HttpResponseMessage> respuesta) =>
            ResponderAsync(ruta, (peticion, _) => Task.FromResult(respuesta(peticion)));

        public void Rpc(string nombre, Func<Peticion, HttpResponseMessage> respuesta) => Responder("/rest/v1/rpc/" + nombre, respuesta);

        public void ResponderAsync(string ruta, Func<Peticion, CancellationToken, Task<HttpResponseMessage>> respuesta) =>
            _respuestas.Enqueue((ruta, respuesta));

        public void Completo() => Igual(_respuestas.Count == 0, "No se enviaron todas las solicitudes esperadas.");

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Igual(request.RequestUri?.Scheme == "https" && request.RequestUri.Host == "pruebas.supabase.co", "Destino HTTP inesperado.");
            Igual(request.Headers.TryGetValues("apikey", out var claves) && claves.SequenceEqual(new[] { Clave }), "Falta apikey o se usó una clave diferente.");
            Igual(request.Headers.Accept.Any(valor => valor.MediaType == "application/json"), "Falta Accept JSON.");
            Igual(_respuestas.Count > 0, "Se hizo una solicitud inesperada o un reintento adicional.");
            var esperado = _respuestas.Dequeue();
            var peticion = new Peticion(request.RequestUri!.PathAndQuery, request.Method.Method,
                request.Headers.Authorization?.Parameter,
                request.Content is null ? Array.Empty<byte>() : await request.Content.ReadAsByteArrayAsync(cancellationToken));
            Peticiones.Add(peticion);
            Igual(peticion.Ruta == esperado.Ruta, $"Ruta inesperada: {peticion.Ruta}; se esperaba {esperado.Ruta}.");
            if (peticion.Ruta.StartsWith("/rest/", StringComparison.Ordinal))
            {
                Igual(request.Headers.Authorization?.Scheme == "Bearer" && !string.IsNullOrEmpty(peticion.Token), "Falta autenticación Bearer en la llamada protegida.");
                Igual(peticion.Metodo == (peticion.Ruta.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal) ? "POST" : "GET"), "Método HTTP incorrecto.");
            }
            if (request.Content is not null)
                Igual(request.Content.Headers.ContentType?.MediaType == "application/json", "El cuerpo no se envía como JSON.");
            return await esperado.Respuesta(peticion, cancellationToken);
        }
    }

    private sealed class ContenidoLimitado : HttpContent
    {
        private readonly long _longitud;
        private readonly bool _longitudConocida;
        public ContenidoLimitado(long longitud, bool longitudConocida)
        {
            _longitud = longitud;
            _longitudConocida = longitudConocida;
            Headers.ContentType = new MediaTypeHeaderValue("application/json");
            if (longitudConocida) Headers.ContentLength = longitud;
        }
        protected override bool TryComputeLength(out long length) { length = _longitud; return _longitudConocida; }
        protected override Task SerializeToStreamAsync(Stream stream, TransportContext? context) => throw new InvalidOperationException("La lectura debe usar el flujo acotado.");
        protected override Task<Stream> CreateContentReadStreamAsync() => Task.FromResult<Stream>(new EspaciosStream(_longitud));
        protected override Task<Stream> CreateContentReadStreamAsync(CancellationToken cancellationToken) => CreateContentReadStreamAsync();
    }

    private sealed class EspaciosStream(long restantes) : Stream
    {
        public override bool CanRead => true;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
        public override int Read(byte[] buffer, int offset, int count)
        {
            int cuantos = (int)Math.Min(count, restantes);
            buffer.AsSpan(offset, cuantos).Fill((byte)' ');
            restantes -= cuantos;
            return cuantos;
        }
        public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            int cuantos = (int)Math.Min(buffer.Length, restantes);
            buffer.Span[..cuantos].Fill((byte)' ');
            restantes -= cuantos;
            return ValueTask.FromResult(cuantos);
        }
        public override void Flush() => throw new NotSupportedException();
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
    }
}
