using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>El flujo de colaboradores no publica una obra independiente ni concede acceso a la base completa.</summary>
internal static class ColaboracionObraBaseCheck
{
    private const string Servidor = "https://colaboracion-sin-copia.supabase.co";
    private const string Clave = "sb_publishable_colaboracion_sin_copia_qa";
    private static readonly Guid Usuario = Guid.Parse("4de83c0a-03f5-4317-97d2-5e83bf5fe7d4");
    private static readonly Guid Base = Guid.Parse("a3eced97-4609-4599-8233-9b95d78c5685");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string temporal = Path.Combine(Path.GetTempPath(), "MYG-Colaboracion-Sin-Copia-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temporal);
        try
        {
            string ruta = Path.Combine(temporal, "dos-obras.sqlite");
            var compartible = MYGProyectoStorage.Nuevo("Obra compartible QA", "Presupuesto compartible QA");
            var privada = MYGProyectoStorage.Nuevo("Obra privada QA", "Presupuesto privado QA");
            MYGProyectoStorage.Guardar(ruta, compartible);
            MYGProyectoStorage.Guardar(ruta, privada);
            string original = Hash(ruta);
            using var http = new Transporte();
            using var cliente = new ClienteSupabase(Servidor, Clave, http);
            await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
            Exige(http.Peticiones == 1 && cliente.SesionIniciada,
                "la prueba debe usar una sesión autenticada y una única solicitud de ingreso simulada.");

            string nueva = Path.Combine(temporal, "publicaciones-no-creadas");
            var servicio = new PublicacionObraBasePendiente(nueva, Servidor, Usuario.ToString("D"));
            await ExigirBloqueo(() => servicio.PrepararYEnviarAsync(cliente, Base, ruta, compartible.Id));
            Exige(!Directory.Exists(nueva), "agregar un colaborador no debe preparar carpetas, archivos ni paquetes de publicación.");
            Exige(Hash(ruta) == original, "la base de dos obras debe conservar exactamente sus bytes.");
            Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 2
                && MYGBaseDatos.LeerProyecto(ruta, privada.Id).Nombre == privada.Nombre,
                "la obra privada debe conservar su identidad y contenido sin cambios.");
            Exige(http.Peticiones == 1, "el bloqueo no debe consultar, crear, vincular ni subir nada después del ingreso.");

            // Una ruta inexistente distingue este bloqueo previo de un error al intentar extraer SQLite.
            await ExigirBloqueo(() => servicio.PrepararYEnviarAsync(cliente, Base,
                Path.Combine(temporal, "no-existe.sqlite"), compartible.Id));
            Exige(!Directory.Exists(nueva) && http.Peticiones == 1,
                "la llamada pública directa debe bloquearse antes de leer el archivo o acceder a la red.");

            // Los intentos de la versión anterior se preservan; no se reenvían ni se borran automáticamente.
            string anterior = Path.Combine(temporal, "publicacion-anterior");
            Directory.CreateDirectory(anterior);
            string metadata = Path.Combine(anterior, "intento.json");
            File.WriteAllText(metadata, "{\"qa\":\"pendiente anterior que debe conservarse\"}");
            string huellaAnterior = Hash(metadata);
            var legado = new PublicacionObraBasePendiente(anterior, Servidor, Usuario.ToString("D"));
            await ExigirBloqueo(() => legado.PrepararYEnviarAsync(cliente, Base, ruta, compartible.Id));
            Exige(Directory.EnumerateFiles(anterior, "*", SearchOption.AllDirectories).Count() == 1
                && Hash(metadata) == huellaAnterior,
                "el rechazo debe conservar intactos los archivos pendientes existentes sin agregar otros.");
            Exige(Hash(ruta) == original && http.Peticiones == 1,
                "un intento legado no debe reactivar la publicación independiente ni alterar la base.");
            Console.WriteLine($"OK Colaboración sin copias: {comprobaciones} comprobaciones de bloqueo previo, SQLite de dos obras intacto y HTTP simulado sin publicaciones.");
        }
        finally
        {
            SqliteConnection.ClearAllPools();
            Directory.Delete(temporal, true);
        }
    }

    private static async Task ExigirBloqueo(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error)
        {
            Exige(error.Codigo == "MYG_BASE_REQUIERE_SERVIDOR",
                "debe informar que la colaboración sobre la misma base requiere servidor, sin fingir una copia compartida.");
            return;
        }
        throw new InvalidOperationException("Colaboración sin copias: la API anterior permitió continuar la publicación independiente.");
    }

    private static string Hash(string ruta)
    {
        using var archivo = File.OpenRead(ruta);
        return Convert.ToHexString(SHA256.HashData(archivo));
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Colaboración sin copias: " + detalle);
    }

    private sealed class Transporte : HttpMessageHandler
    {
        internal int Peticiones;

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            Peticiones++;
            if (Peticiones != 1 || solicitud.Method != HttpMethod.Post
                || solicitud.RequestUri?.AbsolutePath != "/auth/v1/token"
                || solicitud.RequestUri.Query != "?grant_type=password")
                throw new InvalidOperationException("Colaboración sin copias: se intentó una operación de nube después del ingreso.");
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonSerializer.Serialize(new
                {
                    access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600,
                    user = new { id = Usuario }
                }), Encoding.UTF8, "application/json")
            });
        }
    }
}
