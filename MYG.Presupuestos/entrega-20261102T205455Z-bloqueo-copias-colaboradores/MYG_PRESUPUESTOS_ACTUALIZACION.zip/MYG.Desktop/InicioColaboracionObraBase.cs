#nullable enable
using MYG.Colaboracion;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private bool abriendoColaboradores;

    private Task ColaboracionObraBaseAsync(string ruta, string documentoId, bool agregar) =>
        GestionarColaboradoresAsync(agregar, async cliente =>
        {
            var vinculo = VinculoColaboracionObra(ruta, documentoId)
                ?? throw new InvalidOperationException("La obra no tiene vínculo de nube. Vuelva a abrirla desde Nube MYG.");
            SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
            if (CopiaSqliteNube.EsBase(ruta))
                return await PrepararColaboracionObraAsync(cliente, vinculo.ProyectoId, ruta, documentoId);
            var lista = await cliente.ListarProyectosAsync();
            ComprobarClienteActual(cliente);
            return lista.SingleOrDefault(p => p.Id == vinculo.ProyectoId && p.Alcance == "obra" && !p.EliminacionPendiente)
                ?? throw new InvalidOperationException("La obra ya no está disponible para su cuenta. Actualice sus permisos.");
        });

    // El editor conserva su acceso a la misma gestión independiente; no abre
    // el explorador general ni vuelve a elegir otra obra.
    private Task MostrarColaboracionObraAsync(Guid id) => GestionarColaboradoresAsync(false, async cliente =>
    {
        var lista = await cliente.ListarProyectosAsync();
        ComprobarClienteActual(cliente);
        return lista.SingleOrDefault(p => p.Id == id && p.Alcance == "obra" && !p.EliminacionPendiente)
            ?? throw new InvalidOperationException("La obra no está disponible para su cuenta.");
    });

    private async Task GestionarColaboradoresAsync(bool agregar,
        Func<ClienteSupabase, Task<ProyectoNube?>> preparar)
    {
        if (abriendoColaboradores)
            throw new InvalidOperationException("Espere a que termine la gestión de colaboradores actual.");
        abriendoColaboradores = true;
        try
        {
            RequerirSesion();
            PrepararConfiguracionNube();
            ActualizarSesionNube();
            if (clienteNube is null)
                throw new InvalidOperationException(errorConfiguracionNube
                    ?? "No se encontró la conexión de Nube MYG. Solicite a soporte que revise la instalación.");
            await MYGCargaAnimada.EjecutarAsync(this, "Conectando con su cuenta MYG…", ConectarNubeConMygAsync);
            var cliente = RequerirNube();
            var obra = await preparar(cliente);
            ComprobarClienteActual(cliente);
            if (obra is null) return;
            using var dialogo = new ColaboradoresObraForm(sesion, cliente, obra, agregar);
            await MYGCargaAnimada.EjecutarAsync(this, "Consultando colaboradores de la obra…", dialogo.CargarAsync);
            ComprobarClienteActual(cliente);
            dialogo.ShowDialog(this);
        }
        finally { abriendoColaboradores = false; }
    }

    private Task<ProyectoNube?> PrepararColaboracionObraAsync(ClienteSupabase cliente,
        Guid baseId, string ruta, string documentoId)
    {
        // El protocolo anterior creaba otra publicación y revisiones separadas.
        // No ofrecer ese flujo ni compartir el archivo entero como sustituto.
        throw PublicacionObraBasePendiente.ServicioRequerido();
    }
}
