using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class PublicacionSqlitePendienteCheck
{
    internal static Task RunAsync()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-publicacion-sqlite-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        int comprobaciones = 0;
        void Exigir(bool valor, string mensaje) { comprobaciones++; if (!valor) throw new InvalidOperationException(mensaje); }
        void Rechaza(Action accion, string mensaje)
        {
            bool fallo = false;
            try { accion(); } catch (Exception ex) when (ex is InvalidDataException or IOException or ArgumentException or InvalidOperationException) { fallo = true; }
            Exigir(fallo, mensaje);
        }
        try
        {
            string origen = Path.Combine(carpeta, "origen.sqlite");
            var principal = MYGProyectoStorage.Nuevo("Obra compartida", "Presupuesto");
            principal.FuenteCatalogo = new MYGFuenteDelphin { Id = "CATALOGO-PROPIO", RutaSQLite = origen };
            MYGProyectoStorage.Guardar(origen, principal);
            var otra = MYGProyectoStorage.Nuevo("Obra privada", "Segundo presupuesto");
            MYGProyectoStorage.Guardar(origen, otra);
            string original = Hash(origen);
            var almacen = new ArchivoPublicacionSqlitePendiente(Path.Combine(carpeta, "pendientes"), "https://pruebas.supabase.co", "11111111-1111-4111-8111-111111111111");
            Exigir(almacen.Consultar() is null, "Un almacén nuevo no debe inventar una publicación.");
            var pendiente = almacen.Crear("Publicación SQL", "obra", principal, origen);
            Exigir(Hash(origen) == original, "Preparar/publicar debe conservar el origen byte por byte.");
            Exigir(pendiente.Id != Guid.Empty && pendiente.BytesArchivo == new FileInfo(pendiente.RutaSQLite).Length
                && pendiente.Sha256 == Hash(pendiente.RutaSQLite), "El pendiente debe describir el SQLite exacto.");
            Exigir(MYGBaseDatos.ListarProyectos(pendiente.RutaSQLite).Count == 1
                && MYGBaseDatos.ListarProyectos(pendiente.RutaSQLite)[0].Id == principal.Id,
                "Publicar una obra no debe incluir las otras obras de la base.");
            Exigir(almacen.Consultar() == pendiente && almacen.Leer(pendiente) == pendiente,
                "Reabrir un intento debe conservar UUID, hash y copia congelada.");
            var portable = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(pendiente.RutaSQLite, principal.Id);
            Exigir(portable.FuenteCatalogo.RutaSQLite == pendiente.RutaSQLite,
                "Las autorreferencias deben reubicarse en memoria a la copia descargada.");
            Exigir(MYGBaseDatos.LeerProyecto(pendiente.RutaSQLite, principal.Id).FuenteCatalogo.RutaSQLite
                == ArchivoPublicacionSqlitePendiente.ReferenciaPropia,
                "El archivo compartido no debe depender de la ruta privada del equipo de origen.");
            Rechaza(() => almacen.Crear("Duplicada", "obra", principal, origen), "Otro intento no puede sustituir uno pendiente.");
            var otraCuenta = new ArchivoPublicacionSqlitePendiente(Path.Combine(carpeta, "pendientes"), "https://pruebas.supabase.co", "22222222-2222-4222-8222-222222222222");
            Exigir(otraCuenta.Consultar() is null, "Los intentos deben aislarse por cuenta.");
            Rechaza(() => otraCuenta.Confirmar(pendiente), "Una cuenta no puede confirmar el intento de otra.");
            almacen.Confirmar(pendiente);
            Exigir(almacen.Consultar() is null && File.Exists(pendiente.RutaSQLite),
                "El ACK retira solo el intento activo y conserva la copia recuperable.");
            var baseCompleta = almacen.Crear("Base completa", "base", principal, origen);
            Exigir(MYGBaseDatos.ListarProyectos(baseCompleta.RutaSQLite).Count == 2,
                "El alcance base debe conservar las dos obras.");
            Exigir(Hash(origen) == original, "Sanitizar la copia completa no debe escribir en el original.");
            using (var c = Abrir(baseCompleta.RutaSQLite))
            {
                using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT count(*) FROM usuario";
                Exigir(Convert.ToInt64(cmd.ExecuteScalar()) == 0, "La copia no debe incluir cuentas de acceso Delphin.");
            }
            string retirada = almacen.Retirar(baseCompleta);
            Exigir(almacen.Consultar() is null && retirada == baseCompleta.RutaSQLite && File.Exists(retirada),
                "Retirar debe conservar la copia y no borrar proyectos remotos.");
            using (var c = Abrir(origen))
            {
                using var cmd = c.CreateCommand(); cmd.CommandText = "CREATE TABLE extension_privada(secreto TEXT); INSERT INTO extension_privada VALUES('dato sintético')";
                cmd.ExecuteNonQuery();
            }
            Rechaza(() => almacen.Crear("Extensión desconocida", "base", principal, origen),
                "Las extensiones no reconocidas deben impedir compartir silenciosamente datos de alcance desconocido.");
            Exigir(almacen.Consultar() is null, "Una preparación rechazada no debe dejar un intento activo.");
            var recursos = MYGProyectoStorage.Copia(principal);
            // Un campo de adjunto persistido en una tabla reconocida se valida
            // aun si no está visible en el documento principal del editor.
            using (var c = Abrir(origen))
            {
                using var cmd = c.CreateCommand();
                cmd.CommandText = "INSERT INTO catalogo_insumo(id,codigo,descripcion,unidad,grupo,precio,json_datos,revision,modificado_utc) VALUES('externo','EX','Adjunto','und','Materiales','0','{\"ImagenRuta\":\"imagen.png\"}',1,'2026-10-30')";
                cmd.ExecuteNonQuery();
            }
            Rechaza(() => almacen.Crear("Recurso externo", "obra", recursos, origen),
                "No debe perderse un archivo externo al publicar únicamente SQLite.");
            Exigir(almacen.Consultar() is null, "El rechazo de adjuntos no debe dejar un intento parcial.");
            Console.WriteLine($"OK Publicación SQLite nativa: {comprobaciones} comprobaciones de alcance, portabilidad, origen intacto e intento durable; sin red.");
            return Task.CompletedTask;
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static string Hash(string ruta) { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }
    private static SqliteConnection Abrir(string ruta)
    {
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()); c.Open(); return c;
    }
}
