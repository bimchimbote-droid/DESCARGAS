using System.Security.Cryptography;
using System.Text.Json;
using System.Net;
using System.Text;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class PublicacionBasePendienteCheck
{
    internal static async Task RunAsync()
    {
        string temporal = Path.Combine(Path.GetTempPath(), "myg-base-pendiente-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temporal);
        int comprobaciones = 0;
        void Exigir(bool valor, string mensaje)
        {
            comprobaciones++;
            if (!valor) throw new InvalidOperationException(mensaje);
        }
        void Rechaza(Action accion, string mensaje)
        {
            bool rechazo = false;
            try { accion(); }
            catch (Exception ex) when (ex is ArgumentException or IOException or InvalidOperationException or OperationCanceledException)
            { rechazo = true; }
            Exigir(rechazo, mensaje);
        }

        try
        {
            const string servidor = "https://pruebas.supabase.co";
            const string usuario = "11111111-1111-4111-8111-111111111111";
            string ruta = Path.Combine(temporal, "origen.sqlite");
            string pendientes = Path.Combine(temporal, "pendientes");
            var primera = MYGProyectoStorage.Nuevo("OBRA_ALFA_PRIVADA_739", "Presupuesto alfa");
            var segunda = MYGProyectoStorage.Nuevo("OBRA_BETA_PRIVADA_624", "Presupuesto beta");
            MYGProyectoStorage.Guardar(ruta, primera);
            MYGProyectoStorage.Guardar(ruta, segunda);
            string huellaOrigen = Hash(ruta);

            var almacen = new ArchivoPublicacionBasePendiente(pendientes, servidor, usuario);
            Exigir(almacen.Consultar() is null, "Una cuenta nueva no debe tener una importación pendiente.");
            var intento = almacen.Crear("Base de dos obras", primera, ruta);
            Exigir(intento.Id != Guid.Empty && intento.Nombre == "Base de dos obras"
                && intento.Obras == 2 && intento.DocumentoPrincipalId == primera.Id,
                "La importación debe describir ambas obras y conservar la identidad principal.");
            Exigir(Hash(ruta) == huellaOrigen, "Preparar la base privada no puede modificar el origen.");
            Exigir(File.Exists(intento.RutaSQLite), "El respaldo privado debe existir antes de publicar.");
            Exigir(MYGBaseDatos.ListarProyectos(intento.RutaSQLite).Select(p => p.Id).ToHashSet()
                .SetEquals(new[] { primera.Id, segunda.Id }), "El respaldo completo debe conservar todas las obras.");
            var reabierto = new ArchivoPublicacionBasePendiente(pendientes, servidor, usuario).Consultar();
            Exigir(reabierto == intento, "Reabrir debe conservar el UUID y los metadatos del intento congelado.");

            var otraCuenta = new ArchivoPublicacionBasePendiente(pendientes, servidor,
                "22222222-2222-4222-8222-222222222222");
            Exigir(otraCuenta.Consultar() is null, "Los intentos deben aislarse por cuenta.");
            var otroServidor = new ArchivoPublicacionBasePendiente(pendientes, "https://otro.supabase.co", usuario);
            Exigir(otroServidor.Consultar() is null, "Los intentos deben aislarse por servidor.");
            Rechaza(() => almacen.Crear("Duplicada", segunda, ruta), "Otro intento no puede sustituir los UUID de una publicación pendiente.");
            Rechaza(() => otraCuenta.Retirar(intento), "Otra cuenta no puede retirar el intento ajeno.");

            // Cada archivo contiene el paquete que se enviará a una obra independiente,
            // sin dar al colaborador el respaldo SQLite de la base completa.
            var archivos = Directory.GetFiles(pendientes, "obra-*.json", SearchOption.AllDirectories);
            Exigir(archivos.Length == 2, "Debe prepararse un paquete congelado por cada obra de la base.");
            var documentos = new HashSet<string>();
            foreach (string archivo in archivos)
            {
                using var json = JsonDocument.Parse(File.ReadAllBytes(archivo), new JsonDocumentOptions { MaxDepth = 128 });
                var contenido = FormatoPaqueteNube.Expandir(json.RootElement);
                var documento = PaqueteNube.LeerDocumento(contenido);
                Exigir(documentos.Add(documento.Id), "No deben duplicarse obras en la importación.");
                Exigir(contenido.GetProperty("alcance").GetString() == "obra"
                    && contenido.GetProperty("documentos").GetArrayLength() == 1
                    && contenido.GetProperty("documentos")[0].GetProperty("Id").GetString() == documento.Id,
                    "El paquete de una obra debe incluir solo su documento, sin las otras obras.");
                string otraObra = documento.Id == primera.Id ? segunda.Nombre : primera.Nombre;
                Exigir(!contenido.GetRawText().Contains(otraObra, StringComparison.Ordinal),
                    "El paquete compartible no debe filtrar el nombre ni los datos de otra obra.");
            }
            Exigir(documentos.SetEquals(new[] { primera.Id, segunda.Id }), "Los paquetes deben cubrir exactamente las obras de la base.");

            string retirada = almacen.Retirar(intento);
            Exigir(almacen.Consultar() is null && Directory.Exists(retirada), "Retirar debe liberar el intento y conservar su carpeta recuperable.");
            Exigir(File.Exists(intento.RutaSQLite) && archivos.All(File.Exists), "Retirar no puede borrar el respaldo ni los paquetes de las obras.");
            Exigir(Hash(ruta) == huellaOrigen, "Retirar no puede cambiar la base original.");

            using var cancelacion = new CancellationTokenSource();
            cancelacion.Cancel();
            Rechaza(() => almacen.Crear("Cancelada", primera, ruta, cancelacion.Token), "La cancelación previa debe impedir una preparación nueva.");
            Exigir(almacen.Consultar() is null, "Una preparación cancelada no debe dejar un intento activo.");
            // Reproducir la longitud habitual de AppData en Windows. SQLite
            // necesita espacio también para el esquema auxiliar y su journal.
            string carpetaLarga = Path.Combine(temporal, new string('r', Math.Max(1, 90 - temporal.Length - 1)));
            var largo = new ArchivoPublicacionBasePendiente(carpetaLarga, servidor, usuario);
            var intentoLargo = largo.Crear("Base con ruta AppData", primera, ruta);
            Exigir((intentoLargo.RutaSQLite + ".esquema.sqlite-journal").Length < 260,
                "Las rutas de publicación y sus auxiliares deben caber en MAX_PATH de SQLite Windows.");
            Exigir(new ArchivoPublicacionBasePendiente(carpetaLarga, servidor, usuario).Consultar() == intentoLargo,
                "El formato corto debe poder reabrirse conservando el intento.");
            largo.Retirar(intentoLargo);
            Exigir(File.Exists(intentoLargo.RutaSQLite) && Hash(ruta) == huellaOrigen,
                "Acortar las rutas no debe borrar la copia ni cambiar el original.");
            Console.WriteLine($"OK Base privada pendiente: {comprobaciones} comprobaciones de base completa, aislamiento de obras, reanudación y conservación del origen; sin red.");
            await EnvioReanudable(temporal, primera, ruta);
            await EnvioReanudable(temporal, primera, ruta, perderCrearAck: true);
            await PaqueteAlterado(temporal, primera, ruta);
        }
        finally
        {
            SqliteConnection.ClearAllPools();
            Directory.Delete(temporal, recursive: true);
        }
    }

    private static string Hash(string ruta)
    {
        using var archivo = File.OpenRead(ruta);
        return Convert.ToHexString(SHA256.HashData(archivo));
    }

    private static async Task EnvioReanudable(string temporal, MYGProyectoDocumento primera, string origen, bool perderCrearAck = false)
    {
        const string servidor = "https://pruebas.supabase.co";
        const string usuario = "11111111-1111-4111-8111-111111111111";
        string carpeta = Path.Combine(temporal, perderCrearAck ? "envio-crear" : "envio-vinculo");
        var almacen = new ArchivoPublicacionBasePendiente(carpeta, servidor, usuario);
        var pendiente = almacen.Crear("Importación reanudable", primera, origen);
        using var transporte = new TransporteBase { PerderCrearAck = perderCrearAck, PerderVinculoAck = !perderCrearAck };
        using var cliente = new ClienteSupabase(servidor, "sb_publishable_prueba_sintetica", transporte);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        bool fallo = false;
        try { await almacen.EnviarAsync(cliente); }
        catch (NubeException ex) when (ex.EsErrorDeConexion) { fallo = true; }
        if (!fallo || almacen.Consultar()?.Id != pendiente.Id || transporte.Vinculadas.Count != (perderCrearAck ? 0 : 1)
            || transporte.CreacionesObra != 1)
            throw new InvalidOperationException("El ACK perdido debe conservar el intento y exactamente una primera obra creada.");
        // La primera obra ya se puede editar: el reintento no debe reenviar su
        // instantánea inicial ni intentar crear otro UUID para el mismo documento.
        transporte.RevisionObra = 2;
        var reabierto = new ArchivoPublicacionBasePendiente(carpeta, servidor, usuario);
        var confirmado = await reabierto.EnviarAsync(cliente);
        if (confirmado.Proyecto.Id != pendiente.Id || reabierto.Consultar() is not null
            || transporte.CreacionesObra != 2 || transporte.SubidasBase != 1
            || transporte.Vinculadas.Count != 2 || !File.Exists(pendiente.RutaSQLite))
            throw new InvalidOperationException("Reanudar debe completar exactamente dos obras sin duplicar ni sobrescribir la obra editada.");
        Console.WriteLine(perderCrearAck
            ? "OK Importación recuperable: ACK perdido tras crear antes de vincular, reinicio del almacén y dos UUID únicos; HTTP simulado, sin red."
            : "OK Importación recuperable: ACK perdido tras vincular, reinicio del almacén, obra ya editada y dos UUID únicos; HTTP simulado, sin red.");
    }

    private static async Task PaqueteAlterado(string temporal, MYGProyectoDocumento primera, string origen)
    {
        const string servidor = "https://pruebas.supabase.co";
        const string usuario = "11111111-1111-4111-8111-111111111111";
        string carpeta = Path.Combine(temporal, "alterado");
        var almacen = new ArchivoPublicacionBasePendiente(carpeta, servidor, usuario);
        var pendiente = almacen.Crear("Paquete alterado", primera, origen);
        foreach (string paquete in Directory.GetFiles(carpeta, "obra-*.json", SearchOption.AllDirectories))
            File.AppendAllText(paquete, " ");
        using var transporte = new TransporteBase { PerderVinculoAck = false };
        using var cliente = new ClienteSupabase(servidor, "sb_publishable_prueba_sintetica", transporte);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        bool rechazado = false;
        try { await almacen.EnviarAsync(cliente); }
        catch (InvalidDataException) { rechazado = true; }
        if (!rechazado || almacen.Consultar()?.Id != pendiente.Id || transporte.CreacionesObra != 0
            || transporte.Vinculadas.Count != 0 || !File.Exists(pendiente.RutaSQLite))
            throw new InvalidOperationException("Un paquete modificado no debe enviarse ni vincularse; el intento y su respaldo deben conservarse.");
        Console.WriteLine("OK Importación íntegra: paquete alterado rechazado sin enviar obras; intento y respaldo local conservados; HTTP simulado, sin red.");
    }

    private sealed class TransporteBase : HttpMessageHandler
    {
        private const string Usuario = "11111111-1111-4111-8111-111111111111";
        private Guid baseId;
        private string nombreBase = "", documentoBase = "", rutaBase = "", shaBase = "";
        private long bytesBase;
        private readonly Dictionary<Guid, (string Nombre, string Documento)> obras = new();
        private readonly Dictionary<Guid, string> cuerpos = new();
        internal readonly HashSet<Guid> Vinculadas = new();
        internal int CreacionesObra, SubidasBase;
        internal long RevisionObra = 1;
        internal bool PerderCrearAck, PerderVinculoAck = true;

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token") return Respuesta(new
            { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600, user = new { id = Usuario } });
            if (solicitud.Headers.Authorization is null) throw new InvalidOperationException("Una publicación omitió la sesión.");
            if (ruta.StartsWith("/storage/v1/object/myg-nube-sqlite/", StringComparison.Ordinal))
            {
                if (solicitud.Method != HttpMethod.Post) throw new InvalidOperationException("No se esperaba descargar el respaldo privado.");
                byte[] bytes = await solicitud.Content!.ReadAsByteArrayAsync(ct);
                if (!bytes.AsSpan(0, 16).SequenceEqual("SQLite format 3\0"u8))
                    throw new InvalidOperationException("La base no se subió como SQLite.");
                SubidasBase++;
                return Respuesta(new { Key = ruta });
            }
            using var documento = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(ct), new JsonDocumentOptions { MaxDepth = 128 });
            var p = documento.RootElement;
            string rpc = ruta.Split('/').Last();
            switch (rpc)
            {
                case "myg_nube_bases_capacidades": return Respuesta(new { version = 1 });
                case "myg_nube_sqlite_capacidades": return Respuesta(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
                case "myg_nube_capacidades": return Respuesta(new { paquete_compacto = 2, cambios = 1, max_contenido_mib = 300, publicacion_ligera = 1, publicacion_comprimida = 0 });
                case "myg_nube_sqlite_consultar": return baseId == Guid.Empty ? Respuesta<object?>(null) : Respuesta(DescriptorBase());
                case "myg_nube_sqlite_crear":
                {
                    Guid id = p.GetProperty("p_id").GetGuid();
                    if (baseId != Guid.Empty && baseId != id) throw new InvalidOperationException("El reintento cambió el UUID de la base.");
                    baseId = id;
                    nombreBase = p.GetProperty("p_nombre").GetString()!;
                    documentoBase = p.GetProperty("p_documento_id").GetString()!;
                    rutaBase = p.GetProperty("p_ruta").GetString()!;
                    shaBase = p.GetProperty("p_sha256").GetString()!;
                    bytesBase = p.GetProperty("p_bytes").GetInt64();
                    return Respuesta(DescriptorBase());
                }
                case "myg_nube_base_obras_listar": return Respuesta(Vinculadas.Select(DescriptorObra).ToArray());
                case "myg_nube_estado_publicacion": return Respuesta(new { estado = obras.ContainsKey(p.GetProperty("p_id").GetGuid()) ? "existente" : "disponible" });
                case "myg_nube_crear_confirmacion":
                {
                    Guid id = p.GetProperty("p_id").GetGuid();
                    if (Vinculadas.Contains(id)) throw new InvalidOperationException("Se volvió a publicar una obra vinculada que ya pudo ser editada.");
                    string cuerpo = p.GetProperty("p_contenido").GetRawText();
                    if (obras.ContainsKey(id))
                    {
                        if (cuerpos[id] != cuerpo) throw new InvalidOperationException("El reintento cambió el paquete de la obra creada sin ACK.");
                        return Respuesta(DescriptorProyecto(id));
                    }
                    var contenido = FormatoPaqueteNube.Expandir(p.GetProperty("p_contenido"));
                    var obra = PaqueteNube.LeerDocumento(contenido);
                    if (contenido.GetProperty("documentos").GetArrayLength() != 1)
                        throw new InvalidOperationException("Una publicación contiene más de una obra.");
                    obras.Add(id, (p.GetProperty("p_nombre").GetString()!, obra.Id));
                    cuerpos.Add(id, cuerpo);
                    CreacionesObra++;
                    if (PerderCrearAck) { PerderCrearAck = false; throw new HttpRequestException("ACK perdido después de crear la obra sintética."); }
                    return Respuesta(DescriptorProyecto(id));
                }
                case "myg_nube_base_obra_vincular":
                {
                    Guid id = p.GetProperty("p_obra").GetGuid();
                    if (p.GetProperty("p_base").GetGuid() != baseId
                        || p.GetProperty("p_documento").GetString() != obras[id].Documento)
                        throw new InvalidOperationException("El vínculo cambió la identidad de la base o de la obra.");
                    Vinculadas.Add(id);
                    if (PerderVinculoAck) { PerderVinculoAck = false; throw new HttpRequestException("ACK perdido después del vínculo sintético."); }
                    return Respuesta(DescriptorObra(id));
                }
                default: throw new InvalidOperationException("RPC inesperada durante publicación de base: " + rpc);
            }
        }

        private object DescriptorBase() => new
        {
            id = baseId, codigo = "MYG-BASE-QA", nombre = nombreBase, rol = "propietario", revision = 1, alcance = "base",
            documento_id = documentoBase, archivo_sqlite = new { ruta = rutaBase, sha256 = shaBase, bytes = bytesBase }
        };
        private object DescriptorProyecto(Guid id) => new
        { id, codigo = "MYG-OBRA-" + id.ToString("N"), nombre = obras[id].Nombre, rol = "propietario", revision = 1, alcance = "obra" };
        private object DescriptorObra(Guid id) => new
        {
            base_id = baseId, id, codigo = "MYG-OBRA-" + id.ToString("N"), nombre = obras[id].Nombre,
            rol = "propietario", revision = RevisionObra, alcance = "obra", documento_id = obras[id].Documento
        };
        private static HttpResponseMessage Respuesta<T>(T valor) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
