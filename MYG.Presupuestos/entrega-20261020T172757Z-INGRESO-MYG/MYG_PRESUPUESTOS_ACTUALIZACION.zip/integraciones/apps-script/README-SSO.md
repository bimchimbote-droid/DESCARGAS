# Nube MYG con la sesión MYG

`Codigo.gs` contiene el Apps Script completo del archivo original entregado por el propietario, con dos acciones POST añadidas. La aplicación puede revalidar su sesión MYG y solicitar un ticket breve para la función de autenticación de Supabase. No se introduce correo ni contraseña de Supabase en ese flujo.

Se conservan el login original de los complementos, la página de compras, los precios configurados de **S/23 mensual y S/210 anual**, los pedidos, las renovaciones y las funciones administrativas originales. Los precios del objeto `PLANES_MYG_` son los que se aplican; el comentario histórico inicial del original menciona otros precios.

## Configuración del propietario

1. Guarda una copia del Apps Script y de la hoja de licencias actuales. Abre **Extensiones → Apps Script desde esa misma hoja**. Usa un único archivo con el contenido completo de `Codigo.gs`; evita duplicar `doGet` y `doPost` en otros archivos.
2. Conserva las propiedades existentes de licencias y Mercado Pago, la hoja `LICENCIAS`, la URL `/exec` y las zonas horarias **America/Lima** del proyecto y la hoja. Esta ampliación no requiere ejecutar `PREPARAR_INTEGRACION`, modificar pedidos ni habilitar ventas.
3. En **Configuración del proyecto → Propiedades del script**, añade `MYG_NUBE_URL` con la URL del proyecto Supabase que utiliza MYG, por ejemplo `https://referencia.supabase.co`. Debe ser HTTPS y terminar en `.supabase.co`, sin ruta, puerto, parámetros ni credenciales. Puede tener una barra final; se convierte al formato sin barra.
4. Ejecuta **`PREPARAR_NUBE_MYG`** desde el editor con la cuenta propietaria. Si falta `MYG_NUBE_HMAC`, genera un secreto aleatorio de 64 caracteres hexadecimales. Si ya existe, lo conserva. Una configuración existente con formato incorrecto se rechaza. La función no imprime el secreto, no escribe licencias, no crea hojas ni activadores y no cambia `MYG_PAGOS_HABILITADOS`.
5. Copia el valor completo de `MYG_NUBE_HMAC` directamente de las propiedades al secreto del mismo nombre en el entorno seguro de la función de Supabase. Los dos lados deben usar exactamente el mismo texto, incluidas mayúsculas o minúsculas: es una clave **UTF-8 literal de 64 caracteres, no bytes decodificados del hexadecimal**. Nunca lo pongas en C#, archivos públicos, el ZIP, capturas, registros o mensajes. Configura también el resto del entorno de la función según su documentación.
6. Ejecuta **`VERIFICAR_NUBE_MYG`**. Sólo informa de que la URL y el secreto tienen el formato esperado; no muestra sus valores ni hace peticiones de red. Esta comprobación no prueba por sí sola que la función Supabase esté desplegada o tenga el mismo secreto.
7. Publica el código en la **implementación existente**: **Implementar → Gestionar implementaciones → lápiz → Versión: Nueva versión → Implementar**. Conserva la misma URL `/exec` que usan las DLL y MYG, con los permisos de ejecución de la implementación anterior. Guardar el editor sin actualizar esa versión no actualiza `/exec`.
8. Una vez preparada la función Supabase y sus migraciones, inicia sesión normalmente en MYG y abre Nube MYG. El servidor mantiene la vinculación verificada de la cuenta MYG, los permisos del proyecto y la restricción de máquina de la licencia. Este Apps Script no crea cuentas Supabase, no verifica vinculaciones por su cuenta y no concede permisos de edición.

Mantén el secreto estable. Cambiarlo exige actualizar el entorno seguro de Supabase al mismo tiempo; los tickets pendientes caducan a los 60 segundos. No se cambia el acceso a una licencia al configurar este secreto.

## Contrato POST

Se envían parámetros de formulario a la misma URL `/exec`, con `accion`, `usuario`, `pc` y **una sola** credencial:

| Parámetro | Uso |
| --- | --- |
| `accion=validar_sesion` | Revalida sin escribir en la hoja; responde texto `OK` o un código de error. |
| `accion=nube_ticket` | Revalida y devuelve JSON con un ticket HS256 de 60 segundos. |
| `usuario` | Usuario MYG; se recortan extremos y se convierte a minúsculas. Acepta acentos y espacios internos, de 1 a 256 unidades UTF-16, sin controles ni pares sustitutos inválidos. |
| `pc` | Mismo identificador de máquina registrado en `LICENCIAS.C`. Las acciones nuevas no registran una máquina sin vincular. |
| `clave` | Credencial manual MYG. Puede usarse aunque H indique `NO`; no cambia H ni TOKEN_HASH. |
| `token` | Credencial automática MYG actual. Exige H=`SI` y coincidencia del SHA256 con I. No se envía junto con `clave`. |
| `audiencia` | Opcional para `nube_ticket`; si se envía, debe coincidir con `MYG_NUBE_URL` tras normalizar la URL. |

Respuesta de éxito de `nube_ticket`: `{ "ok": true, "ticket": "…", "usuario": "usuario normalizado", "expira_en": 1790000060, "audiencia": "https://referencia.supabase.co" }`. **`expira_en` es el instante de caducidad en segundos Unix**, igual al claim `exp`, no una duración. Fallo: `{ "ok": false, "codigo": "CODIGO" }`.

El JWT lleva cabecera `{alg:"HS256",typ:"JWT"}` y únicamente estos claims:

| Claim | Valor |
| --- | --- |
| `iss` | `MYG_LICENCIAS` |
| `aud` | URL canónica configurada del proyecto Supabase |
| `sub` | Usuario MYG normalizado |
| `pc` | SHA256 del identificador de máquina, hexadecimal en mayúsculas |
| `jti` | UUID aleatorio con guiones en minúsculas; el servidor debe impedir su reutilización |
| `iat` | Fecha actual en segundos Unix |
| `exp` | `iat + 60` |

Cabecera, cuerpo y firma usan base64url sin relleno `=`. El ticket es una credencial breve y debe mantenerse fuera de registros y almacenamiento persistente. Supabase verifica su firma y vinculación antes de emitir una sesión propia; el cliente no puede declararse verificado por enviar un nombre de usuario.

Los códigos compartidos con el login existente son `DATOS_INCOMPLETOS`, `SIN_HOJA`, `NO_EXISTE`, `CLAVE_ERROR`, `BLOQUEADO`, `FECHA_INVALIDA`, `EXPIRADO`, `AUTO_DESACTIVADO`, `OTRA_PC`, `TOKEN_INVALIDO` y `ERROR`. `nube_ticket` puede añadir `NUBE_NO_CONFIGURADA` y `AUDIENCIA_INVALIDA`. No se devuelven excepciones internas ni credenciales.

Las nuevas acciones no escriben **ninguna** celda, incluidas C, G, H e I. El GET manual original conserva su comportamiento histórico de registrar la máquina y rotar o borrar el token de su propia fila; el POST sin estas acciones conserva la validación automática original. Por tanto, otros complementos que sigan ejecutando el GET manual original pueden seguir rotando el token de esa cuenta. Dos usuarios MYG distintos conservan sus propias filas, PC y tokens.

La validación del script admite Unicode, pero algunos nombres especiales se convierten a minúsculas de forma distinta en JavaScript, .NET y PostgreSQL (por ejemplo `İ` y la sigma griega final). Para esos usuarios debe comprobarse la coincidencia del nombre canónico antes de habilitarlos; las pruebas no afirman equivalencia universal entre los tres entornos.

Las funciones nuevas auxiliares terminan en `_`. Las únicas funciones nuevas de administración públicas son `PREPARAR_NUBE_MYG` y `VERIFICAR_NUBE_MYG`, protegidas por la comprobación administrativa original.

## Validación local

Desde la raíz del repositorio, con Node.js 18 o posterior:

```sh
node --test integraciones/apps-script/tests/*.test.mjs
```

Las pruebas usan un entorno `vm` con Sheets, Properties y Utilities simulados. No llaman a Google, Supabase ni Mercado Pago y no contienen credenciales reales. Verifican dos usuarios/PC independientes, firma y caducidad, errores de licencias, configuración y audiencia, ausencia de escrituras, usuarios Unicode, login heredado y renovación idempotente que conserva C/H/I.

`tests/legacy.sha256.json` registra las huellas del original proporcionado. Las pruebas recuperan el texto completo original quitando únicamente el dispatcher añadido a `doPost` y la extensión final, y comparan su SHA256 con normalización CRLF→LF. También comparan las funciones originales individualmente. Esto verifica que compras, precios, renovaciones y administración no se han reescrito. Las pruebas locales no sustituyen la comprobación de la implementación real `/exec` y de la función Supabase después del despliegue.
