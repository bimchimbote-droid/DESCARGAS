using System.Net;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using MYG.Externo;

internal static class IngresoMygChecks
{
    private const string Servidor = "https://ingreso.supabase.co";
    private const string Clave = "sb_publishable_ingreso_pruebas";
    private const string Ticket = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJjIn0.firma_solo_pruebas";
    private static readonly Guid UsuarioA = Guid.Parse("11111111-1111-4111-8111-111111111111");
    private static readonly Guid UsuarioB = Guid.Parse("22222222-2222-4222-8222-222222222222");
    private static int comprobaciones;

    public static async Task RunAsync()
    {
        comprobaciones = 0;
        await DosUsuariosIndependientes();
        await RenovarIdentidad();
        await RenovacionAjena();
        await RenovacionFallida();
        await MetadatosInvalidos();
        await RespuestaAjenaYCompatibilidad();
        await ErroresSeguros();
        await CancelacionYDispose();
        Console.WriteLine($"OK Ingreso único MYG: 8 casos y {comprobaciones} comprobaciones; HTTP simulado, sin red.");
    }

    private static TicketNubeMYG Credencial(string usuario = "c", string audiencia = Servidor, DateTimeOffset? expira = null,
        string ticket = Ticket) => new(ticket, usuario, audiencia, expira ?? DateTimeOffset.UtcNow.AddSeconds(60));
    private static void Exige(bool condicion, string detalle)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException("Ingreso MYG: " + detalle); }
    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException ex) { comprobaciones++; return ex; }
        throw new InvalidOperationException("Ingreso MYG: faltó el rechazo esperado.");
    }
    private static HttpResponseMessage Json(object objeto, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
    { Content = new StringContent(JsonSerializer.Serialize(objeto), Encoding.UTF8, "application/json") };
    private static HttpResponseMessage Sesion(string usuario = "c", Guid? id = null, string acceso = "acceso_myg") => Json(new
    {
        access_token = acceso, refresh_token = "refresco_solo_memoria", expires_in = 3600,
        user = new { id = id ?? UsuarioA }, usuario_myg = usuario
    });
    private static async Task RevisarCanje(HttpRequestMessage solicitud)
    {
        Exige(solicitud.Method == HttpMethod.Post && solicitud.RequestUri?.PathAndQuery == "/functions/v1/myg-login", "El canje usa otro endpoint.");
        Exige(solicitud.Headers.GetValues("apikey").Single() == Clave && solicitud.Headers.Authorization is null, "El canje debe usar solo la clave pública.");
        using var json = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync());
        Exige(json.RootElement.EnumerateObject().Count() == 1 && json.RootElement.GetProperty("ticket").GetString() == Ticket,
            "Se enviaron credenciales o metadatos en lugar de un ticket.");
    }

    private static async Task DosUsuariosIndependientes()
    {
        using var ta = new Transporte(); using var tb = new Transporte();
        using var a = new ClienteSupabase(Servidor, Clave, ta); using var b = new ClienteSupabase(Servidor, Clave, tb);
        ta.Paso(async (r, _) => { await RevisarCanje(r); return Sesion(); });
        tb.Paso(async (r, _) => { await RevisarCanje(r); return Sesion("editor", UsuarioB); });
        await Task.WhenAll(a.IniciarSesionMygAsync(Credencial()), b.IniciarSesionMygAsync(Credencial("editor")));
        Exige(a.UsuarioId == UsuarioA.ToString("D") && a.UsuarioMygSesion == "c", "Cuenta propietaria incorrecta.");
        Exige(b.UsuarioId == UsuarioB.ToString("D") && b.UsuarioMygSesion == "editor", "Se cruzaron las cuentas MYG.");
        ta.Paso((r, _) =>
        {
            Exige(r.RequestUri?.PathAndQuery == "/auth/v1/logout?scope=local", "Se intentó un cierre global.");
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.NoContent));
        });
        await a.CerrarSesionAsync();
        Exige(!a.SesionIniciada && a.UsuarioMygSesion is null && a.UsuarioId is null, "El cierre dejó identidad local.");
        tb.Paso((r, _) =>
        {
            Exige(r.RequestUri?.AbsolutePath == "/rest/v1/rpc/myg_nube_listar" && r.Headers.Authorization?.Parameter == "acceso_myg", "La cuenta B perdió su acceso.");
            return Task.FromResult(Json(Array.Empty<object>()));
        });
        await b.ListarProyectosAsync();
        Exige(b.SesionIniciada && b.UsuarioMygSesion == "editor", "El cierre de A afectó B.");
        ta.Completo(); tb.Completo();
    }

    private static async Task RenovarIdentidad()
    {
        using var transporte = new Transporte(); using var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        transporte.Paso((_, _) => Task.FromResult(Sesion()));
        await cliente.IniciarSesionMygAsync(Credencial());
        transporte.Paso((_, _) => Task.FromResult(Json(new { error = "caducado" }, HttpStatusCode.Unauthorized)));
        transporte.Paso(async (r, _) =>
        {
            Exige(r.RequestUri?.PathAndQuery == "/auth/v1/token?grant_type=refresh_token" && r.Headers.Authorization is null, "Refresco incorrecto.");
            using var json = JsonDocument.Parse(await r.Content!.ReadAsStringAsync());
            Exige(json.RootElement.GetProperty("refresh_token").GetString() == "refresco_solo_memoria", "Refresco mezclado.");
            return Sesion(acceso: "acceso_renovado");
        });
        transporte.Paso((r, _) =>
        {
            Exige(r.Headers.Authorization?.Parameter == "acceso_renovado", "No usó el acceso renovado.");
            return Task.FromResult(Json(Array.Empty<object>()));
        });
        await cliente.ListarProyectosAsync();
        Exige(cliente.UsuarioMygSesion == "c" && cliente.UsuarioId == UsuarioA.ToString("D"), "El refresco perdió identidad MYG.");
        transporte.Completo();
    }

    private static async Task RenovacionAjena()
    {
        using var transporte = new Transporte(); using var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        transporte.Paso((_, _) => Task.FromResult(Sesion()));
        await cliente.IniciarSesionMygAsync(Credencial());
        transporte.Paso((_, _) => Task.FromResult(Json(new { error = "caducado" }, HttpStatusCode.Unauthorized)));
        transporte.Paso((_, _) => Task.FromResult(Sesion("editor", UsuarioB)));
        var error = await Rechaza(() => cliente.ListarProyectosAsync());
        Exige(error.NecesitaIniciarSesion && !cliente.SesionIniciada && cliente.UsuarioMygSesion is null, "Refresco ajeno retuvo la identidad anterior.");
        transporte.Completo();
    }

    private static async Task RenovacionFallida()
    {
        using var transporte = new Transporte(); using var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        transporte.Paso((_, _) => Task.FromResult(Sesion()));
        await cliente.IniciarSesionMygAsync(Credencial());
        transporte.Paso((r, _) =>
        {
            Exige(r.RequestUri?.AbsolutePath == "/rest/v1/rpc/myg_nube_listar", "No se ejercitó la consulta con sesión caducada.");
            return Task.FromResult(Json(new { error = "jwt_expired" }, HttpStatusCode.Unauthorized));
        });
        transporte.Paso((r, _) =>
        {
            Exige(r.RequestUri?.PathAndQuery == "/auth/v1/token?grant_type=refresh_token", "No se intentó renovar la sesión MYG.");
            return Task.FromResult(Json(new { error = "refresh_token_not_found", message = "secreto_remoto" }, HttpStatusCode.BadRequest));
        });
        var error = await Rechaza(() => cliente.ListarProyectosAsync());
        Exige(error.NecesitaIniciarSesion, "El rechazo de renovación no solicita un nuevo ingreso.");
        Exige(!cliente.SesionIniciada && cliente.UsuarioMygSesion is null && cliente.UsuarioId is null,
            "El rechazo de renovación no borró toda la identidad.");
        Exige(error.Message.Contains("usuario MYG") && !error.Message.Contains("correo", StringComparison.OrdinalIgnoreCase)
            && !error.Message.Contains("contraseña", StringComparison.OrdinalIgnoreCase) && !error.Message.Contains("secreto_remoto"),
            "El diagnóstico solicitó credenciales Supabase o reveló contenido remoto.");
        transporte.Completo();
    }

    private static async Task MetadatosInvalidos()
    {
        using var transporte = new Transporte(); using var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        foreach (var ticket in new[] {
            Credencial(audiencia: "https://otro.supabase.co"), Credencial(expira: DateTimeOffset.UtcNow.AddSeconds(-1)),
            Credencial(expira: DateTimeOffset.UtcNow.AddMinutes(3)), Credencial(usuario: " C "), Credencial(usuario: "c\n"),
            Credencial(usuario: "c\ud800"), Credencial(ticket: "incorrecto"), Credencial(ticket: new string('a', 8193)) })
        {
            var error = await Rechaza(() => cliente.IniciarSesionMygAsync(ticket));
            Exige(error.NecesitaIniciarSesion && !cliente.SesionIniciada, "Se admitió autorización local inválida.");
        }
        transporte.Paso((_, _) => Task.FromResult(Sesion("área 😃")));
        await cliente.IniciarSesionMygAsync(Credencial("área 😃"));
        Exige(cliente.UsuarioMygSesion == "área 😃", "Se rechazó un nombre Unicode válido.");
        transporte.Completo();
    }

    private static async Task RespuestaAjenaYCompatibilidad()
    {
        using var transporte = new Transporte(); using var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        transporte.Paso((_, _) => Task.FromResult(Sesion()));
        await cliente.IniciarSesionMygAsync(Credencial());
        transporte.Paso((_, _) => Task.FromResult(Sesion("otro")));
        var ajena = await Rechaza(() => cliente.IniciarSesionMygAsync(Credencial()));
        Exige(ajena.NecesitaIniciarSesion && !cliente.SesionIniciada && cliente.UsuarioMygSesion is null, "Publicó una cuenta ajena.");
        transporte.Paso((_, _) => Task.FromResult(Sesion()));
        await cliente.IniciarSesionMygAsync(Credencial());
        transporte.Paso((r, _) =>
        {
            Exige(r.RequestUri?.PathAndQuery == "/auth/v1/token?grant_type=password", "Cambió el API de compatibilidad.");
            return Task.FromResult(Sesion());
        });
        await cliente.IniciarSesionAsync("prueba@example.test", "clave_legacy");
        Exige(cliente.SesionIniciada && cliente.UsuarioMygSesion is null, "El acceso legacy heredó identidad MYG.");
        transporte.Paso((_, _) => Task.FromResult(Json(new { access_token = "acceso", refresh_token = "refresco", expires_in = 3600, user = new { id = UsuarioA } })));
        await Rechaza(() => cliente.IniciarSesionMygAsync(Credencial()));
        Exige(!cliente.SesionIniciada && cliente.UsuarioMygSesion is null, "Faltó rechazar respuesta sin identidad MYG.");
        transporte.Completo();
    }

    private static async Task ErroresSeguros()
    {
        foreach (var (estado, codigo) in new[] {
            (HttpStatusCode.Unauthorized, "MYG_INGRESO_INVALIDO"), (HttpStatusCode.Forbidden, "MYG_VINCULO_NO_VERIFICADO"),
            (HttpStatusCode.Conflict, "MYG_INGRESO_REUTILIZADO"), (HttpStatusCode.ServiceUnavailable, "MYG_NUBE_NO_DISPONIBLE"),
            (HttpStatusCode.NotFound, "NOT_FOUND"), (HttpStatusCode.BadRequest, "arbitrario_secreto") })
        {
            using var transporte = new Transporte(); using var cliente = new ClienteSupabase(Servidor, Clave, transporte);
            transporte.Paso((_, _) => Task.FromResult(Json(new { error = codigo, access_token = "secreto_remoto", ticket = Ticket }, estado)));
            var error = await Rechaza(() => cliente.IniciarSesionMygAsync(Credencial()));
            Exige(!error.Message.Contains("secreto") && !error.Message.Contains(Ticket) && !error.Message.Contains("arbitrario"), "Reveló contenido remoto.");
            Exige(!cliente.SesionIniciada && cliente.UsuarioMygSesion is null, "Retuvo una sesión tras error.");
            if (estado == HttpStatusCode.Forbidden) Exige(error.AccesoDenegado && error.VinculoNoVerificado, "El vínculo faltante perdió su diagnóstico.");
            if (estado == HttpStatusCode.ServiceUnavailable) Exige(error.EsErrorDeConexion && error.Message.Contains("myg-login"), "No indicó la función de ingreso.");
            if (estado is HttpStatusCode.Unauthorized or HttpStatusCode.Conflict) Exige(error.NecesitaIniciarSesion, "No indicó solicitar un ingreso nuevo.");
            transporte.Completo();
        }
    }

    private static async Task CancelacionYDispose()
    {
        using var transporte = new Transporte(); var cliente = new ClienteSupabase(Servidor, Clave, transporte);
        using var ct = new CancellationTokenSource();
        transporte.Paso(async (_, token) => { ct.Cancel(); await Task.Delay(Timeout.Infinite, token); return Sesion(); });
        try { await cliente.IniciarSesionMygAsync(Credencial(), ct.Token); throw new InvalidOperationException("No canceló el ingreso."); }
        catch (OperationCanceledException) { Exige(!cliente.SesionIniciada && cliente.UsuarioMygSesion is null, "Cancelación publicó sesión."); }
        transporte.Paso((_, _) => Task.FromResult(Sesion()));
        await cliente.IniciarSesionMygAsync(Credencial());
        cliente.Dispose();
        Exige(!cliente.SesionIniciada && cliente.UsuarioMygSesion is null && cliente.UsuarioId is null, "Dispose conservó identidad.");
        transporte.Completo();
    }

    private sealed class Transporte : HttpMessageHandler
    {
        private readonly Queue<Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>>> pasos = new();
        public void Paso(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> paso) => pasos.Enqueue(paso);
        public void Completo() => Exige(pasos.Count == 0, "Quedaron solicitudes sin ejecutar.");
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Exige(request.RequestUri?.Host == "ingreso.supabase.co", "El transporte salió a otro servidor.");
            if (pasos.Count == 0) throw new InvalidOperationException("Solicitud HTTP inesperada.");
            return pasos.Dequeue()(request, cancellationToken);
        }
    }
}
