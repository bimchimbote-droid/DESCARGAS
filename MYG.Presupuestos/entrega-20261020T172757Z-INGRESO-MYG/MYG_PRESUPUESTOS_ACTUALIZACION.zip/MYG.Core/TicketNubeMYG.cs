namespace MYG.Externo;

/// <summary>Credencial breve que solo se conserva en memoria durante el acceso a Nube MYG.</summary>
public sealed class TicketNubeMYG
{
    public string Ticket { get; }
    public string Usuario { get; }
    public string Audiencia { get; }
    public DateTimeOffset Expira { get; }

    public TicketNubeMYG(string ticket, string usuario, string audiencia, DateTimeOffset expira)
    { Ticket = ticket; Usuario = usuario; Audiencia = audiencia; Expira = expira; }
}

public sealed record ResultadoTicketNube(bool Ok, string Mensaje, TicketNubeMYG Ticket = null, bool LicenciaDenegada = false);
