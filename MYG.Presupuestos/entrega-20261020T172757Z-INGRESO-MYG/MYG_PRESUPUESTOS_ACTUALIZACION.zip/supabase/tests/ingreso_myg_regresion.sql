-- Solo fixture local/PGlite. Todos los datos se revierten al terminar.
begin;
insert into auth.users(id) values
 ('11111111-1111-4111-8111-111111111111'),
 ('22222222-2222-4222-8222-222222222222'),
 ('33333333-3333-4333-8333-333333333333');
insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion)
values ('11111111-1111-4111-8111-111111111111',' Persona-A ','Fixture local A'),
       ('22222222-2222-4222-8222-222222222222','persona-b','Fixture local B');

do $$
begin
    if has_function_privilege('anon','public.myg_nube_canjear_ingreso(text,uuid,bigint,bigint,text)','execute')
       or has_function_privilege('authenticated','public.myg_nube_canjear_ingreso(text,uuid,bigint,bigint,text)','execute')
       or not has_function_privilege('service_role','public.myg_nube_canjear_ingreso(text,uuid,bigint,bigint,text)','execute') then
        raise exception 'Permisos incorrectos de canje.';
    end if;
    if has_table_privilege('anon','myg_nube_privado.ingresos_consumidos','select')
       or has_table_privilege('authenticated','myg_nube_privado.ingresos_consumidos','insert')
       or has_table_privilege('service_role','myg_nube_privado.ingresos_consumidos','delete') then
        raise exception 'Los nonces deben ser privados incluso para service_role directo.';
    end if;
    if not (select relrowsecurity from pg_class where oid='myg_nube_privado.ingresos_consumidos'::regclass) then
        raise exception 'RLS desactivado.';
    end if;
    begin
        insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion)
        values('33333333-3333-4333-8333-333333333333','PERSONA-A','No insertar duplicado normalizado');
        raise exception 'Se aceptó duplicado normalizado.';
    exception when unique_violation then null;
    end;
end;
$$;
set local role anon;
do $$
begin
    begin
        perform public.myg_nube_canjear_ingreso('persona-a','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',1,61,repeat('A',64));
        raise exception 'anon invocó el canje.';
    exception when insufficient_privilege then null;
    end;
end;
$$;
set local role authenticated;
do $$
begin
    begin
        perform public.myg_nube_canjear_ingreso('persona-a','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',1,61,repeat('A',64));
        raise exception 'authenticated invocó el canje.';
    exception when insufficient_privilege then null;
    end;
end;
$$;
set local role service_role;
do $$
declare
    v_ahora bigint := floor(extract(epoch from clock_timestamp()))::bigint;
    v_a jsonb; v_b jsonb; v_caso jsonb;
begin
    v_a := public.myg_nube_canjear_ingreso('persona-a','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',v_ahora,v_ahora+60,repeat('A',64));
    v_b := public.myg_nube_canjear_ingreso('persona-b','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',v_ahora,v_ahora+60,repeat('B',64));
    if v_a <> '{"usuario_id":"11111111-1111-4111-8111-111111111111","usuario_myg":"persona-a"}'::jsonb
       or v_b <> '{"usuario_id":"22222222-2222-4222-8222-222222222222","usuario_myg":"persona-b"}'::jsonb then
        raise exception 'Vinculación equivocada entre dos usuarios.';
    end if;
    begin
        perform public.myg_nube_canjear_ingreso('persona-a','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',v_ahora,v_ahora+60,repeat('A',64));
        raise exception 'Se aceptó replay.';
    exception when unique_violation then
        if sqlerrm <> 'MYG_INGRESO_REUTILIZADO' then raise; end if;
    end;
    begin
        perform public.myg_nube_canjear_ingreso('no-vinculado','cccccccc-cccc-4ccc-8ccc-cccccccccccc',v_ahora,v_ahora+60,repeat('C',64));
        raise exception 'Se aceptó usuario sin verificar.';
    exception when insufficient_privilege then
        if sqlerrm <> 'MYG_VINCULO_NO_VERIFICADO' then raise; end if;
    end;
    begin
        perform public.myg_nube_canjear_ingreso('persona-a','cccccccc-cccc-4ccc-8ccc-cccccccccccc',v_ahora-92,v_ahora-32,repeat('A',64));
        raise exception 'Se aceptó ticket vencido.';
    exception when invalid_authorization_specification then
        if sqlerrm <> 'MYG_INGRESO_EXPIRADO' then raise; end if;
    end;
    for v_caso in select value from jsonb_array_elements(jsonb_build_array(
        jsonb_build_object('usuario',' Persona-A ','pc',repeat('A',64),'iat',v_ahora,'exp',v_ahora+60),
        jsonb_build_object('usuario','persona-a','pc',repeat('a',64),'iat',v_ahora,'exp',v_ahora+60),
        jsonb_build_object('usuario','persona-a','pc',repeat('A',64),'iat',v_ahora+31,'exp',v_ahora+91),
        jsonb_build_object('usuario','persona-a','pc',repeat('A',64),'iat',v_ahora,'exp',v_ahora+91)
    )) loop
        begin
            perform public.myg_nube_canjear_ingreso(v_caso->>'usuario','cccccccc-cccc-4ccc-8ccc-cccccccccccc',
                (v_caso->>'iat')::bigint,(v_caso->>'exp')::bigint,v_caso->>'pc');
            raise exception 'Se aceptó parámetro inválido.';
        exception when invalid_parameter_value then
            if sqlerrm <> 'MYG_INGRESO_INVALIDO' then raise; end if;
        end;
    end loop;
end;
$$;
reset role;
-- Desactivar vínculo impide un nuevo canje sin alterar roles/proyectos.
update myg_nube_privado.identidades_verificadas set activo=false where usuario_myg='persona-b';
set local role service_role;
do $$
declare v_ahora bigint := floor(extract(epoch from clock_timestamp()))::bigint;
begin
    begin
        perform public.myg_nube_canjear_ingreso('persona-b','cccccccc-cccc-4ccc-8ccc-cccccccccccc',v_ahora,v_ahora+60,repeat('B',64));
        raise exception 'Se aceptó vínculo revocado.';
    exception when insufficient_privilege then
        if sqlerrm <> 'MYG_VINCULO_NO_VERIFICADO' then raise; end if;
    end;
end;
$$;
reset role;
-- Eliminar una cuenta nunca borra su nonce antes de expirar.
delete from auth.users where id='11111111-1111-4111-8111-111111111111';
insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion)
values('33333333-3333-4333-8333-333333333333','persona-a','Fixture reasignación después de borrar cuenta');
-- Solo la limpieza de TTL puede retirar un nonce vencido.
insert into myg_nube_privado.ingresos_consumidos(nonce,auth_usuario_id,emitido,expira)
values('dddddddd-dddd-4ddd-8ddd-dddddddddddd','33333333-3333-4333-8333-333333333333',1,61);
set local role service_role;
do $$
declare v_ahora bigint := floor(extract(epoch from clock_timestamp()))::bigint;
begin
    begin
        perform public.myg_nube_canjear_ingreso('persona-a','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',v_ahora,v_ahora+60,repeat('A',64));
        raise exception 'Borrar/reasignar la cuenta permitió replay.';
    exception when unique_violation then
        if sqlerrm <> 'MYG_INGRESO_REUTILIZADO' then raise; end if;
    end;
    perform public.myg_nube_canjear_ingreso('persona-a','cccccccc-cccc-4ccc-8ccc-cccccccccccc',v_ahora,v_ahora+60,repeat('A',64));
end;
$$;
reset role;
do $$
begin
    if exists(select 1 from myg_nube_privado.ingresos_consumidos where nonce='dddddddd-dddd-4ddd-8ddd-dddddddddddd') then
        raise exception 'No se limpió el nonce vencido.';
    end if;
    if (select count(*) from myg_nube_privado.identidades_verificadas) <> 2
       or (select count(*) from auth.users) <> 2 then
        raise exception 'El canje creó cuentas/vinculaciones.';
    end if;
    if exists(select 1 from public.myg_nube_proyectos)
       or exists(select 1 from public.myg_nube_miembros)
       or exists(select 1 from public.myg_nube_solicitudes) then
        raise exception 'El canje modificó proyectos/roles/solicitudes.';
    end if;
end;
$$;
select 'PRUEBA_INGRESO_MYG_CORRECTA' as resultado;
rollback;
