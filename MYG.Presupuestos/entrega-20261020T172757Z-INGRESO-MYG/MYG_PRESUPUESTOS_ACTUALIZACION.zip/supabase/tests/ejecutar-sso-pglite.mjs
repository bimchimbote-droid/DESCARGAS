// Solo PostgreSQL en memoria; no recibe conexiones ni credenciales reales.
// Copiar junto a @electric-sql/pglite@0.3.14; ver README-INGRESO-MYG.md.
import { PGlite } from '@electric-sql/pglite';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const raiz = resolve(process.argv[2] || process.cwd());
const db = new PGlite();
try {
  await db.exec(`
    create role anon; create role authenticated; create role service_role bypassrls;
    create schema auth; create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as $$
      select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
    grant usage on schema auth to anon,authenticated,service_role;
    grant execute on function auth.uid() to anon,authenticated,service_role;
  `);
  await db.exec(await readFile(resolve(raiz, 'supabase/migrations/202610190001_nube_myg.sql'), 'utf8'));
  const migracion = await readFile(resolve(raiz, 'supabase/migrations/202610200003_ingreso_myg.sql'), 'utf8');
  // Una instalación con duplicados normalizados debe abortar sin modificar datos.
  await db.exec(`insert into auth.users values('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222');
    insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion)
    values('11111111-1111-4111-8111-111111111111','Persona','Fixture'),
          ('22222222-2222-4222-8222-222222222222',' persona ','Fixture');`);
  let duplicadoBloqueado = false;
  try { await db.exec(migracion); }
  catch (error) { duplicadoBloqueado = error.message.includes('duplicados al normalizar'); await db.exec('rollback'); }
  if (!duplicadoBloqueado) throw new Error('La migración no rechazó duplicados normalizados.');
  const intacto = await db.query(`select count(*)::int as cantidad,
    to_regclass('myg_nube_privado.ingresos_consumidos') as tabla from myg_nube_privado.identidades_verificadas`);
  if (intacto.rows[0].cantidad !== 2 || intacto.rows[0].tabla !== null) throw new Error('La migración fallida modificó el estado previo.');
  await db.exec('delete from auth.users'); // Solo limpia fixture PGlite, jamás datos de producción.
  await db.exec(migracion);
  console.log('MIGRACION_INGRESO_MYG_CORRECTA; DUPLICADOS_BLOQUEADOS_SIN_CAMBIOS');
  const resultado = await db.exec(await readFile(resolve(raiz, 'supabase/tests/ingreso_myg_regresion.sql'), 'utf8'));
  if (!resultado.some(r => r.rows?.some(f => f.resultado === 'PRUEBA_INGRESO_MYG_CORRECTA'))) throw new Error('Falta confirmación SQL final.');
  const final = await db.query(`select
    (select count(*) from myg_nube_privado.identidades_verificadas)::int as identidades,
    (select count(*) from myg_nube_privado.ingresos_consumidos)::int as nonces,
    (select count(*) from auth.users)::int as usuarios`);
  if (Object.values(final.rows[0]).some(cantidad => cantidad !== 0)) throw new Error('La regresión no revirtió datos.');
  console.log('PRUEBA_INGRESO_MYG_CORRECTA; ROLLBACK_CORRECTO');
} catch (error) {
  console.error(error.message, error.code || '', error.where || ''); process.exitCode = 1;
} finally { await db.close(); }
