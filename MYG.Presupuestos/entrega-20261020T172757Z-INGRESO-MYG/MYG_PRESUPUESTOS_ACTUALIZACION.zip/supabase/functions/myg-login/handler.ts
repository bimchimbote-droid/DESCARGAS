// Sin SDK ni dependencias remotas. El adaptador permite probar todo el flujo sin red.
type Entorno = (nombre: string) => string | undefined;
type Opciones = {
  env: Entorno;
  fetch?: typeof fetch;
  crypto?: Crypto;
  now?: () => number;
};
type Objeto = Record<string, unknown>;
type Claims = { iss: string; aud: string; sub: string; pc: string; jti: string; iat: number; exp: number };
const MAX_CUERPO = 16 * 1024;
const MAX_TICKET = 8 * 1024;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const CERO = '00000000-0000-0000-0000-000000000000';
const CODIGOS_RPC: Record<string, [number, string]> = {
  MYG_VINCULO_NO_VERIFICADO: [403, 'MYG_VINCULO_NO_VERIFICADO'],
  MYG_INGRESO_REUTILIZADO: [409, 'MYG_INGRESO_REUTILIZADO'],
  MYG_INGRESO_EXPIRADO: [401, 'MYG_INGRESO_EXPIRADO'],
  MYG_INGRESO_INVALIDO: [401, 'MYG_INGRESO_INVALIDO'],
};
class Fallo extends Error {
  readonly estado: number;
  readonly codigo: string;
  constructor(estado: number, codigo: string) { super(codigo); this.estado = estado; this.codigo = codigo; }
}
function objeto(valor: unknown): valor is Objeto {
  return typeof valor === 'object' && valor !== null && !Array.isArray(valor);
}
function uuid(valor: unknown): valor is string {
  return typeof valor === 'string' && UUID.test(valor) && valor !== CERO;
}
function usuario(valor: unknown): valor is string {
  return typeof valor === 'string' && valor.length >= 1 && valor.length <= 256 &&
    valor === valor.trim().toLowerCase() && !/[\u0000-\u001f\u007f\uD800-\uDFFF]/u.test(valor);
}
function respuesta(estado: number, cuerpo: unknown): Response {
  return new Response(JSON.stringify(cuerpo), {
    status: estado,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store',
      'pragma': 'no-cache', 'x-content-type-options': 'nosniff' },
  });
}
async function jsonAcotado(fuente: Request | Response, maximo: number): Promise<unknown> {
  const longitud = fuente.headers.get('content-length');
  if (longitud !== null && (!/^\d+$/.test(longitud) || Number(longitud) > maximo)) {
    throw new Fallo(413, 'MYG_SOLICITUD_DEMASIADO_GRANDE');
  }
  if (!fuente.body) throw new Fallo(400, 'MYG_SOLICITUD_INVALIDA');
  const lector = fuente.body.getReader();
  const bloques: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { value, done } = await lector.read();
      if (done) break;
      total += value.byteLength;
      if (total > maximo) {
        await lector.cancel();
        throw new Fallo(413, 'MYG_SOLICITUD_DEMASIADO_GRANDE');
      }
      bloques.push(value);
    }
  } finally { lector.releaseLock(); }
  const bytes = new Uint8Array(total);
  let posicion = 0;
  for (const bloque of bloques) { bytes.set(bloque, posicion); posicion += bloque.byteLength; }
  try { return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); }
  catch { throw new Fallo(400, 'MYG_SOLICITUD_INVALIDA'); }
}
function decodificar(segmento: string) {
  if (!/^[A-Za-z0-9_-]+$/.test(segmento) || segmento.length % 4 === 1) {
    throw new Fallo(401, 'MYG_INGRESO_INVALIDO');
  }
  try {
    const binario = atob(segmento.replace(/-/g, '+').replace(/_/g, '/'));
    const bytes = Uint8Array.from(binario, c => c.charCodeAt(0));
    // Rechaza representaciones base64url no canónicas de una misma firma.
    if (btoa(String.fromCharCode(...bytes)).replace(/=+$/g, '').replace(/\+/g, '-').replace(/\//g, '_') !== segmento) {
      throw new Error('base64url');
    }
    return bytes;
  } catch { throw new Fallo(401, 'MYG_INGRESO_INVALIDO'); }
}
function segmentoJson(segmento: string): unknown {
  try { return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(decodificar(segmento))); }
  catch { throw new Fallo(401, 'MYG_INGRESO_INVALIDO'); }
}
function configuracion(env: Entorno) {
  const url = (env('SUPABASE_URL') || '').replace(/\/$/, '');
  const servicio = env('SUPABASE_SERVICE_ROLE_KEY') || '';
  const anon = env('SUPABASE_ANON_KEY') || '';
  const secreto = env('MYG_NUBE_HMAC') || '';
  try {
    const destino = new URL(url);
    if (destino.protocol !== 'https:' || destino.username || destino.password || destino.search ||
      destino.hash || destino.pathname !== '/' || destino.origin !== url || !servicio || !anon ||
      !/^[0-9a-fA-F]{64}$/.test(secreto)) throw new Error('configuracion');
  } catch { throw new Fallo(503, 'MYG_NUBE_NO_CONFIGURADA'); }
  return { url, servicio, anon, secreto };
}
async function validarTicket(ticket: unknown, url: string, clave: CryptoKey, cripto: Crypto, ahora: number): Promise<Claims> {
  if (typeof ticket !== 'string' || ticket.length > MAX_TICKET || ticket.length < 40) {
    throw new Fallo(401, 'MYG_INGRESO_INVALIDO');
  }
  const segmentos = ticket.split('.');
  if (segmentos.length !== 3) throw new Fallo(401, 'MYG_INGRESO_INVALIDO');
  const cabecera = segmentoJson(segmentos[0]);
  if (!objeto(cabecera) || cabecera.alg !== 'HS256' || cabecera.typ !== 'JWT' ||
    Object.keys(cabecera).some(k => k !== 'alg' && k !== 'typ')) throw new Fallo(401, 'MYG_INGRESO_INVALIDO');
  const firma = decodificar(segmentos[2]);
  if (firma.length !== 32 || !await cripto.subtle.verify('HMAC', clave, firma,
    new TextEncoder().encode(`${segmentos[0]}.${segmentos[1]}`))) throw new Fallo(401, 'MYG_INGRESO_INVALIDO');
  const p = segmentoJson(segmentos[1]);
  if (!objeto(p) || Object.keys(p).sort().join(',') !== 'aud,exp,iat,iss,jti,pc,sub' ||
    p.iss !== 'MYG_LICENCIAS' || p.aud !== url || !usuario(p.sub) || !uuid(p.jti) ||
    typeof p.pc !== 'string' || !/^[0-9A-F]{64}$/.test(p.pc) ||
    !Number.isSafeInteger(p.iat) || !Number.isSafeInteger(p.exp) ||
    (p.iat as number) < 1 || (p.exp as number) <= (p.iat as number) ||
    (p.exp as number) - (p.iat as number) > 90 || (p.iat as number) > ahora + 30) {
    throw new Fallo(401, 'MYG_INGRESO_INVALIDO');
  }
  if ((p.exp as number) < ahora - 30) throw new Fallo(401, 'MYG_INGRESO_EXPIRADO');
  return p as Claims;
}

export function crearHandler(opciones: Opciones): (solicitud: Request) => Promise<Response> {
  const enviar = opciones.fetch || globalThis.fetch;
  const cripto = opciones.crypto || globalThis.crypto;
  const reloj = opciones.now || (() => Date.now());
  let clave: Promise<CryptoKey> | undefined;
  return async (solicitud: Request): Promise<Response> => {
    if (solicitud.method !== 'POST') return respuesta(405, { error: 'MYG_METODO_NO_PERMITIDO' });
    try {
      const config = configuracion(opciones.env);
      const tipo = solicitud.headers.get('content-type')?.split(';')[0].trim().toLowerCase();
      if (tipo !== 'application/json') throw new Fallo(400, 'MYG_SOLICITUD_INVALIDA');
      const entrada = await jsonAcotado(solicitud, MAX_CUERPO);
      if (!objeto(entrada) || Object.keys(entrada).length !== 1 || !('ticket' in entrada)) {
        throw new Fallo(400, 'MYG_SOLICITUD_INVALIDA');
      }
      clave ||= cripto.subtle.importKey('raw', new TextEncoder().encode(config.secreto),
        { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
      const p = await validarTicket(entrada.ticket, config.url, await clave, cripto, Math.floor(reloj() / 1000));
      // Todos los destinos son rutas constantes bajo SUPABASE_URL; nunca se sigue una redirección.
      const llamar = async (ruta: string, cuerpo?: unknown, admin = true): Promise<Objeto> => {
        const llave = admin ? config.servicio : config.anon;
        let resultado: Response;
        try {
          resultado = await enviar(config.url + ruta, { method: cuerpo === undefined ? 'GET' : 'POST',
            headers: { apikey: llave, Authorization: `Bearer ${llave}`, 'Content-Type': 'application/json' },
            body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo), redirect: 'error',
            signal: AbortSignal.timeout(10000) });
        } catch { throw new Fallo(503, 'MYG_NUBE_NO_DISPONIBLE'); }
        let datos: unknown;
        try { datos = await jsonAcotado(resultado, 1024 * 1024); }
        catch { throw new Fallo(503, 'MYG_NUBE_NO_DISPONIBLE'); }
        if (!resultado.ok) {
          if (ruta === '/rest/v1/rpc/myg_nube_canjear_ingreso' && objeto(datos) && typeof datos.message === 'string') {
            const fallo = CODIGOS_RPC[datos.message];
            if (fallo) throw new Fallo(...fallo);
          }
          if (resultado.status === 404 && ruta.startsWith('/auth/v1/admin/users/')) {
            throw new Fallo(403, 'MYG_VINCULO_NO_VERIFICADO');
          }
          throw new Fallo(503, 'MYG_NUBE_NO_DISPONIBLE');
        }
        if (!objeto(datos)) throw new Fallo(503, 'MYG_NUBE_NO_DISPONIBLE');
        return datos;
      };
      const vinculo = await llamar('/rest/v1/rpc/myg_nube_canjear_ingreso', {
        p_usuario: p.sub, p_nonce: p.jti, p_emitido: p.iat, p_expira: p.exp, p_pc: p.pc,
      });
      if (!uuid(vinculo.usuario_id) || vinculo.usuario_myg !== p.sub) throw new Fallo(503, 'MYG_NUBE_NO_DISPONIBLE');
      const perfil = await llamar(`/auth/v1/admin/users/${vinculo.usuario_id}`);
      if (perfil.id !== vinculo.usuario_id || typeof perfil.email !== 'string' ||
        !perfil.email || perfil.email.length > 320 || /[\s\u0000-\u001f\u007f]/.test(perfil.email) ||
        perfil.is_anonymous === true || perfil.deleted_at ||
        (typeof perfil.banned_until === 'string' && Date.parse(perfil.banned_until) > reloj())) {
        throw new Fallo(403, 'MYG_VINCULO_NO_VERIFICADO');
      }
      // recovery falla si desapareció el usuario; magiclink podría crear una cuenta.
      // Solo genera/consume el OTP internamente: no envía correo ni cambia contraseña.
      const generado = await llamar('/auth/v1/admin/generate_link', { type: 'recovery', email: perfil.email });
      if (generado.id !== vinculo.usuario_id || generado.verification_type !== 'recovery' ||
        typeof generado.hashed_token !== 'string' || !generado.hashed_token || generado.hashed_token.length > 512) {
        throw new Fallo(503, 'MYG_NUBE_NO_DISPONIBLE');
      }
      const sesion = await llamar('/auth/v1/verify', { token_hash: generado.hashed_token, type: 'recovery' }, false);
      if (!objeto(sesion.user) || sesion.user.id !== vinculo.usuario_id ||
        typeof sesion.access_token !== 'string' || !sesion.access_token || sesion.access_token.length > 16384 ||
        typeof sesion.refresh_token !== 'string' || !sesion.refresh_token || sesion.refresh_token.length > 4096 ||
        !Number.isSafeInteger(sesion.expires_in) || (sesion.expires_in as number) < 1 ||
        (sesion.expires_in as number) > 604800) throw new Fallo(503, 'MYG_NUBE_NO_DISPONIBLE');
      return respuesta(200, { access_token: sesion.access_token, refresh_token: sesion.refresh_token,
        expires_in: sesion.expires_in, user: { id: vinculo.usuario_id }, usuario_myg: p.sub });
    } catch (fallo) {
      // Jamás registrar el ticket, credenciales, enlaces, OTP ni respuestas de Auth.
      if (fallo instanceof Fallo) return respuesta(fallo.estado, { error: fallo.codigo });
      return respuesta(503, { error: 'MYG_NUBE_NO_DISPONIBLE' });
    }
  };
}
