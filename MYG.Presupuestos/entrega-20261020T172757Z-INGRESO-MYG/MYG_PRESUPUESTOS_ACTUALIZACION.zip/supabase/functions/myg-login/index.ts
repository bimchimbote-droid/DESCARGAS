import { crearHandler } from './handler.ts';

Deno.serve(crearHandler({ env: (nombre) => Deno.env.get(nombre) }));
