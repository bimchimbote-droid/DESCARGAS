-- Ingreso único MYG -> Auth. Solo agrega el canje; conserva cuentas, proyectos y roles.
-- Ejecutar DESPUÉS de 202610190001_nube_myg.sql como administrador PostgreSQL.
begin;
set local lock_timeout = '5s';

do $$
begin
    if to_regclass('myg_nube_privado.identidades_verificadas') is null then
        raise exception 'Falta la migración Nube MYG 001; no se cambió ninguna cuenta.';
    end if;
    if exists (select 1 from myg_nube_privado.identidades_verificadas
               group by lower(btrim(usuario_myg)) having count(*) > 1) then
        raise exception 'Existen usuarios MYG duplicados al normalizar; revise las vinculaciones sin borrar datos.';
    end if;
    if to_regclass('myg_nube_privado.ingresos_consumidos') is not null
       or to_regprocedure('public.myg_nube_canjear_ingreso(text,uuid,bigint,bigint,text)') is not null then
        raise exception 'El ingreso MYG ya existe; revise el historial de migraciones.';
    end if;
end;
$$;

create unique index identidades_verificadas_usuario_normalizado
    on myg_nube_privado.identidades_verificadas (lower(btrim(usuario_myg)));

create table myg_nube_privado.ingresos_consumidos (
    nonce uuid primary key check(nonce <> '00000000-0000-0000-0000-000000000000'::uuid),
    -- Sin FK: borrar/revocar una cuenta no permite reutilizar un ticket ya consumido.
    auth_usuario_id uuid not null,
    emitido bigint not null,
    expira bigint not null,
    consumido_en timestamptz not null default clock_timestamp(),
    check(expira > emitido and expira - emitido <= 90)
);
create index ingresos_consumidos_expira on myg_nube_privado.ingresos_consumidos(expira);
alter table myg_nube_privado.ingresos_consumidos enable row level security;
revoke all on myg_nube_privado.ingresos_consumidos from public, anon, authenticated, service_role;

create function public.myg_nube_canjear_ingreso(
    p_usuario text, p_nonce uuid, p_emitido bigint, p_expira bigint, p_pc text
) returns jsonb
language plpgsql security definer set search_path = pg_catalog, myg_nube_privado as $$
declare
    v_ahora bigint := floor(extract(epoch from clock_timestamp()))::bigint;
    v_id uuid;
    v_usuario text;
begin
    -- La firma HMAC se valida en Edge. Solo service_role puede llegar a este canje.
    if p_usuario is null or length(p_usuario) not between 1 and 256
       or p_usuario <> lower(btrim(p_usuario)) or p_usuario ~ '[[:cntrl:]]'
       or p_nonce is null or p_nonce = '00000000-0000-0000-0000-000000000000'::uuid
       or p_pc is null or p_pc !~ '^[0-9A-F]{64}$'
       or p_emitido is null or p_expira is null or p_emitido < 1
       or p_expira <= p_emitido or p_expira::numeric - p_emitido::numeric > 90
       or p_emitido > v_ahora + 30 then
        raise exception using errcode = '22023', message = 'MYG_INGRESO_INVALIDO';
    end if;
    if p_expira < v_ahora - 30 then
        raise exception using errcode = '28000', message = 'MYG_INGRESO_EXPIRADO';
    end if;
    -- Bloqueo compartido hasta finalizar el canje para serializar revocación del vínculo.
    select i.auth_usuario_id, lower(btrim(i.usuario_myg)) into v_id, v_usuario
      from myg_nube_privado.identidades_verificadas i
      join auth.users u on u.id = i.auth_usuario_id
     where lower(btrim(i.usuario_myg)) = p_usuario and i.activo
     for share of i, u;
    if v_id is null then
        raise exception using errcode = '42501', message = 'MYG_VINCULO_NO_VERIFICADO';
    end if;
    -- Conservar el nonce hasta fuera de la tolerancia. Un ticket vencido no se acepta
    -- aunque su fila ya se haya limpiado. El índice único serializa canjes simultáneos.
    delete from myg_nube_privado.ingresos_consumidos where expira < v_ahora - 30;
    begin
        insert into myg_nube_privado.ingresos_consumidos(nonce, auth_usuario_id, emitido, expira)
        values(p_nonce, v_id, p_emitido, p_expira);
    exception when unique_violation then
        raise exception using errcode = '23505', message = 'MYG_INGRESO_REUTILIZADO';
    end;
    return jsonb_build_object('usuario_id', v_id, 'usuario_myg', v_usuario);
end;
$$;
revoke all on function public.myg_nube_canjear_ingreso(text, uuid, bigint, bigint, text)
    from public, anon, authenticated;
grant execute on function public.myg_nube_canjear_ingreso(text, uuid, bigint, bigint, text)
    to service_role;
comment on function public.myg_nube_canjear_ingreso(text, uuid, bigint, bigint, text)
    is 'Solo Edge con service_role, después de verificar ticket MYG firmado. No otorga roles de proyecto.';
notify pgrst, 'reload schema';
commit;
