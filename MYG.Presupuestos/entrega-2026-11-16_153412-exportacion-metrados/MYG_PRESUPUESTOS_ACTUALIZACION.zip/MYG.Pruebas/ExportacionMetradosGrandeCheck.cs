using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ExportacionMetradosGrandeCheck
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static void Rechaza(Action accion, string mensaje)
    { try { accion(); } catch (InvalidDataException) { return; } throw new Exception(mensaje); }

    private static ItemPresupuestoDelphin Partida(string nombre, int posicion)
    {
        string id = MYGProyectoStorage.NuevoId();
        var hoja = new MYGHojaMetrado { Filas = 800, Columnas = 8, CeldaTotal = "G800" };
        hoja.AnchosColumnas[1] = 288 + posicion * 8;
        hoja.Poner("A3", nombre); hoja.Poner("B3", "2"); hoja.Poner("C3", "3");
        hoja.Poner("G800", "=B3*C3");
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, TipoPropuesta = "PARTIDA", Descripcion = nombre, Unidad = "m",
            Item = posicion.ToString("D2", CultureInfo.InvariantCulture), Posicion = posicion,
            Costos = new MYGDatosPartida { FuenteMetrado = MYGFuenteMetrado.Excel, Hoja = hoja }
        };
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("PROYECTO XLSX GRANDE", "PRESUPUESTO UNO");
        var p = d.Presupuestos.Single();
        for (int n = 1; n <= 7; n++) p.Items.Add(Partida("BLOQUE UNO " + n, n));
        var otro = new MYGPresupuestoDocumento { Nombre = "PRESUPUESTO DOS", Posicion = 2, Item = "02" };
        for (int n = 1; n <= 7; n++) otro.Items.Add(Partida("BLOQUE DOS " + n, n));
        d.Presupuestos.Add(otro);
        var primero = p.Items[0]; var ultimo = otro.Items[^1];
        primero.Costos.Hoja.Celdas["B3"].Contenido = "=" +
            MYGReferenciasMetrado.CrearReferencia(primero.Costos.Hoja, otro, ultimo, "G800") + "+1";
        string antes = JsonSerializer.Serialize(d);
        var consolidado = MYGReporteMetradosExcel.CrearParaExportar(d, p.Id, todosPresupuestos: true).Hoja;
        Exige(consolidado.Filas > 10000 && (long)consolidado.Filas * consolidado.Columnas > 200000,
            "La prueba no excede ambos límites antiguos del consolidado.");
        Exige(JsonSerializer.Serialize(d) == antes, "Componer la exportación modificó el proyecto.");
        Rechaza(() => MYGHojaCalculo.Validar(MYGProyectoStorage.Copia(consolidado)),
            "Ampliar la exportación también amplió indebidamente el editor de partidas.");
        MYGHojaCalculo.ValidarParaExportacion(consolidado);
        string destino = Path.Combine(carpeta, "Proyecto completo mayor de 10000 filas.xlsx");
        MYGExcelPresupuestos.GuardarParaExportacion(destino, new[] { consolidado });
        using (var z = ZipFile.OpenRead(destino))
        {
            using var flujo = z.GetEntry("xl/worksheets/sheet1.xml").Open();
            var x = XDocument.Load(flujo);
            Exige(x.Descendants(S + "row").Any(f => (int)f.Attribute("r") > 10000),
                "El XLSX truncó las filas posteriores a 10000.");
            Exige(x.Descendants(S + "f").Any(f => !f.Value.Contains("METRADO", StringComparison.OrdinalIgnoreCase) &&
                    System.Text.RegularExpressions.Regex.IsMatch(f.Value, @"[A-Z]+1[0-9]{4}")),
                "La referencia a la última partida no se trasladó más allá de la fila 10000.");
            Exige(x.Descendants(S + "c").Any(c => (string)c.Element(S + "v") == "21" && c.Element(S + "f") != null),
                "El XLSX perdió el resultado de la fórmula entre presupuestos.");
            string texto = string.Concat(x.Descendants(S + "t").Select(t => t.Value));
            // Las bandas de texto también pueden almacenarse como fórmulas de texto con caché.
            texto += string.Concat(x.Descendants(S + "c").Where(c => (string)c.Attribute("t") == "str").Select(c => c.Element(S + "v")?.Value));
            Exige(texto.Contains("BLOQUE UNO 1", StringComparison.Ordinal) && texto.Contains("BLOQUE DOS 7", StringComparison.Ordinal),
                "El proyecto exportado perdió partidas del primer o último presupuesto.");
        }
        pasa("XLSX consolida más de 10000 filas y 200000 celdas de área, mantiene última partida y fórmulas entre presupuestos sin ampliar el editor");

        var seleccion = MYGReporteMetradosExcel.CrearParaExportar(d, p.Id).Hoja;
        var calculo = new MYGHojaCalculo(seleccion);
        Exige(seleccion.Celdas.Any(c => calculo.Mostrar(c.Key).Contains("BLOQUE UNO 1", StringComparison.Ordinal)) &&
            !seleccion.Celdas.Any(c => calculo.Mostrar(c.Key).Contains("BLOQUE DOS 7", StringComparison.Ordinal)) &&
            seleccion.Celdas.Any(c => c.Value.Contenido == "7"),
            "El alcance presupuesto incluyó partidas ajenas o perdió el valor de una dependencia externa.");
        string presupuesto = Path.Combine(carpeta, "Presupuesto seleccionado.xlsx");
        MYGReporteMetradosExcel.Exportar(presupuesto, d, p.Id);
        Exige(File.Exists(presupuesto) && JsonSerializer.Serialize(d) == antes, "Exportar por presupuesto mutó el documento o no creó el archivo.");
        pasa("La exportación por presupuesto respeta su selección y conserva valores de referencias ajenas sin añadir otro presupuesto");

        var limite = new MYGHojaMetrado { Filas = 1048576, Columnas = 1, CeldaTotal = "A1048576" };
        limite.Poner("A1048576", "17");
        string ultimaFila = Path.Combine(carpeta, "Ultima fila XLSX.xlsx");
        MYGExcelPresupuestos.GuardarParaExportacion(ultimaFila, new[] { limite });
        using (var z = ZipFile.OpenRead(ultimaFila))
        using (var flujo = z.GetEntry("xl/worksheets/sheet1.xml").Open())
            Exige(XDocument.Load(flujo).Descendants(S + "c").Any(c => (string)c.Attribute("r") == "A1048576"),
                "El escritor omitió la última fila admitida por XLSX.");
        limite.Filas++;
        Rechaza(() => MYGHojaCalculo.ValidarParaExportacion(limite), "La exportación aceptó filas fuera de XLSX.");
        Exige(JsonSerializer.Serialize(d) == antes, "La prueba de límites alteró el proyecto de origen.");
        pasa("El perfil de exportación admite la fila 1048576 y rechaza exceder las dimensiones XLSX");

        MuestraReal(carpeta, pasa);
    }

    private static void MuestraReal(string carpeta, Action<string> pasa)
    {
        string ruta = Environment.GetEnvironmentVariable("MYG_QA_METRADO_DELPHIN_SQLITE");
        if (string.IsNullOrWhiteSpace(ruta))
        { Console.WriteLine("OMITIDA: muestra externa para exportar el proyecto completo."); return; }
        byte[] firma = SHA256.HashData(File.ReadAllBytes(ruta));
        bool excedeLimiteAnterior = false;
        foreach (var resumen in MYGBaseDatos.ListarProyectos(ruta))
        {
            var d = MYGBaseDatos.LeerProyecto(ruta, resumen.Id);
            string antes = MYGProyectoStorage.Firma(d);
            var h = MYGReporteMetradosExcel.CrearParaExportar(d, todosPresupuestos: true).Hoja;
            excedeLimiteAnterior |= h.Filas > 10000 || (long)h.Filas * h.Columnas > 200000;
            string salida = Path.Combine(carpeta, "Metrados reales " + Guid.NewGuid().ToString("N") + ".xlsx");
            MYGExcelPresupuestos.GuardarParaExportacion(salida, new[] { h });
            using (var z = ZipFile.OpenRead(salida))
            using (var flujo = z.GetEntry("xl/worksheets/sheet1.xml").Open())
            {
                var x = XDocument.Load(flujo);
                Exige(x.Descendants(S + "row").Max(f => (int)f.Attribute("r")) >= h.Celdas.Keys.Max(k => MYGHojaCalculo.Coordenadas(k).Fila),
                    "La exportación real perdió las últimas filas.");
                Exige(!x.Descendants(S + "c").Any(c => (string)c.Attribute("t") == "e"),
                    "La exportación real generó errores de cálculo.");
                Exige(x.Descendants(S + "f").Any(), "La exportación real perdió todas las fórmulas.");
            }
            Exige(MYGProyectoStorage.Firma(d) == antes, "Exportar la muestra alteró el proyecto en memoria.");
            Console.WriteLine($"XLSX muestra: {h.Filas} filas, {h.Columnas} columnas, {h.Celdas.Count} celdas almacenadas.");
        }
        Exige(excedeLimiteAnterior && firma.SequenceEqual(SHA256.HashData(File.ReadAllBytes(ruta))),
            "La muestra no reprodujo el límite anterior o el archivo original fue modificado.");
        pasa("La muestra real exporta todos los proyectos sin el aviso de tamaño, conserva fórmulas y deja intacta la base original");
    }
}
