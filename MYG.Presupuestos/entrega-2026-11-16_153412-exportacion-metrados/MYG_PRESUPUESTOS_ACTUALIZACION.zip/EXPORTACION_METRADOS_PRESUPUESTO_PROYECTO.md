# Exportar metrados Excel del presupuesto o del proyecto

Esta entrega parte de la última actualización de metrados Delphin entregada en `DESCARGAS`, commit `dddd53a1a0c4fbb63eca2119ef61a304de1b9e29` (código base `main/e48bb43720f204ad310ecbae18afa784e4b4063d`). Conserva esa corrección. Aplicar sobre esa versión ya instalada, no sobre una versión anterior sin el intercambio nativo de Delphin.

## Uso

En **Imprimir / PDF → Metrados (Formato DE Excel)** aparecen dos opciones:

- **Presupuesto seleccionado (.xlsx)**: solo las partidas Excel del presupuesto activo.
- **Proyecto completo (.xlsx)**: partidas Excel de todos los presupuestos del proyecto abierto, en una sola hoja consolidada.

Ambas abren el diálogo Guardar y exportan directamente el archivo XLSX. La opción de exportar metrados completos desde el panel también utiliza el mismo exportador. No es necesario abrir la vista previa para guardar un proyecto grande.

La opción de proyecto sigue disponible si el presupuesto actual no tiene metrados Excel, pero otro presupuesto del proyecto sí los tiene. Seleccionar un alcance no modifica la base, los metrados ni las cantidades.

## Corrección del límite

El aviso de 10.000 filas/200.000 celdas correspondía al límite de la hoja editable de una partida. Ahora el consolidado XLSX usa un perfil separado: hasta 1.048.576 filas y 16.384 columnas, con un máximo práctico de 2.000.000 de celdas almacenadas con contenido o formato, 200.000 combinaciones y 2.000.000 de celdas abarcadas por combinaciones. Superar estos límites produce un aviso; no se truncan partidas.

Las filas se escriben progresivamente en el ZIP de Excel. Se conservan bandas de presupuesto/partida, orden, fórmulas, resultados, formatos, combinaciones y filas ocultas. Las referencias entre partidas incluidas se trasladan al consolidado; si un origen queda fuera de la selección, se conserva su valor calculado sin añadir otro presupuesto.

Los límites del editor y del importador de hojas permanecen iguales. La vista previa de MYG mantiene su límite; para consolidaciones grandes se utiliza la nueva exportación directa. El formato de salida es `.xlsx`, no `.xls`.

## Archivos que deben aplicarse

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `MYG.Core/EdicionHojaMetrado.cs` | REEMPLAZAR | Validación de combinaciones por intervalos |
| 2 | `MYG.Core/HojaMetrado.cs` | REEMPLAZAR | Perfil separado de exportación |
| 3 | `MYG.Core/HojaMetradoExcelEscritura.cs` | CREAR | Escritura XLSX por filas |
| 4 | `MYG.Core/LimitesExportacionExcel.cs` | CREAR | Límites del archivo exportado |
| 5 | `MYG.Core/MYGReporteMetradosExcel.cs` | REEMPLAZAR | Consolidación ampliada y selección de alcance |
| 6 | `MYG.Desktop/EditorHerramientas.cs` | REEMPLAZAR | Submenú de presupuesto/proyecto |
| 7 | `MYG.Desktop/PresupuestosExcelPanel.cs` | REEMPLAZAR | Exportación directa del proyecto |
| 8 | `MYG.Pruebas/ExportacionMetradosGrandeCheck.cs` | CREAR | Regresión de tamaño y alcance |
| 9 | `MYG.Pruebas/Program.cs` | REEMPLAZAR | Registro de las nuevas pruebas |
| 10 | `MYG.PruebasUI/ImprimirProyectoCheck.cs` | REEMPLAZAR | Pruebas del desplegable |
| 11 | `EXPORTACION_METRADOS_PRESUPUESTO_PROYECTO.md` | CREAR | Esta guía |

Todos los archivos REEMPLAZAR se entregan completos, con los cambios anteriores preservados. No hay eliminaciones, parches, migraciones SQL, dependencias nuevas ni cambios de conexión. Los proyectos SDK incluyen automáticamente los nuevos archivos `.cs`.

## Instalación y compilación

1. Respaldar o confirmar cambios locales en Visual Studio y cerrar MYG.
2. Extraer el ZIP sobre la carpeta del código que ya contiene la última corrección Delphin, conservando las rutas. Comparar antes de reemplazar si se modificaron esos archivos después de la entrega anterior.
3. Compilar con .NET SDK 10.0.100 o el roll-forward admitido por `global.json`:

   ```powershell
   dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true
   dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --exportacion-metrados
   ```

4. Abrir una copia de la obra. Exportar el presupuesto seleccionado y el proyecto completo desde el nuevo submenú. Abrir ambos XLSX en Excel y verificar presupuestos, última partida, totales y presentación.
5. Revisar los cambios en **Cambios de Git** de Visual Studio; hacer Commit y Push a la rama elegida y comprobarlos en GitHub. La publicación del ZIP no modifica automáticamente el repositorio del código.

## Validación

La solución compila con C#/.NET 10.0.100 y SQLite. La prueba específica ejecutó 16 grupos, incluidos casos de más de 10.000 filas y de más de 200.000 celdas de área, referencias entre presupuestos y la última fila permitida por XLSX.

Con la muestra proporcionada, las exportaciones de sus dos proyectos produjeron hojas de 762 y 10.430 filas; el proyecto grande contiene 91.374 celdas almacenadas en 10 columnas. Las fórmulas se conservaron sin errores OOXML y la base original permaneció intacta. No se incluye ninguna base privada en la entrega.

Para repetir la prueba con la muestra de la incidencia, indicar su ruta mediante `MYG_QA_METRADO_DELPHIN_SQLITE`. Las pruebas visuales del desplegable están compiladas y requieren Windows para ejecutarse. La apertura manual en Microsoft Excel y la comprobación visual del menú quedan pendientes en Windows. No se afirma haber ejecutado Revit ni Delphin en Linux.
