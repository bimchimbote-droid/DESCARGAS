using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace MYG_2027;

public static partial class MYGExcelPresupuestos
{
    private readonly record struct CeldaOrdenada(string Direccion, MYGCeldaHoja Celda, int Fila, int Columna);

    private static void EscribirHoja(ZipArchiveEntry entrada, MYGHojaMetrado hoja,
        Dictionary<MYGCeldaHoja, int> estilos, MYGExportacionReferenciasExcel referencias)
    {
        // Se analizan las direcciones una sola vez. La hoja se escribe por filas
        // sin materializar un árbol XML con todas las celdas del informe.
        var celdas = hoja.Celdas.Select(c =>
        {
            var p = MYGHojaCalculo.Coordenadas(c.Key);
            return new CeldaOrdenada(c.Key, c.Value, p.Fila, p.Columna);
        }).ToArray();
        Array.Sort(celdas, (a, b) => a.Fila != b.Fila ? a.Fila.CompareTo(b.Fila) : a.Columna.CompareTo(b.Columna));
        var ocultas = hoja.FilasOcultas.ToHashSet();
        var filasConFormato = hoja.AltosFilas.Keys.Concat(ocultas).Distinct().OrderBy(f => f).ToArray();
        using var salida = entrada.Open();
        using var xml = XmlWriter.Create(salida, new XmlWriterSettings
        { Encoding = new UTF8Encoding(false), Indent = false, CloseOutput = false });
        xml.WriteStartDocument();
        xml.WriteStartElement("worksheet", S.NamespaceName);
        if (hoja.AjustarImpresionAUnaPaginaAncho)
            new XElement(S + "sheetPr", new XElement(S + "pageSetUpPr", new XAttribute("fitToPage", 1))).WriteTo(xml);
        MYGFormatoExcelHoja.Vista(hoja).WriteTo(xml);
        new XElement(S + "sheetFormatPr", new XAttribute("defaultRowHeight", 18)).WriteTo(xml);
        MYGFormatoExcelHoja.Columnas(hoja).WriteTo(xml);
        xml.WriteStartElement("sheetData", S.NamespaceName);
        int indice = 0, formato = 0;
        while (indice < celdas.Length || formato < filasConFormato.Length)
        {
            int fila = Math.Min(indice < celdas.Length ? celdas[indice].Fila : int.MaxValue,
                formato < filasConFormato.Length ? filasConFormato[formato] : int.MaxValue);
            xml.WriteStartElement("row", S.NamespaceName);
            xml.WriteAttributeString("r", fila.ToString(CultureInfo.InvariantCulture));
            if (hoja.AltosFilas.TryGetValue(fila, out int alto))
            {
                xml.WriteAttributeString("ht", (alto * 0.75m).ToString(CultureInfo.InvariantCulture));
                xml.WriteAttributeString("customHeight", "1");
            }
            if (ocultas.Contains(fila)) xml.WriteAttributeString("hidden", "1");
            while (indice < celdas.Length && celdas[indice].Fila == fila)
            {
                var celda = celdas[indice++];
                CrearCelda(hoja, celda.Direccion, celda.Celda, estilos[celda.Celda], referencias).WriteTo(xml);
            }
            xml.WriteEndElement();
            if (formato < filasConFormato.Length && filasConFormato[formato] == fila) formato++;
        }
        xml.WriteEndElement();
        foreach (var complemento in MYGFormatoExcelHoja.Complementos(hoja)) complemento.WriteTo(xml);
        xml.WriteEndElement();
        xml.WriteEndDocument();
    }

    private static XElement CrearCelda(MYGHojaMetrado hoja, string direccion, MYGCeldaHoja datos,
        int estilo, MYGExportacionReferenciasExcel referencias)
    {
        string texto = datos.Contenido ?? "";
        var celda = new XElement(S + "c", new XAttribute("r", direccion), new XAttribute("s", estilo));
        if (texto.StartsWith('='))
        {
            // La conversión usa los mismos nombres finales y copias que el
            // cálculo de la caché, también para vínculos entre presupuestos.
            if (referencias.IntentarConvertir(hoja, texto, out string formula))
                celda.Add(new XElement(S + "f", formula[1..]));
            try
            {
                var resultado = referencias.Resultado(hoja, direccion);
                if (resultado.EsTexto) celda.Add(new XAttribute("t", "str"), new XElement(S + "v", resultado.Texto));
                else if (resultado.EsLogico) celda.Add(new XAttribute("t", "b"), new XElement(S + "v", resultado.Logico ? "1" : "0"));
                else celda.Add(new XElement(S + "v", resultado.Numero().ToString(CultureInfo.InvariantCulture)));
            }
            catch (Exception ex) when (ex is FormatException or InvalidDataException or OverflowException or DivideByZeroException)
            {
                celda.Add(new XAttribute("t", "e"), new XElement(S + "v", ex is MYGErrorReferenciaMetrado ? "#REF!" :
                    ex is MYGErrorExcel error ? error.Codigo : ex is DivideByZeroException ? "#DIV/0!" : "#VALUE!"));
            }
        }
        else if (MYGHojaCalculo.IntentarNumero(texto, out var numero))
            celda.Add(new XElement(S + "v", numero.ToString(CultureInfo.InvariantCulture)));
        else celda.Add(new XAttribute("t", "inlineStr"), new XElement(S + "is",
            new XElement(S + "t", new XAttribute(XNamespace.Xml + "space", "preserve"), TextoXml(texto))));
        return celda;
    }

    private static string TextoXml(string texto)
    {
        var resultado = new StringBuilder(texto.Length);
        for (int i = 0; i < texto.Length; i++)
        {
            char c = texto[i];
            if (char.IsHighSurrogate(c) && i + 1 < texto.Length && char.IsLowSurrogate(texto[i + 1]))
            { resultado.Append(c).Append(texto[++i]); continue; }
            if (XmlConvert.IsXmlChar(c)) resultado.Append(c);
        }
        return resultado.ToString();
    }
}
