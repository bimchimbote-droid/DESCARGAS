namespace MYG_2027;

// Límites del archivo exportado. No amplían las hojas editables ni se guardan
// como permisos o indicadores en el documento del usuario.
internal static class MYGLimitesExportacionExcel
{
    internal const int Filas = 1_048_576;
    internal const int Columnas = 16_384;
    internal const int Celdas = 2_000_000;
    internal const int Combinaciones = 200_000;
    internal const long CeldasCombinadas = 2_000_000;
}
