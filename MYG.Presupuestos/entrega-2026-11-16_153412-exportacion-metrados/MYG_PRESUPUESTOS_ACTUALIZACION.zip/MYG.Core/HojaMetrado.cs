using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Text.Json.Serialization;
using System.Xml;
using System.Xml.Linq;

namespace MYG_2027
{
    public sealed class MYGCeldaHoja
    {
        public const string FuentePredeterminada = "Arial Narrow";
        public string Contenido { get; set; } = "";
        public bool Negrita { get; set; }
        public bool Cursiva { get; set; }
        public string Fuente { get; set; } = FuentePredeterminada;
        public decimal TamanoFuente { get; set; } = 9m;
        public bool Subrayado { get; set; }
        public bool Tachado { get; set; }
        public string ColorTexto { get; set; } = "";
        public string ColorFondo { get; set; } = "";
        public string AlineacionHorizontal { get; set; } = "Izquierda";
        // Earlier sheets saved the same left alignment for every data column.
        // Explicit formatting in the editor or an imported workbook overrides
        // the measurement template's per-column defaults.
        public bool AlineacionPersonalizada { get; set; }
        public string AlineacionVertical { get; set; } = "Centro";
        public bool AjustarTexto { get; set; }
        public bool Bordes { get; set; }
        public string FormatoNumero { get; set; } = "0.0000";
        public string TipoValidacion { get; set; } = "Ninguna";
        public decimal? Minimo { get; set; }
        public decimal? Maximo { get; set; }
        public List<string> ListaValores { get; set; } = new();
    }
    public sealed class MYGHojaMetrado
    {
        public string Nombre { get; set; } = "Metrado";
        // Se guarda dentro del JSON de la hoja; una hoja importada o anterior
        // conserva una identidad vacía hasta que se seleccione una plantilla.
        public string IdPlantilla { get; set; } = "";
        // Contenido automático de la plantilla configurada al crear esta hoja.
        // Conserva sus parámetros aunque cambien las preferencias del usuario;
        // las hojas anteriores siguen usando la plantilla integrada.
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public Dictionary<string, string> ContenidoInicialPlantilla { get; set; }
        // null corresponde a hojas anteriores; vacío significa que el cuerpo
        // de la plantilla fue eliminado. Sigue las ediciones estructurales.
        public string RangoCuerpoPlantilla { get; set; }
        // Las hojas anteriores conservan cuatro decimales. Las plantillas
        // nuevas establecen su formato también para las celdas aún vacías.
        public string FormatoNumeroPredeterminado { get; set; } = "0.0000";
        // Permite completar una sola vez el relleno que faltaba en cabeceras
        // estándar guardadas, sin volver a imponerlo tras una edición manual.
        public bool RellenoCabeceraEstandarAplicado { get; set; }
        public int Filas { get; set; } = 100;
        public int Columnas { get; set; } = 12;
        public string CeldaTotal { get; set; } = "G16";
        public List<string> RangosCombinados { get; set; } = new();
        public bool LineasDivision { get; set; } = true;
        public bool Encabezados { get; set; } = true;
        public int Zoom { get; set; } = 100;
        public int FilasInmovilizadas { get; set; } = 2;
        public int ColumnasInmovilizadas { get; set; }
        public string OrientacionPagina { get; set; } = "Vertical";
        public string TamanoPapel { get; set; } = "A4";
        public string AreaImpresion { get; set; } = "";
        public bool ImprimirLineasDivision { get; set; }
        public bool ImprimirEncabezados { get; set; }
        public Dictionary<int, int> AnchosColumnas { get; set; } = new();
        public Dictionary<int, int> AltosFilas { get; set; } = new();
        public List<int> FilasOcultas { get; set; } = new();
        public decimal MargenIzquierdo { get; set; } = 0.5m;
        public decimal MargenDerecho { get; set; } = 0.5m;
        public decimal MargenSuperior { get; set; } = 0.5m;
        public decimal MargenInferior { get; set; } = 0.5m;
        public bool RepetirTitulos { get; set; }
        public bool AjustarImpresionAUnaPaginaAncho { get; set; }
        public Dictionary<string, MYGCeldaHoja> Celdas { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public List<MYGReferenciaMetradoPartida> ReferenciasPartidas { get; set; } = new();
        public List<MYGAnclaMetrado> AnclasReferencias { get; set; } = new();
        [JsonIgnore] internal MYGContextoReferenciasMetrado ContextoReferencias { get; set; }
        [JsonIgnore] internal string PresupuestoReferenciasId { get; set; }
        [JsonIgnore] internal string PartidaReferenciasId { get; set; }
        [JsonIgnore] internal bool EsCopiaReferencias { get; set; }
        public void Poner(string direccion, string contenido, bool negrita = false) =>
            Celdas[MYGHojaCalculo.Normalizar(direccion)] = new MYGCeldaHoja { Contenido = contenido ?? "", Negrita = negrita, FormatoNumero = FormatoNumeroPredeterminado,
                AlineacionHorizontal = MYGHojaCalculo.Coordenadas(direccion).Columna == 1 ? "Izquierda" : "Centro" };
        public static MYGHojaMetrado Crear()
        {
            var h = new MYGHojaMetrado { IdPlantilla = MYGPlantillasMetrado.Estandar, FormatoNumeroPredeterminado = "0.00",
                RellenoCabeceraEstandarAplicado = true, RangoCuerpoPlantilla = "A3:H15" };
            h.RangosCombinados.AddRange(new[] { "A1:C1", "D1:F1", "G1:H1" });
            h.AnchosColumnas = new() { [1] = 288, [2] = 58, [3] = 62, [4] = 68, [5] = 68, [6] = 68, [7] = 95, [8] = 110 };
            h.AltosFilas = new() { [1] = 20, [2] = 28 };
            h.Poner("A1", "Datos", true); h.Poner("D1", "Dimensiones", true); h.Poner("G1", "Total", true);
            string[] titulos = { "Descripción", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Parcial", "Plano / Referencia" };
            for (int c = 0; c < titulos.Length; c++) h.Poner(MYGHojaCalculo.Columna(c + 1) + "2", titulos[c], true);
            for (int f = 3; f <= 15; f++)
            {
                h.Poner("G" + f, $"=PRODUCT(B{f}:F{f})*IF(COUNT(B{f}:F{f})=0,0,1)");
                h.Celdas["G" + f].FormatoNumero = "0.00;-0.00;-";
            }
            h.Poner("A16", "Total:", true); h.Poner("G16", "=SUM(G3:G15)", true);
            foreach (string dir in MYGEdicionHoja.Direcciones(h, "A1:H2"))
            {
                var celda = MYGEdicionHoja.Celda(h, dir);
                celda.ColorFondo = "EFF9FC";
                celda.AlineacionHorizontal = dir == "A2" ? "Izquierda" : "Centro";
            }
            h.Celdas["A16"].AlineacionHorizontal = "Derecha";
            h.Celdas["G16"].FormatoNumero = "0.00";
            return h;
        }
    }
    // Motor numérico para metrados, sin dependencias de Excel ni ejecución de código.
    // No usa el resultado en caché de Excel como sustituto de una fórmula no soportada.
    public sealed class MYGHojaCalculo
    {
        private readonly MYGHojaMetrado hoja;
        private readonly MYGSesionHojaCalculo sesion;
        public MYGHojaCalculo(MYGHojaMetrado hoja)
        { this.hoja = hoja ?? throw new ArgumentNullException(nameof(hoja)); sesion = new(hoja.ContextoReferencias); }
        public static string Columna(int n)
        { string r = ""; for (; n > 0; n = (n - 1) / 26) r = (char)('A' + (n - 1) % 26) + r; return r; }
        public static string Normalizar(string direccion) => (direccion ?? "").Replace("$", "").Trim().ToUpperInvariant();
        // A rectangle is reported as a range only when every cell belongs to
        // the selection. Separate areas must not imply unselected cells.
        public static string ReferenciaSeleccion(IEnumerable<string> direcciones, string activa = null)
        {
            var celdas = (direcciones ?? Enumerable.Empty<string>()).Select(Coordenadas).Distinct()
                .OrderBy(p => p.Fila).ThenBy(p => p.Columna).ToArray();
            if (celdas.Length == 0)
            {
                if (string.IsNullOrWhiteSpace(activa)) return "";
                var p = Coordenadas(activa); return Columna(p.Columna) + p.Fila;
            }
            int f1 = celdas[0].Fila, f2 = celdas[^1].Fila, c1 = celdas.Min(p => p.Columna), c2 = celdas.Max(p => p.Columna);
            string Direccion(int f, int c) => Columna(c) + f.ToString(CultureInfo.InvariantCulture);
            if ((long)(f2 - f1 + 1) * (c2 - c1 + 1) == celdas.Length)
                return celdas.Length == 1 ? Direccion(f1, c1) : Direccion(f1, c1) + ":" + Direccion(f2, c2);
            var areas = new List<string>();
            foreach (var fila in celdas.GroupBy(p => p.Fila))
            {
                int primero = 0, ultimo = 0;
                void Agregar()
                { if (primero != 0) areas.Add(Direccion(fila.Key, primero) + (primero == ultimo ? "" : ":" + Direccion(fila.Key, ultimo))); }
                foreach (var p in fila)
                {
                    if (primero == 0) primero = ultimo = p.Columna;
                    else if (p.Columna == ultimo + 1) ultimo = p.Columna;
                    else { Agregar(); primero = ultimo = p.Columna; }
                }
                Agregar();
            }
            return string.Join(",", areas);
        }
        public static (int Fila, int Columna) Coordenadas(string direccion)
        {
            var m = Regex.Match(Normalizar(direccion), @"^([A-Z]{1,3})([1-9][0-9]{0,6})$");
            if (!m.Success) throw new FormatException("Referencia de celda no válida: " + direccion);
            int c = 0; foreach (char letra in m.Groups[1].Value) c = c * 26 + letra - 'A' + 1;
            return (int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture), c);
        }
        public static bool IntentarNumero(string texto, out decimal numero)
        {
            texto = (texto ?? "").Trim();
            if (decimal.TryParse(texto, NumberStyles.Float, CultureInfo.InvariantCulture, out numero)) return true;
            return !texto.Contains('.') && decimal.TryParse(texto.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out numero);
        }
        public static void Validar(MYGHojaMetrado h) => Validar(h, false);
        /// <summary>Valida un informe para XLSX sin ampliar los límites del editor.
        /// El límite de memoria se aplica a las celdas presentes, no al rectángulo vacío.</summary>
        public static void ValidarParaExportacion(MYGHojaMetrado h) => Validar(h, true);
        private static void Validar(MYGHojaMetrado h, bool paraExportacion)
        {
            ArgumentNullException.ThrowIfNull(h);
            int filas = paraExportacion ? MYGLimitesExportacionExcel.Filas : 10000;
            int columnas = paraExportacion ? MYGLimitesExportacionExcel.Columnas : 200;
            int celdas = paraExportacion ? MYGLimitesExportacionExcel.Celdas : 200000;
            if (h.Filas < 1 || h.Filas > filas || h.Columnas < 1 || h.Columnas > columnas ||
                !paraExportacion && (long)h.Filas * h.Columnas > celdas)
                throw new InvalidDataException(paraExportacion
                    ? "El informe supera las dimensiones de XLSX: 1.048.576 filas o 16.384 columnas."
                    : "La hoja admite hasta 200.000 celdas, 10.000 filas y 200 columnas.");
            h.Celdas ??= new();
            if (h.Celdas.Count > celdas) throw new InvalidDataException(paraExportacion
                ? "El informe supera los 2.000.000 de celdas almacenadas admitidas para exportar."
                : "La hoja es demasiado grande.");
            var normalizadas = new Dictionary<string, MYGCeldaHoja>(h.Celdas.Count, StringComparer.OrdinalIgnoreCase);
            foreach (var celda in h.Celdas)
                if (!normalizadas.TryAdd(Normalizar(celda.Key), celda.Value))
                    throw new InvalidDataException("La hoja contiene direcciones de celda duplicadas.");
            h.Celdas = normalizadas;
            foreach (var celda in h.Celdas)
            {
                var p = Coordenadas(celda.Key);
                if (p.Fila > h.Filas || p.Columna > h.Columnas || celda.Value == null || (celda.Value.Contenido?.Length ?? 0) > 32767)
                    throw new InvalidDataException("Celda fuera de la hoja o con contenido no válido.");
                MYGEdicionHoja.ValidarFormato(celda.Value);
            }
            if (h.ContenidoInicialPlantilla != null)
            {
                if (h.ContenidoInicialPlantilla.Count > celdas)
                    throw new InvalidDataException("El contenido inicial de la plantilla es demasiado grande.");
                foreach (var celda in h.ContenidoInicialPlantilla)
                {
                    var p = Coordenadas(celda.Key);
                    // El original no se desplaza al editar la estructura: puede
                    // conservar posiciones que ya no existen en la hoja actual.
                    if (p.Fila > filas || p.Columna > columnas || celda.Value == null || celda.Value.Length > 32767)
                        throw new InvalidDataException("Contenido inicial de plantilla no válido.");
                }
            }
            var total = Coordenadas(h.CeldaTotal);
            if (total.Fila > h.Filas || total.Columna > h.Columnas) throw new InvalidDataException("La celda total está fuera de la hoja.");
            MYGEdicionHoja.ValidarConfiguracion(h, paraExportacion);
            MYGReferenciasMetrado.Validar(h);
        }
        public string Contenido(string direccion) => hoja.Celdas.TryGetValue(Normalizar(direccion), out var c) ? c.Contenido ?? "" : "";
        public string Mostrar(string direccion)
        {
            string t = Contenido(direccion);
            if (!t.StartsWith('=') && !IntentarNumero(t, out _)) return t;
            try
            {
                var valor = Resultado(direccion);
                if (valor.EsTexto || valor.EsLogico) return valor.Texto;
                string formato = hoja.Celdas.TryGetValue(Normalizar(direccion), out var c) ? c.FormatoNumero : "General";
                return valor.Numero().ToString(string.IsNullOrEmpty(formato) || formato == "General" ? "0.####" : formato, CultureInfo.CurrentCulture);
            }
            catch (MYGErrorReferenciaMetrado) { return "#REF!"; }
            catch (Exception ex) when (ex is FormatException || ex is InvalidDataException || ex is DivideByZeroException || ex is OverflowException)
            { return "#ERROR"; }
        }
        public decimal Numero(string direccion) => Resultado(direccion).Numero();
        /// <summary>Comprueba la fórmula sin exigir que una descripción o un resultado lógico sean números.</summary>
        public void ValidarResultado(string direccion) => Resultado(direccion).SinError();
        internal MYGValorExcel Resultado(string direccion) => sesion.Resultado(hoja, direccion);
    }

    public static partial class MYGExcelPresupuestos
    {
        private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly XNamespace Rel = "http://schemas.openxmlformats.org/package/2006/relationships";
        private static readonly XNamespace Ct = "http://schemas.openxmlformats.org/package/2006/content-types";
        private static XDocument Leer(ZipArchive z, string nombre)
        {
            var e = z.GetEntry(nombre) ?? throw new InvalidDataException("Falta la parte Excel: " + nombre);
            if (e.Length > 32 * 1024 * 1024) throw new InvalidDataException("Parte Excel demasiado grande.");
            using var flujo = e.Open(); using var lector = XmlReader.Create(flujo, new XmlReaderSettings
            { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 32 * 1024 * 1024 });
            return XDocument.Load(lector);
        }
        public static string[] Hojas(string ruta)
        { using var z = ZipFile.OpenRead(ruta); return Leer(z, "xl/workbook.xml").Descendants(S + "sheet").Select(x => (string)x.Attribute("name")).ToArray(); }
        public static MYGHojaMetrado Importar(string ruta, string nombre, string celdaTotal)
        {
            using var z = ZipFile.OpenRead(ruta);
            if (z.Entries.Sum(x => x.Length) > 64 * 1024 * 1024) throw new InvalidDataException("Libro Excel demasiado grande.");
            var libro = Leer(z, "xl/workbook.xml");
            var hoja = libro.Descendants(S + "sheet").FirstOrDefault(x => (string)x.Attribute("name") == nombre)
                ?? throw new InvalidDataException("No se encontró la hoja seleccionada.");
            string id = (string)hoja.Attribute(R + "id");
            var relacion = Leer(z, "xl/_rels/workbook.xml.rels").Descendants(Rel + "Relationship").First(x => (string)x.Attribute("Id") == id);
            if ((string)relacion.Attribute("TargetMode") == "External") throw new InvalidDataException("La hoja es un vínculo externo.");
            string parte = (string)relacion.Attribute("Target");
            parte = parte.StartsWith('/') ? parte.TrimStart('/') : "xl/" + parte;
            if (parte.Contains("..") || !parte.StartsWith("xl/")) throw new InvalidDataException("Ruta de hoja no válida.");
            var compartidas = z.GetEntry("xl/sharedStrings.xml") == null ? Array.Empty<string>() : Leer(z, "xl/sharedStrings.xml")
                .Descendants(S + "si").Select(x => string.Concat(x.Descendants(S + "t").Select(t => t.Value))).ToArray();
            var h = new MYGHojaMetrado { Nombre = nombre, CeldaTotal = MYGHojaCalculo.Normalizar(celdaTotal), Filas = 100, Columnas = 12, Celdas = new() };
            var contenidoHoja = Leer(z, parte);
            var estilos = MYGFormatoExcelHoja.LeerEstilos(z.GetEntry("xl/styles.xml") == null ? null : Leer(z, "xl/styles.xml"));
            foreach (var c in contenidoHoja.Descendants(S + "c"))
            {
                string dir = MYGHojaCalculo.Normalizar((string)c.Attribute("r")); var pos = MYGHojaCalculo.Coordenadas(dir);
                if (pos.Fila > 10000 || pos.Columna > 200) throw new InvalidDataException("La hoja excede las dimensiones admitidas.");
                h.Filas = Math.Max(h.Filas, pos.Fila); h.Columnas = Math.Max(h.Columnas, pos.Columna);
                string tipo = (string)c.Attribute("t"), v = c.Element(S + "v")?.Value ?? ""; var f = c.Element(S + "f");
                if (f != null && (string)f.Attribute("t") is "shared" or "array" or "dataTable")
                    throw new InvalidDataException("La hoja contiene fórmulas compartidas, matriciales o tablas de datos. Guarde una copia con fórmulas simples para importarla.");
                string t = f != null ? "=" + f.Value : tipo == "inlineStr" ? string.Concat(c.Descendants(S + "t").Select(x => x.Value)) :
                    tipo == "s" ? compartidas[int.Parse(v, CultureInfo.InvariantCulture)] : v;
                h.Poner(dir, t);
                if (int.TryParse((string)c.Attribute("s"), NumberStyles.Integer, CultureInfo.InvariantCulture, out int estilo))
                {
                    if (estilo < 0 || estilo >= estilos.Count) throw new InvalidDataException("Índice de formato de celda no válido.");
                    MYGFormatoExcelHoja.AplicarEstilo(h.Celdas[dir], estilos[estilo]);
                }
            }
            MYGFormatoExcelHoja.LeerConfiguracion(h, contenidoHoja);
            int indiceHoja = libro.Descendants(S + "sheet").TakeWhile(x => x != hoja).Count();
            foreach (var definida in libro.Descendants(S + "definedName").Where(x => (string)x.Attribute("localSheetId") == indiceHoja.ToString(CultureInfo.InvariantCulture)))
            {
                if ((string)definida.Attribute("name") == "_xlnm.Print_Area")
                {
                    string area = definida.Value; int separador = area.LastIndexOf('!');
                    if (separador >= 0) area = area[(separador + 1)..];
                    h.AreaImpresion = MYGEdicionHoja.NormalizarRango(area);
                    foreach (string dir in h.AreaImpresion.Split(':')) { var pos = MYGHojaCalculo.Coordenadas(dir); h.Filas = Math.Max(h.Filas, pos.Fila); h.Columnas = Math.Max(h.Columnas, pos.Columna); }
                }
                if ((string)definida.Attribute("name") == "_xlnm.Print_Titles")
                {
                    string titulos = definida.Value[(definida.Value.LastIndexOf('!') + 1)..].Replace("$", "");
                    var extremos = titulos.Split(':');
                    if (extremos.Length != 2 || extremos[0] != "1" ||
                        !int.TryParse(extremos[1], NumberStyles.None, CultureInfo.InvariantCulture, out int ultimaFila) ||
                        ultimaFila < 1 || ultimaFila > 10000)
                        throw new InvalidDataException("El editor admite repetir un bloque de filas desde la primera fila como títulos de impresión.");
                    h.Filas = Math.Max(h.Filas, ultimaFila);
                    h.FilasInmovilizadas = Math.Max(h.FilasInmovilizadas, ultimaFila);
                    h.RepetirTitulos = true;
                }
            }
            var total = MYGHojaCalculo.Coordenadas(h.CeldaTotal); h.Filas = Math.Max(h.Filas, total.Fila); h.Columnas = Math.Max(h.Columnas, total.Columna);
            MYGHojaCalculo.Validar(h); return h;
        }
        public static void Guardar(string ruta, IReadOnlyList<MYGHojaMetrado> hojas) => GuardarLibro(ruta, hojas, false);
        /// <summary>Escribe un informe XLSX amplio sin convertirlo en una hoja editable.</summary>
        public static void GuardarParaExportacion(string ruta, IReadOnlyList<MYGHojaMetrado> hojas) => GuardarLibro(ruta, hojas, true);
        private static void GuardarLibro(string ruta, IReadOnlyList<MYGHojaMetrado> hojas, bool paraExportacion)
        {
            ArgumentNullException.ThrowIfNull(hojas);
            if (paraExportacion && !string.Equals(Path.GetExtension(ruta), ".xlsx", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Guarde el informe amplio como un libro XLSX con extensión .xlsx.");
            if (hojas.Count == 0) throw new InvalidOperationException("El libro no contiene hojas.");
            if (paraExportacion && hojas.Sum(h => (long)(h?.Celdas?.Count ?? 0)) > MYGLimitesExportacionExcel.Celdas)
                throw new InvalidDataException("El libro supera los 2.000.000 de celdas almacenadas admitidas para exportar.");
            foreach (var h in hojas)
                if (paraExportacion) MYGHojaCalculo.ValidarParaExportacion(h); else MYGHojaCalculo.Validar(h);
            // Se fijan todos los nombres antes de escribir las fórmulas: un origen
            // puede aparecer después del destino o compartir su nombre inicial.
            var referenciasExcel = new MYGExportacionReferenciasExcel(hojas);
            string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var z = new ZipArchive(File.Create(temporal), ZipArchiveMode.Create))
                {
                    void Escribir(string nombre, XElement raiz) { using var salida = z.CreateEntry(nombre).Open(); new XDocument(raiz).Save(salida); }
                    var tipos = new XElement(Ct + "Types",
                        new XElement(Ct + "Default", new XAttribute("Extension", "rels"), new XAttribute("ContentType", "application/vnd.openxmlformats-package.relationships+xml")),
                        new XElement(Ct + "Default", new XAttribute("Extension", "xml"), new XAttribute("ContentType", "application/xml")),
                        new XElement(Ct + "Override", new XAttribute("PartName", "/xl/workbook.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")),
                        new XElement(Ct + "Override", new XAttribute("PartName", "/xl/styles.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")));
                    var relacion = new XElement(Rel + "Relationships"); var lista = new XElement(S + "sheets"); var definidas = new XElement(S + "definedNames");
                    var estilos = MYGFormatoExcelHoja.CrearEstilos(hojas);
                    for (int n = 0; n < hojas.Count; n++)
                    {
                        var h = hojas[n]; string nombre = referenciasExcel.Nombres[n];
                        string id = "rId" + (n + 1), parte = "worksheets/sheet" + (n + 1) + ".xml";
                        lista.Add(new XElement(S + "sheet", new XAttribute("name", nombre), new XAttribute("sheetId", n + 1), new XAttribute(R + "id", id)));
                        relacion.Add(new XElement(Rel + "Relationship", new XAttribute("Id", id), new XAttribute("Type", R.NamespaceName + "/worksheet"), new XAttribute("Target", parte)));
                        tipos.Add(new XElement(Ct + "Override", new XAttribute("PartName", "/xl/" + parte), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")));
                        string ReferenciaImpresion(string rango) => "'" + nombre.Replace("'", "''") + "'!" + string.Join(":", rango.Split(':').Select(d => { var p = MYGHojaCalculo.Coordenadas(d); return "$" + MYGHojaCalculo.Columna(p.Columna) + "$" + p.Fila; }));
                        if (!string.IsNullOrWhiteSpace(h.AreaImpresion)) definidas.Add(new XElement(S + "definedName", new XAttribute("name", "_xlnm.Print_Area"), new XAttribute("localSheetId", n), ReferenciaImpresion(h.AreaImpresion)));
                        if (h.RepetirTitulos) definidas.Add(new XElement(S + "definedName", new XAttribute("name", "_xlnm.Print_Titles"), new XAttribute("localSheetId", n), "'" + nombre.Replace("'", "''") + "'!$1:$" + Math.Clamp(h.FilasInmovilizadas, 1, h.Filas).ToString(CultureInfo.InvariantCulture)));
                        EscribirHoja(z.CreateEntry("xl/" + parte), h, estilos.Indices, referenciasExcel);
                    }
                    Escribir("[Content_Types].xml", tipos);
                    Escribir("_rels/.rels", new XElement(Rel + "Relationships", new XElement(Rel + "Relationship", new XAttribute("Id", "rId1"), new XAttribute("Type", R.NamespaceName + "/officeDocument"), new XAttribute("Target", "xl/workbook.xml"))));
                    Escribir("xl/workbook.xml", new XElement(S + "workbook", new XAttribute(XNamespace.Xmlns + "r", R), lista, definidas.HasElements ? definidas : null,
                        new XElement(S + "calcPr", new XAttribute("calcId", 0), new XAttribute("calcMode", "auto"), new XAttribute("fullCalcOnLoad", 1))));
                    relacion.Add(new XElement(Rel + "Relationship", new XAttribute("Id", "rIdStyles"), new XAttribute("Type", R.NamespaceName + "/styles"), new XAttribute("Target", "styles.xml")));
                    Escribir("xl/_rels/workbook.xml.rels", relacion);
                    Escribir("xl/styles.xml", estilos.Estilos);
                }
                File.Move(temporal, ruta, true);
            }
            finally { if (File.Exists(temporal)) File.Delete(temporal); }
        }
        public static MYGHojaMetrado Tabla(string nombre, string[] titulos, IEnumerable<object[]> filas)
        {
            var datos = filas.ToList(); var h = new MYGHojaMetrado { Nombre = nombre, Filas = Math.Max(2, datos.Count + 2), Columnas = Math.Max(1, titulos.Length), CeldaTotal = "A1", Celdas = new() };
            for (int c = 0; c < titulos.Length; c++)
            {
                string direccion = MYGHojaCalculo.Columna(c + 1) + "1";
                h.Poner(direccion, titulos[c], true); h.Celdas[direccion].ColorFondo = "D5E2F2";
            }
            for (int f = 0; f < datos.Count; f++) for (int c = 0; c < datos[f].Length; c++)
                h.Poner(MYGHojaCalculo.Columna(c + 1) + (f + 2), Convert.ToString(datos[f][c], CultureInfo.InvariantCulture));
            // Generated budget reports keep their previous layout; measurement
            // defaults apply to the interactive measurement sheet.
            foreach (var celda in h.Celdas.Values)
            { celda.AlineacionHorizontal = "Izquierda"; celda.AlineacionPersonalizada = true; }
            return h;
        }
    }
}
