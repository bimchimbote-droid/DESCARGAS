using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly Dictionary<Control, MYGEspecificacionesRueda> ruedasHoja = new();
    private int ruedaPendienteHoja;

    private void PrepararZoomRuedaHoja()
    {
        AsociarRuedaHoja(hoja);
        AsociarRuedaHoja(formula);
        hoja.EditingControlShowing += (_, e) => AsociarRuedaHoja(e.Control);
        Disposed += (_, _) =>
        {
            foreach (var rueda in ruedasHoja.Values) rueda.Dispose();
            ruedasHoja.Clear();
        };
    }
    private void AsociarRuedaHoja(Control control)
    {
        if (control == null || ruedasHoja.ContainsKey(control)) return;
        ruedasHoja.Add(control, new MYGEspecificacionesRueda(control, ZoomRuedaHoja));
    }

    // Intercept WM_MOUSEWHEEL before DataGridView/its edit control scrolls.
    // Layout changes never call EndEdit or replace the draft formula.
    private bool ZoomRuedaHoja(int delta, bool control, Point puntoPantalla)
    {
        if (!control) { ruedaPendienteHoja = 0; return false; }
        if (!HayPartida || !hoja.Visible || delta == 0 ||
            !(hoja.RectangleToScreen(hoja.ClientRectangle).Contains(puntoPantalla) ||
                formula.Visible && formula.RectangleToScreen(formula.ClientRectangle).Contains(puntoPantalla))) return false;
        ruedaPendienteHoja += delta;
        int pasos = ruedaPendienteHoja / 120;
        ruedaPendienteHoja %= 120;
        if (pasos == 0) return true;
        var h = actual.Costos.Hoja;
        int nuevo = Math.Clamp(h.Zoom + pasos * 10, 25, 300);
        if (nuevo == h.Zoom) return true;
        var editor = hoja.EditingControl as TextBoxBase;
        string texto = editor?.Text;
        int inicio = editor?.SelectionStart ?? 0, longitud = editor?.SelectionLength ?? 0;
        int primeraFila = hoja.FirstDisplayedScrollingRowIndex, desplazamiento = hoja.HorizontalScrollingOffset;
        antes();
        bool previo = cargando; cargando = true;
        try
        {
            h.Zoom = nuevo;
            AplicarVistaHoja(true);
            foreach (DataGridViewRow fila in hoja.Rows)
                foreach (DataGridViewCell celda in fila.Cells)
                    AplicarFormatoCeldaHoja(celda, h.Celdas.GetValueOrDefault(DireccionCelda(fila.Index, celda.ColumnIndex)));
            if (primeraFila >= 0 && primeraFila < hoja.RowCount && hoja.Rows[primeraFila].Visible && !hoja.Rows[primeraFila].Frozen)
                hoja.FirstDisplayedScrollingRowIndex = primeraFila;
            int ancho = hoja.Columns.Cast<DataGridViewColumn>().Where(c => c.Visible).Sum(c => c.Width);
            int visible = Math.Max(0, hoja.ClientSize.Width - (hoja.RowHeadersVisible ? hoja.RowHeadersWidth : 0) - SystemInformation.VerticalScrollBarWidth);
            hoja.HorizontalScrollingOffset = Math.Min(desplazamiento, Math.Max(0, ancho - visible));
            if (editor != null && !editor.IsDisposed && hoja.IsCurrentCellInEditMode)
            {
                var ancla = MYGHojaCalculo.Coordenadas(DireccionAnclaHoja(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex));
                editor.Font = hoja[ancla.Columna - 1, ancla.Fila - 1].InheritedStyle.Font;
                // Reapplying the style must not discard a native editor's draft.
                if (editor.Text != texto) editor.Text = texto;
                editor.Select(Math.Min(inicio, editor.TextLength), Math.Min(longitud, Math.Max(0, editor.TextLength - inicio)));
            }
        }
        finally { cargando = previo; }
        var celdaActiva = hoja.CurrentCell;
        string direccionActiva = celdaActiva == null ? null : DireccionAnclaHoja(celdaActiva.RowIndex, celdaActiva.ColumnIndex);
        var estilo = direccionActiva == null ? null : MYGEdicionHoja.CopiarCelda(h.Celdas.GetValueOrDefault(direccionActiva));
        if (estilo != null) estilo.AlineacionHorizontal = MYGEdicionHoja.AlineacionCelda(h.Celdas.GetValueOrDefault(direccionActiva), direccionActiva);
        SincronizarCintaHoja(h, estilo);
        hoja.Invalidate();
        despues();
        return true;
    }
}
