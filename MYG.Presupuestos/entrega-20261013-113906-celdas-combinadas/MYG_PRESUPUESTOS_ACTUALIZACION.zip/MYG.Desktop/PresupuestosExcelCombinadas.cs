using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private (int f1, int c1, int f2, int c2)? CombinacionCeldaHoja(int fila, int columna)
    {
        if (!HayPartida) return null;
        foreach (string combinacion in actual.Costos.Hoja.RangosCombinados)
        {
            var r = RangoHoja(combinacion);
            if (fila >= r.f1 && fila <= r.f2 && columna >= r.c1 && columna <= r.c2) return r;
        }
        return null;
    }

    private string DireccionAnclaHoja(int fila, int columna)
    {
        var r = CombinacionCeldaHoja(fila, columna);
        return r is { } combinacion ? DireccionCelda(combinacion.f1, combinacion.c1) : DireccionCelda(fila, columna);
    }

    private bool EstaEditandoCombinacionHoja(int fila, int columna)
    {
        if (!hoja.IsCurrentCellInEditMode || hoja.CurrentCell == null) return false;
        return DireccionAnclaHoja(fila, columna) ==
            DireccionAnclaHoja(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex);
    }

    private (Rectangle Limites, DataGridViewCellStyle Estilo)? ConfiguracionEdicionCombinadaHoja(int fila, int columna)
    {
        var r = CombinacionCeldaHoja(fila, columna);
        if (r is not { } combinacion) return null;
        var union = LimitesCombinacionHoja(combinacion);
        if (union == null) return null;
        return (union.Value, hoja[combinacion.c1, combinacion.f1].InheritedStyle);
    }

    private Rectangle? LimitesCombinacionHoja((int f1, int c1, int f2, int c2) r)
    {
        while (r.f1 <= r.f2 && !hoja.Rows[r.f1].Visible) r.f1++;
        while (r.f2 >= r.f1 && !hoja.Rows[r.f2].Visible) r.f2--;
        while (r.c1 <= r.c2 && !hoja.Columns[r.c1].Visible) r.c1++;
        while (r.c2 >= r.c1 && !hoja.Columns[r.c2].Visible) r.c2--;
        if (r.f1 > r.f2 || r.c1 > r.c2) return null;
        Rectangle inicio = hoja.GetCellDisplayRectangle(r.c1, r.f1, false);
        Rectangle fin = hoja.GetCellDisplayRectangle(r.c2, r.f2, false);
        return Rectangle.FromLTRB(Math.Min(inicio.Left, fin.Left), inicio.Top,
            Math.Max(inicio.Right, fin.Right), fin.Bottom);
    }
}

// Mantiene el ciclo nativo de edición, validación, Escape y confirmación de la
// cuadrícula. Sólo amplía su editor al rectángulo completo de la combinación.
internal sealed class MYGCeldaMetradoCombinada : DataGridViewTextBoxCell
{
    public MYGCeldaMetradoCombinada() { }

    internal Func<int, int, (Rectangle Limites, DataGridViewCellStyle Estilo)?> ConfigurarEdicion { get; set; }

    public override object Clone()
    {
        var copia = (MYGCeldaMetradoCombinada)base.Clone();
        copia.ConfigurarEdicion = ConfigurarEdicion;
        return copia;
    }

    public override void InitializeEditingControl(int rowIndex, object initialFormattedValue, DataGridViewCellStyle dataGridViewCellStyle)
    {
        var configuracion = ConfigurarEdicion?.Invoke(rowIndex, ColumnIndex);
        base.InitializeEditingControl(rowIndex, initialFormattedValue, configuracion?.Estilo ?? dataGridViewCellStyle);
    }

    public override void PositionEditingControl(bool setLocation, bool setSize, Rectangle cellBounds, Rectangle cellClip,
        DataGridViewCellStyle cellStyle, bool singleVerticalBorderAdded, bool singleHorizontalBorderAdded,
        bool isFirstDisplayedColumn, bool isFirstDisplayedRow)
    {
        var configuracion = ConfigurarEdicion?.Invoke(RowIndex, ColumnIndex);
        if (configuracion is { } combinada)
        {
            cellBounds = combinada.Limites;
            var visible = DataGridView.ClientRectangle;
            if (DataGridView.RowHeadersVisible)
            {
                int ancho = DataGridView.RowHeadersWidth;
                if (DataGridView.RightToLeft == RightToLeft.Yes) visible.Width -= ancho;
                else { visible.X += ancho; visible.Width -= ancho; }
            }
            if (DataGridView.ColumnHeadersVisible)
            { visible.Y += DataGridView.ColumnHeadersHeight; visible.Height -= DataGridView.ColumnHeadersHeight; }
            foreach (Control control in DataGridView.Controls)
                if (control is ScrollBar && control.Visible)
                {
                    if (control is VScrollBar)
                    {
                        if (DataGridView.RightToLeft == RightToLeft.Yes) visible.X += control.Width;
                        visible.Width -= control.Width;
                    }
                    else visible.Height -= control.Height;
                }
            cellClip = Rectangle.Intersect(cellBounds, visible);
            cellStyle = combinada.Estilo;
        }
        base.PositionEditingControl(setLocation, setSize, cellBounds, cellClip, cellStyle,
            singleVerticalBorderAdded, singleHorizontalBorderAdded, isFirstDisplayedColumn, isFirstDisplayedRow);
    }
}
