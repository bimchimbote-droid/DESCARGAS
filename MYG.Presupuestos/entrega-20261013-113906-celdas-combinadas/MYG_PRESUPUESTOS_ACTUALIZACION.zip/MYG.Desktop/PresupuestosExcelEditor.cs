using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private TabPage paginaExcel;
    private MYGMetradoCabecera cabeceraExcel;
    private TabControl pestanasHoja;
    private bool mostrarFormulasHoja, actualizandoFormulaHoja, formulaPendienteHoja;
    private string direccionFormulaHoja;
    private readonly Dictionary<string, Font> fuentesHoja = new();
    private string filtroTextoHoja = "";
    private static string DireccionCelda(int fila, int columna) => MYGHojaCalculo.Columna(columna + 1) + (fila + 1);

    private Control PrepararPestanasHoja()
    {
        pestanasHoja = new() { Name = "metrado_hojas", Dock = DockStyle.Bottom, Height = 27 };
        pestanasHoja.TabPages.Add(new TabPage("Metrado"));
        MYGTemaPestanas.Preparar(pestanasHoja);
        return pestanasHoja;
    }
    private Control PrepararBarraFormulaHoja()
    {
        var barra = new TableLayoutPanel { Name = "metrado_barra_formula", Dock = DockStyle.Top, Height = 32, ColumnCount = 5, Padding = new(2) };
        barra.ColumnStyles.Add(new(SizeType.Absolute, 100));
        barra.ColumnStyles.Add(new(SizeType.Absolute, 76));
        barra.ColumnStyles.Add(new(SizeType.Percent, 100));
        barra.ColumnStyles.Add(new(SizeType.Absolute, 65));
        barra.ColumnStyles.Add(new(SizeType.Absolute, 136));
        direccion.Name = "metrado_direccion"; direccion.ReadOnly = false; direccion.Dock = DockStyle.Fill;
        formula.Name = "metrado_formula"; formula.Dock = DockStyle.Fill;
        celdaTotal.Name = "metrado_total"; celdaTotal.Dock = DockStyle.Fill;
        var confirmar = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        foreach (var par in new[] { ("×", (Action)CancelarEdicionHoja), ("✓", (Action)AplicarFormula) })
        {
            var boton = new Button { Text = par.Item1, Width = 24, Height = 25, Margin = new(0), FlatStyle = FlatStyle.Flat, CausesValidation = par.Item1 != "×" };
            boton.Click += (_, _) => Intentar(par.Item2); confirmar.Controls.Add(boton);
        }
        confirmar.Controls.Add(new Label { Text = "fx", AutoSize = true, Margin = new(3, 4, 0, 0) });
        var usar = new Button { Text = "Usar total Excel", Dock = DockStyle.Fill, Margin = new(2, 0, 0, 0) };
        usar.Click += (_, _) => Intentar(UsarTotalHoja);
        barra.Controls.Add(direccion, 0, 0); barra.Controls.Add(confirmar, 1, 0); barra.Controls.Add(formula, 2, 0);
        barra.Controls.Add(celdaTotal, 3, 0); barra.Controls.Add(usar, 4, 0);
        formula.TextChanged += (_, _) => { if (!actualizandoFormulaHoja && !cargando) formulaPendienteHoja = true; };
        formula.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Intentar(AplicarFormula); hoja.Focus(); }
            if (e.KeyCode == Keys.Escape) { e.SuppressKeyPress = true; formulaPendienteHoja = false; ActualizarFormula(); hoja.Focus(); }
        };
        direccion.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Intentar(IrDireccionHoja); } };
        return barra;
    }
    private void ConfirmarFormulaHoja()
    {
        if (!cargando && formulaPendienteHoja && HayPartida && direccionFormulaHoja != null) AplicarFormula();
    }
    private void CancelarEdicionHoja()
    {
        formulaPendienteHoja = false;
        LimpiarReferenciasHoja();
        hoja.CancelEdit();
        if (hoja.IsCurrentCellInEditMode) hoja.EndEdit();
        ActualizarFormula();
    }
    private void IrDireccionHoja()
    {
        RequerirPartida(); FinalizarEdicion();
        var rangos = direccion.Text.Split(',', StringSplitOptions.TrimEntries).Select(RangoHoja).ToArray();
        var activa = (Fila: -1, Columna: -1);
        foreach (var rango in rangos)
        {
            for (int f = rango.f1; f <= rango.f2 && activa.Fila < 0; f++)
                if (hoja.Rows[f].Visible) activa = (f, rango.c1);
            if (activa.Fila >= 0) break;
        }
        if (activa.Fila < 0) throw new InvalidOperationException("La selección sólo contiene filas ocultas. Muestre el detalle antes de navegar.");
        bool previo = cargando; cargando = true;
        try
        {
            hoja.ClearSelection();
            hoja.CurrentCell = hoja.Rows[activa.Fila].Cells[activa.Columna];
            foreach (var limites in rangos)
                for (int f = limites.f1; f <= limites.f2; f++) for (int c = limites.c1; c <= limites.c2; c++) hoja[c, f].Selected = true;
        }
        finally { cargando = previo; }
        ActualizarFormula();
        hoja.Focus();
    }
    private (int f1, int c1, int f2, int c2) RangoHoja(string rango = null)
    {
        if (rango == null)
        {
            var seleccion = hoja.SelectedCells.Cast<DataGridViewCell>().ToArray();
            if (seleccion.Length == 0) throw new InvalidOperationException("Seleccione una celda o un rango.");
            return (seleccion.Min(x => x.RowIndex), seleccion.Min(x => x.ColumnIndex), seleccion.Max(x => x.RowIndex), seleccion.Max(x => x.ColumnIndex));
        }
        var partes = rango.Trim().Split(':');
        if (partes.Length > 2) throw new FormatException("Indique una celda o un rango como A3:F15.");
        var a = MYGHojaCalculo.Coordenadas(partes[0]); var b = MYGHojaCalculo.Coordenadas(partes[^1]);
        var h = actual.Costos.Hoja;
        if (a.Fila > h.Filas || b.Fila > h.Filas || a.Columna > h.Columnas || b.Columna > h.Columnas)
            throw new InvalidOperationException("El rango está fuera de la hoja.");
        return (Math.Min(a.Fila, b.Fila) - 1, Math.Min(a.Columna, b.Columna) - 1, Math.Max(a.Fila, b.Fila) - 1, Math.Max(a.Columna, b.Columna) - 1);
    }
    private string RangoSeleccionHoja()
    {
        var r = RangoHoja(); return DireccionCelda(r.f1, r.c1) + ":" + DireccionCelda(r.f2, r.c2);
    }
    private void UsarTotalHoja()
    {
        RequerirPartida(); FinalizarEdicion();
        string dir = MYGHojaCalculo.Normalizar(celdaTotal.Text);
        RangoHoja(dir);
        var n = new MYGHojaCalculo(actual.Costos.Hoja).Numero(dir);
        if (n < 0) throw new InvalidOperationException("El total del metrado debe ser positivo o cero.");
        antes(); actual.Costos.Hoja.CeldaTotal = dir; actual.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        bool previo = cargando; cargando = true;
        try { fuente.SelectedItem = MYGFuenteMetrado.Excel; }
        finally { cargando = previo; }
        RecalcularHoja(); Cambiado();
    }
    private void EditarFormatoHoja(Action<MYGCeldaHoja> cambiar)
    {
        RequerirPartida(); FinalizarEdicion();
        var seleccion = hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => DireccionCelda(c.RowIndex, c.ColumnIndex)).ToArray();
        if (seleccion.Length == 0) return;
        var copia = MYGProyectoStorage.Copia(actual.Costos.Hoja);
        foreach (string direccion in seleccion) cambiar(MYGEdicionHoja.Celda(copia, direccion));
        MYGHojaCalculo.Validar(copia);
        antes(); actual.Costos.Hoja = copia;
        RecalcularHoja(); Cambiado();
    }
    private void EditarVistaHoja(Action<MYGHojaMetrado> cambiar)
    {
        RequerirPartida(); FinalizarEdicion(); antes(); cambiar(actual.Costos.Hoja); AplicarVistaHoja(); RecalcularHoja(); Cambiado();
    }
    private void EjecutarComandoHoja(string comando)
    {
        RequerirPartida(); FinalizarEdicion();
        var h = actual.Costos.Hoja;
        string valor = comando.Contains(':') ? comando[(comando.IndexOf(':') + 1)..] : "";
        string accion = comando.Split(':')[0];
        switch (accion)
        {
            case "guardar": guardarProyecto?.Invoke(); return;
            case "exportar": ExportarHoja(); return;
            case "importar": ImportarHoja(); return;
            case "volver": detalle.SelectedTab = paginaACU; return;
            case "deshacer": deshacerProyecto?.Invoke(); return;
            case "rehacer": rehacerProyecto?.Invoke(); return;
            case "copiar": CopiarHoja(); return;
            case "pegar": PegarHoja(); return;
            case "cortar": CopiarHoja(); EjecutarComandoHoja("limpiar"); return;
            case "limpiar":
                antes(); foreach (DataGridViewCell c in hoja.SelectedCells) PonerCelda(DireccionCelda(c.RowIndex, c.ColumnIndex), ""); RecalcularHoja(); Cambiado(); return;
            case "rellenar_abajo": RellenarHoja(); return;
            case "negrita": EditarFormatoHoja(c => c.Negrita = !c.Negrita); return;
            case "cursiva": EditarFormatoHoja(c => c.Cursiva = !c.Cursiva); return;
            case "subrayado": EditarFormatoHoja(c => c.Subrayado = !c.Subrayado); return;
            case "tachado": EditarFormatoHoja(c => c.Tachado = !c.Tachado); return;
            case "fuente": EditarFormatoHoja(c => c.Fuente = valor); return;
            case "tamano":
                if (!decimal.TryParse(valor, NumberStyles.Float, CultureInfo.InvariantCulture, out var puntos) || puntos < 6 || puntos > 72)
                    throw new InvalidOperationException("El tamaño de fuente debe estar entre 6 y 72.");
                EditarFormatoHoja(c => c.TamanoFuente = puntos); return;
            case "aumentar_fuente": EditarFormatoHoja(c => c.TamanoFuente = Math.Min(72, c.TamanoFuente + 1)); return;
            case "reducir_fuente": EditarFormatoHoja(c => c.TamanoFuente = Math.Max(6, c.TamanoFuente - 1)); return;
            case "alineacion": EditarFormatoHoja(c => { c.AlineacionHorizontal = valor switch { "centro" => "Centro", "derecha" => "Derecha", _ => "Izquierda" }; c.AlineacionPersonalizada = true; }); return;
            case "vertical": EditarFormatoHoja(c => c.AlineacionVertical = valor switch { "centro" => "Centro", "abajo" => "Abajo", _ => "Arriba" }); return;
            case "ajustar_texto": EditarFormatoHoja(c => c.AjustarTexto = !c.AjustarTexto); return;
            case "bordes": EditarFormatoHoja(c => c.Bordes = !c.Bordes); return;
            case "color_fuente": case "color_fondo":
                using (var d = new ColorDialog { FullOpen = true })
                    if (d.ShowDialog(this) == DialogResult.OK) EditarFormatoHoja(c =>
                    {
                        string color = $"#{d.Color.R:X2}{d.Color.G:X2}{d.Color.B:X2}";
                        if (accion == "color_fuente") c.ColorTexto = color; else c.ColorFondo = color;
                    });
                return;
            case "formato_numero": EditarFormatoHoja(c => c.FormatoNumero = valor); return;
            case "decimales_mas": case "decimales_menos":
                EditarFormatoHoja(c => { int n = c.FormatoNumero.Contains('.') ? c.FormatoNumero.Split('.')[1].TakeWhile(x => x == '0').Count() : 0; n = Math.Clamp(n + (accion == "decimales_mas" ? 1 : -1), 0, 8); c.FormatoNumero = n == 0 ? "0" : "0." + new string('0', n); }); return;
            case "borrar_formato":
                EditarFormatoHoja(c => { c.Negrita = c.Cursiva = c.Subrayado = c.Tachado = c.Bordes = c.AjustarTexto = false; c.Fuente = MYGCeldaHoja.FuentePredeterminada; c.TamanoFuente = 9; c.ColorTexto = c.ColorFondo = ""; c.AlineacionHorizontal = "Izquierda"; c.AlineacionPersonalizada = false; c.AlineacionVertical = "Centro"; c.FormatoNumero = "General"; }); return;
            case "insertar_filas": case "eliminar_filas": case "insertar_columnas": case "eliminar_columnas":
                var r = RangoHoja(); var copia = MYGProyectoStorage.Copia(h);
                if (accion == "insertar_filas") MYGEdicionHoja.InsertarFilas(copia, r.f1 + 1, r.f2 - r.f1 + 1);
                if (accion == "eliminar_filas") MYGEdicionHoja.EliminarFilas(copia, r.f1 + 1, r.f2 - r.f1 + 1);
                if (accion == "insertar_columnas") MYGEdicionHoja.InsertarColumnas(copia, r.c1 + 1, r.c2 - r.c1 + 1);
                if (accion == "eliminar_columnas") MYGEdicionHoja.EliminarColumnas(copia, r.c1 + 1, r.c2 - r.c1 + 1);
                antes(); actual.Costos.Hoja = copia; CargarHoja(); Cambiado(); return;
            case "ancho_columna": case "alto_fila":
                string dimension = PedirHoja("Formato de celda", "Tamaño en píxeles (a 100%)", accion == "ancho_columna" ? "90" : "18");
                if (dimension == null) return;
                if (!int.TryParse(dimension, out int medida) || medida < 14 || medida > 1000) throw new InvalidOperationException("Indique un tamaño entre 14 y 1.000 píxeles.");
                EditarVistaHoja(x => { foreach (DataGridViewCell c in hoja.SelectedCells) { if (accion == "ancho_columna") x.AnchosColumnas[c.ColumnIndex + 1] = medida; else x.AltosFilas[c.RowIndex + 1] = medida; } }); return;
            case "combinar":
                string rango = RangoSeleccionHoja();
                var combinar = MYGProyectoStorage.Copia(h);
                if (valor == "separar") MYGEdicionHoja.Separar(combinar, rango);
                else
                {
                    var contenidos = MYGEdicionHoja.ContenidosAlCombinar(h, rango);
                    if (contenidos.Count > 1)
                    {
                        var primero = contenidos[0];
                        using var aviso = new MYGConfirmarCombinacionForm(rango, primero.Direccion, primero.Contenido, contenidos.Count);
                        if (aviso.ShowDialog(this) != DialogResult.OK) return;
                    }
                    MYGEdicionHoja.Combinar(combinar, rango);
                }
                antes(); actual.Costos.Hoja = combinar; RecalcularHoja(); hoja.Invalidate(); Cambiado(); return;
            case "estilo": AplicarEstiloHoja(valor); return;
            case "dar_formato_tabla": EditarFormatoHoja(c => { c.Bordes = true; c.ColorFondo = "#EAF3F8"; }); return;
            case "mostrar_formulas": mostrarFormulasHoja = !mostrarFormulasHoja; RecalcularHoja(); return;
            case "autosuma": InsertarFuncionHoja("SUM", true); return;
            case "insertar_funcion": InsertarFuncionHoja(valor, false); return;
            case "recalcular": RecalcularHoja(); return;
            case "usar_total": UsarTotalHoja(); return;
            case "ordenar_asc": case "ordenar_desc":
                var ordenada = MYGProyectoStorage.Copia(h);
                MYGEdicionHoja.Ordenar(ordenada, RangoSeleccionHoja(), hoja.CurrentCell.ColumnIndex + 1, accion == "ordenar_desc");
                antes(); actual.Costos.Hoja = ordenada; RecalcularHoja(); Cambiado(); return;
            case "buscar": BuscarHoja(); return;
            case "reemplazar": ReemplazarHoja(); return;
            case "lineas_division": EditarVistaHoja(x => x.LineasDivision = !x.LineasDivision); return;
            case "encabezados": EditarVistaHoja(x => x.Encabezados = !x.Encabezados); return;
            case "zoom_mas": EditarVistaHoja(x => x.Zoom = Math.Min(300, x.Zoom + 10)); return;
            case "zoom_menos": EditarVistaHoja(x => x.Zoom = Math.Max(25, x.Zoom - 10)); return;
            case "zoom_100": EditarVistaHoja(x => x.Zoom = 100); return;
            case "zoom":
                string z = PedirHoja("Zoom", "Porcentaje (25 a 300)", h.Zoom.ToString());
                if (z == null) return;
                if (!int.TryParse(z, out int zoom) || zoom < 25 || zoom > 300) throw new InvalidOperationException("El zoom debe estar entre 25% y 300%.");
                EditarVistaHoja(x => x.Zoom = zoom); return;
            case "inmovilizar":
                EditarVistaHoja(x => { if (x.FilasInmovilizadas > 0 || x.ColumnasInmovilizadas > 0) x.FilasInmovilizadas = x.ColumnasInmovilizadas = 0; else { x.FilasInmovilizadas = hoja.CurrentCell?.RowIndex ?? 2; x.ColumnasInmovilizadas = hoja.CurrentCell?.ColumnIndex ?? 0; } }); return;
            case "inmovilizar_fila": EditarVistaHoja(x => x.FilasInmovilizadas = 1); return;
            case "inmovilizar_columna": EditarVistaHoja(x => x.ColumnasInmovilizadas = 1); return;
            case "movilizar": EditarVistaHoja(x => x.FilasInmovilizadas = x.ColumnasInmovilizadas = 0); return;
            case "orientacion": EditarVistaHoja(x => x.OrientacionPagina = valor == "horizontal" ? "Horizontal" : "Vertical"); return;
            case "tamano_papel": EditarVistaHoja(x => x.TamanoPapel = valor); return;
            case "area_impresion": EditarVistaHoja(x => x.AreaImpresion = valor == "borrar" ? "" : RangoSeleccionHoja()); return;
            case "imprimir_lineas_division": EditarVistaHoja(x => x.ImprimirLineasDivision = !x.ImprimirLineasDivision); return;
            case "imprimir_encabezados": EditarVistaHoja(x => x.ImprimirEncabezados = !x.ImprimirEncabezados); return;
            case "imprimir_titulos": EditarVistaHoja(x => x.RepetirTitulos = !x.RepetirTitulos); return;
            case "margenes": MargenesHoja(); return;
            case "imprimir": ImprimirHoja(false); return;
            case "impresion_rapida": ImprimirHoja(false, true); return;
            case "vista_previa": ImprimirHoja(true); return;
            case "filtro":
                filtroTextoHoja = PedirHoja("Filtro", "Mostrar filas que contienen (filas 3 hasta antes del total)", filtroTextoHoja) ?? filtroTextoHoja; FiltrarHoja(); return;
            case "borrar_filtro": filtroTextoHoja = ""; FiltrarHoja(); return;
            case "reaplicar_filtro": FiltrarHoja(); return;
            case "agrupar": case "ocultar_detalle":
                var filas = hoja.SelectedCells.Cast<DataGridViewCell>().Where(c => !hoja.Rows[c.RowIndex].Frozen).Select(c => c.RowIndex + 1).Distinct().ToArray();
                EditarVistaHoja(x => x.FilasOcultas = x.FilasOcultas.Union(filas).ToList()); return;
            case "desagrupar": case "mostrar_detalle": EditarVistaHoja(x => x.FilasOcultas.Clear()); return;
            case "subtotal": InsertarFuncionHoja("SUM", true); return;
            case "validacion": ValidacionHoja(); return;
            case "enlace": case "simbolo":
                string texto = PedirHoja(accion == "enlace" ? "Insertar hipervínculo" : "Insertar símbolo", accion == "enlace" ? "Dirección https://" : "Símbolo o texto", accion == "enlace" ? "https://" : "m²");
                if (texto == null) return;
                if (accion == "enlace" && (!Uri.TryCreate(texto, UriKind.Absolute, out var uri) || uri.Scheme != "https")) throw new InvalidOperationException("Indique un enlace HTTPS válido.");
                antes(); PonerCelda(DireccionCelda(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex), texto); RecalcularHoja(); Cambiado(); return;
            default: throw new InvalidOperationException("La operación no está disponible en esta hoja: " + accion);
        }
    }
    private string PedirHoja(string titulo, string etiqueta, string inicial)
    {
        using var f = new MYGCamposProyectoForm(titulo, new[] { etiqueta }, new[] { inicial });
        return f.ShowDialog(this) == DialogResult.OK ? f.Valores[0] : null;
    }
    private void InsertarFuncionHoja(string funcion, bool automatico)
    {
        var r = RangoHoja(); string celda = DireccionAnclaHoja(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex);
        string rango = RangoSeleccionHoja();
        if (r.f1 == r.f2 && r.c1 == r.c2 && r.f1 > 0) rango = DireccionCelda(0, r.c1) + ":" + DireccionCelda(r.f1 - 1, r.c1);
        else if (automatico && (r.f1 != r.f2 || r.c1 != r.c2))
        {
            int f = r.f1 == r.f2 ? r.f1 : r.f2 + 1, c = r.f1 == r.f2 ? r.c2 + 1 : r.c1;
            if (f >= hoja.RowCount || c >= hoja.ColumnCount) throw new InvalidOperationException("No hay una celda libre junto al rango para la suma.");
            celda = DireccionCelda(f, c);
            if (!string.IsNullOrEmpty(new MYGHojaCalculo(actual.Costos.Hoja).Contenido(celda)))
                throw new InvalidOperationException("La celda para la suma ya contiene datos: " + celda + ". Seleccione una celda vacía o inserte una fila.");
        }
        string expresion = "=" + funcion + "(" + rango + ")";
        if (!automatico) expresion = PedirHoja("Insertar función " + funcion, "Fórmula", funcion == "IF" ? "=IF(B3>0,B3,0)" : funcion == "ROUND" ? "=ROUND(B3,2)" : expresion);
        if (expresion == null) return;
        var copia = MYGProyectoStorage.Copia(actual.Costos.Hoja);
        MYGEdicionHoja.Celda(copia, celda).Contenido = expresion;
        new MYGHojaCalculo(copia).Numero(celda);
        antes(); PonerCelda(celda, expresion); RecalcularHoja(); Cambiado();
    }
    private void AplicarEstiloHoja(string estilo)
    {
        EditarFormatoHoja(c =>
        {
            c.ColorFondo = estilo switch { "buena" => "#C6EFCE", "incorrecto" => "#FFC7CE", "neutral" => "#FFEB9C", "comentario" => "#A5A5A5", _ => "" };
            c.ColorTexto = estilo switch { "buena" => "#006100", "incorrecto" => "#9C0006", "neutral" => "#9C6500", "calculo" => "#FF8000", "comentario" => "#FFFFFF", _ => "" };
            c.Negrita = estilo is "calculo" or "comentario";
        });
    }
    private void BuscarHoja()
    {
        string texto = PedirHoja("Buscar en la hoja", "Texto o fórmula", "");
        if (string.IsNullOrEmpty(texto)) return;
        int inicio = hoja.CurrentCell == null ? 0 : hoja.CurrentCell.RowIndex * hoja.ColumnCount + hoja.CurrentCell.ColumnIndex + 1;
        var motor = new MYGHojaCalculo(actual.Costos.Hoja); int total = hoja.RowCount * hoja.ColumnCount;
        for (int n = 0; n < total; n++)
        {
            int indice = (inicio + n) % total, f = indice / hoja.ColumnCount, c = indice % hoja.ColumnCount;
            if (motor.Contenido(DireccionCelda(f, c)).Contains(texto, StringComparison.CurrentCultureIgnoreCase))
            { hoja.Rows[f].Visible = true; hoja.CurrentCell = hoja[c, f]; hoja.Focus(); return; }
        }
        MessageBox.Show(this, "No se encontraron coincidencias.", "Buscar");
    }
    private void ReemplazarHoja()
    {
        using var d = new MYGCamposProyectoForm("Reemplazar en el rango seleccionado", new[] { "Buscar (distingue mayúsculas)", "Reemplazar por" }, new[] { "", "" });
        if (d.ShowDialog(this) != DialogResult.OK || string.IsNullOrEmpty(d.Valores[0])) return;
        var copia = MYGProyectoStorage.Copia(actual.Costos.Hoja);
        foreach (DataGridViewCell c in hoja.SelectedCells)
        {
            string dir = DireccionCelda(c.RowIndex, c.ColumnIndex);
            var celda = MYGEdicionHoja.Celda(copia, dir);
            string texto = celda.Contenido.Replace(d.Valores[0], d.Valores[1], StringComparison.Ordinal);
            MYGEdicionHoja.ValidarEntrada(copia, dir, texto); celda.Contenido = texto;
        }
        MYGHojaCalculo.Validar(copia);
        antes(); actual.Costos.Hoja = copia; RecalcularHoja(); Cambiado();
    }
    private void ValidacionHoja()
    {
        using var d = new MYGCamposProyectoForm("Validación de datos", new[] { "Tipo: Ninguna, Numero, Entero o Lista", "Mínimo (vacío: sin límite)", "Máximo (vacío: sin límite)", "Valores permitidos separados por ;" }, new[] { "Numero", "0", "", "" });
        if (d.ShowDialog(this) != DialogResult.OK) return;
        string tipo = d.Valores[0];
        if (!new[] { "Ninguna", "Numero", "Entero", "Lista" }.Contains(tipo)) throw new InvalidOperationException("Tipo de validación no reconocido.");
        decimal? Limite(string s) => string.IsNullOrWhiteSpace(s) ? null : MYGHojaCalculo.IntentarNumero(s, out var n) ? n : throw new InvalidOperationException("Límite numérico inválido.");
        decimal? min = Limite(d.Valores[1]), max = Limite(d.Valores[2]);
        if (min > max) throw new InvalidOperationException("El mínimo supera el máximo.");
        EditarFormatoHoja(c => { c.TipoValidacion = tipo; c.Minimo = min; c.Maximo = max; c.ListaValores = d.Valores[3].Split(';', StringSplitOptions.RemoveEmptyEntries).ToList(); });
    }
    private int AnchoColumnaHoja(MYGHojaMetrado h, int c) => Math.Max(16, (int)Math.Round(h.AnchosColumnas.GetValueOrDefault(c, c == 1 ? 288 : c == 8 ? 110 : c == 2 || c == 3 ? 60 : c == 7 ? 95 : 68) * h.Zoom / 100d * DeviceDpi / 96d));
    private void AplicarVistaHoja(bool conservarEdicion = false)
    {
        if (!HayPartida || hoja.Rows.Count == 0) return;
        var h = actual.Costos.Hoja;
        AplicarEncabezadosHoja();
        hoja.CellBorderStyle = h.LineasDivision ? DataGridViewCellBorderStyle.Single : DataGridViewCellBorderStyle.None;
        hoja.GridColor = MYG2027_TemaComercial.Oscuro ? MYG2027_TemaComercial.Borde : Color.FromArgb(190, 211, 246);
        if (!conservarEdicion) foreach (DataGridViewRow fila in hoja.Rows) fila.Frozen = false;
        foreach (DataGridViewColumn col in hoja.Columns) { if (!conservarEdicion) col.Frozen = false; col.Width = AnchoColumnaHoja(h, col.Index + 1); }
        foreach (DataGridViewRow fila in hoja.Rows)
        {
            if (!conservarEdicion) fila.Frozen = fila.Index < h.FilasInmovilizadas;
            fila.Height = Math.Max(hoja.RowHeadersDefaultCellStyle.Font.Height + (int)Math.Ceiling(2 * DeviceDpi / 96d), (int)Math.Round(h.AltosFilas.GetValueOrDefault(fila.Index + 1, fila.Index == 1 ? 28 : 18) * h.Zoom / 100d * DeviceDpi / 96d));
        }
        if (!conservarEdicion) foreach (DataGridViewColumn col in hoja.Columns) col.Frozen = col.Index < h.ColumnasInmovilizadas;
        pestanasHoja.TabPages[0].Text = h.Nombre;
        if (!conservarEdicion) FiltrarHoja();
    }
    private void FiltrarHoja()
    {
        if (!HayPartida || hoja.Rows.Count == 0) return;
        var h = actual.Costos.Hoja;
        int total = MYGHojaCalculo.Coordenadas(h.CeldaTotal).Fila - 1;
        var motor = new MYGHojaCalculo(h);
        var ocultas = h.FilasOcultas.ToHashSet();
        (int Fila, int Columna)? activa = hoja.CurrentCell == null ? null : (hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex);
        var seleccion = hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => (c.RowIndex, c.ColumnIndex)).ToArray();
        bool previo = cargando; cargando = true;
        try
        {
            hoja.CurrentCell = null;
            foreach (DataGridViewRow f in hoja.Rows)
            {
                bool coincide = string.IsNullOrEmpty(filtroTextoHoja) || f.Cells.Cast<DataGridViewCell>().Any(c =>
                    motor.Mostrar(DireccionCelda(f.Index, c.ColumnIndex)).Contains(filtroTextoHoja, StringComparison.CurrentCultureIgnoreCase));
                f.Visible = f.Frozen || !ocultas.Contains(f.Index + 1) && (f.Index < 2 || f.Index >= total || coincide);
            }
            if (activa is { } posicion)
            {
                var fila = hoja.Rows[posicion.Fila].Visible ? hoja.Rows[posicion.Fila]
                    : hoja.Rows.Cast<DataGridViewRow>().FirstOrDefault(f => f.Visible && f.Index >= 2)
                        ?? hoja.Rows.Cast<DataGridViewRow>().FirstOrDefault(f => f.Visible);
                hoja.ClearSelection();
                if (fila != null)
                {
                    hoja.CurrentCell = fila.Cells[posicion.Columna];
                    foreach (var celda in seleccion)
                        if (hoja.Rows[celda.RowIndex].Visible) hoja[celda.ColumnIndex, celda.RowIndex].Selected = true;
                    hoja.CurrentCell.Selected = true;
                }
            }
        }
        finally { cargando = previo; }
        if (!cargando) ActualizarFormula();
    }
    private void AplicarFormatoCeldaHoja(DataGridViewCell celda, MYGCeldaHoja estilo)
    {
        estilo ??= new();
        string horizontal = MYGEdicionHoja.AlineacionCelda(estilo, DireccionCelda(celda.RowIndex, celda.ColumnIndex));
        var formato = (estilo.Negrita ? FontStyle.Bold : 0) | (estilo.Cursiva ? FontStyle.Italic : 0) | (estilo.Subrayado ? FontStyle.Underline : 0) | (estilo.Tachado ? FontStyle.Strikeout : 0);
        float puntos = (float)estilo.TamanoFuente * (HayPartida ? actual.Costos.Hoja.Zoom / 100f : 1);
        celda.Style.Font = FuenteHoja(estilo.Fuente, puntos, formato);
        celda.Style.WrapMode = estilo.AjustarTexto ? DataGridViewTriState.True : DataGridViewTriState.False;
        celda.Style.Alignment = estilo.AlineacionVertical switch
        {
            "Arriba" => horizontal switch { "Centro" => DataGridViewContentAlignment.TopCenter, "Derecha" => DataGridViewContentAlignment.TopRight, _ => DataGridViewContentAlignment.TopLeft },
            "Abajo" => horizontal switch { "Centro" => DataGridViewContentAlignment.BottomCenter, "Derecha" => DataGridViewContentAlignment.BottomRight, _ => DataGridViewContentAlignment.BottomLeft },
            _ => horizontal switch { "Centro" => DataGridViewContentAlignment.MiddleCenter, "Derecha" => DataGridViewContentAlignment.MiddleRight, _ => DataGridViewContentAlignment.MiddleLeft }
        };
    }
    private Font FuenteHoja(string nombre, float puntos, FontStyle formato = FontStyle.Regular)
    {
        string clave = nombre + "|" + puntos.ToString(CultureInfo.InvariantCulture) + "|" + formato;
        if (!fuentesHoja.TryGetValue(clave, out var f)) fuentesHoja[clave] = f = new Font(nombre, Math.Max(2, puntos), formato);
        return f;
    }
    private int CalcularAnchoEncabezadoHoja(int filas)
    {
        var f = FuenteHoja("Segoe UI", 9);
        int texto = TextRenderer.MeasureText(Math.Max(1, filas).ToString(CultureInfo.InvariantCulture), f, Size.Empty,
            TextFormatFlags.SingleLine | TextFormatFlags.NoPadding).Width;
        return Math.Max((int)Math.Ceiling(28 * DeviceDpi / 96d), texto + (int)Math.Ceiling(12 * DeviceDpi / 96d));
    }
    private void AplicarEncabezadosHoja()
    {
        if (!HayPartida) return;
        var h = actual.Costos.Hoja;
        hoja.RowHeadersVisible = hoja.ColumnHeadersVisible = h.Encabezados;
        hoja.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
        hoja.RowHeadersWidth = CalcularAnchoEncabezadoHoja(h.Filas);
        var fuenteEncabezados = FuenteHoja("Segoe UI", 9);
        hoja.RowHeadersDefaultCellStyle.Font = hoja.ColumnHeadersDefaultCellStyle.Font = fuenteEncabezados;
        hoja.RowHeadersDefaultCellStyle.Padding = hoja.ColumnHeadersDefaultCellStyle.Padding = Padding.Empty;
        hoja.RowHeadersDefaultCellStyle.Alignment = hoja.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        hoja.ColumnHeadersHeight = Math.Max((int)Math.Ceiling(20 * DeviceDpi / 96d), fuenteEncabezados.Height + (int)Math.Ceiling(4 * DeviceDpi / 96d));
    }
    private static void AplicarColoresCeldaHoja(DataGridViewCell celda, MYGCeldaHoja estilo)
    {
        if (estilo == null) return;
        if (!string.IsNullOrEmpty(estilo.ColorFondo)) celda.Style.BackColor = ColorHoja(estilo.ColorFondo);
        if (!string.IsNullOrEmpty(estilo.ColorTexto)) celda.Style.ForeColor = ColorHoja(estilo.ColorTexto);
    }
    private static Color ColorHoja(string color) => ColorTranslator.FromHtml(color.StartsWith('#') ? color : "#" + color);
    private bool EsInteriorCombinado(string direccion)
    {
        if (!HayPartida) return false;
        var p = MYGHojaCalculo.Coordenadas(direccion);
        foreach (string rango in actual.Costos.Hoja.RangosCombinados)
        { var r = RangoHoja(rango); if (p.Fila - 1 >= r.f1 && p.Fila - 1 <= r.f2 && p.Columna - 1 >= r.c1 && p.Columna - 1 <= r.c2) return p.Fila - 1 != r.f1 || p.Columna - 1 != r.c1; }
        return false;
    }
    private void PintarCeldaHoja(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (!HayPartida) return;
        if (e.RowIndex < 0)
        {
            bool seleccionada = e.ColumnIndex >= 0 && hoja.Rows.Cast<DataGridViewRow>().Any(r => hoja[e.ColumnIndex, r.Index].Selected);
            using var fondo = new SolidBrush(seleccionada ? MYG2027_TemaComercial.Seleccion : MYG2027_TemaComercial.CabeceraTabla);
            e.Graphics.FillRectangle(fondo, e.CellBounds);
            if (e.ColumnIndex >= 0)
                TextRenderer.DrawText(e.Graphics, hoja.Columns[e.ColumnIndex].HeaderText,
                    hoja.ColumnHeadersDefaultCellStyle.Font, e.CellBounds, MYG2027_TemaComercial.Texto,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
            using var borde = new Pen(hoja.GridColor);
            e.Graphics.DrawLine(borde, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom);
            e.Graphics.DrawLine(borde, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right, e.CellBounds.Bottom - 1);
            e.Handled = true; return;
        }
        if (e.ColumnIndex < 0)
        {
            // The native row header reserves room for the current-row arrow.
            // Paint the number ourselves so that the arrow cannot hide it.
            bool activa = hoja.Rows[e.RowIndex].Cells.Cast<DataGridViewCell>().Any(c => c.Selected);
            using var fondo = new SolidBrush(activa ? MYG2027_TemaComercial.Seleccion : MYG2027_TemaComercial.CabeceraTabla);
            e.Graphics.FillRectangle(fondo, e.CellBounds);
            var rect = Rectangle.Inflate(e.CellBounds, -(int)Math.Ceiling(4 * DeviceDpi / 96d), 0);
            TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(CultureInfo.InvariantCulture),
                hoja.RowHeadersDefaultCellStyle.Font, rect, MYG2027_TemaComercial.Texto,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
            using var borde = new Pen(hoja.GridColor);
            e.Graphics.DrawLine(borde, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom);
            e.Graphics.DrawLine(borde, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right, e.CellBounds.Bottom - 1);
            e.Handled = true; return;
        }
        var h = actual.Costos.Hoja;
        foreach (string rango in h.RangosCombinados)
        {
            var r = RangoHoja(rango);
            if (e.RowIndex < r.f1 || e.RowIndex > r.f2 || e.ColumnIndex < r.c1 || e.ColumnIndex > r.c2) continue;
            e.PaintBackground(e.ClipBounds, true); e.Handled = true;
            // Every visible member repaints its clipped section, including when
            // the anchor has scrolled out of view.
            var limites = LimitesCombinacionHoja(r);
            if (limites == null) return;
            var union = limites.Value;
            var ancla = hoja[r.c1, r.f1];
            var estado = e.Graphics.Save();
            e.Graphics.SetClip(Rectangle.Intersect(e.CellBounds, e.ClipBounds));
            bool seleccionada = hoja.SelectedCells.Cast<DataGridViewCell>().Any(c =>
                c.RowIndex >= r.f1 && c.RowIndex <= r.f2 && c.ColumnIndex >= r.c1 && c.ColumnIndex <= r.c2);
            using var fondo = new SolidBrush(seleccionada ? ancla.InheritedStyle.SelectionBackColor : ancla.InheritedStyle.BackColor);
            e.Graphics.FillRectangle(fondo, union);
            if (!EstaEditandoCombinacionHoja(e.RowIndex, e.ColumnIndex))
                TextRenderer.DrawText(e.Graphics, Convert.ToString(ancla.Value), ancla.Style.Font ?? hoja.Font, union,
                    seleccionada ? ancla.InheritedStyle.SelectionForeColor : ancla.InheritedStyle.ForeColor,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis |
                    TextFormatFlags.PreserveGraphicsClipping | TextFormatFlags.NoPrefix);
            using var borde = new Pen(hoja.GridColor); e.Graphics.DrawRectangle(borde, union.X, union.Y, union.Width - 1, union.Height - 1);
            e.Graphics.Restore(estado); return;
        }
        // The initial measurement block follows the dotted ruled template.
        bool bloque = e.RowIndex >= 2 && e.RowIndex < 15 && e.ColumnIndex < 8;
        var celda = h.Celdas.GetValueOrDefault(DireccionCelda(e.RowIndex, e.ColumnIndex));
        if (!bloque && celda?.Bordes != true) return;
        e.Paint(e.ClipBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.Border); e.Handled = true;
        using var pen = new Pen(MYG2027_TemaComercial.Secundario);
        if (bloque) pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
        e.Graphics.DrawLine(pen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right, e.CellBounds.Bottom - 1);
        pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
        e.Graphics.DrawLine(pen, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom);
    }
}

internal sealed class MYGConfirmarCombinacionForm : Form
{
    internal MYGConfirmarCombinacionForm(string rango, string origen, string contenido, int cantidad)
    {
        Name = "combinar_aviso";
        Text = "Combinar celdas";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MinimizeBox = MaximizeBox = false;
        ShowInTaskbar = false;
        AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new Size(500, 245);
        var mensaje = new Label
        {
            Name = "combinar_mensaje", Dock = DockStyle.Top, Height = 70, Padding = new Padding(12),
            Text = $"El rango {rango} contiene {cantidad} celdas con contenido.\nSe conservará el primer contenido, de {origen}:"
        };
        var valor = new TextBox
        {
            Name = "combinar_valor", Dock = DockStyle.Fill, ReadOnly = true, Multiline = true,
            ScrollBars = ScrollBars.Vertical, Text = contenido, AccessibleName = "Contenido que conservará la celda combinada"
        };
        var perdida = new Label
        {
            Dock = DockStyle.Bottom, Height = 48, Padding = new Padding(12, 8, 12, 0),
            Text = $"Se eliminará el contenido de las otras {cantidad - 1} celdas.\n¿Desea combinar?"
        };
        var botones = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom, Height = 44, Padding = new Padding(8), FlowDirection = FlowDirection.RightToLeft
        };
        var cancelar = new Button { Name = "combinar_cancelar", Text = "Cancelar", DialogResult = DialogResult.Cancel, AutoSize = true };
        var aceptar = new Button { Name = "combinar_aceptar", Text = "Combinar", DialogResult = DialogResult.OK, AutoSize = true };
        botones.Controls.Add(cancelar); botones.Controls.Add(aceptar);
        Controls.Add(valor); Controls.Add(perdida); Controls.Add(botones); Controls.Add(mensaje);
        AcceptButton = cancelar;
        CancelButton = cancelar;
        Shown += (_, _) => cancelar.Focus();
        MYG2027_TemaComercial.Aplicar(this);
    }
}

internal sealed class MYGMetradoCabecera : Panel
{
    private readonly Func<string> presupuesto, item, partida;
    private readonly Label titulo = new() { Name = "metrado_cabecera_titulo", Text = "Metrado", AutoEllipsis = true };
    private readonly Label etiqueta = new() { Text = "Presupuesto:", AutoEllipsis = true };
    private readonly Label nombre = new() { Name = "metrado_cabecera_presupuesto", AutoEllipsis = true };
    private readonly Label codigo = new() { Name = "metrado_cabecera_item", AutoEllipsis = true };
    private readonly Label descripcion = new() { Name = "metrado_cabecera_partida", AutoEllipsis = true };
    private readonly Button excel = new() { Name = "metrado_exportar_xlsx", Text = "XLS  ▾", FlatStyle = FlatStyle.Flat, AccessibleName = "Importar o exportar libro Excel" };
    private readonly Font fuenteTitulo = new("Segoe UI", 14), fuenteDatos = new("Segoe UI", 9), fuenteCodigo = new("Segoe UI", 9, FontStyle.Bold);
    private readonly ContextMenuStrip menu = new();
    internal MYGMetradoCabecera(Func<string> presupuesto, Func<string> item, Func<string> partida, Action exportar, Action importar)
    {
        this.presupuesto = presupuesto; this.item = item; this.partida = partida;
        Name = "metrado_cabecera"; Dock = DockStyle.Top; Height = 103;
        titulo.Font = fuenteTitulo; etiqueta.Font = nombre.Font = descripcion.Font = fuenteDatos; codigo.Font = fuenteCodigo;
        foreach (var control in new Control[] { titulo, etiqueta, nombre, codigo, descripcion, excel }) Controls.Add(control);
        menu.Items.Add("Guardar como XLSX…", null, (_, _) => exportar());
        menu.Items.Add("Importar XLSX…", null, (_, _) => importar());
        excel.Click += (_, _) => menu.Show(excel, new Point(0, excel.Height));
        excel.ImageAlign = ContentAlignment.TopCenter; excel.TextAlign = ContentAlignment.BottomCenter;
        SizeChanged += (_, _) => Dimensionar();
        Disposed += (_, _) => { fuenteTitulo.Dispose(); fuenteDatos.Dispose(); fuenteCodigo.Dispose(); excel.Image?.Dispose(); menu.Dispose(); };
        AplicarPaleta(); Actualizar(); Dimensionar();
    }
    internal void Actualizar() { nombre.Text = presupuesto() ?? ""; codigo.Text = item() ?? ""; descripcion.Text = partida() ?? ""; }
    internal void AplicarPaleta()
    {
        BackColor = MYG2027_TemaComercial.SuperficieAlterna;
        foreach (var control in new Control[] { titulo, etiqueta, nombre, codigo, descripcion })
        { control.BackColor = Color.Transparent; control.ForeColor = MYG2027_TemaComercial.Texto; }
        MYG2027_TemaComercial.EstilizarBoton(excel);
        excel.Image?.Dispose();
        using var icono = MYGIconos.Obtener("excel");
        excel.Image = new Bitmap(icono, new Size((int)Math.Round(36 * DeviceDpi / 96d), (int)Math.Round(36 * DeviceDpi / 96d)));
        Invalidate(true);
    }
    private void Dimensionar()
    {
        int S(int x) => (int)Math.Round(x * DeviceDpi / 96d);
        Height = S(103);
        int derecha = Math.Max(S(150), Width - S(126));
        titulo.Bounds = new(S(14), S(7), Math.Max(S(40), derecha - S(20)), S(30));
        etiqueta.Bounds = new(S(16), S(44), S(110), S(20));
        nombre.Bounds = new(S(136), S(44), Math.Max(S(20), derecha - S(138)), S(20));
        codigo.Bounds = new(S(16), S(64), S(110), S(20));
        descripcion.Bounds = new(S(136), S(64), Math.Max(S(20), derecha - S(138)), S(20));
        excel.Bounds = new(Math.Max(0, Width - S(116)), S(3), S(110), S(96));
    }
}
