using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class CamposTemaUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private const int WmKeyDown = 0x0100, WmKeyUp = 0x0101;
    private const int WmLeftButtonDown = 0x0201, WmLeftButtonUp = 0x0202;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr ConsultarFecha(IntPtr ventana, int mensaje, IntPtr wParam, ref InformacionFecha informacion);
    [DllImport("user32.dll")]
    private static extern bool GetComboBoxInfo(IntPtr ventana, ref InformacionCombo informacion);
    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr ventana, out Rectangulo rectangulo);
    [DllImport("user32.dll")]
    private static extern IntPtr GetDC(IntPtr ventana);
    [DllImport("user32.dll")]
    private static extern int ReleaseDC(IntPtr ventana, IntPtr dc);
    [DllImport("gdi32.dll")]
    private static extern bool BitBlt(IntPtr destino, int x, int y, int ancho, int alto,
        IntPtr origen, int origenX, int origenY, uint operacion);

    [StructLayout(LayoutKind.Sequential)]
    private struct Rectangulo { internal int Izquierda, Arriba, Derecha, Abajo; }
    [StructLayout(LayoutKind.Sequential)]
    private struct InformacionCombo
    {
        internal int Tamano;
        internal Rectangulo Item, Boton;
        internal uint EstadoBoton;
        internal IntPtr Ventana, Edicion, Lista;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct InformacionFecha
    {
        internal int Tamano;
        internal Rectangulo Casilla;
        internal uint EstadoCasilla;
        internal Rectangulo Boton;
        internal uint EstadoBoton;
        internal IntPtr Edicion, Incremento, Calendario;
    }

    private sealed class Opcion
    {
        public string Nombre { get; init; }
        public override string ToString() => "ESTE TEXTO NO ES EL DISPLAYMEMBER";
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            VerificarControles(exige);
            VerificarDatosProyecto(exige);
            VerificarDialogosConPaletaPropia(exige);
        }
        finally { CambiarTema(original); }
    }

    private static void VerificarControles(Action<bool, string> exige)
    {
        using var ventana = new Form { Text = "Campos de tema", ClientSize = new Size(560, 400) };
        var texto = new TextBox { Text = "Texto pendiente", Bounds = new Rectangle(16, 16, 300, 26) };
        var numero = new NumericUpDown { Value = 12.5m, DecimalPlaces = 2, Bounds = new Rectangle(16, 52, 300, 26) };
        var lista = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList,
            DisplayMember = nameof(Opcion.Nombre), Bounds = new Rectangle(16, 88, 300, 26) };
        lista.Items.AddRange(new object[] { new Opcion { Nombre = "Primera opción" }, new Opcion { Nombre = "Segunda opción" } });
        lista.SelectedIndex = 1;
        var editable = new ComboBox { DropDownStyle = ComboBoxStyle.DropDown,
            Bounds = new Rectangle(16, 124, 300, 26), Text = "Edición libre pendiente" };
        editable.Items.Add("Opción de lista");
        var propia = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DrawMode = DrawMode.OwnerDrawFixed,
            Bounds = new Rectangle(16, 160, 300, 26) };
        propia.Items.Add("Dibujo propio"); propia.SelectedIndex = 0;
        int dibujosPropios = 0;
        propia.DrawItem += (_, e) =>
        {
            dibujosPropios++; e.DrawBackground();
            if (e.Index >= 0) TextRenderer.DrawText(e.Graphics, propia.GetItemText(propia.Items[e.Index]),
                propia.Font, e.Bounds, e.ForeColor, TextFormatFlags.VerticalCenter);
        };
        var fecha = new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy",
            Value = new DateTime(2026, 10, 27), MinDate = new DateTime(2020, 1, 1), MaxDate = new DateTime(2030, 12, 31),
            ShowCheckBox = true, Checked = false, Bounds = new Rectangle(16, 196, 300, 26) };
        var fechaTeclado = new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy",
            Value = new DateTime(2026, 10, 27), ShowUpDown = true, Bounds = new Rectangle(16, 232, 300, 26) };
        ventana.Controls.AddRange(new Control[] { texto, numero, lista, editable, propia, fecha, fechaTeclado });
        ventana.Show(); Application.DoEvents();
        foreach (bool oscuro in new[] { false, true, false, true })
        {
            CambiarTema(oscuro);
            VerificarPaleta(new Control[] { texto, numero, lista, editable, propia, fecha, fechaTeclado }, exige);
            exige(texto.Text == "Texto pendiente" && numero.Value == 12.5m &&
                lista.SelectedIndex == 1 && lista.Text == "Segunda opción" &&
                editable.Text == "Edición libre pendiente" && propia.SelectedIndex == 0 &&
                fecha.Value == new DateTime(2026, 10, 27) && !fecha.Checked &&
                fecha.MinDate == new DateTime(2020, 1, 1) && fecha.MaxDate == new DateTime(2030, 12, 31),
                "Alternar el tema debe conservar textos, DisplayMember, selecciones, valores numéricos y límites/estado de las fechas.");
            exige(propia.DrawMode == DrawMode.OwnerDrawFixed,
                "El tema debe conservar el dibujo propio de los selectores de colores, fuentes y orientación.");
            propia.Refresh();
            exige(dibujosPropios > 0, "Los selectores con dibujo propio deben seguir recibiendo DrawItem.");
            if (!oscuro || SystemInformation.HighContrast) continue;
            foreach (var control in new Control[] { texto, numero, lista, editable, propia, fecha, fechaTeclado })
                VerificarFondoOscuro(control, exige);
            VerificarListaDesplegada(lista, exige);
        }

        var dinamico = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList,
            Bounds = new Rectangle(16, 268, 300, 26) };
        dinamico.Items.Add("Creado después de abrir"); dinamico.SelectedIndex = 0;
        ventana.Controls.Add(dinamico); Application.DoEvents();
        VerificarPaleta(new Control[] { dinamico }, exige);
        foreach (var control in new Control[] { lista, editable, propia, fecha, fechaTeclado, dinamico })
        {
            typeof(Control).GetMethod("RecreateHandle", Privados).Invoke(control, null);
            Application.DoEvents();
            if (!SystemInformation.HighContrast) VerificarFondoOscuro(control, exige);
        }
        exige(lista.SelectedIndex == 1 && propia.DrawMode == DrawMode.OwnerDrawFixed && !fecha.Checked &&
            fecha.Value == new DateTime(2026, 10, 27) && editable.Text == "Edición libre pendiente",
            "Recrear los controles nativos en oscuro debe conservar su edición y los estilos especializados.");

        fechaTeclado.Focus(); Application.DoEvents();
        var antes = fechaTeclado.Value;
        Tecla(fechaTeclado, Keys.Right);
        if (!SystemInformation.HighContrast)
        {
            using var seleccionada = Capturar(fechaTeclado);
            exige(Pixeles(seleccionada, c => Math.Max(c.R, Math.Max(c.G, c.B)) - Math.Min(c.R, Math.Min(c.G, c.B)) > 35) > 3,
                "El selector de fecha enfocado debe mostrar el segmento seleccionado al navegar con el teclado.");
        }
        Tecla(fechaTeclado, Keys.Up);
        exige(fechaTeclado.Value != antes,
            "La fecha oscura debe conservar la edición nativa por segmentos y los controles de incremento.");
        // Una captura del HWND comprueba el repintado visible después de una
        // interacción nativa, además de la ruta WM_PRINTCLIENT de DrawToBitmap.
        var informacionFecha = new InformacionFecha { Tamano = Marshal.SizeOf<InformacionFecha>() };
        ConsultarFecha(fecha.Handle, 0x100E, IntPtr.Zero, ref informacionFecha); // DTM_GETDATETIMEPICKERINFO.
        exige(informacionFecha.Casilla.Derecha > informacionFecha.Casilla.Izquierda,
            "La fecha opcional debe conservar el área nativa de su casilla.");
        int casillaX = (informacionFecha.Casilla.Izquierda + informacionFecha.Casilla.Derecha) / 2;
        int casillaY = (informacionFecha.Casilla.Arriba + informacionFecha.Casilla.Abajo) / 2;
        foreach (bool marcada in new[] { true, false })
        {
            Pulsar(fecha.Handle, casillaX, casillaY); fecha.Update(); Application.DoEvents();
            exige(fecha.Checked == marcada && fecha.Value == new DateTime(2026, 10, 27),
                "Pulsar la casilla nativa debe cambiar su estado sin alterar la fecha guardada.");
            if (!SystemInformation.HighContrast)
            {
                using var pantalla = CapturarPantalla(fecha.Handle, exige);
                VerificarFondoOscuro(pantalla, "DateTimePicker después de pulsar su casilla", exige);
            }
        }
        if (!SystemInformation.HighContrast)
        {
            using var pantalla = CapturarPantalla(fechaTeclado.Handle, exige);
            VerificarFondoOscuro(pantalla, "DateTimePicker después de editar con el teclado", exige);
        }
        fecha.Checked = true;
        Pulsar(fecha.Handle, (informacionFecha.Boton.Izquierda + informacionFecha.Boton.Derecha) / 2,
            (informacionFecha.Boton.Arriba + informacionFecha.Boton.Abajo) / 2);
        try
        {
            IntPtr calendario = Enviar(fecha.Handle, 0x1008, IntPtr.Zero, IntPtr.Zero); // DTM_GETMONTHCAL.
            exige(calendario != IntPtr.Zero, "El selector oscuro debe conservar su calendario desplegable nativo.");
            if (!SystemInformation.HighContrast)
            {
                using var calendarioVisible = CapturarPantalla(calendario, exige);
                exige(Pixeles(calendarioVisible, c => c.GetBrightness() < .48F) >=
                    calendarioVisible.Width * calendarioVisible.Height * .50,
                    "El calendario desplegable de la fecha debe conservar también una superficie oscura legible.");
            }
        }
        finally
        {
            Tecla(fecha, Keys.Escape);
            Enviar(fecha.Handle, 0x100D, IntPtr.Zero, IntPtr.Zero); // DTM_CLOSEMONTHCAL.
            fecha.Checked = false;
        }
        dinamico.Enabled = false; fecha.Enabled = false;
        if (!SystemInformation.HighContrast)
        {
            VerificarFondoOscuro(dinamico, exige); VerificarFondoOscuro(fecha, exige);
        }
        CambiarTema(false);
        exige(lista.DrawMode == DrawMode.Normal && editable.DrawMode == DrawMode.Normal &&
            propia.DrawMode == DrawMode.OwnerDrawFixed,
            "Volver al modo normal debe restaurar el dibujo original sin eliminar los DrawItem personalizados.");
        ventana.Close();
    }

    private static void VerificarDatosProyecto(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-CamposTema-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "proyectos.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            byte[] antes = File.ReadAllBytes(ruta);
            var datos = MYGDatosProyecto.Crear(); datos.Propietario = "Propietario conservado";
            datos.FechaInicio = new DateTime(2026, 10, 27); datos.CalcularFin();
            string firma = JsonSerializer.Serialize(datos);
            using var dialogo = new MYGDatosProyectoForm(ruta, "Proyecto conservado", datos);
            dialogo.Show(); Application.DoEvents();
            var entradas = Controles(dialogo).Where(c => c is TextBox or ComboBox or NumericUpDown or DateTimePicker).ToArray();
            foreach (bool oscuro in new[] { true, false, true })
            {
                CambiarTema(oscuro); VerificarPaleta(entradas, exige);
                if (oscuro && !SystemInformation.HighContrast)
                    foreach (var entrada in entradas.Where(c => c.Visible)) VerificarFondoOscuro(entrada, exige);
            }
            var catalogos = (Dictionary<MYGCatalogoProyecto, ComboBox>)typeof(MYGDatosProyectoForm)
                .GetField("catalogos", Privados).GetValue(dialogo);
            exige(catalogos[MYGCatalogoProyecto.Propietarios].Text.Contains("Propietario conservado", StringComparison.Ordinal) &&
                JsonSerializer.Serialize(datos) == firma,
                "Información del proyecto debe conservar los catálogos y datos mientras cambia su apariencia.");
            dialogo.DialogResult = DialogResult.Cancel; dialogo.Close();
            exige(dialogo.Datos == null && JsonSerializer.Serialize(datos) == firma && antes.SequenceEqual(File.ReadAllBytes(ruta)),
                "Abrir, cambiar de tema y cancelar Información del proyecto debe conservar el documento y su base de datos.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static void VerificarDialogosConPaletaPropia(Action<bool, string> exige)
    {
        using var fuente = new Font("Segoe UI", 10F, FontStyle.Bold);
        using var formato = new MYGFuenteResumenForm(fuente, Color.DarkBlue, Color.LightYellow);
        using var costo = new MYGConfigurarCostoDirectoForm(new MYGConfiguracionCostoDirecto { Nombre = "Costo sin cambios" });
        formato.Show(); costo.Show(); Application.DoEvents();
        foreach (bool oscuro in new[] { false, true, false, true })
        {
            CambiarTema(oscuro);
            foreach (var dialogo in new Form[] { formato, costo })
            {
                var entradas = Controles(dialogo).Where(c => c is TextBox or ListBox or ComboBox).ToArray();
                exige(entradas.All(c => c.BackColor == (oscuro && !SystemInformation.HighContrast
                    ? MYG2027_TemaComercial.Superficie : SystemColors.Window)),
                    "Los diálogos Fuente y Costo directo deben adaptar sus entradas sin reponer el blanco en oscuro.");
                if (oscuro && !SystemInformation.HighContrast)
                    // Las muestras de color son contenido de autor y pueden
                    // ocupar casi todo el selector, incluso en modo oscuro.
                    foreach (var entrada in entradas.Where(c => c is not ComboBox { DrawMode: not DrawMode.Normal }))
                        VerificarFondoOscuro(entrada, exige);
            }
            var ejemplo = formato.Controls.Find("ejemploFuenteResumen", true).Single();
            using var imagen = Capturar(ejemplo);
            exige(imagen.GetPixel(1, 1).ToArgb() == Color.LightYellow.ToArgb() &&
                formato.ColorTexto.ToArgb() == Color.DarkBlue.ToArgb() && formato.ColorFondo.ToArgb() == Color.LightYellow.ToArgb(),
                "La apariencia oscura de los campos debe conservar los colores de autor y el papel de la muestra de fuente.");
        }
        formato.Close(); costo.Close();
    }

    private static void VerificarPaleta(IEnumerable<Control> controles, Action<bool, string> exige)
    {
        foreach (var control in controles)
            exige(control.BackColor == MYG2027_TemaComercial.Superficie &&
                (SystemInformation.HighContrast || DisenoProfesionalCheck.Contraste(control.ForeColor, control.BackColor) >= 4.5),
                $"El campo {control.GetType().Name} debe usar la superficie y texto legible del tema.");
    }

    private static void VerificarFondoOscuro(Control control, Action<bool, string> exige)
    {
        using var imagen = Capturar(control);
        VerificarFondoOscuro(imagen, control.GetType().Name, exige);
    }

    private static void VerificarFondoOscuro(Bitmap imagen, string nombre, Action<bool, string> exige)
    {
        var interior = new Rectangle(Math.Min(20, imagen.Width / 4), 3,
            Math.Max(1, imagen.Width - Math.Min(20, imagen.Width / 4) - 24), Math.Max(1, imagen.Height - 6));
        int oscuros = 0, total = 0;
        for (int y = interior.Top; y < interior.Bottom; y++)
            for (int x = interior.Left; x < interior.Right; x++)
            {
                if (imagen.GetPixel(x, y).GetBrightness() < .48F) oscuros++;
                total++;
            }
        exige(oscuros >= total * .60,
            $"El área visible de {nombre} debe ser oscura, incluidos los campos nativos de fecha y lista.");
    }

    private static void VerificarListaDesplegada(ComboBox combo, Action<bool, string> exige)
    {
        combo.DroppedDown = true; Application.DoEvents();
        try
        {
            var info = new InformacionCombo { Tamano = Marshal.SizeOf<InformacionCombo>() };
            exige(GetComboBoxInfo(combo.Handle, ref info) && info.Lista != IntPtr.Zero,
                "El desplegable oscuro debe conservar su lista nativa accesible.");
            using var imagen = CapturarPantalla(info.Lista, exige);
            exige(Pixeles(imagen, c => c.GetBrightness() < .48F) >= imagen.Width * imagen.Height * .50,
                "Al abrir un desplegable su lista debe mantener el fondo oscuro y la selección visible.");
        }
        finally { combo.DroppedDown = false; Application.DoEvents(); }
    }

    private static Bitmap Capturar(Control control)
    {
        control.Refresh(); Application.DoEvents();
        var imagen = new Bitmap(control.Width, control.Height);
        control.DrawToBitmap(imagen, control.ClientRectangle);
        return imagen;
    }

    private static Bitmap CapturarPantalla(IntPtr ventana, Action<bool, string> exige)
    {
        exige(GetClientRect(ventana, out var rectangulo), "La ventana nativa debe conservar su área de cliente.");
        int ancho = rectangulo.Derecha - rectangulo.Izquierda, alto = rectangulo.Abajo - rectangulo.Arriba;
        exige(ancho > 0 && alto > 0, "El campo nativo debe mantener su área visible.");
        var imagen = new Bitmap(ancho, alto);
        try
        {
            using var dibujo = Graphics.FromImage(imagen);
            IntPtr origen = GetDC(ventana), destino = dibujo.GetHdc();
            try
            {
                exige(origen != IntPtr.Zero && BitBlt(destino, 0, 0, ancho, alto, origen, 0, 0, 0x00CC0020),
                    "Debe poder capturarse el repintado visible del campo nativo.");
            }
            finally { dibujo.ReleaseHdc(destino); if (origen != IntPtr.Zero) ReleaseDC(ventana, origen); }
            return imagen;
        }
        catch { imagen.Dispose(); throw; }
    }

    private static int Pixeles(Bitmap imagen, Func<Color, bool> cumple)
    {
        int cantidad = 0;
        for (int y = 0; y < imagen.Height; y++)
            for (int x = 0; x < imagen.Width; x++)
                if (cumple(imagen.GetPixel(x, y))) cantidad++;
        return cantidad;
    }

    private static void Tecla(Control control, Keys tecla)
    {
        Enviar(control.Handle, WmKeyDown, new IntPtr((int)tecla), new IntPtr(1));
        Enviar(control.Handle, WmKeyUp, new IntPtr((int)tecla), new IntPtr(unchecked((int)0xC0000001)));
        Application.DoEvents();
    }

    private static void Pulsar(IntPtr ventana, int x, int y)
    {
        var punto = new IntPtr((x & 0xffff) | (y << 16));
        Enviar(ventana, WmLeftButtonDown, new IntPtr(1), punto);
        Enviar(ventana, WmLeftButtonUp, IntPtr.Zero, punto);
        Application.DoEvents();
    }

    private static void CambiarTema(bool oscuro)
    {
        if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
        Application.DoEvents();
    }

    private static IEnumerable<Control> Controles(Control control)
    {
        foreach (Control hijo in control.Controls)
        {
            yield return hijo;
            foreach (var nieto in Controles(hijo)) yield return nieto;
        }
    }
}
