using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MYG_2027;

// Las barras de scroll y las entradas nativas no pertenecen al área de dibujo
// del editor. Pedir también a Windows su variante oscura, sin cambiar el RTF.
internal static class MYGTemaNativo
{
    [DllImport("uxtheme.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
    private static extern int SetWindowTheme(IntPtr ventana, string aplicacion, string clases);
    private sealed class Estado
    {
        internal IntPtr Ventana;
        internal bool Oscuro;
    }
    private static readonly ConditionalWeakTable<Control, Estado> estados = new();

    internal static void Aplicar(Control control)
    {
        MYGTemaCamposNativos.Aplicar(control);
        if (!OperatingSystem.IsWindows() || control.IsDisposed || control.Disposing ||
            control is not (ScrollableControl or TextBoxBase or UpDownBase)) return;
        var estado = estados.GetValue(control, c =>
        {
            c.HandleCreated += (_, _) => Aplicar(c);
            c.HandleDestroyed += (_, _) =>
            {
                if (estados.TryGetValue(c, out var anterior)) anterior.Ventana = IntPtr.Zero;
            };
            return new Estado();
        });
        if (!control.IsHandleCreated) return;
        bool oscuro = MYG2027_TemaComercial.Oscuro && !SystemInformation.HighContrast;
        if (estado.Ventana == control.Handle && estado.Oscuro == oscuro) return;
        estado.Ventana = control.Handle;
        estado.Oscuro = oscuro;
        // SetWindowTheme es la API pública de estilos visuales; la disponibilidad
        // de la variante DarkMode_Explorer depende de la versión de Windows.
        if (SetWindowTheme(control.Handle, oscuro ? "DarkMode_Explorer" : null, null) < 0)
            SetWindowTheme(control.Handle, null, null);
        control.Invalidate();
    }
}
