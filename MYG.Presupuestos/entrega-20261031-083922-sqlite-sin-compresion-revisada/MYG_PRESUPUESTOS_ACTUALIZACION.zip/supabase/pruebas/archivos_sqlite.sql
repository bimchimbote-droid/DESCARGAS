-- SOLO PostgreSQL DESECHABLE. Storage se simula: aquí se validan metadatos y
-- permisos SQL; la cabecera/bytes SQLite reales se prueban en las suites C#.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren PostgreSQL desechable.'; end $$;
\endif

\ir usuarios_myg_roles.sql
reset role;
create schema storage;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint);
create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text,
    metadata jsonb,unique(bucket_id,name));
alter table storage.objects enable row level security;
grant usage on schema storage to authenticated,anon;
grant select,insert,update,delete on storage.objects to authenticated,anon;
-- Una política global permisiva representa instalaciones previas defectuosas.
-- Las nuevas políticas RESTRICTIVE deben seguir aislando el bucket SQLite.
create policy qa_permisiva_global on storage.objects for all to authenticated using(true) with check(true);
\ir ../migraciones/20261026_publicacion_ligera.sql
\ir ../migraciones/20261027_publicacion_sin_espera.sql
\ir ../migraciones/20261028_publicacion_comprimida.sql
create table qa.antes_sqlite as select
    (select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p) proyectos,
    (select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m) miembros,
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h) historial;
\ir ../migraciones/20261030_archivos_sqlite.sql
\ir ../migraciones/20261030_archivos_sqlite.sql
select qa.exige((select proyectos is not distinct from
    (select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p)
    and miembros is not distinct from
    (select jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id) from public.myg_nube_miembros m)
    and historial is not distinct from
    (select jsonb_agg(to_jsonb(h) order by proyecto_id,revision) from public.myg_nube_historial h)
    from qa.antes_sqlite),'SQLite: instalar/reinstalar conserva los proyectos, miembros e historial legados');
select qa.exige((select public=false and file_size_limit=314572800 from storage.buckets where id='myg-nube-sqlite'),
    'SQLite: bucket privado con límite 300 MiB');
select qa.exige(not has_function_privilege('anon','public.myg_nube_sqlite_capacidades()','execute')
    and not has_table_privilege('authenticated','myg_nube_privado.sqlite_revisiones','select')
    and not has_function_privilege('authenticated','myg_nube_privado.sqlite_snapshot(uuid,uuid,bigint)','execute'),
    'SQLite: auxiliares y tablas de versiones no son API pública');

create table qa.sqlite_casos(nombre text primary key,ruta text,sha256 text,bytes bigint);
insert into qa.sqlite_casos values
('inicial','00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('a',64)||'.sqlite',repeat('a',64),4096),
('segundo','00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('b',64)||'.sqlite',repeat('b',64),8192),
('tercero','00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('c',64)||'.sqlite',repeat('c',64),12288);
grant select on qa.sqlite_casos to authenticated;
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_sqlite_capacidades()='{"version":1,"max_bytes":314572800}'::jsonb,
    'SQLite: capacidad independiente sin activar compresión');
select qa.exige(public.myg_nube_sqlite_consultar('d9000000-0000-0000-0000-000000000001') is null
    and public.myg_nube_sqlite_consultar('10000000-0000-0000-0000-000000000001') is null,
    'SQLite: consultar distingue nuevos/legados autorizados sin abrir contenido');
insert into storage.objects(bucket_id,name,metadata)
select 'myg-nube-sqlite',ruta,jsonb_build_object('size',bytes) from qa.sqlite_casos;
select qa.exige((select count(*)=3 from storage.objects where bucket_id='myg-nube-sqlite'),
    'SQLite: autor verificado puede subir antes de crear');
select qa.rechaza($$select public.myg_nube_sqlite_crear('d9000000-0000-0000-0000-000000000001',
    'SQLite QA','base','doc-qa',ruta,sha256,bytes+1) from qa.sqlite_casos where nombre='inicial'$$,'22023',
    'SQLite: confirmar no acepta tamaño distinto al objeto Storage');
select qa.exige((select public.myg_nube_sqlite_crear('d9000000-0000-0000-0000-000000000001',
    'SQLite QA','base','doc-qa',ruta,sha256,bytes)#>>'{archivo_sqlite,sha256}'=sha256
    from qa.sqlite_casos where nombre='inicial'),'SQLite: creación confirma el archivo original con metadatos pequeños');
select qa.exige((select public.myg_nube_sqlite_crear('d9000000-0000-0000-0000-000000000001',
    'SQLite QA','base','doc-qa',ruta,sha256,bytes)->>'revision'='1'
    from qa.sqlite_casos where nombre='inicial'),'SQLite: replay creación idempotente');
select qa.exige(public.myg_nube_sqlite_consultar('d9000000-0000-0000-0000-000000000001')->>'documento_id'='doc-qa',
    'SQLite: descriptor conserva identidad documento y permisos');
select qa.rechaza($$select public.myg_nube_abrir('d9000000-0000-0000-0000-000000000001')$$,'MGS01',
    'SQLite: clientes JSON antiguos fallan explícitamente, no abren una obra vacía');
select qa.rechaza($$select public.myg_nube_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000001',1,'{}')$$,'MGS01',
    'SQLite: guardado legado no cambia datos ni formato');
select qa.exige((select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000002',1,ruta,sha256,bytes)->>'revision'='2'
    from qa.sqlite_casos where nombre='segundo'),'SQLite: CAS avanza exactamente una revisión');
select qa.exige((select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000002',1,ruta,sha256,bytes)->>'revision'='2'
    from qa.sqlite_casos where nombre='segundo'),'SQLite: ACK perdido no duplica revisión');
select qa.rechaza($$select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000002',1,ruta,sha256,bytes)
    from qa.sqlite_casos where nombre='tercero'$$,'22023','SQLite: UUID no permite cuerpo distinto');
select qa.exige((select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000003',1,ruta,sha256,bytes)->>'estado'='conflicto'
    from qa.sqlite_casos where nombre='tercero'),'SQLite: revisión atrasada conserva conflicto');
select qa.exige((select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000004',2,ruta,sha256,bytes)->>'revision'='3'
    from qa.sqlite_casos where nombre='tercero'),'SQLite: siguiente revisión válida progresa');
select qa.exige((select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000003',1,ruta,sha256,bytes)#>>'{archivo_sqlite,sha256}'=repeat('b',64)
    from qa.sqlite_casos where nombre='tercero'),'SQLite: replay conflicto devuelve archivo congelado, no versión posterior');
select qa.exige(public.myg_nube_sqlite_abrir('d9000000-0000-0000-0000-000000000001',1)#>>'{archivo_sqlite,sha256}'=repeat('a',64),
    'SQLite: revisiones históricas recuperables sin copias JSON');
select qa.exige(public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000007',1,
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('e',64)||'.sqlite',
    repeat('e',64),4096)->>'estado'='conflicto',
    'SQLite: CAS atrasado informa conflicto sin exigir subir un archivo que no podrá aplicarse');
with cambio as(update storage.objects set metadata='{}' where bucket_id='myg-nube-sqlite' returning *),
    baja as(delete from storage.objects where bucket_id='myg-nube-sqlite' returning *)
select qa.exige((select count(*)=0 from cambio) and (select count(*)=0 from baja),
    'SQLite: objetos confirmados y pendientes son inmutables incluso bajo política global permisiva');

reset role;
insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values
('d9000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','editor'),
('d9000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','lector');
update public.myg_nube_miembros set permisos_modulos='{"acu":false,"especificaciones":true,"metrados_excel":true}'
where proyecto_id='d9000000-0000-0000-0000-000000000001' and usuario_id='00000000-0000-0000-0000-000000000003';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
select qa.rechaza($$insert into storage.objects(bucket_id,name,metadata)
    values('myg-nube-sqlite','00000000-0000-0000-0000-000000000003/d9000000000000000000000000000001/'||repeat('d',64)||'.sqlite','{"size":4096}')$$,
    '42501','SQLite: editor restringido no puede subir snapshot opaco');
select qa.rechaza($$select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000005',3,ruta,sha256,bytes)
    from qa.sqlite_casos where nombre='tercero'$$,'42501','SQLite: editor restringido no puede confirmar');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.exige((select count(*)=3 from storage.objects where bucket_id='myg-nube-sqlite'),
    'SQLite: lector autorizado descarga el historial binario');
select qa.rechaza($$select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000006',3,ruta,sha256,bytes)
    from qa.sqlite_casos where nombre='tercero'$$,'42501','SQLite: lector no escribe');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige((select count(*)=0 from storage.objects where bucket_id='myg-nube-sqlite'),
    'SQLite: ajeno no accede aunque conozca la ruta');
select qa.rechaza($$select public.myg_nube_sqlite_consultar('d9000000-0000-0000-0000-000000000001')$$,
    '42501','SQLite: ajeno no obtiene metadatos');

reset role;
delete from public.myg_nube_miembros where proyecto_id='d9000000-0000-0000-0000-000000000001'
    and usuario_id='00000000-0000-0000-0000-000000000004';
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000004';
select qa.exige((select count(*)=0 from storage.objects where bucket_id='myg-nube-sqlite'),
    'SQLite: revocar membresía retira acceso a todos los archivos históricos');
select qa.rechaza($$select public.myg_nube_sqlite_abrir('d9000000-0000-0000-0000-000000000001',1)$$,
    '42501','SQLite: revocado tampoco descarga revisión antigua por RPC');
reset role;
select qa.exige((select count(*)=3 from myg_nube_privado.sqlite_revisiones)
    and (select count(*)=4 from myg_nube_privado.sqlite_operaciones),
    'SQLite: tres revisiones y cuatro operaciones; conflictos/replays no duplican revisiones');
select qa.exige((select contenido='{"formato":"MYG_SQLITE","version":1}'::jsonb and not es_comprimido
    from public.myg_nube_proyectos where id='d9000000-0000-0000-0000-000000000001')
    and not exists(select 1 from public.myg_nube_historial where proyecto_id='d9000000-0000-0000-0000-000000000001'),
    'SQLite: PostgreSQL conserva solo metadatos; el contenido no se copia a JSON/GZip');

-- Comprobar contención en otra conexión, no solo dos llamadas secuenciales.
create extension dblink;
select dblink_connect('sqlite_bloqueo','dbname='||current_database());
select dblink_exec('sqlite_bloqueo','begin');
select * from dblink('sqlite_bloqueo',
    $$select revision from public.myg_nube_proyectos where id='d9000000-0000-0000-0000-000000000001' for update$$)
    as bloqueo(revision bigint);
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$select public.myg_nube_sqlite_guardar('d9000000-0000-0000-0000-000000000001',
    'd9100000-0000-0000-0000-000000000008',3,ruta,sha256,bytes)
    from qa.sqlite_casos where nombre='tercero'$$,'55006','SQLite: bloqueo concurrente responde ocupado sin esperar ni perder la revisión');
select dblink_exec('sqlite_bloqueo','rollback');
select dblink_disconnect('sqlite_bloqueo');
select 'ARCHIVOS_SQLITE_SQL_APROBADOS' resultado;
