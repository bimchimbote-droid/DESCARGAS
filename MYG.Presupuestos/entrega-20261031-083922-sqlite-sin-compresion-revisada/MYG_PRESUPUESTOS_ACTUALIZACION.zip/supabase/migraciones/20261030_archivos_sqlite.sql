-- ARCHIVO SQLITE NATIVO: no se comprimen ni convierten a JSON los bytes SQLite.
-- Ejecutar completo después de 20261028_publicacion_comprimida.sql.
-- Los RPC solo intercambian metadatos pequeños. No convierte ni elimina obras
-- anteriores; para pasar una obra antigua se publica una copia con UUID nuevo.
-- Un snapshot opaco no permite comprobar módulos en PostgreSQL: los editores
-- con módulos restringidos no pueden subir/confirmar este formato. No se finge
-- una verificación equivalente a la ruta JSON anterior.
-- El bucket admite 300 MiB, sujeto también al límite global de Storage del plan.
begin;

do $preflight$
begin
    if to_regprocedure('myg_nube_privado.identidad()') is null
       or to_regprocedure('myg_nube_privado.exigir_paquete_json(uuid)') is null
       or to_regprocedure('public.myg_nube_revision(uuid)') is null
       or to_regprocedure('myg_nube_privado.permisos_modulos_validos(jsonb)') is null
       or not exists(select 1 from pg_attribute where attrelid='public.myg_nube_proyectos'::regclass
           and attname='es_comprimido' and atttypid='boolean'::regtype and not attisdropped) then
        raise exception 'Aplique primero la actualización de permisos y 20261028_publicacion_comprimida.sql.';
    end if;
    if not exists(select 1 from pg_class where oid=to_regclass('storage.objects') and relrowsecurity) then
        raise exception 'Se requiere Storage con RLS habilitado; no se modificó la instalación.';
    end if;
    if not exists(select 1 from pg_proc where oid='myg_nube_privado.exigir_paquete_json(uuid)'::regprocedure
        and md5(replace(prosrc,E'\r\n',E'\n')) in ('530ae12f40c08cde138a31a0167dafc9','d7f8df323ea3abddc376d5ac49f0682c')) then
        raise exception 'La guarda de formatos contiene una personalización desconocida; se conserva intacta.';
    end if;
    if exists(select 1 from storage.buckets where id='myg-nube-sqlite'
        and (name is distinct from 'myg-nube-sqlite' or public is distinct from false
            or file_size_limit is distinct from 314572800::bigint)) then
        raise exception 'El bucket myg-nube-sqlite tiene configuración incompatible; se conserva intacto.';
    end if;
end $preflight$;

insert into storage.buckets(id,name,public,file_size_limit)
values('myg-nube-sqlite','myg-nube-sqlite',false,314572800) on conflict(id) do nothing;

create table if not exists myg_nube_privado.sqlite_proyectos (
    proyecto_id uuid primary key references public.myg_nube_proyectos(id) deferrable initially deferred,
    documento_id text not null check(length(btrim(documento_id)) between 1 and 200)
);
create table if not exists myg_nube_privado.sqlite_revisiones (
    proyecto_id uuid not null references myg_nube_privado.sqlite_proyectos(proyecto_id),
    revision bigint not null check(revision>=1),
    usuario_id uuid not null,
    ruta text not null,
    sha256 text not null check(sha256 ~ '^[0-9a-f]{64}$'),
    bytes bigint not null check(bytes between 512 and 314572800),
    creado_en timestamptz not null default clock_timestamp(),
    primary key(proyecto_id,revision)
);
create index if not exists myg_nube_sqlite_ruta on myg_nube_privado.sqlite_revisiones(ruta);
create table if not exists myg_nube_privado.sqlite_operaciones (
    usuario_id uuid not null, operacion_id uuid not null,
    proyecto_id uuid not null references myg_nube_privado.sqlite_proyectos(proyecto_id),
    revision_base bigint not null, ruta text not null, sha256 text not null, bytes bigint not null,
    estado text not null check(estado in ('aplicada','conflicto')), revision bigint not null,
    creado_en timestamptz not null default clock_timestamp(),
    primary key(usuario_id,operacion_id)
);
revoke all on myg_nube_privado.sqlite_proyectos,myg_nube_privado.sqlite_revisiones,
    myg_nube_privado.sqlite_operaciones from public,anon,authenticated,service_role;
alter table myg_nube_privado.sqlite_proyectos enable row level security;
alter table myg_nube_privado.sqlite_revisiones enable row level security;
alter table myg_nube_privado.sqlite_operaciones enable row level security;

create or replace function myg_nube_privado.sqlite_puede_escribir(p_id uuid,p_usuario uuid)
returns boolean language sql stable security definer set search_path=pg_catalog as $fn$
    select exists(select 1 from public.myg_nube_miembros m
        where m.proyecto_id=p_id and m.usuario_id=p_usuario
          and m.rol in ('propietario','administrador','editor')
          and myg_nube_privado.permisos_modulos_validos(m.permisos_modulos)
          and m.permisos_modulos @> '{"acu":true,"especificaciones":true,"metrados_excel":true}'::jsonb);
$fn$;

create or replace function myg_nube_privado.sqlite_objeto_acceso(p_ruta text,p_escritura boolean)
returns boolean language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare v_usuario uuid:=auth.uid(); v_id uuid; v_propia boolean;
begin
    if v_usuario is null or not exists(select 1 from myg_nube_privado.identidades_verificadas
        where auth_usuario_id=v_usuario and activo) then return false; end if;
    if p_ruta is null or p_ruta !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{32}/[0-9a-f]{64}\.sqlite$' then
        return false;
    end if;
    v_id:=split_part(p_ruta,'/',2)::uuid;
    v_propia:=split_part(p_ruta,'/',1)=v_usuario::text;
    if p_escritura then
        return v_propia and (not exists(select 1 from public.myg_nube_proyectos where id=v_id)
            or myg_nube_privado.sqlite_puede_escribir(v_id,v_usuario));
    end if;
    if exists(select 1 from myg_nube_privado.sqlite_revisiones where ruta=p_ruta) then
        return exists(select 1 from myg_nube_privado.sqlite_revisiones r
            join public.myg_nube_miembros m on m.proyecto_id=r.proyecto_id
            where r.ruta=p_ruta and m.usuario_id=v_usuario);
    end if;
    return v_propia and (not exists(select 1 from public.myg_nube_proyectos where id=v_id)
        or myg_nube_privado.sqlite_puede_escribir(v_id,v_usuario));
end $fn$;
revoke all on function myg_nube_privado.sqlite_puede_escribir(uuid,uuid),
    myg_nube_privado.sqlite_objeto_acceso(text,boolean) from public,anon,authenticated,service_role;
grant usage on schema myg_nube_privado to authenticated,anon;
grant execute on function myg_nube_privado.sqlite_objeto_acceso(text,boolean) to authenticated,anon;

-- Las políticas RESTRICTIVE mantienen cerrado este bucket aun si existe una
-- política permisiva global antigua para otros buckets. Objetos inmutables.
drop policy if exists myg_sqlite_lectura on storage.objects;
create policy myg_sqlite_lectura on storage.objects for select to authenticated
using(bucket_id='myg-nube-sqlite' and myg_nube_privado.sqlite_objeto_acceso(name,false));
drop policy if exists myg_sqlite_subida on storage.objects;
create policy myg_sqlite_subida on storage.objects for insert to authenticated
with check(bucket_id='myg-nube-sqlite' and myg_nube_privado.sqlite_objeto_acceso(name,true));
drop policy if exists myg_sqlite_limitar_lectura on storage.objects;
create policy myg_sqlite_limitar_lectura on storage.objects as restrictive for select to public
using(bucket_id<>'myg-nube-sqlite' or myg_nube_privado.sqlite_objeto_acceso(name,false));
drop policy if exists myg_sqlite_limitar_subida on storage.objects;
create policy myg_sqlite_limitar_subida on storage.objects as restrictive for insert to public
with check(bucket_id<>'myg-nube-sqlite' or myg_nube_privado.sqlite_objeto_acceso(name,true));
drop policy if exists myg_sqlite_inmutable_update on storage.objects;
create policy myg_sqlite_inmutable_update on storage.objects as restrictive for update to public
using(bucket_id<>'myg-nube-sqlite') with check(bucket_id<>'myg-nube-sqlite');
drop policy if exists myg_sqlite_inmutable_delete on storage.objects;
create policy myg_sqlite_inmutable_delete on storage.objects as restrictive for delete to public
using(bucket_id<>'myg-nube-sqlite');

create or replace function myg_nube_privado.sqlite_validar_datos(
    p_id uuid,p_ruta text,p_sha256 text,p_bytes bigint,p_usuario uuid)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
begin
    if p_id is null or p_id='00000000-0000-0000-0000-000000000000'::uuid
       or p_sha256 is null or p_sha256 !~ '^[0-9a-f]{64}$'
       or p_bytes is null or p_bytes not between 512 and 314572800
       or p_ruta is distinct from p_usuario::text||'/'||replace(p_id::text,'-','')||'/'||p_sha256||'.sqlite' then
        raise exception using errcode='22023',message='MYG_ARCHIVO_SQLITE_INVALIDO';
    end if;
end $fn$;

create or replace function myg_nube_privado.sqlite_validar_objeto(
    p_id uuid,p_ruta text,p_sha256 text,p_bytes bigint,p_usuario uuid)
returns void language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare v_tamano text;
begin
    perform myg_nube_privado.sqlite_validar_datos(p_id,p_ruta,p_sha256,p_bytes,p_usuario);
    select metadata->>'size' into v_tamano from storage.objects
        where bucket_id='myg-nube-sqlite' and name=p_ruta;
    if v_tamano is null or v_tamano !~ '^[0-9]{1,10}$' or v_tamano::bigint<>p_bytes then
        raise exception using errcode='22023',message='MYG_ARCHIVO_SQLITE_NO_DISPONIBLE';
    end if;
    -- PostgreSQL no lee bytes de Storage ni interpreta SQLite: el cliente valida
    -- cabecera, integridad SQLite y SHA256 al preparar y descargar el archivo.
end $fn$;

create or replace function myg_nube_privado.sqlite_snapshot(p_id uuid,p_usuario uuid,p_revision bigint)
returns jsonb language sql stable security definer set search_path=pg_catalog as $fn$
    select jsonb_build_object('id',p.id,'codigo',p.codigo,'nombre',p.nombre,
        'rol',m.rol,'revision',r.revision,'alcance',p.alcance,'permisos_modulos',m.permisos_modulos,
        'documento_id',s.documento_id,'archivo_sqlite',jsonb_build_object('ruta',r.ruta,'sha256',r.sha256,'bytes',r.bytes))
    from public.myg_nube_proyectos p
    join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=p_usuario
    join myg_nube_privado.sqlite_proyectos s on s.proyecto_id=p.id
    join myg_nube_privado.sqlite_revisiones r on r.proyecto_id=p.id and r.revision=p_revision
    where p.id=p_id;
$fn$;

-- No basta un GUC editable por el cliente para autorizar el cambio de formato.
-- Solo las funciones privadas pueden insertar una revisión binaria y su tabla
-- privada debe concordar con la revisión y marcador del proyecto público.
create or replace function myg_nube_privado.sqlite_proteger_proyecto()
returns trigger language plpgsql security definer set search_path=pg_catalog as $fn$
declare v_nativo boolean; v_revision bigint;
begin
    select exists(select 1 from myg_nube_privado.sqlite_proyectos where proyecto_id=new.id) into v_nativo;
    if v_nativo or new.contenido->>'formato'='MYG_SQLITE' then
        select max(revision) into v_revision from myg_nube_privado.sqlite_revisiones where proyecto_id=new.id;
        if not v_nativo or new.revision is distinct from v_revision or new.es_comprimido
            or new.contenido is distinct from '{"formato":"MYG_SQLITE","version":1}'::jsonb then
            raise exception using errcode='MGS01',message='MYG_SQLITE_REQUIERE_CLIENTE_NATIVO';
        end if;
    end if;
    return new;
end $fn$;
drop trigger if exists myg_nube_sqlite_proteger on public.myg_nube_proyectos;
create trigger myg_nube_sqlite_proteger before insert or update on public.myg_nube_proyectos
for each row execute function myg_nube_privado.sqlite_proteger_proyecto();

-- Conservar la guarda GZip y añadir el formato nuevo sin transformar legados.
create or replace function myg_nube_privado.exigir_paquete_json(p_id uuid)
returns boolean language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    if exists(select 1 from myg_nube_privado.sqlite_proyectos s join public.myg_nube_miembros m
        on m.proyecto_id=s.proyecto_id and m.usuario_id=auth.uid() where s.proyecto_id=p_id) then
        raise exception using errcode='MGS01',message='MYG_SQLITE_REQUIERE_CLIENTE_NATIVO';
    end if;
    if exists(select 1 from public.myg_nube_proyectos p join public.myg_nube_miembros m
        on m.proyecto_id=p.id and m.usuario_id=auth.uid() where p.id=p_id and p.es_comprimido) then
        raise exception using errcode='MGC01',message='MYG_PAQUETE_COMPRIMIDO_REQUIERE_CLIENTE';
    end if;
    return true;
end $fn$;

create or replace function public.myg_nube_sqlite_capacidades()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    perform myg_nube_privado.identidad();
    return jsonb_build_object('version',1,'max_bytes',314572800);
end $fn$;

create or replace function public.myg_nube_sqlite_consultar(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_revision bigint;
begin
    select revision into v_revision from public.myg_nube_proyectos where id=p_id;
    if not found then return null; end if;
    if not exists(select 1 from public.myg_nube_miembros where proyecto_id=p_id and usuario_id=v_usuario) then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    return myg_nube_privado.sqlite_snapshot(p_id,v_usuario,v_revision);
end $fn$;

create or replace function public.myg_nube_sqlite_abrir(p_id uuid,p_revision bigint default null)
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_actual bigint; v_snapshot jsonb;
begin
    select p.revision into v_actual from public.myg_nube_proyectos p
        join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=v_usuario where p.id=p_id;
    if v_actual is null then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    v_snapshot:=myg_nube_privado.sqlite_snapshot(p_id,v_usuario,coalesce(p_revision,v_actual));
    if v_snapshot is null then raise exception using errcode='22023',message='MYG_REVISION_SQLITE_NO_DISPONIBLE'; end if;
    return v_snapshot;
end $fn$;

create or replace function public.myg_nube_sqlite_crear(p_id uuid,p_nombre text,p_alcance text,
    p_documento_id text,p_ruta text,p_sha256 text,p_bytes bigint)
returns jsonb language plpgsql security definer set search_path=pg_catalog
set statement_timeout='30s' as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_proyecto public.myg_nube_proyectos%rowtype;
    v_inicial myg_nube_privado.sqlite_revisiones%rowtype; v_documento text;
begin
    if p_id is null or p_id='00000000-0000-0000-0000-000000000000'::uuid
       or p_nombre is null or length(btrim(p_nombre)) not between 1 and 200
       or p_alcance is null or p_alcance not in ('obra','base')
       or p_documento_id is null or length(btrim(p_documento_id)) not between 1 and 200 then
        raise exception using errcode='22023',message='MYG_CREACION_SQLITE_INVALIDA';
    end if;
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-crear:'||p_id::text,0)) then
        raise exception using errcode='55006',message='MYG_PUBLICACION_EN_CURSO';
    end if;
    begin
        select * into v_proyecto from public.myg_nube_proyectos where id=p_id for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;
    if found then
        if v_proyecto.propietario<>v_usuario or not myg_nube_privado.sqlite_puede_escribir(p_id,v_usuario) then
            raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
        end if;
        select * into v_inicial from myg_nube_privado.sqlite_revisiones where proyecto_id=p_id and revision=1;
        select documento_id into v_documento from myg_nube_privado.sqlite_proyectos where proyecto_id=p_id;
        if v_inicial.proyecto_id is null or v_proyecto.nombre<>btrim(p_nombre) or v_proyecto.alcance<>p_alcance
           or v_documento<>btrim(p_documento_id) or v_inicial.ruta<>p_ruta
           or v_inicial.sha256<>p_sha256 or v_inicial.bytes<>p_bytes then
            raise exception using errcode='22023',message='MYG_ID_REUTILIZADO_CON_OTRA_CREACION';
        end if;
        return myg_nube_privado.sqlite_snapshot(p_id,v_usuario,1);
    end if;
    perform myg_nube_privado.sqlite_validar_objeto(p_id,p_ruta,p_sha256,p_bytes,v_usuario);
    insert into myg_nube_privado.sqlite_proyectos(proyecto_id,documento_id) values(p_id,btrim(p_documento_id));
    insert into myg_nube_privado.sqlite_revisiones(proyecto_id,revision,usuario_id,ruta,sha256,bytes)
        values(p_id,1,v_usuario,p_ruta,p_sha256,p_bytes);
    insert into public.myg_nube_proyectos(id,codigo,nombre,propietario,contenido,alcance,es_comprimido)
        values(p_id,'MYG-'||upper(replace(p_id::text,'-','')),btrim(p_nombre),v_usuario,
            '{"formato":"MYG_SQLITE","version":1}',p_alcance,false);
    insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values(p_id,v_usuario,'propietario');
    return myg_nube_privado.sqlite_snapshot(p_id,v_usuario,1);
end $fn$;

create or replace function public.myg_nube_sqlite_guardar(p_id uuid,p_operacion uuid,p_revision bigint,
    p_ruta text,p_sha256 text,p_bytes bigint)
returns jsonb language plpgsql security definer set search_path=pg_catalog
set statement_timeout='30s' as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_actual bigint; v_previa myg_nube_privado.sqlite_operaciones%rowtype;
    v_revision bigint; v_estado text; v_archivo jsonb; v_respuesta jsonb;
begin
    if p_operacion is null or p_operacion='00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision<1 or p_revision=9223372036854775807 then
        raise exception using errcode='22023',message='MYG_OPERACION_INVALIDA';
    end if;
    if not myg_nube_privado.sqlite_puede_escribir(p_id,v_usuario) then
        raise exception using errcode='42501',message='MYG_SQLITE_REQUIERE_EDICION_COMPLETA';
    end if;
    begin
        select revision into v_actual from public.myg_nube_proyectos where id=p_id for update nowait;
    exception when lock_not_available then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end;
    -- Misma fila/bloqueo que los RPC de roles: volver a revisar tras adquirirla.
    if v_actual is null or not myg_nube_privado.sqlite_puede_escribir(p_id,v_usuario) then
        raise exception using errcode='42501',message='MYG_SQLITE_REQUIERE_EDICION_COMPLETA';
    end if;
    if not exists(select 1 from myg_nube_privado.sqlite_proyectos where proyecto_id=p_id) then
        raise exception using errcode='22023',message='MYG_PROYECTO_NO_SQLITE';
    end if;
    if not pg_try_advisory_xact_lock(hashtextextended('myg-nube-op:'||v_usuario::text||':'||p_operacion::text,0)) then
        raise exception using errcode='55006',message='MYG_RECURSO_OCUPADO';
    end if;
    select * into v_previa from myg_nube_privado.sqlite_operaciones
        where usuario_id=v_usuario and operacion_id=p_operacion;
    if found then
        if v_previa.proyecto_id<>p_id or v_previa.revision_base<>p_revision or v_previa.ruta is distinct from p_ruta
           or v_previa.sha256 is distinct from p_sha256 or v_previa.bytes is distinct from p_bytes then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        v_estado:=v_previa.estado; v_revision:=v_previa.revision;
    else
        if exists(select 1 from public.myg_nube_operaciones where usuario_id=v_usuario and operacion_id=p_operacion) then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        perform myg_nube_privado.sqlite_validar_datos(p_id,p_ruta,p_sha256,p_bytes,v_usuario);
        v_revision:=v_actual;
        if v_actual<>p_revision then v_estado:='conflicto';
        else
            perform myg_nube_privado.sqlite_validar_objeto(p_id,p_ruta,p_sha256,p_bytes,v_usuario);
            v_estado:='aplicada'; v_revision:=v_actual+1;
            insert into myg_nube_privado.sqlite_revisiones(proyecto_id,revision,usuario_id,ruta,sha256,bytes)
                values(p_id,v_revision,v_usuario,p_ruta,p_sha256,p_bytes);
            update public.myg_nube_proyectos set revision=v_revision,actualizado_en=clock_timestamp() where id=p_id;
        end if;
        insert into myg_nube_privado.sqlite_operaciones(usuario_id,operacion_id,proyecto_id,revision_base,ruta,sha256,bytes,estado,revision)
            values(v_usuario,p_operacion,p_id,p_revision,p_ruta,p_sha256,p_bytes,v_estado,v_revision);
    end if;
    select jsonb_build_object('ruta',ruta,'sha256',sha256,'bytes',bytes) into v_archivo
        from myg_nube_privado.sqlite_revisiones where proyecto_id=p_id and revision=v_revision;
    v_respuesta:=jsonb_build_object('estado',v_estado,'revision',v_revision,'operacion_id',p_operacion,'archivo_sqlite',v_archivo);
    -- Compartir la reserva global de UUID con los RPC legados; sus clientes no
    -- pueden reutilizar después una operación nativa con otro cuerpo/proyecto.
    insert into public.myg_nube_operaciones(usuario_id,operacion_id,proyecto_id,solicitud,respuesta)
        values(v_usuario,p_operacion,p_id,jsonb_build_object('formato','MYG_SQLITE','revision',p_revision,
            'ruta',p_ruta,'sha256',p_sha256,'bytes',p_bytes),v_respuesta)
        on conflict(usuario_id,operacion_id) do nothing;
    return v_respuesta;
end $fn$;

revoke all on function myg_nube_privado.sqlite_validar_datos(uuid,text,text,bigint,uuid),
    myg_nube_privado.sqlite_validar_objeto(uuid,text,text,bigint,uuid),
    myg_nube_privado.sqlite_snapshot(uuid,uuid,bigint),myg_nube_privado.sqlite_proteger_proyecto()
    from public,anon,authenticated,service_role;
revoke all on function public.myg_nube_sqlite_capacidades(),public.myg_nube_sqlite_consultar(uuid),
    public.myg_nube_sqlite_abrir(uuid,bigint),public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint),
    public.myg_nube_sqlite_guardar(uuid,uuid,bigint,text,text,bigint) from public,anon;
grant execute on function public.myg_nube_sqlite_capacidades(),public.myg_nube_sqlite_consultar(uuid),
    public.myg_nube_sqlite_abrir(uuid,bigint),public.myg_nube_sqlite_crear(uuid,text,text,text,text,text,bigint),
    public.myg_nube_sqlite_guardar(uuid,uuid,bigint,text,text,bigint) to authenticated,service_role;
notify pgrst,'reload schema';
commit;
