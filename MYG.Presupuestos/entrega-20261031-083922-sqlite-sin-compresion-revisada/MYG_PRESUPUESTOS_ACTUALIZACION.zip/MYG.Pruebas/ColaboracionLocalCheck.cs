using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class ColaboracionLocalCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Colaboración local: " + mensaje); }

    private static void Rechaza(Action accion, string mensaje)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (InvalidOperationException) { return; }
        catch (ArgumentException) { return; }
        catch (SqliteException) { return; }
        throw new Exception("Colaboración local aceptó " + mensaje);
    }

    private static MYGVinculoNube Vinculo(MYGProyectoDocumento documento) => new()
    {
        ProyectoId = Guid.NewGuid(), Servidor = "https://prueba.supabase.co/", UsuarioId = "usuario-a", Rol = "editor",
        Revision = 1, JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento)
    };

    private static string NombreEnOperacion(MYGOperacionNube operacion)
    {
        using var json = JsonDocument.Parse(operacion.JsonContenido);
        return MYGColaboracionLocal.ImportarDocumento(json.RootElement.GetProperty("documento").GetRawText()).Nombre;
    }

    private static SqliteConnection Conexion(string ruta)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false, ForeignKeys = true }.ToString());
        c.Open(); return c;
    }

    private static void Sql(string ruta, string sql)
    { using var c = Conexion(ruta); using var cmd = c.CreateCommand(); cmd.CommandText = sql; cmd.ExecuteNonQuery(); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Colaboración con varias obras.sqlite");
        var documento = MYGProyectoStorage.Nuevo("OBRA ORIGINAL", "ESTRUCTURAS");
        documento.Datos = new MYGDatosProyecto { Propietario = "Municipalidad", TipoObra = "Edificaciones", HechoPor = "Equipo MYG" };
        var partida = new ItemPresupuestoDelphin
        {
            Descripcion = "CONCRETO", Unidad = "m³", TipoPropuesta = "PARTIDA", Posicion = 1,
            Id = MYGProyectoStorage.NuevoId(), IdLocalMYG = MYGProyectoStorage.NuevoId()
        };
        partida.Costos.Cantidad = 123.4567m;
        partida.Costos.EspecificacionRtf = @"{\rtf1 Especificación completa}";
        partida.Filtros.Add(new FiltroPlanificacion { Parametro = "Nivel", Regla = "igual", Valor = "PISO 01" });
        documento.Presupuestos[0].Items.Add(partida);
        documento.Presupuestos.Add(new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 });
        documento.Cronograma = new MYGCronograma { FechaInicio = new DateTime(2026, 10, 19) };
        documento.Cronograma.Tareas.Add(new MYGTareaCronograma { Id = "TAREA", Nombre = "Concreto", DuracionDias = 3 });
        string jsonCompleto = MYGColaboracionLocal.ExportarDocumento(documento);
        var importado = MYGColaboracionLocal.ImportarDocumento(jsonCompleto);
        Exige(MYGColaboracionLocal.ExportarDocumento(importado) == jsonCompleto &&
            importado.Presupuestos[0].Items[0].Costos.Cantidad == 123.4567m &&
            importado.Cronograma.Tareas.Single().DuracionDias == 3 &&
            importado.Presupuestos[0].Items[0].Costos.EspecificacionRtf == partida.Costos.EspecificacionRtf,
            "exportar/importar perdió datos, decimales, especificaciones o cronograma.");
        Rechaza(() => MYGColaboracionLocal.ImportarDocumento("{}"), "documento sin formato y contenido.");
        Rechaza(() => MYGColaboracionLocal.ImportarDocumento("{\"Nombre\":\"incompleto\"}"),
            "crear identidades nuevas al importar un fragmento incompleto.");
        pasa("Documento de nube conserva obra completa, decimales, filtros BIM, especificaciones y cronograma con validación");

        var otra = MYGProyectoStorage.Nuevo("OTRA OBRA");
        MYGBaseDatos.GuardarProyecto(ruta, otra);
        MYGCatalogosProyecto.Guardar(ruta, MYGCatalogoProyecto.Propietarios, "Municipalidad");
        var vinculo = Vinculo(documento);
        MYGColaboracionLocal.Vincular(ruta, documento, vinculo);
        Exige(vinculo.Pendiente == null && vinculo.Estado == "Sincronizado" &&
            MYGColaboracionLocal.Leer(ruta, otra.Id) == null &&
            MYGColaboracionLocal.BuscarProyectoLocal(ruta, vinculo.Servidor, vinculo.ProyectoId, vinculo.UsuarioId) == documento.Id &&
            MYGColaboracionLocal.BuscarProyectoLocal(ruta, vinculo.Servidor, vinculo.ProyectoId, "otro") == null,
            "vincular generó una edición inexistente o confundió identidades de obra.");

        documento.Nombre = "PRIMER CAMBIO";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        Guid idEnVuelo = vinculo.Pendiente.Id;
        string cuerpoInicial = vinculo.Pendiente.JsonContenido;
        using var contenido = JsonDocument.Parse(cuerpoInicial);
        string enriquecido = "{\"documento\":" + contenido.RootElement.GetProperty("documento").GetRawText() +
            ",\"base\":{\"sha256\":\"fijo\"},\"recursos\":[{\"ruta\":\"adjunto\"}]}";
        MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, enriquecido);
        documento.Nombre = "SEGUNDO CAMBIO DURANTE ENVÍO";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        var reabierto = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exige(reabierto.Pendiente.Id == idEnVuelo && reabierto.Pendiente.JsonContenido == enriquecido &&
            reabierto.Pendiente.Enviada &&
            MYGColaboracionLocal.ImportarDocumento(reabierto.JsonBorrador).Nombre == documento.Nombre &&
            MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == documento.Nombre,
            "cerrar/reabrir perdió el cuerpo exacto del envío o el borrador siguiente.");
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT json_vinculo FROM myg_colaboracion_local WHERE proyecto_local_id=$id";
            cmd.Parameters.AddWithValue("$id", documento.Id);
            string guardado = (string)cmd.ExecuteScalar();
            Exige(System.Text.Encoding.UTF8.GetByteCount(guardado)
                < JsonSerializer.SerializeToUtf8Bytes(reabierto).Length * 0.8,
                "la cola duradera volvió a multiplicar los escapes de los paquetes y borradores.");
            using var estadoGuardado = JsonDocument.Parse(guardado);
            Exige(estadoGuardado.RootElement.GetProperty("Pendiente").GetProperty("JsonContenido").GetString() == enriquecido,
                "optimizar el contenedor de la cola alteró el cuerpo exacto ya enviado.");
        }
        Rechaza(() => MYGColaboracionLocal.PrepararEnvio(ruta, documento, reabierto, cuerpoInicial),
            "cambiar el cuerpo de un envío con respuesta perdida.");
        pasa("Cola sobrevive reapertura y conserva UUID/cuerpo del paquete enviado mientras guarda nuevas ediciones por separado");

        MYGColaboracionLocal.Confirmar(ruta, documento, reabierto, idEnVuelo, 2);
        Exige(reabierto.Revision == 2 && reabierto.Pendiente != null && reabierto.Pendiente.Id != idEnVuelo &&
            reabierto.Pendiente.RevisionBase == 2 && !reabierto.Pendiente.Enviada &&
            NombreEnOperacion(reabierto.Pendiente) == documento.Nombre &&
            MYGColaboracionLocal.ImportarDocumento(reabierto.JsonConfirmado).Nombre == "PRIMER CAMBIO",
            "confirmar no separó el documento enviado del siguiente borrador.");
        Guid siguiente = reabierto.Pendiente.Id;
        Rechaza(() => MYGColaboracionLocal.Confirmar(ruta, documento, reabierto, idEnVuelo, 3), "ACK de otra operación.");
        Exige(MYGColaboracionLocal.Leer(ruta, documento.Id).Pendiente.Id == siguiente,
            "un ACK ajeno alteró la cola.");
        MYGColaboracionLocal.Confirmar(ruta, documento, reabierto, siguiente, 3);
        Exige(reabierto.Pendiente == null && reabierto.Estado == "Sincronizado", "confirmar última edición dejó una operación artificial.");
        pasa("ACK valida identidad y revisión, confirma sólo lo enviado y prepara una nueva operación para el borrador posterior");

        reabierto.Rol = "lector";
        documento.PresupuestoActivoId = documento.Presupuestos[1].Id;
        documento.ModificadoUtc = DateTime.UtcNow;
        MYGColaboracionLocal.Guardar(ruta, documento, reabierto);
        var edicionLector = MYGProyectoStorage.Copia(documento); edicionLector.Nombre = "CAMBIO SIN PERMISO";
        Rechaza(() => MYGColaboracionLocal.Guardar(ruta, edicionLector, reabierto), "crear edición de nube con rol lector.");
        Exige(reabierto.Pendiente == null && MYGColaboracionLocal.Leer(ruta, documento.Id).Pendiente == null,
            "el lector generó una operación silenciosa.");
        reabierto.Rol = "editor";
        MYGColaboracionLocal.Guardar(ruta, documento, reabierto);
        pasa("Rol lector permite navegar entre presupuestos sin generar pendientes y rechaza cambios locales nuevos");

        // El guardado histórico del editor también participa en la misma cola.
        documento.Nombre = "GUARDADO NORMAL";
        MYGProyectoStorage.Guardar(ruta, documento);
        var normal = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exige(normal.Pendiente != null && NombreEnOperacion(normal.Pendiente) == documento.Nombre,
            "el guardado habitual no preparó la cola.");
        var ventanaVieja = MYGColaboracionLocal.Leer(ruta, documento.Id);
        documento.Nombre = "VENTANA ACTUAL";
        MYGColaboracionLocal.Guardar(ruta, documento, normal);
        Guid pendienteAntesLector = normal.Pendiente.Id;
        string cuerpoAntesLector = normal.Pendiente.JsonContenido;
        normal.Rol = "lector";
        MYGColaboracionLocal.Guardar(ruta, documento, normal);
        Exige(normal.Pendiente.Id == pendienteAntesLector && normal.Pendiente.JsonContenido == cuerpoAntesLector,
            "perder permiso de edición descartó o regeneró la cola anterior.");
        normal.Rol = "editor";
        MYGColaboracionLocal.Guardar(ruta, documento, normal);
        var documentoViejo = MYGProyectoStorage.Copia(documento);
        documentoViejo.Nombre = "VENTANA OBSOLETA";
        Rechaza(() => MYGColaboracionLocal.Guardar(ruta, documentoViejo, ventanaVieja), "guardado con vínculo obsoleto de otra ventana.");
        Exige(MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == "VENTANA ACTUAL" &&
            MYGBaseDatos.LeerProyecto(ruta, otra.Id).Nombre == otra.Nombre,
            "rechazar la ventana obsoleta alteró la obra o una obra vecina.");
        pasa("Guardar habitual actualiza cola atómicamente y rechaza una ventana obsoleta sin pisar documentos ni otras obras");

        normal.EstadoConexion = "sin conexión";
        documento.Nombre = "EDICIÓN LOCAL SIN CONEXIÓN";
        MYGColaboracionLocal.Guardar(ruta, documento, normal);
        Exige(MYGColaboracionLocal.Leer(ruta, documento.Id).EstadoConexion == "sin conexión" &&
            normal.Estado == "Pendiente" && normal.Pendiente.Id == pendienteAntesLector &&
            normal.Pendiente.JsonContenido == cuerpoAntesLector,
            "editar sin red perdió el estado de conexión o regeneró la operación anterior.");
        normal.EstadoConexion = "acceso retirado";
        MYGColaboracionLocal.Guardar(ruta, documento, normal);
        var sinAcceso = MYGProyectoStorage.Copia(documento); sinAcceso.Nombre = "EDICIÓN CON ACCESO RETIRADO";
        Rechaza(() => MYGColaboracionLocal.Guardar(ruta, sinAcceso, normal), "editar una copia con acceso retirado.");
        Exige(MYGColaboracionLocal.Leer(ruta, documento.Id).EstadoConexion == "acceso retirado" &&
            normal.Pendiente.Id == pendienteAntesLector, "reabrir descartó la revocación o sus pendientes previos.");
        normal.EstadoConexion = null;
        MYGColaboracionLocal.Guardar(ruta, documento, normal);
        pasa("Estado de conexión se conserva independiente de la cola: permite editar sin red y bloquea ediciones tras revocación");

        var impostor = MYGColaboracionLocal.Leer(ruta, documento.Id);
        impostor.UsuarioId = "otro-usuario";
        Rechaza(() => MYGColaboracionLocal.Guardar(ruta, documentoViejo, impostor), "reutilizar cola bajo otro usuario.");
        impostor = MYGColaboracionLocal.Leer(ruta, documento.Id); impostor.Servidor = "https://otro.supabase.co";
        Rechaza(() => MYGColaboracionLocal.Guardar(ruta, documentoViejo, impostor), "reutilizar cola con otro servidor.");
        impostor = MYGColaboracionLocal.Leer(ruta, documento.Id); impostor.ProyectoId = Guid.NewGuid();
        Rechaza(() => MYGColaboracionLocal.Guardar(ruta, documentoViejo, impostor), "reutilizar cola en otra obra remota.");
        var duplicado = Vinculo(otra);
        duplicado.ProyectoId = normal.ProyectoId; duplicado.Servidor = normal.Servidor;
        Rechaza(() => MYGColaboracionLocal.Vincular(ruta, otra, duplicado), "duplicar identidad remota en otra obra local.");
        Exige(MYGColaboracionLocal.Leer(ruta, otra.Id) == null, "una identidad duplicada dejó metadatos parciales.");
        pasa("Vínculo aísla proyecto, usuario y servidor, y su restricción única impide reciclar identidades remotas en otras obras");

        // Un fallo en la última escritura de metadatos revierte también todas
        // las tablas nativas y el documento escritos antes en la transacción.
        Sql(ruta, "CREATE TRIGGER prueba_fallo_nube BEFORE UPDATE ON myg_colaboracion_local BEGIN SELECT RAISE(ABORT,'fallo simulado'); END;");
        var fallido = MYGProyectoStorage.Copia(documento); fallido.Nombre = "NUNCA CONFIRMADO";
        string borradorAntes = normal.JsonBorrador;
        Rechaza(() => MYGColaboracionLocal.Guardar(ruta, fallido, normal, (c, t) =>
        {
            using var cmd = c.CreateCommand(); cmd.Transaction = t;
            cmd.CommandText = "CREATE TABLE prueba_dependencia_no_confirmada(id TEXT);"; cmd.ExecuteNonQuery();
        }), "guardar documento si falla su cola.");
        Exige(MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == documento.Nombre &&
            MYGColaboracionLocal.Leer(ruta, documento.Id).JsonBorrador == borradorAntes &&
            normal.JsonBorrador == borradorAntes,
            "el fallo dejó el documento, la cola o el objeto en memoria a medio guardar.");
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='prueba_dependencia_no_confirmada'";
            Exige(Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) == 0,
                "el fallo confirmó una dependencia importada antes de escribir el documento.");
        }
        Sql(ruta, "DROP TRIGGER prueba_fallo_nube;");
        pasa("Fallo SQL al guardar metadatos revierte documento, tablas y cola en una sola transacción sin mutar el vínculo del llamador");

        var remoto = MYGProyectoStorage.Copia(documento); remoto.Nombre = "EDICIÓN REMOTA";
        normal.JsonPaqueteConflicto = "{\"recursos\":[\"imagen-remota\"]}";
        MYGColaboracionLocal.RegistrarConflicto(ruta, documento, normal, 9, MYGColaboracionLocal.ExportarDocumento(remoto));
        var conflicto = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exige(conflicto.Estado == "Conflicto" && conflicto.Pendiente.Id == normal.Pendiente.Id &&
            conflicto.Pendiente.JsonContenido == normal.Pendiente.JsonContenido && conflicto.RevisionRemotaConflicto == 9 &&
            conflicto.JsonPaqueteConflicto.Contains("imagen-remota", StringComparison.Ordinal) &&
            MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == documento.Nombre,
            "registrar/reabrir conflicto reemplazó el documento local o perdió paquete y cola.");
        Guid anteriorConflicto = conflicto.Pendiente.Id;
        MYGColaboracionLocal.ResolverConflictoMantenerLocal(ruta, documento, conflicto);
        Exige(conflicto.Revision == 9 && conflicto.Pendiente.Id != anteriorConflicto &&
            conflicto.Pendiente.RevisionBase == 9 && conflicto.JsonRemotoConflicto == null &&
            conflicto.JsonPaqueteConfirmado.Contains("imagen-remota", StringComparison.Ordinal),
            "resolver manteniendo local no produjo UUID/base nuevos o perdió recursos remotos.");
        pasa("Conflicto conserva ambas versiones y paquete al reabrir; aceptar versión local crea operación nueva contra la revisión remota");

        remoto.Nombre = "REMOTO ACEPTADO";
        MYGColaboracionLocal.RegistrarConflicto(ruta, documento, conflicto, 10, MYGColaboracionLocal.ExportarDocumento(remoto));
        var aceptado = MYGColaboracionLocal.ResolverConflictoUsarRemoto(ruta, conflicto);
        Exige(aceptado.Nombre == remoto.Nombre && conflicto.Pendiente == null && conflicto.Revision == 10 &&
            MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == remoto.Nombre &&
            MYGBaseDatos.LeerProyecto(ruta, otra.Id).Nombre == otra.Nombre,
            "aceptar remoto no guardó su documento y metadatos juntos, o alteró otra obra.");
        pasa("Aceptar conflicto remoto reemplaza sólo la obra seleccionada y limpia la cola con guardado atómico");

        var nuevoCatalogo = MYGProyectoStorage.Copia(aceptado);
        nuevoCatalogo.Datos.PropietarioId = "PR9999999999";
        nuevoCatalogo.Datos.Propietario = "Municipalidad nueva remota";
        conflicto.Revision = 11;
        conflicto.JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(nuevoCatalogo);
        MYGColaboracionLocal.Guardar(ruta, nuevoCatalogo, conflicto, (c, t) =>
        {
            using var cmd = c.CreateCommand(); cmd.Transaction = t;
            cmd.CommandText = "INSERT INTO propietario(id_propietario,nombre_propietario) VALUES('PR9999999999','Municipalidad nueva remota')";
            cmd.ExecuteNonQuery();
        });
        aceptado = nuevoCatalogo;
        Exige(MYGBaseDatos.LeerProyecto(ruta, documento.Id).Datos.PropietarioId == "PR9999999999" &&
            MYGColaboracionLocal.Leer(ruta, documento.Id).Revision == 11 &&
            MYGCatalogosProyecto.Listar(ruta, MYGCatalogoProyecto.Propietarios).Any(p => p.Id == "PR9999999999") &&
            MYGBaseDatos.LeerProyecto(ruta, otra.Id).Nombre == otra.Nombre,
            "el pull no importó la dependencia antes del documento en su misma transacción.");
        pasa("Pull importa dependencias de catálogo antes del documento con la misma conexión y transacción, conservando otras obras");

        string copiaRuta = Path.Combine(carpeta, "Copia independiente nube.sqlite");
        MYGBaseDatos.GuardarProyecto(copiaRuta, aceptado, ruta);
        Exige(MYGBaseDatos.ListarProyectos(copiaRuta).Count == 2 &&
            MYGColaboracionLocal.Leer(copiaRuta, aceptado.Id) == null &&
            MYGColaboracionLocal.Leer(ruta, aceptado.Id) != null,
            "Guardar como copió vínculo de nube, perdió otra obra o desvinculó el origen.");
        using (var c = Conexion(copiaRuta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "PRAGMA integrity_check";
            Exige((string)cmd.ExecuteScalar() == "ok", "la copia independiente no supera integrity_check.");
            cmd.CommandText = "PRAGMA foreign_key_check";
            using var lector = cmd.ExecuteReader();
            Exige(!lector.Read(), "la copia independiente contiene relaciones rotas.");
        }
        MYGColaboracionLocal.Desvincular(ruta, aceptado.Id);
        Exige(MYGColaboracionLocal.Leer(ruta, aceptado.Id) == null &&
            MYGBaseDatos.LeerProyecto(ruta, aceptado.Id).Nombre == aceptado.Nombre,
            "desvincular borró el documento de obra.");
        pasa("Guardar como crea hoja independiente sin tabla de nube y conserva obras y origen; desvincular conserva contenido local");
        ComprobarCambiosSinEdicionDocumento(carpeta, pasa);
        ComprobarConfirmacionSinReescritura(carpeta, pasa);
    }

    private static void ComprobarConfirmacionSinReescritura(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Confirmación sin reescribir presupuestos.sqlite");
        var documento = MYGProyectoStorage.Nuevo("Confirmación inicial");
        documento.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), IdLocalMYG = MYGProyectoStorage.NuevoId(),
            Descripcion = "Partida conservada", Unidad = "m2", TipoPropuesta = "PARTIDA", Posicion = 1
        });
        var vinculo = Vinculo(documento);
        MYGColaboracionLocal.Vincular(ruta, documento, vinculo);
        documento.Nombre = "Cambio enviado";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, vinculo.Pendiente.JsonContenido);
        Sql(ruta, """
            CREATE TABLE qa_escrituras_nativas(n INTEGER);
            CREATE TRIGGER qa_confirmacion_partida AFTER INSERT ON partida_presupuesto
                BEGIN INSERT INTO qa_escrituras_nativas VALUES(1); END;
            CREATE TRIGGER qa_confirmacion_proyecto AFTER UPDATE ON myg_proyecto
                BEGIN INSERT INTO qa_escrituras_nativas VALUES(1); END;
            """);
        MYGColaboracionLocal.Confirmar(ruta, documento, vinculo, vinculo.Pendiente.Id, 2);
        Exige(ContarEscrituras() == 0 && vinculo.Revision == 2 && vinculo.Pendiente == null
            && MYGColaboracionLocal.Leer(ruta, documento.Id).Revision == 2
            && MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == documento.Nombre,
            "confirmar un documento ya guardado reescribió presupuestos o no dejó el ACK durable.");
        pasa("ACK del documento ya guardado confirma sólo metadatos sin reescribir proyecto ni partidas nativas");

        documento.Nombre = "Segundo cambio enviado";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, vinculo.Pendiente.JsonContenido);
        Guid operacion = vinculo.Pendiente.Id;
        Sql(ruta, "DELETE FROM qa_escrituras_nativas; CREATE TRIGGER qa_rechazar_ack BEFORE UPDATE ON myg_colaboracion_local BEGIN SELECT RAISE(ABORT,'fallo ACK'); END;");
        Rechaza(() => MYGColaboracionLocal.Confirmar(ruta, documento, vinculo, operacion, 3), "confirmación SQL fallida.");
        var durable = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exige(vinculo.Revision == 2 && vinculo.Pendiente.Id == operacion && durable.Revision == 2
            && durable.Pendiente.Id == operacion && ContarEscrituras() == 0,
            "un fallo del ACK cambió la cola en memoria, confirmó la revisión o reescribió presupuestos.");
        Sql(ruta, "DROP TRIGGER qa_rechazar_ack;");
        var obsoleto = MYGColaboracionLocal.Leer(ruta, documento.Id);
        vinculo.EstadoConexion = "sin conexión";
        MYGColaboracionLocal.Guardar(ruta, documento, vinculo);
        Rechaza(() => MYGColaboracionLocal.Confirmar(ruta, documento, obsoleto, operacion, 3), "ACK con cola obsoleta.");
        Exige(MYGColaboracionLocal.Leer(ruta, documento.Id).Revision == 2 && obsoleto.Pendiente.Id == operacion,
            "la confirmación de sólo metadatos ignoró el control de concurrencia.");
        pasa("Confirmación de sólo metadatos conserva cola y revisión ante fallo SQL o una ventana obsoleta");

        documento.Nombre = "Borrador posterior todavía sin guardar";
        Sql(ruta, "DELETE FROM qa_escrituras_nativas;");
        MYGColaboracionLocal.Confirmar(ruta, documento, vinculo, operacion, 3);
        durable = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exige(ContarEscrituras() > 0 && durable.Revision == 3 && durable.Pendiente != null
            && durable.Pendiente.Id != operacion && durable.Pendiente.RevisionBase == 3
            && MYGBaseDatos.LeerProyecto(ruta, documento.Id).Nombre == documento.Nombre,
            "confirmar sin reescritura descartó un borrador posterior aún no guardado.");
        pasa("ACK con edición posterior sin guardar mantiene el guardado completo atómico y prepara la siguiente operación");

        Sql(ruta, "DELETE FROM qa_escrituras_nativas;");
        MYGColaboracionLocal.Confirmar(ruta, documento, durable, durable.Pendiente.Id, 4,
            prepararDependencias: (c, t) =>
            {
                using var cmd = c.CreateCommand(); cmd.Transaction = t;
                cmd.CommandText = "CREATE TABLE qa_dependencia_ack(id INTEGER); INSERT INTO qa_dependencia_ack VALUES(1);";
                cmd.ExecuteNonQuery();
            });
        Exige(ContarEscrituras() > 0 && MYGColaboracionLocal.Leer(ruta, documento.Id).Revision == 4,
            "el ACK omitió el guardado completo cuando debía incorporar dependencias.");
        using (var c = Conexion(ruta))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT count(*) FROM qa_dependencia_ack";
            Exige(Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) == 1,
                "la confirmación no incorporó las dependencias solicitadas.");
        }
        pasa("ACK con dependencias explícitas mantiene la ruta de documento y metadatos en la misma transacción");

        long ContarEscrituras()
        {
            using var c = Conexion(ruta);
            using var cmd = c.CreateCommand();
            cmd.CommandText = "SELECT count(*) FROM qa_escrituras_nativas";
            return Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture);
        }
    }

    private static void ComprobarCambiosSinEdicionDocumento(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Colaboración sólo datos nativos.sqlite");
        var documento = MYGProyectoStorage.Nuevo("OBRA CON NUEVOS CATÁLOGOS");
        var vinculo = Vinculo(documento);
        MYGColaboracionLocal.Vincular(ruta, documento, vinculo);
        string paquete = "{\"documento\":" + MYGColaboracionLocal.ExportarDocumento(documento) +
            ",\"nativo\":{\"indice\":42}}";
        var operacion = MYGColaboracionLocal.PrepararCambioContenido(ruta, documento, vinculo, paquete);
        Exige(operacion != null && operacion.RevisionBase == 1 && !operacion.Enviada &&
            operacion.JsonContenido == paquete && vinculo.Estado == "Pendiente",
            "un cambio de paquete sin edición del documento no quedó encolado.");
        string alterado = paquete.Replace("42", "43", StringComparison.Ordinal);
        var conservada = MYGColaboracionLocal.PrepararCambioContenido(ruta, documento, vinculo, alterado);
        Exige(conservada.Id == operacion.Id && conservada.JsonContenido == paquete,
            "un nuevo cambio nativo reemplazó la operación pendiente anterior.");
        MYGColaboracionLocal.PrepararEnvio(ruta, documento, vinculo, paquete);
        vinculo = MYGColaboracionLocal.Leer(ruta, documento.Id);
        Exige(vinculo.Pendiente.Id == operacion.Id && vinculo.Pendiente.JsonContenido == paquete && vinculo.Pendiente.Enviada,
            "cerrar y reabrir perdió un envío de sólo datos nativos.");
        vinculo.JsonPaqueteConfirmado = paquete;
        MYGColaboracionLocal.Confirmar(ruta, documento, vinculo, operacion.Id, 2);
        Exige(vinculo.Pendiente == null && MYGColaboracionLocal.Leer(ruta, documento.Id).JsonPaqueteConfirmado == paquete,
            "confirmar el paquete sin cambios de documento lo dejó pendiente o perdió su contenido.");
        pasa("Cambios de paquete sin editar JSON de obra tienen operación durable propia, preservan cola anterior y se confirman sin pendientes artificiales");
    }
}
