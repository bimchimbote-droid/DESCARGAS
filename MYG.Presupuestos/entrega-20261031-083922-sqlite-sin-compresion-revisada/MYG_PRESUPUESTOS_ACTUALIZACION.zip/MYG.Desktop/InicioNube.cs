#nullable enable
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private ClienteSupabase? clienteNube;
    private NubeForm? ventanaNube;
    private bool clienteNubePreparado;
    private ConfiguracionNube? configuracionNube;
    private string? errorConfiguracionNube;
    private string? usuarioNube;
    private long generacionNube;
    private readonly System.Threading.SemaphoreSlim ingresoNube = new(1, 1);
    private static string CarpetaNube => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "trabajo");

    // Conservar el callback Action de los editores; IntentarAsync controla los
    // errores y las aperturas repetidas antes del primer await.
    private void MostrarNube() => _ = IntentarAsync(MostrarNubeAsync);

    private async Task MostrarNubeAsync()
    {
        RequerirSesion();
        if (!clienteNubePreparado)
        {
            try
            {
                configuracionNube = NubeConfiguracion.Cargar();
                errorConfiguracionNube = null;
            }
            catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or NubeException)
            {
                // Conservar el archivo y el destino previo: no sustituirlo por
                // otra conexión si está dañado. Su recuperación corresponde a soporte.
                configuracionNube = null;
                errorConfiguracionNube = "No se pudo leer la conexión guardada de Nube MYG. Solicite a soporte que revise la instalación. No se cambió el servidor de sus obras.";
            }
            clienteNubePreparado = true;
        }
        ActualizarSesionNube();
        bool nuevaVentana = ventanaNube is null || ventanaNube.IsDisposed;
        if (nuevaVentana)
        {
            ventanaNube = new NubeForm(sesion, clienteNube);
            ventanaNube.AbrirSolicitado += AbrirProyectoNube;
            ventanaNube.PublicarSolicitado += PublicarProyectoNube;
            ventanaNube.PendientesSolicitado += GestionarPublicacionesPendientesNube;
            ventanaNube.DescargarSolicitado += DescargarProyectoNube;
            ventanaNube.ConectarMygSolicitado += ConectarNubeConMygAsync;
        }
        var ventana = ventanaNube!;
        if (ventana.OperacionEnCurso)
        {
            ventana.Activate();
            return;
        }
        ventana.InformarErrorConfiguracion(errorConfiguracionNube);
        ventana.Hide();
        var clienteApertura = clienteNube;
        try
        {
            await MYGCargaAnimada.EjecutarAsync(this, "Conectando…", ventana.ConectarYRefrescarAsync);
            if (IsDisposed || Disposing || ventana.IsDisposed || ventana.Disposing) return;
            ComprobarClienteActual(clienteApertura!);
            ventana.Show(this); ventana.Activate();
        }
        catch
        {
            // El error se presenta sobre Inicio, una vez cerrada la carga.
            // No dejar una ventana nueva suscrita a la sesión tras fallar.
            if (nuevaVentana)
            {
                ventana.Dispose();
                if (ReferenceEquals(ventanaNube, ventana)) ventanaNube = null;
            }
            throw;
        }
    }

    private string? UsuarioMygActual => sesion.Autorizado
        ? sesion.Credencial?.Usuario?.Trim().ToLowerInvariant() : null;

    private void ActualizarSesionNube()
    {
        if (!clienteNubePreparado) return;
        string? usuario = UsuarioMygActual;
        if (usuario == usuarioNube && (clienteNube is not null || configuracionNube is null || usuario is null)) return;
        generacionNube++;
        var anterior = clienteNube;
        clienteNube = usuario is not null ? configuracionNube?.CrearCliente() : null;
        usuarioNube = usuario;
        // Cancelar y eliminar solo la sesión local anterior; nunca cerrar otras computadoras.
        anterior?.Dispose();
        ventanaNube?.ActualizarCliente(clienteNube);
    }

    private async Task ConectarNubeConMygAsync()
    {
        await ingresoNube.WaitAsync();
        try
        {
            if (IsDisposed || Disposing) return;
            RequerirSesion(); ActualizarSesionNube();
            var cliente = clienteNube ?? throw new InvalidOperationException("No se encontró la conexión de Nube MYG. Solicite a soporte que revise la instalación.");
            string usuario = UsuarioMygActual ?? throw new InvalidOperationException("Inicie sesión en MYG.");
            if (cliente.SesionIniciada && cliente.UsuarioMygSesion == usuario) return;
            long generacion = generacionNube;
            var resultado = await sesion.ObtenerTicketNubeAsync(cliente.UrlServidor);
            if (!resultado.Ok || resultado.Ticket is null) throw new InvalidOperationException(resultado.Mensaje);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            await cliente.IniciarSesionMygAsync(resultado.Ticket);
            if (generacion != generacionNube || UsuarioMygActual != usuario || IsDisposed)
            {
                cliente.Dispose();
                throw new OperationCanceledException("Cambió la sesión MYG. Vuelva a abrir Nube MYG.");
            }
            ventanaNube?.ActualizarCliente(cliente);
        }
        finally { ingresoNube.Release(); }
    }

    private void ComprobarClienteActual(ClienteSupabase cliente)
    {
        RequerirSesion();
        if (!ReferenceEquals(clienteNube, cliente) || !cliente.SesionIniciada || cliente.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Cambió la sesión MYG durante la operación. Vuelva a abrir Nube MYG.");
    }

    private ClienteSupabase RequerirNube()
    {
        RequerirSesion();
        if (clienteNube?.SesionIniciada != true || clienteNube.UsuarioMygSesion != UsuarioMygActual)
            throw new InvalidOperationException("Abra Nube MYG para conectar con su usuario MYG actual.");
        return clienteNube;
    }

    private static string CarpetaDeProyectoNube(ClienteSupabase cliente, Guid proyecto)
    {
        string servidor = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(cliente.UrlServidor)))[..24];
        if (!Guid.TryParse(cliente.UsuarioId, out var usuario)) throw new InvalidOperationException("La identidad de nube no es válida.");
        return Path.Combine(CarpetaNube, servidor, usuario.ToString("N"), proyecto.ToString("N"));
    }

    private async Task AbrirProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        Guid proyectoId = seleccionado.Id;
        string servidor = cliente.UrlServidor, usuario = cliente.UsuarioId!;
        var sqlite = await Task.Run(() => cliente.ConsultarSqliteAsync(proyectoId));
        ComprobarClienteActual(cliente);
        if (sqlite is not null)
        {
            await AbrirProyectoSqliteNube(cliente, sqlite);
            return;
        }
        var remoto = await Task.Run(() => cliente.AbrirProyectoAsync(proyectoId));
        ComprobarClienteActual(cliente);
        JsonElement contenido = remoto.Contenido;
        var contenidoCargado = await Task.Run(() => cliente.CargarArchivosAsync(contenido));
        ComprobarClienteActual(cliente);
        remoto = remoto with { Contenido = contenidoCargado };
        var existente = EditoresAbiertos.FirstOrDefault(e => e.NubeProyectoId == remoto.Id
            && string.Equals(e.NubeServidor?.TrimEnd('/'), servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase)
            && e.NubeUsuario == usuario);
        if (existente is not null)
        {
            await existente.ActualizarNubeAsync(true);
            ComprobarClienteActual(cliente);
            SeleccionarEditor(existente); ventanaNube?.Hide(); return;
        }
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Id);
        string ruta = Path.Combine(carpeta, "trabajo.sqlite");
        var original = await Task.Run(() => PaqueteNube.LeerDocumento(contenidoCargado));
        ComprobarClienteActual(cliente);
        MYGProyectoDocumento documento;
        if (File.Exists(ruta))
        {
            var recuperado = await Task.Run(() =>
            {
                var local = MYGBaseDatos.LeerProyecto(ruta, original.Id);
                var vinculoLocal = MYGColaboracionLocal.Leer(ruta, local.Id)
                    ?? throw new InvalidOperationException("La copia existente no tiene un vínculo válido. Consérvela antes de recuperar otra copia.");
                return (Documento: local, Vinculo: vinculoLocal);
            });
            ComprobarClienteActual(cliente);
            documento = recuperado.Documento;
            var vinculo = recuperado.Vinculo;
            SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
            if (vinculo.ProyectoId != remoto.Id) throw new InvalidOperationException("La copia corresponde a otro proyecto remoto.");
            SincronizadorProyectoNube.ActualizarPermisos(vinculo, remoto);
            await Task.Run(() => MYGColaboracionLocal.Guardar(ruta, documento, vinculo));
            ComprobarClienteActual(cliente);
        }
        else
        {
            string preparacion = Path.Combine(carpeta, "preparando-" + Guid.NewGuid().ToString("N") + ".sqlite");
            try
            {
                documento = await Task.Run(() =>
                {
                    Directory.CreateDirectory(carpeta);
                    PaqueteNube.Descargar(contenidoCargado, preparacion);
                    var local = MYGBaseDatos.LeerProyecto(preparacion, original.Id);
                    MYGColaboracionLocal.Vincular(preparacion, local, new MYGVinculoNube
                    {
                        ProyectoId = remoto.Id, Servidor = servidor, UsuarioId = usuario,
                        Revision = remoto.Revision, Rol = remoto.Rol, PermisosModulos = remoto.PermisosModulos?.Copiar(),
                        JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(local),
                        JsonPaqueteConfirmado = contenidoCargado.GetRawText()
                    });
                    return local;
                });
                ComprobarClienteActual(cliente);
                File.Move(preparacion, ruta);
            }
            catch
            {
                // Solo esta preparación recién creada; nunca la copia de trabajo
                // existente ni los borradores que pudieran estar vinculados a ella.
                try { if (File.Exists(preparacion)) File.Delete(preparacion); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
                throw;
            }
        }
        ComprobarClienteActual(cliente);
        var editor = AbrirEditor(documento, ruta);
        editor.ConfigurarNube(() => clienteNube, MostrarNube);
        ventanaNube?.Hide();
        // La copia recuperada conserva borradores: actualizar explícitamente desde su barra.
    }

    private ArchivoPublicacionPendienteNube PublicacionesDe(ClienteSupabase cliente) => new(
        Path.Combine(CarpetaNube, "publicaciones"), cliente.UrlServidor, cliente.UsuarioId!);

    private async Task GestionarPublicacionesPendientesNube()
    {
        var cliente = RequerirNube();
        if (await GestionarPublicacionSqlitePendiente(cliente)) return;
        using var dialogo = new PublicacionesPendientesForm(PublicacionesDe(cliente), () => ComprobarClienteActual(cliente));
        var opcion = dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this);
        ComprobarClienteActual(cliente);
        if (opcion == WinForms.DialogResult.Retry && dialogo.ParaReintentar is { } pendiente)
            await PublicarProyectoNube(pendiente);
        else if (opcion == WinForms.DialogResult.OK)
            await PublicarProyectoNube();
    }

    private Task PublicarProyectoNube() => PublicarProyectoNube(null);

    private Task PublicarProyectoNube(ResumenPublicacionPendienteNube? elegida)
    {
        if (elegida is not null)
            throw new InvalidOperationException("Ese intento usa el formato anterior. Su copia local se conserva en Publicaciones pendientes. Retire el intento conservando la copia y publique la base en formato SQLite sin comprimir.");
        return PublicarProyectoSqliteNube();
    }

    private async Task DescargarProyectoNube(ProyectoNube seleccionado)
    {
        var cliente = RequerirNube();
        var sqlite = await Task.Run(() => cliente.ConsultarSqliteAsync(seleccionado.Id));
        ComprobarClienteActual(cliente);
        if (sqlite is not null)
        {
            await DescargarProyectoSqliteNube(cliente, sqlite);
            return;
        }
        using var dialogo = new WinForms.SaveFileDialog
        {
            Title = "Descargar copia independiente confirmada", Filter = "Paquete con recursos (*.zip)|*.zip|Base SQLite (*.sqlite)|*.sqlite",
            FileName = "MYG_NUBE.zip", AddExtension = true, OverwritePrompt = true
        };
        if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
        string destino = dialogo.FileName;
        bool zip = string.Equals(Path.GetExtension(destino), ".zip", StringComparison.OrdinalIgnoreCase);
        Guid proyectoId = seleccionado.Id;
        if (File.Exists(destino)) throw new InvalidOperationException("Elija un nombre nuevo para conservar el archivo existente.");
        ComprobarClienteActual(cliente);
        var remoto = await Task.Run(() => cliente.AbrirProyectoAsync(proyectoId));
        ComprobarClienteActual(cliente);
        JsonElement contenido = remoto.Contenido;
        var contenidoCargado = await Task.Run(() => cliente.CargarArchivosAsync(contenido));
        ComprobarClienteActual(cliente);
        await Task.Run(() => PaqueteNube.Descargar(contenidoCargado, destino, zip));
        ComprobarClienteActual(cliente);
        WinForms.MessageBox.Show(ventanaNube, "Copia independiente descargada desde la revisión " + remoto.Revision + ".",
            "Nube MYG", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information);
    }

}
