using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;

/// <summary>SQLite real y transporte HTTP simulado. No contacta con Supabase.</summary>
internal static class SqliteNubeCheck
{
    private static readonly Guid Actor = Guid.Parse("bcf5a542-4126-48ec-9ec5-90864f0523f7");
    private static readonly Guid Otro = Guid.Parse("341cc2c1-977f-42d0-a269-d85b8a09cb7b");
    private static readonly Guid Proyecto = Guid.Parse("021e9582-af8a-4fd2-bca5-8979046c3601");
    private const string Documento = "QA-SQLITE-BINARIO";
    private const string Nombre = "Base original sin compresión";
    private const string Bucket = "/storage/v1/object/myg-nube-sqlite/";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-SQLite-Transporte-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            await PublicarGuardarDescargar(carpeta);
            await AckPerdidoYConflicto(carpeta);
            await RenovacionIdentidad(carpeta);
            await DescargasHostiles(carpeta);
            await PermisosYServidorAnterior(carpeta);
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
        Console.WriteLine($"OK SQLite nativo: 5 grupos y {comprobaciones} comprobaciones de bytes exactos, SHA-256, streams, permisos, renovación, ACK y descargas atómicas; sin red.");
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("SQLite nativo: " + detalle);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException ex) { comprobaciones++; return ex; }
        throw new InvalidOperationException("Se esperaba un rechazo del transporte SQLite.");
    }

    private static string CrearBase(string carpeta, string texto)
    {
        string ruta = Path.Combine(carpeta, Guid.NewGuid().ToString("N") + ".sqlite");
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open();
        using var q = c.CreateCommand();
        q.CommandText = "CREATE TABLE datos(id INTEGER PRIMARY KEY, texto TEXT, binario BLOB); INSERT INTO datos VALUES(1,$texto,$bytes)";
        q.Parameters.AddWithValue("$texto", texto);
        q.Parameters.AddWithValue("$bytes", new byte[] { 0, 1, 2, 255 });
        q.ExecuteNonQuery();
        return ruta;
    }

    private static async Task<ClienteSupabase> Cliente(Transporte http)
    {
        var cliente = new ClienteSupabase("https://sqlite-nativo.supabase.co", "sb_publishable_sqlite_sintetico", http);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        return cliente;
    }

    private static string Hash(byte[] datos) => Convert.ToHexString(SHA256.HashData(datos)).ToLowerInvariant();

    private static async Task PublicarGuardarDescargar(string carpeta)
    {
        string origen = CrearBase(carpeta, "Unicode Áncash 漢字 y contenido exacto");
        byte[] inicial = File.ReadAllBytes(origen);
        using var http = new Transporte(); using var cliente = await Cliente(http);
        var etapas = new List<string>();
        var publicado = await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento,
            progreso: new Progreso(etapas.Add));
        Exige(http.Subidas == 1 && http.CuerposSubidos.Single().SequenceEqual(inicial), "la publicación cambió los bytes originales.");
        Exige(publicado.Archivo.Sha256 == Hash(inicial) && publicado.Archivo.Bytes == inicial.Length
            && publicado.Proyecto.Contenido.ValueKind == JsonValueKind.Undefined, "la respuesta debe contener solo metadatos exactos.");
        Exige(etapas.Any(e => e.StartsWith("Enviando SQLite sin comprimir")) && !etapas.Any(e => e.Contains("Comprimiendo")),
            "el progreso no refleja el stream sin compresión.");
        Exige(http.Metadatos.All(cuerpo => cuerpo.Length < 2048 && !cuerpo.Contains("p_contenido")
            && !cuerpo.Contains("Base64")), "una RPC transportó datos de tablas o Base64 en lugar de metadatos.");
        await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento);
        Exige(http.Subidas == 1, "reintentar publicación confirmada volvió a subir el archivo.");
        string destino = Path.Combine(carpeta, Guid.NewGuid().ToString("N") + ".sqlite");
        await cliente.DescargarSqliteAsync(publicado, destino);
        Exige(File.ReadAllBytes(destino).SequenceEqual(inicial), "la descarga no conserva el archivo SQLite original.");
        string nuevo = CrearBase(carpeta, "Revisión siguiente");
        Guid op = Guid.NewGuid();
        var respuesta = await cliente.GuardarSqliteAsync(Proyecto, op, 1, nuevo);
        Exige(respuesta.Estado == "aplicada" && respuesta.Revision == 2 && respuesta.OperacionId == op
            && http.Subidas == 2 && respuesta.Archivo.Sha256 == Hash(File.ReadAllBytes(nuevo)), "guardar no confirmó la revisión correcta.");
        await cliente.GuardarSqliteAsync(Proyecto, op, 1, nuevo);
        Exige(http.Subidas == 2 && http.GuardadosAplicados == 1, "el replay cambió el UUID o repitió la transferencia.");
        Exige(File.ReadAllBytes(origen).SequenceEqual(inicial), "el transporte modificó el archivo de origen.");
    }

    private static async Task AckPerdidoYConflicto(string carpeta)
    {
        using var http = new Transporte(); using var cliente = await Cliente(http);
        string origen = CrearBase(carpeta, "Revisión inicial ACK");
        await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento);
        string cambio = CrearBase(carpeta, "Revisión aplicada sin respuesta");
        Guid op = Guid.NewGuid(); http.PerderAck = true;
        var error = await Rechaza(() => cliente.GuardarSqliteAsync(Proyecto, op, 1, cambio));
        Exige(error.EsErrorDeConexion && http.Revision == 2, "el escenario no perdió el ACK después de aplicar.");
        int subidas = http.Subidas;
        var replay = await cliente.GuardarSqliteAsync(Proyecto, op, 1, cambio);
        Exige(replay.Estado == "aplicada" && replay.Revision == 2 && http.Subidas == subidas
            && http.GuardadosAplicados == 1, "la recuperación de ACK volvió a subir o aplicar el archivo.");
        string otro = CrearBase(carpeta, "Edición local concurrente");
        var conflicto = await cliente.GuardarSqliteAsync(Proyecto, Guid.NewGuid(), 1, otro);
        Exige(conflicto.Estado == "conflicto" && conflicto.Revision == 2 && http.Subidas == subidas,
            "un conflicto conocido debe resolverse con metadatos sin subir una base inútil.");
    }

    private static async Task RenovacionIdentidad(string carpeta)
    {
        string origen = CrearBase(carpeta, "Renovación exacta");
        using (var http = new Transporte { RenovarSubida = true })
        using (var cliente = await Cliente(http))
        {
            await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento);
            Exige(http.Refrescos == 1 && http.CuerposSubidos.Count == 2
                && http.CuerposSubidos[0].SequenceEqual(http.CuerposSubidos[1]), "renovar401 no reabrió el mismo stream inmutable.");
        }
        using (var http = new Transporte { RenovarSubida = true, CambiarIdentidad = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento));
            Exige(error.NecesitaIniciarSesion && http.CuerposSubidos.Count == 1 && http.Actual is null,
                "el cambio de cuenta reenvió o confirmó datos con otra identidad.");
        }
    }

    private static async Task DescargasHostiles(string carpeta)
    {
        using var http = new Transporte(); using var cliente = await Cliente(http);
        string origen = CrearBase(carpeta, "Descarga íntegra");
        var publicado = await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "base", Documento);
        string destino = CrearBase(carpeta, "Destino que debe sobrevivir");
        byte[] previo = File.ReadAllBytes(destino);
        http.CorromperDescarga = true;
        await Rechaza(() => cliente.DescargarSqliteAsync(publicado, destino));
        Exige(File.ReadAllBytes(destino).SequenceEqual(previo) && !Directory.EnumerateFiles(carpeta, ".myg-descarga-*").Any(),
            "una descarga corrupta reemplazó destino o dejó un temporal.");
        http.CorromperDescarga = false; http.ComprimirDescarga = true;
        await Rechaza(() => cliente.DescargarSqliteAsync(publicado, destino));
        Exige(File.ReadAllBytes(destino).SequenceEqual(previo), "una respuesta codificada como gzip se aceptó como SQLite original.");
        http.ComprimirDescarga = false;
        foreach (string ruta in new[] { "../otra.sqlite", Actor + "/" + Guid.NewGuid().ToString("N") + "/" + publicado.Archivo.Sha256 + ".sqlite" })
        {
            int descargas = http.Descargas;
            await Rechaza(() => cliente.DescargarSqliteAsync(publicado with { Archivo = publicado.Archivo with { Ruta = ruta } }, destino));
            Exige(http.Descargas == descargas, "la ruta hostil se envió al servidor.");
        }
        string invalido = Path.Combine(carpeta, "cabecera-no-sqlite.bin");
        File.WriteAllText(invalido, new string('x', 200));
        int llamadas = http.Metadatos.Count;
        await Rechaza(() => cliente.CrearSqliteAsync(Guid.NewGuid(), Nombre, invalido, "obra", Documento));
        Exige(http.Metadatos.Count == llamadas, "un archivo sin cabecera SQLite llegó a las RPC.");
    }

    private static async Task PermisosYServidorAnterior(string carpeta)
    {
        string origen = CrearBase(carpeta, "Permisos");
        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        {
            await cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento);
            http.Restringido = true;
            int subidas = http.Subidas;
            var error = await Rechaza(() => cliente.GuardarSqliteAsync(Proyecto, Guid.NewGuid(), 1, origen));
            Exige(error.AccesoDenegado && http.Subidas == subidas && http.GuardadosAplicados == 0,
                "un editor restringido pudo reemplazar una base opaca completa.");
        }
        using (var http = new Transporte { ServidorAnterior = true })
        using (var cliente = await Cliente(http))
        {
            Exige(await cliente.ConsultarSqliteAsync(Proyecto) is null, "el servidor anterior debe conservar lectura legada.");
            var error = await Rechaza(() => cliente.CrearSqliteAsync(Proyecto, Nombre, origen, "obra", Documento));
            Exige(error.Message.Contains("20261030_archivos_sqlite.sql") && http.Subidas == 0,
                "publicar recurrió a compresión/JSON en vez de exigir la migración.");
        }
    }

    private sealed class Progreso(Action<string> informar) : IProgress<string>
    { public void Report(string value) => informar(value); }

    private sealed class Transporte : HttpMessageHandler
    {
        internal readonly Dictionary<string, byte[]> Objetos = new(StringComparer.Ordinal);
        internal readonly List<string> Metadatos = new();
        internal readonly List<byte[]> CuerposSubidos = new();
        private readonly Dictionary<Guid, (long Base, ArchivoSqliteNube Archivo)> operaciones = new();
        internal ArchivoSqliteNube? Actual;
        private ArchivoSqliteNube? inicial;
        internal long Revision = 1;
        internal int Subidas, Descargas, GuardadosAplicados, Refrescos;
        internal bool PerderAck, RenovarSubida, CambiarIdentidad, Restringido, ServidorAnterior, CorromperDescarga, ComprimirDescarga;
        private string alcance = "obra";

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token")
            {
                bool refresco = solicitud.RequestUri.Query.Contains("refresh_token");
                if (refresco) Refrescos++;
                return Json(new { access_token = refresco ? "acceso_renovado" : "acceso_original", refresh_token = "refresco_sintetico",
                    expires_in = 3600, user = new { id = refresco && CambiarIdentidad ? Otro : Actor } });
            }
            Exige(solicitud.Headers.Authorization is not null, "una transferencia no llevaba la sesión autenticada.");
            Exige(solicitud.Headers.Contains("apikey"), "faltó la clave publicable del proyecto.");
            if (ruta.StartsWith(Bucket, StringComparison.Ordinal))
            {
                string objeto = ruta[Bucket.Length..];
                if (solicitud.Method == HttpMethod.Post)
                {
                    Exige(solicitud.Content!.Headers.ContentType?.MediaType == "application/vnd.sqlite3"
                        && solicitud.Content.Headers.ContentEncoding.Count == 0
                        && solicitud.Headers.GetValues("x-upsert").Single() == "false", "el stream se comprimió o permitió sobrescribir.");
                    using var memoria = new MemoryStream(); await solicitud.Content.CopyToAsync(memoria, ct);
                    byte[] bytes = memoria.ToArray(); CuerposSubidos.Add(bytes);
                    Exige(bytes.AsSpan(0, 16).SequenceEqual("SQLite format 3\0"u8), "el cuerpo de Storage no es SQLite binario.");
                    Exige(objeto == Actor + "/" + Proyecto.ToString("N") + "/" + Hash(bytes) + ".sqlite", "la ruta no está aislada por cuenta/proyecto/hash.");
                    if (RenovarSubida) { RenovarSubida = false; return Json(new { }, HttpStatusCode.Unauthorized); }
                    if (!Objetos.TryAdd(objeto, bytes)) return Json(new { }, HttpStatusCode.Conflict);
                    Subidas++; return Json(new { Key = objeto });
                }
                Descargas++;
                byte[] contenido = Objetos[objeto].ToArray();
                if (CorromperDescarga) contenido[^1] ^= 0xff;
                var respuesta = new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(contenido) };
                if (ComprimirDescarga) respuesta.Content.Headers.ContentEncoding.Add("gzip");
                return respuesta;
            }
            if (!ruta.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal)) throw new InvalidOperationException("Solicitud inesperada: " + ruta);
            string cuerpo = await solicitud.Content!.ReadAsStringAsync(ct); Metadatos.Add(cuerpo);
            using var parametros = JsonDocument.Parse(cuerpo); var p = parametros.RootElement;
            if (ruta.EndsWith("myg_nube_sqlite_capacidades"))
                return ServidorAnterior ? Json(new { code = "PGRST202" }, HttpStatusCode.NotFound)
                    : Json(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
            if (ruta.EndsWith("myg_nube_sqlite_consultar")) return Actual is null ? Json<object?>(null) : Descriptor(Actual, Revision);
            if (ruta.EndsWith("myg_nube_sqlite_crear"))
            {
                var archivo = DeParametros(p); alcance = p.GetProperty("p_alcance").GetString()!;
                Exige(p.GetProperty("p_documento_id").GetString() == Documento && p.GetProperty("p_nombre").GetString() == Nombre,
                    "la publicación alteró la identidad del documento.");
                Exige(Objetos.ContainsKey(archivo.Ruta), "se confirmó un objeto sin subir.");
                if (inicial is not null) Exige(inicial == archivo, "reintentar creación cambió el archivo inmutable.");
                inicial ??= archivo; Actual ??= archivo;
                return Descriptor(inicial, 1);
            }
            if (ruta.EndsWith("myg_nube_sqlite_abrir")) return Descriptor(Actual!, Revision);
            if (ruta.EndsWith("myg_nube_sqlite_guardar"))
            {
                Guid operacion = p.GetProperty("p_operacion").GetGuid();
                long revision = p.GetProperty("p_revision").GetInt64();
                var archivo = DeParametros(p);
                if (operaciones.TryGetValue(operacion, out var anterior))
                {
                    Exige(anterior.Base == revision && anterior.Archivo == archivo, "el replay cambió el UUID/cuerpo congelado.");
                    return Guardado("aplicada", revision + 1, operacion, archivo);
                }
                if (revision != Revision) return Guardado("conflicto", Revision, operacion, Actual!);
                Exige(Objetos.ContainsKey(archivo.Ruta), "se guardó un objeto que no existe en Storage.");
                operaciones.Add(operacion, (revision, archivo)); Actual = archivo; Revision++; GuardadosAplicados++;
                if (PerderAck) { PerderAck = false; throw new HttpRequestException("ACK perdido sintético"); }
                return Guardado("aplicada", Revision, operacion, archivo);
            }
            throw new InvalidOperationException("RPC inesperada: " + ruta);
        }

        private static ArchivoSqliteNube DeParametros(JsonElement p) =>
            new(p.GetProperty("p_ruta").GetString()!, p.GetProperty("p_sha256").GetString()!, p.GetProperty("p_bytes").GetInt64());
        private HttpResponseMessage Descriptor(ArchivoSqliteNube archivo, long revision) => Json(new
        {
            id = Proyecto, codigo = "MYG-SQLITE-001", nombre = Nombre, rol = Restringido ? "editor" : "propietario", revision, alcance,
            documento_id = Documento,
            permisos_modulos = new { acu = !Restringido, especificaciones = true, metrados_excel = true },
            archivo_sqlite = new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes }
        });
        private static HttpResponseMessage Guardado(string estado, long revision, Guid operacion, ArchivoSqliteNube archivo) => Json(new
        { estado, revision, operacion_id = operacion, archivo_sqlite = new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes } });
        private static HttpResponseMessage Json<T>(T valor, HttpStatusCode estado = HttpStatusCode.OK) =>
            new(estado) { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
