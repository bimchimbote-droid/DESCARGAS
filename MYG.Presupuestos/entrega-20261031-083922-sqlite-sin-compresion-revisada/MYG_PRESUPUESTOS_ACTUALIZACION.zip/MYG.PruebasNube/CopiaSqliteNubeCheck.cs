using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class CopiaSqliteNubeCheck
{
    private const string Servidor = "https://sqlite-motor.supabase.co";
    private static readonly Guid Proyecto = Guid.Parse("55555555-1111-4555-8555-555555555555");
    private static readonly Guid Usuario = Guid.Parse("66666666-2222-4666-8666-666666666666");
    private static int comprobaciones;
    private static void Exige(bool valor, string mensaje)
    { comprobaciones++; if (!valor) throw new InvalidOperationException(mensaje); }

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        await SnapshotWal();
        await CambiosFisicosYCola();
        await AckPerdido();
        await DescargaYConflictos();
        await EdicionDuranteDescarga();
        await PermisosYAdjuntosPosteriores();
        Console.WriteLine($"OK Motor SQLite: 6 grupos y {comprobaciones} comprobaciones; archivos reales, WAL, ACK perdido, conflictos y permisos. Sin red.");
    }

    private static async Task SnapshotWal()
    {
        using var e = await Escenario.Crear();
        using var abierta = Abrir(e.Ruta);
        Sql(abierta, "PRAGMA journal_mode=WAL; PRAGMA wal_autocheckpoint=0; INSERT INTO planoteca(id_archivo,titulo_archivo,archivo) VALUES(2,'escritura WAL',zeroblob(8192));");
        Exige(File.Exists(e.Ruta + "-wal"), "La prueba debe conservar cambios WAL reales sin cerrar la conexión.");
        string antes = Huella(e.Ruta), walAntes = Huella(e.Ruta + "-wal");
        string copia = Path.Combine(e.Carpeta, "snapshot-wal.sqlite");
        CopiaSqliteNube.CrearSnapshot(e.Ruta, copia);
        using (var c = Abrir(copia)) Exige((long)Valor(c, "SELECT count(*) FROM planoteca")! == 2, "El backup omitió la escritura WAL.");
        string otra = Path.Combine(e.Carpeta, "snapshot-wal-2.sqlite");
        CopiaSqliteNube.CrearSnapshot(e.Ruta, otra);
        Exige(Huella(copia) == Huella(otra), "La huella de snapshots consecutivos sin edición debe ser estable.");
        using var estado = Abrir(CopiaSqliteNube.RutaEstado(e.Ruta));
        Exige(!((string)Valor(estado, "SELECT group_concat(sql) FROM sqlite_master WHERE type='table'")!).Contains("json", StringComparison.OrdinalIgnoreCase),
            "El sidecar debe mantener la cola como columnas SQL, sin contenido JSON de la obra.");
        Exige(antes == Huella(e.Ruta) && walAntes == Huella(e.Ruta + "-wal"), "Crear snapshots no debe modificar la base fuente ni su WAL.");
    }

    private static async Task CambiosFisicosYCola()
    {
        using var e = await Escenario.Crear();
        await e.Sync();
        Exige(e.Http.Operaciones.Count == 0, "Una copia sin cambios no debe generar un envío SQLite.");
        using (var c = Abrir(e.Ruta)) Sql(c, "UPDATE planoteca SET titulo_archivo='cambio de tabla sin cambiar documento' WHERE id_archivo=1");
        await e.Sync();
        Exige(e.Http.Operaciones.Count == 1 && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Doc.Id)!.Pendiente is null,
            "Cambiar SQL nativo debe enviarse aunque el documento MYG no cambie.");
        Exige(e.Http.Binarios.All(b => b.AsSpan(0, 16).SequenceEqual("SQLite format 3\0"u8)), "El transporte debe recibir SQLite directo, sin ZIP, compresión ni JSON de tablas.");
        await e.Sync();
        Exige(e.Http.Operaciones.Count == 1, "La confirmación no debe provocar un envío nuevo sin cambios.");
        using var original = Abrir(e.Ruta);
        Exige((long)Valor(original, "SELECT count(*) FROM sqlite_master WHERE name='myg_colaboracion_local'")! == 0,
            "Vincular y sincronizar no deben agregar la cola JSON antigua a la base de trabajo.");
    }

    private static async Task AckPerdido()
    {
        using var e = await Escenario.Crear();
        using (var c = Abrir(e.Ruta)) Sql(c, "UPDATE planoteca SET titulo_archivo='versión enviada A' WHERE id_archivo=1");
        e.Http.PerderAck = true;
        bool fallo = false;
        try { await e.Sync(); } catch (NubeException ex) { fallo = ex.EsErrorDeConexion; }
        Exige(fallo, "Debe simularse un ACK perdido después de confirmar el servidor.");
        var pendiente = CopiaSqliteNube.LeerVinculo(e.Ruta, e.Doc.Id)!.Pendiente!;
        Exige(pendiente.Enviada && pendiente.Id != Guid.Empty && e.Http.Revision == 2, "El envío durable no sobrevivió al ACK perdido.");
        using (var c = Abrir(e.Ruta)) Sql(c, "UPDATE planoteca SET titulo_archivo='versión posterior B' WHERE id_archivo=1");
        await e.Sync();
        Exige(e.Http.Operaciones.Count == 2 && e.Http.Operaciones[0] == e.Http.Operaciones[1], "El reintento debe conservar UUID, revisión y hash del archivo A.");
        Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, e.Doc.Id)!.Pendiente != null, "La edición B durante desconexión debe seguir pendiente tras confirmar A.");
        Exige(e.Texto() == "versión posterior B", "Confirmar A no debe sustituir la edición local posterior B.");
        await e.Sync();
        Exige(e.Http.Revision == 3 && e.Http.Operaciones.Last().Id != pendiente.Id, "La edición posterior necesita una operación nueva sobre revisión 2.");
        Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, e.Doc.Id)!.Pendiente is null, "La segunda edición no quedó confirmada.");
    }

    private static async Task DescargaYConflictos()
    {
        using var e = await Escenario.Crear();
        e.Avanzar("revisión remota 2");
        await e.Sync(soloLeer: true);
        Exige(e.Texto() == "revisión remota 2" && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Doc.Id)!.Revision == 2,
            "Recargar debe aplicar la revisión remota y las tablas SQL arbitrarias.");
        Exige(e.Doc.FuenteCatalogo.RutaSQLite == e.Ruta, "El documento descargado debe reubicar el alias de catálogo propio sólo en memoria.");
        Exige(MYGBaseDatos.LeerProyecto(e.Ruta, e.Doc.Id).FuenteCatalogo.RutaSQLite == ArchivoPublicacionSqlitePendiente.ReferenciaPropia,
            "La base sincronizada debe conservar el alias portable, sin rutas del equipo remoto.");
        Exige(Directory.GetFiles(e.Ruta + ".nube", "respaldo-*.sqlite").Length == 1, "Aplicar remoto necesita conservar respaldo SQLite anterior.");
        using (var c = Abrir(e.Ruta)) Sql(c, "UPDATE planoteca SET titulo_archivo='edición local conservada' WHERE id_archivo=1");
        e.Avanzar("revisión remota 3");
        await e.Sync(soloLeer: true);
        Exige(CopiaSqliteNube.TieneConflicto(e.Ruta) && e.Texto() == "edición local conservada", "Recargar con cambios locales debe conservar el archivo y registrar conflicto.");
        CopiaSqliteNube.ResolverMantenerLocal(e.Ruta, e.Doc.Id);
        await e.Sync();
        Exige(e.Http.Revision == 4 && !CopiaSqliteNube.TieneConflicto(e.Ruta) && e.Texto() == "edición local conservada",
            "Mantener local debe generar explícitamente otro CAS contra la revisión remota.");
        using (var c = Abrir(e.Ruta)) Sql(c, "UPDATE planoteca SET titulo_archivo='local descartado con respaldo' WHERE id_archivo=1");
        e.Avanzar("revisión remota elegida");
        await e.Sync(soloLeer: true);
        e.Doc = (await CopiaSqliteNube.ResolverUsarRemotoAsync(e.Cliente, e.Ruta, e.Doc)).Documento;
        Exige(e.Texto() == "revisión remota elegida" && !CopiaSqliteNube.TieneConflicto(e.Ruta), "Usar remoto debe descargar SQLite, conservar respaldo y resolver el conflicto.");
    }

    private static async Task EdicionDuranteDescarga()
    {
        using var e = await Escenario.Crear();
        e.Avanzar("servidor durante descarga");
        e.Http.AlDescargar = () => { using var c = Abrir(e.Ruta); Sql(c, "UPDATE planoteca SET titulo_archivo='edición externa concurrente' WHERE id_archivo=1"); };
        await e.Sync(soloLeer: true);
        Exige(e.Texto() == "edición externa concurrente" && CopiaSqliteNube.TieneConflicto(e.Ruta),
            "La descarga no puede sustituir una edición externa que apareció después de preparar la operación.");
    }

    private static async Task PermisosYAdjuntosPosteriores()
    {
        using (var e = await Escenario.Crear())
        {
            using (var c = Abrir(e.Ruta)) Sql(c, "UPDATE planoteca SET titulo_archivo='cambio con permiso parcial' WHERE id_archivo=1");
            e.Http.Permisos.Especificaciones = false;
            bool rechazo = false;
            try { await e.Sync(); } catch (NubeException ex) { rechazo = ex.Message.Contains("todos los módulos", StringComparison.Ordinal); }
            Exige(rechazo && e.Http.Binarios.Count == 0 && e.Http.Operaciones.Count == 0,
                "Los permisos parciales deben explicar por qué no puede enviarse toda la base, sin subir bytes.");
            Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, e.Doc.Id)!.Pendiente != null && e.Texto() == "cambio con permiso parcial",
                "Rechazar el envío debe conservar el archivo editado y la operación durable.");
            await e.Sync(soloLeer: true);
            Exige(e.Http.Operaciones.Count == 0, "Recargar con permisos parciales debe seguir consultando sin enviar cambios.");
        }
        using (var e = await Escenario.Crear())
        {
            using (var c = Abrir(e.Ruta)) Sql(c, "INSERT INTO catalogo_insumo(id,codigo,descripcion,unidad,grupo,precio,json_datos,revision,modificado_utc) VALUES('externo','EX','Adjunto','und','Materiales','0','{\"ImagenRuta\":\"foto-del-equipo.png\"}',1,'2026-10-30')");
            string antes = Huella(e.Ruta);
            bool rechazo = false;
            try { await e.Sync(); } catch (InvalidDataException) { rechazo = true; }
            Exige(rechazo && Huella(e.Ruta) == antes && e.Http.Binarios.Count == 0,
                "Un adjunto externo añadido después de publicar debe impedir el siguiente envío sin modificar el archivo fuente.");
        }
    }

    private sealed class Escenario : IDisposable
    {
        internal string Carpeta { get; } = Path.Combine(Path.GetTempPath(), "myg-sqlite-motor-" + Guid.NewGuid().ToString("N"));
        internal string Ruta { get; }
        internal MYGProyectoDocumento Doc { get; set; }
        internal Transporte Http { get; }
        internal ClienteSupabase Cliente { get; }
        private Escenario()
        {
            Directory.CreateDirectory(Carpeta); Ruta = Path.Combine(Carpeta, "trabajo.sqlite");
            Doc = MYGProyectoStorage.Nuevo("Proyecto SQL nativo", "Presupuesto");
            Doc.FuenteCatalogo = new MYGFuenteDelphin { Id = "CATALOGO-PROPIO", RutaSQLite = Ruta };
            MYGProyectoStorage.Guardar(Ruta, Doc);
            using (var c = Abrir(Ruta)) Sql(c, "INSERT INTO planoteca(id_archivo,titulo_archivo,archivo) VALUES(1,'inicial',zeroblob(1024));");
            string inicial = Path.Combine(Carpeta, "inicial.sqlite"); CopiaSqliteNube.CrearSnapshot(Ruta, inicial);
            Http = new Transporte(Doc.Id, File.ReadAllBytes(inicial));
            Cliente = new ClienteSupabase(Servidor, "sb_publishable_motor_sqlite", Http);
        }
        internal static async Task<Escenario> Crear()
        {
            var e = new Escenario();
            try
            {
                await e.Cliente.IniciarSesionAsync("sql@myg.example", "clave_prueba");
                CopiaSqliteNube.Vincular(e.Ruta, e.Http.Descriptor, e.Cliente); return e;
            }
            catch { e.Dispose(); throw; }
        }
        internal async Task Sync(bool soloLeer = false) => Doc = (await CopiaSqliteNube.EjecutarAsync(Cliente, Ruta, Doc, soloLeer)).Documento;
        internal string Texto() { using var c = Abrir(Ruta); return (string)Valor(c, "SELECT titulo_archivo FROM planoteca WHERE id_archivo=1")!; }
        internal void Avanzar(string texto)
        {
            string remoto = Path.Combine(Carpeta, "remoto-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.WriteAllBytes(remoto, Http.Actual);
            using (var c = Abrir(remoto))
            { using var q = c.CreateCommand(); q.CommandText = "UPDATE planoteca SET titulo_archivo=$p0 WHERE id_archivo=1"; q.Parameters.AddWithValue("$p0", texto); q.ExecuteNonQuery(); }
            Http.Avanzar(File.ReadAllBytes(remoto));
        }
        public void Dispose() { Cliente.Dispose(); SqliteConnection.ClearAllPools(); Directory.Delete(Carpeta, true); }
    }

    private sealed class Transporte(string documento, byte[] inicial) : HttpMessageHandler
    {
        internal byte[] Actual { get; private set; } = inicial;
        internal long Revision { get; private set; } = 1;
        internal bool PerderAck { get; set; }
        internal MYGPermisosModulos Permisos { get; } = new();
        internal Action? AlDescargar { get; set; }
        internal List<byte[]> Binarios { get; } = new();
        internal List<(Guid Id, long Revision, string Hash)> Operaciones { get; } = new();
        private readonly Dictionary<Guid, (long Revision, ArchivoSqliteNube Archivo)> acks = new();
        private readonly Dictionary<string, byte[]> objetos = new();
        private ArchivoSqliteNube Archivo => Datos(Actual);
        internal ProyectoSqliteNube Descriptor => new(new ProyectoNube(Proyecto, "SQL-001", "Proyecto SQL", "editor", Revision, "base", default)
        { PermisosModulos = Permisos.Copiar() }, documento, Archivo);
        internal void Avanzar(byte[] bytes) { Actual = bytes; Revision++; }
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage q, CancellationToken ct)
        {
            string ruta = q.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token") return Json(new { access_token = "token_sql", refresh_token = "refresh_sql", expires_in = 3600, user = new { id = Usuario } });
            if (ruta == "/rest/v1/rpc/myg_nube_sqlite_capacidades") return Json(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
            if (ruta is "/rest/v1/rpc/myg_nube_sqlite_consultar" or "/rest/v1/rpc/myg_nube_sqlite_abrir")
                return Json(new { id = Proyecto, codigo = "SQL-001", nombre = "Proyecto SQL", rol = "editor", revision = Revision,
                    alcance = "base", documento_id = documento, permisos_modulos = Permisos,
                    archivo_sqlite = ArchivoJson(Archivo) });
            const string prefijo = "/storage/v1/object/myg-nube-sqlite/";
            if (ruta.StartsWith(prefijo, StringComparison.Ordinal))
            {
                string objeto = ruta[prefijo.Length..];
                if (q.Method == HttpMethod.Post)
                {
                    byte[] bytes = await q.Content!.ReadAsByteArrayAsync(ct); Binarios.Add(bytes); objetos[objeto] = bytes;
                    return Json(new { Key = objeto }, HttpStatusCode.Created);
                }
                AlDescargar?.Invoke(); AlDescargar = null;
                byte[] archivo = objeto == Archivo.Ruta ? Actual : objetos[objeto];
                return new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(archivo) };
            }
            if (ruta == "/rest/v1/rpc/myg_nube_sqlite_guardar")
            {
                using var json = JsonDocument.Parse(await q.Content!.ReadAsByteArrayAsync(ct)); var r = json.RootElement;
                Guid id = r.GetProperty("p_operacion").GetGuid(); long revision = r.GetProperty("p_revision").GetInt64();
                var enviado = new ArchivoSqliteNube(r.GetProperty("p_ruta").GetString()!, r.GetProperty("p_sha256").GetString()!, r.GetProperty("p_bytes").GetInt64());
                Operaciones.Add((id, revision, enviado.Sha256));
                if (acks.TryGetValue(id, out var previo)) return Json(new { estado = "aplicada", revision = previo.Revision, operacion_id = id, archivo_sqlite = ArchivoJson(previo.Archivo) });
                if (revision != Revision) return Json(new { estado = "conflicto", revision = Revision, operacion_id = id, archivo_sqlite = ArchivoJson(Archivo) });
                Actual = objetos[enviado.Ruta]; Revision++; acks[id] = (Revision, enviado);
                if (PerderAck) { PerderAck = false; throw new HttpRequestException("ACK perdido después del commit SQLite"); }
                return Json(new { estado = "aplicada", revision = Revision, operacion_id = id, archivo_sqlite = ArchivoJson(enviado) });
            }
            throw new InvalidOperationException("Endpoint inesperado del motor SQLite: " + ruta);
        }
        private static object ArchivoJson(ArchivoSqliteNube a) => new { ruta = a.Ruta, sha256 = a.Sha256, bytes = a.Bytes };
        private static ArchivoSqliteNube Datos(byte[] bytes)
        { string hash = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(); return new(Usuario.ToString("D") + "/" + Proyecto.ToString("N") + "/" + hash + ".sqlite", hash, bytes.Length); }
        private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }

    private static SqliteConnection Abrir(string ruta)
    { var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()); c.Open(); return c; }
    private static void Sql(SqliteConnection c, string sql) { using var q = c.CreateCommand(); q.CommandText = sql; q.ExecuteNonQuery(); }
    private static object? Valor(SqliteConnection c, string sql) { using var q = c.CreateCommand(); q.CommandText = sql; return q.ExecuteScalar(); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
}
