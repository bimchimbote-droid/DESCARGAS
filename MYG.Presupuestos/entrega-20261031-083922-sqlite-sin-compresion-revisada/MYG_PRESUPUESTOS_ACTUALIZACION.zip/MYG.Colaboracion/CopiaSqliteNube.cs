#nullable enable
using System.Collections.Concurrent;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>Colaboración de archivos SQLite; la cola está en un sidecar relacional y nunca dentro de la obra.</summary>
public static class CopiaSqliteNube
{
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> Exclusiones = new(StringComparer.OrdinalIgnoreCase);
    private sealed record Pendiente(Guid Id, long Revision, string Ruta, string Hash, long Bytes, bool Enviada);
    private sealed record Estado(string Documento, Guid Proyecto, string Servidor, string Usuario, string Rol,
        long Revision, string Hash, bool Sucio, long Conflicto, string? Conexion, MYGPermisosModulos? Permisos);

    public static string RutaEstado(string ruta) => Path.GetFullPath(ruta) + ".nube.sqlite";
    private static string Carpeta(string ruta) => Path.GetFullPath(ruta) + ".nube";
    private static SemaphoreSlim Exclusion(string ruta) => Exclusiones.GetOrAdd(Path.GetFullPath(ruta), _ => new(1, 1));

    public static MYGVinculoNube? LeerVinculo(string ruta, string documentoId)
    {
        if (!File.Exists(RutaEstado(ruta))) return null;
        using var c = AbrirEstado(ruta);
        var estado = LeerEstado(c, documentoId);
        return estado is null ? null : Adaptar(estado, LeerPendiente(c, documentoId));
    }

    public static bool TieneConflicto(string ruta)
    {
        if (!File.Exists(RutaEstado(ruta))) return false;
        using var c = AbrirEstado(ruta);
        using var q = c.CreateCommand(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM vinculo WHERE conflicto_revision>0)";
        return (long)q.ExecuteScalar()! != 0;
    }

    /// <summary>Un indicador barato para la barra UI. Sincronizar verifica además cambios externos y WAL.</summary>
    public static void MarcarCambio(string ruta, string documentoId)
    {
        if (!File.Exists(RutaEstado(ruta))) return;
        using var c = AbrirEstado(ruta);
        Ejecutar(c, "UPDATE vinculo SET sucio=1 WHERE documento=$p0", documentoId);
    }

    public static void Vincular(string ruta, ProyectoSqliteNube remoto, ClienteSupabase cliente, string? documentoId = null)
    {
        ArgumentNullException.ThrowIfNull(remoto);
        string id = documentoId ?? remoto.DocumentoId;
        if (id != remoto.DocumentoId) throw new InvalidDataException("El archivo remoto pertenece a otro documento.");
        if (!cliente.SesionIniciada || string.IsNullOrWhiteSpace(cliente.UsuarioId))
            throw new NubeException("Inicie sesión antes de vincular el archivo SQLite.", necesitaIniciarSesion: true);
        var cerrojo = Exclusion(ruta); cerrojo.Wait();
        try
        {
            Directory.CreateDirectory(Carpeta(ruta));
            string copia = Temporal(ruta);
            try
            {
                CrearSnapshot(ruta, copia);
                string hash = Hash(copia);
                using var c = AbrirEstado(ruta);
                var previo = LeerEstado(c, id);
                if (previo != null && (previo.Proyecto != remoto.Proyecto.Id || previo.Usuario != cliente.UsuarioId ||
                    !string.Equals(previo.Servidor, cliente.UrlServidor, StringComparison.OrdinalIgnoreCase)))
                    throw new InvalidOperationException("La copia ya está vinculada a otra identidad. Use otro archivo local.");
                if (LeerPendiente(c, id) != null)
                    throw new InvalidOperationException("La copia conserva una operación pendiente. Sincronícela antes de volver a vincular.");
                var estado = new Estado(id, remoto.Proyecto.Id, cliente.UrlServidor, cliente.UsuarioId!, remoto.Proyecto.Rol,
                    remoto.Proyecto.Revision, hash, false, 0, null, remoto.Proyecto.PermisosModulos?.Copiar());
                EscribirEstado(c, estado);
            }
            finally { Borrar(copia); }
        }
        finally { cerrojo.Release(); }
    }

    /// <summary>Copia consistente con WAL incluido. No cambia la base original ni convierte tablas en JSON.</summary>
    public static void CrearSnapshot(string origen, string destino, CancellationToken ct = default)
    {
        origen = Path.GetFullPath(origen); destino = Path.GetFullPath(destino);
        if (string.Equals(origen, destino, StringComparison.OrdinalIgnoreCase) || File.Exists(destino))
            throw new IOException("La instantánea necesita un archivo de destino nuevo.");
        Directory.CreateDirectory(Path.GetDirectoryName(destino)!);
        ct.ThrowIfCancellationRequested();
        try
        {
            using (var fuente = AbrirArchivo(origen, escritura: false))
            using (var copia = AbrirArchivo(destino, escritura: true))
            {
                fuente.BackupDatabase(copia);
                ct.ThrowIfCancellationRequested();
                // La cola JSON del protocolo anterior nunca se sube en el archivo nuevo.
                using var q = copia.CreateCommand();
                q.CommandText = "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name='myg_colaboracion_local')";
                if ((long)q.ExecuteScalar()! != 0)
                {
                    q.CommandText = "DROP TABLE myg_colaboracion_local"; q.ExecuteNonQuery();
                    q.CommandText = "VACUUM"; q.ExecuteNonQuery();
                }
                q.CommandText = "PRAGMA journal_mode=DELETE"; q.ExecuteScalar();
                q.CommandText = "PRAGMA quick_check";
                if (!string.Equals(q.ExecuteScalar() as string, "ok", StringComparison.Ordinal))
                    throw new InvalidDataException("La instantánea SQLite no pasó la verificación de integridad.");
            }
            ArchivoPublicacionSqlitePendiente.NormalizarCopiaPortable(destino, origen, ct);
            using var archivo = new FileStream(destino, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
            archivo.Flush(flushToDisk: true);
            ct.ThrowIfCancellationRequested();
        }
        catch { Borrar(destino); throw; }
    }

    public static async Task<ResultadoSincronizacion> EjecutarAsync(ClienteSupabase cliente, string ruta,
        MYGProyectoDocumento documento, bool soloLeer = false, CancellationToken ct = default,
        IProgress<string>? progreso = null)
    {
        var cerrojo = Exclusion(ruta); await cerrojo.WaitAsync(ct);
        string? candidato = null;
        try
        {
            using var c = AbrirEstado(ruta);
            var estado = LeerEstado(c, documento.Id) ?? throw new InvalidOperationException("La copia no está vinculada a un archivo SQLite de nube.");
            ValidarIdentidad(cliente, estado);
            progreso?.Report("Preparando una instantánea SQLite consistente, incluidos los cambios WAL…");
            candidato = Temporal(ruta);
            CrearSnapshot(ruta, candidato, ct);
            string huella = Hash(candidato);
            var pendiente = LeerPendiente(c, documento.Id);
            if (pendiente is null && huella != estado.Hash)
            {
                pendiente = Congelar(ruta, candidato, huella, estado.Revision); candidato = null;
                EscribirPendiente(c, documento.Id, pendiente);
            }
            estado = estado with { Sucio = pendiente != null || huella != estado.Hash };
            EscribirEstado(c, estado);
            progreso?.Report("Consultando la revisión y los permisos del archivo SQLite…");
            ProyectoSqliteNube remoto;
            try { remoto = await cliente.AbrirSqliteAsync(estado.Proyecto, ct: ct); }
            catch (NubeException ex)
            {
                EscribirEstado(c, estado with { Conexion = ex.AccesoDenegado ? "acceso retirado" : ex.EsErrorDeConexion ? "sin conexión" : null });
                throw;
            }
            ValidarRemoto(estado, remoto);
            estado = estado with { Rol = remoto.Proyecto.Rol, Permisos = remoto.Proyecto.PermisosModulos?.Copiar(), Conexion = null };
            EscribirEstado(c, estado);
            if (remoto.Proyecto.Revision < estado.Revision)
                throw new NubeException("La nube devolvió una revisión anterior. Se conservan la copia y sus pendientes.");
            if (estado.Conflicto > 0) return new(documento, Adaptar(estado, pendiente));
            if (pendiente != null && !soloLeer && !PuedeEnviar(estado))
                throw new NubeException("Sincronizar un archivo SQLite completo requiere permiso de edición de todos los módulos. Se conservan la copia local y la operación pendiente; puede Recargar para consultar la nube.");
            if (pendiente != null && !soloLeer && PuedeEnviar(estado))
            {
                VerificarPendiente(pendiente);
                // Persistir ANTES del HTTP. Un ACK perdido conserva UUID, base y archivo idénticos.
                pendiente = pendiente with { Enviada = true };
                EscribirPendiente(c, documento.Id, pendiente);
                RespuestaSqliteNube respuesta;
                try { respuesta = await cliente.GuardarSqliteAsync(estado.Proyecto, pendiente.Id, pendiente.Revision, pendiente.Ruta, ct, progreso); }
                catch (NubeException ex)
                {
                    EscribirEstado(c, estado with { Conexion = ex.AccesoDenegado ? "acceso retirado" : ex.EsErrorDeConexion ? "sin conexión" : null });
                    throw;
                }
                if (respuesta.Estado == "conflicto")
                {
                    estado = estado with { Conflicto = respuesta.Revision };
                    EscribirEstado(c, estado);
                    progreso?.Report("Conflicto: se conservan el archivo local y la instantánea pendiente…");
                    return new(documento, Adaptar(estado, pendiente));
                }
                if (respuesta.OperacionId != pendiente.Id || respuesta.Revision != pendiente.Revision + 1 ||
                    !string.Equals(respuesta.Archivo.Sha256, pendiente.Hash, StringComparison.OrdinalIgnoreCase))
                    throw new NubeException("La confirmación SQLite no corresponde a la operación pendiente.");
                estado = estado with { Revision = respuesta.Revision, Hash = pendiente.Hash, Sucio = false };
                using (var t = c.BeginTransaction())
                {
                    EscribirEstado(c, estado, t);
                    Ejecutar(c, "DELETE FROM pendiente WHERE documento=$p0", t, documento.Id);
                    t.Commit();
                }
                Borrar(pendiente.Ruta); pendiente = null;
                remoto = await cliente.AbrirSqliteAsync(estado.Proyecto, ct: ct);
                ValidarRemoto(estado, remoto);
            }
            if (remoto.Proyecto.Revision > estado.Revision)
            {
                if (pendiente != null)
                {
                    // Un envío sin ACK puede ser exactamente esta revisión; reintentar el UUID lo decide.
                    if (!pendiente.Enviada) estado = estado with { Conflicto = remoto.Proyecto.Revision };
                    EscribirEstado(c, estado);
                    return new(documento, Adaptar(estado, pendiente));
                }
                progreso?.Report("Descargando la nueva revisión como archivo SQLite sin comprimir…");
                string descarga = Temporal(ruta);
                try
                {
                    await cliente.DescargarSqliteAsync(remoto, descarga, ct, progreso);
                    ValidarDocumento(descarga, documento.Id);
                    var incorporado = AplicarRemoto(ruta, descarga, estado.Hash, ct, progreso);
                    if (!incorporado)
                    {
                        estado = estado with { Conflicto = remoto.Proyecto.Revision, Sucio = true };
                        EscribirEstado(c, estado);
                        return new(documento, Adaptar(estado, null));
                    }
                    string confirmada = Temporal(ruta);
                    try { CrearSnapshot(ruta, confirmada, ct); estado = estado with { Hash = Hash(confirmada) }; }
                    finally { Borrar(confirmada); }
                    estado = estado with { Revision = remoto.Proyecto.Revision, Conflicto = 0, Sucio = false };
                    EscribirEstado(c, estado);
                    documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documento.Id);
                }
                finally { Borrar(descarga); }
            }
            // Una edición externa durante la transferencia queda marcada para el siguiente envío.
            string final = Temporal(ruta);
            try
            {
                CrearSnapshot(ruta, final, ct);
                estado = estado with { Sucio = LeerPendiente(c, documento.Id) != null || Hash(final) != estado.Hash };
                EscribirEstado(c, estado);
            }
            finally { Borrar(final); }
            progreso?.Report(estado.Sucio ? "Archivo guardado; hay cambios locales pendientes…" : "Archivo SQLite sincronizado…");
            return new(documento, Adaptar(estado, LeerPendiente(c, documento.Id)));
        }
        finally { if (candidato != null) Borrar(candidato); cerrojo.Release(); }
    }

    public static void ResolverMantenerLocal(string ruta, string documentoId)
    {
        var cerrojo = Exclusion(ruta); cerrojo.Wait();
        try
        {
            using var c = AbrirEstado(ruta);
            var estado = LeerEstado(c, documentoId) ?? throw new InvalidOperationException("No existe vínculo SQLite.");
            if (estado.Conflicto <= 0) return;
            if (!PuedeEnviar(estado)) throw new InvalidOperationException("No dispone de permiso para mantener la revisión local.");
            var anterior = LeerPendiente(c, documentoId);
            using var t = c.BeginTransaction();
            EscribirEstado(c, estado with { Revision = estado.Conflicto, Conflicto = 0, Hash = "", Sucio = true }, t);
            Ejecutar(c, "DELETE FROM pendiente WHERE documento=$p0", t, documentoId);
            t.Commit();
            if (anterior != null) Borrar(anterior.Ruta);
        }
        finally { cerrojo.Release(); }
    }

    public static async Task<ResultadoSincronizacion> ResolverUsarRemotoAsync(ClienteSupabase cliente, string ruta,
        MYGProyectoDocumento documento, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        var cerrojo = Exclusion(ruta); await cerrojo.WaitAsync(ct);
        try
        {
            using var c = AbrirEstado(ruta);
            var estado = LeerEstado(c, documento.Id) ?? throw new InvalidOperationException("No existe vínculo SQLite.");
            ValidarIdentidad(cliente, estado);
            if (estado.Conflicto <= 0) throw new InvalidOperationException("No existe un conflicto SQLite pendiente.");
            var remoto = await cliente.AbrirSqliteAsync(estado.Proyecto, ct: ct);
            ValidarRemoto(estado, remoto);
            string descarga = Temporal(ruta), actual = Temporal(ruta);
            try
            {
                CrearSnapshot(ruta, actual, ct);
                await cliente.DescargarSqliteAsync(remoto, descarga, ct, progreso);
                ValidarDocumento(descarga, documento.Id);
                if (!AplicarRemoto(ruta, descarga, Hash(actual), ct, progreso))
                    throw new IOException("El archivo local cambió durante la descarga. Se conserva y puede volver a resolver el conflicto.");
                Borrar(actual); CrearSnapshot(ruta, actual, ct);
                var pendiente = LeerPendiente(c, documento.Id);
                estado = estado with { Revision = remoto.Proyecto.Revision, Hash = Hash(actual), Sucio = false,
                    Conflicto = 0, Conexion = null, Rol = remoto.Proyecto.Rol, Permisos = remoto.Proyecto.PermisosModulos?.Copiar() };
                using var t = c.BeginTransaction();
                EscribirEstado(c, estado, t); Ejecutar(c, "DELETE FROM pendiente WHERE documento=$p0", t, documento.Id); t.Commit();
                if (pendiente != null) Borrar(pendiente.Ruta);
                return new(ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documento.Id), Adaptar(estado, null));
            }
            finally { Borrar(descarga); Borrar(actual); }
        }
        finally { cerrojo.Release(); }
    }

    private static bool AplicarRemoto(string ruta, string descarga, string esperada, CancellationToken ct, IProgress<string>? progreso)
    {
        string comprobar = Temporal(ruta);
        using var local = AbrirArchivo(ruta, escritura: true);
        // Retener el bloqueo exclusivo tras COMMIT impide una escritura externa
        // entre la comprobación de huella y la sustitución mediante SQLite Backup.
        using (var q = local.CreateCommand()) { q.CommandText = "PRAGMA locking_mode=EXCLUSIVE"; q.ExecuteScalar(); }
        using (var t = local.BeginTransaction())
        {
            using var q = local.CreateCommand(); q.Transaction = t;
            q.CommandText = "SELECT count(*) FROM sqlite_master"; q.ExecuteScalar(); t.Commit();
        }
        try
        {
            using (var copia = AbrirArchivo(comprobar, escritura: true)) local.BackupDatabase(copia);
            NormalizarSnapshot(comprobar, ruta, ct);
            if (Hash(comprobar) != esperada) return false;
            ct.ThrowIfCancellationRequested();
            string respaldo = Path.Combine(Carpeta(ruta), "respaldo-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.Move(comprobar, respaldo);
            progreso?.Report("Aplicando la revisión SQLite; la copia local anterior queda respaldada…");
            using var remoto = AbrirArchivo(descarga, escritura: false);
            remoto.BackupDatabase(local);
            return true;
        }
        finally { Borrar(comprobar); }
    }

    private static void NormalizarSnapshot(string ruta, string origen, CancellationToken ct)
    {
        using (var c = AbrirArchivo(ruta, escritura: true))
        {
            using var q = c.CreateCommand(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name='myg_colaboracion_local')";
            if ((long)q.ExecuteScalar()! != 0)
            { q.CommandText = "DROP TABLE myg_colaboracion_local"; q.ExecuteNonQuery(); q.CommandText = "VACUUM"; q.ExecuteNonQuery(); }
            q.CommandText = "PRAGMA journal_mode=DELETE"; q.ExecuteScalar();
        }
        ArchivoPublicacionSqlitePendiente.NormalizarCopiaPortable(ruta, origen, ct);
    }

    private static void ValidarDocumento(string ruta, string documento)
    {
        if (MYGBaseDatos.LeerProyecto(ruta, documento).Id != documento)
            throw new InvalidDataException("El SQLite recibido no contiene el documento esperado.");
    }

    private static void ValidarRemoto(Estado estado, ProyectoSqliteNube remoto)
    {
        if (remoto.Proyecto.Id != estado.Proyecto || remoto.DocumentoId != estado.Documento)
            throw new NubeException("El archivo remoto no corresponde a esta copia de trabajo.");
    }

    private static void ValidarIdentidad(ClienteSupabase cliente, Estado estado)
    {
        if (!cliente.SesionIniciada || cliente.UsuarioId != estado.Usuario ||
            !string.Equals(cliente.UrlServidor.TrimEnd('/'), estado.Servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            throw new NubeException("Inicie la misma sesión de nube que está vinculada a esta copia SQLite.", necesitaIniciarSesion: true);
    }

    private static bool PuedeEnviar(Estado estado) => SincronizadorProyectoNube.PuedeEditar(estado.Rol) &&
        estado.Conexion != "acceso retirado" && estado.Permisos is { Acu: true, Especificaciones: true, MetradosExcel: true };

    private static MYGVinculoNube Adaptar(Estado e, Pendiente? p) => new()
    {
        ProyectoId = e.Proyecto, Servidor = e.Servidor, UsuarioId = e.Usuario, Rol = e.Rol,
        Revision = e.Revision, PermisosModulos = e.Permisos?.Copiar(), EstadoConexion = e.Conexion,
        Estado = e.Conflicto > 0 ? "conflicto" : p != null || e.Sucio ? "pendiente" : "sincronizado",
        JsonRemotoConflicto = e.Conflicto > 0 ? "sqlite" : null, RevisionRemotaConflicto = e.Conflicto,
        Pendiente = p != null ? new MYGOperacionNube { Id = p.Id, RevisionBase = p.Revision, Enviada = p.Enviada }
            : e.Sucio ? new MYGOperacionNube { RevisionBase = e.Revision } : null
    };

    private static Pendiente Congelar(string ruta, string candidato, string hash, long revision)
    {
        Guid id = Guid.NewGuid(); string destino = Path.Combine(Carpeta(ruta), "pendiente-" + id.ToString("N") + ".sqlite");
        File.Move(candidato, destino);
        return new(id, revision, destino, hash, new FileInfo(destino).Length, false);
    }

    private static void VerificarPendiente(Pendiente p)
    {
        if (!File.Exists(p.Ruta) || new FileInfo(p.Ruta).Length != p.Bytes || Hash(p.Ruta) != p.Hash)
            throw new IOException("La instantánea pendiente falta o cambió. No se enviará otro cuerpo con el mismo UUID.");
    }

    private static string Temporal(string ruta)
    { Directory.CreateDirectory(Carpeta(ruta)); return Path.Combine(Carpeta(ruta), "temporal-" + Guid.NewGuid().ToString("N") + ".sqlite"); }
    private static string Hash(string ruta)
    { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)).ToLowerInvariant(); }
    private static void Borrar(string ruta) { if (File.Exists(ruta)) File.Delete(ruta); }

    private static SqliteConnection AbrirArchivo(string ruta, bool escritura)
    {
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = Path.GetFullPath(ruta),
            Mode = escritura ? SqliteOpenMode.ReadWriteCreate : SqliteOpenMode.ReadOnly, Pooling = false,
            DefaultTimeout = 15 }.ToString());
        try { c.Open(); return c; } catch { c.Dispose(); throw; }
    }

    private static SqliteConnection AbrirEstado(string ruta)
    {
        var c = AbrirArchivo(RutaEstado(ruta), escritura: true);
        try
        {
            Ejecutar(c, """
                CREATE TABLE IF NOT EXISTS vinculo(documento TEXT PRIMARY KEY,proyecto TEXT NOT NULL,servidor TEXT NOT NULL,
                  usuario TEXT NOT NULL,rol TEXT NOT NULL,revision INTEGER NOT NULL,hash TEXT NOT NULL,sucio INTEGER NOT NULL,
                  conflicto_revision INTEGER NOT NULL,conexion TEXT,acu INTEGER,especificaciones INTEGER,metrados INTEGER);
                CREATE TABLE IF NOT EXISTS pendiente(documento TEXT PRIMARY KEY REFERENCES vinculo(documento),operacion TEXT NOT NULL,
                  revision INTEGER NOT NULL,ruta TEXT NOT NULL,hash TEXT NOT NULL,bytes INTEGER NOT NULL,enviada INTEGER NOT NULL);
                """);
            return c;
        }
        catch { c.Dispose(); throw; }
    }

    private static Estado? LeerEstado(SqliteConnection c, string id)
    {
        using var q = c.CreateCommand(); q.CommandText = "SELECT documento,proyecto,servidor,usuario,rol,revision,hash,sucio,conflicto_revision,conexion,acu,especificaciones,metrados FROM vinculo WHERE documento=$p0";
        q.Parameters.AddWithValue("$p0", id); using var r = q.ExecuteReader();
        if (!r.Read()) return null;
        return new(r.GetString(0), Guid.Parse(r.GetString(1)), r.GetString(2), r.GetString(3), r.GetString(4),
            r.GetInt64(5), r.GetString(6), r.GetInt64(7) != 0, r.GetInt64(8), r.IsDBNull(9) ? null : r.GetString(9),
            r.IsDBNull(10) ? null : new MYGPermisosModulos { Acu = r.GetInt64(10) != 0, Especificaciones = r.GetInt64(11) != 0, MetradosExcel = r.GetInt64(12) != 0 });
    }

    private static Pendiente? LeerPendiente(SqliteConnection c, string id)
    {
        using var q = c.CreateCommand(); q.CommandText = "SELECT operacion,revision,ruta,hash,bytes,enviada FROM pendiente WHERE documento=$p0";
        q.Parameters.AddWithValue("$p0", id); using var r = q.ExecuteReader();
        return r.Read() ? new(Guid.Parse(r.GetString(0)), r.GetInt64(1), r.GetString(2), r.GetString(3), r.GetInt64(4), r.GetInt64(5) != 0) : null;
    }

    private static void EscribirEstado(SqliteConnection c, Estado e, SqliteTransaction? t = null) => Ejecutar(c, """
        INSERT INTO vinculo VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11,$p12)
        ON CONFLICT(documento) DO UPDATE SET proyecto=excluded.proyecto,servidor=excluded.servidor,usuario=excluded.usuario,
          rol=excluded.rol,revision=excluded.revision,hash=excluded.hash,sucio=excluded.sucio,conflicto_revision=excluded.conflicto_revision,
          conexion=excluded.conexion,acu=excluded.acu,especificaciones=excluded.especificaciones,metrados=excluded.metrados
        """, t, e.Documento, e.Proyecto.ToString("D"), e.Servidor, e.Usuario, e.Rol, e.Revision, e.Hash,
            e.Sucio ? 1 : 0, e.Conflicto, e.Conexion, e.Permisos?.Acu, e.Permisos?.Especificaciones, e.Permisos?.MetradosExcel);

    private static void EscribirPendiente(SqliteConnection c, string id, Pendiente p) => Ejecutar(c, """
        INSERT INTO pendiente VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6)
        ON CONFLICT(documento) DO UPDATE SET operacion=excluded.operacion,revision=excluded.revision,ruta=excluded.ruta,
          hash=excluded.hash,bytes=excluded.bytes,enviada=excluded.enviada
        """, id, p.Id.ToString("D"), p.Revision, p.Ruta, p.Hash, p.Bytes, p.Enviada ? 1 : 0);

    private static void Ejecutar(SqliteConnection c, string sql, params object?[] valores) => Ejecutar(c, sql, null, valores);
    private static void Ejecutar(SqliteConnection c, string sql, SqliteTransaction? t, params object?[] valores)
    {
        using var q = c.CreateCommand(); q.Transaction = t; q.CommandText = sql;
        for (int i = 0; i < valores.Length; i++) q.Parameters.AddWithValue("$p" + i, valores[i] ?? DBNull.Value);
        q.ExecuteNonQuery();
    }
}
