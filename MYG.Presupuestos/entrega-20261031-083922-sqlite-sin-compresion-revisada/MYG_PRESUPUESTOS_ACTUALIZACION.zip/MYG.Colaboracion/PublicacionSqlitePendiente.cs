using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

public sealed record PublicacionSqlitePendiente(Guid Id, string Nombre, string Alcance,
    string DocumentoId, string RutaSQLite, string Sha256, long BytesArchivo, DateTime FechaUtc);

/// <summary>Una copia SQLite durable e inmutable por servidor y cuenta. El contenido
/// no se serializa, comprime ni incluye dentro de los metadatos de la publicación.</summary>
public sealed class ArchivoPublicacionSqlitePendiente
{
    public const string ReferenciaPropia = "MYG_SQLITE_LOCAL";
    private const long MaxBytes = 300L * 1024 * 1024;
    private readonly string carpeta, ambito, metadata;
    // Mantener el esquema MYG y sus mapas de datos. Sólo se retiran accesos,
    // configuración del equipo y colas de colaboración de la COPIA a compartir.
    private static readonly HashSet<string> Privadas = new(StringComparer.OrdinalIgnoreCase)
    {
        "usuario", "usuario_map", "perfil", "perfil_map", "roles_sucursal", "SESION_CAJA",
        "log_objs_changes", "messages_app", "myg_colaboracion_local", "myg_nube_sqlite_local"
    };

    public ArchivoPublicacionSqlitePendiente(string carpetaPublicaciones, string servidor, string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(carpetaPublicaciones)) throw new ArgumentException("Indique la carpeta de publicaciones.");
        if (!Uri.TryCreate(servidor, UriKind.Absolute, out var uri) || uri.Scheme != Uri.UriSchemeHttps
            || uri.UserInfo.Length != 0 || uri.AbsolutePath != "/" || uri.Query.Length != 0 || uri.Fragment.Length != 0)
            throw new ArgumentException("Indique el servidor HTTPS de nube sin credenciales ni rutas.");
        if (!Guid.TryParse(usuarioId, out var usuario) || usuario == Guid.Empty)
            throw new ArgumentException("La cuenta de nube necesita una identidad válida.");
        carpeta = Path.GetFullPath(carpetaPublicaciones);
        ambito = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(uri.GetLeftPart(UriPartial.Authority) + "\n" + usuario.ToString("D"))));
        metadata = Path.Combine(carpeta, ambito + ".publicacion.sqlite");
    }

    public PublicacionSqlitePendiente? Consultar()
    {
        if (!File.Exists(metadata)) return null;
        using var c = Abrir(metadata, soloLectura: true);
        return Leer(c);
    }

    public PublicacionSqlitePendiente Crear(string nombre, string alcance, MYGProyectoDocumento documento,
        string? origen, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        nombre = nombre?.Trim() ?? "";
        if (nombre.Length is < 1 or > 200 || nombre.Any(char.IsControl) || alcance is not ("obra" or "base"))
            throw new ArgumentException("Indique un nombre y alcance válidos para la publicación.");
        ArgumentNullException.ThrowIfNull(documento);
        ct.ThrowIfCancellationRequested();
        Directory.CreateDirectory(carpeta);
        using var bloqueo = Bloquear();
        using var c = Abrir(metadata);
        PrepararEsquema(c);
        if (Leer(c) is not null) throw new IOException("Ya existe una publicación SQLite pendiente para esta cuenta. Reinténtela antes de crear otra.");
        Guid id = Guid.NewGuid();
        string salida = Path.Combine(carpeta, ambito + "-" + id.ToString("N") + ".sqlite");
        try
        {
            progreso?.Report("Preparando una copia SQLite sin comprimir");
            PrepararCopia(salida, documento, origen, alcance, ct);
            ct.ThrowIfCancellationRequested();
            long bytes = new FileInfo(salida).Length;
            if (bytes is < 100 or > MaxBytes) throw new InvalidDataException("La copia SQLite debe ocupar entre 100 bytes y 300 MiB. No se comprimirá automáticamente.");
            string sha = Hash(salida);
            var pendiente = new PublicacionSqlitePendiente(id, nombre, alcance, documento.Id, salida, sha, bytes, DateTime.UtcNow);
            // Flush antes del commit que hace visible el intento. Si el proceso
            // cae antes de este commit sólo puede quedar una copia huérfana.
            using (var archivo = new FileStream(salida, FileMode.Open, FileAccess.ReadWrite, FileShare.Read)) archivo.Flush(true);
            using var t = c.BeginTransaction();
            using var cmd = c.CreateCommand(); cmd.Transaction = t;
            cmd.CommandText = "INSERT INTO publicacion(id,nombre,alcance,documento_id,ruta,sha256,bytes,fecha_utc) VALUES($id,$nombre,$alcance,$documento,$ruta,$sha,$bytes,$fecha)";
            cmd.Parameters.AddWithValue("$id", id.ToString("D")); cmd.Parameters.AddWithValue("$nombre", nombre);
            cmd.Parameters.AddWithValue("$alcance", alcance); cmd.Parameters.AddWithValue("$documento", documento.Id);
            cmd.Parameters.AddWithValue("$ruta", Path.GetFileName(salida)); cmd.Parameters.AddWithValue("$sha", sha);
            cmd.Parameters.AddWithValue("$bytes", bytes); cmd.Parameters.AddWithValue("$fecha", pendiente.FechaUtc.ToString("O"));
            cmd.ExecuteNonQuery(); t.Commit();
            return pendiente;
        }
        catch
        {
            // No retirar una copia si el intento ya llegó a hacerse durable.
            if (Leer(c)?.Id != id) BorrarPreparacion(salida);
            throw;
        }
    }

    /// <summary>Valida los bytes congelados antes de reenviarlos, sin cargarlos en memoria.</summary>
    public PublicacionSqlitePendiente Leer(PublicacionSqlitePendiente esperado)
    {
        using var bloqueo = Bloquear();
        if (!File.Exists(metadata)) throw new FileNotFoundException("No existe una publicación pendiente para esta cuenta.");
        using var c = Abrir(metadata, soloLectura: true);
        var actual = Requerir(c, esperado);
        if (new FileInfo(actual.RutaSQLite).Length != actual.BytesArchivo || !string.Equals(Hash(actual.RutaSQLite), actual.Sha256, StringComparison.Ordinal))
            throw new InvalidDataException("La copia de la publicación pendiente cambió. Consérvela y revise el intento antes de enviarlo.");
        return actual;
    }

    /// <summary>Requiere un ACK validado por el llamador. No borra el archivo:
    /// conserva una copia recuperable aun si el proceso cae inmediatamente después.</summary>
    public void Confirmar(PublicacionSqlitePendiente esperado)
    {
        using var bloqueo = Bloquear();
        if (!File.Exists(metadata)) throw new FileNotFoundException("No existe una publicación pendiente para esta cuenta.");
        using var c = Abrir(metadata);
        Requerir(c, esperado);
        using var cmd = c.CreateCommand(); cmd.CommandText = "DELETE FROM publicacion WHERE id=$id";
        cmd.Parameters.AddWithValue("$id", esperado.Id.ToString("D")); cmd.ExecuteNonQuery();
    }

    public string Retirar(PublicacionSqlitePendiente esperado)
    {
        // La copia queda preservada en su misma ruta. Retirar sólo abandona el
        // intento activo; jamás elimina el archivo origen ni algo en la nube.
        Confirmar(esperado);
        return esperado.RutaSQLite;
    }

    public static void PrepararCopia(string destino, MYGProyectoDocumento documento, string? origen,
        string alcance, CancellationToken ct = default)
    {
        destino = Path.GetFullPath(destino);
        if (File.Exists(destino)) throw new IOException("La copia SQLite necesita un destino nuevo.");
        if (alcance is not ("obra" or "base")) throw new ArgumentException("El alcance debe ser obra o base.");
        if (alcance == "base" && (string.IsNullOrWhiteSpace(origen) || !File.Exists(origen)))
            throw new FileNotFoundException("Seleccione la base SQLite que desea compartir completa.", origen);
        var documentos = alcance == "base"
            ? MYGBaseDatos.ListarProyectos(origen!).Select(p => MYGBaseDatos.LeerProyecto(origen!, p.Id)).ToList()
            : new List<MYGProyectoDocumento> { documento };
        foreach (var d in documentos) ExigirSinRecursosExternos(d);
        ct.ThrowIfCancellationRequested();
        Directory.CreateDirectory(Path.GetDirectoryName(destino)!);
        try
        {
            if (alcance == "base")
            {
                using var fuente = Abrir(origen!, soloLectura: true);
                using var salida = Abrir(destino);
                fuente.BackupDatabase(salida);
            }
            else
            {
                // Crear primero evita que Guardar como copie la hoja completa.
                // Se reutiliza el exportador SQL de proyecto y catálogos del núcleo.
                MYGBaseDatos.CrearBaseVacia(destino);
                MYGProyectoStorage.Guardar(destino, MYGProyectoStorage.Copia(documento), origen);
            }
            ct.ThrowIfCancellationRequested();
            SanitizarCopia(destino, alcance, origen, ct);
            // Un backup físico también copia páginas libres. Reconstruir sólo
            // la copia publicada elimina restos de filas privadas ya borradas;
            // VACUUM conserva SQLite sin aplicar compresión.
            using (var limpia = Abrir(destino))
            using (var q = limpia.CreateCommand()) { q.CommandText = "VACUUM"; q.ExecuteNonQuery(); }
            var recuperado = MYGBaseDatos.LeerProyecto(destino, documento.Id);
            var esperado = MYGProyectoStorage.Copia(documento);
            RebasarReferencias(esperado, valor => NormalizarReferencia(valor, origen));
            if (MYGProyectoStorage.Firma(recuperado) != MYGProyectoStorage.Firma(esperado))
                throw new InvalidDataException("La copia SQL no conserva toda la obra seleccionada. No se publicó ni modificó el original.");
            if (alcance == "obra" && MYGBaseDatos.ListarProyectos(destino).Any(p => p.Id != documento.Id))
                throw new InvalidDataException("La copia de una obra contiene otro proyecto. No se publicará.");
        }
        catch { BorrarPreparacion(destino); throw; }
    }

    /// <summary>Reubica únicamente las autorreferencias portables en memoria;
    /// no cambia el archivo descargado ni sus hashes de integridad.</summary>
    public static MYGProyectoDocumento CargarDocumentoPortable(string ruta, string id)
    {
        var documento = MYGBaseDatos.LeerProyecto(ruta, id);
        ReubicarDocumentoPortable(documento, ruta);
        return documento;
    }

    public static void ReubicarDocumentoPortable(MYGProyectoDocumento documento, string ruta)
    {
        ArgumentNullException.ThrowIfNull(documento);
        string destino = Path.GetFullPath(ruta);
        RebasarReferencias(documento, valor => valor == ReferenciaPropia ? destino : valor);
    }

    /// <summary>Prepara una instantánea ya creada con BackupDatabase. Es
    /// idempotente: no reescribe los JSON internos si ya usan el alias propio.</summary>
    public static void NormalizarCopiaPortable(string destino, string origen, CancellationToken ct = default)
    {
        if (string.Equals(Path.GetFullPath(destino), Path.GetFullPath(origen), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("La normalización portable sólo puede ejecutarse sobre una copia distinta del archivo de trabajo.");
        SanitizarCopia(Path.GetFullPath(destino), "base", Path.GetFullPath(origen), ct);
    }

    private static void SanitizarCopia(string destino, string alcance, string? origen, CancellationToken ct)
    {
        // El esquema de referencia sólo sirve para reconocer extensiones; nunca
        // se reconstruye ni se serializa el contenido de la copia de base completa.
        string patron = destino + ".esquema.sqlite";
        try
        {
            MYGBaseDatos.CrearBaseVacia(patron);
            using var referencia = Abrir(patron, true);
            var conocidas = Tablas(referencia).ToHashSet(StringComparer.OrdinalIgnoreCase);
            using var c = Abrir(destino);
            // Activarlo antes de reubicar rutas evita conservar sus valores
            // anteriores en fragmentos libres de las páginas actualizadas.
            using (var privacidad = c.CreateCommand())
            { privacidad.CommandText = "PRAGMA secure_delete=ON; PRAGMA foreign_keys=OFF;"; privacidad.ExecuteNonQuery(); }
            var tablas = Tablas(c);
            if (alcance == "base")
                foreach (string tabla in tablas.Where(t => !conocidas.Contains(t) && !Privadas.Contains(t)))
                {
                    using var cuenta = c.CreateCommand(); cuenta.CommandText = "SELECT EXISTS(SELECT 1 FROM " + Identificador(tabla) + " LIMIT 1)";
                    if (Convert.ToInt64(cuenta.ExecuteScalar(), CultureInfo.InvariantCulture) != 0)
                        throw new InvalidDataException("La base contiene la extensión '" + tabla + "', cuyo alcance y datos privados no están definidos. Publique una obra o revise esa extensión antes de compartir toda la base.");
                }
            // Escaneo por fila de los JSON ya existentes en la base. Sólo valida
            // rutas; no convierte tablas a JSON ni crea un paquete de datos.
            foreach (string tabla in tablas.Where(t => !Privadas.Contains(t)))
            {
                ct.ThrowIfCancellationRequested();
                foreach (string columna in ColumnasJson(c, tabla))
                {
                    // Sólo se mantienen los rowids y una fila de contenido a la
                    // vez; una tabla grande nunca se materializa como un paquete.
                    var filas = new List<long>();
                    using (var ids = c.CreateCommand())
                    {
                        ids.CommandText = "SELECT rowid FROM " + Identificador(tabla) + " WHERE " + Identificador(columna) + " IS NOT NULL";
                        using var r = ids.ExecuteReader(); while (r.Read()) filas.Add(r.GetInt64(0));
                    }
                    foreach (long fila in filas)
                    {
                        ct.ThrowIfCancellationRequested();
                        using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT " + Identificador(columna) + " FROM " + Identificador(tabla) + " WHERE rowid=$id";
                        cmd.Parameters.AddWithValue("$id", fila);
                        if (cmd.ExecuteScalar() is not string texto || string.IsNullOrWhiteSpace(texto)) continue;
                        try
                        {
                            using var json = JsonDocument.Parse(texto, new JsonDocumentOptions { MaxDepth = 128 }); ExigirSinRutas(json.RootElement);
                            var nodo = JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 });
                            if (NormalizarRutasJson(nodo, origen))
                            {
                                using var actualizar = c.CreateCommand();
                                actualizar.CommandText = "UPDATE " + Identificador(tabla) + " SET " + Identificador(columna) + "=$valor WHERE rowid=$id";
                                actualizar.Parameters.AddWithValue("$valor", nodo!.ToJsonString()); actualizar.Parameters.AddWithValue("$id", fila);
                                actualizar.ExecuteNonQuery();
                            }
                        }
                        catch (JsonException) { /* Una columna histórica no JSON queda intacta. */ }
                    }
                }
            }
            using (var pragma = c.CreateCommand()) { pragma.CommandText = "PRAGMA foreign_keys=OFF; PRAGMA secure_delete=ON;"; pragma.ExecuteNonQuery(); }
            using (var t = c.BeginTransaction())
            {
                foreach (string tabla in tablas.Where(Privadas.Contains))
                {
                    using var borrar = c.CreateCommand(); borrar.Transaction = t;
                    borrar.CommandText = "DELETE FROM " + Identificador(tabla); borrar.ExecuteNonQuery();
                }
                // Sólo se conserva el marcador nativo de migraciones. Los demás
                // parámetros son configuración del equipo/origen, no de la obra.
                if (tablas.Contains("parametro", StringComparer.OrdinalIgnoreCase))
                {
                    using var borrar = c.CreateCommand(); borrar.Transaction = t;
                    borrar.CommandText = "DELETE FROM parametro WHERE id_parametro <> 'last_updated'"; borrar.ExecuteNonQuery();
                }
                t.Commit();
            }
            using var comprobar = c.CreateCommand(); comprobar.CommandText = "PRAGMA quick_check";
            if (!string.Equals(comprobar.ExecuteScalar() as string, "ok", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("La copia SQLite no superó la comprobación de integridad.");
        }
        finally { BorrarPreparacion(patron); }
    }

    private static void ExigirSinRecursosExternos(object? valor)
    {
        var vistos = new HashSet<object>(ReferenceEqualityComparer.Instance);
        void Recorrer(object? actual)
        {
            if (actual is null || actual is string || actual.GetType().IsValueType || !vistos.Add(actual)) return;
            if (actual is IEnumerable lista) { foreach (object? hijo in lista) Recorrer(hijo); return; }
            foreach (var propiedad in actual.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (!propiedad.CanRead || propiedad.GetIndexParameters().Length != 0) continue;
                object? hijo = propiedad.GetValue(actual);
                if (EsRutaRecurso(propiedad.Name) && hijo is string ruta && !string.IsNullOrWhiteSpace(ruta))
                    throw RecursosExternos();
                Recorrer(hijo);
            }
        }
        Recorrer(valor);
    }

    private static void ExigirSinRutas(JsonElement valor)
    {
        if (valor.ValueKind == JsonValueKind.Object)
            foreach (var propiedad in valor.EnumerateObject())
            {
                if (EsRutaRecurso(propiedad.Name) && propiedad.Value.ValueKind == JsonValueKind.String
                    && !string.IsNullOrWhiteSpace(propiedad.Value.GetString())) throw RecursosExternos();
                ExigirSinRutas(propiedad.Value);
            }
        else if (valor.ValueKind == JsonValueKind.Array)
            foreach (var hijo in valor.EnumerateArray()) ExigirSinRutas(hijo);
    }

    private static bool EsRutaRecurso(string nombre) => nombre.Equals("ImagenRuta", StringComparison.OrdinalIgnoreCase)
        || nombre.Equals("FichaTecnicaRuta", StringComparison.OrdinalIgnoreCase);
    private static bool EsRutaBase(string nombre) => nombre.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase)
        || nombre.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase) || nombre.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase);
    private static string NormalizarReferencia(string valor, string? origen)
    {
        if (string.IsNullOrWhiteSpace(valor) || valor == ReferenciaPropia) return valor;
        if (origen != null)
        {
            string completa = Path.IsPathRooted(valor) ? Path.GetFullPath(valor) : Path.GetFullPath(valor, Path.GetDirectoryName(Path.GetFullPath(origen))!);
            if (string.Equals(completa, Path.GetFullPath(origen), StringComparison.OrdinalIgnoreCase)) return ReferenciaPropia;
        }
        throw new InvalidDataException("La obra depende de otro catálogo SQLite externo. Incorpore ese catálogo a la base antes de publicarla sin paquetes. El origen se conserva.");
    }
    private static bool NormalizarRutasJson(JsonNode? nodo, string? origen)
    {
        bool cambio = false;
        if (nodo is JsonObject objeto)
            foreach (var propiedad in objeto.ToList())
            {
                if (EsRutaBase(propiedad.Key) && propiedad.Value is JsonValue valor && valor.TryGetValue<string>(out var ruta) && !string.IsNullOrWhiteSpace(ruta))
                {
                    string portable = NormalizarReferencia(ruta, origen);
                    if (portable != ruta) { objeto[propiedad.Key] = portable; cambio = true; }
                }
                else cambio |= NormalizarRutasJson(propiedad.Value, origen);
            }
        else if (nodo is JsonArray lista)
            foreach (var hijo in lista) cambio |= NormalizarRutasJson(hijo, origen);
        return cambio;
    }
    private static void RebasarReferencias(object? valor, Func<string, string> reemplazar)
    {
        var vistos = new HashSet<object>(ReferenceEqualityComparer.Instance);
        void Recorrer(object? actual)
        {
            if (actual is null || actual is string || actual.GetType().IsValueType || !vistos.Add(actual)) return;
            if (actual is IEnumerable lista) { foreach (object? hijo in lista) Recorrer(hijo); return; }
            foreach (var propiedad in actual.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (!propiedad.CanRead || propiedad.GetIndexParameters().Length != 0) continue;
                object? hijo = propiedad.GetValue(actual);
                if (EsRutaBase(propiedad.Name) && propiedad.CanWrite && hijo is string ruta && !string.IsNullOrWhiteSpace(ruta))
                    propiedad.SetValue(actual, reemplazar(ruta));
                else Recorrer(hijo);
            }
        }
        Recorrer(valor);
    }
    private static InvalidDataException RecursosExternos() => new("Esta obra usa imágenes o fichas técnicas externas a SQLite. La publicación sin paquetes no las incluiría; incorpórelas a la base o retire esas referencias antes de publicar. El original se conserva.");
    private static string Identificador(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";
    private static List<string> Tablas(SqliteConnection c)
    {
        using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'";
        using var r = cmd.ExecuteReader(); var tablas = new List<string>(); while (r.Read()) tablas.Add(r.GetString(0)); return tablas;
    }
    private static List<string> ColumnasJson(SqliteConnection c, string tabla)
    {
        using var cmd = c.CreateCommand(); cmd.CommandText = "PRAGMA table_info(" + Identificador(tabla) + ")";
        using var r = cmd.ExecuteReader(); var columnas = new List<string>();
        while (r.Read()) { string nombre = r.GetString(1); if (nombre.StartsWith("json_", StringComparison.OrdinalIgnoreCase)) columnas.Add(nombre); }
        return columnas;
    }
    private PublicacionSqlitePendiente? Leer(SqliteConnection c)
    {
        using var cmd = c.CreateCommand(); cmd.CommandText = "SELECT id,nombre,alcance,documento_id,ruta,sha256,bytes,fecha_utc FROM publicacion";
        using var r = cmd.ExecuteReader(); if (!r.Read()) return null;
        string nombreArchivo = r.GetString(4);
        if (Path.GetFileName(nombreArchivo) != nombreArchivo || !nombreArchivo.StartsWith(ambito + "-", StringComparison.Ordinal)
            || !Guid.TryParse(r.GetString(0), out var id) || id == Guid.Empty || r.GetString(2) is not ("obra" or "base")
            || r.GetInt64(6) is < 100 or > MaxBytes || r.GetString(5).Length != 64 || !r.GetString(5).All(Uri.IsHexDigit))
            throw new InvalidDataException("Los metadatos del intento SQLite no son válidos. Conserve sus archivos antes de recuperarlo.");
        var resultado = new PublicacionSqlitePendiente(id, r.GetString(1), r.GetString(2), r.GetString(3), Path.Combine(carpeta, nombreArchivo),
            r.GetString(5), r.GetInt64(6), DateTime.Parse(r.GetString(7), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind));
        if (r.Read()) throw new InvalidDataException("Hay más de una publicación activa en el mismo ámbito.");
        return resultado;
    }
    private PublicacionSqlitePendiente Requerir(SqliteConnection c, PublicacionSqlitePendiente esperado)
    {
        var actual = Leer(c) ?? throw new FileNotFoundException("Ya no existe la publicación pendiente seleccionada.");
        if (actual != esperado) throw new InvalidOperationException("El intento pendiente cambió. Actualice la selección antes de continuar.");
        return actual;
    }
    private FileStream Bloquear() { Directory.CreateDirectory(carpeta); return new FileStream(metadata + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None); }
    private static string Hash(string ruta) { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }
    private static SqliteConnection Abrir(string ruta, bool soloLectura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = soloLectura ? SqliteOpenMode.ReadOnly : SqliteOpenMode.ReadWriteCreate, Pooling = false, DefaultTimeout = 15 }.ToString());
        c.Open(); return c;
    }
    private static void PrepararEsquema(SqliteConnection c)
    {
        using var cmd = c.CreateCommand(); cmd.CommandText = "PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS publicacion(id TEXT PRIMARY KEY,nombre TEXT NOT NULL,alcance TEXT NOT NULL,documento_id TEXT NOT NULL,ruta TEXT NOT NULL,sha256 TEXT NOT NULL,bytes INTEGER NOT NULL,fecha_utc TEXT NOT NULL);"; cmd.ExecuteNonQuery();
    }
    private static void BorrarPreparacion(string ruta)
    {
        foreach (string sufijo in new[] { "", "-wal", "-shm", "-journal" }) if (File.Exists(ruta + sufijo)) File.Delete(ruta + sufijo);
    }
}
