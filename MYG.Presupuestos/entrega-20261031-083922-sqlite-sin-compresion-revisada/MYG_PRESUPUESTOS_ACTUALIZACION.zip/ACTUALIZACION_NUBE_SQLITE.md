# Nube MYG: archivos SQLite sin compresión

Esta actualización continúa la ventana de progreso ya entregada. La aplicación publica y sincroniza archivos `.sqlite` reales en un bucket privado de Supabase Storage. No convierte las tablas en un paquete JSON, no usa Base64 para la base y no comprime su contenido. Las RPC intercambian únicamente metadatos pequeños: proyecto, revisión, UUID de operación, ruta, tamaño y SHA-256.

El formato interno existente de MYG dentro de SQLite no cambia: algunas tablas de la aplicación ya contienen campos JSON. Esos campos siguen dentro del archivo SQL original; no constituyen un paquete JSON de transporte.

## Instalar en el proyecto

1. Respaldar o confirmar los cambios locales antes de reemplazar archivos. La base del código de esta entrega es `main`, commit `4526fd76bbf429acb1368babcfc77545692541ae`.
2. Extraer el ZIP de actualización sobre la raíz del proyecto, conservando sus rutas. El paquete contiene archivos completos nuevos o modificados; no contiene bases de usuarios, credenciales ni dependencias restaurables.
3. Restaurar y compilar con SDK .NET 10.0.100 o compatible con `global.json`:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false -p:UseSharedCompilation=false
```

No se agregan paquetes NuGet nuevos. `UseRevitReferencePackages=true` permite verificar compilación sin una instalación local de Revit; ejecutar su conector requiere Revit 2027 en Windows.

## Actualizar Supabase

1. Conservar el respaldo y las modificaciones propias de su backend.
2. La instalación debe tener las migraciones anteriores de MYG, hasta `20261028_publicacion_comprimida.sql`, y los permisos por módulo. Si ya están instaladas, **no volver a ejecutar las migraciones históricas**: la actualización nueva conserva los proyectos anteriores.
3. Ejecutar completo `supabase/migraciones/20261030_archivos_sqlite.sql` en SQL Editor del mismo proyecto Supabase. Esta entrega no ejecuta cambios en el servicio remoto.
4. La migración crea el bucket privado `myg-nube-sqlite`, las RPC nativas, las revisiones y las políticas de acceso. No descomprime, sobrescribe ni elimina publicaciones antiguas. Si detecta una guarda o un bucket personalizado incompatible, se detiene para conservarlos.
5. El bucket admite hasta 300 MiB por archivo, sujeto también al límite global de Supabase Storage y del plan. Si el límite global es menor que la base, debe ajustarlo cuando su plan lo permita; la aplicación no recurrirá a comprimir ni convertir la base como alternativa.

La aplicación comprueba esta migración antes de publicar; si falta, conserva el archivo local y muestra el requisito.

## Proyectos nuevos y existentes

- **Crear / publicar** prepara una copia SQLite de una obra o de la base completa, según el alcance elegido. Una obra no incluye las otras obras de su archivo. La copia excluye cuentas de acceso y configuración local reconocidas, y descarta restos de filas eliminadas en páginas libres; el archivo de origen se conserva.
- Abra la publicación desde Nube MYG para trabajar sobre su copia vinculada. Publicar no vincula ni reemplaza automáticamente el archivo de origen.
- Los proyectos anteriores siguen disponibles para abrir, recargar y guardar una copia local. Para migrarlos: guardar esa copia y publicarla desde **Crear / publicar**. Se crea una publicación SQLite nueva; la publicación anterior conserva sus datos y miembros. Los colaboradores deben asignarse en la publicación nueva.
- Los intentos pendientes del formato anterior se conservan para recuperación. No se reenvían como JSON o GZip: revisar el intento, retirar conservando su copia y publicar la base en el formato nuevo.
- Sincronizar un proyecto antiguo no inicia otra compresión; indica cómo migrarlo.

## Recuperación y concurrencia

La base de trabajo permanece en disco. Su estado y cola se guardan como columnas SQL en un archivo adyacente `trabajo.sqlite.nube.sqlite`; las instantáneas pendientes y los respaldos están en `trabajo.sqlite.nube/`. No se duplica todo el documento como JSON en la cola de colaboración de la base.

Conservar juntos la base, el estado y la carpeta de pendientes cuando se necesite recuperar una copia vinculada. No borrar estos archivos para intentar resolver un conflicto. **Guardar copia local** crea una copia independiente cuando se desea separar el trabajo de la nube.

Cada envío conserva UUID, revisión y archivo inmutable hasta recibir una confirmación válida. Un corte de conexión permite reintentar la misma operación, aunque el servidor ya la hubiera recibido. Una revisión ajena genera conflicto y conserva el archivo local; usar la revisión remota mantiene un respaldo anterior. Las instantáneas incluyen los cambios pendientes del WAL de SQLite y se validan por cabecera, integridad y SHA-256.

La sincronización sin cambios no vuelve a escribir el documento ni sube otra base. Cuando existen cambios reales, se transfiere un archivo SQLite completo; su tiempo de transferencia depende del tamaño y la conexión. Las revisiones históricas consumen Storage y no se eliminan automáticamente.

## Permisos y alcance admitido

Los lectores pueden consultar y descargar según su membresía. Para subir un archivo SQLite completo se necesita un rol de escritura y permiso en todos los módulos. PostgreSQL no puede inspeccionar los módulos internos de un archivo SQLite opaco: por eso un colaborador con módulos restringidos no puede reemplazarlo entero. El backend aplica esta restricción y la aplicación conserva sus cambios locales si no puede enviarlos.

Los BLOB ya incluidos en SQLite se conservan. Si una obra depende de imágenes, fichas técnicas o catálogos externos que no están incorporados en su base, la publicación se detiene con una explicación; no los omite silenciosamente. Las extensiones desconocidas con datos también requieren revisar su alcance antes de compartir una base completa.

## Validación

Pruebas funcionales portables, con SQLite real y HTTP simulado:

```powershell
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
```

La opción `--sqlite-nativo` del segundo ejecutable permite comprobar únicamente transporte, publicación pendiente y sincronización nativa. Las pruebas SQL usan PostgreSQL 17 desechable mediante `bash scripts/pruebas/Probar-ArchivosSqlite.sh`; no usan la base Supabase real.

Resultados de esta entrega: solución Release con 0 errores y 0 advertencias; núcleo 750 comprobaciones; nube 43 grupos principales y 982 comprobaciones del contrato HTTP general, además de las suites internas. Las pruebas nuevas de SQLite aprobaron 163 comprobaciones de transporte, 21 de publicación pendiente y 29 de sincronización/recuperación. Las 32 aserciones SQL terminaron correctamente en PostgreSQL 17 desechable, incluida concurrencia real. La interfaz de Windows se compiló, pero no se ejecutó en Linux.

La optimización de confirmación conservó las comprobaciones de identidad y concurrencia: cuando el documento ya está guardado, el ACK actualiza solo metadatos. En el benchmark sintético de 120 partidas y documento de aproximadamente 2 MiB, la mediana de confirmación pasó de 665 a 379 ms y las asignaciones de memoria de 982 a 178 MB; las reinserciones de partidas pasaron de 120 a 0. Son medidas locales de esa fase, no una promesa del tiempo total de transferencia de sus proyectos.

Prueba visual, **solo en Windows**:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --nube-progreso
```

Comprobar manualmente publicación, apertura, Sincronizar, Recargar y reconexión con una copia de un proyecto representativo. La compilación en Linux no valida la ejecución visual de Windows, el servidor Supabase instalado ni Revit.

## Publicar el código

El ZIP se entrega en el repositorio independiente `bimchimbote-droid/DESCARGAS`. No se publica automáticamente el repositorio del código. Después de aplicar y validar los archivos, revisar Cambios de Git en Visual Studio, realizar el commit, hacer push y verificar la rama `main` en GitHub.
