using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace MYG_2027;

/// <summary>Instantánea independiente de los datos que se crearán en Project.
/// No contiene objetos COM ni requiere un archivo de intercambio.</summary>
public sealed record MYGModeloExportacionProject(
    string Nombre, DateTime Inicio, DateTime Fin, DateTime FechaEstado,
    int MinutosPorDia, int MinutosPorSemana, string Moneda,
    MYGCalendarioExportacionProject Calendario,
    IReadOnlyList<MYGTareaExportacionProject> Tareas,
    IReadOnlyList<MYGRecursoExportacionProject> Recursos,
    IReadOnlyList<MYGAsignacionExportacionProject> Asignaciones,
    IReadOnlyList<MYGDependenciaExportacionProject> Dependencias,
    IReadOnlyList<string> Advertencias)
{
    public IReadOnlyDictionary<int, IReadOnlyList<MYGTramoTareaExportacionProject>> TramosPorTarea { get; init; } =
        new ReadOnlyDictionary<int, IReadOnlyList<MYGTramoTareaExportacionProject>>(new Dictionary<int, IReadOnlyList<MYGTramoTareaExportacionProject>>());
}

public sealed record MYGTareaExportacionProject(
    int Uid, string IdMYG, int PadreUid, int Nivel, string Esquema, string Codigo, string Nombre,
    bool Manual, bool Resumen, bool Hito, bool Critica,
    DateTime Inicio, DateTime Fin, decimal DuracionMinutos, decimal Avance,
    DateTime? InicioBase, DateTime? FinBase, decimal? DuracionBaseMinutos, string Notas)
{
    // Identifica fechas de Delphin aún vigentes en el modelo de origen.
    // Sirven para comparar e informar el recálculo; no imponen restricciones
    // de programación a Project.
    public bool ConservarFechasImportadas { get; init; }
}

public sealed record MYGTramoTareaExportacionProject(DateTime Inicio, DateTime Fin);

/// <summary>Tipo: 0 material (también %mo), 1 trabajo horario, 2 costo explícito.</summary>
public sealed record MYGRecursoExportacionProject(
    int Uid, int Tipo, string Nombre, string Codigo, string Grupo, string Unidad, decimal Tarifa);

/// <summary>TrabajoHoras se usa para trabajo; Unidades expresa cantidad fija
/// en materiales y dedicación asignada en recursos de trabajo. Project mantiene
/// por separado la dedicación efectiva (PeakUnits) que resulta del trabajo.</summary>
public sealed record MYGAsignacionExportacionProject(
    int TareaUid, int RecursoUid, decimal Cantidad, decimal? TrabajoHoras,
    decimal? Unidades, decimal Costo, DateTime Inicio, DateTime Fin);

public sealed record MYGDependenciaExportacionProject(
    int TareaUid, int PredecesoraUid, MYGTipoVinculo Tipo, decimal DesfaseMinutos);

public sealed record MYGCalendarioExportacionProject(
    string Nombre, IReadOnlyList<MYGDiaExportacionProject> Dias,
    IReadOnlyList<MYGExcepcionExportacionProject> Excepciones);

public sealed record MYGDiaExportacionProject(
    DayOfWeek Dia, IReadOnlyList<MYGTramoExportacionProject> Tramos);

/// <summary>Intervalo inclusivo de fechas. Los tramos vacíos indican descanso.
/// Las excepciones ya resuelven las prioridades, sin intervalos solapados.</summary>
public sealed record MYGExcepcionExportacionProject(
    DateTime Inicio, DateTime Fin, IReadOnlyList<MYGTramoExportacionProject> Tramos);

public sealed record MYGTramoExportacionProject(int InicioMinuto, int FinMinuto);

public static partial class MYGExportacionCronograma
{
    private static ReadOnlyCollection<T> SoloLectura<T>(IEnumerable<T> elementos) => Array.AsReadOnly(elementos.ToArray());

    /// <summary>Calcula tareas, calendario, recursos reales y vínculos para la
    /// automatización directa de Microsoft Project. Nunca modifica el origen.
    /// Sólo tareas omite completamente el cálculo y la validación de recursos.</summary>
    public static MYGModeloExportacionProject PrepararProject(
        MYGProyectoDocumento proyecto, MYGCronograma plan, bool incluirRecursos)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        ArgumentNullException.ThrowIfNull(plan);
        var copia = MYGProyectoStorage.Copia(proyecto);
        var planCopia = MYGProyectoStorage.Copia(plan);
        var resultado = MYGMotorCronograma.Calcular(planCopia);
        var calendario = planCopia.Calendario;
        var horas = new HorasCalendario(calendario);
        bool horariosExplicitos = calendario.HorariosSemanales?.Count > 0 || calendario.Excepciones?.Any(e => e.Laborable) == true;
        decimal HorasFila(MYGResultadoTarea f)
        {
            if (f.DuracionDias == 0) return 0;
            bool importada = MYGMotorCronograma.ConservaFechasDelphin(f.Tarea);
            // Una tarea manual admite extremos y duración independientes. Una
            // automática debe caber en sus fechas con el calendario exportado:
            // la duración nativa de Delphin puede declarar dos días para un
            // intervalo de uno y Project desplazaría el fin al recibir 960 min.
            if (f.Tarea.Modo == MYGModoTarea.Manual && importada && !horariosExplicitos)
                return f.DuracionDias * calendario.HorasPorDia;
            decimal duracion = horas.Entre(f.Inicio, f.Fin);
            if (f.Tarea.Modo == MYGModoTarea.Automatica && importada &&
                f.Tarea.FechasImportadasDelphin.Tramos.Count > 1)
            {
                // El adaptador COM aplica Split en los huecos internos. Restar
                // sólo sus horas laborables, sin duplicar tramos solapados ni
                // descartar los extremos propios de la tarea.
                var tramos = f.Tarea.FechasImportadasDelphin.Tramos.OrderBy(t => t.Inicio).ToArray();
                DateTime finTramo = Hasta(tramos[0].Fin, tramos[0].Duracion == 0);
                foreach (var tramo in tramos.Skip(1))
                {
                    DateTime inicioTramo = Desde(tramo.Inicio);
                    if (inicioTramo > finTramo) duracion -= HorasEntreInstantes(finTramo, inicioTramo);
                    DateTime fin = Hasta(tramo.Fin, tramo.Duracion == 0);
                    if (fin > finTramo) finTramo = fin;
                }
            }
            return duracion;
        }
        DateTime Desde(DateTime fecha) => fecha.Date.AddMinutes(HorarioFecha(fecha, calendario)[0].InicioMinuto);
        DateTime Hasta(DateTime fecha, bool hito) => fecha.Date.AddMinutes(hito
            ? HorarioFecha(fecha, calendario)[0].InicioMinuto : HorarioFecha(fecha, calendario)[^1].FinMinuto);
        decimal HorasAntes(DateTime fecha) => calendario.ObtenerHorario(fecha).Sum(t =>
            Math.Clamp((decimal)fecha.TimeOfDay.TotalMinutes - t.InicioMinuto, 0m, t.FinMinuto - t.InicioMinuto)) / 60m;
        decimal HorasEntreInstantes(DateTime inicio, DateTime fin) => fin <= inicio ? 0 :
            horas.Entre(inicio, fin) - HorasAntes(inicio) - (calendario.HorasDelDia(fin) - HorasAntes(fin));

        var recursos = new List<Recurso>();
        var asignaciones = new List<Asignacion>();
        var advertenciasRecursos = new List<string>();
        string moneda = null;
        if (incluirRecursos) PrepararRecursosProject(copia, resultado, recursos, asignaciones, advertenciasRecursos, out moneda);
        var uids = resultado.Filas.ToDictionary(f => f.Tarea.Id, f => f.Numero, StringComparer.Ordinal);
        var contadores = new Dictionary<string, int>(StringComparer.Ordinal);
        var esquemas = new Dictionary<string, string>(StringComparer.Ordinal);
        var tareas = new List<MYGTareaExportacionProject>();
        var tramosPorTarea = new Dictionary<int, IReadOnlyList<MYGTramoTareaExportacionProject>>();
        var dependencias = new List<MYGDependenciaExportacionProject>();
        foreach (var f in resultado.Filas)
        {
            var t = f.Tarea;
            string padre = t.PadreId ?? "";
            int ordinal = contadores.GetValueOrDefault(padre) + 1;
            contadores[padre] = ordinal;
            string esquema = (padre.Length == 0 ? "" : esquemas[padre] + ".") + ordinal.ToString(System.Globalization.CultureInfo.InvariantCulture);
            esquemas[t.Id] = esquema;
            decimal? duracionBase = t.DuracionBase.HasValue
                ? t.DuracionBase == 0 ? 0 : (horariosExplicitos
                    ? horas.Entre(t.InicioBase.Value, t.FinBase.Value) : t.DuracionBase.Value * calendario.HorasPorDia) * 60m
                : null;
            tareas.Add(new MYGTareaExportacionProject(
                f.Numero, t.Id, padre.Length == 0 ? 0 : uids[padre], f.Nivel + 1, esquema,
                string.IsNullOrWhiteSpace(t.Codigo) ? esquema : t.Codigo, t.Nombre,
                t.Modo == MYGModoTarea.Manual, t.EsResumen, !t.EsResumen && f.DuracionDias == 0, f.EsCritica,
                Desde(f.Inicio), Hasta(f.Fin, f.DuracionDias == 0), HorasFila(f) * 60m, f.Avance,
                t.InicioBase.HasValue ? Desde(t.InicioBase.Value) : null,
                t.FinBase.HasValue ? Hasta(t.FinBase.Value, t.DuracionBase == 0) : null,
                duracionBase, t.Notas)
            {
                ConservarFechasImportadas = !t.EsResumen && t.Modo == MYGModoTarea.Automatica &&
                    MYGMotorCronograma.ConservaFechasDelphin(t)
            });
            if (MYGMotorCronograma.ConservaFechasDelphin(t) && t.FechasImportadasDelphin.Tramos.Count > 1)
            {
                if (t.Modo != MYGModoTarea.Manual && t.FechasImportadasDelphin.Tramos.Any(s => s.Inicio.Date < f.Inicio.Date || s.Fin.Date > f.Fin.Date))
                    throw new System.IO.InvalidDataException("Los tramos de la tarea automática «" + t.Nombre +
                        "» están fuera de las fechas de la tarea guardadas en SQLite. Revise su distribución en Delphin antes de exportar a Project.");
                tramosPorTarea.Add(f.Numero, SoloLectura(t.FechasImportadasDelphin.Tramos.OrderBy(s => s.Inicio)
                    .Select(s => new MYGTramoTareaExportacionProject(Desde(s.Inicio), Hasta(s.Fin, s.Duracion == 0)))));
            }
            foreach (var dependencia in t.Predecesoras)
                dependencias.Add(new MYGDependenciaExportacionProject(
                    f.Numero, uids[dependencia.PredecesoraId], dependencia.Tipo,
                    dependencia.DesfaseDias * calendario.HorasPorDia * 60m));
        }
        var recursosProject = recursos.Select(r => new MYGRecursoExportacionProject(
            r.Uid, r.Tipo, r.Insumo.Descripcion, r.Insumo.Codigo ?? "",
            MYGMotorPresupuestos.Grupo(r.Insumo.Grupo), r.Insumo.Unidad ?? "", r.Precio));
        var asignacionesProject = asignaciones.Select(a => new MYGAsignacionExportacionProject(
            a.TareaUid, a.Recurso.Uid, a.Cantidad, a.Recurso.Tipo == 1 ? a.Cantidad : null,
            a.Recurso.Tipo == 0 ? a.Cantidad : a.Recurso.Tipo == 1 ? 1m : null,
            a.Costo, Desde(a.Fila.Inicio), Hasta(a.Fila.Fin, a.Fila.DuracionDias == 0)));
        return new MYGModeloExportacionProject(
            copia.Nombre ?? "Cronograma MYG", Desde(resultado.Inicio),
            Hasta(resultado.Fin, resultado.Filas.Count > 0 && resultado.Filas.All(f => f.DuracionDias == 0)),
            planCopia.FechaEstado.Date,
            decimal.ToInt32(decimal.Round(calendario.HorasPorDia * 60m, MidpointRounding.AwayFromZero)),
            Enum.GetValues<DayOfWeek>().Sum(d => calendario.HorarioSemanal(d).Sum(t => t.FinMinuto - t.InicioMinuto)),
            moneda, PrepararCalendarioProject(planCopia, resultado),
            SoloLectura(tareas), SoloLectura(recursosProject), SoloLectura(asignacionesProject),
            SoloLectura(dependencias), SoloLectura(resultado.Advertencias.Concat(advertenciasRecursos)))
        {
            TramosPorTarea = new ReadOnlyDictionary<int, IReadOnlyList<MYGTramoTareaExportacionProject>>(tramosPorTarea)
        };
    }

    private static void PrepararRecursosProject(MYGProyectoDocumento proyecto, MYGResultadoCronograma resultado,
        List<Recurso> recursos, List<Asignacion> asignaciones, List<string> advertencias, out string moneda)
    {
        var presupuestos = (proyecto.Presupuestos ?? new()).ToDictionary(p => p.Id, StringComparer.OrdinalIgnoreCase);
        var calculos = new Dictionary<string, MYGCalculoPresupuesto>(StringComparer.OrdinalIgnoreCase);
        var vistas = new HashSet<(string Presupuesto, string Partida)>();
        // Una misma unidad porcentual puede tener un precio efectivo distinto
        // en cada partida. Compartirla sólo si también coincide su tarifa evita
        // que el precio de la primera tarea cambie el costo de las siguientes.
        var porClave = new Dictionary<(string Presupuesto, string Insumo, int Tipo, decimal Tarifa), Recurso>();
        var asignacionPorClave = new Dictionary<(int Tarea, int Recurso), int>();
        var orden = new Dictionary<MYGInsumo, int>();
        foreach (var p in proyecto.Presupuestos ?? new())
            foreach (var insumo in p.Costos?.Insumos ?? new()) orden.TryAdd(insumo, orden.Count);
        var monedas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in resultado.Filas.Where(f => !f.Tarea.EsResumen && !string.IsNullOrWhiteSpace(f.Tarea.PartidaId)))
        {
            var t = f.Tarea;
            if (string.IsNullOrWhiteSpace(t.PresupuestoId) || !presupuestos.TryGetValue(t.PresupuestoId, out var p))
                throw new System.IO.InvalidDataException("La tarea «" + t.Nombre + "» refiere a un presupuesto inexistente. Sincronice el cronograma.");
            if (!calculos.TryGetValue(p.Id, out var calculo))
            {
                MYGProyectoStorage.ValidarPresupuesto(p);
                calculos.Add(p.Id, calculo = MYGMotorPresupuestos.CrearCalculo(p));
            }
            var partida = p.Items.FirstOrDefault(i => string.Equals(i.Id, t.PartidaId, StringComparison.OrdinalIgnoreCase));
            if (partida == null || MYGProyectoStorage.EsTitulo(partida))
                throw new System.IO.InvalidDataException("La tarea «" + t.Nombre + "» no refiere a una partida vigente. Sincronice el cronograma.");
            if (!vistas.Add((p.Id.ToUpperInvariant(), partida.Id.ToUpperInvariant())))
                throw new System.IO.InvalidDataException("Una partida está vinculada a varias tareas. Sincronice el cronograma para no duplicar recursos.");
            var insumos = p.Costos.Insumos.ToDictionary(i => i.Id, StringComparer.Ordinal);
            var consolidado = calculo.Consolidar(partida);
            string Identidad(MYGInsumoConsolidado r) => r.Clave.StartsWith("PORCENTAJE:", StringComparison.Ordinal) ||
                r.Clave.StartsWith("PORCENTAJE_NATIVO:", StringComparison.Ordinal) ? r.Clave[(r.Clave.IndexOf(':') + 1)..] : r.Clave;
            (string Codigo, string Nombre, string Proveedor) IdentidadPorcentaje(string id)
            {
                var insumo = insumos[id];
                return ((insumo.Codigo ?? "").Trim().ToUpperInvariant(), insumo.Descripcion.Trim().ToUpperInvariant(),
                    (insumo.Proveedor ?? "").Trim().ToUpperInvariant());
            }
            var clavesNativas = consolidado.Where(r => r.Clave.StartsWith("PORCENTAJE_NATIVO:", StringComparison.Ordinal))
                .ToDictionary(r => IdentidadPorcentaje(Identidad(r)), r => r.Clave);
            var cantidadesPorcentuales = new Dictionary<string, decimal>(StringComparer.Ordinal);
            void CantidadesDeOrigen(ItemPresupuestoDelphin item, decimal factor)
            {
                bool nativo = calculo.ConservaRecursosDelphin(item);
                foreach (var origen in calculo.Analizar(item).Recursos)
                {
                    if (origen.Recurso.Grupo == MYGGrupoRecurso.Subpartidas)
                    {
                        CantidadesDeOrigen(calculo.Subpartida(origen.Recurso.SubpartidaIdLocal), factor * origen.Cantidad);
                        continue;
                    }
                    if (origen.Recurso.Modo != MYGModoCantidad.PorcentajeManoObra &&
                        !(nativo && string.Equals(origen.Unidad, "%mo", StringComparison.OrdinalIgnoreCase))) continue;
                    string clave = (nativo ? "PORCENTAJE_NATIVO:" : "PORCENTAJE:") + origen.Recurso.InsumoId;
                    if (nativo && clavesNativas.TryGetValue(IdentidadPorcentaje(origen.Recurso.InsumoId), out string claveAgrupada))
                        clave = claveAgrupada;
                    cantidadesPorcentuales[clave] = cantidadesPorcentuales.GetValueOrDefault(clave) + factor * origen.Cantidad;
                }
            }
            CantidadesDeOrigen(partida, calculo.Cantidad(partida));
            foreach (var r in consolidado.Where(r => insumos.ContainsKey(Identidad(r)))
                .OrderBy(r => orden[insumos[Identidad(r)]]))
            {
                var insumo = insumos[Identidad(r)];
                monedas.Add(p.Costos.Moneda.Trim());
                bool nativo = r.Clave.StartsWith("PORCENTAJE_NATIVO:", StringComparison.Ordinal);
                bool porcentaje = nativo || r.Clave.StartsWith("PORCENTAJE:", StringComparison.Ordinal);
                decimal cantidad = r.Cantidad, tarifa = r.Precio;
                if (porcentaje)
                {
                    // Consolidar sustituye la cantidad porcentual por importe
                    // o tasa económica. Usar el consumo del ACU de origen,
                    // incluidos metrado y factores de subanálisis: un parcial
                    // importado o el IGV no deben transformar 1 en 5 ni 5 en
                    // 5,9. La tarifa conserva el importe y su conciliación.
                    cantidad = cantidadesPorcentuales.GetValueOrDefault(r.Clave);
                    if (cantidad == 0 && r.Total != 0)
                    {
                        cantidad = 1;
                        advertencias.Add("El recurso «" + insumo.Descripcion + "» de la tarea «" + t.Nombre +
                            "» se exportó como una unidad «" + (insumo.Unidad ?? "") +
                            "» con el costo consolidado: la cantidad porcentual de origen es cero y no permite representar ese importe.");
                    }
                    tarifa = cantidad == 0 ? 0 : r.Total / cantidad;
                }
                string unidad = (insumo.Unidad ?? "").Trim().ToLowerInvariant();
                bool horario = !porcentaje && (insumo.Grupo is MYGGrupoRecurso.ManoObra or MYGGrupoRecurso.Equipo) &&
                    unidad is "h" or "hh" or "hm" or "h-h" or "h-m" or "hora" or "horas";
                int tipo = horario ? 1 : 0;
                var llave = (p.Id, insumo.Id, tipo, tarifa);
                if (!porClave.TryGetValue(llave, out var recurso))
                {
                    recurso = new Recurso(recursos.Count + 1, insumo, tipo, tarifa);
                    porClave.Add(llave, recurso);
                    recursos.Add(recurso);
                }
                var claveAsignacion = (f.Numero, recurso.Uid);
                if (asignacionPorClave.TryGetValue(claveAsignacion, out int indice))
                {
                    var anterior = asignaciones[indice];
                    asignaciones[indice] = anterior with { Cantidad = anterior.Cantidad + cantidad, Costo = anterior.Costo + r.Total };
                }
                else
                {
                    asignacionPorClave.Add(claveAsignacion, asignaciones.Count);
                    asignaciones.Add(new(f.Numero, recurso, f, cantidad, r.Total));
                }
            }
        }
        if (monedas.Count > 1)
            throw new System.IO.InvalidDataException("Microsoft Project usa una sola moneda. Exporte por separado los presupuestos de monedas distintas.");
        // El orden del catálogo de origen determina también el de los recursos
        // creados en Project; las variantes de tarifa conservan el mismo nombre.
        recursos.Sort((a, b) => orden[a.Insumo] != orden[b.Insumo]
            ? orden[a.Insumo].CompareTo(orden[b.Insumo]) : a.Uid.CompareTo(b.Uid));
        moneda = monedas.SingleOrDefault();
    }

    private static MYGCalendarioExportacionProject PrepararCalendarioProject(MYGCronograma plan, MYGResultadoCronograma resultado)
    {
        var calendario = plan.Calendario;
        IReadOnlyList<MYGTramoExportacionProject> Tramos(IReadOnlyList<MYGTramoHorario> horario) =>
            SoloLectura(horario.Select(t => new MYGTramoExportacionProject(t.InicioMinuto, t.FinMinuto)));
        var dias = Enum.GetValues<DayOfWeek>().Select(d => new MYGDiaExportacionProject(d, Tramos(calendario.HorarioSemanal(d))));
        var excepciones = new List<MYGExcepcionExportacionProject>();
        int primerAnio = Math.Min(plan.FechaInicio.Year, resultado.Inicio.Year);
        int ultimoAnio = Math.Max(plan.FechaEstado.Year, resultado.Fin.Year);
        foreach (var fila in resultado.Filas)
        {
            if (fila.Tarea.InicioBase.HasValue) primerAnio = Math.Min(primerAnio, fila.Tarea.InicioBase.Value.Year);
            if (fila.Tarea.FinBase.HasValue) ultimoAnio = Math.Max(ultimoAnio, fila.Tarea.FinBase.Value.Year);
        }
        if (RequiereExpansionDeRecurrencias(calendario))
            return PrepararCalendarioRecurrenteProject(calendario, dias, primerAnio, ultimoAnio);
        var feriados = calendario.Feriados.Select(f => f.Date).ToHashSet();
        void AgregarAnual(int mes, int dia)
        {
            for (int anio = primerAnio; anio <= ultimoAnio; anio++)
                if (dia <= DateTime.DaysInMonth(anio, mes)) feriados.Add(new DateTime(anio, mes, dia));
        }
        foreach (var anual in calendario.FeriadosAnuales ?? new()) AgregarAnual(anual.Mes, anual.Dia);
        foreach (var anual in (calendario.Excepciones ?? new()).Where(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.DiaMesDelAnio)) AgregarAnual(anual.Mes, anual.Dia);
        void Agregar(DateTime desde, DateTime hasta, IReadOnlyList<MYGTramoHorario> horario) =>
            excepciones.Add(new MYGExcepcionExportacionProject(desde.Date, hasta.Date, Tramos(horario)));
        var rangos = (calendario.Excepciones ?? new()).Where(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.FechaORango).OrderBy(e => e.Inicio.Value.Date).ToArray();
        foreach (var fecha in feriados.Order().Where(f => !rangos.Any(r => r.Contiene(f))))
            Agregar(fecha, fecha, calendario.ObtenerHorario(fecha));
        foreach (var rango in rangos)
        {
            if (!rango.Laborable || rango.Tramos?.Count > 0)
            {
                Agregar(rango.Inicio.Value, rango.Fin.Value, calendario.ObtenerHorario(rango.Inicio.Value));
                continue;
            }
            // Las guardias sin tramos heredan el horario del día. Un fin de
            // semana puede tener tramos distintos de un día habitual de obra.
            DateTime desde = rango.Inicio.Value.Date > new DateTime(primerAnio, 1, 1) ? rango.Inicio.Value.Date : new DateTime(primerAnio, 1, 1);
            DateTime hasta = rango.Fin.Value.Date < new DateTime(ultimoAnio, 12, 31) ? rango.Fin.Value.Date : new DateTime(ultimoAnio, 12, 31);
            if (desde > hasta) continue;
            var tramos = calendario.ObtenerHorario(desde);
            DateTime grupo = desde, actual = desde;
            while (actual < hasta)
            {
                DateTime siguiente = actual.AddDays(1);
                var nuevos = calendario.ObtenerHorario(siguiente);
                if (!tramos.Select(t => (t.InicioMinuto, t.FinMinuto)).SequenceEqual(nuevos.Select(t => (t.InicioMinuto, t.FinMinuto))))
                { Agregar(grupo, actual, tramos); grupo = siguiente; tramos = nuevos; }
                actual = siguiente;
            }
            Agregar(grupo, hasta, tramos);
        }
        return new MYGCalendarioExportacionProject(calendario.Nombre, SoloLectura(dias), SoloLectura(excepciones));
    }

    private static MYGCalendarioExportacionProject PrepararCalendarioRecurrenteProject(
        MYGCalendarioTrabajo calendario, IEnumerable<MYGDiaExportacionProject> dias, int primerAnio, int ultimoAnio)
    {
        var semana = dias.ToArray();
        var excepciones = new List<MYGExcepcionExportacionProject>();
        var fin = new DateTime(ultimoAnio, 12, 31);
        DateTime? inicioGrupo = null;
        DateTime finGrupo = default;
        MYGTramoExportacionProject[] tramosGrupo = null;
        void CerrarGrupo()
        {
            if (!inicioGrupo.HasValue) return;
            excepciones.Add(new(inicioGrupo.Value, finGrupo, SoloLectura(tramosGrupo)));
            inicioGrupo = null;
        }
        // Una recurrencia sin vigencia nunca se expande hasta DateTime.MaxValue:
        // Project recibe sólo los años que necesita el plan y su línea base.
        for (var fecha = new DateTime(primerAnio, 1, 1); ; fecha = fecha.AddDays(1))
        {
            var horario = calendario.ObtenerHorario(fecha).Select(t =>
                new MYGTramoExportacionProject(t.InicioMinuto, t.FinMinuto)).ToArray();
            bool cambiaSemana = !semana[(int)fecha.DayOfWeek].Tramos.SequenceEqual(horario);
            if (!cambiaSemana) CerrarGrupo();
            else
            {
                if (inicioGrupo.HasValue && !tramosGrupo.SequenceEqual(horario)) CerrarGrupo();
                if (!inicioGrupo.HasValue) { inicioGrupo = fecha; tramosGrupo = horario; }
                finGrupo = fecha;
            }
            if (fecha == fin) break;
        }
        CerrarGrupo();
        return new(calendario.Nombre, SoloLectura(semana), SoloLectura(excepciones));
    }
}
