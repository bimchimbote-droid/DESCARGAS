using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json.Serialization;

namespace MYG_2027;

public sealed class MYGFeriadoAnual
{
    public int Mes { get; set; }
    public int Dia { get; set; }
}

public sealed class MYGTramoHorario
{
    public int InicioMinuto { get; set; }
    public int FinMinuto { get; set; }
}

public sealed class MYGHorarioDiaTrabajo
{
    public DayOfWeek Dia { get; set; }
    public List<MYGTramoHorario> Tramos { get; set; } = new();
}

public enum MYGTipoExcepcionCalendario
{
    FechaORango = 0,
    DiaSemana = 1,
    DiaMes = 2,
    DiaSemanaDelMes = 3,
    DiaMesDelAnio = 4,
    DiaSemanaMesDelAnio = 5
}

public sealed class MYGExcepcionCalendario
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Nombre { get; set; } = "";
    public bool Anual { get; set; }
    // Ausente en documentos anteriores: conserva exactamente el significado de Anual.
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public MYGTipoExcepcionCalendario? Tipo { get; set; }
    [JsonIgnore]
    public MYGTipoExcepcionCalendario TipoEfectivo => Tipo ??
        (Anual ? MYGTipoExcepcionCalendario.DiaMesDelAnio : MYGTipoExcepcionCalendario.FechaORango);
    public int Mes { get; set; }
    public int Dia { get; set; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public DayOfWeek DiaSemana { get; set; }
    // Primera, segunda, tercera o cuarta ocurrencia del día de la semana en el mes.
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public int NumeroSemana { get; set; }
    public DateTime? Inicio { get; set; }
    public DateTime? Fin { get; set; }
    public bool Laborable { get; set; }
    public string Color { get; set; } = "#FDE9D9";
    public List<MYGTramoHorario> Tramos { get; set; } = new();

    public bool Contiene(DateTime fecha)
    {
        fecha = fecha.Date;
        if (Inicio.HasValue && fecha < Inicio.Value.Date || Fin.HasValue && fecha > Fin.Value.Date) return false;
        return TipoEfectivo switch
        {
            MYGTipoExcepcionCalendario.FechaORango => Inicio.HasValue && Fin.HasValue,
            MYGTipoExcepcionCalendario.DiaSemana => fecha.DayOfWeek == DiaSemana,
            MYGTipoExcepcionCalendario.DiaMes => fecha.Day == Dia,
            MYGTipoExcepcionCalendario.DiaSemanaDelMes => FechaSemanalDelMes(fecha.Year, fecha.Month) == fecha,
            MYGTipoExcepcionCalendario.DiaMesDelAnio => fecha.Month == Mes && fecha.Day == Dia,
            MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio => fecha.Month == Mes && FechaSemanalDelMes(fecha.Year, Mes) == fecha,
            _ => false
        };
    }

    /// <summary>Primera fecha coincidente desde el día indicado, incluidos ambos límites de vigencia.</summary>
    public DateTime? ProximaFecha(DateTime desde)
    {
        desde = desde.Date;
        if (Inicio.HasValue && desde < Inicio.Value.Date) desde = Inicio.Value.Date;
        if (Fin.HasValue && desde > Fin.Value.Date) return null;
        DateTime? fecha = SiguienteCoincidencia(desde);
        return fecha.HasValue && (!Fin.HasValue || fecha.Value <= Fin.Value.Date) ? fecha : null;
    }

    // Sin límites de vigencia: también se usa para el patrón gregoriano del índice ordinal.
    internal DateTime? SiguienteCoincidencia(DateTime desde)
    {
        desde = desde.Date;
        if (TipoEfectivo == MYGTipoExcepcionCalendario.FechaORango)
            return Inicio.HasValue && Fin.HasValue && desde <= Fin.Value.Date ?
                (desde < Inicio.Value.Date ? Inicio.Value.Date : desde) : null;
        if (TipoEfectivo == MYGTipoExcepcionCalendario.DiaSemana)
        {
            if (!Enum.IsDefined(DiaSemana)) return null;
            int salto = ((int)DiaSemana - (int)desde.DayOfWeek + 7) % 7;
            return DateTime.MaxValue.Date.Subtract(desde).Days >= salto ? desde.AddDays(salto) : null;
        }
        bool anual = TipoEfectivo is MYGTipoExcepcionCalendario.DiaMesDelAnio or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        bool semanal = TipoEfectivo is MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        if (!anual && TipoEfectivo is not MYGTipoExcepcionCalendario.DiaMes and not MYGTipoExcepcionCalendario.DiaSemanaDelMes)
            return null;
        if (anual && (Mes < 1 || Mes > 12) || !semanal && (Dia < 1 || Dia > 31)) return null;
        if (anual && !semanal && Dia > DateTime.DaysInMonth(2000, Mes)) return null;
        int anio = desde.Year, mes = anual ? Mes : desde.Month;
        while (anio <= 9999)
        {
            DateTime? candidata = semanal ? FechaSemanalDelMes(anio, mes) :
                Dia <= DateTime.DaysInMonth(anio, mes) ? new DateTime(anio, mes, Dia) : null;
            if (candidata.HasValue && candidata.Value >= desde) return candidata;
            if (semanal && (!Enum.IsDefined(DiaSemana) || NumeroSemana < 1 || NumeroSemana > 4)) return null;
            if (anual) anio++;
            else if (++mes > 12) { mes = 1; anio++; }
        }
        return null;
    }

    private DateTime? FechaSemanalDelMes(int anio, int mes)
    {
        if (mes < 1 || mes > 12 || !Enum.IsDefined(DiaSemana) || NumeroSemana < 1 || NumeroSemana > 4) return null;
        var inicio = new DateTime(anio, mes, 1);
        int dia = 1 + ((int)DiaSemana - (int)inicio.DayOfWeek + 7) % 7 + (NumeroSemana - 1) * 7;
        return new DateTime(anio, mes, dia);
    }
}

public sealed class MYGCalendarioTrabajo
{
    public string Nombre { get; set; } = "Predeterminado";
    public List<DayOfWeek> DiasLaborables { get; set; } = new()
    { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday };
    public List<DateTime> Feriados { get; set; } = new();
    public List<MYGFeriadoAnual> FeriadosAnuales { get; set; } = new();
    public decimal HorasPorDia { get; set; } = 8;
    // Una lista vacía conserva los calendarios guardados antes del editor de horarios.
    public List<MYGHorarioDiaTrabajo> HorariosSemanales { get; set; } = new();
    public List<MYGExcepcionCalendario> Excepciones { get; set; } = new();

    /// <summary>Fechas concretas, recurrencias explícitas en orden de lista y, por último, anuales heredadas.</summary>
    public MYGExcepcionCalendario ObtenerExcepcion(DateTime fecha) => Excepciones?
        .Where(e => e != null && e.Contiene(fecha))
        .OrderBy(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.FechaORango ? 0 : e.Tipo.HasValue ? 1 : 2)
        .FirstOrDefault();

    public IReadOnlyList<MYGTramoHorario> ObtenerHorario(DateTime fecha)
    {
        // Una excepción fechada permite, por ejemplo, trabajar una Navidad concreta.
        var excepcion = ObtenerExcepcion(fecha);
        if (excepcion != null)
        {
            if (!excepcion.Laborable) return Array.Empty<MYGTramoHorario>();
            if (excepcion.Tramos?.Count > 0) return Ordenar(excepcion.Tramos);
            var semanal = HorarioSemanal(fecha.DayOfWeek);
            return semanal.Count > 0 ? semanal : JornadaPredeterminada();
        }
        if ((Feriados?.Any(f => f.Date == fecha.Date) ?? false) ||
            (FeriadosAnuales?.Any(f => f != null && f.Mes == fecha.Month && f.Dia == fecha.Day) ?? false))
            return Array.Empty<MYGTramoHorario>();
        return HorarioSemanal(fecha.DayOfWeek);
    }

    public decimal HorasDelDia(DateTime fecha) => ObtenerHorario(fecha).Sum(t => t.FinMinuto - t.InicioMinuto) / 60m;
    public bool EsLaborable(DateTime fecha) => ObtenerHorario(fecha).Count > 0;

    internal IReadOnlyList<MYGTramoHorario> HorarioSemanal(DayOfWeek dia)
    {
        if (HorariosSemanales?.Count > 0)
            return Ordenar(HorariosSemanales.FirstOrDefault(h => h != null && h.Dia == dia)?.Tramos);
        return DiasLaborables?.Contains(dia) == true ? JornadaPredeterminada() : Array.Empty<MYGTramoHorario>();
    }

    private static IReadOnlyList<MYGTramoHorario> Ordenar(List<MYGTramoHorario> tramos) =>
        tramos == null ? Array.Empty<MYGTramoHorario>() : tramos.OrderBy(t => t.InicioMinuto).ToArray();

    private IReadOnlyList<MYGTramoHorario> JornadaPredeterminada()
    {
        int minutos = Math.Clamp((int)Math.Round(HorasPorDia * 60, MidpointRounding.AwayFromZero), 1, 1440);
        // Horario habitual de obra, con refrigerio, para las jornadas heredadas.
        if (minutos <= 240) return new[] { new MYGTramoHorario { InicioMinuto = 480, FinMinuto = 480 + minutos } };
        if (minutos <= 900) return new[] { new MYGTramoHorario { InicioMinuto = 480, FinMinuto = 720 },
            new MYGTramoHorario { InicioMinuto = 780, FinMinuto = 780 + minutos - 240 } };
        return new[] { new MYGTramoHorario { InicioMinuto = 0, FinMinuto = minutos } };
    }

    public void Validar()
    {
        if (string.IsNullOrWhiteSpace(Nombre)) throw new InvalidDataException("El calendario requiere un nombre.");
        if (HorasPorDia <= 0 || HorasPorDia > 24 || Feriados == null)
            throw new InvalidDataException("El calendario requiere una jornada mayor que cero y de hasta 24 horas y una lista de feriados.");
        if (HorariosSemanales?.Count > 0)
        {
            if (HorariosSemanales.Any(h => h == null || !Enum.IsDefined(h.Dia)) ||
                HorariosSemanales.Select(h => h.Dia).Distinct().Count() != HorariosSemanales.Count)
                throw new InvalidDataException("El horario semanal requiere días válidos y sin duplicados.");
            foreach (var horario in HorariosSemanales) ValidarTramos(horario.Tramos);
        }
        else if (DiasLaborables == null || DiasLaborables.Count == 0 ||
            DiasLaborables.Any(d => !Enum.IsDefined(d)) || DiasLaborables.Distinct().Count() != DiasLaborables.Count)
            throw new InvalidDataException("El calendario requiere días laborables válidos y sin duplicados.");
        if ((FeriadosAnuales ?? new()).Any(f => f == null || !FechaAnualValida(f.Mes, f.Dia)))
            throw new InvalidDataException("El calendario contiene un feriado anual no válido.");
        var excepciones = Excepciones ?? new();
        if (excepciones.Any(e => e == null || string.IsNullOrWhiteSpace(e.Id)) ||
            excepciones.Select(e => e.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() != excepciones.Count)
            throw new InvalidDataException("Las excepciones requieren identificadores únicos.");
        foreach (var e in excepciones)
        {
            if (!Enum.IsDefined(e.TipoEfectivo) ||
                e.Inicio.HasValue && e.Fin.HasValue && e.Fin.Value.Date < e.Inicio.Value.Date ||
                e.TipoEfectivo == MYGTipoExcepcionCalendario.FechaORango && (!e.Inicio.HasValue || !e.Fin.HasValue))
                throw new InvalidDataException("La excepción «" + e.Nombre + "» contiene una fecha o intervalo no válido.");
            bool diaSemanal = e.TipoEfectivo is MYGTipoExcepcionCalendario.DiaSemana or
                MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
            bool numeroSemanal = e.TipoEfectivo is MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
            if (diaSemanal && !Enum.IsDefined(e.DiaSemana) || numeroSemanal && (e.NumeroSemana < 1 || e.NumeroSemana > 4) ||
                e.TipoEfectivo == MYGTipoExcepcionCalendario.DiaMes && (e.Dia < 1 || e.Dia > 31) ||
                e.TipoEfectivo == MYGTipoExcepcionCalendario.DiaMesDelAnio && !FechaAnualValida(e.Mes, e.Dia) ||
                e.TipoEfectivo == MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio && (e.Mes < 1 || e.Mes > 12))
                throw new InvalidDataException("La excepción «" + e.Nombre + "» contiene una regla de repetición no válida.");
            ValidarTramos(e.Tramos);
            if (!string.IsNullOrEmpty(e.Color) && ((e.Color.Length != 7 && e.Color.Length != 9) || e.Color[0] != '#' ||
                e.Color.Skip(1).Any(c => !Uri.IsHexDigit(c))))
                throw new InvalidDataException("El color de una excepción debe usar #RRGGBB o #AARRGGBB.");
        }
        var periodos = excepciones.Where(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.FechaORango).OrderBy(e => e.Inicio.Value.Date).ToArray();
        for (int i = 1; i < periodos.Length; i++)
            if (periodos[i].Inicio.Value.Date <= periodos[i - 1].Fin.Value.Date)
                throw new InvalidDataException("Las excepciones con fechas no pueden solaparse; edite o divida el intervalo existente.");
        // Reglas distintas pueden coincidir: decide la precedencia documentada. Repetir la misma
        // regla durante vigencias solapadas produciría dos definiciones ambiguas del mismo caso.
        foreach (var grupo in excepciones.Where(e => e.TipoEfectivo != MYGTipoExcepcionCalendario.FechaORango).GroupBy(ClaveRegla))
        {
            DateTime? finAnterior = null;
            foreach (var e in grupo.OrderBy(e => e.Inicio?.Date ?? DateTime.MinValue.Date))
            {
                var inicio = e.Inicio?.Date ?? DateTime.MinValue.Date;
                if (finAnterior.HasValue && inicio <= finAnterior.Value)
                    throw new InvalidDataException("Dos excepciones con la misma regla no pueden tener vigencias solapadas.");
                finAnterior = e.Fin?.Date ?? DateTime.MaxValue.Date;
            }
        }
    }

    private static (MYGTipoExcepcionCalendario Tipo, int Mes, int Dia, DayOfWeek DiaSemana, int NumeroSemana) ClaveRegla(MYGExcepcionCalendario e) =>
        (e.TipoEfectivo,
        e.TipoEfectivo is MYGTipoExcepcionCalendario.DiaMesDelAnio or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio ? e.Mes : 0,
        e.TipoEfectivo is MYGTipoExcepcionCalendario.DiaMes or MYGTipoExcepcionCalendario.DiaMesDelAnio ? e.Dia : 0,
        e.TipoEfectivo is MYGTipoExcepcionCalendario.DiaSemana or MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio ? e.DiaSemana : default,
        e.TipoEfectivo is MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio ? e.NumeroSemana : 0);

    private static bool FechaAnualValida(int mes, int dia) => mes >= 1 && mes <= 12 &&
        dia >= 1 && dia <= DateTime.DaysInMonth(2000, mes);
    private static void ValidarTramos(List<MYGTramoHorario> tramos)
    {
        if (tramos == null) return;
        if (tramos.Any(t => t == null || t.InicioMinuto < 0 || t.FinMinuto > 1440 || t.InicioMinuto >= t.FinMinuto))
            throw new InvalidDataException("Cada tramo debe tener inicio anterior al fin, entre 00:00 y 24:00.");
        var ordenados = tramos.OrderBy(t => t.InicioMinuto).ToArray();
        for (int i = 1; i < ordenados.Length; i++)
            if (ordenados[i].InicioMinuto < ordenados[i - 1].FinMinuto)
                throw new InvalidDataException("Los tramos de una jornada no pueden solaparse.");
    }
    public DateTime SiguienteLaborable(DateTime fecha)
    { var c = new MYGCalendarioEntero(this); return c.Fecha(c.Primero(fecha)); }
    public DateTime SumarDiasLaborables(DateTime fecha, int dias)
    { var c = new MYGCalendarioEntero(this); return c.Fecha(c.Primero(fecha) + dias); }
    public int ContarDiasLaborables(DateTime inicio, DateTime fin)
    { var c = new MYGCalendarioEntero(this); return c.Contar(inicio, fin); }
}

// Ordinal absoluto de día laborable, independiente del inicio del proyecto.
// Conteo por semanas + intervalos y ajustes puntuales indexados. Los intervalos
// extensos y los desfases enormes no recorren el calendario día por día.
internal sealed class MYGCalendarioEntero
{
    private const int UltimoDia = 3652058;
    private readonly HashSet<DayOfWeek> semana;
    private readonly int[] puntos;
    private readonly int[] acumuladosPuntos;
    private readonly Periodo[] periodos;
    private readonly SegmentoRecurrente[] segmentosRecurrentes;
    private readonly int total;
    internal MYGCalendarioEntero(MYGCalendarioTrabajo calendario)
    {
        if (calendario == null) throw new InvalidDataException("El cronograma requiere un calendario.");
        calendario.Validar();
        semana = Enum.GetValues<DayOfWeek>().Where(d => calendario.HorarioSemanal(d).Count > 0).ToHashSet();
        // Se conserva la ruta de semanas e intervalos para proyectos anteriores. Las reglas
        // nuevas repiten su patrón cada 400 años y sólo cambian al entrar o salir de vigencia.
        if ((calendario.Excepciones ?? new()).Any(e => e.TipoEfectivo != MYGTipoExcepcionCalendario.FechaORango &&
            (e.TipoEfectivo != MYGTipoExcepcionCalendario.DiaMesDelAnio || e.Inicio.HasValue || e.Fin.HasValue)))
        {
            periodos = Array.Empty<Periodo>();
            segmentosRecurrentes = CrearSegmentosRecurrentes(calendario);
            var ajustesFeriados = calendario.Feriados.Select(Dia).Distinct().Where(d =>
                calendario.ObtenerExcepcion(FechaDelDia(d)) == null && ContarRecurrentesHasta(d) > ContarRecurrentesHasta(d - 1))
                .OrderBy(d => d).ToArray();
            puntos = ajustesFeriados;
            acumuladosPuntos = Enumerable.Range(0, puntos.Length + 1).Select(n => -n).ToArray();
            total = Hasta(UltimoDia);
            if (total == 0) throw new InvalidDataException("El calendario no contiene ningún día laborable disponible.");
            return;
        }
        periodos = (calendario.Excepciones ?? new()).Where(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.FechaORango).OrderBy(e => e.Inicio.Value.Date)
            .Select(e => new Periodo { Inicio = Dia(e.Inicio.Value), Fin = Dia(e.Fin.Value), Laborable = e.Laborable }).ToArray();
        int acumulado = 0;
        foreach (var p in periodos)
        {
            p.AcumuladoAnterior = acumulado;
            acumulado += DeltaPeriodo(p, p.Fin);
        }
        var fechas = calendario.Feriados.Select(Dia).Distinct().ToDictionary(d => d, _ => false);
        foreach (var f in calendario.FeriadosAnuales ?? new()) AgregarAnual(f.Mes, f.Dia, false);
        foreach (var e in (calendario.Excepciones ?? new()).Where(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.DiaMesDelAnio)) AgregarAnual(e.Mes, e.Dia, e.Laborable);
        var ajustes = fechas.Where(f => !EnPeriodo(f.Key)).Select(f => new { Dia = f.Key,
            Delta = (f.Value ? 1 : 0) - (semana.Contains((DayOfWeek)((f.Key + 1) % 7)) ? 1 : 0) })
            .Where(f => f.Delta != 0).OrderBy(f => f.Dia).ToArray();
        puntos = ajustes.Select(f => f.Dia).ToArray();
        acumuladosPuntos = new int[ajustes.Length + 1];
        for (int i = 0; i < ajustes.Length; i++) acumuladosPuntos[i + 1] = acumuladosPuntos[i] + ajustes[i].Delta;
        total = Hasta(UltimoDia);
        if (total == 0) throw new InvalidDataException("El calendario no contiene ningún día laborable disponible.");

        void AgregarAnual(int mes, int dia, bool laborable)
        {
            for (int anio = 1; anio <= 9999; anio++)
                if (dia <= DateTime.DaysInMonth(anio, mes)) fechas[Dia(new DateTime(anio, mes, dia))] = laborable;
        }
    }
    private static int Dia(DateTime fecha) => (int)(fecha.Date.Ticks / TimeSpan.TicksPerDay);
    private static DateTime FechaDelDia(int dia) => new((long)dia * TimeSpan.TicksPerDay);

    private SegmentoRecurrente[] CrearSegmentosRecurrentes(MYGCalendarioTrabajo calendario)
    {
        const int ciclo = 146097; // 400 años gregorianos; también contiene semanas completas.
        var reglas = (calendario.Excepciones ?? new()).Where(e => e.TipoEfectivo != MYGTipoExcepcionCalendario.FechaORango)
            .OrderBy(e => e.Tipo.HasValue ? 0 : 1).ToArray();
        var rangos = (calendario.Excepciones ?? new()).Where(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.FechaORango).ToArray();
        var cortes = new SortedSet<int> { 0, UltimoDia + 1 };
        foreach (var e in reglas.Concat(rangos))
        {
            if (e.Inicio.HasValue) cortes.Add(Dia(e.Inicio.Value));
            if (e.Fin.HasValue) cortes.Add(Dia(e.Fin.Value) + 1);
        }
        var baseSemanal = new bool[ciclo];
        for (int dia = 0; dia < ciclo; dia++) baseSemanal[dia] = semana.Contains((DayOfWeek)((dia + 1) % 7));
        foreach (var anual in calendario.FeriadosAnuales ?? new())
            for (int anio = 1; anio <= 400; anio++)
                if (anual.Dia <= DateTime.DaysInMonth(anio, anual.Mes))
                    baseSemanal[Dia(new DateTime(anio, anual.Mes, anual.Dia))] = false;

        var patrones = new Dictionary<string, PatronRecurrente>();
        var resultado = new List<SegmentoRecurrente>();
        var limites = cortes.ToArray();
        int acumulado = 0;
        for (int i = 0; i < limites.Length - 1; i++)
        {
            int inicio = limites[i], fin = limites[i + 1] - 1;
            if (inicio > fin) continue;
            var segmento = new SegmentoRecurrente { Inicio = inicio, Fin = fin, AcumuladoAnterior = acumulado };
            var rango = rangos.FirstOrDefault(e => Dia(e.Inicio.Value) <= inicio && Dia(e.Fin.Value) >= inicio);
            if (rango != null) segmento.LaborableConstante = rango.Laborable;
            else
            {
                var activas = Enumerable.Range(0, reglas.Length).Where(n =>
                    (!reglas[n].Inicio.HasValue || Dia(reglas[n].Inicio.Value) <= inicio) &&
                    (!reglas[n].Fin.HasValue || Dia(reglas[n].Fin.Value) >= inicio)).ToArray();
                string clave = string.Join(",", activas);
                if (!patrones.TryGetValue(clave, out var patron))
                {
                    var jornadas = (bool[])baseSemanal.Clone();
                    // Escribir las de mayor prioridad al final conserva el orden de la lista.
                    foreach (int indice in activas.Reverse())
                    {
                        var regla = reglas[indice];
                        for (DateTime? fecha = regla.SiguienteCoincidencia(DateTime.MinValue); fecha.HasValue && fecha.Value.Year <= 400;
                            fecha = regla.SiguienteCoincidencia(fecha.Value.AddDays(1)))
                            jornadas[Dia(fecha.Value)] = regla.Laborable;
                    }
                    patron = new PatronRecurrente(jornadas);
                    patrones.Add(clave, patron);
                }
                segmento.Patron = patron;
            }
            acumulado += segmento.ContarHasta(fin);
            resultado.Add(segmento);
        }
        return resultado.ToArray();
    }

    private int ContarRecurrentesHasta(int dia)
    {
        if (dia < 0) return 0;
        int inferior = 0, superior = segmentosRecurrentes.Length;
        while (inferior < superior)
        {
            int medio = inferior + (superior - inferior) / 2;
            if (segmentosRecurrentes[medio].Inicio <= dia) inferior = medio + 1; else superior = medio;
        }
        var segmento = segmentosRecurrentes[inferior - 1];
        return segmento.AcumuladoAnterior + segmento.ContarHasta(dia);
    }
    private int SemanalHasta(int dia)
    {
        if (dia < 0) return 0;
        int dias = dia + 1, cantidad = dias / 7 * semana.Count;
        for (int n = 0; n < dias % 7; n++)
            if (semana.Contains((DayOfWeek)((n + 1) % 7))) cantidad++;
        return cantidad;
    }
    private int Hasta(int dia)
    {
        if (dia < 0) return 0;
        int inferior = 0, superior = puntos.Length;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (puntos[medio] <= dia) inferior = medio + 1; else superior = medio; }
        if (segmentosRecurrentes != null) return ContarRecurrentesHasta(dia) + acumuladosPuntos[inferior];
        int cantidad = SemanalHasta(dia) + acumuladosPuntos[inferior];
        int indice = IndicePeriodo(dia);
        if (indice >= 0) cantidad += periodos[indice].AcumuladoAnterior + DeltaPeriodo(periodos[indice], dia);
        return cantidad;
    }
    private int DeltaPeriodo(Periodo p, int hasta) => (p.Laborable ? Math.Min(hasta, p.Fin) - p.Inicio + 1 : 0) -
        (SemanalHasta(Math.Min(hasta, p.Fin)) - SemanalHasta(p.Inicio - 1));
    private bool EnPeriodo(int dia)
    { int indice = IndicePeriodo(dia); return indice >= 0 && dia <= periodos[indice].Fin; }
    private int IndicePeriodo(int dia)
    {
        int inferior = 0, superior = periodos.Length;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (periodos[medio].Inicio <= dia) inferior = medio + 1; else superior = medio; }
        return inferior - 1;
    }
    private sealed class Periodo
    {
        internal int Inicio, Fin, AcumuladoAnterior;
        internal bool Laborable;
    }
    private sealed class PatronRecurrente
    {
        private readonly ulong[] dias;
        private readonly int[] acumuladosBloques;
        private readonly int longitud;
        internal PatronRecurrente(bool[] jornadas)
        {
            longitud = jornadas.Length;
            dias = new ulong[(longitud + 63) / 64];
            for (int n = 0; n < longitud; n++)
                if (jornadas[n]) dias[n / 64] |= 1UL << (n % 64);
            acumuladosBloques = new int[dias.Length + 1];
            for (int n = 0; n < dias.Length; n++)
                acumuladosBloques[n + 1] = acumuladosBloques[n] + BitOperations.PopCount(dias[n]);
        }
        internal int Hasta(int dia)
        {
            if (dia < 0) return 0;
            int cantidad = dia + 1, resto = cantidad % longitud, bloque = resto / 64, bits = resto % 64;
            return cantidad / longitud * acumuladosBloques[^1] + acumuladosBloques[bloque] +
                (bits == 0 ? 0 : BitOperations.PopCount(dias[bloque] & ((1UL << bits) - 1)));
        }
    }
    private sealed class SegmentoRecurrente
    {
        internal int Inicio, Fin, AcumuladoAnterior;
        internal bool? LaborableConstante;
        internal PatronRecurrente Patron;
        internal int ContarHasta(int dia) => LaborableConstante.HasValue ?
            (LaborableConstante.Value ? Math.Min(dia, Fin) - Inicio + 1 : 0) :
            Patron.Hasta(Math.Min(dia, Fin)) - Patron.Hasta(Inicio - 1);
    }
    internal long Primero(DateTime fecha) => Hasta(Dia(fecha) - 1) + 1L;
    internal long Despues(DateTime fecha) => Hasta(Dia(fecha)) + 1L;
    internal long AnteriorOIgual(DateTime fecha) => Hasta(Dia(fecha));
    internal int Contar(DateTime inicio, DateTime fin) => fin.Date < inicio.Date ? 0 : Hasta(Dia(fin)) - Hasta(Dia(inicio) - 1);
    internal DateTime Fecha(long ordinal)
    {
        if (ordinal < 1 || ordinal > total)
            throw new InvalidDataException("Las fechas del cronograma exceden el rango permitido. Revise duraciones y desfases.");
        int inferior = 0, superior = UltimoDia;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (Hasta(medio) < ordinal) inferior = medio + 1; else superior = medio; }
        return new DateTime((long)inferior * TimeSpan.TicksPerDay);
    }
}
