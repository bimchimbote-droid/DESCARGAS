# Actualización de Tiempo de trabajo

Base: `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`, commit
`a84877a3a941c12574559aab73fb3f4a4b0b01d6`. Los cambios se prepararon en el
checkout de trabajo, sin publicar en el repositorio del código.

## Comportamiento tomado del video

El video de referencia dura 94,1 segundos (2.823 fotogramas, 30 fps). Se
examinaron las transiciones de edición de jornadas, excepciones y colores.

- Los días se marcan como laborables cuando contienen tramos. Eliminar el
  último tramo desmarca el día; agregar uno vuelve a habilitarlo.
- Cada tramo admite hora inicial/final, entrada manual e incremento por
  horas/minutos. Se muestran horas a. m./p. m.; también se acepta `HH:mm`.
  `24:00` está reservado al final de un tramo.
- Los totales diarios y semanales se actualizan; el mensual de referencia
  corresponde a cuatro semanas, como en el video.
- Se conservan los calendarios nombrados y las acciones de creación,
  renombrado, eliminación y activación del calendario del proyecto.
- La vista de tres meses pinta las excepciones efectivas. «Mostrar calendario
  base» consulta la semana habitual sin modificar el proyecto.
- Las excepciones conservan descripción, color, condición laborable y tramos.
  Las paletas se organizan en Personalizado, Web y Sistema.

| Tipo de excepción | Configuración |
|---|---|
| Fecha o rango de fechas | Del/Al inclusivos; sin Al, solamente el día inicial |
| Día de la semana | Domingo a sábado |
| Día del mes | Número 1 a 31; omite meses que no tienen ese día |
| Día de la n-ésima semana del mes | Día semanal y Primera, Segunda, Tercera o Cuarta |
| Día y mes del año | Número de día y mes; 29 de febrero sólo en años bisiestos |
| Día de la n-ésima semana de un mes concreto | Día semanal, número de semana y mes |

Las repeticiones pueden tener límites Del/Al inclusivos. Desmarcar un límite
lo deja abierto. «Cuarta» significa la cuarta ocurrencia del día semanal,
incluso cuando el mes tiene cinco. «Ubicar excepción» busca una
ocurrencia real que respete esos límites.

Una excepción de fecha concreta prevalece sobre las repeticiones. Entre
repeticiones nuevas distintas que coinciden se utiliza la primera en la lista;
las excepciones anuales heredadas conservan su compatibilidad. Los rangos
superpuestos y las reglas idénticas con vigencias superpuestas se rechazan.

El panel trabaja sobre una copia. «Guardar cambios» incorpora una sola
operación al historial, conserva las tareas editadas mientras estaba abierto
y recalcula el Gantt. Cerrar permite guardar, descartar o cancelar.

## Instalación manual

1. En su carpeta local, respalde o confirme los cambios pendientes antes de
   reemplazar archivos. La entrega corresponde al commit indicado arriba;
   compare los archivos si tiene cambios locales o posteriores.
2. Descargue y extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip` fuera del proyecto.
3. Copie su contenido sobre la raíz del proyecto, conservando las rutas
   `MYG.Core/`, `MYG.Desktop/`, `MYG.Pruebas/` y `MYG.PruebasUI/`.
   Se entregan archivos completos. No hay archivos que eliminar ni parches
   adicionales que aplicar.
4. Abra `MYG.Presupuestos.sln` con Visual Studio 2026 y SDK .NET 10.
5. Restaure, compile y valide con los comandos siguientes.

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

`UseRevitReferencePackages=true` permite compilar el conector sin tener Revit
instalado. Para compilar contra la instalación local de Revit 2027, omita esa
propiedad y utilice su configuración habitual de `RevitInstallDir`.

En Windows, ejecute también la suite de interfaz:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

## Configuración y compatibilidad

No se agregan paquetes NuGet ni se requieren migraciones manuales de SQLite.
Los nuevos `.cs` se incluyen automáticamente por el SDK del proyecto.
Se conservan la lectura de calendarios anteriores y sus firmas de
serialización. Las nuevas reglas deben abrirse con esta versión actualizada;
versiones anteriores no conocen sus tipos.

El motor conserva el cálculo en días laborables enteros: una jornada corta
sigue contando como un día. No se convierte el Gantt a programación por horas.
Las nuevas recurrencias se aplican también al calendario exportado a Project.

Validación realizada con SDK .NET 10.0.100: solución completa Release con
**0 errores y 0 advertencias**, y suite `MYG.Pruebas` con **542 comprobaciones
completadas**, código de salida 0. Se cubren recurrencias, vigencias, ordinales,
Gantt, compatibilidad y persistencia JSON/SQLite, además del modelo y XML de
exportación a Microsoft Project. Se omitieron la prueba de Named Pipes de
Windows y la muestra externa opcional LLACUSBAMBA, que no está incluida.

La validación de esta entrega se ejecutó en Linux. Compilar los proyectos de
interfaz no prueba su ejecución visual en Windows. Quedan por comprobar en
Windows el tamaño, DPI, temas, navegación, edición con spinner y guardado de
una copia de su proyecto real. La integración de Revit requiere Revit 2027.

## GitHub del código

Después de copiar los archivos, revise «Cambios de Git» en Visual Studio,
compruebe la rama `main`, compile y ejecute las pruebas. Haga Commit de los
archivos de esta actualización y después Push con su flujo habitual.
Verifique en GitHub la rama y el commit publicado. La publicación del ZIP en
`bimchimbote-droid/DESCARGAS` no aplica cambios a su copia local ni publica
modificaciones en el repositorio del código.
