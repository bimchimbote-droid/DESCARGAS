using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Horas de la jornada; mantiene los valores de la tabla en formato HH:mm.</summary>
internal sealed class MYGHoraTrabajoColumn : DataGridViewTextBoxColumn
{
    [DefaultValue(false)]
    public bool PermitirFinDelDia { get; set; }

    public MYGHoraTrabajoColumn() => CellTemplate = new MYGHoraTrabajoCell();

    public override object Clone()
    {
        var copia = (MYGHoraTrabajoColumn)base.Clone();
        copia.PermitirFinDelDia = PermitirFinDelDia;
        return copia;
    }
}

internal static class MYGHoraTrabajoFormato
{
    private static readonly Regex Patron = new(
        @"^\s*(\d{1,2})\s*:\s*(\d{2})\s*(?:([ap])\s*\.?\s*m\s*\.?)?\s*$",
        RegexOptions.CultureInvariant | RegexOptions.IgnoreCase);

    /// <summary>Acepta HH:mm y hh:mm a. m./p. m.; null conserva el error para validarlo en el formulario.</summary>
    internal static int? Minutos(string texto, bool permitirFinDelDia)
    {
        var coincidencia = Patron.Match(texto ?? "");
        if (!coincidencia.Success ||
            !int.TryParse(coincidencia.Groups[1].Value, NumberStyles.None, CultureInfo.InvariantCulture, out int hora) ||
            !int.TryParse(coincidencia.Groups[2].Value, NumberStyles.None, CultureInfo.InvariantCulture, out int minuto) ||
            minuto > 59) return null;

        string periodo = coincidencia.Groups[3].Value;
        if (periodo.Length != 0)
        {
            if (hora is < 1 or > 12) return null;
            hora = hora % 12 + (periodo.Equals("p", StringComparison.OrdinalIgnoreCase) ? 12 : 0);
        }
        else if (hora > 23 && !(permitirFinDelDia && hora == 24 && minuto == 0)) return null;
        return hora * 60 + minuto;
    }

    internal static string Mostrar(int minutos)
    {
        if (minutos is < 0 or > 1440) throw new ArgumentOutOfRangeException(nameof(minutos));
        if (minutos == 1440) return "24:00";
        int hora = minutos / 60;
        return (hora % 12 == 0 ? 12 : hora % 12).ToString("00", CultureInfo.InvariantCulture) + ":" +
            (minutos % 60).ToString("00", CultureInfo.InvariantCulture) + (hora < 12 ? " a. m." : " p. m.");
    }

    internal static string Guardar(int minutos) => (minutos / 60).ToString("00", CultureInfo.InvariantCulture) + ":" +
        (minutos % 60).ToString("00", CultureInfo.InvariantCulture);
}

internal sealed class MYGHoraTrabajoCell : DataGridViewTextBoxCell
{
    public MYGHoraTrabajoCell() { }

    public override Type EditType => typeof(MYGHoraTrabajoEditingControl);

    protected override object GetFormattedValue(object value, int rowIndex, ref DataGridViewCellStyle cellStyle,
        TypeConverter valueTypeConverter, TypeConverter formattedValueTypeConverter, DataGridViewDataErrorContexts context)
    {
        string texto = Convert.ToString(value, CultureInfo.InvariantCulture) ?? "";
        return MYGHoraTrabajoFormato.Minutos(texto, true) is int minutos ? MYGHoraTrabajoFormato.Mostrar(minutos) : texto;
    }

    public override object ParseFormattedValue(object formattedValue, DataGridViewCellStyle cellStyle,
        TypeConverter formattedValueTypeConverter, TypeConverter valueTypeConverter)
    {
        string texto = Convert.ToString(formattedValue, CultureInfo.InvariantCulture) ?? "";
        // No sustituir entradas inválidas: el formulario debe conservarlas y permitir su corrección.
        return MYGHoraTrabajoFormato.Minutos(texto, true) is int minutos ? MYGHoraTrabajoFormato.Guardar(minutos) : texto;
    }

    public override void InitializeEditingControl(int rowIndex, object initialFormattedValue, DataGridViewCellStyle cellStyle)
    {
        base.InitializeEditingControl(rowIndex, initialFormattedValue, cellStyle);
        if (DataGridView?.EditingControl is MYGHoraTrabajoEditingControl editor)
            editor.Inicializar(Convert.ToString(Value, CultureInfo.InvariantCulture) ?? "",
                (OwningColumn as MYGHoraTrabajoColumn)?.PermitirFinDelDia == true);
    }
}

/// <summary>Editor con flechas nativas; el texto libre se valida al confirmar la jornada.</summary>
internal sealed class MYGHoraTrabajoEditingControl : UpDownBase, IDataGridViewEditingControl
{
    private bool inicializando;
    private bool permitirFinDelDia;
    private TextBox Entrada => Controls.OfType<TextBox>().FirstOrDefault();

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataGridView EditingControlDataGridView { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int EditingControlRowIndex { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool EditingControlValueChanged { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public object EditingControlFormattedValue
    {
        get => Text;
        set => Inicializar(Convert.ToString(value, CultureInfo.InvariantCulture) ?? "", permitirFinDelDia);
    }
    public Cursor EditingPanelCursor => Cursors.Default;
    public bool RepositionEditingControlOnValueChange => false;

    public MYGHoraTrabajoEditingControl()
    {
        BorderStyle = BorderStyle.None;
        InterceptArrowKeys = true;
        TabStop = false;
        AccessibleName = "Hora de trabajo. Escriba HH:mm o use las flechas para aumentar o disminuir horas y minutos.";
    }

    internal void Inicializar(string texto, bool permitirFin)
    {
        inicializando = true;
        try
        {
            permitirFinDelDia = permitirFin;
            Text = texto;
            EditingControlValueChanged = false;
        }
        finally { inicializando = false; }
    }

    public object GetEditingControlFormattedValue(DataGridViewDataErrorContexts context) => Text;

    public void ApplyCellStyleToEditingControl(DataGridViewCellStyle estilo)
    {
        Font = estilo.Font ?? Control.DefaultFont;
        ForeColor = estilo.ForeColor;
        BackColor = Color.FromArgb(255, estilo.BackColor);
        TextAlign = estilo.Alignment switch
        {
            DataGridViewContentAlignment.TopRight or DataGridViewContentAlignment.MiddleRight or DataGridViewContentAlignment.BottomRight => HorizontalAlignment.Right,
            DataGridViewContentAlignment.TopCenter or DataGridViewContentAlignment.MiddleCenter or DataGridViewContentAlignment.BottomCenter => HorizontalAlignment.Center,
            _ => HorizontalAlignment.Left
        };
    }

    public void PrepareEditingControlForEdit(bool selectAll)
    {
        if (Entrada is { } entrada) entrada.Select(selectAll ? 0 : entrada.TextLength, selectAll ? entrada.TextLength : 0);
    }

    public bool EditingControlWantsInputKey(Keys keyData, bool dataGridViewWantsInputKey) => (keyData & Keys.KeyCode) switch
    {
        Keys.Up or Keys.Down or Keys.Left or Keys.Right or Keys.Home or Keys.End or Keys.Delete => true,
        Keys.Tab or Keys.Enter or Keys.Escape => false,
        _ => !dataGridViewWantsInputKey
    };

    public override void UpButton() => Incrementar(1);
    public override void DownButton() => Incrementar(-1);

    private void Incrementar(int direccion)
    {
        if (ReadOnly || MYGHoraTrabajoFormato.Minutos(Text, permitirFinDelDia) is not int minutos) return;
        int posicion = Entrada?.SelectionStart ?? 0;
        int separador = Text.IndexOf(':');
        bool teniaPeriodo = Text.Any(c => c is 'a' or 'A' or 'p' or 'P');
        int paso = posicion <= separador ? 60 : teniaPeriodo && posicion > separador + 2 ? 720 : 1;
        int siguiente = paso == 720 ? (minutos + 720) % 1440 :
            Math.Clamp(minutos + direccion * paso, 0, permitirFinDelDia ? 1440 : 1439);
        if (siguiente == minutos) return;
        Text = teniaPeriodo && siguiente < 1440 ? MYGHoraTrabajoFormato.Mostrar(siguiente) : MYGHoraTrabajoFormato.Guardar(siguiente);
        int inicio = paso == 60 ? 0 : paso == 1 ? 3 : 6;
        Entrada?.Select(Math.Min(inicio, Text.Length), Math.Min(paso == 720 ? 5 : 2, Math.Max(0, Text.Length - inicio)));
    }

    protected override void OnTextChanged(EventArgs e)
    {
        base.OnTextChanged(e);
        if (inicializando) return;
        EditingControlValueChanged = true;
        EditingControlDataGridView?.NotifyCurrentCellDirty(true);
    }

    // UpDownBase debe conservar cualquier texto sin corregirlo antes de la validación del host.
    protected override void ValidateEditText() { }
    protected override void UpdateEditText() { }
}
