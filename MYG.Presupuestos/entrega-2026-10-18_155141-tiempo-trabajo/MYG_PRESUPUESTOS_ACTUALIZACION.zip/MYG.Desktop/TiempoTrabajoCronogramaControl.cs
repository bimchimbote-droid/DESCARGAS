using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Editor de calendarios sobre una copia. Sólo Guardar incorpora una transacción al proyecto.</summary>
internal sealed class MYGTiempoTrabajoCronogramaControl : UserControl
{
    private const string Prefijo = "cronograma_tiempo_";
    private readonly Func<MYGCronograma> obtener;
    private readonly Action<MYGCronograma> aplicar;
    private readonly Func<bool> puedeEditar;
    private readonly CheckedListBox dias = new() { Name = Prefijo + "dias", Dock = DockStyle.Fill, CheckOnClick = true, IntegralHeight = false };
    private readonly DataGridView horario = TablaHorario("horario");
    private readonly DataGridView horarioExcepcion = TablaHorario("excepcion_horario");
    private readonly DataGridView excepciones = new() { Name = Prefijo + "excepciones", Dock = DockStyle.Fill };
    private readonly ComboBox calendarios = new() { Name = Prefijo + "calendarios", DropDownStyle = ComboBoxStyle.DropDownList, Width = 190 };
    private readonly Label actual = new() { Name = Prefijo + "calendario_actual", Dock = DockStyle.Top, Height = 25, TextAlign = ContentAlignment.MiddleLeft };
    private readonly Label horasDia = new() { Name = Prefijo + "horas_dia", AutoSize = true, Padding = new(2, 6, 2, 0) };
    private readonly Label resumen = new() { Name = Prefijo + "resumen_horas", Dock = DockStyle.Bottom, Height = 36, TextAlign = ContentAlignment.MiddleLeft };
    private readonly Label fechaActual = new() { Name = Prefijo + "fecha_actual", AutoSize = true, Padding = new(3, 7, 3, 0) };
    private readonly Label mensaje = new() { Name = Prefijo + "mensaje", Dock = DockStyle.Bottom, Height = 28, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly MYGMesesTrabajoCronogramaControl meses = new() { Name = Prefijo + "meses", Dock = DockStyle.Fill };
    private readonly TextBox nombreExcepcion = new() { Name = Prefijo + "excepcion_nombre", MaxLength = 160 };
    private readonly ComboBox tipoExcepcion = new() { Name = Prefijo + "excepcion_tipo", DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly DateTimePicker desde = MYGCronogramaDialogoUI.Fecha(Prefijo + "excepcion_desde", DateTime.Today);
    private readonly DateTimePicker hasta = MYGCronogramaDialogoUI.Fecha(Prefijo + "excepcion_hasta", DateTime.Today);
    private readonly NumericUpDown diaMes = new() { Name = Prefijo + "excepcion_dia", Minimum = 1, Maximum = 31, Value = 1 };
    private readonly ComboBox mes = new() { Name = Prefijo + "excepcion_mes", DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox diaSemanaExcepcion = new() { Name = Prefijo + "excepcion_dia_semana", DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox numeroSemana = new() { Name = Prefijo + "excepcion_numero_semana", DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly CheckBox mostrarBase = new() { Name = Prefijo + "mostrar_calendario_base", Text = "Mostrar calendario base", AutoSize = true };
    private readonly Dictionary<Control, (TableLayoutPanel Tabla, int Fila, Label Etiqueta)> camposExcepcion = new();
    private readonly RadioButton noLaborable = new() { Name = Prefijo + "excepcion_no_laborable", Text = "No laborable", AutoSize = true, Checked = true };
    private readonly RadioButton laborable = new() { Name = Prefijo + "excepcion_laborable", Text = "Laborable", AutoSize = true };
    private readonly Button colorExcepcion = new() { Name = Prefijo + "excepcion_color", Text = "Color…", AutoSize = true };
    private readonly List<Control> requiereEdicion = new();
    private readonly List<Button> botones = new();
    private readonly ToolTip ayuda = new();
    private MYGCronograma borrador;
    private MYGCalendarioTrabajo seleccionado;
    private MYGExcepcionCalendario excepcion;
    private string firmaInicial;
    private DayOfWeek diaSeleccionado = DayOfWeek.Monday;
    private DateTime fechaSeleccionada = DateTime.Today;
    private bool cargando, aplicando, finalizando, navegando, horarioPendiente, excepcionPendiente;

    internal MYGTiempoTrabajoCronogramaControl(Func<MYGCronograma> obtener,
        Action<MYGCronograma> aplicar, Func<bool> puedeEditar)
    {
        this.obtener = obtener ?? throw new ArgumentNullException(nameof(obtener));
        this.aplicar = aplicar ?? throw new ArgumentNullException(nameof(aplicar));
        this.puedeEditar = puedeEditar ?? throw new ArgumentNullException(nameof(puedeEditar));
        Name = "cronograma_tiempo_trabajo";
        AccessibleName = "Tiempo de trabajo: calendario, jornada y excepciones del proyecto";
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        Font = new Font("Segoe UI", 9F);
        Dock = DockStyle.Fill;
        Height = 380;
        AutoScroll = true;
        var contenido = new TableLayoutPanel
        {
            Name = Prefijo + "contenido", Dock = DockStyle.Fill, MinimumSize = new Size(1480, 344),
            ColumnCount = 3, RowCount = 1, Padding = new Padding(4)
        };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19));
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 36));
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        contenido.Controls.Add(CrearSemana(), 0, 0);
        contenido.Controls.Add(CrearCalendarios(), 1, 0);
        contenido.Controls.Add(CrearExcepciones(), 2, 0);
        Controls.Add(contenido);
        PrepararEventos();
        MYG2027_TemaComercial.CambioTema += CambioTema;
        Disposed += (_, _) => { MYG2027_TemaComercial.CambioTema -= CambioTema; ayuda.Dispose(); Font.Dispose(); };
        AplicarTema();
        Refrescar();
    }

    private bool Editable => puedeEditar();
    internal bool TieneCambios => borrador != null && (horarioPendiente || excepcionPendiente ||
        HoraEditada(horario) || HoraEditada(horarioExcepcion) || Firma() != firmaInicial);

    private static bool HoraEditada(DataGridView tabla) => tabla.IsCurrentCellInEditMode && tabla.CurrentCell != null &&
        Convert.ToString(tabla.CurrentCell.EditedFormattedValue) != Convert.ToString(tabla.CurrentCell.Value);

    private Control CrearSemana()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 0, 5, 0) };
        var division = new SplitContainer
        {
            Name = Prefijo + "division_semana", Dock = DockStyle.Fill, Size = new Size(300, 290),
            SplitterDistance = 100, Panel1MinSize = 90, Panel2MinSize = 170, SplitterWidth = 4
        };
        dias.Items.AddRange(new object[] { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" });
        dias.AccessibleName = "Días laborables de la semana";
        dias.ItemHeight = 25;
        division.Panel1.Controls.Add(dias);
        division.Panel1.Controls.Add(Titulo("Día laboral"));
        var pie = Fila(34);
        pie.Controls.Add(horasDia);
        pie.Controls.Add(Boton("+", "horario_agregar", () => AgregarTramo(horario), true, "Agregar un tramo horario al día seleccionado"));
        pie.Controls.Add(Boton("−", "horario_eliminar", () => EliminarTramo(horario), true, "Eliminar el tramo horario seleccionado"));
        division.Panel2.Controls.Add(horario);
        division.Panel2.Controls.Add(Titulo("Horario de trabajo"));
        division.Panel2.Controls.Add(pie);
        panel.Controls.Add(division);
        panel.Controls.Add(resumen);
        ayuda.SetToolTip(dias, "Marque los días laborables. Seleccione un día para editar todos sus tramos horarios.");
        ayuda.SetToolTip(horario, "Escriba horas de 00:00 a 24:00. Un día puede contener varios tramos sin solaparse.");
        return panel;
    }

    private Control CrearCalendarios()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(4, 0, 4, 0) };
        var selector = Fila(36, DockStyle.Top);
        selector.AutoScroll = true;
        selector.Controls.Add(new Label { Text = "Cambiar cal.:", AutoSize = true, Padding = new(0, 7, 0, 0) });
        selector.Controls.Add(calendarios);
        selector.Controls.Add(Boton("+", "calendario_agregar", AgregarCalendario, true, "Crear un calendario a partir del seleccionado"));
        selector.Controls.Add(Boton("✎", "calendario_renombrar", RenombrarCalendario, true, "Cambiar el nombre del calendario seleccionado"));
        selector.Controls.Add(Boton("−", "calendario_eliminar", EliminarCalendario, true, "Eliminar el calendario seleccionado"));
        selector.Controls.Add(Boton("Usar", "calendario_activar", ActivarCalendario, true, "Usar el calendario seleccionado en el proyecto"));
        var navegacion = Fila(40);
        navegacion.Controls.Add(Boton("◀", "mes_anterior", () => meses.Desplazar(-1)));
        navegacion.Controls.Add(Boton("Hoy", "hoy", () => SeleccionarFecha(DateTime.Today)));
        navegacion.Controls.Add(Boton("▶", "mes_siguiente", () => meses.Desplazar(1)));
        navegacion.Controls.Add(Boton("Inicio", "inicio_proyecto", () => SeleccionarFecha(obtener().FechaInicio)));
        navegacion.Controls.Add(Boton("Fin", "fin_proyecto", () => SeleccionarFecha(MYGMotorCronograma.Calcular(obtener()).Fin)));
        navegacion.Controls.Add(Boton("Ir a la fecha", "ir_fecha", IrFecha));
        var estadoFecha = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 55, WrapContents = true };
        estadoFecha.Controls.Add(fechaActual);
        estadoFecha.Controls.Add(mostrarBase);
        panel.Controls.Add(meses);
        panel.Controls.Add(selector);
        panel.Controls.Add(actual);
        panel.Controls.Add(estadoFecha);
        panel.Controls.Add(navegacion);
        meses.ObtenerCalendario = () => seleccionado;
        meses.MostrarBase = () => mostrarBase.Checked;
        mostrarBase.CheckedChanged += (_, _) => ActualizarResumen();
        meses.FechaSeleccionada += fecha => Intentar(() => SeleccionarFecha(fecha));
        return panel;
    }

    private Control CrearExcepciones()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(3, 0, 0, 0) };
        var division = new SplitContainer
        {
            Name = Prefijo + "division_excepciones", Dock = DockStyle.Fill, Size = new Size(660, 285),
            SplitterDistance = 355, Panel1MinSize = 295, Panel2MinSize = 285, SplitterWidth = 5
        };
        excepciones.AutoGenerateColumns = false;
        excepciones.AccessibleName = "Excepciones del calendario seleccionado";
        excepciones.AllowUserToAddRows = excepciones.AllowUserToDeleteRows = false;
        excepciones.AllowUserToResizeRows = false;
        excepciones.ReadOnly = true;
        excepciones.RowHeadersVisible = false;
        excepciones.MultiSelect = false;
        excepciones.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        excepciones.Columns.Add(new DataGridViewTextBoxColumn { Name = "NOMBRE", HeaderText = "Descripción", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, MinimumWidth = 120 });
        excepciones.Columns.Add(new DataGridViewTextBoxColumn { Name = "TIPO", HeaderText = "Tipo", Width = 145 });
        excepciones.Columns.Add(new DataGridViewTextBoxColumn { Name = "COLOR", HeaderText = "Color", Width = 55 });
        var acciones = Fila(36);
        acciones.Controls.Add(Boton("Ubicar excepción", "excepcion_ubicar", UbicarExcepcion));
        acciones.Controls.Add(Boton("+ Agregar", "excepcion_agregar", AgregarExcepcion, true));
        acciones.Controls.Add(Boton("Eliminar", "excepcion_eliminar", EliminarExcepcion, true));
        division.Panel1.Controls.Add(excepciones);
        division.Panel1.Controls.Add(Titulo("Excepciones"));
        division.Panel1.Controls.Add(acciones);
        division.Panel2.Controls.Add(CrearDetalleExcepcion());
        var pie = Fila(38);
        pie.FlowDirection = FlowDirection.RightToLeft;
        pie.Controls.Add(Boton("Guardar cambios", "guardar", GuardarCambios, true));
        pie.Controls.Add(Boton("Descartar cambios", "descartar", DescartarCambios, true));
        panel.Controls.Add(division);
        panel.Controls.Add(mensaje);
        panel.Controls.Add(pie);
        return panel;
    }

    private Control CrearDetalleExcepcion()
    {
        var pestanas = new TabControl { Name = Prefijo + "excepcion_pestanas", Dock = DockStyle.Fill };
        var configurar = new TabPage("Configurar") { AutoScroll = true };
        var trabajo = new TabPage("Horario") { AutoScroll = true };
        var tabla = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Padding = new Padding(5) };
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 107));
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        void Campo(string texto, Control control)
        {
            int fila = tabla.RowCount++;
            tabla.RowStyles.Add(new RowStyle(SizeType.Absolute, 31));
            var etiqueta = new Label { Text = texto, AutoSize = true, Anchor = AnchorStyles.Left };
            tabla.Controls.Add(etiqueta, 0, fila);
            control.Dock = DockStyle.Fill; tabla.Controls.Add(control, 1, fila);
            camposExcepcion[control] = (tabla, fila, etiqueta);
            requiereEdicion.Add(control);
        }
        tipoExcepcion.Items.AddRange(new object[] { "Fecha o rango de fechas", "Día de la semana", "Día del mes",
            "Día de la n-ésima semana del mes", "Día y mes del año", "Día de la n-ésima semana de un mes concreto" });
        tipoExcepcion.DropDownWidth = 355;
        mes.Items.AddRange(CultureInfo.GetCultureInfo("es-PE").DateTimeFormat.MonthNames.Take(12).Cast<object>().ToArray());
        diaSemanaExcepcion.Items.AddRange(new object[] { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" });
        numeroSemana.Items.AddRange(new object[] { "Primera", "Segunda", "Tercera", "Cuarta" });
        desde.ShowCheckBox = hasta.ShowCheckBox = true;
        ayuda.SetToolTip(desde, "Límite inicial inclusivo. Desmarque para aplicar la repetición sin límite inicial.");
        ayuda.SetToolTip(hasta, "Límite final inclusivo. Desmarque para repetir sin fecha final; en un rango sin fecha final se aplica sólo el día inicial.");
        Campo("Nombre:", nombreExcepcion); Campo("Tipo:", tipoExcepcion);
        Campo("Rango del:", desde); Campo("Al:", hasta);
        Campo("Día de semana:", diaSemanaExcepcion); Campo("N.º de semana:", numeroSemana);
        Campo("N.º día del mes:", diaMes); Campo("Mes:", mes); Campo("Color:", colorExcepcion);
        configurar.Controls.Add(tabla);
        var modo = Fila(34, DockStyle.Top); modo.Controls.Add(noLaborable); modo.Controls.Add(laborable);
        var acciones = Fila(34);
        acciones.Controls.Add(Boton("+ Tramo", "excepcion_horario_agregar", () => AgregarTramo(horarioExcepcion), true));
        acciones.Controls.Add(Boton("− Tramo", "excepcion_horario_eliminar", () => EliminarTramo(horarioExcepcion), true));
        var nota = new Label { Dock = DockStyle.Bottom, Height = 35, Text = "Laborable sin tramos: usa la jornada semanal o la jornada habitual.", Padding = new(3) };
        trabajo.Controls.Add(horarioExcepcion); trabajo.Controls.Add(modo); trabajo.Controls.Add(nota); trabajo.Controls.Add(acciones);
        pestanas.TabPages.Add(configurar); pestanas.TabPages.Add(trabajo);
        requiereEdicion.Add(noLaborable); requiereEdicion.Add(laborable);
        return pestanas;
    }

    private void PrepararEventos()
    {
        dias.SelectedIndexChanged += (_, _) =>
        {
            if (cargando || navegando || dias.SelectedIndex < 0) return;
            int nuevoIndice = dias.SelectedIndex;
            Intentar(() =>
            {
                navegando = true;
                try
                {
                    FinalizarEdicion();
                    diaSeleccionado = (DayOfWeek)nuevoIndice;
                    MostrarHorarioSemanal();
                }
                catch { Cargando(() => dias.SelectedIndex = (int)diaSeleccionado); throw; }
                finally { navegando = false; }
            });
        };
        dias.ItemCheck += (_, e) =>
        {
            if (cargando || seleccionado == null) return;
            if (!Editable) { e.NewValue = e.CurrentValue; return; }
            try
            {
                FinalizarEdicion();
                MaterializarSemana();
                var dia = seleccionado.HorariosSemanales.Single(h => h.Dia == (DayOfWeek)e.Index);
                if (e.NewValue == CheckState.Checked && dia.Tramos.Count == 0) dia.Tramos = JornadaHabitual(seleccionado);
                else if (e.NewValue != CheckState.Checked) dia.Tramos.Clear();
                SincronizarDiasLegacy();
                if (diaSeleccionado == dia.Dia) MostrarHorarioSemanal();
                ActualizarResumen();
            }
            catch (Exception ex) { e.NewValue = e.CurrentValue; Error(ex); }
        };
        horario.CellValueChanged += (_, _) => { if (!cargando) horarioPendiente = true; };
        horarioExcepcion.CellValueChanged += (_, _) => { if (!cargando) excepcionPendiente = true; };
        horario.CellEndEdit += (_, _) => Intentar(GuardarHorarioSemanal);
        horarioExcepcion.CellEndEdit += (_, _) => Intentar(GuardarHorarioExcepcion);
        foreach (var tabla in new[] { horario, horarioExcepcion })
            tabla.DataError += (_, e) => { e.ThrowException = false; Error(new InvalidDataException("Escriba horas válidas en formato HH:mm.")); };
        calendarios.SelectedIndexChanged += (_, _) =>
        {
            if (cargando || borrador == null || calendarios.SelectedIndex < 0) return;
            int indiceAnterior = borrador.Calendarios.IndexOf(seleccionado);
            Intentar(() =>
            {
                try { FinalizarEdicion(); }
                catch { Cargando(() => calendarios.SelectedIndex = indiceAnterior); throw; }
                seleccionado = borrador.Calendarios[calendarios.SelectedIndex];
                MostrarCalendario();
            });
        };
        excepciones.CurrentCellChanged += (_, _) =>
        {
            if (cargando || navegando) return;
            var nueva = excepciones.CurrentRow?.Tag as MYGExcepcionCalendario;
            if (ReferenceEquals(nueva, excepcion)) return;
            Intentar(() =>
            {
                navegando = true;
                try
                {
                    FinalizarEdicion();
                    excepcion = nueva; MostrarExcepcion();
                }
                catch
                {
                    var anterior = excepciones.Rows.Cast<DataGridViewRow>().FirstOrDefault(f => ReferenceEquals(f.Tag, excepcion));
                    // CurrentCellChanged se ejecuta dentro de SetCurrentCellAddressCore.
                    // Reponer la celda en el siguiente mensaje evita reentrar en ese método nativo.
                    if (anterior != null && IsHandleCreated) BeginInvoke((Action)(() =>
                    {
                        if (IsDisposed || anterior.DataGridView != excepciones) return;
                        Cargando(() =>
                        {
                            excepciones.CurrentCell = anterior.Cells[0];
                            excepciones.ClearSelection(); anterior.Selected = true;
                        });
                    }));
                    throw;
                }
                finally { navegando = false; }
            });
        };
        nombreExcepcion.TextChanged += (_, _) => ActualizarExcepcion();
        tipoExcepcion.SelectedIndexChanged += (_, _) => ActualizarExcepcion();
        desde.ValueChanged += (_, _) => ActualizarExcepcion(); hasta.ValueChanged += (_, _) => ActualizarExcepcion();
        diaMes.ValueChanged += (_, _) => ActualizarExcepcion();
        diaSemanaExcepcion.SelectedIndexChanged += (_, _) => ActualizarExcepcion();
        numeroSemana.SelectedIndexChanged += (_, _) => ActualizarExcepcion();
        foreach (var fecha in new[] { desde, hasta })
        {
            fecha.MouseUp += (_, _) => ActualizarExcepcion();
            fecha.KeyUp += (_, _) => ActualizarExcepcion();
            fecha.Validated += (_, _) => ActualizarExcepcion();
        }
        mes.SelectedIndexChanged += (_, _) =>
        {
            if (cargando) return;
            AjustarMaximoDia();
            ActualizarExcepcion();
        };
        laborable.CheckedChanged += (_, _) => ActualizarExcepcion();
        colorExcepcion.Click += (_, _) => Intentar(() =>
        {
            if (!Editable || excepcion == null) return;
            Color? elegido = MYGColorTiempoTrabajoSelector.Elegir(FindForm(), ColorExcepcion(excepcion.Color));
            if (!elegido.HasValue) return;
            excepcion.Color = "#" + elegido.Value.R.ToString("X2") + elegido.Value.G.ToString("X2") + elegido.Value.B.ToString("X2");
            ActualizarFilaExcepcion(); ActualizarResumen(); MostrarColor();
        });
        excepciones.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex < 0) return;
            if (e.ColumnIndex == excepciones.Columns["COLOR"].Index) colorExcepcion.PerformClick();
            else if (e.ColumnIndex == excepciones.Columns["NOMBRE"].Index)
            { nombreExcepcion.Focus(); nombreExcepcion.SelectAll(); }
            else if (e.ColumnIndex == excepciones.Columns["TIPO"].Index)
            { tipoExcepcion.Focus(); tipoExcepcion.DroppedDown = true; }
        };
    }

    internal void Refrescar()
    {
        if (cargando || aplicando || IsDisposed) return;
        if (TieneCambios) { ActualizarPermisos(); return; }
        CargarCopia();
    }

    private void CargarCopia()
    {
        var plan = obtener() ?? throw new InvalidOperationException("No hay un cronograma disponible.");
        string nombreElegido = seleccionado?.Nombre;
        borrador = MYGProyectoStorage.Copia(plan);
        borrador.Calendario ??= new(); borrador.Calendarios ??= new();
        string nombreActivo = string.IsNullOrWhiteSpace(borrador.Calendario.Nombre) ? "Predeterminado" : borrador.Calendario.Nombre.Trim();
        borrador.Calendario.Nombre = nombreActivo;
        int activo = borrador.Calendarios.FindIndex(c => c != null && string.Equals(c.Nombre?.Trim(), nombreActivo, StringComparison.OrdinalIgnoreCase));
        if (activo < 0) borrador.Calendarios.Add(borrador.Calendario);
        else borrador.Calendarios[activo] = borrador.Calendario;
        var nombres = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var calendario in borrador.Calendarios)
        {
            if (calendario == null) throw new InvalidDataException("La lista de calendarios contiene un calendario vacío.");
            string baseNombre = string.IsNullOrWhiteSpace(calendario.Nombre) ? "Calendario" : calendario.Nombre.Trim();
            string nombre = baseNombre;
            for (int i = 2; !nombres.Add(nombre); i++) nombre = baseNombre + " (" + i + ")";
            calendario.Nombre = nombre;
            MaterializarFeriados(calendario);
        }
        seleccionado = borrador.Calendarios.FirstOrDefault(c => c.Nombre == nombreElegido) ?? borrador.Calendario;
        horarioPendiente = excepcionPendiente = false;
        firmaInicial = Firma();
        fechaSeleccionada = plan.FechaInicio.Date;
        diaSeleccionado = fechaSeleccionada.DayOfWeek;
        meses.IrFecha(fechaSeleccionada);
        MostrarSelectorCalendarios(); MostrarCalendario();
        mensaje.Text = "La duración de las tareas se calcula en días laborables enteros.";
        mensaje.ForeColor = MYG2027_TemaComercial.Secundario;
    }

    private static void MaterializarFeriados(MYGCalendarioTrabajo calendario)
    {
        calendario.Excepciones ??= new();
        var explicitas = calendario.Excepciones.ToList();
        foreach (var fecha in (calendario.Feriados ?? new()).Select(f => f.Date).Distinct())
        {
            if (explicitas.Any(e => e.Contiene(fecha))) continue;
            calendario.Excepciones.Add(new MYGExcepcionCalendario
            { Nombre = "No laborable " + fecha.ToString("dd/MM/yyyy"), Inicio = fecha, Fin = fecha, Laborable = false });
        }
        foreach (var anual in (calendario.FeriadosAnuales ?? new()).GroupBy(f => (f.Mes, f.Dia)).Select(g => g.First()))
        {
            if (explicitas.Any(e => e.TipoEfectivo == MYGTipoExcepcionCalendario.DiaMesDelAnio &&
                !e.Inicio.HasValue && !e.Fin.HasValue && e.Mes == anual.Mes && e.Dia == anual.Dia)) continue;
            calendario.Excepciones.Add(new MYGExcepcionCalendario
            { Nombre = "No laborable " + anual.Dia.ToString("00") + "/" + anual.Mes.ToString("00"), Anual = true, Mes = anual.Mes, Dia = anual.Dia, Laborable = false });
        }
        calendario.Feriados = new(); calendario.FeriadosAnuales = new();
    }

    private string Firma() => borrador == null ? "" : JsonSerializer.Serialize(new { borrador.Calendario, borrador.Calendarios });

    private void MostrarSelectorCalendarios()
    {
        Cargando(() =>
        {
            calendarios.Items.Clear();
            calendarios.Items.AddRange(borrador.Calendarios.Select(c => (object)c.Nombre).ToArray());
            calendarios.SelectedIndex = borrador.Calendarios.IndexOf(seleccionado);
            actual.Text = "Cal. actual: " + borrador.Calendario.Nombre + " (Proyecto)";
        });
    }

    private void MostrarCalendario()
    {
        Cargando(() =>
        {
            for (int d = 0; d < 7; d++) dias.SetItemChecked(d, HorarioSemanal((DayOfWeek)d).Count > 0);
            dias.SelectedIndex = (int)diaSeleccionado;
            MostrarHorarioSemanal();
            MostrarExcepciones();
        });
        ActualizarResumen(); ActualizarPermisos();
    }

    private List<MYGTramoHorario> HorarioSemanal(DayOfWeek dia)
    {
        var copia = MYGProyectoStorage.Copia(seleccionado);
        copia.Feriados = new(); copia.FeriadosAnuales = new(); copia.Excepciones = new();
        // El 4 de enero de 2026 es domingo: sólo importa el día de la semana.
        return copia.ObtenerHorario(new DateTime(2026, 1, 4).AddDays((int)dia))
            .Select(t => new MYGTramoHorario { InicioMinuto = t.InicioMinuto, FinMinuto = t.FinMinuto }).ToList();
    }

    private static List<MYGTramoHorario> JornadaHabitual(MYGCalendarioTrabajo calendario)
    {
        var copia = MYGProyectoStorage.Copia(calendario);
        copia.HorariosSemanales = new(); copia.DiasLaborables = new() { DayOfWeek.Monday };
        copia.Feriados = new(); copia.FeriadosAnuales = new(); copia.Excepciones = new();
        return copia.ObtenerHorario(new DateTime(2026, 1, 5))
            .Select(t => new MYGTramoHorario { InicioMinuto = t.InicioMinuto, FinMinuto = t.FinMinuto }).ToList();
    }

    private void MaterializarSemana()
    {
        if (seleccionado.HorariosSemanales?.Count > 0)
        {
            foreach (DayOfWeek dia in Enum.GetValues<DayOfWeek>())
                if (!seleccionado.HorariosSemanales.Any(h => h.Dia == dia)) seleccionado.HorariosSemanales.Add(new() { Dia = dia });
            return;
        }
        var horarios = Enum.GetValues<DayOfWeek>().Select(d => new MYGHorarioDiaTrabajo { Dia = d, Tramos = HorarioSemanal(d) }).ToList();
        seleccionado.HorariosSemanales = horarios;
    }

    private void SincronizarDiasLegacy() => seleccionado.DiasLaborables = seleccionado.HorariosSemanales
        .Where(h => h.Tramos?.Count > 0).Select(h => h.Dia).ToList();

    private void MostrarHorarioSemanal()
    {
        Cargando(() => CargarHorario(horario, HorarioSemanal(diaSeleccionado)));
        horarioPendiente = false;
        horasDia.Text = "Horas diarias: " + HorarioSemanal(diaSeleccionado).Sum(t => (t.FinMinuto - t.InicioMinuto) / 60m).ToString("0.##");
    }

    private void GuardarHorarioSemanal()
    {
        if (cargando || seleccionado == null || !horarioPendiente) return;
        if (!Editable) throw new InvalidOperationException("Inicie una sesión autorizada para modificar el tiempo de trabajo.");
        var tramos = LeerHorario(horario);
        MaterializarSemana();
        seleccionado.HorariosSemanales.Single(h => h.Dia == diaSeleccionado).Tramos = tramos;
        SincronizarDiasLegacy();
        horarioPendiente = false;
        Cargando(() => dias.SetItemChecked((int)diaSeleccionado, tramos.Count > 0));
        horasDia.Text = "Horas diarias: " + tramos.Sum(t => (t.FinMinuto - t.InicioMinuto) / 60m).ToString("0.##");
        ActualizarResumen();
    }

    private void MostrarExcepciones(string id = null)
    {
        id ??= excepcion?.Id;
        Cargando(() =>
        {
            excepciones.Rows.Clear();
            foreach (var e in seleccionado.Excepciones)
            {
                int indice = excepciones.Rows.Add(e.Nombre, NombreTipo(e), "");
                var fila = excepciones.Rows[indice]; fila.Tag = e;
                fila.Cells["TIPO"].ToolTipText = NombreTipo(e);
                fila.Cells["COLOR"].Style.BackColor = ColorExcepcion(e.Color);
                fila.Cells["COLOR"].Style.SelectionBackColor = ColorExcepcion(e.Color);
                fila.Cells["COLOR"].ToolTipText = e.Color;
            }
            var elegida = excepciones.Rows.Cast<DataGridViewRow>().FirstOrDefault(f => ((MYGExcepcionCalendario)f.Tag).Id == id)
                ?? excepciones.Rows.Cast<DataGridViewRow>().FirstOrDefault();
            excepcion = elegida?.Tag as MYGExcepcionCalendario;
            if (elegida != null) excepciones.CurrentCell = elegida.Cells[0];
            MostrarExcepcion();
        });
    }

    private void MostrarExcepcion()
    {
        Cargando(() =>
        {
            nombreExcepcion.Text = excepcion?.Nombre ?? "";
            tipoExcepcion.SelectedIndex = (int)(excepcion?.TipoEfectivo ?? MYGTipoExcepcionCalendario.FechaORango);
            desde.Value = FechaAdmitida(excepcion?.Inicio ?? fechaSeleccionada, desde);
            hasta.Value = FechaAdmitida(excepcion?.Fin ?? fechaSeleccionada, hasta);
            desde.Checked = excepcion?.Inicio.HasValue == true;
            hasta.Checked = excepcion?.Fin.HasValue == true &&
                (excepcion.TipoEfectivo != MYGTipoExcepcionCalendario.FechaORango || excepcion.Fin?.Date != excepcion.Inicio?.Date);
            mes.SelectedIndex = Math.Clamp((excepcion?.Mes ?? fechaSeleccionada.Month) - 1, 0, 11);
            diaMes.Maximum = tipoExcepcion.SelectedIndex == (int)MYGTipoExcepcionCalendario.DiaMesDelAnio ?
                DateTime.DaysInMonth(2000, mes.SelectedIndex + 1) : 31;
            diaMes.Value = Math.Clamp(excepcion?.Dia ?? fechaSeleccionada.Day, 1, (int)diaMes.Maximum);
            diaSemanaExcepcion.SelectedIndex = Math.Clamp((int)(excepcion?.DiaSemana ?? fechaSeleccionada.DayOfWeek), 0, 6);
            numeroSemana.SelectedIndex = Math.Clamp((excepcion?.NumeroSemana ?? 1) - 1, 0, 3);
            laborable.Checked = excepcion?.Laborable == true; noLaborable.Checked = !laborable.Checked;
            CargarHorario(horarioExcepcion, excepcion?.Tramos ?? new());
            MostrarColor();
        });
        excepcionPendiente = false;
        ActualizarPermisos();
    }

    private static DateTime FechaAdmitida(DateTime fecha, DateTimePicker selector) =>
        fecha.Date < selector.MinDate ? selector.MinDate : fecha.Date > selector.MaxDate ? selector.MaxDate : fecha.Date;

    private void ActualizarExcepcion()
    {
        if (cargando || excepcion == null || !Editable) return;
        AjustarMaximoDia();
        var tipo = (MYGTipoExcepcionCalendario)Math.Max(0, tipoExcepcion.SelectedIndex);
        DateTime? inicio = desde.Checked ? desde.Value.Date : null;
        DateTime? fin = hasta.Checked ? hasta.Value.Date : tipo == MYGTipoExcepcionCalendario.FechaORango ? inicio : null;
        bool usaDiaSemana = tipo is MYGTipoExcepcionCalendario.DiaSemana or MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        bool usaSemana = tipo is MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        bool usaDiaMes = tipo is MYGTipoExcepcionCalendario.DiaMes or MYGTipoExcepcionCalendario.DiaMesDelAnio;
        bool usaMes = tipo is MYGTipoExcepcionCalendario.DiaMesDelAnio or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        // Salir de un campo o consultar la base no convierte las reglas heredadas ni altera su prioridad.
        if (excepcion.Nombre == nombreExcepcion.Text && excepcion.TipoEfectivo == tipo &&
            excepcion.Inicio?.Date == inicio && excepcion.Fin?.Date == fin && excepcion.Laborable == laborable.Checked &&
            (!usaDiaSemana || (int)excepcion.DiaSemana == diaSemanaExcepcion.SelectedIndex) &&
            (!usaSemana || excepcion.NumeroSemana == numeroSemana.SelectedIndex + 1) &&
            (!usaDiaMes || excepcion.Dia == decimal.ToInt32(diaMes.Value)) &&
            (!usaMes || excepcion.Mes == mes.SelectedIndex + 1)) return;
        excepcion.Nombre = nombreExcepcion.Text;
        if (excepcion.Tipo.HasValue || excepcion.TipoEfectivo != tipo) excepcion.Tipo = tipo;
        excepcion.Anual = tipo == MYGTipoExcepcionCalendario.DiaMesDelAnio;
        excepcion.Mes = mes.SelectedIndex + 1;
        excepcion.Dia = decimal.ToInt32(diaMes.Value);
        excepcion.DiaSemana = (DayOfWeek)Math.Max(0, diaSemanaExcepcion.SelectedIndex);
        excepcion.NumeroSemana = numeroSemana.SelectedIndex + 1;
        excepcion.Inicio = inicio;
        excepcion.Fin = fin;
        excepcion.Laborable = laborable.Checked;
        ActualizarFilaExcepcion(); ActualizarPermisos(); ActualizarResumen();
    }

    private void ActualizarFilaExcepcion()
    {
        var fila = excepciones.Rows.Cast<DataGridViewRow>().FirstOrDefault(f => ReferenceEquals(f.Tag, excepcion));
        if (fila == null) return;
        fila.Cells["NOMBRE"].Value = excepcion.Nombre;
        fila.Cells["TIPO"].Value = NombreTipo(excepcion);
        fila.Cells["TIPO"].ToolTipText = NombreTipo(excepcion);
        fila.Cells["COLOR"].Style.BackColor = ColorExcepcion(excepcion.Color);
        fila.Cells["COLOR"].Style.SelectionBackColor = ColorExcepcion(excepcion.Color);
        fila.Cells["COLOR"].ToolTipText = excepcion.Color;
    }

    private void MostrarColor()
    {
        colorExcepcion.BackColor = ColorExcepcion(excepcion?.Color);
        colorExcepcion.ForeColor = MYG2027_TemaComercial.TextoSobreFondoDocumento(colorExcepcion.BackColor);
    }

    private string NombreTipo(MYGExcepcionCalendario valor) =>
        Convert.ToString(tipoExcepcion.Items[Math.Clamp((int)valor.TipoEfectivo, 0, tipoExcepcion.Items.Count - 1)]);

    private void GuardarHorarioExcepcion()
    {
        if (cargando || excepcion == null || !excepcionPendiente) return;
        if (!Editable) throw new InvalidOperationException("Inicie una sesión autorizada para modificar las excepciones.");
        excepcion.Tramos = LeerHorario(horarioExcepcion);
        excepcionPendiente = false;
        ActualizarResumen();
    }

    private void AgregarTramo(DataGridView tabla)
    {
        if (!Editable || seleccionado == null || (ReferenceEquals(tabla, horarioExcepcion) && excepcion == null)) return;
        if (!tabla.EndEdit()) throw new InvalidDataException("Corrija el tramo horario que está editando.");
        var tramos = LeerHorario(tabla);
        int inicio = tramos.Count == 0 ? 480 : tramos[^1].FinMinuto < 1440 ? tramos[^1].FinMinuto : 0;
        // Al agregar después del turno de mañana se propone el descanso del mediodía.
        if (inicio == 720) inicio = 780;
        if (tramos.Count > 0 && inicio <= tramos[^1].InicioMinuto)
            throw new InvalidDataException("El último tramo termina a las 24:00. Edítelo antes de agregar otro.");
        int fila = tabla.Rows.Add(Hora(inicio), Hora(Math.Min(1440, inicio + 240)));
        tabla.CurrentCell = tabla.Rows[fila].Cells[0];
        if (ReferenceEquals(tabla, horario)) { horarioPendiente = true; GuardarHorarioSemanal(); }
        else { excepcionPendiente = true; GuardarHorarioExcepcion(); }
    }

    private void EliminarTramo(DataGridView tabla)
    {
        if (!Editable || tabla.CurrentRow == null) return;
        tabla.CancelEdit();
        tabla.Rows.Remove(tabla.CurrentRow);
        if (ReferenceEquals(tabla, horario)) { horarioPendiente = true; GuardarHorarioSemanal(); }
        else { excepcionPendiente = true; GuardarHorarioExcepcion(); }
    }

    private void AgregarCalendario()
    {
        if (!Editable) return;
        FinalizarEdicion();
        string nombre = PedirNombre("Nuevo calendario", "Calendario " + (borrador.Calendarios.Count + 1));
        if (nombre == null) return;
        ExigirNombreUnico(nombre);
        var nuevo = MYGProyectoStorage.Copia(seleccionado); nuevo.Nombre = nombre;
        borrador.Calendarios.Add(nuevo); seleccionado = nuevo;
        MostrarSelectorCalendarios(); MostrarCalendario();
    }

    private void RenombrarCalendario()
    {
        if (!Editable) return;
        FinalizarEdicion();
        string nombre = PedirNombre("Renombrar calendario", seleccionado.Nombre);
        if (nombre == null || nombre == seleccionado.Nombre) return;
        ExigirNombreUnico(nombre, seleccionado);
        seleccionado.Nombre = nombre;
        MostrarSelectorCalendarios();
    }

    private void EliminarCalendario()
    {
        if (!Editable) return;
        FinalizarEdicion();
        if (borrador.Calendarios.Count <= 1) throw new InvalidOperationException("El proyecto debe conservar al menos un calendario.");
        if (ReferenceEquals(seleccionado, borrador.Calendario))
            throw new InvalidOperationException("Active otro calendario antes de eliminar el calendario del proyecto.");
        borrador.Calendarios.Remove(seleccionado); seleccionado = borrador.Calendario;
        MostrarSelectorCalendarios(); MostrarCalendario();
    }

    private void ActivarCalendario()
    {
        if (!Editable) return;
        FinalizarEdicion();
        borrador.Calendario = seleccionado;
        MostrarSelectorCalendarios(); ActualizarResumen();
    }

    private void ExigirNombreUnico(string nombre, MYGCalendarioTrabajo exceptuar = null)
    {
        if (string.IsNullOrWhiteSpace(nombre) || nombre.Length > 160)
            throw new InvalidDataException("El nombre del calendario debe tener entre 1 y 160 caracteres.");
        if (borrador.Calendarios.Any(c => !ReferenceEquals(c, exceptuar) && string.Equals(c.Nombre, nombre, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("Ya existe un calendario con ese nombre.");
    }

    private string PedirNombre(string titulo, string valor)
    {
        using var dialogo = new Form();
        MYGCronogramaDialogoUI.Preparar(dialogo, Prefijo + "nombre_dialogo", titulo, new Size(430, 185));
        var nombre = new TextBox { Name = Prefijo + "nombre_calendario", Text = valor, MaxLength = 160 };
        var tabla = MYGCronogramaDialogoUI.Tabla(); MYGCronogramaDialogoUI.Campo(tabla, "Nombre:", nombre);
        dialogo.Controls.Add(tabla);
        var error = MYGCronogramaDialogoUI.Error(Prefijo + "nombre");
        MYGCronogramaDialogoUI.Botones(dialogo, Prefijo + "nombre", error, () => ExigirNombreUnico(nombre.Text.Trim(), seleccionado?.Nombre == valor ? seleccionado : null));
        MYGCronogramaDialogoUI.Tema(dialogo);
        dialogo.Shown += (_, _) => { nombre.Focus(); nombre.SelectAll(); };
        return dialogo.ShowDialog(FindForm()) == DialogResult.OK ? nombre.Text.Trim() : null;
    }

    private void AgregarExcepcion()
    {
        if (!Editable) return;
        FinalizarEdicion();
        var nueva = new MYGExcepcionCalendario
        { Nombre = "<Sin Especificar>", Tipo = MYGTipoExcepcionCalendario.FechaORango,
            Inicio = fechaSeleccionada, Fin = fechaSeleccionada, Mes = fechaSeleccionada.Month,
            Dia = fechaSeleccionada.Day, DiaSemana = fechaSeleccionada.DayOfWeek, NumeroSemana = 1,
            Color = "#00FFFF", Laborable = false };
        seleccionado.Excepciones.Add(nueva);
        MostrarExcepciones(nueva.Id); ActualizarResumen();
        nombreExcepcion.Focus(); nombreExcepcion.SelectAll();
    }

    private void EliminarExcepcion()
    {
        if (!Editable || excepcion == null) return;
        // Eliminar permite retirar también una excepción cuyo horario aún no es válido.
        horarioExcepcion.CancelEdit(); excepcionPendiente = false;
        seleccionado.Excepciones.Remove(excepcion); excepcion = null;
        MostrarExcepciones(); ActualizarResumen();
    }

    private void UbicarExcepcion()
    {
        if (excepcion == null) return;
        FinalizarEdicion();
        // Una vigencia ya terminada también se puede localizar, sin fingir una ocurrencia futura.
        DateTime? fecha = excepcion.ProximaFecha(fechaSeleccionada) ?? excepcion.ProximaFecha(excepcion.Inicio ?? desde.MinDate);
        if (!fecha.HasValue) throw new InvalidDataException("La regla no tiene una fecha válida dentro de su rango.");
        SeleccionarFecha(fecha.Value);
    }

    private void IrFecha()
    {
        using var dialogo = new Form();
        MYGCronogramaDialogoUI.Preparar(dialogo, Prefijo + "ir_fecha_dialogo", "Ir a la fecha", new Size(390, 180));
        var fecha = MYGCronogramaDialogoUI.Fecha(Prefijo + "ir_fecha_valor", fechaSeleccionada);
        var tabla = MYGCronogramaDialogoUI.Tabla(); MYGCronogramaDialogoUI.Campo(tabla, "Fecha:", fecha);
        dialogo.Controls.Add(tabla);
        MYGCronogramaDialogoUI.Botones(dialogo, Prefijo + "ir_fecha", MYGCronogramaDialogoUI.Error(Prefijo + "ir_fecha"), () => { });
        MYGCronogramaDialogoUI.Tema(dialogo);
        if (dialogo.ShowDialog(FindForm()) == DialogResult.OK) SeleccionarFecha(fecha.Value);
    }

    private void SeleccionarFecha(DateTime fecha)
    {
        FinalizarEdicion();
        fechaSeleccionada = fecha.Date; diaSeleccionado = fecha.DayOfWeek;
        meses.IrFecha(fechaSeleccionada);
        Cargando(() => dias.SelectedIndex = (int)diaSeleccionado);
        MostrarHorarioSemanal(); ActualizarResumen();
    }

    internal void FinalizarEdicion()
    {
        if (cargando || aplicando || finalizando) return;
        finalizando = true;
        try
        {
            if (!horario.EndEdit() || !horarioExcepcion.EndEdit()) throw new InvalidDataException("Corrija las horas que está editando antes de continuar.");
            GuardarHorarioSemanal(); GuardarHorarioExcepcion();
        }
        finally { finalizando = false; }
    }

    internal void GuardarCambios()
    {
        if (!Editable) throw new InvalidOperationException("Inicie una sesión autorizada para guardar el tiempo de trabajo.");
        FinalizarEdicion();
        if (!TieneCambios) { mensaje.Text = "No hay cambios pendientes."; return; }
        foreach (var calendario in borrador.Calendarios)
        {
            ExigirNombreUnico(calendario.Nombre, calendario);
            if (calendario.Excepciones.Any(e => string.IsNullOrWhiteSpace(e.Nombre) || e.Nombre.Length > 160))
                throw new InvalidDataException("Indique un nombre de 1 a 160 caracteres para cada excepción.");
            calendario.Validar();
        }
        // Se parte del estado actual para conservar las ediciones de tareas efectuadas mientras el panel está abierto.
        var copia = MYGProyectoStorage.Copia(obtener());
        copia.Calendarios = MYGProyectoStorage.Copia(borrador.Calendarios);
        copia.Calendario = MYGProyectoStorage.Copia(borrador.Calendario);
        MYGMotorCronograma.Calcular(copia);
        aplicando = true;
        try { aplicar(copia); }
        finally { aplicando = false; }
        string nombre = seleccionado.Nombre; DateTime fecha = fechaSeleccionada;
        horarioPendiente = excepcionPendiente = false; firmaInicial = Firma();
        CargarCopia();
        seleccionado = borrador.Calendarios.FirstOrDefault(c => c.Nombre == nombre) ?? borrador.Calendario;
        MostrarSelectorCalendarios(); MostrarCalendario(); SeleccionarFecha(fecha);
        mensaje.ForeColor = MYG2027_TemaComercial.Texto;
        mensaje.Text = "Cambios de calendario guardados.";
    }

    internal bool ConfirmarCierre()
    {
        if (!TieneCambios) return true;
        var respuesta = MessageBox.Show(FindForm(), "Hay cambios de tiempo de trabajo pendientes. ¿Desea guardarlos antes de cerrar el panel?",
            "Tiempo de trabajo", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
        if (respuesta == DialogResult.Cancel) return false;
        if (respuesta == DialogResult.No) { CargarCopia(); return true; }
        try { GuardarCambios(); return true; }
        catch (Exception ex) { Error(ex); return false; }
    }

    private void DescartarCambios()
    {
        if (!TieneCambios) return;
        if (MessageBox.Show(FindForm(), "¿Descartar los cambios pendientes de tiempo de trabajo?", "Tiempo de trabajo",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) CargarCopia();
    }

    private void ActualizarResumen()
    {
        if (seleccionado == null) return;
        decimal semanales = Enum.GetValues<DayOfWeek>().Sum(d => HorarioSemanal(d).Sum(t => (t.FinMinuto - t.InicioMinuto) / 60m));
        resumen.Text = "Horas semanales: " + semanales.ToString("0.##") + "     Horas mensuales: " + (semanales * 4).ToString("0.##");
        ayuda.SetToolTip(resumen, "Horas mensuales de referencia: cuatro semanas de la jornada habitual.");
        var consulta = CalendarioMostrado();
        decimal horas = consulta.HorasDelDia(fechaSeleccionada);
        fechaActual.Text = "El " + fechaSeleccionada.ToString("dd/MM/yyyy") + " es: " + (horas > 0 ? "Laborable · " + horas.ToString("0.##") + " h" : "No laborable") +
            (mostrarBase.Checked ? " (base)" : "");
        meses.Invalidate();
    }

    private MYGCalendarioTrabajo CalendarioMostrado()
    {
        if (!mostrarBase.Checked) return seleccionado;
        var copia = MYGProyectoStorage.Copia(seleccionado);
        copia.Excepciones.Clear(); copia.Feriados.Clear(); copia.FeriadosAnuales.Clear();
        return copia;
    }

    private void AjustarMaximoDia() => Cargando(() =>
        diaMes.Maximum = tipoExcepcion.SelectedIndex == (int)MYGTipoExcepcionCalendario.DiaMesDelAnio ?
            DateTime.DaysInMonth(2000, Math.Max(1, mes.SelectedIndex + 1)) : 31);

    private void MostrarCampo(Control control, bool visible)
    {
        var campo = camposExcepcion[control];
        control.Visible = campo.Etiqueta.Visible = visible;
        campo.Tabla.RowStyles[campo.Fila].Height = visible ? 31 : 0;
    }

    private void ActualizarPermisos()
    {
        bool editar = Editable;
        foreach (var control in requiereEdicion) control.Enabled = editar;
        horario.ReadOnly = !editar; dias.Enabled = true;
        bool hay = editar && excepcion != null;
        foreach (var control in new Control[] { nombreExcepcion, tipoExcepcion, colorExcepcion, laborable, noLaborable }) control.Enabled = hay;
        desde.Enabled = hasta.Enabled = hay;
        var tipo = (MYGTipoExcepcionCalendario)Math.Max(0, tipoExcepcion.SelectedIndex);
        bool semanal = tipo is MYGTipoExcepcionCalendario.DiaSemana or MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        bool enesima = tipo is MYGTipoExcepcionCalendario.DiaSemanaDelMes or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        bool mensual = tipo is MYGTipoExcepcionCalendario.DiaMes or MYGTipoExcepcionCalendario.DiaMesDelAnio;
        bool anual = tipo is MYGTipoExcepcionCalendario.DiaMesDelAnio or MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio;
        MostrarCampo(diaSemanaExcepcion, semanal); MostrarCampo(numeroSemana, enesima);
        MostrarCampo(diaMes, mensual); MostrarCampo(mes, anual);
        diaSemanaExcepcion.Enabled = hay && semanal; numeroSemana.Enabled = hay && enesima;
        diaMes.Enabled = hay && mensual; mes.Enabled = hay && anual;
        horarioExcepcion.ReadOnly = !hay || !laborable.Checked;
        horarioExcepcion.Enabled = excepcion != null && laborable.Checked;
        foreach (var boton in botones.Where(b => b.Name.Contains("excepcion_horario_"))) boton.Enabled = hay && laborable.Checked;
    }

    internal void AplicarTema()
    {
        MYG2027_TemaComercial.Aplicar(this);
        foreach (var tabla in new[] { horario, horarioExcepcion, excepciones }) MYG2027_TemaComercial.EstilizarTabla(tabla, 27);
        foreach (var boton in botones) MYG2027_TemaComercial.EstilizarBoton(boton, boton.Name == Prefijo + "guardar" ? 1 : 0);
        if (excepcion != null) MostrarColor();
        meses.Invalidate();
    }

    private void CambioTema(object sender, EventArgs e) => AplicarTema();
    private void Cargando(Action accion) { bool anterior = cargando; cargando = true; try { accion(); } finally { cargando = anterior; } }
    private void Intentar(Action accion) { if (cargando) return; try { accion(); } catch (Exception ex) { Error(ex); } }
    private void Error(Exception ex) { mensaje.ForeColor = Color.Firebrick; mensaje.Text = ex.Message; ayuda.SetToolTip(mensaje, ex.Message); }
    private static Label Titulo(string texto) => new() { Text = texto, Dock = DockStyle.Top, Height = 26, TextAlign = ContentAlignment.MiddleLeft, Padding = new(2, 0, 0, 0) };
    private static FlowLayoutPanel Fila(int alto, DockStyle dock = DockStyle.Bottom) => new() { Dock = dock, Height = alto, WrapContents = false, Padding = new(0, 2, 0, 0) };

    private Button Boton(string texto, string nombre, Action accion, bool edita = false, string descripcion = null)
    {
        var boton = new Button { Name = Prefijo + nombre, Text = texto, AutoSize = true, MinimumSize = new Size(28, 28), Margin = new Padding(2, 1, 2, 1), Padding = new Padding(2, 0, 2, 0), AccessibleName = descripcion ?? texto };
        boton.Click += (_, _) => Intentar(() => { if (!edita || Editable) accion(); });
        ayuda.SetToolTip(boton, descripcion ?? texto); botones.Add(boton);
        if (edita) requiereEdicion.Add(boton);
        return boton;
    }

    private static DataGridView TablaHorario(string nombre)
    {
        var tabla = new DataGridView
        {
            Name = Prefijo + nombre, Dock = DockStyle.Fill, AutoGenerateColumns = false, AllowUserToAddRows = false,
            AllowUserToDeleteRows = false, AllowUserToResizeRows = false, RowHeadersVisible = false,
            MultiSelect = false, SelectionMode = DataGridViewSelectionMode.CellSelect, EditMode = DataGridViewEditMode.EditOnEnter,
            AccessibleName = nombre == "horario" ? "Tramos horarios del día de la semana" : "Tramos horarios de la excepción"
        };
        foreach (var columna in new[] { ("INICIO", "Hora inicio"), ("FIN", "Hora fin") })
            tabla.Columns.Add(new MYGHoraTrabajoColumn { Name = columna.Item1, HeaderText = columna.Item2,
                PermitirFinDelDia = columna.Item1 == "FIN", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                SortMode = DataGridViewColumnSortMode.NotSortable });
        return tabla;
    }

    private static void CargarHorario(DataGridView tabla, IEnumerable<MYGTramoHorario> tramos)
    {
        tabla.CancelEdit(); tabla.Rows.Clear();
        foreach (var tramo in tramos) tabla.Rows.Add(Hora(tramo.InicioMinuto), Hora(tramo.FinMinuto));
    }

    private static string Hora(int minutos) => (minutos / 60).ToString("00") + ":" + (minutos % 60).ToString("00");
    private static int Minutos(object valor, bool fin)
    {
        return MYGHoraTrabajoFormato.Minutos(Convert.ToString(valor), fin) ??
            throw new InvalidDataException("Escriba una hora HH:mm o hh:mm a. m./p. m.; 24:00 sólo puede ser el fin de un tramo.");
    }

    private static List<MYGTramoHorario> LeerHorario(DataGridView tabla)
    {
        var tramos = new List<MYGTramoHorario>();
        foreach (DataGridViewRow fila in tabla.Rows)
        {
            int inicio = Minutos(fila.Cells["INICIO"].Value, false), fin = Minutos(fila.Cells["FIN"].Value, true);
            if (fin <= inicio) throw new InvalidDataException("La hora de fin debe ser posterior al inicio. Para un turno nocturno use dos tramos, uno en cada día.");
            tramos.Add(new() { InicioMinuto = inicio, FinMinuto = fin });
        }
        tramos = tramos.OrderBy(t => t.InicioMinuto).ToList();
        for (int i = 1; i < tramos.Count; i++)
            if (tramos[i].InicioMinuto < tramos[i - 1].FinMinuto) throw new InvalidDataException("Los tramos horarios del mismo día no pueden solaparse.");
        return tramos;
    }

    internal static Color ColorExcepcion(string color)
    {
        try
        {
            Color valor = color?.Length == 9 ? Color.FromArgb(unchecked((int)uint.Parse(color[1..], NumberStyles.HexNumber))) :
                ColorTranslator.FromHtml(string.IsNullOrWhiteSpace(color) ? "#FDE9D9" : color);
            if (valor.A == 255) return valor;
            Color fondo = MYG2027_TemaComercial.Superficie;
            return Color.FromArgb((valor.R * valor.A + fondo.R * (255 - valor.A)) / 255,
                (valor.G * valor.A + fondo.G * (255 - valor.A)) / 255, (valor.B * valor.A + fondo.B * (255 - valor.A)) / 255);
        }
        catch { return Color.FromArgb(253, 233, 217); }
    }
}

/// <summary>Tres meses con selección y colores de excepciones, sin las limitaciones de color del calendario nativo.</summary>
internal sealed class MYGMesesTrabajoCronogramaControl : Control
{
    private readonly List<(Rectangle Area, DateTime Fecha)> celdas = new();
    private DateTime primero = new(DateTime.Today.Year, DateTime.Today.Month, 1);
    private DateTime seleccion = DateTime.Today;
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal Func<MYGCalendarioTrabajo> ObtenerCalendario { get; set; }
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal Func<bool> MostrarBase { get; set; }
    internal event Action<DateTime> FechaSeleccionada;
    internal MYGMesesTrabajoCronogramaControl()
    {
        DoubleBuffered = true; TabStop = true;
        AccessibleName = "Calendario de tres meses. Use las flechas para seleccionar una fecha y RePág o AvPág para cambiar de mes.";
        SetStyle(ControlStyles.Selectable | ControlStyles.ResizeRedraw, true);
    }
    internal void IrFecha(DateTime fecha)
    {
        seleccion = fecha.Date;
        if (seleccion < primero || seleccion >= LimiteMes(primero, 3)) primero = new DateTime(fecha.Year, fecha.Month, 1);
        if (primero.Year == 9999 && primero.Month > 10) primero = new DateTime(9999, 10, 1);
        AccessibleDescription = seleccion.ToString("dd/MM/yyyy"); Invalidate();
    }
    internal void Desplazar(int meses)
    {
        primero = LimiteMes(primero, meses);
        if (primero.Year == 9999 && primero.Month > 10) primero = new DateTime(9999, 10, 1);
        Invalidate();
    }
    private static DateTime LimiteMes(DateTime fecha, int meses)
    { try { return fecha.AddMonths(meses); } catch (ArgumentOutOfRangeException) { return meses < 0 ? DateTime.MinValue : DateTime.MaxValue; } }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e); celdas.Clear();
        e.Graphics.Clear(MYG2027_TemaComercial.Superficie);
        var calendario = ObtenerCalendario?.Invoke();
        int ancho = Math.Max(180, ClientSize.Width / 3), altoFila = Math.Max(23, Math.Min(30, (ClientSize.Height - 34) / 7));
        var cultura = CultureInfo.GetCultureInfo("es-PE");
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        using var azul = new Pen(MYG2027_TemaComercial.Azul, 2);
        string[] dias = { "LU", "MA", "MI", "JU", "VI", "SÁ", "DO" };
        for (int m = 0; m < 3; m++)
        {
            DateTime mes = LimiteMes(primero, m);
            int x = m * ancho + 5, celda = (ancho - 12) / 7;
            TextRenderer.DrawText(e.Graphics, mes.ToString("MMMM yyyy", cultura), Font, new Rectangle(x, 5, celda * 7, 25), MYG2027_TemaComercial.Texto, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            for (int d = 0; d < 7; d++)
                TextRenderer.DrawText(e.Graphics, dias[d], Font, new Rectangle(x + d * celda, 31, celda, altoFila), MYG2027_TemaComercial.Secundario, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            int inicio = ((int)mes.DayOfWeek + 6) % 7;
            for (int dia = 1; dia <= DateTime.DaysInMonth(mes.Year, mes.Month); dia++)
            {
                DateTime fecha = new(mes.Year, mes.Month, dia);
                int posicion = inicio + dia - 1;
                var rect = new Rectangle(x + posicion % 7 * celda, 31 + altoFila + posicion / 7 * altoFila, celda, altoFila);
                var excepcion = MostrarBase?.Invoke() == true ? null : calendario?.ObtenerExcepcion(fecha);
                bool laborable;
                if (MostrarBase?.Invoke() == true)
                {
                    laborable = calendario?.HorariosSemanales?.Count > 0 ?
                        calendario.HorariosSemanales.Any(h => h.Dia == fecha.DayOfWeek && h.Tramos?.Count > 0) :
                        calendario?.DiasLaborables?.Contains(fecha.DayOfWeek) == true;
                }
                else laborable = calendario?.HorasDelDia(fecha) > 0;
                Color fondo = excepcion != null ? MYGTiempoTrabajoCronogramaControl.ColorExcepcion(excepcion.Color) :
                    laborable ? MYG2027_TemaComercial.Superficie : MYG2027_TemaComercial.AzulSuave;
                using (var pincel = new SolidBrush(fondo)) e.Graphics.FillRectangle(pincel, rect);
                e.Graphics.DrawRectangle(borde, rect);
                Color texto = excepcion != null ? MYG2027_TemaComercial.TextoSobreFondoDocumento(fondo) : laborable ? MYG2027_TemaComercial.Texto : Color.Firebrick;
                TextRenderer.DrawText(e.Graphics, dia.ToString(), Font, rect, texto, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                if (fecha == seleccion) e.Graphics.DrawRectangle(azul, Rectangle.Inflate(rect, -1, -1));
                if (fecha == DateTime.Today) e.Graphics.DrawLine(azul, rect.Left + 5, rect.Bottom - 4, rect.Right - 5, rect.Bottom - 4);
                celdas.Add((rect, fecha));
            }
        }
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e); Focus();
        foreach (var celda in celdas)
            if (celda.Area.Contains(e.Location)) { FechaSeleccionada?.Invoke(celda.Fecha); return; }
    }
    protected override bool IsInputKey(Keys keyData) => (keyData & Keys.KeyCode) is Keys.Left or Keys.Right or Keys.Up or Keys.Down or Keys.PageUp or Keys.PageDown or Keys.Home || base.IsInputKey(keyData);
    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        int dias = e.KeyCode switch { Keys.Left => -1, Keys.Right => 1, Keys.Up => -7, Keys.Down => 7, _ => 0 };
        if (dias != 0)
        {
            long numero = Math.Clamp(seleccion.Ticks / TimeSpan.TicksPerDay + dias, 0, DateTime.MaxValue.Ticks / TimeSpan.TicksPerDay);
            FechaSeleccionada?.Invoke(new DateTime(numero * TimeSpan.TicksPerDay)); e.Handled = true;
        }
        else if (e.KeyCode is Keys.PageUp or Keys.PageDown) { Desplazar(e.KeyCode == Keys.PageUp ? -1 : 1); e.Handled = true; }
        else if (e.KeyCode == Keys.Home) { FechaSeleccionada?.Invoke(DateTime.Today); e.Handled = true; }
    }
    protected override void OnMouseWheel(MouseEventArgs e) { base.OnMouseWheel(e); Desplazar(e.Delta > 0 ? -1 : 1); }
}
