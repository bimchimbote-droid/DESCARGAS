using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGColorTiempoTrabajoSelector
{
    internal static Color? Elegir(IWin32Window propietario, Color actual)
    {
        using var dialogo = new Selector(actual);
        return dialogo.ShowDialog(propietario) == DialogResult.OK ? dialogo.ColorElegido : null;
    }

    // Guardar RGB concreto evita que un color de Sistema cambie con el tema de Windows.
    private static Color RGB(Color color) => Color.FromArgb(color.R, color.G, color.B);
    private static string Hex(Color color) => $"#{color.R:X2}{color.G:X2}{color.B:X2}";

    private sealed class Selector : Form
    {
        private const string Prefijo = "cronograma_tiempo_color_";
        private readonly TextBox hexadecimal = new()
        {
            Name = Prefijo + "hex", MaxLength = 7, AccessibleName = "Color hexadecimal RGB",
            CharacterCasing = CharacterCasing.Upper, Dock = DockStyle.Fill
        };
        private readonly Muestra vistaPrevia = new()
        {
            Name = Prefijo + "vista_previa", AccessibleName = "Vista previa del color seleccionado",
            Dock = DockStyle.Fill, Margin = new Padding(3, 0, 3, 0)
        };
        private readonly Button aceptar = new()
        {
            Name = Prefijo + "aceptar", Text = "Aceptar", MinimumSize = new Size(90, 30), AutoSize = true
        };
        private readonly ToolTip ayuda = new();
        internal Color ColorElegido { get; private set; }

        internal Selector(Color actual)
        {
            ColorElegido = RGB(actual);
            MYGCronogramaDialogoUI.Preparar(this, Prefijo + "dialogo", "Color", new Size(420, 430));
            AccessibleName = "Color de la excepción del tiempo de trabajo";
            var pestanas = new TabControl
            {
                Name = Prefijo + "pestanas", Dock = DockStyle.Fill,
                AccessibleName = "Paletas de colores", TabIndex = 0
            };
            var personalizado = new TabPage("Personalizado") { Name = Prefijo + "personalizado", Padding = new Padding(10) };
            personalizado.Controls.Add(CrearPersonalizado());
            pestanas.TabPages.Add(personalizado);
            pestanas.TabPages.Add(CrearLista("Web", false));
            pestanas.TabPages.Add(CrearLista("Sistema", true));

            var pie = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom, Height = 48, Padding = new Padding(10, 6, 10, 6),
                FlowDirection = FlowDirection.RightToLeft, WrapContents = false, TabIndex = 2
            };
            var cancelar = new Button
            {
                Name = Prefijo + "cancelar", Text = "Cancelar", DialogResult = DialogResult.Cancel,
                MinimumSize = new Size(90, 30), AutoSize = true
            };
            pie.Controls.Add(cancelar);
            pie.Controls.Add(aceptar);
            var resumen = new TableLayoutPanel
            {
                Dock = DockStyle.Bottom, Height = 43, ColumnCount = 2, Padding = new Padding(12, 4, 12, 4), TabIndex = 1
            };
            resumen.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            resumen.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            resumen.Controls.Add(new Label { Text = "Color seleccionado:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
            resumen.Controls.Add(vistaPrevia, 1, 0);
            Controls.Add(pestanas);
            Controls.Add(resumen);
            Controls.Add(pie);
            AcceptButton = aceptar;
            CancelButton = cancelar;
            aceptar.Click += (_, _) =>
            {
                if (!TryColor(hexadecimal.Text, out var elegido)) return;
                ColorElegido = elegido;
                DialogResult = DialogResult.OK;
            };
            hexadecimal.TextChanged += (_, _) =>
            {
                aceptar.Enabled = TryColor(hexadecimal.Text, out var elegido);
                if (aceptar.Enabled)
                {
                    ColorElegido = elegido;
                    vistaPrevia.ColorMuestra = elegido;
                    vistaPrevia.AccessibleDescription = Hex(elegido);
                }
            };
            Seleccionar(ColorElegido);
            ayuda.SetToolTip(hexadecimal, "Escriba un color como #336699 (rojo, verde y azul).");
            MYGCronogramaDialogoUI.Tema(this);
        }

        private Control CrearPersonalizado()
        {
            var tabla = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5 };
            tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            tabla.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tabla.RowStyles.Add(new RowStyle(SizeType.Absolute, 166));
            tabla.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
            tabla.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
            tabla.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            tabla.Controls.Add(new Label { Text = "Colores básicos", AutoSize = true, Margin = new Padding(0, 0, 0, 7) }, 0, 0);
            var paleta = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 8, RowCount = 6, Margin = Padding.Empty };
            for (int columna = 0; columna < 8; columna++) paleta.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            for (int fila = 0; fila < 6; fila++) paleta.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / 6));
            int[] colores =
            {
                0xFFFFFF, 0xFFE0E0, 0xFFE6C7, 0xFFFFCC, 0xD6F2D6, 0xD5FFFF, 0xDAE8FF, 0xF4D7FF,
                0xE0E0E0, 0xFFB3B3, 0xFFC080, 0xFFFF80, 0x99DD99, 0x80E5E5, 0xA5C8FF, 0xDAA1EF,
                0xBFBFBF, 0xFF8080, 0xFF9933, 0xFFFF00, 0x66CC66, 0x33CCCC, 0x6699FF, 0xCC66FF,
                0x808080, 0xFF0000, 0xFF6600, 0xCCCC00, 0x00AA00, 0x009999, 0x0066FF, 0x9900CC,
                0x404040, 0xCC0000, 0xCC6600, 0x999900, 0x008000, 0x006666, 0x0033CC, 0x660099,
                0x000000, 0x800000, 0x804000, 0x808000, 0x004000, 0x004040, 0x000080, 0x400040
            };
            for (int n = 0; n < colores.Length; n++)
            {
                var color = Color.FromArgb((colores[n] >> 16) & 255, (colores[n] >> 8) & 255, colores[n] & 255);
                var muestra = new BotonColor(color)
                {
                    Name = Prefijo + "muestra_" + n, Dock = DockStyle.Fill,
                    Margin = new Padding(2), AccessibleName = Hex(color)
                };
                muestra.Click += (_, _) => Seleccionar(color);
                ayuda.SetToolTip(muestra, Hex(color));
                paleta.Controls.Add(muestra, n % 8, n / 8);
            }
            tabla.Controls.Add(paleta, 0, 1);
            var campo = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Margin = new Padding(0, 5, 0, 0) };
            campo.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            campo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            campo.Controls.Add(new Label { Text = "Hexadecimal:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
            campo.Controls.Add(hexadecimal, 1, 0);
            tabla.Controls.Add(campo, 0, 2);
            var mas = new Button
            {
                Name = Prefijo + "mas", Text = "Más colores…", AutoSize = true,
                Anchor = AnchorStyles.Left, AccessibleDescription = "Abre el selector de colores de Windows."
            };
            mas.Click += (_, _) =>
            {
                using var dialogo = new ColorDialog { Color = ColorElegido, FullOpen = true };
                if (dialogo.ShowDialog(this) == DialogResult.OK) Seleccionar(dialogo.Color);
            };
            tabla.Controls.Add(mas, 0, 3);
            return tabla;
        }

        private TabPage CrearLista(string titulo, bool sistema)
        {
            var pagina = new TabPage(titulo) { Name = Prefijo + titulo.ToLowerInvariant() + "_pagina", Padding = new Padding(8) };
            var lista = new ListBox
            {
                Name = Prefijo + titulo.ToLowerInvariant(), Dock = DockStyle.Fill,
                DrawMode = DrawMode.OwnerDrawFixed, ItemHeight = 25, IntegralHeight = false,
                AccessibleName = "Colores " + titulo, BorderStyle = BorderStyle.FixedSingle
            };
            foreach (var color in Enum.GetValues<KnownColor>().Select(Color.FromKnownColor)
                .Where(c => c.IsSystemColor == sistema && c.A == 255).OrderBy(c => c.Name, StringComparer.OrdinalIgnoreCase))
                lista.Items.Add(new ColorNombrado(color.Name, RGB(color)));
            lista.DrawItem += (_, e) =>
            {
                if (e.Index < 0) return;
                var color = (ColorNombrado)lista.Items[e.Index];
                bool seleccionado = (e.State & DrawItemState.Selected) != 0;
                using var fondo = new SolidBrush(seleccionado ? MYG2027_TemaComercial.AzulSuave : lista.BackColor);
                e.Graphics.FillRectangle(fondo, e.Bounds);
                int lado = Math.Max(8, e.Bounds.Height - 8);
                var muestra = new Rectangle(e.Bounds.Left + 5, e.Bounds.Top + 4, lado + 13, lado);
                using var pincel = new SolidBrush(color.Color);
                e.Graphics.FillRectangle(pincel, muestra);
                using var borde = new Pen(MYG2027_TemaComercial.Borde);
                e.Graphics.DrawRectangle(borde, muestra);
                var texto = new Rectangle(muestra.Right + 9, e.Bounds.Top, Math.Max(1, e.Bounds.Right - muestra.Right - 12), e.Bounds.Height);
                TextRenderer.DrawText(e.Graphics, color.Nombre, e.Font, texto, lista.ForeColor,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
                e.DrawFocusRectangle();
            };
            lista.SelectedIndexChanged += (_, _) =>
            {
                if (lista.SelectedItem is ColorNombrado color) Seleccionar(color.Color);
            };
            pagina.Controls.Add(lista);
            return pagina;
        }

        private void Seleccionar(Color color)
        {
            ColorElegido = RGB(color);
            hexadecimal.Text = Hex(ColorElegido);
            vistaPrevia.ColorMuestra = ColorElegido;
        }

        private static bool TryColor(string texto, out Color color)
        {
            color = Color.Empty;
            if (texto.Length != 7 || texto[0] != '#' ||
                !int.TryParse(texto.AsSpan(1), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out int valor)) return false;
            color = Color.FromArgb((valor >> 16) & 255, (valor >> 8) & 255, valor & 255);
            return true;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) ayuda.Dispose();
            base.Dispose(disposing);
        }
    }

    private sealed record ColorNombrado(string Nombre, Color Color)
    {
        public override string ToString() => Nombre;
    }

    // La muestra se dibuja con su RGB, aunque el tema cambie BackColor del control.
    private sealed class Muestra : Control
    {
        private Color colorMuestra;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal Color ColorMuestra { get => colorMuestra; set { colorMuestra = value; Invalidate(); } }
        internal Muestra() { DoubleBuffered = true; AccessibleRole = AccessibleRole.Graphic; }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var rectangulo = new Rectangle(0, 0, Math.Max(0, Width - 1), Math.Max(0, Height - 1));
            using var pincel = new SolidBrush(colorMuestra);
            e.Graphics.FillRectangle(pincel, rectangulo);
            using var borde = new Pen(MYG2027_TemaComercial.Borde);
            e.Graphics.DrawRectangle(borde, rectangulo);
        }
    }

    private sealed class BotonColor : Button
    {
        private readonly Color color;
        internal BotonColor(Color color) { this.color = color; DoubleBuffered = true; }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            var rectangulo = new Rectangle(2, 2, Math.Max(0, Width - 5), Math.Max(0, Height - 5));
            using var pincel = new SolidBrush(color);
            e.Graphics.FillRectangle(pincel, rectangulo);
            using var borde = new Pen(MYG2027_TemaComercial.Borde);
            e.Graphics.DrawRectangle(borde, rectangulo);
            if (Focused) ControlPaint.DrawFocusRectangle(e.Graphics, ClientRectangle, ForeColor, BackColor);
        }
    }
}
