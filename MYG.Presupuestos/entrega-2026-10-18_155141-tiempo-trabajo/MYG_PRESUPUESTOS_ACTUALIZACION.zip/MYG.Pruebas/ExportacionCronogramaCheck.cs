using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Xml;
using System.Xml.Linq;
using MYG_2027;

static class ExportacionCronogramaCheck
{
    private static readonly XNamespace Ns = "http://schemas.microsoft.com/project";
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object o) => JsonSerializer.Serialize(o);
    private static string Valor(XElement e, string nombre) => (string)e.Element(Ns + nombre);
    private static XElement Tarea(XDocument d, string nombre) => d.Root.Element(Ns + "Tasks").Elements(Ns + "Task").Single(t => Valor(t, "Name") == nombre);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        string antes = Firma(proyecto), planAntes = Firma(plan);
        string soloRuta = Path.Combine(carpeta, "Cronograma sólo tareas.xml");
        string recursosRuta = Path.Combine(carpeta, "Cronograma recursos.xml");
        MYGExportacionCronograma.Guardar(soloRuta, proyecto, plan, MYGFormatoExportacionCronograma.XmlTareas);
        MYGExportacionCronograma.Guardar(recursosRuta, proyecto, plan, MYGFormatoExportacionCronograma.XmlTareasRecursos);
        var solo = XDocument.Load(soloRuta); var xml = XDocument.Load(recursosRuta);
        Exige(xml.Root.Name == Ns + "Project" && solo.Root.Element(Ns + "Resources") == null && solo.Root.Element(Ns + "Assignments") == null,
            "El XML no usó el espacio de nombres de Project o incluyó recursos en la opción de sólo tareas.");
        var tareas = xml.Root.Element(Ns + "Tasks").Elements(Ns + "Task").ToArray();
        Exige(tareas.Length == plan.Tareas.Count && tareas.Select(t => (int)t.Element(Ns + "UID")).SequenceEqual(Enumerable.Range(1, tareas.Length)) &&
            Valor(tareas[0], "Summary") == "1" && Valor(tareas[0], "OutlineNumber") == "1" && Valor(tareas[1], "OutlineNumber") == "1.1" &&
            Valor(tareas[1], "OutlineLevel") == "2" && Valor(tareas[1], "WBS") == "0001" && Valor(tareas[1], "Name") == "=Excavación <QA> & \"obra\"" &&
            XmlConvert.ToTimeSpan(Valor(tareas[1], "Duration")) == TimeSpan.FromHours(19.5) &&
            Valor(Tarea(xml, "Hito"), "Milestone") == "1" && Valor(Tarea(xml, "Hito"), "Duration") == "PT0S" &&
            Valor(tareas[1], "PercentComplete") == "38",
            "Project perdió jerarquía, UID, códigos, escapado XML, duración horaria, avance o hitos.");
        var vinculos = tareas.SelectMany(t => t.Elements(Ns + "PredecessorLink")).ToArray();
        Exige(vinculos.Select(v => (int)v.Element(Ns + "Type")).Order().SequenceEqual(new[] { 0, 1, 2, 3 }) &&
            vinculos.All(v => tareas.Any(t => Valor(t, "UID") == Valor(v, "PredecessorUID"))) &&
            vinculos.Any(v => Valor(v, "Type") == "1" && Valor(v, "LinkLag") == "7800") &&
            vinculos.Any(v => Valor(v, "Type") == "3" && Valor(v, "LinkLag") == "-3900"),
            "Los tipos FC/CC/FF/CF, identidades de predecesoras o desfases de décimas de minuto no son coherentes.");
        var manual = Tarea(xml, "Manual importada");
        var baseline = manual.Element(Ns + "Baseline");
        Exige(Valor(manual, "Manual") == "1" && Valor(manual, "ManualStart") == "2026-02-01T08:00:00" &&
            Valor(manual, "ManualFinish") == "2026-02-07T15:30:00" && Valor(manual, "Start") == Valor(manual, "ManualStart") &&
            Valor(manual, "Finish") == Valor(manual, "ManualFinish") && XmlConvert.ToTimeSpan(Valor(manual, "ManualDuration")) == TimeSpan.FromHours(13) &&
            Valor(baseline, "Number") == "0" && Valor(baseline, "Start") == "2025-12-30T08:00:00" && Valor(baseline, "Finish") == "2026-01-02T15:30:00" &&
            XmlConvert.ToTimeSpan(Valor(baseline, "Duration")) == TimeSpan.FromHours(19.5) && Valor(manual, "PercentComplete") == "25",
            "La exportación recalculó fechas manuales importadas o perdió su duración, avance y línea base.");
        string primera = File.ReadAllText(recursosRuta);
        MYGExportacionCronograma.Guardar(recursosRuta, proyecto, plan, MYGFormatoExportacionCronograma.XmlTareasRecursos);
        Exige(File.ReadAllText(recursosRuta) == primera && Firma(proyecto) == antes && Firma(plan) == planAntes,
            "Los UID o el XML variaron entre exportaciones sin cambios, o el exportador editó sus datos.");
        pasa("XML Project conserva jerarquía/UID deterministas, vínculos FC/CC/FF/CF con desfases, hitos, avance, fechas manuales importadas y línea base");

        var calendario = xml.Root.Element(Ns + "Calendars").Element(Ns + "Calendar");
        var dias = calendario.Element(Ns + "WeekDays").Elements(Ns + "WeekDay").ToArray();
        var semanales = dias.Where(d => Valor(d, "DayType") != "0").ToArray();
        var lunes = semanales.Single(d => Valor(d, "DayType") == "2");
        var turno = lunes.Element(Ns + "WorkingTimes").Element(Ns + "WorkingTime");
        var feriados = dias.Where(d => Valor(d, "DayType") == "0").Select(d => d.Element(Ns + "TimePeriod")).ToArray();
        Exige(semanales.Length == 7 && semanales.Count(d => Valor(d, "DayWorking") == "1") == 5 &&
            Valor(semanales.Single(d => Valor(d, "DayType") == "1"), "DayWorking") == "0" &&
            Valor(turno, "FromTime") == "08:00:00" && Valor(turno, "ToTime") == "12:00:00" &&
            lunes.Element(Ns + "WorkingTimes").Elements(Ns + "WorkingTime").Count() == 2 &&
            Valor(lunes.Element(Ns + "WorkingTimes").Elements(Ns + "WorkingTime").Last(), "FromTime") == "13:00:00" &&
            Valor(lunes.Element(Ns + "WorkingTimes").Elements(Ns + "WorkingTime").Last(), "ToTime") == "15:30:00" &&
            Valor(xml.Root, "MinutesPerDay") == "390" && Valor(xml.Root, "MinutesPerWeek") == "1950" &&
            feriados.Any(f => Valor(f, "FromDate") == "2026-02-02T00:00:00") &&
            feriados.Any(f => Valor(f, "FromDate") == "2026-02-03T00:00:00") &&
            feriados.Any(f => Valor(f, "FromDate") == "2025-02-03T00:00:00") &&
            feriados.Count(f => Valor(f, "FromDate") == "2026-02-02T00:00:00") == 1,
            "El calendario no conservó semana, jornada fraccionaria, feriados únicos o anuales del horizonte y línea base.");
        pasa("XML exporta los siete días y los tramos heredados del calendario; conserva feriados y expande anuales en todos los años del plan y línea base");

        var recursos = xml.Root.Element(Ns + "Resources").Elements(Ns + "Resource").ToArray();
        var asignaciones = xml.Root.Element(Ns + "Assignments").Elements(Ns + "Assignment").ToArray();
        var material = recursos.Single(r => Valor(r, "Name") == "Arena & grava");
        var trabajador = recursos.Single(r => Valor(r, "Name") == "Operario QA");
        var porcentaje = recursos.Single(r => Valor(r, "Name") == "Herramientas QA");
        var aMaterial = asignaciones.Single(a => Valor(a, "ResourceUID") == Valor(material, "UID"));
        var aTrabajo = asignaciones.Single(a => Valor(a, "ResourceUID") == Valor(trabajador, "UID"));
        var aPorcentaje = asignaciones.Single(a => Valor(a, "ResourceUID") == Valor(porcentaje, "UID"));
        Exige(recursos.Length == 4 && asignaciones.Length == 4 && recursos.Count(r => Valor(r, "Code") == "0007") == 2 &&
            recursos.All(r => !Valor(r, "Name").Contains("precio directo", StringComparison.OrdinalIgnoreCase) && !Valor(r, "Name").Contains("redondeo", StringComparison.OrdinalIgnoreCase)) &&
            asignaciones.All(a => tareas.Any(t => Valor(t, "UID") == Valor(a, "TaskUID")) && recursos.Any(r => Valor(r, "UID") == Valor(a, "ResourceUID"))) &&
            Valor(material, "Type") == "0" && Valor(material, "MaterialLabel") == "m3" &&
            decimal.Parse(Valor(aMaterial, "Units"), CultureInfo.InvariantCulture) == 8 && decimal.Parse(Valor(aMaterial, "Cost"), CultureInfo.InvariantCulture) == 80 &&
            Valor(trabajador, "Type") == "1" && XmlConvert.ToTimeSpan(Valor(aTrabajo, "Work")) == TimeSpan.FromHours(8) &&
            Math.Abs(decimal.Parse(Valor(aTrabajo, "Units"), CultureInfo.InvariantCulture) - 8m / 19.5m) < 0.000001m &&
            decimal.Parse(Valor(aTrabajo, "Cost"), CultureInfo.InvariantCulture) == 160 &&
            Valor(porcentaje, "Type") == "2" && aPorcentaje.Element(Ns + "Work") == null && aPorcentaje.Element(Ns + "Units") == null &&
            decimal.Parse(Valor(aPorcentaje, "Cost"), CultureInfo.InvariantCulture) == 8,
            "Los recursos/asignaciones no corresponden al ACU real, mezclaron proveedores, omitieron subanálisis o confundieron trabajo, materiales y porcentajes.");
        pasa("XML con recursos usa sólo insumos reales y asignaciones referenciadas: expande subanálisis, separa proveedores y distingue trabajo horario, cantidades materiales y costos porcentuales");

        string textoRuta = Path.Combine(carpeta, "Cronograma legible.txt");
        MYGExportacionCronograma.Guardar(textoRuta, proyecto, plan, MYGFormatoExportacionCronograma.Texto);
        byte[] bytes = File.ReadAllBytes(textoRuta);
        var filas = File.ReadAllText(textoRuta).Split("\r\n", StringSplitOptions.RemoveEmptyEntries).Select(f => f.Split('\t')).ToArray();
        var filaA = filas.Single(f => f[1] == "A"); var filaManual = filas.Single(f => f[1] == "E");
        Exige(bytes.Take(3).SequenceEqual(new byte[] { 0xEF, 0xBB, 0xBF }) && filas.Length == plan.Tareas.Count + 1 && filas.All(f => f.Length == 19) &&
            filaA[4] == "0001" && filaA[5] == "'=Excavación <QA> & \"obra\"" && filaA[18] == "' @NOTA literal segunda línea" &&
            filaA[10] == "2026-01-30" && filaA[11] == "2026-02-05" && filaA[13] == "37.5" && filaManual[10] == "2026-02-01" && filaManual[11] == "2026-02-07",
            "El TSV perdió UTF-8/BOM, fechas, avance fraccionario, estructura de filas o protección de fórmulas.");
        string mhtRuta = Path.Combine(carpeta, "Cronograma web.mht");
        MYGExportacionCronograma.Guardar(mhtRuta, proyecto, plan, MYGFormatoExportacionCronograma.Mht);
        string mht = File.ReadAllText(mhtRuta);
        int inicioHtml = mht.IndexOf("Content-Location: informe.html\r\n\r\n", StringComparison.Ordinal) + "Content-Location: informe.html\r\n\r\n".Length;
        int finHtml = mht.IndexOf("\r\n--", inicioHtml, StringComparison.Ordinal);
        string html = Encoding.UTF8.GetString(Convert.FromBase64String(mht[inicioHtml..finHtml]));
        Exige(mht.StartsWith("MIME-Version: 1.0\r\nContent-Type: multipart/related;", StringComparison.Ordinal) &&
            mht.Contains("Content-Transfer-Encoding: base64\r\n", StringComparison.Ordinal) && html.Contains("DIAGRAMA GANTT", StringComparison.Ordinal) &&
            html.Contains("&lt;QA&gt; &amp;", StringComparison.Ordinal) && Firma(proyecto) == antes && Firma(plan) == planAntes &&
            !Directory.GetFiles(carpeta, "Cronograma*.tmp").Any(),
            "MHT no es el contenedor MIME del informe Gantt existente, perdió escapado o dejó cambios/temporales.");
        pasa("Texto TSV UTF-8 seguro conserva fechas y valores; MHT reutiliza un informe Gantt MIME real, sin modificar documentos ni dejar temporales");

        ComprobarTurnos(carpeta, pasa);
        ComprobarRecurrencias(carpeta, pasa);

        ComprobarRechazos(proyecto, plan, carpeta);
        pasa("Exportación valida antes de reemplazar: rechaza ciclos, vínculos rotos/duplicados y monedas incompatibles sin cambiar el destino ni el documento");
        var vacio = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 1), FechaEstado = new DateTime(2026, 1, 1) };
        string vacioRuta = Path.Combine(carpeta, "Cronograma vacío.xml");
        MYGExportacionCronograma.Guardar(vacioRuta, proyecto, vacio, MYGFormatoExportacionCronograma.XmlTareasRecursos);
        var vacioXml = XDocument.Load(vacioRuta);
        Exige(!vacioXml.Root.Element(Ns + "Tasks").Elements().Any() && !vacioXml.Root.Element(Ns + "Resources").Elements().Any() &&
            !vacioXml.Root.Element(Ns + "Assignments").Elements().Any(), "Un cronograma vacío fabricó tareas, recursos o asignaciones.");
        pasa("Cronograma vacío genera XML válido sin fabricar tareas, recursos ni asignaciones");
    }

    private static void ComprobarTurnos(string carpeta, Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("Turnos reales QA"); var p = d.Presupuestos.Single();
        var operario = new MYGInsumo { Id = "OPERARIO", Codigo = "HH", Descripcion = "Operario turnos", Grupo = MYGGrupoRecurso.ManoObra, Unidad = "hh", Precio = 10 };
        p.Costos.Insumos.Add(operario);
        foreach (string id in new[] { "A", "B" })
        {
            var partida = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, Descripcion = id, TipoPropuesta = "PARTIDA", Unidad = "und" };
            partida.Costos.Cantidad = 1; partida.Costos.Analisis.Add(new() { InsumoId = operario.Id, Grupo = MYGGrupoRecurso.ManoObra, Cantidad = 8 }); p.Items.Add(partida);
        }
        var c = new MYGCalendarioTrabajo { Nombre = "Obra partida y guardias", HorasPorDia = 8 };
        foreach (var dia in new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday })
            c.HorariosSemanales.Add(new() { Dia = dia, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 }, new() { InicioMinuto = 780, FinMinuto = 1020 } } });
        c.HorariosSemanales.Add(new() { Dia = DayOfWeek.Saturday, Tramos = new() { new() { InicioMinuto = 540, FinMinuto = 780 } } });
        c.FeriadosAnuales.Add(new() { Mes = 12, Dia = 25 });
        c.Excepciones.Add(new() { Id = "NAVIDAD", Nombre = "Navidad", Anual = true, Mes = 12, Dia = 25, Laborable = false });
        c.Excepciones.Add(new() { Id = "ENERO", Nombre = "Año nuevo", Anual = true, Mes = 1, Dia = 1, Laborable = false });
        c.Excepciones.Add(new() { Id = "GUARDIA", Nombre = "Guardia Navidad", Inicio = new DateTime(2026, 12, 25), Fin = new DateTime(2026, 12, 25), Laborable = true,
            Tramos = new() { new() { InicioMinuto = 600, FinMinuto = 720 } } });
        c.Excepciones.Add(new() { Id = "CIERRE", Nombre = "Cierre de obra", Inicio = new DateTime(2026, 12, 26), Fin = new DateTime(2026, 12, 27), Laborable = false });
        c.Excepciones.Add(new() { Id = "RANGO", Nombre = "Jornada reducida", Inicio = new DateTime(2026, 12, 28), Fin = new DateTime(2026, 12, 29), Laborable = true,
            Tramos = new() { new() { InicioMinuto = 540, FinMinuto = 720 } } });
        var plan = new MYGCronograma
        {
            FechaInicio = new DateTime(2026, 12, 24), FechaEstado = new DateTime(2026, 12, 31), Calendario = c,
            Tareas = new()
            {
                new() { Id = "A", Nombre = "Turnos A", DuracionDias = 5, PresupuestoId = p.Id, PartidaId = "A",
                    InicioBase = new DateTime(2026, 12, 24), FinBase = new DateTime(2026, 12, 30), DuracionBase = 5 },
                new() { Id = "B", Nombre = "Turnos B", DuracionDias = 2, PresupuestoId = p.Id, PartidaId = "B", Predecesoras = new() { new() { PredecesoraId = "A" } } }
            }
        };
        string dAntes = Firma(d), pAntes = Firma(plan), ruta = Path.Combine(carpeta, "Cronograma turnos reales.xml");
        MYGExportacionCronograma.Guardar(ruta, d, plan, MYGFormatoExportacionCronograma.XmlTareasRecursos);
        var xml = XDocument.Load(ruta); var a = Tarea(xml, "Turnos A"); var b = Tarea(xml, "Turnos B");
        var dias = xml.Root.Element(Ns + "Calendars").Element(Ns + "Calendar").Element(Ns + "WeekDays").Elements(Ns + "WeekDay").ToArray();
        var jueves = dias.Single(e => Valor(e, "DayType") == "5").Element(Ns + "WorkingTimes").Elements(Ns + "WorkingTime").ToArray();
        var sabado = dias.Single(e => Valor(e, "DayType") == "7").Element(Ns + "WorkingTimes").Element(Ns + "WorkingTime");
        var guardia = dias.Single(e => Valor(e, "DayType") == "0" && Valor(e.Element(Ns + "TimePeriod"), "FromDate") == "2026-12-25T00:00:00");
        var rango = dias.Single(e => Valor(e, "DayType") == "0" && Valor(e.Element(Ns + "TimePeriod"), "FromDate") == "2026-12-28T00:00:00");
        var cierre = dias.Single(e => Valor(e, "DayType") == "0" && Valor(e.Element(Ns + "TimePeriod"), "FromDate") == "2026-12-26T00:00:00");
        var asignaciones = xml.Root.Element(Ns + "Assignments").Elements(Ns + "Assignment").ToArray();
        Exige(jueves.Length == 2 && Valor(jueves[0], "FromTime") == "08:00:00" && Valor(jueves[0], "ToTime") == "12:00:00" &&
            Valor(jueves[1], "FromTime") == "13:00:00" && Valor(jueves[1], "ToTime") == "17:00:00" &&
            Valor(sabado, "FromTime") == "09:00:00" && Valor(sabado, "ToTime") == "13:00:00" && Valor(xml.Root, "MinutesPerWeek") == "2640" &&
            Valor(guardia, "DayWorking") == "1" && Valor(guardia.Element(Ns + "WorkingTimes").Element(Ns + "WorkingTime"), "FromTime") == "10:00:00" &&
            Valor(rango, "DayWorking") == "1" && Valor(rango.Element(Ns + "TimePeriod"), "ToDate") == "2026-12-29T23:59:59" &&
            Valor(cierre, "DayWorking") == "0" && Valor(cierre.Element(Ns + "TimePeriod"), "ToDate") == "2026-12-27T23:59:59" &&
            dias.Any(e => Valor(e, "DayType") == "0" && Valor(e, "DayWorking") == "0" && Valor(e.Element(Ns + "TimePeriod"), "FromDate") == "2027-12-25T00:00:00") &&
            XmlConvert.ToTimeSpan(Valor(a, "Duration")) == TimeSpan.FromHours(24) && XmlConvert.ToTimeSpan(Valor(a.Element(Ns + "Baseline"), "Duration")) == TimeSpan.FromHours(24) &&
            Valor(a, "Finish") == "2026-12-30T17:00:00" && XmlConvert.ToTimeSpan(Valor(b, "Duration")) == TimeSpan.FromHours(12) && Valor(b, "Finish") == "2027-01-02T13:00:00" &&
            Math.Abs(decimal.Parse(Valor(asignaciones.Single(e => Valor(e, "TaskUID") == Valor(a, "UID")), "Units"), CultureInfo.InvariantCulture) - 8m / 24m) < 0.000001m &&
            Firma(d) == dAntes && Firma(plan) == pAntes,
            "XML no preservó turnos partidos, sábado, guardia sobre feriado anual, excepciones por rango o duración/asignación con horas variables.");
        pasa("XML conserva 08–12/13–17, sábados y excepciones laborales por rango; la guardia específica prevalece sobre feriados anuales y las duraciones/asignaciones suman horas reales");
    }

    private static void ComprobarRecurrencias(string carpeta, Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Recurrencias Project QA");
        var calendario = new MYGCalendarioTrabajo { Nombre = "Semanas, meses y vigencias" };
        foreach (var dia in new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday })
            calendario.HorariosSemanales.Add(new() { Dia = dia, Tramos = new()
                { new() { InicioMinuto = 480, FinMinuto = 720 }, new() { InicioMinuto = 780, FinMinuto = 1020 } } });
        calendario.Feriados.Add(new(2026, 10, 17));
        calendario.FeriadosAnuales.Add(new() { Mes = 1, Dia = 1 });
        calendario.Excepciones.AddRange(new MYGExcepcionCalendario[]
        {
            new() { Tipo = MYGTipoExcepcionCalendario.DiaSemana, DiaSemana = DayOfWeek.Saturday, Laborable = true,
                Tramos = new() { new() { InicioMinuto = 540, FinMinuto = 660 } } },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaMes, Dia = 15 },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes, DiaSemana = DayOfWeek.Monday,
                NumeroSemana = 4, Laborable = true, Tramos = new() { new() { InicioMinuto = 600, FinMinuto = 780 } } },
            // Tipo explícito debe funcionar aunque el indicador Anual heredado sea false.
            new() { Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio, Mes = 2, Dia = 29 },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio, Mes = 11, DiaSemana = DayOfWeek.Thursday,
                NumeroSemana = 4, Inicio = new(2026, 1, 1), Fin = new(2027, 12, 31) },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio, Anual = true, Mes = 10, Dia = 20,
                Inicio = new(2026, 1, 1), Fin = new(2026, 12, 31), Laborable = true,
                Tramos = new() { new() { InicioMinuto = 600, FinMinuto = 660 } } },
            new() { Tipo = MYGTipoExcepcionCalendario.FechaORango, Inicio = new(2026, 10, 15), Fin = new(2026, 10, 15),
                Laborable = true, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } },
            new() { Anual = true, Mes = 12, Dia = 25 }
        });
        var plan = new MYGCronograma
        {
            Calendario = calendario, FechaInicio = new(2026, 10, 14), FechaEstado = new(2028, 11, 30),
            Tareas = new() { new() { Id = "R", Nombre = "Tarea recurrente", DuracionDias = 120,
                InicioBase = new(2024, 2, 27), FinBase = new(2024, 3, 1), DuracionBase = 4 } }
        };
        string antes = Firma(plan), documentoAntes = Firma(proyecto);
        var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        string ruta = Path.Combine(carpeta, "Cronograma recurrencias.xml");
        MYGExportacionCronograma.Guardar(ruta, proyecto, plan, MYGFormatoExportacionCronograma.XmlTareas);
        var xml = XDocument.Load(ruta);
        var excepcionesXml = xml.Root.Element(Ns + "Calendars").Element(Ns + "Calendar")
            .Element(Ns + "WeekDays").Elements(Ns + "WeekDay").Where(e => Valor(e, "DayType") == "0").ToArray();
        Exige(excepcionesXml.Length == modelo.Calendario.Excepciones.Count && modelo.Calendario.Excepciones.Count > 0,
            "XML y modelo Project no expandieron las mismas recurrencias.");
        for (int i = 0; i < excepcionesXml.Length; i++)
        {
            var e = excepcionesXml[i]; var esperado = modelo.Calendario.Excepciones[i];
            var periodo = e.Element(Ns + "TimePeriod");
            var tramos = e.Element(Ns + "WorkingTimes")?.Elements(Ns + "WorkingTime").Select(t =>
                new MYGTramoExportacionProject((int)TimeSpan.Parse(Valor(t, "FromTime"), CultureInfo.InvariantCulture).TotalMinutes,
                    (int)TimeSpan.Parse(Valor(t, "ToTime"), CultureInfo.InvariantCulture).TotalMinutes)).ToArray()
                ?? Array.Empty<MYGTramoExportacionProject>();
            Exige(DateTime.Parse(Valor(periodo, "FromDate"), CultureInfo.InvariantCulture).Date == esperado.Inicio &&
                DateTime.Parse(Valor(periodo, "ToDate"), CultureInfo.InvariantCulture).Date == esperado.Fin &&
                tramos.SequenceEqual(esperado.Tramos) && Valor(e, "DayWorking") == (tramos.Length > 0 ? "1" : "0"),
                "XML perdió fechas, tramos o condición laboral de una recurrencia.");
        }
        var orden = modelo.Calendario.Excepciones.OrderBy(e => e.Inicio).ToArray();
        Exige(orden.All(e => e.Inicio.Year >= 2024 && e.Fin.Year <= 2028) &&
            orden.Zip(orden.Skip(1)).All(par => par.First.Fin < par.Second.Inicio),
            "La expansión recurrente creó solapamientos o fechas fuera del horizonte y línea base exportados.");
        decimal HorasExportadas(DateTime fecha)
        {
            var e = orden.SingleOrDefault(e => fecha >= e.Inicio && fecha <= e.Fin);
            var horario = e?.Tramos ?? modelo.Calendario.Dias.Single(d => d.Dia == fecha.DayOfWeek).Tramos;
            return horario.Sum(t => t.FinMinuto - t.InicioMinuto) / 60m;
        }
        for (var fecha = new DateTime(2024, 1, 1); fecha < new DateTime(2029, 1, 1); fecha = fecha.AddDays(1))
            Exige(HorasExportadas(fecha) == calendario.HorasDelDia(fecha),
                "El calendario Project difiere de MYG el " + fecha.ToString("yyyy-MM-dd"));
        Exige(HorasExportadas(new(2026, 10, 15)) == 4 && HorasExportadas(new(2026, 10, 17)) == 2 &&
            HorasExportadas(new(2026, 10, 20)) == 1 && HorasExportadas(new(2027, 10, 20)) == 8 &&
            HorasExportadas(new(2026, 10, 26)) == 3 && HorasExportadas(new(2026, 11, 26)) == 0 &&
            HorasExportadas(new(2028, 11, 30)) == 8 && HorasExportadas(new(2024, 2, 29)) == 0,
            "Project ignoró prioridad específica, vigencia, cuarta semana, año bisiesto o regla explícita sobre feriado.");
        var tarea = modelo.Tareas.Single();
        decimal horas = 0;
        for (var fecha = tarea.Inicio.Date; fecha <= tarea.Fin.Date; fecha = fecha.AddDays(1)) horas += calendario.HorasDelDia(fecha);
        var tareaXml = Tarea(xml, "Tarea recurrente");
        Exige(tarea.DuracionMinutos == horas * 60 && tarea.DuracionBaseMinutos == 24 * 60 &&
            XmlConvert.ToTimeSpan(Valor(tareaXml, "Duration")) == TimeSpan.FromHours((double)horas) &&
            XmlConvert.ToTimeSpan(Valor(tareaXml.Element(Ns + "Baseline"), "Duration")) == TimeSpan.FromHours(24) &&
            Firma(plan) == antes && Firma(proyecto) == documentoAntes,
            "Recurrencias alteraron duración real, línea base o documentos al preparar XML/Project.");
        pasa("XML y Project expanden cinco recurrencias y rangos en el horizonte del plan/línea base, sin solapamientos, con prioridades, vigencias y minutos reales");

        var anualExplicito = new MYGCronograma { FechaInicio = new(2026, 12, 24), FechaEstado = new(2026, 12, 31),
            Calendario = new() { Excepciones = new() { new() { Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio, Mes = 12, Dia = 25 } } },
            Tareas = new() { new() { Id = "A", Nombre = "Anual explícito", DuracionDias = 2 } } };
        var modeloAnual = MYGExportacionCronograma.PrepararProject(proyecto, anualExplicito, false);
        string rutaAnual = Path.Combine(carpeta, "Cronograma anual explícito.xml");
        MYGExportacionCronograma.Guardar(rutaAnual, proyecto, anualExplicito, MYGFormatoExportacionCronograma.XmlTareas);
        Exige(modeloAnual.Tareas.Single().Fin.Date == new DateTime(2026, 12, 28) &&
            modeloAnual.Tareas.Single().DuracionMinutos == 960 && modeloAnual.Calendario.Excepciones.Single().Tramos.Count == 0 &&
            XmlConvert.ToTimeSpan(Valor(Tarea(XDocument.Load(rutaAnual), "Anual explícito"), "Duration")) == TimeSpan.FromHours(16),
            "La ruta anual heredada interpretó Tipo explícito como un rango por Anual=false.");
        pasa("Exportación anual conserva la ruta heredada y reconoce Tipo explícito aunque Anual no esté informado");
    }

    private static void ComprobarRechazos(MYGProyectoDocumento proyecto, MYGCronograma plan, string carpeta)
    {
        string ruta = Path.Combine(carpeta, "Cronograma conservar.xml");
        const string existente = "ARCHIVO EXISTENTE"; File.WriteAllText(ruta, existente);
        void Rechaza(MYGProyectoDocumento d, MYGCronograma p)
        {
            string dAntes = Firma(d), pAntes = Firma(p); bool rechazo = false;
            try { MYGExportacionCronograma.Guardar(ruta, d, p, MYGFormatoExportacionCronograma.XmlTareasRecursos); }
            catch (InvalidDataException) { rechazo = true; }
            Exige(rechazo && File.ReadAllText(ruta) == existente && Firma(d) == dAntes && Firma(p) == pAntes && !Directory.GetFiles(carpeta, "Cronograma conservar.xml.*.tmp").Any(),
                "La exportación aceptó datos incoherentes o dañó el destino existente/documento al fallar.");
        }
        var ciclo = MYGProyectoStorage.Copia(plan);
        ciclo.Tareas.Single(t => t.Id == "A").Predecesoras.Add(new() { PredecesoraId = "B" }); Rechaza(proyecto, ciclo);
        var roto = MYGProyectoStorage.Copia(plan); roto.Tareas.Single(t => t.Id == "A").PartidaId = "INEXISTENTE"; Rechaza(proyecto, roto);
        var duplicado = MYGProyectoStorage.Copia(plan);
        duplicado.Tareas.Add(new() { Id = "DUP", Nombre = "DUP", PresupuestoId = proyecto.Presupuestos[0].Id, PartidaId = "PARTIDA" });
        Rechaza(proyecto, duplicado);
        var monedas = MYGProyectoStorage.Copia(proyecto); monedas.Presupuestos[1].Costos.Moneda = "USD"; Rechaza(monedas, plan);
    }

    private static MYGProyectoDocumento Datos(out MYGCronograma plan)
    {
        var d = MYGProyectoStorage.Nuevo("Obra XML <QA> & Perú"); var p = d.Presupuestos.Single();
        var material = new MYGInsumo { Id = "ARENA", Codigo = "0007", Descripcion = "Arena & grava", Unidad = "m3", Precio = 10, Proveedor = "PROVEEDOR A" };
        var trabajo = new MYGInsumo { Id = "OPERARIO", Codigo = "0008", Descripcion = "Operario QA", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 20 };
        var porcentaje = new MYGInsumo { Id = "HERRAMIENTAS", Codigo = "0009", Descripcion = "Herramientas QA", Unidad = "%mo", Grupo = MYGGrupoRecurso.Equipo };
        p.Costos.Insumos.AddRange(new[] { material, trabajo, porcentaje, new MYGInsumo { Id = "SINUSO", Codigo = "99", Descripcion = "No utilizado", Precio = 123 } });
        ItemPresupuestoDelphin Partida(MYGPresupuestoDocumento presupuesto, string id, decimal cantidad)
        {
            var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, Descripcion = id, TipoPropuesta = "PARTIDA", Unidad = "und" };
            i.Costos.Cantidad = cantidad; presupuesto.Items.Add(i); return i;
        }
        var partida = Partida(p, "PARTIDA", 2); var sub = Partida(p, "SUB", 0); var directa = Partida(p, "DIRECTA", 1); directa.Costos.PrecioDirecto = 45;
        sub.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 });
        partida.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 3 });
        partida.Costos.Analisis.Add(new() { InsumoId = trabajo.Id, Grupo = MYGGrupoRecurso.ManoObra, Cantidad = 4 });
        partida.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = .5m });
        partida.Costos.Analisis.Add(new() { InsumoId = porcentaje.Id, Grupo = MYGGrupoRecurso.Equipo, Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 5 });
        var p2 = new MYGPresupuestoDocumento { Id = "P2", Nombre = "Proveedor B", Item = "02" }; d.Presupuestos.Add(p2);
        var otroMaterial = MYGProyectoStorage.Copia(material); otroMaterial.Id = "ARENA2"; otroMaterial.Descripcion = "Arena proveedor B"; otroMaterial.Proveedor = "PROVEEDOR B";
        p2.Costos.Insumos.Add(otroMaterial); var otra = Partida(p2, "OTRA", 1);
        otra.Costos.Analisis.Add(new() { InsumoId = otroMaterial.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 1 });
        plan = new MYGCronograma
        {
            FechaInicio = new DateTime(2026, 1, 30), FechaEstado = new DateTime(2026, 2, 4),
            Calendario = new() { HorasPorDia = 6.5m, Feriados = new() { new DateTime(2026, 2, 2), new DateTime(2026, 2, 2) },
                FeriadosAnuales = new() { new() { Mes = 2, Dia = 3 } } },
            Tareas = new()
            {
                new() { Id = "R", Nombre = "Resumen", EsResumen = true },
                new() { Id = "A", PadreId = "R", Codigo = "0001", Nombre = "=Excavación <QA> & \"obra\"", DuracionDias = 3, Avance = 37.5m,
                    PresupuestoId = p.Id, PartidaId = partida.Id, Notas = " @NOTA literal\tsegunda\nlínea" },
                new() { Id = "B", PadreId = "R", Nombre = "Fin comienzo", DuracionDias = 2, PresupuestoId = p.Id, PartidaId = directa.Id,
                    Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.FC, DesfaseDias = 2 } } },
                new() { Id = "C", PadreId = "R", Nombre = "Comienzo comienzo", Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.CC, DesfaseDias = -1 } } },
                new() { Id = "D", PadreId = "R", Nombre = "Fin fin", PresupuestoId = p2.Id, PartidaId = otra.Id,
                    Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.FF, DesfaseDias = 1 } } },
                new() { Id = "E", PadreId = "R", Nombre = "Manual importada", Modo = MYGModoTarea.Manual, InicioManual = new DateTime(2026, 2, 1), DuracionDias = 2, Avance = 25,
                    FechasImportadasDelphin = new() { Inicio = new DateTime(2026, 2, 1), Fin = new DateTime(2026, 2, 7), DuracionDias = 2 },
                    InicioBase = new DateTime(2025, 12, 30), FinBase = new DateTime(2026, 1, 2), DuracionBase = 3,
                    Predecesoras = new() { new() { PredecesoraId = "D", Tipo = MYGTipoVinculo.CF, DesfaseDias = -1 } } },
                new() { Id = "H", Nombre = "Hito", DuracionDias = 0 }
            }
        };
        return d;
    }
}
