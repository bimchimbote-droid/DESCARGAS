using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class CalendarioTrabajoDetalladoCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Calendario detallado: " + detalle); }
    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new Exception("Calendario detallado aceptó " + detalle);
    }
    private static MYGTramoHorario Tramo(int inicio, int fin) => new() { InicioMinuto = inicio, FinMinuto = fin };
    private static MYGHorarioDiaTrabajo Dia(DayOfWeek dia, params MYGTramoHorario[] tramos) =>
        new() { Dia = dia, Tramos = tramos.ToList() };
    private static MYGCalendarioTrabajo Ejemplo() => new()
    {
        Nombre = "Jornadas de obra",
        HorariosSemanales = new()
        {
            Dia(DayOfWeek.Monday, Tramo(480, 720), Tramo(780, 1020)),
            Dia(DayOfWeek.Tuesday, Tramo(420, 660)),
            Dia(DayOfWeek.Thursday, Tramo(480, 720)),
            Dia(DayOfWeek.Friday, Tramo(480, 720))
        },
        Excepciones = new()
        {
            new() { Nombre = "Día del Trabajo", Anual = true, Mes = 5, Dia = 1, Color = "#FFDD88" },
            new() { Nombre = "Navidad", Anual = true, Mes = 12, Dia = 25, Color = "#FFD6D6" },
            new() { Nombre = "Sábado de recuperación", Inicio = new(2026, 12, 26), Fin = new(2026, 12, 26),
                Laborable = true, Tramos = new() { Tramo(540, 780) }, Color = "#CCEECC" },
            new() { Nombre = "Cierre de obra", Inicio = new(2026, 12, 27), Fin = new(2026, 12, 28) }
        }
    };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Horarios(pasa);
        ExcepcionesYOrdinales(pasa);
        Recurrencias(pasa);
        RecurrenciasYOrdinales(pasa);
        Validacion(pasa);
        ValidacionRecurrencias(pasa);
        Persistencia(carpeta, pasa);
    }

    private static void Horarios(Action<string> pasa)
    {
        var legado = new MYGCalendarioTrabajo();
        Exige(legado.Nombre == "Predeterminado" && legado.HorariosSemanales.Count == 0 && legado.Excepciones.Count == 0,
            "los valores iniciales no conservan el calendario heredado");
        Exige(legado.HorasDelDia(new(2026, 10, 5)) == 8 && !legado.EsLaborable(new(2026, 10, 10)),
            "el calendario heredado perdió su jornada o el sábado inhábil");
        var c = Ejemplo(); c.Validar();
        string antes = JsonSerializer.Serialize(c);
        Exige(c.HorasDelDia(new(2026, 10, 5)) == 8 && c.HorasDelDia(new(2026, 10, 6)) == 4 &&
            c.HorasDelDia(new(2026, 10, 7)) == 0 && c.HorasDelDia(new(2026, 10, 8)) == 4,
            "no se respetan turnos partidos, duraciones variables o días semanales ausentes");
        Exige(c.ObtenerHorario(new(2026, 10, 5)).Select(t => (t.InicioMinuto, t.FinMinuto))
            .SequenceEqual(new[] { (480, 720), (780, 1020) }) && JsonSerializer.Serialize(c) == antes,
            "consultar un horario cambió los turnos o el modelo original");
        pasa("Calendario conserva compatibilidad L–V/8 h y admite semanas con turnos partidos, horas variables y días inhábiles");
    }

    private static void ExcepcionesYOrdinales(Action<string> pasa)
    {
        var c = Ejemplo();
        Exige(!c.EsLaborable(new(2026, 5, 1)) && !c.EsLaborable(new(2026, 12, 25)) &&
            !c.EsLaborable(new(2027, 12, 25)), "los feriados anuales no se repiten en años distintos");
        Exige(c.HorasDelDia(new(2026, 12, 26)) == 4 && !c.EsLaborable(new(2026, 12, 28)),
            "no aplica el sábado laborable ni el cierre fechado inclusivo");
        Exige(c.SumarDiasLaborables(new(2026, 12, 24), 1) == new DateTime(2026, 12, 26) &&
            c.SumarDiasLaborables(new(2026, 12, 24), 2) == new DateTime(2026, 12, 29) &&
            c.SumarDiasLaborables(new(2026, 12, 29), -1) == new DateTime(2026, 12, 26) &&
            c.ContarDiasLaborables(new(2026, 12, 24), new(2026, 12, 30)) == 3,
            "los ordinales no consideran las excepciones al avanzar, retroceder o contar");
        c.Excepciones.Add(new() { Nombre = "Guardia de Navidad", Inicio = new(2026, 12, 25), Fin = new(2026, 12, 25),
            Laborable = true, Tramos = new() { Tramo(600, 720) } });
        c.Feriados.Add(new(2026, 12, 25));
        c.Excepciones.Add(new() { Nombre = "Día bisiesto", Anual = true, Mes = 2, Dia = 29 });
        c.Excepciones.Add(new() { Nombre = "Guardia anual", Anual = true, Mes = 1, Dia = 1, Laborable = true });
        c.Feriados.Add(new(2028, 1, 1));
        c.Validar();
        Exige(c.HorasDelDia(new(2026, 12, 25)) == 2 && !c.EsLaborable(new(2024, 2, 29)) &&
            c.HorasDelDia(new(2028, 1, 1)) == 8,
            "las guardias explícitas no prevalecen sobre feriados/fin de semana o no se admite 29 de febrero");
        var inicio = new DateTime(2024, 1, 1); var fin = new DateTime(2028, 1, 1);
        int esperado = 0;
        for (var fecha = inicio; fecha <= fin; fecha = fecha.AddDays(1)) if (c.EsLaborable(fecha)) esperado++;
        Exige(c.ContarDiasLaborables(inicio, fin) == esperado,
            "el conteo indexado difiere del horario diario al combinar reglas anuales, rangos y guardias");
        var plan = new MYGCronograma { Calendario = c, FechaInicio = new(2026, 12, 24),
            Tareas = new() { new() { Nombre = "Cuatro jornadas", DuracionDias = 4 } } };
        var fila = MYGMotorCronograma.Calcular(plan).Filas.Single();
        Exige(fila.Inicio == new DateTime(2026, 12, 24) && fila.Fin == new DateTime(2026, 12, 29),
            "el motor del Gantt no consume las mismas excepciones que el calendario");
        pasa("Feriados anuales, año bisiesto, cierres inclusivos y guardias específicas se aplican también al cálculo del Gantt y sus ordinales");

        // Un cierre de casi 10 000 años debe manejarse como intervalo, sin expandir sus días.
        var extenso = new MYGCalendarioTrabajo
        {
            DiasLaborables = Enum.GetValues<DayOfWeek>().ToList(),
            Excepciones = new() { new() { Nombre = "Cierre extenso", Inicio = DateTime.MinValue,
                Fin = new(9999, 12, 30) } }
        };
        Exige(extenso.ContarDiasLaborables(DateTime.MinValue, DateTime.MaxValue) == 1 &&
            extenso.SiguienteLaborable(DateTime.MinValue) == new DateTime(9999, 12, 31),
            "un intervalo extenso perdió su límite o la búsqueda ordinal");
        Rechaza(() => extenso.SumarDiasLaborables(DateTime.MinValue, int.MaxValue), "un desfase fuera del rango DateTime");
        pasa("Intervalos de casi 10 000 años usan conteo ordinal y rechazan desfases fuera de rango sin recorrer sus días");
    }

    private static void Recurrencias(Action<string> pasa)
    {
        var rango = new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.FechaORango,
            Inicio = new(2026, 4, 8), Fin = new(2026, 4, 10) };
        Exige(rango.Contiene(new(2026, 4, 8, 23, 0, 0)) && rango.Contiene(new(2026, 4, 10)) &&
            !rango.Contiene(new(2026, 4, 7)) && !rango.Contiene(new(2026, 4, 11)) &&
            rango.ProximaFecha(new(2026, 4, 1)) == new DateTime(2026, 4, 8) &&
            rango.ProximaFecha(new(2026, 4, 9, 18, 0, 0)) == new DateTime(2026, 4, 9) &&
            rango.ProximaFecha(new(2026, 4, 11)) == null,
            "el intervalo no conserva extremos inclusivos ni normaliza la fecha de consulta");

        var semanal = new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaSemana,
            DiaSemana = DayOfWeek.Monday, Inicio = new(2026, 1, 5), Fin = new(2026, 1, 19) };
        Exige(semanal.Contiene(new(2026, 1, 5)) && semanal.Contiene(new(2026, 1, 19)) &&
            !semanal.Contiene(new(2026, 1, 4)) && !semanal.Contiene(new(2026, 1, 6)) &&
            !semanal.Contiene(new(2026, 1, 26)) &&
            semanal.ProximaFecha(new(2026, 1, 1)) == new DateTime(2026, 1, 5) &&
            semanal.ProximaFecha(new(2026, 1, 18)) == new DateTime(2026, 1, 19) &&
            semanal.ProximaFecha(new(2026, 1, 20)) == null,
            "la repetición por día semanal o sus límites de vigencia no son inclusivos");
        semanal.Inicio = null;
        Exige(semanal.ProximaFecha(new(2025, 12, 29)) == new DateTime(2025, 12, 29),
            "una recurrencia sin inicio perdió su primera coincidencia disponible");
        semanal.Inicio = new(2026, 1, 5); semanal.Fin = null;
        Exige(semanal.ProximaFecha(new(2026, 1, 20)) == new DateTime(2026, 1, 26),
            "una recurrencia sin fin no continúa después de su inicio");

        var mensual = new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaMes, Dia = 31 };
        Exige(mensual.Contiene(new(2026, 3, 31)) && !mensual.Contiene(new(2026, 4, 30)) &&
            mensual.ProximaFecha(new(2026, 4, 1)) == new DateTime(2026, 5, 31) &&
            mensual.ProximaFecha(new(2026, 12, 31, 12, 0, 0)) == new DateTime(2026, 12, 31) &&
            mensual.ProximaFecha(new(2027, 2, 1)) == new DateTime(2027, 3, 31),
            "el día 31 debe omitir meses cortos y respetar el cambio de año");
        mensual.Fin = new(2026, 4, 30);
        Exige(mensual.ProximaFecha(new(2026, 4, 1)) == null,
            "la búsqueda mensual pasó el límite sin encontrar una fecha válida");

        var cuarto = new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes,
            DiaSemana = DayOfWeek.Monday, NumeroSemana = 4 };
        Exige(cuarto.Contiene(new(2026, 3, 23)) && !cuarto.Contiene(new(2026, 3, 30)) &&
            cuarto.Contiene(new(2026, 2, 23)) &&
            cuarto.ProximaFecha(new(2026, 3, 24)) == new DateTime(2026, 4, 27),
            "la cuarta semana debe conservar su ordinal tanto en meses con cuatro como con cinco coincidencias");
        for (int numero = 1; numero <= 4; numero++)
        {
            var ordinal = new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes,
                DiaSemana = DayOfWeek.Monday, NumeroSemana = numero };
            var fecha = new DateTime(2026, 3, 2).AddDays(7 * (numero - 1));
            Exige(ordinal.Contiene(fecha) && ordinal.ProximaFecha(new(2026, 3, 1)) == fecha &&
                !ordinal.Contiene(fecha.AddDays(7)), "se perdió el ordinal mensual " + numero);
        }

        var bisiesto = new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio,
            Mes = 2, Dia = 29 };
        Exige(bisiesto.Contiene(new(2028, 2, 29)) && !bisiesto.Contiene(new(2027, 2, 28)) &&
            bisiesto.ProximaFecha(new(2025, 3, 1)) == new DateTime(2028, 2, 29) &&
            bisiesto.ProximaFecha(new(2097, 1, 1)) == new DateTime(2104, 2, 29),
            "la fecha anual 29 de febrero no respeta años comunes o la excepción secular de 2100");
        bisiesto.Fin = new(2027, 12, 31);
        Exige(bisiesto.ProximaFecha(new(2025, 1, 1)) == null,
            "la fecha bisiesta excedió la vigencia para obtener una coincidencia");

        var anualSemanal = new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio,
            Mes = 5, DiaSemana = DayOfWeek.Monday, NumeroSemana = 4 };
        Exige(anualSemanal.Contiene(new(2026, 5, 25)) && anualSemanal.Contiene(new(2027, 5, 24)) &&
            !anualSemanal.Contiene(new(2027, 5, 31)) && !anualSemanal.Contiene(new(2026, 6, 22)) &&
            anualSemanal.ProximaFecha(new(2026, 5, 26)) == new DateTime(2027, 5, 24),
            "la cuarta semana de un mes anual no respeta su ordinal, mes o salto de año");

        var legado = JsonSerializer.Deserialize<MYGExcepcionCalendario>("{\"Anual\":true,\"Mes\":12,\"Dia\":25}");
        Exige(legado.Tipo == null && legado.TipoEfectivo == MYGTipoExcepcionCalendario.DiaMesDelAnio &&
            legado.Contiene(new(2027, 12, 25)), "una excepción anual antigua perdió su recurrencia al deserializar");
        string jsonLegado = JsonSerializer.Serialize(legado);
        Exige(!jsonLegado.Contains("\"Tipo\":") && !jsonLegado.Contains("\"DiaSemana\":") &&
            !jsonLegado.Contains("\"NumeroSemana\":") && !jsonLegado.Contains("\"TipoEfectivo\":"),
            "los campos nuevos sin usar alteran el JSON de excepciones antiguas");
        legado.Tipo = MYGTipoExcepcionCalendario.DiaSemana; legado.DiaSemana = DayOfWeek.Monday;
        Exige(legado.TipoEfectivo == MYGTipoExcepcionCalendario.DiaSemana && legado.Contiene(new(2026, 10, 5)) &&
            !legado.Contiene(new(2026, 12, 25)) && !JsonSerializer.Serialize(legado).Contains("TipoEfectivo"),
            "el tipo explícito no prevalece sobre Anual o el tipo calculado se persistió en JSON");
        Exige(new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaSemana,
            DiaSemana = DayOfWeek.Monday }.ProximaFecha(DateTime.MaxValue) == null &&
            new MYGExcepcionCalendario { Tipo = MYGTipoExcepcionCalendario.DiaMes,
                Dia = 31 }.ProximaFecha(DateTime.MaxValue) == DateTime.MaxValue.Date,
            "buscar la próxima fecha cerca del año 9999 desbordó o perdió el último día válido");
        pasa("Las seis opciones de excepción buscan fechas inclusivas, respetan vigencias, meses cortos, primera a cuarta semana y años bisiestos");
    }

    private static void RecurrenciasYOrdinales(Action<string> pasa)
    {
        var inicio = new DateTime(2026, 1, 1); var fin = new DateTime(2026, 12, 31);
        var c = new MYGCalendarioTrabajo
        {
            Feriados = new() { new(2026, 5, 1), new(2026, 12, 26) },
            Excepciones = new()
            {
                new() { Nombre = "Sábados de recuperación", Tipo = MYGTipoExcepcionCalendario.DiaSemana,
                    DiaSemana = DayOfWeek.Saturday, Inicio = inicio, Fin = fin, Laborable = true,
                    Tramos = new() { Tramo(360, 600) } },
                new() { Nombre = "Cierre mensual", Tipo = MYGTipoExcepcionCalendario.DiaMes,
                    Dia = 15, Inicio = inicio, Fin = fin },
                new() { Nombre = "Cuarto lunes", Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes,
                    DiaSemana = DayOfWeek.Monday, NumeroSemana = 4, Inicio = inicio, Fin = fin },
                new() { Nombre = "Día del Trabajo", Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio,
                    Mes = 5, Dia = 1, Inicio = inicio, Fin = fin },
                new() { Nombre = "Cuarto jueves de noviembre", Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio,
                    Mes = 11, DiaSemana = DayOfWeek.Thursday, NumeroSemana = 4, Inicio = inicio, Fin = fin },
                new() { Nombre = "Guardia específica", Tipo = MYGTipoExcepcionCalendario.FechaORango,
                    Inicio = new(2026, 5, 1), Fin = new(2026, 5, 1), Laborable = true,
                    Tramos = new() { Tramo(600, 720) } },
                new() { Nombre = "Cierre específico", Tipo = MYGTipoExcepcionCalendario.FechaORango,
                    Inicio = new(2026, 10, 10), Fin = new(2026, 10, 12) }
            }
        };
        c.Validar();
        Exige(c.HorasDelDia(new(2026, 5, 1)) == 2 && c.HorasDelDia(new(2026, 12, 26)) == 4 &&
            c.HorasDelDia(new(2026, 8, 15)) == 4 && !c.EsLaborable(new(2026, 10, 10)) &&
            !c.EsLaborable(new(2026, 11, 26)) && !c.EsLaborable(new(2026, 11, 23)) &&
            c.EsLaborable(new(2026, 11, 30)) &&
            !c.EsLaborable(new(2027, 1, 2)),
            "rangos específicos, prioridad entre recurrencias, feriados o vigencias difieren del horario diario");

        var laborables = Enumerable.Range(0, (fin - inicio).Days + 1).Select(d => inicio.AddDays(d))
            .Where(c.EsLaborable).ToArray();
        Exige(c.ContarDiasLaborables(inicio, fin) == laborables.Length &&
            c.ContarDiasLaborables(fin, inicio) == 0,
            "el conteo ordinal con recurrencias difiere de la consulta diaria o admite intervalos invertidos");
        var origen = new DateTime(2026, 11, 20);
        int indice = Array.IndexOf(laborables, origen);
        foreach (int desfase in new[] { -12, -1, 0, 1, 7, 12 })
            Exige(c.SumarDiasLaborables(origen, desfase) == laborables[indice + desfase],
                "el desfase ordinal " + desfase + " difiere de los horarios recurrentes diarios");
        Exige(c.SiguienteLaborable(new(2026, 10, 10)) == new DateTime(2026, 10, 13) &&
            c.ContarDiasLaborables(new(2026, 11, 20), new(2026, 12, 1)) == 8,
            "el conteo o avance no aplica el cierre específico y las reglas semanales/mensuales/anuales");
        var plan = new MYGCronograma { Calendario = c, FechaInicio = origen,
            Tareas = new() { new() { Nombre = "Ocho jornadas recurrentes", DuracionDias = 8 } } };
        var fila = MYGMotorCronograma.Calcular(plan).Filas.Single();
        Exige(fila.Inicio == origen && fila.Fin == new DateTime(2026, 12, 1),
            "el Gantt no usa las mismas reglas recurrentes que el horario y el conteo ordinal");
        var periodico = new MYGCalendarioTrabajo { Excepciones = new()
        {
            new() { Tipo = MYGTipoExcepcionCalendario.DiaSemana, DiaSemana = DayOfWeek.Sunday, Laborable = true },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaMes, Dia = 31 },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes, DiaSemana = DayOfWeek.Monday, NumeroSemana = 4 },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio, Mes = 2, Dia = 29 },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio, Mes = 12,
                DiaSemana = DayOfWeek.Friday, NumeroSemana = 4 },
            new() { Tipo = MYGTipoExcepcionCalendario.FechaORango, Inicio = new(2399, 12, 30), Fin = new(2400, 1, 2) }
        } };
        foreach (var ventana in new[]
        {
            (Inicio: new DateTime(2099, 12, 20), Fin: new DateTime(2100, 3, 7)),
            (Inicio: new DateTime(2399, 12, 20), Fin: new DateTime(2400, 3, 7)),
            (Inicio: new DateTime(9999, 12, 1), Fin: new DateTime(9999, 12, 31))
        })
        {
            var diario = Enumerable.Range(0, (ventana.Fin - ventana.Inicio).Days + 1)
                .Select(d => ventana.Inicio.AddDays(d)).Where(periodico.EsLaborable).ToArray();
            Exige(periodico.ContarDiasLaborables(ventana.Inicio, ventana.Fin) == diario.Length &&
                periodico.SumarDiasLaborables(diario[0], diario.Length - 1) == diario[^1] &&
                periodico.SumarDiasLaborables(diario[^1], 1 - diario.Length) == diario[0],
                "el patrón ordinal de 400 años difiere del horario diario alrededor del año " + ventana.Fin.Year);
        }
        pasa("Reglas recurrentes conservan prioridad, turnos, vigencia y coherencia entre horario diario, avance, retroceso, conteo y Gantt");
    }

    private static void Validacion(Action<string> pasa)
    {
        var c = Ejemplo();
        c.HorariosSemanales[0].Tramos.Add(Tramo(700, 800));
        Rechaza(c.Validar, "turnos semanales solapados");
        c = Ejemplo(); c.HorariosSemanales[0].Tramos[0].InicioMinuto = -1;
        Rechaza(c.Validar, "un minuto de inicio negativo");
        c = Ejemplo(); c.HorariosSemanales[0].Tramos[0].FinMinuto = 1441;
        Rechaza(c.Validar, "un minuto de fin posterior a las 24:00");
        c = Ejemplo(); c.HorariosSemanales.Add(Dia(DayOfWeek.Monday, Tramo(480, 720)));
        Rechaza(c.Validar, "un día semanal duplicado");
        c = Ejemplo(); c.Excepciones.Add(new() { Nombre = "Superposición", Inicio = new(2026, 12, 28), Fin = new(2026, 12, 29) });
        Rechaza(c.Validar, "excepciones fechadas superpuestas");
        c = Ejemplo(); c.Excepciones.Add(new() { Anual = true, Mes = 12, Dia = 25 });
        Rechaza(c.Validar, "dos excepciones anuales en la misma fecha");
        c = Ejemplo(); c.Excepciones.Add(new() { Anual = true, Mes = 2, Dia = 30 });
        Rechaza(c.Validar, "una fecha anual inexistente");
        c = Ejemplo(); c.Excepciones.Add(new() { Inicio = new(2026, 5, 2), Fin = new(2026, 5, 1) });
        Rechaza(c.Validar, "un rango invertido");
        c = Ejemplo(); c.Excepciones[2].Tramos.Add(Tramo(700, 800));
        Rechaza(c.Validar, "turnos de excepción solapados");
        pasa("Validación rechaza turnos solapados, minutos inválidos, días duplicados, fechas imposibles y excepciones ambiguas");
    }

    private static void ValidacionRecurrencias(Action<string> pasa)
    {
        void Invalida(MYGExcepcionCalendario excepcion, string detalle)
        {
            var c = new MYGCalendarioTrabajo { Excepciones = new() { excepcion } };
            Rechaza(c.Validar, detalle);
        }
        Invalida(new() { Tipo = (MYGTipoExcepcionCalendario)99 }, "un tipo de excepción desconocido");
        Invalida(new() { Tipo = MYGTipoExcepcionCalendario.FechaORango, Inicio = new(2026, 1, 1) },
            "un intervalo sin fecha final");
        Invalida(new() { Tipo = MYGTipoExcepcionCalendario.FechaORango, Fin = new(2026, 1, 1) },
            "un intervalo sin fecha inicial");
        Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaSemana, DiaSemana = (DayOfWeek)7 },
            "un día semanal fuera de rango");
        foreach (int dia in new[] { 0, 32 })
            Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaMes, Dia = dia }, "un día mensual " + dia);
        foreach (int numero in new[] { 0, 5, 6 })
        {
            Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes,
                DiaSemana = DayOfWeek.Friday, NumeroSemana = numero }, "un ordinal mensual " + numero);
            Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio,
                Mes = 4, DiaSemana = DayOfWeek.Friday, NumeroSemana = numero }, "un ordinal anual " + numero);
        }
        Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes,
            DiaSemana = (DayOfWeek)(-1), NumeroSemana = 1 }, "un día semanal mensual inválido");
        Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio,
            Mes = 4, DiaSemana = (DayOfWeek)7, NumeroSemana = 1 }, "un día semanal anual inválido");
        foreach (int mes in new[] { 0, 13 })
        {
            Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio, Mes = mes, Dia = 1 },
                "un mes de fecha anual " + mes);
            Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio,
                Mes = mes, DiaSemana = DayOfWeek.Friday, NumeroSemana = 1 }, "un mes de ordinal anual " + mes);
        }
        Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio, Mes = 2, Dia = 30 },
            "una fecha recurrente anual imposible");
        Invalida(new() { Tipo = MYGTipoExcepcionCalendario.DiaSemana,
            DiaSemana = DayOfWeek.Monday, Inicio = new(2026, 2, 1), Fin = new(2026, 1, 31) },
            "la vigencia invertida de una recurrencia");
        var duplicadas = new MYGCalendarioTrabajo { Excepciones = new()
        {
            new() { Tipo = MYGTipoExcepcionCalendario.DiaMes, Dia = 15,
                Inicio = new(2026, 1, 1), Fin = new(2026, 6, 30) },
            new() { Tipo = MYGTipoExcepcionCalendario.DiaMes, Dia = 15,
                Inicio = new(2026, 6, 30), Fin = new(2026, 12, 31) }
        } };
        Rechaza(duplicadas.Validar, "la misma recurrencia con vigencias superpuestas en el extremo");
        duplicadas.Excepciones[1].Inicio = new(2026, 7, 1);
        duplicadas.Validar();
        Exige(duplicadas.Excepciones[0].ProximaFecha(new(2026, 7, 1)) == null &&
            duplicadas.Excepciones[1].ProximaFecha(new(2026, 6, 1)) == new DateTime(2026, 7, 15),
            "las vigencias separadas de una misma regla no se mantienen independientes");
        pasa("Validación distingue los seis tipos, rechaza parámetros imposibles y recurrencias duplicadas, y permite vigencias separadas");
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("CALENDARIOS NOMBRADOS");
        documento.Cronograma = new() { Calendario = Ejemplo(), FechaInicio = new(2026, 12, 24),
            Tareas = new() { new() { Nombre = "Obra con turnos", DuracionDias = 3 } } };
        documento.Cronograma.Calendario.Excepciones.AddRange(new MYGExcepcionCalendario[]
        {
            new() { Nombre = "Sábado recurrente", Tipo = MYGTipoExcepcionCalendario.DiaSemana,
                DiaSemana = DayOfWeek.Saturday, Inicio = new(2027, 1, 1), Fin = new(2030, 12, 31),
                Laborable = true, Tramos = new() { Tramo(540, 660) }, Color = "#AABBCC" },
            new() { Nombre = "Día mensual", Tipo = MYGTipoExcepcionCalendario.DiaMes,
                Dia = 3, Inicio = new(2027, 1, 1), Fin = new(2030, 12, 31) },
            new() { Nombre = "Primer miércoles", Tipo = MYGTipoExcepcionCalendario.DiaSemanaDelMes,
                DiaSemana = DayOfWeek.Wednesday, NumeroSemana = 1, Inicio = new(2027, 1, 1), Fin = new(2030, 12, 31) },
            new() { Nombre = "Bisiesto explícito", Tipo = MYGTipoExcepcionCalendario.DiaMesDelAnio,
                Mes = 2, Dia = 29, Inicio = new(2027, 1, 1), Fin = new(2030, 12, 31) },
            new() { Nombre = "Cuarto viernes de septiembre", Tipo = MYGTipoExcepcionCalendario.DiaSemanaMesDelAnio,
                Mes = 9, DiaSemana = DayOfWeek.Friday, NumeroSemana = 4,
                Inicio = new(2027, 1, 1), Fin = new(2030, 12, 31) },
            new() { Nombre = "Rango explícito", Tipo = MYGTipoExcepcionCalendario.FechaORango,
                Inicio = new(2029, 7, 1), Fin = new(2029, 7, 2) }
        });
        var alternativo = MYGProyectoStorage.Copia(documento.Cronograma.Calendario);
        alternativo.Nombre = "Segundo calendario";
        alternativo.HorariosSemanales[0].Tramos = new() { Tramo(360, 720) };
        documento.Cronograma.Calendarios.Add(MYGProyectoStorage.Copia(documento.Cronograma.Calendario));
        documento.Cronograma.Calendarios.Add(alternativo);
        string esperado = JsonSerializer.Serialize(documento.Cronograma.Calendario);
        string listaEsperada = JsonSerializer.Serialize(documento.Cronograma.Calendarios);
        var copia = MYGProyectoStorage.Copia(documento);
        Exige(JsonSerializer.Serialize(copia.Cronograma.Calendario) == esperado &&
            JsonSerializer.Serialize(copia.Cronograma.Calendarios) == listaEsperada,
            "la copia JSON perdió nombre, horarios o excepciones");
        copia.Cronograma.Calendario.HorariosSemanales[0].Tramos[0].InicioMinuto = 500;
        copia.Cronograma.Calendario.Excepciones[0].Nombre = "CAMBIO EN COPIA";
        copia.Cronograma.Calendario.Excepciones[^6].DiaSemana = DayOfWeek.Sunday;
        copia.Cronograma.Calendario.Excepciones[^6].Tramos[0].InicioMinuto = 600;
        copia.Cronograma.Calendarios[1].Nombre = "CAMBIO EN SEGUNDO CALENDARIO";
        Exige(JsonSerializer.Serialize(documento.Cronograma.Calendario) == esperado &&
            JsonSerializer.Serialize(documento.Cronograma.Calendarios) == listaEsperada,
            "los tramos o excepciones comparten referencias después de copiar");
        // AgregarTarea utiliza la copia manual del motor, distinta de la copia JSON.
        MYGMotorCronograma.AgregarTarea(documento.Cronograma, null, "Nueva tarea");
        Exige(JsonSerializer.Serialize(documento.Cronograma.Calendario) == esperado &&
            JsonSerializer.Serialize(documento.Cronograma.Calendarios) == listaEsperada,
            "la edición mediante copia manual perdió los nuevos campos del calendario");
        foreach (string extension in new[] { ".sqlite", ".myg.json" })
        {
            string ruta = Path.Combine(carpeta, "Calendario detallado" + extension);
            MYGProyectoStorage.Guardar(ruta, documento);
            var reabierto = MYGProyectoStorage.Leer(ruta);
            Exige(JsonSerializer.Serialize(reabierto.Cronograma.Calendario) == esperado &&
                JsonSerializer.Serialize(reabierto.Cronograma.Calendarios) == listaEsperada,
                "guardar/reabrir " + extension + " perdió los campos de calendarios o excepciones");
            Exige(reabierto.Cronograma.Calendario.SumarDiasLaborables(new(2026, 12, 24), 2) == new DateTime(2026, 12, 29),
                "guardar/reabrir " + extension + " cambió las fechas ordinales heredadas");
            Exige(reabierto.Cronograma.Calendario.HorasDelDia(new(2027, 1, 2)) == 2 &&
                !reabierto.Cronograma.Calendario.EsLaborable(new(2028, 2, 29)) &&
                !reabierto.Cronograma.Calendario.EsLaborable(new(2027, 9, 24)) &&
                reabierto.Cronograma.Calendario.Excepciones[^2].ProximaFecha(new(2028, 1, 1)) == new DateTime(2028, 9, 22),
                "guardar/reabrir " + extension + " perdió los horarios, excepciones o sus fechas resultantes");
        }
        pasa("Copia independiente, edición del motor y guardado/reapertura SQLite y JSON conservan nombre, turnos, seis tipos de excepción y resultados");
    }
}
