using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MYG_2027;

/// <summary>Una instantánea independiente de todos los metrados Excel seleccionados,
/// ordenados por la estructura del presupuesto en una sola hoja de cálculo.</summary>
public static class MYGReporteMetradosExcel
{
    private static readonly Regex Metrado = new(@"METRADO\s*\(\s*""(?<alias>(?:[^""]|"""")*)""\s*[;,]\s*""(?<dir>(?:[^""]|"""")*)""\s*\)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex Referencia = new(@"^(?<ca>\$?)(?<c>[A-Za-z]{1,3})(?<fa>\$?)(?<f>[1-9][0-9]*)$", RegexOptions.Compiled);
    private sealed class Bloque
    {
        internal MYGPresupuestoDocumento Presupuesto;
        internal ItemPresupuestoDelphin Partida;
        internal MYGHojaMetrado Hoja => Partida.Costos.Hoja;
        internal int Filas, Columnas, Inicio;
        internal int[] Limites, Principios, Finales;
        internal string Direccion(string direccion)
        {
            var p = MYGHojaCalculo.Coordenadas(direccion);
            if (p.Fila > Filas || p.Columna > Columnas) throw new FormatException("Referencia fuera del bloque de metrado.");
            return MYGHojaCalculo.Columna(Principios[p.Columna]) + (Inicio + p.Fila - 1).ToString(CultureInfo.InvariantCulture);
        }
        internal void Incluir(string direccion)
        {
            var p = MYGHojaCalculo.Coordenadas(direccion);
            if (p.Fila <= Hoja.Filas && p.Columna <= Hoja.Columnas)
            { Filas = Math.Max(Filas, p.Fila); Columnas = Math.Max(Columnas, p.Columna); }
        }
    }

    /// <param name="plantilla">null incluye todas las plantillas; vacío incluye
    /// las hojas importadas; las constantes de MYGPlantillasMetrado filtran la plantilla.</param>
    public static MYGHojaReporteProyecto Crear(MYGProyectoDocumento documento, string presupuestoId = null,
        string plantilla = null, bool todosPresupuestos = false)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var copia = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(copia);
        var presupuestos = todosPresupuestos
            ? copia.Presupuestos.OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.OrdinalIgnoreCase).ToArray()
            : new[] { copia.Presupuestos.FirstOrDefault(p => Igual(p.Id, string.IsNullOrWhiteSpace(presupuestoId)
                ? copia.PresupuestoActivoId : presupuestoId))
                ?? throw new InvalidOperationException("Seleccione un presupuesto del proyecto para mostrar sus metrados Excel.") };
        var bloques = presupuestos.SelectMany(p => MYGOrdenPresupuestos.FilasOrdenadas(p)
            .Where(i => !MYGProyectoStorage.EsTitulo(i) && i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel && i.Costos.Hoja != null &&
                (plantilla == null || Igual(MYGPlantillasMetrado.Identificar(i.Costos.Hoja), plantilla)))
            .Select(i => CrearBloque(p, i))).ToArray();
        var mapa = bloques.ToDictionary(b => Clave(b.Presupuesto.Id, b.Partida.IdLocalMYG ?? b.Partida.Id));
        // Incluye también celdas vacías que sean orígenes de una referencia: al
        // trasladarlas nunca deben terminar dentro del bloque de otra partida.
        foreach (var b in bloques)
            foreach (var r in b.Hoja.ReferenciasPartidas)
                if (mapa.TryGetValue(Clave(r.PresupuestoId, r.PartidaLocalId), out var origen))
                {
                    string direccion = Ancla(origen.Hoja, r);
                    if (!string.IsNullOrEmpty(direccion) && direccion != "#REF!") origen.Incluir(direccion);
                }

        // Una hoja Excel sólo admite un ancho por columna. Los límites comunes
        // y las combinaciones conservan el ancho propio de cada bloque. La
        // resolución de ocho píxeles respeta el mínimo que admite el editor;
        // cada límite se aproxima como máximo cuatro píxeles.
        var limites = new SortedSet<int> { 0, 192, 800 };
        foreach (var b in bloques)
        {
            b.Limites = new int[b.Columnas + 1];
            int ancho = 0;
            for (int c = 1; c <= b.Columnas; c++)
            {
                ancho += b.Hoja.AnchosColumnas.GetValueOrDefault(c, c == 1 ? 288 : c == 8 ? 110 : c is 2 or 3 ? 60 : c == 7 ? 95 : 68);
                b.Limites[c] = Math.Max(b.Limites[c - 1] + 8, (int)Math.Round(ancho / 8d, MidpointRounding.AwayFromZero) * 8);
                limites.Add(b.Limites[c]);
            }
        }
        int[] rejilla = limites.ToArray();
        if (rejilla.Length - 1 > 200)
            throw new InvalidDataException("Los metrados seleccionados superan las 200 columnas de la hoja consolidada. Exporte un presupuesto o una plantilla por separado.");
        var indices = rejilla.Select((x, i) => (x, i)).ToDictionary(x => x.x, x => x.i);
        var hoja = new MYGHojaMetrado
        {
            Nombre = "Metrados", Columnas = rejilla.Length - 1, Filas = 12, CeldaTotal = "A1",
            FormatoNumeroPredeterminado = "0.00", LineasDivision = true, Encabezados = true,
            FilasInmovilizadas = 10, RepetirTitulos = false, OrientacionPagina = rejilla[^1] > 1100 ? "Horizontal" : "Vertical"
        };
        for (int c = 1; c < rejilla.Length; c++)
            // Anchos superiores al máximo de una columna se subdividen por
            // límites de los otros bloques; una columna aislada ya fue validada.
            hoja.AnchosColumnas[c] = rejilla[c] - rejilla[c - 1];
        var datos = Datos(copia, presupuestos, todosPresupuestos);
        Cabecera(hoja, datos, indices[192]);
        int fila = 12;
        var niveles = new Dictionary<int, int>();
        foreach (var p in presupuestos)
        {
            var propios = bloques.Where(b => ReferenceEquals(b.Presupuesto, p)).ToArray();
            if (propios.Length == 0) continue;
            Banda(hoja, fila, string.IsNullOrWhiteSpace(p.Item) ? p.Nombre : p.Item + "  " + p.Nombre, 0); niveles[fila++] = 0;
            var items = p.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
            var necesarios = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var b in propios)
            {
                var actual = b.Partida;
                while (!string.IsNullOrEmpty(actual.ParentId) && items.TryGetValue(actual.ParentId, out var padre) && necesarios.Add(padre.Id))
                    actual = padre;
            }
            foreach (var i in MYGOrdenPresupuestos.FilasOrdenadas(p))
            {
                if (MYGProyectoStorage.EsTitulo(i))
                {
                    if (!necesarios.Contains(i.Id)) continue;
                    int nivel = 1;
                    var actual = i; var vistos = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { i.Id };
                    while (!string.IsNullOrEmpty(actual.ParentId) && items.TryGetValue(actual.ParentId, out var padre) && vistos.Add(padre.Id))
                    { nivel++; actual = padre; }
                    Banda(hoja, fila, i.Item + "  " + i.Descripcion, nivel); niveles[fila++] = nivel;
                    continue;
                }
                if (!mapa.TryGetValue(Clave(p.Id, i.IdLocalMYG ?? i.Id), out var bloque)) continue;
                Banda(hoja, fila++, Codigo(p, i) + "  " + i.Descripcion + (string.IsNullOrWhiteSpace(i.Unidad) ? "" : "  [" + i.Unidad + "]"), -1);
                bloque.Inicio = fila;
                bloque.Principios = new int[bloque.Columnas + 1]; bloque.Finales = new int[bloque.Columnas + 1];
                for (int c = 1; c <= bloque.Columnas; c++)
                { bloque.Principios[c] = indices[bloque.Limites[c - 1]] + 1; bloque.Finales[c] = indices[bloque.Limites[c]]; }
                fila += bloque.Filas + 1;
                ComprobarLimites(hoja, fila - 1);
            }
        }
        if (bloques.Length == 0) Banda(hoja, fila++, "No hay partidas con metrados Excel en la selección.", -1);
        hoja.Filas = fila - 1;
        ComprobarLimites(hoja, hoja.Filas);
        var calculo = new MYGSesionHojaCalculo(new MYGContextoReferenciasMetrado(copia.Presupuestos));
        var formulas = new List<(Bloque Bloque, string Origen, string Destino)>();
        foreach (var b in bloques) CopiarBloque(hoja, b, mapa, calculo, formulas);
        // Funciones que dependen de la posición o del número de columnas pueden
        // cambiar de significado al reunir anchos distintos. Sólo esos resultados
        // se materializan; las fórmulas equivalentes siguen siendo editables.
        var pendientes = formulas.ToList();
        while (pendientes.Count > 0)
        {
            var resultado = new MYGHojaCalculo(hoja);
            var congelar = pendientes.Where(f => Valor(Evaluar(() => calculo.Resultado(f.Bloque.Hoja, f.Origen))) !=
                Valor(Evaluar(() => resultado.Resultado(f.Destino)))).ToArray();
            if (congelar.Length == 0) break;
            foreach (var f in congelar)
            {
                hoja.Celdas[f.Destino].Contenido = Literal(Evaluar(() => calculo.Resultado(f.Bloque.Hoja, f.Origen)));
                pendientes.Remove(f);
            }
            // Una fórmula dependiente puede haber coincidido por casualidad
            // antes de congelar su origen. Recalcular con una sesión nueva
            // garantiza que el resultado final de toda la hoja sea equivalente.
        }
        hoja.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(hoja.Columnas) + hoja.Filas;
        MYGHojaCalculo.Validar(hoja);
        return new MYGHojaReporteProyecto("Metrados Excel", hoja, datos, nivelesTitulos: niveles, cabeceraEnHoja: true);
    }

    private static Bloque CrearBloque(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i)
    {
        var b = new Bloque { Presupuesto = p, Partida = i, Filas = 1, Columnas = 1 };
        b.Incluir(b.Hoja.CeldaTotal);
        foreach (var c in b.Hoja.Celdas)
        {
            b.Incluir(c.Key);
            foreach (var r in MYGReferenciasFormulaHoja.Extraer(c.Value.Contenido, b.Hoja.Filas, b.Hoja.Columnas))
                b.Incluir(MYGHojaCalculo.Columna(r.ColumnaFinal) + r.FilaFinal);
        }
        foreach (string r in b.Hoja.RangosCombinados)
            foreach (string extremo in r.Split(':')) b.Incluir(extremo);
        foreach (int f in b.Hoja.AltosFilas.Keys) b.Filas = Math.Max(b.Filas, f);
        return b;
    }

    private static void CopiarBloque(MYGHojaMetrado destino, Bloque b, Dictionary<(string, string), Bloque> mapa,
        MYGSesionHojaCalculo calculo, List<(Bloque, string, string)> formulas)
    {
        var combinadas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        // La vista, impresión y XLSX omiten las filas vacías de la plantilla.
        // Conservar sus celdas ocultas mantiene intactas las fórmulas y anclas.
        var ocultas = b.Hoja.FilasOcultas.Concat(MYGContenidoPartida.FilasVaciasPlantilla(b.Hoja)).ToHashSet();
        foreach (string rango in b.Hoja.RangosCombinados)
        {
            string[] partes = rango.Split(':'); var a = MYGHojaCalculo.Coordenadas(partes[0]); var z = MYGHojaCalculo.Coordenadas(partes[^1]);
            destino.RangosCombinados.Add(b.Direccion(partes[0]) + ":" + MYGHojaCalculo.Columna(b.Finales[z.Columna]) + (b.Inicio + z.Fila - 1));
            for (int f = a.Fila; f <= z.Fila; f++)
                for (int c = a.Columna; c <= z.Columna; c++) combinadas.Add(MYGHojaCalculo.Columna(c) + f);
        }
        for (int f = 1; f <= b.Filas; f++)
        {
            int fila = b.Inicio + f - 1;
            if (b.Hoja.AltosFilas.TryGetValue(f, out int alto)) destino.AltosFilas[fila] = alto;
            if (ocultas.Contains(f)) destino.FilasOcultas.Add(fila);
            for (int c = 1; c <= b.Columnas; c++)
            {
                string origen = MYGHojaCalculo.Columna(c) + f, direccion = b.Direccion(origen);
                bool borde = MYGBordesPlantillaMetrado.Contiene(b.Hoja, f, c);
                if (!b.Hoja.Celdas.TryGetValue(origen, out var original) && !borde) continue;
                var copia = MYGEdicionHoja.CopiarCelda(original ?? new MYGCeldaHoja { FormatoNumero = b.Hoja.FormatoNumeroPredeterminado });
                copia.AlineacionHorizontal = MYGEdicionHoja.AlineacionCelda(copia, origen);
                copia.AlineacionPersonalizada = true; copia.Bordes |= borde;
                if (copia.Contenido.StartsWith('='))
                {
                    copia.Contenido = ConvertirFormula(b, copia.Contenido, mapa) ?? Literal(Evaluar(() => calculo.Resultado(b.Hoja, origen)));
                    formulas.Add((b, origen, direccion));
                }
                destino.Celdas[direccion] = copia;
                for (int sub = b.Principios[c] + 1; sub <= b.Finales[c]; sub++)
                {
                    var estilo = MYGEdicionHoja.CopiarCelda(copia); estilo.Contenido = "";
                    destino.Celdas[MYGHojaCalculo.Columna(sub) + fila] = estilo;
                }
                if (b.Principios[c] < b.Finales[c] && !combinadas.Contains(origen))
                    destino.RangosCombinados.Add(direccion + ":" + MYGHojaCalculo.Columna(b.Finales[c]) + fila);
            }
        }
    }

    private static string ConvertirFormula(Bloque b, string formula, Dictionary<(string, string), Bloque> mapa)
    {
        // Resolver la notación decimal antes de quitar METRADO: eliminar el
        // último ';' no debe reinterpretar una coma decimal como otro argumento.
        formula = MYGFuncionesExcel.AExcel(formula);
        var salida = new StringBuilder();
        // Las referencias locales se reemplazan desde el final para conservar
        // sus posiciones y mover también los anclajes absolutos de cada bloque.
        var cambios = new Dictionary<int, (int Longitud, string Valor)>();
        foreach (var r in MYGReferenciasFormulaHoja.Extraer(formula, b.Hoja.Filas, b.Hoja.Columnas))
        {
            string[] extremos = formula.Substring(r.Inicio, r.Longitud).Split(':');
            string Cambiar(string texto)
            {
                texto = texto.Trim(); var m = Referencia.Match(texto); var p = MYGHojaCalculo.Coordenadas(texto);
                if (p.Fila > b.Filas || p.Columna > b.Columnas) return "#REF!";
                return m.Groups["ca"].Value + MYGHojaCalculo.Columna(b.Principios[p.Columna]) + m.Groups["fa"].Value + (b.Inicio + p.Fila - 1);
            }
            cambios[r.Inicio] = (r.Longitud, string.Join(":", extremos.Select(Cambiar)));
        }
        for (int n = 0; n < formula.Length; n++)
        {
            if (cambios.TryGetValue(n, out var cambio))
            { salida.Append(cambio.Valor); n += cambio.Longitud - 1; continue; }
            if (formula[n] == '"')
            {
                salida.Append(formula[n]);
                while (++n < formula.Length)
                {
                    salida.Append(formula[n]);
                    if (formula[n] != '"') continue;
                    if (n + 1 < formula.Length && formula[n + 1] == '"') { salida.Append(formula[++n]); continue; }
                    break;
                }
                continue;
            }
            // Los vínculos nativos a libros/hojas ajenos no tienen identidad de
            // partida en MYG. Conservar su resultado evita crear referencias
            // colgantes al entregar un libro con una sola hoja.
            if (formula[n] is '\'' or '[' || formula[n] == '!' && (n < 4 || !formula[..n].EndsWith("#REF", StringComparison.OrdinalIgnoreCase)))
                return null;
            if ((n == 0 || !(char.IsLetterOrDigit(formula[n - 1]) || formula[n - 1] is '_' or '.')) &&
                formula.AsSpan(n).StartsWith("METRADO", StringComparison.OrdinalIgnoreCase))
            {
                var m = Metrado.Match(formula, n);
                if (!m.Success || m.Index != n) return null;
                string alias = m.Groups["alias"].Value.Replace("\"\"", "\"");
                string dir = MYGHojaCalculo.Normalizar(m.Groups["dir"].Value.Replace("\"\"", "\""));
                var r = b.Hoja.ReferenciasPartidas.FirstOrDefault(r => Igual(r.Alias, alias) && Igual(r.DireccionFormula, dir));
                if (r == null || !mapa.TryGetValue(Clave(r.PresupuestoId, r.PartidaLocalId), out var origen)) return null;
                string direccion = Ancla(origen.Hoja, r);
                if (!string.IsNullOrEmpty(direccion) && direccion != "#REF!")
                {
                    var p = MYGHojaCalculo.Coordenadas(direccion);
                    if (p.Fila > origen.Filas || p.Columna > origen.Columnas) return null;
                }
                salida.Append(string.IsNullOrEmpty(direccion) || direccion == "#REF!" ? "#REF!" : origen.Direccion(direccion));
                n += m.Length - 1; continue;
            }
            salida.Append(formula[n]);
        }
        return salida.ToString();
    }

    private static string Ancla(MYGHojaMetrado hoja, MYGReferenciaMetradoPartida r) =>
        hoja.AnclasReferencias.FirstOrDefault(a => Igual(a.Id, r.AnclaId))?.Direccion ?? (r.Pendiente ? r.DireccionFormula : "");
    private static bool Igual(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    private static (string, string) Clave(string p, string i) => ((p ?? "").ToUpperInvariant(), (i ?? "").ToUpperInvariant());
    private static string Codigo(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
        string.IsNullOrWhiteSpace(p.Item) ? i.Item ?? "" : p.Item + (string.IsNullOrWhiteSpace(i.Item) ? "" : "." + i.Item);
    private static string Valor(MYGValorExcel valor)
    {
        try { valor.SinError(); return (valor.EsTexto ? "T:" : valor.EsLogico ? "L:" : "N:") + valor.Texto; }
        catch (Exception e) when (e is FormatException or InvalidDataException or DivideByZeroException or OverflowException) { return "E:" + CodigoError(e); }
    }
    private static MYGValorExcel Evaluar(Func<MYGValorExcel> calcular)
    {
        try { return calcular(); }
        catch (Exception e) when (e is FormatException or InvalidDataException or DivideByZeroException or OverflowException)
        { return new MYGValorExcel(e); }
    }
    private static string CodigoError(Exception e) => e is MYGErrorReferenciaMetrado ? "#REF!" : e is MYGErrorExcel error ? error.Codigo : e is DivideByZeroException ? "#DIV/0!" : "#VALUE!";
    private static string Literal(MYGValorExcel valor)
    {
        try
        {
            valor.SinError();
            return valor.EsTexto ? "=\"" + valor.Texto.Replace("\"", "\"\"") + "\"" : valor.EsLogico ? valor.Logico ? "=TRUE" : "=FALSE" : valor.Numero().ToString(CultureInfo.InvariantCulture);
        }
        catch (Exception e) when (e is FormatException or InvalidDataException or DivideByZeroException or OverflowException) { return "=" + CodigoError(e); }
    }
    private static void ComprobarLimites(MYGHojaMetrado h, int filas)
    {
        if (filas > 10000 || (long)filas * h.Columnas > 200000)
            throw new InvalidDataException("Los metrados seleccionados superan las 10.000 filas o 200.000 celdas de la hoja consolidada. Exporte un presupuesto o una plantilla por separado.");
    }
    private static IReadOnlyList<KeyValuePair<string, string>> Datos(MYGProyectoDocumento d, MYGPresupuestoDocumento[] p, bool todos)
    {
        static string Texto(string valor) => string.IsNullOrWhiteSpace(valor) ? "No registrado" : valor.Trim();
        return new KeyValuePair<string, string>[]
        {
            new("PROYECTO", Texto(d.Nombre)), new("PRESUPUESTO", todos ? "Todos los presupuestos" : Texto(p.Single().ToString())),
            new("PROPIETARIO", Texto(d.Datos?.Propietario)), new("LOCALIDAD", Texto(d.Datos?.Localidad)),
            new("DISTRITO", Texto(d.Datos?.Distrito)), new("PROVINCIA", Texto(d.Datos?.Provincia)),
            new("DEPARTAMENTO", Texto(d.Datos?.Departamento)),
            new("FECHA PROY.", d.Datos?.FechaElaboracion?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "No registrado")
        };
    }
    private static void Cabecera(MYGHojaMetrado h, IReadOnlyList<KeyValuePair<string, string>> datos, int etiqueta)
    {
        Banda(h, 1, "METRADOS", -1); h.AltosFilas[1] = 32;
        h.Celdas["A1"].TamanoFuente = 14; h.Celdas["A1"].AlineacionHorizontal = "Centro";
        for (int n = 0; n < datos.Count; n++)
        {
            int f = n + 2; string derecha = MYGHojaCalculo.Columna(etiqueta + 1) + f;
            Texto(h, "A" + f, datos[n].Key + " :", false); Texto(h, derecha, datos[n].Value, false);
            if (etiqueta > 1) h.RangosCombinados.Add("A" + f + ":" + MYGHojaCalculo.Columna(etiqueta) + f);
            if (etiqueta + 1 < h.Columnas) h.RangosCombinados.Add(derecha + ":" + MYGHojaCalculo.Columna(h.Columnas) + f);
            h.AltosFilas[f] = Alto(datos[n].Value,
                h.AnchosColumnas.Where(c => c.Key > etiqueta).Sum(c => c.Value), 9m, n == 0 ? 46 : 23);
        }
    }
    private static void Banda(MYGHojaMetrado h, int fila, string titulo, int nivel)
    {
        ComprobarLimites(h, fila); Texto(h, "A" + fila, titulo, true);
        h.AltosFilas[fila] = Alto(titulo, h.AnchosColumnas.Values.Sum(), 9m, 28);
        if (h.Columnas > 1) h.RangosCombinados.Add("A" + fila + ":" + MYGHojaCalculo.Columna(h.Columnas) + fila);
        h.Celdas["A" + fila].ColorFondo = nivel == 0 ? "DCE6F1" : nivel > 0 ? "EDF2F7" : "FFFFFF";
    }
    private static void Texto(MYGHojaMetrado h, string direccion, string texto, bool negrita)
    {
        // Los nombres y códigos que parecen números o fórmulas son texto.
        h.Poner(direccion, "=\"" + (texto ?? "").Replace("\"", "\"\"") + "\"", negrita);
        var c = h.Celdas[direccion]; c.AjustarTexto = true; c.FormatoNumero = "General";
        c.AlineacionPersonalizada = true; c.AlineacionHorizontal = "Izquierda";
    }
    private static int Alto(string texto, int ancho, decimal fuente, int minimo)
    {
        int caracteres = Math.Max(1, (int)(Math.Max(8, ancho - 10) / (double)(fuente * .64m)));
        int lineas = (texto ?? "").Replace("\r\n", "\n").Replace('\r', '\n').Split('\n')
            .Sum(l => Math.Max(1, (int)Math.Ceiling(l.Length / (double)caracteres)));
        return Math.Min(1000, Math.Max(minimo, (int)Math.Ceiling(lineas * (double)fuente * 1.6 + 6)));
    }
}
