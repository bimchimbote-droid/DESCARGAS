using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

public sealed class MYGIndiceUnificado
{
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public override string ToString() => Codigo + " · " + Descripcion;
}

// Anexo 1 de la R.J. 016-2026-INEI, El Peruano, 20/01/2026, pág. 32.
// Los códigos reagrupados no son nuevas opciones; los datos históricos no se recodifican.
public static class MYGCatalogoIndicesUnificados
{
    public const string Resolucion = "016-2026-INEI";
    public const string PeriodoBase = "Diciembre 2025=100";
    /// <summary>Lee el código asignado sin reclasificar valores históricos ni
    /// confundir códigos internos o alternos con un índice unificado.</summary>
    public static string CodigoDeClasificacion(string clasificacion) =>
        System.Text.RegularExpressions.Regex.Match((clasificacion ?? "").Trim(),
            @"^[0-9]+(?:-[0-9]+)?(?=\s|·|$)").Value;

    private const string Tabla = "myg_indice_unificado";
    private static readonly (string Codigo, string Descripcion)[] Oficiales =
    {
        ("01", "Aceite y lubricante"),
        ("02", "Acero de construcción liso"),
        ("03", "Acero de construcción corrugado"),
        ("04", "Agregado fino"),
        ("05", "Agregado grueso"),
        ("06", "Alambre y cable de cobre desnudo"),
        ("07", "Alambre y cable tipo TW, THW, LSOH"),
        ("08", "Alambre y cable tipo WP, CPI"),
        ("09", "Alcantarilla metálica y guardavías"),
        ("10", "Aparato sanitario con grifería"),
        ("11", "Artefacto de alumbrado exterior"),
        ("12", "Artefacto de alumbrado interior"),
        ("13", "Asfalto"),
        ("14", "Baldosa acústica"),
        ("16", "Baldosa vinílica y PVC"),
        ("17", "Bloque y ladrillo"),
        ("18", "Cable telefónico y de red"),
        ("19", "Cable NYY,N2XY, NPT, N2XOH, N2XSY"),
        ("20", "Cemento asfáltico"),
        ("21", "Cemento Portland e hidráulico"),
        ("24", "Cerámica y porcelanato"),
        ("26", "Cerrajería"),
        ("27", "Detonante"),
        ("28", "Dinamita"),
        ("30", "Dólar más inflación mercado USA"),
        ("31", "Prefabricado de concreto"),
        ("32", "Flete terrestre"),
        ("33", "Flete aéreo"),
        ("34", "Gasohol y gasolina"),
        ("37", "Herramienta manual"),
        ("38", "Hormigón y afirmado"),
        ("39", "Índice de Precios al Consumidor (INEI)"),
        ("40", "Loseta y terrazo"),
        ("41", "Madera nacional en tiras para piso"),
        ("42", "Madera importada para encofrado y carpintería"),
        ("43", "Madera nacional para encofrado y carpintería"),
        ("44", "Madera terciada nacional"),
        ("46", "Malla de acero"),
        ("47", "Mano de obra (incluye leyes sociales)"),
        ("47-1", "Mano de obra de alta especialización (incluye leyes sociales)"),
        ("48", "Maquinaria y equipo de construcción liviano"),
        ("49", "Maquinaria y equipo de construcción pesado"),
        ("50", "Marco y tapa de fierro"),
        ("51", "Perfil de acero al carbono"),
        ("52", "Perfil de aluminio"),
        ("53", "Petróleo diésel"),
        ("54", "Pintura látex"),
        ("55", "Pintura temple"),
        ("56", "Plancha de acero LAC"),
        ("57", "Plancha de acero LAF"),
        ("59", "Plancha de fibrocemento y yeso"),
        ("60", "Plancha de poliuretano, poliestireno y termoaislante"),
        ("61", "Plancha galvanizada"),
        ("62", "Poste de concreto"),
        ("65", "Tubería de acero negro y/o galvanizado"),
        ("66", "Tubería de PVC para la red de agua potable y alcantarillado"),
        ("68", "Tubería de cobre"),
        ("71", "Tubería de hierro fundido y dúctil"),
        ("72", "Tubería de PVC para redes interiores"),
        ("77", "Válvula de bronce y latón"),
        ("78", "Válvula de hierro y acero"),
        ("79", "Vidrio"),
        ("80", "Concreto premezclado"),
        ("81", "Aditivo de concreto y similar"),
        ("82", "Alambre y cable de aluminio"),
        ("83", "Implemento y accesorio de seguridad"),
        ("84", "Madera terciada importada"),
        ("85", "Perfil de acero galvanizado"),
        ("86", "Pintura esmalte y epóxica"),
        ("87", "Plancha con cubierta aluzinc"),
        ("88", "Plancha y cobertura plástica"),
        ("89", "Poste y tubería de fibra de vidrio"),
        ("90", "Tubería de polietileno"),
        ("91", "Geomembrana y geotextil"),
        ("92", "Flete fluvial"),
        ("93", "Bienes y servicios auxiliares"),
        ("94", "Encofrado y andamio prefabricado"),
        ("95", "Equipamiento permanente de obra"),
    };

    private static List<MYGIndiceUnificado> Predeterminados() => Oficiales.Select(x =>
        new MYGIndiceUnificado { Codigo = x.Codigo, Descripcion = x.Descripcion }).ToList();

    // Las bases anteriores ofrecen el catálogo actual sin escribir al consultarlas.
    // Los valores históricos de GrupoGenerico se conservan hasta una selección explícita.
    public static List<MYGIndiceUnificado> Listar(string ruta = null)
    {
        if (string.IsNullOrWhiteSpace(ruta)) return Predeterminados();
        using var c = MYGBaseDatos.Abrir(ruta, false);
        if (!MYGBaseDatos.TieneTabla(c, null, Tabla)) return Predeterminados();
        using var cmd = MYGBaseDatos.Comando(c, null,
            "SELECT codigo,descripcion FROM myg_indice_unificado ORDER BY orden,codigo COLLATE NOCASE");
        using var r = cmd.ExecuteReader(); var lista = new List<MYGIndiceUnificado>();
        while (r.Read()) lista.Add(new MYGIndiceUnificado { Codigo = r.GetString(0), Descripcion = r.GetString(1) });
        return lista;
    }

    internal static void Inicializar(SqliteConnection c, SqliteTransaction t)
    {
        MYGBaseDatos.Ejecutar(c, t, """
            CREATE TABLE IF NOT EXISTS myg_indice_unificado(
                codigo TEXT PRIMARY KEY COLLATE NOCASE,descripcion TEXT NOT NULL,
                periodo_base TEXT NOT NULL,resolucion TEXT NOT NULL,orden INTEGER NOT NULL);
            """);
        for (int n = 0; n < Oficiales.Length; n++)
        {
            var indice = Oficiales[n];
            MYGBaseDatos.Ejecutar(c, t,
                "INSERT OR IGNORE INTO myg_indice_unificado(codigo,descripcion,periodo_base,resolucion,orden) VALUES($p0,$p1,$p2,$p3,$p4)",
                indice.Codigo, indice.Descripcion, PeriodoBase, Resolucion, n);
        }
    }

    internal static void Copiar(SqliteConnection origen, SqliteTransaction lectura, SqliteConnection destino, SqliteTransaction escritura)
    {
        if (!MYGBaseDatos.TieneTabla(origen, lectura, Tabla)) return;
        Inicializar(destino, escritura);
        // Guardar copia conserva el catálogo del archivo, sin cambiar clasificaciones antiguas.
        MYGBaseDatos.Ejecutar(destino, escritura, "DELETE FROM myg_indice_unificado");
        using var cmd = MYGBaseDatos.Comando(origen, lectura,
            "SELECT codigo,descripcion,periodo_base,resolucion,orden FROM myg_indice_unificado");
        using var r = cmd.ExecuteReader();
        while (r.Read()) MYGBaseDatos.Ejecutar(destino, escritura,
            "INSERT INTO myg_indice_unificado(codigo,descripcion,periodo_base,resolucion,orden) VALUES($p0,$p1,$p2,$p3,$p4)",
            r.GetString(0), r.GetString(1), r.GetString(2), r.GetString(3), r.GetInt32(4));
    }
}
