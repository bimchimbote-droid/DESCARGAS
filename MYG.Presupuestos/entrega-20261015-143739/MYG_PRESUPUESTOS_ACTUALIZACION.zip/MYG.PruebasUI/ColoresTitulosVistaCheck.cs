using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class ColoresTitulosVistaCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = CrearProyecto();
        var presupuesto = proyecto.Presupuestos.Single();
        string proyectoOriginal = MYGProyectoStorage.Firma(proyecto);
        var reportes = MYGReportesProyecto.Crear(proyecto, presupuesto.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado);
        var reporte = reportes.Single();
        exige(reporte.NivelesTitulos.OrderBy(n => n.Key).SequenceEqual(new KeyValuePair<int, int>[]
            { new(3, 0), new(4, 1), new(5, 2) }),
            "El presupuesto debe identificar la raíz, el título y el subtítulo por nivel, excluyendo la partida y el pie.");

        // Un color guardado distinto de negro permite detectar una restauración
        // que borre el formato original en vez de recuperar la instantánea.
        reporte.Hoja.Celdas["B4"].ColorTexto = "314159";
        foreach (var celda in reporte.Hoja.Celdas.Values) celda.Fuente = "Times New Roman";
        string reportesOriginales = Datos(reportes);
        using (var formulario = new MYGVistaPreliminarReportesForm("Colores de los títulos", reportes))
        {
            var controles = Controles(formulario).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
            var colores = (CheckBox)controles["vista_colores_titulos"];
            var configuracion = formulario.Configuracion;
            string vistaOriginal = Datos(configuracion.Reportes);
            var celdasOriginales = configuracion.Reportes.Single().Hoja.Celdas.ToDictionary(c => c.Key, c => Datos(c.Value));
            exige(colores.Enabled && !colores.Checked && !configuracion.TitulosConColor,
                "La opción de colorear títulos debe estar habilitada para el presupuesto e iniciar desmarcada, sin aplicar colores.");
            exige(configuracion.Reportes.Single().Hoja.Celdas.Values.All(c => c.Fuente == "Arial Narrow") &&
                    configuracion.Reportes.Single().Hoja.Celdas["B4"].ColorTexto == "314159",
                "Abrir el presupuesto debe aplicar Arial Narrow a la copia y conservar sus colores originales mientras la opción está desmarcada.");

            var hojaEsperada = MYGProyectoStorage.Copia(configuracion.Reportes.Single().Hoja);
            foreach (var entrada in hojaEsperada.Celdas)
            {
                int fila = MYGHojaCalculo.Coordenadas(entrada.Key).Fila;
                if (reporte.NivelesTitulos.TryGetValue(fila, out int nivel))
                    entrada.Value.ColorTexto = ColorNivel(nivel);
            }
            colores.Checked = true;
            exige(colores.Checked && configuracion.TitulosConColor &&
                    Datos(configuracion.Reportes.Single().Hoja) == Datos(hojaEsperada),
                "Marcar la opción debe usar el color de cada nivel en toda la fila de título y conservar fondos, fuentes, contenidos, formatos, partida y pie.");
            exige(configuracion.Reportes.Single().Hoja.Celdas.Where(c =>
                    !reporte.NivelesTitulos.ContainsKey(MYGHojaCalculo.Coordenadas(c.Key).Fila)).All(c =>
                    Datos(c.Value) == celdasOriginales[c.Key]),
                "Colorear los títulos debe conservar intactas las celdas de cabecera, partida y resumen, además de sus sombreados e importes.");
            exige(Datos(reportes) == reportesOriginales && MYGProyectoStorage.Firma(proyecto) == proyectoOriginal,
                "Activar los colores en la vista debe mantener intactos los reportes recibidos y el proyecto abierto.");

            colores.Checked = false;
            exige(!configuracion.TitulosConColor && Datos(configuracion.Reportes) == vistaOriginal,
                "Desmarcar la opción debe recuperar exactamente los colores y formatos de la vista inicial, incluido cualquier color personalizado.");
            colores.Checked = true;
            configuracion.Fuente("Courier New");
            var restaurar = Controles(formulario).OfType<ToolStrip>().SelectMany(b => Acciones(b.Items))
                .Single(a => a.Name == "vista_restaurar");
            restaurar.PerformClick();
            exige(colores.Enabled && !colores.Checked && !configuracion.TitulosConColor &&
                    controles["vista_fuente"].Text == "Arial Narrow" && Datos(configuracion.Reportes) == vistaOriginal,
                "Restablecer debe desmarcar colores, recuperar Arial Narrow y restaurar todas las celdas sin perder los niveles de los títulos.");
        }

        VerificarColoresEntreTemas(reportes, exige);
        var metrados = MYGReportesProyecto.Crear(proyecto, presupuesto.Id, MYGTipoReporteProyecto.Metrados);
        var metrado = metrados.Single();
        var nivelesMetrados = new KeyValuePair<int, int>[] { new(3, 0), new(4, 1), new(5, 2) };
        exige(metrado.NivelesTitulos.OrderBy(n => n.Key).SequenceEqual(nivelesMetrados),
            "El listado de metrados debe identificar la raíz, el título y el subtítulo con los mismos niveles del presupuesto, excluyendo las cantidades de las partidas.");
        metrado.Hoja.Celdas["B4"].ColorTexto = "314159";
        string metradosOriginales = Datos(metrados);
        using (var formulario = new MYGVistaPreliminarReportesForm("Colores del listado de metrados", metrados))
        {
            var controles = Controles(formulario).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
            var colores = (CheckBox)controles["vista_colores_titulos"];
            var configuracion = formulario.Configuracion;
            string vistaOriginal = Datos(configuracion.Reportes);
            var original = configuracion.Reportes.Single();
            exige(colores.Enabled && !colores.Checked && !configuracion.TitulosConColor &&
                    original.EsListadoMetrados && original.UsaFormatoPresupuesto &&
                    original.NivelesTitulos.OrderBy(n => n.Key).SequenceEqual(nivelesMetrados),
                "La vista de metrados debe permitir colorear los títulos y conservar el formato de presupuesto y todos sus niveles en la copia de impresión.");
            exige(original.Hoja.Celdas.Values.All(c => c.Fuente == "Arial Narrow") &&
                    original.Hoja.Celdas["B4"].ColorTexto == "314159",
                "Abrir el listado de metrados debe conservar los colores iniciales y aplicar Arial Narrow a la vista.");

            var hojaEsperada = MYGProyectoStorage.Copia(original.Hoja);
            foreach (var entrada in hojaEsperada.Celdas)
            {
                int fila = MYGHojaCalculo.Coordenadas(entrada.Key).Fila;
                if (metrado.NivelesTitulos.TryGetValue(fila, out int nivel))
                    entrada.Value.ColorTexto = ColorNivel(nivel);
            }
            colores.Checked = true;
            exige(configuracion.TitulosConColor && Datos(configuracion.Reportes.Single().Hoja) == Datos(hojaEsperada),
                "Colorear metrados debe aplicar los tonos de cada nivel a sus títulos sin alterar las partidas, sus cantidades, las unidades ni los fondos.");
            colores.Checked = false;
            exige(!configuracion.TitulosConColor && Datos(configuracion.Reportes) == vistaOriginal,
                "Desmarcar los colores en metrados debe recuperar todos los colores y formatos originales, incluido el color personalizado.");
            colores.Checked = true;
            configuracion.Fuente("Courier New");
            var restaurar = Controles(formulario).OfType<ToolStrip>().SelectMany(b => Acciones(b.Items))
                .Single(a => a.Name == "vista_restaurar");
            restaurar.PerformClick();
            exige(colores.Enabled && !colores.Checked && !configuracion.TitulosConColor &&
                    controles["vista_fuente"].Text == "Arial Narrow" && Datos(configuracion.Reportes) == vistaOriginal,
                "Restablecer el listado de metrados debe recuperar la vista inicial y mantener habilitados sus colores y niveles de títulos.");
        }
        exige(Datos(reportes) == reportesOriginales && Datos(metrados) == metradosOriginales &&
                MYGProyectoStorage.Firma(proyecto) == proyectoOriginal,
            "Cerrar las vistas después de activar, desactivar y restablecer colores debe conservar todas las hojas y el proyecto originales.");
    }

    private static void VerificarColoresEntreTemas(IReadOnlyList<MYGHojaReporteProyecto> reportes, Action<bool, string> exige)
    {
        MYG2027_TemaComercial.Inicializar();
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        string vistaColoreada = null;
        try
        {
            foreach (bool oscuro in new[] { false, true, false })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                using var formulario = new MYGVistaPreliminarReportesForm("Paleta de impresión", reportes);
                var colores = Controles(formulario).OfType<CheckBox>().Single(c => c.Name == "vista_colores_titulos");
                colores.Checked = true;
                string actual = Datos(formulario.Configuracion.Reportes);
                vistaColoreada ??= actual;
                exige(formulario.Configuracion.TitulosConColor && actual == vistaColoreada,
                    "Activar los colores con tema claro u oscuro debe producir los mismos tonos de impresión legibles sobre papel blanco, conservando todos los formatos.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static MYGProyectoDocumento CrearProyecto()
    {
        var proyecto = MYGProyectoStorage.Nuevo("PRUEBA DE COLORES DE TÍTULOS", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var titulo = CrearItem("01", "TÍTULO DE ESTRUCTURAS", null, true);
        var subtitulo = CrearItem("01.01", "SUBTÍTULO DE CONCRETO", titulo.Id, true);
        var partida = CrearItem("01.01.01", "CONCRETO PARA CIMENTACIÓN", subtitulo.Id, false);
        partida.Costos.Cantidad = 2.5m;
        partida.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        partida.Costos.PrecioDirecto = 100m;
        presupuesto.Items.AddRange(new[] { titulo, subtitulo, partida });
        presupuesto.Costos.GastosGeneralesPorcentaje = 10m;
        presupuesto.Costos.UtilidadPorcentaje = 7m;
        presupuesto.Costos.ImpuestoPorcentaje = 18m;
        return proyecto;
    }

    private static ItemPresupuestoDelphin CrearItem(string codigo, string descripcion, string padre, bool titulo)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, ParentId = padre,
            Item = codigo, Descripcion = descripcion, Unidad = titulo ? "" : "m³",
            TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1
        };
    }

    private static string ColorNivel(int nivel) =>
        (MYG2027_TemaComercial.ColorTituloImpresion(nivel).ToArgb() & 0xFFFFFF).ToString("X6", CultureInfo.InvariantCulture);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }

    private static IEnumerable<ToolStripItem> Acciones(ToolStripItemCollection items)
    {
        foreach (ToolStripItem item in items)
        {
            yield return item;
            if (item is ToolStripDropDownItem menu)
                foreach (var descendiente in Acciones(menu.DropDownItems)) yield return descendiente;
        }
    }

    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
}
