using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using MYG_2027;

internal static class ReportesImpresionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarColumnasAcero(exige);
        VerificarFilasYCombinaciones(exige);
        VerificarLimitesYErrores(exige);
        VerificarPresupuestoObra(exige);
        VerificarListadoMetrados(exige);
        VerificarAjusteAnchura(exige);
    }

    private static void VerificarListadoMetrados(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("PROYECTO DE METRADOS", "ESTRUCTURAS");
        proyecto.Datos = new MYGDatosProyecto
        {
            Propietario = "PROPIETARIO DE METRADOS",
            Portafolio = "PORTAFOLIO_OCULTO_METRADOS"
        };
        var presupuesto = proyecto.Presupuestos.Single();
        for (int n = 1; n <= 8; n++)
        {
            string id = MYGProyectoStorage.NuevoId();
            var partida = new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, IdPropuesta = id,
                Item = "01." + n.ToString("00"), Descripcion = "PARTIDA DE METRADO " + n,
                Unidad = "m²", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = n
            };
            partida.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
            partida.Costos.Cantidad = n == 8 ? 0m : n;
            partida.Costos.PrecioDirecto = 987654.32m;
            presupuesto.Items.Add(partida);
        }

        var reportes = MYGReportesProyecto.Crear(proyecto, presupuesto.Id, MYGTipoReporteProyecto.Metrados);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        exige(reportes.Count == 1 && vista.CantidadPaginas == 1 &&
                Enumerable.Range(1, 8).All(n => vista.BuscarPagina("PARTIDA DE METRADO " + n, 0) == 0),
            "Metrados debe imprimir juntas las ocho partidas en un listado compacto, incluida la partida de cantidad cero, sin crear una página por partida.");
        exige(vista.BuscarPagina("METRADOS", 0) == 0 && vista.BuscarPagina("PROPIETARIO DE METRADOS", 0) == 0 &&
                vista.BuscarPagina("PORTAFOLIO_OCULTO_METRADOS", 0) == -1 &&
                vista.BuscarPagina("Precio", 0) == -1 && vista.BuscarPagina("Parcial", 0) == -1 &&
                vista.BuscarPagina("Gastos generales", 0) == -1 && vista.BuscarPagina("987", 0) == -1,
            "El listado de metrados debe mostrar su título y la cabecera compacta del presupuesto sin metadatos adicionales, precios, parciales ni pie monetario.");
        RectangleF cabecera = vista.AreaCabecera(0);
        exige(cabecera.Height > .8f && cabecera.Height < 3,
            "La cabecera de metrados debe usar el formato compacto del presupuesto para dejar espacio al listado.");
        using var imagen = new Bitmap(794, 1123);
        imagen.SetResolution(96, 96);
        using var dibujo = Graphics.FromImage(imagen);
        vista.DibujarPagina(dibujo, 0);
    }

    private static void VerificarPresupuestoObra(Action<bool, string> exige)
    {
        var doc = MYGProyectoStorage.Nuevo(new string('X', 180) + " PROYECTO DE PRUEBA", "ESTRUCTURAS");
        doc.Datos = new MYGDatosProyecto();
        doc.Datos.Propietario = "ENTIDAD PROPIETARIA";
        doc.Datos.Portafolio = "PORTAFOLIO_OCULTO_QA";
        var p = doc.Presupuestos[0];
        for (int n = 1; n <= 80; n++)
        {
            string id = MYGProyectoStorage.NuevoId();
            p.Items.Add(new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
                Item = n.ToString("00"), Descripcion = "PARTIDA DE COMPROBACIÓN CON DESCRIPCIÓN EXTENSA " + n,
                Unidad = "m²", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = n });
        }
        var reportes = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        exige(vista.CantidadPaginas > 1 && vista.BuscarPagina("PORTAFOLIO_OCULTO_QA", 0) == -1 &&
            vista.BuscarPagina("PRESUPUESTO DE OBRA", 0) == 0 && vista.BuscarPagina("ENTIDAD PROPIETARIA", 0) == 0,
            "La búsqueda del presupuesto debe encontrar el título y datos visibles, sin anunciar metadatos ocultos.");
        RectangleF cabecera = vista.AreaCabecera(0);
        exige(cabecera.Height > .8f && cabecera.Height < 3 && vista.AreaCabecera(vista.CantidadPaginas - 1) == cabecera,
            "La cabecera en filas debe admitir nombres largos y repetirse sin ocupar toda la página.");
        foreach (var ajuste in new (float Escala, int Ancho)[] { (1f, 0), (.25f, 0), (1f, 1), (1f, 2) })
        {
            var plan = MYGReportesImpresion.PrepararVista(reportes, ajuste.Escala, paginasDeAncho: ajuste.Ancho);
            using var imagen = new Bitmap(794, 1123);
            imagen.SetResolution(96, 96);
            using var dibujo = Graphics.FromImage(imagen);
            plan.DibujarPagina(dibujo, 0);
            plan.DibujarPagina(dibujo, plan.CantidadPaginas - 1);
            exige(plan.CantidadPaginas > 0, "Escala y anchura deben producir páginas renderizables del presupuesto de obra.");
        }
        var configuracion = new MYGConfiguracionVistaReporte(reportes);
        configuracion.ConfigurarPagina("A4", "Vertical", 51 / 25.4m, 51 / 25.4m, 25 / 25.4m, 25 / 25.4m);
        var ancho = MYGReportesImpresion.PrepararVista(configuracion.Reportes, paginasDeAncho: 1);
        exige(ancho.CantidadPaginas > 0 && ancho.BuscarPagina("ENTIDAD PROPIETARIA", 0) == 0,
            "El presupuesto debe conservar la cabecera y todas sus columnas con márgenes anchos y ajuste a una página.");
    }

    private static void VerificarAjusteAnchura(Action<bool, string> exige)
    {
        var hoja = new MYGHojaMetrado { Nombre = "Anchura", Filas = 2, Columnas = 10,
            CeldaTotal = "J2", AreaImpresion = "A1:J2", RepetirTitulos = false };
        for (int c = 1; c <= 10; c++)
        {
            hoja.AnchosColumnas[c] = 250;
            hoja.Poner(MYGHojaCalculo.Columna(c) + "1", "COLUMNA " + c);
            hoja.Poner(MYGHojaCalculo.Columna(c) + "2", c.ToString());
        }
        var reportes = new[] { new MYGHojaReporteProyecto("Anchura", hoja) };
        var porcentual = MYGReportesImpresion.PrepararVista(reportes);
        var una = MYGReportesImpresion.PrepararVista(reportes, paginasDeAncho: 1);
        var dos = MYGReportesImpresion.PrepararVista(reportes, paginasDeAncho: 2);
        exige(porcentual.CantidadPaginas > 2 && una.CantidadPaginas == 1 && dos.CantidadPaginas == 2 &&
            una.BuscarPagina("COLUMNA 10", 0) == 0 && dos.BuscarPagina("COLUMNA 10", 0) == 1,
            "Ajustar a una o dos páginas de ancho debe paginar realmente y conservar la última columna.");
    }

    private static void VerificarColumnasAcero(Action<bool, string> exige)
    {
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        float[] anchos = Enumerable.Range(1, hoja.Columnas)
            .Select(columna => hoja.AnchosColumnas.TryGetValue(columna, out int ancho) ? (float)ancho : 72f).ToArray();
        float[] originales = anchos.ToArray();
        exige(anchos.Length == 34, "El caso de impresión debe cubrir las 34 columnas de la plantilla de fierros y aceros.");
        foreach (float disponible in new[] { 440f, 640f, 980f })
        {
            var segmentos = MYGReportesImpresion.SegmentarColumnas(anchos, disponible);
            exige(segmentos.Count > 1 && segmentos.All(s => s.Length > 1 && s[0] == 0),
                "Una hoja ancha de aceros debe generar varias páginas horizontales, cada una con la descripción y columnas de datos.");
            exige(segmentos.SelectMany(s => s.Skip(1)).SequenceEqual(Enumerable.Range(1, anchos.Length - 1)),
                "La impresión de aceros debe conservar todas las columnas y su orden, repitiendo únicamente la descripción de cada segmento.");
            exige(segmentos.All(s => s.Distinct().Count() == s.Length && s.All(c => c >= 0 && c < anchos.Length) &&
                    s.Sum(c => anchos[c]) * 0.85f <= disponible + 0.001f),
                "Cada segmento debe caber completo sin recortar datos ni reducirlos por debajo de la escala mínima de lectura.");
        }
        exige(anchos.SequenceEqual(originales),
            "Preparar los segmentos de impresión debe conservar los anchos definidos por el usuario.");

        float[] limite = { 120f, 60f, 60f, 80f };
        float anchoExacto = limite.Sum() * 0.85f;
        var unaPagina = MYGReportesImpresion.SegmentarColumnas(limite, anchoExacto);
        exige(unaPagina.Count == 1 && unaPagina[0].SequenceEqual(Enumerable.Range(0, limite.Length)),
            "Las columnas que caben exactamente a la escala mínima deben permanecer juntas y completas.");
        var espacioMenor = MYGReportesImpresion.SegmentarColumnas(limite, anchoExacto - 1f);
        exige(espacioMenor.Count > 1 && espacioMenor.SelectMany(s => s.Skip(1)).SequenceEqual(Enumerable.Range(1, limite.Length - 1)) &&
            espacioMenor.All(s => s.Sum(c => limite[c]) * 0.85f <= anchoExacto - 1f + 0.001f),
            "Reducir el espacio por debajo del límite debe crear segmentos adicionales sin perder ni recortar la última columna.");
    }

    private static void VerificarFilasYCombinaciones(Action<bool, string> exige)
    {
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        hoja.FilasOcultas.AddRange(new[] { 5, 7 });
        int[] filas = Enumerable.Range(1, 16).Where(f => !hoja.FilasOcultas.Contains(f)).ToArray();
        float[] altos = filas.Select(f => hoja.AltosFilas.TryGetValue(f, out int alto) ? (float)alto : 20f).ToArray();
        int[] filasOriginales = filas.ToArray();
        float[] altosOriginales = altos.ToArray();
        (int Primera, int Ultima)[] combinaciones = { (6, 8), (8, 10), (14, 15) };
        var paginas = MYGReportesImpresion.PaginarFilas(filas, altos, combinaciones, 160f, 2);
        exige(paginas.Count > 1, "La hoja de aceros debe distribuir su cuerpo en varias páginas cuando el alto disponible no alcanza.");
        VerificarPaginacion(filas, altos, combinaciones, paginas, 160f, 2, exige);
        exige(paginas.All(p => !p.Contains(5) && !p.Contains(7)),
            "Las filas ocultas deben permanecer ausentes incluso dentro de un rango combinado.");
        exige(filas.SequenceEqual(filasOriginales) && altos.SequenceEqual(altosOriginales),
            "Paginar la hoja debe conservar la numeración y las alturas originales para exportar sin modificar el proyecto.");

        int[] sinCabecera = { 3, 4, 6, 7, 9, 10 };
        float[] altosSinCabecera = { 21f, 21f, 21f, 21f, 21f, 21f };
        (int Primera, int Ultima)[] bloque = { (6, 7) };
        var paginasSinCabecera = MYGReportesImpresion.PaginarFilas(sinCabecera, altosSinCabecera, bloque, 63f, 0);
        exige(paginasSinCabecera.Count > 1, "La paginación también debe funcionar sin filas de título.");
        VerificarPaginacion(sinCabecera, altosSinCabecera, bloque, paginasSinCabecera, 63f, 0, exige);

        // Una unión que atraviesa título y cuerpo es válida cuando toda la hoja
        // cabe: repetir solo una parte tendría sentido únicamente al paginar.
        var hojaCompleta = MYGReportesImpresion.PaginarFilas(new[] { 1, 2, 3, 4 },
            new[] { 10f, 10f, 10f, 10f }, new[] { (2, 3) }, 40f, 2);
        exige(hojaCompleta.Count == 1 && hojaCompleta[0].SequenceEqual(new[] { 1, 2, 3, 4 }),
            "Una combinación entre título y cuerpo que cabe en una página debe imprimirse íntegra sin generar páginas adicionales.");
    }

    private static void VerificarPaginacion(IReadOnlyList<int> filas, IReadOnlyList<float> altos,
        IReadOnlyList<(int Primera, int Ultima)> combinaciones, IReadOnlyList<int[]> paginas,
        float altoDisponible, int filasTitulo, Action<bool, string> exige)
    {
        int[] titulos = filas.Take(filasTitulo).ToArray();
        int[] cuerpo = filas.Skip(filasTitulo).ToArray();
        var altura = filas.Select((fila, i) => (fila, alto: altos[i])).ToDictionary(x => x.fila, x => x.alto);
        exige(paginas.All(p => p.Take(filasTitulo).SequenceEqual(titulos) && p.Length > filasTitulo),
            "Cada página del cuerpo debe repetir los títulos completos y contener datos; no debe crear páginas vacías.");
        exige(paginas.SelectMany(p => p.Skip(filasTitulo)).SequenceEqual(cuerpo),
            "Todas las filas visibles del cuerpo deben imprimirse una sola vez y en su orden original.");
        exige(paginas.All(p => p.All(altura.ContainsKey) && p.Sum(f => altura[f]) <= altoDisponible + 0.001f),
            "Cada página debe respetar las alturas reales y el espacio disponible sin inventar filas ni recortar su contenido.");
        exige(combinaciones.All(c =>
        {
            int[] bloqueVisible = cuerpo.Where(f => f >= c.Primera && f <= c.Ultima).ToArray();
            return bloqueVisible.Length == 0 || paginas.Count(p => bloqueVisible.Any(p.Contains)) == 1;
        }), "Las filas combinadas verticalmente deben permanecer en una única página, incluso con bloques superpuestos y filas ocultas.");
    }

    private static void VerificarLimitesYErrores(Action<bool, string> exige)
    {
        foreach (float invalida in new[] { 0f, -1f, float.NaN, float.PositiveInfinity })
        {
            Rechaza<ArgumentException>(() => MYGReportesImpresion.SegmentarColumnas(new[] { 100f, invalida }, 300f), exige,
                "Un ancho de columna inválido debe producir un error claro antes de generar páginas.");
            Rechaza<ArgumentException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2 },
                new[] { 20f, invalida }, Array.Empty<(int, int)>(), 100f, 1), exige,
                "Una altura de fila inválida debe producir un error claro antes de paginar.");
            Rechaza<ArgumentException>(() => MYGReportesImpresion.SegmentarColumnas(new[] { 100f, 50f }, invalida), exige,
                "El ancho imprimible debe ser finito y positivo.");
            Rechaza<ArgumentException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2 },
                new[] { 20f, 20f }, Array.Empty<(int, int)>(), invalida, 1), exige,
                "El alto imprimible debe ser finito y positivo.");
        }
        Rechaza<InvalidOperationException>(() => MYGReportesImpresion.SegmentarColumnas(new[] { 288f, 700f }, 300f), exige,
            "Una columna que no cabe junto a la descripción debe informar el problema sin recortar datos ni generar segmentos sin avance.", "columna", "ancho");
        Rechaza<InvalidOperationException>(() => MYGReportesImpresion.SegmentarColumnas(new[] { 700f }, 300f), exige,
            "Una hoja con una sola columna demasiado ancha debe informar el problema y nunca desaparecer de la impresión.", "columna", "ancho");
        Rechaza<InvalidOperationException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2, 3 },
            new[] { 20f, 20f, 101f }, Array.Empty<(int, int)>(), 100f, 2), exige,
            "Una fila demasiado alta debe informar el problema sin generar páginas vacías ni un bucle.", "fila", "alto", "altura");
        Rechaza<InvalidOperationException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2, 3, 4, 5 },
            new[] { 20f, 20f, 30f, 30f, 30f }, new[] { (3, 5) }, 120f, 2), exige,
            "Un bloque combinado que no cabe con los títulos debe informar el problema y conservar el bloque completo.", "combin", "bloque", "fila");
        Rechaza<InvalidOperationException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2, 3, 4 },
            new[] { 10f, 10f, 10f, 10f }, new[] { (2, 3) }, 30f, 2), exige,
            "Una unión que cruza título y cuerpo debe rechazarse si necesita paginar, evitando dividir la celda combinada.", "combin", "título", "cabecera");
        Rechaza<ArgumentException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 3, 3 },
            new[] { 20f, 20f, 20f }, Array.Empty<(int, int)>(), 100f, 1), exige,
            "Una numeración de filas repetida debe rechazarse para no imprimir dos veces los mismos datos.");
        Rechaza<ArgumentException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2, 3 },
            new[] { 20f, 20f }, Array.Empty<(int, int)>(), 100f, 1), exige,
            "Las alturas deben corresponder una a una a las filas visibles.");
        Rechaza<ArgumentException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2, 3 },
            new[] { 20f, 20f, 20f }, new[] { (3, 2) }, 100f, 1), exige,
            "Un rango combinado invertido debe rechazarse antes de paginar.");
        Rechaza<ArgumentException>(() => MYGReportesImpresion.PaginarFilas(new[] { 1, 2, 3 },
            new[] { 20f, 20f, 20f }, Array.Empty<(int, int)>(), 100f, 4), exige,
            "La cantidad de títulos no puede exceder las filas visibles.");
    }

    private static void Rechaza<T>(Action accion, Action<bool, string> exige, string mensaje, params string[] contexto)
        where T : Exception
    {
        Exception error = null;
        try { accion(); }
        catch (Exception ex) { error = ex; }
        exige(error is T && !string.IsNullOrWhiteSpace(error.Message) &&
            (contexto.Length == 0 || contexto.Any(p => error.Message.Contains(p, StringComparison.OrdinalIgnoreCase))), mensaje);
    }
}
