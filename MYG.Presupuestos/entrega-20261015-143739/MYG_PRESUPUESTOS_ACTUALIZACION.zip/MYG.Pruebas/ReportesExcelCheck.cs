using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ReportesExcelCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        CabeceraYFormato(pasa);
        AreaYTexto(pasa);
        CabeceraIncrustada(pasa);
        ResumenYConsolidado(carpeta, pasa);
        ListadoMetrados(carpeta, pasa);
        ListadoMetradosGrande(carpeta, pasa);
        ReferenciasEntreInformes(carpeta, pasa);
    }

    private static void CabeceraYFormato(Action<string> pasa)
    {
        var h = new MYGHojaMetrado
        {
            Nombre = "Presupuesto", Filas = 7, Columnas = 4, AreaImpresion = "A1:D7", CeldaTotal = "D7",
            RangosCombinados = new() { "A1:D1", "A4:B4" }, FilasOcultas = new() { 5 },
            AnchosColumnas = new() { [1] = 85, [2] = 260, [3] = 75, [4] = 100 },
            AltosFilas = new() { [4] = 38 }, RangoCuerpoPlantilla = "A3:D6"
        };
        h.Poner("A1", "PRESUPUESTO DE OBRA"); h.Poner("A2", "Ítem");
        h.Poner("B3", "2"); h.Poner("C3", "3"); h.Poner("D3", "=B3*$C$3");
        h.Poner("A4", "Descripción combinada"); h.Poner("D7", "=SUM(D3:D6)");
        h.Celdas["D3"].ColorFondo = "ABCDEF"; h.Celdas["D3"].FormatoNumero = "0.00";
        var r = new MYGHojaReporteProyecto("Presupuesto · 01 QA", h, new[]
        {
            new KeyValuePair<string, string>("Proyecto", "Obra QA"), new("Presupuesto", "ARQUITECTURA"),
            new("Propietario", "Entidad QA"), new("Departamento", "ÁNCASH"), new("Provincia", "SANTA"),
            new("Distrito", "NUEVO CHIMBOTE"), new("Fecha de elaboración", "01/09/2026")
        }, presupuestoObra: true);
        string antes = JsonSerializer.Serialize(r);
        var copia = MYGReportesExcel.CrearHojas(new[] { r }).Single();
        int delta = r.CabeceraImpresion.Count + 3;
        var motor = new MYGHojaCalculo(copia);
        Exige(motor.Mostrar("A1") == "PRESUPUESTO DE OBRA" &&
            r.CabeceraImpresion.All(d => copia.Celdas.Values.Any(c => c.Contenido == d.Key + ":") &&
                copia.Celdas.Values.Any(c => c.Contenido == d.Value)), "Excel perdió el título o un dato visible de la cabecera institucional.");
        Exige(copia.Celdas["D" + (3 + delta)].Contenido == "=B" + (3 + delta) + "*$C$" + (3 + delta) &&
            motor.Numero("D" + (7 + delta)) == 6 && copia.CeldaTotal == "D" + (7 + delta),
            "Insertar cabecera debe ajustar también las referencias absolutas y la celda total.");
        Exige(copia.RangosCombinados.Contains("A" + (4 + delta) + ":B" + (4 + delta)) &&
            copia.RangoCuerpoPlantilla == "A" + (3 + delta) + ":D" + (6 + delta) &&
            copia.AreaImpresion == "A1:D" + (7 + delta) && copia.FilasOcultas.Contains(5 + delta) &&
            copia.FilasOcultas.Contains(1 + delta) && copia.AltosFilas[4 + delta] == 38 &&
            copia.AnchosColumnas.SequenceEqual(h.AnchosColumnas) && copia.Celdas["D" + (3 + delta)].ColorFondo == "ABCDEF" &&
            copia.Celdas["D" + (3 + delta)].FormatoNumero == "0.00", "Excel perdió dimensiones, combinaciones, área, ocultación del título duplicado o formato del cuerpo.");
        Exige(JsonSerializer.Serialize(r) == antes, "Materializar cabecera alteró el reporte original.");
        pasa("Excel incluye la cabecera institucional completa y conserva cálculos, referencias absolutas, rangos, dimensiones y formatos sin modificar el informe");
    }

    private static void AreaYTexto(Action<string> pasa)
    {
        var h = new MYGHojaMetrado { Filas = 6, Columnas = 4, CeldaTotal = "D6", AreaImpresion = "B2:D6", FilasInmovilizadas = 0 };
        h.Poner("D6", "4"); h.Poner("A1", "FUERA DEL ÁREA");
        var r = new MYGHojaReporteProyecto("Título QA", h, new[]
        {
            new KeyValuePair<string, string>("Proyecto", "=SUM(A1:A5)"), new("Presupuesto", "0012"),
            new("Propietario", "Primera línea\nSegunda línea")
        });
        var copia = MYGReportesExcel.CrearHojas(new[] { r }).Single();
        var motor = new MYGHojaCalculo(copia);
        Exige(copia.AreaImpresion == "B1:D12" && motor.Mostrar("C3") == "=SUM(A1:A5)" && motor.Mostrar("C4") == "0012" &&
            copia.Celdas["C3"].Contenido.StartsWith("=\"") && copia.AltosFilas[5] > 24 && copia.FilasInmovilizadas == 0,
            "La cabecera debe conservar el área por columnas, los metadatos literales, sus saltos de línea y la vista sin inmovilizar.");
        pasa("Excel conserva nombres que empiezan por =, códigos con ceros, metadatos multilínea y el área original por columnas");
    }

    private static void CabeceraIncrustada(Action<string> pasa)
    {
        var h = new MYGHojaMetrado { Filas = 2, Columnas = 2, CeldaTotal = "B2", FilasInmovilizadas = 0 };
        h.Poner("A1", "METRADOS"); h.Poner("B2", "7");
        var r = new MYGHojaReporteProyecto("METRADOS", h,
            new[] { new KeyValuePair<string, string>("Proyecto", "Obra") }, cabeceraEnHoja: true);
        var copia = MYGReportesExcel.CrearHojas(new[] { r }).Single();
        Exige(JsonSerializer.Serialize(copia) == JsonSerializer.Serialize(h) && !ReferenceEquals(copia, h),
            "Una hoja con cabecera materializada debe exportarse una sola vez y por copia.");
        copia.Celdas["A1"].Contenido = "Copia";
        Exige(h.Celdas["A1"].Contenido == "METRADOS", "La hoja incrustada debe quedar aislada del original.");
        pasa("Excel respeta las cabeceras ya materializadas y entrega una copia independiente sin duplicarlas");
    }

    private static void ResumenYConsolidado(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("PROYECTO EXPORTACION RESUMEN QA", "ESTRUCTURAS EXPORTADAS QA");
        doc.Datos = new MYGDatosProyecto { Propietario = "ENTIDAD EXPORTACION QA", Departamento = "ANCASH",
            Provincia = "SANTA", Distrito = "NUEVO CHIMBOTE", FechaElaboracion = new DateTime(2026, 10, 14),
            Portafolio = "PORTAFOLIO QUE NO DEBE MOSTRARSE QA" };
        var p = doc.Presupuestos[0];
        var otro = new MYGPresupuestoDocumento { Item = "02", Nombre = "ARQUITECTURA EXPORTADA QA", Posicion = 2 };
        void AgregarPartida(MYGPresupuestoDocumento presupuesto, decimal importe)
        {
            string id = MYGProyectoStorage.NuevoId();
            presupuesto.Items.Add(new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = "01", Posicion = 1,
                Descripcion = "PARTIDA EXPORTACION QA", Unidad = "und", TipoPropuesta = "PARTIDA",
                Costos = new MYGDatosPartida { Cantidad = 1, PrecioDirecto = importe } });
        }
        AgregarPartida(p, 7.25m); AgregarPartida(otro, 13m); doc.Presupuestos.Add(otro);
        string antes = JsonSerializer.Serialize(doc);
        var reportes = new[]
        {
            MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.HojaResumen).Single(),
            MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.ConsolidadoCostosUnitarios).Single()
        };
        string informesAntes = JsonSerializer.Serialize(reportes);
        var hojas = MYGReportesExcel.CrearHojas(reportes);
        for (int indice = 0; indice < reportes.Length; indice++)
        {
            var reporte = reportes[indice]; var hoja = hojas[indice]; var motor = new MYGHojaCalculo(hoja);
            string[] visibles = hoja.Celdas.Where(c => !hoja.FilasOcultas.Contains(MYGHojaCalculo.Coordenadas(c.Key).Fila))
                .Select(c => motor.Mostrar(c.Key)).ToArray();
            Exige(motor.Mostrar("A1") == reporte.TituloImpresion && visibles.Count(v => v == reporte.TituloImpresion) == 1 &&
                !visibles.Contains("PRESUPUESTO DE OBRA") && !visibles.Contains("PORTAFOLIO QUE NO DEBE MOSTRARSE QA") &&
                reporte.CabeceraImpresion.All(d => visibles.Contains(d.Key + ":") && visibles.Contains(d.Value)),
                "La exportación debe mostrar una sola vez el título propio del resumen/consolidado y los mismos datos generales compactos del presupuesto.");
            Exige(visibles.Contains("PRESUPUESTO:") == reporte.EsConsolidadoCostosUnitarios &&
                motor.Numero(hoja.CeldaTotal) == (indice == 0 ? 20.25m : 7.25m),
                "La cabecera global del resumen no debe identificar el presupuesto activo y sus importes deben incluir todos los presupuestos; el consolidado conserva su alcance seleccionado.");
        }
        string ruta = Path.Combine(carpeta, "Resumen y consolidado con formato presupuesto.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, reportes);
        var nombres = MYGExcelPresupuestos.Hojas(ruta);
        Exige(nombres.Length == 2, "La exportación conjunta debe conservar los informes de resumen y consolidado como dos hojas.");
        for (int indice = 0; indice < hojas.Count; indice++)
        {
            var original = hojas[indice];
            var reabierta = MYGExcelPresupuestos.Importar(ruta, nombres[indice], original.CeldaTotal);
            var motor = new MYGHojaCalculo(reabierta);
            Exige(motor.Numero(reabierta.CeldaTotal) == (indice == 0 ? 20.25m : 7.25m) &&
                reabierta.Celdas[original.CeldaTotal].FormatoNumero == "#,##0.00" &&
                reabierta.Celdas[original.CeldaTotal].AlineacionHorizontal == "Derecha" &&
                reabierta.AreaImpresion == original.AreaImpresion &&
                reabierta.RangosCombinados.SequenceEqual(original.RangosCombinados) &&
                motor.Mostrar("A1") == reportes[indice].TituloImpresion,
                "Guardar y reabrir el XLSX del resumen/consolidado debe conservar título, importes, formato del presupuesto, combinaciones y área de impresión.");
        }
        string rutaHtml = Path.Combine(carpeta, "Resumen y consolidado con formato presupuesto.html");
        MYGReportesExportacion.Guardar(rutaHtml, MYGFormatoExportacionReporte.Html, reportes);
        var secciones = XDocument.Load(rutaHtml).Descendants("section").ToArray();
        Exige(secciones.Length == reportes.Length && secciones.Select((seccion, i) =>
            seccion.Element("h1")?.Value == reportes[i].TituloImpresion &&
            !seccion.Descendants("td").Any(c => c.Value == reportes[i].TituloImpresion) &&
            seccion.Descendants("dt").Select(d => d.Value).SequenceEqual(reportes[i].CabeceraImpresion.Select(d => d.Key)) &&
            seccion.Descendants("dd").Select(d => d.Value).SequenceEqual(reportes[i].CabeceraImpresion.Select(d => d.Value))).All(v => v),
            "HTML debe conservar una sola cabecera con título propio y los mismos campos visibles del resumen y consolidado.");
        Exige(JsonSerializer.Serialize(doc) == antes && JsonSerializer.Serialize(reportes) == informesAntes,
            "Exportar resumen y consolidado no debe cambiar los datos ni los informes originales.");
        pasa("XLSX y HTML de resumen y consolidado conservan títulos propios, cabeceras compactas y alcance; XLSX reabre importes y formato del presupuesto");
    }

    private static void ListadoMetrados(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("PROYECTO EXPORTACION METRADOS QA", "PRESUPUESTO METRADOS EXPORTADO QA");
        doc.Datos = new MYGDatosProyecto { Propietario = "ENTIDAD METRADOS EXPORTADOS QA", Departamento = "ANCASH",
            Provincia = "SANTA", Distrito = "CHIMBOTE", FechaElaboracion = new DateTime(2026, 10, 15),
            Portafolio = "PORTAFOLIO FUERA DE METRADOS QA" };
        var p = doc.Presupuestos[0]; p.Item = "0007";
        ItemPresupuestoDelphin Agregar(string descripcion, string codigo, int posicion, bool titulo = false)
        {
            string id = MYGProyectoStorage.NuevoId();
            var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = codigo, Posicion = posicion,
                Descripcion = descripcion, Unidad = titulo ? "" : "m2", TipoPropuesta = titulo ? "TITULO" : "PARTIDA" };
            p.Items.Add(i); return i;
        }
        var titulo = Agregar("CAPITULO METRADOS EXPORTADOS QA", "0001", 1, true);
        var conCantidad = Agregar("PARTIDA CON METRADO EXPORTADO QA", "0001.01", 1);
        conCantidad.Costos.Cantidad = 9.25m; conCantidad.Costos.PrecioDirecto = 98765.43m;
        var cero = Agregar("PARTIDA CERO EXPORTADA QA", "0001.02", 2);
        cero.Costos.Cantidad = 0; cero.Costos.PrecioDirecto = 87654.32m;
        var excel = Agregar("=PARTIDA EXCEL EXPORTADA QA", "0001.03", 3);
        excel.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        excel.Costos.Hoja.Poner("B3", "2"); excel.Costos.Hoja.Poner("C3", "3");
        var bimCero = Agregar("PARTIDA BIM CERO EXPORTADA QA", "0001.04", 4);
        bimCero.Costos.FuenteMetrado = MYGFuenteMetrado.BIM; bimCero.Costos.Cantidad = 88;
        foreach (var partida in new[] { conCantidad, cero, excel, bimCero }) partida.ParentId = titulo.Id;
        var otro = new MYGPresupuestoDocumento { Item = "02", Nombre = "PRESUPUESTO EXCLUIDO DE METRADOS EXPORTADOS QA", Posicion = 2 };
        doc.Presupuestos.Add(otro);
        MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string antes = JsonSerializer.Serialize(doc);
        var reportes = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.Metrados);
        string informesAntes = JsonSerializer.Serialize(reportes);
        var reporte = reportes.Single(); var hoja = MYGReportesExcel.CrearHojas(reportes).Single();
        var motor = new MYGHojaCalculo(hoja);
        int Fila(string descripcion) => hoja.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == 2 && motor.Mostrar(c.Key) == descripcion)
            .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();
        string[] visibles = hoja.Celdas.Where(c => !hoja.FilasOcultas.Contains(MYGHojaCalculo.Coordenadas(c.Key).Fila))
            .Select(c => motor.Mostrar(c.Key)).ToArray();
        Exige(reporte.EsListadoMetrados && motor.Mostrar("A1") == "METRADOS" && visibles.Count(v => v == "METRADOS") == 1 &&
            reporte.CabeceraImpresion.All(d => visibles.Contains(d.Key + ":") && visibles.Contains(d.Value)) &&
            !visibles.Contains("PORTAFOLIO FUERA DE METRADOS QA") && !visibles.Contains(otro.Nombre) &&
            new[] { "Precio", "Total", "Costo directo", "Gastos generales", "Utilidad", "I.G.V.", "Otros impuestos" }.All(t => !visibles.Contains(t)),
            "Exportar el listado de metrados debe conservar el título propio y la cabecera compacta del presupuesto sin precios ni pie económico.");
        string ruta = Path.Combine(carpeta, "Listado de todos los metrados sin precios.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, reportes);
        string[] nombres = MYGExcelPresupuestos.Hojas(ruta);
        Exige(nombres.Length == 1, "El XLSX de metrados debe conservar todas las partidas del listado en una sola hoja.");
        var reabierta = MYGExcelPresupuestos.Importar(ruta, nombres[0], hoja.CeldaTotal);
        var motorReabierto = new MYGHojaCalculo(reabierta);
        foreach (var entrada in new[] { (Partida: conCantidad, Cantidad: 9.25m), (Partida: cero, Cantidad: 0m),
            (Partida: excel, Cantidad: 6m), (Partida: bimCero, Cantidad: 0m) })
        {
            int fila = Fila(entrada.Partida.Descripcion); string direccion = "D" + fila;
            Exige(motorReabierto.Mostrar("A" + fila) == p.Item + "." + entrada.Partida.Item &&
                motorReabierto.Mostrar("B" + fila) == entrada.Partida.Descripcion &&
                motorReabierto.Mostrar("C" + fila) == entrada.Partida.Unidad &&
                reabierta.Celdas.ContainsKey(direccion) && motorReabierto.Resultado(direccion).EsNumero &&
                motorReabierto.Numero(direccion) == entrada.Cantidad && motorReabierto.Mostrar(direccion) != "" &&
                reabierta.Celdas[direccion].FormatoNumero == "#,##0.00" &&
                reabierta.Celdas[direccion].AlineacionHorizontal == "Derecha" && !reabierta.FilasOcultas.Contains(fila),
                "Guardar y reabrir el listado de metrados debe conservar códigos literales, unidades y cantidades visibles incluso cero: " + entrada.Partida.Descripcion + ".");
        }
        Exige(reabierta.AreaImpresion == hoja.AreaImpresion && reabierta.RangosCombinados.SequenceEqual(hoja.RangosCombinados) &&
            reabierta.Celdas.Where(c => motorReabierto.Mostrar(c.Key) == "Cant.").All(c => c.Value.ColorFondo == "ECEEF1") &&
            motorReabierto.Mostrar("D" + Fila(titulo.Descripcion)) == "" &&
            reabierta.Celdas.Keys.All(d => MYGHojaCalculo.Coordenadas(d).Columna <= 4),
            "Reabrir el listado XLSX debe conservar área, títulos, encabezado gris, títulos sin metrado y sólo las cuatro columnas del presupuesto sin precios.");
        pasa("XLSX de metrados reúne todas las partidas con formato de presupuesto sin precios y reabre cantidades, ceros visibles, códigos, descripciones literales y unidades");

        string rutaHtml = Path.Combine(carpeta, "Listado de todos los metrados sin precios.html");
        MYGReportesExportacion.Guardar(rutaHtml, MYGFormatoExportacionReporte.Html, reportes);
        var seccion = XDocument.Load(rutaHtml).Descendants("section").Single();
        Exige(seccion.Element("h1")?.Value == "METRADOS" &&
            !seccion.Descendants("td").Any(c => c.Value == "METRADOS") &&
            seccion.Descendants("dt").Select(d => d.Value).SequenceEqual(reporte.CabeceraImpresion.Select(d => d.Key)) &&
            seccion.Descendants("dd").Select(d => d.Value).SequenceEqual(reporte.CabeceraImpresion.Select(d => d.Value)) &&
            seccion.Descendants("col").Count() == 4,
            "HTML debe mostrar una sola cabecera compacta y las cuatro columnas del listado de metrados, sin duplicar el título.");
        foreach (var partida in new[] { conCantidad, cero, excel, bimCero })
        {
            var celdas = seccion.Descendants("tr").Single(f => f.Elements("td").Any(c => c.Value == partida.Descripcion))
                .Elements("td").ToArray();
            Exige(celdas.Length == 4 && celdas[0].Value == p.Item + "." + partida.Item &&
                celdas[2].Value == partida.Unidad && celdas[3].Value == motor.Mostrar("D" + Fila(partida.Descripcion)) &&
                celdas[3].Value != "",
                "HTML debe incluir la cantidad de cada partida, incluidos los ceros de cualquier fuente, con su código y unidad.");
        }
        Exige(new[] { "Precio", "Total", "Costo directo", "Gastos generales", "Utilidad", "I.G.V.", "Otros impuestos" }
                .All(t => !seccion.Descendants("td").Any(c => c.Value == t)) &&
            JsonSerializer.Serialize(doc) == antes && JsonSerializer.Serialize(reportes) == informesAntes,
            "Exportar el listado HTML/XLSX no debe agregar columnas económicas ni alterar el proyecto o los informes originales.");
        pasa("HTML de metrados comparte la cabecera y formato del presupuesto, lista todas las partidas y conserva ceros sin precios ni cambios en los originales");
    }

    private static void ListadoMetradosGrande(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("METRADOS GRANDES QA", "LISTADO GRANDE QA");
        var p = doc.Presupuestos[0];
        const int cantidad = 9990;
        var esperadas = new List<string>(cantidad);
        for (int numero = 1; numero <= cantidad; numero++)
        {
            string codigo = numero.ToString("00000"), descripcion = "M" + codigo;
            string id = MYGProyectoStorage.NuevoId();
            var hojaMinima = new MYGHojaMetrado { Filas = 1, Columnas = 1, CeldaTotal = "A1", AreaImpresion = "A1", FilasInmovilizadas = 0 };
            hojaMinima.Poner("A1", "0");
            p.Items.Add(new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = codigo,
                Posicion = numero, Descripcion = descripcion, Unidad = "und", TipoPropuesta = "PARTIDA",
                Costos = new MYGDatosPartida { Cantidad = 0, Hoja = hojaMinima } });
            esperadas.Add(descripcion);
        }
        var reportes = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.Metrados);
        Exige(reportes.Count == 2 && reportes.All(r => r.EsListadoMetrados),
            "Un listado de 9.990 partidas debe dividirse antes de que la cabecera de exportación exceda el límite de filas.");
        var hojas = MYGReportesExcel.CrearHojas(reportes);
        Exige(hojas.Count == 2 && hojas.All(h => h.Filas <= 10000 && h.Celdas.Keys.All(d => MYGHojaCalculo.Coordenadas(d).Fila <= 10000)),
            "Materializar la cabecera compacta de todas las partes del listado debe respetar el límite de 10.000 filas.");
        string ruta = Path.Combine(carpeta, "Listado grande de metrados con ceros.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        Exige(MYGExcelPresupuestos.Hojas(ruta).Length == 2,
            "El XLSX del listado grande debe conservar sus dos partes sin perder una hoja al guardar.");
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        var exportadas = new List<string>(cantidad);
        using var zip = ZipFile.OpenRead(ruta);
        for (int indice = 1; indice <= hojas.Count; indice++)
        {
            using var entrada = (zip.GetEntry("xl/worksheets/sheet" + indice + ".xml") ??
                throw new Exception("Falta la parte " + indice + " del listado de metrados.")).Open();
            var xml = XDocument.Load(entrada);
            foreach (var fila in xml.Descendants(ns + "row"))
            {
                Exige(int.Parse((string)fila.Attribute("r")) <= 10000,
                    "El XLSX guardado no debe contener direcciones de fila que excedan el límite del modelo.");
                var celdas = fila.Elements(ns + "c").ToArray();
                var descripcion = celdas.SingleOrDefault(c => ((string)c.Attribute("r"))?.StartsWith("B", StringComparison.Ordinal) == true);
                string texto = descripcion == null ? "" : string.Concat(descripcion.Descendants(ns + "t").Select(t => t.Value));
                if (!texto.StartsWith("M", StringComparison.Ordinal) || texto.Length != 6 || !texto.Skip(1).All(char.IsDigit)) continue;
                var celdaCantidad = celdas.SingleOrDefault(c => ((string)c.Attribute("r"))?.StartsWith("D", StringComparison.Ordinal) == true);
                Exige(celdaCantidad?.Element(ns + "v")?.Value == "0" &&
                    (string)celdaCantidad.Attribute("t") != "inlineStr" &&
                    (string)fila.Attribute("hidden") is not ("1" or "true"),
                    "Cada partida del listado grande debe guardar su metrado cero como número visible en el XLSX.");
                exportadas.Add(texto);
            }
        }
        Exige(exportadas.SequenceEqual(esperadas) && exportadas.Distinct(StringComparer.Ordinal).Count() == cantidad,
            "Exportar y reabrir el XLSX grande debe conservar las 9.990 partidas una sola vez, en orden y con sus ceros.");
        pasa("Listado de 9.990 metrados se divide en dos hojas compatibles con la cabecera XLSX y conserva todas las partidas una vez con cero numérico visible");
    }

    private static void ReferenciasEntreInformes(string carpeta, Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "Presupuesto QA", Item = "01" };
        ItemPresupuestoDelphin Partida(string codigo)
        {
            string id = MYGProyectoStorage.NuevoId();
            return new() { Id = id, IdLocalMYG = id, Item = codigo, TipoPropuesta = "PARTIDA", Descripcion = codigo, Unidad = "und" };
        }
        var a = Partida("01.01"); var b = Partida("01.02");
        p.Items.AddRange(new[] { a, b }); MYGReferenciasMetrado.Vincular(new[] { p });
        b.Costos.Hoja.Poner("B3", "7");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3") + "*2");
        var reportes = new[]
        {
            new MYGHojaReporteProyecto("Destino", a.Costos.Hoja, new[] { new KeyValuePair<string, string>("Proyecto", "Obra") }),
            new MYGHojaReporteProyecto("Origen", b.Costos.Hoja, new[] { new KeyValuePair<string, string>("Proyecto", "Obra"), new("Presupuesto", "QA") })
        };
        string antes = JsonSerializer.Serialize(p);
        string ruta = Path.Combine(carpeta, "Reportes con cabeceras y vinculos.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, reportes);
        using var zip = ZipFile.OpenRead(ruta);
        using var entrada = zip.GetEntry("xl/worksheets/sheet1.xml").Open();
        var xml = XDocument.Load(entrada); XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        var celda = xml.Descendants(ns + "c").Single(c => (string)c.Attribute("r") == "B7");
        Exige(celda.Element(ns + "f")?.Value.EndsWith("!B8*2", StringComparison.Ordinal) == true &&
            celda.Element(ns + "v")?.Value == "14" && JsonSerializer.Serialize(p) == antes,
            "Excel debe reubicar los vínculos METRADO según la cabecera de su origen y calcular las copias sin tocar el proyecto.");
        pasa("Excel reubica vínculos entre informes con cabeceras de distinta altura y conserva su fórmula nativa y valor calculado");
    }
}
