using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ReporteMetradosExcelCheck
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static ItemPresupuestoDelphin Nodo(string codigo, string nombre, int posicion, string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = codigo, Descripcion = nombre,
            Posicion = posicion, ParentId = padre, TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Unidad = titulo ? "" : "m2" };
    }
    private static int Fila(MYGHojaMetrado h, string texto)
    {
        var calculo = new MYGHojaCalculo(h);
        return h.Celdas.Where(c => calculo.Mostrar(c.Key) == texto).Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();
    }
    private static bool Contiene(MYGHojaMetrado h, string texto)
    {
        var calculo = new MYGHojaCalculo(h);
        return h.Celdas.Any(c => calculo.Mostrar(c.Key).Contains(texto, StringComparison.Ordinal));
    }
    private static string Columna(MYGHojaMetrado consolidada, MYGHojaMetrado origen, int columna)
    {
        int limite = Enumerable.Range(1, columna - 1).Sum(c => origen.AnchosColumnas.GetValueOrDefault(c,
            c == 1 ? 288 : c == 8 ? 110 : c is 2 or 3 ? 60 : c == 7 ? 95 : 68));
        limite = (int)Math.Round(limite / 8d, MidpointRounding.AwayFromZero) * 8;
        int ancho = 0;
        for (int c = 1; c <= consolidada.Columnas; c++)
        {
            if (ancho == limite) return MYGHojaCalculo.Columna(c);
            ancho += consolidada.AnchosColumnas[c];
        }
        throw new Exception("No se encontró el límite de columna de la partida.");
    }
    private static (MYGProyectoDocumento Doc, MYGPresupuestoDocumento P, ItemPresupuestoDelphin A,
        ItemPresupuestoDelphin B, MYGPresupuestoDocumento Otro, ItemPresupuestoDelphin C) Proyecto()
    {
        var d = MYGProyectoStorage.Nuevo("PROYECTO CONSOLIDADO QA", "ARQUITECTURA QA");
        d.Datos = MYGDatosProyecto.Crear(); d.Datos.Propietario = "PROPIETARIO QA";
        d.Datos.Departamento = "ÁNCASH"; d.Datos.Provincia = "SANTA"; d.Datos.Distrito = "NUEVO CHIMBOTE";
        d.Datos.FechaElaboracion = new DateTime(2026, 9, 1);
        var p = d.Presupuestos.Single();
        var t = Nodo("01", "TITULO PADRE QA", 1, titulo: true);
        var s = Nodo("01.01", "SUBTITULO QA", 1, t.Id, titulo: true);
        var a = Nodo("01.01.01", "PARTIDA ESTANDAR QA", 1, s.Id);
        var b = Nodo("01.01.02", "PARTIDA ACEROS QA", 2, s.Id);
        var manual = Nodo("02", "PARTIDA MANUAL NO VISIBLE QA", 2);
        a.Costos.FuenteMetrado = b.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        manual.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        b.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        a.Costos.Hoja.Poner("A3", "FILA ESTANDAR QA"); a.Costos.Hoja.Poner("B3", "2"); a.Costos.Hoja.Poner("C3", "3");
        b.Costos.Hoja.Poner("A3", "FILA ACEROS QA"); b.Costos.Hoja.Poner("B3", "2"); b.Costos.Hoja.Poner("C3", "3");
        b.Costos.Hoja.Poner("D3", "4mm"); b.Costos.Hoja.Poner("E3", "5");
        p.Items.AddRange(new[] { b, manual, s, a, t });
        var otro = new MYGPresupuestoDocumento { Item = "02", Nombre = "ESTRUCTURAS QA", Posicion = 2 };
        var c = Nodo("01", "PARTIDA OTRO PRESUPUESTO QA", 1); c.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        c.Costos.Hoja.Poner("A3", "FILA OTRO PRESUPUESTO QA"); c.Costos.Hoja.Poner("B3", "7");
        otro.Items.Add(c); d.Presupuestos.Add(otro);
        MYGReferenciasMetrado.Vincular(d.Presupuestos);
        return (d, p, a, b, otro, c);
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        CabeceraYJerarquia(pasa);
        FormulasYAnchos(carpeta, pasa);
        ReferenciasEntrePresupuestos(carpeta, pasa);
        FiltrosYVacios(pasa);
        ErroresYTipos(pasa);
        CongelacionDeDependientes(pasa);
        TextosExtensos(pasa);
        FilasVaciasCompactas(carpeta, pasa);
        DatosCeroYPersonalizados(pasa);
        ReferenciasAFilasOcultas(pasa);
        EstructuraMetradosCompacta(pasa);
    }

    private static void CabeceraYJerarquia(Action<string> pasa)
    {
        var (d, p, a, _, _, _) = Proyecto();
        string antes = JsonSerializer.Serialize(d);
        var r = MYGReporteMetradosExcel.Crear(d, p.Id); var h = r.Hoja;
        Exige(r.CabeceraEnHoja && Fila(h, "METRADOS") == 1 && Contiene(h, d.Nombre) &&
            new MYGHojaCalculo(h).Mostrar("A3") == "PRESUPUESTO :" && Contiene(h, p.ToString()) &&
            Contiene(h, "PROPIETARIO QA") && Contiene(h, "ÁNCASH") && Contiene(h, "01/09/2026"),
            "La hoja debe contener título, proyecto, propietario, ubicación y fecha antes de los metrados.");
        Exige(Fila(h, p.Item + "  " + p.Nombre) == 12 &&
            Fila(h, p.Item + "  " + p.Nombre) < Fila(h, "01  TITULO PADRE QA") &&
            Fila(h, "01  TITULO PADRE QA") < Fila(h, "01.01  SUBTITULO QA") &&
            Fila(h, "01.01  SUBTITULO QA") < Fila(h, "FILA ESTANDAR QA") &&
            Fila(h, "FILA ESTANDAR QA") < Fila(h, "FILA ACEROS QA") &&
            Fila(h, "01.01.01.01  PARTIDA ESTANDAR QA  [m2]") < Fila(h, "FILA ESTANDAR QA") &&
            !Contiene(h, "PRESUPUESTO:") && !Contiene(h, "PARTIDA:") &&
            !Contiene(h, "PARTIDA MANUAL NO VISIBLE QA") && !Contiene(h, "FILA OTRO PRESUPUESTO QA"),
            "El consolidado debe ordenar presupuesto, títulos y partidas Excel por jerarquía, mostrar ítem y descripción separados por espacios sin prefijos y excluir fuentes manuales y otros presupuestos.");
        Exige(r.NivelesTitulos[Fila(h, p.Item + "  " + p.Nombre)] == 0 &&
            r.NivelesTitulos[Fila(h, "01.01  SUBTITULO QA")] == 2 && JsonSerializer.Serialize(d) == antes,
            "La jerarquía debe registrarse por ParentId sin modificar el proyecto original.");
        a.Costos.Hoja.Poner("A3", "EDITADO DESPUES");
        Exige(Contiene(h, "FILA ESTANDAR QA") && !Contiene(h, "EDITADO DESPUES"), "La vista consolidada debe permanecer aislada de ediciones posteriores.");
        pasa("Metrados Excel presenta cabecera completa, presupuesto, títulos jerárquicos y partidas activas en una copia independiente");
    }

    private static void FormulasYAnchos(string carpeta, Action<string> pasa)
    {
        var (d, p, a, b, _, _) = Proyecto();
        a.Costos.Hoja.Poner("D3", "=$B$3+C$3+$C3");
        a.Costos.Hoja.Poner("H3", "=\"A1 y METRADO(\"\"literal\"\";\"\"B3\"\")\"");
        a.Costos.Hoja.Celdas["A3"].ColorFondo = "F0E1D2";
        a.Costos.Hoja.Celdas["A3"].Cursiva = true; a.Costos.Hoja.Celdas["A3"].TamanoFuente = 11;
        a.Costos.Hoja.FilasOcultas.Add(4); a.Costos.Hoja.AltosFilas[3] = 37;
        var r = MYGReporteMetradosExcel.Crear(d, p.Id); var h = r.Hoja;
        int f = Fila(h, "FILA ESTANDAR QA"), g = Fila(h, "FILA ACEROS QA");
        string bCol = Columna(h, a.Costos.Hoja, 2), cCol = Columna(h, a.Costos.Hoja, 3), dCol = Columna(h, a.Costos.Hoja, 4);
        Exige(h.Celdas[dCol + f].Contenido == "=$" + bCol + "$" + f + "+" + cCol + "$" + f + "+$" + cCol + f &&
            new MYGHojaCalculo(h).Numero(dCol + f) == 8 &&
            new MYGHojaCalculo(h).Numero(Columna(h, b.Costos.Hoja, 30) + (g + 13)) == 2.97m,
            "Las fórmulas relativas y absolutas estándar y de aceros deben apuntar al bloque reubicado y conservar resultados.");
        Exige(h.Celdas["A" + f].Cursiva && h.Celdas["A" + f].ColorFondo == "F0E1D2" &&
            h.Celdas["A" + f].TamanoFuente == 11 && h.FilasOcultas.Contains(f + 1) && h.AltosFilas[f] == 37,
            "El consolidado debe conservar fuentes, fondos, alturas y filas ocultas de las hojas originales.");
        int anchoA = h.AnchosColumnas.Where(c => c.Key < MYGHojaCalculo.Coordenadas(bCol + "1").Columna).Sum(c => c.Value);
        Exige(anchoA == a.Costos.Hoja.AnchosColumnas[1] && Contiene(h, "A1 y METRADO(\"literal\";\"B3\")"),
            "Los anchos deben conservarse mediante combinaciones sin modificar texto que parezca una referencia.");
        string ruta = Path.Combine(carpeta, "Metrados consolidados con formatos.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { h });
        var reabierta = MYGExcelPresupuestos.Importar(ruta, "Metrados", h.CeldaTotal);
        using var zip = ZipFile.OpenRead(ruta);
        using var entrada = zip.GetEntry("xl/worksheets/sheet1.xml").Open(); var xml = XDocument.Load(entrada);
        Exige(MYGExcelPresupuestos.Hojas(ruta).Length == 1 && xml.Descendants(S + "mergeCell").Any() &&
            Fila(reabierta, p.Item + "  " + p.Nombre) == 12 &&
            Contiene(reabierta, "01.01.01.01  PARTIDA ESTANDAR QA  [m2]") &&
            !Contiene(reabierta, "PRESUPUESTO:") && !Contiene(reabierta, "PARTIDA:") &&
            new MYGHojaCalculo(reabierta).Mostrar("A3") == "PRESUPUESTO :" &&
            xml.Descendants(S + "c").Single(c => (string)c.Attribute("r") == dCol + f).Element(S + "f") != null,
            "El archivo Excel debe contener exactamente una hoja con celdas combinadas, fórmulas y las mismas bandas sin prefijos que la vista, conservando la etiqueta superior de presupuesto.");
        pasa("Metrados consolida plantillas estándar y aceros conservando fórmulas absolutas/relativas, estilos, anchos, combinaciones y XLSX de una hoja");
    }

    private static void ReferenciasEntrePresupuestos(string carpeta, Action<string> pasa)
    {
        var (d, p, a, _, otro, c) = Proyecto();
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, otro, c, "B3") + "+1");
        string antes = JsonSerializer.Serialize(d);
        var h = MYGReporteMetradosExcel.Crear(d, p.Id, todosPresupuestos: true).Hoja;
        int f = Fila(h, "FILA ESTANDAR QA"), g = Fila(h, "FILA OTRO PRESUPUESTO QA");
        string destino = Columna(h, a.Costos.Hoja, 2) + f, origen = Columna(h, c.Costos.Hoja, 2) + g;
        Exige(h.Celdas[destino].Contenido == "=" + origen + "+1" && new MYGHojaCalculo(h).Numero(destino) == 8 &&
            Contiene(h, otro.Item + "  " + otro.Nombre),
            "Los vínculos entre presupuestos incluidos deben convertirse en referencias de la misma hoja.");
        h.Poner(origen, "9");
        Exige(new MYGHojaCalculo(h).Numero(destino) == 10, "Los vínculos incluidos deben seguir calculando al cambiar el origen en la copia consolidada.");
        var seleccionado = MYGReporteMetradosExcel.Crear(d, p.Id).Hoja;
        string aislada = Columna(seleccionado, a.Costos.Hoja, 2) + Fila(seleccionado, "FILA ESTANDAR QA");
        Exige(new MYGHojaCalculo(seleccionado).Numero(aislada) == 8 && seleccionado.Celdas[aislada].Contenido == "8" &&
            !Contiene(seleccionado, "FILA OTRO PRESUPUESTO QA") && JsonSerializer.Serialize(d) == antes,
            "Las dependencias fuera de la selección deben materializar su valor sin añadir hojas ni modificar datos.");
        string ruta = Path.Combine(carpeta, "Metrados consolidados entre presupuestos.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { h });
        Exige(MYGExcelPresupuestos.Hojas(ruta).Length == 1, "Los vínculos entre presupuestos no deben producir hojas de soporte adicionales.");
        pasa("Metrados mantiene vínculos recalculables entre presupuestos de la hoja única y congela dependencias fuera de la selección sin mutar el proyecto");
    }

    private static void FiltrosYVacios(Action<string> pasa)
    {
        var (d, p, a, _, _, _) = Proyecto();
        var importada = Nodo("03", "PARTIDA IMPORTADA QA", 3);
        importada.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        importada.Costos.Hoja = new MYGHojaMetrado { Nombre = "Importada", Filas = 5, Columnas = 3, CeldaTotal = "C3" };
        importada.Costos.Hoja.Poner("A3", "CONTENIDO IMPORTADO QA"); importada.Costos.Hoja.Poner("C3", "12");
        p.Items.Add(importada);
        var estandar = MYGReporteMetradosExcel.Crear(d, p.Id, MYGPlantillasMetrado.Estandar).Hoja;
        var aceros = MYGReporteMetradosExcel.Crear(d, p.Id, MYGPlantillasMetrado.Aceros).Hoja;
        var otras = MYGReporteMetradosExcel.Crear(d, p.Id, "").Hoja;
        Exige(Contiene(estandar, "FILA ESTANDAR QA") && !Contiene(estandar, "FILA ACEROS QA") &&
            Contiene(aceros, "FILA ACEROS QA") && !Contiene(aceros, "FILA ESTANDAR QA") &&
            Contiene(otras, "CONTENIDO IMPORTADO QA") && !Contiene(otras, a.Descripcion) &&
            Enumerable.Range(Fila(otras, "CONTENIDO IMPORTADO QA") - 2, 3).All(f => !otras.FilasOcultas.Contains(f)),
            "Los filtros deben seleccionar estándar, aceros e importadas sin perder la cabecera, compactar filas importadas ni añadir otras partidas.");
        foreach (var i in p.Items) i.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        Exige(Contiene(MYGReporteMetradosExcel.Crear(d, p.Id).Hoja, "No hay partidas con metrados Excel"),
            "Una selección sin metrados debe producir una hoja informativa y válida.");
        pasa("Metrados filtra plantillas estándar, aceros e importadas y presenta correctamente una selección vacía");
    }

    private static void ErroresYTipos(Action<string> pasa)
    {
        var (d, p, a, _, otro, c) = Proyecto();
        c.Costos.Hoja.Poner("B3", "=TRUE"); c.Costos.Hoja.Poner("C3", "TEXTO QA");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, otro, c, "B3"));
        a.Costos.Hoja.Poner("C3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, otro, c, "C3"));
        a.Costos.Hoja.Poner("D3", "=1/0"); a.Costos.Hoja.Poner("E3", "=METRADO(\"desconocido\";\"B3\")");
        // El proyecto exige que el total seleccionado sea calculable; los
        // errores a comprobar pertenecen a otras celdas de la hoja.
        a.Costos.Hoja.Poner("H16", "0"); a.Costos.Hoja.CeldaTotal = "H16";
        var h = MYGReporteMetradosExcel.Crear(d, p.Id).Hoja; int f = Fila(h, "FILA ESTANDAR QA");
        var calculo = new MYGHojaCalculo(h);
        Exige(h.Celdas[Columna(h, a.Costos.Hoja, 2) + f].Contenido == "=TRUE" &&
            calculo.Mostrar(Columna(h, a.Costos.Hoja, 3) + f) == "TEXTO QA" &&
            calculo.Mostrar(Columna(h, a.Costos.Hoja, 4) + f) == "#ERROR" &&
            h.Celdas[Columna(h, a.Costos.Hoja, 5) + f].Contenido == "=#REF!",
            "La consolidación debe conservar resultados lógicos, textos y errores sin sustituirlos por cero ni abortar toda la exportación.");
        pasa("Metrados conserva texto, valores lógicos y errores de las fórmulas, incluidas dependencias que quedan fuera del filtro");
    }

    private static void CongelacionDeDependientes(Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("CONGELACIÓN QA"); var p = d.Presupuestos.Single();
        var a = Nodo("01", "REJILLA DIFERENTE QA", 1); a.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        a.Costos.Hoja = new MYGHojaMetrado { Filas = 1, Columnas = 4, CeldaTotal = "D1",
            AnchosColumnas = new() { [1] = 100, [2] = 100, [3] = 100, [4] = 100 }, FilasInmovilizadas = 0 };
        a.Costos.Hoja.Poner("A1", "=COUNTBLANK(B1:C1)");
        a.Costos.Hoja.Poner("D1", "=IF(A1=2,COUNTBLANK(B1:C1),2)"); p.Items.Add(a);
        var h = MYGReporteMetradosExcel.Crear(d, p.Id).Hoja;
        int inicio = Fila(h, "01.01  REJILLA DIFERENTE QA  [m2]") + 1;
        Exige(new MYGHojaCalculo(h).Numero("A" + inicio) == 2 &&
            new MYGHojaCalculo(h).Numero(Columna(h, a.Costos.Hoja, 4) + inicio) == 2,
            "Congelar fórmulas sensibles a la rejilla debe recalcular sus dependientes hasta conservar todos los valores originales.");
        pasa("Metrados estabiliza resultados dependientes al congelar fórmulas afectadas por la rejilla común");
    }

    private static void TextosExtensos(Action<string> pasa)
    {
        var (d, p, a, _, _, _) = Proyecto();
        d.Nombre = "PROYECTO PRIMERA LÍNEA\nSEGUNDA LÍNEA\nTERCERA LÍNEA\nCUARTA LÍNEA\nQUINTA LÍNEA";
        a.Descripcion = "PARTIDA PRIMERA LÍNEA\nSEGUNDA LÍNEA\nTERCERA LÍNEA\nCUARTA LÍNEA";
        var h = MYGReporteMetradosExcel.Crear(d, p.Id).Hoja;
        int partida = Fila(h, "01.01.01.01  " + a.Descripcion + "  [m2]");
        Exige(h.AltosFilas[2] >= 78 && h.AltosFilas[partida] >= 63,
            "Las cabeceras y nombres de partida con varias líneas deben tener altura explícita suficiente en las celdas combinadas exportadas.");
        pasa("Metrados ajusta alturas de cabeceras y nombres de partidas extensos para conservar sus líneas en Excel");
    }

    private static void FilasVaciasCompactas(string carpeta, Action<string> pasa)
    {
        var (d, p, a, b, _, _) = Proyecto();
        // Una fila de metrado válida no necesita descripción para conservarse.
        a.Costos.Hoja.Poner("B4", "1"); a.Costos.Hoja.Poner("C4", "2");
        string antes = JsonSerializer.Serialize(d);
        var h = MYGReporteMetradosExcel.Crear(d, p.Id).Hoja;
        int f = Fila(h, "FILA ESTANDAR QA"), g = Fila(h, "FILA ACEROS QA");
        int[] ocultas = Enumerable.Range(f + 2, 11).Concat(Enumerable.Range(g + 1, 10)).ToArray();
        Exige(h.FilasOcultas.OrderBy(x => x).SequenceEqual(ocultas.OrderBy(x => x)) &&
            !h.FilasOcultas.Contains(f) && !h.FilasOcultas.Contains(f + 1) && !h.FilasOcultas.Contains(g),
            "La vista debe ocultar las filas de relleno estándar y de aceros, conservando todas las filas con metrados aunque no tengan descripción.");
        Exige(new[] { 1, 12, f - 3, f - 2, f - 1, f + 13, g - 3, g - 2, g - 1, g + 11, g + 12, g + 13 }
                .All(fila => !h.FilasOcultas.Contains(fila)) &&
            new MYGHojaCalculo(h).Numero(Columna(h, a.Costos.Hoja, 7) + (f + 13)) == 8 &&
            new MYGHojaCalculo(h).Numero(Columna(h, b.Costos.Hoja, 30) + (g + 13)) == 2.97m &&
            JsonSerializer.Serialize(d) == antes && a.Costos.Hoja.FilasOcultas.Count == 0 && b.Costos.Hoja.FilasOcultas.Count == 0,
            "Compactar debe conservar títulos, cabeceras y totales, sin modificar ninguna hoja editable ni sus importes.");
        string ruta = Path.Combine(carpeta, "Metrados compactos sin filas de relleno.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { h });
        var reabierta = MYGExcelPresupuestos.Importar(ruta, "Metrados", h.CeldaTotal);
        using var zip = ZipFile.OpenRead(ruta);
        using var entrada = zip.GetEntry("xl/worksheets/sheet1.xml").Open(); var xml = XDocument.Load(entrada);
        Exige(reabierta.FilasOcultas.OrderBy(x => x).SequenceEqual(ocultas.OrderBy(x => x)) &&
            xml.Descendants(S + "row").Where(r => (string)r.Attribute("hidden") == "1")
                .Select(r => (int)r.Attribute("r")).OrderBy(x => x).SequenceEqual(ocultas.OrderBy(x => x)) &&
            new MYGHojaCalculo(reabierta).Numero(Columna(h, a.Costos.Hoja, 7) + (f + 13)) == 8 &&
            reabierta.Celdas[Columna(h, a.Costos.Hoja, 7) + (f + 2)].Contenido.StartsWith('=') &&
            JsonSerializer.Serialize(d) == antes,
            "Guardar y reabrir XLSX debe conservar la ocultación de las filas vacías y sus fórmulas, manteniendo los totales y el proyecto original.");
        pasa("Metrados compacta estándar y aceros en la vista y XLSX sin alterar filas útiles, totales ni las plantillas editables");

        var antiguo = MYGProyectoStorage.Copia(d);
        var hojaAntigua = antiguo.Presupuestos.Single(x => x.Id == p.Id).Items.Single(x => x.Id == a.Id).Costos.Hoja;
        hojaAntigua.IdPlantilla = ""; hojaAntigua.RangoCuerpoPlantilla = null;
        string antesAntiguo = JsonSerializer.Serialize(antiguo);
        var vistaAntigua = MYGReporteMetradosExcel.Crear(antiguo, p.Id).Hoja;
        Exige(vistaAntigua.FilasOcultas.OrderBy(x => x).SequenceEqual(ocultas.OrderBy(x => x)) &&
            JsonSerializer.Serialize(antiguo) == antesAntiguo,
            "Las hojas estándar antiguas reconocidas por sus cabeceras deben compactarse sin migrar su identidad ni modificar el proyecto.");
        hojaAntigua.RangoCuerpoPlantilla = "";
        string sinCuerpo = JsonSerializer.Serialize(antiguo);
        var vistaSinCuerpo = MYGReporteMetradosExcel.Crear(antiguo, p.Id).Hoja;
        Exige(Enumerable.Range(f, 13).All(fila => !vistaSinCuerpo.FilasOcultas.Contains(fila)) &&
            JsonSerializer.Serialize(antiguo) == sinCuerpo,
            "Un cuerpo eliminado explícitamente debe conservar su distribución sin inferir ni ocultar filas del diseño restante.");
        pasa("Metrados compacta plantillas estándar antiguas sin migrarlas y respeta un cuerpo eliminado explícitamente");
    }

    private static void DatosCeroYPersonalizados(Action<string> pasa)
    {
        var (d, p, a, b, _, _) = Proyecto();
        a.Costos.Hoja.Poner("B4", "0");
        a.Costos.Hoja.Poner("A5", "NOTA SIN CANTIDAD QA");
        a.Costos.Hoja.Poner("H6", "PLANO SIN MEDIDA QA");
        a.Costos.Hoja.Poner("G7", "=1-1");
        a.Costos.Hoja.Poner("B9", "=0");
        a.Costos.Hoja.Poner("B10", "=\"\"");
        b.Costos.Hoja.Poner("D4", "4mm");
        b.Costos.Hoja.Poner("AD5", "REFERENCIA ACERO QA");
        b.Costos.Hoja.Poner("I6", "=1-1");
        b.Costos.Hoja.Poner("B7", "0");
        b.Costos.Hoja.Poner("A8", "NOTA ACERO QA");
        string antes = JsonSerializer.Serialize(d);
        var h = MYGReporteMetradosExcel.Crear(d, p.Id).Hoja;
        int f = Fila(h, "FILA ESTANDAR QA"), g = Fila(h, "FILA ACEROS QA");
        Exige(new[] { f + 1, f + 2, f + 3, f + 4, f + 6, f + 7 }.All(fila => !h.FilasOcultas.Contains(fila)) &&
            Enumerable.Range(g + 1, 5).All(fila => !h.FilasOcultas.Contains(fila)) &&
            h.FilasOcultas.Contains(f + 5) && h.FilasOcultas.Contains(g + 6),
            "Un cero introducido, una descripción, una referencia, un diámetro o una fórmula propia deben mantener visible la fila aunque su parcial sea cero.");
        Exige(h.Celdas[Columna(h, a.Costos.Hoja, 7) + (f + 4)].Contenido == "=1-1" &&
            h.Celdas[Columna(h, a.Costos.Hoja, 2) + (f + 6)].Contenido == "=0" &&
            h.Celdas[Columna(h, b.Costos.Hoja, 9) + (g + 3)].Contenido == "=1-1" &&
            JsonSerializer.Serialize(d) == antes,
            "Compactar no debe borrar ni sustituir las fórmulas personalizadas que dan cero ni modificar las hojas originales.");
        pasa("Metrados conserva visibles ceros introducidos, notas, referencias y fórmulas propias con resultado cero");
    }

    private static void ReferenciasAFilasOcultas(Action<string> pasa)
    {
        var (d, p, a, _, _, c) = Proyecto();
        a.Costos.Hoja.Poner("B3", "=G10+1");
        c.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(c.Costos.Hoja, p, a, "H12") + "+7");
        string antes = JsonSerializer.Serialize(d);
        var h = MYGReporteMetradosExcel.Crear(d, p.Id, todosPresupuestos: true).Hoja;
        int f = Fila(h, "FILA ESTANDAR QA"), g = Fila(h, "FILA OTRO PRESUPUESTO QA");
        string local = Columna(h, a.Costos.Hoja, 7) + (f + 7);
        string blanca = Columna(h, a.Costos.Hoja, 8) + (f + 9);
        string destinoLocal = Columna(h, a.Costos.Hoja, 2) + f;
        string destinoVinculo = Columna(h, c.Costos.Hoja, 2) + g;
        Exige(h.FilasOcultas.Contains(f + 7) && h.FilasOcultas.Contains(f + 9) &&
            h.Celdas[destinoLocal].Contenido == "=" + local + "+1" &&
            h.Celdas[destinoVinculo].Contenido == "=" + blanca + "+7" &&
            h.Celdas[local].Contenido.StartsWith('=') && h.Celdas[blanca].Contenido == "" &&
            new MYGHojaCalculo(h).Numero(destinoLocal) == 1 && new MYGHojaCalculo(h).Numero(destinoVinculo) == 7 &&
            JsonSerializer.Serialize(d) == antes,
            "Las referencias locales y entre partidas a filas de relleno deben conservar sus direcciones, fórmulas y resultados al ocultarlas, sin cambiar el proyecto.");
        pasa("Metrados oculta filas vacías referenciadas sin desplazar celdas ni romper vínculos locales o entre partidas");
    }

    private static void EstructuraMetradosCompacta(Action<string> pasa)
    {
        var (d, p, a, _, _, _) = Proyecto();
        MYGEdicionHoja.InsertarFilas(a.Costos.Hoja, 4);
        MYGEdicionHoja.InsertarColumnas(a.Costos.Hoja, 2);
        a.Costos.Hoja.RangosCombinados.Add("A5:A6");
        // Elegir una celda vacía como total no debe hacerla desaparecer de la vista.
        a.Costos.Hoja.CeldaTotal = "C8";
        string antes = JsonSerializer.Serialize(d);
        var h = MYGReporteMetradosExcel.Crear(d, p.Id, MYGPlantillasMetrado.Estandar).Hoja;
        int f = Fila(h, "FILA ESTANDAR QA");
        string finA = MYGHojaCalculo.Columna(MYGHojaCalculo.Coordenadas(Columna(h, a.Costos.Hoja, 2) + "1").Columna - 1);
        Exige(h.FilasOcultas.Contains(f + 1) && h.FilasOcultas.Contains(f + 4) &&
            h.FilasOcultas.Contains(f + 13) &&
            new[] { f, f + 2, f + 3, f + 5, f + 14 }.All(fila => !h.FilasOcultas.Contains(fila)) &&
            new MYGHojaCalculo(h).Numero(Columna(h, a.Costos.Hoja, 8) + (f + 14)) == 6 &&
            h.RangosCombinados.Contains("A" + (f + 2) + ":" + finA + (f + 3)) &&
            JsonSerializer.Serialize(d) == antes,
            "La compactación debe seguir el cuerpo tras insertar filas y columnas y preservar combinaciones verticales, la celda elegida como total y la suma final.");
        pasa("Metrados compacta plantillas editadas y conserva las filas de combinaciones verticales y de la celda elegida como total");
    }
}
