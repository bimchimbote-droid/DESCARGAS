# Actualización: vistas R / CPM y cronograma Gantt

## A. Resumen de la implementación

Se agregan dos botones persistentes en la esquina superior derecha:
- R: recupera la interfaz de presupuesto, sus herramientas y datos.
- CPM: muestra la interfaz de cronograma con tabla de tareas y diagrama Gantt.

La vista CPM incluye:
- Tabla jerárquica con ID, modo, descripción, días calendario, duración, inicio, fin, predecesoras y porcentaje de avance.
- Gantt sincronizado con la tabla: meses/días, no laborables sombreados, tareas, hitos, resúmenes, progreso, línea de estado, vínculos, selección, desplazamiento y zoom.
- Herramientas visibles Tiempo de trabajo, Información de tarea, Insertar hito, Ruta crítica, Diagrama de red, Línea base, Línea de tiempo, Programar automáticamente, Programar manualmente, Calendario de adquisiciones, Calendario valorizado, Responsables y Otros.
- Creación/eliminación de tareas e hitos, edición real de celdas y diálogos, responsables y notas.
- Vínculos FC, CC, FF y CF con desfases positivos/negativos; rechazo de ciclos y referencias inexistentes.
- Ruta crítica y holgura, línea base de inicio/fin/duración, calendario laboral editable con feriados.
- Guardado en el proyecto SQLite/JSON, copias independientes para Deshacer/Rehacer y exportación CSV/XLSX e impresión del Gantt.
- Los calendarios valorizado y de adquisiciones se calculan con las partidas e insumos reales programados y separan monedas.

Abrir CPM por primera vez prepara una vista temporal desde todos los presupuestos, títulos y partidas existentes, sin modificar el proyecto por navegar. La primera edición incorpora el cronograma al documento y al historial. La navegación conserva ambas interfaces y confirma las celdas pendientes antes de cambiar de vista o guardar. La edición respeta la autorización MYG existente.

## Base y compatibilidad

Código: bimchimbote-droid/MYG.Presupuestos, rama main.
Commit base Git: 48765e07163a63217f87048fb4a6a1a76b5b504d.
Esta entrega incremental se aplica sobre la entrega anterior de formato de impresión de insumos, publicada en el repositorio independiente bimchimbote-droid/DESCARGAS:
- Commit: c932dd8cbdbe2f7ce596a1cb5ecc0073e595686e.
- Ruta: MYG.Presupuestos/entrega-2026-10-17_02-18-46-formato-impresion-insumos/MYG_PRESUPUESTOS_ACTUALIZACION.zip.

Se conservan las actualizaciones anteriores del presupuesto, resumen, insumos e impresión. No aplique estos archivos mezclados con una versión antigua de main sin incorporar primero las entregas anteriores.

## B. Archivos de esta entrega

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | INSTRUCCIONES_ACTUALIZACION.md | REEMPLAZAR | Instrucciones, uso y validación. |
| 2 | MYG.Core/CalendarioCronogramaMYG.cs | CREAR | Calendario laboral y cálculo de días. |
| 3 | MYG.Core/CronogramaMYG.cs | CREAR | Modelos, CPM, vínculos, base y sincronización. |
| 4 | MYG.Core/ProyectoBim.cs | REEMPLAZAR | Guarda y valida el cronograma del proyecto. |
| 5 | MYG.Core/ReportesCronogramaMYG.cs | CREAR | Gantt imprimible, CSV/XLSX y calendarios. |
| 6 | MYG.Desktop/CronogramaDialogos.cs | CREAR | Tarea, calendario, responsables y red. |
| 7 | MYG.Desktop/CronogramaGanttControl.cs | CREAR | Dibujo e interacción del Gantt. |
| 8 | MYG.Desktop/CronogramaPanel.cs | CREAR | Tabla editable y herramientas CPM. |
| 9 | MYG.Desktop/EditorCronograma.cs | CREAR | Integra R/CPM, cintas e historial. |
| 10 | MYG.Desktop/EditorForm.cs | REEMPLAZAR | Sincroniza edición, guardado, tema y atajos. |
| 11 | MYG.Desktop/EditorPresupuestos.cs | REEMPLAZAR | Integra la nueva vista con el presupuesto. |
| 12 | MYG.Pruebas/CronogramaCheck.cs | CREAR | Comprueba programación y persistencia. |
| 13 | MYG.Pruebas/Program.cs | REEMPLAZAR | Ejecuta las comprobaciones nuevas. |
| 14 | MYG.Pruebas/ReportesCronogramaCheck.cs | CREAR | Comprueba informes y calendarios. |
| 15 | MYG.PruebasUI/CronogramaUICheck.cs | CREAR | Comprueba interfaz y navegación. |
| 16 | MYG.PruebasUI/Program.cs | REEMPLAZAR | Registra la prueba UI nueva. |

Los archivos REEMPLAZAR se entregan completos. No hay archivos que eliminar ni parches pendientes. El ZIP contiene sólo estos dieciséis archivos; excluye proyecto completo, ejecutables, dependencias, bases de datos y metadatos Git.

## C. Descarga

MYG_PRESUPUESTOS_ACTUALIZACION.zip se publica únicamente en una ruta nueva de bimchimbote-droid/DESCARGAS, conservando todas las entregas anteriores.
La respuesta incluye el enlace HTTPS público fijado al commit y la comprobación real de descarga por bytes/SHA-256 e integridad ZIP.

## D. Instalación y uso

1. Cierre MYG. Confirme o respalde sus cambios locales en Visual Studio > Cambios de Git y conserve copia de sus proyectos SQLite.
2. Compruebe que ya aplicó la entrega anterior indicada en Base y compatibilidad.
3. Descargue y extraiga el ZIP fuera del proyecto.
4. Copie su contenido a la raíz del proyecto, conservando las rutas. Cree los diez archivos nuevos y sustituya los seis existentes de la tabla. Si tienen cambios locales/posteriores, compare y fusione antes de reemplazarlos.
5. Abra MYG.Presupuestos.sln, restaure y compile Release.
6. Abra un proyecto y pulse CPM. Sus presupuestos/títulos serán resúmenes y las partidas se mostrarán como tareas. R regresa al presupuesto.
7. Abra Tiempo de trabajo para fijar inicio del cronograma, fecha de estado, días laborables y feriados.
8. Edite duración y avance. En Predecesoras use el ID numérico de la tabla: por ejemplo 3FC+2;5CC-1. Un número solo significa FC sin desfase. Los vínculos se conservan internamente por identidad, aunque cambien los números de fila.
9. Programar automáticamente respeta calendario y vínculos. Programar manualmente fija el inicio calculado actual. Editar Inicio o Fin también fija modo Manual; Fin debe ser laborable y no anterior al inicio. Confirmar una fecha sin cambios no altera el modo.
10. Duración cero crea un hito. Insertar hito abre el diálogo correspondiente. Otros permite nuevas tareas, eliminación, vinculación/desvinculación, sincronización, zoom, plegado e historial.
11. Línea base permite establecer, quitar y mostrar el plan de referencia. Ruta crítica y Línea de tiempo son opciones de visualización y no generan historial.
12. Guarde desde la cinta o Ctrl+S. Cierre y reabra su SQLite para comprobar la planificación. Imprimir/PDF y Exportar utilizan el cronograma cuando CPM está activo.

## E. Configuraciones y reglas de cálculo

Tecnologías: C#, WinForms, .NET 10 y SQLite. SDK utilizado: .NET 10.0.100.
No se agregan paquetes, referencias de Office/Project ni cambios de solución/proyectos. Los proyectos SDK incluyen automáticamente las clases nuevas. No se requieren credenciales nuevas.

- Programación en días laborables enteros, con fin inclusivo y un calendario común del proyecto. La jornada en horas se registra en el calendario; la duración se introduce en días.
- Los resúmenes calculan rango y avance ponderado de sus tareas. Los vínculos se asignan a tareas e hitos, no directamente a resúmenes.
- Una tarea manual conserva su fecha aunque incumpla una predecesora; el estado y sus ayudas muestran la advertencia.
- Sincronizar con el presupuesto actualiza nombres y agrega orígenes nuevos, conservando programación y tareas propias. Los orígenes eliminados del presupuesto se conservan como tareas personalizadas para no perder avances/vínculos.
- El calendario valorizado distribuye el costo directo de cada partida programada entre sus días laborables y concilia los centavos. No es una valorización aprobada ni incluye por sí mismo gastos/impuestos del pie.
- Adquisiciones muestra necesidades de recursos reales al inicio de la tarea; no introduce plazos de proveedor ni registra compras. El informe explica este supuesto. Herramientas porcentuales y ajustes contables no se convierten en compras.
- Las tareas propias sin partida de origen no inventan costos o insumos.
- No se cambian tablas nativas de Delphin: el cronograma se conserva en el documento JSON del proyecto SQLite. Los documentos anteriores sin cronograma mantienen su firma y omiten el campo nuevo.

## F. Compilación y validación

Desde la raíz del proyecto:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

En Windows, ejecute también:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

Resultados:
- Compilación completa Release: 0 errores y 0 advertencias.
- Suite funcional: 432 comprobaciones aprobadas. Incluye calendarios/feriados, cuatro vínculos y desfases, ciclos, manuales, resúmenes, progreso, ruta crítica/holgura, línea base, sincronización, guardado/reapertura SQLite y JSON, firmas históricas, Gantt/exportaciones y calendarios financieros conciliados.
- Pruebas UI compiladas, no ejecutadas en Linux. Ejercitan edición real, fecha Fin, acciones de herramientas, rechazos atómicos, hitos, baseline, manual/automático, permisos, sincronización Gantt/tabla y navegación R/CPM sin cambios de datos.
- Named Pipes de Windows fue omitida por el runner. Las muestras externas opcionales no se ejecutaron.
- No se ejecutaron la interfaz Windows, impresora física, Revit ni licencias reales. UseRevitReferencePackages permite compilar el conector sin Revit instalado.

Comprobaciones manuales en Windows:
1. Abra R/CPM varias veces sin editar; no deben aparecer cambios pendientes ni perderse selección/datos del presupuesto.
2. Cree una cadena de tres tareas; cambie duración, predecesoras, feriados e inicio del proyecto y revise el Gantt.
3. Pruebe inicio y fin manuales, hitos, vínculos cíclicos rechazados y advertencias de incumplimientos manuales.
4. Establezca línea base, cambie duración/avance y revise la comparación y ruta crítica.
5. Guarde con una celda todavía en edición; cambie R/CPM, cierre y reabra. Revise notas, responsables, calendario, vínculos y base.
6. Use Deshacer/Rehacer, búsqueda, plegado, zoom y desplazamiento en ambos lados. Revise DPI y ambos temas.
7. Exporte CSV/XLSX e imprima a Microsoft Print to PDF. Revise los calendarios de adquisiciones/valorizado y sus supuestos.

## G. Publicación del código en GitHub

Sólo se publica el ZIP en el repositorio independiente DESCARGAS. No se hace Commit ni Push al repositorio del código.
Después de aplicar y validar, abra Visual Studio > Cambios de Git, compruebe su rama, revise los archivos, haga Commit y Push y verifique el commit en bimchimbote-droid/MYG.Presupuestos.

## H. Advertencias y pendientes

- El alcance implementado es la programación diaria y las herramientas enumeradas; no se declara equivalencia con todas las funciones ni con el formato MPP de Microsoft Project.
- La ejecución visual, interacción real de Windows e impresión final quedan pendientes de validación en Windows.
- Reemplazar archivos completos puede perder cambios locales/posteriores: respalde y compare.
- Esta entrega requiere la versión anterior indicada y no incluye el proyecto completo.
- Guarde cronogramas con esta versión: una versión anterior que desconozca el campo podría descartarlo al volver a guardar.
- Publicar el ZIP no aplica los cambios automáticamente en su PC.

