using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class CronogramaCheck
{
    // Fechas y duraciones calculadas a mano sobre el lunes 5 de octubre de 2026.
    private static readonly DateTime Lunes = new(2026, 10, 5);
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true, MaxDepth = 128 };
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Cronograma: " + mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor, Json);
    private static MYGCronograma Plan() => new() { FechaInicio = Lunes, FechaEstado = Lunes };
    private static MYGTareaCronograma Tarea(MYGCronograma plan, string id, int dias = 1, string padre = null,
        bool resumen = false)
    {
        var tarea = new MYGTareaCronograma { Id = id, Nombre = id, DuracionDias = dias,
            PadreId = padre, EsResumen = resumen };
        plan.Tareas.Add(tarea); return tarea;
    }
    private static void Depende(MYGTareaCronograma tarea, string predecesora,
        MYGTipoVinculo tipo = MYGTipoVinculo.FC, int desfase = 0) =>
        tarea.Predecesoras.Add(new() { PredecesoraId = predecesora, Tipo = tipo, DesfaseDias = desfase });
    private static MYGResultadoTarea Fila(MYGResultadoCronograma resultado, string id) =>
        resultado.Filas.Single(f => f.Tarea.Id == id);
    private static void Fechas(MYGResultadoCronograma resultado, string id, DateTime inicio, DateTime fin,
        int dias, string detalle)
    {
        var fila = Fila(resultado, id);
        Exige(fila.Inicio == inicio && fila.Fin == fin && fila.DuracionDias == dias,
            detalle + $"; {id} devolvió {fila.Inicio:dd/MM/yyyy}–{fila.Fin:dd/MM/yyyy}, {fila.DuracionDias} días.");
    }
    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (ArgumentException) { return; }
        catch (InvalidOperationException) { return; }
        throw new Exception("Cronograma aceptó " + detalle + ".");
    }
    private static void RechazaPlan(MYGCronograma plan, string detalle)
    {
        string antes = Firma(plan);
        Rechaza(() => MYGMotorCronograma.Calcular(plan), detalle);
        Exige(Firma(plan) == antes, "validar " + detalle + " modificó la planificación rechazada.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Calendario(pasa);
        Vinculos(pasa);
        Validacion(pasa);
        ManualResumen(pasa);
        RutaCritica(pasa);
        LineaBaseEdicion(pasa);
        Predecesoras(pasa);
        Sincronizacion(pasa);
        Persistencia(carpeta, pasa);
    }

    private static void Calendario(Action<string> pasa)
    {
        var plan = Plan();
        Exige(plan.Calendario.DiasLaborables.OrderBy(d => (int)d).SequenceEqual(new[] {
            DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday }) &&
            plan.Calendario.HorasPorDia == 8, "el calendario inicial no es de lunes a viernes y ocho horas.");
        var a = Tarea(plan, "TRES DÍAS", 3);
        Tarea(plan, "UN DÍA", 1);
        Tarea(plan, "HITO", 0);
        plan.Calendario.Feriados.Add(new DateTime(2026, 10, 7));
        string antes = Firma(plan);
        var resultado = MYGMotorCronograma.Calcular(plan);
        Fechas(resultado, a.Id, Lunes, new(2026, 10, 8), 3, "tres jornadas deben saltar el feriado del miércoles");
        Fechas(resultado, "UN DÍA", Lunes, Lunes, 1, "el fin de una jornada es inclusivo");
        Fechas(resultado, "HITO", Lunes, Lunes, 0, "un hito no debe consumir una jornada");
        Exige(Fila(resultado, a.Id).DiasCalendario == 4 && Firma(plan) == antes,
            "se confundieron días calendario y laborables o calcular modificó el modelo.");
        pasa("Cronograma usa fin inclusivo, semana L–V, feriados, días calendario e hitos de duración cero sin modificar el plan");

        var finSemana = Plan(); finSemana.FechaInicio = new(2026, 10, 10);
        Tarea(finSemana, "DESDE SÁBADO", 2);
        var lunesFeriado = new DateTime(2026, 10, 12);
        finSemana.Calendario.Feriados.Add(lunesFeriado);
        Fechas(MYGMotorCronograma.Calcular(finSemana), "DESDE SÁBADO", new(2026, 10, 13), new(2026, 10, 14), 2,
            "el inicio automático debe saltar fin de semana y lunes feriado");
        var sabados = Plan(); sabados.FechaInicio = new(2026, 10, 9);
        sabados.Calendario.DiasLaborables.Add(DayOfWeek.Saturday);
        Tarea(sabados, "SEMANA DE SEIS DÍAS", 2);
        Fechas(MYGMotorCronograma.Calcular(sabados), "SEMANA DE SEIS DÍAS", new(2026, 10, 9), new(2026, 10, 10), 2,
            "personalizar la semana debe permitir trabajar sábado");
        pasa("Calendario configurable desplaza el inicio automático fuera de días inhábiles y permite semanas con sábado laborable");
    }

    private static void Vinculos(Action<string> pasa)
    {
        var plan = Plan(); plan.Calendario.Feriados.Add(new(2026, 10, 7));
        Tarea(plan, "A", 3); // 5, 6 y 8 de octubre.
        var fc = Tarea(plan, "FC", 2); Depende(fc, "A");
        var cc = Tarea(plan, "CC", 2); Depende(cc, "A", MYGTipoVinculo.CC, 2);
        var ff = Tarea(plan, "FF", 3); Depende(ff, "A", MYGTipoVinculo.FF, 1);
        var cf = Tarea(plan, "CF", 2); Depende(cf, "A", MYGTipoVinculo.CF, 3);
        var negativo = Tarea(plan, "SOLAPE", 1); Depende(negativo, "A", MYGTipoVinculo.FC, -1);
        var positivo = Tarea(plan, "ESPERA", 1); Depende(positivo, "A", MYGTipoVinculo.FC, 2);
        var resultado = MYGMotorCronograma.Calcular(plan);
        Fechas(resultado, "FC", new(2026, 10, 9), new(2026, 10, 12), 2, "FC debe comenzar la siguiente jornada");
        Fechas(resultado, "CC", new(2026, 10, 8), new(2026, 10, 9), 2, "CC+2 debe contar dos jornadas desde el inicio");
        Fechas(resultado, "FF", new(2026, 10, 6), new(2026, 10, 9), 3, "FF+1 debe fijar el fin y retroceder por el calendario");
        Fechas(resultado, "CF", new(2026, 10, 8), new(2026, 10, 9), 2, "CF+3 debe limitar el fin desde el inicio predecesor");
        Fechas(resultado, "SOLAPE", new(2026, 10, 8), new(2026, 10, 8), 1, "FC-1 debe permitir solape de una jornada");
        Fechas(resultado, "ESPERA", new(2026, 10, 13), new(2026, 10, 13), 1, "FC+2 debe agregar dos jornadas antes del sucesor");
        pasa("Vínculos FC, CC, FF y CF aplican restricciones y desfases positivos/negativos sobre jornadas con feriados");

        var varios = Plan();
        Tarea(varios, "LARGA", 5); Tarea(varios, "CORTA", 2);
        var final = Tarea(varios, "FINAL", 1); Depende(final, "CORTA"); Depende(final, "LARGA");
        var hito = Tarea(varios, "ENTREGA", 0); Depende(hito, "FINAL");
        // Orden de almacenamiento deliberadamente diferente del orden topológico.
        varios.Tareas.Reverse();
        var calculado = MYGMotorCronograma.Calcular(varios);
        Fechas(calculado, "FINAL", new(2026, 10, 12), new(2026, 10, 12), 1, "debe prevalecer la última de varias restricciones");
        Fechas(calculado, "ENTREGA", new(2026, 10, 13), new(2026, 10, 13), 0, "un hito vinculado debe respetar FC");
        pasa("Cálculo ordena el grafo independientemente de la tabla y respeta todas las predecesoras y los hitos vinculados");
    }

    private static void Validacion(Action<string> pasa)
    {
        var ciclo = Plan();
        var a = Tarea(ciclo, "A"); var b = Tarea(ciclo, "B");
        Depende(a, "B"); Depende(b, "A");
        RechazaPlan(ciclo, "ciclos de dependencias");
        a.Modo = b.Modo = MYGModoTarea.Manual; a.InicioManual = b.InicioManual = Lunes;
        RechazaPlan(ciclo, "ciclos entre tareas manuales");
        var jerarquia = Plan();
        Tarea(jerarquia, "PADRE", padre: "HIJO", resumen: true);
        Tarea(jerarquia, "HIJO", padre: "PADRE", resumen: true);
        RechazaPlan(jerarquia, "ciclos de jerarquía");
        var ausente = Plan(); Depende(Tarea(ausente, "A"), "NO EXISTE");
        RechazaPlan(ausente, "predecesoras inexistentes");
        var huerfana = Plan(); Tarea(huerfana, "A", padre: "NO EXISTE");
        RechazaPlan(huerfana, "padres inexistentes");
        var duplicado = Plan(); Tarea(duplicado, "A"); Tarea(duplicado, "A");
        RechazaPlan(duplicado, "identificadores duplicados");
        pasa("Validación rechaza ciclos de tareas automáticas/manuales y jerarquías, referencias ausentes e identificadores duplicados sin mutar entradas");

        foreach (int dias in new[] { -1, 36501 })
        {
            var invalido = Plan(); Tarea(invalido, "DURACIÓN", dias);
            RechazaPlan(invalido, "duración fuera del rango 0–36500");
        }
        foreach (decimal avance in new[] { -1m, 100.01m })
        {
            var invalido = Plan(); Tarea(invalido, "AVANCE").Avance = avance;
            RechazaPlan(invalido, "avance fuera de 0–100");
        }
        var semanaVacia = Plan(); semanaVacia.Calendario.DiasLaborables.Clear(); Tarea(semanaVacia, "A");
        RechazaPlan(semanaVacia, "semana sin jornadas laborables");
        var horas = Plan(); horas.Calendario.HorasPorDia = 0; Tarea(horas, "A");
        RechazaPlan(horas, "jornada de cero horas");
        var manualSinInicio = Plan(); Tarea(manualSinInicio, "A").Modo = MYGModoTarea.Manual;
        RechazaPlan(manualSinInicio, "tarea manual sin inicio");
        pasa("Validación rechaza duraciones/avances fuera de rango, calendario sin trabajo y tarea manual sin fecha");
    }

    private static void ManualResumen(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "PREVIA", 5);
        var manual = Tarea(plan, "MANUAL", 2); manual.Modo = MYGModoTarea.Manual;
        manual.InicioManual = new(2026, 10, 6); Depende(manual, "PREVIA");
        var automatica = Tarea(plan, "AUTO", 2); Depende(automatica, "PREVIA");
        var sabado = Tarea(plan, "MANUAL SÁBADO", 1); sabado.Modo = MYGModoTarea.Manual;
        sabado.InicioManual = new(2026, 10, 10);
        var hito = Tarea(plan, "HITO SÁBADO", 0); hito.Modo = MYGModoTarea.Manual;
        hito.InicioManual = new(2026, 10, 10);
        var resultado = MYGMotorCronograma.Calcular(plan);
        Fechas(resultado, "MANUAL", new(2026, 10, 6), new(2026, 10, 7), 2, "el modo manual debe conservar el inicio pese al vínculo");
        Fechas(resultado, "AUTO", new(2026, 10, 12), new(2026, 10, 13), 2, "el modo automático debe aplicar el vínculo");
        Fechas(resultado, "MANUAL SÁBADO", new(2026, 10, 10), new(2026, 10, 12), 1,
            "un inicio manual inhábil se conserva y la duración se cuenta en jornadas");
        Fechas(resultado, "HITO SÁBADO", new(2026, 10, 10), new(2026, 10, 10), 0, "un hito manual conserva su fecha exacta");
        Exige(Fila(resultado, "MANUAL").Advertencias.Count > 0 &&
            Fila(resultado, "MANUAL SÁBADO").Advertencias.Count == 0 && resultado.Advertencias.Count > 0,
            "un vínculo manual incumplido debe advertirse sin bloquear ni advertir tareas sin vínculos.");
        pasa("Modo manual conserva fechas incluso con vínculos incumplidos y días inhábiles; automático respeta precedencias");

        var resumen = Plan(); var raiz = Tarea(resumen, "OBRA", resumen: true);
        raiz.DuracionDias = 100; raiz.Avance = 99;
        Tarea(resumen, "ETAPA", padre: raiz.Id, resumen: true);
        var corta = Tarea(resumen, "CORTA", 2, "ETAPA"); corta.Avance = 100;
        var larga = Tarea(resumen, "LARGA", 6, raiz.Id); larga.Avance = 0;
        Depende(larga, corta.Id);
        string antes = Firma(resumen);
        var filas = MYGMotorCronograma.Calcular(resumen);
        Fechas(filas, raiz.Id, Lunes, new(2026, 10, 14), 8, "el resumen debe abarcar sus descendientes y no usar duración editable");
        Exige(Fila(filas, raiz.Id).Avance == 25 && Fila(filas, "ETAPA").Avance == 100 &&
            Fila(filas, corta.Id).Nivel == Fila(filas, raiz.Id).Nivel + 2 &&
            filas.Filas.Select(f => f.Numero).SequenceEqual(Enumerable.Range(1, filas.Filas.Count)) && Firma(resumen) == antes,
            "el resumen no ponderó sus hojas por duración, duplicó la etapa intermedia o cambió el plan.");
        var avanceHito = Plan(); Tarea(avanceHito, "ETAPA", resumen: true);
        Tarea(avanceHito, "COMPLETA", 2, "ETAPA").Avance = 100;
        Tarea(avanceHito, "PENDIENTE", 3, "ETAPA").Avance = 0;
        Tarea(avanceHito, "HITO COMPLETO", 0, "ETAPA").Avance = 100;
        Exige(Fila(MYGMotorCronograma.Calcular(avanceHito), "ETAPA").Avance == 50,
            "el hito completo debe pesar una unidad al ponderar avance de su resumen.");
        pasa("Resúmenes derivan rango y avance de hojas sin doble conteo; filas conservan numeración y niveles jerárquicos");
    }

    private static void RutaCritica(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "A", 2);
        var b = Tarea(plan, "B", 3); Depende(b, "A");
        Tarea(plan, "C", 2);
        var d = Tarea(plan, "D", 1); Depende(d, "B"); Depende(d, "C");
        var resultado = MYGMotorCronograma.Calcular(plan);
        Exige(resultado.Inicio == Lunes && resultado.Fin == new DateTime(2026, 10, 12) &&
            new[] { "A", "B", "D" }.All(id => Fila(resultado, id).EsCritica && Fila(resultado, id).HolguraDias == 0) &&
            !Fila(resultado, "C").EsCritica && Fila(resultado, "C").HolguraDias == 3,
            "la red A2→B3→D1 / C2→D1 no dio seis jornadas y tres de holgura en C.");
        pasa("Ruta crítica identifica la rama dominante y calcula tres jornadas de holgura en la rama paralela corta");

        foreach (var caso in new[] { (MYGTipoVinculo.CC, 1, 2), (MYGTipoVinculo.FF, 0, 0), (MYGTipoVinculo.CF, 3, 1) })
        {
            var otro = Plan(); Tarea(otro, "A", 5);
            var sucesora = Tarea(otro, "B", 2); Depende(sucesora, "A", caso.Item1, caso.Item2);
            var calculado = MYGMotorCronograma.Calcular(otro);
            Exige(Fila(calculado, "A").HolguraDias == 0 && Fila(calculado, "B").HolguraDias == caso.Item3 &&
                Fila(calculado, "B").EsCritica == (caso.Item3 == 0),
                "la pasada hacia atrás ignoró la restricción " + caso.Item1 + " al calcular holguras.");
        }
        pasa("Holguras y ruta crítica usan también los vínculos CC, FF y CF en la pasada hacia atrás");
    }

    private static void LineaBaseEdicion(Action<string> pasa)
    {
        var plan = Plan(); var a = Tarea(plan, "A", 2);
        var b = Tarea(plan, "B", 3); Depende(b, "A");
        MYGMotorCronograma.EstablecerLineaBase(plan);
        Exige(a.InicioBase == Lunes && a.FinBase == new DateTime(2026, 10, 6) && a.DuracionBase == 2 &&
            b.InicioBase == new DateTime(2026, 10, 7) && b.FinBase == new DateTime(2026, 10, 9) && b.DuracionBase == 3,
            "la línea base no capturó las fechas y duraciones calculadas.");
        a.DuracionDias = 4;
        Fechas(MYGMotorCronograma.Calcular(plan), "B", new(2026, 10, 9), new(2026, 10, 13), 3,
            "la programación debe cambiar después de capturar la línea base");
        Exige(b.InicioBase == new DateTime(2026, 10, 7) && b.FinBase == new DateTime(2026, 10, 9),
            "recalcular sobrescribió la línea base original.");
        MYGMotorCronograma.QuitarLineaBase(plan);
        Exige(plan.Tareas.All(t => t.InicioBase == null && t.FinBase == null && t.DuracionBase == null),
            "quitar la línea base dejó valores parciales.");
        pasa("Línea base captura el cronograma, permanece estable al reprogramar y se quita completamente");

        var edicion = Plan(); var s = Tarea(edicion, "RESUMEN", resumen: true);
        var nueva = MYGMotorCronograma.AgregarTarea(edicion, s.Id, "TRABAJO NUEVO");
        var hito = MYGMotorCronograma.AgregarTarea(edicion, s.Id, "ENTREGA NUEVA", true);
        var externa = MYGMotorCronograma.AgregarTarea(edicion, null, "TRABAJO EXTERNO");
        Exige(nueva.PadreId == s.Id && hito.PadreId == s.Id && hito.DuracionDias == 0 &&
            nueva.Id != hito.Id && edicion.Tareas.All(t => !string.IsNullOrWhiteSpace(t.Id)),
            "agregar tarea o hito perdió el padre, la identidad o la duración cero.");
        MYGMotorCronograma.Vincular(edicion, new[] { nueva.Id, hito.Id, externa.Id });
        Exige(hito.Predecesoras.Single().PredecesoraId == nueva.Id &&
            externa.Predecesoras.Single().PredecesoraId == hito.Id, "vincular no creó una cadena en el orden seleccionado.");
        MYGMotorCronograma.Desvincular(edicion, new[] { nueva.Id, hito.Id, externa.Id });
        Exige(hito.Predecesoras.Count == 0 && externa.Predecesoras.Count == 0, "desvincular dejó los enlaces seleccionados.");
        Depende(externa, hito.Id);
        MYGMotorCronograma.EliminarTarea(edicion, s.Id);
        Exige(edicion.Tareas.Count == 1 && edicion.Tareas[0].Id == externa.Id && externa.Predecesoras.Count == 0,
            "eliminar una rama dejó descendientes o referencias entrantes rotas.");
        MYGMotorCronograma.Validar(edicion);
        pasa("Edición agrega tareas e hitos, vincula/desvincula cadenas y elimina descendientes limpiando referencias");
    }

    private static void Predecesoras(Action<string> pasa)
    {
        var plan = Plan(); foreach (string id in new[] { "A", "B", "C", "D", "E" }) Tarea(plan, id);
        var filas = MYGMotorCronograma.Calcular(plan).Filas;
        var links = MYGMotorCronograma.LeerPredecesoras("1FC+2;2CC-1;3FF;4CF+3", filas, "E");
        Exige(links.Select(l => l.PredecesoraId).SequenceEqual(new[] { "A", "B", "C", "D" }) &&
            links.Select(l => l.Tipo).SequenceEqual(new[] { MYGTipoVinculo.FC, MYGTipoVinculo.CC, MYGTipoVinculo.FF, MYGTipoVinculo.CF }) &&
            links.Select(l => l.DesfaseDias).SequenceEqual(new[] { 2, -1, 0, 3 }),
            "leer predecesoras perdió números, tipos o desfases.");
        plan.Tareas.Single(t => t.Id == "E").Predecesoras = links;
        string texto = MYGMotorCronograma.FormatoPredecesoras(plan.Tareas.Single(t => t.Id == "E"), filas);
        Exige(Firma(MYGMotorCronograma.LeerPredecesoras(texto, filas, "E")) == Firma(links),
            "mostrar y volver a leer predecesoras cambió los enlaces.");
        var simples = MYGMotorCronograma.LeerPredecesoras("1, 2CC-1", filas, "E");
        Exige(simples.Count == 2 && simples[0].Tipo == MYGTipoVinculo.FC && simples[0].DesfaseDias == 0,
            "no se aceptó número simple o separador coma.");
        foreach (string invalido in new[] { "5", "99FC", "1;1FC+2", "1XX", "1FC+abc" })
            Rechaza(() => MYGMotorCronograma.LeerPredecesoras(invalido, filas, "E"), "predecesora inválida «" + invalido + "»");
        var jerarquico = Plan(); Tarea(jerarquico, "RESUMEN", resumen: true);
        Tarea(jerarquico, "HIJA", padre: "RESUMEN"); Tarea(jerarquico, "DESTINO");
        var jerarquia = MYGMotorCronograma.Calcular(jerarquico).Filas;
        int numeroResumen = jerarquia.Single(f => f.Tarea.Id == "RESUMEN").Numero;
        Rechaza(() => MYGMotorCronograma.LeerPredecesoras(numeroResumen.ToString(), jerarquia, "DESTINO"), "un resumen como predecesora editable");
        pasa("Predecesoras admite cuatro tipos, desfases y separadores, conserva el texto al releer y rechaza autorreferencias, duplicados, resúmenes y filas inválidas");
    }

    private static ItemPresupuestoDelphin Nodo(MYGPresupuestoDocumento presupuesto, string id, string codigo,
        string padre = null, bool titulo = false)
    {
        var nodo = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = codigo, ParentId = padre,
            // MYG puede identificar nodos dentro de cada presupuesto; Delphin usa una identidad global.
            IdInternoDelphin = "CPM-NATIVO-" + presupuesto.Id + "-" + id,
            TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Descripcion = id, Unidad = titulo ? "" : "und",
            Posicion = presupuesto.Items.Count + 1 };
        nodo.Costos.Cantidad = titulo ? 0 : 2.5m; nodo.Costos.PrecioDirecto = titulo ? 0 : 3.2m;
        presupuesto.Items.Add(nodo); return nodo;
    }
    private static MYGProyectoDocumento Documento()
    {
        var documento = MYGProyectoStorage.Nuevo("OBRA CON CRONOGRAMA", "ESTRUCTURAS");
        documento.Datos = new MYGDatosProyecto { FechaInicio = Lunes, FechaElaboracion = new(2026, 10, 1) };
        var primero = documento.Presupuestos[0];
        Nodo(primero, "TITULO", "01.01", titulo: true);
        Nodo(primero, "MISMO-ID-PARTIDA", "01.01.01", "TITULO");
        var segundo = new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 };
        Nodo(segundo, "MISMO-ID-PARTIDA", "02.01"); documento.Presupuestos.Add(segundo);
        MYGProyectoStorage.Validar(documento); return documento;
    }

    private static void Sincronizacion(Action<string> pasa)
    {
        var documento = Documento(); string antes = Firma(documento);
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(documento);
        var repetido = MYGMotorCronograma.CrearDesdePresupuestos(documento);
        var primero = documento.Presupuestos[0]; var segundo = documento.Presupuestos[1];
        var a = plan.Tareas.Single(t => t.PresupuestoId == primero.Id && t.PartidaId == "MISMO-ID-PARTIDA");
        var b = plan.Tareas.Single(t => t.PresupuestoId == segundo.Id && t.PartidaId == "MISMO-ID-PARTIDA");
        var titulo = plan.Tareas.Single(t => t.PresupuestoId == primero.Id && t.PartidaId == "TITULO");
        Exige(plan.FechaInicio == Lunes && plan.Tareas.Count == 5 && a.Id != b.Id && a.PadreId == titulo.Id &&
            titulo.EsResumen && plan.Tareas.Count(t => t.EsResumen) == 3 && Firma(documento) == antes &&
            plan.Tareas.All(t => repetido.Tareas.Any(o => o.Id == t.Id && o.PresupuestoId == t.PresupuestoId && o.PartidaId == t.PartidaId)),
            "crear desde presupuesto cambió la obra, perdió jerarquía/fechas o mezcló identidades entre presupuestos.");
        pasa("Cronograma inicial copia todos los presupuestos, títulos y partidas con jerarquía e identidades estables sin alterar cantidades ni costos");

        a.DuracionDias = 4; a.Modo = MYGModoTarea.Manual; a.InicioManual = new(2026, 10, 6);
        a.Avance = 35; a.Notas = "PLANIFICACIÓN EXISTENTE"; a.Responsables.Add("ANA");
        MYGMotorCronograma.EstablecerLineaBase(plan);
        DateTime inicioBase = a.InicioBase.Value, finBase = a.FinBase.Value;
        int duracionBase = a.DuracionBase.Value;
        var custom = MYGMotorCronograma.AgregarTarea(plan, titulo.Id, "INSPECCIÓN PERSONALIZADA");
        custom.DuracionDias = 2; Depende(custom, a.Id);
        primero.Items.Single(i => i.Id == "MISMO-ID-PARTIDA").Descripcion = "PARTIDA RENOMBRADA";
        Nodo(primero, "NUEVA PARTIDA", "01.01.02", "TITULO");
        string presupuestoAntes = Firma(documento);
        MYGMotorCronograma.SincronizarPresupuestos(documento, plan);
        var actualizada = plan.Tareas.Single(t => t.Id == a.Id);
        Exige(actualizada.Nombre == "PARTIDA RENOMBRADA" && actualizada.DuracionDias == 4 &&
            actualizada.Modo == MYGModoTarea.Manual && actualizada.InicioManual == new DateTime(2026, 10, 6) &&
            actualizada.Avance == 35 && actualizada.Notas == "PLANIFICACIÓN EXISTENTE" &&
            actualizada.Responsables.SequenceEqual(new[] { "ANA" }) && actualizada.InicioBase == inicioBase &&
            actualizada.FinBase == finBase && actualizada.DuracionBase == duracionBase &&
            plan.Tareas.Any(t => t.PartidaId == "NUEVA PARTIDA") && plan.Tareas.Any(t => t.Id == custom.Id) &&
            plan.Tareas.Single(t => t.Id == custom.Id).Predecesoras.Single().PredecesoraId == a.Id &&
            Firma(documento) == presupuestoAntes,
            "sincronizar no actualizó origen conservando duración, modo, inicio, avance, notas, responsables, base y tareas propias.");
        string estable = Firma(plan);
        MYGMotorCronograma.SincronizarPresupuestos(documento, plan);
        Exige(Firma(plan) == estable, "sincronizar dos veces duplicó tareas o cambió una planificación ya actualizada.");
        primero.Items.RemoveAll(i => i.Id == "MISMO-ID-PARTIDA");
        MYGMotorCronograma.SincronizarPresupuestos(documento, plan);
        var ids = plan.Tareas.Select(t => t.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        Exige(plan.Tareas.Any(t => t.Id == custom.Id) && plan.Tareas.All(t =>
            (string.IsNullOrWhiteSpace(t.PadreId) || ids.Contains(t.PadreId)) &&
            t.Predecesoras.All(v => ids.Contains(v.PredecesoraId))),
            "quitar una partida de origen eliminó una tarea propia o dejó referencias sin destino.");
        MYGMotorCronograma.Validar(plan);
        pasa("Sincronización conserva programación y tareas propias, actualiza nombres/agrega partidas y gestiona eliminaciones sin referencias rotas ni duplicados");

        var sinInicio = Documento(); sinInicio.Datos.FechaInicio = null;
        var esperado = new DateTime(2026, 10, 1);
        Exige(MYGMotorCronograma.CrearDesdePresupuestos(sinInicio).FechaInicio == esperado,
            "no se usó fecha de elaboración cuando falta fecha de inicio.");
        pasa("Cronograma usa la fecha de elaboración como alternativa cuando el proyecto no tiene inicio definido");
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var documento = Documento(); documento.Cronograma = MYGMotorCronograma.CrearDesdePresupuestos(documento);
        var hoja = documento.Cronograma.Tareas.First(t => !t.EsResumen);
        hoja.DuracionDias = 3; hoja.Avance = 40; hoja.Notas = "NOTAS PERSISTENTES";
        hoja.Responsables.Add("INGENIERA");
        var custom = MYGMotorCronograma.AgregarTarea(documento.Cronograma, hoja.PadreId, "PRUEBA FINAL");
        Depende(custom, hoja.Id, MYGTipoVinculo.FC, 2);
        documento.Cronograma.Calendario.Feriados.Add(new(2026, 10, 7));
        MYGMotorCronograma.EstablecerLineaBase(documento.Cronograma);
        string firmaPlan = Firma(documento.Cronograma);
        var copia = MYGProyectoStorage.Copia(documento);
        Exige(Firma(copia.Cronograma) == firmaPlan && !ReferenceEquals(copia.Cronograma, documento.Cronograma),
            "la copia usada por deshacer/rehacer perdió cronograma o compartió su referencia.");
        copia.Cronograma.Tareas.Single(t => t.Id == hoja.Id).Avance = 75;
        Exige(MYGProyectoStorage.Firma(copia) != MYGProyectoStorage.Firma(documento) && hoja.Avance == 40,
            "la firma no detectó cambios del cronograma o editar la copia cambió el original.");
        foreach (string extension in new[] { ".sqlite", ".myg.json" })
        {
            string ruta = Path.Combine(carpeta, "Cronograma persistente" + extension);
            MYGProyectoStorage.Guardar(ruta, documento);
            var reabierto = MYGProyectoStorage.Leer(ruta);
            Exige(Firma(reabierto.Cronograma) == firmaPlan &&
                Firma(reabierto.Presupuestos) == Firma(documento.Presupuestos) &&
                MYGProyectoStorage.Firma(reabierto) == MYGProyectoStorage.Firma(documento),
                "guardar/reabrir " + extension + " perdió tareas, fechas, calendario, enlaces, base o presupuesto.");
        }
        pasa("Copias, firmas y guardado/reapertura SQLite y JSON preservan cronograma completo, historial independiente y presupuesto original");

        // Fixture con el esquema JSON anterior al cronograma: la firma debe ser idéntica.
        const string legado = """
            {"Formato":"MYG_BIM_PROYECTO","Version":3,"Id":"LEGACY-CRONOGRAMA-CHECK","Nombre":"OBRA HISTORICA",
            "IdProyectoRevit":"LEGACY-CRONOGRAMA-CHECK","PresupuestoActivoId":null,"ModificadoUtc":"0001-01-01T00:00:00",
            "FuenteCatalogo":null,"Datos":null,"Presupuestos":[]}
            """;
        string legadoRuta = Path.Combine(carpeta, "Proyecto anterior sin cronograma.json");
        File.WriteAllText(legadoRuta, legado);
        var historico = MYGProyectoStorage.Leer(legadoRuta);
        using var jsonLegado = JsonDocument.Parse(legado);
        string firmaHistorica = JsonSerializer.Serialize(jsonLegado.RootElement, Json);
        Exige(historico.Cronograma == null && MYGProyectoStorage.Firma(historico) == firmaHistorica &&
            !JsonSerializer.Serialize(historico, Json).Contains("\"Cronograma\"", StringComparison.Ordinal),
            "abrir una obra histórica agregó cronograma nulo o cambió la firma del documento sin editarlo.");
        MYGProyectoStorage.Guardar(legadoRuta, historico);
        Exige(MYGProyectoStorage.Firma(MYGProyectoStorage.Leer(legadoRuta)) == firmaHistorica &&
            !File.ReadAllText(legadoRuta).Contains("\"Cronograma\"", StringComparison.Ordinal),
            "guardar y reabrir el documento histórico añadió un cronograma inexistente.");
        pasa("Proyectos históricos sin cronograma conservan su firma y omiten el campo nuevo incluso después de guardar/reabrir");
    }
}
