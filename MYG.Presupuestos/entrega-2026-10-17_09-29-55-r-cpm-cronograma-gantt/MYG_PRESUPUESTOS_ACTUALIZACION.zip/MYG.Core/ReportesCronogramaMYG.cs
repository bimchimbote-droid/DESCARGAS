using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace MYG_2027;

/// <summary>Instantáneas imprimibles y archivos abiertos de la planificación. No
/// cambia el presupuesto, las fechas de las tareas ni los costos del proyecto.</summary>
public static class MYGReportesCronograma
{
    private static readonly CultureInfo Espanol = CultureInfo.GetCultureInfo("es-PE");
    private const int PeriodosPorHoja = 8;
    private const int FilasPorHoja = 1000;
    private sealed record Periodo(DateTime Inicio, DateTime Fin, string Rotulo);
    private sealed record PartidaProgramada(MYGResultadoTarea Fila, MYGPresupuestoDocumento Presupuesto,
        ItemPresupuestoDelphin Partida, MYGCalculoPresupuesto Calculo);

    /// <summary>Gantt en A3 horizontal. Hasta ocho semanas o meses por hoja,
    /// conservando la tabla de tareas en cada tramo, también al exportar a Excel.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> Crear(MYGProyectoDocumento documento, MYGCronograma plan)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var resultado = MYGMotorCronograma.Calcular(plan);
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        DateTime inicio = resultado.Inicio, fin = resultado.Fin;
        foreach (var f in resultado.Filas)
        {
            if (f.Tarea.InicioBase.HasValue && f.Tarea.InicioBase.Value.Date < inicio) inicio = f.Tarea.InicioBase.Value.Date;
            if (f.Tarea.FinBase.HasValue && f.Tarea.FinBase.Value.Date > fin) fin = f.Tarea.FinBase.Value.Date;
        }
        bool semanal = (fin - inicio).TotalDays <= 112;
        var periodos = Periodos(inicio, fin, semanal);
        var reportes = new List<MYGHojaReporteProyecto>();
        var tramosFilas = PartirFilas(resultado.Filas);
        int numero = 0;
        foreach (var tramo in periodos.Chunk(PeriodosPorHoja))
        foreach (var filas in tramosFilas)
        {
            numero++;
            var h = Hoja("Gantt " + numero, new[] { 30, 44, 210, 40, 44, 68, 68, 82, 48, 42, 68, 68 }, tramo.Length, 62);
            string[] titulos = { "ID", "Modo", "Descripción", "Días cal.", "Duración", "Inicio", "Fin", "Predecesoras", "% avance", "Holgura", "Inicio base", "Fin base" };
            Encabezados(h, titulos, tramo, "DIAGRAMA GANTT · " + (semanal ? "SEMANAS" : "MESES"));
            int fila = 3;
            foreach (var f in filas)
            {
                var t = f.Tarea;
                bool resumen = t.EsResumen;
                Numero(h, fila, 1, f.Numero, "0", resumen);
                Texto(h, fila, 2, resumen ? "Resumen" : t.Modo == MYGModoTarea.Manual ? "Manual" : "Auto", resumen, "Centro");
                Texto(h, fila, 3, new string(' ', Math.Min(f.Nivel, 20) * 2) + t.Codigo + " " + t.Nombre +
                    (!resumen && f.DuracionDias == 0 ? " [hito]" : ""), resumen);
                Numero(h, fila, 4, f.DiasCalendario, "0", resumen);
                Numero(h, fila, 5, f.DuracionDias, "0\" d\"", resumen);
                Texto(h, fila, 6, Fecha(f.Inicio), resumen, "Centro");
                Texto(h, fila, 7, Fecha(f.Fin), resumen, "Centro");
                Texto(h, fila, 8, MYGMotorCronograma.FormatoPredecesoras(t, resultado.Filas));
                Numero(h, fila, 9, t.Avance, "0.##\"%\"", resumen);
                Numero(h, fila, 10, f.HolguraDias, "0\" d\"", resumen);
                Texto(h, fila, 11, t.InicioBase.HasValue ? Fecha(t.InicioBase.Value) : "", resumen, "Centro");
                Texto(h, fila, 12, t.FinBase.HasValue ? Fecha(t.FinBase.Value) : "", resumen, "Centro");
                // El trazo inferior representa la línea base; el porcentaje
                // queda explícito en la tabla y el relleno oscuro marca el avance.
                int duracion = Math.Max(1, f.DuracionDias);
                decimal completados = duracion * t.Avance / 100m;
                int laborablesPrevios = 0;
                for (int p = 0; p < tramo.Length; p++)
                {
                    var periodo = tramo[p];
                    bool activa = Solapan(f.Inicio, f.Fin, periodo.Inicio, periodo.Fin);
                    bool baseActiva = t.InicioBase.HasValue && t.FinBase.HasValue &&
                        Solapan(t.InicioBase.Value, t.FinBase.Value, periodo.Inicio, periodo.Fin);
                    var c = Texto(h, fila, 13 + p, "", resumen, "Centro");
                    c.Fuente = "Arial";
                    if (activa)
                    {
                        if (resumen) { c.Contenido = "━"; c.ColorFondo = "DCE3EA"; c.ColorTexto = "243746"; }
                        else if (f.DuracionDias == 0) { c.Contenido = "◆"; c.ColorTexto = f.EsCritica ? "B72E36" : "2463A5"; }
                        else
                        {
                            int anteriores = periodo.Inicio == DateTime.MinValue.Date ? 0 :
                                calendario.Contar(f.Inicio, Menor(f.Fin, periodo.Inicio.AddDays(-1)));
                            int enPeriodo = calendario.Contar(Mayor(f.Inicio, periodo.Inicio), Menor(f.Fin, periodo.Fin));
                            laborablesPrevios = Math.Max(laborablesPrevios, anteriores);
                            bool avanzado = completados > laborablesPrevios && enPeriodo > 0 || t.Avance == 100;
                            c.Contenido = avanzado ? "▓▓" : "░░";
                            c.ColorFondo = f.EsCritica ? "F6DADD" : "D7E8FA";
                            c.ColorTexto = f.EsCritica ? "A92532" : "1D5795";
                        }
                    }
                    if (baseActiva) c.Contenido += "\n―";
                    if (periodo.Inicio <= plan.FechaEstado.Date && periodo.Fin >= plan.FechaEstado.Date)
                    { c.Subrayado = true; if (!activa) c.ColorFondo = "FFF0E2"; }
                    c.Bordes = true;
                }
                h.AltosFilas[fila] = f.Tarea.InicioBase.HasValue ? 32 : 25;
                if (resumen)
                    for (int col = 1; col <= 12; col++) Celda(h, fila, col).ColorFondo = "EAF0F6";
                fila++;
            }
            if (filas.Length == 0) { Texto(h, fila, 3, "Sin tareas programadas."); fila++; }
            Pie(h, fila, "Leyenda: ░ plan · ▓ avance · ◆ hito · ━ resumen · ― línea base · rojo: ruta crítica. " +
                "La columna naranja contiene la fecha de estado. Duraciones y holguras: días laborables completos.");
            Terminar(h, fila);
            reportes.Add(new("CRONOGRAMA · GANTT DE SEGUIMIENTO", h,
                Datos(documento, plan, "Escala", (semanal ? "Semanal" : "Mensual") + " · " + Fecha(tramo[0].Inicio) + " al " + Fecha(tramo[^1].Fin))));
        }
        return reportes.AsReadOnly();
    }

    /// <summary>Una fila por tarea, fechas ISO, sin fórmulas ejecutables al abrir
    /// el CSV en una hoja de cálculo. Sustituye el destino de manera atómica.</summary>
    public static void GuardarCsv(string ruta, MYGCronograma plan)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("Indique el archivo CSV de destino.", nameof(ruta));
        var r = MYGMotorCronograma.Calcular(plan);
        var s = new StringBuilder();
        void Fila(params string[] campos) => s.AppendJoin(',', campos.Select(CampoCsv)).Append("\r\n");
        Fila("ID", "ID estable", "ID padre", "Código", "Descripción", "Resumen", "Modo", "Días calendario", "Duración laborable", "Inicio", "Fin",
            "Predecesoras", "Avance %", "Holgura laborable", "Crítica", "Inicio base", "Fin base", "Duración base", "Responsables", "Notas", "Presupuesto ID", "Partida ID");
        foreach (var f in r.Filas)
        {
            var t = f.Tarea;
            Fila(Num(f.Numero), t.Id, t.PadreId, t.Codigo, t.Nombre, t.EsResumen ? "Sí" : "No",
                t.Modo == MYGModoTarea.Manual ? "Manual" : "Automática", Num(f.DiasCalendario), Num(f.DuracionDias),
                Iso(f.Inicio), Iso(f.Fin), MYGMotorCronograma.FormatoPredecesoras(t, r.Filas), Num(t.Avance),
                Num(f.HolguraDias), f.EsCritica ? "Sí" : "No", t.InicioBase.HasValue ? Iso(t.InicioBase.Value) : "",
                t.FinBase.HasValue ? Iso(t.FinBase.Value) : "", t.DuracionBase.HasValue ? Num(t.DuracionBase.Value) : "",
                string.Join("; ", t.Responsables ?? new()), t.Notas, t.PresupuestoId, t.PartidaId);
        }
        string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { File.WriteAllText(temporal, s.ToString(), new UTF8Encoding(true)); File.Move(temporal, ruta, true); }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    public static void GuardarExcel(string ruta, MYGProyectoDocumento documento, MYGCronograma plan) =>
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, Crear(documento, plan));

    /// <summary>Distribuye el costo directo de cada partida programada entre sus
    /// días laborables. El residuo monetario se asigna al último mes y las monedas
    /// se imprimen en informes separados. No supone gastos generales ni impuestos.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> CrearValorizado(MYGProyectoDocumento documento, MYGCronograma plan)
    {
        var partidas = PrepararPartidas(documento, plan, out _);
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        var reportes = new List<MYGHojaReporteProyecto>();
        var monedas = partidas.GroupBy(x => Moneda(x.Presupuesto), StringComparer.OrdinalIgnoreCase).ToArray();
        if (monedas.Length == 0) return new[] { SinDatos(documento, plan, "CALENDARIO VALORIZADO", "Sin partidas de presupuesto vinculadas al cronograma.") };
        int numero = 0;
        foreach (var moneda in monedas)
        {
            var importes = moneda.Select(p => (Partida: p, Meses: Repartir(p, calendario))).ToArray();
            var periodos = Periodos(importes.Min(p => p.Partida.Fila.Inicio), importes.Max(p => p.Partida.Fila.Fin), false);
            foreach (var tramo in periodos.Chunk(PeriodosPorHoja))
            foreach (var filas in importes.Chunk(FilasPorHoja))
            {
                var h = Hoja("Valorizado " + ++numero, new[] { 36, 92, 310, 100 }, tramo.Length, 90);
                Encabezados(h, new[] { "ID", "Código", "Partida", "Costo del tramo " + moneda.Key }, tramo, "VALORIZACIÓN MENSUAL · " + moneda.Key);
                int fila = 3;
                foreach (var p in filas)
                {
                    Numero(h, fila, 1, p.Partida.Fila.Numero, "0");
                    Texto(h, fila, 2, p.Partida.Fila.Tarea.Codigo);
                    Texto(h, fila, 3, p.Partida.Fila.Tarea.Nombre);
                    Numero(h, fila, 4, tramo.Sum(m => p.Meses.GetValueOrDefault(m.Inicio)));
                    for (int n = 0; n < tramo.Length; n++) Numero(h, fila, 5 + n, p.Meses.GetValueOrDefault(tramo[n].Inicio));
                    h.AltosFilas[fila++] = 26;
                }
                Texto(h, fila, 3, "TOTAL COSTO DIRECTO DEL TRAMO", true);
                Numero(h, fila, 4, filas.Sum(p => tramo.Sum(m => p.Meses.GetValueOrDefault(m.Inicio))), negrita: true);
                for (int n = 0; n < tramo.Length; n++) Numero(h, fila, 5 + n, filas.Sum(p => p.Meses.GetValueOrDefault(tramo[n].Inicio)), negrita: true);
                h.CeldaTotal = "D" + fila;
                for (int c = 1; c <= h.Columnas; c++) Celda(h, fila, c).ColorFondo = "E2EAF3";
                Pie(h, ++fila, "Alcance: sólo partidas vinculadas; costo directo real, sin gastos generales, utilidad ni impuestos adicionales. " +
                    "Reparto uniforme por días laborables de cada tarea; hitos o tareas sin días laborables se cargan al inicio. " +
                    "El último mes absorbe redondeos. Totales sólo de las filas y meses de esta hoja. " +
                    "Tareas personalizadas sin partida no generan costos. Monedas separadas; los importes no son una valorización contractual.");
                Terminar(h, fila);
                reportes.Add(new("CALENDARIO VALORIZADO · " + moneda.Key, h,
                    Datos(documento, plan, "Tramo mensual", Fecha(tramo[0].Inicio) + " al " + Fecha(tramo[^1].Fin))));
            }
        }
        return reportes.AsReadOnly();
    }

    /// <summary>Consolida recursos reales por condiciones económicas iguales y
    /// programa toda la cantidad al inicio de la tarea. Los subanálisis se
    /// expanden mediante el mismo motor que calcula el presupuesto.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> CrearAdquisiciones(MYGProyectoDocumento documento, MYGCronograma plan)
    {
        var partidas = PrepararPartidas(documento, plan, out _);
        var recursos = new Dictionary<ClaveRecurso, RecursoProgramado>();
        foreach (var p in partidas)
        {
            var catalogo = p.Presupuesto.Costos.Insumos.ToDictionary(i => i.Id, StringComparer.Ordinal);
            foreach (var i in p.Calculo.Consolidar(p.Partida))
            {
                // Sólo un recurso del catálogo identifica algo adquirible.
                // DIRECTO, PORCENTAJE y REDONDEO sintéticos no se convierten en
                // subcontratos ni en compras ficticias.
                if (!catalogo.TryGetValue(i.Clave, out var fuente)) continue;
                var clave = new ClaveRecurso(Moneda(p.Presupuesto), i.Grupo, i.Codigo ?? "", i.Descripcion ?? "",
                    string.IsNullOrWhiteSpace(fuente.Proveedor) ? "SIN CLASIFICAR" : fuente.Proveedor.Trim(), i.Unidad ?? "", i.Precio);
                if (!recursos.TryGetValue(clave, out var recurso)) recursos.Add(clave, recurso = new());
                var mes = Mes(p.Fila.Inicio);
                recurso.Cantidades[mes] = recurso.Cantidades.GetValueOrDefault(mes) + i.Cantidad;
                recurso.Costos[mes] = recurso.Costos.GetValueOrDefault(mes) + i.Total;
            }
        }
        if (recursos.Count == 0) return new[] { SinDatos(documento, plan, "CALENDARIO DE ADQUISICIONES", "Sin recursos reales requeridos por las partidas programadas.") };
        var reportes = new List<MYGHojaReporteProyecto>();
        int numero = 0;
        foreach (var moneda in recursos.GroupBy(r => r.Key.Moneda, StringComparer.OrdinalIgnoreCase))
        {
            var ordenados = moneda.OrderBy(r => r.Key.Grupo).ThenBy(r => r.Key.Codigo, StringComparer.OrdinalIgnoreCase)
                .ThenBy(r => r.Key.Descripcion, StringComparer.OrdinalIgnoreCase).ThenBy(r => r.Key.Proveedor, StringComparer.OrdinalIgnoreCase).ToArray();
            var fechas = ordenados.SelectMany(r => r.Value.Cantidades.Keys).ToArray();
            var periodos = Periodos(fechas.Min(), fechas.Max(), false);
            foreach (var tramo in periodos.Chunk(PeriodosPorHoja))
            foreach (var filas in ordenados.Chunk(FilasPorHoja))
            {
                var h = Hoja("Adquisiciones " + ++numero, new[] { 74, 72, 220, 42, 140, 84, 74, 94 }, tramo.Length, 66);
                Encabezados(h, new[] { "Grupo", "Código", "Recurso", "Unid.", "Proveedor", "Cant. tramo", "Precio " + moneda.Key, "Costo tramo " + moneda.Key }, tramo, "CANTIDADES REQUERIDAS AL INICIO DE LAS TAREAS");
                int fila = 3;
                foreach (var r in filas)
                {
                    Texto(h, fila, 1, MYGMotorPresupuestos.Grupo(r.Key.Grupo)); Texto(h, fila, 2, r.Key.Codigo);
                    Texto(h, fila, 3, r.Key.Descripcion); Texto(h, fila, 4, r.Key.Unidad, alineacion: "Centro");
                    Texto(h, fila, 5, r.Key.Proveedor); Numero(h, fila, 6, tramo.Sum(m => r.Value.Cantidades.GetValueOrDefault(m.Inicio)), "#,##0.0000");
                    Numero(h, fila, 7, r.Key.Precio, "#,##0.0000"); Numero(h, fila, 8, tramo.Sum(m => r.Value.Costos.GetValueOrDefault(m.Inicio)));
                    for (int n = 0; n < tramo.Length; n++) Numero(h, fila, 9 + n, r.Value.Cantidades.GetValueOrDefault(tramo[n].Inicio), "#,##0.0000");
                    h.AltosFilas[fila++] = 30;
                }
                Texto(h, fila, 5, "TOTAL RECURSOS · " + moneda.Key, true);
                Numero(h, fila, 8, filas.Sum(r => tramo.Sum(m => r.Value.Costos.GetValueOrDefault(m.Inicio))), negrita: true); h.CeldaTotal = "H" + fila;
                Pie(h, ++fila, "Supuesto: se requiere el 100% de cada recurso al inicio de la tarea, sin plazos de proveedor ni inventario. " +
                    "Las columnas mensuales muestran cantidades en la unidad de cada recurso; no se suman unidades distintas. " +
                    "Incluye recursos reales del ACU y subanálisis; excluye precios directos sin recursos, porcentajes y ajustes. " +
                    "Totales sólo de las filas y meses de esta hoja. No duplica resúmenes. Cada moneda se presenta por separado.");
                Terminar(h, fila);
                reportes.Add(new("CALENDARIO DE ADQUISICIONES · " + moneda.Key, h,
                    Datos(documento, plan, "Tramo mensual", Fecha(tramo[0].Inicio) + " al " + Fecha(tramo[^1].Fin))));
            }
        }
        return reportes.AsReadOnly();
    }

    private sealed record ClaveRecurso(string Moneda, MYGGrupoRecurso Grupo, string Codigo, string Descripcion,
        string Proveedor, string Unidad, decimal Precio);
    private sealed class RecursoProgramado
    {
        internal Dictionary<DateTime, decimal> Cantidades = new();
        internal Dictionary<DateTime, decimal> Costos = new();
    }

    private static List<PartidaProgramada> PrepararPartidas(MYGProyectoDocumento documento, MYGCronograma plan,
        out MYGResultadoCronograma resultado)
    {
        ArgumentNullException.ThrowIfNull(documento);
        resultado = MYGMotorCronograma.Calcular(plan);
        var copia = MYGProyectoStorage.Copia(documento);
        var presupuestos = copia.Presupuestos.ToDictionary(p => p.Id, StringComparer.OrdinalIgnoreCase);
        var calculos = new Dictionary<string, MYGCalculoPresupuesto>(StringComparer.OrdinalIgnoreCase);
        var vistas = new HashSet<(string Presupuesto, string Partida)>();
        var partidas = new List<PartidaProgramada>();
        foreach (var f in resultado.Filas.Where(f => !f.Tarea.EsResumen))
        {
            var t = f.Tarea;
            if (string.IsNullOrWhiteSpace(t.PartidaId)) continue;
            if (string.IsNullOrWhiteSpace(t.PresupuestoId) || !presupuestos.TryGetValue(t.PresupuestoId, out var p))
                throw new InvalidDataException("La tarea «" + t.Nombre + "» refiere a un presupuesto que ya no existe. Sincronice el cronograma.");
            var i = p.Items.FirstOrDefault(i => string.Equals(i.Id, t.PartidaId, StringComparison.OrdinalIgnoreCase));
            if (i == null || MYGProyectoStorage.EsTitulo(i))
                throw new InvalidDataException("La tarea «" + t.Nombre + "» no refiere a una partida vigente. Sincronice el cronograma.");
            if (!vistas.Add((p.Id.ToUpperInvariant(), i.Id.ToUpperInvariant())))
                throw new InvalidDataException("La partida «" + i.Descripcion + "» está vinculada a más de una tarea. Mantenga un solo vínculo para no duplicar sus costos y recursos.");
            if (!calculos.TryGetValue(p.Id, out var calculo))
            {
                MYGProyectoStorage.ValidarPresupuesto(p);
                calculos.Add(p.Id, calculo = MYGMotorPresupuestos.CrearCalculo(p));
            }
            partidas.Add(new(f, p, i, calculo));
        }
        return partidas;
    }

    private static Dictionary<DateTime, decimal> Repartir(PartidaProgramada p, MYGCalendarioEntero calendario)
    {
        decimal total = p.Calculo.TotalPartida(p.Partida);
        var meses = new SortedDictionary<DateTime, int>();
        if (p.Fila.DuracionDias > 0)
            foreach (var mes in Periodos(p.Fila.Inicio, p.Fila.Fin, false))
            {
                int diasMes = calendario.Contar(Mayor(p.Fila.Inicio, mes.Inicio), Menor(p.Fila.Fin, mes.Fin));
                if (diasMes > 0) meses.Add(mes.Inicio, diasMes);
            }
        if (meses.Count == 0) return new() { [Mes(p.Fila.Inicio)] = total };
        int dias = meses.Values.Sum(), n = 0, acumulados = 0;
        decimal asignado = 0;
        var resultado = new Dictionary<DateTime, decimal>();
        foreach (var mes in meses)
        {
            acumulados += mes.Value;
            // Redondear acumulados evita que muchos meses pequeños produzcan
            // un residuo final negativo por sumar redondeos independientes.
            decimal objetivo = ++n == meses.Count ? total : MYGMotorPresupuestos.Dinero(p.Presupuesto, total * acumulados / dias);
            resultado.Add(mes.Key, objetivo - asignado); asignado = objetivo;
        }
        return resultado;
    }

    private static MYGHojaReporteProyecto SinDatos(MYGProyectoDocumento d, MYGCronograma p, string titulo, string mensaje)
    {
        var h = Hoja(titulo, new[] { 400, 400 }, 0, 0);
        Texto(h, 1, 1, mensaje); h.RangosCombinados.Add("A1:B1"); h.AltosFilas[1] = 40; Terminar(h, 2);
        return new(titulo, h, Datos(d, p));
    }

    private static MYGResultadoTarea[][] PartirFilas(IReadOnlyList<MYGResultadoTarea> filas) =>
        filas.Count == 0 ? new[] { Array.Empty<MYGResultadoTarea>() } : filas.Chunk(FilasPorHoja).ToArray();
    private static MYGHojaMetrado Hoja(string nombre, int[] anchos, int periodos, int anchoPeriodo)
    {
        var h = new MYGHojaMetrado
        {
            Nombre = nombre, Filas = 2, Columnas = anchos.Length + periodos, CeldaTotal = "A1",
            TamanoPapel = "A3", OrientacionPagina = "Horizontal", FormatoNumeroPredeterminado = "#,##0.00",
            LineasDivision = false, Encabezados = false, ImprimirLineasDivision = false, ImprimirEncabezados = false,
            RepetirTitulos = true, FilasInmovilizadas = 2, ColumnasInmovilizadas = Math.Min(3, anchos.Length),
            MargenIzquierdo = .35m, MargenDerecho = .35m, MargenSuperior = .35m, MargenInferior = .35m,
            AltosFilas = new() { [1] = 27, [2] = 30 }
        };
        for (int c = 1; c <= h.Columnas; c++) h.AnchosColumnas[c] = c <= anchos.Length ? anchos[c - 1] : anchoPeriodo;
        return h;
    }

    private static void Encabezados(MYGHojaMetrado h, string[] titulos, Periodo[] periodos, string banda)
    {
        for (int c = 1; c <= h.Columnas; c++)
        {
            Texto(h, 1, c, "", true, "Centro").ColorFondo = "DCE6F1";
            Texto(h, 2, c, "", true, "Centro").ColorFondo = "EAF0F6";
        }
        Texto(h, 1, 1, "PLANIFICACIÓN DEL PROYECTO", true).ColorFondo = "DCE6F1";
        h.RangosCombinados.Add("A1:" + MYGHojaCalculo.Columna(titulos.Length) + "1");
        for (int c = 0; c < titulos.Length; c++) Texto(h, 2, c + 1, titulos[c], true, c == 2 ? "Izquierda" : "Centro").ColorFondo = "EAF0F6";
        if (periodos.Length == 0) return;
        int inicial = titulos.Length + 1;
        Texto(h, 1, inicial, banda, true, "Centro").ColorFondo = "DCE6F1";
        if (periodos.Length > 1) h.RangosCombinados.Add(MYGHojaCalculo.Columna(inicial) + "1:" + MYGHojaCalculo.Columna(h.Columnas) + "1");
        for (int p = 0; p < periodos.Length; p++) Texto(h, 2, inicial + p, periodos[p].Rotulo, true, "Centro").ColorFondo = "EAF0F6";
    }

    private static MYGCeldaHoja Texto(MYGHojaMetrado h, int fila, int columna, string valor, bool negrita = false, string alineacion = "Izquierda")
    {
        // Las cadenas numéricas, códigos y textos que empiezan por '=' conservan
        // su identidad literal tanto en el motor como en el archivo XLSX.
        valor ??= "";
        string contenido = MYGHojaCalculo.IntentarNumero(valor, out _) || valor.StartsWith('=')
            ? "=\"" + valor.Replace("\"", "\"\"") + "\"" : valor;
        var celda = new MYGCeldaHoja
        {
            Contenido = contenido, Negrita = negrita, Fuente = "Arial Narrow", TamanoFuente = 9,
            FormatoNumero = "@", ColorTexto = "172D45", ColorFondo = "FFFFFF", Bordes = true,
            AlineacionPersonalizada = true, AlineacionHorizontal = alineacion, AjustarTexto = true
        };
        h.Celdas[MYGHojaCalculo.Columna(columna) + fila] = celda;
        return celda;
    }
    private static void Numero(MYGHojaMetrado h, int fila, int columna, decimal valor, string formato = "#,##0.00", bool negrita = false)
    {
        var c = Texto(h, fila, columna, "", negrita, "Derecha"); c.Contenido = Num(valor); c.FormatoNumero = formato;
    }
    private static MYGCeldaHoja Celda(MYGHojaMetrado h, int fila, int columna) =>
        h.Celdas.TryGetValue(MYGHojaCalculo.Columna(columna) + fila, out var c) ? c : Texto(h, fila, columna, "");
    private static void Pie(MYGHojaMetrado h, int fila, string texto)
    {
        var c = Texto(h, fila, 1, texto); c.TamanoFuente = 8; c.ColorTexto = "52667A"; c.Bordes = false;
        h.RangosCombinados.Add("A" + fila + ":" + MYGHojaCalculo.Columna(h.Columnas) + fila); h.AltosFilas[fila] = 48;
    }
    private static void Terminar(MYGHojaMetrado h, int fila)
    {
        h.Filas = Math.Max(2, fila); h.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(h.Columnas) + h.Filas;
        MYGHojaCalculo.Validar(h);
    }
    private static IReadOnlyList<KeyValuePair<string, string>> Datos(MYGProyectoDocumento documento, MYGCronograma plan,
        string etiqueta = null, string valor = null)
    {
        string ubicacion = string.Join(" / ", new[] { documento.Datos?.Departamento, documento.Datos?.Provincia, documento.Datos?.Distrito }
            .Where(s => !string.IsNullOrWhiteSpace(s)));
        var datos = new List<KeyValuePair<string, string>>
        {
            new("Proyecto", documento.Nombre ?? ""), new("Propietario", documento.Datos?.Propietario ?? "No registrado"),
            new("Ubicación", ubicacion), new("Fecha de estado", Fecha(plan.FechaEstado)),
            new("Calendario", string.Join(", ", plan.Calendario.DiasLaborables.OrderBy(d => ((int)d + 6) % 7)
                .Select(d => Espanol.DateTimeFormat.GetAbbreviatedDayName(d))) + " · " + Num(plan.Calendario.HorasPorDia) + " h/día"),
            new("Línea base", plan.Tareas.Any(t => t.InicioBase.HasValue) ? "Fechas base en tabla y trazo inferior en Gantt" : "Sin establecer")
        };
        if (etiqueta != null) datos.Add(new(etiqueta, valor ?? ""));
        return datos.AsReadOnly();
    }

    private static Periodo[] Periodos(DateTime inicio, DateTime fin, bool semanal)
    {
        inicio = inicio.Date; fin = fin.Date;
        if (fin < inicio) fin = inicio;
        var lista = new List<Periodo>();
        DateTime actual;
        if (semanal)
        {
            int retroceso = ((int)inicio.DayOfWeek + 6) % 7;
            actual = inicio.Ticks >= TimeSpan.TicksPerDay * retroceso ? inicio.AddDays(-retroceso) : DateTime.MinValue.Date;
        }
        else actual = Mes(inicio);
        while (actual <= fin)
        {
            DateTime termino = semanal ? SumarDias(actual, 6) : new DateTime(actual.Year, actual.Month, DateTime.DaysInMonth(actual.Year, actual.Month));
            lista.Add(new(actual, termino, semanal ? actual.ToString("dd MMM", Espanol) + "\n" + actual.Year : actual.ToString("MMM yyyy", Espanol)));
            if (termino >= fin || termino == DateTime.MaxValue.Date) break;
            actual = termino.AddDays(1);
        }
        return lista.ToArray();
    }
    private static bool Solapan(DateTime a, DateTime b, DateTime c, DateTime d) => a.Date <= d.Date && b.Date >= c.Date;
    private static DateTime Menor(DateTime a, DateTime b) => a < b ? a : b;
    private static DateTime Mayor(DateTime a, DateTime b) => a > b ? a : b;
    private static DateTime Mes(DateTime d) => new(d.Year, d.Month, 1);
    private static DateTime SumarDias(DateTime d, int dias) => (DateTime.MaxValue.Date - d).Days < dias ? DateTime.MaxValue.Date : d.AddDays(dias);
    private static string Moneda(MYGPresupuestoDocumento p) => (p.Costos.Moneda ?? "S/").Trim().ToUpperInvariant();
    private static string Fecha(DateTime fecha) => fecha.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
    private static string Iso(DateTime fecha) => fecha.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    private static string Num(decimal numero) => numero.ToString(CultureInfo.InvariantCulture);
    private static string CampoCsv(string valor)
    {
        valor ??= "";
        string significativo = valor.TrimStart(' ', '\t', '\r', '\n', '\uFEFF');
        if (significativo.Length > 0 && "=+-@".Contains(significativo[0])) valor = "'" + valor;
        return "\"" + valor.Replace("\"", "\"\"") + "\"";
    }
}
