using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class HerramientasEditorCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var exportaciones = new List<MYGDestinoExportacionCronograma>();
        int metrados = 0;
        using (var menu = EditorForm.CrearMenuExportarProyecto(
            exportaciones.Add, () => metrados++, true, true))
        {
            var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
            using var cronograma = MYGMenuExportacionCronograma.Crear(_ => { });
            var destinos = cronograma.Items.OfType<ToolStripMenuItem>().Select(x => (MYGDestinoExportacionCronograma)x.Tag).ToArray();
            exige(opciones.Length == destinos.Length + 1 && opciones.Take(destinos.Length).Select(x => x.Tag).SequenceEqual(
                destinos.Cast<object>()) && menu.ImageScalingSize == cronograma.ImageScalingSize && opciones.All(x => x.Image != null),
                "Exportar presupuesto debe compartir los destinos, orden e iconos del cronograma y conservar los metrados completos.");
            exige(opciones.All(x => x.DropDownItems.Count == 0) &&
                !opciones.Any(x => x.Name == "exportar_especificaciones") &&
                opciones.Single(x => x.Name == "exportar_presupuesto_activo").Tag is MYGDestinoExportacionCronograma.Xlsx &&
                opciones.Single(x => x.Tag is MYGDestinoExportacionCronograma.Csv).Text == "Lista de partidas CSV",
                "El menú debe adaptar los formatos al presupuesto y dejar las especificaciones en su botón propio.");
            foreach (var opcion in opciones) opcion.PerformClick();
            exige(exportaciones.SequenceEqual(destinos) && metrados == 1,
                "Cada formato y los metrados completos deben ejecutar su destino una sola vez por clic.");
            exige(opciones.Where(x => x.Tag is MYGDestinoExportacionCronograma.ProjectTareas or MYGDestinoExportacionCronograma.ProjectRecursos
                    or MYGDestinoExportacionCronograma.XmlTareas or MYGDestinoExportacionCronograma.XmlRecursos)
                .All(x => x.ToolTipText.Contains("cronograma del proyecto", StringComparison.Ordinal)),
                "Project y XML deben indicar que exportan la programación del proyecto.");
        }
        using (var menu = EditorForm.CrearMenuExportarProyecto(
            exportaciones.Add, () => metrados++, false, false))
        {
            var opciones = menu.Items.OfType<ToolStripMenuItem>().ToArray();
            exige(opciones.Where(x => x.Tag is MYGDestinoExportacionCronograma.Pdf or MYGDestinoExportacionCronograma.Xlsx
                    or MYGDestinoExportacionCronograma.Texto or MYGDestinoExportacionCronograma.Mht or MYGDestinoExportacionCronograma.Csv)
                .All(x => !x.Enabled) && !menu.Items["exportar_metrados_completos"].Enabled &&
                menu.Items["presupuesto_exportar_nativo"].Enabled,
                "Sin presupuesto activo deben bloquearse sus informes y metrados, conservando la copia nativa del proyecto.");
        }

        var responsables = new List<string>();
        using (var menu = EditorForm.CrearMenuResponsablesProyecto(
            () => responsables.Add("asignar"), () => responsables.Add("ver"), () => responsables.Add("quitar"), true, true))
        {
            foreach (ToolStripMenuItem opcion in menu.Items) opcion.PerformClick();
            exige(responsables.SequenceEqual(new[] { "asignar", "ver", "quitar" }),
                "Responsables debe reutilizar los comandos de asignación, consulta y retiro, sin acciones vacías.");
        }
        using (var menu = EditorForm.CrearMenuResponsablesProyecto(
            () => responsables.Add("sin-permiso"), () => responsables.Add("ver"), () => responsables.Add("sin-permiso"), false, true))
        {
            exige(!menu.Items[0].Enabled && menu.Items[1].Enabled && !menu.Items[2].Enabled,
                "La consulta de responsables debe conservarse y las modificaciones requieren autorización.");
        }
        using (var menu = EditorForm.CrearMenuResponsablesProyecto(() => { }, () => { }, () => { }, true, false))
        {
            exige(menu.Items[0].Enabled && !menu.Items[2].Enabled,
                "Se puede asignar el primer responsable y no se puede quitar uno inexistente.");
        }

        exige(EditorForm.HerramientaProyectoDisponible(false, false, false) &&
            !EditorForm.HerramientaProyectoDisponible(true, false, false) &&
            EditorForm.HerramientaProyectoDisponible(true, false, true),
            "Inicio, guardado y sesión deben seguir disponibles con sesión vencida; editar requiere autorización.");
        exige(!EditorForm.HerramientaProyectoDisponible(false, true, false) &&
            !EditorForm.HerramientaProyectoDisponible(true, true, true),
            "La barra debe bloquear sus comandos mientras una operación está en curso.");
        VerificarCintaSinCambiarPaneles(exige);
    }

    private static void VerificarCintaSinCambiarPaneles(Action<bool, string> exige)
    {
        var presupuesto = new MYGPresupuestoDocumento { Item = "01", Nombre = "PRESUPUESTO DE PRUEBA", Posicion = 1 };
        var proyecto = new MYGProyectoDocumento { Nombre = "PROYECTO DE PRUEBA", PresupuestoActivoId = presupuesto.Id };
        proyecto.Presupuestos.Add(presupuesto);
        using var sesion = new SesionDesktop();
        using var editor = new EditorForm(proyecto, null, sesion);
        editor.WindowState = FormWindowState.Normal; editor.ClientSize = new Size(1600, 900);
        editor.Show(); Application.DoEvents();
        var controles = Descendientes(editor).ToArray();
        var barra = controles.OfType<FlowLayoutPanel>().Single(x => x.Name == "herramientas_proyecto");
        var botones = barra.Controls.Cast<Button>().ToArray();
        string[] principales = {
            "ir_inicio_button", "guardar_proyecto_button", "imprimir_proyecto_button", "info_proyecto_button", "exportar_proyecto_button",
            "formula_polinomica_button", "calendario_adquisiciones_button", "calendario_valorizado_button", "resumen_costos_button",
            "responsables_proyecto_button", "especificaciones_button", "valorizacion_button", "permisos_proyecto_button",
            "tamano_texto_button"
        };
        exige(barra.Controls.Count == principales.Length && botones.Select(b => b.Name).SequenceEqual(principales) &&
            botones.All(b => b.Image != null),
            "La cinta superior debe conservar sus herramientas en orden y añadir el ajuste de texto con su icono.");
        exige(!controles.OfType<Button>().Any(b => b.Name is "exportar_especificaciones_button" or "alternarTema"),
            "La ventana del proyecto no debe añadir botones superiores de exportar especificaciones ni de cambio de tema.");
        var navegacion = controles.OfType<TabControl>().Single(t => t.TabPages.Cast<TabPage>().Any(p => p.Text == "Configuración BIM / Revit"));
        var pie = controles.OfType<FlowLayoutPanel>().Single(f => f.Controls.OfType<GroupBox>().Any(g => g.Text == "Tablas de planificación"));
        Control[] controlesPie = pie.Controls.Cast<Control>().ToArray();
        exige(controles.OfType<Button>().Any(b => b.Text == "Actualizar activo") &&
            controles.OfType<Button>().Any(b => b.Text == "Federar metrados") &&
            controles.OfType<Button>().Any(b => b.Text == "Crear tablas"),
            "Agregar herramientas superiores debe conservar los botones originales de los ejecutables de BIM y metrados.");
        string firma = MYGProyectoStorage.Firma(proyecto);
        var historial = (Stack<MYGProyectoDocumento>)typeof(EditorForm).GetField("undo", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        int registros = historial.Count, formularios = Application.OpenForms.Count, seleccion = navegacion.SelectedIndex;
        var especificaciones = botones.Single(b => b.Name == "especificaciones_button");
        exige(especificaciones.Enabled && especificaciones.Text == "Especificaciones ▾",
            "El botón Especificaciones existente debe desplegar la exportación sin exigir una sesión de edición.");
        especificaciones.PerformClick(); Application.DoEvents();
        var menus = (System.ComponentModel.Container)typeof(EditorForm).GetField("componentesMenus", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        var menuEspecificaciones = menus.Components.OfType<ContextMenuStrip>().Single(x => x.Name == "menu_especificaciones_proyecto");
        exige(menuEspecificaciones.Visible && menuEspecificaciones.Items.Cast<ToolStripMenuItem>().Select(x => x.Name).SequenceEqual(new[]
                { "exportar_especificaciones_proyecto", "exportar_especificaciones_presupuesto" }) &&
            MYGProyectoStorage.Firma(proyecto) == firma && historial.Count == registros && navegacion.SelectedIndex == seleccion,
            "El botón señalado debe abrir los dos alcances de exportación sin editar partidas, cambiar pestaña ni agregar historial.");
        menuEspecificaciones.Close(); Application.DoEvents();
        var formula = botones.Single(b => b.Name == "formula_polinomica_button");
        exige(formula.Enabled && formula.AccessibleDescription != "Pendiente de implementación.",
            "Fórmula polinómica debe abrir su consulta sin exigir una sesión de edición.");
        foreach (string nombre in new[] { "calendario_adquisiciones_button", "calendario_valorizado_button", "valorizacion_button" })
        {
            var boton = botones.Single(b => b.Name == nombre);
            exige(boton.Enabled && boton.AccessibleDescription == "Pendiente de implementación.",
                "Las herramientas nuevas deben colocarse como accesos pendientes, según lo solicitado.");
            boton.PerformClick(); Application.DoEvents();
            exige(MYGProyectoStorage.Firma(proyecto) == firma && historial.Count == registros &&
                Application.OpenForms.Count == formularios && navegacion.SelectedIndex == seleccion &&
                pie.Controls.Cast<Control>().SequenceEqual(controlesPie),
                "Pulsar una herramienta pendiente no debe sincronizar, modificar el proyecto, agregar historial, abrir formularios ni alterar los controles inferiores.");
        }
        exige(botones.Single(b => b.Name == "ir_inicio_button").Enabled &&
            botones.Single(b => b.Name == "guardar_proyecto_button").Enabled &&
            botones.Single(b => b.Name == "responsables_proyecto_button").Enabled &&
            botones.Single(b => b.Name == "permisos_proyecto_button").Enabled &&
            botones.Single(b => b.Name == "tamano_texto_button").Enabled &&
            !botones.Single(b => b.Name == "info_proyecto_button").Enabled,
            "La cinta real debe permitir volver, guardar e iniciar sesión sin autorización y bloquear la edición de los datos del proyecto.");
    }

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
