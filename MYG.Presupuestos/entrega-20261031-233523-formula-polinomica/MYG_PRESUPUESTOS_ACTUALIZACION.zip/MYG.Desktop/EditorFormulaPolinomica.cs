using System;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private void AbrirFormulaPolinomica()
    {
        if (P == null) throw new InvalidOperationException("Seleccione un presupuesto.");
        var presupuestoActual = P;
        using var ventana = new MYGFormulaPolinomicaForm(presupuestoActual, PuedeModificarProyecto);
        if (ventana.ShowDialog(this) != DialogResult.OK || !ventana.Cambiado) return;
        ExigirPermisoEdicionProyecto();
        var candidato = MYGProyectoStorage.Copia(documento);
        candidato.Presupuestos.Single(p => p.Id == presupuestoActual.Id).FormulaPolinomica = ventana.Configuracion;
        if (vinculoNube?.PermisosModulos != null)
            MYGCambiosModulosNube.ExigirPermitidos(documento, candidato, vinculoNube.PermisosModulos);
        Recordar();
        presupuestoActual.FormulaPolinomica = ventana.Configuracion;
        Refrescar();
        estado.Text = "Fórmula polinómica actualizada. Guarde el proyecto para conservar la configuración.";
    }
}
