using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

/// <summary>Informes independientes de las filas visibles y de los grupos contraídos.</summary>
internal static class MYGFormulaPolinomicaReportes
{
    internal static MYGHojaReporteProyecto CrearDetallado(string nombre, MYGMatrizFormulaPolinomica matriz)
    {
        ArgumentNullException.ThrowIfNull(matriz);
        int columnas = 5 + matriz.Indices.Count;
        ComprobarDimensiones(matriz.Filas.Count + 3, columnas);
        var h = Hoja("Polinómica detallada", columnas);
        h.AnchosColumnas = new() { [1] = 300, [2] = 42, [3] = 85, [4] = 85, [5] = 100 };
        string[] cabeceras = { "Descripción", "Und.", "Metrado", "Precio", "Total" };
        for (int c = 1; c <= cabeceras.Length; c++) Cabecera(h, c, cabeceras[c - 1]);
        for (int i = 0; i < matriz.Indices.Count; i++)
        {
            var indice = matriz.Indices[i];
            Cabecera(h, i + 6, indice.Codigo + "\n" + indice.Descripcion);
            h.AnchosColumnas[i + 6] = 115;
        }
        h.AltosFilas[1] = 56;
        var niveles = new Dictionary<int, int>();
        var porId = matriz.Filas.Where(f => f.Id != null).GroupBy(f => f.Id)
            .ToDictionary(g => g.Key, g => g.First());
        int fila = 2;
        foreach (var partida in matriz.Filas)
        {
            int nivel = 0;
            string padre = partida.ParentId;
            var visitados = new HashSet<string>();
            while (padre != null && visitados.Add(padre) && porId.TryGetValue(padre, out var anterior))
            { nivel++; padre = anterior.ParentId; }
            Texto(h, fila, 1, new string(' ', Math.Min(20, nivel) * 2) +
                ((partida.Item?.Length ?? 0) > 0 ? partida.Item + "  " : "") + partida.Descripcion, partida.EsTitulo);
            Texto(h, fila, 2, partida.Unidad);
            if (!partida.EsTitulo)
            {
                Numero(h, fila, 3, partida.Metrado, "#,##0.0000");
                Numero(h, fila, 4, partida.Precio);
            }
            Numero(h, fila, 5, partida.Total, negrita: partida.EsTitulo);
            for (int i = 0; i < matriz.Indices.Count; i++)
                Numero(h, fila, i + 6, partida.Importes.GetValueOrDefault(matriz.Indices[i].Codigo), negrita: partida.EsTitulo);
            if (partida.EsTitulo) niveles[fila] = nivel;
            h.AltosFilas[fila++] = partida.EsTitulo ? 25 : 22;
        }
        Texto(h, fila, 1, "TOTAL DEL PRESUPUESTO", true);
        Numero(h, fila, 5, matriz.Total, negrita: true);
        for (int i = 0; i < matriz.Indices.Count; i++)
            Numero(h, fila, i + 6, matriz.Indices[i].Total, negrita: true);
        h.CeldaTotal = "E" + fila;
        fila++;
        Texto(h, fila, 1, "COEFICIENTE POR ÍNDICE", true);
        for (int i = 0; i < matriz.Indices.Count; i++)
            Numero(h, fila, i + 6, matriz.Total == 0 ? 0 : matriz.Indices[i].Total / matriz.Total, "0.0000000000", true);
        Terminar(h, fila);
        return new MYGHojaReporteProyecto("FÓRMULA POLINÓMICA · DETALLADO · " + nombre, h,
            nivelesTitulos: niveles, ajustarAUnaPaginaDeAncho: false);
    }

    internal static MYGHojaReporteProyecto CrearFormula(string nombre, MYGResultadoFormulaPolinomica resultado)
    {
        ArgumentNullException.ThrowIfNull(resultado);
        ComprobarDimensiones(resultado.Monomios.Sum(m => 1 + m.Indices.Count) + resultado.Advertencias.Count + 8, 6);
        var h = Hoja("Fórmula polinómica", 6);
        h.AnchosColumnas = new() { [1] = 380, [2] = 85, [3] = 110, [4] = 100, [5] = 100, [6] = 80 };
        string[] cabeceras = { "Descripción", "Nomenclatura", "Importe", "Coef. calculado", "Coef. definido", "% del monomio" };
        for (int c = 1; c <= cabeceras.Length; c++) Cabecera(h, c, cabeceras[c - 1]);
        h.AltosFilas[1] = 38;
        int fila = 2;
        foreach (var monomio in resultado.Monomios)
        {
            Texto(h, fila, 1, monomio.Descripcion, true);
            Texto(h, fila, 2, monomio.Nomenclatura, true);
            Numero(h, fila, 3, monomio.Importe, negrita: true);
            Numero(h, fila, 4, monomio.CoeficienteCalculado, "0.0000000000", true);
            Numero(h, fila, 5, monomio.CoeficienteDefinido, "0.000", true);
            Numero(h, fila, 6, 100, "0.00", true);
            h.AltosFilas[fila++] = 25;
            foreach (var indice in monomio.Indices)
            {
                Texto(h, fila, 1, "    " + indice.Codigo + "  " + indice.Descripcion);
                Numero(h, fila, 3, indice.Total);
                Numero(h, fila, 4, monomio.Importe == 0 ? 0 : monomio.CoeficienteCalculado * indice.Total / monomio.Importe, "0.0000000000");
                Numero(h, fila, 6, monomio.Porcentajes.GetValueOrDefault(indice.Codigo), "0.00");
                h.AltosFilas[fila++] = 22;
            }
        }
        Texto(h, fila, 1, "TOTAL", true);
        Numero(h, fila, 3, resultado.Monomios.Sum(m => m.Importe), negrita: true);
        Numero(h, fila, 4, resultado.TotalCalculado, "0.0000000000", true);
        Numero(h, fila, 5, resultado.TotalDefinido, "0.000", true);
        h.CeldaTotal = "E" + fila;
        fila += 2;
        Texto(h, fila, 1, "EXPRESIÓN DE LA FÓRMULA", true);
        Combinar(h, fila++, 6);
        string coef(decimal n) => n.ToString("0.000", CultureInfo.InvariantCulture);
        var terminos = resultado.Monomios.Select(m =>
        {
            var razones = m.Indices.Select(i => i.Codigo == "SIN_INDICE" ? "[importe sin índice asignado]"
                : (m.Indices.Count == 1 ? "" : (m.Porcentajes.GetValueOrDefault(i.Codigo) / 100m).ToString("0.##########", CultureInfo.InvariantCulture) + " × ")
                    + "I" + i.Codigo + "r/I" + i.Codigo + "o");
            return coef(m.CoeficienteDefinido) + " × (" + string.Join(" + ", razones) + ")";
        });
        string expresion = "K = " + string.Join(" + ", terminos);
        // Distribuir una fórmula larga entre filas evita crear un bloque que
        // exceda la altura de una página y conserva todos sus términos al exportar.
        foreach (string linea in Dividir(expresion, 135))
        { Texto(h, fila, 1, linea); Combinar(h, fila++, 6); }
        Texto(h, fila, 1, "r: período de reajuste; o: período base. Cada monomio agrupado pondera los índices según su incidencia.");
        Combinar(h, fila++, 6);
        foreach (string advertencia in resultado.Advertencias)
        {
            foreach (string linea in Dividir("ADVERTENCIA: " + advertencia, 135))
            {
                Texto(h, fila, 1, linea, true); Combinar(h, fila, 6);
                h.Celdas["A" + fila].ColorTexto = "A43715"; fila++;
            }
        }
        Terminar(h, fila - 1);
        return new MYGHojaReporteProyecto("FÓRMULA POLINÓMICA · " + nombre, h, ajustarAUnaPaginaDeAncho: true);
    }

    private static MYGHojaMetrado Hoja(string nombre, int columnas) => new()
    {
        Nombre = nombre, Columnas = columnas, Filas = 1, CeldaTotal = "A1",
        TamanoPapel = "A4", OrientacionPagina = "Horizontal", FilasInmovilizadas = 1,
        RepetirTitulos = true, LineasDivision = false, Encabezados = false,
        ImprimirLineasDivision = true, ImprimirEncabezados = false,
        FormatoNumeroPredeterminado = "#,##0.00",
        MargenIzquierdo = .35m, MargenDerecho = .35m, MargenSuperior = .45m, MargenInferior = .45m
    };

    private static void Texto(MYGHojaMetrado h, int fila, int columna, string texto, bool negrita = false)
    {
        texto ??= "";
        bool literal = texto.StartsWith('=') || MYGHojaCalculo.IntentarNumero(texto, out _);
        Celda(h, fila, columna, literal ? "=\"" + texto.Replace("\"", "\"\"") + "\"" : texto, "@", negrita, "Izquierda");
    }

    private static void Numero(MYGHojaMetrado h, int fila, int columna, decimal numero,
        string formato = "#,##0.00", bool negrita = false) =>
        Celda(h, fila, columna, numero.ToString(CultureInfo.InvariantCulture), formato, negrita, "Derecha");

    private static void Celda(MYGHojaMetrado h, int fila, int columna, string contenido,
        string formato, bool negrita, string alineacion)
    {
        if (fila > 10000) throw new InvalidDataException("El informe supera las 10.000 filas disponibles.");
        string direccion = MYGHojaCalculo.Columna(columna) + fila;
        h.Celdas[direccion] = new MYGCeldaHoja
        {
            Contenido = contenido, FormatoNumero = formato, Negrita = negrita,
            Fuente = "Arial Narrow", TamanoFuente = 9, ColorTexto = "243746", ColorFondo = "FFFFFF",
            AjustarTexto = true, AlineacionHorizontal = alineacion, AlineacionPersonalizada = true
        };
        h.Filas = Math.Max(h.Filas, fila);
    }

    private static void Cabecera(MYGHojaMetrado h, int columna, string texto)
    {
        Texto(h, 1, columna, texto, true);
        h.Celdas[MYGHojaCalculo.Columna(columna) + "1"].ColorFondo = "DFEAF4";
    }

    private static void Combinar(MYGHojaMetrado h, int fila, int columnas)
    { h.RangosCombinados.Add("A" + fila + ":" + MYGHojaCalculo.Columna(columnas) + fila); h.AltosFilas[fila] = 28; }

    private static void Terminar(MYGHojaMetrado h, int fila)
    {
        ComprobarDimensiones(fila, h.Columnas);
        h.Filas = fila;
        h.AreaImpresion = "A1:" + MYGHojaCalculo.Columna(h.Columnas) + fila;
    }

    private static void ComprobarDimensiones(int filas, int columnas)
    {
        if (filas > 10000 || columnas > 200 || (long)filas * columnas > 200000)
            throw new InvalidDataException("El informe supera las dimensiones de hoja admitidas. Divida el presupuesto antes de imprimir o exportar.");
    }

    private static IEnumerable<string> Dividir(string texto, int maximo)
    {
        while (texto.Length > maximo)
        {
            int corte = texto.LastIndexOf(' ', maximo);
            if (corte < maximo / 2) corte = maximo;
            yield return texto[..corte]; texto = texto[corte..].TrimStart();
        }
        yield return texto;
    }
}
