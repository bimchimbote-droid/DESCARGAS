using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Edición sobre una copia: cerrar o cancelar nunca altera el presupuesto.</summary>
internal sealed class MYGFormulaPolinomicaForm : Form
{
    private readonly MYGPresupuestoDocumento presupuesto;
    private readonly bool puedeEditar;
    private readonly Font fuenteNegrita;
    private MYGMatrizFormulaPolinomica matriz;
    private MYGConfiguracionFormulaPolinomica configuracion;
    private readonly string configuracionInicial;
    private readonly Stack<MYGConfiguracionFormulaPolinomica> historial = new();
    private readonly HashSet<string> gruposPlegados = new(StringComparer.Ordinal);
    private readonly HashSet<string> titulosPlegados = new(StringComparer.Ordinal);
    private readonly DataGridView detalle = Tabla("polinomica_detalle");
    private readonly DataGridView monomios = Tabla("polinomica_monomios");
    private readonly Label avisos = new() { Name = "polinomica_avisos", Dock = DockStyle.Top, AutoSize = true,
        MaximumSize = new Size(1600, 0), Padding = new Padding(8), AccessibleName = "Avisos de la fórmula polinómica" };
    private readonly Label totalDetalle = new() { Name = "polinomica_total_detalle", Dock = DockStyle.Bottom, Height = 28,
        TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8, 0, 0, 0) };
    private readonly Label totalFormula = new() { Name = "polinomica_total_formula", Dock = DockStyle.Bottom, Height = 44,
        TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8, 0, 0, 0), AutoEllipsis = true };
    private readonly Button aplicar, deshacer;
    private readonly List<Button> botonesEdicion = new();
    private bool llenando;
    private Point inicioArrastre;
    private FilaMonomio origenArrastre;
    private sealed record FilaMonomio(string GrupoId, string CodigoIndice = null);
    internal MYGConfiguracionFormulaPolinomica Configuracion => MYGProyectoStorage.Copia(configuracion);
    internal MYGResultadoFormulaPolinomica Resultado { get; private set; }
    internal bool Cambiado => Serializar(configuracion) != configuracionInicial;
    internal int CantidadPreparaciones { get; private set; }

    internal MYGFormulaPolinomicaForm(MYGPresupuestoDocumento presupuesto, bool puedeEditar)
    {
        this.presupuesto = MYGProyectoStorage.Copia(presupuesto ?? throw new ArgumentNullException(nameof(presupuesto)));
        this.puedeEditar = puedeEditar;
        matriz = MYGFormulaPolinomica.Preparar(this.presupuesto); CantidadPreparaciones++;
        configuracion = MYGFormulaPolinomica.CrearConfiguracion(matriz, this.presupuesto.FormulaPolinomica);
        configuracionInicial = Serializar(configuracion);
        Name = "formula_polinomica_form";
        Text = "Fórmula polinómica · " + presupuesto.Nombre;
        StartPosition = FormStartPosition.CenterParent;
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96, 96);
        ClientSize = new Size(1420, 860); MinimumSize = new Size(980, 640);
        Font = new Font("Segoe UI", 9);
        fuenteNegrita = new Font(Font, FontStyle.Bold);
        Disposed += (_, _) => fuenteNegrita.Dispose();
        KeyPreview = true;

        var cinta = new FlowLayoutPanel { Name = "polinomica_cinta", Dock = DockStyle.Top, Height = 86,
            WrapContents = false, AutoScroll = true, Padding = new Padding(6) };
        Button Comando(string texto, string nombre, string icono, Action accion)
        {
            var boton = EditorForm.CrearBotonCintaProyecto(icono, texto, false);
            boton.Name = nombre; boton.Width = 103; boton.Margin = new Padding(2);
            boton.Click += (_, _) => Intentar(accion); cinta.Controls.Add(boton); return boton;
        }
        Comando("Volver", "polinomica_volver", "proyecto", Close);
        Comando("Imprimir\ndetallado", "polinomica_imprimir_detalle", "imprimir", () => Imprimir(true));
        Comando("Imprimir\nfórmula", "polinomica_imprimir_formula", "imprimir", () => Imprimir(false));
        Comando("Actualizar", "polinomica_actualizar", "actualizar", Actualizar);
        Comando("Exportar\nExcel", "polinomica_excel", "excel", ExportarExcel);
        deshacer = Comando("Deshacer", "polinomica_deshacer", "editar", () => Deshacer());
        aplicar = Comando("Aplicar", "polinomica_aplicar", "guardar", Aplicar);
        aplicar.Enabled = puedeEditar;
        var contexto = new Label { AutoSize = true, Margin = new Padding(14, 18, 4, 4), Text = puedeEditar
            ? "Arrastre un índice o monomio sobre otro para agrupar.\nAplicar incorpora los cambios al proyecto; después guarde."
            : "Solo lectura. Puede consultar, imprimir y exportar la fórmula." };
        cinta.Controls.Add(contexto);

        var division = new SplitContainer { Name = "polinomica_division", Dock = DockStyle.Fill,
            Orientation = Orientation.Horizontal, SplitterWidth = 7,
            Size = new Size(1380, 720), SplitterDistance = 325, Panel1MinSize = 130, Panel2MinSize = 180 };
        division.Panel1.Controls.Add(detalle); division.Panel1.Controls.Add(totalDetalle);
        division.Panel2.Controls.Add(monomios); division.Panel2.Controls.Add(totalFormula);
        division.Panel2.Controls.Add(avisos);
        var acciones = new FlowLayoutPanel { Name = "polinomica_acciones", Dock = DockStyle.Right, Width = 115,
            FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(4) };
        void Accion(string texto, string nombre, Action accion)
        {
            var b = MYGProyectoUI.Boton(texto); b.Name = nombre; b.Size = new Size(100, 34);
            b.Enabled = puedeEditar; b.Click += (_, _) => Intentar(accion);
            acciones.Controls.Add(b); botonesEdicion.Add(b);
        }
        Accion("↑ Subir", "polinomica_subir", () => Mover(Seleccion()?.GrupoId, -1));
        Accion("↓ Bajar", "polinomica_bajar", () => Mover(Seleccion()?.GrupoId, 1));
        Accion("Agrupar…", "polinomica_agrupar", AgruparSeleccion);
        Accion("Desagrupar", "polinomica_desagrupar", () =>
        { var fila = Seleccion(); if (fila != null) Separar(fila.GrupoId, fila.CodigoIndice); });
        division.Panel2.Controls.Add(acciones);
        Controls.Add(division); Controls.Add(cinta);
        ConfigurarDetalle(); ConfigurarMonomios();
        void Tema(object sender, EventArgs e) => AplicarTema();
        MYG2027_TemaComercial.CambioTema += Tema;
        Disposed += (_, _) => MYG2027_TemaComercial.CambioTema -= Tema;
        PrepararMenu(detalle, false); PrepararMenu(monomios, true);
        AplicarTema(); RefrescarDetalle(); RefrescarFormula();
    }

    private static DataGridView Tabla(string nombre) => new()
    {
        Name = nombre, Dock = DockStyle.Fill, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        AllowUserToResizeRows = false, RowHeadersVisible = false, MultiSelect = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoGenerateColumns = false,
        ColumnHeadersHeight = 44, ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
        RowTemplate = { Height = 25 }, BorderStyle = BorderStyle.FixedSingle,
        EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2, ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
    };

    private static void Columna(DataGridView tabla, string nombre, string texto, int ancho, string formato = null)
    {
        var columna = new DataGridViewTextBoxColumn { Name = nombre, HeaderText = texto, Width = ancho,
            SortMode = DataGridViewColumnSortMode.NotSortable, ReadOnly = true };
        columna.DefaultCellStyle.Format = formato;
        columna.DefaultCellStyle.Alignment = formato == null ? DataGridViewContentAlignment.MiddleLeft : DataGridViewContentAlignment.MiddleRight;
        tabla.Columns.Add(columna);
    }

    private void ConfigurarDetalle()
    {
        detalle.ReadOnly = true;
        detalle.CellClick += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 0 || detalle.Rows[e.RowIndex].Tag is not MYGFilaFormulaPolinomica fila || !fila.EsTitulo) return;
            if (!FinalizarEdicion()) return;
            if (!titulosPlegados.Add(fila.Id)) titulosPlegados.Remove(fila.Id);
            RefrescarDetalle();
        };
    }

    private void RefrescarDetalle()
    {
        detalle.SuspendLayout();
        try
        {
            detalle.Rows.Clear(); detalle.Columns.Clear();
            Columna(detalle, "DESCRIPCION", "Descripción", 360);
            Columna(detalle, "UNIDAD", "Und.", 54);
            Columna(detalle, "METRADO", "Metrado", 95, "N2");
            Columna(detalle, "PRECIO", "Precio", 88, "N2");
            Columna(detalle, "TOTAL", "Total", 110, "N2");
            detalle.Columns["DESCRIPCION"].Frozen = true;
            foreach (var indice in matriz.Indices)
            {
                Columna(detalle, "IU_" + indice.Codigo, indice.Codigo + "\n" + indice.Descripcion, 114, "N2");
                detalle.Columns[^1].ToolTipText = indice.Codigo + " · " + indice.Descripcion;
            }
            var padres = matriz.Filas.Where(x => x.Id != null).GroupBy(x => x.Id).ToDictionary(g => g.Key, g => g.First());
            foreach (var fila in matriz.Filas)
            {
                int nivel = 0; bool visible = true;
                string padre = fila.ParentId; var visitados = new HashSet<string>();
                while (padre != null && visitados.Add(padre) && padres.TryGetValue(padre, out var p))
                {
                    nivel++;
                    if (titulosPlegados.Contains(padre)) { visible = false; break; }
                    padre = p.ParentId;
                }
                if (!visible) continue;
                string texto = new string(' ', Math.Min(nivel, 15) * 3)
                    + (fila.EsTitulo ? titulosPlegados.Contains(fila.Id) ? "▸ " : "▾ " : "  ")
                    + (string.IsNullOrWhiteSpace(fila.Item) ? "" : fila.Item + "  ") + fila.Descripcion;
                var valores = new List<object> { texto, fila.Unidad, fila.EsTitulo ? null : fila.Metrado,
                    fila.EsTitulo ? null : fila.Precio, fila.Total };
                valores.AddRange(matriz.Indices.Select(i => fila.Importes.GetValueOrDefault(i.Codigo) is var valor && valor != 0 ? (object)valor : null));
                var row = detalle.Rows[detalle.Rows.Add(valores.ToArray())]; row.Tag = fila;
                if (fila.EsTitulo) row.DefaultCellStyle.Font = fuenteNegrita;
            }
            var totales = new List<object> { "TOTAL", "", null, null, matriz.Total };
            totales.AddRange(matriz.Indices.Select(i => (object)i.Total));
            var total = detalle.Rows[detalle.Rows.Add(totales.ToArray())]; total.DefaultCellStyle.Font = fuenteNegrita;
            totalDetalle.Text = $"Costo directo desglosado: {matriz.Total:N2} · Índices: {matriz.Indices.Count}";
        }
        finally { detalle.ResumeLayout(); }
    }

    private void ConfigurarMonomios()
    {
        monomios.ReadOnly = !puedeEditar;
        Columna(monomios, "DESCRIPCION", "Descripción", 520);
        Columna(monomios, "NOMENCLATURA", "Nomenclatura", 120);
        Columna(monomios, "CALCULADO", "Coef. calculado", 155, "0.0000000000");
        Columna(monomios, "DEFINIDO", "Coef. definido", 140, "0.000");
        Columna(monomios, "PORCENTAJE", "%", 100, "0.00");
        foreach (string nombre in new[] { "DESCRIPCION", "NOMENCLATURA", "DEFINIDO" }) monomios.Columns[nombre].ReadOnly = !puedeEditar;
        monomios.CellBeginEdit += (_, e) =>
        {
            if (!puedeEditar || monomios.Rows[e.RowIndex].Tag is not FilaMonomio { CodigoIndice: null }) e.Cancel = true;
        };
        monomios.CellValidating += (_, e) =>
        {
            if (llenando || !monomios.IsCurrentCellInEditMode || monomios.Rows[e.RowIndex].Tag is not FilaMonomio { CodigoIndice: null } fila) return;
            string texto = Convert.ToString(e.FormattedValue)?.Trim() ?? "";
            string columna = monomios.Columns[e.ColumnIndex].Name;
            string error = columna switch
            {
                "DESCRIPCION" when texto.Length == 0 || texto.Length > 200 => "Escriba una descripción de 1 a 200 caracteres.",
                "NOMENCLATURA" when texto.Length == 0 || texto.Length > 12 || texto.Any(c => !char.IsLetterOrDigit(c) && c != '_') => "Use de 1 a 12 letras o números para la nomenclatura.",
                "NOMENCLATURA" when configuracion.Grupos.Any(g => g.Id != fila.GrupoId && string.Equals(g.Nomenclatura, texto, StringComparison.OrdinalIgnoreCase)) => "La nomenclatura ya está en uso.",
                "DEFINIDO" when !MYGHojaCalculo.IntentarNumero(texto, out decimal n) || n < 0 || n > 1 || decimal.Round(n, 3) != n => "Indique un coeficiente de 0 a 1, con un máximo de tres decimales.",
                _ => null
            };
            e.Cancel = error != null;
            monomios.Rows[e.RowIndex].ErrorText = error ?? "";
        };
        monomios.CellEndEdit += (_, e) =>
        {
            if (llenando || !puedeEditar || monomios.Rows[e.RowIndex].Tag is not FilaMonomio { CodigoIndice: null } fila) return;
            string valor = Convert.ToString(monomios.Rows[e.RowIndex].Cells[e.ColumnIndex].Value)?.Trim() ?? "";
            string columna = monomios.Columns[e.ColumnIndex].Name;
            var anterior = MYGProyectoStorage.Copia(configuracion);
            var grupo = configuracion.Grupos.Single(g => g.Id == fila.GrupoId);
            if (columna == "DESCRIPCION") grupo.Descripcion = valor;
            else if (columna == "NOMENCLATURA") grupo.Nomenclatura = valor;
            else if (columna == "DEFINIDO" && MYGHojaCalculo.IntentarNumero(valor, out var numero)) grupo.CoeficienteDefinido = numero;
            if (Serializar(anterior) != Serializar(configuracion)) historial.Push(anterior);
            BeginInvoke(new Action(() => { if (!IsDisposed) RefrescarFormula(fila.GrupoId); }));
        };
        monomios.DataError += (_, e) => { e.ThrowException = false; if (e.RowIndex >= 0) monomios.Rows[e.RowIndex].ErrorText = "Revise el valor introducido."; };
        monomios.CellClick += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 0 || monomios.Rows[e.RowIndex].Tag is not FilaMonomio { CodigoIndice: null } fila) return;
            var punto = monomios.PointToClient(MousePosition);
            if (punto.X - monomios.GetCellDisplayRectangle(0, e.RowIndex, false).Left > 20) return;
            if (!FinalizarEdicion()) return;
            if (!gruposPlegados.Add(fila.GrupoId)) gruposPlegados.Remove(fila.GrupoId);
            RefrescarFormula(fila.GrupoId);
        };
        monomios.CellPainting += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 0 || monomios.Rows[e.RowIndex].Tag is not FilaMonomio { CodigoIndice: null } fila) return;
            e.Paint(e.ClipBounds, e.PaintParts);
            var area = new Rectangle(e.CellBounds.Left + 2, e.CellBounds.Top, 18, e.CellBounds.Height);
            TextRenderer.DrawText(e.Graphics, gruposPlegados.Contains(fila.GrupoId) ? "▸" : "▾", monomios.Font, area,
                e.CellStyle.ForeColor, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            e.Handled = true;
        };
        monomios.AllowDrop = puedeEditar;
        monomios.MouseDown += (_, e) =>
        {
            inicioArrastre = e.Location;
            int row = monomios.HitTest(e.X, e.Y).RowIndex;
            origenArrastre = e.Button == MouseButtons.Left && row >= 0 ? monomios.Rows[row].Tag as FilaMonomio : null;
        };
        monomios.MouseMove += (_, e) =>
        {
            if (!puedeEditar || e.Button != MouseButtons.Left || origenArrastre == null ||
                Math.Abs(e.X - inicioArrastre.X) + Math.Abs(e.Y - inicioArrastre.Y) < SystemInformation.DragSize.Width) return;
            var origen = origenArrastre; origenArrastre = null;
            monomios.DoDragDrop(origen, DragDropEffects.Move);
        };
        monomios.DragOver += (_, e) =>
        {
            var punto = monomios.PointToClient(new Point(e.X, e.Y));
            int row = monomios.HitTest(punto.X, punto.Y).RowIndex;
            var origen = e.Data?.GetData(typeof(FilaMonomio)) as FilaMonomio;
            e.Effect = puedeEditar && origen != null && row >= 0 && monomios.Rows[row].Tag is FilaMonomio destino
                && destino.GrupoId != origen.GrupoId ? DragDropEffects.Move : DragDropEffects.None;
        };
        monomios.DragDrop += (_, e) => Intentar(() =>
        {
            var punto = monomios.PointToClient(new Point(e.X, e.Y));
            int row = monomios.HitTest(punto.X, punto.Y).RowIndex;
            if (row >= 0 && e.Data?.GetData(typeof(FilaMonomio)) is FilaMonomio origen && monomios.Rows[row].Tag is FilaMonomio destino)
                Agrupar(origen.GrupoId, destino.GrupoId, origen.CodigoIndice);
        });
    }

    private void RefrescarFormula(string seleccionar = null)
    {
        Resultado = MYGFormulaPolinomica.CalcularAgrupacion(matriz, configuracion);
        llenando = true; monomios.SuspendLayout();
        try
        {
            monomios.Rows.Clear();
            foreach (var grupo in Resultado.Monomios)
            {
                bool plegado = gruposPlegados.Contains(grupo.Id);
                var row = monomios.Rows[monomios.Rows.Add(grupo.Descripcion,
                    grupo.Nomenclatura, grupo.CoeficienteCalculado, grupo.CoeficienteDefinido, 100m)];
                row.Tag = new FilaMonomio(grupo.Id); row.DefaultCellStyle.Font = fuenteNegrita;
                row.Cells[0].Style.Padding = new Padding(18, 0, 0, 0);
                if (grupo.CoeficienteDefinido < .05m) row.ErrorText = "El coeficiente definido es menor de 0.05. Revise la agrupación.";
                if (grupo.Id == seleccionar) monomios.CurrentCell = row.Cells[0];
                if (plegado) continue;
                foreach (var indice in grupo.Indices)
                {
                    var hijo = monomios.Rows[monomios.Rows.Add("      " + indice.Codigo + "  " + indice.Descripcion,
                        "", matriz.Total == 0 ? 0 : indice.Total / matriz.Total,
                        decimal.Round(matriz.Total == 0 ? 0 : indice.Total / matriz.Total, 3, MidpointRounding.AwayFromZero),
                        grupo.Porcentajes.GetValueOrDefault(indice.Codigo))];
                    hijo.Tag = new FilaMonomio(grupo.Id, indice.Codigo); hijo.ReadOnly = true;
                }
            }
            var total = monomios.Rows[monomios.Rows.Add("TOTAL", "", Resultado.TotalCalculado, Resultado.TotalDefinido, null)];
            total.ReadOnly = true; total.DefaultCellStyle.Font = fuenteNegrita;
            avisos.Text = string.Join("\n", Resultado.Advertencias);
            avisos.Visible = Resultado.Advertencias.Count > 0;
            totalFormula.Text = $"Monomios: {Resultado.Monomios.Count} / 8 · Coef. calculado: {Resultado.TotalCalculado:0.0000000000} · Coef. definido: {Resultado.TotalDefinido:0.000}\n"
                + "Los porcentajes de cada índice se calculan dentro de su monomio. El arrastre mueve el aporte, sin duplicarlo.";
            deshacer.Enabled = puedeEditar && historial.Count > 0;
        }
        finally { llenando = false; monomios.ResumeLayout(); }
    }

    internal bool Agrupar(string origenId, string destinoId, string indice = null, bool confirmar = true)
    {
        if (!puedeEditar || origenId == destinoId) return false;
        if (!FinalizarEdicion()) return false;
        var origen = configuracion.Grupos.SingleOrDefault(g => g.Id == origenId);
        var destino = configuracion.Grupos.SingleOrDefault(g => g.Id == destinoId);
        if (origen == null || destino == null || indice != null && !origen.Indices.Contains(indice)) return false;
        string descripcion = indice == null ? origen.Descripcion : matriz.Indices.First(i => i.Codigo == indice).Descripcion;
        if (confirmar && MessageBox.Show(this, $"¿Mover «{descripcion}» al monomio «{destino.Descripcion}»?\n\nEl importe se retirará del origen y se sumará una sola vez al destino.",
            "Agrupar monomios", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return false;
        historial.Push(MYGProyectoStorage.Copia(configuracion));
        var codigos = indice == null ? origen.Indices.ToArray() : new[] { indice };
        foreach (var codigo in codigos) { origen.Indices.Remove(codigo); if (!destino.Indices.Contains(codigo)) destino.Indices.Add(codigo); }
        // Los coeficientes definidos anteriores ya no representan la agrupación nueva.
        origen.CoeficienteDefinido = destino.CoeficienteDefinido = null;
        if (origen.Indices.Count == 0) configuracion.Grupos.Remove(origen);
        gruposPlegados.Remove(destino.Id); RefrescarFormula(destino.Id); return true;
    }

    internal bool Separar(string grupoId, string indice = null)
    {
        if (!puedeEditar) return false;
        if (!FinalizarEdicion()) return false;
        var grupo = configuracion.Grupos.SingleOrDefault(g => g.Id == grupoId);
        if (grupo == null || grupo.Indices.Count < 2 || indice != null && !grupo.Indices.Contains(indice)) return false;
        historial.Push(MYGProyectoStorage.Copia(configuracion));
        var separar = indice == null ? grupo.Indices.Skip(1).ToArray() : new[] { indice };
        int posicion = configuracion.Grupos.IndexOf(grupo) + 1;
        foreach (string codigo in separar)
        {
            grupo.Indices.Remove(codigo);
            var nuevo = MYGFormulaPolinomica.CrearConfiguracion(matriz).Grupos.Single(g => g.Indices.Contains(codigo));
            nuevo.Id = MYGProyectoStorage.NuevoId();
            string baseNombre = nuevo.Nomenclatura; int sufijo = 2;
            while (configuracion.Grupos.Any(g => g.Nomenclatura == nuevo.Nomenclatura)) nuevo.Nomenclatura = baseNombre + sufijo++;
            configuracion.Grupos.Insert(posicion++, nuevo);
        }
        grupo.CoeficienteDefinido = null; RefrescarFormula(grupoId); return true;
    }

    internal bool Mover(string grupoId, int delta)
    {
        if (!puedeEditar || delta is not (-1 or 1)) return false;
        if (!FinalizarEdicion()) return false;
        int actual = configuracion.Grupos.FindIndex(g => g.Id == grupoId), destino = actual + delta;
        if (actual < 0 || destino < 0 || destino >= configuracion.Grupos.Count) return false;
        historial.Push(MYGProyectoStorage.Copia(configuracion));
        (configuracion.Grupos[actual], configuracion.Grupos[destino]) = (configuracion.Grupos[destino], configuracion.Grupos[actual]);
        RefrescarFormula(grupoId); return true;
    }

    internal bool Deshacer()
    {
        if (!puedeEditar || !FinalizarEdicion() || !historial.TryPop(out var anterior)) return false;
        configuracion = anterior; RefrescarFormula(); return true;
    }

    private void AgruparSeleccion()
    {
        var fila = Seleccion(); if (fila == null) return;
        var otros = configuracion.Grupos.Where(g => g.Id != fila.GrupoId).ToList(); if (otros.Count == 0) return;
        using var elegir = new Form { Text = "Agrupar en otro monomio", StartPosition = FormStartPosition.CenterParent,
            ClientSize = new Size(440, 135), FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false };
        var lista = new ComboBox { Name = "polinomica_destino", DropDownStyle = ComboBoxStyle.DropDownList,
            Left = 12, Top = 35, Width = 414, DisplayMember = "Descripcion", DataSource = otros };
        elegir.Controls.Add(new Label { Text = "Seleccione el monomio de destino:", AutoSize = true, Left = 12, Top = 12 });
        elegir.Controls.Add(lista);
        var aceptar = MYGProyectoUI.Boton("Continuar"); aceptar.SetBounds(212, 85, 104, 32); aceptar.DialogResult = DialogResult.OK;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.SetBounds(322, 85, 104, 32); cancelar.DialogResult = DialogResult.Cancel;
        elegir.Controls.AddRange(new Control[] { aceptar, cancelar }); elegir.AcceptButton = aceptar; elegir.CancelButton = cancelar;
        MYG2027_TemaComercial.Aplicar(elegir);
        if (elegir.ShowDialog(this) == DialogResult.OK && lista.SelectedItem is MYGGrupoFormulaPolinomica destino)
            Agrupar(fila.GrupoId, destino.Id, fila.CodigoIndice);
    }

    private FilaMonomio Seleccion() => monomios.CurrentRow?.Tag as FilaMonomio;
    private static string Serializar(MYGConfiguracionFormulaPolinomica valor) => JsonSerializer.Serialize(valor);
    private void Actualizar()
    {
        if (!FinalizarEdicion()) return;
        matriz = MYGFormulaPolinomica.Preparar(presupuesto); CantidadPreparaciones++;
        configuracion = MYGFormulaPolinomica.CrearConfiguracion(matriz, configuracion);
        RefrescarDetalle(); RefrescarFormula();
    }
    private void Aplicar()
    {
        if (!puedeEditar || !FinalizarEdicion()) return;
        DialogResult = DialogResult.OK; Close();
    }
    private void Imprimir(bool detallado)
    {
        if (!FinalizarEdicion()) return;
        var reporte = detallado ? MYGFormulaPolinomicaReportes.CrearDetallado(presupuesto.Nombre, matriz)
            : MYGFormulaPolinomicaReportes.CrearFormula(presupuesto.Nombre, Resultado);
        MYGReportesImpresion.Imprimir(this, reporte.Titulo, new[] { reporte }, () => reporte);
    }
    private void ExportarExcel()
    {
        if (!FinalizarEdicion()) return;
        using var guardar = new SaveFileDialog { Title = "Exportar fórmula polinómica", Filter = "Libro Excel (*.xlsx)|*.xlsx",
            FileName = "Formula_polinomica.xlsx", DefaultExt = "xlsx", AddExtension = true };
        if (guardar.ShowDialog(this) != DialogResult.OK) return;
        var reportes = new[] { MYGFormulaPolinomicaReportes.CrearDetallado(presupuesto.Nombre, matriz),
            MYGFormulaPolinomicaReportes.CrearFormula(presupuesto.Nombre, Resultado) };
        MYGExcelPresupuestos.Guardar(guardar.FileName, MYGReportesExcel.CrearHojas(reportes));
    }
    private bool FinalizarEdicion()
    {
        if (!ValidateChildren() || !monomios.EndEdit()) return false;
        Resultado = MYGFormulaPolinomica.CalcularAgrupacion(matriz, configuracion);
        return true;
    }
    private void PrepararMenu(DataGridView tabla, bool esFormula)
    {
        var menu = new ContextMenuStrip(); tabla.ContextMenuStrip = menu;
        tabla.Disposed += (_, _) => menu.Dispose();
        void Item(string texto, Action accion) => menu.Items.Add(texto, null, (_, _) => Intentar(accion));
        Item("Copiar selección", () => { var datos = tabla.GetClipboardContent(); if (datos != null) Clipboard.SetDataObject(datos); });
        Item("Copiar todo", () =>
        {
            var filas = new List<string> { string.Join("\t", tabla.Columns.Cast<DataGridViewColumn>().Select(c => c.HeaderText.Replace('\n', ' '))) };
            filas.AddRange(tabla.Rows.Cast<DataGridViewRow>().Select(r => string.Join("\t", r.Cells.Cast<DataGridViewCell>().Select(c => Convert.ToString(c.FormattedValue)))));
            Clipboard.SetText(string.Join(Environment.NewLine, filas));
        });
        Item("Exportar Excel…", ExportarExcel);
        menu.Items.Add(new ToolStripSeparator());
        Item("Expandir todo", () => { if (!FinalizarEdicion()) return; if (esFormula) { gruposPlegados.Clear(); RefrescarFormula(); } else { titulosPlegados.Clear(); RefrescarDetalle(); } });
        Item("Contraer todo", () =>
        {
            if (!FinalizarEdicion()) return;
            if (esFormula) { gruposPlegados.UnionWith(configuracion.Grupos.Select(g => g.Id)); RefrescarFormula(); }
            else { titulosPlegados.UnionWith(matriz.Filas.Where(f => f.EsTitulo).Select(f => f.Id)); RefrescarDetalle(); }
        });
    }
    private void AplicarTema()
    {
        MYG2027_TemaComercial.Aplicar(this);
        foreach (var tabla in new[] { detalle, monomios })
        {
            tabla.BackgroundColor = MYG2027_TemaComercial.Superficie;
            tabla.DefaultCellStyle.BackColor = MYG2027_TemaComercial.Superficie;
            tabla.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
            tabla.ColumnHeadersDefaultCellStyle.BackColor = MYG2027_TemaComercial.AzulSuave;
            tabla.ColumnHeadersDefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
            tabla.EnableHeadersVisualStyles = false;
        }
        avisos.ForeColor = MYG2027_TemaComercial.Oscuro ? Color.LightSalmon : Color.Firebrick;
    }
    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception error) { MYGProyectoUI.Error(this, error); }
    }
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (keyData == (Keys.Control | Keys.Z) && !monomios.IsCurrentCellInEditMode) { Deshacer(); return true; }
        if (keyData == Keys.Escape) { Close(); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }
}
