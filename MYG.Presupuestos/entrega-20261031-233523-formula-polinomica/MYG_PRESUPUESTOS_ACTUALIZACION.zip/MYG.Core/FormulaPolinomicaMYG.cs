using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

public sealed class MYGConfiguracionFormulaPolinomica
{
    public List<MYGGrupoFormulaPolinomica> Grupos { get; set; } = new();
}

public sealed class MYGGrupoFormulaPolinomica
{
    public string Id { get; set; } = MYGProyectoStorage.NuevoId();
    public string Descripcion { get; set; } = "";
    public string Nomenclatura { get; set; } = "";
    public List<string> Indices { get; set; } = new();
    public decimal? CoeficienteDefinido { get; set; }
}

public sealed class MYGFilaFormulaPolinomica
{
    public string Id { get; set; }
    public string ParentId { get; set; }
    public string Item { get; set; }
    public string Descripcion { get; set; }
    public string Unidad { get; set; }
    public decimal Metrado { get; set; }
    public decimal Precio { get; set; }
    public decimal Total { get; set; }
    public bool EsTitulo { get; set; }
    public Dictionary<string, decimal> Importes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class MYGIndiceFormulaPolinomica
{
    public string Codigo { get; set; }
    public string Descripcion { get; set; }
    public decimal Total { get; set; }
}

/// <summary>Instantánea del presupuesto: reconstruir tras editar costos o metrados.
/// Agrupar y ordenar monomios no vuelve a recorrer los ACU.</summary>
public sealed class MYGMatrizFormulaPolinomica
{
    public List<MYGFilaFormulaPolinomica> Filas { get; set; } = new();
    public List<MYGIndiceFormulaPolinomica> Indices { get; set; } = new();
    public decimal Total { get; set; }
}

public sealed class MYGMonomioFormulaPolinomica
{
    public string Id { get; set; }
    public string Descripcion { get; set; }
    public string Nomenclatura { get; set; }
    public List<MYGIndiceFormulaPolinomica> Indices { get; set; } = new();
    public decimal Importe { get; set; }
    public decimal CoeficienteCalculado { get; set; }
    public decimal CoeficienteDefinido { get; set; }
    public Dictionary<string, decimal> Porcentajes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class MYGResultadoFormulaPolinomica
{
    public List<MYGMonomioFormulaPolinomica> Monomios { get; set; } = new();
    public List<string> Advertencias { get; set; } = new();
    public decimal TotalCalculado { get; set; }
    public decimal TotalDefinido { get; set; }
}

public static class MYGFormulaPolinomica
{
    public const string SinIndice = "SIN_INDICE";

    /// <summary>Desglosa exclusivamente el costo directo. No atribuye gastos,
    /// precios directos ni diferencias de redondeo a un índice supuesto.</summary>
    public static MYGMatrizFormulaPolinomica Preparar(MYGPresupuestoDocumento presupuesto)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        var matriz = new MYGMatrizFormulaPolinomica();
        var calculo = MYGMotorPresupuestos.CrearCalculo(presupuesto);
        var nombres = MYGCatalogoIndicesUnificados.Listar().ToDictionary(x => x.Codigo, x => x.Descripcion, StringComparer.OrdinalIgnoreCase);
        var totales = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
        string Indice(MYGInsumo insumo)
        {
            string codigo = MYGCatalogoIndicesUnificados.CodigoDeClasificacion(insumo?.GrupoGenerico);
            if (string.IsNullOrEmpty(codigo)) return SinIndice;
            if (!nombres.ContainsKey(codigo))
            {
                string texto = (insumo.GrupoGenerico ?? "").Trim();
                nombres[codigo] = texto.Length > codigo.Length ? texto[codigo.Length..].Trim(' ', '·', '-') : "Índice " + codigo;
            }
            return codigo;
        }
        static void Sumar(Dictionary<string, decimal> d, string clave, decimal importe)
        { if (importe != 0) d[clave] = d.GetValueOrDefault(clave) + importe; }
        var desgloses = new Dictionary<(ItemPresupuestoDelphin Partida, decimal Factor), Dictionary<string, decimal>>();
        Dictionary<string, decimal> Desglosar(ItemPresupuestoDelphin partida, decimal factor, HashSet<string> camino)
        {
            string id = partida.IdLocalMYG ?? partida.Id;
            if (camino.Count >= 64 || !camino.Add(id)) throw new InvalidDataException("Referencia circular en fórmula polinómica.");
            try
            {
                // La clave incluye la cantidad: el redondeo monetario depende
                // del factor. No reutilizar un desglose unitario escalado.
                if (desgloses.TryGetValue((partida, factor), out var guardado)) return guardado;
                var salida = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
                var analisis = calculo.Analizar(partida);
                bool nativo = calculo.ConservaRecursosDelphin(partida);
                string indicePorcentaje = null;
                foreach (var r in analisis.Recursos)
                {
                    decimal importe = nativo ? factor * r.Total : MYGMotorPresupuestos.Dinero(presupuesto, factor * r.Total);
                    if (r.Recurso.Grupo == MYGGrupoRecurso.Subpartidas)
                    {
                        var desglose = Desglosar(calculo.Subpartida(r.Recurso.SubpartidaIdLocal), factor * r.Cantidad, camino);
                        foreach (var par in desglose) Sumar(salida, par.Key, par.Value);
                        Sumar(salida, SinIndice, importe - desglose.Values.Sum());
                    }
                    else
                    {
                        string indice = Indice(calculo.Insumo(r.Recurso.InsumoId));
                        Sumar(salida, indice, importe);
                        if (nativo && string.Equals(r.Unidad, "%mo", StringComparison.OrdinalIgnoreCase)) indicePorcentaje ??= indice;
                    }
                }
                decimal diferencia = MYGMotorPresupuestos.Dinero(presupuesto, factor * analisis.PrecioUnitario) - salida.Values.Sum();
                // Conciliar como el consolidado nativo sólo cuando ya existe el
                // recurso dependiente. El resto permanece identificado sin IU.
                Sumar(salida, indicePorcentaje ?? SinIndice, diferencia);
                desgloses[(partida, factor)] = salida;
                return salida;
            }
            finally { camino.Remove(id); }
        }
        foreach (var partida in presupuesto.Items)
        {
            bool titulo = MYGProyectoStorage.EsTitulo(partida);
            var fila = new MYGFilaFormulaPolinomica
            {
                Id = partida.Id, ParentId = partida.ParentId, Item = partida.Item,
                Descripcion = partida.Descripcion, Unidad = partida.Unidad, EsTitulo = titulo
            };
            if (!titulo)
            {
                fila.Metrado = calculo.Cantidad(partida);
                fila.Precio = calculo.Analizar(partida).PrecioUnitario;
                fila.Total = calculo.TotalPartida(partida);
                fila.Importes = new(Desglosar(partida, fila.Metrado, new(StringComparer.OrdinalIgnoreCase)), StringComparer.OrdinalIgnoreCase);
                Sumar(fila.Importes, SinIndice, fila.Total - fila.Importes.Values.Sum());
                foreach (var par in fila.Importes) Sumar(totales, par.Key, par.Value);
                matriz.Total += fila.Total;
            }
            matriz.Filas.Add(fila);
        }
        var porId = matriz.Filas.ToDictionary(x => x.Id, StringComparer.OrdinalIgnoreCase);
        // Acumular las hojas una sola vez en cada ancestro, sin sumar de nuevo
        // títulos que ya contienen sus descendientes.
        foreach (var hoja in matriz.Filas.Where(x => !x.EsTitulo))
        {
            string padre = hoja.ParentId;
            var visitados = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { hoja.Id };
            while (!string.IsNullOrEmpty(padre) && porId.TryGetValue(padre, out var titulo))
            {
                if (!visitados.Add(padre)) throw new InvalidDataException("Jerarquía circular en fórmula polinómica.");
                if (titulo.EsTitulo)
                {
                    titulo.Total += hoja.Total;
                    foreach (var par in hoja.Importes) Sumar(titulo.Importes, par.Key, par.Value);
                }
                padre = titulo.ParentId;
            }
        }
        matriz.Indices = totales.OrderBy(x => x.Key == SinIndice).ThenBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
            .Select(x => new MYGIndiceFormulaPolinomica { Codigo = x.Key, Descripcion = x.Key == SinIndice ? "Sin índice asignado / diferencias de redondeo" : nombres.GetValueOrDefault(x.Key, "Índice " + x.Key), Total = x.Value }).ToList();
        return matriz;
    }

    /// <summary>Devuelve una copia normalizada; cada índice pertenece a un solo
    /// grupo y los índices nuevos quedan visibles. No modifica la configuración.</summary>
    public static MYGConfiguracionFormulaPolinomica CrearConfiguracion(MYGMatrizFormulaPolinomica matriz,
        MYGConfiguracionFormulaPolinomica configuracion = null)
    {
        ArgumentNullException.ThrowIfNull(matriz);
        var resultado = new MYGConfiguracionFormulaPolinomica();
        var conocidos = matriz.Indices.ToDictionary(x => x.Codigo, StringComparer.OrdinalIgnoreCase);
        var usados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var grupo in configuracion?.Grupos ?? new())
        {
            if (grupo == null) continue;
            var indices = (grupo.Indices ?? new()).Where(x => x != null && conocidos.ContainsKey(x) && usados.Add(x)).ToList();
            if (indices.Count == 0) continue;
            string id = grupo.Id;
            if (string.IsNullOrWhiteSpace(id) || !ids.Add(id)) { id = MYGProyectoStorage.NuevoId(); ids.Add(id); }
            resultado.Grupos.Add(new MYGGrupoFormulaPolinomica
            {
                Id = id, Descripcion = grupo.Descripcion ?? "", Nomenclatura = grupo.Nomenclatura ?? "",
                Indices = indices, CoeficienteDefinido = grupo.CoeficienteDefinido
            });
        }
        foreach (var indice in matriz.Indices.Where(x => usados.Add(x.Codigo)))
        {
            string id = "IU:" + indice.Codigo;
            if (!ids.Add(id)) { id = MYGProyectoStorage.NuevoId(); ids.Add(id); }
            resultado.Grupos.Add(new MYGGrupoFormulaPolinomica
            {
                Id = id, Descripcion = indice.Descripcion,
                Nomenclatura = indice.Codigo == SinIndice ? "S/I" : "I" + indice.Codigo,
                Indices = new() { indice.Codigo }
            });
        }
        return resultado;
    }

    public static MYGResultadoFormulaPolinomica CalcularAgrupacion(MYGMatrizFormulaPolinomica matriz,
        MYGConfiguracionFormulaPolinomica configuracion = null)
    {
        ArgumentNullException.ThrowIfNull(matriz);
        var resultado = new MYGResultadoFormulaPolinomica();
        var indices = matriz.Indices.ToDictionary(x => x.Codigo, StringComparer.OrdinalIgnoreCase);
        foreach (var grupo in CrearConfiguracion(matriz, configuracion).Grupos)
        {
            var monomio = new MYGMonomioFormulaPolinomica
            {
                Id = grupo.Id, Descripcion = grupo.Descripcion, Nomenclatura = grupo.Nomenclatura,
                Indices = grupo.Indices.Select(x => indices[x]).ToList()
            };
            monomio.Importe = monomio.Indices.Sum(x => x.Total);
            monomio.CoeficienteCalculado = matriz.Total == 0 ? 0 : monomio.Importe / matriz.Total;
            monomio.CoeficienteDefinido = grupo.CoeficienteDefinido ?? Math.Round(monomio.CoeficienteCalculado, 3, MidpointRounding.AwayFromZero);
            monomio.Porcentajes = monomio.Indices.ToDictionary(x => x.Codigo,
                x => monomio.Importe == 0 ? 0 : x.Total * 100m / monomio.Importe, StringComparer.OrdinalIgnoreCase);
            resultado.Monomios.Add(monomio);
        }
        resultado.TotalCalculado = resultado.Monomios.Sum(x => x.CoeficienteCalculado);
        resultado.TotalDefinido = resultado.Monomios.Sum(x => x.CoeficienteDefinido);
        if (matriz.Total <= 0) resultado.Advertencias.Add("El presupuesto no tiene un costo directo positivo para calcular la fórmula.");
        if (resultado.Monomios.Count > 8) resultado.Advertencias.Add("La fórmula polinómica debe tener como máximo 8 monomios.");
        if (resultado.Monomios.Any(x => x.CoeficienteDefinido < 0.05m)) resultado.Advertencias.Add("Hay monomios con coeficiente menor de 0,050; revise su agrupación.");
        if (resultado.Monomios.Any(x => x.CoeficienteDefinido < 0 || x.CoeficienteDefinido > 1)) resultado.Advertencias.Add("Los coeficientes definidos deben estar entre 0 y 1.");
        if (matriz.Indices.Any(x => x.Codigo == SinIndice)) resultado.Advertencias.Add("Existen importes sin índice asignado o diferencias de redondeo; revíselos antes de utilizar la fórmula.");
        if (matriz.Total != 0 && resultado.TotalDefinido != 1m) resultado.Advertencias.Add("La suma de los coeficientes definidos debe ser 1,000 (actual: " + resultado.TotalDefinido.ToString("0.000", CultureInfo.CurrentCulture) + ").");
        return resultado;
    }
}
