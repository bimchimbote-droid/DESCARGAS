using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Globalization;



namespace MYG_2027
{
    // Documento independiente del SQL de Delphin. Una copia contiene
    // la estructura completa, todos los presupuestos y sus filtros BIM.
    public sealed class MYGProyectoDocumento
    {
        public string Formato { get; set; } = "MYG_BIM_PROYECTO";
        public int Version { get; set; } = 3;
        public string Id { get; set; } = MYGProyectoStorage.NuevoId();
        public string Nombre { get; set; }
        public string IdProyectoRevit { get; set; }
        public string PresupuestoActivoId { get; set; }
        public DateTime ModificadoUtc { get; set; }
        public MYGFuenteDelphin FuenteCatalogo { get; set; }
        public MYGDatosProyecto Datos { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public MYGCronograma Cronograma { get; set; }
        public List<MYGPresupuestoDocumento> Presupuestos { get; set; } = new List<MYGPresupuestoDocumento>();
    }

    public sealed class MYGFuenteDelphin
    {
        public string Id { get; set; }
        public string RutaSQLite { get; set; }
    }

    public sealed class MYGConexionDelphin
    {
        public string FuenteId { get; set; }
        public string RutaSQLite { get; set; }
        public string ProyectoId { get; set; }
        public string PresupuestoId { get; set; }
    }

    public sealed class MYGPresupuestoDocumento
    {
        public MYGCostosPresupuesto Costos { get; set; } = new MYGCostosPresupuesto();
        public string Id { get; set; } = MYGProyectoStorage.NuevoId();
        public string Item { get; set; }
        public string IdPresupuestoRevit { get; set; }
        public string Nombre { get; set; }
        public int Posicion { get; set; }
        public int CantidadFiltros { get; set; } = 1;
        public MYGConexionDelphin Conexion { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public MYGConfiguracionFormulaPolinomica FormulaPolinomica { get; set; }
        public List<ItemPresupuestoDelphin> Items { get; set; } = new List<ItemPresupuestoDelphin>();
        [JsonIgnore] internal MYGContextoReferenciasMetrado ContextoReferencias { get; set; }
        public override string ToString() => string.IsNullOrWhiteSpace(Item) ? Nombre : Item + " - " + Nombre;
    }

    public sealed class MYGPlantillaPresupuesto
    {
        public string Id { get; set; } = MYGProyectoStorage.NuevoId();
        public string Nombre { get; set; }
        public DateTime GuardadoUtc { get; set; }
        public MYGPresupuestoDocumento Presupuesto { get; set; }
        public override string ToString() => Nombre;
    }

    public sealed class MYGBibliotecaDocumento
    {
        public string Formato { get; set; } = "MYG_BIM_BIBLIOTECA";
        public int Version { get; set; } = 2;
        public List<MYGConfiguracionPartida> Configuraciones { get; set; } = new List<MYGConfiguracionPartida>();
        [JsonIgnore] public string FirmaLectura { get; set; }
        public List<MYGPlantillaPresupuesto> Plantillas { get; set; } = new List<MYGPlantillaPresupuesto>();
    }

    public sealed class MYGPartidaCatalogo
    {
        public string Id { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string Unidad { get; set; }
        public string FuenteId { get; set; }
        public string RutaSQLite { get; set; }
    }

    public sealed class MYGInformeActualizacion
    {
        public int Nuevas { get; set; }
        public int Actualizadas { get; set; }
        public int Ausentes { get; set; }
        public List<string> Avisos { get; set; } = new List<string>();
    }

    public static class MYGProyectoStorage
    {
        internal static readonly JsonSerializerOptions Opciones = new JsonSerializerOptions
        { WriteIndented = true, PropertyNameCaseInsensitive = true, MaxDepth = 128 };

        public static string NuevoId() => "MYG-" + Guid.NewGuid().ToString("N").ToUpperInvariant();
        public static T Copia<T>(T valor)
        {
            if (valor == null) return default(T);
            var copia = JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(valor, Opciones), Opciones);
            MYGReferenciasMetrado.ConservarContexto(valor, copia);
            return copia;
        }

        public static MYGProyectoDocumento Nuevo(string nombre, string presupuesto = "PRESUPUESTO GENERAL")
        {
            var p = new MYGPresupuestoDocumento { Nombre = presupuesto.Trim(), Item = "01", Posicion = 1 };
            var documento = new MYGProyectoDocumento
            { Nombre = nombre.Trim(), Presupuestos = new List<MYGPresupuestoDocumento> { p }, PresupuestoActivoId = p.Id };
            MYGReferenciasMetrado.Vincular(documento.Presupuestos);
            return documento;
        }

        public static MYGProyectoDocumento Leer(string ruta)
        {
            if (MYGBaseDatos.EsRutaSQLite(ruta)) return MYGBaseDatos.LeerProyecto(ruta);
            using (var j = JsonDocument.Parse(File.ReadAllText(ruta)))
            {
                if (j.RootElement.ValueKind != JsonValueKind.Object ||
                    !j.RootElement.TryGetProperty("Formato", out var f) || f.GetString() != "MYG_BIM_PROYECTO")
                    throw new InvalidDataException("Este archivo no es un proyecto MYG completo. " +
                        "Para un JSON antiguo de filtros, abre Delphin y usa Importar filtros antiguos.");
            }
            var d = JsonSerializer.Deserialize<MYGProyectoDocumento>(File.ReadAllText(ruta), Opciones);
            Validar(d);
            return d;
        }

        public static void Guardar(string ruta, MYGProyectoDocumento documento, string origenCatalogos = null)
        {
            Validar(documento);
            var copia = Copia(documento);
            copia.ModificadoUtc = DateTime.UtcNow;
            MYGBaseDatos.GuardarProyecto(MYGBaseDatos.RutaDeProyecto(ruta), copia, origenCatalogos);
            if (!MYGBaseDatos.EsRutaSQLite(ruta))
                EscribirAtomico(ruta, JsonSerializer.Serialize(copia, Opciones));
            documento.ModificadoUtc = copia.ModificadoUtc;
        }

        public static void EscribirAtomico(string ruta, string contenido)
        {
            ruta = Path.GetFullPath(ruta);
            Directory.CreateDirectory(Path.GetDirectoryName(ruta));
            string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var s = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] bytes = new UTF8Encoding(false).GetBytes(contenido);
                    s.Write(bytes, 0, bytes.Length);
                    s.Flush(true);
                }
                if (File.Exists(ruta)) File.Copy(ruta, ruta + ".bak", true);
                File.Move(temporal, ruta, true);
            }
            finally { if (File.Exists(temporal)) File.Delete(temporal); }
        }

        public static string Firma(MYGProyectoDocumento documento)
        {
            // Seleccionar otro presupuesto no es una modificación de contenido.
            var c = Copia(documento);
            c.ModificadoUtc = default(DateTime);
            c.PresupuestoActivoId = null;
            // El guardado reconstruye las cachés nativas de importación. Ese
            // mantenimiento no constituye una edición ni altera la cola durable.
            MYGDocumentoDelphinAlmacenamiento.OmitirDiagnosticosParaComparacion(c);
            return JsonSerializer.Serialize(c, Opciones);
        }

        public static void Validar(MYGProyectoDocumento d)
        {
            if (d == null || d.Formato != "MYG_BIM_PROYECTO" || (d.Version != 2 && d.Version != 3))
                throw new InvalidDataException("Formato o versión de proyecto MYG no compatible.");
            // La versión anterior no debe abrir los archivos con costos y eliminar campos al guardarlos.
            d.Version = 3;
            if (string.IsNullOrWhiteSpace(d.Id) || string.IsNullOrWhiteSpace(d.Nombre))
                throw new InvalidDataException("El proyecto necesita identificador y nombre.");
            d.Datos?.Validar();
            if (d.Cronograma != null) MYGMotorCronograma.Validar(d.Cronograma);
            if (string.IsNullOrWhiteSpace(d.IdProyectoRevit)) d.IdProyectoRevit = d.Id;
            if (d.FuenteCatalogo != null && (string.IsNullOrWhiteSpace(d.FuenteCatalogo.Id) ||
                string.IsNullOrWhiteSpace(d.FuenteCatalogo.RutaSQLite)))
                throw new InvalidDataException("La referencia al catálogo está incompleta.");
            d.Presupuestos = d.Presupuestos ?? new List<MYGPresupuestoDocumento>();
            // Resolver todos los presupuestos antes de calcular cantidades; el
            // presupuesto origen puede aparecer después del destino en el JSON.
            MYGReferenciasMetrado.Vincular(d.Presupuestos);
            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in d.Presupuestos)
            {
                if (p == null || string.IsNullOrWhiteSpace(p.Id) || !ids.Add(p.Id) || string.IsNullOrWhiteSpace(p.Nombre))
                    throw new InvalidDataException("Presupuesto sin nombre, sin identificador o duplicado.");
                ValidarPresupuesto(p);
            }
        }

        public static bool EsTitulo(ItemPresupuestoDelphin i) => i != null &&
            string.Equals(i.TipoPropuesta, "TITULO", StringComparison.OrdinalIgnoreCase);

        public static void ValidarPresupuesto(MYGPresupuestoDocumento p)
        {
            if (string.IsNullOrWhiteSpace(p.IdPresupuestoRevit)) p.IdPresupuestoRevit = p.Id;
            if (p.Conexion != null && (string.IsNullOrWhiteSpace(p.Conexion.FuenteId) ||
                string.IsNullOrWhiteSpace(p.Conexion.RutaSQLite) || string.IsNullOrWhiteSpace(p.Conexion.ProyectoId) ||
                string.IsNullOrWhiteSpace(p.Conexion.PresupuestoId)))
                throw new InvalidDataException("El vínculo Delphin del presupuesto está incompleto.");
            p.Items = p.Items ?? new List<ItemPresupuestoDelphin>();
            if (p.CantidadFiltros < 1 || p.CantidadFiltros > 8)
                throw new InvalidDataException("La cantidad de filtros debe estar entre 1 y 8.");
            var mapa = new Dictionary<string, ItemPresupuestoDelphin>(StringComparer.OrdinalIgnoreCase);
            var locales = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var i in p.Items)
            {
                if (i == null || string.IsNullOrWhiteSpace(i.Id) || mapa.ContainsKey(i.Id))
                    throw new InvalidDataException("Ítem sin identificador o duplicado en " + p.Nombre + ".");
                mapa.Add(i.Id, i);
                if (string.IsNullOrWhiteSpace(i.IdLocalMYG)) i.IdLocalMYG = NuevoId();
                if (!locales.Add(i.IdLocalMYG)) throw new InvalidDataException("Identidad MYG duplicada.");
                i.Filtros = i.Filtros ?? new List<FiltroPlanificacion>();
                if (i.Filtros.Count > 8) throw new InvalidDataException("Una partida tiene más de 8 filtros.");
                if (i.Filtros.Any(f => f == null)) throw new InvalidDataException("Filtro BIM nulo.");
                if (i.ParentId == "__ROOT__" || string.IsNullOrWhiteSpace(i.ParentId)) i.ParentId = null;
            }
            // Algunos SQL no explicitan el tipo de título: se reconoce por sus hijos.
            foreach (var i in p.Items.Where(x => !string.IsNullOrWhiteSpace(x.ParentId)))
                if (mapa.TryGetValue(i.ParentId, out var padre) && string.IsNullOrWhiteSpace(padre.TipoPropuesta))
                    padre.TipoPropuesta = "TITULO";
            foreach (var i in p.Items)
            {
                if (string.IsNullOrWhiteSpace(i.TipoPropuesta)) i.TipoPropuesta = "PARTIDA";
                var visitados = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { i.Id };
                var actual = i;
                for (int nivel = 0; !string.IsNullOrWhiteSpace(actual.ParentId); nivel++)
                {
                    if (nivel >= 64 || !visitados.Add(actual.ParentId))
                        throw new InvalidDataException("Jerarquía circular o demasiado profunda.");
                    if (!mapa.TryGetValue(actual.ParentId, out var padre))
                        throw new InvalidDataException("Falta el padre de " + i.Descripcion + ".");
                    if (!EsTitulo(padre)) throw new InvalidDataException("Una partida no puede contener otros ítems.");
                    actual = padre;
                }
            }
            MYGReferenciasMetrado.PrepararPresupuesto(p);
            MYGMotorPresupuestos.Validar(p);
        }

        public static void Renumerar(MYGPresupuestoDocumento p)
        {
            ValidarPresupuesto(p);
            var grupos = p.Items.GroupBy(i => i.ParentId ?? "")
                .ToDictionary(g => g.Key, g => g.OrderBy(i => i.Posicion).ThenBy(i => i.Item).ToList(),
                    StringComparer.OrdinalIgnoreCase);
            Action<string, string> visitar = null;
            visitar = (padre, prefijo) =>
            {
                if (!grupos.TryGetValue(padre, out var hijos)) return;
                for (int n = 0; n < hijos.Count; n++)
                {
                    hijos[n].Item = prefijo + (n + 1).ToString("D2", CultureInfo.InvariantCulture);
                    hijos[n].Posicion = n + 1;
                    visitar(hijos[n].Id, hijos[n].Item + ".");
                }
            };
            visitar("", "");
        }

        public static MYGPresupuestoDocumento CopiarComoPlantilla(MYGPresupuestoDocumento original, string nombre)
        {
            var p = Copia(original);
            string presupuestoAnteriorId = p.Id;
            p.Id = NuevoId(); p.IdPresupuestoRevit = p.Id; p.Nombre = nombre; p.Conexion = null;
            var remap = p.Items.ToDictionary(i => i.Id, i => NuevoId(), StringComparer.OrdinalIgnoreCase);
            var locales = p.Items.ToDictionary(i => i.IdLocalMYG ?? i.Id, i => remap[i.Id], StringComparer.OrdinalIgnoreCase);
            foreach (var i in p.Items)
            {
                foreach (var recurso in i.Costos.Analisis)
                    if (!string.IsNullOrWhiteSpace(recurso.SubpartidaIdLocal) && locales.TryGetValue(recurso.SubpartidaIdLocal, out var nuevaReferencia))
                        recurso.SubpartidaIdLocal = nuevaReferencia;
                i.Id = remap[i.Id]; i.IdLocalMYG = i.Id; i.IdPropuesta = i.Id;
                i.ParentId = !string.IsNullOrWhiteSpace(i.ParentId) && remap.ContainsKey(i.ParentId) ? remap[i.ParentId] : null;
                i.IdInternoDelphin = null; i.IdAnalisisDelphin = null;
                i.Origen = "MODELO"; i.Estado = "PROPUESTA";
                i.PartidaOriginal = null; i.UnidadOriginal = null;
                i.PartidaPropuesta = null; i.UnidadPropuesta = null;
                i.EstadoRevit = null; i.MensajeRevit = null;
            }
            foreach (var hoja in p.Items.Select(i => i.Costos?.Hoja).Where(h => h != null))
                foreach (var referencia in hoja.ReferenciasPartidas)
                    if (string.Equals(referencia.PresupuestoId, presupuestoAnteriorId, StringComparison.OrdinalIgnoreCase) &&
                        locales.TryGetValue(referencia.PartidaLocalId, out string nuevaPartida))
                    { referencia.PresupuestoId = p.Id; referencia.PartidaLocalId = nuevaPartida; }
            MYGReferenciasMetrado.PrepararPlantilla(original, p);
            Renumerar(p);
            return p;
        }

        public static List<ItemPresupuestoDelphin> DesvincularComoPropuestas(MYGPresupuestoDocumento original)
        {
            var items = Copia(original.Items);
            var remap = items.ToDictionary(i => i.Id,
                i => string.IsNullOrWhiteSpace(i.IdLocalMYG) ? NuevoId() : i.IdLocalMYG, StringComparer.OrdinalIgnoreCase);
            foreach (var i in items)
            {
                i.Id = remap[i.Id]; i.IdLocalMYG = i.Id; i.IdPropuesta = i.Id;
                i.ParentId = !string.IsNullOrWhiteSpace(i.ParentId) && remap.ContainsKey(i.ParentId) ? remap[i.ParentId] : null;
                i.IdInternoDelphin = null; i.IdAnalisisDelphin = null;
                i.Origen = "MODELO"; i.Estado = "PROPUESTA";
                i.PartidaOriginal = null; i.UnidadOriginal = null;
                i.PartidaPropuesta = null; i.UnidadPropuesta = null;
            }
            return items;
        }

        public static MYGBibliotecaDocumento LeerBiblioteca(string ruta)
        {
            if (!File.Exists(ruta)) return new MYGBibliotecaDocumento { FirmaLectura = "NO_EXISTE" };
            byte[] bytes = File.ReadAllBytes(ruta);
            var b = JsonSerializer.Deserialize<MYGBibliotecaDocumento>(bytes, Opciones);
            MYGBibliotecaPartidas.Validar(b);
            b.FirmaLectura = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes));
            return b;
        }

        public static void AgregarPlantilla(string ruta, string nombre, MYGPresupuestoDocumento presupuesto)
        {
            var b = LeerBiblioteca(ruta);
            b.Plantillas.Add(new MYGPlantillaPresupuesto
            { Nombre = nombre, GuardadoUtc = DateTime.UtcNow, Presupuesto = CopiarComoPlantilla(presupuesto, nombre) });
            MYGBibliotecaPartidas.Guardar(ruta, b);
        }

        public static bool MismaUnidad(string a, string b)
        {
            Func<string, string> normalizar = s => (s ?? "").Trim().ToLowerInvariant()
                .Replace("²", "2").Replace("³", "3").Replace(" ", "").Replace("m^", "m");
            return !string.IsNullOrWhiteSpace(a) && normalizar(a) == normalizar(b);
        }

        public static bool ReferenciaCatalogoExacta(ItemPresupuestoDelphin propuesta,
            ItemPresupuestoDelphin oficial, string fuentePresupuesto)
        {
            return propuesta != null && oficial != null &&
                !string.IsNullOrWhiteSpace(propuesta.IdCatalogoDelphin) &&
                !string.IsNullOrWhiteSpace(propuesta.FuenteCatalogoId) &&
                string.Equals(propuesta.FuenteCatalogoId, fuentePresupuesto, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(propuesta.IdCatalogoDelphin, oficial.IdAnalisisDelphin, StringComparison.OrdinalIgnoreCase) &&
                MismaUnidad(propuesta.Unidad, oficial.Unidad);
        }

        public static bool TieneBim(ItemPresupuestoDelphin i) => !string.IsNullOrWhiteSpace(i.Plantilla) ||
            (i.Filtros ?? new List<FiltroPlanificacion>()).Any(f => f != null && !f.EstaVacio()) ||
            !string.IsNullOrWhiteSpace(i.Parametro) || !string.IsNullOrWhiteSpace(i.Regla) || !string.IsNullOrWhiteSpace(i.Valor);

        public static ItemPresupuestoDelphin VinculoAutomatico(ItemPresupuestoDelphin propuesta,
            IEnumerable<ItemPresupuestoDelphin> pendientes, IEnumerable<ItemPresupuestoDelphin> elegibles, string fuente)
        {
            if (string.IsNullOrWhiteSpace(propuesta.IdCatalogoDelphin) ||
                pendientes.Count(i => i.IdCatalogoDelphin == propuesta.IdCatalogoDelphin &&
                    i.FuenteCatalogoId == propuesta.FuenteCatalogoId) != 1) return null;
            var exactas = elegibles.Where(i => ReferenciaCatalogoExacta(propuesta, i, fuente)).ToList();
            return exactas.Count == 1 ? exactas[0] : null;
        }

        public static void Vincular(ItemPresupuestoDelphin propuesta, ItemPresupuestoDelphin oficial)
        {
            if (MYGMotorPresupuestos.TieneDatosPropios(propuesta.Costos)) oficial.Costos = Copia(propuesta.Costos);
            // Asignar sólo responsables no debe sustituir el ACU oficial por un costo vacío.
            if (propuesta.Costos?.Responsables?.Count > 0)
                oficial.Costos.Responsables = Copia(propuesta.Costos.Responsables);
            oficial.IdLocalMYG = propuesta.IdLocalMYG ?? propuesta.Id;
            oficial.IdPropuesta = propuesta.IdPropuesta ?? propuesta.Id;
            oficial.IdInternoDelphin = oficial.IdInternoDelphin ?? oficial.Id;
            oficial.IdCatalogoDelphin = propuesta.IdCatalogoDelphin ?? oficial.IdAnalisisDelphin;
            oficial.FuenteCatalogoId = propuesta.FuenteCatalogoId ?? oficial.FuenteCatalogoId;
            oficial.FuenteCatalogoRuta = propuesta.FuenteCatalogoRuta ?? oficial.FuenteCatalogoRuta;
            oficial.CodigoCatalogoDelphin = propuesta.CodigoCatalogoDelphin ?? propuesta.CodigoDelphin;
            oficial.Origen = "MODELO"; oficial.Estado = "VINCULADA";
            if (string.IsNullOrWhiteSpace(oficial.Unidad)) oficial.Unidad = propuesta.Unidad;
            oficial.IdConfiguracionBibliotecaMYG = propuesta.IdConfiguracionBibliotecaMYG;
            oficial.Plantilla = propuesta.Plantilla;
            oficial.Filtros = Copia(propuesta.Filtros ?? new List<FiltroPlanificacion>());
            oficial.Parametro = propuesta.Parametro; oficial.Regla = propuesta.Regla; oficial.Valor = propuesta.Valor;
        }

        public static MYGInformeActualizacion ActualizarDesdeDelphin(MYGPresupuestoDocumento p,
            List<ItemPresupuestoDelphin> oficiales)
        {
            if (p.Conexion == null) throw new InvalidOperationException("El presupuesto no está conectado con Delphin.");
            var informe = new MYGInformeActualizacion();
            var viejos = (p.Items ?? new List<ItemPresupuestoDelphin>()).Where(i =>
                !string.IsNullOrWhiteSpace(i.IdInternoDelphin)).ToDictionary(i => i.IdInternoDelphin,
                    StringComparer.OrdinalIgnoreCase);
            var pendientes = (p.Items ?? new List<ItemPresupuestoDelphin>()).Where(i =>
                string.IsNullOrWhiteSpace(i.IdInternoDelphin)).Select(Copia).ToList();
            var nuevos = oficiales.Select(Copia).ToList();
            var nuevosIds = new HashSet<string>(nuevos.Select(i => i.Id), StringComparer.OrdinalIgnoreCase);
            foreach (var i in nuevos)
            {
                i.IdInternoDelphin = i.Id; i.Origen = "DELPHIN"; i.Estado = "OFICIAL";
                i.FuenteCatalogoId = p.Conexion.FuenteId; i.FuenteCatalogoRuta = p.Conexion.RutaSQLite;
                i.IdCatalogoDelphin = i.IdAnalisisDelphin; i.CodigoCatalogoDelphin = i.CodigoDelphin;
                if (viejos.TryGetValue(i.Id, out var anterior))
                {
                    i.Costos = Copia(anterior.Costos);
                    i.IdLocalMYG = anterior.IdLocalMYG; i.IdPropuesta = anterior.IdPropuesta;
                    i.IdConfiguracionBibliotecaMYG = anterior.IdConfiguracionBibliotecaMYG;
                    i.Plantilla = anterior.Plantilla; i.Filtros = Copia(anterior.Filtros);
                    i.Parametro = anterior.Parametro; i.Regla = anterior.Regla; i.Valor = anterior.Valor;
                    i.IdCatalogoDelphin = anterior.IdCatalogoDelphin ?? i.IdAnalisisDelphin;
                    i.FuenteCatalogoId = anterior.FuenteCatalogoId ?? p.Conexion.FuenteId;
                    i.FuenteCatalogoRuta = anterior.FuenteCatalogoRuta ?? p.Conexion.RutaSQLite;
                    i.CodigoCatalogoDelphin = anterior.CodigoCatalogoDelphin ?? i.CodigoDelphin;
                    if (!string.IsNullOrWhiteSpace(anterior.IdPropuesta)) i.Estado = anterior.Estado;
                    i.PartidaOriginal = anterior.PartidaOriginal; i.UnidadOriginal = anterior.UnidadOriginal;
                    i.PartidaPropuesta = anterior.PartidaPropuesta; i.UnidadPropuesta = anterior.UnidadPropuesta;
                    if (anterior.Estado == "PROP. MODIFICAR")
                    { i.Descripcion = anterior.Descripcion; i.Unidad = anterior.Unidad; }
                    if (!EsTitulo(i) && TieneBim(anterior) && !MismaUnidad(anterior.Unidad, i.Unidad))
                        informe.Avisos.Add("Cambió la unidad de " + i.Descripcion + "; revisa su plantilla y filtros.");
                    informe.Actualizadas++;
                }
                else { i.IdLocalMYG = NuevoId(); informe.Nuevas++; }
            }
            var ausentes = viejos.Values.Where(i => !nuevosIds.Contains(i.IdInternoDelphin)).ToList();
            var remapAusentes = ausentes.ToDictionary(i => i.Id,
                i => i.IdLocalMYG ?? NuevoId(), StringComparer.OrdinalIgnoreCase);
            foreach (var anterior in ausentes)
            {
                // Una partida eliminada del SQL conserva todo su trabajo BIM.
                var i = Copia(anterior);
                i.Id = remapAusentes[i.Id]; i.IdLocalMYG = i.Id; i.IdPropuesta = i.Id;
                i.IdInternoDelphin = null; i.IdAnalisisDelphin = null; i.Origen = "MODELO"; i.Estado = "PROPUESTA";
                pendientes.Add(i); informe.Ausentes++;
            }
            foreach (var i in pendientes)
                if (!string.IsNullOrWhiteSpace(i.ParentId) && remapAusentes.TryGetValue(i.ParentId, out var nuevoPadre))
                    i.ParentId = nuevoPadre;
            foreach (var i in pendientes)
                if (nuevosIds.Contains(i.Id)) throw new InvalidDataException("Colisión entre una identidad MYG y Delphin.");
            nuevos.AddRange(pendientes);
            var todosIds = new HashSet<string>(nuevos.Select(i => i.Id), StringComparer.OrdinalIgnoreCase);
            foreach (var i in nuevos)
                if (!string.IsNullOrWhiteSpace(i.ParentId) && !todosIds.Contains(i.ParentId)) i.ParentId = null;
            var verificado = new MYGPresupuestoDocumento
            {
                Id = p.Id,
                IdPresupuestoRevit = p.IdPresupuestoRevit,
                Nombre = p.Nombre,
                CantidadFiltros = p.CantidadFiltros,
                Items = nuevos,
                Costos = Copia(p.Costos)
            };
            // La comprobación usa los nuevos ítems de este presupuesto y las
            // fuentes de los demás presupuestos del proyecto, sin publicarlos.
            verificado.ContextoReferencias = p.ContextoReferencias;
            ValidarPresupuesto(verificado);
            p.Items = verificado.Items;
            return informe;
        }
    }

    // Este índice solo recuerda fuentes y proyectos recientes. Los filtros
    // y partidas están en el archivo portable del proyecto, nunca en este índice.
    internal sealed class MYGIndiceDatos
    {
        public string RutaBiblioteca { get; set; }
        public List<MYGFuenteDelphin> Fuentes { get; set; } = new List<MYGFuenteDelphin>();
        public List<MYGAsociacionProyecto> Proyectos { get; set; } = new List<MYGAsociacionProyecto>();
    }
    internal sealed class MYGAsociacionProyecto
    {
        public string RutaSQLite { get; set; }
        public string ProyectoDelphinId { get; set; }
        public string PresupuestoDelphinId { get; set; }
        public string RutaProyectoMYG { get; set; }
        public string Nombre { get; set; }
        public DateTime UsadoUtc { get; set; }
    }
    public static class MYGIndiceLocal
    {
        private static readonly object Candado = new object();
        internal static string RutaAlternativaPruebas { get; set; }
        private static string Ruta => RutaAlternativaPruebas ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "MYG", "TablasAutomaticas", "proyectos_myg_indice_v2.json");
        private static bool IgualRuta(string a, string b) => !string.IsNullOrWhiteSpace(a) &&
            !string.IsNullOrWhiteSpace(b) && string.Equals(Path.GetFullPath(a), Path.GetFullPath(b), StringComparison.OrdinalIgnoreCase);
        private static MYGIndiceDatos Leer()
        {
            if (!File.Exists(Ruta)) return new MYGIndiceDatos();
            // Un índice dañado no debe bloquear un proyecto portable.
            try
            {
                var i = JsonSerializer.Deserialize<MYGIndiceDatos>(File.ReadAllText(Ruta)) ?? new MYGIndiceDatos();
                i.Fuentes = i.Fuentes ?? new List<MYGFuenteDelphin>();
                i.Proyectos = i.Proyectos ?? new List<MYGAsociacionProyecto>();
                return i;
            }
            catch (JsonException) { return new MYGIndiceDatos(); }
        }
        public static string RutaBiblioteca()
        {
            string configurada = Leer().RutaBiblioteca;
            if (!string.IsNullOrWhiteSpace(configurada)) return Path.GetFullPath(configurada);
            string documentos = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (string.IsNullOrWhiteSpace(documentos)) documentos = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            return Path.Combine(documentos, "MYG", "MYG_BIBLIOTECA.biblioteca.json");
        }
        public static void RecordarBiblioteca(string ruta)
        {
            lock (Candado)
            {
                var i = Leer(); i.RutaBiblioteca = Path.GetFullPath(ruta);
                MYGProyectoStorage.EscribirAtomico(Ruta, JsonSerializer.Serialize(i));
            }
        }
        public static string FuenteId(string ruta)
        {
            lock (Candado)
            {
                var indice = Leer();
                var f = indice.Fuentes.FirstOrDefault(x => IgualRuta(x.RutaSQLite, ruta));
                if (f != null) return f.Id;
                f = new MYGFuenteDelphin { Id = MYGProyectoStorage.NuevoId(), RutaSQLite = Path.GetFullPath(ruta) };
                indice.Fuentes.Add(f);
                MYGProyectoStorage.EscribirAtomico(Ruta, JsonSerializer.Serialize(indice));
                return f.Id;
            }
        }
        public static void Registrar(MYGProyectoDocumento documento, string archivo)
        {
            lock (Candado)
            {
                var i = Leer();
                i.Proyectos.RemoveAll(x => IgualRuta(x.RutaProyectoMYG, archivo));
                i.Proyectos.Add(new MYGAsociacionProyecto
                { RutaProyectoMYG = Path.GetFullPath(archivo), Nombre = documento.Nombre, UsadoUtc = DateTime.UtcNow });
                var fuentes = documento.Presupuestos.Where(p => p.Conexion != null).Select(p =>
                    new MYGFuenteDelphin { Id = p.Conexion.FuenteId, RutaSQLite = p.Conexion.RutaSQLite }).ToList();
                if (documento.FuenteCatalogo != null) fuentes.Add(documento.FuenteCatalogo);
                foreach (var f in fuentes.Where(f => f != null && !string.IsNullOrWhiteSpace(f.RutaSQLite)))
                {
                    if (!i.Fuentes.Any(x => IgualRuta(x.RutaSQLite, f.RutaSQLite))) i.Fuentes.Add(MYGProyectoStorage.Copia(f));
                }
                foreach (var p in documento.Presupuestos.Where(p => p.Conexion != null))
                    i.Proyectos.Add(new MYGAsociacionProyecto
                    {
                        RutaSQLite = p.Conexion.RutaSQLite,
                        ProyectoDelphinId = p.Conexion.ProyectoId,
                        PresupuestoDelphinId = p.Conexion.PresupuestoId,
                        RutaProyectoMYG = Path.GetFullPath(archivo),
                        Nombre = documento.Nombre,
                        UsadoUtc = DateTime.UtcNow
                    });
                i.Proyectos = i.Proyectos.OrderByDescending(x => x.UsadoUtc).Take(120).ToList();
                MYGProyectoStorage.EscribirAtomico(Ruta, JsonSerializer.Serialize(i));
            }
        }
        public static List<string> Asociados(string sqlite, string proyecto) => Leer().Proyectos.Where(x =>
            IgualRuta(x.RutaSQLite, sqlite) && x.ProyectoDelphinId == proyecto && File.Exists(x.RutaProyectoMYG))
            .Select(x => x.RutaProyectoMYG).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        public static List<string> Recientes() => Leer().Proyectos.Where(x => File.Exists(x.RutaProyectoMYG))
            .OrderByDescending(x => x.UsadoUtc).Select(x => x.RutaProyectoMYG)
            .Distinct(StringComparer.OrdinalIgnoreCase).Take(8).ToList();
    }

    // Las configuraciones de todas las obras viven en la misma biblioteca MYG.
    // Una referencia identifica el análisis del catálogo, nunca el código visible
    // ni el ID de una fila de costo_unitario del presupuesto.
    public sealed class MYGReferenciaConfiguracion
    {
        public string FuenteId { get; set; }
        public string IdAnalisis { get; set; }
        public string IdPartidaMYG { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string RutaSQLite { get; set; }
    }

    public sealed class MYGConfiguracionPartida
    {
        public string Id { get; set; } = MYGProyectoStorage.NuevoId();
        public string Nombre { get; set; }
        public string Unidad { get; set; }
        public string Plantilla { get; set; }
        public DateTime GuardadoUtc { get; set; }
        public List<FiltroPlanificacion> Filtros { get; set; } = new List<FiltroPlanificacion>();
        public List<MYGReferenciaConfiguracion> Referencias { get; set; } = new List<MYGReferenciaConfiguracion>();
        public override string ToString() => Nombre;
    }

    public sealed class MYGGuardarConfiguracionSolicitud
    {
        public ItemPresupuestoDelphin Partida { get; set; }
        public string Nombre { get; set; }
        // Vacío crea una variante; un ID concreto actualiza esa configuración.
        public string IdActualizar { get; set; }
        public string IdGuardado { get; set; }
    }

    public static class MYGBibliotecaPartidas
    {
        private static bool Igual(string a, string b) => string.Equals((a ?? "").Trim(), (b ?? "").Trim(),
            StringComparison.OrdinalIgnoreCase);

        public static string FirmaArchivo(string ruta)
        {
            if (!File.Exists(ruta)) return "NO_EXISTE";
            using (var hash = System.Security.Cryptography.SHA256.Create())
                return Convert.ToHexString(hash.ComputeHash(File.ReadAllBytes(ruta)));
        }

        public static void Validar(MYGBibliotecaDocumento b)
        {
            if (b == null || b.Formato != "MYG_BIM_BIBLIOTECA" || (b.Version != 1 && b.Version != 2 && b.Version != 3))
                throw new InvalidDataException("Biblioteca MYG no compatible.");
            b.Plantillas = b.Plantillas ?? new List<MYGPlantillaPresupuesto>();
            b.Configuraciones = b.Configuraciones ?? new List<MYGConfiguracionPartida>();
            if (b.Plantillas.Any(x => x == null || x.Presupuesto == null || string.IsNullOrWhiteSpace(x.Nombre)))
                throw new InvalidDataException("Biblioteca con un presupuesto incompleto.");
            foreach (var t in b.Plantillas) MYGProyectoStorage.ValidarPresupuesto(t.Presupuesto);
            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var c in b.Configuraciones)
            {
                ValidarConfiguracion(c);
                if (!ids.Add(c.Id)) throw new InvalidDataException("La biblioteca repite el ID de una configuración.");
            }
        }

        public static void ValidarConfiguracion(MYGConfiguracionPartida c)
        {
            if (c == null || string.IsNullOrWhiteSpace(c.Id) || string.IsNullOrWhiteSpace(c.Nombre) ||
                string.IsNullOrWhiteSpace(c.Unidad) || string.IsNullOrWhiteSpace(c.Plantilla))
                throw new InvalidDataException("Cada configuración necesita un nombre, una unidad y una plantilla Revit.");
            c.Filtros = c.Filtros ?? new List<FiltroPlanificacion>();
            c.Referencias = c.Referencias ?? new List<MYGReferenciaConfiguracion>();
            if (c.Filtros.Count > 8 || c.Filtros.Any(f => f == null ||
                (!f.EstaVacio() && (string.IsNullOrWhiteSpace(f.Parametro) || string.IsNullOrWhiteSpace(f.Regla)))))
                throw new InvalidDataException("Revisa los filtros de «" + c.Nombre + "»: completa parámetro y regla (máximo ocho filtros).");
            var referencias = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var r in c.Referencias)
            {
                if (r == null || (string.IsNullOrWhiteSpace(r.IdPartidaMYG) &&
                    (string.IsNullOrWhiteSpace(r.FuenteId) || string.IsNullOrWhiteSpace(r.IdAnalisis))))
                    throw new InvalidDataException("Referencia de partida incompleta en «" + c.Nombre + "».");
                string clave = string.IsNullOrWhiteSpace(r.IdPartidaMYG)
                    ? r.FuenteId + "\n" + r.IdAnalisis : "LOCAL\n" + r.IdPartidaMYG;
                if (!referencias.Add(clave)) throw new InvalidDataException("Referencia duplicada en «" + c.Nombre + "».");
            }
        }

        public static List<FiltroPlanificacion> FiltrosGuardables(ItemPresupuestoDelphin i)
        {
            var filtros = MYGProyectoStorage.Copia(i.Filtros ?? new List<FiltroPlanificacion>());
            if (!filtros.Any(f => f != null && !f.EstaVacio()) && (!string.IsNullOrWhiteSpace(i.Parametro) ||
                !string.IsNullOrWhiteSpace(i.Regla) || !string.IsNullOrWhiteSpace(i.Valor)))
            {
                filtros.Clear();
                filtros.Add(new FiltroPlanificacion { Parametro = i.Parametro, Regla = i.Regla, Valor = i.Valor });
            }
            while (filtros.Count > 0 && (filtros[filtros.Count - 1] == null || filtros[filtros.Count - 1].EstaVacio()))
                filtros.RemoveAt(filtros.Count - 1);
            return filtros.Select(f => f ?? new FiltroPlanificacion()).ToList();
        }

        public static MYGReferenciaConfiguracion Referencia(ItemPresupuestoDelphin i)
        {
            string analisis = string.IsNullOrWhiteSpace(i.IdCatalogoDelphin) ? i.IdAnalisisDelphin : i.IdCatalogoDelphin;
            if (!string.IsNullOrWhiteSpace(i.FuenteCatalogoId) && !string.IsNullOrWhiteSpace(analisis))
                return new MYGReferenciaConfiguracion
                {
                    FuenteId = i.FuenteCatalogoId,
                    IdAnalisis = analisis,
                    Codigo = i.CodigoCatalogoDelphin ?? i.CodigoDelphin,
                    Descripcion = i.Descripcion,
                    RutaSQLite = i.FuenteCatalogoRuta
                };
            string local = i.IdLocalMYG ?? i.Id;
            return string.IsNullOrWhiteSpace(local) ? null : new MYGReferenciaConfiguracion
            { IdPartidaMYG = local, Descripcion = i.Descripcion, Codigo = i.CodigoDelphin };
        }

        public static bool Coincide(MYGReferenciaConfiguracion r, ItemPresupuestoDelphin i)
        {
            var propia = Referencia(i);
            if (r == null || propia == null) return false;
            if (!string.IsNullOrWhiteSpace(r.IdPartidaMYG))
                return !string.IsNullOrWhiteSpace(propia.IdPartidaMYG) && Igual(r.IdPartidaMYG, propia.IdPartidaMYG);
            return string.IsNullOrWhiteSpace(propia.IdPartidaMYG) && Igual(r.FuenteId, propia.FuenteId) &&
                Igual(r.IdAnalisis, propia.IdAnalisis);
        }

        public static List<MYGConfiguracionPartida> Disponibles(MYGBibliotecaDocumento b, ItemPresupuestoDelphin i)
        {
            if (b == null || i == null || MYGProyectoStorage.EsTitulo(i)) return new List<MYGConfiguracionPartida>();
            bool local = string.IsNullOrWhiteSpace(i.IdCatalogoDelphin) && string.IsNullOrWhiteSpace(i.IdAnalisisDelphin);
            return b.Configuraciones.Where(c => MYGProyectoStorage.MismaUnidad(c.Unidad, i.Unidad) &&
                (c.Referencias.Any(r => Coincide(r, i)) ||
                 (local && Igual(c.Id, i.IdConfiguracionBibliotecaMYG))))
                .OrderBy(c => c.Nombre, StringComparer.OrdinalIgnoreCase).ToList();
        }

        public static List<MYGConfiguracionPartida> Disponibles(MYGBibliotecaDocumento b, MYGPartidaCatalogo p) =>
            Disponibles(b, new ItemPresupuestoDelphin
            {
                IdCatalogoDelphin = p.Id,
                FuenteCatalogoId = p.FuenteId,
                Unidad = p.Unidad,
                Descripcion = p.Descripcion
            });

        public static bool MismoContenido(ItemPresupuestoDelphin i, MYGConfiguracionPartida c)
        {
            if (!Igual(i.Plantilla, c.Plantilla) || !MYGProyectoStorage.MismaUnidad(i.Unidad, c.Unidad)) return false;
            var a = FiltrosGuardables(i);
            var temporal = new ItemPresupuestoDelphin { Filtros = c.Filtros };
            var b = FiltrosGuardables(temporal);
            if (a.Count != b.Count) return false;
            // Se compara el valor exactamente: distintos textos pueden filtrar elementos distintos.
            return a.Zip(b, (x, y) => Igual(x.Parametro, y.Parametro) && Igual(x.Regla, y.Regla) &&
                string.Equals(x.Valor ?? "", y.Valor ?? "", StringComparison.Ordinal)).All(x => x);
        }

        public static string Estado(MYGBibliotecaDocumento b, ItemPresupuestoDelphin i)
        {
            if (i == null || MYGProyectoStorage.EsTitulo(i)) return "";
            var disponibles = Disponibles(b, i);
            if (disponibles.Any(c => MismoContenido(i, c))) return "Guardada";
            if (disponibles.Any(c => Igual(c.Id, i.IdConfiguracionBibliotecaMYG))) return "Editada en proyecto";
            if (disponibles.Count > 0) return disponibles.Count + (disponibles.Count == 1 ? " disponible" : " disponibles");
            return "Sin guardar";
        }

        public static void Asociar(MYGConfiguracionPartida c, ItemPresupuestoDelphin i)
        {
            if (!MYGProyectoStorage.MismaUnidad(c.Unidad, i.Unidad))
                throw new InvalidDataException("La unidad de la configuración no coincide con la partida.");
            var r = Referencia(i);
            if (r != null && !c.Referencias.Any(x => Coincide(x, i))) c.Referencias.Add(r);
        }

        public static void Guardar(string ruta, MYGBibliotecaDocumento b)
        {
            Validar(b);
            string nombre;
            using (var sha = System.Security.Cryptography.SHA256.Create())
                nombre = "MYG_BIBLIOTECA_" + Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(Path.GetFullPath(ruta).ToUpperInvariant())));
            using (var mutex = new System.Threading.Mutex(false, nombre))
            {
                bool adquirido = false;
                try
                {
                    try { adquirido = mutex.WaitOne(0); }
                    catch (System.Threading.AbandonedMutexException) { adquirido = true; }
                    if (!adquirido) throw new IOException("La biblioteca está siendo guardada por otra ventana. Actualiza y vuelve a intentar.");
                    if (b.FirmaLectura == null || b.FirmaLectura != FirmaArchivo(ruta))
                        throw new IOException("La biblioteca cambió desde que la abriste. Pulsa Actualizar biblioteca y repite la operación.");
                    var copia = MYGProyectoStorage.Copia(b);
                    copia.Version = b.Version == 3 || b.Plantillas.Any(t => MYGMotorPresupuestos.TieneCostos(t.Presupuesto)) ? 3 : 2;
                    MYGProyectoStorage.EscribirAtomico(ruta, JsonSerializer.Serialize(copia, MYGProyectoStorage.Opciones));
                    b.Version = copia.Version; b.FirmaLectura = FirmaArchivo(ruta);
                }
                finally { if (adquirido) mutex.ReleaseMutex(); }
            }
        }

        public static MYGBibliotecaDocumento PrepararGuardado(MYGBibliotecaDocumento original,
            IList<MYGGuardarConfiguracionSolicitud> solicitudes)
        {
            var b = MYGProyectoStorage.Copia(original); b.FirmaLectura = original.FirmaLectura;
            var destinos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var s in solicitudes)
            {
                if (s.Partida == null || MYGProyectoStorage.EsTitulo(s.Partida))
                    throw new InvalidDataException("Selecciona partidas para guardar sus configuraciones.");
                MYGConfiguracionPartida c = null;
                if (!string.IsNullOrWhiteSpace(s.IdActualizar))
                {
                    c = b.Configuraciones.FirstOrDefault(x => Igual(x.Id, s.IdActualizar));
                    if (c == null || !Disponibles(b, s.Partida).Any(x => Igual(x.Id, c.Id)))
                        throw new InvalidDataException("La configuración elegida para actualizar no corresponde a esa partida.");
                    if (!destinos.Add(c.Id)) throw new InvalidDataException("Dos filas intentan actualizar la misma configuración. Guarda una o crea otra variante.");
                }
                else
                {
                    if (Disponibles(b, s.Partida).Any(x => Igual(x.Nombre, s.Nombre)))
                        throw new InvalidDataException("Ya existe «" + s.Nombre + "» para esa partida. Elige actualizarla o escribe otro nombre para la variante.");
                    c = new MYGConfiguracionPartida(); b.Configuraciones.Add(c);
                }
                c.Nombre = (s.Nombre ?? "").Trim(); c.Unidad = s.Partida.Unidad;
                c.Plantilla = s.Partida.Plantilla; c.Filtros = FiltrosGuardables(s.Partida); c.GuardadoUtc = DateTime.UtcNow;
                Asociar(c, s.Partida); ValidarConfiguracion(c); s.IdGuardado = c.Id;
            }
            Validar(b);
            return b;
        }

        public static MYGBibliotecaDocumento GuardarConfiguraciones(string ruta, MYGBibliotecaDocumento original,
            IList<MYGGuardarConfiguracionSolicitud> solicitudes)
        {
            var b = PrepararGuardado(original, solicitudes);
            Guardar(ruta, b);
            foreach (var s in solicitudes) s.Partida.IdConfiguracionBibliotecaMYG = s.IdGuardado;
            return b;
        }

        public static bool Aplicar(ItemPresupuestoDelphin i, MYGConfiguracionPartida c, bool reemplazar = false)
        {
            ValidarConfiguracion(c);
            if (i == null || MYGProyectoStorage.EsTitulo(i)) throw new InvalidDataException("Una configuración BIM se aplica a una partida, no a un título.");
            if (!MYGProyectoStorage.MismaUnidad(i.Unidad, c.Unidad)) throw new InvalidDataException("Las unidades de la partida y de la configuración son diferentes.");
            if (MYGProyectoStorage.TieneBim(i) && !reemplazar) return false;
            i.Plantilla = c.Plantilla; i.Filtros = MYGProyectoStorage.Copia(c.Filtros);
            i.IdConfiguracionBibliotecaMYG = c.Id;
            var primero = i.Filtros.FirstOrDefault();
            i.Parametro = primero?.Parametro; i.Regla = primero?.Regla; i.Valor = primero?.Valor;
            i.EstadoRevit = null; i.MensajeRevit = null;
            return true;
        }

        public static bool AplicarUnica(MYGBibliotecaDocumento b, ItemPresupuestoDelphin i)
        {
            var opciones = Disponibles(b, i);
            return opciones.Count == 1 && Aplicar(i, opciones[0]);
        }
    }

    public sealed class MYGDataFiltrosArchivo
    {
        public int TotalRegistros { get; set; }
        public int SinConfiguracion { get; set; }
        public List<ConfiguracionTablaPlanificacion> Configuraciones { get; set; } = new List<ConfiguracionTablaPlanificacion>();
    }

    public sealed class MYGDataFiltrosCoincidencia
    {
        public ConfiguracionTablaPlanificacion Registro { get; set; }
        public ItemPresupuestoDelphin Destino { get; set; }
        public bool Segura { get; set; }
        public string Motivo { get; set; }
    }

    public sealed class MYGDataFiltrosSolicitud
    {
        public ConfiguracionTablaPlanificacion Registro { get; set; }
        public ItemPresupuestoDelphin Destino { get; set; }
    }

    public static class MYGDataFiltrosStorage
    {
        private static string Texto(string s) => string.Join(" ", (s ?? "").Split((char[])null,
            StringSplitOptions.RemoveEmptyEntries)).ToUpperInvariant();
        private static bool Igual(string a, string b) => !string.IsNullOrWhiteSpace(a) &&
            string.Equals(a.Trim(), (b ?? "").Trim(), StringComparison.OrdinalIgnoreCase);

        public static List<FiltroPlanificacion> Filtros(ConfiguracionTablaPlanificacion c) =>
            MYGBibliotecaPartidas.FiltrosGuardables(new ItemPresupuestoDelphin
            {
                Filtros = c.Filtros,
                Parametro = c.Parametro,
                Regla = c.Regla,
                Valor = c.Valor
            });

        public static MYGDataFiltrosArchivo Leer(string ruta)
        {
            string texto = File.ReadAllText(ruta);
            using (var j = JsonDocument.Parse(texto))
                if (j.RootElement.ValueKind != JsonValueKind.Array)
                    throw new InvalidDataException("Cargar Data utiliza el JSON antiguo con la lista de filtros. Para un proyecto MYG completo, usa Abrir proyecto.");
            var lista = JsonSerializer.Deserialize<List<ConfiguracionTablaPlanificacion>>(texto, MYGProyectoStorage.Opciones);
            var resultado = new MYGDataFiltrosArchivo { TotalRegistros = lista.Count };
            foreach (var c in lista)
            {
                if (c == null || string.Equals(c.TipoPropuesta, "TITULO", StringComparison.OrdinalIgnoreCase))
                { resultado.SinConfiguracion++; continue; }
                var filtros = Filtros(c);
                if (string.IsNullOrWhiteSpace(c.Plantilla) && filtros.Count == 0)
                { resultado.SinConfiguracion++; continue; }
                if (filtros.Count > 8 || filtros.Any(f => !f.EstaVacio() &&
                    (string.IsNullOrWhiteSpace(f.Parametro) || string.IsNullOrWhiteSpace(f.Regla))))
                    throw new InvalidDataException("Revisa los filtros del registro «" + c.Item + " " + c.Partida + "»: completa parámetro y regla, con un máximo de ocho filtros.");
                c.Filtros = filtros; resultado.Configuraciones.Add(c);
            }
            return resultado;
        }

        public static bool UnidadCompatible(ConfiguracionTablaPlanificacion c, ItemPresupuestoDelphin i) =>
            string.IsNullOrWhiteSpace(c.Unidad) || MYGProyectoStorage.MismaUnidad(c.Unidad, i.Unidad);

        private static bool IdentidadCompatible(ConfiguracionTablaPlanificacion c, ItemPresupuestoDelphin i) =>
            string.IsNullOrWhiteSpace(c.FuenteCatalogoId) || Igual(c.FuenteCatalogoId, i.FuenteCatalogoId);

        private static bool MismoId(ConfiguracionTablaPlanificacion c, ItemPresupuestoDelphin i)
        {
            var antiguos = new[] { c.IdInternoDelphin, c.IdInterno, c.IdPropuesta, c.IdLocalMYG }
                .Where(x => !string.IsNullOrWhiteSpace(x));
            var actuales = new[] { i.IdInternoDelphin, i.Id, i.IdPropuesta, i.IdLocalMYG };
            return antiguos.Any(a => actuales.Any(b => Igual(a, b)));
        }

        public static List<MYGDataFiltrosCoincidencia> Sugerir(MYGDataFiltrosArchivo archivo,
            IEnumerable<ItemPresupuestoDelphin> actuales)
        {
            var items = actuales.Where(i => i != null && !MYGProyectoStorage.EsTitulo(i)).ToList();
            var resultado = new List<MYGDataFiltrosCoincidencia>();
            foreach (var c in archivo.Configuraciones)
            {
                var fila = new MYGDataFiltrosCoincidencia { Registro = c, Motivo = "Sin coincidencia: elige la partida destino" };
                var compatibles = items.Where(i => UnidadCompatible(c, i)).ToList();
                bool tieneNombre = !string.IsNullOrWhiteSpace(c.Partida);
                bool tieneUnidad = !string.IsNullOrWhiteSpace(c.Unidad);
                var porId = compatibles.Where(i => IdentidadCompatible(c, i) && MismoId(c, i)).ToList();
                var exactas = porId.Where(i => tieneNombre && Texto(i.Descripcion) == Texto(c.Partida)).ToList();
                if (exactas.Count == 1)
                {
                    fila.Destino = exactas[0]; fila.Segura = tieneUnidad;
                    fila.Motivo = tieneUnidad ? "ID interno, descripción y unidad" : "ID y descripción: revisa la unidad";
                }
                else if (tieneNombre)
                {
                    var porNombre = compatibles.Where(i => Texto(i.Descripcion) == Texto(c.Partida)).ToList();
                    int fuentesIguales = archivo.Configuraciones.Count(x => Texto(x.Partida) == Texto(c.Partida) &&
                        (string.IsNullOrWhiteSpace(x.Unidad) || string.IsNullOrWhiteSpace(c.Unidad) || MYGProyectoStorage.MismaUnidad(x.Unidad, c.Unidad)));
                    var porItem = porNombre.Where(i => Igual(i.Item, c.Item)).ToList();
                    int fuentesMismoItem = archivo.Configuraciones.Count(x => Texto(x.Partida) == Texto(c.Partida) && Igual(x.Item, c.Item) &&
                        (string.IsNullOrWhiteSpace(x.Unidad) || string.IsNullOrWhiteSpace(c.Unidad) || MYGProyectoStorage.MismaUnidad(x.Unidad, c.Unidad)));
                    if (porItem.Count == 1 && fuentesMismoItem == 1)
                    {
                        fila.Destino = porItem[0]; fila.Segura = tieneUnidad && IdentidadCompatible(c, fila.Destino);
                        fila.Motivo = "Ítem, descripción y unidad (IDs distintos)";
                    }
                    else if (porNombre.Count == 1 && fuentesIguales == 1)
                    {
                        fila.Destino = porNombre[0]; fila.Segura = tieneUnidad && IdentidadCompatible(c, fila.Destino);
                        fila.Motivo = "Descripción y unidad únicas (IDs distintos)";
                    }
                    else if (porNombre.Count > 0) fila.Motivo = "Descripción repetida: elige el uso correcto";
                }
                if (fila.Destino == null && porId.Count > 0 && !tieneNombre)
                { fila.Destino = porId[0]; fila.Motivo = "ID sin descripción: confirma la partida destino"; }
                resultado.Add(fila);
            }
            // Dos configuraciones antiguas no se aplican silenciosamente a una sola fila.
            foreach (var grupo in resultado.Where(f => f.Destino != null).GroupBy(f => f.Destino.Id, StringComparer.OrdinalIgnoreCase))
                if (grupo.Count() > 1)
                    foreach (var f in grupo) { f.Segura = false; f.Motivo = "Varios registros para esta partida: selecciona uno"; }
            return resultado;
        }

        private static void ValidarSolicitud(MYGDataFiltrosSolicitud s)
        {
            if (s == null || s.Registro == null || s.Destino == null || MYGProyectoStorage.EsTitulo(s.Destino))
                throw new InvalidDataException("Elige una partida destino para cada registro seleccionado.");
            if (!UnidadCompatible(s.Registro, s.Destino)) throw new InvalidDataException("La unidad del registro antiguo no coincide con la partida destino.");
            var filtros = Filtros(s.Registro);
            if (filtros.Count > 8 || filtros.Any(f => !f.EstaVacio() &&
                (string.IsNullOrWhiteSpace(f.Parametro) || string.IsNullOrWhiteSpace(f.Regla))))
                throw new InvalidDataException("La configuración antigua tiene filtros incompletos o supera ocho filtros.");
            if (string.IsNullOrWhiteSpace(s.Registro.Plantilla) && string.IsNullOrWhiteSpace(s.Destino.Plantilla))
                throw new InvalidDataException("Asigna una plantilla Revit para la partida «" + s.Destino.Descripcion + "» antes de importar sus filtros.");
        }

        public static void ValidarLote(IList<MYGDataFiltrosSolicitud> solicitudes)
        {
            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var s in solicitudes)
            {
                ValidarSolicitud(s);
                if (!ids.Add(s.Destino.Id)) throw new InvalidDataException("Hay dos registros seleccionados para la misma partida destino. Elige uno o distribúyelos en partidas diferentes.");
            }
        }

        public static void Aplicar(IList<MYGDataFiltrosSolicitud> solicitudes)
        {
            ValidarLote(solicitudes);
            foreach (var s in solicitudes)
            {
                var i = s.Destino;
                if (!string.IsNullOrWhiteSpace(s.Registro.Plantilla)) i.Plantilla = s.Registro.Plantilla;
                i.Filtros = Filtros(s.Registro);
                var primero = i.Filtros.FirstOrDefault();
                i.Parametro = primero?.Parametro; i.Regla = primero?.Regla; i.Valor = primero?.Valor;
                i.IdConfiguracionBibliotecaMYG = null;
                i.EstadoRevit = null; i.MensajeRevit = null;
                // No se importan identidades, descripciones, unidades, propuestas,
                // jerarquía, cambios pendientes ni conexiones del presupuesto antiguo.
            }
        }
    }


}
