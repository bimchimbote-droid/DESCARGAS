using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

internal static partial class DelphinImportacionMYG
{
    // Se consulta la agrupación nativa sin escribir coeficientes calculados ni
    // modificar las tablas de origen. Las ediciones se guardan como extensión MYG.
    private static void LeerFormulaPolinomica(Lectura lectura, MYGPresupuestoDocumento presupuesto)
    {
        var filas = lectura.Filas("titulo_indice", new[] { "id_titulo", "id_titulopadre", "id_presupuesto",
            "descripcion_titulo", "posicion_titulo", "codigo_clase", "es_indice", "nomenclatura", "coeficientedefinido" },
            "id_presupuesto", presupuesto.Id);
        if (filas.Count == 0) return;
        var porId = filas.Where(x => !string.IsNullOrEmpty(x.Texto("id_titulo")))
            .GroupBy(x => x.Texto("id_titulo"), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(x => x.Key, x => x.First(), StringComparer.OrdinalIgnoreCase);
        var hijos = filas.GroupBy(x => x.Texto("id_titulopadre"), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(x => x.Key, x => x.OrderBy(y => y.Entero("posicion_titulo")).ToList(), StringComparer.OrdinalIgnoreCase);
        var configuracion = new MYGConfiguracionFormulaPolinomica();
        var usados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var raiz in filas.Where(x => !porId.ContainsKey(x.Texto("id_titulopadre"))).OrderBy(x => x.Entero("posicion_titulo")))
        {
            var grupo = new MYGGrupoFormulaPolinomica
            {
                Id = raiz.Texto("id_titulo"), Descripcion = raiz.Texto("descripcion_titulo"),
                Nomenclatura = raiz.Texto("nomenclatura"),
                CoeficienteDefinido = raiz.Valor("coeficientedefinido") == null ? null : raiz.Numero("coeficientedefinido")
            };
            var pendientes = new Stack<string>(); pendientes.Push(raiz.Texto("id_titulo"));
            var visitados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            while (pendientes.TryPop(out string id))
            {
                if (!visitados.Add(id) || !porId.TryGetValue(id, out var fila)) continue;
                bool tieneHijos = hijos.TryGetValue(id, out var descendientes);
                if (!tieneHijos || Igual(fila.Texto("es_indice"), "S"))
                {
                    string codigo = MYGCatalogoIndicesUnificados.CodigoDeClasificacion(fila.Texto("codigo_clase"));
                    if (!string.IsNullOrEmpty(codigo) && usados.Add(codigo)) grupo.Indices.Add(codigo);
                }
                if (tieneHijos) foreach (var hijo in descendientes.AsEnumerable().Reverse()) pendientes.Push(hijo.Texto("id_titulo"));
            }
            if (grupo.Indices.Count > 0) configuracion.Grupos.Add(grupo);
        }
        if (configuracion.Grupos.Count > 0) presupuesto.FormulaPolinomica = configuracion;
    }
}
