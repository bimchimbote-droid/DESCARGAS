using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Xml.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class FormulaPolinomicaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Fórmula polinómica: " + mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Matriz(pasa);
        ImportadosYRedondeos(pasa);
        Agrupaciones(pasa);
        Advertencias(pasa);
        Persistencia(carpeta, pasa);
        AgrupacionNativa(carpeta, pasa);
        ReportesYExcel(carpeta, pasa);
    }

    private static ItemPresupuestoDelphin Partida(string id, decimal cantidad, string padre = "T") => new()
    {
        Id = id, IdLocalMYG = id, IdPropuesta = id, ParentId = padre, Item = id,
        Descripcion = id, TipoPropuesta = "PARTIDA", Unidad = "und", Origen = "MODELO", Estado = "PROPUESTA",
        Costos = new() { Cantidad = cantidad }
    };

    private static MYGProyectoDocumento Crear()
    {
        var doc = MYGProyectoStorage.Nuevo("Fórmula polinómica QA");
        var p = doc.Presupuestos.Single();
        p.Items.Add(new() { Id = "T", IdLocalMYG = "T", Item = "01", Descripcion = "ESTRUCTURAS",
            TipoPropuesta = "TITULO", Unidad = "", Origen = "MODELO", Estado = "PROPUESTA" });
        p.Costos.Insumos.AddRange(new[]
        {
            new MYGInsumo { Id = "MO", Codigo = "R-MO", Descripcion = "Mano de obra", Grupo = MYGGrupoRecurso.ManoObra,
                Unidad = "hh", Precio = 100, GrupoGenerico = "47 · Mano de obra" },
            new MYGInsumo { Id = "MAT", Codigo = "R-MAT", Descripcion = "Cemento", Precio = 40,
                GrupoGenerico = "21 · Cemento", IGVPorcentaje = 18 },
            new MYGInsumo { Id = "HERR", Codigo = "R-HERR", Descripcion = "Herramienta", Grupo = MYGGrupoRecurso.Equipo,
                Unidad = "%mo", GrupoGenerico = "37 · Herramienta" }
        });
        var principal = Partida("PRINCIPAL", 2);
        principal.Costos.Analisis.AddRange(new[]
        {
            new MYGRecursoACU { InsumoId = "MO", Grupo = MYGGrupoRecurso.ManoObra, Cantidad = 1 },
            new MYGRecursoACU { InsumoId = "MAT", Cantidad = 1 },
            new MYGRecursoACU { InsumoId = "HERR", Grupo = MYGGrupoRecurso.Equipo,
                Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 10 }
        });
        var sub = Partida("SUB", 0);
        sub.Costos.Analisis.AddRange(new[]
        {
            new MYGRecursoACU { InsumoId = "MO", Grupo = MYGGrupoRecurso.ManoObra, Cantidad = 0.2m },
            new MYGRecursoACU { InsumoId = "MAT", Cantidad = 0.5m }
        });
        var compuesta = Partida("COMPUESTA", 1);
        compuesta.Costos.Analisis.AddRange(new[]
        {
            new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = "SUB", Cantidad = 3 },
            new MYGRecursoACU { InsumoId = "MAT", Cantidad = 1 }
        });
        var directa = Partida("PRECIO DIRECTO", 3); directa.Costos.PrecioDirecto = 7;
        p.Items.AddRange(new[] { principal, sub, compuesta, directa });
        return doc;
    }

    private static void Matriz(Action<string> pasa)
    {
        var doc = Crear(); var p = doc.Presupuestos.Single();
        string antes = JsonSerializer.Serialize(doc);
        var matriz = MYGFormulaPolinomica.Preparar(p);
        Exige(JsonSerializer.Serialize(doc) == antes && p.FormulaPolinomica == null,
            "consultar la matriz modificó el documento o creó configuración persistente.");
        Exige(matriz.Total == 481 && matriz.Total == MYGMotorPresupuestos.Resumen(p).CostoDirecto &&
            matriz.Indices.Sum(x => x.Total) == matriz.Total &&
            matriz.Filas.Where(x => !x.EsTitulo).Sum(x => x.Total) == matriz.Total,
            "el costo directo se duplicó al incluir títulos o subpartidas.");
        Exige(matriz.Indices.Single(x => x.Codigo == "47").Total == 260 &&
            matriz.Indices.Single(x => x.Codigo == "21").Total == 180 &&
            matriz.Indices.Single(x => x.Codigo == "37").Total == 20 &&
            matriz.Indices.Single(x => x.Codigo == MYGFormulaPolinomica.SinIndice).Total == 21,
            "no se expandieron los ACU, subpartidas y porcentajes de mano de obra en sus índices reales.");
        Exige(matriz.Filas.All(x => x.Importes.Values.Sum() == x.Total) &&
            matriz.Filas.Single(x => x.EsTitulo).Total == 481,
            "el desglose de alguna partida o título no concilia con su total.");
        pasa("Fórmula polinómica desglosa ACU, subpartidas y porcentajes sin duplicar títulos ni modificar el presupuesto");

        p.Costos.ConfiguracionCostoDirecto = new() { IncluirIgvMateriales = true };
        matriz = MYGFormulaPolinomica.Preparar(p);
        Exige(matriz.Total == 513.4m && matriz.Total == MYGMotorPresupuestos.Resumen(p).CostoDirecto &&
            matriz.Indices.Sum(x => x.Total) == matriz.Total &&
            matriz.Indices.Single(x => x.Codigo == "21").Total == 212.4m,
            "el desglose no incorporó el IGV efectivo o gravó dos veces las subpartidas.");
        pasa("Fórmula polinómica aplica el IGV efectivo del motor y concilia el costo directo por índices");

        p.Costos.Insumos.Single(x => x.Id == "MAT").GrupoGenerico = "";
        p.Costos.Insumos.Single(x => x.Id == "MAT").Codigo = "21";
        matriz = MYGFormulaPolinomica.Preparar(p);
        Exige(!matriz.Indices.Any(x => x.Codigo == "21") &&
            matriz.Indices.Single(x => x.Codigo == MYGFormulaPolinomica.SinIndice).Total == 233.4m,
            "se inventó un índice unificado a partir del código interno de un insumo.");
        pasa("Fórmula polinómica identifica importes sin índice sin inferirlo de códigos internos");
    }

    private static void ImportadosYRedondeos(Action<string> pasa)
    {
        var p = Crear().Presupuestos.Single();
        var partida = p.Items.Single(x => x.Id == "PRINCIPAL");
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, partida, 150.01m, 300.03m);
        var matriz = MYGFormulaPolinomica.Preparar(p);
        Exige(matriz.Total == 481.03m && matriz.Indices.Sum(x => x.Total) == matriz.Total &&
            matriz.Filas.Single(x => x.Id == partida.Id).Total == 300.03m &&
            matriz.Filas.All(x => x.Importes.Values.Sum() == x.Total),
            "los precios o parciales importados perdieron sus redondeos en la matriz.");
        Exige(matriz.Indices.Single(x => x.Codigo == MYGFormulaPolinomica.SinIndice).Total == 21.03m,
            "se atribuyó una diferencia importada a un índice supuesto.");
        pasa("Fórmula polinómica conserva parciales Delphin y muestra separadamente las diferencias de redondeo");
    }

    private static void Agrupaciones(Action<string> pasa)
    {
        var p = Crear().Presupuestos.Single();
        var matriz = MYGFormulaPolinomica.Preparar(p);
        var configuracion = new MYGConfiguracionFormulaPolinomica
        {
            Grupos = new()
            {
                new() { Id = "MO-H", Descripcion = "Mano de obra y herramientas", Nomenclatura = "J",
                    Indices = new() { "47", "37", "47" }, CoeficienteDefinido = 0.6m },
                new() { Id = "M", Descripcion = "Materiales", Nomenclatura = "M", Indices = new() { "21", "47", "NO_EXISTE" } }
            }
        };
        string original = JsonSerializer.Serialize(configuracion);
        var normalizada = MYGFormulaPolinomica.CrearConfiguracion(matriz, configuracion);
        var calculado = MYGFormulaPolinomica.CalcularAgrupacion(matriz, configuracion);
        Exige(original == JsonSerializer.Serialize(configuracion) && p.FormulaPolinomica == null &&
            normalizada.Grupos.SelectMany(x => x.Indices).Order().SequenceEqual(matriz.Indices.Select(x => x.Codigo).Order()),
            "la agrupación modificó el original, duplicó índices o perdió índices nuevos.");
        var grupo = calculado.Monomios.Single(x => x.Id == "MO-H");
        Exige(grupo.Importe == 280 && grupo.Indices.Count == 2 && grupo.CoeficienteDefinido == 0.6m &&
            grupo.Porcentajes.Values.Sum() == 100 &&
            Math.Abs(calculado.TotalCalculado - 1) < 0.00000000000000000000000001m &&
            calculado.Monomios.Sum(x => x.Importe) == matriz.Total,
            "agrupar alteró el importe total, el coeficiente definido o los porcentajes internos.");
        // La matriz es una instantánea. Reagrupar no debe volver a analizar costos ya editados.
        p.Costos.Insumos.Single(x => x.Id == "MO").Precio = 999;
        var repetido = MYGFormulaPolinomica.CalcularAgrupacion(matriz, configuracion);
        Exige(repetido.Monomios.Single(x => x.Id == "MO-H").Importe == 280,
            "reagrupar volvió a recorrer los ACU en vez de reutilizar la matriz preparada.");
        normalizada.Grupos[0].Descripcion = "Cambio aislado";
        Exige(configuracion.Grupos[0].Descripcion != normalizada.Grupos[0].Descripcion,
            "la configuración de edición conserva referencias mutables a la del documento.");
        pasa("Agrupar monomios conserva importes y porcentajes, normaliza índices únicos y reutiliza la matriz sin recalcular ACU");
    }

    private static void Advertencias(Action<string> pasa)
    {
        var matriz = new MYGMatrizFormulaPolinomica { Total = 100 };
        for (int n = 1; n <= 10; n++) matriz.Indices.Add(new() { Codigo = n.ToString("D2"), Descripcion = "Índice " + n, Total = n == 1 ? 1 : 11 });
        var resultado = MYGFormulaPolinomica.CalcularAgrupacion(matriz);
        Exige(resultado.Advertencias.Any(x => x.Contains("8 monomios")) &&
            resultado.Advertencias.Any(x => x.Contains("0,050")) && resultado.Monomios.Count == 10,
            "los avisos deben permitir agrupar una fórmula inicial con más de ocho monomios o coeficientes pequeños.");
        var configuracion = new MYGConfiguracionFormulaPolinomica { Grupos = new()
            { new() { Id = "UNICO", Nomenclatura = "K", Indices = matriz.Indices.Select(x => x.Codigo).ToList() } } };
        resultado = MYGFormulaPolinomica.CalcularAgrupacion(matriz, configuracion);
        Exige(resultado.Advertencias.Count == 0 && resultado.TotalDefinido == 1 && resultado.Monomios.Count == 1,
            "agrupar todos los índices no resolvió los avisos ni conservó la suma uno.");
        resultado = MYGFormulaPolinomica.CalcularAgrupacion(new());
        Exige(resultado.TotalCalculado == 0 && resultado.TotalDefinido == 0 && resultado.Advertencias.Count > 0,
            "un presupuesto vacío produjo coeficientes inválidos o división entre cero.");
        pasa("Fórmula polinómica informa límites de ocho monomios y coeficiente mínimo, y permite corregirlos agrupando");
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var doc = Crear(); var p = doc.Presupuestos.Single();
        Exige(!MYGJsonAlmacenamiento.Serializar(doc).Contains("FormulaPolinomica"),
            "el campo no configurado altera el JSON de presupuestos anteriores.");
        string firmaAnterior = MYGProyectoStorage.Firma(doc);
        p.FormulaPolinomica = MYGFormulaPolinomica.CrearConfiguracion(MYGFormulaPolinomica.Preparar(p));
        var primero = p.FormulaPolinomica.Grupos[0];
        primero.Descripcion = "Grupo personalizado con acento"; primero.Nomenclatura = "J"; primero.CoeficienteDefinido = 0.123m;
        Exige(MYGProyectoStorage.Firma(doc) != firmaAnterior,
            "la edición de monomios no aparece en la firma de cambios del documento.");
        string esperado = JsonSerializer.Serialize(p.FormulaPolinomica);
        var copia = MYGProyectoStorage.Copia(doc);
        copia.Presupuestos.Single().FormulaPolinomica.Grupos[0].Indices.Clear();
        Exige(p.FormulaPolinomica.Grupos[0].Indices.Count == 1,
            "cancelar/deshacer sobre una copia elimina índices del documento original.");
        var json = MYGJsonAlmacenamiento.Deserializar<MYGProyectoDocumento>(MYGJsonAlmacenamiento.Serializar(doc));
        Exige(JsonSerializer.Serialize(json.Presupuestos.Single().FormulaPolinomica) == esperado,
            "el recorrido JSON pierde coeficientes definidos, nomenclatura, orden o identidad de monomios.");
        string ruta = Path.Combine(carpeta, "Formula polinomica QA.sqlite");
        MYGProyectoStorage.Guardar(ruta, doc);
        foreach (var leido in new[] { MYGProyectoStorage.Leer(ruta), MYGBaseDatos.LeerProyecto(ruta, doc.Id) })
            Exige(JsonSerializer.Serialize(leido.Presupuestos.Single().FormulaPolinomica) == esperado,
                "guardar y reabrir SQLite perdió la configuración completa de los monomios.");
        p.FormulaPolinomica = null;
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(MYGProyectoStorage.Leer(ruta).Presupuestos.Single().FormulaPolinomica == null,
            "borrar la configuración de fórmula resucitó una agrupación anterior al reabrir SQLite.");
        pasa("Configuración polinómica conserva firma, copia aislada y recorridos JSON/SQLite sin alterar documentos históricos");
    }

    private static void AgrupacionNativa(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Formula nativa Delphin.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString()))
        {
            conexion.Open(); using var cmd = conexion.CreateCommand();
            cmd.CommandText = """
                INSERT INTO proyecto(id_proyecto,id_usuario,id_infraestructura,id_ubicacion,nombre_proyecto,tipo_gasto,decimales_costo)
                VALUES('PR-FORM','US0000000001','IN0000000007','No','FÓRMULA NATIVA','PR',2);
                INSERT INTO presupuesto(id_presupuesto,id_proyecto,nombre_presupuesto,posicion_presupuesto,numeracion_presupuesto)
                VALUES('PS-FORM','PR-FORM','ESTRUCTURAS',1,'01');
                INSERT INTO unidad(id_unidad,abreviatura_unidad) VALUES('U-FORM','und');
                INSERT INTO costo_unitario(id_costounitario,id_presupuesto,id_unidad,descripcion_costo,cantidad,costo_unitario,parcial_costo)
                VALUES('CU-FORM','PS-FORM','U-FORM','Partida',1,100,100);
                INSERT INTO titulo_indice(id_titulo,id_titulopadre,id_presupuesto,descripcion_titulo,posicion_titulo,nomenclatura,coeficientedefinido,codigo_clase,es_indice) VALUES
                ('GR-MO',NULL,'PS-FORM','Mano de obra y herramientas',1,'J',0.75,NULL,'N'),
                ('IU-MO','GR-MO','PS-FORM','Mano de obra',1,NULL,NULL,'47','S'),
                ('IU-HERR','GR-MO','PS-FORM','Herramientas',2,NULL,NULL,'37','S'),
                ('GR-MAT','','PS-FORM','Materiales',2,'M',0.25,'21','S');
                """;
            cmd.ExecuteNonQuery();
        }
        string antes = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
        var doc = MYGBaseDatos.LeerProyecto(ruta);
        var grupos = doc.Presupuestos.Single().FormulaPolinomica.Grupos;
        Exige(grupos.Count == 2 && grupos[0].Id == "GR-MO" && grupos[0].Nomenclatura == "J" &&
            grupos[0].CoeficienteDefinido == 0.75m && grupos[0].Indices.SequenceEqual(new[] { "47", "37" }) &&
            grupos[1].Id == "GR-MAT" && grupos[1].Indices.Single() == "21" && grupos[1].CoeficienteDefinido == 0.25m,
            "la importación nativa perdió agrupaciones anidadas, orden, nomenclatura o coeficientes definidos.");
        Exige(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta))) == antes,
            "consultar las agrupaciones nativas modificó la base Delphin.");
        grupos[0].Descripcion = "Agrupación editada";
        grupos[0].Nomenclatura = "JO"; grupos[0].CoeficienteDefinido = 0.7m;
        grupos[0].Indices.Reverse();
        string esperado = JsonSerializer.Serialize(doc.Presupuestos.Single().FormulaPolinomica);
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(JsonSerializer.Serialize(MYGProyectoStorage.Leer(ruta).Presupuestos.Single().FormulaPolinomica) == esperado,
            "la extensión MYG sobre SQLite nativo perdió agrupaciones editadas al reabrir.");
        using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly }.ToString()))
        {
            conexion.Open(); using var cmd = conexion.CreateCommand();
            cmd.CommandText = "SELECT nomenclatura || ':' || coeficientedefinido FROM titulo_indice WHERE id_titulo='GR-MO'";
            Exige((string)cmd.ExecuteScalar() == "J:0.75",
                "guardar una extensión MYG sobrescribió la fórmula nativa de la base Delphin.");
        }
        pasa("Importación polinómica lee grupos e índices nativos anidados, orden y coeficientes sin escribir la base de origen");
    }

    private static void ReportesYExcel(string carpeta, Action<string> pasa)
    {
        var p = Crear().Presupuestos.Single();
        var matriz = MYGFormulaPolinomica.Preparar(p);
        var configuracion = MYGFormulaPolinomica.CrearConfiguracion(matriz);
        configuracion.Grupos[0].Descripcion = "=SUM(1,2)";
        configuracion.Grupos[0].Nomenclatura = "=J";
        configuracion.Grupos[0].CoeficienteDefinido = 0.125m;
        var resultado = MYGFormulaPolinomica.CalcularAgrupacion(matriz, configuracion);
        string original = JsonSerializer.Serialize(matriz), gruposAntes = JsonSerializer.Serialize(resultado);
        var detallado = MYGFormulaPolinomicaReportes.CrearDetallado("Presupuesto QA", matriz);
        var formula = MYGFormulaPolinomicaReportes.CrearFormula("Presupuesto QA", resultado);
        var calculoDetalle = new MYGHojaCalculo(detallado.Hoja);
        var calculoFormula = new MYGHojaCalculo(formula.Hoja);
        Exige(detallado.Hoja.Columnas == 5 + matriz.Indices.Count && formula.Hoja.Columnas == 6 &&
            calculoDetalle.Resultado(detallado.Hoja.CeldaTotal).Numero() == 481 &&
            calculoFormula.Resultado(formula.Hoja.CeldaTotal).Numero() == resultado.TotalDefinido &&
            formula.Hoja.Celdas.Keys.Any(k => calculoFormula.Mostrar(k).Contains("K = ", StringComparison.Ordinal)) &&
            formula.Hoja.Celdas.Keys.Any(k => calculoFormula.Mostrar(k).Contains("importe sin índice", StringComparison.Ordinal)),
            "los informes perdieron columnas, totales, expresión o la advertencia de importes sin índice.");
        Exige(calculoFormula.Mostrar("A2") == "=SUM(1,2)" && calculoFormula.Mostrar("B2") == "=J" &&
            calculoFormula.Resultado("E2").Numero() == 0.125m,
            "un nombre que empieza por igual se evaluó como fórmula o se perdió el coeficiente definido.");
        string ruta = Path.Combine(carpeta, "Formula polinomica informes.xlsx");
        var hojasExcel = MYGReportesExcel.CrearHojas(new[] { detallado, formula });
        var calculoExcel = new MYGHojaCalculo(hojasExcel[1]);
        string direccionLiteral = hojasExcel[1].Celdas.Keys.Single(k => calculoExcel.Mostrar(k) == "=SUM(1,2)");
        int filaGrupo = MYGHojaCalculo.Coordenadas(direccionLiteral).Fila;
        MYGExcelPresupuestos.Guardar(ruta, hojasExcel);
        XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        using (var zip = ZipFile.OpenRead(ruta))
        {
            using var libroStream = zip.GetEntry("xl/workbook.xml").Open();
            var libro = XDocument.Load(libroStream);
            Exige(libro.Descendants(s + "sheet").Count() == 2,
                "el libro Excel no conserva las dos hojas de detalle y fórmula.");
            using var detalleStream = zip.GetEntry("xl/worksheets/sheet1.xml").Open();
            using var formulaStream = zip.GetEntry("xl/worksheets/sheet2.xml").Open();
            var hojaDetalle = XDocument.Load(detalleStream); var hojaFormula = XDocument.Load(formulaStream);
            XElement Celda(XDocument xml, string direccion) => xml.Descendants(s + "c").Single(c => (string)c.Attribute("r") == direccion);
            Exige(decimal.Parse(Celda(hojaDetalle, hojasExcel[0].CeldaTotal).Element(s + "v").Value, CultureInfo.InvariantCulture) == 481 &&
                decimal.Parse(Celda(hojaFormula, "E" + filaGrupo).Element(s + "v").Value, CultureInfo.InvariantCulture) == 0.125m,
                "Excel perdió el costo directo o el coeficiente definido como valores numéricos.");
            var literal = Celda(hojaFormula, direccionLiteral);
            var nomenclatura = Celda(hojaFormula, "B" + filaGrupo);
            // El escritor XLSX existente conserva textos que comienzan por '='
            // como fórmulas constantes entre comillas, con valor cacheado de texto.
            Exige((string)literal.Attribute("t") == "str" && literal.Element(s + "v").Value == "=SUM(1,2)" &&
                literal.Element(s + "f").Value == "\"=SUM(1,2)\"" &&
                nomenclatura.Element(s + "f").Value == "\"=J\"" && nomenclatura.Element(s + "v").Value == "=J",
                "Excel ejecutaría el nombre o la nomenclatura como una fórmula en vez de conservarlos como texto.");
            Exige(hojaDetalle.Descendants(s + "t").Any(t => t.Value.Contains("SIN_INDICE", StringComparison.Ordinal)) &&
                hojaFormula.Descendants(s + "t").Any(t => t.Value.Contains("ADVERTENCIA:", StringComparison.Ordinal)),
                "Excel perdió los encabezados por índice o los avisos de validación.");
        }
        Exige(JsonSerializer.Serialize(matriz) == original && JsonSerializer.Serialize(resultado) == gruposAntes,
            "componer informes o exportar a Excel modificó la matriz o los monomios.");
        pasa("Informes polinómicos y libro Excel conservan detalle, monomios, totales, fórmula, avisos y nombres literales seguros");
    }
}
