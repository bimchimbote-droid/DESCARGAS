using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Configura una copia del informe; el proyecto y su historial quedan intactos.</summary>
internal sealed class MYGVistaPreliminarReportesForm : Form
{
    private readonly MYGConfiguracionVistaReporte configuracion;
    private readonly string nombreDocumento;
    private readonly Func<MYGHojaReporteProyecto> crearMetradosExcel;
    private readonly Action<string, string> validarDestino;
    private readonly MYGVistaPaginaControl superficie = new();
    private readonly TabControl cinta = new() { Name = "vista_cinta", Dock = DockStyle.Top, Height = 160 };
    private readonly TrackBar deslizadorZoom = new() { Name = "vista_deslizador_zoom", Minimum = 10, Maximum = 500, Value = 100, TickStyle = TickStyle.None, AutoSize = false, Width = 180, Height = 28 };
    private readonly Label estado = new() { Dock = DockStyle.Bottom, Height = 28, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8, 0, 0, 0) };
    private readonly ComboBox impresoras = Lista("vista_impresora");
    private readonly ComboBox orientacion = Lista("vista_orientacion");
    private readonly ComboBox tamano = Lista("vista_papel");
    private readonly ComboBox fuentes = Lista("vista_fuente");
    private readonly ComboBox zoom = Lista("vista_zoom");
    private readonly NumericUpDown escala = Numero("vista_escala", 25, 200, 100);
    private readonly NumericUpDown izquierda = Margen("vista_margen_izquierdo"), derecha = Margen("vista_margen_derecho");
    private readonly NumericUpDown superior = Margen("vista_margen_superior"), inferior = Margen("vista_margen_inferior");
    private readonly NumericUpDown desde = Numero("vista_desde", 1, 100000, 1), hasta = Numero("vista_hasta", 1, 100000, 1);
    private readonly NumericUpDown copias = Numero("vista_copias", 1, 999, 1);
    private readonly CheckBox rango = new() { Text = "Solo páginas indicadas", AutoSize = true, Name = "vista_rango" };
    private readonly CheckBox lineas = new() { Text = "Líneas de división", AutoSize = true, Name = "vista_lineas" };
    private readonly CheckBox encabezados = new() { Text = "Letras y números de celdas", AutoSize = true, Name = "vista_encabezados" };
    private readonly CheckBox titulos = new() { Text = "Repetir filas de título", AutoSize = true, Name = "vista_titulos" };
    private readonly CheckBox coloresTitulos = new() { Text = "Colorear títulos según presupuesto", AutoSize = true,
        Name = "vista_colores_titulos", AccessibleDescription = "Usa los colores de los niveles del presupuesto en la vista, impresión y PDF." };
    private readonly Button imprimir, pdf;
    private readonly List<ToolStripItem> accionesSalida = new();
    private readonly MYGActualizacionDiferida<Func<Action<string>, MYGReportesImpresion.Vista>, MYGReportesImpresion.Vista> actualizacion;
    private ToolStripButton primera, anterior, siguiente, ultima, puntero, mano, varias;
    private MYGReportesImpresion.Vista vista;
    private int pagina;
    private bool cargando;
    private bool paginaInvalida;
    private bool vistaInicialPreparada;
    private Exception errorActualizacion;
    private Color colorPagina = Color.White;
    private string filigrana = "", ultimoPdf;
    private float ampliacion => superficie.Ampliacion;

    internal MYGConfiguracionVistaReporte Configuracion => configuracion;
    internal int CantidadPaginas => vista?.CantidadPaginas ?? 0;
    internal int PreparacionesVista { get; private set; }
    internal bool ActualizacionPendiente => actualizacion.Pendiente;
    internal bool VistaActualizada => vista != null && !ActualizacionPendiente && !paginaInvalida && errorActualizacion == null;
    internal Task EsperarActualizacionAsync() => actualizacion.EsperarAsync();

    internal MYGVistaPreliminarReportesForm(string nombre, IReadOnlyList<MYGHojaReporteProyecto> reportes,
        Func<MYGHojaReporteProyecto> crearMetradosExcel = null, Action<string, string> validarDestino = null,
        MYGConfiguracionVistaReporte configuracionPreparada = null)
    {
        configuracion = configuracionPreparada ?? new MYGConfiguracionVistaReporte(reportes);
        actualizacion = new MYGActualizacionDiferida<Func<Action<string>, MYGReportesImpresion.Vista>, MYGReportesImpresion.Vista>(
            preparar => MYGCargaAnimada.EnStaAsync(preparar, _ => { }),
            nueva => AplicarVista(nueva, conservarDesplazamiento: true),
            MostrarFalloActualizacion);
        actualizacion.EstadoChanged += (_, _) => { if (!IsDisposed && !Disposing) { ActualizarSalidas(); ActualizarEstado(); } };
        this.crearMetradosExcel = crearMetradosExcel;
        this.validarDestino = validarDestino;
        if (configuracionPreparada == null) configuracion.Fuente("Arial Narrow");
        nombreDocumento = nombre ?? "Reportes del proyecto";
        Name = "vista_preliminar_reportes";
        Text = "Vista preliminar · " + nombreDocumento;
        AutoScaleDimensions = new SizeF(96, 96);
        AutoScaleMode = AutoScaleMode.Dpi;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1280, 850); MinimumSize = new Size(960, 650);
        WindowState = FormWindowState.Maximized;
        Font = new Font("Segoe UI", 9);
        BackColor = Color.FromArgb(226, 236, 246);

        CrearCinta();
        var opciones = new FlowLayoutPanel { Name = "vista_opciones", Dock = DockStyle.Left, Width = 280,
            FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(10), BackColor = Color.FromArgb(213, 227, 241) };
        void Campo(string texto, Control control)
        {
            opciones.Controls.Add(new Label { Text = texto, AutoSize = true, Margin = new Padding(3, 8, 3, 3) });
            control.Width = 240; opciones.Controls.Add(control);
        }
        opciones.Controls.Add(new Label { Text = "Imprimir / exportar PDF", Font = new Font(Font, FontStyle.Bold), AutoSize = true });
        Campo("Impresora", impresoras);
        imprimir = new Button { Name = "vista_imprimir", Text = "Imprimir", Width = 240, Height = 32 };
        imprimir.Click += (_, _) => Intentar(Imprimir); opciones.Controls.Add(imprimir);
        pdf = new Button { Name = "vista_pdf", Text = "Exportar PDF…", Width = 240, Height = 32 };
        pdf.Click += (_, _) => Intentar(ExportarPdf); opciones.Controls.Add(pdf);
        opciones.Controls.Add(rango);
        Campo("Desde la página", desde); Campo("Hasta la página", hasta); Campo("Copias", copias);
        opciones.Controls.Add(new Label { Text = "Configuración de todas las hojas", Font = new Font(Font, FontStyle.Bold), AutoSize = true, Margin = new Padding(3, 14, 3, 3) });
        orientacion.Items.AddRange(new object[] { "Vertical", "Horizontal" });
        orientacion.DrawMode = DrawMode.OwnerDrawFixed;
        orientacion.ItemHeight = 26;
        orientacion.DrawItem += DibujarOrientacion;
        tamano.Items.AddRange(MYGPapelReporte.Nombres.Cast<object>().ToArray());
        var familias = FontFamily.Families;
        try { fuentes.Items.AddRange(familias.Select(f => f.Name).OrderBy(n => n).Cast<object>().ToArray()); }
        finally { foreach (var familia in familias) familia.Dispose(); }
        Campo("Orientación", orientacion); Campo("Tamaño de papel", tamano);
        Campo("Margen izquierdo (cm)", izquierda); Campo("Margen derecho (cm)", derecha);
        Campo("Margen superior (cm)", superior); Campo("Margen inferior (cm)", inferior);
        Campo("Fuente", fuentes); Campo("Escala de impresión (%)", escala);
        opciones.Controls.Add(titulos); opciones.Controls.Add(lineas); opciones.Controls.Add(encabezados); opciones.Controls.Add(coloresTitulos);
        zoom.Items.AddRange(new object[] { "10%", "25%", "50%", "75%", "100%", "125%", "150%", "200%", "300%", "400%", "500%" });
        zoom.SelectedItem = "100%";
        Campo("Ampliación de la vista", zoom);
        var pie = new Panel { Name = "vista_estado", Dock = DockStyle.Bottom, Height = 34 };
        estado.Dock = DockStyle.Fill;
        var zoomPie = new FlowLayoutPanel { Dock = DockStyle.Right, Width = 250, WrapContents = false, Padding = new Padding(0, 2, 0, 0) };
        var menos = new Button { Name = "vista_zoom_menos_pie", Text = "−", Width = 28, Height = 27, Margin = Padding.Empty };
        var mas = new Button { Name = "vista_zoom_mas_pie", Text = "+", Width = 28, Height = 27, Margin = Padding.Empty };
        menos.Click += (_, _) => CambiarZoom(ampliacion / 1.12f);
        mas.Click += (_, _) => CambiarZoom(ampliacion * 1.12f);
        zoomPie.Controls.Add(menos); zoomPie.Controls.Add(deslizadorZoom); zoomPie.Controls.Add(mas);
        pie.Controls.Add(estado); pie.Controls.Add(zoomPie);
        Controls.Add(superficie); Controls.Add(opciones); Controls.Add(pie); Controls.Add(cinta);
        zoom.DropDownStyle = ComboBoxStyle.DropDown;
        KeyPreview = true;

        CargarAjustes();
        foreach (var control in new Control[] { orientacion, tamano, izquierda, derecha, superior, inferior })
        {
            if (control is ComboBox combo) combo.SelectedIndexChanged += (_, _) => CambiarPagina();
            else ((NumericUpDown)control).ValueChanged += (_, _) => CambiarPagina();
        }
        escala.ValueChanged += (_, _) => Cambiar(() =>
        {
            configuracion.Escala = (float)escala.Value / 100;
            configuracion.PaginasDeAncho = 0;
        });
        fuentes.SelectedIndexChanged += (_, _) => Cambiar(() => configuracion.Fuente(fuentes.Text));
        lineas.CheckedChanged += (_, _) => CambiarApariencia(() => configuracion.LineasDivision(lineas.Checked));
        encabezados.CheckedChanged += (_, _) => Cambiar(() => configuracion.Encabezados(encabezados.Checked));
        titulos.CheckedChanged += (_, _) => Cambiar(() => configuracion.RepetirTitulos(titulos.Checked));
        coloresTitulos.CheckedChanged += (_, _) => CambiarApariencia(() => configuracion.ColorearTitulos(coloresTitulos.Checked, ColorTituloPresupuesto));
        zoom.SelectedIndexChanged += (_, _) => { if (!cargando) Intentar(LeerZoom); };
        zoom.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Intentar(LeerZoom); } };
        deslizadorZoom.ValueChanged += (_, _) => { if (!cargando) CambiarZoom((float)deslizadorZoom.Value / 100); };
        superficie.AmpliacionChanged += (_, _) => ActualizarPosicionVista();
        superficie.PaginaActualChanged += (_, _) => ActualizarPosicionVista();
        superficie.ErrorPreparacion += error =>
        {
            InvalidarVista();
            Intentar(() => throw new InvalidOperationException("No se pudo preparar la página del informe. Vuelva a actualizar la vista.", error));
        };
        KeyDown += (_, e) =>
        {
            if (!e.Control) return;
            if (e.KeyCode is Keys.Add or Keys.Oemplus) CambiarZoom(ampliacion * 1.12f);
            else if (e.KeyCode is Keys.Subtract or Keys.OemMinus) CambiarZoom(ampliacion / 1.12f);
            else if (e.KeyCode == Keys.D0) AjustarPagina();
            else return;
            e.Handled = true; e.SuppressKeyPress = true;
        };
        impresoras.SelectedIndexChanged += (_, _) => { if (!cargando) ProgramarActualizacion(); };
        rango.CheckedChanged += (_, _) => desde.Enabled = hasta.Enabled = rango.Checked;
        desde.Enabled = hasta.Enabled = false;
        Shown += (_, _) => Intentar(() =>
        {
            if (!vistaInicialPreparada)
                MYGCargaAnimada.EjecutarConProgreso(this, "Preparando vista preliminar…", async progreso =>
                { await PrepararInicialAsync(progreso); return true; });
            // El maximizado puede cambiar el espacio disponible al presentarse.
            AjustarPagina();
        });
    }

    internal static MYGVistaPreliminarReportesForm CrearPreparada(Form propietario, string nombre,
        IReadOnlyList<MYGHojaReporteProyecto> reportes, Func<MYGHojaReporteProyecto> crearMetradosExcel = null,
        Action<string, string> validarDestino = null)
        => CrearPreparada(propietario, nombre, _ => reportes, crearMetradosExcel, validarDestino);

    internal static MYGVistaPreliminarReportesForm CrearPreparada(Form propietario, string nombre,
        Func<Action<string>, IReadOnlyList<MYGHojaReporteProyecto>> prepararReportes,
        Func<MYGHojaReporteProyecto> crearMetradosExcel = null, Action<string, string> validarDestino = null)
    {
        MYGVistaPreliminarReportesForm preparada = null;
        try
        {
            return MYGCargaAnimada.EjecutarConProgreso(propietario, "Preparando vista preliminar del informe…", async progreso =>
            {
                var copia = await MYGCargaAnimada.EnStaAsync(informar =>
                {
                    informar("Preparando los datos del informe…");
                    var reportes = prepararReportes(informar);
                    informar("Preparando las copias de las hojas y sus fórmulas…");
                    var ajustes = new MYGConfiguracionVistaReporte(reportes);
                    informar("Preparando las fuentes y los formatos de impresión…");
                    ajustes.Fuente("Arial Narrow");
                    return ajustes;
                }, progreso.Report);
                progreso.Report("Construyendo las herramientas de la vista preliminar…");
                preparada = new MYGVistaPreliminarReportesForm(nombre, copia.Reportes, crearMetradosExcel, validarDestino, copia);
                await preparada.PrepararInicialAsync(progreso);
                return preparada;
            });
        }
        catch { preparada?.Dispose(); throw; }
    }

    private async Task PrepararInicialAsync(IProgress<string> progreso)
    {
        progreso.Report("Consultando las impresoras disponibles…");
        var disponibles = await MYGCargaAnimada.EnStaAsync(_ => LeerImpresoras(), progreso.Report);
        AplicarImpresoras(disponibles.Nombres, disponibles.Predeterminada);
        InvalidarVista();
        var preparar = CrearSolicitudVista(copiarActuales: false);
        var nueva = await MYGCargaAnimada.EnStaAsync(preparar, progreso.Report);
        progreso.Report("Preparando la ventana y sus controles…");
        cargando = true;
        try { CrearHandles(this); }
        finally { cargando = false; }
        progreso.Report("Dibujando la primera página del informe…");
        AplicarVista(nueva);
        AjustarPagina();
        vistaInicialPreparada = true;
        progreso.Report("Vista preliminar preparada: " + CantidadPaginas + " páginas.");
    }

    private static void CrearHandles(Control control)
    {
        _ = control.Handle;
        if (control is TabControl pestanas)
        {
            if (pestanas.SelectedTab != null) CrearHandles(pestanas.SelectedTab);
        }
        else foreach (Control hijo in control.Controls) CrearHandles(hijo);
        control.PerformLayout();
    }

    private void CrearCinta()
    {
        MYGEspecificacionesCinta.Preparar(cinta);
        var grupos = MYGEspecificacionesCinta.Pagina(cinta, "Imprimir Previsualización");
        grupos.Name = "vista_grupos";
        ToolStripButton Boton(string texto, string nombre, string icono, Action accion)
        {
            var boton = new ToolStripButton(texto) { Name = nombre, Tag = icono, AutoSize = false, Width = 60, Height = 74,
                ToolTipText = texto.Replace('\n', ' '), AccessibleName = texto.Replace('\n', ' ') };
            MYGEspecificacionesCinta.Icono(boton, icono, MYGVistaPreliminarCintaIconos.Dibujar, 32, true);
            boton.Click += (_, _) => Intentar(accion);
            return boton;
        }
        ToolStripDropDownButton Menu(string texto, string nombre, string icono)
        {
            var boton = new ToolStripDropDownButton(texto) { Name = nombre, Tag = icono, AutoSize = false, Width = 60, Height = 74,
                ToolTipText = texto.Replace('\n', ' '), AccessibleName = texto.Replace('\n', ' ') };
            MYGEspecificacionesCinta.Icono(boton, icono, MYGVistaPreliminarCintaIconos.Dibujar, 32, true);
            return boton;
        }
        void Opcion(ToolStripDropDownButton menu, string texto, Action accion, string nombre = null, string icono = "pagina")
        {
            var item = new ToolStripMenuItem(texto) { Name = nombre ?? "" };
            MYGEspecificacionesCinta.Icono(item, icono, MYGVistaPreliminarCintaIconos.Dibujar, 24, true);
            item.TextImageRelation = TextImageRelation.ImageBeforeText;
            item.Click += (_, _) => Intentar(accion); menu.DropDownItems.Add(item);
        }
        void Grupo(string titulo, params ToolStripItem[] acciones)
        {
            var grupo = MYGVistaPreliminarCintaDiseno.Grupo(grupos, titulo, acciones.Sum(i => i.Width + 2) + 10);
            grupo.Name = "vista_grupo_" + titulo;
            var fila = MYGVistaPreliminarCintaDiseno.Fila(grupo, 4, acciones);
            fila.Name = "vista_barra_" + titulo;
        }

        Grupo("Volver", Boton("Volver", "vista_volver", "volver", Close));
        var imprimirBarra = Boton("Imprimir", "vista_imprimir_barra", "imprimir", Imprimir);
        var impresionRapida = Boton("Impresión\nrápida", "vista_impresion_rapida", "impresion_rapida", Imprimir);
        accionesSalida.Add(imprimirBarra); accionesSalida.Add(impresionRapida);
        Grupo("Imprimir", imprimirBarra, impresionRapida);
        var menuEscala = Menu("Escala", "vista_escala_barra", "escala");
        var panelEscala = new MYGEscalaImpresionControl();
        var entradaEscala = new ToolStripControlHost(panelEscala) { Name = "vista_escala_editor", AutoSize = false,
            Size = panelEscala.Size, Padding = Padding.Empty, Margin = Padding.Empty };
        menuEscala.DropDownItems.Add(entradaEscala);
        menuEscala.DropDownOpening += (_, _) => panelEscala.Cargar(configuracion.Escala, configuracion.PaginasDeAncho);
        panelEscala.Aceptar += (_, _) =>
        {
            menuEscala.HideDropDown();
            AplicarEscala(panelEscala.Escala, panelEscala.PaginasDeAncho);
        };
        panelEscala.Cancelar += (_, _) => menuEscala.HideDropDown();
        menuEscala.DropDownItems.Add(new ToolStripSeparator());
        Opcion(menuEscala, "Restablecer configuración", () =>
        {
            configuracion.Restaurar(); configuracion.Fuente("Arial Narrow");
            paginaInvalida = false; colorPagina = Color.White; filigrana = "";
            CargarAjustes(); ProgramarActualizacion();
        }, "vista_restaurar", "deshacer");
        var menuMargenes = Menu("Márgenes", "vista_margenes_barra", "margenes");
        void Margenes(string nombre, string id, decimal lateral, decimal vertical)
        {
            var item = new ToolStripMenuItem(nombre + "\nSuperior: " + vertical + " mm     Inferior: " + vertical +
                " mm\nIzquierdo: " + lateral + " mm    Derecho: " + lateral + " mm")
            {
                Name = id, AutoSize = false, Width = 380, Height = 82, Padding = new Padding(8),
                Image = IconoMargenes(lateral, vertical), ImageScaling = ToolStripItemImageScaling.None,
                TextImageRelation = TextImageRelation.ImageBeforeText, TextAlign = ContentAlignment.MiddleLeft,
                AccessibleName = nombre + ", superior e inferior " + vertical + " milímetros, izquierdo y derecho " + lateral + " milímetros"
            };
            item.Click += (_, _) => AplicarAjustesPagina(new MYGAjustesPaginaReporte(tamano.Text, orientacion.Text, lateral, lateral, vertical, vertical));
            menuMargenes.DropDownItems.Add(item);
        }
        Margenes("Normal", "vista_margenes_normal", 25, 25);
        Margenes("Estrecho", "vista_margenes_estrecho", 13, 13);
        Margenes("Moderado", "vista_margenes_moderado", 19, 25);
        Margenes("Ancho", "vista_margenes_ancho", 51, 25);
        menuMargenes.DropDownItems.Add(new ToolStripSeparator());
        Opcion(menuMargenes, "Márgenes personalizados…", ConfigurarPagina, "vista_margenes_personalizados", "margenes");
        var menuOrientacion = Menu("Orientación", "vista_orientacion_barra", "orientacion");
        foreach (var opcion in new[] { (Valor: "Vertical", Texto: "Retrato", Icono: "retrato"),
            (Valor: "Horizontal", Texto: "Apaisado", Icono: "apaisado") })
            Opcion(menuOrientacion, opcion.Texto, () => orientacion.SelectedItem = opcion.Valor,
                "vista_orientacion_" + opcion.Icono, opcion.Icono);
        void MarcarOrientacion()
        {
            ((ToolStripMenuItem)menuOrientacion.DropDownItems[0]).Checked = orientacion.Text == "Vertical";
            ((ToolStripMenuItem)menuOrientacion.DropDownItems[1]).Checked = orientacion.Text == "Horizontal";
        }
        menuOrientacion.DropDownOpening += (_, _) => MarcarOrientacion();
        orientacion.SelectedIndexChanged += (_, _) => MarcarOrientacion();
        var menuTamano = Menu("Tamaño", "vista_tamano_barra", "tamano");
        foreach (string valor in MYGPapelReporte.Nombres)
            Opcion(menuTamano, valor, () => tamano.SelectedItem = valor, icono: "tamano");
        Grupo("Configurar página", menuEscala, menuMargenes, menuOrientacion, menuTamano,
            Boton("Buscar", "vista_buscar", "buscar", Buscar));
        primera = Boton("Primera\npágina", "vista_primera", "primera", () => MostrarPagina(0));
        anterior = Boton("Página\nanterior", "vista_anterior", "anterior", () => MostrarPagina(Math.Max(0, pagina - (superficie.VariasPaginas ? 2 : 1))));
        siguiente = Boton("Página\nsiguiente", "vista_siguiente", "siguiente", () => MostrarPagina(Math.Min(CantidadPaginas - 1, pagina + (superficie.VariasPaginas ? 2 : 1))));
        ultima = Boton("Última\npágina", "vista_ultima", "ultima", () => MostrarPagina(CantidadPaginas - 1));
        Grupo("Navegación", primera, anterior, siguiente, ultima);

        var grupoZoom = MYGVistaPreliminarCintaDiseno.Grupo(grupos, "Ampliación", 286);
        grupoZoom.Name = "vista_grupo_Ampliación";
        puntero = Boton("Seleccionar", "vista_puntero", "puntero", () => ModoMano(false));
        mano = Boton("Mano", "vista_mano", "mano", () => ModoMano(true));
        foreach (var modo in new[] { puntero, mano })
        {
            MYGEspecificacionesCinta.Icono(modo, modo == mano ? "mano" : "puntero", MYGVistaPreliminarCintaIconos.Dibujar, 24, false);
            modo.Width = 30; modo.Height = 32;
        }
        puntero.Checked = true;
        MYGVistaPreliminarCintaDiseno.Fila(grupoZoom, 4, puntero);
        MYGVistaPreliminarCintaDiseno.Fila(grupoZoom, 42, mano);
        varias = Boton("Varias\npáginas", "vista_varias_paginas", "varias_paginas", () =>
        {
            superficie.VariasPaginas = !superficie.VariasPaginas; varias.Checked = superficie.VariasPaginas;
            AjustarPagina(); ActualizarEstado();
        });
        var menuZoom = Menu("Ampliación", "vista_zoom_barra", "ampliacion");
        foreach (int valor in new[] { 10, 25, 50, 75, 100, 125, 150, 200, 300, 400, 500 })
            Opcion(menuZoom, valor + "%", () => CambiarZoom(valor / 100f), icono: "ampliacion");
        Opcion(menuZoom, "Página completa", AjustarPagina, "vista_ajustar", "pagina_completa");
        MYGVistaPreliminarCintaDiseno.Fila(grupoZoom, 40, 4, varias,
            Boton("Alejar", "vista_alejar", "zoom_menos", () => CambiarZoom(ampliacion / 1.12f)), menuZoom,
            Boton("Acercar", "vista_acercar", "zoom_mas", () => CambiarZoom(ampliacion * 1.12f)));
        Grupo("Fondo de página", Boton("Color de\npágina", "vista_color_pagina", "color_pagina", ColorPagina),
            Boton("Filigrana", "vista_filigrana", "filigrana", Filigrana));
        var exportar = Menu("Exportar\ncomo", "vista_pdf_barra", "pdf");
        MYGVistaPreliminarExportacionMenu.Preparar(exportar, false, formato => Intentar(() => ExportarFormato(formato)));
        var correo = Menu("E-Mail\nComo", "vista_email", "email");
        correo.ToolTipText = "Elegir formato y abrir un correo con el informe adjunto.";
        MYGVistaPreliminarExportacionMenu.Preparar(correo, true, formato => Intentar(() => CorreoFormato(formato)));
        var guardar = Boton("Guardar", "vista_guardar", "guardar", ExportarPdf); guardar.ToolTipText = "Guardar informe PDF";
        var abrir = Boton("Abrir", "vista_abrir", "abrir", AbrirInforme); abrir.ToolTipText = "Abrir un informe guardado";
        Grupo("Exportar", exportar, correo, guardar, abrir);
        accionesSalida.Add(exportar); accionesSalida.Add(correo); accionesSalida.Add(guardar);
    }

    internal void AplicarEscala(float valor, int paginasDeAncho)
    {
        Cambiar(() =>
        {
            configuracion.Escala = valor;
            configuracion.PaginasDeAncho = paginasDeAncho;
            CargarAjustes();
        });
    }
    internal void AplicarAjustesPagina(MYGAjustesPaginaReporte ajustes)
    {
        paginaInvalida = true;
        Cambiar(() =>
        {
            configuracion.ConfigurarPagina(ajustes.Papel, ajustes.Orientacion,
                ajustes.IzquierdaMm / 25.4m, ajustes.DerechaMm / 25.4m, ajustes.SuperiorMm / 25.4m, ajustes.InferiorMm / 25.4m);
            paginaInvalida = false;
            CargarAjustes();
        });
    }
    private void ConfigurarPagina()
    {
        // La ventana guarda su propuesta localmente hasta que se pulsa Aceptar.
        using var dialogo = new MYGConfigurarPaginaReporteDialog(MYGAjustesPaginaReporte.Desde(configuracion.Reportes[0].Hoja));
        if (dialogo.ShowDialog(this) == DialogResult.OK) AplicarAjustesPagina(dialogo.Ajustes);
    }
    private static Bitmap IconoMargenes(decimal lateral, decimal vertical)
    {
        var imagen = new Bitmap(48, 60);
        using var dibujo = Graphics.FromImage(imagen);
        dibujo.Clear(Color.Transparent);
        using var linea = new Pen(Color.FromArgb(74, 117, 165), 2.5f);
        dibujo.FillRectangle(Brushes.White, 3, 3, 41, 53);
        dibujo.DrawRectangle(linea, 3, 3, 41, 53);
        float x = 3 + (float)lateral / 210 * 41, y = 3 + (float)vertical / 297 * 53;
        dibujo.DrawLine(linea, x, 3, x, 56); dibujo.DrawLine(linea, 47 - x, 3, 47 - x, 56);
        dibujo.DrawLine(linea, 3, y, 44, y); dibujo.DrawLine(linea, 3, 59 - y, 44, 59 - y);
        return imagen;
    }
    private void ModoMano(bool activo)
    {
        superficie.Arrastrar = activo; mano.Checked = activo; puntero.Checked = !activo;
    }
    private void ColorPagina()
    {
        using var dialogo = new ColorDialog { Color = colorPagina, FullOpen = true };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        colorPagina = dialogo.Color; ActualizarDecoracion();
    }
    private void Filigrana()
    {
        string texto = PedirTexto("Filigrana", "Texto de fondo (vacío para quitarlo):", filigrana);
        if (texto == null) return;
        filigrana = texto; ActualizarDecoracion();
    }
    private void ActualizarDecoracion()
    {
        if (vista == null) return;
        vista.ColorPagina = colorPagina; vista.Filigrana = filigrana;
        superficie.InvalidarPaginas();
        ActualizarEstado();
    }
    private void CambiarApariencia(Action cambio)
    {
        if (cargando) return;
        try
        {
            cambio();
            AplicarAparienciaActual();
            ActualizarEstado();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException) { MostrarFalloActualizacion(ex); }
    }
    private void AplicarAparienciaActual()
    {
        if (vista == null) return;
        vista.AplicarApariencia(lineas.Checked, coloresTitulos.Checked, ColorTituloPresupuesto, configuracion.ColorOriginalTitulo);
        vista.ColorPagina = colorPagina; vista.Filigrana = filigrana;
        superficie.InvalidarPaginas();
    }
    private void Buscar()
    {
        if (vista == null) return;
        string texto = PedirTexto("Buscar en el informe", "Texto o valor:", "");
        if (string.IsNullOrWhiteSpace(texto)) return;
        int encontrado = vista.BuscarPagina(texto, pagina + 1);
        if (encontrado >= 0) MostrarPagina(encontrado);
        else MessageBox.Show(this, "No se encontró el texto en el informe.", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    private string PedirTexto(string titulo, string etiqueta, string texto)
    {
        using var dialogo = new Form { Text = titulo, StartPosition = FormStartPosition.CenterParent,
            ClientSize = new Size(430, 140), FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
        var entrada = new TextBox { Text = texto, MaxLength = 100, Location = new Point(16, 45), Width = 396 };
        var aceptar = new Button { Text = "Aceptar", DialogResult = DialogResult.OK, Location = new Point(236, 92), Width = 84 };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Location = new Point(328, 92), Width = 84 };
        dialogo.Controls.Add(new Label { Text = etiqueta, AutoSize = true, Location = new Point(16, 16) });
        dialogo.Controls.Add(entrada); dialogo.Controls.Add(aceptar); dialogo.Controls.Add(cancelar);
        dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
        return dialogo.ShowDialog(this) == DialogResult.OK ? entrada.Text.Trim() : null;
    }
    private void CorreoFormato(MYGVistaPreliminarExportacionMenu.Formato formato)
    {
        string archivo = ExportarFormato(formato);
        if (archivo == null) return;
        MYGReportesExportacionWindows.PrepararCorreo(this, "Informe · " + nombreDocumento, new[] { archivo });
    }
    private string ExportarFormato(MYGVistaPreliminarExportacionMenu.Formato formato)
    {
        if (!ExigirVistaActualizada()) return null;
        if (formato.Valor == MYGFormatoVistaReporte.Pdf)
        {
            // Preparar el driver o cancelar no debe reutilizar un PDF anterior en el correo.
            ultimoPdf = null; ExportarPdf();
            return ultimoPdf;
        }
        if (crearMetradosExcel != null && formato.Valor is MYGFormatoVistaReporte.Xls or MYGFormatoVistaReporte.Xlsx)
        {
            using var libro = new MYGVistaMetradosExcelForm(nombreDocumento, crearMetradosExcel(),
                preferirXls: formato.Valor == MYGFormatoVistaReporte.Xls);
            libro.ShowDialog(this);
            string guardado = libro.ArchivoGuardado;
            if (guardado != null) estado.Text = "Informe guardado en " + guardado;
            return guardado;
        }
        using var dialogo = new SaveFileDialog
        {
            Title = "Exportar informe · " + formato.Titulo, Filter = formato.Filtro,
            DefaultExt = formato.Extension, AddExtension = true,
            FileName = "Informe." + formato.Extension,
            OverwritePrompt = formato.Valor != MYGFormatoVistaReporte.Imagen
        };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return null;
        string archivo = dialogo.FileName;
        if (formato.Valor == MYGFormatoVistaReporte.Imagen)
        {
            string extension = new[] { ".png", ".bmp", ".gif", ".jpg", ".tiff", ".emf", ".wmf" }[dialogo.FilterIndex - 1];
            archivo = Path.ChangeExtension(archivo, extension);
            validarDestino?.Invoke(archivo, extension.TrimStart('.'));
            int primera = rango.Checked ? (int)desde.Value : 1;
            int ultima = rango.Checked ? (int)hasta.Value : CantidadPaginas;
            string salida = MYGReportesImagenExportacion.RutaSalida(archivo, primera, ultima);
            if (!string.Equals(archivo, salida, StringComparison.OrdinalIgnoreCase))
            {
                string aviso = "Las " + (ultima - primera + 1) + " páginas se guardarán como imágenes numeradas en este archivo ZIP:\n\n" + salida;
                if (File.Exists(salida)) aviso += "\n\nEl archivo ya existe. Se reemplazará al continuar.";
                if (MessageBox.Show(this, aviso, "Exportar imágenes", MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Information) != DialogResult.OK) return null;
            }
            else if (File.Exists(salida) && MessageBox.Show(this, "El archivo ya existe:\n\n" + salida + "\n\n¿Desea reemplazarlo?",
                "Exportar imágenes", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return null;
            archivo = MYGReportesImagenExportacion.Guardar(archivo, vista, primera, ultima).Single();
        }
        else if (formato.Valor == MYGFormatoVistaReporte.Xls)
        {
            validarDestino?.Invoke(archivo, formato.Extension);
            MYGReportesExportacionWindows.GuardarXls(archivo, configuracion.Reportes);
        }
        else
        {
            validarDestino?.Invoke(archivo, formato.Extension);
            var salida = formato.Valor switch
            {
                MYGFormatoVistaReporte.Html => MYGFormatoExportacionReporte.Html,
                MYGFormatoVistaReporte.Mht => MYGFormatoExportacionReporte.Mht,
                MYGFormatoVistaReporte.Rtf => MYGFormatoExportacionReporte.Rtf,
                MYGFormatoVistaReporte.Xlsx => MYGFormatoExportacionReporte.Xlsx,
                MYGFormatoVistaReporte.Csv => MYGFormatoExportacionReporte.Csv,
                MYGFormatoVistaReporte.Texto => MYGFormatoExportacionReporte.Texto,
                _ => throw new ArgumentOutOfRangeException(nameof(formato))
            };
            MYGReportesExportacion.Guardar(archivo, salida, configuracion.Reportes);
        }
        estado.Text = "Informe guardado en " + archivo;
        return archivo;
    }
    internal void ExportarComo(MYGFormatoVistaReporte formato)
        => Intentar(() => ExportarFormato(MYGVistaPreliminarExportacionMenu.Formatos.Single(f => f.Valor == formato)));
    private void AbrirInforme()
    {
        using var dialogo = new OpenFileDialog { Title = "Abrir informe guardado",
            Filter = "Informes e imágenes|*.pdf;*.html;*.mht;*.rtf;*.xls;*.xlsx;*.csv;*.txt;*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.emf;*.wmf;*.zip|Todos los archivos|*.*",
            CheckFileExists = true };
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            Process.Start(new ProcessStartInfo(dialogo.FileName) { UseShellExecute = true });
    }

    private static ComboBox Lista(string nombre) => new() { Name = nombre, DropDownStyle = ComboBoxStyle.DropDownList };
    private static string ColorTituloPresupuesto(int nivel) =>
        (MYG2027_TemaComercial.ColorTituloImpresion(nivel).ToArgb() & 0xFFFFFF).ToString("X6", CultureInfo.InvariantCulture);
    private void DibujarOrientacion(object sender, DrawItemEventArgs e)
    {
        e.DrawBackground();
        if (e.Index >= 0)
        {
            bool horizontal = (string)orientacion.Items[e.Index] == "Horizontal";
            int lado = Math.Max(16, (int)Math.Round(20 * DeviceDpi / 96f));
            using var icono = MYGVistaPreliminarCintaIconos.Dibujar(horizontal ? "apaisado" : "retrato", lado,
                (e.State & DrawItemState.Selected) != 0);
            e.Graphics.DrawImage(icono, e.Bounds.Left + 3, e.Bounds.Top + (e.Bounds.Height - lado) / 2, lado, lado);
            TextRenderer.DrawText(e.Graphics, horizontal ? "Apaisado" : "Retrato", e.Font,
                new Rectangle(e.Bounds.Left + lado + 8, e.Bounds.Top, Math.Max(0, e.Bounds.Width - lado - 8), e.Bounds.Height),
                e.ForeColor, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
        }
        e.DrawFocusRectangle();
    }
    private static NumericUpDown Numero(string nombre, decimal min, decimal max, decimal valor) => new() { Name = nombre, Minimum = min, Maximum = max, Value = valor };
    private static NumericUpDown Margen(string nombre) => new() { Name = nombre, DecimalPlaces = 2, Increment = .1m, Minimum = 0, Maximum = 7.62m };

    private void CargarAjustes()
    {
        cargando = true;
        try
        {
            var h = configuracion.Reportes[0].Hoja;
            orientacion.SelectedItem = h.OrientacionPagina; tamano.SelectedItem = h.TamanoPapel;
            izquierda.Value = Math.Clamp(h.MargenIzquierdo * 2.54m, izquierda.Minimum, izquierda.Maximum);
            derecha.Value = Math.Clamp(h.MargenDerecho * 2.54m, derecha.Minimum, derecha.Maximum);
            superior.Value = Math.Clamp(h.MargenSuperior * 2.54m, superior.Minimum, superior.Maximum);
            inferior.Value = Math.Clamp(h.MargenInferior * 2.54m, inferior.Minimum, inferior.Maximum);
            string fuente = h.Celdas.Values.FirstOrDefault()?.Fuente ?? MYGCeldaHoja.FuentePredeterminada;
            if (!fuentes.Items.Contains(fuente)) fuentes.Items.Add(fuente);
            fuentes.SelectedItem = fuente; escala.Value = Math.Clamp((decimal)configuracion.Escala * 100, escala.Minimum, escala.Maximum);
            escala.Enabled = configuracion.PaginasDeAncho == 0;
            escala.AccessibleDescription = configuracion.PaginasDeAncho > 0
                ? "Ajustar a " + configuracion.PaginasDeAncho + " página(s) de ancho desde Escala en la cinta." : "Escala de impresión en porcentaje.";
            titulos.Checked = h.RepetirTitulos; lineas.Checked = h.ImprimirLineasDivision; encabezados.Checked = h.ImprimirEncabezados;
            coloresTitulos.Enabled = configuracion.Reportes.Any(r => r.NivelesTitulos.Count > 0);
            coloresTitulos.Checked = configuracion.TitulosConColor;
        }
        finally { cargando = false; }
    }
    private void CargarImpresoras()
    {
        var disponibles = LeerImpresoras();
        AplicarImpresoras(disponibles.Nombres, disponibles.Predeterminada);
    }
    private static (string[] Nombres, string Predeterminada) LeerImpresoras()
    {
        var nombres = PrinterSettings.InstalledPrinters.Cast<string>().ToArray();
        var predeterminada = new PrinterSettings();
        return (nombres, predeterminada.IsValid ? predeterminada.PrinterName : null);
    }
    private void AplicarImpresoras(string[] nombres, string predeterminada)
    {
        cargando = true;
        try
        {
            impresoras.Items.Clear(); impresoras.Items.Add("Vista sin impresora");
            impresoras.Items.AddRange(nombres.Cast<object>().ToArray());
            impresoras.SelectedItem = predeterminada != null && impresoras.Items.Contains(predeterminada)
                ? predeterminada : "Vista sin impresora";
        }
        finally { cargando = false; }
    }
    private PrinterSettings ImpresoraSeleccionada() => impresoras.SelectedIndex > 0
        ? new PrinterSettings { PrinterName = impresoras.Text } : null;
    private void CambiarPagina()
    {
        if (cargando) return;
        paginaInvalida = true;
        Cambiar(() =>
        {
            configuracion.ConfigurarPagina(tamano.Text, orientacion.Text,
                izquierda.Value / 2.54m, derecha.Value / 2.54m, superior.Value / 2.54m, inferior.Value / 2.54m);
            paginaInvalida = false;
        });
    }
    private void Cambiar(Action cambio)
    {
        if (cargando) return;
        try { cambio(); ProgramarActualizacion(); }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            actualizacion.Invalidar();
            MostrarFalloActualizacion(ex);
        }
    }
    private void ProgramarActualizacion()
    {
        if (cargando || IsDisposed || Disposing) return;
        // También admite ventanas creadas pero todavía ocultas: WinForms
        // instala su contexto al crear el handle, antes del primer await.
        if (!IsHandleCreated) _ = Handle;
        errorActualizacion = null;
        actualizacion.Solicitar(() => CrearSolicitudVista(copiarActuales: false));
        ActualizarSalidas();
        ActualizarEstado();
    }
    private void MostrarFalloActualizacion(Exception error)
    {
        if (IsDisposed || Disposing) return;
        errorActualizacion = error;
        ActualizarSalidas();
        ActualizarEstado();
    }
    private void ActualizarSalidas()
    {
        bool lista = VistaActualizada;
        bool hayImpresora = impresoras.SelectedIndex > 0;
        imprimir.Enabled = lista && hayImpresora;
        pdf.Enabled = lista;
        foreach (var accion in accionesSalida)
            accion.Enabled = lista && (accion.Name is not ("vista_imprimir_barra" or "vista_impresion_rapida") || hayImpresora);
    }
    private bool ExigirVistaActualizada()
    {
        if (VistaActualizada) return true;
        if (errorActualizacion != null) estado.Text = errorActualizacion.Message;
        else estado.Text = paginaInvalida ? "Corrija el papel y los márgenes antes de exportar." : "La vista se está actualizando. Espere a que termine para imprimir o exportar.";
        return false;
    }
    internal void ActualizarVista()
    {
        // Entrada explícita para comprobaciones y llamadas existentes. Los
        // eventos del panel usan la cola diferida y nunca abren un diálogo.
        actualizacion.Invalidar();
        errorActualizacion = null;
        try
        {
            var preparar = CrearSolicitudVista();
            AplicarVista(preparar(_ => { }), conservarDesplazamiento: true);
        }
        catch { InvalidarVista(); throw; }
    }
    private Func<Action<string>, MYGReportesImpresion.Vista> CrearSolicitudVista(bool copiarActuales = true)
    {
        if (paginaInvalida) throw new InvalidOperationException("Corrija el papel, la orientación o los márgenes antes de continuar.");
        var impresora = ImpresoraSeleccionada();
        if (!copiarActuales)
        {
            var solicitud = configuracion.CapturarSolicitud();
            return informar => MYGReportesImpresion.PrepararVista(solicitud.CrearReportes(), solicitud.Escala,
                impresora, solicitud.PaginasDeAncho, informar);
        }
        var reportes = configuracion.CopiarReportesActuales();
        float escalaActual = configuracion.Escala;
        int paginasAncho = configuracion.PaginasDeAncho;
        return informar => MYGReportesImpresion.PrepararVista(reportes, escalaActual, impresora, paginasAncho, informar);
    }
    private void AplicarVista(MYGReportesImpresion.Vista nueva, bool conservarDesplazamiento = false)
    {
        if (IsDisposed || Disposing) return;
        Point desplazamiento = superficie.AutoScrollPosition;
        int paginaAnterior = pagina;
        float? altoAnterior = null;
        if (conservarDesplazamiento)
        {
            var indices = superficie.IndicesPaginasVisibles;
            var hojas = superficie.RectangulosPapel;
            for (int i = 0; i < indices.Count; i++)
                if (indices[i] == paginaAnterior) { altoAnterior = hojas[i].Top; break; }
        }
        nueva.AplicarApariencia(lineas.Checked, coloresTitulos.Checked, ColorTituloPresupuesto, configuracion.ColorOriginalTitulo);
        nueva.ColorPagina = colorPagina; nueva.Filigrana = filigrana;
        vista = nueva;
        errorActualizacion = null;
        PreparacionesVista++;
        hasta.Maximum = desde.Maximum = vista.CantidadPaginas;
        if (!rango.Checked) hasta.Value = vista.CantidadPaginas;
        MostrarPagina(Math.Min(pagina, vista.CantidadPaginas - 1));
        if (conservarDesplazamiento && altoAnterior.HasValue && paginaAnterior < vista.CantidadPaginas)
        {
            var indices = superficie.IndicesPaginasVisibles;
            var hojas = superficie.RectangulosPapel;
            for (int i = 0; i < indices.Count; i++)
                if (indices[i] == paginaAnterior)
                {
                    int y = Math.Max(0, -superficie.AutoScrollPosition.Y + (int)Math.Round(hojas[i].Top - altoAnterior.Value));
                    superficie.AutoScrollPosition = new Point(Math.Max(0, -desplazamiento.X), y);
                    superficie.Invalidate();
                    break;
                }
        }
        ActualizarPosicionVista();
        ActualizarSalidas();
    }
    private void InvalidarVista()
    {
        actualizacion.Invalidar();
        vista = null; superficie.Limpiar();
        imprimir.Enabled = pdf.Enabled = false;
        foreach (var accion in accionesSalida) accion.Enabled = false;
        primera.Enabled = anterior.Enabled = siguiente.Enabled = ultima.Enabled = false;
    }
    private void MostrarPagina(int indice)
    {
        if (vista == null || indice < 0 || indice >= vista.CantidadPaginas) return;
        pagina = indice;
        try { superficie.Cargar(vista, indice); }
        catch (Exception error)
        {
            // Invalidar cancela la revisión en curso. Conservar el fallo antes
            // evita que la cola lo confunda con un resultado antiguo descartado.
            errorActualizacion = error;
            InvalidarVista();
            MostrarFalloActualizacion(error);
            throw;
        }
        ActualizarPosicionVista();
    }
    private void ActualizarPosicionVista()
    {
        if (vista == null || superficie.PaginaActual < 0) return;
        pagina = superficie.PaginaActual;
        ActualizarEstado();
        int maximo = Math.Max(0, superficie.AutoScrollMinSize.Height - superficie.ClientSize.Height);
        bool alFinal = -superficie.AutoScrollPosition.Y >= maximo - 1;
        primera.Enabled = -superficie.AutoScrollPosition.Y > 0;
        anterior.Enabled = pagina > 0;
        siguiente.Enabled = !alFinal && pagina + (superficie.VariasPaginas ? 2 : 1) < CantidadPaginas;
        ultima.Enabled = !alFinal && CantidadPaginas > 1;
    }
    private void CambiarZoom(float valor) => Intentar(() => superficie.CambiarZoom(valor));
    private void AjustarPagina() => superficie.AjustarPagina();
    private void LeerZoom()
    {
        if (!float.TryParse(zoom.Text.Trim().TrimEnd('%'), NumberStyles.Float, CultureInfo.CurrentCulture, out float valor) || !float.IsFinite(valor))
            throw new InvalidOperationException("Indique una ampliación entre 10 % y 500 %.");
        CambiarZoom(valor / 100);
    }
    private void ActualizarEstado()
    {
        if (varias != null) varias.Checked = superficie.VariasPaginas;
        var visibles = superficie.IndicesPaginasVisibles;
        string paginas = visibles.Count > 1
            ? "Páginas " + (visibles.Min() + 1) + "–" + (visibles.Max() + 1)
            : "Página " + (visibles.Count == 1 ? visibles[0] + 1 : pagina + 1);
        string textoEstado = paginas + " de " + CantidadPaginas + "  ·  Ampliación " + (ampliacion * 100).ToString("0") + "%  ·  Ctrl + rueda para ampliar";
        if (errorActualizacion != null) textoEstado = errorActualizacion.Message;
        else if (paginaInvalida) textoEstado = "Corrija el papel, la orientación o los márgenes de la vista.";
        else if (ActualizacionPendiente) textoEstado = "Actualizando vista…  ·  " + textoEstado;
        if (estado.Text != textoEstado) estado.Text = textoEstado;
        bool cargandoAntes = cargando;
        cargando = true;
        try
        {
            int porcentaje = Math.Clamp((int)Math.Round(ampliacion * 100), deslizadorZoom.Minimum, deslizadorZoom.Maximum);
            if (deslizadorZoom.Value != porcentaje) deslizadorZoom.Value = porcentaje;
            string textoZoom = (ampliacion * 100).ToString("0") + "%";
            if (zoom.Text != textoZoom) zoom.Text = textoZoom;
        }
        finally { cargando = cargandoAntes; }
    }
    private void Imprimir()
    {
        if (!ExigirVistaActualizada()) return;
        var ajustes = ImpresoraSeleccionada();
        if (ajustes?.IsValid != true) throw new InvalidOperationException("Seleccione una impresora disponible.");
        ajustes.Copies = (short)copias.Value;
        ajustes.MinimumPage = 1; ajustes.MaximumPage = CantidadPaginas;
        ajustes.FromPage = (int)desde.Value; ajustes.ToPage = (int)hasta.Value;
        ajustes.PrintRange = rango.Checked ? PrintRange.SomePages : PrintRange.AllPages;
        // Usar el plan visible conserva exactamente los cortes y páginas revisados.
        // La impresora, el rango y las copias se eligen en el panel de esta vista.
        using var documento = vista.Documento(nombreDocumento, ajustes);
        documento.Print();
    }
    private void ExportarPdf()
    {
        if (!ExigirVistaActualizada()) return;
        const string nombre = "Microsoft Print to PDF";
        if (!PrinterSettings.InstalledPrinters.Cast<string>().Any(n => string.Equals(n, nombre, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Active Microsoft Print to PDF en las características de Windows para exportar el informe como PDF.");
        if (!string.Equals(impresoras.Text, nombre, StringComparison.OrdinalIgnoreCase))
        {
            // El cambio de driver puede cambiar los cortes. Revisarlos precede al guardado.
            cargando = true;
            try { impresoras.SelectedItem = nombre; }
            finally { cargando = false; }
            ProgramarActualizacion();
            estado.Text = "Preparando la vista para PDF. Revise las páginas actualizadas antes de exportar.";
            return;
        }
        var ajustes = new PrinterSettings { PrinterName = nombre };
        using var dialogo = new SaveFileDialog { Title = "Exportar informe a PDF", Filter = "Documento PDF (*.pdf)|*.pdf",
            DefaultExt = "pdf", AddExtension = true, FileName = "Informe.pdf", OverwritePrompt = true };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        validarDestino?.Invoke(dialogo.FileName, "pdf");
        ajustes.PrintToFile = true; ajustes.PrintFileName = dialogo.FileName;
        ajustes.PrintRange = rango.Checked ? PrintRange.SomePages : PrintRange.AllPages;
        ajustes.FromPage = (int)desde.Value; ajustes.ToPage = (int)hasta.Value;
        using var documento = vista.Documento(nombreDocumento, ajustes);
        documento.PrintController = new StandardPrintController();
        documento.Print();
        ultimoPdf = dialogo.FileName;
    }
    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            estado.Text = ex.Message;
            MessageBox.Show(this, ex.Message, "Vista preliminar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) { actualizacion.Dispose(); superficie.Limpiar(); }
        base.Dispose(disposing);
    }
}
