using System;
using System.Threading;
using System.Threading.Tasks;

namespace MYG_2027;

// Se usa desde un único contexto (la UI). Agrupa pulsaciones y sólo ejecuta
// una preparación a la vez; un resultado anterior nunca sustituye al último.
internal sealed class MYGActualizacionDiferida<TSolicitud, TResultado> : IDisposable
{
    private readonly Func<TSolicitud, Task<TResultado>> preparar;
    private readonly Action<TResultado> aplicar;
    private readonly Action<Exception> fallo;
    private readonly Action<TResultado> descartar;
    private readonly int demoraMs;
    private Func<TSolicitud> solicitud;
    private CancellationTokenSource demora;
    private Task ciclo = Task.CompletedTask;
    private bool ejecutando, dispuesto;

    internal event EventHandler EstadoChanged;
    internal bool Pendiente => !dispuesto && (ejecutando || solicitud != null);
    internal long Revision { get; private set; }

    internal MYGActualizacionDiferida(Func<TSolicitud, Task<TResultado>> preparar, Action<TResultado> aplicar,
        Action<Exception> fallo, Action<TResultado> descartar = null, int demoraMs = 200)
    {
        ArgumentNullException.ThrowIfNull(preparar);
        ArgumentNullException.ThrowIfNull(aplicar);
        ArgumentNullException.ThrowIfNull(fallo);
        if (demoraMs < 0) throw new ArgumentOutOfRangeException(nameof(demoraMs));
        this.preparar = preparar; this.aplicar = aplicar; this.fallo = fallo;
        this.descartar = descartar; this.demoraMs = demoraMs;
    }

    internal long Solicitar(Func<TSolicitud> capturar)
    {
        ObjectDisposedException.ThrowIf(dispuesto, this);
        ArgumentNullException.ThrowIfNull(capturar);
        long revision = ++Revision;
        solicitud = capturar;
        demora?.Cancel();
        Notificar();
        if (!ejecutando)
        {
            ejecutando = true;
            ciclo = ProcesarAsync();
        }
        return revision;
    }

    private async Task ProcesarAsync()
    {
        // Publicar el Task del ciclo antes de cualquier callback de aplicación.
        await Task.Yield();
        try
        {
            while (!dispuesto && solicitud != null)
            {
                long revision = Revision;
                var capturar = solicitud;
                using var pausa = new CancellationTokenSource();
                demora = pausa;
                try { await Task.Delay(demoraMs, pausa.Token); }
                catch (OperationCanceledException) when (pausa.IsCancellationRequested) { continue; }
                finally { if (ReferenceEquals(demora, pausa)) demora = null; }
                if (dispuesto || revision != Revision) continue;
                solicitud = null;
                try
                {
                    var datos = capturar();
                    var resultado = await preparar(datos);
                    if (dispuesto || revision != Revision) descartar?.Invoke(resultado);
                    else aplicar(resultado);
                }
                catch (Exception ex) when (ex is not OutOfMemoryException)
                {
                    if (!dispuesto && revision == Revision) fallo(ex);
                }
                Notificar();
            }
        }
        finally
        {
            ejecutando = false;
            Notificar();
        }
    }

    internal void Invalidar()
    {
        if (dispuesto) return;
        Revision++;
        solicitud = null;
        demora?.Cancel();
        Notificar();
    }

    internal async Task EsperarAsync()
    {
        do
        {
            var actual = ciclo;
            await actual;
            if (ReferenceEquals(actual, ciclo) && !Pendiente) return;
        } while (!dispuesto);
    }

    private void Notificar()
    { if (!dispuesto) EstadoChanged?.Invoke(this, EventArgs.Empty); }

    public void Dispose()
    {
        if (dispuesto) return;
        dispuesto = true;
        Revision++;
        solicitud = null;
        demora?.Cancel();
    }
}
