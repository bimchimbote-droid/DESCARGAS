using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using MYG_2027;

internal static class ConfiguracionVistaReporteCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
    private static void Rechaza(Action accion, string mensaje)
    {
        try { accion(); }
        catch (ArgumentException) { return; }
        throw new Exception(mensaje);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        ConfiguracionAislada(pasa);
        ValidacionAtomica(pasa);
        ReferenciasEnInstantanea(pasa);
        TodosLosReportes(pasa);
        AjusteDeAnchura(pasa);
        ColoresTitulosAislados(pasa);
        SolicitudAisladaYPendientes(pasa);
        SolicitudConReferencias(pasa);
    }

    private static void AjusteDeAnchura(Action<string> pasa)
    {
        var vista = new MYGConfiguracionVistaReporte(new[] { new MYGHojaReporteProyecto("A", MYGHojaMetrado.Crear()) });
        vista.Escala = .75f; vista.PaginasDeAncho = 2;
        Rechaza(() => vista.PaginasDeAncho = -1, "Se aceptó un ancho negativo.");
        Rechaza(() => vista.PaginasDeAncho = 11, "Se aceptaron más de diez páginas de ancho.");
        Exige(vista.PaginasDeAncho == 2 && vista.Escala == .75f, "Un ajuste inválido cambió la configuración anterior.");
        vista.Restaurar();
        Exige(vista.PaginasDeAncho == 0 && vista.Escala == 1, "Restaurar no recuperó el modo porcentual.");

        float[] anchos = { 210, 120, 95, 130, 120, 70, 90, 150, 130, 80 };
        var original = anchos.ToArray();
        float anterior = 0;
        foreach (int paginas in new[] { 1, 2, 3, 10 })
        {
            var ajuste = MYGConfiguracionVistaReporte.AjustarAnchura(anchos, 500, paginas);
            Exige(ajuste.Escala > 0 && ajuste.Escala <= 1 && ajuste.Escala >= anterior && ajuste.Segmentos.Count <= paginas,
                "El ajuste de anchura no respeta el máximo de páginas o reduce la escala al permitir más páginas.");
            Exige(ajuste.Segmentos.All(s => s[0] == 0 && s.Length > 1 && s.Sum(c => anchos[c]) * ajuste.Escala <= 500.001f) &&
                ajuste.Segmentos.SelectMany(s => s.Skip(1)).SequenceEqual(Enumerable.Range(1, anchos.Length - 1)),
                "El ajuste perdió columnas, alteró su orden o excedió el ancho imprimible.");
            anterior = ajuste.Escala;
        }
        var estrecha = MYGConfiguracionVistaReporte.AjustarAnchura(new[] { 2000f }, 100, 1);
        Exige(Math.Abs(estrecha.Escala - .05f) < .0001f && estrecha.Segmentos.Single().SequenceEqual(new[] { 0 }),
            "Ajustar una página debe admitir escalas menores al porcentaje manual sin perder la columna.");
        var cabe = MYGConfiguracionVistaReporte.AjustarAnchura(new[] { 100f, 50f }, 200, 3);
        Exige(cabe.Escala == 1 && cabe.Segmentos.Count == 1 && anchos.SequenceEqual(original),
            "El ajuste agrandó una hoja que ya cabe, inventó páginas o cambió anchos originales.");
        Rechaza(() => MYGConfiguracionVistaReporte.AjustarAnchura(new[] { float.NaN }, 100, 1), "Se aceptó un ancho no finito.");
        Rechaza(() => MYGConfiguracionVistaReporte.AjustarAnchura(new[] { 100f }, 0, 1), "Se aceptó espacio vacío.");
        Rechaza(() => MYGConfiguracionVistaReporte.AjustarAnchura(new[] { 100f }, 100, 0), "Se aceptó cero páginas en el modo de ajuste.");
        pasa("Escala por anchura conserva todas las columnas, repite identificadores y respeta el máximo de páginas sin cambiar el proyecto");
    }

    private static void SolicitudAisladaYPendientes(Action<string> pasa)
    {
        var hoja = HojaConTitulos("Instantánea");
        var reporte = new MYGHojaReporteProyecto("Presupuesto", hoja, presupuestoObra: true,
            nivelesTitulos: new Dictionary<int, int> { [3] = 0, [4] = 1 });
        string original = Datos(reporte);
        var vista = new MYGConfiguracionVistaReporte(new[] { reporte });
        var referencia = vista.Reportes[0].Hoja;
        vista.Fuente("Calibri");
        vista.ConfigurarPagina("A3", "Horizontal", .2m, .3m, .4m, .5m);
        vista.Escala = .75f; vista.PaginasDeAncho = 2;
        vista.LineasDivision(true); vista.Encabezados(true); vista.RepetirTitulos(true);
        vista.ColorearTitulos(true, nivel => nivel == 0 ? "aa1133" : "445566");
        var solicitud = vista.CapturarSolicitud();
        Exige(referencia.Celdas["A3"].Fuente == "Courier New" && referencia.Celdas["A3"].ColorTexto == "123456",
            "Capturar un ajuste no debe recorrer ni materializar fuentes y colores sobre las celdas de la interfaz.");

        // Cambios posteriores, incluso Restaurar, no deben modificar el pedido
        // que un trabajador ya está preparando.
        vista.Fuente("Arial Narrow"); vista.ColorearTitulos(false);
        vista.ConfigurarPagina("A5", "Vertical", .1m, .1m, .1m, .1m);
        vista.LineasDivision(false); vista.Encabezados(false); vista.RepetirTitulos(false);
        vista.Escala = 1.5f; vista.PaginasDeAncho = 0;
        vista.Restaurar();
        var preparados = Task.Run(solicitud.CrearReportes).GetAwaiter().GetResult();
        var h = preparados[0].Hoja;
        Exige(solicitud.Escala == .75f && solicitud.PaginasDeAncho == 2 && h.TamanoPapel == "A3" &&
            h.OrientacionPagina == "Horizontal" && h.MargenIzquierdo == .2m && h.MargenDerecho == .3m &&
            h.MargenSuperior == .4m && h.MargenInferior == .5m && h.RepetirTitulos && h.ImprimirLineasDivision &&
            h.ImprimirEncabezados && h.Celdas.Values.All(c => c.Fuente == "Calibri") &&
            h.Celdas["A3"].ColorTexto == "AA1133" && h.Celdas["A4"].ColorTexto == "445566" &&
            h.Celdas["D6"].ColorTexto == hoja.Celdas["D6"].ColorTexto && new MYGHojaCalculo(h).Numero("F6") == 4m,
            "El trabajador debe conservar los ajustes, la paleta y las fórmulas capturados antes de los cambios posteriores.");
        h.Celdas["D6"].Contenido = "100";
        var segundo = solicitud.CrearReportes()[0].Hoja;
        Exige(new MYGHojaCalculo(segundo).Numero("F6") == 4m && !ReferenceEquals(h, segundo) &&
            Datos(reporte) == original && Datos(vista.Reportes[0]) == original,
            "Cada materialización debe ser independiente y conservar tanto la restauración como el informe original.");

        vista.Fuente("Georgia"); vista.ColorearTitulos(true, _ => "102030");
        var paraExportar = vista.Reportes[0].Hoja;
        Exige(paraExportar.Celdas.Values.All(c => c.Fuente == "Georgia") && paraExportar.Celdas["A3"].ColorTexto == "102030" &&
            vista.ColorOriginalTitulo(0, "A3") == "123456",
            "Pedir los reportes para exportación debe materializar los últimos estilos y conservar el color original real.");
        paraExportar.Poner("D6", "9");
        var exacta = vista.CopiarReportesActuales();
        paraExportar.Poner("D6", "7");
        Exige(exacta[0].Hoja.Celdas["D6"].Contenido == "9" && Datos(reporte) == original,
            "La ruta explícita debe copiar también las ediciones directas de las celdas sin compartirlas con el trabajador.");
        pasa("Ajustes interactivos capturan solicitudes aisladas sin materializar celdas en UI y exportan los últimos estilos al pedirlos");
    }

    private static void SolicitudConReferencias(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("OBRA CON REFERENCIAS", "ORIGEN");
        var p = doc.Presupuestos[0];
        var destino = Partida("Destino", 1); var origen = Partida("Origen", 2);
        p.Items.AddRange(new[] { destino, origen });
        MYGProyectoStorage.Renumerar(p); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        origen.Costos.Hoja.Poner("B3", "5");
        destino.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(destino.Costos.Hoja, p, origen, "B3") + "*3");
        var vista = new MYGConfiguracionVistaReporte(new[]
        {
            new MYGHojaReporteProyecto("Destino", MYGProyectoStorage.Copia(destino.Costos.Hoja)),
            new MYGHojaReporteProyecto("Origen", MYGProyectoStorage.Copia(origen.Costos.Hoja))
        });
        var pedido = vista.CapturarSolicitud();
        origen.Costos.Hoja.Poner("B3", "20");
        string documentoActual = Datos(doc);
        vista.Reportes[1].Hoja.Poner("B3", "9");
        var trabajador = Task.Run(pedido.CrearReportes).GetAwaiter().GetResult();
        Exige(new MYGHojaCalculo(trabajador[0].Hoja).Numero("B3") == 15m &&
            new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 27m &&
            new MYGHojaCalculo(destino.Costos.Hoja).Numero("B3") == 60m && Datos(doc) == documentoActual,
            "La instantánea del trabajo debe congelar las dependencias METRADO sin mezclar cambios del editor ni del origen.");
        trabajador[1].Hoja.Poner("B3", "8");
        Exige(new MYGHojaCalculo(trabajador[0].Hoja).Numero("B3") == 24m &&
            new MYGHojaCalculo(pedido.CrearReportes()[0].Hoja).Numero("B3") == 15m &&
            new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 27m && Datos(doc) == documentoActual,
            "Las referencias entre las copias del trabajador deben permanecer aisladas entre sí, del panel y de los datos persistidos.");
        pasa("Solicitudes de paginación conservan las fórmulas METRADO y sus dependencias en copias de trabajo independientes");
    }

    private static MYGHojaMetrado HojaConTitulos(string nombre)
    {
        var hoja = new MYGHojaMetrado { Nombre = nombre, Filas = 10, Columnas = 6,
            AreaImpresion = "A1:F10", CeldaTotal = "F10" };
        foreach (int fila in new[] { 3, 4, 5, 7 })
        {
            hoja.Poner("A" + fila, "Código " + fila, true);
            hoja.Poner("B" + fila, nombre + " título " + fila, true);
            hoja.Poner("F" + fila, "=F6", true);
        }
        for (int columna = 1; columna <= 6; columna++)
        {
            hoja.Poner(MYGHojaCalculo.Columna(columna) + "6", columna == 6 ? "=D6*E6" : "2");
            hoja.Poner(MYGHojaCalculo.Columna(columna) + "10", columna == 6 ? "=F6" : "Pie");
        }
        foreach (var entrada in hoja.Celdas)
        {
            entrada.Value.Fuente = "Courier New"; entrada.Value.TamanoFuente = 13;
            entrada.Value.Cursiva = true; entrada.Value.Subrayado = entrada.Key.EndsWith("3", StringComparison.Ordinal);
            entrada.Value.ColorTexto = entrada.Key.StartsWith("A", StringComparison.Ordinal) ? "123456" : "654321";
            entrada.Value.ColorFondo = entrada.Key.EndsWith("10", StringComparison.Ordinal) ? "ECEEF0" : "ABCDEF";
        }
        return hoja;
    }

    private static void ColoresTitulosAislados(Action<string> pasa)
    {
        var niveles = new Dictionary<int, int> { [3] = 0, [4] = 1, [5] = 2, [7] = 1 };
        var reportes = new[]
        {
            new MYGHojaReporteProyecto("Presupuesto A", HojaConTitulos("A"), presupuestoObra: true, nivelesTitulos: niveles),
            new MYGHojaReporteProyecto("Presupuesto B", HojaConTitulos("B"), presupuestoObra: true,
                nivelesTitulos: new Dictionary<int, int> { [3] = 0, [4] = 2 }),
            new MYGHojaReporteProyecto("Metrado sin títulos", HojaConTitulos("Metrado"))
        };
        niveles[4] = 9; niveles[99] = 8;
        Exige(reportes[0].NivelesTitulos[4] == 1 && !reportes[0].NivelesTitulos.ContainsKey(99) &&
            reportes[0].NivelesTitulos is IDictionary<int, int> mapa && mapa.IsReadOnly,
            "La metadata de títulos debe congelar el diccionario recibido y exponerlo solo para lectura.");
        var vista = new MYGConfiguracionVistaReporte(reportes);
        string iniciales = Datos(vista.Reportes);
        Exige(!vista.TitulosConColor && vista.Reportes.Select(r => Datos(r.NivelesTitulos))
                .SequenceEqual(reportes.Select(r => Datos(r.NivelesTitulos))) &&
            !ReferenceEquals(vista.Reportes[0].NivelesTitulos, reportes[0].NivelesTitulos),
            "La configuración debe comenzar sin colores de títulos y copiar la metadata de todos los reportes.");
        vista.Fuente("Arial Narrow"); vista.ConfigurarPagina("A3", "Horizontal", .3m, .4m, .5m, .6m);
        vista.Escala = .75f;
        string sinColores = Datos(vista.Reportes);
        var hojasEsperadas = vista.Reportes.Select(r => MYGProyectoStorage.Copia(r.Hoja)).ToArray();
        reportes[0].Hoja.Celdas["A3"].ColorTexto = "FEDCBA";
        reportes[0].Hoja.Celdas["D6"].Contenido = "99";
        string origenEditado = Datos(reportes);
        string ColorNivel(int nivel) => new[] { " #112233 ", "445566", "aabbcc" }[nivel];
        vista.ColorearTitulos(true, ColorNivel);
        Exige(vista.TitulosConColor, "Activar colores de títulos debe quedar registrado en la configuración de la vista.");
        for (int indice = 0; indice < vista.Reportes.Count; indice++)
        {
            var reporte = vista.Reportes[indice];
            Exige(reporte.Hoja.Celdas.Keys.SequenceEqual(hojasEsperadas[indice].Celdas.Keys),
                "Colorear títulos no debe crear ni eliminar celdas del informe.");
            foreach (var entrada in hojasEsperadas[indice].Celdas)
            {
                var esperada = JsonSerializer.Deserialize<MYGCeldaHoja>(Datos(entrada.Value));
                int fila = MYGHojaCalculo.Coordenadas(entrada.Key).Fila;
                if (reporte.NivelesTitulos.TryGetValue(fila, out int nivel))
                    esperada.ColorTexto = ColorNivel(nivel).Trim().TrimStart('#').ToUpperInvariant();
                Exige(Datos(reporte.Hoja.Celdas[entrada.Key]) == Datos(esperada),
                    "El color por nivel debe cambiar solo el texto de las filas mapeadas y conservar fórmulas, fuente, rellenos y estilos de cada celda.");
            }
        }
        string activos = Datos(vista.Reportes);
        Rechaza(() => vista.ColorearTitulos(true, nivel => nivel == 2 ? "NO-RGB" : "102030"),
            "La paleta de títulos aceptó un color que no es RGB hexadecimal.");
        Exige(vista.TitulosConColor && Datos(vista.Reportes) == activos,
            "Una paleta inválida debe conservar el estado activo y los colores anteriores de todos los presupuestos.");
        vista.ColorearTitulos(false);
        Exige(!vista.TitulosConColor && Datos(vista.Reportes) == sinColores && vista.Escala == .75f && Datos(reportes) == origenEditado,
            "Desactivar títulos debe restaurar sus colores de la instantánea sin perder fuente, página o escala ni tomar ediciones posteriores del origen.");
        Rechaza(() => vista.ColorearTitulos(true, nivel => nivel == 2 ? null : "102030"),
            "La paleta de títulos aceptó un color nulo.");
        Exige(!vista.TitulosConColor && Datos(vista.Reportes) == sinColores,
            "Rechazar una paleta después de resolver otros niveles no debe aplicar cambios parciales ni activar el control.");
        vista.ColorearTitulos(true, _ => "334455"); vista.ColorearTitulos(false);
        Exige(Datos(vista.Reportes) == sinColores,
            "Alternar repetidamente títulos debe recuperar los colores originales de cada celda, incluidos los informes sin metadata.");
        vista.ColorearTitulos(true, ColorNivel); vista.Restaurar();
        Exige(!vista.TitulosConColor && vista.Escala == 1 && Datos(vista.Reportes) == iniciales && Datos(reportes) == origenEditado,
            "Restaurar debe desactivar los colores de títulos y recuperar la instantánea completa con su jerarquía y datos originales.");
        pasa("Colores de títulos usan la jerarquía congelada de cada presupuesto, se validan sin cambios parciales y restauran colores sin alterar datos, fórmulas o estilos");
    }

    private static void ConfiguracionAislada(Action<string> pasa)
    {
        var a = MYGHojaMetrado.Crear(); var b = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        a.Poner("B3", "2"); a.Poner("C3", "4");
        a.Celdas["B3"].Cursiva = true; a.Celdas["B3"].ColorTexto = "123456";
        a.Celdas["B3"].TamanoFuente = 13m;
        a.Celdas["C3"].TipoValidacion = "Lista"; a.Celdas["C3"].ListaValores.Add("4");
        var reportes = new[] { new MYGHojaReporteProyecto("Metrado estándar", a), new MYGHojaReporteProyecto("Acero", b) };
        string antes = Datos(reportes);
        var vista = new MYGConfiguracionVistaReporte(reportes);
        vista.ConfigurarPagina("A3", "Horizontal", .3m, .4m, .6m, .7m);
        vista.Fuente("  Calibri  "); vista.Escala = 1.5f;
        Exige(vista.Reportes.All(r => r.Hoja.TamanoPapel == "A3" && r.Hoja.OrientacionPagina == "Horizontal" &&
            r.Hoja.MargenIzquierdo == .3m && r.Hoja.MargenDerecho == .4m &&
            r.Hoja.MargenSuperior == .6m && r.Hoja.MargenInferior == .7m &&
            r.Hoja.Celdas.Values.All(c => c.Fuente == "Calibri")), "La configuración debe aplicarse a todas las hojas del reporte.");
        var celda = vista.Reportes[0].Hoja.Celdas["B3"];
        Exige(celda.TamanoFuente == 13m && celda.Cursiva && celda.ColorTexto == "123456" &&
            new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("G3") == 8m &&
            vista.Reportes[0].Hoja.Celdas["G3"].Contenido == a.Celdas["G3"].Contenido,
            "Cambiar fuente y escala debe conservar estilos, tamaños, fórmulas y resultados.");
        vista.Reportes[0].Hoja.Celdas["C3"].ListaValores.Add("8");
        vista.Reportes[0].Hoja.AnchosColumnas[1] = 400;
        vista.Reportes[0].Hoja.RangosCombinados.Clear();
        Exige(Datos(reportes) == antes && vista.Reportes is IList<MYGHojaReporteProyecto> lista && lista.IsReadOnly,
            "Las celdas, listas y dimensiones de la vista previa deben estar separadas del proyecto.");
        var anterior = vista.Reportes;
        a.Poner("B3", "99");
        vista.Restaurar();
        Exige(Datos(vista.Reportes) == antes && vista.Escala == 1f && !ReferenceEquals(anterior, vista.Reportes),
            "Restaurar debe recuperar la instantánea inicial, aun si cambia el documento de origen.");
        vista.Reportes[0].Hoja.Celdas["B3"].Contenido = "123";
        vista.Restaurar();
        Exige(Datos(vista.Reportes) == antes, "Editar tras restaurar debe conservar intacta la instantánea para la siguiente restauración.");
        pasa("Vista previa configura todas las hojas sin cambiar el proyecto y restaura datos, estilos y escala iniciales");
    }

    private static void ValidacionAtomica(Action<string> pasa)
    {
        Rechaza(() => new MYGConfiguracionVistaReporte(null), "Se aceptó un conjunto de reportes nulo.");
        Rechaza(() => new MYGConfiguracionVistaReporte(Array.Empty<MYGHojaReporteProyecto>()), "Se aceptó una vista previa vacía.");
        Rechaza(() => new MYGConfiguracionVistaReporte(new MYGHojaReporteProyecto[] { null }), "Se aceptó una hoja de reporte nula.");
        var vista = new MYGConfiguracionVistaReporte(new[]
        { new MYGHojaReporteProyecto("A", MYGHojaMetrado.Crear()), new MYGHojaReporteProyecto("B", MYGHojaMetrado.Crear()) });
        vista.ConfigurarPagina("Carta", "Horizontal", .4m, .5m, .6m, .7m);
        vista.Fuente("Arial"); vista.Escala = .75f;
        string antes = Datos(vista.Reportes);
        foreach (Action fallo in new Action[]
        {
            () => vista.ConfigurarPagina("Papel inexistente", "Vertical", 0, 0, 0, 0),
            () => vista.ConfigurarPagina("A4", "Diagonal", 0, 0, 0, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", -.1m, 0, 0, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", 0, 3.01m, 0, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", 0, 0, decimal.MaxValue, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", 0, 0, 0, -1),
            () => vista.Fuente(null), () => vista.Fuente(" "), () => vista.Fuente(new string('a', 101)),
            () => vista.Fuente("Arial\n"),
            () => vista.Escala = float.NaN, () => vista.Escala = float.PositiveInfinity,
            () => vista.Escala = .249f, () => vista.Escala = 2.001f
        })
        {
            Rechaza(fallo, "La vista previa aceptó una configuración inválida.");
            Exige(Datos(vista.Reportes) == antes && vista.Escala == .75f,
                "Una configuración rechazada no debe modificar parcialmente ninguna hoja ni la escala.");
        }
        vista.Escala = .25f; vista.Escala = 2f;
        foreach (string papel in new[] { "A4", "A3", "Carta", "Oficio" })
            foreach (string orientacion in new[] { "Vertical", "Horizontal" })
                vista.ConfigurarPagina(papel, orientacion, 0, 3, 0, 3);
        Exige(vista.Reportes.All(r => r.Hoja.TamanoPapel == "Oficio" && r.Hoja.OrientacionPagina == "Horizontal"),
            "Las opciones válidas de papel y orientación deben conservarse.");
        pasa("Vista previa rechaza configuraciones inválidas sin cambios parciales y admite los límites de escala y márgenes");
    }

    private static ItemPresupuestoDelphin Partida(string descripcion, int posicion)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
            Descripcion = descripcion, Unidad = "m²", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = posicion };
    }

    private static void ReferenciasEnInstantanea(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("OBRA", "ESTRUCTURAS"); var p = doc.Presupuestos[0];
        var a = Partida("Destino", 1); var b = Partida("Origen visible", 2); p.Items.AddRange(new[] { a, b });
        var externo = new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 };
        var c = Partida("Dependencia oculta", 1); externo.Items.Add(c); doc.Presupuestos.Add(externo);
        MYGProyectoStorage.Renumerar(p); MYGProyectoStorage.Renumerar(externo);
        MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        c.Costos.Hoja.Poner("B3", "4");
        b.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(b.Costos.Hoja, externo, c, "B3") + "*3");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3") + "*2+" +
            MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, externo, c, "B3"));
        string antes = Datos(doc);
        var vista = new MYGConfiguracionVistaReporte(new[]
        { new MYGHojaReporteProyecto("Destino", MYGProyectoStorage.Copia(a.Costos.Hoja)),
            new MYGHojaReporteProyecto("Origen", MYGProyectoStorage.Copia(b.Costos.Hoja)) });
        vista.ConfigurarPagina("A4", "Vertical", .3m, .3m, .5m, .5m); vista.Fuente("Arial");
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 28m && Datos(doc) == antes,
            "Configurar la vista previa debe conservar cadenas entre reportes y dependencias de otros presupuestos.");
        c.Costos.Hoja.Poner("B3", "10");
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 28m,
            "La instantánea de la vista previa debe aislar también las dependencias que no se imprimen.");
        vista.Reportes[1].Hoja.Poner("B3", "7");
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 18m &&
            new MYGHojaCalculo(a.Costos.Hoja).Numero("B3") == 70m,
            "Las fórmulas entre reportes deben usar sus propias copias sin escribir en las hojas originales.");
        vista.Restaurar();
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 28m,
            "Restaurar debe recuperar las dependencias iniciales y no las del documento modificado.");
        pasa("Vista previa mantiene fórmulas entre hojas y congela dependencias ocultas sin alterar el documento");
    }

    private static void TodosLosReportes(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("PROYECTO", "PRESUPUESTO"); var p = doc.Presupuestos[0];
        var a = Partida("Metrado estándar", 1); var b = Partida("Metrado de acero", 2);
        a.Costos.FuenteMetrado = b.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        a.Costos.PrecioDirecto = b.Costos.PrecioDirecto = 2m;
        b.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        p.Items.AddRange(new[] { a, b }); MYGProyectoStorage.Renumerar(p); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string antes = Datos(doc);
        foreach (var tipo in Enum.GetValues<MYGTipoReporteProyecto>())
        {
            var reportes = MYGReportesProyecto.Crear(doc, p.Id, tipo);
            string originales = Datos(reportes);
            var vista = new MYGConfiguracionVistaReporte(reportes);
            vista.ConfigurarPagina("A3", "Horizontal", .25m, .25m, .5m, .5m); vista.Fuente("Arial Narrow"); vista.Escala = .5f;
            Exige(vista.Reportes.Count == reportes.Count && Datos(reportes) == originales && Datos(doc) == antes,
                "Configurar el reporte " + tipo + " debe conservar todas sus hojas y el documento original.");
            vista.Restaurar();
            Exige(Datos(vista.Reportes) == originales, "El reporte " + tipo + " no recuperó su formato inicial.");
        }
        pasa("Los siete destinos de impresión admiten configuración y restauración sin modificar datos ni reportes originales");
    }
}
