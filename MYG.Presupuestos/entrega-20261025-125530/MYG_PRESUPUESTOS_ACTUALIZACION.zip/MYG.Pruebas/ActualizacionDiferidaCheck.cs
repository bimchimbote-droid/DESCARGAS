using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MYG_2027;

internal static class ActualizacionDiferidaCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        var anterior = SynchronizationContext.Current;
        using var contexto = new ContextoPrueba();
        SynchronizationContext.SetSynchronizationContext(contexto);
        try
        {
            Task prueba = VerificarAsync();
            var tiempo = Stopwatch.StartNew();
            while (!prueba.IsCompleted)
            {
                if (tiempo.Elapsed > TimeSpan.FromSeconds(10)) throw new TimeoutException("La cola de actualización no terminó.");
                contexto.Procesar();
            }
            prueba.GetAwaiter().GetResult();
        }
        finally { SynchronizationContext.SetSynchronizationContext(anterior); }
        pasa("Panel diferido agrupa pulsaciones, prepara una sola tarea, descarta resultados antiguos y se recupera de errores");
    }

    private static async Task VerificarAsync()
    {
        int capturas = 0, preparaciones = 0;
        var aplicadas = new List<int>();
        var fallos = new List<Exception>();
        using (var cola = new MYGActualizacionDiferida<int, int>(n =>
        { preparaciones++; return Task.FromResult(n); }, aplicadas.Add, fallos.Add, demoraMs: 10))
        {
            for (int i = 1; i <= 30; i++)
            {
                int valor = i;
                cola.Solicitar(() => { capturas++; return valor; });
            }
            Exige(cola.Pendiente && capturas == 0, "Cambiar campos no debe capturar ni preparar cada estado intermedio.");
            await cola.EsperarAsync();
            Exige(!cola.Pendiente && capturas == 1 && preparaciones == 1 && aplicadas.SequenceEqual(new[] { 30 }),
                "Una ráfaga debe preparar y aplicar únicamente su último valor.");
        }

        var entrada = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        var continuar = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        int activas = 0, maximas = 0;
        aplicadas.Clear();
        var descartadas = new List<int>();
        using (var cola = new MYGActualizacionDiferida<int, int>(async n =>
        {
            activas++; maximas = Math.Max(maximas, activas);
            try
            {
                if (n == 1) { entrada.TrySetResult(true); await continuar.Task; }
                if (n == 4) throw new InvalidOperationException("fallo controlado");
                return n;
            }
            finally { activas--; }
        }, aplicadas.Add, fallos.Add, descartadas.Add, demoraMs: 1))
        {
            cola.Solicitar(() => 1);
            await entrada.Task;
            cola.Solicitar(() => 2);
            cola.Solicitar(() => 3);
            continuar.TrySetResult(true);
            await cola.EsperarAsync();
            Exige(maximas == 1 && aplicadas.SequenceEqual(new[] { 3 }) && descartadas.SequenceEqual(new[] { 1 }),
                "Una preparación lenta no debe competir con otra ni publicar una configuración antigua.");
            cola.Solicitar(() => 4);
            await cola.EsperarAsync();
            Exige(fallos.Count == 1 && !cola.Pendiente && !aplicadas.Contains(4),
                "Un error debe notificarse y liberar la cola sin publicar un resultado inválido.");
            cola.Solicitar(() => 5);
            await cola.EsperarAsync();
            Exige(aplicadas.Last() == 5 && !cola.Pendiente, "La siguiente configuración debe poder recuperarse después de un error.");
            cola.Solicitar(() => throw new InvalidOperationException("fallo al capturar"));
            await cola.EsperarAsync();
            Exige(fallos.Count == 2 && !cola.Pendiente, "Un fallo al capturar no debe dejar la actualización bloqueada.");
        }

        entrada = new(TaskCreationOptions.RunContinuationsAsynchronously);
        continuar = new(TaskCreationOptions.RunContinuationsAsynchronously);
        aplicadas.Clear(); descartadas.Clear();
        using (var cola = new MYGActualizacionDiferida<int, int>(async n =>
        { entrada.TrySetResult(true); await continuar.Task; return n; }, aplicadas.Add, fallos.Add, descartadas.Add, demoraMs: 1))
        {
            cola.Solicitar(() => 7);
            await entrada.Task;
            cola.Invalidar();
            continuar.TrySetResult(true);
            await cola.EsperarAsync();
            Exige(aplicadas.Count == 0 && descartadas.SequenceEqual(new[] { 7 }) && !cola.Pendiente,
                "Invalidar debe descartar el resultado en curso sin publicar una vista anterior.");
        }

        int descartadasAlCerrar = 0;
        var cerrada = new MYGActualizacionDiferida<int, int>(n => Task.FromResult(n), _ => descartadasAlCerrar++, fallos.Add, demoraMs: 10);
        cerrada.Solicitar(() => 8);
        cerrada.Dispose();
        await cerrada.EsperarAsync();
        Exige(descartadasAlCerrar == 0 && !cerrada.Pendiente, "Cerrar debe cancelar las solicitudes pendientes y evitar callbacks sobre una ventana cerrada.");

        MYGActualizacionDiferida<int, int> reentrante = null;
        aplicadas.Clear();
        using (reentrante = new MYGActualizacionDiferida<int, int>(Task.FromResult, n =>
        {
            aplicadas.Add(n);
            if (n == 9) reentrante.Solicitar(() => 10);
        }, fallos.Add, demoraMs: 0))
        {
            reentrante.Solicitar(() => 9);
            await reentrante.EsperarAsync();
            Exige(aplicadas.SequenceEqual(new[] { 9, 10 }) && !reentrante.Pendiente,
                "Una solicitud surgida durante la aplicación debe terminar dentro de la misma espera.");
        }
    }

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }

    private sealed class ContextoPrueba : SynchronizationContext, IDisposable
    {
        private readonly BlockingCollection<(SendOrPostCallback Accion, object Estado)> cola = new();
        public override void Post(SendOrPostCallback accion, object estado) => cola.Add((accion, estado));
        internal void Procesar()
        { if (cola.TryTake(out var trabajo, 50)) trabajo.Accion(trabajo.Estado); }
        public void Dispose() => cola.Dispose();
    }
}
