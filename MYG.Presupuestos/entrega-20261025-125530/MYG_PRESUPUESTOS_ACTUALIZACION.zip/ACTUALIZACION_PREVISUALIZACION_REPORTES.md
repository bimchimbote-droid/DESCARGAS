# Previsualización de presupuestos, costos y metrados

Base del código: `bimchimbote-droid/MYG.Presupuestos`, rama `main`, commit
`c95ab893faf6bcab97492a6ebe53b720b33229c7`.
Esta actualización complementa la corrección de desplazamiento continuo
`entrega-20261025-123109`, que debe estar aplicada previamente. Conserva el zoom,
la caché y el desplazamiento continuo. Contiene once archivos nuevos o actualizados
para que el panel responda sin abrir una ventana de carga; no incluye ejecutables,
paquetes ni bases de datos.

## Panel de configuración sin ventana de carga

- La ventana de carga se conserva al abrir inicialmente el previsualizador.
  Cambiar sus ajustes después no abre otro diálogo ni deshabilita el panel.
- Líneas de división, colores de títulos, color de página y filigrana renuevan
  directamente el dibujo del plan existente, sin recalcular fórmulas ni cortes.
- Copias, rango de páginas y zoom no vuelven a preparar el informe.
- Papel, orientación, márgenes, fuente, repetición de títulos, encabezados y
  escala de impresión pueden cambiar los cortes: se procesan en un trabajador
  STA, manteniendo la interfaz disponible y la vista anterior durante el cálculo.
- Las pulsaciones rápidas se agrupan con una pausa de 200 ms. Se prepara una sola
  tarea a la vez y sólo se publica el resultado de la configuración más reciente.
  La captura de ajustes no clona las hojas ni recorre todas las celdas en la UI.
- La barra de estado indica «Actualizando vista…» mientras hace falta terminar
  un cálculo. Impresión y exportación se habilitan cuando las páginas corresponden
  a los ajustes actuales, para evitar entregar un informe con ajustes anteriores.
- Se conserva el zoom, la página y, cuando es posible, la posición dentro de ella.
  Si los ajustes o el dibujo fallan, el mensaje queda en la propia vista; corregir
  los ajustes permite reintentar sin abrir la ventana de carga.

La respuesta de los controles es inmediata, pero la paginación de un documento
grande sigue necesitando cálculo. No se promete un tiempo fijo ni se oculta ese
trabajo: se reduce el trabajo repetido y se realiza sin bloquear la interfaz.

## Comportamiento de las vistas

- La mejora se aplica al componente común de vista preliminar: presupuesto
  seleccionado, todos los presupuestos, hoja de resumen, análisis de costos,
  consolidado, metrados y metrados de fierros/aceros. También lo usan las vistas
  de impresión de metrados Excel y los informes de programación.
- La barra vertical y la rueda sin Ctrl recorren ahora todo el documento: las
  hojas siguientes aparecen debajo de las anteriores. En dos columnas, continúa
  con la siguiente fila de páginas en lugar de limitarse al primer par.
- El contador y las flechas se sincronizan con las páginas visibles al bajar,
  subir o arrastrar la barra. Las flechas desplazan la misma superficie y Última
  página alcanza el final del documento. El rango de impresión no cambia.
- Sólo se generan imágenes de las páginas que entran en pantalla; calcular la
  extensión de las 39 o más hojas no obliga a dibujarlas todas al abrir la vista.
- Ctrl + rueda acerca y aleja suavemente entre 10 % y 500 %, manteniendo el punto
  bajo el cursor. La lista, los botones y el deslizador usan el mismo rango.
- Al alejar lo suficiente, se muestran dos hojas cuando caben y existen varias
  páginas. Al acercar vuelve a una. El botón Varias páginas permite elegir el
  modo manual; Página completa ajusta el modo elegido.
- Navegar y alternar entre una y dos páginas reutiliza los metaficheros de las
  páginas ya visitadas. La caché conserva hasta 128 páginas y 128 MiB de buffers
  EMF, retirando las menos recientes. Las páginas visibles se conservan aunque
  por sí solas superen ese presupuesto. No es un límite de toda la RAM de GDI.
- Los cortes de página y cálculos se preparan una vez por configuración. Cambiar
  zoom o navegar no repagina el informe. Cambiar papel, márgenes, fuente, escala
  de impresión o impresora sí necesita volver a preparar sus cortes.
- Color de página y filigrana renuevan el dibujo sin recalcular las fórmulas ni
  los saltos de página. Las imágenes anteriores se invalidan para que no aparezca
  una decoración obsoleta.
- La composición, las copias de hojas y la paginación se realizan fuera de la
  interfaz, mientras el diálogo muestra etapas reales. La carga se mantiene
  hasta preparar los controles y dibujar la primera página. Mostrar después la
  ventana preparada no repite la paginación.
- Las opciones de metrados en formato Excel conservan su vista de celdas y sus
  funciones. Su apertura también informa las etapas de preparación; al entrar
  en su vista de impresión se utiliza el previsualizador común actualizado.

## Impresión y exportación

Impresión y Microsoft Print to PDF continúan usando el mismo plan y los mismos
cortes revisados en la vista. Si se cambia al controlador PDF, hay que revisar
las páginas recalculadas antes de confirmar la exportación, como en el flujo
existente. El rango de páginas y las copias siguen disponibles.

Los reportes no requieren Microsoft Word. Los formatos editables de exportación
conservan su funcionamiento: pueden volver a distribuirse en el programa que
los abra. La coincidencia de esta vista corresponde a impresión/PDF con la misma
configuración, no a una promesa de paginación de todos los formatos editables.

## Aplicar la entrega

1. Respalde o confirme sus modificaciones locales. Compare con la base indicada
   si tiene cambios posteriores: se entregan archivos completos para reemplazar.
2. Aplique primero la corrección `entrega-20261025-123109` si todavía no la tiene.
   Extraiga este ZIP sobre la raíz de `MYG.Presupuestos`, conservando las carpetas.
   Cree los archivos nuevos y sustituya los indicados en la tabla de la respuesta.
3. No hay eliminaciones, nuevos paquetes ni migraciones de bases de datos.
4. Restaure y compile con .NET 10.0.100 o una versión admitida por `global.json`:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2
```

La opción de referencias Revit ya existe en el proyecto y permite compilar sin
tener Autodesk instalado. No instala Revit ni permite ejecutarlo en Linux.

## Validación

Resultado de esta entrega: solución completa compilada en Release con .NET
10.0.100, cero errores y cero advertencias. `MYG.Pruebas` completó 600
comprobaciones, incluidas la agrupación de ajustes rápidos, una sola preparación
en curso, descarte de resultados antiguos, errores y recuperación, solicitudes
aisladas con referencias METRADO y la geometría continua de 39 hojas.
La prueba rápida de actualización diferida también finalizó correctamente. La suite de nube
de la entrega anterior completó 39 grupos principales y 982 comprobaciones de
contrato HTTP simulado; no fue necesario repetirla para esta corrección visual.
Las pruebas gráficas nuevas se compilaron, pero no se ejecutaron en Linux.
Se omitieron Named Pipes de Windows y la base privada LLACUSBAMBA.

Pruebas portables de lógica, fórmulas y composición de todos los tipos de reporte:

```powershell
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release
# Comprobación rápida y portable de las 39 páginas y sus posiciones.
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release -- --desplazamiento-reportes
# Cola de ajustes: ráfagas, una sola tarea, último resultado y recuperación.
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release -- --actualizacion-reportes
```

Pruebas específicas de la carga, reutilización de páginas, zoom y configuración,
en Windows x64 con .NET Desktop Runtime 10:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --reportes-previsualizacion
```

Las comprobaciones gráficas se compilan en Linux pero necesitan Windows para
ejecutarse. No se midieron tiempos con la base privada LLACUSBAMBA de la captura,
que no está disponible en este entorno. Consulte la respuesta de entrega para
los resultados efectivos de compilación y pruebas.

Las pruebas gráficas incluyen un documento sintético de 160 hojas: rueda normal,
barra hasta la última hoja, filas de dos columnas, conservación del ancla de zoom
en la página 61, reutilización de imágenes y límite de caché. Se compilaron; su
ejecución real requiere Windows.

También se comprueban los cambios rápidos del panel sin diálogo, la actividad del
temporizador de UI, la última configuración aplicada, la conservación de página
y zoom, los cambios de apariencia sin repaginación y los mensajes ante errores.

Revise manualmente los informes del menú, desplazamiento hasta la última hoja,
Ctrl + rueda en ambos sentidos, la
transición a dos hojas, el regreso a páginas visitadas y el rango de impresión.
Cambie orientación/márgenes y compruebe que la carga acompaña la actualización.
Pruebe color y filigrana, y revise los mismos cortes al exportar PDF. Confirme
también la apertura y la vista de impresión de los metrados Excel disponibles.

Después de validar, revise los cambios en Visual Studio, haga Commit y Push a su
rama y compruébelos en GitHub. Publicar el ZIP en DESCARGAS no modifica la rama
del código ni aplica automáticamente los cambios en su equipo.

## Archivos de esta entrega

Aplicar sobre la [corrección anterior de desplazamiento continuo](https://raw.githubusercontent.com/bimchimbote-droid/DESCARGAS/256a42d8b55a09b3e4c523b781d84790718997b7/MYG.Presupuestos/entrega-20261025-123109/MYG_PRESUPUESTOS_ACTUALIZACION.zip).

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `ACTUALIZACION_PREVISUALIZACION_REPORTES.md` | REEMPLAZAR | Instalación, alcance y resultados de esta actualización. |
| 2 | `MYG.Core/ConfiguracionVistaReporte.cs` | REEMPLAZAR | Captura ligera de ajustes y materialización aislada en segundo plano. |
| 3 | `MYG.Desktop/ActualizacionDiferida.cs` | CREAR | Agrupa pulsaciones y sólo publica la configuración más reciente. |
| 4 | `MYG.Desktop/ReportesImpresion.cs` | REEMPLAZAR | Actualiza líneas y colores sin recalcular las páginas. |
| 5 | `MYG.Desktop/VistaPreliminarReportesForm.cs` | REEMPLAZAR | Panel sin carga modal, actualización diferida y salidas coherentes. |
| 6 | `MYG.Pruebas/ActualizacionDiferidaCheck.cs` | CREAR | Pruebas de ráfagas, serialización, descarte y recuperación. |
| 7 | `MYG.Pruebas/ConfiguracionVistaReporteCheck.cs` | REEMPLAZAR | Pruebas de solicitudes aisladas, estilos y referencias METRADO. |
| 8 | `MYG.Pruebas/MYG.Pruebas.csproj` | REEMPLAZAR | Incluye el coordinador compartido en las pruebas portables. |
| 9 | `MYG.Pruebas/Program.cs` | REEMPLAZAR | Registra las pruebas y el comando rápido de actualización. |
| 10 | `MYG.PruebasUI/ReportesCargaProgresoCheck.cs` | REEMPLAZAR | Verifica la carga sólo en la apertura inicial. |
| 11 | `MYG.PruebasUI/VistaPreliminarReportesCheck.cs` | REEMPLAZAR | Pruebas de panel activo, cambios rápidos, apariencia y errores. |
