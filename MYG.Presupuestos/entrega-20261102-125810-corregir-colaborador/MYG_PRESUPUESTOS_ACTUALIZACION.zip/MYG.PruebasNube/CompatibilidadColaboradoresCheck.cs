using System.Net;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

/// <summary>Regresión del contrato de permisos entre servidores previos y posteriores a Metrados Revit.</summary>
internal static class CompatibilidadColaboradoresCheck
{
    private const string Servidor = "https://compatibilidad-colaboradores.supabase.co";
    private const string UsuarioMyg = "c";
    private const string SecretoRemoto = "SENTINELA_CUERPO_REMOTO_NO_PUBLICAR";
    private static readonly Guid ProyectoId = Guid.Parse("2c9a38b2-77d2-46e4-91e9-ddc81b91bd15");
    private static readonly Guid UsuarioId = Guid.Parse("4d905fd1-dbc9-4e45-9e4d-e817cb0c47bf");
    private static readonly Guid MiembroId = Guid.Parse("8ff10591-0f36-4931-8758-724315d43fe8");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        await ServidorAnterior();
        await ServidorRevit();
        await RevitNoSeDegrada();
        await DiagnosticosPrecisos();
        await MensajesRemotosNoSonInstrucciones();
        Console.WriteLine($"OK Compatibilidad de colaboradores: {comprobaciones} comprobaciones de contrato legado/BIM, roles, revocación, identidad y diagnósticos seguros; HTTP simulado, sin red.");
    }

    private static async Task ServidorAnterior()
    {
        using var http = new ServidorSintetico(admiteRevit: false);
        using var cliente = await Conectar(http);
        foreach (string rol in new[] { "lector", "editor", "administrador" })
        {
            var permisos = new MYGPermisosModulos
            {
                Acu = false, Especificaciones = rol != "lector", MetradosExcel = rol == "administrador",
                MetradosRevit = false, MetradosRevitDisponible = true
            };
            int anteriores = http.Peticiones.Count;
            await cliente.CompartirConUsuarioMygAsync(ProyectoId, " X ", rol, permisos);
            Exige(http.Peticiones.Count == anteriores + 1 && http.Mutaciones == http.Peticiones.Count,
                "agregar en servidor anterior debe confirmar una sola RPC sin negociar ni reintentar.");
            var enviada = http.Peticiones[^1];
            Exige(enviada.UsuarioMyg == "x" && enviada.Rol == rol,
                "debe aceptar un usuario de un carácter y conservar normalización y rol.");
            Exige(enviada.Modulos.Count == 3 && !enviada.Modulos.ContainsKey("metrados_revit")
                && !enviada.Modulos["acu"] && enviada.Modulos["especificaciones"] == permisos.Especificaciones
                && enviada.Modulos["metrados_excel"] == permisos.MetradosExcel,
                "el servidor previo debe recibir exactamente los tres permisos originales.");
            Exige(!permisos.Acu && !permisos.MetradosRevit && permisos.MetradosRevitDisponible,
                "la compatibilidad no debe modificar el objeto de permisos del llamador.");
        }
        await cliente.CambiarPermisosMiembroAsync(ProyectoId, MiembroId.ToString("D"),
            new MYGPermisosModulos { Acu = true, Especificaciones = false, MetradosExcel = true, MetradosRevit = false });
        var cambio = http.Peticiones[^1];
        Exige(cambio.Rpc == "myg_nube_permisos" && cambio.UsuarioId == MiembroId && cambio.Modulos.Count == 3,
            "cambiar permisos debe usar también el contrato legado y el UUID del miembro correcto.");
        Exige(cambio.Modulos["acu"] && !cambio.Modulos["especificaciones"] && cambio.Modulos["metrados_excel"],
            "la adaptación no debe ampliar ni perder las restricciones solicitadas.");
        Exige(cliente.UsuarioId == UsuarioId.ToString("D") && cliente.UsuarioMygSesion == UsuarioMyg
            && cliente.SesionIniciada && !http.RevitGuardado,
            "el éxito no debe cambiar la cuenta ni conceder Revit implícitamente.");
    }

    private static async Task ServidorRevit()
    {
        using var http = new ServidorSintetico(admiteRevit: true);
        using var cliente = await Conectar(http);
        var permisos = new MYGPermisosModulos
        { Acu = false, Especificaciones = true, MetradosExcel = false, MetradosRevit = true };
        await cliente.CompartirConUsuarioMygAsync(ProyectoId, "colaborador", "editor", permisos);
        Exige(http.Peticiones[^1].Modulos.Count == 4 && http.Peticiones[^1].Modulos["metrados_revit"]
            && http.RevitGuardado,
            "solicitar Revit debe enviar explícitamente ese permiso en un servidor actualizado.");
        permisos.MetradosRevit = false;
        await cliente.CambiarPermisosMiembroAsync(ProyectoId, MiembroId.ToString("D"), permisos);
        Exige(http.Peticiones[^1].Modulos.Count == 3 && !http.RevitGuardado,
            "omitir Revit al actualizar debe revocar un permiso anterior, nunca conservarlo por accidente.");
        permisos.MetradosRevit = true;
        await cliente.CambiarPermisosMiembroAsync(ProyectoId, MiembroId.ToString("D"), permisos);
        Exige(http.Peticiones[^1].Modulos.Count == 4 && http.RevitGuardado,
            "cambiar permisos también debe poder conceder Revit explícitamente.");
        await cliente.CompartirConUsuarioMygAsync(ProyectoId, "lector", "lector",
            new MYGPermisosModulos { Acu = false, Especificaciones = false, MetradosExcel = false });
        Exige(http.Peticiones[^1].Modulos.Count == 3 && !http.RevitGuardado
            && http.Peticiones[^1].Modulos.Values.All(v => !v),
            "un lector debe conservar todos los módulos sin edición en el servidor nuevo.");
    }

    private static async Task RevitNoSeDegrada()
    {
        using var http = new ServidorSintetico(admiteRevit: false);
        using var cliente = await Conectar(http);
        var permisos = new MYGPermisosModulos { MetradosRevit = true };
        var error = await Rechaza(() => cliente.CompartirConUsuarioMygAsync(ProyectoId, "x", "editor", permisos));
        Exige(http.Peticiones.Count == 1 && http.Mutaciones == 0
            && http.Peticiones[0].Modulos.Count == 4 && http.Peticiones[0].Modulos["metrados_revit"],
            "un servidor viejo debe rechazar Revit sin un segundo envío silencioso que retire el permiso solicitado.");
        VerificarErrorSinDatos(error);
        Exige(error.Codigo == "22023" && error.Message.Contains("permis", StringComparison.OrdinalIgnoreCase),
            "el rechazo del colaborador debe explicar que el servidor rechazó los permisos.");
        error = await Rechaza(() => cliente.CambiarPermisosMiembroAsync(ProyectoId, MiembroId.ToString("D"), permisos));
        Exige(http.Peticiones.Count == 2 && http.Mutaciones == 0 && permisos.MetradosRevit,
            "el cambio de permisos incompatible tampoco debe reintentar ni alterar el objeto original.");
        VerificarErrorSinDatos(error);
        Exige(error.Message.Contains("permis", StringComparison.OrdinalIgnoreCase),
            "el rechazo de permisos necesita diagnóstico específico.");
    }

    private static async Task DiagnosticosPrecisos()
    {
        foreach (string marcador in new[] { "MYG_COLABORADOR_INVALIDO", "MYG_PERMISOS_INVALIDOS",
            "MYG_DESTINATARIO_NO_VERIFICADO", "MYG_MIEMBRO_NO_EXISTE" })
        {
            using var http = new ServidorSintetico(admiteRevit: true) { MarcadorForzado = marcador };
            using var cliente = await Conectar(http);
            Func<Task> accion = marcador is "MYG_PERMISOS_INVALIDOS" or "MYG_MIEMBRO_NO_EXISTE"
                ? () => cliente.CambiarPermisosMiembroAsync(ProyectoId, MiembroId.ToString("D"), new MYGPermisosModulos())
                : () => cliente.CompartirConUsuarioMygAsync(ProyectoId, "x", "lector", new MYGPermisosModulos());
            var error = await Rechaza(accion);
            VerificarErrorSinDatos(error);
            Exige(http.Mutaciones == 0 && http.Peticiones.Count == 1 && cliente.SesionIniciada
                && cliente.UsuarioMygSesion == UsuarioMyg && !error.NecesitaIniciarSesion,
                "un rechazo de datos o destinatario no puede conceder acceso ni cerrar la sesión del propietario.");
            Exige(!error.Message.Contains("La nube rechazó los datos del proyecto, la revisión o la operación.", StringComparison.Ordinal),
                "los marcadores de colaboración conocidos necesitan una explicación distinta del error genérico.");
            if (marcador == "MYG_DESTINATARIO_NO_VERIFICADO")
                Exige(error.Message.Contains("verific", StringComparison.OrdinalIgnoreCase)
                    && error.Message.Contains("usuario", StringComparison.OrdinalIgnoreCase),
                    "el destinatario sin vínculo verificado debe explicarse sin atribuir el problema al propietario.");
            else if (marcador == "MYG_MIEMBRO_NO_EXISTE")
                Exige(error.Message.Contains("miembro", StringComparison.OrdinalIgnoreCase)
                    || error.Message.Contains("colaborador", StringComparison.OrdinalIgnoreCase),
                    "la ausencia del miembro debe identificarse como problema del colaborador.");
            else
                Exige(error.Message.Contains("permis", StringComparison.OrdinalIgnoreCase),
                    "el diagnóstico de los datos de colaboración debe mencionar permisos.");
        }
    }

    private static async Task MensajesRemotosNoSonInstrucciones()
    {
        foreach (var caso in new[]
        {
            (Codigo: "22023", Marcador: "MYG_DESTINATARIO_NO_VERIFICADO " + SecretoRemoto),
            (Codigo: "22023", Marcador: "MYG_COLABORADOR_INVALIDO\n" + SecretoRemoto),
            (Codigo: "22023", Marcador: "myg_destinatario_no_verificado"),
            (Codigo: "22023", Marcador: "ERROR_DESCONOCIDO_" + SecretoRemoto),
            (Codigo: "42501", Marcador: "MYG_DESTINATARIO_NO_VERIFICADO")
        })
        {
            using var http = new ServidorSintetico(admiteRevit: true)
            { MarcadorForzado = caso.Marcador, CodigoForzado = caso.Codigo };
            using var cliente = await Conectar(http);
            var error = await Rechaza(() => cliente.CompartirConUsuarioMygAsync(ProyectoId, "x", "lector", new MYGPermisosModulos()));
            VerificarErrorSinDatos(error);
            Exige(!error.Message.Contains("vinculación de nube verificada", StringComparison.OrdinalIgnoreCase),
                "un marcador parecido o con otro SQLSTATE no debe activar el diagnóstico del destinatario.");
            if (caso.Codigo == "22023")
                Exige(error.Message.Contains("La nube rechazó los datos del proyecto, la revisión o la operación.", StringComparison.Ordinal),
                    "un marcador desconocido o no exacto debe conservar el diagnóstico genérico seguro.");
            else
                Exige(error.AccesoDenegado && error.Codigo == "42501",
                    "el diagnóstico del destinatario no debe ocultar un rechazo real de autorización.");
        }
    }

    private static void VerificarErrorSinDatos(NubeException error)
    {
        Exige(!error.Message.Contains(SecretoRemoto, StringComparison.Ordinal)
            && !error.Message.Contains("https://secreto.example", StringComparison.Ordinal)
            && !error.Message.Contains("access_token", StringComparison.Ordinal)
            && !error.Message.Contains("MYG_COLABORADOR_INVALIDO", StringComparison.Ordinal)
            && !error.Message.Contains("MYG_DESTINATARIO_NO_VERIFICADO", StringComparison.Ordinal),
            "el diagnóstico debe usar textos locales, sin copiar el cuerpo, detalles ni enlaces del servidor.");
        Exige(error.Message.Contains("Diagnóstico: HTTP", StringComparison.Ordinal)
            && error.Message.Contains("myg_nube_", StringComparison.Ordinal),
            "el texto seguro debe conservar HTTP y la operación que falló para poder diagnosticarla.");
    }

    private static async Task<ClienteSupabase> Conectar(ServidorSintetico http)
    {
        var cliente = new ClienteSupabase(Servidor, "sb_publishable_compatibilidad_sintetica", http);
        await cliente.IniciarSesionMygAsync(new TicketNubeMYG("cabecera.cuerpo.firma", UsuarioMyg,
            Servidor, DateTimeOffset.UtcNow.AddSeconds(60)));
        return cliente;
    }

    private sealed record Peticion(string Rpc, string? UsuarioMyg, Guid? UsuarioId,
        string? Rol, IReadOnlyDictionary<string, bool> Modulos);

    private sealed class ServidorSintetico(bool admiteRevit) : HttpMessageHandler
    {
        internal readonly List<Peticion> Peticiones = new();
        internal int Mutaciones;
        internal bool RevitGuardado;
        internal string? MarcadorForzado;
        internal string CodigoForzado = "22023";

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            string ruta = request.RequestUri!.AbsolutePath;
            if (ruta == "/functions/v1/myg-login")
                return Json(new { access_token = "acceso_compatibilidad", refresh_token = "refresco_compatibilidad",
                    expires_in = 3600, user = new { id = UsuarioId }, usuario_myg = UsuarioMyg });
            Exige(request.Method == HttpMethod.Post && request.Headers.Authorization?.Parameter == "acceso_compatibilidad"
                && request.Headers.Contains("apikey"), "la operación de permisos debe conservar método y autenticación.");
            string rpc = ruta.Split('/').Last();
            Exige(ruta == "/rest/v1/rpc/myg_nube_compartir_usuario" || ruta == "/rest/v1/rpc/myg_nube_permisos",
                "la compatibilidad no debe buscar usuarios ni invocar endpoints adicionales.");
            using var json = JsonDocument.Parse(await request.Content!.ReadAsStringAsync(ct));
            var p = json.RootElement;
            bool compartir = rpc == "myg_nube_compartir_usuario";
            Exige(p.GetProperty("p_id").GetGuid() == ProyectoId && p.EnumerateObject().Count() == (compartir ? 4 : 3),
                "la petición debe apuntar exclusivamente al proyecto y contrato previsto.");
            string? nombre = compartir ? p.GetProperty("p_usuario_myg").GetString() : null;
            string? rol = compartir ? p.GetProperty("p_rol").GetString() : null;
            Guid? miembro = compartir ? null : p.GetProperty("p_usuario").GetGuid();
            Exige(compartir ? !string.IsNullOrWhiteSpace(nombre) && nombre == nombre.Trim().ToLowerInvariant()
                && rol is "lector" or "editor" or "administrador" : miembro == MiembroId,
                "la normalización no puede cambiar la identidad MYG, el rol o el miembro editado.");
            var permisos = p.GetProperty("p_permisos_modulos");
            var mapa = permisos.EnumerateObject().ToDictionary(x => x.Name, x => x.Value.GetBoolean(), StringComparer.Ordinal);
            Peticiones.Add(new(rpc, nombre, miembro, rol, mapa));
            if (MarcadorForzado is not null) return Error(MarcadorForzado, CodigoForzado);

            // Replica la allowlist de las migraciones 20261020 y 20261104. El servidor
            // previo rechaza incluso metrados_revit:false: el error ocurre antes de
            // buscar al destinatario, tal como MYG_COLABORADOR_INVALIDO en Supabase.
            bool valida = new[] { "acu", "especificaciones", "metrados_excel" }.All(mapa.ContainsKey)
                && mapa.Keys.All(k => k is "acu" or "especificaciones" or "metrados_excel"
                    || admiteRevit && k == "metrados_revit");
            if (!valida) return Error(compartir ? "MYG_COLABORADOR_INVALIDO" : "MYG_PERMISOS_INVALIDOS");
            Mutaciones++;
            RevitGuardado = mapa.TryGetValue("metrados_revit", out bool revit) && revit;
            return Json(new { estado = "actualizada" });
        }

        private static HttpResponseMessage Error(string marcador, string codigo = "22023") => Json(new
        {
            code = codigo, message = marcador,
            details = SecretoRemoto + " access_token=secreto https://secreto.example",
            hint = SecretoRemoto
        }, codigo == "42501" ? HttpStatusCode.Forbidden : HttpStatusCode.BadRequest);

        private static HttpResponseMessage Json(object dato, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        { Content = new StringContent(JsonSerializer.Serialize(dato), Encoding.UTF8, "application/json") };
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error) { comprobaciones++; return error; }
        throw new InvalidOperationException("Compatibilidad colaboradores: se esperaba rechazo de la operación.");
    }

    private static void Exige(bool condicion, string detalle)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException("Compatibilidad colaboradores: " + detalle); }
}
