# Corrección MYG_COLABORADOR_INVALIDO

Aplicar sobre la entrega anterior del menú de colaboradores (DESCARGAS commit
636d6110897b9e1631f30d0aa1d1d0d60576397a), código main
83974008e17cf37a292a75d5e18db7a49523ee46.

## Causa y cambio

El cliente enviaba metrados_revit:false incluso al agregar un lector. El
validador anterior de Supabase acepta exactamente acu, especificaciones y
metrados_excel, por lo que devuelve HTTP400/22023/MYG_COLABORADOR_INVALIDO antes
de buscar al destinatario. Se reprodujo con los validadores SQL exactos.

Agregar colaborador y cambiar permisos ahora envían tres campos cuando Revit
está desactivado. El servidor BIM interpreta la ausencia como false, también
al revocar un permiso anterior. Cuando Revit está activado se envía true
explícitamente, sin reintentar con permisos distintos. El servidor anterior
requiere la migración completa 20261104_modeladores_bim.sql para ese módulo.

Los errores conocidos de colaboración ahora muestran instrucciones precisas,
sin copiar texto remoto ni exponer datos. La verificación de identidad, roles,
privacidad de la base y permisos del servidor se conserva.

## Instalar y comprobar

1. Cierre MYG y respalde sus cambios locales. Este ZIP es incremental sobre la
   entrega anterior indicada arriba; contiene solo archivos nuevos o modificados.
2. Copie los archivos conservando sus rutas. Compare antes de reemplazar si
   tiene cambios propios. No se elimina ningún archivo.
3. Con SDK .NET 10, desde la raíz:

   ```powershell
   dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -p:UseSharedCompilation=false -m:1 -nr:false
   dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --compatibilidad-colaboradores
   dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --permisos-modulos
   ```

4. Abra la obra y pruebe Agregar colaborador con rol lector. Para usar los tres
   módulos anteriores no necesita ejecutar SQL nuevo. Para habilitar edición
   Revit el servidor debe tener la migración BIM completa y sus prerrequisitos.
5. El destinatario debe tener un vínculo MYG de nube activo y verificado único.
   Si aparece el aviso correspondiente, compruebe su nombre y que haya ingresado
   a Nube MYG; el administrador debe revisar vínculos ausentes o duplicados.
6. En Visual Studio revise Cambios de Git, haga Commit y Push cuando valide la
   actualización, y compruebe su rama en GitHub. El ZIP en DESCARGAS no publica
   ni aplica cambios automáticamente al repositorio del código.

## Evidencia y límites

.NET SDK10.0.100; solución Release: 0 errores, 0 advertencias.
154 comprobaciones nuevas de compatibilidad, 191 de permisos y 206 de
colaboración por obra aprobadas con HTTP simulado/SQLite. Otras 15 comprobaciones
SQL pasaron en PostgreSQL efímero sin red con ambos validadores exactos.
No se alteró Supabase de producción, ni se ejecutó Windows/Revit.
La suite global conserva su fallo previo de renovación de sesión, independiente
de esta corrección; no se declara aprobada.

No hay dependencias, proyectos, lockfiles ni migraciones nuevos. El paquete
conserva la interfaz de la entrega anterior. Las pruebas del modelo local
mantienen sus cuatro campos; el contrato RPC compatible se valida por separado.
