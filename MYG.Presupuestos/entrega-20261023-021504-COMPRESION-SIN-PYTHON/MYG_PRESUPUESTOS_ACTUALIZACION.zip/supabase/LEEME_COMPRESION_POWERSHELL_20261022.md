# Comprimir una copia del pendiente sin Python

El equipo del usuario no encuentra `py` ni `python`. Esta alternativa utiliza
Windows PowerShell y .NET, incluidos en Windows, para realizar la misma prueba
local. No necesita instalar Python ni cambiar el ejecutable MYG.

## Qué hacer ahora

1. Abrir el ZIP nuevo y copiar sus carpetas `scripts` y `supabase` dentro de la
   carpeta de trabajo `CODEX`, conservando las rutas. En la captura del usuario
   PowerShell ya está situado en esa carpeta.
2. Ejecutar lo siguiente en esa ventana, sin una publicación de MYG en curso:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\diagnosticos\Probar-CompresionPaquete.ps1
```

3. Esperar a que termine. El script localizará el único `.json` de
   `%LOCALAPPDATA%\MYG\Nube\trabajo\publicaciones`, que en la captura ocupa
   aproximadamente 200,1 MiB. No selecciona el archivo `.lock` ni busca dentro
   de `retiradas`.
4. En el Escritorio aparecerá una carpeta nueva `MYG_Compresion_...`. Dentro hay
   `copia.gz` y `resultado.json`. La consola también muestra dónde se guardaron.
5. Compartir únicamente `resultado.json` o sus campos `bytes_originales`,
   `bytes_gzip`, `ahorro_porcentaje` y `roundtrip_exacto`.

`-ExecutionPolicy Bypass` se aplica únicamente al proceso que ejecuta esta
prueba; no cambia la política global ni requiere permisos de administrador.

Si hay más de un pendiente JSON, el programa no elige uno arbitrariamente.
En ese caso se puede indicar el archivo explícitamente:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\diagnosticos\Probar-CompresionPaquete.ps1 -Archivo "C:\RUTA\AL\PENDIENTE.json"
```

## Qué conserva y qué comprueba

El archivo original se abre solo para lectura y se mantiene abierto mientras se
comprime y verifica. En Windows ese modo impide escrituras y borrados
concurrentes durante la prueba. No se interpreta ni reserializa el JSON y no se
modifica el UUID del intento.

La copia se escribe por bloques de 1 MiB. Se descomprime por bloques para
comprobar su longitud y SHA-256; después se vuelve a leer el origen y se revisan
su hash, longitud y fecha. Todo se prepara en una carpeta temporal hermana y se
publica mediante un movimiento de carpeta: si el destino aparece entretanto,
se rechaza sin sobrescribirlo. Ante un error se retiran los temporales propios.

El informe contiene solo tamaños, ahorro, hashes y confirmaciones de integridad.
No incluye contenido de la obra, nombres de proyectos ni credenciales. La copia
Gzip sí contiene los datos originales comprimidos; conservarla como archivo
privado local. No sustituir manualmente el pendiente activo por ella.

## Archivos de esta entrega

| Archivo | Acción |
|---|---|
| `scripts/diagnosticos/Probar-CompresionPaquete.ps1` | Añadir y ejecutar con el comando anterior. |
| `scripts/pruebas/ProbarCompresionPowerShellCheck.ps1` | Añadir. Pruebas opcionales de desarrollo; no hace falta ejecutarlas para medir el paquete. |
| `supabase/LEEME_COMPRESION_POWERSHELL_20261022.md` | Añadir y leer estas instrucciones. |

Son archivos nuevos. No reemplazan la herramienta Python ni los cambios previos,
no instalan SQL en Supabase y no cambian el programa de producción. Si se desea
conservarlos en el repositorio de código, revisar los cambios y hacer Commit y
Push en `MYG.Presupuestos`. La descarga publicada en `DESCARGAS` no hace ese Push.

## Validación realizada

La regresión nueva superó **11 escenarios y 72 comprobaciones**: contenido UTF-8,
binario de más de 1 MiB, archivo vacío, SHA-256 y descompresión independiente,
privacidad del informe, salida existente, origen ausente, detección de cero/uno/
varios pendientes, rutas relativas y el modo completo sin argumentos con salida
automática en el Escritorio. No quedaron temporales de compresión.

La ejecución funcional fue en PowerShell 7.4.19 sobre Linux. El script usa sintaxis
y API revisadas para Windows PowerShell 5.1/.NET Framework y se guarda con BOM
UTF-8 para que los mensajes se lean correctamente allí. No se presenta como una
ejecución ya realizada en Windows 5.1.

La primera prueba aprobó nueve escenarios y cincuenta comprobaciones. Se corrigió
la resolución de rutas relativas para que respete la ubicación de PowerShell,
y se añadieron los casos de esa ruta y del modo automático completo. Se repitió
solo esta nueva regresión después de ese cambio. No se repitieron benchmarks
grandes, pruebas de servidor ni compilaciones generales.

## Límite de esta prueba

La copia comprimida permite medir el ahorro real del pendiente privado. No se
ha medido todavía ese archivo de 200,1 MiB desde este entorno. Comprimir una copia
local no cambia el JSON que transmite la RPC actual ni considera resueltos los
HTTP 502/520. No se publica nada ni se usa la red durante esta prueba.
