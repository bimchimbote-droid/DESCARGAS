﻿#requires -Version 5.1
<#
Prueba local de Gzip sin instalar Python ni cambiar el pendiente de MYG.
Crea copia.gz y resultado.json; no publica datos ni utiliza la red.
Comprimir esta copia no modifica el JSON enviado por la RPC de publicación.
#>
[CmdletBinding()]
param(
    [string]$Archivo,
    [string]$Salida
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function ConvertTo-MYGHex {
    param([byte[]]$Bytes)
    return [BitConverter]::ToString($Bytes).Replace('-', '').ToLowerInvariant()
}

$mensajeSeguro = 'No se pudo leer, comprimir o verificar el archivo. El original no se sobrescribió.'
$marcaError = 'MYG_COMPRESION_RECHAZADA'
$temporalMYG = $null
$origenMYG = $null
$gzipMYG = $null
$salidaMYG = $null
$lectorGzipMYG = $null
$descompresorMYG = $null
$shaOriginalMYG = $null
$shaRestauradoMYG = $null
$shaGzipMYG = $null
$shaSegundoMYG = $null
$publicadoMYG = $false

try {
    if ([string]::IsNullOrWhiteSpace($Archivo)) {
        if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
            $mensajeSeguro = 'No se pudo localizar la carpeta de MYG. Indique el archivo con -Archivo.'
            throw $marcaError
        }
        $carpetaMYG = Join-Path (Join-Path (Join-Path (Join-Path $env:LOCALAPPDATA 'MYG') 'Nube') 'trabajo') 'publicaciones'
        if (-not (Test-Path -LiteralPath $carpetaMYG -PathType Container)) {
            $mensajeSeguro = 'No se encontró la carpeta de publicaciones. Indique el archivo con -Archivo.'
            throw $marcaError
        }
        $candidatosMYG = @(Get-ChildItem -LiteralPath $carpetaMYG -Filter '*.json' -File)
        if ($candidatosMYG.Count -ne 1) {
            $mensajeSeguro = 'Debe haber exactamente un JSON pendiente para elegirlo automáticamente. Indique el archivo con -Archivo.'
            throw $marcaError
        }
        $Archivo = $candidatosMYG[0].FullName
    }

    $itemMYG = Get-Item -LiteralPath $Archivo -Force
    if (-not ($itemMYG -is [IO.FileInfo])) {
        $mensajeSeguro = 'El origen debe ser un archivo regular.'
        throw $marcaError
    }
    $rutaOriginalMYG = $itemMYG.FullName

    if ([string]::IsNullOrWhiteSpace($Salida)) {
        $escritorioMYG = [Environment]::GetFolderPath([Environment+SpecialFolder]::Desktop)
        if ([string]::IsNullOrWhiteSpace($escritorioMYG) -or -not [IO.Directory]::Exists($escritorioMYG)) {
            $mensajeSeguro = 'No se pudo localizar el Escritorio. Indique una carpeta nueva con -Salida.'
            throw $marcaError
        }
        $nombreMYG = 'MYG_Compresion_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss') + '_' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
        $Salida = Join-Path $escritorioMYG $nombreMYG
    }
    # Resolver rutas relativas desde Get-Location de PowerShell, no desde el
    # directorio del proceso .NET, que puede ser distinto después de un cd.
    $destinoMYG = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Salida)
    if ([IO.File]::Exists($destinoMYG) -or [IO.Directory]::Exists($destinoMYG)) {
        $mensajeSeguro = 'La salida ya existe. Elija una carpeta nueva; no se sobrescriben archivos.'
        throw $marcaError
    }
    $padreMYG = [IO.Path]::GetDirectoryName($destinoMYG)
    if ([string]::IsNullOrWhiteSpace($padreMYG) -or -not [IO.Directory]::Exists($padreMYG)) {
        $mensajeSeguro = 'La carpeta padre de la salida debe existir.'
        throw $marcaError
    }

    # Preparar todo en una carpeta hermana. Directory.Move publica la carpeta
    # completa y rechaza un destino que aparezca concurrentemente, sin pisarlo.
    $nombreTemporalMYG = '.myg-compresion-' + [Guid]::NewGuid().ToString('N')
    $rutaTemporalMYG = Join-Path $padreMYG $nombreTemporalMYG
    [void](New-Item -ItemType Directory -Path $rutaTemporalMYG)
    $temporalMYG = $rutaTemporalMYG
    $rutaGzipMYG = Join-Path $temporalMYG 'copia.gz'

    # Mantener abierto el origen con permiso de lectura solamente. En Windows
    # FileShare.Read impide escrituras y borrados concurrentes mientras se mide.
    $origenMYG = [IO.FileStream]::new($rutaOriginalMYG, [IO.FileMode]::Open,
        [IO.FileAccess]::Read, [IO.FileShare]::Read)
    $itemMYG.Refresh()
    $longitudAntesMYG = $origenMYG.Length
    $fechaAntesMYG = $itemMYG.LastWriteTimeUtc.Ticks
    $shaOriginalMYG = [Security.Cryptography.SHA256]::Create()
    $salidaMYG = [IO.FileStream]::new($rutaGzipMYG, [IO.FileMode]::CreateNew,
        [IO.FileAccess]::Write, [IO.FileShare]::None)
    $gzipMYG = [IO.Compression.GZipStream]::new($salidaMYG,
        [IO.Compression.CompressionLevel]::Optimal, $true)
    $bufferMYG = New-Object byte[] (1024 * 1024)
    [long]$bytesOriginalesMYG = 0
    while (($leidosMYG = $origenMYG.Read($bufferMYG, 0, $bufferMYG.Length)) -gt 0) {
        [void]$shaOriginalMYG.TransformBlock($bufferMYG, 0, $leidosMYG, $bufferMYG, 0)
        $gzipMYG.Write($bufferMYG, 0, $leidosMYG)
        $bytesOriginalesMYG += $leidosMYG
    }
    [void]$shaOriginalMYG.TransformFinalBlock([byte[]]@(), 0, 0)
    $huellaOriginalMYG = ConvertTo-MYGHex $shaOriginalMYG.Hash
    $gzipMYG.Dispose()
    $gzipMYG = $null
    $salidaMYG.Flush($true)
    $salidaMYG.Dispose()
    $salidaMYG = $null

    if ($origenMYG.Length -ne $longitudAntesMYG -or $bytesOriginalesMYG -ne $longitudAntesMYG) {
        $mensajeSeguro = 'El origen cambió durante la lectura. No se publicó una copia.'
        throw $marcaError
    }

    # Descomprimir por bloques y acotar los bytes a la longitud real del origen.
    $lectorGzipMYG = [IO.FileStream]::new($rutaGzipMYG, [IO.FileMode]::Open,
        [IO.FileAccess]::Read, [IO.FileShare]::Read)
    [long]$bytesGzipMYG = $lectorGzipMYG.Length
    $descompresorMYG = [IO.Compression.GZipStream]::new($lectorGzipMYG,
        [IO.Compression.CompressionMode]::Decompress, $true)
    $shaRestauradoMYG = [Security.Cryptography.SHA256]::Create()
    [long]$bytesRestauradosMYG = 0
    while (($leidosMYG = $descompresorMYG.Read($bufferMYG, 0, $bufferMYG.Length)) -gt 0) {
        $bytesRestauradosMYG += $leidosMYG
        if ($bytesRestauradosMYG -gt $bytesOriginalesMYG) {
            $mensajeSeguro = 'La copia descomprimida supera el tamaño del original.'
            throw $marcaError
        }
        [void]$shaRestauradoMYG.TransformBlock($bufferMYG, 0, $leidosMYG, $bufferMYG, 0)
    }
    [void]$shaRestauradoMYG.TransformFinalBlock([byte[]]@(), 0, 0)
    $huellaRestauradaMYG = ConvertTo-MYGHex $shaRestauradoMYG.Hash
    $descompresorMYG.Dispose()
    $descompresorMYG = $null
    if ($bytesRestauradosMYG -ne $bytesOriginalesMYG -or $huellaRestauradaMYG -ne $huellaOriginalMYG) {
        $mensajeSeguro = 'La copia descomprimida no coincide exactamente con el original.'
        throw $marcaError
    }

    $lectorGzipMYG.Position = 0
    $shaGzipMYG = [Security.Cryptography.SHA256]::Create()
    $huellaGzipMYG = ConvertTo-MYGHex ($shaGzipMYG.ComputeHash($lectorGzipMYG))
    $lectorGzipMYG.Dispose()
    $lectorGzipMYG = $null

    # Releer el original antes de publicar, sin crear un JSON descomprimido.
    $origenMYG.Position = 0
    $shaSegundoMYG = [Security.Cryptography.SHA256]::Create()
    $huellaSegundoMYG = ConvertTo-MYGHex ($shaSegundoMYG.ComputeHash($origenMYG))
    $itemDespuesMYG = Get-Item -LiteralPath $rutaOriginalMYG -Force
    if ($huellaSegundoMYG -ne $huellaOriginalMYG -or
        $origenMYG.Length -ne $longitudAntesMYG -or
        $itemDespuesMYG.Length -ne $longitudAntesMYG -or
        $itemDespuesMYG.LastWriteTimeUtc.Ticks -ne $fechaAntesMYG) {
        $mensajeSeguro = 'El origen cambió. No se publicó la copia y no se sobrescribió el archivo.'
        throw $marcaError
    }

    [double]$ahorroPorcentajeMYG = 0.0
    if ($bytesOriginalesMYG -gt 0) {
        $ahorroPorcentajeMYG = [Math]::Round((1.0 - [double]$bytesGzipMYG / [double]$bytesOriginalesMYG) * 100.0, 4)
    }
    $resultadoMYG = [ordered]@{
        bytes_originales = $bytesOriginalesMYG
        bytes_gzip = $bytesGzipMYG
        ahorro_bytes = $bytesOriginalesMYG - $bytesGzipMYG
        ahorro_porcentaje = $ahorroPorcentajeMYG
        sha256_original = $huellaOriginalMYG
        sha256_descomprimido = $huellaRestauradaMYG
        sha256_gzip = $huellaGzipMYG
        roundtrip_exacto = $true
        original_sin_cambios = $true
    }
    $jsonMYG = ($resultadoMYG | ConvertTo-Json -Depth 3)
    $utf8MYG = [Text.UTF8Encoding]::new($false)
    $informeMYG = [IO.FileStream]::new((Join-Path $temporalMYG 'resultado.json'),
        [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $jsonBytesMYG = $utf8MYG.GetBytes($jsonMYG + [Environment]::NewLine)
        $informeMYG.Write($jsonBytesMYG, 0, $jsonBytesMYG.Length)
        $informeMYG.Flush($true)
    }
    finally { $informeMYG.Dispose() }

    [IO.Directory]::Move($temporalMYG, $destinoMYG)
    $temporalMYG = $null
    $publicadoMYG = $true
    Write-Output $jsonMYG
    Write-Host ('Resultado guardado en: ' + $destinoMYG)
}
catch {
    if ($publicadoMYG) {
        [Console]::Error.WriteLine('La copia y el informe fueron verificados, pero no se pudo mostrar el resultado.')
    }
    elseif ($_.Exception.Message -eq $marcaError) {
        [Console]::Error.WriteLine('Error: ' + $mensajeSeguro)
    }
    else {
        [Console]::Error.WriteLine('Error: no se pudo leer, comprimir o verificar el archivo. El original no se sobrescribió.')
    }
    exit 1
}
finally {
    foreach ($recursoMYG in @($gzipMYG, $salidaMYG, $descompresorMYG, $lectorGzipMYG,
        $origenMYG, $shaOriginalMYG, $shaRestauradoMYG, $shaGzipMYG, $shaSegundoMYG)) {
        if ($null -ne $recursoMYG) {
            try { $recursoMYG.Dispose() } catch { }
        }
    }
    if ($null -ne $temporalMYG -and [IO.Directory]::Exists($temporalMYG)) {
        try { [IO.Directory]::Delete($temporalMYG, $true) } catch { }
    }
}
