﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$Resultados)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$checksMYG = 0
$casosMYG = 0
$herramientaMYG = Join-Path (Split-Path $PSScriptRoot -Parent) 'diagnosticos/Probar-CompresionPaquete.ps1'
$motorMYG = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
$raizMYG = Join-Path ([IO.Path]::GetTempPath()) ('myg-powershell-check-' + [Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($raizMYG)
$localAnteriorMYG = $env:LOCALAPPDATA
$estadoMYG = 'failed'

function Exige-MYG {
    param([bool]$Condicion, [string]$Detalle)
    $script:checksMYG++
    if (-not $Condicion) { throw $Detalle }
}

function Hash-MYG {
    param([byte[]]$Bytes)
    $hashMYG = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hashMYG.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $hashMYG.Dispose() }
}

function Ejecutar-MYG {
    param([string]$Origen, [string]$Destino, [switch]$Automatico)
    $ErrorActionPreference = 'Continue'
    if ($Automatico) {
        $textoMYG = & $motorMYG -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $herramientaMYG -Salida $Destino 2>&1
    }
    else {
        $textoMYG = & $motorMYG -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $herramientaMYG -Archivo $Origen -Salida $Destino 2>&1
    }
    $codigoMYG = $LASTEXITCODE
    return @{ Codigo = $codigoMYG; Texto = ($textoMYG | Out-String) }
}

function Verificar-CopiaMYG {
    param([string]$Origen, [string]$Destino, [byte[]]$Bytes)
    $resultadoMYG = Get-Content -LiteralPath (Join-Path $Destino 'resultado.json') -Raw | ConvertFrom-Json
    Exige-MYG ($resultadoMYG.bytes_originales -eq $Bytes.LongLength) 'Longitud original incorrecta.'
    Exige-MYG ($resultadoMYG.sha256_original -eq (Hash-MYG $Bytes)) 'SHA original incorrecto.'
    Exige-MYG ($resultadoMYG.sha256_original -eq $resultadoMYG.sha256_descomprimido) 'SHA descomprimido distinto.'
    Exige-MYG ($resultadoMYG.roundtrip_exacto -and $resultadoMYG.original_sin_cambios) 'Falta confirmación de integridad.'
    Exige-MYG ((Hash-MYG ([IO.File]::ReadAllBytes($Origen))) -eq (Hash-MYG $Bytes)) 'Se alteró el origen.'
    $copiaMYG = Join-Path $Destino 'copia.gz'
    Exige-MYG ((Get-Item -LiteralPath $copiaMYG).Length -eq $resultadoMYG.bytes_gzip) 'Longitud Gzip incorrecta.'
    $entradaMYG = [IO.File]::OpenRead($copiaMYG)
    $gzipMYG = [IO.Compression.GZipStream]::new($entradaMYG, [IO.Compression.CompressionMode]::Decompress)
    $memoriaMYG = [IO.MemoryStream]::new()
    try {
        $gzipMYG.CopyTo($memoriaMYG)
        $restauradosMYG = $memoriaMYG.ToArray()
        Exige-MYG ($restauradosMYG.LongLength -eq $Bytes.LongLength -and
            (Hash-MYG $restauradosMYG) -eq (Hash-MYG $Bytes)) 'La verificación independiente no coincide.'
    }
    finally { $gzipMYG.Dispose(); $entradaMYG.Dispose(); $memoriaMYG.Dispose() }
    $nombresMYG = @(Get-ChildItem -LiteralPath $Destino -Force | Select-Object -ExpandProperty Name | Sort-Object)
    Exige-MYG ($nombresMYG.Count -eq 2 -and $nombresMYG[0] -eq 'copia.gz' -and $nombresMYG[1] -eq 'resultado.json') 'Archivos de salida inesperados.'
    Exige-MYG (@($resultadoMYG.PSObject.Properties).Count -eq 9) 'Campos de informe inesperados.'
}

try {
    $casosDatosMYG = @(
        @{ Nombre = 'unicode'; Bytes = [Text.Encoding]::UTF8.GetBytes(('Áncash 漢字 "comillas" C:\obra\hoja' + "`r`n") * 200) },
        @{ Nombre = 'binario_grande'; Bytes = (New-Object byte[] (1024 * 1024 + 17)) },
        @{ Nombre = 'vacio'; Bytes = [byte[]]@() }
    )
    $aleatorioMYG = [Random]::new(48317)
    $aleatorioMYG.NextBytes($casosDatosMYG[1].Bytes)
    foreach ($casoMYG in $casosDatosMYG) {
        $origenMYG = Join-Path $raizMYG ($casoMYG.Nombre + '.json')
        $destinoMYG = Join-Path $raizMYG ($casoMYG.Nombre + '-resultado')
        [IO.File]::WriteAllBytes($origenMYG, $casoMYG.Bytes)
        $salidaMYG = Ejecutar-MYG $origenMYG $destinoMYG
        Exige-MYG ($salidaMYG.Codigo -eq 0) ('Falló caso ' + $casoMYG.Nombre + ': ' + $salidaMYG.Texto)
        Verificar-CopiaMYG $origenMYG $destinoMYG $casoMYG.Bytes
        $casosMYG++
    }

    $textoPrivadoMYG = 'SENTINELA_PRIVADA_NO_DEBE_APARECER'
    $origenPrivadoMYG = Join-Path $raizMYG ($textoPrivadoMYG + '.json')
    $bytesPrivadosMYG = [Text.Encoding]::UTF8.GetBytes('{"dato":"' + $textoPrivadoMYG + '"}')
    [IO.File]::WriteAllBytes($origenPrivadoMYG, $bytesPrivadosMYG)
    $destinoPrivadoMYG = Join-Path $raizMYG 'privacidad'
    $salidaPrivadaMYG = Ejecutar-MYG $origenPrivadoMYG $destinoPrivadoMYG
    Exige-MYG ($salidaPrivadaMYG.Codigo -eq 0) 'Falló caso de privacidad.'
    $jsonPrivadoMYG = Get-Content -LiteralPath (Join-Path $destinoPrivadoMYG 'resultado.json') -Raw
    Exige-MYG (-not $jsonPrivadoMYG.Contains($textoPrivadoMYG) -and -not $jsonPrivadoMYG.Contains($raizMYG)) 'Informe reveló datos o rutas.'
    $casosMYG++

    $sentinelaMYG = Join-Path $destinoPrivadoMYG 'conservar.txt'
    [IO.File]::WriteAllText($sentinelaMYG, 'conservar')
    $rechazoMYG = Ejecutar-MYG $origenPrivadoMYG $destinoPrivadoMYG
    Exige-MYG ($rechazoMYG.Codigo -ne 0) 'Se aceptó un destino existente.'
    Exige-MYG ([IO.File]::ReadAllText($sentinelaMYG) -eq 'conservar') 'Se sobrescribió un archivo previo.'
    Exige-MYG ((Hash-MYG ([IO.File]::ReadAllBytes($origenPrivadoMYG))) -eq (Hash-MYG $bytesPrivadosMYG)) 'Se alteró el origen tras el rechazo.'
    $casosMYG++

    $destinoAusenteMYG = Join-Path $raizMYG 'no-publicar'
    $rechazoMYG = Ejecutar-MYG (Join-Path $raizMYG 'no-existe.json') $destinoAusenteMYG
    Exige-MYG ($rechazoMYG.Codigo -ne 0 -and -not (Test-Path -LiteralPath $destinoAusenteMYG)) 'Se publicó salida sin origen.'
    Exige-MYG (-not $rechazoMYG.Texto.Contains($raizMYG)) 'El error expuso la ruta privada.'
    $casosMYG++

    $env:LOCALAPPDATA = Join-Path $raizMYG 'localdata'
    $carpetaMYG = Join-Path (Join-Path (Join-Path (Join-Path $env:LOCALAPPDATA 'MYG') 'Nube') 'trabajo') 'publicaciones'
    [void][IO.Directory]::CreateDirectory($carpetaMYG)
    $destinoAutoMYG = Join-Path $raizMYG 'auto-ninguno'
    $rechazoMYG = Ejecutar-MYG '' $destinoAutoMYG -Automatico
    Exige-MYG ($rechazoMYG.Codigo -ne 0 -and -not (Test-Path -LiteralPath $destinoAutoMYG)) 'Se eligió un origen inexistente automáticamente.'
    $casosMYG++

    $unicoMYG = Join-Path $carpetaMYG 'unico.json'
    [IO.File]::WriteAllBytes($unicoMYG, $bytesPrivadosMYG)
    $destinoAutoMYG = Join-Path $raizMYG 'auto-unico'
    $salidaAutoMYG = Ejecutar-MYG '' $destinoAutoMYG -Automatico
    Exige-MYG ($salidaAutoMYG.Codigo -eq 0) ('Falló autodetección: ' + $salidaAutoMYG.Texto)
    Verificar-CopiaMYG $unicoMYG $destinoAutoMYG $bytesPrivadosMYG
    $casosMYG++

    # Comprobar la resolución relativa de PowerShell incluso si el CWD de .NET
    # es distinto. Restaurar ambos directorios al terminar este caso.
    $ubicacionAntesMYG = Get-Location
    $directorioNetAntesMYG = [Environment]::CurrentDirectory
    try {
        Set-Location -LiteralPath $raizMYG
        [Environment]::CurrentDirectory = [IO.Path]::GetTempPath()
        $salidaRelativaMYG = & $herramientaMYG -Archivo $unicoMYG -Salida 'salida-relativa'
        $destinoRelativoMYG = Join-Path $raizMYG 'salida-relativa'
        Exige-MYG (Test-Path -LiteralPath (Join-Path $destinoRelativoMYG 'resultado.json')) 'La salida relativa usó otro directorio.'
        Verificar-CopiaMYG $unicoMYG $destinoRelativoMYG $bytesPrivadosMYG
    }
    finally {
        [Environment]::CurrentDirectory = $directorioNetAntesMYG
        Set-Location -LiteralPath $ubicacionAntesMYG.Path
    }
    $casosMYG++

    # El runtime de pruebas debe disponer de un Escritorio. En Linux se prepara
    # mediante XDG antes de ejecutar este runner; en Windows se usa el normal.
    $escritorioPruebasMYG = [Environment]::GetFolderPath([Environment+SpecialFolder]::Desktop)
    Exige-MYG (-not [string]::IsNullOrWhiteSpace($escritorioPruebasMYG) -and
        [IO.Directory]::Exists($escritorioPruebasMYG)) 'Prepare un Escritorio para comprobar el modo sin argumentos.'
    $previosDesktopMYG = @(Get-ChildItem -LiteralPath $escritorioPruebasMYG -Directory -Filter 'MYG_Compresion_*' | Select-Object -ExpandProperty FullName)
    $textoDefaultMYG = & $motorMYG -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $herramientaMYG 2>&1
    Exige-MYG ($LASTEXITCODE -eq 0) ('Falló modo sin argumentos: ' + ($textoDefaultMYG | Out-String))
    $nuevosDesktopMYG = @(Get-ChildItem -LiteralPath $escritorioPruebasMYG -Directory -Filter 'MYG_Compresion_*' |
        Where-Object { $previosDesktopMYG -notcontains $_.FullName } | Select-Object -ExpandProperty FullName)
    Exige-MYG ($nuevosDesktopMYG.Count -eq 1) 'No se pudo identificar una única salida del modo automático.'
    Verificar-CopiaMYG $unicoMYG $nuevosDesktopMYG[0] $bytesPrivadosMYG
    [IO.Directory]::Delete($nuevosDesktopMYG[0], $true)
    $casosMYG++

    [IO.File]::WriteAllText((Join-Path $carpetaMYG 'otro.json'), '{}')
    $destinoAutoMYG = Join-Path $raizMYG 'auto-ambiguo'
    $rechazoMYG = Ejecutar-MYG '' $destinoAutoMYG -Automatico
    Exige-MYG ($rechazoMYG.Codigo -ne 0 -and -not (Test-Path -LiteralPath $destinoAutoMYG)) 'Se eligió arbitrariamente entre varios pendientes.'
    $casosMYG++
    Exige-MYG (@(Get-ChildItem -LiteralPath $raizMYG -Force -Filter '.myg-compresion-*').Count -eq 0) 'Quedaron temporales de compresión.'
    $estadoMYG = 'passed'
}
finally {
    $env:LOCALAPPDATA = $localAnteriorMYG
    $registroMYG = [ordered]@{ status = $estadoMYG; cases = $casosMYG; checks = $checksMYG;
        powershell_version = $PSVersionTable.PSVersion.ToString();
        scope = 'Fixtures nuevos locales; PowerShell nativo, sin Python, red, GUI ni Supabase real.' }
    if (-not [string]::IsNullOrWhiteSpace($Resultados)) {
        [void][IO.Directory]::CreateDirectory($Resultados)
        [IO.File]::WriteAllText((Join-Path $Resultados 'results.json'),
            ($registroMYG | ConvertTo-Json -Depth 3), [Text.UTF8Encoding]::new($false))
    }
    Write-Output ($registroMYG | ConvertTo-Json -Depth 3)
    if ([IO.Directory]::Exists($raizMYG)) { [IO.Directory]::Delete($raizMYG, $true) }
}
