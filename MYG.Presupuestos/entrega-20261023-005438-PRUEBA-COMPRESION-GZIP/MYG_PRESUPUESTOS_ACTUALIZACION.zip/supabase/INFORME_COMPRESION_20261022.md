# Prueba de compresión del paquete de Nube MYG

## Resultado y alcance

Se probó Gzip sin pérdida sobre paquetes sintéticos existentes. La compresión
reduce mucho su tamaño físico y la descompresión conservó exactamente los bytes.
No se dispone del archivo privado de 200,1 MiB, por lo que no se presenta un
porcentaje de ahorro para ese archivo ni se promete que Nano pueda publicarlo.

Se reutilizan las mediciones ya realizadas, sin volver a comprimir esos fixtures:

| Paquete sintético existente | JSON original | Gzip nivel 6 | Ahorro |
|---|---:|---:|---:|
| Compacto v2 | 182.439 bytes | 36.962 bytes | 79,74 % |
| El mismo ejemplo expandido | 433.384 bytes | 43.995 bytes | 89,85 % |

Estas cifras corresponden a paquetes pequeños con estructura de MYG, no a un
campo artificial de 200 MiB formado por caracteres repetidos. No se extrapolan
al SQLite Delphin del usuario ni al POST final de su pendiente.

## Por qué comprimir el archivo local no cambia automáticamente el POST

El cliente actual lee el pendiente y construye de nuevo el JSON de
`p_contenido`. Si el archivo se guarda como Gzip y se descomprime antes de ese
paso, el JSON que recibe PostgreSQL mantiene su tamaño lógico. Reducir el espacio
en disco no elimina el coste de convertir ese JSON a JSONB.

El formato compacto v2 existente ya evita copias del documento principal,
referencia documentos equivalentes y usa un diccionario para textos repetidos.
Recompactar un pendiente v2 no aporta por sí solo un ahorro nuevo. Cambiar el
contenido de un intento ya enviado conservando silenciosamente su UUID tampoco
es seguro: el servidor verifica su igualdad con la creación original.

## Prueba nueva del envío HTTP comprimido

Se hizo una prueba aislada, con PostgreSQL 17.11 y PostgREST 16.5, usando las mismas
imágenes fijadas en los ensayos anteriores. Solo se enviaron dos POST pequeños a
una RPC sintética; no se utilizó Supabase real, proyectos privados ni claves.

| Petición | Bytes enviados | Resultado |
|---|---:|---|
| JSON normal, Unicode y comillas | 73 | HTTP 200; datos recibidos correctamente. |
| El mismo JSON con Gzip y `Content-Encoding: gzip` | 94 | HTTP 400 / `PGRST102`: `Empty or invalid json`. |

El cuerpo de la RPC se ejecutó una sola vez: la petición Gzip se rechazó antes.
En un texto tan pequeño, la cabecera Gzip ocupa más que el ahorro de compresión;
esta prueba comprueba compatibilidad, no ratio ni capacidad máxima.

No se ha comprobado si una pasarela particular de Supabase descomprimiría esa
petición antes de PostgREST. Incluso si lo hiciera, PostgreSQL seguiría recibiendo
el JSON expandido. Por eso no se activa una cabecera Gzip en el cliente como
supuesto arreglo de los HTTP 502/520.

El primer intento del instrumento falló al consultar un puerto que la red Docker
interna no publicaba, antes de enviar ninguna petición HTTP. Se corrigió para
usar la dirección interna, como los ensayos anteriores; únicamente el intento
corregido se considera evidencia. No se repitieron los benchmarks grandes.

## Compresión y almacenamiento en la nube

PostgreSQL puede comprimir físicamente datos mediante TOAST, pero eso no evita
que antes tenga que interpretar el JSON completo. El tamaño físico de una tabla
no es una medición del JSON de entrada ni de la RAM necesaria para procesarlo.

Guardar el proyecto como archivo comprimido privado en Storage es otro contrato.
El actual usa Storage para adjuntos, con un límite de 20 MiB por archivo, y sigue
necesitando el contenido JSON para validación, permisos por módulo,
sincronización, comparación de reintentos e historial. Sustituirlo directamente
por una referencia a un ZIP rompería esas operaciones.

Para reducir de verdad la carga sobre PostgreSQL habría que diseñar publicación
por bloques o snapshots comprimidos con sus metadatos, recuperación e historial,
manteniendo la autorización de módulos y la compatibilidad con proyectos
existentes. Esta prueba no instala ese protocolo ni elimina funciones actuales.

## Medir el pendiente real sin modificarlo

Se incluye una herramienta local que crea **una copia comprimida**, comprueba su
descompresión por longitud y SHA-256, y genera un informe numérico. Trabaja por
streaming para no cargar el paquete completo en RAM. No altera el SQLite, el
pendiente ni su UUID; no publica archivos ni solicita credenciales.

Requiere Python 3. El archivo activo del pendiente está normalmente en:

```text
%LOCALAPPDATA%\MYG\Nube\trabajo\publicaciones\
```

Hay un archivo `.json` por cuenta y servidor; no seleccionar los archivos
`.lock` ni los de la carpeta `retiradas`. Elegir el `.json` cuyo tamaño corresponda
al pendiente de unos 200,1 MiB. Hacer la medición sin una publicación en curso.

En PowerShell, desde la carpeta del repositorio, se pueden listar las rutas:

```powershell
Get-ChildItem "$env:LOCALAPPDATA\MYG\Nube\trabajo\publicaciones" -Filter *.json |
    Select-Object FullName, LastWriteTime, @{Name='MiB';Expression={[math]::Round($_.Length / 1MB, 1)}}
```

Después, sustituir la ruta de ejemplo por la del `.json` elegido y ejecutar:

```powershell
py -3 scripts\diagnosticos\Probar-CompresionPaquete.py --archivo "C:\RUTA\AL\PENDIENTE.json" --salida "$([Environment]::GetFolderPath('Desktop'))\MYG_Compresion_01"
```

La carpeta de salida debe ser nueva y su carpeta padre debe existir; si ya se
usó `MYG_Compresion_01`, elegir otro nombre. El resultado contiene:

- `copia.gz`: copia privada comprimida y verificada del archivo elegido.
- `resultado.json`: tamaños, ahorro, SHA-256 y las confirmaciones
  `roundtrip_exacto` y `original_sin_cambios`. No incluye contenido de la obra,
  nombres de proyectos ni credenciales.

Para revisar el ahorro del paquete real basta compartir `resultado.json` o sus
campos `bytes_originales`, `bytes_gzip`, `ahorro_porcentaje` y `roundtrip_exacto`.

Conservar el `.gz` como copia local. **No sustituir manualmente el pendiente
activo por ese archivo ni subirlo como si fuera un proyecto compatible con el
contrato actual.** El informe de tamaños es suficiente para analizar el ahorro;
no hace falta compartir el archivo con datos de la obra.

## Validación y estado del problema

La herramienta superó **13 pruebas focales** con archivos pequeños nuevos:
Unicode, comillas y controles, datos binarios y vacío; verificación de longitud
y SHA-256; privacidad del informe y cabecera Gzip; destino existente; cambios
concurrentes del origen o destino; Gzip truncado y limpieza de una publicación
parcial ante un fallo simulado. No hubo fallos, errores ni pruebas omitidas.

```bash
PYTHONDONTWRITEBYTECODE=1 python3 scripts/pruebas/ProbarCompresionPaqueteCheck.py
```

Se ejecutaron en Linux con Python estándar; no se afirma haber ejecutado la
interfaz Windows. El ensayo HTTP nuevo pasó con las dos respuestas esperadas y
se eliminaron los contenedores de prueba. No se recompiló MYG ni se repitieron
los benchmarks de 200 MiB.

No se modifican los archivos del cliente de producción, las funciones RPC ni la
instalación del parche 27. Se conservan las verificaciones anteriores de 55006,
integridad, recuperación y límites. Los HTTP 502/520 reales y el motivo de las
interrupciones de PostgreSQL siguen sin identificarse: comprimir una copia no
los considera resueltos.

## Qué hacer con cada archivo

| Archivo | Acción |
|---|---|
| `scripts/diagnosticos/Probar-CompresionPaquete.py` | Añadir. Ejecutar localmente con el pendiente real para crear su copia y medir el ahorro. |
| `scripts/pruebas/ProbarCompresionPaqueteCheck.py` | Añadir. Solo pruebas de desarrollo; no hace falta ejecutarlo para usar la herramienta. |
| `scripts/pruebas/Probar-GzipPostgrestHTTP.py` | Añadir. Solo prueba de desarrollo con Docker desechable; no se ejecuta en Supabase real. |
| `supabase/diagnosticos/RESULTADOS_COMPRESION_20261022.json` | Añadir y leer; resultados de laboratorio, no se ejecuta. |
| `supabase/INFORME_COMPRESION_20261022.md` | Añadir y leer estas instrucciones. |

Copiar desde la raíz del ZIP a la carpeta de la solución conservando las rutas.
Todos son archivos nuevos: no reemplazan archivos de las entregas anteriores.
No hay SQL que instalar ni una nueva versión del ejecutable en esta entrega.
Para conservarlos en `MYG.Presupuestos`, revisar en Git y hacer Commit y Push en
la rama elegida junto con los cambios previos que correspondan. Publicar la
descarga en `DESCARGAS` no actualiza el repositorio de código.
