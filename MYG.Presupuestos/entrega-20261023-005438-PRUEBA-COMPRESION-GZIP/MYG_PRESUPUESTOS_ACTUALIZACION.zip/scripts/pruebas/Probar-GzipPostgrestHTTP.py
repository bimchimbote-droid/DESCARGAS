#!/usr/bin/env python3
"""Prueba solo la aceptación de JSON Gzip en PostgREST desechable.

No usa Supabase real, claves privadas, archivos de obras ni cargas grandes.
Compara dos POST pequeños con los mismos datos: JSON y Content-Encoding:gzip.
"""
import argparse
import gzip
import json
from pathlib import Path
import signal
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid

POSTGRES = 'postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
POSTGREST = 'postgrest/postgrest:v16.5@sha256:1347d7552b88f17832912c06afbf7c43209af6eeeb60834b04aae12c9bd9d5cc'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resultados', type=Path)
    args = parser.parse_args()
    output = args.resultados or Path(tempfile.mkdtemp(prefix='myg-gzip-http-'))
    output.mkdir(parents=True, exist_ok=True)
    if (output / 'results.json').exists():
        raise FileExistsError('El directorio ya contiene resultados; use otro.')
    suffix = uuid.uuid4().hex[:12]
    network, database, api = ('myg-gzip-' + suffix + '-' + part for part in ('red', 'pg', 'api'))
    created, network_created = [], False
    result = {'status': 'running', 'scope': 'Dos POST sintéticos pequeños; sin datos privados ni Supabase real.',
              'postgresql_image': POSTGRES, 'postgrest_image': POSTGREST, 'requests': []}
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def stop(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)

    with (output / 'ejecucion.log').open('w') as log:
        def run(*command, check=True):
            proc = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(proc.stdout)
            log.flush()
            if check and proc.returncode:
                raise RuntimeError(command[0] + ' falló: ' + proc.stdout[-1600:])
            return proc

        def sql(query):
            return run('docker', 'exec', '-u', 'postgres', database, 'psql', '-X', '-qAt',
                       '-v', 'ON_ERROR_STOP=1', '-c', query).stdout.strip()

        try:
            for image in (POSTGRES, POSTGREST):
                if run('docker', 'image', 'inspect', image, check=False).returncode:
                    run('docker', 'pull', image)
            run('docker', 'network', 'create', '--internal', network)
            network_created = True
            run('docker', 'run', '--detach', '--rm', '--name', database, '--network', network,
                '--memory=512m', '--memory-swap=512m', '--cpus=1',
                '--tmpfs', '/var/lib/postgresql/data:rw,size=128m',
                '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', POSTGRES,
                '-c', 'shared_buffers=32MB', '-c', 'work_mem=1MB', '-c', 'max_connections=20')
            created.append(database)
            for _attempt in range(60):
                if run('docker', 'exec', database, 'pg_isready', '-U', 'postgres', check=False).returncode == 0:
                    break
                time.sleep(0.2)
            else:
                raise RuntimeError('PostgreSQL de prueba no inició.')
            sql("""
                create role myg_gzip_anon nologin;
                create table public.myg_gzip_entradas(bytes_json integer not null);
                create function public.myg_gzip_control(p_contenido jsonb) returns jsonb
                language plpgsql security definer set search_path=pg_catalog as $$
                begin
                    insert into public.myg_gzip_entradas values (octet_length(p_contenido::text));
                    return jsonb_build_object('recibido',p_contenido->>'prueba');
                end $$;
                revoke all on function public.myg_gzip_control(jsonb) from public;
                grant usage on schema public to myg_gzip_anon;
                grant execute on function public.myg_gzip_control(jsonb) to myg_gzip_anon;
            """)
            run('docker', 'run', '--detach', '--rm', '--name', api, '--network', network,
                '--memory=256m', '--memory-swap=256m', '--cpus=1',
                '-e', 'PGRST_DB_URI=postgres://postgres@' + database + ':5432/postgres',
                '-e', 'PGRST_DB_SCHEMAS=public', '-e', 'PGRST_DB_ANON_ROLE=myg_gzip_anon',
                POSTGREST)
            created.append(api)
            # La red interna de este laboratorio no publica puertos en el host.
            # Usar la dirección del contenedor, igual que los ensayos anteriores.
            address = run('docker', 'inspect', api, '--format',
                          '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}').stdout.strip()
            base = 'http://' + address + ':3000'
            for _attempt in range(60):
                try:
                    with opener.open(base + '/', timeout=2) as response:
                        if response.status == 200:
                            break
                except (urllib.error.URLError, OSError):
                    pass
                time.sleep(0.2)
            else:
                raise RuntimeError('PostgREST de prueba no inició.')
            body = json.dumps({'p_contenido': {'prueba': 'Unicode Áncash 漢字 y comillas " exactas'}},
                              ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            for label, payload, encoding in (('json', body, None), ('gzip', gzip.compress(body, mtime=0), 'gzip')):
                headers = {'Content-Type': 'application/json'}
                if encoding:
                    headers['Content-Encoding'] = encoding
                request = urllib.request.Request(base + '/rpc/myg_gzip_control', data=payload, headers=headers)
                started = time.monotonic()
                try:
                    with opener.open(request, timeout=10) as response:
                        status, raw = response.status, response.read(8192)
                except urllib.error.HTTPError as error:
                    status, raw = error.code, error.read(8192)
                parsed = json.loads(raw)
                result['requests'].append({'encoding': label, 'request_bytes': len(payload),
                                           'http_status': status, 'response': parsed,
                                           'seconds': round(time.monotonic() - started, 6)})
            plain, zipped = result['requests']
            assert plain['http_status'] == 200 and plain['response']['recibido'] == 'Unicode Áncash 漢字 y comillas " exactas'
            assert zipped['http_status'] == 400 and zipped['response'].get('code') == 'PGRST102', \
                'El comportamiento Gzip de esta versión cambió; revisar antes de concluir.'
            assert sql('select count(*) from public.myg_gzip_entradas;') == '1'
            result['rpc_body_entries'] = 1
            result['gzip_request_supported'] = False
            result['postgresql_version'] = sql('show server_version;')
            result['status'] = 'passed'
        except BaseException as error:
            result['status'] = 'failed'
            result['error'] = str(error)
            raise
        finally:
            for name in reversed(created):
                (output / (('postgrest' if name == api else 'postgres') + '.log')).write_text(
                    run('docker', 'logs', name, check=False).stdout)
                run('docker', 'rm', '-f', name, check=False)
            if network_created:
                run('docker', 'network', 'rm', network, check=False)
            (output / 'results.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
            print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
