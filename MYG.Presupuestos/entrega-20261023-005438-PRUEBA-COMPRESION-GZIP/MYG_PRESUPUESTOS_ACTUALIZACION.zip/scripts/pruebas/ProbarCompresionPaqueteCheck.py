#!/usr/bin/env python3
"""Pruebas pequenas del compresor local, sin red, Supabase ni datos de obras."""

import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


sys.dont_write_bytecode = True
HERRAMIENTA = Path(__file__).resolve().parents[1] / "diagnosticos" / "Probar-CompresionPaquete.py"
ESPECIFICACION = importlib.util.spec_from_file_location("myg_compresion_paquete_pruebas", HERRAMIENTA)
if ESPECIFICACION is None or ESPECIFICACION.loader is None:
    raise RuntimeError("No se pudo localizar la herramienta de compresion.")
COMPRESOR = importlib.util.module_from_spec(ESPECIFICACION)
sys.modules[ESPECIFICACION.name] = COMPRESOR
ESPECIFICACION.loader.exec_module(COMPRESOR)


class CompresionPaqueteCheck(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory(prefix="myg-compresion-pruebas-")
        self.addCleanup(self.temporal.cleanup)
        self.raiz = Path(self.temporal.name)

    def escribir(self, contenido, nombre="origen_sintetico.json"):
        origen = self.raiz / nombre
        origen.write_bytes(contenido)
        return origen

    def exigir_original(self, origen, contenido):
        self.assertEqual(origen.read_bytes(), contenido)
        self.assertEqual(hashlib.sha256(origen.read_bytes()).hexdigest(), hashlib.sha256(contenido).hexdigest())

    def exigir_sin_temporales(self, entradas):
        self.assertEqual({p.name for p in self.raiz.iterdir()}, set(entradas))

    def exigir_resultado(self, salida, original, resultado):
        self.assertEqual({p.name for p in salida.iterdir()}, {"copia.gz", "resultado.json"})
        self.assertEqual(json.loads((salida / "resultado.json").read_text(encoding="utf-8")), resultado)
        comprimido = (salida / "copia.gz").read_bytes()
        restaurado = gzip.decompress(comprimido)
        self.assertEqual(restaurado, original)
        self.assertEqual(resultado["bytes_originales"], len(original))
        self.assertEqual(resultado["bytes_gzip"], len(comprimido))
        self.assertEqual(resultado["ahorro_bytes"], len(original) - len(comprimido))
        self.assertEqual(resultado["sha256_original"], hashlib.sha256(original).hexdigest())
        self.assertEqual(resultado["sha256_descomprimido"], hashlib.sha256(restaurado).hexdigest())
        self.assertEqual(resultado["sha256_gzip"], hashlib.sha256(comprimido).hexdigest())
        self.assertIs(resultado["roundtrip_exacto"], True)
        self.assertIs(resultado["original_sin_cambios"], True)
        self.assertEqual(set(resultado), {
            "bytes_originales", "bytes_gzip", "ahorro_bytes", "ahorro_porcentaje",
            "sha256_original", "sha256_descomprimido", "sha256_gzip",
            "roundtrip_exacto", "original_sin_cambios",
        })
        # El gzip no debe conservar el nombre ni la fecha del archivo original.
        self.assertEqual(comprimido[:3], b"\x1f\x8b\x08")
        self.assertEqual(comprimido[3] & 8, 0)
        self.assertEqual(comprimido[4:8], bytes(4))

    def test_unicode_comillas_controles_y_privacidad_del_informe(self):
        secreto = "NOMBRE_OBRA_PRIVADA_NO_PUBLICAR"
        contenido = json.dumps({
            "Id": secreto,
            "filas": [{"texto": "Ancash \u6f22\u5b57 \U0001f3d7 \"cita\" C:\\obra\\hoja", "control": "\x01\r\n\t"}] * 25,
        }, ensure_ascii=False).encode("utf-8")
        origen = self.escribir(contenido, secreto + ".json")
        antes = origen.stat()
        salida = self.raiz / "salida"
        resultado = COMPRESOR.probar_compresion(origen, salida)
        self.exigir_resultado(salida, contenido, resultado)
        self.exigir_original(origen, contenido)
        self.assertEqual(origen.stat().st_mtime_ns, antes.st_mtime_ns)
        self.assertNotIn(secreto, (salida / "resultado.json").read_text())
        self.assertGreater(resultado["ahorro_porcentaje"], 0)
        self.exigir_sin_temporales({origen.name, salida.name})

    def test_binario_cualquier_byte_se_conserva(self):
        contenido = bytes(range(256)) * 7 + hashlib.sha256(b"fixture binario nuevo").digest()
        origen = self.escribir(contenido, "entrada.bin")
        salida = self.raiz / "salida_binaria"
        resultado = COMPRESOR.probar_compresion(origen, salida)
        self.exigir_resultado(salida, contenido, resultado)
        self.exigir_original(origen, contenido)

    def test_archivo_vacio_no_divide_por_cero(self):
        origen = self.escribir(b"")
        salida = self.raiz / "salida_vacia"
        resultado = COMPRESOR.probar_compresion(origen, salida)
        self.exigir_resultado(salida, b"", resultado)
        self.assertGreater(resultado["bytes_gzip"], 0)
        self.assertIsInstance(resultado["ahorro_porcentaje"], (int, float))

    def test_no_sobrescribe_salida_existente_vacia_con_datos_o_archivo(self):
        contenido = b"origen intacto"
        origen = self.escribir(contenido)
        for tipo in ("directorio_vacio", "directorio_con_datos", "archivo"):
            with self.subTest(tipo=tipo):
                salida = self.raiz / tipo
                if tipo == "archivo":
                    salida.write_bytes(b"archivo ajeno")
                else:
                    salida.mkdir()
                    if tipo == "directorio_con_datos":
                        (salida / "sentinela.txt").write_bytes(b"dato ajeno")
                entradas = {p.name for p in self.raiz.iterdir()}
                with self.assertRaises(COMPRESOR.CompresionError):
                    COMPRESOR.probar_compresion(origen, salida)
                self.exigir_original(origen, contenido)
                if tipo == "archivo":
                    self.assertEqual(salida.read_bytes(), b"archivo ajeno")
                elif tipo == "directorio_con_datos":
                    self.assertEqual({p.name for p in salida.iterdir()}, {"sentinela.txt"})
                    self.assertEqual((salida / "sentinela.txt").read_bytes(), b"dato ajeno")
                else:
                    self.assertEqual(list(salida.iterdir()), [])
                self.exigir_sin_temporales(entradas)

    def test_origen_igual_salida_se_rechaza_sin_reescribir(self):
        contenido = b"el origen no es una carpeta de salida"
        origen = self.escribir(contenido)
        with self.assertRaises(COMPRESOR.CompresionError):
            COMPRESOR.probar_compresion(origen, origen)
        self.exigir_original(origen, contenido)
        self.exigir_sin_temporales({origen.name})

    def test_origen_directorio_se_rechaza(self):
        origen = self.raiz / "no_es_archivo"
        origen.mkdir()
        with self.assertRaises(COMPRESOR.CompresionError):
            COMPRESOR.probar_compresion(origen, self.raiz / "salida")
        self.exigir_sin_temporales({origen.name})

    def test_gzip_truncado_no_publica_resultados(self):
        contenido = b"integridad nueva antes de publicar\n" * 30
        origen = self.escribir(contenido)
        salida = self.raiz / "salida"
        verificar = COMPRESOR._verificar_gzip

        def truncar(archivo, *args, **kwargs):
            archivo = Path(archivo)
            archivo.write_bytes(archivo.read_bytes()[:-5])
            return verificar(archivo, *args, **kwargs)

        with mock.patch.object(COMPRESOR, "_verificar_gzip", side_effect=truncar):
            with self.assertRaises(COMPRESOR.CompresionError):
                COMPRESOR.probar_compresion(origen, salida)
        self.assertFalse(salida.exists())
        self.exigir_original(origen, contenido)
        self.exigir_sin_temporales({origen.name})

    def test_error_al_publicar_informe_retira_la_copia_parcial(self):
        contenido = b"entrada sintetica para error de publicacion"
        origen = self.escribir(contenido)
        salida = self.raiz / "salida"
        reemplazar = COMPRESOR.os.replace
        publicados = []

        def fallar_informe(desde, hacia, *args, **kwargs):
            nombre = Path(hacia).name
            publicados.append(nombre)
            if nombre == "resultado.json":
                raise OSError("ruta_privada_sintetica_no_mostrar")
            return reemplazar(desde, hacia, *args, **kwargs)

        with mock.patch.object(COMPRESOR.os, "replace", side_effect=fallar_informe):
            with self.assertRaises(COMPRESOR.CompresionError) as error:
                COMPRESOR.probar_compresion(origen, salida)
        self.assertIn("copia.gz", publicados)
        self.assertNotIn("ruta_privada_sintetica_no_mostrar", str(error.exception))
        self.assertFalse(salida.exists())
        self.exigir_original(origen, contenido)
        self.exigir_sin_temporales({origen.name})

    def test_salida_creada_durante_la_lectura_no_se_sobrescribe(self):
        contenido = b"lectura concurrente sintetica"
        origen = self.escribir(contenido)
        salida = self.raiz / "salida"
        verificar = COMPRESOR._verificar_gzip

        def crear_salida(*args, **kwargs):
            resultado = verificar(*args, **kwargs)
            salida.mkdir()
            (salida / "otro_usuario.txt").write_bytes(b"no sobrescribir")
            return resultado

        with mock.patch.object(COMPRESOR, "_verificar_gzip", side_effect=crear_salida):
            with self.assertRaises(COMPRESOR.CompresionError):
                COMPRESOR.probar_compresion(origen, salida)
        self.assertEqual({p.name for p in salida.iterdir()}, {"otro_usuario.txt"})
        self.assertEqual((salida / "otro_usuario.txt").read_bytes(), b"no sobrescribir")
        self.exigir_original(origen, contenido)
        self.exigir_sin_temporales({origen.name, salida.name})

    def test_cambio_externo_del_origen_se_detecta_antes_de_publicar(self):
        contenido = b"entrada antes del cambio"
        origen = self.escribir(contenido)
        salida = self.raiz / "salida"
        verificar = COMPRESOR._verificar_gzip
        cambio = b" cambio externo simulado por la prueba"

        def modificar_origen(*args, **kwargs):
            resultado = verificar(*args, **kwargs)
            with origen.open("ab") as archivo:
                archivo.write(cambio)
            return resultado

        with mock.patch.object(COMPRESOR, "_verificar_gzip", side_effect=modificar_origen):
            with self.assertRaises(COMPRESOR.CompresionError):
                COMPRESOR.probar_compresion(origen, salida)
        self.assertFalse(salida.exists())
        self.assertEqual(origen.read_bytes(), contenido + cambio)
        self.exigir_sin_temporales({origen.name})

    def ejecutar_cli(self, *argumentos):
        entorno = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        return subprocess.run([sys.executable, str(HERRAMIENTA), *map(str, argumentos)],
                              capture_output=True, text=True, env=entorno, check=False)

    def test_cli_exige_ambos_argumentos(self):
        origen = self.escribir(b"argumentos nuevos")
        for argumentos in ((), ("--archivo", origen)):
            with self.subTest(argumentos=bool(argumentos)):
                proceso = self.ejecutar_cli(*argumentos)
                self.assertNotEqual(proceso.returncode, 0)
                self.assertNotIn(origen.name, proceso.stdout + proceso.stderr)
        self.exigir_sin_temporales({origen.name})

    def test_cli_argumento_invalido_no_revela_su_valor(self):
        origen = self.escribir(b"privacidad de errores CLI")
        salida = self.raiz / "salida"
        secreto = "token_privado_sintetico_no_mostrar"
        proceso = self.ejecutar_cli("--archivo", origen, "--salida", salida, "--invalido", secreto)
        self.assertNotEqual(proceso.returncode, 0)
        self.assertNotIn(secreto, proceso.stdout + proceso.stderr)
        self.assertNotIn(origen.name, proceso.stdout + proceso.stderr)
        self.assertFalse(salida.exists())
        self.exigir_sin_temporales({origen.name})

    def test_cli_correcta_solo_devuelve_el_json_de_medidas(self):
        contenido = b"CLI correcta nueva\n" * 13
        origen = self.escribir(contenido)
        salida = self.raiz / "salida_cli"
        proceso = self.ejecutar_cli("--archivo", origen, "--salida", salida)
        self.assertEqual(proceso.returncode, 0, proceso.stderr)
        self.assertEqual(proceso.stderr, "")
        resultado = json.loads(proceso.stdout)
        self.exigir_resultado(salida, contenido, resultado)
        self.exigir_original(origen, contenido)


if __name__ == "__main__":
    resultado = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(CompresionPaqueteCheck))
    print(json.dumps({
        "status": "passed" if resultado.wasSuccessful() else "failed",
        "tests_run": resultado.testsRun,
        "failures": len(resultado.failures),
        "errors": len(resultado.errors),
        "skipped": len(resultado.skipped),
        "scope": "Fixtures pequenos nuevos; sin red, Supabase ni benchmarks anteriores",
    }, ensure_ascii=False))
    raise SystemExit(0 if resultado.wasSuccessful() else 1)
