#!/usr/bin/env python3
"""Mide gzip sin alterar ni publicar un paquete: copia local y verificación exacta.

No cambia JSON, UUID ni formatos de MYG. Comprimir esta copia no modifica el
tamaño del JSON que recibe la RPC ni demuestra que se resuelva un HTTP 502/520.
Solo requiere Python 3; no utiliza red ni dependencias externas.
"""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile
import zlib


BLOQUE = 1024 * 1024


class CompresionError(Exception):
    """Fallo seguro sin incorporar contenido ni rutas al diagnóstico."""


class Argumentos(argparse.ArgumentParser):
    def error(self, _message):
        self.print_usage(sys.stderr)
        self.exit(2, "Argumentos inválidos. Indique --archivo y --salida.\n")


def _identidad(datos):
    return (datos.st_dev, datos.st_ino, datos.st_mode, datos.st_size,
            datos.st_mtime_ns, datos.st_ctime_ns)


def _comprimir_original(archivo, temporal):
    huella = hashlib.sha256()
    total = 0
    with archivo.open("rb") as origen:
        antes = os.fstat(origen.fileno())
        if not stat.S_ISREG(antes.st_mode):
            raise CompresionError("El origen debe ser un archivo regular.")
        with temporal.open("xb") as salida:
            # filename vacío evita incluir el nombre privado del origen en gzip.
            with gzip.GzipFile(filename="", mode="wb", fileobj=salida,
                               compresslevel=6, mtime=0) as comprimido:
                while True:
                    bloque = origen.read(BLOQUE)
                    if not bloque:
                        break
                    total += len(bloque)
                    huella.update(bloque)
                    comprimido.write(bloque)
            salida.flush()
            os.fsync(salida.fileno())
        despues = os.fstat(origen.fileno())
    if (_identidad(antes) != _identidad(despues)
            or _identidad(antes) != _identidad(archivo.stat())
            or total != antes.st_size):
        raise CompresionError("El origen cambió durante la lectura. No se publicó una copia.")
    return total, huella.hexdigest(), _identidad(antes)


def _verificar_gzip(archivo, expected_bytes, expected_sha256):
    huella = hashlib.sha256()
    total = 0
    try:
        with gzip.open(archivo, "rb") as origen:
            while True:
                bloque = origen.read(BLOQUE)
                if not bloque:
                    break
                total += len(bloque)
                if total > expected_bytes:
                    raise CompresionError("La copia descomprimida supera el tamaño original.")
                huella.update(bloque)
    except (OSError, EOFError, zlib.error):
        raise CompresionError("La copia gzip está incompleta o no supera su verificación.") from None
    if total != expected_bytes or huella.hexdigest() != expected_sha256:
        raise CompresionError("La copia descomprimida no coincide exactamente con el original.")
    return total, huella.hexdigest()


def _hash_archivo(archivo):
    huella = hashlib.sha256()
    total = 0
    with archivo.open("rb") as origen:
        while True:
            bloque = origen.read(BLOQUE)
            if not bloque:
                break
            huella.update(bloque)
            total += len(bloque)
    return total, huella.hexdigest()


def _comprobar_original(archivo, identidad, expected_bytes, expected_sha256):
    if _identidad(archivo.stat()) != identidad:
        raise CompresionError("El origen cambió. Se conserva sin reescribir y no se publica la copia.")
    total, huella = _hash_archivo(archivo)
    if (_identidad(archivo.stat()) != identidad or total != expected_bytes
            or huella != expected_sha256):
        raise CompresionError("El origen cambió. Se conserva sin reescribir y no se publica la copia.")


def _publicar(temporal, salida):
    # mkdir exclusivo reserva una carpeta NUEVA; nunca se reutiliza una entrega.
    salida.mkdir()
    propios = []
    try:
        for nombre in ("copia.gz", "resultado.json"):
            destino = salida / nombre
            # Reservar con xb también evita sustituir un archivo que apareciera
            # después de crear la carpeta. Solo se reemplazan reservas propias.
            with destino.open("xb"):
                pass
            propios.append(destino)
        os.replace(temporal / "copia.gz.tmp", salida / "copia.gz")
        # El informe se publica al final, después de verificar los bytes gzip.
        os.replace(temporal / "resultado.json.tmp", salida / "resultado.json")
    except BaseException:
        for destino in propios:
            try:
                destino.unlink(missing_ok=True)
            except OSError:
                pass
        try:
            salida.rmdir()
        except OSError:
            pass
        raise


def probar_compresion(archivo, salida):
    """Genera copia.gz e informe sin datos del proyecto en una carpeta nueva.

    El JSON se conserva como bytes opacos: no se interpreta, reserializa ni sube.
    Si el archivo cambia durante la operación, se rechaza la copia obtenida.
    """
    temporal = None
    try:
        archivo = Path(archivo).expanduser().resolve(strict=True)
        salida_solicitada = Path(os.path.abspath(os.fspath(Path(salida).expanduser())))
        if salida_solicitada.exists() or salida_solicitada.is_symlink():
            raise CompresionError("La carpeta de salida ya existe. Elija una carpeta nueva.")
        padre = salida_solicitada.parent.resolve(strict=True)
        if not padre.is_dir():
            raise CompresionError("La carpeta padre de la salida debe existir.")
        salida = padre / salida_solicitada.name
        if salida == archivo:
            raise CompresionError("El origen y la salida deben ser distintos.")
        if not archivo.is_file():
            raise CompresionError("El origen debe ser un archivo regular.")
        temporal = Path(tempfile.mkdtemp(prefix=".myg-compresion-", dir=padre))
        copia = temporal / "copia.gz.tmp"
        total, huella, identidad = _comprimir_original(archivo, copia)
        recuperados, huella_recuperada = _verificar_gzip(copia, total, huella)
        bytes_gzip, huella_gzip = _hash_archivo(copia)
        _comprobar_original(archivo, identidad, total, huella)
        resultado = {
            "bytes_originales": total,
            "bytes_gzip": bytes_gzip,
            "ahorro_bytes": total - bytes_gzip,
            "ahorro_porcentaje": round((1 - bytes_gzip / total) * 100, 4) if total else 0.0,
            "sha256_original": huella,
            "sha256_descomprimido": huella_recuperada,
            "sha256_gzip": huella_gzip,
            "roundtrip_exacto": recuperados == total and huella_recuperada == huella,
            "original_sin_cambios": True,
        }
        with (temporal / "resultado.json.tmp").open("x", encoding="utf-8", newline="\n") as informe:
            json.dump(resultado, informe, ensure_ascii=False, indent=2, sort_keys=True)
            informe.write("\n")
            informe.flush()
            os.fsync(informe.fileno())
        _publicar(temporal, salida)
        return resultado
    except CompresionError:
        raise
    except (OSError, ValueError):
        # OSError suele incluir rutas. No copiarlas a stdout, informes o errores.
        raise CompresionError("No se pudo leer, verificar o guardar la copia. No se sobrescribió el origen.") from None
    finally:
        if temporal is not None:
            shutil.rmtree(temporal, ignore_errors=True)


def main(argv=None):
    parser = Argumentos(description=__doc__)
    parser.add_argument("--archivo", required=True, type=Path, help="Archivo local que se leerá sin modificar.")
    parser.add_argument("--salida", required=True, type=Path, help="Carpeta nueva; su carpeta padre debe existir.")
    args = parser.parse_args(argv)
    try:
        resultado = probar_compresion(args.archivo, args.salida)
    except CompresionError as error:
        print("Error: " + str(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Operación interrumpida; no se confirmó una copia.", file=sys.stderr)
        return 130
    try:
        print(json.dumps(resultado, ensure_ascii=False, sort_keys=True))
    except BrokenPipeError:
        # Los archivos ya están verificados; cerrar stdout no invalida la copia.
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
