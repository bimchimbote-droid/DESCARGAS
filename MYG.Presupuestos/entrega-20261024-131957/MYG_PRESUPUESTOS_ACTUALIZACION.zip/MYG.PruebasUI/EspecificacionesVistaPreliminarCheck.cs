using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesVistaPreliminarCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var original = new RichTextBox
        {
            Rtf = @"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}{\f1 Courier New;}}{\colortbl;\red0\green0\blue255;}" +
                @"\pard\qc\f0\fs32\b Encabezado\b0\par\pard\ql\f1\fs20\i\ul\cf1 Cuerpo con formato\ul0\i0\cf0\par" +
                @"\trowd\trgaph90\cellx2000\cellx4000\pard\intbl A\cell B\cell\row\pard\par}"
        };
        original.Select(2, 5);
        original.Modified = false;
        string rtfOriginal = original.Rtf;
        using var copia = MYGEspecificacionesDocumento.CrearCopiaImpresion(original);
        exige(copia.Text == original.Text && copia.Rtf.Contains("Arial Narrow;", StringComparison.Ordinal) &&
                copia.Rtf.Contains(@"\trowd", StringComparison.Ordinal),
            "La copia de impresión debe usar Arial Narrow y conservar el texto y las tablas de la especificación.");

        copia.Select(0, "Encabezado".Length);
        using (var titulo = copia.SelectionFont)
            exige(titulo != null && titulo.Bold && Math.Abs(titulo.SizeInPoints - 16) < .01 &&
                    copia.SelectionAlignment == HorizontalAlignment.Center,
                "La fuente de impresión debe conservar el tamaño, negrita y alineación del encabezado RTF.");
        copia.Select(copia.Text.IndexOf("Cuerpo", StringComparison.Ordinal), "Cuerpo con formato".Length);
        using (var cuerpo = copia.SelectionFont)
            exige(cuerpo != null && cuerpo.Italic && cuerpo.Underline && Math.Abs(cuerpo.SizeInPoints - 10) < .01 &&
                    copia.SelectionColor.ToArgb() == Color.Blue.ToArgb(),
                "Cambiar la familia de impresión debe conservar cursiva, subrayado, tamaño y color de una selección mixta.");
        exige(original.Rtf == rtfOriginal && original.SelectionStart == 2 && original.SelectionLength == 5 && !original.Modified,
            "Preparar Arial Narrow para la vista y la impresión no debe modificar el RTF, la selección ni el estado del editor.");
        VerificarVistaPaginada(exige);
    }

    private static void VerificarVistaPaginada(Action<bool, string> exige)
    {
        // Cada sección cabe holgadamente en una hoja; los dos saltos nativos
        // deben crear al menos tres páginas, incluso con un papel amplio.
        var rtf = new StringBuilder(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}\f0\fs22 ");
        for (int seccion = 1; seccion <= 3; seccion++)
        {
            rtf.Append(seccion == 1 ? @"\pard " : @"\pard\pagebb ");
            rtf.Append(@"\b SECCION ").Append(seccion).Append(@"\b0\par\pard ");
            for (int linea = 1; linea <= 8; linea++)
                rtf.Append("Contenido sintetico ").Append(seccion).Append('.').Append(linea).Append(@"\par ");
        }
        rtf.Append('}');
        using var original = new RichTextBox { Rtf = rtf.ToString() };
        original.ClearUndo();
        string textoSinEdicion = original.Text;
        original.Select(original.TextLength, 0);
        original.SelectedText = "Edicion reversible para comprobar el historial.";
        exige(original.CanUndo, "El documento de prueba debe conservar una edición real en su historial antes de previsualizar.");
        original.Select(3, 7);
        original.Modified = false;
        string rtfOriginal = original.Rtf;
        bool podiaDeshacer = original.CanUndo, podiaRehacer = original.CanRedo;

        var impresora = new PrinterSettings();
        if (!impresora.IsValid)
        {
            impresora = PrinterSettings.InstalledPrinters.Cast<string>()
                .Select(nombre => new PrinterSettings { PrinterName = nombre }).FirstOrDefault(p => p.IsValid);
        }
        if (impresora == null || !impresora.IsValid)
        {
            Console.WriteLine("OMITIDA: paginación real de especificaciones y navegación de la vista; no hay una impresora válida en Windows. Las comprobaciones de copia y formato sí se ejecutaron.");
            return;
        }

        using var host = new Form { ClientSize = new Size(1000, 720), ShowInTaskbar = false };
        using var vista = new MYGEspecificacionesVistaPaginada { Dock = DockStyle.Fill };
        host.Controls.Add(vista);
        var pagina = new PageSettings(impresora)
        {
            PaperSize = new PaperSize("A4", 827, 1169), Margins = new Margins(75, 75, 75, 75)
        };
        using var documento = MYGEspecificacionesDocumento.CrearDocumentoImpresion(original,
            "Especificaciones paginadas de prueba", pagina, "CABECERA DE PRUEBA", "PIE DE PRUEBA", numeroPagina: true);
        documento.PrinterSettings = impresora;
        int generaciones = 0, paginasImpresas = 0;
        bool soloVistaPrevia = true, liberado = false;
        documento.BeginPrint += (_, e) =>
        {
            generaciones++;
            soloVistaPrevia &= e.PrintAction == PrintAction.PrintToPreview;
        };
        documento.PrintPage += (_, _) => paginasImpresas++;
        documento.Disposed += (_, _) => liberado = true;
        host.Show();
        vista.Cargar(documento);
        exige(Esperar(() => vista.CantidadPaginas >= 3, TimeSpan.FromSeconds(10)),
            "La vista debe generar al menos tres páginas reales con los saltos RTF, encabezado, pie y numeración, sin imprimir papel.");
        exige(soloVistaPrevia && generaciones > 0 && paginasImpresas >= 3 && !liberado,
            "Las páginas deben proceder del motor de impresión en modo de vista previa y conservar su documento mientras se muestran.");
        exige(vista.AjustarPagina && vista.Columnas == 1 &&
                vista.PaginaActual == 1 && !Controles(vista).OfType<RichTextBox>().Any(),
            "La vista debe ajustar una página completa sin mostrar un RichTextBox con desplazamiento interno.");

        var botones = Controles(vista).OfType<ToolStrip>().SelectMany(b => b.Items.OfType<ToolStripButton>())
            .ToDictionary(b => b.Name);
        exige(!botones["espec_previa_anterior"].Enabled && botones["espec_previa_siguiente"].Enabled,
            "La primera página debe permitir avanzar y bloquear el retroceso anterior al inicio.");
        int generacionesIniciales = generaciones;
        botones["espec_previa_siguiente"].PerformClick();
        Application.DoEvents();
        exige(vista.PaginaActual == 2 && botones["espec_previa_anterior"].Enabled,
            "La flecha siguiente debe mostrar la segunda página y habilitar el regreso.");
        botones["espec_previa_anterior"].PerformClick();
        exige(vista.PaginaActual == 1, "La flecha anterior debe recuperar la primera página.");
        vista.NavegarRueda(-SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == 2, "La rueda hacia abajo debe avanzar una página completa.");
        vista.NavegarRueda(SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == 1, "La rueda hacia arriba debe recuperar la página anterior.");
        vista.NavegarRueda(SystemInformation.MouseWheelScrollDelta);
        vista.IrAPagina(int.MinValue);
        exige(vista.PaginaActual == 1, "La rueda y la selección directa deben respetar el límite inicial.");
        vista.IrAPagina(int.MaxValue);
        exige(vista.PaginaActual == vista.CantidadPaginas && !botones["espec_previa_siguiente"].Enabled,
            "La selección directa debe limitarse a la última página y deshabilitar el avance posterior.");
        vista.NavegarRueda(-SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == vista.CantidadPaginas, "La rueda no debe avanzar más allá de la última página.");
        vista.IrAPagina(1);
        botones["espec_previa_dos_paginas"].PerformClick();
        Application.DoEvents();
        exige(vista.AjustarPagina && vista.Columnas == 2,
            "Dos páginas debe mostrar dos columnas ajustadas al espacio de la vista.");
        botones["espec_previa_una_pagina"].PerformClick();
        vista.Vista.Refresh();
        Application.DoEvents();
        exige(vista.AjustarPagina && vista.Columnas == 1 &&
                generaciones == generacionesIniciales,
            "Volver a una página y navegar debe reutilizar las páginas generadas sin iniciar otra impresión.");
        exige(original.Rtf == rtfOriginal && original.SelectionStart == 3 && original.SelectionLength == 7 &&
                !original.Modified && original.CanUndo == podiaDeshacer && original.CanRedo == podiaRehacer,
            "Generar y recorrer la vista no debe modificar el RTF, selección, estado ni historial del documento original.");

        vista.LiberarDocumento();
        Application.DoEvents();
        exige(liberado && vista.CantidadPaginas == 0 && vista.PaginaActual == 0 &&
                !botones["espec_previa_anterior"].Enabled && !botones["espec_previa_siguiente"].Enabled,
            "Liberar la vista debe disponer su documento y desactivar la navegación sin conservar páginas obsoletas.");
        original.Undo();
        exige(original.Text == textoSinEdicion,
            "El historial anterior a la vista previa debe seguir deshaciendo exactamente la edición original.");
        host.Close();
    }

    private static bool Esperar(Func<bool> listo, TimeSpan limite)
    {
        var reloj = Stopwatch.StartNew();
        while (!listo() && reloj.Elapsed < limite)
        {
            Application.DoEvents();
            Thread.Sleep(15);
        }
        Application.DoEvents();
        return listo();
    }

    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (var control in Controles(hijo)) yield return control;
    }
}
