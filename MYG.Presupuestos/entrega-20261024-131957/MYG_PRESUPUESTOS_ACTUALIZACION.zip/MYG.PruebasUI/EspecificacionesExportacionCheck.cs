using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesExportacionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Especificaciones-Exportacion-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            VerificarMenu(exige);
            VerificarGuardarConTeclado(exige);
            var proyecto = ProyectoDePrueba(carpeta);
            string firma = MYGProyectoStorage.Firma(proyecto);
            var presupuesto = proyecto.Presupuestos.Single(x => x.Id == "presupuesto-A");
            VerificarComposicion(proyecto, presupuesto, firma, exige);
            VerificarContenidoRecuperable(proyecto, exige);
            VerificarVentana(proyecto, presupuesto, firma, exige);
            VerificarVentanaOscura(proyecto, presupuesto, firma, exige);
            VerificarFormatoDoc(carpeta, exige);
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static void VerificarMenu(Action<bool, string> exige)
    {
        var alcances = new List<MYGAlcanceEspecificaciones>();
        using (var menu = EditorForm.CrearMenuEspecificaciones(alcances.Add, presupuestoDisponible: true))
        {
            var opciones = menu.Items.Cast<ToolStripMenuItem>().ToArray();
            exige(opciones.Select(x => x.Text).SequenceEqual(new[]
                { "Especificaciones de Proyecto", "Especificaciones de Presupuesto" }),
                "El botón Especificaciones debe desplegar exactamente los alcances Proyecto y Presupuesto.");
            exige(opciones.Select(x => x.Name).SequenceEqual(new[]
                { "exportar_especificaciones_proyecto", "exportar_especificaciones_presupuesto" }) && opciones.All(x => x.Enabled),
                "Las dos opciones de exportación deben conservar sus nombres accesibles y habilitarse cuando hay un presupuesto seleccionado.");
            exige(menu.Name == "menu_especificaciones_proyecto" && menu.AccessibleName == "Exportar especificaciones técnicas" &&
                menu.ShowImageMargin && menu.ImageScalingSize == new Size(20, 20) &&
                opciones.All(x => x.Image != null && x.AccessibleName == x.Text &&
                    !string.IsNullOrWhiteSpace(x.AccessibleDescription) && x.ToolTipText == x.AccessibleDescription),
                "El menú propio de Especificaciones debe mostrar iconos y describir sus dos alcances para accesibilidad.");
            opciones[0].PerformClick();
            opciones[1].PerformClick();
            exige(alcances.SequenceEqual(new[] { MYGAlcanceEspecificaciones.Proyecto, MYGAlcanceEspecificaciones.Presupuesto }),
                "Cada opción del menú debe abrir el documento correspondiente a su alcance, una única vez por clic.");
        }
        alcances.Clear();
        using (var menu = EditorForm.CrearMenuEspecificaciones(alcances.Add, presupuestoDisponible: false))
        {
            var proyecto = (ToolStripMenuItem)menu.Items["exportar_especificaciones_proyecto"];
            var presupuesto = (ToolStripMenuItem)menu.Items["exportar_especificaciones_presupuesto"];
            exige(proyecto.Enabled && !presupuesto.Enabled,
                "Sin presupuesto seleccionado, la exportación de Proyecto debe seguir disponible y Presupuesto debe deshabilitarse.");
            proyecto.PerformClick();
            exige(alcances.SequenceEqual(new[] { MYGAlcanceEspecificaciones.Proyecto }),
                "La exportación del proyecto completo debe funcionar también sin un presupuesto activo.");
        }
    }

    private static void VerificarGuardarConTeclado(Action<bool, string> exige)
    {
        int entregas = 0, proyectos = 0, cambios = 0;
        using var texto = new RichTextBoxTeclas { Text = "Documento de entrega." };
        using var editor = new MYGEspecificacionesEditor(texto, () => cambios++, () => cambios++,
            () => "Entrega", () => "", () => "", guardarProyecto: () => proyectos++);
        using var ventana = new Form { ClientSize = new Size(1200, 800) };
        ventana.Controls.Add(editor);
        editor.Cargar("copia-exportacion", "", "Documento de entrega.");
        editor.PrepararExportacion(() => { }, () => entregas++);
        ventana.Show();
        Application.DoEvents();
        string inicial = editor.DocumentoRtf;
        int cambiosIniciales = cambios;
        var pulsacion = texto.EnviarTecla(Keys.Control | Keys.S);
        exige(entregas == 1 && proyectos == 0 && pulsacion.SuppressKeyPress,
            "Ctrl+S en la vista de exportación debe abrir Guardar como para la entrega y suprimir la tecla sin guardar el proyecto.");
        exige(cambios == cambiosIniciales && editor.DocumentoRtf == inicial,
            "Invocar el guardado con Ctrl+S no debe crear modificaciones ni estados de historial en la copia del documento.");
        texto.EnviarTecla(Keys.Control | Keys.Alt | Keys.S);
        exige(entregas == 1 && proyectos == 0,
            "El atajo de guardado debe responder únicamente a Ctrl+S, sin apropiarse de combinaciones con Alt.");
        ventana.Close();
    }

    private sealed class RichTextBoxTeclas : RichTextBox
    {
        internal KeyEventArgs EnviarTecla(Keys teclas)
        {
            var evento = new KeyEventArgs(teclas);
            OnKeyDown(evento);
            return evento;
        }
    }

    private static MYGProyectoDocumento ProyectoDePrueba(string carpeta)
    {
        var proyecto = MYGProyectoStorage.Nuevo("OBRA DE PRUEBA Ñ");
        proyecto.Datos = new MYGDatosProyecto
        {
            Propietario = "PROPIETARIO DE PRUEBA", Localidad = "CENTRO POBLADO",
            Distrito = "NUEVO CHIMBOTE", Provincia = "SANTA", Departamento = "ÁNCASH",
            FechaElaboracion = new DateTime(2026, 10, 11)
        };
        var a = new MYGPresupuestoDocumento { Id = "presupuesto-A", Item = "01", Nombre = "PRESUPUESTO A", Posicion = 1 };
        var b = new MYGPresupuestoDocumento { Id = "presupuesto-B", Item = "02", Nombre = "PRESUPUESTO B", Posicion = 2 };
        var concreto = Partida("concreto", "01", "CONCRETO SIMPLE", "m³", 1);
        var pintura = Partida("pintura", "02", "PINTURA EXTERIOR", "m²", 2);
        pintura.Costos.EspecificacionTexto = "Acabado exterior, protección {especial} y aplicación \\ dos manos.";
        var acero = Partida("acero", "01", "ACERO ESTRUCTURAL", "kg", 1);
        acero.Costos.EspecificacionTexto = "Contenido exclusivo del presupuesto B.";

        // La cabecera reproduce el resultado de Insertar título. La exportación
        // debe consolidarla una sola vez y conservar los formatos del cuerpo.
        using (var original = new RichTextBox { Font = new Font("Arial", 11), DetectUrls = false })
        {
            original.Text = "01.01  CONCRETO SIMPLE   (unidad de medida: m³)\n\nDESCRIPCIÓN:\nResistencia característica y control de calidad.\n";
            original.Select(0, "01.01  CONCRETO SIMPLE".Length);
            original.SelectionFont = new Font("Arial", 11, FontStyle.Bold);
            int descripcion = original.Text.IndexOf("DESCRIPCIÓN:", StringComparison.Ordinal);
            original.Select(descripcion, "DESCRIPCIÓN:".Length);
            original.SelectionFont = new Font("Arial", 11, FontStyle.Bold);
            int resistencia = original.Text.IndexOf("Resistencia", StringComparison.Ordinal);
            original.Select(resistencia, "Resistencia característica".Length);
            original.SelectionFont = new Font("Courier New", 12, FontStyle.Italic | FontStyle.Underline);
            original.SelectionColor = Color.DarkGreen;
            original.Select(original.TextLength, 0);
            MYGEspecificacionesDocumento.InsertarTabla(original, 2, 2, 7000);
            original.Select(original.TextLength, 0);
            original.SelectedText = "\nDetalle de referencia:\n";
            string imagen = Path.Combine(carpeta, "detalle.bmp");
            using (var dibujo = new Bitmap(16, 12))
            {
                using (var grafico = Graphics.FromImage(dibujo))
                {
                    grafico.Clear(Color.DarkGreen);
                    grafico.FillRectangle(Brushes.Gold, 3, 2, 8, 6);
                }
                dibujo.Save(imagen, ImageFormat.Bmp);
            }
            original.Select(original.TextLength, 0);
            MYGEspecificacionesDocumento.InsertarImagen(original, imagen, 7000);
            concreto.Costos.EspecificacionRtf = MYGEspecificacionesPagina.Guardar(original.Rtf,
                new MYGPaginaEspecificacion { Encabezado = "CABECERA SOLO DE LA PARTIDA" });
            concreto.Costos.EspecificacionTexto = original.Text;
        }

        // La lista se guarda desordenada para probar el orden visible, sin
        // renumerar ni reorganizar los objetos del documento original.
        a.Items.AddRange(new[] { pintura, concreto });
        b.Items.Add(acero);
        proyecto.Presupuestos.Clear();
        proyecto.Presupuestos.AddRange(new[] { b, a });
        proyecto.PresupuestoActivoId = b.Id;
        return proyecto;
    }

    private static ItemPresupuestoDelphin Partida(string id, string item, string descripcion, string unidad, int posicion) => new()
    {
        Id = id, IdLocalMYG = id, IdPropuesta = id, Item = item,
        Descripcion = descripcion, Unidad = unidad, Posicion = posicion,
        TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA"
    };

    private static void VerificarComposicion(MYGProyectoDocumento proyecto, MYGPresupuestoDocumento presupuesto,
        string firma, Action<bool, string> exige)
    {
        string rtf = MYGEspecificacionesComposicion.Crear(proyecto, MYGAlcanceEspecificaciones.Presupuesto, presupuesto.Id);
        using var documento = new RichTextBox { Rtf = MYGEspecificacionesPagina.QuitarMetadatos(rtf) };
        string texto = documento.Text;
        exige(texto.Contains("ESPECIFICACIONES TECNICAS", StringComparison.Ordinal) &&
            texto.Contains(proyecto.Nombre, StringComparison.Ordinal) && texto.Contains(presupuesto.Nombre, StringComparison.Ordinal),
            "La exportación del presupuesto debe presentar el título y los nombres reales del proyecto y presupuesto.");
        exige(texto.Contains("PROPIETARIO DE PRUEBA", StringComparison.Ordinal) &&
            texto.Contains("CENTRO POBLADO", StringComparison.Ordinal) && texto.Contains("NUEVO CHIMBOTE", StringComparison.Ordinal) &&
            texto.Contains("SANTA", StringComparison.Ordinal) && texto.Contains("ÁNCASH", StringComparison.Ordinal) &&
            texto.Contains("11/10/2026", StringComparison.Ordinal),
            "La portada debe usar propietario, localidad, distrito, provincia, departamento y fecha de elaboración del proyecto.");
        exige(texto.Contains("CONCRETO SIMPLE", StringComparison.Ordinal) && texto.Contains("PINTURA EXTERIOR", StringComparison.Ordinal) &&
            !texto.Contains("ACERO ESTRUCTURAL", StringComparison.Ordinal) && !texto.Contains("Contenido exclusivo", StringComparison.Ordinal),
            "Especificaciones de Presupuesto debe incluir únicamente las partidas del presupuesto elegido.");
        exige(texto.IndexOf("CONCRETO SIMPLE", StringComparison.Ordinal) < texto.IndexOf("PINTURA EXTERIOR", StringComparison.Ordinal),
            "Las partidas exportadas deben seguir su posición en el presupuesto, aunque la colección esté desordenada.");
        exige(Apariciones(texto, "CONCRETO SIMPLE") == 1 && Apariciones(texto, "DESCRIPCIÓN:") == 1 &&
            texto.Contains("01.01", StringComparison.Ordinal) && texto.Contains("(unidad de medida: m³)", StringComparison.Ordinal),
            "Exportar una partida con Insertar título debe conservar ítem y unidad sin duplicar su cabecera ni DESCRIPCIÓN.");
        exige(texto.Contains("protección {especial} y aplicación \\ dos manos.", StringComparison.Ordinal),
            "Las especificaciones de texto deben conservar Unicode, llaves y barras al convertirse a RTF.");
        int resistencia = texto.IndexOf("Resistencia característica", StringComparison.Ordinal);
        documento.Select(resistencia, "Resistencia característica".Length);
        exige(documento.SelectionFont is Font fuente && fuente.Name == "Courier New" && fuente.Italic && fuente.Underline &&
            Math.Abs(fuente.Size - 12) < .01 && documento.SelectionColor.ToArgb() == Color.DarkGreen.ToArgb(),
            "Consolidar especificaciones debe conservar fuente, tamaño, cursiva, subrayado y color de cada cuerpo RTF.");
        exige(documento.Rtf.Contains(@"\trowd", StringComparison.Ordinal) && documento.Rtf.Contains(@"\pict", StringComparison.Ordinal),
            "La exportación debe conservar las tablas y las imágenes originales, sin convertir el cuerpo a texto plano.");
        var pagina = MYGEspecificacionesPagina.Leer(rtf);
        exige(pagina.AnchoMm == 210 && pagina.AltoMm == 297 && !pagina.Horizontal &&
            string.IsNullOrEmpty(pagina.Encabezado),
            "El documento consolidado debe usar su página A4 y evitar mezclar los encabezados privados de las partidas.");

        string rtfProyecto = MYGEspecificacionesComposicion.Crear(proyecto, MYGAlcanceEspecificaciones.Proyecto);
        using var completo = new RichTextBox { Rtf = MYGEspecificacionesPagina.QuitarMetadatos(rtfProyecto) };
        exige(completo.Text.Contains("CONCRETO SIMPLE", StringComparison.Ordinal) && completo.Text.Contains("PINTURA EXTERIOR", StringComparison.Ordinal) &&
            completo.Text.Contains("ACERO ESTRUCTURAL", StringComparison.Ordinal) && completo.Text.Contains("Contenido exclusivo del presupuesto B.", StringComparison.Ordinal),
            "Especificaciones de Proyecto debe reunir las partidas y contenidos de todos sus presupuestos.");
        exige(completo.Text.IndexOf("PRESUPUESTO A", StringComparison.Ordinal) < completo.Text.IndexOf("PRESUPUESTO B", StringComparison.Ordinal) &&
            completo.Text.IndexOf("PINTURA EXTERIOR", StringComparison.Ordinal) < completo.Text.IndexOf("ACERO ESTRUCTURAL", StringComparison.Ordinal),
            "La exportación del proyecto debe ordenar los presupuestos y mantener sus partidas agrupadas.");
        exige(MYGProyectoStorage.Firma(proyecto) == firma && proyecto.PresupuestoActivoId == "presupuesto-B" &&
            presupuesto.Items[0].Id == "pintura", "Preparar una exportación no debe escribir, renumerar ni cambiar la selección del proyecto original.");
    }

    private static void VerificarVentana(MYGProyectoDocumento proyecto, MYGPresupuestoDocumento presupuesto,
        string firma, Action<bool, string> exige)
    {
        using (var ventana = new MYGEspecificacionesExportacionForm(proyecto, MYGAlcanceEspecificaciones.Presupuesto,
            presupuesto.Id, @"C:\Proyectos\OBRA.sqlite"))
        {
            ventana.WindowState = FormWindowState.Normal;
            ventana.ClientSize = new Size(1200, 800);
            ventana.Show();
            Application.DoEvents();
            var controles = Descendientes(ventana).ToArray();
            var editor = controles.OfType<MYGEspecificacionesEditor>().Single();
            var cinta = controles.OfType<TabControl>().Single(x => x.Name == "espec_cinta");
            exige(ventana.Name == "espec_exportacion_form" && editor.Name == "espec_exportacion_editor" &&
                ReferenceEquals(ventana.Documento, editor.Documento),
                "La exportación debe abrir un espacio propio con el editor de especificaciones integrado.");
            exige(cinta.SelectedTab.Text == "Fichero" && cinta.TabPages.Cast<TabPage>().Select(x => x.Text).SequenceEqual(
                new[] { "Fichero", "Inicio", "Insertar", "Distribución de Página", "Vista" }),
                "La vista de exportación debe comenzar en Fichero y conservar las cinco pestañas de la referencia.");
            exige(!controles.Single(x => x.Name == "espec_cabecera").Visible &&
                !controles.Single(x => x.Name == "espec_barra_titulo").Visible,
                "La vista completa de exportación debe ocultar la cabecera de partida y la franja Insertar título.");
            Color fondoEsperado = MYG2027_TemaComercial.Oscuro && !SystemInformation.HighContrast
                ? Color.FromArgb(unchecked((int)0xff303640)) : Color.White;
            var previa = controles.OfType<MYGEspecificacionesVistaPaginada>().Single();
            exige(previa.Visible && !ventana.Documento.Visible &&
                !controles.Single(x => x.Name == "espec_lienzo").Visible &&
                !controles.Single(x => x.Name == "espec_regla_horizontal").Visible &&
                !controles.Single(x => x.Name == "espec_regla_vertical").Visible,
                "Fichero debe mostrar páginas de impresión completas y ocultar el editor continuo y sus barras internas.");
            cinta.SelectedIndex = 1; Application.DoEvents();
            exige(!previa.Visible && ventana.Documento.Visible &&
                controles.Single(x => x.Name == "espec_regla_horizontal").Visible &&
                controles.Single(x => x.Name == "espec_regla_vertical").Visible &&
                ventana.Documento.BackColor.ToArgb() == fondoEsperado.ToArgb(),
                "Inicio debe conservar el editor y sus reglas para preparar la copia exportable.");
            cinta.SelectedIndex = 0; Application.DoEvents();
            exige(previa.Visible && !ventana.Documento.Visible && !ventana.HayCambiosPendientes,
                "Volver a Fichero debe restaurar la vista paginada sin modificar la entrega.");
            var botones = Herramientas(cinta.SelectedTab).OfType<ToolStripButton>().ToArray();
            string[] etiquetas = botones.Select(x => Normalizar(x.Text)).ToArray();
            exige(etiquetas.SequenceEqual(new[] { "Volver al proyecto", "Abrir", "Guardar como", "Imprimir", "Comprobar ortografía" }),
                "Fichero debe presentar Volver al proyecto, Abrir, Guardar como, Imprimir y Comprobar ortografía en ese orden.");
            exige(botones.Single(x => Normalizar(x.Text) == "Volver al proyecto").Name == "espec_volver_proyecto" &&
                botones.Single(x => Normalizar(x.Text) == "Guardar como").Name == "espec_exportacion_guardar",
                "La navegación y el guardado de la entrega deben usar sus comandos propios de exportación.");
            exige(botones.All(x => x.Image != null), "Cada comando de Fichero debe presentar su icono en la cinta de exportación.");
            var grupos = Descendientes(cinta.SelectedTab).OfType<Label>().Select(x => Normalizar(x.Text)).ToArray();
            exige(grupos.Contains("Navegar") && grupos.Contains("Común") && grupos.Any(x => x.StartsWith("Comprobar", StringComparison.Ordinal)),
                "Los comandos deben conservar los grupos Navegar, Común y Comprobar de la referencia.");
            exige(ventana.Documento.Text.Contains("CONCRETO SIMPLE", StringComparison.Ordinal) &&
                !ventana.Documento.Text.Contains("ACERO ESTRUCTURAL", StringComparison.Ordinal),
                "El editor de exportación debe mostrar la composición del presupuesto solicitado.");
            exige(MYGProyectoStorage.Firma(proyecto) == firma, "Abrir la ventana de exportación no debe modificar las partidas.");
            botones.Single(x => Normalizar(x.Text) == "Volver al proyecto").PerformClick();
            Application.DoEvents();
            exige(!ventana.Visible, "Volver al proyecto debe cerrar la vista de exportación y devolver el control al proyecto.");
        }

        // Editar el documento consolidado sirve para preparar la entrega, pero
        // esos cambios pertenecen a la copia y jamás a una partida del proyecto.
        using (var ventana = new MYGEspecificacionesExportacionForm(proyecto, MYGAlcanceEspecificaciones.Proyecto))
        {
            ventana.WindowState = FormWindowState.Normal;
            ventana.ClientSize = new Size(1200, 800);
            ventana.Show();
            Application.DoEvents();
            var editor = Descendientes(ventana).OfType<MYGEspecificacionesEditor>().Single();
            Descendientes(ventana).OfType<TabControl>().Single(x => x.Name == "espec_cinta").SelectedIndex = 1;
            Application.DoEvents();
            string inicial = ventana.DocumentoRtf;
            exige(!ventana.HayCambiosPendientes, "Abrir la copia de exportación no debe marcar cambios pendientes.");
            ventana.Documento.Select(0, "ESPECIFICACIONES TECNICAS".Length);
            ventana.Documento.SelectionColor = Color.Navy;
            exige(ventana.HayCambiosPendientes,
                "Un cambio nativo de formato sin TextChanged debe detectarse antes de cerrar la exportación.");
            ventana.Documento.Select(ventana.Documento.TextLength, 0);
            editor.AplicarFormato(() => ventana.Documento.SelectedText = "\nNota exclusiva del documento de entrega.");
            exige(ventana.DocumentoRtf != inicial && ventana.Documento.Text.Contains("Nota exclusiva del documento de entrega.", StringComparison.Ordinal),
                "El documento consolidado debe permitir ajustes en la copia que se guardará para entregar.");
            exige(MYGProyectoStorage.Firma(proyecto) == firma && proyecto.PresupuestoActivoId == "presupuesto-B",
                "Editar el documento de entrega no debe escribir su contenido en partidas ni cambiar el presupuesto activo.");
            string editado = ventana.DocumentoRtf;
            Descendientes(ventana).OfType<TabControl>().Single(x => x.Name == "espec_cinta").SelectedIndex = 0;
            Application.DoEvents();
            exige(Descendientes(ventana).OfType<MYGEspecificacionesVistaPaginada>().Single().Visible &&
                !ventana.Documento.Visible && ventana.DocumentoRtf == editado && ventana.HayCambiosPendientes &&
                MYGProyectoStorage.Firma(proyecto) == firma,
                "Reabrir la vista paginada tras editar debe conservar la copia pendiente y dejar intacto el proyecto original.");
            // Dispose evita responder al aviso de una entrega editada sin guardar.
        }
    }

    private static void VerificarVentanaOscura(MYGProyectoDocumento proyecto, MYGPresupuestoDocumento presupuesto,
        string firma, Action<bool, string> exige)
    {
        if (SystemInformation.HighContrast) return;
        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            if (!MYG2027_TemaComercial.Oscuro) MYG2027_TemaComercial.Alternar(false);
            using var ventana = new MYGEspecificacionesExportacionForm(proyecto,
                MYGAlcanceEspecificaciones.Presupuesto, presupuesto.Id);
            ventana.WindowState = FormWindowState.Normal;
            ventana.ClientSize = new Size(1200, 800);
            ventana.Show();
            Application.DoEvents();
            var controles = Descendientes(ventana).ToArray();
            var editor = controles.OfType<MYGEspecificacionesEditor>().Single();
            var cinta = controles.OfType<TabControl>().Single(x => x.Name == "espec_cinta");
            cinta.SelectedIndex = 1; Application.DoEvents();
            controles.OfType<NumericUpDown>().Single(x => x.Name == "espec_zoom").Value = 100;
            ventana.Documento.Select(0, 5);
            string original = ventana.DocumentoRtf, salida = editor.RtfParaArchivo;
            bool undo = ventana.Documento.CanUndo;
            int posicion = ventana.Documento.SelectionStart, longitud = ventana.Documento.SelectionLength;
            var herramientas = Descendientes(cinta.SelectedTab).OfType<ToolStrip>().First();
            ToolStripRenderer renderer = herramientas.Renderer;
            foreach (Control destino in new Control[] { ventana, editor, ventana.Documento, cinta, herramientas })
            {
                MYG2027_TemaComercial.Aplicar(destino);
                Application.DoEvents();
                exige(cinta.TabPages.Cast<TabPage>().All(x => x.BackColor.GetBrightness() < .3f) &&
                    controles.Where(x => x.Name.StartsWith("espec_grupo_", StringComparison.Ordinal))
                        .All(x => x.BackColor.GetBrightness() < .3f && x.ForeColor.GetBrightness() > .7f) &&
                    ReferenceEquals(herramientas.Renderer, renderer),
                    "Abrir y recolorear una exportación con oscuro ya activo debe conservar la cinta completa en oscuro.");
                EspecificacionesEditorCheck.VerificarDibujoDocumento(editor, oscuro: true, exige);
            }
            ventana.Hide();
            ventana.Show();
            Application.DoEvents();
            EspecificacionesEditorCheck.VerificarDibujoDocumento(editor, oscuro: true, exige);
            exige(ventana.DocumentoRtf == original && editor.RtfParaArchivo == salida &&
                ventana.Documento.CanUndo == undo && ventana.Documento.SelectionStart == posicion &&
                ventana.Documento.SelectionLength == longitud && !ventana.HayCambiosPendientes &&
                MYGProyectoStorage.Firma(proyecto) == firma,
                "El tema de la exportación debe conservar su RTF, colores de salida, selección, Deshacer y proyecto original.");
            ventana.Close();
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarContenidoRecuperable(MYGProyectoDocumento original, Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Copia(original);
        var partida = proyecto.Presupuestos.Single(x => x.Id == "presupuesto-B").Items.Single();
        partida.Costos.EspecificacionRtf = @"{\rtf1\ansi RTF incompleto";
        partida.Costos.EspecificacionTexto = "Texto recuperado de una especificación antigua dañada.";
        string firma = MYGProyectoStorage.Firma(proyecto);
        string rtf = MYGEspecificacionesComposicion.Crear(proyecto, MYGAlcanceEspecificaciones.Presupuesto, "presupuesto-B");
        using (var documento = new RichTextBox { Rtf = MYGEspecificacionesPagina.QuitarMetadatos(rtf) })
            exige(documento.Text.Contains(partida.Costos.EspecificacionTexto, StringComparison.Ordinal) &&
                MYGProyectoStorage.Firma(proyecto) == firma,
                "Un RTF dañado con texto recuperable debe exportar ese texto sin reescribir la partida original.");
        partida.Costos.EspecificacionTexto = "";
        bool rechazado = false;
        try { MYGEspecificacionesComposicion.Crear(proyecto, MYGAlcanceEspecificaciones.Presupuesto, "presupuesto-B"); }
        catch (InvalidOperationException ex)
        {
            rechazado = ex.Message.Contains("ACERO ESTRUCTURAL", StringComparison.Ordinal);
        }
        exige(rechazado, "Un RTF dañado sin texto recuperable debe identificar la partida y evitar una entrega con contenido perdido.");
    }

    private static void VerificarFormatoDoc(string carpeta, Action<bool, string> exige)
    {
        string falsoDoc = Path.Combine(carpeta, "rtf-con-extension-doc.doc");
        File.WriteAllText(falsoDoc, @"{\rtf1\ansi Documento RTF, no archivo binario de Word.}");
        exige(!MYGEspecificacionesDocumento.EsDocumentoWordValido(falsoDoc),
            "Guardar en .doc debe validar el formato binario Word 97 y rechazar un RTF simplemente renombrado.");
        string truncado = Path.Combine(carpeta, "doc-truncado.doc");
        File.WriteAllBytes(truncado, new byte[] { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 });
        exige(!MYGEspecificacionesDocumento.EsDocumentoWordValido(truncado),
            "La validación del archivo .doc debe rechazar una firma OLE truncada antes de reemplazar una entrega.");
    }

    private static int Apariciones(string texto, string fragmento)
    {
        int total = 0, posicion = 0;
        while ((posicion = texto.IndexOf(fragmento, posicion, StringComparison.Ordinal)) >= 0)
        {
            total++;
            posicion += fragmento.Length;
        }
        return total;
    }

    private static string Normalizar(string texto) => string.Join(" ", (texto ?? "").Split((char[])null, StringSplitOptions.RemoveEmptyEntries));

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }

    private static IEnumerable<ToolStripItem> Herramientas(Control padre) => Descendientes(padre)
        .OfType<ToolStrip>().SelectMany(x => x.Items.Cast<ToolStripItem>());
}
