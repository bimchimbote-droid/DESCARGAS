using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Operaciones de documento que conservan el contenido RTF de la especificación.</summary>
internal static class MYGEspecificacionesDocumento
{
    private const int EmFormatRange = 0x0439;
    private const int EmGetParaFormat = 0x043D, EmSetParaFormat = 0x0447;
    private const uint PfmPageBreakBefore = 0x00080000;
    private const ushort PfePageBreakBefore = 0x0008;
    private const int FormatoWord97 = 0, FormatoWordXml = 12, FormatoRtf = 6;

    internal static void InsertarTabla(RichTextBox editor, int filas, int columnas, int anchoTwips)
    {
        ArgumentNullException.ThrowIfNull(editor);
        if (filas is < 1 or > 100 || columnas is < 1 or > 20)
            throw new ArgumentOutOfRangeException(nameof(filas), "La tabla admite entre 1 y 100 filas y entre 1 y 20 columnas.");
        if (anchoTwips < columnas * 360 || anchoTwips > 31680)
            throw new ArgumentOutOfRangeException(nameof(anchoTwips), "El ancho de la tabla debe permitir al menos 0,635 cm por columna.");

        var rtf = new StringBuilder(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}\pard\par ");
        const string borde = @"\brdrs\brdrw10\brdrcf0";
        for (int fila = 0; fila < filas; fila++)
        {
            rtf.Append(@"\trowd\trgaph90\trleft0\trrh360");
            for (int columna = 1; columna <= columnas; columna++)
            {
                rtf.Append(@"\clbrdrt").Append(borde).Append(@"\clbrdrl").Append(borde)
                    .Append(@"\clbrdrb").Append(borde).Append(@"\clbrdrr").Append(borde)
                    .Append(@"\cellx").Append((anchoTwips * columna / columnas).ToString(CultureInfo.InvariantCulture));
            }
            for (int columna = 0; columna < columnas; columna++)
                rtf.Append(@"\pard\intbl\f0\fs22 \cell ");
            rtf.Append(@"\row ");
        }
        rtf.Append(@"\pard\par }");
        editor.SelectedRtf = rtf.ToString();
        editor.Focus();
    }

    internal static void InsertarImagen(RichTextBox editor, string ruta, int anchoMaximoTwips)
    {
        ArgumentNullException.ThrowIfNull(editor);
        if (anchoMaximoTwips is < 360 or > 31680)
            throw new ArgumentOutOfRangeException(nameof(anchoMaximoTwips));
        var archivo = new FileInfo(ruta);
        if (archivo.Length > 32 * 1024 * 1024)
            throw new InvalidOperationException("La imagen supera 32 MB. Reduzca su tamaño antes de insertarla.");
        using var imagen = Image.FromFile(ruta);
        if ((long)imagen.Width * imagen.Height > 40_000_000)
            throw new InvalidOperationException("La imagen supera 40 megapíxeles. Reduzca su resolución antes de insertarla.");

        // RichEdit representa imágenes WMF en pantalla y al imprimir, sin depender de Word.
        var dpiX = imagen.HorizontalResolution > 0 ? imagen.HorizontalResolution : 96;
        var dpiY = imagen.VerticalResolution > 0 ? imagen.VerticalResolution : 96;
        var anchoNatural = Math.Max(1, (int)Math.Round(imagen.Width * 1440d / dpiX));
        var altoNatural = Math.Max(1, (int)Math.Round(imagen.Height * 1440d / dpiY));
        var escala = Math.Min(1d, anchoMaximoTwips / (double)anchoNatural);
        var ancho = Math.Max(1, (int)Math.Round(anchoNatural * escala));
        var alto = Math.Max(1, (int)Math.Round(altoNatural * escala));
        var wmf = ObtenerMetarchivo(editor, imagen);
        var rtf = new StringBuilder(wmf.Length * 2 + 160);
        rtf.Append(@"{\rtf1\ansi{\pict\wmetafile8\picw")
            .Append((int)Math.Round(imagen.Width * 2540d / dpiX))
            .Append(@"\pich").Append((int)Math.Round(imagen.Height * 2540d / dpiY))
            .Append(@"\picwgoal").Append(ancho).Append(@"\pichgoal").Append(alto).Append(' ')
            .Append(Convert.ToHexString(wmf)).Append("}}");
        editor.SelectedRtf = rtf.ToString();
        editor.Focus();
    }

    internal static void InsertarSaltoPagina(RichTextBox editor)
    {
        ArgumentNullException.ThrowIfNull(editor);
        var anterior = editor.Rtf;
        var posicion = editor.SelectionStart;
        var longitud = editor.SelectionLength;
        try
        {
            editor.SelectedText = "\n";
            var formato = CrearFormatoParrafo();
            formato.Mascara = PfmPageBreakBefore;
            formato.Efectos = PfePageBreakBefore;
            if (SendMessageParrafo(editor.Handle, EmSetParaFormat, IntPtr.Zero, ref formato) == IntPtr.Zero ||
                !TieneSaltoAntes(editor) || !editor.Rtf.Contains(@"\pagebb", StringComparison.Ordinal))
                throw new InvalidOperationException("No se pudo insertar el salto de página. Sitúe el cursor en un párrafo fuera de una tabla.");
            editor.Focus();
        }
        catch
        {
            editor.Rtf = anterior;
            editor.Select(posicion, longitud);
            throw;
        }
    }

    internal static string RtfConPagina(RichTextBox editor, PageSettings pagina,
        string encabezado = "", string pie = "", bool numeroPagina = false)
    {
        ArgumentNullException.ThrowIfNull(editor);
        ArgumentNullException.ThrowIfNull(pagina);
        var rtf = LimpiarConfiguracionRtf(editor.Rtf);
        var inicio = rtf.IndexOf(@"\rtf1", StringComparison.Ordinal);
        if (inicio < 0) throw new InvalidOperationException("La especificación no contiene un documento RTF válido.");
        static int Twips(int centesimas) => checked((int)Math.Round(centesimas * 14.4));
        var ajustes = new StringBuilder();
        ajustes.Append(@"\paperw").Append(Twips(pagina.Bounds.Width)).Append(@"\paperh").Append(Twips(pagina.Bounds.Height));
        if (pagina.Landscape) ajustes.Append(@"\landscape");
        ajustes.Append(@"\margl").Append(Twips(pagina.Margins.Left)).Append(@"\margr").Append(Twips(pagina.Margins.Right))
            .Append(@"\margt").Append(Twips(pagina.Margins.Top + (!string.IsNullOrEmpty(encabezado) ? 34 : 0)))
            .Append(@"\margb").Append(Twips(pagina.Margins.Bottom + (!string.IsNullOrEmpty(pie) || numeroPagina ? 34 : 0)))
            .Append(@"\headery").Append(Twips(pagina.Margins.Top)).Append(@"\footery").Append(Twips(pagina.Margins.Bottom)).Append(' ');
        if (!string.IsNullOrEmpty(encabezado))
            ajustes.Append(@"{\header\pard\plain\ql\f0\fs18\uc1 ").Append(EscaparRtf(encabezado)).Append(@"\par}");
        if (!string.IsNullOrEmpty(pie) || numeroPagina)
        {
            ajustes.Append(@"{\footer\pard\plain\qr\f0\fs18\uc1 ").Append(EscaparRtf(pie ?? ""));
            if (numeroPagina)
                ajustes.Append(EscaparRtf(string.IsNullOrEmpty(pie) ? "Página " : "   ·   Página "))
                    .Append(@"{\field{\*\fldinst PAGE}{\fldrslt 1}}");
            ajustes.Append(@"\par}");
        }
        // Las tablas de fuentes preceden a los encabezados que hacen referencia a ellas.
        return rtf.Insert(InicioCuerpoRtf(rtf), ajustes.ToString());
    }

    internal static PrintDocument CrearDocumentoImpresion(RichTextBox editor, string titulo,
        PageSettings pagina, string encabezado = "", string pie = "", bool numeroPagina = false)
    {
        ArgumentNullException.ThrowIfNull(editor);
        var copia = CrearCopiaImpresion(editor);
        PrintDocument documento = null;
        try
        {
            documento = new PrintDocument();
            // La vista integrada puede conservar el documento entre repintados;
            // su copia y la caché nativa tienen la misma vida que PrintDocument.
            documento.Disposed += (_, _) =>
            {
                try { LiberarFormato(copia); }
                finally { copia.Dispose(); }
            };
            documento.DocumentName = string.IsNullOrWhiteSpace(titulo) ? "Especificación técnica" : titulo;
            if (pagina != null) documento.DefaultPageSettings = (PageSettings)pagina.Clone();
            var inicio = 0;
            var numero = 0;
            var saltos = ObtenerSaltosPagina(copia);
            documento.BeginPrint += (_, _) => { inicio = 0; numero = 0; };
            documento.EndPrint += (_, _) => LiberarFormato(copia);
            documento.PrintPage += (_, e) =>
            {
                numero++;
                var contenido = e.MarginBounds;
                const int reserva = 34; // 24,48 puntos: deja el encabezado y pie fuera del texto.
                if (!string.IsNullOrEmpty(encabezado)) { contenido.Y += reserva; contenido.Height -= reserva; }
                if (!string.IsNullOrEmpty(pie) || numeroPagina) contenido.Height -= reserva;
                if (contenido.Width <= 0 || contenido.Height <= 0)
                    throw new InvalidOperationException("Los márgenes no dejan espacio para imprimir el documento.");
                var limite = copia.TextLength;
                foreach (var salto in saltos)
                    if (salto > inicio) { limite = salto; break; }
                var siguiente = FormatearPagina(copia, e, contenido, inicio, limite);
                if (inicio < copia.TextLength && siguiente <= inicio)
                    throw new InvalidOperationException("No se pudo distribuir el documento. Revise el tamaño de papel y los márgenes.");
                inicio = siguiente;
                DibujarEncabezadoPie(e, encabezado, pie, numeroPagina ? numero : 0, reserva);
                // La ventana de vista previa también permite imprimir. Consultar el
                // controlador actual evita que sus guías lleguen al papel o al PDF.
                if (documento.PrintController.IsPreview) DibujarGuiasMargen(e);
                e.HasMorePages = inicio < copia.TextLength;
            };
            return documento;
        }
        catch
        {
            try { documento?.Dispose(); }
            finally { copia.Dispose(); }
            throw;
        }
    }

    internal static void Imprimir(IWin32Window owner, RichTextBox editor, string titulo, bool vistaPrevia,
        PageSettings pagina, string encabezado = "", string pie = "", bool numeroPagina = false)
    {
        using var documento = CrearDocumentoImpresion(editor, titulo, pagina, encabezado, pie, numeroPagina);
        try
        {
            if (vistaPrevia)
            {
                using var vista = new PrintPreviewDialog { Document = documento, Width = 1050, Height = 800, UseAntiAlias = true };
                vista.ShowDialog(owner);
            }
            else
            {
                using var dialogo = new PrintDialog { Document = documento, UseEXDialog = true, AllowSomePages = false, AllowSelection = false };
                if (dialogo.ShowDialog(owner) == DialogResult.OK) documento.Print();
            }
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            MessageBox.Show(owner, "No se pudo imprimir la especificación.\n\n" + Mensaje(ex), "Impresión", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    internal static RichTextBox CrearCopiaImpresion(RichTextBox editor)
    {
        ArgumentNullException.ThrowIfNull(editor);
        var copia = new RichTextBox { Font = editor.Font, DetectUrls = false, Rtf = editor.Rtf };
        try
        {
            copia.SelectAll();
            // Cambiar únicamente CFM_FACE conserva los tamaños, estilos, colores,
            // tablas e imágenes del RTF y deja intacto el documento del usuario.
            MYGEspecificacionesFormato.EstablecerFuente(copia, "Arial Narrow", null);
            copia.Select(0, 0);
            return copia;
        }
        catch { copia.Dispose(); throw; }
    }

    private static void DibujarGuiasMargen(PrintPageEventArgs e)
    {
        using var guia = new Pen(Color.FromArgb(172, 172, 172), .5f) { DashStyle = DashStyle.Dot };
        float x = e.PageSettings.HardMarginX, y = e.PageSettings.HardMarginY;
        var papel = e.PageBounds;
        var margen = e.MarginBounds;
        e.Graphics.DrawLine(guia, margen.Left - x, papel.Top - y, margen.Left - x, papel.Bottom - y);
        e.Graphics.DrawLine(guia, margen.Right - x, papel.Top - y, margen.Right - x, papel.Bottom - y);
        e.Graphics.DrawLine(guia, papel.Left - x, margen.Top - y, papel.Right - x, margen.Top - y);
        e.Graphics.DrawLine(guia, papel.Left - x, margen.Bottom - y, papel.Right - x, margen.Bottom - y);
    }

    internal static void GuardarWord(IWin32Window owner, RichTextBox editor, string ruta, PageSettings pagina,
        string encabezado = "", string pie = "", bool numeroPagina = false)
    {
        ArgumentNullException.ThrowIfNull(editor);
        string carpeta = null, temporalDestino = null;
        try
        {
            var destino = Path.GetFullPath(ruta);
            var extension = Path.GetExtension(destino);
            var esDoc = string.Equals(extension, ".doc", StringComparison.OrdinalIgnoreCase);
            if (!esDoc && !string.Equals(extension, ".docx", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Seleccione un archivo con extensión .doc o .docx para exportar a Word.");
            if (!Directory.Exists(Path.GetDirectoryName(destino)))
                throw new DirectoryNotFoundException("La carpeta de destino no existe.");
            carpeta = CrearCarpetaTemporal();
            var origen = Path.Combine(carpeta, "especificacion.rtf");
            editor.SaveFile(origen, RichTextBoxStreamType.RichText);
            temporalDestino = Path.Combine(Path.GetDirectoryName(destino), ".myg-" + Guid.NewGuid().ToString("N") + extension);
            ConvertirConWord(origen, temporalDestino, esDoc ? FormatoWord97 : FormatoWordXml, pagina, encabezado, pie, numeroPagina);
            if (!EsDocumentoWordValido(temporalDestino))
                throw new IOException("Word no generó un documento válido para la extensión seleccionada.");
            // Reemplaza el archivo únicamente después de cerrar Word y validar el formato real.
            File.Move(temporalDestino, destino, true);
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            throw new InvalidOperationException("No se pudo guardar el documento Word.\n\n" + Mensaje(ex), ex);
        }
        finally { EliminarArchivoTemporal(temporalDestino); EliminarCarpetaTemporal(carpeta); }
    }

    internal static bool EsDocumentoWordValido(string ruta)
    {
        if (string.IsNullOrEmpty(ruta)) return false;
        try
        {
            var extension = Path.GetExtension(ruta);
            using var archivo = File.OpenRead(ruta);
            Span<byte> firma = stackalloc byte[8];
            archivo.ReadExactly(firma);
            if (string.Equals(extension, ".doc", StringComparison.OrdinalIgnoreCase))
                // wdFormatDocument97 produce un contenedor OLE, nunca RTF con otra extensión.
                return archivo.Length >= 512 && firma.SequenceEqual(new byte[] { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 });
            if (!string.Equals(extension, ".docx", StringComparison.OrdinalIgnoreCase) ||
                !firma[..4].SequenceEqual(new byte[] { 0x50, 0x4B, 0x03, 0x04 })) return false;
            archivo.Position = 0;
            using var paquete = new ZipArchive(archivo, ZipArchiveMode.Read);
            // Un ZIP ajeno a Word tampoco debe reemplazar un documento existente.
            return paquete.GetEntry("[Content_Types].xml") is { Length: > 0 } &&
                paquete.GetEntry("word/document.xml") is { Length: > 0 };
        }
        catch (IOException) { return false; }
        catch (UnauthorizedAccessException) { return false; }
        catch (InvalidDataException) { return false; }
    }

    internal static void AbrirWord(IWin32Window owner, RichTextBox editor, string ruta)
    {
        ArgumentNullException.ThrowIfNull(editor);
        string carpeta = null;
        try
        {
            var extension = Path.GetExtension(ruta);
            if (!string.Equals(extension, ".docx", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(extension, ".doc", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Seleccione un documento Word .docx o .doc.");
            carpeta = CrearCarpetaTemporal();
            var origen = Path.Combine(carpeta, "origen" + extension);
            var convertido = Path.Combine(carpeta, "especificacion.rtf");
            File.Copy(ruta, origen);
            ConvertirConWord(origen, convertido, FormatoRtf, null, "", "", false);
            using var validacion = new RichTextBox();
            validacion.LoadFile(convertido, RichTextBoxStreamType.RichText);
            // La conversión y validación se completan antes de reemplazar el contenido en edición.
            var anterior = editor.Rtf;
            var posicion = editor.SelectionStart;
            var longitud = editor.SelectionLength;
            var modificado = editor.Modified;
            try
            {
                editor.Rtf = validacion.Rtf;
                editor.Select(0, 0);
                editor.Focus();
            }
            catch
            {
                editor.Rtf = anterior;
                editor.Select(posicion, longitud);
                editor.Modified = modificado;
                throw;
            }
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            throw new InvalidOperationException("No se pudo abrir el documento Word.\n\n" + Mensaje(ex), ex);
        }
        finally { EliminarCarpetaTemporal(carpeta); }
    }

    internal static void ComprobarOrtografia(RichTextBox editor, IWin32Window owner)
    {
        ArgumentNullException.ThrowIfNull(editor);
        if (editor.ReadOnly) return;
        var anterior = editor.Rtf;
        var posicion = editor.SelectionStart;
        var longitud = editor.SelectionLength;
        var modificado = editor.Modified;
        string carpeta = null;
        try
        {
            var tipo = Type.GetTypeFromProgID("Word.Application");
            if (tipo == null)
                throw new InvalidOperationException("La comprobación ortográfica requiere Microsoft Word instalado en Windows.");
            carpeta = CrearCarpetaTemporal();
            var origen = Path.Combine(carpeta, "revision-original.rtf");
            var corregido = Path.Combine(carpeta, "revision-corregida.rtf");
            editor.SaveFile(origen, RichTextBoxStreamType.RichText);
            object aplicacion = null, documentos = null, documento = null;
            try
            {
                try { aplicacion = Activator.CreateInstance(tipo); }
                catch (COMException ex) when (ex.HResult == unchecked((int)0x80040154))
                {
                    throw new InvalidOperationException("La comprobación ortográfica requiere Microsoft Word instalado en Windows.", ex);
                }
                dynamic word = aplicacion;
                word.DisplayAlerts = 0;
                word.AutomationSecurity = 3; // msoAutomationSecurityForceDisable.
                documentos = word.Documents;
                documento = ((dynamic)documentos).Open(FileName: origen, ConfirmConversions: false, ReadOnly: false,
                    AddToRecentFiles: false, Visible: true, NoEncodingDialog: true);
                word.Visible = true;
                ((dynamic)documento).Activate();
                word.Activate();
                // Word muestra su diálogo de revisión y usa los diccionarios instalados.
                // Cancelar conserva las correcciones que el usuario ya haya aceptado.
                ((dynamic)documento).CheckSpelling(IgnoreUppercase: false, AlwaysSuggest: true);
                ((dynamic)documento).SaveAs2(FileName: corregido, FileFormat: FormatoRtf, AddToRecentFiles: false);
                if (!File.Exists(corregido) || new FileInfo(corregido).Length == 0)
                    throw new IOException("Word no generó un documento corregido válido.");
            }
            finally
            {
                if (documento != null)
                {
                    try { ((dynamic)documento).Close(SaveChanges: 0); } catch (Exception) { }
                    LiberarCom(documento);
                }
                LiberarCom(documentos);
                if (aplicacion != null)
                {
                    try { ((dynamic)aplicacion).Quit(SaveChanges: 0); } catch (Exception) { }
                    LiberarCom(aplicacion);
                }
            }
            using var validacion = new RichTextBox();
            validacion.LoadFile(corregido, RichTextBoxStreamType.RichText);
            // SelectedRtf conserva Deshacer; no sustituir Rtf directamente ni borrar el historial.
            // Si no cambió el texto, mantener también el formato original exacto del editor.
            if (!string.Equals(validacion.Text, editor.Text, StringComparison.Ordinal))
            {
                editor.SelectAll();
                editor.SelectedRtf = validacion.Rtf;
            }
            editor.Focus();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            if (!editor.IsDisposed)
            {
                if (!string.Equals(editor.Rtf, anterior, StringComparison.Ordinal))
                {
                    editor.SelectAll();
                    editor.SelectedRtf = anterior;
                }
                editor.Modified = modificado;
            }
            throw new InvalidOperationException("No se pudo comprobar la ortografía de la especificación.\n\n" + Mensaje(ex), ex);
        }
        finally
        {
            EliminarCarpetaTemporal(carpeta);
            if (!editor.IsDisposed)
            {
                int inicio = Math.Min(posicion, editor.TextLength);
                editor.Select(inicio, Math.Min(longitud, editor.TextLength - inicio));
            }
            if (owner is Control ventana && !ventana.IsDisposed)
                ventana.FindForm()?.Activate();
        }
    }

    private static byte[] ObtenerMetarchivo(RichTextBox editor, Image imagen)
    {
        using var memoria = new MemoryStream();
        using var referencia = editor.CreateGraphics();
        Metafile metarchivo;
        var hdc = referencia.GetHdc();
        try { metarchivo = new Metafile(memoria, hdc, EmfType.EmfPlusDual); }
        finally { referencia.ReleaseHdc(hdc); }
        using (metarchivo)
        {
            using (var dibujo = Graphics.FromImage(metarchivo))
                dibujo.DrawImage(imagen, new Rectangle(0, 0, imagen.Width, imagen.Height));
            var hemf = metarchivo.GetHenhmetafile();
            try
            {
                var longitud = GdipEmfToWmfBits(hemf, 0, null, 8, 0);
                if (longitud == 0 || longitud > 64 * 1024 * 1024)
                    throw new InvalidOperationException("No se pudo convertir la imagen para el editor.");
                var bytes = new byte[longitud];
                if (GdipEmfToWmfBits(hemf, longitud, bytes, 8, 0) != longitud)
                    throw new InvalidOperationException("No se pudo completar la conversión de la imagen.");
                return bytes;
            }
            finally { DeleteEnhMetaFile(hemf); }
        }
    }

    private static int FormatearPagina(RichTextBox editor, PrintPageEventArgs e, Rectangle contenido, int inicio, int fin)
    {
        var hdc = e.Graphics.GetHdc();
        try
        {
            var rango = new FormatRange
            {
                Hdc = hdc, HdcTarget = hdc,
                Pagina = RectanguloTwips(e.PageBounds, e.PageSettings.HardMarginX, e.PageSettings.HardMarginY),
                Contenido = RectanguloTwips(contenido, e.PageSettings.HardMarginX, e.PageSettings.HardMarginY),
                Caracteres = new CharacterRange { Inicio = inicio, Fin = fin }
            };
            return (int)SendMessageFormato(editor.Handle, EmFormatRange, new IntPtr(1), ref rango);
        }
        finally { e.Graphics.ReleaseHdc(hdc); }
    }

    private static RectanguloNativo RectanguloTwips(Rectangle rectangulo, float margenX, float margenY) => new()
    {
        Izquierda = (int)Math.Round((rectangulo.Left - margenX) * 14.4),
        Superior = (int)Math.Round((rectangulo.Top - margenY) * 14.4),
        Derecha = (int)Math.Round((rectangulo.Right - margenX) * 14.4),
        Inferior = (int)Math.Round((rectangulo.Bottom - margenY) * 14.4)
    };

    private static void DibujarEncabezadoPie(PrintPageEventArgs e, string encabezado, string pie, int numero, int reserva)
    {
        using var fuente = new Font("Arial Narrow", 9);
        using var formato = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter };
        var ancho = e.MarginBounds.Width;
        var x = e.MarginBounds.X - e.PageSettings.HardMarginX;
        var y = e.MarginBounds.Y - e.PageSettings.HardMarginY;
        if (!string.IsNullOrEmpty(encabezado))
            e.Graphics.DrawString(encabezado, fuente, Brushes.Black, new RectangleF(x, y, ancho, reserva), formato);
        if (!string.IsNullOrEmpty(pie) || numero > 0)
        {
            var texto = pie ?? "";
            if (numero > 0) texto += (texto.Length > 0 ? "   ·   " : "") + "Página " + numero.ToString(CultureInfo.CurrentCulture);
            formato.Alignment = StringAlignment.Far;
            e.Graphics.DrawString(texto, fuente, Brushes.Black, new RectangleF(x, e.MarginBounds.Bottom - e.PageSettings.HardMarginY - reserva, ancho, reserva), formato);
        }
    }

    private static void LiberarFormato(RichTextBox editor)
    {
        if (editor.IsHandleCreated && !editor.IsDisposed)
            SendMessage(editor.Handle, EmFormatRange, IntPtr.Zero, IntPtr.Zero);
    }

    private static void ConvertirConWord(string origen, string destino, int formato, PageSettings pagina,
        string encabezado, string pie, bool numeroPagina)
    {
        var tipo = Type.GetTypeFromProgID("Word.Application");
        if (tipo == null)
            throw new InvalidOperationException("Para abrir o guardar .doc y .docx se necesita Microsoft Word instalado en Windows. Puede abrir y guardar RTF sin Word.");
        object aplicacion = null, documentos = null, documento = null;
        try
        {
            aplicacion = Activator.CreateInstance(tipo);
            dynamic word = aplicacion;
            word.Visible = false;
            word.DisplayAlerts = 0;
            word.AutomationSecurity = 3; // msoAutomationSecurityForceDisable: no ejecutar macros.
            documentos = word.Documents;
            documento = ((dynamic)documentos).Open(FileName: origen, ConfirmConversions: false, ReadOnly: true,
                AddToRecentFiles: false, Visible: false, NoEncodingDialog: true);
            if (formato == FormatoWord97 || formato == FormatoWordXml)
            {
                ConfigurarPaginaWord(documento, pagina, !string.IsNullOrEmpty(encabezado), !string.IsNullOrEmpty(pie) || numeroPagina);
                ConfigurarEncabezadosWord(documento, encabezado, pie, numeroPagina);
            }
            ((dynamic)documento).SaveAs2(FileName: destino, FileFormat: formato, AddToRecentFiles: false);
            if (!File.Exists(destino) || new FileInfo(destino).Length == 0)
                throw new IOException("Word no generó un documento válido.");
        }
        finally
        {
            if (documento != null)
            {
                try { ((dynamic)documento).Close(SaveChanges: 0); } catch (Exception) { }
                LiberarCom(documento);
            }
            LiberarCom(documentos);
            if (aplicacion != null)
            {
                try { ((dynamic)aplicacion).Quit(SaveChanges: 0); } catch (Exception) { }
                LiberarCom(aplicacion);
            }
        }
    }

    private static void ConfigurarPaginaWord(object documento, PageSettings pagina, bool reservarEncabezado, bool reservarPie)
    {
        if (pagina == null) return;
        object configuracion = null;
        try
        {
            configuracion = ((dynamic)documento).PageSetup;
            dynamic ajuste = configuracion;
            ajuste.Orientation = pagina.Landscape ? 1 : 0;
            ajuste.PageWidth = pagina.Bounds.Width * .72f;
            ajuste.PageHeight = pagina.Bounds.Height * .72f;
            ajuste.TopMargin = (pagina.Margins.Top + (reservarEncabezado ? 34 : 0)) * .72f;
            ajuste.BottomMargin = (pagina.Margins.Bottom + (reservarPie ? 34 : 0)) * .72f;
            ajuste.HeaderDistance = pagina.Margins.Top * .72f;
            ajuste.FooterDistance = pagina.Margins.Bottom * .72f;
            ajuste.LeftMargin = pagina.Margins.Left * .72f;
            ajuste.RightMargin = pagina.Margins.Right * .72f;
        }
        finally { LiberarCom(configuracion); }
    }

    private static void ConfigurarEncabezadosWord(object documento, string encabezado, string pie, bool numeroPagina)
    {
        if (string.IsNullOrEmpty(encabezado) && string.IsNullOrEmpty(pie) && !numeroPagina) return;
        object secciones = null;
        try
        {
            secciones = ((dynamic)documento).Sections;
            var cantidad = (int)((dynamic)secciones).Count;
            for (int i = 1; i <= cantidad; i++)
            {
                object seccion = null;
                try
                {
                    seccion = ((dynamic)secciones).Item(i);
                    if (!string.IsNullOrEmpty(encabezado)) AsignarEncabezadoPie(seccion, false, encabezado, false);
                    if (!string.IsNullOrEmpty(pie) || numeroPagina) AsignarEncabezadoPie(seccion, true, pie, numeroPagina);
                }
                finally { LiberarCom(seccion); }
            }
        }
        finally { LiberarCom(secciones); }
    }

    private static void AsignarEncabezadoPie(object seccion, bool esPie, string texto, bool numeroPagina)
    {
        object elementos = null, elemento = null, rango = null, campos = null, campo = null, fuente = null, parrafo = null;
        try
        {
            elementos = esPie ? ((dynamic)seccion).Footers : ((dynamic)seccion).Headers;
            elemento = ((dynamic)elementos).Item(1); // wdHeaderFooterPrimary.
            rango = ((dynamic)elemento).Range;
            ((dynamic)rango).Text = (texto ?? "") + (numeroPagina ? (string.IsNullOrEmpty(texto) ? "Página " : "   ·   Página ") : "");
            fuente = ((dynamic)rango).Font;
            ((dynamic)fuente).Name = "Arial";
            ((dynamic)fuente).Size = 9f;
            parrafo = ((dynamic)rango).ParagraphFormat;
            ((dynamic)parrafo).Alignment = esPie ? 2 : 0;
            if (numeroPagina)
            {
                // Mantener el campo antes de la marca final del párrafo del pie.
                if ((int)((dynamic)rango).End > (int)((dynamic)rango).Start)
                    ((dynamic)rango).End = (int)((dynamic)rango).End - 1;
                ((dynamic)rango).Collapse(0); // wdCollapseEnd.
                campos = ((dynamic)rango).Fields;
                campo = ((dynamic)campos).Add(Range: rango, Type: 33); // wdFieldPage.
                ((dynamic)campo).Update();
            }
        }
        finally
        {
            LiberarCom(campo); LiberarCom(campos); LiberarCom(parrafo); LiberarCom(fuente);
            LiberarCom(rango); LiberarCom(elemento); LiberarCom(elementos);
        }
    }

    private static void LiberarCom(object objeto)
    {
        if (objeto != null && Marshal.IsComObject(objeto)) Marshal.FinalReleaseComObject(objeto);
    }

    private static string CrearCarpetaTemporal()
    {
        var ruta = Path.Combine(Path.GetTempPath(), "MYG-Especificaciones-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(ruta);
        return ruta;
    }

    private static void EliminarArchivoTemporal(string ruta)
    {
        if (string.IsNullOrEmpty(ruta)) return;
        try { File.Delete(ruta); } catch (IOException) { } catch (UnauthorizedAccessException) { }
    }

    private static void EliminarCarpetaTemporal(string ruta)
    {
        if (string.IsNullOrEmpty(ruta)) return;
        try { Directory.Delete(ruta, true); } catch (IOException) { } catch (UnauthorizedAccessException) { }
    }

    private static string Mensaje(Exception ex)
    {
        if (ex is System.Reflection.TargetInvocationException && ex.InnerException != null) return Mensaje(ex.InnerException);
        return ex.Message;
    }

    private static List<int> ObtenerSaltosPagina(RichTextBox editor)
    {
        var resultado = new List<int>();
        var texto = editor.Text;
        for (int i = 0; i < texto.Length; i++)
        {
            if (i == 0 || texto[i - 1] != '\n') continue;
            editor.Select(i, 0);
            if (TieneSaltoAntes(editor))
            {
                resultado.Add(i);
                // Esta copia se imprime con límites explícitos: evita aplicar el salto dos veces.
                var formato = CrearFormatoParrafo();
                formato.Mascara = PfmPageBreakBefore;
                SendMessageParrafo(editor.Handle, EmSetParaFormat, IntPtr.Zero, ref formato);
            }
        }
        editor.Select(0, 0);
        return resultado;
    }

    private static bool TieneSaltoAntes(RichTextBox editor)
    {
        var formato = CrearFormatoParrafo();
        SendMessageParrafo(editor.Handle, EmGetParaFormat, IntPtr.Zero, ref formato);
        return (formato.Mascara & PfmPageBreakBefore) != 0 && (formato.Efectos & PfePageBreakBefore) != 0;
    }

    private static FormatoParrafo CrearFormatoParrafo() => new()
    {
        Tamano = (uint)Marshal.SizeOf<FormatoParrafo>(), Tabulaciones = new int[32]
    };

    private static string EscaparRtf(string texto)
    {
        var resultado = new StringBuilder(texto.Length);
        for (int i = 0; i < texto.Length; i++)
        {
            var caracter = texto[i];
            switch (caracter)
            {
                case '\\': case '{': case '}': resultado.Append('\\').Append(caracter); break;
                case '\t': resultado.Append(@"\tab "); break;
                case '\r':
                    if (i + 1 < texto.Length && texto[i + 1] == '\n') i++;
                    resultado.Append(@"\line "); break;
                case '\n': resultado.Append(@"\line "); break;
                default:
                    if (caracter is >= ' ' and <= '~') resultado.Append(caracter);
                    else resultado.Append(@"\u").Append(unchecked((short)caracter).ToString(CultureInfo.InvariantCulture)).Append('?');
                    break;
            }
        }
        return resultado.ToString();
    }

    private static readonly HashSet<string> ControlesPagina = new(StringComparer.Ordinal)
    {
        "paperw", "paperh", "margl", "margr", "margt", "margb", "landscape", "headery", "footery",
        "pgwsxn", "pghsxn", "marglsxn", "margrsxn", "margtsxn", "margbsxn", "lndscpsxn"
    };
    private static readonly HashSet<string> DestinosEncabezadoPie = new(StringComparer.Ordinal)
    {
        "header", "headerl", "headerr", "headerf", "footer", "footerl", "footerr", "footerf"
    };

    private static int InicioCuerpoRtf(string rtf)
    {
        var profundidad = 0;
        for (int i = 0; i < rtf.Length;)
        {
            if (rtf[i] == '{') { profundidad++; i++; }
            else if (rtf[i] == '}') { if (profundidad == 1) return i; profundidad--; i++; }
            else if (rtf[i] == '\\')
            {
                var token = LeerTokenRtf(rtf, i);
                if (profundidad == 1 && token.Nombre is "pard" or "plain" or "sectd" or "trowd" or "par" or "tab" or "line" or "page" or "'" or "{" or "}" or "\\" or "~")
                    return i;
                i = token.Fin;
                if (token.Nombre == "bin") i += token.Numero ?? 0;
            }
            else { if (profundidad == 1 && !char.IsWhiteSpace(rtf[i])) return i; i++; }
        }
        throw new InvalidOperationException("No se pudo localizar el contenido del documento RTF.");
    }

    // Examinar tokens evita modificar texto escapado, imágenes y metadatos al sustituir la configuración.
    private static string LimpiarConfiguracionRtf(string rtf)
    {
        var salida = new StringBuilder(rtf.Length);
        var profundidad = 0;
        for (int i = 0; i < rtf.Length;)
        {
            var caracter = rtf[i];
            if (caracter == '{')
            {
                if (profundidad == 1 && EsEncabezadoPie(rtf, i)) { i = FinGrupoRtf(rtf, i); continue; }
                profundidad++;
                salida.Append(caracter); i++;
            }
            else if (caracter == '}')
            {
                if (--profundidad < 0) throw new InvalidOperationException("El documento RTF contiene grupos inválidos.");
                salida.Append(caracter); i++;
            }
            else if (caracter == '\\')
            {
                var token = LeerTokenRtf(rtf, i);
                if (profundidad != 1 || !ControlesPagina.Contains(token.Nombre)) salida.Append(rtf, i, token.Fin - i);
                i = token.Fin;
                if (token.Nombre == "bin")
                {
                    var cantidad = token.Numero ?? throw new InvalidOperationException("El documento RTF contiene datos binarios inválidos.");
                    if (cantidad < 0 || cantidad > rtf.Length - i) throw new InvalidOperationException("El documento RTF contiene datos binarios incompletos.");
                    salida.Append(rtf, i, cantidad); i += cantidad;
                }
            }
            else { salida.Append(caracter); i++; }
        }
        if (profundidad != 0) throw new InvalidOperationException("El documento RTF contiene grupos incompletos.");
        return salida.ToString();
    }

    private static bool EsEncabezadoPie(string rtf, int inicio)
    {
        var posicion = inicio + 1;
        while (posicion < rtf.Length && char.IsWhiteSpace(rtf[posicion])) posicion++;
        if (posicion >= rtf.Length || rtf[posicion] != '\\') return false;
        var token = LeerTokenRtf(rtf, posicion);
        if (token.Nombre == "*" && token.Fin < rtf.Length && rtf[token.Fin] == '\\')
            token = LeerTokenRtf(rtf, token.Fin);
        return DestinosEncabezadoPie.Contains(token.Nombre);
    }

    private static int FinGrupoRtf(string rtf, int inicio)
    {
        var profundidad = 0;
        for (int i = inicio; i < rtf.Length;)
        {
            if (rtf[i] == '{') { profundidad++; i++; }
            else if (rtf[i] == '}') { i++; if (--profundidad == 0) return i; }
            else if (rtf[i] == '\\')
            {
                var token = LeerTokenRtf(rtf, i);
                i = token.Fin;
                if (token.Nombre == "bin")
                {
                    var cantidad = token.Numero ?? -1;
                    if (cantidad < 0 || cantidad > rtf.Length - i) throw new InvalidOperationException("El documento RTF contiene datos binarios incompletos.");
                    i += cantidad;
                }
            }
            else i++;
        }
        throw new InvalidOperationException("El documento RTF contiene un encabezado o pie incompleto.");
    }

    private readonly record struct TokenRtf(string Nombre, int? Numero, int Fin);

    private static TokenRtf LeerTokenRtf(string rtf, int inicio)
    {
        var posicion = inicio + 1;
        if (posicion >= rtf.Length) throw new InvalidOperationException("El documento RTF termina en un control incompleto.");
        if (rtf[posicion] == '\'')
        {
            if (posicion + 2 >= rtf.Length) throw new InvalidOperationException("El documento RTF contiene un carácter hexadecimal incompleto.");
            return new TokenRtf("'", null, posicion + 3);
        }
        if (!char.IsAsciiLetter(rtf[posicion])) return new TokenRtf(rtf[posicion].ToString(), null, posicion + 1);
        var inicioNombre = posicion;
        while (posicion < rtf.Length && char.IsAsciiLetter(rtf[posicion])) posicion++;
        var nombre = rtf[inicioNombre..posicion];
        var inicioNumero = posicion;
        if (posicion < rtf.Length && rtf[posicion] == '-' && posicion + 1 < rtf.Length && char.IsAsciiDigit(rtf[posicion + 1])) posicion++;
        while (posicion < rtf.Length && char.IsAsciiDigit(rtf[posicion])) posicion++;
        int? numero = null;
        if (posicion > inicioNumero)
        {
            if (!int.TryParse(rtf.AsSpan(inicioNumero, posicion - inicioNumero), NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out var valor))
                throw new InvalidOperationException("El documento RTF contiene un parámetro numérico inválido.");
            numero = valor;
        }
        if (posicion < rtf.Length && rtf[posicion] == ' ') posicion++;
        return new TokenRtf(nombre, numero, posicion);
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct CharacterRange { internal int Inicio, Fin; }
    [StructLayout(LayoutKind.Sequential)]
    private struct RectanguloNativo { internal int Izquierda, Superior, Derecha, Inferior; }
    [StructLayout(LayoutKind.Sequential)]
    private struct FormatRange
    {
        internal IntPtr Hdc, HdcTarget;
        internal RectanguloNativo Contenido, Pagina;
        internal CharacterRange Caracteres;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct FormatoParrafo
    {
        internal uint Tamano, Mascara;
        internal ushort Numeracion, Efectos;
        internal int SangriaInicial, SangriaDerecha, Desplazamiento;
        internal ushort Alineacion;
        internal short NumeroTabulaciones;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)] internal int[] Tabulaciones;
        internal int EspacioAntes, EspacioDespues, EspacioLineas;
        internal short Estilo;
        internal byte ReglaLineas, Nivel;
        internal ushort SombraPeso, SombraEstilo, NumeroInicial, NumeroEstilo, NumeroTabulacion, BordeEspacio, BordeAncho, Bordes;
    }

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessageFormato(IntPtr hwnd, int mensaje, IntPtr parametro, ref FormatRange rango);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr hwnd, int mensaje, IntPtr parametro, IntPtr datos);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessageParrafo(IntPtr hwnd, int mensaje, IntPtr parametro, ref FormatoParrafo formato);
    [DllImport("gdiplus.dll", ExactSpelling = true)]
    private static extern uint GdipEmfToWmfBits(IntPtr hemf, uint longitud, [Out] byte[] buffer, int modoMapeo, int indicadores);
    [DllImport("gdi32.dll", ExactSpelling = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DeleteEnhMetaFile(IntPtr hemf);
}
