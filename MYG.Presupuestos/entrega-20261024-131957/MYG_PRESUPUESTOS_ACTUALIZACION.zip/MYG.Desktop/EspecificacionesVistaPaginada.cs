using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace MYG_2027;

// Conserva los metaficheros vectoriales de impresión. La navegación cambia
// hojas completas, sin una superficie RichEdit desplazable ni bitmaps por página.
internal sealed class MYGEspecificacionesVistaPaginada : UserControl
{
    private readonly LienzoPaginas vista;
    private readonly ToolStrip barra = new()
    {
        Name = "espec_previa_navegacion", Dock = DockStyle.Top,
        GripStyle = ToolStripGripStyle.Hidden, CanOverflow = true
    };
    private readonly ToolStripButton primera, anterior, siguiente, ultima, unaPagina, dosPaginas;
    private readonly ToolStripLabel contador = new()
    {
        Name = "espec_previa_contador", Text = "Página 0 de 0",
        AccessibleName = "Página actual y cantidad de páginas"
    };
    private readonly Label mensaje = new()
    {
        Name = "espec_previa_mensaje", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter,
        Padding = new Padding(24), Text = "No hay un documento para previsualizar.",
        AccessibleName = "Estado de la vista de páginas"
    };
    private PrintDocument documento;
    private PreviewPageInfo[] paginas = Array.Empty<PreviewPageInfo>();
    private int paginaActual, columnas = 1, revision;
    private long deltaRueda;
    private bool generando, programado, cerrando;

    internal int PaginaActual => paginaActual;
    internal int CantidadPaginas => paginas.Length;
    internal Control Vista => vista;
    internal int Columnas => columnas;
    internal bool AjustarPagina => true;

    internal MYGEspecificacionesVistaPaginada()
    {
        Name = "espec_vista_paginada";
        AccessibleName = "Vista paginada de especificaciones técnicas";
        Dock = DockStyle.Fill;
        AutoScroll = false;
        vista = new LienzoPaginas(this)
        {
            Name = "espec_previa_paginas", Dock = DockStyle.Fill, TabStop = true,
            AccessibleName = "Páginas de las especificaciones técnicas", Visible = false
        };
        primera = Boton("|◀", "primera", () => IrAPagina(1), "Primera página");
        anterior = Boton("◀ Anterior", "anterior", () => IrAPagina(paginaActual - 1), "Página anterior");
        siguiente = Boton("Siguiente ▶", "siguiente", () => IrAPagina(paginaActual + 1), "Página siguiente");
        ultima = Boton("▶|", "ultima", () => IrAPagina(paginas.Length), "Última página");
        unaPagina = Boton("Una página", "una_pagina", () => MostrarPaginas(1));
        dosPaginas = Boton("Dos páginas", "dos_paginas", () => MostrarPaginas(2));
        unaPagina.Checked = true;
        barra.Items.AddRange(new ToolStripItem[]
        {
            primera, anterior, contador, siguiente, ultima, new ToolStripSeparator(), unaPagina, dosPaginas
        });
        var cuerpo = new Panel { Dock = DockStyle.Fill, Name = "espec_previa_superficie" };
        cuerpo.Controls.Add(vista);
        cuerpo.Controls.Add(mensaje);
        Controls.Add(cuerpo);
        Controls.Add(barra);
        HandleCreated += (_, _) => ProgramarGeneracion();
        VisibleChanged += (_, _) => ProgramarGeneracion();
        MYG2027_TemaComercial.CambioTema += CambioTema;
        AplicarTema();
        ActualizarNavegacion();
    }

    private static ToolStripButton Boton(string texto, string nombre, Action ejecutar, string nombreAccesible = null)
    {
        var boton = new ToolStripButton(texto)
        {
            Name = "espec_previa_" + nombre, DisplayStyle = ToolStripItemDisplayStyle.Text,
            AccessibleName = nombreAccesible ?? texto, ToolTipText = nombreAccesible ?? texto, AutoToolTip = false
        };
        boton.Click += (_, _) => ejecutar();
        return boton;
    }

    // El control toma propiedad del PrintDocument y de su copia de impresión.
    internal void Cargar(PrintDocument nuevo)
    {
        ArgumentNullException.ThrowIfNull(nuevo);
        if (IsDisposed || cerrando) throw new ObjectDisposedException(nameof(MYGEspecificacionesVistaPaginada));
        if (!ReferenceEquals(documento, nuevo))
        {
            LiberarDocumento();
            documento = nuevo;
        }
        else
        {
            revision++;
            programado = false;
            LiberarPaginas();
        }
        paginaActual = 0;
        deltaRueda = 0;
        vista.Visible = false;
        mensaje.Text = "Preparando páginas…";
        mensaje.AccessibleDescription = mensaje.Text;
        mensaje.Visible = true;
        ActualizarNavegacion();
        ProgramarGeneracion();
    }

    private void ProgramarGeneracion()
    {
        if (cerrando || IsDisposed || Disposing || !IsHandleCreated || !Visible ||
            documento == null || paginas.Length > 0 || generando || programado) return;
        int version = revision;
        programado = true;
        try
        {
            BeginInvoke(new Action(() =>
            {
                if (cerrando || IsDisposed || Disposing || revision != version) return;
                programado = false;
                if (Visible && documento != null) GenerarPaginas(documento, version);
            }));
        }
        catch (InvalidOperationException) when (IsDisposed || Disposing || !IsHandleCreated)
        { programado = false; }
    }

    private void GenerarPaginas(PrintDocument actual, int version)
    {
        if (generando || version != revision || !ReferenceEquals(actual, documento)) return;
        generando = true;
        var controlador = new PreviewPrintController { UseAntiAlias = true };
        PrintController anteriorControlador = actual.PrintController;
        PreviewPageInfo[] generadas = Array.Empty<PreviewPageInfo>();
        Exception fallo = null;
        try
        {
            if (!actual.PrinterSettings.IsValid) throw new InvalidPrinterException(actual.PrinterSettings);
            // Sólo genera EMF en memoria: nunca envía trabajos al dispositivo.
            actual.PrintController = controlador;
            actual.Print();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException) { fallo = ex; }
        finally
        {
            actual.PrintController = anteriorControlador;
            generadas = controlador.GetPreviewPageInfo();
            generando = false;
        }

        if (cerrando || IsDisposed || version != revision || !ReferenceEquals(actual, documento))
        {
            LiberarImagenes(generadas);
            ProgramarGeneracion();
            return;
        }
        if (fallo != null || generadas.Length == 0)
        {
            LiberarImagenes(generadas);
            MostrarError(fallo is InvalidPrinterException
                ? "No hay una impresora disponible para preparar las páginas. Configure una impresora en Windows, por ejemplo Microsoft Print to PDF."
                : fallo != null ? "No se pudo generar el documento paginado. " + fallo.Message
                : "El documento no contiene páginas para mostrar.");
            return;
        }
        paginas = generadas;
        paginaActual = 1;
        mensaje.Visible = false;
        vista.Visible = true;
        vista.Invalidate();
        ActualizarNavegacion();
    }

    internal void LiberarDocumento()
    {
        revision++;
        programado = false;
        var anteriorDocumento = documento;
        documento = null;
        LiberarPaginas();
        paginaActual = 0;
        deltaRueda = 0;
        anteriorDocumento?.Dispose();
        if (!cerrando)
        {
            vista.Visible = false;
            mensaje.Text = "No hay un documento para previsualizar.";
            mensaje.Visible = true;
            ActualizarNavegacion();
        }
    }

    private void LiberarPaginas()
    {
        var anteriores = paginas;
        paginas = Array.Empty<PreviewPageInfo>();
        LiberarImagenes(anteriores);
        vista.Invalidate();
    }

    private static void LiberarImagenes(PreviewPageInfo[] imagenes)
    {
        foreach (var pagina in imagenes) pagina.Image?.Dispose();
    }

    internal void MostrarError(string texto)
    {
        if (IsDisposed || cerrando) return;
        LiberarDocumento();
        mensaje.Text = string.IsNullOrWhiteSpace(texto) ? "No se pudo generar la vista de páginas." : texto;
        mensaje.AccessibleDescription = mensaje.Text;
        mensaje.Visible = true;
        mensaje.BringToFront();
    }

    internal void IrAPagina(int pagina)
    {
        if (paginas.Length == 0 || IsDisposed || cerrando) return;
        paginaActual = Math.Clamp(pagina, 1, paginas.Length);
        vista.Invalidate();
        ActualizarNavegacion();
    }

    internal void NavegarRueda(int delta)
    {
        if (delta == 0 || paginas.Length == 0) return;
        // Acumular fracciones evita saltos por cada evento de un trackpad.
        // El resto queda entre -119 y 119; long evita overflow en deltas extremos.
        deltaRueda += delta;
        long pasos = deltaRueda / 120;
        deltaRueda %= 120;
        if (pasos == 0) return;
        IrAPagina((int)Math.Clamp(paginaActual - pasos, 1, paginas.Length));
    }

    private void NavegarTecla(Keys tecla)
    {
        if (tecla == Keys.Home) IrAPagina(1);
        else if (tecla == Keys.End) IrAPagina(paginas.Length);
        else IrAPagina(paginaActual + (tecla is Keys.PageUp or Keys.Left or Keys.Up ? -1 : 1));
    }

    private static bool EsNavegacion(Keys tecla) => tecla is Keys.PageUp or Keys.PageDown or Keys.Home or Keys.End
        or Keys.Left or Keys.Right or Keys.Up or Keys.Down;

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (EsNavegacion(keyData)) { NavegarTecla(keyData); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }

    private void MostrarPaginas(int cantidad)
    {
        columnas = cantidad;
        unaPagina.Checked = cantidad == 1;
        dosPaginas.Checked = cantidad == 2;
        vista.Invalidate();
    }

    private void ActualizarNavegacion()
    {
        contador.Text = "Página " + paginaActual + " de " + paginas.Length;
        contador.AccessibleDescription = contador.Text;
        primera.Enabled = anterior.Enabled = paginaActual > 1;
        siguiente.Enabled = ultima.Enabled = paginaActual > 0 && paginaActual < paginas.Length;
        unaPagina.Enabled = dosPaginas.Enabled = paginas.Length > 0;
    }

    private void DibujarPaginas(Graphics g, Size tamano)
    {
        if (paginas.Length == 0 || paginaActual == 0) return;
        int visibles = Math.Min(columnas, paginas.Length - paginaActual + 1);
        float margen = 24 * vista.DeviceDpi / 96f, separacion = margen;
        float ancho = Math.Max(1, (tamano.Width - 2 * margen - separacion * (visibles - 1)) / visibles);
        float alto = Math.Max(1, tamano.Height - 2 * margen);
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        using var sombra = new SolidBrush(Color.FromArgb(48, Color.Black));
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        for (int i = 0; i < visibles; i++)
        {
            var pagina = paginas[paginaActual - 1 + i];
            var papel = pagina.PhysicalSize;
            float factor = Math.Min(ancho / Math.Max(1, papel.Width), alto / Math.Max(1, papel.Height));
            float anchura = Math.Max(1, papel.Width * factor), altura = Math.Max(1, papel.Height * factor);
            var hoja = new RectangleF(margen + i * (ancho + separacion) + (ancho - anchura) / 2,
                margen + (alto - altura) / 2, anchura, altura);
            g.FillRectangle(sombra, hoja.X + 3, hoja.Y + 3, hoja.Width, hoja.Height);
            g.FillRectangle(Brushes.White, hoja);
            g.DrawImage(pagina.Image, hoja);
            g.DrawRectangle(borde, hoja.X, hoja.Y, hoja.Width, hoja.Height);
        }
    }

    private void ErrorDibujo(Exception error)
    {
        int version = revision;
        if (!IsHandleCreated || cerrando || IsDisposed) return;
        try
        {
            BeginInvoke(new Action(() =>
            {
                if (!cerrando && !IsDisposed && version == revision)
                    MostrarError("No se pudo mostrar el documento paginado. " + error.Message);
            }));
        }
        catch (InvalidOperationException) when (IsDisposed || Disposing || !IsHandleCreated) { }
    }

    private void CambioTema(object sender, EventArgs e) => AplicarTema();

    private void AplicarTema()
    {
        BackColor = vista.BackColor = MYG2027_TemaComercial.Fondo;
        ForeColor = mensaje.ForeColor = barra.ForeColor = MYG2027_TemaComercial.Texto;
        mensaje.BackColor = barra.BackColor = MYG2027_TemaComercial.Superficie;
        vista.Invalidate();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && !cerrando)
        {
            cerrando = true;
            MYG2027_TemaComercial.CambioTema -= CambioTema;
            LiberarDocumento();
        }
        base.Dispose(disposing);
    }

    private sealed class LienzoPaginas : Control
    {
        private readonly MYGEspecificacionesVistaPaginada propietario;

        internal LienzoPaginas(MYGEspecificacionesVistaPaginada propietario)
        {
            this.propietario = propietario;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            ResizeRedraw = true;
        }

        protected override void OnMouseDown(MouseEventArgs e)
        { Focus(); base.OnMouseDown(e); }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            if (CanFocus) Focus();
            propietario.NavegarRueda(e.Delta);
            if (e is HandledMouseEventArgs manejado) manejado.Handled = true;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (EsNavegacion(keyData)) { propietario.NavegarTecla(keyData); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            try { propietario.DibujarPaginas(e.Graphics, ClientSize); }
            catch (Exception ex) when (ex is not OutOfMemoryException) { propietario.ErrorDibujo(ex); }
        }
    }
}
