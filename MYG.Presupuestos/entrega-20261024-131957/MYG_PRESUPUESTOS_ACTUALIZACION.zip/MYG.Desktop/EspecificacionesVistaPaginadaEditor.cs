using System;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGEspecificacionesEditor
{
    private MYGEspecificacionesVistaPaginada vistaPaginada;
    private bool vistaPaginadaActiva, actualizacionPaginadaPendiente;
    private bool reglaVerticalAntesPrevia = true;
    private string rtfVistaPaginada;

    private void PrepararVistaPaginadaExportacion()
    {
        if (vistaPaginada != null) return;
        vistaPaginada = new MYGEspecificacionesVistaPaginada { Dock = DockStyle.Fill, Visible = false };
        lienzo.Parent.Controls.Add(vistaPaginada);
        cinta.SelectedIndexChanged += (_, _) => ActualizarModoVistaPaginada();
        documento.TextChanged += (_, _) => ProgramarActualizacionVistaPaginada();
        ActualizarModoVistaPaginada();
    }

    private void ActualizarModoVistaPaginada()
    {
        if (vistaPaginada == null || IsDisposed || Disposing) return;
        bool mostrar = modoExportacion && cinta.SelectedIndex == 0;
        if (mostrar && !vistaPaginadaActiva)
        {
            CancelarArrastreMargenes(); DetenerZoom();
            if (lienzo.Visible) reglaVerticalAntesPrevia = reglaVertical.Visible;
        }
        vistaPaginadaActiva = mostrar;
        lienzo.Visible = !mostrar;
        regla.Visible = !mostrar && verRegla.Checked;
        reglaVertical.Visible = !mostrar && reglaVerticalAntesPrevia;
        vistaPaginada.Visible = mostrar;
        if (mostrar)
        {
            vistaPaginada.BringToFront();
            ActualizarDocumentoVistaPaginada();
        }
        else
        {
            // No retener la copia y las imágenes de impresión mientras se edita.
            vistaPaginada.LiberarDocumento();
            rtfVistaPaginada = null;
            ActualizarVista();
        }
    }

    private void ActualizarDocumentoVistaPaginada()
    {
        if (!vistaPaginadaActiva || vistaPaginada == null || IsDisposed || Disposing) return;
        string rtf = DocumentoRtf;
        if (rtf == rtfVistaPaginada) return;
        try
        {
            // La misma copia, márgenes y saltos que la impresión real. Navegar
            // sólo cambia StartPage: no recorta ni reescribe el RTF del usuario.
            vistaPaginada.Cargar(MYGEspecificacionesDocumento.CrearDocumentoImpresion(documento,
                titulo(), ConfiguracionImpresion(), pagina.Encabezado, pagina.Pie, pagina.NumerarPaginas));
            rtfVistaPaginada = rtf;
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            vistaPaginada.MostrarError("No se pudo preparar la vista por páginas. " + ex.Message);
        }
    }

    private void ProgramarActualizacionVistaPaginada()
    {
        if (!vistaPaginadaActiva || actualizacionPaginadaPendiente || !IsHandleCreated || IsDisposed || Disposing) return;
        actualizacionPaginadaPendiente = true;
        BeginInvoke(new Action(() =>
        {
            actualizacionPaginadaPendiente = false;
            if (!IsDisposed && !Disposing) ActualizarDocumentoVistaPaginada();
        }));
    }

    private void MostrarVistaPreliminarPaginada()
    {
        // Una petición explícita también reintenta después de configurar una
        // impresora o corregir un fallo, aunque no haya cambiado el contenido.
        rtfVistaPaginada = null;
        cinta.SelectedIndex = 0;
        ActualizarModoVistaPaginada();
        vistaPaginada?.Focus();
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (vistaPaginadaActiva && keyData == (Keys.Control | Keys.S))
        { Intentar(() => guardarExportacion?.Invoke()); return true; }
        if (vistaPaginadaActiva && keyData == (Keys.Control | Keys.P))
        { Intentar(() => Imprimir(false)); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }
}
