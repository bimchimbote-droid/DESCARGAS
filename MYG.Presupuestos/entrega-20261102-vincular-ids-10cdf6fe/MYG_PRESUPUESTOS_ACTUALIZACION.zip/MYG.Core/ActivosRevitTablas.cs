using MYG.Externo;

namespace MYG_2027;

/// <summary>Prepara exclusivamente las tablas asignadas al modelo reconocido de una obra.</summary>
public static class MYGTablasActivosRevit
{
    /// <summary>Obtiene una referencia editable; no registra ni vincula el activo a una obra.</summary>
    public static MYGActivoRevit ReferenciaDesdeModelo(DocumentoRevitInfo documento)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (!Enum.IsDefined(documento.Origen) || string.IsNullOrWhiteSpace(documento.Nombre))
            throw new InvalidDataException("Revit no devolvió la información completa del modelo. Actualice el conector y vuelva a consultar.");
        if (documento.EsModeloSeparado)
            throw new InvalidDataException("El modelo está separado del central. Guárdelo como un archivo independiente antes de registrar su referencia.");
        var referencia = new MYGActivoRevit { Nombre = documento.Nombre.Trim(), Origen = documento.Origen };
        if (documento.Origen == MYGOrigenActivoRevit.Autodesk)
        {
            referencia.ProyectoAutodeskId = GuidAutodesk(documento.ProyectoAutodeskId, true);
            referencia.ModeloAutodeskId = GuidAutodesk(documento.ModeloAutodeskId, false);
            if (referencia.ProyectoAutodeskId == null || referencia.ModeloAutodeskId == null)
                throw new InvalidDataException("El modelo de nube no devolvió ambos GUID de Autodesk. Actualice el conector; no use una URL o un identificador de versión.");
        }
        else
        {
            if (!string.IsNullOrWhiteSpace(documento.ProyectoAutodeskId) || !string.IsNullOrWhiteSpace(documento.ModeloAutodeskId))
                throw new InvalidDataException("El conector devolvió un origen local con identificadores Autodesk. Actualice el conector y vuelva a consultar.");
            referencia.RutaLocal = RutaReferencia(documento);
            if (referencia.RutaLocal == null || !referencia.RutaLocal.EndsWith(".rvt", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Guarde el archivo RVT en Revit antes de traer su referencia.");
        }
        // La lectura rellena el formulario. La vinculación persistente continúa
        // por el flujo existente, después de guardar y verificar la referencia.
        return referencia;
    }

    private static bool Igual(string a, string b) => string.Equals(a?.Trim(), b?.Trim(), StringComparison.OrdinalIgnoreCase);
    // No usar Path.GetFullPath: las rutas vienen de Windows/Revit y estas
    // comprobaciones también se ejecutan en Linux. Nunca completar una ruta
    // relativa con el directorio de trabajo del proceso.
    private static string RutaLocal(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta)) return null;
        ruta = ruta.Trim().Replace('\\', '/');
        if (ruta.StartsWith("//?/UNC/", StringComparison.OrdinalIgnoreCase)) ruta = "//" + ruta[8..];
        else if (ruta.StartsWith("//?/", StringComparison.Ordinal)) ruta = ruta[4..];
        string prefijo;
        int protegidos;
        if (ruta.Length >= 3 && char.IsAsciiLetter(ruta[0]) && ruta[1] == ':' && ruta[2] == '/')
        { prefijo = ruta[..3]; ruta = ruta[3..]; protegidos = 0; }
        else if (ruta.StartsWith("rsn://", StringComparison.OrdinalIgnoreCase))
        { prefijo = "rsn://"; ruta = ruta[6..]; protegidos = 1; }
        else if (ruta.StartsWith("//", StringComparison.Ordinal))
        { prefijo = "//"; ruta = ruta[2..]; protegidos = 2; }
        else return null;
        var partes = new List<string>();
        foreach (string parte in ruta.Split('/', StringSplitOptions.RemoveEmptyEntries))
        {
            if (parte.IndexOfAny(new[] { '\0', ':', '*', '?', '"', '<', '>', '|' }) >= 0) return null;
            if (partes.Count < protegidos && (parte == "." || parte == "..")) return null;
            if (parte == ".") continue;
            if (parte == "..")
            {
                if (partes.Count <= protegidos) return null;
                partes.RemoveAt(partes.Count - 1);
            }
            else partes.Add(parte);
        }
        if (partes.Count <= protegidos) return null;
        return prefijo + string.Join('/', partes);
    }

    private static string RutaReferencia(DocumentoRevitInfo documento) =>
        RutaLocal(documento.EsColaborativo ? documento.RutaCentral : documento.Ruta);

    private static string GuidAutodesk(string valor, bool proyecto)
    {
        valor = valor?.Trim();
        // APS presenta habitualmente el GUID de proyecto con este prefijo;
        // los URN de archivos/versiones no equivalen al GUID del modelo Revit.
        if (proyecto && valor?.StartsWith("b.", StringComparison.OrdinalIgnoreCase) == true) valor = valor[2..];
        return Guid.TryParse(valor, out var id) && id != Guid.Empty ? id.ToString("D") : null;
    }

    private static bool IdAutodeskIgual(string a, string b, bool proyecto)
    {
        string x = GuidAutodesk(a, proyecto), y = GuidAutodesk(b, proyecto);
        return x != null && y != null ? Igual(x, y) : Igual(a, b);
    }

    private static List<MYGActivoRevit> CoincidenciasReferencia(MYGProyectoDocumento proyecto, DocumentoRevitInfo documento)
    {
        var activos = proyecto.ActivosRevit?.Activos ?? new List<MYGActivoRevit>();
        if (documento.Origen == MYGOrigenActivoRevit.Local)
        {
            string ruta = RutaReferencia(documento);
            return ruta == null ? new() : activos.Where(a => a.Origen == MYGOrigenActivoRevit.Local &&
                Igual(RutaLocal(a.RutaLocal), ruta)).ToList();
        }
        string idProyecto = GuidAutodesk(documento.ProyectoAutodeskId, true);
        string idModelo = GuidAutodesk(documento.ModeloAutodeskId, false);
        if (idProyecto == null || idModelo == null) return new();
        return activos.Where(a => a.Origen == MYGOrigenActivoRevit.Autodesk &&
            Igual(GuidAutodesk(a.ProyectoAutodeskId, true), idProyecto) &&
            Igual(GuidAutodesk(a.ModeloAutodeskId, false), idModelo)).ToList();
    }

    private static void ValidarDocumento(DocumentoRevitInfo documento)
    {
        if (documento == null || string.IsNullOrWhiteSpace(documento.Id) || string.IsNullOrWhiteSpace(documento.DocumentoRevitId))
            throw new InvalidDataException("El conector no informó la identidad persistente del modelo. Actualice el conector y vuelva a conectar Revit.");
        if (documento.EsModeloSeparado)
            throw new InvalidDataException("El modelo abierto está separado del central. Guárdelo como un archivo independiente y compruebe su registro antes de aplicar tablas.");
        if (!Enum.IsDefined(documento.Origen) || (documento.Origen == MYGOrigenActivoRevit.Autodesk &&
            (string.IsNullOrWhiteSpace(documento.ProyectoAutodeskId) || string.IsNullOrWhiteSpace(documento.ModeloAutodeskId))))
            throw new InvalidDataException("La identidad del modelo Revit está incompleta.");
    }

    private static void ComprobarOrigen(MYGActivoRevit activo, DocumentoRevitInfo documento)
    {
        if (activo.Origen != documento.Origen || (activo.Origen == MYGOrigenActivoRevit.Autodesk &&
            (!IdAutodeskIgual(activo.ProyectoAutodeskId, documento.ProyectoAutodeskId, true) ||
                !IdAutodeskIgual(activo.ModeloAutodeskId, documento.ModeloAutodeskId, false))))
            throw new InvalidDataException("El modelo abierto no corresponde al origen o a los identificadores Autodesk del activo.");
    }

    public static MYGActivoRevit ResolverActivo(MYGProyectoDocumento proyecto, DocumentoRevitInfo documento)
    {
        MYGActivosRevit.Validar(proyecto);
        ValidarDocumento(documento);
        var activo = proyecto.ActivosRevit?.Activos.SingleOrDefault(a => !string.IsNullOrWhiteSpace(a.DocumentoRevitId) &&
            Igual(a.DocumentoRevitId, documento.DocumentoRevitId));
        if (activo != null)
        {
            ComprobarOrigen(activo, documento);
            // Una copia RVT puede conservar la identidad de creación. Una ruta
            // registrada expresamente a otro activo evidencia esa contradicción;
            // bloqueamos el envío sin usar la ruta para elegir otro activo.
            if (CoincidenciasReferencia(proyecto, documento).Any(a => !Igual(a.Id, activo.Id)))
                throw new InvalidDataException("La identidad Revit y la referencia registrada señalan activos distintos. Revise las copias o los identificadores del modelo antes de aplicar tablas.");
        }
        // Esta consulta conserva su semántica de identidad ya vinculada. La
        // primera coincidencia por referencia se consulta aparte, sin mutación.
        return activo;
    }

    /// <summary>Busca una referencia inequívoca; el llamador valida y guarda el vínculo antes de ejecutar Revit.</summary>
    public static MYGActivoRevit BuscarActivoPorReferencia(MYGProyectoDocumento proyecto, DocumentoRevitInfo documento)
    {
        var identificado = ResolverActivo(proyecto, documento);
        var candidatos = CoincidenciasReferencia(proyecto, documento);
        if (candidatos.Count > 1)
            throw new InvalidDataException("Varios activos tienen la misma ruta o los mismos identificadores Autodesk equivalentes. Corrija el registro antes de vincular automáticamente.");
        var candidato = candidatos.SingleOrDefault();
        if (candidato == null) return null;
        if (identificado != null && !Igual(identificado.Id, candidato.Id))
            throw new InvalidDataException("El modelo ya pertenece a otro activo. No se cambió su vinculación.");
        if (!string.IsNullOrWhiteSpace(candidato.DocumentoRevitId) && !Igual(candidato.DocumentoRevitId, documento.DocumentoRevitId))
            throw new InvalidDataException("La ruta o los identificadores coinciden con un activo vinculado a otra identidad Revit. Revise si el archivo fue sustituido; no se cambiará el vínculo automáticamente.");
        ComprobarOrigen(candidato, documento);
        return candidato;
    }

    public static MYGActivoRevit VincularDocumento(MYGProyectoDocumento proyecto, string activoId, DocumentoRevitInfo documento)
    {
        MYGActivosRevit.Validar(proyecto);
        ValidarDocumento(documento);
        var activo = proyecto.ActivosRevit?.Activos.SingleOrDefault(a => Igual(a.Id, activoId))
            ?? throw new InvalidDataException("Registre el activo en esta obra antes de vincular el modelo.");
        ComprobarOrigen(activo, documento);
        if (!string.IsNullOrWhiteSpace(activo.DocumentoRevitId) && !Igual(activo.DocumentoRevitId, documento.DocumentoRevitId))
            throw new InvalidDataException("Ese activo ya está vinculado a otro modelo Revit. Revise su registro antes de cambiar la vinculación.");
        var referencias = CoincidenciasReferencia(proyecto, documento);
        if (referencias.Count > 1 || referencias.Any(a => !Igual(a.Id, activo.Id)))
            throw new InvalidDataException("La referencia del modelo corresponde a otro activo o a varios registros equivalentes. Corrija el registro antes de confirmar la vinculación.");
        var identificado = ResolverActivo(proyecto, documento);
        if (identificado != null && !Igual(identificado.Id, activo.Id))
            throw new InvalidDataException("El modelo abierto ya está vinculado a otro activo de la obra.");
        var copia = MYGProyectoStorage.Copia(activo);
        copia.DocumentoRevitId = documento.DocumentoRevitId.Trim();
        return MYGActivosRevit.GuardarActivo(proyecto, copia);
    }

    public static List<LoteTablasRevit> PrepararLotes(MYGProyectoDocumento proyecto, DocumentoRevitInfo documento)
    {
        var activo = ResolverActivo(proyecto, documento)
            ?? throw new InvalidDataException("Vincule primero el modelo abierto con uno de los activos de esta obra.");
        var lotes = new List<LoteTablasRevit>();
        foreach (var presupuesto in proyecto.Presupuestos)
        {
            var ids = proyecto.ActivosRevit.Asignaciones.Where(a => Igual(a.ActivoId, activo.Id) && Igual(a.PresupuestoId, presupuesto.Id))
                .Select(a => a.PartidaId).ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (ids.Count == 0) continue;
            var lote = new LoteTablasRevit { PresupuestoId = presupuesto.IdPresupuestoRevit };
            if (string.IsNullOrWhiteSpace(lote.PresupuestoId))
                throw new InvalidDataException("El presupuesto no tiene identidad de Revit. Guarde la obra antes de generar sus tablas.");
            foreach (var partida in presupuesto.Items.Where(i => ids.Contains(i.Id)))
            {
                ValidarConfiguracion(partida, documento);
                lote.Configuraciones.Add(Configuracion(partida));
            }
            lotes.Add(lote);
        }
        if (lotes.Count == 0) throw new InvalidDataException("El activo reconocido no tiene partidas asignadas en esta obra.");
        if (lotes.Select(l => l.PresupuestoId).Distinct(StringComparer.OrdinalIgnoreCase).Count() != lotes.Count)
            throw new InvalidDataException("Dos presupuestos comparten la misma identidad de Revit. Revise la obra antes de generar tablas.");
        return lotes;
    }

    private static void ValidarConfiguracion(ItemPresupuestoDelphin partida, DocumentoRevitInfo documento)
    {
        string contexto = "La partida «" + (partida.Item + " " + partida.Descripcion).Trim() + "» ";
        if (string.IsNullOrWhiteSpace(partida.Plantilla) || documento.Plantillas?.Any(p => Igual(p, partida.Plantilla)) != true)
            throw new InvalidDataException(contexto + "necesita una plantilla disponible en el modelo abierto.");
        if (partida.Filtros?.Any(f => f == null) == true)
            throw new InvalidDataException(contexto + "contiene un filtro inválido.");
        var filtros = MYGBibliotecaPartidas.FiltrosGuardables(partida);
        if (filtros.Count > 8) throw new InvalidDataException(contexto + "supera el máximo de ocho filtros.");
        foreach (var filtro in filtros.Where(f => !f.EstaVacio()))
        {
            if (string.IsNullOrWhiteSpace(filtro.Parametro) || string.IsNullOrWhiteSpace(filtro.Regla))
                throw new InvalidDataException(contexto + "tiene un filtro sin parámetro o regla.");
            bool sinValor = new[] { "parámetro existe", "tiene valor", "no tiene valor" }.Any(r => Igual(r, filtro.Regla));
            if (!sinValor && string.IsNullOrWhiteSpace(filtro.Valor))
                throw new InvalidDataException(contexto + "tiene un filtro cuya regla necesita un valor.");
            // INFO enumera los campos ya presentes en la plantilla. Revit puede
            // añadir otros campos programables durante su preflight real; su
            // ausencia en esta instantánea no demuestra que sean inválidos.
            if (documento.Reglas.TryGetValue(partida.Plantilla.Trim(), out var reglas) &&
                reglas.TryGetValue(filtro.Parametro.Trim(), out var aplicables) && aplicables?.Count > 0 &&
                !aplicables.Any(r => Igual(r, filtro.Regla)))
                throw new InvalidDataException(contexto + "usa una regla no compatible con el parámetro «" + filtro.Parametro + "».");
        }
    }

    private static ConfiguracionTablaPlanificacion Configuracion(ItemPresupuestoDelphin i) => new()
    {
        IdInterno = i.Id, ParentId = i.ParentId, IdInternoDelphin = i.IdInternoDelphin, IdLocalMYG = i.IdLocalMYG,
        IdPropuesta = i.IdPropuesta, IdAnalisisDelphin = i.IdAnalisisDelphin, IdCatalogoDelphin = i.IdCatalogoDelphin,
        FuenteCatalogoId = i.FuenteCatalogoId, FuenteCatalogoRuta = i.FuenteCatalogoRuta, CodigoCatalogoDelphin = i.CodigoCatalogoDelphin,
        CodigoDelphin = i.CodigoDelphin, IdConfiguracionBibliotecaMYG = i.IdConfiguracionBibliotecaMYG,
        Item = i.Item, Partida = i.Descripcion, Unidad = i.Unidad, Plantilla = i.Plantilla.Trim(),
        Filtros = MYGBibliotecaPartidas.FiltrosGuardables(i), Estado = i.Estado, Origen = i.Origen, TipoPropuesta = i.TipoPropuesta,
        Posicion = i.Posicion, PartidaOriginal = i.PartidaOriginal, UnidadOriginal = i.UnidadOriginal,
        PartidaPropuesta = i.PartidaPropuesta, UnidadPropuesta = i.UnidadPropuesta
    };
}
