using System;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using MYG.Externo;
using System.Windows.Forms;

namespace MYG_2027;

// El formulario trabaja sobre una copia: cerrar o cancelar nunca modifica la obra.
internal sealed class MYGActivosRevitForm : Form
{
    private readonly MYGProyectoDocumento copia;
    private readonly bool puedeEditar;
    private readonly Func<IWin32Window, Task<DocumentoRevitInfo>> consultarRevit;
    private readonly Func<bool> puedeEditarActual;
    private bool consultandoRevit, cerrando;
    private int consultaRevit;
    private Control editorContenedor, herramientasActivos;
    private Button nuevo, aplicar, traer, vincular, copiarProyecto, copiarModelo;
    private bool PuedeEditarAhora => puedeEditar && (puedeEditarActual?.Invoke() ?? true);
    private readonly DataGridView lista = new();
    private readonly TextBox nombre = new(), ruta = new(), proyectoAutodesk = new(), modeloAutodesk = new();
    private readonly TextBox identidad = new() { ReadOnly = true }, documentoRevit = new() { ReadOnly = true };
    private readonly ComboBox origen = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly Label estado = new() { AutoSize = true, Dock = DockStyle.Fill };
    private readonly Label explicacionOrigen = new() { AutoSize = true, Dock = DockStyle.Fill };
    private readonly Button examinar, guardar, eliminar;
    private readonly Font fuente = new("Segoe UI", 9F);
    private bool cargando, pendiente;
    private string seleccionado;
    internal MYGConfiguracionActivosRevit Resultado;

    internal MYGActivosRevitForm(MYGProyectoDocumento proyecto, bool puedeEditar,
        Func<IWin32Window, Task<DocumentoRevitInfo>> consultarRevit = null, Func<bool> puedeEditarActual = null)
    {
        if (proyecto == null) throw new ArgumentNullException(nameof(proyecto));
        copia = MYGProyectoStorage.Copia(proyecto);
        this.puedeEditar = puedeEditar;
        this.consultarRevit = consultarRevit;
        this.puedeEditarActual = puedeEditarActual;
        Name = "activos_revit_obra";
        MYGProyectoUI.Preparar(this, "Activos Revit de la obra", 900, 600);
        Font = fuente;
        MinimumSize = new Size(640, 520);
        MaximizeBox = true;
        ShowInTaskbar = false;
        AccessibleName = "Activos Revit de la obra";

        var contenido = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5,
            Padding = new Padding(12), AutoScroll = true };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        contenido.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
        contenido.Controls.Add(new Label { AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 10),
            Text = "Registre los modelos locales y de Autodesk en una misma lista. Después, asigne cada activo a las partidas que correspondan." }, 0, 0);

        lista.Name = "activos_revit_lista";
        lista.Dock = DockStyle.Fill;
        lista.ReadOnly = true;
        lista.AllowUserToAddRows = false;
        lista.AllowUserToDeleteRows = false;
        lista.RowHeadersVisible = false;
        lista.MultiSelect = false;
        lista.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        lista.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        lista.MinimumSize = new Size(0, 120);
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "NOMBRE", HeaderText = "Activo", MinimumWidth = 130, FillWeight = 90 });
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "ORIGEN", HeaderText = "Origen", MinimumWidth = 110, FillWeight = 65 });
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "REFERENCIA", HeaderText = "Modelo registrado", MinimumWidth = 190, FillWeight = 150 });
        lista.Columns.Add(new DataGridViewTextBoxColumn { Name = "ESTADO", HeaderText = "Conexión", MinimumWidth = 130, FillWeight = 75 });
        lista.SelectionChanged += (_, _) => SeleccionarFila();
        contenido.Controls.Add(lista, 0, 1);

        var herramientas = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, AutoScroll = true };
        nuevo = Boton("Nuevo activo", "activo_revit_nuevo", () =>
        {
            if (!PuedeEditarAhora || !GuardarPendiente()) return;
            CargarEditor(null);
            cargando = true; lista.ClearSelection(); cargando = false;
            nombre.Focus();
        });
        guardar = Boton("Guardar activo", "activo_revit_guardar", () => GuardarEditor());
        eliminar = Boton("Eliminar activo", "activo_revit_eliminar", EliminarSeleccionado);
        nuevo.Enabled = guardar.Enabled = eliminar.Enabled = puedeEditar;
        traer = MYGProyectoUI.Boton("Traer del modelo abierto");
        traer.Name = "activo_revit_traer_modelo"; traer.Width = 190; traer.Height = 34; traer.Margin = new Padding(0, 5, 8, 5);
        traer.Click += async (_, _) => await TraerDesdeRevitAsync();
        vincular = MYGProyectoUI.Boton("Vincular");
        vincular.Name = "activo_revit_vincular"; vincular.Width = 112; vincular.Height = 34; vincular.Margin = new Padding(0, 5, 8, 5);
        vincular.Click += async (_, _) => await VincularDesdeRevitAsync();
        herramientas.Controls.AddRange(new Control[] { nuevo, guardar, eliminar, traer, vincular });
        herramientasActivos = herramientas;
        contenido.Controls.Add(herramientas, 0, 2);

        var editor = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 2,
            RowCount = 8, Padding = new Padding(0, 6, 0, 6) };
        editor.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 148));
        editor.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        void Campo(string titulo, Control control, int fila)
        {
            editor.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            editor.Controls.Add(new Label { Text = titulo, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(0, 6, 6, 6) }, 0, fila);
            control.Dock = DockStyle.Fill; control.Margin = new Padding(0, 3, 0, 3);
            editor.Controls.Add(control, 1, fila);
        }
        nombre.Name = "activo_revit_nombre";
        origen.Name = "activo_revit_origen";
        ruta.Name = "activo_revit_ruta";
        proyectoAutodesk.Name = "activo_revit_proyecto_autodesk";
        modeloAutodesk.Name = "activo_revit_modelo_autodesk";
        identidad.Name = "activo_revit_id";
        documentoRevit.Name = "activo_revit_documento_id";
        origen.Items.AddRange(new object[] { "Archivo RVT local", "Nube Autodesk" });
        var rutaContenedor = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, AutoSize = true, Margin = new Padding(0) };
        rutaContenedor.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        rutaContenedor.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 108));
        ruta.Dock = DockStyle.Fill;
        examinar = Boton("Examinar…", "activo_revit_examinar", Examinar);
        examinar.Width = 100; examinar.Height = 27; examinar.Margin = new Padding(6, 0, 0, 0);
        rutaContenedor.Controls.Add(ruta, 0, 0); rutaContenedor.Controls.Add(examinar, 1, 0);
        Campo("Nombre del activo", nombre, 0);
        Campo("Origen", origen, 1);
        Campo("Archivo RVT", rutaContenedor, 2);
        Campo("Proyecto Autodesk · ID", CampoCopiable(proyectoAutodesk, "activo_revit_copiar_proyecto", out copiarProyecto), 3);
        Campo("Modelo Autodesk · ID", CampoCopiable(modeloAutodesk, "activo_revit_copiar_modelo", out copiarModelo), 4);
        Campo("Identidad del activo", identidad, 5);
        Campo("Documento Revit · ID", documentoRevit, 6);
        editor.Controls.Add(explicacionOrigen, 0, 7); editor.SetColumnSpan(explicacionOrigen, 2);
        editorContenedor = editor;
        contenido.Controls.Add(editor, 0, 3);

        var pie = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        pie.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); pie.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        estado.Margin = new Padding(0, 8, 8, 0);
        pie.Controls.Add(estado, 0, 0);
        var botones = new FlowLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, WrapContents = false, FlowDirection = FlowDirection.RightToLeft };
        var cancelar = MYGProyectoUI.Boton(puedeEditar ? "Cancelar" : "Cerrar");
        cancelar.Name = "activos_revit_cancelar"; cancelar.Width = 105; cancelar.DialogResult = DialogResult.Cancel;
        aplicar = Boton("Aplicar a la obra", "activos_revit_aplicar", () =>
        {
            if (consultandoRevit) return;
            if (!PuedeEditarAhora) throw new InvalidOperationException("Se retiró el permiso de edición. Puede copiar la información o cancelar el formulario.");
            if (!GuardarPendiente()) return;
            MYGActivosRevit.Validar(copia);
            Resultado = MYGProyectoStorage.Copia(copia.ActivosRevit);
            DialogResult = DialogResult.OK; Close();
        });
        aplicar.Width = 150; aplicar.Enabled = puedeEditar;
        botones.Controls.Add(cancelar); botones.Controls.Add(aplicar);
        pie.Controls.Add(botones, 1, 0); contenido.Controls.Add(pie, 0, 4);
        Controls.Add(contenido);
        CancelButton = cancelar;
        // Enter dentro de los campos no confirma accidentalmente toda la obra.
        AcceptButton = null;
        foreach (TextBox campo in new[] { nombre, ruta, proyectoAutodesk, modeloAutodesk })
        {
            campo.ReadOnly = !puedeEditar; campo.ShortcutsEnabled = true;
            campo.TextChanged += (_, _) => { if (!cargando) pendiente = true; ActualizarBotonesCopiar(); };
        }
        origen.Enabled = puedeEditar;
        origen.SelectedIndexChanged += (_, _) =>
        {
            if (!cargando) pendiente = true;
            ActualizarOrigen();
        };
        MYG2027_TemaComercial.CambioTema += ActualizarTema;
        ActualizarLista();
        CargarEditor(null);
        ActualizarTema(null, EventArgs.Empty);
    }

    private Control CampoCopiable(TextBox campo, string nombreBoton, out Button copiar)
    {
        var panel = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2,
            RowCount = 1, Margin = Padding.Empty };
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90));
        campo.Dock = DockStyle.Fill;
        copiar = Boton("Copiar", nombreBoton, () => CopiarId(campo));
        copiar.Width = 82; copiar.Height = 27; copiar.Margin = new Padding(6, 0, 0, 0);
        panel.Controls.Add(campo, 0, 0); panel.Controls.Add(copiar, 1, 0);
        return panel;
    }

    private void ActualizarBotonesCopiar()
    {
        if (copiarProyecto != null) copiarProyecto.Enabled = !string.IsNullOrWhiteSpace(proyectoAutodesk.Text);
        if (copiarModelo != null) copiarModelo.Enabled = !string.IsNullOrWhiteSpace(modeloAutodesk.Text);
    }

    private void CopiarId(TextBox campo)
    {
        if (string.IsNullOrWhiteSpace(campo.Text)) { estado.Text = "Primero traiga la información del modelo o seleccione un activo registrado."; return; }
        try
        {
            Clipboard.SetText(campo.Text.Trim());
            estado.Text = "ID copiado al portapapeles.";
        }
        catch (Exception ex) when (ex is ExternalException or System.Threading.ThreadStateException)
        {
            campo.Focus(); campo.SelectAll();
            estado.Text = "El portapapeles está ocupado. El ID quedó seleccionado; pulse Ctrl+C para volver a intentar.";
        }
    }

    private Task TraerDesdeRevitAsync() => ConsultarDesdeRevitAsync(false);
    private Task VincularDesdeRevitAsync() => ConsultarDesdeRevitAsync(true);

    private async Task ConsultarDesdeRevitAsync(bool comprobarVinculo)
    {
        if (IsDisposed || Disposing || cerrando || consultandoRevit || consultarRevit == null || !PuedeEditarAhora) return;
        consultandoRevit = true;
        int numeroConsulta = ++consultaRevit;
        lista.Enabled = editorContenedor.Enabled = herramientasActivos.Enabled = aplicar.Enabled = false;
        estado.Text = "Consultando los modelos abiertos en Revit…";
        try
        {
            var info = await consultarRevit(this);
            if (IsDisposed || Disposing || cerrando || numeroConsulta != consultaRevit) return;
            if (info == null) { estado.Text = "Consulta cancelada. Se conservan los datos del activo."; return; }
            if (!PuedeEditarAhora) { estado.Text = "Se retiró el permiso de edición. Se conservan los datos del activo."; return; }
            if (comprobarVinculo) { VincularModeloConsultado(info); return; }
            var referencia = MYGTablasActivosRevit.ReferenciaDesdeModelo(info);
            string proyecto = referencia.ProyectoAutodeskId, modelo = referencia.ModeloAutodeskId, archivo = referencia.RutaLocal;
            bool previo = cargando; cargando = true;
            try
            {
                if (string.IsNullOrWhiteSpace(nombre.Text)) nombre.Text = referencia.Nombre;
                origen.SelectedIndex = info.Origen == MYGOrigenActivoRevit.Autodesk ? 1 : 0;
                ruta.Text = archivo ?? ""; proyectoAutodesk.Text = proyecto ?? ""; modeloAutodesk.Text = modelo ?? "";
                var anterior = copia.ActivosRevit?.Activos.FirstOrDefault(a => a.Id == seleccionado);
                bool mismaReferencia = anterior != null && anterior.Origen == info.Origen &&
                    (info.Origen == MYGOrigenActivoRevit.Autodesk
                        ? string.Equals(anterior.ProyectoAutodeskId?.Trim(), proyecto, StringComparison.Ordinal) &&
                          string.Equals(anterior.ModeloAutodeskId?.Trim(), modelo, StringComparison.Ordinal)
                        : string.Equals(anterior.RutaLocal?.Trim(), archivo, StringComparison.OrdinalIgnoreCase));
                documentoRevit.Text = mismaReferencia && !string.IsNullOrWhiteSpace(anterior.DocumentoRevitId)
                    ? anterior.DocumentoRevitId : "Pendiente de vincular desde Revit";
                pendiente = true;
            }
            finally { cargando = previo; }
            estado.Text = "Datos traídos de Revit. Puede copiar los IDs; pulse Guardar activo y Aplicar a la obra para conservar el registro.";
        }
        catch (Exception ex)
        {
            if (!IsDisposed && !Disposing && !cerrando) estado.Text = (comprobarVinculo ? "No se pudo vincular: " : "No se pudo traer la información: ") + ex.Message + " Se conservan los datos del activo.";
        }
        finally
        {
            consultandoRevit = false;
            if (!IsDisposed && !Disposing && !cerrando)
            {
                lista.Enabled = editorContenedor.Enabled = herramientasActivos.Enabled = true;
                ActualizarOrigen();
            }
        }
    }

    private void VincularModeloConsultado(DocumentoRevitInfo info)
    {
        // La consulta no otorga autoridad para sustituir un registro o cambiar
        // referencias con metrados: primero validar todo sobre otra copia.
        var candidato = MYGProyectoStorage.Copia(copia);
        var referencia = MYGTablasActivosRevit.ReferenciaDesdeModelo(info);
        var coincidencia = MYGTablasActivosRevit.BuscarActivoPorReferencia(candidato, info);
        MYGActivoRevit activo;
        bool reutilizado = false;
        if (seleccionado != null)
        {
            activo = candidato.ActivosRevit?.Activos.SingleOrDefault(a => a.Id == seleccionado)
                ?? throw new InvalidOperationException("El activo seleccionado ya no está disponible.");
            if (coincidencia == null || !string.Equals(coincidencia.Id, activo.Id, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("El modelo consultado no coincide con la referencia guardada. Guarde o corrija la referencia, o cree otro activo; no se cambió la vinculación.");
            if (pendiente)
                throw new InvalidOperationException("Guarde primero los cambios del activo para no descartar su borrador. Después pulse Vincular de nuevo.");
        }
        else if (coincidencia != null)
        {
            activo = coincidencia;
            reutilizado = true;
        }
        else
        {
            if (!string.IsNullOrWhiteSpace(nombre.Text)) referencia.Nombre = nombre.Text.Trim();
            activo = MYGActivosRevit.GuardarActivo(candidato, referencia);
        }
        var vinculado = MYGTablasActivosRevit.VincularDocumento(candidato, activo.Id, info);
        if (!PuedeEditarAhora) throw new InvalidOperationException("Se retiró el permiso de edición. No se cambió la vinculación.");
        copia.ActivosRevit = candidato.ActivosRevit;
        ActualizarLista(vinculado.Id);
        CargarEditor(vinculado);
        estado.Text = (reutilizado ? "Se reconoció el activo existente y se comprobó su modelo. " : "Modelo vinculado al activo. ")
            + "Pulse Aplicar a la obra para conservarlo; cancelar descarta los cambios del diálogo.";
    }

    private Button Boton(string texto, string nombreControl, Action accion)
    {
        var boton = MYGProyectoUI.Boton(texto);
        boton.Name = nombreControl;
        boton.Height = 34; boton.Width = 144; boton.Margin = new Padding(0, 5, 8, 5);
        boton.Click += (_, _) =>
        {
            try { accion(); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Activos Revit", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        };
        return boton;
    }

    private void ActualizarLista(string seleccionarId = null)
    {
        bool previo = cargando; cargando = true;
        try
        {
            lista.Rows.Clear();
            foreach (var activo in copia.ActivosRevit?.Activos ?? Enumerable.Empty<MYGActivoRevit>())
            {
                string referencia = activo.Origen == MYGOrigenActivoRevit.Local ? activo.RutaLocal
                    : activo.ProyectoAutodeskId + " / " + activo.ModeloAutodeskId;
                var fila = lista.Rows[lista.Rows.Add(activo.Nombre,
                    activo.Origen == MYGOrigenActivoRevit.Local ? "Local" : "Autodesk", referencia,
                    string.IsNullOrWhiteSpace(activo.DocumentoRevitId) ? "Pendiente de vincular" : "Modelo vinculado")];
                fila.Tag = activo.Id;
                fila.Cells["REFERENCIA"].ToolTipText = referencia;
            }
            lista.ClearSelection();
            var seleccion = lista.Rows.Cast<DataGridViewRow>().FirstOrDefault(f => Equals(f.Tag, seleccionarId));
            if (seleccion != null) { lista.CurrentCell = seleccion.Cells[0]; seleccion.Selected = true; }
            estado.Text = lista.Rows.Count == 0 ? "Sin activos registrados. Añada un modelo para comenzar."
                : lista.Rows.Count + " activo(s) · Los cambios se confirman al aplicar a la obra.";
        }
        finally { cargando = previo; }
    }

    private void SeleccionarFila()
    {
        if (cargando || lista.SelectedRows.Count == 0) return;
        string id = lista.SelectedRows[0].Tag as string;
        if (id == seleccionado) return;
        if (!GuardarPendiente())
        { ActualizarLista(seleccionado); return; }
        var activo = copia.ActivosRevit?.Activos.FirstOrDefault(a => a.Id == id);
        CargarEditor(activo);
        // GuardarPendiente puede reconstruir la lista: restablecer el destino elegido.
        ActualizarLista(id);
    }

    private void CargarEditor(MYGActivoRevit activo)
    {
        cargando = true;
        try
        {
            seleccionado = activo?.Id;
            nombre.Text = activo?.Nombre ?? "";
            origen.SelectedIndex = activo?.Origen == MYGOrigenActivoRevit.Autodesk ? 1 : 0;
            ruta.Text = activo?.RutaLocal ?? "";
            proyectoAutodesk.Text = activo?.ProyectoAutodeskId ?? "";
            modeloAutodesk.Text = activo?.ModeloAutodeskId ?? "";
            identidad.Text = activo?.Id ?? "Se asignará al guardar el activo";
            documentoRevit.Text = string.IsNullOrWhiteSpace(activo?.DocumentoRevitId) ? "Pendiente de vincular desde Revit" : activo.DocumentoRevitId;
            eliminar.Enabled = puedeEditar && activo != null;
            pendiente = false;
            ActualizarOrigen();
        }
        finally { cargando = false; }
    }

    private void ActualizarOrigen()
    {
        bool local = origen.SelectedIndex != 1, permiso = PuedeEditarAhora && !consultandoRevit;
        ruta.Enabled = proyectoAutodesk.Enabled = modeloAutodesk.Enabled = true;
        nombre.ReadOnly = !permiso;
        ruta.ReadOnly = !(permiso && local);
        proyectoAutodesk.ReadOnly = modeloAutodesk.ReadOnly = !(permiso && !local);
        proyectoAutodesk.ShortcutsEnabled = modeloAutodesk.ShortcutsEnabled = true;
        proyectoAutodesk.PlaceholderText = modeloAutodesk.PlaceholderText = local ? "No se usa para archivos RVT locales" : "Traer del modelo abierto o pegar el GUID";
        examinar.Enabled = permiso && local;
        origen.Enabled = nuevo.Enabled = guardar.Enabled = aplicar.Enabled = permiso;
        eliminar.Enabled = permiso && seleccionado != null;
        traer.Enabled = vincular.Enabled = permiso && consultarRevit != null;
        ActualizarBotonesCopiar();
        explicacionOrigen.Text = local
            ? "Para archivos locales seleccione el RVT o pulse Traer del modelo abierto. Vincular comprueba el modelo; Aplicar guarda en la obra. No se necesitan IDs Autodesk."
            : "Traer del modelo abierto lee los GUID. Puede copiarlos con Ctrl+C o Copiar. Vincular registra y comprueba el modelo; Aplicar guarda los cambios en la obra.";
    }

    private bool GuardarPendiente()
    {
        if (!pendiente) return true;
        if (!PuedeEditarAhora) { estado.Text = "Se retiró el permiso de edición. Cancele el formulario para conservar la obra sin cambios."; return false; }
        try { GuardarEditor(); return true; }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message + "\n\nComplete los datos del activo o cancele el formulario para descartar los cambios.",
                "Activos Revit", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
    }

    private void GuardarEditor()
    {
        if (!PuedeEditarAhora || consultandoRevit) return;
        var anterior = copia.ActivosRevit?.Activos.FirstOrDefault(a => a.Id == seleccionado);
        var activo = new MYGActivoRevit
        {
            Id = anterior?.Id ?? MYGProyectoStorage.NuevoId(),
            Nombre = nombre.Text.Trim(),
            Origen = origen.SelectedIndex == 1 ? MYGOrigenActivoRevit.Autodesk : MYGOrigenActivoRevit.Local,
            RutaLocal = origen.SelectedIndex == 1 ? null : ruta.Text.Trim(),
            ProyectoAutodeskId = origen.SelectedIndex == 1 ? proyectoAutodesk.Text.Trim() : null,
            ModeloAutodeskId = origen.SelectedIndex == 1 ? modeloAutodesk.Text.Trim() : null,
            DocumentoRevitId = anterior?.DocumentoRevitId
        };
        bool referenciaCambio = anterior != null && (anterior.Origen != activo.Origen ||
            !string.Equals(anterior.RutaLocal?.Trim(), activo.RutaLocal?.Trim(), StringComparison.OrdinalIgnoreCase) ||
            !string.Equals(anterior.ProyectoAutodeskId?.Trim(), activo.ProyectoAutodeskId?.Trim(), StringComparison.Ordinal) ||
            !string.Equals(anterior.ModeloAutodeskId?.Trim(), activo.ModeloAutodeskId?.Trim(), StringComparison.Ordinal));
        // Una ubicación nueva requiere comprobar de nuevo qué documento hay allí.
        // La identidad MYG del activo y sus asignaciones se conservan.
        if (referenciaCambio && copia.Presupuestos.Any(p => p.Items.Any(i => i.Costos.MetradosBIM.Any(m => m.ActivoId == activo.Id))) &&
            MessageBox.Show(this, "Este activo tiene metrados recibidos. Cambiar su referencia conserva esos resultados y sus opciones de inclusión, "
                + "pero no acredita que pertenezcan al nuevo modelo. Revise las cantidades en Metrados recibidos antes de utilizarlas. "
                + "Si se trata de otro bloque, registre un activo nuevo. ¿Continuar con el cambio de referencia?", "Cambiar referencia del activo",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            throw new InvalidOperationException("No se cambió la referencia. Puede corregirla o cancelar el formulario.");
        if (referenciaCambio) activo.DocumentoRevitId = null;
        MYGActivosRevit.GuardarActivo(copia, activo);
        ActualizarLista(activo.Id);
        CargarEditor(copia.ActivosRevit.Activos.First(a => a.Id == activo.Id));
    }

    private void EliminarSeleccionado()
    {
        if (!PuedeEditarAhora || consultandoRevit || seleccionado == null) return;
        var activo = copia.ActivosRevit?.Activos.FirstOrDefault(a => a.Id == seleccionado);
        if (activo == null) return;
        if (MessageBox.Show(this, "¿Eliminar el registro del activo «" + activo.Nombre + "»? El archivo RVT se conserva.",
            "Activos Revit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        MYGActivosRevit.EliminarActivo(copia, activo.Id);
        ActualizarLista(); CargarEditor(null);
    }

    private void Examinar()
    {
        if (!PuedeEditarAhora || consultandoRevit) return;
        using var dialogo = new OpenFileDialog { Title = "Elegir modelo Revit", Filter = "Modelo Revit (*.rvt)|*.rvt", CheckFileExists = true };
        if (dialogo.ShowDialog(this) == DialogResult.OK) ruta.Text = dialogo.FileName;
    }

    private void ActualizarTema(object sender, EventArgs e)
    {
        if (IsDisposed || Disposing) return;
        MYG2027_TemaComercial.Aplicar(this);
        lista.BackgroundColor = MYG2027_TemaComercial.Superficie;
        lista.EnableHeadersVisualStyles = false;
        lista.ColumnHeadersDefaultCellStyle.BackColor = MYG2027_TemaComercial.CabeceraTabla;
        lista.ColumnHeadersDefaultCellStyle.ForeColor = MYG2027_TemaComercial.TextoCabeceraTabla;
        lista.DefaultCellStyle.BackColor = MYG2027_TemaComercial.Superficie;
        lista.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
        lista.DefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
        lista.DefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        base.OnFormClosing(e);
        if (!e.Cancel) { cerrando = true; consultaRevit++; }
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        MYG2027_TemaComercial.AjustarAlAreaDeTrabajo(this);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) MYG2027_TemaComercial.CambioTema -= ActualizarTema;
        base.Dispose(disposing);
        if (disposing) fuente.Dispose();
    }
}
