using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;
using MYG.Externo;

internal static class ActivosRevitUICheck
{
    private const BindingFlags Privados = BindingFlags.NonPublic | BindingFlags.Instance;
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados)!.GetValue(objeto)!;
    private static void Invocar(object objeto, string nombre) => objeto.GetType().GetMethod(nombre, Privados)!.Invoke(objeto, null);
    private static Task Traer(object objeto) => (Task)objeto.GetType().GetMethod("TraerDesdeRevitAsync", Privados)!.Invoke(objeto, null)!;
    private static Task Vincular(object objeto) => (Task)objeto.GetType().GetMethod("VincularDesdeRevitAsync", Privados)!.Invoke(objeto, null)!;

    private static void Esperar(Task tarea)
    {
        var reloj = System.Diagnostics.Stopwatch.StartNew();
        while (!tarea.IsCompleted && reloj.Elapsed < TimeSpan.FromSeconds(5))
        { Application.DoEvents(); System.Threading.Thread.Sleep(1); }
        if (!tarea.IsCompleted) throw new TimeoutException("La consulta simulada no completó su continuación de interfaz.");
        tarea.GetAwaiter().GetResult();
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Activos de prueba", "Estructuras");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = "Columnas", Unidad = "m³" };
        presupuesto.Items.Add(partida);
        var local = MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Bloque A", RutaLocal = @"C:\Modelos\A.rvt" });
        MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Bloque B", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "proyecto-prueba", ModeloAutodeskId = "modelo-prueba" });
        string firma = MYGProyectoStorage.Firma(proyecto);
        using (var dialogo = new MYGActivosRevitForm(proyecto, true))
        {
            Campo<TextBox>(dialogo, "nombre").Text = "Otro activo";
            Campo<TextBox>(dialogo, "ruta").Text = @"C:\Modelos\C.rvt";
            Invocar(dialogo, "GuardarEditor");
            exige(MYGProyectoStorage.Firma(proyecto) == firma, "Guardar en el diálogo no debe modificar la obra antes de Aplicar.");
            exige(Campo<MYGProyectoDocumento>(dialogo, "copia").ActivosRevit!.Activos.Count == 3, "El alta debe quedar en la copia del diálogo.");
        }
        exige(MYGProyectoStorage.Firma(proyecto) == firma, "Cancelar el gestor debe conservar la obra original.");
        using (var consulta = new MYGActivosRevitForm(proyecto, false))
            exige(Campo<TextBox>(consulta, "nombre").ReadOnly, "El gestor debe admitir consulta sin editar.");

        var nube = new DocumentoRevitInfo { Nombre = "Modelo Autodesk de prueba", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "11111111-1111-4111-8111-111111111111", ModeloAutodeskId = "22222222-2222-4222-8222-222222222222",
            DocumentoRevitId = "autodesk:no-acreditar-vinculo" };
        IWin32Window propietario = null;
        using (var importar = new MYGActivosRevitForm(proyecto, true, owner => { propietario = owner; return Task.FromResult(nube); }))
        {
            Esperar(Traer(importar));
            exige(ReferenceEquals(propietario, importar), "La selección de modelo debe pertenecer al diálogo de activos abierto.");
            exige(Campo<ComboBox>(importar, "origen").SelectedIndex == 1 && Campo<TextBox>(importar, "ruta").Text == ""
                && Campo<TextBox>(importar, "proyectoAutodesk").Text == nube.ProyectoAutodeskId
                && Campo<TextBox>(importar, "modeloAutodesk").Text == nube.ModeloAutodeskId,
                "Traer de Revit debe rellenar el origen y ambos GUID sin mezclar rutas de caché local.");
            exige(Campo<TextBox>(importar, "proyectoAutodesk").Enabled && Campo<TextBox>(importar, "modeloAutodesk").Enabled
                && Campo<Button>(importar, "copiarProyecto").Enabled && Campo<Button>(importar, "copiarModelo").Enabled,
                "Los GUID traídos deben poder seleccionarse y copiarse con los botones de cada campo.");
            exige(Campo<TextBox>(importar, "documentoRevit").Text == "Pendiente de vincular desde Revit"
                && MYGProyectoStorage.Firma(proyecto) == firma, "Leer IDs no verifica la vinculación ni modifica la obra original.");
            Invocar(importar, "GuardarEditor");
            var guardado = Campo<MYGProyectoDocumento>(importar, "copia").ActivosRevit!.Activos.Single(a => a.Nombre == nube.Nombre);
            exige(guardado.ProyectoAutodeskId == nube.ProyectoAutodeskId && guardado.ModeloAutodeskId == nube.ModeloAutodeskId
                && string.IsNullOrWhiteSpace(guardado.DocumentoRevitId), "Guardar la referencia importada no debe acreditar acceso o vinculación al modelo.");
        }
        using (var cancelar = new MYGActivosRevitForm(proyecto, true, _ => Task.FromResult<DocumentoRevitInfo>(null)))
        {
            Campo<TextBox>(cancelar, "nombre").Text = "Borrador anterior";
            Campo<TextBox>(cancelar, "ruta").Text = @"C:\Modelos\Pendiente.rvt";
            Esperar(Traer(cancelar));
            exige(Campo<TextBox>(cancelar, "nombre").Text == "Borrador anterior"
                && Campo<TextBox>(cancelar, "ruta").Text == @"C:\Modelos\Pendiente.rvt", "Cancelar la selección no descarta los datos del editor.");
        }
        using (var importarLocal = new MYGActivosRevitForm(proyecto, true, _ => Task.FromResult(new DocumentoRevitInfo
            { Nombre = "Modelo local", Origen = MYGOrigenActivoRevit.Local, Ruta = @"C:\Modelos\Importado.rvt" })))
        {
            Campo<ComboBox>(importarLocal, "origen").SelectedIndex = 1;
            Campo<TextBox>(importarLocal, "proyectoAutodesk").Text = nube.ProyectoAutodeskId;
            Campo<TextBox>(importarLocal, "modeloAutodesk").Text = nube.ModeloAutodeskId;
            Esperar(Traer(importarLocal));
            exige(Campo<ComboBox>(importarLocal, "origen").SelectedIndex == 0
                && Campo<TextBox>(importarLocal, "ruta").Text.Replace('\\', '/') == "C:/Modelos/Importado.rvt"
                && Campo<TextBox>(importarLocal, "proyectoAutodesk").Text == "" && Campo<TextBox>(importarLocal, "modeloAutodesk").Text == "",
                "Importar un RVT local no debe conservar identificadores Autodesk de otro modelo.");
        }
        using (var invalido = new MYGActivosRevitForm(proyecto, true, _ => Task.FromResult(new DocumentoRevitInfo
            { Nombre = "No aplicar", Origen = MYGOrigenActivoRevit.Autodesk, ProyectoAutodeskId = "no-guid", ModeloAutodeskId = "no-guid" })))
        {
            Campo<TextBox>(invalido, "nombre").Text = "Dato previo";
            Campo<TextBox>(invalido, "ruta").Text = @"C:\Modelos\Conservar.rvt";
            Esperar(Traer(invalido));
            exige(Campo<TextBox>(invalido, "nombre").Text == "Dato previo" && Campo<ComboBox>(invalido, "origen").SelectedIndex == 0
                && Campo<TextBox>(invalido, "ruta").Text == @"C:\Modelos\Conservar.rvt", "Una respuesta inválida no aplica parcialmente los datos de Revit.");
        }
        var respuestaTrasCerrar = new TaskCompletionSource<DocumentoRevitInfo>();
        var cerrado = new MYGActivosRevitForm(proyecto, true, _ => respuestaTrasCerrar.Task);
        Task consultaCerrada = Traer(cerrado); cerrado.Dispose();
        respuestaTrasCerrar.SetResult(nube); Esperar(consultaCerrada);
        exige(MYGProyectoStorage.Firma(proyecto) == firma, "La respuesta recibida después de cerrar el diálogo no debe modificar la obra.");
        bool autorizado = true;
        var respuestaPendiente = new TaskCompletionSource<DocumentoRevitInfo>();
        using (var revocacion = new MYGActivosRevitForm(proyecto, true, _ => respuestaPendiente.Task, () => autorizado))
        {
            Campo<TextBox>(revocacion, "nombre").Text = "Conservar borrador";
            Task consulta = Traer(revocacion);
            exige(!Campo<DataGridView>(revocacion, "lista").Enabled && !Campo<Button>(revocacion, "aplicar").Enabled,
                "Una consulta pendiente impide cambiar de activo o aplicar datos a medio recibir.");
            autorizado = false; respuestaPendiente.SetResult(nube); Esperar(consulta);
            exige(Campo<TextBox>(revocacion, "nombre").Text == "Conservar borrador" && Campo<TextBox>(revocacion, "proyectoAutodesk").Text == ""
                && Campo<TextBox>(revocacion, "nombre").ReadOnly && !Campo<Button>(revocacion, "traer").Enabled,
                "Retirar el permiso mientras consulta debe conservar los datos y bloquear la importación.");
        }
        using (var consultaIds = new MYGActivosRevitForm(proyecto, false))
        {
            var gridActivos = Campo<DataGridView>(consultaIds, "lista");
            var filaNube = gridActivos.Rows.Cast<DataGridViewRow>().Single(r => Convert.ToString(r.Cells["ORIGEN"].Value) == "Autodesk");
            gridActivos.CurrentCell = filaNube.Cells[0];
            exige(Campo<TextBox>(consultaIds, "proyectoAutodesk").Enabled && Campo<TextBox>(consultaIds, "proyectoAutodesk").ReadOnly
                && Campo<TextBox>(consultaIds, "modeloAutodesk").Enabled && Campo<TextBox>(consultaIds, "modeloAutodesk").ReadOnly
                && Campo<Button>(consultaIds, "copiarProyecto").Enabled && Campo<Button>(consultaIds, "copiarModelo").Enabled,
                "Sólo lectura conserva la selección y copia de los IDs registrados sin habilitar edición.");
        }
        exige(MYGProyectoStorage.Firma(proyecto) == firma, "Consultar, importar y cancelar nunca aplica por su cuenta cambios a la obra.");

        var modeloVinculable = new DocumentoRevitInfo { Id = "sesion-cloud-prueba", Nombre = "Vínculo Autodesk nuevo", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = nube.ProyectoAutodeskId, ModeloAutodeskId = nube.ModeloAutodeskId,
            DocumentoRevitId = "autodesk:" + nube.ProyectoAutodeskId + ":" + nube.ModeloAutodeskId };
        using (var vinculoNuevo = new MYGActivosRevitForm(proyecto, true, _ => Task.FromResult(modeloVinculable)))
        {
            Campo<TextBox>(vinculoNuevo, "nombre").Text = "Activo vinculado desde el formulario";
            Esperar(Vincular(vinculoNuevo));
            var candidato = Campo<MYGProyectoDocumento>(vinculoNuevo, "copia");
            var activoVinculado = candidato.ActivosRevit!.Activos.Single(a => a.Nombre == "Activo vinculado desde el formulario");
            exige(activoVinculado.DocumentoRevitId == modeloVinculable.DocumentoRevitId
                && Campo<TextBox>(vinculoNuevo, "documentoRevit").Text == modeloVinculable.DocumentoRevitId,
                "Vincular en el mismo formulario debe registrar y comprobar el modelo cloud de forma explícita.");
            exige(MYGProyectoStorage.Firma(proyecto) == firma, "Vincular sólo cambia la copia del diálogo hasta pulsar Aplicar.");
        }
        using (var cancelacionVinculo = new MYGActivosRevitForm(proyecto, true, _ => Task.FromResult<DocumentoRevitInfo>(null)))
        {
            Campo<TextBox>(cancelacionVinculo, "nombre").Text = "Mantener nombre";
            string antes = MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(cancelacionVinculo, "copia"));
            Esperar(Vincular(cancelacionVinculo));
            exige(Campo<TextBox>(cancelacionVinculo, "nombre").Text == "Mantener nombre"
                && MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(cancelacionVinculo, "copia")) == antes,
                "Cancelar el selector al vincular conserva campos y copia completa.");
        }
        using (var identidadAusente = new MYGActivosRevitForm(proyecto, true, _ => Task.FromResult(nube)))
        {
            Campo<TextBox>(identidadAusente, "nombre").Text = "Conservar sin identidad de sesión";
            string antes = MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(identidadAusente, "copia"));
            Esperar(Vincular(identidadAusente));
            exige(Campo<TextBox>(identidadAusente, "nombre").Text == "Conservar sin identidad de sesión"
                && MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(identidadAusente, "copia")) == antes,
                "Una respuesta sin identidad de documento no crea ni vincula parcialmente un activo.");
        }
        using (var referenciaDistinta = new MYGActivosRevitForm(proyecto, true, _ => Task.FromResult(modeloVinculable)))
        {
            var registroLocal = Campo<MYGProyectoDocumento>(referenciaDistinta, "copia").ActivosRevit!.Activos.Single(a => a.Nombre == "Bloque A");
            typeof(MYGActivosRevitForm).GetMethod("CargarEditor", Privados)!.Invoke(referenciaDistinta, new object[] { registroLocal });
            string antes = MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(referenciaDistinta, "copia"));
            string rutaAntes = Campo<TextBox>(referenciaDistinta, "ruta").Text;
            Esperar(Vincular(referenciaDistinta));
            exige(MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(referenciaDistinta, "copia")) == antes
                && Campo<TextBox>(referenciaDistinta, "ruta").Text == rutaAntes,
                "Vincular un activo cuya referencia guardada es distinta no la sobrescribe ni salta sus advertencias.");
        }
        var yaRegistrado = MYGProyectoStorage.Copia(proyecto);
        var referenciaRegistrada = MYGTablasActivosRevit.ReferenciaDesdeModelo(modeloVinculable);
        referenciaRegistrada.Nombre = "Nombre existente conservado";
        MYGActivosRevit.GuardarActivo(yaRegistrado, referenciaRegistrada);
        using (var reutilizar = new MYGActivosRevitForm(yaRegistrado, true, _ => Task.FromResult(modeloVinculable)))
        {
            Campo<TextBox>(reutilizar, "nombre").Text = "No renombrar el existente";
            Esperar(Vincular(reutilizar));
            var activos = Campo<MYGProyectoDocumento>(reutilizar, "copia").ActivosRevit!.Activos;
            exige(activos.Count == yaRegistrado.ActivosRevit!.Activos.Count
                && activos.Single(a => a.ProyectoAutodeskId == modeloVinculable.ProyectoAutodeskId).Nombre == "Nombre existente conservado",
                "Una referencia ya registrada se reutiliza sin duplicar el activo ni cambiar su nombre.");
        }

        MYGActivosRevit.Asignar(proyecto, presupuesto.Id, partida.Id, local.Id);
        partida.Costos.FuenteMetrado = MYGFuenteMetrado.BIM;
        partida.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = local.Id, Tabla = "Columnas", Cantidad = 12m, Unidad = "m³", FechaUtc = DateTime.UtcNow });
        int historial = 0, consultas = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => historial++, () => { }, _ => { },
            () => { consultas++; return Task.CompletedTask; }, _ => { });
        panel.InicializarCatalogos(() => "no-usado", () => true, () => { });
        panel.InicializarActivosRevit(() => proyecto, () => { });
        typeof(MYGPanelPresupuesto).GetField("actual", Privados)!.SetValue(panel, partida);
        Invocar(panel, "CargarConfiguracionMetradosRevit");
        var asignaciones = Campo<DataGridView>(panel, "asignacionesRevit");
        exige(asignaciones.Rows.Count == 1 && Convert.ToString(asignaciones.Rows[0].Cells["ACTIVO"].Value) == "Bloque A",
            "La partida debe mostrar únicamente sus activos asignados, con nombre legible.");
        asignaciones.Rows[0].Cells["INCLUIR"].Value = false;
        exige(partida.Costos.MetradosBIM.Single().ExcluirDelTotal && !proyecto.ActivosRevit!.Asignaciones.Single().IncluirEnTotal,
            "El checkbox de asignación debe excluir el resultado asociado sin borrarlo.");
        exige(historial == 1 && consultas == 0, "La asignación debe guardar historial sin contactar Revit o Autodesk.");
        panel.ConfigurarPermisoNube(() => true, () => new MYGPermisosModulos { MetradosExcel = false });
        exige(Campo<DataGridView>(panel, "bim").ReadOnly && asignaciones.ReadOnly,
            "El permiso de metrados debe bloquear cambios de inclusión.");
    }
}
