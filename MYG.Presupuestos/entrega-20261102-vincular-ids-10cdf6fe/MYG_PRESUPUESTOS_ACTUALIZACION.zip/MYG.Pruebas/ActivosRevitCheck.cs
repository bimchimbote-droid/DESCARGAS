using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;
using MYG.Externo;

internal static class ActivosRevitCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new InvalidOperationException(detalle); }
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new InvalidOperationException("La operación inválida fue aceptada.");
    }
    private static MYGProyectoDocumento Documento()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Obra de activos", "Estructuras");
        proyecto.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = "Concreto", Unidad = "m³",
            Plantilla = "Concreto", Filtros = new() { new FiltroPlanificacion { Parametro = "Tipo", Regla = "Igual", Valor = "210" } }
        });
        MYGProyectoStorage.Validar(proyecto);
        return proyecto;
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var info = new DocumentoRevitInfo { Id = "abierto", Nombre = " Edificio nube ", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "b.11111111-2222-4333-8444-555555555555", ModeloAutodeskId = "AAAAAAAA-BBBB-4CCC-8DDD-EEEEEEEEEEEE",
            Ruta = @"C:\Cache\no-usar.rvt", DocumentoRevitId = "identidad-verificada-del-conector" };
        string infoOriginal = JsonSerializer.Serialize(info);
        var referencia = MYGTablasActivosRevit.ReferenciaDesdeModelo(info);
        Exige(referencia.Nombre == "Edificio nube" && referencia.Origen == MYGOrigenActivoRevit.Autodesk
            && referencia.ProyectoAutodeskId == "11111111-2222-4333-8444-555555555555"
            && referencia.ModeloAutodeskId == "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee" && referencia.RutaLocal == null
            && referencia.DocumentoRevitId == null && JsonSerializer.Serialize(info) == infoOriginal,
            "Traer IDs debe normalizar ambos GUID sin usar la caché local, modificar la respuesta o acreditar un vínculo.");
        var obraReferencia = Documento();
        MYGActivosRevit.GuardarActivo(obraReferencia, referencia);
        Exige(obraReferencia.ActivosRevit.Activos.Single().DocumentoRevitId == null,
            "Guardar los IDs importados no debe acreditar por sí solo un vínculo con el modelo.");
        pasa("Traer IDs de Autodesk conserva ambos GUID, descarta rutas de caché y mantiene la referencia pendiente de vincular");
        var infoLocal = new DocumentoRevitInfo { Nombre = "Local", Origen = MYGOrigenActivoRevit.Local,
            EsColaborativo = true, Ruta = @"C:\Usuarios\modelo_local.rvt", RutaCentral = @"\\Servidor\BIM\Central.rvt" };
        var referenciaLocal = MYGTablasActivosRevit.ReferenciaDesdeModelo(infoLocal);
        Exige(referenciaLocal.RutaLocal == "//Servidor/BIM/Central.rvt" && referenciaLocal.ProyectoAutodeskId == null
            && referenciaLocal.ModeloAutodeskId == null && referenciaLocal.DocumentoRevitId == null,
            "El archivo local debe usar la referencia central sin inventar identificadores Autodesk.");
        Rechaza(() => MYGTablasActivosRevit.ReferenciaDesdeModelo(new DocumentoRevitInfo { Nombre = "Sin guardar" }));
        Rechaza(() => MYGTablasActivosRevit.ReferenciaDesdeModelo(new DocumentoRevitInfo { Nombre = "Origen inválido", Origen = (MYGOrigenActivoRevit)123 }));
        foreach (string valor in new[] { "", "urn:adsk.wipprod:dm.lineage:version", "00000000-0000-0000-0000-000000000000" })
        {
            var invalida = MYGProyectoStorage.Copia(info); invalida.ModeloAutodeskId = valor;
            Rechaza(() => MYGTablasActivosRevit.ReferenciaDesdeModelo(invalida));
        }
        infoLocal.EsModeloSeparado = true;
        Rechaza(() => MYGTablasActivosRevit.ReferenciaDesdeModelo(infoLocal));
        pasa("La lectura de activos locales usa el central y rechaza modelos sin guardar, separados o con IDs de nube incompletos");

        var proyecto = Documento();
        var p = proyecto.Presupuestos.Single(); var i = p.Items.Single();
        string firma = MYGProyectoStorage.Firma(proyecto);
        Exige(!firma.Contains("ActivosRevit", StringComparison.Ordinal) && !firma.Contains("ExcluirDelTotal", StringComparison.Ordinal),
            "Los campos opcionales alteraron la firma de una obra anterior.");
        var anterior = JsonSerializer.Deserialize<MYGProyectoDocumento>(firma);
        Exige(anterior.ActivosRevit == null, "Un documento anterior creó registros de activos implícitos.");
        pasa("Activos Revit opcionales conservan el formato anterior y no crean conexiones al abrir");

        var local = MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Bloque A", RutaLocal = @"D:\Obras\BloqueA.rvt" });
        var nube = MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Bloque B", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "proyecto-autodesk", ModeloAutodeskId = "modelo-estructuras", DocumentoRevitId = "documento-B" });
        MYGActivosRevit.Asignar(proyecto, p.Id, i.Id, local.Id);
        MYGActivosRevit.Asignar(proyecto, p.Id, i.Id, nube.Id);
        MYGActivosRevit.Asignar(proyecto, p.Id, i.Id, nube.Id);
        Exige(proyecto.ActivosRevit.Activos.Count == 2 && proyecto.ActivosRevit.Asignaciones.Count == 2, "La asignación idempotente duplicó la relación.");
        local.Nombre = "Bloque A renombrado"; local.RutaLocal = @"D:\NuevaRuta\BloqueA.rvt";
        MYGActivosRevit.GuardarActivo(proyecto, local);
        Exige(proyecto.ActivosRevit.Asignaciones.Any(a => a.ActivoId == local.Id), "Renombrar un activo perdió sus asignaciones.");
        pasa("Activos locales y Autodesk comparten registro con identidad estable y asignaciones únicas");

        string sinCambios = MYGProyectoStorage.Firma(proyecto);
        Rechaza(() => MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Duplicado", RutaLocal = "d:/nuevaruta/BLOQUEA.RVT" }));
        Rechaza(() => MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Otro cloud", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = nube.ProyectoAutodeskId, ModeloAutodeskId = nube.ModeloAutodeskId }));
        Rechaza(() => MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Otro doc", RutaLocal = "D:/Otro.rvt", DocumentoRevitId = nube.DocumentoRevitId }));
        Rechaza(() => MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Cloud sin modelo", Origen = MYGOrigenActivoRevit.Autodesk, ProyectoAutodeskId = "proyecto" }));
        Exige(MYGProyectoStorage.Firma(proyecto) == sinCambios, "Un registro rechazado cambió la obra.");
        pasa("Activos rechazan archivos, modelos y documentos duplicados o incompletos sin cambios parciales");

        Rechaza(() => MYGActivosRevit.Asignar(proyecto, p.Id, "partida-inexistente", local.Id));
        Rechaza(() => MYGActivosRevit.Asignar(proyecto, p.Id, i.Id, "activo-inexistente"));
        var titulo = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "TITULO", Descripcion = "Título" };
        p.Items.Add(titulo);
        Rechaza(() => MYGActivosRevit.Asignar(proyecto, p.Id, titulo.Id, local.Id));
        p.Items.Remove(titulo);
        Rechaza(() => MYGActivosRevit.EliminarActivo(proyecto, local.Id));
        pasa("Asignaciones solo aceptan partidas existentes y protegen activos todavía utilizados");

        i.Costos.FuenteMetrado = MYGFuenteMetrado.BIM;
        i.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = local.Id, Cantidad = 24.5m, Unidad = "m³" });
        i.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = nube.Id, Cantidad = 18.3m, Unidad = "m³" });
        Exige(MYGMotorPresupuestos.Cantidad(p, i) == 42.8m, "El total BIM anterior cambió.");
        MYGActivosRevit.CambiarInclusion(proyecto, p.Id, i.Id, nube.Id, false);
        Exige(MYGMotorPresupuestos.Cantidad(p, i) == 24.5m && !proyecto.ActivosRevit.Asignaciones.Single(a => a.ActivoId == nube.Id).IncluirEnTotal,
            "La exclusión del activo no se aplicó a su cantidad.");
        Exige(i.Costos.MetradosBIM.Single(m => m.ActivoId == nube.Id).Cantidad == 18.3m, "Excluir un metrado eliminó su cantidad recibida.");
        pasa("Usar en total excluye resultados registrados sin borrar las cantidades ni alterar los valores anteriores por defecto");

        string Snapshot(string activo, decimal cantidad) => JsonSerializer.Serialize(new
        {
            VersionFormato = 1, ActivoId = activo, ProyectoId = proyecto.IdProyectoRevit, PresupuestoId = p.IdPresupuestoRevit,
            ArchivoRvt = "documento", Partidas = new[] { new { ClavePartida = i.Id, Unidad = "m³", Metrado = cantidad, TablaPlanificacion = "Tabla" } }
        });
        MYGMotorPresupuestos.ImportarMetradoBIM(proyecto, p, Snapshot(nube.Id, 20m));
        Exige(i.Costos.MetradosBIM.Single(m => m.ActivoId == nube.Id).ExcluirDelTotal && MYGMotorPresupuestos.Cantidad(p, i) == 24.5m,
            "Actualizar un snapshot reactivó una asignación excluida.");
        MYGMotorPresupuestos.ImportarMetradoBIM(proyecto, p, Snapshot("activo-legado", 3m));
        i.Costos.MetradosBIM.Single(m => m.ActivoId == "activo-legado").ExcluirDelTotal = true;
        MYGMotorPresupuestos.ImportarMetradoBIM(proyecto, p, Snapshot("activo-legado", 9m));
        Exige(i.Costos.MetradosBIM.Single(m => m.ActivoId == "activo-legado").ExcluirDelTotal, "Actualizar un snapshot antiguo perdió su exclusión explícita.");
        pasa("Actualizar snapshots conserva la selección de cantidades tanto en activos registrados como heredados");

        string ruta = Path.Combine(carpeta, "activos-revit.myg.json");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        foreach (string archivo in new[] { ruta, MYGBaseDatos.RutaDeProyecto(ruta) })
        {
            var leido = MYGProyectoStorage.Leer(archivo);
            Exige(leido.ActivosRevit.Activos.Count == 2 && leido.ActivosRevit.Asignaciones.Count == 2,
                "Reabrir perdió el registro o las asignaciones de la obra.");
            Exige(leido.ActivosRevit.Activos.Single(a => a.Id == nube.Id).ModeloAutodeskId == "modelo-estructuras" &&
                !leido.ActivosRevit.Asignaciones.Single(a => a.ActivoId == nube.Id).IncluirEnTotal,
                "Reabrir cambió el vínculo cloud o su inclusión.");
            Exige(leido.Presupuestos.Single().Items.Single().Costos.MetradosBIM.Single(m => m.ActivoId == nube.Id).ExcluirDelTotal,
                "La exclusión del resultado no sobrevivió al guardado.");
        }
        pasa("JSON y SQLite reales conservan activos, destinos Autodesk, asignaciones y exclusiones de resultados BIM");

        var otraObra = MYGProyectoStorage.Nuevo("Otra obra");
        otraObra.Presupuestos.Clear();
        otraObra.Presupuestos.Add(MYGProyectoStorage.CopiarComoPlantilla(p, "Configuración reutilizada"));
        Exige(otraObra.ActivosRevit == null && otraObra.Presupuestos.Single().Items.Single().Plantilla == i.Plantilla,
            "Reutilizar una plantilla transfirió el registro de activos de otra obra o perdió su configuración.");
        var copia = MYGProyectoStorage.Copia(proyecto);
        copia.ActivosRevit.Activos[0].Nombre = "Solo en copia";
        Exige(proyecto.ActivosRevit.Activos[0].Nombre != "Solo en copia", "La copia comparte activos por referencia.");
        copia.Presupuestos.Single().Items.Clear();
        MYGActivosRevit.LimpiarAsignacionesHuerfanas(copia);
        Exige(copia.ActivosRevit.Asignaciones.Count == 0 && proyecto.ActivosRevit.Asignaciones.Count == 2,
            "Limpiar partidas eliminadas afectó otra obra o dejó vínculos huérfanos.");
        pasa("Plantillas reutilizan filtros sin asignaciones de otra obra y la limpieza conserva originales e historial");
    }
}
