# Traer/copiar IDs Autodesk y vincular el activo

Actualización incremental sobre la entrega anterior de plantillas y filtros publicada en DESCARGAS, commit `48271e3cd86e155749d9511aafc17e5aa655a25a`. Main se comprobó en `a3130eca22fb423fbe7aae665a02dccdb379522c`. Los archivos REEMPLAZAR se entregan completos; compare antes si tiene modificaciones propias posteriores.

## Uso
En **Activos Revit de la obra**, la misma ventana de la captura:

- **Traer del modelo abierto**: lee los datos de Revit y rellena el origen, ruta local o ambos GUID Autodesk. Ya no necesita extraerlos con Dynamo. No registra ni vincula el activo por sí solo.
- **Copiar** junto a cada ID, o seleccionar y pulsar Ctrl+C: los campos siguen habilitados y seleccionables incluso en consulta. Si el portapapeles está ocupado se conserva el texto y se muestra cómo reintentar.
- **Vincular**: consulta el modelo de nuevo. Para un activo nuevo crea o reutiliza una referencia inequívoca y vincula su identidad; para uno seleccionado exige que coincida con la referencia guardada. Si tiene cambios pendientes, guarde primero el activo y pulse Vincular después. No sustituye un vínculo de otro modelo silenciosamente.
- **Aplicar a la obra**: confirma el registro/vínculo en el documento. Después use Guardar en la obra para conservarlo en SQLite y sincronice si corresponde. Cancelar cierra el diálogo y descarta sus cambios.

Si hay un modelo disponible se elige automáticamente; con varios se abre el selector, también para archivos de la misma instancia si ya instaló el conector de la entrega anterior. Esta consulta no cambia la conexión de plantillas de la ventana principal ni activa/modifica documentos en Revit.

Para empezar desde cero: abra el RVT en Revit con el conector MYG, entre al gestor de activos, pulse Nuevo activo si corresponde y luego **Vincular**; elija el modelo si aparece un selector y pulse **Aplicar a la obra**. Si sólo quiere consultar/copiar GUID, use **Traer del modelo abierto** y los botones Copiar.

En archivos locales no se necesitan IDs Autodesk; se lee la ruta del RVT o del central. Los modelos sin guardar o separados del central requieren guardar una referencia válida primero. Los GUID importados se validan y normalizan; no se usan enlaces de navegador, URN de versiones ni rutas de caché como identidad de nube.

## Instalar
1. Cierre MYG y respalde/confirme sus cambios locales. Extraiga este ZIP en una carpeta temporal.
2. Copie sus archivos a la raíz del repositorio conservando las rutas de la tabla. No sobrescriba bases SQLite ni sidecars de nube.
3. Restaure y compile con SDK .NET 10 y Visual Studio compatible:

```powershell
dotnet restore MYG.Presupuestos.sln
dotnet build MYG.Presupuestos.sln -c Release
```

Ejecute la aplicación recompilada con su MYG.Core.dll correspondiente. No hay SQL, paquetes externos ni credenciales nuevos. Se reutiliza el conector instalado; para varios documentos en una instancia use el conector actualizado de la entrega anterior. Si aún no lo instaló, cierre Revit y ejecute el script existente `scripts/Actualizar-Conector.ps1`, después abra Revit de nuevo.

La edición/vinculación respeta el permiso Metrados Revit y la autorización de la obra. Copiar información existente en consulta no habilita cambios. Se mantienen las limitaciones ya documentadas para sincronizar configuración de activos desde una copia SQLite con permisos restringidos; esta entrega no amplía el protocolo de sincronización de activos.

## Validación ejecutada
SDK .NET 10.0.100, solución completa Release con referencias Revit NuGet: **0 errores y 0 advertencias**.

```text
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --activos-revit
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --tablas-activos-revit
```

**10 grupos de activos y 8 de tablas/vínculos aprobados.** Cubren GUID válidos/incompletos, prefijos de proyecto, exclusión de rutas de caché, referencias locales/centrales, persistencia SQLite, identidad del modelo, duplicados, asignaciones y vínculos cruzados.

Pruebas UI nuevas compiladas para importar nube/local, cancelar, cerrar durante consulta, revocar permisos, copiar en consulta, vincular un activo nuevo, reutilizar sin duplicar y rechazar referencias incompatibles. La ejecución visual, el portapapeles Windows y una sesión real de Revit no se ejecutaron en Linux. Para probarlos en Windows:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --activos-revit
```

## GitHub del código
No se hizo Push ni se fusionó código. Después de aplicar y probar en Windows, use Cambios de Git de Visual Studio para revisar, hacer Commit y Push a su rama de trabajo. La publicación del ZIP en DESCARGAS no instala ni actualiza su checkout automáticamente.

## Archivos de esta entrega

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `IDS_AUTODESK_Y_VINCULAR_ACTIVO.md` | CREAR | Uso, instalación y lista de archivos |
| 2 | `MYG.Core/ActivosRevitTablas.cs` | REEMPLAZAR | Validar y preparar referencias del modelo sin autovincular |
| 3 | `MYG.Desktop/ActivosRevitForm.cs` | REEMPLAZAR | Traer, copiar y vincular con confirmación del borrador |
| 4 | `MYG.Desktop/EditorForm.cs` | REEMPLAZAR | Reutilizar selección de modelos desde el gestor de activos |
| 5 | `MYG.Desktop/PresupuestosActivosRevit.cs` | REEMPLAZAR | Conectar consulta de Revit y permisos del módulo |
| 6 | `MYG.Pruebas/ActivosRevitCheck.cs` | REEMPLAZAR | Pruebas ejecutables de importación y persistencia |
| 7 | `MYG.PruebasUI/ActivosRevitUICheck.cs` | REEMPLAZAR | Pruebas visuales de copia, cancelación y vinculación |
