using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class AsistenteCronogramaIAUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarExportacionYCancelacion(exige);
        VerificarReplanteamientoCompleto(exige);
        VerificarTareasManualesSinElegibles(exige);
        VerificarCasillasDePrevisualizacion(exige);
        VerificarSeleccionInicialDelGantt(exige);
        VerificarLimiteDePredecesoras(exige);
        VerificarPlazoObligatorio(exige);
        VerificarFechasSinRegistrar(exige);
        VerificarCuadrillasPropuestas(exige);
        VerificarSoloLectura(exige);
        VerificarCintaAplicacionEHistorial(exige);
    }

    private static void VerificarExportacionYCancelacion(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        string original = JsonSerializer.Serialize(proyecto);
        using (var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true))
        {
            dialogo.Show();
            Application.DoEvents();
            exige(dialogo.Name == "cronograma_ia_dialogo" && !dialogo.PuedeAplicar &&
                !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled && dialogo.AcceptButton == null,
                "El asistente debe abrir sin una propuesta aplicable y con Aplicar deshabilitado.");
            exige(!Control<DateTimePicker>(dialogo, "cronograma_ia_inicio").Enabled &&
                !Control<NumericUpDown>(dialogo, "cronograma_ia_plazo").Enabled &&
                Control<CheckBox>(dialogo, "cronograma_ia_recalcular").Enabled &&
                Control<CheckBox>(dialogo, "cronograma_ia_reprogramar").Enabled &&
                Control<TextBox>(dialogo, "cronograma_ia_contexto").Enabled &&
                Control<Label>(dialogo, "cronograma_ia_regla_fechas").Text.Contains("Datos del proyecto", StringComparison.Ordinal),
                "Las fechas definidas en la ficha deben quedar bloqueadas con indicación para editar Datos del proyecto; duraciones, modos y contexto siguen disponibles.");
            string datos = dialogo.CrearDatosParaIA();
            string prompt = dialogo.CrearPromptParaIA();
            using (var json = JsonDocument.Parse(datos))
                exige(json.RootElement.ValueKind == JsonValueKind.Object && datos.Contains("Trabajo IA 1", StringComparison.Ordinal),
                    "La exportación debe producir un paquete JSON con las tareas del proyecto actual.");
            exige(!string.IsNullOrWhiteSpace(prompt) && prompt.Contains("JSON", StringComparison.OrdinalIgnoreCase),
                "El prompt exportado debe explicar el contrato de respuesta JSON de la propuesta.");
            dialogo.CargarPaquete(datos);
            exige(JsonSerializer.Serialize(proyecto) == original && !dialogo.PuedeAplicar,
                "Exportar el paquete y el prompt y volver a cargar los datos no debe cambiar el proyecto ni crear una propuesta.");
            Control<Button>(dialogo, "cronograma_ia_cerrar").PerformClick();
            Application.DoEvents();
            exige(dialogo.DialogResult != DialogResult.OK && JsonSerializer.Serialize(proyecto) == original,
                "Cerrar el asistente después de exportar y cargar datos debe conservar todo el documento original.");
        }
        using (var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true))
        {
            dialogo.Show();
            UsarModoParcial(dialogo);
            dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan));
            dialogo.SeleccionarTareas(new[] { plan.Tareas[0].Id });
            Application.DoEvents();
            exige(Control<DataGridView>(dialogo, "cronograma_ia_cambios").Rows.Count >= 2 &&
                JsonSerializer.Serialize(proyecto) == original,
                "Importar y previsualizar las tareas propuestas debe mostrar cambios sin modificar el cronograma.");
            var fila = Control<DataGridView>(dialogo, "cronograma_ia_cambios").Rows.Cast<DataGridViewRow>()
                .Single(r => Equals(r.Tag, plan.Tareas[0].Id));
            exige(Convert.ToString(fila.Cells["ANTES"].Value) != Convert.ToString(fila.Cells["DESPUES"].Value) &&
                fila.Cells["INICIO"].Value != null && fila.Cells["FIN"].Value != null,
                "La previsualización debe mostrar las predecesoras anteriores y propuestas junto a las fechas calculadas.");
            bool rechazada = false;
            try { dialogo.CargarPropuesta("{"); }
            catch (InvalidDataException) { rechazada = true; }
            exige(rechazada && !dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled &&
                JsonSerializer.Serialize(proyecto) == original,
                "Importar una respuesta inválida debe retirar la propuesta anterior y deshabilitar Aplicar sin cambios en el origen.");
            dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan));
            dialogo.SeleccionarTareas(new[] { plan.Tareas[0].Id });
            Control<Button>(dialogo, "cronograma_ia_cerrar").PerformClick();
            Application.DoEvents();
            exige(JsonSerializer.Serialize(proyecto) == original,
                "Cancelar una propuesta previsualizada conserva tareas, presupuesto y datos del proyecto.");
        }
    }

    private static void VerificarReplanteamientoCompleto(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        plan.Tareas[0].Predecesoras.Add(new() { PredecesoraId = plan.Tareas[1].Id, Tipo = MYGTipoVinculo.FC });
        var tercera = new MYGTareaCronograma { Nombre = "Tercer frente elegible", DuracionDias = 5 };
        var manual = new MYGTareaCronograma
        {
            Nombre = "Frente manual protegido", DuracionDias = 5,
            Modo = MYGModoTarea.Manual, InicioManual = plan.FechaInicio
        };
        var resumen = new MYGTareaCronograma { Nombre = "Resumen de frentes", EsResumen = true, DuracionDias = 0 };
        plan.Tareas.AddRange(new[] { tercera, manual });
        foreach (var tarea in plan.Tareas) tarea.PadreId = resumen.Id;
        plan.Tareas.Insert(0, resumen);
        string original = JsonSerializer.Serialize(proyecto);
        var fechasOriginales = MYGMotorCronograma.Calcular(plan);
        using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true);
        dialogo.Show();
        Application.DoEvents();
        var todas = Control<CheckBox>(dialogo, "cronograma_ia_replantear_todas");
        var reprogramar = Control<CheckBox>(dialogo, "cronograma_ia_reprogramar");
        var aplicar = Control<Button>(dialogo, "cronograma_ia_aplicar");
        var revisar = Control<Button>(dialogo, "cronograma_ia_revisar");
        var copiar = Control<Button>(dialogo, "cronograma_ia_prompt");
        var cambios = Control<DataGridView>(dialogo, "cronograma_ia_cambios");
        var estado = Control<Label>(dialogo, "cronograma_ia_estado");
        exige(todas.Checked && dialogo.Paquete.Opciones.ReplantearTodasLasTareas && !reprogramar.Checked &&
            dialogo.Paquete.Tareas.Count(t => t.Editable) == 3 &&
            !dialogo.Paquete.Tareas.Single(t => t.TareaId == manual.Id).Editable &&
            !dialogo.Paquete.Tareas.Single(t => t.TareaId == resumen.Id).Editable &&
            estado.Text.Contains("Cobertura requerida: 3 elegibles; recibidas: 0; seleccionadas: 0", StringComparison.Ordinal) &&
            estado.Text.Contains("Protegidas: 1; resúmenes: 1", StringComparison.Ordinal),
            "El asistente debe exigir por defecto todas las elegibles, contar aparte protegidas y resúmenes y mantener separado el permiso de tareas manuales.");
        string paqueteCompleto = dialogo.CrearDatosParaIA();
        bool incompletaRechazada = false;
        try
        {
            dialogo.CargarPropuesta(JsonSerializer.Serialize(new MYGPropuestaCronogramaIA
            {
                Firma = dialogo.Paquete.Firma,
                Tareas = new() { new() { TareaId = tercera.Id, Justificacion = "Este frente independiente conserva su programación." } }
            }));
        }
        catch (InvalidDataException) { incompletaRechazada = true; }
        exige(fechasOriginales.Inicio == proyecto.Datos.FechaInicio && fechasOriginales.Fin == proyecto.Datos.FechaFin &&
            incompletaRechazada && !dialogo.PuedeAplicar && !aplicar.Enabled && cambios.Rows.Count == 0 &&
            JsonSerializer.Serialize(proyecto) == original,
            "Una respuesta de una sola tarea entre tres elegibles debe rechazarse aunque el cronograma ya cumpla ambas fechas, sin conservar una propuesta aplicable ni cambiar el origen.");
        dialogo.CargarPropuesta(PropuestaCompleta());
        Application.DoEvents();
        var elegibles = dialogo.Paquete.Tareas.Where(t => t.Editable).Select(t => t.TareaId).ToArray();
        exige(cambios.Rows.Count == 3 && dialogo.PuedeAplicar && aplicar.Enabled &&
            cambios.Rows.Cast<DataGridViewRow>().All(r => r.Cells["SELECCION"].Value is true) &&
            estado.Text.Contains("recibidas: 3; seleccionadas: 3", StringComparison.Ordinal) &&
            cambios.Rows.Cast<DataGridViewRow>().All(r => !Equals(r.Tag, manual.Id) && !Equals(r.Tag, resumen.Id)),
            "Una respuesta completa debe mostrar y seleccionar las tres tareas elegibles, sin incluir las protegidas ni los resúmenes.");
        dialogo.SeleccionarTareas(elegibles.Where(id => id != tercera.Id));
        bool seleccionIncompletaRechazada = false;
        try { dialogo.PrepararAplicacion(proyecto, plan); }
        catch (InvalidDataException) { seleccionIncompletaRechazada = true; }
        exige(!dialogo.PuedeAplicar && !aplicar.Enabled && seleccionIncompletaRechazada &&
            estado.Text.Contains("recibidas: 3; seleccionadas: 2", StringComparison.Ordinal) &&
            estado.Text.Contains("faltan 1 tareas por seleccionar", StringComparison.Ordinal) &&
            estado.Text.Contains("Aplicar bloqueado", StringComparison.Ordinal) &&
            JsonSerializer.Serialize(proyecto) == original,
            "Desmarcar una tarea independiente debe bloquear tanto Aplicar como su validación directa por cobertura incompleta aunque no cambien las fechas.");
        dialogo.SeleccionarTareas(elegibles);
        exige(dialogo.PuedeAplicar && aplicar.Enabled,
            "Volver a marcar todas las elegibles debe habilitar la propuesta completa sin pedir otra respuesta.");

        todas.Checked = false;
        Application.DoEvents();
        exige(cambios.Rows.Count == 0 && !dialogo.PuedeAplicar && !aplicar.Enabled && !copiar.Enabled,
            "Cambiar el alcance del replanteamiento debe invalidar la propuesta y el paquete anterior y exigir datos y prompt nuevos.");
        revisar.PerformClick();
        string paqueteParcial = dialogo.CrearDatosParaIA();
        exige(!dialogo.Paquete.Opciones.ReplantearTodasLasTareas && copiar.Enabled &&
            estado.Text.Contains("Modo parcial", StringComparison.Ordinal),
            "La revisión explícita después de desmarcar el alcance debe preparar un paquete de propuestas parciales.");
        todas.Checked = true;
        revisar.PerformClick();
        dialogo.CargarPaquete(paqueteParcial);
        exige(!todas.Checked && !dialogo.Paquete.Opciones.ReplantearTodasLasTareas &&
            estado.Text.Contains("Modo parcial", StringComparison.Ordinal) && !dialogo.PuedeAplicar,
            "Recuperar un paquete parcial debe restaurar su opción de alcance sin crear una propuesta aplicable.");
        dialogo.CargarPaquete(paqueteCompleto);
        exige(todas.Checked && dialogo.Paquete.Opciones.ReplantearTodasLasTareas &&
            estado.Text.Contains("Cobertura requerida: 3 elegibles", StringComparison.Ordinal) && !dialogo.PuedeAplicar,
            "Recuperar un paquete completo debe restaurar la exigencia de todas las elegibles y su cobertura requerida.");

        reprogramar.Checked = true;
        revisar.PerformClick();
        exige(todas.Checked && dialogo.Paquete.Opciones.ReprogramarManualesEImportadas &&
            dialogo.Paquete.Tareas.Count(t => t.Editable) == 4 &&
            dialogo.Paquete.Tareas.Single(t => t.TareaId == manual.Id).Editable &&
            estado.Text.Contains("Protegidas: 0; resúmenes: 1", StringComparison.Ordinal),
            "Autorizar expresamente la reprogramación manual debe ampliar la cobertura requerida a las cuatro tareas y conservar el resumen protegido.");
        dialogo.CargarPropuesta(PropuestaCompleta());
        var aplicado = dialogo.PrepararAplicacion(proyecto, plan);
        exige(cambios.Rows.Count == 4 && dialogo.PuedeAplicar && aplicar.Enabled &&
            aplicado.Tareas.Single(t => t.Id == manual.Id).Modo == MYGModoTarea.Automatica &&
            estado.Text.Contains("Cobertura requerida: 4 elegibles; recibidas: 4; seleccionadas: 4", StringComparison.Ordinal) &&
            JsonSerializer.Serialize(proyecto) == original,
            "La respuesta completa tras autorizar tareas manuales debe incluirlas todas y preparar su reprogramación sobre una copia sin modificar el documento original.");
        dialogo.Close();

        string PropuestaCompleta() => JsonSerializer.Serialize(new MYGPropuestaCronogramaIA
        {
            Firma = dialogo.Paquete.Firma,
            Tareas = dialogo.Paquete.Tareas.Where(t => t.Editable).Select(t => new MYGTareaPropuestaCronogramaIA
            {
                TareaId = t.TareaId,
                Predecesoras = plan.Tareas.Single(original => original.Id == t.TareaId).Predecesoras.Select(d =>
                    new MYGPredecesoraPropuestaCronogramaIA
                    { PredecesoraId = d.PredecesoraId, Tipo = d.Tipo.ToString(), DesfaseDias = d.DesfaseDias, Unidad = "laborables" }).ToList(),
                Justificacion = "Se revisa este frente conservando la duración y sus liberaciones inmediatas dentro del plazo exacto."
            }).ToList()
        });
    }

    private static void VerificarTareasManualesSinElegibles(Action<bool, string> exige)
    {
        foreach (bool soloLectura in new[] { false, true })
        {
            var (proyecto, plan) = CrearProyecto();
            foreach (var tarea in plan.Tareas)
            {
                tarea.Modo = MYGModoTarea.Manual;
                tarea.InicioManual = plan.FechaInicio;
            }
            string original = JsonSerializer.Serialize(proyecto);
            using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => !soloLectura);
            dialogo.Show();
            var revisar = Control<Button>(dialogo, "cronograma_ia_revisar");
            var copiarPrompt = Control<Button>(dialogo, "cronograma_ia_prompt");
            var exportar = Control<Button>(dialogo, "cronograma_ia_exportar");
            var aplicar = Control<Button>(dialogo, "cronograma_ia_aplicar");
            var reprogramar = Control<CheckBox>(dialogo, "cronograma_ia_reprogramar");
            var datos = Control<DataGridView>(dialogo, "cronograma_ia_datos");
            var cambios = Control<DataGridView>(dialogo, "cronograma_ia_cambios");
            revisar.PerformClick();
            Application.DoEvents();
            var paqueteOriginal = dialogo.Paquete;
            exige(paqueteOriginal.Tareas.Count == 2 && paqueteOriginal.Tareas.All(t => !t.Editable) &&
                !copiarPrompt.Enabled && !aplicar.Enabled,
                "Un cronograma con todas las tareas manuales debe deshabilitar Copiar prompt y Aplicar mientras no se autorice su reprogramación.");
            string avisos = Control<TextBox>(dialogo, "cronograma_ia_avisos").Text;
            exige(avisos.Contains("Permitir reprogramar tareas manuales o importadas", StringComparison.OrdinalIgnoreCase) &&
                avisos.Contains("Revisar datos", StringComparison.OrdinalIgnoreCase) &&
                avisos.Contains("NUEVO archivo de datos", StringComparison.OrdinalIgnoreCase) &&
                avisos.Contains("NUEVO prompt", StringComparison.OrdinalIgnoreCase),
                "La revisión sin tareas elegibles debe explicar qué casilla activar y pedir nuevos datos y prompt después de revisar.");
            using (var json = JsonDocument.Parse(dialogo.CrearDatosParaIA()))
                exige(exportar.Enabled && json.RootElement.GetProperty("Tareas").GetArrayLength() == 2 &&
                    json.RootElement.GetProperty("Tareas").EnumerateArray().All(t => !t.GetProperty("Editable").GetBoolean()),
                    "La exportación de datos debe seguir disponible para revisar las dos tareas protegidas sin producir un prompt vacío.");

            reprogramar.Checked = true;
            Application.DoEvents();
            exige(datos.Rows.Count == 0 && cambios.Rows.Count == 0 && !copiarPrompt.Enabled &&
                !dialogo.PuedeAplicar && !aplicar.Enabled,
                "Activar la reprogramación debe invalidar el paquete anterior y exigir revisión antes de habilitar el prompt.");
            revisar.PerformClick();
            Application.DoEvents();
            var paqueteNuevo = dialogo.Paquete;
            exige(!ReferenceEquals(paqueteNuevo, paqueteOriginal) && paqueteNuevo.Firma != paqueteOriginal.Firma &&
                paqueteNuevo.Opciones.ReprogramarManualesEImportadas && paqueteNuevo.Tareas.Count(t => t.Editable) == 2 &&
                copiarPrompt.Enabled && datos.Rows.Count == 2,
                "Revisar con la casilla activada debe generar otra firma, habilitar ambas tareas y permitir copiar el nuevo prompt.");
            exige(!aplicar.Enabled && !dialogo.PuedeAplicar &&
                dialogo.CrearPromptParaIA().Contains(plan.Tareas[0].Id, StringComparison.Ordinal) &&
                JsonSerializer.Serialize(proyecto) == original,
                "Regenerar datos y prompt no debe modificar las tareas manuales ni habilitar Aplicar antes de importar una propuesta válida.");

            dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan));
            Application.DoEvents();
            exige(cambios.Rows.Count == 2 && dialogo.PuedeAplicar == !soloLectura && aplicar.Enabled == !soloLectura,
                "Una propuesta válida de tareas manuales sólo debe habilitar Aplicar cuando también existe permiso de edición.");
            reprogramar.Checked = false;
            reprogramar.Checked = true;
            Application.DoEvents();
            exige(cambios.Rows.Count == 0 && datos.Rows.Count == 0 && !aplicar.Enabled && !copiarPrompt.Enabled,
                "Cambiar nuevamente la opción debe retirar la propuesta importada y el paquete revisado anterior.");
            revisar.PerformClick();
            Application.DoEvents();
            exige(copiarPrompt.Enabled && !dialogo.PuedeAplicar && !aplicar.Enabled &&
                JsonSerializer.Serialize(proyecto) == original,
                "Otra revisión debe permitir obtener un nuevo prompt sin recuperar automáticamente la propuesta invalidada ni cambiar el origen.");
            dialogo.Close();
        }
    }

    private static void VerificarCasillasDePrevisualizacion(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        string original = JsonSerializer.Serialize(proyecto);
        using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true);
        dialogo.Show();
        UsarModoParcial(dialogo);
        dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan));
        Application.DoEvents();
        var tabla = Control<DataGridView>(dialogo, "cronograma_ia_cambios");
        var filas = tabla.Rows.Cast<DataGridViewRow>().ToArray();
        var primera = filas.Single(r => Equals(r.Tag, plan.Tareas[0].Id));
        var segunda = filas.Single(r => Equals(r.Tag, plan.Tareas[1].Id));
        exige(filas.All(r => r.Cells["SELECCION"].Value is true),
            "Las tareas de una propuesta válida deben aparecer inicialmente seleccionadas.");

        Marcar(primera, false);
        bool parcialRechazada = false;
        try { dialogo.PrepararAplicacion(proyecto, plan); }
        catch (InvalidDataException) { parcialRechazada = true; }
        exige(parcialRechazada &&
            Convert.ToString(primera.Cells["DESPUES"].Value) == Convert.ToString(primera.Cells["ANTES"].Value) &&
            !dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled,
            "Desmarcar el vínculo que completa el plazo debe conservar la previsualización, pero bloquear tanto el botón como la aplicación directa de la selección parcial.");

        Marcar(segunda, false);
        exige(!dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled &&
            filas.All(r => r.Cells["SELECCION"].Value is false),
            "Confirmar la última casilla desmarcada debe deshabilitar Aplicar y conservar las casillas vacías.");

        Marcar(primera, true);
        var conVinculo = dialogo.PrepararAplicacion(proyecto, plan);
        exige(dialogo.PuedeAplicar && Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled &&
            conVinculo.Tareas[0].Predecesoras.Single().PredecesoraId == plan.Tareas[1].Id &&
            primera.Cells["SELECCION"].Value is true && segunda.Cells["SELECCION"].Value is false &&
            JsonSerializer.Serialize(proyecto) == original,
            "Volver a marcar una casilla debe restaurar sólo su propuesta y mantener el documento de origen intacto.");
        dialogo.Close();

        void Marcar(DataGridViewRow fila, bool valor)
        {
            var celda = (DataGridViewCheckBoxCell)fila.Cells["SELECCION"];
            tabla.CurrentCell = celda;
            tabla.Focus();
            exige(tabla.BeginEdit(false), "La casilla de propuesta debe admitir edición real en la tabla.");
            var edicion = (IDataGridViewEditingCell)celda;
            edicion.EditingCellFormattedValue = valor;
            edicion.EditingCellValueChanged = true;
            // El manejador real CurrentCellDirtyStateChanged confirma la
            // casilla y recalcula desde CellValueChanged mientras sigue editándose.
            tabla.NotifyCurrentCellDirty(true);
            exige(tabla.CommitEdit(DataGridViewDataErrorContexts.Commit) && tabla.EndEdit(),
                "La confirmación de una casilla no debe interrumpirse al recalcular la previsualización.");
            Application.DoEvents();
            exige(tabla.Rows.Cast<DataGridViewRow>().SequenceEqual(filas) &&
                ReferenceEquals(tabla.CurrentRow, fila) && ReferenceEquals(tabla.CurrentCell, celda) &&
                tabla.ContainsFocus && Equals(celda.Value, valor),
                "Recalcular desde una casilla debe conservar las mismas filas, la celda activa, el foco y el valor confirmado.");
        }
    }

    private static void VerificarSeleccionInicialDelGantt(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        var tercera = new MYGTareaCronograma { Nombre = "Tercer frente de revisión IA", DuracionDias = 5 };
        var cuarta = new MYGTareaCronograma
        {
            Nombre = "Otro frente con vínculo existente", DuracionDias = 5,
            Predecesoras = new() { new() { PredecesoraId = plan.Tareas[1].Id, Tipo = MYGTipoVinculo.CC } }
        };
        plan.Tareas.AddRange(new[] { tercera, cuarta });
        string original = JsonSerializer.Serialize(proyecto);
        using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true);
        dialogo.Show();
        UsarModoParcial(dialogo);
        var tabla = Control<DataGridView>(dialogo, "cronograma_ia_cambios");
        var gantt = Control<MYGCronogramaGanttControl>(dialogo, "cronograma_ia_gantt");
        dialogo.CargarPropuesta(PropuestaDeUnaTarea(plan.Tareas[0].Id));
        Application.DoEvents();
        var iniciales = gantt.EnumerarVinculosParaDibujar(0, plan.Tareas.Count).ToArray();
        exige(tabla.Rows.Count == 1 && Equals(tabla.CurrentRow?.Tag, plan.Tareas[0].Id) &&
            gantt.ModoVinculos == MYGModoVinculosGantt.Todos && iniciales.Length == 2 &&
            iniciales.Any(v => v.Origen == 1 && v.Destino == 0 && v.Vinculo.PredecesoraId == plan.Tareas[1].Id) &&
            iniciales.Any(v => v.Origen == 1 && v.Destino == 3),
            "Importar una propuesta debe seleccionar su fila y mostrar por defecto todos los vínculos, incluidos los de otros frentes no seleccionados.");
        gantt.ModoVinculos = MYGModoVinculosGantt.Seleccionadas;
        exige(gantt.EnumerarVinculosParaDibujar(0, plan.Tareas.Count).Single().Destino == 0,
            "Elegir explícitamente el filtro de seleccionadas debe usar la fila inicial de la propuesta sin requerir otro clic en la tabla.");
        gantt.ModoVinculos = MYGModoVinculosGantt.Todos;

        dialogo.CargarPropuesta(PropuestaDeUnaTarea(tercera.Id));
        Application.DoEvents();
        var reimportados = gantt.EnumerarVinculosParaDibujar(0, plan.Tareas.Count).ToArray();
        exige(tabla.Rows.Count == 1 && Equals(tabla.CurrentRow?.Tag, tercera.Id) &&
            gantt.ModoVinculos == MYGModoVinculosGantt.Todos && reimportados.Length == 2 &&
            reimportados.Any(v => v.Origen == 1 && v.Destino == 2 && v.Vinculo.PredecesoraId == plan.Tareas[1].Id) &&
            reimportados.Any(v => v.Origen == 1 && v.Destino == 3),
            "Reimportar otra fila debe seleccionar su nueva identidad y mantener visibles los vínculos del resto de frentes en el modo Todos.");
        gantt.ModoVinculos = MYGModoVinculosGantt.Seleccionadas;
        exige(gantt.EnumerarVinculosParaDibujar(0, plan.Tareas.Count).Single().Destino == 2,
            "El filtro voluntario de seleccionadas debe seguir la fila reimportada y retirar la selección de la propuesta anterior.");

        var filasReimportadas = MYGMotorCronograma.Calcular(dialogo.PrepararAplicacion(proyecto, plan)).Filas;
        Control<TextBox>(dialogo, "cronograma_ia_contexto").Text = "Nuevo contexto: revisar los frentes disponibles.";
        Application.DoEvents();
        exige(tabla.Rows.Count == 0 && !gantt.EnumerarVinculosParaDibujar(0, plan.Tareas.Count).Any() &&
            !dialogo.PuedeAplicar && JsonSerializer.Serialize(proyecto) == original,
            "Invalidar las opciones debe limpiar filas, vínculos y propuesta aplicable sin modificar el documento de origen.");
        // El filtro de seleccionadas se activó voluntariamente. La limpieza del
        // asistente debe retirar su selección aunque vuelvan a aparecer las filas.
        gantt.Cargar(filasReimportadas, plan.Calendario, plan.FechaEstado);
        exige(gantt.ModoVinculos == MYGModoVinculosGantt.Seleccionadas &&
            !gantt.EnumerarVinculosParaDibujar(0, plan.Tareas.Count).Any(),
            "Recargar las mismas filas después de limpiar el asistente no debe resucitar vínculos de una selección antigua.");
        dialogo.Close();

        string PropuestaDeUnaTarea(string tareaId) => JsonSerializer.Serialize(new MYGPropuestaCronogramaIA
        {
            Firma = dialogo.Paquete.Firma,
            Tareas = new()
            {
                new()
                {
                    TareaId = tareaId,
                    Predecesoras = new()
                    {
                        new() { PredecesoraId = plan.Tareas[1].Id, Tipo = "FC", DesfaseDias = 0, Unidad = "laborables" }
                    },
                    Justificacion = "Este frente comienza al concluir el segundo y conserva cinco jornadas de ejecución."
                }
            }
        });
    }

    private static void VerificarLimiteDePredecesoras(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        plan.Tareas.AddRange(new[]
        {
            new MYGTareaCronograma { Nombre = "Tercer frente para convergencia", DuracionDias = 5 },
            new MYGTareaCronograma { Nombre = "Cuarto frente para convergencia", DuracionDias = 5 }
        });
        string original = JsonSerializer.Serialize(proyecto);
        using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true);
        dialogo.Show();
        string[] motivos =
        {
            "El primer frente entrega su plataforma terminada antes del cierre.",
            "El segundo frente libera el acceso de equipos que necesita el cierre.",
            "El tercer frente concluye las instalaciones que deben probarse antes del cierre."
        };
        var convergente = new MYGPropuestaCronogramaIA
        {
            Firma = dialogo.Paquete.Firma,
            Tareas = plan.Tareas.Select((t, indice) => new MYGTareaPropuestaCronogramaIA
            {
                TareaId = t.Id,
                Predecesoras = indice == 0 ? plan.Tareas.Skip(1).Select((predecesora, motivo) =>
                    new MYGPredecesoraPropuestaCronogramaIA
                {
                    PredecesoraId = predecesora.Id, Tipo = "FC", DesfaseDias = 0, Unidad = "laborables",
                    Justificacion = motivos[motivo]
                }).ToList() : new(),
                Justificacion = indice == 0 ? "Cierre que reúne tres liberaciones inmediatas independientes." :
                    "Este frente puede comenzar de manera independiente dentro del plazo del proyecto."
            }).ToList()
        };
        dialogo.CargarPropuesta(JsonSerializer.Serialize(convergente));
        Application.DoEvents();
        var cambios = Control<DataGridView>(dialogo, "cronograma_ia_cambios");
        var cierre = cambios.Rows.Cast<DataGridViewRow>().Single(r => Equals(r.Tag, plan.Tareas[0].Id));
        string justificaciones = Convert.ToString(cierre.Cells["MOTIVO"].Value);
        var aplicado = dialogo.PrepararAplicacion(proyecto, plan);
        exige(cambios.Rows.Count == 4 && dialogo.PuedeAplicar && Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled &&
            motivos.All(m => justificaciones.Contains(m, StringComparison.Ordinal)) &&
            cierre.Cells["DESPUES"].ToolTipText.Contains("Revisar 3 predecesoras justificadas", StringComparison.Ordinal) &&
            Control<TextBox>(dialogo, "cronograma_ia_avisos").Text.Contains("[CONVERGENCIA]", StringComparison.Ordinal) &&
            aplicado.Tareas[0].Predecesoras.Count == 3 &&
            aplicado.Tareas[0].Predecesoras.Select(d => d.PredecesoraId).SequenceEqual(plan.Tareas.Skip(1).Select(t => t.Id)) &&
            MYGMotorCronograma.Calcular(aplicado).Fin == proyecto.Datos.FechaFin && JsonSerializer.Serialize(proyecto) == original,
            "Una respuesta completa con tres predecesoras justificadas por vínculo debe conservarlas todas, mostrar sus tres motivos y el aviso de revisión y permitir Aplicar cuando cumple las fechas, sin aprobaciones adicionales ni cambios en el origen.");

        convergente.Tareas[0].Predecesoras[1].Justificacion = null;
        bool rechazada = false;
        try { dialogo.CargarPropuesta(JsonSerializer.Serialize(convergente)); }
        catch (InvalidDataException ex)
        {
            rechazada = ex.Message.Contains("justific", StringComparison.OrdinalIgnoreCase);
        }
        Application.DoEvents();
        exige(rechazada && !dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled &&
            cambios.Rows.Count == 0 && dialogo.Valor == null &&
            Control<Label>(dialogo, "cronograma_ia_estado").Text.Contains("Aplicar bloqueado", StringComparison.Ordinal) &&
            JsonSerializer.Serialize(proyecto) == original,
            "Una convergencia de tres predecesoras sin la justificación de uno de sus vínculos debe retirar la propuesta anterior y bloquear Aplicar sin recortar vínculos ni modificar el origen.");
        dialogo.Close();
    }

    private static void VerificarPlazoObligatorio(Action<bool, string> exige)
    {
        foreach (int desfase in new[] { -1, 1 })
        {
            var (proyecto, plan) = CrearProyecto();
            string original = JsonSerializer.Serialize(proyecto);
            using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true);
            dialogo.Show();
            dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan, desfase: desfase));
            Application.DoEvents();
            exige(!dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled &&
                Control<DataGridView>(dialogo, "cronograma_ia_cambios").Rows.Count == 2 &&
                Control<Label>(dialogo, "cronograma_ia_estado").Text.Contains("Aplicar bloqueado", StringComparison.Ordinal),
                "Un fin anterior o posterior al proyecto debe poder revisarse, pero nunca habilitar Aplicar.");
            bool directaRechazada = false, accionRechazada = false;
            try { dialogo.PrepararAplicacion(proyecto, plan); }
            catch (InvalidDataException) { directaRechazada = true; }
            try { dialogo.AplicarSeleccion(); }
            catch (InvalidOperationException) { accionRechazada = true; }
            exige(directaRechazada && accionRechazada && dialogo.Valor == null &&
                dialogo.DialogResult != DialogResult.OK && JsonSerializer.Serialize(proyecto) == original,
                "La aplicación directa y la acción del botón deben rechazar un fin incorrecto sin confirmación alternativa ni cambios en el documento.");
            dialogo.Close();
        }
    }

    private static void VerificarFechasSinRegistrar(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        proyecto.Datos.FechaInicio = null;
        proyecto.Datos.FechaFin = null;
        string original = JsonSerializer.Serialize(proyecto);
        using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true);
        dialogo.Show();
        Control<NumericUpDown>(dialogo, "cronograma_ia_plazo").Value = 12;
        dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan));
        Application.DoEvents();
        bool directaRechazada = false;
        try { dialogo.PrepararAplicacion(proyecto, plan); }
        catch (InvalidDataException) { directaRechazada = true; }
        exige(Control<DateTimePicker>(dialogo, "cronograma_ia_inicio").Enabled &&
            Control<NumericUpDown>(dialogo, "cronograma_ia_plazo").Enabled &&
            !dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled && directaRechazada &&
            Control<Label>(dialogo, "cronograma_ia_estado").Text.Contains("registre inicio y fin en Datos del proyecto", StringComparison.Ordinal) &&
            JsonSerializer.Serialize(proyecto) == original,
            "Sin fechas registradas, las opciones sólo deben permitir simular y revisar; incluso una simulación exacta requiere completar Datos del proyecto antes de aplicar.");
        dialogo.Close();
    }

    private static void VerificarCuadrillasPropuestas(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        var presupuesto = proyecto.Presupuestos.Single();
        presupuesto.Costos.Insumos.Add(new MYGInsumo
        {
            Id = "INS-CUADRILLA-UI", Codigo = "MO-UI", Descripcion = "Operario de cuadrilla de prueba",
            Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 20m
        });
        var costos = presupuesto.Items[0].Costos;
        costos.Cantidad = 100m;
        costos.RendimientoDiario = 10m;
        costos.JornadaHoras = 8m;
        costos.Analisis = new List<MYGRecursoACU>
        {
            new() { Id = "ACU-CUADRILLA-UI", Grupo = MYGGrupoRecurso.ManoObra, InsumoId = "INS-CUADRILLA-UI",
                Modo = MYGModoCantidad.Rendimiento, NumeroRecursos = 1m }
        };
        string original = JsonSerializer.Serialize(proyecto);
        using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => true);
        dialogo.Show();
        UsarModoParcial(dialogo);
        dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan, cuadrillas: 2m));
        Application.DoEvents();
        var tabla = Control<DataGridView>(dialogo, "cronograma_ia_cambios");
        var fila = tabla.Rows.Cast<DataGridViewRow>().Single(r => Equals(r.Tag, plan.Tareas[0].Id));
        var aplicado = dialogo.PrepararAplicacion(proyecto, plan);
        exige(tabla.Columns.Contains("CUADRILLAS") && Convert.ToString(fila.Cells["CUADRILLAS"].Value) == "1 → 2" &&
            aplicado.Tareas[0].NumeroCuadrillas == 2m && aplicado.Tareas[0].DuracionDias == 5 &&
            MYGMotorCronograma.Calcular(aplicado).Fin == proyecto.Datos.FechaFin && dialogo.PuedeAplicar,
            "La revisión debe mostrar cuadrillas anteriores y propuestas y aplicar su duración productiva cumpliendo exactamente la fecha final.");
        dialogo.SeleccionarTareas(new[] { plan.Tareas[1].Id });
        exige(Convert.ToString(fila.Cells["CUADRILLAS"].Value) == "1 → 1" && !dialogo.PuedeAplicar &&
            JsonSerializer.Serialize(proyecto) == original,
            "Desmarcar una cuadrilla propuesta debe mostrar nuevamente la original y bloquear la selección parcial si deja de cumplir el plazo, sin mutar el origen.");
        dialogo.Close();
    }

    private static void VerificarSoloLectura(Action<bool, string> exige)
    {
        var (proyecto, plan) = CrearProyecto();
        string original = JsonSerializer.Serialize(proyecto);
        using var dialogo = new MYGAsistenteCronogramaIAForm(() => proyecto, () => plan, () => false);
        dialogo.Show();
        UsarModoParcial(dialogo);
        dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan));
        dialogo.SeleccionarTareas(new[] { plan.Tareas[0].Id });
        Application.DoEvents();
        exige(!dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled,
            "Consultar una propuesta en solo lectura debe mantener Aplicar deshabilitado aunque se seleccionen tareas válidas.");
        exige(!string.IsNullOrWhiteSpace(dialogo.CrearDatosParaIA()) &&
            Control<DataGridView>(dialogo, "cronograma_ia_cambios").Rows.Count >= 2,
            "El usuario de solo lectura debe poder exportar datos y consultar la previsualización.");
        bool rechazado = false;
        try { dialogo.PrepararAplicacion(proyecto, plan); }
        catch (InvalidOperationException) { rechazado = true; }
        exige(rechazado && JsonSerializer.Serialize(proyecto) == original,
            "La validación directa de Aplicar también debe exigir permiso de edición y conservar el origen.");
        dialogo.Close();
    }

    private static void VerificarCintaAplicacionEHistorial(Action<bool, string> exige)
    {
        var (proyecto, inicial) = CrearProyecto();
        var plan = inicial;
        string original = JsonSerializer.Serialize(proyecto);
        var historial = new Stack<MYGCronograma>();
        int aplicaciones = 0, deshechos = 0;
        bool autorizado = true;
        using var panel = new MYGPanelCronograma(() => plan, nuevo =>
        {
            historial.Push(MYGProyectoStorage.Copia(plan));
            plan = nuevo;
            proyecto.Cronograma = nuevo;
            aplicaciones++;
        }, () => autorizado, () => { }, () =>
        {
            plan = historial.Pop();
            proyecto.Cronograma = plan;
            deshechos++;
        }, () => { }, () => proyecto);
        using var ventana = new Form { ClientSize = new Size(1450, 720) };
        var cinta = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 98, WrapContents = false, AutoScroll = true };
        cinta.Controls.AddRange(panel.BotonesCinta.Cast<Control>().ToArray());
        ventana.Controls.Add(panel);
        ventana.Controls.Add(cinta);
        ventana.Show();
        panel.Refrescar();
        Application.DoEvents();
        var botones = panel.BotonesCinta.ToArray();
        int red = Array.FindIndex(botones, b => b.Name == "cronograma_diagrama_red");
        var asistente = botones.Single(b => b.Name == "cronograma_asistente_ia");
        exige(red >= 0 && red + 1 < botones.Length && ReferenceEquals(botones[red + 1], asistente) &&
            asistente.Image != null && asistente.TextImageRelation == TextImageRelation.ImageAboveText,
            "Asistente IA debe aparecer inmediatamente después de Diagrama de red y conservar el estilo de la cinta CPM.");

        autorizado = false;
        panel.Refrescar();
        Application.DoEvents();
        exige(asistente.Enabled, "La cinta debe permitir abrir el asistente en modo de consulta.");
        EjecutarDialogo(asistente, dialogo =>
        {
            exige(!Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled,
                "Abrir el asistente desde la cinta sin permiso debe mostrar Aplicar deshabilitado.");
            Control<Button>(dialogo, "cronograma_ia_cerrar").PerformClick();
        });
        exige(aplicaciones == 0 && historial.Count == 0 && JsonSerializer.Serialize(proyecto) == original,
            "Consultar y cerrar el asistente desde la cinta no debe generar historial.");

        autorizado = true;
        panel.Refrescar();
        EjecutarDialogo(asistente, dialogo =>
        {
            UsarModoParcial(dialogo);
            dialogo.CargarPropuesta(CrearPropuesta(dialogo, plan));
            dialogo.SeleccionarTareas(Array.Empty<string>());
            exige(!dialogo.PuedeAplicar && !Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled,
                "Una propuesta sin tareas seleccionadas no debe poder aplicarse.");
            dialogo.SeleccionarTareas(new[] { plan.Tareas[0].Id });
            Application.DoEvents();
            exige(dialogo.PuedeAplicar && Control<Button>(dialogo, "cronograma_ia_aplicar").Enabled,
                "Seleccionar una tarea válida debe habilitar Aplicar después de la previsualización.");
            exige(aplicaciones == 0 && historial.Count == 0 && JsonSerializer.Serialize(proyecto) == original,
                "Seleccionar cambios debe permanecer como previsualización hasta pulsar Aplicar.");
            Control<Button>(dialogo, "cronograma_ia_aplicar").PerformClick();
        });
        exige(aplicaciones == 1 && historial.Count == 1 &&
            plan.Tareas[0].Predecesoras.Single().PredecesoraId == plan.Tareas[1].Id &&
            plan.Tareas[0].Predecesoras.Single().Tipo == MYGTipoVinculo.FC &&
            plan.Tareas[1].Predecesoras.Count == 0 && plan.Tareas.All(t => t.DuracionDias == 5) &&
            !ReferenceEquals(plan, inicial) &&
            !ReferenceEquals(plan.Tareas[0], inicial.Tareas[0]),
            "Aplicar desde el asistente debe registrar una sola copia y modificar únicamente la tarea seleccionada.");
        var otros = botones.Single(b => b.Name == "cronograma_otros");
        otros.PerformClick();
        Application.DoEvents();
        otros.ContextMenuStrip.Items.OfType<ToolStripMenuItem>()
            .Single(i => i.Name == "cronograma_deshacer").PerformClick();
        otros.ContextMenuStrip.Close();
        Application.DoEvents();
        exige(deshechos == 1 && historial.Count == 0 && JsonSerializer.Serialize(proyecto) == original,
            "Una sola operación Deshacer debe restaurar íntegramente el proyecto anterior a la propuesta IA.");
        ventana.Close();
    }

    private static void UsarModoParcial(MYGAsistenteCronogramaIAForm dialogo)
    {
        Control<CheckBox>(dialogo, "cronograma_ia_replantear_todas").Checked = false;
        Control<Button>(dialogo, "cronograma_ia_revisar").PerformClick();
        Application.DoEvents();
    }

    private static void EjecutarDialogo(Button boton, Action<MYGAsistenteCronogramaIAForm> comprobar)
    {
        Exception fallo = null;
        bool ejecutado = false;
        using var temporizador = new System.Windows.Forms.Timer { Interval = 20 };
        temporizador.Tick += (_, _) =>
        {
            var dialogo = Application.OpenForms.OfType<MYGAsistenteCronogramaIAForm>().SingleOrDefault();
            if (dialogo == null) return;
            temporizador.Stop();
            ejecutado = true;
            try { comprobar(dialogo); }
            catch (Exception ex) { fallo = ex; }
            finally { if (dialogo.Visible && dialogo.DialogResult != DialogResult.OK) dialogo.Close(); }
        };
        temporizador.Start();
        boton.PerformClick();
        temporizador.Stop();
        if (fallo != null) throw new InvalidOperationException("Falló la comprobación del diálogo del asistente IA.", fallo);
        if (!ejecutado) throw new InvalidOperationException("El botón de la cinta no abrió el diálogo del asistente IA.");
    }

    private static (MYGProyectoDocumento Proyecto, MYGCronograma Plan) CrearProyecto()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Asistente IA: proyecto de prueba", "Presupuesto IA");
        proyecto.Datos.FechaInicio = new DateTime(2026, 11, 2);
        proyecto.Datos.FechaFin = new DateTime(2026, 11, 13);
        var presupuesto = proyecto.Presupuestos.Single();
        var plan = new MYGCronograma { FechaInicio = proyecto.Datos.FechaInicio.Value, FechaEstado = proyecto.Datos.FechaInicio.Value };
        for (int i = 1; i <= 2; i++)
        {
            var partida = new ItemPresupuestoDelphin
            {
                Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = "Trabajo IA " + i,
                Unidad = "m3", Item = "01.0" + i, Posicion = i,
                Costos = new MYGDatosPartida { Cantidad = 10m, FuenteMetrado = MYGFuenteMetrado.Cantidad, PrecioDirecto = 125m }
            };
            partida.IdLocalMYG = partida.IdPropuesta = partida.Id;
            presupuesto.Items.Add(partida);
            plan.Tareas.Add(new MYGTareaCronograma
            {
                PresupuestoId = presupuesto.Id, PartidaId = partida.Id, Codigo = partida.Item,
                Nombre = partida.Descripcion, DuracionDias = 5
            });
        }
        proyecto.Cronograma = plan;
        MYGProyectoStorage.Validar(proyecto);
        MYGMotorCronograma.Validar(plan);
        return (proyecto, plan);
    }

    private static string CrearPropuesta(MYGAsistenteCronogramaIAForm dialogo, MYGCronograma plan,
        int desfase = 0, decimal? cuadrillas = null)
    {
        return JsonSerializer.Serialize(new MYGPropuestaCronogramaIA
        {
            Firma = dialogo.Paquete.Firma,
            Tareas = new List<MYGTareaPropuestaCronogramaIA>
            {
                new()
                {
                    TareaId = plan.Tareas[0].Id,
                    NumeroCuadrillas = cuadrillas,
                    Predecesoras = new List<MYGPredecesoraPropuestaCronogramaIA>
                    {
                        new() { PredecesoraId = plan.Tareas[1].Id, Tipo = "FC", DesfaseDias = desfase, Unidad = "laborables" }
                    },
                    Justificacion = cuadrillas.HasValue
                        ? "Dos cuadrillas independientes ejecutan 100 m3 a 10 m3 por cuadrilla y jornada durante cinco jornadas de ocho horas; confirmar disponibilidad antes de aplicar."
                        : "Concluir el segundo frente antes de iniciar el primero."
                },
                new() { TareaId = plan.Tareas[1].Id, Justificacion = "Este frente puede comenzar sin predecesoras." }
            }
        });
    }

    private static T Control<T>(Control padre, string nombre) where T : Control =>
        Descendientes(padre).OfType<T>().Single(c => c.Name == nombre);

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
