using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class ModeladoresBimUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial))!.SetValue(sesion,
            new CredencialMYG { Usuario = "Modelador sintético" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado))!.SetValue(sesion, true);
        var documento = MYGProyectoStorage.Nuevo("Interfaz modeladores BIM");
        var partida = MYGPartidasBim.CrearTexto(documento, documento.PresupuestoActivoId, "Nueva partida", "m2", null, null, "propietario");
        using var editor = new EditorForm(documento, null, sesion);
        var grid = Campo<DataGridView>(editor, "grid");
        string[] internas = { "CODIGO", "CODIGO_DELPHIN", "ID_PROPUESTA", "ORIGEN", "ESTADO" };
        exige(internas.All(c => !grid.Columns[c].Visible) && grid.Columns["ITEM"].Visible
            && grid.Columns["PARTIDA"].Visible && grid.MultiSelect,
            "La vista BIM retira las cinco columnas internas y mantiene selección múltiple.");
        Llamar(editor, "Refrescar");
        exige(internas.All(c => !grid.Columns[c].Visible) && partida.IdPropuesta != null,
            "Refrescar no recupera las columnas ocultas ni elimina la identidad de las partidas.");
        var acciones = Campo<FlowLayoutPanel>(editor, "acciones");
        string[] textos = Controles(acciones).OfType<Button>().Select(b => b.Text).ToArray();
        exige(textos.Contains("+ Partida de texto") && textos.Contains("+ Desde catálogo") && textos.Contains("Editar filtros en lote")
            && !textos.Contains("+ Título") && !textos.Contains("Reconciliar Delphin") && !textos.Contains("− Quitar propuesta"),
            "La ventana ofrece altas y filtros BIM sin comandos que alteren otros módulos o eliminen estructura.");

        using var cliente = new ClienteSupabase("https://bim-ui.supabase.co", "sb_publishable_bim_sintetica", new Acceso());
        cliente.IniciarSesionAsync("bim@myg.example", "clave_sintetica").GetAwaiter().GetResult();
        var permisos = new MYGPermisosModulos { Acu = false, Especificaciones = false, MetradosExcel = false, MetradosRevit = true };
        var vinculo = new MYGVinculoNube { Servidor = cliente.UrlServidor, UsuarioId = cliente.UsuarioId,
            ProyectoId = Guid.NewGuid(), Rol = "editor", PermisosModulos = permisos };
        typeof(EditorForm).GetField("vinculoNube", Privados)!.SetValue(editor, vinculo);
        typeof(EditorForm).GetField("obtenerClienteNube", Privados)!.SetValue(editor, new Func<ClienteSupabase>(() => cliente));
        Llamar(editor, "AplicarPermisosModeladoresBim");
        exige(!grid.ReadOnly && Controles(acciones).OfType<Button>().Single(b => b.Text == "Editar filtros en lote").Enabled,
            "Metrados Revit habilita la edición BIM aunque ACU, especificaciones y Excel estén bloqueados.");
        permisos.MetradosRevit = false;
        Llamar(editor, "AplicarPermisosModeladoresBim");
        exige(grid.ReadOnly && !Controles(acciones).OfType<Button>().Single(b => b.Text == "+ Desde catálogo").Enabled,
            "Retirar sólo Metrados Revit bloquea la tabla y las altas de catálogo.");
        string firma = MYGProyectoStorage.Firma(documento);
        foreach (string metodo in new[] { "NuevaPartidaBimTexto", "NuevaPartidaBimCatalogo", "EditarFiltrosMasivosBim" })
            Rechaza(() => Llamar(editor, metodo), exige);
        Rechaza(() => Llamar(editor, "CambiarFiltros", 1), exige);
        exige(MYGProyectoStorage.Firma(documento) == firma,
            "Las invocaciones directas sin permiso no modifican la obra ni abren diálogos.");

        using var configuracion = new PermisosModulosNubeForm("modelador", permisos, true, "editor");
        var check = Controles(configuracion).OfType<CheckBox>().Single(c => c.Name == "permisoEditarMetradosRevit");
        check.Checked = true;
        exige(configuracion.Permisos.MetradosRevit && !configuracion.Permisos.Acu && !configuracion.Permisos.Especificaciones
            && !configuracion.Permisos.MetradosExcel,
            "El administrador puede asignar únicamente el permiso Metrados Revit.");
        using var lote = new BimFiltrosMasivosForm(2000, partida, null);
        exige(Controles(lote).OfType<Label>().Any(l => l.Text == "2000 partida(s) seleccionada(s)")
            && Controles(lote).OfType<DataGridView>().Single().Rows.Count == 8,
            "El diálogo acepta dos mil partidas y limita sólo los filtros de cada tabla.");
        exige(MYGProyectoStorage.Firma(documento) == firma,
            "Consultar y cancelar el diálogo masivo no altera las partidas.");
    }

    private static T Campo<T>(object instancia, string nombre) => (T)instancia.GetType().GetField(nombre, Privados)!.GetValue(instancia)!;
    private static void Llamar(object instancia, string nombre, params object[] argumentos)
    {
        try { instancia.GetType().GetMethod(nombre, Privados)!.Invoke(instancia, argumentos); }
        catch (TargetInvocationException error) when (error.InnerException != null)
        { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error.InnerException).Throw(); }
    }
    private static void Rechaza(Action accion, Action<bool, string> exige)
    {
        bool rechazo = false;
        try { accion(); } catch (InvalidOperationException) { rechazo = true; }
        exige(rechazo, "La operación BIM exige autorización también al invocarla directamente.");
    }
    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (var control in Controles(hijo)) yield return control;
    }
    private sealed class Acceso : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken token)
        {
            if (solicitud.RequestUri!.AbsolutePath != "/auth/v1/token") throw new InvalidOperationException("Sólo autenticación HTTP simulada.");
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            { Content = new StringContent(JsonSerializer.Serialize(new { access_token = "bim_sintetico", refresh_token = "refresco_sintetico",
                expires_in = 3600, user = new { id = "11111111-1111-4111-8111-111111111111" } }), Encoding.UTF8, "application/json") });
        }
    }
}
