#nullable enable
using System.Collections.Concurrent;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>Colaboración de archivos SQLite; la cola está en un sidecar relacional y nunca dentro de la obra.</summary>
public static partial class CopiaSqliteNube
{
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> Exclusiones = new(StringComparer.OrdinalIgnoreCase);
    private static readonly object EsquemaEstado = new();
    private sealed record Pendiente(Guid Id, long Revision, string Ruta, string Hash, long Bytes, bool Enviada);
    private sealed record Estado(string Documento, Guid Proyecto, string Servidor, string Usuario, string Rol,
        long Revision, string Hash, bool Sucio, long Conflicto, string? Conexion, MYGPermisosModulos? Permisos, string Alcance);

    public static string RutaEstado(string ruta) => Path.GetFullPath(ruta) + ".nube.sqlite";
    private static string Carpeta(string ruta) => Path.GetFullPath(ruta) + ".nube";
    private static SemaphoreSlim Exclusion(string ruta) => Exclusiones.GetOrAdd(Path.GetFullPath(ruta), _ => new(1, 1));

    public static MYGVinculoNube? LeerVinculo(string ruta, string documentoId)
    {
        if (!File.Exists(RutaEstado(ruta))) return null;
        using var c = AbrirEstado(ruta);
        var estado = LeerEstado(c, documentoId);
        if (estado is null || (estado.Alcance == "base" && !ContieneDocumento(ruta, documentoId))) return null;
        if (estado.Permisos?.MetradosRevitDisponible == true && (!estado.Sucio || PuedeEnviar(estado))) AsegurarBaseBim(c, ruta, documentoId, estado.Revision);
        return Adaptar(estado, LeerPendiente(c, estado.Documento));
    }

    /// <summary>La revisión y la operación pendiente pertenecen al archivo completo, no a una obra.</summary>
    public static bool EsBase(string ruta)
    {
        if (!File.Exists(RutaEstado(ruta))) return false;
        using var c = AbrirEstado(ruta);
        using var q = c.CreateCommand(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM vinculo WHERE alcance='base')";
        return (long)q.ExecuteScalar()! != 0;
    }

    public static bool TieneConflicto(string ruta)
    {
        if (!File.Exists(RutaEstado(ruta))) return false;
        using var c = AbrirEstado(ruta);
        using var q = c.CreateCommand(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM vinculo WHERE conflicto_revision>0)";
        return (long)q.ExecuteScalar()! != 0;
    }

    /// <summary>Un indicador barato para la barra UI. Sincronizar verifica además cambios externos y WAL.</summary>
    public static void MarcarCambio(string ruta, string documentoId)
    {
        if (!File.Exists(RutaEstado(ruta))) return;
        using var c = AbrirEstado(ruta);
        var estado = LeerEstado(c, documentoId);
        if (estado is not null && (estado.Alcance != "base" || ContieneDocumento(ruta, documentoId)))
            Ejecutar(c, "UPDATE vinculo SET sucio=1 WHERE documento=$p0", estado.Documento);
    }

    public static void Vincular(string ruta, ProyectoSqliteNube remoto, ClienteSupabase cliente, string? documentoId = null)
    {
        ArgumentNullException.ThrowIfNull(remoto);
        string id = documentoId ?? remoto.DocumentoId;
        bool baseCompleta = remoto.Proyecto.Alcance == "base";
        if (id != remoto.DocumentoId && !baseCompleta)
            throw new InvalidDataException("El archivo remoto pertenece a otro documento.");
        if (!cliente.SesionIniciada || string.IsNullOrWhiteSpace(cliente.UsuarioId))
            throw new NubeException("Inicie sesión antes de vincular el archivo SQLite.", necesitaIniciarSesion: true);
        var cerrojo = Exclusion(ruta); cerrojo.Wait();
        try
        {
            ValidarDocumento(ruta, id);
            if (baseCompleta) ValidarDocumento(ruta, remoto.DocumentoId);
            using var c = AbrirEstado(ruta);
            // Una ruta física no puede tener revisiones o colas independientes:
            // cualquier edición de cualquiera de sus obras se envía en el mismo SQLite.
            using (var consulta = c.CreateCommand())
            {
                consulta.CommandText = "SELECT documento FROM vinculo";
                using var filas = consulta.ExecuteReader();
                while (filas.Read())
                    if (filas.GetString(0) != remoto.DocumentoId)
                        throw new InvalidOperationException("La copia ya está vinculada a otro documento. Use otro archivo local.");
            }
            var previo = LeerEstado(c, remoto.DocumentoId);
            if (previo != null && (previo.Proyecto != remoto.Proyecto.Id || previo.Usuario != cliente.UsuarioId ||
                !string.Equals(previo.Servidor.TrimEnd('/'), cliente.UrlServidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException("La copia ya está vinculada a otra identidad. Use otro archivo local.");
            if (previo?.Alcance == "base" && !baseCompleta)
                throw new InvalidOperationException("La copia está vinculada a una base completa. Su alcance no puede cambiar al abrir otra obra.");
            if (previo != null && baseCompleta)
            {
                // Reabrir una base nunca vuelve a marcar como confirmados cambios
                // locales ni reinicia una operación cuyo ACK todavía puede perderse.
                if (previo.Alcance != "base") EscribirEstado(c, previo with { Alcance = "base" });
                return;
            }
            if (LeerPendiente(c, remoto.DocumentoId) != null)
                throw new InvalidOperationException("La copia conserva una operación pendiente. Sincronícela antes de volver a vincular.");
            Directory.CreateDirectory(Carpeta(ruta));
            string copia = Temporal(ruta);
            try
            {
                CrearSnapshot(ruta, copia);
                var estado = new Estado(remoto.DocumentoId, remoto.Proyecto.Id, cliente.UrlServidor, cliente.UsuarioId!, remoto.Proyecto.Rol,
                    remoto.Proyecto.Revision, Hash(copia), false, 0, null, remoto.Proyecto.PermisosModulos?.Copiar(),
                    baseCompleta ? "base" : "obra");
                EscribirEstado(c, estado);
            }
            finally { Borrar(copia); }
        }
        finally { cerrojo.Release(); }
    }

    /// <summary>Copia consistente con WAL incluido. No cambia la base original ni convierte tablas en JSON.</summary>
    public static void CrearSnapshot(string origen, string destino, CancellationToken ct = default)
    {
        origen = Path.GetFullPath(origen); destino = Path.GetFullPath(destino);
        if (string.Equals(origen, destino, StringComparison.OrdinalIgnoreCase) || File.Exists(destino))
            throw new IOException("La instantánea necesita un archivo de destino nuevo.");
        Directory.CreateDirectory(Path.GetDirectoryName(destino)!);
        ct.ThrowIfCancellationRequested();
        try
        {
            using (var fuente = AbrirArchivo(origen, escritura: false))
            using (var copia = AbrirArchivo(destino, escritura: true))
            {
                fuente.BackupDatabase(copia);
                ct.ThrowIfCancellationRequested();
                // La cola JSON del protocolo anterior nunca se sube en el archivo nuevo.
                using var q = copia.CreateCommand();
                q.CommandText = "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name='myg_colaboracion_local')";
                if ((long)q.ExecuteScalar()! != 0)
                {
                    q.CommandText = "DROP TABLE myg_colaboracion_local"; q.ExecuteNonQuery();
                    q.CommandText = "VACUUM"; q.ExecuteNonQuery();
                }
                q.CommandText = "PRAGMA journal_mode=DELETE"; q.ExecuteScalar();
                q.CommandText = "PRAGMA quick_check";
                if (!string.Equals(q.ExecuteScalar() as string, "ok", StringComparison.Ordinal))
                    throw new InvalidDataException("La instantánea SQLite no pasó la verificación de integridad.");
            }
            ArchivoPublicacionSqlitePendiente.NormalizarCopiaPortable(destino, origen, ct);
            using var archivo = new FileStream(destino, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
            archivo.Flush(flushToDisk: true);
            ct.ThrowIfCancellationRequested();
        }
        catch { Borrar(destino); throw; }
    }

    private static async Task<ResultadoSincronizacion> EjecutarArchivoAsync(ClienteSupabase cliente, string ruta,
        MYGProyectoDocumento documento, bool soloLeer = false, CancellationToken ct = default,
        IProgress<string>? progreso = null)
    {
        var cerrojo = Exclusion(ruta); await cerrojo.WaitAsync(ct);
        string? candidato = null;
        try
        {
            using var c = AbrirEstado(ruta);
            var estado = LeerEstadoDocumento(c, ruta, documento.Id);
            ValidarIdentidad(cliente, estado);
            progreso?.Report("Preparando una instantánea SQLite consistente, incluidos los cambios WAL…");
            candidato = Temporal(ruta);
            CrearSnapshot(ruta, candidato, ct);
            string huella = Hash(candidato);
            var pendiente = LeerPendiente(c, estado.Documento);
            if (pendiente is null && huella != estado.Hash)
            {
                pendiente = Congelar(ruta, candidato, huella, estado.Revision); candidato = null;
                EscribirPendiente(c, estado.Documento, pendiente);
            }
            estado = estado with { Sucio = pendiente != null || huella != estado.Hash };
            EscribirEstado(c, estado);
            progreso?.Report("Consultando la revisión y los permisos del archivo SQLite…");
            ProyectoSqliteNube remoto;
            try { remoto = await cliente.AbrirSqliteAsync(estado.Proyecto, ct: ct); }
            catch (NubeException ex)
            {
                EscribirEstado(c, estado with { Conexion = ex.AccesoDenegado ? "acceso retirado" : ex.EsErrorDeConexion ? "sin conexión" : null });
                throw;
            }
            ValidarRemoto(estado, remoto);
            estado = estado with { Rol = remoto.Proyecto.Rol, Permisos = remoto.Proyecto.PermisosModulos?.Copiar(), Conexion = null };
            EscribirEstado(c, estado);
            if (remoto.Proyecto.Revision < estado.Revision)
                throw new NubeException("La nube devolvió una revisión anterior. Se conservan la copia y sus pendientes.");
            if (estado.Conflicto > 0) return new(documento, Adaptar(estado, pendiente));
            if (pendiente != null && !soloLeer && !PuedeEnviar(estado))
                throw new NubeException("Sincronizar un archivo SQLite completo requiere permiso de edición de todos los módulos. Se conservan la copia local y la operación pendiente; puede Recargar para consultar la nube.");
            if (pendiente != null && !soloLeer && PuedeEnviar(estado))
            {
                VerificarPendiente(pendiente);
                // Persistir ANTES del HTTP. Un ACK perdido conserva UUID, base y archivo idénticos.
                pendiente = pendiente with { Enviada = true };
                EscribirPendiente(c, estado.Documento, pendiente);
                RespuestaSqliteNube respuesta;
                try { respuesta = await cliente.GuardarSqliteAsync(estado.Proyecto, pendiente.Id, pendiente.Revision, pendiente.Ruta, ct, progreso); }
                catch (NubeException ex)
                {
                    EscribirEstado(c, estado with { Conexion = ex.AccesoDenegado ? "acceso retirado" : ex.EsErrorDeConexion ? "sin conexión" : null });
                    throw;
                }
                if (respuesta.Estado == "conflicto")
                {
                    estado = estado with { Conflicto = respuesta.Revision };
                    EscribirEstado(c, estado);
                    progreso?.Report("Conflicto: se conservan el archivo local y la instantánea pendiente…");
                    return new(documento, Adaptar(estado, pendiente));
                }
                if (respuesta.OperacionId != pendiente.Id || respuesta.Revision != pendiente.Revision + 1 ||
                    !string.Equals(respuesta.Archivo.Sha256, pendiente.Hash, StringComparison.OrdinalIgnoreCase))
                    throw new NubeException("La confirmación SQLite no corresponde a la operación pendiente.");
                estado = estado with { Revision = respuesta.Revision, Hash = pendiente.Hash, Sucio = false };
                using (var t = c.BeginTransaction())
                {
                    EscribirEstado(c, estado, t);
                    Ejecutar(c, "DELETE FROM pendiente WHERE documento=$p0", t, estado.Documento);
                    t.Commit();
                }
                Borrar(pendiente.Ruta); pendiente = null;
                remoto = await cliente.AbrirSqliteAsync(estado.Proyecto, ct: ct);
                ValidarRemoto(estado, remoto);
            }
            if (remoto.Proyecto.Revision > estado.Revision)
            {
                if (pendiente != null)
                {
                    // Un envío sin ACK puede ser exactamente esta revisión; reintentar el UUID lo decide.
                    if (!pendiente.Enviada) estado = estado with { Conflicto = remoto.Proyecto.Revision };
                    EscribirEstado(c, estado);
                    return new(documento, Adaptar(estado, pendiente));
                }
                progreso?.Report("Descargando la nueva revisión como archivo SQLite sin comprimir…");
                string descarga = Temporal(ruta);
                try
                {
                    await cliente.DescargarSqliteAsync(remoto, descarga, ct, progreso);
                    ValidarDocumento(descarga, documento.Id);
                    var incorporado = AplicarRemoto(ruta, descarga, estado.Hash, ct, progreso);
                    if (!incorporado)
                    {
                        estado = estado with { Conflicto = remoto.Proyecto.Revision, Sucio = true };
                        EscribirEstado(c, estado);
                        return new(documento, Adaptar(estado, null));
                    }
                    string confirmada = Temporal(ruta);
                    try { CrearSnapshot(ruta, confirmada, ct); estado = estado with { Hash = Hash(confirmada) }; }
                    finally { Borrar(confirmada); }
                    estado = estado with { Revision = remoto.Proyecto.Revision, Conflicto = 0, Sucio = false };
                    EscribirEstado(c, estado);
                    documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documento.Id);
                }
                finally { Borrar(descarga); }
            }
            // Una edición externa durante la transferencia queda marcada para el siguiente envío.
            string final = Temporal(ruta);
            try
            {
                CrearSnapshot(ruta, final, ct);
                estado = estado with { Sucio = LeerPendiente(c, estado.Documento) != null || Hash(final) != estado.Hash };
                EscribirEstado(c, estado);
            }
            finally { Borrar(final); }
            progreso?.Report(estado.Sucio ? "Archivo guardado; hay cambios locales pendientes…" : "Archivo SQLite sincronizado…");
            return new(documento, Adaptar(estado, LeerPendiente(c, estado.Documento)));
        }
        finally { if (candidato != null) Borrar(candidato); cerrojo.Release(); }
    }

    public static void ResolverMantenerLocal(string ruta, string documentoId)
    {
        var cerrojo = Exclusion(ruta); cerrojo.Wait();
        try
        {
            using var c = AbrirEstado(ruta);
            var estado = LeerEstadoDocumento(c, ruta, documentoId);
            if (estado.Conflicto <= 0) return;
            if (!PuedeEnviar(estado)) throw new InvalidOperationException("No dispone de permiso para mantener la revisión local.");
            var anterior = LeerPendiente(c, estado.Documento);
            using var t = c.BeginTransaction();
            EscribirEstado(c, estado with { Revision = estado.Conflicto, Conflicto = 0, Hash = "", Sucio = true }, t);
            Ejecutar(c, "DELETE FROM pendiente WHERE documento=$p0", t, estado.Documento);
            t.Commit();
            if (anterior != null) Borrar(anterior.Ruta);
        }
        finally { cerrojo.Release(); }
    }

    public static async Task<ResultadoSincronizacion> ResolverUsarRemotoAsync(ClienteSupabase cliente, string ruta,
        MYGProyectoDocumento documento, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        var cerrojo = Exclusion(ruta); await cerrojo.WaitAsync(ct);
        try
        {
            using var c = AbrirEstado(ruta);
            var estado = LeerEstadoDocumento(c, ruta, documento.Id);
            ValidarIdentidad(cliente, estado);
            if (estado.Conflicto <= 0) throw new InvalidOperationException("No existe un conflicto SQLite pendiente.");
            var remoto = await cliente.AbrirSqliteAsync(estado.Proyecto, ct: ct);
            ValidarRemoto(estado, remoto);
            string descarga = Temporal(ruta), actual = Temporal(ruta);
            try
            {
                CrearSnapshot(ruta, actual, ct);
                await cliente.DescargarSqliteAsync(remoto, descarga, ct, progreso);
                ValidarDocumento(descarga, documento.Id);
                if (!AplicarRemoto(ruta, descarga, Hash(actual), ct, progreso))
                    throw new IOException("El archivo local cambió durante la descarga. Se conserva y puede volver a resolver el conflicto.");
                Borrar(actual); CrearSnapshot(ruta, actual, ct);
                var pendiente = LeerPendiente(c, estado.Documento);
                estado = estado with { Revision = remoto.Proyecto.Revision, Hash = Hash(actual), Sucio = false,
                    Conflicto = 0, Conexion = null, Rol = remoto.Proyecto.Rol, Permisos = remoto.Proyecto.PermisosModulos?.Copiar() };
                using var t = c.BeginTransaction();
                EscribirEstado(c, estado, t); Ejecutar(c, "DELETE FROM pendiente WHERE documento=$p0", t, estado.Documento); t.Commit();
                if (pendiente != null) Borrar(pendiente.Ruta);
                EsquemaBim(c);
                Ejecutar(c, "DELETE FROM bim_local");
                return new(ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documento.Id), Adaptar(estado, null));
            }
            finally { Borrar(descarga); Borrar(actual); }
        }
        finally { cerrojo.Release(); }
    }

    private static bool AplicarRemoto(string ruta, string descarga, string esperada, CancellationToken ct, IProgress<string>? progreso)
    {
        string comprobar = Temporal(ruta);
        using var local = AbrirArchivo(ruta, escritura: true);
        // Retener el bloqueo exclusivo tras COMMIT impide una escritura externa
        // entre la comprobación de huella y la sustitución mediante SQLite Backup.
        using (var q = local.CreateCommand()) { q.CommandText = "PRAGMA locking_mode=EXCLUSIVE"; q.ExecuteScalar(); }
        using (var t = local.BeginTransaction())
        {
            using var q = local.CreateCommand(); q.Transaction = t;
            q.CommandText = "SELECT count(*) FROM sqlite_master"; q.ExecuteScalar(); t.Commit();
        }
        try
        {
            using (var copia = AbrirArchivo(comprobar, escritura: true)) local.BackupDatabase(copia);
            NormalizarSnapshot(comprobar, ruta, ct);
            if (Hash(comprobar) != esperada) return false;
            ct.ThrowIfCancellationRequested();
            string respaldo = Path.Combine(Carpeta(ruta), "respaldo-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.Move(comprobar, respaldo);
            progreso?.Report("Aplicando la revisión SQLite; la copia local anterior queda respaldada…");
            using var remoto = AbrirArchivo(descarga, escritura: false);
            remoto.BackupDatabase(local);
            return true;
        }
        finally { Borrar(comprobar); }
    }

    private static void NormalizarSnapshot(string ruta, string origen, CancellationToken ct)
    {
        using (var c = AbrirArchivo(ruta, escritura: true))
        {
            using var q = c.CreateCommand(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name='myg_colaboracion_local')";
            if ((long)q.ExecuteScalar()! != 0)
            { q.CommandText = "DROP TABLE myg_colaboracion_local"; q.ExecuteNonQuery(); q.CommandText = "VACUUM"; q.ExecuteNonQuery(); }
            q.CommandText = "PRAGMA journal_mode=DELETE"; q.ExecuteScalar();
        }
        ArchivoPublicacionSqlitePendiente.NormalizarCopiaPortable(ruta, origen, ct);
    }

    private static bool ContieneDocumento(string ruta, string documento)
    {
        if (string.IsNullOrWhiteSpace(documento) || !File.Exists(ruta)) return false;
        using var c = AbrirArchivo(ruta, escritura: false);
        foreach (var (tabla, columna) in new[] { ("myg_proyecto", "id"), ("proyecto", "id_proyecto") })
        {
            using var existe = c.CreateCommand();
            existe.CommandText = "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name=$p0)";
            existe.Parameters.AddWithValue("$p0", tabla);
            if ((long)existe.ExecuteScalar()! == 0) continue;
            using var q = c.CreateCommand();
            q.CommandText = "SELECT EXISTS(SELECT 1 FROM " + tabla + " WHERE " + columna + "=$p0)";
            q.Parameters.AddWithValue("$p0", documento);
            if ((long)q.ExecuteScalar()! != 0) return true;
        }
        return false;
    }

    private static void ValidarDocumento(string ruta, string documento)
    {
        if (!ContieneDocumento(ruta, documento))
            throw new InvalidDataException("El SQLite recibido no contiene el documento esperado.");
    }

    private static Estado LeerEstadoDocumento(SqliteConnection c, string ruta, string documento)
    {
        var estado = LeerEstado(c, documento) ?? throw new InvalidOperationException("La copia no está vinculada a un archivo SQLite de nube.");
        if (estado.Alcance == "base") ValidarDocumento(ruta, documento);
        return estado;
    }

    private static void ValidarRemoto(Estado estado, ProyectoSqliteNube remoto)
    {
        if (remoto.Proyecto.Id != estado.Proyecto || remoto.DocumentoId != estado.Documento
            || remoto.Proyecto.Alcance != estado.Alcance)
            throw new NubeException("El archivo remoto no corresponde a esta copia de trabajo.");
    }

    private static void ValidarIdentidad(ClienteSupabase cliente, Estado estado)
    {
        if (!cliente.SesionIniciada || cliente.UsuarioId != estado.Usuario ||
            !string.Equals(cliente.UrlServidor.TrimEnd('/'), estado.Servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            throw new NubeException("Inicie la misma sesión de nube que está vinculada a esta copia SQLite.", necesitaIniciarSesion: true);
    }

    private static bool PuedeEnviar(Estado estado) => SincronizadorProyectoNube.PuedeEditar(estado.Rol) &&
        estado.Conexion != "acceso retirado" && estado.Permisos is { Acu: true, Especificaciones: true, MetradosExcel: true }
        && (!estado.Permisos.MetradosRevitDisponible || estado.Permisos.MetradosRevit);

    private static MYGVinculoNube Adaptar(Estado e, Pendiente? p) => new()
    {
        ProyectoId = e.Proyecto, Servidor = e.Servidor, UsuarioId = e.Usuario, Rol = e.Rol,
        Revision = e.Revision, PermisosModulos = e.Permisos?.Copiar(), EstadoConexion = e.Conexion,
        Estado = e.Conflicto > 0 ? "conflicto" : p != null || e.Sucio ? "pendiente" : "sincronizado",
        JsonRemotoConflicto = e.Conflicto > 0 ? "sqlite" : null, RevisionRemotaConflicto = e.Conflicto,
        Pendiente = p != null ? new MYGOperacionNube { Id = p.Id, RevisionBase = p.Revision, Enviada = p.Enviada }
            : e.Sucio ? new MYGOperacionNube { RevisionBase = e.Revision } : null
    };

    private static Pendiente Congelar(string ruta, string candidato, string hash, long revision)
    {
        Guid id = Guid.NewGuid(); string destino = Path.Combine(Carpeta(ruta), "pendiente-" + id.ToString("N") + ".sqlite");
        File.Move(candidato, destino);
        return new(id, revision, destino, hash, new FileInfo(destino).Length, false);
    }

    private static void VerificarPendiente(Pendiente p)
    {
        if (!File.Exists(p.Ruta) || new FileInfo(p.Ruta).Length != p.Bytes || Hash(p.Ruta) != p.Hash)
            throw new IOException("La instantánea pendiente falta o cambió. No se enviará otro cuerpo con el mismo UUID.");
    }

    private static string Temporal(string ruta)
    { Directory.CreateDirectory(Carpeta(ruta)); return Path.Combine(Carpeta(ruta), "temporal-" + Guid.NewGuid().ToString("N") + ".sqlite"); }
    private static string Hash(string ruta)
    { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)).ToLowerInvariant(); }
    private static void Borrar(string ruta) { if (File.Exists(ruta)) File.Delete(ruta); }

    private static SqliteConnection AbrirArchivo(string ruta, bool escritura)
    {
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = Path.GetFullPath(ruta),
            Mode = escritura ? SqliteOpenMode.ReadWriteCreate : SqliteOpenMode.ReadOnly, Pooling = false,
            DefaultTimeout = 15 }.ToString());
        try { c.Open(); return c; } catch { c.Dispose(); throw; }
    }

    private static SqliteConnection AbrirEstado(string ruta)
    {
        var c = AbrirArchivo(RutaEstado(ruta), escritura: true);
        try
        {
            // LeerVinculo también puede llegar desde el temporizador de la UI.
            // Serializar la migración impide dos ALTER simultáneos del mismo sidecar.
            lock (EsquemaEstado)
            {
                Ejecutar(c, """
                    CREATE TABLE IF NOT EXISTS vinculo(documento TEXT PRIMARY KEY,proyecto TEXT NOT NULL,servidor TEXT NOT NULL,
                      usuario TEXT NOT NULL,rol TEXT NOT NULL,revision INTEGER NOT NULL,hash TEXT NOT NULL,sucio INTEGER NOT NULL,
                      conflicto_revision INTEGER NOT NULL,conexion TEXT,acu INTEGER,especificaciones INTEGER,metrados INTEGER,
                      alcance TEXT NOT NULL DEFAULT 'obra',metrados_revit INTEGER);
                    CREATE TABLE IF NOT EXISTS pendiente(documento TEXT PRIMARY KEY REFERENCES vinculo(documento),operacion TEXT NOT NULL,
                      revision INTEGER NOT NULL,ruta TEXT NOT NULL,hash TEXT NOT NULL,bytes INTEGER NOT NULL,enviada INTEGER NOT NULL);
                    """);
                using (var esquema = c.CreateCommand())
                {
                    esquema.CommandText = "SELECT EXISTS(SELECT 1 FROM pragma_table_info('vinculo') WHERE name='alcance')";
                    if ((long)esquema.ExecuteScalar()! == 0)
                        Ejecutar(c, "ALTER TABLE vinculo ADD COLUMN alcance TEXT NOT NULL DEFAULT 'obra'");
                }
                using (var esquema = c.CreateCommand())
                {
                    esquema.CommandText = "SELECT EXISTS(SELECT 1 FROM pragma_table_info('vinculo') WHERE name='metrados_revit')";
                    if ((long)esquema.ExecuteScalar()! == 0)
                        Ejecutar(c, "ALTER TABLE vinculo ADD COLUMN metrados_revit INTEGER");
                }
            }
            return c;
        }
        catch { c.Dispose(); throw; }
    }

    private static Estado? LeerEstado(SqliteConnection c, string id)
    {
        using var q = c.CreateCommand(); q.CommandText = "SELECT documento,proyecto,servidor,usuario,rol,revision,hash,sucio,conflicto_revision,conexion,acu,especificaciones,metrados,alcance,metrados_revit FROM vinculo WHERE documento=$p0 OR alcance='base' ORDER BY CASE WHEN documento=$p0 THEN 0 ELSE 1 END LIMIT 1";
        q.Parameters.AddWithValue("$p0", id); using var r = q.ExecuteReader();
        if (!r.Read()) return null;
        return new(r.GetString(0), Guid.Parse(r.GetString(1)), r.GetString(2), r.GetString(3), r.GetString(4),
            r.GetInt64(5), r.GetString(6), r.GetInt64(7) != 0, r.GetInt64(8), r.IsDBNull(9) ? null : r.GetString(9),
            r.IsDBNull(10) ? null : new MYGPermisosModulos { Acu = r.GetInt64(10) != 0, Especificaciones = r.GetInt64(11) != 0, MetradosExcel = r.GetInt64(12) != 0, MetradosRevit = !r.IsDBNull(14) && r.GetInt64(14) != 0, MetradosRevitDisponible = !r.IsDBNull(14) }, r.GetString(13));
    }

    private static Pendiente? LeerPendiente(SqliteConnection c, string id)
    {
        using var q = c.CreateCommand(); q.CommandText = "SELECT operacion,revision,ruta,hash,bytes,enviada FROM pendiente WHERE documento=$p0";
        q.Parameters.AddWithValue("$p0", id); using var r = q.ExecuteReader();
        return r.Read() ? new(Guid.Parse(r.GetString(0)), r.GetInt64(1), r.GetString(2), r.GetString(3), r.GetInt64(4), r.GetInt64(5) != 0) : null;
    }

    private static void EscribirEstado(SqliteConnection c, Estado e, SqliteTransaction? t = null) => Ejecutar(c, """
        INSERT INTO vinculo(documento,proyecto,servidor,usuario,rol,revision,hash,sucio,conflicto_revision,conexion,acu,especificaciones,metrados,alcance,metrados_revit)
        VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11,$p12,$p13,$p14)
        ON CONFLICT(documento) DO UPDATE SET proyecto=excluded.proyecto,servidor=excluded.servidor,usuario=excluded.usuario,
          rol=excluded.rol,revision=excluded.revision,hash=excluded.hash,sucio=excluded.sucio,conflicto_revision=excluded.conflicto_revision,
          conexion=excluded.conexion,acu=excluded.acu,especificaciones=excluded.especificaciones,metrados=excluded.metrados,alcance=excluded.alcance,metrados_revit=excluded.metrados_revit
        """, t, e.Documento, e.Proyecto.ToString("D"), e.Servidor, e.Usuario, e.Rol, e.Revision, e.Hash,
            e.Sucio ? 1 : 0, e.Conflicto, e.Conexion, e.Permisos?.Acu, e.Permisos?.Especificaciones, e.Permisos?.MetradosExcel, e.Alcance, e.Permisos?.MetradosRevitDisponible == true ? e.Permisos.MetradosRevit : null);

    private static void EscribirPendiente(SqliteConnection c, string id, Pendiente p) => Ejecutar(c, """
        INSERT INTO pendiente VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6)
        ON CONFLICT(documento) DO UPDATE SET operacion=excluded.operacion,revision=excluded.revision,ruta=excluded.ruta,
          hash=excluded.hash,bytes=excluded.bytes,enviada=excluded.enviada
        """, id, p.Id.ToString("D"), p.Revision, p.Ruta, p.Hash, p.Bytes, p.Enviada ? 1 : 0);

    private static void Ejecutar(SqliteConnection c, string sql, params object?[] valores) => Ejecutar(c, sql, null, valores);
    private static void Ejecutar(SqliteConnection c, string sql, SqliteTransaction? t, params object?[] valores)
    {
        using var q = c.CreateCommand(); q.Transaction = t; q.CommandText = sql;
        for (int i = 0; i < valores.Length; i++) q.Parameters.AddWithValue("$p" + i, valores[i] ?? DBNull.Value);
        q.ExecuteNonQuery();
    }
}
