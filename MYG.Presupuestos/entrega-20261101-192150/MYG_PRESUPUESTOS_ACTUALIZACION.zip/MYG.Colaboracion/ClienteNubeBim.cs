#nullable enable
using System.Text.Json;

namespace MYG.Colaboracion;

public sealed record EstadoBimNube(long RevisionBase, long RevisionBim, JsonElement Contenido,
    string Estado = "actual", Guid? OperacionId = null);

public sealed partial class ClienteSupabase
{
    public async Task<EstadoBimNube> AbrirBimAsync(Guid id, string documentoId, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        if (!TextoEntradaValido(documentoId, 200)) throw new NubeException("Identidad de obra BIM inválida.");
        try
        {
            return await EjecutarRpcNubeAsync("myg_nube_bim_abrir", new { p_id = id, p_documento_id = documentoId },
                LeerEstadoBim, ct);
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883")
        {
            throw new NubeException("Instale la migración de modeladores BIM en Supabase antes de sincronizar este módulo. Se conserva la copia local.");
        }
    }

    public Task<EstadoBimNube> GuardarBimAsync(Guid id, string documentoId, Guid operacion,
        long revisionBase, long revisionBim, JsonElement contenido, CancellationToken ct = default)
    {
        ValidarIdNube(id); ValidarIdNube(operacion);
        if (!TextoEntradaValido(documentoId, 200) || revisionBase < 1 || revisionBim < 0
            || contenido.ValueKind != JsonValueKind.Object) throw new NubeException("La operación BIM no tiene una revisión válida.");
        var copia = contenido.Clone();
        return EjecutarRpcNubeAsync("myg_nube_bim_guardar", new { p_id = id, p_documento_id = documentoId,
            p_operacion = operacion, p_revision_base = revisionBase, p_revision_bim = revisionBim, p_contenido = copia }, raiz =>
        {
            var respuesta = LeerEstadoBim(raiz);
            if (respuesta.Estado is not ("aplicada" or "conflicto") || respuesta.OperacionId != operacion
                || respuesta.Estado == "aplicada" && (respuesta.RevisionBase != revisionBase || respuesta.RevisionBim != revisionBim + 1
                    || !JsonElement.DeepEquals(respuesta.Contenido, copia))) throw RespuestaNubeInvalida();
            return respuesta;
        }, ct);
    }

    public Task<EstadoBimNube> ConfirmarBimSqliteAsync(Guid id, string documentoId, long revisionBase,
        long revisionBim, CancellationToken ct = default) =>
        EjecutarRpcNubeAsync("myg_nube_bim_confirmar_sqlite", new { p_id = id, p_documento_id = documentoId,
            p_revision_base = revisionBase, p_revision_bim = revisionBim }, raiz =>
        {
            if (!raiz.TryGetProperty("estado", out var estado) || estado.GetString() is not ("aplicada" or "conflicto")
                || !raiz.TryGetProperty("revision_base", out var nativa) || !nativa.TryGetInt64(out long rb) || rb < 1
                || !raiz.TryGetProperty("revision_bim", out var bim) || !bim.TryGetInt64(out long ri) || ri < 0)
                throw RespuestaNubeInvalida();
            return new EstadoBimNube(rb, ri, BimNube.Vacio, estado.GetString()!);
        }, ct);

    private static EstadoBimNube LeerEstadoBim(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Object || !raiz.TryGetProperty("revision_base", out var nativa)
            || !nativa.TryGetInt64(out long revision) || revision < 1
            || !raiz.TryGetProperty("revision_bim", out var bim) || !bim.TryGetInt64(out long revisionBim) || revisionBim < 0
            || !raiz.TryGetProperty("contenido", out var contenido) || contenido.ValueKind != JsonValueKind.Object
            || !contenido.TryGetProperty("presupuestos", out var presupuestos) || presupuestos.ValueKind != JsonValueKind.Array)
            throw RespuestaNubeInvalida();
        string estado = raiz.TryGetProperty("estado", out var e) && e.ValueKind == JsonValueKind.String ? e.GetString()! : "actual";
        Guid? operacion = raiz.TryGetProperty("operacion_id", out var o) && o.ValueKind == JsonValueKind.String && o.TryGetGuid(out var oid) ? oid : null;
        return new(revision, revisionBim, contenido.Clone(), estado, operacion);
    }
}
