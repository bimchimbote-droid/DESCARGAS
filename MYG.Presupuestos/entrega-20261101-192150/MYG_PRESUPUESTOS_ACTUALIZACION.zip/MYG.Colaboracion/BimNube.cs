#nullable enable
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG_2027;

namespace MYG.Colaboracion;

/// <summary>Proyección explícita de coordinación BIM. Nunca transporta costos ni contenido de otros módulos.</summary>
public static class BimNube
{
    public static JsonElement Vacio => JsonSerializer.SerializeToElement(new { presupuestos = Array.Empty<object>() });

    public static JsonElement Cambios(MYGProyectoDocumento anterior, MYGProyectoDocumento actual)
    {
        var presupuestos = new JsonArray();
        foreach (var p in actual.Presupuestos)
        {
            var antes = anterior.Presupuestos.SingleOrDefault(x => x.Id == p.Id);
            if (antes == null) continue; // Los cambios generales viajan en el snapshot completo autorizado.
            var filas = new JsonArray();
            foreach (var i in p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i)))
            {
                var previo = antes.Items.SingleOrDefault(x => x.Id == i.Id);
                if (previo == null && !i.CreadaParaBim) continue;
                var fila = Exportar(i);
                if (previo == null || !JsonNode.DeepEquals(fila, Exportar(previo))) filas.Add(fila);
            }
            if (filas.Count > 0 || antes.CantidadFiltros != p.CantidadFiltros)
                presupuestos.Add(new JsonObject { ["id"] = p.Id, ["cantidad_filtros"] = p.CantidadFiltros, ["partidas"] = filas });
        }
        return JsonSerializer.SerializeToElement(new JsonObject { ["presupuestos"] = presupuestos });
    }

    public static bool EstaVacio(JsonElement contenido) => contenido.GetProperty("presupuestos").GetArrayLength() == 0;

    public static JsonElement Combinar(JsonElement confirmado, JsonElement cambios)
    {
        var resultado = JsonNode.Parse(confirmado.GetRawText())!.AsObject();
        var presupuestos = resultado["presupuestos"]!.AsArray();
        foreach (var p in cambios.GetProperty("presupuestos").EnumerateArray())
        {
            string id = p.GetProperty("id").GetString()!;
            var destino = presupuestos.OfType<JsonObject>().SingleOrDefault(x => x["id"]!.GetValue<string>() == id);
            if (destino == null) { presupuestos.Add(JsonNode.Parse(p.GetRawText())); continue; }
            destino["cantidad_filtros"] = p.GetProperty("cantidad_filtros").GetInt32();
            var filas = destino["partidas"]!.AsArray();
            foreach (var i in p.GetProperty("partidas").EnumerateArray())
            {
                var previa = filas.OfType<JsonObject>().SingleOrDefault(x => x["id"]!.GetValue<string>() == i.GetProperty("id").GetString());
                if (previa != null) filas.Remove(previa);
                filas.Add(JsonNode.Parse(i.GetRawText()));
            }
        }
        return JsonSerializer.SerializeToElement(resultado);
    }

    public static MYGProyectoDocumento Aplicar(MYGProyectoDocumento original, JsonElement contenido)
    {
        var copia = MYGProyectoStorage.Copia(original);
        var presupuestos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in contenido.GetProperty("presupuestos").EnumerateArray())
        {
            string id = p.GetProperty("id").GetString()!;
            if (!presupuestos.Add(id)) throw new InvalidDataException("Presupuesto BIM repetido.");
            var destino = copia.Presupuestos.SingleOrDefault(x => x.Id == id)
                ?? throw new InvalidDataException("La configuración BIM corresponde a un presupuesto que ya no existe.");
            int cantidad = p.GetProperty("cantidad_filtros").GetInt32();
            if (cantidad is < 1 or > 8) throw new InvalidDataException("Cantidad de filtros BIM inválida.");
            var filas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var i in p.GetProperty("partidas").EnumerateArray())
            {
                string clave = i.GetProperty("id").GetString()!;
                if (!filas.Add(clave)) throw new InvalidDataException("Partida BIM repetida.");
                bool creada = i.GetProperty("creada_para_bim").GetBoolean();
                var partida = destino.Items.SingleOrDefault(x => x.Id == clave);
                if (partida != null && (MYGProyectoStorage.EsTitulo(partida) || creada != partida.CreadaParaBim))
                    throw new InvalidDataException("La identidad BIM coincide con una fila incompatible. Se conserva la copia local.");
                if (partida == null)
                {
                    if (!creada || !clave.StartsWith("MYG-", StringComparison.Ordinal))
                        throw new InvalidDataException("La partida configurada ya no existe en la revisión SQLite.");
                    string? padre = Texto(i, "parent_id");
                    if (padre != null && !destino.Items.Any(x => x.Id == padre && MYGProyectoStorage.EsTitulo(x)))
                        throw new InvalidDataException("El título de destino BIM ya no existe.");
                    partida = new ItemPresupuestoDelphin
                    {
                        Id = clave, IdLocalMYG = clave, IdPropuesta = clave, CreadaParaBim = true,
                        TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", ParentId = padre,
                        Item = "P-" + (destino.Items.Count + 1).ToString("D3"),
                        Posicion = destino.Items.Where(x => x.ParentId == padre).Select(x => x.Posicion).DefaultIfEmpty().Max() + 1
                    };
                    destino.Items.Add(partida);
                }
                if (creada)
                {
                    // Estos metadatos solo pertenecen a altas BIM; nunca se aplican sobre filas originales.
                    partida.Descripcion = Texto(i, "descripcion"); partida.Unidad = Texto(i, "unidad");
                    if (i.TryGetProperty("catalogo_bim", out var catalogo) && catalogo.ValueKind == JsonValueKind.Object)
                        partida.CatalogoBim = new MYGReferenciaCatalogoBim { Id = Texto(catalogo, "id"), Codigo = Texto(catalogo, "codigo"),
                            RutaSQLite = Texto(catalogo, "ruta_sqlite"), Revision = catalogo.GetProperty("revision").GetInt32() };
                    else partida.CatalogoBim = null;
                }
                partida.Plantilla = Texto(i, "plantilla");
                partida.Filtros = i.GetProperty("filtros").EnumerateArray().Select(f => new FiltroPlanificacion
                    { Parametro = Texto(f, "parametro"), Regla = Texto(f, "regla"), Valor = Texto(f, "valor") }).ToList();
                if (partida.Filtros.Count > 8) throw new InvalidDataException("La partida supera ocho filtros BIM.");
                partida.IdConfiguracionBibliotecaMYG = Texto(i, "id_configuracion_biblioteca_myg");
                partida.Parametro = Texto(i, "parametro"); partida.Regla = Texto(i, "regla"); partida.Valor = Texto(i, "valor");
            }
            destino.CantidadFiltros = cantidad;
            MYGProyectoStorage.ValidarPresupuesto(destino);
            if (destino.Conexion == null) MYGProyectoStorage.Renumerar(destino);
        }
        return copia;
    }

    private static string? Texto(JsonElement objeto, string nombre) =>
        objeto.TryGetProperty(nombre, out var valor) && valor.ValueKind == JsonValueKind.String ? valor.GetString() : null;

    private static JsonObject Exportar(ItemPresupuestoDelphin i)
    {
        var fila = new JsonObject { ["id"] = i.Id, ["creada_para_bim"] = i.CreadaParaBim,
            ["plantilla"] = i.Plantilla, ["filtros"] = JsonSerializer.SerializeToNode((i.Filtros ?? new()).Select(f =>
                new { parametro = f.Parametro, regla = f.Regla, valor = f.Valor })),
            ["id_configuracion_biblioteca_myg"] = i.IdConfiguracionBibliotecaMYG,
            ["parametro"] = i.Parametro, ["regla"] = i.Regla, ["valor"] = i.Valor };
        if (i.CreadaParaBim)
        {
            fila["descripcion"] = i.Descripcion; fila["unidad"] = i.Unidad; fila["parent_id"] = i.ParentId;
            fila["catalogo_bim"] = i.CatalogoBim == null ? null : JsonSerializer.SerializeToNode(new
                { id = i.CatalogoBim.Id, codigo = i.CatalogoBim.Codigo, ruta_sqlite = i.CatalogoBim.RutaSQLite, revision = i.CatalogoBim.Revision });
        }
        return fila;
    }
}
