#nullable enable
using System.Collections.Concurrent;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

public static partial class CopiaSqliteNube
{
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> ExclusionesBim = new(StringComparer.OrdinalIgnoreCase);
    private sealed record BaseBim(string Documento, string JsonBase, string JsonConfirmado, long RevisionBase, long RevisionBim,
        Guid? Operacion, string? JsonPendiente, long BasePendiente, long BimPendiente, string? DocumentoPendiente, bool Conflicto);

    private static void EsquemaBim(SqliteConnection c) => Ejecutar(c, """
        CREATE TABLE IF NOT EXISTS bim_local(documento TEXT PRIMARY KEY,json_base TEXT NOT NULL,json_confirmado TEXT NOT NULL,
          revision_base INTEGER NOT NULL,revision_bim INTEGER NOT NULL,operacion TEXT,json_pendiente TEXT,
          base_pendiente INTEGER NOT NULL DEFAULT 0,bim_pendiente INTEGER NOT NULL DEFAULT 0,documento_pendiente TEXT,
          conflicto INTEGER NOT NULL DEFAULT 0);
        """);

    private static void AsegurarBaseBim(SqliteConnection c, string ruta, string id, long revision)
    {
        EsquemaBim(c);
        if (LeerBaseBim(c, id) != null) return;
        var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, id);
        GuardarBaseBim(c, new(id, MYGColaboracionLocal.ExportarDocumento(documento), BimNube.Vacio.GetRawText(),
            revision, 0, null, null, 0, 0, null, false));
    }

    private static BaseBim? LeerBaseBim(SqliteConnection c, string id)
    {
        EsquemaBim(c);
        using var q = c.CreateCommand(); q.CommandText = "SELECT documento,json_base,json_confirmado,revision_base,revision_bim,operacion,json_pendiente,base_pendiente,bim_pendiente,documento_pendiente,conflicto FROM bim_local WHERE documento=$p0";
        q.Parameters.AddWithValue("$p0", id); using var r = q.ExecuteReader();
        return r.Read() ? new(r.GetString(0), r.GetString(1), r.GetString(2), r.GetInt64(3), r.GetInt64(4),
            r.IsDBNull(5) ? null : Guid.Parse(r.GetString(5)), r.IsDBNull(6) ? null : r.GetString(6), r.GetInt64(7), r.GetInt64(8),
            r.IsDBNull(9) ? null : r.GetString(9), r.GetInt64(10) != 0) : null;
    }

    private static void GuardarBaseBim(SqliteConnection c, BaseBim b) => Ejecutar(c, """
        INSERT INTO bim_local VALUES($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10)
        ON CONFLICT(documento) DO UPDATE SET json_base=excluded.json_base,json_confirmado=excluded.json_confirmado,
          revision_base=excluded.revision_base,revision_bim=excluded.revision_bim,operacion=excluded.operacion,
          json_pendiente=excluded.json_pendiente,base_pendiente=excluded.base_pendiente,bim_pendiente=excluded.bim_pendiente,
          documento_pendiente=excluded.documento_pendiente,conflicto=excluded.conflicto
        """, b.Documento, b.JsonBase, b.JsonConfirmado, b.RevisionBase, b.RevisionBim, b.Operacion?.ToString("D"),
        b.JsonPendiente, b.BasePendiente, b.BimPendiente, b.DocumentoPendiente, b.Conflicto ? 1 : 0);

    public static bool TieneConflictoBim(string ruta, string documentoId)
    {
        if (string.IsNullOrWhiteSpace(ruta) || !File.Exists(RutaEstado(ruta))) return false;
        using var c = AbrirEstado(ruta);
        return LeerBaseBim(c, documentoId)?.Conflicto == true;
    }

    public static async Task<ResultadoSincronizacion> EjecutarAsync(ClienteSupabase cliente, string ruta,
        MYGProyectoDocumento documento, bool soloLeer = false, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        var cerrojo = ExclusionesBim.GetOrAdd(Path.GetFullPath(ruta), _ => new(1, 1));
        await cerrojo.WaitAsync(ct);
        try
        {
            using var c = AbrirEstado(ruta);
            var estado = LeerEstadoDocumento(c, ruta, documento.Id);
            ValidarIdentidad(cliente, estado);
            if (estado.Permisos?.MetradosRevitDisponible != true)
                return await EjecutarArchivoAsync(cliente, ruta, documento, soloLeer, ct, progreso);
            var metadatos = await cliente.AbrirSqliteAsync(estado.Proyecto, ct: ct);
            ValidarRemoto(estado, metadatos);
            estado = estado with { Rol = metadatos.Proyecto.Rol, Permisos = metadatos.Proyecto.PermisosModulos?.Copiar(), Conexion = null };
            EscribirEstado(c, estado);
            // Los servidores anteriores siguen disponibles para lectores y el flujo
            // SQLite original. La edición BIM exige la migración y el permiso explícito.
            bool completo = PuedeEnviar(estado);
            bool puedeBim = SincronizadorProyectoNube.PuedeEditar(estado.Rol) && estado.Permisos?.MetradosRevit == true;
            if (LeerPendiente(c, estado.Documento) != null)
            {
                if (!completo && !soloLeer) throw new NubeException("Hay un envío SQLite completo pendiente. Consérvelo y resuélvalo con un usuario autorizado para todos los módulos.");
                // No fusionar una revisión BIM nueva dentro de bytes ya congelados.
                return await EjecutarArchivoAsync(cliente, ruta, documento, soloLeer, ct, progreso);
            }
            var ids = estado.Alcance == "base" ? MYGBaseDatos.ListarProyectos(ruta).Select(p => p.Id).ToList() : new List<string> { documento.Id };
            var fusionadas = new Dictionary<string, EstadoBimNube>();
            bool cambiosRestantes = false;
            foreach (string id in ids)
            {
                var actual = id == documento.Id ? documento : ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, id);
                string firmaDisco = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, id));
                if (LeerBaseBim(c, id) == null && estado.Sucio && !completo)
                    throw new NubeException("Esta copia anterior contiene cambios sin una base BIM confirmada. Guarde una copia local y vuelva a abrir la obra desde la nube antes de editar filtros; los cambios existentes se conservan.");
                AsegurarBaseBim(c, ruta, id, estado.Revision);
                var local = LeerBaseBim(c, id)!;
                if (local.Conflicto) return new(documento, Adaptar(estado with { Conflicto = Math.Max(1, metadatos.Proyecto.Revision) }, null));
                var anterior = MYGColaboracionLocal.ImportarDocumento(local.JsonBase);
                JsonElement cambios = BimNube.Cambios(anterior, actual);
                if (!completo)
                {
                    // Reconstruir la única modificación autorizada evita confirmar
                    // silenciosamente ediciones de costos, resultados o metadatos ajenos.
                    var permitido = BimNube.Aplicar(anterior, cambios);
                    if (MYGProyectoStorage.Firma(permitido) != MYGProyectoStorage.Firma(actual))
                        throw new NubeException("La copia contiene cambios fuera de partidas y filtros BIM. Se conservan localmente; no se enviará un archivo SQLite opaco con permisos restringidos.");
                }
                EstadoBimNube remoto;
                try { remoto = await cliente.AbrirBimAsync(estado.Proyecto, id, ct); }
                catch (NubeException ex) when (ex.Message.Contains("Instale la migración", StringComparison.Ordinal) && !puedeBim)
                { return await EjecutarArchivoAsync(cliente, ruta, documento, soloLeer, ct, progreso); }
                if (local.Operacion == null && !BimNube.EstaVacio(cambios) && !soloLeer)
                {
                    if (!puedeBim) throw new NubeException("Metrados Revit está en solo lectura. Se conservan los cambios sin enviarlos.", accesoDenegado: true, codigo: "42501");
                    using var confirmado = JsonDocument.Parse(local.JsonConfirmado);
                    var acumulado = BimNube.Combinar(confirmado.RootElement, cambios);
                    local = local with { Operacion = Guid.NewGuid(), JsonPendiente = acumulado.GetRawText(),
                        BasePendiente = local.RevisionBase, BimPendiente = local.RevisionBim,
                        DocumentoPendiente = MYGColaboracionLocal.ExportarDocumento(actual) };
                    GuardarBaseBim(c, local); // Antes del HTTP: UUID, revisiones y cuerpo inmutables.
                }
                bool hayCambios = local.Operacion != null || !BimNube.EstaVacio(cambios);
                if (local.Operacion != null && !soloLeer)
                {
                    if (!puedeBim) throw new NubeException("Se retiró el permiso Metrados Revit. La operación pendiente se conserva sin reenviarla.", accesoDenegado: true, codigo: "42501");
                    using var pendiente = JsonDocument.Parse(local.JsonPendiente!);
                    progreso?.Report("Enviando la configuración BIM con sus revisiones y permisos…");
                    var respuesta = await cliente.GuardarBimAsync(estado.Proyecto, id, local.Operacion.Value,
                        local.BasePendiente, local.BimPendiente, pendiente.RootElement, ct);
                    if (respuesta.Estado == "conflicto")
                    {
                        GuardarBaseBim(c, local with { Conflicto = true });
                        estado = estado with { Conflicto = Math.Max(1, respuesta.RevisionBase), Sucio = true };
                        EscribirEstado(c, estado); return new(documento, Adaptar(estado, null));
                    }
                    // Un usuario puede haber seguido editando después de un fallo HTTP.
                    // Conservar esas ediciones como siguiente borrador, sin cambiarlas por el ACK.
                    var enviado = MYGColaboracionLocal.ImportarDocumento(local.DocumentoPendiente!);
                    var posteriores = BimNube.Cambios(enviado, actual);
                    var confirmadoDocumento = BimNube.Aplicar(actual, respuesta.Contenido);
                    actual = BimNube.Aplicar(BimNube.Aplicar(actual, respuesta.Contenido), posteriores);
                    local = local with { JsonBase = MYGColaboracionLocal.ExportarDocumento(confirmadoDocumento),
                        JsonConfirmado = respuesta.Contenido.GetRawText(), RevisionBase = respuesta.RevisionBase,
                        RevisionBim = respuesta.RevisionBim, Operacion = null, JsonPendiente = null, DocumentoPendiente = null };
                    GuardarBaseBim(c, local); remoto = respuesta;
                    hayCambios = !BimNube.EstaVacio(posteriores);
                }
                if (hayCambios)
                {
                    // Recargar o un ACK de una versión anterior nunca reemplaza el borrador.
                    if (remoto.RevisionBim != local.RevisionBim || remoto.RevisionBase != local.RevisionBase)
                    {
                        GuardarBaseBim(c, local with { Conflicto = true });
                        estado = estado with { Conflicto = Math.Max(1, remoto.RevisionBase), Sucio = true };
                        EscribirEstado(c, estado); return new(documento, Adaptar(estado, null));
                    }
                }
                else
                {
                    if (metadatos.Proyecto.Revision > estado.Revision)
                    {
                        var resultado = await EjecutarArchivoAsync(cliente, ruta, documento, true, ct, progreso);
                        if (resultado.Vinculo.Estado == "conflicto" || resultado.Vinculo.Pendiente != null) return resultado;
                        documento = resultado.Documento; estado = LeerEstadoDocumento(c, ruta, documento.Id);
                        actual = id == documento.Id ? documento : ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, id);
                    }
                    actual = BimNube.Aplicar(actual, remoto.Contenido);
                    local = local with { JsonBase = MYGColaboracionLocal.ExportarDocumento(actual), JsonConfirmado = remoto.Contenido.GetRawText(),
                        RevisionBase = remoto.RevisionBase, RevisionBim = remoto.RevisionBim };
                    GuardarBaseBim(c, local);
                }
                cambiosRestantes |= hayCambios;
                if (MYGProyectoStorage.Firma(actual) != firmaDisco)
                    MYGBaseDatos.GuardarProyectoSiNoCambio(ruta, actual, firmaDisco);
                if (id == documento.Id) documento = actual;
                fusionadas[id] = remoto;
            }
            if (!completo)
            {
                // La modificación autorizada vive en el overlay. No se sube el SQLite.
                string snapshot = Temporal(ruta);
                try { CrearSnapshot(ruta, snapshot, ct); estado = estado with { Hash = Hash(snapshot), Sucio = cambiosRestantes, Conflicto = 0 }; }
                finally { Borrar(snapshot); }
                EscribirEstado(c, estado);
                return new(documento, Adaptar(estado, null));
            }
            long revisionAntes = estado.Revision;
            var sincronizado = await EjecutarArchivoAsync(cliente, ruta, documento, soloLeer, ct, progreso);
            if (!soloLeer && sincronizado.Vinculo.Pendiente == null && sincronizado.Vinculo.Estado != "conflicto"
                && sincronizado.Vinculo.Revision > revisionAntes)
            {
                foreach (var par in fusionadas.Where(p => !BimNube.EstaVacio(p.Value.Contenido)))
                {
                    // Sólo retira exactamente la revisión fusionada; un cambio
                    // concurrente queda en el servidor para la próxima lectura.
                    var confirmacion = await cliente.ConfirmarBimSqliteAsync(estado.Proyecto, par.Key,
                        sincronizado.Vinculo.Revision, par.Value.RevisionBim, ct);
                    if (confirmacion.Estado == "aplicada")
                    {
                        var local = LeerBaseBim(c, par.Key)!;
                        GuardarBaseBim(c, local with { JsonBase = MYGColaboracionLocal.ExportarDocumento(ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, par.Key)),
                            JsonConfirmado = BimNube.Vacio.GetRawText(),
                            RevisionBase = confirmacion.RevisionBase, RevisionBim = confirmacion.RevisionBim });
                    }
                }
            }
            return sincronizado;
        }
        finally { cerrojo.Release(); }
    }
}
