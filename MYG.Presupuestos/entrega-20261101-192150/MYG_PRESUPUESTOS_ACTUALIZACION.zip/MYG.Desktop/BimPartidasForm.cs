using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Consulta de catálogo para BIM: no ofrece edición de precios o ACU.</summary>
internal sealed class BimPartidasForm : Form
{
    private readonly DataGridView tabla = new() { Name = "catalogo_partidas_bim", Dock = DockStyle.Fill,
        ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        MultiSelect = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, RowHeadersVisible = false };
    private readonly TextBox buscar = new() { Name = "buscar_catalogo_bim", Dock = DockStyle.Top,
        PlaceholderText = "Buscar código, descripción o unidad…" };
    private readonly Label origen = new() { Dock = DockStyle.Top, Height = 36, AutoEllipsis = true, Padding = new(8) };
    private List<MYGEntradaCatalogo> entradas;
    internal string Ruta { get; private set; }
    internal MYGEntradaCatalogo Seleccionada { get; private set; }

    internal BimPartidasForm(string ruta)
    {
        MYGProyectoUI.Preparar(this, "Nueva partida BIM desde catálogo", 900, 580);
        MinimumSize = new(640, 420);
        tabla.Columns.Add("CODIGO", "Código"); tabla.Columns.Add("DESCRIPCION", "Partida"); tabla.Columns.Add("UNIDAD", "Unidad");
        tabla.Columns["CODIGO"].Width = 130;
        tabla.Columns["DESCRIPCION"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        tabla.Columns["UNIDAD"].Width = 80;
        var barra = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, Padding = new(5) };
        var abrir = MYGProyectoUI.Boton("Abrir otro catálogo"); abrir.AutoSize = true;
        abrir.Click += (_, _) =>
        {
            using var dialogo = new OpenFileDialog { Filter = "Base MYG (*.sqlite)|*.sqlite", Title = "Consultar otro catálogo de partidas" };
            if (dialogo.ShowDialog(this) == DialogResult.OK) Intentar(() => Cargar(dialogo.FileName));
        };
        barra.Controls.Add(abrir);
        var usar = MYGProyectoUI.Boton("Crear partida BIM", 1); usar.Name = "crear_partida_catalogo_bim";
        usar.AutoSize = true;
        usar.Click += (_, _) => Elegir();
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        var pie = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, FlowDirection = FlowDirection.RightToLeft, Padding = new(6) };
        pie.Controls.Add(cancelar); pie.Controls.Add(usar);
        Controls.Add(tabla); Controls.Add(buscar); Controls.Add(barra); Controls.Add(origen); Controls.Add(pie);
        Controls.Add(new Label { Dock = DockStyle.Bottom, Height = 48, Padding = new(8),
            Text = "Se conserva el vínculo de la partida con el catálogo. Sus precios, ACU, especificaciones y hojas Excel permanecen independientes." });
        buscar.TextChanged += (_, _) => Filtrar();
        tabla.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) Elegir(); };
        AcceptButton = usar; CancelButton = cancelar;
        Cargar(ruta);
    }

    private void Cargar(string ruta)
    {
        var nuevas = MYGCatalogos.Listar(ruta, true);
        Ruta = Path.GetFullPath(ruta); entradas = nuevas; origen.Text = "Catálogo: " + Ruta; Filtrar();
    }
    private void Filtrar()
    {
        tabla.Rows.Clear();
        foreach (var entrada in entradas.Where(i => (i.Codigo + " " + i.Descripcion + " " + i.Unidad)
            .Contains(buscar.Text.Trim(), StringComparison.OrdinalIgnoreCase)))
            tabla.Rows[tabla.Rows.Add(entrada.Codigo, entrada.Descripcion, entrada.Unidad)].Tag = entrada;
    }
    private void Elegir()
    {
        if (tabla.CurrentRow?.Tag is not MYGEntradaCatalogo entrada) return;
        Seleccionada = entrada; DialogResult = DialogResult.OK;
    }
    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception error) { MYGProyectoUI.Error(this, error); }
    }
}
