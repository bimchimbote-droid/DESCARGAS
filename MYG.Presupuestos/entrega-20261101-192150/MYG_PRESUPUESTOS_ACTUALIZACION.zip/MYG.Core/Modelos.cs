using System;
using System.Collections.Generic;
namespace MYG_2027
{
    public class FiltroPlanificacion
    {
        public string Parametro { get; set; }
        public string Regla { get; set; }
        public string Valor { get; set; }

        public bool EstaVacio()
        {
            return string.IsNullOrWhiteSpace(Parametro) &&
                   string.IsNullOrWhiteSpace(Regla) &&
                   string.IsNullOrWhiteSpace(Valor);
        }
    }
    public class ItemPresupuestoDelphin
    {
        public MYGDatosPartida Costos { get; set; } = new MYGDatosPartida();
        // Id de trabajo de la jerarquía.
        // Para partidas Delphin normales = ID interno Delphin.
        // Para propuestas = ID PROPUESTA MYG.
        public string Id { get; set; }

        public string ParentId { get; set; }

        public string Item { get; set; }
        public string Descripcion { get; set; }

        // Unidad de medida informativa para coordinación con presupuesto.
        // En propuestas MYG se edita manualmente.
        public string Unidad { get; set; }

        public string CodigoDelphin { get; set; }

        // Identidad local, análisis y referencia al catálogo: se guardan por separado.
        public string IdLocalMYG { get; set; }
        public string IdAnalisisDelphin { get; set; }
        public string IdCatalogoDelphin { get; set; }
        public string FuenteCatalogoId { get; set; }
        public string FuenteCatalogoRuta { get; set; }
        public string CodigoCatalogoDelphin { get; set; }
        public string IdConfiguracionBibliotecaMYG { get; set; }

        [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingDefault)]
        public bool CreadaParaBim { get; set; }

        // Vínculo de coordinación BIM independiente de la copia del ACU.
        [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
        public MYGReferenciaCatalogoBim CatalogoBim { get; set; }

        // =======================================
        // IDENTIDAD MYG / DELPHIN
        // =======================================
        public string IdPropuesta { get; set; }

        public string IdInternoDelphin { get; set; }

        // DELPHIN / MODELO
        public string Origen { get; set; }

        // OFICIAL / PROPUESTA / VINCULADA /
        // PROP. MODIFICAR / PROP. ELIMINAR
        public string Estado { get; set; }

        // PARTIDA / TITULO
        public string TipoPropuesta { get; set; }

        // Datos oficiales previos cuando se propone modificar.
        public string PartidaOriginal { get; set; }
        public string UnidadOriginal { get; set; }

        // Texto/unidad que el modelador está proponiendo.
        // Se guardan separados de los valores oficiales.
        public string PartidaPropuesta { get; set; }
        public string UnidadPropuesta { get; set; }

        public string Plantilla { get; set; }

        public List<FiltroPlanificacion> Filtros { get; set; } =
            new List<FiltroPlanificacion>();

        // =======================================
        // ESTADO REVIT - SOLO SESION ACTUAL
        // No se guarda en el JSON porque representa el resultado
        // de la última revisión contra el documento Revit abierto.
        // =======================================
        [System.Text.Json.Serialization.JsonIgnore]
        public string EstadoRevit { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public string MensajeRevit { get; set; }

        // Compatibilidad con JSON anteriores.
        public string Parametro { get; set; }
        public string Regla { get; set; }
        public string Valor { get; set; }

        public int Posicion { get; set; }

        public override string ToString()
        {
            string item =
                (Item ?? "").Trim();

            string descripcion =
                (Descripcion ?? "").Trim();

            string id =
                (IdInternoDelphin ?? Id ?? "").Trim();

            if (string.IsNullOrWhiteSpace(item))
            {
                return descripcion +
                    (string.IsNullOrWhiteSpace(id)
                    ? ""
                    : "  [" + id + "]");
            }

            return item +
                " - " +
                descripcion +
                (string.IsNullOrWhiteSpace(id)
                ? ""
                : "  [" + id + "]");
        }
    }
    public class ConfiguracionTablaPlanificacion
    {
        // CLAVE PERSISTENTE:
        // - oficial Delphin: ID interno Delphin
        // - propuesta MYG: ID propuesta
        public string IdInterno { get; set; }

        public string ParentId { get; set; }

        public string IdPropuesta { get; set; }

        public string IdInternoDelphin { get; set; }

        public string Origen { get; set; }

        public string Estado { get; set; }

        public string TipoPropuesta { get; set; }

        public string PartidaOriginal { get; set; }
        public string UnidadOriginal { get; set; }

        public string PartidaPropuesta { get; set; }
        public string UnidadPropuesta { get; set; }

        public int Posicion { get; set; }

        public string CodigoDelphin { get; set; }

        // Identidad local, análisis y referencia al catálogo: se guardan por separado.
        public string IdLocalMYG { get; set; }
        public string IdAnalisisDelphin { get; set; }
        public string IdCatalogoDelphin { get; set; }
        public string FuenteCatalogoId { get; set; }
        public string FuenteCatalogoRuta { get; set; }
        public string CodigoCatalogoDelphin { get; set; }
        public string IdConfiguracionBibliotecaMYG { get; set; }
        public string Item { get; set; }
        public string Partida { get; set; }
        public string Unidad { get; set; }
        public string Plantilla { get; set; }

        public List<FiltroPlanificacion> Filtros { get; set; } =
            new List<FiltroPlanificacion>();

        // Compatibilidad con JSON anteriores.
        public string Parametro { get; set; }
        public string Regla { get; set; }
        public string Valor { get; set; }

        public List<FiltroPlanificacion> ObtenerFiltros()
        {
            if (Filtros != null && Filtros.Count > 0)
                return Filtros;

            var resultado = new List<FiltroPlanificacion>();

            if (!string.IsNullOrWhiteSpace(Parametro) ||
                !string.IsNullOrWhiteSpace(Regla) ||
                !string.IsNullOrWhiteSpace(Valor))
            {
                resultado.Add(new FiltroPlanificacion()
                {
                    Parametro = Parametro,
                    Regla = Regla,
                    Valor = Valor
                });
            }

            return resultado;
        }
    }
    public class ProyectoDelphin
    {
        public string Id { get; set; }
        public string Nombre { get; set; }

        public override string ToString()
        {
            return Nombre;
        }
    }
    public class PresupuestoDelphin
    {
        public string Id { get; set; }
        public string Item { get; set; }
        public string Nombre { get; set; }
        public int Posicion { get; set; }

        public override string ToString()
        {
            string item = (Item ?? "").Trim();
            string nombre = (Nombre ?? "").Trim();

            if (string.IsNullOrWhiteSpace(item))
                return nombre;

            if (string.IsNullOrWhiteSpace(nombre))
                return item;

            return item + " - " + nombre;
        }
    }
    public class ResultadoValidacionRevitPartida
    {
        public string ClavePartida { get; set; }
        public string Estado { get; set; }
        public string Mensaje { get; set; }

        public bool PuedeSincronizar
        {
            get
            {
                return string.Equals(
                    Estado,
                    "LISTO",
                    StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}
