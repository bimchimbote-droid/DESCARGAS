using System.IO;

namespace MYG_2027;

public enum MYGOperacionFiltrosBim { Reemplazar, Agregar, Modificar, Eliminar, Limpiar }

/// <summary>Un lote se precomprueba completo y se confirma de una sola vez.</summary>
public static class MYGEdicionMasivaFiltrosBim
{
    public static void Aplicar(MYGProyectoDocumento documento, string presupuestoId, IEnumerable<string> ids,
        MYGOperacionFiltrosBim operacion, IEnumerable<FiltroPlanificacion> filtros, string plantilla,
        bool cambiarPlantilla, MYGPermisosModulos permisos, string rol, int indice = 0)
    {
        MYGPartidasBim.ExigirPermiso(permisos, rol);
        ArgumentNullException.ThrowIfNull(documento); ArgumentNullException.ThrowIfNull(ids);
        if (!Enum.IsDefined(operacion)) throw new InvalidDataException("Operación de filtros no reconocida.");
        var seleccion = ids.ToList();
        if (seleccion.Count == 0 || seleccion.Any(string.IsNullOrWhiteSpace) ||
            seleccion.Distinct(StringComparer.OrdinalIgnoreCase).Count() != seleccion.Count)
            throw new InvalidDataException("Seleccione partidas con identificadores únicos.");
        var entrada = MYGProyectoStorage.Copia(filtros?.ToList() ?? new List<FiltroPlanificacion>());
        ValidarFiltros(entrada);
        if (operacion == MYGOperacionFiltrosBim.Agregar && entrada.Count == 0 ||
            operacion == MYGOperacionFiltrosBim.Modificar && entrada.Count != 1)
            throw new InvalidDataException("Indique los filtros del lote; modificar requiere exactamente un filtro.");
        var original = MYGPartidasBim.Presupuesto(documento, presupuestoId);
        var candidato = MYGProyectoStorage.Copia(documento);
        var presupuesto = MYGPartidasBim.Presupuesto(candidato, presupuestoId);
        var mapa = new Dictionary<string, ItemPresupuestoDelphin>(StringComparer.OrdinalIgnoreCase);
        foreach (var partida in presupuesto.Items)
            if (partida == null || string.IsNullOrWhiteSpace(partida.Id) || !mapa.TryAdd(partida.Id, partida))
                throw new InvalidDataException("El presupuesto contiene identificadores ausentes o repetidos.");
        foreach (string id in seleccion)
        {
            if (!mapa.TryGetValue(id, out var partida) || MYGProyectoStorage.EsTitulo(partida))
                throw new InvalidDataException("La selección debe contener sólo partidas del presupuesto activo.");
            var actuales = MYGBibliotecaPartidas.FiltrosGuardables(partida);
            if (operacion is MYGOperacionFiltrosBim.Modificar or MYGOperacionFiltrosBim.Eliminar &&
                (indice < 0 || indice >= actuales.Count))
                throw new InvalidDataException("El filtro elegido no existe en todas las partidas seleccionadas.");
            switch (operacion)
            {
                case MYGOperacionFiltrosBim.Reemplazar: actuales = MYGProyectoStorage.Copia(entrada); break;
                case MYGOperacionFiltrosBim.Agregar: actuales.AddRange(MYGProyectoStorage.Copia(entrada)); break;
                case MYGOperacionFiltrosBim.Modificar: actuales[indice] = MYGProyectoStorage.Copia(entrada[0]); break;
                case MYGOperacionFiltrosBim.Eliminar: actuales.RemoveAt(indice); break;
                case MYGOperacionFiltrosBim.Limpiar: actuales.Clear(); break;
            }
            ValidarFiltros(actuales);
            partida.Filtros = actuales;
            if (cambiarPlantilla) partida.Plantilla = string.IsNullOrWhiteSpace(plantilla) ? null : plantilla.Trim();
            partida.IdConfiguracionBibliotecaMYG = null;
            ActualizarLegado(partida);
            partida.EstadoRevit = null; partida.MensajeRevit = null;
            presupuesto.CantidadFiltros = Math.Max(presupuesto.CantidadFiltros, Math.Max(1, actuales.Count));
        }
        MYGCambiosModulosNube.ExigirPermitidos(documento, candidato, permisos);
        original.Items = presupuesto.Items; original.CantidadFiltros = presupuesto.CantidadFiltros;
    }

    public static void ValidarFiltros(IReadOnlyCollection<FiltroPlanificacion> filtros)
    {
        if (filtros == null || filtros.Count > 8 || filtros.Any(f => f == null ||
            string.IsNullOrWhiteSpace(f.Parametro) || string.IsNullOrWhiteSpace(f.Regla)))
            throw new InvalidDataException("Complete parámetro y regla de cada filtro, con un máximo de ocho filtros por partida.");
    }

    internal static void ActualizarLegado(ItemPresupuestoDelphin partida)
    {
        var primero = partida.Filtros.FirstOrDefault();
        partida.Parametro = primero?.Parametro; partida.Regla = primero?.Regla; partida.Valor = primero?.Valor;
    }
}
