using System.IO;

namespace MYG_2027;

public sealed class MYGReferenciaCatalogoBim
{
    public string Id { get; set; }
    public string Codigo { get; set; }
    public string RutaSQLite { get; set; }
    public int Revision { get; set; }
}

/// <summary>Altas de coordinación: no importan precios, análisis, hojas ni especificaciones.</summary>
public static class MYGPartidasBim
{
    public static void ExigirPermiso(MYGPermisosModulos permisos, string rol)
    {
        if (rol is not ("propietario" or "administrador" or "editor") || permisos?.MetradosRevit == false)
            throw new InvalidOperationException("Metrados Revit está en solo lectura. Solicite el permiso al administrador de la obra.");
    }

    public static ItemPresupuestoDelphin CrearTexto(MYGProyectoDocumento documento, string presupuestoId,
        string descripcion, string unidad, string padreId, MYGPermisosModulos permisos, string rol)
    {
        ExigirPermiso(permisos, rol);
        return Crear(documento, presupuestoId, descripcion, unidad, padreId, permisos, null);
    }

    public static ItemPresupuestoDelphin CrearCatalogo(MYGProyectoDocumento documento, string presupuestoId,
        string rutaCatalogo, MYGEntradaCatalogo entrada, string padreId, MYGPermisosModulos permisos, string rol)
    {
        ExigirPermiso(permisos, rol);
        ArgumentNullException.ThrowIfNull(entrada);
        string ruta = Path.GetFullPath(rutaCatalogo);
        // La lista de selección no concede autoridad para inventar una referencia
        // o reutilizar una revisión que cambió mientras el diálogo estaba abierto.
        var actual = MYGCatalogos.Listar(ruta, true).SingleOrDefault(e =>
            string.Equals(e.Id, entrada.Id, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("La partida ya no existe en el catálogo. Actualice la selección.");
        if (entrada.Revision != actual.Revision)
            throw new InvalidOperationException("La partida cambió en el catálogo. Actualice la selección.");
        return Crear(documento, presupuestoId, actual.Descripcion, actual.Unidad, padreId, permisos,
            new MYGReferenciaCatalogoBim { Id = actual.Id, Codigo = actual.Codigo,
                RutaSQLite = ruta, Revision = actual.Revision });
    }

    private static ItemPresupuestoDelphin Crear(MYGProyectoDocumento documento, string presupuestoId,
        string descripcion, string unidad, string padreId, MYGPermisosModulos permisos, MYGReferenciaCatalogoBim catalogo)
    {
        ArgumentNullException.ThrowIfNull(documento);
        descripcion = (descripcion ?? "").Trim(); unidad = (unidad ?? "").Trim();
        if (descripcion.Length is 0 or > 2000 || unidad.Length is 0 or > 80)
            throw new InvalidDataException("Indique una descripción de hasta 2000 caracteres y una unidad de hasta 80 caracteres.");
        var original = Presupuesto(documento, presupuestoId);
        var candidato = MYGProyectoStorage.Copia(documento);
        var destino = Presupuesto(candidato, presupuestoId);
        padreId = string.IsNullOrWhiteSpace(padreId) ? null : padreId;
        if (padreId != null && !destino.Items.Any(i => string.Equals(i.Id, padreId, StringComparison.OrdinalIgnoreCase)
            && MYGProyectoStorage.EsTitulo(i)))
            throw new InvalidOperationException("Seleccione un título del presupuesto como destino.");
        string id = MYGProyectoStorage.NuevoId();
        var partida = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, CreadaParaBim = true, CatalogoBim = catalogo,
            Descripcion = descripcion, Unidad = unidad, ParentId = padreId, TipoPropuesta = "PARTIDA",
            Origen = "MODELO", Estado = "PROPUESTA", Item = "P-" + (destino.Items.Count + 1).ToString("D3"),
            Posicion = destino.Items.Where(i => string.Equals(i.ParentId, padreId, StringComparison.OrdinalIgnoreCase))
                .Select(i => i.Posicion).DefaultIfEmpty().Max() + 1
        };
        // Una reutilización del catálogo conserva la configuración de la obra,
        // sin convertir la edición de una instancia en una escritura del ACU.
        var configurada = catalogo == null ? null : candidato.Presupuestos.SelectMany(p => p.Items)
            .FirstOrDefault(i => i.CatalogoBim != null &&
                MYGBibliotecaPartidas.Coincide(MYGBibliotecaPartidas.Referencia(i), partida) &&
                MYGProyectoStorage.MismaUnidad(i.Unidad, partida.Unidad) &&
                MYGProyectoStorage.TieneBim(i));
        if (configurada != null)
        {
            partida.Plantilla = configurada.Plantilla;
            partida.Filtros = MYGBibliotecaPartidas.FiltrosGuardables(configurada);
            MYGEdicionMasivaFiltrosBim.ActualizarLegado(partida);
        }
        destino.Items.Add(partida);
        destino.CantidadFiltros = Math.Max(destino.CantidadFiltros, Math.Max(1, partida.Filtros.Count));
        MYGProyectoStorage.ValidarPresupuesto(destino);
        if (destino.Conexion == null) MYGProyectoStorage.Renumerar(destino);
        MYGCambiosModulosNube.ExigirPermitidos(documento, candidato, permisos);
        original.Items = destino.Items; original.CantidadFiltros = destino.CantidadFiltros;
        return partida;
    }

    internal static MYGPresupuestoDocumento Presupuesto(MYGProyectoDocumento documento, string id) =>
        documento.Presupuestos.SingleOrDefault(p => string.Equals(p.Id, id, StringComparison.OrdinalIgnoreCase))
        ?? throw new InvalidOperationException("El presupuesto ya no está disponible.");
}
