using System.Text.Json.Serialization;

namespace MYG_2027;

/// <summary>Permisos de edición; la consulta de los módulos permanece disponible.</summary>
public sealed class MYGPermisosModulos
{
    [JsonPropertyName("acu")]
    public bool Acu { get; set; } = true;

    [JsonPropertyName("especificaciones")]
    public bool Especificaciones { get; set; } = true;

    [JsonPropertyName("metrados_excel")]
    public bool MetradosExcel { get; set; } = true;

    [JsonPropertyName("metrados_revit")]
    public bool MetradosRevit { get; set; }

    [JsonIgnore]
    public bool MetradosRevitDisponible { get; set; }

    public MYGPermisosModulos Copiar() => new()
    {
        Acu = Acu,
        Especificaciones = Especificaciones,
        MetradosExcel = MetradosExcel,
        MetradosRevit = MetradosRevit,
        MetradosRevitDisponible = MetradosRevitDisponible
    };

    public bool Permite(string rol, string modulo)
    {
        if (rol is not ("propietario" or "administrador" or "editor")) return false;
        return modulo switch
        {
            "acu" => Acu,
            "especificaciones" => Especificaciones,
            "metrados_excel" => MetradosExcel,
            "metrados_revit" => MetradosRevit,
            _ => false
        };
    }
}
