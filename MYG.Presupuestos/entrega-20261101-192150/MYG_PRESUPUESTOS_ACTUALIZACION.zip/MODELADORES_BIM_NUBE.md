# Actualización de modeladores BIM en MYG Nube

Base: `main`, commit `a3130eca22fb423fbe7aae665a02dccdb379522c`. Entrega de código fuente, no instalador.

## Uso
La ventana BIM oculta ID interno, código Delphin, ID propuesta, origen y estado. Mantiene sus datos internos. Permite añadir partidas de texto o catálogo sin importar ACU, especificaciones ni hojas Excel. Seleccione partidas con Ctrl/Mayús y use **Editar filtros en lote**: reemplazar, agregar, modificar, eliminar o limpiar. Cada lote se valida antes de aplicarse; no limita la cantidad de partidas seleccionadas.

Los filtros y la referencia de catálogo se conservan en la obra SQLite. **Guardar filtros / Traer filtros** permite reutilizarlos mediante la biblioteca existente. Los IDs GUID del catálogo MYG mantienen su identidad al copiar o trasladar ese catálogo. Los IDs nativos no globales usan el ámbito de la ruta para evitar asociaciones erróneas; trasladarlos entre equipos requiere verificar/asociar la biblioteca explícitamente.

## Instalación manual
1. Cierre MYG y Revit. Respalde/confirme sus cambios locales, bases y archivos auxiliares `.nube.sqlite`/`.nube`. No los sustituya con archivos de otra persona.
2. Extraiga el ZIP en una carpeta temporal y copie sus archivos en la raíz de su repositorio, conservando las rutas relativas de la tabla. Los archivos REEMPLAZAR se entregan completos: compare antes si su código cambió después del commit base. No copie sobre una base de datos de usuario.
3. En el SQL Editor del proyecto Supabase correcto, aplique **supabase/migraciones/20261104_modeladores_bim.sql** completo. Requiere `20261030_archivos_sqlite.sql` y sus prerrequisitos; puede aplicarse después de las migraciones actuales hasta `20261103`. Respalde la configuración de producción antes de la migración. No aplique los scripts de pruebas a producción.
4. Actualice el cliente de todos los participantes. En Colaboración asigne rol **editor** y habilite **Metrados Revit**. ACU, Especificaciones y Metrados Excel pueden permanecer desactivados para el modelador. Los miembros anteriores conservan el acceso BIM implícito que ya tenían; revíselo y retírelo donde corresponda. Los miembros nuevos no lo reciben automáticamente.
5. Abra/recargue la obra compartida antes de editar y sincronice después de los cambios. Las operaciones BIM usan revisión de base y revisión BIM, UUID durable y autorización del servidor; no suben una base SQLite opaca con permisos restringidos.
6. Ante conflicto no se sobrescribe automáticamente. Guarde una copia local, elija **Usar remoto** (se conserva un respaldo SQLite del archivo anterior) y reaplique los cambios que quiera mantener sobre la revisión confirmada. No borre el sidecar para intentar resolverlo.

## Compilar y probar
Windows x64, Visual Studio compatible con .NET 10, SDK 10.0.100 o compatible con global.json. No se añadieron paquetes externos nuevos. Desde la raíz:

```text
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --modeladores-bim
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --modeladores-bim
```

El modo `UseRevitReferencePackages=true` permite compilar sin instalación local de Revit usando las referencias 2027.0.0. Para ejecutar el conector necesita Revit 2027 en Windows. Para pruebas SQL desechables: `bash scripts/pruebas/Probar-ModeladoresBim.sh` con Docker y .NET. Para comprobación visual en Windows: `dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --modeladores-bim`.

## Límites y comprobaciones manuales
Esta entrega especializa la ventana en partidas y filtros. Los resultados numéricos, federación y configuración de activos siguen el flujo completo existente; están deshabilitados para modeladores con permisos restringidos porque el overlay BIM no transporta esos datos. Un snapshot SQLite completo requiere todos los permisos: si revoca BIM pero mantiene los otros tres, sus ediciones pueden guardarse localmente, pero ese snapshot opaco no se sincroniza. No conceda BIM como sustituto de la autorización de otro módulo.

En Windows compruebe con dos usuarios: alta texto/catálogo, selección masiva, guardar/cerrar/reabrir, recarga en el segundo cliente, revocación del permiso y conflicto simultáneo. La interfaz visual y una sesión real de Revit/Supabase no se ejecutaron en Linux. La suite general de nube ya tenía un fallo previo en PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar; no se ha desactivado ni se declara aprobada.

## Commit y Push del código por el usuario
En Visual Studio, abra **Cambios de Git**, revise el diff, compile y haga Commit; después haga Push a su rama de trabajo y compruebe `main` en GitHub. Esta entrega no hace Push ni mezcla cambios del repositorio del código. Publicar el ZIP en DESCARGAS no aplica estos archivos automáticamente a su proyecto.

## Archivos de esta entrega

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `MODELADORES_BIM_NUBE.md` | CREAR | Instrucciones y relación completa de archivos |
| 2 | `MYG.Colaboracion/BimNube.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 3 | `MYG.Colaboracion/ClienteNubeBim.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 4 | `MYG.Colaboracion/ClienteNubeComprimida.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 5 | `MYG.Colaboracion/ClienteNubeProyectos.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 6 | `MYG.Colaboracion/ClienteNubeSqlite.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 7 | `MYG.Colaboracion/CopiaSqliteNube.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 8 | `MYG.Colaboracion/CopiaSqliteNubeBim.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 9 | `MYG.Core/BaseDatosMYG.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 10 | `MYG.Core/CambiosModulosNube.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 11 | `MYG.Core/EdicionMasivaFiltrosBim.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 12 | `MYG.Core/Modelos.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 13 | `MYG.Core/PartidasBim.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 14 | `MYG.Core/PermisosModulosMYG.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 15 | `MYG.Core/ProyectoBim.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 16 | `MYG.Desktop/BimFiltrosMasivosForm.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 17 | `MYG.Desktop/BimPartidasForm.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 18 | `MYG.Desktop/EditorForm.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 19 | `MYG.Desktop/EditorModeladoresBim.cs` | CREAR | Interfaz, persistencia o sincronización del módulo BIM |
| 20 | `MYG.Desktop/EditorNube.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 21 | `MYG.Desktop/PermisosModulosNubeForm.cs` | REEMPLAZAR | Interfaz, persistencia o sincronización del módulo BIM |
| 22 | `MYG.Pruebas/ModeladoresBimCoreCheck.cs` | CREAR | Pruebas de regresión y del módulo BIM |
| 23 | `MYG.Pruebas/Program.cs` | REEMPLAZAR | Pruebas de regresión y del módulo BIM |
| 24 | `MYG.PruebasNube/CopiaSqliteBaseNubeCheck.cs` | REEMPLAZAR | Pruebas de regresión y del módulo BIM |
| 25 | `MYG.PruebasNube/CopiaSqliteNubeCheck.cs` | REEMPLAZAR | Pruebas de regresión y del módulo BIM |
| 26 | `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Pruebas de regresión y del módulo BIM |
| 27 | `MYG.PruebasUI/ModeladoresBimUICheck.cs` | CREAR | Pruebas de regresión y del módulo BIM |
| 28 | `MYG.PruebasUI/Program.cs` | REEMPLAZAR | Pruebas de regresión y del módulo BIM |
| 29 | `scripts/pruebas/Probar-ModeladoresBim.sh` | CREAR | Pruebas de regresión y del módulo BIM |
| 30 | `supabase/migraciones/20261104_modeladores_bim.sql` | CREAR | Autorización y revisión de cambios BIM en Supabase |
| 31 | `supabase/pruebas/modeladores_bim.sql` | CREAR | Pruebas de regresión y del módulo BIM |

## Validación ejecutada en esta entrega

- SDK .NET 10.0.100; solución Release: 0 errores y 0 advertencias.
- Suite principal: 806 comprobaciones aprobadas (muestras externas y Named Pipes Windows omitidos explícitamente).
- Suite focalizada del núcleo BIM: 6 grupos aprobados, incluida selección de 1001 partidas.
- Transporte BIM con HTTP simulado y SQLite real: alta/filtros con permiso BIM exclusivo, ACK perdido, reintento con mismo UUID, edición posterior conservada, recarga sin subida SQLite y rechazo de escritura local concurrente: aprobado.
- SQLite nativo: 506 comprobaciones; publicación SQLite: 21; motor SQLite: 29; base multiobra: 75, aprobadas.
- PostgreSQL 17 desechable: 27 comprobaciones BIM aprobadas y migración aplicada dos veces. No se ejecutó contra producción.
- Pruebas GUI nuevas compiladas; no ejecutadas en Linux. La suite completa de nube conserva el fallo previo descrito arriba y no se declara aprobada.
