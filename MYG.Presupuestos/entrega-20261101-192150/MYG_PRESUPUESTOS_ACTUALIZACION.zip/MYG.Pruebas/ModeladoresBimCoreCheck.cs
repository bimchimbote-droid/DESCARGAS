using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ModeladoresBimCoreCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza(Action accion)
    {
        bool rechazada = false;
        try { accion(); }
        catch (InvalidOperationException) { rechazada = true; }
        catch (InvalidDataException) { rechazada = true; }
        Exige(rechazada, "Una operación BIM inválida o sin permiso fue aceptada.");
    }

    private static FiltroPlanificacion Filtro(string valor = "N01") =>
        new() { Parametro = "Nivel", Regla = "igual", Valor = valor };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var permisos = new MYGPermisosModulos { Acu = false, Especificaciones = false,
            MetradosExcel = false, MetradosRevit = true };
        var denegado = permisos.Copiar(); denegado.MetradosRevit = false;
        var doc = MYGProyectoStorage.Nuevo("OBRA BIM");
        string presupuestoId = doc.Presupuestos[0].Id;
        string original = MYGProyectoStorage.Firma(doc);
        Rechaza(() => MYGPartidasBim.CrearTexto(doc, presupuestoId, "Sin permiso", "m²", null, denegado, "editor"));
        Rechaza(() => MYGPartidasBim.CrearTexto(doc, presupuestoId, "Lector", "m²", null, permisos, "lector"));
        Exige(original == MYGProyectoStorage.Firma(doc), "La operación rechazada mutó la obra.");
        Exige(!JsonSerializer.Deserialize<MYGPermisosModulos>("{\"acu\":true}").MetradosRevit,
            "Un permiso ausente concedió escritura BIM.");
        Exige(permisos.Permite("editor", "metrados_revit") && !denegado.Permite("editor", "metrados_revit"),
            "El permiso BIM depende de módulos ajenos.");
        pasa("Metrados Revit exige su permiso independiente y rol de edición incluso en llamadas directas; permiso ausente se deniega");

        var primera = MYGPartidasBim.CrearTexto(doc, presupuestoId, "Concreto de coordinación", "m³", null, permisos, "editor");
        Exige(primera.CreadaParaBim && primera.Id == primera.IdLocalMYG && primera.Costos.Analisis.Count == 0 &&
            primera.Costos.PrecioDirecto == 0 && primera.Costos.EspecificacionTexto == "" &&
            primera.Costos.Hoja.Celdas.Count == new MYGDatosPartida().Hoja.Celdas.Count,
            "La creación BIM incorporó contenido de otro módulo.");
        var p = doc.Presupuestos[0];
        for (int n = 1; n <= 1000; n++)
        {
            string id = "BIM-" + n;
            p.Items.Add(new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
                Descripcion = "Partida " + n, Unidad = "m²", CreadaParaBim = true, TipoPropuesta = "PARTIDA",
                Origen = "MODELO", Estado = "PROPUESTA", Posicion = n + 1 });
        }
        string[] ids = p.Items.Select(i => i.Id).ToArray();
        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Reemplazar,
            new[] { Filtro() }, "PLANTILLA BIM", true, permisos, "editor");
        Exige(p.Items.Count == 1001 && p.Items.All(i => i.Filtros.Count == 1 && i.Plantilla == "PLANTILLA BIM"),
            "El lote limitó arbitrariamente la selección.");
        p.Items[0].Filtros[0].Valor = "ÚNICA";
        Exige(p.Items[1].Filtros[0].Valor == "N01", "Dos partidas comparten la misma instancia de filtros.");
        pasa("La edición masiva aplica filtros y plantilla a 1001 partidas sin tope de selección ni referencias compartidas");

        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Reemplazar,
            Enumerable.Range(1, 8).Select(n => Filtro(n.ToString())), null, false, permisos, "editor");
        string ocho = MYGProyectoStorage.Firma(doc);
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Agregar,
            new[] { Filtro() }, null, false, permisos, "editor"));
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids.Append("AJENA"),
            MYGOperacionFiltrosBim.Limpiar, null, null, false, permisos, "editor"));
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids,
            MYGOperacionFiltrosBim.Reemplazar, new[] { new FiltroPlanificacion { Valor = "incompleto" } }, null, false, permisos, "editor"));
        Exige(ocho == MYGProyectoStorage.Firma(doc), "Un lote inválido dejó cambios parciales.");
        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Modificar,
            new[] { Filtro("MODIFICADO") }, null, false, permisos, "editor", 7);
        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Eliminar,
            null, null, false, permisos, "editor", 0);
        Exige(p.Items.All(i => i.Filtros.Count == 7 && i.Filtros[6].Valor == "MODIFICADO" && i.Parametro == "Nivel"),
            "Modificar/eliminar perdió orden o campos legados.");
        pasa("Lotes de filtros respetan ocho por tabla, modifican y eliminan por posición y rechazan fallos sin cambios parciales");

        var copia = MYGProyectoStorage.Copia(doc);
        void Protegido(Action<MYGProyectoDocumento> cambiar)
        {
            var candidato = MYGProyectoStorage.Copia(copia); cambiar(candidato);
            Rechaza(() => MYGCambiosModulosNube.ExigirPermitidos(copia, candidato, denegado));
        }
        Protegido(d => d.Presupuestos[0].Items.RemoveAt(0));
        Protegido(d => d.Presupuestos[0].Items[0].Descripcion = "Cambio sin permiso");
        Protegido(d => d.Presupuestos[0].Items[0].Filtros[0].Valor = "cambio");
        Protegido(d => d.Presupuestos[0].Items[0].IdLocalMYG = "OTRA");
        Protegido(d => d.Presupuestos[0].CantidadFiltros = 2);
        Protegido(d => d.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.BIM);
        Protegido(d => d.Presupuestos[0].Items[0].Costos.MetradosBIM.Add(new MYGMetradoBIM()));
        var cambiaAcu = MYGProyectoStorage.Copia(copia); cambiaAcu.Presupuestos[0].Items[0].Costos.PrecioDirecto = 50;
        Rechaza(() => MYGCambiosModulosNube.ExigirPermitidos(copia, cambiaAcu, permisos));
        var permiteAcu = denegado.Copiar(); permiteAcu.Acu = true;
        MYGCambiosModulosNube.ExigirPermitidos(copia, cambiaAcu, permiteAcu);
        var heredada = MYGProyectoStorage.Copia(copia);
        heredada.Presupuestos[0].Items.ForEach(i => i.CreadaParaBim = false);
        var filtroHeredado = MYGProyectoStorage.Copia(heredada);
        filtroHeredado.Presupuestos[0].Items[0].Filtros[0].Valor = "Sin permiso en partida existente";
        Rechaza(() => MYGCambiosModulosNube.ExigirPermitidos(heredada, filtroHeredado, denegado));
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids,
            MYGOperacionFiltrosBim.Limpiar, null, null, false, denegado, "editor"));
        pasa("La guardia compuesta protege alta/baja, identidad, filtros, columnas y metrados BIM sin conceder ACU, Excel o especificaciones");

        string ruta = Path.Combine(carpeta, "modeladores-bim.sqlite");
        MYGProyectoStorage.Guardar(ruta, doc);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        Exige(reabierto.Presupuestos[0].Items.Count == 1001 && reabierto.Presupuestos[0].Items.All(i =>
            i.CreadaParaBim && i.Filtros.Count == 7 && i.Filtros[6].Valor == "MODIFICADO"),
            "Cerrar y reabrir SQLite perdió la configuración BIM.");
        pasa("SQLite conserva identidad BIM, plantilla y filtros de todas las partidas al guardar y reabrir");

        var fuente = MYGProyectoStorage.Nuevo("CATÁLOGO"); var pf = fuente.Presupuestos[0];
        var raiz = new ItemPresupuestoDelphin { Id = "RAIZ", IdLocalMYG = "RAIZ", Descripcion = "Entrada con costos",
            Unidad = "m³", TipoPropuesta = "PARTIDA", Costos = new() { PrecioDirecto = 123,
                EspecificacionTexto = "Especificación que no se debe copiar" } };
        pf.Items.Add(raiz);
        string catalogo = Path.Combine(carpeta, "catalogo-bim.sqlite"); MYGProyectoStorage.Guardar(catalogo, fuente);
        var entrada = MYGCatalogos.GuardarPartida(catalogo, pf, raiz, "CAT-001", raiz.Descripcion, raiz.Unidad);
        var destino = MYGProyectoStorage.Nuevo("OBRA DESTINO"); string destinoId = destino.Presupuestos[0].Id;
        var creada = MYGPartidasBim.CrearCatalogo(destino, destinoId, catalogo, entrada, null, permisos, "editor");
        Exige(creada.CatalogoBim?.Id == entrada.Id && creada.CatalogoBim.Revision == entrada.Revision &&
            creada.Costos.PrecioDirecto == 0 && creada.Costos.EspecificacionTexto == "" && creada.Costos.CatalogoMYGId == null,
            "El vínculo del catálogo BIM copió contenido de otros módulos.");
        MYGEdicionMasivaFiltrosBim.Aplicar(destino, destinoId, new[] { creada.Id }, MYGOperacionFiltrosBim.Reemplazar,
            new[] { Filtro("CATÁLOGO OBRA") }, "PLANTILLA CATÁLOGO", true, permisos, "editor");
        var otra = MYGPartidasBim.CrearCatalogo(destino, destinoId, catalogo, entrada, null, permisos, "editor");
        Exige(otra.Id != creada.Id && otra.Filtros.Single().Valor == "CATÁLOGO OBRA", "No se recuperó configuración de catálogo de la obra.");
        string destinoRuta = Path.Combine(carpeta, "obra-catalogo-bim.sqlite");
        MYGProyectoStorage.Guardar(destinoRuta, destino);
        var destinoReabierto = MYGProyectoStorage.Leer(destinoRuta);
        Exige(destinoReabierto.Presupuestos[0].Items.All(i => i.CatalogoBim?.Id == entrada.Id &&
            i.Filtros.Single().Valor == "CATÁLOGO OBRA"), "SQLite perdió el vínculo BIM con el catálogo.");
        var tercera = MYGPartidasBim.CrearCatalogo(destinoReabierto, destinoId, catalogo, entrada, null, permisos, "editor");
        Exige(tercera.Filtros.Single().Valor == "CATÁLOGO OBRA" && MYGCatalogos.LeerPartida(catalogo, entrada.Id)
            .Partidas.Single().Costos.PrecioDirecto == 123, "Reabrir no recuperó filtros o modificó el catálogo fuente.");
        string bibliotecaRuta = Path.Combine(carpeta, "modeladores-bim.biblioteca.json");
        MYGBibliotecaPartidas.GuardarConfiguraciones(bibliotecaRuta, MYGProyectoStorage.LeerBiblioteca(bibliotecaRuta),
            new[] { new MYGGuardarConfiguracionSolicitud { Partida = tercera, Nombre = "Filtros del catálogo" } });
        string copiaCatalogo = Path.Combine(carpeta, "catalogo-trasladado.sqlite"); File.Copy(catalogo, copiaCatalogo);
        var otraObra = MYGProyectoStorage.Nuevo("OTRA OBRA BIM");
        var nuevaInstancia = MYGPartidasBim.CrearCatalogo(otraObra, otraObra.Presupuestos[0].Id,
            copiaCatalogo, entrada, null, permisos, "editor");
        Exige(MYGBibliotecaPartidas.AplicarUnica(MYGProyectoStorage.LeerBiblioteca(bibliotecaRuta), nuevaInstancia) &&
            nuevaInstancia.Filtros.Single().Valor == "CATÁLOGO OBRA" && nuevaInstancia.Costos.PrecioDirecto == 0,
            "La biblioteca no recuperó los filtros del catálogo trasladado en otra obra.");
        var nativaA = new ItemPresupuestoDelphin { CatalogoBim = new() { Id = "AC-1", RutaSQLite = "D:/CatalogoA.sqlite" } };
        var nativaB = new ItemPresupuestoDelphin { CatalogoBim = new() { Id = "AC-1", RutaSQLite = "D:/CatalogoB.sqlite" } };
        Exige(!MYGBibliotecaPartidas.Coincide(MYGBibliotecaPartidas.Referencia(nativaA), nativaB),
            "Dos catálogos nativos con ID repetible compartieron configuración.");
        entrada.Revision++;
        Rechaza(() => MYGPartidasBim.CrearCatalogo(destino, destinoId, catalogo, entrada, null, permisos, "editor"));
        pasa("Selección de catálogo verifica revisión y conserva vínculo y configuración de obra sin importar ACU, especificaciones ni Excel");
    }
}
