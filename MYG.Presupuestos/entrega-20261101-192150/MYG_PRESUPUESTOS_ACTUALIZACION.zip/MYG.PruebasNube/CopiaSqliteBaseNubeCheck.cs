using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Una base, varias obras: el archivo y su revisión son la unidad de sincronización.</summary>
internal static class CopiaSqliteBaseNubeCheck
{
    private const string Servidor = "https://sqlite-base-multiple.supabase.co";
    private static readonly Guid BaseId = Guid.Parse("77777777-1111-4777-8777-777777777777");
    private static readonly Guid Usuario = Guid.Parse("88888888-2222-4888-8888-888888888888");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        await CompartirArchivoYRevision();
        await ReintentarDesdeOtraObra();
        await ConflictosCompartidos();
        await RechazarIdentidadesAjenas();
        await MigrarSidecarConAckPendiente();
        Console.WriteLine($"OK Base SQLite multiobra: 5 grupos y {comprobaciones} comprobaciones; cantidades reales, cola única, ACK perdido, conflictos compartidos y migración del sidecar. Sin red.");
    }

    private static void Exige(bool condicion, string detalle)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException(detalle); }

    private static async Task CompartirArchivoYRevision()
    {
        using var e = await Escenario.Crear();
        Exige(CopiaSqliteNube.EsBase(e.Ruta), "La copia debe reconocer que su unidad de sincronización es la base completa.");
        var primero = CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!;
        var segundo = CopiaSqliteNube.LeerVinculo(e.Ruta, e.Secundaria);
        Exige(segundo is not null && segundo.ProyectoId == primero.ProyectoId && segundo.Revision == 1,
            "Una obra secundaria debe usar el vínculo SQLite de la misma base, sin publicación independiente.");
        await e.Sincronizar(e.Secundaria);
        Exige(e.Http.Operaciones.Count == 0, "Abrir una obra secundaria sin editar no debe volver a publicar la base.");
        e.CambiarCantidad(e.Secundaria, 25.5m);
        CopiaSqliteNube.MarcarCambio(e.Ruta, e.Secundaria);
        Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!.Pendiente is not null,
            "Editar la obra secundaria debe marcar pendiente también la base vista desde la principal.");
        // Reabrir otra obra del mismo archivo no puede convertir los cambios locales en la nueva huella confirmada.
        CopiaSqliteNube.Vincular(e.Ruta, e.Http.Descriptor, e.Cliente, e.Secundaria);
        await e.Sincronizar(e.Secundaria);
        Exige(e.Http.Operaciones.Count == 1 && e.Http.Revision == 2,
            "Cambiar una cantidad y sincronizar desde la obra secundaria debe guardar una sola revisión SQLite.");
        Exige(e.Cantidad(e.Principal) == 10m && e.Cantidad(e.Secundaria) == 25.5m,
            "Guardar una obra debe conservar la cantidad de la obra vecina en el mismo archivo.");
        var remoto = e.CantidadesRemotas();
        Exige(remoto.Principal == 10m && remoto.Secundaria == 25.5m,
            "La revisión enviada debe contener las dos obras y la cantidad modificada, no sólo el documento principal.");
        VerificarRevisionCompartida(e, 2, pendiente: false);
        Exige(e.ContarEstado("vinculo") == 1 && e.ContarEstado("pendiente") == 0,
            "Las obras de una base deben compartir una fila de estado y una sola cola por archivo.");
        Exige(e.Http.Binarios.Single().AsSpan(0, 16).SequenceEqual("SQLite format 3\0"u8),
            "Sincronizar la base debe transportar SQLite directo y no un paquete JSON o Gzip.");
    }

    private static async Task ReintentarDesdeOtraObra()
    {
        using var e = await Escenario.Crear();
        e.CambiarCantidad(e.Secundaria, 21m);
        e.Http.PerderAck = true;
        bool fallo = false;
        try { await e.Sincronizar(e.Secundaria); }
        catch (NubeException error) { fallo = error.EsErrorDeConexion; }
        Exige(fallo && e.Http.Revision == 2, "Debe perderse el ACK después de guardar la base en el servidor simulado.");
        var pendiente = CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!.Pendiente!;
        Exige(pendiente.Enviada && pendiente.Id != Guid.Empty
            && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Secundaria)!.Pendiente!.Id == pendiente.Id,
            "El ACK perdido debe dejar el mismo UUID durable visible desde ambas obras.");
        CopiaSqliteNube.Vincular(e.Ruta, e.Http.Descriptor, e.Cliente, e.Secundaria);
        Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!.Pendiente!.Id == pendiente.Id
            && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Secundaria)!.Revision == 1,
            "Reabrir el vínculo con ACK pendiente no debe avanzar revisión ni retirar la operación sin confirmación.");
        e.CambiarCantidad(e.Principal, 11m);
        await e.Sincronizar(e.Principal);
        Exige(e.Http.Operaciones.Count == 2 && e.Http.Operaciones[0] == e.Http.Operaciones[1],
            "Reintentar desde otra obra debe conservar UUID, revisión base y SHA-256 de la instantánea original.");
        Exige(e.Cantidad(e.Principal) == 11m && e.Cantidad(e.Secundaria) == 21m,
            "Confirmar el ACK perdido no debe sustituir la edición posterior de otra obra.");
        VerificarRevisionCompartida(e, 2, pendiente: true);
        await e.Sincronizar(e.Secundaria);
        Exige(e.Http.Revision == 3 && e.Http.Operaciones.Last().Id != pendiente.Id,
            "La edición posterior de otra obra debe enviarse con un UUID nuevo sobre la revisión compartida confirmada.");
        var remoto = e.CantidadesRemotas();
        Exige(remoto.Principal == 11m && remoto.Secundaria == 21m,
            "La segunda operación debe conservar ambas cantidades en la base remota.");
        VerificarRevisionCompartida(e, 3, pendiente: false);
    }

    private static async Task ConflictosCompartidos()
    {
        using var e = await Escenario.Crear();
        e.CambiarCantidad(e.Secundaria, 23m);
        e.CambiarRemoto(e.Principal, 12m);
        await e.Sincronizar(e.Secundaria, soloLeer: true);
        Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!.Estado == "conflicto"
            && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Secundaria)!.Estado == "conflicto",
            "Un conflicto del archivo debe ser visible desde todas las obras, no sólo la que inició Recargar.");
        Exige(e.Cantidad(e.Principal) == 10m && e.Cantidad(e.Secundaria) == 23m,
            "Recargar una base en conflicto debe conservar todas sus ediciones locales.");
        CopiaSqliteNube.ResolverMantenerLocal(e.Ruta, e.Principal);
        await e.Sincronizar(e.Secundaria);
        Exige(e.Http.Revision == 3 && !CopiaSqliteNube.TieneConflicto(e.Ruta),
            "Resolver desde otra obra debe actualizar la revisión y desbloquear la única cola de la base.");
        VerificarRevisionCompartida(e, 3, pendiente: false);
        e.CambiarCantidad(e.Principal, 13m);
        e.CambiarRemoto(e.Secundaria, 24m);
        await e.Sincronizar(e.Principal, soloLeer: true);
        await CopiaSqliteNube.ResolverUsarRemotoAsync(e.Cliente, e.Ruta, e.Leer(e.Secundaria));
        Exige(e.Cantidad(e.Principal) == 10m && e.Cantidad(e.Secundaria) == 24m,
            "Usar remoto desde la obra secundaria debe recuperar la revisión completa de ambas obras.");
        Exige(!CopiaSqliteNube.TieneConflicto(e.Ruta)
            && Directory.GetFiles(e.Ruta + ".nube", "respaldo-*.sqlite").Length > 0,
            "Resolver la base debe retirar el conflicto compartido y conservar respaldo del archivo local anterior.");
        VerificarRevisionCompartida(e, 4, pendiente: false);
    }

    private static async Task RechazarIdentidadesAjenas()
    {
        using var e = await Escenario.Crear();
        Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, "obra-inexistente") is null,
            "El vínculo de la base no puede atribuirse a un documento que no existe en su archivo SQLite.");
        bool rechazo = false;
        try { CopiaSqliteNube.Vincular(e.Ruta, e.Http.Descriptor, e.Cliente, "obra-inexistente"); }
        catch (InvalidDataException) { rechazo = true; }
        Exige(rechazo, "Vincular una base debe rechazar un documento que no existe en su SQLite.");
        rechazo = false;
        try
        {
            var individual = e.Http.Descriptor with { Proyecto = e.Http.Descriptor.Proyecto with { Alcance = "obra" } };
            CopiaSqliteNube.Vincular(e.Ruta, individual, e.Cliente, e.Secundaria);
        }
        catch (InvalidDataException) { rechazo = true; }
        Exige(rechazo, "Una publicación individual no debe conceder un vínculo a otras obras del archivo.");
        int peticiones = e.Http.Peticiones;
        var inexistente = MYGProyectoStorage.Nuevo("Documento ajeno no guardado");
        rechazo = false;
        try { await CopiaSqliteNube.EjecutarAsync(e.Cliente, e.Ruta, inexistente); }
        catch (InvalidOperationException) { rechazo = true; }
        catch (InvalidDataException) { rechazo = true; }
        Exige(rechazo && e.Http.Peticiones == peticiones && e.Http.Operaciones.Count == 0,
            "Sincronizar un documento inexistente debe rechazarse antes de enviar bytes o consultar la nube.");
        e.CambiarCantidad(e.Secundaria, 26m);
        CopiaSqliteNube.MarcarCambio(e.Ruta, e.Secundaria);
        rechazo = false;
        try
        {
            var otro = e.Http.Descriptor with { Proyecto = e.Http.Descriptor.Proyecto with { Id = Guid.NewGuid() } };
            CopiaSqliteNube.Vincular(e.Ruta, otro, e.Cliente, e.Secundaria);
        }
        catch (InvalidOperationException) { rechazo = true; }
        catch (InvalidDataException) { rechazo = true; }
        Exige(rechazo && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!.ProyectoId == BaseId
            && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Secundaria)!.Pendiente is not null,
            "Vincular otra obra no puede cambiar la identidad remota ni limpiar cambios pendientes del archivo compartido.");
        await e.Sincronizar(e.Principal);
        Exige(e.Http.Revision == 2 && e.CantidadesRemotas().Secundaria == 26m,
            "El rechazo de un vínculo ajeno debe conservar la capacidad de sincronizar la base original.");
    }

    private static void VerificarRevisionCompartida(Escenario e, long revision, bool pendiente)
    {
        var uno = CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!;
        var dos = CopiaSqliteNube.LeerVinculo(e.Ruta, e.Secundaria)!;
        Exige(uno.Revision == revision && dos.Revision == revision
            && (uno.Pendiente is not null) == pendiente && (dos.Pendiente is not null) == pendiente,
            "Las dos obras deben observar la misma revisión y el mismo estado pendiente de su base.");
    }

    private static async Task MigrarSidecarConAckPendiente()
    {
        using var e = await Escenario.Crear();
        e.CambiarCantidad(e.Secundaria, 27m);
        e.Http.PerderAck = true;
        try { await e.Sincronizar(e.Secundaria); }
        catch (NubeException error) when (error.EsErrorDeConexion) { }
        var pendiente = CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!.Pendiente;
        Exige(pendiente is { Enviada: true } && e.Http.Revision == 2,
            "La migración debe comenzar con un envío durable cuyo ACK se perdió después del commit remoto.");
        // Las versiones anteriores no guardaban alcance en el sidecar. Sus
        // operaciones congeladas siguen siendo válidas y nunca se regeneran.
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = CopiaSqliteNube.RutaEstado(e.Ruta), Pooling = false }.ToString()))
        {
            c.Open(); using var q = c.CreateCommand(); q.CommandText = "ALTER TABLE vinculo DROP COLUMN alcance";
            q.ExecuteNonQuery();
        }
        CopiaSqliteNube.Vincular(e.Ruta, e.Http.Descriptor, e.Cliente, e.Secundaria);
        Exige(CopiaSqliteNube.EsBase(e.Ruta), "La reapertura debe migrar de forma aditiva el vínculo de una base antigua.");
        Exige(CopiaSqliteNube.LeerVinculo(e.Ruta, e.Principal)!.Revision == 1
            && CopiaSqliteNube.LeerVinculo(e.Ruta, e.Secundaria)!.Pendiente!.Id == pendiente!.Id,
            "Promover el sidecar antiguo no debe avanzar revisión ni cambiar el UUID de la operación pendiente.");
        await e.Sincronizar(e.Principal);
        Exige(e.Http.Operaciones.Count == 2 && e.Http.Operaciones[0] == e.Http.Operaciones[1],
            "Tras migrar, reintentar desde otra obra debe usar los bytes, UUID y revisión base previos a la migración.");
        VerificarRevisionCompartida(e, 2, pendiente: false);
        Exige(e.Cantidad(e.Principal) == 10m && e.Cantidad(e.Secundaria) == 27m,
            "La migración y el ACK recuperado deben conservar todas las obras y sus cantidades.");
    }

    private sealed class Escenario : IDisposable
    {
        private readonly string carpeta = Path.Combine(Path.GetTempPath(), "myg-base-multiple-" + Guid.NewGuid().ToString("N"));
        internal string Ruta { get; }
        internal string Principal { get; }
        internal string Secundaria { get; }
        internal Transporte Http { get; }
        internal ClienteSupabase Cliente { get; }

        private Escenario()
        {
            Directory.CreateDirectory(carpeta); Ruta = Path.Combine(carpeta, "base.sqlite");
            var una = Obra("Obra principal", 10m); var otra = Obra("Obra secundaria", 20m);
            Principal = una.Id; Secundaria = otra.Id;
            MYGProyectoStorage.Guardar(Ruta, una); MYGProyectoStorage.Guardar(Ruta, otra);
            string inicial = Path.Combine(carpeta, "inicial.sqlite");
            CopiaSqliteNube.CrearSnapshot(Ruta, inicial);
            Http = new Transporte(Principal, File.ReadAllBytes(inicial));
            Cliente = new ClienteSupabase(Servidor, "sb_publishable_base_multiple_qa", Http);
        }

        internal static async Task<Escenario> Crear()
        {
            var e = new Escenario();
            try
            {
                await e.Cliente.IniciarSesionAsync("base-multiple@myg.example", "clave_sintetica");
                CopiaSqliteNube.Vincular(e.Ruta, e.Http.Descriptor, e.Cliente);
                return e;
            }
            catch { e.Dispose(); throw; }
        }

        private static MYGProyectoDocumento Obra(string nombre, decimal cantidad)
        {
            var obra = MYGProyectoStorage.Nuevo(nombre, "Presupuesto");
            string id = MYGProyectoStorage.NuevoId();
            var partida = new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = "Partida de prueba",
                Unidad = "und", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = 1
            };
            partida.Costos.Cantidad = cantidad; partida.Costos.PrecioDirecto = 5m;
            obra.Presupuestos[0].Items.Add(partida);
            return obra;
        }

        internal MYGProyectoDocumento Leer(string id) => ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(Ruta, id);
        internal decimal Cantidad(string id) => Leer(id).Presupuestos.Single().Items.Single().Costos.Cantidad;
        internal void CambiarCantidad(string id, decimal cantidad) => GuardarCantidad(Ruta, id, cantidad);
        private static void GuardarCantidad(string ruta, string id, decimal cantidad)
        {
            var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, id);
            documento.Presupuestos.Single().Items.Single().Costos.Cantidad = cantidad;
            MYGProyectoStorage.Guardar(ruta, documento);
        }
        internal Task<ResultadoSincronizacion> Sincronizar(string id, bool soloLeer = false)
            => CopiaSqliteNube.EjecutarAsync(Cliente, Ruta, Leer(id), soloLeer);
        internal (decimal Principal, decimal Secundaria) CantidadesRemotas()
        {
            string ruta = Path.Combine(carpeta, "remoto-comprobacion-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.WriteAllBytes(ruta, Http.Actual);
            Exige(MYGBaseDatos.ListarProyectos(ruta).Count == 2, "La base remota debe conservar exactamente sus dos obras.");
            return (MYGBaseDatos.LeerProyecto(ruta, Principal).Presupuestos.Single().Items.Single().Costos.Cantidad,
                MYGBaseDatos.LeerProyecto(ruta, Secundaria).Presupuestos.Single().Items.Single().Costos.Cantidad);
        }
        internal void CambiarRemoto(string id, decimal cantidad)
        {
            string ruta = Path.Combine(carpeta, "remoto-edicion-" + Guid.NewGuid().ToString("N") + ".sqlite");
            File.WriteAllBytes(ruta, Http.Actual); GuardarCantidad(ruta, id, cantidad);
            string portable = Path.Combine(carpeta, "remoto-portable-" + Guid.NewGuid().ToString("N") + ".sqlite");
            CopiaSqliteNube.CrearSnapshot(ruta, portable);
            Http.Avanzar(File.ReadAllBytes(portable));
        }
        internal long ContarEstado(string tabla)
        {
            using var c = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = CopiaSqliteNube.RutaEstado(Ruta), Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
            c.Open(); using var q = c.CreateCommand(); q.CommandText = "SELECT count(*) FROM " + tabla;
            return (long)q.ExecuteScalar()!;
        }
        public void Dispose()
        { Cliente.Dispose(); SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private sealed class Transporte(string documentoPrincipal, byte[] inicial) : HttpMessageHandler
    {
        internal byte[] Actual { get; private set; } = inicial;
        internal long Revision { get; private set; } = 1;
        internal bool PerderAck { get; set; }
        internal int Peticiones { get; private set; }
        internal List<byte[]> Binarios { get; } = new();
        internal List<(Guid Id, long Revision, string Hash)> Operaciones { get; } = new();
        private readonly Dictionary<Guid, (long Revision, ArchivoSqliteNube Archivo)> acks = new();
        private readonly Dictionary<string, byte[]> objetos = new();
        private ArchivoSqliteNube Archivo => Datos(Actual);
        internal ProyectoSqliteNube Descriptor => new(new ProyectoNube(BaseId, "BASE-001", "Base de dos obras",
            "editor", Revision, "base", default) { PermisosModulos = new MYGPermisosModulos() }, documentoPrincipal, Archivo);
        internal void Avanzar(byte[] datos) { Actual = datos; Revision++; }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            Peticiones++;
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token") return Json(new
            { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600, user = new { id = Usuario } });
            if (ruta == "/rest/v1/rpc/myg_nube_sqlite_capacidades")
                return Json(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
            if (ruta is "/rest/v1/rpc/myg_nube_sqlite_consultar" or "/rest/v1/rpc/myg_nube_sqlite_abrir")
            {
                using var entrada = JsonDocument.Parse(await solicitud.Content!.ReadAsByteArrayAsync(ct));
                Exige(entrada.RootElement.GetProperty("p_id").GetGuid() == BaseId,
                    "Todas las obras deben consultar el UUID de la base, sin crear otra identidad remota.");
                return Json(new { id = BaseId, codigo = "BASE-001", nombre = "Base de dos obras", rol = "editor",
                    revision = Revision, alcance = "base", documento_id = documentoPrincipal,
                    permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true }, archivo_sqlite = ArchivoJson(Archivo) });
            }
            const string prefijo = "/storage/v1/object/myg-nube-sqlite/";
            if (ruta.StartsWith(prefijo, StringComparison.Ordinal))
            {
                string objeto = ruta[prefijo.Length..];
                if (solicitud.Method == HttpMethod.Post)
                {
                    byte[] bytes = await solicitud.Content!.ReadAsByteArrayAsync(ct);
                    Binarios.Add(bytes); objetos[objeto] = bytes;
                    return Json(new { Key = objeto }, HttpStatusCode.Created);
                }
                return new HttpResponseMessage(HttpStatusCode.OK)
                { Content = new ByteArrayContent(objeto == Archivo.Ruta ? Actual : objetos[objeto]) };
            }
            if (ruta == "/rest/v1/rpc/myg_nube_sqlite_guardar")
            {
                using var entrada = JsonDocument.Parse(await solicitud.Content!.ReadAsByteArrayAsync(ct));
                var r = entrada.RootElement;
                Exige(r.GetProperty("p_id").GetGuid() == BaseId, "Toda sincronización debe guardar el UUID compartido de la base.");
                Guid id = r.GetProperty("p_operacion").GetGuid(); long revision = r.GetProperty("p_revision").GetInt64();
                var archivo = new ArchivoSqliteNube(r.GetProperty("p_ruta").GetString()!, r.GetProperty("p_sha256").GetString()!, r.GetProperty("p_bytes").GetInt64());
                Operaciones.Add((id, revision, archivo.Sha256));
                if (acks.TryGetValue(id, out var anterior))
                    return Json(new { estado = "aplicada", revision = anterior.Revision, operacion_id = id, archivo_sqlite = ArchivoJson(anterior.Archivo) });
                if (revision != Revision)
                    return Json(new { estado = "conflicto", revision = Revision, operacion_id = id, archivo_sqlite = ArchivoJson(Archivo) });
                Actual = objetos[archivo.Ruta]; Revision++; acks[id] = (Revision, archivo);
                if (PerderAck) { PerderAck = false; throw new HttpRequestException("ACK perdido después de guardar la base de prueba"); }
                return Json(new { estado = "aplicada", revision = Revision, operacion_id = id, archivo_sqlite = ArchivoJson(archivo) });
            }
            throw new InvalidOperationException("Endpoint inesperado en base multiobra: " + ruta);
        }

        private static ArchivoSqliteNube Datos(byte[] bytes)
        {
            string hash = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
            return new(Usuario.ToString("D") + "/" + BaseId.ToString("N") + "/" + hash + ".sqlite", hash, bytes.Length);
        }
        private static object ArchivoJson(ArchivoSqliteNube archivo)
            => new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes };
        private static HttpResponseMessage Json(object valor, HttpStatusCode codigo = HttpStatusCode.OK)
            => new(codigo) { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
