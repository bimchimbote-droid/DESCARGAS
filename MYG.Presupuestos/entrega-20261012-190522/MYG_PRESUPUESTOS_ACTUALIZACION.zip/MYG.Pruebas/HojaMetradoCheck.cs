using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

static class HojaMetradoCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static void Rechaza(Action accion, string mensaje)
    { try { accion(); } catch (InvalidDataException) { return; } throw new Exception(mensaje); }
    public static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var plantilla = MYGHojaMetrado.Crear();
        Exige(new MYGCeldaHoja().Fuente == "Arial Narrow" && plantilla.Celdas.Values.All(celda => celda.Fuente == "Arial Narrow") &&
            MYGEdicionHoja.Celda(plantilla, "J20").Fuente == "Arial Narrow",
            "Las celdas nuevas, la plantilla y las celdas vacías deben usar Arial Narrow por defecto.");
        var sinFuente = JsonSerializer.Deserialize<MYGCeldaHoja>("{\"Contenido\":\"Metrado anterior\"}");
        var fuenteExplicita = JsonSerializer.Deserialize<MYGCeldaHoja>("{\"Contenido\":\"Fuente propia\",\"Fuente\":\"Calibri Light\"}");
        Exige(sinFuente.Fuente == "Arial Narrow" && fuenteExplicita.Fuente == "Calibri Light" &&
            MYGProyectoStorage.Copia(fuenteExplicita).Fuente == "Calibri Light",
            "Los datos sin fuente deben recibir Arial Narrow sin sustituir una fuente guardada explícitamente.");
        pasa("Metrado usa Arial Narrow en celdas nuevas y datos sin fuente, conservando las fuentes explícitas");

        VerificarCabeceraCombinada(carpeta, pasa);

        string[] rectangulo = Enumerable.Range(4, 3)
            .SelectMany(fila => Enumerable.Range(1, 3).Select(columna => MYGHojaCalculo.Columna(columna) + fila))
            .Reverse().Concat(new[] { "$a$4", "c6" }).ToArray();
        Exige(MYGHojaCalculo.ReferenciaSeleccion(rectangulo, "B5") == "A4:C6" &&
            MYGHojaCalculo.ReferenciaSeleccion(new[] { "$b$7", "B7" }, "A1") == "B7" &&
            MYGHojaCalculo.ReferenciaSeleccion(Array.Empty<string>(), "$d$8") == "D8" &&
            MYGHojaCalculo.ReferenciaSeleccion(Array.Empty<string>()) == "",
            "La referencia seleccionada debe distinguir celda y rango completo, normalizar duplicados y usar la activa cuando no hay selección.");
        Exige(MYGHojaCalculo.ReferenciaSeleccion(new[] { "C8", "B4", "A4", "A6" }, "C8") == "A4:B4,A6,C8" &&
            MYGHojaCalculo.ReferenciaSeleccion(new[] { "C6", "A4" }, "A4") == "A4,C6",
            "La selección discontinua debe mostrar sus tramos reales sin incluir celdas no seleccionadas.");
        pasa("La dirección distingue una celda, un rango rectangular y los tramos de una selección discontinua");

        var alineaciones = MYGHojaMetrado.Crear();
        alineaciones.Poner("A3", "Descripción"); alineaciones.Poner("B3", "2");
        Exige(MYGEdicionHoja.AlineacionCelda(alineaciones.Celdas["A3"], "A3") == "Izquierda" &&
            MYGEdicionHoja.AlineacionCelda(alineaciones.Celdas["B3"], "B3") == "Centro" &&
            MYGEdicionHoja.AlineacionCelda(null, "D25") == "Centro" &&
            MYGEdicionHoja.AlineacionCelda(new MYGCeldaHoja { AlineacionHorizontal = "Izquierda" }, "G3") == "Centro",
            "La hoja nueva, las celdas vacías y los datos anteriores deben centrar los datos salvo la descripción.");
        alineaciones.Celdas["B3"].AlineacionPersonalizada = true;
        alineaciones.Celdas["B3"].AlineacionHorizontal = "Izquierda";
        Exige(MYGEdicionHoja.AlineacionCelda(MYGProyectoStorage.Copia(alineaciones).Celdas["B3"], "B3") == "Izquierda",
            "Guardar/copiar el documento debe conservar la alineación manual.");
        string rutaAlineaciones = Path.Combine(carpeta, "Metrado alineaciones.xlsx");
        MYGExcelPresupuestos.Guardar(rutaAlineaciones, new[] { alineaciones });
        var copiaAlineaciones = MYGExcelPresupuestos.Importar(rutaAlineaciones, alineaciones.Nombre, alineaciones.CeldaTotal);
        Exige(MYGEdicionHoja.AlineacionCelda(copiaAlineaciones.Celdas["A3"], "A3") == "Izquierda" &&
            MYGEdicionHoja.AlineacionCelda(copiaAlineaciones.Celdas["B3"], "B3") == "Izquierda" &&
            MYGEdicionHoja.AlineacionCelda(copiaAlineaciones.Celdas["G3"], "G3") == "Centro",
            "El intercambio XLSX debe conservar el centrado automático y la alineación explícita elegida después.");
        var informe = MYGExcelPresupuestos.Tabla("Presupuesto", new[] { "Ítem", "Descripción" }, new[] { new object[] { "01", "Informe" } });
        Exige(MYGEdicionHoja.AlineacionCelda(informe.Celdas["B2"], "B2") == "Izquierda",
            "Centrar la hoja de metrado no debe cambiar la disposición de los informes de presupuesto.");
        pasa("Metrado centra datos salvo descripción y conserva alineación personalizada en JSON y XLSX");

        var h = MYGHojaMetrado.Crear(); h.Poner("B3", "2"); h.Poner("C3", "3"); h.Poner("D3", "4");
        var c = MYGEdicionHoja.Celda(h, "A3"); c.Contenido = "Zapata"; c.Fuente = "Arial"; c.TamanoFuente = 12m;
        c.Negrita = c.Cursiva = c.Subrayado = c.Tachado = c.Bordes = c.AjustarTexto = true;
        c.ColorTexto = "123456"; c.ColorFondo = "FEDCBA"; c.AlineacionHorizontal = "Centro"; c.AlineacionVertical = "Abajo";
        var cantidad = MYGEdicionHoja.Celda(h, "B3"); cantidad.FormatoNumero = "0.00";
        h.Zoom = 125; h.LineasDivision = false; h.Encabezados = false; h.ColumnasInmovilizadas = 1;
        h.OrientacionPagina = "Horizontal"; h.TamanoPapel = "A3"; h.AreaImpresion = "A1:H16";
        h.ImprimirLineasDivision = h.ImprimirEncabezados = h.RepetirTitulos = true;
        h.MargenIzquierdo = 0.25m; h.MargenSuperior = 0.75m; h.FilasOcultas.Add(5); h.AltosFilas[5] = 30;
        cantidad.TipoValidacion = "Entero"; cantidad.Minimo = 0; cantidad.Maximo = 10;
        var lista = MYGEdicionHoja.Celda(h, "H3"); lista.TipoValidacion = "Lista"; lista.ListaValores.AddRange(new[] { "P-01", "P-02" }); lista.Contenido = "P-01";
        MYGHojaCalculo.Validar(h);
        var json = MYGProyectoStorage.Copia(h);
        Exige(json.Celdas["A3"].Subrayado && json.Celdas["A3"].TamanoFuente == 12 && json.FilasOcultas.SequenceEqual(new[] { 5 }) && json.RepetirTitulos,
            "La copia persistente perdió estilos y configuración de página.");
        Exige(new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 24 && new MYGHojaCalculo(h).Mostrar("B3") == 2m.ToString("0.00", CultureInfo.CurrentCulture),
            "El formato visual alteró el metrado o no se aplicó a un número.");
        var datos = new MYGDatosPartida(); Exige(!MYGMotorPresupuestos.TieneDatosPropios(datos), "La plantilla de hoja genera datos propios falsos.");
        datos.Hoja.Celdas["A2"].Subrayado = true; Exige(MYGMotorPresupuestos.TieneDatosPropios(datos), "Una biblioteca perdería formato sin datos nuevos.");
        datos = new(); datos.Hoja.Zoom = 125; Exige(MYGMotorPresupuestos.TieneDatosPropios(datos), "Una biblioteca perdería la vista personalizada.");
        pasa("Metrado XLS persiste fuente, estilos, formato numérico, vista y página sin alterar cantidades; biblioteca detecta cambios de formato");

        Exige(MYGEdicionHoja.TrasladarFormula("=SUM(A3:$B$5)+C$2+$D4", 2, 1) == "=SUM(B5:$B$5)+D$2+$D6", "Rellenar no respetó referencias absolutas y mixtas.");
        Exige(MYGEdicionHoja.TrasladarFormula("=IF(A3>0,LOG10(A3),\"A3\")", 1, 0) == "=IF(A4>0,LOG10(A4),\"A3\")", "Rellenar cambió texto literal o nombre de función.");
        Exige(MYGEdicionHoja.TrasladarFormula("=A1+$B$2", -1, 0) == "=#REF!+$B$2", "Referencia trasladada fuera de hoja no produce #REF!.");
        MYGEdicionHoja.InsertarFilas(h, 3, 2);
        Exige(h.CeldaTotal == "G18" && h.Celdas["G18"].Contenido == "=SUM(G5:G17)" && h.Celdas["A5"].Fuente == "Arial" &&
            h.Celdas["G5"].Contenido == "=PRODUCT(B5:F5)*IF(COUNT(B5:F5)=0,0,1)" && new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 24 && h.AreaImpresion == "A1:H18" && h.FilasOcultas.Contains(7),
            "Insertar filas perdió total, referencias, estilos o metadatos de impresión.");
        MYGEdicionHoja.InsertarColumnas(h, 2);
        Exige(h.CeldaTotal == "H18" && h.Celdas["H5"].Contenido.Contains("C5:G5") && h.RangosCombinados.Contains("A1:D1") && h.AnchosColumnas[3] == 58,
            "Insertar columnas no desplazó las referencias y combinaciones.");
        MYGEdicionHoja.EliminarColumnas(h, 2); MYGEdicionHoja.EliminarFilas(h, 3, 2);
        Exige(h.CeldaTotal == "G16" && new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 24 && h.RangosCombinados.Contains("A1:C1"), "La inserción/eliminación no conserva el metrado.");
        string antes = JsonSerializer.Serialize(h);
        Rechaza(() => MYGEdicionHoja.EliminarFilas(h, 16), "Se eliminó el metrado total.");
        Rechaza(() => MYGEdicionHoja.InsertarFilas(h, 1, 10000), "Se admitió una hoja excesiva.");
        Exige(JsonSerializer.Serialize(h) == antes, "Una operación estructural rechazada modificó la hoja.");
        var rangos = new MYGHojaMetrado { CeldaTotal = "G10", Filas = 20, Columnas = 8, FilasInmovilizadas = 0 };
        rangos.Poner("G10", "=SUM($A$3:A5)+A3"); rangos.Poner("A3", "1"); rangos.Poner("A4", "2"); rangos.Poner("A5", "3");
        MYGEdicionHoja.EliminarFilas(rangos, 3);
        Exige(rangos.Celdas["G9"].Contenido == "=SUM($A$3:A4)+#REF!" && new MYGHojaCalculo(rangos).Mostrar("G9") == "#ERROR",
            "Eliminar no contrajo un rango o dejó una referencia directa apuntando a otros datos.");
        var absolutas = new MYGHojaMetrado { CeldaTotal = "G10", Filas = 20, Columnas = 8 };
        absolutas.Poner("G10", "=$A$3+A$3+$A3"); MYGEdicionHoja.InsertarFilas(absolutas, 3);
        Exige(absolutas.Celdas["G11"].Contenido == "=$A$4+A$4+$A4", "La inserción estructural no ajustó referencias absolutas.");
        pasa("Insertar/eliminar filas y columnas ajusta fórmulas absolutas, rangos, total, combinaciones y dimensiones con atomicidad");

        var ordenar = new MYGHojaMetrado { CeldaTotal = "G10", Filas = 20, Columnas = 8 };
        ordenar.Poner("B1", "10"); ordenar.Poner("A3", "Zapata"); ordenar.Poner("B3", "3"); ordenar.Poner("C3", "=B3*$B$1");
        ordenar.Poner("A4", "Muro"); ordenar.Poner("B4", "1"); ordenar.Poner("C4", "=B4*$B$1"); ordenar.Celdas["A4"].ColorTexto = "FF0000";
        ordenar.Poner("A5", "Viga"); ordenar.Poner("B5", "2"); ordenar.Poner("C5", "=B5*$B$1");
        MYGEdicionHoja.Ordenar(ordenar, "A3:C5", 2);
        Exige(ordenar.Celdas["A3"].Contenido == "Muro" && ordenar.Celdas["A3"].ColorTexto == "FF0000" && ordenar.Celdas["C3"].Contenido == "=B3*$B$1" &&
            new MYGHojaCalculo(ordenar).Numero("C3") == 10 && ordenar.Celdas["A5"].Contenido == "Zapata", "Ordenar separó las fórmulas/estilos de sus filas.");
        MYGEdicionHoja.Ordenar(ordenar, "A3:C5", 2, true); Exige(ordenar.Celdas["A3"].Contenido == "Zapata", "Orden descendente incorrecto.");
        MYGEdicionHoja.Combinar(ordenar, "D3:F3");
        Rechaza(() => MYGEdicionHoja.Combinar(ordenar, "E3:G3"), "Se superpusieron combinaciones.");
        MYGEdicionHoja.Separar(ordenar, "E3"); Exige(ordenar.RangosCombinados.Count == 0, "Separar no detectó combinación dentro de la selección.");
        Rechaza(() => MYGEdicionHoja.Combinar(ordenar, "A3:B3"), "Combinar perdió un valor secundario.");
        pasa("Ordenar conserva filas, referencias relativas y estilos; combinar evita solapamientos y pérdida de contenido");

        MYGEdicionHoja.ValidarEntrada(h, "B3", "=2+3"); MYGEdicionHoja.ValidarEntrada(h, "B3", "");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "B3", "1.5"), "Validación entera admitió decimal.");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "B3", "11"), "Validación admitió número fuera de límites.");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "B3", "=B3+1"), "Validación admitió fórmula circular.");
        Rechaza(() => MYGEdicionHoja.ValidarEntrada(h, "H3", "P-03"), "Validación admitió valor ajeno a lista.");
        MYGEdicionHoja.ValidarEntrada(h, "A4", "=FUNCION_NO_SOPORTADA(A1)");
        h.Poner("A4", "=FUNCION_NO_SOPORTADA(A1)"); Exige(new MYGHojaCalculo(h).Mostrar("A4") == "#ERROR", "No se puede conservar una fórmula no soportada como error visible.");
        pasa("Validación numérica/entera/lista aplica límites y evalúa fórmulas sin impedir el guardado de errores en celdas sin regla");

        string ruta = Path.Combine(carpeta, "Metrado estilos.xlsx"); MYGExcelPresupuestos.Guardar(ruta, new[] { h });
        var excel = MYGExcelPresupuestos.Importar(ruta, h.Nombre, h.CeldaTotal); var estilo = excel.Celdas["A3"];
        Exige(estilo.Negrita && estilo.Cursiva && estilo.Subrayado && estilo.Tachado && estilo.Bordes && estilo.AjustarTexto && estilo.Fuente == "Arial" && estilo.TamanoFuente == 12 &&
            estilo.ColorTexto == "123456" && estilo.ColorFondo == "FEDCBA" && estilo.AlineacionHorizontal == "Centro" && estilo.AlineacionVertical == "Abajo",
            "Excel perdió formato de celda durante exportación/importación.");
        Exige(excel.Zoom == 125 && !excel.LineasDivision && !excel.Encabezados && excel.ColumnasInmovilizadas == 1 && excel.OrientacionPagina == "Horizontal" && excel.TamanoPapel == "A3" &&
            excel.AreaImpresion == "A1:H16" && excel.RepetirTitulos && excel.MargenIzquierdo == 0.25m && excel.MargenSuperior == 0.75m && excel.ImprimirEncabezados && excel.ImprimirLineasDivision &&
            excel.AnchosColumnas[1] == 288 && excel.AltosFilas[5] == 30 && excel.FilasOcultas.Contains(5) && excel.RangosCombinados.Contains("D1:F1"),
            "Excel perdió vista, dimensiones, impresión o combinaciones.");
        Exige(excel.Celdas["B3"].TipoValidacion == "Entero" && excel.Celdas["B3"].Minimo == 0 && excel.Celdas["B3"].Maximo == 10 &&
            excel.Celdas["H3"].ListaValores.SequenceEqual(new[] { "P-01", "P-02" }) && new MYGHojaCalculo(excel).Numero(excel.CeldaTotal) == 24,
            "Excel perdió reglas de validación o valores/fórmulas.");
        using (var z = ZipFile.OpenRead(ruta))
        {
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            using var flujo = z.GetEntry("xl/worksheets/sheet1.xml").Open(); var hojaXml = XDocument.Load(flujo);
            Exige(hojaXml.Root.Elements().Select(x => x.Name.LocalName).SequenceEqual(new[] { "sheetViews", "sheetFormatPr", "cols", "sheetData", "mergeCells", "dataValidations", "printOptions", "pageMargins", "pageSetup" }),
                "La exportación incumple el orden de partes de una hoja OOXML.");
        }
        pasa("Excel exporta e importa formatos, reglas, combinaciones, zoom, inmovilización, tamaño de filas/columnas y configuración de impresión");

        Exige(excel.Celdas["B3"].Fuente == "Arial Narrow" && excel.Celdas["A3"].Fuente == "Arial",
            "El intercambio XLSX debe conservar Arial Narrow por defecto y las fuentes personalizadas.");
        string rutaSinNombreFuente = Path.Combine(carpeta, "Metrado fuente omitida.xlsx");
        File.Copy(ruta, rutaSinNombreFuente, true);
        using (var z = ZipFile.Open(rutaSinNombreFuente, ZipArchiveMode.Update))
        {
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            var entrada = z.GetEntry("xl/styles.xml");
            XDocument estilos;
            using (var flujo = entrada.Open()) estilos = XDocument.Load(flujo);
            var normal = estilos.Root.Element(s + "fonts").Elements(s + "font").First();
            Exige((string)normal.Element(s + "name")?.Attribute("val") == "Arial Narrow",
                "El estilo normal del libro XLSX debe declarar Arial Narrow.");
            normal.Element(s + "name").Remove();
            entrada.Delete();
            using var salida = z.CreateEntry("xl/styles.xml").Open();
            estilos.Save(salida);
        }
        var excelSinNombre = MYGExcelPresupuestos.Importar(rutaSinNombreFuente, h.Nombre, h.CeldaTotal);
        Exige(excelSinNombre.Celdas["B3"].Fuente == "Arial Narrow" && excelSinNombre.Celdas["A3"].Fuente == "Arial",
            "Importar un estilo XLSX sin nombre de fuente debe usar Arial Narrow y preservar otras fuentes explícitas.");
        pasa("XLSX declara Arial Narrow como fuente normal y la usa al importar estilos sin fuente sin cambiar fuentes explícitas");
    }

    private static void VerificarCabeceraCombinada(string carpeta, Action<string> pasa)
    {
        string[] grupos = { "A1:C1", "D1:F1", "G1:H1" };
        var nueva = MYGHojaMetrado.Crear();
        Exige(nueva.RangosCombinados.SequenceEqual(grupos) && nueva.Celdas["A1"].Contenido == "Datos" &&
            nueva.Celdas["D1"].Contenido == "Dimensiones" && nueva.Celdas["G1"].Contenido == "Total",
            "La cabecera de metrado debe combinar Datos en A1:C1, Dimensiones en D1:F1 y Total en G1:H1.");

        var anterior = MYGHojaMetrado.Crear();
        anterior.RangosCombinados.Clear();
        anterior.Poner("A3", "Columna C-01"); anterior.Poner("B3", "2"); anterior.Poner("C3", "3");
        anterior.Celdas["A3"].Fuente = "Arial"; anterior.Celdas["A3"].ColorFondo = "FEDCBA";
        anterior.RangosCombinados.Add("J20:K20");
        string datos = JsonSerializer.Serialize(anterior.Celdas);
        decimal total = new MYGHojaCalculo(anterior).Numero(anterior.CeldaTotal);
        Exige(MYGEdicionHoja.RepararCabeceraMetrado(anterior),
            "Una plantilla antigua sin grupos debe reparar sus combinaciones.");
        MYGHojaCalculo.Validar(anterior);
        Exige(grupos.All(anterior.RangosCombinados.Contains) && anterior.RangosCombinados.Contains("J20:K20") &&
            JsonSerializer.Serialize(anterior.Celdas) == datos && new MYGHojaCalculo(anterior).Numero(anterior.CeldaTotal) == total,
            "Restaurar combinaciones de una hoja anterior debe conservar contenido, fórmulas, estilos y combinaciones ajenas a la cabecera.");
        string reparada = JsonSerializer.Serialize(anterior);
        Exige(!MYGEdicionHoja.RepararCabeceraMetrado(anterior) && JsonSerializer.Serialize(anterior) == reparada,
            "La reparación repetida de cabecera no debe duplicar rangos ni modificar una hoja ya corregida.");

        var personalizada = MYGHojaMetrado.Crear(); personalizada.RangosCombinados.Clear();
        personalizada.Celdas["A1"].Contenido = "Hoja personalizada";
        string antes = JsonSerializer.Serialize(personalizada);
        Exige(!MYGEdicionHoja.RepararCabeceraMetrado(personalizada) && JsonSerializer.Serialize(personalizada) == antes,
            "Una hoja con cabecera personalizada debe conservar sus celdas y combinaciones sin imponer la plantilla de metrado.");

        var conDatos = MYGHojaMetrado.Crear(); conDatos.RangosCombinados.Clear(); conDatos.Poner("B1", "Dato que se conserva");
        string antesDatos = JsonSerializer.Serialize(conDatos);
        Exige(!MYGEdicionHoja.RepararCabeceraMetrado(conDatos) && JsonSerializer.Serialize(conDatos) == antesDatos &&
            conDatos.Celdas["B1"].Contenido == "Dato que se conserva" &&
            !conDatos.RangosCombinados.Any(r => MYGEdicionHoja.Direcciones(conDatos, r).Contains("B1")),
            "La reparación no debe ocultar ni perder un dato secundario al combinar una cabecera antigua.");
        var solapada = MYGHojaMetrado.Crear(); solapada.RangosCombinados.Clear(); solapada.RangosCombinados.Add("B1:D1");
        string antesSolapada = JsonSerializer.Serialize(solapada);
        Exige(!MYGEdicionHoja.RepararCabeceraMetrado(solapada) && JsonSerializer.Serialize(solapada) == antesSolapada,
            "Una combinación que cruza grupos debe rechazar la reparación de forma atómica.");
        MYGHojaCalculo.Validar(solapada);
        Exige(solapada.RangosCombinados.Contains("B1:D1"),
            "La reparación no debe sustituir ni superponer una combinación personalizada que cruza los grupos de cabecera.");

        var parcial = MYGHojaMetrado.Crear(); parcial.RangosCombinados.Remove("A1:C1"); parcial.RangosCombinados.Add("A1:B1");
        Exige(MYGEdicionHoja.RepararCabeceraMetrado(parcial) && grupos.All(parcial.RangosCombinados.Contains) &&
            parcial.RangosCombinados.Count == grupos.Length,
            "Un grupo antiguo más corto debe restaurar el rango completo sin duplicar combinaciones.");

        string ruta = Path.Combine(carpeta, "Metrado cabeceras combinadas.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { anterior });
        var copia = MYGExcelPresupuestos.Importar(ruta, anterior.Nombre, anterior.CeldaTotal);
        Exige(grupos.All(copia.RangosCombinados.Contains) && copia.RangosCombinados.Contains("J20:K20") &&
            copia.Celdas["A1"].Contenido == "Datos" && copia.Celdas["D1"].Contenido == "Dimensiones" &&
            copia.Celdas["G1"].Contenido == "Total" && new MYGHojaCalculo(copia).Numero(copia.CeldaTotal) == total,
            "Guardar y reabrir XLSX debe conservar los tres grupos de cabecera y el metrado calculado.");
        pasa("Cabecera de metrado combina A1:C1, D1:F1 y G1:H1, repara hojas anteriores sin perder datos y conserva XLSX");
    }
}
