using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly TabControl cintaHoja = new() { Dock = DockStyle.Fill, Name = "metrado_cinta" };
    private Panel contenedorCintaHoja;
    private bool sincronizandoCintaHoja;
    private bool ajustandoEncabezadosCintaHoja;

    // La misma cinta y los mismos controles de tema que el editor de especificaciones.
    // Los comandos se resuelven en el editor para conservar su transacción e historial.
    private Control PrepararCintaHoja()
    {
        contenedorCintaHoja = new Panel { Dock = DockStyle.Top, Height = 145, Name = "metrado_cinta_contenedor" };
        MYGEspecificacionesCinta.Preparar(cintaHoja);
        // El dibujador del tema reserva 20 píxeles para el texto. La cinta de
        // metrados necesita margen nativo suficiente y filas adicionales cuando
        // su panel se estrecha, conservando siempre los nombres completos.
        cintaHoja.Multiline = true;
        cintaHoja.SizeMode = TabSizeMode.Normal;
        cintaHoja.Font = new Font("Segoe UI", 9f);
        cintaHoja.Disposed += (_, _) => cintaHoja.Font.Dispose();
        contenedorCintaHoja.Controls.Add(cintaHoja);
        PrepararArchivoHoja();
        PrepararInicioHoja();
        PrepararCeldasHoja();
        PrepararPaginaHoja();
        PrepararFormulasHoja();
        PrepararInsertarHoja();
        PrepararDatosHoja();
        PrepararRevisarHoja();
        PrepararVistaHoja();
        cintaHoja.SelectedIndex = 1;
        cintaHoja.SelectedIndexChanged += (_, _) => AjustarEncabezadosCintaHoja();
        cintaHoja.SizeChanged += (_, _) => AjustarEncabezadosCintaHoja();
        cintaHoja.HandleCreated += (_, _) => AjustarEncabezadosCintaHoja();
        cintaHoja.FontChanged += (_, _) => AjustarEncabezadosCintaHoja();
        cintaHoja.DpiChangedAfterParent += (_, _) => AjustarEncabezadosCintaHoja();

        var rapido = new Panel { Dock = DockStyle.Right, Width = 31, Name = "metrado_accesos_rapidos" };
        var guardar = MYGEspecificacionesCinta.Fila(rapido, 2, BotonCintaHoja("Guardar", "guardar", "guardar"));
        guardar.Width = 28;
        guardar.Height = 27;
        contenedorCintaHoja.Controls.Add(rapido);
        rapido.BringToFront();
        AplicarTemaCintaHoja();
        return contenedorCintaHoja;
    }

    private void AjustarEncabezadosCintaHoja()
    {
        if (contenedorCintaHoja == null || ajustandoEncabezadosCintaHoja || cintaHoja.IsDisposed) return;
        ajustandoEncabezadosCintaHoja = true;
        try
        {
            float escala = cintaHoja.DeviceDpi / 96f;
            var margen = new Point((int)Math.Ceiling(20 * escala), (int)Math.Ceiling(5 * escala));
            if (cintaHoja.Padding != margen) cintaHoja.Padding = margen;
            AjustarAltoCintaHoja();
        }
        finally { ajustandoEncabezadosCintaHoja = false; }
    }

    private void AjustarAltoCintaHoja()
    {
        if (contenedorCintaHoja == null || cintaHoja.SelectedTab?.Controls.Count != 1 ||
            cintaHoja.SelectedTab.Controls[0] is not FlowLayoutPanel grupos) return;
        // El desplazamiento horizontal conserva visibles los grupos en paneles estrechos.
        // Reservar también las filas reales de pestañas impide que cualquiera
        // de las dos barras tape los comandos o los títulos de los grupos.
        int ancho = grupos.Controls.Cast<Control>().Sum(c => c.Width + c.Margin.Horizontal);
        int alto = (int)Math.Ceiling(145f * cintaHoja.DeviceDpi / 96f);
        if (cintaHoja.IsHandleCreated)
        {
            Rectangle pagina = cintaHoja.DisplayRectangle;
            int altoGrupos = grupos.Controls.Cast<Control>().Select(c => c.Height + c.Margin.Vertical).DefaultIfEmpty(0).Max();
            alto = Math.Max(alto, pagina.Top + altoGrupos + cintaHoja.ClientSize.Height - pagina.Bottom);
        }
        if (ancho > grupos.ClientSize.Width) alto += SystemInformation.HorizontalScrollBarHeight;
        if (contenedorCintaHoja.Height != alto) contenedorCintaHoja.Height = alto;
    }

    private void AplicarTemaCintaHoja()
    {
        if (contenedorCintaHoja == null) return;
        MYGEspecificacionesCinta.AplicarTema(contenedorCintaHoja);
        MYGEspecificacionesCinta.AplicarTema(cintaHoja);
        AjustarEncabezadosCintaHoja();
    }

    private void SincronizarCintaHoja(MYGHojaMetrado libro, MYGCeldaHoja celda)
    {
        if (contenedorCintaHoja == null || libro == null || sincronizandoCintaHoja) return;
        sincronizandoCintaHoja = true;
        try
        {
            celda ??= new MYGCeldaHoja();
            foreach (var control in ControlesCintaHoja(contenedorCintaHoja))
                if (control is CheckBox check)
                    check.Checked = check.Name switch
                    {
                        "metrado_lineas_division" => libro.LineasDivision,
                        "metrado_encabezados" => libro.Encabezados,
                        "metrado_imprimir_lineas_division" => libro.ImprimirLineasDivision,
                        "metrado_imprimir_encabezados" => libro.ImprimirEncabezados,
                        _ => check.Checked
                    };
            foreach (var item in ItemsCintaHoja(contenedorCintaHoja))
            {
                if (item is ToolStripComboBox combo)
                {
                    if (combo.Name == "metrado_fuente")
                    {
                        if (!combo.Items.Contains(celda.Fuente)) combo.Items.Add(celda.Fuente);
                        combo.SelectedItem = celda.Fuente;
                    }
                    else if (combo.Name == "metrado_tamano") combo.Text = celda.TamanoFuente.ToString("0.##", CultureInfo.CurrentCulture);
                    else if (combo.Name == "metrado_formato_numero")
                    {
                        combo.SelectedItem = celda.FormatoNumero switch { "0.00" => "Número", "S/ #,##0.00" => "Moneda", "#,##0.00" => "Contabilidad", "0%" or "0.00%" => "Porcentaje", "0" => "Entero", _ => celda.FormatoNumero.Contains('0') ? "Número" : "General" };
                        combo.ToolTipText = "Formato actual: " + celda.FormatoNumero;
                    }
                }
                if (item is ToolStripButton boton)
                    boton.Checked = boton.Name switch
                    {
                        "metrado_negrita" => celda.Negrita,
                        "metrado_cursiva" => celda.Cursiva,
                        "metrado_subrayado" => celda.Subrayado,
                        "metrado_tachado" => celda.Tachado,
                        "metrado_bordes" => celda.Bordes,
                        "metrado_ajustar_texto" => celda.AjustarTexto,
                        "metrado_alineacion_izquierda" => celda.AlineacionHorizontal == "Izquierda",
                        "metrado_alineacion_centro" => celda.AlineacionHorizontal == "Centro",
                        "metrado_alineacion_derecha" => celda.AlineacionHorizontal == "Derecha",
                        "metrado_vertical_arriba" => celda.AlineacionVertical == "Arriba",
                        "metrado_vertical_centro" => celda.AlineacionVertical == "Centro",
                        "metrado_vertical_abajo" => celda.AlineacionVertical == "Abajo",
                        "metrado_mostrar_formulas" => mostrarFormulasHoja,
                        _ => boton.Checked
                    };
            }
        }
        finally { sincronizandoCintaHoja = false; }
    }

    private static IEnumerable<Control> ControlesCintaHoja(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in ControlesCintaHoja(hijo)) yield return descendiente;
        }
    }

    private static IEnumerable<ToolStripItem> ItemsCintaHoja(Control padre)
    {
        foreach (var control in ControlesCintaHoja(padre))
            if (control is ToolStrip strip)
                foreach (ToolStripItem item in strip.Items) yield return item;
    }

    private FlowLayoutPanel PestanaHoja(string titulo)
    {
        var grupos = MYGEspecificacionesCinta.Pagina(cintaHoja, titulo);
        grupos.Parent.Name = "metrado_pestana_" + titulo;
        return grupos;
    }

    private static Panel GrupoHoja(FlowLayoutPanel pagina, string titulo, int ancho)
    {
        var grupo = MYGEspecificacionesCinta.Grupo(pagina, titulo, ancho);
        grupo.Name = "metrado_grupo_" + titulo;
        return grupo;
    }

    private ToolStripButton BotonCintaHoja(string texto, string comando, string icono, bool grande = false, string bloqueo = null)
    {
        var boton = new ToolStripButton(texto)
        {
            Name = "metrado_" + comando.Replace(':', '_'),
            ToolTipText = bloqueo ?? texto.Replace('\n', ' '),
            Enabled = bloqueo == null,
            AutoToolTip = false
        };
        if (bloqueo == null) boton.Click += (_, _) => Intentar(() => EjecutarComandoHoja(comando));
        IconoCintaHoja(boton, icono, grande ? 32 : 18, grande);
        return boton;
    }

    private ToolStripDropDownButton MenuCintaHoja(string texto, string icono, bool grande,
        params (string Texto, string Comando)[] opciones)
    {
        var menu = new ToolStripDropDownButton(texto) { AutoToolTip = false, ToolTipText = texto.Replace('\n', ' ') };
        IconoCintaHoja(menu, icono, grande ? 32 : 18, grande);
        foreach (var opcion in opciones)
        {
            var item = new ToolStripMenuItem(opcion.Texto) { Name = "metrado_" + opcion.Comando.Replace(':', '_') };
            string comando = opcion.Comando;
            item.Click += (_, _) => Intentar(() => EjecutarComandoHoja(comando));
            menu.DropDownItems.Add(item);
        }
        return menu;
    }

    private void IconoCintaHoja(ToolStripItem item, string icono, int tamano, bool texto)
    {
        if (!icono.StartsWith("xls_", StringComparison.Ordinal))
        {
            MYGEspecificacionesCinta.Icono(item, icono, tamano, texto);
            return;
        }
        MYGEspecificacionesCinta.Icono(item, icono, MYGExcelCintaIconos.Dibujar, tamano, texto);
    }

    private void FilaGrandeHoja(Panel grupo, params ToolStripItem[] botones)
    {
        var fila = MYGEspecificacionesCinta.Fila(grupo, 7, botones);
        var fuente = new Font("Segoe UI", 8.25f);
        fila.Font = fuente;
        fila.Disposed += (_, _) => fuente.Dispose();
    }

    private ToolStripButton TextoFormatoHoja(string texto, string comando, FontStyle estilo, string ayuda)
    {
        var boton = new ToolStripButton(texto) { Name = "metrado_" + comando, ToolTipText = ayuda, AutoToolTip = false,
            AutoSize = false, Size = new Size(26, 26), Font = new Font("Arial", 11f, estilo), DisplayStyle = ToolStripItemDisplayStyle.Text };
        boton.Click += (_, _) => Intentar(() => EjecutarComandoHoja(comando));
        boton.Disposed += (_, _) => boton.Font.Dispose();
        return boton;
    }

    private void ComprobacionHoja(Panel grupo, string texto, string comando, int y, bool marcada, bool habilitada = true)
    {
        var check = new CheckBox { Text = texto, Name = "metrado_" + comando, Location = new Point(10, y),
            AutoSize = true, Checked = marcada, Enabled = habilitada, UseVisualStyleBackColor = false };
        check.CheckedChanged += (_, _) => { if (!cargando && !sincronizandoCintaHoja) Intentar(() => EjecutarComandoHoja(comando)); };
        grupo.Controls.Add(check);
    }

    private void PrepararArchivoHoja()
    {
        var pagina = PestanaHoja("Archivo");
        FilaGrandeHoja(GrupoHoja(pagina, "Navegación", 92), BotonCintaHoja("Volver", "volver", "xls_volver", true));
        FilaGrandeHoja(GrupoHoja(pagina, "Común", 397),
            BotonCintaHoja("Guardar\ncomo", "exportar", "guardar_como", true),
            BotonCintaHoja("Impresión\nrápida", "impresion_rapida", "imprimir", true),
            BotonCintaHoja("Imprimir", "imprimir", "imprimir", true),
            BotonCintaHoja("Vista\nprevia", "vista_previa", "xls_previa", true),
            BotonCintaHoja("Deshacer", "deshacer", "deshacer", true),
            BotonCintaHoja("Rehacer", "rehacer", "rehacer", true));
        FilaGrandeHoja(GrupoHoja(pagina, "Información", 116), BotonCintaHoja("Cifrar con\ncontraseña", "cifrar", "xls_cifrar", true,
            "El exportador XLSX no admite cifrado de libros. Puede proteger el archivo exportado desde Microsoft Excel."));
    }

    private void PrepararInicioHoja()
    {
        var pagina = PestanaHoja("Inicio");
        var portapapeles = GrupoHoja(pagina, "Portapapeles", 98);
        var pegar = MYGEspecificacionesCinta.Fila(portapapeles, 7, BotonCintaHoja("Pegar", "pegar", "pegar", true));
        pegar.Left = 5; pegar.Width = 49;
        foreach (var (texto, comando, icono, y) in new[] { ("Cortar", "cortar", "cortar", 4), ("Copiar", "copiar", "copiar", 29), ("Importar XLSX", "importar", "xls_importar", 54) })
        {
            var fila = MYGEspecificacionesCinta.Fila(portapapeles, y, BotonCintaHoja(texto, comando, icono));
            fila.Left = 63; fila.Width = 30;
        }
        var fuenteGrupo = GrupoHoja(pagina, "Fuente", 311);
        var fuentes = new ToolStripComboBox { Name = "metrado_fuente", Width = 151, AutoSize = false, DropDownStyle = ComboBoxStyle.DropDownList };
        using (var instaladas = new System.Drawing.Text.InstalledFontCollection())
            fuentes.Items.AddRange(instaladas.Families.Select(f => (object)f.Name).OrderBy(x => x).ToArray());
        if (!fuentes.Items.Contains(MYGCeldaHoja.FuentePredeterminada)) fuentes.Items.Add(MYGCeldaHoja.FuentePredeterminada);
        fuentes.SelectedItem = MYGCeldaHoja.FuentePredeterminada;
        if (fuentes.SelectedIndex < 0) fuentes.SelectedItem = "Segoe UI";
        fuentes.ComboBox.SelectionChangeCommitted += (_, _) => Intentar(() => EjecutarComandoHoja("fuente:" + fuentes.Text));
        var tamanos = new ToolStripComboBox { Name = "metrado_tamano", Width = 57, AutoSize = false, Text = "9" };
        tamanos.Items.AddRange(new object[] { "8", "9", "10", "11", "12", "14", "16", "18", "20", "24", "28", "36", "48", "72" });
        void AplicarTamano()
        {
            string valor = tamanos.Text;
            if (decimal.TryParse(valor, NumberStyles.Float, CultureInfo.CurrentCulture, out var numero) ||
                decimal.TryParse(valor, NumberStyles.Float, CultureInfo.InvariantCulture, out numero))
                valor = numero.ToString(CultureInfo.InvariantCulture);
            Intentar(() => EjecutarComandoHoja("tamano:" + valor));
        }
        tamanos.ComboBox.SelectionChangeCommitted += (_, _) => AplicarTamano();
        tamanos.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AplicarTamano(); } };
        MYGEspecificacionesCinta.Fila(fuenteGrupo, 10, fuentes, tamanos,
            BotonCintaHoja("Aumentar tamaño de fuente", "aumentar_fuente", "aumentar_fuente"),
            BotonCintaHoja("Reducir tamaño de fuente", "reducir_fuente", "reducir_fuente"));
        MYGEspecificacionesCinta.Fila(fuenteGrupo, 48,
            TextoFormatoHoja("B", "negrita", FontStyle.Bold, "Negrita (Ctrl+B)"),
            TextoFormatoHoja("I", "cursiva", FontStyle.Italic, "Cursiva (Ctrl+I)"),
            TextoFormatoHoja("U", "subrayado", FontStyle.Underline, "Subrayado (Ctrl+U)"),
            TextoFormatoHoja("S", "tachado", FontStyle.Strikeout, "Tachado"),
            BotonCintaHoja("Bordes", "bordes", "xls_bordes"),
            BotonCintaHoja("Color de relleno", "color_fondo", "color_fondo"),
            BotonCintaHoja("Color de fuente", "color_fuente", "color_fuente"));
        var alineacion = GrupoHoja(pagina, "Alineación", 288);
        var primera = MYGEspecificacionesCinta.Fila(alineacion, 10,
            BotonCintaHoja("Alinear en la parte superior", "vertical:arriba", "xls_arriba"),
            BotonCintaHoja("Alinear en el medio", "vertical:centro", "xls_medio"),
            BotonCintaHoja("Alinear en la parte inferior", "vertical:abajo", "xls_abajo"),
            BotonCintaHoja("Ajustar texto", "ajustar_texto", "xls_ajustar"));
        primera.Items[3].DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
        primera.Items[3].TextImageRelation = TextImageRelation.ImageBeforeText;
        var combinar = MenuCintaHoja("Combinar", "xls_combinar", false, ("Combinar celdas", "combinar:combinar"), ("Separar celdas", "combinar:separar"));
        combinar.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText; combinar.TextImageRelation = TextImageRelation.ImageBeforeText;
        MYGEspecificacionesCinta.Fila(alineacion, 48,
            BotonCintaHoja("Alinear a la izquierda", "alineacion:izquierda", "izquierda"),
            BotonCintaHoja("Centrar", "alineacion:centro", "centro"),
            BotonCintaHoja("Alinear a la derecha", "alineacion:derecha", "derecha"),
            BotonCintaHoja("Disminuir sangría", "sangria_menos", "sangria_menos", bloqueo: "Las celdas de metrado no almacenan sangría; use la alineación horizontal."),
            BotonCintaHoja("Aumentar sangría", "sangria_mas", "sangria_mas", bloqueo: "Las celdas de metrado no almacenan sangría; use la alineación horizontal."), combinar);
        var numero = GrupoHoja(pagina, "Número", 206);
        var formatos = new ToolStripComboBox { Name = "metrado_formato_numero", AutoSize = false, Width = 174, DropDownStyle = ComboBoxStyle.DropDownList };
        (string Nombre, string Formato)[] opciones = { ("General", "General"), ("Número", "0.00"), ("Moneda", "S/ #,##0.00"), ("Contabilidad", "#,##0.00"), ("Porcentaje", "0.00%"), ("Entero", "0") };
        formatos.Items.AddRange(opciones.Select(o => (object)o.Nombre).ToArray()); formatos.SelectedIndex = 0;
        formatos.ComboBox.SelectionChangeCommitted += (_, _) => Intentar(() => EjecutarComandoHoja("formato_numero:" + opciones[formatos.SelectedIndex].Formato));
        MYGEspecificacionesCinta.Fila(numero, 10, formatos);
        MYGEspecificacionesCinta.Fila(numero, 48,
            MenuCintaHoja("Formato de moneda", "xls_moneda", false, ("Soles (S/)", "formato_numero:S/ #,##0.00"), ("Dólares ($)", "formato_numero:$ #,##0.00")),
            BotonCintaHoja("Porcentaje", "formato_numero:0%", "xls_porcentaje"),
            BotonCintaHoja("Estilo millares", "formato_numero:#,##0.00", "xls_millares"),
            BotonCintaHoja("Disminuir decimales", "decimales_menos", "xls_decimal_menos"),
            BotonCintaHoja("Aumentar decimales", "decimales_mas", "xls_decimal_mas"));
    }

    private void PrepararCeldasHoja()
    {
        var pagina = PestanaHoja("Celdas");
        var celdas = GrupoHoja(pagina, "Celdas", 132);
        MYGEspecificacionesCinta.Fila(celdas, 3, MenuTextoHoja("Insertar", "xls_insertar", ("Insertar filas", "insertar_filas"), ("Insertar columnas", "insertar_columnas")));
        MYGEspecificacionesCinta.Fila(celdas, 28, MenuTextoHoja("Eliminar", "xls_eliminar", ("Eliminar filas", "eliminar_filas"), ("Eliminar columnas", "eliminar_columnas")));
        MYGEspecificacionesCinta.Fila(celdas, 53, MenuTextoHoja("Formato", "xls_formato", ("Alto de fila…", "alto_fila"), ("Ancho de columna…", "ancho_columna"), ("Borrar formato", "borrar_formato")));
        var opciones = GrupoHoja(pagina, "", 198); opciones.Name = "metrado_grupo_opciones_estilos";
        var condicional = BotonCintaHoja("Formato condicional", "formato_condicional", "xls_condicional", bloqueo:
            "El formato condicional de Excel requiere reglas que aún no se almacenan en el libro de metrado. Use los estilos de celda.");
        condicional.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText; condicional.TextImageRelation = TextImageRelation.ImageBeforeText;
        MYGEspecificacionesCinta.Fila(opciones, 12, condicional);
        var tabla = BotonCintaHoja("Dar formato como tabla", "dar_formato_tabla", "xls_formato_tabla");
        tabla.ToolTipText = "Aplicar relleno y bordes de tabla al rango seleccionado";
        tabla.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText; tabla.TextImageRelation = TextImageRelation.ImageBeforeText;
        MYGEspecificacionesCinta.Fila(opciones, 49, tabla);
        var estilos = GrupoHoja(pagina, "Estilos", 421);
        (string Texto, string Id, Color Fondo, Color Tinta)[] modelos = {
            ("Normal", "normal", Color.FromArgb(255, 226, 126), Color.Black),
            ("Buena", "buena", Color.FromArgb(198, 239, 206), Color.FromArgb(0, 97, 0)),
            ("Incorrecto", "incorrecto", Color.FromArgb(255, 199, 206), Color.FromArgb(156, 0, 6)),
            ("Neutral", "neutral", Color.FromArgb(255, 235, 156), Color.FromArgb(156, 101, 0)),
            ("Cálculo", "calculo", Color.FromArgb(242, 242, 242), Color.FromArgb(237, 125, 49)),
            ("Celda de comentario", "comentario", Color.FromArgb(166, 166, 166), Color.White) };
        for (int fila = 0; fila < 2; fila++)
        {
            var items = new List<ToolStripItem>();
            foreach (var modelo in modelos.Skip(fila * 3).Take(3))
            {
                var item = new ToolStripButton(modelo.Texto) { Name = "metrado_estilo_" + modelo.Id, AutoSize = false, Size = new Size(131, 29),
                    DisplayStyle = ToolStripItemDisplayStyle.Text, TextAlign = ContentAlignment.MiddleLeft, ToolTipText = "Aplicar estilo " + modelo.Texto };
                string id = modelo.Id;
                item.Click += (_, _) => Intentar(() => EjecutarComandoHoja("estilo:" + id));
                // Las muestras conservan los colores del formato incluso al cambiar el tema.
                item.Paint += (_, e) =>
                {
                    if (SystemInformation.HighContrast) return;
                    using var fondo = new SolidBrush(modelo.Fondo);
                    e.Graphics.FillRectangle(fondo, 3, 3, item.Width - 6, item.Height - 6);
                    TextRenderer.DrawText(e.Graphics, item.Text, item.Font, new Rectangle(8, 3, item.Width - 13, item.Height - 6),
                        modelo.Tinta, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
                    if (item.Selected)
                    {
                        using var borde = new Pen(MYG2027_TemaComercial.Azul);
                        e.Graphics.DrawRectangle(borde, 2, 2, item.Width - 5, item.Height - 5);
                    }
                };
                items.Add(item);
            }
            MYGEspecificacionesCinta.Fila(estilos, fila == 0 ? 6 : 43, items.ToArray());
        }
        var modificar = GrupoHoja(pagina, "Modificar", 105);
        FilaGrandeHoja(modificar, MenuCintaHoja("Modificar", "xls_modificar", true, ("Rellenar hacia abajo", "rellenar_abajo"), ("Borrar contenido", "limpiar"), ("Buscar…", "buscar"), ("Reemplazar…", "reemplazar")));
    }

    private ToolStripDropDownButton MenuTextoHoja(string texto, string icono, params (string Texto, string Comando)[] opciones)
    {
        var menu = MenuCintaHoja(texto, icono, false, opciones);
        menu.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
        menu.TextImageRelation = TextImageRelation.ImageBeforeText;
        menu.TextAlign = ContentAlignment.MiddleLeft;
        return menu;
    }

    private void PrepararPaginaHoja()
    {
        var pagina = PestanaHoja("Diseño de Página");
        FilaGrandeHoja(GrupoHoja(pagina, "Configurar página", 369),
            BotonCintaHoja("Márgenes", "margenes", "margenes", true),
            MenuCintaHoja("Orientación", "orientacion", true, ("Vertical", "orientacion:vertical"), ("Horizontal", "orientacion:horizontal")),
            MenuCintaHoja("Tamaño", "tamano", true, ("A4", "tamano_papel:A4"), ("A3", "tamano_papel:A3"), ("Carta", "tamano_papel:Carta"), ("Oficio", "tamano_papel:Oficio")),
            MenuCintaHoja("Área de\nimpresión", "xls_area_impresion", true, ("Establecer área de impresión", "area_impresion:establecer"), ("Borrar área de impresión", "area_impresion:borrar")),
            BotonCintaHoja("Imprimir\ntítulos", "imprimir_titulos", "xls_titulos", true));
        var mostrar = GrupoHoja(pagina, "Mostrar", 144);
        ComprobacionHoja(mostrar, "Líneas división", "lineas_division", 17, true);
        ComprobacionHoja(mostrar, "Encabezados", "encabezados", 54, true);
        var imprimir = GrupoHoja(pagina, "Imprimir", 144);
        ComprobacionHoja(imprimir, "Líneas división", "imprimir_lineas_division", 17, false);
        ComprobacionHoja(imprimir, "Encabezados", "imprimir_encabezados", 54, false);
        FilaGrandeHoja(GrupoHoja(pagina, "Organizar", 175),
            BotonCintaHoja("Adelantar", "adelantar", "xls_adelantar", true, "La hoja no contiene objetos flotantes que se puedan ordenar en capas."),
            BotonCintaHoja("Enviar\nhacia atrás", "enviar_atras", "xls_atras", true, "La hoja no contiene objetos flotantes que se puedan ordenar en capas."));
    }

    private void PrepararFormulasHoja()
    {
        var pagina = PestanaHoja("Fórmulas");
        FilaGrandeHoja(GrupoHoja(pagina, "Biblioteca de funciones", 696),
            BotonCintaHoja("Mostrar\nfórmulas", "mostrar_formulas", "xls_formulas", true),
            MenuCintaHoja("Autosuma", "xls_suma", true, ("Suma", "autosuma"), ("Promedio", "insertar_funcion:AVERAGE"), ("Contar números", "insertar_funcion:COUNT"), ("Máximo", "insertar_funcion:MAX"), ("Mínimo", "insertar_funcion:MIN")),
            BotonCintaHoja("Financieras", "financieras", "xls_financieras", true, "El motor del metrado aún no evalúa funciones financieras como VA, VF o PAGO."),
            MenuCintaHoja("Lógicas", "xls_logicas", true, ("SI (IF)", "insertar_funcion:IF")),
            BotonCintaHoja("Texto", "funciones_texto", "xls_texto", true, "El motor del metrado aún no evalúa funciones de texto como CONCATENAR o IZQUIERDA."),
            BotonCintaHoja("Fecha\ny hora", "funciones_fecha", "xls_fecha", true, "El motor del metrado aún no evalúa funciones de fecha y hora."),
            BotonCintaHoja("Búsqueda y\nreferencia", "funciones_busqueda", "xls_busqueda", true, "El motor del metrado aún no evalúa BUSCARV o INDICE. Puede usar referencias directas de celda."),
            MenuCintaHoja("Matemáticas y\ntrigonométricas", "xls_matematicas", true, ("Suma (SUM)", "insertar_funcion:SUM"), ("Producto (PRODUCT)", "insertar_funcion:PRODUCT"), ("Redondear (ROUND)", "insertar_funcion:ROUND"), ("Valor absoluto (ABS)", "insertar_funcion:ABS")),
            MenuCintaHoja("Más funciones", "xls_mas_funciones", true, ("Contar (COUNT)", "insertar_funcion:COUNT"), ("Promedio (AVERAGE)", "insertar_funcion:AVERAGE"), ("Máximo (MAX)", "insertar_funcion:MAX"), ("Mínimo (MIN)", "insertar_funcion:MIN")));
        FilaGrandeHoja(GrupoHoja(pagina, "Nombres definidos", 110), BotonCintaHoja("Nombres\ndefinidos", "nombres", "xls_nombres", true,
            "El motor del metrado trabaja con direcciones A1 y rangos; los nombres definidos de Excel aún no se almacenan."));
        FilaGrandeHoja(GrupoHoja(pagina, "Cálculo", 85), MenuCintaHoja("Cálculo", "xls_calculo", true, ("Calcular ahora", "recalcular"), ("Usar celda como total del metrado", "usar_total")));
    }

    private void PrepararInsertarHoja()
    {
        var pagina = PestanaHoja("Insertar");
        FilaGrandeHoja(GrupoHoja(pagina, "Tablas", 136),
            BotonCintaHoja("Tabla\ndinámica", "tabla_dinamica", "xls_pivot", true, "Las tablas dinámicas aún no se almacenan ni se calculan en el libro de metrado."),
            BotonCintaHoja("Tabla", "dar_formato_tabla", "xls_tabla", true));
        FilaGrandeHoja(GrupoHoja(pagina, "Ilustraciones", 118), BotonCintaHoja("Insertar imagen\ndesde fichero", "imagen", "imagen", true,
            "La hoja aún no admite imágenes flotantes; use la referencia de imagen en Metrados manuales."));
        FilaGrandeHoja(GrupoHoja(pagina, "Gráficos", 447),
            GraficoHoja("Columna", "columnas"), GraficoHoja("Línea", "linea"), GraficoHoja("Circular", "circular"),
            GraficoHoja("Barras", "barras"), GraficoHoja("Área", "area"), GraficoHoja("Dispersión", "dispersion"), GraficoHoja("Más gráficos", "mas_graficos"));
        FilaGrandeHoja(GrupoHoja(pagina, "Vínculos", 98), BotonCintaHoja("Insertar\nHipervínculo", "enlace", "enlace", true));
        FilaGrandeHoja(GrupoHoja(pagina, "Símbolos", 81), BotonCintaHoja("Símbolo", "simbolo", "simbolo", true));
    }

    private ToolStripItem GraficoHoja(string texto, string tipo)
        => BotonCintaHoja(texto, "grafico:" + tipo, "xls_grafico_" + tipo, true,
            "Los gráficos de Excel aún no se almacenan en el libro de metrado. Puede crearlos en el archivo XLSX exportado.");

    private void PrepararDatosHoja()
    {
        var pagina = PestanaHoja("Datos");
        FilaGrandeHoja(GrupoHoja(pagina, "Ordenar y filtrar", 306),
            BotonCintaHoja("Ordenar\nde A a Z", "ordenar_asc", "xls_ordenar_asc", true),
            BotonCintaHoja("Ordenar\nde Z a A", "ordenar_desc", "xls_ordenar_desc", true),
            BotonCintaHoja("Filtro", "filtro", "xls_filtro", true),
            BotonCintaHoja("Borrar", "borrar_filtro", "xls_borrar_filtro", true),
            BotonCintaHoja("Volver a\naplicar", "reaplicar_filtro", "xls_reaplicar", true));
        FilaGrandeHoja(GrupoHoja(pagina, "Herramientas de datos", 114), BotonCintaHoja("Validación\nde datos", "validacion", "xls_validacion", true));
        var esquema = GrupoHoja(pagina, "Esquema", 361);
        var grandes = MYGEspecificacionesCinta.Fila(esquema, 7,
            BotonCintaHoja("Agrupar", "agrupar", "xls_agrupar", true),
            BotonCintaHoja("Desagrupar", "desagrupar", "xls_desagrupar", true),
            BotonCintaHoja("Subtotal", "subtotal", "xls_subtotal", true));
        grandes.Width = 216;
        var mostrar = MYGEspecificacionesCinta.Fila(esquema, 10, BotonCintaHoja("Mostrar detalle", "mostrar_detalle", "xls_mostrar"));
        mostrar.Left = 220; mostrar.Width = 135;
        mostrar.Items[0].DisplayStyle = ToolStripItemDisplayStyle.ImageAndText; mostrar.Items[0].TextImageRelation = TextImageRelation.ImageBeforeText;
        var ocultar = MYGEspecificacionesCinta.Fila(esquema, 48, BotonCintaHoja("Ocultar detalle", "ocultar_detalle", "xls_ocultar"));
        ocultar.Left = 220; ocultar.Width = 135;
        ocultar.Items[0].DisplayStyle = ToolStripItemDisplayStyle.ImageAndText; ocultar.Items[0].TextImageRelation = TextImageRelation.ImageBeforeText;
    }

    private void PrepararRevisarHoja()
    {
        var pagina = PestanaHoja("Revisar");
        FilaGrandeHoja(GrupoHoja(pagina, "Revisión", 202),
            BotonCintaHoja("Buscar", "buscar", "buscar", true),
            BotonCintaHoja("Reemplazar", "reemplazar", "reemplazar", true),
            BotonCintaHoja("Ortografía", "ortografia", "ortografia", true, "La hoja de metrado no incluye un corrector ortográfico. Puede revisar el archivo exportado desde Excel."));
        FilaGrandeHoja(GrupoHoja(pagina, "Comentarios", 106), BotonCintaHoja("Comentario", "comentario", "comentario", true,
            "Las anotaciones de celda aún no se almacenan en el libro de metrado. Use la columna Plano - Referencia para observaciones."));
        FilaGrandeHoja(GrupoHoja(pagina, "Proteger", 220),
            BotonCintaHoja("Proteger\nhoja", "proteger_hoja", "xls_cifrar", true, "La protección de hojas de Excel aún no se almacena en el libro de metrado."),
            BotonCintaHoja("Proteger\nlibro", "proteger_libro", "xls_cifrar", true, "La protección de libros de Excel aún no se almacena en el libro de metrado."));
    }

    private void PrepararVistaHoja()
    {
        var pagina = PestanaHoja("Vista");
        var mostrar = GrupoHoja(pagina, "Mostrar", 145);
        ComprobacionHoja(mostrar, "Líneas división", "lineas_division", 17, true);
        ComprobacionHoja(mostrar, "Encabezados", "encabezados", 54, true);
        FilaGrandeHoja(GrupoHoja(pagina, "Ampliación", 238),
            BotonCintaHoja("Zoom", "zoom", "buscar", true),
            BotonCintaHoja("Alejar", "zoom_menos", "zoom_menos", true),
            BotonCintaHoja("Acercar", "zoom_mas", "zoom_mas", true),
            BotonCintaHoja("100%", "zoom_100", "xls_zoom_100", true));
        FilaGrandeHoja(GrupoHoja(pagina, "Ventana", 121), MenuCintaHoja("Inmovilizar", "xls_inmovilizar", true,
            ("Inmovilizar paneles", "inmovilizar"), ("Inmovilizar fila superior", "inmovilizar_fila"),
            ("Inmovilizar primera columna", "inmovilizar_columna"), ("Movilizar paneles", "movilizar")));
    }
}

// Iconos vectoriales del libro de metrado; se regeneran con la paleta del tema.
internal static class MYGExcelCintaIconos
{
    internal static Bitmap Dibujar(string id, int tamano, bool seleccionado = false)
    {
        var imagen = new Bitmap(tamano, tamano, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(imagen);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        g.ScaleTransform(tamano / 24f, tamano / 24f);
        bool altoContraste = SystemInformation.HighContrast;
        Color azulColor = altoContraste ? seleccionado ? SystemColors.HighlightText : SystemColors.ControlText : MYG2027_TemaComercial.Secundario;
        Color verdeColor = altoContraste ? azulColor : Color.FromArgb(62, 160, 79);
        Color naranjaColor = altoContraste ? azulColor : Color.FromArgb(255, 158, 0);
        Color rojoColor = altoContraste ? azulColor : Color.FromArgb(239, 70, 102);
        using var azul = new Pen(azulColor, 1.6f) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round };
        using var azulFondo = new SolidBrush(azulColor);
        using var verde = new SolidBrush(verdeColor);
        using var rojo = new SolidBrush(rojoColor);
        using var naranja = new SolidBrush(naranjaColor);
        Color fondoContraste = seleccionado ? SystemColors.Highlight : SystemColors.Control;
        using var superficie = new SolidBrush(altoContraste ? fondoContraste : MYG2027_TemaComercial.Superficie);
        void Rect(float x, float y, float w, float h) => g.DrawRectangle(azul, x, y, w, h);
        void Linea(float x, float y, float x2, float y2) => g.DrawLine(azul, x, y, x2, y2);
        void Texto(string texto, RectangleF area, float size = 13, Color? color = null)
        {
            using var fuente = new Font("Arial", size, FontStyle.Bold, GraphicsUnit.Pixel);
            using var tinta = new SolidBrush(color ?? azulColor);
            using var formato = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            g.DrawString(texto, fuente, tinta, area, formato);
        }
        void Tabla(bool cabecera = true)
        {
            Rect(3, 3, 19, 18);
            if (cabecera) g.FillRectangle(azulFondo, 3, 3, 19, 4);
            for (int x = 8; x < 22; x += 5) Linea(x, 3, x, 21);
            for (int y = 7; y < 21; y += 5) Linea(3, y, 22, y);
        }
        void Insignia(bool agregar, float x = 1, float y = 9)
        {
            g.FillRectangle(agregar ? verde : rojo, x, y, 9, 9);
            using var p = new Pen(altoContraste ? fondoContraste : Color.White, 1.4f);
            g.DrawLine(p, x + 2, y + 4.5f, x + 7, y + 4.5f);
            if (agregar) g.DrawLine(p, x + 4.5f, y + 2, x + 4.5f, y + 7);
        }
        switch (id)
        {
            case "xls_volver":
                using (var p = new Pen(naranjaColor, 2)) g.DrawEllipse(p, 2, 2, 20, 20);
                using (var p = new Pen(naranjaColor, 2)) { g.DrawLine(p, 6, 12, 18, 12); g.DrawLines(p, new[] { new PointF(11, 7), new PointF(6, 12), new PointF(11, 17) }); }
                break;
            case "xls_previa":
                Rect(4, 2, 14, 20); g.DrawEllipse(azul, 8, 7, 9, 9); Linea(16, 15, 22, 21); break;
            case "xls_cifrar":
                using (var p = new Pen(naranjaColor, 2)) g.DrawArc(p, 5, 1, 9, 13, 180, 180);
                g.FillRectangle(naranja, 3, 9, 14, 11); g.FillEllipse(azulFondo, 13, 12, 9, 9);
                Linea(16, 18, 10, 23); g.FillEllipse(superficie, 16, 14, 3, 3); break;
            case "xls_importar":
                Tabla(); Insignia(true); break;
            case "xls_bordes": Tabla(false); break;
            case "xls_arriba": case "xls_medio": case "xls_abajo":
                int desplazamiento = id == "xls_arriba" ? 4 : id == "xls_medio" ? 9 : 14;
                for (int i = 0; i < 3; i++) Linea(4, desplazamiento + i * 2, 20, desplazamiento + i * 2);
                Linea(3, id == "xls_arriba" ? 1 : 22, 21, id == "xls_arriba" ? 1 : 22); break;
            case "xls_ajustar":
                Linea(2, 5, 18, 5); Linea(2, 9, 13, 9); Linea(2, 16, 12, 16);
                Linea(18, 9, 18, 17); Linea(18, 17, 13, 17); g.FillPolygon(azulFondo, new[] { new PointF(12, 17), new PointF(16, 14), new PointF(16, 20) }); break;
            case "xls_combinar":
                Tabla(false); g.FillRectangle(superficie, 8, 8, 8, 8); Linea(5, 12, 19, 12);
                g.FillPolygon(verde, new[] { new PointF(9, 12), new PointF(5, 9), new PointF(5, 15) });
                g.FillPolygon(verde, new[] { new PointF(15, 12), new PointF(19, 9), new PointF(19, 15) }); break;
            case "xls_moneda":
                g.FillEllipse(naranja, 1, 2, 13, 13); g.FillEllipse(verde, 10, 11, 12, 12);
                Texto("$", new RectangleF(1, 2, 13, 13), 11, altoContraste ? fondoContraste : Color.White);
                Texto("S", new RectangleF(10, 11, 12, 12), 10, altoContraste ? fondoContraste : Color.White); break;
            case "xls_porcentaje": Texto("%", new RectangleF(1, 1, 22, 22), 20); break;
            case "xls_millares": Texto(",", new RectangleF(1, -5, 22, 29), 25); break;
            case "xls_decimal_menos": case "xls_decimal_mas":
                Texto(".0", new RectangleF(4, 0, 20, 10), 9); Texto(".00", new RectangleF(4, 10, 20, 10), 9);
                Linea(1, 6, 1, 18); g.FillPolygon(azulFondo, id == "xls_decimal_mas"
                    ? new[] { new PointF(0, 19), new PointF(0, 14), new PointF(5, 16.5f) }
                    : new[] { new PointF(0, 2), new PointF(0, 7), new PointF(5, 4.5f) }); break;
            case "xls_insertar": case "xls_eliminar": Tabla(false); Insignia(id == "xls_insertar"); break;
            case "xls_formato": Tabla(false); Linea(1, 1, 22, 1); break;
            case "xls_condicional": case "xls_formato_tabla":
                Tabla(); g.FillRectangle(verde, 4, 8, 4, 4); g.FillRectangle(rojo, 9, 8, 4, 4); g.FillRectangle(naranja, 14, 8, 4, 4); break;
            case "xls_modificar":
                Linea(3, 4, 20, 4); Linea(3, 9, 17, 9); Linea(3, 14, 13, 14); Linea(11, 21, 21, 11);
                using (var p = new Pen(naranjaColor, 4)) g.DrawLine(p, 13, 19, 20, 12); break;
            case "xls_area_impresion": case "xls_titulos":
                Tabla();
                if (id == "xls_titulos") g.FillRectangle(verde, 3, 3, 19, 4);
                g.FillRectangle(azulFondo, 12, 13, 11, 8); g.FillRectangle(superficie, 15, 19, 6, 4); break;
            case "xls_adelantar": case "xls_atras":
                if (id == "xls_adelantar") { Rect(10, 10, 11, 11); g.FillRectangle(azulFondo, 2, 2, 12, 12); }
                else { g.FillRectangle(azulFondo, 2, 2, 12, 12); g.FillRectangle(superficie, 10, 10, 11, 11); Rect(10, 10, 11, 11); }
                break;
            case "xls_formulas":
                Rect(2, 2, 15, 12); Texto("12", new RectangleF(3, 2, 13, 11), 9); Texto("fx", new RectangleF(8, 9, 16, 15), 14); break;
            case "xls_suma": Texto("Σ", new RectangleF(0, -2, 24, 27), 26, naranjaColor); break;
            case "xls_financieras": case "xls_logicas": case "xls_texto": case "xls_fecha": case "xls_busqueda": case "xls_matematicas":
                Brush fondo = id == "xls_financieras" || id == "xls_matematicas" ? verde : id == "xls_texto" ? naranja : id == "xls_fecha" ? rojo : azulFondo;
                g.FillRectangle(fondo, 3, 2, 18, 20); g.FillRectangle(superficie, 5, 3, 14, 1.5f);
                if (id == "xls_busqueda") { using var p = new Pen(altoContraste ? fondoContraste : Color.White, 1.5f); g.DrawEllipse(p, 7, 7, 8, 8); g.DrawLine(p, 14, 14, 18, 18); }
                else if (id == "xls_fecha") { g.FillEllipse(superficie, 7, 7, 11, 11); Linea(12, 9, 12, 13); Linea(12, 13, 16, 13); }
                else Texto(id == "xls_financieras" ? "$" : id == "xls_logicas" ? "?" : id == "xls_texto" ? "A" : "Θ", new RectangleF(4, 5, 16, 15), 14, altoContraste ? fondoContraste : Color.White);
                break;
            case "xls_mas_funciones":
                g.FillRectangle(naranja, 6, 4, 16, 18); using (var p = new Pen(naranjaColor, 1.5f)) { g.DrawRectangle(p, 2, 1, 16, 18); g.DrawRectangle(p, 4, 3, 16, 18); } break;
            case "xls_nombres": Tabla(); Texto("A", new RectangleF(7, 8, 12, 12), 9); break;
            case "xls_calculo": Rect(4, 2, 16, 20); Texto("=", new RectangleF(5, 2, 14, 10), 12); Texto("+−", new RectangleF(5, 12, 14, 9), 9); break;
            case "xls_pivot": case "xls_tabla": Tabla(); if (id == "xls_pivot") Texto("Σ", new RectangleF(12, 11, 12, 14), 14); break;
            case "xls_ordenar_asc": case "xls_ordenar_desc":
                Linea(4, 2, 4, 20); g.FillPolygon(azulFondo, new[] { new PointF(4, 23), new PointF(0, 18), new PointF(8, 18) });
                Texto(id == "xls_ordenar_asc" ? "A" : "Z", new RectangleF(9, 0, 14, 12), 12, id == "xls_ordenar_asc" ? rojoColor : azulColor);
                Texto(id == "xls_ordenar_asc" ? "Z" : "A", new RectangleF(9, 12, 14, 12), 12, id == "xls_ordenar_asc" ? azulColor : rojoColor); break;
            case "xls_filtro": case "xls_borrar_filtro": case "xls_reaplicar":
                g.FillPolygon(id == "xls_filtro" ? naranja : azulFondo, new[] { new PointF(2, 2), new PointF(22, 2), new PointF(14, 12), new PointF(14, 20), new PointF(10, 23), new PointF(10, 12) });
                if (id == "xls_borrar_filtro") { using var p = new Pen(rojoColor, 2); g.DrawLine(p, 16, 15, 23, 22); g.DrawLine(p, 16, 22, 23, 15); }
                if (id == "xls_reaplicar") { g.DrawArc(azul, 13, 13, 10, 10, 20, 270); }
                break;
            case "xls_validacion":
                Rect(2, 5, 10, 5); Rect(2, 15, 10, 5);
                using (var p = new Pen(verdeColor, 2)) g.DrawLines(p, new[] { new PointF(14, 5), new PointF(17, 8), new PointF(22, 2) });
                using (var p = new Pen(rojoColor, 2)) { g.DrawLine(p, 15, 14, 22, 21); g.DrawLine(p, 15, 21, 22, 14); } break;
            case "xls_agrupar": case "xls_desagrupar": case "xls_subtotal":
                Tabla();
                if (id == "xls_subtotal") { g.FillRectangle(naranja, 1, 9, 10, 10); Texto("Σ", new RectangleF(1, 9, 10, 10), 10, altoContraste ? fondoContraste : Color.White); }
                else Insignia(id == "xls_agrupar"); break;
            case "xls_mostrar": case "xls_ocultar":
                Linea(8, 4, 22, 4); Linea(8, 10, 22, 10); Linea(8, 16, 22, 16); Insignia(id == "xls_mostrar", 0, 3); break;
            case "xls_zoom_100":
                g.DrawEllipse(azul, 6, 1, 13, 13); Linea(17, 12, 23, 18); Texto("100", new RectangleF(0, 14, 22, 10), 9); break;
            case "xls_inmovilizar":
                Tabla(); g.FillRectangle(azulFondo, 3, 3, 19, 4); g.FillRectangle(azulFondo, 3, 3, 5, 18); break;
            case "xls_grafico_columnas": case "xls_grafico_barras":
                if (id.EndsWith("columnas", StringComparison.Ordinal)) { g.FillRectangle(naranja, 2, 14, 5, 9); g.FillRectangle(verde, 9, 7, 5, 16); g.FillRectangle(azulFondo, 16, 2, 5, 21); }
                else { g.FillRectangle(naranja, 2, 2, 9, 5); g.FillRectangle(verde, 2, 9, 17, 5); g.FillRectangle(azulFondo, 2, 16, 21, 5); } break;
            case "xls_grafico_linea":
                using (var p = new Pen(rojoColor, 1.7f)) g.DrawLines(p, new[] { new PointF(2, 5), new PointF(8, 17), new PointF(15, 9), new PointF(22, 3) });
                using (var p = new Pen(naranjaColor, 1.7f)) g.DrawLines(p, new[] { new PointF(2, 20), new PointF(8, 11), new PointF(15, 18), new PointF(22, 10) });
                foreach (var punto in new[] { new Point(2, 5), new Point(8, 17), new Point(15, 9), new Point(22, 3) }) g.FillEllipse(rojo, punto.X - 2, punto.Y - 2, 4, 4); break;
            case "xls_grafico_circular": case "xls_grafico_mas_graficos":
                g.FillPie(rojo, 1, 1, 22, 22, 0, 230); g.FillPie(azulFondo, 1, 1, 22, 22, 230, 80); g.FillPie(naranja, 1, 1, 22, 22, 310, 50);
                if (id.EndsWith("mas_graficos", StringComparison.Ordinal)) g.FillEllipse(superficie, 8, 8, 8, 8); break;
            case "xls_grafico_area":
                g.FillPolygon(naranja, new[] { new PointF(1, 22), new PointF(1, 15), new PointF(9, 9), new PointF(16, 15), new PointF(23, 2), new PointF(23, 22) });
                g.FillPolygon(azulFondo, new[] { new PointF(1, 22), new PointF(1, 8), new PointF(9, 17), new PointF(16, 11), new PointF(23, 14), new PointF(23, 22) }); break;
            case "xls_grafico_dispersion":
                for (int i = 0; i < 8; i++) { float x = 3 + i * 2.5f, y = 20 - i * 2 + (i % 3 - 1) * 4; g.FillEllipse(i % 2 == 0 ? naranja : azulFondo, x - 1.3f, y - 1.3f, 2.6f, 2.6f); } break;
            default: Tabla(); break;
        }
        return imagen;
    }
}
