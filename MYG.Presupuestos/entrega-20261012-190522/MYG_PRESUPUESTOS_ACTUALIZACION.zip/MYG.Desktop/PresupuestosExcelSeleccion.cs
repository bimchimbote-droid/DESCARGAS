using System;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private int anclaEncabezadoColumnaHoja = -1, anclaEncabezadoFilaHoja = -1;

    private void SeleccionarEncabezadoHoja(int fila, int columna, bool control, bool ampliar)
    {
        if (!HayPartida || hoja.RowCount == 0 || hoja.ColumnCount == 0) return;
        if (fila >= hoja.RowCount || columna >= hoja.ColumnCount || fila < -1 || columna < -1) return;
        FinalizarEdicion();
        bool previo = cargando; cargando = true;
        try
        {
            if (!control) hoja.ClearSelection();
            if (fila == -1 && columna >= 0)
            {
                int ancla = ampliar && anclaEncabezadoColumnaHoja >= 0 ? anclaEncabezadoColumnaHoja : columna;
                if (!ampliar || anclaEncabezadoColumnaHoja < 0) anclaEncabezadoColumnaHoja = columna;
                int primera = hoja.Rows.Cast<DataGridViewRow>().First(r => r.Visible).Index;
                hoja.CurrentCell = hoja[columna, primera];
                for (int c = Math.Min(ancla, columna); c <= Math.Max(ancla, columna); c++)
                    foreach (DataGridViewRow r in hoja.Rows) hoja[c, r.Index].Selected = true;
            }
            else if (columna == -1 && fila >= 0)
            {
                if (!hoja.Rows[fila].Visible) return;
                int ancla = ampliar && anclaEncabezadoFilaHoja >= 0 ? anclaEncabezadoFilaHoja : fila;
                if (!ampliar || anclaEncabezadoFilaHoja < 0) anclaEncabezadoFilaHoja = fila;
                hoja.CurrentCell = hoja[0, fila];
                for (int f = Math.Min(ancla, fila); f <= Math.Max(ancla, fila); f++)
                    foreach (DataGridViewColumn c in hoja.Columns) hoja[c.Index, f].Selected = true;
            }
            else if (fila == -1 && columna == -1) hoja.SelectAll();
        }
        finally { cargando = previo; }
        ActualizarFormula();
        hoja.Invalidate();
        hoja.Focus();
    }
}
