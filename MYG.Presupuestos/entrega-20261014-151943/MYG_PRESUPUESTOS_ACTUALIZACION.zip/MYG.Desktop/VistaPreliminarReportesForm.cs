using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Configura una copia del informe; el proyecto y su historial quedan intactos.</summary>
internal sealed class MYGVistaPreliminarReportesForm : Form
{
    private readonly MYGConfiguracionVistaReporte configuracion;
    private readonly string nombreDocumento;
    private readonly MYGVistaPaginaControl superficie = new();
    private readonly TabControl cinta = new() { Name = "vista_cinta", Dock = DockStyle.Top, Height = 168 };
    private readonly TrackBar deslizadorZoom = new() { Name = "vista_deslizador_zoom", Minimum = 10, Maximum = 400, Value = 100, TickStyle = TickStyle.None, AutoSize = false, Width = 180, Height = 28 };
    private readonly Label estado = new() { Dock = DockStyle.Bottom, Height = 28, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8, 0, 0, 0) };
    private readonly ComboBox impresoras = Lista("vista_impresora");
    private readonly ComboBox orientacion = Lista("vista_orientacion");
    private readonly ComboBox tamano = Lista("vista_papel");
    private readonly ComboBox fuentes = Lista("vista_fuente");
    private readonly ComboBox zoom = Lista("vista_zoom");
    private readonly NumericUpDown escala = Numero("vista_escala", 25, 200, 100);
    private readonly NumericUpDown izquierda = Margen("vista_margen_izquierdo"), derecha = Margen("vista_margen_derecho");
    private readonly NumericUpDown superior = Margen("vista_margen_superior"), inferior = Margen("vista_margen_inferior");
    private readonly NumericUpDown desde = Numero("vista_desde", 1, 100000, 1), hasta = Numero("vista_hasta", 1, 100000, 1);
    private readonly NumericUpDown copias = Numero("vista_copias", 1, 999, 1);
    private readonly CheckBox rango = new() { Text = "Solo páginas indicadas", AutoSize = true, Name = "vista_rango" };
    private readonly CheckBox lineas = new() { Text = "Líneas de división", AutoSize = true, Name = "vista_lineas" };
    private readonly CheckBox encabezados = new() { Text = "Letras y números de celdas", AutoSize = true, Name = "vista_encabezados" };
    private readonly CheckBox titulos = new() { Text = "Repetir filas de título", AutoSize = true, Name = "vista_titulos" };
    private readonly Button imprimir, pdf;
    private ToolStripButton primera, anterior, siguiente, ultima, puntero, mano, varias;
    private MYGReportesImpresion.Vista vista;
    private int pagina;
    private bool cargando;
    private bool paginaInvalida;
    private Color colorPagina = Color.White;
    private string filigrana = "", ultimoPdf;
    private float ampliacion => superficie.Ampliacion;

    internal MYGConfiguracionVistaReporte Configuracion => configuracion;
    internal int CantidadPaginas => vista?.CantidadPaginas ?? 0;

    internal MYGVistaPreliminarReportesForm(string nombre, IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        configuracion = new MYGConfiguracionVistaReporte(reportes);
        nombreDocumento = nombre ?? "Reportes del proyecto";
        Name = "vista_preliminar_reportes";
        Text = "Vista preliminar · " + nombreDocumento;
        AutoScaleDimensions = new SizeF(96, 96);
        AutoScaleMode = AutoScaleMode.Dpi;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1280, 850); MinimumSize = new Size(960, 650);
        WindowState = FormWindowState.Maximized;
        Font = new Font("Segoe UI", 9);
        BackColor = Color.FromArgb(226, 236, 246);

        CrearCinta();
        var opciones = new FlowLayoutPanel { Name = "vista_opciones", Dock = DockStyle.Left, Width = 280,
            FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(10), BackColor = Color.FromArgb(213, 227, 241) };
        void Campo(string texto, Control control)
        {
            opciones.Controls.Add(new Label { Text = texto, AutoSize = true, Margin = new Padding(3, 8, 3, 3) });
            control.Width = 240; opciones.Controls.Add(control);
        }
        opciones.Controls.Add(new Label { Text = "Imprimir / exportar PDF", Font = new Font(Font, FontStyle.Bold), AutoSize = true });
        Campo("Impresora", impresoras);
        imprimir = new Button { Name = "vista_imprimir", Text = "Imprimir", Width = 240, Height = 32 };
        imprimir.Click += (_, _) => Intentar(Imprimir); opciones.Controls.Add(imprimir);
        pdf = new Button { Name = "vista_pdf", Text = "Exportar PDF…", Width = 240, Height = 32 };
        pdf.Click += (_, _) => Intentar(ExportarPdf); opciones.Controls.Add(pdf);
        opciones.Controls.Add(rango);
        Campo("Desde la página", desde); Campo("Hasta la página", hasta); Campo("Copias", copias);
        opciones.Controls.Add(new Label { Text = "Configuración de todas las hojas", Font = new Font(Font, FontStyle.Bold), AutoSize = true, Margin = new Padding(3, 14, 3, 3) });
        orientacion.Items.AddRange(new object[] { "Vertical", "Horizontal" });
        tamano.Items.AddRange(new object[] { "A4", "A3", "Carta", "Oficio" });
        var familias = FontFamily.Families;
        try { fuentes.Items.AddRange(familias.Select(f => f.Name).OrderBy(n => n).Cast<object>().ToArray()); }
        finally { foreach (var familia in familias) familia.Dispose(); }
        Campo("Orientación", orientacion); Campo("Tamaño de papel", tamano);
        Campo("Margen izquierdo (cm)", izquierda); Campo("Margen derecho (cm)", derecha);
        Campo("Margen superior (cm)", superior); Campo("Margen inferior (cm)", inferior);
        Campo("Fuente", fuentes); Campo("Escala de impresión (%)", escala);
        opciones.Controls.Add(titulos); opciones.Controls.Add(lineas); opciones.Controls.Add(encabezados);
        zoom.Items.AddRange(new object[] { "25%", "50%", "75%", "100%", "125%", "150%", "200%", "300%" });
        zoom.SelectedItem = "100%";
        Campo("Ampliación de la vista", zoom);
        var pie = new Panel { Name = "vista_estado", Dock = DockStyle.Bottom, Height = 34 };
        estado.Dock = DockStyle.Fill;
        var zoomPie = new FlowLayoutPanel { Dock = DockStyle.Right, Width = 250, WrapContents = false, Padding = new Padding(0, 2, 0, 0) };
        var menos = new Button { Name = "vista_zoom_menos_pie", Text = "−", Width = 28, Height = 27, Margin = Padding.Empty };
        var mas = new Button { Name = "vista_zoom_mas_pie", Text = "+", Width = 28, Height = 27, Margin = Padding.Empty };
        menos.Click += (_, _) => CambiarZoom(ampliacion / 1.12f);
        mas.Click += (_, _) => CambiarZoom(ampliacion * 1.12f);
        zoomPie.Controls.Add(menos); zoomPie.Controls.Add(deslizadorZoom); zoomPie.Controls.Add(mas);
        pie.Controls.Add(estado); pie.Controls.Add(zoomPie);
        Controls.Add(superficie); Controls.Add(opciones); Controls.Add(pie); Controls.Add(cinta);
        zoom.DropDownStyle = ComboBoxStyle.DropDown;
        KeyPreview = true;

        CargarAjustes();
        foreach (var control in new Control[] { orientacion, tamano, izquierda, derecha, superior, inferior })
        {
            if (control is ComboBox combo) combo.SelectedIndexChanged += (_, _) => CambiarPagina();
            else ((NumericUpDown)control).ValueChanged += (_, _) => CambiarPagina();
        }
        escala.ValueChanged += (_, _) => Cambiar(() => configuracion.Escala = (float)escala.Value / 100);
        fuentes.SelectedIndexChanged += (_, _) => Cambiar(() => configuracion.Fuente(fuentes.Text));
        lineas.CheckedChanged += (_, _) => Cambiar(() => { foreach (var r in configuracion.Reportes) r.Hoja.ImprimirLineasDivision = lineas.Checked; });
        encabezados.CheckedChanged += (_, _) => Cambiar(() => { foreach (var r in configuracion.Reportes) r.Hoja.ImprimirEncabezados = encabezados.Checked; });
        titulos.CheckedChanged += (_, _) => Cambiar(() => { foreach (var r in configuracion.Reportes) r.Hoja.RepetirTitulos = titulos.Checked; });
        zoom.SelectedIndexChanged += (_, _) => { if (!cargando) Intentar(LeerZoom); };
        zoom.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Intentar(LeerZoom); } };
        deslizadorZoom.ValueChanged += (_, _) => { if (!cargando) CambiarZoom((float)deslizadorZoom.Value / 100); };
        superficie.AmpliacionChanged += (_, _) => ActualizarEstado();
        KeyDown += (_, e) =>
        {
            if (!e.Control) return;
            if (e.KeyCode is Keys.Add or Keys.Oemplus) CambiarZoom(ampliacion * 1.12f);
            else if (e.KeyCode is Keys.Subtract or Keys.OemMinus) CambiarZoom(ampliacion / 1.12f);
            else if (e.KeyCode == Keys.D0) AjustarPagina();
            else return;
            e.Handled = true; e.SuppressKeyPress = true;
        };
        impresoras.SelectedIndexChanged += (_, _) => { if (!cargando) Intentar(ActualizarVista); };
        rango.CheckedChanged += (_, _) => desde.Enabled = hasta.Enabled = rango.Checked;
        desde.Enabled = hasta.Enabled = false;
        Shown += (_, _) => Intentar(() => { CargarImpresoras(); ActualizarVista(); AjustarPagina(); });
    }

    private void CrearCinta()
    {
        MYGEspecificacionesCinta.Preparar(cinta);
        var grupos = MYGEspecificacionesCinta.Pagina(cinta, "Imprimir Previsualización");
        grupos.Name = "vista_grupos";
        ToolStripButton Boton(string texto, string nombre, string icono, Action accion)
        {
            var boton = new ToolStripButton(texto) { Name = nombre, Tag = icono, AutoSize = false, Width = 60, Height = 74,
                ToolTipText = texto.Replace('\n', ' '), AccessibleName = texto.Replace('\n', ' ') };
            MYGEspecificacionesCinta.Icono(boton, icono, MYGVistaPreliminarCintaIconos.Dibujar, 32, true);
            boton.Click += (_, _) => Intentar(accion);
            return boton;
        }
        ToolStripDropDownButton Menu(string texto, string nombre, string icono)
        {
            var boton = new ToolStripDropDownButton(texto) { Name = nombre, Tag = icono, AutoSize = false, Width = 60, Height = 74,
                ToolTipText = texto.Replace('\n', ' '), AccessibleName = texto.Replace('\n', ' ') };
            MYGEspecificacionesCinta.Icono(boton, icono, MYGVistaPreliminarCintaIconos.Dibujar, 32, true);
            return boton;
        }
        void Opcion(ToolStripDropDownButton menu, string texto, Action accion, string nombre = null, string icono = "pagina")
        {
            var item = new ToolStripMenuItem(texto) { Name = nombre ?? "" };
            MYGEspecificacionesCinta.Icono(item, icono, MYGVistaPreliminarCintaIconos.Dibujar, 24, true);
            item.TextImageRelation = TextImageRelation.ImageBeforeText;
            item.Click += (_, _) => Intentar(accion); menu.DropDownItems.Add(item);
        }
        void Grupo(string titulo, params ToolStripItem[] acciones)
        {
            var grupo = MYGVistaPreliminarCintaDiseno.Grupo(grupos, titulo, acciones.Sum(i => i.Width + 2) + 10);
            grupo.Name = "vista_grupo_" + titulo;
            var fila = MYGVistaPreliminarCintaDiseno.Fila(grupo, 4, acciones);
            fila.Name = "vista_barra_" + titulo;
        }

        Grupo("Volver", Boton("Volver", "vista_volver", "volver", Close));
        Grupo("Imprimir", Boton("Imprimir", "vista_imprimir_barra", "imprimir", Imprimir),
            Boton("Impresión\nrápida", "vista_impresion_rapida", "impresion_rapida", Imprimir));
        var menuEscala = Menu("Escala", "vista_escala_barra", "escala");
        foreach (int valor in new[] { 25, 50, 75, 100, 125, 150, 200 })
            Opcion(menuEscala, valor + "%", () => escala.Value = valor, icono: "escala");
        menuEscala.DropDownItems.Add(new ToolStripSeparator());
        Opcion(menuEscala, "Restablecer configuración", () =>
        {
            configuracion.Restaurar(); paginaInvalida = false; colorPagina = Color.White; filigrana = "";
            CargarAjustes(); ActualizarVista();
        }, "vista_restaurar", "deshacer");
        var menuMargenes = Menu("Márgenes", "vista_margenes_barra", "margenes");
        Opcion(menuMargenes, "Normal (1,27 cm)", () => AplicarMargenes(1.27m), icono: "margenes");
        Opcion(menuMargenes, "Estrecho (0,64 cm)", () => AplicarMargenes(.64m), icono: "margenes");
        Opcion(menuMargenes, "Ancho (2,54 cm)", () => AplicarMargenes(2.54m), icono: "margenes");
        Opcion(menuMargenes, "Personalizar márgenes…", () => izquierda.Focus(), icono: "margenes");
        var menuOrientacion = Menu("Orientación", "vista_orientacion_barra", "orientacion");
        foreach (string valor in new[] { "Vertical", "Horizontal" })
            Opcion(menuOrientacion, valor, () => orientacion.SelectedItem = valor, icono: "orientacion");
        var menuTamano = Menu("Tamaño", "vista_tamano_barra", "tamano");
        foreach (string valor in new[] { "A4", "A3", "Carta", "Oficio" })
            Opcion(menuTamano, valor, () => tamano.SelectedItem = valor, icono: "tamano");
        Grupo("Configurar página", menuEscala, menuMargenes, menuOrientacion, menuTamano,
            Boton("Buscar", "vista_buscar", "buscar", Buscar));
        primera = Boton("Primera\npágina", "vista_primera", "primera", () => MostrarPagina(0));
        anterior = Boton("Página\nanterior", "vista_anterior", "anterior", () => MostrarPagina(pagina - 1));
        siguiente = Boton("Página\nsiguiente", "vista_siguiente", "siguiente", () => MostrarPagina(pagina + 1));
        ultima = Boton("Última\npágina", "vista_ultima", "ultima", () => MostrarPagina(CantidadPaginas - 1));
        Grupo("Navegación", primera, anterior, siguiente, ultima);

        var grupoZoom = MYGVistaPreliminarCintaDiseno.Grupo(grupos, "Ampliación", 286);
        grupoZoom.Name = "vista_grupo_Ampliación";
        puntero = Boton("Seleccionar", "vista_puntero", "puntero", () => ModoMano(false));
        mano = Boton("Mano", "vista_mano", "mano", () => ModoMano(true));
        foreach (var modo in new[] { puntero, mano })
        {
            MYGEspecificacionesCinta.Icono(modo, modo == mano ? "mano" : "puntero", MYGVistaPreliminarCintaIconos.Dibujar, 24, false);
            modo.Width = 30; modo.Height = 32;
        }
        puntero.Checked = true;
        MYGVistaPreliminarCintaDiseno.Fila(grupoZoom, 4, puntero);
        MYGVistaPreliminarCintaDiseno.Fila(grupoZoom, 42, mano);
        varias = Boton("Varias\npáginas", "vista_varias_paginas", "varias_paginas", () =>
        {
            superficie.VariasPaginas = !superficie.VariasPaginas; varias.Checked = superficie.VariasPaginas;
            AjustarPagina(); ActualizarEstado();
        });
        var menuZoom = Menu("Ampliación", "vista_zoom_barra", "ampliacion");
        foreach (int valor in new[] { 25, 50, 75, 100, 125, 150, 200, 300, 400 })
            Opcion(menuZoom, valor + "%", () => CambiarZoom(valor / 100f), icono: "ampliacion");
        Opcion(menuZoom, "Página completa", AjustarPagina, "vista_ajustar", "pagina_completa");
        MYGVistaPreliminarCintaDiseno.Fila(grupoZoom, 40, 4, varias,
            Boton("Alejar", "vista_alejar", "zoom_menos", () => CambiarZoom(ampliacion / 1.12f)), menuZoom,
            Boton("Acercar", "vista_acercar", "zoom_mas", () => CambiarZoom(ampliacion * 1.12f)));
        Grupo("Fondo de página", Boton("Color de\npágina", "vista_color_pagina", "color_pagina", ColorPagina),
            Boton("Filigrana", "vista_filigrana", "filigrana", Filigrana));
        var correo = Boton("E-Mail\ncomo PDF", "vista_email", "email", CorreoPdf);
        correo.ToolTipText = "Guardar PDF y abrir un borrador de correo. Adjunte el archivo guardado antes de enviarlo.";
        var guardar = Boton("Guardar", "vista_guardar", "guardar", ExportarPdf); guardar.ToolTipText = "Guardar informe PDF";
        var abrir = Boton("Abrir", "vista_abrir", "abrir", AbrirPdf); abrir.ToolTipText = "Abrir un informe PDF guardado";
        Grupo("Exportar", Boton("Exportar\nPDF", "vista_pdf_barra", "pdf", ExportarPdf), correo, guardar, abrir);
    }

    private void AplicarMargenes(decimal cm)
    {
        cargando = true;
        try { izquierda.Value = derecha.Value = superior.Value = inferior.Value = cm; }
        finally { cargando = false; }
        CambiarPagina();
    }
    private void ModoMano(bool activo)
    {
        superficie.Arrastrar = activo; mano.Checked = activo; puntero.Checked = !activo;
    }
    private void ColorPagina()
    {
        using var dialogo = new ColorDialog { Color = colorPagina, FullOpen = true };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        colorPagina = dialogo.Color; ActualizarVista();
    }
    private void Filigrana()
    {
        string texto = PedirTexto("Filigrana", "Texto de fondo (vacío para quitarlo):", filigrana);
        if (texto == null) return;
        filigrana = texto; ActualizarVista();
    }
    private void Buscar()
    {
        if (vista == null) return;
        string texto = PedirTexto("Buscar en el informe", "Texto o valor:", "");
        if (string.IsNullOrWhiteSpace(texto)) return;
        int encontrado = vista.BuscarPagina(texto, pagina + 1);
        if (encontrado >= 0) MostrarPagina(encontrado);
        else MessageBox.Show(this, "No se encontró el texto en el informe.", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    private string PedirTexto(string titulo, string etiqueta, string texto)
    {
        using var dialogo = new Form { Text = titulo, StartPosition = FormStartPosition.CenterParent,
            ClientSize = new Size(430, 140), FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
        var entrada = new TextBox { Text = texto, MaxLength = 100, Location = new Point(16, 45), Width = 396 };
        var aceptar = new Button { Text = "Aceptar", DialogResult = DialogResult.OK, Location = new Point(236, 92), Width = 84 };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Location = new Point(328, 92), Width = 84 };
        dialogo.Controls.Add(new Label { Text = etiqueta, AutoSize = true, Location = new Point(16, 16) });
        dialogo.Controls.Add(entrada); dialogo.Controls.Add(aceptar); dialogo.Controls.Add(cancelar);
        dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
        return dialogo.ShowDialog(this) == DialogResult.OK ? entrada.Text.Trim() : null;
    }
    private void CorreoPdf()
    {
        ultimoPdf = null; ExportarPdf();
        if (ultimoPdf == null) return;
        string asunto = Uri.EscapeDataString("Informe · " + nombreDocumento);
        string cuerpo = Uri.EscapeDataString("Adjunte el PDF guardado en:\r\n" + ultimoPdf);
        Process.Start(new ProcessStartInfo("mailto:?subject=" + asunto + "&body=" + cuerpo) { UseShellExecute = true });
    }
    private void AbrirPdf()
    {
        using var dialogo = new OpenFileDialog { Title = "Abrir informe PDF", Filter = "Documento PDF (*.pdf)|*.pdf", CheckFileExists = true };
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            Process.Start(new ProcessStartInfo(dialogo.FileName) { UseShellExecute = true });
    }

    private static ComboBox Lista(string nombre) => new() { Name = nombre, DropDownStyle = ComboBoxStyle.DropDownList };
    private static NumericUpDown Numero(string nombre, decimal min, decimal max, decimal valor) => new() { Name = nombre, Minimum = min, Maximum = max, Value = valor };
    private static NumericUpDown Margen(string nombre) => new() { Name = nombre, DecimalPlaces = 2, Increment = .1m, Minimum = 0, Maximum = 7.62m };

    private void CargarAjustes()
    {
        cargando = true;
        try
        {
            var h = configuracion.Reportes[0].Hoja;
            orientacion.SelectedItem = h.OrientacionPagina; tamano.SelectedItem = h.TamanoPapel;
            izquierda.Value = Math.Clamp(h.MargenIzquierdo * 2.54m, izquierda.Minimum, izquierda.Maximum);
            derecha.Value = Math.Clamp(h.MargenDerecho * 2.54m, derecha.Minimum, derecha.Maximum);
            superior.Value = Math.Clamp(h.MargenSuperior * 2.54m, superior.Minimum, superior.Maximum);
            inferior.Value = Math.Clamp(h.MargenInferior * 2.54m, inferior.Minimum, inferior.Maximum);
            string fuente = h.Celdas.Values.FirstOrDefault()?.Fuente ?? MYGCeldaHoja.FuentePredeterminada;
            if (!fuentes.Items.Contains(fuente)) fuentes.Items.Add(fuente);
            fuentes.SelectedItem = fuente; escala.Value = (decimal)configuracion.Escala * 100;
            titulos.Checked = h.RepetirTitulos; lineas.Checked = h.ImprimirLineasDivision; encabezados.Checked = h.ImprimirEncabezados;
        }
        finally { cargando = false; }
    }
    private void CargarImpresoras()
    {
        cargando = true;
        try
        {
            impresoras.Items.Clear(); impresoras.Items.Add("Vista sin impresora");
            foreach (string nombre in PrinterSettings.InstalledPrinters) impresoras.Items.Add(nombre);
            var predeterminada = new PrinterSettings();
            impresoras.SelectedItem = predeterminada.IsValid && impresoras.Items.Contains(predeterminada.PrinterName)
                ? predeterminada.PrinterName : "Vista sin impresora";
        }
        finally { cargando = false; }
    }
    private PrinterSettings ImpresoraSeleccionada() => impresoras.SelectedIndex > 0
        ? new PrinterSettings { PrinterName = impresoras.Text } : null;
    private void CambiarPagina()
    {
        if (cargando) return;
        paginaInvalida = true;
        Cambiar(() =>
        {
            configuracion.ConfigurarPagina(tamano.Text, orientacion.Text,
                izquierda.Value / 2.54m, derecha.Value / 2.54m, superior.Value / 2.54m, inferior.Value / 2.54m);
            paginaInvalida = false;
        });
    }
    private void Cambiar(Action cambio)
    {
        if (cargando) return;
        // Una configuración inválida nunca debe dejar una vista antigua exportable.
        InvalidarVista();
        Intentar(() => { cambio(); ActualizarVista(); });
    }
    internal void ActualizarVista()
    {
        InvalidarVista();
        if (paginaInvalida) throw new InvalidOperationException("Corrija el papel, la orientación o los márgenes antes de continuar.");
        vista = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala, ImpresoraSeleccionada());
        vista.ColorPagina = colorPagina; vista.Filigrana = filigrana;
        hasta.Maximum = desde.Maximum = vista.CantidadPaginas;
        if (!rango.Checked) hasta.Value = vista.CantidadPaginas;
        MostrarPagina(Math.Min(pagina, vista.CantidadPaginas - 1));
        imprimir.Enabled = ImpresoraSeleccionada()?.IsValid == true;
        pdf.Enabled = true;
    }
    private void InvalidarVista()
    {
        vista = null; superficie.Limpiar();
        imprimir.Enabled = pdf.Enabled = false;
        primera.Enabled = anterior.Enabled = siguiente.Enabled = ultima.Enabled = false;
    }
    private void MostrarPagina(int indice)
    {
        if (vista == null || indice < 0 || indice >= vista.CantidadPaginas) return;
        pagina = indice;
        superficie.Cargar(vista, indice);
        ActualizarEstado();
        primera.Enabled = anterior.Enabled = pagina > 0;
        siguiente.Enabled = ultima.Enabled = pagina + 1 < CantidadPaginas;
    }
    private void CambiarZoom(float valor) => superficie.CambiarZoom(valor);
    private void AjustarPagina() => superficie.AjustarPagina();
    private void LeerZoom()
    {
        if (!float.TryParse(zoom.Text.Trim().TrimEnd('%'), NumberStyles.Float, CultureInfo.CurrentCulture, out float valor) || !float.IsFinite(valor))
            throw new InvalidOperationException("Indique una ampliación entre 25 % y 400 %.");
        CambiarZoom(valor / 100);
    }
    private void ActualizarEstado()
    {
        string paginas = superficie.VariasPaginas && pagina + 1 < CantidadPaginas
            ? "Páginas " + (pagina + 1) + "–" + (pagina + 2) : "Página " + (pagina + 1);
        string textoEstado = paginas + " de " + CantidadPaginas + "  ·  Ampliación " + (ampliacion * 100).ToString("0") + "%  ·  Ctrl + rueda para ampliar";
        if (estado.Text != textoEstado) estado.Text = textoEstado;
        cargando = true;
        try
        {
            int porcentaje = Math.Clamp((int)Math.Round(ampliacion * 100), deslizadorZoom.Minimum, deslizadorZoom.Maximum);
            if (deslizadorZoom.Value != porcentaje) deslizadorZoom.Value = porcentaje;
            string textoZoom = (ampliacion * 100).ToString("0") + "%";
            if (zoom.Text != textoZoom) zoom.Text = textoZoom;
        }
        finally { cargando = false; }
    }
    private void Imprimir()
    {
        if (vista == null) throw new InvalidOperationException("Corrija la configuración y actualice la vista antes de imprimir.");
        var ajustes = ImpresoraSeleccionada();
        if (ajustes?.IsValid != true) throw new InvalidOperationException("Seleccione una impresora disponible.");
        ajustes.Copies = (short)copias.Value;
        ajustes.MinimumPage = 1; ajustes.MaximumPage = CantidadPaginas;
        ajustes.FromPage = (int)desde.Value; ajustes.ToPage = (int)hasta.Value;
        ajustes.PrintRange = rango.Checked ? PrintRange.SomePages : PrintRange.AllPages;
        // Usar el plan visible conserva exactamente los cortes y páginas revisados.
        // La impresora, el rango y las copias se eligen en el panel de esta vista.
        using var documento = vista.Documento(nombreDocumento, ajustes);
        documento.Print();
    }
    private void ExportarPdf()
    {
        if (vista == null) throw new InvalidOperationException("Corrija la configuración y actualice la vista antes de exportar.");
        const string nombre = "Microsoft Print to PDF";
        if (!PrinterSettings.InstalledPrinters.Cast<string>().Any(n => string.Equals(n, nombre, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Active Microsoft Print to PDF en las características de Windows para exportar el informe como PDF.");
        if (!string.Equals(impresoras.Text, nombre, StringComparison.OrdinalIgnoreCase))
        {
            // El cambio de driver puede cambiar los cortes. Revisarlos precede al guardado.
            cargando = true;
            try { impresoras.SelectedItem = nombre; }
            finally { cargando = false; }
            ActualizarVista();
            estado.Text = "Vista preparada para PDF. Revise las páginas y pulse Exportar PDF para guardar.";
            return;
        }
        var ajustes = new PrinterSettings { PrinterName = nombre };
        using var dialogo = new SaveFileDialog { Title = "Exportar informe a PDF", Filter = "Documento PDF (*.pdf)|*.pdf",
            DefaultExt = "pdf", AddExtension = true, FileName = "Informe.pdf", OverwritePrompt = true };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        ajustes.PrintToFile = true; ajustes.PrintFileName = dialogo.FileName;
        ajustes.PrintRange = rango.Checked ? PrintRange.SomePages : PrintRange.AllPages;
        ajustes.FromPage = (int)desde.Value; ajustes.ToPage = (int)hasta.Value;
        using var documento = vista.Documento(nombreDocumento, ajustes);
        documento.PrintController = new StandardPrintController();
        documento.Print();
        ultimoPdf = dialogo.FileName;
    }
    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            estado.Text = ex.Message;
            MessageBox.Show(this, ex.Message, "Vista preliminar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) superficie.Limpiar();
        base.Dispose(disposing);
    }
}
